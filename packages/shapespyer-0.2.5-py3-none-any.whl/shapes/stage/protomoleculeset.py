"""
.. module:: protosmoleculeset
       :platform: Linux - tested, Windows [WSL Ubuntu] - tested
       :synopsis: contributes to the hierarchy of classes:
        Atom > AtomSet > Molecule > MoleculeSet > MolecularSystem

.. moduleauthor:: Dr Andrey Brukhno <andrey.brukhno[@]stfc.ac.uk>

The module contains class MoleculeSet(object)
"""

# This software is provided under The Modified BSD-3-Clause License (Consistent with Python 3 licenses).
# Refer to and abide by the Copyright detailed in LICENSE file found in the root directory of the library!

##################################################
#                                                #
#  Shapespyer - soft matter structure generator  #
#                                                #
#  Author: Dr Andrey Brukhno (c) 2020 - 2025     #
#          Daresbury Laboratory, SCD, STFC/UKRI  #
#                                                #
##################################################

##from __future__ import absolute_import
__author__ = "Andrey Brukhno"


import logging
import sys

import time
import numpy as np
from math import sin, cos, atan2, sqrt

from shapes.basics.defaults import NL_INDENT
from shapes.basics.globals import TINY, Pi
from shapes.basics.functions import pbc, timing, sec2hms, distSSD
from shapes.basics.mendeleyev import Chemistry

# from shapes.stage.protoatom import Atom
# from shapes.stage.protoatomset import AtomSet
from shapes.stage.protomolecule import Molecule
from shapes.stage.protovector import Vec3

import scipy.spatial.distance as sd

logger = logging.getLogger("__main__")


#MAXR = 990 # max recursion depth

class MoleculeSet(object):
    """
    Class **MoleculeSet** - defines a collection of
    :class:`Molecule` instances, most often of the same type 
    (but not necessarily).
    """
    def __init__(self,
                 sindx  : int  = 0,
                 sitems : int  = 0,
                 sname  : str  = 'empty',
                 stype  : str  = 'empty',
                 mols   : list[Molecule] | None = None,
                 **keys
                 ) -> None:
        """
        Initialize an instance of :class:`MoleculeSet`.

        Creates a set of molecules, either from provided list, by copying a sample,
        or by generating new ones from specified list of molecules.

        Parameters
        ----------
        sindx : int, optional
            Index of the molecule set 
            (default 0).
        sitems : int, optional
            Number of molecules to create if mols is None 
            (default 0).
        sname : str, optional
            Name of the molecule set (default 'empty').
        stype : str, optional
            Type of the molecule set (default 'empty').
        mols : list of :class:`Molecule`, optional
            List of molecules to include (default None).
        **keys
            Keyword arguments for molecule set creation.

        Returns
        -------
        None
        """
        # *args
        #     Positional arguments for molecule set creation.
        # **keys
        #     Keyword arguments for molecule set creation.
        # """
        self.indx = sindx
        self.mass = 0.0
        self.chrg = 0.0
        self.items = []
        self.nitems = 0
        self.rvec = None
        self.rcog = None
        self.sample = None
        self.neibours = None
        self.clusters = None
        self.clustnum = None
        self.isMassElems = False
        if mols is not None:
            try:
                _ = iter(mols)
            except (
                TypeError
            ):  # non-iterable => use a sample / template molecule
                if isinstance(mols, Molecule):
                    self.sample = mols.copy()
                    if (sitems > 0):  
                        # create a set of same molecules (copies of sample)
                        for i in range(sitems):
                            self.items.append(mols.copy(i))
                        self.nitems = len(self.items)
                        self.name = self.items[0].name
                        self.type = self.items[0].type
            else:  # iterable
                if isinstance(mols[0], Molecule):  
                    # use the given set of molecules
                    self.sample = mols[0].copy()
                    self.items = mols[:]
                    self.nitems = len(self.items)
                    self.name = self.items[0].name
                    self.type = self.items[0].type
        elif (sitems > 0):  
            # create a set of same molecules defined by (*args, **keys)
            #self.sample = Molecule(0, *args, **keys)
            self.sample = Molecule(0, **keys)
            for i in range(sitems):
                self.items.append(Molecule(i, **keys))
                #self.items.append(Molecule(i, *args, **keys))
            self.nitems = len(self.items)
            self.name = self.items[0].name
            self.type = self.items[0].type
        else:
            self.name = sname
            self.type = stype
        self.refresh()

    def copy(self, sindx: int = -1):
        """
        Create a copy of the molecule set.

        Parameters
        ----------
        sindx : int, optional
            Index for the new set (default -1 falls back to ``self.indx``).

        Returns
        -------
        MoleculeSet
            A new MoleculeSet instance with copied set of molecules.
        """
        setIndex = sindx
        if setIndex < 0:
            setIndex = self.indx
        new_items = []
        for mol in self.items:
            new_items.append(mol.copy())
        new_set = MoleculeSet(setIndex,
                              sitems=len(self.items),
                              sname=self.name,
                              stype=self.type,
                              mols=new_items,
                              )
        # AB: it's all set upon refresh() in the init
        # new_set.mass = self.mass,
        # new_set.chrg = self.chrg,
        # new_set.nitems = self.nitems
        # new_set.rvec   = self.rvec
        # new_set.rcog   = self.rcog
        # new_set.sample = self.sample
        new_set.neibours  = self.neibours
        new_set.clusters  = self.clusters
        new_set.clustnum  = self.clustnum
        new_set.isMassElems = self.isMassElems
        return new_set

    def __del__(self) -> None:
        while len(self.items) > 0:
            del self.items[len(self) - 1]
        del self.items
        del self.rvec

    def __repr__(self) -> str:
        return (
            "{self.__class__.__name__} => {{ index: {self.indx}, name: '{self.name}', type: '{self.type}', "
            "mass: {self.mass}, charge: {self.chrg}, nitems: {self.nitems};\n rvec: {self.rvec};\n rcog: {self.rcog} }}".format(
                self=self
            )
        )

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, i: int) -> Molecule:
        return self.items[i]

    def addItem(self, mol: Molecule = None, verbose: bool = False) -> None:
        """
        Add a molecule to the molecule set.

        Updates cumulative properties and sets name/type 
        if they are currently 'empty'.

        Parameters
        ----------
        mol : Molecule, optional
            Molecule to add.
        verbose : bool, optional
            If ``True``, log on invalid input.

        Returns
        -------
        None
        """
        if isinstance(mol, Molecule):
            self.items.append(mol)  # .copy()
            self.nitems = len(self.items)
            if self.name == "empty":
                self.name = mol.name
            if self.type == "empty":
                self.type = mol.type
            if self.rvec is None:
                self.rvec = Vec3()
                self.rcog = Vec3()
            self.rvec += mol.getRvec()
            self.rcog += mol.getRcog()
            self.mass += mol.getMass()
            self.chrg += mol.getCharge()
        elif verbose:
            logger.info(f"Input {mol} does not qualify as "
                         f"Molecule(AtomSet) - skipped (item not added)!")

    def setSample(self, mol: Molecule = None, verbose: bool = False) -> None:
        """
        Set the sample molecule for the molecule set.

        Parameters
        ----------
        mol : Molecule, optional
            Sample molecule.
        verbose : bool, optional
            If ``True``, log on invalid input.

        Returns
        -------
        None
        """
        if isinstance(mol, Molecule):
            if self.sample is not None:
                del self.sample
            self.sample = mol.copy()
            if self.name == "empty":
                self.name = mol.name
            if self.type == "empty":
                self.type = mol.type
        elif verbose:
            logger.info(
                f"Input {mol} does not qualify as "
                f"Molecule(AtomSet) - skipped (sample not set)!"
            )

    def setMass(self, isupdate: bool = False) -> None:
        """
        Recalculate the total mass of the molecule set.

        Parameters
        ----------
        isupdate : bool, optional
            If ``True``, refresh individual molecule masses.

        Returns
        -------
        None
        """
        self.mass = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            for mol in self.items:
                self.mass += mol.getMass(isupdate)

    def setMassElems(self) -> bool:
        """
        Set masses from their atoms' elements for all molecules.

        Returns
        -------
        bool
            ``True`` if successful for all.
        """
        success = False
        self.nitems = len(self.items)
        if self.nitems > 0:
            success = True
            mass = 0.0
            for mol in self.items:
                if not mol.setMassElems():
                    success = False
                    break
                mass += mol.getMass()
            if success:
                self.mass = mass
        self.isMassElems = success
        return success

    def getMass(self, isupdate: bool = False) -> float:
        """
        Get the total mass.

        Parameters
        ----------
        isupdate : bool, optional
            If ``True``, refresh first.

        Returns
        -------
        float
            Total mass.
        """
        if isupdate:
            self.setMass(isupdate)
        return self.mass

    def setCharge(self, isupdate: bool = False) -> None:
        """
        Recalculate the total charge.

        Parameters
        ----------
        isupdate : bool, optional
            If ``True``, update individual charges.

        Returns
        -------
        None
        """
        self.chrg = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            for mol in self.items:
                self.chrg += mol.getCharge(isupdate)

    def getCharge(self, isupdate: bool = False) -> float:
        """
        Get the total charge.

        Parameters
        ----------
        isupdate : bool, optional
            If ``True``, refresh first.

        Returns
        -------
        float
            Total charge.
        """
        if isupdate:
            self.setCharge(isupdate)
        return self.chrg

    def refresh(self, **kwargs) -> None:
        """
        Recalculate all aggregate properties.

        Parameters
        ----------
        **kwargs
            Passed to the :class:`Molecule` :meth:`refresh` method.

        Returns
        -------
        None
        """
        if self.rvec is not None:
            del self.rvec
        if self.rcog is not None:
            del self.rcog
        self.mass = 0.0
        self.chrg = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            self.rvec = Vec3()
            self.rcog = Vec3()
            for mol in self.items:
                mol.refresh(**kwargs)
                self.mass += mol.mass
                self.chrg += mol.chrg
                self.rcog += mol.rcog
                self.rvec += mol.rvec * mol.mass
            self.rvec /= self.mass
            self.rcog /= float(self.nitems)

    def updateRcom(self, isupdate: bool = False, **kwargs) -> None:  # center of mass
        if self.rvec is not None:
            del self.rvec
        self.mass = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            self.rvec = Vec3()
            for mol in self.items:
                mol.updateRcom(**kwargs)
                self.mass += mol.mass
                self.rvec += mol.rvec * mol.mass
            self.rvec /= self.mass

    def getRvec(self, isupdate: bool = False, **kwargs) -> Vec3:  # center of mass
        if isupdate:
            self.updateRcom(**kwargs)
        return self.rvec

    def getRcom(self, isupdate: bool = False, **kwargs) -> Vec3:  # center of mass
        """
        Get the center-of-mass vector (alias for getRvec).

        Parameters
        ----------
        isupdate : bool, optional
            Flag to update COM before returning. 
            Default is ``False``.
        **kwargs
            Passed to :meth:`updateRcom`, if ``isupdate = True``.

        Returns
        -------
        Vec3
            The COM vector.
        """
        return self.getRvec(isupdate, **kwargs)

    def getRcomPBC(self, box: float | Vec3 = 1.0) -> Vec3:
        """
        Get the center-of-mass vector 
        with periodic boundary conditions applied.

        Parameters
        ----------
        box : float or Vec3, optional
            Peiodic box dimension(s) for PBC wrapping. 
            Default is 1.0 (same for all three dimensions).

        Returns
        -------
        Vec3
            The COM vector with PBC applied.
        """
        return pbc(self.getRvec().copy(), box)

    def updateRcog(self, **kwargs) -> None:  # center of geometry
        """
        Update the center-of-geometry (COG) vector.

        Parameters
        ----------
        **kwargs
            Passed to :class:`Molecule` :meth:`updateRcog` method.

        Returns
        -------
        None
        """
        if self.rcog is not None:
            del self.rcog
        self.nitems = len(self.items)
        if self.nitems > 0:
            self.rcog = Vec3()
            for mol in self.items:
                mol.updateRcog(**kwargs)
                self.rcog += mol.rcog
            self.rcog /= float(self.nitems)

    def getRcog(self, isupdate: bool = False, **kwargs) -> Vec3:  # center of geometry
        """
        Get the center-of-geometry (COG) vector.

        Parameters
        ----------
        isupdate : bool, optional
            Flag to update COG before returning. 
            Default is ``False``.
        **kwargs
            Passed to updateRcog if ``isupdate = True``.

        Returns
        -------
        Vec3
            The COG vector.
        """
        if isupdate:
            self.updateRcog(**kwargs)
        return self.rcog

    def getRcogPBC(self, box: float | Vec3 = 1.0) -> Vec3:
        """
        Get the COG vector with periodic boundary conditions applied.

        Parameters
        ----------
        box : float or Vec3, optional
            Periodic box dimensions for PBC handling. 
            Default is 1.0 (same for all dimensions).

        Returns
        -------
        Vec3
            The COG vector with PBC applied.
        """
        return pbc(self.getRcog().copy(), box)

    @timing
    def getRcomCls(self, box: list[float] = [1.0, 1.0, 1.0]) -> Vec3:
        """
        Compute COM using the trigonometric method 
        for periodic boundary conditions.

        Parameters
        ----------
        box : list of float, optional
            Periodic box dimensions [x, y, z]. 
            Default is [1.0, 1.0, 1.0].

        Returns
        -------
        Vec3
            The COM vector.
        """
        xi_x = zeta_x = 0.0
        xi_y = zeta_y = 0.0
        xi_z = zeta_z = 0.0
        mass = 0.0
        for mol in self.items:
            for atom in mol.items:
                theta_x = (2.0 * atom.getRvec()[0] / box[0] + 1.0) * Pi
                theta_y = (2.0 * atom.getRvec()[1] / box[1] + 1.0) * Pi
                theta_z = (2.0 * atom.getRvec()[2] / box[2] + 1.0) * Pi
                mass_i = atom.getMass()
                xi_x += cos(theta_x) * mass_i
                zeta_x += sin(theta_x) * mass_i
                xi_y += cos(theta_y) * mass_i
                zeta_y += sin(theta_y) * mass_i
                xi_z += cos(theta_z) * mass_i
                zeta_z += sin(theta_z) * mass_i
                mass += mass_i
        omega_x = atan2(-zeta_x, -xi_x) + Pi
        omega_y = atan2(-zeta_y, -xi_y) + Pi
        omega_z = atan2(-zeta_z, -xi_z) + Pi
        com_x = 0.5 * box[0] * (omega_x / Pi - 1.0)
        com_y = 0.5 * box[1] * (omega_y / Pi - 1.0)
        com_z = 0.5 * box[2] * (omega_z / Pi - 1.0)
        self.rvec = Vec3(com_x, com_y, com_z)
        return self.rvec

    def getMolRcoms(self) -> list[Vec3]:
        """
        Get the COM vectors for all molecules.

        Returns
        -------
        list[Vec3]
            List of COM vectors for each molecule.
        """
        return [ mol.getRcom() for mol in self.items ]

    def getMolRcomsArr3(self) -> list[np.ndarray]:
        """
        Get the COM vectors as 3-element arrays for all molecules.

        Returns
        -------
        list[np.ndarray]
            List of COM vectors as numpy arrays for each molecule.
        """
        return [ mol.getRcom().arr3() for mol in self.items ]

    def imagesVecs3(self,
                   vecs: list[np.ndarray] | None = None,
                   box: Vec3 | None = None,
                   dmax: float = 0.0,
                   ) -> tuple[list[np.ndarray], dict]:
        """
        Create ghost images of points near box boundaries.

        Parameters
        ----------
        vecs : list[np.ndarray], optional
            List of vectors to replicate. 
            Default is  ``None``.
        box : Vec3, optional
            Periodic box dimensions. 
            Default is  ``None``.
        dmax : float, optional
            Maximum distance for replication. 
            Default is 0.0.

        Returns
        -------
        tuple[list[np.ndarray], dict]
            Tuple of replicated points and mapping dictionary.
        """
        # if not vecs:
        #     raise ValueError(f"imagesVec3(): Insufficient input: "
        #                      f"check that vecs and box are non None "
        #                      f"and cutoff > 0.0!")
        if not (vecs and box and dmax > TINY):
            raise ValueError(f"imagesVec3(): Insufficient input: "
                             f"check that vecs and box are not None "
                             f"and cutoff > 0.0!")
        nvec = len(vecs)
        boxx = (box * 0.5 - Vec3(dmax-TINY, dmax-TINY, dmax-TINY)).arr3()
        # create a map of additional indices pointing to the original ones
        vmap = dict()
        vecx = list()
        imap = 0
        imapp= []
        imaps= set()
        for iv in range(nvec):
            ipmap = imap
            #vec  = Vec3(*vecs[iv]).arr3()
            vec0 = Vec3(*vecs[iv]).arr3()
            vec1 = Vec3(*vecs[iv]).arr3()
            vec2 = Vec3(*vecs[iv]).arr3()
            # extend the system by adding the nearest images of
            # molecules (their COM's) within dmax from the box lower boundaries
            if vec0[0] < -boxx[0]:
                vec0[0] += box[0]
                vecx.append(vec0)
                vmap.update({str(nvec + imap): iv})
                imap += 1
            elif vec0[0] > boxx[0]:
                vec0[0] -= box[0]
                vecx.append(vec0)
                vmap.update({str(nvec + imap): iv})
                imap += 1
            if vec1[1] < -boxx[1]:
                vec1[1] += box[1]
                vecx.append(vec1)
                vmap.update({str(nvec + imap): iv})
                imap += 1
                if vec1[0] != vec0[0]:
                    vecx.append(Vec3(vec0[0], vec1[1], vec1[2]))
                    vmap.update({str(nvec + imap): iv})
                    imap += 1
            elif vec1[1] > boxx[1]:
                vec1[1] -= box[1]
                vecx.append(vec1)
                vmap.update({str(nvec + imap): iv})
                imap += 1
                if vec1[0] != vec0[0]:
                    vecx.append(Vec3(vec0[0], vec1[1], vec1[2]))
                    vmap.update({str(nvec + imap): iv})
                    imap += 1
            if vec2[2] < -boxx[2]:
                vec2[2] += box[2]
                vecx.append(vec2)
                vmap.update({str(nvec + imap): iv})
                imap += 1
                if vec2[0] != vec0[0]:
                    vecx.append(Vec3(vec0[0], vec2[1], vec2[2]))
                    vmap.update({str(nvec + imap): iv})
                    imap += 1
                    if vec2[1] != vec1[1]:
                        vecx.append(Vec3(vec0[0], vec1[1], vec2[2]))
                        vmap.update({str(nvec + imap): iv})
                        imap += 1
                elif vec2[1] != vec1[1]:
                    vecx.append(Vec3(vec0[0], vec1[1], vec2[2]))
                    vmap.update({str(nvec + imap): iv})
                    imap += 1
            elif vec2[2] > boxx[2]:
                vec2[2] -= box[2]
                vecx.append(vec2)
                vmap.update({str(nvec + imap): iv})
                imap += 1
                if vec2[0] != vec0[0]:
                    vecx.append(Vec3(vec0[0], vec2[1], vec2[2]))
                    vmap.update({str(nvec + imap): iv})
                    imap += 1
                    if vec2[1] != vec1[1]:
                        vecx.append(Vec3(vec0[0], vec1[1], vec2[2]))
                        vmap.update({str(nvec + imap): iv})
                        imap += 1
                elif vec2[1] != vec1[1]:
                    vecx.append(Vec3(vec0[0], vec1[1], vec2[2]))
                    vmap.update({str(nvec + imap): iv})
                    imap += 1

            imapp.append(imap-ipmap)
            imaps.add(imap-ipmap)

        logger.info(f"Number of images per point: {imaps} -> {sum(imapp)} in total")

        # logger.debug(f"{len(vmap)} points "
        #       f"to add to the original {len(vecs)} ...")
        return vecx, vmap

    def imagesVec3(self,
                   points: list[np.ndarray] | None = None,
                   box: Vec3 | None = None,
                   dmax: float = 0.0,
                   ) -> tuple[list[np.ndarray], dict]:
        """
        Create ghost images of points near box boundaries.

        Parameters
        ----------
        points : list[np.ndarray], optional
            List of points to replicate. 
            Default is  ``None``.
        box : Vec3, optional
            Box dimensions. 
            Default is  ``None``.
        dmax : float, optional
            Maximum distance for replication. 
            Default is 0.0.

        Returns
        -------
        tuple[list[np.ndarray], dict]
            Tuple of image points and mapping dictionary.
        """

        from itertools import combinations, product
        # Determine which points are near boundaries
        ghost_shifts = []
        ghost_indices = []

        #points = np.asarray(points)
        n_points = len(points)
        boxx = np.asarray(box * 0.5 - Vec3(dmax, dmax, dmax))

        shifts = product([-1, 0, 1], repeat=3)

        for i, shft in enumerate(shifts):
            if shft == (0, 0, 0):
                continue  # skip the original
            shift = np.array(shft)
            shift_vec = shift * box

            # Determine which points would interact across this boundary
            mask = np.ones(n_points, dtype=bool)
            for dim in range(3):
                if shift[dim] == -1:
                    mask &= points[:, dim] > boxx[dim] # (box[dim] - cutoff)
                elif shift[dim] == 1:
                    mask &= points[:, dim] < -boxx[dim]  # cutoff
            if not np.any(mask):
                continue  # no points to replicate in this shift

            ghost_shifts.append(shift_vec)
            ghost_indices.append(np.where(mask)[0])

        # Build KDTree with original + minimal ghost images
        image_points = list(points)
        image_map = dict()

        nvec = n_points
        imapp= [ 0 for _ in range(nvec)]
        imap = 0
        for shift_vec, idxs in zip(ghost_shifts, ghost_indices):
            shifted = points[idxs] + shift_vec
            image_points.append(shifted)
            for idx in idxs:
                image_map.update({str(nvec + imap): int(idx)})
                imap += 1
                imapp[idx] += 1

        imaps = set([ imp for imp in imapp ])
        logger.info(f"Number of images per particle: {imaps} -> {sum(imapp)} in total")

        # logger.debug(f"{len(image_map)} points "
        #       f"to add to the original {len(points)} ...")
        return image_points, image_map

    @timing
    def findNeighboursKDT(self,
        box: Vec3 | None = None,
        dmax: float = 1.5,
        nmax = 15,
        verbose: bool = False,
    ) -> list[list[int]]:
        """
        Collect ``nmax`` nearest neighbours for each molecule in the molecule set.
        The method uses the KD-Tree algorithm with periodic boundary conditions,
        which appears to be the most efficient for the purpose.

        Parameters
        ----------
        box: Vec3 (3D vector with positive components)
            Simulation box dimensions

        dmax: float (must be positive)
            Cutoff distance for including neighbours

        nmax: int (must be positive)
            Maximum number of neighbours to include per molecule

        Returns
        -------
        self.neibours : list[list[int]]

        """
        #from scipy.spatial import KDTree
        from scipy.spatial import cKDTree as KDTree
        # stime = time.time()
        norg = self.nitems
        vecs = [ mol.getRvec().arr3() for mol in self.items ]
        vecs, vmap = self.imagesVec3(np.array(vecs), box, dmax)
        vecs = np.vstack(vecs)
        # vecx, vmap = self.imagesVecs3(vecs, box, dmax)
        # vecs.extend(vecx)
        # vecs = np.array(vecs)
        self.Vecs = vecs
        self.Vmap = vmap

        tree = KDTree(vecs)
        # AB: uncomment the next line to collect pairwise distances
        # ssd_dnnb = []
        # kdt_rnnb = []
        # mnbr = []
        kdt_rnnb = [ [] for i in range(self.nitems) ]
        mnbr = [ [] for i in range(self.nitems) ]
        # split the main loop into molecule batches
        # to be able to report the progress in the terminal.
        # if redirecting into a log file, remove `\r` at the end of lines
        # as follows: `sed -i 's/\r/\n/g' log_file`
        nrep = 100
        loop = int(norg / nrep) + 1
        ltime = time.time()
        il = 0
        k  = 0
        while il < loop:
            if il == 10:
                il = 1
                nrep *= 10
                loop = int(norg / nrep) + 1
            jrem = norg - il * nrep
            if jrem > nrep:
                jrem = nrep
            for j in range(jrem):
                k = il * nrep + j
                rnnb = tree.query_ball_point(vecs[k], dmax, workers=4)
                dnnb = distSSD(vecs[k], vecs[rnnb])
                rnnb = [ int(idx) if idx < norg else vmap[str(int(idx))]
                         for idx, dst in sorted(zip(rnnb, dnnb),
                                           key=lambda pair: pair[1])[:nmax] ]
                kdt_rnnb[k].extend(rnnb)
                mnbr[k].extend([ int(idx) for idx in rnnb if int(idx) != k ])
                # kdt_rnnb.append(rnnb)
                # mnnb = rnnb[:]
                # mnnb.pop(mnnb.index(k))
                # mnbr.append(mnnb)
                # if k < 6:  # or k > norg - 6:
                #     logger.debug(f"rnnb: {kdt_rnnb[k]}")
                #     logger.debug(f"mnnb: {mnbr[k]}")
                #     logger.debug(f"dnnb: {sorted(dnnb)[:nmax]}")
            secs = time.time() - ltime
            esec = secs * float(norg) / float(k + 1)
            logger.debug(f"{k + 1} / {norg} = {100.0 * float(k + 1) / float(norg):.3f} "
                         f"% done in {sec2hms(secs)} -> total time: {sec2hms(esec)}")
            il += 1
        # AB: kdt_rnnb neighbours include self!
        self.neibours = mnbr  # proper neighbour-lists (excluding self!)
        # AB: uncomment the next line to collect pairwise distances
        # self.dnnbs = ssd_dnnb
        # AB: collect stats
        nnbrs = [len(nbr) for nbr in mnbr]
        # nnbrs0 = [len(nbr) for nbr in mnbr if len(nbr)==0]
        minnbs = min(nnbrs)
        cminnb = nnbrs.count(minnbs)
        maxnbs = max(nnbrs)
        cmaxnb = nnbrs.count(maxnbs)
        if verbose:
            counts = []
            for nc in range(minnbs, maxnbs+1):
                num = nnbrs.count(nc)
                if num > 0:
                    counts.append((nc,num))
                    logger.debug(f"min = {minnbs} ({nnbrs.count(minnbs)}), "
                                 f"max = {maxnbs} ({nnbrs.count(maxnbs)}), "
                                 f"avr = {np.sum(nnbrs) / len(mnbr)}; "
                                 f"dmax = {dmax}, nmax = {nmax}"
                                 f"{NL_INDENT}counts = {counts}")
        else:
            logger.info(f"min = {minnbs} ({nnbrs.count(minnbs)}), "
                        f"max = {maxnbs} ({nnbrs.count(maxnbs)}), "
                        f"avr = {np.sum(nnbrs) / len(mnbr)}; "
                        f"dmax = {dmax}, nmax = {nmax}")
        # AB: uncomment the next 3 lines for benchmarking
        # etime = time.time()
        # logger.debug(f"Elapsed time for ssd_dist {sec2hms(etime-stime)}{NL_INDENT}"
        #       f"{kdt_rnnb[:10]}")
        return kdt_rnnb
    # end of findNeighboursKDT()

    @timing
    def findNeighboursSSD(self,
        box: Vec3 = Vec3(),
        dmax: float = 1.5,
        nmax = 15,
        verbose: bool = False,
    ) -> list[list[int]]:
        """
        Collect nearest neighbours using the SSD method -
        a less efficient alternative to the KD-Tree method 
        (for debugging purposes).

        Parameters
        ----------
        box : Vec3, optional
            Simulation box dimensions. 
            Default is Vec3().
        dmax : float, optional
            Cutoff distance. 
            Default is 1.5.
        nmax : int, optional
            Maximum number of neighbours. 
            Default is 15.
        verbose : bool, optional
            Whether to print verbose output. 
            Default is ``False``.

        Returns
        -------
        list[list[int]]
            List of neighbour lists for each molecule.
        """
        # collect molecule neighbour-lists
        # internally within the molecule set
        from shapes.basics.functions import rnn, knn
        stime = time.time()
        norg = self.nitems
        vecs = [ mol.getRvec().arr3() for mol in self.items ]
        vecs, vmap = self.imagesVec3(np.array(vecs), box, dmax)
        vecs = np.vstack(vecs)
        # vecx, vmap = self.imagesVec3(vecs, box, dmax)
        # vecs.extend(vecx)
        # vecs = np.array(vecs)
        self.Vecs = vecs
        self.Vmap = vmap

        # ssd_dnnb = []
        ssd_rnnb = [ [] for i in range(self.nitems) ]
        mnbr = [ [] for i in range(self.nitems) ]
        nrep = 100
        loop = int(norg / nrep) + 1
        ltime = time.time()
        il = 0
        k  = 0
        while il < loop:
            if il == 10:
                il = 1
                nrep *= 10
                loop = int(norg / nrep) + 1
            jrem = norg - il * nrep
            if jrem > nrep:
                jrem = nrep
            for j in range(jrem):
                k = il * nrep + j
                # all neighbours within max distance
                dnnb = distSSD(vecs[k], vecs)
                # first nmax nearest-neighbours:
                # mnnb = np.argpartition(dnnb, mmax)[1:mmax]
                # ssd_knnb.append(mnnb)
                # all nearest neighbours within cutoff
                # rnnb = sorted([ int(inn) for inn in
                #                 list(np.where(dnnb < dmax)[0][:]) ]) # [:mmax])
                rnnb = [ idx if idx < norg else vmap[str(int(idx))]
                         for idx in list(np.where(dnnb < dmax)[0][:nmax]) ]
                ssd_rnnb[k].extend(rnnb)
                mnnb = rnnb[:]
                mnnb.pop(mnnb.index(k))
                mnbr[k].extend(mnnb)
                # ssd_dnnb.append(dnnb)
                # if k < 6:  # or k > norg - 6:
                #     logger.debug(f"mnnb: {mnbr[k]}")
                #     logger.debug(f"rnnb: {rnnb}")
                #     logger.debug(f"dnnb: {dnnb[rnnb]}")
                # ssd_knnb.append(knn(vecs[k], vecs, mmax)[1:mmax])
                # ssd_rnnb.append(rnn(vecs[k], vecs, dmax)[0][1:mmax])
            secs = time.time() - ltime
            esec = secs * float(norg) / float(k + 1)
            logger.info(f"{k + 1} / {norg} = {100.0 * float(k + 1) / float(norg):.3f} "
                        f"% done in {sec2hms(secs)} -> total time: {sec2hms(esec)}")
            il += 1
        nnbrs = [len(nbr) for nbr in mnbr]
        # nnbrs0 = [len(nbr) for nbr in mnbr if len(nbr)==0]
        minnbs = min(nnbrs)
        maxnbs = max(nnbrs)
        if verbose:
            counts = []
            for nc in range(minnbs, maxnbs+1):
                num = nnbrs.count(nc)
                if num > 0:
                    counts.append((nc,num))
                    logger.debug(f"min = {minnbs} ({nnbrs.count(minnbs)}), "
                                 f"max = {maxnbs} ({nnbrs.count(maxnbs)}), "
                                 f"avr = {np.sum(nnbrs) / len(mnbr)}; "
                                 f"dmax = {dmax}, nmax = {nmax}"
                                 f"{NL_INDENT}counts = {counts}")
        else:
            logger.info(f"min = {minnbs} ({nnbrs.count(minnbs)}), "
                        f"max = {maxnbs} ({nnbrs.count(maxnbs)}), "
                        f"avr = {np.sum(nnbrs) / len(mnbr)}; "
                        f"dmax = {dmax}, nmax = {nmax}")

        # AB: ssd_rnnb neighbours include self!
        self.neibours = mnbr  # proper neighbour-lists (excluding self!)
        # self.dnnbs = ssd_dnnb
        # etime = time.time()
        # logger.debug(f"Elapsed time for ssd_dist {sec2hms(etime-stime)}{NL_INDENT}"
        #       f"{ssd_rnnb[:10]}")
        return ssd_rnnb
    # end of findNeighboursSSD()

    @timing
    def findNeighbours(self,
        box: Vec3 | None = None,
        dmax: float = 1.5,
        nmax: int = 15,
        verbose: bool = False,
    ) -> list[list[int]]:
        """
        Collect nearest neighbours using direct calculation of distances.

        Parameters
        ----------
        box : Vec3, optional
            Simulation box dimensions. 
            Default is  ``None``.
        dmax : float, optional
            Cutoff distance. 
            Default is 1.5 (nm).
        nmax : int, optional
            Maximum number of neighbours. 
            Default is 15.
        verbose : bool, optional
            Flag to log debug info. 
            Default is ``False``.

        Returns
        -------
        list[list[int]]
            List of neighbour lists for each molecule.
        """

        # collect molecule neighbour-lists
        # internally within the molecule set
        ltime = time.time()
        dmax2 = dmax*dmax
        mmax = nmax+1
        mnbr = [ [] for i in range(self.nitems) ]
        norg = self.nitems
        loop = int((self.nitems-1) / 100)+1
        k = 0
        for i in range(loop):
            jrem = self.nitems-1 - i * 100
            if jrem > 100:
                jrem = 100
            for j in range(jrem):
                k = i*100 + j
                if len(mnbr[k]) < mmax:
                    kvec = self.items[k].getRvec()
                    for l in range(k+1, self.nitems):
                        if len(mnbr[l]) < mmax:
                            dv = pbc(kvec - self.items[l].getRvec(), box)
                            if dv[0]*dv[0]+dv[1]*dv[1]+dv[2]*dv[2] < dmax2:
                                mnbr[k].append(l)
                                mnbr[l].append(k)
            secs = time.time() - ltime
            esec = secs * float(norg-1) / float(k + 1)

            logger.info(f"{k + 1} / {norg-1} = {100.0 * float(k+1) / float(norg-1):.3f} "
                        f"% done in {sec2hms(secs)} -> total time: {sec2hms(esec)}")

        nnbrs = [len(nbr) for nbr in mnbr]
        # nnbrs0 = [len(nbr) for nbr in mnbr if len(nbr)==0]
        minnbs = min(nnbrs)
        maxnbs = max(nnbrs)
        if verbose:
            counts = []
            for nc in range(minnbs, maxnbs+1):
                num = nnbrs.count(nc)
                if num > 0:
                    counts.append((nc,num))
                    logger.debug(f"min = {minnbs} ({nnbrs.count(minnbs)}), "
                                 f"max = {maxnbs} ({nnbrs.count(maxnbs)}), "
                                 f"avr = {np.sum(nnbrs) / len(mnbr)}; "
                                 f"dmax = {dmax}, nmax = {nmax}"
                                 f"{NL_INDENT}counts = {counts}")
        else:
            logger.info(f"min = {minnbs} ({nnbrs.count(minnbs)}), "
                        f"max = {maxnbs} ({nnbrs.count(maxnbs)}), "
                        f"avr = {np.sum(nnbrs) / len(mnbr)}; "
                        f"dmax = {dmax}, nmax = {nmax}")
        self.neibours = mnbr
        return mnbr  
        # list of neighbour-lists for each molecule in self (MoleluleSet)
    # end of findNeighbours()

    @timing
    def findClusters(self, box: Vec3 | None = None):
        """
        Find clusters of molecules based on their neighbour-lists.

        Parameters
        ----------
        box : Vec3
            Simulation box dimensions.

        Returns
        -------
        list
            List of clusters.
        """
        # from sys import setrecursionlimit
        if self.nitems > sys.getrecursionlimit():
            sys.setrecursionlimit(self.nitems)

        clusters = []
        mnbr = self.neibours
        for n in range(self.nitems):
            is_skip = False
            for clust in clusters:
                mlst = n
                if mlst in clust:
                    is_skip = True
                    break
            if not is_skip:
                clusters.append([n])
                logger.debug(
                    f"Found 'loose' molecule {n} => starting a new "
                    f"cluster {len(clusters)} ..."
                )
                count = 0
                self._extendCluster(clusters[-1], mnbr, n, count)

        nclust = [len(ncls) for ncls in clusters]
        mincls = min(nclust)
        maxcls = max(nclust)
        idxmax = nclust.index(maxcls)
        counts = []
        for nc in range(mincls, maxcls+1):
            numcls = nclust.count(nc)
            if numcls > 0:
                counts.append((nc,numcls))
        self.clustnum = counts
        logger.info(f"Found {len(clusters)} clusters of sizes:{NL_INDENT}"
                    f"counts = {counts} ->{NL_INDENT}"
                    f"{nclust} => {np.sum(nclust)} =?= {self.nitems} molecules in total")
        maxids = []
        nummax = nclust.count(maxcls)
        mc = 0
        for nc in range(nummax):
            maxids.append(nclust.index(maxcls, mc))
            mc = maxids[-1]+1

        #logger.debug(f"self = {self}")

        # reconstruct clusters and apply PBC to COMs
        # molnames = set([ mol.name for mol in self.items ])
        msetClust = []
        for ic, clust in enumerate(clusters):
            molc0 = self.items[clust[0]]
            rvec0 = molc0.getRvec().copy()
            rvec1 = molc0.getRvec().copy()
            msetClust.append(MoleculeSet(sname="Cluster_" + str(ic)  + "_" + molc0.name))
            msetClust[-1].addItem(molc0)
            # msetClust.append([molc0])
            ipassed = [0]
            for i in range(1, len(clust)):
                k = clust[i - 1]
                cnt = clust[i]
                if cnt not in self.neibours[k]:
                    for k in self.neibours[cnt]:
                        if k in ipassed:
                            break
                ipassed.append(cnt)
                rveck = self.items[k].getRvec().copy()
                molcl = self.items[cnt]
                rvecl = molcl.getRvec().copy()
                rvec0 = rvec0 + rvecl
                dvecl = pbc(rvecl - rveck, box)
                rvecl = rveck + dvecl
                molcl.setRvecAt(rvecl)
                rvec1 = rvec1 + rvecl
                msetClust[-1].addItem(molcl)
                # msetClust[-1].append(molcl)
            flcls = float(len(clust))
            rvec0 = rvec0 / flcls
            rvec1 = rvec1 / flcls
            rvec2 = pbc(rvec1.copy(), box)
            dvec = rvec2 - rvec1
            if abs(dvec[0]) + abs(dvec[1]) + abs(dvec[2]) > TINY:
                logger.info(
                    f"Now applying PBC to cluster {ic} @ {rvec0} -> {rvec1}"
                    f" -> {rvec2} of {int(flcls)} molecules ..."
                )
                for im, mol in enumerate(msetClust[-1]):
                    mol.moveBy(dvec)
                    # logger.debug(f"mol {im} ({mol.indx}) moved by {dvec} -> {mol.getRvec()}")
        # self.getRvecs(True)
        # logger.debug(f"self = {self}")

        # clsmax = clusters[idxmax]
        # logger.info(f"Largest cluster is # {idxmax} of size {maxcls} "
        #             f"molecules: {clsmax}")

        self.maxcluster = None

        if len(clusters) < 1:
            logger.warning(f"No clusters found: {len(clusters)} -"
                            " try to increase dmax value!")
            return clusters

        maxclist = []
        for idx in maxids:
            maxclist.append(msetClust[idx])
            clsmax = clusters[idx]
            logger.info(f"Largest cluster # {idx} of size {maxcls} : "
                        f"molecules: {clsmax}")

        self.maxcluster = maxclist

        # AB: output for debugging:
        # from shapes.ioports import ioframe
        # cell = ioframe.CellParameters()
        # cell.dims_from_vec(box)
        # cell.angs_from_vec(Vec3(90.,90.,90.))
        #
        # out_data = dict()
        # out_data.update({"header": 
        #                  f"Largest clusters of size {maxcls} "
        #                  f"from molset '{msetClust[idxmax][0].name}'"})
        # # out_data.update({"molsout": [msetClust[idxmax]]})
        # out_data.update({"molsout": maxclist})
        # out_data.update({"simcell": cell})
        # out_data.update({"lscale": 1.0})
        # # out_data.update({"lscale": 10.0})
        #
        # from shapes.ioports import iogro, iopdb
        # writer = iogro.groFile("largest_cluster.gro", "w")
        # # writer = iopdb.pdbFile("largest_cluster.pdb", "w")
        # writer.writeOutMols(out_data)

        return clusters
    # end of findClusters()

    def _extendCluster(self, cluster: list, mnbrs: list, cnt: int, count: int):
        """
        Recursively extend a cluster.

        Parameters
        ----------
        cluster : list
            Current cluster list.
        mnbrs : list
            Neighbour-lists.
        cnt : int
            The index of molecule in focus.
        count : int
            Recursion count.

        Returns
        -------
        None
        """
        count += 1
        if count > self.nitems - 1:
            return
        # logger.warning(f"recursion count reached its max - miscounting possible!")
        # return  # avoid recursion overflow (beware of possible miscounting of clusters!)
        for n in mnbrs[cnt]:
            if n not in cluster:
                cluster.append(n)
                self._extendCluster(cluster, mnbrs, n, count)

    # end of extendCluster()

    @timing
    def updateRvecs(self, **kwargs) -> None:
        """
        Update COM and COG vectors for the molecule set.

        Parameters
        ----------
        **kwargs
            Additional arguments for PBC handling.

        Returns
        -------
        None
        """
        # class_method = f"{self.updateRvecs.__qualname__}"
        #
        if self.rvec is not None:
            del self.rvec
        if self.rcog is not None:
            del self.rcog
        self.mass = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            self.rvec = Vec3()
            self.rcog = Vec3()
            box = None
            is_MolPBC = False
            is_MolSetPBC = False
            if "box" in kwargs.keys():
                # AB: check if PBC to be applied to molecules or the molecule set
                box = kwargs['box']
                if 'isMolPBC' in kwargs.keys():
                    is_MolPBC = kwargs['isMolPBC']
                is_MolSetPBC = (box is not None and not is_MolPBC)
                # logger.debug(f"Check: box = {box} & isMolPBC = {is_MolPBC} "
                #       f"=> isMolSetPBC = {is_MolSetPBC}")
            #
            # AB: if box is not None: undoing PBC for molecules (making them whole again)
            # AB: if isMolPBC: applying PBC to molecule COM's (upon making each molecule whole)
            for mol in self.items:
                mol.updateRvecs(box=box, isMolPBC=is_MolPBC)
            #
            if is_MolSetPBC:  # AB: applying PBC to the molecular set
                logger.info(f"Applying PBC to molecules in set '{self.name}': "
                            f"box = {box} & isMolSetPBC = {is_MolSetPBC} & "
                            f"isMolPBC = {is_MolPBC}")
                #
                dmax = 1.25
                if "dmax" in kwargs.keys():
                    dmax = kwargs["dmax"]
                #
                mmax = 8
                if 'nmax' in kwargs.keys():
                    mmax = kwargs['nmax']
                #
                # self.neibours = self.findNeighbours(box, dmax=dmax, nmax=mmax)
                # self.findNeighboursSSD(box, dmax=dmax, nmax=mmax)
                self.findNeighboursKDT(box, dmax=dmax, nmax=mmax)
                self.clusters = self.findClusters(box)
                #
                self.mass = 0.0
                self.rvec = Vec3()
                for mol in self.items:
                    self.mass += mol.mass
                    self.rvec += mol.rvec * mol.mass
                    self.rcog += mol.rcog
                self.rvec /= self.mass
                self.rcog /= self.nitems
            else:  # AB: possibly applying PBC to molecules (depending on kwargs)
                if box is not None:
                    logger.info(f"Undoing PBC for molecules in set '{self.name}': "
                                f"box = {box} & isMolSetPBC = {is_MolSetPBC} & "
                                f"isMolPBC = {is_MolPBC}")
                else:
                    logger.info(f"Skipping 'undo PBC' for molecules in set "
                                f"'{self.name}': box = {box} & isMolSetPBC = "
                                f"{is_MolSetPBC} & isMolPBC = {is_MolPBC}")
                self.mass = 0.0
                self.rvec = Vec3()
                for mol in self.items:
                    # mol.updateRvecs(**kwargs)
                    self.mass += mol.mass
                    self.rvec += mol.rvec * mol.mass
                    self.rcog += mol.rcog
                self.rvec /= self.mass
                self.rcog /= self.nitems

    # end of updateRvecs()

    def getRvecs(self, isupdate: bool = False, **kwargs) -> tuple[Vec3, Vec3]:
        """
        Get COM and COG vectors, optionally updated first.

        Parameters
        ----------
        isupdate : bool, optional
            Flag to update vectors before returning. 
            Default is ``False``.
        **kwargs
            Passed to updateRvecs if ``isupdate = True``.

        Returns
        -------
        tuple[Vec3, Vec3]
            Tuple of COM and COG vectors.
        """
        if isupdate:
            self.updateRvecs(**kwargs)
        return self.rvec, self.rcog

    # end of getRvecs()

    def moveBy(self, dvec: Vec3 = Vec3(), verbose: bool = False) -> None:
        """
        Move all molecules in the molecule set 
        by a displacement vector.

        Parameters
        ----------
        dvec : Vec3, optional
            Displacement vector. 
            Default is ``Vec3(0.,0.,0.)``.
        verbose : bool, optional
            Flag to log debug info. 
            Default is ``False``.

        Returns
        -------
        None
        """
        if isinstance(dvec, Vec3):
            self.nitems = len(self.items)
            if self.nitems > 0:
                for mol in self.items:
                    mol.moveBy(dvec)
                self.rvec += dvec
                self.rcog += dvec
        elif verbose:
            logger.info(
                f"Input {dvec} does not qualify "
                "as Vec3(float, float, float) - skipped (no change)!"
            )

    # end of moveBy()


# end of class MoleculeSet
