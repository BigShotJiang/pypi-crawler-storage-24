"""This module defines the core asset management system for handling various types
of assets such as solvents, ions, components, and their collections. It provides a
base class for assets and collections, along with specific implementations for
different asset types.

Classes
-------
BaseAsset
    A base class for managing assets with file paths, metadata, and serialization capabilities.
Solvent
    A subclass of BaseAsset representing a solvent.
Ion
    A subclass of BaseAsset representing an ion.
Component
    A subclass of BaseAsset representing a component with additional attributes like
    number of atoms, counter ions, and file paths for structure and topology.
Lipid
    A subclass of Component representing a lipid.
Surfactant
    A subclass of Component representing a surfactant.
BaseAssetCollection
    A base class for managing collections of assets.
Components
    A collection class for managing Component objects.
Ions
    A collection class for managing Ion objects.
"""


import logging
from pathlib import Path
from typing import Any, TypeVar

import nglview

from shapes.basics.defaults import STRUCTURE_EXTENSIONS
from shapes.project.core.base_collection import BaseCollection
from shapes.project.core.base_item import BaseItem
from shapes.project.files import AppFileManager, BaseFileManager

logger = logging.getLogger("__main__")


_BaseAsset = TypeVar("_BaseAsset", bound="BaseAsset")


class BaseAsset(BaseItem):
    """Base class for managing assets with file management capabilities.

    This class provides functionality for managing assets, including loading,
    saving, exporting, and managing file paths. It integrates with a file
    manager to handle file operations and supports hierarchical asset
    relationships.

    Attributes
    ----------
    paths : list[str | Path]
        A list of file paths associated with the asset.
    name : str
        The name of the asset.

    Methods
    -------
    load(name: str)
        Class method to load an asset by name from the library.
    save()
        Raises a NotImplementedError.
    change_manager(manager: BaseFileManager)
        Changes the file manager for the asset and its nested assets.
    export(export_path)
        Exports the asset to the specified path.
    """
    def __init__(
        self,
        paths: list[str | Path] | tuple[str | Path, ...] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the object with optional paths and additional keyword
        arguments.

        Parameters
        ----------
        paths : list[str | Path] or tuple[str | Path, ...], optional
            A list or tuple of file paths to be associated with the object. Defaults to None.
        **kwargs : Any
            Additional keyword arguments passed to the parent class initializer.
        """
        super().__init__(**kwargs)

        self._manager = AppFileManager()
        self._manager.prepare_path(self.__class__.__name__, self.name)

        if paths is not None:
            self.paths = [item for item in paths]

    def __str__(self) -> str:
        """Generate a string representation of the object.

        This method constructs a string that includes the class name, the object's
        name, and its attributes. Attributes that are instances of `BaseCollection`
        are included directly, while other attributes are displayed as key-value pairs.

        Returns
        -------
        str
            A string representation of the object, including its name and attributes.
        """
        attrs = {key: getattr(self, key) for key in self._attr_param_map}
        attrs = [
            attr_value 
            if isinstance(attr_value, BaseCollection) 
            else f"{attr_name}: {attr_value}"
            for attr_name, attr_value 
            in attrs.items()
        ]
        attrs = "\n- ".join(map(str, attrs))
        attrs_msg = f" with\n- {attrs}" if attrs else ""
        return f"{self.__class__.__name__}({self.name}){attrs_msg}"

    def __setattr__(self, name: str, value: Any) -> None:
        """Overrides the default behavior of setting an attribute on the object.

        The method ensures that the value's manager is updated to the current object's manager.

        Parameters
        ----------
        name : str
            The name of the attribute to set.
        value : Any
            The value to assign to the attribute.
        """
        if (
            name != "_manager"
            and hasattr(self, "_manager")
            and (isinstance(value, (BaseAsset, BaseAssetCollection)))
        ):
            value.change_manager(self._manager)
        return object.__setattr__(self, name, value)

    @classmethod
    def load(cls: type[_BaseAsset], name: str) -> _BaseAsset:
        """Load an asset by its name and initialize an instance with the asset's
        metadata.

        Parameters
        ----------
        name : str
            The name of the asset to load.

        Returns
        -------
        Self
            An instance of the class initialized with the loaded asset's metadata.
        """
        item_metadata = AppFileManager().load_asset_from_lib(cls.__name__, name)
        return cls(**item_metadata)

    def save(self):
        raise NotImplementedError("The object has to be serializable to implement .save")

    def change_manager(self, manager: BaseFileManager) -> None:
        """Updates the file manager for the current asset and its attribute
        assets.

        This method changes the file manager used by the current asset and ensures
        that all associated assets (if any) also update their file manager. It moves
        the asset's data from the old manager to the new one.

        Parameters
        ----------
        manager : BaseFileManager
            The new file manager to be used.
        """
        if self._manager is manager:
            return
        old_paths = self._manager.locate(self.__class__.__name__, self.name)
        self._manager = manager
        manager.move_from_custom(self.__class__.__name__, self.name, old_paths)
        for attr_name in self._attr_param_map:
            value = getattr(self, attr_name)
            if isinstance(value, (BaseAsset, BaseAssetCollection)):
                value.change_manager(self._manager)

    @property
    def paths(self) -> tuple[Path, ...]:
        """Retrieve the file paths associated with the current class and instance
        name.

        Returns
        -------
        str
            The located file path as determined by the manager, based on the class name
            and the instance name.
        """
        return self._manager.locate(self.__class__.__name__, self.name)

    @paths.setter
    def paths(self, value: list[str | Path]) -> None:
        """Sets the paths for the current Asset.

        Parameters
        ----------
        value : list of str or Path
            A list of paths, where each path is either a string or a Path object.

        Returns
        -------
        None
        """
        self._manager.copy_from_custom(self.__class__.__name__, self.name, value)

    def export(self, export_path: Path | str) -> None:
        """Export the asset to a specified file path.

        Parameters
        ----------
        export_path : str
            The destination dir path where the asset will be exported to.

        Raises
        ------
        Exception
            If the export operation fails or the export path is invalid.
        """
        self._manager.export(self.__class__.__name__, self.name, export_path)

    @property
    def name(self) -> str:
        """Get the name of the asset.

        Returns
        -------
        str
            The name of the asset.
        """
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """Updates the name of the current object and moves associated assets to
        the new name's location.

        Parameters
        ----------
        value : str
            The new name to assign to the object.
        """
        old_paths = self._manager.locate(self.__class__.__name__, self.name)
        self._manager.move_from_custom(self.__class__.__name__, value, old_paths)
        self._name = value


class Solvent(BaseAsset): ...
"""Solvent asset class.

This class represents a solvent asset, inheriting from the BaseAsset class. It
does not add any additional attributes or methods, but serves as a specific type
of asset that can be used within the asset management system. The Solvent class
can be instantiated and managed like any other asset, with the ability to load,
save, export, and manage file paths through the inherited functionality from
BaseAsset.
"""


class Ion(BaseAsset): ...
"""Ion asset class.

This class represents an ion asset, inheriting from the BaseAsset class. It does
not add any additional attributes or methods, but serves as a specific type of
asset that can be used within the asset management system. The Ion class can be
instantiated and managed like any other asset, with the ability to load, save,
export, and manage file paths through the inherited functionality from BaseAsset.
"""

class Component(BaseAsset):
    """Represents a component with associated structural and topological data.

    Parameters
    ----------
    number_of_atoms : int, optional
        The number of atoms in the component. Default is 0.
    counter_ion : Ion or str or None, optional
        The counter ion associated with the component. Can be an `Ion` object,
        a string representing the ion, or None. If a string is provided, it will
        be loaded as an `Ion` object. Default is None.
    mint : int, optional
        Minimum value for some property (specific context not provided). Default is 0.
    mext : int, optional
        Maximum value for some property (specific context not provided). Default is 0.
    **kwargs : Any
        Additional keyword arguments passed to the `BaseAsset` initializer.

    Attributes
    ----------
    mint : int
        Minimum value for some property.
    mext : int
        Maximum value for some property.
    number_of_atoms : int
        The number of atoms in the component.
    counter_ion : Ion or None
        The counter ion associated with the component.
    structure_file_path : pathlib.Path or None
        The path to the structure file, if available. Returns None if no structure
        file is found.
    topology_file_path : pathlib.Path or None
        The path to the topology file (with `.itp` extension), if available. Returns
        None if no topology file is found.

    Methods
    -------
    show()
        Displays the structure of the component using NGLView if a structure file
        is available. Supports Jupyter Notebook environments. Logs a warning if
        no structure file is found.
    """
    def __init__(
        self,
        number_of_atoms: int = 0,
        counter_ion: Ion | str | None = None,
        mint: int = 0,
        mext: int = 0,
        **kwargs: Any,
    ) -> None:
        """Initialize the object with specified parameters.

        Parameters
        ----------
        number_of_atoms : int, optional
            The number of atoms, by default 0.
        counter_ion : Ion, str, or None, optional
            The counter ion, which can be an Ion object, a string representing
            the ion, or None. If a string is provided, it will be loaded as an Ion
            object from library. By default, None.
        mint : int, optional
            The minimum integer value, by default 0.
        mext : int, optional
            The maximum integer value, by default 0.
        **kwargs : Any
            Additional keyword arguments passed to the superclass initializer.
        """
        super().__init__(**kwargs)
        self.mint: int = mint
        self.mext: int = mext
        self.number_of_atoms: int = number_of_atoms
        if isinstance(counter_ion, str):
            self.counter_ion = Ion.load(counter_ion)
        else:
            self.counter_ion: Ion | None = counter_ion

    @property
    def structure_file_path(self) -> Path | None:
        """The object's first file path with a suffix matching the allowed
        structure extensions.

        Returns
        -------
        Path or None
            The first file path with a suffix in `STRUCTURE_EXTENSIONS`, or None if no such path
            exists.
        """
        for path in self.paths:
            if path.suffix in STRUCTURE_EXTENSIONS:
                return path
        return None

    @property
    def topology_file_path(self) -> Path | None:
        """Retrieve the first file path with an ".itp" suffix from the list of
        paths.

        Returns
        -------
        Path or None
            The first file path with an ".itp" suffix if found, otherwise None.
        """
        for path in self.paths:
            if path.suffix == ".itp":
                return path
        return None

    def show(self) -> nglview.NGLWidget | None:
        """Display the molecular structure using NGLView.

        This method visualizes the molecular structure file specified by
        `self.structure_file_path` using NGLView. It supports rendering
        within Jupyter notebooks (ZMQInteractiveShell). If the method is
        called in an unsupported environment, a warning or exception is raised.

        Returns
        -------
        nglview.NGLWidget or None
            The NGLView widget displaying the molecular structure if successful,
            or None if `self.structure_file_path` is not set or an error occurs.

        Raises
        ------
        NotImplementedError
            If the method is called in a terminal interactive shell or an
            unsupported environment.
        NameError
            If the `get_ipython` function is not available in the current context.

        Notes
        -----
        - The method clears any existing representations in the NGLView widget
          and adds a "ball+stick" representation with a specified radius.
        - This method is designed to work in Jupyter notebook environments.
        """
        if self.structure_file_path is None:
            logger.warning("Nothing to show")
            return None
        try:
            shell = get_ipython().__class__.__name__
            if shell == "ZMQInteractiveShell":
                view = nglview.show_structure_file(str(self.structure_file_path))
                view.clear_representations()
                view.add_representation("ball+stick", selection=self.name, radius=0.25)
                return view
            elif shell == "TerminalInteractiveShell":
                raise NotImplementedError
            else:
                raise NotImplementedError
        except NameError:
            return None


class Lipid(Component): ...
"""Lipid class representing a specific type of component.

This class is used to model lipids within the system. This class is used when
loading lipids from the library, allowing for specialized handling of lipid-
related data and functionality.
"""


class Surfactant(Component): ...
"""Surfactant class representing a specific type of component.

This class is used to model surfactants within the system. This class is used when
loading surfactants from the library, allowing for specialized handling of
surfactant- related data and functionality.
"""


class BaseAssetCollection(BaseCollection[_BaseAsset]):
    """A collection class for managing `_BaseAsset` objects with an associated
    file manager.

    This class extends `BaseCollection` and provides additional functionality to manage
    `_BaseAsset` objects, ensuring that each asset is associated with a file manager.

    Parameters
    ----------
    **kwargs : dict
        Additional keyword arguments passed to the parent `BaseCollection` initializer.

    Methods
    -------
    append(value)
        Appends an item to the collection and updates its file manager.
    insert(idx, value)
        Inserts an item at the specified index and updates its file manager.
    change_manager(manager)
        Changes the file manager for the collection and updates all items in the collection.

    Attributes
    ----------
    _manager : AppFileManager or None
        The file manager associated with the collection. Defaults to an instance of
        `AppFileManager`.
    """
    def __init__(self, **kwargs: Any) -> None:
        """Initializes the instance and sets up the application file manager.

        Parameters
        ----------
        **kwargs : dict
            Arbitrary keyword arguments passed to the parent class initializer.
        """
        super().__init__(**kwargs)
        self._manager = AppFileManager()

    def __setitem__(self, idx: int | str, value: _BaseAsset) -> None:
        """Sets an item in the collection at the specified index and updates its
        manager.

        Parameters
        ----------
        idx : int or str
            The index or key at which the asset should be set.
        value : _BaseAsset
            The asset to be added to the collection.
        """
        super().__setitem__(idx, value)
        if self._manager is not None:
            value.change_manager(self._manager)

    def append(self, value: _BaseAsset) -> None:
        """Appends a new asset to the collection and updates its manager if
        applicable.

        Parameters
        ----------
        value : _BaseAsset
            The asset to be appended to the collection.
        """
        super().append(value)
        if self._manager is not None:
            value.change_manager(self._manager)

    def insert(self, idx: int, value: _BaseAsset) -> None:
        """Inserts a value into the list at the specified index and updates its
        manager.

        Parameters
        ----------
        idx : int
            The index at which the value should be inserted.
        value : _BaseAsset
            The asset to be inserted. It must be an instance of `_BaseAsset`.
        """
        super().insert(idx, value)
        if self._manager is not None:
            value.change_manager(self._manager)

    def change_manager(self, manager: BaseFileManager) -> None:
        """Updates the file manager for the current object and propagates the
        change to all associated items.

        Parameters
        ----------
        manager : BaseFileManager
            The new file manager instance to be assigned.
        """
        self._manager = manager
        for item in self._items:
            item.change_manager(manager)


class Components(BaseAssetCollection[Component]):
    """A collection of `Component` objects, inheriting from `BaseAssetCollection`.

    This class provides functionality to manage a collection of unique `Component`
    objects.

    Parameters
    ----------
    **kwargs : dict
        Additional keyword arguments passed to the parent class initializer.
        The `uniques` keyword argument determines whether the collection
        enforces unique elements. Defaults to `True`.
    """
    def __init__(self, **kwargs: Any) -> None:
        """Initializes the object with the given keyword arguments.

        Parameters
        ----------
        **kwargs : dict
            Arbitrary keyword arguments. The "uniques" key is optional and
            defaults to True. All other keyword arguments are passed to the
            superclass initializer.
        """
        uniques = kwargs.pop("uniques", True)
        super().__init__(uniques=uniques, **kwargs)


class Ions(BaseAssetCollection[Ion]):
    """A collection of Ion objects with additional configuration options.

    Parameters
    ----------
    amount_of_pairs : int, optional
        The number of ion pairs to initialize in the collection. Default is 0.
    match_structure_components : bool, optional
        If True, ensures that the amount matches the structure components. Default is False.
    **kwargs : dict
        Additional keyword arguments passed to the parent class initializer.
        Includes `uniques` which defaults to True.

    Attributes
    ----------
    amount_of_pairs : int
        The number of ion pairs in the collection.
    match_structure_components : bool
        Indicates whether the structure components of the ions should match.
    """
    def __init__(
            self, 
            amount_of_pairs: int = 0,
            match_structure_components: bool = False,
            **kwargs: Any,
        ) -> None:
        """Initialize the object with the specified parameters.

        Parameters
        ----------
        amount_of_pairs : int, optional
            The number of pairs to be handled by the object. Default is 0.
        match_structure_components : bool, optional
            Whether to match structure components. Default is False.
        **kwargs : Any
            Additional keyword arguments passed to the superclass initializer. Includes `uniques`
            to indicate whether unique elements should be used. Default is True.
        """
        uniques = kwargs.pop("uniques", True)
        super().__init__(uniques=uniques, **kwargs)
        self.amount_of_pairs: int = amount_of_pairs
        self.match_structure_components: bool = match_structure_components