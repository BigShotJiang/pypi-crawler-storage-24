"""This module defines the BaseItem class, which serves as a foundational class
for all items in the project package.

It provides common functionality such as serialization, deserialization, hashing,
and equality comparison.
"""

import logging
import uuid
import warnings
from enum import Enum
from pathlib import Path
from typing import Any, Literal, TypeAlias, TypeVar

logger = logging.getLogger("__main__")

SerializedObj: TypeAlias = dict[Literal["module", "dtype", "data", "id"], Any]
TBaseItem = TypeVar("TBaseItem", bound="BaseItem")


class BaseItem:
    """The foundational class for all items in the project package. It provides
    common functionality such as serialization, deserialization, hashing, and
    equality comparison. Each item has a unique name and can be initialized with
    optional attributes that are defined in the _attr_param_map property.

    Parameters
    ----------
    name : str, optional
        The name of the item. If not provided, a unique name will be generated automatically.
    **kwargs : Any
        Additional attributes that can be passed to the initializer. These attributes should be
        defined in the _attr_param_map property of the class. If any attributes are passed that
        are not defined in the _attr_param_map, a warning will be issued indicating that some
        attributes were not assigned.

    Attributes
    ----------
    name : str
        The name of the item. This attribute can be accessed and modified using the name property.
    _attr_param_map : dict[str, str]
        A mapping of attribute names to parameter names for serialization and display purposes.
         This property can be overridden in child classes to specify which attributes should be
         serialized and displayed in the string representation of the item. If there are private
         attributes that need to be passed to the initializer with different names, this property
         should return a dictionary that maps the attribute name of the private attribute to the
         corresponding parameter name in the initializer.

    Methods
    -------
    """
    def __init__(self, name: str | None = None, **kwargs: Any) -> None:
        """Initialize a BaseItem instance.

        If a name is not provided, a unique name will be generated automatically using the class
        name and a portion of a UUID. The initializer also accepts additional keyword arguments
        that can be used to set attributes defined in the _attr_param_map property. If any
        attributes are passed that are not defined in the _attr_param_map, a warning will be
        issued indicating that some attributes were not assigned.

        It is expected, that anything passed to parents from children classes is passed through
        **kwargs.

        Parameters
        ----------
        name : str, optional
            The name of the item. If not provided, a unique name will be generated automatically.
        **kwargs : Any
            Additional attributes that can be passed to the initializer. These attributes should be
            defined in the _attr_param_map property of the class. If any attributes are passed that
            are not defined in the _attr_param_map, a warning will be issued indicating that some
            attributes were not assigned.
        """
        
        super().__init__()
        if name is None:
            self._name = f"{self.__class__.__name__[:3]}{str(uuid.uuid4())[-12:]}"
        else:
            self._name = str(name)
        if kwargs:
            warnings.warn(
                f"While initializing {self._name} some attributes were not assigned: {kwargs}"
            )

    def __str__(self) -> str:
        """Return a string representation of the object.

        The string representation includes the class name and the object name.

        Returns
        -------
        str
            A string representation of the item in the format:
            "<ClassName>(<name>)".
        """
        return f"{self.__class__.__name__}({self.name})"

    def __repr__(self) -> str:
        """Return a string representation of the object.

        This method provides a developer-friendly string representation of the
        object, including its class name and the `names` attribute.

        Returns
        -------
        str
            A string in the format "<ClassName>(<items>)".
        """
        attrs = ", ".join(
            f"{param}={getattr(self, attr)}" 
            for attr, param 
            in self._attr_param_map.items()
        )
        return f"{type(self).__module__}.{type(self).__qualname__}({attrs})"

    def __hash__(self) -> int:
        """Hashing method override for general use."""
        hashing_info = {
            str(type(self)),
        }
        for attr_name in self._attr_param_map:
            if hasattr(self, attr_name):
                hashing_info.add(str(getattr(self, attr_name)))
        return hash(frozenset(hashing_info))

    def __eq__(self, other: Any) -> bool:
        """Equality comparison method override for general use."""
        if not isinstance(self, type(other)):
            return False

        for attr_name in self._attr_param_map:
            if not (hasattr(self, attr_name) or hasattr(other, attr_name)):
                return False

            self_attr = getattr(self, attr_name)
            other_attr = getattr(other, attr_name)
            if isinstance(self_attr, Path) or isinstance(other_attr, Path):
                continue
            elif isinstance(self_attr, dict) and isinstance(other_attr, dict):
                if len(self_attr) != len(other_attr):
                    return False
                for key in self_attr.keys():
                    if isinstance(self_attr[key], Path):
                        continue
                    if isinstance(other_attr[key], Path):
                        continue
                    if self_attr[key] != other_attr[key]:
                        return False
            elif hasattr(self_attr, "__iter__") and hasattr(other_attr, "__iter__"):
                if len(self_attr) != len(other_attr):
                    return False
                for idx in range(len(self_attr)):
                    if isinstance(self_attr[idx], Path):
                        continue
                    if isinstance(other_attr[idx], Path):
                        continue
                    if self_attr[idx] != other_attr[idx]:
                        return False
            else:
                return getattr(self, attr_name) == getattr(other, attr_name)
        return True

    @staticmethod
    def _import_class(class_name: str, module_name: str) -> type:
        """Dynamically import a class from a module.

        Parameters
        ----------
        class_name : str
            The name of the class to import.
        module_name : str
            The name of the module from which to import the class.

        Returns
        -------
        type
            The imported class.
        """
        try:
            module = __import__(module_name, globals(), locals(), [class_name], 0)
        except ImportError as e:
            raise ImportError(f"Could not import module {module_name}") from e

        if not hasattr(module, class_name):
            raise ValueError(f"Class {class_name} not found in module {module_name}.")

        return getattr(module, class_name)

    def _serialize_attr_value(self, attr_value: Any, skip_id: bool = False) -> SerializedObj:
        """Serialize an attribute value for the serialized representation of the
        object.

        This method handles the serialization of various types of attribute values, including
        instances of BaseItem, Enum, Path, lists, tuples, sets, and dictionaries. It also includes
        type information in the serialized output to facilitate deserialization.

        Parameters
        ----------
        attr_value : Any
            The attribute value to serialize.
        skip_id : bool, optional
            A flag indicating whether to skip including the unique identifier of the object in
            the serialized output. This is useful for comparisons and some tests where the unique
            identifier may cause issues, comparing serialized data of different objects.
            Default is False.

        Returns
        -------
        SerializedObj
            A dictionary containing the serialized representation of the attribute value,
            including its type information and data.
        """
        attr_type = type(attr_value).__name__
        attr_module = type(attr_value).__module__

        if isinstance(attr_value, BaseItem):
            return attr_value.to_dict(skip_id=skip_id)

        elif isinstance(attr_value, Enum):
            ser_data = attr_value.value

        elif isinstance(attr_value, Path):
            ser_data = str(attr_value)

        elif isinstance(attr_value, (list, tuple, set)):
            ser_data = [self._serialize_attr_value(item, skip_id) for item in attr_value]

        elif isinstance(attr_value, dict):
            for key in attr_value.keys():
                if not isinstance(key, (str, int, float)):
                    raise ValueError(
                        f"Can't serialize dict with atypical keys: {type(key).__name__}"
                    )
            ser_data = {
                key: self._serialize_attr_value(val, skip_id) for key, val in attr_value.items()
            }
        elif isinstance(attr_value, (str, int, float)) or attr_value is None:
            ser_data = attr_value
        else:
            raise ValueError(f"Unexpected type {type(attr_value).__name__} to serialize")

        attr_dict: SerializedObj = {"dtype": attr_type, "data": ser_data}
        if attr_module is not None:
            attr_dict["module"] = attr_module

        return attr_dict

    def to_dict(self, skip_id: bool = False) -> SerializedObj:
        """Serialize the object to a dictionary representation.

        This method constructs a dictionary representation of the object, including its type
        information and data. It iterates over the attributes defined in the _attr_param_map
        property and serializes their values using the _serialize_attr_value method. The resulting
        dictionary includes the module and class name of the object, as well as the serialized
        data for each attribute. If the skip_id flag is set to True, the unique identifier of the
        object will not be included in the serialized output, which can be useful for comparisons
        and some tests where the unique identifier may cause issues when comparing serialized data
        of different objects.

        Parameters
        ----------
        skip_id : bool, optional
            A flag indicating whether to skip including the unique identifier of the object in
            the serialized output. This is useful for comparisons and some tests where the unique
            identifier may cause issues when comparing serialized data of different objects.
            Default is False.

        Returns
        -------
        SerializedObj
            A dictionary containing the serialized representation of the object, including its type
            information and data for each attribute defined in the _attr_param_map property.
        """
        obj_data: dict[str, Any] = {}
        ser_data: SerializedObj = {
            "module": type(self).__module__,
            "dtype": type(self).__name__,
            "data": obj_data,
        }
        if not skip_id:
            ser_data["id"] = id(self)

        for attr_name, parameter in self._attr_param_map.items():
            if not hasattr(self, attr_name):
                raise KeyError(
                    f"Object '{self}' does not have the attribute '{attr_name}' "
                    "which was listed for serialization"
                )

            attr_value = getattr(self, attr_name)
            try:
                attr_dict = self._serialize_attr_value(attr_value, skip_id)
            except ValueError as ve:
                raise ValueError(f"Failed to serialize {attr_name} in {self}") from ve

            obj_data[parameter] = attr_dict

        return ser_data

    @classmethod
    def _deserialize_attr_value(
        cls, 
        attr_value: SerializedObj, 
        obj_map: dict[str, Any] | None = None
    ) -> Any:
        """Deserialize an attribute value from its serialized representation.

        This method handles the deserialization of various types of attribute values, including
        instances of BaseItem, Enum, Path, lists, tuples, sets, and dictionaries. It uses the
        type information included in the serialized representation to determine how to deserialize
        the attribute value. If the deserialization process encounters an unexpected type or data
        format, it raises a ValueError with an appropriate error message. The obj_map parameter is
        used to keep track of deserialized objects and their unique identifiers, which helps to
        handle cyclic dependencies during deserialization. If an object is encountered that has
        already been deserialized (i.e., its unique identifier is present in the obj_map),
        the method returns the existing deserialized object instead of attempting to deserialize
        it again, thus preventing infinite recursion in cases of cyclic dependencies.

        Parameters
        ----------
        attr_value : SerializedObj
            A dictionary containing the serialized representation of the attribute value,
            including its type information and data.
        obj_map : dict[str, Any], optional
            A mapping of unique identifiers to deserialized objects, used to handle cyclic
            dependencies during deserialization. If an object is encountered that has already been
            deserialized (i.e., its unique identifier is present in the obj_map), the method
            returns the existing deserialized object instead of attempting to deserialize it
            again. Default is None.

        Returns
        -------
        Any
            The deserialized attribute value, reconstructed from its serialized representation.
        """
        attr_dtype = str(attr_value["dtype"])
        if attr_dtype == "NoneType":
            return None
        attr_module = str(attr_value.get("module", "builtins"))
        attr_cls = cls._import_class(attr_dtype, attr_module)
        attr_data = attr_value["data"]

        if issubclass(attr_cls, BaseItem):
            deser_value = attr_cls.from_dict(attr_value, obj_map)

        elif issubclass(attr_cls, Enum):
            if not isinstance(attr_data, int):
                raise ValueError(f"Expected serialized int value for attr_dtype {attr_dtype}")
            deser_value = attr_cls(attr_data)

        elif issubclass(attr_cls, Path):
            if not isinstance(attr_data, str):
                raise ValueError(f"Expected serialized str value for attr_dtype {attr_dtype}")
            deser_value = attr_cls(attr_data)

        elif issubclass(attr_cls, (list, tuple, set)):
            deser_value = attr_cls(
                cls._deserialize_attr_value(item, obj_map) for item in attr_data
            )

        elif issubclass(attr_cls, dict):
            if not isinstance(attr_data, dict):
                raise ValueError(f"Expected serialized dict value for attr_dtype {attr_dtype}")
            deser_value = {
                key: cls._deserialize_attr_value(val, obj_map) for key, val in attr_data.items()
            }

        elif issubclass(attr_cls, (int, float, str)):
            if not isinstance(attr_data, (int, float, str)):
                raise ValueError(f"Expected int or float or str value for attr_dtype {attr_dtype}")
            deser_value = attr_cls(attr_data)

        else:
            raise ValueError(f"Unexpected dtype {attr_cls} for attribute {attr_value}")

        return deser_value

    @classmethod
    def from_dict(
        cls: type[TBaseItem], 
        ser_data: SerializedObj, 
        obj_map: dict[str, Any] | None = None
    ) -> TBaseItem:
        """Deserialize an object from its serialized dictionary representation.

        This method reconstructs an object from its serialized representation, which includes type
        information and data for each attribute. It first checks for the presence of a unique
        identifier in the serialized data and uses the obj_map to handle cyclic dependencies. If
        the object has already been deserialized (i.e., its unique identifier is present in the
        obj_map), it returns the existing deserialized object. Otherwise, it proceeds to import
        the class specified in the serialized data, verifies that it matches the expected class,
        and then iterates over the serialized attributes to deserialize their values using the
        _deserialize_attr_value method. Finally, it constructs a new instance of the class with
        the deserialized attributes and updates the obj_map with the new object if a unique
        identifier was provided.

        Parameters
        ----------
        ser_data : SerializedObj
            A dictionary containing the serialized representation of the object, including its
            type information and data for each attribute.
        obj_map : dict[str, Any], optional
            A mapping of unique identifiers to deserialized objects, used to handle cyclic
            dependencies during deserialization. If an object is encountered that has already
            been deserialized (i.e., its unique identifier is present in the obj_map), the method
            returns the existing deserialized object instead of attempting to deserialize it
            again. Default is None.

        Returns
        -------
        Self
            The deserialized object, reconstructed from its serialized representation.
        """

        if obj_map is None:
            obj_map = {}

        serialize_id = ser_data.get("id")
        if serialize_id is not None:
            if serialize_id in obj_map:
                deser_obj = obj_map[serialize_id]
                if deser_obj is None:
                    raise ValueError(
                        f"Found a cyclic dependency in ser_data. Object {deser_obj} "
                        f"multiple in {ser_data}"
                    )
                return deser_obj
            obj_map[serialize_id] = None

        dtype = str(ser_data["dtype"])
        module = str(ser_data.get("module", "builtins"))

        deser_cls = cls._import_class(dtype, module)
        if deser_cls != cls:
            raise ValueError(
                f"Provided data is supposed to serialize {dtype} class, but was passed"
                f" to {cls.__name__}. Pick the fitting class or use other data"
            )

        data: dict[str, SerializedObj] = ser_data["data"]
        if not isinstance(data, dict):
            raise ValueError(f"Unexpected data composition. Expected dict, got {type(data)}")

        kwargs = {}
        for attr_name, attr_value in data.items():
            kwargs[attr_name] = cls._deserialize_attr_value(attr_value, obj_map)

        deser_obj = cls(**kwargs)
        if serialize_id is not None:
            obj_map[serialize_id] = deser_obj

        return deser_obj

    @property
    def name(self) -> str:
        """Get the name of the asset.

        Returns
        -------
        str
            The name of the asset.
        """
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """Updates the name of the current object.

        Parameters
        ----------
        value : str
            The new name to assign to the object.
        """
        self._name = value

    @property
    def _attr_param_map(self) -> dict[str, str]:
        """Maps internal attribute names to their corresponding parameter names.

        Used for serialization. The attribute names (keys) are used when reading attributes for
        serialization and the parameter names (values) are used in the serialized output and sent
        as **kwargs to the initializer during deserialization. The parameter names are also used
        in the string representation of the object.

        This method provides basic functionality, including public attributes into the map
        and it can be used to modify in child classes by calling super()_attr_param_map first and
        updating the returned dictionary.

        Returns
        -------
        dict[str, str]
            A dictionary where keys are internal attribute names and values
            are their corresponding parameter names.
        """
        attrs = {}
        for attr_name in self.__dir__():
            if attr_name.startswith("_"):
                continue
            try:
                attr_value = getattr(self, attr_name)
            except NotImplementedError:
                continue
            if callable(attr_value):
                continue
            if hasattr(type(self), attr_name):
                class_attr = getattr(type(self), attr_name)
                if isinstance(class_attr, property) and class_attr.fset is None:
                    continue
            attrs[attr_name] = attr_name
        return attrs
