import logging
from typing import Any, overload

from typeguard import typechecked

from .assets import Component, Components
from .base_item import BaseItem

logger = logging.getLogger("__main__")


class Fractions(BaseItem):
    """A class that holds fraction values for components.

    Attributes
    ----------
    DEFAULT_FRACTION : float
        Used to setup fractions when no value is provided.
    _structure_components : Components
        A reference to components collection to maintain integrity between
        the two objects.
    _component_fraction_map : dict[str,float]
        A mapping between component names and their fraction values.
    """

    DEFAULT_FRACTION: float = 100.0

    @typechecked
    def __init__(self, components: Components, empty: bool = True, **kwargs) -> None:
        """Initialize the class that holds fraction values for components.

        Maybe optionally filled out with the contents of the `Components` object.

        Parameters
        ----------
        components : Components
            A collection of structure components.
        empty : bool
            A flag to create fractions empty (if True), or fill it with the contents of
            the `Components` object otherwise. By default True.
        """
        super().__init__(**kwargs)
        self._structure_components: Components = components
        self._component_fraction_map: dict[str, float] = {}
        if not empty:
            for component in components:
                self._component_fraction_map[component.name] = self.DEFAULT_FRACTION

    def __str__(self) -> str:
        """Custom casting of the object to `str`"""
        return str(self._component_fraction_map)

    def __len__(self) -> int:
        """The number of components in the object.

        Returns:
            int: The amount of components in the object.
        """
        return len(self._component_fraction_map)

    def __eq__(self, other: Any) -> bool:
        """Comparison method.

        True if both objects are `Fractions` and have matching maps.
        """
        return (
            isinstance(other, type(self))
            and self._component_fraction_map == other._component_fraction_map
        )

    def _ensure_components_alignment(self, key: Component | str) -> str:
        """Deletes component reference if it is missing in structure components.

        Parameters
        ----------
        key : Component | str
            A component object or its name.

        Returns
        -------
        str
            A component's name.
        """
        name = key.name if isinstance(key, Component) else key
        if (
            name not in self._structure_components.names
            and name in self._component_fraction_map
        ):
            del self._component_fraction_map[name]
        return name

    @typechecked
    def __getitem__(self, key: Component | str) -> float:
        """Get a fraction value of a component.

        Parameters
        ----------
        key : Component | str
            A component object or its name.

        Returns
        -------
        float
            A fraction of a component.
        """
        name = self._ensure_components_alignment(key)

        return self._component_fraction_map[name]

    @typechecked
    def __setitem__(self, key: Component | str, value: int | float) -> None:
        """Set a fraction value for a component. Int values transformed to float.

        Parameters
        ----------
        key : Component | str
            A component object or its name.
        value : int | float
            A fraction of a component.

        Raises
        ------
        ValueError
            If corresponding component is not present in structure components.
        """
        if isinstance(key, Component):
            component = key
        else:
            try:
                component = self._structure_components[key]
            except KeyError:
                raise ValueError(
                    f"Used key {key} to set a fraction, but a corresponding component "
                    f"was not found among {self._structure_components}."
                )

        self._structure_components.append(component)
        self._structure_components.add_reference(self, component.name, component)

        self._component_fraction_map[component.name] = float(value)

    @typechecked
    def __delitem__(self, key: Component | str) -> None:
        """Set a fraction value for a component.

        Parameters
        ----------
        key : Component | str
            A component object or its name.
        """
        name = self._ensure_components_alignment(key)
        logger.debug(f"Removing {name} from Fractions {self._component_fraction_map}")
        if name not in self._component_fraction_map:
            return
        del self._component_fraction_map[name]

    @overload
    def get(self, key: Component | str, default: float) -> float: ...
    @overload
    def get(self, key: Component | str) -> float | None: ...
    @typechecked
    def get(self, key: Component | str, default: float | None = None) -> float | None:
        """Get a fraction value for a component, or the default otherwise.

        Parameters
        ----------
        key : Component | str
            A component object or its name.
        default : float | None, optional
            A value to return, if a component has no fraction set, by default None.

        Returns
        -------
        float | None
            A fraction value, or the default value.
        """
        name = self._ensure_components_alignment(key)
        if name not in self._component_fraction_map:
            return default
        return self[name]

    @typechecked
    def remove(self, key: Component | str) -> None:
        """Remove a fraction.

        Parameters
        ----------
        key : Component | str
            A component object or its name.
        """
        name = self._ensure_components_alignment(key)
        if name in self._component_fraction_map:
            del self._component_fraction_map[name]
    
    @property
    def _attr_param_map(self) -> dict[str, str]:
        """Maps attribute names to parameter names for the class.

        Used for serialization.
        This method overrides the parent class's `_attr_param_map` method to
        customize the mapping of attribute names to parameter names. It adds
        a mapping for `_structure_components` to `components` and removes
        the mapping for `DEFAULT_FRACTION`.

        Returns
        -------
        dict[str, str]
            A dictionary where keys are attribute names and values are the
            corresponding parameter names.
        """
        attrs = super()._attr_param_map
        attrs["_structure_components"] = "components"
        del attrs["DEFAULT_FRACTION"]
        return attrs
    
    def as_list(self):
        """Generate a list of fractions corresponding to the structure components.

        This method creates a list of fractions based on the `self._structure_components`.
        If the sum of the fractions is zero and there are structure components, it defaults
        all fractions to `self.DEFAULT_FRACTION`.

        Returns
        -------
        list of float
            A list of fractions corresponding to the structure components. If no fractions
            are defined and there are structure components, a default fraction is used for
            each component.
        """
        frac_list = [
            self.get(component.name, 0.0)
            for component in self._structure_components
        ]

        if sum(frac_list) == 0 and len(self._structure_components) > 0:
            frac_list = [
                self.DEFAULT_FRACTION for component in self._structure_components
            ]
        return frac_list   
