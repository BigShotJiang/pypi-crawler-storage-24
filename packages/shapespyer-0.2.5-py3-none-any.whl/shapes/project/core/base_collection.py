"""This module defines the `BaseCollection` class, which is a generic collection
class for managing a collection of items that extend the `BaseItem` class. It
provides functionality for managing unique items, enforcing length limits, and
maintaining references between items.

Classes
-------
BaseCollection
    A generic collection class for managing items of type `BaseItem`.
"""

import logging
from collections import defaultdict
from typing import Any, Generic, Iterator, TypeVar

from .base_item import BaseItem

logger = logging.getLogger("__main__")

_BaseItem = TypeVar("_BaseItem", bound="BaseItem")


class BaseCollection(Generic[_BaseItem], BaseItem):
    """A generic collection class that manages a list of BaseItems.

    Can be instantiated with optional uniqueness and length constraints. It provides methods for 
    adding, removing, and accessing items by index or BaseItem's name.

    Parameters
    ----------
    uniques : bool, optional
        If True, ensures that all items in the collection have unique names. Default is False.
    length_limit : int, optional
        Maximum number of items allowed in the collection. If None, no limit is enforced. 
        Default is None.
    items : list[_BaseItem] or None, optional
        Initial list of items to populate the collection. Default is None.
    **kwargs : Any
        Additional keyword arguments passed to the parent class initializer.

    Attributes
    ----------
    _items : list[_BaseItem]
        Internal list storing the items in the collection.
    _name_map : dict[str, int]
        Mapping of item names to their indices in the collection.
    _references : defaultdict
        Tracks references to items in the collection.
    _uniques : bool
        Indicates whether the collection enforces unique item names.
    length_limit : int or None
        Maximum number of items allowed in the collection.
    names : tuple[str, ...]
        Tuple of all item names in the collection.
    _attr_param_map : dict[str, str]
        Mapping of internal attribute names to their corresponding parameter names.

    Methods
    -------
    append(value)
        Appends a new item to the collection.
    insert(idx, value)
        Inserts a new item at the specified index.
    add_reference(ref_holder, ref_key, item)
        Adds a reference to an item in the collection.
    remove(marker)
        Removes an item by its index, name, or instance.

    Examples
    --------
    >>> collection = BaseCollection(uniques=True, length_limit=3)
    >>> item1 = BaseItem(name="item1")
    >>> item2 = BaseItem(name="item2")
    >>> collection.append(item1)
    >>> collection.append(item2)
    >>> print(collection)
    BaseCollection: [
      item1
      item2
    ]
    >>> collection.append(item1)  # This will not be added due to uniqueness constraint
    >>> print(collection)
    BaseCollection: [
      item1
      item2
    ]
    >>> collection.remove("item1")
    >>> print(collection)
    BaseCollection: [
      item2
    ]
    >>> collection.insert(0, item1)
    >>> print(collection)
    BaseCollection: [
      item1
      item2
    ]
    >>> collection["item2"]
    item2
    >>> collection[0]
    item1
    """
    def __init__(
            self, 
            uniques: bool = False, 
            length_limit: int = None, 
            items: list[_BaseItem] | None = None, 
            **kwargs: Any
        ) -> None:
        """Initialize a BaseCollection instance.

        Parameters
        ----------
        uniques : bool, optional
            If True, ensures that all items in the collection are unique. Default is False.
        length_limit : int, optional
            The maximum number of items allowed in the collection. If None, no limit is enforced.
            Default is None.
        items : list[_BaseItem] or None, optional
            A list of initial items to populate the collection. If None, the collection starts
            empty. Default is None.
        **kwargs : Any
            Additional keyword arguments passed to the superclass initializer.

        Attributes
        ----------
        _items : list[_BaseItem]
            The list of items in the collection.
        _name_map : dict[str, int]
            A mapping of item names to their indices in the collection.
        _references : defaultdict[list]
            A dictionary mapping items to their associated references.
        _uniques : bool
            Indicates whether the collection enforces uniqueness of items.
        length_limit : int or None
            The maximum number of items allowed in the collection.
        """
        super().__init__(**kwargs)
        if items is None:
            self._items: list[_BaseItem] = []
        else:
            self._items = items
        self._name_map: dict[str, int] = {}
        self._references = defaultdict(list)
        self._uniques = uniques
        self.length_limit = length_limit

    def __str__(self) -> str:
        """Return a string representation of the collection.

        The string representation includes the class name and a formatted list
        of items in the collection, where each item is indented for readability.

        Returns
        -------
        str
            A string representation of the collection in the format:
            "ClassName: [\n  item1\n  item2\n  ...\n]".
        """
        items = "\n".join(map(lambda x: f"  {x}", self._items))
        items = f"[\n{items}\n]"
        return f"{self.__class__.__name__}: {items}"

    def __repr__(self) -> str:
        """Return a string representation of the object.

        This method provides a developer-friendly string representation of the
        object, including its class name and the `names` attribute.

        Returns
        -------
        str
            A string in the format "<ClassName>(<items>)".
        """
        return f"{self.__class__.__name__}({self._items})"

    def __iter__(self) -> Iterator[_BaseItem]:
        """Returns an iterator over the items in the collection.

        Returns
        -------
        Iterator[_BaseItem]
            An iterator over the `_BaseItem` objects contained in the collection.
        """
        return iter(self._items)

    def __len__(self) -> int:
        """Return the number of items in the collection.

        Returns
        -------
        int
            The number of items in the collection.
        """
        return len(self._items)

    def __getitem__(self, idx: int | str) -> _BaseItem:
        """Retrieve an item from the collection by index or name.

        Parameters
        ----------
        idx : int or str
            The index or name of the item to retrieve. If a string is provided,
            it is assumed to be the name of the item, which is mapped to its
            corresponding index.

        Returns
        -------
        _BaseItem
            The item from the collection corresponding to the given index or name.

        Raises
        ------
        KeyError
            If the provided name does not exist in the collection's name map.
        IndexError
            If the provided index is out of range.
        """
        if isinstance(idx, str):
            idx = self._name_map[idx]
        return self._items[idx]

    def _find(self, marker: str | int) -> tuple[int, str]:
        """Retrieve the index and name of an item based on the given marker.

        Parameters
        ----------
        marker : str or int
            The identifier for the item. If an integer is provided, it is treated
            as the index of the item. If a string is provided, it is treated as
            the name of the item.

        Returns
        -------
        tuple of (int, str)
            A tuple containing the index and name of the item.

        Raises
        ------
        KeyError
            If the marker is a string and the name does not exist in the collection.
        IndexError
            If the marker is an integer and the index is out of range.
        """
        if isinstance(marker, int):
            idx = marker
            name = self._items[idx].name
        elif isinstance(marker, str):
            name = marker
            idx = self._name_map[name]
        return idx, name

    def _reset_name_map(self) -> None:
        """Rebuilds the internal name-to-index mapping for the collection.

        This method iterates over the items in the collection and creates
        a new mapping (`_name_map`) where each item's name is associated
        with its index in the `_items` list. This ensures that the mapping
        remains consistent with the current state of the collection.
        """
        new_map = {}
        for idx, item in enumerate(self._items):
            new_map[item.name] = idx
        self._name_map = new_map

    def __delitem__(self, idx: int | str) -> None:
        """Remove an item from the collection by its index or name.

        This method removes the item from both `_name_map` and `_items`. It also ensures that any
        references to the removed item in `_references` are deleted from their respective holders.

        Parameters
        ----------
        idx : int or str
            The index (int) or name (str) of the item to be removed.

        Raises
        ------
        KeyError
            If the name does not exist in the `_name_map`.
        IndexError
            If the index is out of range of `_items`.
        """
        idx, name = self._find(idx)
        if name in self._name_map:
            del self._name_map[name]
        if idx < len(self._items) and idx >= 0:
            del self._items[idx]
        referenced_in = self._references[name]
        for ref_holder, ref_key in referenced_in:
            del ref_holder[ref_key]

    def __setitem__(self, idx: int | str, value: _BaseItem) -> None:
        """Sets an item in the collection at the specified index or with the
        specified name.

        Parameters
        ----------
        idx : int or str
            The index or name of the item to replace.
        value : _BaseItem
            The new item to insert into the collection.

        Raises
        ------
        KeyError
            If the specified name does not exist in the collection.
        ValueError
            If the index is invalid or out of range.
        """
        idx, name = self._find(idx)

        del self._name_map[name]

        self._items[idx] = value
        self._name_map[value.name] = idx

    def append(self, value: _BaseItem) -> None:
        """Append a new item to the collection.

        Parameters
        ----------
        value : _BaseItem
            The item to be appended to the collection.

        Raises
        ------
        IndexError
            If the collection has a length limit and the limit is exceeded.
        """
        if self.length_limit and len(self._items) >= self.length_limit:
            raise IndexError(
                f"Can't append a new item to the collection with a limit of {self.length_limit}"
            )
        if value.name in self._name_map and self._uniques:
            return
        idx = len(self._items)
        self._items.append(value)
        self._name_map[value.name] = idx

    def insert(self, idx: int, value: _BaseItem) -> None:
        """Insert an item into the collection at the specified index.

        Parameters
        ----------
        idx : int
            The index at which the item should be inserted.
        value : _BaseItem
            The item to be inserted into the collection.

        Raises
        ------
        IndexError
            If the collection has a length limit and the limit is reached.
        """
        if self.length_limit and len(self._items) >= self.length_limit:
            raise IndexError(
                f"Can't append a new item to the collection with a limit of {self.length_limit}"
            )
        self._items.insert(idx, value)
        self._reset_name_map()

    def add_reference(self, ref_holder: BaseItem, ref_key: str, item: BaseItem) -> None:
        """Adds a reference to the internal references dictionary.

        If a mapping was added as a reference to this collection, that means that when an item
        is deleted from Self, it will also be deleted from all the ref_holders that reference it.
        This functionality makes some BaseCollection subclasses the main 'holders' for items and
        determine if an item should exist in the project as a whole.

        If any other class uses this collection as a source of truth, `add_reference` should be
        used.

        Parameters
        ----------
        ref_holder : BaseItem
            The object that holds the reference.
        ref_key : str
            The key associated with the reference (usually the name).
        item : BaseItem
            The item to which the reference is being added.
        """
        self._references[item.name].append((ref_holder, ref_key))

    def remove(self, marker: int | str | BaseItem) -> None:
        """Remove an item from the collection.

        Parameters
        ----------
        marker : int, str, or BaseItem
            The identifier of the item to remove. It can be:
            - An integer representing the index of the item.
            - A string representing the name of the item.
            - A `BaseItem` instance, in which case its `name` attribute will be used.

        Raises
        ------
        KeyError
            If the specified marker does not exist in the collection.
        """
        if isinstance(marker, BaseItem):
            marker = marker.name
        del self[marker]

    @property
    def names(self) -> tuple[str, ...]:
        """Retrieve the names of all items in the collection.

        Returns
        -------
        tuple of str
            A tuple containing the names of all items in the collection.
        """
        return tuple(item.name for item in self._items)
    
    @property
    def _attr_param_map(self) -> dict[str, str]:
        """Maps internal attribute names to their corresponding parameter names.

        Used for serialization.
        This method overrides the parent class's `_attr_param_map` method to
        include additional mappings specific to this class. It adds a mapping
        for the `_items` attribute to the "items" parameter.

        Returns
        -------
        dict[str, str]
            A dictionary where keys are internal attribute names and values
            are their corresponding parameter names.
        """
        attrs = super()._attr_param_map
        attrs["_items"] = "items"
        return attrs
