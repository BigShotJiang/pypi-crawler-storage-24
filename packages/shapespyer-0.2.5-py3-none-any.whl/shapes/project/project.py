from pathlib import Path
from typing import Any

from .analysis import Analysis
from .files import ProjectFileManager
from .sample_model import SampleModel
from .core import BaseAssetCollection
from .core import BaseAsset
from .core import BaseItem

class Project(BaseItem):
    def __init__(
            self,
            title: str = "",
            description: str = "",
            sample_model: SampleModel | None = None,
            analysis: Analysis | None = None,
            path: str | Path | None = None,
            **kwargs,
        ):
        super().__init__(**kwargs)
        self.title: str = title
        self.description: str = description

        self._manager = ProjectFileManager(path)

        self.sample_model = sample_model if sample_model else SampleModel()
        self.analysis = analysis if analysis else Analysis(self.sample_model)

    def __setattr__(self, name: str, value: Any) -> None:
        if (
            name != "_manager"
            and hasattr(self, "_manager")
            and (isinstance(value, (BaseAsset, BaseAssetCollection)))
        ):
            value.change_manager(self._manager)
        return object.__setattr__(self, name, value)

    def save(self):
        raise NotImplementedError("Can't be implemented without serialization")

    def save_as(self, path: str | Path):
        raise NotImplementedError("Can't be implemented without serialization")
        self._manager.move_all(path)

    @property
    def summary(self):
        return Summary(self)

    @property
    def path(self):
        return self._manager._items_root


class Summary:
    def __init__(self, project):
        raise NotImplementedError

    def show_report(self):
        raise NotImplementedError
