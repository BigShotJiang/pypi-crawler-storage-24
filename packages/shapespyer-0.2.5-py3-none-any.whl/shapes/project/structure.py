"""Module for defining and managing molecular structure shapes.

This module provides classes for creating and assembling various molecular structure
geometries used in molecular modeling and simulation. It includes support for different
shape types such as rings, balls, vesicles, rods, bilayers, monolayers, and lattices.

Classes:
    Structure: Interface for all molecular structures with assembly capabilities.
    DiscreteStructure: Base class for all discrete structures.
    Ring: Circular ring-shaped molecular structure with angular and radial parameters.
    Ball: Spherical structure with support for layered composition.
    Vesicle: Spherical shell structure composed of multiple lamellae layers.
    Rod: Rod-shaped structure with helical parameters.
    Bilayer: Two-dimensional bilayer membrane structure.
    Monolayer: Single-layer membrane structure.
    Lattice: Periodic arrangement of structures in a lattice configuration.
    StructureFactory: Factory class for creating structure instances by type.
"""

import logging
from abc import abstractmethod
from pathlib import Path
from typing import Any

import nglview

from shapes.basics.defaults import Defaults, Fill
from shapes.basics.options import InputOptions, Options, ShapeType
from shapes.basics.utils import Generator
from shapes.project.core import BaseAsset, Components
from shapes.project.layers import Fractions, Lamellae, Layers

logger = logging.getLogger("__main__")


class Structure(BaseAsset):
    """Represents a structural asset within the project.

    This abstract base class provides the interface and basic initialization
    for structural assets, requiring subclasses to implement the `assemble` method.
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the object with a name and a list of paths.

        Parameters
        ----------
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)
        self._options = Options()

    @abstractmethod
    def assemble(self) -> None:
        """This method should be implemented to define how the structure's
        attributes are built from the configuration options.

        Raises
        ------
        NotImplementedError
            If the method is not implemented in a subclass.
        """

    @property
    def path(self) -> Path | None:
        """Retrieve the file path associated with this object.

        This method searches through the collection of paths related to the structure
        to find a match based on the structure name. A path is considered a match if its
        stem (filename without extension) contains the object's name as a substring.

        Returns
        -------
        Path | None
            The first Path object whose stem matches the name criteria, or None if
            no matching path is found.

        Examples
        --------
        >>> struct.path
        PosixPath('/home/ales/shapespyer/shapes/project/myfile.gro')
        >>> struct.path
        None
        """
        for item in self.paths:
            if item.stem == self.name or self.name in item.stem:
                return item
        return None

    def show(self) -> nglview.NGLWidget | None:
        """Display the structure file in an interactive viewer.

        This method attempts to visualize the molecular structure file using nglview
        in Jupyter notebook environments. It detects the IPython shell type and
        provides appropriate visualization or error handling.

        Returns
        -------
        view : nglview.NGLWidget | None
            Returns the nglview interactive widget if successfully displayed in a
            Jupyter notebook (ZMQInteractiveShell). Returns None if called outside
            of an IPython environment or if the path is not set or if nglview is not
            installed.

        Raises
        ------
        NotImplementedError
            If called from a terminal IPython shell (TerminalInteractiveShell) or
            any other shell type that is not supported.

        Notes
        -----
        This method requires nglview to be installed. If not available, install
        shapespyer with extras.
        The method is primarily designed for interactive use in Jupyter notebooks.
        Terminal-based IPython shells and other environments are not currently supported.

        Examples
        --------
        >>> structure = Structure(paths=["struct.pdb"])
        >>> structure.show()  # Display in Jupyter notebook
        """
        if self.path is None:
            logger.warning("Nothing to show")
            return None
        try:
            shell = get_ipython().__class__.__name__
            if shell == "ZMQInteractiveShell":
                view = nglview.show_structure_file(str(self.path))
                view.clear_representations()
                view.add_representation("ball+stick", radius=0.25)
                return view
            if shell == "TerminalInteractiveShell":
                raise NotImplementedError
            raise NotImplementedError
        except NameError:
            return None


class DiscreteStructure(Structure):
    """A Discrete Structure parent for managing molecular components and their
    assembly.

    This class extends BaseAsset to handle the organization, configuration, and
    assembly of molecular components into a complete discrete structure. It manages
    component properties, generates assembly options, and provides visualization
    capabilities.

    Notes
    -----
    The show() method supports interactive visualization in Jupyter notebooks
    using nglview. It requires the Shapespyer extras installation.
    """

    def __init__(
        self,
        components: Components | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a Discrete Structure instance.

        Initializes parent class with name and paths parameters. Creates an empty
        Options instance for structure configuration and an empty Components collection
        that is populated with valid Component instances from the provided arguments.
        Only Component instances are added; other types are ignored.

        Parameters
        ----------
        components : Components | None, default=None, optional
            Component container to be added to the structure.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.

        Raises
        ------
        TypeError
            if components argument is not instance of `Components`
        """
        super().__init__(**kwargs)

        if components is not None:
            if isinstance(components, Components):
                self.components = components
            else:
                error_msg = f"Got an unexpected type {type(components).__name__} as Components."
                raise TypeError(error_msg)
        else:
            self.components = Components()

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format.

        This method prepares and configures output and molecule-related options
        by extracting data from the current structure and its components.
        Sets the following options:
        - output.path: Directory path for output based on class name and structure name
        - output.base: Base name for output files
        - molecule.resnames: List of residue names from all components
        - molecule.mint: Initial vector point per component (if any component's mint>0)
        - molecule.mext: Terminal vector point per component (if any component's mext>0)
        """
        self._options.output.path = str(
            self._manager.prepare_path(self.__class__.__name__, self.name)
        )
        self._options.output.base = self.name

        self._options.molecule.resnames = [component.name for component in self.components]
        mint = [component.mint for component in self.components]
        if sum(mint) > 0:
            self._options.molecule.mint = mint
        mext = [component.mext for component in self.components]
        if sum(mext) > 0:
            self._options.molecule.mext = mext

    def assemble(self) -> None:
        """Assemble the project structure by generating shapes from components.

        This method orchestrates the assembly process by converting internal options,
        initializing a generator, reading input from each component, and producing
        the final output file.

        Notes
        -----
        The method performs the following steps in sequence:
        1. Converts internal attributes to the appropriate options format
        2. Creates a Generator instance with the converted options
        3. Reads input structure files from each component
        4. Generates the shape based on the collected inputs
        5. Writes the generated output to a file
        """
        self._to_options()
        generator = Generator(self._options)

        for component in self.components:
            if not component.structure_file_path:
                error_msg = f"Component {component} does not have a valid path."
                raise ValueError(error_msg)
            input_opts = InputOptions(str(component.structure_file_path))
            generator.read_input(input_opts, (component.name,))

        generator.generate_shape()
        generator.dump_file()


class RingStructure(DiscreteStructure):
    """Ring discrete structure class."""

    def __init__(
        self,
        alpha: float = Defaults.Angle.ALPHA,
        theta: float = Defaults.Angle.THETA,
        dmin: float = Defaults.Shape.DMIN,
        rmin: float = Defaults.Shape.RMIN,
        fractions: Fractions | None = None,
        fxz: bool = Defaults.Flags.FXZ,
        rev: bool = Defaults.Flags.REV,
        **kwargs: Any,
    ) -> None:
        """Initialize a Ring object with components and configuration parameters.

        Parameters
        ----------
        alpha : float, default=Defaults.Angle.ALPHA
            Initial azimuth angle (in XY plane), for molecules on the 'equator' ring
            (0,...,360) {0.0* degrees}.
        theta : float, default=Defaults.Angle.THETA
            Initial altitude angle (w.r.t. OZ axis), for molecules on the 'equator' ring
            (0,...,180) {0.0* degrees}.
        dmin : float, default=Defaults.Shape.DMIN
            Minimum distance between 'bone' atoms in the generated structure {0.5 * nm}.
        rmin : float, default=Defaults.Shape.RMIN
            Radius of internal cavity in the centre of the generated structure {0.25* nm}
        fractions : Fractions | None, default=None, optional
            Fractions object managing component fractions.
        fxz : bool, default=Defaults.Flags.FXZ
            Use 'XZ-flattened' initial molecule orientation to minimize its 'spread' along
            Y axis.
        rev : bool, default=Defaults.Flags.REV
            Reverse 'internal' <-> 'external' atom indexing in each of the picked-up
            molecules.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)

        self.alpha: float = alpha
        self.theta: float = theta
        self.dmin: float = dmin
        self.rmin: float = rmin
        if fractions is not None:
            self.fractions = fractions
        else:
            self.fractions = Fractions(self.components, empty=False)
        self.fxz: bool = fxz
        self.rev: bool = rev

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format."""
        self._options.shape.stype = ShapeType.RING

        super()._to_options()

        self._options.angle.alpha = float(self.alpha)
        self._options.angle.theta = float(self.theta)
        self._options.shape.dmin = float(self.dmin)
        self._options.shape.rmin = float(self.rmin)
        self._options.molecule.fracs = [self.fractions.as_list()]
        self._options.flags.fxz = self.fxz
        self._options.flags.rev = self.rev


class BallStructure(DiscreteStructure):
    """A spherical discrete structure.

    Can be composed of multiple components and organized into layers.
    """

    def __init__(
        self,
        dmin: float = Defaults.Shape.DMIN,
        rmin: float = Defaults.Shape.RMIN,
        fxz: bool = Defaults.Flags.FXZ,
        rev: bool = Defaults.Flags.REV,
        fill: Fill = Defaults.Shape.FILL,
        layers: Layers | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a Ball object with components and configuration parameters.

        Parameters
        ----------
        dmin : float, default=Defaults.Shape.DMIN
            Minimum distance between 'bone' atoms in the generated structure {0.5 * nm}.
        rmin : float, default=Defaults.Shape.RMIN
            Radius of internal cavity in the centre of the generated structure {0.25* nm}.
        fxz : bool, default=Defaults.Flags.FXZ
            Use 'XZ-flattened' initial molecule orientation to minimize its 'spread' along
            Y axis.
        rev : bool, default=Defaults.Flags.REV
            Reverse 'internal' <-> 'external' atom indexing in each of the picked-up
            molecules.
        fill : Fill, default=Defaults.Shape.FILL
            Type of molecules' placement for filling in the shape {rings*/area/fibo/mesh}.
        layers : Layers | None, default=None, optional
            Container managing the concentric layers of the ball structure.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)

        self.dmin: float = dmin
        self.rmin: float = rmin
        self.fxz: bool = fxz
        self.rev: bool = rev
        self.fill = fill
        if layers is not None:
            self.layers: Layers = layers
        else:
            self.layers = Layers(self.components)
            self.layers.add(empty=False)

    @property
    def fill(self) -> Fill:
        """Type of molecules' placement for filling in the shape.

        {rings*/area/fibo/mesh}.
        """
        return self._fill

    @fill.setter
    def fill(self, value: str | Fill) -> None:
        """Set the fill property of the structure.

        Parameters
        ----------
        value : str | Fill
            The fill value to set. If a string is provided, it will be converted to
            the corresponding Fill enum member (case-insensitive).

        Examples
        --------
        >>> shape.fill("fibo")
        >>> shape.fill(Fill.FIBO)
        """
        if isinstance(value, str):
            value = Fill[value.upper()]
        self._fill = value

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format."""
        self._options.shape.stype = ShapeType.BALL

        super()._to_options()

        self._options.shape.fill = self.fill

        self._options.shape.layers.quantity = len(self.layers)
        fracs = []
        dmins = []
        rmins = []
        for layer in self.layers.as_list:
            fracs.append(layer.fractions.as_list())
            dmins.append(layer.dmin)
            rmins.append(layer.rmin)
        self._options.shape.layers.rmin_scaling = self.layers.rmin_scaling
        self._options.shape.layers.dmin_scaling = self.layers.dmin_scaling
        self._options.molecule.fracs = fracs
        if rmins and None not in rmins:
            self._options.shape.rmin = rmins
        else:
            self._options.shape.rmin = self.rmin
        if dmins and None not in dmins:
            self._options.shape.dmin = dmins
        else:
            self._options.shape.dmin = self.dmin

        self._options.flags.fxz = self.fxz
        self._options.flags.rev = self.rev


class VesicleStructure(DiscreteStructure):
    """A vesicle discrete structure.

    Can be composed of multiple components and organized into lamellae.
    """

    def __init__(
        self,
        dmin: float = Defaults.Shape.DMIN,
        rmin: float = Defaults.Shape.RMIN,
        fxz: bool = Defaults.Flags.FXZ,
        rev: bool = Defaults.Flags.REV,
        fill: Fill = Defaults.Shape.FILL,
        lamellae: Lamellae | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a Vesicle object with components and configuration
        parameters.

        Parameters
        ----------
        dmin : float, default=Defaults.Shape.DMIN
            Minimum distance between 'bone' atoms in the generated structure {0.5 * nm}.
        rmin : float, default=Defaults.Shape.RMIN
            Radius of internal cavity in the centre of the generated structure {0.25* nm}.
        fxz : bool, default=Defaults.Flags.FXZ
            Use 'XZ-flattened' initial molecule orientation to minimize its 'spread' along
            Y axis.
        rev : bool, default=Defaults.Flags.REV
            Reverse 'internal' <-> 'external' atom indexing in each of the picked-up
            molecules.
        fill : Fill, default=Defaults.Shape.FILL
            Type of molecules' placement for filling in the shape {rings*/area/fibo/mesh}.
        lamellae : Lamellae | None, default=None, optional
            Container managing the concentric lamellae of the vesicle structure, containing
            an outer and an inner leaflets.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)

        self.dmin: float = dmin
        self.rmin: float = rmin
        self.fxz: bool = fxz
        self.rev: bool = rev
        self.fill = fill
        if lamellae is not None:
            self.lamellae = lamellae
        else:
            self.lamellae = Lamellae(self.components)
            self.lamellae.add(empty=False)

    @property
    def fill(self) -> Fill:
        """Type of molecules' placement for filling in the shape
        {rings*/area/fibo/mesh}.
        """
        return self._fill

    @fill.setter
    def fill(self, value: str | Fill) -> None:
        """Set the fill property of the structure.

        Parameters
        ----------
        value : str | Fill
            The fill value to set. If a string is provided, it will be converted to
            the corresponding Fill enum member (case-insensitive).

        Examples
        --------
        >>> shape.fill("fibo")
        >>> shape.fill(Fill.FIBO)
        """
        if isinstance(value, str):
            value = Fill[value.upper()]
        self._fill = value

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format."""
        self._options.shape.stype = ShapeType.VES

        super()._to_options()

        self._options.shape.fill = self.fill

        self._options.shape.layers.quantity = len(self.lamellae) * 2
        fracs = []
        dmins = []
        rmins = []
        for leaflet in self.lamellae.as_list:
            fracs.append(leaflet.fractions.as_list())
            dmins.append(leaflet.dmin)
            rmins.append(leaflet.rmin)
        self._options.shape.layers.rmin_scaling = self.lamellae.rmin_scaling
        self._options.shape.layers.dmin_scaling = self.lamellae.dmin_scaling
        self._options.molecule.fracs = fracs
        if rmins and None not in rmins:
            self._options.shape.rmin = rmins
        else:
            self._options.shape.rmin = self.rmin
        if dmins and None not in dmins:
            self._options.shape.dmin = dmins
        else:
            self._options.shape.dmin = self.dmin

        self._options.flags.fxz = self.fxz
        self._options.flags.rev = not self.rev


class RodStructure(DiscreteStructure):
    """A rod discrete structure."""

    def __init__(
        self,
        turns: int = Defaults.Shape.TURNS,
        dmin: float = Defaults.Shape.DMIN,
        rmin: float = Defaults.Shape.RMIN,
        fractions: Fractions | None = None,
        fxz: bool = Defaults.Flags.FXZ,
        rev: bool = Defaults.Flags.REV,
        **kwargs: Any,
    ) -> None:
        """Initialize a Rod object with components and configuration parameters.

        Parameters
        ----------
        turns : int, default=Defaults.Shape.TURNS
            Number of full turns in a 'rod', i.e. stack of rings, or a band spiral
            (>0) {0*}.
        dmin : float, default=Defaults.Shape.DMIN
            Minimum distance between 'bone' atoms in the generated structure
            {0.5 * nm}.
        rmin : float, default=Defaults.Shape.RMIN
            Radius of internal cavity in the centre of the generated structure
            {0.25* nm}.
        fractions : Fractions | None, default=None, optional
            Object managing the fractional composition of components in the rod.
        fxz : bool, default=Defaults.Flags.FXZ
            Use 'XZ-flattened' initial molecule orientation to minimize its 'spread'
            along Y axis.
        rev : bool, default=Defaults.Flags.REV
            Reverse 'internal' <-> 'external' atom indexing in each of the picked-up
            molecules.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)

        self.turns: int = turns
        self.dmin: float = dmin
        self.rmin: float = rmin
        if fractions is not None:
            self.fractions: Fractions = fractions
        else:
            self.fractions = Fractions(self.components, empty=False)
        self.fxz: bool = fxz
        self.rev: bool = rev

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format."""
        self._options.shape.stype = ShapeType.ROD

        super()._to_options()

        self._options.shape.turns = int(self.turns)
        self._options.shape.dmin = float(self.dmin)
        self._options.shape.rmin = float(self.rmin)
        self._options.molecule.fracs = [self.fractions.as_list()]
        self._options.flags.fxz = self.fxz
        self._options.flags.rev = self.rev


class BilayerStructure(DiscreteStructure):
    """A bilayer discrete structure that can be composed of multiple
    components.
    """

    def __init__(
        self,
        dmin: float = Defaults.Shape.DMIN,
        zsep: float = Defaults.Membrane.ZSEP,
        nside: int = Defaults.Membrane.NSIDE,
        fractions: Fractions | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a Bilayer object with components and configuration
        parameters.

        Parameters
        ----------
        dmin : float, default=Defaults.Shape.DMIN
            Minimum distance between 'bone' atoms in the generated structure {0.5 * nm}.
        zsep : float, default=Defaults.Membrane.ZSEP
            XY distance between molecules in a bilayer.
        nside : int, default=Defaults.Membrane.NSIDE
            Number of molecules on the side of a bilayer.
        fractions : Fractions | None, default=None, optional
            Object managing the fractional composition of components in the bilayer.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)

        self.dmin: float = dmin
        self.zsep: float = zsep
        self.nside: int = nside
        if fractions is not None:
            self.fractions = fractions
        else:
            self.fractions = Fractions(self.components, empty=False)

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format."""
        self._options.shape.stype = ShapeType.BILAYER

        super()._to_options()

        self._options.shape.dmin = float(self.dmin)
        self._options.membrane.zsep = float(self.zsep)
        self._options.membrane.nside = int(self.nside)
        self._options.molecule.fracs = [self.fractions.as_list()]


class MonolayerStructure(DiscreteStructure):
    """A monolayer discrete structure that can be composed of multiple
    components.
    """

    def __init__(
        self,
        dmin: float = Defaults.Shape.DMIN,
        zsep: float = Defaults.Membrane.ZSEP,
        nside: int = Defaults.Membrane.NSIDE,
        fractions: Fractions | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a Monolayer object with components and configuration
        parameters.

        Parameters
        ----------
        dmin : float, default=Defaults.Shape.DMIN
            Minimum distance between 'bone' atoms in the generated structure {0.5 * nm}.
        zsep : float, default=Defaults.Membrane.ZSEP
            XY distance between molecules in a monolayer.
        nside : int, default=Defaults.Membrane.NSIDE
            Number of molecules on the side of a monolayer.
        fractions : Fractions | None, default=None, optional
            Object managing the fractional composition of components in the monolayer.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)

        self.dmin: float = dmin
        self.zsep: float = zsep
        self.nside: int = nside
        if fractions is not None:
            self.fractions = fractions
        else:
            self.fractions = Fractions(self.components, empty=False)

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format."""
        self._options.shape.stype = ShapeType.MONOLAYER

        super()._to_options()

        self._options.shape.dmin = float(self.dmin)
        self._options.membrane.zsep = float(self.zsep)
        self._options.membrane.nside = int(self.nside)
        self._options.molecule.fracs = [self.fractions.as_list()]


class LatticeStructure(Structure):
    """A periodic structure that can be composed of multiple discrete substructure
    nodes.
    """

    def __init__(
        self,
        alpha: float = Defaults.Angle.ALPHA,
        theta: float = Defaults.Angle.THETA,
        nlatx: int = Defaults.Lattice.NLATT[0],
        nlaty: int = Defaults.Lattice.NLATT[1],
        nlatz: int = Defaults.Lattice.NLATT[2],
        sbuff: float = Defaults.Base.SBUFF,
        lattice_type: ShapeType = ShapeType.LAT,
        substructure: DiscreteStructure | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a Lattice object with a substructure and configuration
        parameters.

        Parameters
        ----------
        alpha : float, default=Defaults.Angle.ALPHA
            Initial azimuth angle (in XY plane), for molecules on the 'equator' ring
            (0,...,360) {0.0* degrees}.
        theta : float, default=Defaults.Angle.THETA
            Initial altitude angle (w.r.t. OZ axis), for molecules on the 'equator' ring
            (0,...,180) {0.0* degrees}.
        nlatx : int, default=Defaults.Lattice.NLATT[0]
            Lattice number in X, i.e. number of nodes in X dimension on a rectangular
            3D lattice {1*}.
        nlaty : int, default=Defaults.Lattice.NLATT[1]
            Lattice number in Y, i.e. number of nodes in Y dimension on a rectangular
            3D lattice {1*}.
        nlatz : int, default=Defaults.Lattice.NLATT[2]
            Lattice number in Z, i.e. number of nodes in Z dimension on a rectangular
            3D lattice {1*}.
        sbuff : float, default=Defaults.Base.SBUFF
            Solvation buffer size around the generated structure {1.0* nm}.
        lattice_type: ShapeType, default=ShapeType.LAT
            Lattice type, the only allowed values are LAT, LAT2 and LAT3.
        substructure : DiscreteStructure | None, default=None, optional
            A discrete substructure to use as a node in the lattice.
        **kwargs : Any
            Arbitrary keyword arguments for the parent class and/or Serializer to use.
        """
        super().__init__(**kwargs)
        self._options = Options()

        self.alpha: float = alpha
        self.theta: float = theta
        self.nlatx: int = nlatx
        self.nlaty: int = nlaty
        self.nlatz: int = nlatz
        self.sbuff: float = sbuff
        self.lattice_type = lattice_type
        if substructure is not None:
            self.substructure: DiscreteStructure = substructure
        else:
            self.substructure: DiscreteStructure = RingStructure()

    def __str__(self) -> str:
        """Generate a string representation of the object.

        This method constructs a string that includes the class name, the object's
        name, and its substructure.

        Returns
        -------
        str
            A string representation of the object, including its name and substructure.
        """
        return f"{self.__class__.__name__}({self.name}) with substructure {self.substructure}"

    def __repr__(self) -> str:
        """Generate a string representation of the object."""
        return str(self)

    @property
    def lattice_type(self) -> ShapeType:
        """The lattice type.

        Returns
        -------
        ShapeType
            The LAT, LAT2 or LAT3 type of the Lattice.
        """
        return self._type

    @lattice_type.setter
    def lattice_type(self, value: str | ShapeType) -> None:
        """Set the type of the lattice.

        Parameters
        ----------
        value : str | ShapeType
            The value representing the shape type. Can be a string, integer, or a
            ShapeType enum. Accepted values: 'LAT' for ShapeType.LAT, 'LAT2'
            for ShapeType.LAT2, 'LAT3' for ShapeType.LAT3.

        Raises
        ------
        ValueError
            If the provided value does not correspond to a valid lattice ShapeType.
        """

        if isinstance(value, str):
            value = ShapeType[value.upper()]

        if not value.is_lattice:
            error_msg = f"Unknown ShapeType lattice value {value}."
            raise ValueError(error_msg)

        self._type = value

    def _to_options(self) -> None:
        """Convert internal structure configuration to CLI options format."""
        self._options.shape.stype = self.lattice_type

        self._options.output.path = str(
            self._manager.prepare_path(self.__class__.__name__, self.name)
        )
        self._options.output.base = self.name

        self._options.angle.alpha = float(self.alpha)
        self._options.angle.theta = float(self.theta)

        self._options.lattice.nlatt = [int(self.nlatx), int(self.nlaty), int(self.nlatz)]
        self._options.base.sbuff = float(self.sbuff)

    def assemble(self) -> None:
        """Assemble the project lattice structure by generating shapes from nodes.

        This method orchestrates the assembly process by converting internal options,
        initializing a generator, reading input from each node, and producing
        the final output file.

        Notes
        -----
        The method performs the following steps in sequence:
        1. Converts internal attributes to the appropriate options format
        2. Creates a Generator instance with the converted options
        3. Reads input structure files from each node
        4. Generates the shape based on the collected inputs
        5. Writes the generated output to a file
        """
        if self.substructure is None:
            error_msg = "Substructure was not defined, can't assemble."
            raise ValueError(error_msg)
        if not self.substructure.path:
            error_msg = "Substructure was not assembled, can't put in a lattice."
            raise ValueError(error_msg)

        self._to_options()
        generator = Generator(self._options)

        input_opts = InputOptions(str(self.substructure.path))
        names = tuple(comp.name for comp in self.substructure.components)
        generator.read_input(input_opts, names)

        generator.generate_shape()
        generator.dump_file()


class StructureFactory:
    """Factory class for creating structure instances.

    This factory provides a centralized way to create different types of molecular
    structures (rings, balls, vesicles, etc.) by name or type. It maintains a registry
    of available structures and supports alias resolution for common structure names.

    Examples
    --------
    >>> factory = StructureFactory()
    >>> factory.create(ShapeType.BALL)
    <class 'Ball'>
    >>> factory.create("Micelle")  # alias for BALL
    <class 'Ball'>
    >>> factory.available_structures
    {'Ring', 'Ball', 'Vesicle', 'Rod', 'Bilayer', 'Monolayer', 'Lattice'}
    """

    def __init__(self) -> None:
        """Initialize the Structure factory with available structure types.

        This constructor sets up mappings for different shape types and their common
        aliases, allowing flexible structure instantiation and user-friendly naming.

        Attributes
        ----------
        _available_structures : dict[ShapeType, type[Structure]]
            Mapping of ShapeType enums to their corresponding Structure class types.
            Includes: RING, BALL, VES, ROD, BILAYER, MONOLAYER, and LAT.
        _aliases : dict[str, str]
            Mapping of alternative shape names to their canonical ShapeType names.
            Supports common abbreviations like "BAL" for "BALL" and "MICELLE" for "BALL".
        """

        self._available_structures: dict[ShapeType, type[Structure]] = {
            ShapeType.RING: RingStructure,
            ShapeType.BALL: BallStructure,
            ShapeType.VES: VesicleStructure,
            ShapeType.ROD: RodStructure,
            ShapeType.BILAYER: BilayerStructure,
            ShapeType.MONOLAYER: MonolayerStructure,
            ShapeType.LAT: LatticeStructure,
        }
        self._aliases = {
            "BAL": "BALL",
            "MICELLE": "BALL",
            "BALP": "BALL",
            "VES": "VESICLE",
            "VESP": "VESICLE",
        }

    @property
    def available_structures(self) -> set:
        """Get the names of all available structures."""
        return {key.__name__ for key in self._available_structures.values()}

    def _key_from_alias(self, structure_name: str | ShapeType) -> ShapeType | None:
        """Resolve a structure name or alias to its corresponding ShapeType key.

        This method converts structure name aliases to their actual ShapeType enums.
        It handles both ShapeType enum instances and string representations, supporting
        case-insensitive string lookups.

        Parameters
        ----------
        structure_name : str | ShapeType
            The structure identifier to resolve. Can be either:
            - A ShapeType enum instance
            - A string name or alias (case-insensitive)

        Returns
        -------
        ShapeType | None
            The resolved ShapeType key if found in available structures or aliases,
            None otherwise.

        Examples
        --------
        >>> result = self._key_from_alias("ball")
        >>> result = self._key_from_alias(ShapeType.BALL)
        """
        if (
            isinstance(structure_name, ShapeType)
            and structure_name in self._available_structures
        ):
            return structure_name
        if isinstance(structure_name, ShapeType):
            structure_name = structure_name.name
        if isinstance(structure_name, str):
            structure_name = structure_name.upper()
            alias = self._aliases.get(structure_name)
            if alias is not None:
                return ShapeType[alias]
        return None

    def create(self, structure_name: str | ShapeType) -> type[Structure] | None:
        """Create and retrieve a structure class by name or type alias.

        Parameters
        ----------
        structure_name : str | ShapeType
            The name or alias of the structure to retrieve.

        Returns
        -------
        type[Structure] | None
            The structure class corresponding to the given name or alias,
            or None if the structure is not found in available structures.

        Examples
        --------
        >>> structure_class = factory.create('MyStructure')
        >>> structure_class = factory.create(ShapeType.CUSTOM)
        """

        key = self._key_from_alias(structure_name)
        if key is not None:
            return self._available_structures[key]
        return None
