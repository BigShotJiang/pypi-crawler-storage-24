import sys
from typing import Any

from scripts.bash_cli import call_script
from shapes.project.core import BaseAsset
from shapes.project.files import ProjectFileManager
from shapes.project.sample_model import SampleModel



class AnalysisConfiguration(BaseAsset): ...


class ForceField(BaseAsset): ...


class Analysis(BaseAsset):
    def __init__(
            self, 
            sample_model: SampleModel | None = None, 
            force_field: ForceField | None = None, 
            configuration: AnalysisConfiguration | None = None,
            steps: int = 6,
            **kwargs: Any,
        ):
        super().__init__(**kwargs)

        # TODO update to default when it's available from assets
        # self.configuration = AnalysisConfiguration.load("default")
        self.configuration = configuration if configuration else AnalysisConfiguration()
        self.force_field = force_field if force_field else ForceField.load("CHARMM36")
        self.steps = steps

        self.sample_model =  sample_model

    def equilibrate(self, sample_model_name: str | None = None):
        if sample_model_name is not None:
            sample_name = sample_model_name
        elif self.sample_model is not None:
            sample_name = self.sample_model.name
        else:
            raise ValueError("A valid Sample Model (name) was not provided")
        cwd = None
        if sys.platform.startswith("win"):
            raise RuntimeError("The script is not available on Windows")
        if isinstance(self._manager, ProjectFileManager):
            cwd = self._manager.stage_equilibration(sample_name)
        else:
            raise RuntimeError("Can't run analysis without a project")

        args = (sample_name, str(0), str(self.steps), str(8), "eq")

        call_script("gmx-equilibrate.bsh", *args, cwd=cwd)
