import logging
from copy import deepcopy
from typing import Any

from typeguard import typechecked

from shapes.basics.defaults import Defaults
from shapes.project.core import (
    BaseCollection,
    BaseItem,
    Component,
    Components,
    Fractions,
)

logger = logging.getLogger("__main__")


class Layer(BaseItem):
    """A layer of spherical structures.

    Attributes
    ----------
    fractions : Fractions
        A map of components and their corresponding fractions.
    dmin : float
        A minimum distance between 'bone' atoms in the structure.
    rmin : float
        A radius of internal cavity in the centre of the structure.
    """

    @typechecked
    def __init__(
        self, 
        components: Components, 
        empty: bool = True, 
        fractions: Fractions | None = None, 
        dmin: float | None = None,
        rmin: float | None = None,
        **kwargs
    ) -> None:
        """Initialize the object.

        Parameters
        ----------
        components : Components
            A collection of structure components.
        empty : bool, optional
            A flag to create fractions empty (if True), or fill it with the contents of
            the `Components` object otherwise, by default True.
        fractions : Fractions, optional
            A map of components and their corresponding fractions.
        dmin : float, optional
            A minimum distance between 'bone' atoms in the structure.
        rmin : float, optional
            A radius of internal cavity in the centre of the structure.
        """

        super().__init__(**kwargs)
        self.components = components
        if fractions is None:
            self.fractions = Fractions(self.components, empty)
        else:
            self.fractions = fractions
        self.dmin = dmin
        self.rmin = rmin

    def __str__(self) -> str:
        """Custom casting of the object to `str`"""
        return (
            f"Layer {self.name}: dmin={self.dmin}, rmin={self.rmin}, "
            f"fractions={self.fractions}"
        )

    def __repr__(self) -> str:
        """Custom representation of the object."""
        return str(self)

    def __eq__(self, other: Any) -> bool:
        """Comparison method.

        True if both objects are `Layer` and have matching fractions, dmin and rmin.
        """
        return (
            isinstance(other, type(self))
            and self.dmin == other.dmin
            and self.rmin == other.rmin
            and self.fractions == other.fractions
        )

    @typechecked
    def add_component(self, component: Component) -> None:
        """Adds a component to the layer.

        The component is automatically assigned a default fraction. If it's not present
        in the structure components, it's added to the collection as well.

        Parameters
        ----------
        component : Component
            A component.
        """
        self.fractions[component] = self.fractions.DEFAULT_FRACTION

    @typechecked
    def remove_component(self, component: str | Component) -> None:
        """Removes a component from the layer.

        Gets the component's reference and fraction removed form `fractions`.

        Parameters
        ----------
        component : str | Component
            A component or its name.
        """
        logger.debug(f"Removing component {component} from Layer {self}")
        self.fractions.remove(component)


class Lamella(BaseItem):
    """A lamella containing two leaflets with a symmetric or asymmetric
    composition.

    Parameters
    ----------
    inner_leaflet : Layer
        The inner leaflet of the lamella.
    outer_leaflet : Layer
        The outer leaflet of the lamella.
    components : Components
        A collection of structure components.
    empty : bool, optional
        A flag to create fractions empty (if True), or fill it with the contents of
        the `Components` object otherwise, by default True.
    symmetric : bool, optional
        A flag indicating if the layer should act as symmetric or asymmetric,
        by default True
    """

    @typechecked
    def __init__(
        self,
        components: Components,
        empty: bool = True,
        symmetric: bool = True,
        inner_leaflet: Layer | None = None,
        outer_leaflet: Layer | None = None,
        **kwargs,
    ) -> None:
        """Initialize the object.

        Parameters
        ----------
        inner_leaflet : Layer
            The inner leaflet of the lamella.
        outer_leaflet : Layer
            The outer leaflet of the lamella.
        components : Components
            A collection of structure components.
        empty : bool, optional
            A flag to create fractions empty (if True), or fill it with the contents of
            the `Components` object otherwise, by default True.
        symmetric : bool, optional
            A flag indicating if the layer should act as symmetric or asymmetric,
            by default True
        """
        super().__init__(**kwargs)
        self.components = components
        self.empty = empty
        if inner_leaflet is None:
            self.inner_leaflet = Layer(components, empty, name=f"inner_{self.name}")
        else:
            self.inner_leaflet = inner_leaflet
        if outer_leaflet is None:
            self.outer_leaflet = Layer(components, empty, name=f"outer_{self.name}")
        else:
            self.outer_leaflet = outer_leaflet
        self.symmetric = symmetric

    def __str__(self) -> str:
        """Custom casting of the object to `str`"""
        return (f"Lamella {self.name}: (\n    {self.inner_leaflet};"
                f"\n    {self.outer_leaflet}\n  )")

    def __repr__(self) -> str:
        """Custom representation of the object."""
        return str(self)

    @property
    def symmetric(self) -> bool:
        """A flag indicating if the layer acts as symmetric or asymmetric.

        Returns
        -------
        bool
            Indication of symmetry.
        """

        return self.inner_leaflet.fractions is self.outer_leaflet.fractions

    @symmetric.setter
    @typechecked
    def symmetric(self, value: bool) -> None:
        """Set if the layer should act as symmetric or asymmetric.

        Parameters
        ----------
        value : bool
            If True, the inner leaflet's fractions are assigned to the outer leaflet.
            If False, creates a copy from the inner leaflet's fractions and assigns
            to the outer one.
        """
        if value:
            self.outer_leaflet.fractions = self.inner_leaflet.fractions
        elif not value and self.symmetric:
            self.outer_leaflet.fractions = deepcopy(self.inner_leaflet.fractions)

    def swap(self) -> None:
        """Swaps the inner and outer leaflets."""
        inner_name = self.inner_leaflet.name
        outer_name = self.outer_leaflet.name
        outer = self.inner_leaflet
        inner = self.outer_leaflet
        self.inner_leaflet = inner
        self.inner_leaflet.name = inner_name
        self.outer_leaflet = outer
        self.outer_leaflet.name = outer_name


class Layers(BaseCollection[Layer]):
    """A collection of layers for spherical structures.

    Attributes
    ----------
    rmin_scaling : float
        A scaling value to use in place of manually set rmin values for each layer.
    dmin_scaling : float
        A scaling value to use in place of manually set dmin values for each layer.
    _components : Components
        A collection of structure components.
    """

    @typechecked
    def __init__(
        self, 
        components: Components,
        rmin_scaling: float = Defaults.Shape.LAYERS[1],
        dmin_scaling: float = Defaults.Shape.LAYERS[2],
        **kwargs
    ) -> None:
        """Initialize the object.

        Parameters
        ----------
        components : Components
            A collection of structure components.
        rmin_scaling : float
            A scaling value to use in place of manually set rmin values for each layer.
        dmin_scaling : float
            A scaling value to use in place of manually set dmin values for each layer.
        """
        super().__init__(**kwargs)
        self._components: Components = components
        self.rmin_scaling: float = rmin_scaling
        self.dmin_scaling: float = dmin_scaling

    @typechecked
    def add(self, value: int | None = None, empty: bool = True) -> None:
        """Add a new layer(s) to the collection.

        Parameters
        ----------
        value : int | None, optional
            An amount of layers to add, by default None
        empty : bool, optional
            A flag to create fractions empty (if True), or fill it with the contents of
            the `Components` object otherwise, by default True.
        """
        if value is None:
            amount = 1
        elif isinstance(value, int):
            amount = value
        else:
            amount = 0
        for _ in range(amount):
            self.append(Layer(self._components, empty, name=f"lr_{len(self)}"))

    @typechecked
    def add_component_to_all(self, component: Component) -> None:
        """Add a component to every layer in the collection.

        Parameters
        ----------
        component : Component
            A component to add.
        """
        for item in self._items:
            item.add_component(component)

    @typechecked
    def remove_component_from_all(self, component: Component) -> None:
        """Remove a component from every layer in the collection.

        Parameters
        ----------
        component : Component
            A component to remove.
        """
        for item in self._items:
            item.remove_component(component)

    @property
    def as_list(self) -> list[Layer]:
        """A property that provides a list of all layers in the collection.

        Returns
        -------
        list[Layer]
            the list of layers in the collection.
        """
        return self._items

    @property
    def _attr_param_map(self) -> dict[str, str]:
        attrs = super()._attr_param_map
        attrs["_components"] = "components"
        return attrs


class Lamellae(BaseCollection[Lamella]):
    """A collection of lamellae for spherical structures.

    Attributes
    ----------
    rmin_scaling : float
        A scaling value to use in place of manually set rmin values for each layer.
    dmin_scaling : float
        A scaling value to use in place of manually set dmin values for each layer.
    _components : Components
        A collection of structure components.
    """

    @typechecked
    def __init__(
        self, 
        components: Components, 
        rmin_scaling: float = Defaults.Shape.LAYERS[1],
        dmin_scaling: float = Defaults.Shape.LAYERS[2],
        **kwargs
    ) -> None:
        """Initialize the object.

        Parameters
        ----------
        components : Components
            A collection of structure components.
        rmin_scaling : float
            A scaling value to use in place of manually set rmin values for each layer.
        dmin_scaling : float
            A scaling value to use in place of manually set dmin values for each layer.
        """
        super().__init__(**kwargs)
        self._components: Components = components
        self.rmin_scaling: float = rmin_scaling
        self.dmin_scaling: float = dmin_scaling

    @typechecked
    def add(self, value: int | None = None, empty: bool = True) -> None:
        """Add a new layer(s) to the collection.

        Parameters
        ----------
        value : int | None, optional
            An amount of layers to add, by default None
        empty : bool, optional
            A flag to create fractions empty (if True), or fill it with the contents of
            the `Components` object otherwise, by default True.
        """
        if value is None:
            amount = 1
        elif isinstance(value, int):
            amount = value
        else:
            amount = 0
        for _ in range(amount):
            self.append(Lamella(self._components, empty, name=f"lr_{len(self)}"))

    @typechecked
    def add_component_to_all(self, component: Component) -> None:
        """Add a component to every layer and its leaflets in the collection.

        Parameters
        ----------
        component : Component
            A component to add.
        """
        for item in self._items:
            item.inner_leaflet.add_component(component)
            item.outer_leaflet.add_component(component)

    @typechecked
    def remove_component_from_all(self, component: Component) -> None:
        """Remove a component from every leaflet in the collection.

        Parameters
        ----------
        component : Component
            A component to remove.
        """
        for item in self._items:
            item.inner_leaflet.remove_component(component)
            item.outer_leaflet.remove_component(component)

    @property
    def as_list(self) -> list[Layer]:
        """A property that provides a list of all lamellae leaflets in the
        collection.

        Returns
        -------
        list[Layer]
            the list of layers in the collection.
        """
        leaflets_list = []
        for layer in self._items:
            leaflets_list.append(layer.inner_leaflet)
            leaflets_list.append(layer.outer_leaflet)
        return leaflets_list

    @property
    def _attr_param_map(self) -> dict[str, str]:
        attrs = super()._attr_param_map
        attrs["_components"] = "components"
        return attrs