"""This module defines the `SampleModel` class.

The `SampleModel` class represents a molecular system composed of a structure, a pair
of ions, and a solvent. It provides functionality to initialize, validate, and assemble
the molecular system for simulation purposes.

Usage
-----
Typical usage example:

    model = SampleModel(structure=my_structure, ion1, ion2, name="example")
    model.assemble()
"""

from typing import Any

from scripts.bash_cli import call_script
from shapes.project.core import (
    BaseAsset,
    Ions,
    Solvent,
)
from shapes.project.structure import (
    DiscreteStructure,
    LatticeStructure,
    RingStructure,
    Structure,
)


class SampleModel(BaseAsset):
    """A molecular system composed of a structure, ions pair, and a solvent.

    Parameters
    ----------
    structure : Structure or None, optional
        The molecular structure to use. If None, a default Ring structure is used.
    *ions : Ion
        Variable number (up to 2) of Ion objects to include in the model.

    Attributes
    ----------
    ions : Ions
        Collection of ions (up to 2) included in the model.
    structure : Structure
        The molecular structure of the model.
    solvent : Solvent
        The solvent used in the model.

    Methods
    -------
    assemble()
        Validates the model components and assembles the molecular system, preparing it
        for simulation.
    """

    def __init__(
        self,
        structure: Structure | None = None,
        solvent: Solvent | None = None,
        ions: Ions | None = None,
        **kwargs: Any,
    ) -> None:
        """Initializes the model with the given structure, ions, name, and paths.

        If no structure is provided, a default `Ring` is used. Loads the default solvent
        ("TIP3") and appends any provided ions to the model.

        Parameters
        ----------
        structure : Structure or None, optional
            The structure to use for the model. If None, a default `Ring` structure is
            used.
        solvent : Solvent or None, optional
            The solvent to use for the model. If None, a default `TIP3` is used.
        ions : Ions
            Collection of ions (up to 2) included in the model.
        **kwargs
            Arbitrary keyword arguments for the parent class and/or Serializer yse.
        """
        super().__init__(**kwargs)
        if ions is not None:
            if isinstance(ions, Ions):
                self.ions = ions
            else:
                raise TypeError(
                    f"Got an unexpected type {type(ions).__name__} as Ions."
                )
        else:
            self.ions = Ions(length_limit=2)

        self.structure: Structure = structure if structure else RingStructure()
        self.solvent: Solvent = solvent if solvent else Solvent.load("TIP3")

    def assemble(self):
        """Assemble the sample model.

        This method prepares the molecular system for simulation by validating the
        structure and components, extracting component properties, configuring ions,
        and invoking the assembly script.

        Raises
        ------
        TypeError
            If the structure is neither a DiscreteStructure nor a Lattice with a
            substructure.
        ValueError
            If no components are present, if any component lacks sufficient paths,
            if atom numbers are missing or zero, or if counter-ions are not defined
            for all components.
        FileNotFoundError
            If topology or structure files are missing for any component (fewer than
            2 paths).
        NotImplementedError
            If the number of ions is not 0 or 2.
        RuntimeError
            If the structure was assembled but the path cannot be found.

        Notes
        -----
        The method performs the following steps:
        1. Validates structure type and extracts components
        2. Validates component paths, atom numbers, and counter-ions
        3. Prepares solute and ion parameters
        4. Assembles the structure
        5. Invokes the gmx-setup-multi.bsh script with appropriate arguments
        6. Finalizes the sample model in the manager
        """

        # validations
        if isinstance(self.structure, DiscreteStructure):
            components = self.structure.components
        elif (
            isinstance(self.structure, LatticeStructure)
            and self.structure.substructure is not None
        ):
            components = self.structure.substructure.components
        else:
            raise TypeError("Unexpected structure type in the SampleModel.")

        if len(components) == 0:
            raise ValueError("Can't assemble without any components.")

        for component in components:
            if len(component.paths) < 2:
                raise FileNotFoundError(
                    "Make sure that both topology and structure files are present. "
                    f"{component.paths} is not enough to assemble."
                )

        solute_names = [comp.name for comp in components]
        solute_names = ",".join(solute_names)
        solute_atom_nums = [comp.number_of_atoms for comp in components]
        if len(solute_atom_nums) < len(components) or 0 in solute_atom_nums:
            raise ValueError("Can't assemble without all the components' atom numbers.")
        solute_atom_nums = ",".join(map(str, solute_atom_nums))
        c_ions = [comp.counter_ion for comp in components]
        if None in c_ions:
            raise ValueError("Can't assemble without all the components' counter-ions.")
        c_ion_names = [c_ion.name for c_ion in c_ions if c_ion is not None]
        if len(c_ion_names) < len(components):
            raise ValueError("Can't assemble without all the components' counter-ions.")
        c_ion_names = ",".join(map(str, c_ion_names))

        salt_pairs_num = -1 if self.ions.match_structure_components else self.ions.amount_of_pairs

        args = [solute_names, solute_atom_nums, c_ion_names, salt_pairs_num]

        if len(self.ions) == 2:
            args.append(self.ions[0].name)
            args.append(self.ions[1].name)
        elif len(self.ions) != 0:
            raise NotImplementedError("Can only add pairs of ions or use the default.")

        # assembly
        self.structure.assemble()
        struct_path = self.structure.path

        args.insert(0, str(struct_path))

        if struct_path is None:
            raise RuntimeError("Structure was assembled but not found")
        temp_setup_dir = self._manager.setup_sample_model(struct_path)

        call_script("gmx-setup-multi.bsh", *args, cwd=temp_setup_dir)

        self._manager.finalize_sample_model(temp_setup_dir, self.name)
