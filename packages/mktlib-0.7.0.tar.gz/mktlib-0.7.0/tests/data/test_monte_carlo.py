from __future__ import annotations

import numpy as np
import pytest

from mktlib.data import (
    Process,
    geometric_brownian_motion,
    monte_carlo,
    ornstein_uhlenbeck,
)


class TestMonteCarlo:
    def test_output_shape(self):
        df = monte_carlo(
            geometric_brownian_motion, n_simulations=10, n=50, seed=42
        )
        assert df.shape == (500, 3)  # 10 sims * 50 steps
        assert df.columns == ["simulation", "step", "price"]

    def test_simulation_column_values(self):
        df = monte_carlo(
            geometric_brownian_motion, n_simulations=5, n=20, seed=42
        )
        sims = df["simulation"].unique().sort().to_list()
        assert sims == [0, 1, 2, 3, 4]

    def test_reproducibility(self):
        df1 = monte_carlo(
            geometric_brownian_motion, n_simulations=5, n=50, seed=99
        )
        df2 = monte_carlo(
            geometric_brownian_motion, n_simulations=5, n=50, seed=99
        )
        assert df1.equals(df2)

    def test_different_seeds_differ(self):
        df1 = monte_carlo(
            geometric_brownian_motion, n_simulations=3, n=50, seed=1
        )
        df2 = monte_carlo(
            geometric_brownian_motion, n_simulations=3, n=50, seed=2
        )
        assert not df1.equals(df2)

    def test_works_with_ou(self):
        df = monte_carlo(ornstein_uhlenbeck, n_simulations=3, n=100, seed=42)
        assert df.columns == ["simulation", "step", "value"]
        assert df.shape == (300, 3)

    def test_passes_kwargs(self):
        df = monte_carlo(
            geometric_brownian_motion,
            n_simulations=2,
            n=10,
            base_price=500.0,
            seed=42,
        )
        # First price of each sim should be base_price
        first_prices = df.filter(step=0)["price"].to_list()
        assert all(p == pytest.approx(500.0) for p in first_prices)

    def test_invalid_n_simulations(self):
        with pytest.raises(ValueError, match="n_simulations must be >= 1"):
            monte_carlo(geometric_brownian_motion, n_simulations=0, n=10)


class TestMonteCarloEnum:
    def test_gbm_enum_shape(self):
        df = monte_carlo(Process.GBM, n_simulations=10, n=50, seed=42)
        assert df.shape == (500, 3)
        assert df.columns == ["simulation", "step", "price"]

    def test_gbm_enum_simulation_values(self):
        df = monte_carlo(Process.GBM, n_simulations=5, n=20, seed=42)
        sims = df["simulation"].unique().sort().to_list()
        assert sims == [0, 1, 2, 3, 4]

    def test_gbm_enum_reproducibility(self):
        df1 = monte_carlo(Process.GBM, n_simulations=5, n=50, seed=99)
        df2 = monte_carlo(Process.GBM, n_simulations=5, n=50, seed=99)
        assert df1.equals(df2)

    def test_gbm_enum_different_seeds_differ(self):
        df1 = monte_carlo(Process.GBM, n_simulations=3, n=50, seed=1)
        df2 = monte_carlo(Process.GBM, n_simulations=3, n=50, seed=2)
        assert not df1.equals(df2)

    def test_gbm_enum_base_price(self):
        df = monte_carlo(
            Process.GBM, n_simulations=2, n=10, base_price=500.0, seed=42
        )
        first_prices = df.filter(step=0)["price"].to_list()
        assert all(p == pytest.approx(500.0) for p in first_prices)

    def test_gbm_enum_prices_positive(self):
        df = monte_carlo(
            Process.GBM, n_simulations=10, n=100, volatility=0.1, seed=42
        )
        assert (df["price"] > 0).all()

    def test_ou_enum(self):
        df = monte_carlo(Process.OU, n_simulations=3, n=100, seed=42)
        assert df.columns == ["simulation", "step", "value"]
        assert df.shape == (300, 3)

    def test_frw_enum(self):
        df = monte_carlo(Process.FRW, n_simulations=3, n=100, seed=42)
        assert df.columns == ["simulation", "step", "price"]
        assert df.shape == (300, 3)

    def test_gbm_enum_single_point(self):
        df = monte_carlo(Process.GBM, n_simulations=5, n=1, seed=42)
        assert df.shape == (5, 3)
        assert all(
            p == pytest.approx(100.0) for p in df["price"].to_list()
        )


class TestFrwVectorized:
    def test_reproducibility(self):
        df1 = monte_carlo(
            Process.FRW, n_simulations=5, n=50, hurst=0.7, seed=99
        )
        df2 = monte_carlo(
            Process.FRW, n_simulations=5, n=50, hurst=0.7, seed=99
        )
        assert df1.equals(df2)

    def test_hurst_above_05_positive_autocorrelation(self):
        df = monte_carlo(
            Process.FRW,
            n_simulations=20,
            n=500,
            hurst=0.8,
            step_size=1.0,
            seed=42,
        )
        autocorrs = []
        for sim in df["simulation"].unique().to_list():
            prices = df.filter(simulation=sim)["price"].to_numpy()
            inc = np.diff(prices)
            if len(inc) > 1:
                autocorrs.append(np.corrcoef(inc[:-1], inc[1:])[0, 1])
        mean_ac = np.mean(autocorrs)
        assert mean_ac > 0.1

    def test_hurst_below_05_negative_autocorrelation(self):
        df = monte_carlo(
            Process.FRW,
            n_simulations=20,
            n=500,
            hurst=0.2,
            step_size=1.0,
            seed=42,
        )
        autocorrs = []
        for sim in df["simulation"].unique().to_list():
            prices = df.filter(simulation=sim)["price"].to_numpy()
            inc = np.diff(prices)
            if len(inc) > 1:
                autocorrs.append(np.corrcoef(inc[:-1], inc[1:])[0, 1])
        mean_ac = np.mean(autocorrs)
        assert mean_ac < -0.1

    def test_base_price(self):
        df = monte_carlo(
            Process.FRW,
            n_simulations=5,
            n=20,
            base_price=250.0,
            seed=42,
        )
        first_prices = df.filter(step=0)["price"].to_list()
        assert all(p == pytest.approx(250.0) for p in first_prices)
