import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="readysignal-staging",
    version="0.1.1",
    author="Sean Yoon",
    author_email="sean.yoon@readysignal.com",
    description="The staging API for staging.app.readysignal.com",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Ready-Signal/readysignal-python-staging",
    packages=setuptools.find_packages(),
    install_requires=["requests>=2.24.0", "pandas>=1.2.0"],
    classifiers=[]
)
