from tests.credentials import creds
from readysignal_staging import (
    connect_to_readysignal,
    list_signals,
    get_signal_details,
    delete_signal,
    auto_discover,
)
from readysignal_staging import get_signal, get_signal_pandas, signal_to_csv
from readysignal_staging import (
    connect_to_readysignal_features,
    get_features_list,
    show_feature,
    show_feature_detailed,
    get_feature_data,
    get_feature_data_pandas,
)
import pandas as pd


def test_connect_to_readysignal():
    access_token = creds["access_token"]
    rs = connect_to_readysignal(access_token)

    assert isinstance(rs, dict)


def test_list_signals():
    access_token = creds["access_token"]
    signals = list_signals(access_token)

    assert isinstance(signals, dict)
    assert "data" in signals.keys()


def test_get_signal_details():
    access_token = creds["access_token"]
    signal_id = creds["signal_id"]
    signal_details = get_signal_details(access_token, signal_id)

    assert isinstance(signal_details, dict)
    assert "data" in signal_details.keys()


def test_get_signal():
    access_token = creds["access_token"]
    signal_id = creds["signal_id"]
    signal = get_signal(access_token, signal_id)

    assert isinstance(signal, list)
    assert "start" in signal[0].keys()


def test_get_signal_pandas():
    access_token = creds["access_token"]
    signal_id = creds["signal_id"]
    signal = get_signal_pandas(access_token, signal_id)

    assert isinstance(signal, pd.DataFrame)
    assert "start" in signal.columns


def test_signal_to_csv(tmp_path):
    access_token = creds["access_token"]
    signal_id = creds["signal_id"]
    file_name = str(tmp_path / "test_output.csv")
    signal_to_csv(access_token, signal_id, file_name)

    import os
    assert os.path.exists(file_name)


def test_auto_discover():
    access_token = creds["access_token"]
    response = auto_discover(
        access_token, "Country", "Month", df=pd.read_csv("tests/country.csv")
    )

    assert response.status_code == 200


def test_connect_to_readysignal_features():
    access_token = creds["access_token"]
    bank_name = creds["bank_name"]
    rs = connect_to_readysignal_features(access_token, bank_name)

    assert isinstance(rs, dict)


def test_get_features_list():
    access_token = creds["access_token"]
    bank_name = creds["bank_name"]
    list_features = get_features_list(access_token, bank_name)

    assert isinstance(list_features, dict)


def test_show_feature():
    access_token = creds["access_token"]
    bank_name = creds["bank_name"]
    feature = [317]
    feat_show = show_feature(access_token, bank_name, feature)
    feat_dict = list(feat_show.values())[0]

    assert isinstance(feat_show, dict)
    assert feature[0] in feat_dict.values()


def test_show_feature_detailed():
    access_token = creds["access_token"]
    bank_name = creds["bank_name"]
    feature = [317]
    feat_details = show_feature_detailed(access_token, bank_name, feature)

    assert isinstance(feat_details, dict)


def test_features_data():
    access_token = creds["access_token"]
    bank_name = creds["bank_name"]
    features = [317]
    start_date = "2021-01-01"
    end_date = "2021-12-31"
    feat_data = get_feature_data(access_token, bank_name, features, start_date, end_date)

    assert isinstance(feat_data, dict)


def test_feature_data_pandas():
    access_token = creds["access_token"]
    bank_name = creds["bank_name"]
    features = [317]
    start_date = "2021-01-01"
    end_date = "2021-12-31"
    df = get_feature_data_pandas(access_token, bank_name, features, start_date, end_date)

    assert isinstance(df, pd.DataFrame)
