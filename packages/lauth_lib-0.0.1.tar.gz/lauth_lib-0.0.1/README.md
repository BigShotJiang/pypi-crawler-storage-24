# lauth-lib

[![PyPI - Version](https://img.shields.io/pypi/v/lauth-lib.svg)](https://pypi.org/project/lauth-lib)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/lauth-lib.svg)](https://pypi.org/project/lauth-lib)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install lauth-lib
```

## License

`lauth-lib` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
