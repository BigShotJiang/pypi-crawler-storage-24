# Geospatial Tool-Definitionen
