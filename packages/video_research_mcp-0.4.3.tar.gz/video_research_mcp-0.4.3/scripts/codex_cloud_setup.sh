#!/usr/bin/env bash
set -euo pipefail

cd /workspace/video-research-mcp

if ! command -v uv >/dev/null 2>&1; then
  python3 -m pip install --user uv
  export PATH="$HOME/.local/bin:$PATH"
fi

uv venv
source .venv/bin/activate
uv pip install -e ".[dev]"
