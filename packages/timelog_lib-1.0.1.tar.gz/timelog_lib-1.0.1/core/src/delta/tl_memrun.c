#include "tl_memrun.h"
#include "../internal/tl_refcount.h"

/*===========================================================================
 * Bounds computation (public for reuse by tl_memtable.c)
 *
 * CRITICAL: Bounds MUST include tombstones, not just records.
 * This ensures tombstones outside record bounds are NOT pruned during
 * read-path overlap checks (which would cause missed deletes).
 *===========================================================================*/

void tl__memrun_compute_bounds(tl_memrun_t* mr) {
    tl_ts_t min_ts = TL_TS_MAX;
    tl_ts_t max_ts = TL_TS_MIN;

    if (mr->run_len > 0) {
        min_ts = TL_MIN(min_ts, mr->run[0].ts);
        max_ts = TL_MAX(max_ts, mr->run[mr->run_len - 1].ts);
    }

    if (mr->ooo_total_len > 0) {
        min_ts = TL_MIN(min_ts, mr->ooo_min_ts);
        max_ts = TL_MAX(max_ts, mr->ooo_max_ts);
    }

    /* Tombstones widen bounds to prevent pruning during overlap checks */
    for (size_t i = 0; i < mr->tombs_len; i++) {
        const tl_interval_t* tomb = &mr->tombs[i];
        min_ts = TL_MIN(min_ts, tomb->start);

        if (tomb->end_unbounded) {
            max_ts = TL_TS_MAX;
        } else {
            max_ts = TL_MAX(max_ts, tomb->end - 1);
        }
    }

    mr->min_ts = min_ts;
    mr->max_ts = max_ts;
}

/*===========================================================================
 * Creation
 *===========================================================================*/

/** Initialize pre-allocated memrun. Takes ownership of arrays. */
tl_status_t tl_memrun_init(tl_memrun_t* mr,
                            tl_alloc_ctx_t* alloc,
                            tl_record_t* run, size_t run_len,
                            tl_ooorunset_t* ooo_runs,
                            tl_interval_t* tombs, size_t tombs_len,
                            tl_seq_t applied_seq) {
    if (mr == NULL || alloc == NULL) {
        return TL_EINVAL;
    }
    if (run_len == 0 && ooo_runs == NULL && tombs_len == 0) {
        return TL_EINVAL;
    }
    if (run_len > 0 && run == NULL) {
        return TL_EINVAL;
    }
    if (ooo_runs != NULL && ooo_runs->count == 0) {
        return TL_EINVAL;
    }
    if (tombs_len > 0 && tombs == NULL) {
        return TL_EINVAL;
    }

    mr->run = run;
    mr->run_len = run_len;
    mr->ooo_runs = ooo_runs;
    mr->ooo_total_len = (ooo_runs == NULL) ? 0 : ooo_runs->total_len;
    mr->ooo_run_count = (ooo_runs == NULL) ? 0 : ooo_runs->count;
    mr->ooo_min_ts = TL_TS_MAX;
    mr->ooo_max_ts = TL_TS_MIN;
    mr->tombs = tombs;
    mr->tombs_len = tombs_len;
    mr->applied_seq = applied_seq;

    mr->alloc = alloc;
    tl_atomic_init_u32(&mr->refcnt, 1);

    if (mr->ooo_total_len > 0) {
        for (size_t i = 0; i < mr->ooo_run_count; i++) {
            const tl_ooorun_t* run_ptr = mr->ooo_runs->runs[i];
            mr->ooo_min_ts = TL_MIN(mr->ooo_min_ts, run_ptr->min_ts);
            mr->ooo_max_ts = TL_MAX(mr->ooo_max_ts, run_ptr->max_ts);
        }
    }

    tl__memrun_compute_bounds(mr);
    return TL_OK;
}

tl_status_t tl_memrun_create(tl_alloc_ctx_t* alloc,
                              tl_record_t* run, size_t run_len,
                              tl_ooorunset_t* ooo_runs,
                              tl_interval_t* tombs, size_t tombs_len,
                              tl_seq_t applied_seq,
                              tl_memrun_t** out) {
    TL_ASSERT(alloc != NULL);
    TL_ASSERT(out != NULL);

    *out = NULL;

    if (run_len == 0 && ooo_runs == NULL && tombs_len == 0) {
        return TL_EINVAL;
    }
    if (run_len > 0 && run == NULL) {
        return TL_EINVAL;
    }
    if (ooo_runs != NULL && ooo_runs->count == 0) {
        return TL_EINVAL;
    }
    if (tombs_len > 0 && tombs == NULL) {
        return TL_EINVAL;
    }

    tl_memrun_t* mr = NULL;
    tl_status_t st = tl_memrun_alloc(alloc, &mr);
    if (st != TL_OK) {
        return st;
    }

    st = tl_memrun_init(mr, alloc, run, run_len, ooo_runs, tombs, tombs_len,
                        applied_seq);
    if (st != TL_OK) {
        tl__free(alloc, mr);
        return st;
    }

    *out = mr;
    return TL_OK;
}

tl_status_t tl_memrun_alloc(tl_alloc_ctx_t* alloc, tl_memrun_t** out) {
    TL_ASSERT(alloc != NULL);
    TL_ASSERT(out != NULL);

    *out = NULL;

    tl_memrun_t* mr = TL_NEW(alloc, tl_memrun_t);
    if (mr == NULL) {
        return TL_ENOMEM;
    }

    *out = mr;
    return TL_OK;
}

/*===========================================================================
 * Reference Counting
 *===========================================================================*/

tl_memrun_t* tl_memrun_acquire(tl_memrun_t* mr) {
    if (mr == NULL) {
        return NULL;
    }

    tl_atomic_fetch_add_u32(&mr->refcnt, 1, TL_MO_RELAXED);
    return mr;
}

void tl_memrun_release(tl_memrun_t* mr) {
    if (mr == NULL) {
        return;
    }

    TL_REFCOUNT_RELEASE(&mr->refcnt, {
        if (mr->run != NULL) {
            tl__free(mr->alloc, mr->run);
        }
        if (mr->ooo_runs != NULL) {
            tl_ooorunset_release(mr->ooo_runs);
        }
        if (mr->tombs != NULL) {
            tl__free(mr->alloc, mr->tombs);
        }
        tl__free(mr->alloc, mr);
    }, "memrun double-release: refcnt was 0 before decrement");
}

/*===========================================================================
 * Validation (Debug Only)
 *===========================================================================*/

#ifdef TL_DEBUG

static bool is_records_sorted_ts(const tl_record_t* arr, size_t len) {
    if (len <= 1) {
        return true;
    }
    for (size_t i = 0; i < len - 1; i++) {
        if (arr[i].ts > arr[i + 1].ts) {
            return false;
        }
    }
    return true;
}

static bool is_records_sorted_ts_handle(const tl_record_t* arr, size_t len) {
    if (len <= 1) {
        return true;
    }
    for (size_t i = 0; i < len - 1; i++) {
        if (arr[i].ts > arr[i + 1].ts) {
            return false;
        }
        if (arr[i].ts == arr[i + 1].ts &&
            arr[i].handle > arr[i + 1].handle) {
            return false;
        }
    }
    return true;
}

static bool is_tombs_valid(const tl_interval_t* arr, size_t len) {
    if (len <= 1) {
        return true;
    }
    for (size_t i = 0; i < len - 1; i++) {
        const tl_interval_t* curr = &arr[i];
        const tl_interval_t* next = &arr[i + 1];

        if (curr->start > next->start) {
            return false;
        }
        if (curr->end_unbounded) {
            return false;
        }
        if (curr->end > next->start) {
            return false;
        }
        /* Adjacent with same seq should have been coalesced */
        if (curr->end == next->start && curr->max_seq == next->max_seq) {
            return false;
        }
    }
    return true;
}

bool tl_memrun_validate(const tl_memrun_t* mr) {
    if (mr == NULL) {
        return false;
    }

    if (tl_memrun_refcnt(mr) == 0) {
        return false;
    }

    if (mr->run_len == 0 && mr->ooo_total_len == 0 && mr->tombs_len == 0) {
        return false;
    }

    if (!is_records_sorted_ts(mr->run, mr->run_len)) {
        return false;
    }

    if (mr->ooo_total_len > 0) {
        if (mr->ooo_runs == NULL || mr->ooo_run_count == 0) {
            return false;
        }
        if (mr->ooo_run_count != mr->ooo_runs->count) {
            return false;
        }
        size_t total = 0;
        uint64_t last_gen = 0;
        bool have_gen = false;
        tl_ts_t min_ts = TL_TS_MAX;
        tl_ts_t max_ts = TL_TS_MIN;

        for (size_t i = 0; i < mr->ooo_run_count; i++) {
            const tl_ooorun_t* run = mr->ooo_runs->runs[i];
            if (run == NULL) {
                return false;
            }
            if (!is_records_sorted_ts_handle(run->records, run->len)) {
                return false;
            }
            if (have_gen && run->gen < last_gen) {
                return false;
            }
            have_gen = true;
            last_gen = run->gen;

            if (run->len > SIZE_MAX - total) {
                return false;
            }
            total += run->len;

            min_ts = TL_MIN(min_ts, run->min_ts);
            max_ts = TL_MAX(max_ts, run->max_ts);
        }

        if (total != mr->ooo_total_len) {
            return false;
        }
        if (min_ts != mr->ooo_min_ts || max_ts != mr->ooo_max_ts) {
            return false;
        }
    } else if (mr->ooo_runs != NULL || mr->ooo_run_count != 0) {
        return false;
    }

    if (!is_tombs_valid(mr->tombs, mr->tombs_len)) {
        return false;
    }

    tl_ts_t expected_min = TL_TS_MAX;
    if (mr->run_len > 0) {
        expected_min = TL_MIN(expected_min, mr->run[0].ts);
    }
    if (mr->ooo_total_len > 0) {
        expected_min = TL_MIN(expected_min, mr->ooo_min_ts);
    }
    for (size_t i = 0; i < mr->tombs_len; i++) {
        expected_min = TL_MIN(expected_min, mr->tombs[i].start);
    }
    if (mr->min_ts != expected_min) {
        return false;
    }

    tl_ts_t expected_max = TL_TS_MIN;
    if (mr->run_len > 0) {
        expected_max = TL_MAX(expected_max, mr->run[mr->run_len - 1].ts);
    }
    if (mr->ooo_total_len > 0) {
        expected_max = TL_MAX(expected_max, mr->ooo_max_ts);
    }
    for (size_t i = 0; i < mr->tombs_len; i++) {
        const tl_interval_t* tomb = &mr->tombs[i];
        if (tomb->end_unbounded) {
            expected_max = TL_TS_MAX;
        } else {
            expected_max = TL_MAX(expected_max, tomb->end - 1);
        }
    }
    if (mr->max_ts != expected_max) {
        return false;
    }

    return true;
}

#endif /* TL_DEBUG */
