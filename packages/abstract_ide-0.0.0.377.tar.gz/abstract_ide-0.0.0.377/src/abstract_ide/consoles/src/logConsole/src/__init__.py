from .main import logConsole
