"""AnyVector - Unified Python interface for vector databases."""

__version__ = "0.0.1a1"
