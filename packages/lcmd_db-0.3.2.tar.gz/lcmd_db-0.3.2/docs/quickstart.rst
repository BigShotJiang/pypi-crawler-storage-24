Quick Start
===========

Loading Data
------------

.. code-block:: python

   from lcmd_db import load_dataset

   # Download a dataset (cached locally)
   data = load_dataset("qm9", include=["molecules", "reactions", "structures"])

   # Access raw DataFrames
   data.molecules.head()
   data.reactions.head()

Working with Datasets
---------------------

.. code-block:: python

   import polars as pl

   # Convert to a typed, lazy Dataset
   molecules = data.as_dataset("molecules")

   # Index, slice, iterate
   mol = molecules[0]         # Molecule(id=1, properties={...}, structure_path=...)
   subset = molecules[10:20]  # MoleculeDataset
   for mol in molecules:
       print(mol.properties["smiles"])

   # Filter (pushed down to parquet)
   heavy = molecules.filter(pl.col("molecular_weight") > 200)

   # Train/test split
   train, test = molecules.train_test_split(test_size=0.2)

Reactions & Participants
------------------------

.. code-block:: python

   from lcmd_db import ParticipantRole

   reactions = data.as_dataset("reactions")
   rxn = reactions[0]

   for p in rxn.participants:
       print(f"{p.role.value}: {p.molecule.properties['smiles']}")

   # Filter by role
   reactants = [p for p in rxn.participants if p.role == ParticipantRole.REACTANT]

Fragments
---------

.. code-block:: python

   fragments = data.as_dataset("fragments")
   frag = fragments[0]
   print(frag.fragment_type)  # "core", "substituent", etc.
