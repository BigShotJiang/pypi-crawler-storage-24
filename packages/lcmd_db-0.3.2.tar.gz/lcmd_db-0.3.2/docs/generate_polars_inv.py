"""Generate a patched polars objects.inv that includes py:class entries.

Polars uses :noindex: on its classes, so downstream intersphinx can't link them.
This script downloads their inventory and adds the missing py:class entries.

Run: uv run --group docs python docs/generate_polars_inv.py
"""

from pathlib import Path

import sphobjinv as soi

POLARS_URL = "https://docs.pola.rs/api/python/stable/"
OUTPUT = Path(__file__).parent / "_polars_inv.inv"

CLASSES = {
    "polars.DataFrame": "reference/dataframe/index.html",
    "polars.LazyFrame": "reference/lazyframe/index.html",
    "polars.Expr": "reference/expressions/index.html",
    "polars.Series": "reference/series/index.html",
}


def main() -> None:
    inv = soi.Inventory(url=POLARS_URL + "objects.inv")

    existing = {o.name for o in inv.objects if o.domain == "py" and o.role == "class"}

    for cls, page in CLASSES.items():
        if cls not in existing:
            inv.objects.append(
                soi.DataObjStr(
                    name=cls,
                    domain="py",
                    role="class",
                    priority="1",
                    uri=page,
                    dispname="-",
                )
            )

    soi.writebytes(str(OUTPUT), soi.compress(inv.data_file()))
    print(f"Wrote {OUTPUT} ({len(inv.objects)} entries)")


if __name__ == "__main__":
    main()
