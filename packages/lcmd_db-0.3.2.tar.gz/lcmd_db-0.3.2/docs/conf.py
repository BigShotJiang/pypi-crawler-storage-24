"""Sphinx configuration for lcmd-db."""

import lcmd_db

project = "lcmd-db"
author = "LCMD, EPFL"
copyright = "2025, LCMD, EPFL"
version = lcmd_db.__version__
release = lcmd_db.__version__

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.autosummary",
    "sphinx.ext.intersphinx",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "sphinx_autodoc_typehints",
    "sphinx_copybutton",
    "sphinx_design",
    "sphinx_toolbox.more_autodoc.typevars",
    "sphinx_toolbox.more_autodoc.generic_bases",
]

html_theme = "furo"
html_title = "lcmd-db"
html_static_path = ["_static"]
html_theme_options = {
    "sidebar_hide_name": True,
    "light_logo": "logo.svg",
    "dark_logo": "logo-dark.svg",
    "source_repository": "https://github.com/lcmd-epfl/db",
    "source_branch": "master",
    "source_directory": "packages/lcmd-client/",
    "light_css_variables": {
        "color-brand-primary": "#dc2626",
        "color-brand-content": "#dc2626",
    },
    "dark_css_variables": {
        "color-brand-primary": "#f87171",
        "color-brand-content": "#f87171",
    },
}

# Autodoc
autodoc_default_options = {
    "members": True,
    "show-inheritance": True,
    "member-order": "bysource",
}
autodoc_typehints = "description"
autodoc_typehints_description_target = "documented_params"
autodoc_class_signature = "separated"
autosummary_generate = True

# Type display
always_use_bars_union = True
python_display_short_literal_types = True

# sphinx-autodoc-typehints
typehints_defaults = "braces"
typehints_use_signature = False
typehints_use_signature_return = False
simplify_optional_unions = True
typehints_fully_qualified = False


def _typehints_formatter(annotation: object, config: object) -> str | None:
    """Render TypeVars by name and fix polars cross-references."""
    from typing import TypeVar

    if isinstance(annotation, TypeVar):
        return f"``{annotation.__name__}``"
    if isinstance(annotation, type):
        module = getattr(annotation, "__module__", "")
        qualname = getattr(annotation, "__qualname__", "")
        if module.startswith("polars.") and "." not in qualname:
            return f":py:class:`polars.{qualname}`"
    ref = str(annotation)
    if ref.startswith("polars."):
        return f":py:class:`{ref}`"
    return None


typehints_formatter = _typehints_formatter

# sphinx-toolbox
all_typevars = False
no_unbound_typevars = True
generic_bases_fully_qualified = False

# Napoleon
napoleon_google_docstring = True
napoleon_numpy_docstring = False
napoleon_attr_annotations = True

# Intersphinx
_POLARS_URL = "https://docs.pola.rs/api/python/stable/"
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "polars": (_POLARS_URL, ("_polars_inv.inv", None)),
    "pandas": ("https://pandas.pydata.org/pandas-docs/stable/", None),
    "ase": ("https://ase-lib.org/", None),
}

autodoc_type_aliases = {
    "Value": "Value",
    "pl.DataFrame": "polars.DataFrame",
    "pl.LazyFrame": "polars.LazyFrame",
    "pl.Expr": "polars.Expr",
}

add_module_names = False
toc_object_entries_show_parents = "hide"
exclude_patterns = ["_build"]
suppress_warnings = ["autodoc.import_object"]
nitpicky = False
