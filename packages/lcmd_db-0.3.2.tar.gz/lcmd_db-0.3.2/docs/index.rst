lcmd-db
=======

Python client for the `LCMD molecular database <https://lcmd-app.epfl.ch>`_.

.. code-block:: python

   from lcmd_db import load_dataset

   data = load_dataset("qm9", include=["molecules", "structures"])
   molecules = data.as_dataset("molecules")
   mol = molecules[0]
   print(mol.id, mol.properties["smiles"], mol.structure_path)

Installation
------------

.. tab-set::

   .. tab-item:: pip

      .. code-block:: bash

         pip install lcmd-db

   .. tab-item:: uv

      .. code-block:: bash

         uv add lcmd-db

.. grid:: 2
   :gutter: 3

   .. grid-item-card:: Quick Start
      :link: quickstart
      :link-type: doc

      Loading datasets, filtering, splitting, and converting to pandas/ASE.

   .. grid-item-card:: API Reference
      :link: api/index
      :link-type: doc

      Full reference for all classes, functions, and types.

.. toctree::
   :maxdepth: 2
   :hidden:

   quickstart
   api/index
