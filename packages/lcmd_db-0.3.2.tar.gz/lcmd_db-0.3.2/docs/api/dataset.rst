Dataset
=======

Base Class
----------

.. autoclass:: lcmd_db.Dataset
   :members: df, lazy, columns, properties, select, filter, train_test_split, to_polars, to_pandas, to_ase
   :special-members: __getitem__, __len__, __iter__

Specialized Datasets
--------------------

.. autoclass:: lcmd_db.MoleculeDataset
   :show-inheritance:
   :exclude-members: __init__

.. autoclass:: lcmd_db.ReactionDataset
   :show-inheritance:
   :exclude-members: __init__

.. autoclass:: lcmd_db.FragmentDataset
   :show-inheritance:
   :exclude-members: __init__
