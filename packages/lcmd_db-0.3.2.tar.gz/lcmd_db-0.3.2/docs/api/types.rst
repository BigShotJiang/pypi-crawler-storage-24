Entry Types
===========

These frozen dataclasses represent the entries returned when iterating over a :class:`~lcmd_db.Dataset`.

Type Parameters
---------------

.. autotypevar:: lcmd_db.types.Properties

   The properties type parameter used by :class:`Molecule`, :class:`Reaction`, and :class:`Fragment`.
   Defaults to ``dict[str, Value]`` for untyped access; narrow with a ``TypedDict`` for full autocomplete.

.. data:: lcmd_db.types.Value
   :type: TypeAlias
   :value: str | int | float | bool | None

   Union of allowed property value types.

Molecule
--------

.. autoclass:: lcmd_db.Molecule
   :members:
   :exclude-members: __init__

.. autoclass:: lcmd_db.Reaction
   :members:
   :exclude-members: __init__

.. autoclass:: lcmd_db.Fragment
   :members:
   :exclude-members: __init__

Participants
------------

.. autoclass:: lcmd_db.Participant
   :members:
   :exclude-members: __init__
   :no-show-inheritance:

.. autoclass:: lcmd_db.ParticipantRole
   :members:
   :undoc-members:
   :exclude-members: __new__

Metadata
--------

.. autoclass:: lcmd_db.SubsetData
   :members:
   :exclude-members: __init__

.. autoclass:: lcmd_db.SubsetMetadata
   :members:
   :exclude-members: __init__, model_config

.. autoclass:: lcmd_db.types.EntityMetadata
   :members:
   :exclude-members: __init__, model_config

.. autoclass:: lcmd_db.PropertyInfo
   :members:
   :exclude-members: __init__, model_config

Enums
-----

.. autoclass:: lcmd_db.DataFormat
   :members:
   :undoc-members:
   :exclude-members: __new__

.. autoclass:: lcmd_db.EntityType
   :members:
   :undoc-members:
   :exclude-members: __new__
