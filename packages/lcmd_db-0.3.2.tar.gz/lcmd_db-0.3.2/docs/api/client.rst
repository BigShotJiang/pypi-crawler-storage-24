Client
======

Loading
-------

.. autofunction:: lcmd_db.load_dataset

.. autofunction:: lcmd_db.clear_cache

Schema
------

.. autofunction:: lcmd_db.schema

Exceptions
----------

.. autoexception:: lcmd_db.LCMDError

.. autoexception:: lcmd_db.DatasetNotFoundError
   :show-inheritance:

.. autoexception:: lcmd_db.DownloadError
   :show-inheritance:

.. autoexception:: lcmd_db.SchemaError
   :show-inheritance:
