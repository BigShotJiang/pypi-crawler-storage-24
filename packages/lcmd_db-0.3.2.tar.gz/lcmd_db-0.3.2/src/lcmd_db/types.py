"""Type definitions for LCMD-DB client."""

from __future__ import annotations

import dataclasses
import sys
from collections.abc import Mapping
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Generic, Literal, TypeAlias, overload

if sys.version_info >= (3, 13):  # noqa: UP036 — TypeVar(default=) needs typing_extensions on <3.13
    from typing import TypeVar
else:
    from typing_extensions import TypeVar  # noqa: UP035

import polars as pl
from pydantic import BaseModel, field_validator

if TYPE_CHECKING:
    from .dataset._base import Dataset
    from .dataset._fragments import FragmentDataset
    from .dataset._molecules import MoleculeDataset
    from .dataset._reactions import ReactionDataset

Value: TypeAlias = str | int | float | bool | None  # noqa: UP040

Properties = TypeVar(
    "Properties",
    bound=Mapping[str, object],
    default=dict[str, Value],
)


class _PropertyAccess:
    """Mixin providing direct attribute access to entity properties.

    Entity dataclasses inherit this to expose ``properties`` values as
    attributes (e.g. ``mol.energy`` instead of ``mol.properties["energy"]``).
    Generated per-subset stubs narrow return types; see ``lcmd-db stubs sync``.
    """

    __slots__ = ()

    def __getattr__(self, name: str) -> Value:
        props: Mapping[str, Value] = object.__getattribute__(self, "properties")
        try:
            return props[name]
        except (KeyError, TypeError):
            raise AttributeError(name) from None

    def __dir__(self) -> list[str]:
        base = list(super().__dir__())
        props = object.__getattribute__(self, "properties")
        if isinstance(props, Mapping):
            base.extend(props.keys())
        return base


class DataFormat(str, Enum):
    CSV = "csv"
    TSV = "tsv"
    XLSX = "xlsx"
    PARQUET = "parquet"
    JSON = "json"


class EntityType(str, Enum):
    MOLECULES = "molecules"
    REACTIONS = "reactions"
    FRAGMENTS = "fragments"


class PropertyDataType(str, Enum):
    FLOAT = "float"
    INTEGER = "integer"
    STRING = "string"
    BOOLEAN = "boolean"


Include = Literal["molecules", "reactions", "fragments", "structures"]

ENTITY_TYPES: tuple[str, ...] = ("molecules", "reactions", "fragments")


class PropertyInfo(BaseModel, frozen=True):
    slug: str
    name: str = ""
    data_type: PropertyDataType = PropertyDataType.STRING
    units: str | None = None
    description: str | None = None
    is_intrinsic: bool = False
    is_required: bool | None = None

    @field_validator("data_type", mode="before")
    @classmethod
    def _coerce_data_type(cls, v: object) -> PropertyDataType:
        if isinstance(v, PropertyDataType):
            return v
        try:
            return PropertyDataType(str(v))
        except ValueError:
            return PropertyDataType.STRING


class EntityMetadata(BaseModel, frozen=True):
    count: int = 0
    columns: int = 0
    properties: list[PropertyInfo] = []


class SubsetMetadata(BaseModel, frozen=True):
    subset: str
    subset_name: str = ""
    data_format: str = ""
    entities: dict[str, EntityMetadata] = {}
    structures_count: int | None = None
    client_version: str | None = None


@dataclasses.dataclass(frozen=True)
class Molecule(_PropertyAccess, Generic[Properties]):
    """A molecule entry with typed properties and optional structure file.

    Properties are accessible both via the ``properties`` dict and as direct
    attributes (e.g. ``mol.energy`` instead of ``mol.properties["energy"]``).
    Per-subset type stubs narrow attribute types; see ``lcmd-db stubs sync``.
    """

    id: int
    properties: Properties
    structure_path: Path | None = None


class ParticipantRole(str, Enum):
    """Role of a molecule participating in a reaction."""

    REACTANT = "reactant"
    PRODUCT = "product"
    CATALYST = "catalyst"
    CO_CATALYST = "co_catalyst"
    SUBSTRATE = "substrate"
    INTERMEDIATE = "intermediate"
    TRANSITION_STATE = "transition_state"
    SOLVENT = "solvent"
    ADDITIVE = "additive"


@dataclasses.dataclass(frozen=True)
class Participant:
    """A molecule's participation in a reaction step.

    Attributes:
        molecule (Molecule[dict[str, Value]]): The participating molecule.
        role (ParticipantRole): Role in the reaction (reactant, product, catalyst, ...).
        step_from (float | None): Starting step index, if applicable.
        step_to (float | None): Ending step index, if applicable.
        label (str): Optional human-readable label.
    """

    molecule: Molecule[dict[str, Value]]
    role: ParticipantRole
    step_from: float | None = None
    step_to: float | None = None
    label: str = ""


@dataclasses.dataclass(frozen=True)
class Reaction(_PropertyAccess, Generic[Properties]):
    """A reaction entry with typed properties and participant molecules.

    Properties are accessible as direct attributes (e.g. ``rxn.barrier``).
    Per-subset type stubs narrow attribute types; see ``lcmd-db stubs sync``.
    """

    id: int
    properties: Properties
    participants: list[Participant] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(frozen=True)
class Fragment(_PropertyAccess, Generic[Properties]):
    """A molecular fragment entry with typed properties.

    Properties are accessible as direct attributes (e.g. ``frag.charge``).
    Per-subset type stubs narrow attribute types; see ``lcmd-db stubs sync``.
    """

    id: int
    properties: Properties
    fragment_type: str | None = None


@dataclasses.dataclass
class SubsetData:
    """Container for data returned by a subset download.

    Holds polars DataFrames for each requested entity type and optional
    metadata. Use ``as_dataset`` to obtain a typed ``Dataset`` for lazy
    iteration, filtering, and conversion.

    Attributes:
        molecules: Molecule DataFrame, if included in the download.
        reactions: Reaction DataFrame, if included in the download.
        fragments: Fragment DataFrame, if included in the download.
        metadata: Subset metadata from the API, if available.
    """

    molecules: pl.DataFrame | None = None
    reactions: pl.DataFrame | None = None
    fragments: pl.DataFrame | None = None
    metadata: SubsetMetadata | None = None
    _data_dir: Path | None = dataclasses.field(default=None, repr=False)
    _data_format: DataFormat = dataclasses.field(default=DataFormat.PARQUET, repr=False)

    @property
    def dataframes(self) -> dict[str, pl.DataFrame]:
        """Return a mapping of entity type names to their non-null DataFrames."""
        return {
            name: df for name in ENTITY_TYPES if (df := getattr(self, name)) is not None
        }

    @overload
    def as_dataset(
        self, entity_type: Literal["molecules"]
    ) -> MoleculeDataset[dict[str, Value]]: ...

    @overload
    def as_dataset(
        self, entity_type: Literal["reactions"]
    ) -> ReactionDataset[dict[str, Value]]: ...

    @overload
    def as_dataset(
        self, entity_type: Literal["fragments"]
    ) -> FragmentDataset[dict[str, Value]]: ...

    def as_dataset(
        self, entity_type: str
    ) -> (
        Dataset[Molecule[dict[str, Value]]]
        | Dataset[Reaction[dict[str, Value]]]
        | Dataset[Fragment[dict[str, Value]]]
    ):
        """Build a typed :class:`~lcmd_db.Dataset` for the given entity type.

        Args:
            entity_type: One of ``"molecules"``, ``"reactions"``, or ``"fragments"``.

        Returns:
            A :class:`MoleculeDataset`, :class:`ReactionDataset`, or
            :class:`FragmentDataset` depending on the entity type.

        Raises:
            ValueError: If no data directory is available or the entity type is unknown.

        Example::

            molecules = data.as_dataset("molecules")   # MoleculeDataset
            reactions = data.as_dataset("reactions")    # ReactionDataset
        """
        from .dataset._factory import build_dataset

        if self._data_dir is None:
            raise ValueError(
                "No data directory available — dataset was not loaded from cache"
            )

        return build_dataset(
            entity_type,
            data_dir=self._data_dir,
            data_format=self._data_format,
            metadata=self.metadata,
        )
