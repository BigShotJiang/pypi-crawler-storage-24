"""Allow ``python -m lcmd_db`` to invoke the CLI."""

from lcmd_db.cli import main

main()
