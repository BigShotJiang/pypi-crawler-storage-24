"""Cache commands — manage the local download cache."""

from __future__ import annotations

import click


@click.group()
def cache() -> None:
    """Manage the local download cache."""


@cache.command()
@click.argument("subset", required=False, default=None)
def clear(subset: str | None) -> None:
    """Clear cached downloads.

    If SUBSET is given, only that subset's cache is cleared.
    Otherwise the entire cache is wiped.

    \b
    Examples:
        lcmd-db cache clear
        lcmd-db cache clear qm9
    """
    from ..client import clear_cache

    clear_cache(subset)
    click.echo(f"Cleared cache for {repr(subset) if subset else 'all'}")


@cache.command(name="dir")
def show_dir() -> None:
    """Show the cache directory path."""
    from .._cache import DownloadCache

    click.echo(DownloadCache().cache_dir)


@cache.command(name="list")
def list_cached() -> None:
    """List cached datasets with their entity types and property counts."""
    from .._cache import DownloadCache
    from .._schema_store import SchemaStore

    schemas = SchemaStore(DownloadCache()).load_all()

    if not schemas:
        click.echo("No cached datasets")
        return

    for slug, entities in sorted(schemas.items()):
        parts = [f"{et} ({len(props)} props)" for et, props in sorted(entities.items())]
        click.echo(f"  {slug}: {', '.join(parts)}")
