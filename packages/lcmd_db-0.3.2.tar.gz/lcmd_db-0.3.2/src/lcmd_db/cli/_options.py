"""Shared Click options and types derived from enums."""

from __future__ import annotations

from typing import TYPE_CHECKING

import click

from ..types import DataFormat, EntityType

if TYPE_CHECKING:
    from ..types import PropertyInfo

ENTITY_TYPE_CHOICE = click.Choice([e.value for e in EntityType])
DATA_FORMAT_CHOICE = click.Choice([f.value for f in DataFormat])
INCLUDE_CHOICE = click.Choice([e.value for e in EntityType] + ["structures"])

subset_argument = click.argument("subset")

entity_type_option = click.option(
    "--entity-type",
    type=ENTITY_TYPE_CHOICE,
    default=EntityType.MOLECULES.value,
    help="Entity type.",
)

entity_types_option = click.option(
    "--entity-types",
    multiple=True,
    type=ENTITY_TYPE_CHOICE,
    help="Entity types to include (default: all available).",
)

include_option = click.option(
    "--include",
    multiple=True,
    type=INCLUDE_CHOICE,
    default=(EntityType.MOLECULES.value,),
    help="Entity types to include.",
)

data_format_option = click.option(
    "-f",
    "--format",
    "data_format",
    type=DATA_FORMAT_CHOICE,
    default=DataFormat.PARQUET.value,
    help="Data format.",
)

force_option = click.option(
    "--force", is_flag=True, help="Force re-download even if cached."
)


def resolve_entity_types(entity_types: tuple[str, ...]) -> list[EntityType]:
    return [EntityType(t) for t in entity_types] if entity_types else list(EntityType)


def fetch_all_schemas(
    subset: str,
    entity_types: list[EntityType],
) -> dict[str, list[PropertyInfo]]:
    from .._schema import schema

    return {et.value: props for et in entity_types if (props := schema(subset, et))}
