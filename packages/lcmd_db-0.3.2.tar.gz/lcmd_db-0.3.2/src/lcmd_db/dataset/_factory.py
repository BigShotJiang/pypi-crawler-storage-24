"""Registry-based factory for building typed Dataset instances."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import TypeAlias

from ..types import DataFormat, EntityMetadata, SubsetMetadata
from ._base import Dataset
from ._source import DataSource, source_for_entity

Builder: TypeAlias = Callable[  # noqa: UP040
    [DataSource, EntityMetadata | None, "_Context"], "Dataset[object]"
]


class _Context:
    """Holds resolved data sources for cross-entity lookups (e.g. reactions -> molecules)."""

    def __init__(self, data_dir: Path, fmt: DataFormat) -> None:
        self.data_dir = data_dir
        self.fmt = fmt
        self._cache: dict[str, DataSource | None] = {}

    def source(self, entity: str) -> DataSource | None:
        if entity not in self._cache:
            self._cache[entity] = source_for_entity(self.data_dir, entity, self.fmt)
        return self._cache[entity]

    @property
    def structures_dir(self) -> Path:
        return self.data_dir / "structures"


def _build_molecules(
    src: DataSource, meta: EntityMetadata | None, ctx: _Context
) -> Dataset[object]:
    from ._molecules import MoleculeDataset

    return MoleculeDataset(src, structures_dir=ctx.structures_dir, metadata=meta)


def _build_reactions(
    src: DataSource, meta: EntityMetadata | None, ctx: _Context
) -> Dataset[object]:
    from ._reactions import ReactionDataset

    return ReactionDataset(
        src,
        participants_source=ctx.source("reaction_participants"),
        molecules_source=ctx.source("molecules"),
        structures_dir=ctx.structures_dir,
        metadata=meta,
    )


def _build_fragments(
    src: DataSource, meta: EntityMetadata | None, ctx: _Context
) -> Dataset[object]:
    from ._fragments import FragmentDataset

    return FragmentDataset(src, metadata=meta)


_BUILDERS: dict[str, Builder] = {
    "molecules": _build_molecules,
    "reactions": _build_reactions,
    "fragments": _build_fragments,
}


def build_dataset(
    entity_type: str,
    *,
    data_dir: Path,
    data_format: DataFormat,
    metadata: SubsetMetadata | None,
) -> Dataset[object]:
    builder = _BUILDERS.get(entity_type)
    if builder is None:
        raise ValueError(f"Unknown entity type: {entity_type}")

    ctx = _Context(data_dir, data_format)
    src = ctx.source(entity_type)
    if src is None:
        raise ValueError(f"No {entity_type} data found")

    entity_meta = metadata.entities.get(entity_type) if metadata else None
    return builder(src, entity_meta, ctx)
