"""FragmentDataset — one row per Fragment entry."""

from __future__ import annotations

from typing import Generic

from ..types import EntityMetadata, Fragment, Properties
from ._base import Dataset, _extract_properties
from ._source import DataSource

_FRAGMENT_EXCLUDE: frozenset[str] = frozenset(("id", "fragment_type_slug"))


class FragmentDataset(Dataset[Fragment[Properties]], Generic[Properties]):
    def __init__(
        self,
        source: DataSource,
        *,
        metadata: EntityMetadata | None = None,
    ) -> None:
        super().__init__(source, metadata=metadata)

    def _resolve_entry(self, row: dict[str, object]) -> Fragment[Properties]:
        return Fragment(
            id=int(row["id"]),  # type: ignore[arg-type]
            properties=_extract_properties(row, _FRAGMENT_EXCLUDE),  # type: ignore[arg-type]
            fragment_type=row.get("fragment_type_slug"),  # type: ignore[arg-type]
        )

    def _with_source(self, source: DataSource) -> FragmentDataset[Properties]:
        return FragmentDataset(source, metadata=self._metadata)
