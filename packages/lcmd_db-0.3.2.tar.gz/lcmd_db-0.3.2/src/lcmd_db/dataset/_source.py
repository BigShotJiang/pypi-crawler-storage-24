"""DataSource abstraction for lazy and eager data loading."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Protocol, runtime_checkable

import polars as pl

from ..types import DataFormat


@runtime_checkable
class DataSource(Protocol):
    @property
    def lazy(self) -> pl.LazyFrame: ...

    def collect(self) -> pl.DataFrame: ...

    @property
    def columns(self) -> list[str]: ...


class LazySource:
    """Truly lazy — defers I/O until collect(). Works for parquet, CSV, TSV, NDJSON."""

    def __init__(self, lf: pl.LazyFrame) -> None:
        self._lf = lf

    @property
    def lazy(self) -> pl.LazyFrame:
        return self._lf

    def collect(self) -> pl.DataFrame:
        return self._lf.collect()

    @property
    def columns(self) -> list[str]:
        return self._lf.collect_schema().names()


class EagerSource:
    """For formats without lazy support (JSON, XLSX). Reads once, wraps in .lazy()."""

    def __init__(self, df: pl.DataFrame) -> None:
        self._df = df

    @property
    def lazy(self) -> pl.LazyFrame:
        return self._df.lazy()

    def collect(self) -> pl.DataFrame:
        return self._df

    @property
    def columns(self) -> list[str]:
        return self._df.columns


_LAZY_SCANNERS: dict[str, Callable[[Path], pl.LazyFrame]] = {
    "parquet": pl.scan_parquet,
    "csv": pl.scan_csv,
    "tsv": lambda p: pl.scan_csv(p, separator="\t"),
    "ndjson": pl.scan_ndjson,
}

_EAGER_READERS: dict[str, Callable[[Path], pl.DataFrame]] = {
    "json": pl.read_json,
    "xlsx": pl.read_excel,
}


def source_for(path: Path) -> DataSource:
    """Factory: lazy when possible (parquet/csv/tsv/ndjson), eager otherwise (json/xlsx)."""
    ext = path.suffix.lstrip(".")
    if scanner := _LAZY_SCANNERS.get(ext):
        return LazySource(scanner(path))
    if reader := _EAGER_READERS.get(ext):
        return EagerSource(reader(path))
    raise ValueError(f"Unsupported format: {ext}")


def source_for_entity(
    data_dir: Path, entity: str, data_format: DataFormat
) -> DataSource | None:
    """Resolve entity file in a cache directory and return its DataSource, or None if missing."""
    path = data_dir / f"{entity}.{data_format.value}"
    return source_for(path) if path.exists() else None
