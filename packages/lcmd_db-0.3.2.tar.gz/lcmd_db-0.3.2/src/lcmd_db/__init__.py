"""LCMD-DB - Python client for the LCMD molecular database."""

import logging
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("lcmd-db")
except PackageNotFoundError:
    __version__ = "0.0.0"

from ._overloads import load_dataset
from ._schema import schema
from .client import clear_cache
from .dataset import (
    Dataset,
    FragmentDataset,
    MoleculeDataset,
    ReactionDataset,
)
from .exceptions import DatasetNotFoundError, DownloadError, LCMDError, SchemaError
from .settings import settings
from .types import (
    DataFormat,
    EntityType,
    Fragment,
    Include,
    Molecule,
    Participant,
    ParticipantRole,
    PropertyDataType,
    PropertyInfo,
    Reaction,
    SubsetData,
    SubsetMetadata,
    Value,
)

__all__ = [
    "__version__",
    "load_dataset",
    "clear_cache",
    "schema",
    "settings",
    "DataFormat",
    "Dataset",
    "EntityType",
    "Fragment",
    "FragmentDataset",
    "Include",
    "Molecule",
    "MoleculeDataset",
    "Participant",
    "ParticipantRole",
    "PropertyDataType",
    "PropertyInfo",
    "Reaction",
    "ReactionDataset",
    "SubsetData",
    "SubsetMetadata",
    "Value",
    "LCMDError",
    "DatasetNotFoundError",
    "DownloadError",
    "SchemaError",
]

# Auto-sync stubs on import (fast no-op if marker matches)
if settings.auto_sync_stubs:
    try:
        from ._sync import sync_stubs

        sync_stubs()
    except Exception:
        logging.getLogger(__name__).warning(
            "Auto stub sync failed — run 'lcmd-db stubs sync' manually for typed properties",
            exc_info=True,
        )
