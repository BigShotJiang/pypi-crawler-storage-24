"""Code generation from property schemas using Jinja2 templates."""

from __future__ import annotations

import importlib.metadata
import logging
import re
import unicodedata
from collections.abc import Sequence
from pathlib import Path

import jinja2

from .types import ENTITY_TYPES, PropertyDataType, PropertyInfo

DATASET_CLASSES: dict[str, str] = {
    "molecules": "MoleculeDataset",
    "reactions": "ReactionDataset",
    "fragments": "FragmentDataset",
}

logger = logging.getLogger(__name__)

_TEMPLATES_DIR = Path(__file__).parent / "templates"

_LOOKUPS_BY_TYPE: dict[PropertyDataType, list[tuple[str, str]]] = {
    PropertyDataType.FLOAT: [("__gte", "float"), ("__lte", "float")],
    PropertyDataType.INTEGER: [("__gte", "int"), ("__lte", "int")],
    PropertyDataType.STRING: [
        ("__exact", "str"),
        ("__in", "str"),
        ("__icontains", "str"),
    ],
    PropertyDataType.BOOLEAN: [("__exact", "bool")],
}


_PYTHON_TYPES: dict[PropertyDataType, str] = {
    PropertyDataType.FLOAT: "float",
    PropertyDataType.INTEGER: "int",
    PropertyDataType.STRING: "str",
    PropertyDataType.BOOLEAN: "bool",
}


def _make_env() -> jinja2.Environment:
    env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(str(_TEMPLATES_DIR)),
        keep_trailing_newline=True,
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["identifier"] = _filter_identifier
    env.filters["literal_list"] = _filter_literal_list
    env.filters["to_class_name"] = _filter_to_class_name
    env.filters["singularize"] = _filter_singularize
    env.filters["filter_lookup_fields"] = _filter_lookup_fields
    env.filters["python_type"] = _filter_python_type
    env.filters["typed"] = _filter_typed
    env.filters["dataset_class"] = _filter_dataset_class
    return env


def _filter_identifier(slug: str) -> str:
    """Sanitize a property slug into a valid Python identifier.

    Mirrors the backend ``core.lib.text.slugify``: lowercase,
    replace non-alphanumeric sequences with underscores, strip edges.
    """
    text = unicodedata.normalize("NFKD", slug).encode("ascii", "ignore").decode("ascii")
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    text = text.strip("_")
    return text or "unnamed"


def _filter_literal_list(values: object) -> str:
    items = list(values)  # type: ignore[arg-type]
    slugs = [
        _filter_identifier(p.slug) if isinstance(p, PropertyInfo) else str(p)
        for p in items
    ]
    return ", ".join(f'"{s}"' for s in sorted(slugs))


def _filter_to_class_name(entity_type: str) -> str:
    return _filter_singularize(entity_type).capitalize()


def _filter_singularize(word: str) -> str:
    return word.rstrip("s") if word.endswith("s") else word


def _filter_lookup_fields(
    props: Sequence[PropertyInfo],
) -> list[tuple[str, str]]:
    return [
        (f"{prop.slug}{suffix}", py_type)
        for prop in sorted(props, key=lambda p: p.slug)
        for suffix, py_type in _LOOKUPS_BY_TYPE.get(prop.data_type, [])
    ]


def _filter_typed(prop: PropertyInfo) -> str:
    """Return the Python type annotation, adding ``| None`` for optional properties."""
    base = _PYTHON_TYPES.get(prop.data_type, "str")
    if prop.is_required:
        return base
    return f"{base} | None"


def _filter_dataset_class(entity_type: str) -> str:
    cls = DATASET_CLASSES.get(entity_type)
    if cls is None:
        raise ValueError(f"Unknown entity type: {entity_type}")
    return cls


def _filter_python_type(data_type: str | PropertyDataType) -> str:
    if isinstance(data_type, str):
        try:
            data_type = PropertyDataType(data_type)
        except ValueError:
            return "str"
    return _PYTHON_TYPES.get(data_type, "str")


def _client_version() -> str:
    try:
        return importlib.metadata.version("lcmd-db")
    except importlib.metadata.PackageNotFoundError:
        return "0.0.0"


def generate_overloads(
    schemas: dict[str, dict[str, list[PropertyInfo]]],
    marker: str,
) -> str:
    """Generate the ``_overloads.py`` module source."""
    env = _make_env()
    template = env.get_template("overloads.py.j2")

    subsets: dict[str, dict[str, list[str]]] = {
        slug: {
            et: sorted(p.slug for p in props) for et, props in sorted(entities.items())
        }
        for slug, entities in sorted(schemas.items())
    }

    source = template.render(
        marker=marker,
        version=_client_version(),
        subsets=subsets,
        entity_types=list(ENTITY_TYPES),
    )

    compile(source, "<generated:_overloads.py>", "exec")
    return source


def generate_typed_module(
    subset: str,
    schemas: dict[str, list[PropertyInfo]],
) -> str:
    """Generate a standalone typed module for a single dataset.

    Raises ValueError if *schemas* has no entity types with properties.
    """
    if not schemas:
        raise ValueError(f"No properties found for subset '{subset}'")
    env = _make_env()
    template = env.get_template("typed_module.py.j2")

    source = template.render(
        subset_slug=subset,
        entities={et: props for et, props in sorted(schemas.items()) if props},
    )

    compile(source, f"<generated:{subset}.py>", "exec")
    return source
