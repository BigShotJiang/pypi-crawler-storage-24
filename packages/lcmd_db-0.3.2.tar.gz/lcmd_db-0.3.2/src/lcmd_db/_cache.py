"""Param-aware download cache using pooch."""

from __future__ import annotations

import hashlib
import json
import logging
import shutil
from collections.abc import Iterator, Sequence
from pathlib import Path

import platformdirs
import pooch

from .settings import settings

logger = logging.getLogger(__name__)


def _default_cache_dir() -> Path:
    if settings.cache_dir is not None:
        return Path(settings.cache_dir)
    return Path(platformdirs.user_cache_dir("lcmd-db")) / "client"


class DownloadCache:
    """Manages cached dataset downloads.

    Each unique combination of download parameters produces a separate
    cache entry keyed by a content hash.
    """

    def __init__(self, cache_dir: Path | None = None) -> None:
        self.cache_dir = cache_dir or _default_cache_dir()

    def get_or_download(
        self,
        url: str,
        subset: str,
        cache_key: str,
        *,
        force: bool = False,
    ) -> Path:
        """Return the extracted download directory, downloading if needed."""
        extract_dir = self._extract_dir(subset, cache_key)
        zip_path = self._zip_path(subset, cache_key)

        if force:
            self._remove(extract_dir, zip_path)

        if extract_dir.exists():
            return extract_dir

        self.cache_dir.mkdir(parents=True, exist_ok=True)

        try:
            downloader = pooch.HTTPDownloader(
                progressbar=True, timeout=settings.timeout
            )
            pooch.retrieve(
                url,
                known_hash=None,
                fname=zip_path.name,
                path=str(self.cache_dir),
                downloader=downloader,
                processor=pooch.Unzip(extract_dir=f"{subset}_{cache_key}"),
            )
        except Exception:
            self._remove(extract_dir, zip_path)
            raise

        if not extract_dir.exists():
            raise FileNotFoundError(
                f"ZIP extraction produced no directory for subset '{subset}'"
            )
        return extract_dir

    def clear(self, subset: str | None = None) -> None:
        """Remove cached downloads (all or for a specific subset)."""
        if not self.cache_dir.exists():
            return
        if subset is None:
            shutil.rmtree(self.cache_dir)
            return
        for item in self.cache_dir.iterdir():
            if item.name.startswith(f"{subset}_"):
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()

    def iter_extracted_dirs(self) -> Iterator[Path]:
        """Yield extracted directories that contain a ``metadata.json``."""
        if not self.cache_dir.exists():
            return
        for item in sorted(self.cache_dir.iterdir()):
            if item.is_dir() and (item / "metadata.json").exists():
                yield item

    @staticmethod
    def compute_cache_key(
        subset: str,
        include: Sequence[str],
        data_format: str,
        molecule_properties: Sequence[str] | None = None,
        reaction_properties: Sequence[str] | None = None,
        fragment_properties: Sequence[str] | None = None,
    ) -> str:
        """Deterministic 16-char hex hash from all download parameters."""
        canonical = json.dumps(
            {
                "subset": subset,
                "include": sorted(include),
                "data_format": data_format,
                "molecule_properties": sorted(molecule_properties)
                if molecule_properties
                else None,
                "reaction_properties": sorted(reaction_properties)
                if reaction_properties
                else None,
                "fragment_properties": sorted(fragment_properties)
                if fragment_properties
                else None,
            },
            sort_keys=True,
        )
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    def _extract_dir(self, subset: str, cache_key: str) -> Path:
        return self.cache_dir / f"{subset}_{cache_key}"

    def _zip_path(self, subset: str, cache_key: str) -> Path:
        return self.cache_dir / f"{subset}_{cache_key}.zip"

    @staticmethod
    def _remove(extract_dir: Path, zip_path: Path) -> None:
        if extract_dir.exists():
            shutil.rmtree(extract_dir)
        if zip_path.exists():
            zip_path.unlink()
