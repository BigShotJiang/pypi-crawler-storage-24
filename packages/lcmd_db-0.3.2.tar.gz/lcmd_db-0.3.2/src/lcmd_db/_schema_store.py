"""Aggregates property schemas from cached metadata.json files for codegen."""

from __future__ import annotations

import hashlib
import json

from ._cache import DownloadCache
from .types import ENTITY_TYPES, PropertyInfo, SubsetMetadata


class SchemaStore:
    """Read-only view over cached ``metadata.json`` files.

    The download cache is the sole source of truth.
    """

    def __init__(self, cache: DownloadCache) -> None:
        self._cache = cache

    def load_all(self) -> dict[str, dict[str, list[PropertyInfo]]]:
        """Return ``{subset_slug: {entity_type: [PropertyInfo, ...]}}``
        aggregated across all cached downloads.
        """
        result: dict[str, dict[str, list[PropertyInfo]]] = {}

        for meta in self._iter_metadata():
            if not meta.subset:
                continue

            if meta.subset not in result:
                result[meta.subset] = {}

            for entity_type in ENTITY_TYPES:
                entity = meta.entities.get(entity_type)
                if entity is None or not entity.properties:
                    continue

                existing = result[meta.subset].get(entity_type, [])
                result[meta.subset][entity_type] = _union_properties(
                    existing, entity.properties
                )

        return result

    def content_hash(self) -> str:
        schemas = self.load_all()
        canonical = json.dumps(
            {
                slug: {
                    et: sorted(p.slug for p in props)
                    for et, props in sorted(entities.items())
                }
                for slug, entities in sorted(schemas.items())
            },
            sort_keys=True,
        )
        return hashlib.sha256(canonical.encode()).hexdigest()[:12]

    def _iter_metadata(self) -> list[SubsetMetadata]:
        return [
            SubsetMetadata.model_validate(
                json.loads((d / "metadata.json").read_bytes())
            )
            for d in self._cache.iter_extracted_dirs()
        ]


def _union_properties(
    existing: list[PropertyInfo],
    new: list[PropertyInfo],
) -> list[PropertyInfo]:
    seen = {p.slug for p in existing}
    return existing + [p for p in new if p.slug not in seen]
