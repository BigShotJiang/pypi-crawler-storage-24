"""Centralized configuration via ``LCMD_DB_`` environment variables or direct assignment."""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="LCMD_DB_")

    base_url: str = "https://lcmd-app.epfl.ch"
    timeout: int = 300
    cache_dir: str | None = None
    auto_sync_stubs: bool = True


settings = Settings()
