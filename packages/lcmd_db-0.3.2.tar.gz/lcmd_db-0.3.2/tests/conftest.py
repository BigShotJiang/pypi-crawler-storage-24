from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path

import polars as pl
import pytest
from lcmd_db._cache import DownloadCache

SAMPLE_PROPERTIES = [
    {
        "slug": "molecular_weight",
        "name": "Molecular Weight",
        "data_type": "float",
        "units": "g/mol",
        "is_intrinsic": True,
    },
    {"slug": "smiles", "name": "SMILES", "data_type": "string", "is_intrinsic": True},
    {"slug": "energy", "name": "Energy", "data_type": "float", "units": "Ha"},
    {"slug": "converged", "name": "Converged", "data_type": "boolean"},
]


SubsetFactory = Callable[..., Path]


@pytest.fixture(scope="session")
def session_cache_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    return tmp_path_factory.mktemp("lcmd_cache")


@pytest.fixture(scope="session")
def cache(session_cache_dir: Path) -> DownloadCache:
    return DownloadCache(session_cache_dir)


@pytest.fixture(scope="session")
def subset_factory(cache: DownloadCache) -> SubsetFactory:
    def factory(
        subset: str,
        *,
        cache_key: str = "abc123",
        properties: list[dict[str, object]] | None = None,
        entity_type: str = "molecules",
        rows: pl.DataFrame | None = None,
        data_format: str = "parquet",
    ) -> Path:
        extract_dir = cache.cache_dir / f"{subset}_{cache_key}"
        extract_dir.mkdir(parents=True, exist_ok=True)

        props = properties if properties is not None else SAMPLE_PROPERTIES
        metadata = {
            "subset": subset,
            "subset_name": subset.upper(),
            "data_format": data_format,
            "entities": {
                entity_type: {
                    "count": rows.height if rows is not None else 3,
                    "columns": len(props),
                    "properties": props,
                }
            },
        }
        (extract_dir / "metadata.json").write_text(json.dumps(metadata))

        if rows is not None:
            rows.write_parquet(extract_dir / f"{entity_type}.{data_format}")

        return extract_dir

    return factory


@pytest.fixture(scope="session")
def sample_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "id": [1, 2, 3],
            "molecular_weight": [18.015, 44.01, 28.014],
            "smiles": ["O", "O=C=O", "N#N"],
            "energy": [-76.0, -188.0, -109.0],
            "converged": [True, True, False],
        }
    )


@pytest.fixture(scope="session", autouse=True)
def _seed_cache(subset_factory: SubsetFactory, sample_df: pl.DataFrame) -> None:
    subset_factory("test_subset", rows=sample_df)
