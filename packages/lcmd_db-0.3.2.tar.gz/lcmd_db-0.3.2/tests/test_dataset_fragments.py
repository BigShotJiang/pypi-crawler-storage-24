from __future__ import annotations

import polars as pl
from lcmd_db.dataset._fragments import FragmentDataset
from lcmd_db.dataset._source import EagerSource
from lcmd_db.types import Fragment


def _make_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "id": [1, 2, 3],
            "smiles": ["[*]C", "[*]CC", "[*]O"],
            "fragment_type_slug": ["core", "substituent", None],
        }
    )


class TestEntryResolution:
    def test_entry_is_fragment(self) -> None:
        ds = FragmentDataset(EagerSource(_make_df()))
        assert isinstance(ds[0], Fragment)

    def test_fragment_type_extracted(self) -> None:
        ds = FragmentDataset(EagerSource(_make_df()))
        assert ds[0].fragment_type == "core"
        assert ds[1].fragment_type == "substituent"
        assert ds[2].fragment_type is None

    def test_fragment_type_slug_excluded_from_properties(self) -> None:
        ds = FragmentDataset(EagerSource(_make_df()))
        frag = ds[0]
        assert "fragment_type_slug" not in frag.properties
        assert frag.properties["smiles"] == "[*]C"

    def test_id_excluded_from_properties(self) -> None:
        ds = FragmentDataset(EagerSource(_make_df()))
        assert "id" not in ds[0].properties


class TestWithoutTypeColumn:
    def test_works_without_fragment_type_slug(self) -> None:
        df = pl.DataFrame({"id": [1], "smiles": ["[*]C"]})
        ds = FragmentDataset(EagerSource(df))
        frag = ds[0]
        assert frag.fragment_type is None
        assert frag.properties["smiles"] == "[*]C"
