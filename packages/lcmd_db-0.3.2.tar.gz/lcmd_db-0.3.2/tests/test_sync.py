from __future__ import annotations

from lcmd_db._cache import DownloadCache
from lcmd_db._sync import _read_current_marker, sync_stubs


class TestSyncStubs:
    def test_regenerates_with_schemas(self, cache: DownloadCache) -> None:
        assert sync_stubs(cache, force=True) is True

    def test_idempotent(self, cache: DownloadCache) -> None:
        sync_stubs(cache, force=True)
        marker = _read_current_marker()
        assert sync_stubs(cache) is False
        assert _read_current_marker() == marker

    def test_force_always_regenerates(self, cache: DownloadCache) -> None:
        sync_stubs(cache, force=True)
        assert sync_stubs(cache, force=True) is True

    def test_no_schemas_skips(self, tmp_path) -> None:
        empty = DownloadCache(tmp_path / "empty")
        assert sync_stubs(empty) is False


class TestReadCurrentMarker:
    def test_returns_string(self) -> None:
        assert isinstance(_read_current_marker(), str)
