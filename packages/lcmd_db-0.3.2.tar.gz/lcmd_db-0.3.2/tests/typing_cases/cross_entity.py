"""Multiple entity types from the same generated stub coexist correctly."""

from typing import assert_type

from lcmd_db.subsets._typing_test import (
    Fragment,
    FragmentDataset,
    Molecule,
    MoleculeDataset,
    Reaction,
    ReactionDataset,
)


def check_all_entities(mol: Molecule, rxn: Reaction, frag: Fragment) -> None:
    assert_type(mol.energy, float)
    assert_type(rxn.barrier, float)
    assert_type(frag.charge, float)


def check_all_datasets(
    mol_ds: MoleculeDataset,
    rxn_ds: ReactionDataset,
    frag_ds: FragmentDataset,
) -> None:
    assert_type(mol_ds[0], Molecule)
    assert_type(rxn_ds[0], Reaction)
    assert_type(frag_ds[0], Fragment)
