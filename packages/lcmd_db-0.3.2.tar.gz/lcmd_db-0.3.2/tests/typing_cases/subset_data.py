"""SubsetData.as_dataset overload narrowing and generated load() return type."""

from typing import assert_type

from lcmd_db.dataset import FragmentDataset, MoleculeDataset, ReactionDataset
from lcmd_db.subsets._typing_test import load
from lcmd_db.types import SubsetData, Value


def check_as_dataset(data: SubsetData) -> None:
    assert_type(data.as_dataset("molecules"), MoleculeDataset[dict[str, Value]])
    assert_type(data.as_dataset("reactions"), ReactionDataset[dict[str, Value]])
    assert_type(data.as_dataset("fragments"), FragmentDataset[dict[str, Value]])


def check_load_return_type() -> None:
    result = load()
    assert_type(result, SubsetData)
