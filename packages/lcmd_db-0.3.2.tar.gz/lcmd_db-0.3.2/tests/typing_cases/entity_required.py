"""Required properties return the bare type; optional properties return type | None."""

from typing import assert_type

from lcmd_db.subsets._typing_test import Fragment, Molecule, Reaction


def check_molecule_required(mol: Molecule) -> None:
    assert_type(mol.energy, float)
    assert_type(mol.smiles, str)


def check_molecule_optional(mol: Molecule) -> None:
    assert_type(mol.dipole, float | None)


def check_reaction_required(rxn: Reaction) -> None:
    assert_type(rxn.barrier, float)


def check_reaction_optional(rxn: Reaction) -> None:
    assert_type(rxn.yield_pct, float | None)


def check_fragment_required(frag: Fragment) -> None:
    assert_type(frag.charge, float)


def check_fragment_optional(frag: Fragment) -> None:
    assert_type(frag.weight, float | None)
