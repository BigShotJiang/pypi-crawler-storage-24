"""to_polars returns the correct DataFrame type."""

from typing import assert_type

import polars as pl
from lcmd_db.subsets._typing_test import MoleculeDataset


def check_to_polars(ds: MoleculeDataset) -> None:
    assert_type(ds.to_polars(), pl.DataFrame)
