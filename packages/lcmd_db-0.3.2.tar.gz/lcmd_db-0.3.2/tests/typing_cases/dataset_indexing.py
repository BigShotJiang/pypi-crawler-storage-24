"""Dataset __getitem__: int → entity, slice/list → Dataset."""

from typing import assert_type

from lcmd_db.dataset import (
    Dataset,
    FragmentDataset,
    MoleculeDataset,
    ReactionDataset,
)
from lcmd_db.subsets._typing_test import (
    Fragment,
    FragmentProps,
    Molecule,
    MoleculeProps,
    Reaction,
    ReactionProps,
)
from lcmd_db.subsets._typing_test import (
    FragmentDataset as TypedFragmentDataset,
)
from lcmd_db.subsets._typing_test import (
    MoleculeDataset as TypedMoleculeDataset,
)
from lcmd_db.subsets._typing_test import (
    ReactionDataset as TypedReactionDataset,
)
from lcmd_db.types import (
    Fragment as BaseFragment,
)
from lcmd_db.types import (
    Molecule as BaseMolecule,
)
from lcmd_db.types import (
    Reaction as BaseReaction,
)


def check_int_index(
    mol_ds: TypedMoleculeDataset,
    rxn_ds: TypedReactionDataset,
    frag_ds: TypedFragmentDataset,
) -> None:
    assert_type(mol_ds[0], Molecule)
    assert_type(mol_ds[0].energy, float)
    assert_type(mol_ds[0].properties, MoleculeProps)
    assert_type(rxn_ds[0], Reaction)
    assert_type(frag_ds[0], Fragment)


def check_slice_index(
    mol_ds: MoleculeDataset[MoleculeProps],
    rxn_ds: ReactionDataset[ReactionProps],
    frag_ds: FragmentDataset[FragmentProps],
) -> None:
    assert_type(mol_ds[0:5], Dataset[BaseMolecule[MoleculeProps]])
    assert_type(rxn_ds[0:5], Dataset[BaseReaction[ReactionProps]])
    assert_type(frag_ds[0:5], Dataset[BaseFragment[FragmentProps]])


def check_list_index(mol_ds: MoleculeDataset[MoleculeProps]) -> None:
    assert_type(mol_ds[[1, 2, 3]], Dataset[BaseMolecule[MoleculeProps]])
