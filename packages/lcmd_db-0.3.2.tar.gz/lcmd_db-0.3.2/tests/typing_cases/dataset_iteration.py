"""Iterating over a dataset yields typed entities."""

from typing import assert_type

from lcmd_db.subsets._typing_test import (
    FragmentDataset,
    FragmentProps,
    MoleculeDataset,
    MoleculeProps,
    ReactionDataset,
    ReactionProps,
)
from lcmd_db.types import (
    Fragment as BaseFragment,
)
from lcmd_db.types import (
    Molecule as BaseMolecule,
)
from lcmd_db.types import (
    Reaction as BaseReaction,
)


def check_iteration(
    mol_ds: MoleculeDataset,
    rxn_ds: ReactionDataset,
    frag_ds: FragmentDataset,
) -> None:
    assert_type(next(iter(mol_ds)), BaseMolecule[MoleculeProps])
    assert_type(next(iter(rxn_ds)), BaseReaction[ReactionProps])
    assert_type(next(iter(frag_ds)), BaseFragment[FragmentProps])
