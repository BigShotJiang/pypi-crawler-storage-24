"""filter, select, and train_test_split preserve the entity type parameter."""

from typing import assert_type

import polars as pl
from lcmd_db.dataset import Dataset
from lcmd_db.subsets._typing_test import (
    FragmentDataset,
    FragmentProps,
    MoleculeDataset,
    MoleculeProps,
    ReactionDataset,
    ReactionProps,
)
from lcmd_db.types import (
    Fragment as BaseFragment,
)
from lcmd_db.types import (
    Molecule as BaseMolecule,
)
from lcmd_db.types import (
    Reaction as BaseReaction,
)


def check_filter(
    mol_ds: MoleculeDataset,
    rxn_ds: ReactionDataset,
    frag_ds: FragmentDataset,
) -> None:
    assert_type(
        mol_ds.filter(pl.col("energy") > 0), Dataset[BaseMolecule[MoleculeProps]]
    )
    assert_type(
        rxn_ds.filter(pl.col("barrier") > 0), Dataset[BaseReaction[ReactionProps]]
    )
    assert_type(
        frag_ds.filter(pl.col("charge") > 0), Dataset[BaseFragment[FragmentProps]]
    )


def check_select(mol_ds: MoleculeDataset) -> None:
    assert_type(mol_ds.select("energy"), Dataset[BaseMolecule[MoleculeProps]])


def check_train_test_split(mol_ds: MoleculeDataset) -> None:
    train, test = mol_ds.train_test_split()
    assert_type(train, Dataset[BaseMolecule[MoleculeProps]])
    assert_type(test, Dataset[BaseMolecule[MoleculeProps]])
