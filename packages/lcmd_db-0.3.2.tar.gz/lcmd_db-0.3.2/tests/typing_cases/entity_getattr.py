"""Typed __getattr__ overloads narrow return types for all entity × property type combos."""

from typing import assert_type

from lcmd_db.subsets._typing_test import Fragment, Molecule, Reaction
from lcmd_db.types import Value


def check_molecule(mol: Molecule) -> None:
    assert_type(mol.energy, float)
    assert_type(mol.atom_count, int)
    assert_type(mol.smiles, str)
    assert_type(mol.converged, bool)


def check_reaction(rxn: Reaction) -> None:
    assert_type(rxn.barrier, float)
    assert_type(rxn.step_count, int)
    assert_type(rxn.mechanism, str)
    assert_type(rxn.reversible, bool)


def check_fragment(frag: Fragment) -> None:
    assert_type(frag.charge, float)
    assert_type(frag.size, int)
    assert_type(frag.name, str)
    assert_type(frag.aromatic, bool)


def check_unknown_attr_fallback(mol: Molecule, rxn: Reaction, frag: Fragment) -> None:
    assert_type(mol.unknown_field, Value)
    assert_type(rxn.unknown_field, Value)
    assert_type(frag.unknown_field, Value)
