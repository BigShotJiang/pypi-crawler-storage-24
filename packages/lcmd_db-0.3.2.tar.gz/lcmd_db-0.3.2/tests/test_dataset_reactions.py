from __future__ import annotations

import polars as pl
import pytest
from lcmd_db.dataset._reactions import ReactionDataset
from lcmd_db.dataset._source import EagerSource
from lcmd_db.types import Molecule, ParticipantRole, Reaction


@pytest.fixture()
def rxn_df() -> pl.DataFrame:
    return pl.DataFrame({"id": [10, 20], "barrier": [0.5, 1.2]})


@pytest.fixture()
def mol_df() -> pl.DataFrame:
    return pl.DataFrame({"id": [1, 2, 3, 4], "smiles": ["A", "B", "C", "D"]})


@pytest.fixture()
def parts_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "reaction_id": [10, 10, 10, 20, 20],
            "molecule_id": [1, 2, 3, 1, 4],
            "role": ["reactant", "product", "catalyst", "reactant", "product"],
            "step_from": [0.0, 1.0, None, 0.0, 1.0],
            "step_to": [None, None, None, None, None],
            "label": ["r1", "p1", "cat", "r1", "p2"],
        }
    )


@pytest.fixture()
def dataset(
    rxn_df: pl.DataFrame, mol_df: pl.DataFrame, parts_df: pl.DataFrame
) -> ReactionDataset[dict]:
    return ReactionDataset(
        EagerSource(rxn_df),
        participants_source=EagerSource(parts_df),
        molecules_source=EagerSource(mol_df),
    )


class TestEntryResolution:
    def test_entry_is_reaction(self, dataset: ReactionDataset[dict]) -> None:
        rxn = dataset[0]
        assert isinstance(rxn, Reaction)

    def test_id_and_properties(self, dataset: ReactionDataset[dict]) -> None:
        rxn = dataset[0]
        assert rxn.id == 10
        assert rxn.properties["barrier"] == 0.5
        assert "id" not in rxn.properties


class TestParticipants:
    def test_participants_populated(self, dataset: ReactionDataset[dict]) -> None:
        rxn = dataset[0]
        assert len(rxn.participants) == 3

    def test_participant_roles(self, dataset: ReactionDataset[dict]) -> None:
        rxn = dataset[0]
        roles = {p.role for p in rxn.participants}
        assert roles == {
            ParticipantRole.REACTANT,
            ParticipantRole.PRODUCT,
            ParticipantRole.CATALYST,
        }

    def test_participant_molecules(self, dataset: ReactionDataset[dict]) -> None:
        rxn = dataset[0]
        reactants = [p for p in rxn.participants if p.role == ParticipantRole.REACTANT]
        assert len(reactants) == 1
        assert isinstance(reactants[0].molecule, Molecule)
        assert reactants[0].molecule.id == 1
        assert reactants[0].molecule.properties["smiles"] == "A"

    def test_participant_labels(self, dataset: ReactionDataset[dict]) -> None:
        rxn = dataset[0]
        labels = {p.label for p in rxn.participants}
        assert labels == {"r1", "p1", "cat"}

    def test_second_reaction_has_different_participants(
        self, dataset: ReactionDataset[dict]
    ) -> None:
        rxn = dataset[1]
        assert rxn.id == 20
        assert len(rxn.participants) == 2
        mol_ids = {p.molecule.id for p in rxn.participants}
        assert mol_ids == {1, 4}

    def test_participants_sorted_by_step(self, dataset: ReactionDataset[dict]) -> None:
        rxn = dataset[0]
        steps = [p.step_from for p in rxn.participants]
        non_none = [s for s in steps if s is not None]
        assert non_none == sorted(non_none)


class TestWithoutParticipants:
    def test_no_participants_source(self, rxn_df: pl.DataFrame) -> None:
        ds = ReactionDataset(EagerSource(rxn_df))
        rxn = ds[0]
        assert rxn.participants == []


class TestLazyRelationships:
    def test_relationships_loaded_on_first_access(
        self, dataset: ReactionDataset[dict]
    ) -> None:
        assert dataset._participants_by_rxn is None
        assert dataset._molecules_index is None
        _ = dataset[0]
        assert dataset._participants_by_rxn is not None
        assert dataset._molecules_index is not None

    def test_with_source_preserves_cached_relationships(
        self, dataset: ReactionDataset[dict]
    ) -> None:
        _ = dataset[0]  # trigger loading
        sub = dataset[0:1]
        assert sub._participants_by_rxn is dataset._participants_by_rxn
        assert sub._molecules_index is dataset._molecules_index
