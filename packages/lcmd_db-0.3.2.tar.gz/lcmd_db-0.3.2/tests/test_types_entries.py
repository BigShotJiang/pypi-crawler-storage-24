from __future__ import annotations

import pytest
from lcmd_db.types import (
    Fragment,
    Molecule,
    Participant,
    ParticipantRole,
    Reaction,
)


class TestMolecule:
    def test_create(self) -> None:
        mol = Molecule(id=1, properties={"smiles": "C"})
        assert mol.id == 1
        assert mol.properties["smiles"] == "C"
        assert mol.structure_path is None

    def test_frozen(self) -> None:
        mol = Molecule(id=1, properties={})
        with pytest.raises(AttributeError):
            mol.id = 2  # type: ignore[misc]

    def test_equality(self) -> None:
        a = Molecule(id=1, properties={"x": 1})
        b = Molecule(id=1, properties={"x": 1})
        assert a == b


class TestParticipantRole:
    def test_all_roles(self) -> None:
        assert len(ParticipantRole) == 9

    def test_string_value(self) -> None:
        assert ParticipantRole.REACTANT == "reactant"
        assert ParticipantRole.TRANSITION_STATE == "transition_state"

    def test_construct_from_string(self) -> None:
        assert ParticipantRole("catalyst") is ParticipantRole.CATALYST


class TestParticipant:
    def test_create(self) -> None:
        mol = Molecule(id=1, properties={})
        p = Participant(molecule=mol, role=ParticipantRole.REACTANT)
        assert p.molecule.id == 1
        assert p.role == ParticipantRole.REACTANT
        assert p.step_from is None
        assert p.label == ""

    def test_with_steps(self) -> None:
        mol = Molecule(id=1, properties={})
        p = Participant(
            molecule=mol,
            role=ParticipantRole.TRANSITION_STATE,
            step_from=0.0,
            step_to=1.0,
            label="TS1",
        )
        assert p.step_from == 0.0
        assert p.step_to == 1.0
        assert p.label == "TS1"


class TestReaction:
    def test_create_empty_participants(self) -> None:
        rxn = Reaction(id=1, properties={"barrier": 0.5})
        assert rxn.participants == []

    def test_create_with_participants(self) -> None:
        mol = Molecule(id=1, properties={})
        p = Participant(molecule=mol, role=ParticipantRole.REACTANT)
        rxn = Reaction(id=1, properties={}, participants=[p])
        assert len(rxn.participants) == 1


class TestFragment:
    def test_create(self) -> None:
        frag = Fragment(id=1, properties={"smiles": "[*]C"})
        assert frag.fragment_type is None

    def test_with_type(self) -> None:
        frag = Fragment(id=1, properties={}, fragment_type="core")
        assert frag.fragment_type == "core"
