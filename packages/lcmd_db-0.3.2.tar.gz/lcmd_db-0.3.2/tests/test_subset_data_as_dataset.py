"""Tests for SubsetData.as_dataset() factory."""

from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest
from lcmd_db.dataset._fragments import FragmentDataset
from lcmd_db.dataset._molecules import MoleculeDataset
from lcmd_db.dataset._reactions import ReactionDataset
from lcmd_db.types import (
    DataFormat,
    Fragment,
    Molecule,
    ParticipantRole,
    Reaction,
    SubsetData,
    SubsetMetadata,
)


@pytest.fixture()
def data_dir(tmp_path: Path) -> Path:
    pl.DataFrame(
        {"id": [1, 2], "smiles": ["C", "CC"], "weight": [16.0, 30.0]}
    ).write_parquet(tmp_path / "molecules.parquet")

    pl.DataFrame({"id": [10], "barrier": [0.5]}).write_parquet(
        tmp_path / "reactions.parquet"
    )

    pl.DataFrame(
        {
            "reaction_id": [10, 10],
            "molecule_id": [1, 2],
            "role": ["reactant", "product"],
            "step_from": [0.0, 1.0],
            "step_to": [None, None],
            "label": ["", ""],
        }
    ).write_parquet(tmp_path / "reaction_participants.parquet")

    pl.DataFrame(
        {"id": [1], "smiles": ["[*]C"], "fragment_type_slug": ["core"]}
    ).write_parquet(tmp_path / "fragments.parquet")

    structures = tmp_path / "structures"
    structures.mkdir()
    (structures / "1.xyz").write_text("xyz data")

    return tmp_path


@pytest.fixture()
def subset_data(data_dir: Path) -> SubsetData:
    return SubsetData(
        molecules=pl.read_parquet(data_dir / "molecules.parquet"),
        reactions=pl.read_parquet(data_dir / "reactions.parquet"),
        fragments=pl.read_parquet(data_dir / "fragments.parquet"),
        _data_dir=data_dir,
        _data_format=DataFormat.PARQUET,
    )


@pytest.mark.parametrize(
    ("entity_type", "expected_cls"),
    [
        ("molecules", MoleculeDataset),
        ("reactions", ReactionDataset),
        ("fragments", FragmentDataset),
    ],
)
class TestAsDatasetReturnsCorrectType:
    def test_returns_correct_dataset_class(
        self,
        subset_data: SubsetData,
        entity_type: str,
        expected_cls: type,
    ) -> None:
        ds = subset_data.as_dataset(entity_type)
        assert isinstance(ds, expected_cls)


class TestMoleculeEntries:
    def test_entry_is_molecule_with_properties(self, subset_data: SubsetData) -> None:
        mol = subset_data.as_dataset("molecules")[0]
        assert isinstance(mol, Molecule)
        assert mol.id == 1
        assert mol.properties["smiles"] == "C"

    def test_structure_paths_resolved(self, subset_data: SubsetData) -> None:
        ds = subset_data.as_dataset("molecules")
        assert ds[0].structure_path is not None
        assert ds[0].structure_path.exists()
        assert ds[1].structure_path is None


class TestReactionEntries:
    def test_participants_populated(self, subset_data: SubsetData) -> None:
        rxn = subset_data.as_dataset("reactions")[0]
        assert isinstance(rxn, Reaction)
        assert len(rxn.participants) == 2

    def test_participant_molecules_have_properties(
        self, subset_data: SubsetData
    ) -> None:
        rxn = subset_data.as_dataset("reactions")[0]
        reactants = [p for p in rxn.participants if p.role == ParticipantRole.REACTANT]
        assert len(reactants) == 1
        assert reactants[0].molecule.properties["smiles"] == "C"


class TestFragmentEntries:
    def test_fragment_type_extracted(self, subset_data: SubsetData) -> None:
        frag = subset_data.as_dataset("fragments")[0]
        assert isinstance(frag, Fragment)
        assert frag.fragment_type == "core"


class TestErrors:
    def test_no_data_dir_raises(self) -> None:
        with pytest.raises(ValueError, match="No data directory"):
            SubsetData().as_dataset("molecules")

    def test_missing_entity_file_raises(self, data_dir: Path) -> None:
        (data_dir / "molecules.parquet").unlink()
        data = SubsetData(_data_dir=data_dir, _data_format=DataFormat.PARQUET)
        with pytest.raises(ValueError, match="No molecules data found"):
            data.as_dataset("molecules")

    def test_unknown_entity_type_raises(self, subset_data: SubsetData) -> None:
        with pytest.raises(ValueError, match="Unknown entity type"):
            subset_data.as_dataset("bananas")


class TestMetadataPassthrough:
    def test_metadata_forwarded_to_dataset(self, data_dir: Path) -> None:
        meta = SubsetMetadata.model_validate(
            {
                "subset": "test",
                "entities": {
                    "molecules": {
                        "count": 2,
                        "columns": 3,
                        "properties": [{"slug": "weight", "data_type": "float"}],
                    }
                },
            }
        )
        data = SubsetData(
            metadata=meta, _data_dir=data_dir, _data_format=DataFormat.PARQUET
        )
        ds = data.as_dataset("molecules")
        assert ds.properties is not None
        assert ds.properties[0].slug == "weight"
