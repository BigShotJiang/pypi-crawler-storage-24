from .lam_candle import *

__doc__ = lam_candle.__doc__
if hasattr(lam_candle, "__all__"):
    __all__ = lam_candle.__all__