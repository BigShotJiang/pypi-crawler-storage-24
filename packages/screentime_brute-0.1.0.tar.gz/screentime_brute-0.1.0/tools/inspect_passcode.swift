import Foundation
import ObjectiveC

let handle = dlopen("/System/Library/PrivateFrameworks/ScreenTimeCore.framework/ScreenTimeCore", RTLD_NOW)
if handle == nil {
    if let err = dlerror() {
        print("dlopen error: \(String(cString: err))")
    }
}

// Get the class
if let cls = NSClassFromString("STOpaquePasscode") {
    print("Found STOpaquePasscode class")
    print("Superclass: \(String(describing: class_getSuperclass(cls)))")

    // Print instance methods
    var count: UInt32 = 0
    if let methods = class_copyMethodList(cls, &count) {
        print("\nInstance Methods (\(count)):")
        for i in 0..<Int(count) {
            let sel = method_getName(methods[i])
            let types = method_getTypeEncoding(methods[i])
            let typesStr = types != nil ? String(cString: types!) : "?"
            print("  \(NSStringFromSelector(sel))  [\(typesStr)]")
        }
        free(methods)
    }

    // Print class methods
    if let metaCls = object_getClass(cls) {
        var classMethodCount: UInt32 = 0
        if let methods = class_copyMethodList(metaCls, &classMethodCount) {
            print("\nClass Methods (\(classMethodCount)):")
            for i in 0..<Int(classMethodCount) {
                let sel = method_getName(methods[i])
                print("  +\(NSStringFromSelector(sel))")
            }
            free(methods)
        }
    }

    // Properties
    var propCount: UInt32 = 0
    if let props = class_copyPropertyList(cls, &propCount) {
        print("\nProperties (\(propCount)):")
        for i in 0..<Int(propCount) {
            let name = String(cString: property_getName(props[i]))
            let attrs = String(cString: property_getAttributes(props[i])!)
            print("  \(name) -> \(attrs)")
        }
        free(props)
    }

    // Ivars
    var ivarCount: UInt32 = 0
    if let ivars = class_copyIvarList(cls, &ivarCount) {
        print("\nIvars (\(ivarCount)):")
        for i in 0..<Int(ivarCount) {
            let name = ivar_getName(ivars[i]).map { String(cString: $0) } ?? "?"
            let typeEnc = ivar_getTypeEncoding(ivars[i]).map { String(cString: $0) } ?? "?"
            print("  \(name) : \(typeEnc)")
        }
        free(ivars)
    }

    // Check protocols
    var protoCount: UInt32 = 0
    if let protos = class_copyProtocolList(cls, &protoCount) {
        print("\nProtocols (\(protoCount)):")
        for i in 0..<Int(protoCount) {
            print("  \(NSStringFromProtocol(protos[i]))")
        }
    }

    // Check specific selectors
    let selectors = [
        "initWithPasscode:", "initWithString:", "initWithPin:",
        "initWithCode:", "init", "passcode", "pin", "code",
        "stringValue", "string", "value", "data",
        "encodeWithCoder:", "initWithCoder:",
        "isEqual:", "hash", "isEqualToPasscode:",
        "verifyPasscode:", "verify:", "check:",
        "opaqueData", "passcodeData", "rawData",
        "salt", "derivedKey", "hashedPasscode",
    ]

    print("\nSelector checks:")
    for selName in selectors {
        let sel = NSSelectorFromString(selName)
        let responds = (cls as AnyObject).responds(to: sel)
        if responds {
            print("  responds to \(selName): YES")
        }
    }

    // Try to create an instance
    print("\n--- Attempting instance creation ---")

    // Try initWithPasscode:
    let initWithPasscode = NSSelectorFromString("initWithPasscode:")
    if (cls as AnyObject).responds(to: initWithPasscode) {
        print("Class responds to initWithPasscode: - trying it...")
        let obj = (cls as! NSObject.Type).init()
        // We'll use perform selector
    }

    // Try alloc/initWithPasscode via NSObject
    let obj = (cls as! NSObject.Type).perform(NSSelectorFromString("alloc"))?.takeUnretainedValue()
    if let obj = obj {
        print("Allocated instance: \(obj)")
        print("Instance class: \(type(of: obj))")
        print("Instance description: \(obj)")

        // Try initWithPasscode:
        if obj.responds(to: NSSelectorFromString("initWithPasscode:")) {
            let initialized = obj.perform(NSSelectorFromString("initWithPasscode:"), with: "1234")?.takeUnretainedValue()
            if let initialized = initialized {
                print("\ninitWithPasscode:\"1234\" succeeded!")
                print("Result: \(initialized)")
                print("Description: \(initialized.description)")

                // Try to read properties
                for prop in ["passcode", "pin", "code", "stringValue", "string", "value", "data", "opaqueData", "hashedPasscode", "salt", "derivedKey"] {
                    if initialized.responds(to: NSSelectorFromString(prop)) {
                        let val = initialized.perform(NSSelectorFromString(prop))?.takeUnretainedValue()
                        print("  .\(prop) = \(String(describing: val))")
                    }
                }

                // Archive it
                print("\n--- NSKeyedArchiver ---")
                do {
                    let data = try NSKeyedArchiver.archivedData(withRootObject: initialized, requiringSecureCoding: true)
                    print("Archived data length: \(data.count) bytes")
                    print("Hex: \(data.map { String(format: "%02x", $0) }.joined())")

                    // Also print as property list for readability
                    if let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) {
                        print("\nPlist structure:")
                        print(plist)
                    }
                } catch {
                    print("Archiving error: \(error)")

                    // Try without secure coding
                    do {
                        let archiver = NSKeyedArchiver(requiringSecureCoding: false)
                        archiver.encode(initialized, forKey: NSKeyedArchiveRootObjectKey)
                        archiver.finishEncoding()
                        let data = archiver.encodedData
                        print("Archived (non-secure) data length: \(data.count) bytes")
                        print("Hex: \(data.map { String(format: "%02x", $0) }.joined())")
                    } catch {
                        print("Non-secure archiving error: \(error)")
                    }
                }

                // Try creating another with different PIN and compare
                let initialized2 = obj.perform(NSSelectorFromString("initWithPasscode:"), with: "0000")?.takeUnretainedValue()
                if let initialized2 = initialized2 {
                    print("\n--- Comparison with PIN 0000 ---")
                    print("Result: \(initialized2)")
                    do {
                        let data2 = try NSKeyedArchiver.archivedData(withRootObject: initialized2, requiringSecureCoding: true)
                        print("Archived data length: \(data2.count) bytes")
                        print("Hex: \(data2.map { String(format: "%02x", $0) }.joined())")
                    } catch {
                        let archiver = NSKeyedArchiver(requiringSecureCoding: false)
                        archiver.encode(initialized2, forKey: NSKeyedArchiveRootObjectKey)
                        archiver.finishEncoding()
                        let data2 = archiver.encodedData
                        print("Archived (non-secure) data length: \(data2.count) bytes")
                        print("Hex: \(data2.map { String(format: "%02x", $0) }.joined())")
                    }
                }
            }
        }

        // Try initWithString:
        if obj.responds(to: NSSelectorFromString("initWithString:")) {
            let obj2 = (cls as! NSObject.Type).perform(NSSelectorFromString("alloc"))?.takeUnretainedValue()
            let initialized = obj2?.perform(NSSelectorFromString("initWithString:"), with: "1234")?.takeUnretainedValue()
            if let initialized = initialized {
                print("\ninitWithString:\"1234\" succeeded!")
                print("Result: \(initialized)")
            }
        }
    }

} else {
    print("STOpaquePasscode class not found")
}

// Also inspect STUserSettings
if let cls = NSClassFromString("STUserSettings") {
    print("\n\n========== STUserSettings ==========")
    var count: UInt32 = 0
    if let props = class_copyPropertyList(cls, &count) {
        print("Properties (\(count)):")
        for i in 0..<Int(count) {
            let name = String(cString: property_getName(props[i]))
            let attrs = String(cString: property_getAttributes(props[i])!)
            print("  \(name) -> \(attrs)")
        }
        free(props)
    }

    var ivarCount: UInt32 = 0
    if let ivars = class_copyIvarList(cls, &ivarCount) {
        print("\nIvars (\(ivarCount)):")
        for i in 0..<Int(ivarCount) {
            let name = ivar_getName(ivars[i]).map { String(cString: $0) } ?? "?"
            let typeEnc = ivar_getTypeEncoding(ivars[i]).map { String(cString: $0) } ?? "?"
            print("  \(name) : \(typeEnc)")
        }
        free(ivars)
    }
}

// Also check STBlueprintConfiguration
if let cls = NSClassFromString("STBlueprintConfiguration") {
    print("\n\n========== STBlueprintConfiguration ==========")
    var count: UInt32 = 0
    if let props = class_copyPropertyList(cls, &count) {
        print("Properties (\(count)):")
        for i in 0..<Int(count) {
            let name = String(cString: property_getName(props[i]))
            let attrs = String(cString: property_getAttributes(props[i])!)
            print("  \(name) -> \(attrs)")
        }
        free(props)
    }

    var ivarCount: UInt32 = 0
    if let ivars = class_copyIvarList(cls, &ivarCount) {
        print("\nIvars (\(ivarCount)):")
        for i in 0..<Int(ivarCount) {
            let name = ivar_getName(ivars[i]).map { String(cString: $0) } ?? "?"
            let typeEnc = ivar_getTypeEncoding(ivars[i]).map { String(cString: $0) } ?? "?"
            print("  \(name) : \(typeEnc)")
        }
        free(ivars)
    }
}
