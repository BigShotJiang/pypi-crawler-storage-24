# macOS Screen Time Passcode Internals

*Reverse-engineered from macOS Tahoe 26.x (ScreenTimeCore 605.3.1), March 2025*

---

## Overview

Screen Time uses a 4-digit PIN to lock parental controls and content restrictions. Unlike most password systems, the PIN is **not hashed** at the application layer. Instead, Apple relies entirely on **storage-layer encryption** and **kernel-level access control** (datavaults) to protect it.

This document traces the full lifecycle of the passcode: how it's entered, verified, stored, synced, and protected.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        UI Layer                              │
│  ScreenTimeViewService.xpc  (STPasscodeField, PIN entry UI)  │
│  STPINServiceViewController                                  │
└──────────────────────┬──────────────────────────────────────┘
                       │ calls authenticateWithPIN:
                       │       allowPasscodeRecovery:
                       │       completionHandler:
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                   PIN Controller                             │
│  STPINController  (attempt tracking, lockout state machine)  │
└──────────────────────┬──────────────────────────────────────┘
                       │ XPC over com.apple.ScreenTimeAgent.private
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                   ScreenTimeAgent                            │
│  STConcretePasscodeAuthenticationProviderService              │
│  STConcretePasscodeProviderService                            │
│  STPrivateAgentService protocol                               │
└──────────────────────┬──────────────────────────────────────┘
                       │ CoreData read/write
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              CoreData Store (SQLite)                          │
│  RMAdminStore-Local.sqlite   (local passcode)                │
│  RMAdminStore-Cloud.sqlite   (iCloud-synced copy)            │
│                                                              │
│  Entity: STBlueprintConfiguration                            │
│  Type:   STBlueprintConfigurationTypePasscodeSettings         │
│  Field:  passcode (STOpaquePasscode, NSSecureCoding)          │
└─────────────────────────────────────────────────────────────┘
```

---

## Components

### Frameworks

| Framework | Visibility | Role |
|-----------|-----------|------|
| `ScreenTime.framework` | Public | Developer API (Family Controls authorization) |
| `ScreenTimeCore.framework` | Private | Core logic, agent, passcode management |
| `ScreenTimeSwift.framework` | Private | Swift overlays for ScreenTimeCore |
| `ScreenTimeUI.framework` | Private | Lockout UI, PIN entry views |
| `ScreenTimeUICore.framework` | Private | Shared UI primitives |
| `ScreenTimeSettingsUI.framework` | Private | System Settings panel |
| `ScreenTimeServiceUI.framework` | Private | XPC view service hosting PIN entry |
| `FamilyControls.framework` | Public | Authorization and family management |
| `ManagedSettings.framework` | Public | Shield and restriction enforcement |
| `ManagedConfiguration.framework` | Private | MDM restriction profiles |
| `UsageTracking.framework` | Private | App usage data collection |
| `CloudFamilyRestrictions.framework` | Private | Cloud-synced family restriction logic |

### Binaries

| Binary | Location | Purpose |
|--------|----------|---------|
| **ScreenTimeAgent** | `ScreenTimeCore.framework/Versions/A/ScreenTimeAgent` | Main daemon; runs as a launch agent per-user |
| **ScreenTimeViewService** | `ScreenTimeServiceUI.framework/.../ScreenTimeViewService.xpc` | XPC view service rendering the PIN entry UI |
| **FamilyControlsAgent** | `FamilyControls.framework/Versions/A/FamilyControlsAgent` | Manages family authorization state |
| **ManagedSettingsAgent** | `ManagedSettings.framework/Versions/A/ManagedSettingsAgent` | Enforces shields and restrictions |
| **parentalcontrolsd** | `FamilyControls.framework/.../Resources/parentalcontrolsd` | Legacy parental controls daemon |
| **UsageTrackingAgent** | `UsageTracking.framework/Versions/A/UsageTrackingAgent` | Collects per-app usage telemetry |
| **screentimediagnose** | `ScreenTimeCore.framework/screentimediagnose` | CLI diagnostic tool (read-only) |
| **ScreenTimePreferencesExtension** | `ExtensionKit/Extensions/ScreenTimePreferencesExtension.appex` | System Settings extension |

---

## XPC Services

ScreenTimeAgent registers the following Mach services (from its launch agent plist):

| Mach Service | Purpose |
|--------------|---------|
| `com.apple.ScreenTimeAgent` | Public service endpoint |
| `com.apple.ScreenTimeAgent.private` | **Passcode authentication lives here** |
| `com.apple.ScreenTimeAgent.settings` | Settings management |
| `com.apple.ScreenTimeAgent.setup` | Initial setup flow |
| `com.apple.ScreenTimeAgent.persistence` | CoreData persistence |
| `com.apple.ScreenTimeAgent.command-line-tool` | CLI tool endpoint |
| `com.apple.ScreenTimeAgent.ask-for-time` | "Ask For More Time" feature |
| `com.apple.ScreenTimeAgent.communication` | Communication limits |
| `com.apple.ScreenTimeAgent.downtime` | Downtime scheduling |
| `com.apple.ScreenTimeAgent.diagnostics-service` | Diagnostics |
| `com.apple.ScreenTimeAgent.reactor-tool` | Reactor management |
| `com.apple.ScreenTimeAgent.organization-status` | Family org status |
| `com.apple.ScreenTimeAgent.Contacts` | Contacts management |
| `com.apple.ScreenTimeAgent.accessrequestor` | Access request handling |
| `com.apple.ScreenTimeAgent.accessresponder` | Access response handling |

---

## Passcode Verification Flow

### 1. PIN Entry (UI Layer)

The user enters a 4-digit PIN through `STPasscodeField`, rendered inside `ScreenTimeViewService.xpc`. The view controller (`STPINServiceViewController`) provides three entry points:

- `authenticateWithPIN:allowPasscodeRecovery:completionHandler:` — standard verification
- `_locallyAuthenticateWithPasscode:` — local-only verification
- `_promptForRecoveryAppleIDForPasscode:completionHandler:skipHandler:` — Apple ID recovery flow

### 2. State Machine (STPINController)

`STPINController` (from ScreenTimeCore) manages the PIN lifecycle:

- Tracks `passcodeEntryAttemptCount` — number of consecutive failed attempts
- Tracks `passcodeEntryTimeoutEndDate` — when the lockout expires
- Posts `STPINTimeoutDidBeginNotification` when lockout starts
- Posts `STPINTimeoutDidEndNotification` when lockout ends
- Escalating timeouts: 1 min → 5 min → 15 min → 1 hour (after 6, 7, 8, 9 failures)
- State is persisted on the `STUserDeviceState` CoreData entity

### 3. XPC to ScreenTimeAgent

The PIN controller communicates with ScreenTimeAgent over the `com.apple.ScreenTimeAgent.private` Mach service using the `STPrivateAgentService` protocol:

```objc
// Verification
- (void)authenticateRestrictionsPasscode:(STOpaquePasscode *)passcode
                       completionHandler:(void (^)(BOOL success, NSError *error))handler;

// Management
- (void)setRestrictionsPasscode:(STOpaquePasscode *)passcode
              completionHandler:(void (^)(NSError *error))handler;

- (void)clearRestrictionsPasscodeWithCompletionHandler:(void (^)(NSError *error))handler;

// State queries
- (void)isRestrictionsPasscodeSetWithCompletionHandler:(void (^)(BOOL isSet))handler;

- (void)needsToSetRestrictionsPasscodeWithCompletionHandler:(void (^)(BOOL needs))handler;

- (void)fetchRestrictionsPasscodeEntryAttemptCountAndTimeoutDateWithCompletionHandler:
    (void (^)(NSInteger count, NSDate *timeoutDate))handler;
```

### 4. Storage Comparison

ScreenTimeAgent reads the `effectivePasscode` (an `STOpaquePasscode` object) from the CoreData store and compares it with the submitted passcode. The comparison appears to be a direct equality check on the wrapped string value — there is no KDF or hash involved.

---

## Data Storage

### CoreData Model

The schema is defined in `ScreenTime.momd` (inside ScreenTimeCore). Key entities related to passcode:

**`BlueprintConfiguration` (class: `STBlueprintConfiguration`)**

| Attribute | Type | Purpose |
|-----------|------|---------|
| `passcode` | Transformable (`STOpaquePasscode`) | The PIN value, wrapped in an opaque NSSecureCoding-compliant object |
| `passcodeOwner` | String | Which user/device set the passcode |
| `needsToSetPasscode` | Boolean | Whether passcode setup is required |
| `lastPasscodeUseDate` | Date | Last time the passcode was entered |
| `supportsPasscodeActivity` | Boolean | Whether passcode usage notifications are enabled |

**`UserDeviceState` (class: `STUserDeviceState`)**

| Attribute | Type | Purpose |
|-----------|------|---------|
| `passcodeEntryAttemptCount` | Integer | Consecutive failed attempts |
| `passcodeEntryTimeoutEndDate` | Date | Current lockout expiry |
| `passcodeRecoveryAttemptCount` | Integer | Failed Apple ID recovery attempts |

### STOpaquePasscode

The PIN is wrapped in `STOpaquePasscode`, an `NSSecureCoding`-compliant class. Internally, the `UserSettings.pin` property is typed as `String?`, suggesting the 4-digit PIN is stored as a plain string within the archive.

**There is no independent hashing.** No symbols for PBKDF2, scrypt, argon2, bcrypt, or CommonCrypto key derivation were found in any Screen Time binary. This is a deliberate design choice: a 4-digit PIN has only 10,000 possible values, making application-level hashing pointless against offline brute-force. Instead, Apple protects the storage itself.

### File Locations

| Store | Path | Purpose |
|-------|------|---------|
| Local | `/private/var/folders/.../com.apple.ScreenTimeAgent/Store/RMAdminStore-Local.sqlite` | Device-local passcode and settings |
| Cloud | `/private/var/folders/.../com.apple.ScreenTimeAgent/Store/RMAdminStore-Cloud.sqlite` | iCloud-synced copy |
| Preferences | `~/Library/Containers/com.apple.ScreenTimeAgent/Data/Library/Preferences/com.apple.ScreenTimeAgent.plist` | Metadata (no passcode data) |
| Group Container | `~/Library/Group Containers/group.com.apple.ScreenTime/` | Shared data (no passcode data) |

---

## Protection Layers

The passcode is protected by four concentric layers, from outermost to innermost:

### Layer 1: TCC (Transparency, Consent, and Control)

Screen Time data requires the `com.apple.private.screen-time.persistence` entitlement. Standard Full Disk Access does not grant access to this container.

### Layer 2: Datavault

The `Store/` directory is protected by a **datavault** — a kernel-level sandbox mechanism that restricts file access to processes with specific entitlements. This is stronger than both TCC and SIP for file access:

- `sudo` cannot read the files
- Full Disk Access cannot read the files
- Only processes signed with Apple's `com.apple.private.screen-time.persistence` entitlement can access the directory
- The protection is enforced at the VFS layer in the kernel

### Layer 3: SIP (System Integrity Protection)

SIP prevents:
- Modifying ScreenTimeAgent or ScreenTimeCore binaries
- Injecting code (DYLD_INSERT_LIBRARIES) into Apple-signed processes
- Attaching debuggers (lldb/dtrace) to Apple system processes
- Replacing system frameworks with modified versions

### Layer 4: iCloud Encryption (CKKS)

When synced to iCloud, the passcode is protected by **CloudKit Key-Value Store (CKKS)** encryption:
- CloudKit container: `com.apple.remotemanagement.encrypted`
- Sync group: `DigitalHealth`
- Encryption tier: `Manatee` (iCloud Keychain level)
- Transport: IDS (Identity Services) over topics `com.apple.private.alloy.screentime` and `com.apple.private.alloy.digitalhealth`

### Entitlements on ScreenTimeAgent

| Entitlement | Purpose |
|-------------|---------|
| `com.apple.private.screen-time.persistence` | Access to the datavault-protected CoreData store |
| `com.apple.private.system-keychain` | System keychain access |
| `com.apple.keystore.sik.access` | System Identity Key (device-level encryption) |
| Keychain groups: `apple`, `com.apple.certificates`, `com.apple.identities`, `lockdown-identities`, `InternetAccounts` | Various credential access |

---

## Recovery Mechanisms

### Apple ID Recovery

The primary recovery path. When the passcode is set, a recovery Apple ID is registered via `effectiveRecoveryAltDSID` (an obfuscated Apple ID identifier). Recovery uses:

- `AKAppleIDAuthenticationController` (from AuthKit) to verify the Apple ID
- `_promptForRecoveryAppleIDForPasscode:completionHandler:skipHandler:` to present the UI
- `_forgotPasscode:` triggers the recovery flow from the "Forgot Passcode?" button

### Local Authentication (Touch ID)

Uses `LAUIAuthenticationSheetController` from the LocalAuthentication framework. This provides biometric bypass for the device owner.

### Parent Notification

When a child uses the passcode, `sendPasscodeActivityToParentsWithCompletionHandler:` sends a notification to parent devices via IDS.

---

## Cross-Device Sync

Screen Time settings (including the passcode) sync across devices via two mechanisms:

### IDS (Identity Services)

- Topic: `com.apple.private.alloy.screentime`
- Topic: `com.apple.private.alloy.digitalhealth`
- Used for real-time push of passcode changes and activity notifications
- `STPasscodeActivityUserNotificationContext` handles parent notifications

### CloudKit (NSPersistentCloudKitContainer)

- Container: `com.apple.remotemanagement.encrypted`
- Uses `NSPersistentCloudKitContainer` for automatic CoreData ↔ CloudKit sync
- Store names: `defaultStoreName`, `restricitonsStoreName` (note: typo in Apple's code), `shareAcrossDevicesStoreName`, `userSafetyStoreName`
- Protected by CKKS encryption (Manatee tier = iCloud Keychain level security)

### Family Organization

- `STFamilyOrganization` and `STFamilyOrganizationSettings` propagate settings to family members
- `STRemotePasscodeController` (in ScreenTimeUI) handles remote passcode entry for family management

---

## Attack Surface Analysis

| Vector | Feasibility | Notes |
|--------|-------------|-------|
| Read SQLite directly | **Blocked** | Datavault protection, even with root + FDA |
| Debug ScreenTimeAgent | **Blocked** | SIP prevents attaching to Apple system processes |
| DYLD injection | **Blocked** | Library validation on Apple-signed binaries |
| Brute-force via UI | **Slow** | Escalating lockouts after 5 failures |
| Brute-force via XPC | **Blocked** | XPC service requires entitlements to connect |
| Backup extraction | **Possible** | If unencrypted backups contain the store |
| Disable SIP + read DB | **Possible** | Requires physical access + Recovery Mode boot |
| Boot external OS | **Possible** | Mount internal disk, read file outside datavault enforcement |
| iCloud interception | **Blocked** | CKKS end-to-end encryption |
| `screentimediagnose` | **Partial** | Confirms passcode is set, but redacts the value |
| Custom entitled binary | **Blocked** | Requires Apple-internal signing certificate |
| Keychain extraction | **No data** | PIN is not stored in Keychain |

---

## Observations

1. **No application-level hashing is a conscious design decision.** With only 10,000 possible 4-digit PINs, any hash is trivially brute-forced offline. Apple chose to make the storage inaccessible instead of the value unreadable.

2. **The datavault is the real security boundary.** TCC, SIP, and code signing all contribute, but the datavault kernel protection is what ultimately prevents local extraction. It's one of the strongest file-level protections in macOS.

3. **Apple has a typo in their code.** The store name `restricitonsStoreName` (sic) appears in the binary — "restricitons" instead of "restrictions."

4. **The PIN syncs at iCloud Keychain security level.** The `Manatee` CKKS tier means the passcode is protected by the same infrastructure that guards passwords and credit cards in iCloud Keychain.

5. **Recovery is the intended escape hatch.** Apple clearly designed the system so that the Apple ID associated with the account is the master key. If you lose both the PIN and the recovery Apple ID credentials, there is no supported path short of device reset.

---

*Research conducted via binary analysis (dyld_info, nm, strings), runtime inspection (lsof, screentimediagnose), CoreData model extraction (plutil), and XPC service enumeration.*
