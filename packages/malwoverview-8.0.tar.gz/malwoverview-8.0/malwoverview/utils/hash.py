import hashlib
import os
import re
from malwoverview.utils.colors import mycolors, printr
import malwoverview.modules.configvars as cv


def detect_hash_type(value):
    value = value.strip()
    if not re.match(r'^[a-fA-F0-9]+$', value):
        return 'unknown'
    length = len(value)
    if length == 32:
        return 'md5'
    elif length == 40:
        return 'sha1'
    elif length == 64:
        return 'sha256'
    return 'unknown'


def sha256hash(fname):
    BSIZE = 65536
    hash256 = hashlib.sha256()
    with open(fname, 'rb') as hnd:
        while True:
            info = hnd.read(BSIZE)
            if not info:
                break
            hash256.update(info)
    return hash256.hexdigest()


def md5hash(fname):
    BSIZE = 65536
    hashmd5 = hashlib.md5()
    with open(fname, 'rb') as hnd:
        while True:
            info = hnd.read(BSIZE)
            if not info:
                break
            hashmd5.update(info)
    return hashmd5.hexdigest()


def calchash(ffpname2):
    targetfile = ffpname2
    mysha256hash = ''
    dname = str(os.path.dirname(targetfile))
    if not os.path.abspath(dname):
        dname = os.path.abspath('.') + "/" + dname

    print(mycolors.reset, end=' ')

    try:
        mysha256hash = sha256hash(targetfile)
        return mysha256hash
    except Exception:
        if (cv.bkg == 1):
            print((mycolors.foreground.lightred + "Error while calculing the hash!\n"))
        else:
            print((mycolors.foreground.red + "Error while calculating the hash\n"))
        printr()
