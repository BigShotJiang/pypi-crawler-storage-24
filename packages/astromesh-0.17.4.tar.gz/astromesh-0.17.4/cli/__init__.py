"""Astromesh OS CLI — astromeshctl."""
