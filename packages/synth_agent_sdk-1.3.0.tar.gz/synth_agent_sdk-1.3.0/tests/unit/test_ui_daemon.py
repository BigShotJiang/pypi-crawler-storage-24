"""Unit tests for UI server daemonization in ``synth ui``.

Tests the daemon lifecycle logic in ``ui_cmd``: detecting a running server,
starting a new daemon when none exists, and cleaning up stale PIDs before
restarting.

Requirements: 7.2, 7.3, 7.4
"""

from __future__ import annotations

from unittest.mock import MagicMock, mock_open, patch

import pytest
from click.testing import CliRunner

from synth.cli.main import cli
from synth.cli.registry import ServerInfo


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_server_info(
    pid: int = 1234,
    port: int = 8420,
) -> ServerInfo:
    return ServerInfo(
        pid=pid,
        port=port,
        started_at="2025-01-15T10:00:00+00:00",
    )


# ---------------------------------------------------------------------------
# TestUiDaemon
# ---------------------------------------------------------------------------


class TestUiDaemon:
    """Tests for the daemonization logic in ``synth ui``."""

    def test_existing_server_opens_browser(self):
        """When registry has a live ServerInfo, open browser and skip start.

        Validates: Requirement 7.3
        """
        runner = CliRunner()
        server = _make_server_info(pid=1234, port=8420)

        mock_store = MagicMock()
        mock_store.get_server.return_value = server

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=mock_store,
        ), patch("os.kill") as mock_kill, \
             patch("urllib.request.urlopen") as mock_urlopen, \
             patch("webbrowser.open") as mock_browser, \
             patch("subprocess.Popen") as mock_popen:

            # PID alive — os.kill(pid, 0) succeeds (no exception)
            mock_kill.return_value = None
            # Port responsive — urlopen succeeds
            mock_urlopen.return_value = MagicMock()

            result = runner.invoke(cli, ["ui", "agent.py"])

        assert result.exit_code == 0, result.output
        # Browser opened to existing server URL
        mock_browser.assert_called_once_with(
            "http://localhost:8420",
        )
        # No new process started
        mock_popen.assert_not_called()
        # Stale cleanup NOT called (server is alive)
        mock_store.clear_server.assert_not_called()

    def test_new_server_start(self):
        """When no existing server, start a daemon and store ServerInfo.

        Validates: Requirement 7.2
        """
        runner = CliRunner()

        mock_store = MagicMock()
        mock_store.get_server.return_value = None

        mock_proc = MagicMock()
        mock_proc.pid = 9999

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=mock_store,
        ), patch(
            "subprocess.Popen", return_value=mock_proc,
        ) as mock_popen, \
             patch("webbrowser.open") as mock_browser, \
             patch("time.sleep"), \
             patch("builtins.open", mock_open()):

            result = runner.invoke(cli, ["ui", "agent.py"])

        assert result.exit_code == 0, result.output
        # Popen was called to start the daemon
        mock_popen.assert_called_once()
        # ServerInfo stored in registry with the new PID
        mock_store.set_server.assert_called_once()
        stored = mock_store.set_server.call_args[0][0]
        assert isinstance(stored, ServerInfo)
        assert stored.pid == 9999
        assert stored.port == 8420
        # Browser opened
        mock_browser.assert_called_once_with("http://localhost:8420")

    def test_stale_pid_cleanup_and_restart(self):
        """When stored PID is dead, clear stale entry and start new daemon.

        Validates: Requirement 7.4
        """
        runner = CliRunner()
        stale_server = _make_server_info(pid=5555, port=8420)

        mock_store = MagicMock()
        mock_store.get_server.return_value = stale_server

        mock_proc = MagicMock()
        mock_proc.pid = 7777

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=mock_store,
        ), patch(
            "os.kill", side_effect=ProcessLookupError,
        ) as mock_kill, \
             patch(
            "subprocess.Popen", return_value=mock_proc,
        ) as mock_popen, \
             patch("webbrowser.open") as mock_browser, \
             patch("time.sleep"), \
             patch("builtins.open", mock_open()):

            result = runner.invoke(cli, ["ui", "agent.py"])

        assert result.exit_code == 0, result.output
        # os.kill was called to check the stale PID
        mock_kill.assert_called_with(5555, 0)
        # Stale entry cleared
        mock_store.clear_server.assert_called_once()
        # New daemon started
        mock_popen.assert_called_once()
        # New ServerInfo stored with fresh PID
        mock_store.set_server.assert_called_once()
        stored = mock_store.set_server.call_args[0][0]
        assert stored.pid == 7777
        # Browser opened
        mock_browser.assert_called_once_with("http://localhost:8420")
