"""Tests for the BedrockProvider — streaming tool-call accumulation and complete().

Covers the contentBlockStart → contentBlockDelta* → contentBlockStop flow
introduced to correctly assemble tool calls from chunked Bedrock stream events.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from synth.providers.base import (
    ProviderDoneEvent,
    ProviderErrorEvent,
    TextChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USER_MSG: list[Message] = [{"role": "user", "content": "hello"}]


def _make_provider(**kwargs: Any):
    """Create a BedrockProvider with a mocked boto3 client."""
    with patch("synth.providers.bedrock.boto3") as mock_boto3:
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client
        from synth.providers.bedrock import BedrockProvider

        provider = BedrockProvider(model="bedrock/test-model", **kwargs)
    return provider, mock_client


async def _collect_stream(provider, messages=None, **kwargs):
    """Collect all events from a stream() call into a list."""
    events = []
    async for event in provider.stream(messages or _USER_MSG, **kwargs):
        events.append(event)
    return events


# ---------------------------------------------------------------------------
# Streaming — text-only
# ---------------------------------------------------------------------------


class TestBedrockStreamTextOnly:
    """Stream events containing only text deltas."""

    @pytest.mark.asyncio
    async def test_text_chunks_yielded(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "Hello"}}},
                {"contentBlockDelta": {"delta": {"text": " world"}}},
                {"metadata": {"usage": {"inputTokens": 5, "outputTokens": 2}}},
            ],
        }

        events = await _collect_stream(provider)

        text_events = [e for e in events if isinstance(e, TextChunkEvent)]
        assert len(text_events) == 2
        assert text_events[0].text == "Hello"
        assert text_events[1].text == " world"

    @pytest.mark.asyncio
    async def test_done_event_with_usage(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "hi"}}},
                {"metadata": {"usage": {"inputTokens": 10, "outputTokens": 20}}},
            ],
        }

        events = await _collect_stream(provider)

        done = [e for e in events if isinstance(e, ProviderDoneEvent)]
        assert len(done) == 1
        assert done[0].usage.input_tokens == 10
        assert done[0].usage.output_tokens == 20
        assert done[0].usage.total_tokens == 30


# ---------------------------------------------------------------------------
# Streaming — tool call accumulation
# ---------------------------------------------------------------------------


class TestBedrockStreamToolCallAccumulation:
    """The contentBlockStart → contentBlockDelta* → contentBlockStop flow."""

    @pytest.mark.asyncio
    async def test_single_tool_call_assembled(self) -> None:
        """A complete tool call across start/delta/stop yields one event."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {
                                "toolUseId": "tc_1",
                                "name": "get_weather",
                            },
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {
                            "toolUse": {"input": '{"city":'},
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {
                            "toolUse": {"input": ' "Paris"}'},
                        },
                    },
                },
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 8, "outputTokens": 15}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 1
        assert tool_events[0].id == "tc_1"
        assert tool_events[0].name == "get_weather"
        assert tool_events[0].args == {"city": "Paris"}

    @pytest.mark.asyncio
    async def test_multiple_tool_calls_assembled(self) -> None:
        """Two sequential tool calls each produce their own event."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                # First tool call
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_1", "name": "add"},
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": '{"a": 1, "b": 2}'}},
                    },
                },
                {"contentBlockStop": {}},
                # Second tool call
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_2", "name": "multiply"},
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": '{"a": 3, "b": 4}'}},
                    },
                },
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 12, "outputTokens": 10}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 2
        assert tool_events[0].id == "tc_1"
        assert tool_events[0].name == "add"
        assert tool_events[0].args == {"a": 1, "b": 2}
        assert tool_events[1].id == "tc_2"
        assert tool_events[1].name == "multiply"
        assert tool_events[1].args == {"a": 3, "b": 4}

    @pytest.mark.asyncio
    async def test_tool_call_with_empty_input_chunks(self) -> None:
        """Empty input strings in deltas are skipped during accumulation."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_1", "name": "greet"},
                        },
                    },
                },
                # Empty input chunk — should be skipped
                {"contentBlockDelta": {"delta": {"toolUse": {"input": ""}}}},
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": '{"name": "Alice"}'}},
                    },
                },
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 5, "outputTokens": 5}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 1
        assert tool_events[0].args == {"name": "Alice"}

    @pytest.mark.asyncio
    async def test_tool_call_with_no_input_yields_empty_args(self) -> None:
        """A tool call with no input deltas at all yields empty dict args."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_1", "name": "noop"},
                        },
                    },
                },
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 3, "outputTokens": 1}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 1
        assert tool_events[0].name == "noop"
        assert tool_events[0].args == {}

    @pytest.mark.asyncio
    async def test_tool_call_with_invalid_json_yields_empty_args(self) -> None:
        """Malformed JSON input falls back to empty dict args."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_1", "name": "broken"},
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": "{not valid json"}},
                    },
                },
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 3, "outputTokens": 1}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 1
        assert tool_events[0].name == "broken"
        assert tool_events[0].args == {}


# ---------------------------------------------------------------------------
# Streaming — mixed text and tool calls
# ---------------------------------------------------------------------------


class TestBedrockStreamMixed:
    """Streams containing both text and tool call blocks."""

    @pytest.mark.asyncio
    async def test_text_then_tool_call(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "Let me check."}}},
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_1", "name": "search"},
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": '{"q": "test"}'}},
                    },
                },
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 10, "outputTokens": 8}}},
            ],
        }

        events = await _collect_stream(provider)

        text_events = [e for e in events if isinstance(e, TextChunkEvent)]
        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(text_events) == 1
        assert text_events[0].text == "Let me check."
        assert len(tool_events) == 1
        assert tool_events[0].args == {"q": "test"}


# ---------------------------------------------------------------------------
# Streaming — contentBlockStop without prior tool start
# ---------------------------------------------------------------------------


class TestBedrockStreamContentBlockStopNoTool:
    """contentBlockStop for a text block should not emit a tool event."""

    @pytest.mark.asyncio
    async def test_stop_without_tool_start_ignored(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "hi"}}},
                # Stop for the text block — _current_tool_name is empty
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 2, "outputTokens": 1}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 0
        text_events = [e for e in events if isinstance(e, TextChunkEvent)]
        assert len(text_events) == 1


# ---------------------------------------------------------------------------
# Streaming — contentBlockStart without toolUse
# ---------------------------------------------------------------------------


class TestBedrockStreamContentBlockStartNoTool:
    """contentBlockStart for a text block (no toolUse key) is a no-op."""

    @pytest.mark.asyncio
    async def test_start_without_tool_use_ignored(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                # Text block start — no toolUse in start
                {"contentBlockStart": {"start": {}}},
                {"contentBlockDelta": {"delta": {"text": "hello"}}},
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 2, "outputTokens": 1}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 0
        text_events = [e for e in events if isinstance(e, TextChunkEvent)]
        assert len(text_events) == 1


# ---------------------------------------------------------------------------
# Streaming — error handling
# ---------------------------------------------------------------------------


class TestBedrockStreamError:
    """Errors during streaming yield ProviderErrorEvent."""

    @pytest.mark.asyncio
    async def test_exception_yields_error_event(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.side_effect = RuntimeError("boom")

        events = await _collect_stream(provider)

        error_events = [e for e in events if isinstance(e, ProviderErrorEvent)]
        assert len(error_events) == 1
        assert str(error_events[0].error) == "boom"


# ---------------------------------------------------------------------------
# Streaming — empty stream
# ---------------------------------------------------------------------------


class TestBedrockStreamEmpty:
    """An empty event stream still yields a done event."""

    @pytest.mark.asyncio
    async def test_empty_stream_yields_done(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {"stream": []}

        events = await _collect_stream(provider)

        done = [e for e in events if isinstance(e, ProviderDoneEvent)]
        assert len(done) == 1
        assert done[0].usage.input_tokens == 0
        assert done[0].usage.output_tokens == 0

    @pytest.mark.asyncio
    async def test_missing_stream_key_yields_done(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {}

        events = await _collect_stream(provider)

        done = [e for e in events if isinstance(e, ProviderDoneEvent)]
        assert len(done) == 1


# ---------------------------------------------------------------------------
# Streaming — accumulator state reset between tool calls
# ---------------------------------------------------------------------------


class TestBedrockStreamAccumulatorReset:
    """Verify accumulator state is properly reset between tool calls."""

    @pytest.mark.asyncio
    async def test_second_tool_does_not_inherit_first_input(self) -> None:
        """Each tool call gets its own clean accumulator."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_1", "name": "first"},
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": '{"x": 1}'}},
                    },
                },
                {"contentBlockStop": {}},
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "tc_2", "name": "second"},
                        },
                    },
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": '{"y": 2}'}},
                    },
                },
                {"contentBlockStop": {}},
                {"metadata": {"usage": {"inputTokens": 5, "outputTokens": 5}}},
            ],
        }

        events = await _collect_stream(provider)

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert tool_events[0].args == {"x": 1}
        assert tool_events[1].args == {"y": 2}
        # Confirm no cross-contamination
        assert "x" not in tool_events[1].args
        assert "y" not in tool_events[0].args


# ---------------------------------------------------------------------------
# Streaming — metadata without usage
# ---------------------------------------------------------------------------


class TestBedrockStreamMetadata:
    """Edge cases in metadata handling."""

    @pytest.mark.asyncio
    async def test_metadata_without_usage_defaults_to_zero(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "ok"}}},
                {"metadata": {}},
            ],
        }

        events = await _collect_stream(provider)

        done = [e for e in events if isinstance(e, ProviderDoneEvent)]
        assert done[0].usage.input_tokens == 0
        assert done[0].usage.output_tokens == 0


# ---------------------------------------------------------------------------
# complete() — tool calls in response
# ---------------------------------------------------------------------------


class TestBedrockComplete:
    """Tests for the complete() method."""

    @pytest.mark.asyncio
    async def test_complete_text_response(self) -> None:
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {
                "message": {
                    "content": [{"text": "The capital is Paris."}],
                },
            },
            "usage": {
                "inputTokens": 10,
                "outputTokens": 8,
                "totalTokens": 18,
            },
        }

        result = await provider.complete(_USER_MSG)

        assert result.text == "The capital is Paris."
        assert result.usage.input_tokens == 10
        assert result.usage.output_tokens == 8
        assert result.tool_calls == []

    @pytest.mark.asyncio
    async def test_complete_with_tool_calls(self) -> None:
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {
                "message": {
                    "content": [
                        {"text": "Let me check."},
                        {
                            "toolUse": {
                                "toolUseId": "tc_1",
                                "name": "get_weather",
                                "input": {"city": "Tokyo"},
                            },
                        },
                    ],
                },
            },
            "usage": {
                "inputTokens": 15,
                "outputTokens": 12,
                "totalTokens": 27,
            },
        }

        result = await provider.complete(_USER_MSG)

        assert result.text == "Let me check."
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].id == "tc_1"
        assert result.tool_calls[0].name == "get_weather"
        assert result.tool_calls[0].args == {"city": "Tokyo"}

    @pytest.mark.asyncio
    async def test_complete_forwards_kwargs(self) -> None:
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "usage": {"inputTokens": 1, "outputTokens": 1, "totalTokens": 2},
        }

        await provider.complete(_USER_MSG, temperature=0.5, max_tokens=100)

        call_kwargs = client.converse.call_args[1]
        assert call_kwargs["inferenceConfig"]["temperature"] == 0.5
        assert call_kwargs["inferenceConfig"]["maxTokens"] == 100


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------


class TestBedrockProviderInit:
    """Constructor and model ID handling."""

    def test_strips_bedrock_prefix(self) -> None:
        provider, _ = _make_provider()
        assert provider._model_id == "test-model"

    def test_missing_boto3_raises_config_error(self) -> None:
        with patch("synth.providers.bedrock.boto3", None):
            from synth.providers.bedrock import BedrockProvider

            with pytest.raises(Exception, match="boto3.*not installed"):
                BedrockProvider(model="bedrock/test")

    def test_custom_base_url(self) -> None:
        with patch("synth.providers.bedrock.boto3") as mock_boto3:
            mock_boto3.client.return_value = MagicMock()
            from synth.providers.bedrock import BedrockProvider

            BedrockProvider(
                model="bedrock/test", base_url="https://custom.endpoint"
            )
            call_kwargs = mock_boto3.client.call_args[1]
            assert call_kwargs["endpoint_url"] == "https://custom.endpoint"

    def test_custom_region(self) -> None:
        with patch("synth.providers.bedrock.boto3") as mock_boto3:
            mock_boto3.client.return_value = MagicMock()
            from synth.providers.bedrock import BedrockProvider

            BedrockProvider(
                model="bedrock/test", region_name="eu-west-1"
            )
            call_kwargs = mock_boto3.client.call_args[1]
            assert call_kwargs["region_name"] == "eu-west-1"


# ---------------------------------------------------------------------------
# _sanitize_text — empty content block prevention
# ---------------------------------------------------------------------------


class TestSanitizeText:
    """BedrockProvider._sanitize_text guards against blank text blocks.

    The Bedrock Converse API rejects any ContentBlock where the text
    field is empty.  _sanitize_text replaces blank/None values with a
    safe placeholder.
    """

    def _sanitize(self, value: str | None) -> str:
        provider, _ = _make_provider()
        return provider._sanitize_text(value)

    @pytest.mark.parametrize(
        "input_val",
        ["", "   ", "\t", "\n", "  \n\t  "],
        ids=["empty", "spaces", "tab", "newline", "mixed-whitespace"],
    )
    def test_blank_strings_replaced(self, input_val: str) -> None:
        assert self._sanitize(input_val) == "(no content)"

    def test_none_replaced(self) -> None:
        assert self._sanitize(None) == "(no content)"

    def test_valid_text_unchanged(self) -> None:
        assert self._sanitize("hello world") == "hello world"

    def test_whitespace_padded_text_preserved(self) -> None:
        assert self._sanitize("  hello  ") == "  hello  "


# ---------------------------------------------------------------------------
# _build_messages — sanitization integration
# ---------------------------------------------------------------------------


class TestBuildMessagesSanitization:
    """Verify _build_messages never produces blank text content blocks.

    These tests target the three injection points: system messages,
    regular user/assistant messages, and tool result content blocks.
    """

    def _build(
        self, messages: list[Message]
    ) -> tuple[list[dict[str, Any]] | None, list[dict[str, Any]]]:
        provider, _ = _make_provider()
        return provider._build_messages(messages)

    def test_empty_user_message_sanitized(self) -> None:
        system, msgs = self._build([{"role": "user", "content": ""}])
        text = msgs[0]["content"][0]["text"]
        assert text == "(no content)"

    def test_empty_system_message_sanitized(self) -> None:
        system, msgs = self._build([
            {"role": "system", "content": ""},
            {"role": "user", "content": "hi"},
        ])
        assert system is not None
        assert system[0]["text"] == "(no content)"

    def test_empty_tool_result_sanitized(self) -> None:
        system, msgs = self._build([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "let me check"},
            {"role": "tool", "content": ""},
        ])
        # Find the user message containing toolResult blocks
        tool_result_msg = [
            m for m in msgs if m["role"] == "user"
            and any("toolResult" in b for b in m["content"])
        ]
        assert len(tool_result_msg) == 1
        tr_content = tool_result_msg[0]["content"][0]["toolResult"]["content"]
        assert tr_content[0]["text"] == "(no content)"

    def test_nonempty_content_passes_through(self) -> None:
        system, msgs = self._build([
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "hello"},
        ])
        assert system[0]["text"] == "You are helpful."
        user_msg = [m for m in msgs if m["role"] == "user"][0]
        assert user_msg["content"][0]["text"] == "hello"

    def test_none_tool_result_sanitized(self) -> None:
        system, msgs = self._build([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "checking"},
            {"role": "tool", "content": None},
        ])
        tool_result_msg = [
            m for m in msgs if m["role"] == "user"
            and any("toolResult" in b for b in m["content"])
        ]
        assert len(tool_result_msg) == 1
        tr_content = tool_result_msg[0]["content"][0]["toolResult"]["content"]
        assert tr_content[0]["text"] == "(no content)"


# ---------------------------------------------------------------------------
# _has_tool_blocks — detection of toolUse / toolResult in messages
# ---------------------------------------------------------------------------


class TestHasToolBlocks:
    """BedrockProvider._has_tool_blocks detects tool-bearing messages."""

    def _has(self, api_messages: list[dict[str, Any]]) -> bool:
        provider, _ = _make_provider()
        return provider._has_tool_blocks(api_messages)

    def test_empty_messages_returns_false(self) -> None:
        assert self._has([]) is False

    def test_text_only_messages_returns_false(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "hello"}]},
            {"role": "assistant", "content": [{"text": "hi"}]},
        ]
        assert self._has(msgs) is False

    def test_tool_use_block_returns_true(self) -> None:
        msgs = [
            {"role": "assistant", "content": [
                {"toolUse": {"toolUseId": "tc_1", "name": "search", "input": {}}},
            ]},
        ]
        assert self._has(msgs) is True

    def test_tool_result_block_returns_true(self) -> None:
        msgs = [
            {"role": "user", "content": [
                {"toolResult": {"toolUseId": "tc_1", "content": [{"text": "ok"}]}},
            ]},
        ]
        assert self._has(msgs) is True

    def test_mixed_text_and_tool_blocks_returns_true(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "hi"}]},
            {"role": "assistant", "content": [
                {"text": "Let me check."},
                {"toolUse": {"toolUseId": "tc_1", "name": "get_weather", "input": {}}},
            ]},
        ]
        assert self._has(msgs) is True

    def test_message_without_content_key_returns_false(self) -> None:
        msgs = [{"role": "user"}]
        assert self._has(msgs) is False

    def test_non_dict_content_items_skipped(self) -> None:
        msgs = [{"role": "user", "content": ["plain string", 42]}]
        assert self._has(msgs) is False


# ---------------------------------------------------------------------------
# complete() / stream() — empty toolConfig fallback for tool-bearing history
# ---------------------------------------------------------------------------


class TestToolConfigFallback:
    """When no tools are passed but messages contain toolUse/toolResult blocks,
    the provider strips tool blocks from the message history to avoid the
    Bedrock ``toolConfig`` validation error.
    """

    # -- complete() ----------------------------------------------------------

    @pytest.mark.asyncio
    async def test_complete_no_tools_no_tool_blocks_omits_tool_config(self) -> None:
        """Plain conversation without tool history should not send toolConfig."""
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "usage": {"inputTokens": 1, "outputTokens": 1, "totalTokens": 2},
        }

        await provider.complete(_USER_MSG, tools=None)

        call_kwargs = client.converse.call_args[1]
        assert "toolConfig" not in call_kwargs

    @pytest.mark.asyncio
    async def test_complete_no_tools_with_tool_blocks_strips_tool_blocks(
        self,
    ) -> None:
        """Follow-up turn with tool history but no tools strips tool blocks."""
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": [{"text": "Done."}]}},
            "usage": {"inputTokens": 5, "outputTokens": 3, "totalTokens": 8},
        }

        # Simulate a conversation that previously used tools:
        # user → assistant (toolUse) → user (toolResult) → assistant → user
        messages: list[Message] = [
            {"role": "user", "content": "What's the weather?"},
            {"role": "assistant", "content": "Let me check."},
            {"role": "tool", "content": "Sunny, 72°F", "tool_name": "get_weather"},
            {"role": "assistant", "content": "It's sunny and 72°F."},
            {"role": "user", "content": "Thanks!"},
        ]

        await provider.complete(messages, tools=None)

        call_kwargs = client.converse.call_args[1]
        # Tool blocks are stripped rather than sending empty toolConfig
        assert "toolConfig" not in call_kwargs
        for msg in call_kwargs["messages"]:
            for block in msg.get("content", []):
                if isinstance(block, dict):
                    assert "toolUse" not in block
                    assert "toolResult" not in block

    @pytest.mark.asyncio
    async def test_complete_with_tools_uses_normal_tool_config(self) -> None:
        """When tools are explicitly passed, the normal toolConfig is used."""
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "usage": {"inputTokens": 1, "outputTokens": 1, "totalTokens": 2},
        }

        tools = [{"name": "search", "description": "Search", "parameters": {}}]
        await provider.complete(_USER_MSG, tools=tools)

        call_kwargs = client.converse.call_args[1]
        assert "toolConfig" in call_kwargs
        assert len(call_kwargs["toolConfig"]["tools"]) == 1

    # -- stream() ------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_stream_no_tools_no_tool_blocks_omits_tool_config(self) -> None:
        """Plain streaming without tool history should not send toolConfig."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "hi"}}},
                {"metadata": {"usage": {"inputTokens": 1, "outputTokens": 1}}},
            ],
        }

        await _collect_stream(provider, _USER_MSG, tools=None)

        call_kwargs = client.converse_stream.call_args[1]
        assert "toolConfig" not in call_kwargs

    @pytest.mark.asyncio
    async def test_stream_no_tools_with_tool_blocks_strips_tool_blocks(
        self,
    ) -> None:
        """Streaming follow-up with tool history strips tool blocks."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "Sure."}}},
                {"metadata": {"usage": {"inputTokens": 5, "outputTokens": 2}}},
            ],
        }

        messages: list[Message] = [
            {"role": "user", "content": "Search for cats"},
            {"role": "assistant", "content": "Searching..."},
            {"role": "tool", "content": "Found 10 results", "tool_name": "search"},
            {"role": "assistant", "content": "Here are the results."},
            {"role": "user", "content": "Tell me more"},
        ]

        await _collect_stream(provider, messages, tools=None)

        call_kwargs = client.converse_stream.call_args[1]
        # Tool blocks are stripped rather than sending empty toolConfig
        assert "toolConfig" not in call_kwargs
        for msg in call_kwargs["messages"]:
            for block in msg.get("content", []):
                if isinstance(block, dict):
                    assert "toolUse" not in block
                    assert "toolResult" not in block

    @pytest.mark.asyncio
    async def test_stream_with_tools_uses_normal_tool_config(self) -> None:
        """When tools are passed to stream(), normal toolConfig is used."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "ok"}}},
                {"metadata": {"usage": {"inputTokens": 1, "outputTokens": 1}}},
            ],
        }

        tools = [{"name": "search", "description": "Search", "parameters": {}}]
        await _collect_stream(provider, _USER_MSG, tools=tools)

        call_kwargs = client.converse_stream.call_args[1]
        assert "toolConfig" in call_kwargs
        assert len(call_kwargs["toolConfig"]["tools"]) == 1


