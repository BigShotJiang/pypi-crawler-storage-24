"""Unit tests for the ``synth agents`` CLI commands.

Covers list, status, start, and stop subcommands with mocked registry
and subprocess calls.

Requirements: 2.1, 2.3, 2.4, 3.1, 3.2, 3.3, 4.3, 4.4, 4.5, 4.6
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from synth.cli.agents_cmd import agents_group
from synth.cli.registry import RegistryRecord


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sample_record(name: str = "my_agent") -> RegistryRecord:
    return RegistryRecord(
        agent_name=name,
        region="us-west-2",
        model_id="anthropic.claude-sonnet-4-20250514",
        source_file="agent.py",
        deployed_at="2025-01-15T10:30:00+00:00",
        aws_profile="dev-profile",
    )


def _mock_store(agents: list[RegistryRecord] | None = None):
    """Return a mock RegistryStore with controlled data."""
    store = MagicMock()
    agent_list = agents or []
    store.list_agents.return_value = agent_list
    store.get_agent.side_effect = lambda n: next(
        (a for a in agent_list if a.agent_name == n), None
    )
    return store


# ---------------------------------------------------------------------------
# TestAgentsListCmd
# ---------------------------------------------------------------------------


class TestAgentsListCmd:
    """Tests for ``synth agents list``."""

    def test_list_empty_registry(self):
        """Shows 'No agents registered' when registry is empty."""
        runner = CliRunner()
        store = _mock_store([])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store):
            result = runner.invoke(agents_group, ["list"])

        assert result.exit_code == 0
        assert "No agents registered" in result.output

    def test_list_with_agents(self):
        """Shows table with agent data when agents exist."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._query_live_status", return_value={}):
            result = runner.invoke(agents_group, ["list"])

        assert result.exit_code == 0
        assert "my_agent" in result.output
        assert "us-west-2" in result.output
        assert "1 agent(s) found" in result.output

    def test_list_agentcore_unavailable(self):
        """Shows 'unknown' status when _query_live_status returns empty."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._query_live_status", return_value={}):
            result = runner.invoke(agents_group, ["list"])

        assert result.exit_code == 0
        assert "unknown" in result.output


# ---------------------------------------------------------------------------
# TestAgentsStatusCmd
# ---------------------------------------------------------------------------


class TestAgentsStatusCmd:
    """Tests for ``synth agents status <name>``."""

    def test_status_found(self):
        """Displays all fields for a known agent."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])
        live = {"my_agent": {"status": "active", "agent_id": "abc123"}}

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._query_live_status", return_value=live):
            result = runner.invoke(agents_group, ["status", "my_agent"])

        assert result.exit_code == 0
        assert "my_agent" in result.output
        assert "us-west-2" in result.output
        assert "anthropic.claude-sonnet-4-20250514" in result.output
        assert "agent.py" in result.output
        assert "2025-01-15T10:30:00+00:00" in result.output
        assert "dev-profile" in result.output
        assert "active" in result.output

    def test_status_not_found(self):
        """Shows error with available names when agent not in registry."""
        runner = CliRunner()
        existing = _sample_record("other_agent")
        store = _mock_store([existing])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store):
            result = runner.invoke(agents_group, ["status", "missing_agent"])

        assert result.exit_code != 0
        assert "missing_agent" in result.output
        assert "not found" in result.output
        assert "other_agent" in result.output

    def test_status_expired_credentials(self):
        """Shows credential refresh message on expired AWS credentials."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])

        from synth.cli.agents_cmd import _CredentialExpiredError

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._query_live_status", return_value={}), \
             patch(
                 "synth.cli.agents_cmd._probe_credentials",
                 side_effect=_CredentialExpiredError(),
             ):
            result = runner.invoke(agents_group, ["status", "my_agent"])

        assert result.exit_code != 0
        assert "AWS session expired" in result.output
        assert "aws login" in result.output


# ---------------------------------------------------------------------------
# TestAgentsStartStopCmd
# ---------------------------------------------------------------------------


class TestAgentsStartStopCmd:
    """Tests for ``synth agents start`` and ``synth agents stop``."""

    def test_start_success(self):
        """Prints [  OK  ] when subprocess returns 0."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])
        proc = MagicMock(returncode=0, stdout="", stderr="")

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._find_agentcore_bin", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", return_value=proc):
            result = runner.invoke(agents_group, ["start", "my_agent"])

        assert result.exit_code == 0
        assert "[  OK  ]" in result.output
        assert "started successfully" in result.output

    def test_stop_success(self):
        """Prints [  OK  ] when subprocess returns 0."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])
        proc = MagicMock(returncode=0, stdout="", stderr="")

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._find_agentcore_bin", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", return_value=proc):
            result = runner.invoke(agents_group, ["stop", "my_agent"])

        assert result.exit_code == 0
        assert "[  OK  ]" in result.output
        assert "stopped successfully" in result.output

    def test_start_agent_not_found(self):
        """Shows error with available names when agent not in registry."""
        runner = CliRunner()
        existing = _sample_record("other_agent")
        store = _mock_store([existing])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store):
            result = runner.invoke(agents_group, ["start", "missing_agent"])

        assert result.exit_code != 0
        assert "missing_agent" in result.output
        assert "not found" in result.output
        assert "other_agent" in result.output

    def test_stop_agent_not_found(self):
        """Shows error with available names when agent not in registry."""
        runner = CliRunner()
        existing = _sample_record("other_agent")
        store = _mock_store([existing])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store):
            result = runner.invoke(agents_group, ["stop", "missing_agent"])

        assert result.exit_code != 0
        assert "missing_agent" in result.output
        assert "not found" in result.output
        assert "other_agent" in result.output

    def test_start_agentcore_cli_not_found(self):
        """Shows install suggestion when agentcore binary is missing."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._find_agentcore_bin", return_value=None):
            result = runner.invoke(agents_group, ["start", "my_agent"])

        assert result.exit_code != 0
        assert "AgentCore CLI not found" in result.output
        assert "pip install bedrock-agentcore-starter-toolkit" in result.output

    def test_stop_agentcore_cli_not_found(self):
        """Shows install suggestion when agentcore binary is missing."""
        runner = CliRunner()
        rec = _sample_record("my_agent")
        store = _mock_store([rec])

        with patch("synth.cli.agents_cmd.RegistryStore", return_value=store), \
             patch("synth.cli.agents_cmd._find_agentcore_bin", return_value=None):
            result = runner.invoke(agents_group, ["stop", "my_agent"])

        assert result.exit_code != 0
        assert "AgentCore CLI not found" in result.output
        assert "pip install bedrock-agentcore-starter-toolkit" in result.output
