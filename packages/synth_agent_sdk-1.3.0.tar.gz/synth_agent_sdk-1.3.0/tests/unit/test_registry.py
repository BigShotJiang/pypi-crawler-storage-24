"""Unit tests for the agent registry store and error classes.

Covers RegistryStore CRUD operations, file permissions, malformed JSON
recovery, missing-field filtering, and the RegistryError hierarchy.

Requirements: 1.2, 1.4, 8.1, 8.2, 8.3
"""

from __future__ import annotations

import json
import os
import stat
import sys

import pytest

from synth.cli.registry import (
    RegistryData,
    RegistryRecord,
    RegistryStore,
    ServerInfo,
)
from synth.errors import RegistryError, SynthError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sample_record(name: str = "my_agent", **overrides) -> RegistryRecord:
    defaults = dict(
        agent_name=name,
        region="us-west-2",
        model_id="anthropic.claude-sonnet-4-20250514",
        source_file="agent.py",
        deployed_at="2025-01-15T10:30:00+00:00",
        aws_profile="dev-profile",
    )
    defaults.update(overrides)
    return RegistryRecord(**defaults)


def _sample_server() -> ServerInfo:
    return ServerInfo(pid=12345, port=8420, started_at="2025-01-15T10:00:00+00:00")


# ---------------------------------------------------------------------------
# TestRegistryStore
# ---------------------------------------------------------------------------


class TestRegistryStore:
    """CRUD operations on the registry file using a temp directory."""

    def test_add_agent_creates_file(self, tmp_path):
        """Adding an agent to a fresh store creates the registry file."""
        path = tmp_path / "registry.json"
        store = RegistryStore(path=path)

        assert not path.exists()
        store.add_agent(_sample_record())
        assert path.exists()

    @pytest.mark.skipif(sys.platform == "win32", reason="Unix permissions")
    def test_add_agent_file_permissions(self, tmp_path):
        """The registry file is created with owner-only permissions (0o600)."""
        path = tmp_path / "registry.json"
        store = RegistryStore(path=path)

        store.add_agent(_sample_record())
        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600

    def test_get_agent_not_found(self, tmp_path):
        """get_agent returns None for a name that doesn't exist."""
        store = RegistryStore(path=tmp_path / "registry.json")
        assert store.get_agent("nonexistent") is None

    def test_remove_agent_not_found(self, tmp_path):
        """remove_agent returns False for a name that doesn't exist."""
        store = RegistryStore(path=tmp_path / "registry.json")
        assert store.remove_agent("nonexistent") is False

    def test_load_malformed_json_creates_backup(self, tmp_path):
        """Corrupted JSON triggers a .bak backup and returns empty data."""
        path = tmp_path / "registry.json"
        path.write_text("{bad json!!", encoding="utf-8")

        store = RegistryStore(path=path)
        data = store.load()

        assert data.agents == []
        assert data.server is None

        backup = path.with_suffix(".json.bak")
        assert backup.exists()
        assert backup.read_text(encoding="utf-8") == "{bad json!!"

    def test_load_missing_fields_skips_record(self, tmp_path):
        """Records missing required fields are silently skipped."""
        path = tmp_path / "registry.json"
        payload = {
            "agents": [
                {"agent_name": "good", "region": "us-east-1", "model_id": "m",
                 "source_file": "a.py", "deployed_at": "2025-01-01T00:00:00"},
                {"agent_name": "bad"},  # missing required fields
            ],
            "server": None,
        }
        path.write_text(json.dumps(payload), encoding="utf-8")

        store = RegistryStore(path=path)
        data = store.load()

        assert len(data.agents) == 1
        assert data.agents[0].agent_name == "good"

    def test_empty_registry_list(self, tmp_path):
        """list_agents returns an empty list when no agents are stored."""
        store = RegistryStore(path=tmp_path / "registry.json")
        assert store.list_agents() == []

    def test_load_missing_file_returns_empty(self, tmp_path):
        """Loading from a non-existent file returns empty RegistryData."""
        store = RegistryStore(path=tmp_path / "registry.json")
        data = store.load()

        assert data.agents == []
        assert data.server is None

    def test_upsert_replaces_existing(self, tmp_path):
        """add_agent with the same name replaces the existing record."""
        store = RegistryStore(path=tmp_path / "registry.json")

        store.add_agent(_sample_record("agent_a", region="us-east-1"))
        store.add_agent(_sample_record("agent_a", region="eu-west-1"))

        agents = store.list_agents()
        assert len(agents) == 1
        assert agents[0].region == "eu-west-1"

    def test_server_info_crud(self, tmp_path):
        """set_server, get_server, and clear_server work correctly."""
        store = RegistryStore(path=tmp_path / "registry.json")

        # Initially no server
        assert store.get_server() is None

        # Set server
        info = _sample_server()
        store.set_server(info)
        loaded = store.get_server()
        assert loaded is not None
        assert loaded.pid == info.pid
        assert loaded.port == info.port
        assert loaded.started_at == info.started_at

        # Clear server
        store.clear_server()
        assert store.get_server() is None


# ---------------------------------------------------------------------------
# TestRegistryError
# ---------------------------------------------------------------------------


class TestRegistryError:
    """RegistryError hierarchy and constructor kwargs."""

    def test_inherits_synth_error(self):
        """RegistryError is a subclass of SynthError."""
        assert issubclass(RegistryError, SynthError)

    def test_accepts_component_and_suggestion(self):
        """Constructor kwargs component and suggestion are stored."""
        err = RegistryError(
            "Cannot write to registry file",
            component="AgentRegistry",
            suggestion="Check file permissions",
        )
        assert str(err) == "Cannot write to registry file"
        assert err.component == "AgentRegistry"
        assert err.suggestion == "Check file permissions"
