"""Unit tests for agent registry API endpoints in server.py.

Tests the GET /api/agents, POST /api/agents/{name}/start,
POST /api/agents/{name}/stop, and POST /api/agents/{name}/connect
endpoints defined in ``synth/cli/_ui_assets/server.py``.

Requirements: 5.2, 5.3, 5.4, 5.5
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import httpx
import pytest

from synth.cli.registry import RegistryRecord, RegistryStore


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sample_record(name: str = "my_agent") -> RegistryRecord:
    """Create a sample registry record for testing."""
    return RegistryRecord(
        agent_name=name,
        region="us-west-2",
        model_id="anthropic.claude-sonnet-4-20250514",
        source_file="agent.py",
        deployed_at="2025-01-15T10:30:00+00:00",
        aws_profile="dev-profile",
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _ensure_static_dir() -> None:
    """Ensure the static assets directory exists so the FastAPI app imports."""
    import synth.cli as _cli_pkg

    static_dir = (
        Path(_cli_pkg.__file__).parent / "_ui_assets" / "static"
    )
    static_dir.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Test class
# ---------------------------------------------------------------------------

class TestAgentsAPI:
    """Tests for the /api/agents endpoints."""

    @pytest.mark.asyncio
    async def test_get_agents_empty_registry(self, tmp_path: Path) -> None:
        """GET /api/agents returns an empty JSON array when no agents exist."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli.discover._query_agentcore_cli",
            return_value={},
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.get("/api/agents")

        assert resp.status_code == 200
        assert resp.json() == []

    @pytest.mark.asyncio
    async def test_get_agents_populated(self, tmp_path: Path) -> None:
        """GET /api/agents returns all agents with correct fields."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        rec_a = _sample_record("agent_alpha")
        rec_b = _sample_record("agent_beta")
        store.add_agent(rec_a)
        store.add_agent(rec_b)

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli.discover._query_agentcore_cli",
            return_value={},
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.get("/api/agents")

        assert resp.status_code == 200
        body = resp.json()
        assert len(body) == 2

        names = {entry["agent_name"] for entry in body}
        assert names == {"agent_alpha", "agent_beta"}

        for entry in body:
            assert "region" in entry
            assert "model_id" in entry
            assert "source_file" in entry
            assert "deployed_at" in entry
            assert "aws_profile" in entry
            assert "status" in entry
            assert entry["status"] == "unknown"

    @pytest.mark.asyncio
    async def test_start_agent_success(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/start returns success on subprocess ok."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        store.add_agent(_sample_record("my_agent"))

        cmd_result = {"success": True, "message": "Agent launch succeeded"}

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._run_agentcore_cmd",
            return_value=cmd_result,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/my_agent/start")

        assert resp.status_code == 200
        body = resp.json()
        assert body["success"] is True
        assert "launch" in body["message"].lower() or "succeeded" in body["message"].lower()

    @pytest.mark.asyncio
    async def test_start_agent_not_found(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/start returns 404 for unknown agent."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/nonexistent/start")

        assert resp.status_code == 404
        body = resp.json()
        assert body["success"] is False
        assert "not found" in body["message"].lower()

    @pytest.mark.asyncio
    async def test_stop_agent_success(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/stop returns success on subprocess ok."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        store.add_agent(_sample_record("my_agent"))

        cmd_result = {"success": True, "message": "Agent stop succeeded"}

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._run_agentcore_cmd",
            return_value=cmd_result,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/my_agent/stop")

        assert resp.status_code == 200
        body = resp.json()
        assert body["success"] is True

    @pytest.mark.asyncio
    async def test_stop_agent_not_found(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/stop returns 404 for unknown agent."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/ghost/stop")

        assert resp.status_code == 404
        body = resp.json()
        assert body["success"] is False
        assert "not found" in body["message"].lower()

    @pytest.mark.asyncio
    async def test_connect_agent(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/connect sets _remote_agent state."""
        import synth.cli._ui_assets.server as server_mod
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        store.add_agent(_sample_record("my_agent"))

        # Reset state before test
        server_mod._remote_agent = None

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/my_agent/connect")

        assert resp.status_code == 200
        body = resp.json()
        assert body["success"] is True
        assert "my_agent" in body["message"]

        # Verify module-level state was set
        assert server_mod._remote_agent is not None
        assert server_mod._remote_agent["name"] == "my_agent"
        assert server_mod._remote_agent["region"] == "us-west-2"
        assert server_mod._remote_agent["aws_profile"] == "dev-profile"

        # Clean up
        server_mod._remote_agent = None
