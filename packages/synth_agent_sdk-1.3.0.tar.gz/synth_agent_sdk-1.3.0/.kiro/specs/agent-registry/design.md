# Design Document: Agent Registry

## Overview

The Agent Registry feature introduces persistent tracking of deployed agents, CLI management commands, browser UI integration, and a daemonized UI server. The core architectural addition is a local JSON registry file (`~/.synth/registry.json`) that serves as the single source of truth for deployment metadata. All other components — CLI commands, API endpoints, and UI — read from and write to this registry.

The design follows existing SDK patterns: dataclasses for internal types, Click for CLI commands, FastAPI for UI endpoints, and `SynthError` subclasses for error handling. AWS credentials are never stored — only profile names are persisted.

## Architecture

```mermaid
graph TD
    subgraph CLI Layer
        DW[Deploy Wizard<br>deploy_cmd.py] -->|writes| REG
        AC[synth agents<br>agents_cmd.py] -->|reads/writes| REG
        UI_CMD[synth ui<br>main.py] -->|manages| SRV
    end

    subgraph Data Layer
        REG[Agent Registry<br>~/.synth/registry.json]
    end

    subgraph UI Layer
        SRV[UI Server<br>server.py] -->|reads/writes| REG
        SRV -->|serves| TAB[Agents Tab<br>index.html]
    end

    subgraph External
        AGC[AgentCore CLI<br>agentcore binary]
        AWS[AWS Credentials<br>~/.aws/]
    end

    AC -->|invokes| AGC
    SRV -->|invokes| AGC
    AC -->|resolves via| AWS
    SRV -->|resolves via| AWS
    DW -->|invokes| AGC
```

### Key Design Decisions

1. **File-based registry over SQLite**: JSON file is simpler, human-readable, and consistent with the existing `conversations.json` pattern in the UI server. The registry will hold at most dozens of records, so performance is not a concern.

2. **Registry module as a standalone library**: `synth/cli/registry.py` owns all CRUD operations. Both CLI commands and the UI server import from it, avoiding duplication.

3. **Daemonized UI server**: The current `subprocess.run()` blocks the terminal. Switching to a daemon process with PID tracking in the registry allows reconnection across terminal sessions.

4. **Reuse of existing `_query_agentcore_cli` and `_parse_agentcore_list`**: The discover module already has the logic for querying AgentCore status. The agents CLI and UI endpoints delegate to these functions rather than reimplementing.

## Components and Interfaces

### 1. Registry Module (`synth/cli/registry.py`)

The central module for all registry operations. Provides a `RegistryStore` class with CRUD methods.

```python
@dataclass
class RegistryRecord:
    """A single deployed agent entry."""
    agent_name: str
    region: str
    model_id: str
    source_file: str
    deployed_at: str          # ISO 8601
    aws_profile: str | None

@dataclass
class ServerInfo:
    """Tracks a running UI server daemon."""
    pid: int
    port: int
    started_at: str           # ISO 8601

@dataclass
class RegistryData:
    """Top-level registry file structure."""
    agents: list[RegistryRecord] = field(default_factory=list)
    server: ServerInfo | None = None

class RegistryStore:
    """CRUD operations on ~/.synth/registry.json."""

    def __init__(self, path: Path | None = None) -> None: ...
    def load(self) -> RegistryData: ...
    def save(self, data: RegistryData) -> None: ...
    def add_agent(self, record: RegistryRecord) -> None: ...
    def get_agent(self, name: str) -> RegistryRecord | None: ...
    def remove_agent(self, name: str) -> bool: ...
    def list_agents(self) -> list[RegistryRecord]: ...
    def set_server(self, info: ServerInfo) -> None: ...
    def get_server(self) -> ServerInfo | None: ...
    def clear_server(self) -> None: ...
```

File permissions: `save()` creates the file with `os.open(..., 0o600)` on first write, and uses `os.chmod()` to enforce permissions on subsequent writes.

Upsert semantics: `add_agent()` replaces any existing record with the same `agent_name`.

### 2. CLI Commands (`synth/cli/agents_cmd.py`)

A Click command group registered on the root `cli` group in `main.py`.

```python
@cli.group("agents")
def agents_group() -> None:
    """Manage deployed AgentCore agents."""

@agents_group.command("list")
def agents_list_cmd() -> None: ...

@agents_group.command("status")
@click.argument("name")
def agents_status_cmd(name: str) -> None: ...

@agents_group.command("start")
@click.argument("name")
def agents_start_cmd(name: str) -> None: ...

@agents_group.command("stop")
@click.argument("name")
def agents_stop_cmd(name: str) -> None: ...
```

Status enrichment: `agents_list_cmd` calls `_query_agentcore_cli` from `discover.py` to get live status, falling back to "unknown" on failure.

Start/stop: Locate the `agentcore` binary using the same `shutil.which()` + fallback pattern from `deploy_cmd.py`. Build a subprocess command with `AWS_PROFILE` injected into the environment.

Output formatting: Uses `_print_stage_result` pattern from `deploy_cmd.py` for `[  OK  ]`/`[FAIL]` lines.

### 3. Deploy Wizard Integration (`synth/cli/deploy_cmd.py`)

After `_stage_submit` returns successfully, the `run_deploy` function calls `RegistryStore.add_agent()` with the metadata from `StageResult.data`:

```python
# In run_deploy(), after successful _stage_submit:
from synth.cli.registry import RegistryStore, RegistryRecord
from datetime import datetime, timezone

store = RegistryStore()
store.add_agent(RegistryRecord(
    agent_name=submit_result.data["agent_name"],
    region=submit_result.data["region"],
    model_id=submit_result.data["model_id"],
    source_file=file,
    deployed_at=datetime.now(timezone.utc).isoformat(),
    aws_profile=aws_profile,
))
```

### 4. UI Server Endpoints (`synth/cli/_ui_assets/server.py`)

New FastAPI endpoints added to the existing `app`:

```python
@app.get("/api/agents")
async def list_agents() -> JSONResponse: ...

@app.post("/api/agents/{name}/start")
async def start_agent(name: str) -> JSONResponse: ...

@app.post("/api/agents/{name}/stop")
async def stop_agent(name: str) -> JSONResponse: ...

@app.post("/api/agents/{name}/connect")
async def connect_agent(name: str) -> JSONResponse: ...
```

The `/api/agents` endpoint reads the registry, then enriches each record with live status by calling `_query_agentcore_cli`. Start/stop endpoints run `agentcore launch`/`agentcore stop` via `asyncio.get_event_loop().run_in_executor()` to avoid blocking the event loop.

The `/api/agents/{name}/connect` endpoint sets a module-level `_remote_agent` variable. When set, the `/api/chat/stream` endpoint routes prompts through the AgentCore invocation API (via `GatewayMCPClient` from `synth/deploy/agentcore/gateway.py`) instead of the local agent.

### 5. UI Server Daemonization (`synth/cli/main.py`)

The `ui_cmd` function is modified to:

1. Check the registry for an existing `ServerInfo` with a live PID.
2. If alive and port responsive, open the browser and return.
3. Otherwise, fork a daemon process running uvicorn, store PID/port in registry, and open the browser.

Daemon approach: Use `subprocess.Popen` with `start_new_session=True` (Unix) or `CREATE_NEW_PROCESS_GROUP` (Windows) so the child survives parent exit. Redirect stdout/stderr to `~/.synth/ui-server.log`.

### 6. Agents Tab UI (`synth/cli/_ui_assets/static/index.html`)

A new tab in the existing tab bar. Renders agent cards by fetching `GET /api/agents` on tab activation. Each card shows:
- Agent name (heading)
- Region badge
- Status indicator (green dot = running, red dot = stopped, yellow dot = unknown)
- Model ID
- Deploy date (relative, e.g. "2 hours ago")
- Start/Stop button (toggles based on status)
- Connect button (switches chat to remote agent)

### 7. Error Types (`synth/errors.py`)

```python
class RegistryError(SynthError):
    """Raised when a registry operation fails."""
```

Follows the existing pattern: accepts `message`, `component`, and `suggestion` kwargs.

## Data Models

### Registry File Schema (`~/.synth/registry.json`)

```json
{
  "agents": [
    {
      "agent_name": "my_agent",
      "region": "us-west-2",
      "model_id": "anthropic.claude-sonnet-4-20250514",
      "source_file": "agent.py",
      "deployed_at": "2025-01-15T10:30:00+00:00",
      "aws_profile": "dev-profile"
    }
  ],
  "server": {
    "pid": 12345,
    "port": 8420,
    "started_at": "2025-01-15T10:00:00+00:00"
  }
}
```

### RegistryRecord Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| agent_name | str | Yes | Unique agent identifier (matches AgentCore name) |
| region | str | Yes | AWS region of deployment |
| model_id | str | Yes | Bedrock model ID |
| source_file | str | Yes | Path to the agent Python file |
| deployed_at | str | Yes | ISO 8601 UTC timestamp |
| aws_profile | str \| None | No | AWS profile name used for deployment |

### ServerInfo Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| pid | int | Yes | OS process ID of the daemon |
| port | int | Yes | TCP port the server listens on |
| started_at | str | Yes | ISO 8601 UTC timestamp |

### Serialization

`RegistryStore.save()` serializes `RegistryData` to JSON using `dataclasses.asdict()` and `json.dumps(indent=2)`. `RegistryStore.load()` deserializes using `json.loads()` and constructs dataclass instances from the parsed dicts. Unknown keys are ignored for forward compatibility.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

The following properties were derived from the acceptance criteria in the requirements document. Each property is universally quantified and suitable for property-based testing with Hypothesis.

### Property 1: Registry data round-trip

*For any* valid `RegistryData` object (containing any number of `RegistryRecord` entries and an optional `ServerInfo`), serializing to JSON via `RegistryStore.save()` then deserializing via `RegistryStore.load()` SHALL produce an equivalent `RegistryData` object.

**Validates: Requirements 1.6, 1.7, 7.2**

### Property 2: Add-then-get consistency

*For any* valid `RegistryRecord`, after calling `RegistryStore.add_agent(record)`, calling `RegistryStore.get_agent(record.agent_name)` SHALL return a record equivalent to the one that was added.

**Validates: Requirements 1.1**

### Property 3: Upsert deduplication

*For any* two valid `RegistryRecord` objects sharing the same `agent_name` but differing in other fields, adding the first then adding the second SHALL result in `list_agents()` containing exactly one record with that name, and that record SHALL match the second (most recent) record's data.

**Validates: Requirements 1.3**

### Property 4: Remove-then-get absence

*For any* valid `RegistryRecord` that has been added to the registry, after calling `RegistryStore.remove_agent(record.agent_name)`, calling `RegistryStore.get_agent(record.agent_name)` SHALL return `None`, and the total count of agents SHALL decrease by one.

**Validates: Requirements 1.5**

### Property 5: Validation rejects incomplete records

*For any* JSON dict that is missing one or more of the required fields (`agent_name`, `region`, `model_id`, `source_file`, `deployed_at`), the registry loader SHALL either skip the malformed record or raise a validation error, and SHALL NOT produce a `RegistryRecord` with `None` in required fields.

**Validates: Requirements 1.4**

### Property 6: CLI list output contains all agents

*For any* list of valid `RegistryRecord` objects stored in the registry, the formatted output of the `agents list` command SHALL contain every agent's `agent_name` and `region`.

**Validates: Requirements 2.1**

### Property 7: CLI status output contains all fields

*For any* valid `RegistryRecord`, the formatted output of `agents status <name>` SHALL contain the record's `agent_name`, `region`, `model_id`, `source_file`, `deployed_at`, and `aws_profile` values.

**Validates: Requirements 3.1**

### Property 8: API response contains all agents

*For any* list of valid `RegistryRecord` objects stored in the registry, the JSON response from `GET /api/agents` SHALL contain an entry for every agent, and each entry SHALL include the agent's `agent_name` and `region`.

**Validates: Requirements 5.2**

### Property 9: No credentials in serialized registry

*For any* valid `RegistryData` object, the JSON string produced by serialization SHALL NOT contain any substring matching AWS access key patterns (`AKIA[A-Z0-9]{16}` or `ASIA[A-Z0-9]{16}`) or 40-character base64-like secret key patterns.

**Validates: Requirements 6.1**

## Error Handling

### RegistryError

A new `RegistryError(SynthError)` class in `synth/errors.py` for all registry-specific failures:

| Scenario | Message | Component | Suggestion |
|----------|---------|-----------|------------|
| Malformed JSON | "Registry file contains invalid JSON" | "AgentRegistry" | "The corrupted file has been backed up. A fresh registry was created." |
| Permission denied | "Cannot write to registry file: {path}" | "AgentRegistry" | "Check file permissions: chmod 600 {path}" |
| Missing agent | "Agent '{name}' not found in registry" | "AgentRegistry" | "Available agents: {names}. Run `synth deploy` to register a new agent." |

### Credential Expiry

When `_query_agentcore_cli` or subprocess calls fail with credential-related errors (detected by checking for "expired", "token", or "credentials" in the error message), the CLI displays:

```
AWS session expired. Run `aws login` to refresh your credentials.
```

### Corrupted Registry Recovery

When `json.loads()` raises `JSONDecodeError` during `load()`:

1. Copy the corrupted file to `~/.synth/registry.json.bak`
2. Log a warning via `click.echo()`
3. Return an empty `RegistryData()`
4. The next `save()` call overwrites with valid JSON

### AgentCore CLI Not Found

When `shutil.which("agentcore")` returns `None` and the fallback path check also fails, raise or display:

```
AgentCore CLI not found. Install it with: pip install bedrock-agentcore-starter-toolkit
```

## Testing Strategy

### Unit Tests (`tests/unit/test_registry.py`)

- `TestRegistryStore`: CRUD operations with a temp directory
  - `test_add_agent_creates_file`: verify file creation on first add
  - `test_add_agent_file_permissions`: verify 0o600 mode on created file
  - `test_get_agent_not_found`: returns `None` for missing name
  - `test_remove_agent_not_found`: returns `False` for missing name
  - `test_load_malformed_json_creates_backup`: corrupted file recovery
  - `test_load_missing_fields_skips_record`: incomplete records filtered
  - `test_empty_registry_list`: empty list when no agents
- `TestRegistryError`: error class hierarchy
  - `test_inherits_synth_error`: `issubclass(RegistryError, SynthError)`
  - `test_accepts_component_and_suggestion`: constructor kwargs

### Unit Tests (`tests/unit/test_agents_cmd.py`)

- `TestAgentsListCmd`: CLI list command with mocked registry
  - `test_list_empty_registry`: shows "no agents" message
  - `test_list_with_agents`: shows table with agent data
  - `test_list_agentcore_unavailable`: shows "unknown" status
- `TestAgentsStatusCmd`: CLI status command
  - `test_status_found`: displays all fields
  - `test_status_not_found`: shows error with available names
  - `test_status_expired_credentials`: shows credential refresh message
- `TestAgentsStartStopCmd`: CLI start/stop commands
  - `test_start_success`: `[  OK  ]` output
  - `test_stop_success`: `[  OK  ]` output
  - `test_start_agent_not_found`: error with available names
  - `test_agentcore_cli_not_found`: install suggestion

### Property Tests (`tests/property/test_registry_props.py`)

Property-based tests using Hypothesis with minimum 100 iterations per property. Each test is tagged with its design property reference.

```python
# Feature: agent-registry, Property 1: Registry data round-trip
@given(registry_data=st.builds(RegistryData, ...))
@settings(max_examples=100)
def test_registry_round_trip(registry_data, tmp_path): ...

# Feature: agent-registry, Property 2: Add-then-get consistency
@given(record=st.builds(RegistryRecord, ...))
@settings(max_examples=100)
def test_add_then_get(record, tmp_path): ...

# Feature: agent-registry, Property 3: Upsert deduplication
@given(record1=..., record2=...)
@settings(max_examples=100)
def test_upsert_deduplication(record1, record2, tmp_path): ...

# Feature: agent-registry, Property 4: Remove-then-get absence
@given(record=st.builds(RegistryRecord, ...))
@settings(max_examples=100)
def test_remove_then_get(record, tmp_path): ...

# Feature: agent-registry, Property 5: Validation rejects incomplete records
@given(fields_to_drop=st.sets(st.sampled_from([...]), min_size=1))
@settings(max_examples=100)
def test_validation_rejects_incomplete(fields_to_drop, tmp_path): ...

# Feature: agent-registry, Property 6: CLI list output contains all agents
@given(records=st.lists(st.builds(RegistryRecord, ...), min_size=1))
@settings(max_examples=100)
def test_list_output_contains_all(records, tmp_path): ...

# Feature: agent-registry, Property 7: CLI status output contains all fields
@given(record=st.builds(RegistryRecord, ...))
@settings(max_examples=100)
def test_status_output_contains_fields(record, tmp_path): ...

# Feature: agent-registry, Property 8: API response contains all agents
@given(records=st.lists(st.builds(RegistryRecord, ...), min_size=1))
@settings(max_examples=100)
def test_api_response_contains_all(records, tmp_path): ...

# Feature: agent-registry, Property 9: No credentials in serialized registry
@given(registry_data=st.builds(RegistryData, ...))
@settings(max_examples=100)
def test_no_credentials_in_json(registry_data, tmp_path): ...
```

### Hypothesis Strategies

Custom strategies for generating valid `RegistryRecord` and `RegistryData` instances:

- `agent_name`: `st.text(alphabet=st.characters(whitelist_categories=('L', 'N'), whitelist_characters='_-'), min_size=1, max_size=48).filter(lambda s: s[0].isalpha())`
- `region`: `st.sampled_from(["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"])`
- `model_id`: `st.text(min_size=1, max_size=100).filter(lambda s: s.strip())`
- `source_file`: `st.text(min_size=1, max_size=200).filter(lambda s: s.strip())`
- `deployed_at`: `st.datetimes(timezones=st.just(timezone.utc)).map(lambda dt: dt.isoformat())`
- `aws_profile`: `st.one_of(st.none(), st.text(min_size=1, max_size=50).filter(lambda s: s.strip()))`

### Testing Library

- **Property-based testing**: Hypothesis (already used in the project — see `tests/property/` and `.hypothesis/` directory)
- **Test runner**: pytest
- **Async tests**: `@pytest.mark.asyncio` for FastAPI endpoint tests
- **CLI testing**: Click's `CliRunner` for command invocation tests
