# Implementation Plan: Agent Registry

## Overview

Incremental implementation starting with the core registry data layer, then CLI commands, deploy integration, UI endpoints, UI tab, and finally server daemonization. Each step builds on the previous and includes testing sub-tasks close to the implementation they validate.

## Tasks

- [x] 1. Create RegistryError and registry data models
  - [x] 1.1 Add `RegistryError` class to `synth/errors.py`
    - Subclass of `SynthError`, accepts `message`, `component`, `suggestion`
    - _Requirements: 8.2, 8.3_
  - [x] 1.2 Create `synth/cli/registry.py` with `RegistryRecord`, `ServerInfo`, and `RegistryData` dataclasses
    - Use `@dataclass`, `from __future__ import annotations`, `field(default_factory=list)`
    - `RegistryRecord` fields: agent_name, region, model_id, source_file, deployed_at, aws_profile (str | None)
    - `ServerInfo` fields: pid, port, started_at
    - `RegistryData` fields: agents (list[RegistryRecord]), server (ServerInfo | None)
    - _Requirements: 1.1, 1.6_
  - [x] 1.3 Implement `RegistryStore` class with `load()`, `save()`, `add_agent()`, `get_agent()`, `remove_agent()`, `list_agents()`, `set_server()`, `get_server()`, `clear_server()`
    - Default path: `~/.synth/registry.json`
    - `save()` creates file with `os.open(..., 0o600)` on first write
    - `load()` handles missing file (returns empty RegistryData), malformed JSON (backup + fresh), and missing fields (skip record)
    - `add_agent()` uses upsert semantics (replace by agent_name)
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 8.1_
  - [x] 1.4 Write property tests for registry data layer (`tests/property/test_registry_props.py`)
    - **Property 1: Registry data round-trip**
    - **Validates: Requirements 1.6, 1.7, 7.2**
    - **Property 2: Add-then-get consistency**
    - **Validates: Requirements 1.1**
    - **Property 3: Upsert deduplication**
    - **Validates: Requirements 1.3**
    - **Property 4: Remove-then-get absence**
    - **Validates: Requirements 1.5**
    - **Property 5: Validation rejects incomplete records**
    - **Validates: Requirements 1.4**
    - **Property 9: No credentials in serialized registry**
    - **Validates: Requirements 6.1**
  - [x] 1.5 Write unit tests for registry store (`tests/unit/test_registry.py`)
    - Test file creation and permissions (0o600)
    - Test malformed JSON backup and recovery
    - Test get/remove for non-existent agents
    - Test empty registry list
    - Test RegistryError inherits SynthError
    - _Requirements: 1.2, 1.4, 8.1, 8.2, 8.3_

- [x] 2. Checkpoint — Ensure all registry data layer tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Implement `synth agents` CLI commands
  - [x] 3.1 Create `synth/cli/agents_cmd.py` with Click command group and `list`, `status`, `start`, `stop` subcommands
    - `agents_group` registered on root `cli` in `main.py`
    - `list`: reads registry, queries AgentCore status via `_query_agentcore_cli` from `discover.py`, displays table with `[  OK  ]`/`[FAIL]` formatting
    - `status <name>`: displays all record fields + live status, handles missing agent with available names, handles expired credentials with `aws login` message
    - `start <name>`: locates `agentcore` binary, runs `agentcore launch` with stored region/profile, `[  OK  ]`/`[FAIL]` output
    - `stop <name>`: locates `agentcore` binary, runs `agentcore stop` with stored region/profile, `[  OK  ]`/`[FAIL]` output
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 3.1, 3.2, 3.3, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 6.2, 6.3_
  - [x] 3.2 Register `agents_group` in `synth/cli/main.py`
    - Import and add the command group to the root `cli`
    - _Requirements: 2.1_
  - [x] 3.3 Write property tests for CLI output (`tests/property/test_registry_props.py`)
    - **Property 6: CLI list output contains all agents**
    - **Validates: Requirements 2.1**
    - **Property 7: CLI status output contains all fields**
    - **Validates: Requirements 3.1**
  - [x] 3.4 Write unit tests for agents CLI (`tests/unit/test_agents_cmd.py`)
    - Test list with empty registry, list with agents, list with AgentCore unavailable
    - Test status found, status not found, status expired credentials
    - Test start/stop success, agent not found, agentcore CLI not found
    - Use Click's `CliRunner` and mock `RegistryStore` and subprocess calls
    - _Requirements: 2.1, 2.3, 2.4, 3.1, 3.2, 3.3, 4.3, 4.4, 4.5, 4.6_

- [x] 4. Integrate registry with deploy wizard
  - [x] 4.1 Modify `synth/cli/deploy_cmd.py` `run_deploy()` to call `RegistryStore.add_agent()` after successful `_stage_submit`
    - Extract agent_name, region, model_id from `StageResult.data`
    - Create `RegistryRecord` with current UTC timestamp and aws_profile
    - Wrap in try/except so registry failure doesn't break deployment
    - _Requirements: 1.1, 1.3_
  - [x] 4.2 Write unit test for deploy-registry integration (`tests/unit/test_deploy_wizard.py`)
    - Test that successful deploy writes to registry
    - Test that registry failure doesn't break deploy
    - _Requirements: 1.1_

- [x] 5. Checkpoint — Ensure all CLI and deploy integration tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Add UI server agent API endpoints
  - [x] 6.1 Add `GET /api/agents`, `POST /api/agents/{name}/start`, `POST /api/agents/{name}/stop`, `POST /api/agents/{name}/connect` endpoints to `synth/cli/_ui_assets/server.py`
    - `GET /api/agents`: reads registry, enriches with live status via `_query_agentcore_cli`, returns JSON array
    - `POST .../start`: runs `agentcore launch` via `run_in_executor`, returns success/failure JSON
    - `POST .../stop`: runs `agentcore stop` via `run_in_executor`, returns success/failure JSON
    - `POST .../connect`: sets module-level `_remote_agent` dict with agent name/region/profile, subsequent chat requests route through AgentCore invocation API
    - Add `_remote_agent` state variable and modify `/api/chat/stream` to check it
    - _Requirements: 5.2, 5.3, 5.4, 5.5, 5.6_
  - [x] 6.2 Write property test for API response completeness (`tests/property/test_registry_props.py`)
    - **Property 8: API response contains all agents**
    - **Validates: Requirements 5.2**
  - [x] 6.3 Write unit tests for agent API endpoints (`tests/unit/test_agents_api.py`)
    - Test GET /api/agents with empty and populated registry
    - Test start/stop endpoints with mocked subprocess
    - Test connect endpoint sets remote agent state
    - _Requirements: 5.2, 5.3, 5.4, 5.5_

- [x] 7. Add Agents tab to browser UI
  - [x] 7.1 Add "Agents" tab to the tab bar in `synth/cli/_ui_assets/static/index.html`
    - Add tab button alongside existing tabs
    - Add agents panel with card layout
    - JavaScript: fetch `GET /api/agents` on tab activation, render cards with name/region/status/model/date/buttons
    - Wire start/stop/connect buttons to POST endpoints
    - Show remote-agent indicator in chat tab when connected
    - _Requirements: 5.1, 5.6, 5.7_

- [x] 8. Implement UI server daemonization
  - [x] 8.1 Modify `ui_cmd` in `synth/cli/main.py` to daemonize the UI server
    - Check registry for existing `ServerInfo` with live PID (use `os.kill(pid, 0)`)
    - If alive and port responsive (HTTP GET to `/api/health`), open browser and return
    - Otherwise, start uvicorn via `subprocess.Popen(start_new_session=True)` with stdout/stderr redirected to `~/.synth/ui-server.log`
    - Store PID and port in registry via `RegistryStore.set_server()`
    - Open browser to `http://localhost:{port}`
    - _Requirements: 7.1, 7.2, 7.3, 7.4_
  - [x] 8.2 Write unit tests for server daemonization (`tests/unit/test_ui_daemon.py`)
    - Test detection of running server (mock os.kill and HTTP check)
    - Test new server start when no existing server
    - Test stale PID cleanup and restart
    - _Requirements: 7.2, 7.3, 7.4_

- [x] 9. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties using Hypothesis
- Unit tests validate specific examples and edge cases using pytest
- The registry module (`synth/cli/registry.py`) is the foundation — all other components depend on it
