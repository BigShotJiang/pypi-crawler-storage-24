# Requirements Document

## Introduction

The Agent Registry feature adds persistent agent tracking, CLI management commands, and browser UI integration to the Synth SDK. Currently, when a user closes the terminal after deploying an agent via `synth deploy`, all context about deployed agents is lost. This feature introduces a local JSON registry at `~/.synth/registry.json` that records deployment metadata, a `synth agents` CLI command group for listing, inspecting, starting, and stopping agents, an "Agents" tab in the browser UI for visual management, and a daemonized UI server that survives terminal close.

## Glossary

- **Agent_Registry**: The persistent JSON file at `~/.synth/registry.json` that stores deployment records for all agents deployed via `synth deploy`.
- **Registry_Record**: A single entry in the Agent_Registry containing agent metadata (name, region, model ID, source file, deploy timestamp, AWS profile).
- **Agent_CLI**: The `synth agents` Click command group providing `list`, `status`, `start`, and `stop` subcommands.
- **Agents_Tab**: The browser UI tab that displays deployed agent cards with status indicators and action buttons.
- **UI_Server**: The FastAPI-based local server (`server.py`) that serves the browser UI and agent management API endpoints.
- **AgentCore_CLI**: The external `agentcore` command-line tool used to configure, launch, list, and stop agents on AWS AgentCore Runtime.
- **Credential_Resolver**: The existing `CredentialResolver` class in `synth/deploy/agentcore/credentials.py` that resolves AWS credentials from multiple sources.
- **Deploy_Wizard**: The existing sequential stage runner in `synth/cli/deploy_cmd.py` that validates, packages, and submits agents to AgentCore.

## Requirements

### Requirement 1: Persistent Agent Registry Storage

**User Story:** As a developer, I want my deployed agent metadata to persist across terminal sessions, so that I can manage agents without re-deploying or remembering deployment details.

#### Acceptance Criteria

1. WHEN a successful deployment completes via the Deploy_Wizard, THE Agent_Registry SHALL append a new Registry_Record containing agent_name, region, model_id, source_file path, deployed_at ISO 8601 timestamp, and aws_profile to the registry file at `~/.synth/registry.json`.
2. WHEN the Agent_Registry file does not exist, THE Agent_Registry SHALL create the file with owner-only read/write permissions (mode 0o600).
3. WHEN an agent with the same name already exists in the Agent_Registry, THE Agent_Registry SHALL update the existing Registry_Record with the new deployment metadata instead of creating a duplicate.
4. WHEN a Registry_Record is read from the Agent_Registry, THE Agent_Registry SHALL validate that all required fields (agent_name, region, model_id, source_file, deployed_at, aws_profile) are present.
5. WHEN a user explicitly deletes an agent, THE Agent_Registry SHALL remove the corresponding Registry_Record from the registry file.
6. THE Agent_Registry SHALL serialize Registry_Records to JSON and deserialize Registry_Records from JSON.
7. FOR ALL valid Registry_Record objects, serializing to JSON then deserializing from JSON SHALL produce an equivalent Registry_Record (round-trip property).

### Requirement 2: CLI Agent List Command

**User Story:** As a developer, I want to list all my deployed agents from the terminal, so that I can see their names, regions, statuses, and deployment dates at a glance.

#### Acceptance Criteria

1. WHEN a user runs `synth agents list`, THE Agent_CLI SHALL read all Registry_Records from the Agent_Registry and display them in a formatted table with columns for name, region, status, and deployed date.
2. WHEN displaying agent status, THE Agent_CLI SHALL query the AgentCore_CLI for live status of each agent using the stored region and aws_profile.
3. WHEN the AgentCore_CLI is unavailable or the query fails, THE Agent_CLI SHALL display "unknown" as the status instead of raising an error.
4. WHEN the Agent_Registry is empty, THE Agent_CLI SHALL display a message indicating no agents are registered and suggest using `synth deploy`.
5. WHEN displaying output, THE Agent_CLI SHALL use the `[  OK  ]`/`[FAIL]` formatting pattern consistent with existing CLI commands.

### Requirement 3: CLI Agent Status Command

**User Story:** As a developer, I want to view detailed information about a specific deployed agent, so that I can inspect its model, region, profile, and configuration.

#### Acceptance Criteria

1. WHEN a user runs `synth agents status <name>`, THE Agent_CLI SHALL display the agent's name, region, model_id, source_file, deployed_at, aws_profile, and live AgentCore status.
2. WHEN the specified agent name does not exist in the Agent_Registry, THE Agent_CLI SHALL display an error message listing available agent names.
3. WHEN AWS credentials for the stored profile are expired, THE Agent_CLI SHALL display the message "AWS session expired. Run `aws login` to refresh your credentials."

### Requirement 4: CLI Agent Start and Stop Commands

**User Story:** As a developer, I want to start and stop deployed agents from the terminal, so that I can control agent lifecycle without using the AWS console.

#### Acceptance Criteria

1. WHEN a user runs `synth agents start <name>`, THE Agent_CLI SHALL execute `agentcore launch` using the agent_name, region, and aws_profile stored in the Registry_Record.
2. WHEN a user runs `synth agents stop <name>`, THE Agent_CLI SHALL execute `agentcore stop` using the agent_name, region, and aws_profile stored in the Registry_Record.
3. WHEN the specified agent name does not exist in the Agent_Registry, THE Agent_CLI SHALL display an error message listing available agent names.
4. WHEN the AgentCore_CLI binary is not found on the system PATH, THE Agent_CLI SHALL display an error with the suggestion "Install it with: pip install bedrock-agentcore-starter-toolkit".
5. WHEN a start or stop command succeeds, THE Agent_CLI SHALL display a `[  OK  ]` status line with the agent name and action taken.
6. WHEN a start or stop command fails, THE Agent_CLI SHALL display a `[FAIL]` status line with the error message and a corrective suggestion.

### Requirement 5: UI Agents Tab and API Endpoints

**User Story:** As a developer, I want to see and manage my deployed agents in the browser UI, so that I can visually monitor status and trigger start/stop actions.

#### Acceptance Criteria

1. WHEN the UI_Server starts, THE Agents_Tab SHALL be available in the browser UI tab bar alongside existing tabs (Chat, Prompts, Evals, Flow, Observe, Scenarios, Config).
2. WHEN a client sends a GET request to `/api/agents`, THE UI_Server SHALL read the Agent_Registry, enrich each record with live AgentCore status, and return a JSON array of agent objects.
3. WHEN a client sends a POST request to `/api/agents/{name}/start`, THE UI_Server SHALL execute `agentcore launch` for the specified agent using stored registry metadata and return a JSON response indicating success or failure.
4. WHEN a client sends a POST request to `/api/agents/{name}/stop`, THE UI_Server SHALL execute `agentcore stop` for the specified agent using stored registry metadata and return a JSON response indicating success or failure.
5. WHEN a client sends a POST request to `/api/agents/{name}/connect`, THE UI_Server SHALL switch the active session to route prompts to the deployed agent via the AgentCore invocation API instead of the local agent file.
6. WHEN the UI session is connected to a remote agent, THE Agents_Tab SHALL display an indicator in the chat tab showing that prompts are routed to a deployed agent.
7. WHEN displaying agent information, THE Agents_Tab SHALL show each agent as a card with name, region, status indicator (running/stopped/unknown), model, deploy date, and start/stop action buttons.

### Requirement 6: AWS Credential Handling

**User Story:** As a developer, I want the agent registry to use my existing AWS credentials seamlessly, so that I do not need to configure authentication separately.

#### Acceptance Criteria

1. THE Agent_Registry SHALL store only the AWS profile name in each Registry_Record and SHALL NOT store any credential values (access keys, secret keys, session tokens).
2. WHEN executing AgentCore_CLI commands, THE Agent_CLI SHALL resolve credentials using the stored aws_profile via the existing Credential_Resolver.
3. WHEN AWS credentials are expired or invalid, THE Agent_CLI SHALL display the message "AWS session expired. Run `aws login` to refresh your credentials."

### Requirement 7: UI Server Session Persistence

**User Story:** As a developer, I want the browser UI server to survive terminal close, so that I can reconnect to it in a new terminal session.

#### Acceptance Criteria

1. WHEN `synth ui` is executed, THE UI_Server SHALL start uvicorn as a background daemon process that survives terminal close.
2. WHEN the UI_Server starts as a daemon, THE Agent_Registry SHALL store the server PID and port in the registry file.
3. WHEN `synth ui` is executed and a UI_Server is already running (PID is alive and port is responsive), THE UI_Server SHALL open the browser to the existing server instead of starting a new one.
4. WHEN `synth ui` is executed and the stored PID is no longer alive, THE UI_Server SHALL start a new daemon process and update the registry with the new PID and port.

### Requirement 8: Error Handling

**User Story:** As a developer, I want clear and actionable error messages when agent management operations fail, so that I can quickly resolve issues.

#### Acceptance Criteria

1. WHEN the Agent_Registry file contains malformed JSON, THE Agent_Registry SHALL log a warning, create a backup of the corrupted file, and initialize a fresh empty registry.
2. WHEN a registry operation fails due to file system permissions, THE Agent_Registry SHALL raise a RegistryError with the file path and a suggestion to check permissions.
3. THE RegistryError class SHALL inherit from SynthError and include component and suggestion fields consistent with the existing error hierarchy.
