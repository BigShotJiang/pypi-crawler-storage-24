# Synth Product Roadmap

> From SDK to Platform: A phased strategy for building an enterprise agentic ecosystem.

---

## Vision

Three interconnected products forming a layered agentic platform:

1. **Synth SDK** — The engine. A Python SDK for building production-grade AI agents.
2. **Synth Platform** — The control plane. A SaaS/self-hosted platform for governed agent composition, deployment, and operations.
3. **Synth for VS Code** — The developer bridge. An extension connecting the IDE to the Platform for advanced customization and deployment.

---

## Current State (v1.2.1)

**What exists today:**
- Agent core: single agent, pipelines, graphs, agent teams, human-in-the-loop
- Providers: Anthropic, OpenAI, Google Gemini, Ollama, AWS Bedrock
- Deployment: AWS AgentCore (full lifecycle)
- Tooling: @tool decorator, ToolKit, MCP support via CLI scaffolding
- Observability: tracing (OTEL export), eval framework, bench command
- Guards: PII, cost, tool filter, custom
- Memory: thread, persistent (Redis), semantic
- Checkpointing: local, Redis
- CLI: init, dev, run, deploy, create, edit, doctor, bench, eval, ui
- Testing dashboard: browser-based UI with streaming, flow viz, A/B testing

**What's in progress (existing specs):**
- Agent registry
- AgentCore observability integration
- CLI reliability fixes
- Init flow redesign
- Multi-agent init flow
- UI enhancements

---

## Phase 1: SDK Stabilization & Multi-Cloud (Q2–Q3 2026)

**Goal:** Solidify the SDK as the universal agent engine across all major cloud providers.

### 1.1 Azure OpenAI Provider
- Implement `AzureOpenAIProvider` subclassing `BaseProvider`
- Handle Azure-specific auth (API key + Azure AD/Entra ID tokens)
- Support deployment-name-based routing (Azure uses deployment names, not model IDs)
- API version pinning in URL path
- Add `synth[azure]` optional extra

### 1.2 GCP Vertex AI Provider
- Implement `VertexAIProvider` subclassing `BaseProvider`
- Support Application Default Credentials (ADC) + service account JSON
- Handle Vertex AI endpoint format (project/location/publisher/model)
- Add `synth[vertex]` optional extra

### 1.3 Cloud-Agnostic Agent Manifest
- Design a universal agent manifest format (superset of current `agentcore.yaml`)
- Declare: tools, guards, provider requirements, resource needs, memory backend, pattern lineage
- Must be interpretable by SDK CLI, future Platform, and all deployment targets
- Version the manifest schema from day one

### 1.4 Agent Registry (already in progress)
- Complete the agent registry spec
- Enable discovery, versioning, and metadata for agents within a project/org

### 1.5 SDK API Freeze (v2.0)
- Audit public API surface for consistency and completeness
- Mark experimental APIs explicitly
- Publish migration guide from v1.x
- This is the contract the Platform will build on — it must be stable

### Milestone: Synth SDK v2.0 — deploy agents to AWS, Azure, or GCP from a single codebase.

---

## Phase 2: Pattern System & VS Code Extension (Q3–Q4 2026)

**Goal:** Introduce reusable agent patterns and bring the developer experience into the editor.

### 2.1 Pattern Schema & Catalog
- Design the pattern schema: a parameterized, composable agent template
- Patterns declare: agent structure, required tools (by capability, not implementation), guard policies, resource requirements, configurable parameters
- Ship 5–10 built-in patterns (customer support, RAG pipeline, data analyst, code reviewer, approval workflow)
- CLI support: `synth create --from-pattern customer-support`

### 2.2 MCP as Integration Backbone
- First-class MCP server discovery and configuration in agent manifests
- Patterns reference tool capabilities ("needs a CRM tool") rather than specific MCP servers
- At instantiation, teams bind their MCP server (Salesforce, ServiceNow, etc.) to the capability slot
- Auto-generate MCP wrappers from OpenAPI specs as a bridge for enterprises with existing REST APIs

### 2.3 VS Code Extension (v1.0)
- Agent scaffolding wizard (visual `synth init`)
- Pattern browser: browse, preview, and instantiate patterns
- Inline trace viewer: inspect traces without leaving the editor
- Deploy-from-editor: one-click deploy to AgentCore / Azure / GCP
- Tool testing: invoke individual tools with test arguments
- Agent manifest editor with validation and autocomplete
- Connect to Synth Platform (when available) for pattern sync and team collaboration

### 2.4 Multi-Target Deployment
- Extend `synth deploy` to support `--target azure` and `--target gcp`
- Each target generates cloud-specific deployment artifacts from the universal manifest
- Dry-run mode for all targets

### Milestone: Developers can create agents from governed patterns, customize in VS Code, and deploy to any cloud.

---

## Phase 3: Synth Platform — Control Plane (Q1–Q2 2027)

**Goal:** Launch the Platform as a governance and operations layer for enterprise agent fleets.

### 3.1 Platform Core Architecture
- Containerized microservices (control plane + data plane separation)
- Control plane: pattern catalog, RBAC, audit log, deployment orchestration, cost tracking
- Data plane: agent execution runtime (runs in customer's cloud for self-hosted)
- SaaS deployment on AWS (ECS/EKS + RDS + S3)
- Self-hosted: Helm chart for Kubernetes, Docker Compose for simpler setups
- Tenant isolation model: org → teams → environments (dev/staging/prod)

### 3.2 Pattern Catalog & Governance
- Web UI for browsing, creating, and versioning patterns
- Pattern approval workflow: platform team creates → reviews → publishes
- Pattern instantiation: teams select a pattern, bind their tools/MCP servers, configure parameters
- Generated code uses Synth SDK under the hood
- Audit trail: who created what, when, from which pattern version

### 3.3 Agent Lifecycle Management
- Dashboard: view all deployed agents across clouds and environments
- Health monitoring: uptime, error rates, latency, cost per agent
- Promotion workflow: dev → staging → prod with approval gates
- Rollback: one-click revert to previous agent version
- Cost allocation: per-agent, per-team, per-environment cost tracking

### 3.4 RBAC & Multi-Tenancy
- Role model: org admin, platform engineer, team lead, developer, viewer
- Scoped permissions: who can create patterns, deploy to prod, view costs, etc.
- SSO integration (SAML, OIDC) for enterprise identity providers
- API keys for CI/CD integration

### Milestone: Enterprises can govern, deploy, and monitor agent fleets from a central control plane.

---

## Phase 4: Synth Platform — Builder & Integrations (Q2–Q3 2027)

**Goal:** Add the low-code builder and enterprise integration layer.

### 4.1 Visual Agent Builder
- Drag-and-drop agent composition from patterns and tools
- Visual graph editor for workflow agents (maps to Synth SDK Graph)
- Tool configuration UI: connect MCP servers, configure OpenAPI endpoints
- Guard policy editor: set guardrails visually
- Preview/test mode: run the agent from the builder before deploying
- "Eject to code" button: export the visual agent as Synth SDK Python code for full customization

### 4.2 Integration Hub
- Curated MCP server catalog for popular enterprise systems:
  - ServiceNow, Salesforce, Jira, Confluence, Slack, Teams
  - AWS services (S3, DynamoDB, Lambda, SQS)
  - Databases (PostgreSQL, MySQL, MongoDB)
- OpenAPI import: paste an OpenAPI spec URL, auto-generate an MCP wrapper
- REST API connector: configure generic HTTP endpoints as tools
- Webhook support: trigger agents from external events
- OAuth2 credential vault for managing integration credentials securely

### 4.3 Infrastructure Provisioning
- Generate IaC artifacts (CDK stacks / Terraform modules) rather than direct API calls
- Respect enterprise deployment pipelines (output goes through their CI/CD, not ours)
- Supported resources: IAM roles, Lambda functions, API Gateway endpoints, S3 buckets
- Least-privilege IAM policy generation based on agent's declared tool requirements

### 4.4 VS Code Extension (v2.0)
- Bidirectional sync with Platform: pull patterns, push customizations
- Platform explorer panel: browse agents, patterns, deployments from the editor
- Collaborative editing: see team members' agents and patterns
- Local testing against Platform-managed MCP servers

### Milestone: Non-developers can compose agents visually; developers can eject to code. Enterprise integrations are plug-and-play.

---

## Phase 5: Platform Maturity & Ecosystem (Q4 2027+)

**Goal:** Harden for enterprise scale and build the ecosystem.

### 5.1 Observability & Analytics
- Centralized trace aggregation across all deployed agents
- Anomaly detection: cost spikes, latency degradation, error rate changes
- Usage analytics: which patterns are most used, which tools are most called
- Compliance reporting: audit logs exportable for SOC2/ISO27001

### 5.2 Marketplace
- Community pattern marketplace: publish and discover patterns
- MCP server marketplace: share and install integration connectors
- Verified publisher program for enterprise-grade patterns

### 5.3 Advanced Orchestration
- Cross-agent workflows: agents from different teams collaborating on a task
- Event-driven agent activation: trigger agents from CloudWatch events, SNS, webhooks
- Scheduled agent runs: cron-like scheduling from the Platform

### 5.4 Self-Hosted Parity
- Feature parity between SaaS and self-hosted (minus marketplace)
- Air-gapped deployment support for regulated industries
- Bring-your-own-KMS for encryption at rest

---

## Open Questions

These need answers before or during each phase. They're ordered by urgency — the earlier phases have questions that block downstream decisions.

---

### Phase 1 Questions (Answer Now)

**Q1. What is the universal agent manifest format?**
The current `agentcore.yaml` is AWS-specific. The manifest needs to describe an agent's full contract (tools, guards, provider, resources, pattern lineage) in a cloud-agnostic way. Is this YAML, TOML (matching `synth.toml`), or JSON? Does it replace `agentcore.yaml` or sit above it as a superset that generates cloud-specific configs?

**Q2. How do you handle provider-specific model capabilities?**
Not all models support all features (tool calling, structured output, streaming, vision). When a pattern says "needs tool calling," how do you validate that the chosen provider/model supports it? Do you build a capability matrix into the SDK, or fail at runtime?

**Q3. What's the Azure auth story?**
Azure OpenAI supports API keys and Azure AD tokens. AD tokens expire and need refresh. Do you handle token refresh in the provider, or require users to pass a token provider callback? This affects the credential resolution pattern.

**Q4. What's the GCP auth story?**
Vertex AI uses ADC, service account JSON, or workload identity. ADC is magic but breaks in containers without explicit setup. How opinionated do you want to be about auth configuration?

**Q5. What does "v2.0 API freeze" actually mean?**
Which APIs are public vs experimental? Do you use `__all__` exports, a `synth.experimental` namespace, or deprecation warnings? How long is the deprecation window before removing something?

**Q6. What's the versioning strategy for the manifest schema?**
If the manifest evolves (and it will), how do you handle backward compatibility? Schema version field + migration tooling? Or strict additive-only changes?

---

### Phase 2 Questions (Answer in Q3 2026)

**Q7. What does a pattern actually look like?**
Is it a directory with a manifest + template files (like Cookiecutter)? A single declarative YAML that the SDK interprets? A Python module with parameterized defaults? The answer determines how patterns are authored, versioned, shared, and instantiated.

**Q8. How do patterns reference tool capabilities vs implementations?**
If a pattern says "needs a CRM tool that can read tickets," what's the schema for that capability declaration? How does the binding happen at instantiation — interactive prompt, config file, or Platform UI?

**Q9. What's the VS Code extension's offline story?**
If the Platform is down or the developer is offline, what still works? Pattern instantiation from local cache? Deploy to cloud directly? The extension needs a clear degraded-mode behavior.

**Q10. How do you handle pattern versioning and updates?**
If a team instantiated v1 of a pattern and v2 is published with a security fix, how are they notified? Can they upgrade in place, or do they need to re-instantiate? What about breaking changes in patterns?

**Q11. OpenAPI-to-MCP auto-generation: how complete?**
OpenAPI specs vary wildly in quality. How do you handle specs with auth requirements, pagination, file uploads, webhooks, or polymorphic schemas? Is this a best-effort tool or a production-grade converter?

---

### Phase 3 Questions (Answer in Q4 2026)

**Q12. SaaS vs self-hosted: what's the data boundary?**
What data stays in the customer's environment vs what flows to your SaaS? Agent execution logs? Trace data? Pattern definitions? Cost metrics? This is the single most important question for enterprise sales.

**Q13. What's the tenant isolation model?**
For SaaS: shared infrastructure with logical isolation, or dedicated resources per tenant? For self-hosted: single-tenant by definition, but how do you handle multi-team isolation within one deployment?

**Q14. How does the Platform authenticate with cloud providers?**
To deploy agents to a customer's AWS/Azure/GCP account, the Platform needs credentials. Do customers create a cross-account IAM role (AWS), a service principal (Azure), or a workload identity (GCP)? How do you handle credential rotation?

**Q15. What's the Platform's own infrastructure stack?**
Are you building on AWS-native services (ECS, RDS, Cognito) or cloud-agnostic (Kubernetes, PostgreSQL, Keycloak)? The former is faster to build but makes self-hosted on Azure/GCP harder. The latter is more portable but more operational overhead.

**Q16. How do you price the Platform?**
Per-agent? Per-deployment? Per-seat? Per-API-call? Free tier for small teams? This affects architecture (you need metering infrastructure) and go-to-market.

**Q17. What's the migration path from SDK-only to Platform?**
If a team has been using the SDK directly with `synth deploy`, how do they onboard to the Platform without re-creating everything? Import existing agents, manifests, and deployment configs?

---

### Phase 4 Questions (Answer in Q1 2027)

**Q18. How far does the visual builder go?**
Can it express everything the SDK can (graphs with complex conditional logic, custom guards, parallel pipelines)? Or is it intentionally limited to common patterns, with "eject to code" for advanced cases? The answer determines the builder's complexity and maintenance burden.

**Q19. How do you handle the "eject to code" round-trip?**
Once someone ejects a visual agent to Python code and modifies it, can they re-import it into the builder? If not, that's a one-way door. If yes, you need a code-to-visual parser, which is extremely hard.

**Q20. Integration credential management: who's responsible?**
When the Platform stores OAuth tokens for Salesforce/ServiceNow, you're now a credential custodian. What's the encryption model? Do you use a cloud KMS? What happens if your Platform is compromised — what's the blast radius?

**Q21. IaC generation: CDK, Terraform, or both?**
Enterprises are split. Supporting both doubles the maintenance. Do you pick one and add the other later? Or generate a cloud-agnostic intermediate representation that compiles to either?

**Q22. How do you handle MCP server lifecycle?**
If the Platform provisions an MCP server for a Salesforce integration, who runs it? Does it run as a sidecar to the agent? A shared service? In the customer's cloud or yours? What about scaling and availability?

---

### Strategic Questions (Answer Anytime, But Sooner Is Better)

**Q23. What's your competitive moat?**
LangChain, CrewAI, AutoGen, Semantic Kernel — the agent framework space is crowded. The SDK alone isn't defensible. Is the moat the pattern system? The Platform governance story? The multi-cloud deployment? Enterprise integrations? Be specific about what's hard to replicate.

**Q24. Who is the primary buyer?**
The SDK targets individual developers. The Platform targets platform engineering teams. The VS Code extension targets both. These are different buying motions (bottom-up adoption vs top-down procurement). Which do you optimize for first?

**Q25. What's the team size and composition needed?**
Phase 1 is SDK work (Python engineers). Phase 2 adds VS Code (TypeScript). Phase 3 adds Platform (full-stack + infra + security). Phase 4 adds integrations (domain expertise per connector). Do you have or can you hire for all of these?

**Q26. Open source strategy?**
The SDK is MIT licensed. Does the Platform have an open-source core (like GitLab CE/EE)? Or is it fully proprietary? This affects community building, hiring, and enterprise trust.

**Q27. What's the self-hosted support model?**
Self-hosted enterprise software requires dedicated support engineering, upgrade tooling, compatibility testing across environments, and documentation that's 10x more detailed than SaaS. Are you prepared for that operational burden?

**Q28. How do you handle the "works locally, breaks in production" gap?**
Agents that work in `synth dev` may behave differently when deployed (different model versions, network latency, tool timeouts, credential scoping). What's your story for environment parity and production debugging?

---

## Dependencies & Risk Map

| Risk | Impact | Mitigation |
|------|--------|------------|
| SDK API instability delays Platform | High | Freeze public API in Phase 1; use adapter layer in Platform |
| Azure/GCP provider complexity exceeds estimates | Medium | Ship FM access first; defer full deployment parity |
| Pattern schema doesn't generalize | High | Validate with 10+ real-world agent architectures before committing |
| Self-hosted adds 2x maintenance burden | High | Design for SaaS first; self-hosted is a packaging concern, not a code fork |
| MCP ecosystem fragmentation | Medium | Curate a small set of high-quality MCP servers; don't try to support everything |
| Enterprise sales cycle delays Platform revenue | High | Keep SDK free/open; Platform is the monetization layer |
| VS Code extension maintenance across VS Code versions | Low | Use stable VS Code API; avoid preview APIs |
| Credential management liability | High | Use cloud-native KMS; never store credentials in Platform DB; consider Vault integration |

---

## Success Metrics

| Phase | Metric | Target |
|-------|--------|--------|
| Phase 1 | SDK downloads (PyPI) | 10K+ monthly |
| Phase 1 | Providers with full feature parity | 5 (Anthropic, OpenAI, Azure, GCP, Bedrock) |
| Phase 2 | Patterns in catalog | 10+ built-in |
| Phase 2 | VS Code extension installs | 1K+ in first quarter |
| Phase 3 | Platform beta customers | 5–10 enterprise design partners |
| Phase 3 | Agents managed via Platform | 100+ across beta customers |
| Phase 4 | Integration connectors available | 10+ MCP servers |
| Phase 4 | Visual builder → production deployments | 50+ agents built visually |
