"""Persistent agent registry data models.

Defines the dataclasses that represent entries in the local agent registry
file (``~/.synth/registry.json``).  The registry tracks deployment metadata
so that agents can be managed across terminal sessions.

The three models form a simple hierarchy::

    RegistryData
    ├── agents: list[RegistryRecord]   # one per deployed agent
    └── server: ServerInfo | None      # optional UI server daemon info
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Registry record — one entry per deployed agent
# ---------------------------------------------------------------------------

@dataclass
class RegistryRecord:
    """A single deployed agent entry in the registry.

    Parameters
    ----------
    agent_name:
        Unique agent identifier (matches the AgentCore name).
    region:
        AWS region of deployment (e.g. ``"us-west-2"``).
    model_id:
        Bedrock model ID used by the agent.
    source_file:
        Path to the agent Python file that was deployed.
    deployed_at:
        ISO 8601 UTC timestamp of the deployment.
    aws_profile:
        AWS profile name used for deployment, or ``None`` if the default
        credential chain was used.
    """

    agent_name: str
    region: str
    model_id: str
    source_file: str
    deployed_at: str
    aws_profile: str | None


# ---------------------------------------------------------------------------
# Server info — tracks a running UI server daemon
# ---------------------------------------------------------------------------

@dataclass
class ServerInfo:
    """Tracks a running UI server daemon process.

    Parameters
    ----------
    pid:
        OS process ID of the daemon.
    port:
        TCP port the server listens on.
    started_at:
        ISO 8601 UTC timestamp of when the server was started.
    """

    pid: int
    port: int
    started_at: str


# ---------------------------------------------------------------------------
# Top-level registry structure
# ---------------------------------------------------------------------------

@dataclass
class RegistryData:
    """Top-level structure of the ``~/.synth/registry.json`` file.

    Parameters
    ----------
    agents:
        List of deployed agent records.
    server:
        Info about a running UI server daemon, or ``None`` if no server
        is tracked.
    """

    agents: list[RegistryRecord] = field(default_factory=list)
    server: ServerInfo | None = None


# ---------------------------------------------------------------------------
# Imports for RegistryStore
# ---------------------------------------------------------------------------

import json
import os
import shutil
from dataclasses import asdict
from pathlib import Path

import click

from synth.errors import RegistryError


# ---------------------------------------------------------------------------
# Registry store — CRUD operations on the registry file
# ---------------------------------------------------------------------------

_REQUIRED_RECORD_FIELDS = {"agent_name", "region", "model_id", "source_file", "deployed_at"}
_REQUIRED_SERVER_FIELDS = {"pid", "port", "started_at"}


class RegistryStore:
    """CRUD operations on ``~/.synth/registry.json``.

    Provides load/save primitives and convenience methods for managing
    agent records and server info.  The file is created with owner-only
    permissions (``0o600``) on first write.

    Parameters
    ----------
    path:
        Override the default registry file location.  Useful for testing.
    """

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or Path.home() / ".synth" / "registry.json"

    # -- persistence --------------------------------------------------------

    def load(self) -> RegistryData:
        """Load the registry from disk.

        Returns
        -------
        RegistryData
            The deserialized registry.  Returns an empty ``RegistryData``
            when the file is missing or contains malformed JSON (a ``.bak``
            backup is created in the latter case).
        """
        if not self._path.exists():
            return RegistryData()

        raw_text = ""
        try:
            raw_text = self._path.read_text(encoding="utf-8")
            data = json.loads(raw_text)
        except json.JSONDecodeError:
            backup = self._path.with_suffix(".json.bak")
            try:
                shutil.copy2(self._path, backup)
            except OSError:
                pass
            click.echo(
                f"Warning: Registry file contains invalid JSON. "
                f"A backup was saved to {backup}. Starting with a fresh registry."
            )
            return RegistryData()
        except OSError as exc:
            raise RegistryError(
                f"Cannot read registry file: {self._path}",
                component="AgentRegistry",
                suggestion=f"Check file permissions: chmod 600 {self._path}",
            ) from exc

        # Parse agents — skip records missing required fields
        agents: list[RegistryRecord] = []
        for entry in data.get("agents", []):
            if not isinstance(entry, dict):
                continue
            if not _REQUIRED_RECORD_FIELDS.issubset(entry.keys()):
                continue
            agents.append(
                RegistryRecord(
                    agent_name=entry["agent_name"],
                    region=entry["region"],
                    model_id=entry["model_id"],
                    source_file=entry["source_file"],
                    deployed_at=entry["deployed_at"],
                    aws_profile=entry.get("aws_profile"),
                )
            )

        # Parse server info
        server: ServerInfo | None = None
        srv = data.get("server")
        if isinstance(srv, dict) and _REQUIRED_SERVER_FIELDS.issubset(srv.keys()):
            server = ServerInfo(
                pid=srv["pid"],
                port=srv["port"],
                started_at=srv["started_at"],
            )

        return RegistryData(agents=agents, server=server)

    def save(self, data: RegistryData) -> None:
        """Persist *data* to the registry file.

        Creates parent directories and the file with owner-only permissions
        (``0o600``) on first write.

        Parameters
        ----------
        data:
            The registry data to serialize.

        Raises
        ------
        RegistryError
            If the file cannot be written due to permission or I/O errors.
        """
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(asdict(data), indent=2)

            if not self._path.exists():
                # First write — create with restricted permissions
                try:
                    fd = os.open(str(self._path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                    try:
                        os.write(fd, payload.encode("utf-8"))
                    finally:
                        os.close(fd)
                except OSError:
                    # Fallback for platforms that don't support Unix permissions
                    self._path.write_text(payload, encoding="utf-8")
            else:
                self._path.write_text(payload, encoding="utf-8")
        except OSError as exc:
            raise RegistryError(
                f"Cannot write to registry file: {self._path}",
                component="AgentRegistry",
                suggestion=f"Check file permissions: chmod 600 {self._path}",
            ) from exc

    # -- agent CRUD ---------------------------------------------------------

    def add_agent(self, record: RegistryRecord) -> None:
        """Add or update an agent record (upsert by ``agent_name``).

        Parameters
        ----------
        record:
            The agent record to store.  If a record with the same
            ``agent_name`` already exists it is replaced.
        """
        data = self.load()
        data.agents = [a for a in data.agents if a.agent_name != record.agent_name]
        data.agents.append(record)
        self.save(data)

    def get_agent(self, name: str) -> RegistryRecord | None:
        """Return the record for *name*, or ``None`` if not found.

        Parameters
        ----------
        name:
            The ``agent_name`` to look up.
        """
        data = self.load()
        for agent in data.agents:
            if agent.agent_name == name:
                return agent
        return None

    def remove_agent(self, name: str) -> bool:
        """Remove the record for *name*.

        Parameters
        ----------
        name:
            The ``agent_name`` to remove.

        Returns
        -------
        bool
            ``True`` if a record was removed, ``False`` if *name* was not
            found.
        """
        data = self.load()
        original_count = len(data.agents)
        data.agents = [a for a in data.agents if a.agent_name != name]
        if len(data.agents) == original_count:
            return False
        self.save(data)
        return True

    def list_agents(self) -> list[RegistryRecord]:
        """Return all agent records.

        Returns
        -------
        list[RegistryRecord]
            A list of all stored agent records, possibly empty.
        """
        return self.load().agents

    # -- server info --------------------------------------------------------

    def set_server(self, info: ServerInfo) -> None:
        """Store UI server daemon info.

        Parameters
        ----------
        info:
            The server info to persist.
        """
        data = self.load()
        data.server = info
        self.save(data)

    def get_server(self) -> ServerInfo | None:
        """Return stored server info, or ``None`` if not set.

        Returns
        -------
        ServerInfo | None
            The stored server info, or ``None``.
        """
        return self.load().server

    def clear_server(self) -> None:
        """Remove stored server info."""
        data = self.load()
        data.server = None
        self.save(data)
