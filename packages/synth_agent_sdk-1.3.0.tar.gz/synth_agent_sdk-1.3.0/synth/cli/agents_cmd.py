"""CLI commands for managing deployed AgentCore agents.

Provides the ``synth agents`` command group with ``list``, ``status``,
``start``, and ``stop`` subcommands.  All commands read from the local
agent registry (``~/.synth/registry.json``) and delegate to the
``agentcore`` CLI binary for live operations.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys

import click

from synth.cli.registry import RegistryRecord, RegistryStore


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_AGENTCORE_INSTALL_HINT = (
    "AgentCore CLI not found. "
    "Install it with: pip install bedrock-agentcore-starter-toolkit"
)

_CREDENTIAL_KEYWORDS = ("expired", "token", "credentials")

_CREDENTIAL_EXPIRED_MSG = (
    "AWS session expired. Run `aws login` to refresh your credentials."
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_agentcore_bin() -> str | None:
    """Locate the ``agentcore`` binary on ``PATH`` or next to the interpreter."""
    agentcore_bin = shutil.which("agentcore")
    if agentcore_bin:
        return agentcore_bin

    scripts_dir = os.path.dirname(sys.executable)
    suffix = ".exe" if sys.platform == "win32" else ""
    candidate = os.path.join(scripts_dir, f"agentcore{suffix}")
    if os.path.isfile(candidate):
        return candidate

    return None


def _is_credential_error(text: str) -> bool:
    """Return ``True`` if *text* looks like an AWS credential expiry error."""
    lower = text.lower()
    return any(kw in lower for kw in _CREDENTIAL_KEYWORDS)


def _print_ok(label: str, message: str) -> None:
    """Print a ``[  OK  ]`` status line."""
    status = click.style("[  OK  ]", fg="green")
    click.echo(f"  {status} {label}: {message}")


def _print_fail(label: str, message: str, suggestion: str | None = None) -> None:
    """Print a ``[FAIL]`` status line with an optional suggestion."""
    status = click.style("[FAIL]", fg="red")
    click.echo(f"  {status}  {label}: {message}")
    if suggestion:
        click.echo(
            f"         {click.style('Suggestion:', fg='yellow')} {suggestion}"
        )


def _agent_not_found(name: str, store: RegistryStore) -> None:
    """Print an error for a missing agent and list available names."""
    agents = store.list_agents()
    if agents:
        names = ", ".join(a.agent_name for a in agents)
        _print_fail(
            "Agent lookup",
            f"Agent '{name}' not found in registry",
            f"Available agents: {names}. Run `synth deploy` to register a new agent.",
        )
    else:
        _print_fail(
            "Agent lookup",
            f"Agent '{name}' not found in registry",
            "No agents registered. Run `synth deploy` to register an agent.",
        )


def _query_live_status(
    store: RegistryStore,
) -> dict[str, dict[str, str]]:
    """Query AgentCore for live status of all registered agents.

    Reuses ``_query_agentcore_cli`` from ``discover.py`` by building
    lightweight stand-in objects.  Returns ``{name: {status, agent_id}}``
    or an empty dict on failure.
    """
    from synth.cli.discover import (
        DiscoveredAgent,
        _query_agentcore_cli,
    )

    agents = store.list_agents()
    if not agents:
        return {}

    # Build minimal DiscoveredAgent stand-ins so _query_agentcore_cli
    # can extract region and profile information.
    discovered: list[DiscoveredAgent] = []
    for rec in agents:
        da = DiscoveredAgent(
            name=rec.agent_name,
            file=rec.source_file,
            has_agentcore_yaml=True,
            aws_region=rec.region,
        )
        discovered.append(da)

    try:
        return _query_agentcore_cli(discovered)
    except Exception:
        return {}


def _build_subprocess_env(record: RegistryRecord) -> dict[str, str]:
    """Build an environment dict with ``AWS_PROFILE`` set if applicable."""
    env = os.environ.copy()
    if record.aws_profile:
        env["AWS_PROFILE"] = record.aws_profile
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONWARNINGS"] = "ignore"
    return env


# ---------------------------------------------------------------------------
# Command group
# ---------------------------------------------------------------------------

@click.group("agents")
def agents_group() -> None:
    """Manage deployed AgentCore agents."""


# ---------------------------------------------------------------------------
# synth agents list
# ---------------------------------------------------------------------------

@agents_group.command("list")
def agents_list_cmd() -> None:
    """List all registered agents with live status."""
    store = RegistryStore()
    agents = store.list_agents()

    if not agents:
        click.echo("No agents registered. Run `synth deploy` to deploy an agent.")
        return

    # Query live status — fall back to "unknown" on failure
    live_status = _query_live_status(store)

    # Header
    click.echo()
    header = f"  {'Name':<30} {'Region':<16} {'Status':<12} {'Deployed'}"
    click.echo(click.style(header, bold=True))
    click.echo(f"  {'─' * 30} {'─' * 16} {'─' * 12} {'─' * 24}")

    for rec in agents:
        info = live_status.get(rec.agent_name)
        status_text = info["status"].lower() if info else "unknown"

        # Color the status
        color_map = {
            "active": "green",
            "creating": "yellow",
            "failed": "red",
            "deleting": "yellow",
        }
        color = color_map.get(status_text, "white")
        styled_status = click.style(status_text, fg=color)

        click.echo(
            f"  {rec.agent_name:<30} {rec.region:<16} "
            f"{styled_status:<21} {rec.deployed_at}"
        )

    click.echo()
    _print_ok("Agent list", f"{len(agents)} agent(s) found")


# ---------------------------------------------------------------------------
# synth agents status <name>
# ---------------------------------------------------------------------------

@agents_group.command("status")
@click.argument("name")
def agents_status_cmd(name: str) -> None:
    """Show detailed status for a specific agent."""
    store = RegistryStore()
    record = store.get_agent(name)

    if record is None:
        _agent_not_found(name, store)
        sys.exit(1)

    # Query live status for this agent
    live_status = _query_live_status(store)
    info = live_status.get(record.agent_name)

    if info:
        status_text = info["status"].lower()
    else:
        status_text = "unknown"

    # Check for credential errors — if status query returned nothing and
    # we can probe for a credential issue, do so.
    if not info:
        try:
            _probe_credentials(record)
        except _CredentialExpiredError:
            click.echo(click.style(_CREDENTIAL_EXPIRED_MSG, fg="yellow"))
            sys.exit(1)

    click.echo()
    click.echo(click.style(f"  Agent: {record.agent_name}", bold=True))
    click.echo(f"  Region:      {record.region}")
    click.echo(f"  Model:       {record.model_id}")
    click.echo(f"  Source:      {record.source_file}")
    click.echo(f"  Deployed:    {record.deployed_at}")
    click.echo(f"  AWS Profile: {record.aws_profile or '(default)'}")
    click.echo(f"  Status:      {status_text}")
    click.echo()
    _print_ok("Agent status", f"Details for '{record.agent_name}'")


# ---------------------------------------------------------------------------
# Credential probing
# ---------------------------------------------------------------------------

class _CredentialExpiredError(Exception):
    """Internal signal for expired AWS credentials."""


def _probe_credentials(record: RegistryRecord) -> None:
    """Run a lightweight AgentCore command to detect credential errors.

    Raises
    ------
    _CredentialExpiredError
        If the subprocess output indicates expired credentials.
    """
    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        return

    env = _build_subprocess_env(record)
    cmd = [agentcore_bin, "list", "--region", record.region]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15,
            env=env,
        )
        combined = f"{result.stdout}\n{result.stderr}"
        if result.returncode != 0 and _is_credential_error(combined):
            raise _CredentialExpiredError()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass


# ---------------------------------------------------------------------------
# synth agents start <name>
# ---------------------------------------------------------------------------

@agents_group.command("start")
@click.argument("name")
def agents_start_cmd(name: str) -> None:
    """Start a deployed agent via AgentCore."""
    store = RegistryStore()
    record = store.get_agent(name)

    if record is None:
        _agent_not_found(name, store)
        sys.exit(1)

    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        _print_fail("Start agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)

    env = _build_subprocess_env(record)
    cmd = [agentcore_bin, "launch", "--region", record.region]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            env=env,
        )
        combined = f"{result.stdout}\n{result.stderr}"

        if result.returncode == 0:
            _print_ok("Start agent", f"Agent '{name}' started successfully")
        else:
            if _is_credential_error(combined):
                _print_fail(
                    "Start agent",
                    _CREDENTIAL_EXPIRED_MSG,
                )
            else:
                msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
                _print_fail(
                    "Start agent",
                    f"Failed to start agent '{name}'",
                    msg,
                )
            sys.exit(1)

    except subprocess.TimeoutExpired:
        _print_fail(
            "Start agent",
            f"Timed out starting agent '{name}'",
            "The AgentCore CLI did not respond within 120 seconds.",
        )
        sys.exit(1)
    except FileNotFoundError:
        _print_fail("Start agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)


# ---------------------------------------------------------------------------
# synth agents stop <name>
# ---------------------------------------------------------------------------

@agents_group.command("stop")
@click.argument("name")
def agents_stop_cmd(name: str) -> None:
    """Stop a deployed agent via AgentCore."""
    store = RegistryStore()
    record = store.get_agent(name)

    if record is None:
        _agent_not_found(name, store)
        sys.exit(1)

    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        _print_fail("Stop agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)

    env = _build_subprocess_env(record)
    cmd = [agentcore_bin, "stop", "--region", record.region]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            env=env,
        )
        combined = f"{result.stdout}\n{result.stderr}"

        if result.returncode == 0:
            _print_ok("Stop agent", f"Agent '{name}' stopped successfully")
        else:
            if _is_credential_error(combined):
                _print_fail(
                    "Stop agent",
                    _CREDENTIAL_EXPIRED_MSG,
                )
            else:
                msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
                _print_fail(
                    "Stop agent",
                    f"Failed to stop agent '{name}'",
                    msg,
                )
            sys.exit(1)

    except subprocess.TimeoutExpired:
        _print_fail(
            "Stop agent",
            f"Timed out stopping agent '{name}'",
            "The AgentCore CLI did not respond within 120 seconds.",
        )
        sys.exit(1)
    except FileNotFoundError:
        _print_fail("Stop agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)
