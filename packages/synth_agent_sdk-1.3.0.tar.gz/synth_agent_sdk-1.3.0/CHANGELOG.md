# Changelog

All notable changes to the Synth SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.1] - 2026-03-01

### Changed
- **UI: split-pane layout** — the chat tab now uses a two-column layout: left column has chat messages stacked above a resizable telemetry panel, right column is a dedicated flow visualization panel. Both are visible simultaneously during agent execution
- **UI: flow-per-turn history** — each conversation turn saves its flow state. Clicking any agent message in the chat loads that turn's execution flow into the flow panel, letting you inspect past turns without losing the current view
- **UI: inline thinking restored** — the animated thinking dots and reasoning text are back in chat messages, giving real-time feedback that the agent is working. Tool calls remain in the flow panel only, keeping the chat clean
- **UI: clickable messages** — agent messages highlight on hover and show a green glow when selected, indicating which turn's flow is currently displayed
- **Version bump** — 1.2.0 → 1.2.1

## [1.2.0] - 2026-03-01

### Added
- **UI: real-time flow visualization** — the Flow tab now renders a live node graph during agent execution, showing the full path from user prompt → agent → tool calls / MCP calls → output. Each node animates in real-time with status badges (ACTIVE with spinner, DONE, ERROR) and CRT-themed glow effects. Clicking any node opens a detail panel with full trace data: prompt text, tool arguments and results, token usage, cost, trace spans, guard results, or error details depending on node type
- **UI: flow detail panel** — slide-in panel on the right side of the Flow tab shows contextual information for the selected node. Output nodes include the full trace span timeline, token breakdown, and cost. Tool nodes show arguments and results. Guard nodes display pass/fail status per guard with violation messages
- **UI: multi-agent flow support** — when using AgentTeam, Pipeline, or Graph orchestration, the flow graph shows agent handoff nodes as each sub-agent starts and completes, giving a visual map of the delegation chain
- **UI: Fallout CRT animations** — running nodes pulse with type-specific glow effects (green for agents, amber for tools, purple for thinking). Output nodes flash on completion. Error nodes flicker red. Detail panel has a subtle scanline overlay

### Changed
- **Version bump** — 1.1.2 → 1.2.0

## [1.1.2] - 2026-02-26

### Fixed
- **Multi-agent init: orchestrator model reuses shared config** — when all agents share the same provider/model, the AgentTeam orchestrator model prompt now offers "Use the same model for the orchestrator?" instead of repeating the full provider → region → model selection flow. Saves ~20 lines of prompts for the common case

### Changed
- **Version bump** — 1.1.1 → 1.1.2

## [1.1.1] - 2026-02-26

### Fixed
- **Multi-agent deploy: agent variable discovery** — `_load_agent` now scans for any `Agent` instance in the module when the conventional `agent` variable isn't found. Multi-agent files use the sanitized agent name as the variable (e.g., `molly_miles = Agent(...)`) which the previous loader didn't recognize, causing `"must define an 'agent' variable"` errors during deployment validation

### Changed
- **Version bump** — 1.1.0 → 1.1.1

## [1.1.0] - 2026-02-25

### Added
- **Multi-agent init: shared configuration** — `synth init` for multi-agent projects now asks upfront whether to share provider/model/region and tools across all agents. When shared, these are collected once and applied to every agent, cutting a 5-agent setup from ~30 repetitive prompts to ~15 focused ones
- **Multi-agent UI: collaboration visualization** — the testing dashboard now supports `AgentTeam`, `Pipeline`, and `Graph` orchestration. The server detects `team`, `pipeline`, or `graph` exports from `main.py` and renders real-time delegation cards during streaming, showing which agent is active, its tool calls, output preview, latency, and cost. A swimlane panel on the final response shows all agent contributions at a glance
- **UI: `agent_start` / `agent_complete` SSE events** — new server-sent event types for multi-agent delegation visibility. Pipeline streaming wraps `StageEvent` objects with agent attribution; Team runs emit per-contribution delegation events
- **UI: multi-agent info in sidebar** — the agent info panel now shows orchestration mode (team/pipeline/graph) and agent count
- **Agent name sanitization** — agent names with spaces, hyphens, or special characters (e.g. "Molly Mikes") are now converted to valid Python identifiers (`molly_mikes`) for filenames and variable names, with the original name preserved for display. Prevents the `invalid syntax (agent_Molly Mikes.py, line 6)` deployment error
- **Safe name collision detection** — `synth init` warns if two agents with different display names would produce the same safe identifier

### Fixed
- **Multi-agent deployment syntax error** — agent files with spaces in names (e.g. `agent_Molly Mikes.py`) produced invalid Python. All generated code now uses sanitized `safe_name` for imports, variable names, filenames, and deploy paths

### Changed
- **Version bump** — 1.0.1 → 1.1.0

## [1.0.1] - 2026-02-25

### Fixed
- **UI: agent thinking visible immediately** — thinking/reasoning tokens now stream progressively to the UI as they arrive instead of waiting for the full reasoning block to complete. Text accumulates in real-time using `textContent` to avoid markdown re-parsing flicker mid-stream, then renders as markdown once streaming ends
- **UI: "show reasoning" toggle always appears** — the chain-of-thought toggle button was never added after streaming because `collapseThinking()` was hiding the entire `cot-block` before `finalizeStreamingMessage` could detect its content. Fixed by separating collapse state from visibility detection
- **UI: thinking content preserved in history** — accumulated thinking text is now included in the `done` event payload and saved to conversation history, so the "show reasoning" section persists when reloading past conversations

### Changed
- **Version bump** — 1.0.0 → 1.0.1

## [1.0.0] - 2026-02-25

This is the first fully stable, production-ready release of the Synth SDK. The public API is now stable and will follow semantic versioning from this point forward. No breaking changes from 0.9.x.

### Added
- **UI: chain-of-thought panel** — agent tool calls and thinking blocks now appear below the conversational response text, collapsed by default. A "▶ show reasoning" toggle lets users expand the full chain of thought (thinking + all tool invocations with arguments and results) for any turn. Previously tool calls appeared above the response text and were always visible during streaming
- **UI: consistent history replay** — conversation history loaded from previous sessions now renders tool calls in the same collapsed cot-block pattern as live turns, so all turns look and behave consistently

### Changed
- **Version bump** — 0.9.19 → 1.0.0



### Changed
- **README: "Environment Variables in the Container" section** — new subsection under "Deploy" explains the two-tier env var model: non-sensitive config goes in `agentcore.yaml environment:` (forwarded via `agentcore launch --env`), secrets go in AWS Secrets Manager / SSM with a `get_ssm_parameter()` fetch-at-startup pattern. Includes a concrete `TAVILY_API_KEY` example
- **README: Built-in Web Search** — added a note pointing AgentCore users to the Secrets Manager pattern for search API keys
- **README: `synth deploy` description** — updated stage count from "six-stage" to "deployment wizard" (it's seven stages)
- **`botocore[crt]` removed from extras** — `bedrock`, `agentcore`, `aws`, and `all` extras no longer list `botocore[crt]` as a separate dependency. `boto3` already depends on `botocore`; the CRT extension (`awscrt`) is an optional performance add-on for S3 multi-region and EventBridge features not used by Bedrock or AgentCore. Users who need CRT can install `boto3[crt]` explicitly
- **Version bump** — 0.9.18 → 0.9.19



### Added
- **`agentcore launch --env` injection** — non-secret environment variables from `agentcore.yaml environment:` are now passed to `agentcore launch` via `--env KEY=VALUE` flags so they land in the container at deploy time. Previously these vars were never forwarded, meaning `SYNTH_NO_BANNER` and similar config never reached the running container
- **Secret key filtering** — `_is_secret_key()` filters out any key whose name contains `key`, `secret`, `token`, `password`, `passwd`, `credential`, `auth`, `api_key`, or `apikey` (case-insensitive) before building the `--env` list, preventing accidental exposure of credentials in process listings
- **`agentcore.yaml` template clarification** — the `environment:` section in generated `agentcore.yaml` files now includes a comment block explaining that only non-sensitive config belongs there, and that secrets must go to AWS Secrets Manager or SSM Parameter Store

### Fixed
- **Stale comment** — the `run_deploy` comment incorrectly said env vars were passed via `agentcore configure --env`; corrected to `agentcore launch --env` (configure does not support `--env`)

### Changed
- **Version bump** — 0.9.17 → 0.9.18



### Fixed
- **Bedrock empty `toolConfig` validation error** — replaced the `{"tools": []}` fallback (which Bedrock rejects as min length 1) with `_strip_tool_blocks()` that removes `toolUse`/`toolResult` blocks from messages when no tools are available, preventing `"Invalid length for parameter toolConfig.tools, value: 0"` errors
- **UI `/api/info` now exposes memory status** — the info endpoint returns `memory: {configured, type}` so the UI panel shows whether memory (including AgentCore Memory) is active

### Changed
- **Version bump** — 0.9.15 → 0.9.16

## [0.9.15] - 2026-02-25

### Fixed
- **Bedrock `toolConfig` ValidationException on follow-up turns** — the Bedrock provider now sends an empty `toolConfig` when the message history contains `toolUse`/`toolResult` blocks but no tools are explicitly passed, preventing the `"The toolConfig field must be defined when using toolUse and toolResult content blocks"` error on multi-turn conversations
- **`astream` missing `tool_name` in tool result messages** — tool results appended during streaming now include `tool_name`, matching the `arun` behavior and ensuring Bedrock correctly attributes tool results to their corresponding tool use blocks

### Changed
- **UI: inline tool call and result rendering** — tool calls and results are now shown as collapsible blocks in the chat area during streaming (similar to Claude/ChatGPT), with tool name, arguments, status indicator, and result text. Previously tool calls were only visible in the telemetry panel after the response completed
- **UI: improved thinking block** — thinking blocks now render markdown content and use an SVG icon instead of an emoji
- **UI: `ToolResultEvent` streaming** — the server now emits `tool_result` SSE events during streaming, so the UI can show results as they arrive rather than waiting for the final response
- **Version bump** — 0.9.14 → 0.9.15

## [0.9.14] - 2026-02-25

### Added
- **`synth ui` CLI command** — launches the browser-based testing UI as a subprocess using `sys.executable`, with agent discovery fallback when no file is specified. Works correctly with pipx installs
- **Web search API key prompt in `synth init`** — when the web search tool is selected during project setup, the wizard now prompts for a Brave, SerpAPI, or Tavily API key and saves it to `.env`. Skips the prompt if a key is already set in the environment. Applies to both single-agent and multi-agent flows
- **Dockerfile folder validation in `synth deploy`** — new validation stage between manifest generation and packaging checks that the agent name matches a folder under `.bedrock_agentcore/`, with actionable error messages listing available folders on mismatch

### Fixed
- **Agent loader sys.path injection** — centralized in both `run_cmd._load_agent` and `_tui._load_agent_module` with duplicate-entry prevention. Non-existent file paths now produce a clear error message instead of a raw traceback
- **UI server memory support** — chat endpoints now pass `thread_id=conv_id` to `agent.run()` and `agent.stream()`, enabling conversation memory in the browser UI
- **UI server true streaming** — replaced the buffered `list(agent.stream())` pattern with a queue-based approach that yields events as they arrive from a background thread
- **UI server event detection** — replaced string-based `type(event).__name__` checks with `isinstance()` using imported event types from `synth.types`
- **UI server tool error surfacing** — tool initialization errors during agent loading are now captured and exposed via `/api/info`
- **Bedrock content block sanitization** — added `_sanitize_content()` helper in `agent.py` that replaces empty, None, or whitespace-only tool results with `"(no content)"` before appending to the message list, preventing Bedrock `ValidationException` errors
- **Venv-aware UI launch in init flow** — `_prompt_testing_mode` now passes `SYNTH_AGENT_FILE` in the subprocess environment and uses `sys.executable` consistently

### Changed
- **Version bump** — 0.9.13 → 0.9.14

## [0.9.13] - 2026-02-24

### Fixed
- **Search no longer uses Playwright** — `BrowserTools.search()` now uses httpx exclusively (DuckDuckGo HTML + lite endpoints). Eliminates the "Playwright Sync API inside asyncio loop" error that occurred when the agent called search tools from within the async `arun()` method
- **`navigate()` httpx-first** — page fetching tries httpx before Playwright, so `browse_web` works without browser binaries for most pages
- **DuckDuckGo ad URLs filtered** — redirect URLs pointing to `bing.com/aclick` are now skipped, so results only contain real destination URLs
- **Deployment readiness checks Playwright** — `synth deploy` now reports whether Playwright is installed when browser tools are registered

### Changed
- **Playwright added to `aws`/`agentcore` extras** — `pip install synth-agent-sdk[aws]` now includes `playwright>=1.40`. Browser binaries still require `playwright install chromium`
- **Version bump** — 0.9.12 → 0.9.13

## [0.9.12] - 2026-02-24

### Fixed
- **`browse_web` no longer requires playwright** — `navigate()` now uses `httpx` as the primary path (fetches page, strips HTML, returns text), falling back to Playwright only if the simple fetch fails. Previously every `browse_web` call failed with "playwright is not installed"
- **Search results now have clean URLs** — DuckDuckGo redirect URLs (`duckduckgo.com/y.js?...`) are resolved to the actual destination URL. HTML entities in titles and snippets are decoded
- **DuckDuckGo rate-limit resilience** — `_search_httpx` now falls back to DuckDuckGo's lite endpoint (`lite.duckduckgo.com`) when the HTML endpoint returns a CAPTCHA/challenge (HTTP 202), which happens under sustained automated use
- **Tool call loop capped at 10 rounds** — the agent's tool execution loop now stops after 10 rounds of tool calls to prevent the model from spiralling into infinite empty-args retry loops

### Changed
- **Version bump** — 0.9.11 → 0.9.12

## [0.9.11] - 2026-02-24

### Fixed
- **Bedrock tool name attribution** — `_build_messages` no longer hardcodes `"tool_call"` as the tool name in synthetic `toolUse` blocks. Tool result messages now carry a `tool_name` field that the Bedrock provider reads to build correctly attributed `toolUse`/`toolResult` pairs. This fixes the root cause of the `Unknown tool 'tool_call'` error where the model would see every tool result attributed to a nonexistent tool named `"tool_call"` and then try to call it
- **BrowserTools search returning empty results** — rewrote the DuckDuckGo HTML parser to extract titles/URLs and snippets separately instead of trying to match both in a single regex, which failed on DuckDuckGo's actual HTML structure where snippets are `<a>` tags not `<td>` elements
- **Tool execution errors no longer crash the run** — the agent's tool loop now catches `ToolExecutionError` and feeds the error message back to the model as a tool result, allowing the model to recover or retry with the correct tool name

### Changed
- **`Message` TypedDict extended** — added optional `tool_name: str` field to `Message` for tool result attribution. Backward compatible — existing messages without the field still work (falls back to `"tool_call"`)
- **Version bump** — 0.9.10 → 0.9.11

## [0.9.10] - 2026-02-24

### Fixed
- **BrowserTools search returning empty results** — rewrote the DuckDuckGo HTML parser to extract titles/URLs and snippets separately instead of trying to match both in a single regex pattern, which failed on DuckDuckGo's actual HTML structure
- **"Unknown tool 'tool_call'" crash** — the agent's tool execution loop now catches `ToolExecutionError` and feeds the error message back to the model as a tool result instead of crashing the run. This handles cases where Bedrock returns a malformed tool name

### Changed
- **Version bump** — 0.9.9 → 0.9.10

## [0.9.9] - 2026-02-24

### Fixed
- **BrowserTools.search() no longer requires playwright** — the search method now uses a lightweight `httpx` request to DuckDuckGo's HTML endpoint as the primary path, falling back to the full AgentCore Browser (via Playwright) only if the simple fetch fails. This eliminates the `"playwright is not installed"` error that occurred when using the browser-based search tool without playwright installed

### Changed
- **Version bump** — 0.9.8 → 0.9.9

## [0.9.8] - 2026-02-24

### Added
- **AgentCore Memory integration** — replaced stub `AgentCoreMemory` with real API calls using `bedrock_agentcore.memory.MemoryClient`. Conversation history is now stored and retrieved via the AgentCore events API (`create_event` / `get_last_k_turns`), with role mapping between Synth and AgentCore formats
- **Auto-configured memory in AgentCore deployments** — `AgentCoreAdapter` now automatically wraps the agent with `AgentCoreMemory` when no memory backend is configured, so conversation persistence works out of the box without manual setup
- **Built-in `web_search` tool** — `synth.tools.web_search` provides a real web search tool supporting Brave Search, SerpAPI, and Tavily via environment variables. Auto-detects whichever provider is configured
- **AgentCore Browser tool** — `synth.deploy.agentcore.BrowserTools` wraps the AgentCore Browser service for zero-config web search and page navigation using AWS credentials only (no third-party API keys)
- **AgentCore Code Interpreter in tool catalog** — `synth init` now offers Code Interpreter as a pre-built tool option for sandboxed Python execution via AgentCore
- **Deployment readiness stage** — `synth deploy` now runs a 7th stage between packaging and API submission that reports on auth method, memory, guards, tools, output schema, search API keys, and target region/model with warnings for missing components

### Fixed
- **All scaffold stubs replaced with working implementations** — `search_web`, `search`, and `write_file` stubs in `synth init` and `synth create` templates now delegate to real implementations instead of returning placeholder strings

### Changed
- **Version bump** — 0.9.7 → 0.9.8

## [0.9.7] - 2026-02-24

### Fixed
- **Bedrock Converse API blank text block rejection** — fixed `ValidationException: The text field in the ContentBlock object is blank` error when tool results (e.g., from web search) return empty content. The Bedrock provider now sanitizes all text content blocks (system messages, user/assistant messages, and tool results) via `_sanitize_text()`, replacing empty or whitespace-only strings with `"(no content)"` before sending to the Converse API
- **Agent discovery model extraction** — fixed `discover_agents()` returning empty model strings when `model=` appeared inline (e.g., `Agent(model="claude-sonnet-4-5")`) rather than on its own line. The parser now uses a regex search across the full file content

### Changed
- **Version bump** — 0.9.6 → 0.9.7

## [0.9.6] - 2026-02-24

### Added
- **`synth dev` cloud status detection** — when no file argument is given, `synth dev` now queries the AgentCore CLI (`agentcore list`) to check live deployment status of agents with `agentcore.yaml`, showing color-coded badges (active, creating, failed, etc.) in the agent picker
- **Deploy-or-interact routing** — `synth dev` automatically detects whether an AgentCore agent is deployed; if live, opens the REPL directly; if not, prompts to deploy first
- **Agent name validation** — `_stage_manifest` now validates agent names against AgentCore's naming rules (letters/numbers/underscores, 1–48 chars, starts with letter) and fails early with an actionable error message instead of waiting for the AgentCore CLI to reject it
- **Agent name auto-sanitization** — when `agent_name` from `agentcore.yaml` contains invalid characters (spaces, hyphens, etc.), it is automatically sanitized with a notification showing the original and sanitized names

### Fixed
- **Bedrock Converse API tool result formatting** — fixed `ValidationException: Value 'tool' at 'messages.N.member.role' failed to satisfy constraint` error when agents with tools made multiple tool calls via Bedrock. The provider now correctly translates `role: "tool"` messages into `role: "user"` with `toolResult` content blocks, and injects `toolUse` blocks into preceding assistant messages, matching the Bedrock Converse API's required message format
- **Bedrock message role alternation** — added `_merge_consecutive_roles()` to ensure strictly alternating user/assistant messages as required by the Converse API
- **AgentCore agent name validation** — `_sanitize_for_path` now uses underscores instead of hyphens and enforces AgentCore's naming constraints (must start with a letter, alphanumeric + underscores only, max 48 chars). Previously, names like "Travel Agent" or names with hyphens were rejected by the AgentCore CLI with an unhelpful error
- **RequestsDependencyWarning masking real errors** — `_stage_submit` now sets `PYTHONWARNINGS=ignore` in the subprocess environment when calling the AgentCore CLI, preventing `RequestsDependencyWarning` from `requests`/`urllib3`/`chardet` version mismatches from polluting stderr and hiding the actual error message

### Changed
- **Version bump** — 0.9.5 → 0.9.6

## [0.9.5] - 2026-02-24

### Added
- **`[ui]` optional extra** — `pip install synth-agent-sdk[ui]` installs `uvicorn` and `fastapi` for the testing dashboard
- **Auto-install UI dependencies** — choosing "ui" testing mode during `synth init` automatically installs `uvicorn` and `fastapi` if missing
- **Global UI dashboard** — the testing UI is now scaffolded once at the workspace root (`./ui/`) and shared across all agents in the project, instead of being created per-agent
- **UI server reuse detection** — `synth init` detects if the UI server is already running on port 8420 and shows the URL instead of re-scaffolding or re-launching
- **Agent `sys.path` injection** — the UI server automatically adds the agent's parent directory to `sys.path` before loading, so sibling imports (e.g. `from tools import ...`) resolve without manual `PYTHONPATH` configuration

### Fixed
- **UI server path doubling** — fixed `[Errno 2] No such file or directory` when launching the UI server after `synth init`; the project directory was being doubled in the path (`Pointy/Pointy/ui/server.py`)
- **`isinstance()` with parameterized generics** — fixed `TypeError: isinstance() argument 2 cannot be a parameterized generic` crash on Python 3.10 when tools declare return types like `list[str]`; `ToolExecutor._check_return_type` now uses `typing.get_origin()` to unwrap generics before the check
- **Agent instructions with special characters** — fixed `SyntaxError` in generated `agent.py` when user instructions contain quotes, em dashes, backslashes, or other special characters; instructions are now embedded using `repr()` for bulletproof escaping
- **Windows backslash escape in AGENT_FILE** — fixed `\a` being interpreted as a bell escape character on Windows by normalizing paths to forward slashes in the generated UI server config

### Changed
- **Version bump** — 0.9.0 → 0.9.5

## [0.9.0] - 2026-02-23

### Added
- **AgentCore Evaluations init wiring** — `synth init` with AgentCore provider and "eval" feature now generates `eval_config.json` with three built-in evaluators (Helpfulness, Correctness, GoalSuccessRate), adds an `evaluations` section to `agentcore.yaml`, and appends evaluation IAM permissions (`CreateEvaluationConfig`, `RunEvaluation`, `GetEvaluationResults`, `CreateLogGroup`, `PutLogEvents`)
- **Evaluator ARN validation** — `_validate_evaluator_arns()` warns during init if evaluator ARNs don't match the expected `arn:aws:bedrock-agentcore:::evaluator/Builtin.*` pattern
- **Agent code eval comment** — generated agent code for AgentCore + eval includes a comment block referencing `eval_config.json`
- **Dashboard Evaluations sub-section** — AgentCore tab gains an Evaluations panel with evaluator score summary table (scores below 0.5 flagged), online evaluation config status, and "Run Evaluation" button
- **Evaluation API endpoints** — `GET /api/agentcore/evaluations`, `POST /api/agentcore/evaluations/run`, `GET /api/agentcore/evaluations/config` with credential scrubbing on all responses
- **`EvaluationResult` and `EvaluationConfigStatus` dataclasses** — typed data models for evaluation API responses
- **`_parse_eval_config()`** — server-side parser for `eval_config.json` following the `_parse_agentcore_yaml()` pattern
- **`_parse_agentcore_yaml()` evaluations detection** — returned dict now includes `evaluations_configured: bool` based on YAML section or `eval_config.json` presence
- **Credential scrubbing helpers** — `_scrub_credentials()` and `_scrub_dict()` for recursive redaction of AWS access key patterns in evaluation data
- **Property-based tests** — 8 Hypothesis properties (100 examples each) covering eval config generation, YAML eval section, agent code comments, ARN validation, response shapes, and credential scrubbing
- **Backward compatibility tests** — unit and property tests verifying `_build_agentcore_yaml()` produces unchanged output when `features` is omitted

### Changed
- **`_build_agentcore_yaml()`** — gains optional `features` parameter; when `"eval"` is present, appends evaluations section and IAM permissions; fully backward-compatible

## [0.6.1] - 2026-02-20

### Changed
- **Init flow redesign** — `synth init` wizard now follows a more logical step order: name → description → provider → model selection → instructions → tool wizard → MCP wizard → features → credential check → summary → generate → deploy prompt
- **Split `_run_agentcore_setup()`** — replaced the monolithic function with two focused helpers: `_run_model_selection()` (handles model picking for all providers) and `_run_credential_check()` (handles AWS credential detection for AgentCore)
- **Removed "tools" from feature selection** — tool configuration is now handled entirely by the Tool Wizard step, eliminating the redundant feature toggle
- **Post-generation deploy prompt** — after `synth init` generates an AgentCore project, users are now prompted "Deploy now?" to optionally deploy in a single session

### Fixed
- **Bedrock model ID prefix bug** — `synth init` now correctly prepends `bedrock/` to the effective model ID for AgentCore projects, preventing runtime `ProviderRouter` failures. Double-prefixing (`bedrock/bedrock/...`) is also prevented.

## [0.6.0] - 2026-02-20

### Added
- **AgentCore credential detection** — `CredentialResolver` auto-detects AWS credentials from env vars, `~/.aws/credentials`, and AWS Toolkit VS Code profiles during `synth init` and `synth create agent --provider agentcore`
- **Model selection with CRIS validation** — region-aware model picker backed by `ModelCatalog` and `RegionValidator`; automatically selects the correct base or cross-region inference profile ID and writes `aws_region`, `model_id`, `cris_enabled`, `aws_profile` to `agentcore.yaml`
- **Tool Wizard and MCP Wizard** — optional sub-wizards during `synth init` to scaffold pre-built tools (`tools.py`) or MCP servers (`server.py`) from a catalog, or generate custom `@tool` / `@mcp.tool()` stubs
- **Deploy Wizard** (`synth deploy --target agentcore`) — six-stage guided deployment with `[  OK  ]` / `[FAIL]` status output, `--dry-run` support, and a success summary showing agent ARN, region, and model ID
- **Edit Wizard** (`synth edit agent <file>`) — interactive wizard to modify instructions, model, tools, or MCP servers in an existing agent; shows a diff before writing; uses atomic temp-file rename
- **AgentCore Doctor checks** — `synth doctor` now validates `agentcore.yaml` fields (`aws_region`, `model_id`, `cris_enabled`, `aws_profile`) when the file is present, printing `[  OK  ]` or `[FAIL]` for each
- **Packager credential scan** — `synth deploy` packaging step aborts with `SynthConfigError` if `agentcore.yaml` contains AWS access key or secret key patterns; `.env` files are always excluded from artifacts

### Changed
- **Google provider** — migrated from deprecated `google-generativeai` to `google-genai>=1.0` SDK; updated to the new `genai.Client` / `client.aio.models.generate_content` API
- **`synth doctor`** — core dependency version detection now uses `importlib.metadata.version()` instead of `pkg.__version__` (eliminates Click 9.x `DeprecationWarning`)
- **`pyproject.toml`** — `synth[google]` extra updated to `google-genai>=1.0`

### Fixed
- Unclosed file handles in `test_init_wizard.py` (eliminated `ResourceWarning`)

## [0.5.7] - 2026-02-19

### Fixed
- **`synth create agentcore`** — fixed `KeyError: 'name'` crash when scaffolding an AgentCore agent. The `greet` tool's f-string literal `{name}` was unescaped inside a `.format()` call, causing Python to treat it as a missing format key. Escaped to `{{name}}` so the generated code renders correctly.

## [0.5.6] - 2026-02-19

### Added
- **Interactive shell** — running `synth` with no arguments now launches a persistent REPL instead of printing help. Commands are typed without the `synth` prefix (e.g. `run agent.py "Hello"`, `create agent my-bot`). Features tab completion, persistent `~/.synth_history`, Ctrl+C to clear line, Ctrl+D or `exit`/`quit` to leave.

## [0.5.5] - 2025-02-19

### Added
- **`synth/deploy/agentcore/auth.py`** — `extract_user_id()` securely extracts user identity from the AgentCore `RequestContext` JWT (prevents prompt injection impersonation); `get_gateway_token()` implements OAuth2 client credentials flow for Gateway authentication
- **`synth/deploy/agentcore/ssm.py`** — `get_ssm_parameter()` helper for reading runtime config from AWS SSM Parameter Store
- **`synth/deploy/agentcore/gateway.py`** — `GatewayMCPClient` and `create_gateway_client()` factory for connecting agents to AgentCore Gateway via MCP, with automatic credential resolution from SSM + Secrets Manager; supports both Strands (`as_mcp_client()`) and LangGraph (`as_langgraph_client()`) integration styles
- **`synth/deploy/agentcore/code_interpreter.py`** — `CodeInterpreterTools` framework-agnostic wrapper for AgentCore Code Interpreter; lazy session init, persistent sandbox state, `execute()` and `execute_python()` methods
- **`agentcore` extra** — added `PyJWT>=2.8` and `requests>=2.31` dependencies

### Changed
- **`AgentCoreAdapter`** — now accepts optional `RequestContext` and extracts user ID from JWT; passes `thread_id` from `runtimeSessionId`; validates payload schema before processing
- **`agentcore_handler()`** — entrypoint now passes `context` through to the adapter for JWT user extraction
- **`synth create agentcore`** scaffolding — generates full production-ready agent with Gateway MCP client, Code Interpreter tool, JWT user extraction, SSM config, and updated `agentcore.yaml` with correct IAM permissions
- **`synth/deploy/agentcore/__init__.py`** — exports all new public symbols

### Fixed
- **Packager self-copy bug** — `synth deploy` no longer crashes when `dist/` exists inside the source directory

## [0.5.4] - 2025-02-19

### Fixed
- **Packager self-copy bug**: `synth deploy` no longer crashes with `shutil.Error` when the `dist` output directory exists inside the source directory. The packager now resolves and skips the output path during iteration to prevent recursive self-copy on Windows and Linux.

## [0.5.3] - 2025-02-19

### Fixed
- **AgentCore deployment pattern**: Updated `agentcore_handler()` to use the correct `BedrockAgentCoreApp` pattern required by AgentCore runtime
- **AgentCore dependencies**: Added `bedrock-agentcore>=0.1.0` to the `agentcore` extra for proper deployment support

### Changed
- `agentcore_handler()` now returns a `BedrockAgentCoreApp` instance instead of a plain function
- Updated all AgentCore scaffolding templates to use `app = agentcore_handler(agent)` pattern

## [0.5.2] - 2025-02-19

### Added
- **Quickstart extra**: New `synth-agent-sdk[quickstart]` installs both Anthropic and OpenAI providers for easy demos
- **First-run welcome message**: Beautiful onboarding experience on first `synth` command with setup guide
- **`synth info` command**: Shows what's included in each installation option (provider, dependencies, models)
- **Enhanced `synth doctor`**: Now suggests specific install commands when providers are missing

### Improved
- **Installation documentation**: Reorganized README to lead with most common use case
- **Error messages**: All provider errors now include clear `pip install` instructions
- **User experience**: Better guidance for new users throughout the installation and setup process

### Changed
- Installation section in README now recommends `synth-agent-sdk[anthropic]` as the starting point

## [0.5.1] - Previous Release

Initial release with core SDK functionality.
