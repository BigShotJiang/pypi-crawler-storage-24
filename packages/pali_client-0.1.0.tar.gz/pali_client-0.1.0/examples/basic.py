"""Basic sync client example."""

from pali import PaliClient


def main() -> None:
    client = PaliClient("http://127.0.0.1:8080")
    try:
        client.create_tenant("user:42", name="User 42")
        client.store("user:42", "Likes jazz", tags=["music"], kind="observation")
        results = client.search("user:42", "music preferences", top_k=3)
        for item in results.items:
            print(item.content)
    finally:
        client.close()


if __name__ == "__main__":
    main()
