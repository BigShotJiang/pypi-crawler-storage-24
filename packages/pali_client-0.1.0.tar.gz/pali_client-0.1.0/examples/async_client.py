"""Async client example."""

from __future__ import annotations

import asyncio

from pali import PaliAsyncClient


async def main() -> None:
    async with PaliAsyncClient("http://127.0.0.1:8080") as client:
        health = await client.health()
        print(health.status)


if __name__ == "__main__":
    asyncio.run(main())
