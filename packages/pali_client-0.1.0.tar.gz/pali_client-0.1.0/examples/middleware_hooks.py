"""Middleware hooks example."""

from __future__ import annotations

from pali import PaliClient, PaliMiddleware


def log_hook(phase: str, payload: dict[str, object]) -> None:
    print(f"{phase}: {sorted(payload.keys())}")


def llm(messages: list[dict[str, str]]) -> str:
    return f"message_count={len(messages)}"


def main() -> None:
    client = PaliClient("http://127.0.0.1:8080")
    try:
        middleware = PaliMiddleware(
            client,
            "user:42",
            hooks={
                "SEARCH": [log_hook],
                "INJECT": [log_hook],
                "CALL": [log_hook],
                "STORE": [log_hook],
            },
        )
        wrapped = middleware.wrap(llm)
        print(wrapped([{"role": "user", "content": "What music do I like?"}]))
    finally:
        client.close()


if __name__ == "__main__":
    main()
