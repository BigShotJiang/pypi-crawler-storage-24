from __future__ import annotations

import httpx
import pytest

from pali._retry import RetryConfig
from pali._transport import (
    DEFAULT_USER_AGENT,
    ClientConfig,
    SyncTransport,
    parse_api_error,
    parse_datetime,
    resolve_config,
)
from pali.errors import (
    APIError,
    ForbiddenError,
    TransportError,
    UnauthorizedError,
    ValidationError,
)


def test_resolve_config_rejects_invalid_timeout_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALI_BASE_URL", "http://example.com")
    monkeypatch.setenv("PALI_TIMEOUT", "abc")

    with pytest.raises(ValidationError):
        resolve_config(None, token=None, timeout=None, max_retries=3)


def test_parse_api_error_maps_status_to_subclass() -> None:
    response = httpx.Response(
        401,
        json={"error": "bad token"},
        headers={"X-Request-ID": "req_1"},
    )

    error = parse_api_error(response)

    assert isinstance(error, UnauthorizedError)
    assert error.request_id == "req_1"
    assert error.code == "unauthorized"


def test_parse_api_error_uses_server_code_when_present() -> None:
    response = httpx.Response(
        403,
        json={"message": "tenant mismatch", "code": "tenant_mismatch"},
    )

    error = parse_api_error(response)

    assert isinstance(error, ForbiddenError)
    assert error.code == "tenant_mismatch"


def test_parse_api_error_handles_plain_text_body() -> None:
    response = httpx.Response(500, text="server exploded")

    error = parse_api_error(response)

    assert isinstance(error, APIError)
    assert error.code == "internal_error"
    assert error.body == "server exploded"


def test_sync_transport_sends_auth_and_versioned_user_agent() -> None:
    captured_headers: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured_headers["authorization"] = request.headers.get("Authorization", "")
        captured_headers["user-agent"] = request.headers.get("User-Agent", "")
        return httpx.Response(200, json={"status": "ok"})

    transport = httpx.MockTransport(handler)
    http_client = httpx.Client(transport=transport, base_url="http://example.com")
    client_config = ClientConfig(
        base_url="http://example.com",
        token="secret",
        timeout=15.0,
        retry=RetryConfig(max_attempts=1),
    )
    transport_wrapper = SyncTransport(client_config, http_client=http_client)

    payload = transport_wrapper.request_json("GET", "/health", retryable=True)

    assert payload["status"] == "ok"
    assert captured_headers["authorization"] == "Bearer secret"
    assert captured_headers["user-agent"] == DEFAULT_USER_AGENT

    transport_wrapper.close()
    http_client.close()


def test_sync_transport_invalid_json_raises_transport_error() -> None:
    transport = httpx.MockTransport(lambda request: httpx.Response(200, text="not json"))
    http_client = httpx.Client(transport=transport, base_url="http://example.com")
    wrapper = SyncTransport(
        ClientConfig(
            base_url="http://example.com",
            token=None,
            timeout=15.0,
            retry=RetryConfig(max_attempts=1),
        ),
        http_client=http_client,
    )

    with pytest.raises(TransportError):
        wrapper.request_json("GET", "/health", retryable=True)

    wrapper.close()
    http_client.close()


def test_parse_datetime_normalizes_z_suffix() -> None:
    parsed = parse_datetime("2026-03-07T00:00:00Z")

    assert parsed.isoformat() == "2026-03-07T00:00:00+00:00"
