from __future__ import annotations

from datetime import datetime, timedelta, timezone

import httpx
import pytest

from pali._retry import RetryConfig, compute_delay, should_retry_exception, should_retry_status


def test_should_retry_exception_recognizes_retryable_httpx_errors() -> None:
    assert should_retry_exception(httpx.ConnectTimeout("boom"))
    assert should_retry_exception(httpx.ReadTimeout("boom"))
    assert not should_retry_exception(ValueError("boom"))


def test_should_retry_status_only_retries_429_and_503() -> None:
    assert should_retry_status(429)
    assert should_retry_status(503)
    assert not should_retry_status(500)
    assert not should_retry_status(404)


def test_compute_delay_uses_retry_after_seconds() -> None:
    response = httpx.Response(429, headers={"Retry-After": "1.25"})

    delay = compute_delay(2, response, RetryConfig())

    assert delay == pytest.approx(1.25)


def test_compute_delay_uses_retry_after_http_date() -> None:
    retry_at = datetime.now(timezone.utc) + timedelta(seconds=2)
    response = httpx.Response(
        429,
        headers={"Retry-After": retry_at.strftime("%a, %d %b %Y %H:%M:%S GMT")},
    )

    delay = compute_delay(1, response, RetryConfig())

    assert 0.0 <= delay <= 2.1


def test_compute_delay_uses_full_jitter_when_retry_after_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("pali._retry.random.uniform", lambda low, high: high / 2)

    delay = compute_delay(3, None, RetryConfig(base_delay=0.2, max_delay=5.0))

    assert delay == pytest.approx(0.4)
