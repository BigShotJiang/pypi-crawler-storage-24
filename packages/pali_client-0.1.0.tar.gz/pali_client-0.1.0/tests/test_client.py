from __future__ import annotations

import httpx
import pytest
import respx

from pali import (
    APIError,
    NotFoundError,
    PaliAsyncClient,
    PaliClient,
    RateLimitError,
    SearchMemoryRequest,
    StoreMemoryRequest,
    TransportError,
    ValidationError,
)


def test_constructor_uses_env_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALI_BASE_URL", "http://env.example")
    monkeypatch.setenv("PALI_TOKEN", "env-token")
    monkeypatch.setenv("PALI_TIMEOUT", "9.5")

    with respx.mock(base_url="http://env.example") as router:
        route = router.get("/health").mock(
            return_value=httpx.Response(200, json={"status": "ok", "time": "2026-03-07T00:00:00Z"})
        )
        client = PaliClient()
        health = client.health()
        client.close()

    assert route.called
    assert health.status == "ok"


def test_constructor_argument_overrides_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALI_BASE_URL", "http://env.example")

    with respx.mock(base_url="http://override.example") as router:
        route = router.get("/health").mock(
            return_value=httpx.Response(200, json={"status": "ok", "time": "2026-03-07T00:00:00Z"})
        )
        client = PaliClient("http://override.example")
        client.health()
        client.close()

    assert route.called


def test_validation_happens_before_network() -> None:
    client = PaliClient("http://example.com")
    with pytest.raises(ValidationError):
        client.search("", "")
    client.close()


def test_store_uses_typed_request() -> None:
    with respx.mock(base_url="http://example.com") as router:
        route = router.post("/v1/memory").mock(
            return_value=httpx.Response(
                201,
                json={"id": "mem_1", "created_at": "2026-03-07T00:00:00Z"},
            )
        )
        client = PaliClient("http://example.com")
        stored = client.store(
            StoreMemoryRequest(
                tenant_id="tenant_1",
                content="Likes tea",
                kind="observation",
                created_by="user",
            )
        )
        client.close()

    assert route.called
    assert stored.id == "mem_1"


def test_tenant_stats_is_wired() -> None:
    with respx.mock(base_url="http://example.com") as router:
        route = router.get("/v1/tenants/tenant_1/stats").mock(
            return_value=httpx.Response(
                200,
                json={"tenant_id": "tenant_1", "memory_count": 7},
            )
        )
        client = PaliClient("http://example.com")
        stats = client.tenant_stats("tenant_1")
        client.close()

    assert route.called
    assert stats.memory_count == 7


def test_search_parses_debug_payload() -> None:
    payload = {
        "items": [
            {
                "id": "mem_1",
                "tenant_id": "tenant_1",
                "content": "Likes tea",
                "tier": "semantic",
                "tags": ["preferences"],
                "source": "chat_message",
                "created_by": "user",
                "kind": "observation",
                "recall_count": 2,
                "created_at": "2026-03-07T00:00:00Z",
                "updated_at": "2026-03-07T00:00:00Z",
                "last_accessed_at": "2026-03-07T00:00:00Z",
                "last_recalled_at": "2026-03-07T00:00:00Z",
            }
        ],
        "debug": {
            "plan": {
                "intent": "fact_lookup",
                "confidence": 0.91,
                "entities": ["tea"],
                "relations": [],
                "time_constraints": [],
                "required_evidence": "single_fact",
                "fallback_path": ["semantic"],
            },
            "ranking": [
                {
                    "rank": 1,
                    "memory_id": "mem_1",
                    "kind": "observation",
                    "tier": "semantic",
                    "lexical_score": 0.6,
                    "query_overlap": 0.8,
                    "route_fit": 1.0,
                }
            ],
        },
    }
    with respx.mock(base_url="http://example.com") as router:
        router.post("/v1/memory/search").mock(return_value=httpx.Response(200, json=payload))
        client = PaliClient("http://example.com")
        response = client.search(SearchMemoryRequest(tenant_id="tenant_1", query="tea", debug=True))
        client.close()

    assert response.debug is not None
    assert response.debug.plan.intent == "fact_lookup"
    assert response.debug.ranking[0].memory_id == "mem_1"


def test_api_errors_are_typed() -> None:
    with respx.mock(base_url="http://example.com") as router:
        router.delete("/v1/memory/missing").mock(
            return_value=httpx.Response(
                404,
                json={"error": "memory not found", "code": "not_found"},
                headers={"X-Request-ID": "req_123"},
            )
        )
        client = PaliClient("http://example.com")
        with pytest.raises(NotFoundError) as exc_info:
            client.delete("tenant_1", "missing")
        client.close()

    assert exc_info.value.request_id == "req_123"


def test_retryable_search_retries_on_503(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("pali._transport.sleep_sync", lambda _: None)
    with respx.mock(base_url="http://example.com") as router:
        route = router.post("/v1/memory/search")
        route.side_effect = [
            httpx.Response(503, json={"error": "busy"}),
            httpx.Response(200, json={"items": []}),
        ]
        client = PaliClient("http://example.com")
        response = client.search("tenant_1", "tea")
        client.close()

    assert response.items == ()
    assert route.call_count == 2


def test_store_does_not_retry_on_503(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("pali._transport.sleep_sync", lambda _: None)
    with respx.mock(base_url="http://example.com") as router:
        route = router.post("/v1/memory").mock(
            return_value=httpx.Response(503, json={"error": "busy"})
        )
        client = PaliClient("http://example.com")
        with pytest.raises(APIError):
            client.store("tenant_1", "tea")
        client.close()

    assert route.call_count == 1


def test_retry_after_maps_to_rate_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("pali._transport.sleep_sync", lambda _: None)
    with respx.mock(base_url="http://example.com") as router:
        route = router.post("/v1/memory/search").mock(
            return_value=httpx.Response(
                429,
                json={"error": "slow down", "code": "rate_limited"},
                headers={"Retry-After": "0"},
            )
        )
        client = PaliClient("http://example.com", max_retries=1)
        with pytest.raises(RateLimitError):
            client.search("tenant_1", "tea")
        client.close()

    assert route.call_count == 1


def test_network_errors_raise_transport_error() -> None:
    transport = httpx.MockTransport(
        lambda request: (_ for _ in ()).throw(httpx.ConnectTimeout("boom"))
    )
    http_client = httpx.Client(transport=transport, base_url="http://example.com")
    client = PaliClient("http://example.com", http_client=http_client, max_retries=1)

    with pytest.raises(TransportError):
        client.health()

    client.close()
    http_client.close()


@pytest.mark.asyncio
async def test_async_client_has_parity() -> None:
    with respx.mock(base_url="http://example.com") as router:
        router.get("/health").mock(
            return_value=httpx.Response(200, json={"status": "ok", "time": "2026-03-07T00:00:00Z"})
        )
        router.post("/v1/memory/search").mock(return_value=httpx.Response(200, json={"items": []}))
        async with PaliAsyncClient("http://example.com") as client:
            health = await client.health()
            results = await client.search("tenant_1", "tea")

    assert health.status == "ok"
    assert results.items == ()
