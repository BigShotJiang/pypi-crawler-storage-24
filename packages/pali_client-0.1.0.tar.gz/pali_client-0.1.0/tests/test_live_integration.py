from __future__ import annotations

import os
from uuid import uuid4

import pytest

from pali import PaliClient

LIVE_BASE_URL = os.getenv("PALI_TEST_BASE_URL")
LIVE_TOKEN = os.getenv("PALI_TEST_TOKEN")


@pytest.mark.live
@pytest.mark.skipif(
    not LIVE_BASE_URL,
    reason="set PALI_TEST_BASE_URL to run live integration tests",
)
def test_live_server_round_trip() -> None:
    tenant_id = f"sdk-test-{uuid4().hex[:8]}"
    client = PaliClient(LIVE_BASE_URL, token=LIVE_TOKEN)
    try:
        client.create_tenant(tenant_id, name="SDK Live Test")
        stored = client.store(tenant_id, "User likes tea", kind="observation", created_by="user")
        stats = client.tenant_stats(tenant_id)
        results = client.search(tenant_id, "tea", top_k=3)
        client.delete(tenant_id, stored.id)
    finally:
        client.close()

    assert stats.tenant_id == tenant_id
    assert any(item.id == stored.id for item in results.items)
