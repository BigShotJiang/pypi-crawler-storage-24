from __future__ import annotations

from dataclasses import dataclass

import httpx
import pytest
import respx

from pali import (
    DeleteMemoryAction,
    PaliAsyncClient,
    PaliClient,
    PaliMiddleware,
    ReplaceMemoryAction,
    StoreMemoryRequest,
)


def test_middleware_injects_memories_and_stores_turns() -> None:
    with respx.mock(base_url="http://example.com") as router:
        search_route = router.post("/v1/memory/search").mock(
            return_value=httpx.Response(
                200,
                json={
                    "items": [
                        {
                            "id": "mem_1",
                            "tenant_id": "tenant_1",
                            "content": "User likes jazz.",
                            "tier": "semantic",
                            "tags": [],
                            "source": "seed",
                            "created_by": "system",
                            "kind": "observation",
                            "recall_count": 0,
                            "created_at": "2026-03-07T00:00:00Z",
                            "updated_at": "2026-03-07T00:00:00Z",
                            "last_accessed_at": "2026-03-07T00:00:00Z",
                            "last_recalled_at": "2026-03-07T00:00:00Z",
                        }
                    ]
                },
            )
        )
        batch_route = router.post("/v1/memory/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "items": [
                        {"id": "mem_2", "created_at": "2026-03-07T00:00:00Z"},
                        {"id": "mem_3", "created_at": "2026-03-07T00:00:00Z"},
                    ]
                },
            )
        )

        seen_messages: list[object] = []

        def llm(messages: list[dict[str, str]]) -> str:
            seen_messages.extend(messages)
            return "You like jazz."

        client = PaliClient("http://example.com")
        middleware = PaliMiddleware(client, "tenant_1")
        wrapped = middleware.wrap(llm)
        result = wrapped([{"role": "user", "content": "What music do I like?"}])
        client.close()

    assert search_route.called
    assert batch_route.called
    assert result == "You like jazz."
    assert seen_messages[0]["role"] == "system"
    assert "User likes jazz." in seen_messages[0]["content"]


def test_middleware_degrades_when_search_fails() -> None:
    with respx.mock(base_url="http://example.com") as router:
        router.post("/v1/memory/search").mock(
            return_value=httpx.Response(503, json={"error": "busy"})
        )
        router.post("/v1/memory/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "items": [
                        {"id": "mem_2", "created_at": "2026-03-07T00:00:00Z"},
                        {"id": "mem_3", "created_at": "2026-03-07T00:00:00Z"},
                    ]
                },
            )
        )

        seen_messages: list[object] = []

        def llm(messages: list[dict[str, str]]) -> str:
            seen_messages.extend(messages)
            return "No memory context."

        client = PaliClient("http://example.com", max_retries=1)
        middleware = PaliMiddleware(client, "tenant_1")
        wrapped = middleware.wrap(llm)
        result = wrapped([{"role": "user", "content": "hello"}])
        client.close()

    assert result == "No memory context."
    assert seen_messages[0]["role"] == "user"


def test_middleware_swallows_store_failures() -> None:
    hooks: list[tuple[str, dict[str, object]]] = []

    def hook(phase: str, payload: dict[str, object]) -> None:
        hooks.append((phase, payload))

    with respx.mock(base_url="http://example.com") as router:
        router.post("/v1/memory/search").mock(return_value=httpx.Response(200, json={"items": []}))
        router.post("/v1/memory/batch").mock(
            return_value=httpx.Response(500, json={"error": "boom"})
        )

        client = PaliClient("http://example.com", max_retries=1)
        middleware = PaliMiddleware(client, "tenant_1", hooks={"STORE": [hook]})

        def llm(messages: list[dict[str, str]]) -> str:
            return "reply"

        wrapped = middleware.wrap(llm)
        result = wrapped([{"role": "user", "content": "hello"}])
        client.close()

    assert result == "reply"
    assert any(phase == "STORE" and payload.get("error") for phase, payload in hooks)


def test_middleware_can_replace_memory_when_enabled() -> None:
    with respx.mock(base_url="http://example.com") as router:
        delete_route = router.delete("/v1/memory/mem_1").mock(return_value=httpx.Response(204))
        store_route = router.post("/v1/memory").mock(
            return_value=httpx.Response(
                201,
                json={"id": "mem_2", "created_at": "2026-03-07T00:00:00Z"},
            )
        )
        router.post("/v1/memory/search").mock(
            return_value=httpx.Response(
                200,
                json={
                    "items": [
                        {
                            "id": "mem_1",
                            "tenant_id": "tenant_1",
                            "content": "User lives in Boston.",
                            "tier": "semantic",
                            "tags": ["profile"],
                            "source": "seed",
                            "created_by": "system",
                            "kind": "observation",
                            "recall_count": 0,
                            "created_at": "2026-03-07T00:00:00Z",
                            "updated_at": "2026-03-07T00:00:00Z",
                            "last_accessed_at": "2026-03-07T00:00:00Z",
                            "last_recalled_at": "2026-03-07T00:00:00Z",
                        }
                    ]
                },
            )
        )

        def planner(messages, memories, result, response_text):
            assert memories[0].id == "mem_1"
            return [
                ReplaceMemoryAction(
                    memory_id="mem_1",
                    request=StoreMemoryRequest(
                        tenant_id="tenant_1",
                        content="User lives in Austin.",
                        kind="observation",
                        created_by="system",
                    ),
                )
            ]

        client = PaliClient("http://example.com")
        middleware = PaliMiddleware(
            client,
            "tenant_1",
            allow_destructive_actions=True,
            action_planner=planner,
        )

        def llm(messages: list[dict[str, str]]) -> str:
            return "User now lives in Austin."

        wrapped = middleware.wrap(llm)
        wrapped([{"role": "user", "content": "I moved to Austin."}])
        client.close()

    assert delete_route.called
    assert store_route.called


def test_middleware_skips_delete_actions_without_opt_in() -> None:
    hooks: list[tuple[str, dict[str, object]]] = []

    def hook(phase: str, payload: dict[str, object]) -> None:
        hooks.append((phase, payload))

    with respx.mock(base_url="http://example.com", assert_all_called=False) as router:
        delete_route = router.delete("/v1/memory/mem_1").mock(return_value=httpx.Response(204))
        router.post("/v1/memory/search").mock(return_value=httpx.Response(200, json={"items": []}))

        def planner(messages, memories, result, response_text):
            return [DeleteMemoryAction(memory_id="mem_1")]

        client = PaliClient("http://example.com")
        middleware = PaliMiddleware(
            client,
            "tenant_1",
            hooks={"STORE": [hook]},
            action_planner=planner,
        )

        def llm(messages: list[dict[str, str]]) -> str:
            return "Okay."

        wrapped = middleware.wrap(llm)
        wrapped([{"role": "user", "content": "forget that"}])
        client.close()

    assert not delete_route.called
    assert any(payload.get("skipped_destructive_actions") == 1 for _, payload in hooks)


@pytest.mark.asyncio
async def test_middleware_wraps_async_functions() -> None:
    with respx.mock(base_url="http://example.com") as router:
        router.post("/v1/memory/search").mock(return_value=httpx.Response(200, json={"items": []}))
        router.post("/v1/memory/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "items": [
                        {"id": "mem_2", "created_at": "2026-03-07T00:00:00Z"},
                        {"id": "mem_3", "created_at": "2026-03-07T00:00:00Z"},
                    ]
                },
            )
        )

        async with PaliAsyncClient("http://example.com") as client:
            middleware = PaliMiddleware(client, "tenant_1")

            async def llm(messages: list[dict[str, str]]) -> str:
                return f"count={len(messages)}"

            wrapped = middleware.wrap(llm)
            result = await wrapped([{"role": "user", "content": "hello"}])

    assert result == "count=1"


def test_wrap_openai_proxies_chat_completions() -> None:
    with respx.mock(base_url="http://example.com") as router:
        router.post("/v1/memory/search").mock(return_value=httpx.Response(200, json={"items": []}))
        router.post("/v1/memory/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "items": [
                        {"id": "mem_2", "created_at": "2026-03-07T00:00:00Z"},
                        {"id": "mem_3", "created_at": "2026-03-07T00:00:00Z"},
                    ]
                },
            )
        )

        @dataclass
        class Message:
            content: str

        @dataclass
        class Choice:
            message: Message

        @dataclass
        class Completion:
            choices: list[Choice]

        class Completions:
            def create(self, *, model: str, messages: list[dict[str, str]]) -> Completion:
                assert model == "gpt-test"
                return Completion(choices=[Choice(message=Message(content="answer"))])

        class Chat:
            def __init__(self) -> None:
                self.completions = Completions()

        class OpenAIClient:
            def __init__(self) -> None:
                self.chat = Chat()

        client = PaliClient("http://example.com")
        middleware = PaliMiddleware(client, "tenant_1")
        wrapped_client = middleware.wrap_openai(OpenAIClient())
        completion = wrapped_client.chat.completions.create(
            model="gpt-test",
            messages=[{"role": "user", "content": "hello"}],
        )
        client.close()

    assert completion.choices[0].message.content == "answer"


def test_wrap_anthropic_injects_system_prompt() -> None:
    with respx.mock(base_url="http://example.com") as router:
        router.post("/v1/memory/search").mock(
            return_value=httpx.Response(
                200,
                json={
                    "items": [
                        {
                            "id": "mem_1",
                            "tenant_id": "tenant_1",
                            "content": "User likes green tea.",
                            "tier": "semantic",
                            "tags": [],
                            "source": "seed",
                            "created_by": "system",
                            "kind": "observation",
                            "recall_count": 0,
                            "created_at": "2026-03-07T00:00:00Z",
                            "updated_at": "2026-03-07T00:00:00Z",
                            "last_accessed_at": "2026-03-07T00:00:00Z",
                            "last_recalled_at": "2026-03-07T00:00:00Z",
                        }
                    ]
                },
            )
        )
        router.post("/v1/memory/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "items": [
                        {"id": "mem_2", "created_at": "2026-03-07T00:00:00Z"},
                        {"id": "mem_3", "created_at": "2026-03-07T00:00:00Z"},
                    ]
                },
            )
        )

        seen: dict[str, object] = {}

        class Messages:
            def create(
                self,
                *,
                model: str,
                max_tokens: int,
                system: str | None = None,
                messages: list[dict[str, object]],
            ) -> dict[str, object]:
                seen["model"] = model
                seen["max_tokens"] = max_tokens
                seen["system"] = system
                seen["messages"] = messages
                return {"content": [{"type": "text", "text": "Anthropic answer"}]}

        class AnthropicClient:
            def __init__(self) -> None:
                self.messages = Messages()

        client = PaliClient("http://example.com")
        middleware = PaliMiddleware(client, "tenant_1")
        wrapped = middleware.wrap_anthropic(AnthropicClient())
        result = wrapped.messages.create(
            model="claude-test",
            max_tokens=100,
            system="Original system",
            messages=[{"role": "user", "content": [{"type": "text", "text": "What tea?"}]}],
        )
        client.close()

    assert result["content"][0]["text"] == "Anthropic answer"
    assert isinstance(seen["system"], str)
    assert "User likes green tea." in str(seen["system"])
    assert "Original system" in str(seen["system"])
