"""Typed error hierarchy for the Pali SDK."""

from __future__ import annotations

from dataclasses import dataclass


class PaliError(Exception):
    """Base class for all SDK errors."""


@dataclass(slots=True)
class ValidationError(PaliError):
    """Raised when caller input is invalid before a network call is made."""

    field: str
    message: str

    def __str__(self) -> str:
        return f"pali: invalid {self.field}: {self.message}"


@dataclass(slots=True)
class TransportError(PaliError):
    """Raised for local transport failures such as timeouts or malformed URLs."""

    message: str

    def __str__(self) -> str:
        return f"pali: transport error: {self.message}"


@dataclass(slots=True)
class APIError(PaliError):
    """Represents a non-2xx response from the Pali API."""

    status_code: int
    code: str
    message: str
    request_id: str = ""
    body: str = ""

    def __str__(self) -> str:
        if self.request_id:
            return (
                f"pali: {self.status_code} {self.code}: {self.message} "
                f"(request_id={self.request_id})"
            )
        return f"pali: {self.status_code} {self.code}: {self.message}"


class UnauthorizedError(APIError):
    """Raised for HTTP 401 responses."""


class ForbiddenError(APIError):
    """Raised for HTTP 403 responses."""


class NotFoundError(APIError):
    """Raised for HTTP 404 responses."""


class ConflictError(APIError):
    """Raised for HTTP 409 responses."""


class RateLimitError(APIError):
    """Raised for HTTP 429 responses."""
