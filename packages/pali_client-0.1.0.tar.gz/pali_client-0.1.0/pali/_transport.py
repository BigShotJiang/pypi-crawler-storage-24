"""Private transport layer for the Pali SDK."""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
from typing import Any
from urllib.parse import urlparse

import httpx

from ._retry import (
    RetryConfig,
    compute_delay,
    should_retry_exception,
    should_retry_status,
    sleep_async,
    sleep_sync,
)
from .errors import (
    APIError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    TransportError,
    UnauthorizedError,
    ValidationError,
)

DEFAULT_TIMEOUT = 15.0

try:
    DEFAULT_USER_AGENT = f"pali-client/{version('pali-client')}"
except PackageNotFoundError:
    DEFAULT_USER_AGENT = "pali-client/0.1.0"


@dataclass(slots=True, frozen=True)
class ClientConfig:
    """Normalized configuration shared by sync and async clients."""

    base_url: str
    token: str | None
    timeout: float
    retry: RetryConfig


def resolve_config(
    base_url: str | None,
    *,
    token: str | None,
    timeout: float | None,
    max_retries: int,
) -> ClientConfig:
    """Resolve constructor arguments with environment variable fallbacks."""

    resolved_base_url = _clean_string(base_url) or _clean_string(os.getenv("PALI_BASE_URL"))
    if resolved_base_url is None:
        raise ValidationError("base_url", "base_url is required")
    parsed = urlparse(resolved_base_url)
    if not parsed.scheme or not parsed.netloc:
        raise ValidationError("base_url", "base_url must include scheme and host")

    resolved_token = _clean_string(token)
    if resolved_token is None:
        resolved_token = _clean_string(os.getenv("PALI_TOKEN"))

    resolved_timeout = timeout
    if resolved_timeout is None:
        env_timeout = _clean_string(os.getenv("PALI_TIMEOUT"))
        if env_timeout is not None:
            try:
                resolved_timeout = float(env_timeout)
            except ValueError as exc:
                raise ValidationError("timeout", "PALI_TIMEOUT must be numeric") from exc
    if resolved_timeout is None:
        resolved_timeout = DEFAULT_TIMEOUT
    if resolved_timeout <= 0:
        raise ValidationError("timeout", "timeout must be greater than 0")
    if max_retries < 1:
        raise ValidationError("max_retries", "max_retries must be at least 1")

    return ClientConfig(
        base_url=resolved_base_url.rstrip("/"),
        token=resolved_token,
        timeout=resolved_timeout,
        retry=RetryConfig(max_attempts=max_retries),
    )


class SyncTransport:
    """Private sync HTTP transport wrapper."""

    def __init__(self, config: ClientConfig, http_client: httpx.Client | None = None) -> None:
        self._config = config
        self._client = http_client or httpx.Client(base_url=config.base_url, timeout=config.timeout)
        self._owns_client = http_client is None

    def close(self) -> None:
        """Close the underlying client if this transport created it."""

        if self._owns_client:
            self._client.close()

    def set_bearer_token(self, token: str | None) -> None:
        """Update the bearer token used for subsequent requests."""

        self._config = ClientConfig(
            base_url=self._config.base_url,
            token=_clean_string(token),
            timeout=self._config.timeout,
            retry=self._config.retry,
        )

    def request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
        timeout: float | None = None,
        retryable: bool,
    ) -> Any:
        """Perform a JSON request and decode the JSON response."""

        headers = self._headers()
        attempts = self._config.retry.max_attempts if retryable else 1
        last_error: Exception | None = None

        for attempt in range(1, attempts + 1):
            response: httpx.Response | None = None
            try:
                response = self._client.request(
                    method,
                    path,
                    params=params,
                    json=json_body,
                    headers=headers,
                    timeout=timeout or self._config.timeout,
                )
            except Exception as exc:  # noqa: BLE001
                if retryable and attempt < attempts and should_retry_exception(exc):
                    delay = compute_delay(attempt, None, self._config.retry)
                    sleep_sync(delay)
                    continue
                if should_retry_exception(exc):
                    raise TransportError(str(exc)) from exc
                raise TransportError(f"request failed: {exc}") from exc

            if response.status_code >= 400:
                if retryable and attempt < attempts and should_retry_status(response.status_code):
                    delay = compute_delay(attempt, response, self._config.retry)
                    sleep_sync(delay)
                    continue
                raise parse_api_error(response)

            if response.status_code == 204:
                return None

            try:
                return response.json()
            except ValueError as exc:
                raise TransportError("invalid JSON response body") from exc

        if last_error is not None:
            raise last_error
        raise TransportError("request failed")

    def _headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/json",
            "User-Agent": DEFAULT_USER_AGENT,
        }
        if self._config.token:
            headers["Authorization"] = f"Bearer {self._config.token}"
        return headers


class AsyncTransport:
    """Private async HTTP transport wrapper."""

    def __init__(self, config: ClientConfig, http_client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = http_client or httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout,
        )
        self._owns_client = http_client is None

    async def aclose(self) -> None:
        """Close the underlying client if this transport created it."""

        if self._owns_client:
            await self._client.aclose()

    def set_bearer_token(self, token: str | None) -> None:
        """Update the bearer token used for subsequent requests."""

        self._config = ClientConfig(
            base_url=self._config.base_url,
            token=_clean_string(token),
            timeout=self._config.timeout,
            retry=self._config.retry,
        )

    async def request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
        timeout: float | None = None,
        retryable: bool,
    ) -> Any:
        """Perform a JSON request and decode the JSON response."""

        headers = self._headers()
        attempts = self._config.retry.max_attempts if retryable else 1

        for attempt in range(1, attempts + 1):
            response: httpx.Response | None = None
            try:
                response = await self._client.request(
                    method,
                    path,
                    params=params,
                    json=json_body,
                    headers=headers,
                    timeout=timeout or self._config.timeout,
                )
            except Exception as exc:  # noqa: BLE001
                if retryable and attempt < attempts and should_retry_exception(exc):
                    delay = compute_delay(attempt, None, self._config.retry)
                    await sleep_async(delay)
                    continue
                if should_retry_exception(exc):
                    raise TransportError(str(exc)) from exc
                raise TransportError(f"request failed: {exc}") from exc

            if response.status_code >= 400:
                if retryable and attempt < attempts and should_retry_status(response.status_code):
                    delay = compute_delay(attempt, response, self._config.retry)
                    await sleep_async(delay)
                    continue
                raise parse_api_error(response)

            if response.status_code == 204:
                return None

            try:
                return response.json()
            except ValueError as exc:
                raise TransportError("invalid JSON response body") from exc

        raise TransportError("request failed")

    def _headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/json",
            "User-Agent": DEFAULT_USER_AGENT,
        }
        if self._config.token:
            headers["Authorization"] = f"Bearer {self._config.token}"
        return headers


def parse_api_error(response: httpx.Response) -> APIError:
    """Parse a typed API error from a response."""

    body = response.text
    message = response.reason_phrase or "HTTP error"
    code = _derive_code(response.status_code)

    if body:
        try:
            payload = response.json()
        except ValueError:
            payload = None
        if isinstance(payload, dict):
            error_message = payload.get("error") or payload.get("message")
            if isinstance(error_message, str) and error_message.strip():
                message = error_message.strip()
            payload_code = payload.get("code")
            if isinstance(payload_code, str) and payload_code.strip():
                code = payload_code.strip()

    request_id = response.headers.get("X-Request-ID", "").strip()
    error_cls = _api_error_class(response.status_code)
    return error_cls(
        status_code=response.status_code,
        code=code,
        message=message,
        request_id=request_id,
        body=body,
    )


def parse_datetime(value: str) -> datetime:
    """Parse API timestamps into aware datetimes."""

    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _clean_string(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def _derive_code(status_code: int) -> str:
    mapping = {
        400: "bad_request",
        401: "unauthorized",
        403: "forbidden",
        404: "not_found",
        409: "conflict",
        422: "unprocessable",
        429: "rate_limited",
        500: "internal_error",
        503: "unavailable",
    }
    return mapping.get(status_code, "error")


def _api_error_class(status_code: int) -> type[APIError]:
    mapping: dict[int, type[APIError]] = {
        401: UnauthorizedError,
        403: ForbiddenError,
        404: NotFoundError,
        409: ConflictError,
        429: RateLimitError,
    }
    return mapping.get(status_code, APIError)
