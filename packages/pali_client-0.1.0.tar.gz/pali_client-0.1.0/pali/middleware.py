"""Experimental memory middleware for wrapping LLM calls.

This helper is early-stage and infra-first. It is not a complete memory
optimization system, and callers should treat behavior as evolving.
"""

from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable, Iterable, Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from typing import Any, ParamSpec, TypeVar, cast

from .client import PaliAsyncClient, PaliClient
from .types import (
    ChatMessage,
    DeleteMemoryAction,
    MemoryAction,
    MemoryResponse,
    MessageRole,
    ReplaceMemoryAction,
    StoreMemoryAction,
    StoreMemoryRequest,
)

P = ParamSpec("P")
R = TypeVar("R")
ActionPlanner = Callable[
    [Sequence[ChatMessage], Sequence[MemoryResponse], Any, str],
    Iterable[MemoryAction],
]

DEFAULT_SYSTEM_PROMPT_TEMPLATE = (
    "Relevant memories:\n"
    "{{memories}}\n\n"
    "Use these memories only when they help answer the user accurately. "
    "Prefer the latest user message if it conflicts with older memories."
)


@dataclass(slots=True, frozen=True)
class _Options:
    top_k: int
    min_score: float
    read_only: bool
    allow_destructive_actions: bool
    system_prompt_template: str
    hooks: dict[str, tuple[Callable[[str, dict[str, Any]], None], ...]]


class PaliMiddleware:
    """Wrap LLM calls with Pali search, prompt injection, and store phases.

    Experimental: this is an early autopilot helper on top of Pali infra.
    """

    def __init__(
        self,
        client: PaliClient | PaliAsyncClient,
        tenant_id: str,
        *,
        top_k: int = 5,
        min_score: float = 0.3,
        read_only: bool = False,
        allow_destructive_actions: bool = False,
        system_prompt_template: str = DEFAULT_SYSTEM_PROMPT_TEMPLATE,
        hooks: Mapping[str, Sequence[Callable[[str, dict[str, Any]], None]]] | None = None,
        extractor: (
            Callable[[Sequence[ChatMessage], Any, str], Iterable[StoreMemoryRequest]] | None
        ) = None,
        action_planner: ActionPlanner | None = None,
        response_text_getter: Callable[[Any], str] | None = None,
    ) -> None:
        """Initialize middleware for a tenant."""

        if "{{memories}}" not in system_prompt_template:
            raise ValueError("system_prompt_template must contain {{memories}}")
        if top_k <= 0:
            raise ValueError("top_k must be greater than 0")
        if min_score < 0 or min_score > 1:
            raise ValueError("min_score must be between 0 and 1")
        if not tenant_id.strip():
            raise ValueError("tenant_id is required")

        normalized_hooks: dict[str, tuple[Callable[[str, dict[str, Any]], None], ...]] = {}
        for phase, phase_hooks in (hooks or {}).items():
            normalized_hooks[phase.upper()] = tuple(phase_hooks)

        self._client = client
        self._tenant_id = tenant_id.strip()
        self._options = _Options(
            top_k=top_k,
            min_score=min_score,
            read_only=read_only,
            allow_destructive_actions=allow_destructive_actions,
            system_prompt_template=system_prompt_template,
            hooks=normalized_hooks,
        )
        self._extractor = extractor or self._default_extractor
        self._action_planner = action_planner
        self._response_text_getter = response_text_getter or _default_response_text_getter

    def wrap(
        self,
        llm_fn: Callable[P, R] | Callable[P, Awaitable[R]],
    ) -> Callable[P, R] | Callable[P, Awaitable[R]]:
        """Wrap a sync or async LLM function.

        The wrapped callable must receive `messages` as its first positional argument
        or as a `messages=` keyword argument.
        """

        if inspect.iscoroutinefunction(llm_fn):
            return cast(
                Callable[P, Awaitable[R]],
                self._wrap_async(cast(Callable[P, Awaitable[R]], llm_fn)),
            )
        return cast(Callable[P, R], self._wrap_sync(cast(Callable[P, R], llm_fn)))

    def wrap_openai(self, openai_client: Any) -> Any:
        """Return a proxy object that wraps `chat.completions.create`."""

        return _WrappedOpenAIClient(openai_client, self)

    def wrap_anthropic(self, anthropic_client: Any) -> Any:
        """Return a proxy object that wraps `messages.create`."""

        return _WrappedAnthropicClient(anthropic_client, self)

    def _wrap_sync(self, llm_fn: Callable[P, R]) -> Callable[P, R]:
        def wrapped(*args: P.args, **kwargs: P.kwargs) -> R:
            messages = _coerce_messages(_extract_messages(args, kwargs))
            memories = self._search_sync(messages)
            injected_messages = _inject_memories(
                messages,
                memories,
                self._options.system_prompt_template,
            )
            self._emit_hook("INJECT", {"memories": memories, "messages": injected_messages})
            updated_args, updated_kwargs = _replace_messages(args, kwargs, injected_messages)
            self._emit_hook("CALL", {"messages": injected_messages})
            result = llm_fn(*updated_args, **updated_kwargs)
            self._store_sync(messages, memories, result)
            return result

        return wrapped

    def _wrap_async(self, llm_fn: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        async def wrapped(*args: P.args, **kwargs: P.kwargs) -> R:
            messages = _coerce_messages(_extract_messages(args, kwargs))
            memories = await self._search_async(messages)
            injected_messages = _inject_memories(
                messages,
                memories,
                self._options.system_prompt_template,
            )
            self._emit_hook("INJECT", {"memories": memories, "messages": injected_messages})
            updated_args, updated_kwargs = _replace_messages(args, kwargs, injected_messages)
            self._emit_hook("CALL", {"messages": injected_messages})
            result = await llm_fn(*updated_args, **updated_kwargs)
            await self._store_async(messages, memories, result)
            return result

        return wrapped

    def _search_sync(self, messages: Sequence[ChatMessage]) -> tuple[MemoryResponse, ...]:
        if not isinstance(self._client, PaliClient):
            raise TypeError("sync middleware requires PaliClient")
        query = _query_from_messages(messages)
        self._emit_hook("SEARCH", {"query": query})
        try:
            return self._client.search(
                self._tenant_id,
                query,
                top_k=self._options.top_k,
                min_score=self._options.min_score,
            ).items
        except Exception as exc:  # noqa: BLE001
            self._emit_hook("SEARCH", {"query": query, "error": exc, "degraded": True})
            return ()

    async def _search_async(self, messages: Sequence[ChatMessage]) -> tuple[MemoryResponse, ...]:
        if not isinstance(self._client, PaliAsyncClient):
            raise TypeError("async middleware requires PaliAsyncClient")
        query = _query_from_messages(messages)
        self._emit_hook("SEARCH", {"query": query})
        try:
            return (
                await self._client.search(
                    self._tenant_id,
                    query,
                    top_k=self._options.top_k,
                    min_score=self._options.min_score,
                )
            ).items
        except Exception as exc:  # noqa: BLE001
            self._emit_hook("SEARCH", {"query": query, "error": exc, "degraded": True})
            return ()

    def _store_sync(
        self,
        messages: Sequence[ChatMessage],
        memories: Sequence[MemoryResponse],
        result: Any,
    ) -> None:
        if self._options.read_only:
            return
        if not isinstance(self._client, PaliClient):
            raise TypeError("sync middleware requires PaliClient")
        response_text = self._response_text_getter(result)
        actions = tuple(self._plan_actions(messages, memories, result, response_text))
        if not actions:
            return
        self._emit_hook("STORE", {"count": len(actions), "actions": actions})
        try:
            self._apply_actions_sync(actions)
        except Exception as exc:  # noqa: BLE001
            self._emit_hook("STORE", {"count": len(actions), "error": exc, "degraded": True})

    async def _store_async(
        self,
        messages: Sequence[ChatMessage],
        memories: Sequence[MemoryResponse],
        result: Any,
    ) -> None:
        if self._options.read_only:
            return
        if not isinstance(self._client, PaliAsyncClient):
            raise TypeError("async middleware requires PaliAsyncClient")
        response_text = self._response_text_getter(result)
        actions = tuple(self._plan_actions(messages, memories, result, response_text))
        if not actions:
            return
        self._emit_hook("STORE", {"count": len(actions), "actions": actions})
        try:
            await self._apply_actions_async(actions)
        except Exception as exc:  # noqa: BLE001
            self._emit_hook("STORE", {"count": len(actions), "error": exc, "degraded": True})

    def _default_extractor(
        self,
        messages: Sequence[ChatMessage],
        _result: Any,
        response_text: str,
    ) -> Iterable[StoreMemoryRequest]:
        last_user = _last_message_by_role(messages, "user")
        if last_user is not None and last_user.content.strip():
            yield StoreMemoryRequest(
                tenant_id=self._tenant_id,
                content=last_user.content,
                kind="raw_turn",
                source="pali_middleware",
                created_by="user",
            )
        if response_text.strip():
            yield StoreMemoryRequest(
                tenant_id=self._tenant_id,
                content=response_text,
                kind="raw_turn",
                source="pali_middleware",
                created_by="system",
            )

    def _emit_hook(self, phase: str, payload: dict[str, Any]) -> None:
        for hook in self._options.hooks.get(phase.upper(), ()):
            hook(phase.upper(), payload)

    def _plan_actions(
        self,
        messages: Sequence[ChatMessage],
        memories: Sequence[MemoryResponse],
        result: Any,
        response_text: str,
    ) -> tuple[MemoryAction, ...]:
        if self._action_planner is not None:
            planned = tuple(self._action_planner(messages, memories, result, response_text))
        else:
            planned = tuple(
                StoreMemoryAction(request=request)
                for request in self._extractor(messages, result, response_text)
            )

        validated: list[MemoryAction] = []
        skipped = 0
        for action in planned:
            if isinstance(action, StoreMemoryAction):
                validated.append(
                    StoreMemoryAction(request=_validate_store_request_for_action(action.request))
                )
                continue
            if not self._options.allow_destructive_actions:
                skipped += 1
                continue
            if isinstance(action, DeleteMemoryAction):
                validated.append(DeleteMemoryAction(memory_id=_require_memory_id(action.memory_id)))
                continue
            if isinstance(action, ReplaceMemoryAction):
                validated.append(
                    ReplaceMemoryAction(
                        memory_id=_require_memory_id(action.memory_id),
                        request=_validate_store_request_for_action(action.request),
                    )
                )
                continue
            raise TypeError("unsupported memory action")

        if skipped:
            self._emit_hook(
                "STORE",
                {"skipped_destructive_actions": skipped, "allow_destructive_actions": False},
            )
        return tuple(validated)

    def _apply_actions_sync(self, actions: Sequence[MemoryAction]) -> None:
        if not isinstance(self._client, PaliClient):
            raise TypeError("sync middleware requires PaliClient")
        pending_stores: list[StoreMemoryRequest] = []

        def flush_stores() -> None:
            if not pending_stores:
                return
            if len(pending_stores) == 1:
                self._client.store(pending_stores[0])
            else:
                self._client.store_batch(tuple(pending_stores))
            pending_stores.clear()

        for action in actions:
            if isinstance(action, StoreMemoryAction):
                pending_stores.append(action.request)
                continue
            flush_stores()
            if isinstance(action, DeleteMemoryAction):
                self._client.delete(self._tenant_id, action.memory_id)
                continue
            if isinstance(action, ReplaceMemoryAction):
                self._client.delete(self._tenant_id, action.memory_id)
                self._client.store(action.request)
                continue
            raise TypeError("unsupported memory action")
        flush_stores()

    async def _apply_actions_async(self, actions: Sequence[MemoryAction]) -> None:
        if not isinstance(self._client, PaliAsyncClient):
            raise TypeError("async middleware requires PaliAsyncClient")
        client: PaliAsyncClient = self._client
        pending_stores: list[StoreMemoryRequest] = []

        async def flush_stores() -> None:
            if not pending_stores:
                return
            if len(pending_stores) == 1:
                await client.store(pending_stores[0])
            else:
                await client.store_batch(tuple(pending_stores))
            pending_stores.clear()

        for action in actions:
            if isinstance(action, StoreMemoryAction):
                pending_stores.append(action.request)
                continue
            await flush_stores()
            if isinstance(action, DeleteMemoryAction):
                await client.delete(self._tenant_id, action.memory_id)
                continue
            if isinstance(action, ReplaceMemoryAction):
                await client.delete(self._tenant_id, action.memory_id)
                await client.store(action.request)
                continue
            raise TypeError("unsupported memory action")
        await flush_stores()


class _WrappedOpenAIClient:
    def __init__(self, openai_client: Any, middleware: PaliMiddleware) -> None:
        self._openai_client = openai_client
        self._middleware = middleware
        self.chat = _WrappedChatNamespace(openai_client.chat, middleware)


class _WrappedChatNamespace:
    def __init__(self, chat_namespace: Any, middleware: PaliMiddleware) -> None:
        self._chat_namespace = chat_namespace
        self.completions = _WrappedCompletionsNamespace(chat_namespace.completions, middleware)


class _WrappedCompletionsNamespace:
    def __init__(self, completions_namespace: Any, middleware: PaliMiddleware) -> None:
        self._completions_namespace = completions_namespace
        self._middleware = middleware

    def create(self, *args: Any, **kwargs: Any) -> Any:
        create_fn = self._completions_namespace.create
        wrapped = self._middleware.wrap(_openai_create_adapter(create_fn))
        return wrapped(*args, **kwargs)


def _openai_create_adapter(
    create_fn: Callable[..., Any],
) -> Callable[..., Any]:
    def call(*args: Any, **kwargs: Any) -> Any:
        return create_fn(*args, **kwargs)

    return call


class _WrappedAnthropicClient:
    def __init__(self, anthropic_client: Any, middleware: PaliMiddleware) -> None:
        self._anthropic_client = anthropic_client
        self._middleware = middleware
        self.messages = _WrappedAnthropicMessagesNamespace(anthropic_client.messages, middleware)


class _WrappedAnthropicMessagesNamespace:
    def __init__(self, messages_namespace: Any, middleware: PaliMiddleware) -> None:
        self._messages_namespace = messages_namespace
        self._middleware = middleware

    def create(self, *args: Any, **kwargs: Any) -> Any:
        create_fn = self._messages_namespace.create
        if inspect.iscoroutinefunction(create_fn):
            return self._create_async(create_fn, *args, **kwargs)
        return self._create_sync(create_fn, *args, **kwargs)

    def _create_sync(
        self,
        create_fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        messages = _coerce_anthropic_messages(_extract_anthropic_messages(args, kwargs))
        memories = self._middleware._search_sync(messages)
        system = _inject_system_prompt(
            kwargs.get("system"),
            memories,
            self._middleware._options.system_prompt_template,
        )
        self._middleware._emit_hook("INJECT", {"memories": memories, "system": system})
        updated_kwargs = dict(kwargs)
        if system is not None:
            updated_kwargs["system"] = system
        self._middleware._emit_hook("CALL", {"messages": messages, "system": system})
        result = create_fn(*args, **updated_kwargs)
        self._middleware._store_sync(messages, memories, result)
        return result

    async def _create_async(
        self,
        create_fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        messages = _coerce_anthropic_messages(_extract_anthropic_messages(args, kwargs))
        memories = await self._middleware._search_async(messages)
        system = _inject_system_prompt(
            kwargs.get("system"),
            memories,
            self._middleware._options.system_prompt_template,
        )
        self._middleware._emit_hook("INJECT", {"memories": memories, "system": system})
        updated_kwargs = dict(kwargs)
        if system is not None:
            updated_kwargs["system"] = system
        self._middleware._emit_hook("CALL", {"messages": messages, "system": system})
        result = await create_fn(*args, **updated_kwargs)
        await self._middleware._store_async(messages, memories, result)
        return result


def _extract_messages(args: tuple[Any, ...], kwargs: Mapping[str, Any]) -> Sequence[object]:
    if "messages" in kwargs:
        messages = kwargs["messages"]
        if isinstance(messages, Sequence):
            return list(messages)
        raise TypeError("messages must be a sequence")
    if not args:
        raise TypeError(
            "wrapped function must receive messages as first argument "
            "or messages keyword"
        )
    messages = args[0]
    if isinstance(messages, Sequence):
        return list(messages)
    raise TypeError("messages must be a sequence")


def _extract_anthropic_messages(
    args: tuple[Any, ...],
    kwargs: Mapping[str, Any],
) -> Sequence[object]:
    if "messages" in kwargs:
        messages = kwargs["messages"]
        if isinstance(messages, Sequence):
            return list(messages)
        raise TypeError("Anthropic messages must be a sequence")
    if not args:
        raise TypeError("Anthropic wrapped function must receive messages keyword argument")
    messages = args[0]
    if isinstance(messages, Sequence):
        return list(messages)
    raise TypeError("Anthropic messages must be a sequence")


def _replace_messages(
    args: tuple[Any, ...],
    kwargs: Mapping[str, Any],
    messages: Sequence[ChatMessage],
) -> tuple[tuple[Any, ...], dict[str, Any]]:
    raw_messages = [_message_to_wire(message) for message in messages]
    if "messages" in kwargs:
        updated_kwargs = dict(kwargs)
        updated_kwargs["messages"] = raw_messages
        return args, updated_kwargs
    if not args:
        raise TypeError("wrapped function must receive messages")
    updated_args = (raw_messages, *args[1:])
    return updated_args, dict(kwargs)


def _coerce_messages(messages: Sequence[object]) -> tuple[ChatMessage, ...]:
    coerced: list[ChatMessage] = []
    for message in messages:
        if isinstance(message, ChatMessage):
            coerced.append(message)
            continue
        if isinstance(message, Mapping):
            role = message.get("role")
            content = message.get("content")
            if not isinstance(role, str) or not isinstance(content, str):
                raise TypeError("message mappings must include string role and content")
            name = message.get("name")
            if name is not None and not isinstance(name, str):
                raise TypeError("message name must be a string when provided")
            metadata = {
                key: value
                for key, value in message.items()
                if key not in {"role", "content", "name"}
            }
            coerced.append(
                ChatMessage(
                    role=_validate_message_role(role),
                    content=content,
                    name=name,
                    metadata=metadata,
                )
            )
            continue
        raise TypeError("messages must contain ChatMessage objects or mapping-like chat messages")
    return tuple(coerced)


def _coerce_anthropic_messages(messages: Sequence[object]) -> tuple[ChatMessage, ...]:
    coerced: list[ChatMessage] = []
    for message in messages:
        if not isinstance(message, Mapping):
            raise TypeError("Anthropic messages must be mapping-like objects")
        role = message.get("role")
        content = message.get("content")
        if not isinstance(role, str):
            raise TypeError("Anthropic messages must include string role")
        text = _content_to_text(content)
        name = message.get("name")
        if name is not None and not isinstance(name, str):
            raise TypeError("message name must be a string when provided")
        metadata = {
            key: value
            for key, value in message.items()
            if key not in {"role", "content", "name"}
        }
        coerced.append(
            ChatMessage(
                role=_validate_message_role(role),
                content=text,
                name=name,
                metadata=metadata,
            )
        )
    return tuple(coerced)


def _inject_memories(
    messages: Sequence[ChatMessage],
    memories: Sequence[MemoryResponse],
    template: str,
) -> tuple[ChatMessage, ...]:
    if not memories:
        return tuple(messages)

    memory_lines = "\n".join(f"- {memory.content}" for memory in memories)
    injected_context = template.replace("{{memories}}", memory_lines)
    result = list(messages)
    for index, message in enumerate(result):
        if message.role == "system":
            result[index] = ChatMessage(
                role="system",
                content=f"{injected_context}\n\n{message.content}",
                name=message.name,
                metadata=dict(message.metadata),
            )
            return tuple(result)

    return (ChatMessage(role="system", content=injected_context), *result)


def _query_from_messages(messages: Sequence[ChatMessage]) -> str:
    last_user = _last_message_by_role(messages, "user")
    if last_user is not None and last_user.content.strip():
        return last_user.content
    for message in reversed(messages):
        if message.content.strip():
            return message.content
    return ""


def _last_message_by_role(messages: Sequence[ChatMessage], role: str) -> ChatMessage | None:
    for message in reversed(messages):
        if message.role == role:
            return message
    return None


def _default_response_text_getter(result: Any) -> str:
    if isinstance(result, str):
        return result

    choices = getattr(result, "choices", None)
    if isinstance(choices, Sequence) and choices:
        first_choice = choices[0]
        message = getattr(first_choice, "message", None)
        content = getattr(message, "content", None)
        if isinstance(content, str):
            return content
        if content is not None:
            return _content_to_text(content)

    if isinstance(result, Mapping):
        content = result.get("content")
        if isinstance(content, str):
            return content
        if content is not None:
            return _content_to_text(content)

    return str(result)


def _validate_message_role(role: str) -> MessageRole:
    if role not in {"system", "user", "assistant", "tool"}:
        raise TypeError("message role must be system, user, assistant, or tool")
    return role  # type: ignore[return-value]


def _inject_system_prompt(
    existing_system: Any,
    memories: Sequence[MemoryResponse],
    template: str,
) -> Any:
    if not memories:
        return existing_system

    memory_lines = "\n".join(f"- {memory.content}" for memory in memories)
    injected_context = template.replace("{{memories}}", memory_lines)
    if existing_system is None:
        return injected_context
    if isinstance(existing_system, str):
        return f"{injected_context}\n\n{existing_system}"
    if isinstance(existing_system, Sequence) and not isinstance(
        existing_system,
        (str, bytes, bytearray),
    ):
        return [{"type": "text", "text": injected_context}, *list(existing_system)]
    return f"{injected_context}\n\n{existing_system}"


def _content_to_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, Sequence) and not isinstance(content, (str, bytes, bytearray)):
        parts: list[str] = []
        for block in content:
            if isinstance(block, Mapping):
                text = block.get("text")
                if isinstance(text, str) and text.strip():
                    parts.append(text)
            elif isinstance(block, str) and block.strip():
                parts.append(block)
        return "\n".join(parts)
    return str(content)


def _message_to_wire(message: ChatMessage) -> MutableMapping[str, Any]:
    payload: MutableMapping[str, Any] = {"role": message.role, "content": message.content}
    if message.name is not None:
        payload["name"] = message.name
    payload.update(message.metadata)
    return payload


def _require_memory_id(memory_id: str) -> str:
    normalized = memory_id.strip()
    if not normalized:
        raise ValueError("memory_id is required for delete/replace actions")
    return normalized


def _validate_store_request_for_action(request: StoreMemoryRequest) -> StoreMemoryRequest:
    if not request.tenant_id.strip():
        raise ValueError("tenant_id is required for store actions")
    if not request.content.strip():
        raise ValueError("content is required for store actions")
    return request
