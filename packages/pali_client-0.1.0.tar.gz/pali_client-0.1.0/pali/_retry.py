"""Retry helpers shared by sync and async transports."""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Final, cast

import httpx

NETWORK_RETRYABLE_EXCEPTIONS: Final = (
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.PoolTimeout,
    httpx.ReadTimeout,
    httpx.WriteTimeout,
    httpx.RemoteProtocolError,
)


@dataclass(slots=True, frozen=True)
class RetryConfig:
    """Retry configuration for idempotent operations."""

    max_attempts: int = 3
    base_delay: float = 0.2
    max_delay: float = 5.0


def should_retry_exception(exc: Exception) -> bool:
    """Return True when a transport exception is retryable."""

    return isinstance(exc, NETWORK_RETRYABLE_EXCEPTIONS)


def should_retry_status(status_code: int) -> bool:
    """Return True when an HTTP status should be retried."""

    return status_code in {429, 503}


def compute_delay(attempt: int, response: httpx.Response | None, config: RetryConfig) -> float:
    """Return retry delay in seconds using Retry-After or exponential backoff with full jitter."""

    retry_after = _parse_retry_after(response)
    if retry_after is not None:
        return max(0.0, min(retry_after, config.max_delay))

    expo = min(config.base_delay * (2 ** max(attempt - 1, 0)), config.max_delay)
    return random.uniform(0.0, expo)


def sleep_sync(delay: float) -> None:
    """Sleep for the given delay in sync code."""

    time.sleep(delay)


async def sleep_async(delay: float) -> None:
    """Sleep for the given delay in async code."""

    await asyncio.sleep(delay)


def _parse_retry_after(response: httpx.Response | None) -> float | None:
    if response is None:
        return None

    raw_value = response.headers.get("Retry-After")
    if raw_value is None:
        return None

    stripped = raw_value.strip()
    if not stripped:
        return None

    try:
        return float(stripped)
    except ValueError:
        pass

    try:
        retry_at = cast(datetime, parsedate_to_datetime(stripped))
    except (TypeError, ValueError):
        return None

    if retry_at.tzinfo is None:
        retry_at = retry_at.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    return max(0.0, (retry_at - now).total_seconds())
