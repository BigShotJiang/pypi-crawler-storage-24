"""Public request and response types for the Pali SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

MemoryTier = Literal["auto", "working", "episodic", "semantic"]
SearchTier = Literal["working", "episodic", "semantic"]
MemoryKind = Literal["raw_turn", "observation", "summary", "event"]
CreatedBy = Literal["auto", "user", "system"]
MessageRole = Literal["system", "user", "assistant", "tool"]
MemoryActionKind = Literal["store", "delete", "replace"]


@dataclass(slots=True, frozen=True)
class HealthResponse:
    """Response returned by GET /health."""

    status: str
    time: str


@dataclass(slots=True, frozen=True)
class CreateTenantRequest:
    """Request payload for POST /v1/tenants."""

    id: str
    name: str


@dataclass(slots=True, frozen=True)
class CreateTenantResponse:
    """Response returned by POST /v1/tenants."""

    id: str
    name: str
    created_at: datetime


@dataclass(slots=True, frozen=True)
class TenantStatsResponse:
    """Response returned by GET /v1/tenants/:id/stats."""

    tenant_id: str
    memory_count: int


@dataclass(slots=True, frozen=True)
class StoreMemoryRequest:
    """Request payload for POST /v1/memory."""

    tenant_id: str
    content: str
    tags: tuple[str, ...] = ()
    tier: MemoryTier = "auto"
    kind: MemoryKind = "raw_turn"
    source: str = ""
    created_by: CreatedBy = "auto"


@dataclass(slots=True, frozen=True)
class StoreMemoryResponse:
    """Response returned by POST /v1/memory."""

    id: str
    created_at: datetime


@dataclass(slots=True, frozen=True)
class StoreMemoryBatchRequest:
    """Request payload for POST /v1/memory/batch."""

    items: tuple[StoreMemoryRequest, ...]


@dataclass(slots=True, frozen=True)
class StoreMemoryBatchResponse:
    """Response returned by POST /v1/memory/batch."""

    items: tuple[StoreMemoryResponse, ...]


@dataclass(slots=True, frozen=True)
class SearchMemoryRequest:
    """Request payload for POST /v1/memory/search."""

    tenant_id: str
    query: str
    top_k: int = 10
    min_score: float = 0.0
    tiers: tuple[SearchTier, ...] = ()
    kinds: tuple[MemoryKind, ...] = ()
    disable_touch: bool = False
    debug: bool = False


@dataclass(slots=True, frozen=True)
class MemoryResponse:
    """Single memory item returned by search."""

    id: str
    tenant_id: str
    content: str
    tier: SearchTier
    tags: tuple[str, ...]
    source: str
    created_by: str
    kind: str
    recall_count: int
    created_at: datetime
    updated_at: datetime
    last_accessed_at: datetime
    last_recalled_at: datetime


@dataclass(slots=True, frozen=True)
class SearchPlanDebug:
    """Planner diagnostics returned when search debug mode is enabled."""

    intent: str
    confidence: float
    entities: tuple[str, ...] = ()
    relations: tuple[str, ...] = ()
    time_constraints: tuple[str, ...] = ()
    required_evidence: str = ""
    fallback_path: tuple[str, ...] = ()


@dataclass(slots=True, frozen=True)
class SearchRankingDebug:
    """Ranking diagnostics for an individual candidate."""

    rank: int
    memory_id: str
    kind: str
    tier: str
    lexical_score: float
    query_overlap: float
    route_fit: float


@dataclass(slots=True, frozen=True)
class SearchMemoryDebug:
    """Debug metadata for search operations."""

    plan: SearchPlanDebug
    ranking: tuple[SearchRankingDebug, ...] = ()


@dataclass(slots=True, frozen=True)
class SearchMemoryResponse:
    """Response returned by POST /v1/memory/search."""

    items: tuple[MemoryResponse, ...]
    debug: SearchMemoryDebug | None = None


@dataclass(slots=True, frozen=True)
class ChatMessage:
    """Minimal chat message representation used by the middleware."""

    role: MessageRole
    content: str
    name: str | None = None
    metadata: dict[str, object] = field(default_factory=dict)


@dataclass(slots=True, frozen=True)
class StoreMemoryAction:
    """Store a new memory item during middleware writeback."""

    request: StoreMemoryRequest
    kind: Literal["store"] = "store"


@dataclass(slots=True, frozen=True)
class DeleteMemoryAction:
    """Delete an existing memory item during middleware writeback."""

    memory_id: str
    kind: Literal["delete"] = "delete"


@dataclass(slots=True, frozen=True)
class ReplaceMemoryAction:
    """Replace an existing memory by deleting it and storing a new version."""

    memory_id: str
    request: StoreMemoryRequest
    kind: Literal["replace"] = "replace"


MemoryAction = StoreMemoryAction | DeleteMemoryAction | ReplaceMemoryAction
