"""Public exports for the Pali Python SDK."""

from importlib.metadata import PackageNotFoundError, version

from .client import PaliAsyncClient, PaliClient
from .errors import (
    APIError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    PaliError,
    RateLimitError,
    TransportError,
    UnauthorizedError,
    ValidationError,
)
from .middleware import PaliMiddleware
from .types import (
    ChatMessage,
    CreateTenantRequest,
    CreateTenantResponse,
    DeleteMemoryAction,
    HealthResponse,
    MemoryAction,
    MemoryResponse,
    ReplaceMemoryAction,
    SearchMemoryDebug,
    SearchMemoryRequest,
    SearchMemoryResponse,
    SearchPlanDebug,
    SearchRankingDebug,
    StoreMemoryAction,
    StoreMemoryBatchRequest,
    StoreMemoryBatchResponse,
    StoreMemoryRequest,
    StoreMemoryResponse,
    TenantStatsResponse,
)

try:
    __version__ = version("pali-client")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = [
    "APIError",
    "ChatMessage",
    "ConflictError",
    "CreateTenantRequest",
    "CreateTenantResponse",
    "DeleteMemoryAction",
    "ForbiddenError",
    "HealthResponse",
    "MemoryAction",
    "MemoryResponse",
    "NotFoundError",
    "PaliAsyncClient",
    "PaliClient",
    "PaliError",
    "PaliMiddleware",
    "RateLimitError",
    "SearchMemoryDebug",
    "SearchMemoryRequest",
    "SearchMemoryResponse",
    "SearchPlanDebug",
    "SearchRankingDebug",
    "ReplaceMemoryAction",
    "StoreMemoryAction",
    "StoreMemoryBatchRequest",
    "StoreMemoryBatchResponse",
    "StoreMemoryRequest",
    "StoreMemoryResponse",
    "TenantStatsResponse",
    "TransportError",
    "UnauthorizedError",
    "ValidationError",
    "__version__",
]
