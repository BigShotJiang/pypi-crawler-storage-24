from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

import httpx

from ._retry import RetryConfig
from .errors import APIError

DEFAULT_TIMEOUT: float
DEFAULT_USER_AGENT: str

@dataclass(slots=True, frozen=True)
class ClientConfig:
    base_url: str
    token: str | None
    timeout: float
    retry: RetryConfig

def resolve_config(
    base_url: str | None,
    *,
    token: str | None,
    timeout: float | None,
    max_retries: int,
) -> ClientConfig: ...

class SyncTransport:
    def __init__(self, config: ClientConfig, http_client: httpx.Client | None = None) -> None: ...
    def close(self) -> None: ...
    def set_bearer_token(self, token: str | None) -> None: ...
    def request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
        timeout: float | None = None,
        retryable: bool,
    ) -> Any: ...

class AsyncTransport:
    def __init__(
        self,
        config: ClientConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None: ...
    async def aclose(self) -> None: ...
    def set_bearer_token(self, token: str | None) -> None: ...
    async def request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
        timeout: float | None = None,
        retryable: bool,
    ) -> Any: ...

def parse_api_error(response: httpx.Response) -> APIError: ...
def parse_datetime(value: str) -> datetime: ...
