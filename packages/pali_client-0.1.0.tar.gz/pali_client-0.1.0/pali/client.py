"""Typed sync and async clients for the Pali API."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, overload

import httpx

from ._transport import AsyncTransport, SyncTransport, parse_datetime, resolve_config
from .errors import ValidationError
from .types import (
    CreatedBy,
    CreateTenantRequest,
    CreateTenantResponse,
    HealthResponse,
    MemoryKind,
    MemoryResponse,
    MemoryTier,
    SearchMemoryDebug,
    SearchMemoryRequest,
    SearchMemoryResponse,
    SearchPlanDebug,
    SearchRankingDebug,
    SearchTier,
    StoreMemoryBatchRequest,
    StoreMemoryBatchResponse,
    StoreMemoryRequest,
    StoreMemoryResponse,
    TenantStatsResponse,
)


class PaliClient:
    """Sync typed client for the Pali memory API."""

    def __init__(
        self,
        base_url: str | None = None,
        *,
        token: str | None = None,
        timeout: float | None = None,
        max_retries: int = 3,
        http_client: httpx.Client | None = None,
    ) -> None:
        """Initialize a sync client with sane defaults and env fallbacks."""

        config = resolve_config(base_url, token=token, timeout=timeout, max_retries=max_retries)
        self._transport = SyncTransport(config, http_client=http_client)

    def close(self) -> None:
        """Close the underlying HTTP client if owned by this instance."""

        self._transport.close()

    def __enter__(self) -> PaliClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def set_bearer_token(self, token: str | None) -> None:
        """Update the bearer token used for subsequent requests."""

        self._transport.set_bearer_token(token)

    def health(self) -> HealthResponse:
        """Return API health status."""

        payload = self._transport.request_json("GET", "/health", retryable=True)
        return HealthResponse(
            status=_string_field(payload, "status"),
            time=_string_field(payload, "time"),
        )

    @overload
    def create_tenant(self, request: CreateTenantRequest, /) -> CreateTenantResponse:
        ...

    @overload
    def create_tenant(self, tenant_id: str, /, *, name: str) -> CreateTenantResponse:
        ...

    def create_tenant(
        self,
        tenant_id_or_request: str | CreateTenantRequest,
        /,
        *,
        name: str | None = None,
    ) -> CreateTenantResponse:
        """Create a tenant."""

        request = _coerce_create_tenant_request(tenant_id_or_request, name=name)
        payload = self._transport.request_json(
            "POST",
            "/v1/tenants",
            json_body=_serialize_create_tenant_request(request),
            retryable=False,
        )
        return _parse_create_tenant_response(payload)

    def tenant_stats(self, tenant_id: str) -> TenantStatsResponse:
        """Return aggregate stats for a tenant."""

        tenant = _require_non_empty(tenant_id, "tenant_id")
        payload = self._transport.request_json(
            "GET",
            f"/v1/tenants/{tenant}/stats",
            retryable=True,
        )
        return TenantStatsResponse(
            tenant_id=_string_field(payload, "tenant_id"),
            memory_count=_int_field(payload, "memory_count"),
        )

    @overload
    def store(self, request: StoreMemoryRequest, /) -> StoreMemoryResponse:
        ...

    @overload
    def store(
        self,
        tenant_id: str,
        content: str,
        /,
        *,
        tags: Sequence[str] | None = None,
        tier: str = "auto",
        kind: str = "raw_turn",
        source: str = "",
        created_by: str = "auto",
    ) -> StoreMemoryResponse:
        ...

    def store(
        self,
        tenant_id_or_request: str | StoreMemoryRequest,
        content: str | None = None,
        /,
        *,
        tags: Sequence[str] | None = None,
        tier: str = "auto",
        kind: str = "raw_turn",
        source: str = "",
        created_by: str = "auto",
    ) -> StoreMemoryResponse:
        """Store a memory."""

        request = _coerce_store_request(
            tenant_id_or_request,
            content=content,
            tags=tags,
            tier=tier,
            kind=kind,
            source=source,
            created_by=created_by,
        )
        payload = self._transport.request_json(
            "POST",
            "/v1/memory",
            json_body=_serialize_store_memory_request(request),
            retryable=False,
        )
        return _parse_store_memory_response(payload)

    def store_batch(
        self,
        items: Sequence[StoreMemoryRequest] | StoreMemoryBatchRequest,
    ) -> StoreMemoryBatchResponse:
        """Store multiple memories in request order."""

        request = _coerce_store_batch_request(items)
        payload = self._transport.request_json(
            "POST",
            "/v1/memory/batch",
            json_body={
                "items": [_serialize_store_memory_request(item) for item in request.items],
            },
            retryable=False,
        )
        return _parse_store_batch_response(payload)

    @overload
    def search(self, request: SearchMemoryRequest, /) -> SearchMemoryResponse:
        ...

    @overload
    def search(
        self,
        tenant_id: str,
        query: str,
        /,
        *,
        top_k: int = 10,
        min_score: float = 0.0,
        tiers: Sequence[str] | None = None,
        kinds: Sequence[str] | None = None,
        disable_touch: bool = False,
        debug: bool = False,
    ) -> SearchMemoryResponse:
        ...

    def search(
        self,
        tenant_id_or_request: str | SearchMemoryRequest,
        query: str | None = None,
        /,
        *,
        top_k: int = 10,
        min_score: float = 0.0,
        tiers: Sequence[str] | None = None,
        kinds: Sequence[str] | None = None,
        disable_touch: bool = False,
        debug: bool = False,
    ) -> SearchMemoryResponse:
        """Search memories for a tenant."""

        request = _coerce_search_request(
            tenant_id_or_request,
            query=query,
            top_k=top_k,
            min_score=min_score,
            tiers=tiers,
            kinds=kinds,
            disable_touch=disable_touch,
            debug=debug,
        )
        payload = self._transport.request_json(
            "POST",
            "/v1/memory/search",
            json_body=_serialize_search_request(request),
            retryable=True,
        )
        return _parse_search_response(payload)

    def delete(self, tenant_id: str, memory_id: str) -> None:
        """Delete a memory for a tenant."""

        tenant = _require_non_empty(tenant_id, "tenant_id")
        memory = _require_non_empty(memory_id, "memory_id")
        self._transport.request_json(
            "DELETE",
            f"/v1/memory/{memory}",
            params={"tenant_id": tenant},
            retryable=True,
        )


class PaliAsyncClient:
    """Async typed client for the Pali memory API."""

    def __init__(
        self,
        base_url: str | None = None,
        *,
        token: str | None = None,
        timeout: float | None = None,
        max_retries: int = 3,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        """Initialize an async client with sane defaults and env fallbacks."""

        config = resolve_config(base_url, token=token, timeout=timeout, max_retries=max_retries)
        self._transport = AsyncTransport(config, http_client=http_client)

    async def aclose(self) -> None:
        """Close the underlying HTTP client if owned by this instance."""

        await self._transport.aclose()

    async def __aenter__(self) -> PaliAsyncClient:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    def set_bearer_token(self, token: str | None) -> None:
        """Update the bearer token used for subsequent requests."""

        self._transport.set_bearer_token(token)

    async def health(self) -> HealthResponse:
        """Return API health status."""

        payload = await self._transport.request_json("GET", "/health", retryable=True)
        return HealthResponse(
            status=_string_field(payload, "status"),
            time=_string_field(payload, "time"),
        )

    async def create_tenant(
        self,
        tenant_id_or_request: str | CreateTenantRequest,
        /,
        *,
        name: str | None = None,
    ) -> CreateTenantResponse:
        """Create a tenant."""

        request = _coerce_create_tenant_request(tenant_id_or_request, name=name)
        payload = await self._transport.request_json(
            "POST",
            "/v1/tenants",
            json_body=_serialize_create_tenant_request(request),
            retryable=False,
        )
        return _parse_create_tenant_response(payload)

    async def tenant_stats(self, tenant_id: str) -> TenantStatsResponse:
        """Return aggregate stats for a tenant."""

        tenant = _require_non_empty(tenant_id, "tenant_id")
        payload = await self._transport.request_json(
            "GET",
            f"/v1/tenants/{tenant}/stats",
            retryable=True,
        )
        return TenantStatsResponse(
            tenant_id=_string_field(payload, "tenant_id"),
            memory_count=_int_field(payload, "memory_count"),
        )

    async def store(
        self,
        tenant_id_or_request: str | StoreMemoryRequest,
        content: str | None = None,
        /,
        *,
        tags: Sequence[str] | None = None,
        tier: str = "auto",
        kind: str = "raw_turn",
        source: str = "",
        created_by: str = "auto",
    ) -> StoreMemoryResponse:
        """Store a memory."""

        request = _coerce_store_request(
            tenant_id_or_request,
            content=content,
            tags=tags,
            tier=tier,
            kind=kind,
            source=source,
            created_by=created_by,
        )
        payload = await self._transport.request_json(
            "POST",
            "/v1/memory",
            json_body=_serialize_store_memory_request(request),
            retryable=False,
        )
        return _parse_store_memory_response(payload)

    async def store_batch(
        self,
        items: Sequence[StoreMemoryRequest] | StoreMemoryBatchRequest,
    ) -> StoreMemoryBatchResponse:
        """Store multiple memories in request order."""

        request = _coerce_store_batch_request(items)
        payload = await self._transport.request_json(
            "POST",
            "/v1/memory/batch",
            json_body={
                "items": [_serialize_store_memory_request(item) for item in request.items],
            },
            retryable=False,
        )
        return _parse_store_batch_response(payload)

    async def search(
        self,
        tenant_id_or_request: str | SearchMemoryRequest,
        query: str | None = None,
        /,
        *,
        top_k: int = 10,
        min_score: float = 0.0,
        tiers: Sequence[str] | None = None,
        kinds: Sequence[str] | None = None,
        disable_touch: bool = False,
        debug: bool = False,
    ) -> SearchMemoryResponse:
        """Search memories for a tenant."""

        request = _coerce_search_request(
            tenant_id_or_request,
            query=query,
            top_k=top_k,
            min_score=min_score,
            tiers=tiers,
            kinds=kinds,
            disable_touch=disable_touch,
            debug=debug,
        )
        payload = await self._transport.request_json(
            "POST",
            "/v1/memory/search",
            json_body=_serialize_search_request(request),
            retryable=True,
        )
        return _parse_search_response(payload)

    async def delete(self, tenant_id: str, memory_id: str) -> None:
        """Delete a memory for a tenant."""

        tenant = _require_non_empty(tenant_id, "tenant_id")
        memory = _require_non_empty(memory_id, "memory_id")
        await self._transport.request_json(
            "DELETE",
            f"/v1/memory/{memory}",
            params={"tenant_id": tenant},
            retryable=True,
        )


def _coerce_create_tenant_request(
    tenant_id_or_request: str | CreateTenantRequest,
    *,
    name: str | None,
) -> CreateTenantRequest:
    if isinstance(tenant_id_or_request, CreateTenantRequest):
        return CreateTenantRequest(
            id=_require_non_empty(tenant_id_or_request.id, "id"),
            name=_require_non_empty(tenant_id_or_request.name, "name"),
        )
    return CreateTenantRequest(
        id=_require_non_empty(tenant_id_or_request, "id"),
        name=_require_non_empty(name, "name"),
    )


def _coerce_store_request(
    tenant_id_or_request: str | StoreMemoryRequest,
    *,
    content: str | None,
    tags: Sequence[str] | None,
    tier: str,
    kind: str,
    source: str,
    created_by: str,
) -> StoreMemoryRequest:
    if isinstance(tenant_id_or_request, StoreMemoryRequest):
        request = tenant_id_or_request
    else:
        request = StoreMemoryRequest(
            tenant_id=tenant_id_or_request,
            content=content or "",
            tags=tuple(tags or ()),
            tier=_validate_tier(tier),
            kind=_validate_kind(kind),
            source=source,
            created_by=_validate_created_by(created_by),
        )
    return StoreMemoryRequest(
        tenant_id=_require_non_empty(request.tenant_id, "tenant_id"),
        content=_require_non_empty(request.content, "content"),
        tags=tuple(_validate_string_list(request.tags, "tags")),
        tier=_validate_tier(request.tier),
        kind=_validate_kind(request.kind),
        source=request.source.strip(),
        created_by=_validate_created_by(request.created_by),
    )


def _coerce_store_batch_request(
    items: Sequence[StoreMemoryRequest] | StoreMemoryBatchRequest,
) -> StoreMemoryBatchRequest:
    if isinstance(items, StoreMemoryBatchRequest):
        request = items
    else:
        request = StoreMemoryBatchRequest(items=tuple(items))
    if not request.items:
        raise ValidationError("items", "items must not be empty")
    normalized = tuple(
        _coerce_store_request(
            item,
            content=None,
            tags=None,
            tier="auto",
            kind="raw_turn",
            source="",
            created_by="auto",
        )
        for item in request.items
    )
    return StoreMemoryBatchRequest(items=normalized)


def _coerce_search_request(
    tenant_id_or_request: str | SearchMemoryRequest,
    *,
    query: str | None,
    top_k: int,
    min_score: float,
    tiers: Sequence[str] | None,
    kinds: Sequence[str] | None,
    disable_touch: bool,
    debug: bool,
) -> SearchMemoryRequest:
    if isinstance(tenant_id_or_request, SearchMemoryRequest):
        request = tenant_id_or_request
    else:
        request = SearchMemoryRequest(
            tenant_id=tenant_id_or_request,
            query=query or "",
            top_k=top_k,
            min_score=min_score,
            tiers=tuple(_validate_search_tier(value) for value in (tiers or ())),
            kinds=tuple(_validate_kind(value) for value in (kinds or ())),
            disable_touch=disable_touch,
            debug=debug,
        )

    if request.min_score < 0 or request.min_score > 1:
        raise ValidationError("min_score", "min_score must be between 0 and 1")

    return SearchMemoryRequest(
        tenant_id=_require_non_empty(request.tenant_id, "tenant_id"),
        query=_require_non_empty(request.query, "query"),
        top_k=request.top_k if request.top_k > 0 else 10,
        min_score=request.min_score,
        tiers=tuple(_validate_search_tier(value) for value in request.tiers),
        kinds=tuple(_validate_kind(value) for value in request.kinds),
        disable_touch=bool(request.disable_touch),
        debug=bool(request.debug),
    )


def _serialize_create_tenant_request(request: CreateTenantRequest) -> dict[str, Any]:
    return {"id": request.id, "name": request.name}


def _serialize_store_memory_request(request: StoreMemoryRequest) -> dict[str, Any]:
    return {
        "tenant_id": request.tenant_id,
        "content": request.content,
        "tags": list(request.tags),
        "tier": request.tier,
        "kind": request.kind,
        "source": request.source,
        "created_by": request.created_by,
    }


def _serialize_search_request(request: SearchMemoryRequest) -> dict[str, Any]:
    return {
        "tenant_id": request.tenant_id,
        "query": request.query,
        "top_k": request.top_k,
        "min_score": request.min_score,
        "tiers": list(request.tiers),
        "kinds": list(request.kinds),
        "disable_touch": request.disable_touch,
        "debug": request.debug,
    }


def _parse_create_tenant_response(payload: Any) -> CreateTenantResponse:
    return CreateTenantResponse(
        id=_string_field(payload, "id"),
        name=_string_field(payload, "name"),
        created_at=parse_datetime(_string_field(payload, "created_at")),
    )


def _parse_store_memory_response(payload: Any) -> StoreMemoryResponse:
    return StoreMemoryResponse(
        id=_string_field(payload, "id"),
        created_at=parse_datetime(_string_field(payload, "created_at")),
    )


def _parse_store_batch_response(payload: Any) -> StoreMemoryBatchResponse:
    raw_items = _list_field(payload, "items")
    return StoreMemoryBatchResponse(
        items=tuple(_parse_store_memory_response(item) for item in raw_items)
    )


def _parse_search_response(payload: Any) -> SearchMemoryResponse:
    raw_items = _list_field(payload, "items")
    debug_payload = None
    if isinstance(payload, dict):
        debug_payload = payload.get("debug")

    return SearchMemoryResponse(
        items=tuple(_parse_memory_response(item) for item in raw_items),
        debug=_parse_search_debug(debug_payload),
    )


def _parse_memory_response(payload: Any) -> MemoryResponse:
    return MemoryResponse(
        id=_string_field(payload, "id"),
        tenant_id=_string_field(payload, "tenant_id"),
        content=_string_field(payload, "content"),
        tier=_validate_search_tier(_string_field(payload, "tier")),
        tags=tuple(_validate_string_list(_list_field(payload, "tags"), "tags")),
        source=_string_field(payload, "source", default=""),
        created_by=_string_field(payload, "created_by", default=""),
        kind=_string_field(payload, "kind", default=""),
        recall_count=_int_field(payload, "recall_count"),
        created_at=parse_datetime(_string_field(payload, "created_at")),
        updated_at=parse_datetime(_string_field(payload, "updated_at")),
        last_accessed_at=parse_datetime(_string_field(payload, "last_accessed_at")),
        last_recalled_at=parse_datetime(_string_field(payload, "last_recalled_at")),
    )


def _parse_search_debug(payload: Any) -> SearchMemoryDebug | None:
    if payload is None:
        return None
    if not isinstance(payload, dict):
        raise ValidationError("debug", "debug payload must be an object")
    plan_payload = payload.get("plan")
    if not isinstance(plan_payload, dict):
        raise ValidationError("debug.plan", "debug plan must be an object")

    ranking_payload = payload.get("ranking", [])
    if not isinstance(ranking_payload, list):
        raise ValidationError("debug.ranking", "debug ranking must be an array")

    return SearchMemoryDebug(
        plan=SearchPlanDebug(
            intent=_string_field(plan_payload, "intent"),
            confidence=_float_field(plan_payload, "confidence"),
            entities=tuple(_validate_string_list(plan_payload.get("entities", []), "entities")),
            relations=tuple(_validate_string_list(plan_payload.get("relations", []), "relations")),
            time_constraints=tuple(
                _validate_string_list(plan_payload.get("time_constraints", []), "time_constraints")
            ),
            required_evidence=_string_field(plan_payload, "required_evidence", default=""),
            fallback_path=tuple(
                _validate_string_list(plan_payload.get("fallback_path", []), "fallback_path")
            ),
        ),
        ranking=tuple(
            SearchRankingDebug(
                rank=_int_field(item, "rank"),
                memory_id=_string_field(item, "memory_id"),
                kind=_string_field(item, "kind"),
                tier=_string_field(item, "tier"),
                lexical_score=_float_field(item, "lexical_score"),
                query_overlap=_float_field(item, "query_overlap"),
                route_fit=_float_field(item, "route_fit"),
            )
            for item in ranking_payload
        ),
    )


def _require_non_empty(value: str | None, field: str) -> str:
    if value is None or not value.strip():
        raise ValidationError(field, f"{field} is required")
    return value.strip()


def _validate_string_list(values: Sequence[Any], field: str) -> list[str]:
    normalized: list[str] = []
    for value in values:
        if not isinstance(value, str) or not value.strip():
            raise ValidationError(field, f"{field} entries must be non-empty strings")
        normalized.append(value.strip())
    return normalized


def _validate_tier(value: str) -> MemoryTier:
    normalized = value.strip().lower()
    if normalized not in {"auto", "working", "episodic", "semantic"}:
        raise ValidationError("tier", "tier must be auto, working, episodic, or semantic")
    return normalized  # type: ignore[return-value]


def _validate_search_tier(value: str) -> SearchTier:
    normalized = value.strip().lower()
    if normalized not in {"working", "episodic", "semantic"}:
        raise ValidationError("tiers", "tiers entries must be working, episodic, or semantic")
    return normalized  # type: ignore[return-value]


def _validate_kind(value: str) -> MemoryKind:
    normalized = value.strip().lower()
    if normalized not in {"raw_turn", "observation", "summary", "event"}:
        raise ValidationError("kind", "kind must be raw_turn, observation, summary, or event")
    return normalized  # type: ignore[return-value]


def _validate_created_by(value: str) -> CreatedBy:
    normalized = value.strip().lower()
    if normalized not in {"auto", "user", "system"}:
        raise ValidationError("created_by", "created_by must be auto, user, or system")
    return normalized  # type: ignore[return-value]


def _string_field(payload: Any, key: str, *, default: str | None = None) -> str:
    if not isinstance(payload, dict):
        raise ValidationError(key, f"{key} payload must be an object")
    value = payload.get(key, default)
    if not isinstance(value, str):
        raise ValidationError(key, f"{key} must be a string")
    return value


def _int_field(payload: Any, key: str) -> int:
    if not isinstance(payload, dict):
        raise ValidationError(key, f"{key} payload must be an object")
    value = payload.get(key)
    if not isinstance(value, int):
        raise ValidationError(key, f"{key} must be an integer")
    return value


def _float_field(payload: Any, key: str) -> float:
    if not isinstance(payload, dict):
        raise ValidationError(key, f"{key} payload must be an object")
    value = payload.get(key)
    if not isinstance(value, (int, float)):
        raise ValidationError(key, f"{key} must be numeric")
    return float(value)


def _list_field(payload: Any, key: str) -> list[Any]:
    if not isinstance(payload, dict):
        raise ValidationError(key, f"{key} payload must be an object")
    value = payload.get(key)
    if not isinstance(value, list):
        raise ValidationError(key, f"{key} must be an array")
    return value
