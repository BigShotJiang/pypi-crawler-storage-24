# Contributing

## Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
ruff check .
mypy .
```

## Standards

- Keep the public API typed and documented.
- Preserve sync and async parity for network operations.
- Add tests for validation, transport failures, retries, and API error mapping.
- Maintain compatibility with the API contract in `/Users/vein/Documents/pali/docs/sdk-architecture.md`.
