# Changelog

## 0.1.0 - 2026-03-07

- Added the initial standalone Python SDK in `/Users/vein/Documents/pali-python`.
- Shipped typed sync and async clients for health, tenant creation, tenant stats, memory store, batch store, search, and delete.
- Added typed API errors, validation errors, retry logic, and environment variable fallbacks.
- Added `PaliMiddleware` with graceful degradation and OpenAI-compatible wrapping.
- Added Anthropic-compatible middleware wrapping, examples, README coverage for hooks and environment variables, and an opt-in live integration harness.
- Added strict tests for retry logic, transport behavior, and middleware adapters.
