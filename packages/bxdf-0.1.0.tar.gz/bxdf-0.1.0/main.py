def main():
    print("Hello from bxdf!")


if __name__ == "__main__":
    main()
