# PyLocket CLI

Protect and distribute Python applications from the command line.

## Installation

```bash
pip install pylocket
```

Or download platform-specific binaries from your [Developer Portal](https://portal.pylocket.com/cli).

## Quick Start

```bash
# Authenticate with your PyLocket account
pylocket login

# List your apps
pylocket apps list

# Protect a PyInstaller executable
pylocket protect --app <APP_ID> --artifact dist/myapp.exe

# Check build status
pylocket status --build <BUILD_ID>

# Download the protected artifact
pylocket fetch --build <BUILD_ID> --out ./protected/
```

## Commands

| Command | Description |
|---------|-------------|
| `pylocket login` | Authenticate with your PyLocket account |
| `pylocket apps list` | List all your applications |
| `pylocket apps create` | Create a new application |
| `pylocket protect` | Upload and protect an artifact |
| `pylocket status` | Check build protection status |
| `pylocket fetch` | Download a protected artifact |

## Documentation

Full documentation: [docs.pylocket.com](https://docs.pylocket.com)

## Support

- Documentation: https://docs.pylocket.com
- Developer Portal: https://portal.pylocket.com
- Email: support@pylocket.com
