"""Polling update mechanism module."""
