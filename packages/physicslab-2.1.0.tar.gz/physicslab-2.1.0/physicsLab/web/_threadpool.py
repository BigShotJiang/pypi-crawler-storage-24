# -*- coding: utf-8 -*-
"""在 Python3.14之前, Thread.join 在 Windows 上会阻塞异常的传播, 详见:
    https://www.bilibili.com/video/BV1au411q7LN/?spm_id_from=333.999.0.0

因此, 我无法直接使用ThreadPoolExecutor, 我就自己写了一个线程池
"""

import queue
import platform
from threading import Thread, Condition
from enum import Enum, unique
from physicsLab import errors
from physicsLab._typing import List, Callable, Self, Any, Optional


class CanceledError(Exception):
    """Task have been canceled"""

    def __repr__(self) -> str:
        return "Task have been canceled"


class _EndOfQueue:
    def __new__(cls):
        return _EndOfQueue


@unique
class _Status(Enum):
    """task's status"""

    wait = 0
    running = 1
    done = 2
    cancelled = 3


class _StatusEvent:
    if platform.system() == "Windows":  # and sys.version_info < (3, 14):

        def __init__(self) -> None:
            self._status: _Status = _Status.wait

        def wait(self) -> None:
            while self._status != _Status.done:
                pass

        def set_as_done(self) -> None:
            self._status = _Status.done

    else:

        def __init__(self) -> None:
            self._condition = Condition()
            self._status: _Status = _Status.wait

        def wait(self) -> None:
            with self._condition:
                if self._status != _Status.done:
                    self._condition.wait()

        def set_as_done(self) -> None:
            with self._condition:
                self._status = _Status.done
                self._condition.notify_all()

    def set_as_running(self) -> None:
        self._status = _Status.running

    def set_as_cancelled(self) -> None:
        self._status = _Status.cancelled

    def get_status(self) -> _Status:
        return self._status


class _Task:
    def __init__(self, func: Callable, args: tuple, kwargs: dict) -> None:
        self.func = func
        self.args = args
        self.kwargs = kwargs
        self.res: Any = None
        self.exception: Optional[Exception] = None
        self.status_event: _StatusEvent = _StatusEvent()

    def has_result(self) -> bool:
        return self.status_event.get_status() == _Status.done

    def result(self):
        if self.status_event.get_status() == _Status.cancelled:
            raise CanceledError
        self.status_event.wait()

        if self.exception is not None:
            raise self.exception
        else:
            return self.res


class ThreadPool:
    def __init__(self, *, max_workers: int) -> None:
        """@param max_workers: 最大线程数"""
        if not isinstance(max_workers, int):
            raise TypeError(
                f"Parameter `max_workers` must be of type `int`, but got value `{max_workers}` of type `{type(max_workers).__name__}`"
            )
        if max_workers <= 0:
            raise ValueError

        self.max_workers = max_workers
        self.task_queue = queue.SimpleQueue()
        self.threads: List[Thread] = []

    def _office(self) -> None:
        """workers work here"""
        while True:
            try:
                _task = self.task_queue.get_nowait()
            except queue.Empty:
                continue
            if _task is _EndOfQueue:
                self.task_queue.put_nowait(_EndOfQueue)
                return
            assert isinstance(_task, _Task)
            _task.status_event.set_as_running()
            try:
                _task.res = _task.func(*_task.args, **_task.kwargs)
            except Exception as e:
                _task.exception = e
            finally:
                _task.status_event.set_as_done()

    def submit(self, func, *args, **kwargs) -> _Task:
        """submit a task
        @param func: function to be submitted
        """
        if not callable(func):
            raise TypeError(
                f"Parameter func must be of `callable`, but got value {func} of type `{type(func)}`"
            )

        task = _Task(func, args, kwargs)
        self.task_queue.put_nowait(task)
        if len(self.threads) < self.max_workers:
            worker = Thread(target=self._office, daemon=True)
            self.threads.append(worker)
            worker.start()

        return task

    def submit_end(self) -> None:
        """users should call this method after all tasks are submitted"""
        self.task_queue.put_nowait(_EndOfQueue)

    def cancel_all_pending_tasks(self) -> None:
        """cancel all pending tasks"""
        while True:
            try:
                task = self.task_queue.get_nowait()
            except queue.Empty:
                break

            if task.status == _Status.wait:
                task.status = _Status.cancelled
            else:
                errors.unreachable()

        self.submit_end()

    def wait(self) -> None:
        """blocking until all tasks are done"""
        for thread in self.threads:
            if platform.system() == "Windows":  # and sys.version_info < (3, 14):
                while thread.is_alive():
                    thread.join(timeout=2)
            else:
                thread.join()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is None:
            self.wait()
