# antarraksha-openai-agents

Antarraksha AI Agent Enforcement SDK for Openai Agents.

## Installation

```bash
pip install antarraksha-openai-agents
```

## Quick Start

```python
from antarraksha_openai_agents import AntarakshaClient

client = AntarakshaClient(
    base_url="https://antarraksha.ai",
    agent_id="my-agent",
    passport_id="ANTK-PASS-xxx",
)
client.register()
```
