"""OpenAI Agents SDK guardrails for Antarraksha enforcement."""

from typing import Any, Dict, Optional

from .client import AntarakshaClient


class AntarakshaInputGuardrail:
    """Antarraksha enforcement guardrail for OpenAI Agents SDK input.

    Usage:
        from antarraksha_openai_agents import AntarakshaInputGuardrail

        guardrail = AntarakshaInputGuardrail(
            base_url="https://antarraksha.ai",
            agent_id="my-openai-agent",
            passport_id="ANTK-PASS-xxx",
        )

        # Use with OpenAI Agents SDK
        agent = Agent(
            name="my-agent",
            input_guardrails=[guardrail],
        )
    """

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        fail_closed: bool = True,
    ):
        self.client = AntarakshaClient(
            base_url=base_url,
            agent_id=agent_id,
            passport_id=passport_id,
            sdk_key=sdk_key,
            framework="openai-agents",
            fail_closed=fail_closed,
        )
        if not sdk_key and agent_id and passport_id:
            try:
                self.client.register(capabilities=["openai_agents"])
            except Exception:
                pass

    async def __call__(self, context: Any, agent: Any) -> Any:
        input_text = str(getattr(context, "input", ""))
        result = self.client.intercept(
            call_type="input_guardrail",
            call_name="openai_agent_input",
            parameters={"input_length": len(input_text), "agent_name": getattr(agent, "name", "unknown")},
        )
        if result.get("decision") == "DENY":
            raise PermissionError(
                f"Antarraksha denied agent input: {result.get('reason', 'Policy violation')}"
            )
        return None


class AntarakshaOutputGuardrail:
    """Antarraksha enforcement guardrail for OpenAI Agents SDK output."""

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        fail_closed: bool = True,
    ):
        self.client = AntarakshaClient(
            base_url=base_url,
            agent_id=agent_id,
            passport_id=passport_id,
            sdk_key=sdk_key,
            framework="openai-agents",
            fail_closed=fail_closed,
        )
        if not sdk_key and agent_id and passport_id:
            try:
                self.client.register(capabilities=["openai_agents"])
            except Exception:
                pass

    async def __call__(self, context: Any, agent: Any) -> Any:
        output_text = str(getattr(context, "output", ""))
        result = self.client.intercept(
            call_type="output_guardrail",
            call_name="openai_agent_output",
            parameters={"output_length": len(output_text), "agent_name": getattr(agent, "name", "unknown")},
        )
        if result.get("decision") == "DENY":
            raise PermissionError(
                f"Antarraksha denied agent output: {result.get('reason', 'Policy violation')}"
            )
        return None
