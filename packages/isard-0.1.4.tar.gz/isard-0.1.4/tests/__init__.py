"""Unit tests for isard-py."""
