# Zoro CLI

Initial command-line client for Zoro.

Install:

```bash
pip install -U zoro-cli
```

Default API base URL:

- `https://api.zoro.algohub.cc/api/v1`

First login:

```bash
zoro login --token <your-token>
```

Release model:

- Public distribution is via PyPI.
- The source repository can remain private.
- Binary release assets and `install.sh` are optional and are not the primary public install path.

Interactive mode:

- `zoro` launches the terminal UI
- `zoro ui` explicitly launches the terminal UI
- plain text sends chat messages through the existing Zoro chat session
- slash commands control sessions, plans, approvals, and log views

TUI slash commands:

- `/help`
- `/new`
- `/sessions`
- `/use <session_id>`
- `/projects`
- `/servers`
- `/envs <project_id>`
- `/plan <project_id> <env_id> <branch> [method]`
- `/show <deployment_id>`
- `/approve <deployment_id>`
- `/cancel <deployment_id>`
- `/logs <deployment_id>`

Current commands:

- `zoro login`
- `zoro ui`
- `zoro logout`
- `zoro whoami`
- `zoro projects list`
- `zoro servers list`
- `zoro envs list --project-id <id>`
- `zoro deploy plan`
- `zoro deploy show`
- `zoro deploy approve`
- `zoro deploy cancel`
- `zoro deploy logs`
