from __future__ import annotations

import asyncio
import json
import shlex
from pathlib import Path

import websockets
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.widgets import Input, Label, ListItem, ListView, RichLog, Static

from zoro_cli.api import APIError, ZoroAPI
from zoro_cli.config import load_config

# ── Brand palette ──────────────────────────────────────────────────────────────
# Primary accent  : #e8754a  (Zoro orange)
# Dim accent      : #8f4a2e  (darker orange, borders / inactive)
# Background      : #0a0a0c
# Panel bg        : #111115
# Text            : #d4c9be  (warm off-white)
# Muted           : #7a7480  (comments, hints)
# User label      : #c9b99a  (parchment)
# Success         : #5a9a6f
# Warning         : #c9a84c
# Error           : #c05050
# Info            : #5a85b0
# Tool chip       : #7060a0  (purple)
# ─────────────────────────────────────────────────────────────────────────────


class ZoroTerminalApp(App[None]):
    CSS = """
    Screen {
        background: #0a0a0c;
        color: #d4c9be;
    }

    /* ── Header ── */
    #header {
        height: 2;
        background: #0a0a0c;
        border-bottom: tall #252528;
        padding: 0 2;
        layout: horizontal;
    }
    #header-brand {
        width: auto;
        content-align: left middle;
        color: #e8754a;
        text-style: bold;
    }
    #header-meta {
        width: 1fr;
        content-align: right middle;
        color: #7a7480;
    }

    /* ── Body ── */
    #body {
        height: 1fr;
        padding: 1 1 0 1;
    }

    /* ── Panels ── */
    .panel {
        background: #111115;
        border: round #252528;
    }
    .panel:focus-within {
        border: round #e8754a;
    }
    .panel-title {
        color: #e8754a;
        text-style: bold;
        padding: 0 1 0 1;
        height: 2;
        content-align: left middle;
        border-bottom: solid #252528;
    }

    /* ── Left: sessions ── */
    #left-panel {
        width: 22;
        margin-right: 1;
    }
    #sessions {
        height: 1fr;
        background: transparent;
        border: none;
        padding: 0 1;
    }
    #session-hint {
        color: #7a7480;
        padding: 0 1 1 1;
        height: 3;
    }
    ListItem {
        background: transparent;
        padding: 0;
    }
    ListItem:hover {
        background: #1a1a1f;
    }
    ListItem.-highlight {
        background: #1e1a14;
    }

    /* ── Center: chat ── */
    #center-panel {
        width: 1fr;
        margin-right: 1;
    }
    #transcript-scroll {
        height: 1fr;
        padding: 0 1;
    }
    #transcript {
        height: 1fr;
        padding: 0;
    }
    #chat-input-row {
        height: 3;
        border-top: solid #252528;
        padding: 0 1;
        align: left middle;
    }
    #input-prefix {
        width: 3;
        content-align: left middle;
        color: #e8754a;
        text-style: bold;
    }
    #input {
        width: 1fr;
        background: transparent;
        border: none;
        color: #d4c9be;
    }
    #input:focus {
        border: none;
    }

    /* ── Right: plan + logs ── */
    #right-panel {
        width: 34;
    }
    #plan-scroll {
        height: 12;
        border-bottom: solid #252528;
        padding: 0 1 1 1;
    }
    #plan {
        color: #d4c9be;
        padding: 0;
    }
    #log-title {
        color: #e8754a;
        text-style: bold;
        padding: 0 1 0 1;
        height: 2;
        content-align: left middle;
        border-bottom: solid #252528;
    }
    #deploy-log {
        height: 1fr;
        min-height: 6;
        padding: 0 1;
    }

    /* ── Footer: shortcuts ── */
    #footer {
        height: 2;
        background: #0a0a0c;
        border-top: tall #252528;
        padding: 0 2;
        align: left middle;
    }
    .shortcut {
        color: #7a7480;
        margin-right: 2;
    }
    .shortcut-key {
        color: #d4c9be;
        text-style: bold;
    }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=False),
        Binding("ctrl+l", "clear_transcript", "Clear", show=False),
        Binding("ctrl+n", "new_session", "New session", show=False),
        Binding("ctrl+r", "refresh_data", "Refresh", show=False),
        Binding("ctrl+i", "focus_input", "Input", show=False),
        Binding("ctrl+s", "focus_sessions", "Sessions", show=False),
    ]

    def __init__(self, api_url: str | None = None) -> None:
        super().__init__()
        self._api_url_override = api_url
        self._sessions: list[dict] = []
        self._current_session_id: str | None = None
        self._current_deployment_id: str | None = None
        # Transcript entries: {"role": "user"|"assistant"|"system"|"tool", "content": str}
        self._transcript: list[dict] = []
        self._assistant_buffer: str = ""
        self._streaming: bool = False
        self._current_plan_text: str = ""
        self._chat_task: asyncio.Task | None = None
        self._deployment_task: asyncio.Task | None = None
        # tracks current breakpoint to detect transitions: "wide" | "medium" | "narrow"
        self._layout_mode: str = ""

    # ── Layout ────────────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        with Horizontal(id="header"):
            yield Static("  zoro", id="header-brand")
            yield Static("", id="header-meta")
        with Container(id="body"):
            with Vertical(id="left-panel", classes="panel"):
                yield Static("Sessions", classes="panel-title")
                yield ListView(id="sessions")
                yield Static("", id="session-hint")
            with Vertical(id="center-panel", classes="panel"):
                yield Static("Chat", classes="panel-title")
                with VerticalScroll(id="transcript-scroll"):
                    yield RichLog(id="transcript", wrap=True, markup=True, highlight=False, auto_scroll=True)
                with Horizontal(id="chat-input-row"):
                    yield Static(">", id="input-prefix")
                    yield Input(placeholder="message or /help", id="input")
            with Vertical(id="right-panel", classes="panel"):
                yield Static("Plan", classes="panel-title")
                with VerticalScroll(id="plan-scroll"):
                    yield RichLog(id="plan", wrap=True, markup=True, highlight=False, auto_scroll=False)
                yield Static("Logs", id="log-title")
                yield RichLog(id="deploy-log", wrap=True, markup=False, highlight=False, auto_scroll=True)
        with Horizontal(id="footer"):
            yield Static(
                "[bold #d4c9be]^N[/] new  "
                "[bold #d4c9be]^R[/] refresh  "
                "[bold #d4c9be]^L[/] clear  "
                "[bold #d4c9be]^I[/] input  "
                "[bold #d4c9be]^S[/] sessions  "
                "[bold #d4c9be]^C[/] quit",
                id="footer-shortcuts",
                markup=True,
            )

    async def on_mount(self) -> None:
        self.query_one("#body", Container).styles.layout = "horizontal"
        self._apply_layout(self.size.width)
        self._refresh_header()
        await self._refresh_sessions()
        self.query_one("#input", Input).focus()
        self._system("Type [bold #d4c9be]/help[/] for commands. Start typing to chat.")

    async def on_unmount(self) -> None:
        await self._cancel_tasks()

    # ── Actions ───────────────────────────────────────────────────────────────

    async def action_new_session(self) -> None:
        await self._create_new_session(select=True)

    async def action_refresh_data(self) -> None:
        await self._refresh_sessions()
        if self._current_session_id:
            await self._load_session_messages(self._current_session_id)
        self._system("Refreshed.")

    def action_focus_input(self) -> None:
        self.query_one("#input", Input).focus()

    def action_focus_sessions(self) -> None:
        self.query_one("#sessions", ListView).focus()

    def action_clear_transcript(self) -> None:
        self._transcript = []
        self._assistant_buffer = ""
        self._streaming = False
        log = self.query_one("#transcript", RichLog)
        log.clear()
        self.query_one("#deploy-log", RichLog).clear()
        self._system("Cleared.")

    # ── Events ────────────────────────────────────────────────────────────────

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        raw = event.value.strip()
        event.input.value = ""
        if not raw:
            return
        if raw.startswith("/"):
            await self._handle_command(raw)
            return
        await self._ensure_session()
        self._append_message("user", raw)
        if self._chat_task and not self._chat_task.done():
            self._system("Already streaming — wait for the current response to finish.")
            return
        self._chat_task = asyncio.create_task(self._stream_chat_message(raw))

    async def on_list_view_selected(self, event: ListView.Selected) -> None:
        if event.list_view.id != "sessions":
            return
        try:
            index = list(event.list_view.children).index(event.item)
        except ValueError:
            return
        if 0 <= index < len(self._sessions):
            await self._select_session(str(self._sessions[index]["id"]))

    def on_resize(self, event) -> None:
        self._apply_layout(event.size.width)
        self._refresh_header()

    # ── Layout helpers ────────────────────────────────────────────────────────

    def _apply_layout(self, width: int) -> None:
        body = self.query_one("#body", Container)
        left = self.query_one("#left-panel", Vertical)
        center = self.query_one("#center-panel", Vertical)
        right = self.query_one("#right-panel", Vertical)

        if width >= 130:
            new_mode = "wide"
        elif width >= 85:
            new_mode = "medium"
        else:
            new_mode = "narrow"

        # Reorder children when entering or leaving narrow mode so that
        # plan+logs sits on TOP of chat in narrow (more useful at a glance).
        if new_mode == "narrow" and self._layout_mode != "narrow":
            body.move_child(right, before=center)
        elif new_mode != "narrow" and self._layout_mode == "narrow":
            body.move_child(center, before=right)

        self._layout_mode = new_mode

        if new_mode == "wide":
            # ── 3-column side-by-side ─────────────────────────────────────────
            body.styles.layout = "horizontal"
            left.display = True
            right.display = True
            left.styles.width = 22
            left.styles.height = "1fr"
            left.styles.margin = (0, 1, 0, 0)
            center.styles.width = "1fr"
            center.styles.height = "1fr"
            center.styles.margin = (0, 1, 0, 0)
            right.styles.width = min(40, max(28, width // 5))
            right.styles.height = "1fr"
            right.styles.margin = (0, 0, 0, 0)

        elif new_mode == "medium":
            # ── 2-column: chat + plan/logs, sessions hidden ───────────────────
            body.styles.layout = "horizontal"
            left.display = False
            right.display = True
            center.styles.width = "1fr"
            center.styles.height = "1fr"
            center.styles.margin = (0, 1, 0, 0)
            right.styles.width = min(36, max(26, width // 4))
            right.styles.height = "1fr"
            right.styles.margin = (0, 0, 0, 0)

        else:
            # ── Narrow: plan+logs on top (compact), chat below (fills rest) ───
            body.styles.layout = "vertical"
            left.display = False
            right.display = True
            right.styles.width = "1fr"
            right.styles.height = 12
            right.styles.margin = (0, 0, 1, 0)
            center.styles.width = "1fr"
            center.styles.height = "1fr"
            center.styles.margin = (0, 0, 0, 0)

    # ── Header ────────────────────────────────────────────────────────────────

    def _refresh_header(self) -> None:
        config = load_config()
        email = config.user_email or "not logged in"
        session_label = (
            f"…{self._current_session_id[-6:]}"
            if self._current_session_id
            else "—"
        )
        width = self.size.width
        if width >= 100:
            meta = f"{email}  ·  session {session_label}"
        elif width >= 70:
            meta = f"{email}  ·  {session_label}"
        else:
            # very narrow: just show the session marker
            meta = session_label
        self.query_one("#header-meta", Static).update(meta)

    # ── Session list ──────────────────────────────────────────────────────────

    async def _refresh_sessions(self) -> None:
        try:
            api = self._build_api()
            self._sessions = api.list_chat_sessions()
        except (RuntimeError, APIError):
            self._sessions = []
        self._render_sessions()

    def _render_sessions(self) -> None:
        lv = self.query_one("#sessions", ListView)
        lv.clear()
        if not self._sessions:
            lv.append(ListItem(Label("[dim]No sessions yet[/]", markup=True)))
            self.query_one("#session-hint", Static).update(
                "[dim]/new to create a session[/]"
            )
            return

        for s in self._sessions:
            active = str(s["id"]) == self._current_session_id
            marker = "[bold #e8754a]●[/]" if active else "[#7a7480]○[/]"
            stype = s.get("session_type") or "general"
            sid_short = str(s["id"])[:6]
            line = f"{marker} [bold]{stype}[/] [dim]{sid_short}[/]"
            lv.append(ListItem(Label(line, markup=True)))

        hint_parts = ["[dim]↑↓ navigate · enter select[/]"]
        if self._current_session_id:
            hint_parts.append(f"[dim]active: …{self._current_session_id[-6:]}[/]")
        self.query_one("#session-hint", Static).update("\n".join(hint_parts))

    async def _create_new_session(self, *, select: bool = False) -> None:
        try:
            api = self._build_api()
            session = api.create_chat_session()
        except (RuntimeError, APIError) as exc:
            self._system(f"Could not create session: {exc}")
            return
        await self._refresh_sessions()
        self._system(f"New session [bold]{session['id']}[/]")
        if select:
            await self._select_session(str(session["id"]))

    async def _ensure_session(self) -> None:
        if not self._current_session_id:
            await self._create_new_session(select=True)

    async def _select_session(self, session_id: str) -> None:
        self._current_session_id = session_id
        self._assistant_buffer = ""
        self._streaming = False
        await self._load_session_messages(session_id)
        self._render_sessions()
        self._refresh_header()

    async def _load_session_messages(self, session_id: str) -> None:
        try:
            api = self._build_api()
            messages = api.list_chat_messages(session_id)
        except (RuntimeError, APIError) as exc:
            self._system(f"Could not load messages: {exc}")
            return
        log = self.query_one("#transcript", RichLog)
        log.clear()
        self._transcript = []
        for msg in messages:
            self._append_message(msg["role"], msg["content"], render_only=True)

    # ── Transcript rendering ──────────────────────────────────────────────────

    def _append_message(self, role: str, content: str, *, render_only: bool = False) -> None:
        """Append a completed message to the transcript."""
        if not render_only:
            self._transcript.append({"role": role, "content": content})
        log = self.query_one("#transcript", RichLog)
        log.write(self._format_message(role, content))

    def _format_message(self, role: str, content: str) -> str:
        """Return a Rich-markup string for a single message."""
        if role == "user":
            label = "[bold #c9b99a]  you [/]"
            body = f"[#d4c9be]{content}[/]"
            return f"{label}[#4a4050]│[/] {body}\n"
        if role == "assistant":
            label = "[bold #e8754a] zoro [/]"
            body = f"[#d4c9be]{content}[/]"
            return f"{label}[#4a4050]│[/] {body}\n"
        if role == "system":
            return f"[dim #7a7480]  ◦ {content}[/]\n"
        if role == "tool":
            return f"[#7060a0]  ⚡ {content}[/]\n"
        # fallback
        return f"[dim]{role}: {content}[/]\n"

    def _system(self, content: str) -> None:
        log = self.query_one("#transcript", RichLog)
        log.write(f"[dim #7a7480]  ◦ {content}[/]\n")

    def _update_streaming(self, token: str) -> None:
        """Called for each streamed token. Appends to the buffer and refreshes the last line."""
        self._assistant_buffer += token
        log = self.query_one("#transcript", RichLog)
        if self._streaming:
            # Replace the last written line by clearing the last entry and rewriting
            # RichLog does not support in-place update; we use a full-clear + replay strategy
            # capped at a reasonable transcript size to keep it snappy.
            log.clear()
            for entry in self._transcript:
                log.write(self._format_message(entry["role"], entry["content"]))
        # Write the live buffer as a partial assistant message
        label = "[bold #e8754a] zoro [/]"
        cursor = "[blink #e8754a]▌[/]"
        log.write(f"{label}[#4a4050]│[/] [#d4c9be]{self._assistant_buffer}[/]{cursor}\n")
        self._streaming = True

    def _finalize_streaming(self) -> None:
        if self._assistant_buffer:
            self._transcript.append({"role": "assistant", "content": self._assistant_buffer})
        self._assistant_buffer = ""
        self._streaming = False
        # Redraw cleanly without the cursor
        log = self.query_one("#transcript", RichLog)
        log.clear()
        for entry in self._transcript:
            log.write(self._format_message(entry["role"], entry["content"]))

    # ── Plan panel ────────────────────────────────────────────────────────────

    def _set_plan(self, text: str) -> None:
        self._current_plan_text = text
        plan_log = self.query_one("#plan", RichLog)
        plan_log.clear()
        if not text:
            plan_log.write("[dim #7a7480]No deployment plan.[/]\n")
            return
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                plan_log.write("")
                continue
            # Highlight step markers like "1.", "2." or "Step"
            if stripped[:2].rstrip(".").isdigit():
                plan_log.write(f"[bold #e8754a]{stripped}[/]")
            elif stripped.lower().startswith("step"):
                plan_log.write(f"[bold #e8754a]{stripped}[/]")
            elif stripped.startswith("#") or stripped.startswith("=="):
                plan_log.write(f"[bold #c9b99a]{stripped}[/]")
            elif stripped.startswith("-") or stripped.startswith("•"):
                plan_log.write(f"[#d4c9be]  {stripped}[/]")
            else:
                plan_log.write(f"[#d4c9be]{stripped}[/]")

    # ── Deploy log ────────────────────────────────────────────────────────────

    def _log_deploy(self, line: str) -> None:
        log = self.query_one("#deploy-log", RichLog)
        # Plain text log — apply level-based coloring via search
        upper = line.upper()
        if "ERROR" in upper or "FAILED" in upper or "FAILURE" in upper:
            log.write(f"[#c05050]{line}[/]")
        elif "WARN" in upper:
            log.write(f"[#c9a84c]{line}[/]")
        elif "SUCCESS" in upper or "SUCCEEDED" in upper or "COMPLETE" in upper:
            log.write(f"[#5a9a6f]{line}[/]")
        elif "STEP" in upper:
            log.write(f"[#5a85b0]{line}[/]")
        else:
            log.write(f"[#7a7480]{line}[/]")

    # ── API helper ────────────────────────────────────────────────────────────

    def _build_api(self, require_auth: bool = True) -> ZoroAPI:
        config = load_config()
        if require_auth and not config.access_token:
            raise RuntimeError("Not logged in. Run `zoro login` in another terminal.")
        return ZoroAPI(
            api_url=(self._api_url_override or config.api_url).rstrip("/"),
            access_token=config.access_token,
        )

    async def _cancel_tasks(self) -> None:
        for task in (self._chat_task, self._deployment_task):
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    # ── Commands ──────────────────────────────────────────────────────────────

    async def _handle_command(self, raw: str) -> None:
        try:
            parts = shlex.split(raw)
        except ValueError as exc:
            self._system(f"Parse error: {exc}")
            return

        cmd = parts[0].lower()
        args = parts[1:]

        if cmd == "/help":
            help_lines = [
                "[bold #e8754a]Commands[/]",
                "  [bold #d4c9be]/new[/]                         create a new session",
                "  [bold #d4c9be]/sessions[/]                    refresh session list",
                "  [bold #d4c9be]/use[/] [dim]<id>[/]                   switch to session",
                "  [bold #d4c9be]/whoami[/]                      show logged-in user",
                "  [bold #d4c9be]/projects[/]                    list projects",
                "  [bold #d4c9be]/servers[/]                     list servers",
                "  [bold #d4c9be]/envs[/] [dim]<project_id>[/]          list environments",
                "  [bold #d4c9be]/plan[/] [dim]<proj> <env> <branch>[/]  create deployment plan",
                "  [bold #d4c9be]/show[/] [dim]<deployment_id>[/]        show stored plan",
                "  [bold #d4c9be]/approve[/] [dim]<deployment_id>[/]     approve and start deploy",
                "  [bold #d4c9be]/cancel[/] [dim]<deployment_id>[/]      cancel deployment",
                "  [bold #d4c9be]/logs[/] [dim]<deployment_id>[/]        show deployment logs",
                "  [bold #d4c9be]/clear[/]                       clear transcript",
                "  [bold #d4c9be]/quit[/]                        exit",
            ]
            log = self.query_one("#transcript", RichLog)
            for line in help_lines:
                log.write(line)
            return

        if cmd == "/new":
            await self._create_new_session(select=True)
            return
        if cmd == "/sessions":
            await self._refresh_sessions()
            self._system("Sessions refreshed.")
            return
        if cmd == "/use":
            if len(args) != 1:
                self._system("Usage: /use <session_id>")
            else:
                await self._select_session(args[0])
            return
        if cmd == "/clear":
            self.action_clear_transcript()
            return
        if cmd == "/quit":
            self.exit()
            return

        try:
            api = self._build_api()
        except RuntimeError as exc:
            self._system(str(exc))
            return

        try:
            if cmd == "/whoami":
                data = api.whoami()
                self._system(json.dumps(data, indent=2))
            elif cmd == "/projects":
                data = api.list_projects()
                self._render_list_result("Projects", data, ["id", "name", "slug"])
            elif cmd == "/servers":
                data = api.list_servers()
                self._render_list_result("Servers", data, ["id", "name", "host"])
            elif cmd == "/envs":
                if len(args) != 1:
                    self._system("Usage: /envs <project_id>")
                else:
                    data = api.list_environments(args[0])
                    self._render_list_result("Environments", data, ["id", "name", "branch"])
            elif cmd == "/plan":
                if len(args) < 3:
                    self._system("Usage: /plan <project_id> <env_id> <branch> [method]")
                else:
                    method = args[3] if len(args) > 3 else "system"
                    data = api.create_deployment_plan(
                        project_id=args[0],
                        environment_id=args[1],
                        branch=args[2],
                        deploy_method=method,
                    )
                    self._current_deployment_id = data["deployment_id"]
                    self._set_plan(data.get("plan_text", ""))
                    self._system(
                        f"Plan ready · deployment [bold]{data['deployment_id']}[/]  "
                        f"· run [bold #d4c9be]/approve {data['deployment_id']}[/] to deploy"
                    )
                    self._refresh_header()
            elif cmd == "/show":
                if len(args) != 1:
                    self._system("Usage: /show <deployment_id>")
                else:
                    data = api.get_deployment_plan(args[0])
                    self._current_deployment_id = args[0]
                    self._set_plan(data.get("plan_text", ""))
                    self._refresh_header()
            elif cmd == "/approve":
                if len(args) != 1:
                    self._system("Usage: /approve <deployment_id>")
                else:
                    data = api.approve_deployment(args[0])
                    self._current_deployment_id = args[0]
                    self._system(f"Approved · queuing deployment [bold]{args[0]}[/]…")
                    self._start_deployment_stream(args[0])
                    self._refresh_header()
            elif cmd == "/cancel":
                if len(args) != 1:
                    self._system("Usage: /cancel <deployment_id>")
                else:
                    api.cancel_deployment(args[0])
                    self._system(f"Cancelled deployment [bold]{args[0]}[/]")
            elif cmd == "/logs":
                if len(args) != 1:
                    self._system("Usage: /logs <deployment_id>")
                else:
                    self._current_deployment_id = args[0]
                    logs = api.get_deployment_logs(args[0])
                    dlog = self.query_one("#deploy-log", RichLog)
                    dlog.clear()
                    if not logs:
                        self._log_deploy("No logs yet.")
                    for item in logs:
                        self._log_deploy(f"[{item['timestamp']}] {item['level'].upper()}: {item['message']}")
                    self._start_deployment_stream(args[0])
                    self._refresh_header()
            else:
                self._system(f"Unknown command [bold]{cmd}[/]. Use /help.")
        except APIError as exc:
            self._system(f"[#c05050]API error: {exc}[/]")

    def _render_list_result(self, title: str, items: list[dict], fields: list[str]) -> None:
        log = self.query_one("#transcript", RichLog)
        log.write(f"[bold #e8754a]{title}[/] ([dim]{len(items)} items[/])")
        for item in items:
            parts = []
            for f in fields:
                val = item.get(f, "")
                if val:
                    parts.append(f"[dim]{f}=[/][#d4c9be]{val}[/]")
            log.write("  " + "  ".join(parts) if parts else "  [dim](empty)[/]")
        log.write("")

    # ── Chat streaming ────────────────────────────────────────────────────────

    async def _stream_chat_message(self, content: str) -> None:
        if not self._current_session_id:
            self._system("No active session.")
            return
        api = self._build_api()
        ws_url = api.websocket_url("chat", self._current_session_id)
        self._assistant_buffer = ""
        self._streaming = False

        try:
            async with websockets.connect(ws_url) as ws:
                await ws.send(json.dumps({"type": "message", "content": content}))
                async for raw in ws:
                    event = json.loads(raw)
                    etype = event.get("type")
                    if etype == "token":
                        self._update_streaming(event.get("content", ""))
                    elif etype == "action":
                        await self._handle_chat_action(event)
                    elif etype == "error":
                        self._system(f"[#c05050]Agent error: {event.get('content', '')}[/]")
                    elif etype == "done":
                        break
        except Exception as exc:
            self._system(f"[#c05050]Stream error: {exc}[/]")
        finally:
            self._finalize_streaming()
            await self._refresh_sessions()

    async def _handle_chat_action(self, event: dict) -> None:
        action = event.get("action", "")
        data = event.get("data", {}) or {}

        if action == "tool.result.trigger_deployment":
            result = data.get("result", {}) or {}
            plan_text = result.get("plan_text")
            deployment_id = result.get("deployment_id")
            if plan_text:
                self._set_plan(str(plan_text))
            if deployment_id:
                self._current_deployment_id = str(deployment_id)
                self._refresh_header()
            self._system(
                f"Deployment plan ready · [bold #d4c9be]/approve {deployment_id}[/] to start"
            )
            return

        if action == "plan.approved":
            deployment_id = data.get("deployment_id")
            if deployment_id:
                self._current_deployment_id = str(deployment_id)
                self._start_deployment_stream(str(deployment_id))
                self._refresh_header()
            return

        # Generic tool activity
        tool_name = action.replace("tool.result.", "").replace("tool.call.", "")
        log = self.query_one("#transcript", RichLog)
        log.write(f"[#7060a0]  ⚡ {tool_name}[/]")

    # ── Deployment log streaming ──────────────────────────────────────────────

    def _start_deployment_stream(self, deployment_id: str) -> None:
        if self._deployment_task and not self._deployment_task.done():
            self._deployment_task.cancel()
        self._deployment_task = asyncio.create_task(
            self._stream_deployment_logs(deployment_id)
        )

    async def _stream_deployment_logs(self, deployment_id: str) -> None:
        api = self._build_api()
        ws_url = api.websocket_url("deployment", deployment_id)

        try:
            async with websockets.connect(ws_url) as ws:
                async for raw in ws:
                    event = json.loads(raw)
                    etype = event.get("type")
                    if etype == "connected":
                        self._log_deploy(
                            f"Connected · deployment {deployment_id} ({event.get('status')})"
                        )
                    elif etype == "plan_loaded":
                        steps = event.get("steps", [])
                        if steps:
                            lines = [
                                f"{i + 1}. {s.get('label', '')}"
                                + (f" — {s['detail']}" if s.get("detail") else "")
                                for i, s in enumerate(steps)
                            ]
                            self._set_plan("\n".join(lines))
                    elif etype == "log":
                        self._log_deploy(event.get("line", ""))
                    elif etype == "log_history":
                        for item in event.get("logs", []):
                            self._log_deploy(
                                f"[{item['timestamp']}] {item['level'].upper()}: {item['message']}"
                            )
                    elif etype == "step":
                        status = event.get("status", "").upper()
                        label = event.get("label") or event.get("step", "")
                        icon = {"RUNNING": "▶", "DONE": "✓", "FAILED": "✗"}.get(status, "·")
                        self._log_deploy(f"{icon} {status}: {label}")
                    elif etype == "step_history":
                        for step in event.get("steps", []):
                            status = step.get("status", "").upper()
                            label = step.get("label") or step.get("step_id", "")
                            self._log_deploy(f"· {status}: {label}")
                    elif etype == "deployment_complete":
                        success = event.get("success", False)
                        dur = event.get("duration_seconds")
                        msg = "SUCCEEDED" if success else "FAILED"
                        suffix = f" in {dur}s" if dur else ""
                        self._log_deploy(f"DEPLOYMENT {msg}{suffix}")
                        break
                    elif etype == "deployment_failed":
                        self._log_deploy(f"DEPLOYMENT FAILED: {event.get('error', '')}")
                    elif etype == "rollback_complete":
                        self._log_deploy(f"ROLLBACK COMPLETE: {event.get('rollback_sha', '')}")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._log_deploy(f"Stream error: {exc}")
