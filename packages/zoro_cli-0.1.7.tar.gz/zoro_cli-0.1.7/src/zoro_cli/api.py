from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx


@dataclass
class APIError(Exception):
    message: str
    status_code: int | None = None

    def __str__(self) -> str:
        if self.status_code is None:
            return self.message
        return f"{self.message} (HTTP {self.status_code})"


class ZoroAPI:
    def __init__(self, api_url: str, access_token: str = "", timeout: float = 30.0):
        self.api_url = api_url.rstrip("/")
        self.access_token = access_token
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def request(self, method: str, path: str, json_body: dict[str, Any] | None = None) -> Any:
        url = f"{self.api_url}/{path.lstrip('/')}"
        try:
            response = httpx.request(
                method,
                url,
                headers=self._headers(),
                json=json_body,
                timeout=self.timeout,
                follow_redirects=True,
            )
        except httpx.ConnectError as exc:
            raise APIError(
                f"Could not reach {self.api_url}. Check your API URL and network connection."
            ) from exc
        except httpx.TimeoutException as exc:
            raise APIError(
                f"Timed out talking to {self.api_url}. Check your API URL and network connection."
            ) from exc
        except httpx.HTTPError as exc:
            raise APIError(f"Request failed: {exc}") from exc

        # --debug output
        try:
            from zoro_cli.state import state
            if state.debug:
                import sys
                print(f"[DEBUG] {method} {url}", file=sys.stderr)
                if json_body:
                    import json as _json
                    print(f"[DEBUG] body: {_json.dumps(json_body)}", file=sys.stderr)
                print(f"[DEBUG] status: {response.status_code}", file=sys.stderr)
        except ImportError:
            pass

        if response.status_code >= 400:
            message = self._extract_error_message(response)
            raise APIError(message, response.status_code)

        if not response.content:
            return {}
        return response.json()

    @staticmethod
    def _extract_error_message(response: httpx.Response) -> str:
        try:
            payload = response.json()
        except ValueError:
            return response.text or "Request failed"

        if isinstance(payload, dict):
            detail = payload.get("detail")
            if isinstance(detail, str) and detail:
                return detail
            error = payload.get("error")
            if isinstance(error, str) and error:
                return error
        return response.text or "Request failed"

    def login(self, email: str, password: str) -> dict[str, Any]:
        return self.request(
            "POST",
            "/auth/login/",
            json_body={"email": email, "password": password},
        )

    def whoami(self) -> dict[str, Any]:
        return self.request("GET", "/users/me/")

    def list_projects(self) -> list[dict[str, Any]]:
        return self.request("GET", "/projects/")

    def list_servers(self) -> list[dict[str, Any]]:
        return self.request("GET", "/servers/")

    def list_environments(self, project_id: str) -> list[dict[str, Any]]:
        return self.request("GET", f"/projects/{project_id}/environments")

    def list_chat_sessions(self, limit: int = 30) -> list[dict[str, Any]]:
        return self.request("GET", f"/chat/sessions/?limit={limit}")

    def create_chat_session(self) -> dict[str, Any]:
        return self.request("POST", "/chat/sessions/")

    def list_chat_messages(self, session_id: str, limit: int = 200) -> list[dict[str, Any]]:
        return self.request("GET", f"/chat/{session_id}/messages?limit={limit}")

    def create_deployment_plan(
        self,
        *,
        project_id: str,
        environment_id: str,
        branch: str,
        deploy_method: str,
        commit_sha: str = "",
        followup_environments: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        return self.request(
            "POST",
            f"/projects/{project_id}/deployments/plan",
            json_body={
                "environment_id": environment_id,
                "branch": branch,
                "deploy_method": deploy_method,
                "commit_sha": commit_sha,
                "followup_environments": followup_environments or [],
            },
        )

    def get_deployment_plan(self, deployment_id: str) -> dict[str, Any]:
        return self.request("GET", f"/deployments/{deployment_id}/plan")

    def approve_deployment(self, deployment_id: str) -> dict[str, Any]:
        return self.request("POST", f"/deployments/{deployment_id}/approve")

    def cancel_deployment(self, deployment_id: str) -> dict[str, Any]:
        return self.request("POST", f"/deployments/{deployment_id}/cancel")

    def get_deployment_logs(self, deployment_id: str) -> list[dict[str, Any]]:
        return self.request("GET", f"/deployments/{deployment_id}/logs")

    def websocket_url(self, kind: str, identifier: str) -> str:
        parsed = urlparse(self.api_url)
        scheme = "wss" if parsed.scheme == "https" else "ws"
        netloc = parsed.netloc
        if kind == "chat":
            return f"{scheme}://{netloc}/ws/chat/{identifier}/?token={self.access_token}"
        if kind == "deployment":
            return f"{scheme}://{netloc}/ws/deployments/{identifier}/logs/?token={self.access_token}"
        raise ValueError(f"Unsupported websocket kind: {kind}")
