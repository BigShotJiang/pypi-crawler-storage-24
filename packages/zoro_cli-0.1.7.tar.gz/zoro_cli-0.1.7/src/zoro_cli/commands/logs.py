from __future__ import annotations

import asyncio
import json
from datetime import datetime
from typing import Optional

import typer

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import console, get_theme, print_error, print_info, print_json
from zoro_cli.state import state

app = typer.Typer(help="Fetch and stream deployment logs")

_LEVEL_STYLES = {
    "error":    "bold red",
    "critical": "bold red",
    "warning":  "yellow",
    "warn":     "yellow",
    "info":     "",           # default text
    "debug":    "dim",
}


def _format_line(level: str, message: str, timestamp: str, theme) -> str:
    ts_part = f"[{theme.muted}]{timestamp}[/] " if timestamp else ""
    style = _LEVEL_STYLES.get(level.lower(), "")
    badge = f"[{style}]{level.upper():>7}[/] " if style else f"{level.upper():>7} "
    return f"{ts_part}{badge}{message}"


@app.command()
def logs(
    deployment_id: str = typer.Argument(..., help="Deployment ID"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Stream live until Ctrl+C"),
    level: Optional[str] = typer.Option(None, "--level", "-l", help="Filter: error, warning, info, debug"),
    lines: int = typer.Option(100, "--lines", "-n", help="Number of historical lines to fetch"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Show deployment logs. Use --follow to stream live.

    \b
    Examples:
      zoro deploy logs <id>
      zoro deploy logs <id> --follow
      zoro deploy logs <id> --level error
      zoro deploy logs <id> --json | jq '.[].message'
    """
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)

    # ── Historical logs ───────────────────────────────────────────────────────
    try:
        history = api.get_deployment_logs(deployment_id)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    # Filter by level if requested
    if level:
        history = [e for e in history if e.get("level", "").lower() == level.lower()]

    # Cap to --lines
    history = history[-lines:]

    if state.json_output:
        print_json(history)
        if not follow:
            return
    else:
        if not history:
            print_info("No logs yet.")
        for entry in history:
            console.print(_format_line(
                level=entry.get("level", "info"),
                message=entry.get("message", ""),
                timestamp=_short_ts(entry.get("timestamp", "")),
                theme=t,
            ))

    if not follow:
        return

    # ── Live follow via WebSocket ─────────────────────────────────────────────
    from zoro_cli.config import load_config
    cfg = load_config()
    access_token = cfg.access_token
    effective_url = (api_url or cfg.api_url).rstrip("/")

    console.print(f"[{t.muted}]  Following deployment {deployment_id[:8]}… (Ctrl+C to stop)[/]")

    async def _follow() -> None:
        from zoro_cli.streaming import stream_deployment

        def on_event(event: dict) -> str | None:
            etype = event.get("type", "")
            if etype == "log":
                raw_line = event.get("line", "").rstrip()
                if raw_line:
                    if level and level.lower() not in raw_line.lower():
                        return None
                    if state.json_output:
                        console.print(json.dumps({"line": raw_line}))
                    else:
                        console.print(raw_line)
            elif etype == "log_history":
                for item in event.get("logs", []):
                    lvl = item.get("level", "info")
                    if level and lvl.lower() != level.lower():
                        continue
                    if state.json_output:
                        console.print(json.dumps(item))
                    else:
                        console.print(_format_line(
                            level=lvl,
                            message=item.get("message", ""),
                            timestamp=_short_ts(item.get("timestamp", "")),
                            theme=t,
                        ))
            elif etype in ("deployment_complete", "deployment_failed"):
                success = event.get("success", etype == "deployment_complete")
                dur = event.get("duration_seconds")
                msg = "SUCCEEDED" if success else "FAILED"
                suffix = f" in {dur}s" if dur else ""
                console.print(f"[{t.muted}]── Deployment {msg}{suffix}[/]")
                return "done"
            return None

        await stream_deployment(
            api_url=effective_url,
            deployment_id=deployment_id,
            access_token=access_token,
            on_event=on_event,
        )

    try:
        asyncio.run(_follow())
    except KeyboardInterrupt:
        console.print(f"\n[{t.muted}]  Stopped.[/]")


def _short_ts(ts: str) -> str:
    """Convert an ISO timestamp to HH:MM:SS."""
    if not ts:
        return ""
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%H:%M:%S")
    except ValueError:
        return ts[:8]
