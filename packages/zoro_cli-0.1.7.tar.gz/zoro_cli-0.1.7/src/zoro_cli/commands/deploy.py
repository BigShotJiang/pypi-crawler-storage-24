from __future__ import annotations

import asyncio
import time
from datetime import datetime
from typing import Optional

import typer
from rich.columns import Columns
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.rule import Rule
from rich.text import Text

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import console, get_theme, print_error, print_success, render_step_line
from zoro_cli.streaming import stream_deployment

app = typer.Typer(no_args_is_help=True, help="Deploy a project with live log streaming")


# ── Renderers ─────────────────────────────────────────────────────────────────

def _render_steps(steps: list[dict], elapsed: float) -> Panel:
    t = get_theme()
    body = Text()
    for step in steps:
        body.append_text(render_step_line(
            label=step.get("label") or step.get("step_id") or "…",
            status=step.get("status", "pending"),
            theme=t,
        ))
    mins, secs = divmod(int(elapsed), 60)
    body.append(f"\n  elapsed  {mins:02d}:{secs:02d}", style=t.muted)
    return Panel(body, title=f"[bold {t.accent}]Steps[/]", border_style=t.dim_border, padding=(0, 1))


def _render_logs(lines: list[str]) -> Panel:
    t = get_theme()
    visible = lines[-40:]  # last 40 lines
    body = Text()
    for line in visible:
        upper = line.upper()
        if "ERROR" in upper or "FAILED" in upper:
            body.append(line + "\n", style=t.error)
        elif "WARN" in upper:
            body.append(line + "\n", style=t.warning)
        elif "SUCCESS" in upper or "SUCCEEDED" in upper or "COMPLETE" in upper:
            body.append(line + "\n", style=t.success)
        else:
            body.append(line + "\n", style=t.muted)
    return Panel(body, title=f"[bold {t.accent}]Logs[/]", border_style=t.dim_border, padding=(0, 1))


def _build_layout(steps: list[dict], log_lines: list[str], elapsed: float) -> Layout:
    layout = Layout()
    layout.split_row(
        Layout(_render_steps(steps, elapsed), name="steps", ratio=1),
        Layout(_render_logs(log_lines), name="logs", ratio=2),
    )
    return layout


def _summary_panel(project_id: str, environment_id: str, branch: str, method: str) -> Panel:
    t = get_theme()
    body = Text()
    body.append(f"  Project      ", style=t.muted)
    body.append(f"{project_id}\n", style=f"bold {t.accent}")
    body.append(f"  Environment  ", style=t.muted)
    body.append(f"{environment_id}\n", style="bold")
    body.append(f"  Branch       ", style=t.muted)
    body.append(f"{branch}\n", style="bold")
    body.append(f"  Method       ", style=t.muted)
    body.append(f"{method}\n", style="dim")
    return Panel(body, title=f"[bold {t.accent}] Deploying [/]", border_style=t.accent, padding=(0, 1))


# ── Command ───────────────────────────────────────────────────────────────────

@app.command()
def run(
    project_id: str = typer.Option(..., "--project-id", "-p"),
    environment_id: str = typer.Option(..., "--environment-id", "-e"),
    branch: str = typer.Option(..., "--branch", "-b"),
    method: str = typer.Option("system", "--method"),
    commit_sha: str = typer.Option("", "--commit-sha"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
    json_output: bool = typer.Option(False, "--json", help="Output JSON, no live UI"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Create a deployment plan, confirm, then stream live logs."""
    t = get_theme()

    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)

    # ── Step 1: create plan ───────────────────────────────────────────────────
    console.print(_summary_panel(project_id, environment_id, branch, method))

    if not yes:
        confirmed = typer.confirm("Deploy?", default=False)
        if not confirmed:
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    console.print(f"[{t.muted}]Creating deployment plan…[/]")
    try:
        plan_data = api.create_deployment_plan(
            project_id=project_id,
            environment_id=environment_id,
            branch=branch,
            deploy_method=method,
            commit_sha=commit_sha,
        )
    except APIError as exc:
        print_error(f"Plan failed: {exc}")
        raise typer.Exit(1)

    deployment_id: str = plan_data["deployment_id"]
    plan_text: str = plan_data.get("plan_text", "")
    plan_steps: list[dict] = plan_data.get("plan_data", {}).get("steps", [])

    # Show the plan
    if plan_text:
        console.print(Rule(f"[bold {t.accent}]Deployment plan[/]", style=t.dim_border))
        console.print(plan_text)
        console.print(Rule(style=t.dim_border))

    # Seed step list from plan_data if available
    steps: list[dict] = [
        {"label": s.get("label", s.get("step_id", "")), "status": "pending"}
        for s in plan_steps
    ]

    # ── Step 2: approve ───────────────────────────────────────────────────────
    if not yes:
        confirmed = typer.confirm("Approve and start deployment?", default=False)
        if not confirmed:
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    try:
        api.approve_deployment(deployment_id)
    except APIError as exc:
        print_error(f"Approval failed: {exc}")
        raise typer.Exit(1)

    if json_output:
        import json
        console.print(json.dumps({"deployment_id": deployment_id, "status": "approved"}))
        raise typer.Exit(0)

    # ── Step 3: stream ────────────────────────────────────────────────────────
    console.print(f"\n[{t.accent}]Streaming deployment {deployment_id[:8]}…[/]\n")

    config = api  # not config; we need access_token from the build_api result
    from zoro_cli.config import load_config
    cfg = load_config()
    access_token = cfg.access_token
    effective_api_url = (api_url or cfg.api_url).rstrip("/")

    log_lines: list[str] = []
    start_time = time.monotonic()
    final_success: bool | None = None

    def on_event(event: dict) -> str | None:
        nonlocal final_success
        etype = event.get("type", "")

        if etype == "connected":
            status = event.get("status", "")
            log_lines.append(f"Connected  ({status})")

        elif etype == "plan_loaded":
            nonlocal steps
            ws_steps = event.get("steps", [])
            if ws_steps:
                steps = [
                    {"label": s.get("label", s.get("step_id", "")), "status": "pending"}
                    for s in ws_steps
                ]

        elif etype == "step":
            label = event.get("label") or event.get("step") or ""
            status = event.get("status", "running").lower()
            # Update matching step or append
            for s in steps:
                if s["label"] == label or label in s["label"]:
                    s["status"] = status
                    break
            else:
                steps.append({"label": label, "status": status})

        elif etype == "log":
            line = event.get("line", "").rstrip()
            if line:
                log_lines.append(line)

        elif etype == "log_history":
            for item in event.get("logs", []):
                ts = item.get("timestamp", "")
                level = item.get("level", "").upper()
                msg = item.get("message", "")
                log_lines.append(f"[{ts}] {level}: {msg}")

        elif etype == "deployment_complete":
            final_success = event.get("success", False)
            dur = event.get("duration_seconds")
            label = "SUCCEEDED" if final_success else "FAILED"
            log_lines.append(f"── Deployment {label}" + (f" in {dur}s" if dur else ""))
            # Mark all running steps as done/failed
            for s in steps:
                if s["status"] == "running":
                    s["status"] = "done" if final_success else "failed"
            return "done"

        elif etype == "deployment_failed":
            final_success = False
            log_lines.append(f"── FAILED: {event.get('error', '')}")
            return "done"

        return None

    try:
        with Live(
            _build_layout(steps, log_lines, 0),
            console=console,
            refresh_per_second=8,
            screen=False,
            vertical_overflow="visible",
        ) as live:
            async def _run() -> None:
                await stream_deployment(
                    api_url=effective_api_url,
                    deployment_id=deployment_id,
                    access_token=access_token,
                    on_event=on_event,
                )

            async def _tick_and_run() -> None:
                stream_task = asyncio.create_task(_run())
                while not stream_task.done():
                    elapsed = time.monotonic() - start_time
                    live.update(_build_layout(steps, log_lines, elapsed))
                    await asyncio.sleep(0.12)
                await stream_task  # propagate exceptions

            asyncio.run(_tick_and_run())

    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted — deployment may still be running.[/]")
        raise typer.Exit(1)
    except Exception as exc:
        print_error(f"Stream error: {exc}")
        raise typer.Exit(1)

    # ── Final result ──────────────────────────────────────────────────────────
    console.print()
    if final_success:
        elapsed = time.monotonic() - start_time
        mins, secs = divmod(int(elapsed), 60)
        print_success(f"Deployed in {mins:02d}:{secs:02d}")
    elif final_success is False:
        print_error(
            "Deployment failed.",
            hint=f"Run: zoro deploy logs {deployment_id}",
        )
        raise typer.Exit(1)
