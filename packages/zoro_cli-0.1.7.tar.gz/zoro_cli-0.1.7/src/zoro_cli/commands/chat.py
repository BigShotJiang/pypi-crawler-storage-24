from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Optional

import typer
from rich.rule import Rule
from rich.text import Text

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import console, get_theme, print_error, print_info
from zoro_cli.streaming import stream_chat

app = typer.Typer(help="Interactive chat session with the Zoro agent")


# ── Message renderers ─────────────────────────────────────────────────────────

def _render_user(content: str) -> Text:
    """Right-leaning, muted label — user owns the message."""
    t = get_theme()
    out = Text()
    out.append("        you  ", style=f"bold {t.user_label}")
    out.append(content, style="white")
    return out


def _render_assistant(content: str, streaming: bool = False) -> Text:
    """Accent-coloured label, slightly indented — Zoro's voice."""
    t = get_theme()
    prefix = Text()
    prefix.append("  zoro  ", style=f"bold {t.accent}")
    prefix.append("│ ", style=t.muted)

    body = Text()
    body.append_text(prefix)
    body.append(content, style=f"{t.accent}")   # brand colour, distinct from user's white
    if streaming:
        body.append(" ▌", style=f"blink bold {t.accent}")
    return body


def _print_history(messages: list[dict]) -> None:
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "") or ""
        if not content.strip():
            continue
        if role == "user":
            console.print(_render_user(content))
        elif role == "assistant":
            console.print(_render_assistant(content))
        console.print()


def _stream_response(
    api_url: str,
    session_id: str,
    access_token: str,
    user_message: str,
) -> tuple[str, list[str], str | None]:
    """Returns (final_text, tools_used, deployment_id_if_triggered)."""
    import json as _json
    t = get_theme()
    buffer: dict = {"text": "", "tools": [], "deployment_id": None, "pending_deployment_id": None}
    label_markup = f"[bold {t.accent}] zoro [/][{t.muted}]│[/] "

    def on_event(event: dict) -> str | None:
        etype = event.get("type", "")
        if etype == "token":
            buffer["text"] += event.get("content", "")
            live.update(Text.from_markup(
                f"{label_markup}{buffer['text']}[blink bold {t.accent}]▌[/]"
            ))
        elif etype == "action":
            action = event.get("action", "")
            tool_name = action.replace("tool.result.", "").replace("tool.call.", "")
            if tool_name and tool_name not in buffer["tools"]:
                buffer["tools"].append(tool_name)

            # Capture deployment_id from tool result or plan approval
            data = event.get("data", {}) or {}
            if action == "plan.approved":
                # Plan was approved — deployment is now actually queued
                buffer["deployment_id"] = data.get("deployment_id") or buffer.get("deployment_id")
            elif action == "tool.result.trigger_deployment":
                result = data.get("result", {}) or {}
                if isinstance(result, str):
                    try:
                        result = _json.loads(result)
                    except Exception:
                        result = {}
                if result.get("deployment_id"):
                    buffer["pending_deployment_id"] = result["deployment_id"]

            live.update(Text.from_markup(
                f"{label_markup}{buffer['text']}\n"
                f"  [{t.tool}]⚡ {tool_name}[/]"
            ))
        elif etype == "error":
            buffer["text"] += f"\n[Error: {event.get('content', '')}]"
        elif etype == "done":
            return "done"
        return None

    from rich.live import Live
    with Live(
        Text.from_markup(f"{label_markup}[dim]thinking…[/]"),
        console=console,
        refresh_per_second=15,
        transient=False,
    ) as live:
        asyncio.run(stream_chat(
            api_url=api_url,
            session_id=session_id,
            access_token=access_token,
            message=user_message,
            on_event=on_event,
        ))
        live.update(Text.from_markup(f"{label_markup}{buffer['text']}"))

    # Fall back to the pending id if plan.approved never fired (e.g. re-deploy flow)
    dep_id = buffer["deployment_id"] or buffer["pending_deployment_id"]
    return buffer["text"], buffer["tools"], dep_id


def _stream_deployment_inline(api_url: str, deployment_id: str, access_token: str) -> None:
    from zoro_cli.streaming import stream_deployment
    t = get_theme()

    console.print()

    def on_event(event: dict) -> str | None:
        msg = (event.get("message") or event.get("data") or "").rstrip()
        if msg:
            style = t.error if event.get("stream") == "stderr" else t.muted
            console.print(f"  [{style}]{msg}[/]")
        if event.get("type") in ("deployment_complete", "deployment_failed"):
            return "done"
        return None

    asyncio.run(stream_deployment(
        api_url=api_url,
        deployment_id=deployment_id,
        access_token=access_token,
        on_event=on_event,
    ))
    console.print()


# ── prompt_toolkit setup ──────────────────────────────────────────────────────

def _make_prompt_session(theme_accent: str):
    """Build a prompt_toolkit PromptSession with Zoro styling and history."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.styles import Style
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.formatted_text import HTML

    history_dir = Path.home() / ".zoro"
    history_dir.mkdir(exist_ok=True)
    history_file = history_dir / "chat_history"

    # Convert hex color for prompt_toolkit (strip #)
    accent = theme_accent.lstrip("#")

    style = Style.from_dict({
        "prompt":        f"#{accent} bold",
        "prompt.arrow":  f"#{accent}",
        "bottom-toolbar": "bg:#1a1a1a #555555",
    })

    kb = KeyBindings()

    @kb.add("c-c")
    def _ctrl_c(event):
        # Clear current buffer on Ctrl+C (don't exit — use Ctrl+D or 'exit')
        event.app.current_buffer.reset()
        print("")

    session: PromptSession = PromptSession(
        history=FileHistory(str(history_file)),
        style=style,
        key_bindings=kb,
        mouse_support=False,
        enable_history_search=True,
    )
    return session


# ── Command ───────────────────────────────────────────────────────────────────

@app.command()
def start(
    session_id: Optional[str] = typer.Option(None, "--session", "-s", help="Resume a session by ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Open an interactive chat session. Stream agent responses token by token.

    \b
    Shortcuts:
      ↑ / ↓     Browse history
      Ctrl+C    Clear current input
      Ctrl+D    Exit
      exit      Exit
    """
    t = get_theme()

    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)

    from zoro_cli.config import load_config
    cfg = load_config()
    access_token = cfg.access_token
    effective_api_url = (api_url or cfg.api_url).rstrip("/")

    # ── Session setup ─────────────────────────────────────────────────────────
    if session_id:
        active_session_id = session_id
    else:
        try:
            session = api.create_chat_session()
            active_session_id = str(session["id"])
        except APIError as exc:
            print_error(f"Could not create session: {exc}")
            raise typer.Exit(1)

    # ── Load history ──────────────────────────────────────────────────────────
    messages: list[dict] = []
    try:
        raw_messages = api.list_chat_messages(active_session_id)
        for m in raw_messages:
            messages.append({"role": m["role"], "content": m["content"]})
    except APIError:
        pass

    # ── Header ────────────────────────────────────────────────────────────────
    console.print(Rule(style=t.muted))
    console.print(
        f"  [{t.muted}]session {active_session_id[:8]}…  ·  ↑↓ history · Ctrl+C clear · Ctrl+D or [bold]exit[/bold] to quit[/]"
    )
    console.print()

    if messages:
        _print_history(messages)

    # ── Input loop with prompt_toolkit ───────────────────────────────────────
    try:
        from prompt_toolkit.formatted_text import HTML
        prompt_session = _make_prompt_session(t.accent)
    except ImportError:
        # Fallback to plain input if prompt_toolkit not available
        prompt_session = None

    while True:
        try:
            if prompt_session:
                user_input = prompt_session.prompt(
                    HTML(f'<prompt> ❯ </prompt> '),
                ).strip()
            else:
                user_input = input(" ❯  ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print(f"\n[{t.muted}]  Goodbye.[/]")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "/quit", "/exit"):
            console.print(f"[{t.muted}]  Goodbye.[/]")
            break

        # Overwrite the prompt_toolkit input line with the formatted user message
        import sys
        sys.stdout.write("\033[1A\033[2K")  # cursor up 1, erase line
        sys.stdout.flush()
        console.print(_render_user(user_input))
        console.print()
        messages.append({"role": "user", "content": user_input})

        # Stream assistant response
        try:
            final_text, tools, deployment_id = _stream_response(
                api_url=effective_api_url,
                session_id=active_session_id,
                access_token=access_token,
                user_message=user_input,
            )
        except KeyboardInterrupt:
            console.print(f"\n[{t.muted}]  Interrupted.[/]")
            continue
        except Exception as exc:
            print_error(f"Stream error: {exc}")
            continue

        if final_text:
            messages.append({"role": "assistant", "content": final_text})

        if tools:
            t2 = get_theme()
            console.print(f"  [{t2.tool}]⚡ {' · '.join(tools)}[/]")

        console.print()

        # Auto-stream deployment logs when trigger_deployment was called
        if deployment_id:
            try:
                _stream_deployment_inline(
                    api_url=effective_api_url,
                    deployment_id=deployment_id,
                    access_token=access_token,
                )
            except KeyboardInterrupt:
                console.print(f"  [{t.muted}]  Stopped watching — deployment continues in background.[/]")
            except Exception as exc:
                console.print(f"  [{t.muted}]  Could not stream logs: {exc}[/]")


@app.command("sessions")
def sessions(
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Browse past chat sessions and resume one."""
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout as PTLayout
    from prompt_toolkit.layout.containers import HSplit, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.styles import Style as PTStyle

    t = get_theme()

    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
    except RuntimeError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    try:
        session_list = api.list_chat_sessions(limit=50)
    except APIError as exc:
        print_error(f"Could not load sessions: {exc}")
        raise typer.Exit(1)

    if not session_list:
        console.print(f"  [{t.muted}]No sessions yet. Start one with:[/]  zoro chat start")
        return

    # Fetch first user message as preview for each session (best-effort)
    previews: dict[str, str] = {}
    for s in session_list:
        sid = str(s.get("id", ""))
        try:
            msgs = api.list_chat_messages(sid, limit=10)
            for m in msgs:
                if m.get("role") == "user" and m.get("content", "").strip():
                    previews[sid] = m["content"].strip()[:60]
                    break
        except Exception:
            pass

    selected = [0]
    chosen: dict | None = None

    def _rows():
        rows = []
        for i, s in enumerate(session_list):
            sid     = str(s.get("id", ""))
            sid_short = sid[:8]
            ts      = (s.get("updated_at") or s.get("created_at") or "")[:16].replace("T", "  ")
            stype   = s.get("session_type", "")
            preview = previews.get(sid) or stype or "—"
            is_sel  = i == selected[0]
            if is_sel:
                rows.append(("class:sel", f"  ❯  {sid_short}…  {ts}  {preview}\n"))
            else:
                rows.append(("class:row", f"     {sid_short}…  {ts}  {preview}\n"))
        rows.append(("class:hint", "\n  ↑↓ navigate · Enter resume · q quit\n"))
        return rows

    kb = KeyBindings()

    @kb.add("up")
    def _up(event):
        selected[0] = max(0, selected[0] - 1)

    @kb.add("down")
    def _down(event):
        selected[0] = min(len(session_list) - 1, selected[0] + 1)

    @kb.add("enter")
    def _enter(event):
        nonlocal chosen
        chosen = session_list[selected[0]]
        event.app.exit()

    @kb.add("q")
    @kb.add("c-c")
    def _quit(event):
        event.app.exit()

    accent = t.accent.lstrip("#")
    style = PTStyle.from_dict({
        "sel":  f"#{accent} bold",
        "row":  "#888888",
        "hint": "#555555",
    })

    app_pt = Application(
        layout=PTLayout(HSplit([Window(FormattedTextControl(_rows, focusable=False))])),
        key_bindings=kb,
        style=style,
        full_screen=False,
        mouse_support=False,
    )
    app_pt.run()

    if chosen:
        console.print()
        start(session_id=str(chosen["id"]), api_url=api_url)
