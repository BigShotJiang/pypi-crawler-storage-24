from __future__ import annotations

from typing import Optional

import typer

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import console, get_theme, print_error, print_info, print_json, print_success, print_warning
from zoro_cli.state import state

app = typer.Typer(no_args_is_help=True, help="Manage project secrets")


def _resolve_project(api, slug_or_id: str) -> str:
    projects = api.list_projects()
    match = next(
        (p for p in projects if p["id"] == slug_or_id or p.get("slug") == slug_or_id),
        None,
    )
    if not match:
        raise APIError(f"Project '{slug_or_id}' not found.")
    return match["id"]


def _resolve_env(api, project_id: str, env_name: str) -> str:
    envs = api.list_environments(project_id)
    match = next(
        (e for e in envs if e["id"] == env_name or e.get("name", "").lower() == env_name.lower()),
        None,
    )
    if not match:
        raise APIError(f"Environment '{env_name}' not found.")
    return match["id"]


def _mask(value: str) -> str:
    return "••••••••"


@app.command("list")
def secrets_list(
    project: str = typer.Argument(..., help="Project slug or ID"),
    env: str = typer.Option("production", "--env", "-e"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """List secrets for a project environment. Values are always masked."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
        secrets = api.request("GET", f"/projects/{project_id}/environments/{env_id}/secrets")
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if state.json_output:
        # Never reveal secret values in JSON output either
        for s in secrets:
            s["value"] = "••••••••"
        print_json(secrets)
        return

    if not secrets:
        print_info(f"No secrets for {project}/{env}.")
        return

    from rich.table import Table
    from rich import box
    table = Table(box=box.SIMPLE, header_style=f"bold {t.accent}")
    table.add_column("Name")
    table.add_column("Value")
    table.add_column("Updated")

    for s in secrets:
        name = s.get("name", "")
        updated = s.get("updated_at", "")[:10]
        table.add_row(
            f"[bold]{name}[/]",
            f"[{t.muted}]••••••••[/]",
            f"[{t.muted}]{updated}[/]",
        )

    console.print(table)


@app.command("set")
def secrets_set(
    project: str = typer.Argument(..., help="Project slug or ID"),
    kv: str = typer.Argument(..., help="NAME=VALUE"),
    env: str = typer.Option("production", "--env", "-e"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Set a secret value.

    \b
    Examples:
      zoro secrets set myapp DATABASE_URL=postgres://...
      zoro secrets set myapp STRIPE_KEY=sk_live_... --env staging
    """
    if "=" not in kv:
        print_error("Format must be NAME=VALUE")
        raise typer.Exit(1)
    name, _, value = kv.partition("=")
    name = name.strip()

    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if not state.force:
        if not typer.confirm(f"Set secret '{name}' in {project}/{env}?", default=True):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    try:
        api.request(
            "POST",
            f"/projects/{project_id}/environments/{env_id}/secrets",
            json_body={"name": name, "value": value},
        )
    except APIError as exc:
        print_error(f"Failed to set '{name}': {exc}")
        raise typer.Exit(1)

    print_success(f"Secret '{name}' set in {project}/{env}")


@app.command("delete")
def secrets_delete(
    project: str = typer.Argument(..., help="Project slug or ID"),
    name: str = typer.Argument(..., help="Secret name to delete"),
    env: str = typer.Option("production", "--env", "-e"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Delete a secret."""
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if not state.force:
        if not typer.confirm(f"Delete secret '{name}' from {project}/{env}?", default=False):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    try:
        api.request("DELETE", f"/projects/{project_id}/environments/{env_id}/secrets/{name}")
    except APIError as exc:
        print_error(f"Failed to delete '{name}': {exc}")
        raise typer.Exit(1)

    print_success(f"Secret '{name}' deleted from {project}/{env}")
