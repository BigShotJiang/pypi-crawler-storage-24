from __future__ import annotations

from typing import Optional

import typer

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import console, get_theme, print_error, print_info, print_json, print_success, print_table
from zoro_cli.state import state

app = typer.Typer(no_args_is_help=True, help="Manage repository connections")


@app.command("list")
def repos_list(
    project: str = typer.Argument(..., help="Project ID or slug"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """List repositories connected to a project."""
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        repos = api.list_project_repositories(project_id)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if state.json_output:
        print_json(repos)
        return

    if not repos:
        print_info(f"No repositories connected to '{project}'.")
        return

    rows = [
        [r.get("provider", "—"), r.get("repo_full_name", "—"),
         r.get("default_branch", "—"), r.get("repo_url", "—")]
        for r in repos
    ]
    print_table(["Provider", "Repo", "Branch", "URL"], rows, title=f"Repos — {project}")


@app.command("connect")
def repos_connect(
    project: str = typer.Argument(..., help="Project ID or slug"),
    repo_url: Optional[str] = typer.Option(None, "--url", help="Repository URL"),
    branch: Optional[str] = typer.Option(None, "--branch", "-b", help="Deploy branch"),
    token: Optional[str] = typer.Option(None, "--token", help="Personal access token for private repos"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Connect a GitHub/GitLab/Bitbucket repository to a project."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    console.print(f"\n[bold {t.accent}]Connect a repository — {project}[/]\n")

    if not repo_url:
        repo_url = typer.prompt("  Repository URL (e.g. github.com/acme/api)")
    if not branch:
        branch = typer.prompt("  Deploy branch", default="main")

    # Parse the URL using the existing helper
    try:
        from zoro_cli.api import ZoroAPI
        # Parse inline — same logic as api-client.ts parseRepoInput
        parsed = _parse_repo_url(repo_url)
    except ValueError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if not token:
        is_private = typer.confirm("  Is this a private repository?", default=False)
        if is_private:
            token = typer.prompt("  Personal access token", hide_input=True)

    if not state.force:
        console.print(f"\n  [bold]Summary[/]")
        console.print(f"  [{t.muted}]Repo[/]     {parsed['repo_full_name']}")
        console.print(f"  [{t.muted}]Branch[/]   {branch}")
        console.print(f"  [{t.muted}]Provider[/] {parsed['provider']}")
        if not typer.confirm("\n  Connect this repository?", default=True):
            console.print("[dim]  Cancelled.[/]")
            raise typer.Exit(0)

    try:
        result = api.create_repository(
            project_id,
            {
                "provider": parsed["provider"],
                "repo_full_name": parsed["repo_full_name"],
                "repo_url": parsed["repo_url"],
                "default_branch": branch,
                **({"access_token": token} if token else {}),
            },
        )
    except APIError as exc:
        print_error(f"Failed to connect repository: {exc}")
        raise typer.Exit(1)

    print_success(f"Connected {parsed['repo_full_name']} → {project}  (branch: {branch})")


@app.command("disconnect")
def repos_disconnect(
    project: str = typer.Argument(..., help="Project ID or slug"),
    repo: str = typer.Argument(..., help="Repository full name or ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Disconnect a repository from a project."""
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        repos = api.list_project_repositories(project_id)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    target = next(
        (r for r in repos if r["id"] == repo or r.get("repo_full_name") == repo),
        None,
    )
    if not target:
        print_error(f"Repository '{repo}' not found in project '{project}'.")
        raise typer.Exit(1)

    name = target.get("repo_full_name", repo)
    if not state.force:
        if not typer.confirm(f"Disconnect '{name}' from '{project}'?", default=False):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    try:
        # Use the generic request method — no dedicated helper yet
        api.request("DELETE", f"/projects/{project_id}/repos/{target['id']}")
    except APIError as exc:
        print_error(f"Failed to disconnect: {exc}")
        raise typer.Exit(1)

    print_success(f"Disconnected '{name}' from '{project}'.")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _resolve_project(api, slug_or_id: str) -> str:
    """Return a project ID. Accepts either a UUID or a slug."""
    projects = api.list_projects()
    match = next(
        (p for p in projects if p["id"] == slug_or_id or p.get("slug") == slug_or_id),
        None,
    )
    if not match:
        raise APIError(f"Project '{slug_or_id}' not found.")
    return match["id"]


def _parse_repo_url(raw: str) -> dict:
    """Parse a GitHub/GitLab/Bitbucket URL or owner/repo string."""
    trimmed = raw.strip().rstrip("/").replace(".git", "")
    cleaned = trimmed.replace("https://", "").replace("http://", "")

    provider = (
        "gitlab" if "gitlab" in cleaned else
        "bitbucket" if "bitbucket" in cleaned else
        "github"
    )
    without_host = cleaned.replace("github.com/", "").replace("gitlab.com/", "").replace("bitbucket.org/", "")
    parts = [p for p in without_host.split("/") if p]
    if len(parts) < 2:
        raise ValueError(
            f"'{raw}' doesn't look like a valid repo. Use a URL or owner/repo — e.g. github.com/acme/api"
        )
    repo_full_name = f"{parts[0]}/{parts[1]}"
    host = {"gitlab": "gitlab.com", "bitbucket": "bitbucket.org"}.get(provider, "github.com")
    return {
        "provider": provider,
        "repo_full_name": repo_full_name,
        "repo_url": f"https://{host}/{repo_full_name}",
    }
