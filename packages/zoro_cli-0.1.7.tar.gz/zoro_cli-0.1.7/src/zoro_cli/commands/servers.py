from __future__ import annotations

import asyncio
import time
from typing import Optional

import typer
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import (
    console, get_theme, print_error, print_info, print_json,
    print_success, print_table, print_warning,
)
from zoro_cli.state import state

app = typer.Typer(no_args_is_help=True, help="Manage servers")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _status_dot(status: str, theme) -> str:
    s = status.lower()
    if s in ("connected", "ok", "healthy"):
        return f"[{theme.success}]●[/]"
    if s in ("disconnected", "error", "failed"):
        return f"[{theme.error}]●[/]"
    return f"[{theme.muted}]○[/]"


def _bar(pct: float, width: int = 10, theme=None) -> Text:
    filled = round(pct / 100 * width)
    t = theme
    bar = Text()
    color = t.success if pct < 70 else t.warning if pct < 90 else t.error
    bar.append("█" * filled, style=color)
    bar.append("░" * (width - filled), style=t.muted)
    bar.append(f" {pct:.0f}%", style=t.muted)
    return bar


def _metrics_panel(server_label: str, metrics: dict, elapsed: float, theme) -> Panel:
    t = theme
    cpu = metrics.get("cpu_percent", 0)
    ram_used = metrics.get("ram_used_mb", 0)
    ram_total = metrics.get("ram_total_mb", 1)
    disk_used = metrics.get("disk_used_gb", 0)
    disk_total = metrics.get("disk_total_gb", 1)
    ram_pct = ram_used / ram_total * 100 if ram_total else 0
    disk_pct = disk_used / disk_total * 100 if disk_total else 0

    body = Text()
    body.append(f"  CPU   ", style=t.muted)
    body.append_text(_bar(cpu, theme=t))
    body.append(f"\n  RAM   ", style=t.muted)
    body.append_text(_bar(ram_pct, theme=t))
    body.append(f"  {ram_used:.0f}/{ram_total:.0f} MB", style=t.muted)
    body.append(f"\n  DISK  ", style=t.muted)
    body.append_text(_bar(disk_pct, theme=t))
    body.append(f"  {disk_used:.1f}/{disk_total:.1f} GB", style=t.muted)

    mins, secs = divmod(int(elapsed), 60)
    body.append(f"\n\n  updated every 2s · elapsed {mins:02d}:{secs:02d}", style=t.muted)
    body.append(f"\n  [{t.muted}]Ctrl+C to exit[/]", style="")

    return Panel(
        body,
        title=f"[bold {t.accent}] {server_label} [/]",
        border_style=t.border,
        padding=(0, 1),
    )


# ── Commands ──────────────────────────────────────────────────────────────────

@app.command("list")
def servers_list(
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """List all servers with status and last-seen time."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        servers = api.list_servers()
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if state.json_output:
        print_json(servers)
        return

    if not servers:
        print_info("No servers yet.")
        return

    rows = []
    for s in servers:
        dot = _status_dot(s.get("status", "unknown"), t)
        rows.append([
            f"{dot} {s.get('label', s.get('name', '—'))}",
            s.get("ip_address", "—"),
            s.get("ssh_user", "—"),
            s.get("status", "unknown"),
            s.get("last_checked_at") or "never",
        ])
    print_table(["Server", "IP", "User", "Status", "Last Seen"], rows)


@app.command("status")
def servers_status(
    server: str = typer.Argument(..., help="Server ID or label"),
    once: bool = typer.Option(False, "--once", help="Show once and exit without live refresh"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Show live CPU / RAM / disk metrics. Refreshes every 2s until Ctrl+C."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        servers = api.list_servers()
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    # Resolve server by ID or label
    target = next(
        (s for s in servers if s["id"] == server or s.get("label", "").lower() == server.lower()),
        None,
    )
    if not target:
        print_error(f"Server '{server}' not found.")
        raise typer.Exit(1)

    server_id = target["id"]
    label = target.get("label", server_id)

    def _fetch() -> dict:
        try:
            metrics = api.list_server_metrics(server_id)
            return metrics[-1] if metrics else {}
        except APIError:
            return {}

    if once or state.json_output:
        metrics = _fetch()
        if state.json_output:
            print_json(metrics)
        else:
            console.print(_metrics_panel(label, metrics, 0, t))
        return

    start = time.monotonic()
    metrics = _fetch()
    try:
        with Live(
            _metrics_panel(label, metrics, 0, t),
            console=console,
            refresh_per_second=4,
        ) as live:
            while True:
                elapsed = time.monotonic() - start
                live.update(_metrics_panel(label, metrics, elapsed, t))
                time.sleep(2)
                metrics = _fetch()
    except KeyboardInterrupt:
        pass


@app.command("connect")
def servers_connect(
    name: Optional[str] = typer.Option(None, "--name", help="Server label"),
    ip: Optional[str] = typer.Option(None, "--ip", help="IP address or hostname"),
    port: int = typer.Option(22, "--port", help="SSH port"),
    user: Optional[str] = typer.Option(None, "--user", help="SSH username"),
    key_file: Optional[str] = typer.Option(None, "--key-file", help="Path to SSH private key file"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Interactively connect a new server via SSH credentials."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)

    console.print(f"\n[bold {t.accent}]Connect a server[/]\n")

    # Prompt for missing values
    if not name:
        name = typer.prompt("  Server label (e.g. prod-vps)")
    if not ip:
        ip = typer.prompt("  IP address or hostname")
    if not user:
        user = typer.prompt("  SSH username", default="root")

    # Auth method
    if not key_file:
        auth_choice = typer.prompt(
            "  Auth method  [1] paste private key  [2] key file path",
            default="1",
        )
        if auth_choice == "2":
            key_file = typer.prompt("  Key file path")

    ssh_private_key = ""
    if key_file:
        import os
        path = os.path.expanduser(key_file)
        if not os.path.exists(path):
            print_error(f"Key file not found: {path}")
            raise typer.Exit(1)
        with open(path) as f:
            ssh_private_key = f.read()
    else:
        console.print(f"  [{t.muted}]Paste your private key below, then press Enter twice:[/]")
        lines = []
        while True:
            line = input()
            if not line and lines and not lines[-1]:
                break
            lines.append(line)
        ssh_private_key = "\n".join(lines[:-1])

    if not ssh_private_key.strip():
        print_error("No SSH key provided.")
        raise typer.Exit(1)

    if not state.force:
        console.print(f"\n  [bold]Summary[/]")
        console.print(f"  [{t.muted}]Label[/]  {name}")
        console.print(f"  [{t.muted}]IP[/]     {ip}:{port}")
        console.print(f"  [{t.muted}]User[/]   {user}")
        if not typer.confirm("\n  Save this server?", default=True):
            console.print("[dim]  Cancelled.[/]")
            raise typer.Exit(0)

    print_info("Saving server…")
    try:
        from zoro_cli.api import ZoroAPI
        from zoro_cli.config import load_config
        cfg = load_config()
        server_data = api.create_server(
            project_id=None,
            payload={
                "label": name,
                "ip_address": ip,
                "ssh_port": port,
                "ssh_user": user,
                "auth_method": "key",
                "ssh_private_key": ssh_private_key,
            },
        )
    except APIError as exc:
        print_error(f"Failed to save server: {exc}")
        raise typer.Exit(1)

    print_success(f"Server '{name}' connected  (id: {server_data['id'][:8]}…)")
    print_info("Run: zoro servers status " + name)


@app.command("remove")
def servers_remove(
    server: str = typer.Argument(..., help="Server ID or label"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Remove a server from Zoro."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        servers = api.list_servers()
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    target = next(
        (s for s in servers if s["id"] == server or s.get("label", "").lower() == server.lower()),
        None,
    )
    if not target:
        print_error(f"Server '{server}' not found.")
        raise typer.Exit(1)

    label = target.get("label", target["id"])
    if not state.force:
        if not typer.confirm(
            f"Remove '{label}'? This disconnects it from all projects.",
            default=False,
        ):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    try:
        api.delete_server(target["id"])
    except APIError as exc:
        print_error(f"Failed to remove server: {exc}")
        raise typer.Exit(1)

    print_success(f"Server '{label}' removed.")
