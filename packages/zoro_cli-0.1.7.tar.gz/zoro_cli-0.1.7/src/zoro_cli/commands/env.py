from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import typer

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import console, get_theme, print_error, print_info, print_json, print_success, print_warning
from zoro_cli.state import state

app = typer.Typer(no_args_is_help=True, help="Manage environment variables")


def _resolve_project(api, slug_or_id: str) -> str:
    projects = api.list_projects()
    match = next(
        (p for p in projects if p["id"] == slug_or_id or p.get("slug") == slug_or_id),
        None,
    )
    if not match:
        raise APIError(f"Project '{slug_or_id}' not found.")
    return match["id"]


def _resolve_env(api, project_id: str, env_name: str) -> str:
    envs = api.list_environments(project_id)
    match = next(
        (e for e in envs if e["id"] == env_name or e.get("name", "").lower() == env_name.lower()),
        None,
    )
    if not match:
        raise APIError(f"Environment '{env_name}' not found.")
    return match["id"]


def _mask(value: str) -> str:
    return "••••••••"


@app.command("list")
def env_list(
    project: str = typer.Argument(..., help="Project slug or ID"),
    env: str = typer.Option("production", "--env", "-e"),
    reveal: bool = typer.Option(False, "--reveal", help="Show actual values (prompts for confirmation)"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """List environment variables. Values are masked by default."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
        vars_ = api.request("GET", f"/projects/{project_id}/environments/{env_id}/env-vars")
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if reveal and not state.force:
        if not typer.confirm("Show actual secret values?", default=False):
            reveal = False

    if state.json_output:
        if not reveal:
            for v in vars_:
                if v.get("is_secret"):
                    v["value"] = "••••••••"
        print_json(vars_)
        return

    if not vars_:
        print_info(f"No env vars for {project}/{env}.")
        return

    from rich.table import Table
    from rich import box
    table = Table(box=box.SIMPLE, header_style=f"bold {t.accent}")
    table.add_column("Key")
    table.add_column("Value")
    table.add_column("Secret")
    table.add_column("Updated")

    for v in vars_:
        key = v.get("key", "")
        value = v.get("value", "")
        is_secret = v.get("is_secret", False)
        updated = v.get("updated_at", "")[:10]

        display_value = value if (reveal or not is_secret) else _mask(value)
        secret_marker = f"[{t.warning}]yes[/]" if is_secret else f"[{t.muted}]no[/]"
        table.add_row(f"[bold]{key}[/]", display_value, secret_marker, f"[{t.muted}]{updated}[/]")

    console.print(table)


@app.command("set")
def env_set(
    project: str = typer.Argument(..., help="Project slug or ID"),
    kv: str = typer.Argument(..., help="KEY=VALUE"),
    env: str = typer.Option("production", "--env", "-e"),
    secret: bool = typer.Option(False, "--secret", help="Mark as secret (masked in logs)"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Set a single environment variable.

    \b
    Examples:
      zoro env set myapp DEBUG=false
      zoro env set myapp DATABASE_URL=postgres://... --secret
    """
    if "=" not in kv:
        print_error("Format must be KEY=VALUE")
        raise typer.Exit(1)
    key, _, value = kv.partition("=")
    key = key.strip()

    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if not state.force:
        display = _mask(value) if secret else value
        if not typer.confirm(f"Set {key}={display} in {project}/{env}?", default=True):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    try:
        api.request("POST", f"/projects/{project_id}/environments/{env_id}/env-vars", json_body={
            "key": key, "value": value, "is_secret": secret,
        })
    except APIError as exc:
        print_error(f"Failed to set {key}: {exc}")
        raise typer.Exit(1)

    print_success(f"{key} set in {project}/{env}")


@app.command("delete")
def env_delete(
    project: str = typer.Argument(..., help="Project slug or ID"),
    key: str = typer.Argument(..., help="Variable key to delete"),
    env: str = typer.Option("production", "--env", "-e"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Delete an environment variable."""
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if not state.force:
        if not typer.confirm(f"Delete {key} from {project}/{env}?", default=False):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    try:
        api.request("DELETE", f"/projects/{project_id}/environments/{env_id}/env-vars/{key}")
    except APIError as exc:
        print_error(f"Failed to delete {key}: {exc}")
        raise typer.Exit(1)

    print_success(f"{key} deleted from {project}/{env}")


@app.command("pull")
def env_pull(
    project: str = typer.Argument(..., help="Project slug or ID"),
    env: str = typer.Option("production", "--env", "-e"),
    output: str = typer.Option(".env", "--output", "-o", help="Output file path"),
    reveal: bool = typer.Option(False, "--reveal", help="Include actual secret values"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Download environment variables to a .env file."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
        vars_ = api.request("GET", f"/projects/{project_id}/environments/{env_id}/env-vars")
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    out_path = Path(output)
    if out_path.exists() and not state.force:
        if not typer.confirm(f"Overwrite {output}?", default=False):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    lines = [f"# {project}/{env} — pulled by zoro\n"]
    for v in vars_:
        key = v.get("key", "")
        value = v.get("value", "")
        is_secret = v.get("is_secret", False)
        display = value if (reveal or not is_secret) else "# <secret — run with --reveal to include>"
        lines.append(f"{key}={display}\n")

    out_path.write_text("".join(lines))
    print_success(f"Wrote {len(vars_)} vars to {output}")


@app.command("push")
def env_push(
    project: str = typer.Argument(..., help="Project slug or ID"),
    env: str = typer.Option("production", "--env", "-e"),
    file: str = typer.Option(".env", "--file", "-f", help="Input .env file"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Upload a .env file and apply the changes with a diff preview."""
    t = get_theme()
    in_path = Path(file)
    if not in_path.exists():
        print_error(f"File not found: {file}")
        raise typer.Exit(1)

    # Parse the local file
    local: dict[str, str] = {}
    for line in in_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        local[key.strip()] = value.strip()

    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        env_id = _resolve_env(api, project_id, env)
        remote_list = api.request("GET", f"/projects/{project_id}/environments/{env_id}/env-vars")
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    remote: dict[str, str] = {v["key"]: v["value"] for v in remote_list}

    # Build diff
    added = {k: v for k, v in local.items() if k not in remote}
    changed = {k: v for k, v in local.items() if k in remote and remote[k] != v}
    removed = {k for k in remote if k not in local}

    if not added and not changed and not removed:
        print_info("No changes — remote is already up to date.")
        return

    # Show diff
    console.print(f"\n[bold {t.accent}]Changes to apply → {project}/{env}[/]\n")
    for k, v in added.items():
        console.print(f"  [{t.success}]+[/] {k}={v}")
    for k, v in changed.items():
        console.print(f"  [{t.warning}]~[/] {k}  [{t.muted}]{remote[k][:20]}… → {v[:20]}…[/]")
    for k in removed:
        console.print(f"  [{t.error}]-[/] {k}")
    console.print()

    if not state.force:
        if not typer.confirm("Apply these changes?", default=False):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    # Apply — upsert added/changed, delete removed
    errors: list[str] = []
    for key, value in {**added, **changed}.items():
        try:
            api.request("POST", f"/projects/{project_id}/environments/{env_id}/env-vars",
                        json_body={"key": key, "value": value})
        except APIError as exc:
            errors.append(f"{key}: {exc}")

    for key in removed:
        try:
            api.request("DELETE", f"/projects/{project_id}/environments/{env_id}/env-vars/{key}")
        except APIError as exc:
            errors.append(f"{key}: {exc}")

    if errors:
        for e in errors:
            print_warning(f"  {e}")
        print_error(f"{len(errors)} var(s) failed to apply.")
        raise typer.Exit(1)

    total = len(added) + len(changed) + len(removed)
    print_success(f"Applied {total} change(s) to {project}/{env}")
