from __future__ import annotations

import typer

from zoro_cli.config import CLIConfig, CONFIG_PATH, load_config, save_config
from zoro_cli.output import THEME_NAMES, THEMES, console, get_theme, print_error, print_success

app = typer.Typer(help="Read and write local CLI configuration")

_SETTABLE = {
    "api-url":             "api_url",
    "default-project":     "default_project",
    "default-environment": "default_environment",
}

_READONLY = {"access-token", "refresh-token", "user-email"}


@app.command("list")
def config_list() -> None:
    """Show the current CLI configuration (token masked)."""
    t = get_theme()
    config = load_config()
    rows = [
        ("api_url",      config.api_url),
        ("theme",        config.theme),
        ("user_email",   config.user_email or "(not set)"),
        ("access_token", _mask(config.access_token)),
        ("config_file",  str(CONFIG_PATH)),
    ]
    for key, value in rows:
        console.print(f"  [{t.muted}]{key:<20}[/]  [{t.accent}]{value}[/]")


@app.command("get")
def config_get(key: str = typer.Argument(..., help="Config key")) -> None:
    """Print the value of a single config key."""
    config = load_config()
    field = _SETTABLE.get(key)
    if not field:
        print_error(f"Unknown key '{key}'.", hint=f"Keys: {', '.join(_SETTABLE)}")
        raise typer.Exit(1)
    console.print(getattr(config, field, "") or "(not set)")


@app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key"),
    value: str = typer.Argument(..., help="Value"),
) -> None:
    """Set a config value.

    \b
    Keys:
      api-url              Backend base URL
      default-project      Default project slug
      default-environment  Default environment (default: production)
    """
    if key in _READONLY:
        print_error(f"'{key}' is read-only — set automatically by `zoro login`.")
        raise typer.Exit(1)
    field = _SETTABLE.get(key)
    if not field:
        print_error(f"Unknown key '{key}'.", hint=f"Keys: {', '.join(_SETTABLE)}")
        raise typer.Exit(1)
    config = load_config()
    setattr(config, field, value)
    save_config(config)
    print_success(f"{key} = {value}")


@app.command("theme")
def config_theme() -> None:
    """Interactively pick a colour theme."""
    from rich.text import Text
    from rich import box
    from rich.table import Table

    current = load_config().theme

    console.print()

    # Build a numbered preview table
    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 1))
    table.add_column(width=3,  justify="right")
    table.add_column(width=14)
    table.add_column(width=26)

    for i, name in enumerate(THEME_NAMES, 1):
        t = THEMES[name]
        marker = "●" if name == current else " "

        # Colour swatch: show the accent, success, error, warning in their own colours
        swatch = Text()
        swatch.append("██", style=t.accent)
        swatch.append(" ")
        swatch.append("██", style=t.success)
        swatch.append(" ")
        swatch.append("██", style=t.error)
        swatch.append(" ")
        swatch.append("██", style=t.warning)

        label = Text()
        label.append(f"[{marker}] ", style=t.muted if marker == " " else t.accent)
        label.append(name, style=f"bold {t.accent}" if name == current else "")

        table.add_row(str(i), label, swatch)

    console.print(table)
    console.print()

    try:
        raw = typer.prompt(f"  Pick a theme [1-{len(THEME_NAMES)}] or Enter to keep '{current}'",
                           default="", show_default=False)
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]  Cancelled.[/]")
        raise typer.Exit(0)

    if not raw.strip():
        console.print(f"[dim]  Keeping '{current}'.[/]")
        raise typer.Exit(0)

    try:
        idx = int(raw.strip()) - 1
        if not (0 <= idx < len(THEME_NAMES)):
            raise ValueError
    except ValueError:
        print_error(f"Invalid choice '{raw}'. Enter a number 1–{len(THEME_NAMES)}.")
        raise typer.Exit(1)

    chosen = THEME_NAMES[idx]
    config = load_config()
    config.theme = chosen
    save_config(config)

    t = THEMES[chosen]
    console.print()
    console.print(Text.from_markup(
        f"  [{t.accent}]●[/]  Theme set to [{t.accent}]{chosen}[/]  "
        f"[{t.muted}]— takes effect immediately[/]"
    ))
    console.print()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _mask(value: str) -> str:
    if not value:
        return "(not set)"
    if len(value) <= 8:
        return "••••••••"
    return value[:6] + "••••" + value[-4:]
