from __future__ import annotations

import asyncio
import time
from typing import Optional

import typer
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from zoro_cli.api import APIError
from zoro_cli.auth import build_api
from zoro_cli.output import console, get_theme, print_error, print_info, print_json, print_success, print_warning
from zoro_cli.state import state

app = typer.Typer(no_args_is_help=True, help="Security scanning and findings")

_SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"]

_SEVERITY_STYLES = {
    "critical": "bold red",
    "high":     "red",
    "medium":   "yellow",
    "low":      "cyan",
    "info":     "dim",
}


def _resolve_project(api, slug_or_id: str) -> str:
    projects = api.list_projects()
    match = next(
        (p for p in projects if p["id"] == slug_or_id or p.get("slug") == slug_or_id),
        None,
    )
    if not match:
        raise APIError(f"Project '{slug_or_id}' not found.")
    return match["id"]


def _severity_badge(severity: str, theme) -> str:
    style = _SEVERITY_STYLES.get(severity.lower(), "")
    label = severity.upper()
    return f"[{style}]{label}[/]" if style else label


def _scan_summary_panel(scan: dict, elapsed: float, theme) -> Panel:
    t = theme
    status = scan.get("status", "running")
    steps = scan.get("steps", [])

    body = Text()
    for step in steps:
        s = step.get("status", "pending")
        name = step.get("name", "")
        if s == "done":
            icon = f"[{t.success}]✓[/]"
        elif s == "running":
            icon = f"[{t.warning}]●[/]"
        elif s == "failed":
            icon = f"[{t.error}]✗[/]"
        else:
            icon = f"[{t.muted}]○[/]"
        body.append_text(Text.from_markup(f"  {icon} {name}\n"))

    if status == "running":
        mins, secs = divmod(int(elapsed), 60)
        body.append(f"\n  elapsed {mins:02d}:{secs:02d}  ·  Ctrl+C to detach", style=t.muted)

    color = (
        t.error if status == "failed"
        else t.success if status == "done"
        else t.warning
    )
    title = f"[bold {color}] Security Scan — {status.upper()} [/]"
    return Panel(body, title=title, border_style=t.border, padding=(0, 1))


@app.command("scan")
def security_scan(
    project: str = typer.Argument(..., help="Project slug or ID"),
    wait: bool = typer.Option(False, "--wait", "-w", help="Wait for scan to complete with live progress"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Trigger a security scan.

    \b
    Examples:
      zoro security scan myapp
      zoro security scan myapp --wait
    """
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    try:
        scan = api.request("POST", f"/projects/{project_id}/security/scans")
    except APIError as exc:
        print_error(f"Failed to start scan: {exc}")
        raise typer.Exit(1)

    scan_id = scan.get("id", "")
    print_info(f"Scan started  (id: {scan_id[:8]}…)")

    if state.json_output:
        print_json(scan)
        return

    if not wait:
        console.print(
            f"  [{t.muted}]Run[/] [bold]zoro security status {project}[/] [dim]to check progress[/]"
        )
        return

    # Live progress loop
    start = time.monotonic()
    try:
        with Live(console=console, refresh_per_second=4) as live:
            while True:
                elapsed = time.monotonic() - start
                try:
                    scan = api.request("GET", f"/projects/{project_id}/security/scans/{scan_id}")
                except APIError:
                    pass
                live.update(_scan_summary_panel(scan, elapsed, t))
                status = scan.get("status", "running")
                if status in ("done", "failed", "cancelled"):
                    break
                time.sleep(2)
    except KeyboardInterrupt:
        console.print(f"\n[{t.muted}]  Detached — scan continues in the background.[/]")
        return

    status = scan.get("status", "")
    findings_count = scan.get("findings_count", 0)
    if status == "done":
        if findings_count:
            print_warning(f"Scan complete — {findings_count} finding(s). Run: zoro security findings {project}")
        else:
            print_success("Scan complete — no findings.")
    else:
        print_error(f"Scan {status}.")
        raise typer.Exit(1)


@app.command("status")
def security_status(
    project: str = typer.Argument(..., help="Project slug or ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """Show the latest security scan status."""
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        scans = api.request("GET", f"/projects/{project_id}/security/scans")
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if not scans:
        print_info(f"No scans run yet for '{project}'. Run: zoro security scan {project}")
        return

    latest = scans[0] if isinstance(scans, list) else scans

    if state.json_output:
        print_json(latest)
        return

    status = latest.get("status", "unknown")
    scan_id = latest.get("id", "")[:8]
    started = latest.get("started_at", "")[:19].replace("T", " ")
    finished = latest.get("finished_at", "")[:19].replace("T", " ") or "—"
    findings = latest.get("findings_count", "—")

    color = (
        t.error if status == "failed"
        else t.success if status == "done"
        else t.warning
    )

    console.print(f"\n  [{t.muted}]Scan ID[/]   {scan_id}…")
    console.print(f"  [{t.muted}]Status[/]    [{color}]{status.upper()}[/]")
    console.print(f"  [{t.muted}]Started[/]   {started}")
    console.print(f"  [{t.muted}]Finished[/]  {finished}")
    console.print(f"  [{t.muted}]Findings[/]  {findings}\n")


@app.command("findings")
def security_findings(
    project: str = typer.Argument(..., help="Project slug or ID"),
    severity: Optional[str] = typer.Option(None, "--severity", "-s", help="Filter: critical, high, medium, low, info"),
    api_url: Optional[str] = typer.Option(None, "--api-url"),
) -> None:
    """List security findings from the latest scan.

    \b
    Examples:
      zoro security findings myapp
      zoro security findings myapp --severity high
    """
    t = get_theme()
    try:
        api, _ = build_api(api_url=api_url)
        project_id = _resolve_project(api, project)
        findings = api.request("GET", f"/projects/{project_id}/security/findings")
    except RuntimeError as exc:
        print_error(str(exc), hint="Run: zoro login --token <your-token>")
        raise typer.Exit(1)
    except APIError as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if severity:
        findings = [f for f in findings if f.get("severity", "").lower() == severity.lower()]

    if state.json_output:
        print_json(findings)
        return

    if not findings:
        msg = f"No findings" + (f" at severity '{severity}'" if severity else "") + f" for '{project}'."
        print_info(msg)
        return

    # Sort by severity order
    findings.sort(key=lambda f: _SEVERITY_ORDER.index(f.get("severity", "info").lower())
                  if f.get("severity", "info").lower() in _SEVERITY_ORDER else 99)

    table = Table(box=box.SIMPLE, header_style=f"bold {t.accent}")
    table.add_column("Severity")
    table.add_column("Title")
    table.add_column("Location")
    table.add_column("Rule")

    for f in findings:
        sev = f.get("severity", "info")
        badge = _severity_badge(sev, t)
        title = f.get("title", f.get("description", ""))
        location = f.get("location", f.get("file", "—"))
        rule = f.get("rule_id", f.get("rule", "—"))
        table.add_row(badge, title, f"[{t.muted}]{location}[/]", f"[{t.muted}]{rule}[/]")

    total = len(findings)
    console.print(f"\n[bold {t.accent}]Findings — {project}[/]  [{t.muted}]({total} total)[/]\n")
    console.print(table)
