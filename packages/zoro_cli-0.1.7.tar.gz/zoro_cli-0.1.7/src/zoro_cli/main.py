from __future__ import annotations

import json
import sys
from typing import Optional

import typer

from zoro_cli import __version__
from zoro_cli.api import APIError
from zoro_cli.auth import build_api, login_and_store, login_with_token
from zoro_cli.config import DEFAULT_API_URL, clear_config, load_config
from zoro_cli.state import state

from zoro_cli.commands.deploy import app as _deploy_run_app
from zoro_cli.commands.chat import app as _chat_app
from zoro_cli.commands.config_cmd import app as _config_app
from zoro_cli.commands.servers import app as _servers_app
from zoro_cli.commands.repos import app as _repos_app
from zoro_cli.commands.logs import app as _logs_app
from zoro_cli.commands.env import app as _env_app
from zoro_cli.commands.secrets import app as _secrets_app
from zoro_cli.commands.security import app as _security_app

app = typer.Typer(
    no_args_is_help=True,
    help="Zoro command-line interface",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(__version__)
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def _global_options(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-V", callback=_version_callback, is_eager=True, help="Show the installed CLI version and exit."),
    json_flag: bool = typer.Option(False, "--json", help="Output raw JSON, no formatting", is_eager=False),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompts", is_eager=False),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress all output except errors", is_eager=False),
    debug: bool = typer.Option(False, "--debug", help="Print HTTP request/response details", is_eager=False),
) -> None:
    state.json_output = json_flag
    state.force = force
    state.quiet = quiet
    state.debug = debug
    if ctx.invoked_subcommand is None:
        _show_dashboard()
deploy_app = typer.Typer(no_args_is_help=True, help="Deployment plan and execution commands")
projects_app = typer.Typer(no_args_is_help=True, help="Project commands")
servers_app = typer.Typer(no_args_is_help=True, help="Server commands")
envs_app = typer.Typer(no_args_is_help=True, help="Environment commands")
app.add_typer(deploy_app, name="deploy")
app.add_typer(projects_app, name="projects")
app.add_typer(_servers_app, name="servers")
app.add_typer(envs_app, name="envs")

# Rich-based live commands
deploy_app.add_typer(_deploy_run_app, name="go", help="Deploy with live log streaming (rich.Live)")
deploy_app.add_typer(_logs_app, name="logs", help="Fetch and stream deployment logs")
app.add_typer(_chat_app, name="chat", help="Interactive agent chat session")
app.add_typer(_config_app, name="config", help="Read and write local CLI configuration")
app.add_typer(_repos_app, name="repos", help="Manage repository connections")
app.add_typer(_env_app, name="env", help="Manage environment variables")
app.add_typer(_secrets_app, name="secrets", help="Manage project secrets")
app.add_typer(_security_app, name="security", help="Security scanning and findings")


def _print_json(data) -> None:
    typer.echo(json.dumps(data, indent=2))


def _handle_api_error(exc: APIError) -> None:
    typer.echo(f"Error: {exc}", err=True)
    raise typer.Exit(code=1)


def launch_tui(api_url: str | None = None) -> None:
    try:
        from zoro_cli.tui import ZoroTerminalApp
    except ModuleNotFoundError as exc:  # pragma: no cover - depends on optional install state
        if exc.name == "textual":
            typer.echo(
                "Textual is not installed in this environment. Reinstall the CLI package to get the TUI.",
                err=True,
            )
            raise typer.Exit(code=1) from exc
        raise
    ZoroTerminalApp(api_url=api_url).run()


@app.command()
def login(
    api_url: str = typer.Option(DEFAULT_API_URL, "--api-url"),
    token: str = typer.Option("", "--token", "-t", help="API token copied from the web UI (Settings → API Keys)."),
    email: str = typer.Option("", "--email", "-e"),
    password: str = typer.Option("", "--password", "-p", hide_input=True),
) -> None:
    """Authenticate against the Zoro API.

    Preferred: copy an API token from the web UI (Settings → API Keys) and run:

      zoro login --token <your-token>

    Alternatively use email + password (you will be prompted if omitted):

      zoro login --email you@example.com
    """
    try:
        if token:
            me = login_with_token(api_url=api_url, token=token)
            typer.echo(f"Logged in as {me.get('email', '(unknown)')}")
        else:
            # Fall back to email / password prompt
            if not email:
                email = typer.prompt("Email")
            if not password:
                password = typer.prompt("Password", hide_input=True)
            data = login_and_store(api_url=api_url, email=email, password=password)
            typer.echo(f"Logged in as {data['user']['email']}")
    except APIError as exc:
        _handle_api_error(exc)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)


@app.command()
def ui(api_url: str | None = typer.Option(None, "--api-url")) -> None:
    """Launch the interactive terminal UI."""
    launch_tui(api_url=api_url)


@app.command()
def logout() -> None:
    """Clear local CLI credentials."""
    clear_config()
    typer.echo("Logged out")


@app.command()
def whoami(api_url: str | None = typer.Option(None, "--api-url")) -> None:
    """Show the authenticated user."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        _print_json(api.whoami())
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)


@app.command("config")
def show_config() -> None:
    """Show the current local CLI configuration."""
    config = load_config()
    _print_json(
        {
            "api_url": config.api_url,
            "user_email": config.user_email,
            "has_access_token": bool(config.access_token),
            "has_refresh_token": bool(config.refresh_token),
        }
    )


@projects_app.command("list")
def projects_list(api_url: str | None = typer.Option(None, "--api-url")) -> None:
    """List projects visible to the authenticated user."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        _print_json(api.list_projects())
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)


@servers_app.command("list")
def servers_list(api_url: str | None = typer.Option(None, "--api-url")) -> None:
    """List saved servers."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        _print_json(api.list_servers())
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)


@envs_app.command("list")
def envs_list(
    project_id: str = typer.Option(..., "--project-id"),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """List environments for a project."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        _print_json(api.list_environments(project_id))
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)


@deploy_app.command("plan")
def deploy_plan(
    project_id: str = typer.Option(..., "--project-id"),
    environment_id: str = typer.Option(..., "--environment-id"),
    branch: str = typer.Option(..., "--branch"),
    method: str = typer.Option("system", "--method"),
    commit_sha: str = typer.Option("", "--commit-sha"),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """Create a deployment plan without starting deployment."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        data = api.create_deployment_plan(
            project_id=project_id,
            environment_id=environment_id,
            branch=branch,
            deploy_method=method,
            commit_sha=commit_sha,
        )
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)

    typer.echo(data["plan_text"])
    typer.echo("")
    typer.echo(f"Deployment ID: {data['deployment_id']}")
    typer.echo(f"Plan ID: {data['plan_id']}")


@deploy_app.command("show")
def deploy_show(
    deployment_id: str = typer.Argument(...),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """Show a stored deployment plan."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        data = api.get_deployment_plan(deployment_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)

    typer.echo(data["plan_text"])


@deploy_app.command("approve")
def deploy_approve(
    deployment_id: str = typer.Argument(...),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """Approve and queue a deployment plan."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        data = api.approve_deployment(deployment_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)

    _print_json(data)


@deploy_app.command("cancel")
def deploy_cancel(
    deployment_id: str = typer.Argument(...),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """Cancel a deployment."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        data = api.cancel_deployment(deployment_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)

    _print_json(data)


@deploy_app.command("logs")
def deploy_logs(
    deployment_id: str = typer.Argument(...),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """Show deployment logs."""
    try:
        api, _ = build_api(api_url=api_url, require_auth=True)
        logs = api.get_deployment_logs(deployment_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    except APIError as exc:
        _handle_api_error(exc)

    if not logs:
        typer.echo("No logs yet")
        return

    for item in logs:
        typer.echo(f"[{item['timestamp']}] {item['level'].upper()}: {item['message']}")


def _show_dashboard() -> None:
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from zoro_cli.output import console, get_theme
    from zoro_cli import __version__

    t = get_theme()
    cfg = load_config()

    # ── Fetch data best-effort ────────────────────────────────────────────────
    projects, servers, recent_deployments = [], [], []
    api_warning = ""
    if cfg.access_token:
        try:
            from zoro_cli.api import ZoroAPI
            api = ZoroAPI(api_url=cfg.api_url, access_token=cfg.access_token)
            try:
                projects = api.list_projects()
            except APIError as exc:
                api_warning = str(exc)
            try:
                servers = api.list_servers()
            except APIError as exc:
                api_warning = api_warning or str(exc)
            try:
                raw = api.request("GET", "/deployments/?limit=5")
                recent_deployments = raw if isinstance(raw, list) else raw.get("results", [])
            except APIError as exc:
                api_warning = api_warning or str(exc)
        except APIError as exc:
            api_warning = str(exc)

    # ── Left panel ────────────────────────────────────────────────────────────
    name = (cfg.user_email or "").split("@")[0] if cfg.user_email else ""
    left = Text()
    left.append("\n")
    left.append("  Welcome back", style="bold")
    left.append(f" {name}!\n" if name else "!\n", style=f"bold {t.accent}" if name else "bold")
    left.append("\n")

    # Brand Z mark
    left.append("   ████████\n", style=t.accent)
    left.append("       ██\n",   style=t.accent)
    left.append("     ██\n",     style=t.accent)
    left.append("   ████████\n", style=t.accent)
    left.append("\n")

    if cfg.user_email:
        left.append(f"  {cfg.user_email}\n", style=t.muted)
    if projects:
        left.append(f"  {len(projects)} project{'s' if len(projects) != 1 else ''}", style=t.muted)
        if servers:
            left.append(f"  ·  {len(servers)} server{'s' if len(servers) != 1 else ''}", style=t.muted)
        left.append("\n")
    elif not cfg.access_token:
        left.append("  Not logged in\n", style=t.error)

    # ── Right panel ───────────────────────────────────────────────────────────
    right = Text()

    if not cfg.access_token:
        right.append("Get started\n", style=f"bold {t.accent}")
        right.append("─" * 28 + "\n", style=t.muted)
        right.append("Log in with an API token:\n\n", style=t.muted)
        right.append("  zoro login --token <token>\n", style="bold")
        right.append("\nCopy your token from\n", style=t.muted)
        right.append("Settings → API Keys\n", style=t.muted)
    else:
        right.append("Recent deployments\n", style=f"bold {t.accent}")
        right.append("─" * 28 + "\n", style=t.muted)
        if recent_deployments:
            for d in recent_deployments[:5]:
                status = d.get("status", "")
                if status in ("success", "completed"):
                    icon, style = "✓", t.success
                elif status in ("failed", "error"):
                    icon, style = "✗", t.error
                elif status in ("running", "in_progress"):
                    icon, style = "●", t.warning
                else:
                    icon, style = "○", t.muted
                proj = d.get("project_name", d.get("project", {}).get("name", "—"))
                branch = d.get("branch", "")
                ts = d.get("created_at", "")[:10]
                right.append(f"{icon} ", style=style)
                right.append(f"{proj}", style="bold")
                if branch:
                    right.append(f"  {branch}", style=t.muted)
                right.append(f"  {ts}\n", style=t.muted)
        else:
            right.append("No recent deployments\n", style=t.muted)

        right.append("\n")
        right.append("Quick commands\n", style=f"bold {t.accent}")
        right.append("─" * 28 + "\n", style=t.muted)
        cmds = [
            ("zoro chat start", "talk to the agent"),
            ("zoro deploy go <app>", "deploy an app"),
            ("zoro env list <app>", "view env vars"),
            ("zoro --help", "all commands"),
        ]
        for cmd, desc in cmds:
            right.append(cmd, style="bold")
            right.append(f"  {desc}\n", style=t.muted)

        if api_warning:
            right.append("\n")
            right.append("Connection\n", style=f"bold {t.accent}")
            right.append("─" * 28 + "\n", style=t.muted)
            right.append(f"{api_warning}\n", style=t.error)
            right.append(f"Current API URL: {cfg.api_url}\n", style=t.muted)
            right.append("Run zoro config to inspect saved settings.\n", style=t.muted)

    # ── Assemble two-column layout ────────────────────────────────────────────
    grid = Table.grid(padding=(0, 3))
    grid.add_column(min_width=30)
    grid.add_column(min_width=36)
    grid.add_row(left, right)

    version = getattr(__import__("zoro_cli"), "__version__", "")
    title = f"[bold {t.accent}] zoro [/]" + (f"[{t.muted}]v{version}[/]" if version else "")
    console.print()
    console.print(Panel(grid, title=title, border_style=t.accent, padding=(0, 1)))
    console.print()

def run() -> None:
    if len(sys.argv) == 1:
        try:
            _show_dashboard()
        except typer.Exit as exc:
            raise SystemExit(exc.exit_code or 0) from exc
        return
    app()


if __name__ == "__main__":
    run()
