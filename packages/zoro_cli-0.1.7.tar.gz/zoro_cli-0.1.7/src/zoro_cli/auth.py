from __future__ import annotations

from zoro_cli.api import ZoroAPI
from zoro_cli.config import CLIConfig, load_config, save_config


def build_api(api_url: str | None = None, require_auth: bool = True) -> tuple[ZoroAPI, CLIConfig]:
    config = load_config()
    effective_url = (api_url or config.api_url).rstrip("/")
    if require_auth and not config.access_token:
        raise RuntimeError("You are not logged in. Run `zoro login` first.")
    return ZoroAPI(api_url=effective_url, access_token=config.access_token), config


def login_and_store(api_url: str, email: str, password: str) -> dict:
    api = ZoroAPI(api_url=api_url)
    data = api.login(email=email, password=password)
    config = CLIConfig(
        api_url=api_url.rstrip("/"),
        access_token=data["access"],
        refresh_token=data["refresh"],
        user_email=data["user"]["email"],
    )
    save_config(config)
    return data


def login_with_token(api_url: str, token: str) -> dict:
    """Store an API token copied from the web UI.  Calls /users/me to verify it."""
    api = ZoroAPI(api_url=api_url.rstrip("/"), access_token=token)
    me = api.whoami()
    email = me.get("email", "")
    config = CLIConfig(
        api_url=api_url.rstrip("/"),
        access_token=token,
        refresh_token="",
        user_email=email,
    )
    save_config(config)
    return me
