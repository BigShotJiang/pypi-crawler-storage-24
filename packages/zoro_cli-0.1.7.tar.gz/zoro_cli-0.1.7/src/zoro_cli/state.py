"""Shared mutable state set by the top-level Typer callback.

Import `state` and read `state.json_output`, `state.force`, etc. from any
command without needing to thread the flags through every function signature.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class GlobalState:
    json_output: bool = False   # --json : raw JSON, no Rich
    force: bool = False          # --force / -f : skip confirmations
    quiet: bool = False          # --quiet / -q : suppress non-error output
    debug: bool = False          # --debug : print HTTP requests/responses


state = GlobalState()
