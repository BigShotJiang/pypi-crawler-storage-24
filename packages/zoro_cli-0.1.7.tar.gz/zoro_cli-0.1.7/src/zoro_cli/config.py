from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path


DEFAULT_API_URL = os.environ.get("ZORO_API_URL", "https://api.zoro.algohub.cc/api/v1")


def _config_dir() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "zoro"
    return Path.home() / ".config" / "zoro"


CONFIG_DIR = _config_dir()
CONFIG_PATH = CONFIG_DIR / "config.json"


@dataclass
class CLIConfig:
    api_url: str = DEFAULT_API_URL
    access_token: str = ""
    refresh_token: str = ""
    user_email: str = ""
    theme: str = "dark"          # "dark" or "light" — auto-detected if unset
    default_project: str = ""
    default_environment: str = "production"


def load_config() -> CLIConfig:
    if not CONFIG_PATH.exists():
        return CLIConfig()

    data = json.loads(CONFIG_PATH.read_text())
    return CLIConfig(
        api_url=data.get("api_url", DEFAULT_API_URL),
        access_token=data.get("access_token", ""),
        refresh_token=data.get("refresh_token", ""),
        user_email=data.get("user_email", ""),
        theme=data.get("theme", "dark"),
        default_project=data.get("default_project", ""),
        default_environment=data.get("default_environment", "production"),
    )


def save_config(config: CLIConfig) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(asdict(config), indent=2) + "\n")


def clear_config() -> None:
    if CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
