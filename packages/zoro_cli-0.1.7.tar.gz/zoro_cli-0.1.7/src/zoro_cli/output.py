from __future__ import annotations

import json as _json
import sys
from dataclasses import dataclass

from rich import box
from rich.console import Console
from rich.table import Table
from rich.text import Text


# ── Themes ────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ColorTheme:
    accent: str       # brand / primary
    user_label: str   # "you" label color
    muted: str        # timestamps, hints
    success: str
    error: str
    warning: str
    info: str
    tool: str         # tool call chips
    border: str       # active panel border
    dim_border: str   # inactive panel border


THEMES: dict[str, ColorTheme] = {
    # ── Dark (default — Zoro amber gold, matches web app --accent) ────────────
    "dark": ColorTheme(
        accent="#c4975a",
        user_label="#6ea8d4",
        muted="#6b6b6b",
        success="#4a9e6b",
        error="#b85c5c",
        warning="#c49a3c",
        info="#5a85b0",
        tool="#a07840",
        border="#c4975a",
        dim_border="#3a2a14",
    ),
    "dark-blue": ColorTheme(
        accent="#5a8fc4",
        user_label="#6ea8d4",
        muted="#6b6b6b",
        success="#4a9e6b",
        error="#b85c5c",
        warning="#c49a3c",
        info="#5a8fc4",
        tool="#a07840",
        border="#5a8fc4",
        dim_border="#1a2a3a",
    ),
    "dark-green": ColorTheme(
        accent="#4a9e6b",
        user_label="#6ea8d4",
        muted="#6b6b6b",
        success="#4a9e6b",
        error="#b85c5c",
        warning="#c49a3c",
        info="#5a85b0",
        tool="#a07840",
        border="#4a9e6b",
        dim_border="#1a3a28",
    ),
    "dark-purple": ColorTheme(
        accent="#8b6fd4",
        user_label="#6ea8d4",
        muted="#6b6b6b",
        success="#4a9e6b",
        error="#b85c5c",
        warning="#c49a3c",
        info="#5a85b0",
        tool="#c4975a",
        border="#8b6fd4",
        dim_border="#2a1a4a",
    ),
    # ── Light ─────────────────────────────────────────────────────────────────
    "light": ColorTheme(
        accent="#b97c30",
        user_label="#4a8ab0",
        muted="#9b907f",
        success="#3c8b5f",
        error="#b45151",
        warning="#b7842b",
        info="#3a6a9a",
        tool="#7a5a20",
        border="#b97c30",
        dim_border="#ddd2c2",
    ),
    "light-blue": ColorTheme(
        accent="#2a6db5",
        user_label="#4a8ab0",
        muted="#9b907f",
        success="#3c8b5f",
        error="#b45151",
        warning="#b7842b",
        info="#2a6db5",
        tool="#7a5a20",
        border="#2a6db5",
        dim_border="#c0d0e0",
    ),
    "light-purple": ColorTheme(
        accent="#7c3aed",
        user_label="#4a8ab0",
        muted="#9b907f",
        success="#3c8b5f",
        error="#b45151",
        warning="#b7842b",
        info="#3a6a9a",
        tool="#7a5a20",
        border="#7c3aed",
        dim_border="#ddd6fe",
    ),
}

THEME_NAMES = list(THEMES.keys())



def get_theme() -> ColorTheme:
    from zoro_cli.config import load_config
    name = load_config().theme
    return THEMES.get(name or "dark", THEMES["dark"])


# ── Console ───────────────────────────────────────────────────────────────────

def make_console(force_terminal: bool = False) -> Console:
    is_tty = force_terminal or sys.stdout.isatty()
    return Console(
        highlight=False,
        markup=True,
        no_color=not is_tty,
    )


# Module-level singletons — detected once at import time.
console = make_console()


def _make_err_console() -> Console:
    import sys as _sys
    is_tty = _sys.stderr.isatty()
    return Console(stderr=True, highlight=False, markup=True, no_color=not is_tty)


err_console = _make_err_console()


def _quiet() -> bool:
    """True when --quiet flag is active."""
    try:
        from zoro_cli.state import state
        return state.quiet
    except ImportError:
        return False


# ── Helpers ───────────────────────────────────────────────────────────────────

def print_success(msg: str) -> None:
    if _quiet():
        return
    t = get_theme()
    console.print(f"[{t.success}]✓[/]  {msg}")


def print_error(msg: str, hint: str = "") -> None:
    # Errors always print even with --quiet
    t = get_theme()
    err_console.print(f"[{t.error}]✗  Error:[/] {msg}")
    if hint:
        err_console.print(f"   [dim]{hint}[/]")


def print_warning(msg: str) -> None:
    if _quiet():
        return
    t = get_theme()
    console.print(f"[{t.warning}]⚠[/]  {msg}")


def print_info(msg: str) -> None:
    if _quiet():
        return
    console.print(f"[dim]◦  {msg}[/]")


def print_json(data) -> None:
    from rich.json import JSON
    console.print(JSON(_json.dumps(data, indent=2)))


def print_table(headers: list[str], rows: list[list], title: str = "") -> None:
    t = get_theme()
    table = Table(
        box=box.SIMPLE,
        header_style=f"bold {t.accent}",
        title=title or None,
        title_style=f"bold {t.accent}",
    )
    for h in headers:
        table.add_column(h)
    for row in rows:
        table.add_row(*[str(c) for c in row])
    console.print(table)


def format_log_line(line: str, stream: str = "stdout", timestamp: str = "") -> Text:
    t = get_theme()
    result = Text()
    if timestamp:
        result.append(f"{timestamp} ", style=t.muted)
    if stream == "stderr":
        result.append(line, style=f"dim {t.error}")
    elif stream == "system":
        result.append(line, style=f"dim {t.warning}")
    else:
        result.append(line)
    return result


def severity_badge(severity: str) -> str:
    s = severity.lower()
    if s == "critical":
        return "[bold red]CRITICAL[/]"
    if s == "high":
        return "[bold red]HIGH[/]"
    if s == "medium":
        return "[bold yellow]MEDIUM[/]"
    if s == "low":
        return "[bold blue]LOW[/]"
    return "[dim]INFO[/]"


# ── Step/plan renderers (shared by deploy + TUI) ──────────────────────────────

STEP_ICONS = {
    "pending": ("○", "dim"),
    "running": ("●", ""),       # color set by caller
    "done":    ("✓", ""),
    "failed":  ("✗", ""),
}


def render_step_line(label: str, status: str, theme: ColorTheme) -> Text:
    t = theme
    status = status.lower()
    if status == "running":
        icon, style = "●", t.warning
    elif status == "done":
        icon, style = "✓", t.success
    elif status == "failed":
        icon, style = "✗", t.error
    else:
        icon, style = "○", t.muted
    line = Text()
    line.append(f" {icon} ", style=style)
    line.append(label, style=style if status != "pending" else t.muted)
    line.append("\n")
    return line
