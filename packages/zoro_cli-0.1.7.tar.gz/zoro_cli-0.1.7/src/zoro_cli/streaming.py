from __future__ import annotations

import asyncio
import json
from typing import Callable
from urllib.parse import urlparse

import websockets


def _ws_url(api_url: str, path: str, token: str) -> str:
    parsed = urlparse(api_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return f"{scheme}://{parsed.netloc}{path}?token={token}"


async def stream_deployment(
    api_url: str,
    deployment_id: str,
    access_token: str,
    on_event: Callable[[dict], str | None],
    max_reconnects: int = 3,
) -> None:
    """Stream deployment log events.

    `on_event` receives each parsed event dict.
    Return the string ``"done"`` from the callback to stop streaming.
    Reconnects automatically up to `max_reconnects` times on disconnect.
    """
    path = f"/ws/deployments/{deployment_id}/logs/"
    url = _ws_url(api_url, path, access_token)
    attempts = 0
    while True:
        try:
            async with websockets.connect(url) as ws:
                attempts = 0
                async for raw in ws:
                    event = json.loads(raw)
                    result = on_event(event)
                    if result == "done":
                        return
        except websockets.ConnectionClosed:
            attempts += 1
            if attempts > max_reconnects:
                raise
            await asyncio.sleep(0.5 * attempts)


async def stream_chat(
    api_url: str,
    session_id: str,
    access_token: str,
    message: str,
    on_event: Callable[[dict], str | None],
) -> None:
    """Send a message and stream the assistant response.

    `on_event` receives each parsed event dict.
    Streaming stops automatically on ``type == "done"`` or when the callback
    returns ``"done"``.
    """
    path = f"/ws/chat/{session_id}/"
    url = _ws_url(api_url, path, access_token)
    async with websockets.connect(url) as ws:
        await ws.send(json.dumps({"type": "message", "content": message}))
        async for raw in ws:
            event = json.loads(raw)
            result = on_event(event)
            if result == "done" or event.get("type") == "done":
                break
