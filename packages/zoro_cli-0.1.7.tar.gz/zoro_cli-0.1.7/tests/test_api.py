from __future__ import annotations

import unittest

from zoro_cli.api import ZoroAPI


class APITests(unittest.TestCase):
    def test_chat_websocket_url_uses_ws_scheme_and_token(self):
        api = ZoroAPI("http://127.0.0.1:8000/api/v1", access_token="abc123")
        url = api.websocket_url("chat", "session-1")
        self.assertEqual(url, "ws://127.0.0.1:8000/ws/chat/session-1/?token=abc123")

    def test_deployment_websocket_url_uses_wss_for_https(self):
        api = ZoroAPI("https://zoro.example.com/api/v1", access_token="xyz")
        url = api.websocket_url("deployment", "dep-1")
        self.assertEqual(url, "wss://zoro.example.com/ws/deployments/dep-1/logs/?token=xyz")


if __name__ == "__main__":
    unittest.main()
