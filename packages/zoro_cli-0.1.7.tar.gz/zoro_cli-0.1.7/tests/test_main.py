from __future__ import annotations

import json
import unittest
from unittest.mock import patch

from typer.testing import CliRunner

from zoro_cli.api import APIError
from zoro_cli.config import DEFAULT_API_URL
from zoro_cli.main import app, run


class _FakeAPI:
    def whoami(self):
        return {"email": "cli@example.com", "id": "user-1"}

    def list_projects(self):
        return [{"id": "proj-1", "name": "zoro-app"}]

    def list_servers(self):
        return [{"id": "srv-1", "label": "staging"}]

    def list_environments(self, project_id: str):
        return [{"id": "env-1", "name": "staging-backend", "project_id": project_id}]

    def create_deployment_plan(self, **kwargs):
        return {
            "deployment_id": "dep-1",
            "plan_id": "plan-1",
            "plan_text": "DEPLOYMENT PLAN\\n 1. Connect",
        }

    def approve_deployment(self, deployment_id: str):
        return {"deployment_id": deployment_id, "status": "approved", "queued": True}

    def cancel_deployment(self, deployment_id: str):
        return {"id": deployment_id, "status": "failed"}

    def get_deployment_logs(self, deployment_id: str):
        return [
            {
                "timestamp": "2026-03-21T12:00:00Z",
                "level": "info",
                "message": f"log line for {deployment_id}",
            }
        ]


class CLIMainTests(unittest.TestCase):
    def setUp(self) -> None:
        self.runner = CliRunner()

    def test_login_command(self):
        with patch("zoro_cli.main.login_and_store", return_value={"user": {"email": "cli@example.com"}}):
            result = self.runner.invoke(
                app,
                ["login", "--email", "cli@example.com", "--password", "secret", "--api-url", "http://127.0.0.1:8000/api/v1"],
            )
        self.assertEqual(result.exit_code, 0, result.output)
        self.assertIn("Logged in as cli@example.com", result.output)

    def test_default_api_url_points_to_public_api(self):
        self.assertEqual(DEFAULT_API_URL, "https://api.zoro.algohub.cc/api/v1")

    def test_version_option(self):
        result = self.runner.invoke(app, ["--version"])
        self.assertEqual(result.exit_code, 0, result.output)
        self.assertEqual(result.output.strip(), "0.1.6")

    def test_projects_list_command(self):
        with patch("zoro_cli.main.build_api", return_value=(_FakeAPI(), object())):
            result = self.runner.invoke(app, ["projects", "list"])
        self.assertEqual(result.exit_code, 0, result.output)
        payload = json.loads(result.output)
        self.assertEqual(payload[0]["name"], "zoro-app")

    def test_envs_list_command(self):
        with patch("zoro_cli.main.build_api", return_value=(_FakeAPI(), object())):
            result = self.runner.invoke(app, ["envs", "list", "--project-id", "proj-1"])
        self.assertEqual(result.exit_code, 0, result.output)
        payload = json.loads(result.output)
        self.assertEqual(payload[0]["project_id"], "proj-1")

    def test_deploy_plan_command(self):
        with patch("zoro_cli.main.build_api", return_value=(_FakeAPI(), object())):
            result = self.runner.invoke(
                app,
                [
                    "deploy",
                    "plan",
                    "--project-id",
                    "proj-1",
                    "--environment-id",
                    "env-1",
                    "--branch",
                    "main",
                    "--method",
                    "system",
                ],
            )
        self.assertEqual(result.exit_code, 0, result.output)
        self.assertIn("DEPLOYMENT PLAN", result.output)
        self.assertIn("Deployment ID: dep-1", result.output)

    def test_deploy_cancel_command(self):
        with patch("zoro_cli.main.build_api", return_value=(_FakeAPI(), object())):
            result = self.runner.invoke(app, ["deploy", "cancel", "dep-1"])
        self.assertEqual(result.exit_code, 0, result.output)
        payload = json.loads(result.output)
        self.assertEqual(payload["status"], "failed")

    def test_ui_command_invokes_tui_launcher(self):
        with patch("zoro_cli.main.launch_tui") as launch_mock:
            result = self.runner.invoke(app, ["ui"])
        self.assertEqual(result.exit_code, 0, result.output)
        launch_mock.assert_called_once_with(api_url=None)

    def test_run_without_arguments_launches_tui(self):
        with patch("zoro_cli.main._show_dashboard") as dashboard_mock, patch("sys.argv", ["zoro"]):
            run()
        dashboard_mock.assert_called_once_with()

    def test_dashboard_shows_connection_warning_when_api_unreachable(self):
        class _FailingAPI:
            def list_projects(self):
                raise APIError("Could not reach https://api.zoro.algohub.cc/api/v1. Check your API URL and network connection.")

            def list_servers(self):
                raise APIError("Could not reach https://api.zoro.algohub.cc/api/v1. Check your API URL and network connection.")

            def request(self, method, path):
                raise APIError("Could not reach https://api.zoro.algohub.cc/api/v1. Check your API URL and network connection.")

        class _Config:
            access_token = "token"
            api_url = "https://api.zoro.algohub.cc/api/v1"
            user_email = "cli@example.com"

        with patch("zoro_cli.main.load_config", return_value=_Config()), patch("zoro_cli.api.ZoroAPI", return_value=_FailingAPI()):
            result = self.runner.invoke(app, [])

        self.assertEqual(result.exit_code, 0, result.output)
        self.assertIn("Could not reach https://api.zoro.algohub.cc/api/v1", result.output)


if __name__ == "__main__":
    unittest.main()
