"""Allow running as: python -m mempal"""

from .cli import main

main()
