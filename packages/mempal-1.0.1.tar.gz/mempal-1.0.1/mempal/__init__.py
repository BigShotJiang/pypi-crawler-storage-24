"""MemPal — Give your AI a memory. No API key required."""

__version__ = "1.0.1"

from .cli import main

__all__ = ["main", "__version__"]
