# minimls

A minimal Python client for accessing MLS (Machine Learning Service) from OMI on-premises environments.

## Overview

`minimls` provides a lightweight interface for OMI on-premises servers to communicate with the internal MLS service running on AWS. It abstracts REST API calls and/or AWS SDK interactions into a simple, consistent Python API.

## Installation

```bash
pip install minimls
```

## Usage

```python
import minimls

print(minimls.__version__)
```

## Development

### Setup

```bash
# Clone the repository
git clone https://gitlab.cidp.io/mls/minimls.git
cd minimls

# Install with dev dependencies
pip install -e ".[dev]"
```

### Running tests

```bash
pytest
```

### Linting

```bash
ruff check .
mypy minimls/
```

### Building and publishing

```bash
# Build
python -m build

# Upload to PyPI (test)
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*
```

## License

MIT
