import minimls


def test_version():
    assert minimls.__version__ == "0.1.0"
