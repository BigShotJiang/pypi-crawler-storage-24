"""minimls - A minimal Python client for MLS on OMI on-premises environments."""

from importlib.metadata import PackageNotFoundError, version

from minimls.s3_client import MLSClient

try:
    __version__ = version("minimls")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["MLSClient"]
