# Copyright 2026 Arthur Strauss
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Parameter class: mapping of a parameter to a QUA variable for runtime updates.

Author: Arthur Strauss
Date: 2026-02-08
"""

from __future__ import annotations

import copy
import warnings
from itertools import chain
import sys

from qm import QuantumMachine
from qm.api.v2.job_api import JobApi
from qm.qua._dsl import _ResultSource

from .parameter_pool import ParameterPool
from .input_type import Direction, InputType
from typing import Optional, List, Union, Tuple, Literal, Sequence, TYPE_CHECKING, Dict
import numpy as np
from qm.qua import (
    fixed,
    assign,
    declare,
    pause,
    declare_input_stream,
    save,
    for_,
    advance_input_stream as qua_advance_input_stream,
    declare_stream as qua_declare_stream,
    IO1,
    IO2,
    if_,
    Util,
)
from qm.qua._expressions import QuaArrayVariable
from qm.jobs.running_qm_job import RunningQmJob
from qualang_tools.results import wait_until_job_is_paused

if TYPE_CHECKING:
    from .parameter_table import ParameterTable
    from qm.qua.type_hints import (
        Scalar,
        Vector,
        VectorOfAnyType,
        ScalarOfAnyType,
        QuaScalar,
    )


def set_type(qua_type: Union[str, type]):
    """
    Set the type of the QUA variable to be declared.
    Args: qua_type: Type of the QUA variable to be declared (int, fixed, bool).
    """

    if qua_type == "fixed" or qua_type == fixed:
        return fixed
    elif qua_type == "bool" or qua_type == bool:
        return bool
    elif qua_type == "int" or qua_type == int:
        return int
    else:
        raise ValueError("Invalid QUA type. Please use 'fixed', 'int' or 'bool'.")


def infer_type(value: Optional[Union[int, float, List, np.ndarray]] = None):
    """
    Infer automatically the type of the QUA variable to be declared from the type of the initial parameter value.
    """
    if value is None:
        raise ValueError("Initial value must be provided to infer type.")

    # Handle scalar values
    if isinstance(value, bool):
        return bool
    if isinstance(value, int):
        return int
    if isinstance(value, float):
        return fixed if not value.is_integer() or value <= 8 else int

    # Handle array values
    if isinstance(value, (List, np.ndarray)):
        if isinstance(value, np.ndarray):
            if value.ndim != 1:
                raise ValueError("Array must be 1D")
            value = value.tolist()

        if not value:
            raise ValueError("Array cannot be empty")

        first_type = type(value[0])
        if not all(isinstance(x, first_type) for x in value):
            raise ValueError("All array elements must be of same type")

        if first_type == bool:
            return bool
        if first_type == int:
            return int
        if first_type == float:
            return fixed

        raise ValueError("Array elements must be bool, int or float")

    raise ValueError("Value must be bool, int, float or array")


def reset_var(var: QuaScalar, type: Union[str, type]):
    """
    Reset the QUA variable to a 0 value (in the appropriate QUA type).
    """
    if type == int:
        assign(var, 0)
    elif type == fixed:
        assign(var, 0.0)
    elif type == bool:
        assign(var, False)
    else:
        raise ValueError("Invalid QUA type. Please use 'int', 'fixed' or 'bool'.")


class Parameter:
    """
    Class enabling the mapping of a parameter to a QUA variable to be updated. The type of the QUA variable to be
    adjusted can be declared explicitly or either be automatically inferred from the type of provided initial value.
    """

    def __new__(cls, name, *args, **kwargs):
        """
        Create a new instance of the Parameter class.
        """
        for obj in ParameterPool.get_all_objs():
            if hasattr(obj, "parameters"):
                for param in obj.parameters:
                    if param.name == name:
                        warnings.warn(
                            f"Parameter with name {name} already exists in parameter table {obj.name}."
                        )
                        return param
            else:
                if obj.name == name:
                    warnings.warn(
                        f"Parameter with name {name} already exists in the parameter pool."
                    )
                    return obj
        # TODO: Handle the case where the parameter is part of a parameter table with indexing
        obj = super().__new__(cls)
        return obj

    def __init__(
        self,
        name: str,
        value: Optional[Union[int, float, List, np.ndarray]] = None,
        qua_type: Optional[Union[str, type]] = None,
        input_type: Optional[
            Union[Literal["DGX_Q", "INPUT_STREAM", "IO1", "IO2"], InputType]
        ] = None,
        direction: Optional[
            Union[Literal["INCOMING", "OUTGOING", "BOTH"], Direction]
        ] = None,
        units: str = "",
    ):
        """

        Args:
            name: Name of the parameter.
            value: Initial value of the parameter.
            qua_type: Type of the QUA variable to be declared (int, fixed, bool). If none is provided, the type is inferred from initial value.
            input_type: Input type of the parameter (DGX_Q, INPUT_STREAM, IO1, IO2). Default is None.
            direction: Direction of the parameter stream (INCOMING, OUTGOING, BOTH).
                The direction describes in this case the relationship between DGX_Q and OPX in the following manner:
                DGX_Q -> OPX: OUTGOING
                OPX -> DGX_Q: INCOMING
                DGX_Q <-> OPX: BOTH
                Default is None. Relevant only if
                          input_type is DGX_Q.
            units: Units of the parameter. Default is "".

        """
        if hasattr(self, "_initialized") and self._initialized:
            return
        self._name = name
        self.units = units
        self.value = value
        self._index = -1  # Default value for parameters not part of a parameter table
        self._var = None
        self._is_declared = False
        self._stream = None
        self._stream_id = None
        self._type = set_type(qua_type) if qua_type is not None else infer_type(value)
        self._length = 0 if not isinstance(value, (List, np.ndarray)) else len(value)
        self._ctr: Optional[QuaScalar[int]] = None  # Counter for QUA array variables

        self._qua_external_stream_in = None
        self._qua_external_stream_out = None

        if input_type is not None:
            input_type = (
                InputType(input_type) if isinstance(input_type, str) else input_type
            )
        self._input_type: Optional[InputType] = input_type
        self._dgx_struct = None
        if direction is not None:
            direction = (
                Direction(direction) if isinstance(direction, str) else direction
            )
        self._direction = direction
        self._table_indices: Dict[str, int] = {}
        self._main_table = None

        if self._input_type == InputType.DGX_Q and self.direction is None:
            raise ValueError("Direction must be provided for DGX input type.")

        self._initialized = True

    def get_name(self):
        return f"{self.name} [{self.units}]"

    def __repr__(self):
        """
        Returns:
            str: String representation of the parameter.
        """
        return f"Parameter({self.name}{self.units}[{self.type.__name__}])"

    def get_index(self, param_table: ParameterTable) -> int:
        """
        Get the index of the parameter in the parameter table.
        Args:
            param_table: ParameterTable object to get the index from.
        Returns:
            int: Index of the parameter in the parameter table.
        """
        if self._index == -1:
            raise ValueError(
                "This parameter is not part of a parameter table. "
                "Please use this method through the parameter table instead."
            )
        if param_table.name not in self._table_indices:
            raise ValueError(
                f"Parameter {self.name} is not part of the parameter table {param_table.name}."
            )
        return self._table_indices[param_table.name]

    def set_index(self, param_table: ParameterTable, index: int):
        """
        Set the index of the parameter in the parameter table.
        Args:
            param_table: ParameterTable object to set the index for.
            index: Index of the parameter in the parameter table.
        """
        if self._index == -1:
            self._index = -2

        if param_table.name not in self._table_indices:
            self._table_indices[param_table.name] = index
        else:
            raise ValueError(
                f"Parameter {self.name} is already part of the parameter table {param_table.name}."
            )

    def is_standalone(self) -> bool:
        """
        Check if the parameter is standalone (not part of a parameter table).
        Returns:
            bool: True if the parameter is standalone, False otherwise.
        """
        return self.main_table is None

    @property
    def main_table(self) -> Optional[ParameterTable]:
        """
        Returns:
            The ParameterTable object used to declare the parameter.
            Specifically, the one that should be used for communication if InputType is DGX_Q.
        :returns: ParameterTable object or None if not found.

        """
        return self._main_table

    def assign(
        self,
        value: Union["Parameter", ScalarOfAnyType, VectorOfAnyType],
        condition=None,
        value_cond: Optional[
            Union["Parameter", ScalarOfAnyType, VectorOfAnyType]
        ] = None,
    ):
        """
        Assign value to the QUA variable corresponding to the parameter.

        Args:
            value: Value to be assigned to the QUA variable. If the ParameterValue corresponds to a QUA array,
                   the value should be a list or a QUA array of the same length.
            condition: Condition to be met for the value to be assigned to the QUA variable.
            value_cond: Optional value to be assigned to the QUA variable if provided condition is not met.

        Raises:
            ValueError: If the variable is not declared, or if the condition and value_cond are not provided together,
                        or if the value_cond is not of the same type as value, or if the value length does not match
                        the parameter length, or if the input is invalid.
        """
        if not self.is_declared:
            raise ValueError(
                "Variable not declared. Declare the variable first through declare_variable method."
            )
        if (condition is not None) != (value_cond is not None):
            raise ValueError("Both condition and value_cond must be provided.")

        def assign_with_condition(var, val, cond_val):
            if condition is not None:
                assign(var, Util.cond(condition, val, cond_val))
            else:
                assign(var, val)

        if isinstance(value, Parameter):
            if not value.is_declared:
                raise ValueError(
                    "Variable not declared. Declare the variable first through declare_variable method."
                )
            if value.length != self.length:
                raise ValueError(
                    f"Invalid input. Mismatch in length of {self.name} ({self.length}) and {value.name} ({value.length})."
                )
            if value_cond is not None and not isinstance(value_cond, Parameter):
                raise ValueError(
                    "Invalid input. value_cond should be of same type as value."
                )
            if self.is_array:
                with for_(self._ctr, 0, self._ctr < self.length, self._ctr + 1):
                    assign_with_condition(
                        self.var[self._ctr],
                        value.var[self._ctr],
                        value_cond.var[self._ctr] if value_cond else None,
                    )
            else:
                assign_with_condition(
                    self.var, value.var, value_cond.var if value_cond else None
                )
        else:
            if self.is_array:
                if isinstance(value, QuaArrayVariable):
                    with for_(self._ctr, 0, self._ctr < self.length, self._ctr + 1):
                        assign_with_condition(
                            self.var[self._ctr],
                            value[self._ctr],
                            value_cond[self._ctr] if value_cond is not None else None,
                        )
                else:
                    if len(value) != self.length:
                        raise ValueError(
                            f"Invalid input. {self.name} should be a list of length {self.length}."
                        )
                    for i in range(self.length):
                        assign_with_condition(
                            self.var[i], value[i], value_cond[i] if value_cond else None
                        )
            else:
                if isinstance(value, List):
                    raise ValueError(
                        f"Invalid input. {self.name} should be a single value, not a list."
                    )
                assign_with_condition(self.var, value, value_cond)

    def declare_variable(self, pause_program=False, declare_stream=True):
        """
        Declare the QUA variable associated with the parameter.
        Args: pause_program: Boolean indicating if the program should be paused after declaring the variable.
            Default is False.
        declare_stream: Boolean indicating if an output stream should be declared to save the QUA variable.
        """
        if self.is_declared:
            raise ValueError("Variable already declared. Cannot declare again.")
        if self.input_type == InputType.DGX_Q:
            if self.is_standalone():
                from qm.qua import (
                    declare_struct,
                    declare_external_stream,
                    QuaStreamDirection,
                )

                # Parameter not part of a parameter table
                self.stream_id = ParameterPool.get_id(self)
                dgx_struct = self.dgx_struct
                self._var = declare_struct(dgx_struct)

                if self.direction == Direction.INCOMING:
                    self._qua_external_stream_out = declare_external_stream(
                        dgx_struct, self.stream_id, QuaStreamDirection.OUTGOING
                    )
                elif self.direction == Direction.OUTGOING:
                    self._qua_external_stream_in = declare_external_stream(
                        dgx_struct, self.stream_id, QuaStreamDirection.INCOMING
                    )
                else:
                    self._qua_external_stream_in = declare_external_stream(
                        dgx_struct, self.stream_id, QuaStreamDirection.INCOMING
                    )
                    self._qua_external_stream_out = declare_external_stream(
                        dgx_struct, self.stream_id, QuaStreamDirection.OUTGOING
                    )

            else:
                raise ValueError(
                    f"This parameter is part of a parameter table. "
                    f"Please use the parameter table {ParameterPool.get_obj(self.stream_id).name} "
                    f"forming the Struct to declare it."
                )
        else:
            args_declare = {"t": self.type}
            if self.value is not None:
                args_declare["value"] = self.value
            elif self.length > 1:
                args_declare["size"] = self.length
            if self.input_type == InputType.INPUT_STREAM:
                args_declare["name"] = self.name
                declare_statement = declare_input_stream
            else:
                declare_statement = declare
            self._var = declare_statement(**args_declare)

        if self.is_array and self.length > 1:
            self._ctr = declare(int)
        if pause_program:
            pause()
        self._is_declared = True
        if declare_stream:
            self.declare_stream()
        return self._var

    def declare_stream(self):
        """
        Declare the output stream associated with the parameter.
        """
        if self._stream is None:
            self._stream = qua_declare_stream()
        else:
            warnings.warn(f"Stream {self.name} already declared, skipping declaration.")
        return self._stream

    @property
    def is_declared(self):
        """Boolean indicating if the QUA variable has been declared."""
        return self._is_declared

    @property
    def name(self):
        """Name of the parameter."""
        return self._name

    @property
    def direction(self):
        if self.input_type != InputType.DGX_Q:
            warnings.warn("This parameter is not associated with a DGX stream.")
            raise ValueError("This parameter is not associated with a DGX stream.")
        return self._direction

    @property
    def dgx_struct(self):
        """
        DGX struct associated with the parameter.
        Can be a reference to a bigger struct describing a ParameterTable (automatically set by the
        ParameterTable class) or a standalone struct created on the fly.
        Returns:

        """
        if self.input_type != InputType.DGX_Q:
            raise ValueError(
                "Invalid input type for calling dgx_struct property. Must be set to InputType.DGX."
            )
        if self.is_standalone():
            try:
                from qm.qua import qua_struct, QuaArray
            except ImportError:
                raise ImportError("Need to install QUA version compatible with DGX")
            length = 1 if not self.is_array else self.length
            cls_name = f"{self.name}_struct_{self.stream_id}"
            dgxStruct = qua_struct(
                type(
                    cls_name,
                    (object,),
                    {"__annotations__": {self.name: QuaArray[self.type, length]}},
                )
            )
            self._dgx_struct = dgxStruct

        return self._dgx_struct

    @dgx_struct.setter
    def dgx_struct(self, value):
        if self._dgx_struct is None:
            self._dgx_struct = value
        else:
            raise ValueError("DGX struct already set. Cannot change it.")

    @property
    def stream_id(self) -> int:
        """
        ID of the external stream associated with the parameter (Relevant only for DGX).
        If the Parameter is part of a ParameterTable, returns the stream_id of the table.
        Returns:
            Unique ID integer of the external stream.

        """

        return self._stream_id

    @stream_id.setter
    def stream_id(self, value: int):
        if self._stream_id is None:
            self._stream_id = value
        else:
            raise ValueError("Stream ID already set. Cannot change it.")

    @property
    def var(self) -> QuaArrayVariable | QuaScalar:
        """
        Returns:
            QUA variable associated with the parameter.
        """
        if not self.is_declared:
            raise ValueError(
                "Variable not declared. Declare the variable first through declare_variable method."
            )
        if self.input_type == InputType.DGX_Q:
            var = getattr(self._var, self.name)
            return var if self.is_array else var[0]

        else:
            return self._var

    @property
    def tables(self) -> List[ParameterTable]:
        """
        Returns:
            List of ParameterTable objects associated with the parameter.
        """
        from .parameter_table import ParameterTable

        tables = []
        for table in ParameterPool.get_all_objs():
            if isinstance(table, ParameterTable) and table.has_parameter(self):
                tables.append(table)
        return tables

    @property
    def type(self):
        """Type of the associated QUA variable."""
        return self._type

    @type.setter
    def type(self, value: Union[str, type]):
        if self.is_declared:
            raise ValueError("Variable already declared. Cannot change type.")
        self._type = set_type(value)

    @property
    def length(self):
        """Length of the parameter if it refers to a QUA array (
        returns 0 if single value)."""
        return self._length

    @property
    def input_type(self) -> Optional[InputType]:
        """
        Type of input stream associated with the parameter.
        """
        return self._input_type

    @property
    def is_array(self):
        """Boolean indicating if the parameter refers to a QUA array."""
        return self.length > 0

    @property
    def stream(self) -> _ResultSource:
        """Output stream associated with the parameter."""
        return self._stream

    def save_to_stream(self, reset: bool = False):
        """
        Save the QUA variable to the output stream.

        Args:
            reset: Whether to reset the parameter to a 0 value (in the appropriate QUA type) after saving it to the stream.
        Raises:
            ValueError: If the output stream is not declared, or if the variable is not declared.
        """
        if self.is_declared and self.stream is not None:
            if self.is_array:
                with for_(self._ctr, 0, self._ctr < self.length, self._ctr + 1):
                    save(self.var[self._ctr], self.stream)
                    if reset:
                        reset_var(self.var[self._ctr], self.type)
            else:
                save(self.var, self.stream)
                if reset:
                    reset_var(self.var, self.type)
        else:
            raise ValueError("Output stream or variable itself not declared.")

    def stream_processing(
        self,
        mode: Literal["save", "save_all"] = "save_all",
        buffer: Optional[Union[Tuple[int, ...], int, Literal["default"]]] = "default",
    ):
        """
        Process the output stream associated with the parameter.
        Args:
            mode: Mode of processing the stream. Can be "save" or "save_all". Default is "save_all".
            buffer: Buffer size for the stream. If "default", the default buffer size is used (no buffer for a single variable
                and buffer of array size for an array). Can also be set to None for no buffer.
        """
        if mode not in ["save", "save_all"]:
            raise ValueError("Invalid mode. Must be 'save' or 'save_all'.")
        if buffer == "default":
            if self.is_array:
                buffer = (self.length,)
            else:
                buffer = None
        elif isinstance(buffer, int):
            buffer = (buffer,)
        if self.stream is not None:
            if buffer is not None:
                stream = self.stream.buffer(*buffer)
            else:
                stream = self.stream
            getattr(stream, mode)(self.name)
        else:
            raise ValueError("Output stream not declared.")

    def clip(
        self,
        min_val: Optional[
            Scalar[int], Scalar[float], Vector[int], Vector[float]
        ] = None,
        max_val: Optional[
            Scalar[int], Scalar[float], Vector[int], Vector[float]
        ] = None,
        is_qua_array: bool = False,
    ):
        """
        Clip the QUA variable to a given range.
        Args: min_val: Minimum value of the range.
            max_val: Maximum value of the range.
            is_array: Boolean indicating if the bounds are QUA arrays.
        """
        if not self.is_declared:
            raise ValueError(
                "Variable not declared. Declare the variable first through declare_variable method."
            )
        if not self.is_array and is_qua_array:
            raise ValueError(
                "Invalid input. Single value cannot be clipped with array bounds."
            )
        elif (
            isinstance(min_val, (int, float))
            and isinstance(max_val, (int, float))
            and min_val > max_val
        ):
            raise ValueError(
                "Invalid range. Minimum value must be less than maximum value."
            )

        elif min_val is None and max_val is None:
            warnings.warn("No range specified. No clipping performed.")
            return

        if self.is_array:
            i = self._ctr
            with for_(i, 0, i < self.length, i + 1):
                if is_qua_array:
                    if min_val is not None:
                        with if_(self.var[i] < min_val[i]):
                            assign(self.var[i], min_val[i])
                    if max_val is not None:
                        with if_(self.var[i] > max_val[i]):
                            assign(self.var[i], max_val[i])
                else:
                    if min_val is not None:
                        with if_(self.var[i] < min_val):
                            assign(self.var[i], min_val)
                    if max_val is not None:
                        with if_(self.var[i] > max_val):
                            assign(self.var[i], max_val)
        else:
            if min_val is not None:
                with if_(self.var < min_val):
                    assign(self.var, min_val)
            if max_val is not None:
                with if_(self.var > max_val):
                    assign(self.var, max_val)

    def load_input_value(self):
        """
        QUA Macro: Load a value from the input mechanism associated with the parameter.
        This should be corresponding to one call of the `fetch_from_opx` method on the client side.
        For input streams, the stream is advanced.
        For IO1 and IO2, the value is assigned to the QUA variable.
        For DGX Quantum, the value is polled.
        """
        if self.input_type is None:
            raise ValueError("No input type specified")
        elif self.input_type == InputType.INPUT_STREAM:
            qua_advance_input_stream(self.var)

        elif self.input_type == InputType.DGX_Q:
            from qm.qua import receive_from_external_stream

            if self.is_standalone():
                receive_from_external_stream(self._qua_external_stream_in, self._var)
            else:
                raise RuntimeError(
                    f"This method should be called from the ParameterTable {ParameterPool.get_obj(self.stream_id).name}"
                    f" as this parameter was associated with a bigger packet."
                )

        elif self.input_type in [InputType.IO1, InputType.IO2]:
            io = IO1 if self.input_type == InputType.IO1 else IO2
            if self.is_array:
                if self.length == 1:
                    pause()
                    assign(self.var[0], io)
                    return
                with for_(self._ctr, 0, self._ctr < self.length, self._ctr + 1):
                    pause()
                    assign(self.var[self._ctr], io)
            else:
                pause()
                assign(self.var, io)

        else:
            raise ValueError("Invalid input stream type.")

    def push_to_opx(
        self,
        value: Union[int, float, bool, Sequence[Union[int, float, bool]]],
        job: Optional[RunningQmJob | JobApi] = None,
        qm: Optional[QuantumMachine] = None,
        verbosity: int = 1,
        time_out: int = 30,
    ):
        """
        Client function: pass an input value to the OPX from client/server side.
        This should be corresponding to one call of the `load_input_value` method on the QUA side.
        Args:
            value: Value to be passed to the OPX.
            job: RunningQmJob object (required if input_type is IO1 or IO2 or input_stream).
            qm: QuantumMachine object (required if input_type is IO1 or IO2).
            verbosity: Verbosity level. Default is 1.
            time_out: Time out for waiting for the job to be paused. Default is 90 seconds.
        """

        if self.is_array:
            if not isinstance(value, (List, np.ndarray)):
                raise ValueError(
                    f"Invalid input. {self.name} should be a list of {self.type}."
                )
            if len(value) != self.length:
                raise ValueError(
                    f"Invalid input. {self.name} should be a list of length {self.length}."
                )
        param_type = self.type if self.type != fixed else float
        if self.is_array and not all(isinstance(x, param_type) for x in value):
            try:
                value = [param_type(x) for x in value]
            except ValueError:
                raise ValueError(
                    f"Invalid input. {self.name} should be a list of {param_type}."
                )
        elif not self.is_array and not isinstance(value, param_type):
            try:
                value = param_type(value)
            except ValueError:
                raise ValueError(
                    f"Invalid input. {self.name} should be a single value of type {param_type}."
                )

        if self.input_type in [InputType.IO1, InputType.IO2]:
            if job is None:
                raise ValueError("Job object is required to set IO values.")
            io = "io1" if self.input_type == InputType.IO1 else "io2"
            if self.is_array:
                for i in range(self.length):
                    if verbosity > 1:
                        print(f"Setting {self.name} to {value[i]} through {io}")
                    wait_until_job_is_paused(job, time_out)
                    if isinstance(job, JobApi):
                        job.set_io_values(**{io: value[i]})
                    else:
                        if qm is None:
                            raise ValueError(
                                "QuantumMachine object is required to set IO values."
                            )
                        qm.set_io_values(**{io: value[i]})
                    job.resume()
            else:
                if verbosity > 1:
                    print(f"Setting {self.name} to {value} through {io}")
                wait_until_job_is_paused(job, time_out)
                if isinstance(job, JobApi):
                    # For JobApi, we need to use the set_io_values method
                    job.set_io_values(**{io: value})
                else:
                    if qm is None:
                        raise ValueError(
                            "QuantumMachine object is required to set IO values."
                        )
                    qm.set_io_values(**{io: value})
                job.resume()

        elif self.input_type == InputType.INPUT_STREAM:
            if verbosity > 1:
                print(f"Pushing value {value} to {self.name} through input stream.")
            if job is None:
                raise ValueError(
                    "Job object is required to push values to the input stream."
                )
            job.push_to_input_stream(self.name, value)

        elif self.input_type == InputType.DGX_Q:
            if self.is_standalone():
                if self.direction == Direction.INCOMING:
                    raise ValueError("Cannot push value to Incoming stream.")
                if not ParameterPool.configured() or not ParameterPool.patched():
                    raise ValueError("OPNIC not configured or patched.")
                # Prepare the packet to be sent
                param_dict = {self.name: [value] if not self.is_array else value}
                param_dict = {
                    k: v.tolist() if isinstance(v, np.ndarray) else v
                    for k, v in param_dict.items()
                }

                from opnic_wrapper import OutgoingPacket, send_packet

                flattened_values = list(chain(*param_dict.values()))
                packet = OutgoingPacket(*flattened_values)
                for k, v in param_dict.items():
                    setattr(packet, k, v)
                send_packet(self.stream_id, packet)

                if verbosity > 1:
                    print(f"Sent packet: {packet}")
            else:
                raise RuntimeError(
                    f"This method should be called from the ParameterTable object"
                    f" {ParameterPool.get_obj(self.stream_id).name} as this parameter "
                    f"was associated with a bigger packet."
                )

    def stream_back(self, reset: bool = False):
        """
        QUA Macro: Save/stream the value of the parameter to the client/server side.
        This method uses stream_processing method to save the value to the stream if input_type is different from DGX Quantum.
        If input_type is DGX Quantum, the value is sent to the external stream.

        Args:
            reset: Whether to reset the parameter to a 0 value (in the appropriate QUA type) after sending it to the client/server side.
        """
        if (
            self.input_type in [InputType.INPUT_STREAM, None]
            and self.stream is not None
        ):
            self.save_to_stream(reset)
        elif self.input_type == InputType.DGX_Q:
            from qm.qua import send_to_external_stream

            if not self.is_standalone():  # Part of a parameter table
                raise RuntimeError(
                    f"This method should be called from the"
                    f" ParameterTable object {ParameterPool.get_obj(self.stream_id).name} "
                    f"as this parameter was associated with a bigger packet."
                )

            if self.direction == Direction.OUTGOING:
                raise ValueError("Cannot send value to outgoing stream.")

            send_to_external_stream(self._qua_external_stream_out, self._var)
            self.reset_var()
        elif self.input_type in [InputType.IO1, InputType.IO2]:
            io = IO1 if self.input_type == InputType.IO1 else IO2
            if self.is_array:
                i = self._ctr
                with for_(i, 0, i < self.length, i + 1):
                    assign(io, self.var[i])
                    if reset:
                        reset_var(self.var[i], self.type)
                    pause()

            else:
                assign(io, self.var)
                if reset:
                    reset_var(self.var, self.type)
                pause()

    def fetch_from_opx(
        self,
        job: Optional[RunningQmJob | JobApi] = None,
        fetching_index: int = 0,
        fetching_size: int = 1,
        verbosity: int = 1,
        time_out=30,
    ):
        """
        Client function: Fetches data based on the specified input type and returns the fetched value.

        This method handles various input types defined by the `InputType` enumeration
        (IO1, IO2, INPUT_STREAM, DGX). It manages the fetching logic, including waiting
        for paused jobs, accessing specified result streams, and interacting with
        external modules when necessary. For DGX input type, it also checks configurations
        and fetches data based on parameters related to outgoing or incoming streams.

        :param job: The job instance of the RunningQmJob for which data is being fetched.
        :type job: RunningQmJob
        :param qm: The QuantumMachine instance utilized for fetching the data. Defaults to None.
        :param fetching_index: The starting index for fetching data when required. Defaults to 0.
        :type fetching_index: int
        :param fetching_size: Number of items to fetch from the source, if applicable. Defaults to 1.
        :type fetching_size: int
        :param verbosity: Level of output verbosity for log printing. A verbosity > 1 enables detailed logging.
        :type verbosity: int
        :param time_out: Time in seconds to wait for the job to be paused before fetching data. Defaults to 30 seconds.
        :return: The fetched value depending upon the input type and fetching logic.
        """
        if self.input_type == InputType.INPUT_STREAM or self.input_type is None:
            if job is None:
                raise ValueError(
                    "Job object is required to fetch values from the result handles."
                )
            if verbosity > 1:
                print(
                    f"Fetching value from {self.name} with input type {self.input_type}"
                )
            result_handle = job.result_handles
            if self.name not in result_handle:
                raise ValueError(
                    f"Parameter {self.name} not found in the result handles. "
                    "Make sure to save the parameter to the stream first."
                )
            result = result_handle.get(self.name)
            result.wait_for_values(fetching_index + fetching_size, time_out)
            value = result.fetch(slice(fetching_index, fetching_index + fetching_size))[
                "value"
            ]

        elif self.input_type == InputType.DGX_Q:
            if not self.is_standalone():  # Part of a parameter table
                raise RuntimeError(
                    f"This method should be called from the"
                    f" ParameterTable object {ParameterPool.get_obj(self.stream_id).name} "
                    f"as this parameter was associated with a bigger packet."
                )

            if self.direction == Direction.OUTGOING:
                raise ValueError("Cannot fetch value from outgoing stream.")
            elif not ParameterPool.configured() or not ParameterPool.patched():
                raise ValueError("OPNIC not configured or patched.")

            from opnic_wrapper import wait_for_packets, read_packet

            wait_for_packets(self.stream_id, fetching_index + fetching_size)
            packets = []
            for i in range(fetching_size):
                packet = read_packet(self.stream_id, fetching_index + i)
                packets.append(packet)
            value = np.array([getattr(packet, self.name) for packet in packets])
        elif self.input_type in [InputType.IO1, InputType.IO2]:
            io_method = (
                "get_io1_value" if self.input_type == InputType.IO1 else "get_io2_value"
            )
            if self.is_array:
                value = []
                for i in range(self.length):
                    wait_until_job_is_paused(job, time_out)
                    value.append(getattr(job, io_method)(self.type))
                    job.resume()
            else:
                wait_until_job_is_paused(job, time_out)
                value = getattr(job, io_method)(self.type)
                job.resume()
        else:
            raise ValueError("Invalid input type.")
        if verbosity > 1:
            print(f"Fetched value: {value}")
        return value

    def reset(self):
        """
        Client function: Reset the parameter to its initial state.
        """
        self._is_declared = False
        self._var = None
        self._stream = None
        self._stream_id = None
        self._ctr = None
        self._dgx_struct = None
        self._qua_external_stream_in = None
        self._qua_external_stream_out = None
        # self._index = -1
        # self._main_table = None
        # self._table_indices = {}

    def reset_var(self):
        """
        QUA Macro: Assign the QUA variable to 0 (in the appropriate QUA type).
        """
        if self.is_array:
            with for_(self._ctr, 0, self._ctr < self.length, self._ctr + 1):
                reset_var(self.var[self._ctr], self.type)
        else:
            reset_var(self.var, self.type)

    def __deepcopy__(self, memodict=None):
        if memodict is None:
            memodict = {}
        if id(self) in memodict:
            return memodict[id(self)]
        cls = self.__class__
        new_param = object.__new__(cls)
        memodict[id(self)] = new_param

        # Now, manually populate new_param with copied attributes:
        new_param._name = self._name
        new_param.units = self.units
        new_param._type = self._type
        new_param._input_type = self._input_type
        new_param._direction = self._direction
        new_param.value = copy.deepcopy(self.value, memodict)  # Deepcopy mutable values
        new_param._length = self._length

        # Reset QUA-specific and context-dependent state
        new_param._var = None
        new_param._is_declared = False
        new_param._stream = None
        new_param._ctr = None
        new_param._qua_external_stream_in = None
        new_param._qua_external_stream_out = None

        # Reset table/DGX specific attributes that will be set by the new table or properties
        new_param._index = -1  # Default for a parameter not (yet) in a table
        new_param._table_indices = {}  # New dictionary for table associations
        new_param._dgx_struct = None
        new_param._stream_id = None  # Will be re-evaluated by property or new table
        new_param._main_table = None

        # If your __init__ sets an _initialized flag, set it here too
        if hasattr(self, "_initialized"):
            new_param._initialized = True

        return new_param
