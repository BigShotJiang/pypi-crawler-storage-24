# Copyright 2026 Arthur Strauss
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""SymPy/SymEngine to QUA expression translation for parameterized pulse/circuit code.

Author: Arthur Strauss
Date: 2026-02-08
"""

import functools
from typing import Dict

import qm.qua as qua
import sympy as sp
import symengine as se
from functools import partial

from qm.qua.type_hints import QuaVariable
from qiskit_qm_provider.parameter_table import Parameter

sympy_to_qua_dict = {
    sp.Float: qua.fixed,
    sp.Integer: int,
    sp.Abs: qua.Math.abs,
    sp.cos: qua.Math.cos,
    sp.sin: qua.Math.sin,
    sp.exp: qua.Math.exp,
    sp.ln: qua.Math.ln,
    sp.log: qua.Math.log,
    partial(sp.log, 10): qua.Math.log10,
    partial(sp.log, 2): qua.Math.log2,
    partial(sp.Pow, -1): qua.Math.inv,
    partial(sp.Pow, 0.5): qua.Math.sqrt,
    sp.Pow: qua.Math.pow,
    sp.sqrt: qua.Math.sqrt,
}


def match_expr(expr: sp.Function):
    """
    Match a sympy expression to a Qua function
    """
    for key, value in sympy_to_qua_dict.items():
        if isinstance(key, partial):
            if expr.func == key.func and expr.args[1] == key.args[0]:
                return value
        elif isinstance(expr, key):
            return value
    raise ValueError(f"Unsupported sympy expression: {expr}")


def sympy_to_qua(sympy_expr: sp.Basic, parameters: Dict[str, Parameter]) -> QuaVariable:
    """
    Convert a Sympy expression to a QuaVariableType

    Args:
        sympy_expr: Sympy expression to convert (could contain multiple Parameters)
        parameters: Dictionary of parameters (contain name and QUA variable)
    Returns:
        QuaVariableType: The equivalent QUA variable transformed from the sympy expression
    """
    # Convert sympy_expr that could be from symengine to actual sympy
    # if any([isinstance(param.type, fixed) for param in parameter_vals.values()]):
    #     new_val = declare(fixed)
    # else:
    #     new_val = declare(int)

    sympy_to_qua_dict = {}
    for symbol in sympy_expr.free_symbols:
        assert (
            symbol.name in parameters
        ), f"Parameter {symbol.name} not found in parameter_vals"
        sympy_to_qua_dict[symbol] = parameters[symbol.name].var

    if isinstance(sympy_expr, se.Basic):
        sympy_expr = sp.sympify(str(sympy_expr))
    if isinstance(sympy_expr, sp.Symbol):
        # Proceed to name comparison, as direct comparison of sympy symbols is not working
        initial_key = sympy_expr.name
        final_key = None
        for key in sympy_to_qua_dict.keys():
            if key.name == initial_key:
                final_key = key
                break
        if not final_key:
            raise ValueError(f"Parameter {initial_key} not found in parameter_vals")
        result = sympy_to_qua_dict[final_key]

    elif isinstance(sympy_expr, sp.Number):
        result = sympy_expr.evalf()

    elif isinstance(sympy_expr, sp.Mul):
        # handle multiplication for arbitrary number of terms
        result = functools.reduce(
            lambda x, y: x * y,
            [sympy_to_qua(term, parameters) for term in sympy_expr.args],
        )

    elif isinstance(sympy_expr, sp.Add):
        # handle addition for arbitrary number of terms
        result = functools.reduce(
            lambda x, y: x + y,
            [sympy_to_qua(term, parameters) for term in sympy_expr.args],
        )
    elif isinstance(sympy_expr, sp.Pow):
        result = sympy_to_qua_dict[type(sympy_expr)](
            sympy_to_qua(sympy_expr.args[0], parameters),
            sympy_to_qua(sympy_expr.args[1], parameters),
        )
    elif isinstance(sympy_expr, sp.Function):
        qua_func = match_expr(sympy_expr)
        if qua_func:
            result = qua_func(sympy_to_qua(sympy_expr.args[0], parameters))
        else:
            raise ValueError(f"Unsupported sympy expression: {sympy_expr}")
    else:
        raise ValueError(f"Unsupported sympy expression: {sympy_expr}")
    # assign(new_val, result)
    return result
