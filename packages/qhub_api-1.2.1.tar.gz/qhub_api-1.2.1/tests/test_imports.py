import importlib
import unittest

MODULES = [
    "qhub.api.platform",
    "qhub.api.quantum",
    "qhub.api.service",
]


class ImportTests(unittest.TestCase):
    def test_all_exports_importable(self):
        for module_name in MODULES:
            with self.subTest(module=module_name):
                mod = importlib.import_module(module_name)
                for name in mod.__all__:
                    with self.subTest(name=name):
                        self.assertTrue(
                            hasattr(mod, name),
                            f"{module_name}.{name} is listed in __all__ but cannot be imported",
                        )
