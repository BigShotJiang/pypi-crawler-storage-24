from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional, Tuple
from importlib import resources as _resources


def _safe_json_loads(raw: str, default: Any) -> Any:
    try:
        return json.loads(raw)
    except Exception:
        return default


def _read_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}
##########################################################
def _read_json_resource(name: str) -> Dict[str, Any]:
    """Read JSON packaged with the module (works even when running from a wheel)."""
    try:
        raw = _resources.files(__package__).joinpath(name).read_text(encoding="utf-8")
        data = _safe_json_loads(raw, {})
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


_FALLBACK_INDEX: Dict[str, Any] = {
    "default": "2026-01-19",
    "versions": {"2026-01-19": "catalogue.v1.json"},
}

_FALLBACK_CATALOGUE_V1: Dict[str, Any] = {
    "schema": "smx-premium-catalogue/v1",
    "version": "2026-01-19",
    "currency": "EUR",
    "plans": {
        "trial": {
            "display_name": "Trial",
            "entitlements": {
                "docs": True,
                "ml_lab": True,
                "registration": True,
                "theme_toggle": True,
                "branding_controls": True,
                "plugins": True,
                "premium_db_backends": True,
                "audit_export": True,
                "max_users": 9999,
                "max_pages": 9999,
                "max_upload_mb": 9999,
                "max_pdf_pages_per_doc": 999999,
                "max_vector_records": 999999999,
            },
        },
        "free": {
            "display_name": "Free",
            "entitlements": {
                "docs": False,
                "ml_lab": False,
                "registration": False,
                "theme_toggle": False,
                "branding_controls": False,
                "plugins": False,
                "premium_db_backends": False,
                "audit_export": False,
                "max_users": 1,
                "max_pages": 3,
                "max_upload_mb": 5,
                "max_pdf_pages_per_doc": 20,
                "max_vector_records": 1500,
            },
        },
        "pro": {
            "display_name": "Pro",
            "entitlements": {
                "docs": True,
                "ml_lab": True,
                "registration": True,
                "theme_toggle": True,
                "branding_controls": True,
                "plugins": True,
                "premium_db_backends": False,
                "audit_export": True,
                "max_users": 10,
                "max_pages": 50,
                "max_upload_mb": 200,
                "max_pdf_pages_per_doc": 300,
                "max_vector_records": 50000,
            },
        },
        "business": {
            "display_name": "Business",
            "entitlements": {
                "docs": True,
                "ml_lab": True,
                "registration": True,
                "theme_toggle": True,
                "branding_controls": True,
                "plugins": True,
                "premium_db_backends": True,
                "audit_export": True,
                "max_users": 25,
                "max_pages": 150,
                "max_upload_mb": 500,
                "max_pdf_pages_per_doc": 750,
                "max_vector_records": 200000,
            },
        },
        "enterprise": {
            "display_name": "Enterprise",
            "entitlements": {
                "docs": True,
                "ml_lab": True,
                "registration": True,
                "theme_toggle": True,
                "branding_controls": True,
                "plugins": True,
                "premium_db_backends": True,
                "audit_export": True,
                "max_users": 200,
                "max_pages": 500,
                "max_upload_mb": 2000,
                "max_pdf_pages_per_doc": 2000,
                "max_vector_records": 500000,
            },
        },
    },
    "addons": {},
    "ui": {
        "labels": {
            "docs": {"name": "Docs", "category": "Features", "type": "bool"},
            "ml_lab": {"name": "ML Lab", "category": "Features", "type": "bool"},
            "registration": {"name": "Registration", "category": "Features", "type": "bool"},
            "theme_toggle": {"name": "Theme toggle", "category": "Features", "type": "bool"},
            "branding_controls": {"name": "Branding controls", "category": "Features", "type": "bool"},
            "plugins": {"name": "Plugins", "category": "Features", "type": "bool"},
            "premium_db_backends": {"name": "Premium DB backends", "category": "Features", "type": "bool"},
            "audit_export": {"name": "Audit/export", "category": "Features", "type": "bool"},
            "max_users": {"name": "Max users", "category": "Limits", "type": "int", "unit": "users"},
            "max_pages": {"name": "Max pages", "category": "Limits", "type": "int", "unit": "pages"},
            "max_upload_mb": {"name": "Max upload size", "category": "Limits", "type": "int", "unit": "MB"},
            "max_pdf_pages_per_doc": {
                "name": "Max PDF pages per document",
                "category": "Limits",
                "type": "int",
                "unit": "pages",
            },
            "max_vector_records": {"name": "Max vector records", "category": "Limits", "type": "int", "unit": "records"},
        }
    },
}
#########################################

def _catalogue_dir() -> str:
    return os.path.join(os.path.dirname(__file__))


def load_index() -> Dict[str, Any]:
    """Load catalogue index.json (safe, returns fallback on failure)."""
    data = _read_json(os.path.join(_catalogue_dir(), "index.json"))
    if data:
        return data
    data = _read_json_resource("index.json")
    return data if data else dict(_FALLBACK_INDEX)


def load_catalogue(version: Optional[str] = None) -> Tuple[Dict[str, Any], str]:
    """Load a catalogue for the requested version.

    Returns: (catalogue_dict, resolved_version)
    """
    idx = load_index()
    resolved = (version or "").strip() or str(idx.get("default") or "").strip()
    versions = idx.get("versions") if isinstance(idx.get("versions"), dict) else {}
    fname = versions.get(resolved) if isinstance(versions, dict) else None

    if not fname:
        # Fall back to default file name if index is missing or version unknown.
        fname = "catalogue.v1.json"

    cat = _read_json(os.path.join(_catalogue_dir(), str(fname)))
    if not cat:
        cat = _read_json_resource(str(fname))
    if not cat:
        cat = dict(_FALLBACK_CATALOGUE_V1)

    # If the loaded file advertises a version, prefer that.
    advertised = str(cat.get("version") or "").strip()
    if advertised:
        resolved = advertised
    return cat, resolved


def ui_labels(version: Optional[str] = None) -> Dict[str, Any]:
    cat, _ = load_catalogue(version)
    ui = cat.get("ui") if isinstance(cat.get("ui"), dict) else {}
    labels = ui.get("labels") if isinstance(ui.get("labels"), dict) else {}
    return labels if isinstance(labels, dict) else {}


def resolve_entitlements(
    *,
    plan_id: str,
    version: Optional[str] = None,
    addons: Optional[list] = None,
    custom_overrides: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Resolve final entitlements from catalogue.

    This keeps entitlements data-driven:
    - base entitlements come from the plan in the catalogue
    - optional add-ons apply deltas/overrides
    - optional custom_overrides apply last
    """
    pid = (plan_id or "free").strip().lower() or "free"
    cat, resolved_version = load_catalogue(version)

    plans = cat.get("plans") if isinstance(cat.get("plans"), dict) else {}
    p = plans.get(pid) if isinstance(plans, dict) else None
    base = {}
    if isinstance(p, dict) and isinstance(p.get("entitlements"), dict):
        base = dict(p.get("entitlements") or {})

    # Always stamp plan + version for UI/debugging.
    base["plan"] = pid
    base["entitlement_version"] = resolved_version

    # Apply add-ons.
    addons_list = addons if isinstance(addons, list) else []
    if addons_list:
        addons_def = cat.get("addons") if isinstance(cat.get("addons"), dict) else {}
        for addon_id in addons_list:
            aid = str(addon_id or "").strip()
            if not aid:
                continue
            a = addons_def.get(aid) if isinstance(addons_def, dict) else None
            if not isinstance(a, dict):
                continue
            delta = a.get("entitlements_delta") if isinstance(a.get("entitlements_delta"), dict) else {}
            for k, v in (delta or {}).items():
                # Support "+N" increment for numeric limits.
                if isinstance(v, str) and v.strip().startswith("+"):
                    try:
                        inc = int(v.strip()[1:])
                        cur = int(base.get(k) or 0)
                        base[k] = cur + inc
                        continue
                    except Exception:
                        pass
                base[k] = v
        base["addons"] = addons_list

    # Apply overrides last.
    if isinstance(custom_overrides, dict) and custom_overrides:
        for k, v in custom_overrides.items():
            if k in ("sig",):
                continue
            base[k] = v

    return base
