"""
pmtvs-entropy — Entropy primitives for signal analysis.

numpy in, number out.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_entropy._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-entropy && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

# --- Public API ---
from pmtvs_entropy.core import (
    sample_entropy,
    permutation_entropy,
    approximate_entropy,
    multiscale_entropy,
    lempel_ziv_complexity,
    entropy_rate,
)

__all__ = [
    "__version__",
    "BACKEND",
    "sample_entropy",
    "permutation_entropy",
    "approximate_entropy",
    "multiscale_entropy",
    "lempel_ziv_complexity",
    "entropy_rate",
]
