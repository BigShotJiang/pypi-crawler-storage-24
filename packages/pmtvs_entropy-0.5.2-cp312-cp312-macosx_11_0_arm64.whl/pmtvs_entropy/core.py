"""
Entropy Primitives

Sample entropy, permutation entropy, approximate entropy.
These measure signal complexity and regularity.
"""

import numpy as np
from typing import Optional
from math import factorial

import pmtvs_entropy._rust as _rust


def sample_entropy(
    signal: np.ndarray,
    m: int = 2,
    r: Optional[float] = None
) -> float:
    """
    Compute sample entropy.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    m : int
        Embedding dimension
    r : float, optional
        Tolerance (default: 0.2 * std)

    Returns
    -------
    float
        Sample entropy (higher = more complex/random)
    """
    # Input normalization and edge guards
    signal = np.asarray(signal, dtype=np.float64).flatten()
    signal = signal[~np.isnan(signal)]
    n = len(signal)

    if r is None:
        r = 0.2 * np.std(signal)

    if r == 0 or n < m + 2:
        return np.nan

    return _rust.sample_entropy(signal, m, r)


def permutation_entropy(
    signal: np.ndarray,
    order: int = 3,
    delay: int = 1,
    normalize: bool = True
) -> float:
    """
    Compute permutation entropy.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    order : int
        Embedding dimension (pattern length)
    delay : int
        Time delay
    normalize : bool
        If True, normalize to [0, 1]

    Returns
    -------
    float
        Permutation entropy
    """
    signal = np.asarray(signal, dtype=np.float64).flatten()
    n = len(signal)

    if n < order * delay:
        return np.nan

    return float(_rust.permutation_entropy(signal, order, delay, normalize))


def approximate_entropy(
    signal: np.ndarray,
    m: int = 2,
    r: Optional[float] = None
) -> float:
    """
    Compute approximate entropy.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    m : int
        Embedding dimension
    r : float, optional
        Tolerance (default: 0.2 * std)

    Returns
    -------
    float
        Approximate entropy
    """
    signal = np.asarray(signal, dtype=np.float64).flatten()
    n = len(signal)

    if r is None:
        r = 0.2 * np.std(signal)

    if r == 0 or n < m + 2:
        return np.nan

    return float(_rust.approximate_entropy(signal, m, r))


def multiscale_entropy(
    signal: np.ndarray,
    m: int = 2,
    r: Optional[float] = None,
    max_scale: int = 20
) -> np.ndarray:
    """
    Compute multiscale entropy (MSE).

    Coarse-grains the signal at multiple scales and computes sample
    entropy at each scale.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    m : int
        Embedding dimension
    r : float, optional
        Tolerance (default: 0.2 * std of original signal)
    max_scale : int
        Maximum scale factor

    Returns
    -------
    np.ndarray
        Sample entropy values at each scale (1 to max_scale)
    """
    signal = np.asarray(signal, dtype=np.float64).flatten()
    signal = signal[~np.isnan(signal)]
    n = len(signal)

    if r is None:
        r = 0.2 * np.std(signal)

    max_scale = min(max_scale, n // (m + 2))
    if max_scale < 1:
        return np.array([np.nan])

    return np.asarray(_rust.multiscale_entropy(signal, m, r, max_scale))


def lempel_ziv_complexity(
    signal: np.ndarray,
    threshold: Optional[float] = None
) -> float:
    """
    Compute Lempel-Ziv complexity.

    Binarizes the signal and counts the number of distinct subsequences.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    threshold : float, optional
        Binarization threshold (default: median)

    Returns
    -------
    float
        Normalized Lempel-Ziv complexity in [0, 1]
    """
    signal = np.asarray(signal, dtype=np.float64).flatten()
    signal = signal[~np.isnan(signal)]
    n = len(signal)

    if n < 2:
        return np.nan

    if threshold is None:
        threshold = float(np.median(signal))

    return float(_rust.lempel_ziv_complexity(signal, threshold))


def entropy_rate(
    signal: np.ndarray,
    m_max: int = 10,
    r: Optional[float] = None
) -> float:
    """
    Estimate entropy rate from sample entropy convergence.

    Computes sample entropy at increasing embedding dimensions and
    estimates the asymptotic rate.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    m_max : int
        Maximum embedding dimension to try
    r : float, optional
        Tolerance (default: 0.2 * std)

    Returns
    -------
    float
        Estimated entropy rate
    """
    signal = np.asarray(signal, dtype=np.float64).flatten()
    signal = signal[~np.isnan(signal)]
    n = len(signal)

    if r is None:
        r = 0.2 * np.std(signal)

    if n < m_max + 2 or r == 0:
        return np.nan

    return float(_rust.entropy_rate(signal, m_max, r))
