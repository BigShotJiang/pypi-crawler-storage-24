"""FastAPI application for Intercom article export."""

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import PlainTextResponse, HTMLResponse, JSONResponse
from pydantic import BaseModel
from pathlib import Path
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from app.intercom import IntercomClient, IntercomAPIError
from app.filters import filter_articles
from app.exporters import export_txt, export_csv

# ── Request models ───────────────────────────────────────────────────────


class ExportRequest(BaseModel):
    token: str
    format: str = "txt"
    state: str = "published"
    include_tags: list[str] | None = None
    exclude_tags: list[str] | None = None
    include_collections: list[str] | None = None
    exclude_collections: list[str] | None = None


class TokenRequest(BaseModel):
    token: str


# ── App setup ────────────────────────────────────────────────────────────

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title="Intercom Docs Exporter")
app.state.limiter = limiter


@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(
        status_code=429,
        content={"error": "Too many requests. Please try again later."},
    )


@app.exception_handler(IntercomAPIError)
async def intercom_error_handler(request, exc):
    return JSONResponse(status_code=exc.status_code, content={"error": exc.message})

STATIC_DIR = Path(__file__).parent / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# ── Endpoints ────────────────────────────────────────────────────────────


@app.post("/api/export")
@limiter.limit("5/minute")
def export_articles(request: Request, req: ExportRequest):
    client = IntercomClient(req.token)
    articles = client.fetch_articles()
    collections = client.fetch_collections()

    filtered = filter_articles(
        articles,
        state=req.state,
        include_tags=req.include_tags,
        exclude_tags=req.exclude_tags,
        collections=collections,
        include_collections=req.include_collections,
        exclude_collections=req.exclude_collections,
    )

    if req.format == "csv":
        content = export_csv(filtered, collections)
        media_type = "text/csv"
        filename = "intercom_articles.csv"
    else:
        content = export_txt(filtered)
        media_type = "text/plain"
        filename = "intercom_articles.txt"

    return PlainTextResponse(
        content=content,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.post("/api/collections")
@limiter.limit("5/minute")
def list_collections(request: Request, req: TokenRequest):
    client = IntercomClient(req.token)
    collections = client.fetch_collections()
    return [{"id": c["id"], "name": c["name"]} for c in collections]


@app.post("/api/tags")
@limiter.limit("5/minute")
def list_tags(request: Request, req: TokenRequest):
    client = IntercomClient(req.token)
    tags = client.fetch_tags()
    return [{"id": t["id"], "name": t["name"]} for t in tags]


@app.get("/")
def root():
    index_path = STATIC_DIR / "index.html"
    if index_path.exists():
        return HTMLResponse(content=index_path.read_text())
    return HTMLResponse(
        content="<html><body><h1>Intercom Docs Exporter</h1></body></html>"
    )
