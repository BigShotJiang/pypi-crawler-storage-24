"""CLI entry point for a11y-lint.

Provides command-line interface for accessibility linting of CLI output.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from . import __version__
from .render import Renderer
from .report_md import MarkdownReporter, generate_badge_md
from .scan_cli_text import Scanner
from .scorecard import create_scorecard
from .validate import validate_json_file


@click.group()
@click.version_option(version=__version__, prog_name="a11y-lint")
def main() -> None:
    """Accessibility linter for CLI output.

    Validates that CLI error messages follow accessible patterns
    with [OK]/[WARN]/[ERROR] + What/Why/Fix structure.
    """
    pass


@main.command()
@click.argument("input", type=click.Path(exists=True), required=False)
@click.option("--stdin", is_flag=True, help="Read from stdin instead of file.")
@click.option(
    "--color",
    type=click.Choice(["auto", "always", "never"]),
    default="auto",
    help="Color output mode: auto (respects NO_COLOR), always, or never.",
)
@click.option("--json", "json_output", is_flag=True, help="Output results as JSON.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["plain", "json", "markdown"]),
    default="plain",
    help="Output format.",
)
@click.option(
    "--disable",
    multiple=True,
    help="Disable specific rules (can be used multiple times).",
)
@click.option(
    "--enable",
    multiple=True,
    help="Enable only specific rules (can be used multiple times).",
)
@click.option("--strict", is_flag=True, help="Treat warnings as errors.")
def scan(
    input: str | None,
    stdin: bool,
    color: str,
    json_output: bool,
    output_format: str,
    disable: tuple[str, ...],
    enable: tuple[str, ...],
    strict: bool,
) -> None:
    """Scan CLI text for accessibility issues.

    Reads from a file or stdin and checks for common accessibility problems.

    Examples:

        a11y-lint scan output.txt

        echo "ERROR: It failed" | a11y-lint scan --stdin

        a11y-lint scan --format=json output.txt
    """
    # Get input text
    if stdin:
        text = sys.stdin.read()
        source = "<stdin>"
    elif input:
        path = Path(input)
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            click.echo(
                f"[ERROR] Cannot read '{path}': file is not valid UTF-8 text.\n"
                f"  Why: a11y-lint only processes UTF-8 encoded text files.\n"
                f"  Fix: Convert the file to UTF-8 encoding, or check that it is a text file.",
                err=True,
            )
            sys.exit(1)
        except PermissionError:
            click.echo(
                f"[ERROR] Cannot read '{path}': permission denied.\n"
                f"  Fix: Check file permissions and try again.",
                err=True,
            )
            sys.exit(1)
        source = str(path)
    else:
        click.echo("Error: Must specify INPUT file or --stdin.", err=True)
        sys.exit(1)

    # Configure scanner
    scanner = Scanner()

    # Handle rule filtering
    if enable:
        # Enable only specified rules
        scanner.rules = []
        for rule_name in enable:
            scanner.enable_rule(rule_name)
    for rule_name in disable:
        scanner.disable_rule(rule_name)

    # Run scan
    messages = scanner.scan_text(text, file=source)

    # Handle output format
    if json_output or output_format == "json":
        result = {
            "source": source,
            "messages": [msg.to_dict() for msg in messages],
            "summary": {
                "total": len(messages),
                "errors": scanner.error_count,
                "warnings": scanner.warn_count,
            },
        }
        click.echo(json.dumps(result, indent=2))
    elif output_format == "markdown":
        reporter = MarkdownReporter(title=f"Accessibility Report: {source}")
        click.echo(reporter.render(messages))
    else:
        # Plain text output
        # Resolve color mode: auto uses environment detection, always/never are explicit
        color_enabled: bool | None = None  # None = auto
        if color == "always":
            color_enabled = True
        elif color == "never":
            color_enabled = False
        # "auto" leaves it as None, which triggers should_use_color()

        renderer = Renderer(color=color_enabled)
        renderer.write_batch(messages)
        renderer.write_summary()

    # Exit with error if issues found
    exit_code = 0
    if scanner.error_count > 0 or (strict and scanner.warn_count > 0):
        exit_code = 1

    sys.exit(exit_code)


@main.command()
@click.argument("input", type=click.Path(exists=True))
@click.option("--verbose", "-v", is_flag=True, help="Show detailed validation errors.")
def validate(input: str, verbose: bool) -> None:
    """Validate a JSON file against the CLI error schema.

    Checks that JSON messages conform to the ground truth schema.

    Examples:

        a11y-lint validate messages.json
    """
    path = Path(input)
    valid_messages, errors = validate_json_file(path)

    if errors:
        click.echo(f"[ERROR] {len(errors)} validation error(s) found:", err=True)
        if verbose:
            for err in errors:
                click.echo(f"  - {err}", err=True)
        sys.exit(1)
    else:
        click.echo(f"[OK] {len(valid_messages)} message(s) validated successfully.")
        sys.exit(0)


@main.command()
@click.argument("input", type=click.Path(exists=True), required=False)
@click.option("--stdin", is_flag=True, help="Read from stdin instead of file.")
@click.option("--name", default="CLI Assessment", help="Name for the scorecard.")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON.")
@click.option("--badge", is_flag=True, help="Generate a shields.io badge markdown.")
def scorecard(
    input: str | None,
    stdin: bool,
    name: str,
    json_output: bool,
    badge: bool,
) -> None:
    """Generate an accessibility scorecard.

    Creates a summary scorecard from scan results.

    Examples:

        a11y-lint scorecard output.txt

        a11y-lint scorecard --badge output.txt
    """
    # Get input text
    if stdin:
        text = sys.stdin.read()
        source = "<stdin>"
    elif input:
        path = Path(input)
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            click.echo(
                f"[ERROR] Cannot read '{path}': file is not valid UTF-8 text.\n"
                f"  Fix: Convert the file to UTF-8 encoding.",
                err=True,
            )
            sys.exit(1)
        except PermissionError:
            click.echo(f"[ERROR] Cannot read '{path}': permission denied.", err=True)
            sys.exit(1)
        source = str(path)
    else:
        click.echo("Error: Must specify INPUT file or --stdin.", err=True)
        sys.exit(1)

    # Scan and create scorecard
    scanner = Scanner()
    messages = scanner.scan_text(text, file=source)
    card = create_scorecard(messages, name=name)

    if json_output:
        click.echo(json.dumps(card.to_dict(), indent=2))
    elif badge:
        click.echo(generate_badge_md(card.overall_score))
    else:
        click.echo(card.summary())

    # Exit with error if not passing
    sys.exit(0 if card.is_passing else 1)


@main.command()
@click.argument("input", type=click.Path(exists=True), required=False)
@click.option("--stdin", is_flag=True, help="Read from stdin instead of file.")
@click.option("--output", "-o", type=click.Path(), help="Output file path.")
@click.option("--title", default="Accessibility Report", help="Report title.")
def report(
    input: str | None,
    stdin: bool,
    output: str | None,
    title: str,
) -> None:
    """Generate a markdown accessibility report.

    Creates a detailed markdown report from scan results.

    Examples:

        a11y-lint report output.txt -o report.md

        a11y-lint report --stdin < cli_output.txt
    """
    # Get input text
    if stdin:
        text = sys.stdin.read()
        source = "<stdin>"
    elif input:
        path = Path(input)
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            click.echo(
                f"[ERROR] Cannot read '{path}': file is not valid UTF-8 text.\n"
                f"  Fix: Convert the file to UTF-8 encoding.",
                err=True,
            )
            sys.exit(1)
        except PermissionError:
            click.echo(f"[ERROR] Cannot read '{path}': permission denied.", err=True)
            sys.exit(1)
        source = str(path)
    else:
        click.echo("Error: Must specify INPUT file or --stdin.", err=True)
        sys.exit(1)

    # Scan and generate report
    scanner = Scanner()
    messages = scanner.scan_text(text, file=source)
    reporter = MarkdownReporter(title=title)
    markdown = reporter.render(messages)

    if output:
        Path(output).write_text(markdown, encoding="utf-8")
        click.echo(f"Report written to {output}")
    else:
        click.echo(markdown)

    sys.exit(0 if not scanner.has_errors else 1)


@main.command("list-rules")
@click.option("--verbose", "-v", is_flag=True, help="Show rule categories and WCAG refs.")
def list_rules(verbose: bool) -> None:
    """List all available accessibility rules.

    Shows the names of all rules that can be enabled/disabled.
    Rules are categorized as:
    - WCAG: Mapped to WCAG success criteria (accessibility violations)
    - Policy: Best practices for cognitive accessibility
    """
    from .scan_cli_text import RULES, RuleCategory

    if verbose:
        click.echo("Available rules:\n")
        click.echo("WCAG Rules (mapped to WCAG success criteria):")
        for rule in RULES:
            if rule.category == RuleCategory.WCAG:
                wcag = f" [WCAG {rule.wcag_ref}]" if rule.wcag_ref else ""
                click.echo(f"  - {rule.name}{wcag}: {rule.description}")

        click.echo("\nPolicy Rules (cognitive accessibility best practices):")
        for rule in RULES:
            if rule.category == RuleCategory.POLICY:
                click.echo(f"  - {rule.name}: {rule.description}")

        click.echo("\nNote: Policy rules are not WCAG requirements but improve")
        click.echo("accessibility for users with cognitive disabilities.")
    else:
        click.echo("Available rules:")
        for rule in RULES:
            click.echo(f"  - {rule.name}")


@main.command()
def schema() -> None:
    """Print the CLI error JSON schema.

    Outputs the ground truth schema for CLI error messages.
    """
    schema_path = Path(__file__).parent / "schemas" / "cli.error.schema.v0.1.json"
    click.echo(schema_path.read_text(encoding="utf-8"))


@main.command()
def diagnose() -> None:
    """Check terminal accessibility environment.

    Reports whether your terminal supports accessible output:
    NO_COLOR, encoding, terminal width, and color detection.

    Examples:

        a11y-lint diagnose
    """
    import locale
    import os
    import shutil

    from .render import should_use_color
    from .scan_cli_text import RULES

    checks_passed = 0
    checks_warned = 0

    def ok(msg: str) -> None:
        nonlocal checks_passed
        checks_passed += 1
        click.echo(f"  [OK] {msg}")

    def warn(msg: str, fix: str) -> None:
        nonlocal checks_warned
        checks_warned += 1
        click.echo(f"  [WARN] {msg}")
        click.echo(f"    Fix: {fix}")

    click.echo(f"a11y-lint v{__version__} — Terminal Accessibility Diagnostic\n")

    # 1. NO_COLOR support
    click.echo("Environment:")
    no_color = os.environ.get("NO_COLOR")
    if no_color is not None:
        ok(f"NO_COLOR is set ('{no_color}') — color output disabled per https://no-color.org/")
    else:
        ok("NO_COLOR is not set — color output follows terminal detection.")

    # 2. FORCE_COLOR
    force_color = os.environ.get("FORCE_COLOR")
    if force_color is not None:
        click.echo(f"  [INFO] FORCE_COLOR is set ('{force_color}') — overrides terminal detection.")

    # 3. Color detection
    use_color = should_use_color()
    click.echo(f"  [INFO] Color output: {'enabled' if use_color else 'disabled'}")

    # 4. Encoding
    encoding = locale.getpreferredencoding(False)
    stdout_encoding = sys.stdout.encoding or "unknown"
    if stdout_encoding.lower().replace("-", "") in ("utf8", "utf_8"):
        ok(f"stdout encoding: {stdout_encoding}")
    else:
        warn(
            f"stdout encoding is '{stdout_encoding}', not UTF-8.",
            "Set PYTHONIOENCODING=utf-8 or use a UTF-8 terminal for best results.",
        )

    if encoding.lower().replace("-", "") in ("utf8", "utf_8"):
        ok(f"Locale encoding: {encoding}")
    else:
        warn(
            f"Locale encoding is '{encoding}', not UTF-8.",
            "Set your system locale to a UTF-8 variant for full accessibility support.",
        )

    # 5. Terminal width
    term_size = shutil.get_terminal_size((80, 24))
    click.echo(f"\nTerminal:")
    if term_size.columns >= 80:
        ok(f"Terminal width: {term_size.columns} columns")
    else:
        warn(
            f"Terminal width: {term_size.columns} columns (narrow).",
            "Widen your terminal to at least 80 columns for readable linter output.",
        )

    # 6. TTY detection
    is_tty = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    click.echo(f"  [INFO] stdout is {'a TTY' if is_tty else 'not a TTY (piped/redirected)'}")

    # 7. Rules summary
    click.echo(f"\nRules:")
    click.echo(f"  [INFO] {len(RULES)} rules available")
    wcag_count = sum(1 for r in RULES if r.category.value == "wcag")
    policy_count = len(RULES) - wcag_count
    click.echo(f"  [INFO] {wcag_count} WCAG-mapped, {policy_count} policy rules")

    # Summary
    click.echo(f"\nSummary: {checks_passed} passed, {checks_warned} warnings")
    if checks_warned == 0:
        click.echo("Your terminal environment looks good for accessibility linting.")
    else:
        click.echo("Some environment issues found — see [WARN] items above.")


if __name__ == "__main__":
    main()
