# CATAPA Private Python SDK

A Python client library for the CATAPA Private API with session-based authentication.

## Documentation

📚 **Full documentation, tutorials, and API reference:**

**[https://gdplabs.gitbook.io/catapa-python-private-sdk](https://gdplabs.gitbook.io/catapa-python-private-sdk)**
