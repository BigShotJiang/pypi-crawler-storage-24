"""CATAPA Private Python Client.

Main entry point for the CATAPA Private Python SDK with session-based authentication.

This package provides:
- CatapaPrivate: Main wrapper class with automatic session-based authentication.
- CatapaPrivateAuth & CatapaPrivateConfig: Authentication utilities.
- SessionClient: Low-level session-based HTTP client.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

from catapa_private.auth.catapa_private_auth import CatapaPrivateAuth, CatapaPrivateConfig
from catapa_private.client import CatapaPrivate
from catapa_private.session_client import SessionClient

__version__ = "0.1.1"
__author__ = "Catapa Team"
__email__ = "dev@catapa.com"

__all__ = [
    "CatapaPrivate",
    "CatapaPrivateAuth",
    "CatapaPrivateConfig",
    "SessionClient",
]
