"""
EDC Contract Permission V3 with header-based validation.

This module provides the base V3 implementation that validates access
based on DSP headers (DSP-AGREEMENT-ID, DSP-PARTICIPANT-ID).

Agreement ID resolution:
    In EDC, consumer and provider each generate their own UUID for the same
    contract agreement. The provider stores the consumer's ID in the
    `agreementId` field, while `@id` is the provider's own internal ID.

    The lookup order is:
    1. Query by `agreementId` field (common case: consumer sends its own ID)
    2. Direct GET by `@id` (rare: caller already has the provider's ID)
    3. Search by consumer + asset coverage (last resort)
"""

from djangoldp.permissions import LDPBasePermission
from django.conf import settings
import logging
from typing import Optional, Dict, Any

from djangoldp_edc.utils import (
    get_asset_id_from_request,
    fetch_agreement,
    fetch_agreement_by_agreement_id_field,
    fetch_agreements_by_consumer,
    is_resource_covered_by_contract,
)

logger = logging.getLogger(__name__)


class EdcContractPermissionV3(LDPBasePermission):
    """
    EDC-based permission class using Management API v3 with header-based validation.

    This permission class validates access to resources based on DSP headers:
    - DSP-AGREEMENT-ID: The contract agreement identifier
    - DSP-PARTICIPANT-ID: The participant's decentralized identifier (DID)

    The class verifies that:
    1. Both headers are present in the request
    2. The agreement exists and is valid in the EDC connector
    3. The agreement's assetId matches the requested resource
    4. The participant ID matches the agreement's consumer

    Configuration:
    - EDC_URL: Base URL of the EDC connector (required)
    - EDC_PARTICIPANT_ID: This participant's identifier (required)
    - EDC_API_KEY: API key for EDC Management API (optional, for provider-side validation)
    - EDC_AGREEMENT_VALIDATION_ENABLED: Enable/disable validation (default: True)
    - EDC_ASSET_ID_STRATEGY: Strategy for asset ID generation ('slugify', 'path', 'full_url')
    """

    # Header names following DSP conventions
    HEADER_AGREEMENT_ID = 'DSP-AGREEMENT-ID'
    HEADER_PARTICIPANT_ID = 'DSP-PARTICIPANT-ID'
    HEADER_CONSUMER_CONNECTOR_URL = 'DSP-CONSUMER-CONNECTORURL'

    @classmethod
    def get_filter_backend(cls, model):
        """Return EdcContractFilterBackend so InheritPermissions can chain EDC filtering."""
        from djangoldp_edc.filters import EdcContractFilterBackend
        return EdcContractFilterBackend

    def has_object_permission(self, request, view, obj) -> bool:
        """Validate object-level permissions based on EDC contract agreement."""
        # Only validate for safe methods (GET, HEAD, OPTIONS)
        if request.method not in ('GET', 'HEAD', 'OPTIONS'):
            logger.debug("Unsafe method %s - denying access", request.method)
            return False

        # Check if validation is enabled
        if not getattr(settings, 'EDC_AGREEMENT_VALIDATION_ENABLED', True):
            logger.warning("EDC agreement validation is disabled - allowing access")
            return True

        # Extract DSP headers
        agreement_id = self._get_header(request, self.HEADER_AGREEMENT_ID)
        participant_id = self._get_header(request, self.HEADER_PARTICIPANT_ID)

        if not agreement_id or not participant_id:
            logger.info("Missing DSP headers - agreement_id: %s, participant_id: %s",
                        bool(agreement_id), bool(participant_id))
            return False

        asset_id = self.get_asset_id(request)

        result = self.validate_agreement(
            agreement_id=agreement_id,
            participant_id=participant_id,
            asset_id=asset_id,
            request=request
        )
        logger.info("[EDC V3] %s %s agreement=%s participant=%s",
                     "ALLOWED" if result else "DENIED",
                     request.build_absolute_uri(), agreement_id, participant_id)
        return result

    def has_permission(self, request, view) -> bool:
        """Validate container/index-level permissions based on EDC contract agreement."""
        if request.method not in ('GET', 'HEAD', 'OPTIONS'):
            return False

        if not getattr(settings, 'EDC_AGREEMENT_VALIDATION_ENABLED', True):
            return True

        agreement_id = self._get_header(request, self.HEADER_AGREEMENT_ID)
        participant_id = self._get_header(request, self.HEADER_PARTICIPANT_ID)

        if not agreement_id or not participant_id:
            logger.info("Missing DSP headers for container access")
            return False

        asset_id = self.get_asset_id(request)

        return self.validate_agreement(
            agreement_id=agreement_id,
            participant_id=participant_id,
            asset_id=asset_id,
            request=request
        )

    def validate_agreement(
        self,
        agreement_id: str,
        participant_id: str,
        asset_id: str,
        request
    ) -> bool:
        """Validate that the agreement is valid for the given participant and asset."""
        try:
            agreement = self._resolve_agreement(agreement_id, participant_id, asset_id, request)

            if not agreement:
                logger.warning("No agreement found for ID=%s, consumer=%s",
                               agreement_id, participant_id)
                return False

            # Validate participant ID matches consumer
            if not self._validate_participant(agreement, participant_id):
                logger.warning("Participant mismatch - header: %s, agreement consumer: %s",
                               participant_id, agreement.get('consumerId'))
                return False

            # Validate asset coverage
            if not self._validate_asset(agreement, asset_id, request):
                logger.warning("Asset not covered - requested: %s, agreement asset: %s",
                               asset_id, agreement.get('assetId'))
                return False

            logger.info("Access granted - agreement: %s, participant: %s",
                        agreement.get('@id'), participant_id)
            return True

        except Exception as e:
            logger.error("Error validating agreement: %s", e, exc_info=True)
            return False

    def _resolve_agreement(
        self,
        agreement_id: str,
        participant_id: str,
        asset_id: str,
        request
    ) -> Optional[Dict[str, Any]]:
        """
        Resolve agreement through a 3-tier lookup, optimized for fewest requests.

        1. Query by `agreementId` field (1 POST - handles the common case where
           the consumer sends its own agreement ID, which differs from the
           provider's @id)
        2. Direct GET by `@id` (1 GET - handles the case where the caller
           already has the provider's internal ID)
        3. Search by consumer + asset coverage (1 POST + N GETs - last resort)
        """
        # Tier 1: Query by agreementId field (common case)
        agreement = fetch_agreement_by_agreement_id_field(agreement_id)
        if agreement:
            logger.debug("Agreement resolved via agreementId field lookup")
            return agreement

        # Tier 2: Direct GET by @id (in case the header contains the provider's ID)
        agreement = fetch_agreement(agreement_id)
        if agreement:
            logger.debug("Agreement resolved via direct @id lookup")
            return agreement

        # Tier 3: Search by consumer + asset (last resort)
        logger.info("Agreement %s not found by ID - searching by consumer=%s + asset",
                     agreement_id, participant_id)
        return self._find_agreement_by_consumer_and_asset(
            participant_id, asset_id, request
        )

    def _validate_participant(self, agreement: Dict[str, Any], participant_id: str) -> bool:
        """Validate that the participant ID matches the agreement's consumer."""
        consumer_id = agreement.get('consumerId')
        if not consumer_id:
            logger.warning("Agreement missing consumerId")
            return False

        if consumer_id == participant_id:
            return True

        # Handle potential formatting differences (e.g., URL encoding)
        return consumer_id.strip().lower() == participant_id.strip().lower()

    def _validate_asset(self, agreement: Dict[str, Any], asset_id: str, request) -> bool:
        """Validate that the requested resource URL is covered by the agreement's asset."""
        agreement_asset_id = agreement.get('assetId')
        if not agreement_asset_id:
            logger.warning("Agreement missing assetId")
            return False

        requested_url = request.build_absolute_uri()

        # If assetId looks like a URL, do direct matching
        if agreement_asset_id.startswith(('http://', 'https://')):
            # Exact match
            if requested_url == agreement_asset_id:
                return True

            # Subresource match
            asset_base = agreement_asset_id.rstrip('/')
            if '/index' in asset_base:
                asset_base = asset_base.rsplit('/index', 1)[0]

            requested_base = requested_url.rstrip('/')
            url_parts = requested_base.split('/')
            if url_parts and url_parts[-1].isdigit():
                requested_base = '/'.join(url_parts[:-1])

            if requested_base.startswith(asset_base + '/') or requested_base == asset_base:
                return True

            logger.debug("URL mismatch - asset: %s, requested: %s",
                         agreement_asset_id, requested_url)
            return False

        # Asset ID is not a URL - fetch asset details from EDC to check baseUrl
        return is_resource_covered_by_contract(agreement, requested_url)

    def _find_agreement_by_consumer_and_asset(
        self, participant_id: str, asset_id: str, request
    ) -> Optional[Dict[str, Any]]:
        """
        Find a provider-side agreement by consumer ID and asset coverage.

        Fetches all agreements for the given consumer and returns the first
        one whose asset covers the requested resource.
        """
        agreements = fetch_agreements_by_consumer(participant_id)
        if not agreements:
            return None

        logger.debug("Checking %d agreements for consumer %s",
                      len(agreements), participant_id)
        for agreement in agreements:
            if self._validate_asset(agreement, asset_id, request):
                logger.debug("Matched agreement %s via consumer+asset search",
                             agreement.get('@id'))
                return agreement

        return None

    def get_asset_id(self, request) -> str:
        """Generate asset ID from the request URL."""
        return get_asset_id_from_request(request)

    def _get_header(self, request, header_name: str) -> Optional[str]:
        """Extract a header value from the request, handling case-insensitivity."""
        if hasattr(request, 'headers'):
            return request.headers.get(header_name)

        # Fallback for older Django versions
        header_key = f"HTTP_{header_name.upper().replace('-', '_')}"
        return request.META.get(header_key)
