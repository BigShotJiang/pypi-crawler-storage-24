"""
EDC Inherit Permission - like DjangoLDP's InheritPermissions but excludes orphans.

Items MUST belong to at least one allowed parent to be visible.
Standalone items (not in any parent) are hidden, unlike InheritPermissions
which includes orphans via a union filter.
"""

from djangoldp.permissions import InheritPermissions, join_filter_backends, LDPBasePermission


class EdcInheritPermission(LDPBasePermission):
    """
    Like InheritPermissions but excludes items with no parent.

    This is designed for scenarios where child resources (e.g., Facts) should only
    be visible if they belong to a parent (e.g., FactBundle) that the consumer has
    access to via an EDC contract agreement.

    Key difference from InheritPermissions:
    - InheritPermissions: orphans (no parent) ARE visible (line 356: return True if no parents)
    - EdcInheritPermission: orphans are HIDDEN (must be in at least one allowed parent)
    """

    @classmethod
    def get_parent_fields(cls, model):
        return InheritPermissions.get_parent_fields(model)

    @classmethod
    def get_parent_model(cls, model, field_name):
        return InheritPermissions.get_parent_model(model, field_name)

    @classmethod
    def get_filter_backend(cls, model):
        """
        Returns a union filter backend of all parent filter backends.
        Unlike InheritPermissions, does NOT include orphan filter — items without
        a parent are excluded.
        """
        fields = cls.get_parent_fields(model)
        backends = [
            InheritPermissions.generate_filter_backend(
                cls.get_parent_model(model, field), field
            )
            for field in fields
        ]
        # NO generate_filter_backend_for_none — orphans are excluded
        return join_filter_backends(*backends, model=model, union=True)

    def has_permission(self, request, view):
        """Delegate to InheritPermissions for container-level checks."""
        return InheritPermissions().has_permission(request, view)

    def _is_edc_request(self, request):
        """Check if this is an EDC consumer request (has DSP headers)."""
        if hasattr(request, 'headers'):
            return bool(request.headers.get('DSP-PARTICIPANT-ID'))
        return bool(request.META.get('HTTP_DSP_PARTICIPANT_ID'))

    def has_object_permission(self, request, view, obj):
        """
        Like InheritPermissions but returns False when no parents exist.

        For regular users (no DSP headers): allow access (pass-through).
        For EDC consumers (DSP headers present): a fact must be in at least
        one allowed bundle; orphans are denied.
        """
        if not obj:
            return super().has_object_permission(request, view, obj)

        # Regular user without DSP headers — allow access
        if not self._is_edc_request(request):
            return True

        parents = []
        for field in InheritPermissions.get_parent_fields(view.model):
            model = InheritPermissions.get_parent_model(view.model, field)
            parent_request, parent_view = InheritPermissions.clone_with_model(request, view, model)
            for parent_object in InheritPermissions().get_parent_objects(obj, field):
                parents.append(parent_object)
                try:
                    if all(
                        perm().has_object_permission(parent_request, parent_view, parent_object)
                        for perm in model._meta.permission_classes
                    ):
                        return True
                except Exception:
                    pass

        # EDC consumer: deny if no parents or no parent granted access
        return False

    def get_permissions(self, user, model, obj=None):
        """Delegate to InheritPermissions for permission set computation."""
        return InheritPermissions().get_permissions(user, model, obj)
