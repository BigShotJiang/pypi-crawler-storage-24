"""
Utility functions for EDC integration.
"""

import requests
import logging
from typing import Optional, Dict, Any, List
from urllib.parse import urlparse
from django.conf import settings
from django.utils.text import slugify

logger = logging.getLogger(__name__)


def get_edc_url() -> Optional[str]:
    """Get EDC URL from settings."""
    return getattr(settings, 'EDC_URL', None)


def get_edc_participant_id() -> Optional[str]:
    """Get EDC participant ID from settings."""
    return getattr(settings, 'EDC_PARTICIPANT_ID', None)


def get_edc_api_key() -> Optional[str]:
    """Get EDC API key from settings."""
    return getattr(settings, 'EDC_API_KEY', None)


def _get_edc_headers() -> Optional[Dict[str, str]]:
    """Build standard EDC Management API headers. Returns None if EDC_URL is not configured."""
    edc_url = get_edc_url()
    if not edc_url:
        logger.error("EDC_URL not configured")
        return None

    headers = {'Content-Type': 'application/json'}
    edc_api_key = get_edc_api_key()
    if edc_api_key:
        headers['X-Api-Key'] = edc_api_key
    return headers


def _edc_query_spec(filter_field: str = None, filter_value: str = None) -> Dict[str, Any]:
    """Build a QuerySpec payload, optionally with a single equality filter."""
    query: Dict[str, Any] = {
        "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
        "@type": "QuerySpec",
    }
    if filter_field and filter_value:
        query["filterExpression"] = [{
            "operandLeft": filter_field,
            "operator": "=",
            "operandRight": filter_value,
        }]
    return query


def get_asset_id_from_request(request, strategy: str = None) -> str:
    """
    Generate asset ID from the request URL.

    Strategy can be configured via EDC_ASSET_ID_STRATEGY setting:
    - 'slugify' (default): Slugify the URL without resource ID
    - 'path': Use the URL path (e.g., '/objects/trial6')
    - 'full_url': Use the complete URL
    - 'container': Use only the container path
    """
    if strategy is None:
        strategy = getattr(settings, 'EDC_ASSET_ID_STRATEGY', 'slugify')

    url = request.build_absolute_uri()
    parsed_url = urlparse(url)

    if strategy == 'path':
        path_parts = parsed_url.path.strip('/').split('/')
        if path_parts and path_parts[-1].isdigit():
            path_parts = path_parts[:-1]
        return '/' + '/'.join(path_parts)

    elif strategy == 'container':
        path_parts = parsed_url.path.strip('/').split('/')
        if path_parts and path_parts[-1].isdigit():
            path_parts = path_parts[:-1]
        return path_parts[-1] if path_parts else ''

    elif strategy == 'full_url':
        path_parts = parsed_url.path.strip('/').split('/')
        if path_parts and path_parts[-1].isdigit():
            path_parts = path_parts[:-1]
        clean_path = '/'.join(path_parts)
        return f"{parsed_url.scheme}://{parsed_url.netloc}/{clean_path}"

    else:  # 'slugify' (default)
        netloc = parsed_url.hostname
        path_parts = parsed_url.path.strip('/').split('/')
        if path_parts and path_parts[-1].isdigit():
            path_parts = path_parts[:-1]
        clean_path = '/'.join(path_parts)
        port = f":{parsed_url.port}" if parsed_url.port else ""
        clean_url = f"{parsed_url.scheme}{port}//{netloc}/{clean_path}"
        return slugify(clean_url)


# ---------------------------------------------------------------------------
# Agreement fetching (used by permissions)
# ---------------------------------------------------------------------------

def fetch_agreement(agreement_id: str) -> Optional[Dict[str, Any]]:
    """
    Fetch contract agreement by @id from EDC Management API v3.

    Uses GET /v3/contractagreements/{id}.
    """
    edc_url = get_edc_url()
    headers = _get_edc_headers()
    if not edc_url or not headers:
        return None

    if not get_edc_participant_id():
        logger.error("EDC_PARTICIPANT_ID not configured")
        return None

    url = f"{edc_url}/management/v3/contractagreements/{agreement_id}"

    try:
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 404:
            logger.debug("Agreement %s not found by @id", agreement_id)
            return None
        response.raise_for_status()
        return response.json()
    except requests.exceptions.Timeout:
        logger.error("Timeout fetching agreement %s", agreement_id)
        return None
    except requests.exceptions.RequestException as e:
        logger.error("Error fetching agreement %s: %s", agreement_id, e)
        return None


def fetch_agreement_by_agreement_id_field(agreement_id: str) -> Optional[Dict[str, Any]]:
    """
    Fetch a contract agreement by its `agreementId` field (not `@id`).

    In EDC, the provider stores the consumer-side agreement ID in the
    `agreementId` field, while `@id` is the provider's own internal ID.
    Uses POST /v3/contractagreements/request with a filter on agreementId.
    """
    edc_url = get_edc_url()
    headers = _get_edc_headers()
    if not edc_url or not headers:
        return None

    url = f"{edc_url}/management/v3/contractagreements/request"
    query = _edc_query_spec("agreementId", agreement_id)

    try:
        response = requests.post(url, headers=headers, json=query, timeout=10)
        if not response.ok:
            logger.warning("agreementId field query failed: %s", response.status_code)
            return None

        agreements = response.json()
        if not isinstance(agreements, list):
            agreements = [agreements] if agreements else []

        if agreements:
            logger.debug("Resolved agreement via agreementId field: provider @id=%s",
                         agreements[0].get('@id'))
            return agreements[0]
        return None

    except requests.exceptions.Timeout:
        logger.error("Timeout querying agreements by agreementId %s", agreement_id)
        return None
    except requests.exceptions.RequestException as e:
        logger.error("Error querying agreements by agreementId %s: %s", agreement_id, e)
        return None


def fetch_agreements_by_consumer(consumer_id: str) -> List[Dict[str, Any]]:
    """
    Fetch all contract agreements for a given consumer from the provider's EDC.

    Uses POST /v3/contractagreements/request with a filter on consumerId.
    """
    edc_url = get_edc_url()
    headers = _get_edc_headers()
    if not edc_url or not headers:
        return []

    url = f"{edc_url}/management/v3/contractagreements/request"
    query = _edc_query_spec("consumerId", consumer_id)

    try:
        response = requests.post(url, headers=headers, json=query, timeout=10)
        if not response.ok:
            logger.warning("Consumer agreements query failed: %s", response.status_code)
            return []

        agreements = response.json()
        if not isinstance(agreements, list):
            agreements = [agreements] if agreements else []

        logger.debug("Found %d agreements for consumer %s", len(agreements), consumer_id)
        return agreements

    except requests.exceptions.Timeout:
        logger.error("Timeout querying agreements for consumer %s", consumer_id)
        return []
    except requests.exceptions.RequestException as e:
        logger.error("Error querying agreements for consumer %s: %s", consumer_id, e)
        return []


# ---------------------------------------------------------------------------
# Catalog / asset fetching
# ---------------------------------------------------------------------------

def fetch_catalog_entry(asset_id: str, resource_url: str = None) -> Optional[Dict[str, Any]]:
    """
    Fetch local asset and its policy from provider's EDC.

    Uses EDC Management API v3 to query LOCAL assets (not remote catalog).
    First tries exact ID match, then falls back to searching by baseUrl.
    """
    edc_url = get_edc_url()
    headers = _get_edc_headers()
    if not edc_url or not headers:
        return None

    # Try exact ID match
    try:
        asset_url = f"{edc_url}/management/v3/assets/{asset_id}"
        response = requests.get(asset_url, headers=headers, timeout=10)
        if response.status_code == 200:
            return _build_catalog_entry_from_asset(response.json(), headers, edc_url)
        logger.debug("Asset %s not found by ID (status %s)", asset_id, response.status_code)
    except requests.exceptions.RequestException as e:
        logger.error("Error fetching asset %s: %s", asset_id, e)

    # Fall back to URL match
    if resource_url:
        return fetch_catalog_entry_by_url(resource_url)
    return None


def _build_catalog_entry_from_asset(
    asset_data: Dict[str, Any], headers: Dict[str, str], edc_url: str
) -> Optional[Dict[str, Any]]:
    """Build a catalog-like entry from asset data by fetching its offers from the DSP catalog."""
    asset_id = (
        asset_data.get('@id') or
        asset_data.get('id') or
        asset_data.get('edc:id') or
        asset_data.get('https://w3id.org/edc/v0.0.1/ns/id')
    )

    try:
        catalog_entry = _fetch_catalog_offers_for_asset(asset_id, edc_url, headers)
        if catalog_entry:
            return catalog_entry
        logger.debug("No offers found in catalog for asset %s", asset_id)
        return None
    except Exception as e:
        logger.error("Error building catalog entry for %s: %s", asset_id, e, exc_info=True)
        return None


def _fetch_catalog_offers_for_asset(
    asset_id: str, edc_url: str, headers: Dict[str, str]
) -> Optional[Dict[str, Any]]:
    """Fetch catalog offers for a specific asset via DSP protocol."""
    protocol_url = edc_url.replace('/management', '') + '/protocol'
    catalog_url = f"{edc_url}/management/v3/catalog/request"

    catalog_request = {
        "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
        "@type": "CatalogRequest",
        "counterPartyAddress": protocol_url,
        "protocol": "dataspace-protocol-http",
        "querySpec": {
            "filterExpression": [{
                "operandLeft": "https://w3id.org/edc/v0.0.1/ns/id",
                "operator": "=",
                "operandRight": asset_id,
            }]
        },
    }

    try:
        response = requests.post(catalog_url, headers=headers, json=catalog_request, timeout=15)
        if response.status_code != 200:
            logger.debug("Filtered catalog request failed (%s), trying full catalog",
                         response.status_code)
            return _fetch_full_catalog_and_find_asset(asset_id, catalog_url, protocol_url, headers)

        catalog = response.json()
        datasets = catalog.get('dcat:dataset', [])
        if isinstance(datasets, dict):
            datasets = [datasets]

        for dataset in datasets:
            dataset_id = dataset.get('@id') or dataset.get('id')
            if dataset_id == asset_id:
                return dataset

        # No exact match — return first if available
        return datasets[0] if datasets else None

    except Exception as e:
        logger.error("Error fetching catalog offers for %s: %s", asset_id, e, exc_info=True)
        return None


def _fetch_full_catalog_and_find_asset(
    asset_id: str, catalog_url: str, protocol_url: str, headers: Dict[str, str]
) -> Optional[Dict[str, Any]]:
    """Fetch full catalog and find the asset (fallback when filtered query fails)."""
    catalog_request = {
        "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
        "@type": "CatalogRequest",
        "counterPartyAddress": protocol_url,
        "protocol": "dataspace-protocol-http",
    }

    try:
        response = requests.post(catalog_url, headers=headers, json=catalog_request, timeout=15)
        if response.status_code != 200:
            logger.warning("Full catalog request failed: %s", response.status_code)
            return None

        catalog = response.json()
        datasets = catalog.get('dcat:dataset', [])
        if isinstance(datasets, dict):
            datasets = [datasets]

        for dataset in datasets:
            dataset_id = dataset.get('@id') or dataset.get('id')
            if dataset_id == asset_id:
                return dataset

        logger.debug("Asset %s not found in full catalog (%d datasets)", asset_id, len(datasets))
        return None

    except Exception as e:
        logger.error("Error fetching full catalog: %s", e)
        return None


def _fetch_policy_definition(
    policy_id: str, headers: Dict[str, str], edc_url: str
) -> Optional[Dict[str, Any]]:
    """Fetch a policy definition by ID."""
    try:
        url = f"{edc_url}/management/v3/policydefinitions/{policy_id}"
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 200:
            policy_def = response.json()
            policy = policy_def.get('policy', policy_def)
            policy['@id'] = policy_id
            return policy
    except Exception as e:
        logger.debug("Error fetching policy %s: %s", policy_id, e)
    return None


def fetch_catalog_entry_by_url(resource_url: str) -> Optional[Dict[str, Any]]:
    """Fetch local asset that matches the given resource URL by baseUrl."""
    edc_url = get_edc_url()
    headers = _get_edc_headers()
    if not edc_url or not headers:
        return None

    try:
        assets_url = f"{edc_url}/management/v3/assets/request"
        payload = _edc_query_spec()
        response = requests.post(assets_url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        assets = response.json()

        # Extract base URL from resource URL (remove trailing numeric ID)
        parsed = urlparse(resource_url)
        path_parts = parsed.path.strip('/').split('/')
        if path_parts and path_parts[-1].isdigit():
            path_parts = path_parts[:-1]
        resource_base = f"{parsed.scheme}://{parsed.netloc}/{'/'.join(path_parts)}"

        for asset in assets:
            asset_id = (
                asset.get('@id') or asset.get('id') or
                asset.get('edc:id') or asset.get('https://w3id.org/edc/v0.0.1/ns/id') or
                'unknown'
            )

            if 'index' in asset_id.lower():
                continue

            data_address = asset.get('dataAddress', {}) or asset.get('edc:dataAddress', {})
            asset_base_url = (
                data_address.get('baseUrl') or
                data_address.get('edc:baseUrl') or
                data_address.get('baseurl') or
                ''
            )

            if asset_base_url:
                asset_base_stripped = asset_base_url.rstrip('/').rsplit('/index', 1)[0]
                if resource_base.startswith(asset_base_stripped) or asset_base_stripped.startswith(resource_base):
                    logger.debug("URL match: asset %s covers %s", asset_id, resource_url)
                    return _build_catalog_entry_from_asset(asset, headers, edc_url)

        logger.debug("No matching asset found for URL: %s", resource_url)
        return None

    except Exception as e:
        logger.error("Error fetching assets by URL: %s", e, exc_info=True)
        return None


# ---------------------------------------------------------------------------
# Catalog helpers
# ---------------------------------------------------------------------------

def extract_all_datasets_from_catalog(catalog: Any) -> List[Dict[str, Any]]:
    """Extract all datasets from a catalog response."""
    datasets = []

    if isinstance(catalog, list):
        for cat in catalog:
            datasets.extend(extract_all_datasets_from_catalog(cat))
    elif isinstance(catalog, dict):
        for ds in catalog.get('dcat:dataset', []):
            if ds.get('@type') == 'dcat:Catalog' and 'dcat:dataset' in ds:
                datasets.extend(extract_all_datasets_from_catalog(ds))
            else:
                datasets.append(ds)

    return datasets


def get_asset_base_url(asset_id: str) -> Optional[str]:
    """Fetch asset details and extract baseUrl from dataAddress."""
    edc_url = get_edc_url()
    headers = _get_edc_headers()
    if not edc_url or not headers:
        return None

    try:
        asset_url = f"{edc_url}/management/v3/assets/{asset_id}"
        response = requests.get(asset_url, headers=headers, timeout=5)
        if response.status_code == 200:
            asset_data = response.json()
            data_address = asset_data.get('dataAddress', {}) or asset_data.get('edc:dataAddress', {})
            return (
                data_address.get('baseUrl') or
                data_address.get('edc:baseUrl') or
                data_address.get('baseurl') or
                ''
            )
    except Exception as e:
        logger.debug("Error fetching asset %s: %s", asset_id, e)

    return None


def extract_dataset_from_catalog(catalog: Any, asset_id: str) -> Optional[Dict[str, Any]]:
    """Extract the dataset/asset from catalog response (flat or nested)."""
    if isinstance(catalog, list):
        for cat in catalog:
            result = extract_dataset_from_catalog(cat, asset_id)
            if result:
                return result
        return None

    if isinstance(catalog, dict):
        datasets = catalog.get('dcat:dataset', [])
        for dataset in datasets:
            dataset_id = dataset.get('id') or dataset.get('@id')
            if dataset_id == asset_id:
                return dataset
            if dataset.get('@type') == 'dcat:Catalog' and 'dcat:dataset' in dataset:
                inner_result = extract_dataset_from_catalog(dataset, asset_id)
                if inner_result:
                    return inner_result

    return None


# ---------------------------------------------------------------------------
# Policy helpers
# ---------------------------------------------------------------------------

def calculate_policy_openness(policy: Dict[str, Any]) -> float:
    """
    Calculate an "openness" score for a policy (0-100, higher is more open).

    Scoring: start at 100, -30/prohibition, -20/obligation, -10/permission constraint.
    """
    score = 100.0

    prohibitions = policy.get('odrl:prohibition', [])
    if isinstance(prohibitions, dict):
        prohibitions = [prohibitions]
    score -= len(prohibitions) * 30

    obligations = policy.get('odrl:obligation', [])
    if isinstance(obligations, dict):
        obligations = [obligations]
    for obligation in obligations:
        score -= 20
        constraints = obligation.get('odrl:constraint', [])
        if isinstance(constraints, dict):
            constraints = [constraints]
        score -= len(constraints) * 5

    permissions = policy.get('odrl:permission', [])
    if isinstance(permissions, dict):
        permissions = [permissions]
    for permission in permissions:
        constraints = permission.get('odrl:constraint', [])
        if isinstance(constraints, dict):
            constraints = [constraints]
        score -= len(constraints) * 10

    return max(0, score)


def describe_policy(policy: Dict[str, Any]) -> str:
    """Generate human-readable policy description."""
    parts = []

    prohibitions = policy.get('odrl:prohibition', [])
    if prohibitions:
        if isinstance(prohibitions, dict):
            prohibitions = [prohibitions]
        parts.append(f"{len(prohibitions)} prohibition(s)")

    obligations = policy.get('odrl:obligation', [])
    if obligations:
        if isinstance(obligations, dict):
            obligations = [obligations]
        parts.append(f"{len(obligations)} obligation(s)")

    permissions = policy.get('odrl:permission', [])
    if permissions:
        if isinstance(permissions, dict):
            permissions = [permissions]
        constraint_count = sum(
            len(p.get('odrl:constraint', []) if isinstance(p.get('odrl:constraint', []), list) else [p.get('odrl:constraint')])
            for p in permissions if p.get('odrl:constraint')
        )
        if constraint_count > 0:
            parts.append(f"{constraint_count} constraint(s)")

    if not parts:
        return "Open access policy with no restrictions"
    return "Policy with " + ", ".join(parts)


# ---------------------------------------------------------------------------
# Contract validation helpers
# ---------------------------------------------------------------------------

def is_contract_valid(contract_data: Dict[str, Any]) -> bool:
    """Check if the contract agreement is valid (not expired, properly signed, etc.)."""
    contract_state = (
        contract_data.get('state') or
        contract_data.get('edc:state') or
        contract_data.get('contractAgreement', {}).get('state') or
        contract_data.get('contractAgreement', {}).get('edc:state')
    )

    # If no state field, assume valid (we got it from the API, so it exists)
    if contract_state is None:
        logger.warning("No state field found in contract data, assuming valid")
        return True

    valid_states = ['FINALIZED', 'VERIFIED', 'CONFIRMED', 'AGREED']
    if contract_state not in valid_states:
        logger.warning("Contract state '%s' not in valid states %s", contract_state, valid_states)
        return False

    return True


def is_resource_covered_by_contract(contract_data: Dict[str, Any], requested_url: str) -> bool:
    """Check if the requested resource URL is covered by the contract agreement's asset."""
    # Extract asset ID
    asset_id = (
        contract_data.get('assetId') or
        contract_data.get('edc:assetId') or
        contract_data.get('@id') or
        contract_data.get('contractAgreement', {}).get('assetId') or
        ''
    )

    # Fall back to policy target
    if not asset_id:
        policy_target = (
            contract_data.get('policy', {}).get('target') or
            contract_data.get('edc:policy', {}).get('target') or
            contract_data.get('edc:policy', {}).get('edc:target')
        )
        if policy_target:
            asset_id = policy_target
        else:
            logger.warning("No assetId or policy target found in contract")
            return False

    # If asset_id is a URL, do direct matching
    if asset_id.startswith(('http://', 'https://')):
        if requested_url == asset_id:
            return True
        asset_base = asset_id.rsplit('/index', 1)[0] if '/index' in asset_id else asset_id
        if requested_url.startswith(asset_base + '/'):
            return True
        logger.debug("URL mismatch - asset: %s, requested: %s", asset_id, requested_url)
        return False

    # Asset ID is not a URL — fetch asset details to get baseUrl
    edc_url = get_edc_url()
    headers = _get_edc_headers()
    if not edc_url or not headers:
        return False

    try:
        asset_url = f"{edc_url}/management/v3/assets/{asset_id}"
        asset_response = requests.get(asset_url, headers=headers, timeout=5)
        asset_response.raise_for_status()
        asset_data = asset_response.json()

        data_address = asset_data.get('dataAddress', {}) or asset_data.get('edc:dataAddress', {})
        base_url = (
            data_address.get('baseUrl') or
            data_address.get('edc:baseUrl') or
            data_address.get('baseurl') or
            data_address.get('edc:baseurl') or
            ''
        )

        if not base_url:
            logger.warning("No baseUrl in asset %s dataAddress", asset_id)
            return False

        if requested_url == base_url:
            return True

        base_url_stripped = base_url.rsplit('/index', 1)[0] if '/index' in base_url else base_url
        base_url_stripped = base_url_stripped.rstrip('/')

        if requested_url.startswith(base_url_stripped + '/'):
            return True

        logger.debug("URL mismatch - base: %s, requested: %s", base_url, requested_url)
        return False

    except requests.exceptions.RequestException as e:
        logger.error("Error fetching asset %s: %s", asset_id, e)
        return False
    except Exception as e:
        logger.error("Unexpected error checking asset coverage: %s", e, exc_info=True)
        return False
