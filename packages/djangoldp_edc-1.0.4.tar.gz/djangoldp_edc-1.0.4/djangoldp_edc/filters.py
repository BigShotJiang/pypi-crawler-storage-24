"""
EDC Contract Filter Backend for DjangoLDP.

Provides a DRF filter backend that filters querysets based on EDC contract agreements.
Used by EdcInheritPermission to filter child resources (e.g., Facts) based on
whether their parent (e.g., FactBundle) is covered by a signed agreement.
"""

import logging
from urllib.parse import urlparse

from django.core.cache import cache
from rest_framework.filters import BaseFilterBackend

from djangoldp_edc.utils import (
    fetch_agreements_by_consumer,
    get_asset_base_url,
)

logger = logging.getLogger(__name__)

# Cache TTL for agreement lookups (seconds)
AGREEMENT_CACHE_TTL = 60


class EdcContractFilterBackend(BaseFilterBackend):
    """
    Filter backend that returns only model instances covered by a signed EDC agreement.

    Extracts DSP-PARTICIPANT-ID from the request, fetches all agreements for that
    consumer, resolves which model instances are covered (via asset baseUrl → PK),
    and filters the queryset accordingly.

    If no DSP-PARTICIPANT-ID header is present, the request is not an EDC consumer
    request — return the unfiltered queryset (pass-through for regular users).
    """

    def filter_queryset(self, request, queryset, view):
        participant_id = self._get_participant_id(request)
        if not participant_id:
            logger.debug("[EdcContractFilterBackend] No DSP-PARTICIPANT-ID header - pass-through")
            return queryset

        allowed_pks = self._get_allowed_pks(participant_id, queryset)
        logger.debug(
            "[EdcContractFilterBackend] consumer=%s, allowed PKs=%s",
            participant_id, allowed_pks,
        )
        return queryset.filter(pk__in=allowed_pks)

    def _get_participant_id(self, request):
        """Extract DSP-PARTICIPANT-ID from request headers."""
        if hasattr(request, 'headers'):
            return request.headers.get('DSP-PARTICIPANT-ID')
        # Fallback for older Django versions
        return request.META.get('HTTP_DSP_PARTICIPANT_ID')

    def _get_allowed_pks(self, participant_id, queryset):
        """
        Get the set of PKs from the queryset's model that are covered by agreements
        for the given consumer. Results are cached for AGREEMENT_CACHE_TTL seconds.
        """
        model = queryset.model
        cache_key = f"edc_filter:{participant_id}:{model._meta.label}"
        cached = cache.get(cache_key)
        if cached is not None:
            return cached

        agreements = fetch_agreements_by_consumer(participant_id)
        if not agreements:
            cache.set(cache_key, set(), AGREEMENT_CACHE_TTL)
            return set()

        allowed_pks = set()
        for agreement in agreements:
            pk = self._resolve_pk_from_agreement(agreement, model)
            if pk is not None:
                allowed_pks.add(pk)

        cache.set(cache_key, allowed_pks, AGREEMENT_CACHE_TTL)
        return allowed_pks

    def _resolve_pk_from_agreement(self, agreement, model):
        """
        Resolve which model instance PK is covered by this agreement.

        Strategy:
        1. If assetId is a URL, parse the PK from the URL path
        2. Otherwise, call get_asset_base_url(assetId) to get the baseUrl, then parse PK
        """
        asset_id = (
            agreement.get('assetId')
            or agreement.get('edc:assetId')
            or ''
        )
        if not asset_id:
            return None

        # If assetId is already a URL, parse PK from it
        if asset_id.startswith(('http://', 'https://')):
            return self._parse_pk_from_url(asset_id)

        # Otherwise, fetch asset details to get baseUrl
        base_url = get_asset_base_url(asset_id)
        if base_url:
            return self._parse_pk_from_url(base_url)

        return None

    def _parse_pk_from_url(self, url):
        """
        Parse the PK (last numeric path segment) from a URL.

        Examples:
            https://example.com/factbundles/5/ → 5
            https://example.com/factbundles/5/index → 5
        """
        parsed = urlparse(url)
        path_parts = parsed.path.strip('/').split('/')

        # Strip trailing 'index' if present
        if path_parts and path_parts[-1] == 'index':
            path_parts = path_parts[:-1]

        # The last segment should be the PK
        if path_parts and path_parts[-1].isdigit():
            return int(path_parts[-1])

        return None
