from __future__ import annotations

import msgspec

from grim.assets import RuntimeResources
from grim.config import CrimsonConfig
from grim.geom import Vec2
from grim.terrain_render import GroundRenderer

from ..creatures.runtime import CreaturePool
from ..gameplay import GameplayState
from ..sim.state_types import PlayerState
from .rtx.mode import RtxRenderMode


class RenderFrame(msgspec.Struct, frozen=True):
    """Typed world snapshot consumed by render code.

    This intentionally carries references (not deep copies) so render can be
    deterministic per frame boundary while remaining allocation-light.
    """

    world_size: float
    demo_mode_active: bool
    config: CrimsonConfig | None
    camera: Vec2
    ground: GroundRenderer | None

    state: GameplayState
    players: list[PlayerState]
    creatures: CreaturePool
    resources: RuntimeResources

    elapsed_ms: float
    bonus_anim_phase: float
    lan_player_rings_enabled: bool
    lan_local_aim_indicators_only: bool
    lan_local_player_slot_index: int
    rtx_mode: RtxRenderMode
