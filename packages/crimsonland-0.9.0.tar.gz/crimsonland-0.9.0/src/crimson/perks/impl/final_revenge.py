from __future__ import annotations

from typing import TYPE_CHECKING

from grim.geom import Vec2
from grim.sfx_map import SfxId

from ...creatures.damage_types import CreatureDamageType
from ...effects import FxQueue
from ...owner_ref import OwnerRef
from ...sim.state_types import GameplayState, PlayerState
from ..helpers import perk_active
from ..ids import PerkId
from ..runtime.hook_types import PerkHooks

if TYPE_CHECKING:
    from ...creatures.runtime import CreatureDeath, CreaturePool


def apply_final_revenge_on_player_death(
    *,
    state: GameplayState,
    creatures: CreaturePool,
    players: list[PlayerState],
    player: PlayerState,
    dt: float,
    world_size: float,
    detail_preset: int,
    fx_queue: FxQueue | None,
    deaths: list[CreatureDeath],
) -> None:
    """Apply Final Revenge perk behavior when a player dies."""
    from ...creatures.damage import creature_apply_damage_with_lethal_followup

    if not perk_active(player, PerkId.FINAL_REVENGE):
        return

    player_pos = player.pos
    state.effects.spawn_explosion_burst(
        pos=player_pos,
        scale=1.8,
        rng=state.rng,
        detail_preset=int(detail_preset),
    )

    prev_guard = bool(state.bonus_spawn_guard)
    state.bonus_spawn_guard = True
    for creature_idx, creature in enumerate(creatures.entries):
        if not creature.active:
            continue

        delta = creature.pos - player_pos
        if abs(delta.x) > 512.0 or abs(delta.y) > 512.0:
            continue

        remaining = 512.0 - delta.length()
        if remaining <= 0.0:
            continue

        damage = remaining * 5.0
        death_creature_idx = int(creature_idx)
        creature_apply_damage_with_lethal_followup(
            creature,
            damage_amount=damage,
            damage_type=CreatureDamageType.EXPLOSION,
            impulse=Vec2(),
            owner=OwnerRef.from_player(int(player.index)),
            dt=float(dt),
            players=players,
            rng=state.rng,
            preserve_bugs=bool(state.preserve_bugs),
            effects=state.effects,
            detail_preset=int(detail_preset),
            on_lethal=lambda death_sfx, death_creature_idx=death_creature_idx: (
                deaths.append(
                    creatures.handle_death(
                        int(death_creature_idx),
                        state=state,
                        players=players,
                        rng=state.rng,
                        dt=float(dt),
                        detail_preset=int(detail_preset),
                        world_width=float(world_size),
                        world_height=float(world_size),
                        fx_queue=fx_queue,
                    ),
                ),
                state.sfx_queue.extend(death_sfx),
            ),
        )

    state.bonus_spawn_guard = prev_guard
    state.sfx_queue.append(SfxId.EXPLOSION_LARGE)
    state.sfx_queue.append(SfxId.SHOCKWAVE)


HOOKS = PerkHooks(
    perk_id=PerkId.FINAL_REVENGE,
    player_death_hook=apply_final_revenge_on_player_death,
)
