"""
a.k.a Clean Slate Utils
"""

__version__ = "2.0.5"
