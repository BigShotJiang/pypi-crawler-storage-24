"""Unit tests configuration file."""
