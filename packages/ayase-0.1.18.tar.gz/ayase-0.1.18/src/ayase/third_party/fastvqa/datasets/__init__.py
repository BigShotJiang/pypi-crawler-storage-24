# This source code is licensed under the S-Lab License 1.0 found in the
# LICENSE file in the current directory's parent directory.
"""
The code has been adopted from FAST-VQA-and-FasterVQA
(https://github.com/VQAssessment/FAST-VQA-and-FasterVQA/blob/dev/fastvqa/datasets/__init__.py)
"""

## Version 0.0 Dataset API, includes FAST-VQA and its variants
from .basic_datasets import (
    FastVQAPlusPlusDataset,
    FragmentVideoDataset,
    FragmentImageDataset,
    ResizedVideoDataset,
    ResizedImageDataset,
    CroppedVideoDataset,
    CroppedImageDataset,
    SampleFrames,
    FragmentSampleFrames,
)

## Version 1.0 Dataset API, includes DiViDe VQA and its variants
from .fusion_datasets import (
    get_spatial_fragments,
    SimpleDataset,
    FusionDataset,
    LSVQPatchDataset,
    FusionDatasetK400,
)


__all__ = [
    "FragmentVideoDataset",
    "FragmentImageDataset",
    "ResizedVideoDataset",
    "ResizedImageDataset",
    "CroppedVideoDataset",
    "CroppedImageDataset",
    "LSVQPatchDataset",
    "get_spatial_fragments",
    "SampleFrames",
    "FragmentSampleFrames",
    "SimpleDataset",
    "FusionDatasetK400",
    "FusionDataset",
]
