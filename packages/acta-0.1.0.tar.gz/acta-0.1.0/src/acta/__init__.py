"""ACTA — file-based async message passing for AI agents.

Agents are commodity instances. Skills are the identity.
Files are the communication layer. No server, no framework.

Usage:
    from acta import post, read, clear, archive

    post("Found NAV discrepancy", sender="avantis-verify", to="terry", severity="action")
    msgs = read(to="terry")
    clear(msgs[0]["id"])
"""

from acta.board import post, read, clear, clear_all, archive, archive_all, count

__all__ = ["post", "read", "clear", "clear_all", "archive", "archive_all", "count"]
__version__ = "0.1.0"
