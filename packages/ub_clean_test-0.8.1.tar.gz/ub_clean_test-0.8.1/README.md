# ub-clean-test

[中文版](#chinese) | [English](#english)

---

## 中文版

一个模块化的机器人控制框架。

### 功能
- **基础控制**：PID、LQR、自适应控制
- **运动学**：逆运动学（速度级、位置级）
- **轨迹规划**：五次多项式平滑运动
- **路径规划**：RRT 快速扩展随机树
- **强化学习**：PPO 近端策略优化

### 安装
pip install ub-clean-test

### 快速开始
from ultra_balance import create_robot
robot = create_robot('two_wheel')
robot.start()

---

## English Version

A modular robot control framework.

### Features
- **Control**: PID, LQR, adaptive control
- **Kinematics**: Forward/Inverse kinematics
- **Trajectory Planning**: Quintic polynomial
- **Path Planning**: RRT (Rapidly-exploring Random Tree)
- **Reinforcement Learning**: PPO (Proximal Policy Optimization)

### Installation
pip install ub-clean-test

### Quick Start
from ultra_balance import create_robot
robot = create_robot('two_wheel')
robot.start()

### Modules
- `core/`: Core algorithms (Kalman filter, PID, etc.)
- `planning/`: Path planning (A*, RRT)
- `learning/`: Reinforcement learning (PPO)

### Examples
- `demo_trajectory.py`: Trajectory planning demo
- `demo_rrt.py`: RRT path planning demo
- `demo_ppo.py`: PPO reinforcement learning demo




