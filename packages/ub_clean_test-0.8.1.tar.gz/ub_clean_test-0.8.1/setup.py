from setuptools import setup, find_packages

setup(
    name="ub-clean-test",
    version="0.8.1",
    author="pengyeqin",
    author_email="xxbj433@qq.com",
    description="机器人控制框架",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.21.0",
        "scipy>=1.7.0",
    ],
)