"""Tests for the core TokBurn components."""

import json
from pathlib import Path

from tokburn.analyzer import analyze_sessions, detect_repeated_reads
from tokburn.cost import calculate_cost, normalize_model_id
from tokburn.parsers.claude_code import ClaudeCodeParser

# ─── Cost Engine Tests ───


def test_normalize_model_id_strips_date():
    assert normalize_model_id("claude-sonnet-4-5-20250929") == "claude-sonnet-4-5"
    assert normalize_model_id("claude-opus-4-0-20260115") == "claude-opus-4-0"


def test_normalize_model_id_no_date():
    assert normalize_model_id("claude-sonnet-4-5") == "claude-sonnet-4-5"
    assert normalize_model_id("gpt-4o") == "gpt-4o"


def test_calculate_cost_known_model():
    tc = calculate_cost("claude-sonnet-4-5", input_tokens=1_000_000, output_tokens=500_000)
    assert tc.input_cost == 3.00  # $3/M input
    assert tc.output_cost == 7.50  # $15/M output * 0.5M
    assert tc.total_cost == 10.50


def test_calculate_cost_with_date_suffix():
    tc = calculate_cost("claude-sonnet-4-5-20250929", input_tokens=100_000, output_tokens=50_000)
    assert tc.input_cost > 0
    assert tc.output_cost > 0


def test_calculate_cost_unknown_model():
    tc = calculate_cost("unknown-model-xyz", input_tokens=1000, output_tokens=500)
    assert tc.total_cost == 0.0
    assert tc.input_tokens == 1000
    assert tc.output_tokens == 500


def test_calculate_cost_sonnet_4_6():
    """Regression: claude-sonnet-4-6 (no date suffix) must resolve to non-zero cost."""
    tc = calculate_cost("claude-sonnet-4-6", input_tokens=1_000_000, output_tokens=500_000)
    assert tc.input_cost == 3.00
    assert tc.output_cost == 7.50
    assert tc.total_cost == 10.50


def test_calculate_cost_haiku_with_date_suffix():
    """Regression: claude-haiku-4-5-20251001 strips date → claude-haiku-4-5 → non-zero cost."""
    tc = calculate_cost("claude-haiku-4-5-20251001", input_tokens=1_000_000, output_tokens=500_000)
    assert tc.input_cost == 0.80
    assert tc.output_cost == 2.00
    assert tc.total_cost == 2.80


def test_calculate_cost_with_cache():
    tc = calculate_cost(
        "claude-sonnet-4-5",
        input_tokens=100_000,
        output_tokens=50_000,
        cache_read_tokens=200_000,
        cache_write_tokens=10_000,
    )
    assert tc.cache_read_cost > 0
    assert tc.cache_write_cost > 0
    assert tc.total_cost > tc.input_cost + tc.output_cost


# ─── Parser Tests ───


def _make_session_jsonl(messages: list[dict]) -> str:
    """Create a JSONL string from a list of message dicts."""
    return "\n".join(json.dumps(m) for m in messages)


def _create_test_session(tmp_path: Path, project: str = "test-project", session_id: str = "abc123"):
    """Create a fake session file structure and return the JSONL path."""
    project_dir = tmp_path / project / "sessions"
    project_dir.mkdir(parents=True, exist_ok=True)
    filepath = project_dir / f"{session_id}.jsonl"

    messages = [
        {
            "type": "user",
            "sessionId": session_id,
            "timestamp": "2026-03-20T10:00:00Z",
            "message": {"role": "user", "content": "Fix the auth bug in src/auth.py"},
        },
        {
            "type": "assistant",
            "sessionId": session_id,
            "timestamp": "2026-03-20T10:00:05Z",
            "model": "claude-sonnet-4-5-20250929",
            "message": {
                "role": "assistant",
                "content": [
                    {"type": "text", "text": "Let me look at the auth module..."},
                    {
                        "type": "tool_use",
                        "id": "tu_1",
                        "name": "Read",
                        "input": {"file_path": "src/auth.py"},
                    },
                ],
            },
            "usage": {
                "input_tokens": 5000,
                "output_tokens": 200,
                "cache_read_input_tokens": 1000,
                "cache_creation_input_tokens": 0,
            },
        },
        {
            "type": "tool_result",
            "sessionId": session_id,
            "timestamp": "2026-03-20T10:00:06Z",
            "content": "def validate_token(token: str): ...",
        },
        {
            "type": "assistant",
            "sessionId": session_id,
            "timestamp": "2026-03-20T10:00:10Z",
            "model": "claude-sonnet-4-5-20250929",
            "message": {
                "role": "assistant",
                "content": [
                    {"type": "text", "text": "I see the issue. Let me read the config too..."},
                    {
                        "type": "tool_use",
                        "id": "tu_2",
                        "name": "Read",
                        "input": {"file_path": "src/auth.py"},
                    },
                    {
                        "type": "tool_use",
                        "id": "tu_3",
                        "name": "Read",
                        "input": {"file_path": "src/auth.py"},
                    },
                    {
                        "type": "tool_use",
                        "id": "tu_4",
                        "name": "Read",
                        "input": {"file_path": "src/config.py"},
                    },
                ],
            },
            "usage": {
                "input_tokens": 8000,
                "output_tokens": 500,
                "cache_read_input_tokens": 2000,
                "cache_creation_input_tokens": 100,
            },
        },
        {
            "type": "assistant",
            "sessionId": session_id,
            "timestamp": "2026-03-20T10:01:00Z",
            "model": "claude-sonnet-4-5-20250929",
            "message": {
                "role": "assistant",
                "content": [
                    {
                        "type": "tool_use",
                        "id": "tu_5",
                        "name": "Read",
                        "input": {"file_path": "src/auth.py"},
                    },
                    {
                        "type": "tool_use",
                        "id": "tu_6",
                        "name": "Edit",
                        "input": {"file_path": "src/auth.py"},
                    },
                ],
            },
            "usage": {
                "input_tokens": 4000,
                "output_tokens": 800,
                "cache_read_input_tokens": 500,
                "cache_creation_input_tokens": 0,
            },
        },
    ]

    filepath.write_text(_make_session_jsonl(messages))
    return filepath


def test_parser_discovers_sessions(tmp_path):
    _create_test_session(tmp_path, project="my-project", session_id="sess1")
    _create_test_session(tmp_path, project="my-project", session_id="sess2")
    _create_test_session(tmp_path, project="other-project", session_id="sess3")

    parser = ClaudeCodeParser(base_dir=tmp_path)
    files = parser.discover_sessions()
    assert len(files) == 3


def test_parser_parses_session(tmp_path):
    filepath = _create_test_session(tmp_path)
    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)

    assert session is not None
    assert session.session_id == "abc123"
    assert session.agent == "claude_code"
    assert session.message_count > 0
    assert session.total_input_tokens > 0
    assert session.total_output_tokens > 0
    assert "Fix the auth bug" in session.summary


def test_parser_extracts_tool_calls(tmp_path):
    filepath = _create_test_session(tmp_path)
    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)

    tool_summary = session.tool_call_summary
    assert "Read" in tool_summary
    assert tool_summary["Read"] >= 4  # auth.py read multiple times + config.py
    assert "Edit" in tool_summary


def test_parser_extracts_files_read(tmp_path):
    filepath = _create_test_session(tmp_path)
    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)

    files = session.files_read
    assert "src/auth.py" in files
    assert "src/config.py" in files
    assert files.count("src/auth.py") >= 3  # Read multiple times


def test_parser_extracts_timestamps(tmp_path):
    filepath = _create_test_session(tmp_path)
    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)

    assert session.started_at is not None
    assert session.ended_at is not None
    assert session.ended_at > session.started_at


def test_parser_handles_empty_file(tmp_path):
    project_dir = tmp_path / "empty-project" / "sessions"
    project_dir.mkdir(parents=True, exist_ok=True)
    filepath = project_dir / "empty.jsonl"
    filepath.write_text("")

    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)
    assert session is None


def test_parser_handles_malformed_json(tmp_path):
    project_dir = tmp_path / "bad-project" / "sessions"
    project_dir.mkdir(parents=True, exist_ok=True)
    filepath = project_dir / "bad.jsonl"
    filepath.write_text("not json\n{invalid\n")

    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)
    assert session is None  # No valid messages


def test_parser_nested_model_and_usage(tmp_path):
    """Regression: real JSONL has model/usage inside record.message, not at top level."""
    project_dir = tmp_path / "real-project"
    project_dir.mkdir(parents=True)
    filepath = project_dir / "nested-sess.jsonl"

    records = [
        {
            "type": "user",
            "sessionId": "nested-sess",
            "timestamp": "2026-03-20T10:00:00Z",
            "message": {"role": "user", "content": "Hello"},
        },
        {
            "type": "assistant",
            "sessionId": "nested-sess",
            "timestamp": "2026-03-20T10:00:05Z",
            # model and usage are nested inside message (real format)
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6",
                "content": [{"type": "text", "text": "Hi there"}],
                "usage": {
                    "input_tokens": 500,
                    "output_tokens": 100,
                    "cache_read_input_tokens": 0,
                    "cache_creation_input_tokens": 0,
                },
            },
        },
    ]
    filepath.write_text("\n".join(json.dumps(r) for r in records))

    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)

    assert session is not None
    assert session.total_input_tokens == 500
    assert session.total_output_tokens == 100
    # Model was correctly extracted from nested message.model
    assert "claude-sonnet-4-6" in session.models_used


def test_parser_discovers_subagent_sessions(tmp_path):
    """Regression: subagent JSONL files under <session-id>/subagents/ must be discovered."""
    project_dir = tmp_path / "my-project"
    session_subdir = project_dir / "main-session-id" / "subagents"
    session_subdir.mkdir(parents=True)
    subagent_file = session_subdir / "agent-abc.jsonl"
    subagent_file.write_text(
        json.dumps(
            {
                "type": "user",
                "sessionId": "agent-abc",
                "timestamp": "2026-03-20T10:00:00Z",
                "message": {"role": "user", "content": "subagent task"},
            }
        )
    )

    parser = ClaudeCodeParser(base_dir=tmp_path)
    files = parser.discover_sessions()
    assert subagent_file in files


# ─── Analyzer Tests ───


def test_detect_repeated_reads(tmp_path):
    filepath = _create_test_session(tmp_path)
    parser = ClaudeCodeParser(base_dir=tmp_path)
    session = parser.parse_session(filepath)

    insights = detect_repeated_reads(session)
    # src/auth.py was read 4 times — should trigger
    auth_insights = [i for i in insights if "auth.py" in i.title]
    assert len(auth_insights) > 0
    assert auth_insights[0].type == "repeated_reads"
    assert auth_insights[0].estimated_waste_tokens > 0


def test_analyze_sessions_full_pipeline(tmp_path):
    _create_test_session(tmp_path, session_id="s1")
    _create_test_session(tmp_path, session_id="s2")

    parser = ClaudeCodeParser(base_dir=tmp_path)
    sessions = parser.parse_all()
    insights = analyze_sessions(sessions)

    # Should have at least repeated_reads insights
    assert len(insights) > 0
    assert all(hasattr(i, "type") for i in insights)
    assert all(hasattr(i, "severity") for i in insights)
