"""FastAPI server — serves the REST API and the static dashboard.

Endpoints:
  GET /                        → Dashboard HTML
  GET /api/sessions            → All sessions with cost summaries
  GET /api/sessions/{id}       → Single session detail
  GET /api/stats               → Aggregate statistics
  GET /api/insights            → Waste detection insights
  GET /api/projects            → Per-project cost breakdown
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from tokburn.analyzer import analyze_sessions
from tokburn.cost import calculate_cost
from tokburn.parsers.claude_code import ClaudeCodeParser

logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(
    title="TokBurn",
    description="See where your AI coding agent tokens actually go.",
    version="0.1.0",
)

# Cache parsed sessions (refreshed on demand)
_sessions_cache: list | None = None
_cache_time: datetime | None = None
CACHE_TTL_SECONDS = 30  # Re-parse every 30 seconds at most


def _get_sessions(force_refresh: bool = False) -> list:
    """Parse all sessions, with simple time-based caching."""
    global _sessions_cache, _cache_time

    now = datetime.now()
    if (
        not force_refresh
        and _sessions_cache is not None
        and _cache_time is not None
        and (now - _cache_time).total_seconds() < CACHE_TTL_SECONDS
    ):
        return _sessions_cache

    parser = ClaudeCodeParser()
    _sessions_cache = parser.parse_all()
    _cache_time = now
    logger.info("Parsed %d sessions", len(_sessions_cache))
    return _sessions_cache


def _session_cost(session) -> dict:
    """Compute cost breakdown for a session."""
    total_cost = 0.0
    model_costs: dict[str, float] = {}

    for msg in session.messages:
        if msg.model:
            tc = calculate_cost(
                msg.model,
                input_tokens=msg.input_tokens,
                output_tokens=msg.output_tokens,
                cache_read_tokens=msg.cache_read_tokens,
                cache_write_tokens=msg.cache_write_tokens,
            )
            total_cost += tc.total_cost
            model_costs[msg.model] = model_costs.get(msg.model, 0) + tc.total_cost

    return {
        "total_cost": round(total_cost, 4),
        "model_costs": {k: round(v, 4) for k, v in model_costs.items()},
    }


def _session_to_summary(session) -> dict:
    """Convert a Session to a JSON-serializable summary dict."""
    cost = _session_cost(session)
    return {
        "session_id": session.session_id,
        "project": session.project_path,
        "agent": session.agent,
        "summary": session.summary,
        "started_at": session.started_at.isoformat() if session.started_at else None,
        "ended_at": session.ended_at.isoformat() if session.ended_at else None,
        "duration_seconds": session.duration_seconds,
        "message_count": session.message_count,
        "total_tokens": session.total_tokens,
        "input_tokens": session.total_input_tokens,
        "output_tokens": session.total_output_tokens,
        "cache_read_tokens": session.total_cache_read_tokens,
        "cache_write_tokens": session.total_cache_write_tokens,
        "models_used": list(session.models_used),
        "tool_calls": session.tool_call_summary,
        **cost,
    }


# ─── API Routes ───


@app.get("/api/sessions")
async def list_sessions():
    """List all sessions with cost summaries, sorted by most recent first."""
    sessions = _get_sessions()
    summaries = [_session_to_summary(s) for s in sessions]
    summaries.sort(key=lambda s: s["total_cost"], reverse=True)
    return {"sessions": summaries, "count": len(summaries)}


@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str):
    """Get detailed info for a single session."""
    sessions = _get_sessions()
    session = next((s for s in sessions if s.session_id == session_id), None)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    detail = _session_to_summary(session)
    # Add per-file read counts
    from collections import Counter

    file_reads = Counter(session.files_read)
    detail["file_reads"] = dict(file_reads.most_common(20))
    return detail


@app.get("/api/stats")
async def get_stats():
    """Aggregate statistics across all sessions."""
    sessions = _get_sessions()
    if not sessions:
        return {"total_sessions": 0, "total_cost": 0, "total_tokens": 0}

    total_cost = 0.0
    total_tokens = 0
    daily_costs: dict[str, float] = {}
    project_costs: dict[str, float] = {}

    for s in sessions:
        cost = _session_cost(s)
        total_cost += cost["total_cost"]
        total_tokens += s.total_tokens

        # Daily aggregation
        if s.started_at:
            day = s.started_at.strftime("%Y-%m-%d")
            daily_costs[day] = daily_costs.get(day, 0) + cost["total_cost"]

        # Per-project aggregation
        project_costs[s.project_path] = project_costs.get(s.project_path, 0) + cost["total_cost"]

    total_input = sum(s.total_input_tokens for s in sessions)
    total_output = sum(s.total_output_tokens for s in sessions)
    total_cache_read = sum(s.total_cache_read_tokens for s in sessions)
    total_cache_write = sum(s.total_cache_write_tokens for s in sessions)

    return {
        "total_sessions": len(sessions),
        "total_cost": round(total_cost, 2),
        "total_tokens": total_tokens,
        "daily_costs": {k: round(v, 4) for k, v in sorted(daily_costs.items())},
        "project_costs": {
            k: round(v, 4) for k, v in sorted(project_costs.items(), key=lambda x: -x[1])
        },
        "total_input_tokens": total_input,
        "total_output_tokens": total_output,
        "total_cache_read_tokens": total_cache_read,
        "total_cache_write_tokens": total_cache_write,
    }


@app.get("/api/insights")
async def get_insights():
    """Run waste detection analysis and return actionable insights."""
    sessions = _get_sessions()
    insights = analyze_sessions(sessions)
    return {
        "insights": [
            {
                "type": i.type,
                "severity": i.severity,
                "title": i.title,
                "description": i.description,
                "session_id": i.session_id,
                "estimated_waste_tokens": i.estimated_waste_tokens,
                "estimated_waste_cost": round(i.estimated_waste_cost, 4),
            }
            for i in insights[:20]  # Top 20 insights
        ],
        "count": len(insights),
    }


@app.get("/api/projects")
async def get_projects():
    """Per-project breakdown with session counts and costs."""
    sessions = _get_sessions()
    projects: dict[str, dict] = {}

    for s in sessions:
        if s.project_path not in projects:
            projects[s.project_path] = {
                "project": s.project_path,
                "session_count": 0,
                "total_cost": 0.0,
                "total_tokens": 0,
            }
        cost = _session_cost(s)
        projects[s.project_path]["session_count"] += 1
        projects[s.project_path]["total_cost"] += cost["total_cost"]
        projects[s.project_path]["total_tokens"] += s.total_tokens

    result = sorted(projects.values(), key=lambda p: -p["total_cost"])
    for p in result:
        p["total_cost"] = round(p["total_cost"], 4)
    return {"projects": result}


# ─── Static Files (Dashboard) ───


@app.get("/")
async def dashboard():
    """Serve the main dashboard HTML."""
    index = STATIC_DIR / "index.html"
    if index.exists():
        return FileResponse(index)
    return JSONResponse({"error": "Dashboard not found. Static files missing."}, status_code=500)


# Mount static directory for CSS/JS
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
