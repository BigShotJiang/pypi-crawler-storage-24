"""Waste detection and actionable insights engine.

This is AgentLens's differentiator. Existing tools show raw numbers.
We explain WHY costs are high and WHAT to do about it.

Insight types:
  - repeated_reads: Same file read 3+ times in one session → wasted tokens
  - floundering: >60% of tokens are tool results → agent is searching, not building
  - cost_outlier: Session costs 3x+ the median → something went wrong
  - long_session: Session ran 60+ min → likely hit compaction, context was lost
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from statistics import median

from tokburn.cost import calculate_cost
from tokburn.parsers.base import Session


@dataclass
class Insight:
    """A single actionable insight about waste or inefficiency."""

    type: str  # "repeated_reads", "floundering", "cost_outlier", "long_session"
    severity: str  # "high", "medium", "low"
    title: str
    description: str
    session_id: str
    estimated_waste_tokens: int = 0
    estimated_waste_cost: float = 0.0


def _session_total_cost(session: Session) -> float:
    """Calculate total dollar cost for a session across all models."""
    total = 0.0
    for msg in session.messages:
        if msg.model:
            tc = calculate_cost(
                msg.model,
                input_tokens=msg.input_tokens,
                output_tokens=msg.output_tokens,
                cache_read_tokens=msg.cache_read_tokens,
                cache_write_tokens=msg.cache_write_tokens,
            )
            total += tc.total_cost
    return total


def detect_repeated_reads(session: Session) -> list[Insight]:
    """Find files that were read 3+ times in a single session."""
    insights = []
    file_reads = [
        tc.input_summary
        for msg in session.messages
        for tc in msg.tool_calls
        if tc.name == "Read" and tc.input_summary
    ]

    counts = Counter(file_reads)
    for filepath, count in counts.most_common():
        if count < 3:
            break
        # Estimate wasted tokens: each re-read after the first is waste
        # Average file read ≈ 2000 tokens (conservative estimate)
        wasted_reads = count - 1
        est_waste_tokens = wasted_reads * 2000
        insights.append(
            Insight(
                type="repeated_reads",
                severity="high" if count >= 5 else "medium",
                title=f"File read {count}x: {filepath}",
                description=(
                    f"'{filepath}' was read {count} times in this session. "
                    f"After the first read, the agent should remember the content. "
                    f"~{wasted_reads} redundant reads wasted an estimated {est_waste_tokens:,} tokens. "
                    f"Consider using a memory tool or CLAUDE.md to cache key file summaries."
                ),
                session_id=session.session_id,
                estimated_waste_tokens=est_waste_tokens,
            )
        )
    return insights


def detect_floundering(session: Session) -> list[Insight]:
    """Detect sessions where the agent spent most of its time on tool calls, not generating."""
    total_input = session.total_input_tokens
    total_output = session.total_output_tokens
    total = total_input + total_output
    if total < 5000:
        return []  # Too small to judge

    # Count tool-result tokens vs total
    tool_result_tokens = sum(m.input_tokens for m in session.messages if m.role == "tool_result")
    if total_input > 0 and tool_result_tokens / total_input > 0.60:
        ratio_pct = int((tool_result_tokens / total_input) * 100)
        return [
            Insight(
                type="floundering",
                severity="medium",
                title=f"Agent spent {ratio_pct}% of input on tool results",
                description=(
                    f"In this session, {ratio_pct}% of input tokens came from tool results "
                    f"(file reads, command output, etc.). This usually means the agent was "
                    f"searching for information rather than making progress. Consider providing "
                    f"better context upfront or using more specific prompts."
                ),
                session_id=session.session_id,
                estimated_waste_tokens=int(tool_result_tokens * 0.3),  # 30% of tool tokens as waste
            )
        ]
    return []


def detect_cost_outliers(sessions: list[Session]) -> list[Insight]:
    """Find sessions that cost significantly more than the median."""
    if len(sessions) < 5:
        return []  # Need enough data for meaningful comparison

    costs = [(s, _session_total_cost(s)) for s in sessions]
    cost_values = [c for _, c in costs if c > 0]
    if not cost_values:
        return []

    med = median(cost_values)
    if med <= 0:
        return []

    insights = []
    for session, cost in costs:
        if cost > med * 3 and cost > 0.50:  # 3x median AND at least $0.50
            ratio = cost / med
            insights.append(
                Insight(
                    type="cost_outlier",
                    severity="high",
                    title=f"Session cost ${cost:.2f} — {ratio:.1f}x above median",
                    description=(
                        f"This session cost ${cost:.2f}, which is {ratio:.1f}x the median "
                        f"session cost of ${med:.2f}. Check the session for runaway loops, "
                        f"large file processing, or unnecessarily broad searches."
                    ),
                    session_id=session.session_id,
                    estimated_waste_cost=cost - med,
                )
            )
    return insights


def detect_long_sessions(session: Session) -> list[Insight]:
    """Flag sessions over 60 minutes — likely hit compaction."""
    duration = session.duration_seconds
    if duration is None or duration < 3600:
        return []

    minutes = int(duration / 60)
    return [
        Insight(
            type="long_session",
            severity="low",
            title=f"Session ran for {minutes} minutes",
            description=(
                f"This session lasted {minutes} minutes. Sessions over 60 minutes "
                f"typically trigger context compaction, which causes the agent to lose "
                f"previously established decisions and patterns. Consider breaking long "
                f"tasks into shorter, focused sessions."
            ),
            session_id=session.session_id,
        )
    ]


def analyze_sessions(sessions: list[Session]) -> list[Insight]:
    """Run all waste detection analyses on a list of sessions."""
    all_insights: list[Insight] = []

    for session in sessions:
        all_insights.extend(detect_repeated_reads(session))
        all_insights.extend(detect_floundering(session))
        all_insights.extend(detect_long_sessions(session))

    # Cross-session analyses
    all_insights.extend(detect_cost_outliers(sessions))

    # Sort by severity (high first) then by estimated waste
    severity_order = {"high": 0, "medium": 1, "low": 2}
    all_insights.sort(key=lambda i: (severity_order.get(i.severity, 3), -i.estimated_waste_tokens))

    return all_insights
