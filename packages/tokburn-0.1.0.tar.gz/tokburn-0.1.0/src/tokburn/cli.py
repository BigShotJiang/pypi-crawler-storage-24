"""CLI entry point for TokBurn.

Usage:
  tokburn              → Start the dashboard (default)
  tokburn serve        → Same as above
  tokburn serve -p 8484 → Custom port
  tokburn scan         → Quick CLI scan (no server)
"""

from __future__ import annotations

import logging
import webbrowser
from threading import Timer

import click

from tokburn import __version__


@click.group(invoke_without_command=True)
@click.version_option(__version__)
@click.pass_context
def main(ctx: click.Context):
    """TokBurn — See where your AI coding agent tokens actually go."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(serve)


@main.command()
@click.option("-p", "--port", default=8391, help="Port to serve on")
@click.option("--host", default="127.0.0.1", help="Host to bind to")
@click.option("--no-open", is_flag=True, help="Don't auto-open browser")
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging")
def serve(port: int, host: str, no_open: bool, verbose: bool):
    """Start the TokBurn dashboard server."""
    import uvicorn

    log_level = "debug" if verbose else "info"
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    url = f"http://{host}:{port}"
    click.echo(f"\n  🔥 TokBurn v{__version__}")
    click.echo(f"  → Dashboard: {url}")
    click.echo(f"  → API docs:  {url}/docs")
    click.echo("  → Press Ctrl+C to stop\n")

    if not no_open:
        Timer(1.2, lambda: webbrowser.open(url)).start()

    uvicorn.run(
        "tokburn.server:app",
        host=host,
        port=port,
        log_level=log_level,
        reload=False,
    )


@main.command()
@click.option("-n", "--limit", default=10, help="Number of recent sessions to show")
def scan(limit: int):
    """Quick CLI scan — show recent sessions and costs without starting the server."""
    from tokburn.cost import calculate_cost
    from tokburn.parsers.claude_code import ClaudeCodeParser

    click.echo("\n🔍 Scanning Claude Code sessions...\n")

    parser = ClaudeCodeParser()
    sessions = parser.parse_all()

    if not sessions:
        click.echo("  No sessions found in ~/.claude/projects/")
        click.echo("  Make sure you've used Claude Code at least once.\n")
        return

    # Sort by most recent
    sessions.sort(key=lambda s: s.started_at or "", reverse=True)

    def _session_cost(s) -> float:
        cost = 0.0
        for msg in s.messages:
            if msg.model:
                tc = calculate_cost(
                    msg.model,
                    input_tokens=msg.input_tokens,
                    output_tokens=msg.output_tokens,
                    cache_read_tokens=msg.cache_read_tokens,
                    cache_write_tokens=msg.cache_write_tokens,
                )
                cost += tc.total_cost
        return cost

    # Aggregate ALL sessions for accurate totals
    total_cost = sum(_session_cost(s) for s in sessions)
    total_tokens = sum(s.total_tokens for s in sessions)

    click.echo(
        f"  Found {len(sessions)} sessions. Showing {min(limit, len(sessions))} most recent:\n"
    )
    click.echo(f"  {'Date':<12} {'Cost':>8} {'Tokens':>10} {'Msgs':>5}  Summary")
    click.echo(f"  {'─' * 12} {'─' * 8} {'─' * 10} {'─' * 5}  {'─' * 40}")

    for s in sessions[:limit]:
        cost = _session_cost(s)
        date_str = s.started_at.strftime("%Y-%m-%d") if s.started_at else "unknown"
        summary = s.summary[:42] if s.summary else "(no summary)"
        click.echo(
            f"  {date_str:<12} ${cost:>7.2f} {s.total_tokens:>10,} {s.message_count:>5}  {summary}"
        )

    if len(sessions) > limit:
        click.echo(f"  (showing {limit} of {len(sessions)} sessions)")

    click.echo(f"\n  {'─' * 80}")
    click.echo(
        f"  Total: ${total_cost:.2f} across {total_tokens:,} tokens in {len(sessions)} sessions"
    )
    click.echo("\n  Run 'tokburn serve' for the full dashboard →\n")


if __name__ == "__main__":
    main()
