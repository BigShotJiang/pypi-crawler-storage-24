"""Model pricing and token cost calculations.

Prices are per 1M tokens. Updated March 2026.
Source: https://docs.anthropic.com/en/docs/about-claude/models
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# Price per 1 MILLION tokens (input, output)
# We also track cache read/write prices where applicable
MODEL_PRICING: dict[str, tuple[float, float]] = {
    # Anthropic — Claude 4 family (new naming: claude-<tier>-<major>-<minor>)
    "claude-sonnet-4-6": (3.00, 15.00),
    "claude-sonnet-4-5": (3.00, 15.00),
    "claude-sonnet-4-0": (3.00, 15.00),
    "claude-opus-4-6": (15.00, 75.00),
    "claude-opus-4-5": (15.00, 75.00),
    "claude-opus-4-0": (15.00, 75.00),
    "claude-haiku-4-5": (0.80, 4.00),
    # Claude 3.5 family (still used in some sessions)
    "claude-3-5-sonnet": (3.00, 15.00),
    "claude-3-5-haiku": (0.80, 4.00),
    # Claude 3 family
    "claude-3-opus": (15.00, 75.00),
    "claude-3-sonnet": (3.00, 15.00),
    "claude-3-haiku": (0.25, 1.25),
    # OpenAI (for cross-agent support later)
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4-turbo": (10.00, 30.00),
    "gpt-4": (30.00, 60.00),
    "o1": (15.00, 60.00),
    "o1-mini": (3.00, 12.00),
    # Google
    "gemini-2.0-flash": (0.10, 0.40),
    "gemini-2.0-pro": (1.25, 10.00),
    "gemini-1.5-pro": (1.25, 5.00),
    "gemini-1.5-flash": (0.075, 0.30),
}

# Cache pricing (per 1M tokens) — Anthropic specific
CACHE_PRICING: dict[str, tuple[float, float]] = {
    # (cache_write, cache_read)
    "claude-sonnet-4-6": (3.75, 0.30),
    "claude-sonnet-4-5": (3.75, 0.30),
    "claude-sonnet-4-0": (3.75, 0.30),
    "claude-opus-4-6": (18.75, 1.50),
    "claude-opus-4-5": (18.75, 1.50),
    "claude-opus-4-0": (18.75, 1.50),
    "claude-haiku-4-5": (1.00, 0.08),
    "claude-3-5-sonnet": (3.75, 0.30),
    "claude-3-5-haiku": (1.00, 0.08),
}

# Regex to strip date suffixes: claude-sonnet-4-5-20250929 → claude-sonnet-4-5
_DATE_SUFFIX = re.compile(r"-\d{8}$")


def normalize_model_id(model_id: str) -> str:
    """Strip date suffix and normalize model identifier for price lookup."""
    return _DATE_SUFFIX.sub("", model_id)


def get_pricing(model_id: str) -> tuple[float, float] | None:
    """Get (input_price, output_price) per 1M tokens for a model. Returns None if unknown."""
    normalized = normalize_model_id(model_id)
    # Try exact match first
    if normalized in MODEL_PRICING:
        return MODEL_PRICING[normalized]
    # Try prefix matching (e.g., "claude-sonnet-4-5-thinking" → "claude-sonnet-4-5")
    for key in sorted(MODEL_PRICING.keys(), key=len, reverse=True):
        if normalized.startswith(key):
            return MODEL_PRICING[key]
    return None


@dataclass
class TokenCost:
    """Calculated cost for a set of tokens."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    input_cost: float = 0.0
    output_cost: float = 0.0
    cache_read_cost: float = 0.0
    cache_write_cost: float = 0.0

    @property
    def total_tokens(self) -> int:
        return (
            self.input_tokens
            + self.output_tokens
            + self.cache_read_tokens
            + self.cache_write_tokens
        )

    @property
    def total_cost(self) -> float:
        return self.input_cost + self.output_cost + self.cache_read_cost + self.cache_write_cost


def calculate_cost(
    model_id: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cache_read_tokens: int = 0,
    cache_write_tokens: int = 0,
) -> TokenCost:
    """Calculate the dollar cost for a given token usage."""
    pricing = get_pricing(model_id)
    if pricing is None:
        # Unknown model — return tokens with zero cost (we'll flag this in the UI)
        return TokenCost(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
        )

    input_price, output_price = pricing
    normalized = normalize_model_id(model_id)
    cache_prices = CACHE_PRICING.get(normalized, (0.0, 0.0))

    return TokenCost(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_write_tokens=cache_write_tokens,
        input_cost=(input_tokens / 1_000_000) * input_price,
        output_cost=(output_tokens / 1_000_000) * output_price,
        cache_read_cost=(cache_read_tokens / 1_000_000) * cache_prices[1],
        cache_write_cost=(cache_write_tokens / 1_000_000) * cache_prices[0],
    )
