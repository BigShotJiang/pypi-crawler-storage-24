/* TokBurn Dashboard — fetch data from local API and render */

const API = "";

function fmt(n) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K";
  return n.toLocaleString();
}

function fmtCost(n) {
  if (n >= 1) return "$" + n.toFixed(2);
  if (n >= 0.01) return "$" + n.toFixed(2);
  return "$" + n.toFixed(4);
}

function shortDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function shortProject(path) {
  if (!path) return "—";
  const parts = path.split("/").filter(Boolean);
  if (parts.length === 0) return path;
  if (parts.length === 1) return parts[0];
  return parts.slice(-2).join("/");
}

const SEVERITY_COLORS = {
  high: { bg: "#fef2f2", border: "#ef4444", text: "#991b1b", icon: "🔴" },
  medium: { bg: "#fffbeb", border: "#f59e0b", text: "#92400e", icon: "🟡" },
  low: { bg: "#f0f9ff", border: "#3b82f6", text: "#1e40af", icon: "🔵" },
};

// ─── Fetch & Render ───

async function loadStats() {
  try {
    const res = await fetch(API + "/api/stats");
    const data = await res.json();

    document.getElementById("stat-cost").textContent = fmtCost(data.total_cost);
    document.getElementById("stat-sessions").textContent = data.total_sessions;
    document.getElementById("stat-tokens").textContent = fmt(data.total_tokens);

    const avg = data.total_sessions > 0 ? data.total_cost / data.total_sessions : 0;
    document.getElementById("stat-avg").textContent = fmtCost(avg);

    const totalAll = (data.total_input_tokens || 0) + (data.total_output_tokens || 0)
      + (data.total_cache_read_tokens || 0) + (data.total_cache_write_tokens || 0);
    const output = data.total_output_tokens || 0;
    const writePct = totalAll > 0 ? (output / totalAll) * 100 : 0;
    document.getElementById("stat-wrote").textContent = writePct.toFixed(1) + "%";
    document.getElementById("stat-wrote-detail").textContent =
      fmt(output) + " written of " + fmt(totalAll) + " total";

    renderDailyChart(data.daily_costs);
    renderProjectChart(data.project_costs);
  } catch (e) {
    console.error("Failed to load stats:", e);
  }
}

let showAll = false;

function renderSessions(sessions) {
  const tbody = document.getElementById("sessions-body");
  const footer = document.getElementById("table-footer");
  const visible = showAll ? sessions : sessions.slice(0, 15);

  tbody.innerHTML = visible
    .map(
      (s, idx) => `
    <tr>
      <td class="row-num">${idx + 1}</td>
      <td>${shortDate(s.started_at)}</td>
      <td class="project">${shortProject(s.project)}</td>
      <td class="summary">${s.summary || "—"}</td>
      <td class="num">${fmt(s.total_tokens)}</td>
      <td class="num cost">${fmtCost(s.total_cost)}</td>
      <td class="num">${s.message_count}</td>
    </tr>`
    )
    .join("");

  if (!showAll && sessions.length > 15) {
    footer.innerHTML = `<button class="show-more" id="show-more-btn">Show all ${sessions.length} sessions ↓</button>`;
    document.getElementById("show-more-btn").addEventListener("click", () => {
      showAll = true;
      renderSessions(sessions);
    });
  } else {
    footer.innerHTML = "";
  }
}

async function loadSessions() {
  try {
    const res = await fetch(API + "/api/sessions");
    const data = await res.json();
    const tbody = document.getElementById("sessions-body");

    if (!data.sessions || data.sessions.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="empty">No sessions found. Use Claude Code to generate some data.</td></tr>';
      return;
    }

    window._allSessions = data.sessions;
    window._sessionMap = Object.fromEntries(data.sessions.map(s => [s.session_id, s]));
    renderSessions(data.sessions);
  } catch (e) {
    console.error("Failed to load sessions:", e);
    document.getElementById("sessions-body").innerHTML =
      '<tr><td colspan="7" class="empty">Failed to load sessions. Is the API running?</td></tr>';
  }
}

async function loadInsights() {
  try {
    const res = await fetch(API + "/api/insights");
    const data = await res.json();
    const container = document.getElementById("insights-list");
    const summary = document.getElementById("insights-summary");

    if (!data.insights || data.insights.length === 0) {
      summary.innerHTML = "<span class=\"insights-count\">0</span> patterns detected";
      container.innerHTML = '<div class="empty-insights">No waste detected. Your sessions look efficient.</div>';
      return;
    }

    const totalWaste = data.insights.reduce((sum, i) => sum + (i.estimated_waste_tokens || 0), 0);
    const affectedSessions = new Set(data.insights.map(i => i.session_id).filter(Boolean)).size;
    const totalCount = data.count || data.insights.length;

    summary.innerHTML =
      `<span class="insights-count">${totalCount}</span> patterns across ` +
      `<span class="insights-count">${affectedSessions}</span> sessions · ` +
      `Est. <span>${fmt(totalWaste)}</span> tokens potentially wasted`;

    const sessionMap = window._sessionMap || {};

    container.innerHTML = data.insights.map((i) => {
      const c = SEVERITY_COLORS[i.severity] || SEVERITY_COLORS.low;
      const session = sessionMap[i.session_id];
      const sessionCtx = session
        ? `${shortProject(session.project)} · ${shortDate(session.started_at)} · ${fmtCost(session.total_cost)}`
        : i.session_id ? i.session_id.slice(0, 8) : "";
      return `
      <div class="insight-card" style="border-left-color:${c.border}">
        <div class="insight-header">
          <span class="insight-icon">${c.icon}</span>
          <span class="insight-title">${i.title}</span>
          <span class="insight-type">${i.type.replace(/_/g, " ")}</span>
        </div>
        <p class="insight-desc">${i.description}</p>
        <div class="insight-footer">
          ${i.estimated_waste_tokens > 0 ? `<span class="insight-waste">~${fmt(i.estimated_waste_tokens)} tokens wasted</span>` : ""}
          ${sessionCtx ? `<span class="insight-session">${sessionCtx}</span>` : ""}
        </div>
      </div>`;
    }).join("");
  } catch (e) {
    console.error("Failed to load insights:", e);
  }
}

// ─── Charts ───

function renderDailyChart(dailyCosts) {
  const ctx = document.getElementById("daily-chart");
  if (!dailyCosts || Object.keys(dailyCosts).length === 0) return;

  const labels = Object.keys(dailyCosts).slice(-30); // Last 30 days
  const values = labels.map((d) => dailyCosts[d]);

  new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels.map((d) => {
        const dt = new Date(d + "T00:00:00");
        return dt.toLocaleDateString("en-US", { month: "short", day: "numeric" });
      }),
      datasets: [
        {
          label: "Daily Cost ($)",
          data: values,
          backgroundColor: "rgba(59, 130, 246, 0.6)",
          borderColor: "rgba(59, 130, 246, 1)",
          borderWidth: 1,
          borderRadius: 4,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => "$" + ctx.parsed.y.toFixed(2),
          },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { callback: (v) => "$" + v.toFixed(2) },
          grid: { color: "rgba(0,0,0,0.06)" },
        },
        x: {
          grid: { display: false },
          ticks: { maxRotation: 45 },
        },
      },
    },
  });
}

function renderProjectChart(projectCosts) {
  const ctx = document.getElementById("project-chart");
  if (!projectCosts || Object.keys(projectCosts).length === 0) return;

  const entries = Object.entries(projectCosts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  const colors = [
    "#3b82f6", "#10b981", "#f59e0b", "#ef4444",
    "#8b5cf6", "#06b6d4", "#ec4899", "#6b7280",
  ];

  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: entries.map(([p]) => shortProject(p)),
      datasets: [
        {
          data: entries.map(([, v]) => v),
          backgroundColor: colors.slice(0, entries.length),
          borderWidth: 2,
          borderColor: "#fff",
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: "right", labels: { boxWidth: 12, padding: 12, font: { size: 12 } } },
        tooltip: {
          callbacks: {
            label: (ctx) => ctx.label + ": $" + ctx.parsed.toFixed(2),
          },
        },
      },
    },
  });
}

// ─── Init ───

document.addEventListener("DOMContentLoaded", () => {
  loadStats();
  loadSessions().then(loadInsights);
});
