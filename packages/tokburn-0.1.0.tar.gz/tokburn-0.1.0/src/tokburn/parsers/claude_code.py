"""Parser for Claude Code session JSONL files.

Claude Code stores sessions as JSONL in:
  ~/.claude/projects/<encoded-cwd>/sessions/<session-id>.jsonl

Each line is a JSON object with a 'type' field:
  - "user" / "human" — user messages
  - "assistant" — Claude responses (contain model + token usage)
  - "tool_result" — tool execution results
  - "file-history-snapshot" — file state snapshots (skip these)

Token usage is embedded in assistant message metadata under various keys
depending on the Claude Code version. We check multiple locations.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path

from tokburn.parsers.base import BaseParser, Message, Session, ToolCall

logger = logging.getLogger(__name__)

# Default Claude Code session directory
DEFAULT_CLAUDE_DIR = Path.home() / ".claude" / "projects"


def _decode_project_path(encoded: str) -> str:
    """Decode the project directory name back to a readable path.

    Claude Code encodes paths by replacing non-alphanumeric chars with '-'.
    e.g., '-Users-vishaal-code-myproject' → '/Users/vishaal/code/myproject'
    """
    if encoded.startswith("-"):
        # Likely an absolute path that was encoded
        return "/" + encoded[1:].replace("-", "/")
    return encoded.replace("-", "/")


def _parse_timestamp(ts: str | None) -> datetime | None:
    """Parse an ISO timestamp string, handling various formats."""
    if not ts:
        return None
    try:
        # Handle both 'Z' suffix and '+00:00' offset
        ts = ts.replace("Z", "+00:00")
        return datetime.fromisoformat(ts)
    except (ValueError, TypeError):
        return None


def _extract_tool_calls(content: list | str | None) -> list[ToolCall]:
    """Extract tool calls from assistant message content blocks."""
    if not isinstance(content, list):
        return []

    calls = []
    for block in content:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "tool_use":
            name = block.get("name", "unknown")
            # Extract useful summary from tool input
            tool_input = block.get("input", {})
            summary = ""
            if (
                name == "Read"
                and isinstance(tool_input, dict)
                or name in ("Edit", "Write")
                and isinstance(tool_input, dict)
            ):
                summary = tool_input.get("file_path", "")
            elif name == "Bash" and isinstance(tool_input, dict):
                cmd = tool_input.get("command", "")
                summary = cmd[:80] if cmd else ""
            elif name in ("Grep", "Glob") and isinstance(tool_input, dict):
                summary = tool_input.get("pattern", "")
            calls.append(ToolCall(name=name, input_summary=summary))
    return calls


def _extract_token_usage(record: dict) -> tuple[str | None, int, int, int, int]:
    """Extract model and token counts from a record.

    Returns: (model, input_tokens, output_tokens, cache_read, cache_write)

    Claude Code embeds usage in different places depending on version:
    - record.message.usage (older)
    - record.usage (newer)
    - record.costTrackingMetadata (alternative)
    """
    model = None
    input_tokens = 0
    output_tokens = 0
    cache_read = 0
    cache_write = 0

    # Try to find model
    model = record.get("model")
    if not model:
        msg = record.get("message", {})
        if isinstance(msg, dict):
            model = msg.get("model")

    # Try record-level usage first (newer format)
    usage = record.get("usage")
    if not usage:
        # Fall back to message.usage
        msg = record.get("message", {})
        if isinstance(msg, dict):
            usage = msg.get("usage")

    if isinstance(usage, dict):
        input_tokens = usage.get("input_tokens", 0) or 0
        output_tokens = usage.get("output_tokens", 0) or 0
        cache_read = usage.get("cache_read_input_tokens", 0) or 0
        cache_write = usage.get("cache_creation_input_tokens", 0) or 0

    return model, input_tokens, output_tokens, cache_read, cache_write


class ClaudeCodeParser(BaseParser):
    """Parse Claude Code JSONL session files."""

    agent_name = "claude_code"

    def __init__(self, base_dir: Path | None = None):
        self.base_dir = base_dir or DEFAULT_CLAUDE_DIR

    def discover_sessions(self) -> list[Path]:
        """Find all .jsonl session files under ~/.claude/projects/."""
        if not self.base_dir.exists():
            logger.warning("Claude Code directory not found: %s", self.base_dir)
            return []

        session_files = []
        for project_dir in self.base_dir.iterdir():
            if not project_dir.is_dir():
                continue
            sessions_dir = project_dir / "sessions"
            if sessions_dir.exists():
                session_files.extend(sorted(sessions_dir.glob("*.jsonl")))
            # JSONL files directly in the project dir (standard format)
            session_files.extend(sorted(project_dir.glob("*.jsonl")))
            # Subagent sessions: project_dir/<session-id>/subagents/*.jsonl
            session_files.extend(sorted(project_dir.glob("*/subagents/*.jsonl")))

        # Deduplicate (in case files appear in both locations)
        seen = set()
        unique = []
        for f in session_files:
            if f not in seen:
                seen.add(f)
                unique.append(f)

        logger.info("Found %d Claude Code session files", len(unique))
        return unique

    def parse_session(self, filepath: Path) -> Session | None:
        """Parse a single JSONL session file into a Session object."""
        try:
            messages = []
            session_id = filepath.stem  # Filename without .jsonl
            parent_session_id = None
            first_user_message = ""
            timestamps: list[datetime] = []
            filename_session_id = session_id

            with filepath.open("r", encoding="utf-8", errors="replace") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        logger.debug("Skipping malformed JSON at %s:%d", filepath, line_num)
                        continue

                    if not isinstance(record, dict):
                        continue

                    record_type = record.get("type", "")
                    is_compact = record.get("isCompactSummary", False)

                    # Skip file history snapshots and other non-message types
                    if record_type in ("file-history-snapshot", "checkpoint"):
                        continue

                    # Parse timestamp
                    ts = _parse_timestamp(record.get("timestamp"))
                    if ts:
                        timestamps.append(ts)

                    # Detect parent session (continuation chain)
                    record_session = record.get("sessionId", "")
                    if record_session and record_session != filename_session_id:
                        # This record belongs to a parent session
                        if parent_session_id is None:
                            parent_session_id = record_session

                    # Determine role
                    role = record_type
                    if role in ("human", "user"):
                        role = "user"
                    elif role == "assistant":
                        role = "assistant"
                    elif role == "tool_result":
                        role = "tool_result"
                    else:
                        # Unknown type — skip or treat as metadata
                        continue

                    # Extract content for tool calls and first user message
                    content = None
                    msg_obj = record.get("message", {})
                    if isinstance(msg_obj, dict):
                        content = msg_obj.get("content")
                    elif isinstance(record.get("content"), (list, str)):
                        content = record.get("content")

                    # Capture first user message as summary
                    if role == "user" and not first_user_message and not is_compact:
                        if isinstance(content, str):
                            first_user_message = content[:120]
                        elif isinstance(content, list):
                            for block in content:
                                if isinstance(block, dict) and block.get("type") == "text":
                                    first_user_message = block.get("text", "")[:120]
                                    break
                                elif isinstance(block, str):
                                    first_user_message = block[:120]
                                    break

                    # Extract token usage (only meaningful for assistant messages)
                    model, inp, out, cache_r, cache_w = _extract_token_usage(record)

                    # Extract tool calls from assistant content
                    tool_calls = _extract_tool_calls(content) if role == "assistant" else []

                    messages.append(
                        Message(
                            role=role,
                            timestamp=ts,
                            model=model,
                            input_tokens=inp,
                            output_tokens=out,
                            cache_read_tokens=cache_r,
                            cache_write_tokens=cache_w,
                            tool_calls=tool_calls,
                            is_compact_summary=is_compact,
                        )
                    )

            if not messages:
                return None

            # Determine project path from directory structure.
            # Layouts:
            #   project_dir/<session>.jsonl           → parent.name == project_dir.name
            #   project_dir/sessions/<session>.jsonl  → parent.name == "sessions"
            #   project_dir/<session>/subagents/<agent>.jsonl → parent.name == "subagents"
            project_encoded = filepath.parent.name
            if project_encoded == "sessions":
                project_encoded = filepath.parent.parent.name
            elif project_encoded == "subagents":
                project_encoded = filepath.parent.parent.parent.name
            project_path = _decode_project_path(project_encoded)

            return Session(
                session_id=session_id,
                project_path=project_path,
                source_file=filepath,
                agent=self.agent_name,
                started_at=min(timestamps) if timestamps else None,
                ended_at=max(timestamps) if timestamps else None,
                messages=messages,
                parent_session_id=parent_session_id,
                summary=first_user_message or "(no summary)",
            )

        except Exception:
            logger.exception("Failed to parse session file: %s", filepath)
            return None
