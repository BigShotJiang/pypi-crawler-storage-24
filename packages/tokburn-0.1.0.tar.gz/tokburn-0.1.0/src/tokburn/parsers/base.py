"""Base parser interface for agent session logs."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass
class ToolCall:
    """A single tool invocation within a session."""

    name: str  # e.g., "Read", "Edit", "Bash", "Grep"
    input_summary: str = ""  # e.g., file path for Read, command for Bash
    duration_ms: int | None = None


@dataclass
class Message:
    """A single message (user, assistant, or tool_result) in a session."""

    role: str  # "user", "assistant", "tool_result"
    timestamp: datetime | None = None
    model: str | None = None  # Only for assistant messages
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    tool_calls: list[ToolCall] = field(default_factory=list)
    is_compact_summary: bool = False


@dataclass
class Session:
    """A parsed agent session with computed metadata."""

    session_id: str
    project_path: str  # The decoded project directory
    source_file: Path  # Actual JSONL file on disk
    agent: str  # "claude_code", "opencode", "aider", etc.
    started_at: datetime | None = None
    ended_at: datetime | None = None
    messages: list[Message] = field(default_factory=list)
    parent_session_id: str | None = None  # For continuation chains
    summary: str = ""  # First user message or auto-generated summary

    @property
    def duration_seconds(self) -> float | None:
        if self.started_at and self.ended_at:
            return (self.ended_at - self.started_at).total_seconds()
        return None

    @property
    def total_input_tokens(self) -> int:
        return sum(m.input_tokens for m in self.messages)

    @property
    def total_output_tokens(self) -> int:
        return sum(m.output_tokens for m in self.messages)

    @property
    def total_cache_read_tokens(self) -> int:
        return sum(m.cache_read_tokens for m in self.messages)

    @property
    def total_cache_write_tokens(self) -> int:
        return sum(m.cache_write_tokens for m in self.messages)

    @property
    def total_tokens(self) -> int:
        return (
            self.total_input_tokens
            + self.total_output_tokens
            + self.total_cache_read_tokens
            + self.total_cache_write_tokens
        )

    @property
    def message_count(self) -> int:
        return len([m for m in self.messages if not m.is_compact_summary])

    @property
    def models_used(self) -> set[str]:
        return {m.model for m in self.messages if m.model}

    @property
    def tool_call_summary(self) -> dict[str, int]:
        """Count of each tool type used across all messages."""
        counts: dict[str, int] = {}
        for msg in self.messages:
            for tc in msg.tool_calls:
                counts[tc.name] = counts.get(tc.name, 0) + 1
        return counts

    @property
    def files_read(self) -> list[str]:
        """List of file paths that were read during this session."""
        files = []
        for msg in self.messages:
            for tc in msg.tool_calls:
                if tc.name == "Read" and tc.input_summary:
                    files.append(tc.input_summary)
        return files


class BaseParser:
    """Interface that all agent parsers must implement."""

    agent_name: str = "unknown"

    def discover_sessions(self) -> list[Path]:
        """Find all session files on disk for this agent."""
        raise NotImplementedError

    def parse_session(self, filepath: Path) -> Session | None:
        """Parse a single session file into a Session object. Returns None if unparseable."""
        raise NotImplementedError

    def parse_all(self) -> list[Session]:
        """Discover and parse all sessions for this agent."""
        sessions = []
        for filepath in self.discover_sessions():
            session = self.parse_session(filepath)
            if session is not None:
                sessions.append(session)
        return sessions
