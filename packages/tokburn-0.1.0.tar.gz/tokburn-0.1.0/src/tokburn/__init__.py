"""TokBurn — See where your AI coding agent tokens actually go."""

__version__ = "0.1.0"
