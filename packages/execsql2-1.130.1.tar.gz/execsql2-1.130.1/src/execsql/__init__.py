"""execsql - A multi-DBMS SQL script processor."""

__version__ = "1.130.1"
