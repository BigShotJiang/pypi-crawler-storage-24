"""Entry point for execsql."""
from execsql.execsql import main

if __name__ == "__main__":
    main()
