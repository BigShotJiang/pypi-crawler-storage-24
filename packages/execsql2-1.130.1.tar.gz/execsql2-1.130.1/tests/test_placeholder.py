"""Placeholder test suite — expand during refactor phase."""


def test_import():
    """Package can be imported."""
    import execsql

    assert execsql.__version__ == "1.130.1"
