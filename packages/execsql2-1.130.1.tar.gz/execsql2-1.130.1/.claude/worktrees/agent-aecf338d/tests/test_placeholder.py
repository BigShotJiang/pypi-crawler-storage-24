"""Placeholder test suite — expand during refactor phase."""


def test_import():
    """Package can be imported."""
    import execsql2

    assert execsql2.__version__ == "1.130.1"
