# Change Log 

  Version     Date         Features
  ----------- ------------ --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  1.130.0     2024-12-18   Added variable substitution to the \'config_file\' settings read from execsql.conf.
  1.129.0     2024-05-21   Added a PROMPT MESSAGE metacommand that only displays a message in a dialog box.
  1.128.0     2024-05-12   Added a sash between the tables displayed by the PROMPT COMPARE metacommand so they can be resized.
  1.127.0     2024-04-09   Added a menu item to table displays allowing columns to be hidden or shown.
  1.126.1     2024-02-16   Corrected the use of the width specification for listboxes in the PROMPT ENTRY_FORM metacommand. Improved sorting in tables shown by the PROMPT DISPLAY and other metacommands. Added templates and scripts to the distribution, to be placed in the *execsql_extras* directory.
  1.126.0     2024-02-15   Added a horizontal scrollbar to listboxes used with the PROMPT ENTRY_FORM metacommand. Allowed radio buttons to be used with the PROMPT ENTRY_FORM metacommand.
  1.125.3     2024-02-09   Eliminated spurious warnings when running under Python 3.12.
  1.125.0     2023-12-13   Added command-line and configuration settings to use an *execsql.log* file in the user\'s home directory.
  1.124.0     2023-12-12   Added optional HELP clauses for most metacommands that produce GUI dialogs.
  1.123.0     2023-08-22   Added the RESET DIALOG_CANCELED metacommand.
  1.122.0     2023-07-27   Added the FREE keyword to the PROMPT DISPLAY metacommand. Added substitution variables \$SCRIPT_START_TIME_UTC and \$CURRENT_TIME_UTC.
  1.120.0     2023-07-16   Extended the PROMPT ENTRY_FORM specifications to allow listboxes, specification of height for listboxes and text areas, and specification of columns to create a multi-column form.
  1.119.0     2023-07-15   Modified the WRITE metacommand to run in a separate process.
  1.118.0     2023-07-09   Added \'Save as\' menu items to the PROMPT COMPARE UI. Performance improvement for the data type evaluator used by IMPORT and COPY metacommands.
  1.117.0     2023-06-10   Added support for DuckDB databases. Extended the EXPORT metacommand to export data to SQLite and DuckDB databases.
  1.115.0     2023-04-06   Enabled export of multiple tables to an ODS workbook with a single EXPORT metacommand.
  1.114.0     2023-04-01   Added the DELETE_EMPTY_COLUMNS configuration metacommand and setting.
  1.113.0     2023-03-26   Added the BREAK metacommand to allow early exit of loops and sub-scripts.
  1.112.0     2023-03-20   Added the !\"! replacement delimiter for substitution variables.
  1.111.0     2023-01-09   Added the PROMPT CREDENTIALS metacommand.
  1.110.0     2022-12-20   Added creation of the the \$SHEETS_IMPORTED, \$SHEETS_TABLES, and \$SHEETS_TABLES_VALUES system variables.
  1.109.0     2022-12-13   Added the CONFIG WRITE_PREFIX and CONFIG WRITE_SUFFIX metacommands and configuration settings.
  1.108.0     2022-11-17   Renamed the EMIT metacommand to SERVE.
  1.107.0     2022-11-02   Added the CGI-HTML type for the EXPORT metacommand, and added the SUB_QUERYSTRING and EMIT metacommands to support use of *execsql* as a CGI script.
  1.106.0     2022-10-27   Modified the \'table_exists()\' and \'view_exists()\' conditionals for Postgres to only look for tables that are either in the temporary-table schema or in a schema that is on Postgres\' search path.
  1.105.0     2022-10-19   Added the CD metacommand.
  1.104.0     2022-10-15   Added the \'trim_column_headers\' configuration setting and configuration metacommand.
  1.103.0     2022-07-23   Extended the EXPORT_METADATA metacommand to insert the metadata into a database table.
  1.102.0     2022-06-21   Added import from data files in Feather format.
  1.101.0     2022-06-18   Added import from data files in Parquet format.
  1.100.3     2022-04-30   Modified the PROMPT ENTRY_FORM so that the \'Enter\' key does not close the form when a checkbox has the focus.
  1.100.1     2022-02-22   Added a bottom border to the header row and top-alignment of body cells to ODS export.
  1.100.0     2022-02-20   Added the INITIALLY clause to the PROMPT ENTER_SUB metacommand.
  1.99.0      2022-02-19   Added the variant IMPORT metacommands that use a SHEETS MATCHING \<regex\> clause to import multiple sheets from an OpenDocument or Excel workbook in one step.
  1.98.0      2022-01-12   Added the FOLD_COLUMN_HEADERS configuration setting. Cleaning column headers now adds an underscore to the beginning of any column header that starts with a digit.
  1.97.0      2022-01-08   Added the CONTAINS, ENDS_WITH, and STARTS_WITH conditional tests. Modified the \'textarea\' control in an ENTRY_FORM to allow newlines to be inserted, and to strip trailing newlines. Modified the SQL statement evaluator to ignore multiple terminating semicolons.
  1.96.0      2022-01-03   Reading of .xlsx files now uses the openpyxl library\--a new requirement.
  1.95.0      2021-12-03   The SYSTEM_CMD metacommand now logs the command to execsql.log.
  1.94.0      2021-10-19   Modified the INCLUDE and IMPORT metacommands to recognize leading tildes on the filename, and added the \$PATHSEP system variable.
  1.93.0      2021-10-02   Added the USER variant of the CONNECT metacommand.
  1.92.0      2021-09-19   Added the TRIM_STRINGS and REPLACE_NEWLINES settings.
  1.91.0      2021-09-16   Added the DIALOG_CANCELED() conditional.
  1.90.0      2021-08-08   Modified to dynamically re-order metacommand patterns to match usage.
  1.89.1      2021-05-18   Changed the column name \"user\" to \"username\" in the output of the EXPORT_METADATA metacommand.
  1.89.0      2021-03-17   Added the TEE clause to the HALT metacommand.
  1.88.0      2021-02-13   Added the EXPORT_METADATA metacommand.
  1.87.0      2021-02-10   Added the ZIP metacommand.
  1.86.0      2021-02-09   Added the \'create_column_headers\' configuration setting and configuration metacommand.
  1.85.0      2021-02-09   Added the \'zip_buffer_mb\' configuration setting and configuration metacommand.
  1.84.0      2021-02-06   Enabled EXPORT directly to a zip file for most export formats.
  1.83.0      2021-01-09   Modified interpretation of both the \'config_file\' and \'linux_config_file\' settings to expand a leading \'\~\' character to the user\'s home directory.
  1.82.0      2020-11-14   Added console window size configuration options in execsql.conf, and modified the console height and width configuration metacommands to change the settings for any future console windows as well as for any currently open console.
  1.81.0      2020-11-08   Added the \'only_strings\' configuration setting and metacommand.
  1.80.0      2020-10-26   Added \'linux_config_file\' and \'win_config_file\' configuration settings.
  1.79.0      2020-08-29   Added the ENCODING clause to the WRITE CREATE_TABLE metacommand for text files.
  1.78.0      2020-08-08   Modified the PROMPT SELECT_ROWS metacommand to set a grey background on selected rows.
  1.77.0      2020-07-29   Added the \$STARTING_SCRIPT_REVTIME system variable.
  1.76.0      2020-07-18   Added a configuration option and metacommand to deduplicate repeated column headers in IMPORTed data. Modified column header cleaning to strip leading and trailing spaces.
  1.75.0      2020-07-16   Added more quoting characters for the WRITE metacommand.
  1.74.3      2020-07-11   Corrected the ASK metacommand under Python 3 on Windows.
  1.74.1      2020-07-08   Modified the IMPORT metacommand to buffer input rows for slightly better performance, and added an \'import_row_buffer\' setting and a CONFIG IMPORT_ROW_BUFFER metacommand to allow the buffer size to be customized.
  1.73.0      2020-05-01   Changed to set execsql.log to read-only on exit.
  1.72.2      2020-03-31   Correction to 2020-03-30 modification.
  1.72.0      2020-03-30   Modifed the export buffer size for better performance and added an \'export_row_buffer\' setting and a CONFIG EXPORT_ROW_BUFFER metacommand to allow the buffer size to be customized.
  1.71.2      2020-03-29   Added encoding name translations to allow more encoding name aliases when using the EXPORT metacommand with Postgres.
  1.71.0      2020-03-21   Added the CONFIG LOG_DATAVARS metacommand and the \'log_datavars\' configuration setting.
  1.70.0      2020-03-14   Added the \"!\'!\" substitution delimiter and the SUB_EMPTY conditional test.
  1.69.0      2020-03-07   Added export to HDF5 files.
  1.68.0      2020-03-03   Added the IF EXISTS clause to the EXECUTE SCRIPT metacommand.
  1.67.0      2020-02-22   Added the EXTEND SCRIPT WITH SQL and EXTEND SCRIPT WITH METACOMMAND metacommands, and aliased the APPEND SCRIPT metacommand to EXTEND SCRIPT\...WITH SCRIPT.
  1.66.0      2020-02-22   Added the DISCONNECT metacommand.
  1.65.0      2020-02-22   Added CONFIG SCAN_LINES and CONFIG GUI_LEVEL metacommands.
  1.64.0      2020-02-22   Added the LOCAL and USER keywords to the DEBUG LOG SUBVARS metacommand.
  1.63.0      2020-02-15   Modified the CONFIG metacommands to accept 0 or 1 as arguments.
  1.62.0      2020-02-13   Added the CONFIG DAO_FLUSH_DELAY_SECS metacommand and the \'dao_flush_delay_secs\' configuration file setting.
  1.61.0      2020-02-05   Added the PROMPT PAUSE metacommand. Added write of execsql version number to execsql.log.
  1.60.0      2020-02-01   Added the LOOP metacommand.
  1.59.0      2020-01-31   Added \$STARTING_PATH and \$CURRENT_PATH system variables.
  1.58.0      2020-01-28   Modified PAUSE and ASK metacommands to allow apostrophes and square brackets as string delimiters.
  1.57.0      2020-01-25   Modified evaluation of conditionals to accept Boolean literals.
  1.56.0      2019-12-27   Added the ROLE_EXISTS conditional.
  1.55.0      2019-12-26   Added the CONTINUE keyword to the SYSTEM_CMD metacommand.
  1.54.0      2019-12-20   Added the BEGIN/END SQL metacommands.
  1.53.0      2019-10-27   Added Oracle support.
  1.52.0      2019-10-11   Added export to XML.
  1.51.0      2019-10-10   Added WHILE and UNTIL loop control to EXECUTE SCRIPT; implemented deferred variable substitution.
  1.50.0      2019-10-05   Added a numeric expression parser for the SUB_ADD and SET COUNTER metacommands.
  1.49.0      2019-10-04   Added a conditional expression parser for the IF metacommands.
  1.48.0      2019-09-27   Added the CONFIG EMPTY_ROWS metacommand and the [empty_rows] configuration setting.
  1.47.0      2019-09-21   Added the FROM keyword to PROMPT OPENFILE, SAVEFILE, and DIRECTORY metacommands.
  1.46.0      2019-09-04   Added the COMPACT keyword to the PROMPT ACTION metacommand.
  1.45.0      2019-09-01   Added the SCRIPT_EXISTS conditional and the PROMPT ACTION metacommand.
  1.43.0      2019-08-27   Added the PROMPT SELECT_ROWS metacommand.
  1.42.1      2019-08-22   Corrected EXPORT\...AS VALUES to write \"NULL\" for null data.
  1.42.0      2019-08-18   Added the APPEND SCRIPT metacommand.
  1.41.0      2019-08-17   Added an export option to produce a JSON table schema.
  1.40.0      2019-08-16   Added the USER keword to the DEBUG WRITE SUBVARS metacommand.
  1.39.0      2019-08-16   Added the SUB_INI metacommand.
  1.38.8      2019-06-30   Added input and output filename prompt options to the entry form specifications.
  1.37.7      2019-05-10   Protected error messages containing bad data from encoding errors.
  1.37.6      2019-05-07   Removed Unicode conversion of data when loaded into Tkinter Treeview control. Added MARS_Connection=Yes to SQL Server ODBC connections.
  1.37.4      2019-05-04   Corrected int/long conversion for Python 3 with Access; Added SQL Server ODBC drivers 13.1 and 17; improved efficiency of COPY metacommand.
  1.37.0      2019-03-16   Added the PASSWORD keyword to the CONNECT metacommand for SQL Server.
  1.36.0      2019-03-11   Changed to three-part semantic version number.
  1.35.2.0    2019-02-27   Added \'WITH COMMIT\|ROLLBACK\' clause to the \'AUTOCOMMIT ON\' metacommand.
  1.35.1.0    2019-02-23   Added a warning if a SQL statement is incomplete when a metacommand is encountered. Triggered an error if a SQL statement is incomplete at the end of a script file. Added CONFIG WRITE_WARNINGS metacommand.
  1.35.0.0    2019-02-21   Modified substitution metacommands to accept a \'+\' prefix to reference local variables in outer scopes.
  1.34.9.0    2019-02-18   Added ON ERROR_HALT EXECUTE SCRIPT and ON CANCEL_HALT EXECUTE SCRIPT.
  1.34.8.0    2019-02-12   Modified reporting of origin lines of mismatched IF conditionals.
  1.34.7.0    2019-02-09   Made quotes optional on the arguments to the \'is_true\', \'equal\', and \'identical\' conditional. Allowed a script name to be specified on the END SCRIPT metacommand. Added system variables for execsql\'s primary, secondary, and tertiary version numbers.
  1.34.4.0    2019-02-08   Added a configuration option to clean IMPORTed column headers of non-alphanumeric characters.
  1.34.2.0    2019-02-03   Raises an exception if there is an incomplete SQL statement at END SCRIPT. Issues a warning if IF levels are unbalanced within a script. Issues a warning if a command appears to have an unsubstituted variable.
  1.34.0.0    2019-02-02   Added optional extensions WITH ARGUMENTS to EXECUTE SCRIPT metacommand and WITH PARAMETERS to BEGIN SCRIPT metacommand.
  1.33.0.0    2019-01-19   Added the PROMPT ASK\...COMPARE metacommand. Modified so that all ASK metacommands and the SUBDATA metacommand can set local variables.
  1.32.0.0    2018-12-16   Added export to the feather file format.
  1.31.13.0   2018-11-07   Added the \"quote_all_text\" output setting and the CONFIG QUOTE_ALL_TEXT metacommand.
  1.31.12.0   2018-11-03   Added CONSOLE WIDTH and CONSOLE HEIGHT metacommands. Modified so that PROMPT ENTRY_FORM recognizes local variables. Modified so that all CONFIG metacommands that take Boolean arguments recognize both Yes/No and On/Off.
  1.31.10.0   2018-10-30   Added asterisks to denote required entries on PROMPT ENTRY_FORM.
  1.31.9.0    2018-10-29   Added a fifth variable to the PROMPT OPENFILE and PROMPT SAVEFILE commands to get the base filename without path or extension.
  1.31.8.0    2018-10-25   Allowed the RM_FILE metacommand to take wildcards.
  1.31.7.0    2018-10-23   Added an optional second, third, and fourth substitution variable names to PROMPT SAVEFILE that, if provided, will be set to the filename only, the path only, and the extension, respectively.
  1.31.6.0    2018-10-22   Added an optional third and fourth substitution variable names to PROMPT OPENFILE that, if provided, will be set to the path only and the extension, respectively.
  1.31.5.0    2018-10-15   Added an optional second substitution variable name to PROMPT OPENFILE that, if provided, will be set to the filename without the path.
  1.31.4.0    2018-10-14   Added the ENCODING clause to the IMPORT\...FROM EXCEL metacommand.
  1.31.3.0    2018-10-14   Enabled sorting of tabular displays by clicking on column headers. Converted all path separators returned by PROMPT OPENFILE, SAVEFILE, and DIRECTORY from \"/\" to \"\\\\\" on Windows.
  1.31.1.0    2018-10-09   Added LOCAL clause to DEBUG WRITE SUBVARS.
  1.31.0.0    2018-10-07   Added local variables.
  1.30.6.0    2018-09-30   Added a button to show unmatched rows to the PROMPT COMPARE display. Added the \'IF EXISTS\' clause to the INCLUDE metacommand. Added an \'IF CONSOLE_ON\' conditional test.
  1.30.3.0    2018-09-29   Added the \'IN \<alias\>\' clauses to the PROMPT COMPARE metacommand. Added a checkbox to the PROMPT COMPARE GUI to allow highlighting of matches in both tables.
  1.30.1.0    2018-09-23   Modified the PROMPT COMPARE command so that it highlights all matching rows in the other table, not just the first.
  1.30.0.0    2018-09-22   Changed to write a description of the binary data length when binary data are used with PROMPT DISPLAY or EXPORT AS TXT.
  1.29.3.0    2018-09-22   Modified the WRITE metacommand to use the \'make_export_dirs\' configuration setting.
  1.29.2.0    2018-09-19   Added the SUB_ADD metacommand. Made the WITH keyword optional in the IMPORT metacommand.
  1.29.0.0    2018-09-12   Added the IMPORT_FILE metacommand.
  1.28.0.0    2018-08-19   Modified to run under Python 3.x as well as 2.7.
  1.27.4.0    2018-08-19   Now writes Python version number into execsql.log.
  1.27.3.0    2018-07-31   Changed to read configuration files from both the script directory and the starting directory, if different.
  1.27.2.0    2018-07-30   Added the SUB_EMPTY metacommand.
  1.27.1.0    2018-07-29   Allowed single quotes and square brackets in ON ERROR_HALT WRITE and ON CANCEL_HALT WRITE metacommands.
  1.27.0.0    2018-07-29   Internal script processing routines rewritten.
  1.26.8.0    2018-07-25   Allowed single quotes and square brackets in WRITE metacommand. Fixed stripping of extra spaces from input data when input is not strings. Modfied data format evaluation used by IMPORT to take account of the empty_strings configuration setting.
  1.26.5.0    2018-07-20   Added \$PYTHON_EXECUTABLE system variable. Trimmed any trailing space from last column header of an IMPORTed CSV file. Changed to treat a string of only spaces as an empty string when empty_strings=False.
  1.26.4.3    2018-07-12   Corrected handling of double-quoted filenames by the ON ERROR_HALT WRITE and ON CANCEL_HALT WRITE metacommands.
  1.26.4.2    2018-07-09   Corrected handling of double-quoted filenames by the WRITE and RM_FILE metacommands.
  1.26.4.0    2018-06-27   Added \$STARTING_SCRIPT_NAME and \$CURRENT_SCRIPT_NAME system variables. Added IS_TRUE conditional.
  1.26.2.0    2018-06-25   Added a \$CURRENT_SCRIPT_PATH system variable that returns the path only of the current script file.
  1.26.1.0    2018-06-13   Corrected hang on uppercase counter references. Changed HALT metacommands to set the exit code to 3.
  1.26.0.0    2018-06-13   Added ON CANCEL_HALT WRITE and ON CANCEL_HALT EMAIL metacommands.
  1.25.0.0    2018-06-10   Added the PROMPT COMPARE metacommand.
  1.24.12.0   2018-06-09   Added a MAKE_EXPORT_DIRS metacommand. Grouped all metacommands corresponding to configuration options under a common CONFIG prefix to the metacommand names. Added configuration file size and date to the message that is written to execsql.log when a configuration file is read.
  1.24.9.0    2018-06-03   Modified the IMPORT metacommand to write the file name, file size, and file date to execsql.log.
  1.24.8.0    2018-06-03   Corrected \'is_null()\', \'equals()\', and \'identical()\' to strip quotes. Added filename to error message when the IMPORT metacommand can\'t find a file. Modified SUBDATA to only remove the substitution variable, not raise an exception, when there are no rows in the specified table or view.
  1.24.7.0    2018-04-03   Added the \$SYSTEM_CMD_EXIT_STATUS system variable.
  1.24.6.0    2018-04-01   Added the \"B64\" format to the EXPORT and EXPORT_QUERY metacommands.
  1.24.5.0    2018-03-15   Added the \'textarea\' entry type to the PROMPT ENTRY_FORM metacommand.
  1.24.4.0    2017-12-31   Allowed \"CREATE SCRIPT\" as an alias for \"BEGIN SCRIPT\". Allowed \"DEBUG WRITE SCRIPT\" as an alias for \"WRITE SCRIPT\". Added the \"-o\" command-line option to display online help.
  1.24.2.0    2017-12-30   Modified characters allowed in user names for Postgres and ODBC connections. Added the TYPE and LCASE UCASE keywords to the PROMPT ENTER_SUB metacommand.
  1.24.0.0    2017-11-04   Added the \'include_required\' and \'include_optional\' configuration settings.
  1.23.3.0    2017-11-03   Added the CONSOLE_WAIT_WHEN_ERROR_HALT setting and associated metacommand and system variable.
  1.23.2.0    2017-11-02   Added the \$ERROR_MESSAGE system variable.
  1.23.1.0    2017-10-20   Added the ASK metacommand.
  1.23.0.0    2017-10-09   Added the ON ERROR_HALT EMAIL metacommand.
  1.22.0.0    2017-10-07   Added the ON ERROR_HALT WRITE metacommand.
  1.21.13.0   2017-09-29   Added the SUB_APPEND and WRITE SCRIPT metacommands. Modified all metacommand messages to allow multiline text.
  1.21.12.0   2017-09-24   Added the PG_VACUUM metacommand.
  1.21.11.0   2017-09-23   Modified error message content and format.
  1.21.10.0   2017-09-12   Added the \"error_response\" configuration setting for encoding mismatches.
  1.21.9.0    2017-09-06   Modified to handle trailing comments on SQL script lines.
  1.21.8.0    2017-08-11   Modified to allow a password to be specified in the CONNECT metacommand for MySQL.
  1.21.7.0    2017-08-05   Modified to allow import of CSV files with more columns than the target table. Added DEBUG metacommands.
  1.21.1.0    2017-07-04   Passed column headers to template processors as a separate object.
  1.21.0.0    2017-07-01   Extended the EXPORT metacommand to allow several different template processors to be used.
  1.20.0.0    2017-06-30   Added the EMAIL, SUB_ENCRYPT, and SUB_DECRYPT metacommands, and configuration properties to support emailing. Added the METACOMMAND_ERROR_HALT metacommand, the \$METACOMMAND_ERROR_HALT_STATE system variable, and the METACOMMAND_ERROR() conditional.
  1.18.0.0    2017-06-24   Improved the speed of import of CSV files to Postgres and MySQL/MariaDB. Modified the EXPORT\...APPEND\...AS HTML metacommand to append tables *inside* the (first) \</body\> tag.
  1.17.0.0    2017-05-28   Modified the specifications for the PROMPT ENTRY_FORM to allow checkboxes to be used.
  1.16.9.0    2017-05-27   Added a DESCRIPTION keyword to the EXPORT metacommands.
  1.16.8.0    2017-05-20   Added the VALUES export format.
  1.16.7.0    2017-05-20   Added BOOLEAN_INT and BOOLEAN_WORDS metacommands. Allowed the PAUSE metacommand to take fractional timeout arguments. Added a \'console_wait_when_done\' configuration parameter. Added the server name to the password prompt.
  1.16.3.0    2017-04-23   Added a configuration option allowing the specification of additional configuration files to read. Added a MAX_INT configuration parameter and metacommand.
  1.16.0.0    2017-03-25   Added the BEGIN SCRIPT, END SCRIPT, and EXECUTE SCRIPT metacommands.
  1.15.0.0    2017-03-09   Added the TEE keyword to the WRITE, EXPORT, and EXPORT QUERY metacommands.
  1.13.0.0    2017-03-05   Added the LOG_WRITE_MESSAGES metacommand and configuration parameter.
  1.12.0.0    2017-03-04   Added a \'boolean_words\' configuration option. Enabled reading of CSV files with newlines within delimited text data. Added the SKIP keyword to the IMPORT metacommand for CSV, ODS, and Excel data. Added the COLUMN_EXISTS conditional.
  1.8.15.0    2017-01-14   Added a \$LAST_ROWCOUNT system variable.
  1.8.14.0    2016-11-13   Added evaluation of numeric types in input. Added \'empty_strings\' configuration parameter and metacommand. Corrections to IMPORT metacommand for Firebird.
  1.8.13.0    2016-11-07   Added the \"-b\" command-line option and configuration parameter.
  1.8.12.0    2016-10-22   Added the RM_SUB metacommand.
  1.8.11.0    2016-10-19   Added the SET COUNTER metacommand.
  1.8.10.2    2016-10-17   Added \$RUN_ID system variable Modified to recognize as text any imported data that contains only numeric values but where the first digit of any value is a zero.
  1.8.8.0     2016-09-28   Added \$CURRENT_ALIAS, \$RANDOM, and \$UUID system variables.
  1.8.4.0     2016-08-13   Added logging of database close when autocommit is off. Added import from MS-Excel. Corrected parsing of numeric time zones.
  1.7.3.0     2016-08-05   Added \$OS system variable.
  1.7.2.0     2016-06-11   Added DIRECTORY_EXISTS conditional and option to automatically make directories used by the EXPORT metacommand.
  1.7.0.0     2016-05-20   Added NEWER_DATE and NEWER_FILE conditionals.
  1.6.0.0     2016-05-15   Added CONSOLE SAVE metacommand. Added DSN connections. Added COPY QUERY and EXPORT QUERY metacommands.
  1.4.4.0     2016-05-02   Added CONSOLE HIDE SHOW metacommands and allowed \<Enter\> in response to the CONSOLE WAIT metacommand, to continue without closing.
  1.4.2.0     2016-05-02   Added a \"Save as\...\" menu to the GUI console and changed the PAUSE and HALT metacommands to use a GUI if the console is on.
  1.4.0.0     2016-04-30   Added a GUI console with a status bar and progress bar to which WRITE output and exported text will be written.
  1.3.3.0     2016-04-09   Additions to \'Save as\...\' options in PROMPT DISPLAY metacommand, and date/time values exported to ODS.
  1.3.2.0     2016-02-28   Enabled the use of a backslash as a line continuation character for SQL statements.
  1.3.1.0     2016-02-20   Added PROMPT ENTRY_FORM and LOG metacommands.
  1.2.15.0    2016-02-14   Added \$DB_NAME, \$DB_NEED_PWD, \$DB_SERVER, and \$DB_USER system variables. Added RAW as an export format for binary data. Added a PASSWORD keyword to the PROMPT ENTER_SUB metacommand. Allowed a password to be used in the CONNECT metacommand for Access. Other minor improvements and debugging.
  1.2.10.0    2016-01-23   Added ENCODING keyword to IMPORT metacommand. Added TIMER metacommand and \$TIMER system variable.
  1.2.8.2     2016-01-21   Fixed extra quoting in drop table method. Fixed str coercion in TXT export.
  1.2.8.0     2016-01-11   Suppressed column headers when EXPORTing to CSV and TSV with APPEND. Eliminated %H%M pattern to match time values in IMPORTed data.
  1.2.7.1     2016-01-03   Modified import of integers to Postgres; added the AUTOCOMMIT metacommand and modified the BATCH metacommand; changed to explicitly roll back any uncommitted changes on exit; miscellaneous debugging.
  1.2.4.6     2015-12-19   Modified quoting of column names for the COPY and IMPORT metacommands.
  1.2.4.5     2015-12-17   Fixed asterisks in PROMPT ENTER_SUB.
  1.2.4.4     2015-12-14   Fixed regexes for quoted filenames.
  1.2.4.3     2015-12-13   Fixed -y option display; fixed parsing of WRITE CREATE_TABLE comment option; fixed parsing of backslashes in substitution strings on Windows.
  1.2.4.0     2015-11-21   Added connections to PostgreSQL, SQL Server, MySQL, MariaDB, SQLite, and Firebird. Added numerous metacommands and conditional tests. Added reading of configuration files.
  0.4.4.0     2010-06-20   Added INCLUDE, WRITE, EXPORT, SUB, EXECUTE, HALT, and IF (HASROWS, SQL_ERROR) metacommands.
  0.3.1.0     2008-12-19   Added internal documentation.
  0.3.0.0     2008-05-20   Added cp1252 encoding for data read from Access.
  0.2.0.0     2008-04-26   Added creation and deletion of temporary views (queries) and export of final query to Excel.
  0.1.2.0     2008-04-22   Added regular expressions to match \'create temp view\...\' SQL command preface.
  0.1.1.0     2008-04-20   Converted to use DAO instead of the dbconnect library.
  0.1.0.0     2008-01-01   Modified to allow writing of the output of the last SQL command to a CSV file.
  0.0.1.0     2007-11-11   Created; executes SQL against Access.
