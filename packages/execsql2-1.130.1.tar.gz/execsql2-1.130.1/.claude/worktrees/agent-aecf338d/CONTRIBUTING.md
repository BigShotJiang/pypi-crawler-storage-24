# Contributing

## Development Setup

Requires [uv](https://docs.astral.sh/uv/).

```bash
git clone https://github.com/geocoug/execsql
cd execsql
uv sync
```

This creates a virtual environment at `.venv/` and installs all dev dependencies.

## Running Tests

```bash
uv run pytest tests/ -v
```

## Linting & Formatting

```bash
uv run ruff check src/       # lint
uv run ruff format src/      # format
```

CI will reject PRs that fail either check.

## Building the Docs Locally

```bash
uv run mkdocs serve
```

Then open [http://127.0.0.1:8000](http://127.0.0.1:8000).

## Building a Distribution

```bash
uv build
```

Artifacts are written to `dist/`.

## Releases

Releases are published to PyPI automatically when a `v*.*.*` tag is pushed:

```bash
git tag v1.131.0
git push origin v1.131.0
```

This triggers the `publish.yml` workflow, which builds the package, publishes to
PyPI via trusted publishing, and deploys the docs to GitHub Pages.

### PyPI Trusted Publishing Setup

The `publish.yml` workflow uses OIDC trusted publishing — no API token needed.
To configure it, go to the PyPI project settings and add a trusted publisher:

- **Owner:** `geocoug`
- **Repository:** `execsql`
- **Workflow:** `publish.yml`
- **Environment:** `pypi`

## Project Structure

```
execsql/
├── src/execsql2/          # Package source
│   ├── __init__.py
│   ├── __main__.py
│   └── execsql.py         # Main module (to be refactored)
├── tests/                 # pytest test suite
├── docs/                  # MkDocs documentation
│   └── images/
├── templates/             # Bundled SQL templates and config
├── .github/workflows/     # CI/CD
├── pyproject.toml
└── mkdocs.yml
```
