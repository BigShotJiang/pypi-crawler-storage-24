"""Entry point for execsql2."""
from execsql2.execsql import main

if __name__ == "__main__":
    main()
