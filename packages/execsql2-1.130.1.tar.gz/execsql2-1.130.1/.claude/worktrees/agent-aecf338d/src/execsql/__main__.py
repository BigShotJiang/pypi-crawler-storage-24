from __future__ import annotations

from execsql.cli import main

if __name__ == "__main__":
    main()
