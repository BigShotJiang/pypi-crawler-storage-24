from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from execsql.config import ConfigData

# Configuration data, initialized in main()
conf: Optional[ConfigData] = None

# Default encodings
logfile_encoding: str = "utf8"  # Should never be changed; is not configurable.

# The last command run.  This should be a ScriptCmd object.
last_command: Any = None

# The last user password entered via 'get_password()'
upass: Optional[str] = None

# A compiled regex to match prefixed regular expressions, used to check
# for unsubstituted variables.
varlike = re.compile(r"!![$@&~#]?\w+!!", re.I)

# A WriteSpec object for messages to be written when the program halts due to an error.
err_halt_writespec: Any = None

# A MailSpec object for email to be sent when the program halts due to an error.
err_halt_email: Any = None

# A ScriptExecSpec object for a script to be executed when the program halts due to an error.
err_halt_exec: Any = None

# A WriteSpec object for messages to be written when the program halts due to user cancellation.
cancel_halt_writespec: Any = None

# A MailSpec object for email to be sent when the program halts due to user cancellation.
cancel_halt_mailspec: Any = None

# A ScriptExecSpec object for a script to be executed when the program halts due to user cancellation.
cancel_halt_exec: Any = None

# A stack of the CommandList objects currently in the queue to be executed.
commandliststack: list = []

# A dictionary of CommandList objects (ordinarily created by BEGIN/END SCRIPT metacommands).
savedscripts: dict = {}

# A stack of CommandList objects used when compiling the statements within a loop.
loopcommandstack: list = []

# A global flag to indicate that commands should be compiled into the topmost entry
# in the loopcommandstack rather than executed.
compiling_loop: bool = False

# Compiled regex for END LOOP metacommand, which is immediate.
endloop_rx = re.compile(r"^\s*END\s+LOOP\s*$", re.I)

# Compiled regex for *start of* LOOP metacommand, for testing while compiling commands within a loop.
loop_rx = re.compile(r"\s*LOOP\s+", re.I)

# Nesting counter, to ensure loops are only ended when nesting level is zero.
loop_nest_level: int = 0

# A count of all of the commands run.
cmds_run: int = 0

# Pattern for deferred substitution, e.g.: "!{somevar}!"
defer_rx = re.compile(r"(!{([$@&~#]?[a-z0-9_]+)}!)", re.I)

# The string type (str in Python 3).
stringtypes: type = str

# The execution log object; set at startup.
exec_log: Any = None

# The substitution variable set; set at startup.
subvars: Any = None

# The program execution status tracker; set at startup.
status: Any = None
