from __future__ import annotations

import datetime
import getpass
import io
import os
import re
import sys
import tempfile
from typing import Any, Optional, List

import execsql.state as _state
from execsql.exporters.zip import ZipWriter


def export_html(outfile: str, hdrs: List[str], rows: Any, append: bool = False, querytext: Optional[str] = None, desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    conf = _state.conf

    def write_table(f):
        f.write(u'<table>\n')
        if desc is not None:
            f.write(f'<caption>{desc}</caption>\n')
        f.write(u'<thead><tr>')
        for h in hdrs:
            f.write(f'<th>{h}</th>')
        f.write(u'</tr></thead>\n<tbody>\n')
        for r in rows:
            f.write(u'<tr>')
            for v in r:
                f.write(f'<td>{v if v else u""}</td>')
            f.write(u'</tr>\n')
        f.write(u'</tbody>\n</table>\n')

    script, lno = _state.current_script_line()
    # If not append, write a complete HTML document with header and table.
    # If append and the file does not exist, write just the table.
    # If append and the file exists, R/W up to the </body> tag, write the table, write the remainder of the input.
    if zipfile or not append:
        if zipfile is None:
            if outfile.lower() == 'stdout':
                f = sys.stdout
            else:
                _state.filewriter_close(outfile)
                from execsql.utils.fileio import EncodedFile
                ef = EncodedFile(outfile, conf.output_encoding)
                f = ef.open("wt")
        else:
            f = ZipWriter(zipfile, outfile, append)
        f.write(u'<!DOCTYPE html>\n<html>\n<head>\n<meta charset="utf-8" />\n')
        if querytext:
            descrip = f"Source: [{querytext}] with database {_state.dbs.current().name()} in script {os.path.abspath(script)}, line {lno}"
        else:
            descrip = f"From database {_state.dbs.current().name()} in script {os.path.abspath(script)}, line {lno}"
        f.write(f'<meta name="description" content="{descrip}" />\n')
        datecontent = datetime.datetime.now().strftime("%Y-%m-%d")
        f.write(f'<meta name="created" content="{datecontent}" />\n')
        f.write(f'<meta name="revised" content="{datecontent}" />\n')
        f.write(f'<meta name="author" content="{getpass.getuser()}" />\n')
        f.write(u'<title>Data Table</title>\n')
        if conf.css_file or conf.css_styles:
            if conf.css_file:
                f.write(f'<link rel="stylesheet" type="text/css" href="{conf.css_file}">')
            if conf.css_styles:
                f.write(f'<style type="text/css">\n{conf.css_styles}\n</style>')
        else:
            f.write(u'<style type="text/css">\n')
            f.write(u'table {font-family: "Liberation Mono", "DejaVu Sans Mono", "Bitstream Vera Sans Mono", "Lucida Console", "Courier New", Courier, fixed; ' +
                    u'border-top: 3px solid #814324; border-bottom: 3px solid #814324; ' +
                    u'border-left: 2px solid #814324; border-right: 2px solid #814324; ' +
                    u'border-collapse: collapse; }\n')
            f.write(u'td {text-align: left; padding 0 10px; border-right: 1px dotted #814324; }\n')
            f.write(u'th {padding: 2px 10px; text-align: center; border-bottom: 1px solid #814324; border-right: 1px dotted #814324;}\n')
            f.write(u'tr.hdr {font-weight: bold;}\n')
            f.write(u'thead tr {border-bottom: 1px solid #814324; background-color: #F3F1E2; }\n')
            f.write(u'tbody tr { border-bottom: 1px dotted #814324; }\n')
            f.write(u'</style>')
        f.write(u'\n</head>\n<body>\n')
        write_table(f)
        f.write(u'</body>\n</html>\n')
        f.close()
    elif not zipfile and append:
        if outfile.lower() == 'stdout':
            f = sys.stdout
            write_table(f)
        elif not os.path.isfile(outfile):
            from execsql.utils.fileio import EncodedFile
            ef = EncodedFile(outfile, conf.output_encoding)
            f = ef.open("wt")
            write_table(f)
            f.close()
        else:
            _state.filewriter_close(outfile)
            from execsql.utils.fileio import EncodedFile
            ef = EncodedFile(outfile, conf.output_encoding)
            f = ef.open("rt")
            tempf, tempfname = tempfile.mkstemp(text=True)
            tf = EncodedFile(tempfname, conf.output_encoding)
            t = tf.open("wt")
            remainder = u''
            for line in f:
                bodypos = line.lower().find("</body>")
                if bodypos > -1:
                    t.write(line[0:bodypos])
                    t.write(u"\n")
                    remainder = line[bodypos:]
                    break
                else:
                    t.write(line)
            t.write(u"\n")
            write_table(t)
            t.write(remainder)
            for line in f:
                t.write(line)
            t.close()
            f.close()
            os.unlink(outfile)
            os.rename(tempfname, outfile)


def export_cgi_html(outfile: str, hdrs: List[str], rows: Any, append: bool = False, querytext: Optional[str] = None, desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    conf = _state.conf

    def write_table(f):
        f.write(u'<table>\n')
        if desc is not None:
            f.write(f'<caption>{desc}</caption>\n')
        f.write(u'<thead><tr>')
        for h in hdrs:
            f.write(f'<th>{h}</th>')
        f.write(u'</tr></thead>\n<tbody>\n')
        for r in rows:
            f.write(u'<tr>')
            for v in r:
                f.write(f'<td>{v if v else u""}</td>')
            f.write(u'</tr>\n')
        f.write(u'</tbody>\n</table>\n')

    script, lno = _state.current_script_line()
    if zipfile or not append or (append and not os.path.isfile(outfile)):
        if zipfile is None:
            if outfile.lower() == 'stdout':
                f = sys.stdout
            else:
                _state.filewriter_close(outfile)
                from execsql.utils.fileio import EncodedFile
                ef = EncodedFile(outfile, conf.output_encoding)
                f = ef.open("wt")
        else:
            f = ZipWriter(zipfile, outfile, append)
        f.write(u'Content-Type: text/html\n\n')
        write_table(f)
        if outfile.lower() != 'stdout':
            f.close()
    else:
        if outfile == 'stdout':
            f = sys.stdout
        else:
            from execsql.utils.fileio import EncodedFile
            ef = EncodedFile(outfile, conf.output_encoding)
            f = ef.open("a")
        write_table(f)
        if outfile.lower() != 'stdout':
            f.close()


def write_query_to_html(select_stmt: str, db: Any, outfile: str, append: bool = False, desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    try:
        hdrs, rows = db.select_rowsource(select_stmt)
    except _state.ErrInfo:
        raise
    except:
        raise _state.ErrInfo("db", select_stmt, exception_msg=_state.exception_desc())
    export_html(outfile, hdrs, rows, append, select_stmt, desc, zipfile=zipfile)


def write_query_to_cgi_html(select_stmt: str, db: Any, outfile: str, append: bool = False, desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    try:
        hdrs, rows = db.select_rowsource(select_stmt)
    except _state.ErrInfo:
        raise
    except:
        raise _state.ErrInfo("db", select_stmt, exception_msg=_state.exception_desc())
    export_cgi_html(outfile, hdrs, rows, append, select_stmt, desc, zipfile=zipfile)
