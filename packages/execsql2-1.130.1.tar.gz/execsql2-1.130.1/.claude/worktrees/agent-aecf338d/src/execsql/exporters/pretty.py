from __future__ import annotations

import io
import os
from typing import Any, Optional, List

import execsql.state as _state
from execsql.exporters.zip import ZipWriter


def prettyprint_rowset(colhdrs: List[str], rows: Any, output_dest: str, append: bool = False, nd_val: str = u'', desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    # Adapted from the pp() function by Aaron Watters,
    # posted to gadfly-rdbms@egroups.com 1999-01-18.
    def as_ucode(s):
        if s is None:
            return nd_val
        if isinstance(s, type(u"")):
            return s
        if type(s) in (type(memoryview(b'')), bytes, bytearray):
            return f"Binary data ({len(s)} bytes)"
        else:
            if type(s) == type(b''):
                return s.decode(_state.dbs.current().encoding)
        return str(s)

    if type(rows) != 'list':
        try:
            rows = list(rows)
        except:
            raise _state.ErrInfo("exception", exception_msg=_state.exception_desc(), other_msg="Can't create a list in memory of the data to be displayed as formatted text.")
    rcols = range(len(colhdrs))
    rrows = range(len(rows))
    colwidths = [max(0, len(colhdrs[j]), *(len(as_ucode(rows[i][j])) for i in rrows)) for j in rcols]
    names = u' ' + u' | '.join([colhdrs[j].ljust(colwidths[j]) for j in rcols])
    sep = u'|'.join([u'-' * (colwidths[j] + 2) for j in rcols])
    rows = [names, sep] + [u' ' + u' | '.join(
            [as_ucode(rows[i][j]).ljust(colwidths[j])
            for j in rcols]) for i in rrows]
    if output_dest == 'stdout':
        ofile = _state.output
        margin = u'    '
    else:
        margin = u' '
        if zipfile is None:
            from execsql.utils.fileio import EncodedFile
            _state.filewriter_close(output_dest)
            if append:
                ofile = EncodedFile(output_dest, _state.conf.output_encoding).open("a")
            else:
                ofile = EncodedFile(output_dest, _state.conf.output_encoding).open("w")
        else:
            ofile = ZipWriter(zipfile, output_dest, append)
    if desc is not None:
        ofile.write(f"{desc}\n")
    for row in rows:
        ln = f"{margin}{row}\n"
        ofile.write(ln)
    if output_dest != 'stdout':
        ofile.close()
    return None


def prettyprint_query(select_stmt: str, db: Any, outfile: str, append: bool = False, nd_val: str = u'', desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    _state.status.sql_error = False
    names, rows = db.select_data(select_stmt)
    prettyprint_rowset(names, rows, outfile, append, nd_val, desc, zipfile=zipfile)
