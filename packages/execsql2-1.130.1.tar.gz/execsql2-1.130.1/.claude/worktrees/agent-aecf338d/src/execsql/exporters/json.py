from __future__ import annotations

import datetime
import io
import os
from typing import Any, Optional, List

import execsql.state as _state
from execsql.exporters.zip import ZipWriter


def write_query_to_json(select_stmt: str, db: Any, outfile: str, append: bool = False, desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    global json
    import json
    conf = _state.conf
    try:
        hdrs, rows = db.select_rowsource(select_stmt)
    except _state.ErrInfo:
        raise
    except:
        raise _state.ErrInfo("db", select_stmt, exception_msg=_state.exception_desc())
    if zipfile is None:
        _state.filewriter_close(outfile)
        from execsql.utils.fileio import EncodedFile
        ef = EncodedFile(outfile, conf.output_encoding)
        if append:
            f = ef.open("at")
            f.write(u",\n")
        else:
            f = ef.open("wt")
    else:
        f = ZipWriter(zipfile, outfile, append)
    f.write(u"[")
    uhdrs = [str(h) for h in hdrs]
    first = True
    for row in rows:
        if first:
            f.write(u"\n")
        else:
            f.write(u",\n")
        first = False
        dictdata = dict(zip(uhdrs, [str(v) if isinstance(v, str) else v for v in row]))
        jsondata = json.dumps(dictdata, separators=(u',', u':'), default=str)
        f.write(str(jsondata))
    f.write(u"\n]\n")
    f.close()


def write_query_to_json_ts(select_stmt: str, db: Any, outfile: str, append: bool = False, write_types: bool = True, desc: Optional[str] = None, zipfile: Optional[str] = None) -> None:
    conf = _state.conf
    try:
        hdrs, rows = db.select_rowsource(select_stmt)
    except _state.ErrInfo:
        raise
    except:
        raise _state.ErrInfo("db", select_stmt, exception_msg=_state.exception_desc())
    max_col_idx = len(hdrs) - 1
    if zipfile is None:
        _state.filewriter_close(outfile)
        from execsql.utils.fileio import EncodedFile
        ef = EncodedFile(outfile, conf.output_encoding)
        if append:
            f = ef.open("at")
            f.write(u",\n")
        else:
            f = ef.open("wt")
    else:
        f = ZipWriter(zipfile, outfile, append)
    f.write(u'{\n')
    if desc is not None:
        f.write(f'  "description": "{desc}",\n')
    f.write(u'  "fields": [\n')
    if write_types:
        # Scan the data to determine data types.
        tbl_desc = _state.DataTable(hdrs, rows)
        # Write the column descriptions to the header.
        # Iterate over hdrs instead of tbl_desc.cols to preserve column order.
        for i, h in enumerate(hdrs):
            qcomma = u"," if i < max_col_idx else u""
            c = [col for col in tbl_desc.cols if col.name == h][0]
            f.write(f'    {{\n      "name": "{c.name}",\n      "title": "{c.name.capitalize().replace("_", " ")}",\n      "type": "{_state.to_json_type[c.dt[1]]}"\n    }}{qcomma}\n')
    else:
        # Write the column descriptions to the header.
        for i, h in enumerate(hdrs):
            qcomma = u"," if i < max_col_idx else u""
            f.write(f'    {{\n      "name": "{h}",\n      "title": "{h.capitalize().replace("_", " ")}"\n    }}{qcomma}\n')
    f.write(u'  ]\n}\n')
    f.close()
