from __future__ import annotations

import os
from typing import Optional

from execsql.exceptions import ErrInfo
from execsql.db.access import AccessDatabase
from execsql.db.dsn import DsnDatabase
from execsql.db.sqlserver import SqlServerDatabase
from execsql.db.postgres import PostgresDatabase
from execsql.db.oracle import OracleDatabase
from execsql.db.sqlite import SQLiteDatabase
from execsql.db.duckdb import DuckDBDatabase
from execsql.db.mysql import MySQLDatabase
from execsql.db.firebird import FirebirdDatabase


def db_Access(
    Access_fn: str,
    pw_needed: bool = False,
    user: Optional[str] = None,
    encoding: Optional[str] = None,
) -> AccessDatabase:
    if not os.path.exists(Access_fn):
        raise ErrInfo(
            type="error",
            other_msg=f'Access database file "{Access_fn}" does not exist.',
        )
    return AccessDatabase(Access_fn, need_passwd=pw_needed, user_name=user, encoding=encoding)


def db_Postgres(
    server_name: str,
    database_name: str,
    user: Optional[str] = None,
    pw_needed: bool = True,
    port: Optional[int] = None,
    encoding: Optional[str] = None,
    new_db: bool = False,
) -> PostgresDatabase:
    return PostgresDatabase(server_name, database_name, user, pw_needed, port, new_db=new_db)


def db_SQLite(
    sqlite_fn: str,
    new_db: bool = False,
    encoding: Optional[str] = None,
) -> SQLiteDatabase:
    if new_db:
        from execsql.utils.fileio import check_dir
        check_dir(sqlite_fn)
    else:
        if not os.path.exists(sqlite_fn):
            raise ErrInfo(
                type="error",
                other_msg=f'SQLite database file "{sqlite_fn}" does not exist.',
            )
    return SQLiteDatabase(sqlite_fn)


def db_SqlServer(
    server_name: str,
    database_name: str,
    user: Optional[str] = None,
    pw_needed: bool = True,
    port: Optional[int] = None,
    encoding: Optional[str] = None,
) -> SqlServerDatabase:
    return SqlServerDatabase(server_name, database_name, user, pw_needed, port, encoding)


def db_MySQL(
    server_name: str,
    database_name: str,
    user: Optional[str] = None,
    pw_needed: bool = True,
    port: Optional[int] = None,
    encoding: Optional[str] = None,
) -> MySQLDatabase:
    return MySQLDatabase(server_name, database_name, user, pw_needed, port, encoding)


def db_DuckDB(
    duckdb_fn: str,
    new_db: bool = False,
    encoding: Optional[str] = None,
) -> DuckDBDatabase:
    if new_db:
        from execsql.utils.fileio import check_dir
        check_dir(duckdb_fn)
    else:
        if not os.path.exists(duckdb_fn):
            raise ErrInfo(
                type="error",
                other_msg=f'DuckDB database file "{duckdb_fn}" does not exist.',
            )
    return DuckDBDatabase(duckdb_fn)


def db_Oracle(
    server_name: str,
    database_name: str,
    user: Optional[str] = None,
    pw_needed: bool = True,
    port: Optional[int] = None,
    encoding: Optional[str] = None,
) -> OracleDatabase:
    return OracleDatabase(server_name, database_name, user, pw_needed, port, encoding)


def db_Firebird(
    server_name: str,
    database_name: str,
    user: Optional[str] = None,
    pw_needed: bool = True,
    port: Optional[int] = None,
    encoding: Optional[str] = None,
) -> FirebirdDatabase:
    return FirebirdDatabase(server_name, database_name, user, pw_needed, port, encoding)


def db_Dsn(
    dsn_name: str,
    user: Optional[str] = None,
    pw_needed: bool = True,
    encoding: Optional[str] = None,
) -> DsnDatabase:
    return DsnDatabase(dsn_name=dsn_name, user_name=user, need_passwd=pw_needed, encoding=encoding)
