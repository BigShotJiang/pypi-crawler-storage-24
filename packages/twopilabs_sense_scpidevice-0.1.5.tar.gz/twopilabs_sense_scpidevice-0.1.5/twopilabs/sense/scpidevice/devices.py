from twopilabs.utils.scpi import ScpiResource, ScpiSerialTransport, ScpiUsbCdcTransport, ScpiTcpIpTransport, ScpiUsbTmcTransport


class SenseDevice:
    name: str
    display_name: str = None
    transports: list
    usb_vid: int = None
    usb_pid: int = None
    dnssd_services: list = None
    dnssd_names: list = None
    dnssd_domains: list = None

    @classmethod
    def discover(cls, **kwargs):
        if cls.transports is not None: kwargs.setdefault('transports', cls.transports)
        if cls.usb_vid is not None: kwargs.setdefault('usb_vid', cls.usb_vid)
        if cls.usb_pid is not None: kwargs.setdefault('usb_pid', cls.usb_pid)
        if cls.dnssd_services is not None: kwargs.setdefault('dnssd_services', cls.dnssd_services)
        if cls.dnssd_names is not None: kwargs.setdefault('dnssd_names', cls.dnssd_names)
        if cls.dnssd_domains is not None: kwargs.setdefault('dnssd_domains', cls.dnssd_domains)

        return ScpiResource.discover(**kwargs)


class ArubaDevice(SenseDevice):
    name = 'Aruba'
    display_name = '2πSENSE Aruba'
    transports = [ScpiSerialTransport, ScpiUsbCdcTransport]
    usb_vid = 0x0483
    usb_pid = 0xA53A


class TahitiDevice(SenseDevice):
    name = 'Tahiti'
    display_name = '2πSENSE X1000'
    transports = [ScpiTcpIpTransport, ScpiUsbTmcTransport]
    usb_vid = 0x1FC9
    usb_pid = 0x8271
    dnssd_services = ['_scpi-raw._tcp']
    dnssd_names = ['2πSENSE X1000.*']
    dnssd_domains = ['local']

SENSE_DEVICES = [ArubaDevice, TahitiDevice]