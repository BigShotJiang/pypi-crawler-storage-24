"""Troi MCP Server - connects Claude Desktop to Troi project management."""

__version__ = "1.2.0"
