"""open-panacea — Alias for CyberHuaTuo"""
from cyberhuatuo import *  # noqa: F401,F403
