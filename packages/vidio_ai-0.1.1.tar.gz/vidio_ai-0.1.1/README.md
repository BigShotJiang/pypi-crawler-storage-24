# VIDIO Python SDK

Official Python SDK for interacting with the VIDIO API ([https://www.vidio.ai](https://www.vidio.ai)).

This SDK allows developers to:

- Upload videos
- Create highlight reels
- Check job status
- Render output videos

## Installation

For installation, please visit our official documentation [here](https://www.vidio.ai/docs/quickstart)