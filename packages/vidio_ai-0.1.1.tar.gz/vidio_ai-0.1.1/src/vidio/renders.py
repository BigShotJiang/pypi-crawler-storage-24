from .models import RenderResult


def render(
    client,
    job_id: str,
    export_option: str,
    output_index: int,
) -> RenderResult:
    payload = {
        "export_option": export_option,
        "output_index": output_index,
    }

    resp = client._request(
        "POST",
        f"/api/v1/jobs/{job_id}/render",
        json=payload,
    )

    return RenderResult(
        job_id=job_id,
        status=resp["status"],
    )


def get_render(client, job_id: str) -> RenderResult:
    # backend does not have a separate render-status route
    # it reuses GET /jobs/:job_id/status
    resp = client._request(
        "GET",
        f"/api/v1/jobs/{job_id}/status",
    )

    return RenderResult(
        job_id=job_id,
        status=resp["status"],
    )