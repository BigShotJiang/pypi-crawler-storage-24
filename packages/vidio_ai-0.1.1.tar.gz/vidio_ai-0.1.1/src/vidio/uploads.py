import os
import uuid
from tqdm import tqdm
import httpx

from .media_probe import infer_media_type, probe_media
from .models import UploadResult
from .exceptions import UploadError


class ProgressByteStream(httpx.SyncByteStream):
    def __init__(
        self,
        file_path: str,
        chunk_size: int = 1024 * 1024,
        show_progress: bool = True,
        desc: str = "Uploading",
    ):
        self.file_path = file_path
        self.chunk_size = chunk_size
        self.file_size = os.path.getsize(file_path)
        self.show_progress = show_progress
        self.desc = desc

    def __iter__(self):
        pbar = (
            tqdm(total=self.file_size, unit="B", unit_scale=True, desc=self.desc)
            if self.show_progress
            else None
        )

        try:
            with open(self.file_path, "rb") as f:
                while True:
                    chunk = f.read(self.chunk_size)
                    if not chunk:
                        break
                    if pbar:
                        pbar.update(len(chunk))
                    yield chunk
        finally:
            if pbar:
                pbar.close()


def upload(
    client,
    file_path: str,
    media_type: str | None = None,
    metadata: dict | None = None,
    show_progress: bool = True,
) -> UploadResult:
    if not os.path.exists(file_path):
        raise UploadError(f"File does not exist: {file_path}")

    if not os.path.isfile(file_path):
        raise UploadError(f"Not a file: {file_path}")

    file_name = os.path.basename(file_path)
    file_ext = os.path.splitext(file_name)[1].lstrip(".").lower()
    if not file_ext:
        raise UploadError(f"File has no extension: {file_name}")

    media_type = media_type or infer_media_type(file_path)
    info = probe_media(file_path, media_type=media_type)

    if info.width is None:
        raise UploadError(f"Could not determine width for file: {file_name}")

    if info.height is None:
        raise UploadError(f"Could not determine height for file: {file_name}")

    if info.duration_sec is None:
        raise UploadError(f"Could not determine duration for file: {file_name}")

    job_id = str(uuid.uuid4())
    metadata = metadata or {}

    params = {
        "job_id": job_id,
        "file_name": file_name,
        "file_type": file_ext,
        "media_type": media_type,
        "width": str(info.width),
        "height": str(info.height),
        "duration": str(info.duration_sec),
    }

    for k, v in metadata.items():
        if v is not None:
            params[str(k)] = str(v)

    params["to_be_downscaled"] = "true"

    resp = client._request("GET", "/api/v1/uploads/upload-url", params=params)
    signed_url = resp["url"]

    file_size = os.path.getsize(file_path)
    stream = ProgressByteStream(
        file_path=file_path,
        show_progress=show_progress,
        desc="Uploading",
    )

    upload_resp = client._raw_put(
        signed_url,
        content=stream,
        media_type=media_type,
        file_ext=file_ext,
        content_length=file_size,
    )

    if upload_resp.status_code >= 400:
        raise UploadError(
            f"Upload failed ({upload_resp.status_code}): {upload_resp.text}"
        )

    input_key = _build_input_key(job_id, file_name)

    return UploadResult(
        file_name=file_name,
        media_type=media_type,
        input_key=input_key,
        width=info.width,
        height=info.height,
        duration_sec=info.duration_sec,
        uploaded=True,
    )

def _build_input_key(job_id: str, file_name: str) -> str:
    return f"uploads/{job_id}/{file_name}"