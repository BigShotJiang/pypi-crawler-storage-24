DEFAULT_BASE_URL = "https://api.vidio.ai"

DEFAULT_TIMEOUT = 30.0

USER_AGENT = "vidio-python-sdk/0.1.1"