class VidioError(Exception):
    """Base exception for VIDIO SDK."""


class AuthenticationError(VidioError):
    pass


class ApiError(VidioError):
    pass


class UploadError(VidioError):
    pass


class JobError(VidioError):
    pass


class RenderError(VidioError):
    pass


class TimeoutError(VidioError):
    pass