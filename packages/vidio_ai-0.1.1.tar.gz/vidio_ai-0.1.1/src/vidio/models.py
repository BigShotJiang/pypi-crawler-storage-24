from dataclasses import dataclass
from typing import Any


@dataclass
class MediaInfo:
    media_type: str | None
    width: int | None = None
    height: int | None = None
    duration_sec: float | None = None


@dataclass
class UploadResult:
    file_name: str
    media_type: str
    input_key: str
    width: int | None = None
    height: int | None = None
    duration_sec: float | None = None
    uploaded: bool = True
    raw: dict[str, Any] | None = None


@dataclass
class JobResult:
    job_id: str
    status: str


@dataclass
class JobStatusResult:
    job_id: str
    status: str


@dataclass
class RenderResult:
    job_id: str
    status: str