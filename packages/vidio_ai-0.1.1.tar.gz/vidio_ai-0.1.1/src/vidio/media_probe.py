import json
import mimetypes
import os
import subprocess

from .models import MediaInfo


VIDEO_EXTENSIONS = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm"}
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}


def infer_media_type(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()

    if ext in VIDEO_EXTENSIONS:
        return "video"
    if ext in IMAGE_EXTENSIONS:
        return "image"

    guessed, _ = mimetypes.guess_type(file_path)
    if guessed:
        if guessed.startswith("video/"):
            return "video"
        if guessed.startswith("image/"):
            return "image"

    raise ValueError(f"Could not infer media type from file: {file_path}")


def probe_media(file_path: str, media_type: str | None = None) -> MediaInfo:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File does not exist: {file_path}")

    media_type = media_type or infer_media_type(file_path)

    if media_type == "image":
        return _probe_image(file_path)

    if media_type == "video":
        return _probe_video(file_path)

    return MediaInfo(media_type=media_type)


def _probe_video(file_path: str) -> MediaInfo:
    cmd = [
        "ffprobe",
        "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=width,height:format=duration",
        "-of", "json",
        file_path,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        return MediaInfo(media_type="video")

    try:
        data = json.loads(result.stdout or "{}")
        streams = data.get("streams") or []
        fmt = data.get("format") or {}

        width = None
        height = None
        if streams:
            width = streams[0].get("width")
            height = streams[0].get("height")

        duration = fmt.get("duration")
        duration_sec = float(duration) if duration is not None else None

        return MediaInfo(
            media_type="video",
            width=int(width) if width is not None else None,
            height=int(height) if height is not None else None,
            duration_sec=duration_sec,
        )
    except Exception:
        return MediaInfo(media_type="video")


def _probe_image(file_path: str) -> MediaInfo:
    try:
        from PIL import Image
    except ImportError:
        return MediaInfo(media_type="image")

    try:
        with Image.open(file_path) as img:
            width, height = img.size
            return MediaInfo(
                media_type="image",
                width=width,
                height=height,
                duration_sec=None,
            )
    except Exception:
        return MediaInfo(media_type="image")