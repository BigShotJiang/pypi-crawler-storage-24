import time

from .exceptions import ApiError


TERMINAL_JOB_STATUSES = {"processed", "rendered", "failed", "error"}
ACTIVE_JOB_STATUSES = {
    "loaded",
    "processing",
    "submitted",
    "queued",
    "rendering",
    "cpu_work_pending",
    "small_work_pending",
    "big_work_pending",
}


def wait_for_job(
    client,
    job_id: str,
    poll_interval: float = 5.0,
    timeout: float = 3600.0,
):
    start = time.time()

    while True:
        result = client.get_job(job_id)
        status = result.status

        if status in TERMINAL_JOB_STATUSES:
            return result

        if time.time() - start > timeout:
            raise ApiError(f"Timed out waiting for job {job_id}")

        time.sleep(poll_interval)


def wait_for_render(
    client,
    job_id: str,
    poll_interval: float = 5.0,
    timeout: float = 3600.0,
):
    start = time.time()

    while True:
        result = client.get_render(job_id)
        status = result.status

        if status == "rendered":
            return result

        if status in {"failed", "error"}:
            return result

        if time.time() - start > timeout:
            raise ApiError(f"Timed out waiting for render for job {job_id}")

        time.sleep(poll_interval)