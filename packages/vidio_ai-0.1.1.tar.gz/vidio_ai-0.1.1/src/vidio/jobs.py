from .models import JobResult, JobStatusResult


def create_highlight_reel(
    client,
    input_keys: list[str],
    video_category: str,
    output_length: float,
    aspect_ratio: str,
) -> JobResult:

    if not input_keys or not isinstance(input_keys, list):
        raise ValueError("input_keys must be a non-empty list")
    
    VALID_VIDEO_CATEGORIES = {
        "podcast",
        "ball-sports",
        "non-ball-sports",
        "beauty-product-demo",
        "wedding",
        "travel",
        "others",
    }

    VALID_ASPECT_RATIOS = {"square", "portrait", "landscape"}

    if video_category not in VALID_VIDEO_CATEGORIES:
        raise ValueError(f"Invalid video_category: {video_category}")

    if aspect_ratio not in VALID_ASPECT_RATIOS:
        raise ValueError(f"Invalid aspect_ratio: {aspect_ratio}")

    payload = {
        "input_keys": input_keys,
        "video_category": video_category,
        "output_length": output_length,
        "aspect_ratio": aspect_ratio,
    }

    resp = client._request(
        "POST",
        "/api/v1/jobs/highlight-reel",
        json=payload,
    )

    return JobResult(
        job_id=resp["job_id"],
        status=resp["status"],
    )


def get_job(client, job_id: str) -> JobStatusResult:
    resp = client._request(
        "GET",
        f"/api/v1/jobs/{job_id}/status",
    )

    return JobStatusResult(
        job_id=job_id,
        status=resp["status"],
    )