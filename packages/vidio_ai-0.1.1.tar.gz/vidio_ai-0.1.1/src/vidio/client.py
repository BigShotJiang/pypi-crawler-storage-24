import mimetypes
import httpx

from .config import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, USER_AGENT
from .exceptions import ApiError, AuthenticationError
from .uploads import upload as _upload
from .jobs import create_highlight_reel as _create_highlight_reel, get_job as _get_job
from .renders import render as _render, get_render as _get_render
from .polling import wait_for_job as _wait_for_job, wait_for_render as _wait_for_render


class VidioClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key

        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={
                "x-api-key": api_key,
                "User-Agent": USER_AGENT,
            },
            timeout=timeout,
        )

    def _request(self, method: str, path: str, **kwargs):
        response = self._client.request(method, path, **kwargs)

        if response.status_code == 401:
            raise AuthenticationError("Invalid API key")

        if response.status_code >= 400:
            raise ApiError(
                f"API request failed ({response.status_code}): {response.text}"
            )

        if response.content:
            return response.json()

        return None

    def _raw_put(
        self,
        url: str,
        content,
        media_type: str,
        file_ext: str,
        content_length: int | None = None,
    ):
        content_type, _ = mimetypes.guess_type(f"file.{file_ext}")
        if not content_type:
            content_type = f"{media_type}/{file_ext}"

        headers = {
            "Content-Type": content_type,
        }

        if content_length is not None:
            headers["Content-Length"] = str(content_length)

        return httpx.put(
            url,
            content=content,
            headers=headers,
            timeout=self._client.timeout,
        )

    def upload(
        self,
        file_path: str,
        media_type: str | None = None,
        metadata: dict | None = None,
    ):
        return _upload(
            self,
            file_path=file_path,
            media_type=media_type,
            metadata=metadata,
        )

    def create_highlight_reel(
        self,
        input_keys: list[str],
        video_category: str,
        output_length: float,
        aspect_ratio: str,
    ):
        return _create_highlight_reel(
            self,
            input_keys=input_keys,
            video_category=video_category,
            output_length=output_length,
            aspect_ratio=aspect_ratio,
        )

    def get_job(self, job_id: str):
        return _get_job(self, job_id=job_id)

    def wait_for_job(
        self,
        job_id: str,
        poll_interval: float = 5.0,
        timeout: float = 3600.0,
    ):
        return _wait_for_job(
            self,
            job_id=job_id,
            poll_interval=poll_interval,
            timeout=timeout,
        )

    def render(
        self,
        job_id: str,
        export_option: str = "premium",
        output_index: int = 0,
    ):
        return _render(
            self,
            job_id=job_id,
            export_option=export_option,
            output_index=output_index,
        )

    def get_render(self, job_id: str):
        return _get_render(self, job_id=job_id)

    def wait_for_render(
        self,
        job_id: str,
        poll_interval: float = 5.0,
        timeout: float = 3600.0,
    ):
        return _wait_for_render(
            self,
            job_id=job_id,
            poll_interval=poll_interval,
            timeout=timeout,
        )

    def close(self):
        self._client.close()