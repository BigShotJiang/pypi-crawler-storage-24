"""
01_single_agent.py — Simplest possible example: one agent, one LLM call.

WHAT THE DASHBOARD SHOULD SHOW:
  Live Graph:
    • One node: "analyst" (green = success)
    • No edges (no parent, no children)

  State View:
    • Step 1 — analyst: INPUT = {topic}, OUTPUT = summary string

  Time Travel:
    • Single step scrubber

  Token Dashboard:
    • One bar: analyst ~300-500 tokens
    • Donut: 100% analyst

  Run Comparison:
    • One row: analyst | SUCCESS | ~2s | ~400 tokens

  Failure History:
    • Empty (this run succeeds)
"""
import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from agentradar import radar, reset_run

load_dotenv()

llm = ChatOpenAI(
    api_key=os.getenv("DEEPSEEK_API_KEY"),
    base_url=os.getenv("DEEPSEEK_BASE_URL"),
    model=os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
    temperature=0.3,
)


@radar(tag="analyst", llm_input="Analyze this topic and return a 3-sentence summary")
def analyst(topic: str) -> str:
    """Single agent: analyze a topic and return a concise summary."""
    message = llm.invoke(f"Analyze this topic and return a 3-sentence summary:\n{topic}")
    return message.content


def main():
    reset_run()
    topic = "The impact of large language models on software development"

    print("=== Single Agent Example ===\n")
    result = analyst(topic)
    print(f"Result:\n{result}")
    print("\n✓ Dashboard should show: 1 green node, 1 step, token bar for 'analyst'")


if __name__ == "__main__":
    main()
    input("\nPress Enter to view dashboard (http://localhost:7111) or Ctrl+C to exit...")
