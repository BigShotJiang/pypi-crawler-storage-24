import requests
from pathlib import Path

BASE_URL = "https://api.geoaxis.ai"
ACCEPTED_FORMATS = {"png", "jpg", "jpeg", "heic", "bmp", "webp"}


class GeoAxisError(Exception):
    def __init__(self, status_code, message, data=None):
        self.status_code = status_code
        self.data = data or {}
        super().__init__(f"[{status_code}] {message}")


def _raise_for_status(resp):
    if not resp.ok:
        try:
            data = resp.json()
            msg = data.get("error", resp.text)
        except Exception:
            data = {}
            msg = resp.text
        raise GeoAxisError(resp.status_code, msg, data)
    return resp


class GeoAxis:
    def __init__(self, token: str = None):
        if not api_key and not token:
            raise ValueError("Provide a token")
        self.session = requests.Session()
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"