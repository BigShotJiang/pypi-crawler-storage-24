"""Tests for the _check_text type in daemon/commands.py."""

from __future__ import annotations

import pytest

from daemon.channels.file import FileChannel
from daemon.commands import _check_text


@pytest.fixture
def channel(config):
    return FileChannel(config.storage.outbox_dir)


def test_contiguous_match_case_insensitive():
    """A contiguous case-insensitive match is detected."""
    secret = "John Doe"
    doc_text = "The applicant is john doe and resides in Springfield."
    result = _check_text("fullname", secret, doc_text, ctx_window=40)
    assert "contiguous match" in result.lower()
    assert "MATCHES VAULT SECRET" in result


def test_component_matching():
    """Name split across First Name / Last Name fields is found via components."""
    secret = "Jane Smith"
    # The name appears in separate fields, not contiguously
    doc_text = "First Name: Jane\nMiddle: A\nLast Name: Smith\nDOB: 1990-01-01"
    result = _check_text("name", secret, doc_text, ctx_window=40)
    # Should find both components but not as contiguous
    assert "components found" in result.lower() or "contiguous" in result.lower()


def test_partial_match():
    """When some components are found and some are not, reports partial match."""
    secret = "Alice Wonderland"
    doc_text = "Hello Alice, welcome to the real world."
    result = _check_text("name", secret, doc_text, ctx_window=40)
    assert "PARTIAL MATCH" in result
    assert "1/2" in result


def test_no_components_found():
    """When no components are found, reports NOT FOUND."""
    secret = "Xyzzy Plugh"
    doc_text = "This document contains no matching names at all."
    result = _check_text("name", secret, doc_text, ctx_window=40)
    assert "NOT FOUND" in result


def test_short_components_filtered():
    """Components shorter than 2 characters are filtered out.

    If the secret is e.g. 'A B', both components are < 2 chars,
    so the function should return NOT FOUND (no components to search).
    """
    secret = "A B"
    doc_text = "A B appears in this document verbatim."
    result = _check_text("initials", secret, doc_text, ctx_window=40)
    # "A" and "B" are both < 2 chars, filtered out. But the contiguous match
    # should still work since "A B" appears in the text.
    # Let's check: doc_lower.find("a b") will find it, so contiguous match.
    assert "contiguous match" in result.lower()


def test_short_components_filtered_no_contiguous():
    """When short components are filtered and there is no contiguous match, returns NOT FOUND."""
    secret = "X Y"
    doc_text = "X is here but Y is somewhere else entirely separate from X."
    result = _check_text("initials", secret, doc_text, ctx_window=40)
    # "X Y" is not contiguous in doc_text, and "X" and "Y" are < 2 chars
    # so component search returns no valid components -> NOT FOUND
    assert "NOT FOUND" in result
