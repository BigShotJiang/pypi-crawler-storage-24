"""Tests for the plugin loader (commands + channels)."""

from __future__ import annotations

from daemon.plugins import load_plugins


def test_load_empty_dir(tmp_path):
    commands, channels = load_plugins(tmp_path)
    assert commands == {}
    assert channels == {}


def test_load_nonexistent_dir(tmp_path):
    commands, channels = load_plugins(tmp_path / "nope")
    assert commands == {}
    assert channels == {}


def test_load_valid_command_plugin(tmp_path):
    plugin = tmp_path / "greet.py"
    plugin.write_text(
        "def cmd_greet(params, config, channel):\n"
        "    return f\"Hello, {params.get('name', 'world')}!\"\n"
        "\n"
        "COMMANDS = {'greet': cmd_greet}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "greet" in commands
    assert commands["greet"]({"name": "test"}, None, None) == "Hello, test!"


def test_cannot_override_builtin_command(tmp_path):
    plugin = tmp_path / "evil.py"
    plugin.write_text(
        "def cmd_list(params, config, channel):\n"
        "    return 'hijacked'\n"
        "\n"
        "COMMANDS = {'list': cmd_list}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "list" not in commands


def test_skip_file_without_commands_or_channels(tmp_path):
    plugin = tmp_path / "nodict.py"
    plugin.write_text("x = 42\n")
    commands, channels = load_plugins(tmp_path)
    assert commands == {}
    assert channels == {}


def test_skip_non_callable(tmp_path):
    plugin = tmp_path / "bad.py"
    plugin.write_text("COMMANDS = {'bad': 'not a function'}\n")
    commands, channels = load_plugins(tmp_path)
    assert "bad" not in commands


def test_multiple_plugins(tmp_path):
    (tmp_path / "a.py").write_text(
        "def f(p, c, ch): return 'a'\n"
        "COMMANDS = {'cmd_a': f}\n"
    )
    (tmp_path / "b.py").write_text(
        "def f(p, c, ch): return 'b'\n"
        "COMMANDS = {'cmd_b': f}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "cmd_a" in commands
    assert "cmd_b" in commands


def test_broken_plugin_doesnt_crash(tmp_path):
    (tmp_path / "broken.py").write_text("raise RuntimeError('boom')\n")
    (tmp_path / "good.py").write_text(
        "def f(p, c, ch): return 'ok'\n"
        "COMMANDS = {'good': f}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "good" in commands


# --- Channel plugin tests ---

def test_load_valid_channel_plugin(tmp_path):
    plugin = tmp_path / "s3.py"
    plugin.write_text(
        "from daemon.channels.base import OutputChannel\n"
        "\n"
        "class S3Channel(OutputChannel):\n"
        "    def __init__(self, config):\n"
        "        pass\n"
        "    def send(self, body, subject, *, original_message_id=''):\n"
        "        return 'uploaded'\n"
        "\n"
        "CHANNELS = {'s3': S3Channel}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "s3" in channels
    instance = channels["s3"](None)
    assert instance.send("body", "sub") == "uploaded"


def test_cannot_override_builtin_channel(tmp_path):
    plugin = tmp_path / "evil.py"
    plugin.write_text(
        "from daemon.channels.base import OutputChannel\n"
        "\n"
        "class FakeFile(OutputChannel):\n"
        "    def __init__(self, config): pass\n"
        "    def send(self, body, subject, *, original_message_id=''): "
        "return 'hijacked'\n"
        "\n"
        "CHANNELS = {'file': FakeFile}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "file" not in channels


def test_skip_non_outputchannel_subclass(tmp_path):
    plugin = tmp_path / "bad_channel.py"
    plugin.write_text(
        "class NotAChannel:\n"
        "    pass\n"
        "\n"
        "CHANNELS = {'bad': NotAChannel}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "bad" not in channels


def test_plugin_with_both_commands_and_channels(tmp_path):
    plugin = tmp_path / "combo.py"
    plugin.write_text(
        "from daemon.channels.base import OutputChannel\n"
        "\n"
        "def cmd_ping(params, config, channel):\n"
        "    return 'pong'\n"
        "\n"
        "class LogChannel(OutputChannel):\n"
        "    def __init__(self, config): pass\n"
        "    def send(self, body, subject, *, original_message_id=''):\n"
        "        return 'logged'\n"
        "\n"
        "COMMANDS = {'ping': cmd_ping}\n"
        "CHANNELS = {'log': LogChannel}\n"
    )
    commands, channels = load_plugins(tmp_path)
    assert "ping" in commands
    assert "log" in channels
