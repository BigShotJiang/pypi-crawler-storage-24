"""Tests for namespaced (multi-value) secrets."""

from __future__ import annotations

from pathlib import Path

import pytest

from daemon.channels.file import FileChannel
from daemon.commands import cmd_check_document, cmd_delete, cmd_describe, cmd_list, cmd_write
from daemon.crypto import decrypt, encrypt, secret_path

# --- Path resolution ---

def test_secret_path_flat(tmp_path):
    assert secret_path("ssn", tmp_path) == tmp_path / "ssn.age"


def test_secret_path_namespaced(tmp_path):
    assert secret_path("email:work", tmp_path) == tmp_path / "email" / "work.age"


# --- Write + List ---

@pytest.fixture
def channel(config):
    return FileChannel(config.storage.outbox_dir)


def test_write_namespaced(config, channel, vault_dir):
    result = cmd_write(
        {"name": "email:personal", "value": "a@b.com", "type": "exact", "description": "Personal"},
        config, channel,
    )
    assert "encrypted and stored" in result
    assert (vault_dir / "email" / "personal.age").exists()
    assert (vault_dir / "email" / ".type").exists()
    assert (vault_dir / "email" / ".type").read_text().strip() == "exact"


def test_write_multiple_labels(config, channel, vault_dir):
    cmd_write(
        {"name": "email:personal", "value": "a@b.com", "type": "exact", "description": "Personal"},
        config, channel,
    )
    cmd_write(
        {"name": "email:work", "value": "w@c.com", "type": "exact", "description": "Work"},
        config, channel,
    )

    result = cmd_list({}, config, channel)
    assert "email" in result
    assert "personal" in result
    assert "work" in result
    assert "2 values" in result


def test_write_type_conflict(config, channel):
    cmd_write(
        {"name": "email:personal", "value": "a@b.com", "type": "exact"},
        config, channel,
    )
    result = cmd_write(
        {"name": "email:work", "value": "w@c.com", "type": "numeric"},
        config, channel,
    )
    assert "Cannot mix types" in result


def test_write_flat_then_namespace_conflict(config, channel):
    cmd_write({"name": "email", "value": "a@b.com", "type": "exact"}, config, channel)
    result = cmd_write(
        {"name": "email:work", "value": "w@c.com", "type": "exact"},
        config, channel,
    )
    assert "already exists as a flat secret" in result


def test_write_namespace_then_flat_conflict(config, channel):
    cmd_write(
        {"name": "email:personal", "value": "a@b.com", "type": "exact"},
        config, channel,
    )
    result = cmd_write({"name": "email", "value": "x@y.com", "type": "exact"}, config, channel)
    assert "already exists as a namespace group" in result


# --- List ---

def test_list_mixed_flat_and_namespaced(config, channel):
    ssn = {"name": "ssn", "value": "123", "type": "numeric", "description": "SSN"}
    cmd_write(ssn, config, channel)
    em1 = {"name": "email:personal", "value": "a@b.com", "type": "exact", "description": "Gmail"}
    cmd_write(em1, config, channel)
    em2 = {"name": "email:work", "value": "w@c.com", "type": "exact", "description": "Corp"}
    cmd_write(em2, config, channel)

    result = cmd_list({}, config, channel)
    assert "ssn" in result
    assert "email" in result
    assert "personal" in result
    assert "work" in result


# --- Delete ---

def test_delete_single_label(config, channel, vault_dir):
    cmd_write({"name": "email:a", "value": "1", "type": "exact"}, config, channel)
    cmd_write({"name": "email:b", "value": "2", "type": "exact"}, config, channel)

    result = cmd_delete({"name": "email:a"}, config, channel)
    assert "deleted" in result

    # Group still exists with one remaining
    assert (vault_dir / "email").is_dir()
    assert not (vault_dir / "email" / "a.age").exists()
    assert (vault_dir / "email" / "b.age").exists()


def test_delete_last_label_removes_group(config, channel, vault_dir):
    cmd_write({"name": "email:only", "value": "x", "type": "exact"}, config, channel)
    cmd_delete({"name": "email:only"}, config, channel)

    assert not (vault_dir / "email").exists()


def test_delete_entire_group(config, channel, vault_dir):
    cmd_write({"name": "email:a", "value": "1", "type": "exact"}, config, channel)
    cmd_write({"name": "email:b", "value": "2", "type": "exact"}, config, channel)

    result = cmd_delete({"name": "email"}, config, channel)
    assert "2 values" in result
    assert not (vault_dir / "email").exists()


# --- Describe ---

def test_describe_label(config, channel, vault_dir):
    cmd_write({"name": "email:work", "value": "w@c.com", "type": "exact"}, config, channel)
    result = cmd_describe({"name": "email:work", "description": "Updated"}, config, channel)
    assert "updated" in result.lower()
    assert (vault_dir / "email" / "work.desc").read_text() == "Updated"


def test_describe_group(config, channel, vault_dir):
    cmd_write({"name": "email:work", "value": "w@c.com", "type": "exact"}, config, channel)
    result = cmd_describe({"name": "email", "description": "All emails"}, config, channel)
    assert "group" in result.lower()
    assert (vault_dir / "email" / ".desc").read_text() == "All emails"


# --- Check document with namespaces ---

def test_check_specific_label(config, channel):
    cmd_write({"name": "email:work", "value": "work@corp.com", "type": "exact"}, config, channel)

    inbox = Path(config.storage.inbox_dir)
    doc = inbox / "form.txt"
    doc.write_text("Contact: work@corp.com Phone: 555-1234")

    result = cmd_check_document(
        {"name": "email:work", "file_path": str(doc)}, config, channel,
    )
    assert "MATCHES VAULT SECRET" in result


def test_check_group(config, channel):
    cmd_write({"name": "email:personal", "value": "me@gmail.com", "type": "exact"}, config, channel)
    cmd_write({"name": "email:work", "value": "me@corp.com", "type": "exact"}, config, channel)
    cmd_write({"name": "email:old", "value": "me@yahoo.com", "type": "exact"}, config, channel)

    inbox = Path(config.storage.inbox_dir)
    doc = inbox / "form.txt"
    doc.write_text("Email: me@gmail.com Secondary: me@corp.com")

    result = cmd_check_document(
        {"name": "email", "file_path": str(doc)}, config, channel,
    )
    assert "email:personal" in result
    assert "FOUND" in result
    assert "email:work" in result
    assert "email:old" in result
    assert "NOT FOUND" in result
    assert "2 found" in result


# --- Send with namespaced placeholders ---

def test_send_namespaced_placeholder(config, channel):
    cmd_write({"name": "email:work", "value": "w@corp.com", "type": "exact"}, config, channel)

    from daemon.commands import cmd_send
    result = cmd_send(
        {
            "template": "Contact: {{VAULT:email:work}}",
            "subject": "Test",
        },
        config, channel,
    )
    assert "completed successfully" in result.lower() or "Send completed" in result

    # Verify the outbox file has the populated value
    outbox = Path(config.storage.outbox_dir)
    files = list(outbox.glob("*.txt"))
    assert len(files) == 1
    assert "w@corp.com" in files[0].read_text()


# --- Crypto round-trip with namespaces ---

def test_encrypt_decrypt_namespaced(vault_dir, key_file):
    encrypt("bank:checking", "123456", vault_dir, key_file)
    assert (vault_dir / "bank" / "checking.age").exists()

    plaintext = decrypt("bank:checking", vault_dir, key_file)
    assert plaintext == "123456"
