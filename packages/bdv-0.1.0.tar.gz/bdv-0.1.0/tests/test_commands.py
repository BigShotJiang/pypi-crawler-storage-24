"""Tests for command handlers."""

from __future__ import annotations

import pytest

from daemon.channels.file import FileChannel
from daemon.commands import cmd_delete, cmd_describe, cmd_list, cmd_write
from daemon.crypto import encrypt


@pytest.fixture
def channel(config):
    return FileChannel(config.storage.outbox_dir)


def test_write_and_list(config, channel, vault_dir):
    result = cmd_write(
        {"name": "ssn", "value": "123-45-6789", "description": "Test SSN", "type": "numeric"},
        config,
        channel,
    )
    assert "encrypted and stored" in result

    result = cmd_list({}, config, channel)
    assert "ssn" in result
    assert "Test SSN" in result


def test_write_missing_params(config, channel):
    result = cmd_write({"name": "", "value": ""}, config, channel)
    assert "ERROR" in result


def test_write_invalid_type(config, channel):
    result = cmd_write(
        {"name": "x", "value": "y", "type": "badtype"},
        config,
        channel,
    )
    assert "Invalid type" in result


def test_delete(config, channel, vault_dir, key_file):
    encrypt("todelete", "val", vault_dir, key_file)
    result = cmd_delete({"name": "todelete"}, config, channel)
    assert "deleted" in result
    assert not (vault_dir / "todelete.age").exists()


def test_delete_missing(config, channel):
    result = cmd_delete({"name": "nope"}, config, channel)
    assert "not found" in result


def test_describe(config, channel, vault_dir, key_file):
    encrypt("desc_test", "val", vault_dir, key_file)
    result = cmd_describe(
        {"name": "desc_test", "description": "Updated desc"},
        config,
        channel,
    )
    assert "updated" in result.lower()
    assert (vault_dir / "desc_test.desc").read_text() == "Updated desc"


def test_list_empty(config, channel):
    result = cmd_list({}, config, channel)
    assert "empty" in result.lower()
