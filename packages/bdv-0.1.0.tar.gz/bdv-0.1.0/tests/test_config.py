"""Tests for the configuration system."""

from __future__ import annotations

from daemon.config import BDVConfig, load_config


def test_defaults():
    config = BDVConfig()
    assert config.server.socket_path == "/run/bdv/bdv.sock"
    assert config.server.tcp_enabled is False
    assert config.server.tcp_port == 9652
    assert config.storage.vault_dir == "/data/secrets"
    assert config.output.type == "file"
    assert config.patterns.context_window == 40


def test_yaml_overlay(tmp_path):
    cfg_file = tmp_path / "bdv.yml"
    cfg_file.write_text(
        "server:\n"
        "  tcp_enabled: true\n"
        "  tcp_port: 1234\n"
        "storage:\n"
        "  vault_dir: /custom/vault\n"
        "output:\n"
        "  type: smtp\n"
        "  smtp:\n"
        "    host: mail.example.com\n"
        "    port: 465\n"
    )
    config = load_config(str(cfg_file))
    assert config.server.tcp_enabled is True
    assert config.server.tcp_port == 1234
    assert config.storage.vault_dir == "/custom/vault"
    assert config.output.type == "smtp"
    assert config.output.smtp.host == "mail.example.com"
    assert config.output.smtp.port == 465


def test_env_overlay(monkeypatch):
    monkeypatch.setenv("BDV_SERVER_TCP_ENABLED", "true")
    monkeypatch.setenv("BDV_SERVER_TCP_PORT", "5555")
    monkeypatch.setenv("BDV_STORAGE_VAULT_DIR", "/env/vault")
    monkeypatch.setenv("BDV_OUTPUT_TYPE", "webhook")

    config = load_config()
    assert config.server.tcp_enabled is True
    assert config.server.tcp_port == 5555
    assert config.storage.vault_dir == "/env/vault"
    assert config.output.type == "webhook"


def test_env_wins_over_yaml(tmp_path, monkeypatch):
    cfg_file = tmp_path / "bdv.yml"
    cfg_file.write_text("server:\n  tcp_port: 1111\n")

    monkeypatch.setenv("BDV_SERVER_TCP_PORT", "2222")

    config = load_config(str(cfg_file))
    assert config.server.tcp_port == 2222
