"""Tests for output channels."""

from __future__ import annotations

from daemon.channels.file import FileChannel


def test_file_channel_writes(tmp_path):
    ch = FileChannel(tmp_path / "outbox")
    result = ch.send("Hello {{populated}}", "Test Subject")
    assert "Output written" in result

    files = list((tmp_path / "outbox").glob("*.txt"))
    assert len(files) == 1

    content = files[0].read_text()
    assert "Subject: Test Subject" in content
    assert "Hello {{populated}}" in content


def test_file_channel_reply(tmp_path):
    ch = FileChannel(tmp_path / "outbox")
    ch.send("Body", "Sub", original_message_id="<msg123@example.com>")

    files = list((tmp_path / "outbox").glob("*.txt"))
    content = files[0].read_text()
    assert "In-Reply-To: <msg123@example.com>" in content
