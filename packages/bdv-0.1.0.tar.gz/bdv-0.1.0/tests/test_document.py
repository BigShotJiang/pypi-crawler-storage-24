"""Tests for document text extraction."""

from __future__ import annotations

import pytest

from daemon.document import extract_text


def test_extract_text_file(tmp_path):
    f = tmp_path / "test.txt"
    f.write_text("Hello World 123-45-6789")
    text = extract_text(str(f))
    assert "Hello World" in text
    assert "123-45-6789" in text


def test_extract_csv(tmp_path):
    f = tmp_path / "test.csv"
    f.write_text("name,ssn\nJohn,123-45-6789\n")
    text = extract_text(str(f))
    assert "123-45-6789" in text


def test_extract_missing_file():
    with pytest.raises(FileNotFoundError):
        extract_text("/nonexistent/file.txt")


def test_extract_unsupported_type(tmp_path):
    f = tmp_path / "test.xyz"
    f.write_bytes(b"\x00\x01\x02")
    with pytest.raises(ValueError, match="Unsupported"):
        extract_text(str(f))
