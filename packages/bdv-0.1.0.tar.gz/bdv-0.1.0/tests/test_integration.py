"""Integration tests — full daemon round-trip via socket.

These tests start the actual daemon server (Unix socket) and exercise
the full command flow through the client.
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from client.client import BDVClient
from daemon.channels.file import FileChannel
from daemon.server import start_unix_server


@pytest.fixture
def running_server(config):
    """Start a real daemon server on a temp Unix socket."""
    channel = FileChannel(config.storage.outbox_dir)
    server = start_unix_server(config, channel)
    time.sleep(0.1)  # let server thread spin up
    yield config
    server.close()


@pytest.fixture
def client(running_server):
    return BDVClient(socket_path=running_server.server.socket_path)


def test_full_lifecycle(running_server):
    """Write, list, describe, delete — full round-trip."""
    client = BDVClient(socket_path=running_server.server.socket_path)

    # Empty vault
    result = client.list()
    assert "empty" in result.lower()

    # Write
    result = client.write("test_ssn", "123-45-6789", "Test SSN", "numeric")
    assert "encrypted and stored" in result

    # List
    result = client.list()
    assert "test_ssn" in result
    assert "Test SSN" in result

    # Describe
    result = client.describe("test_ssn", "Updated SSN")
    assert "updated" in result.lower()

    # Delete
    result = client.delete("test_ssn")
    assert "deleted" in result

    # Confirm deleted
    result = client.list()
    assert "empty" in result.lower()


def test_check_document_text_file(running_server, config):
    """Write a secret, create a text file in inbox, run check_document."""
    client = BDVClient(socket_path=running_server.server.socket_path)

    client.write("routing", "021000021", "Chase routing", "numeric")

    # Create test document in inbox
    inbox = Path(config.storage.inbox_dir)
    doc = inbox / "test.txt"
    doc.write_text("Routing Number: 021000021 Account: 123456789")

    result = client.check_document("routing", str(doc))
    assert "MATCHES VAULT SECRET" in result


def test_check_document_path_traversal(running_server, config):
    """Attempting to check a file outside inbox should be rejected."""
    client = BDVClient(socket_path=running_server.server.socket_path)

    client.write("ssn", "123-45-6789", "test", "numeric")

    result = client.check_document("ssn", "/etc/passwd")
    assert "ERROR" in result


def test_send_file_channel(running_server, config):
    """Send should write populated content to outbox."""
    client = BDVClient(socket_path=running_server.server.socket_path)

    client.write("pin", "1234", "PIN", "exact")

    result = client.send(
        template="Your PIN is {{VAULT:pin}}.",
        subject="PIN Delivery",
    )
    assert "completed successfully" in result.lower() or "Send completed" in result

    # Verify file was written
    outbox = Path(config.storage.outbox_dir)
    files = list(outbox.glob("*.txt"))
    assert len(files) == 1

    content = files[0].read_text()
    assert "1234" in content  # populated in the file
    assert "PIN Delivery" in content


def test_concurrent_connections(running_server):
    """Multiple simultaneous connections should all succeed."""
    import concurrent.futures

    def do_list():
        c = BDVClient(socket_path=running_server.server.socket_path)
        return c.list()

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        futures = [pool.submit(do_list) for _ in range(10)]
        results = [f.result() for f in futures]

    assert all("empty" in r.lower() or "secret" in r.lower() for r in results)
