"""Tests for SMTP and webhook channels."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from daemon.channels.smtp import SmtpChannel
from daemon.channels.webhook import WebhookChannel
from daemon.config import SmtpConfig, WebhookConfig

# ---------------------------------------------------------------------------
# SmtpChannel tests
# ---------------------------------------------------------------------------

class TestSmtpChannelValidation:
    """Test SmtpChannel validation logic without connecting to SMTP."""

    def test_missing_from_addr_raises(self):
        """Missing from_addr raises ValueError before any SMTP connection."""
        config = SmtpConfig(from_addr="", to_addr="recipient@example.com")
        ch = SmtpChannel(config)
        with pytest.raises(ValueError, match="from_addr and to_addr must be configured"):
            ch.send("body", "subject")

    def test_missing_to_addr_raises(self):
        """Missing to_addr raises ValueError before any SMTP connection."""
        config = SmtpConfig(from_addr="sender@example.com", to_addr="")
        ch = SmtpChannel(config)
        with pytest.raises(ValueError, match="from_addr and to_addr must be configured"):
            ch.send("body", "subject")

    def test_header_injection_prevention(self):
        """Subject containing \\r\\n is sanitized to prevent header injection.

        We verify sanitization by patching smtplib.SMTP so no real connection
        is made, then inspecting the constructed message.
        """
        config = SmtpConfig(
            from_addr="sender@example.com",
            to_addr="recipient@example.com",
            host="localhost",
            port=587,
        )
        ch = SmtpChannel(config)

        mock_smtp_instance = MagicMock()
        mock_smtp_instance.__enter__ = MagicMock(return_value=mock_smtp_instance)
        mock_smtp_instance.__exit__ = MagicMock(return_value=False)

        with patch("daemon.channels.smtp.smtplib.SMTP", return_value=mock_smtp_instance):
            ch.send("body", "Injected\r\nBcc: evil@attacker.com")

        # Inspect the message that was passed to sendmail
        call_args = mock_smtp_instance.sendmail.call_args
        raw_message = call_args[0][2]  # third positional arg is the message string
        # The \r\n should have been stripped from the subject
        assert "\r\nBcc:" not in raw_message
        assert "Injected" in raw_message


# ---------------------------------------------------------------------------
# WebhookChannel tests
# ---------------------------------------------------------------------------

class TestWebhookChannelValidation:
    """Test WebhookChannel URL validation."""

    def test_missing_url_raises(self):
        """Missing URL raises ValueError."""
        config = WebhookConfig(url="")
        ch = WebhookChannel(config)
        with pytest.raises(ValueError, match="Webhook URL must be configured"):
            ch.send("body", "subject")

    def test_http_non_localhost_raises(self):
        """http:// URL that is not localhost raises ValueError."""
        config = WebhookConfig(url="http://example.com/hook")
        ch = WebhookChannel(config)
        with pytest.raises(ValueError, match="must use HTTPS or http://localhost"):
            ch.send("body", "subject")

    def test_https_url_accepted(self):
        """https:// URL is accepted (mock urlopen to avoid real network call)."""
        config = WebhookConfig(url="https://hooks.example.com/notify")
        ch = WebhookChannel(config)

        mock_response = MagicMock()
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_response.status = 200

        with patch("daemon.channels.webhook.urlopen", return_value=mock_response):
            result = ch.send("body", "subject")
        assert "Delivered via webhook" in result
        assert "200" in result

    def test_http_localhost_accepted(self):
        """http://localhost URL is accepted."""
        config = WebhookConfig(url="http://localhost:8080/hook")
        ch = WebhookChannel(config)

        mock_response = MagicMock()
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_response.status = 200

        with patch("daemon.channels.webhook.urlopen", return_value=mock_response) as mock_urlopen:
            result = ch.send("secret body", "Test Subject")

        assert "Delivered via webhook" in result
        # Verify the request was made with proper JSON payload
        req_arg = mock_urlopen.call_args[0][0]
        payload = json.loads(req_arg.data.decode("utf-8"))
        assert payload["subject"] == "Test Subject"
        assert payload["body"] == "secret body"

    def test_http_remote_host_raises(self):
        """http:// URL with a remote host (not localhost) is rejected."""
        config = WebhookConfig(url="http://192.168.1.1:8080/hook")
        ch = WebhookChannel(config)
        with pytest.raises(ValueError, match="must use HTTPS or http://localhost"):
            ch.send("body", "subject")

    def test_http_localhost_evil_raises(self):
        """http://localhost.evil.com should be rejected (not actual localhost)."""
        config = WebhookConfig(url="http://localhost.evil.com/steal")
        ch = WebhookChannel(config)
        with pytest.raises(ValueError, match="must use HTTPS or http://localhost"):
            ch.send("body", "subject")
