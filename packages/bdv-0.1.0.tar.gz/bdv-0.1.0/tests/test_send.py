"""Tests for cmd_send in daemon/commands.py."""

from __future__ import annotations

import pytest

from daemon.channels.file import FileChannel
from daemon.commands import _recent_sends, _recent_sends_lock, cmd_send
from daemon.crypto import encrypt


@pytest.fixture
def channel(config):
    return FileChannel(config.storage.outbox_dir)


@pytest.fixture(autouse=True)
def clear_dedup_cache():
    """Clear the deduplication cache before each test."""
    with _recent_sends_lock:
        _recent_sends.clear()
    yield
    with _recent_sends_lock:
        _recent_sends.clear()


def test_missing_template_returns_error(config, channel):
    """Missing template returns ERROR."""
    result = cmd_send({"subject": "Test"}, config, channel)
    assert "ERROR" in result
    assert "'template' and 'subject' are required" in result


def test_missing_subject_returns_error(config, channel):
    """Missing subject returns ERROR."""
    result = cmd_send({"template": "Hello {{VAULT:ssn}}"}, config, channel)
    assert "ERROR" in result
    assert "'template' and 'subject' are required" in result


def test_no_placeholders_returns_error(config, channel):
    """Template without {{VAULT:...}} placeholders returns ERROR."""
    result = cmd_send(
        {"template": "Hello world, no secrets here", "subject": "Test"},
        config,
        channel,
    )
    assert "ERROR" in result
    assert "No {{VAULT:secret_name}} placeholders found" in result


def test_missing_secret_in_placeholder(config, channel):
    """Placeholder referencing a nonexistent secret returns ERROR."""
    result = cmd_send(
        {"template": "SSN: {{VAULT:nonexistent_secret}}", "subject": "Report"},
        config,
        channel,
    )
    assert "ERROR" in result
    assert "not found in vault" in result


def test_dedup_blocks_identical_sends(config, channel, vault_dir, key_file):
    """Sending the same template+subject twice within the dedup window is blocked."""
    encrypt("ssn", "123-45-6789", vault_dir, key_file)

    params = {
        "template": "Your SSN is {{VAULT:ssn}}",
        "subject": "SSN Report",
    }
    result1 = cmd_send(params, config, channel)
    assert "Send completed successfully" in result1

    result2 = cmd_send(params, config, channel)
    assert "Duplicate blocked" in result2


def test_multiple_placeholders(config, channel, vault_dir, key_file):
    """Template with multiple different placeholders replaces all of them."""
    encrypt("ssn", "123-45-6789", vault_dir, key_file)
    encrypt("dob", "1990-01-15", vault_dir, key_file)

    result = cmd_send(
        {
            "template": "SSN: {{VAULT:ssn}}, DOB: {{VAULT:dob}}",
            "subject": "Multi-field Report",
        },
        config,
        channel,
    )
    assert "Send completed successfully" in result
    assert "2" in result  # 2 secrets injected
    assert "ssn" in result
    assert "dob" in result


def test_namespaced_placeholder(config, channel, vault_dir, key_file):
    """Namespaced placeholders like {{VAULT:email:work}} are resolved."""
    encrypt("email:work", "user@company.com", vault_dir, key_file)

    result = cmd_send(
        {
            "template": "Contact: {{VAULT:email:work}}",
            "subject": "Contact Info",
        },
        config,
        channel,
    )
    assert "Send completed successfully" in result
    assert "email:work" in result
