"""Tests for pattern derivation and context windows."""

from __future__ import annotations

import re

from daemon.patterns import build_context_window, derive_patterns, normalize_secret


def test_ssn_pattern():
    pattern = derive_patterns("ssn", "123-45-6789")
    assert re.search(pattern, "123-45-6789")
    assert re.search(pattern, "123 45 6789")
    assert re.search(pattern, "123456789")
    assert re.search(pattern, "123.45.6789")
    assert not re.search(pattern, "12-345-6789")


def test_uk_ni_pattern():
    pattern = derive_patterns("ni", "AB 12 34 56 C")
    assert re.search(pattern, "AB 12 34 56 C")
    assert re.search(pattern, "AB123456C")
    assert re.search(pattern, "AB-12-34-56-C")


def test_credit_card_pattern():
    pattern = derive_patterns("cc", "4532-0151-2345-6789")
    assert re.search(pattern, "4532-0151-2345-6789")
    assert re.search(pattern, "4532 0151 2345 6789")
    assert re.search(pattern, "4532015123456789")


def test_context_window_redacts_numbers():
    doc = "SSN: 123-45-6789 Account: 987654321 end"
    ctx = build_context_window(doc, 5, 16, 0, 40)
    assert "[REDACTED_MATCH_1]" in ctx
    assert "123-45-6789" not in ctx
    assert "987654321" not in ctx
    assert "[REDACTED]" in ctx


def test_context_window_boundaries():
    doc = "X" * 10
    ctx = build_context_window(doc, 3, 7, 0, 40)
    assert "[REDACTED_MATCH_1]" in ctx
    # No ellipsis since context window covers the whole doc
    assert not ctx.startswith("...")


def test_normalize_secret():
    assert normalize_secret("123-45-6789") == "123456789"
    assert normalize_secret("AB 12 34 56 C") == "AB123456C"
    assert normalize_secret("nope") == "nope"
