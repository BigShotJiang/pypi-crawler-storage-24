"""Tests for the BDV client."""

from __future__ import annotations

import json
import socket
import tempfile
import threading
from pathlib import Path

import pytest

from client.client import BDVClient, BDVError


@pytest.fixture
def mock_server():
    """Start a mock Unix socket server that echoes commands."""
    tmp_dir = Path(tempfile.mkdtemp(prefix="bdv"))
    sock_path = str(tmp_dir / "t.sock")

    def handler(server_sock):
        while True:
            try:
                conn, _ = server_sock.accept()
                data = b""
                while b"\n" not in data:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                req = json.loads(data.decode().strip())
                resp = {"ok": True, "result": f"handled:{req.get('cmd')}"}
                conn.sendall((json.dumps(resp) + "\n").encode())
                conn.close()
            except OSError:
                break

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(sock_path)
    server.listen(5)

    t = threading.Thread(target=handler, args=(server,), daemon=True)
    t.start()

    yield sock_path

    server.close()
    import shutil
    shutil.rmtree(tmp_dir, ignore_errors=True)


def test_client_list(mock_server):
    client = BDVClient(socket_path=mock_server)
    result = client.list()
    assert result == "handled:list"


def test_client_write(mock_server):
    client = BDVClient(socket_path=mock_server)
    result = client.write("ssn", "123", "desc", "numeric")
    assert result == "handled:write"


def test_client_delete(mock_server):
    client = BDVClient(socket_path=mock_server)
    result = client.delete("ssn")
    assert result == "handled:delete"


@pytest.fixture
def error_server():
    """Server that always returns errors."""
    tmp_dir = Path(tempfile.mkdtemp(prefix="bdv"))
    sock_path = str(tmp_dir / "e.sock")

    def handler(server_sock):
        while True:
            try:
                conn, _ = server_sock.accept()
                data = b""
                while b"\n" not in data:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                resp = {"ok": False, "error": "test error"}
                conn.sendall((json.dumps(resp) + "\n").encode())
                conn.close()
            except OSError:
                break

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(sock_path)
    server.listen(5)

    t = threading.Thread(target=handler, args=(server,), daemon=True)
    t.start()

    yield sock_path

    server.close()
    import shutil
    shutil.rmtree(tmp_dir, ignore_errors=True)


def test_client_error(error_server):
    client = BDVClient(socket_path=error_server)
    with pytest.raises(BDVError, match="test error"):
        client.list()
