"""Tests for crypto operations (requires age binary)."""

from __future__ import annotations

from daemon.crypto import decrypt, encrypt, generate_key, get_recipient


def test_encrypt_decrypt(vault_dir, key_file):
    encrypt("test_secret", "hunter2", vault_dir, key_file)
    assert (vault_dir / "test_secret.age").exists()

    plaintext = decrypt("test_secret", vault_dir, key_file)
    assert plaintext == "hunter2"


def test_get_recipient(key_file):
    pub = get_recipient(key_file)
    assert pub.startswith("age1")


def test_decrypt_missing(vault_dir, key_file):
    import pytest

    with pytest.raises(FileNotFoundError, match="not found"):
        decrypt("nonexistent", vault_dir, key_file)


def test_generate_key_idempotent(tmp_path):
    kf = tmp_path / "new-key"
    generate_key(kf)
    assert kf.exists()
    content1 = kf.read_text()

    # Second call should not overwrite
    generate_key(kf)
    assert kf.read_text() == content1
