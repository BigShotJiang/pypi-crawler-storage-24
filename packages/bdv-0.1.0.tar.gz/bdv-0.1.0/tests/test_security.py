"""Security tests for critical and high-severity findings."""

from __future__ import annotations

import pytest

from daemon.crypto import secret_path, validate_name

# --- Secret name validation (path traversal prevention) ---

def test_reject_path_traversal_flat():
    with pytest.raises(ValueError):
        validate_name("../../etc/passwd")


def test_reject_path_traversal_namespaced_group():
    with pytest.raises(ValueError):
        validate_name("../evil:label")


def test_reject_path_traversal_namespaced_label():
    with pytest.raises(ValueError):
        validate_name("group:../../etc/shadow")


def test_reject_slash_in_name():
    with pytest.raises(ValueError):
        validate_name("path/to/secret")


def test_reject_backslash_in_name():
    with pytest.raises(ValueError):
        validate_name("path\\to\\secret")


def test_reject_empty_name():
    with pytest.raises(ValueError):
        validate_name("")


def test_reject_empty_group():
    with pytest.raises(ValueError):
        validate_name(":label")


def test_reject_empty_label():
    with pytest.raises(ValueError):
        validate_name("group:")


def test_reject_null_bytes():
    with pytest.raises(ValueError):
        validate_name("secret\x00evil")


def test_reject_spaces():
    with pytest.raises(ValueError):
        validate_name("my secret")


def test_accept_valid_flat_names():
    for name in ["ssn", "my-secret", "my_secret", "my.secret", "SSN123"]:
        validate_name(name)  # should not raise


def test_accept_valid_namespaced_names():
    for name in ["email:work", "bank:checking-1", "api.keys:prod"]:
        validate_name(name)  # should not raise


def test_secret_path_rejects_traversal(tmp_path):
    with pytest.raises(ValueError):
        secret_path("../../etc/passwd", tmp_path)


# --- Write-side path traversal via commands ---

def test_write_rejects_traversal_name(config, channel):
    from daemon.commands import cmd_write

    result = cmd_write(
        {"name": "../../etc/evil", "value": "x", "type": "numeric"},
        config, channel,
    )
    assert "ERROR" in result


def test_delete_rejects_traversal_name(config, channel):
    from daemon.commands import cmd_delete

    result = cmd_delete({"name": "../important"}, config, channel)
    assert "ERROR" in result or "not found" in result.lower()


# --- Fixture for channel ---

@pytest.fixture
def channel(config):
    from daemon.channels.file import FileChannel
    return FileChannel(config.storage.outbox_dir)


# --- Secret values never returned in responses ---

def test_list_never_returns_values(config, channel):
    from daemon.commands import cmd_list, cmd_write

    cmd_write(
        {"name": "ssn", "value": "123-45-6789", "type": "numeric"},
        config, channel,
    )
    result = cmd_list({}, config, channel)
    assert "123-45-6789" not in result
    assert "ssn" in result


def test_check_document_never_returns_secret(config, channel):
    from pathlib import Path

    from daemon.commands import cmd_check_document, cmd_write

    cmd_write(
        {"name": "routing", "value": "021000021", "type": "numeric"},
        config, channel,
    )

    inbox = Path(config.storage.inbox_dir)
    doc = inbox / "test.txt"
    doc.write_text("Routing: 021000021 end")

    result = cmd_check_document(
        {"name": "routing", "file_path": str(doc)}, config, channel,
    )
    assert "021000021" not in result
    assert "REDACTED" in result


def test_send_never_returns_populated_content(config, channel):
    from daemon.commands import cmd_send, cmd_write

    cmd_write(
        {"name": "pin", "value": "9876", "type": "exact"},
        config, channel,
    )

    result = cmd_send(
        {"template": "PIN: {{VAULT:pin}}", "subject": "Test"},
        config, channel,
    )
    assert "9876" not in result
    assert "NOT returned" in result
