"""Unit tests for daemon/server.py."""

from __future__ import annotations

import json
import socket
import time

import pytest

from daemon.channels.file import FileChannel
from daemon.config import BDVConfig, ServerConfig, StorageConfig
from daemon.server import start_tcp_server, start_unix_server


@pytest.fixture
def channel(config):
    return FileChannel(config.storage.outbox_dir)


def _send_and_recv(sock_path: str, data: bytes) -> dict:
    """Connect to a Unix socket, send data, and return the parsed JSON response."""
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.settimeout(5)
    client.connect(sock_path)
    if data:
        client.sendall(data)
    # Signal that we are done writing. The server may have already closed
    # the connection after processing a newline-terminated message, so
    # ignore errors on shutdown.
    try:
        client.shutdown(socket.SHUT_WR)
    except OSError:
        pass
    response = b""
    while True:
        try:
            chunk = client.recv(4096)
        except OSError:
            break
        if not chunk:
            break
        response += chunk
    client.close()
    if not response:
        return {}
    return json.loads(response.decode().strip())


def test_invalid_json(config, channel):
    """Sending invalid JSON returns the expected error response."""
    server = start_unix_server(config, channel)
    try:
        sock_path = config.server.socket_path
        result = _send_and_recv(sock_path, b"this is not json\n")
        assert result == {"ok": False, "error": "Invalid JSON"}
    finally:
        server.close()


def test_unknown_command(config, channel):
    """Sending an unknown command returns the expected error response."""
    server = start_unix_server(config, channel)
    try:
        sock_path = config.server.socket_path
        payload = json.dumps({"cmd": "nonexistent_cmd"}).encode() + b"\n"
        result = _send_and_recv(sock_path, payload)
        assert result["ok"] is False
        assert "Unknown command: nonexistent_cmd" in result["error"]
    finally:
        server.close()


def test_empty_connection(config, channel):
    """Connecting then immediately disconnecting does not crash the server."""
    server = start_unix_server(config, channel)
    try:
        sock_path = config.server.socket_path
        # Connect and immediately close
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.settimeout(5)
        client.connect(sock_path)
        client.close()

        # Server should still accept connections after an empty one
        time.sleep(0.1)
        result = _send_and_recv(sock_path, b"not json\n")
        assert result == {"ok": False, "error": "Invalid JSON"}
    finally:
        server.close()


def test_tcp_auth_correct_token(tmp_vault):
    """TCP server accepts requests with the correct auth token."""
    short_tmp = tmp_vault
    outbox_dir = short_tmp / "o"
    channel = FileChannel(str(outbox_dir))
    config = BDVConfig(
        server=ServerConfig(
            socket_path=str(short_tmp / "r" / "bdv.sock"),
            tcp_enabled=True,
            tcp_host="127.0.0.1",
            tcp_port=0,  # will be assigned by OS
            tcp_token="correct-secret-token",
        ),
        storage=StorageConfig(
            vault_dir=str(short_tmp / "s"),
            inbox_dir=str(short_tmp / "i"),
            outbox_dir=str(outbox_dir),
        ),
    )

    # Manually bind to port 0 to get a random available port
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.bind(("127.0.0.1", 0))
    _, port = server_sock.getsockname()
    server_sock.close()

    config.server.tcp_port = port
    server = start_tcp_server(config, channel)
    try:
        # Correct token should succeed
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(5)
        client.connect(("127.0.0.1", port))
        payload = json.dumps({
            "token": "correct-secret-token",
            "cmd": "list",
        }).encode() + b"\n"
        client.sendall(payload)
        try:
            client.shutdown(socket.SHUT_WR)
        except OSError:
            pass
        response = b""
        while True:
            try:
                chunk = client.recv(4096)
            except OSError:
                break
            if not chunk:
                break
            response += chunk
        client.close()
        result = json.loads(response.decode().strip())
        assert result["ok"] is True
    finally:
        server.close()


def test_tcp_auth_wrong_token(tmp_vault):
    """TCP server rejects requests with the wrong auth token."""
    short_tmp = tmp_vault
    outbox_dir = short_tmp / "o"
    channel = FileChannel(str(outbox_dir))
    config = BDVConfig(
        server=ServerConfig(
            socket_path=str(short_tmp / "r" / "bdv.sock"),
            tcp_enabled=True,
            tcp_host="127.0.0.1",
            tcp_port=0,
            tcp_token="correct-secret-token",
        ),
        storage=StorageConfig(
            vault_dir=str(short_tmp / "s"),
            inbox_dir=str(short_tmp / "i"),
            outbox_dir=str(outbox_dir),
        ),
    )

    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.bind(("127.0.0.1", 0))
    _, port = server_sock.getsockname()
    server_sock.close()

    config.server.tcp_port = port
    server = start_tcp_server(config, channel)
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(5)
        client.connect(("127.0.0.1", port))
        payload = json.dumps({
            "token": "wrong-token",
            "cmd": "list",
        }).encode() + b"\n"
        client.sendall(payload)
        try:
            client.shutdown(socket.SHUT_WR)
        except OSError:
            pass
        response = b""
        while True:
            try:
                chunk = client.recv(4096)
            except OSError:
                break
            if not chunk:
                break
            response += chunk
        client.close()
        result = json.loads(response.decode().strip())
        assert result["ok"] is False
        assert "Authentication failed" in result["error"]
    finally:
        server.close()
