"""
BDV CLI — command-line interface for the Blind Data Vault.

Usage:
    bdv list
    bdv write <name> --value <value> [--type TYPE] [--desc DESCRIPTION]
    bdv check <name> <file_path>
    bdv send --template "..." --subject "..."
    bdv delete <name>
    bdv desc <name> <description>

The write command prompts for the secret value securely if --value is omitted,
so that secrets never appear in shell history or process listings.
"""

from __future__ import annotations

import os
import sys

import click

from client.client import BDVClient, BDVError


def _make_client(ctx: click.Context) -> BDVClient:
    """Build a BDVClient from CLI options or env vars."""
    tcp = ctx.obj.get("tcp")
    token = ctx.obj.get("token") or os.environ.get("BDV_TOKEN", "")
    socket_path = ctx.obj.get("socket") or os.environ.get("BDV_SOCKET", "")

    if tcp:
        parts = tcp.split(":")
        host = parts[0]
        port = int(parts[1]) if len(parts) > 1 else 9652
        return BDVClient(host=host, port=port, token=token)
    elif socket_path:
        return BDVClient(socket_path=socket_path)
    else:
        return BDVClient()


@click.group()
@click.option("--socket", "-s", help="Unix socket path (or BDV_SOCKET env)")
@click.option("--tcp", "-t", help="TCP host:port (e.g., localhost:9652)")
@click.option("--token", help="Auth token for TCP (or BDV_TOKEN env)")
@click.pass_context
def cli(ctx, socket, tcp, token):
    """BDV — Blind Data Vault CLI"""
    ctx.ensure_object(dict)
    ctx.obj["socket"] = socket
    ctx.obj["tcp"] = tcp
    ctx.obj["token"] = token


@cli.command("list")
@click.pass_context
def list_secrets(ctx):
    """List stored secrets (names + descriptions, never values)."""
    client = _make_client(ctx)
    try:
        click.echo(client.list())
    except BDVError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("name")
@click.option(
    "--value", "-v", prompt=True, hide_input=True,
    help="Secret value (prompted securely if omitted)",
)
@click.option("--type", "-t", "secret_type", default="numeric", help="numeric, exact, text")
@click.option("--desc", "-d", "description", default="", help="Secret description")
@click.pass_context
def write(ctx, name, value, secret_type, description):
    """Store an encrypted secret."""
    client = _make_client(ctx)
    try:
        click.echo(client.write(name, value, description, secret_type))
    except BDVError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("name")
@click.argument("file_path")
@click.pass_context
def check(ctx, name, file_path):
    """Check if a secret exists in a document."""
    client = _make_client(ctx)
    try:
        click.echo(client.check_document(name, file_path))
    except BDVError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option("--template", required=True, help="Template with {{VAULT:name}} placeholders")
@click.option("--subject", required=True, help="Subject line")
@click.option("--reply-to", default="", help="Original message ID for threading")
@click.pass_context
def send(ctx, template, subject, reply_to):
    """Send content with secrets injected atomically."""
    client = _make_client(ctx)
    try:
        click.echo(client.send(template, subject, reply_to))
    except BDVError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("name")
@click.pass_context
def delete(ctx, name):
    """Delete a secret from the vault."""
    client = _make_client(ctx)
    try:
        click.echo(client.delete(name))
    except BDVError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("name")
@click.argument("description")
@click.pass_context
def desc(ctx, name, description):
    """Update a secret's description."""
    client = _make_client(ctx)
    try:
        click.echo(client.describe(name, description))
    except BDVError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def main():
    cli()


if __name__ == "__main__":
    main()
