"""
Thin Python client for BDV. Supports Unix socket and TCP connections.
"""

from __future__ import annotations

import json
import socket

CLIENT_TIMEOUT = 30  # seconds


class BDVError(Exception):
    """Raised when the BDV daemon returns an error."""


class BDVClient:
    """Client for the BDV (Blind Data Vault) daemon.

    Usage:
        # Unix socket (default)
        client = BDVClient()

        # TCP with auth
        client = BDVClient(host="localhost", port=9652, token="mytoken")
    """

    def __init__(
        self,
        socket_path: str | None = None,
        host: str | None = None,
        port: int = 9652,
        token: str = "",
    ) -> None:
        self.socket_path = socket_path
        self.host = host
        self.port = port
        self.token = token

        if not socket_path and not host:
            self.socket_path = "/run/bdv/bdv.sock"

    def _call(self, cmd: dict) -> str:
        """Send a command and return the result string."""
        if self.token:
            cmd["token"] = self.token

        if self.host:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        else:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

        s.settimeout(CLIENT_TIMEOUT)

        try:
            if self.host:
                s.connect((self.host, self.port))
            else:
                s.connect(self.socket_path)

            s.sendall(json.dumps(cmd).encode() + b"\n")

            data = b""
            while True:
                chunk = s.recv(8192)
                if not chunk:
                    break
                data += chunk
                if b"\n" in data:
                    break

            resp = json.loads(data.decode().strip())
            if resp.get("ok"):
                return resp["result"]
            else:
                raise BDVError(resp.get("error", "Unknown error"))
        finally:
            s.close()

    def list(self) -> str:
        """List stored secret names with descriptions (never values)."""
        return self._call({"cmd": "list"})

    def write(
        self,
        name: str,
        value: str,
        description: str = "",
        secret_type: str = "numeric",
    ) -> str:
        """Encrypt and store a secret."""
        return self._call({
            "cmd": "write",
            "name": name,
            "value": value,
            "description": description,
            "type": secret_type,
        })

    def check_document(self, name: str, file_path: str) -> str:
        """Check if a stored secret exists within a document."""
        return self._call({
            "cmd": "check_document",
            "name": name,
            "file_path": file_path,
        })

    def send(
        self,
        template: str,
        subject: str,
        original_message_id: str = "",
    ) -> str:
        """Send populated content via the configured output channel."""
        cmd = {
            "cmd": "send",
            "template": template,
            "subject": subject,
        }
        if original_message_id:
            cmd["original_message_id"] = original_message_id
        return self._call(cmd)

    def delete(self, name: str) -> str:
        """Delete a secret from the vault."""
        return self._call({"cmd": "delete", "name": name})

    def describe(self, name: str, description: str) -> str:
        """Update a secret's description."""
        return self._call({
            "cmd": "describe",
            "name": name,
            "description": description,
        })
