"""SMTP email output channel."""

from __future__ import annotations

import logging
import smtplib
from email.mime.text import MIMEText

from daemon.channels.base import OutputChannel
from daemon.config import SmtpConfig

logger = logging.getLogger("bdv.channels.smtp")


class SmtpChannel(OutputChannel):
    def __init__(self, config: SmtpConfig) -> None:
        self.config = config

    def send(
        self,
        body: str,
        subject: str,
        *,
        original_message_id: str = "",
    ) -> str:
        if not self.config.from_addr or not self.config.to_addr:
            raise ValueError("SMTP from_addr and to_addr must be configured.")

        # Sanitize headers to prevent injection via \r\n
        subject = subject.replace("\r", "").replace("\n", " ")
        original_message_id = original_message_id.replace("\r", "").replace("\n", "")

        if not subject.lower().startswith("re:") and original_message_id:
            subject = f"Re: {subject}"

        msg = MIMEText(body, "plain", "utf-8")
        msg["From"] = self.config.from_addr
        msg["To"] = self.config.to_addr
        msg["Subject"] = subject
        msg["X-Vault-Sensitive"] = "true"
        if original_message_id:
            msg["In-Reply-To"] = original_message_id
            msg["References"] = original_message_id

        with smtplib.SMTP(self.config.host, self.config.port, timeout=10) as smtp:
            if self.config.starttls:
                smtp.starttls()
            if self.config.username:
                smtp.login(self.config.username, self.config.password)
            smtp.sendmail(self.config.from_addr, [self.config.to_addr], msg.as_string())

        logger.info("Email sent: subject=%s, to=%s", subject, self.config.to_addr)
        return f"Delivered to {self.config.to_addr} via SMTP"
