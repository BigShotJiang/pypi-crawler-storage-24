"""Abstract output channel interface."""

from __future__ import annotations

from abc import ABC, abstractmethod


class OutputChannel(ABC):
    """Base class for output channels (file, smtp, webhook)."""

    @abstractmethod
    def send(
        self,
        body: str,
        subject: str,
        *,
        original_message_id: str = "",
    ) -> str:
        """Send populated content via this channel.

        Returns a confirmation message (never the populated content).
        """
        ...
