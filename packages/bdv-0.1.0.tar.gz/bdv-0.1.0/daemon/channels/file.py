"""File drop output channel — writes populated content to outbox directory."""

from __future__ import annotations

import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

from daemon.channels.base import OutputChannel

logger = logging.getLogger("bdv.channels.file")


class FileChannel(OutputChannel):
    def __init__(self, outbox_dir: str | Path) -> None:
        self.outbox_dir = Path(outbox_dir)
        self.outbox_dir.mkdir(parents=True, exist_ok=True)

    def send(
        self,
        body: str,
        subject: str,
        *,
        original_message_id: str = "",
    ) -> str:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        uid = uuid.uuid4().hex[:8]
        filename = f"{timestamp}-{uid}.txt"
        out_path = self.outbox_dir / filename

        content = f"Subject: {subject}\n"
        if original_message_id:
            content += f"In-Reply-To: {original_message_id}\n"
        content += f"Date: {datetime.now(timezone.utc).isoformat()}\n"
        content += f"\n{body}"

        out_path.write_text(content, encoding="utf-8")
        os.chmod(str(out_path), 0o600)
        logger.info("File written: %s", out_path)

        return f"Output written to {filename}"
