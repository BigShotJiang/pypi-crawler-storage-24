"""HTTP POST webhook output channel."""

from __future__ import annotations

import json
import logging
from urllib.request import Request, urlopen

from daemon.channels.base import OutputChannel
from daemon.config import WebhookConfig

logger = logging.getLogger("bdv.channels.webhook")


class WebhookChannel(OutputChannel):
    def __init__(self, config: WebhookConfig) -> None:
        self.config = config

    def send(
        self,
        body: str,
        subject: str,
        *,
        original_message_id: str = "",
    ) -> str:
        if not self.config.url:
            raise ValueError("Webhook URL must be configured.")

        from urllib.parse import urlparse

        parsed = urlparse(self.config.url)
        is_https = parsed.scheme == "https"
        is_localhost = (
            parsed.scheme == "http"
            and parsed.hostname in ("localhost", "127.0.0.1", "::1")
        )
        if not is_https and not is_localhost:
            raise ValueError(
                "Webhook URL must use HTTPS or http://localhost. "
                "Sending secrets over plaintext HTTP is not allowed."
            )

        payload = json.dumps({
            "subject": subject,
            "body": body,
            "original_message_id": original_message_id or None,
        }).encode("utf-8")

        headers = {"Content-Type": "application/json"}
        headers.update(self.config.headers)

        req = Request(self.config.url, data=payload, headers=headers, method="POST")
        with urlopen(req, timeout=10) as resp:
            status = resp.status

        logger.info("Webhook POST: status=%d, url=%s", status, self.config.url)
        return f"Delivered via webhook (HTTP {status})"
