"""
BDV (Blind Data Vault) — entrypoint.

Loads config, generates key if needed, loads plugins, starts socket server(s).
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
from pathlib import Path

from daemon.channels.file import FileChannel
from daemon.channels.smtp import SmtpChannel
from daemon.channels.webhook import WebhookChannel
from daemon.commands import COMMANDS
from daemon.config import BDVConfig, load_config
from daemon.crypto import generate_key
from daemon.plugins import load_plugins
from daemon.server import start_tcp_server, start_unix_server
from daemon.version import __version__

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("bdv")


def _build_channel(config: BDVConfig, plugin_channels: dict[str, type]):
    """Build the output channel from config, falling back to plugins."""
    output_type = config.output.type.lower()

    if output_type == "smtp":
        return SmtpChannel(config.output.smtp)
    elif output_type == "webhook":
        return WebhookChannel(config.output.webhook)
    elif output_type == "file":
        return FileChannel(config.storage.outbox_dir)
    elif output_type in plugin_channels:
        channel_class = plugin_channels[output_type]
        return channel_class(config)
    else:
        logger.warning(
            "Unknown output type '%s', falling back to file channel",
            output_type,
        )
        return FileChannel(config.storage.outbox_dir)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="bdv",
        description="BDV (Blind Data Vault) — privilege-separated "
        "secret vault for AI agents",
    )
    parser.add_argument(
        "-c", "--config",
        help="Path to YAML config file (default: $BDV_CONFIG or none)",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"bdv {__version__}",
    )
    args = parser.parse_args()

    config = load_config(args.config)

    # Ensure directories exist
    vault_dir = Path(config.storage.vault_dir)
    vault_dir.mkdir(parents=True, exist_ok=True)
    Path(config.storage.inbox_dir).mkdir(parents=True, exist_ok=True)
    Path(config.storage.outbox_dir).mkdir(parents=True, exist_ok=True)

    # Auto-generate key on first run
    key_file = vault_dir / ".vault-key"
    generate_key(key_file)

    # Load plugins (commands + channels)
    plugin_commands, plugin_channels = load_plugins(config.plugins_dir)
    COMMANDS.update(plugin_commands)

    # Build output channel (may use a plugin channel)
    channel = _build_channel(config, plugin_channels)

    # Start servers
    servers = []
    unix_server = start_unix_server(config, channel)
    servers.append(unix_server)

    if config.server.tcp_enabled:
        tcp_server = start_tcp_server(config, channel)
        servers.append(tcp_server)

    logger.info("BDV %s started", __version__)

    # Wait for shutdown signal
    def shutdown(signum, frame):
        logger.info("Shutting down BDV")
        for s in servers:
            s.close()
        sys.exit(0)

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)

    # Block main thread
    signal.pause()


if __name__ == "__main__":
    main()
