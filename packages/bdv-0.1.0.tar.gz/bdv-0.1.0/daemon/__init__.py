from daemon.version import __version__

__all__ = ["__version__"]
