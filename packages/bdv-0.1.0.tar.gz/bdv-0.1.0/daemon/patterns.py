"""
Pattern derivation and anomaly detection with contextual redaction windows.

Patterns are derived from TRUSTED data (vault secrets), never from LLM input.
Generated patterns are always linear — no backtracking, no nested quantifiers,
no ReDoS risk.
"""

from __future__ import annotations

import logging
import re

logger = logging.getLogger("bdv.patterns")

# Delimiter characters that can appear between content chars in secrets
DELIMITERS = set("-. /")

# Pattern overrides by secret name (empty by default — auto-derivation handles most cases)
PATTERN_OVERRIDES: dict[str, str] = {}


def derive_patterns(name: str, secret: str) -> str:
    """Derive regex patterns from the secret's actual value.

    Analyzes the character structure and generates multiple pattern variants
    to catch alternative formatting:
      "123-45-6789" -> matches 123-45-6789, 123 45 6789, 123456789, 123.45.6789
      "AB 12 34 56 C" -> matches AB 12 34 56 C, AB123456C, AB-12-34-56-C

    Returns a combined regex pattern string (variants joined with |).
    """
    # Check for manual override first
    name_lower = name.lower()
    for key, pattern in PATTERN_OVERRIDES.items():
        if key in name_lower:
            return pattern

    # Split secret into content groups (digits/letters) and delimiters
    groups: list[str] = []
    current_group = ""
    has_delimiters = False

    for char in secret:
        if char in DELIMITERS:
            has_delimiters = True
            if current_group:
                groups.append(current_group)
                current_group = ""
        else:
            current_group += char
    if current_group:
        groups.append(current_group)

    if not groups:
        return re.escape(secret)

    def group_pattern(g: str) -> str:
        """Convert a content group to a regex pattern."""
        if g.isdigit():
            return r"\d{" + str(len(g)) + "}"
        elif g.isalpha():
            if g.isupper():
                return "[A-Z]{" + str(len(g)) + "}"
            elif g.islower():
                return "[a-z]{" + str(len(g)) + "}"
            else:
                return re.escape(g)
        else:
            parts = []
            for c in g:
                if c.isdigit():
                    parts.append(r"\d")
                elif c.isupper():
                    parts.append("[A-Z]")
                elif c.islower():
                    parts.append("[a-z]")
                else:
                    parts.append(re.escape(c))
            return "".join(parts)

    group_patterns = [group_pattern(g) for g in groups]

    variants = []

    # Variant 1: flexible delimiter (any delimiter character, optional)
    flexible = r"[\s\-./]?".join(group_patterns)
    variants.append(r"\b" + flexible + r"\b")

    if has_delimiters and len(groups) > 1:
        # Variant 2: compact (no delimiters)
        compact = "".join(group_patterns)
        variants.append(r"\b" + compact + r"\b")

    combined = "|".join(variants)

    logger.debug(
        "Derived patterns for '%s': %d variant(s) from %d group(s)",
        name, len(variants), len(groups),
    )

    return combined


def build_context_window(
    doc_text: str,
    match_start: int,
    match_end: int,
    match_index: int,
    window_size: int = 40,
) -> str:
    """Extract text around a match with redacted values.

    Redacts the matched value and any other number sequences in the context
    to prevent adjacent sensitive data from leaking.
    """
    ctx_start = max(0, match_start - window_size)
    ctx_end = min(len(doc_text), match_end + window_size)

    before = doc_text[ctx_start:match_start]
    after = doc_text[match_end:ctx_end]

    before = before.replace("\n", " ").strip()
    after = after.replace("\n", " ").strip()

    # Aggressively redact any numeric sequences to prevent PII leaks
    for txt_pattern in [
        r"\d{3}-\d{2}-\d{4}",
        r"\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}",
        r"\d{3,}",
    ]:
        before = re.sub(txt_pattern, "[REDACTED]", before)
        after = re.sub(txt_pattern, "[REDACTED]", after)

    prefix = "..." if ctx_start > 0 else ""
    suffix = "..." if ctx_end < len(doc_text) else ""

    return f"{prefix}{before} [REDACTED_MATCH_{match_index + 1}] {after}{suffix}"


def normalize_secret(secret: str) -> str:
    """Strip all delimiters from a secret for comparison."""
    return "".join(c for c in secret if c not in DELIMITERS)
