"""
PDF/image/text extraction with OCR fallback.
"""

from __future__ import annotations

import logging
import mimetypes
from pathlib import Path

logger = logging.getLogger("bdv.document")

# Minimum characters pdfplumber must return before we accept its output;
# below this threshold we fall back to OCR (likely a scanned PDF).
MIN_TEXT_LENGTH = 50


def extract_text(file_path: str | Path) -> str:
    """Extract text from a PDF, image, or text file.

    Strategy:
      1. For PDFs: try pdfplumber (text-based PDF)
      2. If pdfplumber returns minimal text: fall back to OCR (scanned PDF)
      3. For images: OCR directly via Tesseract
      4. For text files: direct read
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    mime, _ = mimetypes.guess_type(str(file_path))
    mime = mime or ""

    # Image files: OCR directly
    if mime.startswith("image/"):
        import pytesseract
        from PIL import Image

        img = Image.open(file_path)
        text = pytesseract.image_to_string(img)
        logger.info("Extracted %d chars from image via OCR: %s", len(text), path.name)
        return text

    # PDF files
    if mime == "application/pdf" or path.suffix.lower() == ".pdf":
        import pdfplumber

        text_parts = []
        with pdfplumber.open(str(file_path)) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text_parts.append(page_text)
        text = "\n".join(text_parts).strip()

        if len(text) > MIN_TEXT_LENGTH:
            logger.info("Extracted %d chars from PDF via pdfplumber: %s", len(text), path.name)
            return text

        # Fall back to OCR (scanned PDF)
        logger.info("pdfplumber returned minimal text, falling back to OCR: %s", path.name)
        import pytesseract
        from pdf2image import convert_from_path

        images = convert_from_path(str(file_path))
        ocr_parts = [pytesseract.image_to_string(img) for img in images]
        text = "\n".join(ocr_parts).strip()
        logger.info(
            "Extracted %d chars from PDF via OCR (%d pages): %s",
            len(text), len(images), path.name,
        )
        return text

    # Plain text files
    if mime.startswith("text/") or path.suffix.lower() in (
        ".txt", ".md", ".csv", ".json", ".xml",
    ):
        text = path.read_text(encoding="utf-8", errors="replace")
        logger.info("Read %d chars from text file: %s", len(text), path.name)
        return text

    raise ValueError(f"Unsupported file type: {mime or path.suffix}")
