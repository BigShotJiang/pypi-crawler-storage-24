"""
Command handlers for the vault daemon.

Supports namespaced secrets via colon syntax:
  'ssn'        → flat secret (vault_dir/ssn.age)
  'email:work' → namespaced   (vault_dir/email/work.age)

Group-level operations (check, delete) work on all values in a namespace.
"""

from __future__ import annotations

import hashlib
import logging
import re
import shutil
import threading
import time
from collections.abc import Callable
from pathlib import Path

from daemon.channels.base import OutputChannel
from daemon.config import BDVConfig
from daemon.crypto import decrypt, encrypt, secret_path, validate_name
from daemon.document import extract_text
from daemon.patterns import (
    build_context_window,
    derive_patterns,
    normalize_secret,
)

logger = logging.getLogger("bdv.commands")

VALID_TYPES = {"numeric", "exact", "text"}
DEFAULT_TYPE = "numeric"

# Deduplication: track recent sends (thread-safe with eviction)
_recent_sends: dict[str, float] = {}
_recent_sends_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def _vault_dir(config: BDVConfig) -> Path:
    return Path(config.storage.vault_dir)


def _key_file(config: BDVConfig) -> Path:
    return _vault_dir(config) / ".vault-key"


def _inbox_dir(config: BDVConfig) -> Path:
    return Path(config.storage.inbox_dir)


def _is_namespaced(name: str) -> bool:
    return ":" in name


def _parse_name(name: str) -> tuple[str, str | None]:
    """Parse 'group:label' into (group, label) or ('name', None) for flat."""
    if ":" in name:
        group, label = name.split(":", 1)
        return group, label
    return name, None


def _is_group(name: str, config: BDVConfig) -> bool:
    """Check if a name (without colon) refers to a namespace group directory."""
    return (_vault_dir(config) / name).is_dir()


def _group_labels(group: str, config: BDVConfig) -> list[str]:
    """List all labels in a namespace group, sorted."""
    group_dir = _vault_dir(config) / group
    if not group_dir.is_dir():
        return []
    return sorted(f.stem for f in group_dir.glob("*.age"))


def _desc_path(name: str, config: BDVConfig) -> Path:
    """Resolve description file path for a name."""
    vault = _vault_dir(config)
    group, label = _parse_name(name)
    if label:
        return vault / group / f"{label}.desc"
    if _is_group(name, config):
        return vault / name / ".desc"
    return vault / f"{name}.desc"


def _read_desc(name: str, config: BDVConfig) -> str:
    dp = _desc_path(name, config)
    return dp.read_text().strip() if dp.exists() else "(no description)"


def _type_path(name: str, config: BDVConfig) -> Path:
    """Resolve type file path. Namespaced secrets store type at group level."""
    vault = _vault_dir(config)
    group, label = _parse_name(name)
    if label:
        return vault / group / ".type"
    if _is_group(name, config):
        return vault / name / ".type"
    return vault / f"{name}.type"


def _read_type(name: str, config: BDVConfig) -> str:
    tp = _type_path(name, config)
    if tp.exists():
        t = tp.read_text().strip().lower()
        if t in VALID_TYPES:
            return t
    return DEFAULT_TYPE


def _write_type(name: str, secret_type: str, config: BDVConfig) -> None:
    tp = _type_path(name, config)
    tp.parent.mkdir(parents=True, exist_ok=True)
    tp.write_text(secret_type)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_list(params: dict, config: BDVConfig, channel: OutputChannel) -> str:
    vault = _vault_dir(config)

    # Collect flat secrets
    flat_secrets = sorted(f.stem for f in vault.glob("*.age"))

    # Collect namespace groups
    groups = sorted(
        d.name for d in vault.iterdir()
        if d.is_dir() and not d.name.startswith(".")
    )

    if not flat_secrets and not groups:
        return "Vault is empty. No secrets stored."

    lines = []

    for name in flat_secrets:
        desc = _read_desc(name, config)
        secret_type = _read_type(name, config)
        type_tag = f" [{secret_type}]" if secret_type != DEFAULT_TYPE else ""
        lines.append(f"  \u2022 {name}{type_tag} \u2014 {desc}")

    for group in groups:
        labels = _group_labels(group, config)
        if not labels:
            continue
        group_desc = _read_desc(group, config)
        group_type = _read_type(group, config)
        type_tag = f" [{group_type}]" if group_type != DEFAULT_TYPE else ""
        lines.append(
            f"  \u2022 {group}{type_tag} \u2014 {group_desc} "
            f"({len(labels)} value{'s' if len(labels) != 1 else ''})"
        )
        for label in labels:
            label_desc = _read_desc(f"{group}:{label}", config)
            lines.append(f"    - {label}: {label_desc}")

    return "Stored secrets:\n" + "\n".join(lines)


def cmd_check_document(params: dict, config: BDVConfig, channel: OutputChannel) -> str:
    """Check if a stored secret exists within a document.

    Supports:
      check_document name=ssn           → check flat secret
      check_document name=email:work    → check specific label
      check_document name=email         → check ALL labels in group
    """
    name = params.get("name", "")
    file_path = params.get("file_path", "")

    if not name or not file_path:
        return "ERROR: 'name' and 'file_path' are required."

    try:
        validate_name(name)
    except ValueError as e:
        return f"ERROR: {e}"

    # Path traversal prevention
    inbox = _inbox_dir(config)
    try:
        resolved = Path(file_path).resolve()
        if not resolved.is_relative_to(inbox.resolve()):
            return f"ERROR: file_path must be within {inbox}"
    except (ValueError, OSError):
        return "ERROR: Invalid file_path."

    # Extract document text (shared across all checks)
    try:
        doc_text = extract_text(file_path)
    except FileNotFoundError:
        return f"FILE_NOT_FOUND: {file_path}"
    except ValueError as e:
        return f"UNSUPPORTED_FILE: {e}"
    except Exception as e:
        return f"EXTRACTION_ERROR: Failed to read {file_path}: {e}"

    # Group-level check: no colon, but a group directory exists
    group, label = _parse_name(name)
    if label is None and _is_group(name, config):
        return _check_group(name, doc_text, config)

    # Single secret check (flat or namespaced with label)
    return _check_single(name, doc_text, config)


def _check_single(name: str, doc_text: str, config: BDVConfig) -> str:
    """Check a single secret (flat or specific label) against doc text."""
    try:
        secret = decrypt(name, _vault_dir(config), _key_file(config)).strip()
    except FileNotFoundError:
        return f"SECRET_NOT_FOUND: No secret named '{name}' in vault."
    except RuntimeError as e:
        return f"DECRYPTION_ERROR: {e}"

    secret_type = _read_type(name, config)
    ctx_window = config.patterns.context_window

    if secret_type == "exact":
        return _check_exact(name, secret, doc_text, ctx_window)
    if secret_type == "text":
        return _check_text(name, secret, doc_text, ctx_window)
    return _check_numeric(name, secret, doc_text, ctx_window)


def _check_group(group: str, doc_text: str, config: BDVConfig) -> str:
    """Check all labels in a namespace group against a document."""
    labels = _group_labels(group, config)
    if not labels:
        return f"SECRET_NOT_FOUND: No secrets in group '{group}'."

    results = []
    found = 0
    for label in labels:
        full_name = f"{group}:{label}"
        single_result = _check_single(full_name, doc_text, config)

        # Determine if this label was found based on the result
        is_found = (
            "MATCHES VAULT SECRET" in single_result
            or "was found in the document" in single_result
            or "components found" in single_result
        )

        if is_found:
            found += 1
            # Extract first context line if available
            context_line = ""
            for line in single_result.split("\n"):
                if "Context:" in line:
                    context_line = line.strip()
                    break
            results.append(
                f"  {full_name} \u2014 FOUND"
                + (f"\n    {context_line}" if context_line else "")
            )
        elif single_result.startswith("SECRET_NOT_FOUND") or \
                single_result.startswith("DECRYPTION_ERROR"):
            results.append(
                f"  {full_name} \u2014 ERROR: could not decrypt"
            )
        else:
            results.append(f"  {full_name} \u2014 NOT FOUND")

    total = len(labels)

    header = (
        f"RESULT: Checked {total} value{'s' if total != 1 else ''} "
        f"under '{group}' against document. "
        f"{found} found, {total - found} not found."
    )

    logger.info("check_document group '%s': %d/%d found", group, found, total)
    return header + "\n" + "\n".join(results)


def _check_exact(name: str, secret: str, doc_text: str, ctx_window: int) -> str:
    found_pos = doc_text.find(secret)
    if found_pos >= 0:
        context = build_context_window(
            doc_text, found_pos, found_pos + len(secret), 0, ctx_window,
        )
        logger.info("check_document: '%s' FOUND (type=exact)", name)
        return (
            f"RESULT: Secret '{name}' was found in the document.\n"
            f"  Match 1: [MATCHES VAULT SECRET]\n"
            f"  Context: {context}"
        )
    logger.info("check_document: '%s' NOT FOUND (type=exact)", name)
    return f"NOT FOUND: Secret '{name}' was not found in the document."


def _check_text(name: str, secret: str, doc_text: str, ctx_window: int) -> str:
    doc_lower = doc_text.lower()
    secret_lower = secret.lower()

    found_pos = doc_lower.find(secret_lower)
    if found_pos >= 0:
        context = build_context_window(
            doc_text, found_pos, found_pos + len(secret), 0, ctx_window,
        )
        logger.info("check_document: '%s' FOUND contiguous (type=text)", name)
        return (
            f"RESULT: Secret '{name}' was found in the document "
            f"(contiguous match).\n"
            f"  Match 1: [MATCHES VAULT SECRET]\n"
            f"  Context: {context}"
        )

    components = [
        c.strip() for c in re.split(r"[,\s]+", secret) if len(c.strip()) >= 2
    ]
    if not components:
        return f"NOT FOUND: Secret '{name}' was not found in the document."

    component_results = []
    component_found = []

    for idx, comp in enumerate(components):
        comp_pos = doc_lower.find(comp.lower())
        if comp_pos >= 0:
            context = build_context_window(
                doc_text, comp_pos, comp_pos + len(comp), idx, ctx_window,
            )
            component_results.append(
                f"  Component {idx + 1} ([REDACTED]): FOUND\n"
                f"    Context: {context}"
            )
            component_found.append(True)
        else:
            component_results.append(
                f"  Component {idx + 1} ([REDACTED]): NOT FOUND"
            )
            component_found.append(False)

    found_count = sum(component_found)
    all_found = all(component_found)
    total = len(components)

    if all_found:
        logger.info(
            "check_document: '%s' ALL %d components found", name, total,
        )
        return (
            f"RESULT: Secret '{name}' \u2014 all {total} components found "
            f"in document (non-contiguous, likely in separate fields).\n\n"
            + "\n".join(component_results)
        )
    elif found_count > 0:
        logger.info(
            "check_document: '%s' PARTIAL %d/%d", name, found_count, total,
        )
        return (
            f"PARTIAL MATCH: Secret '{name}' \u2014 "
            f"{found_count}/{total} components found.\n\n"
            + "\n".join(component_results)
        )
    logger.info("check_document: '%s' NOT FOUND (type=text)", name)
    return f"NOT FOUND: Secret '{name}' was not found in the document."


def _check_numeric(
    name: str, secret: str, doc_text: str, ctx_window: int,
) -> str:
    pattern = derive_patterns(name, secret)
    matches = list(re.finditer(pattern, doc_text))

    if not matches:
        logger.info("check_document: '%s' \u2014 no pattern matches", name)
        return (
            f"RESULT: No strings matching the expected format for '{name}' "
            f"were found in the document."
        )

    secret_normalized = normalize_secret(secret)
    match_reports = []
    vault_match_count = 0
    non_match_count = 0

    for i, m in enumerate(matches):
        candidate_normalized = normalize_secret(m.group())
        is_match = candidate_normalized == secret_normalized

        if is_match:
            vault_match_count += 1
            status = "MATCHES VAULT SECRET"
        else:
            non_match_count += 1
            status = "DOES NOT MATCH"

        context = build_context_window(
            doc_text, m.start(), m.end(), i, ctx_window,
        )
        match_reports.append(
            f"  Match {i + 1}: [{status}]\n  Context: {context}"
        )

    total = len(matches)
    report_lines = [
        f"RESULT: Found {total} string(s) matching the expected format "
        f"for '{name}'.",
        f"  Vault matches: {vault_match_count}",
        f"  Non-matches: {non_match_count}",
        "",
    ]
    report_lines.extend(match_reports)

    logger.info(
        "check_document: '%s' \u2014 %d candidates, %d matches, %d non",
        name, total, vault_match_count, non_match_count,
    )

    return "\n".join(report_lines)


def cmd_send(params: dict, config: BDVConfig, channel: OutputChannel) -> str:
    template = params.get("template", "")
    subject = params.get("subject", "")
    original_message_id = params.get("original_message_id", "")

    if not template or not subject:
        return "ERROR: 'template' and 'subject' are required."

    # Dedup check (thread-safe with eviction)
    dedup_key = hashlib.sha256(
        f"{subject}:{template}".encode(),
    ).hexdigest()[:16]
    now = time.time()
    dedup_window = config.patterns.dedup_window
    with _recent_sends_lock:
        # Evict expired entries
        expired = [
            k for k, t in _recent_sends.items()
            if now - t >= dedup_window
        ]
        for k in expired:
            del _recent_sends[k]

        if dedup_key in _recent_sends:
            logger.warning(
                "Duplicate send blocked: %s (within %ds)",
                subject, int(dedup_window),
            )
            return (
                f"Send already completed for '{subject}' within "
                f"the last {int(dedup_window)}s. Duplicate blocked."
            )
        _recent_sends[dedup_key] = now

    # Find and replace placeholders — supports colons for namespaced secrets
    placeholder_pattern = r"\{\{VAULT:([a-zA-Z0-9_:.-]+)\}\}"
    placeholders = re.findall(placeholder_pattern, template)

    if not placeholders:
        return "ERROR: No {{VAULT:secret_name}} placeholders found in template."

    populated = template
    replaced_names = []
    for name in placeholders:
        try:
            validate_name(name)
            value = decrypt(
                name, _vault_dir(config), _key_file(config),
            ).strip()
            populated = populated.replace(f"{{{{VAULT:{name}}}}}", value)
            replaced_names.append(name)
        except ValueError as e:
            return f"ERROR: Invalid secret name '{name}': {e}"
        except FileNotFoundError:
            return (
                f"ERROR: Secret '{name}' not found in vault. Aborting send."
            )
        except RuntimeError as e:
            return (
                f"ERROR: Failed to decrypt '{name}': {e}. Aborting send."
            )

    try:
        delivery_msg = channel.send(
            populated,
            subject,
            original_message_id=original_message_id,
        )
    except Exception as e:
        return f"ERROR: Failed to send: {e}"
    finally:
        populated = None  # noqa: F841

    logger.info(
        "Send completed: %d secret(s) injected [%s], subject=%s",
        len(replaced_names), ", ".join(replaced_names), subject,
    )

    return (
        f"Send completed successfully.\n"
        f"  Secrets injected: {len(replaced_names)} "
        f"({', '.join(replaced_names)})\n"
        f"  {delivery_msg}\n"
        f"  Subject: {subject}\n"
        f"  NOTE: Populated text was NOT returned to this context."
    )


def cmd_write(params: dict, config: BDVConfig, channel: OutputChannel) -> str:
    name = params.get("name", "")
    value = params.get("value", "")
    description = params.get("description", "")
    secret_type = params.get("type", DEFAULT_TYPE).lower()

    if not name or not value:
        return "ERROR: 'name' and 'value' are required."

    try:
        validate_name(name)
    except ValueError as e:
        return f"ERROR: {e}"

    if secret_type not in VALID_TYPES:
        return (
            f"ERROR: Invalid type '{secret_type}'. "
            f"Must be one of: {', '.join(VALID_TYPES)}"
        )

    vault = _vault_dir(config)
    group, label = _parse_name(name)

    # Prevent conflict: can't write email:work if email.age exists as flat
    if label and (vault / f"{group}.age").exists():
        return (
            f"ERROR: '{group}' already exists as a flat secret. "
            f"Delete it first to use as a namespace."
        )

    # Prevent conflict: can't write flat 'email' if email/ group exists
    if label is None and (vault / name).is_dir():
        return (
            f"ERROR: '{name}' already exists as a namespace group. "
            f"Use '{name}:<label>' to add values."
        )

    # For namespaced secrets, enforce consistent type within the group
    if label:
        existing_type_path = vault / group / ".type"
        if existing_type_path.exists():
            existing = existing_type_path.read_text().strip().lower()
            if existing != secret_type:
                return (
                    f"ERROR: Group '{group}' has type '{existing}'. "
                    f"Cannot mix types within a namespace."
                )

    try:
        encrypt(name, value, vault, _key_file(config))
    except RuntimeError as e:
        return f"ERROR: {e}"

    _write_type(name, secret_type, config)

    if description:
        dp = _desc_path(name, config)
        dp.parent.mkdir(parents=True, exist_ok=True)
        dp.write_text(description)

    logger.info("Secret stored: %s (type=%s)", name, secret_type)
    desc_msg = f" ({description})" if description else ""
    return f"Secret '{name}'{desc_msg} [type: {secret_type}] encrypted and stored."


def cmd_delete(params: dict, config: BDVConfig, channel: OutputChannel) -> str:
    name = params.get("name", "")
    if not name:
        return "ERROR: 'name' is required."

    try:
        validate_name(name)
    except ValueError as e:
        return f"ERROR: {e}"

    vault = _vault_dir(config)
    group, label = _parse_name(name)

    # Delete specific label from a namespace
    if label:
        age_path = secret_path(name, vault)
        if not age_path.exists():
            return f"Secret '{name}' not found."

        age_path.unlink()
        desc = vault / group / f"{label}.desc"
        if desc.exists():
            desc.unlink()

        # If group is now empty, clean up the directory
        remaining = list((vault / group).glob("*.age"))
        if not remaining:
            shutil.rmtree(vault / group)
            logger.info("Deleted '%s' and removed empty group '%s'", name, group)
        else:
            logger.info("Deleted '%s' (%d remaining in group)", name, len(remaining))
        return f"Secret '{name}' deleted from vault."

    # Delete entire group
    group_dir = vault / name
    if group_dir.is_dir():
        labels = _group_labels(name, config)
        shutil.rmtree(group_dir)
        logger.info("Deleted group '%s' (%d values)", name, len(labels))
        return (
            f"Group '{name}' deleted from vault "
            f"({len(labels)} value{'s' if len(labels) != 1 else ''} removed)."
        )

    # Delete flat secret
    age_path = vault / f"{name}.age"
    if not age_path.exists():
        return f"Secret '{name}' not found."

    age_path.unlink()
    for ext in (".desc", ".type"):
        p = vault / f"{name}{ext}"
        if p.exists():
            p.unlink()

    logger.info("Secret deleted: %s", name)
    return f"Secret '{name}' deleted from vault."


def cmd_describe(params: dict, config: BDVConfig, channel: OutputChannel) -> str:
    name = params.get("name", "")
    description = params.get("description", "")

    if not name or not description:
        return "ERROR: 'name' and 'description' are required."

    try:
        validate_name(name)
    except ValueError as e:
        return f"ERROR: {e}"

    vault = _vault_dir(config)
    group, label = _parse_name(name)

    # Specific label
    if label:
        if not secret_path(name, vault).exists():
            return f"Secret '{name}' not found."
        dp = _desc_path(name, config)
        dp.write_text(description)
        return f"Description updated for '{name}'."

    # Group-level description
    if _is_group(name, config):
        dp = vault / name / ".desc"
        dp.write_text(description)
        return f"Description updated for group '{name}'."

    # Flat secret
    if not (vault / f"{name}.age").exists():
        return f"Secret '{name}' not found."

    (vault / f"{name}.desc").write_text(description)
    return f"Description updated for '{name}'."


COMMANDS: dict[str, Callable] = {
    "list": cmd_list,
    "check_document": cmd_check_document,
    "send": cmd_send,
    "write": cmd_write,
    "delete": cmd_delete,
    "describe": cmd_describe,
}
