"""
Configuration system with three layers: defaults -> YAML file -> env vars.
Env vars win. Pattern: BDV_<SECTION>_<KEY> (e.g., BDV_SERVER_TCP_ENABLED=true).
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class ServerConfig:
    socket_path: str = "/run/bdv/bdv.sock"
    tcp_enabled: bool = False
    tcp_host: str = "127.0.0.1"
    tcp_port: int = 9652
    tcp_token: str = ""


@dataclass
class StorageConfig:
    vault_dir: str = "/data/secrets"
    inbox_dir: str = "/data/inbox"
    outbox_dir: str = "/data/outbox"


@dataclass
class SmtpConfig:
    host: str = "localhost"
    port: int = 587
    from_addr: str = ""
    to_addr: str = ""
    username: str = ""
    password: str = ""
    starttls: bool = True


@dataclass
class WebhookConfig:
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)


@dataclass
class OutputConfig:
    type: str = "file"  # file | smtp | webhook
    smtp: SmtpConfig = field(default_factory=SmtpConfig)
    webhook: WebhookConfig = field(default_factory=WebhookConfig)


@dataclass
class PatternConfig:
    context_window: int = 40
    dedup_window: float = 30.0


@dataclass
class BDVConfig:
    server: ServerConfig = field(default_factory=ServerConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    patterns: PatternConfig = field(default_factory=PatternConfig)
    plugins_dir: str = "/plugins"


def _apply_env_overrides(config: BDVConfig) -> None:
    """Apply BDV_* environment variables over the config."""
    mapping: list[tuple[str, Any, str, type]] = [
        ("BDV_SERVER_SOCKET_PATH", config.server, "socket_path", str),
        ("BDV_SERVER_TCP_ENABLED", config.server, "tcp_enabled", bool),
        ("BDV_SERVER_TCP_HOST", config.server, "tcp_host", str),
        ("BDV_SERVER_TCP_PORT", config.server, "tcp_port", int),
        ("BDV_SERVER_TCP_TOKEN", config.server, "tcp_token", str),
        ("BDV_STORAGE_VAULT_DIR", config.storage, "vault_dir", str),
        ("BDV_STORAGE_INBOX_DIR", config.storage, "inbox_dir", str),
        ("BDV_STORAGE_OUTBOX_DIR", config.storage, "outbox_dir", str),
        ("BDV_OUTPUT_TYPE", config.output, "type", str),
        ("BDV_OUTPUT_SMTP_HOST", config.output.smtp, "host", str),
        ("BDV_OUTPUT_SMTP_PORT", config.output.smtp, "port", int),
        ("BDV_OUTPUT_SMTP_FROM", config.output.smtp, "from_addr", str),
        ("BDV_OUTPUT_SMTP_TO", config.output.smtp, "to_addr", str),
        ("BDV_OUTPUT_SMTP_USERNAME", config.output.smtp, "username", str),
        ("BDV_OUTPUT_SMTP_PASSWORD", config.output.smtp, "password", str),
        ("BDV_OUTPUT_SMTP_STARTTLS", config.output.smtp, "starttls", bool),
        ("BDV_OUTPUT_WEBHOOK_URL", config.output.webhook, "url", str),
        ("BDV_PATTERNS_CONTEXT_WINDOW", config.patterns, "context_window", int),
        ("BDV_PATTERNS_DEDUP_WINDOW", config.patterns, "dedup_window", float),
        ("BDV_PLUGINS_DIR", config, "plugins_dir", str),
    ]

    for env_key, obj, attr, typ in mapping:
        val = os.environ.get(env_key)
        if val is not None:
            if typ is bool:
                setattr(obj, attr, val.lower() in ("true", "1", "yes"))
            else:
                try:
                    setattr(obj, attr, typ(val))
                except (ValueError, TypeError):
                    logging.getLogger("bdv.config").warning(
                        "Invalid value for %s: '%s' (expected %s), using default",
                        env_key, val, typ.__name__,
                    )


def _apply_yaml_dict(config: BDVConfig, data: dict) -> None:
    """Apply a parsed YAML dict over the config defaults."""
    server = data.get("server", {})
    if server:
        for key in ("socket_path", "tcp_host", "tcp_token"):
            if key in server:
                setattr(config.server, key, str(server[key]))
        if "tcp_enabled" in server:
            config.server.tcp_enabled = bool(server["tcp_enabled"])
        if "tcp_port" in server:
            config.server.tcp_port = int(server["tcp_port"])

    storage = data.get("storage", {})
    if storage:
        for key in ("vault_dir", "inbox_dir", "outbox_dir"):
            if key in storage:
                setattr(config.storage, key, str(storage[key]))

    output = data.get("output", {})
    if output:
        if "type" in output:
            config.output.type = str(output["type"])
        smtp = output.get("smtp", {})
        if smtp:
            for key in ("host", "from_addr", "to_addr", "username", "password"):
                if key in smtp:
                    setattr(config.output.smtp, key, str(smtp[key]))
            if "port" in smtp:
                config.output.smtp.port = int(smtp["port"])
            if "starttls" in smtp:
                config.output.smtp.starttls = bool(smtp["starttls"])
        webhook = output.get("webhook", {})
        if webhook:
            if "url" in webhook:
                config.output.webhook.url = str(webhook["url"])
            if "headers" in webhook:
                config.output.webhook.headers = dict(webhook["headers"])

    patterns = data.get("patterns", {})
    if patterns:
        if "context_window" in patterns:
            config.patterns.context_window = int(patterns["context_window"])
        if "dedup_window" in patterns:
            config.patterns.dedup_window = float(patterns["dedup_window"])

    if "plugins_dir" in data:
        config.plugins_dir = str(data["plugins_dir"])


def load_config(config_path: str | Path | None = None) -> BDVConfig:
    """Load config: defaults -> YAML overlay -> env overlay."""
    config = BDVConfig()

    # YAML overlay
    if config_path is None:
        config_path = os.environ.get("BDV_CONFIG")
    if config_path:
        path = Path(config_path)
        if path.exists():
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            _apply_yaml_dict(config, data)

    # Env overlay (wins over YAML)
    _apply_env_overrides(config)

    return config
