"""
age encrypt/decrypt operations.

Supports namespaced secrets via colon syntax:
  'ssn'        -> vault_dir/ssn.age        (flat)
  'email:work' -> vault_dir/email/work.age (namespaced)
"""

from __future__ import annotations

import logging
import os
import re
import subprocess
from pathlib import Path

logger = logging.getLogger("bdv.crypto")

# Allowed characters in secret names and labels: alphanumeric, underscore, hyphen, dot
_NAME_RE = re.compile(r"^[a-zA-Z0-9_.\-]+$")


def validate_name(name: str) -> None:
    """Validate a secret name. Raises ValueError if invalid."""
    if not name:
        raise ValueError("Secret name cannot be empty.")

    if ":" in name:
        group, label = name.split(":", 1)
        if not group or not label:
            raise ValueError(
                f"Invalid namespaced name '{name}': "
                "both group and label are required."
            )
        if not _NAME_RE.match(group):
            raise ValueError(
                f"Invalid group name '{group}': "
                "only alphanumeric, underscore, hyphen, and dot allowed."
            )
        if not _NAME_RE.match(label):
            raise ValueError(
                f"Invalid label '{label}': "
                "only alphanumeric, underscore, hyphen, and dot allowed."
            )
    else:
        if not _NAME_RE.match(name):
            raise ValueError(
                f"Invalid secret name '{name}': "
                "only alphanumeric, underscore, hyphen, and dot allowed."
            )


def secret_path(name: str, vault_dir: Path) -> Path:
    """Resolve a secret name to its .age file path.

    Validates the name before constructing the path.
    """
    validate_name(name)
    if ":" in name:
        group, label = name.split(":", 1)
        return vault_dir / group / f"{label}.age"
    return vault_dir / f"{name}.age"


def get_recipient(key_file: Path) -> str:
    """Extract public key from age identity file."""
    for line in key_file.read_text().splitlines():
        if line.startswith("# public key:"):
            return line.split(":", 1)[1].strip()
    raise RuntimeError("Could not extract public key from identity file.")


def decrypt(name: str, vault_dir: Path, key_file: Path) -> str:
    """Decrypt a secret by name."""
    path = secret_path(name, vault_dir)
    if not path.exists():
        raise FileNotFoundError(f"Secret '{name}' not found.")

    proc = subprocess.run(
        ["age", "--decrypt", "--identity", str(key_file), str(path)],
        capture_output=True,
    )
    if proc.returncode != 0:
        raise RuntimeError("Decryption failed.")

    return proc.stdout.decode()


def encrypt(name: str, value: str, vault_dir: Path, key_file: Path) -> None:
    """Encrypt and store a secret."""
    recipient = get_recipient(key_file)
    path = secret_path(name, vault_dir)

    # Create parent directory for namespaced secrets
    path.parent.mkdir(parents=True, exist_ok=True)

    proc = subprocess.run(
        ["age", "--encrypt", "--recipient", recipient, "-o", str(path)],
        input=value.encode(),
        capture_output=True,
    )
    if proc.returncode != 0:
        raise RuntimeError("Encryption failed.")

    os.chmod(str(path), 0o600)


def generate_key(key_file: Path) -> None:
    """Generate an age keypair if it doesn't exist."""
    if key_file.exists():
        logger.info("Key file already exists: %s", key_file)
        return

    key_file.parent.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        ["age-keygen", "-o", str(key_file)],
        capture_output=True,
    )
    if proc.returncode != 0:
        raise RuntimeError("Key generation failed.")

    os.chmod(str(key_file), 0o400)
    logger.info("Generated new age keypair: %s", key_file)
