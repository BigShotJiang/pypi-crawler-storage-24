"""
Plugin loader — discovers custom commands and output channels from a directory.

Each .py file in the plugins directory can define:

  COMMANDS — dict mapping command names to handler functions
  CHANNELS — dict mapping channel type names to OutputChannel subclasses

Command handler signature:

    def cmd_example(params: dict, config: BDVConfig, channel: OutputChannel) -> str:
        ...

Channel class signature:

    class S3Channel(OutputChannel):
        def __init__(self, config: BDVConfig):
            ...
        def send(self, body, subject, *, original_message_id="") -> str:
            ...

    CHANNELS = {"s3": S3Channel}

Then set BDV_OUTPUT_TYPE=s3 to use it.
"""

from __future__ import annotations

import importlib.util
import logging
from collections.abc import Callable
from pathlib import Path

from daemon.channels.base import OutputChannel

logger = logging.getLogger("bdv.plugins")

BUILTIN_COMMANDS = frozenset({
    "list", "check_document", "send", "write", "delete", "describe",
})

BUILTIN_CHANNELS = frozenset({"file", "smtp", "webhook"})


def load_plugins(
    plugins_dir: str | Path,
) -> tuple[dict[str, Callable], dict[str, type]]:
    """Load all .py files from plugins_dir.

    Returns (commands_dict, channels_dict).
    """
    plugins_path = Path(plugins_dir)
    commands: dict[str, Callable] = {}
    channels: dict[str, type] = {}

    if not plugins_path.is_dir():
        return commands, channels

    for py_file in sorted(plugins_path.glob("*.py")):
        name = py_file.stem
        try:
            spec = importlib.util.spec_from_file_location(
                f"bdv_plugin_{name}", py_file,
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Load commands
            plugin_commands = getattr(module, "COMMANDS", None)
            if isinstance(plugin_commands, dict):
                for cmd_name, handler in plugin_commands.items():
                    if cmd_name in BUILTIN_COMMANDS:
                        logger.warning(
                            "Plugin %s: cannot override built-in "
                            "command '%s', skipping",
                            py_file.name, cmd_name,
                        )
                        continue

                    if not callable(handler):
                        logger.warning(
                            "Plugin %s: '%s' is not callable, skipping",
                            py_file.name, cmd_name,
                        )
                        continue

                    if cmd_name in commands:
                        logger.warning(
                            "Plugin %s: command '%s' already "
                            "registered, overwriting",
                            py_file.name, cmd_name,
                        )

                    commands[cmd_name] = handler
                    logger.info(
                        "Loaded plugin command: %s (from %s)",
                        cmd_name, py_file.name,
                    )

            # Load channels
            plugin_channels = getattr(module, "CHANNELS", None)
            if isinstance(plugin_channels, dict):
                for ch_name, ch_class in plugin_channels.items():
                    if ch_name in BUILTIN_CHANNELS:
                        logger.warning(
                            "Plugin %s: cannot override built-in "
                            "channel '%s', skipping",
                            py_file.name, ch_name,
                        )
                        continue

                    if not (
                        isinstance(ch_class, type)
                        and issubclass(ch_class, OutputChannel)
                    ):
                        logger.warning(
                            "Plugin %s: '%s' is not an "
                            "OutputChannel subclass, skipping",
                            py_file.name, ch_name,
                        )
                        continue

                    if ch_name in channels:
                        logger.warning(
                            "Plugin %s: channel '%s' already "
                            "registered, overwriting",
                            py_file.name, ch_name,
                        )

                    channels[ch_name] = ch_class
                    logger.info(
                        "Loaded plugin channel: %s (from %s)",
                        ch_name, py_file.name,
                    )

        except Exception as e:
            logger.error("Failed to load plugin %s: %s", py_file.name, e)

    if commands:
        logger.info(
            "Loaded %d plugin command(s) from %s",
            len(commands), plugins_path,
        )
    if channels:
        logger.info(
            "Loaded %d plugin channel(s) from %s",
            len(channels), plugins_path,
        )

    return commands, channels
