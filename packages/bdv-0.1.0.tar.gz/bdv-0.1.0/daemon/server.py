"""
Unix + TCP socket server with optional auth token.
"""

from __future__ import annotations

import hmac
import json
import logging
import os
import socket
from concurrent.futures import ThreadPoolExecutor

from daemon.channels.base import OutputChannel
from daemon.commands import COMMANDS
from daemon.config import BDVConfig

logger = logging.getLogger("bdv.server")

MAX_MESSAGE_SIZE = 1_048_576  # 1 MB
CONNECTION_TIMEOUT = 30  # seconds
MAX_WORKERS = 20


def handle_client(
    conn: socket.socket,
    config: BDVConfig,
    channel: OutputChannel,
    require_auth: bool = False,
    auth_token: str = "",
) -> None:
    """Handle a single client connection."""
    try:
        conn.settimeout(CONNECTION_TIMEOUT)

        data = b""
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            data += chunk
            if len(data) > MAX_MESSAGE_SIZE:
                response = {"ok": False, "error": "Request too large."}
                conn.sendall((json.dumps(response) + "\n").encode())
                return
            if b"\n" in data:
                break

        if not data:
            return

        request = json.loads(data.decode().strip())

        # TCP auth check (timing-safe comparison)
        if require_auth:
            token = str(request.get("token", ""))
            if not hmac.compare_digest(token, auth_token):
                response = {"ok": False, "error": "Authentication failed."}
                conn.sendall((json.dumps(response) + "\n").encode())
                return

        cmd = request.get("cmd", "")

        if cmd not in COMMANDS:
            response = {"ok": False, "error": f"Unknown command: {cmd}"}
        else:
            try:
                result = COMMANDS[cmd](request, config, channel)
                response = {"ok": True, "result": result}
            except Exception as e:
                logger.error("Command '%s' failed: %s", cmd, e)
                response = {"ok": False, "error": "Internal error."}

        conn.sendall((json.dumps(response) + "\n").encode())
    except json.JSONDecodeError:
        conn.sendall(
            (json.dumps({"ok": False, "error": "Invalid JSON"}) + "\n").encode()
        )
    except socket.timeout:
        logger.warning("Client connection timed out")
    except Exception as e:
        logger.error("Client handler error: %s", e)
    finally:
        conn.close()


def _serve_loop(
    server: socket.socket,
    config: BDVConfig,
    channel: OutputChannel,
    require_auth: bool = False,
    auth_token: str = "",
) -> None:
    """Accept loop for a socket server."""
    pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)
    try:
        while True:
            conn, _ = server.accept()
            pool.submit(
                handle_client,
                conn, config, channel, require_auth, auth_token,
            )
    except OSError:
        pass  # socket closed
    finally:
        pool.shutdown(wait=False)


def start_unix_server(
    config: BDVConfig,
    channel: OutputChannel,
) -> socket.socket:
    """Start and return the Unix domain socket server."""
    from threading import Thread

    socket_path = config.server.socket_path

    if os.path.exists(socket_path):
        os.unlink(socket_path)

    os.makedirs(os.path.dirname(socket_path), exist_ok=True)

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(socket_path)
    os.chmod(socket_path, 0o660)
    server.listen(5)

    logger.info("Unix socket listening on %s", socket_path)

    Thread(
        target=_serve_loop,
        args=(server, config, channel),
        daemon=True,
    ).start()

    return server


def start_tcp_server(
    config: BDVConfig,
    channel: OutputChannel,
) -> socket.socket:
    """Start and return the TCP socket server (with auth)."""
    from threading import Thread

    host = config.server.tcp_host
    port = config.server.tcp_port
    token = config.server.tcp_token

    if not token:
        raise ValueError(
            "TCP server requires a non-empty auth token "
            "(BDV_SERVER_TCP_TOKEN)."
        )

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((host, port))
    server.listen(5)

    logger.info("TCP server listening on %s:%d", host, port)

    Thread(
        target=_serve_loop,
        args=(server, config, channel, True, token),
        daemon=True,
    ).start()

    return server
