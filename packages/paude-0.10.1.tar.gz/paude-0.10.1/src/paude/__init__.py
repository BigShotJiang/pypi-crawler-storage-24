"""Paude - Podman wrapper for running Claude Code in isolated containers."""

__version__ = "0.10.1"
