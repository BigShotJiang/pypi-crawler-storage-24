try:
    from . import _version

    __version__ = _version.__version__
except ImportError:
    # _version is generated at build time, fallback to package metadata
    try:
        from importlib.metadata import version

        __version__ = version("prefect-nomad")
    except Exception:
        __version__ = "0.1.0"


from .credentials import NomadCredentials
from .exceptions import (
    NomadError,
    NomadEvaluationError,
    NomadJobRegistrationError,
    NomadJobSchedulingError,
    NomadJobStopError,
    NomadJobTimeoutError,
)
from .worker import NomadWorker
