"""Document intelligence commands."""
