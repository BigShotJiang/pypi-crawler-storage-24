from setuptools import setup
setup(name='privaton-beacon-img-6ccb12ef74e873df-png', version='774.403.531', py_modules=['data'])
