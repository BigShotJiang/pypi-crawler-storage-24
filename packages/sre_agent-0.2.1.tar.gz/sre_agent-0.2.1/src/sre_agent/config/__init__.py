"""Shared configuration helpers."""
