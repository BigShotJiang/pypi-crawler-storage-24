"""Diagnosis quality evaluation suite."""
