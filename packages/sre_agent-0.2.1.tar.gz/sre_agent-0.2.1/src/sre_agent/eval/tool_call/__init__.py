"""Tool call evaluation suite."""
