"""AWS remote deployment package."""
