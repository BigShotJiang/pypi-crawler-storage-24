"""CLI presentation helpers."""
