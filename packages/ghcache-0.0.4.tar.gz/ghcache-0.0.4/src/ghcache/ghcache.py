import os
import requests
import datetime
import time
from urllib.parse import urlparse, parse_qsl, urlencode, urlunsplit
import json
from typing import Iterator, Tuple, Any, Optional
import pytz
import math


class GithubCache:
  def __init__(
    self,
    github_token: str | None = None,
    cache_directory: str | None = None,
    cache_r: bool = True,
    cache_w: bool = True,
  ):
    self._github_token = github_token or os.environ["GITHUB_TOKEN"]
    if cache_directory:
      self._cache_directory = cache_directory
    else:
      self._cache_directory = os.path.join(os.getcwd(), "cache")
    self._cache_r = cache_r
    self._cache_w = cache_w
    self._seconds_between_requests_max = 2.5
    self._seconds_between_requests = 0.5
    self._last_request_at = None

  def iterate(
    self, path_or_url: str, params: dict | None = None, list_key: str | None = None
  ) -> Iterator[Tuple[Any, int, int, Optional[int]]]:
    (cache_filepath, response_list) = self._request_load(path_or_url, params)

    for response_item in response_list or []:
      yield (response_item, len(response_list), 1, 1)

    if response_list is not None:
      return

    ret = []
    params = params or {}
    last_page = None
    loop = True
    if "page" not in params:
      params["page"] = 1

    while loop:
      response = self._raw_get(path_or_url, params)
      this_page = params["page"]

      links = requests.utils.parse_header_links(response.headers.get("link", "") or "")
      loop = False
      for link in links:
        if link["rel"] == "next":
          loop = True
          params["page"] += 1
        if link["rel"] == "last":
          link_params = dict(parse_qsl(urlparse(link["url"]).query))
          last_page = int(link_params["page"])

      response_dict = response.json()

      if (
        not list_key
        and "items" in response_dict
        and isinstance(response_dict.get("items", []), list)
      ):
        list_key = "items"

      if list_key:
        response_list: list = response_dict.get(list_key, [])
      else:
        response_list: list = response_dict

      for response_item in response_list:
        yield (response_item, len(response_list), this_page, last_page)

      ret += response_list

    self._request_save(cache_filepath, ret)

  def get(self, path_or_url: str, params: dict | None = None):
    (cache_filepath, response) = self._request_load(path_or_url, params)
    if response is None:
      response = self._raw_get(path_or_url, params).json()
      self._request_save(cache_filepath, response)
    return response

  def _raw_get(self, path_or_url: str, params: dict | None = None):
    """Makes a GET request to github avoiding rate limits

    Rate limit docs here: https://docs.github.com/en/rest/rate-limit/rate-limit?apiVersion=2026-03-10#get-rate-limit-status-for-the-authenticated-user
    """
    urlparsed = urlparse(path_or_url)

    if urlparsed.netloc:
      domain = urlparsed.netloc
    else:
      domain = "api.github.com"

    if urlparsed.scheme:
      scheme = urlparsed.scheme
    else:
      scheme = "https"

    if self._last_request_at is not None:
      seconds_since_last_request = (
        datetime.datetime.now(datetime.UTC) - self._last_request_at
      ).total_seconds()
      if seconds_since_last_request < self._seconds_between_requests:
        time.sleep(self._seconds_between_requests - seconds_since_last_request)

    params = params or {}
    # TODO: handle query params in the url
    ret = requests.get(
      urlunsplit((scheme, domain, urlparsed.path.strip("/"), "", "")),
      headers={
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {self._github_token}",
        "X-GitHub-Api-Version": "2022-11-28",
      },
      params=params,
    )

    if ret.status_code != 200:
      print(f"WARNING: API Call is not 200, it is {ret.status_code}")

    self._last_request_at = datetime.datetime.now(datetime.UTC)

    all_set, limit, remaining, used, reset = self._ratelimit_vals(ret.headers)

    if all_set:
      reset_at_utc = datetime.datetime.fromtimestamp(reset, datetime.UTC)
      reset_at_cst = reset_at_utc.astimezone(pytz.timezone("US/Central"))

      reset_at_cst_str = reset_at_cst.strftime("%Y-%m-%d %H:%M:%S")
      seconds_remaining = math.floor((reset_at_utc - self._last_request_at).total_seconds())
    else:
      reset_at_cst_str = None
      seconds_remaining = None

    if ret.headers.get("x-ratelimit-resource") == "core":
      if all_set:
        self._seconds_between_requests = max(
          0, math.ceil((seconds_remaining / remaining) * 100) / 100
        )
      else:
        self._seconds_between_requests = 0.5
    else:
      self._seconds_between_requests = self._seconds_between_requests_max

    if os.environ.get("VERBOSE"):
      resource = ret.headers.get("x-ratelimit-resource")
      now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
      print(f"just hit github {urlparsed.path}")
      print(f"{resource=}")
      print(f"{limit=}")
      print(f"{remaining=}")
      print(f"{used=}")
      print(f"{reset=}")
      print(f"{reset_at_cst_str=}")
      print(f"{seconds_remaining=}")
      print(f"{self._seconds_between_requests=}")
      print(f"{now_str=}")
      print("")

    return ret

  def _request_load(
    self, path_or_url: str, params: dict | None = None
  ) -> tuple[str | None, dict | None]:
    if not self._cache_directory:
      cache_filepath = None
    else:
      clean_path = urlparse(path_or_url).path

      params_clean = {k: v for k, v in (params or {}).items() if k != "page"}
      if params_clean:
        clean_path = f"{clean_path}?{urlencode(params_clean)}"

      cache_filepath = ensure_dir(
        os.path.join(self._cache_directory, f"{clean_path.strip('/')}.json")
      )

    if not self._cache_r:
      return (cache_filepath, None)

    if not cache_filepath or not os.path.exists(cache_filepath):
      return (cache_filepath, None)

    with open(cache_filepath, "r") as file:
      return (cache_filepath, json.load(file))

    return (cache_filepath, None)

  def _request_save(self, cache_filepath: str, response: list | dict):
    if not self._cache_w:
      return

    with open(cache_filepath, "w") as file:
      json.dump(response, file, indent=2)

  def _ratelimit_vals(
    self, headers: dict
  ) -> Tuple[bool, int | None, int | None, int | None, int | None]:
    ret = [True, None, None, None, None]

    header_names = [
      "x-ratelimit-limit",
      "x-ratelimit-remaining",
      "x-ratelimit-used",
      "x-ratelimit-reset",
    ]
    for idx, hdr_name in enumerate(header_names):
      try:
        ret[idx + 1] = int(headers.get(hdr_name))
      except ValueError, TypeError:
        ret[idx + 1] = None
        ret[0] = False

    return tuple(ret)


def ensure_dir(filepath) -> str:
  directory = os.path.dirname(filepath)
  if not os.path.exists(directory):
    os.makedirs(directory)
  return filepath
