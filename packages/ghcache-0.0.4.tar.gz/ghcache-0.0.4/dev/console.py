from ghcache import GithubCache

gh = GithubCache()
print("The console is ready")
