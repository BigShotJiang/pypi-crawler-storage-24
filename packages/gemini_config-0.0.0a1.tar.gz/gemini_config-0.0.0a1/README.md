# gemini-config

Tool for statically configuring Gemini CLI
