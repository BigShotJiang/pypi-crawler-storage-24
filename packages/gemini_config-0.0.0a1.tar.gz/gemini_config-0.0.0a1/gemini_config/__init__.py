"""Tool for statically configuring Gemini CLI"""

__version__ = "0.0.0a1"
