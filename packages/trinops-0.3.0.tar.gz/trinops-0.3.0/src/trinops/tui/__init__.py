"""trinops TUI dashboard."""
