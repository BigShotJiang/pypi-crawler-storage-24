@echo off
chcp 65001 >nul
echo ══════════════════════════════════════════════════════
echo   Python SDK 단위 테스트
echo ══════════════════════════════════════════════════════
echo.
cd /d "%~dp0"
call python test/test_basic.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo   ❌ 테스트 실패!
    pause
    exit /b 1
)
pause
