"""Shared types and Pydantic models for Dapp Arena Agent SDK."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ── Enums ──

class AgentCategory(str, Enum):
    EDUCATION = "education"
    COMMERCE = "commerce"
    MEDICAL = "medical"
    LEGAL = "legal"
    SUPPLY = "supply"
    LEGALTECH = "legaltech"
    CUSTOM = "custom"


class AgentStatus(str, Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    MAINTENANCE = "maintenance"


# ── Agent Info ──

class AgentRole(BaseModel):
    name: str
    description: str = ""
    color: str = "#818cf8"


class AgentCapabilities(BaseModel):
    """What this agent can do."""
    category: AgentCategory = AgentCategory.CUSTOM
    roles: list[AgentRole] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    languages: list[str] = Field(default_factory=lambda: ["ko", "en"])
    max_concurrent_tasks: int = 5
    supports_streaming: bool = True


class AgentInfo(BaseModel):
    """Public agent metadata."""
    name: str
    name_ko: str = ""
    description: str = ""
    version: str = "1.0.0"
    capabilities: AgentCapabilities = Field(default_factory=AgentCapabilities)
    price_range: str = "1~5 WL"
    owner_address: str = ""


# ── Chat ──

class ChatRequest(BaseModel):
    message: str
    session_id: str = ""
    context: dict[str, Any] = Field(default_factory=dict)


class ChatResponse(BaseModel):
    message: str
    session_id: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class StreamChunk(BaseModel):
    """A single chunk in a streaming response."""
    token: str = ""
    done: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Quote ──

class QuoteRequest(BaseModel):
    task_description: str
    context: dict[str, Any] = Field(default_factory=dict)


class QuoteResponse(BaseModel):
    task: str
    cost: str  # e.g. "2.5 WL"
    duration: str  # e.g. "약 15분"
    cost_wei: int = 0
    deadline_seconds: int = 900
    details: dict[str, Any] = Field(default_factory=dict)


# ── Health ──

class HealthResponse(BaseModel):
    status: AgentStatus = AgentStatus.ONLINE
    version: str = "1.0.0"
    uptime_seconds: float = 0.0
    agent_name: str = ""
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


# ── A2A ──

class A2AMessage(BaseModel):
    """Agent-to-Agent message."""
    from_agent: str
    to_agent: str
    content: str
    message_type: str = "chat"  # chat, quote, result
    metadata: dict[str, Any] = Field(default_factory=dict)


class A2AResponse(BaseModel):
    content: str
    from_agent: str
    metadata: dict[str, Any] = Field(default_factory=dict)
