"""AgentServer — FastAPI server that exposes a BaseAgent via A2A protocol endpoints."""

from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from .types import (
    ChatRequest,
    ChatResponse,
    HealthResponse,
    QuoteRequest,
    QuoteResponse,
    AgentStatus,
    StreamChunk,
)

if TYPE_CHECKING:
    from .base_agent import BaseAgent


class AgentServer:
    """
    HTTP/WebSocket server that wraps a BaseAgent and exposes
    Dapp Arena A2A protocol endpoints.

    Endpoints:
        GET  /health            — Health check
        GET  /a2a/capabilities  — Agent capabilities
        POST /a2a/chat          — Synchronous chat
        POST /a2a/stream        — Streaming chat (SSE)
        POST /a2a/quote         — Quote generation
        WS   /a2a/ws            — WebSocket chat

    Example:
        from dapparena_basic import BaseAgent, AgentServer

        class MyAgent(BaseAgent):
            async def chat(self, message, context=None):
                return "Hello!"

        server = AgentServer(MyAgent(), port=8080)
        server.run()
    """

    def __init__(
        self,
        agent: BaseAgent,
        host: str = "0.0.0.0",
        port: int = 8080,
        cors_origins: list[str] | None = None,
    ):
        self.agent = agent
        self.host = host
        self.port = port
        self._start_time = time.time()

        self.app = FastAPI(
            title=f"Dapp Arena Agent — {agent.info.name}",
            description=agent.info.description,
            version=agent.info.version,
        )

        # CORS
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins or ["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        self._register_routes()

    def _register_routes(self) -> None:
        app = self.app
        agent = self.agent

        @app.get("/health", response_model=HealthResponse)
        async def health():
            return HealthResponse(
                status=AgentStatus.ONLINE,
                version=agent.info.version,
                uptime_seconds=time.time() - self._start_time,
                agent_name=agent.info.name,
            )

        @app.get("/a2a/capabilities")
        async def capabilities():
            return agent.get_capabilities().model_dump()

        @app.get("/a2a/info")
        async def info():
            return agent.get_info().model_dump()

        @app.post("/a2a/chat", response_model=ChatResponse)
        async def chat(request: ChatRequest):
            response = await agent.chat(
                message=request.message,
                context=request.context,
            )
            return ChatResponse(
                message=response,
                session_id=request.session_id,
            )

        @app.post("/a2a/stream")
        async def stream(request: ChatRequest):
            async def generate():
                async for token in agent.chat_stream(
                    message=request.message,
                    context=request.context,
                ):
                    chunk = StreamChunk(token=token)
                    yield f"data: {chunk.model_dump_json()}\n\n"
                yield f"data: {StreamChunk(done=True).model_dump_json()}\n\n"

            return StreamingResponse(
                generate(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        @app.post("/a2a/quote", response_model=QuoteResponse)
        async def quote(request: QuoteRequest):
            return await agent.get_quote(request)

        @app.websocket("/a2a/ws")
        async def websocket_chat(ws: WebSocket):
            await ws.accept()
            try:
                while True:
                    data = await ws.receive_json()
                    request = ChatRequest(**data)

                    if data.get("stream"):
                        async for token in agent.chat_stream(
                            message=request.message,
                            context=request.context,
                        ):
                            await ws.send_json({"token": token, "done": False})
                        await ws.send_json({"token": "", "done": True})
                    else:
                        response = await agent.chat(
                            message=request.message,
                            context=request.context,
                        )
                        await ws.send_json({"message": response, "done": True})
            except WebSocketDisconnect:
                pass

    def run(self) -> None:
        """Start the agent server."""
        print(f"\nDapp Arena Agent Server")
        print(f"   Agent: {self.agent.info.name}")
        print(f"   URL:   http://{self.host}:{self.port}")
        print(f"   Health: http://{self.host}:{self.port}/health")
        print(f"   Chat:   POST http://{self.host}:{self.port}/a2a/chat")
        print(f"   Stream: POST http://{self.host}:{self.port}/a2a/stream")
        print()
        uvicorn.run(self.app, host=self.host, port=self.port)
