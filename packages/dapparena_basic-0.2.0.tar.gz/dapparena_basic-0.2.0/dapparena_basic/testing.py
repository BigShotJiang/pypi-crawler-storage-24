"""
AgentTestClient — 로컬 테스트 헬퍼

에이전트 서버를 로컬에서 테스트하는 편의 클라이언트입니다.

Example:
    from dapparena_basic.testing import AgentTestClient

    async with AgentTestClient("http://localhost:8080") as client:
        assert await client.assert_health()
        response = await client.assert_chat("안녕하세요")
        print(response)
"""

from __future__ import annotations

import asyncio
from typing import Optional

import httpx


class AgentTestClient:
    """A2A 프로토콜 테스트 클라이언트"""

    def __init__(self, base_url: str = "http://localhost:8080", timeout: float = 15.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "AgentTestClient":
        self._client = httpx.AsyncClient(timeout=self.timeout)
        return self

    async def __aexit__(self, *args) -> None:
        if self._client:
            await self._client.aclose()

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def health(self) -> dict:
        """GET /health"""
        resp = await self.client.get(f"{self.base_url}/health")
        resp.raise_for_status()
        return resp.json()

    async def capabilities(self) -> dict:
        """GET /a2a/capabilities"""
        resp = await self.client.get(f"{self.base_url}/a2a/capabilities")
        resp.raise_for_status()
        return resp.json()

    async def chat(self, message: str, context: dict | None = None) -> dict:
        """POST /a2a/chat"""
        resp = await self.client.post(
            f"{self.base_url}/a2a/chat",
            json={"message": message, "context": context or {}},
        )
        resp.raise_for_status()
        return resp.json()

    async def quote(self, task_description: str, context: dict | None = None) -> dict:
        """POST /a2a/quote"""
        resp = await self.client.post(
            f"{self.base_url}/a2a/quote",
            json={"taskDescription": task_description, "context": context or {}},
        )
        resp.raise_for_status()
        return resp.json()

    # ── Assert 헬퍼 ──

    async def assert_health(self) -> bool:
        """헬스체크가 정상인지 확인합니다."""
        data = await self.health()
        assert "status" in data, "health 응답에 status 필드 없음"
        assert "agentName" in data, "health 응답에 agentName 필드 없음"
        assert data["status"] == "online", f"에이전트 상태가 online이 아님: {data['status']}"
        return True

    async def assert_chat(self, message: str = "테스트 메시지") -> str:
        """채팅 응답이 정상인지 확인하고 메시지를 반환합니다."""
        data = await self.chat(message)
        assert "message" in data, "chat 응답에 message 필드 없음"
        assert len(data["message"]) > 0, "chat 응답이 비어있음"
        return data["message"]

    async def assert_capabilities(self) -> dict:
        """capabilities 응답이 정상인지 확인합니다."""
        data = await self.capabilities()
        assert "name" in data or "category" in data, "capabilities 응답에 name/category 필드 없음"
        return data

    async def assert_quote(self, task: str = "테스트 작업") -> dict:
        """quote 응답이 정상인지 확인합니다."""
        data = await self.quote(task)
        assert "cost" in data, "quote 응답에 cost 필드 없음"
        return data

    async def run_all_tests(self) -> dict[str, bool]:
        """모든 A2A 엔드포인트를 테스트하고 결과를 반환합니다."""
        results = {}

        for name, test_fn in [
            ("health", self.assert_health),
            ("capabilities", self.assert_capabilities),
            ("chat", lambda: self.assert_chat()),
            ("quote", lambda: self.assert_quote()),
        ]:
            try:
                await test_fn()
                results[name] = True
            except Exception as e:
                results[name] = False
                print(f"  ❌ {name}: {e}")

        return results
