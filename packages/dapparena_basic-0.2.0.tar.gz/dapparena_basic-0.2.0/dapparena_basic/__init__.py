"""
Dapp Arena Agent SDK
====================

Build and deploy AI agents on the Dapp Arena marketplace.

Quick Start:
    from dapparena_basic import BaseAgent, AgentServer

    class MyAgent(BaseAgent):
        async def chat(self, message: str, context: dict | None = None) -> str:
            return f"Hello! You said: {message}"

    AgentServer(MyAgent(), port=8080).run()
"""

from .types import (
    AgentCapabilities,
    AgentInfo,
    ChatRequest,
    ChatResponse,
    QuoteRequest,
    QuoteResponse,
    HealthResponse,
    StreamChunk,
)
from .base_agent import BaseAgent
from .server import AgentServer
from .a2a import A2AClient
from .quote import QuoteBuilder
from .toolkit import ToolKit

__version__ = "0.2.0"

__all__ = [
    "BaseAgent",
    "AgentServer",
    "A2AClient",
    "QuoteBuilder",
    "ToolKit",
    "AgentCapabilities",
    "AgentInfo",
    "ChatRequest",
    "ChatResponse",
    "QuoteRequest",
    "QuoteResponse",
    "HealthResponse",
    "StreamChunk",
]
