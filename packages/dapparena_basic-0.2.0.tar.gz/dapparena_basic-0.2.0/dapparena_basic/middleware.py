"""
Middleware — FastAPI 미들웨어 모듈

에이전트 서버에 적용할 수 있는 미들웨어 모음입니다.

Example:
    from dapparena_basic.middleware import RequestLoggerMiddleware, APIKeyMiddleware

    app = FastAPI()
    app.add_middleware(RequestLoggerMiddleware)
    app.add_middleware(APIKeyMiddleware, api_key="my-secret-key")
"""

from __future__ import annotations

import time
import logging
from typing import Optional, Callable
from collections import defaultdict

logger = logging.getLogger("dapparena.middleware")


class RequestLoggerMiddleware:
    """요청/응답 로깅 미들웨어 (ASGI)"""

    def __init__(self, app, log_body: bool = False):
        self.app = app
        self.log_body = log_body

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        method = scope.get("method", "?")
        path = scope.get("path", "?")
        start_time = time.time()

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                status = message.get("status", 0)
                elapsed = (time.time() - start_time) * 1000
                logger.info(f"{method} {path} → {status} ({elapsed:.1f}ms)")
            await send(message)

        await self.app(scope, receive, send_wrapper)


class APIKeyMiddleware:
    """API Key 인증 미들웨어 (ASGI)

    X-API-Key 헤더를 검증합니다.
    /health 엔드포인트는 인증을 건너뜁니다.
    """

    def __init__(self, app, api_key: str, skip_paths: Optional[list[str]] = None):
        self.app = app
        self.api_key = api_key
        self.skip_paths = skip_paths or ["/health", "/docs", "/openapi.json"]

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        path = scope.get("path", "")
        if any(path.startswith(skip) for skip in self.skip_paths):
            return await self.app(scope, receive, send)

        # 헤더에서 API Key 추출
        headers = dict(scope.get("headers", []))
        api_key = headers.get(b"x-api-key", b"").decode("utf-8")

        if api_key != self.api_key:
            await send({
                "type": "http.response.start",
                "status": 401,
                "headers": [[b"content-type", b"application/json"]],
            })
            await send({
                "type": "http.response.body",
                "body": b'{"error": "Unauthorized: Invalid API Key"}',
            })
            return

        await self.app(scope, receive, send)


class RateLimitMiddleware:
    """분당 요청 수 제한 미들웨어 (ASGI)

    IP 기반으로 분당 요청 수를 제한합니다.
    """

    def __init__(self, app, max_requests_per_minute: int = 60):
        self.app = app
        self.max_rpm = max_requests_per_minute
        self._requests: dict[str, list[float]] = defaultdict(list)

    def _get_client_ip(self, scope) -> str:
        """ASGI scope에서 클라이언트 IP를 추출합니다."""
        client = scope.get("client")
        if client:
            return client[0]
        # X-Forwarded-For 헤더 확인
        headers = dict(scope.get("headers", []))
        forwarded = headers.get(b"x-forwarded-for", b"").decode("utf-8")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return "unknown"

    def _is_rate_limited(self, client_ip: str) -> bool:
        now = time.time()
        window_start = now - 60

        # 오래된 요청 제거
        self._requests[client_ip] = [
            t for t in self._requests[client_ip] if t > window_start
        ]

        if len(self._requests[client_ip]) >= self.max_rpm:
            return True

        self._requests[client_ip].append(now)
        return False

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        client_ip = self._get_client_ip(scope)

        if self._is_rate_limited(client_ip):
            await send({
                "type": "http.response.start",
                "status": 429,
                "headers": [
                    [b"content-type", b"application/json"],
                    [b"retry-after", b"60"],
                ],
            })
            await send({
                "type": "http.response.body",
                "body": b'{"error": "Rate limit exceeded. Try again later."}',
            })
            return

        await self.app(scope, receive, send)
