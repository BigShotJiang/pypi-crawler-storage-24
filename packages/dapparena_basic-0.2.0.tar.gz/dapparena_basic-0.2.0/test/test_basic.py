"""
dapparena-basic — 기본 테스트

실행: python test/test_basic.py
"""

import asyncio
import sys
import os

# 패키지 경로 추가
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dapparena_basic import BaseAgent
from dapparena_basic.types import (
    AgentCategory,
    AgentCapabilities,
    AgentInfo,
    ChatRequest,
    QuoteRequest,
    QuoteResponse,
)
from dapparena_basic.quote import QuoteBuilder


# ── 테스트 에이전트 ──
class TestAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="TestAgent",
            name_ko="테스트 에이전트",
            description="Unit test agent",
            version="1.0.0",
        )

    async def chat(self, message: str, context: dict | None = None) -> str:
        return f"Echo: {message}"


# ── 테스트 유틸 ──
passed = 0
failed = 0


def assert_eq(actual, expected, message: str):
    global passed, failed
    if actual == expected:
        print(f"  ✅ {message}")
        passed += 1
    else:
        print(f"  ❌ {message} (expected={expected}, got={actual})")
        failed += 1


def assert_true(condition: bool, message: str):
    global passed, failed
    if condition:
        print(f"  ✅ {message}")
        passed += 1
    else:
        print(f"  ❌ {message}")
        failed += 1


# ── 1. BaseAgent 테스트 ──
print("\n🧪 BaseAgent Tests")
agent = TestAgent()

assert_eq(agent.info.name, "TestAgent", "name이 올바르게 설정됨")
assert_eq(agent.info.name_ko, "테스트 에이전트", "name_ko가 올바르게 설정됨")
assert_eq(agent.info.description, "Unit test agent", "description이 설정됨")
assert_eq(agent.info.version, "1.0.0", "version이 설정됨")
assert_eq(agent.info.price_range, "1~5 WL", "기본 price_range")

# capabilities 테스트
caps = agent.get_capabilities()
assert_true(isinstance(caps, AgentCapabilities), "capabilities는 AgentCapabilities")
assert_eq(caps.supports_streaming, True, "기본 supports_streaming = True")
assert_eq(caps.max_concurrent_tasks, 5, "기본 max_concurrent_tasks = 5")
assert_eq(caps.category, AgentCategory.CUSTOM, "기본 category = CUSTOM")
assert_eq(len(caps.languages), 2, "기본 2개 언어 (ko, en)")

# getInfo 테스트
info = agent.get_info()
assert_true(isinstance(info, AgentInfo), "get_info() → AgentInfo")
assert_eq(info.name, "TestAgent", "get_info().name 정상")


# ── 2. chat() 테스트 ──
print("\n🧪 Chat Tests")


async def test_chat():
    response = await agent.chat("Hello")
    assert_eq(response, "Echo: Hello", "chat() echo 정상 동작")

    response2 = await agent.chat("안녕하세요", context={"lang": "ko"})
    assert_eq(response2, "Echo: 안녕하세요", "chat() 한글 정상 동작")

    # chatStream 기본 구현 테스트
    chunks = []
    async for chunk in agent.chat_stream("Stream test"):
        chunks.append(chunk)
    assert_eq(len(chunks), 1, "chat_stream() 기본: 단일 chunk")
    assert_eq(chunks[0], "Echo: Stream test", "chat_stream() 내용 일치")

    # getQuote 기본 구현 테스트
    quote_req = QuoteRequest(task_description="이미지 생성 작업")
    quote = await agent.get_quote(quote_req)
    assert_true(isinstance(quote, QuoteResponse), "get_quote() → QuoteResponse")
    assert_eq(quote.duration, "약 10분", "기본 duration = 약 10분")
    assert_eq(quote.deadline_seconds, 600, "기본 deadline_seconds = 600")


asyncio.run(test_chat())


# ── 3. QuoteBuilder 테스트 ──
print("\n🧪 QuoteBuilder Tests")
builder = QuoteBuilder(base_rate_wl=2)
quote = builder.build("이미지 생성 작업")

assert_true(isinstance(quote, QuoteResponse), "QuoteBuilder.build() → QuoteResponse")
assert_eq(quote.task, "이미지 생성 작업", "task 내용 일치")
assert_true("WL" in quote.cost, "cost에 WL 포함")
assert_true(isinstance(quote.cost_wei, int), "cost_wei는 정수")
assert_true(quote.cost_wei > 0, "cost_wei > 0")
assert_true(isinstance(quote.duration, str), "duration은 문자열")
assert_eq(quote.deadline_seconds, 720, "deadline = 10분*60 + 120 = 720")

# estimate_minutes 테스트
mins = builder.estimate_minutes(text_length=6000, num_documents=3)
assert_true(mins >= 5, "estimate_minutes >= 5 (base)")
assert_eq(mins, 9, "estimate_minutes(6000, 3) = max(5, 3+6) = 9")


# ── 4. 타입 테스트 ──
print("\n🧪 Type Tests")

# ChatRequest
chat_req = ChatRequest(message="test", session_id="s1")
assert_eq(chat_req.message, "test", "ChatRequest.message 정상")
assert_eq(chat_req.session_id, "s1", "ChatRequest.session_id 정상")

# QuoteRequest
quote_req = QuoteRequest(task_description="Generate image")
assert_eq(quote_req.task_description, "Generate image", "QuoteRequest.task_description 정상")

# AgentCategory enum
assert_true(hasattr(AgentCategory, "CUSTOM"), "AgentCategory.CUSTOM 존재")
assert_true(hasattr(AgentCategory, "EDUCATION"), "AgentCategory.EDUCATION 존재")
assert_true(hasattr(AgentCategory, "COMMERCE"), "AgentCategory.COMMERCE 존재")
assert_eq(AgentCategory.CUSTOM.value, "custom", "CUSTOM = 'custom'")


# ── 결과 출력 ──
print(f"\n{'═' * 40}")
print(f"📊 테스트 결과: {passed} passed, {failed} failed")
print(f"{'═' * 40}\n")

if failed > 0:
    sys.exit(1)
