---
name: "worktree-switch"
description: "List worktrees with status and switch context between them"
short_desc: "List and switch between git worktrees"
version: "1.0.0"
tags: ["git", "worktree", "switch", "list"]
---

# Worktree Switch Skill

Display a status dashboard of all active worktrees and switch working context between them.

## When to Use

- Checking which worktrees exist and their current state
- Switching to a different worktree to continue work there
- Getting an overview of parallel work across multiple worktrees
- Deciding which worktree to merge or clean up

## Workflow

### Phase 1: Discovery

1. **List all worktrees**:

```bash
git worktree list --porcelain
```

2. **Parse output** to extract for each worktree:
   - `worktree <path>` — absolute path
   - `HEAD <sha>` — current commit
   - `branch refs/heads/<name>` — branch name (or `detached` if detached HEAD)

3. **Identify current worktree**: compare `pwd` against listed paths

### Phase 2: Status Dashboard

For each worktree, gather and display:

```bash
# Dirty status
git -C <path> status --porcelain | wc -l

# HEAD commit message
git -C <path> log --oneline -1

# Ahead/behind vs target branch (main/master)
git -C <path> rev-list --left-right --count HEAD...origin/main 2>/dev/null

# Last commit time
git -C <path> log -1 --format="%cr"
```

Present as a table:

```
  # │ Branch          │ Path                        │ Status │ Ahead/Behind │ Last Activity
 ───┼─────────────────┼─────────────────────────────┼────────┼──────────────┼──────────────
 *1 │ main            │ /Users/me/project           │ clean  │ —            │ 2 hours ago
  2 │ feat/auth       │ /Users/me/project-feat-auth │ 3 mod  │ +5 / -2      │ 10 min ago
  3 │ fix/login       │ /Users/me/project-fix-login │ clean  │ +1 / -0      │ 1 hour ago
```

- `*` marks the current worktree
- Status: `clean`, `N mod` (modified files), `N untrk` (untracked)

### Phase 3: Switch (Optional)

If the user wants to switch:

1. **Ask which worktree** to switch to (by number or branch name)
2. **Change directory**: `cd <path>`
3. **Show detailed status** of the target worktree:

```bash
git -C <path> status
git -C <path> log --oneline -5
```

4. Report the switch and current state

### Phase 4: Cleanup Suggestions (Optional)

If any worktrees appear stale (no commits in > 7 days, or already merged into main):

- Suggest cleanup: `git worktree remove <path>`
- Check if branch is merged: `git branch --merged main | grep <branch>`
- **Never auto-remove** — only suggest

## Safety Rules

- **Read-only by default** — this skill only reads state unless the user requests a switch
- Never remove or modify worktrees without explicit user request
- If a worktree path no longer exists on disk, suggest `git worktree prune` to clean up stale entries
- Respect that other Claude Code instances may be actively using other worktrees
