---
name: "worktree-create"
description: "Create a git worktree with optional WIP migration from current branch"
short_desc: "Create worktree with optional WIP migration"
version: "1.0.0"
tags: ["git", "worktree", "create", "branch"]
---

# Worktree Create Skill

Create a new git worktree for isolated work. Supports migrating in-progress (WIP) changes from the current branch into the new worktree.

## When to Use

- Starting a new feature or fix in isolation
- Moving uncommitted WIP changes off the current branch into a dedicated worktree
- Checking out a remote branch in a separate worktree for review or parallel work
- Setting up multiple Claude Code instances to work in parallel

## Workflow

### Phase 1: Context Assessment

1. **Current branch**: `git branch --show-current`
2. **Uncommitted changes**: `git status --porcelain`
   - If output is non-empty, the working tree is dirty — offer WIP migration mode
3. **Existing worktrees**: `git worktree list` — check for naming conflicts
4. **Remote branches** (if user wants to check out an existing branch): `git branch -r`

### Phase 2: Strategy Selection

Present the appropriate strategy based on Phase 1:

| Scenario | Strategy |
|----------|----------|
| Clean state, new feature | `git worktree add <path> -b <branch>` |
| WIP present, user wants to isolate | Stash → create worktree → apply stash in worktree |
| Existing remote branch | `git worktree add <path> <remote>/<branch>` |
| Existing local branch | `git worktree add <path> <branch>` |

Ask the user to confirm:
- **Branch name**: suggest a name based on the task (e.g., `feat/add-auth`, `fix/login-bug`)
- **Worktree path**: default to `../<repo-name>-<branch-name>`
- **Strategy**: which of the above applies

### Phase 3: Execution

#### Clean Create (no WIP)

```bash
# Create worktree with new branch based on current HEAD
git worktree add <path> -b <branch>
```

#### WIP Migration

```bash
# 1. Stash all changes (including untracked)
git stash push -u -m "worktree-create: WIP migration to <branch>"

# 2. Create worktree with new branch
git worktree add <path> -b <branch>

# 3. Apply stash in the new worktree
git -C <path> stash apply stash@{0}

# 4. Drop the stash only after successful apply
git stash drop stash@{0}
```

If stash apply fails (conflicts):
- Report conflicted files
- Leave the stash intact for manual recovery
- **Do NOT drop the stash**

#### Remote Branch Checkout

```bash
git fetch origin <branch>
git worktree add <path> <branch>
```

### Phase 4: Verification

1. Confirm creation: `git worktree list`
2. Verify branch in worktree: `git -C <path> branch --show-current`
3. If WIP migration: verify files are present with `git -C <path> status --porcelain`
4. Report to user:
   - Worktree path
   - Branch name
   - Next steps: `cd <path>` to start working, or use `/worktree-switch`

## Safety Rules

- Never create a worktree on a branch that is already checked out elsewhere — git prevents this, but explain the error clearly if it happens
- Never force-delete existing directories to make room for a worktree
- WIP migration: always verify stash apply succeeded before dropping the stash
- If the user has staged AND unstaged changes, warn that stash preserves the distinction only with `--keep-index` — recommend committing staged changes first
