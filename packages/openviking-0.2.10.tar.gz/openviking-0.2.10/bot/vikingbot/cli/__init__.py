"""CLI module for vikingbot."""
