from __future__ import annotations

import os
from dataclasses import dataclass

DEFAULT_API_URL = "https://api.v2.pd4castr.com.au"
DEFAULT_AUTH0_DOMAIN = "pdview.au.auth0.com"
DEFAULT_AUTH0_AUDIENCE = "https://api.pd4castr.com.au"


@dataclass(frozen=True)
class ClientConfig:
    base_url: str
    auth0_domain: str
    auth0_audience: str


def load_config() -> ClientConfig:
    # allow overrides for advanced usage
    base_url = os.environ.get("PD4CASTR_API_URL", DEFAULT_API_URL)
    audience = os.environ.get("PD4CASTR_AUTH0_AUDIENCE", DEFAULT_AUTH0_AUDIENCE)

    domain = os.environ.get("PD4CASTR_AUTH0_DOMAIN", DEFAULT_AUTH0_DOMAIN)

    return ClientConfig(
        base_url=base_url,
        auth0_domain=domain,
        auth0_audience=audience,
    )
