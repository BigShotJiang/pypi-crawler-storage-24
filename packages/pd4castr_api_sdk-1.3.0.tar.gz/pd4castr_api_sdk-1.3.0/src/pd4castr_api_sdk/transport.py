from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

import httpx


@runtime_checkable
class TransportResponse(Protocol):
    @property
    def status_code(self) -> int: ...
    @property
    def text(self) -> str: ...
    def json(self) -> Any: ...


QueryParams = (
    dict[str, str | int | float | bool | None]
    | list[tuple[str, str | int | float | bool | None]]
    | None
)


class Transport(Protocol):
    def request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        params: QueryParams = None,
        json: Any | None = None,
        data: Any | None = None,
    ) -> TransportResponse: ...

    def close(self) -> None: ...


@dataclass
class HttpxSyncTransport:
    client: httpx.Client

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        params: QueryParams = None,
        json: Any | None = None,
        data: Any | None = None,
    ) -> TransportResponse:
        return self.client.request(
            method,
            url,
            headers=headers,
            params=params,
            json=json,
            data=data,
        )

    def close(self) -> None:
        self.client.close()
