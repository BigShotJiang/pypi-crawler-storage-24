from __future__ import annotations

from typing import Any


class Pd4castrApiError(Exception):
    pass


class AuthenticationError(Pd4castrApiError):
    pass


class NotFoundError(Pd4castrApiError):
    pass


class ApiError(Pd4castrApiError):
    status_code: int
    message: str
    body: Any | None

    def __init__(
        self,
        *,
        status_code: int,
        message: str,
        body: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.body = body

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.status_code}: {self.message}"
