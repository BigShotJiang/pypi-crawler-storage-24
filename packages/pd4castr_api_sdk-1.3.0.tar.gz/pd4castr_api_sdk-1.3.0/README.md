<div align="center">
  <img src="./docs/assets/logo.png" alt="pdView logo" width="92">

  <h1>pd4castr API SDK</h1>

  <p>Official Python client for the pd4castr API</p>

  <p>
    <a href="https://docs.v2.pd4castr.com.au/api-sdk/quick-start">Quick Start</a> •
    <a href="https://docs.v2.pd4castr.com.au/api-sdk/reference">Reference</a>
  </p>
</div>

---

## Installation

> Requires Python >= 3.11

```bash
pip install pd4castr-api-sdk
```

## Quick Start

```python
from pd4castr_api_sdk import Client

with Client(
    client_id="my-client-id",
    client_secret="my-client-secret",
) as client:
    models = client.get_models()
    print(f"Found {len(models)} models")
```

## Documentation

Visit our
[Documentation Site](https://docs.v2.pd4castr.com.au/api-sdk/quick-start) for
usage guides and full API reference.
