"""Keiro admin command — persistent toggle for admin metrics.

Stores the setting in ``~/.keiro/credentials``. Once enabled, all
keiro commands automatically display the admin metrics panel.

Usage::

    keiro admin           # toggle admin mode on/off
    keiro admin --status  # show current state without changing it
"""

from __future__ import annotations

import argparse
import pathlib
import sys
from collections.abc import Callable

from rich.console import Console


def _on_off_label(is_on: bool) -> str:
    """Rich markup for an on/off state indicator."""
    return "[bold]on[/bold]" if is_on else "[dim]off[/dim]"


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser for ``keiro admin``."""
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument(
        "--status",
        action="store_true",
        help="Show current admin mode state without changing it.",
    )
    return parser


def run(args: argparse.Namespace) -> int:
    """Toggle admin mode or show status."""
    from keiro.credentials import (
        is_admin_mode,
        load_credentials,
        save_admin_token,
        set_admin_mode,
    )

    currently_on = is_admin_mode()
    has_token = bool(load_credentials().get("admin_token"))
    console = Console()

    if args.status:
        token = "configured" if has_token else "not configured"
        console.print(f"  Admin mode:  {_on_off_label(currently_on)}")
        console.print(f"  Admin token: {token}")
        return 0

    if not has_token:
        return _flow_enable_with_token(
            console, set_admin_mode, save_admin_token,
        )

    # Token exists — show interactive toggle.
    from keiro.cli.animations import toggle_switch

    new_state = toggle_switch("Admin mode", currently_on)
    if new_state != currently_on:
        set_admin_mode(new_state)
        _print_transition(console, currently_on, new_state)
    else:
        console.print(f"  Admin mode  {_on_off_label(currently_on)} [dim](unchanged)[/dim]")
        console.print()
    return 0


def _flow_enable_with_token(
    console: Console,
    set_admin_mode: Callable[[bool], None],
    save_admin_token: Callable[[str], pathlib.Path],
) -> int:
    """First-time enable: shimmer header, prompt for token, save."""
    from keiro.cli.animations import prompt_with_live_header
    from keiro.cli.setup import _mask_key

    token = prompt_with_live_header(
        console,
        header="Admin",
        body_lines=[
            "  [dim]View detailed metrics: token usage,[/dim]",
            "  [dim]latency, and cost per request.[/dim]",
        ],
        prompt_text="  Admin token: ",
        secret=True,
    ).strip()

    if not token:
        console.print("  Token cannot be empty.")
        return 1

    masked = _mask_key(token)
    sys.stdout.write(
        f"\033[s\033[1A\r  Admin token: {masked}\033[K\033[u",
    )
    sys.stdout.flush()

    save_admin_token(token)
    set_admin_mode(True)

    console.print()
    console.print("  [bold green]Done.[/bold green]")
    console.print("  Saved to ~/.keiro/credentials")
    console.print()
    _print_transition(console, False, True)
    return 0


def _print_transition(
    console: Console,
    was_on: bool,
    now_on: bool,
) -> None:
    """Print the on/off transition line with usage guidance."""
    prev = _on_off_label(was_on)
    curr = _on_off_label(now_on)
    console.print(f"  Admin mode  {prev} → {curr}")
    console.print()
    if now_on:
        console.print("  [dim]Metrics panel will show on every request.[/dim]")
        console.print(
            "  [dim]Toggle in REPL with /admin,"
            " or run[/dim] keiro admin [dim]again.[/dim]",
        )
    else:
        console.print("  [dim]Re-enable anytime with[/dim] keiro admin")
    console.print()
