# pacbot

Security research - T-Mobile Bug Bounty. Dependency confusion PoC for tmobile/pacbot.
