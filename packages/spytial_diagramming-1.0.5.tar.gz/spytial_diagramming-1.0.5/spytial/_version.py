"""Package version source of truth."""

__version__ = "1.0.5"
