"""Sync Gemini client using native Google GenAI SDK"""

import os
import uuid
from google import genai
from google.genai import types as genai_types
from typing import List, Iterator, Optional, Type
from pydantic import BaseModel

from jetflow.action import BaseAction
from jetflow.models.message import Message, TextBlock, ThoughtBlock, ActionBlock
from jetflow.models.events import StreamEvent, MessageStart, MessageEnd, ContentDelta, ThoughtStart, ThoughtDelta, ThoughtEnd, ActionStart, ActionEnd
from jetflow.clients.base import BaseClient, ToolChoice
from jetflow.clients.gemini.utils import build_gemini_config, messages_to_contents, parse_grounding_metadata, ThinkingLevel, RETRYABLE_STREAM_ERRORS


class GeminiClient(BaseClient):
    provider: str = "Gemini"

    def __init__(
        self,
        model: str = "gemini-2.5-flash",
        api_key: str = None,
        thinking_budget: Optional[int] = None,
        thinking_level: Optional[ThinkingLevel] = None,
        max_retries: Optional[int] = None,
    ):
        """Initialize Gemini client.

        Args:
            model: Model name (e.g., "gemini-2.5-flash", "gemini-3-flash-preview")
            api_key: API key (defaults to GEMINI_API_KEY or GOOGLE_API_KEY env var)
            thinking_budget: Token budget for thinking (Gemini 2.5 series only).
                            -1 for dynamic, 0 to disable, or specific token count.
            thinking_level: Thinking level (Gemini 3 series only).
                           Options: "minimal", "low", "medium", "high"
            max_retries: Max retry attempts for transient HTTP errors (429, 5xx).
                        SDK default is 5. Set to 1 to disable retries.
        """
        self.model = model
        self.thinking_budget = thinking_budget
        self.thinking_level = thinking_level
        api_key = api_key or os.environ.get('GEMINI_API_KEY') or os.environ.get('GOOGLE_API_KEY')

        http_options = None
        if max_retries is not None:
            http_options = genai_types.HttpOptions(
                retry_options=genai_types.HttpRetryOptions(attempts=max_retries)
            )
        self.client = genai.Client(api_key=api_key, http_options=http_options)

    def complete(self, messages: List[Message], system_prompt: str, actions: List[BaseAction], allowed_actions: List[BaseAction] = None, tool_choice: ToolChoice = "auto", logger: 'VerboseLogger' = None, enable_caching: bool = False, context_cache_index: Optional[int] = None) -> Message:
        """Non-streaming completion"""
        config = build_gemini_config(
            system_prompt, actions, self.model,
            thinking_budget=self.thinking_budget,
            thinking_level=self.thinking_level,
            allowed_actions=allowed_actions,
            tool_choice=tool_choice
        )
        contents = messages_to_contents(messages)
        response = self.client.models.generate_content(model=self.model, contents=contents, config=config)
        return self._parse_response(response, logger)

    def stream(self, messages: List[Message], system_prompt: str, actions: List[BaseAction], allowed_actions: List[BaseAction] = None, tool_choice: ToolChoice = "auto", logger: 'VerboseLogger' = None, enable_caching: bool = False, context_cache_index: Optional[int] = None) -> Iterator[StreamEvent]:
        """Streaming completion - yields events"""
        config = build_gemini_config(
            system_prompt, actions, self.model,
            thinking_budget=self.thinking_budget,
            thinking_level=self.thinking_level,
            allowed_actions=allowed_actions,
            tool_choice=tool_choice
        )
        contents = messages_to_contents(messages)
        response_stream = self.client.models.generate_content_stream(model=self.model, contents=contents, config=config)
        yield from self._stream_events(response_stream, logger)

    def _parse_response(self, response, logger) -> Message:
        """Parse non-streaming response into Message"""
        completion = Message(role="assistant", status="completed")
        candidate = response.candidates[0]

        def _encode_signature(raw_signature):
            if not raw_signature:
                return None
            import base64
            return base64.b64encode(raw_signature).decode('ascii') if isinstance(raw_signature, bytes) else raw_signature

        for part in candidate.content.parts:
            if part.thought:
                thought_signature = _encode_signature(getattr(part, 'thought_signature', None))
                if part.text:
                    if completion.blocks and isinstance(completion.blocks[-1], ThoughtBlock):
                        if completion.blocks[-1].summaries:
                            completion.blocks[-1].summaries[0] += part.text
                        else:
                            completion.blocks[-1].summaries = [part.text]
                        if thought_signature:
                            completion.blocks[-1].id = thought_signature
                    else:
                        completion.blocks.append(ThoughtBlock(id=thought_signature or "", summaries=[part.text], provider="gemini"))
                    if logger:
                        logger.log_thought(part.text)
                elif thought_signature:
                    for block in reversed(completion.blocks):
                        if isinstance(block, ThoughtBlock):
                            block.id = thought_signature
                            break
                    else:
                        completion.blocks.append(ThoughtBlock(id=thought_signature, summaries=[], provider="gemini"))

            elif part.function_call:
                thought_signature = _encode_signature(getattr(part, 'thought_signature', None))
                if thought_signature:
                    for block in reversed(completion.blocks):
                        if isinstance(block, ThoughtBlock):
                            block.id = thought_signature
                            break
                    else:
                        completion.blocks.append(ThoughtBlock(id=thought_signature, summaries=[], provider="gemini"))

                completion.blocks.append(ActionBlock(id=str(uuid.uuid4()), name=part.function_call.name, status="parsed", body=dict(part.function_call.args)))

            elif part.text:
                if completion.blocks and isinstance(completion.blocks[-1], TextBlock):
                    completion.blocks[-1].text += part.text
                else:
                    completion.blocks.append(TextBlock(text=part.text))
                if logger:
                    logger.log_content(part.text)

        if response.usage_metadata:
            cached = getattr(response.usage_metadata, 'cached_content_token_count', 0) or 0
            completion.cache_read_tokens = cached
            completion.uncached_prompt_tokens = (response.usage_metadata.prompt_token_count or 0) - cached
            completion.completion_tokens = response.usage_metadata.candidates_token_count
            if hasattr(response.usage_metadata, 'thoughts_token_count'):
                completion.thinking_tokens = response.usage_metadata.thoughts_token_count

        search_action = parse_grounding_metadata(candidate)
        if search_action:
            completion.blocks.append(search_action)

        return completion

    def _stream_events(self, stream, logger) -> Iterator[StreamEvent]:
        """Stream response and yield events"""
        completion = Message(role="assistant", status="in_progress")
        yield MessageStart(role="assistant")
        finish_reason = None
        last_candidate = None
        active_thought = None
        active_thought_event_id = None

        def _encode_signature(raw_signature):
            """Normalize Gemini thought signature for JSON-safe storage."""
            if not raw_signature:
                return None
            import base64
            return base64.b64encode(raw_signature).decode('ascii') if isinstance(raw_signature, bytes) else raw_signature

        try:
            for chunk in stream:
                if chunk.candidates:
                    candidate = chunk.candidates[0]
                    last_candidate = candidate
                    if hasattr(candidate, 'finish_reason') and candidate.finish_reason:
                        finish_reason = candidate.finish_reason

                if not chunk.candidates or not chunk.candidates[0].content or not chunk.candidates[0].content.parts:
                    continue

                for part in chunk.candidates[0].content.parts:
                    is_thought = bool(getattr(part, 'thought', False))
                    # In streaming, some terminal thought-signature-only parts can be empty.
                    if not is_thought and active_thought is not None and getattr(part, 'thought_signature', None) and not getattr(part, 'function_call', None) and not getattr(part, 'text', None):
                        is_thought = True

                    if is_thought:
                        if active_thought is None:
                            active_thought_event_id = str(uuid.uuid4())
                            active_thought = ThoughtBlock(id=active_thought_event_id, summaries=[""], provider="gemini")
                            completion.blocks.append(active_thought)
                            yield ThoughtStart(id=active_thought_event_id)

                        thought_signature = _encode_signature(getattr(part, 'thought_signature', None))
                        if thought_signature:
                            active_thought.id = thought_signature

                        if part.text:
                            active_thought.summaries[0] += part.text
                            yield ThoughtDelta(id=active_thought_event_id, delta=part.text)
                            if logger:
                                logger.log_thought(part.text)

                        continue

                    if active_thought is not None:
                        yield ThoughtEnd(id=active_thought_event_id, thought=active_thought.summaries[0])
                        active_thought = None
                        active_thought_event_id = None

                    if part.function_call:
                        thought_signature = _encode_signature(getattr(part, 'thought_signature', None))
                        if thought_signature:
                            for block in reversed(completion.blocks):
                                if isinstance(block, ThoughtBlock):
                                    block.id = thought_signature
                                    break
                            else:
                                completion.blocks.append(ThoughtBlock(id=thought_signature, summaries=[], provider="gemini"))

                        action_id = str(uuid.uuid4())
                        action = ActionBlock(id=action_id, name=part.function_call.name, status="parsed", body=dict(part.function_call.args))
                        completion.blocks.append(action)
                        yield ActionStart(id=action_id, name=action.name)
                        yield ActionEnd(id=action_id, name=action.name, body=action.body)

                    elif part.text:
                        if completion.blocks and isinstance(completion.blocks[-1], TextBlock):
                            completion.blocks[-1].text += part.text
                        else:
                            completion.blocks.append(TextBlock(text=part.text))
                        yield ContentDelta(delta=part.text)
                        if logger:
                            logger.log_content_delta(part.text)

                if chunk.usage_metadata:
                    cached = getattr(chunk.usage_metadata, 'cached_content_token_count', 0) or 0
                    completion.cache_read_tokens = cached
                    completion.uncached_prompt_tokens = (chunk.usage_metadata.prompt_token_count or 0) - cached
                    completion.completion_tokens = chunk.usage_metadata.candidates_token_count
                    if hasattr(chunk.usage_metadata, 'thoughts_token_count'):
                        completion.thinking_tokens = chunk.usage_metadata.thoughts_token_count

        except RETRYABLE_STREAM_ERRORS as e:
            # Stream interrupted (network error, server disconnect, etc.)
            if logger:
                logger.log_error(f"Gemini stream interrupted: {type(e).__name__}: {e}")
            if active_thought is not None:
                yield ThoughtEnd(id=active_thought_event_id, thought=active_thought.summaries[0] if active_thought.summaries else "")
            completion.status = "completed"
            completion.error = True
            yield MessageEnd(message=completion)
            return

        if active_thought is not None:
            yield ThoughtEnd(id=active_thought_event_id, thought=active_thought.summaries[0])

        if finish_reason and str(finish_reason) not in ('FinishReason.STOP', 'STOP') and logger:
            logger.log_warning(f"Gemini stream ended with finish_reason: {finish_reason}")

        if last_candidate:
            search_action = parse_grounding_metadata(last_candidate)
            if search_action:
                completion.blocks.append(search_action)

        completion.status = "completed"
        yield MessageEnd(message=completion)

    def extract(self, schema: Type[BaseModel], query: str, system_prompt: str = "Extract the requested information.") -> BaseModel:
        """Extract structured data using Gemini's native structured output"""
        response = self.client.models.generate_content(
            model=self.model,
            contents=[{"role": "user", "parts": [{"text": f"{system_prompt}\n\n{query}"}]}],
            config={"response_mime_type": "application/json", "response_json_schema": schema.model_json_schema()}
        )
        return schema.model_validate_json(response.text)
