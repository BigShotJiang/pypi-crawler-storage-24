"""Gemini client utilities"""

import base64 as b64
import re
import uuid
from typing import List, Literal, Optional

from google.genai import types

from jetflow.action import BaseAction
from jetflow.clients.base import ToolChoice
from jetflow.models.message import ActionBlock, ImageBlock, Message, TextBlock
from jetflow.models.sources import WebSource
from jetflow.utils.server_tools import extract_server_tools

# Thinking level options for Gemini 3 series
ThinkingLevel = Literal["minimal", "low", "medium", "high"]

# Model prefixes for version detection
GEMINI_3_PREFIXES = ("gemini-3-pro", "gemini-3-flash", "gemini-3.1-pro", "gemini-3.1-flash")
GEMINI_25_PREFIXES = ("gemini-2.5-pro", "gemini-2.5-flash")

# Check if SDK supports thinking_level (requires google-genai >= 1.x)
SDK_SUPPORTS_THINKING_LEVEL = hasattr(types, 'ThinkingLevel')

# Dummy signature for cross-provider compatibility (non-Gemini thoughts)
# See: https://ai.google.dev/gemini-api/docs/thinking#thought-signatures
DUMMY_THOUGHT_SIGNATURE = "context_engineering_is_the_way_to_go"


# Transient stream/network errors that warrant retry
def _build_retryable_errors():
    """Build tuple of retryable stream errors (connection drops, timeouts, etc.)"""
    errors = [ConnectionError, TimeoutError, OSError]
    try:
        from aiohttp.client_exceptions import (
            ClientConnectionError,
            ClientPayloadError,
            ServerDisconnectedError,
        )
        errors.extend([ClientPayloadError, ServerDisconnectedError, ClientConnectionError])
    except ImportError:
        pass
    try:
        from httpx import ConnectError, ReadError, RemoteProtocolError
        errors.extend([ReadError, RemoteProtocolError, ConnectError])
    except ImportError:
        pass
    return tuple(errors)

RETRYABLE_STREAM_ERRORS = _build_retryable_errors()


def parse_grounding_metadata(candidate) -> Optional[ActionBlock]:
    """Parse grounding metadata (Google Search results) into ActionBlock."""
    if not hasattr(candidate, 'grounding_metadata') or not candidate.grounding_metadata:
        return None

    grounding = candidate.grounding_metadata
    results = []

    if hasattr(grounding, 'grounding_chunks') and grounding.grounding_chunks:
        for chunk in grounding.grounding_chunks:
            if hasattr(chunk, 'web') and chunk.web:
                results.append({
                    'url': getattr(chunk.web, 'uri', ''),
                    'title': getattr(chunk.web, 'title', ''),
                })

    if not results:
        return None

    return ActionBlock(
        id=str(uuid.uuid4()),
        name='google_search',
        status='completed',
        body={},
        result={"results": results},
        sources=[WebSource(url=r["url"], title=r["title"]) for r in results],
        server_executed=True
    )


def _is_gemini_3(model: str) -> bool:
    """Check if model is Gemini 3 series"""
    return any(model.startswith(prefix) for prefix in GEMINI_3_PREFIXES)


def _is_gemini_25(model: str) -> bool:
    """Check if model is Gemini 2.5 series"""
    return any(model.startswith(prefix) for prefix in GEMINI_25_PREFIXES)


def build_gemini_config(
    system_prompt: str,
    actions: List[BaseAction],
    model: str,
    thinking_budget: Optional[int] = None,
    thinking_level: Optional[ThinkingLevel] = None,
    allowed_actions: List[BaseAction] = None,
    tool_choice: ToolChoice = "auto",
) -> types.GenerateContentConfig:
    """Build Gemini GenerateContentConfig from parameters

    Thinking configuration:
    - Gemini 3 series: Uses thinking_level ("minimal", "low", "medium", "high")
    - Gemini 2.5 series: Uses thinking_budget (int token count, -1 for dynamic, 0 to disable)

    allowed_actions behavior (takes precedence over tool_choice):
    - None: Use tool_choice logic
    - []: NONE mode (function calling disabled)
    - [action1, action2]: ANY mode with allowed_function_names restricted

    tool_choice behavior:
    - "required": ANY mode (model MUST call a function)
    - "none": NONE mode (model CANNOT call functions)
    - "auto": AUTO mode (model decides)
    """
    tools = None
    tool_config = None

    # Separate server-executed tools from regular actions
    regular_actions, server_tools = extract_server_tools(actions)

    # Build tools list
    tools_list = []

    # Add function declarations for regular actions
    if regular_actions:
        func_declarations = [action_to_function(a) for a in regular_actions]
        tools_list.append(types.Tool(function_declarations=func_declarations))

    # Add server tools (like google_search for WebSearch)
    for server_tool in server_tools:
        schema = getattr(server_tool, 'gemini_schema', None)
        if schema:
            # Handle google_search tool
            if 'google_search' in schema:
                tools_list.append(types.Tool(google_search=types.GoogleSearch()))

    tools = tools_list if tools_list else None

    if regular_actions:

        # Configure function calling mode
        if allowed_actions is not None:
            if len(allowed_actions) == 0:
                # Empty list = disable function calling
                tool_config = types.ToolConfig(
                    function_calling_config=types.FunctionCallingConfig(mode="NONE")
                )
            else:
                # Specific actions = restrict to those functions (and force call)
                allowed_names = [a.name for a in allowed_actions]
                tool_config = types.ToolConfig(
                    function_calling_config=types.FunctionCallingConfig(
                        mode="ANY",
                        allowed_function_names=allowed_names
                    )
                )
        elif tool_choice == "required":
            # Must call a function
            tool_config = types.ToolConfig(
                function_calling_config=types.FunctionCallingConfig(mode="ANY")
            )
        elif tool_choice == "none":
            # Cannot call functions - force text response
            tool_config = types.ToolConfig(
                function_calling_config=types.FunctionCallingConfig(mode="NONE")
            )
        # tool_choice == "auto" defaults to AUTO

    # Build thinking config based on model version
    thinking_config = None
    is_v3 = _is_gemini_3(model)
    is_v25 = _is_gemini_25(model)

    # Validate: cannot set both thinking_budget and thinking_level
    if thinking_budget is not None and thinking_level is not None:
        raise ValueError(
            "Cannot set both thinking_budget and thinking_level. "
            "Use thinking_budget for Gemini 2.5 models, thinking_level for Gemini 3 models."
        )

    # Validate incompatible parameter combinations
    if thinking_level is not None and is_v25:
        raise ValueError(
            f"thinking_level is not supported for Gemini 2.5 models ({model}). "
            "Use thinking_budget instead."
        )
    if thinking_budget is not None and is_v3:
        raise ValueError(
            f"thinking_budget is not supported for Gemini 3 models ({model}). "
            "Use thinking_level instead."
        )

    if is_v3:
        # Gemini 3 uses thinking levels (default to dynamic/"high" if not specified)
        if not SDK_SUPPORTS_THINKING_LEVEL:
            raise ImportError(
                f"Gemini 3 models ({model}) require google-genai >= 1.50.0 for thinking_level support. "
                "Please upgrade: pip install --upgrade google-genai"
            )
        level = thinking_level or "high"
        thinking_config = types.ThinkingConfig(
            include_thoughts=True,
            thinking_level=level
        )
    elif is_v25:
        # Gemini 2.5 uses thinking budgets (default to dynamic/-1 if not specified)
        budget = thinking_budget if thinking_budget is not None else -1
        if budget != 0:
            thinking_config = types.ThinkingConfig(
                include_thoughts=True,
                thinking_budget=budget
            )
    else:
        # Unknown model - prefer thinking_level if SDK supports it (Gemini 3+),
        # otherwise fall back to thinking_budget (Gemini 2.5 compat)
        if SDK_SUPPORTS_THINKING_LEVEL and thinking_budget is None:
            level = thinking_level or "high"
            thinking_config = types.ThinkingConfig(
                include_thoughts=True,
                thinking_level=level
            )
        else:
            budget = thinking_budget if thinking_budget is not None else -1
            if budget != 0:
                thinking_config = types.ThinkingConfig(
                    include_thoughts=True,
                    thinking_budget=budget
                )

    return types.GenerateContentConfig(
        system_instruction=system_prompt,
        tools=tools,
        tool_config=tool_config,
        thinking_config=thinking_config
    )


# Gemini only supports a subset of JSON Schema keywords
GEMINI_SUPPORTED_KEYWORDS = {
    'type', 'format', 'description', 'nullable', 'enum', 'items',
    'properties', 'required', 'anyOf', 'oneOf', 'allOf', 'default'
}


def _clean_schema_for_gemini(schema: dict, defs: dict, is_properties_dict: bool = False) -> dict:
    """Resolve $refs and strip unsupported fields (Gemini doesn't support $ref, additionalProperties, title, etc.)."""
    if isinstance(schema, dict):
        # Handle $ref - inline the definition
        if '$ref' in schema:
            ref_path = schema['$ref']
            if ref_path.startswith('#/$defs/'):
                def_name = ref_path[len('#/$defs/'):]
            elif ref_path.startswith('#/definitions/'):
                def_name = ref_path[len('#/definitions/'):]
            else:
                return schema
            if def_name in defs:
                return _clean_schema_for_gemini(defs[def_name].copy(), defs)
            return schema

        result = {}
        for k, v in schema.items():
            if k in ('$defs', 'definitions'):
                continue  # Skip definitions block

            # If we're inside a "properties" dict, keys are field names (keep all)
            # Otherwise, keys are schema keywords (filter to supported only)
            if not is_properties_dict and k not in GEMINI_SUPPORTED_KEYWORDS:
                continue  # Strip unsupported schema keywords

            # "properties" value is a dict of field names -> schemas
            if k == 'properties':
                result[k] = _clean_schema_for_gemini(v, defs, is_properties_dict=True)
            else:
                result[k] = _clean_schema_for_gemini(v, defs, is_properties_dict=False)
        return result

    elif isinstance(schema, list):
        return [_clean_schema_for_gemini(item, defs) for item in schema]

    return schema


def action_to_function(action: BaseAction) -> dict:
    """Convert BaseAction to Gemini function declaration"""
    schema = action.schema.model_json_schema()
    defs = schema.get('$defs', schema.get('definitions', {}))

    # Clean schema: resolve $refs and strip unsupported fields
    # Pass is_properties_dict=True since we're passing the properties dict directly
    properties = _clean_schema_for_gemini(schema.get('properties', {}), defs, is_properties_dict=True)

    return {
        "name": action.name,
        "description": schema.get('description', ''),
        "parameters": {
            "type": "object",
            "properties": properties,
            "required": schema.get('required', [])
        }
    }


def find_action_name(action_id: str, messages: List[Message]) -> str:
    """Find action name by searching message history for matching action_id"""
    for msg in reversed(messages):
        if msg.role == "assistant" and msg.actions:
            for action in msg.actions:
                if action.id == action_id:
                    return action.name
    return "unknown"


def _safe_display_name(action_name: str, action_id: Optional[str], index: int, media_type: str) -> str:
    """Build a deterministic, ref-safe display name for function-response media parts."""
    ext = media_type.split('/')[-1] if '/' in media_type else 'bin'
    ext = re.sub(r'[^a-zA-Z0-9]+', '', ext) or 'bin'
    safe_action = re.sub(r'[^a-zA-Z0-9_-]+', '_', action_name or 'tool')
    safe_action = safe_action[:32] or 'tool'
    suffix = (action_id or uuid.uuid4().hex)[:12]
    return f"{safe_action}_{suffix}_{index}.{ext}"


def _build_tool_function_response_part(action_name: str, msg: Message, messages: List[Message]) -> dict:
    """Build a Gemini functionResponse part as a raw dict.

    We intentionally use raw dict payloads for functionResponse parts because
    google-genai currently does not camelCase nested keys inside functionResponse
    when serializing typed models, which breaks multimodal refs validation.
    """
    action_name = action_name or find_action_name(msg.action_id, messages)
    response_data = {"result": msg.content}
    multimodal_parts = []

    image_index = 0
    for block in msg.blocks:
        if not isinstance(block, ImageBlock):
            continue

        display_name = _safe_display_name(action_name, msg.action_id, image_index, block.media_type)
        media_ref_key = f"image_{image_index}"

        if block.url:
            # Prefer fileData for URL-backed images (no eager download).
            multimodal_parts.append({
                "fileData": {
                    "fileUri": block.url,
                    "mimeType": block.media_type,
                    "displayName": display_name,
                }
            })
            response_data[media_ref_key] = {"$ref": display_name}
            image_index += 1
            continue

        if block.data:
            multimodal_parts.append({
                "inlineData": {
                    "mimeType": block.media_type,
                    "displayName": display_name,
                    "data": b64.b64decode(block.data),
                }
            })
            response_data[media_ref_key] = {"$ref": display_name}
            image_index += 1

    function_response = {
        "name": action_name,
        "response": response_data,
    }
    if multimodal_parts:
        function_response["parts"] = multimodal_parts

    # Return in snake_case at the outer field because _Part_to_mldev reads
    # "function_response", then forwards nested dict keys untouched.
    return {"function_response": function_response}


def messages_to_contents(messages: List[Message]) -> List[types.Content | dict]:
    """Convert Message objects to Gemini Content format

    Gemini requires function responses to immediately follow function calls,
    and consecutive tool messages must be grouped into a single user turn.
    """
    contents = []
    pending_tool_parts = []  # Accumulate consecutive tool responses

    def flush_tool_parts():
        """Add accumulated tool parts as a single user Content"""
        nonlocal pending_tool_parts
        if pending_tool_parts:
            # Keep tool function responses as raw dicts so nested multimodal
            # functionResponse payloads retain camelCase keys.
            contents.append({"role": "user", "parts": pending_tool_parts})
            pending_tool_parts = []

    for msg in messages:
        if msg.role == "tool":
            # Function response - accumulate for grouping
            action_name = find_action_name(msg.action_id, messages)
            part = _build_tool_function_response_part(action_name, msg, messages)
            pending_tool_parts.append(part)

        elif msg.role == "assistant":
            # Flush any pending tool responses before assistant turn
            flush_tool_parts()

            parts = []

            # Add thought summaries
            if msg.thoughts:
                for thought in msg.thoughts:
                    if thought.summaries:
                        parts.append(types.Part(text=thought.summaries[0]))

            # Add text content
            if msg.content:
                parts.append(types.Part(text=msg.content))

            # Add function calls - signature only on FIRST call
            if msg.actions:
                thought_signature = None
                if msg.thoughts:
                    thought = msg.thoughts[-1]
                    if thought.id:
                        # Use real signature for Gemini, dummy for other providers
                        if thought.provider == "gemini":
                            # Decode base64 back to bytes for Gemini SDK
                            import base64
                            thought_signature = base64.b64decode(thought.id)
                        else:
                            thought_signature = DUMMY_THOUGHT_SIGNATURE

                # If no thoughts but we have actions, use dummy signature
                # This handles cross-provider chains where previous agent had no thinking
                if thought_signature is None:
                    thought_signature = DUMMY_THOUGHT_SIGNATURE

                for i, action in enumerate(msg.actions):
                    fc_part = types.Part.from_function_call(
                        name=action.name,
                        args=action.body
                    )
                    # Only first function call gets the signature
                    if i == 0 and thought_signature:
                        fc_part.thought_signature = thought_signature
                    parts.append(fc_part)

            if parts:
                contents.append(types.Content(role="model", parts=parts))

        else:  # user
            # Flush any pending tool responses before user turn
            flush_tool_parts()

            # Check for image blocks
            if any(isinstance(b, ImageBlock) for b in msg.blocks):
                parts = []
                for block in msg.blocks:
                    if isinstance(block, ImageBlock):
                        if block.data:
                            import base64 as b64
                            parts.append(types.Part.from_bytes(
                                data=b64.b64decode(block.data),
                                mime_type=block.media_type
                            ))
                        elif block.url:
                            import urllib.request
                            with urllib.request.urlopen(block.url) as resp:
                                parts.append(types.Part.from_bytes(
                                    data=resp.read(),
                                    mime_type=block.media_type
                                ))
                    elif isinstance(block, TextBlock):
                        parts.append(types.Part(text=block.text))
                contents.append(types.Content(role="user", parts=parts))
            else:
                contents.append(types.Content(
                    role="user",
                    parts=[types.Part(text=msg.content)]
                ))

    # Flush any remaining tool parts at the end
    flush_tool_parts()

    return contents
