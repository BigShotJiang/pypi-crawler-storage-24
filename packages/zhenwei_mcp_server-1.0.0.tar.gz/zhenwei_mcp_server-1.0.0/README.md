# 诊微 MCP Server — AI 病历质控能力接入

让你的 AI 智能体（Cursor、Claude Desktop、Cline、自定义 Agent 等）具备 **病历质控** 能力。

## 📦 安装

```bash
# 方式一：pip 安装
pip install zhenwei-mcp-server

# 方式二：uvx 直接运行（无需安装）
uvx zhenwei-mcp-server
```

## 🔑 获取 API Key

1. 登录诊微平台 → MCP 服务 → 服务管理
2. 点击「创建 API Key」
3. 保存生成的 Key（格式: `mqc_xxxx`）

## 🔧 配置

### Cursor

在 `~/.cursor/mcp.json` 中添加:

```json
{
  "mcpServers": {
    "zhenwei": {
      "command": "zhenwei-mcp",
      "env": {
        "ZHENWEI_API_URL": "https://your-server.com/api/v1",
        "ZHENWEI_API_KEY": "mqc_your_key_here"
      }
    }
  }
}
```

### Claude Desktop

在 `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) 或 `%APPDATA%\Claude\claude_desktop_config.json` (Windows) 中添加:

```json
{
  "mcpServers": {
    "zhenwei": {
      "command": "zhenwei-mcp",
      "env": {
        "ZHENWEI_API_URL": "https://your-server.com/api/v1",
        "ZHENWEI_API_KEY": "mqc_your_key_here"
      }
    }
  }
}
```

### Cline (VS Code)

在 Cline MCP 设置中添加:

```json
{
  "zhenwei": {
    "command": "zhenwei-mcp",
    "env": {
      "ZHENWEI_API_URL": "https://your-server.com/api/v1",
      "ZHENWEI_API_KEY": "mqc_your_key_here"
    }
  }
}
```

### Python 代码调用

```python
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    server_params = StdioServerParameters(
        command="zhenwei-mcp",
        env={
            "ZHENWEI_API_URL": "https://your-server.com/api/v1",
            "ZHENWEI_API_KEY": "mqc_your_key_here",
        },
    )
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # 查看可用工具
            tools = await session.list_tools()
            print(f"可用工具: {[t.name for t in tools.tools]}")

            # 调用病历质控
            result = await session.call_tool("check_medical_record", {
                "record_text": "主诉：发热伴咳嗽3天\n现病史：...",
                "record_type": "admission",
            })
            print(result)

asyncio.run(main())
```

## 🛠️ 可用工具 (12个)

### 核心质控
| 工具 | 说明 |
|------|------|
| `check_medical_record` | 单病历质控检查（规则引擎 + AI 语义双重检测） |
| `batch_check_records` | 批量质控（最多50份） |
| `get_qc_result` | 获取质控结果 |

### 统计规则
| 工具 | 说明 |
|------|------|
| `get_qc_rules` | 查询质控规则（500+条，覆盖甲乙丙级标准） |
| `get_qc_statistics` | 质控统计数据 |

### AI 辅助
| 工具 | 说明 |
|------|------|
| `get_suggestions` | AI 修改建议（针对缺陷生成示范文本） |
| `check_icd_code` | ICD-10 编码校验和推荐 |
| `check_drg_grouping` | DRG/DIP 分组预测 |
| `check_drug_safety` | 用药安全检查（过敏/配伍/剂量） |

### 数据查询
| 工具 | 说明 |
|------|------|
| `search_knowledge_base` | 知识库搜索（法规/标准/编码） |
| `get_record_detail` | 获取病历详情 |
| `submit_appeal` | 提交缺陷申诉 |

## 💡 使用示例

配置完成后，在 Cursor 或 Claude 中直接对话：

> "帮我检查这份入院记录有没有质量问题：
> 主诉：发热3天
> 现病史：患者3天前出现发热，体温38.5℃，伴咳嗽咳痰...
> 入院诊断：社区获得性肺炎"

AI 会自动调用 `check_medical_record` 工具，返回质控评分和缺陷列表。

> "I25.1 这个 ICD 编码对应什么诊断？"

AI 会调用 `check_icd_code` 进行编码校验。

## 🔒 安全说明

- 所有通信通过 HTTPS 加密
- API Key 支持频率限制和过期时间
- 患者姓名等 PII 字段 AES 加密存储
- MCP 质控创建的临时数据与正式病历隔离

## 📋 环境变量

| 变量 | 必填 | 说明 |
|------|------|------|
| `ZHENWEI_API_URL` | 是 | 诊微平台 API 地址 |
| `ZHENWEI_API_KEY` | 是 | MCP API Key |

## License

MIT
