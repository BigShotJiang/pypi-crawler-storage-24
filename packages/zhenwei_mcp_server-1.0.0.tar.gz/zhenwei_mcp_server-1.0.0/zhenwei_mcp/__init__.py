"""诊微 AI 病历质控 MCP Server."""
__version__ = "1.0.0"
