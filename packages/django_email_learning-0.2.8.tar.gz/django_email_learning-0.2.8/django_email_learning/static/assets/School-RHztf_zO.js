import{c as o,j as s}from"./render-1rZtie3Z.js";const c=o(s.jsx("path",{d:"M5 13.18v4L12 21l7-3.82v-4L12 17zM12 3 1 9l11 6 9-4.91V17h2V9z"}));export{c as S};
//# sourceMappingURL=School-RHztf_zO.js.map
