"""Custom exceptions for flux_config_tui."""


class SSHKeyEncryptedError(Exception):
    """Raised when SSH key requires a passphrase."""


class SSHKeyNotFoundError(Exception):
    """Raised when SSH key file doesn't exist."""


class SSHConnectionError(Exception):
    """Raised when SSH connection fails."""
