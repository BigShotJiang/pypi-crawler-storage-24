"""Node configuration form screen."""

import os
from pathlib import Path

from textual import on, work
from textual.app import ComposeResult
from textual.containers import Container, Grid, Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Static, Switch
from textual_fspicker import FileOpen, Filters

from flux_config_tui.config import NodeConfig, TUIConfig
from flux_config_tui.constants import COMMON_SSH_KEYS, DEFAULT_SSH_PORT


class NodeFormScreen(Screen):
    """Screen for configuring a single SSH node."""

    CSS_PATH = "node_form.tcss"

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(self, node: NodeConfig | None = None) -> None:
        super().__init__()
        self.editing_node = node
        self.selected_key_path: str | None = node.ssh_key_path if node else None

    def compose(self) -> ComposeResult:
        """Compose the node form."""
        with Container(id="node-form-container"):
            yield Static("Node Configuration", classes="form-title")
            with Grid(id="form-grid"):
                # Row 1: Labels
                yield Label("Node name (optional):")
                yield Label("Default:")

                # Row 2: Inputs
                yield Input(placeholder="e.g., Production, banana", id="node-name")
                with Horizontal(id="default-switch-container"):
                    yield Switch(id="is-default-switch", tooltip="Default node")

                # Row 3: SSH Host and Port labels
                yield Label("SSH Host:")
                yield Label("SSH Port:")

                # Row 4: SSH Host and Port inputs
                yield Input(
                    placeholder="e.g., banana, 192.168.1.100", id="ssh-host", classes="ssh-row"
                )
                yield Input(placeholder="22", id="ssh-port", value="22", classes="ssh-row")

                # Row 5: SSH Key label (spans both columns)
                yield Label(id="key-path-label")

            # Key selection buttons
            with Horizontal(id="key-buttons"):
                yield Button("Browse SSH Key", id="browse-key")
                yield Button("Auto-Detect", id="auto-detect-key")

            # Form action buttons
            with Horizontal(id="form-buttons"):
                yield Button("Back", variant="default", id="back")
                yield Button("Save", variant="primary", id="save-node")

            # Error label
            yield Label("", id="error-label", classes="error-text")

    def on_mount(self) -> None:
        """Pre-fill form if editing existing node."""
        if self.editing_node:
            self.query_one("#node-name", Input).value = self.editing_node.name or ""
            self.query_one("#ssh-host", Input).value = self.editing_node.ssh_host
            self.query_one("#ssh-port", Input).value = str(self.editing_node.ssh_port)
            self.query_one("#is-default-switch", Switch).value = self.editing_node.is_default

        self._update_key_label()

    def _update_key_label(self) -> None:
        """Update the key path label."""
        label = self.query_one("#key-path-label", Label)
        if self.selected_key_path:
            label.update(f"SSH Key: {self.selected_key_path}")
        else:
            label.update("SSH Key: Not selected")

    @on(Button.Pressed, "#browse-key")
    def browse_key_clicked(self) -> None:
        """Open file browser for SSH key."""
        self._browse_key()

    @work
    async def _browse_key(self) -> None:
        """Worker to browse for SSH key."""
        ssh_key_filters = Filters(
            ("SSH Keys", lambda p: p.suffix in ("", ".pem", ".key") or p.name.startswith("id_")),
            ("All Files", lambda p: True),
        )

        start_dir = Path.home() / ".ssh"
        if not start_dir.exists():
            start_dir = Path.home()

        selected_file = await self.app.push_screen_wait(
            FileOpen(
                location=start_dir,
                filters=ssh_key_filters,
            )
        )

        if selected_file:
            selected_path = (
                Path(selected_file) if not isinstance(selected_file, Path) else selected_file
            )
            self.selected_key_path = str(selected_path)
            self._update_key_label()
            self._show_error("")  # Clear error

    @on(Button.Pressed, "#auto-detect-key")
    def auto_detect_clicked(self) -> None:
        """Auto-detect SSH key from common locations."""
        detected = self._detect_ssh_key()
        if detected:
            self.selected_key_path = detected
            self._update_key_label()
            self._show_error("")  # Clear error
        else:
            self._show_error("No SSH key found in common locations")

    def _detect_ssh_key(self) -> str | None:
        """Detect SSH key from common paths."""
        for key_path in COMMON_SSH_KEYS:
            expanded = os.path.expanduser(key_path)
            if Path(expanded).exists():
                return expanded
        return None

    @on(Button.Pressed, "#save-node")
    def save_node_clicked(self) -> None:
        """Save node configuration."""
        # Collect form data
        name = self.query_one("#node-name", Input).value.strip()
        ssh_host = self.query_one("#ssh-host", Input).value.strip()
        ssh_port_str = self.query_one("#ssh-port", Input).value.strip()
        is_default = self.query_one("#is-default-switch", Switch).value

        # Validate (name is optional, ssh_host is required)
        if not ssh_host:
            self._show_error("SSH host is required")
            return
        if not self.selected_key_path:
            self._show_error("SSH key must be selected")
            return
        if not Path(self.selected_key_path).exists():
            self._show_error(f"SSH key not found: {self.selected_key_path}")
            return

        try:
            ssh_port = int(ssh_port_str) if ssh_port_str else DEFAULT_SSH_PORT
        except ValueError:
            self._show_error("SSH port must be a number")
            return

        # Create node config (ssh_host is the unique key)
        node = NodeConfig(
            ssh_host=ssh_host,
            name=name,  # Optional display name
            ssh_port=ssh_port,
            ssh_key_path=self.selected_key_path,
            is_default=is_default,
        )

        # Save to config
        TUIConfig.add_or_update_node(node)

        # Dismiss with the new node
        self.dismiss(node)

    @on(Button.Pressed, "#back")
    def back_clicked(self) -> None:
        """Go back without saving."""
        self.dismiss(None)

    def action_cancel(self) -> None:
        """Handle escape key."""
        self.back_clicked()

    def _show_error(self, message: str) -> None:
        """Show error message."""
        self.query_one("#error-label", Label).update(message)
