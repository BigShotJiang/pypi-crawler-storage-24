"""Password prompt screen for encrypted SSH keys."""

from textual import on
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Static


class PasswordPromptScreen(Screen):
    """Modal screen for entering SSH key password."""

    CSS = """
    PasswordPromptScreen {
        align: center middle;
    }

    #password-container {
        width: 60;
        height: auto;
        border: solid $primary;
        padding: 2;
        background: $surface;
    }

    .prompt-title {
        text-align: center;
        text-style: bold;
        margin-bottom: 1;
    }

    .prompt-text {
        text-align: center;
        margin-bottom: 2;
    }

    #password-input {
        margin-bottom: 2;
    }

    #password-buttons {
        height: auto;
        align: center middle;
    }

    #password-buttons > Button {
        margin: 0 1;
    }
    """

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(self, key_path: str) -> None:
        super().__init__()
        self.key_path = key_path

    def compose(self) -> ComposeResult:
        """Compose the password prompt."""
        with Container(id="password-container"):
            yield Static("SSH Key Password Required", classes="prompt-title")
            yield Static(
                f"The SSH key is encrypted and requires a passphrase:\n{self.key_path}",
                classes="prompt-text",
            )
            yield Input(
                placeholder="Enter passphrase",
                password=True,
                id="password-input",
            )
            with Horizontal(id="password-buttons"):
                yield Button("Cancel", variant="error", id="cancel")
                yield Button("Connect", variant="primary", id="submit")

    def on_mount(self) -> None:
        """Focus password input on mount."""
        self.query_one("#password-input", Input).focus()

    @on(Button.Pressed, "#submit")
    def submit_clicked(self) -> None:
        """Submit password."""
        password = self.query_one("#password-input", Input).value
        if password:
            self.dismiss(password)
        else:
            self.dismiss(None)

    @on(Input.Submitted, "#password-input")
    def password_submitted(self) -> None:
        """Handle enter key in password input."""
        self.submit_clicked()

    @on(Button.Pressed, "#cancel")
    def cancel_clicked(self) -> None:
        """Cancel password entry."""
        self.dismiss(None)

    def action_cancel(self) -> None:
        """Handle escape key."""
        self.cancel_clicked()
