"""Shell login screen for PAM authentication."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from textual import on, work
from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Static

from flux_config_shared.protocol import Event, EventType
from flux_config_tui.widgets.spinner import Spinner

if TYPE_CHECKING:
    from flux_config_tui.client_app import FluxConfigApp

logger = logging.getLogger(__name__)


class ShellLoginScreen(Screen):
    """Modal screen for shell authentication via PAM."""

    def __init__(self) -> None:
        super().__init__()
        self._authenticating = False
        self._output_buffer: list[str] = []
        self._buffer_handler = self._buffer_shell_output

    async def _buffer_shell_output(self, event: Event) -> None:
        """Buffer shell output events until ShellScreen is ready."""
        data = event.data.get("data", "")
        if data:
            self._output_buffer.append(data)
            logger.info(f"Buffered {len(data)} chars of shell output")

    CSS = """
    ShellLoginScreen {
        align: center middle;
    }

    #login-container {
        width: 60;
        height: auto;
        border: solid $primary;
        padding: 2;
        background: $surface;
    }

    .login-title {
        text-align: center;
        text-style: bold;
        margin-bottom: 1;
    }

    .login-subtitle {
        text-align: center;
        color: $text-muted;
        margin-bottom: 2;
    }

    .input-label {
        margin-bottom: 0;
    }

    #username-input {
        margin-bottom: 1;
    }

    #password-input {
        margin-bottom: 1;
    }

    #error-label {
        color: $error;
        text-align: center;
        margin-bottom: 1;
        display: none;
    }

    #error-label.visible {
        display: block;
    }

    #login-buttons {
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    #login-buttons > Button {
        margin: 0 1;
    }

    #login-spinner {
        width: 1;
        height: 1;
        display: none;
        margin-left: 1;
    }

    #login-spinner.visible {
        display: block;
    }
    """

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def compose(self) -> ComposeResult:
        """Compose the login screen."""
        with Container(id="login-container"):
            yield Static("Shell Access", classes="login-title")
            yield Static(
                "Enter system credentials to open a shell session",
                classes="login-subtitle",
            )
            yield Label("Username:", classes="input-label")
            yield Input(
                value="console",
                id="username-input",
            )
            yield Label("Password:", classes="input-label")
            yield Input(
                placeholder="Enter password",
                password=True,
                id="password-input",
            )
            yield Label("", id="error-label")
            with Horizontal(id="login-buttons"):
                yield Button("Cancel", variant="error", id="cancel")
                yield Button("Login", variant="primary", id="login")
                yield Spinner("dots", id="login-spinner")

    def on_mount(self) -> None:
        """Focus password input on mount since username is pre-populated."""
        self.query_one("#password-input", Input).focus()

    def _show_error(self, message: str) -> None:
        """Show error message."""
        error_label = self.query_one("#error-label", Label)
        error_label.update(message)
        error_label.add_class("visible")

    def _hide_error(self) -> None:
        """Hide error message."""
        error_label = self.query_one("#error-label", Label)
        error_label.remove_class("visible")

    def _set_loading(self, loading: bool) -> None:
        """Set loading state for buttons."""
        login_button = self.query_one("#login", Button)
        spinner = self.query_one("#login-spinner", Spinner)

        if loading:
            login_button.disabled = True
            spinner.add_class("visible")
        else:
            login_button.disabled = False
            spinner.remove_class("visible")

    @on(Button.Pressed, "#login")
    def login_clicked(self) -> None:
        """Handle login button click."""
        if self._authenticating:
            return
        self._do_login()

    @on(Input.Submitted)
    def input_submitted(self, event: Input.Submitted) -> None:
        """Handle enter key in input fields."""
        if self._authenticating:
            return

        if event.input.id == "username-input":
            # Move to password field
            self.query_one("#password-input", Input).focus()
        elif event.input.id == "password-input":
            # Submit login
            self._do_login()

    @work(name="shell_login", exclusive=True)
    async def _do_login(self) -> None:
        """Perform authentication and open shell session."""
        if self._authenticating:
            return

        self._authenticating = True
        self._hide_error()
        self._set_loading(True)

        username = self.query_one("#username-input", Input).value.strip()
        password = self.query_one("#password-input", Input).value

        if not username:
            self._show_error("Username is required")
            self._set_loading(False)
            self._authenticating = False
            return

        if not password:
            self._show_error("Password is required")
            self._set_loading(False)
            self._authenticating = False
            return

        app: FluxConfigApp = self.app  # type: ignore[assignment]

        try:
            self._output_buffer.clear()
            app.backend_client.on_event(EventType.SHELL_OUTPUT, self._buffer_handler)
            await app.backend_client.subscribe(["shell"])

            # Authenticate and open session atomically
            response = await app.backend_client.call_method(
                "shell.authenticate_and_open",
                {"username": username, "password": password},
            )
            # NOTE: Don't unregister buffer handler here - output arrives async
            # ShellScreen will unregister it after processing the buffer

            if response.error:
                self._show_error(f"RPC error: {response.error.message}")
                self._set_loading(False)
                self._authenticating = False
                return

            result = response.result or {}
            if not result.get("success"):
                error = result.get("error", "Authentication or session creation failed")
                self._show_error(error)
                self._set_loading(False)
                self._authenticating = False
                return

            session_id = result.get("session_id")
            if not session_id:
                self._show_error("No session ID returned")
                self._set_loading(False)
                self._authenticating = False
                return

            logger.info(f"Shell session opened: {session_id}")

            # Dismiss and pass session info + buffer reference + handler
            # Don't copy buffer - pass reference so it keeps accumulating
            self.dismiss({
                "session_id": session_id,
                "username": username,
                "output_buffer": self._output_buffer,
                "buffer_handler": self._buffer_handler,
            })

        except Exception as e:
            logger.error(f"Error during shell login: {e}", exc_info=True)
            self._show_error(f"Error: {e}")
            self._set_loading(False)
            self._authenticating = False

    @on(Button.Pressed, "#cancel")
    def cancel_clicked(self) -> None:
        """Cancel login."""
        self.dismiss(None)

    def action_cancel(self) -> None:
        """Handle escape key."""
        self.cancel_clicked()
