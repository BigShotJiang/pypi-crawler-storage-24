"""Shell screen for interactive terminal display."""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Any

import pyte
from pyte.screens import Char
from rich.color import ColorParseError
from rich.segment import Segment
from rich.style import Style
from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.events import Key, Resize
from textual.geometry import Size
from textual.screen import Screen
from textual.scroll_view import ScrollView
from textual.strip import Strip
from textual.widgets import Static

from flux_config_shared.protocol import Event, EventType

if TYPE_CHECKING:
    from flux_config_tui.client_app import FluxConfigApp

logger = logging.getLogger(__name__)


class TerminalWidget(ScrollView, can_focus=True):
    """Terminal display widget using pyte for emulation with scrollback."""

    HISTORY_SIZE = 1000

    DEFAULT_CSS = """
    TerminalWidget {
        height: 1fr;
        background: $surface-darken-2;
        margin-top: 1;
        overflow: hidden auto;
    }
    """

    def __init__(
        self,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(name=name, id=id, classes=classes)
        self.ncol = 80
        self.nrow = 24
        self._screen = pyte.HistoryScreen(
            self.ncol, self.nrow, history=self.HISTORY_SIZE
        )
        self._stream = pyte.Stream(self._screen)
        self._history_cache: list[dict] = []

    def on_resize(self, event: Resize) -> None:
        """Sync pyte screen size with widget size."""
        width = event.size.width
        height = event.size.height
        if width > 0 and height > 0 and (width != self.ncol or height != self.nrow):
            self._screen.resize(height, width)
            self.ncol = width
            self.nrow = height
            self._update_virtual_size()

    def feed(self, data: str) -> None:
        """Feed data to the terminal emulator and refresh display."""
        try:
            self._stream.feed(data)
        except TypeError as e:
            logger.warning(f"pyte feed error: {e}")

        self._cache_history()
        self._update_virtual_size()
        self.scroll_end(animate=False)
        self.refresh()

    def _cache_history(self) -> None:
        """Cache history lines for efficient rendering."""
        self._history_cache = list(self._screen.history.top)

    def _update_virtual_size(self) -> None:
        """Update virtual size to reflect total scrollable content."""
        total_lines = len(self._history_cache) + self._screen.lines
        self.virtual_size = Size(self.ncol, total_lines)

    def render_line(self, y: int) -> Strip:
        """Render a single line for the Line API."""
        scroll_x, scroll_y = self.scroll_offset
        line_idx = scroll_y + y
        history_len = len(self._history_cache)
        total = history_len + self._screen.lines
        width = self.size.width

        if line_idx < 0 or line_idx >= total:
            return Strip.blank(width, self.rich_style)

        if line_idx < history_len:
            return self._render_history_line(line_idx, width)
        else:
            screen_y = line_idx - history_len
            return self._render_screen_line(screen_y, width)

    def _render_history_line(self, idx: int, width: int) -> Strip:
        """Render a line from history."""
        hist_line = self._history_cache[idx]
        segments: list[Segment] = []

        for x in range(min(self._screen.columns, width)):
            if x in hist_line:
                char: Char = hist_line[x]
                style = self._char_to_style(char)
                segments.append(Segment(char.data, style))
            else:
                segments.append(Segment(" "))

        if len(segments) < width:
            segments.append(Segment(" " * (width - len(segments))))

        return Strip(segments)

    def _render_screen_line(self, y: int, width: int) -> Strip:
        """Render a line from the current screen buffer."""
        if y >= self._screen.lines:
            return Strip.blank(width, self.rich_style)

        line = self._screen.buffer[y]
        cursor_x = self._screen.cursor.x
        cursor_y = self._screen.cursor.y
        cursor_hidden = getattr(self._screen.cursor, 'hidden', False)
        segments: list[Segment] = []

        for x in range(min(self._screen.columns, width)):
            char: Char = line[x]
            style = self._char_to_style(char)

            if x == cursor_x and y == cursor_y and not cursor_hidden:
                style = Style(color="black", bgcolor="white")

            segments.append(Segment(char.data, style))

        if len(segments) < width:
            segments.append(Segment(" " * (width - len(segments))))

        return Strip(segments)

    def _char_to_style(self, char: Char) -> Style | None:
        """Convert pyte Char attributes to Rich Style."""
        fg = self._fix_color(char.fg)
        bg = self._fix_color(char.bg)

        if fg == "default":
            fg = None
        if bg == "default":
            bg = None

        try:
            return Style(
                color=fg,
                bgcolor=bg,
                bold=char.bold,
                italic=char.italics,
                underline=char.underscore,
                strike=char.strikethrough,
                reverse=char.reverse,
            )
        except ColorParseError as e:
            logger.warning(f"Color parse error: {e}")
            return None

    def _fix_color(self, color: str) -> str:
        """Fix color names for Rich compatibility."""
        if color == "brown":
            return "yellow"
        if color == "brightblack":
            return "#808080"
        if re.match(r"[0-9a-f]{6}", color, re.IGNORECASE):
            return f"#{color}"
        return color



class ShellScreen(Screen):
    """Screen for interactive shell terminal."""

    CSS = """
    ShellScreen {
        background: $surface-darken-1;
    }

    #shell-header {
        height: 1;
        background: $primary;
        color: $text;
        padding: 0 1;
    }

    #shell-container {
        height: 1fr;
        padding: 0;
    }

    #shell-footer {
        height: 1;
        background: $surface;
        color: $text-muted;
        padding: 0 1;
    }

    #shell-footer.--disconnected {
        color: red;
    }
    """

    BINDINGS = [
        Binding("ctrl+d", "close_shell", "Exit Shell", show=True),
        Binding("escape", "close_shell", "Exit Shell", show=False),
    ]

    def __init__(
        self,
        session_id: str,
        username: str,
        output_buffer: list[str] | None = None,
        buffer_handler: Any | None = None,
    ) -> None:
        super().__init__()
        self.session_id = session_id
        self.username = username
        self._session_closed = False
        self._input_buffer: list[str] = []
        self._input_flush_scheduled = False
        self._pending_output_buffer = output_buffer
        self._pending_buffer_handler = buffer_handler
        self._output_handler = self._handle_shell_output
        self._session_closed_handler = self._handle_shell_closed
        self._error_handler = self._handle_shell_error

    def compose(self) -> ComposeResult:
        """Compose the shell screen."""
        yield Static(
            f"Shell Session: {self.username}@flux | Timeout: 20min idle | Press Ctrl+D or Escape to exit",
            id="shell-header"
        )
        with Container(id="shell-container"):
            yield TerminalWidget(id="shell-output")
        yield Static("Connected", id="shell-footer")

    async def on_mount(self) -> None:
        """Register event handlers when screen mounts."""
        app: FluxConfigApp = self.app  # type: ignore[assignment]

        app.backend_client.on_event(EventType.SHELL_OUTPUT, self._output_handler)
        app.backend_client.on_event(EventType.SHELL_CLOSED, self._session_closed_handler)
        app.backend_client.on_event(EventType.SHELL_ERROR, self._error_handler)

        try:
            await app.backend_client.subscribe(["shell"])
            logger.info("Subscribed to shell topic")
        except Exception as e:
            logger.error(f"Failed to subscribe to shell topic: {e}", exc_info=True)

        if self._pending_buffer_handler:
            app.backend_client.off_event(EventType.SHELL_OUTPUT, self._pending_buffer_handler)

        if self._pending_output_buffer:
            terminal = self.query_one("#shell-output", TerminalWidget)
            for data in self._pending_output_buffer:
                terminal.feed(data)
            logger.info(f"Processed {len(self._pending_output_buffer)} buffered output chunks")
            self._pending_output_buffer = None

        self._pending_buffer_handler = None

        self.query_one("#shell-output", TerminalWidget).focus()
        logger.info(f"Shell screen mounted for session {self.session_id}")

    async def on_unmount(self) -> None:
        """Cleanup when screen unmounts."""
        app: FluxConfigApp = self.app  # type: ignore[assignment]

        app.backend_client.off_event(EventType.SHELL_OUTPUT, self._output_handler)
        app.backend_client.off_event(EventType.SHELL_CLOSED, self._session_closed_handler)
        app.backend_client.off_event(EventType.SHELL_ERROR, self._error_handler)

        if not self._session_closed:
            await self._close_session()

        try:
            await app.backend_client.unsubscribe(["shell"])
            logger.info("Unsubscribed from shell topic")
        except Exception as e:
            logger.error(f"Failed to unsubscribe from shell topic: {e}", exc_info=True)

    async def _handle_shell_output(self, event: Event) -> None:
        """Handle SHELL_OUTPUT events from daemon."""
        try:
            event_session_id = event.data.get("session_id")
            if event_session_id != self.session_id:
                return

            data = event.data.get("data", "")
            if data:
                terminal = self.query_one("#shell-output", TerminalWidget)
                terminal.feed(data)

        except Exception as e:
            logger.error(f"Error handling shell output: {e}", exc_info=True)

    async def _handle_shell_closed(self, event: Event) -> None:
        """Handle SHELL_CLOSED events from daemon."""
        try:
            event_session_id = event.data.get("session_id")
            if event_session_id != self.session_id:
                return

            reason = event.data.get("reason", "")
            logger.info(f"Shell session {self.session_id} closed by daemon (reason: {reason})")

            self._session_closed = True

            footer = self.query_one("#shell-footer", Static)
            footer.add_class("--disconnected")
            if reason == "pty_closed":
                footer.update("Shell exited")
                self.set_timer(1.5, self._auto_dismiss)
            elif reason == "timeout":
                footer.update("Disconnected (idle timeout) - Press any key to close")
            else:
                footer.update("Disconnected - Press any key to close")

        except Exception as e:
            logger.error(f"Error handling shell closed: {e}", exc_info=True)

    async def _handle_shell_error(self, event: Event) -> None:
        """Handle SHELL_ERROR events from daemon."""
        try:
            event_session_id = event.data.get("session_id")
            if event_session_id != self.session_id:
                return

            error = event.data.get("error", "Unknown error")
            logger.error(f"Shell error for session {self.session_id}: {error}")

            footer = self.query_one("#shell-footer", Static)
            footer.update(f"Error: {error}")

        except Exception as e:
            logger.error(f"Error handling shell error: {e}", exc_info=True)

    async def on_key(self, event: Key) -> None:
        """Handle key events and send to shell."""
        if self._session_closed:
            self.dismiss()
            return

        key_map = {
            "enter": "\r",
            "tab": "\t",
            "backspace": "\x7f",
            "delete": "\x1b[3~",
            "up": "\x1b[A",
            "down": "\x1b[B",
            "right": "\x1b[C",
            "left": "\x1b[D",
            "home": "\x1b[H",
            "end": "\x1b[F",
            "pageup": "\x1b[5~",
            "pagedown": "\x1b[6~",
            "insert": "\x1b[2~",
        }

        if event.key.startswith("ctrl+"):
            key_char = event.key[5:]
            if len(key_char) == 1:
                ctrl_code = ord(key_char.lower()) - ord('a') + 1
                if 1 <= ctrl_code <= 26:
                    char = chr(ctrl_code)
                    self._buffer_input(char)
                    event.prevent_default()
                    return

        if event.key in key_map:
            self._buffer_input(key_map[event.key])
            event.prevent_default()
            return

        if event.character and len(event.character) == 1:
            self._buffer_input(event.character)
            event.prevent_default()
            return

    def _buffer_input(self, data: str) -> None:
        """Buffer input data and schedule flush."""
        self._input_buffer.append(data)

        if not self._input_flush_scheduled:
            self._input_flush_scheduled = True
            self._schedule_flush_input()

    @work(name="flush_input", exclusive=True)
    async def _schedule_flush_input(self) -> None:
        """Flush buffered input immediately to daemon."""
        self._input_flush_scheduled = False

        if not self._input_buffer:
            return

        data = ''.join(self._input_buffer)
        self._input_buffer.clear()

        self._send_input(data)

    @work(name="shell_input", thread=False)
    async def _send_input(self, data: str) -> None:
        """Send input data to daemon."""
        if self._session_closed:
            return

        app: FluxConfigApp = self.app  # type: ignore[assignment]

        try:
            response = await app.backend_client.call_method(
                "shell.input",
                {"session_id": self.session_id, "data": data},
            )

            if not response.result.get("success"):
                error = response.result.get("error", "Unknown error")
                logger.warning(f"Failed to send shell input: {error}")

        except Exception as e:
            logger.error(f"Error sending shell input: {e}", exc_info=True)

    def _auto_dismiss(self) -> None:
        """Timer callback wrapper — dismiss() returns AwaitComplete which
        Textual's invoke() would await, triggering a ScreenError."""
        self.dismiss()

    def action_close_shell(self) -> None:
        """Handle close shell action (Ctrl+D or Escape)."""
        if self._session_closed:
            self.dismiss()
            return
        self._close_shell()

    @work(name="close_shell", exclusive=True)
    async def _close_shell(self) -> None:
        """Close the shell session."""
        if self._session_closed:
            self.dismiss()
            return

        await self._close_session()
        self.dismiss()

    async def _close_session(self) -> None:
        """Send close session request to daemon."""
        if self._session_closed:
            return

        self._session_closed = True
        app: FluxConfigApp = self.app  # type: ignore[assignment]

        try:
            await app.backend_client.call_method(
                "shell.close",
                {"session_id": self.session_id},
            )
            logger.info(f"Closed shell session {self.session_id}")
        except Exception as e:
            logger.error(f"Error closing shell session: {e}", exc_info=True)
