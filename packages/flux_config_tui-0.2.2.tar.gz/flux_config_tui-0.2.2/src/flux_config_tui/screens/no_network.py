"""No network screens - displayed when daemon has no internet connectivity."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Center, Container, Horizontal, Middle, Vertical
from textual.message import Message
from textual.screen import ModalScreen, Screen
from textual.widgets import Button, Label, Static


class NoNetworkScreen(Screen):
    """Full screen displayed during initial boot when there is no connectivity."""

    class NetworkSettingsRequested(Message):
        """Message emitted when user requests network settings."""

    def compose(self) -> ComposeResult:
        """Compose the screen."""
        with Center():
            with Middle():
                with Vertical(id="no-network-container"):
                    yield Static(
                        "No network connectivity available."
                        " Click the button below to configure network settings.",
                        id="no-network-message",
                    )
                    with Center():
                        yield Button("Network Settings", id="network-settings-btn")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        if event.button.id == "network-settings-btn":
            self.post_message(self.NetworkSettingsRequested())


class NoNetworkModal(ModalScreen[None]):
    """Small modal shown post-install when connectivity is lost on boot."""

    class NetworkSettingsRequested(Message):
        """Message emitted when user requests network settings."""

    def compose(self) -> ComposeResult:
        """Compose the modal."""
        with Container(id="no-network-modal-container"):
            yield Label(
                "No network connectivity detected.\n"
                "Upstream connectivity issue or network reconfiguration required.",
                id="no-network-modal-message",
            )
            with Horizontal(id="no-network-modal-buttons"):
                yield Button("Network Settings", id="network-settings-btn")
                yield Button("Dismiss", id="dismiss-btn")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        if event.button.id == "network-settings-btn":
            self.post_message(self.NetworkSettingsRequested())
        elif event.button.id == "dismiss-btn":
            self.dismiss()
