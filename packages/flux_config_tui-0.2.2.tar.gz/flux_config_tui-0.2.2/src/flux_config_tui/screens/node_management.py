"""Node management screen for Settings menu."""

from textual import on
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Label, ListItem, ListView, Static

from flux_config_tui.config import NodeConfig, TUIConfig


class NodeManagementScreen(Screen):
    """Screen for managing SSH nodes from Settings."""

    CSS_PATH = "node_management.tcss"

    BINDINGS = [
        ("escape", "dismiss", "Back"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.selected_node_host: str | None = None

    def compose(self) -> ComposeResult:
        """Compose node management UI."""
        with Container(id="node-mgmt-container"):
            yield Static("Manage SSH Nodes", classes="screen-title")
            yield ListView(id="node-list")
            with Horizontal(id="mgmt-buttons"):
                yield Button("Add Node", variant="primary", id="add-node")
                yield Button("Back", variant="default", id="back")

    def on_mount(self) -> None:
        """Load and display nodes."""
        self._refresh_list()

    def _refresh_list(self) -> None:
        """Refresh node list."""
        nodes = TUIConfig.get_nodes()
        node_list = self.query_one("#node-list", ListView)
        node_list.clear()

        for node in nodes:
            # Use name if provided, otherwise use hostname
            display_name = node.name if node.name else node.ssh_host
            label = f"{display_name} ({node.ssh_user}@{node.ssh_host}:{node.ssh_port})"
            if node.is_default:
                label += " [DEFAULT]"
            # Use ssh_host as unique ID
            node_list.append(ListItem(Label(label), id=f"node-{node.ssh_host}"))

    @on(ListView.Selected, "#node-list")
    def node_list_selected(self, event: ListView.Selected) -> None:
        """Track selected node."""
        self.selected_node_host = event.item.id.replace("node-", "")

    @on(Button.Pressed, "#add-node")
    async def add_node(self) -> None:
        """Add a new node."""
        from flux_config_tui.screens.node_form import NodeFormScreen

        # Push node form screen and wait for result
        result = await self.app.push_screen_wait(NodeFormScreen())
        if result:
            # Node was added, refresh list
            self._refresh_list()

    @on(Button.Pressed, "#back")
    def back_clicked(self) -> None:
        """Go back."""
        self.dismiss()
