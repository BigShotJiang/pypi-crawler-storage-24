"""Action complete notification modal screen."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Label


class ActionCompleteScreen(ModalScreen[None]):
    """Display a completion notification with a Continue button."""

    def __init__(self, action: str) -> None:
        super().__init__()
        self.action = action

    def compose(self) -> ComposeResult:
        with Container():
            yield Label(self.action, id="info-label")
            with Horizontal(id="button-container"):
                yield Button("Continue")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss()
