"""Logs viewer screen for systemd service logs."""

from __future__ import annotations

import logging
from copy import copy
from dataclasses import asdict, dataclass
from time import perf_counter
from typing import TYPE_CHECKING, Any

from textual import work
from textual.binding import Binding
from textual.containers import Horizontal
from textual.dom import NoMatches
from textual.events import Click, Focus, Key
from textual.message import Message
from textual.reactive import var
from textual.screen import Screen
from textual.widget import Widget
from textual.widgets import Button, Label, RichLog, Select, Switch

from flux_config_shared.protocol import Event, EventType

if TYPE_CHECKING:
    from textual.app import ComposeResult

    from flux_config_tui.client_app import FluxConfigApp

logger = logging.getLogger(__name__)

# All available services for log streaming
ALL_SERVICES = ["fluxd", "fluxos", "fluxbenchd", "syncthing"]

# Default services to show on open
DEFAULT_OPEN_SERVICES = ["fluxd", "fluxos", "fluxbenchd"]


@dataclass
class LoggerSettings:
    """Settings for log viewer widget."""

    max_lines: int = 500
    wrap: bool = True
    highlight: bool = True
    auto_scroll: bool = True

    asdict = asdict


class Logger(Widget):
    """Widget for displaying systemd service logs."""

    class LoggerSelected(Message):
        """Posted when logger is double-clicked or Enter is pressed."""

        def __init__(self, logger: Logger) -> None:
            super().__init__()
            self.logger = logger

    class LoggerFocused(Message):
        """Posted when logger receives focus."""

        def __init__(self, logger: Logger) -> None:
            super().__init__()
            self.logger = logger

    ALLOW_MAXIMIZE = True
    BINDINGS = [
        Binding("escape", "dismiss", "Dismiss", show=False),
    ]

    highlight = var(True)
    auto_scroll = var(True)

    def __init__(
        self,
        service: str,
        logger_settings: LoggerSettings | None = None,
    ) -> None:
        """Initialize logger widget.

        Args:
            service: Service name (e.g., "fluxd", "fluxos")
            logger_settings: Optional logger settings
        """
        super().__init__()

        self.service = service
        self.logger_settings = logger_settings or LoggerSettings()
        self.rich_log = RichLog(**self.logger_settings.asdict())
        self.last_click = 0.0
        self._tailing = False

    @classmethod
    def from_service(cls, service: str) -> Logger:
        """Create logger from service name.

        Args:
            service: Service name

        Returns:
            Logger widget
        """
        logger = cls(service)
        logger.border_title = service
        return logger

    def compose(self) -> ComposeResult:
        """Compose logger widget."""
        yield self.rich_log

    def on_mount(self) -> None:
        """Logger widget mounted - logs will arrive via streaming."""
        # No action needed - LogScreen subscribes to logs topic
        # and routes LOG_LINES events to this widget
        pass

    def stop_tail_logs(self) -> None:
        """Stop tailing logs and clear display."""
        self.rich_log.clear()
        self._tailing = False

    def watch_highlight(self, old: bool, new: bool) -> None:
        """React to highlight setting change.

        Args:
            old: Old value
            new: New value
        """
        if old == new:
            return

        lines = copy(self.rich_log.lines)
        raw = "\n".join(x.text for x in lines)

        self.rich_log.clear()
        self.rich_log.highlight = new
        self.rich_log.write(raw)

    def watch_auto_scroll(self, old: bool, new: bool) -> None:
        """React to auto_scroll setting change.

        Args:
            old: Old value
            new: New value
        """
        if old == new:
            return

        self.rich_log.auto_scroll = new

    def on_key(self, event: Key) -> None:
        """Handle key events.

        Args:
            event: Key event
        """
        if event.name == "enter":
            self.post_message(self.LoggerSelected(self))

    def on_click(self, event: Click) -> None:
        """Handle click events (double-click to maximize).

        Args:
            event: Click event
        """
        now = perf_counter()

        if now - self.last_click < 0.4:
            self.post_message(self.LoggerSelected(self))
        else:
            self.last_click = now

    def on_descendant_focus(self, event: Focus) -> None:
        """Handle descendant focus events.

        Args:
            event: Focus event
        """
        event.stop()
        self.post_message(self.LoggerFocused(self))


class LogScreen(Screen):
    """Screen for viewing systemd service logs."""

    CSS_PATH = "logs.tcss"
    BINDINGS = [
        Binding("escape", "dismiss", "Dismiss", show=False),
    ]

    def __init__(self, services: list[str] | None = None) -> None:
        """Initialize log screen.

        Args:
            services: List of service names to show logs for.
                     If None, will use DEFAULT_OPEN_SERVICES.
        """
        super().__init__()
        # All available services
        self._all_services = ALL_SERVICES
        # Services displayed in the 3 fixed slots
        self._slot_services = (services or DEFAULT_OPEN_SERVICES.copy())[:3]
        # Pad to exactly 3 slots
        while len(self._slot_services) < 3:
            self._slot_services.append(self._slot_services[0])
        # Track currently selected service in dropdown (which slot is active)
        self._current_slot = 0
        # Create 3 fixed logger widgets (one per slot)
        self._logger_slots: list[Logger] = [
            Logger.from_service(self._slot_services[0]),
            Logger.from_service(self._slot_services[1]),
            Logger.from_service(self._slot_services[2]),
        ]
        # Legacy list for backward compatibility
        self.loggers: list[Logger] = self._logger_slots
        # Store bound handler reference for cleanup
        self._log_lines_handler = self._handle_log_lines

    def compose(self) -> ComposeResult:
        """Compose log screen."""
        # Create select options for all services
        options = [(s, s) for s in self._all_services]

        header = Horizontal()
        header.border_title = "Flux Logs"

        with header:
            with Horizontal(classes="switch-container"):
                yield Label("Logger:")
                yield Select(
                    options=options,
                    value=self._slot_services[0],
                    allow_blank=False,
                )
            yield Button("Close", id="state-toggle")
            with Horizontal(classes="switch-container"):
                yield Label("Highlight:")
                yield Switch(value=True, id="highlight")
            with Horizontal(classes="switch-container"):
                yield Label("Auto Scroll:")
                yield Switch(value=True, id="auto-scroll")
            yield Button("Exit", id="exit")

        # Yield the 3 fixed logger slots
        yield from self._logger_slots

    async def on_mount(self) -> None:
        """Delay subscription until widgets are sized."""
        # Wait for layout to complete before subscribing
        self.call_after_refresh(self._subscribe_to_logs)

    async def _subscribe_to_logs(self) -> None:
        """Subscribe to logs topic after widgets are mounted and sized."""
        app: FluxConfigApp = self.app  # type: ignore[assignment]

        # Register handler BEFORE subscribing so initial data events aren't lost
        app.backend_client.on_event(EventType.LOG_LINES, self._log_lines_handler)
        try:
            await app.backend_client.subscribe(
                ["logs"],
                params={"services": self._slot_services}
            )
            logger.info(f"Subscribed to logs topic for services: {self._slot_services}")
        except Exception as e:
            logger.error(f"Failed to subscribe to logs topic: {e}", exc_info=True)

    async def on_unmount(self) -> None:
        """Unsubscribe from logs topic when screen is dismissed."""
        app: FluxConfigApp = self.app  # type: ignore[assignment]

        # Unregister event handler
        app.backend_client.off_event(EventType.LOG_LINES, self._log_lines_handler)

        try:
            await app.backend_client.unsubscribe(["logs"])
            logger.info("Unsubscribed from logs topic")
        except Exception as e:
            logger.error(f"Failed to unsubscribe from logs topic: {e}", exc_info=True)

    async def _update_subscription(
        self,
        add: list[str] | None = None,
        remove: list[str] | None = None
    ) -> None:
        """Update log subscription with new service list.

        Args:
            add: Services to add to subscription
            remove: Services to remove from subscription
        """
        app: FluxConfigApp = self.app  # type: ignore[assignment]

        try:
            # Unsubscribe from logs
            await app.backend_client.unsubscribe(["logs"])

            # Resubscribe with updated service list from slots
            await app.backend_client.subscribe(
                ["logs"],
                params={"services": self._slot_services}
            )

            if add:
                logger.info(f"Added services to subscription: {add}")
            if remove:
                logger.info(f"Removed services from subscription: {remove}")

        except Exception as e:
            logger.error(f"Failed to update log subscription: {e}", exc_info=True)

    async def _handle_log_lines(self, event: Event) -> None:
        """Handle LOG_LINES events from daemon.

        Args:
            event: Event containing log lines for a service
        """
        try:
            service = event.data.get("service", "")
            lines = event.data.get("lines", [])

            logger.info(f"Received LOG_LINES event for {service}: {len(lines)} lines")

            if not service or not lines:
                logger.info(f"Skipping LOG_LINES: service={service}, lines count={len(lines)}")
                return

            # Find which slot this service is in
            try:
                slot_idx = self._slot_services.index(service)
                logger_widget = self._logger_slots[slot_idx]
            except ValueError:
                logger.warning(f"Service {service} not in any slot")
                return

            if not logger_widget.display:
                logger.info(f"Logger widget for {service} is not displayed, skipping")
                return

            logger.info(f"Writing {len(lines)} lines to {service} logger widget (slot {slot_idx})")
            # Append all lines to the rich log
            for line in lines:
                logger_widget.rich_log.write(line)

        except Exception as e:
            logger.error(f"Error handling log lines: {e}", exc_info=True)

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle switch changes.

        Args:
            event: Switch changed event
        """
        try:
            logger_name = self.query_one(Select).value
        except NoMatches:
            return

        # Find which slot has this service
        try:
            slot_idx = self._slot_services.index(logger_name)
            logger_widget = self._logger_slots[slot_idx]
        except ValueError:
            return

        if event.switch.id == "highlight":
            logger_widget.highlight = event.value
        elif event.switch.id == "auto-scroll":
            logger_widget.auto_scroll = event.value

    async def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select changes.

        Args:
            event: Select changed event
        """
        new_service = event.value

        # Find which slot is currently selected
        try:
            current_slot_service = self._slot_services[self._current_slot]
        except IndexError:
            self._current_slot = 0
            current_slot_service = self._slot_services[0]

        # If selecting same service in current slot, just update UI
        if new_service == current_slot_service:
            logger_widget = self._logger_slots[self._current_slot]
            highlight = self.query_one("#highlight", Switch)
            auto_scroll = self.query_one("#auto-scroll", Switch)
            state_toggle = self.query_one("#state-toggle", Button)

            highlight.value = logger_widget.highlight
            auto_scroll.value = logger_widget.auto_scroll
            state_toggle.label = "Close" if logger_widget.display else "Open"
            return

        # If service is already in another slot, just switch to that slot
        if new_service in self._slot_services:
            self._current_slot = self._slot_services.index(new_service)
            logger_widget = self._logger_slots[self._current_slot]

            highlight = self.query_one("#highlight", Switch)
            auto_scroll = self.query_one("#auto-scroll", Switch)
            state_toggle = self.query_one("#state-toggle", Button)

            highlight.value = logger_widget.highlight
            auto_scroll.value = logger_widget.auto_scroll
            state_toggle.label = "Close" if logger_widget.display else "Open"
            return

        # Replace service in current slot
        old_service = self._slot_services[self._current_slot]
        self._slot_services[self._current_slot] = new_service

        # Update the logger widget
        logger_widget = self._logger_slots[self._current_slot]
        logger_widget.border_title = new_service
        logger_widget.service = new_service
        logger_widget.rich_log.clear()

        logger.info(f"Replacing slot {self._current_slot}: {old_service} -> {new_service}")

        # Update subscription
        await self._update_subscription(remove=[old_service], add=[new_service])

        # Update UI controls
        highlight = self.query_one("#highlight", Switch)
        auto_scroll = self.query_one("#auto-scroll", Switch)
        state_toggle = self.query_one("#state-toggle", Button)

        highlight.value = logger_widget.highlight
        auto_scroll.value = logger_widget.auto_scroll
        state_toggle.label = "Close" if logger_widget.display else "Open"

        logger.info(f"Switched to service {new_service} in slot {self._current_slot}, services: {self._slot_services}")

    def on_logger_logger_selected(self, event: Logger.LoggerSelected) -> None:
        """Handle logger selection (maximize/minimize).

        Args:
            event: Logger selected event
        """
        self.minimize() if event.logger.is_maximized else self.maximize(event.logger)

    def on_logger_logger_focused(self, event: Logger.LoggerFocused) -> None:
        """Handle logger focus.

        Args:
            event: Logger focused event
        """
        # Find which slot this logger is in
        try:
            slot_idx = self._logger_slots.index(event.logger)
            self._current_slot = slot_idx
            self.query_one(Select).value = self._slot_services[slot_idx]
        except (ValueError, IndexError):
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses.

        Args:
            event: Button pressed event
        """
        if event.button.id == "exit":
            self.dismiss()
        elif event.button.id == "state-toggle":
            logger_name = self.query_one(Select).value

            # Find which slot has this service
            try:
                slot_idx = self._slot_services.index(logger_name)
                logger_widget = self._logger_slots[slot_idx]
            except ValueError:
                return

            logger_widget.display = not logger_widget.display
            event.button.label = "Close" if logger_widget.display else "Open"

            if not logger_widget.display:
                logger_widget.stop_tail_logs()
