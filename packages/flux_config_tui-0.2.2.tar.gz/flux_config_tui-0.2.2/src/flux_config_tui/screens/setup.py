"""Setup screen for SSH node selection."""

from time import perf_counter

from textual import on, work
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.events import Click, Key
from textual.screen import ModalScreen, Screen
from textual.widgets import Button, DataTable, Label, Static

from flux_config_tui.config import NodeConfig, TUIConfig


class ConfirmDeleteModal(ModalScreen[bool]):
    """Confirmation modal for node deletion."""

    DEFAULT_CSS = """
    ConfirmDeleteModal {
        align: center middle;
    }

    #confirm-container {
        width: 50;
        height: auto;
        border: solid $primary;
        padding: 1 2;
    }

    #confirm-message {
        width: 1fr;
        text-align: center;
        padding: 1;
        margin-bottom: 1;
    }

    #confirm-buttons {
        height: auto;
        align: center middle;
    }

    #confirm-buttons > Button {
        margin: 0 1;
    }
    """

    def __init__(self, node_name: str) -> None:
        super().__init__()
        self.node_name = node_name

    def compose(self) -> ComposeResult:
        with Container(id="confirm-container"):
            yield Label(
                f'Delete node "{self.node_name}", are you sure?',
                id="confirm-message",
            )
            with Horizontal(id="confirm-buttons"):
                yield Button("Cancel", id="confirm-cancel")
                yield Button("Delete", variant="error", id="confirm-delete")

    @on(Button.Pressed, "#confirm-cancel")
    def cancel(self) -> None:
        self.dismiss(False)

    @on(Button.Pressed, "#confirm-delete")
    def delete(self) -> None:
        self.dismiss(True)

    def on_key(self, event: Key) -> None:
        if event.name == "escape":
            self.dismiss(False)


class SetupScreen(Screen):
    """Setup screen for SSH node selection."""

    AUTO_FOCUS = None
    CSS_PATH = "setup.tcss"

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.nodes: list[NodeConfig] = []
        self._last_click: float = 0
        self._selected_row: int = 0

    def compose(self) -> ComposeResult:
        """Compose the setup screen."""
        with Container(id="setup-container"):
            yield Static("Connect to Fluxnode", classes="setup-title")
            yield Static(
                "Select a node or configure a new connection",
                classes="help-text",
            )
            with Container(id="table-wrapper"):
                yield DataTable(id="node-table", cursor_type="row")
            with Horizontal(id="list-buttons"):
                yield Button("Cancel", variant="error", id="cancel")
                yield Button("Delete", id="delete-node")
                yield Button("Add New Node", variant="primary", id="add-node")

    def on_mount(self) -> None:
        """Load nodes and show list."""
        self.nodes = TUIConfig.get_nodes()

        if self.nodes:
            self._populate_node_list()
        else:
            self._show_form_on_start()

    @work
    async def _show_form_on_start(self) -> None:
        """Show form if no nodes exist (runs after mount)."""
        from flux_config_tui.screens.node_form import NodeFormScreen

        result = await self.app.push_screen_wait(NodeFormScreen(None))
        if result:
            self.nodes = TUIConfig.get_nodes()
            self._populate_node_list()
        else:
            self.dismiss(None)

    def _populate_node_list(self) -> None:
        """Populate DataTable with nodes."""
        table = self.query_one("#node-table", DataTable)
        table.clear(columns=True)

        table.add_column("Name", width=20, key="name")
        table.add_column("Host", width=20, key="host")
        table.add_column("Port", width=6, key="port")

        for node in self.nodes:
            display_name = node.name if node.name else node.ssh_host
            table.add_row(
                display_name,
                node.ssh_host,
                str(node.ssh_port),
                key=node.ssh_host,
            )

        self._selected_row = 0
        table.move_cursor(row=0)

    def _get_selected_node(self) -> NodeConfig | None:
        """Get the node at the current selected row."""
        if not self.nodes or self._selected_row >= len(self.nodes):
            return None
        table = self.query_one("#node-table", DataTable)
        row_key = table.coordinate_to_cell_key(
            (self._selected_row, 0)
        ).row_key
        return next(
            (n for n in self.nodes if n.ssh_host == row_key.value), None
        )

    def on_key(self, event: Key) -> None:
        """Handle keyboard navigation."""
        table = self.query_one("#node-table", DataTable)

        if event.name == "up":
            event.stop()
            if table.row_count == 0:
                return
            self._selected_row = (self._selected_row - 1) % table.row_count
            table.move_cursor(row=self._selected_row)
        elif event.name == "down":
            event.stop()
            if table.row_count == 0:
                return
            self._selected_row = (self._selected_row + 1) % table.row_count
            table.move_cursor(row=self._selected_row)
        elif event.name == "enter":
            event.stop()
            node = self._get_selected_node()
            if node:
                self.dismiss(node)

    @on(DataTable.RowSelected, "#node-table")
    def on_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle click on row - double-click to connect."""
        now = perf_counter()
        if now - self._last_click < 0.4:
            node = self._get_selected_node()
            if node:
                self.dismiss(node)
        else:
            self._last_click = now

    @on(DataTable.RowHighlighted, "#node-table")
    def on_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        """Track which row is highlighted when user clicks."""
        if event.cursor_row is not None:
            self._selected_row = event.cursor_row

    @on(Button.Pressed, "#delete-node")
    def delete_node_clicked(self) -> None:
        """Delete the highlighted node."""
        self._delete_node()

    @work
    async def _delete_node(self) -> None:
        """Show confirmation and delete node."""
        table = self.query_one("#node-table", DataTable)
        if table.row_count == 0:
            return

        row_key = table.coordinate_to_cell_key(
            (self._selected_row, 0)
        ).row_key
        node = next(
            (n for n in self.nodes if n.ssh_host == row_key.value), None
        )
        if not node:
            return

        display_name = node.name if node.name else node.ssh_host
        confirmed = await self.app.push_screen_wait(
            ConfirmDeleteModal(display_name)
        )

        if confirmed:
            TUIConfig.remove_node(node.ssh_host)
            self.nodes = [n for n in self.nodes if n.ssh_host != node.ssh_host]
            table.remove_row(row_key)
            if self._selected_row >= table.row_count and table.row_count > 0:
                self._selected_row = table.row_count - 1
                table.move_cursor(row=self._selected_row)

    @on(Button.Pressed, "#add-node")
    def add_node_clicked(self) -> None:
        """Show form for adding new node."""
        self._show_form()

    @work
    async def _show_form(self, node: NodeConfig | None = None) -> None:
        """Show node form screen (worker)."""
        from flux_config_tui.screens.node_form import NodeFormScreen

        result = await self.app.push_screen_wait(NodeFormScreen(node))
        if result:
            self.nodes = TUIConfig.get_nodes()
            self._populate_node_list()

    @on(Button.Pressed, "#cancel")
    def cancel_clicked(self) -> None:
        """Cancel setup."""
        self.dismiss(None)

    def action_cancel(self) -> None:
        """Handle escape key."""
        self.cancel_clicked()
