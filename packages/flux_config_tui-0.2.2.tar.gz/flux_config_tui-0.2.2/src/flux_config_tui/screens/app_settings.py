"""App settings modal screen."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Container
from textual.events import Key
from textual.screen import ModalScreen
from textual.widgets import Button


class AppSettingsScreen(ModalScreen[str | None]):
    """Modal screen for accessing app-level settings."""

    def compose(self) -> ComposeResult:
        """Compose the screen."""
        with Container():
            yield Button("Theme Selector", id="change-theme")
            yield Button("Energy Saving", id="energy-saving")
            yield Button("Display Size", id="display-size")

            # Only show "Manage SSH Nodes" if connected via SSH
            if hasattr(self.app, "connection_string") and self.app.connection_string.startswith(
                "ssh://"
            ):
                yield Button("Manage SSH Nodes", id="manage-nodes")

            yield Button("Back", id="back")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        if event.button.id == "back":
            self.dismiss(None)
        else:
            self.dismiss(event.button.id)

    def on_key(self, event: Key) -> None:
        """Handle key press."""
        if event.name == "escape":
            self.dismiss(None)
