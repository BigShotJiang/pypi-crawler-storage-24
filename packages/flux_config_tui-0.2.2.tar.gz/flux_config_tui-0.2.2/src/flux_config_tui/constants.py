"""Application-wide constants."""

# Remote daemon socket path (always the same for SSH forwarding)
DEFAULT_REMOTE_SOCKET_PATH = "/run/flux-configd/daemon.sock"

# Default local unix socket (for direct connections)
DEFAULT_LOCAL_SOCKET_PATH = "/run/flux-configd/daemon.sock"

# SSH defaults
DEFAULT_SSH_PORT = 22

# SSH key auto-detection paths
COMMON_SSH_KEYS = [
    "~/.ssh/id_ed25519",
    "~/.ssh/id_rsa",
    "~/.ssh/id_ecdsa",
    "~/.ssh/operator_ed25519",
]
