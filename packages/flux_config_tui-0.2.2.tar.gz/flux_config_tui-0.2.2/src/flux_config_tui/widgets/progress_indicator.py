"""Progress indicator widget for download/stream operations."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Grid, Horizontal
from textual.widgets import Label, ProgressBar


class ProgressIndicator(Grid):
    """Widget showing download/extraction progress with separate progress bars for each phase."""

    def __init__(self) -> None:
        """Initialize progress indicator with two separate progress tracking systems."""
        super().__init__()

        # Shared labels (text updated based on phase)
        self.header = Label("     Chain Download Progress")
        self.metric_label = Label("Rate:")
        self.value_label = Label("0.00 Mbit/s", id="progress-value")

        # Two separate progress bars (maintain independent ETA calculations)
        self.download_bar = ProgressBar()
        self.extraction_bar = ProgressBar()

        # Initialization tracking
        self._download_initialized = False
        self._extraction_initialized = False
        self._download_bytes = 0
        self._download_total = 0
        self._download_speed = 0.0
        self._extraction_parts = 0
        self._extraction_total = 0

    def compose(self) -> ComposeResult:
        """Compose the widget UI."""
        yield self.header
        with Horizontal():
            yield self.metric_label
            yield self.value_label
        yield self.download_bar
        yield self.extraction_bar

    def on_mount(self) -> None:
        """Initialize visibility - seed bars with any pre-mount progress."""
        self.extraction_bar.display = False

        # If download was initialized before mount, seed the bar with current
        # progress so the ETA starts from the current position (not from 0)
        if self._download_initialized:
            self.download_bar.update(total=self._download_total, progress=self._download_bytes)
            self.value_label.update(f"{self._download_speed:.2f} Mbit/s")

    def start_download(self, total_bytes: int) -> None:
        """Initialize download phase - show download bar, hide extraction.

        Args:
            total_bytes: Total bytes to download
        """
        self.header.update("     Chain Download Progress")
        self.metric_label.update("Rate:")
        if self.is_mounted:
            self.download_bar.display = True
            self.extraction_bar.display = False
        self._download_total = total_bytes
        self.download_bar.update(total=total_bytes, progress=0)
        self._download_initialized = True
        self._extraction_initialized = False

    def start_extraction(self, total_parts: int) -> None:
        """Initialize extraction tracking (bar stays hidden until show_extraction).

        Args:
            total_parts: Total parts to extract
        """
        self.extraction_bar.update(total=total_parts, progress=0)
        self._extraction_initialized = True

    def show_extraction(self) -> None:
        """Switch display from download bar to extraction bar."""
        self.header.update("    Chain Extraction Progress")
        self.metric_label.update("Parts:")
        self.value_label.update(f"{self._extraction_parts}/{self._extraction_total}")
        if self.is_mounted:
            self.download_bar.display = False
            self.extraction_bar.display = True

    def update_download(self, bytes_downloaded: int, speed_mbps: float) -> None:
        """Update download progress.

        Args:
            bytes_downloaded: Current bytes downloaded
            speed_mbps: Download speed in Mbit/s
        """
        self._download_bytes = bytes_downloaded
        self._download_speed = speed_mbps
        if self.is_mounted:
            self.value_label.update(f"{speed_mbps:.2f} Mbit/s")
            self.download_bar.update(progress=bytes_downloaded)

    def update_extraction(self, parts_extracted: int, total_parts: int) -> None:
        """Update extraction progress.

        Args:
            parts_extracted: Current parts extracted
            total_parts: Total parts to extract
        """
        self._extraction_parts = parts_extracted
        self._extraction_total = total_parts
        if self.is_mounted:
            if self.extraction_bar.display:
                self.value_label.update(f"{parts_extracted}/{total_parts}")
            self.extraction_bar.update(progress=parts_extracted)
