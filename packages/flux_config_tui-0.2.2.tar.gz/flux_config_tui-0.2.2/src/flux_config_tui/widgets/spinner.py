from rich.spinner import Spinner as RichSpinner
from textual.app import RenderableType
from textual.widgets import Static


class IntervalUpdater(Static):
    def __init__(self, renderable_object: RenderableType, **kwargs) -> None:
        super().__init__(renderable_object, **kwargs)

    def on_mount(self) -> None:
        self.interval_update = self.set_interval(1 / 15, self.refresh)


class Spinner(IntervalUpdater):
    def __init__(self, style: str, **kwargs) -> None:
        super().__init__(RichSpinner(style), **kwargs)
