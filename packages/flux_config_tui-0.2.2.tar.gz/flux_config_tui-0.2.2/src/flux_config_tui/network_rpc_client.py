"""NetworkClient protocol adapter - bridges NetworkScreen to BackendClient RPC."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from flux_config_tui.client import BackendClient

logger = logging.getLogger(__name__)


class NetworkRpcClient:
    """Implements the NetworkClient protocol by delegating to BackendClient RPC calls."""

    def __init__(self, backend_client: BackendClient) -> None:
        self._client = backend_client

    async def _call(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        try:
            response = await self._client.call_method(method, params or {})
        except Exception:
            logger.exception("RPC call %s raised", method)
            return {"success": False, "error": "RPC exception"}
        if response.result is not None:
            return response.result
        error_msg = response.error.message if response.error else "RPC failed"
        return {"success": False, "error": error_msg}

    # --- Interface Management ---

    async def get_interfaces(self) -> dict[str, Any]:
        return await self._call("network.get_interfaces")

    async def set_static_ip(
        self, interface: str, address: str, gateway: str | None, dns: list[str]
    ) -> dict[str, Any]:
        return await self._call(
            "network.set_static_ip",
            {"interface": interface, "address": address, "gateway": gateway, "dns": dns},
        )

    async def set_dhcp(self, interface: str) -> dict[str, Any]:
        return await self._call("network.set_dhcp", {"interface": interface})

    async def set_disabled(self, interface: str) -> dict[str, Any]:
        return await self._call("network.set_disabled", {"interface": interface})

    async def create_vlan(self, parent: str, vlan_id: int) -> dict[str, Any]:
        return await self._call("network.create_vlan", {"parent": parent, "vlan_id": vlan_id})

    async def delete_vlan(self, interface: str) -> dict[str, Any]:
        return await self._call("network.delete_vlan", {"interface": interface})

    async def restart_networkd(self) -> dict[str, Any]:
        return await self._call("network.restart_networkd")

    async def apply_interface_config(
        self,
        interface: str,
        ip_allocation: str,
        address: str | None,
        gateway: str | None,
        dns: list[str],
        vlan_children: list[str],
        atomic_updates: bool,
    ) -> dict[str, Any]:
        return await self._call(
            "network.apply_interface_config",
            {
                "interface": interface,
                "ip_allocation": ip_allocation,
                "address": address,
                "gateway": gateway,
                "dns": dns,
                "vlan_children": vlan_children,
                "atomic_updates": atomic_updates,
            },
        )

    async def rollback_config(self, atomic_updates: bool) -> dict[str, Any]:
        return await self._call(
            "network.rollback_config", {"atomic_updates": atomic_updates}
        )

    async def persist_config(self, atomic_updates: bool) -> dict[str, Any]:
        return await self._call(
            "network.persist_config", {"atomic_updates": atomic_updates}
        )

    # --- Routing and DNS ---

    async def get_routes(self) -> dict[str, Any]:
        return await self._call("network.get_routes")

    async def get_dns(self) -> dict[str, Any]:
        return await self._call("network.get_dns")

    async def test_dns(self, hostnames: list[str] | None = None) -> dict[str, Any]:
        return await self._call("network.test_dns", {"hostnames": hostnames or []})

    async def test_connectivity(
        self, gateways: list[str], include_public: bool = True
    ) -> dict[str, Any]:
        # Daemon takes a single gateway; test the first one
        if not gateways:
            return {"success": True, "reachable": False}
        return await self._call("network.test_connectivity", {"gateway": gateways[0]})

    # --- UPnP ---

    async def upnp_get_status(self) -> dict[str, Any]:
        return await self._call("network.upnp.get_status")

    async def upnp_get_api_mappings(self) -> dict[str, Any]:
        return await self._call("network.upnp.get_api_mappings")

    async def upnp_add_mapping(self, port: int) -> dict[str, Any]:
        return await self._call("network.upnp.add_mapping", {"port": port})

    async def upnp_remove_mapping(self, port: int) -> dict[str, Any]:
        return await self._call("network.upnp.remove_mapping", {"port": port})

    # --- Traffic Shaping ---

    async def get_shaping_policy(self) -> dict[str, Any]:
        return await self._call("network.shaping.get_policy")

    async def set_shaping_policy(self, interface: str, rate: int | None) -> dict[str, Any]:
        return await self._call("network.shaping.set_policy", {"interface": interface, "rate": rate})

    # --- Event Subscriptions ---

    async def subscribe(self, topics: list[str]) -> dict[str, Any]:
        return await self._call("subscribe", {"topics": topics})

    async def unsubscribe(self, topics: list[str]) -> dict[str, Any]:
        return await self._call("unsubscribe", {"topics": topics})
