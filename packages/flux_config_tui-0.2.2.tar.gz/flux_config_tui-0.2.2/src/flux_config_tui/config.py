import os
from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass
class NodeConfig:
    """SSH node configuration."""

    ssh_host: str  # SSH hostname/IP (e.g., "banana", "192.168.1.100") - UNIQUE KEY
    name: str = ""  # Optional display name (e.g., "Production Node", "banana")
    ssh_port: int = 22  # SSH port
    ssh_key_path: str = ""  # Path to SSH private key
    is_default: bool = False  # Default node for connections

    @property
    def ssh_user(self) -> str:
        """SSH user is always 'fluxtui'."""
        return "fluxtui"


class TUIConfig:
    """TUI configuration using XDG Base Directory."""

    @staticmethod
    def get_config_path() -> Path:
        """Get config file path following XDG spec."""
        xdg_config_home = os.getenv("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
        config_dir = Path(xdg_config_home) / "flux-config"
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir / "config.yaml"

    @staticmethod
    def load() -> dict:
        """Load configuration from file."""
        config_path = TUIConfig.get_config_path()
        if config_path.exists():
            with open(config_path) as f:
                return yaml.safe_load(f) or {}
        return {}

    @staticmethod
    def save(config: dict) -> None:
        """Save configuration to file."""
        config_path = TUIConfig.get_config_path()
        with open(config_path, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False)

    @staticmethod
    def get_ssh_key_path() -> str | None:
        """Get SSH key path from config or environment variable."""
        env_key = os.getenv("FLUX_CONFIG_SSH_KEY")
        if env_key:
            return env_key

        config = TUIConfig.load()
        return config.get("ssh", {}).get("key_path")

    @staticmethod
    def get_nodes() -> list[NodeConfig]:
        """Get all configured SSH nodes."""
        config = TUIConfig.load()
        nodes = []
        for node_dict in config.get("nodes", []):
            nodes.append(NodeConfig(**node_dict))
        return nodes

    @staticmethod
    def get_default_node() -> NodeConfig | None:
        """Get the default SSH node."""
        nodes = TUIConfig.get_nodes()
        default = next((n for n in nodes if n.is_default), None)
        return default or (nodes[0] if nodes else None)

    @staticmethod
    def add_or_update_node(node: NodeConfig) -> None:
        """Add a new node or update existing one by ssh_host."""
        config = TUIConfig.load()
        nodes = config.get("nodes", [])

        # Remove existing node with same ssh_host (unique key)
        nodes = [n for n in nodes if n.get("ssh_host") != node.ssh_host]

        # If this is marked default, unmark all others
        if node.is_default:
            for n in nodes:
                n["is_default"] = False

        # Add new node (ssh_user not stored, always "fluxtui")
        nodes.append({
            "ssh_host": node.ssh_host,
            "name": node.name,
            "ssh_port": node.ssh_port,
            "ssh_key_path": node.ssh_key_path,
            "is_default": node.is_default,
        })

        config["nodes"] = nodes
        TUIConfig.save(config)

    @staticmethod
    def remove_node(ssh_host: str) -> None:
        """Remove a node by ssh_host."""
        config = TUIConfig.load()
        nodes = config.get("nodes", [])
        nodes = [n for n in nodes if n.get("ssh_host") != ssh_host]
        config["nodes"] = nodes
        TUIConfig.save(config)
