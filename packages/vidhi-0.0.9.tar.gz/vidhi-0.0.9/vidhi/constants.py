"""Constants used throughout the Vidhi configuration library.

This module defines all magic strings, default values, and error messages
to avoid hardcoding throughout the codebase.
"""

# =============================================================================
# Dictionary Keys
# =============================================================================

# Key used to store polymorphic type information in dictionaries
DICT_KEY_TYPE = "type"

# Key used to store alternative name information
DICT_KEY_NAME = "name"

# Internal key used during post-initialization
DICT_KEY_IN_POST_INIT = "_in_post_init"


# =============================================================================
# CLI Argument Formatting
# =============================================================================

# Prefix for CLI arguments
CLI_ARG_PREFIX = "--"


# =============================================================================
# Default Values
# =============================================================================

# Maximum number of configuration combinations to prevent combinatorial explosion
DEFAULT_MAX_COMBINATIONS = 10_000

# Default nargs value for list arguments
DEFAULT_LIST_NARGS = "+"


# =============================================================================
# Special String Values
# =============================================================================

# String representation of None for type fields
TYPE_VALUE_NONE = "None"


# =============================================================================
# Error Messages
# =============================================================================

MSG_COMBINATORIAL_EXPLOSION = (
    "The number of generated configuration combinations ({count}) "
    "exceeds the allowed maximum of {max}. Reduce list sizes or "
    "increase the limit to avoid combinatorial explosion."
)

MSG_INVALID_TYPE_VALUE = (
    "No subclass of '{parent}' matches type value '{type_val}'. "
    "Valid types are: {valid_types}"
)

MSG_UNKNOWN_ARGUMENTS = "Unknown arguments provided for {class_name}: {extra_keys}"

MSG_MISSING_REQUIRED_FIELD = (
    "--{arg_name} is required when --{type_arg} is '{type_value}'"
)

MSG_FIELD_REQUIRES_DEFAULT = (
    "Field {field_name} of type {field_type} must have a default or default_factory"
)

MSG_ARGNAME_CONFLICT = (
    "Cannot have multiple fields with the same argname: {argname} "
    "already exists for field {existing_field}"
)

MSG_UNSUPPORTED_LIST_TYPE = (
    "Unsupported list element type '{element_type}'. "
    "Only primitives, dataclasses and BasePolyConfig subclasses are allowed."
)


# =============================================================================
# Metadata Keys
# =============================================================================

# Key for help text in field metadata
METADATA_KEY_HELP = "help"

# Key for custom argument name in field metadata
METADATA_KEY_ARGNAME = "argname"

# Key for CLI argument aliases in field metadata
METADATA_KEY_ALIASES = "aliases"

# Key for choices in field metadata
METADATA_KEY_CHOICES = "choices"

# Key for shortcut flags in field metadata (maps short flag strings to values)
METADATA_KEY_SHORTCUTS = "shortcuts"

# Key for marking a field as positional in field metadata
METADATA_KEY_POSITIONAL = "positional"
