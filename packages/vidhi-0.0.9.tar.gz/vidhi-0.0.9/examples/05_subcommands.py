"""Example: Subcommand-based CLI with BaseCommand.

Demonstrates:
- BaseCommand for multi-command CLIs
- Subcommand names and aliases
- Default command
- Positional args
- Shared base class fields

Usage:
    python 05_subcommands.py --help
    python 05_subcommands.py run ./src
    python 05_subcommands.py r ./src --verbose true
    python 05_subcommands.py list
    python 05_subcommands.py l
    python 05_subcommands.py --verbose true    # uses default command (Run)
"""

import sys

from vidhi import BaseCommand, field, frozen_dataclass, parse_cli_args


@frozen_dataclass
class TaskRunner(BaseCommand):
    """TaskRunner — a simple task management tool"""

    verbose: bool = field(False, help="Verbose output")


@frozen_dataclass
class Run(TaskRunner, name="run", alias="r", default=True):
    """Run a task in the given directory"""

    target: str = field(".", positional=True)
    dry_run: bool = field(False, help="Show what would be done without doing it")


@frozen_dataclass
class List(TaskRunner, name="list", alias="l"):
    """List available tasks"""

    all: bool = field(False, help="Include hidden tasks")


@frozen_dataclass
class Clean(TaskRunner, name="clean", alias="c"):
    """Clean build artifacts"""

    force: bool = field(False, help="Force clean without confirmation")


def main():
    cmd = parse_cli_args(TaskRunner)

    print(f"Command: {type(cmd).__name__}")
    print(f"Verbose: {cmd.verbose}")

    if isinstance(cmd, Run):
        print(f"Target:  {cmd.target}")
        print(f"Dry run: {cmd.dry_run}")
        print()
        if cmd.verbose:
            print(f"[verbose] Running in: {cmd.target}")
        print(f"Running task in {cmd.target}" + (" (dry run)" if cmd.dry_run else ""))

    elif isinstance(cmd, List):
        print(f"All:     {cmd.all}")
        print()
        if cmd.verbose:
            print("[verbose] Listing tasks")
        print("Available tasks:" + (" (including hidden)" if cmd.all else ""))

    elif isinstance(cmd, Clean):
        print(f"Force:   {cmd.force}")
        print()
        if cmd.verbose:
            print("[verbose] Cleaning artifacts")
        print("Cleaning..." + (" (forced)" if cmd.force else ""))


if __name__ == "__main__":
    main()
