# Vidhi Examples

Runnable examples demonstrating Vidhi's configuration management features.

## Examples

### 01_basic_usage.py
Basic frozen dataclasses and CLI argument parsing.

```bash
python 01_basic_usage.py --help
python 01_basic_usage.py --lr 0.01 --epochs 20
```

### 02_polymorphic_cli.py
Polymorphic configurations with variant-specific CLI arguments.

```bash
python 02_polymorphic_cli.py --help
python 02_polymorphic_cli.py --scheduler_type priority --scheduler.levels 10
python 02_polymorphic_cli.py --scheduler_type round_robin --scheduler.quantum_ms 50
```

### 03_yaml_config.py
Loading configurations from YAML files with nested and polymorphic types.

```bash
python 03_yaml_config.py
python 03_yaml_config.py config.yaml
```

### 05_subcommands.py
Subcommand-based CLI with `BaseCommand` — names, aliases, default command, and positional args.

```bash
python 05_subcommands.py --help           # shows all commands
python 05_subcommands.py run ./src        # explicit command + positional arg
python 05_subcommands.py r ./src          # alias
python 05_subcommands.py --verbose        # default command (Run) with base flag
python 05_subcommands.py list --all       # different command with its own flag
python 05_subcommands.py run --help       # command-specific help
```

## Running Examples

From the repository root:

```bash
cd examples
python 01_basic_usage.py --help
```

Or directly:

```bash
python examples/02_polymorphic_cli.py --scheduler_type priority
python examples/05_subcommands.py run ./src --verbose
```
