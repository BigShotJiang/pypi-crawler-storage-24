"""AI model definitions."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Model:
    """AI model configuration."""

    identifier: str
    mode: str = "copilot"


class Models:
    """Available AI models (all use copilot mode with web search)."""

    DEEP_RESEARCH = Model(identifier="pplx_alpha")
    """Deep Research - Create in-depth reports with more sources, charts, and advanced reasoning."""

    CREATE_FILES_AND_APPS = Model(identifier="pplx_beta")
    """Create files and apps (previously known as Labs) - Turn your ideas into docs, slides, dashboards, and more."""

    BEST = Model(identifier="pplx_pro")
    """Best - Automatically selects the best model based on the query."""

    SONAR = Model(identifier="experimental")
    """Sonar - Perplexity's latest model."""

    GEMINI_31_PRO_THINKING = Model(identifier="gemini31pro_high")
    """Gemini 3.1 Pro Thinking - Google's most advanced model (thinking)."""

    GPT_54 = Model(identifier="gpt54")
    """GPT-5.4 - OpenAI's latest model."""

    GPT_54_THINKING = Model(identifier="gpt54_thinking")
    """GPT-5.4 Thinking - OpenAI's latest model (thinking)."""

    CLAUDE_46_SONNET = Model(identifier="claude46sonnet")
    """Claude Sonnet 4.6 - Anthropic's fast model."""

    CLAUDE_46_SONNET_THINKING = Model(identifier="claude46sonnetthinking")
    """Claude Sonnet 4.6 Thinking - Anthropic's fast model (thinking)."""

    CLAUDE_46_OPUS = Model(identifier="claude46opus")
    """Claude Opus 4.6 - Anthropic's most advanced reasoning model."""

    CLAUDE_46_OPUS_THINKING = Model(identifier="claude46opusthinking")
    """Claude Opus 4.6 Thinking - Anthropic's most advanced reasoning model (thinking)."""

    NEMOTRON_3_SUPER = Model(identifier="nv_nemotron_3_super")
    """Nemotron 3 Super - NVIDIA's Nemotron 3 Super 120B model (thinking)."""

