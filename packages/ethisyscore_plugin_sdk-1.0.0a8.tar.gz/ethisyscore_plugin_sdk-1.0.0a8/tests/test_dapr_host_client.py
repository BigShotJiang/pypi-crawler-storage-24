"""
Basic tests for the DaprHostClient and its sub-clients.

These tests verify the public API surface and payload construction
without requiring a running Dapr sidecar or host.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from ethisyscore_plugin_sdk.dapr_host_client import DaprHostClient, _PluginLogger


class TestPluginLogger:
    """Tests for the synchronous logger wrapper."""

    def test_logger_has_all_methods(self) -> None:
        client = DaprHostClient("test-host", "ext-123")
        logger = client.logger

        assert callable(logger.debug)
        assert callable(logger.info)
        assert callable(logger.warning)
        assert callable(logger.error)

    def test_logger_methods_are_synchronous(self) -> None:
        """Logger methods should be plain functions, not coroutines."""
        client = DaprHostClient("test-host", "ext-123")
        logger = client.logger

        # Synchronous methods should not return a coroutine
        import asyncio
        result = logger.debug("test message")
        assert not asyncio.iscoroutine(result)

        result = logger.info("test message")
        assert not asyncio.iscoroutine(result)

        result = logger.warning("test message")
        assert not asyncio.iscoroutine(result)

        result = logger.error("test message")
        assert not asyncio.iscoroutine(result)

    def test_logger_does_not_raise_without_event_loop(self) -> None:
        """Logger should not raise when no event loop is running."""
        client = DaprHostClient("test-host", "ext-123")
        logger = client.logger

        # These should not raise — fire-and-forget silently catches RuntimeError
        logger.debug("test")
        logger.info("test")
        logger.warning("test")
        logger.error("test")
        logger.error("test", exception="traceback here")


class TestDataStore:
    """Tests for the DataStore client API surface."""

    def test_data_store_has_all_methods(self) -> None:
        client = DaprHostClient("test-host", "ext-123")
        ds = client.data_store

        assert callable(ds.get)
        assert callable(ds.set)
        assert callable(ds.delete)
        assert callable(ds.exists)
        assert callable(ds.query)
        assert callable(ds.list_keys)
        assert callable(ds.set_batch)
        assert callable(ds.delete_by_prefix)
        assert callable(ds.get_storage_info)


class TestMcpClient:
    """Tests for the MCP client API surface."""

    def test_mcp_client_has_all_methods(self) -> None:
        client = DaprHostClient("test-host", "ext-123")
        mcp = client.mcp_client

        assert callable(mcp.invoke_tool)
        assert callable(mcp.list_tools)
        assert callable(mcp.get_resource)
        assert callable(mcp.list_resources)


class TestPublishEvent:
    """Tests for event publishing payload construction."""

    @pytest.mark.asyncio
    async def test_publish_event_constructs_correct_payload(self) -> None:
        client = DaprHostClient("test-host", "ext-123")

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {}

            await client.publish_event("TestEvent", {"key": "value"})

            mock_invoke.assert_called_once_with(
                "event/publish",
                {
                    "extensionId": "ext-123",
                    "eventJson": json.dumps({"eventType": "TestEvent", "payload": {"key": "value"}}),
                },
            )

    @pytest.mark.asyncio
    async def test_publish_event_serializes_nested_payload(self) -> None:
        client = DaprHostClient("test-host", "ext-123")

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {}

            payload = {"items": [1, 2, 3], "nested": {"a": True}}
            await client.publish_event("ComplexEvent", payload)

            call_args = mock_invoke.call_args[0]
            event_json = json.loads(call_args[1]["eventJson"])
            assert event_json["eventType"] == "ComplexEvent"
            assert event_json["payload"] == payload
