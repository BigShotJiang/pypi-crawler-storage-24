"""
EthisysCore Plugin SDK for Python.

Build container-hosted plugins by extending ``PluginBase`` and starting with ``PluginHost``.

Example::

    from ethisyscore_plugin_sdk import PluginBase, PluginHost, PluginManifest, ToolResult

    class MyPlugin(PluginBase):
        @property
        def manifest(self) -> PluginManifest:
            return PluginManifest(
                id="my-plugin", name="My Plugin", version="1.0.0",
                type="TenantPlugin", owner="acme",
                compatible_core_version=">=1.0.0", mcp_version="1.0",
                execution_mode="Container",
                mcp_tools=[{"name": "greet", "description": "Say hello", "inputSchemaJson": "{}"}],
            )

        async def on_invoke_tool(self, tool_name: str, args: dict, context) -> ToolResult:
            return ToolResult(success=True, result_json='{"greeting": "Hello!"}')

    PluginHost(MyPlugin()).start()
"""

from .types import (
    PluginManifest,
    McpToolDefinition,
    McpResourceDefinition,
    ToolResult,
    ResourceResult,
    HealthResult,
    PluginContext,
)
from .plugin_base import PluginBase
from .plugin_host import PluginHost
from .dapr_host_client import DaprHostClient

__all__ = [
    "PluginBase",
    "PluginHost",
    "DaprHostClient",
    "PluginManifest",
    "McpToolDefinition",
    "McpResourceDefinition",
    "ToolResult",
    "ResourceResult",
    "HealthResult",
    "PluginContext",
]
