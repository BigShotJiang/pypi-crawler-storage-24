"""
EthisysCore Plugin SDK — Pydantic models for the HTTP plugin contract.
"""

from __future__ import annotations

from typing import Any, Optional, Protocol, runtime_checkable

from pydantic import BaseModel, Field


# ── Plugin Manifest ───────────────────────────────────────────────────────────


class McpToolDefinition(BaseModel):
    name: str
    description: str
    input_schema_json: str = Field(alias="inputSchemaJson", default="{}")
    required_permission: Optional[int] = Field(
        alias="requiredPermission",
        default=None,
        description=(
            "Permission required to invoke this tool. Mirrors the backend ToolPermission enum. "
            "Values: Assign=1, View=2, Delete=4, Write=8, Read=16. Defaults to Write (8) when omitted."
        ),
    )


class McpResourceDefinition(BaseModel):
    uri: str
    name: str
    description: str
    mime_type: str | None = Field(alias="mimeType", default=None)


class PluginManifest(BaseModel):
    id: str
    name: str
    version: str
    type: str  # "GlobalPlugin" | "TenantPlugin"
    owner: str
    compatible_core_version: str = Field(alias="compatibleCoreVersion")
    mcp_version: str = Field(alias="mcpVersion")
    execution_mode: str = Field(alias="executionMode", default="Container")
    group_code: str | None = Field(alias="groupCode", default=None)
    container_image_uri: str | None = Field(alias="containerImageUri", default=None)
    mcp_tools: list[McpToolDefinition] = Field(alias="mcpTools", default_factory=list)
    mcp_resources: list[McpResourceDefinition] = Field(alias="mcpResources", default_factory=list)

    model_config = {"populate_by_name": True}


# ── Tool / Resource Results ───────────────────────────────────────────────────


class ToolResult(BaseModel):
    success: bool
    result_json: str | None = Field(alias="resultJson", default=None)
    error: str | None = None

    model_config = {"populate_by_name": True}


class ResourceResult(BaseModel):
    success: bool
    content: str | None = None  # Base64-encoded
    mime_type: str | None = Field(alias="mimeType", default=None)
    error: str | None = None

    model_config = {"populate_by_name": True}


class HealthResult(BaseModel):
    status: int = 0  # 0=Healthy, 1=Degraded, 2=Unhealthy
    message: str | None = None


# ── Service Protocols ─────────────────────────────────────────────────────────


@runtime_checkable
class PluginDataStoreProtocol(Protocol):
    """Protocol for the plugin data store provided by the host."""

    async def get(self, key: str) -> Any: ...
    async def set(self, key: str, value: Any) -> None: ...
    async def delete(self, key: str) -> bool: ...
    async def exists(self, key: str) -> bool: ...
    async def list_keys(self, prefix: str) -> list[str]: ...
    async def query(self, prefix: str) -> list[dict[str, Any]]: ...


@runtime_checkable
class PluginLoggerProtocol(Protocol):
    """Protocol for the plugin logger provided by the host."""

    def info(self, message: str, *args: Any) -> None: ...
    def warning(self, message: str, *args: Any) -> None: ...
    def error(self, message: str, *args: Any) -> None: ...
    def debug(self, message: str, *args: Any) -> None: ...


@runtime_checkable
class McpClientProtocol(Protocol):
    """Protocol for the MCP client provided by the host."""

    async def invoke_tool(self, tool_name: str, arguments_json: str = "{}") -> Any: ...
    async def list_tools(self) -> list[Any]: ...
    async def get_resource(self, uri: str) -> Any: ...
    async def list_resources(self) -> list[Any]: ...


# ── Plugin Context ────────────────────────────────────────────────────────────


class PluginContext:
    """Runtime context provided to plugin methods."""

    def __init__(
        self,
        extension_id: str,
        organisation_id: str,
        tenant_id: str,
        host_app_id: str,
        data_store: PluginDataStoreProtocol,
        logger: PluginLoggerProtocol,
        mcp_client: McpClientProtocol,
        publish_event: Any = None,
    ) -> None:
        self.extension_id = extension_id
        self.organisation_id = organisation_id
        self.tenant_id = tenant_id
        self.host_app_id = host_app_id
        self.data_store = data_store
        self.logger = logger
        self.mcp_client = mcp_client
        self._publish_event = publish_event

    async def publish_event(self, event_type: str, payload: Any) -> None:
        """Publish a domain event to the host for distribution via the event bus."""
        if self._publish_event is not None:
            await self._publish_event(event_type, payload)
