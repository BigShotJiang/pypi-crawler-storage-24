"""
HTTP server implementing the EthisysCore container plugin contract.
"""

from __future__ import annotations

import json
import logging
import os
import time
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .dapr_host_client import DaprHostClient
from .plugin_base import PluginBase
from .types import PluginContext

_logger = logging.getLogger("ethisyscore.plugin")


class PluginHost:
    """
    HTTP server that implements the EthisysCore container plugin contract.

    Maps all required endpoints and delegates to a PluginBase instance.

    Example::

        from ethisyscore_plugin_sdk import PluginBase, PluginHost

        class MyPlugin(PluginBase):
            ...

        PluginHost(MyPlugin()).start()
    """

    def __init__(self, plugin: PluginBase, port: int | None = None) -> None:
        self.plugin = plugin
        self.port = port or int(os.environ.get("DAPR_APP_PORT", "8080"))
        self._context: PluginContext | None = None
        self._host_client: DaprHostClient | None = None

        @asynccontextmanager
        async def lifespan(_app: FastAPI):  # type: ignore[no-untyped-def]
            yield
            if self._host_client is not None:
                await self._host_client.close()

        self._app = FastAPI(
            title=f"EthisysCore Plugin: {plugin.manifest.name}",
            lifespan=lifespan,
        )
        self._register_routes()

    def start(self) -> None:
        """Start the plugin HTTP server."""
        import uvicorn

        _logger.info(
            "Starting plugin %s v%s on port %d",
            self.plugin.manifest.name,
            self.plugin.manifest.version,
            self.port,
        )
        uvicorn.run(self._app, host="0.0.0.0", port=self.port, log_level="info")

    def _register_routes(self) -> None:
        app = self._app

        @app.post("/plugin/initialize")
        async def initialize(request: Request) -> JSONResponse:
            try:
                body = await request.json()
                extension_id = body.get("extensionId", "")
                host_app_id = body.get("hostAppId", "")
                host_client = DaprHostClient(host_app_id, extension_id)
                self._host_client = host_client

                self._context = PluginContext(
                    extension_id=extension_id,
                    organisation_id=body.get("organisationId", ""),
                    tenant_id=body.get("tenantId", ""),
                    host_app_id=host_app_id,
                    data_store=host_client.data_store,
                    logger=host_client.logger,
                    mcp_client=host_client.mcp_client,
                    publish_event=host_client.publish_event,
                )

                await self.plugin.on_initialize(self._context)

                manifest_json = self.plugin.manifest.model_dump_json(by_alias=True)
                return JSONResponse({"success": True, "manifestJson": manifest_json})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/enable")
        async def enable() -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                await self.plugin.on_enable(self._context)
                return JSONResponse({"success": True})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/disable")
        async def disable() -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                await self.plugin.on_disable(self._context)
                return JSONResponse({"success": True})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/invoke-tool")
        async def invoke_tool(request: Request) -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                body = await request.json()
                tool_name: str = body.get("toolName", "")
                arguments_json: str = body.get("argumentsJson", "{}")
                args: dict[str, Any] = json.loads(arguments_json)

                result = await self.plugin.on_invoke_tool(tool_name, args, self._context)
                return JSONResponse(result.model_dump(by_alias=True))
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/get-resource")
        async def get_resource(request: Request) -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                body = await request.json()
                resource_uri: str = body.get("resourceUri", "")

                result = await self.plugin.on_get_resource(resource_uri, self._context)
                return JSONResponse(result.model_dump(by_alias=True))
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.get("/plugin/health")
        async def health() -> JSONResponse:
            try:
                result = await self.plugin.on_check_health()
                return JSONResponse(result.model_dump())
            except Exception as exc:
                return JSONResponse({"status": 2, "message": str(exc)})

        @app.get("/plugin/heartbeat")
        async def heartbeat() -> JSONResponse:
            return JSONResponse({"timestamp": int(time.time() * 1000)})
