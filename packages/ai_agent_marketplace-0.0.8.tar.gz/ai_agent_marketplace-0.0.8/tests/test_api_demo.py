# -*- coding: utf-8 -*-
# @Time    : 2025/03/01

import json
import ai_agent_marketplace as aam


from ai_agent_marketplace import OneKeyAgentRouter

def run_google_search():
    """

    """
    ### MCP Router Style
    example = {"server_name":"google-maps","tool_name":"maps_directions","tool_input":{"destination":"New York","mode":"driving","origin":"Boston"}}
    server_name = example.get("server_name", "")

    ## 1. MCP Initialize POST Request
    ONEKEY_BETA = "BETA_TEST_KEY_OCT_2025"
    router = OneKeyMCPRouter(server_name=server_name, onekey=ONEKEY_BETA)

    ## 2. Check Available Tools, tools/list
    available_tools = router.tools_list(server_name)
    print (f"Server {server_name}|available_tools {available_tools}")

    ## Your LLM Code



    ## 3. Run Tool, Post tools/call request
    result_json = router.tools_call(server_name, example.get("tool_name", ""), example.get("tool_input", {}))
    print (f"Server {server_name}|tool_name {example.get("tool_name", "")} | tool_input {example.get("tool_input", {})} |result_json {result_json}")


    ## Agent Router Style, Start the API Client

    ## skill_name: google-maps, api_name: maps_directions, get_weather

    onekey = os.getenv("DEEPNLP_ONEKEY_ROUTER_ACCESS", "BETA_TEST_KEY_OCT_2025")
    server_name = "google-maps"
    router = OneKeyAgentRouter(server_name=server_name, onekey=onekey)
    results = router.tools_call(server_name,
                                    "maps_directions",
                                    payload = {
                                        "destination": "New York",
                                        "mode": "driving",
                                        "origin": "Boston"
                                      }
    )

def main():

    run_search_api()
    run_search_api_id()
    run_search_api_batch()
    register_ai_agent_from_dict()
    register_ai_agent_from_github()

if __name__ == '__main__':
    main()
