import asyncio
import functools
import traceback
from collections import defaultdict
from typing import Callable, List, Dict, Any

KEY_CALL_COUNT = "call_count"
KEY_STATUS = "status"
STATUS_SUCCESS = "success"
STATUS_FAIL = "fail"

class BaseMonitor:
    def __init__(self, log_func: Callable, unified_keys: List[str], interval: int = 300):
        """
        :param log_func: The logging function to call (log_api_detail_running).
        :param unified_keys: List of keys to track (e.g., ["onekey", "api_id", "method", "status"]).
        :param interval: Time in seconds between reports.
        """
        self.log_func = log_func
        self.unified_keys = unified_keys
        self.interval = interval
        self.metrics = defaultdict(int)
        self.loop_started = False
        self._task: asyncio.Task | None = None

    async def _flush_loop(self):
        while True:
            await asyncio.sleep(self.interval)
            print("[Monitor] flush tick — metrics size:", len(self.metrics))

            if self.metrics:
                # Take a snapshot and clear the memory for the next window
                snapshot = dict(self.metrics)
                self.metrics.clear()

                for key_tuple, count in snapshot.items():
                    # HIGHLIGHT: Create the data object from the identity tuple
                    data_packet = dict(zip(self.unified_keys, key_tuple))

                    # Extract mandatory positional args for your specific function
                    # onekey = data_packet.pop("onekey", "")
                    # api_id = data_packet.pop("api_id", "")

                    ## add key: call_count
                    await self.log_func(
                        call_count = count,
                        **data_packet
                    )

                    # Call the actual logging function with the aggregated count
                    # await self.log_func(
                    #     onekey=onekey,
                    #     api_id=api_id,
                    #     callCount=count,
                    #     **data_packet
                    # )
            else:
                print("[Monitor] flush tick — metrics size 0 nothing to flush...")

    def track_request(self, **tracking_values):
        def decorator(func: Callable):
            @functools.wraps(func)
            async def wrapper(*args, **kwargs):

                print("[Monitor] entering wrapper function calls....")
                if not self.loop_started:
                    self.loop_started = True
                    self._task = asyncio.create_task(self._flush_loop())

                # Track success or failure
                status_value = STATUS_SUCCESS
                try:
                    if asyncio.iscoroutinefunction(func):
                        return await func(*args, **kwargs)
                    return func(*args, **kwargs)
                except Exception as e:
                    status_value = STATUS_FAIL
                    raise e
                finally:
                    # HIGHLIGHT: Merge decorator keys with the execution status
                    # This ensures {(key1, key2, "success"): 1} and {(key1, key2, "failed"): 1} are separate
                    current_context = {**tracking_values, KEY_STATUS: status_value}

                    # Extract only the keys defined in unified_keys to create the "Identity"
                    key_identity = tuple(current_context.get(k) for k in self.unified_keys)
                    self.metrics[key_identity] += 1

            return wrapper

        return decorator

DEBUG_MODE = True
LOG_ENABLE = True
if DEBUG_MODE:
    MCP_ONEKEY_RECORD_USAGE_ENDPOINT = "http://127.0.0.1:8080/api/billing/record-usage-detailed"
else:
    MCP_ONEKEY_RECORD_USAGE_ENDPOINT = "https://www.deepnlp.org/api/billing/record-usage-detailed"

async def log_api_detail_running(onekey: str = "", api_id: str = "", **kwargs):
    """
        Check the balance of Credit, create a new httpx server
        Args:

        Return:
            Dict, KEY_STATUS: true/false
    """
    if onekey is None or onekey.strip() == "":
        return {KEY_STATUS: False, KEY_MESSAGE: ""}
    payload = {}
    try:
        ## debug
        # return {"status": True, "message": "", "credential": authen_credential}

        """
            {"code":200,"data":{"accessKey":"BETA_TEST_KEY_OCT_2025","canProceed":true,"callCount":3,"hasSufficientCredits":true,"apiId":"agent.deepnlp.org/mcp/amap-maps-streamableHTTP"},"success":true,"message":"检查通过，可以继续调用"}
        """
        async with httpx.AsyncClient() as client:

            KEY_SUCCESS = "success"
            KEY_REQUEST_PARAMS = "requestParams"

            success = kwargs[KEY_SUCCESS] if KEY_SUCCESS in kwargs else False
            request_params = kwargs[KEY_REQUEST_PARAMS] if KEY_REQUEST_PARAMS in kwargs else False

            call_count = kwargs.get(KEY_CALL_COUNT, 1)

            payload = {
                "accessKey": onekey,
                "apiId": api_id,
                "callCount": call_count
            }

            payload.update(kwargs)
            if LOG_ENABLE:
                print(f"DEBUG: log_api_detail_running Started onekey {onekey} and payload {payload}")

            response = await client.post(
                MCP_ONEKEY_RECORD_USAGE_ENDPOINT,
                json=payload,
                timeout=TIMEOUT_GENERAL
            )

            status = False
            message = ""
            if response.status_code == 200:
                response_data = response.json()
                if LOG_ENABLE:
                    print(f"DEBUG: log_api_detail_running Server Center Response Data {response_data}")

                data = response_data.get("data", {})
                success = response_data.get("success", False)
                status = success
            else:
                status = False
                message = "Failed to Log Detailed Usage"

            result = {KEY_STATUS: status, KEY_MESSAGE: message}
            print(
                f"log_api_detail_running access key status {status} | onekey {onekey} API ID {api_id} check_credit_balance {result}")

            # A successful authentication response with the credential.
            return result

    except Exception as e:
        # import traceback
        # traceback.print_exc()
        logging.error(
            f"log_api_detail_running log payload error|onekey {onekey}|api_id {api_id}|payload {payload}|failed with error|{e}")
        return {KEY_STATUS: False, KEY_MESSAGE: ""}

def main():
    """
    """
    from mcp.server.fastmcp import FastMCP

    AGENT_NAME = "Demo Agent"
    mcp = FastMCP(AGENT_NAME, json_response=True)

    access_key = "my_unique_access_key"
    api_id = "api_add_tool"
    method = "tools/call"

    ## define monitor to extract the unified keys to merge the tracking tuple, {(key1, key2, key3): 1}
    monitor = BaseMonitor(
        log_func=log_api_detail_running,
        unified_keys=["onekey", "api_id", "method", "status"],
        interval = 10
    )

    ## success
    onekey = "KEY_123"
    api_id = "tool_A"
    callCount = 4
    kwargs = {"method": "tools/call", "status": "success"}

    ## failure
    onekey = "KEY_123"
    api_id = "tool_A"
    callCount = 1
    kwargs = {"method": "tools/call", "status": "failed"}

    @monitor.track_request(onekey=onekey, api_id = api_id, method=method)
    @mcp.tool()
    def add_tool(
            a: int,
            b: int
        ) -> int:
        """
        """
        return a + b
    mcp.run("streamable-http")

if __name__ == "__main__":
    main()