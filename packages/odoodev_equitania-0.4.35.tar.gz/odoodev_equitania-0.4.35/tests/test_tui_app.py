"""Tests for odoodev.tui app, widgets, and screens."""

import sys

import pytest
from textual.widgets import Static

from odoodev.tui.app import FILTER_LEVELS, OdooTuiApp
from odoodev.tui.widgets.log_viewer import LEVEL_STYLES, LogViewer
from odoodev.tui.widgets.status_bar import StatusBar


@pytest.fixture
def mock_cmd(tmp_path):
    """Create a mock Odoo process command."""
    script = tmp_path / "mock_odoo.py"
    script.write_text(
        "import time, sys\n"
        "lines = [\n"
        '    "2025-03-15 10:00:00,000 999 INFO test_db odoo.modules.loading: Loading module base",\n'
        '    "2025-03-15 10:00:01,000 999 WARNING test_db odoo.models: Deprecated field",\n'
        '    "2025-03-15 10:00:02,000 999 ERROR test_db odoo.http: Request failed",\n'
        '    "2025-03-15 10:00:03,000 999 DEBUG test_db odoo.sql_db: query took 0.003s",\n'
        "]\n"
        "for line in lines:\n"
        "    print(line, flush=True)\n"
        "    time.sleep(0.05)\n"
        "try:\n"
        "    time.sleep(60)\n"
        "except (KeyboardInterrupt, SystemExit):\n"
        "    pass\n"
    )
    return [sys.executable, str(script)]


def make_app(mock_cmd, tmp_path):
    """Create a test TUI app instance."""
    return OdooTuiApp(
        cmd=mock_cmd,
        env={},
        cwd=str(tmp_path),
        version_info="18",
        odoo_port=18069,
        db_name="v18_exam",
    )


class TestLogViewer:
    """Test LogViewer widget functionality."""

    def test_level_styles_complete(self):
        assert "ERROR" in LEVEL_STYLES
        assert "WARNING" in LEVEL_STYLES
        assert "INFO" in LEVEL_STYLES
        assert "DEBUG" in LEVEL_STYLES
        assert "CRITICAL" in LEVEL_STYLES
        assert "RAW" in LEVEL_STYLES

    def test_error_style_is_red(self):
        assert "red" in LEVEL_STYLES["ERROR"]

    def test_warning_style_is_yellow(self):
        assert "yellow" in LEVEL_STYLES["WARNING"]


class TestStatusBar:
    """Test StatusBar widget functionality."""

    def test_format_uptime(self):
        bar = StatusBar()
        bar.uptime_seconds = 3661.0  # 1h 1m 1s
        assert bar._format_uptime() == "01:01:01"

    def test_format_uptime_zero(self):
        bar = StatusBar()
        bar.uptime_seconds = 0.0
        assert bar._format_uptime() == "00:00:00"

    def test_format_uptime_large(self):
        bar = StatusBar()
        bar.uptime_seconds = 86400.0  # 24 hours
        assert bar._format_uptime() == "24:00:00"

    def test_render_status_stopped(self):
        bar = StatusBar()
        bar.server_state = "stopped"
        bar.version = "18"
        bar.port = 18069
        status = bar._render_status()
        assert "Stopped" in status
        assert "v18" in status

    def test_render_status_running(self):
        bar = StatusBar()
        bar.server_state = "running"
        bar.version = "18"
        bar.port = 18069
        bar.uptime_seconds = 60.0
        status = bar._render_status()
        assert "Running" in status
        assert "00:01:00" in status

    def test_render_status_with_db(self):
        bar = StatusBar()
        bar.server_state = "running"
        bar.db_name = "v18_exam"
        status = bar._render_status()
        assert "v18_exam" in status


class TestFilterLevels:
    """Test filter level cycling."""

    def test_filter_levels_no_raw(self):
        assert "RAW" not in FILTER_LEVELS

    def test_filter_levels_order(self):
        assert FILTER_LEVELS == ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]


class TestOdooTuiAppIntegration:
    """Integration tests using Textual's async test runner."""

    async def test_app_starts_and_has_widgets(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as _pilot:
            # Verify core widgets exist
            assert app.query_one("#status-bar", StatusBar) is not None
            assert app.query_one("#filter-bar", Static) is not None
            assert app.query_one("#log-viewer", LogViewer) is not None

    async def test_app_receives_log_output(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            # Wait for process to produce output
            await pilot.pause(1.0)
            log_viewer = app.query_one("#log-viewer", LogViewer)
            assert log_viewer.entry_count > 0

    async def test_cycle_filter(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            log_viewer = app.query_one("#log-viewer", LogViewer)
            assert log_viewer.min_level == "DEBUG"

            await pilot.press("f")
            assert log_viewer.min_level == "INFO"

            await pilot.press("f")
            assert log_viewer.min_level == "WARNING"

    async def test_toggle_auto_scroll(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            log_viewer = app.query_one("#log-viewer", LogViewer)
            assert log_viewer.auto_scroll is True

            await pilot.press("space")
            assert log_viewer.auto_scroll is False

            await pilot.press("space")
            assert log_viewer.auto_scroll is True

    async def test_clear_log_clears_buffer(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.5)
            log_viewer = app.query_one("#log-viewer", LogViewer)
            assert log_viewer.entry_count > 0  # Has entries before clear
            await pilot.press("ctrl+l")
            assert log_viewer.entry_count == 0  # Buffer cleared

    async def test_clear_log_empties_clipboard_copy(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(1.0)
            log_viewer = app.query_one("#log-viewer", LogViewer)
            assert log_viewer.get_errors_text() != ""  # Has errors before clear
            await pilot.press("ctrl+l")
            assert log_viewer.get_errors_text() == ""  # Empty after clear
            assert log_viewer.get_visible_text() == ""

    async def test_clear_log_prevents_filter_restore(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.5)
            log_viewer = app.query_one("#log-viewer", LogViewer)
            assert log_viewer.entry_count > 0
            await pilot.press("ctrl+l")
            assert log_viewer.entry_count == 0
            # Cycling filter should NOT bring back cleared entries
            await pilot.press("f")  # INFO
            assert log_viewer.entry_count == 0
            await pilot.press("f")  # WARNING
            assert log_viewer.entry_count == 0

    async def test_quit_stops_process(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.3)
            assert app._odoo.is_running is True
            await pilot.press("q")
        # After exit, process should be stopped
        assert app._odoo.is_running is False

    async def test_ctrl_q_stops_process(self, mock_cmd, tmp_path):
        """Ctrl+Q must also stop the Odoo process (not just 'q')."""
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.3)
            assert app._odoo.is_running is True
            await pilot.press("ctrl+q")
        # After exit, process should be stopped
        assert app._odoo.is_running is False

    async def test_action_quit_override_stops_process(self, mock_cmd, tmp_path):
        """Textual's action_quit override must stop the Odoo process."""
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.3)
            assert app._odoo.is_running is True
            # Call action_quit directly (simulates any Textual quit path)
            app.action_quit()
        assert app._odoo.is_running is False

    async def test_status_bar_updates(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.5)
            status_bar = app.query_one("#status-bar", StatusBar)
            assert status_bar.version == "18"
            assert status_bar.port == 18069
            assert status_bar.db_name == "v18_exam"

    async def test_get_visible_text(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(1.0)
            log_viewer = app.query_one("#log-viewer", LogViewer)
            text = log_viewer.get_visible_text()
            assert "Loading module base" in text

    async def test_get_errors_text(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(1.0)
            log_viewer = app.query_one("#log-viewer", LogViewer)
            errors = log_viewer.get_errors_text()
            assert "Request failed" in errors
            assert "Loading module base" not in errors

    async def test_get_warnings_and_errors_text(self, mock_cmd, tmp_path):
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(1.0)
            log_viewer = app.query_one("#log-viewer", LogViewer)
            text = log_viewer.get_warnings_and_errors_text()
            assert "Deprecated field" in text
            assert "Request failed" in text
            assert "Loading module base" not in text


class TestTracebackCollection:
    """Test that error/warning copy includes traceback continuation lines."""

    def test_errors_include_traceback(self):
        from odoodev.tui.log_parser import parse_line

        viewer = LogViewer()
        # Simulate buffer directly
        lines = [
            "2025-03-15 10:00:00,000 999 INFO db odoo.modules: Starting",
            "2025-03-15 10:00:01,000 999 ERROR db odoo.http: Exception during request handling.",
            "Traceback (most recent call last):",
            '  File "/server/odoo/http.py", line 2825, in __call__',
            "    response = request._serve_db()",
            "TypeError: cannot unpack non-iterable NoneType object",
            "2025-03-15 10:00:02,000 999 INFO db odoo.modules: Loaded",
        ]
        for line in lines:
            viewer._buffer.append(parse_line(line))

        errors = viewer.get_errors_text()
        assert "Exception during request handling" in errors
        assert "Traceback (most recent call last):" in errors
        assert "TypeError: cannot unpack" in errors
        assert "Starting" not in errors
        assert "Loaded" not in errors

    def test_warnings_include_traceback(self):
        from odoodev.tui.log_parser import parse_line

        viewer = LogViewer()
        lines = [
            "2025-03-15 10:00:00,000 999 WARNING db odoo.models: Deprecated field usage",
            "  some continuation detail",
            "2025-03-15 10:00:01,000 999 INFO db odoo.modules: Done",
        ]
        for line in lines:
            viewer._buffer.append(parse_line(line))

        text = viewer.get_warnings_and_errors_text()
        assert "Deprecated field usage" in text
        assert "some continuation detail" in text
        assert "Done" not in text

    def test_no_traceback_between_separate_errors(self):
        from odoodev.tui.log_parser import parse_line

        viewer = LogViewer()
        lines = [
            "2025-03-15 10:00:00,000 999 ERROR db odoo.http: First error",
            "2025-03-15 10:00:01,000 999 INFO db odoo.modules: Info between",
            "2025-03-15 10:00:02,000 999 ERROR db odoo.http: Second error",
            "Traceback for second error",
        ]
        for line in lines:
            viewer._buffer.append(parse_line(line))

        errors = viewer.get_errors_text()
        assert "First error" in errors
        assert "Info between" not in errors
        assert "Second error" in errors
        assert "Traceback for second error" in errors


class TestLanguageLoadScreen:
    """Test LanguageLoadScreen integration."""

    async def test_language_load_keybinding(self, mock_cmd, tmp_path):
        """'l' key opens LanguageLoadScreen."""
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.3)
            await pilot.press("l")
            await pilot.pause(0.1)
            from odoodev.tui.screens import LanguageLoadScreen

            assert any(isinstance(s, LanguageLoadScreen) for s in app.screen_stack)

    async def test_language_load_screen_has_widgets(self, mock_cmd, tmp_path):
        """LanguageLoadScreen has input, checkbox, and buttons."""
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.3)
            await pilot.press("l")
            await pilot.pause(0.1)
            from textual.widgets import Button, Checkbox, Input

            screen = app.screen_stack[-1]
            assert screen.query_one("#lang-input", Input) is not None
            assert screen.query_one("#lang-overwrite", Checkbox) is not None
            assert screen.query_one("#btn-load", Button) is not None
            assert screen.query_one("#btn-cancel", Button) is not None

    async def test_language_load_cancel(self, mock_cmd, tmp_path):
        """Cancel button dismisses the dialog."""
        app = make_app(mock_cmd, tmp_path)
        async with app.run_test(size=(120, 30)) as pilot:
            await pilot.pause(0.3)
            await pilot.press("l")
            await pilot.pause(0.1)
            from odoodev.tui.screens import LanguageLoadScreen

            assert any(isinstance(s, LanguageLoadScreen) for s in app.screen_stack)
            # Click cancel
            cancel_btn = app.screen_stack[-1].query_one("#btn-cancel")
            cancel_btn.press()
            await pilot.pause(0.1)
            assert not any(isinstance(s, LanguageLoadScreen) for s in app.screen_stack)


class TestClipboard:
    """Test clipboard copy functionality."""

    def test_copy_to_clipboard_returns_bool(self):
        result = OdooTuiApp._copy_to_clipboard("test")
        assert isinstance(result, bool)

    def test_copy_empty_string(self):
        assert OdooTuiApp._copy_to_clipboard("") is True
