#!/usr/bin/env python3
"""
vssh MCP Server - High-speed file transfer and remote execution

Tools:
- vssh_status: Connection status to all servers
- vssh_exec: Execute command on remote server
- vssh_put: Upload file to server
- vssh_get: Download file from server
- vssh_sync: Sync directory between servers
- vssh_p2p_status: P2P connection status
- vssh_speed_test: Test transfer speed

Run: python3 vssh-mcp-server.py
"""

import json
import subprocess
import sys
import os
import socket
import time
import hashlib
import signal
import atexit

# === Singleton: Only one instance allowed ===
# PID_FILE removed — Claude Desktop manages process lifecycle

# cleanup_pid removed — singleton pattern disabled

# ensure_singleton removed — Claude Desktop manages process lifecycle

# ensure_singleton() disabled

# Configuration
VSSH_PORT = 48291
VSSH_SECRET = os.environ.get("VSSH_SECRET", "")
CONFIG_PATH = os.path.expanduser("~/.mpop/config.json")

def load_config():
    """Load mpop config"""
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except (json.JSONDecodeError, ValueError) as e:
        return {}

def get_servers():
    """Get server list from config"""
    config = load_config()
    return config.get("servers", {})

def get_secret():
    """Get vssh secret"""
    global VSSH_SECRET
    if VSSH_SECRET:
        return VSSH_SECRET
    config = load_config()
    VSSH_SECRET = config.get("vssh_secret", "")
    return VSSH_SECRET

# MCP Protocol (line-delimited JSON)
def send_response(response):
    """Send JSON-RPC response - line-delimited JSON"""
    output = json.dumps(response)
    sys.stdout.write(output + "\n")
    sys.stdout.flush()

def read_request():
    """Read JSON-RPC request - line-delimited JSON"""
    line = sys.stdin.readline()
    if not line:
        return None
    line = line.strip()
    if not line:
        return None
    try:
        return json.loads(line)
    except json.JSONDecodeError:
        return None

# vssh Protocol Implementation
_ts_map_cache = None
_failover_cache = {}  # wire_ip -> tailscale_ip

def _get_tailscale_map():
    """Build Wire IP → Tailscale IP map from mpop config"""
    global _ts_map_cache
    if _ts_map_cache is not None:
        return _ts_map_cache
    servers = get_servers()
    _ts_map_cache = {}
    for name, srv in servers.items():
        wire_ip = srv.get("ip", "")
        ts_ip = srv.get("tailscale_ip", "")
        if wire_ip and ts_ip:
            _ts_map_cache[wire_ip] = ts_ip
    # Also load from ~/.vssh/tailscale_map if exists
    ts_file = os.path.expanduser("~/.vssh/tailscale_map")
    if os.path.exists(ts_file):
        try:
            with open(ts_file) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split()
                    if len(parts) >= 2:
                        _ts_map_cache[parts[0]] = parts[1]
        except OSError as e:
            pass  # TODO: log error
    return _ts_map_cache

def vssh_connect(ip: str, timeout: int = 5) -> socket.socket:
    """Connect to vssh server with Tailscale failover.

    1. Try Wire VPN IP (primary)
    2. If Wire fails → try Tailscale IP (fallback)
    """
    # If previously failed over, try Tailscale first
    if ip in _failover_cache:
        ts_ip = _failover_cache[ip]
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            sock.connect((ts_ip, VSSH_PORT))
            return sock
        except OSError as e:
            del _failover_cache[ip]

    # Primary: Wire VPN
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((ip, VSSH_PORT))
        return sock
    except OSError as e:
        pass  # TODO: log error

    # Fallback: Tailscale
    ts_map = _get_tailscale_map()
    ts_ip = ts_map.get(ip)
    if not ts_ip:
        raise ConnectionError(f"Wire failed for {ip}, no Tailscale mapping")

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    sock.connect((ts_ip, VSSH_PORT))
    _failover_cache[ip] = ts_ip
    return sock

def vssh_exec_cmd(ip: str, cmd: str, timeout: int = 30) -> str:
    """Execute command via vssh"""
    try:
        sock = vssh_connect(ip, timeout)
        secret = get_secret()
        sock.sendall(f"SSH:{secret}:{cmd}\n".encode())

        resp = sock.recv(64)
        if not resp.startswith(b'OK'):
            return f"Error: {resp.decode()}"

        data = b''
        while True:
            chunk = sock.recv(8192)
            if not chunk or b'__END__' in chunk:
                data += chunk.replace(b'__END__', b'')
                break
            data += chunk

        sock.close()
        return data.decode('utf-8', errors='replace').strip()
    except Exception as e:
        return f"Error: {e}"

CHUNK_SIZE = 1024 * 1024  # 1MB chunks for streaming

def vssh_upload(ip: str, local_path: str, remote_path: str) -> dict:
    """Upload file via vssh — streams in chunks, works for any file size"""
    try:
        if not os.path.exists(local_path):
            return {"error": f"Local file not found: {local_path}"}

        size = os.path.getsize(local_path)

        # Compute MD5 in streaming fashion (no full-file memory load)
        md5_hash = hashlib.md5()
        with open(local_path, 'rb') as f:
            while True:
                block = f.read(CHUNK_SIZE)
                if not block:
                    break
                md5_hash.update(block)
        md5 = md5_hash.hexdigest()

        # Dynamic timeout: at least 60s, or 1s per MB (for large files)
        timeout = max(60, size // (1024 * 1024) + 30)
        sock = vssh_connect(ip, timeout)
        secret = get_secret()

        # Send PUT command
        header = f"PUT:{secret}:{remote_path}:{size}:{md5}\n"
        sock.sendall(header.encode())

        resp = sock.recv(64)
        if not resp.startswith(b'OK'):
            sock.close()
            return {"error": resp.decode().strip()}

        # Stream file data in chunks (no full-file memory load)
        start = time.time()
        sent = 0
        with open(local_path, 'rb') as f:
            while sent < size:
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break
                sock.sendall(chunk)
                sent += len(chunk)

        # Wait for server confirmation
        sock.settimeout(60)  # final OK may arrive after server hashes file
        resp = sock.recv(64)
        elapsed = time.time() - start

        sock.close()

        if b'OK' in resp:
            speed = size / elapsed / 1024 / 1024 if elapsed > 0 else 0
            return {
                "status": "success",
                "size": size,
                "speed_mbps": round(speed, 2),
                "elapsed": round(elapsed, 2),
                "remote_path": remote_path
            }
        else:
            return {"error": resp.decode().strip()}

    except Exception as e:
        return {"error": str(e)}

def vssh_download(ip: str, remote_path: str, local_path: str) -> dict:
    """Download file via vssh"""
    try:
        sock = vssh_connect(ip, 30)
        secret = get_secret()

        # Send GET command
        header = f"GET:{secret}:{remote_path}\n"
        sock.sendall(header.encode())

        # Read response header
        resp = sock.recv(256)
        if not resp.startswith(b'OK:'):
            return {"error": resp.decode()}

        # Parse size — format: OK:<size>\n or OK:<size>:<checksum>\n
        try:
            parts = resp.decode().split(':')
            size = int(parts[1].strip())
        except (IndexError, ValueError) as parse_err:
            return {"error": f"Unexpected server response: {resp[:64]!r} ({parse_err})"}

        # Stream file data directly to disk (no full-file memory load)
        local_dir = os.path.dirname(os.path.abspath(local_path))
        os.makedirs(local_dir, exist_ok=True)
        start = time.time()
        received = 0
        with open(local_path, 'wb') as f:
            while received < size:
                chunk = sock.recv(min(CHUNK_SIZE, size - received))
                if not chunk:
                    break
                f.write(chunk)
                received += len(chunk)

        elapsed = time.time() - start
        sock.close()

        if received < size:
            return {"error": f"Incomplete transfer: got {received}/{size} bytes"}

        speed = size / elapsed / 1024 / 1024 if elapsed > 0 else 0
        return {
            "status": "success",
            "size": size,
            "speed_mbps": round(speed, 2),
            "elapsed": round(elapsed, 2),
            "local_path": local_path
        }

    except Exception as e:
        return {"error": str(e)}

# Tool Implementations
def tool_vssh_status():
    """Check vssh connection status to all servers"""
    servers = get_servers()
    results = {}

    for name, srv in servers.items():
        ip = srv.get("ip", "")
        if not ip:
            continue

        try:
            start = time.time()
            sock = vssh_connect(ip, 3)
            latency = (time.time() - start) * 1000
            sock.close()
            results[name] = {
                "status": "online",
                "ip": ip,
                "latency_ms": round(latency, 1)
            }
        except OSError as e:
            results[name] = {
                "status": "offline",
                "ip": ip
            }

    online = sum(1 for r in results.values() if r["status"] == "online")
    return {
        "summary": f"{online}/{len(results)} online",
        "servers": results
    }

def tool_vssh_exec(server: str, command: str):
    """Execute command on remote server"""
    servers = get_servers()

    if server not in servers:
        return {"error": f"Unknown server: {server}"}

    ip = servers[server].get("ip", "")
    if not ip:
        return {"error": f"No IP for server: {server}"}

    output = vssh_exec_cmd(ip, command)
    return {
        "server": server,
        "command": command,
        "output": output
    }

def tool_vssh_put(server: str, local_path: str, remote_path: str):
    """Upload file to server"""
    servers = get_servers()

    if server not in servers:
        return {"error": f"Unknown server: {server}"}

    ip = servers[server].get("ip", "")
    return vssh_upload(ip, local_path, remote_path)

def tool_vssh_get(server: str, remote_path: str, local_path: str):
    """Download file from server"""
    servers = get_servers()

    if server not in servers:
        return {"error": f"Unknown server: {server}"}

    ip = servers[server].get("ip", "")
    return vssh_download(ip, remote_path, local_path)

def tool_vssh_sync(source: str, dest: str, path: str):
    """Sync directory from source server to dest server via local relay"""
    servers = get_servers()

    if source not in servers:
        return {"error": f"Unknown source server: {source}"}
    if dest not in servers:
        return {"error": f"Unknown dest server: {dest}"}

    src_ip = servers[source].get("ip", "").strip()
    dst_ip = servers[dest].get("ip", "").strip()

    if not src_ip:
        return {"error": f"No IP configured for source server: {source}"}
    if not dst_ip:
        return {"error": f"No IP configured for dest server: {dest}"}

    # Get file list from source
    files_output = vssh_exec_cmd(src_ip, f"find {path} -type f 2>/dev/null | head -100")
    if files_output.startswith("Error"):
        return {"error": f"Cannot list files on {source}: {files_output}"}

    files = [f.strip() for f in files_output.split("\n") if f.strip()]
    if not files:
        return {"source": source, "dest": dest, "path": path,
                "synced": 0, "message": "No files found at path"}

    # Relay: download each file from source, upload to dest
    import tempfile
    synced, failed = [], []
    with tempfile.TemporaryDirectory(prefix="vssh_sync_") as tmpdir:
        for remote_file in files:
            fname = os.path.basename(remote_file)
            local_tmp = os.path.join(tmpdir, fname)
            dl = vssh_download(src_ip, remote_file, local_tmp)
            if "error" in dl:
                failed.append({"file": remote_file, "error": dl["error"]})
                continue
            ul = vssh_upload(dst_ip, local_tmp, remote_file)
            if "error" in ul:
                failed.append({"file": remote_file, "error": ul["error"]})
            else:
                synced.append(remote_file)

    return {
        "source": source,
        "dest": dest,
        "path": path,
        "total_files": len(files),
        "synced": len(synced),
        "failed": len(failed),
        "errors": failed[:10] if failed else []
    }

def tool_vssh_speed_test(server: str, size_mb: int = 10):
    """Test transfer speed to server"""
    servers = get_servers()

    if server not in servers:
        return {"error": f"Unknown server: {server}"}

    ip = servers[server].get("ip", "")

    # Create test file
    test_data = os.urandom(size_mb * 1024 * 1024)
    test_file = f"/tmp/vssh_speedtest_{os.getpid()}.bin"
    remote_file = f"/tmp/vssh_speedtest_{os.getpid()}.bin"

    with open(test_file, 'wb') as f:
        f.write(test_data)

    # Upload test
    start = time.time()
    result = vssh_upload(ip, test_file, remote_file)
    upload_time = time.time() - start

    if "error" in result:
        os.remove(test_file)
        return result

    upload_speed = size_mb / upload_time if upload_time > 0 else 0

    # Download test
    start = time.time()
    result = vssh_download(ip, remote_file, test_file + ".down")
    download_time = time.time() - start

    download_speed = size_mb / download_time if download_time > 0 else 0

    # Cleanup
    os.remove(test_file)
    os.remove(test_file + ".down")
    vssh_exec_cmd(ip, f"rm -f {remote_file}")

    return {
        "server": server,
        "size_mb": size_mb,
        "upload_mbps": round(upload_speed, 2),
        "download_mbps": round(download_speed, 2),
        "latency_ms": round((upload_time + download_time) * 500 / size_mb, 1)
    }

def tool_vssh_p2p_status():
    """Check P2P connection capabilities"""
    # Check if P2P module is available
    try:
        from vssh_p2p import stun_get_external
        external = stun_get_external()
        return {
            "p2p_available": True,
            "external_ip": external[0] if external else "unknown",
            "external_port": external[1] if external else 0,
            "nat_type": "cone" if external else "unknown"
        }
    except Exception as e:
        return {
            "p2p_available": False,
            "note": "P2P module not loaded"
        }

def tool_vssh_tunnel(server: str, local_port: int, remote_port: int, remote_host: str = "localhost"):
    """Create SSH tunnel (port forwarding). Launches tunnel in background and returns PID."""
    servers = get_servers()

    if server not in servers:
        return {"error": f"Unknown server: {server}"}

    ip = servers[server].get("ip", "").strip()
    if not ip:
        return {"error": f"No IP configured for server: {server}"}

    user = servers[server].get("user", "root")

    # Check if local port is already in use
    import subprocess
    check = subprocess.run(
        f"lsof -i :{local_port} 2>/dev/null | grep LISTEN",
        shell=True, capture_output=True, text=True
    )
    if check.stdout.strip():
        # Check if it's already our tunnel
        if ip in check.stdout or server in check.stdout:
            return {
                "status": "already_running",
                "local_port": local_port,
                "message": f"Tunnel to {server}:{remote_port} already running on localhost:{local_port}"
            }
        return {
            "status": "port_in_use",
            "local_port": local_port,
            "message": f"Port {local_port} is already in use by another process"
        }

    # Build SSH tunnel command
    ssh_args = [
        "ssh", "-f", "-N",
        "-o", "StrictHostKeyChecking=no",
        "-o", "ConnectTimeout=10",
        "-o", "BatchMode=yes",
        "-L", f"{local_port}:{remote_host}:{remote_port}",
        f"{user}@{ip}"
    ]
    tunnel_cmd = " ".join(ssh_args)

    # Launch tunnel as background process
    try:
        proc = subprocess.Popen(
            ssh_args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            start_new_session=True
        )
        # Wait briefly to detect immediate failures
        import time
        time.sleep(1.5)
        if proc.poll() is not None:
            # Process already exited — SSH failed
            err = proc.stderr.read().decode(errors="replace").strip()
            return {
                "status": "failed",
                "error": f"SSH tunnel failed: {err or 'exited immediately'}",
                "command": tunnel_cmd,
                "hint": "Check SSH key auth: ssh-copy-id " + user + "@" + ip
            }

        # Verify port is now listening
        verify = subprocess.run(
            f"lsof -i :{local_port} 2>/dev/null | grep LISTEN",
            shell=True, capture_output=True, text=True
        )
        listening = bool(verify.stdout.strip())

        return {
            "status": "running" if listening else "started",
            "pid": proc.pid,
            "server": server,
            "local_port": local_port,
            "remote_host": remote_host,
            "remote_port": remote_port,
            "access": f"localhost:{local_port}",
            "usage": f"Connect to {remote_host}:{remote_port} on {server} via localhost:{local_port}",
            "close_cmd": f"kill {proc.pid}  # or: pkill -f \'ssh.*-L {local_port}\'"
        }

    except FileNotFoundError:
        return {
            "status": "no_ssh",
            "error": "ssh not found — install OpenSSH",
            "command": tunnel_cmd
        }
    except Exception as e:
        return {"status": "error", "error": str(e), "command": tunnel_cmd}

def tool_vssh_keys():
    """Manage vssh keys and secrets"""
    config = load_config()
    secret = config.get("vssh_secret", "")

    # Check key files
    key_dir = os.path.expanduser("~/.vssh")
    keys = {
        "secret_configured": bool(secret),
        "secret_preview": secret[:8] + "..." if secret else "not set",
        "key_directory": key_dir,
        "keys": []
    }

    if os.path.exists(key_dir):
        for f in os.listdir(key_dir):
            fpath = os.path.join(key_dir, f)
            if os.path.isfile(fpath):
                keys["keys"].append({
                    "name": f,
                    "size": os.path.getsize(fpath),
                    "permissions": oct(os.stat(fpath).st_mode)[-3:]
                })

    # Check servers with vssh server running
    servers = get_servers()
    keys["servers_with_vssh"] = []

    for name, srv in list(servers.items())[:5]:  # Check first 5
        ip = srv.get("ip", "")
        if ip:
            try:
                sock = vssh_connect(ip, timeout=2)
                sock.close()
                keys["servers_with_vssh"].append(name)
            except OSError as e:
                pass  # safe to ignore

    return keys

# MCP Tool Definitions
TOOLS = [
    {
        "name": "vssh_status",
        "description": "Check vssh connection status to all servers. Shows online/offline status and latency.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "vssh_exec",
        "description": "Execute a command on a remote server via vssh. Returns command output.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "server": {
                    "type": "string",
                    "description": "Server name (e.g., v1, g1, d1)"
                },
                "command": {
                    "type": "string",
                    "description": "Command to execute"
                }
            },
            "required": ["server", "command"]
        }
    },
    {
        "name": "vssh_put",
        "description": "Upload a file to a remote server via vssh. High-speed transfer (50+ MB/s).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "server": {
                    "type": "string",
                    "description": "Server name"
                },
                "local_path": {
                    "type": "string",
                    "description": "Local file path"
                },
                "remote_path": {
                    "type": "string",
                    "description": "Remote destination path"
                }
            },
            "required": ["server", "local_path", "remote_path"]
        }
    },
    {
        "name": "vssh_get",
        "description": "Download a file from a remote server via vssh.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "server": {
                    "type": "string",
                    "description": "Server name"
                },
                "remote_path": {
                    "type": "string",
                    "description": "Remote file path"
                },
                "local_path": {
                    "type": "string",
                    "description": "Local destination path"
                }
            },
            "required": ["server", "remote_path", "local_path"]
        }
    },
    {
        "name": "vssh_sync",
        "description": "List files to sync between two servers. Shows files that would be transferred.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "description": "Source server name"
                },
                "dest": {
                    "type": "string",
                    "description": "Destination server name"
                },
                "path": {
                    "type": "string",
                    "description": "Directory path to sync"
                }
            },
            "required": ["source", "dest", "path"]
        }
    },
    {
        "name": "vssh_speed_test",
        "description": "Test file transfer speed to a server. Uploads and downloads test data.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "server": {
                    "type": "string",
                    "description": "Server name to test"
                },
                "size_mb": {
                    "type": "integer",
                    "description": "Test file size in MB (default: 10)",
                    "default": 10
                }
            },
            "required": ["server"]
        }
    },
    {
        "name": "vssh_p2p_status",
        "description": "Check P2P (NAT hole-punch) connection capabilities for direct peer-to-peer transfers.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "vssh_tunnel",
        "description": "Create SSH tunnel (port forwarding) to access remote services locally. Launches tunnel in background, returns PID and access URL.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "server": {
                    "type": "string",
                    "description": "Server name to tunnel through"
                },
                "local_port": {
                    "type": "integer",
                    "description": "Local port to listen on"
                },
                "remote_port": {
                    "type": "integer",
                    "description": "Remote port to forward to"
                },
                "remote_host": {
                    "type": "string",
                    "description": "Remote host (default: localhost)",
                    "default": "localhost"
                }
            },
            "required": ["server", "local_port", "remote_port"]
        }
    },
    {
        "name": "vssh_keys",
        "description": "Manage vssh keys and secrets. Shows configured secrets and available servers.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    }
]

def handle_request(request):
    method = request.get("method", "")
    params = request.get("params", {})
    req_id = request.get("id")

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {
                    "name": "vssh-mcp",
                    "version": "1.0.0"
                }
            }
        }

    elif method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"tools": TOOLS}
        }

    elif method == "tools/call":
        tool_name = params.get("name", "")
        args = params.get("arguments", {})

        result = None
        if tool_name == "vssh_status":
            result = tool_vssh_status()
        elif tool_name == "vssh_exec":
            result = tool_vssh_exec(args.get("server"), args.get("command"))
        elif tool_name == "vssh_put":
            result = tool_vssh_put(args.get("server"), args.get("local_path"), args.get("remote_path"))
        elif tool_name == "vssh_get":
            result = tool_vssh_get(args.get("server"), args.get("remote_path"), args.get("local_path"))
        elif tool_name == "vssh_sync":
            result = tool_vssh_sync(args.get("source"), args.get("dest"), args.get("path"))
        elif tool_name == "vssh_speed_test":
            result = tool_vssh_speed_test(args.get("server"), args.get("size_mb", 10))
        elif tool_name == "vssh_p2p_status":
            result = tool_vssh_p2p_status()
        elif tool_name == "vssh_tunnel":
            result = tool_vssh_tunnel(
                args.get("server"),
                args.get("local_port"),
                args.get("remote_port"),
                args.get("remote_host", "localhost")
            )
        elif tool_name == "vssh_keys":
            result = tool_vssh_keys()
        else:
            result = {"error": f"Unknown tool: {tool_name}"}

        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": json.dumps(result, indent=2)}]
            }
        }

    elif method == "notifications/initialized":
        return None

    else:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": -32601, "message": f"Method not found: {method}"}
        }

def main():
    while True:
        try:
            request = read_request()
            if request is None:
                break
            response = handle_request(request)
            if response:
                send_response(response)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            break


def handle_tool(name: str, arguments: dict) -> str:
    """Unified MCP compatibility wrapper."""
    resp = handle_request({
        "method": "tools/call",
        "id": 1,
        "params": {"name": name, "arguments": arguments},
    })
    if resp and "result" in resp:
        content = resp["result"].get("content", [])
        if content:
            return content[0].get("text", "{}")
    if resp and "error" in resp:
        return json.dumps({"error": resp["error"]})
    return json.dumps({"error": "no result"})

if __name__ == "__main__":
    main()
