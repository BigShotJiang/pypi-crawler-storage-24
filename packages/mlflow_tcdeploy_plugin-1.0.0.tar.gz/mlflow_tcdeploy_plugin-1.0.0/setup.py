from pathlib import Path

from setuptools import find_packages, setup

from mlflow_tcdeploy_plugin import __version__

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="mlflow-tcdeploy-plugin",
    version=__version__,
    description="Tencent Cloud deployment plugin for MLflow",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Tencent WeData Team",
    url="https://git.woa.com/WeDataOS/wedata3-monorepo",
    packages=find_packages(),
    # Require MLflow as a dependency of the plugin, so that plugin users can simply install
    # the plugin & then immediately use it with MLflow.
    # tencentcloud-sdk-python includes all services (TIone for list_instance_types) + common
    install_requires=[
        "mlflow>=3.10.0,<3.11.0",
        "tencentcloud-sdk-python>=3.0.1478",
    ],
    extras_require={
        "dev": ["pytest", "python-dotenv"],
    },
    python_requires=">=3.10",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    entry_points={
        "mlflow.deployments": [
            "tcdeploy=mlflow_tcdeploy_plugin.client:TcDeploymentClient",
        ],
    },
)
