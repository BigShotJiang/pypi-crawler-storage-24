# mlflow-tcdeploy-plugin

MLflow deployment plugin，将腾讯云模型服务对接为 MLflow Deployment 后端。

与 `mlflow-tclake-plugin`（Model Registry）配套使用：
- `tclake`：负责模型存储 → TCLake
- `tcdeploy`：负责模型部署 → 腾讯云在线推理服务

## 安装

```bash
pip install mlflow-tcdeploy-plugin
```

## 环境变量（来自 wedata-pre-execute）

| 变量 | 说明 | 必填 |
|------|------|------|
| `KERNEL_WEDATA_CLOUD_SDK_SECRET_ID` | 腾讯云 SecretId | 是 |
| `KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY` | 腾讯云 SecretKey | 是 |
| `KERNEL_WEDATA_REGION` | 地域，如 `ap-guangzhou` | 否（默认 ap-guangzhou） |
| `WEDATA_WORKSPACE_ID` | WeData 工作空间 ID | 是 |
| `TENCENTCLOUD_ENDPOINT` | WeData API endpoint | 否（默认 wedata.internal.tencentcloudapi.com） |
| `KERNEL_WEDATA_CLOUD_SDK_SECRET_TOKEN` | 临时凭证 Token | 否 |

## 使用

```python
from mlflow.deployments import get_deploy_client

client = get_deploy_client("tcdeploy")

# 查询可用规格
specs = client.list_instance_types(spec_type="CPU")
available = [s for s in specs if s["available"]]
print(available[0]["spec_name"])  # e.g. "TI.SA5.2XLARGE32.POST"

# 创建部署
client.create_deployment(
    name="my-service",
    model_uri="models:/MyModel/1",
    config={"instance_type": "TI.SA5.2XLARGE32.POST"},
)

# 获取详情
info = client.get_deployment(name="svc-id-xxxx")

# 更新
client.update_deployment(name="svc-id-xxxx", config={"replicas": 2})

# 删除（幂等）
client.delete_deployment(name="svc-id-xxxx")

# 列举服务组
groups = client.list_deployments()
# 按服务组过滤
groups = client.list_deployments(endpoint="grp-001")
```

## 测试

```bash
pytest tests/           # 单元测试
pytest tests/integration/  # 集成测试（需要真实环境变量）
```
