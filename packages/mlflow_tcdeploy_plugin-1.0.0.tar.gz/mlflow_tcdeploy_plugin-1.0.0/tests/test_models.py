import pytest
from mlflow_tcdeploy_plugin.models import (
    parse_model_uri,
    to_snake_case_dict,
    build_create_request,
    DEFAULT_CONFIG,
)


class TestParseModelUri:
    def test_parses_registered_model_uri(self):
        result = parse_model_uri("models:/MyModel/3")
        assert result == {"name": "MyModel", "version": "3", "modelPath": None}

    def test_parses_run_artifact_uri(self):
        result = parse_model_uri("runs:/abc123/my_model")
        assert result == {"name": None, "version": None, "modelPath": "runs:/abc123/my_model"}

    def test_raises_on_unsupported_scheme(self):
        with pytest.raises(ValueError, match="Unsupported model_uri"):
            parse_model_uri("s3://bucket/model")


class TestToSnakeCaseDict:
    def test_converts_camel_to_snake(self):
        data = {"serviceId": "svc-1", "serviceGroupId": "grp-1", "createTime": "2024"}
        result = to_snake_case_dict(data)
        assert result == {"service_id": "svc-1", "service_group_id": "grp-1", "create_time": "2024"}

    def test_handles_nested_dict(self):
        data = {"mlModelInfo": {"modelPath": "/path"}}
        result = to_snake_case_dict(data)
        assert result == {"ml_model_info": {"model_path": "/path"}}

    def test_handles_none_values(self):
        data = {"serviceId": None}
        result = to_snake_case_dict(data)
        assert result == {"service_id": None}


class TestBuildCreateRequest:
    def test_applies_defaults(self):
        req = build_create_request(
            name="my-svc",
            model_uri="models:/M/1",
            config={"instance_type": "TI.SA5.2XLARGE32.POST"},
        )
        assert req["serviceName"] == "my-svc"
        assert req["scaleMode"] == "MANUAL"
        assert req["replicas"] == 1
        assert req["chargeType"] == "POSTPAID_BY_HOUR"
        assert req["authorizationEnable"] is False
        assert req["logEnable"] is False
        assert req["instanceType"] == "TI.SA5.2XLARGE32.POST"
        # WorkspaceId is NOT in the request body (injected by api_client._base_body())
        assert "workspaceId" not in req
        assert "WorkspaceId" not in req

    def test_config_overrides_defaults(self):
        req = build_create_request(
            name="svc",
            model_uri="models:/M/1",
            config={"instance_type": "TI.SA5.2XLARGE32.POST", "replicas": 3, "log_enable": True},
        )
        assert req["replicas"] == 3
        assert req["logEnable"] is True

    def test_raises_when_instance_type_missing(self):
        with pytest.raises(ValueError, match="instance_type"):
            build_create_request(
                name="svc",
                model_uri="models:/M/1",
                config={},
            )

    def test_sets_service_group_id_when_endpoint_given(self):
        req = build_create_request(
            name="svc",
            model_uri="models:/M/1",
            config={"instance_type": "TI.SA5.2XLARGE32.POST"},
            endpoint="grp-001",
        )
        assert req["serviceGroupId"] == "grp-001"
