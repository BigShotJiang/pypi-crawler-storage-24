import os
import pytest
from unittest.mock import MagicMock, patch

from mlflow_tcdeploy_plugin.client import TcDeploymentClient

BASE_ENV = {
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_ID": "id",
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY": "key",
    "KERNEL_WEDATA_REGION": "ap-guangzhou",
    "WEDATA_WORKSPACE_ID": "ws-123",
}


def make_client():
    with patch.dict(os.environ, BASE_ENV, clear=True):
        return TcDeploymentClient("tcdeploy")


class TestCreateDeployment:
    def test_passes_name_and_model_uri(self):
        client = make_client()
        client._api.create_deployment = MagicMock(return_value={"ServiceId": "svc-1", "ServiceName": "my-svc", "Status": "Creating"})

        result = client.create_deployment(
            name="my-svc",
            model_uri="models:/MyModel/1",
            config={"instance_type": "TI.SA5.2XLARGE32.POST"},
        )

        call_body = client._api.create_deployment.call_args[0][0]
        assert call_body["serviceName"] == "my-svc"
        assert call_body["instanceType"] == "TI.SA5.2XLARGE32.POST"
        assert result["service_id"] == "svc-1"  # snake_case returned

    def test_raises_when_instance_type_missing(self):
        client = make_client()
        with pytest.raises(ValueError, match="instance_type"):
            client.create_deployment(name="svc", model_uri="models:/M/1", config={})

    def test_passes_endpoint_as_service_group(self):
        client = make_client()
        client._api.create_deployment = MagicMock(return_value={"ServiceId": "svc-1", "ServiceName": "svc", "Status": "Creating"})

        client.create_deployment(
            name="svc",
            model_uri="models:/M/1",
            endpoint="grp-001",
            config={"instance_type": "TI.SA5.2XLARGE32.POST"},
        )

        call_body = client._api.create_deployment.call_args[0][0]
        assert call_body["serviceGroupId"] == "grp-001"


class TestUpdateDeployment:
    def test_calls_api_with_service_id_and_camel_case_config(self):
        client = make_client()
        client._api.update_deployment = MagicMock(return_value=None)

        client.update_deployment(name="svc-id-1", config={"replicas": 2, "instance_type": "TI.SA5.4XLARGE64.POST"})

        # config keys are converted to camelCase before reaching api_client
        client._api.update_deployment.assert_called_once_with(
            "svc-id-1", {"replicas": 2, "instanceType": "TI.SA5.4XLARGE64.POST"}
        )


class TestDeleteDeployment:
    def test_calls_api_with_service_id(self):
        client = make_client()
        client._api.delete_deployment = MagicMock(return_value=None)

        client.delete_deployment(name="svc-id-1")

        client._api.delete_deployment.assert_called_once_with("svc-id-1")


class TestGetDeployment:
    def test_returns_snake_case_dict(self):
        client = make_client()
        client._api.get_deployment = MagicMock(return_value={
            "ServiceId": "svc-1",
            "ServiceName": "my-svc",
            "Status": "Running",
        })

        result = client.get_deployment(name="svc-1")

        assert result["service_id"] == "svc-1"
        assert result["service_name"] == "my-svc"
        assert result["status"] == "Running"


class TestListDeployments:
    def test_returns_list_with_name_field(self):
        client = make_client()
        client._api.list_deployments = MagicMock(return_value=[
            {"ServiceGroupId": "grp-1", "ServiceGroupName": "group-one"},
        ])

        result = client.list_deployments()

        assert result[0]["name"] == "grp-1"
        assert result[0]["service_group_name"] == "group-one"

    def test_passes_endpoint_filter(self):
        client = make_client()
        client._api.list_deployments = MagicMock(return_value=[])

        client.list_deployments(endpoint="grp-001")

        client._api.list_deployments.assert_called_once_with(endpoint="grp-001")


class TestListInstanceTypes:
    def test_calls_tione_sdk_and_returns_formatted_list(self):
        client = make_client()
        mock_spec = MagicMock()
        mock_spec.SpecName = "TI.SA5.2XLARGE32.POST"
        mock_spec.SpecAlias = "8C32GB SA5"
        mock_spec.SpecType = "CPU"
        mock_spec.Available = True
        mock_spec.AvailableRegion = []
        mock_spec.GpuType = ""

        mock_resp = MagicMock()
        mock_resp.SpecInfos = [mock_spec]

        with patch("mlflow_tcdeploy_plugin.client.tione_client") as MockTioneModule:
            MockTioneModule.TioneClient.return_value.DescribeInferenceSpecs.return_value = mock_resp
            specs = client.list_instance_types(spec_type="CPU")

        assert len(specs) == 1
        assert specs[0]["spec_name"] == "TI.SA5.2XLARGE32.POST"
        assert specs[0]["available"] is True
        assert specs[0]["spec_type"] == "CPU"

    def test_filters_by_spec_type(self):
        client = make_client()
        mock_cpu = MagicMock()
        mock_cpu.SpecName = "TI.SA5.CPU"
        mock_cpu.SpecAlias = "CPU spec"
        mock_cpu.SpecType = "CPU"
        mock_cpu.Available = True
        mock_cpu.AvailableRegion = []
        mock_cpu.GpuType = ""

        mock_gpu = MagicMock()
        mock_gpu.SpecName = "TI.GN10X.GPU"
        mock_gpu.SpecAlias = "GPU spec"
        mock_gpu.SpecType = "GPU"
        mock_gpu.Available = True
        mock_gpu.AvailableRegion = []
        mock_gpu.GpuType = "T4"

        mock_resp = MagicMock()
        mock_resp.SpecInfos = [mock_cpu, mock_gpu]

        with patch("mlflow_tcdeploy_plugin.client.tione_client") as MockTioneModule:
            MockTioneModule.TioneClient.return_value.DescribeInferenceSpecs.return_value = mock_resp
            specs = client.list_instance_types(spec_type="GPU")

        assert len(specs) == 1
        assert specs[0]["spec_name"] == "TI.GN10X.GPU"


class TestPredict:
    def test_serializes_inputs_to_json_and_calls_api(self):
        client = make_client()
        client._api.predict = MagicMock(return_value={
            "CurlResponseRaw": '{"status": 200, "body": "{\\"result\\": 42}"}'
        })

        result = client.predict(
            deployment_name="grp-001",
            inputs={"data": [1, 2, 3]},
        )

        call_kwargs = client._api.predict.call_args
        assert call_kwargs[1]["service_group_id"] == "grp-001"
        import json
        assert json.loads(call_kwargs[1]["curl_data"]) == {"data": [1, 2, 3]}
        # 返回值是 JSON 解析后的 dict
        assert result["status"] == 200

    def test_uses_endpoint_as_relative_url(self):
        client = make_client()
        client._api.predict = MagicMock(return_value={"CurlResponseRaw": "{}"})

        client.predict(
            deployment_name="grp-001",
            inputs={},
            endpoint="/v1/infer",
        )

        assert client._api.predict.call_args[1]["relative_url"] == "/v1/infer"

    def test_default_relative_url_is_predict(self):
        client = make_client()
        client._api.predict = MagicMock(return_value={"CurlResponseRaw": "{}"})

        client.predict(deployment_name="grp-001", inputs={})

        assert client._api.predict.call_args[1]["relative_url"] == "/predict"

    def test_passes_auth_token_from_config(self):
        client = make_client()
        client._api.predict = MagicMock(return_value={"CurlResponseRaw": "{}"})

        client.predict(
            deployment_name="grp-001",
            inputs={},
            config={"auth_token": "Bearer xxx"},
        )

        assert client._api.predict.call_args[1]["auth_token_value"] == "Bearer xxx"

    def test_returns_raw_on_invalid_json_response(self):
        client = make_client()
        client._api.predict = MagicMock(return_value={"CurlResponseRaw": "not-json"})

        result = client.predict(deployment_name="grp-001", inputs={})

        assert result == {"raw": "not-json"}

    def test_raises_value_error_when_inputs_not_serializable(self):
        client = make_client()

        class Unserializable:
            pass

        with pytest.raises(ValueError, match="inputs"):
            client.predict(deployment_name="grp-001", inputs=Unserializable())


class TestDebugPodShell:
    def test_returns_url(self):
        client = make_client()
        client._api.debug_pod_shell = MagicMock(return_value={"Url": "https://shell.example.com"})

        result = client.debug_pod_shell(service_id="svc-1", pod_name="pod-0")

        client._api.debug_pod_shell.assert_called_once_with(service_id="svc-1", pod_name="pod-0")
        assert result == {"url": "https://shell.example.com"}


class TestRestartPod:
    def test_returns_request_id(self):
        client = make_client()
        client._api.restart_pod = MagicMock(
            return_value={"TiOneRebuildServiceRequestId": "req-abc"}
        )

        result = client.restart_pod(service_id="svc-1", pod_name="pod-0")

        client._api.restart_pod.assert_called_once_with(service_id="svc-1", pod_name="pod-0")
        assert result == {"request_id": "req-abc"}


class TestGetPodLogs:
    def test_returns_formatted_logs(self):
        client = make_client()
        client._api.get_pod_logs = MagicMock(return_value={
            "Content": [
                {"Id": "1", "Message": "started", "PodName": "pod-0", "Timestamp": "2026-03-11T00:00:00Z"}
            ],
            "Context": "cursor-xyz",
        })

        result = client.get_pod_logs(service_id="svc-1")

        client._api.get_pod_logs.assert_called_once_with(
            service_id="svc-1",
            pod_name=None,
            limit=None,
            start_time=None,
            end_time=None,
            context=None,
        )
        assert len(result["logs"]) == 1
        assert result["logs"][0]["message"] == "started"
        assert result["logs"][0]["pod_name"] == "pod-0"
        assert result["context"] == "cursor-xyz"

    def test_passes_all_optional_params(self):
        client = make_client()
        client._api.get_pod_logs = MagicMock(return_value={"Content": [], "Context": None})

        client.get_pod_logs(
            service_id="svc-1",
            pod_name="pod-0",
            limit=50,
            start_time="2026-03-10T00:00:00+08:00",
            end_time="2026-03-10T23:59:59+08:00",
            context="cursor-prev",
        )

        client._api.get_pod_logs.assert_called_once_with(
            service_id="svc-1",
            pod_name="pod-0",
            limit=50,
            start_time="2026-03-10T00:00:00+08:00",
            end_time="2026-03-10T23:59:59+08:00",
            context="cursor-prev",
        )
