import os
from dataclasses import dataclass, field
from typing import Optional


def _require_env(key: str, override: Optional[str]) -> str:
    value = override or os.getenv(key)
    if not value:
        raise ValueError(
            f"Missing required configuration: '{key}'. "
            f"Set the environment variable or pass it as a parameter."
        )
    return value


@dataclass
class TcDeployConfig:
    secret_id: str = field(init=False)
    secret_key: str = field(init=False)
    secret_token: Optional[str] = field(init=False)
    region: str = field(init=False)
    workspace_id: str = field(init=False)
    endpoint: str = field(init=False)
    sub_account_uin: str = field(init=False)
    owner_uin: str = field(init=False)

    def __init__(
        self,
        secret_id: Optional[str] = None,
        secret_key: Optional[str] = None,
        secret_token: Optional[str] = None,
        region: Optional[str] = None,
        workspace_id: Optional[str] = None,
        endpoint: Optional[str] = None,
    ):
        self.secret_id = _require_env("KERNEL_WEDATA_CLOUD_SDK_SECRET_ID", secret_id)
        self.secret_key = _require_env("KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY", secret_key)
        self.secret_token = secret_token or os.getenv("KERNEL_WEDATA_CLOUD_SDK_SECRET_TOKEN")
        self.region = region or os.getenv("KERNEL_WEDATA_REGION", "ap-guangzhou")
        self.workspace_id = _require_env("WEDATA_WORKSPACE_ID", workspace_id)
        self.endpoint = endpoint or os.getenv(
            "TENCENTCLOUD_ENDPOINT", "wedata.internal.tencentcloudapi.com"
        )
        self.sub_account_uin = os.getenv("KERNEL_LOGIN_UIN", "")
        self.owner_uin = os.getenv("QCLOUD_UIN", "")
