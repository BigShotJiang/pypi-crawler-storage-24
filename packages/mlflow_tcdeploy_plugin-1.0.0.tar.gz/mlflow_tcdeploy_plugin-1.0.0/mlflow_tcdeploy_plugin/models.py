import re
from typing import Optional

DEFAULT_CONFIG = {
    "scaleMode": "MANUAL",
    "replicas": 1,
    "chargeType": "POSTPAID_BY_HOUR",
    "authorizationEnable": False,
    "logEnable": False,
}

# snake_case key → camelCase key mapping (config uses snake_case, request uses camelCase)
_SNAKE_TO_CAMEL = {
    "instance_type": "instanceType",
    "scale_mode": "scaleMode",
    "replicas": "replicas",
    "charge_type": "chargeType",
    "authorization_enable": "authorizationEnable",
    "log_enable": "logEnable",
    "service_group_id": "serviceGroupId",
}


def _camel_to_snake(name: str) -> str:
    s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def to_snake_case_dict(data: dict) -> dict:
    """Recursively convert dict keys from camelCase to snake_case."""
    result = {}
    for k, v in data.items():
        snake_key = _camel_to_snake(k)
        if isinstance(v, dict):
            result[snake_key] = to_snake_case_dict(v)
        else:
            result[snake_key] = v
    return result


def parse_model_uri(model_uri: str) -> dict:
    """
    Parse MLflow model URI into mlModelInfo fields.
    Supports:
      - models:/ModelName/Version  → name + version
      - runs:/run_id/path          → modelPath
    """
    if model_uri.startswith("models:/"):
        parts = model_uri[len("models:/"):].split("/")
        if len(parts) < 2:
            raise ValueError(f"Invalid models URI: {model_uri}")
        return {"name": parts[0], "version": parts[1], "modelPath": None}
    elif model_uri.startswith("runs:/"):
        return {"name": None, "version": None, "modelPath": model_uri}
    else:
        raise ValueError(f"Unsupported model_uri scheme: {model_uri}")


def snake_to_camel_dict(config: dict) -> dict:
    """Convert config dict keys from snake_case to camelCase using _SNAKE_TO_CAMEL mapping."""
    return {_SNAKE_TO_CAMEL.get(k, k): v for k, v in config.items()}


def build_create_request(
    name: str,
    model_uri: str,
    config: dict,
    endpoint: Optional[str] = None,
) -> dict:
    """Assemble create_deployment parameters into a cloud API request body.

    Note: WorkspaceId is injected by ModelServiceApiClient._base_body(), not here.
    """
    if not config.get("instance_type"):
        raise ValueError(
            "config must include 'instance_type'. "
            "Use list_instance_types() to see available options."
        )

    camel_config = snake_to_camel_dict(config)

    req = {**DEFAULT_CONFIG, **camel_config}
    req["serviceName"] = name
    req["mlModelInfo"] = parse_model_uri(model_uri)

    if endpoint:
        req["serviceGroupId"] = endpoint

    return req
