import json
from typing import List, Optional

from mlflow.deployments import BaseDeploymentClient
from tencentcloud.common import credential
from tencentcloud.tione.v20211111 import tione_client

from mlflow_tcdeploy_plugin.api_client import ModelServiceApiClient
from mlflow_tcdeploy_plugin.config import TcDeployConfig
from mlflow_tcdeploy_plugin.models import build_create_request, snake_to_camel_dict, to_snake_case_dict


class TcDeploymentClient(BaseDeploymentClient):
    """
    MLflow deployment client, connecting Tencent Cloud model service as MLflow deployment backend.

    Usage:
        from mlflow.deployments import get_deploy_client
        client = get_deploy_client("tcdeploy")

    Required environment variables (from wedata-pre-execute):
        KERNEL_WEDATA_CLOUD_SDK_SECRET_ID, KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY,
        KERNEL_WEDATA_REGION, WEDATA_WORKSPACE_ID
    """

    def __init__(self, target_uri: str):
        super().__init__(target_uri)
        self._config = TcDeployConfig()
        self._api = ModelServiceApiClient(self._config)

    def create_deployment(
        self,
        name: str,
        model_uri: str,
        flavor=None,
        config: Optional[dict] = None,
        endpoint: Optional[str] = None,
    ) -> dict:
        """
        Create a model service.

        Args:
            name: service name
            model_uri: MLflow model URI, e.g. "models:/MyModel/1"
            config: deployment config, must include instance_type.
                    Use list_instance_types() to see available options.
            endpoint: service group ID (serviceGroupId), optional
        """
        body = build_create_request(
            name=name,
            model_uri=model_uri,
            config=config or {},
            endpoint=endpoint,
        )
        raw = self._api.create_deployment(body)
        return to_snake_case_dict(raw)

    def update_deployment(
        self,
        name: str,
        model_uri: Optional[str] = None,
        flavor=None,
        config: Optional[dict] = None,
        endpoint: Optional[str] = None,
    ) -> None:
        """
        Update a model service. name is serviceId. Only pass fields to change.
        """
        self._api.update_deployment(name, snake_to_camel_dict(config or {}))

    def delete_deployment(
        self,
        name: str,
        config: Optional[dict] = None,
        endpoint: Optional[str] = None,
    ) -> None:
        """
        Delete a model service. name is serviceId. Idempotent.
        """
        self._api.delete_deployment(name)

    def get_deployment(self, name: str, endpoint: Optional[str] = None) -> dict:
        """
        Get model service details. name is serviceId. Returns snake_case dict.
        """
        raw = self._api.get_deployment(name)
        return to_snake_case_dict(raw)

    def list_deployments(self, endpoint: Optional[str] = None) -> List[dict]:
        """
        List service groups. endpoint is serviceGroupId filter, optional.
        Each item includes "name" field (serviceGroupId) as required by MLflow spec.
        """
        raw_list = self._api.list_deployments(endpoint=endpoint)
        result = []
        for item in raw_list:
            converted = to_snake_case_dict(item)
            # MLflow spec requires each item to have "name" field
            converted["name"] = item.get("ServiceGroupId", "")
            result.append(converted)
        return result

    def list_instance_types(self, spec_type: Optional[str] = None) -> List[dict]:
        """
        Query available TIone spec list. Calls TIone SDK directly, bypassing Java layer.

        Args:
            spec_type: "CPU" or "GPU", returns all if not specified

        Returns:
            list of dict with spec_name, spec_alias, spec_type, available, available_region, gpu_type
        """
        cred = credential.Credential(
            self._config.secret_id,
            self._config.secret_key,
            self._config.secret_token,
        )
        client = tione_client.TioneClient(cred, self._config.region)

        # Access via module attribute so that unit-test patches on tione_client are effective
        req = tione_client.models.DescribeInferenceSpecsRequest()
        resp = client.DescribeInferenceSpecs(req)

        specs = []
        for s in resp.SpecInfos or []:
            if spec_type and s.SpecType != spec_type:
                continue
            specs.append({
                "spec_name": s.SpecName,
                "spec_alias": s.SpecAlias,
                "spec_type": s.SpecType,
                "available": s.Available,
                "available_region": list(s.AvailableRegion or []),
                "gpu_type": s.GpuType or "",
            })
        return specs

    def predict(
        self,
        deployment_name=None,
        inputs=None,
        endpoint=None,
        config=None,
    ):
        try:
            curl_data = json.dumps(inputs)
        except (TypeError, ValueError) as e:
            raise ValueError(f"inputs must be JSON-serializable, got {type(inputs).__name__}: {e}") from e

        raw = self._api.predict(
            service_group_id=deployment_name,
            curl_data=curl_data,
            relative_url=endpoint or "/predict",
            auth_token_value=(config or {}).get("auth_token"),
        )

        raw_str = raw.get("CurlResponseRaw", "")
        try:
            return json.loads(raw_str)
        except (json.JSONDecodeError, TypeError):
            return {"raw": raw_str}

    def debug_pod_shell(self, service_id, pod_name):
        raw = self._api.debug_pod_shell(service_id=service_id, pod_name=pod_name)
        return to_snake_case_dict(raw)

    def restart_pod(self, service_id, pod_name):
        raw = self._api.restart_pod(service_id=service_id, pod_name=pod_name)
        return {"request_id": raw.get("TiOneRebuildServiceRequestId")}

    def get_pod_logs(self, service_id, pod_name=None, limit=None, start_time=None, end_time=None, context=None):
        raw = self._api.get_pod_logs(
            service_id=service_id,
            pod_name=pod_name,
            limit=limit,
            start_time=start_time,
            end_time=end_time,
            context=context,
        )
        logs = [to_snake_case_dict(entry) for entry in (raw.get("Content") or [])]
        return {"logs": logs, "context": raw.get("Context")}
