from typing import Optional

from tencentcloud.common import credential
from tencentcloud.common.abstract_client import AbstractClient
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from mlflow.exceptions import MlflowException

from mlflow_tcdeploy_plugin.config import TcDeployConfig


class WedataDeployClient(AbstractClient):
    """WeData deployment API client, inherits AbstractClient for TC3 signing."""
    _apiVersion = '2025-10-10'
    _endpoint = 'wedata.internal.tencentcloudapi.com'
    _service = 'wedata'


class ModelServiceApiClient:
    """Wraps WeData model service cloud API calls."""

    def __init__(self, config: TcDeployConfig):
        self._config = config
        cred = credential.Credential(
            config.secret_id,
            config.secret_key,
            config.secret_token,
        )
        client_profile = ClientProfile()
        client_profile.httpProfile.endpoint = config.endpoint

        self._wedata_client = WedataDeployClient(cred, config.region, client_profile)

    def _call(self, action: str, body: dict) -> dict:
        try:
            return self._wedata_client.call_json(action, body)
        except TencentCloudSDKException as e:
            raise MlflowException(f"{e.code}: {e.message}") from e

    def _base_body(self) -> dict:
        """Common fields required in all requests."""
        return {"WorkspaceId": self._config.workspace_id}

    def create_deployment(self, body: dict) -> dict:
        req = {**self._base_body(), **body}
        return self._call("CreateMLModelServices", req)

    def update_deployment(self, service_id: str, body: dict) -> None:
        req = {**self._base_body(), "ServiceId": service_id, **body}
        self._call("UpdateMLModelService", req)

    def delete_deployment(self, service_id: str) -> None:
        req = {**self._base_body(), "ServiceId": service_id}
        try:
            self._call("DeleteMLModelService", req)
        except MlflowException as e:
            if "ResourceNotFound" in str(e):
                return  # idempotent
            raise

    def get_deployment(self, service_id: str) -> dict:
        req = {**self._base_body(), "ServiceId": service_id}
        return self._call("GetMLModelService", req)

    def list_deployments(self, endpoint: Optional[str] = None) -> list:
        req = {**self._base_body()}
        if endpoint:
            req["ServiceGroupId"] = endpoint
        resp = self._call("ListMLModelServiceGroups", req)
        return resp.get("Groups", [])

    def predict(
        self,
        service_group_id: str,
        curl_data: str,
        relative_url=None,
        auth_token_value=None,
    ) -> dict:
        req = {
            **self._base_body(),
            "ServiceGroupId": service_group_id,
            "CurlData": curl_data,
        }
        if relative_url is not None:
            req["RelativeUrl"] = relative_url
        if auth_token_value is not None:
            req["AuthTokenValue"] = auth_token_value
        return self._call("ModelServiceInterfaceCallTest", req)

    def debug_pod_shell(self, service_id: str, pod_name: str) -> dict:
        req = {
            **self._base_body(),
            "ServiceId": service_id,
            "PodName": pod_name,
        }
        return self._call("CreateModelServicePodUrl", req)

    def restart_pod(self, service_id: str, pod_name: str) -> dict:
        req = {
            **self._base_body(),
            "ServiceId": service_id,
            "PodName": pod_name,
        }
        return self._call("RebuildModelServicePod", req)

    def get_pod_logs(
        self,
        service_id: str,
        pod_name=None,
        limit=None,
        start_time=None,
        end_time=None,
        context=None,
    ) -> dict:
        req = {
            **self._base_body(),
            "ServiceId": service_id,
        }
        if pod_name is not None:
            req["PodName"] = pod_name
        if limit is not None:
            req["Limit"] = limit
        if start_time is not None:
            req["StartTime"] = start_time
        if end_time is not None:
            req["EndTime"] = end_time
        if context is not None:
            req["Context"] = context
        return self._call("ListMLServiceLogs", req)
