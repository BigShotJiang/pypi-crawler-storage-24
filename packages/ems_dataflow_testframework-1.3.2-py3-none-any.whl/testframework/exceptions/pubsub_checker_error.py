class PubsubCheckerError(Exception):
    pass
