class PubsubCreatorError(Exception):
    pass
