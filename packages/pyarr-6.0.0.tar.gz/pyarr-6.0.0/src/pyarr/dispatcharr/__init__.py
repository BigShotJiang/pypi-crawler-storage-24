from pyarr.client import BaseArrClient
from pyarr.dispatcharr.channels import Channels
from pyarr.dispatcharr.streams import Streams
from pyarr.dispatcharr.vod import Vod


class Dispatcharr(BaseArrClient):
    """Dispatcharr API client."""

    def __init__(
        self,
        host: str,
        api_key: str,
        port: int = 9191,
        tls: bool = True,
        base_path: str = "",
        request_timeout: int | None = None,
        api_ver: str | None = "v1",
    ):
        """Initializes the Dispatcharr client.

        Args:
            host (str): The host to connect to.
            api_key (str): The API key for authentication.
            port (int, optional): The port to connect to. Defaults to 9191.
            tls (bool, optional): Whether to use TLS. Defaults to True.
            base_path (str, optional): The base path for the API. Defaults to "".
            request_timeout (int | None, optional): The timeout for requests. Defaults to None.
            api_ver (str | None, optional): The API version to use. Defaults to "v1".
        """
        super().__init__(
            host,
            api_key,
            port=port,
            tls=tls,
            base_path=base_path,
            request_timeout=request_timeout,
            api_ver=api_ver,
        )
        self.channels = Channels(self.http_utils)
        self.streams = Streams(self.http_utils)
        self.vod = Vod(self.http_utils)
