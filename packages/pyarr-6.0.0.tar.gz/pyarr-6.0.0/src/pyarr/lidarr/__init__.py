from pyarr.client import BaseArrClient
from pyarr.lidarr.album import Album
from pyarr.lidarr.artist import Artist
from pyarr.lidarr.config import Config
from pyarr.lidarr.manual_import import ManualImport
from pyarr.lidarr.release import Release
from pyarr.lidarr.track import Track
from pyarr.lidarr.track_file import TrackFile


class Lidarr(BaseArrClient):
    """Lidarr API client."""

    def __init__(
        self,
        host: str,
        api_key: str,
        port: int = 8686,
        tls: bool = True,
        base_path: str = "",
        request_timeout: int | None = None,
        api_ver: str | None = None,
    ):
        """Initializes the Lidarr client with the provided host, API key, and optional parameters.

        Args:
            host (str): The host to connect to.
            api_key (str): The API key for authentication.
            port (int, optional): The port to connect to. Defaults to 8686.
            tls (bool, optional): Whether to use TLS. Defaults to True.
            base_path (str, optional): The base path for the API. Defaults to "".
            request_timeout (int | None, optional): The timeout for requests. Defaults to None.
            api_ver (str | None, optional): The API version to use. Defaults to None, automatically detected.
        """
        super().__init__(
            host,
            api_key,
            port=port,
            tls=tls,
            base_path=base_path,
            request_timeout=request_timeout,
            api_ver=api_ver,
        )
        self.config = Config(self.http_utils)
        self.artist = Artist(self.http_utils)
        self.album = Album(self.http_utils)
        self.track = Track(self.http_utils)
        self.track_file = TrackFile(self.http_utils)
        self.release = Release(self.http_utils)
        self.manual_import = ManualImport(self.http_utils)
