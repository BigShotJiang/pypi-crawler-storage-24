from pyarr.common.base import CommonActions
from pyarr.types import JsonArray, JsonObject


class Album(CommonActions):
    """Album actions for Lidarr."""

    def get(
        self,
        item_id: int | None = None,
        artist_id: int | None = None,
        album_ids: list[int] | None = None,
        foreign_album_id: str | None = None,
        all_artist_albums: bool = False,
    ) -> JsonArray | JsonObject:
        """Returns albums by ID, artist ID, or other criteria.

        Args:
            item_id (int | None, optional): Lidarr ID of album. Defaults to None.
            artist_id (int | None, optional): Lidarr ID of artist. Defaults to None.
            album_ids (list[int] | None, optional): List of album IDs. Defaults to None.
            foreign_album_id (str | None, optional): Foreign album ID. Defaults to None.
            all_artist_albums (bool, optional): Include all artist albums. Defaults to False.

        Returns:
            JsonArray | JsonObject: List of dictionaries with items or a single dictionary.
        """
        params: dict[str, str | int | bool | list[int]] = {"includeAllArtistAlbums": all_artist_albums}
        if artist_id:
            params["artistId"] = artist_id
        if album_ids:
            params["albumIds"] = album_ids
        if foreign_album_id:
            params["foreignAlbumId"] = foreign_album_id

        return self._get("album", item_id=item_id, params=params)

    def add(
        self,
        album: JsonObject,
        root_dir: str,
        quality_profile_id: int,
        metadata_profile_id: int,
        monitored: bool = True,
        artist_monitored: bool = True,
        artist_monitor: str = "all",
        artist_search_for_missing_albums: bool = False,
        search_for_new_album: bool = False,
    ) -> JsonObject:
        """Adds an album to Lidarr.

        Args:
            album (JsonObject): Album record from `lookup()`.
            root_dir (str): Location to store music.
            quality_profile_id (int): Quality profile ID.
            metadata_profile_id (int): Metadata profile ID.
            monitored (bool, optional): Should the album be monitored. Defaults to True.
            artist_monitored (bool, optional): Should the artist be monitored. Defaults to True.
            artist_monitor (str, optional): Artist monitor type. Defaults to "all".
            artist_search_for_missing_albums (bool, optional): Search for missing albums. Defaults to False.
            search_for_new_album (bool, optional): Search for new album. Defaults to False.

        Returns:
            JsonObject: Dictionary with added record.
        """
        album["artist"]["metadataProfileId"] = metadata_profile_id
        album["artist"]["qualityProfileId"] = quality_profile_id
        album["artist"]["rootFolderPath"] = root_dir
        album["artist"]["monitored"] = artist_monitored
        album["artist"]["addOptions"] = {
            "monitor": artist_monitor,
            "searchForMissingAlbums": artist_search_for_missing_albums,
        }
        album["monitored"] = monitored
        album["addOptions"] = {"searchForNewAlbum": search_for_new_album}

        response = self.handler.request("album", method="POST", json_data=album)
        if isinstance(response, dict):
            return response
        raise ValueError("Expected a dictionary response from the 'album' endpoint")

    def update(self, data: JsonObject) -> JsonObject:
        """Update an album.

        Args:
            data (JsonObject): Data to update album.

        Returns:
            JsonObject: Dictionary of updated record.
        """
        response = self.handler.request("album", method="PUT", json_data=data)
        if isinstance(response, dict):
            return response
        raise ValueError("Expected a dictionary response from the 'album' endpoint")

    def delete(self, item_id: int) -> None:
        """Delete an album by ID.

        Args:
            item_id (int): Album ID to be deleted.
        """
        self._delete("album", item_id=item_id)

    def lookup(self, term: str) -> JsonArray:
        """Search for an album to add to the database.

        Args:
            term (str): Search term.

        Returns:
            JsonArray: List of dictionaries with items.
        """
        response = self.handler.request("album/lookup", params={"term": term})
        if isinstance(response, list):
            return response
        raise ValueError("Expected a list response from the 'album/lookup' endpoint")
