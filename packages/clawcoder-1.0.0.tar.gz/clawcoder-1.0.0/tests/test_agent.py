import unittest
import os
import tempfile
import json
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent))

from claw_agent import create_agent, ClawAgent
from processors import FileHandler, ImageHandler, MediaHandler, get_file_info
from skills import BinaryDisassembler
from storage import HistoryStorage


class TestFileHandler(unittest.TestCase):
    
    def setUp(self):
        self.handler = FileHandler()
        self.temp_dir = tempfile.mkdtemp()
    
    def test_handle_txt_file(self):
        txt_path = os.path.join(self.temp_dir, "test.txt")
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write("Hello, World!")
        
        result = self.handler.process(txt_path)
        
        self.assertTrue(result['success'])
        self.assertEqual(result['data'], "Hello, World!")
    
    def test_handle_json_file(self):
        json_path = os.path.join(self.temp_dir, "test.json")
        test_data = {"key": "value", "number": 123}
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(test_data, f)
        
        result = self.handler.process(json_path)
        
        self.assertTrue(result['success'])
        self.assertEqual(result['data'], test_data)
    
    def test_handle_jsonl_file(self):
        jsonl_path = os.path.join(self.temp_dir, "test.jsonl")
        with open(jsonl_path, 'w', encoding='utf-8') as f:
            f.write('{"id": 1, "name": "first"}\n')
            f.write('{"id": 2, "name": "second"}\n')
        
        result = self.handler.process(jsonl_path)
        
        self.assertTrue(result['success'])
        self.assertEqual(len(result['data']), 2)
        self.assertEqual(result['data'][0]['name'], 'first')
    
    def test_handle_md_file(self):
        md_path = os.path.join(self.temp_dir, "test.md")
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write("# Title\n\nContent here")
        
        result = self.handler.process(md_path)
        
        self.assertTrue(result['success'])
        self.assertIn("# Title", result['data'])


class TestHistoryStorage(unittest.TestCase):
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.storage = HistoryStorage(self.temp_dir)
    
    def test_save_and_load_messages(self):
        messages = [
            {'role': 'user', 'content': 'Hello'},
            {'role': 'assistant', 'content': 'Hi there!'}
        ]
        
        self.storage.save_messages('test_session', messages)
        loaded = self.storage.load_messages('test_session')
        
        self.assertEqual(len(loaded), 2)
        self.assertEqual(loaded[0]['content'], 'Hello')
        self.assertEqual(loaded[1]['content'], 'Hi there!')
    
    def test_append_messages(self):
        self.storage.save_messages('test', [{'role': 'user', 'content': 'First'}])
        self.storage.append_messages('test', [{'role': 'user', 'content': 'Second'}])
        
        loaded = self.storage.load_messages('test')
        self.assertEqual(len(loaded), 2)
    
    def test_list_sessions(self):
        self.storage.save_messages('session1', [{'role': 'user', 'content': 'test'}])
        self.storage.save_messages('session2', [{'role': 'user', 'content': 'test'}])
        
        sessions = self.storage.list_sessions()
        self.assertEqual(len(sessions), 2)


class TestBinaryDisassembler(unittest.TestCase):
    
    def setUp(self):
        self.disasm = BinaryDisassembler()
        self.temp_dir = tempfile.mkdtemp()
    
    def test_basic_analysis(self):
        bin_path = os.path.join(self.temp_dir, "test.bin")
        with open(bin_path, 'wb') as f:
            f.write(b'\x90\x90\x90\x90')
        
        result = self.disasm.disassemble(bin_path)
        
        self.assertIsNotNone(result)
        self.assertIn('success', result)
    
    def test_strings_extraction(self):
        bin_path = os.path.join(self.temp_dir, "test.bin")
        with open(bin_path, 'wb') as f:
            f.write(b'Hello World\x00Test String\x00')
        
        result = self.disasm.strings(bin_path)
        
        self.assertTrue(result['success'])
        self.assertIn('Hello World', result['data']['strings'])
        self.assertIn('Test String', result['data']['strings'])


class TestClawAgent(unittest.TestCase):
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.agent = create_agent(history_dir=self.temp_dir)
    
    def test_chat(self):
        response = self.agent.chat("Hello", session_id="test")
        self.assertIsInstance(response, str)
    
    def test_get_supported_extensions(self):
        exts = self.agent.get_supported_extensions()
        
        self.assertIn('text', exts)
        self.assertIn('image', exts)
        self.assertIn('audio', exts)
        self.assertIn('video', exts)
        self.assertIn('binary', exts)
        
        self.assertIn('.md', exts['text'])
        self.assertIn('.jpg', exts['image'])
    
    def test_process_text_file(self):
        txt_path = os.path.join(self.temp_dir, "test.txt")
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write("Test content")
        
        result = self.agent.process_file(txt_path, session_id="test")
        
        self.assertIsNotNone(result)
        self.assertIn('messages', result)


if __name__ == '__main__':
    unittest.main()
