from typing import Dict, Any, Optional, Tuple
from pathlib import Path
import base64


SUPPORTED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp'}


class ImageHandler:
    
    def __init__(self, use_ocr: bool = False):
        self.use_ocr = use_ocr
        self._pillow_available = self._check_pillow()
    
    def _check_pillow(self) -> bool:
        try:
            from PIL import Image
            return True
        except ImportError:
            return False
    
    def can_handle(self, file_path: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return ext in SUPPORTED_EXTENSIONS
    
    def process(self, file_path: str) -> Dict[str, Any]:
        if not self._pillow_available:
            return {
                'success': False,
                'error': 'Pillow library not available',
                'data': None
            }
        
        try:
            from PIL import Image
            
            with Image.open(file_path) as img:
                metadata = {
                    'format': img.format,
                    'mode': img.mode,
                    'size': img.size,
                    'width': img.width,
                    'height': img.height,
                }
                
                if hasattr(img, 'info'):
                    metadata['info'] = img.info
                
                if img.mode not in ('RGB', 'L'):
                    img = img.convert('RGB')
                
                return {
                    'success': True,
                    'data': {
                        'metadata': metadata,
                        'base64': self._image_to_base64(img),
                        'description': self._generate_description(metadata)
                    },
                    'error': None,
                    'metadata': metadata
                }
                
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
    
    def _image_to_base64(self, img) -> str:
        import io
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def _generate_description(self, metadata: Dict) -> str:
        desc_parts = [
            f"Image: {metadata.get('format', 'Unknown')} format",
            f"Size: {metadata.get('width', 0)}x{metadata.get('height', 0)} pixels",
            f"Mode: {metadata.get('mode', 'Unknown')}"
        ]
        return " | ".join(desc_parts)
    
    def extract_text_ocr(self, file_path: str) -> Tuple[bool, Optional[str], Optional[str]]:
        if not self.use_ocr:
            return False, None, "OCR not enabled"
        
        try:
            import pytesseract
            from PIL import Image
            
            with Image.open(file_path) as img:
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                text = pytesseract.image_to_string(img, lang='chi_sim+eng')
                return True, text, None
                
        except ImportError:
            return False, None, "pytesseract not installed"
        except Exception as e:
            return False, None, str(e)
