from typing import Dict, Any, Optional, Tuple
from pathlib import Path
import os


SUPPORTED_AUDIO = {'.mp3', '.wav'}
SUPPORTED_VIDEO = {'.mp4', '.flv'}


class MediaHandler:
    
    def __init__(self):
        self._pydub_available = self._check_pydub()
        self._moviepy_available = self._check_moviepy()
    
    def _check_pydub(self) -> bool:
        try:
            from pydub import AudioSegment
            return True
        except ImportError:
            return False
    
    def _check_moviepy(self) -> bool:
        try:
            from moviepy.editor import VideoFileClip
            return True
        except ImportError:
            return False
    
    def can_handle(self, file_path: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return ext in SUPPORTED_AUDIO or ext in SUPPORTED_VIDEO
    
    def is_audio(self, file_path: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return ext in SUPPORTED_AUDIO
    
    def is_video(self, file_path: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return ext in SUPPORTED_VIDEO
    
    def process(self, file_path: str) -> Dict[str, Any]:
        if self.is_audio(file_path):
            return self._process_audio(file_path)
        elif self.is_video(file_path):
            return self._process_video(file_path)
        else:
            return {
                'success': False,
                'error': 'Unsupported media format',
                'data': None
            }
    
    def _process_audio(self, file_path: str) -> Dict[str, Any]:
        if not self._pydub_available:
            return self._get_basic_audio_info(file_path)
        
        try:
            from pydub import AudioSegment
            
            audio = AudioSegment.from_file(file_path)
            
            metadata = {
                'type': 'audio',
                'duration_seconds': len(audio) / 1000.0,
                'channels': audio.channels,
                'sample_width': audio.sample_width,
                'frame_rate': audio.frame_rate,
                'frame_count': audio.frame_count(),
            }
            
            return {
                'success': True,
                'data': {
                    'metadata': metadata,
                    'description': self._audio_description(metadata)
                },
                'error': None,
                'metadata': metadata
            }
            
        except Exception as e:
            return self._get_basic_audio_info(file_path, str(e))
    
    def _get_basic_audio_info(self, file_path: str, error: str = None) -> Dict[str, Any]:
        stat = os.stat(file_path)
        return {
            'success': True,
            'data': {
                'metadata': {
                    'type': 'audio',
                    'file_size': stat.st_size,
                    'extension': Path(file_path).suffix
                },
                'description': f'Audio file: {Path(file_path).name}'
            },
            'error': error,
            'metadata': {'type': 'audio', 'basic_info': True}
        }
    
    def _process_video(self, file_path: str) -> Dict[str, Any]:
        if not self._moviepy_available:
            return self._get_basic_video_info(file_path)
        
        try:
            from moviepy.editor import VideoFileClip
            
            with VideoFileClip(file_path) as clip:
                metadata = {
                    'type': 'video',
                    'duration': clip.duration,
                    'fps': clip.fps,
                    'size': clip.size,
                    'has_audio': clip.audio is not None,
                }
                
                return {
                    'success': True,
                    'data': {
                        'metadata': metadata,
                        'description': self._video_description(metadata)
                    },
                    'error': None,
                    'metadata': metadata
                }
                
        except Exception as e:
            return self._get_basic_video_info(file_path, str(e))
    
    def _get_basic_video_info(self, file_path: str, error: str = None) -> Dict[str, Any]:
        stat = os.stat(file_path)
        return {
            'success': True,
            'data': {
                'metadata': {
                    'type': 'video',
                    'file_size': stat.st_size,
                    'extension': Path(file_path).suffix
                },
                'description': f'Video file: {Path(file_path).name}'
            },
            'error': error,
            'metadata': {'type': 'video', 'basic_info': True}
        }
    
    def _audio_description(self, metadata: Dict) -> str:
        parts = [
            f"Audio: {metadata.get('duration_seconds', 0):.2f}s",
            f"{metadata.get('channels', 0)} channels",
            f"{metadata.get('frame_rate', 0)}Hz"
        ]
        return " | ".join(parts)
    
    def _video_description(self, metadata: Dict) -> str:
        parts = [
            f"Video: {metadata.get('duration', 0):.2f}s",
            f"{metadata.get('size', (0,0))[0]}x{metadata.get('size', (0,0))[1]}",
            f"{metadata.get('fps', 0)} fps"
        ]
        return " | ".join(parts)
    
    def extract_audio_from_video(self, video_path: str, output_path: str = None) -> Tuple[bool, Optional[str], Optional[str]]:
        if not self._moviepy_available:
            return False, None, "moviepy not available"
        
        try:
            from moviepy.editor import VideoFileClip
            
            with VideoFileClip(video_path) as clip:
                if clip.audio is None:
                    return False, None, "No audio track in video"
                
                if output_path is None:
                    output_path = video_path.rsplit('.', 1)[0] + '_audio.mp3'
                
                clip.audio.write_audiofile(output_path)
                return True, output_path, None
                
        except Exception as e:
            return False, None, str(e)
