import os
import json
from typing import Dict, Any, Optional, Tuple
from pathlib import Path


SUPPORTED_TEXT_EXTENSIONS = {'.md', '.txt', '.json', '.jsonl'}
SUPPORTED_IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp'}
SUPPORTED_AUDIO_EXTENSIONS = {'.mp3', '.wav'}
SUPPORTED_VIDEO_EXTENSIONS = {'.mp4', '.flv'}
SUPPORTED_BINARY_EXTENSIONS = {'.bin'}


def get_file_type(file_path: str) -> Tuple[str, bool]:
    ext = Path(file_path).suffix.lower()
    
    if ext in SUPPORTED_TEXT_EXTENSIONS:
        return 'text', True
    elif ext in SUPPORTED_IMAGE_EXTENSIONS:
        return 'image', True
    elif ext in SUPPORTED_AUDIO_EXTENSIONS:
        return 'audio', True
    elif ext in SUPPORTED_VIDEO_EXTENSIONS:
        return 'video', True
    elif ext in SUPPORTED_BINARY_EXTENSIONS:
        return 'binary', True
    else:
        return 'unknown', False


def get_file_info(file_path: str) -> Dict[str, Any]:
    if not os.path.exists(file_path):
        return {
            'path': file_path,
            'exists': False,
            'error': 'File not found'
        }
    
    stat = os.stat(file_path)
    file_type, supported = get_file_type(file_path)
    
    return {
        'path': file_path,
        'exists': True,
        'supported': supported,
        'file_type': file_type,
        'size': stat.st_size,
        'modified': stat.st_mtime,
        'extension': Path(file_path).suffix.lower()
    }


def read_text_file(file_path: str) -> Tuple[bool, Optional[str], Optional[str]]:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return True, content, None
    except UnicodeDecodeError:
        try:
            with open(file_path, 'r', encoding='gbk') as f:
                content = f.read()
            return True, content, None
        except Exception as e:
            return False, None, str(e)
    except Exception as e:
        return False, None, str(e)


def parse_jsonl(file_path: str) -> Tuple[bool, Optional[list], Optional[str]]:
    try:
        records = []
        with open(file_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if line:
                    try:
                        records.append(json.loads(line))
                    except json.JSONDecodeError as e:
                        return False, None, f"Line {line_num}: {str(e)}"
        return True, records, None
    except Exception as e:
        return False, None, str(e)


def parse_json(file_path: str) -> Tuple[bool, Optional[Any], Optional[str]]:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return True, data, None
    except Exception as e:
        return False, None, str(e)


class FileHandler:
    
    def __init__(self):
        self.handlers = {
            '.md': self._handle_text,
            '.txt': self._handle_text,
            '.json': self._handle_json,
            '.jsonl': self._handle_jsonl,
        }
    
    def can_handle(self, file_path: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return ext in self.handlers
    
    def process(self, file_path: str) -> Dict[str, Any]:
        ext = Path(file_path).suffix.lower()
        if ext not in self.handlers:
            return {
                'success': False,
                'error': f'Unsupported file type: {ext}',
                'data': None
            }
        
        return self.handlers[ext](file_path)
    
    def _handle_text(self, file_path: str) -> Dict[str, Any]:
        success, content, error = read_text_file(file_path)
        return {
            'success': success,
            'data': content if success else None,
            'error': error,
            'metadata': {
                'type': 'text',
                'lines': content.count('\n') + 1 if content else 0
            }
        }
    
    def _handle_json(self, file_path: str) -> Dict[str, Any]:
        success, data, error = parse_json(file_path)
        return {
            'success': success,
            'data': data if success else None,
            'error': error,
            'metadata': {
                'type': 'json',
                'keys': list(data.keys()) if isinstance(data, dict) else None
            }
        }
    
    def _handle_jsonl(self, file_path: str) -> Dict[str, Any]:
        success, records, error = parse_jsonl(file_path)
        return {
            'success': success,
            'data': records if success else None,
            'error': error,
            'metadata': {
                'type': 'jsonl',
                'record_count': len(records) if records else 0
            }
        }
