# ClawCoder 🦀

**AI-Powered Coding Assistant** - 一个基于 LangGraph 的交互式命令行编程助手，由 Kimi K2.5 驱动。

## 特性

- 🤖 **AI 对话** - 直接与 Kimi K2.5 智能对话
- 📁 **文件操作** - 浏览、读取、编辑文件
- ⚡ **代码执行** - 运行 shell 命令
- ✏️ **AI 编辑** - 用 AI 辅助修改代码
- 🔍 **文件分析** - 分析文本、图片、音视频文件
- 🛠️ **二进制反汇编** - 支持 x86/x64/ARM 架构
- 💾 **历史存储** - 对话保存为二进制格式

## 安装

```bash
pip install -r requirements.txt
```

## 使用

```bash
# 交互式 REPL 模式
python clawcoder_cli.py

# 指定工作目录
python clawcoder_cli.py /path/to/project

# 快速提问
python clawcoder_cli.py --ask "如何实现快速排序"

# 执行单条命令
python clawcoder_cli.py -e "/ls"
```

## 命令

| 命令 | 功能 |
|------|------|
| `/help` | 显示帮助 |
| `/ls` | 列出文件 |
| `/cd` | 切换目录 |
| `/cat` | 读取文件 |
| `/write` | 写入文件 |
| `/edit` | AI 辅助编辑 |
| `/run` | 运行命令 |
| `/shell` | 进入 shell |
| `/analyze` | 分析文件 |
| `/disasm` | 反汇编二进制 |
| `/history` | 查看历史 |
| `/save` | 保存对话 |

## 支持的文件类型

| 类型 | 扩展名 |
|------|--------|
| 文本 | `.md`, `.txt`, `.json`, `.jsonl` |
| 图片 | `.jpg`, `.jpeg`, `.png`, `.bmp` |
| 音频 | `.mp3`, `.wav` |
| 视频 | `.mp4`, `.flv` |
| 二进制 | `.bin` |

## 配置

设置环境变量 `KIMI_API_KEY` 或在代码中配置：

```python
from clawcoder import create_coder

coder = create_coder(
    api_key="your-api-key",
    base_url="https://api.kimi.com/coding",
    model="k2p5"
)
```

## 架构

```
clawcoder/
├── agent/           # LangGraph 核心框架
│   ├── state.py     # 状态定义
│   └── graph.py     # 图构建
├── processors/      # 文件处理器
│   ├── file_handler.py
│   ├── image_handler.py
│   └── media_handler.py
├── skills/          # 技能模块
│   └── disassembler.py
├── storage/         # 存储模块
│   └── history_storage.py
├── clawcoder.py     # 核心类
└── clawcoder_cli.py # CLI 入口
```

## 作者

**Jason Sang (桑杰逊)**
- Email: sangjiexun@gmail.com
- QQ: 1009900122
- WeChat: bitchatgpt
- GitHub: https://github.com/sangjiexun

## License

MIT License - 详见 [LICENSE](LICENSE) 文件
