import os
import struct
import msgpack
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path


class HistoryStorage:
    
    MAGIC_HEADER = b'CLAW'
    VERSION = 1
    
    def __init__(self, storage_dir: str = "./history"):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_session_file(self, session_id: str) -> Path:
        return self.storage_dir / f"{session_id}.bin"
    
    def _normalize_message(self, message) -> Dict[str, Any]:
        if hasattr(message, 'type'):
            return {
                'role': message.type,
                'content': str(message.content) if hasattr(message, 'content') else str(message),
                'metadata': {}
            }
        elif isinstance(message, dict):
            return message
        else:
            return {
                'role': 'unknown',
                'content': str(message),
                'metadata': {}
            }
    
    def _encode_message(self, message) -> bytes:
        normalized = self._normalize_message(message)
        msg_data = {
            'timestamp': datetime.now().isoformat(),
            'role': normalized.get('role', 'user'),
            'content': normalized.get('content', ''),
            'metadata': normalized.get('metadata', {})
        }
        return msgpack.packb(msg_data, use_bin_type=True)
    
    def _decode_message(self, data: bytes) -> Dict[str, Any]:
        return msgpack.unpackb(data, raw=False)
    
    def save_message(self, session_id: str, message: Dict[str, Any]) -> bool:
        try:
            file_path = self._get_session_file(session_id)
            encoded = self._encode_message(message)
            
            with open(file_path, 'ab') as f:
                f.write(struct.pack('>I', len(encoded)))
                f.write(encoded)
            
            return True
        except Exception as e:
            print(f"Error saving message: {e}")
            return False
    
    def save_messages(self, session_id: str, messages: List[Dict[str, Any]]) -> bool:
        try:
            file_path = self._get_session_file(session_id)
            
            with open(file_path, 'wb') as f:
                f.write(self.MAGIC_HEADER)
                f.write(struct.pack('>I', self.VERSION))
                
                for msg in messages:
                    encoded = self._encode_message(msg)
                    f.write(struct.pack('>I', len(encoded)))
                    f.write(encoded)
            
            return True
        except Exception as e:
            print(f"Error saving messages: {e}")
            return False
    
    def load_messages(self, session_id: str) -> List[Dict[str, Any]]:
        messages = []
        file_path = self._get_session_file(session_id)
        
        if not file_path.exists():
            return messages
        
        try:
            with open(file_path, 'rb') as f:
                header = f.read(4)
                if header != self.MAGIC_HEADER:
                    f.seek(0)
                    return self._load_legacy_format(f)
                
                version = struct.unpack('>I', f.read(4))[0]
                
                while True:
                    length_bytes = f.read(4)
                    if not length_bytes:
                        break
                    
                    length = struct.unpack('>I', length_bytes)[0]
                    data = f.read(length)
                    
                    if data:
                        messages.append(self._decode_message(data))
            
            return messages
        except Exception as e:
            print(f"Error loading messages: {e}")
            return messages
    
    def _load_legacy_format(self, f) -> List[Dict[str, Any]]:
        messages = []
        try:
            while True:
                length_bytes = f.read(4)
                if not length_bytes:
                    break
                
                length = struct.unpack('>I', length_bytes)[0]
                data = f.read(length)
                
                if data:
                    messages.append(self._decode_message(data))
        except:
            pass
        return messages
    
    def append_messages(self, session_id: str, new_messages: List[Dict[str, Any]]) -> bool:
        existing = self.load_messages(session_id)
        existing.extend(new_messages)
        return self.save_messages(session_id, existing)
    
    def get_session_stats(self, session_id: str) -> Dict[str, Any]:
        file_path = self._get_session_file(session_id)
        
        if not file_path.exists():
            return {'exists': False, 'message_count': 0}
        
        messages = self.load_messages(session_id)
        stat = file_path.stat()
        
        return {
            'exists': True,
            'message_count': len(messages),
            'file_size': stat.st_size,
            'modified': datetime.fromtimestamp(stat.st_mtime).isoformat()
        }
    
    def list_sessions(self) -> List[Dict[str, Any]]:
        sessions = []
        
        for file_path in self.storage_dir.glob("*.bin"):
            session_id = file_path.stem
            stats = self.get_session_stats(session_id)
            sessions.append({
                'session_id': session_id,
                **stats
            })
        
        return sorted(sessions, key=lambda x: x.get('modified', ''), reverse=True)
    
    def delete_session(self, session_id: str) -> bool:
        file_path = self._get_session_file(session_id)
        
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    def export_to_json(self, session_id: str) -> Optional[List[Dict[str, Any]]]:
        return self.load_messages(session_id)
