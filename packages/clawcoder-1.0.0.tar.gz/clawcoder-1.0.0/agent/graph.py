from typing import Dict, Any, Optional
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from agent.state import AgentState, create_initial_state
from processors import FileHandler, ImageHandler, MediaHandler, get_file_info, get_file_type
from skills import BinaryDisassembler
from storage import HistoryStorage


class AgentNodes:
    
    def __init__(self, 
                 llm=None,
                 history_storage: HistoryStorage = None):
        self.llm = llm
        self.file_handler = FileHandler()
        self.image_handler = ImageHandler()
        self.media_handler = MediaHandler()
        self.binary_skill = BinaryDisassembler()
        self.history_storage = history_storage or HistoryStorage()
    
    def load_history(self, state: AgentState) -> Dict[str, Any]:
        session_id = state.get('session_id', 'default')
        
        if state.get('history_loaded'):
            return {'next_action': 'process'}
        
        messages = self.history_storage.load_messages(session_id)
        
        return {
            'messages': messages,
            'history_loaded': True,
            'next_action': 'process'
        }
    
    def route_input(self, state: AgentState) -> str:
        query = state.get('query', '')
        current_file = state.get('current_file')
        
        if current_file:
            file_type = current_file.get('file_type', 'unknown')
            
            if file_type == 'text':
                return 'process_text'
            elif file_type == 'image':
                return 'process_image'
            elif file_type in ('audio', 'video'):
                return 'process_media'
            elif file_type == 'binary':
                return 'process_binary'
            else:
                return 'generate_response'
        
        if query:
            return 'generate_response'
        
        return END
    
    def process_text_file(self, state: AgentState) -> Dict[str, Any]:
        current_file = state.get('current_file')
        
        if not current_file:
            return {
                'process_result': {
                    'success': False,
                    'error': 'No file to process',
                    'data': None
                }
            }
        
        file_path = current_file.get('path')
        result = self.file_handler.process(file_path)
        
        return {'process_result': result}
    
    def process_image_file(self, state: AgentState) -> Dict[str, Any]:
        current_file = state.get('current_file')
        
        if not current_file:
            return {
                'process_result': {
                    'success': False,
                    'error': 'No file to process',
                    'data': None
                }
            }
        
        file_path = current_file.get('path')
        result = self.image_handler.process(file_path)
        
        return {'process_result': result}
    
    def process_media_file(self, state: AgentState) -> Dict[str, Any]:
        current_file = state.get('current_file')
        
        if not current_file:
            return {
                'process_result': {
                    'success': False,
                    'error': 'No file to process',
                    'data': None
                }
            }
        
        file_path = current_file.get('path')
        result = self.media_handler.process(file_path)
        
        return {'process_result': result}
    
    def process_binary_file(self, state: AgentState) -> Dict[str, Any]:
        current_file = state.get('current_file')
        
        if not current_file:
            return {
                'process_result': {
                    'success': False,
                    'error': 'No file to process',
                    'data': None
                }
            }
        
        file_path = current_file.get('path')
        result = self.binary_skill.disassemble(file_path)
        
        return {'process_result': result}
    
    def generate_response(self, state: AgentState) -> Dict[str, Any]:
        messages = state.get('messages', [])
        process_result = state.get('process_result')
        query = state.get('query', '')
        
        context_parts = []
        
        if process_result:
            if process_result.get('success'):
                data = process_result.get('data')
                metadata = process_result.get('metadata', {})
                
                if isinstance(data, dict):
                    if 'description' in data:
                        context_parts.append(f"文件信息: {data['description']}")
                    if 'metadata' in data:
                        context_parts.append(f"元数据: {data['metadata']}")
                    if 'instructions' in data:
                        instructions = data['instructions'][:10]
                        context_parts.append("反汇编指令:")
                        for insn in instructions:
                            context_parts.append(f"  {insn['address']}: {insn['mnemonic']} {insn['op_str']}")
                else:
                    context_parts.append(f"处理结果: {str(data)[:500]}")
            else:
                context_parts.append(f"处理失败: {process_result.get('error', 'Unknown error')}")
        
        if self.llm and query:
            try:
                from langchain_core.messages import HumanMessage, AIMessage
                
                prompt = query
                if context_parts:
                    prompt = f"{query}\n\n上下文信息:\n" + "\n".join(context_parts)
                
                lc_messages = [HumanMessage(content=prompt)]
                response = self.llm.invoke(lc_messages)
                
                if hasattr(response, 'content'):
                    response_content = response.content
                else:
                    response_content = str(response)
                    
                assistant_message = AIMessage(content=response_content)
                return {'messages': [assistant_message]}
                
            except Exception as e:
                print(f"LLM error: {e}")
                response_content = f"LLM调用失败: {str(e)}"
        
        elif query:
            response_content = f"收到查询: {query}"
            if context_parts:
                response_content += "\n\n" + "\n".join(context_parts)
        else:
            response_content = "\n".join(context_parts) if context_parts else "无响应"
        
        assistant_message = {
            'role': 'assistant',
            'content': response_content,
            'metadata': {
                'process_result': process_result
            }
        }
        
        return {'messages': [assistant_message]}
    
    def save_history(self, state: AgentState) -> Dict[str, Any]:
        session_id = state.get('session_id', 'default')
        messages = state.get('messages', [])
        
        if messages:
            self.history_storage.save_messages(session_id, messages)
        
        return {}


def create_agent_graph(llm=None, 
                       history_storage: HistoryStorage = None,
                       checkpointer = None) -> StateGraph:
    
    nodes = AgentNodes(llm=llm, history_storage=history_storage)
    
    workflow = StateGraph(AgentState)
    
    workflow.add_node("load_history", nodes.load_history)
    workflow.add_node("process_text", nodes.process_text_file)
    workflow.add_node("process_image", nodes.process_image_file)
    workflow.add_node("process_media", nodes.process_media_file)
    workflow.add_node("process_binary", nodes.process_binary_file)
    workflow.add_node("generate_response", nodes.generate_response)
    workflow.add_node("save_history", nodes.save_history)
    
    workflow.set_entry_point("load_history")
    
    workflow.add_conditional_edges(
        "load_history",
        nodes.route_input,
        {
            "process_text": "process_text",
            "process_image": "process_image",
            "process_media": "process_media",
            "process_binary": "process_binary",
            "generate_response": "generate_response",
            END: END
        }
    )
    
    workflow.add_edge("process_text", "generate_response")
    workflow.add_edge("process_image", "generate_response")
    workflow.add_edge("process_media", "generate_response")
    workflow.add_edge("process_binary", "generate_response")
    workflow.add_edge("generate_response", "save_history")
    workflow.add_edge("save_history", END)
    
    memory = checkpointer or MemorySaver()
    
    return workflow.compile(checkpointer=memory)


def run_agent(graph, 
              query: str = None,
              file_path: str = None,
              session_id: str = "default") -> Dict[str, Any]:
    
    state = create_initial_state(session_id)
    state['query'] = query
    
    if file_path:
        file_info = get_file_info(file_path)
        if file_info.get('exists') and file_info.get('supported'):
            state['current_file'] = file_info
    
    config = {"configurable": {"thread_id": session_id}}
    
    result = graph.invoke(state, config)
    
    return result
