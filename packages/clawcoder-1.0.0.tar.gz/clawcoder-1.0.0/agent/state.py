from typing import TypedDict, Optional, List, Any, Dict, Annotated
from langgraph.graph.message import add_messages
import operator


class FileInfo(TypedDict):
    path: str
    file_type: str
    size: int
    content: Optional[str]
    metadata: Optional[Dict[str, Any]]


class ProcessResult(TypedDict):
    success: bool
    data: Optional[Any]
    error: Optional[str]
    metadata: Optional[Dict[str, Any]]


class AgentState(TypedDict):
    messages: Annotated[List[Dict], add_messages]
    current_file: Optional[FileInfo]
    process_result: Optional[ProcessResult]
    query: Optional[str]
    history_loaded: bool
    session_id: str
    next_action: Optional[str]


def create_initial_state(session_id: str = "default") -> AgentState:
    return AgentState(
        messages=[],
        current_file=None,
        process_result=None,
        query=None,
        history_loaded=False,
        session_id=session_id,
        next_action=None
    )
