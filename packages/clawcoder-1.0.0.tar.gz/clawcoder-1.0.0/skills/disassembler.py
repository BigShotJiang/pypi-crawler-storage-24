from typing import Dict, Any, Optional, List, Tuple
from pathlib import Path
import struct


class BinaryDisassembler:
    
    ARCH_X86 = 'x86'
    ARCH_X64 = 'x64'
    ARCH_ARM = 'arm'
    ARCH_ARM64 = 'arm64'
    
    def __init__(self):
        self._capstone_available = self._check_capstone()
        self._pefile_available = self._check_pefile()
    
    def _check_capstone(self) -> bool:
        try:
            from capstone import Cs, CS_ARCH_X86, CS_MODE_32, CS_MODE_64
            return True
        except ImportError:
            return False
    
    def _check_pefile(self) -> bool:
        try:
            import pefile
            return True
        except ImportError:
            return False
    
    def can_handle(self, file_path: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return ext == '.bin' or self._is_executable(file_path)
    
    def _is_executable(self, file_path: str) -> bool:
        try:
            with open(file_path, 'rb') as f:
                magic = f.read(2)
                if magic == b'MZ':
                    return True
                magic = f.read(2)
                if magic == b'\x7fELF':
                    return True
            return False
        except:
            return False
    
    def detect_architecture(self, file_path: str) -> str:
        try:
            with open(file_path, 'rb') as f:
                magic = f.read(2)
                
                if magic == b'MZ':
                    if self._pefile_available:
                        import pefile
                        pe = pefile.PE(file_path)
                        if pe.OPTIONAL_HEADER.Magic == 0x20b:
                            return self.ARCH_X64
                        else:
                            return self.ARCH_X86
                
                f.seek(0)
                elf_magic = f.read(4)
                if elf_magic == b'\x7fELF':
                    f.seek(4)
                    ei_class = f.read(1)
                    if ei_class == b'\x02':
                        return self.ARCH_X64
                    else:
                        return self.ARCH_X86
        except:
            pass
        
        return self.ARCH_X86
    
    def disassemble(self, file_path: str, 
                    arch: str = None, 
                    offset: int = 0, 
                    count: int = 100) -> Dict[str, Any]:
        
        if not self._capstone_available:
            return self._basic_analysis(file_path)
        
        try:
            from capstone import Cs, CS_ARCH_X86, CS_MODE_32, CS_MODE_64, CS_ARCH_ARM, CS_MODE_ARM
            
            if arch is None:
                arch = self.detect_architecture(file_path)
            
            if arch == self.ARCH_X64:
                md = Cs(CS_ARCH_X86, CS_MODE_64)
            elif arch == self.ARCH_ARM:
                md = Cs(CS_ARCH_ARM, CS_MODE_ARM)
            elif arch == self.ARCH_ARM64:
                try:
                    from capstone import CS_ARCH_ARM64, CS_MODE_ARM
                    md = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
                except:
                    md = Cs(CS_ARCH_X86, CS_MODE_32)
            else:
                md = Cs(CS_ARCH_X86, CS_MODE_32)
            
            with open(file_path, 'rb') as f:
                f.seek(offset)
                code = f.read(count * 15)
            
            instructions = []
            for insn in md.disasm(code, offset):
                instructions.append({
                    'address': hex(insn.address),
                    'bytes': insn.bytes.hex(),
                    'mnemonic': insn.mnemonic,
                    'op_str': insn.op_str
                })
                
                if len(instructions) >= count:
                    break
            
            return {
                'success': True,
                'data': {
                    'architecture': arch,
                    'instructions': instructions,
                    'total_count': len(instructions)
                },
                'error': None,
                'metadata': {
                    'offset': offset,
                    'requested_count': count
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
    
    def _basic_analysis(self, file_path: str) -> Dict[str, Any]:
        try:
            import os
            stat = os.stat(file_path)
            
            with open(file_path, 'rb') as f:
                header = f.read(64)
            
            hex_dump = []
            for i in range(0, min(len(header), 64), 16):
                chunk = header[i:i+16]
                hex_str = ' '.join(f'{b:02x}' for b in chunk)
                ascii_str = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
                hex_dump.append(f'{i:08x}  {hex_str:<48}  {ascii_str}')
            
            return {
                'success': True,
                'data': {
                    'type': 'basic_analysis',
                    'file_size': stat.st_size,
                    'hex_dump': hex_dump,
                    'is_executable': self._is_executable(file_path),
                    'architecture': self.detect_architecture(file_path)
                },
                'error': 'Capstone not available, using basic analysis',
                'metadata': {}
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
    
    def analyze_pe(self, file_path: str) -> Dict[str, Any]:
        if not self._pefile_available:
            return {
                'success': False,
                'error': 'pefile not available',
                'data': None
            }
        
        try:
            import pefile
            
            pe = pefile.PE(file_path)
            
            sections = []
            for section in pe.sections:
                sections.append({
                    'name': section.Name.decode().rstrip('\x00'),
                    'virtual_address': hex(section.VirtualAddress),
                    'virtual_size': section.Misc_VirtualSize,
                    'raw_size': section.SizeOfRawData,
                    'characteristics': hex(section.Characteristics)
                })
            
            imports = []
            if hasattr(pe, 'DIRECTORY_ENTRY_IMPORT'):
                for entry in pe.DIRECTORY_ENTRY_IMPORT:
                    dll_name = entry.dll.decode() if entry.dll else 'Unknown'
                    functions = []
                    for imp in entry.imports:
                        if imp.name:
                            functions.append(imp.name.decode())
                    imports.append({
                        'dll': dll_name,
                        'functions': functions[:10]
                    })
            
            return {
                'success': True,
                'data': {
                    'type': 'pe_analysis',
                    'machine': hex(pe.FILE_HEADER.Machine),
                    'timestamp': pe.FILE_HEADER.TimeDateStamp,
                    'sections': sections,
                    'imports': imports[:5],
                    'is_dll': pe.is_dll(),
                    'is_exe': pe.is_exe()
                },
                'error': None,
                'metadata': {}
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
    
    def strings(self, file_path: str, min_length: int = 4) -> Dict[str, Any]:
        try:
            strings_found = []
            
            with open(file_path, 'rb') as f:
                data = f.read()
            
            current_string = b''
            for byte in data:
                if 32 <= byte < 127:
                    current_string += bytes([byte])
                else:
                    if len(current_string) >= min_length:
                        try:
                            strings_found.append(current_string.decode('ascii'))
                        except:
                            pass
                    current_string = b''
            
            if len(current_string) >= min_length:
                try:
                    strings_found.append(current_string.decode('ascii'))
                except:
                    pass
            
            return {
                'success': True,
                'data': {
                    'strings': strings_found[:100],
                    'total_count': len(strings_found)
                },
                'error': None,
                'metadata': {'min_length': min_length}
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
