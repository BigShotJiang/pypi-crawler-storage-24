"""FastAPI framework plugin (future)."""
