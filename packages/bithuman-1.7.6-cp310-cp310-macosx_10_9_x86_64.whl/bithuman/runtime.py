"""Bithuman Runtime."""

from __future__ import annotations

import asyncio
import copy
import logging
import os
import threading
import time
from functools import cached_property
from pathlib import Path
from queue import Empty, Queue
from threading import Event
from typing import Callable, Generic, Iterable, Optional, Tuple, TypeVar

import numpy as np
from loguru import logger

from . import audio as audio_utils
from .api import AudioChunk, VideoControl, VideoFrame
from .config import load_settings
from .engine.auth import DEFAULT_AUTH_URL
from .exceptions import (
    TokenExpiredError,
    TokenValidationError,
)
from .lib.generator import BithumanGenerator
from .utils import calculate_file_hash
from .video_graph import FrameRef as FrameMeta
from .video_graph import VideoGraph

T = TypeVar("T")

BufferEmptyCallback = Callable[[], bool]


class _ActionDebouncer:
    """Prevent redundant action playback across consecutive frames."""

    __slots__ = ("_lock", "_last_signature")

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._last_signature: Optional[Tuple[str, str]] = None

    def prepare(self, control: VideoControl) -> None:
        if not control.action:
            return

        signature = (control.action, control.target_video or "")
        with self._lock:
            if not control.force_action and signature == self._last_signature:
                logger.debug("Suppressing repeated action: %s", signature)
                control.action = None
            else:
                self._last_signature = signature

    def reset(self) -> None:
        with self._lock:
            self._last_signature = None


class Bithuman:
    """Bithuman Runtime."""

    def __init__(
        self,
        *,
        input_buffer_size: int = 0,
        token: Optional[str] = None,
        model_path: Optional[str] = None,
        api_secret: Optional[str] = None,
        api_url: str = DEFAULT_AUTH_URL,
        tags: Optional[str] = None,
        insecure: bool = False,
        num_threads: int = 0,
        verbose: Optional[bool] = None,
        batch_workers: int = 1,
    ) -> None:
        """Initialize the Bithuman Runtime.

        Args:
            input_buffer_size: The size of the input buffer.
            token: The token for the Bithuman Runtime. Either token or api_secret must be provided.
            model_path: The path to the avatar model.
            api_secret: API Secret for API authentication. Either token or api_secret must be provided.
            api_url: API endpoint URL for token requests.
            tags: Optional tags for token request.
            insecure: Disable SSL certificate verification.
            num_threads: Number of threads for processing, 0 = single-threaded, >0 = use specified number of threads, <0 = auto-detect optimal thread count
            verbose: Enable verbose logging for token validation. If None, reads from BITHUMAN_VERBOSE environment variable.
            batch_workers: Number of parallel workers for offline batch processing (1 = sequential).
        """
        # Set verbose from parameter or environment variable
        if verbose is None:
            verbose = os.getenv("BITHUMAN_VERBOSE", "false").lower() in ("true", "1", "yes", "on")
        self._verbose = verbose
        self._num_threads = num_threads
        self._batch_workers = batch_workers

        # Transaction ID will be generated in C++ layer at start() to prevent user tampering
        self.transaction_id = ""

        logger.debug(
            f"Initializing Bithuman runtime with: model_path={model_path}, token={token is not None}, api_secret={api_secret is not None}, verbose={verbose}"
        )

        # Log environment variables for debugging
        logger.debug(f"BITHUMAN_VERBOSE env var: {os.getenv('BITHUMAN_VERBOSE', 'not set')}")
        logger.debug(f"LOADING_MODE env var: {os.getenv('LOADING_MODE', 'not set')}")
        logger.debug(f"PRELOAD_TO_MEMORY env var: {os.getenv('PRELOAD_TO_MEMORY', 'not set')}")

        # Log credential presence (not values)
        if api_secret:
            logger.debug("API secret provided")
        if token:
            logger.debug("Token provided")

        if not token and not api_secret:
            logger.error("Neither token nor api_secret provided")
            raise ValueError("Either token or api_secret must be provided")

        self.settings = copy.deepcopy(load_settings())

        try:
            # Initialize generator with token refresh parameters if provided
            # Token refresh will start automatically
            self.generator = BithumanGenerator(
                audio_encoder_path=str(self.settings.AUDIO_ENCODER_PATH),
                api_secret=api_secret if api_secret else None,
                api_url=api_url if api_secret else None,
                model_path=model_path if api_secret else None,
                tags=tags if api_secret else None,
                insecure=insecure if api_secret else False,
            )
        except Exception as e:
            logger.error(f"Failed to initialize BithumanGenerator: {e}")
            raise

        self.video_graph: Optional[VideoGraph] = None

        # Store token request parameters
        # Note: These are stored as private attributes to prevent direct modification
        # after initialization. Token refresh parameters are locked once refresh starts.
        self._model_path = model_path
        self._api_secret = api_secret
        self._api_url = api_url
        self._tags = tags
        self._insecure = insecure
        self._token = token
        # Track if token refresh has been started to prevent parameter changes
        self._token_refresh_started = False

        # Token refresh state
        self._action_debouncer = _ActionDebouncer()

        # Account status flag - set to True when account has issues (402, 403, etc.)
        self._account_status_error = threading.Event()

        try:
            self._warmup()
        except Exception as e:
            logger.error(f"Warmup failed: {e}")
            raise

        # Ignore audios when muted
        self.muted = Event()
        self.interrupt_event = Event()
        self._input_buffer = ThreadSafeAsyncQueue[VideoControl](
            maxsize=input_buffer_size
        )

        # Video
        self.audio_batcher = audio_utils.AudioStreamBatcher(
            output_sample_rate=self.settings.INPUT_SAMPLE_RATE
        )
        self._video_loaded = False
        self._sample_per_video_frame = (
            self.settings.INPUT_SAMPLE_RATE / self.settings.FPS
        )
        self._idle_timeout: float = 0.001

        self._model_hash = None
        if self._model_path:
            # load model if provided
            self._initialize_token()
            self.set_model(self._model_path)

    def set_idle_timeout(self, idle_timeout: float) -> None:
        """Set the idle timeout for the Bithuman Runtime.

        Args:
            idle_timeout: The idle timeout in seconds.
        """
        self._idle_timeout = idle_timeout

    def _regenerate_transaction_id(self) -> None:
        """Generate transaction ID for new runtime sessions.

        This method is called when starting the runtime to ensure each session
        has a unique transaction identifier. Once token refresh starts, transaction ID
        is locked and cannot be regenerated to prevent billing bypass.
        """
        old_id = self.transaction_id
        self.transaction_id = self.generator.generate_transaction_id()
        logger.debug(f"Generated transaction ID: {old_id} -> {self.transaction_id}")

    def set_token(self, token: str, verbose: Optional[bool] = None) -> bool:
        """Set and validate the token for the Bithuman Runtime.

        This method validates the provided token and sets it for subsequent operations if valid.

        Args:
            token: The token to validate and set.
            verbose: Enable verbose logging for token validation. If None, uses instance default.

        Returns:
            bool: True if token is valid and set successfully, False otherwise.

        Raises:
            ValueError: If the token is invalid.
        """
        if verbose is None:
            verbose = self._verbose

        logger.debug("Attempting to set token")

        is_valid = self.generator._generator.validate_token(token, verbose)
        if not is_valid:
            logger.error("Token validation failed - token is invalid")
            raise ValueError("Invalid token")

        logger.debug("Token validated and set successfully")
        return True

    def is_token_validated(self) -> bool:
        """Check if the token is validated."""
        return self.generator.is_token_validated()

    def get_expiration_time(self) -> int:
        """Get the expiration time of the token."""
        return self.generator.get_expiration_time()


    @staticmethod
    def _is_token_error(e: Exception) -> bool:
        """Check if an exception is a token-related error."""
        if isinstance(e, (TokenExpiredError, TokenValidationError)):
            return True
        # Backward compat: check RuntimeError messages from legacy code paths
        if isinstance(e, RuntimeError):
            msg = str(e).lower()
            return any(s in msg for s in (
                "token has expired",
                "token not validated",
                "token validation failed",
            ))
        return False

    def _initialize_token(self) -> None:
        """Initialize token if provided by user.

        If user provided a token, validate and set it.
        If user provided api_secret, token refresh is handled automatically.
        """
        if self._token:
            logger.debug("Token provided, validating...")
            try:
                is_valid = self.generator._generator.validate_token(self._token, self._verbose)
                if not is_valid:
                    raise ValueError("Token validation failed")
                logger.debug("Token validated and set successfully")
            except Exception as e:
                logger.warning(f"Token validation failed: {e}")
                raise
        # If api_secret is provided, token refresh is handled automatically


    def set_model(self, model_path: str) -> "Bithuman":
        """Set the video file or workspace directory.

        Args:
            model_path: The workspace directory.
        """
        if not model_path:
            logger.error("No model path provided to set_model()")
            raise ValueError("Model path cannot be empty")

        if model_path == self._model_path and self._video_loaded:
            logger.debug("Model path is the same as the current model path, skipping")
            return

        if not Path(model_path).exists():
            raise FileNotFoundError(f"Model path {model_path} does not exist")

        # ---- Step 1: Extract model hash ----
        # IMX fast path: read from stored metadata (~0ms).
        # Legacy: compute MD5 from file (slow, but unavoidable).
        stored_model_hash = None
        if Path(model_path).is_file():
            from .engine.video_reader import ImxContainer, is_imx_file

            if is_imx_file(model_path):
                _container = ImxContainer(model_path)
                if _container.has_metadata:
                    stored_model_hash = _container.metadata["model_hash"]
                    self.generator.set_model_hash(stored_model_hash)
                    self._model_hash = stored_model_hash
                    logger.debug(f"IMX fast path: using stored model hash {stored_model_hash[:12]}...")
                del _container  # navigator will create its own

            if stored_model_hash is None:
                # Legacy path: compute hash from file
                try:
                    model_hash = self.generator.set_model_hash_from_file(model_path)
                    self._model_hash = model_hash
                except Exception as e:
                    logger.error(f"Failed to calculate model hash: {e}")
                    raise
        else:
            logger.info(
                "Skip model hash verification for non-file avatar model, "
                "make sure the token is valid for kind of usage."
            )
            self._model_hash = None

        # Security check: If token refresh is already running, verify model_path matches
        if self._api_secret and self._api_url:
            if self.generator.is_token_refresh_running():
                if self._model_path and model_path != self._model_path:
                    logger.error(
                        f"Security violation: Cannot change model_path from '{self._model_path}' "
                        f"to '{model_path}' after token refresh has started. "
                        "Token refresh parameters are locked for security."
                    )
                    raise RuntimeError(
                        "Cannot change model_path after token refresh has started. "
                        "This is a security restriction."
                    )

        # Store the model path for token requests
        self._model_path = model_path

        # ---- Step 2: Fire token request in background (non-blocking) ----
        # Token is needed for process_audio() JWT validation, but not for
        # model loading or initial frame rendering. A 10s grace period lets
        # the caller start producing frames immediately while the token
        # request completes in the background.
        self._pending_token_future = None
        if self._api_secret and self._api_url and not self.generator.is_token_refresh_running():
            if not self.transaction_id:
                self._regenerate_transaction_id()
            self.generator.set_token_grace_period(10.0)
            import concurrent.futures

            self._token_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            self._pending_token_future = self._token_executor.submit(self._request_initial_token)

            def _on_token_done(fut: concurrent.futures.Future) -> None:
                try:
                    fut.result()
                except Exception as e:
                    logger.error(f"Background token request failed: {e}")
                    self.generator.set_token_request_error(e)
                finally:
                    executor = self._token_executor
                    if executor is not None:
                        executor.shutdown(wait=False)

            self._pending_token_future.add_done_callback(_on_token_done)

        # ---- Step 3: Load model ----
        try:
            self.video_graph = VideoGraph.from_workspace(
                model_path, extract_to_local=self.settings.EXTRACT_WORKSPACE_TO_LOCAL
            ).load_workspace()
        except Exception as e:
            logger.error(f"Failed to create VideoGraph or load workspace: {e}")
            raise


        try:
            self.video_graph.update_runtime_configs(self.settings)
        except Exception as e:
            logger.error(f"Failed to update runtime configs: {e}")
            raise

        try:
            self.generator.set_output_size(self.settings.OUTPUT_WIDTH)
        except Exception as e:
            logger.error(f"Failed to set output size: {e}")
            raise

        self._video_loaded = False

        try:
            self.load_data()
        except Exception as e:
            logger.error(f"load_data() failed: {e}")
            raise

        return self

    @property
    def model_hash(self) -> Optional[str]:
        """Get the model hash (read-only).

        Returns the unique model hash that was generated during model loading.
        This property is read-only and cannot be modified after initialization
        after initialization.

        Returns:
            Optional[str]: The model hash if a file model was loaded, None otherwise.
        """
        return self._model_hash

    def _request_initial_token(self) -> None:
        """Request and validate initial token. Safe to call from a background thread."""
        initial_token = self.generator.request_token(
            api_url=self._api_url,
            api_secret=self._api_secret,
            model_path=None,  # hash already set via set_model_hash
            tags=self._tags,
            transaction_id=self.transaction_id,
            insecure=self._insecure,
            timeout=30.0,
        )
        is_valid = self.generator._generator.validate_token(initial_token, self._verbose)
        if not is_valid:
            raise RuntimeError("Initial token validation failed")
        logger.debug("Initial token requested and validated in set_model()")

    def _wait_for_pending_token(self, timeout: float = 30.0) -> None:
        """Wait for the background token request from set_model() to finish.

        Called by run()/start() before start_token_refresh() so the refresh
        loop can reuse the already-validated token instead of making a
        duplicate HTTP request.
        """
        fut = getattr(self, "_pending_token_future", None)
        if fut is None or fut.done():
            return
        try:
            fut.result(timeout=timeout)
        except Exception:
            pass  # error already handled by _on_token_done callback

    def load_data(self) -> None:
        """Load the workspace and set up related components."""
        if self._video_loaded:
            return
        if self.video_graph is None:
            logger.error("Video graph is None. Model may not be set properly.")
            raise ValueError("Video graph is not set. Call set_model() first.")

        container = self.video_graph.imx_container

        # ---- IMX v2 fast path: read everything from container, no filesystem ----
        if container is not None and container.has_metadata:
            import io

            from .engine.video_reader import MP4VideoReader

            metadata = container.metadata
            format_version = metadata.get("format_version", metadata.get("version", 1))

            if format_version >= 2:
                # ---- IMX v2 fast path ----
                from .engine.patch_reader import PatchReader
                from .engine.video_data import LipFormat

                # Load audio features
                fc_file = metadata["audio"]["feature_centers_file"]
                fc_data = container.read_file(fc_file)
                if fc_file.endswith(".npz"):
                    audio_features = np.load(io.BytesIO(fc_data))["arr_0"]
                else:
                    audio_features = np.load(io.BytesIO(fc_data))
                self.generator.set_audio_feature(audio_features)

                videos = list(self.video_graph.videos.items())
                preload = self.settings.PRELOAD_TO_MEMORY
                logger.info(
                    f"Loading model data (IMX v2 fast path): {len(videos)} videos"
                    f"{', PRELOAD_TO_MEMORY enabled' if preload else ''}"
                )

                for name, video in videos:
                    vmeta = metadata["videos"].get(name)
                    if vmeta is None:
                        logger.warning(f"Skipping video '{name}' - not in manifest.json")
                        continue

                    # Get MP4 reader for original video.
                    # Cache frames only for ping-pong LoopingVideos (backward
                    # seeks re-decode from frame 0 without a cache).
                    # SingleActionVideos play forward-only — no cache needed.
                    # Note: caching ALL videos causes OOM for agents with many
                    # videos (13 × ~400 MB = 5+ GB > 4 GB limit).
                    video_file = vmeta["video_file"]
                    is_looping = vmeta.get("type") == "LoopingVideo" and not vmeta.get("single_direction", False)
                    mp4_offset, mp4_size = container.get_entry(video_file)
                    original_reader = MP4VideoReader(
                        container.path,
                        base_offset=mp4_offset,
                        file_size=mp4_size,
                        frame_count=vmeta.get("frame_count", 0),
                        cache_frames=is_looping,
                    )

                    # Store reader on DriverVideo for get_first_frame()
                    video._original_frame_reader = original_reader

                    # Check for lip_sync data
                    lip = vmeta.get("lip_sync")
                    avatar_reader = None
                    h5_bytes = None

                    if lip:
                        h5_file = lip["h5_file"]
                        h5_bytes = io.BytesIO(container.read_file(h5_file))

                        bases_off, bases_sz = container.get_entry(lip["bases_file"])
                        patches_off, patches_sz = container.get_entry(lip["patches_file"])

                        avatar_reader = PatchReader(
                            container.path, container.path,
                            meta=lip,  # pass manifest lip_sync dict directly (has crop_bbox, num_source_frames, num_clusters)
                            decode_fn="webp",
                            bases_offset=bases_off, bases_size=bases_sz,
                            patches_offset=patches_off, patches_size=patches_sz,
                            preload=self.settings.PRELOAD_TO_MEMORY,
                        )

                    self.generator.add_video(
                        name,
                        video_path="",
                        video_data_path=h5_bytes or "",
                        avatar_data_path="",
                        compression_type=self.settings.COMPRESS_METHOD,
                        loading_mode=self.settings.LOADING_MODE,
                        thread_count=self._num_threads,
                        original_frame_reader=original_reader,
                        avatar_reader=avatar_reader,
                    )

                logger.info("Model data loaded successfully (IMX v2 fast path)")
                self._video_loaded = True
                return

            else:
                raise RuntimeError(
                    "This model uses an outdated container format (v1). Please upgrade:\n"
                    "  pip install --upgrade bithuman\n"
                    f"  bithuman convert {self._model_path}"
                )

        # Legacy filesystem path is no longer reachable — TAR models are
        # auto-converted to IMX v2 by unzip_tarfile().
        raise RuntimeError(
            "Unexpected state: model loaded without an IMX v2 container. "
            "This should not happen — legacy TAR models are auto-converted."
        )

    def get_first_frame(self) -> Optional[np.ndarray]:
        """Get the first frame of the video."""
        if not self.video_graph:
            logger.error("Model is not set. Call set_model() first.")
            return None
        try:
            frame = self.video_graph.get_first_frame(self.settings.OUTPUT_WIDTH)
            return frame
        except Exception as e:
            logger.error(f"Failed to get the first frame: {e}")
            return None

    def get_frame_size(self) -> tuple[int, int]:
        """Get the frame size in width and height."""
        image = self.get_first_frame()
        if image is None:
            logger.error("Failed to get the first frame")
            raise ValueError("Failed to get the first frame")
        size = (image.shape[1], image.shape[0])
        return size

    def interrupt(self) -> None:
        """Interrupt the daemon."""
        # clear the input buffer
        while not self._input_buffer.empty():
            try:
                self._input_buffer.get_nowait()
            except Empty:
                break
        self.audio_batcher.reset()
        self.interrupt_event.set()

    def set_muted(self, mute: bool) -> None:
        """Set the muted state."""
        if mute:
            self.muted.set()
        else:
            self.muted.clear()

    def push_audio(
        self, data: bytes, sample_rate: int, last_chunk: bool = True
    ) -> None:
        """Push the audio to the input buffer."""
        self._input_buffer.put(VideoControl.from_audio(data, sample_rate, last_chunk))

    def flush(self) -> None:
        """Flush the input buffer."""
        self._input_buffer.put(VideoControl(end_of_speech=True))

    def push(self, control: VideoControl) -> None:
        """Push the control (with audio, text, action, etc.) to the input buffer."""
        self._input_buffer.put(control)

    def run(
        self,
        out_buffer_empty: Optional[BufferEmptyCallback] = None,
        *,
        idle_timeout: float | None = None,
    ) -> Iterable[VideoFrame]:
        # Start token refresh if api_secret is provided and refresh is not already running
        if self._api_secret and self._api_url and self._model_path:
            if not self.generator.is_token_refresh_running():
                try:
                    if not self.transaction_id:
                        self._regenerate_transaction_id()

                    success = self.generator.start_token_refresh(
                        api_url=self._api_url,
                        api_secret=self._api_secret,
                        model_path=self._model_path,
                        tags=self._tags,
                        refresh_interval=60,
                        insecure=self._insecure,
                        timeout=30.0
                    )
                    if success:
                        logger.debug("Token refresh started in run()")
                        self._token_refresh_started = True
                    else:
                        logger.error("Failed to start token refresh in run()")
                        raise RuntimeError("Failed to start token refresh")
                except Exception as e:
                    logger.error(f"Failed to start token refresh in run(): {e}")
                    raise
            else:
                # Token refresh already running - just ensure transaction ID is set
                if not self.transaction_id:
                    self._regenerate_transaction_id()
        else:
            # Generate transaction ID only if not already set (prevents bypassing billing)
            if not self.transaction_id:
                self._regenerate_transaction_id()

        # Current frame index, reset for every new audio
        if self.video_graph is None:
            raise ValueError("Model is not set. Call set_model() first.")

        curr_frame_index = 0
        action_played = False  # Whether the action is played in this speech
        token_expired = False  # Flag to track token expiration
        _idle_action_active = False  # True while an idle action is playing

        while True:
            # Check if token has expired - if so, stop immediately
            if token_expired:
                logger.error("Token has expired, stopping runtime")
                # Stop token refresh if running
                if self.generator.is_token_refresh_running():
                    try:
                        self.generator._generator.stop_token_refresh()
                    except Exception as stop_error:
                        logger.warning(f"Error stopping token refresh: {stop_error}")
                break

            try:
                if self.interrupt_event.is_set():
                    # Clear the interrupt event for the next loop
                    self.interrupt_event.clear()
                    action_played = False
                control = self._input_buffer.get(
                    timeout=idle_timeout or self._idle_timeout
                )
                if control.action:
                    logger.debug(f"Action: {control.action}")
                if self.muted.is_set():
                    # Consume and skip the audio when muted
                    control = VideoControl(message_id="MUTED")
                    action_played = False  # Reset the action played flag
            except Empty:
                if out_buffer_empty and not out_buffer_empty():
                    continue
                control = VideoControl(message_id="IDLE")  # idle

            if self.video_graph is None:
                # cleanup is called
                logger.debug("Stopping runtime after cleanup")
                break

            # Idle action lifecycle:
            # 1. Action dispatched → _idle_action_active = True
            # 2. Buffer drains frame-by-frame (script skipped)
            # 3. Buffer empty → reset idle timer, _idle_action_active = False
            # 4. Audio arrival → _idle_action_active = False (immediate interrupt)
            if not control.is_idle:
                _idle_action_active = False
            elif _idle_action_active and not self.video_graph.frame_buffer:
                self.video_graph.videos_script.last_nonidle_frame = curr_frame_index
                _idle_action_active = False

            _skip_script = control.is_idle and _idle_action_active

            if not control.target_video and not control.action and not _skip_script:
                # Save idle state before get_video_and_actions() mutates the control.
                # Setting target_video makes is_idle return False, but we need the
                # original state to know whether this was an idle-triggered action.
                _was_idle = control.is_idle
                control.target_video, control.action, reset_action = (
                    self.video_graph.videos_script.get_video_and_actions(
                        curr_frame_index,
                        control.emotion_preds,
                        text=control.text,
                        is_idle=_was_idle,
                        settings=self.settings,
                    )
                )
                if reset_action:
                    action_played = False
                if _was_idle and control.action:
                    _idle_action_active = True

            if control.force_action and control.action:
                _idle_action_active = True

            if not control.is_idle:
                # Avoid playing the action multiple times in a conversation
                if action_played and not control.force_action:
                    control.action = None
                elif control.action:
                    action_played = True

            try:
                frames_yielded = False
                for frame in self.process(control):
                    yield frame
                    curr_frame_index += 1
                    frames_yielded = True

            except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
                if self._is_token_error(e):
                    logger.error(f"Token error in run() loop: {e}")
                    token_expired = True
                    if self.generator.is_token_refresh_running():
                        try:
                            self.generator._generator.stop_token_refresh()
                        except Exception as stop_error:
                            logger.warning(f"Error stopping token refresh: {stop_error}")
                    break
                raise

            if control.end_of_speech:
                self.audio_batcher.reset()
                # Passthrough the end flag of the speech
                yield VideoFrame(
                    source_message_id=control.message_id,
                    end_of_speech=control.end_of_speech,
                )

                # Reset the action played flag
                action_played = False
                curr_frame_index = 0
                self.video_graph.videos_script.last_nonidle_frame = 0
                self._action_debouncer.reset()

                # Reset the video graph if needed
                self.video_graph.next_n_frames(num_frames=0, on_user_speech=True)

    def process(self, control: VideoControl) -> Iterable[VideoFrame]:
        """Process the audio or control data."""

        def _get_next_frame(force_talking: bool = False) -> FrameMeta:
            # When processing audio, force immediate switch to talking video
            # to eliminate residual frames from action videos (fixes flashing)
            target_video = control.target_video
            action = control.action

            if force_talking and not target_video:
                target_video = (
                    self.video_graph.videos_script.default_video
                    or next(iter(self.video_graph.videos), None)
                )
                action = None  # Clear actions to ensure immediate switch

            if action or target_video:
                self._action_debouncer.prepare(control)
                if action:
                    logger.debug(f"Getting next frame for control: {target_video} {action}")

            return self.video_graph.next_n_frames(
                num_frames=1,
                target_video_name=target_video,
                actions_name=action,
                on_agent_speech=control.is_speaking,
                stop_on_user_speech_override=control.stop_on_user_speech,
                stop_on_agent_speech_override=control.stop_on_agent_speech,
            )[0]

        frame_index = 0
        # Get audio chunks from either push (normal audio) or flush (end of speech).
        # When end_of_speech arrives, the batcher may still hold accumulated audio
        # that hasn't reached the batch threshold yet — flush it so the tail
        # of the sentence isn't lost.
        audio_source = []
        if control.audio is not None:
            audio_source = self.audio_batcher.push(control.audio)
        elif control.end_of_speech:
            final = self.audio_batcher.flush()
            if final is not None:
                audio_source = [final]

        if audio_source:
            for padded_chunk in audio_source:
                audio_array = padded_chunk.array

                # get the mel chunks on padded audio
                mel_chunks = audio_utils.get_mel_chunks(
                    audio_utils.int16_to_float32(audio_array), fps=self.settings.FPS
                )
                # unpad the audio and mel chunks
                audio_array = self.audio_batcher.unpad(audio_array)
                start = self.audio_batcher.pre_pad_video_frames
                valid_frames = int(len(audio_array) / self._sample_per_video_frame)
                mel_chunks = mel_chunks[start : start + valid_frames]

                num_frames = len(mel_chunks)
                # Trim audio to exactly valid_frames worth of samples.
                # After flush(), end_pad alignment can leave extra samples
                # that inflate output audio duration beyond video duration.
                expected_samples = int(valid_frames * self._sample_per_video_frame)
                audio_array = audio_array[:expected_samples]
                samples_per_frame = len(audio_array) // max(num_frames, 1)

                # ----- Batch path: batch ONNX + KNN when num_frames > 1 -----
                use_batch = getattr(self, '_batch_workers', 1) > 0 and num_frames > 1
                if use_batch:
                    # 1. Pre-collect frame metadata (sequential — advances video graph)
                    frame_metas = []
                    interrupted_at_batch = False
                    for _i in range(num_frames):
                        if self.muted.is_set() or self.interrupt_event.is_set():
                            if self.interrupt_event.is_set():
                                self.interrupt_event.clear()
                            interrupted_at_batch = True
                            break
                        frame_metas.append(_get_next_frame(force_talking=True))

                    # If interrupted during pre-collection, yield remaining audio so
                    # the WebRTC stream doesn't have a gap, then move on.
                    if interrupted_at_batch:
                        if len(audio_array) > 0:
                            yield VideoFrame(
                                bgr_image=None,
                                audio_chunk=AudioChunk(
                                    data=audio_array,
                                    sample_rate=padded_chunk.sample_rate,
                                    last_chunk=True,
                                ),
                                frame_index=frame_index,
                                source_message_id=control.message_id,
                            )
                        continue  # Next padded_chunk in audio_source

                    # Check all frames target the same video (required for batch)
                    video_names = {fm.video_name for fm in frame_metas}
                    if len(video_names) == 1:
                        vname = frame_metas[0].video_name
                        findices = [fm.frame_index for fm in frame_metas]
                        try:
                            frames = self.generator.process_audio_batch(
                                list(mel_chunks), vname, findices,
                                max_workers=self._batch_workers,
                            )
                        except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
                            if self._is_token_error(e):
                                logger.error(f"Token error during batch processing: {e}")
                                raise
                            raise

                        for i, frame in enumerate(frames):
                            audio_start = i * samples_per_frame
                            audio_end = (
                                audio_start + samples_per_frame
                                if i < num_frames - 1
                                else len(audio_array)
                            )
                            yield VideoFrame(
                                bgr_image=frame,
                                audio_chunk=AudioChunk(
                                    data=audio_array[audio_start:audio_end],
                                    sample_rate=padded_chunk.sample_rate,
                                    last_chunk=i == num_frames - 1,
                                ),
                                frame_index=frame_index,
                                source_message_id=control.message_id,
                            )
                            frame_index += 1
                    else:
                        # Mixed videos — fall through to sequential path
                        for i, mel_chunk in enumerate(mel_chunks):
                            if self.muted.is_set() or self.interrupt_event.is_set():
                                if self.interrupt_event.is_set():
                                    self.interrupt_event.clear()
                                # Yield remaining audio to prevent WebRTC gap
                                remaining_audio = audio_array[i * samples_per_frame:]
                                if len(remaining_audio) > 0:
                                    yield VideoFrame(
                                        bgr_image=None,
                                        audio_chunk=AudioChunk(
                                            data=remaining_audio,
                                            sample_rate=padded_chunk.sample_rate,
                                            last_chunk=True,
                                        ),
                                        frame_index=frame_index,
                                        source_message_id=control.message_id,
                                    )
                                break
                            try:
                                frame = self._process_talking_frame(frame_metas[i], mel_chunk)
                            except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
                                if self._is_token_error(e):
                                    logger.error(f"Token error during frame processing: {e}")
                                    raise
                                raise
                            audio_start = i * samples_per_frame
                            audio_end = (
                                audio_start + samples_per_frame
                                if i < num_frames - 1
                                else len(audio_array)
                            )
                            yield VideoFrame(
                                bgr_image=frame,
                                audio_chunk=AudioChunk(
                                    data=audio_array[audio_start:audio_end],
                                    sample_rate=padded_chunk.sample_rate,
                                    last_chunk=i == num_frames - 1,
                                ),
                                frame_index=frame_index,
                                source_message_id=control.message_id,
                            )
                            frame_index += 1

                # ----- Sequential path (streaming / single frame) -----
                else:
                    for i, mel_chunk in enumerate(mel_chunks):
                        if self.muted.is_set() or self.interrupt_event.is_set():
                            if self.interrupt_event.is_set():
                                self.interrupt_event.clear()
                            # Yield remaining audio to prevent WebRTC gap
                            remaining_audio = audio_array[i * samples_per_frame:]
                            if len(remaining_audio) > 0:
                                yield VideoFrame(
                                    bgr_image=None,
                                    audio_chunk=AudioChunk(
                                        data=remaining_audio,
                                        sample_rate=padded_chunk.sample_rate,
                                        last_chunk=True,
                                    ),
                                    frame_index=frame_index,
                                    source_message_id=control.message_id,
                                )
                            break

                        try:
                            # Force immediate switch to talking video when processing audio
                            frame_meta = _get_next_frame(force_talking=True)
                            frame = self._process_talking_frame(frame_meta, mel_chunk)
                        except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
                            if self._is_token_error(e):
                                logger.error(f"Token error during frame processing: {e}")
                                raise
                            raise

                        audio_start = i * samples_per_frame
                        audio_end = (
                            audio_start + samples_per_frame
                            if i < num_frames - 1
                            else len(audio_array)
                        )
                        yield VideoFrame(
                            bgr_image=frame,
                            audio_chunk=AudioChunk(
                                data=audio_array[audio_start:audio_end],
                                sample_rate=padded_chunk.sample_rate,
                                last_chunk=i == num_frames - 1,
                            ),
                            frame_index=frame_index,
                            source_message_id=control.message_id,
                        )
                        frame_index += 1

        if frame_index == 0 and not control.audio:
            # generate idle frame if no frame is generated
            try:
                frame_meta = _get_next_frame()
                frame = self._process_idle_frame(frame_meta)
            except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
                if self._is_token_error(e):
                    logger.error(f"Token error during idle frame processing: {e}")
                    raise
                raise

            yield VideoFrame(
                bgr_image=frame,
                frame_index=frame_index,
                source_message_id=control.message_id,
            )

    def _process_talking_frame(
        self, frame: FrameMeta, mel_chunk: np.ndarray
    ) -> np.ndarray:
        """Process a talking frame with audio-driven lip sync.

        Args:
            frame: Frame metadata
            mel_chunk: Mel spectrogram chunk

        Returns:
            Processed frame as numpy array
        """
        frame_np = self.generator.process_audio(
            mel_chunk, frame.video_name, frame.frame_index
        )
        return frame_np

    def _process_idle_frame(self, frame: FrameMeta) -> np.ndarray:
        """Get the idle frame with cache.

        Args:
            frame: Frame metadata

        Returns:
            Processed frame as numpy array
        """
        try:
            # Action videos (dance, walk, etc.) have no lip-sync data.
            # process_audio() would silently fall back to the talking video,
            # so use get_original_frame() for them instead.
            video = self.video_graph.videos.get(frame.video_name)
            use_lip_sync = (
                self.settings.PROCESS_IDLE_VIDEO
                and video is not None
                and video.lip_sync_required
            )

            if use_lip_sync:
                frame_np = self.generator.process_audio(
                    self.silent_mel_chunk, frame.video_name, frame.frame_index
                )
            else:
                frame_np = self.generator.get_original_frame(
                    frame.video_name, frame.frame_index
                )

            return frame_np
        except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
            if self._is_token_error(e):
                logger.error(f"Token error during idle frame processing: {e}")
            raise

    @cached_property
    def silent_mel_chunk(self) -> np.ndarray:
        """The mel chunk for silent audio."""
        audio_np = np.zeros(self.settings.INPUT_SAMPLE_RATE * 1, dtype=np.float32)
        return audio_utils.get_mel_chunks(audio_np, fps=self.settings.FPS)[0]

    def _warmup(self) -> None:
        """Warm up the audio processing."""
        audio_utils.get_mel_chunks(
            np.zeros(16000, dtype=np.float32), fps=self.settings.FPS
        )


    def cleanup(self) -> None:
        """Clean up resources."""
        import gc

        # Shut down the token executor if it exists and hasn't been cleaned up yet
        executor = getattr(self, "_token_executor", None)
        if executor is not None:
            try:
                executor.shutdown(wait=False)
            except Exception as e:
                logger.debug(f"Error shutting down token executor: {e}")
            self._token_executor = None

        # Close all video/avatar readers held by the generator (biggest memory consumers)
        gen = getattr(self, "generator", None)
        if gen:
            inner = getattr(gen, "_generator", None)
            if inner:
                for vdata in getattr(inner, "_video_data", {}).values():
                    # Close original frame reader (MP4VideoReader with frame cache)
                    reader = getattr(vdata, "_original_frame_reader", None)
                    if reader and hasattr(reader, "close"):
                        try:
                            reader.close()
                        except Exception:
                            pass
                    # Close avatar/lip-sync reader (PatchReader with preloaded data)
                    areader = getattr(vdata, "_avatar_reader", None)
                    if areader and hasattr(areader, "close"):
                        try:
                            areader.close()
                        except Exception:
                            pass
                inner._video_data.clear()

        vg = getattr(self, "video_graph", None)
        if vg:
            # Clear graph caches before cleanup
            vg.clips.clear()
            vg.filler_clips.clear()
            vg.similarity_matrices.clear()
            vg.path_cache.clear()
            vg.frame_buffer.clear()
            vg.cleanup()
            self.video_graph = None

        # Force garbage collection to release numpy arrays back to the allocator
        gc.collect()

    def __del__(self) -> None:
        """Clean up the video graph."""
        self.cleanup()

    @classmethod
    def create(
        cls,
        *,
        model_path: Optional[str] = None,
        token: Optional[str] = None,
        api_secret: Optional[str] = None,
        api_url: str = DEFAULT_AUTH_URL,
        tags: Optional[str] = None,
        insecure: bool = False,
        input_buffer_size: int = 0,
        verbose: Optional[bool] = None,
    ) -> "Bithuman":
        """Create a fully initialized Bithuman instance.

        Token validation and refresh are handled automatically:
        - If token is provided, it will be validated
        - If api_secret and model_path are provided, token refresh will start when run() is called
        """
        # Create instance - token refresh will start lazily when run() is called
        instance = cls(
            input_buffer_size=input_buffer_size,
            token=token,
            model_path=model_path,
            api_secret=api_secret,
            api_url=api_url,
            tags=tags,
            insecure=insecure,
            verbose=verbose,
        )

        # Validate token if provided (validation happens in _initialize_token during start/set_model)
        # Token refresh will start lazily when run() is called if api_secret is provided

        # Set model if provided
        if model_path:
            try:
                instance.set_model(model_path)
            except Exception as e:
                logger.error(f"Failed to set model: {e}")
                raise
        else:
            logger.warning("No model path provided to factory method")

        # Verify initialization success
        try:
            if instance.video_graph is None:
                raise ValueError("Video graph not initialized")
        except Exception as e:
            logger.error(f"Initialization verification failed: {e}")
            raise

        return instance



class ThreadSafeAsyncQueue(Generic[T]):
    """A thread-safe queue that can be used from both async and sync contexts.

    This queue uses a standard threading.Queue internally for thread safety,
    but provides async methods for use in async contexts.
    """

    def __init__(
        self, maxsize: int = 0, event_loop: Optional[asyncio.AbstractEventLoop] = None
    ):
        """Initialize the queue.

        Args:
            maxsize: Maximum size of the queue. 0 means unlimited.
            event_loop: The event loop to use.
        """
        self._queue = Queue[T](maxsize=maxsize)
        self._loop = event_loop

    def put_nowait(self, item: T) -> None:
        """Put an item into the queue without blocking."""
        self._queue.put_nowait(item)

    async def aput(self, item: T, *args, **kwargs) -> None:
        """Put an item into the queue asynchronously."""
        # Use run_in_executor to avoid blocking the event loop
        if not self._loop:
            self._loop = asyncio.get_event_loop()
        await self._loop.run_in_executor(None, self._queue.put, item, *args, **kwargs)

    def put(self, item: T, *args, **kwargs) -> None:
        """Put an item into the queue."""
        self._queue.put(item, *args, **kwargs)

    def get_nowait(self) -> T:
        """Get an item from the queue without blocking."""
        return self._queue.get_nowait()

    async def aget(self, *args, **kwargs) -> T:
        """Get an item from the queue asynchronously."""
        # Use run_in_executor to avoid blocking the event loop
        if not self._loop:
            self._loop = asyncio.get_event_loop()
        return await self._loop.run_in_executor(None, self._queue.get, *args, **kwargs)

    def get(self, *args, **kwargs) -> T:
        """Get an item from the queue."""
        return self._queue.get(*args, **kwargs)

    def task_done(self) -> None:
        """Mark a task as done."""
        self._queue.task_done()

    def empty(self) -> bool:
        """Check if the queue is empty."""
        return self._queue.empty()

    def qsize(self) -> int:
        """Get the size of the queue."""
        return self._queue.qsize()

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Set the event loop."""
        self._loop = loop
