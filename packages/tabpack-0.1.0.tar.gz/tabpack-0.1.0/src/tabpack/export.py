import sqlite3
import os
import sys
from datetime import datetime

BOOKMARKS_HEADER = """<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file.
     It will be read and overwritten.
     DO NOT EDIT! -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks Menu</H1>
<DL><p>
"""
BOOKMARKS_FOOTER = "</DL><p>\n"


def get_safari_db_path(custom_path=None):
    if custom_path:
        return custom_path

    # Default macOS path
    home = os.path.expanduser("~")
    return os.path.join(
        home,
        "Library",
        "Containers",
        "com.apple.Safari",
        "Data",
        "Library",
        "Safari",
        "SafariTabs.db",
    )


def export_bookmarks(db_path, output_file):
    if not os.path.exists(db_path):
        print(f"Error: Database not found at {db_path}", file=sys.stderr)
        print(
            "Please ensure you have copied the db or have Full Disk Access.",
            file=sys.stderr,
        )
        return False

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # In SafariTabs.db:
        # type 1 = Folder / Tab Group
        # type 0 = Bookmark / Tab
        # parent = ID of the parent folder (0 for root level things)

        # First, find all tab groups (folders)
        cursor.execute(
            "SELECT id, title FROM bookmarks WHERE type = 1 AND title IS NOT NULL AND title != ''"
        )
        groups = cursor.fetchall()

        # Second, find open windows to get their local_tab_group_id
        cursor.execute(
            "SELECT id, local_tab_group_id FROM windows WHERE local_tab_group_id IS NOT NULL"
        )
        windows = cursor.fetchall()

        # Map local_tab_group_ids to window IDs
        local_tab_groups = {row[1]: row[0] for row in windows}

        if not groups and not windows:
            print("No tab groups or open windows found in the database.")
            return False

        with open(output_file, "w", encoding="utf-8") as f:
            f.write(BOOKMARKS_HEADER)

            for group_id, group_title in groups:
                # Find tabs for this group
                cursor.execute(
                    "SELECT title, url FROM bookmarks WHERE type = 0 AND parent = ?",
                    (group_id,),
                )
                tabs = cursor.fetchall()

                # Check if this group is a window's local open tabs
                is_open_tabs = group_id in local_tab_groups

                # We skip certain internal folders like Recovered, pinned, privatePinned, recentlyClosed
                # Usually standard user groups have a normal title
                if not is_open_tabs and group_title in (
                    "Recovered",
                    "pinned",
                    "privatePinned",
                    "recentlyClosed",
                    "Local",
                    "Private",
                    "TopScopedBookmarkList",
                ):
                    continue

                if not tabs:
                    continue  # Skip empty groups

                add_date = int(datetime.now().timestamp())

                # If it's open tabs, rename the group to be clearer
                display_group_title = (
                    f"Open Tabs (Window {local_tab_groups[group_id]})"
                    if is_open_tabs
                    else group_title
                )

                f.write(
                    f'    <DT><H3 ADD_DATE="{add_date}" LAST_MODIFIED="{add_date}">{display_group_title}</H3>\n'
                )
                f.write("    <DL><p>\n")

                for tab_title, tab_url in tabs:
                    # Provide fallback if title is empty
                    display_title = tab_title if tab_title else tab_url
                    f.write(
                        f'        <DT><A HREF="{tab_url}" ADD_DATE="{add_date}">{display_title}</A>\n'
                    )

                f.write("    </DL><p>\n")

            f.write(BOOKMARKS_FOOTER)

        print(f"Successfully exported {len(groups)} tab groups to {output_file}")
        return True

    except sqlite3.Error as e:
        print(f"Database error: {e}", file=sys.stderr)
        return False
    finally:
        if "conn" in locals():
            conn.close()


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="Export Safari Tab Groups to Netscape Bookmarks HTML"
    )
    parser.add_argument(
        "--db",
        help="Path to SafariTabs.db (default: attempts macOS container path)",
        default=None,
    )
    parser.add_argument(
        "--out", help="Output HTML file path", default="safari_tab_groups.html"
    )

    args = parser.parse_args()

    db_path = get_safari_db_path(args.db)
    export_bookmarks(db_path, args.out)


if __name__ == "__main__":
    main()
