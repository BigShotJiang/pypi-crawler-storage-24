def hello() -> str:
    return "Hello from tabpack!"
