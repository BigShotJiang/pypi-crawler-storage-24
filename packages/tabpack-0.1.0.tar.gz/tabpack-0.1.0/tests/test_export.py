import os
import sqlite3
import pytest
from tabpack.export import export_bookmarks


@pytest.fixture
def temp_db(tmp_path):
    """Creates a temporary SQLite database with minimal mock Safari Tab Groups data."""
    db_file = tmp_path / "SafariTabs.db"
    conn = sqlite3.connect(str(db_file))
    cursor = conn.cursor()

    # Create required tables
    cursor.execute(
        "CREATE TABLE bookmarks (id INTEGER PRIMARY KEY, parent INTEGER, type INTEGER, title TEXT, url TEXT)"
    )
    cursor.execute(
        "CREATE TABLE windows (id INTEGER PRIMARY KEY, local_tab_group_id INTEGER)"
    )

    # Insert mock data
    # Type 1 = Folder/Tab Group, Type 0 = Bookmark/Tab
    cursor.execute(
        "INSERT INTO bookmarks (id, type, title) VALUES (10, 1, 'My Cool Group')"
    )
    cursor.execute(
        "INSERT INTO bookmarks (id, parent, type, title, url) VALUES (11, 10, 0, 'Example', 'https://example.com')"
    )

    # Mock open window
    cursor.execute("INSERT INTO bookmarks (id, type, title) VALUES (20, 1, 'Local')")
    cursor.execute("INSERT INTO windows (id, local_tab_group_id) VALUES (1, 20)")
    cursor.execute(
        "INSERT INTO bookmarks (id, parent, type, title, url) VALUES (21, 20, 0, 'Open Tab', 'https://example.org')"
    )

    conn.commit()
    conn.close()

    return str(db_file)


def test_export_bookmarks_creates_file(temp_db, tmp_path):
    output_html = str(tmp_path / "test_bookmarks.html")

    result = export_bookmarks(temp_db, output_html)

    assert result is True
    assert os.path.exists(output_html)


def test_export_bookmarks_content(temp_db, tmp_path):
    output_html = str(tmp_path / "test_bookmarks.html")
    export_bookmarks(temp_db, output_html)

    with open(output_html, "r", encoding="utf-8") as f:
        content = f.read()

    assert "My Cool Group" in content
    assert "https://example.com" in content
    assert "Example" in content

    # Verify open tabs are labeled
    assert "Open Tabs (Window 1)" in content
    assert "https://example.org" in content


def test_export_bookmarks_invalid_db():
    result = export_bookmarks("non_existent_db.sqlite", "out.html")
    assert result is False
