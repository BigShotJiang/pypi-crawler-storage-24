# Tabpack

Export your Safari Tab Groups and currently open Safari tabs into a standardized Netscape Bookmarks HTML file. The generated `bookmarks.html` can be imported into any modern browser (Chrome, Firefox, Arc, etc.) directly.

Unlike the default Safari exporter which cannot export entire Tab Groups, this project directly interrogates the local macOS Safari SQLite database to perfectly extract out your saved context.

## Installation

Tabpack is published as a Python package. You can install it globally via `uv` or any standard pip tool:

```bash
uv tool install tabpack
```

Or just run it instantly without installing:

```bash
uvx tabpack
```

## Usage

Simply run the CLI tool on macOS. By default, it will automatically attempt to locate your Safari database (`Library/Containers/com.apple.Safari/Data/Library/Safari/SafariTabs.db`) and write a `bookmarks.html` locally to your current directory.

```bash
tabpack
```

### Specifying Output Paths

You can manually specify where you want the resulting bookmark file to be saved:

```bash
tabpack --out ~/Desktop/safari_bookmarks.html
```

### Specifying The Database Path
If you have a backup of `SafariTabs.db` stored elsewhere or the tool cannot locate the exact container path on your macOS version, you can manually point the tool to the DB file:

```bash
tabpack --db ~/Downloads/SafariTabs.db
```

## Local Development

The project environment is fully hermetic and managed with Nix flakes plus `devenv`.

1. Enter the development shell:
   ```bash
   nix develop
   ```
2. Sync dependencies:
   ```bash
   uv sync --frozen
   ```
3. Run the CLI:
   ```bash
   uv run tabpack
   ```

### Quality Checks

Run formatting and linting hooks:

```bash
prek run --all-files
```

### Testing

The test suite runs with `pytest`:

```bash
uv run python -m pytest
```

### Packaging

Build source and wheel artifacts:

```bash
uv build
```

## Releases

Releases are automated via GitHub Actions and are triggered on tag push events.

1. Bump `project.version` in `pyproject.toml`.
2. Create and push a tag (for example `v0.1.1`).

```bash
git tag v0.1.1
git push origin v0.1.1
```

The release workflow uploads both `.whl` and `.tar.gz` artifacts.
