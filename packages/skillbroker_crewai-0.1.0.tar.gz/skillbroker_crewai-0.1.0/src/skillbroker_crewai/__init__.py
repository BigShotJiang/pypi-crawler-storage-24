"""
SkillBroker CrewAI Integration

Access expert knowledge in your CrewAI crews through the SkillBroker marketplace.
"""

from .client import SkillBrokerClient, SkillBrokerError, SkillNotFoundError, InvocationError
from .tools import SkillBrokerTool, SkillBrokerSearchTool, SkillBrokerExpertTool
from .models import Skill, SkillQuery, SkillResponse, SearchResult, SkillCapability, SkillPricing, SkillStats, SkillQuality

__version__ = "0.1.0"
__all__ = [
    # Client
    "SkillBrokerClient",
    "SkillBrokerError",
    "SkillNotFoundError",
    "InvocationError",
    # Tools
    "SkillBrokerTool",
    "SkillBrokerSearchTool",
    "SkillBrokerExpertTool",
    # Models
    "Skill",
    "SkillQuery",
    "SkillResponse",
    "SearchResult",
    "SkillCapability",
    "SkillPricing",
    "SkillStats",
    "SkillQuality",
]
