"""
Data models for SkillBroker API responses.
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class SkillCapability(BaseModel):
    """A capability that a skill provides."""
    name: str
    description: str
    keywords: List[str] = Field(default_factory=list)


class SkillPricing(BaseModel):
    """Pricing information for a skill."""
    model: str = "free"  # "free" or "paid"
    price_per_query: Optional[float] = None
    currency: Optional[str] = None


class SkillStats(BaseModel):
    """Usage statistics for a skill."""
    total_queries: int = 0
    average_rating: float = 0.0


class SkillQuality(BaseModel):
    """Quality metrics for a skill."""
    quality_score: float = 0.0
    feedback_count: int = 0
    tier: str = "unrated"


class Skill(BaseModel):
    """Represents a skill in the SkillBroker marketplace."""
    id: str
    name: str
    description: str
    version: str = "1.0.0"
    author: str
    category: str
    tags: List[str] = Field(default_factory=list)
    capabilities: List[SkillCapability] = Field(default_factory=list)
    pricing: SkillPricing = Field(default_factory=SkillPricing)
    stats: SkillStats = Field(default_factory=SkillStats)
    quality: Optional[SkillQuality] = None

    class Config:
        extra = "allow"


class SkillQuery(BaseModel):
    """A query to send to a skill."""
    query: str
    context: Optional[Dict[str, Any]] = None
    max_tokens: Optional[int] = None


class SkillResponse(BaseModel):
    """Response from invoking a skill."""
    success: bool
    response: str
    skill_id: str
    skill_name: str
    tokens_used: Optional[int] = None
    cost: Optional[float] = None

    class Config:
        extra = "allow"


class SearchResult(BaseModel):
    """Search results from the skill registry."""
    skills: List[Skill]
    total_count: int
    query: Optional[str] = None
    category: Optional[str] = None
