# SkillBroker CrewAI Integration

Add expert knowledge to your CrewAI crews with [SkillBroker](https://skillbroker.io) - the marketplace where AI agents pay for human expertise.

## Installation

```bash
pip install skillbroker-crewai
```

## Quick Start

### Basic Agent with Expert Tool

```python
from crewai import Agent, Task, Crew
from skillbroker_crewai import SkillBrokerTool

# Create a tool for a specific skill
tax_tool = SkillBrokerTool(
    skill_id="freelancer-tax-advisor",
    name="Tax Advisor",
    description="Get expert advice on freelancer and self-employment tax questions"
)

# Create an agent with the tool
tax_agent = Agent(
    role="Tax Consultant",
    goal="Provide accurate tax advice to freelancers",
    backstory="You are an expert tax consultant specializing in self-employment taxes.",
    tools=[tax_tool],
    verbose=True
)

# Create a task
task = Task(
    description="Help me understand if I can deduct my home office expenses as a freelancer",
    agent=tax_agent,
    expected_output="Detailed tax advice about home office deductions"
)

# Run the crew
crew = Crew(agents=[tax_agent], tasks=[task])
result = crew.kickoff()
print(result)
```

### Dynamic Expert Tool

Let the agent automatically find the right skill:

```python
from crewai import Agent, Task, Crew
from skillbroker_crewai import SkillBrokerExpertTool

# This tool can handle any domain question
expert_tool = SkillBrokerExpertTool()

# Create a research agent
research_agent = Agent(
    role="Research Assistant",
    goal="Answer complex questions using expert knowledge",
    backstory="You have access to a marketplace of human experts.",
    tools=[expert_tool],
)

task = Task(
    description="What's the best way to structure a holding company for tax efficiency?",
    agent=research_agent,
    expected_output="Expert advice on holding company structure"
)

crew = Crew(agents=[research_agent], tasks=[task])
result = crew.kickoff()
```

### Searching for Skills

```python
from skillbroker_crewai import SkillBrokerSearchTool

# Create a search tool
search_tool = SkillBrokerSearchTool()

# Find relevant skills
results = search_tool.run("financial planning")
print(results)
```

### Using the Client Directly

```python
from skillbroker_crewai import SkillBrokerClient

client = SkillBrokerClient()

# Get registry info
info = client.get_registry_info()
print(f"Total skills available: {info['stats']['totalSkills']}")

# Search for skills
results = client.search("machine learning")
for skill in results.skills:
    print(f"- {skill.name}: {skill.description}")

# Invoke a skill directly
response = client.invoke("skill-id", "Your question here")
print(response.response)
```

## Configuration

### Environment Variables

```bash
# Optional: Override the API URL (defaults to https://api.skillbroker.io)
export SKILLBROKER_API_URL="https://api.skillbroker.io"

# Optional: API key for authenticated requests
export SKILLBROKER_API_KEY="your-api-key"
```

### Programmatic Configuration

```python
from skillbroker_crewai import SkillBrokerClient, SkillBrokerTool

# Configure client
client = SkillBrokerClient(
    api_url="https://api.skillbroker.io",
    api_key="your-api-key",
    timeout=30,
)

# Configure tools
tool = SkillBrokerTool(
    skill_id="my-skill",
    api_url="https://api.skillbroker.io",
    api_key="your-api-key",
)
```

## Available Tools

| Tool | Description |
|------|-------------|
| `SkillBrokerTool` | Invoke a specific skill by ID |
| `SkillBrokerSearchTool` | Search the marketplace for skills |
| `SkillBrokerExpertTool` | Automatically find and invoke the best skill |

## Multi-Agent Crew Example

```python
from crewai import Agent, Task, Crew, Process
from skillbroker_crewai import SkillBrokerTool, SkillBrokerSearchTool

# Create specialized tools
tax_tool = SkillBrokerTool(
    skill_id="freelancer-tax-advisor",
    name="Tax Advisor",
    description="Tax advice for freelancers"
)

legal_tool = SkillBrokerTool(
    skill_id="contract-reviewer",
    name="Contract Advisor",
    description="Contract and legal document review"
)

search_tool = SkillBrokerSearchTool()

# Create specialized agents
tax_agent = Agent(
    role="Tax Specialist",
    goal="Provide accurate tax guidance",
    backstory="Expert in freelancer taxation",
    tools=[tax_tool],
)

legal_agent = Agent(
    role="Legal Advisor",
    goal="Review contracts and legal matters",
    backstory="Specializes in freelancer contracts",
    tools=[legal_tool],
)

research_agent = Agent(
    role="Research Coordinator",
    goal="Find the right experts for any question",
    backstory="Connects users with domain experts",
    tools=[search_tool],
)

# Create tasks
tax_task = Task(
    description="Analyze tax implications of the new contract",
    agent=tax_agent,
    expected_output="Tax analysis report"
)

legal_task = Task(
    description="Review the contract terms",
    agent=legal_agent,
    expected_output="Contract review with recommendations"
)

# Run as a crew
crew = Crew(
    agents=[research_agent, tax_agent, legal_agent],
    tasks=[tax_task, legal_task],
    process=Process.sequential
)

result = crew.kickoff()
```

## API Reference

### SkillBrokerClient

```python
client = SkillBrokerClient(api_url=None, api_key=None, timeout=30)

# Methods
client.get_registry_info() -> dict
client.search(query=None, category=None, limit=20) -> SearchResult
client.get_skill(skill_id) -> Skill
client.invoke(skill_id, query, context=None) -> SkillResponse
client.get_categories() -> list
client.get_top_skills(limit=10, category=None) -> list[Skill]
client.get_recommendations(task_description, limit=5) -> list[Skill]
```

### Models

```python
from skillbroker_crewai import Skill, SkillResponse, SkillQuery

# Skill attributes
skill.id
skill.name
skill.description
skill.category
skill.pricing
skill.stats
skill.quality

# Response attributes
response.success
response.response
response.skill_id
response.tokens_used
response.cost
```

## Support

- Documentation: https://skillbroker.io/docs
- API Reference: https://api.skillbroker.io/swagger
- Issues: https://github.com/skillbroker/skillbroker-crewai/issues
- Email: contact@skillbroker.io

## License

MIT License - see LICENSE file for details.
