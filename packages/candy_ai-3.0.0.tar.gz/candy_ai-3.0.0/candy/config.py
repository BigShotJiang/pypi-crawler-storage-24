"""
candy.config — Système de profils cedric-8EF
=============================================

IMPORT :
    from candy import cfg

UTILISATION :
    cfg.A.lang       = "FR"
    cfg.A.max_tokens = 1000
    cfg.A.style      = "detailed"

    cfg.B.lang       = "EN"
    cfg.B.style      = "concise"

    from candy import Coding, Math
    Coding.use("A").ask("Explique les décorateurs")
    Math.use("B").ask("Solve this integral")

PARAMÈTRES :
    .lang            "FR","EN","ES","DE","IT","PT","ZH","JA","AR","RU",...
    .max_tokens      100=court  600=moyen  1024=défaut  4096=max
    .temperature     0.0=factuel  0.7=équilibré  1.5=créatif
    .style           "default","concise","detailed","bullet","academic",
                     "casual","technical","eli5"
    .tone            "neutral","encouraging","strict","humorous",
                     "empathetic","socratic"
    .output_format   "text","markdown","json","html"
    .expertise       "beginner","intermediate","expert"
    .include_examples  True/False
    .safe_mode         True/False
    .timeout           secondes (défaut 120)
    .cache_url         True/False
"""

_DEFAULTS = {
    "lang":             "EN",
    "max_tokens":       1024,
    "temperature":      0.7,
    "style":            "default",
    "tone":             "neutral",
    "output_format":    "text",
    "expertise":        "intermediate",
    "include_examples": True,
    "safe_mode":        True,
    "timeout":          120,
    "cache_url":        True,
}


class Profile:
    def __init__(self, name: str):
        object.__setattr__(self, "_name", name)
        for k, v in _DEFAULTS.items():
            object.__setattr__(self, k, v)

    def __repr__(self):
        name = object.__getattribute__(self, "_name")
        lines = [f'Profil "{name}" :']
        for k in _DEFAULTS:
            v = getattr(self, k)
            marker = " ✎" if v != _DEFAULTS[k] else ""
            lines.append(f"  {k:20s} = {repr(v)}{marker}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in _DEFAULTS}


class _Config:
    def __init__(self):
        object.__setattr__(self, "_profiles", {})
        self._get_or_create("default")

    def _get_or_create(self, name: str) -> Profile:
        profiles = object.__getattribute__(self, "_profiles")
        if name not in profiles:
            profiles[name] = Profile(name)
        return profiles[name]

    def __getattr__(self, name: str) -> Profile:
        if name.startswith("_"):
            raise AttributeError(name)
        return self._get_or_create(name)

    def __setattr__(self, name: str, value):
        if name.startswith("_"):
            object.__setattr__(self, name, value)
        else:
            raise AttributeError(
                f"Fais cfg.{name}.param = valeur  (ex: cfg.{name}.lang = 'FR')"
            )

    def list(self) -> list:
        return list(object.__getattribute__(self, "_profiles").keys())

    def get(self, name: str) -> Profile:
        return self._get_or_create(name)

    def __repr__(self):
        profiles = object.__getattribute__(self, "_profiles")
        lines = ["🍬 candy — profils définis :"]
        for name, p in profiles.items():
            changed = [k for k in _DEFAULTS if getattr(p, k) != _DEFAULTS[k]]
            summary = ", ".join(f"{k}={repr(getattr(p, k))}" for k in changed) or "défauts"
            lines.append(f"  [{name}] {summary}")
        return "\n".join(lines)


# Instance globale
config = _Config()


def get_profile(name: str) -> Profile:
    return config.get(name)


def list_profiles() -> list:
    return config.list()
