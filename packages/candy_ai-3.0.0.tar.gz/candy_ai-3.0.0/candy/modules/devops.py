from .base import BaseModule

class DevOps(BaseModule):
    """Cloud, Docker, Kubernetes, CI/CD, AWS/GCP/Azure."""
    _personality = "devops"
