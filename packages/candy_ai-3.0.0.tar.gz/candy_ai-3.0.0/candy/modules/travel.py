from .base import BaseModule

class Travel(BaseModule):
    """Planification de voyages, itinéraires, destinations, budget."""
    _personality = "travel"
