from .base import BaseModule

class Business(BaseModule):
    """Stratégie d'entreprise, analyse concurrentielle, management."""
    _personality = "business"
