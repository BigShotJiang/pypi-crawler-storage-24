from .base import BaseModule

class Law(BaseModule):
    """Droit : common law, droit civil, international, contrats."""
    _personality = "law"
