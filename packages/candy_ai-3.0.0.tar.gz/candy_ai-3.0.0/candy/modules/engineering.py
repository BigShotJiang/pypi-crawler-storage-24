from .base import BaseModule

class Engineering(BaseModule):
    """Ingénierie : mécanique, électrique, civil, logiciel."""
    _personality = "engineering"
