from .base import BaseModule

class Security(BaseModule):
    """Cybersécurité : défense, menaces, code sécurisé, cryptographie."""
    _personality = "security"
