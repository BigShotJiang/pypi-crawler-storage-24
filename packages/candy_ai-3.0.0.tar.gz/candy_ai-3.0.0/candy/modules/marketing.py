from .base import BaseModule

class Marketing(BaseModule):
    """Stratégie marketing, croissance, SEO, branding, conversion."""
    _personality = "marketing"
