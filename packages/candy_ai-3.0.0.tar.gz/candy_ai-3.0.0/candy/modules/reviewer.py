from .base import BaseModule

class Reviewer(BaseModule):
    """Revue de code et contenu : qualité, architecture."""
    _personality = "reviewer"
