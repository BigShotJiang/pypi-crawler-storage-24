from .base import BaseModule

class Architecture(BaseModule):
    """Architecture, design urbain, principes structurels."""
    _personality = "architecture"
