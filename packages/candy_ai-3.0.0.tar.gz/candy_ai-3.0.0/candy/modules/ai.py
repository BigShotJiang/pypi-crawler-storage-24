from .base import BaseModule

class AI(BaseModule):
    """Machine learning, NLP, vision, RL, éthique IA, LLMs."""
    _personality = "ai"
