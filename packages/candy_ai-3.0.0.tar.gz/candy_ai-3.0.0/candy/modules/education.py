from .base import BaseModule

class Education(BaseModule):
    """Pédagogie, plans de cours, quiz, styles d'apprentissage."""
    _personality = "education"
