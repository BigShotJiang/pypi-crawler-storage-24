from .base import BaseModule

class Philosophy(BaseModule):
    """Éthique, métaphysique, épistémologie, logique."""
    _personality = "philosophy"
