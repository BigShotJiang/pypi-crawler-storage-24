from .base import BaseModule

class Crypto(BaseModule):
    """Blockchain, DeFi, NFT, smart contracts, tokenomics."""
    _personality = "crypto"
