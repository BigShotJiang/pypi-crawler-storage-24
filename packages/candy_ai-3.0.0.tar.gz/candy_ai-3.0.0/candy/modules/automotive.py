from .base import BaseModule

class Automotive(BaseModule):
    """Mécanique automobile, entretien, véhicules électriques."""
    _personality = "automotive"
