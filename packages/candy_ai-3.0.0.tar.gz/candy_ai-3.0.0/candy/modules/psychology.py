from .base import BaseModule

class Psychology(BaseModule):
    """Psychologie cognitive, comportementale et sociale."""
    _personality = "psychology"
