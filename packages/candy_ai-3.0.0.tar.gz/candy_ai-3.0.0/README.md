# 🍬 candy-ai v3

Client Python pour **cedric-8EF** — moteur IA multi-personnalités.  
**Zéro configuration.** URL récupérée automatiquement.  
**Système de profils** — paramètre chaque appel indépendamment.

---

## Installation

```bash
pip install candy-ai
```

---

## Démarrage immédiat

```python
from candy import Coding

print(Coding.ask("Write a quicksort in Python"))
```

---

## Système de profils

```python
from candy import cfg, Coding, Math, Full, Tutor

# ── Profil A — français, détaillé
cfg.A.lang         = "FR"
cfg.A.max_tokens   = 2000
cfg.A.style        = "detailed"
cfg.A.tone         = "encouraging"
cfg.A.expertise    = "beginner"

# ── Profil B — anglais, court, expert
cfg.B.lang         = "EN"
cfg.B.max_tokens   = 300
cfg.B.style        = "technical"
cfg.B.expertise    = "expert"

# ── Profil "rapide"
cfg.rapide.lang       = "FR"
cfg.rapide.max_tokens = 100
cfg.rapide.style      = "concise"

# ── Profil default (utilisé sans .use())
cfg.default.lang  = "FR"
cfg.default.style = "concise"

# Utilisation
Coding.ask("Explique les générateurs")         # → default
Math.use("A").ask("Résous ∫x²sin(x)dx")       # → profil A
Coding.use("B").ask("Optimise cette fonction") # → profil B
Full.use("rapide").ask("C'est quoi l'IA ?")    # → profil rapide
```

---

## Tous les paramètres

| Paramètre | Défaut | Valeurs |
|-----------|--------|---------|
| `lang` | `"EN"` | `"FR"`, `"EN"`, `"ES"`, `"DE"`, `"IT"`, `"PT"`, `"ZH"`, `"JA"`, `"AR"`, `"RU"`, `"NL"`, `"PL"`, `"SV"`, `"TR"`, `"KO"`, `"HI"`, `"VI"`, `"ID"`, `"CS"`, `"RO"` |
| `max_tokens` | `1024` | `100` (court) → `4096` (max) |
| `temperature` | `0.7` | `0.0` (factuel) → `1.5` (créatif) |
| `style` | `"default"` | `"default"`, `"concise"`, `"detailed"`, `"bullet"`, `"academic"`, `"casual"`, `"technical"`, `"eli5"` |
| `tone` | `"neutral"` | `"neutral"`, `"encouraging"`, `"strict"`, `"humorous"`, `"empathetic"`, `"socratic"` |
| `output_format` | `"text"` | `"text"`, `"markdown"`, `"json"`, `"html"` |
| `expertise` | `"intermediate"` | `"beginner"`, `"intermediate"`, `"expert"` |
| `include_examples` | `True` | `True` / `False` |
| `safe_mode` | `True` | `True` / `False` |
| `timeout` | `120` | secondes |
| `cache_url` | `True` | `True` / `False` |

---

## Streaming

```python
from candy import cfg, Writing

cfg.A.lang  = "FR"
cfg.A.style = "casual"

for token in Writing.use("A").stream("Écris une histoire de pirates"):
    print(token, end="", flush=True)
```

---

## Contexte

```python
from candy import Analytic

data = "Mois,Revenu\nJan,12000\nFév,15400\nMar,9800"
print(Analytic.use("A").ask("Quelle tendance ?", context=data))
```

---

## Combiner plusieurs personnalités

```python
from candy import cfg, Coding, Debugger, Reviewer

cfg.A.lang  = "FR"
cfg.A.style = "detailed"

code    = Coding.use("A").ask("Écris un client REST")
bugs    = Debugger.use("A").ask("Trouve les bugs", context=code)
review  = Reviewer.use("A").ask("Évalue ce code", context=code)
```

---

## Quota et métadonnées

```python
from candy import Coding

print(Coding.quota())
# {'quota_used_today': 12, 'quota_limit': 500, 'quota_remaining': 488}

data = Coding.use("A").ask_with_meta("Hello")
print(data["response"])
print("Quota restant :", data["quota_remaining"])
```

---

## Voir les profils définis

```python
from candy import cfg, list_profiles

print(cfg.A)          # détails du profil A
print(cfg)            # tous les profils
print(list_profiles()) # ['default', 'A', 'B', 'rapide']
```

---

## Les 50 personnalités

`Math` `Coding` `Reflexion` `Analytic` `Full` `Science` `Writing` `History`
`Law` `Medicine` `Finance` `Marketing` `Security` `Design` `Language`
`Psychology` `Education` `Research` `Business` `Productivity` `Cooking`
`Travel` `Music` `Film` `Sports` `Philosophy` `Environment` `Architecture`
`Automotive` `Astronomy` `Biology` `Chemistry` `Physics` `Engineering`
`Entrepreneur` `Ethics` `Geopolitics` `Crypto` `AI` `DevOps` `Database`
`GameDev` `Comic` `Storyteller` `Translator` `Summarizer` `Debugger`
`Reviewer` `Planner` `Tutor`

---

Propulsé par **cedric-8EF** · Quota : 500 req/jour · MIT License
