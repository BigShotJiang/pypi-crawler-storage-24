#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: psakic

This sub-module of geodezyx.utils contains functions for Shell-like
 operations in Python. 

it can be imported directly with:
from geodezyx import utils

The geodezyx toolbox is a software for simple but useful
functions for Geodesy and Geophysics under the GNU LGPL v3 License

Copyright (C) 2019 Pierre Sakic et al. (IPGP, sakic@ipgp.fr)
GitHub repository :
https://github.com/IPGP/geodezyx
"""


########## BEGIN IMPORT ##########
#### External modules
import fnmatch
import glob
import gzip
#### Import the logger
import logging
import os
import re
import shutil
import subprocess

#### geodeZYX modules
from geodezyx import utils

log = logging.getLogger('geodezyx')

##########  END IMPORT  ##########


#################
### SHELL LIKE FCTS
#################


def subprocess_frontend(cmd_in,
                        save_log=False,
                        log_dir=None,
                        log_name_out="out.log",
                        log_name_err="err.log",
                        logname_timestamp=False):
    """
    Run a shell command and optionally save output to log files.

    Parameters
    ----------
    cmd_in : str
        Command to execute via shell.
    save_log : bool, optional
        If True, save stdout and stderr to log files. Default is False.
    log_dir : str, optional
        Directory where log files will be saved. Default is current working directory.
    log_name_out : str, optional
        Name of the stdout log file. Default is "out.log".
    log_name_err : str, optional
        Name of the stderr log file. Default is "err.log".
    logname_timestamp : bool, optional
        If True, prepend timestamp to log filenames. Default is False.

    Returns
    -------
    tuple
        - process1 : subprocess.CompletedProcess
            The subprocess return object.
        - process1_stdout : str
            Standard output from the command.
        - process1_stderr : str
            Standard error from the command.
    """
    now = utils.get_timestamp()
    
    process1 = subprocess.run([cmd_in],
                              capture_output=True,
                              text=True,
                              shell=True)
    
    process1_stdout = process1.stdout.strip()
    process1_stderr = process1.stderr.strip()
    
    if save_log:
        
        if not log_dir:
            log_dir = os.getcwd()
            
        if logname_timestamp:
            prefix = now + "_" 
        else:
            prefix = ""
        
        out_file = open(log_dir + "/" + prefix + log_name_out, "a+")
        err_file = open(log_dir + "/" + prefix + log_name_err, "a+")
    
        out_file.write(process1_stdout)
        err_file.write(process1_stderr)
    
        out_file.close()
        err_file.close()
    
    return process1,process1_stdout,process1_stderr


def tail(filename, count=1, offset=1024):
    """
    Get the last few lines of a file efficiently.

    Depending on the length of your lines, you will want to modify offset
    to get better performance.

    Parameters
    ----------
    filename : str or file-like object
        Path to the file or a file-like object (StringIO, BytesIO, etc.)
    count : int, optional
        Number of lines to return from the end of the file. Default is 1.
    offset : int, optional
        Number of bytes to read from the end of the file. Default is 1024.

    Returns
    -------
    list
        List of lines from the end of the file.
    """

    # file-like object handling (StringIO, BytesIO, open file, etc.)
    if hasattr(filename, "read"):
        f = filename
        close_when_done = False
        f_size = 1000000000  # arbitrary large number
    else:
        # normalize bytes / PathLike to str path
        f_size = os.stat(filename).st_size
        if f_size == 0:
            return []

        if isinstance(filename, bytes):
            filename = os.fsdecode(filename)
        filename = os.fspath(filename)
        f = open(filename, "r", errors="ignore")
        close_when_done = True

    if f_size <= offset:
        offset = int(f_size / 2)
    while True:
        seek_to = min(f_size - offset, 0)
        f.seek(seek_to)
        lines = f.readlines()
        # Empty file
        if seek_to <= 0 and len(lines) == 0:
            return []
        # count is larger than lines in file
        if seek_to == 0 and len(lines) < count:
            return lines
        # Standard case
        if len(lines) >= (count + 1):
            return lines[count * -1:]

def head(filename, count=1):
    """
    Get the first few lines of a file.

    Parameters
    ----------
    filename : str or file-like object
        Path to the file or a file-like object (StringIO, BytesIO, etc.)
    count : int, optional
        Number of lines to return from the beginning of the file. Default is 1.

    Returns
    -------
    list
        List of lines from the beginning of the file.
    """

    # file-like object handling (StringIO, BytesIO, open file, etc.)
    if hasattr(filename, "read"):
        f = filename
        close_when_done = False
    else:
        # normalize bytes / PathLike to str path
        if isinstance(filename, bytes):
            filename = os.fsdecode(filename)
        filename = os.fspath(filename)
        f = open(filename, "r", errors="ignore")
        close_when_done = True

    lines = []
    for iline in range(1, count+1):
        try:
            lines.append(f.readline())
        except Exception as e:
            log.warning(e)
            continue

    if close_when_done:
        f.close()

    return list(filter(len, lines))


def grep(file_in, search_string, only_first_occur=False,
         invert=False, regex=False, line_number=False, col=(None, None),
         force_list_output=False):
    """
    Search for lines matching a pattern in a file.

    Returns an empty string if nothing is found, not a singleton list with an
    empty string inside.

    Parameters
    ----------
    file_in : str or file-like object
        Path to the file or a file-like object to search.
    search_string : str or list
        String(s) to search for.
    only_first_occur : bool, optional
        Return only the first occurrence. Default is False.
    invert : bool, optional
        If True, return lines that do NOT match the search string. Default is False.
    regex : bool, optional
        If True, treat search_string as a regular expression. Default is False.
    line_number : bool, optional
        If True, also return the line numbers. Default is False.
    col : tuple of int, optional
        Column range (start, end) where the grep is executed.
        Use None for unbounded indices. Default is (None, None).
    force_list_output : bool, optional
        If True, always return a list even for single elements. Default is False.

    Returns
    -------
    str, list, or tuple
        - If line_number is True and single result: (line_number, line)
        - If line_number is True and multiple results: (line_numbers_list, lines_list)
        - Otherwise returns matching line(s) as str or list, or empty string if no matches.

    Notes
    -----
    - If nothing is found returns an empty string (not a singleton list)
    - search_string can be a list of patterns to match any
    """
    if type(search_string) is str:
        search_string = [search_string]

    matching_line_list = []
    line_number_list = []

    # Handle file-like objects (StringIO, BytesIO, open file, etc.)
    if hasattr(file_in, "read"):
        file = file_in
        close_when_done = False
    else:
        # Handle file paths
        if file_in[-2:] in ("gz", "GZ"):
            file = gzip.open(file_in, "rt", encoding="utf-8")
        else:
            file = open(file_in, encoding="ISO-8859-1")
        close_when_done = True

    try:
        for iline, line in enumerate(file):
            trigger = False
            for seastr in search_string:
                if regex:
                    if re.search(seastr, line[col[0]:col[1]]):
                        trigger = True
                else:
                    if seastr in line[col[0]:col[1]]:
                        trigger = True
            if invert:
                trigger = not trigger
            if trigger:
                matching_line_list.append(line)
                line_number_list.append(iline)
                if only_first_occur:
                    break
    finally:
        if close_when_done:
            file.close()

    if line_number and len(line_number_list) == 1:
        return line_number_list[0], matching_line_list[0]
    elif line_number:
        return line_number_list, matching_line_list
    elif len(matching_line_list) == 1 and not force_list_output:
        return matching_line_list[0]
    elif len(matching_line_list) == 1 and force_list_output:
        return matching_line_list
    elif len(matching_line_list) == 0:
        return ''
    elif only_first_occur:
        return matching_line_list[0]
    else:
        return matching_line_list


def egrep_big_string(regex,bigstring,only_first_occur=False):
    """
    Perform a regex grep on a big string separated with newlines.

    .. deprecated::
        Use :func:`grep` instead, which handles this functionality (as of 260121).

    Parameters
    ----------
    regex : str
        Regular expression pattern to search for.
    bigstring : str
        The large string (separated by newlines) to search in.
    only_first_occur : bool, optional
        If True, return only the first matching line. Default is False.

    Returns
    -------
    str or list
        Matching line(s) as str if single result, list if multiple results,
        or empty string if no matches.

    Notes
    -----
    This function must be improved with regular pattern matching, without relying on regex.
    """

    matching_line_list = []

    for l in bigstring.split("\n"):
        result = re.search(regex, l)
        if result:
            matching_line_list.append(l)
            if only_first_occur:
                break

    if len(matching_line_list) == 1:
        return matching_line_list[0]
    elif len(matching_line_list) == 0:
        log.warning("nothing found... check the input args order: 1-regex, 2-bigstring")
        return ''
    
    elif only_first_occur:
        return matching_line_list[0]
    else:
        return matching_line_list

def grep_boolean(file_in,search_string):
    """
    Check if a string exists in a file.

    Parameters
    ----------
    file_in : str
        Path to the file to search.
    search_string : str
        String to search for.

    Returns
    -------
    bool
        True if search_string is found in the file, False otherwise.
    """
    for line in open(file_in):
        if search_string in line:
            return True
    return False

def regex_or_from_list(listin):
    """
    Create a regex OR pattern from a list of strings.

    Parameters
    ----------
    listin : list
        List of strings to convert to regex OR pattern.

    Returns
    -------
    str
        Regex pattern matching any of the input strings, e.g., "(pattern1|pattern2)".
    """
    return "(" + utils.join_improved("|" , *listin) +  ")"

def cat(outfilename, *infilenames):
    """
    Concatenate files.

    Parameters
    ----------
    outfilename : str
        Output filename
    infilenames : str
        Input filenames to concatenate

    Returns
    -------
    outfilename : str
        The output filename

    Notes
    -----
    For just a print, use cat_print!

    References
    ----------
    http://stackoverflow.com/questions/11532980/reproduce-the-unix-cat-command-in-python
    kindall response
    """
    with open(outfilename, 'w') as outfile:
        for infilename in infilenames:
            with open(infilename , 'r+') as infile:
                for line in infile:
                    if line.strip():
                        outfile.write(line)
    return outfilename


def cat_remove_header(infilepath,outfilepath,header='',
                      header_included = False):
    """
    Concatenate file content starting from a specified header line.

    Parameters
    ----------
    infilepath : str
        Path to the input file.
    outfilepath : str
        Path to the output file.
    header : str, optional
        The header pattern to search for. Default is empty string.
    header_included : bool, optional
        If True, include the header line in the output. Default is False.

    Returns
    -------
    str
        Path to the output file.
    """
    F = open(infilepath,'r+')
    bool_out = False

    with open(outfilepath, 'w') as outfile:
        for line in F:
            if header in line:
                bool_out = True
                if not header_included:
                    continue
            if bool_out:
                outfile.write(line)

    return outfilepath

def cat_print(inpfile):
    """
    Print file contents to stdout, line by line.

    Parameters
    ----------
    inpfile : str
        Path to the file to print.

    Returns
    -------
    None
    """
    fil = open(inpfile)
    for l in fil:
        if l[-1] == '\n':
            print(l[:-1])
        else:
            print(l)
    return None


def empty_file_check(fpath):
    """
    Check if a file is empty or does not exist.

    Parameters
    ----------
    fpath : str
        The file path to check.

    Returns
    -------
    bool
        True if the file is empty or does not exist, False otherwise.

    See Also
    --------
    http://stackoverflow.com/questions/2507808/python-how-to-check-file-empty-or-not
    """
    return not (os.path.isfile(fpath) and os.path.getsize(fpath) > 0)


def find_recursive(parent_folder , pattern, 
                   sort_results = True, case_sensitive = True,
                   extended_file_stats=False,
                   warn_if_empty=True,
                   regex=False):
    """
    Find files in a folder and his sub-folders in a recursive way.


    Parameters
    ----------
    parent_folder : str
        the parent folder path

    pattern : str
        the researched files pattern name (can manage wildcard or regex)
        - wildcard (only * and ?) for case_sensitive = True
        - regex for case_sensitive = False
        
    sort_results : bool
        Sort results
        
    case_sensitive : bool
        Case sensitive or not. If False, the pattern *must* be a regex
        *Deprecated since 2025-01, use regex instead*
        
    extended_file_stats : bool
        if True, returns the stats of the files
        the outputed matches list will be a list of tuples
        (file_path,stat_object), where stat_object has the following attributes
        
        - st_mode - protection bits,
        - st_ino - inode number,
        - st_dev - device,
        - st_nlink - number of hard links,
        - st_uid - user id of owner,
        - st_gid - group id of owner,
        - st_size - size of file, in bytes,
        - st_atime - time of most recent access,
        - st_mtime - time of most recent content modification,
        - st_ctime - platform dependent; time of most recent metadata 
                     change on Unix, or the time of creation on Windows)

    warn_if_empty : bool
        print a debug warning if no files are found

    regex : bool
        if True, the pattern in a regular expression.
        Default is False

                
    Returns
    -------
    matches : list
        Found files        

    Source
    ------
    https://stackoverflow.com/questions/2186525/use-a-glob-to-find-files-recursively-in-python

    https://stackoverflow.com/questions/15652594/how-to-find-files-with-specific-case-insensitive-extension-names-in-python
    (for the case unsensitive case)
    """
    matches = []

    if not case_sensitive:
        # we test the negation because the default behavior is True
        msg = "case_sensitive boolean is deprecated, use regex instead"
        log.warning(msg)
        DeprecationWarning(msg)
    ## this is also part of the deprecation transition, force case_sensitive to false
    if regex and case_sensitive:
        case_sensitive = False


    if case_sensitive or not regex: # standard case, pattern is a wildcard
        regex_mode = False
        for root, dirnames, filenames in os.walk(parent_folder):
            for filename in fnmatch.filter(filenames, pattern):
            #for filename in fnmatch.fnmatch(filenames, pattern):
                matches.append(os.path.join(root, filename))
    else: # not case sensitive, use a regex
        regex_mode = True
        for root, dirnames, filenames in os.walk(parent_folder):
            for filename in filenames:  
                try:
                    bool_match = re.search(pattern, filename, re.IGNORECASE)
                except Exception as e:
                    log.error("if regex = True, pattern have to be a REGEX (and not only a simple wildcard)")
                    raise e
                    
                if bool_match:
                    matches.append(os.path.join(root, filename))

    if sort_results:
        matches = sorted(matches)
        
    
    if extended_file_stats:
        matches_ext = []
        for f in matches:
            try:
                stat = os.stat(f)
            except FileNotFoundError:
                log.warning("file not found %s",f)
                continue
                
            matches_ext.append((f,stat))
        matches = matches_ext
        
    if warn_if_empty and len(matches) == 0:
        log.warning("no files found! check parent folder and pattern (regex mode: %s)", regex_mode)
        log.info("Parent folder: %s",parent_folder)
        log.info("Pattern      : %s",pattern)
                
    return matches

def glob_smart(dir_path,file_pattern=None,verbose=True):
    """
    Find files in a directory using glob pattern with optional logging.

    Parameters
    ----------
    dir_path : str
        The directory path to search in.
    file_pattern : str, optional
        File pattern to match. Default is None (search all files).
    verbose : bool, optional
        If True, log warnings/info about search results. Default is True.

    Returns
    -------
    list
        List of file paths matching the pattern.
    """
    if file_pattern:
        dir_path_ok = os.path.join(dir_path,file_pattern)
    else:
        dir_path_ok = dir_path
        
    outlist = glob.glob(dir_path_ok)
    
    if verbose:
        if not outlist:
            log.warning("no file(s) found as %s" , dir_path_ok)
        else:
            log.info("%d file(s) found as %s", len(outlist), dir_path_ok)
            
    return outlist


def insert_lines_in_file(file_path,text_values,lines_ids):
    """
    Insert text lines at specified positions in a file.

    Parameters
    ----------
    file_path : str
        Path to the file to modify.
    text_values : str or list
        Text string(s) to insert.
    lines_ids : int or list
        Line number(s) where text should be inserted.

    Returns
    -------
    str
        Path to the modified file.
    """

    if not utils.is_iterable(text_values):
        text_values = [text_values]
    
    if not utils.is_iterable(lines_ids):
        lines_ids = [lines_ids]
    
    f = open(file_path, "r")
    contents = f.readlines()
    f.close()

    for txt , lin in zip(text_values,lines_ids):
        contents.insert(lin, txt)       
    
    f = open(file_path, "w")
    contents = "".join(contents)
    f.write(contents)
    f.close()

    return file_path

def insert_str_in_file_if_line_contains(file_path,str_to_insert,
                                    line_pattern_tup,
                                    position=None,
                                    only_first_occur=False):
    """
    Insert a string at lines matching a pattern.

    Parameters
    ----------
    file_path : str
        Path to the file to modify.
    str_to_insert : str
        String to insert before matching lines.
    line_pattern_tup : tuple
        Tuple of patterns to search for.
    position : int, optional
        Position for insertion (not implemented). Default is None.
    only_first_occur : bool, optional
        If True, only process the first occurrence. Default is False.

    Returns
    -------
    str
        Path to the modified file.

    Notes
    -----
    The position parameter is not currently implemented.
    """
    f = open(file_path, "r")
    contents = f.readlines()
    
    f.close()

    pattern_found = False
    
    for ilin , lin in enumerate(contents):
        for pattern in line_pattern_tup:
            if re.search(pattern, lin):
                contents[ilin] = str_to_insert + lin
                pattern_found = True
                if only_first_occur:
                    break
                
        if only_first_occur and pattern_found:
            log.info("break at line " , ilin)
            break
                
    f = open(file_path, "w")
    contents = "".join(contents)
    f.write(contents)
    f.close()

    return file_path

def gzip_compress(inp_path, out_dir=None, out_fname=None, rm_inp=False):
    """
    Compress a file using gzip.

    Parameters
    ----------
    inp_path : str
        Path to the input file to compress.
    out_dir : str, optional
        Output directory. Default is None (same as input file).
    out_fname : str, optional
        Output filename. Default is None (input filename + ".gz").
    rm_inp : bool, optional
        If True, remove the input file after compression. Default is False.

    Returns
    -------
    str
        Path to the compressed output file.
    """
    if not out_dir:
        out_dir = os.path.dirname(inp_path)
    if not out_fname:
        out_fname = os.path.basename(inp_path) + ".gz"
    out_path = os.path.join(out_dir, out_fname)
    with open(inp_path, 'rb') as f_in:
        with gzip.open(out_path, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
    if rm_inp and os.path.isfile(inp_path):
        os.remove(inp_path)

    return out_path

def uncompress(pathin,dirout = '', opts='-f'):
    """
    Uncompress a file using the uncompress command.

    .. deprecated::
        Use :func:`geodezyx.files_rw.unzip_gz_z` instead.

    Parameters
    ----------
    pathin : str
        Path to the file to uncompress.
    dirout : str, optional
        Output directory. Default is '' (current directory).
    opts : str, optional
        Options for the uncompress command. Default is '-f'.

    Returns
    -------
    str or None
        Path to the uncompressed file, or None if input file does not exist.
    """
    log.warning("function discontinued, use files_rw.unzip_gz_z() instead")
    if not os.path.isfile(pathin):
        log.error('uncompress : %s doesnt exist !!!', pathin)
        return None
    komand = 'uncompress ' + opts + ' ' + pathin
    subprocess.call([komand], shell=True)
    pathout_temp = '.'.join(pathin.split('.')[:-1])

    if dirout == '':
        pathout = pathout_temp
    else:
        pathout = os.path.join(dirout,os.path.basename(pathout_temp))
        shutil.move(pathout_temp,pathout)
    return pathout


def create_dir(directory):
    """
    Create a directory if it does not already exist.

    Parameters
    ----------
    directory : str
        Path to the directory to create.

    Returns
    -------
    str
        The directory path.
    """
    if not os.path.exists(directory):
        os.makedirs(directory)
    return directory

def remove_dir(directory):
    """
    Remove a directory and all its contents.

    Parameters
    ----------
    directory : str
        Path to the directory to remove.

    Returns
    -------
    None

    Warnings
    --------
    Logs a warning if the directory does not exist.
    """
    if os.path.exists(directory):
        shutil.rmtree(directory)
    else:
        log.warning('%s dont exists ... skip ...',directory)
    return None

def walk_dir(parent_dir):
    """
    From a main parent_dir, returns files_list & dirs_list containing all the files and all the dirs in the parent_dir.
    Supports wildcards in the parent_dir path.

    Parameters
    ----------
    parent_dir : str
        The parent directory path, which can include wildcards.

    Returns
    -------
    files_list : list
        List of all file paths.
    dirs_list : list
        List of all directory paths.
    """
    files_list, dirs_list = [], []
    for dir_path in glob.glob(parent_dir):
        for root, dirs, files in os.walk(dir_path, topdown=False):
            for name in files:
                files_list.append(os.path.join(root, name))
            for name in dirs:
                dirs_list.append(os.path.join(root, name))

    return files_list, dirs_list

def fileprint(output,outfile):
    """
    Log output to console and append to a file.

    Parameters
    ----------
    output : str
        The output message to log and write.
    outfile : str
        Path to the output file.

    Returns
    -------
    None
    """
    log.debug(output)
    with open(outfile, "a") as f:
        f.write("{}\n".format(output))
    return None

def write_in_file(string_to_write, outdir_or_outpath,
                  outname="", ext='.txt', encoding='utf8', append=False):
    """
    Write a string to a file with support for bytes or text encoding.

    Parameters
    ----------
    string_to_write : str or bytes
        The content to write to the file.
    outdir_or_outpath : str
        Output directory path or full file path.
    outname : str, optional
        Output filename (without extension). Default is "".
    ext : str, optional
        File extension. Default is '.txt'.
    encoding : str, optional
        Text encoding to use. Default is 'utf8'.
        See https://docs.python.org/3/library/codecs.html#standard-encodings
    append : bool, optional
        If True, append to existing file. If False, overwrite. Default is False.

    Returns
    -------
    str
        Path to the output file.

    Notes
    -----
    Supported encodings: utf8, latin_1, etc.
    See https://docs.python.org/3/library/codecs.html#standard-encodings
    """

    if outname:
        outpath = os.path.join(outdir_or_outpath, outname + ext)
    else:
        outpath = outdir_or_outpath

    # Determine if input is bytes or string
    is_bytes = isinstance(string_to_write, bytes)

    if append:
        mode = "ab+" if is_bytes else "a+"
        newline = b"\n" if is_bytes else "\n"
    else:
        mode = "wb+" if is_bytes else "w+"
        newline = b"" if is_bytes else ""

    # Open file in binary mode for bytes, text mode for strings
    if is_bytes:
        F = open(outpath, mode)
    else:
        F = open(outpath, mode, encoding=encoding)

    F.write(string_to_write + newline)
    F.close()
    return outpath

# def write_in_file(string_to_write,outdir,outname,ext='.txt',encoding='utf8'):
#     """

#     encoding : utf8, latin_1
#     https://docs.python.org/3/library/codecs.html#standard-encodings
#     """
#     outpath = os.path.join(outdir,outname + ext)
#     F = open(outpath,'w+', encoding=encoding)
#     try:
#         F.write(string_to_write.encode(encode))
#         # astuce de http://stackoverflow.com/questions/6048085/writing-unicode-text-to-a-text-file
#     except UnicodeEncodeError as e:
#         print(string_to_write)
#         raise(e)
#     except TypeError as e:
#         print(e)
#         print("INFO : write_in_file : alternative write following a TypeError")
#         F.write(string_to_write)

#     F.close()
#     return outpath

def replace(file_path, pattern, subst):
    """
    Replace a string in a file with a substitute

    Parameters
    ----------
    file_path : str
        path of the file.
    pattern : str
        string to be replaced.
    subst : str
        string which will be substituted.

    Note
    ----
    http://stackoverflow.com/questions/39086/search-and-replace-a-line-in-a-file-in-python

    Returns
    -------
    None.

    """
    #Create temp file
    from tempfile import mkstemp
    from os import close
    fh, abs_path = mkstemp()
    new_file = open(abs_path,'w')
    old_file = open(file_path)
    for line in old_file:
        new_file.write(line.replace(pattern, subst))
    #close temp file
    new_file.close()
    close(fh)
    old_file.close()
    #Remove original file
    os.remove(file_path)
    #Move new file
    shutil.move(abs_path, file_path)


def regex2filelist(dossier,regex,outtype='file'):
    """
    Get files in a directory matching a regex pattern.

    Parameters
    ----------
    dossier : str
        Path to the directory.
    regex : str
        Regular expression pattern to match filenames.
    outtype : str, optional
        Type of output. 'file' returns only files, other values return all matches.
        Default is 'file'.

    Returns
    -------
    list
        Sorted list of file paths matching the pattern.
    """

    templist = []

    for filename in os.listdir(dossier):
        if re.compile(regex).search(filename):
            templist.append(os.path.join(dossier,filename))

    #  Contient fichiers + dossiers
    #  => eliminer les dossiers

    if outtype == 'file':
        outlist = [ f for f in templist if os.path.isfile(f) ]
    else:
        outlist = templist
    outlist.sort()

    return outlist

def check_regex(filein,regex):
    """
    Check if a file contains a regex pattern.

    Parameters
    ----------
    filein : str
        Path to the file to search.
    regex : str
        Regular expression pattern to search for.

    Returns
    -------
    bool
        True if the pattern is found in the file, False otherwise.
    """

    outbool = False

    for line in open(filein):
        if re.compile(regex).search(line):
            outbool = True
            break

    return outbool


def is_exe(fpath):
    """
    Check if a file is executable.

    Parameters
    ----------
    fpath : str
        File path.

    Returns
    -------
    bool
        True if the file is executable, False otherwise.
    """
    return os.path.isfile(fpath) and os.access(fpath, os.X_OK)

def copy_recursive(src, dst, force=False):
    """
    Copy a directory recursively from src to dst with an option to force overwrite.

    Parameters
    ----------
    src : str
        The source directory path.
    dst : str
        The destination directory path.
    force : bool, optional
        If True, overwrite the destination directory if it exists. Default is False.

    Returns
    -------
    None
    """
    if force and os.path.exists(dst):
        shutil.rmtree(dst)
    try:
        shutil.copytree(src, dst)
        print(f"Directory '{src}' copied successfully to '{dst}'.")
    except Exception as e:
        print(f"Error copying directory '{src}' to '{dst}': {e}")
