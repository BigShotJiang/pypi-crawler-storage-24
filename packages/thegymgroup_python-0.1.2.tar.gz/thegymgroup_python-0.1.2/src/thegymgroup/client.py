import requests
from .locations import resolve_location, Location
from datetime import date, datetime
from .datetime_utils import to_api_iso, to_epoch_millis
from .models import GymOccupancy, HistoricalBusyness


BASE_URL = "https://thegymgroup.netpulse.com"

BASE_HEADERS = {
    "accept": "application/json",
    "accept-encoding": "gzip",
    "connection": "Keep-Alive",
    "host": "thegymgroup.netpulse.com",
    "user-agent": "okhttp/3.12.3",
    "x-np-api-version": "1.5",
    "x-np-app-version": "9999",
}

USER_AGENT_TEMPLATE = (
    "clientType=MOBILE_DEVICE; devicePlatform=ANDROID; deviceUid={device_uid}; "
    "applicationName=The Gym Group; applicationVersion={app_version}; "
    "applicationVersionCode={app_version_code}"
)


class Client:
    def __init__(self, session: requests.Session, exerciser_uuid: str):
        if not exerciser_uuid:
            raise ValueError("exerciser_uuid must not be empty")
        self.session = session
        self.exerciser_uuid = exerciser_uuid

    def _get(self, path: str, params: dict | None = None):
        response = self.session.get(f"{BASE_URL}{path}", params=params)
        response.raise_for_status()
        return response.json()

    def _post(self, path: str, data: dict | None = None):
        response = self.session.post(f"{BASE_URL}{path}", data=data)
        response.raise_for_status()
        if response.content:
            return response.json()
        return None

    @staticmethod
    def _build_user_agent(
        device_uid: str,
        app_version: str,
        app_version_code: str,
    ) -> str:
        return USER_AGENT_TEMPLATE.format(
            device_uid=device_uid,
            app_version=app_version,
            app_version_code=app_version_code,
        )

    @classmethod
    def login(
        cls,
        email: str,
        pin: str,
        *,
        device_uid: str = "",
        app_version: str = "6.5.1",
        app_version_code: str = "38",
        app_version_header: str = "9999",
    ) -> "Client":
        session = requests.Session()
        headers = BASE_HEADERS.copy()
        headers["x-np-app-version"] = app_version_header
        headers["x-np-user-agent"] = cls._build_user_agent(
            device_uid=device_uid,
            app_version=app_version,
            app_version_code=app_version_code,
        )
        headers["content-type"] = "application/x-www-form-urlencoded"
        session.headers.update(headers)

        creds = {"username": email, "password": pin}
        response = session.post(f"{BASE_URL}/np/exerciser/login", data=creds)
        response.raise_for_status()
        user_id = response.json()["uuid"]
        return cls(session, user_id)

    def logout(self):
        return self._post("/np/logout")

    def get_schedule(
        self,
        *,
        start: date | datetime | None = None,
        end: date | datetime | None = None,
        location: Location | None = None,
    ):
        """Get the exerciser's booked classes"""
        params = {}
        if start is not None:
            params["startDateTime"] = to_epoch_millis(start)
        if end is not None:
            params["endDateTime"] = to_epoch_millis(end, end_of_day=True)
        if location is not None:
            location_id = resolve_location(location)
            params["clubUuid"] = location_id
        return self._get(f"/np/exerciser/{self.exerciser_uuid}/schedule", params=params)

    def get_class(self, location: Location | str, class_uuid: str):
        location_id = resolve_location(location)
        return self._get(f"/np/company/{location_id}/class/{class_uuid}")

    def get_classes(
        self,
        location: str | Location,
        *,
        start: date | datetime,
        end: date | datetime,
        exerciser_uuid: str | None = None,
        class_type: str | None = None,
    ):
        location_id = resolve_location(location)
        params = {
            "startDateTime": to_epoch_millis(start),
            "endDateTime": to_epoch_millis(end, end_of_day=True),
            "exerciserUuid": exerciser_uuid or self.exerciser_uuid,
        }
        if class_type is not None:
            params["type"] = class_type
        return self._get(f"/np/company/{location_id}/classes", params=params)

    def get_gym_occupancy(self, location: str | Location) -> GymOccupancy:
        data = self._get(
            f"/np/thegymgroup/v1.0/exerciser/{self.exerciser_uuid}/gym-busyness",
            params={"gymLocationId": resolve_location(location)},
        )
        return GymOccupancy(
            gym_location_id=data["gymLocationId"],
            gym_location_name=data["gymLocationName"],
            current_capacity=data["currentCapacity"],
            current_percentage=data["currentPercentage"],
            historical=[
                HistoricalBusyness(hour=item["hour"], percentage=item["percentage"])
                for item in data.get("historical", [])
            ],
            status=data["status"],
        )

    def get_check_ins_history(self, start: date | datetime, end: date | datetime):
        params = {
            "startDate": to_api_iso(start),
            "endDate": to_api_iso(end, end_of_day=True),
        }
        return self._get(
            f"/np/exercisers/{self.exerciser_uuid}/check-ins/history",
            params=params,
        )

    def get_latest_check_in(self):
        return self._get(f"/np/exercisers/{self.exerciser_uuid}/latest-check-in")

    def get_exerciser(self):
        return self._get(f"/np/exerciser/{self.exerciser_uuid}")

    def get_membership(self):
        return self._get(f"/np/exerciser/{self.exerciser_uuid}/membership")

    def get_hours_in_gym(self, start: date | datetime, end: date | datetime) -> int:
        mins = 0
        visits = self.get_check_ins_history(start=start, end=end)

        for i in visits.get("checkIns", []):
            mins += i.get("duration", 0) / 60000

        return round(mins / 60)
