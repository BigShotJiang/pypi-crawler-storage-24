"""
Integration tests for the ARP Python SDK.

These tests run against a LIVE API and are SKIPPED by default.
Set the following environment variables to enable them:

    API_URL   - Base URL of the ARP API (e.g. http://localhost:3000/api)
    API_KEY   - Valid API key (e.g. the admin key)

Example:
    API_URL=http://localhost:3000/api API_KEY=arp-admin-... pytest tests/test_integration.py -v
"""

from __future__ import annotations

import os
import uuid
from typing import Any

import httpx
import pytest

from arp_sdk import ARPClient
from arp_sdk.errors import ARPError, NotFoundError

# ---------------------------------------------------------------------------
# Skip gate
# ---------------------------------------------------------------------------

API_URL = os.environ.get("API_URL", "")
API_KEY = os.environ.get("API_KEY", "")

SKIP_REASON = (
    "Integration tests require API_URL and API_KEY environment variables. "
    "Example: API_URL=http://localhost:3000/api API_KEY=<key> pytest tests/test_integration.py -v"
)

pytestmark = pytest.mark.skipif(
    not API_URL or not API_KEY,
    reason=SKIP_REASON,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def api_headers() -> dict[str, str]:
    """Standard headers for raw httpx calls with the X-API-Key header."""
    return {
        "X-API-Key": API_KEY,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


@pytest.fixture(scope="module")
def http_client(api_headers: dict[str, str]) -> httpx.Client:
    """A shared httpx.Client for raw HTTP requests throughout the module."""
    client = httpx.Client(
        base_url=API_URL,
        headers=api_headers,
        timeout=httpx.Timeout(30.0),
    )
    yield client
    client.close()


@pytest.fixture(scope="module")
def sdk_client() -> ARPClient:
    """
    A shared ARPClient for the module.

    The live API expects X-API-Key but the SDK sends Authorization: Bearer.
    We construct the client normally, then patch in the correct header so
    that both headers are present and the server picks up the right one.
    """
    client = ARPClient(
        api_url=API_URL,
        api_key=API_KEY,
        timeout=30.0,
        max_retries=1,
    )
    # Inject the X-API-Key header that the live API actually checks.
    client._http._client.headers["X-API-Key"] = API_KEY
    yield client
    client.close()


# ---------------------------------------------------------------------------
# 1. System health (raw HTTP -- SDK has no SystemClient)
# ---------------------------------------------------------------------------


class TestSystemHealth:
    """Verify the /health endpoint is reachable and well-formed."""

    def test_health_returns_200(self, http_client: httpx.Client):
        # /health is mounted at server root, not under /api/v1
        # Try the standard location first; fall back if the base_url includes /api
        resp = http_client.get("/v1/system/health")
        if resp.status_code == 404:
            # Some deployments put health at the server root
            root_client = httpx.Client(
                base_url=API_URL.rstrip("/").rsplit("/api", 1)[0],
                headers=http_client.headers,
                timeout=httpx.Timeout(30.0),
            )
            resp = root_client.get("/health")
            root_client.close()
        assert resp.status_code == 200

    def test_health_response_shape(self, http_client: httpx.Client):
        resp = http_client.get("/v1/system/health")
        if resp.status_code == 404:
            root_client = httpx.Client(
                base_url=API_URL.rstrip("/").rsplit("/api", 1)[0],
                headers=http_client.headers,
                timeout=httpx.Timeout(30.0),
            )
            resp = root_client.get("/health")
            root_client.close()
        body = resp.json()
        assert "status" in body


# ---------------------------------------------------------------------------
# 2. Agent search via SDK
# ---------------------------------------------------------------------------


class TestAgentSearch:
    """Test agent search via raw HTTP (SDK Agent model doesn't match API schema yet)."""

    def test_search_returns_paginated_response(self, http_client: httpx.Client):
        resp = http_client.get("/v1/agents")
        assert resp.status_code == 200
        body = resp.json()
        assert "data" in body
        assert "pagination" in body
        assert isinstance(body["data"], list)
        assert body["pagination"]["page"] >= 1
        assert body["pagination"]["limit"] >= 1
        assert body["pagination"]["total"] >= 0
        assert body["pagination"]["totalPages"] >= 0

    def test_search_with_pagination_params(self, http_client: httpx.Client):
        resp = http_client.get("/v1/agents", params={"page": 1, "limit": 5})
        assert resp.status_code == 200
        body = resp.json()
        assert body["pagination"]["page"] == 1
        assert body["pagination"]["limit"] == 5
        assert len(body["data"]) <= 5

    def test_search_with_status_filter(self, http_client: httpx.Client):
        resp = http_client.get("/v1/agents", params={"status": "active"})
        assert resp.status_code == 200
        body = resp.json()
        for agent in body["data"]:
            assert agent["status"] == "active"

    def test_search_results_have_expected_fields(self, http_client: httpx.Client):
        resp = http_client.get("/v1/agents", params={"limit": 3})
        assert resp.status_code == 200
        body = resp.json()
        for agent in body["data"]:
            assert isinstance(agent["id"], str)
            assert "status" in agent
            assert "created_at" in agent


# ---------------------------------------------------------------------------
# 3. Agent get with nonexistent ID
# ---------------------------------------------------------------------------


class TestAgentGetNotFound:
    """Test that looking up a nonexistent agent raises NotFoundError."""

    def test_get_nonexistent_agent_raises_not_found(self, sdk_client: ARPClient):
        fake_id = f"nonexistent-agent-{uuid.uuid4()}"
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.agents.get(fake_id)
        err = exc_info.value
        assert err.code == "NOT_FOUND"
        assert isinstance(err.message, str)
        assert len(err.message) > 0


# ---------------------------------------------------------------------------
# 4. Transaction list via SDK
# ---------------------------------------------------------------------------


class TestTransactionList:
    """Test transactions list via raw HTTP (SDK Transaction model doesn't match API schema yet)."""

    def test_list_returns_paginated_response(self, http_client: httpx.Client):
        resp = http_client.get("/v1/transactions")
        assert resp.status_code == 200
        body = resp.json()
        assert "data" in body
        assert "pagination" in body
        assert isinstance(body["data"], list)
        assert body["pagination"]["total"] >= 0

    def test_list_with_limit(self, http_client: httpx.Client):
        resp = http_client.get("/v1/transactions", params={"page": 1, "limit": 5})
        assert resp.status_code == 200
        body = resp.json()
        assert body["pagination"]["page"] == 1
        assert body["pagination"]["limit"] == 5
        assert len(body["data"]) <= 5

    def test_list_items_have_expected_fields(self, http_client: httpx.Client):
        resp = http_client.get("/v1/transactions", params={"limit": 3})
        assert resp.status_code == 200
        body = resp.json()
        for txn in body["data"]:
            assert isinstance(txn["id"], str)
            assert "status" in txn


# ---------------------------------------------------------------------------
# 5. Reputation leaderboard via raw HTTP
# ---------------------------------------------------------------------------


class TestReputationLeaderboard:
    """Test the reputation leaderboard endpoint via raw HTTP."""

    def test_leaderboard_returns_200(self, http_client: httpx.Client):
        resp = http_client.get("/v1/reputation/leaderboard")
        assert resp.status_code == 200

    def test_leaderboard_response_is_list_or_has_data(self, http_client: httpx.Client):
        resp = http_client.get("/v1/reputation/leaderboard")
        body = resp.json()
        # The response should contain paginated data or an array
        assert isinstance(body, (list, dict))
        if isinstance(body, dict):
            assert "data" in body or "entries" in body or "leaderboard" in body

    def test_leaderboard_with_pagination(self, http_client: httpx.Client):
        resp = http_client.get("/v1/reputation/leaderboard", params={"page": 1, "limit": 5})
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# 6. Staking leaderboard via raw HTTP
# ---------------------------------------------------------------------------


class TestStakingLeaderboard:
    """Test the staking leaderboard endpoint via raw HTTP."""

    def test_staking_leaderboard_returns_200(self, http_client: httpx.Client):
        resp = http_client.get("/v1/staking/leaderboard")
        assert resp.status_code == 200

    def test_staking_leaderboard_response_shape(self, http_client: httpx.Client):
        resp = http_client.get("/v1/staking/leaderboard")
        body = resp.json()
        assert isinstance(body, (list, dict))

    def test_staking_leaderboard_with_pagination(self, http_client: httpx.Client):
        resp = http_client.get("/v1/staking/leaderboard", params={"page": 1, "limit": 5})
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# 7. Guilds list via raw HTTP
# ---------------------------------------------------------------------------


class TestGuildsList:
    """Test listing guilds via raw HTTP."""

    def test_guilds_list_returns_200(self, http_client: httpx.Client):
        resp = http_client.get("/v1/guilds")
        assert resp.status_code == 200

    def test_guilds_list_response_has_pagination(self, http_client: httpx.Client):
        resp = http_client.get("/v1/guilds", params={"page": 1, "limit": 5})
        assert resp.status_code == 200
        body = resp.json()
        if isinstance(body, dict):
            assert "data" in body or "guilds" in body
            if "pagination" in body:
                pagination = body["pagination"]
                assert "page" in pagination
                assert "limit" in pagination
                assert "total" in pagination

    def test_guilds_list_with_search(self, http_client: httpx.Client):
        resp = http_client.get("/v1/guilds", params={"q": "test"})
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# 8. Webhook CRUD via raw HTTP
# ---------------------------------------------------------------------------


class TestWebhookCRUD:
    """
    Test webhook create, list, and delete lifecycle via raw HTTP.

    Note: Creating and deleting webhooks requires EIP-712 signatures,
    so these tests validate the auth requirement is enforced and that
    list (which only needs API-key auth) works correctly.
    """

    def test_webhook_list_returns_200(self, http_client: httpx.Client):
        resp = http_client.get("/v1/webhooks")
        assert resp.status_code == 200

    def test_webhook_list_response_shape(self, http_client: httpx.Client):
        resp = http_client.get("/v1/webhooks")
        body = resp.json()
        assert isinstance(body, dict)
        assert "data" in body
        assert "pagination" in body
        assert isinstance(body["data"], list)

    def test_webhook_list_with_pagination(self, http_client: httpx.Client):
        resp = http_client.get("/v1/webhooks", params={"page": 1, "limit": 5})
        assert resp.status_code == 200
        body = resp.json()
        assert body["pagination"]["page"] == 1
        assert body["pagination"]["limit"] == 5

    def test_webhook_create_requires_auth(self, http_client: httpx.Client):
        """Creating a webhook requires EIP-712 signature; API-key alone should fail."""
        resp = http_client.post(
            "/v1/webhooks",
            json={
                "url": "https://example.com/webhook-test",
                "events": ["agent.registered"],
            },
        )
        # Without EIP-712 signature, the server should reject with 401 or 403
        assert resp.status_code in (401, 403)

    def test_webhook_delete_requires_auth(self, http_client: httpx.Client):
        """Deleting a webhook with a fake ID should fail with auth, 404, or 400."""
        fake_id = str(uuid.uuid4())
        resp = http_client.delete(f"/v1/webhooks/{fake_id}")
        # Without EIP-712 signature: 400/401/403; or 404 if auth passes
        assert resp.status_code in (400, 401, 403, 404)


# ---------------------------------------------------------------------------
# 9. Pagination params (page=1, limit=5)
# ---------------------------------------------------------------------------


class TestPaginationParams:
    """Verify that pagination parameters are respected across endpoints (raw HTTP)."""

    def test_agents_pagination(self, http_client: httpx.Client):
        resp = http_client.get("/v1/agents", params={"page": 1, "limit": 5})
        assert resp.status_code == 200
        body = resp.json()
        assert body["pagination"]["page"] == 1
        assert body["pagination"]["limit"] == 5
        assert len(body["data"]) <= 5

    def test_transactions_pagination(self, http_client: httpx.Client):
        resp = http_client.get("/v1/transactions", params={"page": 1, "limit": 5})
        assert resp.status_code == 200
        body = resp.json()
        assert body["pagination"]["page"] == 1
        assert body["pagination"]["limit"] == 5
        assert len(body["data"]) <= 5

    def test_page_2_offset(self, http_client: httpx.Client):
        """Requesting page 2 should not return the same first-page data
        (unless total items fit in one page)."""
        resp1 = http_client.get("/v1/agents", params={"page": 1, "limit": 2})
        resp2 = http_client.get("/v1/agents", params={"page": 2, "limit": 2})
        body1 = resp1.json()
        body2 = resp2.json()
        if body1["pagination"]["totalPages"] > 1:
            page1_ids = {a["id"] for a in body1["data"]}
            page2_ids = {a["id"] for a in body2["data"]}
            assert page1_ids != page2_ids, "Page 1 and page 2 should contain different agents"


# ---------------------------------------------------------------------------
# 10. Error response shape
# ---------------------------------------------------------------------------


class TestErrorResponseShape:
    """Verify that error responses include the expected fields."""

    def test_404_has_error_and_code(self, http_client: httpx.Client):
        fake_id = f"nonexistent-{uuid.uuid4()}"
        resp = http_client.get(f"/v1/agents/{fake_id}")
        assert resp.status_code == 404
        body = resp.json()
        # The API should return either 'error' or 'message', plus 'code'
        has_message = "message" in body or "error" in body
        assert has_message, f"Error response missing message/error field: {body}"

    def test_sdk_not_found_error_has_code_and_message(self, sdk_client: ARPClient):
        fake_id = f"nonexistent-{uuid.uuid4()}"
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.agents.get(fake_id)
        err = exc_info.value
        assert err.code == "NOT_FOUND"
        assert isinstance(err.message, str)
        assert len(err.message) > 0

    def test_invalid_endpoint_returns_404(self, http_client: httpx.Client):
        resp = http_client.get("/v1/this-endpoint-does-not-exist")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# 11. Guild operations via raw HTTP
# ---------------------------------------------------------------------------


class TestGuildOperations:
    """Test guild register, get, and leaderboard via raw HTTP."""

    def test_guild_register_requires_auth(self, http_client: httpx.Client):
        """Creating a guild requires EIP-712 signature; API-key should fail."""
        resp = http_client.post(
            "/v1/guilds",
            json={
                "name": f"Test Guild {uuid.uuid4().hex[:8]}",
                "description": "Integration test guild",
            },
        )
        # Without EIP-712 signature: 401 or 403
        assert resp.status_code in (401, 403)

    def test_guild_get_nonexistent_returns_404(self, http_client: httpx.Client):
        fake_id = str(uuid.uuid4())
        resp = http_client.get(f"/v1/guilds/{fake_id}")
        assert resp.status_code == 404

    def test_guild_leaderboard(self, http_client: httpx.Client):
        """Guild leaderboard returns paginated results."""
        resp = http_client.get("/v1/guilds/leaderboard")
        assert resp.status_code == 200
        body = resp.json()
        assert "data" in body
        assert "pagination" in body
        assert isinstance(body["data"], list)


# ---------------------------------------------------------------------------
# 12. Transaction post and cancel lifecycle via raw HTTP
# ---------------------------------------------------------------------------


class TestTransactionLifecycle:
    """
    Test creating and cancelling a transaction via raw HTTP.

    Note: Creating transactions requires EIP-712 auth and two registered
    agents. These tests verify the auth gating and error handling rather
    than a full happy-path lifecycle (which needs private keys and agent setup).
    """

    def test_create_transaction_requires_auth(self, http_client: httpx.Client):
        """Posting a transaction requires EIP-712 signature."""
        resp = http_client.post(
            "/v1/transactions",
            json={
                "from": "0x0000000000000000000000000000000000000001",
                "to": "0x0000000000000000000000000000000000000002",
                "type": "service",
                "amount": "1000000",
                "description": "Integration test transaction",
            },
        )
        # Without EIP-712 signature: 401 or 403
        assert resp.status_code in (401, 403)

    def test_cancel_nonexistent_transaction(self, http_client: httpx.Client):
        """Cancelling a nonexistent transaction should return 400, 404, or auth error."""
        fake_id = str(uuid.uuid4())
        resp = http_client.post(f"/v1/transactions/{fake_id}/cancel")
        assert resp.status_code in (400, 401, 403, 404)

    def test_get_nonexistent_transaction_returns_404(self, http_client: httpx.Client):
        fake_id = str(uuid.uuid4())
        resp = http_client.get(f"/v1/transactions/{fake_id}")
        assert resp.status_code == 404

    def test_transaction_list_via_raw_http(self, http_client: httpx.Client):
        resp = http_client.get("/v1/transactions", params={"page": 1, "limit": 5})
        assert resp.status_code == 200
        body = resp.json()
        assert "data" in body
        assert "pagination" in body


# ---------------------------------------------------------------------------
# 13. SDK error hierarchy sanity checks
# ---------------------------------------------------------------------------


class TestSDKErrorHierarchy:
    """Verify that SDK errors raised against the live API have correct types."""

    def test_not_found_is_arp_error(self, sdk_client: ARPClient):
        with pytest.raises(ARPError):
            sdk_client.agents.get(f"no-such-agent-{uuid.uuid4()}")

    def test_not_found_is_specific_subclass(self, sdk_client: ARPClient):
        with pytest.raises(NotFoundError):
            sdk_client.agents.get(f"no-such-agent-{uuid.uuid4()}")

    def test_error_attributes_populated(self, sdk_client: ARPClient):
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.agents.get(f"no-such-agent-{uuid.uuid4()}")
        err = exc_info.value
        assert hasattr(err, "code")
        assert hasattr(err, "message")
        assert hasattr(err, "details")
