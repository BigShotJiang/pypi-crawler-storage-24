"""Tests for API-compatible EIP-712 authentication."""

from __future__ import annotations

import json

from eth_account import Account

from arp_sdk.auth import (
    AUTH_DOMAIN,
    AUTH_TYPES,
    sign_auth_message,
    ARP_DOMAIN,
    ARP_TYPES,
    sign_typed_data,
    get_address,
    generate_nonce,
    generate_deadline,
)


# Deterministic test key
TEST_PRIVATE_KEY = "0x" + "ab" * 32
TEST_ADDRESS = Account.from_key(TEST_PRIVATE_KEY).address


class TestAuthDomain:
    """Tests for API-compatible domain and types."""

    def test_auth_domain_shape(self):
        """AUTH_DOMAIN should have name and version only (no verifyingContract, no chainId)."""
        assert AUTH_DOMAIN["name"] == "AgentReputationProtocol"
        assert AUTH_DOMAIN["version"] == "1"
        assert "chainId" not in AUTH_DOMAIN
        assert "verifyingContract" not in AUTH_DOMAIN

    def test_auth_types_has_auth_message(self):
        """AUTH_TYPES should define AuthMessage with action, timestamp, nonce."""
        assert "AuthMessage" in AUTH_TYPES
        field_names = [f["name"] for f in AUTH_TYPES["AuthMessage"]]
        assert field_names == ["action", "timestamp", "nonce"]
        field_types = [f["type"] for f in AUTH_TYPES["AuthMessage"]]
        assert field_types == ["string", "uint256", "string"]


class TestSignAuthMessage:
    """Tests for sign_auth_message function."""

    def test_returns_signature_and_message(self):
        """sign_auth_message should return signature and message dict."""
        result = sign_auth_message(TEST_PRIVATE_KEY, "POST /v1/agents")
        assert "signature" in result
        assert "message" in result
        assert isinstance(result["signature"], str)
        assert len(result["signature"]) > 0

    def test_message_contains_required_fields(self):
        """The returned message should have action, timestamp, and nonce."""
        result = sign_auth_message(TEST_PRIVATE_KEY, "POST /v1/agents")
        msg = result["message"]
        assert msg["action"] == "POST /v1/agents"
        assert isinstance(msg["timestamp"], int)
        assert isinstance(msg["nonce"], str)
        assert len(msg["nonce"]) > 0

    def test_default_chain_id(self):
        """Default chain_id should be 84532 (Base Sepolia)."""
        result1 = sign_auth_message(TEST_PRIVATE_KEY, "GET /test")
        result2 = sign_auth_message(TEST_PRIVATE_KEY, "GET /test", chain_id=84532)
        # Both should produce valid signatures (can't compare exact since nonces differ)
        assert isinstance(result1["signature"], str)
        assert isinstance(result2["signature"], str)

    def test_custom_chain_id(self):
        """Should work with a custom chain_id."""
        result = sign_auth_message(TEST_PRIVATE_KEY, "POST /v1/agents", chain_id=1)
        assert isinstance(result["signature"], str)
        assert len(result["signature"]) > 0

    def test_signature_is_valid_hex(self):
        """Signature should be a valid hex string (65 bytes = 130 hex chars)."""
        result = sign_auth_message(TEST_PRIVATE_KEY, "POST /v1/agents")
        sig = result["signature"]
        # Remove 0x prefix if present
        hex_sig = sig[2:] if sig.startswith("0x") else sig
        assert len(hex_sig) == 130  # 65 bytes * 2 hex chars

    def test_message_is_json_serializable(self):
        """The message dict should be JSON-serializable (for X-EIP712-Message header)."""
        result = sign_auth_message(TEST_PRIVATE_KEY, "PATCH /v1/agents/123")
        serialized = json.dumps(result["message"])
        parsed = json.loads(serialized)
        assert parsed["action"] == "PATCH /v1/agents/123"


class TestLegacyAuth:
    """Tests for legacy auth functions (backward compat)."""

    def test_legacy_domain_has_verifying_contract(self):
        """Legacy ARP_DOMAIN should have chainId=1 and verifyingContract."""
        assert ARP_DOMAIN["chainId"] == 1
        assert ARP_DOMAIN["verifyingContract"] == "0x0000000000000000000000000000000000000000"

    def test_legacy_types_exist(self):
        """Legacy ARP_TYPES should have all operation types."""
        expected_types = [
            "RegisterAgent", "UpdateAgent", "AcceptTransaction",
            "SubmitTransaction", "Deposit", "Withdraw", "Dispute",
        ]
        for t in expected_types:
            assert t in ARP_TYPES

    def test_get_address(self):
        """get_address should derive the correct Ethereum address."""
        addr = get_address(TEST_PRIVATE_KEY)
        assert addr == TEST_ADDRESS

    def test_generate_nonce(self):
        """generate_nonce should return a positive integer."""
        nonce = generate_nonce()
        assert isinstance(nonce, int)
        assert nonce > 0

    def test_generate_deadline(self):
        """generate_deadline should return a future timestamp."""
        import time
        now = int(time.time())
        deadline = generate_deadline()
        assert deadline > now
        assert deadline <= now + 301  # default 300s + 1s tolerance

    def test_sign_typed_data(self):
        """Legacy sign_typed_data should produce a valid hex signature."""
        sig = sign_typed_data(TEST_PRIVATE_KEY, "RegisterAgent", {
            "name": "Test",
            "description": "Test agent",
            "domains": "general",
            "nonce": 12345,
            "deadline": 99999,
        })
        assert isinstance(sig, str)
        assert len(sig) > 0
