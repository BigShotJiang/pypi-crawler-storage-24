"""
Tests for arp_sdk.models module.

Covers Pydantic model validation from snake_case API response data,
enum values, generic PaginatedResponse, and all key domain models.
"""

import pytest
from datetime import datetime, timezone

from arp_sdk.models import (
    Agent,
    AgentStatus,
    AgentWithDetails,
    DomainReputation,
    DomainReputationScore,
    Guild,
    PaginatedResponse,
    PaginationInfo,
    ReputationScore,
    StakeInfo,
    Transaction,
    TransactionStatus,
    Webhook,
    WebhookEvent,
)


# ──────────────────────────────────────────────
# Shared fixtures
# ──────────────────────────────────────────────

TIMESTAMP_STR = "2025-06-15T10:30:00Z"
TIMESTAMP_DT = datetime(2025, 6, 15, 10, 30, 0, tzinfo=timezone.utc)


def _agent_data(**overrides) -> dict:
    """Return a dict matching the actual API response for an agent (snake_case)."""
    base = {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "agent_id": "1008",
        "owner_address": "0xABCDEF1234567890abcdef1234567890ABCDEF12",
        "registration_uri": "did:arp:base-sepolia:1008",
        "registration_hash": "QmHash001",
        "guild_id": None,
        "status": "active",
        "on_chain_tx_hash": "0xabc123",
        "composite_score": "82.2500000000000000",
        "created_at": TIMESTAMP_STR,
        "updated_at": TIMESTAMP_STR,
    }
    base.update(overrides)
    return base


def _agent_detail_data(**overrides) -> dict:
    """Return a dict matching the actual API response for agent detail (inside 'data' key)."""
    base = _agent_data()
    base["reputation_scores"] = [
        {
            "domain": "code_generation",
            "score": "94.50",
            "confidence": "0.920",
            "transaction_count": 12,
            "volume_total": "780000000",
            "last_calculated": TIMESTAMP_STR,
        },
    ]
    base.update(overrides)
    return base


# ──────────────────────────────────────────────
# Agent model
# ──────────────────────────────────────────────


class TestAgentModel:
    """Test Agent model validation and field mapping."""

    def test_validate_from_api_response(self):
        agent = Agent.model_validate(_agent_data())
        assert agent.id == "550e8400-e29b-41d4-a716-446655440000"
        assert agent.agent_id == "1008"
        assert agent.owner_address == "0xABCDEF1234567890abcdef1234567890ABCDEF12"
        assert agent.registration_uri == "did:arp:base-sepolia:1008"
        assert agent.registration_hash == "QmHash001"
        assert agent.guild_id is None
        assert agent.status == AgentStatus.ACTIVE
        assert agent.on_chain_tx_hash == "0xabc123"
        assert agent.composite_score == "82.2500000000000000"
        assert agent.created_at == TIMESTAMP_DT
        assert agent.updated_at == TIMESTAMP_DT

    def test_optional_fields_default_to_none(self):
        data = {
            "id": "uuid-1",
            "agent_id": "1001",
            "owner_address": "0x123",
            "status": "active",
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
        }
        agent = Agent.model_validate(data)
        assert agent.registration_uri is None
        assert agent.registration_hash is None
        assert agent.guild_id is None
        assert agent.on_chain_tx_hash is None
        assert agent.composite_score is None

    def test_invalid_status_raises(self):
        data = _agent_data(status="nonexistent_status")
        with pytest.raises(Exception):
            Agent.model_validate(data)

    def test_suspended_status(self):
        agent = Agent.model_validate(_agent_data(status="suspended"))
        assert agent.status == AgentStatus.SUSPENDED

    def test_deregistered_status(self):
        agent = Agent.model_validate(_agent_data(status="deregistered"))
        assert agent.status == AgentStatus.DEREGISTERED


# ──────────────────────────────────────────────
# AgentWithDetails model
# ──────────────────────────────────────────────


class TestAgentWithDetails:
    """Test AgentWithDetails model with reputation_scores."""

    def test_validate_with_reputation_scores(self):
        agent = AgentWithDetails.model_validate(_agent_detail_data())
        assert agent.id == "550e8400-e29b-41d4-a716-446655440000"
        assert agent.agent_id == "1008"
        assert agent.owner_address == "0xABCDEF1234567890abcdef1234567890ABCDEF12"
        assert len(agent.reputation_scores) == 1
        score = agent.reputation_scores[0]
        assert isinstance(score, DomainReputationScore)
        assert score.domain == "code_generation"
        assert score.score == "94.50"
        assert score.confidence == "0.920"
        assert score.transaction_count == 12
        assert score.volume_total == "780000000"

    def test_reputation_scores_defaults_to_empty_list(self):
        data = _agent_data()
        # No reputation_scores key
        agent = AgentWithDetails.model_validate(data)
        assert agent.reputation_scores == []


# ──────────────────────────────────────────────
# Enum values
# ──────────────────────────────────────────────


class TestEnums:
    """Test that enum members have expected string values."""

    def test_agent_status_values(self):
        assert AgentStatus.ACTIVE == "active"
        assert AgentStatus.SUSPENDED == "suspended"
        assert AgentStatus.DEREGISTERED == "deregistered"

    def test_agent_status_is_str(self):
        assert isinstance(AgentStatus.ACTIVE, str)

    def test_transaction_status_values(self):
        assert TransactionStatus.POSTED == "posted"
        assert TransactionStatus.ACCEPTED == "accepted"
        assert TransactionStatus.IN_PROGRESS == "in_progress"
        assert TransactionStatus.SUBMITTED == "submitted"
        assert TransactionStatus.VERIFYING == "verifying"
        assert TransactionStatus.SETTLED == "settled"
        assert TransactionStatus.SLASHED == "slashed"
        assert TransactionStatus.DISPUTED == "disputed"
        assert TransactionStatus.EXPIRED == "expired"
        assert TransactionStatus.CANCELLED == "cancelled"
        assert TransactionStatus.RESOLVED == "resolved"

    def test_transaction_status_is_str(self):
        assert isinstance(TransactionStatus.POSTED, str)

    def test_webhook_event_values(self):
        assert WebhookEvent.TRANSACTION_CREATED == "transaction.created"
        assert WebhookEvent.REPUTATION_UPDATED == "reputation.updated"
        assert WebhookEvent.AGENT_REGISTERED == "agent.registered"
        assert WebhookEvent.STAKING_DEPOSITED == "staking.deposited"


# ──────────────────────────────────────────────
# PaginationInfo
# ──────────────────────────────────────────────


class TestPaginationInfo:
    """Test PaginationInfo model with camelCase alias."""

    def test_from_camel_case(self):
        data = {"page": 1, "limit": 25, "total": 100, "totalPages": 4}
        info = PaginationInfo.model_validate(data)
        assert info.page == 1
        assert info.limit == 25
        assert info.total == 100
        assert info.total_pages == 4

    def test_from_snake_case(self):
        data = {"page": 2, "limit": 10, "total": 50, "total_pages": 5}
        info = PaginationInfo.model_validate(data)
        assert info.total_pages == 5


# ──────────────────────────────────────────────
# PaginatedResponse
# ──────────────────────────────────────────────


class TestPaginatedResponse:
    """Test the generic PaginatedResponse[T] type."""

    def test_paginated_response_with_agents(self):
        pagination_data = {"page": 1, "limit": 10, "total": 2, "totalPages": 1}
        agents = [
            Agent.model_validate(_agent_data()),
        ]
        pagination = PaginationInfo.model_validate(pagination_data)
        response = PaginatedResponse[Agent](data=agents, pagination=pagination)

        assert len(response.data) == 1
        assert response.data[0].id == "550e8400-e29b-41d4-a716-446655440000"
        assert response.pagination.page == 1
        assert response.pagination.total == 2

    def test_paginated_response_empty(self):
        pagination_data = {"page": 1, "limit": 10, "total": 0, "totalPages": 0}
        pagination = PaginationInfo.model_validate(pagination_data)
        response = PaginatedResponse[Agent](data=[], pagination=pagination)

        assert response.data == []
        assert response.pagination.total == 0


# ──────────────────────────────────────────────
# ReputationScore with nested DomainReputation
# ──────────────────────────────────────────────


class TestReputationScore:
    """Test ReputationScore model including nested DomainReputation."""

    def _reputation_data(self) -> dict:
        return {
            "agent_id": "agent-001",
            "overall": 0.85,
            "domains": {
                "defi": {
                    "domain": "defi",
                    "score": 0.9,
                    "transaction_count": 42,
                    "success_rate": 0.95,
                    "average_rating": 4.5,
                },
                "nft": {
                    "domain": "nft",
                    "score": 0.7,
                    "transaction_count": 10,
                    "success_rate": 0.8,
                    "average_rating": 3.8,
                },
            },
            "total_transactions": 52,
            "success_rate": 0.92,
            "last_updated": TIMESTAMP_STR,
        }

    def test_validate_reputation_score(self):
        rep = ReputationScore.model_validate(self._reputation_data())
        assert rep.agent_id == "agent-001"
        assert rep.overall == 0.85
        assert rep.total_transactions == 52
        assert rep.success_rate == 0.92
        assert rep.last_updated == TIMESTAMP_DT

    def test_nested_domain_reputation(self):
        rep = ReputationScore.model_validate(self._reputation_data())
        assert "defi" in rep.domains
        defi = rep.domains["defi"]
        assert isinstance(defi, DomainReputation)
        assert defi.domain == "defi"
        assert defi.score == 0.9
        assert defi.transaction_count == 42
        assert defi.success_rate == 0.95
        assert defi.average_rating == 4.5

    def test_domains_default_empty(self):
        data = self._reputation_data()
        del data["domains"]
        rep = ReputationScore.model_validate(data)
        assert rep.domains == {}


# ──────────────────────────────────────────────
# DomainReputation standalone
# ──────────────────────────────────────────────


class TestDomainReputation:
    """Test DomainReputation model validation."""

    def test_from_snake_case(self):
        data = {
            "domain": "defi",
            "score": 0.88,
            "transaction_count": 100,
            "success_rate": 0.95,
            "average_rating": 4.2,
        }
        dr = DomainReputation.model_validate(data)
        assert dr.domain == "defi"
        assert dr.score == 0.88
        assert dr.transaction_count == 100
        assert dr.success_rate == 0.95
        assert dr.average_rating == 4.2

    def test_from_snake_case_alternate_values(self):
        data = {
            "domain": "nft",
            "score": 0.75,
            "transaction_count": 50,
            "success_rate": 0.80,
            "average_rating": 3.9,
        }
        dr = DomainReputation.model_validate(data)
        assert dr.transaction_count == 50
        assert dr.success_rate == 0.80


# ──────────────────────────────────────────────
# Transaction model
# ──────────────────────────────────────────────


class TestTransaction:
    """Test Transaction model with required and optional fields."""

    def _transaction_data(self, **overrides) -> dict:
        base = {
            "id": "550e8400-e29b-41d4-a716-446655440001",
            "on_chain_task_id": "5006",
            "requester_agent_id": "550e8400-e29b-41d4-a716-446655440002",
            "provider_agent_id": None,
            "task_hash": "0xaaaa1234",
            "output_hash": None,
            "payment_amount": "100000000",
            "stake_amount": "50000000",
            "domain": "security",
            "deadline": "2026-04-01T00:00:00Z",
            "status": "posted",
            "quality_score": None,
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
            "accepted_at": None,
            "submitted_at": None,
            "settled_at": None,
            "on_chain_tx_hash": None,
            "requester_address": "0x1234567890abcdef1234567890abcdef12345678",
            "provider_address": None,
        }
        base.update(overrides)
        return base

    def test_validate_posted_transaction(self):
        tx = Transaction.model_validate(self._transaction_data())
        assert tx.id == "550e8400-e29b-41d4-a716-446655440001"
        assert tx.on_chain_task_id == "5006"
        assert tx.requester_agent_id == "550e8400-e29b-41d4-a716-446655440002"
        assert tx.provider_agent_id is None
        assert tx.task_hash == "0xaaaa1234"
        assert tx.output_hash is None
        assert tx.payment_amount == "100000000"
        assert tx.stake_amount == "50000000"
        assert tx.domain == "security"
        assert tx.status == TransactionStatus.POSTED
        assert tx.quality_score is None
        assert tx.accepted_at is None
        assert tx.submitted_at is None
        assert tx.settled_at is None
        assert tx.on_chain_tx_hash is None
        assert tx.requester_address == "0x1234567890abcdef1234567890abcdef12345678"
        assert tx.provider_address is None

    def test_validate_accepted_transaction(self):
        tx = Transaction.model_validate(
            self._transaction_data(
                status="accepted",
                provider_agent_id="550e8400-e29b-41d4-a716-446655440003",
                accepted_at=TIMESTAMP_STR,
                provider_address="0xabcdef",
            )
        )
        assert tx.status == TransactionStatus.ACCEPTED
        assert tx.provider_agent_id == "550e8400-e29b-41d4-a716-446655440003"
        assert tx.accepted_at == TIMESTAMP_DT
        assert tx.provider_address == "0xabcdef"

    def test_validate_settled_transaction(self):
        tx = Transaction.model_validate(
            self._transaction_data(
                status="settled",
                quality_score="95.00",
                settled_at=TIMESTAMP_STR,
                on_chain_tx_hash="0xdeadbeef",
            )
        )
        assert tx.status == TransactionStatus.SETTLED
        assert tx.quality_score == "95.00"
        assert tx.settled_at == TIMESTAMP_DT
        assert tx.on_chain_tx_hash == "0xdeadbeef"

    def test_validate_disputed_transaction(self):
        tx = Transaction.model_validate(
            self._transaction_data(status="disputed")
        )
        assert tx.status == TransactionStatus.DISPUTED

    def test_validate_cancelled_transaction(self):
        tx = Transaction.model_validate(
            self._transaction_data(status="cancelled")
        )
        assert tx.status == TransactionStatus.CANCELLED

    def test_validate_in_progress_transaction(self):
        tx = Transaction.model_validate(
            self._transaction_data(status="in_progress")
        )
        assert tx.status == TransactionStatus.IN_PROGRESS

    def test_minimal_transaction(self):
        """Transaction with only required fields."""
        data = {
            "id": "uuid-min",
            "status": "posted",
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
        }
        tx = Transaction.model_validate(data)
        assert tx.id == "uuid-min"
        assert tx.status == TransactionStatus.POSTED
        assert tx.on_chain_task_id is None
        assert tx.domain is None


# ──────────────────────────────────────────────
# StakeInfo model
# ──────────────────────────────────────────────


class TestStakeInfo:
    """Test StakeInfo model with optional timestamp fields."""

    def test_validate_full_stake(self):
        data = {
            "agent_id": "agent-001",
            "amount": "5000000000000000000",
            "locked_until": TIMESTAMP_STR,
            "last_deposit_at": TIMESTAMP_STR,
            "last_withdraw_at": None,
        }
        stake = StakeInfo.model_validate(data)
        assert stake.agent_id == "agent-001"
        assert stake.amount == "5000000000000000000"
        assert stake.locked_until == TIMESTAMP_DT
        assert stake.last_deposit_at == TIMESTAMP_DT
        assert stake.last_withdraw_at is None

    def test_validate_minimal_stake(self):
        data = {
            "agent_id": "agent-002",
            "amount": "0",
        }
        stake = StakeInfo.model_validate(data)
        assert stake.agent_id == "agent-002"
        assert stake.amount == "0"
        assert stake.locked_until is None
        assert stake.last_deposit_at is None
        assert stake.last_withdraw_at is None

    def test_from_snake_case(self):
        data = {
            "agent_id": "agent-003",
            "amount": "100",
            "locked_until": TIMESTAMP_STR,
            "last_deposit_at": TIMESTAMP_STR,
            "last_withdraw_at": TIMESTAMP_STR,
        }
        stake = StakeInfo.model_validate(data)
        assert stake.agent_id == "agent-003"
        assert stake.locked_until == TIMESTAMP_DT


# ──────────────────────────────────────────────
# Guild model
# ──────────────────────────────────────────────


class TestGuild:
    """Test Guild model validation."""

    def _guild_data(self) -> dict:
        return {
            "id": "guild-001",
            "on_chain_guild_id": "2",
            "name": "DeFi Masters",
            "owner_agent_id": "agent-001",
            "domain": "defi",
            "min_reputation": "50.00",
            "member_count": 42,
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
        }

    def test_validate_guild(self):
        guild = Guild.model_validate(self._guild_data())
        assert guild.id == "guild-001"
        assert guild.on_chain_guild_id == "2"
        assert guild.name == "DeFi Masters"
        assert guild.domain == "defi"
        assert guild.owner_agent_id == "agent-001"
        assert guild.min_reputation == "50.00"
        assert guild.member_count == 42
        assert guild.created_at == TIMESTAMP_DT
        assert guild.updated_at == TIMESTAMP_DT

    def test_optional_fields_default(self):
        data = {
            "id": "guild-002",
            "name": "Test Guild",
            "owner_agent_id": "agent-002",
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
        }
        guild = Guild.model_validate(data)
        assert guild.on_chain_guild_id is None
        assert guild.domain is None
        assert guild.min_reputation is None
        assert guild.member_count == 0


# ──────────────────────────────────────────────
# Webhook model
# ──────────────────────────────────────────────


class TestWebhook:
    """Test Webhook model validation."""

    def test_validate_webhook(self):
        data = {
            "id": "wh-001",
            "owner_address": "0x1234567890abcdef",
            "url": "https://example.com/webhook",
            "event_types": ["agent.registered", "reputation.updated"],
            "secret_hash": "abc123hash",
            "is_active": True,
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
        }
        wh = Webhook.model_validate(data)
        assert wh.id == "wh-001"
        assert wh.owner_address == "0x1234567890abcdef"
        assert wh.url == "https://example.com/webhook"
        assert wh.event_types == ["agent.registered", "reputation.updated"]
        assert wh.secret_hash == "abc123hash"
        assert wh.is_active is True
        assert wh.created_at == TIMESTAMP_DT

    def test_webhook_inactive(self):
        data = {
            "id": "wh-002",
            "url": "https://example.com/hook2",
            "event_types": ["agent.registered"],
            "is_active": False,
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
        }
        wh = Webhook.model_validate(data)
        assert wh.is_active is False
        assert wh.event_types == ["agent.registered"]

    def test_webhook_defaults(self):
        data = {
            "id": "wh-003",
            "url": "https://example.com/hook3",
            "created_at": TIMESTAMP_STR,
            "updated_at": TIMESTAMP_STR,
        }
        wh = Webhook.model_validate(data)
        assert wh.owner_address is None
        assert wh.event_types == []
        assert wh.secret_hash is None
        assert wh.is_active is True
