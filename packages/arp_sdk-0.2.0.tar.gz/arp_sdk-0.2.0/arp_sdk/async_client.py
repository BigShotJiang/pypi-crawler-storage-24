"""
Asynchronous client for the Agent Reputation Protocol.

Usage:
    from arp_sdk import AsyncARPClient

    async with AsyncARPClient(
        api_url="https://api.arp.example.com",
        api_key="your-api-key",
    ) as client:
        agent = await client.agents.get("agent-123")
        score = await client.reputation.get("agent-123")

    # Write operations (require private_key)
    async with AsyncARPClient(
        api_url="https://api.arp.example.com",
        api_key="your-api-key",
        private_key="0x...",
    ) as client:
        new_agent = await client.agents.register(
            name="MyAgent",
            description="An autonomous agent",
        )
"""

from __future__ import annotations

from .http import AsyncHttpClient
from .resources.agents import AsyncAgentsClient
from .resources.reputation import AsyncReputationClient
from .resources.transactions import AsyncTransactionsClient
from .resources.staking import AsyncStakingClient
from .resources.guilds import AsyncGuildsClient
from .resources.webhooks import AsyncWebhooksClient
from .resources.system import AsyncSystemClient


class AsyncARPClient:
    """
    Asynchronous client for the Agent Reputation Protocol SDK.

    Provides access to all ARP API endpoints through typed async sub-clients.
    """

    def __init__(
        self,
        api_url: str,
        api_key: str,
        private_key: str | None = None,
        chain_id: int = 84532,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self._api_url = api_url
        self._api_key = api_key

        self._http = AsyncHttpClient(
            base_url=api_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
                "User-Agent": "arp-sdk-py/0.1.0",
            },
            timeout=timeout,
            max_retries=max_retries,
            private_key=private_key,
            chain_id=chain_id,
        )

        self.agents = AsyncAgentsClient(self._http)
        self.reputation = AsyncReputationClient(self._http)
        self.transactions = AsyncTransactionsClient(self._http)
        self.staking = AsyncStakingClient(self._http)
        self.guilds = AsyncGuildsClient(self._http)
        self.webhooks = AsyncWebhooksClient(self._http)
        self.system = AsyncSystemClient(self._http)

    async def close(self) -> None:
        """Close the underlying async HTTP client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> AsyncARPClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
