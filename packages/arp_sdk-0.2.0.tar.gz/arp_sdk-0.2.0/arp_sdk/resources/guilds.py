"""
Guild resource clients (sync and async) for creation, membership
management, listing, updating, and leaderboards.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..http import HttpClient, AsyncHttpClient
from ..models import (
    Guild,
    GuildWithMembers,
    GuildLeaderboard,
    PaginatedResponse,
    PaginationInfo,
)


class GuildsClient:
    """Synchronous client for guild endpoints."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Guild]:
        """List all guilds."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = self._http.get("/v1/guilds", params)
        guilds = [Guild.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Guild](data=guilds, pagination=pagination)

    def get(self, guild_id: str) -> GuildWithMembers:
        """Get detailed information about a guild, including its member list."""
        data = self._http.get(f"/v1/guilds/{quote(guild_id, safe='')}")
        return GuildWithMembers.model_validate(data)

    def create(
        self,
        name: str,
        description: str | None = None,
        avatar: str | None = None,
        website: str | None = None,
        requirements: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Guild:
        """Create a new guild."""
        body: dict[str, Any] = {
            "name": name,
        }
        if description is not None:
            body["description"] = description
        if avatar is not None:
            body["avatar"] = avatar
        if website is not None:
            body["website"] = website
        if requirements is not None:
            body["requirements"] = requirements
        if metadata is not None:
            body["metadata"] = metadata

        data = self._http.post("/v1/guilds", body)
        return Guild.model_validate(data)

    def update(
        self,
        guild_id: str,
        name: str | None = None,
        description: str | None = None,
        avatar: str | None = None,
        website: str | None = None,
        requirements: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Guild:
        """Update an existing guild."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if avatar is not None:
            body["avatar"] = avatar
        if website is not None:
            body["website"] = website
        if requirements is not None:
            body["requirements"] = requirements
        if metadata is not None:
            body["metadata"] = metadata

        data = self._http.patch(f"/v1/guilds/{quote(guild_id, safe='')}", body)
        return Guild.model_validate(data)

    def join(
        self,
        guild_id: str,
        message: str | None = None,
    ) -> Any:
        """Join a guild."""
        body: dict[str, Any] = {}
        if message is not None:
            body["message"] = message

        data = self._http.post(
            f"/v1/guilds/{quote(guild_id, safe='')}/join",
            body,
        )
        return data

    def manage_member(
        self,
        guild_id: str,
        member_address: str,
        action: str,
        reason: str | None = None,
    ) -> Any:
        """
        Admin member action (add, remove, promote, demote, etc.).
        Body: { memberAddress, action, reason? }
        """
        body: dict[str, Any] = {
            "memberAddress": member_address,
            "action": action,
        }
        if reason is not None:
            body["reason"] = reason

        data = self._http.post(
            f"/v1/guilds/{quote(guild_id, safe='')}/members",
            body,
        )
        return data

    def get_leaderboard(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """
        Get the global guild leaderboard.
        """
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = self._http.get("/v1/guilds/leaderboard", params)
        return data


class AsyncGuildsClient:
    """Asynchronous client for guild endpoints."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Guild]:
        """List all guilds."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = await self._http.get("/v1/guilds", params)
        guilds = [Guild.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Guild](data=guilds, pagination=pagination)

    async def get(self, guild_id: str) -> GuildWithMembers:
        """Get detailed information about a guild, including its member list."""
        data = await self._http.get(f"/v1/guilds/{quote(guild_id, safe='')}")
        return GuildWithMembers.model_validate(data)

    async def create(
        self,
        name: str,
        description: str | None = None,
        avatar: str | None = None,
        website: str | None = None,
        requirements: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Guild:
        """Create a new guild."""
        body: dict[str, Any] = {
            "name": name,
        }
        if description is not None:
            body["description"] = description
        if avatar is not None:
            body["avatar"] = avatar
        if website is not None:
            body["website"] = website
        if requirements is not None:
            body["requirements"] = requirements
        if metadata is not None:
            body["metadata"] = metadata

        data = await self._http.post("/v1/guilds", body)
        return Guild.model_validate(data)

    async def update(
        self,
        guild_id: str,
        name: str | None = None,
        description: str | None = None,
        avatar: str | None = None,
        website: str | None = None,
        requirements: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Guild:
        """Update an existing guild."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if avatar is not None:
            body["avatar"] = avatar
        if website is not None:
            body["website"] = website
        if requirements is not None:
            body["requirements"] = requirements
        if metadata is not None:
            body["metadata"] = metadata

        data = await self._http.patch(f"/v1/guilds/{quote(guild_id, safe='')}", body)
        return Guild.model_validate(data)

    async def join(
        self,
        guild_id: str,
        message: str | None = None,
    ) -> Any:
        """Join a guild."""
        body: dict[str, Any] = {}
        if message is not None:
            body["message"] = message

        data = await self._http.post(
            f"/v1/guilds/{quote(guild_id, safe='')}/join",
            body,
        )
        return data

    async def manage_member(
        self,
        guild_id: str,
        member_address: str,
        action: str,
        reason: str | None = None,
    ) -> Any:
        """
        Admin member action (add, remove, promote, demote, etc.).
        Body: { memberAddress, action, reason? }
        """
        body: dict[str, Any] = {
            "memberAddress": member_address,
            "action": action,
        }
        if reason is not None:
            body["reason"] = reason

        data = await self._http.post(
            f"/v1/guilds/{quote(guild_id, safe='')}/members",
            body,
        )
        return data

    async def get_leaderboard(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """
        Get the global guild leaderboard.
        """
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = await self._http.get("/v1/guilds/leaderboard", params)
        return data
