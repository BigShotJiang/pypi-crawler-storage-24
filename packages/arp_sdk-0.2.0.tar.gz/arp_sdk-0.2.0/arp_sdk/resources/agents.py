"""
Agent resource clients (sync and async) for registration, lookup, update,
search, and activity history.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..http import HttpClient, AsyncHttpClient
from ..models import Agent, AgentWithDetails, PaginatedResponse, PaginationInfo


class AgentsClient:
    """Synchronous client for agent endpoints."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def register(
        self,
        address: str | None = None,
        name: str = "",
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        capabilities: list[str] | None = None,
        endpoint: str | None = None,
    ) -> Agent:
        """Register a new agent in the ARP network. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to register an agent.")

        # Use the signer address if no explicit address provided
        addr = address or self._http.get_signer_address()

        body: dict[str, Any] = {
            "address": addr,
            "name": name,
        }
        if description is not None:
            body["description"] = description
        if metadata is not None:
            body["metadata"] = metadata
        if capabilities is not None:
            body["capabilities"] = capabilities
        if endpoint is not None:
            body["endpoint"] = endpoint

        data = self._http.post("/v1/agents", body)
        return Agent.model_validate(data)

    def get(self, agent_id: str) -> AgentWithDetails:
        """Get detailed information about a specific agent."""
        data = self._http.get(f"/v1/agents/{quote(agent_id, safe='')}")
        return AgentWithDetails.model_validate(data)

    def update(
        self,
        agent_id: str,
        name: str | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        capabilities: list[str] | None = None,
        endpoint: str | None = None,
        status: str | None = None,
    ) -> Agent:
        """Update an existing agent's information. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to update an agent.")

        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if metadata is not None:
            body["metadata"] = metadata
        if capabilities is not None:
            body["capabilities"] = capabilities
        if endpoint is not None:
            body["endpoint"] = endpoint
        if status is not None:
            body["status"] = status

        data = self._http.patch(f"/v1/agents/{quote(agent_id, safe='')}", body)
        return Agent.model_validate(data)

    def search(
        self,
        q: str | None = None,
        capability: str | None = None,
        status: str | None = None,
        min_reputation: float | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Agent]:
        """Search for agents with filtering and pagination."""
        params: dict[str, Any] = {
            "q": q,
            "capability": capability,
            "status": status,
            "minReputation": min_reputation,
            "page": page,
            "limit": limit,
        }

        data = self._http.get("/v1/agents", params)
        agents = [Agent.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Agent](data=agents, pagination=pagination)

    def history(
        self,
        agent_id: str,
        page: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Get paginated activity history for an agent."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = self._http.get(
            f"/v1/agents/{quote(agent_id, safe='')}/history",
            params,
        )
        return data


class AsyncAgentsClient:
    """Asynchronous client for agent endpoints."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def register(
        self,
        address: str | None = None,
        name: str = "",
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        capabilities: list[str] | None = None,
        endpoint: str | None = None,
    ) -> Agent:
        """Register a new agent in the ARP network. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to register an agent.")

        # Use the signer address if no explicit address provided
        addr = address or self._http.get_signer_address()

        body: dict[str, Any] = {
            "address": addr,
            "name": name,
        }
        if description is not None:
            body["description"] = description
        if metadata is not None:
            body["metadata"] = metadata
        if capabilities is not None:
            body["capabilities"] = capabilities
        if endpoint is not None:
            body["endpoint"] = endpoint

        data = await self._http.post("/v1/agents", body)
        return Agent.model_validate(data)

    async def get(self, agent_id: str) -> AgentWithDetails:
        """Get detailed information about a specific agent."""
        data = await self._http.get(f"/v1/agents/{quote(agent_id, safe='')}")
        return AgentWithDetails.model_validate(data)

    async def update(
        self,
        agent_id: str,
        name: str | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        capabilities: list[str] | None = None,
        endpoint: str | None = None,
        status: str | None = None,
    ) -> Agent:
        """Update an existing agent's information. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to update an agent.")

        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if metadata is not None:
            body["metadata"] = metadata
        if capabilities is not None:
            body["capabilities"] = capabilities
        if endpoint is not None:
            body["endpoint"] = endpoint
        if status is not None:
            body["status"] = status

        data = await self._http.patch(f"/v1/agents/{quote(agent_id, safe='')}", body)
        return Agent.model_validate(data)

    async def search(
        self,
        q: str | None = None,
        capability: str | None = None,
        status: str | None = None,
        min_reputation: float | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Agent]:
        """Search for agents with filtering and pagination."""
        params: dict[str, Any] = {
            "q": q,
            "capability": capability,
            "status": status,
            "minReputation": min_reputation,
            "page": page,
            "limit": limit,
        }

        data = await self._http.get("/v1/agents", params)
        agents = [Agent.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Agent](data=agents, pagination=pagination)

    async def history(
        self,
        agent_id: str,
        page: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Get paginated activity history for an agent."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = await self._http.get(
            f"/v1/agents/{quote(agent_id, safe='')}/history",
            params,
        )
        return data
