"""
Reputation resource clients (sync and async) for querying scores,
domain-specific reputation, leaderboard, and batch aggregate lookups.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..http import HttpClient, AsyncHttpClient
from ..models import (
    ReputationScore,
    DomainReputation,
)


class ReputationClient:
    """Synchronous client for reputation endpoints."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get(
        self,
        address: str,
        domain: str | None = None,
        min_score: float | None = None,
        max_score: float | None = None,
        since: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """Get the reputation for an agent by address."""
        params: dict[str, Any] = {
            "domain": domain,
            "minScore": min_score,
            "maxScore": max_score,
            "since": since,
            "page": page,
            "limit": limit,
        }
        data = self._http.get(
            f"/v1/reputation/{quote(address, safe='')}",
            params,
        )
        return data

    def get_domain(self, address: str, domain: str) -> Any:
        """Get the reputation score for an agent in a specific domain."""
        data = self._http.get(
            f"/v1/reputation/{quote(address, safe='')}/{quote(domain, safe='')}"
        )
        return data

    def leaderboard(
        self,
        page: int | None = None,
        limit: int | None = None,
        domain: str | None = None,
    ) -> Any:
        """Get the reputation leaderboard (top agents)."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
            "domain": domain,
        }
        data = self._http.get("/v1/reputation/leaderboard", params)
        return data

    def aggregate(
        self,
        addresses: list[str],
        domain: str | None = None,
    ) -> Any:
        """Batch query reputation for multiple agents."""
        params: dict[str, Any] = {
            "addresses": ",".join(addresses),
        }
        if domain is not None:
            params["domain"] = domain
        data = self._http.get("/v1/reputation/aggregate", params)
        return data

    def submit(
        self,
        subject_address: str,
        domain: str,
        score: float,
        confidence: float,
        evidence: dict[str, Any] | None = None,
        ttl: int | None = None,
    ) -> Any:
        """Submit a reputation score for another agent.

        Requires EIP-712 authentication. The signer must be a registered
        agent and cannot score themselves.

        Args:
            subject_address: Ethereum address of the agent being scored.
            domain: Task domain (e.g. "code_generation").
            score: Reputation score (0-100).
            confidence: Confidence level (0-1).
            evidence: Optional evidence supporting the score.
            ttl: Optional TTL in seconds for the score.
        """
        body: dict[str, Any] = {
            "subjectAddress": subject_address,
            "domain": domain,
            "score": score,
            "confidence": confidence,
        }
        if evidence is not None:
            body["evidence"] = evidence
        if ttl is not None:
            body["ttl"] = ttl
        return self._http.post("/v1/reputation", body)


class AsyncReputationClient:
    """Asynchronous client for reputation endpoints."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get(
        self,
        address: str,
        domain: str | None = None,
        min_score: float | None = None,
        max_score: float | None = None,
        since: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """Get the reputation for an agent by address."""
        params: dict[str, Any] = {
            "domain": domain,
            "minScore": min_score,
            "maxScore": max_score,
            "since": since,
            "page": page,
            "limit": limit,
        }
        data = await self._http.get(
            f"/v1/reputation/{quote(address, safe='')}",
            params,
        )
        return data

    async def get_domain(self, address: str, domain: str) -> Any:
        """Get the reputation score for an agent in a specific domain."""
        data = await self._http.get(
            f"/v1/reputation/{quote(address, safe='')}/{quote(domain, safe='')}"
        )
        return data

    async def leaderboard(
        self,
        page: int | None = None,
        limit: int | None = None,
        domain: str | None = None,
    ) -> Any:
        """Get the reputation leaderboard (top agents)."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
            "domain": domain,
        }
        data = await self._http.get("/v1/reputation/leaderboard", params)
        return data

    async def aggregate(
        self,
        addresses: list[str],
        domain: str | None = None,
    ) -> Any:
        """Batch query reputation for multiple agents."""
        params: dict[str, Any] = {
            "addresses": ",".join(addresses),
        }
        if domain is not None:
            params["domain"] = domain
        data = await self._http.get("/v1/reputation/aggregate", params)
        return data

    async def submit(
        self,
        subject_address: str,
        domain: str,
        score: float,
        confidence: float,
        evidence: dict[str, Any] | None = None,
        ttl: int | None = None,
    ) -> Any:
        """Submit a reputation score for another agent (async).

        Requires EIP-712 authentication. The signer must be a registered
        agent and cannot score themselves.
        """
        body: dict[str, Any] = {
            "subjectAddress": subject_address,
            "domain": domain,
            "score": score,
            "confidence": confidence,
        }
        if evidence is not None:
            body["evidence"] = evidence
        if ttl is not None:
            body["ttl"] = ttl
        return await self._http.post("/v1/reputation", body)
