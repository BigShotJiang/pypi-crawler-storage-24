"""
Transaction resource clients (sync and async) for creating, updating status,
submitting deliverables, rating, disputing, and listing transactions.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..http import HttpClient, AsyncHttpClient
from ..models import (
    Transaction,
    Dispute,
    PaginatedResponse,
    PaginationInfo,
)


class TransactionsClient:
    """Synchronous client for transaction endpoints."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(
        self,
        from_address: str,
        to_address: str,
        type: str,
        amount: str | None = None,
        token_address: str | None = None,
        metadata: dict[str, Any] | None = None,
        description: str | None = None,
        deadline: str | None = None,
    ) -> Transaction:
        """Create a new transaction. Requires a private key for EIP-712 auth."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to create a transaction.")

        body: dict[str, Any] = {
            "from": from_address,
            "to": to_address,
            "type": type,
        }
        if amount is not None:
            body["amount"] = amount
        if token_address is not None:
            body["tokenAddress"] = token_address
        if metadata is not None:
            body["metadata"] = metadata
        if description is not None:
            body["description"] = description
        if deadline is not None:
            body["deadline"] = deadline

        data = self._http.post("/v1/transactions", body)
        return Transaction.model_validate(data)

    def get(self, transaction_id: str) -> Transaction:
        """Get the details of a specific transaction by ID."""
        data = self._http.get(f"/v1/transactions/{quote(transaction_id, safe='')}")
        return Transaction.model_validate(data)

    def list(
        self,
        type: str | None = None,
        status: str | None = None,
        from_address: str | None = None,
        to_address: str | None = None,
        since: str | None = None,
        until: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Transaction]:
        """List transactions with filtering and pagination."""
        params: dict[str, Any] = {
            "type": type,
            "status": status,
            "from": from_address,
            "to": to_address,
            "since": since,
            "until": until,
            "page": page,
            "limit": limit,
        }

        data = self._http.get("/v1/transactions", params)
        transactions = [Transaction.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Transaction](data=transactions, pagination=pagination)

    def update_status(
        self,
        transaction_id: str,
        status: str,
        reason: str | None = None,
        tx_hash: str | None = None,
    ) -> Transaction:
        """Update the status of a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to update transaction status.")

        body: dict[str, Any] = {
            "status": status,
        }
        if reason is not None:
            body["reason"] = reason
        if tx_hash is not None:
            body["txHash"] = tx_hash

        data = self._http.patch(
            f"/v1/transactions/{quote(transaction_id, safe='')}/status",
            body,
        )
        return Transaction.model_validate(data)

    def submit(
        self,
        transaction_id: str,
        output: str,
        output_hash: str | None = None,
        notes: str | None = None,
    ) -> Transaction:
        """Submit a deliverable for a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to submit a transaction.")

        body: dict[str, Any] = {
            "output": output,
        }
        if output_hash is not None:
            body["outputHash"] = output_hash
        if notes is not None:
            body["notes"] = notes

        data = self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/submit",
            body,
        )
        return Transaction.model_validate(data)

    def dispute(
        self,
        transaction_id: str,
        reason: str,
        evidence: dict[str, Any] | None = None,
        requested_outcome: str | None = None,
    ) -> Dispute:
        """Dispute a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to dispute a transaction.")

        body: dict[str, Any] = {
            "reason": reason,
        }
        if evidence is not None:
            body["evidence"] = evidence
        if requested_outcome is not None:
            body["requestedOutcome"] = requested_outcome

        data = self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/dispute",
            body,
        )
        return Dispute.model_validate(data)

    def resolve_dispute(
        self,
        transaction_id: str,
        resolution: str,
        notes: str | None = None,
        refund_amount: str | None = None,
    ) -> Dispute:
        """Resolve a dispute on a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to resolve a dispute.")

        body: dict[str, Any] = {
            "resolution": resolution,
        }
        if notes is not None:
            body["notes"] = notes
        if refund_amount is not None:
            body["refundAmount"] = refund_amount

        data = self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/dispute/resolve",
            body,
        )
        return Dispute.model_validate(data)

    def rate(
        self,
        transaction_id: str,
        score: int,
        comment: str | None = None,
    ) -> Transaction:
        """Rate a completed transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to rate a transaction.")

        body: dict[str, Any] = {
            "score": score,
        }
        if comment is not None:
            body["comment"] = comment

        data = self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/rate",
            body,
        )
        return Transaction.model_validate(data)

    def get_by_agent(
        self,
        address: str,
        type: str | None = None,
        status: str | None = None,
        since: str | None = None,
        until: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Transaction]:
        """Get all transactions for a specific agent by address."""
        params: dict[str, Any] = {
            "type": type,
            "status": status,
            "since": since,
            "until": until,
            "page": page,
            "limit": limit,
        }

        data = self._http.get(
            f"/v1/transactions/agent/{quote(address, safe='')}",
            params,
        )
        transactions = [Transaction.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Transaction](data=transactions, pagination=pagination)


class AsyncTransactionsClient:
    """Asynchronous client for transaction endpoints."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(
        self,
        from_address: str,
        to_address: str,
        type: str,
        amount: str | None = None,
        token_address: str | None = None,
        metadata: dict[str, Any] | None = None,
        description: str | None = None,
        deadline: str | None = None,
    ) -> Transaction:
        """Create a new transaction. Requires a private key for EIP-712 auth."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to create a transaction.")

        body: dict[str, Any] = {
            "from": from_address,
            "to": to_address,
            "type": type,
        }
        if amount is not None:
            body["amount"] = amount
        if token_address is not None:
            body["tokenAddress"] = token_address
        if metadata is not None:
            body["metadata"] = metadata
        if description is not None:
            body["description"] = description
        if deadline is not None:
            body["deadline"] = deadline

        data = await self._http.post("/v1/transactions", body)
        return Transaction.model_validate(data)

    async def get(self, transaction_id: str) -> Transaction:
        """Get the details of a specific transaction by ID."""
        data = await self._http.get(
            f"/v1/transactions/{quote(transaction_id, safe='')}"
        )
        return Transaction.model_validate(data)

    async def list(
        self,
        type: str | None = None,
        status: str | None = None,
        from_address: str | None = None,
        to_address: str | None = None,
        since: str | None = None,
        until: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Transaction]:
        """List transactions with filtering and pagination."""
        params: dict[str, Any] = {
            "type": type,
            "status": status,
            "from": from_address,
            "to": to_address,
            "since": since,
            "until": until,
            "page": page,
            "limit": limit,
        }

        data = await self._http.get("/v1/transactions", params)
        transactions = [Transaction.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Transaction](data=transactions, pagination=pagination)

    async def update_status(
        self,
        transaction_id: str,
        status: str,
        reason: str | None = None,
        tx_hash: str | None = None,
    ) -> Transaction:
        """Update the status of a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to update transaction status.")

        body: dict[str, Any] = {
            "status": status,
        }
        if reason is not None:
            body["reason"] = reason
        if tx_hash is not None:
            body["txHash"] = tx_hash

        data = await self._http.patch(
            f"/v1/transactions/{quote(transaction_id, safe='')}/status",
            body,
        )
        return Transaction.model_validate(data)

    async def submit(
        self,
        transaction_id: str,
        output: str,
        output_hash: str | None = None,
        notes: str | None = None,
    ) -> Transaction:
        """Submit a deliverable for a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to submit a transaction.")

        body: dict[str, Any] = {
            "output": output,
        }
        if output_hash is not None:
            body["outputHash"] = output_hash
        if notes is not None:
            body["notes"] = notes

        data = await self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/submit",
            body,
        )
        return Transaction.model_validate(data)

    async def dispute(
        self,
        transaction_id: str,
        reason: str,
        evidence: dict[str, Any] | None = None,
        requested_outcome: str | None = None,
    ) -> Dispute:
        """Dispute a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to dispute a transaction.")

        body: dict[str, Any] = {
            "reason": reason,
        }
        if evidence is not None:
            body["evidence"] = evidence
        if requested_outcome is not None:
            body["requestedOutcome"] = requested_outcome

        data = await self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/dispute",
            body,
        )
        return Dispute.model_validate(data)

    async def resolve_dispute(
        self,
        transaction_id: str,
        resolution: str,
        notes: str | None = None,
        refund_amount: str | None = None,
    ) -> Dispute:
        """Resolve a dispute on a transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to resolve a dispute.")

        body: dict[str, Any] = {
            "resolution": resolution,
        }
        if notes is not None:
            body["notes"] = notes
        if refund_amount is not None:
            body["refundAmount"] = refund_amount

        data = await self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/dispute/resolve",
            body,
        )
        return Dispute.model_validate(data)

    async def rate(
        self,
        transaction_id: str,
        score: int,
        comment: str | None = None,
    ) -> Transaction:
        """Rate a completed transaction. Requires a private key."""
        if not self._http.has_signer():
            raise ValueError("A private_key is required to rate a transaction.")

        body: dict[str, Any] = {
            "score": score,
        }
        if comment is not None:
            body["comment"] = comment

        data = await self._http.post(
            f"/v1/transactions/{quote(transaction_id, safe='')}/rate",
            body,
        )
        return Transaction.model_validate(data)

    async def get_by_agent(
        self,
        address: str,
        type: str | None = None,
        status: str | None = None,
        since: str | None = None,
        until: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Transaction]:
        """Get all transactions for a specific agent by address."""
        params: dict[str, Any] = {
            "type": type,
            "status": status,
            "since": since,
            "until": until,
            "page": page,
            "limit": limit,
        }

        data = await self._http.get(
            f"/v1/transactions/agent/{quote(address, safe='')}",
            params,
        )
        transactions = [Transaction.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Transaction](data=transactions, pagination=pagination)
