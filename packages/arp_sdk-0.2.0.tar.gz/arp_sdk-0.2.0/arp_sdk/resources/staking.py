"""
Staking resource clients (sync and async) for stake, unstake,
query position, and leaderboard operations.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..http import HttpClient, AsyncHttpClient
from ..models import StakeInfo


class StakingClient:
    """Synchronous client for staking endpoints."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def stake(
        self,
        amount: str,
        lock_period_days: int | None = None,
        delegate_to: str | None = None,
    ) -> StakeInfo:
        """
        Stake tokens. Requires a private key.
        """
        if not self._http.has_signer():
            raise ValueError("A private_key is required to stake.")

        body: dict[str, Any] = {
            "amount": amount,
        }
        if lock_period_days is not None:
            body["lockPeriodDays"] = lock_period_days
        if delegate_to is not None:
            body["delegateTo"] = delegate_to

        data = self._http.post("/v1/staking/stake", body)
        return StakeInfo.model_validate(data)

    def unstake(
        self,
        amount: str,
        immediate: bool | None = None,
    ) -> StakeInfo:
        """
        Unstake tokens. Requires a private key.
        """
        if not self._http.has_signer():
            raise ValueError("A private_key is required to unstake.")

        body: dict[str, Any] = {
            "amount": amount,
        }
        if immediate is not None:
            body["immediate"] = immediate

        data = self._http.post("/v1/staking/unstake", body)
        return StakeInfo.model_validate(data)

    def get(self, address: str) -> StakeInfo:
        """Get the current staking position for an address."""
        data = self._http.get(f"/v1/staking/{quote(address, safe='')}")
        return StakeInfo.model_validate(data)

    def leaderboard(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """Get the staking leaderboard (top stakers)."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = self._http.get("/v1/staking/leaderboard", params)
        return data


class AsyncStakingClient:
    """Asynchronous client for staking endpoints."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def stake(
        self,
        amount: str,
        lock_period_days: int | None = None,
        delegate_to: str | None = None,
    ) -> StakeInfo:
        """
        Stake tokens. Requires a private key.
        """
        if not self._http.has_signer():
            raise ValueError("A private_key is required to stake.")

        body: dict[str, Any] = {
            "amount": amount,
        }
        if lock_period_days is not None:
            body["lockPeriodDays"] = lock_period_days
        if delegate_to is not None:
            body["delegateTo"] = delegate_to

        data = await self._http.post("/v1/staking/stake", body)
        return StakeInfo.model_validate(data)

    async def unstake(
        self,
        amount: str,
        immediate: bool | None = None,
    ) -> StakeInfo:
        """
        Unstake tokens. Requires a private key.
        """
        if not self._http.has_signer():
            raise ValueError("A private_key is required to unstake.")

        body: dict[str, Any] = {
            "amount": amount,
        }
        if immediate is not None:
            body["immediate"] = immediate

        data = await self._http.post("/v1/staking/unstake", body)
        return StakeInfo.model_validate(data)

    async def get(self, address: str) -> StakeInfo:
        """Get the current staking position for an address."""
        data = await self._http.get(f"/v1/staking/{quote(address, safe='')}")
        return StakeInfo.model_validate(data)

    async def leaderboard(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """Get the staking leaderboard (top stakers)."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }
        data = await self._http.get("/v1/staking/leaderboard", params)
        return data
