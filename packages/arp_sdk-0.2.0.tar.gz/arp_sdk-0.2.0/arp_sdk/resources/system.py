"""
System resource clients (sync and async) for health checks, statistics,
domain info, and Merkle tree data.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..http import HttpClient, AsyncHttpClient
from ..models import (
    HealthStatus,
    DomainInfo,
    MerkleRootInfo,
    MerkleProofResponse,
    PaginatedResponse,
    PaginationInfo,
)


class SystemClient:
    """Synchronous client for system-level endpoints."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def health(self) -> HealthStatus:
        """Check the health status of the ARP API and its dependent services."""
        data = self._http.get("/v1/system/health")
        return HealthStatus.model_validate(data)

    def stats(self) -> dict[str, Any]:
        """
        Get aggregate statistics about the ARP network.
        Returns the raw response dict since the stats structure is nested.
        """
        data = self._http.get("/v1/system/stats")
        return data

    def domains(self) -> list[DomainInfo]:
        """Get a list of all registered domains in the ARP network."""
        data = self._http.get("/v1/system/domains")
        # The API returns a paginated response with data + pagination
        items = data["data"] if isinstance(data, dict) and "data" in data else data
        return [DomainInfo.model_validate(item) for item in items]

    def domain(self, domain_name: str) -> DomainInfo:
        """Get detailed information about a specific domain."""
        data = self._http.get(
            f"/v1/system/domains/{quote(domain_name, safe='')}"
        )
        return DomainInfo.model_validate(data)

    def merkle_root(self) -> MerkleRootInfo:
        """
        Get the latest Merkle root for the reputation tree.
        The Merkle root is posted on-chain periodically and can
        be used to verify reputation attestations.
        """
        data = self._http.get("/v1/system/merkle/root")
        return MerkleRootInfo.model_validate(data)

    def merkle_proof(self, agent_id: str) -> MerkleProofResponse:
        """
        Get a Merkle proof for a specific agent's reputation score.
        This proof can be verified against the on-chain Merkle root.
        """
        data = self._http.get(
            f"/v1/system/merkle/proof/{quote(agent_id, safe='')}"
        )
        return MerkleProofResponse.model_validate(data)


class AsyncSystemClient:
    """Asynchronous client for system-level endpoints."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def health(self) -> HealthStatus:
        """Check the health status of the ARP API and its dependent services."""
        data = await self._http.get("/v1/system/health")
        return HealthStatus.model_validate(data)

    async def stats(self) -> dict[str, Any]:
        """
        Get aggregate statistics about the ARP network.
        Returns the raw response dict since the stats structure is nested.
        """
        data = await self._http.get("/v1/system/stats")
        return data

    async def domains(self) -> list[DomainInfo]:
        """Get a list of all registered domains in the ARP network."""
        data = await self._http.get("/v1/system/domains")
        # The API returns a paginated response with data + pagination
        items = data["data"] if isinstance(data, dict) and "data" in data else data
        return [DomainInfo.model_validate(item) for item in items]

    async def domain(self, domain_name: str) -> DomainInfo:
        """Get detailed information about a specific domain."""
        data = await self._http.get(
            f"/v1/system/domains/{quote(domain_name, safe='')}"
        )
        return DomainInfo.model_validate(data)

    async def merkle_root(self) -> MerkleRootInfo:
        """
        Get the latest Merkle root for the reputation tree.
        The Merkle root is posted on-chain periodically and can
        be used to verify reputation attestations.
        """
        data = await self._http.get("/v1/system/merkle/root")
        return MerkleRootInfo.model_validate(data)

    async def merkle_proof(self, agent_id: str) -> MerkleProofResponse:
        """
        Get a Merkle proof for a specific agent's reputation score.
        This proof can be verified against the on-chain Merkle root.
        """
        data = await self._http.get(
            f"/v1/system/merkle/proof/{quote(agent_id, safe='')}"
        )
        return MerkleProofResponse.model_validate(data)
