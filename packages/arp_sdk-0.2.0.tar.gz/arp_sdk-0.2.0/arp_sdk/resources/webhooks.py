"""
Webhook resource clients (sync and async) for creating, listing,
updating, and deleting webhook subscriptions.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..http import HttpClient, AsyncHttpClient
from ..models import Webhook, PaginatedResponse, PaginationInfo


class WebhooksClient:
    """Synchronous client for webhook endpoints."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(
        self,
        url: str,
        event_types: list[str],
        secret: str | None = None,
    ) -> Webhook:
        """
        Create a new webhook subscription. The specified URL will receive
        POST requests whenever any of the subscribed events occur.
        """
        body: dict[str, Any] = {
            "url": url,
            "events": event_types,
        }
        if secret is not None:
            body["secret"] = secret

        data = self._http.post("/v1/webhooks", body)
        return Webhook.model_validate(data)

    def list(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Webhook]:
        """List all webhook subscriptions with pagination."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }

        data = self._http.get("/v1/webhooks", params)
        webhooks = [Webhook.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Webhook](data=webhooks, pagination=pagination)

    def update(
        self,
        webhook_id: str,
        url: str | None = None,
        event_types: list[str] | None = None,
        is_active: bool | None = None,
    ) -> Webhook:
        """
        Update an existing webhook subscription, including its URL,
        subscribed events, or active status.
        """
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if event_types is not None:
            body["events"] = event_types
        if is_active is not None:
            body["active"] = is_active

        data = self._http.patch(
            f"/v1/webhooks/{quote(webhook_id, safe='')}",
            body,
        )
        return Webhook.model_validate(data)

    def delete(self, webhook_id: str) -> None:
        """Delete a webhook subscription."""
        self._http.delete(
            f"/v1/webhooks/{quote(webhook_id, safe='')}"
        )


class AsyncWebhooksClient:
    """Asynchronous client for webhook endpoints."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(
        self,
        url: str,
        event_types: list[str],
        secret: str | None = None,
    ) -> Webhook:
        """
        Create a new webhook subscription. The specified URL will receive
        POST requests whenever any of the subscribed events occur.
        """
        body: dict[str, Any] = {
            "url": url,
            "events": event_types,
        }
        if secret is not None:
            body["secret"] = secret

        data = await self._http.post("/v1/webhooks", body)
        return Webhook.model_validate(data)

    async def list(
        self,
        page: int | None = None,
        limit: int | None = None,
    ) -> PaginatedResponse[Webhook]:
        """List all webhook subscriptions with pagination."""
        params: dict[str, Any] = {
            "page": page,
            "limit": limit,
        }

        data = await self._http.get("/v1/webhooks", params)
        webhooks = [Webhook.model_validate(item) for item in data["data"]]
        pagination = PaginationInfo.model_validate(data["pagination"])
        return PaginatedResponse[Webhook](data=webhooks, pagination=pagination)

    async def update(
        self,
        webhook_id: str,
        url: str | None = None,
        event_types: list[str] | None = None,
        is_active: bool | None = None,
    ) -> Webhook:
        """
        Update an existing webhook subscription, including its URL,
        subscribed events, or active status.
        """
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if event_types is not None:
            body["events"] = event_types
        if is_active is not None:
            body["active"] = is_active

        data = await self._http.patch(
            f"/v1/webhooks/{quote(webhook_id, safe='')}",
            body,
        )
        return Webhook.model_validate(data)

    async def delete(self, webhook_id: str) -> None:
        """Delete a webhook subscription."""
        await self._http.delete(
            f"/v1/webhooks/{quote(webhook_id, safe='')}"
        )
