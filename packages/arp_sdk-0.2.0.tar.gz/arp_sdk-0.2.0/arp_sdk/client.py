"""
Synchronous client for the Agent Reputation Protocol.

Usage:
    from arp_sdk import ARPClient

    client = ARPClient(
        api_url="https://api.arp.example.com",
        api_key="your-api-key",
    )

    # Read-only operations
    agent = client.agents.get("agent-123")
    score = client.reputation.get("agent-123")

    # Write operations (require private_key)
    client = ARPClient(
        api_url="https://api.arp.example.com",
        api_key="your-api-key",
        private_key="0x...",
    )
    new_agent = client.agents.register(
        name="MyAgent",
        description="An autonomous agent",
    )
"""

from __future__ import annotations

from .http import HttpClient
from .resources.agents import AgentsClient
from .resources.reputation import ReputationClient
from .resources.transactions import TransactionsClient
from .resources.staking import StakingClient
from .resources.guilds import GuildsClient
from .resources.webhooks import WebhooksClient
from .resources.system import SystemClient


class ARPClient:
    """
    Synchronous client for the Agent Reputation Protocol SDK.

    Provides access to all ARP API endpoints through typed sub-clients.
    """

    def __init__(
        self,
        api_url: str,
        api_key: str,
        private_key: str | None = None,
        chain_id: int = 84532,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self._api_url = api_url
        self._api_key = api_key

        self._http = HttpClient(
            base_url=api_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
                "User-Agent": "arp-sdk-py/0.1.0",
            },
            timeout=timeout,
            max_retries=max_retries,
            private_key=private_key,
            chain_id=chain_id,
        )

        self.agents = AgentsClient(self._http)
        self.reputation = ReputationClient(self._http)
        self.transactions = TransactionsClient(self._http)
        self.staking = StakingClient(self._http)
        self.guilds = GuildsClient(self._http)
        self.webhooks = WebhooksClient(self._http)
        self.system = SystemClient(self._http)

    def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        self._http.close()

    def __enter__(self) -> ARPClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
