"""
Pydantic models for ARP SDK request and response data.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Generic, List, Optional, TypeVar

from pydantic import BaseModel, Field


# ──────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────


class AgentStatus(str, Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DEREGISTERED = "deregistered"


class TransactionStatus(str, Enum):
    POSTED = "posted"
    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    SUBMITTED = "submitted"
    VERIFYING = "verifying"
    SETTLED = "settled"
    SLASHED = "slashed"
    DISPUTED = "disputed"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    RESOLVED = "resolved"


class DisputeStatus(str, Enum):
    OPEN = "open"
    UNDER_REVIEW = "under_review"
    RESOLVED_FOR_REQUESTER = "resolved_for_requester"
    RESOLVED_FOR_PROVIDER = "resolved_for_provider"
    DISMISSED = "dismissed"
    EXPIRED = "expired"


class WebhookEvent(str, Enum):
    TRANSACTION_POSTED = "transaction.posted"
    TRANSACTION_ACCEPTED = "transaction.accepted"
    TRANSACTION_IN_PROGRESS = "transaction.in_progress"
    TRANSACTION_SUBMITTED = "transaction.submitted"
    TRANSACTION_VERIFYING = "transaction.verifying"
    TRANSACTION_SETTLED = "transaction.settled"
    TRANSACTION_SLASHED = "transaction.slashed"
    TRANSACTION_DISPUTED = "transaction.disputed"
    TRANSACTION_EXPIRED = "transaction.expired"
    TRANSACTION_CANCELLED = "transaction.cancelled"
    TRANSACTION_RESOLVED = "transaction.resolved"
    VERIFICATION_COMPLETED = "verification.completed"
    VERIFICATION_FAILED = "verification.failed"
    REPUTATION_UPDATED = "reputation.updated"
    AGENT_REGISTERED = "agent.registered"
    AGENT_STATUS_CHANGED = "agent.status_changed"
    AGENT_PROFILE_UPDATED = "agent.profile_updated"
    STAKE_DEPOSITED = "stake.deposited"
    STAKE_WITHDRAWAL_INITIATED = "stake.withdrawal_initiated"
    STAKE_WITHDRAWN = "stake.withdrawn"
    STAKE_SLASHED = "stake.slashed"
    GUILD_CREATED = "guild.created"
    GUILD_MEMBER_JOINED = "guild.member_joined"
    GUILD_MEMBER_REMOVED = "guild.member_removed"
    GUILD_SLASHED = "guild.slashed"
    GUILD_DISSOLVED = "guild.dissolved"
    # Legacy aliases kept for backward compatibility
    TRANSACTION_CREATED = "transaction.created"
    TRANSACTION_COMPLETED = "transaction.completed"
    AGENT_SUSPENDED = "agent.suspended"
    STAKING_DEPOSITED = "staking.deposited"
    STAKING_WITHDRAWN = "staking.withdrawn"


# ──────────────────────────────────────────────
# Common
# ──────────────────────────────────────────────

T = TypeVar("T")


class PaginationInfo(BaseModel):
    page: int
    limit: int
    total: int
    total_pages: int = Field(alias="totalPages")

    model_config = {"populate_by_name": True}


class PaginatedResponse(BaseModel, Generic[T]):
    data: list[T]
    pagination: PaginationInfo


# ──────────────────────────────────────────────
# Agent Models
# ──────────────────────────────────────────────


class Agent(BaseModel):
    id: str
    agent_id: str
    owner_address: str
    registration_uri: Optional[str] = None
    registration_hash: Optional[str] = None
    guild_id: Optional[str] = None
    status: AgentStatus
    on_chain_tx_hash: Optional[str] = None
    composite_score: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = {"populate_by_name": True}


class DomainReputationScore(BaseModel):
    """A single domain reputation entry as returned in agent detail responses."""
    domain: str
    score: str
    confidence: str
    transaction_count: int
    volume_total: str
    last_calculated: Optional[datetime] = None

    model_config = {"populate_by_name": True}


class AgentWithDetails(BaseModel):
    """Agent detail response (GET /v1/agents/:id), includes reputation_scores."""
    id: str
    agent_id: str
    owner_address: str
    registration_uri: Optional[str] = None
    registration_hash: Optional[str] = None
    guild_id: Optional[str] = None
    status: AgentStatus
    on_chain_tx_hash: Optional[str] = None
    composite_score: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    reputation_scores: list[DomainReputationScore] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


# ──────────────────────────────────────────────
# Reputation Models (legacy / standalone endpoints)
# ──────────────────────────────────────────────


class DomainReputation(BaseModel):
    domain: str
    score: float
    transaction_count: int
    success_rate: float
    average_rating: float

    model_config = {"populate_by_name": True}


class ReputationScore(BaseModel):
    agent_id: str
    overall: float
    domains: dict[str, DomainReputation] = Field(default_factory=dict)
    total_transactions: int
    success_rate: float
    last_updated: datetime

    model_config = {"populate_by_name": True}


class StakeInfo(BaseModel):
    agent_id: str
    amount: str
    locked_until: Optional[datetime] = None
    last_deposit_at: Optional[datetime] = None
    last_withdraw_at: Optional[datetime] = None

    model_config = {"populate_by_name": True}


class ReputationSnapshot(BaseModel):
    timestamp: datetime
    overall: float
    domains: dict[str, float] = Field(default_factory=dict)
    transaction_id: Optional[str] = None
    change: float
    reason: str

    model_config = {"populate_by_name": True}


class ReputationHistory(BaseModel):
    agent_id: str
    history: list[ReputationSnapshot]

    model_config = {"populate_by_name": True}


class ReputationAttestation(BaseModel):
    agent_id: str
    score: float
    timestamp: datetime
    merkle_root: str
    merkle_proof: list[str]
    signature: str

    model_config = {"populate_by_name": True}


# ──────────────────────────────────────────────
# Transaction Models
# ──────────────────────────────────────────────


class Transaction(BaseModel):
    id: str
    on_chain_task_id: Optional[str] = None
    requester_agent_id: Optional[str] = None
    provider_agent_id: Optional[str] = None
    task_hash: Optional[str] = None
    output_hash: Optional[str] = None
    payment_amount: Optional[str] = None
    stake_amount: Optional[str] = None
    domain: Optional[str] = None
    deadline: Optional[datetime] = None
    status: TransactionStatus
    quality_score: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    accepted_at: Optional[datetime] = None
    submitted_at: Optional[datetime] = None
    settled_at: Optional[datetime] = None
    on_chain_tx_hash: Optional[str] = None
    requester_address: Optional[str] = None
    provider_address: Optional[str] = None

    model_config = {"populate_by_name": True}


class Dispute(BaseModel):
    id: str
    transaction_id: str
    initiator_id: str
    reason: str
    evidence: Optional[Dict[str, Any]] = None
    status: DisputeStatus
    resolution: Optional[str] = None
    resolved_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    model_config = {"populate_by_name": True}


class TransactionVerification(BaseModel):
    transaction_id: str
    verified: bool
    merkle_proof: list[str]
    merkle_root: str
    block_number: Optional[int] = None
    tx_hash: Optional[str] = None

    model_config = {"populate_by_name": True}


# ──────────────────────────────────────────────
# Staking Models
# ──────────────────────────────────────────────


class StakeCalculation(BaseModel):
    agent_id: str
    current_stake: str
    required_stake: str
    reputation_bonus: float
    effective_reputation: float

    model_config = {"populate_by_name": True}


# ──────────────────────────────────────────────
# Guild Models
# ──────────────────────────────────────────────


class GuildMember(BaseModel):
    agent_id: str
    role: Optional[str] = None
    joined_at: datetime

    model_config = {"populate_by_name": True}


class Guild(BaseModel):
    id: str
    on_chain_guild_id: Optional[str] = None
    name: str
    owner_agent_id: Optional[str] = None
    domain: Optional[str] = None
    min_reputation: Optional[str] = None
    member_count: int = 0
    created_at: datetime
    updated_at: datetime

    model_config = {"populate_by_name": True}


class GuildWithMembers(Guild):
    members: list[GuildMember] = Field(default_factory=list)


class TopMember(BaseModel):
    agent_id: str
    reputation: float
    transaction_count: int

    model_config = {"populate_by_name": True}


class AnalyticsPeriod(BaseModel):
    from_time: datetime = Field(alias="from")
    to_time: datetime = Field(alias="to")

    model_config = {"populate_by_name": True}


class GuildAnalytics(BaseModel):
    guild_id: str
    member_count: int
    average_reputation: float
    total_transactions: int
    total_volume: str
    top_members: list[TopMember]
    period: AnalyticsPeriod

    model_config = {"populate_by_name": True}


class LeaderboardEntry(BaseModel):
    rank: int
    guild_id: str
    name: str
    average_reputation: float
    member_count: int
    total_volume: str

    model_config = {"populate_by_name": True}


class GuildLeaderboard(BaseModel):
    entries: list[LeaderboardEntry]
    updated_at: datetime

    model_config = {"populate_by_name": True}


# ──────────────────────────────────────────────
# Webhook Models
# ──────────────────────────────────────────────


class Webhook(BaseModel):
    id: str
    owner_agent_id: Optional[str] = None
    owner_address: Optional[str] = None
    url: str
    events: list[str] = Field(default_factory=list)
    event_types: list[str] = Field(default_factory=list)
    secret: Optional[str] = None
    secret_hash: Optional[str] = None
    active: bool = True
    is_active: bool = True
    created_at: datetime
    updated_at: datetime

    model_config = {"populate_by_name": True}


# ──────────────────────────────────────────────
# System Models
# ──────────────────────────────────────────────


class ServiceStatus(BaseModel):
    status: str
    latency: Optional[float] = None
    latency_ms: Optional[float] = Field(default=None, alias="latencyMs")
    details: Optional[str] = None

    model_config = {"populate_by_name": True}


class HealthStatus(BaseModel):
    status: str
    version: Optional[str] = None
    uptime: Optional[float] = None
    timestamp: Optional[str] = None
    environment: Optional[str] = None
    services: Optional[dict[str, ServiceStatus]] = None
    checks: Optional[dict[str, ServiceStatus]] = None

    model_config = {"populate_by_name": True}


class SystemStats(BaseModel):
    total_agents: int
    active_agents: Optional[int] = None
    total_transactions: int
    total_volume: str
    total_guilds: Optional[int] = None
    average_reputation: float
    updated_at: Optional[datetime] = None

    model_config = {"populate_by_name": True}


class DomainInfo(BaseModel):
    id: Optional[str] = None
    name: str
    description: str
    agent_count: Optional[int] = None
    transaction_count: Optional[int] = None
    average_reputation: Optional[float] = None

    model_config = {"populate_by_name": True}


class MerkleRootInfo(BaseModel):
    root: str
    block_number: int
    timestamp: datetime
    agent_count: int

    model_config = {"populate_by_name": True}


class MerkleProofResponse(BaseModel):
    agent_id: str
    score: float
    proof: list[str]
    root: str
    leaf: str

    model_config = {"populate_by_name": True}
