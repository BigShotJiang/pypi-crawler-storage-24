"""
ARP SDK - Python SDK for the Agent Reputation Protocol.

Provides both synchronous and asynchronous clients for interacting
with the ARP API.
"""

from .client import ARPClient
from .async_client import AsyncARPClient
from .auth import AUTH_DOMAIN, AUTH_TYPES, sign_auth_message
from .resources.webhooks import WebhooksClient, AsyncWebhooksClient
from .resources.system import SystemClient, AsyncSystemClient
from .errors import (
    ARPError,
    AuthError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    ConflictError,
    ServerError,
    TimeoutError,
)
from .models import (
    Agent,
    AgentStatus,
    AgentWithDetails,
    DomainReputation,
    ReputationScore,
    ReputationHistory,
    ReputationSnapshot,
    ReputationAttestation,
    Transaction,
    TransactionStatus,
    TransactionVerification,
    Dispute,
    DisputeStatus,
    StakeInfo,
    StakeCalculation,
    Guild,
    GuildWithMembers,
    GuildMember,
    GuildAnalytics,
    GuildLeaderboard,
    LeaderboardEntry,
    Webhook,
    WebhookEvent,
    HealthStatus,
    SystemStats,
    DomainInfo,
    MerkleRootInfo,
    MerkleProofResponse,
    PaginatedResponse,
    PaginationInfo,
)

__version__ = "0.1.0"

__all__ = [
    # Clients
    "ARPClient",
    "AsyncARPClient",
    # Auth
    "AUTH_DOMAIN",
    "AUTH_TYPES",
    "sign_auth_message",
    # Resource Clients
    "WebhooksClient",
    "AsyncWebhooksClient",
    "SystemClient",
    "AsyncSystemClient",
    # Errors
    "ARPError",
    "AuthError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ConflictError",
    "ServerError",
    "TimeoutError",
    # Models - Agents
    "Agent",
    "AgentStatus",
    "AgentWithDetails",
    # Models - Reputation
    "DomainReputation",
    "ReputationScore",
    "ReputationHistory",
    "ReputationSnapshot",
    "ReputationAttestation",
    # Models - Transactions
    "Transaction",
    "TransactionStatus",
    "TransactionVerification",
    "Dispute",
    "DisputeStatus",
    # Models - Staking
    "StakeInfo",
    "StakeCalculation",
    # Models - Guilds
    "Guild",
    "GuildWithMembers",
    "GuildMember",
    "GuildAnalytics",
    "GuildLeaderboard",
    "LeaderboardEntry",
    # Models - Webhooks
    "Webhook",
    "WebhookEvent",
    # Models - System
    "HealthStatus",
    "SystemStats",
    "DomainInfo",
    "MerkleRootInfo",
    "MerkleProofResponse",
    # Models - Common
    "PaginatedResponse",
    "PaginationInfo",
]
