"""Tonic Textual PII tools and guardrails for the OpenAI Agents SDK."""

from __future__ import annotations

import json
import os
from typing import Any, Literal

from agents import (
    Agent,
    FunctionTool,
    GuardrailFunctionOutput,
    InputGuardrail,
    OutputGuardrail,
    RunContextWrapper,
    TResponseInputItem,
    function_tool,
    input_guardrail,
    output_guardrail,
)

# ---------------------------------------------------------------------------
# Self-correcting redirect messages (same pattern as LlamaIndex/PydanticAI)
# ---------------------------------------------------------------------------

_TEXT_TOOL_REDIRECT = (
    "Use the redact_text tool for plain text (read file contents first)."
)
_JSON_TOOL_REDIRECT = (
    "Use the redact_json tool for JSON strings (read file contents first)."
)
_HTML_TOOL_REDIRECT = (
    "Use the redact_html tool for HTML content (read file contents first)."
)
_FILE_TOOL_REDIRECT = (
    "Use the redact_file tool for binary files (PDF, JPG, PNG, CSV, TSV)."
)

_SUPPORTED_FILE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf", ".csv", ".tsv"}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _init_client(
    api_key: str | None = None,
    base_url: str | None = None,
) -> Any:
    """Lazily import and initialize the Tonic Textual SDK client."""
    try:
        from tonic_textual.redact_api import TextualNer
    except ImportError as exc:
        raise ImportError(
            "Could not import tonic_textual. Install it with: pip install tonic-textual"
        ) from exc

    resolved_key = api_key or os.environ.get("TONIC_TEXTUAL_API_KEY", "")
    kwargs: dict[str, Any] = {"api_key": resolved_key}
    if base_url:
        kwargs["base_url"] = base_url
    return TextualNer(**kwargs)


def _build_kwargs(
    generator_default: str | None = None,
    generator_config: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Build shared keyword arguments for SDK redaction calls."""
    kwargs: dict[str, Any] = {}
    if generator_default is not None:
        kwargs["generator_default"] = generator_default
    if generator_config:
        kwargs["generator_config"] = generator_config
    return kwargs


def _looks_like_json(text: str) -> bool:
    """Return True if *text* parses as JSON."""
    try:
        json.loads(text)
        return True
    except (json.JSONDecodeError, ValueError):
        return False


def _looks_like_html(text: str) -> bool:
    """Return True if *text* appears to be HTML."""
    stripped = text.strip().lower()
    return stripped.startswith(("<html", "<!doctype", "<head", "<body"))


# ---------------------------------------------------------------------------
# Public API: textual_tools()
# ---------------------------------------------------------------------------


def textual_tools(
    api_key: str | None = None,
    base_url: str | None = None,
    generator_default: Literal["Off", "Redaction", "Synthesis"] | None = None,
    generator_config: dict[str, str] | None = None,
) -> list[FunctionTool]:
    """Return all Tonic Textual PII redaction tools for the OpenAI Agents SDK.

    Creates a pre-configured set of ``FunctionTool`` instances that can be
    passed directly to ``Agent(tools=...)``.

    Args:
        api_key: Tonic Textual API key.  Falls back to the
            ``TONIC_TEXTUAL_API_KEY`` environment variable.
        base_url: Optional base URL for self-hosted Textual deployments.
        generator_default: Default PII handling mode: ``"Off"``,
            ``"Redaction"``, or ``"Synthesis"``.
        generator_config: Per-entity-type overrides mapping a PII type name
            to a handling mode.

    Returns:
        A list of six ``FunctionTool`` instances ready for agent use.
    """
    client = _init_client(api_key=api_key, base_url=base_url)
    redact_kwargs = _build_kwargs(generator_default, generator_config)

    # -- redact_text -------------------------------------------------------

    @function_tool
    def redact_text(text: str) -> str:
        """Redact personally identifiable information from plain text.

        Use this tool for raw text or the contents of .txt files. Do NOT use
        this tool for JSON, HTML, or binary files -- dedicated tools exist for
        those formats.

        Args:
            text: The plain text that may contain PII.

        Returns:
            The text with PII entities redacted or replaced with synthetic
            values, depending on configuration.
        """
        if not text or not text.strip():
            return "Error: input text is empty."
        if _looks_like_json(text):
            return (
                f"Error: input looks like JSON, not plain text. {_JSON_TOOL_REDIRECT}"
            )
        if _looks_like_html(text):
            return (
                f"Error: input looks like HTML, not plain text. {_HTML_TOOL_REDIRECT}"
            )
        try:
            return client.redact(text, **redact_kwargs).redacted_text
        except Exception as exc:
            return f"Error redacting text: {exc}"

    # -- redact_json -------------------------------------------------------

    @function_tool
    def redact_json(json_string: str) -> str:
        """Redact PII from a JSON string, preserving JSON structure.

        The JSON keys are preserved and only PII in values is redacted. Use
        this for JSON strings or the contents of .json files.

        Args:
            json_string: A valid JSON string that may contain PII values.

        Returns:
            The JSON string with PII values redacted.
        """
        if not json_string or not json_string.strip():
            return "Error: input JSON string is empty."
        if not _looks_like_json(json_string):
            return (
                "Error: input is not valid JSON. Provide a valid JSON string. "
                f"If this is plain text, {_TEXT_TOOL_REDIRECT.lower()}"
            )
        try:
            return client.redact_json(json_string, **redact_kwargs).redacted_text
        except Exception as exc:
            return f"Error redacting JSON: {exc}"

    # -- redact_html -------------------------------------------------------

    @function_tool
    def redact_html(html: str) -> str:
        """Redact PII from HTML content, preserving markup structure.

        HTML tags and attributes are preserved while PII in text nodes is
        redacted. Use this for HTML strings or the contents of .html files.

        Args:
            html: An HTML string that may contain PII.

        Returns:
            The HTML with PII entities redacted.
        """
        if not html or not html.strip():
            return "Error: input HTML is empty."
        if _looks_like_json(html):
            return f"Error: input looks like JSON, not HTML. {_JSON_TOOL_REDIRECT}"
        try:
            return client.redact_html(html, **redact_kwargs).redacted_text
        except Exception as exc:
            return f"Error redacting HTML: {exc}"

    # -- redact_file -------------------------------------------------------

    @function_tool
    def redact_file(file_path: str, output_path: str | None = None) -> str:
        """Redact PII from a binary file (PDF, JPG, PNG, CSV, TSV).

        The redacted file is written next to the original with a ``_redacted``
        suffix, unless an explicit *output_path* is provided.

        Do NOT use this for .txt, .json, or .html files -- read their contents
        and use the appropriate text-based redaction tool instead.

        Args:
            file_path: Absolute path to the file to redact.
            output_path: Optional path for the redacted output file.

        Returns:
            The path to the redacted output file, or an error message.
        """
        file_path = os.path.expanduser(file_path)
        _, ext = os.path.splitext(file_path)
        ext_lower = ext.lower()

        # Redirect text-based formats to the correct tool.
        if ext_lower == ".txt":
            return f"Error: .txt files should be read first. {_TEXT_TOOL_REDIRECT}"
        if ext_lower == ".json":
            return f"Error: .json files should be read first. {_JSON_TOOL_REDIRECT}"
        if ext_lower in {".html", ".htm"}:
            return f"Error: .html files should be read first. {_HTML_TOOL_REDIRECT}"
        if ext_lower not in _SUPPORTED_FILE_EXTENSIONS:
            supported = ", ".join(sorted(_SUPPORTED_FILE_EXTENSIONS))
            return (
                f"Error: unsupported file extension '{ext}'. "
                f"Supported extensions: {supported}."
            )

        if not os.path.exists(file_path):
            return f"Error: file not found: {file_path}"

        if output_path is None:
            base, _ = os.path.splitext(file_path)
            output_path = f"{base}_redacted{ext}"
        else:
            output_path = os.path.expanduser(output_path)

        file_name = os.path.basename(file_path)

        try:
            with open(file_path, "rb") as fh:
                job_id = client.start_file_redaction(fh, file_name)

            redacted_bytes = client.download_redacted_file(job_id, **redact_kwargs)

            with open(output_path, "wb") as fh:
                fh.write(redacted_bytes)

            return output_path
        except Exception as exc:
            return f"Error redacting file: {exc}"

    # -- list_pii_types ----------------------------------------------------

    @function_tool
    def list_pii_types() -> str:
        """List all PII entity types that Tonic Textual can detect.

        This is useful for understanding what types of PII can be redacted and
        for configuring per-entity-type handling via generator_config.

        Returns:
            A comma-separated list of all supported PII entity type names.
        """
        from tonic_textual.enums.pii_type import PiiType

        return ", ".join(member.value for member in PiiType)

    # -- extract_entities --------------------------------------------------

    @function_tool
    def extract_entities(text: str) -> str:
        """Extract PII entities from plain text without modifying it.

        Unlike the redaction tools, this tool does not transform the text.
        It returns a JSON array of every PII entity found, including the
        entity type, original text, character offsets, and confidence score.

        Use this when you need to *inspect* what PII is present rather than
        redact it.

        Args:
            text: Plain text to scan for PII entities.

        Returns:
            A JSON array of detected entities, each with ``label``,
            ``text``, ``start``, ``end``, and ``score`` fields.
        """
        if not text or not text.strip():
            return "Error: input text is empty."
        if _looks_like_json(text):
            return (
                "Error: input looks like JSON, not plain text. "
                "Pass plain text to this tool."
            )
        if _looks_like_html(text):
            return (
                "Error: input looks like HTML, not plain text. "
                "Pass plain text to this tool."
            )
        try:
            response = client.redact(text, **redact_kwargs)
            entities = [
                {
                    "label": r.label,
                    "text": r.text,
                    "start": r.start,
                    "end": r.end,
                    "score": r.score,
                }
                for r in response.de_identify_results
            ]
            return json.dumps(entities)
        except Exception as exc:
            return f"Error extracting entities: {exc}"

    return [
        redact_text,
        redact_json,
        redact_html,
        redact_file,
        extract_entities,
        list_pii_types,
    ]


# ---------------------------------------------------------------------------
# Public API: textual_input_guardrail()
# ---------------------------------------------------------------------------


def textual_input_guardrail(
    api_key: str | None = None,
    base_url: str | None = None,
    entities: list[str] | None = None,
    run_in_parallel: bool = False,
) -> InputGuardrail[Any]:
    """Create an input guardrail that detects PII in user input.

    The guardrail scans the user's input for PII using Tonic Textual
    **before** it reaches the agent or the LLM provider.  If PII is detected,
    the tripwire is triggered and the run raises
    ``InputGuardrailTripwireTriggered``.  The ``output_info`` dict on the
    exception contains:

    - ``pii_detected`` (bool): always ``True`` when the tripwire fires
    - ``redacted_text`` (str): the input with PII replaced
    - ``entity_count`` (int): number of PII entities found

    Args:
        api_key: Tonic Textual API key.  Falls back to
            ``TONIC_TEXTUAL_API_KEY``.
        base_url: Optional base URL for self-hosted deployments.
        entities: Optional list of PII type names to filter to.  If set, only
            these entity types trigger the guardrail.
        run_in_parallel: Whether to run alongside the agent (``True``) or
            block until complete (``False``, the default).  Blocking is
            recommended so the agent never starts if PII is detected.

    Returns:
        An ``InputGuardrail`` instance ready for ``Agent(input_guardrails=...)``.
    """
    client = _init_client(api_key=api_key, base_url=base_url)

    @input_guardrail(name="tonic_textual_pii", run_in_parallel=run_in_parallel)
    def _pii_guardrail(
        ctx: RunContextWrapper[Any],
        agent: Agent[Any],
        input: str | list[TResponseInputItem],
    ) -> GuardrailFunctionOutput:
        # Extract plain text from the input.
        if isinstance(input, str):
            text = input
        else:
            # Concatenate text content from message items.
            parts: list[str] = []
            for item in input:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict):
                    content = item.get("content")  # type: ignore[union-attr]
                    if isinstance(content, str):
                        parts.append(content)
            text = " ".join(parts) if parts else ""

        if not text.strip():
            return GuardrailFunctionOutput(
                output_info={"pii_detected": False},
                tripwire_triggered=False,
            )

        result = client.redact(text)

        # Count entities, optionally filtering to requested types.
        detected = result.de_identify_results
        if entities:
            detected = [e for e in detected if e.label in entities]

        if not detected:
            return GuardrailFunctionOutput(
                output_info={"pii_detected": False},
                tripwire_triggered=False,
            )

        return GuardrailFunctionOutput(
            output_info={
                "pii_detected": True,
                "redacted_text": result.redacted_text,
                "entity_count": len(detected),
            },
            tripwire_triggered=True,
        )

    return _pii_guardrail


# ---------------------------------------------------------------------------
# Public API: textual_output_guardrail()
# ---------------------------------------------------------------------------


def textual_output_guardrail(
    api_key: str | None = None,
    base_url: str | None = None,
    entities: list[str] | None = None,
) -> OutputGuardrail[Any]:
    """Create an output guardrail that detects PII in agent output.

    The guardrail scans the agent's **final output** for PII using Tonic
    Textual.  If PII is detected, the tripwire is triggered and the run
    raises ``OutputGuardrailTripwireTriggered``.  The ``output_info`` dict on
    the exception contains:

    - ``pii_detected`` (bool): always ``True`` when the tripwire fires
    - ``redacted_text`` (str): the output with PII replaced
    - ``entity_count`` (int): number of PII entities found

    This is useful as a safety net to ensure the LLM does not leak PII in its
    responses -- for example, if the model hallucinates real-looking personal
    data or echoes back PII from its context window.

    Args:
        api_key: Tonic Textual API key.  Falls back to
            ``TONIC_TEXTUAL_API_KEY``.
        base_url: Optional base URL for self-hosted deployments.
        entities: Optional list of PII type names to filter to.  If set, only
            these entity types trigger the guardrail.

    Returns:
        An ``OutputGuardrail`` instance ready for
        ``Agent(output_guardrails=...)``.
    """
    client = _init_client(api_key=api_key, base_url=base_url)

    @output_guardrail(name="tonic_textual_pii_output")
    def _pii_output_guardrail(
        ctx: RunContextWrapper[Any],
        agent: Agent[Any],
        output: Any,
    ) -> GuardrailFunctionOutput:
        text = str(output)

        if not text.strip():
            return GuardrailFunctionOutput(
                output_info={"pii_detected": False},
                tripwire_triggered=False,
            )

        result = client.redact(text)

        # Count entities, optionally filtering to requested types.
        detected = result.de_identify_results
        if entities:
            detected = [e for e in detected if e.label in entities]

        if not detected:
            return GuardrailFunctionOutput(
                output_info={"pii_detected": False},
                tripwire_triggered=False,
            )

        return GuardrailFunctionOutput(
            output_info={
                "pii_detected": True,
                "redacted_text": result.redacted_text,
                "entity_count": len(detected),
            },
            tripwire_triggered=True,
        )

    return _pii_output_guardrail
