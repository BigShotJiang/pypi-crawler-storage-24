"""Example prediction trackers."""
