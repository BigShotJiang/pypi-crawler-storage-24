from setuptools import setup


setup(
    name="superpitch",
    version="0.1.5",
    description="The AI Agent inbox for investors.",
    packages=["superpitch"],
    py_modules=["cli", "model_a", "policy", "prepare", "train"],
    package_data={
        "superpitch": [
            "assets/data/*.jsonl",
            "assets/models/*.pkl",
        ],
    },
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[
        "numpy",
        "scikit-learn",
    ],
    extras_require={
        "mlx": [
            "mlx",
            "mlx-embedding-models",
        ],
        "embeddings": [
            "sentence-transformers",
        ],
    },
)
