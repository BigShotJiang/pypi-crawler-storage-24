# Superpitch

[![PyPI](https://img.shields.io/pypi/v/superpitch)](https://pypi.org/project/superpitch/)
[![Python](https://img.shields.io/pypi/pyversions/superpitch)](https://pypi.org/project/superpitch/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Be early in. The local AI agent that screens and scores your inbound pitches.

**Free forever to run locally. No account required.**

---

## The idea

Early-stage pitching is about telling a story, not sending a fancy PDF. Superpitch makes that story structured — every pitch scored on the same criteria, so you can move fast without missing the ones that matter.

`superpitch.dev/yourhandle` — a public link founders use to pitch you directly. They fill out a short structured form. Every submission lands in your terminal inbox already scored.

---

## Install

```bash
curl -fsSL https://superpitch.dev/install.sh | bash
```

Or if you already have pipx:

```bash
pipx install superpitch
```

---

## Free vs. cloud

| Feature | Free (local) | Cloud |
|---|---|---|
| Score pitches manually | ✓ | ✓ |
| Import from file or stdin | ✓ | ✓ |
| Local model that learns your taste | ✓ | ✓ |
| Local AI explanations (Ollama) | ✓ | ✓ |
| Your public pitch link (`/yourhandle`) | — | ✓ |
| Auto-sync from web form submissions | — | ✓ |
| Set your thesis (shown to founders) | — | ✓ |
| Email copy to founder + you on submit | — | ✓ |

**The local tool is free forever.** Cloud sync — where founders submit via your public link and pitches appear automatically in your inbox — requires a subscription. 30-day free trial, no card required to start.

---

## What you get

Run `superpitch` and you see your inbox:

```
  Superpitch  Logged in as you@email.com          Last checked: 5 min ago
  ──────────────────────────────────────────────────────────────────────

  Inbox
  ·····································································
  DATE          COMPANY                        STAGE    SCORE   STATUS
  ·····································································

  2026-03-12    No Lies Told                   Pre-seed   6.8      New
  2026-03-12    Rockafeeler                    Pre-seed   5.4   Opened
  2026-03-10    Widget Co                      Seed       7.2  ✓ Approved

  ──────────────────────────────────────────────────────────────────────
  ↑↓ move  ·  ↵ open  ·  a/r/v decide  ·  u add  ·  q quit
```

Each pitch is scored `1–10` with sub-scores for team, traction, market, and risk. Open a pitch with `enter`. Approve, reject, or flag for review with `a / r / v`.

---

## Getting started with cloud sync

Sign in from the terminal:

```
/signin
```

This opens a browser for Google auth, then returns you to the terminal. You'll be prompted to:

1. **Claim a handle** — your public pitch link becomes `superpitch.dev/yourhandle`
2. **Set your thesis** — a short note shown to founders before they submit, so they know what you're looking for

After that, share your link. Every pitch submitted through the form appears in your inbox automatically, pre-scored.

---

## Scoring a file or stdin

```bash
superpitch pitch.txt
cat pitch.txt | superpitch -
```

---

## Commands

Inside the app:

| Key / command | Action |
|---|---|
| `↑ ↓` | Move selection |
| `enter` | Open pitch |
| `a / r / v` | Approve / reject / review |
| `u` | Add a pitch manually |
| `/import <file>` | Import a PDF or text file |
| `/today` | Filter to today's pitches |
| `/all` | Show everything |
| `/signin` | Sign in and set up cloud sync |
| `/signout` | Sign out |
| `/sync` | Fetch new pitches now |
| `/thesis` | Update what founders see on your pitch page |
| `/profile` | Show current profile and settings |
| `/subscription` | Manage billing |
| `/install-local` | Install local AI for score explanations |
| `/upgrade` | Upgrade via pipx |
| `q` | Quit |

---

## How it learns

Every approve, reject, or review you make is saved as feedback. After 20 new labels the local model retrains automatically. The more you use it, the better it gets at matching your judgment.

Opt in to contribute anonymized decisions to the shared base model — improving scoring for everyone over time.

---

## Local AI explanations

`/install-local` sets up Ollama + Qwen3-4B on your machine (~2.5 GB, one-time). After that, every pitch gets a plain-English explanation and three follow-up questions to ask before the call. Entirely optional.

---

## For founders

If an investor sent you their `superpitch.dev/handle` link:

1. Click the link
2. Sign in with Google (keeps spam out)
3. Fill in the form — your company details are saved so future pitches to other investors are pre-filled
4. Submit — you and the investor both get an email copy

No dashboard, no account to manage. Your saved pitch is there whenever you come back.

---

## Local files

Everything lives in `~/.superpitch/`. Override with `SUPERPITCH_HOME`.

- `models/latest.pkl` — current model
- `data/feedback.jsonl` — your corrections
- `data/history.jsonl` — scored pitch history
- `config.json` — preferences and settings

---

## Development

```bash
git clone https://github.com/eyoellundberg/superpitch
cd superpitch
pipx install -e .
```

The product code lives in `cli.py` and the `superpitch/` package. Worker code (Cloudflare) is in the `superpitch.dev` repo.
