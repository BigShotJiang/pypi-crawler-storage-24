import json

def main():
    data = input("Paste JSON: ")
    try:
        json.loads(data)
        print("Valid JSON ✅")
    except:
        print("Invalid JSON ❌")
