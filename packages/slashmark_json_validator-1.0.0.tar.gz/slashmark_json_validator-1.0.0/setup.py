from setuptools import setup

setup(
    name="slashmark-json-validator",
    version="1.0.0",
    py_modules=["sm_json_validator"],
    entry_points={
        "console_scripts": [
            "sm-json=sm_json_validator:main"
        ]
    },
    author="Slash Mark",
    author_email="info@slashmark.in",
    description="Validate JSON from CLI",
    long_description="CLI tool to validate JSON format.",
    long_description_content_type="text/plain",
    url="https://slashmark.in",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
