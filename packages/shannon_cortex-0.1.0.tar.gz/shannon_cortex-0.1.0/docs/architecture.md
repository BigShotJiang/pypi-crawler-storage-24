# Architecture

Shannon-Cortex gives Claude Code persistent long-term memory modeled after the human brain's three memory systems.

## Cognitive Model

| Human Memory | Shannon-Cortex | Examples |
|-------------|---------------|----------|
| **Episodic** | Session events | "On March 18, I debugged a race condition by adding a mutex" |
| **Semantic** | Consolidated facts | "The project uses Redpanda for streaming, QuestDB for time-series" |
| **Procedural** | How-to patterns | "To deploy NIM models: stop container, pull image, clear cache, restart" |

## System Architecture

```
Claude Code (VS Code)
    │
    ├── SessionStart hook ──→ prefetch recent memories
    ├── UserPromptSubmit ──→ search + inject (sync, <150ms)
    ├── PreCompact hook ───→ flush buffered memories
    ├── Stop hook ─────────→ extract + embed + store (async)
    └── SessionEnd hook ───→ generate session summary (async)
            │
            ▼
    Shannon-Cortex Daemon (FastAPI on Unix socket)
    ├── Qwen3-Embedding-0.6B (GPU, 768-dim)
    ├── Qdrant hybrid search (dense + BM25 + RRF)
    ├── NIM reranker (localhost:8000)
    └── Markdown files (source of truth)
```

## Data Flow

### Ingestion (Stop hook, async)
1. Claude Code finishes a response → Stop hook fires
2. Hook reads last portion of transcript
3. Daemon chunks at turn boundaries (100-300 tokens)
4. Importance scoring (1-10) via regex heuristics
5. Chunks scoring ≥3 are embedded and stored in Qdrant + Markdown

### Retrieval (UserPromptSubmit hook, sync <150ms)
1. User sends a prompt → hook fires
2. Daemon embeds the query with instruction prefix
3. Qdrant hybrid search: dense prefetch + BM25 prefetch → RRF fusion (top 50)
4. NIM reranker scores the 50 candidates → top 5
5. Temporal decay scoring adjusts for age and access frequency
6. Top 3 memories formatted and injected as `systemMessage`

### Consolidation (nightly at 2 AM)
1. **Decay**: Archive low-importance, unaccessed, old episodic memories
2. **Reflection**: Cluster related memories by similarity → synthesize into semantic facts via Qwen3-0.6B
3. **Conflict resolution**: Detect contradictions → newer/user-corrections win

## Vector Storage

Collection `shannon_cortex_memories` in Qdrant:
- Dense: 768-dim Cosine (Matryoshka from 1024)
- Sparse: BM25 for keyword matching
- HNSW: M=16, efConstruction=200
- Quantization: INT8 scalar
- Payload indexes: memory_type, importance, created_at, last_accessed, access_count, project, session_id

## Scoring Formula

```
composite = 0.6 × sigmoid(rerank_logit) + 0.3 × normalized_decay + 0.1 × recency_bonus

decay_strength = importance × exp(-λ_eff × days) × (1 + access_count × 0.2)
λ_eff = base_lambda × (1 - importance × 0.08)
```

Half-lives: episodic=30d, semantic=365d, procedural=never.
