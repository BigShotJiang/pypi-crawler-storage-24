# Configuration

Shannon-Cortex loads settings from `~/.shannon-cortex/config.yaml` with environment variable overrides.

## Config File

```yaml
# ~/.shannon-cortex/config.yaml

data_dir: ~/.shannon-cortex
project_scope: true

embedding:
  model_name: Qwen/Qwen3-Embedding-0.6B
  device: cuda        # or "cpu" for systems without GPU
  dimensions: 768     # Matryoshka truncation from 1024
  max_seq_length: 8192
  batch_size: 32

qdrant:
  host: localhost
  port: 6333
  collection_name: shannon_cortex_memories
  prefer_grpc: true
  hnsw_m: 16
  hnsw_ef_construct: 200

reranker:
  enabled: true
  endpoint: http://localhost:8000/v1/ranking
  model_name: nvidia/llama-3.2-nv-rerankqa-1b-v2
  top_k_candidates: 50
  top_k_results: 5
  timeout_ms: 100

decay:
  episodic_half_life_days: 30
  semantic_half_life_days: 365
  procedural_half_life_days: 0  # Never decays

scoring:
  rerank_weight: 0.6
  decay_weight: 0.3
  recency_weight: 0.1
  min_importance_for_storage: 3
  min_importance_for_injection: 5

hooks:
  search_timeout_ms: 150
  max_injected_memories: 3
  max_injection_tokens: 400
  enable_adaptive_gating: true

daemon:
  log_level: INFO
```

## Environment Variables

All settings can be overridden with `SC_` prefixed environment variables using `__` as the nested delimiter:

```bash
export SC_EMBEDDING__DEVICE=cpu
export SC_QDRANT__HOST=192.168.1.100
export SC_RERANKER__ENABLED=false
export SC_DAEMON__LOG_LEVEL=DEBUG
```

## Key Tuning Parameters

| Parameter | Default | Impact |
|-----------|---------|--------|
| `scoring.min_importance_for_injection` | 5 | Higher = fewer, more relevant memories injected |
| `hooks.max_injected_memories` | 3 | More memories = more context but risk saturation |
| `reranker.top_k_candidates` | 50 | More candidates = better reranking but slower |
| `decay.episodic_half_life_days` | 30 | Shorter = faster forgetting of old sessions |
| `hooks.enable_adaptive_gating` | true | Skip search for trivial queries (hi, thanks) |
