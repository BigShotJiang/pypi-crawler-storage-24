# Claude Code Hooks Integration

Shannon-Cortex integrates with Claude Code through its hook lifecycle system. Hooks are shell scripts that communicate with the daemon via Unix domain socket.

## Hook Events

| Event | Timing | Purpose | Latency Budget |
|-------|--------|---------|----------------|
| SessionStart | Sync | Prefetch project memories | <500ms |
| UserPromptSubmit | **Sync** | Search + inject memories | **<150ms** |
| PreCompact | Sync | Flush before context compression | <200ms |
| Stop | **Async** | Extract and store new memories | Unbounded |
| SessionEnd | Async | Generate session summary | Unbounded |

## How It Works

### UserPromptSubmit (Critical Path)

This is the latency-sensitive hook. When the user sends a prompt:

1. Claude Code calls `hooks/user-prompt-submit.sh` with JSON on stdin
2. The script extracts `user_prompt`, `session_id`, and `cwd`
3. Sends a POST to the daemon's `/search` endpoint via Unix socket
4. Daemon: embed query → hybrid search → rerank → format
5. Returns `{"systemMessage": "[Shannon-Cortex Memory]\n- ..."}` on stdout
6. Claude Code prepends the system message to the prompt context

### Stop (Memory Extraction)

After Claude finishes responding:

1. Claude Code calls `hooks/stop.sh` with JSON on stdin (async)
2. Script reads the last 4KB of the transcript
3. Fires-and-forgets to the daemon's `/ingest` endpoint
4. Daemon: chunk → score importance → embed → store in Qdrant + Markdown
5. Script returns `{}` immediately (non-blocking)

## Coexistence with Other Hooks

Claude Code runs matching hooks **in parallel**. Shannon-Cortex hooks coexist with:

- **hookify** (PreToolUse, PostToolUse, Stop, UserPromptSubmit): No conflict — hookify has no active rules
- **security-guidance** (PreToolUse on Edit|Write): No overlap
- **Style plugins** (SessionStart): Both return additionalContext, Claude merges them
- **ralph-loop** (Stop): Both run in parallel with independent concerns

## Graceful Degradation

If the daemon is not running:
- All hooks check for the Unix socket file first
- If socket doesn't exist, return `{}` immediately
- Claude Code continues functioning normally without memory injection
- No errors, no latency impact

## JSON Protocol

### Input (stdin)
```json
{
  "hook_event_name": "UserPromptSubmit",
  "session_id": "abc-123",
  "cwd": "/home/user/project",
  "user_prompt": "How do I fix the search bug?",
  "transcript_path": "/home/user/.claude/projects/.../session.jsonl"
}
```

### Output (stdout)
```json
{
  "hookSpecificOutput": {},
  "systemMessage": "[Shannon-Cortex Memory]\n- [E7] Fixed a similar search bug last week..."
}
```

## Troubleshooting

Check daemon status:
```bash
shannon-cortex status
```

Check daemon logs:
```bash
tail -f ~/.shannon-cortex/logs/shannon-cortex.log
```

Test search manually:
```bash
shannon-cortex search "your query here"
```
