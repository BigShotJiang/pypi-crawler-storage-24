# Installation

## Prerequisites

- Python 3.11+
- CUDA-capable GPU (recommended) or CPU
- Qdrant vector database (v1.12+) running on localhost:6333
- Optional: NVIDIA NIM reranker on localhost:8000

## Quick Install

```bash
git clone https://github.com/shiloh/shannon-cortex.git
cd shannon-cortex
bash scripts/install.sh
```

## Manual Install

```bash
# 1. Create virtual environment
python3 -m venv ~/.venvs/shannon-cortex
source ~/.venvs/shannon-cortex/bin/activate

# 2. Install with all extras
pip install -e ".[all]"

# 3. Create data directories
mkdir -p ~/.shannon-cortex/{memory,semantic,procedural,sessions,logs}

# 4. Set up Qdrant collection
python scripts/setup-qdrant.py

# 5. Install systemd service
mkdir -p ~/.config/systemd/user
cp systemd/shannon-cortex.service ~/.config/systemd/user/
cp systemd/shannon-cortex-consolidate.service ~/.config/systemd/user/
cp systemd/shannon-cortex-consolidate.timer ~/.config/systemd/user/
systemctl --user daemon-reload
```

## Start the Daemon

```bash
# Systemd (recommended)
systemctl --user start shannon-cortex
systemctl --user enable shannon-cortex  # Start on login

# Or foreground
shannon-cortex start -f

# Verify
shannon-cortex status
```

## Register Claude Code Hooks

Add to `~/.claude/settings.json`:

```json
{
  "hooks": {
    "SessionStart": [
      {"type": "command", "command": "/path/to/shannon-cortex/hooks/session-start.sh"}
    ],
    "UserPromptSubmit": [
      {"type": "command", "command": "/path/to/shannon-cortex/hooks/user-prompt-submit.sh"}
    ],
    "PreCompact": [
      {"type": "command", "command": "/path/to/shannon-cortex/hooks/pre-compact.sh"}
    ],
    "Stop": [
      {"type": "command", "command": "/path/to/shannon-cortex/hooks/stop.sh"}
    ],
    "SessionEnd": [
      {"type": "command", "command": "/path/to/shannon-cortex/hooks/session-end.sh"}
    ]
  }
}
```

## Enable Nightly Consolidation

```bash
systemctl --user start shannon-cortex-consolidate.timer
systemctl --user enable shannon-cortex-consolidate.timer
```

## CPU-Only Mode

For systems without a GPU:

```bash
# Set device to CPU
export SC_EMBEDDING__DEVICE=cpu

# Or in config.yaml
echo "embedding:\n  device: cpu" > ~/.shannon-cortex/config.yaml
```

## Disable Reranker

If you don't have NVIDIA NIM:

```bash
export SC_RERANKER__ENABLED=false
```

The system falls back to pure hybrid search (dense + BM25 + RRF) without reranking.
