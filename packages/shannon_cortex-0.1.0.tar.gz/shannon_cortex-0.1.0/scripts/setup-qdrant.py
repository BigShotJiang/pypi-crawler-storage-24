#!/usr/bin/env python3
"""Create the Shannon-Cortex memories collection in Qdrant.

Run this once during installation to set up the vector database collection
with proper schema, indexes, and quantization.

Usage:
    python scripts/setup-qdrant.py [--recreate]
"""

from __future__ import annotations

import argparse
import sys

from qdrant_client import QdrantClient
from qdrant_client.http.exceptions import UnexpectedResponse

from shannon_cortex.config import load_settings
from shannon_cortex.storage.schema import (
    PAYLOAD_INDEXES,
    get_hnsw_config,
    get_quantization_config,
    get_sparse_vectors_config,
    get_vectors_config,
)


def setup_collection(recreate: bool = False) -> None:
    settings = load_settings()
    client = QdrantClient(
        host=settings.qdrant.host,
        port=settings.qdrant.port,
        prefer_grpc=settings.qdrant.prefer_grpc,
    )

    collection_name = settings.qdrant.collection_name

    # Check if collection already exists
    collections = client.get_collections().collections
    exists = any(c.name == collection_name for c in collections)

    if exists and not recreate:
        print(f"Collection '{collection_name}' already exists. Use --recreate to drop and recreate.")
        info = client.get_collection(collection_name)
        print(f"  Points: {info.points_count}")
        print(f"  Vectors: {info.indexed_vectors_count}")
        print(f"  Status: {info.status}")
        return

    if exists and recreate:
        print(f"Dropping existing collection '{collection_name}'...")
        client.delete_collection(collection_name)

    print(f"Creating collection '{collection_name}'...")
    client.create_collection(
        collection_name=collection_name,
        vectors_config=get_vectors_config(settings),
        sparse_vectors_config=get_sparse_vectors_config(),
        hnsw_config=get_hnsw_config(settings),
        quantization_config=get_quantization_config(),
        on_disk_payload=False,
    )

    # Create payload indexes for filtered search during HNSW traversal
    print("Creating payload indexes...")
    for field_name, field_type in PAYLOAD_INDEXES:
        try:
            client.create_payload_index(
                collection_name=collection_name,
                field_name=field_name,
                field_schema=field_type,
            )
            print(f"  Created index: {field_name} ({field_type})")
        except UnexpectedResponse as e:
            print(f"  Warning: Could not create index '{field_name}': {e}")

    # Verify
    info = client.get_collection(collection_name)
    print(f"\nCollection '{collection_name}' created successfully!")
    print(f"  Status: {info.status}")
    print(f"  Vectors config: {info.config.params.vectors}")

    # Verify existing collections are untouched
    print("\nAll Qdrant collections:")
    for c in client.get_collections().collections:
        cinfo = client.get_collection(c.name)
        print(f"  {c.name}: {cinfo.points_count} points, status={cinfo.status}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Set up Shannon-Cortex Qdrant collection")
    parser.add_argument("--recreate", action="store_true", help="Drop and recreate if exists")
    args = parser.parse_args()

    try:
        setup_collection(recreate=args.recreate)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
