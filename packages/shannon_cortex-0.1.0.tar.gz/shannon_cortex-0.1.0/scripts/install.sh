#!/bin/bash
# Shannon-Cortex installation script
#
# Usage:
#   bash scripts/install.sh          # Full install
#   bash scripts/install.sh --cpu    # Force CPU mode (no GPU)
#   bash scripts/install.sh --help   # Show help
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
VENV_DIR="$HOME/.venvs/shannon-cortex"
DATA_DIR="$HOME/.shannon-cortex"
CONFIG_FILE="$DATA_DIR/config.yaml"
CPU_MODE=false

for arg in "$@"; do
    case "$arg" in
        --cpu) CPU_MODE=true ;;
        --help|-h)
            echo "Usage: bash scripts/install.sh [--cpu]"
            echo "  --cpu    Force CPU mode (no CUDA GPU required)"
            exit 0 ;;
    esac
done

echo "=== Shannon-Cortex Installer ==="
echo "Repository: $REPO_DIR"
echo "Venv:       $VENV_DIR"
echo "Data:       $DATA_DIR"
echo ""

# ─── Dependency checks ───────────────────────────────────────────
echo "[0/7] Checking dependencies..."

if ! command -v python3 &>/dev/null; then
    echo "  ERROR: python3 is required. Install with: sudo apt install python3 python3-venv"
    exit 1
fi

PYTHON_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
if python3 -c "import sys; exit(0 if sys.version_info >= (3,11) else 1)"; then
    echo "  Python $PYTHON_VER ✓"
else
    echo "  ERROR: Python 3.11+ required (found $PYTHON_VER)"
    exit 1
fi

if ! command -v jq &>/dev/null; then
    echo "  WARNING: jq not found. Installing..."
    if command -v apt &>/dev/null; then
        sudo apt install -y jq
    elif command -v brew &>/dev/null; then
        brew install jq
    else
        echo "  ERROR: Please install jq manually: https://jqlang.github.io/jq/"
        exit 1
    fi
fi
echo "  jq ✓"

if ! command -v curl &>/dev/null; then
    echo "  ERROR: curl is required. Install with: sudo apt install curl"
    exit 1
fi
echo "  curl ✓"

# Check GPU
if [ "$CPU_MODE" = false ]; then
    if command -v nvidia-smi &>/dev/null && nvidia-smi &>/dev/null; then
        echo "  CUDA GPU detected ✓"
    else
        echo "  No CUDA GPU detected — using CPU mode"
        CPU_MODE=true
    fi
fi

# Check Qdrant
QDRANT_RUNNING=false
if curl -s --max-time 2 http://localhost:6333/collections &>/dev/null; then
    echo "  Qdrant running at localhost:6333 ✓"
    QDRANT_RUNNING=true
else
    echo "  Qdrant not found at localhost:6333"
fi

# Check reranker
RERANKER_AVAILABLE=false
if curl -s --max-time 2 http://localhost:8000/v1/models &>/dev/null; then
    echo "  NIM reranker available at localhost:8000 ✓"
    RERANKER_AVAILABLE=true
else
    echo "  NIM reranker not found (will use hybrid search without reranking)"
fi

echo ""

# ─── Step 1: Create venv ─────────────────────────────────────────
if [ ! -d "$VENV_DIR" ]; then
    echo "[1/7] Creating virtual environment..."
    python3 -m venv "$VENV_DIR"
else
    echo "[1/7] Virtual environment exists."
fi

source "$VENV_DIR/bin/activate"
pip install --upgrade pip wheel setuptools -q

# ─── Step 2: Install package ─────────────────────────────────────
echo "[2/7] Installing shannon-cortex (this downloads ~1.2 GB for the embedding model on first run)..."
cd "$REPO_DIR"
pip install -e ".[dev]" -q

# ─── Step 3: Create data directories ─────────────────────────────
echo "[3/7] Creating data directories..."
mkdir -p "$DATA_DIR"/{memory,semantic,procedural,sessions,logs}

# ─── Step 4: Create config ───────────────────────────────────────
echo "[4/7] Setting up configuration..."
if [ ! -f "$CONFIG_FILE" ]; then
    cp "$REPO_DIR/config.example.yaml" "$CONFIG_FILE"
    # Auto-configure based on detected environment
    if [ "$CPU_MODE" = true ]; then
        sed -i 's/device: cuda/device: cpu/' "$CONFIG_FILE"
    fi
    if [ "$RERANKER_AVAILABLE" = true ]; then
        sed -i 's/enabled: false.*# Set to true/enabled: true         # Set to true/' "$CONFIG_FILE"
    fi
    echo "  Created $CONFIG_FILE (auto-configured for your system)"
else
    echo "  Config exists at $CONFIG_FILE"
fi

# ─── Step 5: Set up Qdrant ───────────────────────────────────────
if [ "$QDRANT_RUNNING" = true ]; then
    echo "[5/7] Setting up Qdrant collection..."
    python scripts/setup-qdrant.py || echo "  Warning: Qdrant setup failed"
else
    echo "[5/7] Skipping Qdrant setup (not running)"
    echo "  Start Qdrant with: docker compose -f $REPO_DIR/docker-compose.yml up -d"
    echo "  Then run: $VENV_DIR/bin/python $REPO_DIR/scripts/setup-qdrant.py"
fi

# ─── Step 6: Install systemd services ────────────────────────────
echo "[6/7] Installing systemd user services..."
if command -v systemctl &>/dev/null && systemctl --user status &>/dev/null 2>&1; then
    mkdir -p "$HOME/.config/systemd/user"
    cp "$REPO_DIR/systemd/shannon-cortex.service" "$HOME/.config/systemd/user/"
    cp "$REPO_DIR/systemd/shannon-cortex-consolidate.service" "$HOME/.config/systemd/user/"
    cp "$REPO_DIR/systemd/shannon-cortex-consolidate.timer" "$HOME/.config/systemd/user/"
    systemctl --user daemon-reload
    echo "  Services installed"
else
    echo "  systemd user services not available (macOS or non-systemd system)"
    echo "  Start daemon manually: shannon-cortex start -f"
fi

# ─── Step 7: Prepare hooks ───────────────────────────────────────
echo "[7/7] Preparing hooks..."
chmod +x "$REPO_DIR/hooks/"*.sh

echo ""
echo "============================================"
echo "  Shannon-Cortex installed successfully!"
echo "============================================"
echo ""
echo "Next steps:"
echo ""
if [ "$QDRANT_RUNNING" = false ]; then
    echo "  1. Start Qdrant:"
    echo "     docker compose -f $REPO_DIR/docker-compose.yml up -d"
    echo "     $VENV_DIR/bin/python $REPO_DIR/scripts/setup-qdrant.py"
    echo ""
fi
echo "  2. Start the daemon:"
echo "     systemctl --user start shannon-cortex"
echo "     systemctl --user enable shannon-cortex    # auto-start on login"
echo ""
echo "  3. Add hooks to Claude Code (~/.claude/settings.json):"
echo "     Add this to the top-level JSON object:"
echo ""
cat <<HOOKS
  "hooks": {
    "SessionStart": [{"hooks": [{"type": "command", "command": "$REPO_DIR/hooks/session-start.sh"}]}],
    "UserPromptSubmit": [{"hooks": [{"type": "command", "command": "$REPO_DIR/hooks/user-prompt-submit.sh"}]}],
    "PreCompact": [{"hooks": [{"type": "command", "command": "$REPO_DIR/hooks/pre-compact.sh"}]}],
    "Stop": [{"hooks": [{"type": "command", "command": "$REPO_DIR/hooks/stop.sh", "async": true}]}],
    "SessionEnd": [{"hooks": [{"type": "command", "command": "$REPO_DIR/hooks/session-end.sh", "async": true}]}]
  }
HOOKS
echo ""
echo "  4. Verify:"
echo "     source $VENV_DIR/bin/activate"
echo "     shannon-cortex status"
echo ""
