#!/bin/bash
# Shannon-Cortex: SessionStart hook
# Loads recent project-scoped memories as additional context.
set -euo pipefail

SOCKET="/run/user/$(id -u)/shannon-cortex.sock"

if [ ! -S "$SOCKET" ]; then
    echo '{}'
    exit 0
fi

INPUT=$(cat -)
CWD=$(echo "$INPUT" | jq -r '.cwd // empty' 2>/dev/null)

# Search for recent high-importance memories for this project
REQUEST=$(jq -nc \
    --arg query "session context project overview" \
    --arg project "$CWD" \
    '{query: $query, project: $project, top_k: 3, min_importance: 6}')

RESULT=$(curl -s --max-time 0.5 --unix-socket "$SOCKET" \
    -X POST http://localhost/search \
    -H "Content-Type: application/json" \
    -d "$REQUEST" 2>/dev/null) || true

if [ -z "$RESULT" ]; then
    echo '{}'
    exit 0
fi

SYS_MSG=$(echo "$RESULT" | jq -r '.system_message // empty' 2>/dev/null)

if [ -n "$SYS_MSG" ] && [ "$SYS_MSG" != "null" ]; then
    jq -nc --arg ctx "$SYS_MSG" '{"hookSpecificOutput": {}, "additionalContext": $ctx}'
else
    echo '{}'
fi
