#!/bin/bash
# Shannon-Cortex: UserPromptSubmit hook
# Searches memory and injects relevant context as systemMessage.
# Critical path: must complete in <150ms.
set -euo pipefail

SOCKET="/run/user/$(id -u)/shannon-cortex.sock"

# Graceful degradation: if daemon not running, return empty
if [ ! -S "$SOCKET" ]; then
    echo '{}'
    exit 0
fi

INPUT=$(cat -)

PROMPT=$(echo "$INPUT" | jq -r '.user_prompt // empty' 2>/dev/null)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // empty' 2>/dev/null)
CWD=$(echo "$INPUT" | jq -r '.cwd // empty' 2>/dev/null)

if [ -z "$PROMPT" ]; then
    echo '{}'
    exit 0
fi

# Build search request (escape special chars in JSON)
REQUEST=$(jq -nc \
    --arg query "$PROMPT" \
    --arg session_id "$SESSION_ID" \
    --arg project "$CWD" \
    '{query: $query, session_id: $session_id, project: $project, top_k: 3}')

# Call daemon with strict timeout
RESULT=$(curl -s --max-time 0.15 --unix-socket "$SOCKET" \
    -X POST http://localhost/search \
    -H "Content-Type: application/json" \
    -d "$REQUEST" 2>/dev/null) || true

if [ -z "$RESULT" ]; then
    echo '{}'
    exit 0
fi

# Extract system message
SYS_MSG=$(echo "$RESULT" | jq -r '.system_message // empty' 2>/dev/null)

if [ -n "$SYS_MSG" ] && [ "$SYS_MSG" != "null" ]; then
    jq -nc --arg msg "$SYS_MSG" '{"hookSpecificOutput": {}, "systemMessage": $msg}'
else
    echo '{}'
fi
