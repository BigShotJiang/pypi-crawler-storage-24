#!/bin/bash
# Shannon-Cortex: Stop hook (async, non-blocking)
# Extracts the last assistant turn and sends it to the daemon for ingestion.
set -euo pipefail

SOCKET="/run/user/$(id -u)/shannon-cortex.sock"

if [ ! -S "$SOCKET" ]; then
    echo '{}'
    exit 0
fi

INPUT=$(cat -)

# Extract relevant fields from the hook payload
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // empty' 2>/dev/null)
CWD=$(echo "$INPUT" | jq -r '.cwd // empty' 2>/dev/null)
TRANSCRIPT_PATH=$(echo "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null)

# Read the last portion of the transcript if available
CONTENT=""
if [ -n "$TRANSCRIPT_PATH" ] && [ -f "$TRANSCRIPT_PATH" ]; then
    # Get the last 4KB of the transcript (roughly last few turns)
    CONTENT=$(tail -c 4096 "$TRANSCRIPT_PATH" 2>/dev/null || true)
fi

if [ -z "$CONTENT" ]; then
    echo '{}'
    exit 0
fi

# Build ingest request
REQUEST=$(jq -nc \
    --arg hook_event "Stop" \
    --arg session_id "$SESSION_ID" \
    --arg cwd "$CWD" \
    --arg content "$CONTENT" \
    --arg transcript_path "$TRANSCRIPT_PATH" \
    '{hook_event: $hook_event, session_id: $session_id, cwd: $cwd, content: $content, transcript_path: $transcript_path}')

# Fire-and-forget (async, no latency constraint)
curl -s --max-time 5 --unix-socket "$SOCKET" \
    -X POST http://localhost/ingest \
    -H "Content-Type: application/json" \
    -d "$REQUEST" > /dev/null 2>&1 &

echo '{}'
