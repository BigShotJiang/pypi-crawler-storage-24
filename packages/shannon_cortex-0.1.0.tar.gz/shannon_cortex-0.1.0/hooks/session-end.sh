#!/bin/bash
# Shannon-Cortex: SessionEnd hook (async)
# Generates a session summary and stores it.
set -euo pipefail

SOCKET="/run/user/$(id -u)/shannon-cortex.sock"

if [ ! -S "$SOCKET" ]; then
    echo '{}'
    exit 0
fi

INPUT=$(cat -)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // empty' 2>/dev/null)
CWD=$(echo "$INPUT" | jq -r '.cwd // empty' 2>/dev/null)
TRANSCRIPT_PATH=$(echo "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null)

# Read transcript summary (last 8KB)
CONTENT=""
if [ -n "$TRANSCRIPT_PATH" ] && [ -f "$TRANSCRIPT_PATH" ]; then
    CONTENT=$(tail -c 8192 "$TRANSCRIPT_PATH" 2>/dev/null || true)
fi

if [ -z "$CONTENT" ]; then
    echo '{}'
    exit 0
fi

REQUEST=$(jq -nc \
    --arg hook_event "SessionEnd" \
    --arg session_id "$SESSION_ID" \
    --arg cwd "$CWD" \
    --arg content "$CONTENT" \
    '{hook_event: $hook_event, session_id: $session_id, cwd: $cwd, content: $content}')

# Fire-and-forget
curl -s --max-time 10 --unix-socket "$SOCKET" \
    -X POST http://localhost/ingest \
    -H "Content-Type: application/json" \
    -d "$REQUEST" > /dev/null 2>&1 &

echo '{}'
