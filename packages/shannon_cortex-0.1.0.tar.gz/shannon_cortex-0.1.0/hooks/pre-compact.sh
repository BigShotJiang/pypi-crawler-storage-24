#!/bin/bash
# Shannon-Cortex: PreCompact hook
# Searches for high-importance session memories and returns them as
# additionalContext so they survive context compression.
set -euo pipefail

SOCKET="/run/user/$(id -u)/shannon-cortex.sock"

if [ ! -S "$SOCKET" ]; then
    echo '{}'
    exit 0
fi

INPUT=$(cat -)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // empty' 2>/dev/null)
CWD=$(echo "$INPUT" | jq -r '.cwd // empty' 2>/dev/null)

if [ -z "$SESSION_ID" ]; then
    echo '{}'
    exit 0
fi

# Search for high-importance memories from this session
REQUEST=$(jq -nc \
    --arg query "session context important decisions preferences" \
    --arg project "$CWD" \
    '{query: $query, project: $project, top_k: 5, min_importance: 7}')

RESULT=$(curl -s --max-time 0.2 --unix-socket "$SOCKET" \
    -X POST http://localhost/search \
    -H "Content-Type: application/json" \
    -d "$REQUEST" 2>/dev/null) || true

if [ -z "$RESULT" ]; then
    echo '{}'
    exit 0
fi

SYS_MSG=$(echo "$RESULT" | jq -r '.system_message // empty' 2>/dev/null)

if [ -n "$SYS_MSG" ] && [ "$SYS_MSG" != "null" ]; then
    jq -nc --arg ctx "$SYS_MSG" '{"hookSpecificOutput": {}, "additionalContext": $ctx}'
else
    echo '{}'
fi
