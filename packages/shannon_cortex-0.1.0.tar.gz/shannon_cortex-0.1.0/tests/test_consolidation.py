"""Tests for the consolidation pipeline components."""

import numpy as np

from shannon_cortex.consolidation.conflict import ConflictType, classify_conflict
from shannon_cortex.consolidation.reflection import cluster_memories


def test_cluster_identical_vectors():
    # 3 identical vectors should form 1 cluster
    v = np.random.randn(768).astype(np.float32)
    v = v / np.linalg.norm(v)
    embeddings = np.stack([v, v, v])
    clusters = cluster_memories(embeddings, threshold=0.99)
    assert len(clusters) == 1
    assert len(clusters[0]) == 3


def test_cluster_orthogonal_vectors():
    # Orthogonal vectors should form separate clusters
    embeddings = np.eye(5, 768, dtype=np.float32)
    clusters = cluster_memories(embeddings, threshold=0.5)
    assert len(clusters) == 5


def test_cluster_empty():
    embeddings = np.array([], dtype=np.float32).reshape(0, 768)
    clusters = cluster_memories(embeddings)
    assert clusters == []


def test_conflict_contradictory():
    ct = classify_conflict(
        "The API uses REST endpoints",
        "The API no longer uses REST, we migrated to gRPC",
        similarity=0.9,
    )
    assert ct == ConflictType.CONTRADICTORY


def test_conflict_supplementary():
    ct = classify_conflict(
        "The project uses FastAPI for the web layer",
        "The project uses FastAPI for the web layer with Pydantic models",
        similarity=0.95,
    )
    assert ct == ConflictType.SUPPLEMENTARY


def test_conflict_compatible():
    ct = classify_conflict(
        "We use PostgreSQL for user data",
        "We use Redis for caching",
        similarity=0.6,
    )
    assert ct == ConflictType.COMPATIBLE


def test_conflict_irrelevant():
    ct = classify_conflict(
        "The build pipeline uses GitHub Actions",
        "User prefers dark mode in VS Code",
        similarity=0.3,
    )
    assert ct == ConflictType.IRRELEVANT
