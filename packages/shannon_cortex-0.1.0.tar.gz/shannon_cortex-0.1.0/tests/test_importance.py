"""Tests for importance scoring."""

from shannon_cortex.extraction.importance import score_importance


def test_trivial_messages():
    assert score_importance("hello") == 1
    assert score_importance("thanks") == 1
    assert score_importance("ok") == 1
    assert score_importance("yes") == 1
    assert score_importance("good morning!") == 1
    assert score_importance("") == 1


def test_user_corrections():
    assert score_importance("actually, use port 8080 not 8081") >= 9
    assert score_importance("no, don't use that library") >= 9
    assert score_importance("instead, use the newer API endpoint") >= 9
    assert score_importance("please fix the import order") >= 9


def test_preferences():
    assert score_importance("I prefer functional style over OOP") >= 8
    assert score_importance("I always use type hints in Python") >= 8
    assert score_importance("never use wildcard imports") >= 8


def test_error_resolution():
    assert score_importance("Error: connection refused when connecting to QuestDB on port 8812") >= 7
    assert score_importance("Fixed the traceback by updating the import path") >= 7
    assert score_importance("The bug was caused by a missing await on the async call") >= 7


def test_architecture_decisions():
    assert score_importance("let's use event sourcing for the order processing module") >= 7
    assert score_importance("we're migrating from REST to gRPC for internal services") >= 7
    assert score_importance("The architecture decision was to use Unix domain sockets") >= 7


def test_deployment_config():
    assert score_importance("The API runs on port 8080 behind nginx") >= 6
    assert score_importance("Deploy the Docker container with --gpus all flag") >= 6


def test_short_content_penalty():
    assert score_importance("hi") == 1
    assert score_importance("test") <= 3


def test_long_content_bonus():
    long_text = "This is a detailed explanation of " + "the architecture " * 50
    score = score_importance(long_text)
    assert score >= 5  # Long content gets a bonus
