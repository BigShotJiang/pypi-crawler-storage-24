"""Tests for Markdown storage."""

from datetime import datetime, timezone

from shannon_cortex.models.memory import EpisodicMemory, MemoryType, SemanticMemory
from shannon_cortex.storage.markdown import MarkdownStorage


def test_append_and_read_episodic(tmp_data_dir):
    storage = MarkdownStorage(tmp_data_dir)

    mem = EpisodicMemory(
        content="Fixed a bug in the search pipeline.",
        importance=7,
        project="/test",
        session_id="s1",
        source="conversation",
    )
    filepath = storage.append(mem)
    assert filepath.exists()
    assert filepath.name.endswith(".md")

    # Read back
    records = storage.read_daily(mem.created_at.date())
    assert len(records) == 1
    assert records[0].content == "Fixed a bug in the search pipeline."
    assert records[0].importance == 7


def test_append_multiple_same_day(tmp_data_dir):
    storage = MarkdownStorage(tmp_data_dir)

    for i in range(3):
        mem = EpisodicMemory(
            content=f"Memory number {i}",
            importance=5 + i,
            project="/test",
        )
        storage.append(mem)

    records = storage.read_daily()
    assert len(records) == 3


def test_semantic_memory_separate_file(tmp_data_dir):
    storage = MarkdownStorage(tmp_data_dir)

    sem = SemanticMemory(
        content="The project uses Qdrant for vector search.",
        importance=8,
        domain="architecture",
    )
    filepath = storage.append(sem)
    assert "semantic" in str(filepath)


def test_read_all(tmp_data_dir):
    storage = MarkdownStorage(tmp_data_dir)

    storage.append(EpisodicMemory(content="Episodic 1", importance=5))
    storage.append(EpisodicMemory(content="Episodic 2", importance=6))
    storage.append(SemanticMemory(content="Semantic 1", importance=7, domain="test"))

    all_records = storage.read_all()
    assert len(all_records) == 3

    episodic_only = storage.read_all(MemoryType.EPISODIC)
    assert len(episodic_only) == 2


def test_daily_files_listing(tmp_data_dir):
    storage = MarkdownStorage(tmp_data_dir)
    storage.append(EpisodicMemory(content="Test", importance=5))

    files = storage.get_daily_files()
    assert len(files) >= 1
