"""Tests for BM25 sparse vector generation."""

from shannon_cortex.embedding.sparse import SparseEncoder


def test_encode_basic():
    enc = SparseEncoder()
    indices, values = enc.encode("hello world test query")
    assert len(indices) > 0
    assert len(values) > 0
    assert len(indices) == len(values)
    assert all(v > 0 for v in values)


def test_encode_empty():
    enc = SparseEncoder()
    indices, values = enc.encode("")
    assert indices == []
    assert values == []


def test_encode_whitespace():
    enc = SparseEncoder()
    indices, values = enc.encode("   ")
    assert indices == []
    assert values == []


def test_encode_deterministic():
    enc = SparseEncoder()
    i1, v1 = enc.encode("fix the qdrant search bug")
    i2, v2 = enc.encode("fix the qdrant search bug")
    assert i1 == i2
    assert v1 == v2


def test_encode_different_texts_differ():
    enc = SparseEncoder()
    i1, _ = enc.encode("python function definition")
    i2, _ = enc.encode("javascript arrow function export")
    assert set(i1) != set(i2)


def test_encode_batch():
    enc = SparseEncoder()
    results = enc.encode_batch(["hello world", "test query", ""])
    assert len(results) == 3
    assert len(results[0][0]) > 0  # hello world has tokens
    assert len(results[1][0]) > 0  # test query has tokens
    assert results[2] == ([], [])  # empty string
