"""Tests for AST-aware code chunking."""

from shannon_cortex.extraction.code_chunker import chunk_code, _get_language, _fallback_chunk


def test_get_language():
    assert _get_language("test.py") == "python"
    assert _get_language("test.js") == "javascript"
    assert _get_language("test.ts") == "typescript"
    assert _get_language("test.sh") == "bash"
    assert _get_language("test.yml") == "yaml"
    assert _get_language("test.txt") is None
    assert _get_language("test.rs") is None


def test_fallback_chunk_basic():
    code = "def hello():\n    print('hello world')\n    return True\n\ndef goodbye():\n    print('bye')\n    return False"
    chunks = _fallback_chunk(code, "test.py", max_tokens=300)
    assert len(chunks) >= 1
    assert all(c.source == "code" for c in chunks)
    assert all("test.py" in c.content for c in chunks)


def test_chunk_code_unsupported():
    chunks = chunk_code("some content", "test.txt")
    assert chunks == []


def test_chunk_code_python_if_treesitter_available():
    """Test Python chunking — skips if tree-sitter not installed."""
    code = '''
def hello():
    print("hello")

def world():
    print("world")

class MyClass:
    def method(self):
        return 42
'''
    chunks = chunk_code(code, "example.py")
    # If tree-sitter is installed, we get AST-aware chunks
    # If not, we get fallback line-based chunks
    # Either way, chunks should exist
    if chunks:
        assert all(c.source == "code" for c in chunks)
        assert any("example.py" in c.content for c in chunks)


def test_fallback_large_file():
    # Generate a large file that needs splitting
    lines = [f"line_{i} = 'content content content content'" for i in range(100)]
    code = "\n".join(lines)
    chunks = _fallback_chunk(code, "big.py", max_tokens=100)
    assert len(chunks) > 1
    for chunk in chunks:
        assert chunk.token_estimate <= 120  # Allow slack
