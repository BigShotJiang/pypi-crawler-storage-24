"""Shared test fixtures for Shannon-Cortex."""

from __future__ import annotations

import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock

import numpy as np
import pytest

from shannon_cortex.config import (
    DecayConfig,
    EmbeddingConfig,
    HookConfig,
    QdrantConfig,
    RerankerConfig,
    ScoringConfig,
    Settings,
)
from shannon_cortex.models.memory import EpisodicMemory, MemoryType, SemanticMemory


@pytest.fixture
def tmp_data_dir(tmp_path):
    """Temporary data directory for tests."""
    for d in ["memory", "semantic", "procedural", "sessions", "logs"]:
        (tmp_path / d).mkdir()
    return tmp_path


@pytest.fixture
def settings(tmp_data_dir):
    """Test settings with temporary data directory."""
    return Settings(
        data_dir=tmp_data_dir,
        embedding=EmbeddingConfig(device="cpu", model_name="Qwen/Qwen3-Embedding-0.6B"),
        qdrant=QdrantConfig(collection_name="test_shannon_cortex"),
        reranker=RerankerConfig(enabled=False),
        scoring=ScoringConfig(),
        hooks=HookConfig(),
        decay=DecayConfig(),
    )


@pytest.fixture
def sample_episodic():
    """Sample episodic memory."""
    return EpisodicMemory(
        content="Fixed a race condition in the WebSocket handler by adding a mutex on the connection map.",
        importance=7,
        project="/home/test/project",
        session_id="session-001",
        source="conversation",
    )


@pytest.fixture
def sample_semantic():
    """Sample semantic memory."""
    return SemanticMemory(
        content="The project uses Redpanda for event streaming and QuestDB for time-series storage.",
        importance=8,
        project="/home/test/project",
        source="reflection",
        domain="architecture",
    )


@pytest.fixture
def mock_embedding():
    """Mock embedding provider that returns random vectors."""
    mock = MagicMock()
    mock.dimensions = 768
    mock.model_name = "test-model"
    mock.device = "cpu"
    mock.embed_single.return_value = np.random.randn(768).astype(np.float32)
    mock.embed.return_value = np.random.randn(5, 768).astype(np.float32)
    return mock
