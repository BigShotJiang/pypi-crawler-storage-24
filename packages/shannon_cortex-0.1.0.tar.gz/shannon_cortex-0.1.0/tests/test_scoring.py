"""Tests for temporal decay and composite scoring."""

from datetime import datetime, timedelta, timezone

from shannon_cortex.config import DecayConfig
from shannon_cortex.models.memory import MemoryType
from shannon_cortex.retrieval.scoring import (
    compute_composite_score,
    compute_decay_strength,
    half_life_to_lambda,
)


def test_half_life_to_lambda():
    # 30-day half-life
    lam = half_life_to_lambda(30.0)
    assert abs(lam - 0.0231) < 0.001

    # Zero half-life = no decay
    assert half_life_to_lambda(0.0) == 0.0


def test_no_decay_at_creation():
    now = datetime.now(timezone.utc)
    strength = compute_decay_strength(
        importance=7,
        created_at=now,
        access_count=0,
        memory_type=MemoryType.EPISODIC,
        now=now,
    )
    # At creation, strength should equal importance
    assert abs(strength - 7.0) < 0.01


def test_episodic_decay_30_days():
    now = datetime.now(timezone.utc)
    created = now - timedelta(days=30)
    strength = compute_decay_strength(
        importance=10,
        created_at=created,
        access_count=0,
        memory_type=MemoryType.EPISODIC,
        now=now,
    )
    # After 30 days (half-life), strength should be reduced
    # But importance weighting slows decay for high-importance memories
    assert 3.0 < strength < 10.0


def test_procedural_never_decays():
    now = datetime.now(timezone.utc)
    created = now - timedelta(days=365)
    strength = compute_decay_strength(
        importance=5,
        created_at=created,
        access_count=0,
        memory_type=MemoryType.PROCEDURAL,
        now=now,
    )
    # Procedural memories never decay
    assert strength == 5.0


def test_access_reinforcement():
    now = datetime.now(timezone.utc)
    created = now - timedelta(days=10)

    strength_no_access = compute_decay_strength(
        importance=5, created_at=created, access_count=0,
        memory_type=MemoryType.EPISODIC, now=now,
    )
    strength_with_access = compute_decay_strength(
        importance=5, created_at=created, access_count=5,
        memory_type=MemoryType.EPISODIC, now=now,
    )
    # More accesses = stronger memory
    assert strength_with_access > strength_no_access


def test_composite_score_range():
    score = compute_composite_score(
        rerank_logit=5.0,
        decay_strength=8.0,
        age_hours=1.0,
    )
    # Base score [0, 1] with up to 15% project boost → max ~1.15
    assert 0.0 <= score <= 1.2

    # Cross-project score should be lower
    score_cross = compute_composite_score(
        rerank_logit=5.0,
        decay_strength=8.0,
        age_hours=1.0,
        same_project=False,
    )
    assert score > score_cross  # Same-project wins tiebreaker


def test_composite_score_recency():
    score_recent = compute_composite_score(rerank_logit=0.0, decay_strength=5.0, age_hours=1.0)
    score_old = compute_composite_score(rerank_logit=0.0, decay_strength=5.0, age_hours=168.0)
    # Recent memories should score higher
    assert score_recent > score_old
