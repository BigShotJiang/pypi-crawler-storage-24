"""Tests for conversation chunking."""

from shannon_cortex.extraction.chunker import chunk_conversation


def test_empty_input():
    assert chunk_conversation("") == []
    assert chunk_conversation("   ") == []


def test_single_chunk():
    text = "I fixed a bug in the authentication module by updating the JWT validation logic. The issue was that the token expiry check was using local time instead of UTC."
    chunks = chunk_conversation(text, max_tokens=300, min_tokens=10)
    assert len(chunks) == 1
    assert chunks[0].source == "conversation"


def test_error_detection():
    text = "Error: connection refused on port 8812. The traceback showed a socket timeout exception in the QuestDB client."
    chunks = chunk_conversation(text, max_tokens=300, min_tokens=10)
    assert len(chunks) == 1
    assert chunks[0].source == "error"


def test_short_chunks_discarded():
    text = "ok"
    chunks = chunk_conversation(text, min_tokens=10)
    assert len(chunks) == 0


def test_large_text_split():
    # Create a text that exceeds max_tokens
    sentences = [f"Sentence number {i} with enough content to be meaningful." for i in range(20)]
    text = " ".join(sentences)
    chunks = chunk_conversation(text, max_tokens=100)
    assert len(chunks) > 1
    for chunk in chunks:
        assert chunk.token_estimate <= 120  # Allow some slack


def test_paragraph_splitting():
    text = """First paragraph about the database schema design with enough content to pass the minimum token threshold for chunking.

Second paragraph about the API endpoint structure and how it connects to the backend services running in Docker containers.

Third paragraph about the deployment pipeline including CI/CD configuration and automated testing in the staging environment."""
    chunks = chunk_conversation(text, max_tokens=300, min_tokens=10)
    assert len(chunks) == 3


def test_trivial_query_detection():
    from shannon_cortex.retrieval.search import _is_trivial_query
    assert _is_trivial_query("hello")
    assert _is_trivial_query("thanks!")
    assert _is_trivial_query("ok")
    assert _is_trivial_query("")
    assert not _is_trivial_query("how do I fix the database connection issue")
    assert not _is_trivial_query("what approach did we use for the API schemas")
