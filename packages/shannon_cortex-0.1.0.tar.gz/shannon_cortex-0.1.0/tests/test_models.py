"""Tests for memory data models."""

from datetime import datetime, timezone

from shannon_cortex.models.memory import (
    EpisodicMemory,
    MemoryType,
    ProceduralMemory,
    SemanticMemory,
)


def test_episodic_defaults():
    mem = EpisodicMemory(content="test", importance=5)
    assert mem.memory_type == MemoryType.EPISODIC
    assert mem.access_count == 0
    assert mem.id  # UUID generated
    assert mem.created_at.tzinfo is not None


def test_semantic_with_provenance():
    mem = SemanticMemory(
        content="fact",
        importance=7,
        provenance=["id1", "id2"],
        domain="architecture",
    )
    assert mem.memory_type == MemoryType.SEMANTIC
    assert len(mem.provenance) == 2
    assert mem.domain == "architecture"


def test_procedural_with_steps():
    mem = ProceduralMemory(
        content="how to deploy",
        importance=8,
        trigger="deploy NIM model",
        steps=["stop container", "pull image", "clear cache", "restart"],
        confidence=0.9,
    )
    assert mem.memory_type == MemoryType.PROCEDURAL
    assert len(mem.steps) == 4
    assert mem.confidence == 0.9


def test_touch_updates_access():
    mem = EpisodicMemory(content="test", importance=5)
    original_time = mem.last_accessed
    assert mem.access_count == 0

    mem.touch()
    assert mem.access_count == 1
    assert mem.last_accessed >= original_time


def test_importance_validation():
    mem = EpisodicMemory(content="test", importance=10)
    assert mem.importance == 10

    try:
        EpisodicMemory(content="test", importance=11)
        assert False, "Should have raised"
    except Exception:
        pass  # Expected: importance must be 1-10
