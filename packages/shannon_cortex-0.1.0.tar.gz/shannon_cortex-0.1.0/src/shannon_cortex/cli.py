"""Shannon-Cortex CLI.

Commands: start, stop, status, search, forget, reindex
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
from pathlib import Path

import httpx
import typer

from shannon_cortex import __version__

app = typer.Typer(name="shannon-cortex", help="Persistent long-term memory for Claude Code")


def _socket_path() -> str:
    uid = os.getuid()
    return f"/run/user/{uid}/shannon-cortex.sock"


def _client(timeout: float = 5.0) -> httpx.Client:
    transport = httpx.HTTPTransport(uds=_socket_path())
    return httpx.Client(transport=transport, base_url="http://localhost", timeout=timeout)


def _is_running() -> bool:
    try:
        with _client(timeout=2.0) as c:
            resp = c.get("/health")
            return resp.status_code == 200
    except Exception:
        return False


def _pid_file() -> Path:
    return Path.home() / ".shannon-cortex" / "daemon.pid"


@app.command()
def start(
    foreground: bool = typer.Option(False, "--foreground", "-f", help="Run in foreground"),
) -> None:
    """Start the Shannon-Cortex daemon."""
    if _is_running():
        typer.echo("Shannon-Cortex daemon is already running.")
        raise typer.Exit(0)

    socket = _socket_path()

    # Remove stale socket file
    if Path(socket).exists():
        Path(socket).unlink()

    if foreground:
        typer.echo(f"Starting Shannon-Cortex v{__version__} (foreground)...")
        typer.echo(f"Socket: {socket}")
        _run_server(socket)
    else:
        typer.echo(f"Starting Shannon-Cortex v{__version__}...")
        # Daemonize
        venv_python = sys.executable
        proc = subprocess.Popen(
            [
                venv_python, "-m", "uvicorn",
                "shannon_cortex.daemon:app",
                "--uds", socket,
                "--log-level", "info",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        # Save PID
        pid_file = _pid_file()
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        pid_file.write_text(str(proc.pid))
        typer.echo(f"Daemon started (PID: {proc.pid}, socket: {socket})")


@app.command()
def stop() -> None:
    """Stop the Shannon-Cortex daemon."""
    pid_file = _pid_file()
    if pid_file.exists():
        pid = int(pid_file.read_text().strip())
        try:
            os.kill(pid, signal.SIGTERM)
            typer.echo(f"Sent SIGTERM to PID {pid}")
            pid_file.unlink()
        except ProcessLookupError:
            typer.echo("Daemon not running (stale PID file).")
            pid_file.unlink()
    else:
        typer.echo("No PID file found. Daemon may not be running.")


@app.command()
def status() -> None:
    """Show daemon status."""
    if not _is_running():
        typer.echo("Shannon-Cortex daemon is not running.")
        raise typer.Exit(1)

    with _client() as c:
        resp = c.get("/status")
        data = resp.json()

    typer.echo(f"Shannon-Cortex v{data.get('version', '?')}")
    typer.echo(f"  Status: {data.get('status', '?')}")
    typer.echo(f"  Uptime: {data.get('uptime_seconds', 0):.0f}s")
    typer.echo(f"  Embedding: {data.get('embedding_model', '?')} ({data.get('embedding_device', '?')})")
    typer.echo(f"  Qdrant: {'connected' if data.get('qdrant_connected') else 'disconnected'}")
    typer.echo(f"  Reranker: {'available' if data.get('reranker_available') else 'unavailable'}")
    typer.echo(f"  Memories: {data.get('collection_size', 0)} total")
    for mtype, count in data.get("memories_by_type", {}).items():
        typer.echo(f"    {mtype}: {count}")


@app.command()
def search(
    query: str = typer.Argument(help="Search query"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Number of results"),
    project: str = typer.Option("", "--project", "-p", help="Filter by project"),
) -> None:
    """Search memories."""
    if not _is_running():
        typer.echo("Shannon-Cortex daemon is not running.", err=True)
        raise typer.Exit(1)

    with _client() as c:
        resp = c.post("/search", json={
            "query": query,
            "top_k": top_k,
            "project": project,
        })
        data = resp.json()

    results = data.get("results", [])
    typer.echo(f"Found {len(results)} results ({data.get('query_time_ms', 0):.1f}ms)")
    for i, r in enumerate(results, 1):
        mem = r["memory"]
        typer.echo(f"\n  [{i}] score={r['score']:.3f} type={mem['memory_type']} importance={mem['importance']}")
        content = mem["content"]
        if len(content) > 200:
            content = content[:197] + "..."
        typer.echo(f"      {content}")


@app.command()
def forget(
    memory_id: str = typer.Argument(help="Memory ID to delete"),
) -> None:
    """Delete a specific memory."""
    typer.echo(f"Deleting memory {memory_id}...")
    # Direct Qdrant deletion
    from shannon_cortex.config import load_settings
    from shannon_cortex.storage.qdrant import QdrantStorage

    settings = load_settings()
    storage = QdrantStorage(settings.qdrant)
    storage.delete(memory_id)
    typer.echo("Memory deleted.")


@app.command()
def reindex() -> None:
    """Rebuild Qdrant index from Markdown files."""
    typer.echo("Rebuilding index from Markdown files...")

    from shannon_cortex.config import load_settings
    from shannon_cortex.embedding.qwen import QwenEmbeddingProvider
    from shannon_cortex.storage.markdown import MarkdownStorage
    from shannon_cortex.storage.qdrant import QdrantStorage

    settings = load_settings()
    embedding = QwenEmbeddingProvider(settings.embedding)
    storage = QdrantStorage(settings.qdrant)
    markdown = MarkdownStorage(settings.data_dir)

    memories = markdown.read_all()
    typer.echo(f"Found {len(memories)} memories in Markdown files")

    if not memories:
        typer.echo("Nothing to index.")
        return

    # Embed in batches
    batch_size = settings.embedding.batch_size
    total_stored = 0

    for i in range(0, len(memories), batch_size):
        batch = memories[i : i + batch_size]
        texts = [m.content for m in batch]
        vectors = embedding.embed(texts)
        storage.upsert_batch(batch, vectors)
        total_stored += len(batch)
        typer.echo(f"  Indexed {total_stored}/{len(memories)}")

    typer.echo(f"Reindex complete: {total_stored} memories indexed")


@app.command()
def consolidate(
    dry_run: bool = typer.Option(False, "--dry-run", help="Report without modifying data"),
    skip_reflection: bool = typer.Option(False, "--skip-reflection", help="Skip LLM reflection step"),
    skip_conflict: bool = typer.Option(False, "--skip-conflict", help="Skip conflict resolution"),
) -> None:
    """Run the consolidation pipeline (decay, reflection, conflict resolution)."""
    import json
    import logging

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    from shannon_cortex.consolidation.pipeline import run_consolidation

    typer.echo("Running consolidation pipeline...")
    result = run_consolidation(
        dry_run=dry_run,
        skip_reflection=skip_reflection,
        skip_conflict=skip_conflict,
    )
    typer.echo(json.dumps(result, indent=2))


def _run_server(socket_path: str) -> None:
    """Run uvicorn server in foreground."""
    import uvicorn

    uvicorn.run(
        "shannon_cortex.daemon:app",
        uds=socket_path,
        log_level="info",
    )


def main() -> None:
    app()
