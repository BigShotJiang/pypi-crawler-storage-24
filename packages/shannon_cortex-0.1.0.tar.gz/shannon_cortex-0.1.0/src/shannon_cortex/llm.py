"""Shared local LLM loader for consolidation, summarization, and fact extraction.

Lazy singleton — loads Qwen3-0.6B on first use, shares across all features.
Used by: atomic fact extraction, ingest summarization, nightly reflection, weekly rollup.
"""

from __future__ import annotations

import logging
from threading import Lock

logger = logging.getLogger(__name__)

_model = None
_tokenizer = None
_lock = Lock()
_device = "cuda"
_model_name = "Qwen/Qwen3-0.6B"


def configure(model_name: str = "Qwen/Qwen3-0.6B", device: str = "cuda") -> None:
    """Configure the shared LLM before first use."""
    global _model_name, _device
    _model_name = model_name
    _device = device


def _load():
    """Load model and tokenizer (thread-safe, lazy)."""
    global _model, _tokenizer
    with _lock:
        if _model is not None:
            return _model, _tokenizer

        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer

            logger.info("Loading shared LLM: %s on %s", _model_name, _device)
            _tokenizer = AutoTokenizer.from_pretrained(_model_name)
            _model = AutoModelForCausalLM.from_pretrained(
                _model_name,
                torch_dtype="auto",
                device_map=_device,
            )
            logger.info("Shared LLM loaded")
            return _model, _tokenizer
        except ImportError:
            logger.warning("transformers not installed. Install: pip install shannon-cortex[consolidation]")
            return None, None
        except Exception as e:
            logger.error("Failed to load LLM: %s", e)
            return None, None


def generate(prompt: str, max_new_tokens: int = 200, temperature: float = 0.7) -> str | None:
    """Generate text from a prompt using the shared LLM.

    Returns None if model unavailable or generation fails.
    """
    model, tokenizer = _load()
    if model is None or tokenizer is None:
        return None

    try:
        import torch

        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=temperature,
                top_p=0.9,
            )

        generated = tokenizer.decode(
            outputs[0][inputs["input_ids"].shape[1]:],
            skip_special_tokens=True,
        ).strip()

        # Clean artifacts
        if generated.startswith('"') and generated.endswith('"'):
            generated = generated[1:-1]

        return generated if len(generated) > 10 else None

    except Exception as e:
        logger.error("LLM generation failed: %s", e)
        return None


def is_available() -> bool:
    """Check if the LLM can be loaded."""
    try:
        from transformers import AutoModelForCausalLM
        return True
    except ImportError:
        return False
