"""Entry point for `python -m shannon_cortex`."""

from shannon_cortex.cli import main

if __name__ == "__main__":
    main()
