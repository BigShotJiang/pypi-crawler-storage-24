"""Core memory data structures.

Three memory types modeled after human long-term memory:
- Episodic: specific events/experiences from development sessions
- Semantic: consolidated facts and knowledge about projects
- Procedural: how-to patterns, workflows, and debugging strategies
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class MemoryType(str, Enum):
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"


class MemoryRecord(BaseModel):
    """Base memory record stored in Qdrant and Markdown."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content: str
    memory_type: MemoryType
    importance: int = Field(ge=1, le=10, default=5)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_accessed: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    access_count: int = 0
    project: str = ""
    session_id: str = ""
    source: str = ""  # "conversation", "tool", "error", "reflection", "user_correction"
    metadata: dict[str, Any] = Field(default_factory=dict)

    def touch(self) -> None:
        """Update access timestamp and increment counter."""
        self.last_accessed = datetime.now(timezone.utc)
        self.access_count += 1


class EpisodicMemory(MemoryRecord):
    """A specific event or experience from a development session.

    Examples: debugging a race condition, resolving a build error,
    making an architectural decision.
    """

    memory_type: MemoryType = MemoryType.EPISODIC
    turn_index: int | None = None  # Position in conversation
    tool_name: str | None = None  # Tool that was used, if any
    error_type: str | None = None  # Error class if this was an error resolution


class SemanticMemory(MemoryRecord):
    """Consolidated knowledge — facts, preferences, patterns.

    Examples: user prefers functional style, project uses event sourcing,
    API lives on port 8080.
    """

    memory_type: MemoryType = MemoryType.SEMANTIC
    provenance: list[str] = Field(default_factory=list)  # IDs of source episodic memories
    domain: str = ""  # Knowledge domain: "architecture", "preferences", "conventions"


class ProceduralMemory(MemoryRecord):
    """How-to knowledge — workflows, debugging strategies, deployment steps.

    Examples: how to deploy NIM models, how to debug WebSocket reconnections,
    project build sequence.
    """

    memory_type: MemoryType = MemoryType.PROCEDURAL
    trigger: str = ""  # Condition that activates this procedure
    steps: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0, default=0.8)
    superseded_by: str | None = None  # ID of newer procedure that replaces this one
