"""API request/response models for the Shannon-Cortex daemon."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from shannon_cortex.models.memory import MemoryRecord, MemoryType


class SearchRequest(BaseModel):
    """Search for relevant memories."""

    query: str
    project: str = ""
    session_id: str = ""
    top_k: int = Field(default=3, ge=1, le=20)
    memory_types: list[MemoryType] | None = None
    min_importance: int = Field(default=0, ge=0, le=10)
    time_range_hours: float | None = None  # Only search memories from last N hours


class SearchResult(BaseModel):
    """A single search result with score."""

    memory: MemoryRecord
    score: float
    rerank_score: float | None = None
    decay_score: float | None = None


class SearchResponse(BaseModel):
    """Search response with formatted injection text."""

    results: list[SearchResult]
    system_message: str = ""  # Formatted for Claude Code hook injection
    query_time_ms: float = 0.0
    total_candidates: int = 0


class IngestRequest(BaseModel):
    """Ingest a new memory from a hook payload."""

    hook_event: str  # "Stop", "SessionEnd", etc.
    session_id: str = ""
    cwd: str = ""
    transcript_path: str = ""
    content: str = ""
    tool_name: str | None = None
    tool_input: dict[str, Any] | None = None
    user_prompt: str | None = None


class IngestResponse(BaseModel):
    """Response after ingesting memories."""

    stored_count: int = 0
    skipped_count: int = 0
    memory_ids: list[str] = Field(default_factory=list)


class StatusResponse(BaseModel):
    """Daemon status information."""

    status: str = "ok"
    version: str = ""
    uptime_seconds: float = 0.0
    collection_size: int = 0
    embedding_model: str = ""
    embedding_device: str = ""
    qdrant_connected: bool = False
    reranker_available: bool = False
    gpu_mode: str = "full"  # "full" or "gaming"
    memories_by_type: dict[str, int] = Field(default_factory=dict)
    last_ingest: datetime | None = None
    last_search: datetime | None = None
