"""Qwen3-Embedding-0.6B provider via sentence-transformers.

Loads the model on GPU (CUDA) by default with Matryoshka truncation to 768 dimensions.
Supports instruction-prefixed asymmetric retrieval for improved search quality.
"""

from __future__ import annotations

import logging

import numpy as np
from sentence_transformers import SentenceTransformer

from shannon_cortex.config import EmbeddingConfig
from shannon_cortex.embedding.base import EmbeddingProvider

logger = logging.getLogger(__name__)


class QwenEmbeddingProvider(EmbeddingProvider):
    """Qwen3-Embedding-0.6B embedding provider."""

    def __init__(self, config: EmbeddingConfig | None = None) -> None:
        self._config = config or EmbeddingConfig()
        self._model: SentenceTransformer | None = None

    def _load_model(self) -> SentenceTransformer:
        if self._model is None:
            logger.info(
                "Loading embedding model %s on %s (dims=%d)",
                self._config.model_name,
                self._config.device,
                self._config.dimensions,
            )
            self._model = SentenceTransformer(
                self._config.model_name,
                device=self._config.device,
                truncate_dim=self._config.dimensions,
            )
            if self._config.max_seq_length:
                self._model.max_seq_length = self._config.max_seq_length
            logger.info("Embedding model loaded successfully")
        return self._model

    def embed(self, texts: list[str], is_query: bool = False) -> np.ndarray:
        model = self._load_model()
        if is_query and self._config.instruction_prefix:
            texts = [self._config.instruction_prefix + t for t in texts]
        embeddings = model.encode(
            texts,
            batch_size=self._config.batch_size,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return np.asarray(embeddings, dtype=np.float32)

    def embed_single(self, text: str, is_query: bool = False) -> np.ndarray:
        return self.embed([text], is_query=is_query)[0]

    @property
    def dimensions(self) -> int:
        return self._config.dimensions

    @property
    def model_name(self) -> str:
        return self._config.model_name

    @property
    def device(self) -> str:
        return self._config.device

    def warmup(self) -> None:
        """Pre-load the model and run a dummy embedding to warm GPU caches."""
        self.embed_single("warmup", is_query=True)
        logger.info("Embedding model warmed up")
