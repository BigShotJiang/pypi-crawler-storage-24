"""Embedding providers for Shannon-Cortex."""
