"""Abstract embedding provider interface."""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np


class EmbeddingProvider(ABC):
    """Base class for embedding providers."""

    @abstractmethod
    def embed(self, texts: list[str], is_query: bool = False) -> np.ndarray:
        """Embed a batch of texts.

        Args:
            texts: List of text strings to embed.
            is_query: If True, prepend query instruction prefix (asymmetric retrieval).

        Returns:
            numpy array of shape (len(texts), dimensions).
        """
        ...

    @abstractmethod
    def embed_single(self, text: str, is_query: bool = False) -> np.ndarray:
        """Embed a single text string.

        Args:
            text: Text to embed.
            is_query: If True, prepend query instruction prefix.

        Returns:
            numpy array of shape (dimensions,).
        """
        ...

    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Output embedding dimensions."""
        ...

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Model identifier."""
        ...

    @property
    @abstractmethod
    def device(self) -> str:
        """Device the model is loaded on (cuda, cpu)."""
        ...
