"""BM25-compatible sparse vector generation for hybrid search.

Uses sklearn's HashingVectorizer to generate sparse term-frequency vectors.
No vocabulary to maintain — works from the first document via feature hashing.
Qdrant applies IDF weighting server-side during sparse search.
"""

from __future__ import annotations

import re

from sklearn.feature_extraction.text import HashingVectorizer


class SparseEncoder:
    """Generates sparse vectors for BM25-style keyword matching in Qdrant."""

    def __init__(self, n_features: int = 2**16) -> None:
        self._vectorizer = HashingVectorizer(
            n_features=n_features,
            alternate_sign=False,
            norm=None,
            lowercase=True,
            token_pattern=r"(?u)\b\w+\b",
        )

    def encode(self, text: str) -> tuple[list[int], list[float]]:
        """Encode text into sparse vector (indices, values).

        Returns:
            Tuple of (indices, values) for Qdrant SparseVector.
            Returns empty lists if text produces no tokens.
        """
        if not text or not text.strip():
            return [], []

        sparse_matrix = self._vectorizer.transform([text])
        coo = sparse_matrix.tocoo()

        if coo.nnz == 0:
            return [], []

        return coo.col.tolist(), coo.data.tolist()

    def encode_batch(self, texts: list[str]) -> list[tuple[list[int], list[float]]]:
        """Encode multiple texts into sparse vectors."""
        results = []
        sparse_matrix = self._vectorizer.transform(texts)

        for i in range(len(texts)):
            row = sparse_matrix.getrow(i).tocoo()
            if row.nnz == 0:
                results.append(([], []))
            else:
                results.append((row.col.tolist(), row.data.tolist()))

        return results
