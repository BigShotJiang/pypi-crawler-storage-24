"""Qdrant collection schema definitions."""

from __future__ import annotations

from qdrant_client.models import (
    Distance,
    HnswConfigDiff,
    PayloadSchemaType,
    ScalarQuantization,
    ScalarQuantizationConfig,
    ScalarType,
    SparseIndexParams,
    SparseVectorParams,
    VectorParams,
)

from shannon_cortex.config import Settings

# Payload field index definitions
PAYLOAD_INDEXES: list[tuple[str, PayloadSchemaType]] = [
    ("memory_type", PayloadSchemaType.KEYWORD),
    ("importance", PayloadSchemaType.INTEGER),
    ("created_at", PayloadSchemaType.DATETIME),
    ("last_accessed", PayloadSchemaType.DATETIME),
    ("access_count", PayloadSchemaType.INTEGER),
    ("project", PayloadSchemaType.KEYWORD),
    ("session_id", PayloadSchemaType.KEYWORD),
    ("source", PayloadSchemaType.KEYWORD),
    ("embedding_model", PayloadSchemaType.KEYWORD),
]


def get_vectors_config(settings: Settings) -> dict[str, VectorParams]:
    return {
        "dense": VectorParams(
            size=settings.embedding.dimensions,
            distance=Distance.COSINE,
        ),
    }


def get_sparse_vectors_config() -> dict[str, SparseVectorParams]:
    return {
        "bm25": SparseVectorParams(
            index=SparseIndexParams(),
            modifier=None,  # Qdrant applies IDF by default with built-in tokenizer
        ),
    }


def get_hnsw_config(settings: Settings) -> HnswConfigDiff:
    return HnswConfigDiff(
        m=settings.qdrant.hnsw_m,
        ef_construct=settings.qdrant.hnsw_ef_construct,
    )


def get_quantization_config() -> ScalarQuantization:
    return ScalarQuantization(
        scalar=ScalarQuantizationConfig(
            type=ScalarType.INT8,
            always_ram=True,
        ),
    )
