"""Qdrant vector storage for Shannon-Cortex memories.

Handles all vector DB operations: upsert, hybrid search (dense + BM25 + RRF),
filtered queries, and collection management. Completely isolated from any
existing Qdrant collections.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import numpy as np
from qdrant_client import QdrantClient
from qdrant_client.models import (
    DatetimeRange,
    FieldCondition,
    Filter,
    FusionQuery,
    MatchValue,
    PointStruct,
    Prefetch,
    Range,
    ScoredPoint,
    SparseVector,
)

from shannon_cortex.config import QdrantConfig
from shannon_cortex.models.memory import MemoryRecord, MemoryType

logger = logging.getLogger(__name__)


class QdrantStorage:
    """Qdrant vector storage backend."""

    def __init__(self, config: QdrantConfig | None = None) -> None:
        self._config = config or QdrantConfig()
        self._client: QdrantClient | None = None

    @property
    def client(self) -> QdrantClient:
        if self._client is None:
            self._client = QdrantClient(
                host=self._config.host,
                port=self._config.port,
                prefer_grpc=self._config.prefer_grpc,
            )
        return self._client

    @property
    def collection_name(self) -> str:
        return self._config.collection_name

    def is_connected(self) -> bool:
        try:
            self.client.get_collections()
            return True
        except Exception:
            return False

    def collection_exists(self) -> bool:
        collections = self.client.get_collections().collections
        return any(c.name == self.collection_name for c in collections)

    def count(self) -> int:
        if not self.collection_exists():
            return 0
        info = self.client.get_collection(self.collection_name)
        return info.points_count or 0

    def count_by_type(self) -> dict[str, int]:
        counts = {}
        for mt in MemoryType:
            result = self.client.count(
                collection_name=self.collection_name,
                count_filter=Filter(
                    must=[FieldCondition(key="memory_type", match=MatchValue(value=mt.value))]
                ),
            )
            counts[mt.value] = result.count
        return counts

    def upsert(
        self,
        memory: MemoryRecord,
        dense_vector: np.ndarray,
        sparse_indices: list[int] | None = None,
        sparse_values: list[float] | None = None,
        embedding_model: str = "",
    ) -> None:
        """Store a memory with its dense and optional sparse vectors."""
        vectors: dict[str, Any] = {
            "dense": dense_vector.tolist(),
        }
        if sparse_indices is not None and sparse_values is not None:
            vectors["bm25"] = SparseVector(
                indices=sparse_indices,
                values=sparse_values,
            )

        payload = {
            "content": memory.content,
            "memory_type": memory.memory_type.value,
            "importance": memory.importance,
            "created_at": memory.created_at.isoformat(),
            "last_accessed": memory.last_accessed.isoformat(),
            "access_count": memory.access_count,
            "project": memory.project,
            "session_id": memory.session_id,
            "source": memory.source,
            "metadata": memory.metadata,
            "embedding_model": embedding_model,
        }

        point = PointStruct(
            id=memory.id,
            vector=vectors,
            payload=payload,
        )

        self.client.upsert(
            collection_name=self.collection_name,
            points=[point],
        )
        logger.debug("Upserted memory %s (type=%s, importance=%d)", memory.id, memory.memory_type.value, memory.importance)

    def upsert_batch(
        self,
        memories: list[MemoryRecord],
        dense_vectors: np.ndarray,
        sparse_data: list[tuple[list[int], list[float]] | None] | None = None,
    ) -> None:
        """Batch upsert multiple memories."""
        points = []
        for i, memory in enumerate(memories):
            vectors: dict[str, Any] = {
                "dense": dense_vectors[i].tolist(),
            }
            if sparse_data and sparse_data[i] is not None:
                indices, values = sparse_data[i]
                vectors["bm25"] = SparseVector(indices=indices, values=values)

            payload = {
                "content": memory.content,
                "memory_type": memory.memory_type.value,
                "importance": memory.importance,
                "created_at": memory.created_at.isoformat(),
                "last_accessed": memory.last_accessed.isoformat(),
                "access_count": memory.access_count,
                "project": memory.project,
                "session_id": memory.session_id,
                "source": memory.source,
                "metadata": memory.metadata,
            }

            points.append(PointStruct(id=memory.id, vector=vectors, payload=payload))

        self.client.upsert(
            collection_name=self.collection_name,
            points=points,
        )
        logger.info("Batch upserted %d memories", len(points))

    def hybrid_search(
        self,
        dense_vector: np.ndarray,
        sparse_indices: list[int] | None = None,
        sparse_values: list[float] | None = None,
        top_k: int = 50,
        memory_types: list[MemoryType] | None = None,
        min_importance: int = 0,
        project: str | None = None,
        time_range_hours: float | None = None,
    ) -> list[ScoredPoint]:
        """Hybrid search: dense prefetch + sparse prefetch → RRF fusion.

        Returns top_k candidates for downstream re-ranking.
        """
        # Build filter conditions
        conditions = []
        if memory_types:
            for mt in memory_types:
                conditions.append(
                    FieldCondition(key="memory_type", match=MatchValue(value=mt.value))
                )
        if min_importance > 0:
            conditions.append(
                FieldCondition(key="importance", range=Range(gte=min_importance))
            )
        if project:
            conditions.append(
                FieldCondition(key="project", match=MatchValue(value=project))
            )
        if time_range_hours:
            cutoff = datetime.now(timezone.utc).isoformat()
            conditions.append(
                FieldCondition(
                    key="created_at",
                    range=DatetimeRange(gte=cutoff),
                )
            )

        query_filter = Filter(must=conditions) if conditions else None

        # Build prefetch stages — use raw vector lists for Prefetch query
        prefetches = [
            Prefetch(
                query=dense_vector.tolist(),
                using="dense",
                limit=top_k,
                filter=query_filter,
            ),
        ]

        if sparse_indices is not None and sparse_values is not None:
            prefetches.append(
                Prefetch(
                    query=SparseVector(indices=sparse_indices, values=sparse_values),
                    using="bm25",
                    limit=top_k,
                    filter=query_filter,
                ),
            )

        # RRF fusion of dense + sparse results
        results = self.client.query_points(
            collection_name=self.collection_name,
            prefetch=prefetches,
            query=FusionQuery(fusion="rrf"),
            limit=top_k,
            with_payload=True,
        )

        return results.points

    def dense_search(
        self,
        dense_vector: np.ndarray,
        top_k: int = 50,
        query_filter: Filter | None = None,
    ) -> list[ScoredPoint]:
        """Pure dense vector search (fallback when no sparse vectors available)."""
        results = self.client.query_points(
            collection_name=self.collection_name,
            query=dense_vector.tolist(),
            using="dense",
            limit=top_k,
            query_filter=query_filter,
            with_payload=True,
        )
        return results.points

    def update_access(self, memory_id: str) -> None:
        """Update last_accessed timestamp and increment access_count."""
        self.client.set_payload(
            collection_name=self.collection_name,
            payload={
                "last_accessed": datetime.now(timezone.utc).isoformat(),
            },
            points=[memory_id],
        )
        # Increment access count — need to read first
        points = self.client.retrieve(
            collection_name=self.collection_name,
            ids=[memory_id],
            with_payload=["access_count"],
        )
        if points:
            current = points[0].payload.get("access_count", 0)
            self.client.set_payload(
                collection_name=self.collection_name,
                payload={"access_count": current + 1},
                points=[memory_id],
            )

    def delete(self, memory_id: str) -> None:
        """Delete a memory by ID."""
        self.client.delete(
            collection_name=self.collection_name,
            points_selector=[memory_id],
        )
        logger.info("Deleted memory %s", memory_id)

    def get_all_ids(self) -> list[str]:
        """Get all memory IDs in the collection."""
        ids = []
        offset = None
        while True:
            result = self.client.scroll(
                collection_name=self.collection_name,
                limit=100,
                offset=offset,
                with_payload=False,
                with_vectors=False,
            )
            points, next_offset = result
            ids.extend(str(p.id) for p in points)
            if next_offset is None:
                break
            offset = next_offset
        return ids
