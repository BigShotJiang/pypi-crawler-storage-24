"""Markdown file storage — the source of truth for all memories.

Every memory is written to a daily Markdown file in ~/.shannon-cortex/memory/.
The Qdrant index is a derived cache that can be rebuilt from these files at any time.
Format follows the memsearch pattern: daily files with HTML comment metadata.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import date, datetime, timezone
from pathlib import Path

from shannon_cortex.models.memory import (
    EpisodicMemory,
    MemoryRecord,
    MemoryType,
    ProceduralMemory,
    SemanticMemory,
)

logger = logging.getLogger(__name__)

# Regex to parse memory entries from Markdown files
MEMORY_BLOCK_RE = re.compile(
    r"<!--\s*memory:\s*({.*?})\s*-->\n(.*?)(?=\n<!--\s*memory:|$)",
    re.DOTALL,
)


def _daily_filename(dt: date | None = None) -> str:
    if dt is None:
        dt = datetime.now(timezone.utc).date()
    return f"{dt.isoformat()}.md"


def _memory_type_dir(memory_type: MemoryType) -> str:
    if memory_type == MemoryType.SEMANTIC:
        return "semantic"
    elif memory_type == MemoryType.PROCEDURAL:
        return "procedural"
    return "memory"


class MarkdownStorage:
    """Markdown file storage backend."""

    def __init__(self, base_dir: Path) -> None:
        self._base_dir = base_dir
        self._memory_dir = base_dir / "memory"
        self._semantic_dir = base_dir / "semantic"
        self._procedural_dir = base_dir / "procedural"
        for d in [self._memory_dir, self._semantic_dir, self._procedural_dir]:
            d.mkdir(parents=True, exist_ok=True)

    def _get_dir(self, memory_type: MemoryType) -> Path:
        if memory_type == MemoryType.SEMANTIC:
            return self._semantic_dir
        elif memory_type == MemoryType.PROCEDURAL:
            return self._procedural_dir
        return self._memory_dir

    def append(self, memory: MemoryRecord) -> Path:
        """Append a memory entry to the appropriate Markdown file.

        Episodic memories go to daily files (YYYY-MM-DD.md).
        Semantic/procedural go to their own directories with descriptive names.
        """
        target_dir = self._get_dir(memory.memory_type)

        if memory.memory_type == MemoryType.EPISODIC:
            filename = _daily_filename(memory.created_at.date())
            filepath = target_dir / filename
        else:
            # Use memory ID as filename for semantic/procedural
            safe_id = memory.id.replace("/", "_")[:50]
            filename = f"{safe_id}.md"
            filepath = target_dir / filename

        # Build metadata block
        meta = {
            "id": memory.id,
            "type": memory.memory_type.value,
            "importance": memory.importance,
            "created_at": memory.created_at.isoformat(),
            "project": memory.project,
            "session_id": memory.session_id,
            "source": memory.source,
        }

        # Write entry
        entry = f"\n<!-- memory: {json.dumps(meta)} -->\n{memory.content}\n"

        if filepath.exists() and memory.memory_type == MemoryType.EPISODIC:
            with open(filepath, "a") as f:
                f.write(entry)
        else:
            header = ""
            if memory.memory_type == MemoryType.EPISODIC:
                header = f"# Memories — {memory.created_at.date().isoformat()}\n"
            elif memory.memory_type == MemoryType.SEMANTIC:
                header = f"# Semantic Memory\n"
            elif memory.memory_type == MemoryType.PROCEDURAL:
                header = f"# Procedural Memory\n"
            with open(filepath, "w") as f:
                f.write(header + entry)

        logger.debug("Wrote memory %s to %s", memory.id, filepath)
        return filepath

    def read_daily(self, dt: date | None = None) -> list[MemoryRecord]:
        """Read all memories from a daily file."""
        filename = _daily_filename(dt)
        filepath = self._memory_dir / filename
        if not filepath.exists():
            return []
        return self._parse_file(filepath)

    def read_all(self, memory_type: MemoryType | None = None) -> list[MemoryRecord]:
        """Read all memories of a given type (or all types)."""
        records = []
        dirs = []
        if memory_type is None:
            dirs = [self._memory_dir, self._semantic_dir, self._procedural_dir]
        else:
            dirs = [self._get_dir(memory_type)]

        for d in dirs:
            for filepath in sorted(d.glob("*.md")):
                records.extend(self._parse_file(filepath))
        return records

    def _parse_file(self, filepath: Path) -> list[MemoryRecord]:
        """Parse memory entries from a Markdown file."""
        content = filepath.read_text()
        records = []

        for match in MEMORY_BLOCK_RE.finditer(content):
            try:
                meta = json.loads(match.group(1))
                text = match.group(2).strip()
                memory_type = MemoryType(meta.get("type", "episodic"))

                record = MemoryRecord(
                    id=meta.get("id", ""),
                    content=text,
                    memory_type=memory_type,
                    importance=meta.get("importance", 5),
                    created_at=datetime.fromisoformat(meta["created_at"]) if "created_at" in meta else datetime.now(timezone.utc),
                    project=meta.get("project", ""),
                    session_id=meta.get("session_id", ""),
                    source=meta.get("source", ""),
                )
                records.append(record)
            except (json.JSONDecodeError, KeyError, ValueError) as e:
                logger.warning("Failed to parse memory entry in %s: %s", filepath, e)
                continue

        return records

    def get_daily_files(self) -> list[Path]:
        """List all daily memory files sorted by date."""
        return sorted(self._memory_dir.glob("????-??-??.md"))
