"""Configuration management for Shannon-Cortex.

Loads settings from ~/.shannon-cortex/config.yaml with environment variable overrides.
All SC_ prefixed env vars override the corresponding YAML keys.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Literal

import yaml
from pydantic import Field
from pydantic_settings import BaseSettings


def _default_data_dir() -> Path:
    return Path.home() / ".shannon-cortex"


def _default_socket_path() -> Path:
    uid = os.getuid()
    return Path(f"/run/user/{uid}/shannon-cortex.sock")


class EmbeddingConfig(BaseSettings):
    model_name: str = "Qwen/Qwen3-Embedding-0.6B"
    device: str = "cuda"
    dimensions: int = 768
    max_seq_length: int = 8192
    batch_size: int = 32
    instruction_prefix: str = "Instruct: Retrieve relevant development memories\nQuery: "


class QdrantConfig(BaseSettings):
    host: str = "localhost"
    port: int = 6333
    grpc_port: int = 6334
    collection_name: str = "shannon_cortex_memories"
    prefer_grpc: bool = True
    hnsw_m: int = 16
    hnsw_ef_construct: int = 200
    hnsw_ef_search: int = 128


class RerankerConfig(BaseSettings):
    enabled: bool = True
    endpoint: str = "http://localhost:8000/v1/ranking"
    model_name: str = "nvidia/llama-3.2-nv-rerankqa-1b-v2"
    top_k_candidates: int = 50
    top_k_results: int = 5
    timeout_ms: int = 100


class DecayConfig(BaseSettings):
    episodic_half_life_days: float = 30.0
    semantic_half_life_days: float = 365.0
    procedural_half_life_days: float = 0.0  # 0 = never decays
    access_reinforcement: float = 0.2
    importance_weight: float = 0.08


class ScoringConfig(BaseSettings):
    rerank_weight: float = 0.6
    decay_weight: float = 0.3
    recency_weight: float = 0.1
    min_importance_for_storage: int = 3
    min_importance_for_injection: int = 5


class HookConfig(BaseSettings):
    search_timeout_ms: int = 150
    max_injected_memories: int = 3
    max_injection_tokens: int = 400
    enable_adaptive_gating: bool = True


class DaemonConfig(BaseSettings):
    socket_path: Path = Field(default_factory=_default_socket_path)
    log_level: str = "INFO"
    workers: int = 1


class Settings(BaseSettings):
    data_dir: Path = Field(default_factory=_default_data_dir)
    project_scope: bool = True

    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    qdrant: QdrantConfig = Field(default_factory=QdrantConfig)
    reranker: RerankerConfig = Field(default_factory=RerankerConfig)
    decay: DecayConfig = Field(default_factory=DecayConfig)
    scoring: ScoringConfig = Field(default_factory=ScoringConfig)
    hooks: HookConfig = Field(default_factory=HookConfig)
    daemon: DaemonConfig = Field(default_factory=DaemonConfig)

    model_config = {"env_prefix": "SC_", "env_nested_delimiter": "__"}

    @property
    def memory_dir(self) -> Path:
        return self.data_dir / "memory"

    @property
    def semantic_dir(self) -> Path:
        return self.data_dir / "semantic"

    @property
    def procedural_dir(self) -> Path:
        return self.data_dir / "procedural"

    @property
    def sessions_dir(self) -> Path:
        return self.data_dir / "sessions"

    @property
    def log_dir(self) -> Path:
        return self.data_dir / "logs"

    def ensure_dirs(self) -> None:
        for d in [
            self.data_dir,
            self.memory_dir,
            self.semantic_dir,
            self.procedural_dir,
            self.sessions_dir,
            self.log_dir,
        ]:
            d.mkdir(parents=True, exist_ok=True)


def load_settings(config_path: Path | None = None) -> Settings:
    """Load settings from YAML config file with env var overrides."""
    if config_path is None:
        config_path = _default_data_dir() / "config.yaml"

    yaml_data: dict = {}
    if config_path.exists():
        with open(config_path) as f:
            yaml_data = yaml.safe_load(f) or {}

    settings = Settings(**yaml_data)
    settings.ensure_dirs()
    return settings
