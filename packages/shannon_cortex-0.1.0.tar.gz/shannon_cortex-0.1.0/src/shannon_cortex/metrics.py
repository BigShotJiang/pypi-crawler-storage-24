"""Prometheus metrics for Shannon-Cortex.

Exposes metrics at /metrics endpoint for scraping by Prometheus.
Uses a simple custom implementation to avoid adding prometheus_client dependency.
"""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from threading import Lock


@dataclass
class _Histogram:
    """Simple histogram with buckets."""

    name: str
    help: str
    buckets: list[float] = field(default_factory=lambda: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0])
    _counts: dict[float, int] = field(default_factory=lambda: defaultdict(int))
    _sum: float = 0.0
    _count: int = 0
    _lock: Lock = field(default_factory=Lock)

    def observe(self, value: float) -> None:
        with self._lock:
            self._sum += value
            self._count += 1
            for b in self.buckets:
                if value <= b:
                    self._counts[b] += 1

    def format(self) -> str:
        lines = [f"# HELP {self.name} {self.help}", f"# TYPE {self.name} histogram"]
        with self._lock:
            cumulative = 0
            for b in self.buckets:
                cumulative += self._counts.get(b, 0)
                lines.append(f'{self.name}_bucket{{le="{b}"}} {cumulative}')
            lines.append(f'{self.name}_bucket{{le="+Inf"}} {self._count}')
            lines.append(f"{self.name}_sum {self._sum:.6f}")
            lines.append(f"{self.name}_count {self._count}")
        return "\n".join(lines)


@dataclass
class _Counter:
    """Simple counter metric."""

    name: str
    help: str
    _values: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    _lock: Lock = field(default_factory=Lock)

    def inc(self, labels: str = "") -> None:
        with self._lock:
            self._values[labels] += 1

    def format(self) -> str:
        lines = [f"# HELP {self.name} {self.help}", f"# TYPE {self.name} counter"]
        with self._lock:
            if not self._values:
                lines.append(f"{self.name} 0")
            for labels, value in self._values.items():
                if labels:
                    lines.append(f"{self.name}{{{labels}}} {value}")
                else:
                    lines.append(f"{self.name} {value}")
        return "\n".join(lines)


@dataclass
class _Gauge:
    """Simple gauge metric."""

    name: str
    help: str
    _value: float = 0.0
    _lock: Lock = field(default_factory=Lock)

    def set(self, value: float) -> None:
        with self._lock:
            self._value = value

    def format(self) -> str:
        with self._lock:
            return f"# HELP {self.name} {self.help}\n# TYPE {self.name} gauge\n{self.name} {self._value}"


# Metric instances
search_latency = _Histogram(
    name="sc_search_latency_seconds",
    help="Search request latency in seconds",
)

embedding_latency = _Histogram(
    name="sc_embedding_latency_seconds",
    help="Embedding computation latency in seconds",
)

reranker_latency = _Histogram(
    name="sc_reranker_latency_seconds",
    help="Reranker request latency in seconds",
)

ingest_total = _Counter(
    name="sc_ingest_operations_total",
    help="Total ingest operations by memory type",
)

search_total = _Counter(
    name="sc_search_operations_total",
    help="Total search operations",
)

collection_size = _Gauge(
    name="sc_collection_size_vectors",
    help="Total vectors in the memory collection",
)

ALL_METRICS = [
    search_latency,
    embedding_latency,
    reranker_latency,
    ingest_total,
    search_total,
    collection_size,
]


def format_metrics() -> str:
    """Format all metrics in Prometheus exposition format."""
    return "\n\n".join(m.format() for m in ALL_METRICS) + "\n"
