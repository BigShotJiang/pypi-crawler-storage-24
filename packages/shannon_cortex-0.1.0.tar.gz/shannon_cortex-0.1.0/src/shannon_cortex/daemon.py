"""Shannon-Cortex memory daemon.

FastAPI application served over a Unix domain socket.
Provides /search, /ingest, /status, and /health endpoints.
"""

from __future__ import annotations

import logging
import os
import signal
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI

from fastapi.responses import PlainTextResponse

from shannon_cortex import __version__
from shannon_cortex.metrics import (
    collection_size,
    format_metrics,
    ingest_total,
    search_latency,
    search_total,
)
from shannon_cortex.config import Settings, load_settings
from shannon_cortex.embedding.qwen import QwenEmbeddingProvider
from shannon_cortex.embedding.sparse import SparseEncoder
from shannon_cortex.extraction.chunker import chunk_conversation
from shannon_cortex.extraction.importance import score_importance
from shannon_cortex.models.api import (
    IngestRequest,
    IngestResponse,
    SearchRequest,
    SearchResponse,
    StatusResponse,
)
from shannon_cortex.models.memory import EpisodicMemory
from shannon_cortex.retrieval.reranker import NIMReranker
from shannon_cortex.retrieval.search import SearchPipeline
from shannon_cortex.storage.markdown import MarkdownStorage
from shannon_cortex.storage.qdrant import QdrantStorage

logger = logging.getLogger(__name__)

# Global state
_settings: Settings | None = None
_embedding: QwenEmbeddingProvider | None = None
_storage: QdrantStorage | None = None
_markdown: MarkdownStorage | None = None
_reranker: NIMReranker | None = None
_sparse: SparseEncoder | None = None
_search_pipeline: SearchPipeline | None = None
_start_time: float = 0.0
_last_ingest: datetime | None = None
_last_search: datetime | None = None
_gpu_mode: str = "full"  # "full" or "gaming"


def _handle_gaming_mode(signum, frame):
    """SIGUSR1: Offload embedding model to CPU for gaming mode."""
    global _gpu_mode
    if _embedding and _embedding._model is not None:
        try:
            _embedding._model = _embedding._model.to("cpu")
            _gpu_mode = "gaming"
            logger.info("Offloaded embedding to CPU (gaming mode)")
        except Exception as e:
            logger.error("Failed to offload to CPU: %s", e)


def _handle_full_mode(signum, frame):
    """SIGUSR2: Reload embedding model to GPU for full mode."""
    global _gpu_mode
    if _embedding and _embedding._model is not None:
        try:
            _embedding._model = _embedding._model.to("cuda")
            _gpu_mode = "full"
            logger.info("Reloaded embedding to GPU (full mode)")
        except Exception as e:
            logger.error("Failed to reload to GPU: %s", e)


signal.signal(signal.SIGUSR1, _handle_gaming_mode)
signal.signal(signal.SIGUSR2, _handle_full_mode)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize components on startup, cleanup on shutdown."""
    global _settings, _embedding, _storage, _markdown, _reranker, _sparse, _search_pipeline, _start_time

    _start_time = time.monotonic()
    _settings = load_settings()

    logger.info("Starting Shannon-Cortex daemon v%s", __version__)

    # Initialize components
    _embedding = QwenEmbeddingProvider(_settings.embedding)
    _storage = QdrantStorage(_settings.qdrant)
    _markdown = MarkdownStorage(_settings.data_dir)
    _reranker = NIMReranker(_settings.reranker)
    _sparse = SparseEncoder()

    # Warm up embedding model
    logger.info("Warming up embedding model...")
    _embedding.warmup()

    _search_pipeline = SearchPipeline(
        embedding=_embedding,
        storage=_storage,
        reranker=_reranker,
        sparse=_sparse,
        settings=_settings,
    )

    logger.info("Shannon-Cortex daemon ready")
    yield

    # Cleanup
    logger.info("Shutting down Shannon-Cortex daemon")
    if _reranker:
        _reranker.close()


app = FastAPI(title="Shannon-Cortex", version=__version__, lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "version": __version__}


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics():
    """Prometheus metrics endpoint."""
    if _storage:
        collection_size.set(float(_storage.count()))
    return format_metrics()


@app.get("/status")
async def status() -> StatusResponse:
    uptime = time.monotonic() - _start_time
    return StatusResponse(
        status="ok",
        version=__version__,
        uptime_seconds=uptime,
        collection_size=_storage.count() if _storage else 0,
        embedding_model=_embedding.model_name if _embedding else "",
        embedding_device=_embedding.device if _embedding else "",
        qdrant_connected=_storage.is_connected() if _storage else False,
        reranker_available=_reranker.is_available() if _reranker else False,
        gpu_mode=_gpu_mode,
        memories_by_type=_storage.count_by_type() if _storage else {},
        last_ingest=_last_ingest,
        last_search=_last_search,
    )


@app.post("/search")
async def search(request: SearchRequest) -> SearchResponse:
    global _last_search
    _last_search = datetime.now(timezone.utc)
    start = time.monotonic()
    result = _search_pipeline.search(request)
    search_latency.observe(time.monotonic() - start)
    search_total.inc()
    return result


@app.post("/ingest")
async def ingest(request: IngestRequest) -> IngestResponse:
    """Ingest a memory from a Claude Code hook payload."""
    global _last_ingest

    content = request.content
    if not content:
        return IngestResponse(skipped_count=1)

    # Chunk the content
    chunks = chunk_conversation(
        content,
        project=request.cwd,
        session_id=request.session_id,
    )

    if not chunks:
        return IngestResponse(skipped_count=1)

    stored_ids: list[str] = []
    skipped = 0

    for chunk in chunks:
        importance = score_importance(chunk.content)
        if importance < _settings.scoring.min_importance_for_storage:
            skipped += 1
            continue

        memory = EpisodicMemory(
            content=chunk.content,
            importance=importance,
            project=request.cwd,
            session_id=request.session_id,
            source=chunk.source,
            tool_name=chunk.tool_name,
            turn_index=chunk.turn_index,
        )

        # Embed (dense + sparse)
        vector = _embedding.embed_single(memory.content)
        sparse_indices, sparse_values = _sparse.encode(memory.content)

        # Store in Qdrant
        _storage.upsert(
            memory=memory,
            dense_vector=vector,
            sparse_indices=sparse_indices if sparse_indices else None,
            sparse_values=sparse_values if sparse_values else None,
            embedding_model=_embedding.model_name if _embedding else "",
        )

        # Store in Markdown
        _markdown.append(memory)

        stored_ids.append(memory.id)

    _last_ingest = datetime.now(timezone.utc)
    logger.info(
        "Ingested %d memories (%d skipped) from %s hook",
        len(stored_ids), skipped, request.hook_event,
    )

    return IngestResponse(
        stored_count=len(stored_ids),
        skipped_count=skipped,
        memory_ids=stored_ids,
    )


def create_app() -> FastAPI:
    """Factory function for the FastAPI app."""
    return app
