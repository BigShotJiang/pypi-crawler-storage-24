"""Retrieval pipeline for Shannon-Cortex."""
