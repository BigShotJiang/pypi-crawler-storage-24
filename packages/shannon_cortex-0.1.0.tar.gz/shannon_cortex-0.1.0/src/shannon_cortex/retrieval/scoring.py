"""Temporal decay and composite scoring for memory retrieval.

Implements exponential decay with access-frequency reinforcement,
following MemoryBank's Ebbinghaus model and FadeMem's calibration.
"""

from __future__ import annotations

import math
from datetime import datetime, timezone

from shannon_cortex.config import DecayConfig, ScoringConfig
from shannon_cortex.models.memory import MemoryType


def half_life_to_lambda(half_life_days: float) -> float:
    """Convert half-life in days to decay constant lambda."""
    if half_life_days <= 0:
        return 0.0
    return math.log(2) / half_life_days


def compute_decay_strength(
    importance: int,
    created_at: datetime,
    access_count: int,
    memory_type: MemoryType,
    config: DecayConfig | None = None,
    now: datetime | None = None,
) -> float:
    """Compute current memory strength with temporal decay and access reinforcement.

    Formula:
        strength = importance * exp(-λ_eff * days) * (1 + access_count * reinforcement)
        λ_eff = base_rate * (1 - importance * importance_weight)

    Higher importance → slower decay. More accesses → stronger memory.
    Procedural memories never decay (λ=0).
    """
    if config is None:
        config = DecayConfig()
    if now is None:
        now = datetime.now(timezone.utc)

    # Get half-life for this memory type
    if memory_type == MemoryType.EPISODIC:
        half_life = config.episodic_half_life_days
    elif memory_type == MemoryType.SEMANTIC:
        half_life = config.semantic_half_life_days
    elif memory_type == MemoryType.PROCEDURAL:
        half_life = config.procedural_half_life_days
    else:
        half_life = config.episodic_half_life_days

    # No decay for procedural (half_life=0 means never decays)
    if half_life <= 0:
        return float(importance) * (1 + access_count * config.access_reinforcement)

    base_lambda = half_life_to_lambda(half_life)

    # Importance-weighted effective decay rate (higher importance = slower decay)
    lambda_eff = base_lambda * (1 - importance * config.importance_weight)
    lambda_eff = max(lambda_eff, 0.0)  # Don't allow negative decay

    # Age in days
    age_days = max((now - created_at).total_seconds() / 86400, 0.0)

    # Exponential decay with access reinforcement
    decay = math.exp(-lambda_eff * age_days)
    reinforcement = 1 + access_count * config.access_reinforcement

    return float(importance) * decay * reinforcement


def compute_composite_score(
    rerank_logit: float,
    decay_strength: float,
    age_hours: float,
    same_project: bool = True,
    config: ScoringConfig | None = None,
) -> float:
    """Compute final composite score from reranker, decay, recency, and project affinity.

    Combines:
        - Reranker logit (semantic relevance)
        - Decay strength (importance-weighted temporal relevance)
        - Recency bonus (mild boost for very recent memories)
        - Project affinity (same-project memories get a boost in tiebreakers)
    """
    if config is None:
        config = ScoringConfig()

    # Normalize rerank logit to [0, 1] range using sigmoid
    rerank_normalized = 1 / (1 + math.exp(-rerank_logit))

    # Normalize decay strength to [0, 1] (max possible is 10 * 1.0 * large_reinforcement)
    decay_normalized = min(decay_strength / 10.0, 1.0)

    # Recency bonus: exponential decay over hours (half-life ~24h)
    recency_bonus = math.exp(-0.029 * age_hours)  # ~0.5 at 24h

    # Project affinity: same-project gets a 15% boost, cross-project gets none.
    # This is enough to win tiebreakers but not enough to suppress
    # a highly relevant cross-project memory (like a user preference).
    project_boost = 0.15 if same_project else 0.0

    base = (
        config.rerank_weight * rerank_normalized
        + config.decay_weight * decay_normalized
        + config.recency_weight * recency_bonus
    )
    return base * (1.0 + project_boost)
