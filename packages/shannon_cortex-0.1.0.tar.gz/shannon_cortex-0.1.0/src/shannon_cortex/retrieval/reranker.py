"""NIM reranker client.

Calls the NVIDIA NIM reranker API to re-rank search candidates.
Configurable endpoint for users with different reranker setups.
"""

from __future__ import annotations

import logging
import time

import httpx

from shannon_cortex.config import RerankerConfig

logger = logging.getLogger(__name__)


class RerankResult:
    __slots__ = ("index", "logit")

    def __init__(self, index: int, logit: float) -> None:
        self.index = index
        self.logit = logit


class NIMReranker:
    """Client for the NVIDIA NIM reranker API."""

    def __init__(self, config: RerankerConfig | None = None) -> None:
        self._config = config or RerankerConfig()
        self._client: httpx.Client | None = None

    @property
    def client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(
                timeout=httpx.Timeout(self._config.timeout_ms / 1000.0),
            )
        return self._client

    def is_available(self) -> bool:
        if not self._config.enabled:
            return False
        try:
            resp = self.client.get(
                self._config.endpoint.rsplit("/", 1)[0].rsplit("/", 1)[0] + "/v1/models",
            )
            return resp.status_code == 200
        except Exception:
            return False

    def rerank(
        self,
        query: str,
        passages: list[str],
        top_k: int | None = None,
    ) -> list[RerankResult]:
        """Rerank passages against a query using the NIM reranker.

        Args:
            query: The search query.
            passages: List of passage texts to rerank.
            top_k: Return only top K results (default: all, sorted by score).

        Returns:
            List of RerankResult sorted by logit score descending.
        """
        if not passages:
            return []

        if not self._config.enabled:
            # Return original order with index-based scores
            return [RerankResult(index=i, logit=0.0) for i in range(len(passages))]

        start = time.monotonic()
        try:
            resp = self.client.post(
                self._config.endpoint,
                json={
                    "model": self._config.model_name,
                    "query": {"text": query},
                    "passages": [{"text": p} for p in passages],
                },
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.TimeoutException:
            logger.warning("Reranker timed out after %dms", self._config.timeout_ms)
            return [RerankResult(index=i, logit=0.0) for i in range(len(passages))]
        except Exception as e:
            logger.warning("Reranker request failed: %s", e)
            return [RerankResult(index=i, logit=0.0) for i in range(len(passages))]

        elapsed_ms = (time.monotonic() - start) * 1000
        logger.debug("Reranker returned in %.1fms for %d passages", elapsed_ms, len(passages))

        results = [
            RerankResult(index=r["index"], logit=r["logit"])
            for r in data.get("rankings", [])
        ]
        results.sort(key=lambda r: r.logit, reverse=True)

        if top_k is not None:
            results = results[:top_k]

        return results

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None
