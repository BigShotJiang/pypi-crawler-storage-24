"""Hybrid search pipeline: embed → hybrid search → rerank → score → format.

Orchestrates the full retrieval pipeline from query to formatted context injection.
Includes adaptive gating to skip search for trivial queries.
"""

from __future__ import annotations

import logging
import re
import time
from datetime import datetime, timezone

from shannon_cortex.config import Settings
from shannon_cortex.embedding.base import EmbeddingProvider
from shannon_cortex.embedding.sparse import SparseEncoder
from shannon_cortex.models.api import SearchRequest, SearchResponse, SearchResult
from shannon_cortex.models.memory import MemoryRecord, MemoryType
from shannon_cortex.retrieval.reranker import NIMReranker
from shannon_cortex.retrieval.scoring import compute_composite_score, compute_decay_strength
from shannon_cortex.storage.qdrant import QdrantStorage

logger = logging.getLogger(__name__)

# Patterns that indicate trivial queries not worth searching
TRIVIAL_PATTERNS = [
    re.compile(r"^(hi|hello|hey|thanks|thank you|ok|okay|sure|yes|no|bye|goodbye)\s*[.!?]*$", re.I),
    re.compile(r"^(good morning|good night|gm|gn)\s*[.!?]*$", re.I),
    re.compile(r"^\s*$"),
]


def _is_trivial_query(query: str) -> bool:
    """Check if a query is too trivial to warrant memory search."""
    for pattern in TRIVIAL_PATTERNS:
        if pattern.match(query.strip()):
            return True
    return len(query.strip()) < 5


def _format_injection(
    results: list[SearchResult],
    current_project: str = "",
    max_tokens: int = 400,
) -> str:
    """Format search results for Claude Code system message injection.

    Places memories at the beginning of the injected text per "Lost in the Middle" guidance.
    Labels cross-project memories so the model knows their origin context.
    """
    if not results:
        return ""

    lines = ["[Shannon-Cortex Memory]"]
    token_estimate = 5  # Header tokens

    for r in results:
        content = r.memory.content
        # Truncate long memories
        if len(content) > 300:
            content = content[:297] + "..."

        type_tag = r.memory.memory_type.value[0].upper()  # E/S/P
        importance = r.memory.importance

        # Label cross-project memories so the model knows the source context
        project_label = ""
        mem_project = r.memory.project
        if mem_project and current_project and mem_project != current_project:
            # Show just the last directory component for brevity
            short_name = mem_project.rstrip("/").rsplit("/", 1)[-1]
            project_label = f" (from: {short_name})"

        line = f"- [{type_tag}{importance}] {content}{project_label}"

        # Rough token estimate (1 token ≈ 4 chars)
        line_tokens = len(line) // 4
        if token_estimate + line_tokens > max_tokens:
            break
        lines.append(line)
        token_estimate += line_tokens

    return "\n".join(lines)


class SearchPipeline:
    """Full retrieval pipeline for memory search."""

    def __init__(
        self,
        embedding: EmbeddingProvider,
        storage: QdrantStorage,
        reranker: NIMReranker,
        settings: Settings,
        sparse: SparseEncoder | None = None,
    ) -> None:
        self._embedding = embedding
        self._storage = storage
        self._reranker = reranker
        self._settings = settings
        self._sparse = sparse or SparseEncoder()

    def search(self, request: SearchRequest) -> SearchResponse:
        """Execute the full search pipeline.

        Steps:
        1. Adaptive gating: skip if trivial query
        2. Embed query
        3. Hybrid search in Qdrant (dense + BM25 → RRF)
        4. Re-rank top candidates with NIM reranker
        5. Apply temporal decay scoring
        6. Format for context injection
        """
        start = time.monotonic()

        # 1. Adaptive gating
        if self._settings.hooks.enable_adaptive_gating and _is_trivial_query(request.query):
            logger.debug("Skipping search for trivial query: %s", request.query[:50])
            return SearchResponse(query_time_ms=0.0)

        # 2. Embed query (dense + sparse)
        query_vector = self._embedding.embed_single(request.query, is_query=True)
        sparse_indices, sparse_values = self._sparse.encode(request.query)

        # 3. Hybrid search (dense + BM25 → RRF fusion)
        # Search ALL projects — project affinity is applied in scoring, not as a hard filter.
        # This allows cross-project knowledge (preferences, patterns) to surface
        # while same-project memories get a 15% score boost.
        candidates = self._storage.hybrid_search(
            dense_vector=query_vector,
            sparse_indices=sparse_indices if sparse_indices else None,
            sparse_values=sparse_values if sparse_values else None,
            top_k=self._settings.reranker.top_k_candidates,
            memory_types=request.memory_types,
            min_importance=request.min_importance or self._settings.scoring.min_importance_for_injection,
            project=None,  # No hard filter — project boost in scoring handles affinity
            time_range_hours=request.time_range_hours,
        )

        if not candidates:
            elapsed = (time.monotonic() - start) * 1000
            return SearchResponse(query_time_ms=elapsed)

        total_candidates = len(candidates)

        # 4. Re-rank
        passages = [p.payload.get("content", "") for p in candidates]
        rerank_results = self._reranker.rerank(
            query=request.query,
            passages=passages,
            top_k=self._settings.reranker.top_k_results,
        )

        # 5. Build scored results with temporal decay
        now = datetime.now(timezone.utc)
        results: list[SearchResult] = []

        for rr in rerank_results:
            if rr.index >= len(candidates):
                continue
            point = candidates[rr.index]
            payload = point.payload or {}

            created_at = datetime.fromisoformat(payload.get("created_at", now.isoformat()))
            memory_type = MemoryType(payload.get("memory_type", "episodic"))

            decay_strength = compute_decay_strength(
                importance=payload.get("importance", 5),
                created_at=created_at,
                access_count=payload.get("access_count", 0),
                memory_type=memory_type,
                config=self._settings.decay,
                now=now,
            )

            age_hours = max((now - created_at).total_seconds() / 3600, 0.0)
            mem_project = payload.get("project", "")
            same_project = bool(request.project and mem_project == request.project)
            composite_score = compute_composite_score(
                rerank_logit=rr.logit,
                decay_strength=decay_strength,
                age_hours=age_hours,
                same_project=same_project,
                config=self._settings.scoring,
            )

            memory = MemoryRecord(
                id=str(point.id),
                content=payload.get("content", ""),
                memory_type=memory_type,
                importance=payload.get("importance", 5),
                created_at=created_at,
                last_accessed=datetime.fromisoformat(payload.get("last_accessed", now.isoformat())),
                access_count=payload.get("access_count", 0),
                project=payload.get("project", ""),
                session_id=payload.get("session_id", ""),
                source=payload.get("source", ""),
            )

            results.append(SearchResult(
                memory=memory,
                score=composite_score,
                rerank_score=rr.logit,
                decay_score=decay_strength,
            ))

        # Sort by composite score
        results.sort(key=lambda r: r.score, reverse=True)
        results = results[:request.top_k]

        # Update access timestamps for retrieved memories
        for r in results:
            try:
                self._storage.update_access(r.memory.id)
            except Exception as e:
                logger.debug("Failed to update access for %s: %s", r.memory.id, e)

        # 6. Format for injection (labels cross-project memories for model clarity)
        system_message = _format_injection(
            results,
            current_project=request.project,
            max_tokens=self._settings.hooks.max_injection_tokens,
        )

        elapsed = (time.monotonic() - start) * 1000
        logger.info(
            "Search completed in %.1fms: %d candidates → %d results",
            elapsed, total_candidates, len(results),
        )

        return SearchResponse(
            results=results,
            system_message=system_message,
            query_time_ms=elapsed,
            total_candidates=total_candidates,
        )
