"""AST-aware code chunking via tree-sitter.

Parses source code into an AST and chunks at meaningful boundaries
(function/class definitions), prepending contextual metadata per
Anthropic's Contextual Retrieval technique.

cAST paper (arXiv:2506.15655): +4.3 Recall@5 on RepoEval vs naive chunking.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from shannon_cortex.extraction.chunker import Chunk

logger = logging.getLogger(__name__)

# Node types that represent meaningful code boundaries
BOUNDARY_TYPES = {
    "function_definition",
    "async_function_definition",
    "class_definition",
    "decorated_definition",
    "method_definition",      # JavaScript/TypeScript
    "function_declaration",   # JavaScript/TypeScript
    "class_declaration",      # JavaScript/TypeScript
    "arrow_function",         # JavaScript/TypeScript
    "export_statement",       # JavaScript/TypeScript
}

# File extension to tree-sitter language mapping
LANGUAGE_MAP = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".sh": "bash",
    ".bash": "bash",
    ".yml": "yaml",
    ".yaml": "yaml",
}

# Approximate tokens per character
CHARS_PER_TOKEN = 4
DEFAULT_MAX_TOKENS = 300


def _get_language(file_path: str) -> str | None:
    """Get tree-sitter language name from file extension."""
    ext = Path(file_path).suffix.lower()
    return LANGUAGE_MAP.get(ext)


def _load_parser(language_name: str):
    """Load tree-sitter parser for a given language."""
    try:
        from tree_sitter import Language, Parser

        if language_name == "python":
            from tree_sitter_python import language as ts_lang
        elif language_name == "javascript":
            from tree_sitter_javascript import language as ts_lang
        elif language_name == "typescript":
            from tree_sitter_typescript import language_typescript as ts_lang
        elif language_name == "bash":
            from tree_sitter_bash import language as ts_lang
        elif language_name == "yaml":
            from tree_sitter_yaml import language as ts_lang
        else:
            return None

        parser = Parser()
        lang = Language(ts_lang())
        parser.language = lang
        return parser
    except ImportError:
        logger.debug("tree-sitter language %s not available", language_name)
        return None


def _get_scope_path(node) -> str:
    """Build the scope path from root to this node (e.g., 'module > MyClass > my_method')."""
    parts = []
    current = node.parent
    while current is not None:
        if current.type in ("class_definition", "class_declaration"):
            name_node = current.child_by_field_name("name")
            if name_node:
                parts.append(name_node.text.decode("utf-8", errors="replace"))
        elif current.type in ("function_definition", "async_function_definition", "function_declaration", "method_definition"):
            name_node = current.child_by_field_name("name")
            if name_node:
                parts.append(name_node.text.decode("utf-8", errors="replace"))
        elif current.type == "module":
            parts.append("module")
        current = current.parent
    parts.reverse()
    return " > ".join(parts) if parts else "module"


def _node_token_estimate(node) -> int:
    """Estimate token count for a node."""
    byte_length = node.end_byte - node.start_byte
    return byte_length // CHARS_PER_TOKEN


def _extract_chunks_from_node(
    node,
    source: bytes,
    file_path: str,
    max_tokens: int,
) -> list[Chunk]:
    """Recursively extract chunks from an AST node."""
    chunks = []
    token_est = _node_token_estimate(node)

    if token_est <= max_tokens:
        # Node fits in a single chunk
        text = source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")
        scope = _get_scope_path(node)
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        # Prepend contextual metadata (Anthropic Contextual Retrieval technique)
        name_node = node.child_by_field_name("name")
        name = name_node.text.decode("utf-8", errors="replace") if name_node else node.type

        metadata_header = f"# File: {file_path}\n# Scope: {scope}\n# {node.type}: {name} (lines {start_line}-{end_line})\n"

        chunks.append(Chunk(
            content=metadata_header + text,
            source="code",
            metadata={
                "file_path": file_path,
                "scope": scope,
                "node_type": node.type,
                "name": name,
                "start_line": start_line,
                "end_line": end_line,
            },
        ))
    else:
        # Node too large — try to split at child boundaries
        child_chunks = []
        current_siblings = []
        current_size = 0

        for child in node.children:
            if child.type in BOUNDARY_TYPES:
                # Flush accumulated siblings as one chunk
                if current_siblings and current_size >= 50 // CHARS_PER_TOKEN:
                    merged_text = source[current_siblings[0].start_byte:current_siblings[-1].end_byte]
                    scope = _get_scope_path(current_siblings[0])
                    chunks.append(Chunk(
                        content=f"# File: {file_path}\n# Scope: {scope}\n" + merged_text.decode("utf-8", errors="replace"),
                        source="code",
                        metadata={"file_path": file_path, "scope": scope, "node_type": "block"},
                    ))
                current_siblings = []
                current_size = 0

                # Recursively chunk the boundary node
                child_chunks.extend(
                    _extract_chunks_from_node(child, source, file_path, max_tokens)
                )
            else:
                child_size = child.end_byte - child.start_byte
                if current_size + child_size > max_tokens * CHARS_PER_TOKEN and current_siblings:
                    merged_text = source[current_siblings[0].start_byte:current_siblings[-1].end_byte]
                    scope = _get_scope_path(current_siblings[0])
                    chunks.append(Chunk(
                        content=f"# File: {file_path}\n# Scope: {scope}\n" + merged_text.decode("utf-8", errors="replace"),
                        source="code",
                        metadata={"file_path": file_path, "scope": scope, "node_type": "block"},
                    ))
                    current_siblings = []
                    current_size = 0
                current_siblings.append(child)
                current_size += child_size

        # Flush remaining siblings
        if current_siblings:
            merged_text = source[current_siblings[0].start_byte:current_siblings[-1].end_byte]
            scope = _get_scope_path(current_siblings[0])
            if len(merged_text) > 50:
                chunks.append(Chunk(
                    content=f"# File: {file_path}\n# Scope: {scope}\n" + merged_text.decode("utf-8", errors="replace"),
                    source="code",
                    metadata={"file_path": file_path, "scope": scope, "node_type": "block"},
                ))

        chunks.extend(child_chunks)

    return chunks


def chunk_code(
    code: str,
    file_path: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
) -> list[Chunk]:
    """Parse source code and chunk at AST boundaries.

    Args:
        code: Source code string.
        file_path: Path to the source file (for metadata and language detection).
        max_tokens: Maximum tokens per chunk.

    Returns:
        List of Chunk objects with code-aware boundaries and contextual metadata.
        Falls back to simple line-based splitting if tree-sitter is unavailable.
    """
    language_name = _get_language(file_path)
    if language_name is None:
        logger.debug("Unsupported file type: %s", file_path)
        return []

    parser = _load_parser(language_name)
    if parser is None:
        # Fallback: simple line-based splitting
        return _fallback_chunk(code, file_path, max_tokens)

    source = code.encode("utf-8")
    tree = parser.parse(source)
    root = tree.root_node

    chunks = []
    for child in root.children:
        if child.type in BOUNDARY_TYPES:
            chunks.extend(_extract_chunks_from_node(child, source, file_path, max_tokens))
        elif _node_token_estimate(child) >= 30:
            # Non-boundary top-level content (imports, constants, etc.)
            text = source[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
            chunks.append(Chunk(
                content=f"# File: {file_path}\n# Scope: module\n" + text,
                source="code",
                metadata={"file_path": file_path, "scope": "module", "node_type": child.type},
            ))

    return chunks


def _fallback_chunk(code: str, file_path: str, max_tokens: int) -> list[Chunk]:
    """Simple line-based chunking fallback when tree-sitter isn't available."""
    lines = code.split("\n")
    chunks = []
    current_lines = []
    current_tokens = 0

    for line in lines:
        line_tokens = len(line) // CHARS_PER_TOKEN
        if current_tokens + line_tokens > max_tokens and current_lines:
            text = "\n".join(current_lines)
            chunks.append(Chunk(
                content=f"# File: {file_path}\n" + text,
                source="code",
                metadata={"file_path": file_path, "node_type": "block"},
            ))
            current_lines = []
            current_tokens = 0
        current_lines.append(line)
        current_tokens += line_tokens

    if current_lines and current_tokens >= 10:
        text = "\n".join(current_lines)
        chunks.append(Chunk(
            content=f"# File: {file_path}\n" + text,
            source="code",
            metadata={"file_path": file_path, "node_type": "block"},
        ))

    return chunks
