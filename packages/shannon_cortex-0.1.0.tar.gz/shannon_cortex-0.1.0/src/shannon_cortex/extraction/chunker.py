"""Conversation chunking for memory extraction.

Splits Claude Code session content into memory-sized chunks at turn boundaries.
Target: 100-300 tokens per chunk, preserving dialogue context.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class Chunk:
    """A single chunk of text ready for embedding and storage."""

    content: str
    source: str = "conversation"  # conversation, tool, error, code
    turn_index: int | None = None
    tool_name: str | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict = field(default_factory=dict)  # Extra context (file_path, scope, node_type, etc.)

    @property
    def token_estimate(self) -> int:
        """Rough token estimate (~4 chars per token)."""
        return len(self.content) // 4


# Patterns for splitting conversation turns
TURN_PATTERNS = [
    re.compile(r"^(Human|User|Assistant|Claude):\s*", re.MULTILINE),
    re.compile(r"^>\s*\*\*(Human|User|Assistant|Claude)\*\*", re.MULTILINE),
]

TOOL_CALL_PATTERN = re.compile(
    r"(Tool\s+call|Called|Using)\s+(\w+).*?(?:Result|Output|returned).*?$",
    re.MULTILINE | re.DOTALL,
)

# Reflexion-style failure → resolution detection
FAILURE_PATTERNS = [
    re.compile(r"\b(error|exception|traceback|failed|crash|panic|refused)\b", re.I),
]
RESOLUTION_PATTERNS = [
    re.compile(r"\b(fix(ed)?|resolv(ed|ing)|the\s+(issue|problem|bug)\s+was|working\s+now)\b", re.I),
    re.compile(r"\b(the\s+fix\s+was|solved\s+by|resolved\s+by|changed\s+to)\b", re.I),
]


@dataclass
class FailureResolution:
    """A detected failure → resolution pattern (Reflexion-style)."""

    trigger: str  # The error/failure condition
    resolution: str  # How it was fixed
    full_content: str  # Complete context


def chunk_conversation(
    text: str,
    max_tokens: int = 300,
    min_tokens: int = 30,
    project: str = "",
    session_id: str = "",
) -> list[Chunk]:
    """Split conversation text into chunks at turn boundaries.

    Strategy:
    1. Split at conversation turn boundaries (Human/Assistant markers)
    2. If a turn exceeds max_tokens, split at sentence boundaries
    3. Discard chunks below min_tokens
    4. Prepend context (project, timestamp) to each chunk
    """
    if not text or not text.strip():
        return []

    chunks: list[Chunk] = []

    # Try to split at turn boundaries
    turns = _split_turns(text)

    for i, turn in enumerate(turns):
        turn_text = turn.strip()
        if not turn_text:
            continue

        token_est = len(turn_text) // 4

        if token_est < min_tokens:
            continue

        if token_est <= max_tokens:
            # Single chunk for this turn
            source = _detect_source(turn_text)
            tool_name = _detect_tool(turn_text)
            chunks.append(Chunk(
                content=turn_text,
                source=source,
                turn_index=i,
                tool_name=tool_name,
            ))
        else:
            # Split large turns at sentence boundaries
            sentences = _split_sentences(turn_text)
            current = []
            current_len = 0

            for sentence in sentences:
                sent_tokens = len(sentence) // 4
                if current_len + sent_tokens > max_tokens and current:
                    chunks.append(Chunk(
                        content=" ".join(current),
                        source=_detect_source(" ".join(current)),
                        turn_index=i,
                    ))
                    current = []
                    current_len = 0
                current.append(sentence)
                current_len += sent_tokens

            if current and current_len >= min_tokens:
                chunks.append(Chunk(
                    content=" ".join(current),
                    source=_detect_source(" ".join(current)),
                    turn_index=i,
                ))

    return chunks


def _split_turns(text: str) -> list[str]:
    """Split text at conversation turn boundaries."""
    for pattern in TURN_PATTERNS:
        parts = pattern.split(text)
        if len(parts) > 1:
            # Rejoin label with content
            turns = []
            for j in range(0, len(parts) - 1, 2):
                if j + 1 < len(parts):
                    turns.append(parts[j] + (parts[j + 1] if j + 1 < len(parts) else ""))
                else:
                    turns.append(parts[j])
            if turns:
                return turns

    # Fallback: split on double newlines
    return [p for p in text.split("\n\n") if p.strip()]


def _split_sentences(text: str) -> list[str]:
    """Split text at sentence boundaries."""
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return [s for s in sentences if s.strip()]


def _detect_source(text: str) -> str:
    """Detect whether a chunk is from conversation, tool, or error context."""
    lower = text.lower()
    if any(word in lower for word in ["error", "exception", "traceback", "failed", "crash"]):
        return "error"
    if any(word in lower for word in ["tool call", "bash", "read file", "edit file", "grep"]):
        return "tool"
    return "conversation"


def _detect_tool(text: str) -> str | None:
    """Detect tool name from a chunk if it's a tool invocation."""
    match = TOOL_CALL_PATTERN.search(text)
    if match:
        return match.group(2)
    return None


def detect_failure_resolution(text: str) -> FailureResolution | None:
    """Detect a failure → resolution pattern in conversation text.

    Reflexion (Shinn et al., NeurIPS 2023): storing verbal self-reflections
    on failures as procedural memory achieves 91% pass@1 on HumanEval.

    Returns a FailureResolution if both failure and resolution signals are found.
    """
    has_failure = any(p.search(text) for p in FAILURE_PATTERNS)
    has_resolution = any(p.search(text) for p in RESOLUTION_PATTERNS)

    if not (has_failure and has_resolution):
        return None

    # Split into failure context and resolution context
    # Heuristic: failure appears before resolution in the text
    sentences = _split_sentences(text)
    failure_parts = []
    resolution_parts = []
    in_resolution = False

    for sent in sentences:
        if not in_resolution and any(p.search(sent) for p in RESOLUTION_PATTERNS):
            in_resolution = True
        if in_resolution:
            resolution_parts.append(sent)
        else:
            failure_parts.append(sent)

    if not failure_parts or not resolution_parts:
        return None

    return FailureResolution(
        trigger=" ".join(failure_parts[:3]),  # First 3 sentences of failure
        resolution=" ".join(resolution_parts[:3]),  # First 3 sentences of fix
        full_content=text,
    )
