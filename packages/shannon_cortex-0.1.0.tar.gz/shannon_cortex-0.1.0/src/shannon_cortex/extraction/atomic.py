"""Atomic fact extraction from high-importance memories.

Dense X Retrieval (Chen et al., EMNLP 2024): proposition-based retrieval achieves
17-25% relative improvement in Recall@5 over passage-level retrieval.
10 propositions carry 5x the relevant information vs 2 passages.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from shannon_cortex.models.memory import EpisodicMemory

logger = logging.getLogger(__name__)

ATOMIC_PROMPT = """Extract atomic facts from this development memory. Each fact should be:
- Self-contained (understandable without any other context)
- Specific (include names, file paths, port numbers, versions)
- One sentence only

Memory:
{content}

Facts (one per line, no bullets or numbers):"""


def extract_atomic_facts(content: str) -> list[str]:
    """Extract atomic, self-contained facts from a memory using local LLM.

    Returns list of fact strings, or empty list if LLM unavailable.
    """
    from shannon_cortex import llm

    if not llm.is_available():
        return []

    prompt = ATOMIC_PROMPT.format(content=content)
    result = llm.generate(prompt, max_new_tokens=300, temperature=0.3)

    if not result:
        return []

    # Parse facts — one per line, skip empty/short lines
    facts = []
    for line in result.strip().split("\n"):
        line = line.strip().lstrip("-•*0123456789.) ")
        if len(line) > 20:  # Skip very short fragments
            facts.append(line)

    logger.debug("Extracted %d atomic facts from memory", len(facts))
    return facts


def create_atomic_memories(
    parent: EpisodicMemory,
    facts: list[str],
) -> list[EpisodicMemory]:
    """Create EpisodicMemory records for each extracted fact.

    Each atomic fact links back to the parent memory via metadata.
    """
    memories = []
    for fact in facts:
        mem = EpisodicMemory(
            id=str(uuid.uuid4()),
            content=fact,
            importance=parent.importance,
            created_at=parent.created_at,
            project=parent.project,
            session_id=parent.session_id,
            source="atomic_fact",
            metadata={"parent_id": parent.id},
        )
        memories.append(mem)
    return memories
