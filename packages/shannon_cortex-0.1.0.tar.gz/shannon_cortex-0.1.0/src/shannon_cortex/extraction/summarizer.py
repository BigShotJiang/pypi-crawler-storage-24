"""Third-person summary generation for memory ingest.

memsearch pattern: rewrite conversation excerpts as concise third-person notes.
Summarized memories embed better (less noise) and inject more cleanly into prompts.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

SUMMARY_PROMPT = """Rewrite this development session excerpt as a concise third-person note (1-2 sentences).
Focus on: what was done, why, and the outcome. Be specific with names, paths, and technical details.

Excerpt:
{content}

Summary:"""


def summarize_memory(content: str) -> str | None:
    """Summarize a memory as a third-person note using local LLM.

    Returns the summary string, or None if LLM unavailable.
    The raw content is preserved in Markdown; only the summary is embedded.
    """
    from shannon_cortex import llm

    if not llm.is_available():
        return None

    prompt = SUMMARY_PROMPT.format(content=content)
    result = llm.generate(prompt, max_new_tokens=150, temperature=0.3)

    if result and len(result) > 20:
        logger.debug("Summarized memory: %s -> %s", content[:50], result[:50])
        return result

    return None
