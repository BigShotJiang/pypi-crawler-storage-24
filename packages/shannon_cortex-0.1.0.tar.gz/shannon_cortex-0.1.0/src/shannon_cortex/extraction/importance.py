"""Heuristic importance scoring for memory extraction.

Fast, rule-based scoring (no LLM needed) that runs on the sync path.
Scores range from 1-10 based on content signals that predict future utility.

Based on patterns from Generative Agents (Park et al., 2023) and memsearch.
"""

from __future__ import annotations

import re

# High-importance signal patterns (score 8-10)
USER_CORRECTION_PATTERNS = [
    re.compile(r"\b(actually|no[,.]?\s+(use|do|it's)|instead[,.]?\s+(use|do)|not that|wrong)\b", re.I),
    re.compile(r"\bdon'?t\s+(use|do|add|create|make)\b", re.I),
    re.compile(r"\bplease\s+(change|fix|update|correct)\b", re.I),
]

PREFERENCE_PATTERNS = [
    re.compile(r"\bI\s+(prefer|like|want|always use|never use)\b", re.I),
    re.compile(r"\b(always|never)\s+(use|do|add|include)\b", re.I),
    re.compile(r"\bmy\s+(preference|convention|style)\b", re.I),
]

# Medium-importance signal patterns (score 6-8)
ERROR_RESOLUTION_PATTERNS = [
    re.compile(r"\b(error|exception|traceback|failed|fix(ed)?|resolved|bug|issue)\b", re.I),
    re.compile(r"\b(stack\s*trace|segfault|crash|panic)\b", re.I),
]

ARCHITECTURE_PATTERNS = [
    re.compile(r"\b(let'?s?\s+use|the\s+approach\s+is|architecture|design\s+decision)\b", re.I),
    re.compile(r"\b(we('re|\s+are)\s+(using|migrating|switching))\b", re.I),
    re.compile(r"\b(pattern|strategy|framework|library)\s+(is|for|to)\b", re.I),
]

DEPLOYMENT_PATTERNS = [
    re.compile(r"\b(deploy|deployment|docker|container|kubernetes|systemd|service)\b", re.I),
    re.compile(r"\b(port\s+\d+|endpoint|api\s+url|config(uration)?)\b", re.I),
]

# Low-importance patterns (score 1-3)
TRIVIAL_PATTERNS = [
    re.compile(r"^(hi|hello|hey|thanks|thank you|ok|okay|sure|yes|no|got it|sounds good)\s*[.!?]*$", re.I),
    re.compile(r"^(good morning|good night|bye|goodbye|see you)\s*[.!?]*$", re.I),
]


def score_importance(content: str) -> int:
    """Score the importance of a text chunk on a 1-10 scale.

    Returns:
        Integer importance score from 1 (trivial) to 10 (critical).
    """
    if not content or not content.strip():
        return 1

    text = content.strip()

    # Check trivial first (fast exit)
    for pattern in TRIVIAL_PATTERNS:
        if pattern.match(text):
            return 1

    score = 4  # Default baseline for non-trivial content

    # User corrections (highest signal)
    for pattern in USER_CORRECTION_PATTERNS:
        if pattern.search(text):
            score = max(score, 9)
            break

    # Explicit preferences
    for pattern in PREFERENCE_PATTERNS:
        if pattern.search(text):
            score = max(score, 8)
            break

    # Error resolutions
    for pattern in ERROR_RESOLUTION_PATTERNS:
        if pattern.search(text):
            score = max(score, 7)
            break

    # Architecture decisions
    for pattern in ARCHITECTURE_PATTERNS:
        if pattern.search(text):
            score = max(score, 7)
            break

    # Deployment/configuration
    for pattern in DEPLOYMENT_PATTERNS:
        if pattern.search(text):
            score = max(score, 6)
            break

    # Length-based adjustment: very short content is less likely important
    if len(text) < 20:
        score = min(score, 3)
    elif len(text) > 500:
        # Long, detailed content is more likely important
        score = min(score + 1, 10)

    return min(max(score, 1), 10)
