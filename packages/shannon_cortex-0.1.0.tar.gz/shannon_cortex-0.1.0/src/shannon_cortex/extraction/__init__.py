"""Memory extraction from Claude Code sessions."""
