"""Memory consolidation — episodic to semantic reflection, decay, and conflict resolution."""
