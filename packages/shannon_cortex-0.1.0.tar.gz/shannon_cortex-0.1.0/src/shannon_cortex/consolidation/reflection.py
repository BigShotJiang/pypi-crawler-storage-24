"""Episodic-to-semantic reflection — the Generative Agents consolidation pattern.

Clusters related episodic memories by semantic similarity, then synthesizes
high-level insights using a local LLM (Qwen3-0.6B). The resulting semantic
memories represent consolidated knowledge.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

import numpy as np

from shannon_cortex.config import Settings
from shannon_cortex.embedding.base import EmbeddingProvider
from shannon_cortex.models.memory import MemoryType, SemanticMemory
from shannon_cortex.storage.markdown import MarkdownStorage
from shannon_cortex.storage.qdrant import QdrantStorage

logger = logging.getLogger(__name__)

REFLECTION_PROMPT_TEMPLATE = """You are a memory consolidation system. Given the following episodic memories from development sessions, synthesize them into a concise, high-level insight or fact.

Focus on:
- Patterns that repeat across memories
- Important decisions or preferences
- Key technical facts about the project or system
- Lessons learned from errors or debugging

Episodic memories:
{memories}

Write a single concise paragraph (2-4 sentences) capturing the consolidated knowledge. Be specific and factual."""


def cluster_memories(
    embeddings: np.ndarray,
    timestamps: list[datetime] | None = None,
    threshold: float = 0.85,
    max_hours: float = 2.0,
) -> list[list[int]]:
    """Cluster memory indices by cosine similarity AND temporal proximity.

    Report Section 8: "Cluster by semantic similarity (>0.85) AND temporal
    proximity (<2 hours apart)" to prevent unrelated conversations from
    incorrectly merging.

    Args:
        embeddings: Normalized embedding vectors (dot product = cosine sim).
        timestamps: Optional list of timestamps for temporal gating.
        threshold: Minimum cosine similarity for clustering.
        max_hours: Maximum hours apart for temporal proximity (ignored if no timestamps).
    """
    n = len(embeddings)
    if n == 0:
        return []

    # Compute pairwise cosine similarity matrix
    sim_matrix = embeddings @ embeddings.T

    # Build clusters using union-find
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for i in range(n):
        for j in range(i + 1, n):
            if sim_matrix[i, j] >= threshold:
                # Temporal proximity gate
                if timestamps is not None:
                    time_diff_hours = abs((timestamps[i] - timestamps[j]).total_seconds()) / 3600
                    if time_diff_hours > max_hours:
                        continue
                union(i, j)

    # Group by root
    clusters: dict[int, list[int]] = {}
    for i in range(n):
        root = find(i)
        clusters.setdefault(root, []).append(i)

    return list(clusters.values())


def generate_reflection(memory_texts: list[str]) -> str | None:
    """Generate a reflection/synthesis from a cluster of memories using shared LLM."""
    from shannon_cortex import llm

    memories_text = "\n".join(f"- {t}" for t in memory_texts)
    prompt = REFLECTION_PROMPT_TEMPLATE.format(memories=memories_text)
    return llm.generate(prompt, max_new_tokens=200)


def run_reflection(
    storage: QdrantStorage,
    markdown: MarkdownStorage,
    embedding: EmbeddingProvider,
    settings: Settings,
    target_date: datetime | None = None,
    min_cluster_size: int = 3,
    similarity_threshold: float = 0.85,
    use_llm: bool = True,
) -> dict:
    """Run the reflection pipeline on a day's episodic memories.

    Steps:
    1. Read today's episodic memories from Markdown
    2. Embed them
    3. Cluster by semantic similarity
    4. For clusters above min_cluster_size: generate synthesis via LLM
    5. Store reflections as semantic memories

    Args:
        target_date: Date to process (default: today)
        min_cluster_size: Minimum memories in a cluster to trigger reflection
        similarity_threshold: Cosine similarity threshold for clustering
        use_llm: Whether to use LLM for synthesis (False = skip, useful for testing)

    Returns:
        dict with counts
    """
    if target_date is None:
        target_date = datetime.now(timezone.utc)

    # 1. Read today's episodic memories
    memories = markdown.read_daily(target_date.date())
    if not memories:
        logger.info("No memories found for %s", target_date.date())
        return {"memories_found": 0, "clusters": 0, "reflections_created": 0}

    logger.info("Processing %d memories from %s", len(memories), target_date.date())

    # 2. Embed
    texts = [m.content for m in memories]
    embeddings = embedding.embed(texts)

    # 3. Cluster (with temporal proximity gating)
    timestamps = [m.created_at for m in memories]
    clusters = cluster_memories(embeddings, timestamps=timestamps, threshold=similarity_threshold)
    large_clusters = [c for c in clusters if len(c) >= min_cluster_size]

    logger.info(
        "Found %d clusters (%d with %d+ memories)",
        len(clusters), len(large_clusters), min_cluster_size,
    )

    # 4. Generate reflections for large clusters
    reflections_created = 0
    for cluster_indices in large_clusters:
        cluster_texts = [texts[i] for i in cluster_indices]
        cluster_memory_ids = [memories[i].id for i in cluster_indices]

        if use_llm:
            synthesis = generate_reflection(cluster_texts)
        else:
            # Fallback: simple concatenation summary
            synthesis = f"Consolidated from {len(cluster_texts)} related memories: " + "; ".join(
                t[:100] for t in cluster_texts[:3]
            )

        if synthesis:
            # 5. Store as semantic memory
            semantic = SemanticMemory(
                id=str(uuid.uuid4()),
                content=synthesis,
                importance=7,  # Reflections get moderate-high importance
                project=memories[cluster_indices[0]].project,
                source="reflection",
                provenance=cluster_memory_ids,
                domain="consolidated",
            )

            # Embed and store
            vector = embedding.embed_single(semantic.content)
            storage.upsert(memory=semantic, dense_vector=vector)
            markdown.append(semantic)

            reflections_created += 1
            logger.info(
                "Created reflection from %d memories: %s",
                len(cluster_indices), synthesis[:100],
            )

    result = {
        "memories_found": len(memories),
        "clusters": len(clusters),
        "large_clusters": len(large_clusters),
        "reflections_created": reflections_created,
    }

    logger.info("Reflection complete: %s", result)
    return result
