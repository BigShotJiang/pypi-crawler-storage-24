"""Memory decay and archival.

Scans all memories, computes current strength using the temporal decay model,
and archives memories that have fallen below threshold.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from shannon_cortex.config import DecayConfig, Settings
from shannon_cortex.models.memory import MemoryType
from shannon_cortex.retrieval.scoring import compute_decay_strength
from shannon_cortex.storage.qdrant import QdrantStorage

logger = logging.getLogger(__name__)

# Archival thresholds
DEFAULT_MIN_IMPORTANCE = 5
DEFAULT_MIN_ACCESS_COUNT = 2
DEFAULT_MIN_AGE_DAYS = 30


def run_decay(
    storage: QdrantStorage,
    settings: Settings,
    dry_run: bool = False,
) -> dict:
    """Apply temporal decay and archive weak memories.

    Memories are archived (removed from active index) if ALL conditions are met:
    - importance < min_importance (default 5)
    - access_count < min_access_count (default 2)
    - age > min_age_days (default 30)
    - computed decay_strength < threshold

    Procedural memories are never archived via decay.

    Returns:
        dict with counts: {scanned, archived, preserved}
    """
    now = datetime.now(timezone.utc)
    decay_config = settings.decay

    # Scroll through all memories
    scanned = 0
    archived_ids = []
    preserved = 0
    offset = None

    while True:
        result = storage.client.scroll(
            collection_name=storage.collection_name,
            limit=100,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )
        points, next_offset = result

        for point in points:
            scanned += 1
            payload = point.payload or {}
            memory_type = MemoryType(payload.get("memory_type", "episodic"))

            # Never decay procedural memories
            if memory_type == MemoryType.PROCEDURAL:
                preserved += 1
                continue

            # Never decay semantic memories (very long half-life handles this)
            if memory_type == MemoryType.SEMANTIC:
                preserved += 1
                continue

            importance = payload.get("importance", 5)
            access_count = payload.get("access_count", 0)
            created_at = datetime.fromisoformat(payload.get("created_at", now.isoformat()))
            age_days = (now - created_at).total_seconds() / 86400

            # Check archival conditions
            if (
                importance < DEFAULT_MIN_IMPORTANCE
                and access_count < DEFAULT_MIN_ACCESS_COUNT
                and age_days > DEFAULT_MIN_AGE_DAYS
            ):
                strength = compute_decay_strength(
                    importance=importance,
                    created_at=created_at,
                    access_count=access_count,
                    memory_type=memory_type,
                    config=decay_config,
                    now=now,
                )
                # Archive if strength has decayed below 50% of original importance
                if strength < importance * 0.5:
                    archived_ids.append(str(point.id))
                    continue

            preserved += 1

        if next_offset is None:
            break
        offset = next_offset

    # Perform archival (delete from Qdrant — Markdown files are preserved)
    if archived_ids and not dry_run:
        for memory_id in archived_ids:
            storage.delete(memory_id)
        logger.info("Archived %d memories (removed from vector index, Markdown preserved)", len(archived_ids))

    result = {
        "scanned": scanned,
        "archived": len(archived_ids),
        "preserved": preserved,
        "archived_ids": archived_ids if dry_run else [],
    }

    logger.info(
        "Decay scan: %d scanned, %d archived, %d preserved",
        scanned, len(archived_ids), preserved,
    )
    return result
