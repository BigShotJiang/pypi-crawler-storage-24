"""Nightly consolidation pipeline orchestrator.

Runs decay → reflection → conflict resolution → compact.
Designed to run as a cron job or systemd timer at 2 AM.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone

from shannon_cortex.config import load_settings
from shannon_cortex.consolidation.conflict import detect_conflicts, resolve_conflicts
from shannon_cortex.consolidation.decay import run_decay
from shannon_cortex.consolidation.reflection import run_reflection
from shannon_cortex.embedding.qwen import QwenEmbeddingProvider
from shannon_cortex.storage.markdown import MarkdownStorage
from shannon_cortex.storage.qdrant import QdrantStorage

logger = logging.getLogger(__name__)


def run_consolidation(
    dry_run: bool = False,
    skip_reflection: bool = False,
    skip_conflict: bool = False,
    target_date: datetime | None = None,
) -> dict:
    """Run the full consolidation pipeline.

    Steps:
    1. Decay: Archive weak, old, unaccessed memories
    2. Reflection: Cluster and synthesize episodic → semantic
    3. Conflict: Detect and resolve contradictory memories

    Args:
        dry_run: If True, report what would happen without modifying data
        skip_reflection: Skip the LLM-based reflection step
        skip_conflict: Skip conflict detection/resolution
        target_date: Date for reflection processing (default: today)

    Returns:
        dict with results from each step
    """
    start = time.monotonic()
    settings = load_settings()
    results: dict = {"timestamp": datetime.now(timezone.utc).isoformat()}

    logger.info("Starting consolidation pipeline%s", " (dry run)" if dry_run else "")

    # Initialize components
    storage = QdrantStorage(settings.qdrant)
    markdown = MarkdownStorage(settings.data_dir)
    embedding = QwenEmbeddingProvider(settings.embedding)

    # Step 1: Decay
    logger.info("Step 1/3: Running decay scan...")
    decay_result = run_decay(storage, settings, dry_run=dry_run)
    results["decay"] = decay_result

    # Step 2: Reflection
    if not skip_reflection:
        logger.info("Step 2/3: Running reflection...")
        reflection_result = run_reflection(
            storage=storage,
            markdown=markdown,
            embedding=embedding,
            settings=settings,
            target_date=target_date,
            use_llm=not dry_run,
        )
        results["reflection"] = reflection_result
    else:
        logger.info("Step 2/3: Reflection skipped")
        results["reflection"] = {"skipped": True}

    # Step 3: Conflict resolution
    if not skip_conflict:
        logger.info("Step 3/3: Detecting conflicts...")
        conflicts = detect_conflicts(storage, embedding)
        if conflicts:
            resolve_result = resolve_conflicts(conflicts, storage, dry_run=dry_run)
            results["conflicts"] = {
                "detected": len(conflicts),
                **resolve_result,
            }
        else:
            results["conflicts"] = {"detected": 0}
    else:
        logger.info("Step 3/3: Conflict resolution skipped")
        results["conflicts"] = {"skipped": True}

    elapsed = time.monotonic() - start
    results["duration_seconds"] = elapsed
    logger.info("Consolidation complete in %.1fs: %s", elapsed, results)

    return results


def main() -> None:
    """CLI entry point for consolidation."""
    import argparse

    parser = argparse.ArgumentParser(description="Run Shannon-Cortex consolidation pipeline")
    parser.add_argument("--dry-run", action="store_true", help="Report without modifying data")
    parser.add_argument("--skip-reflection", action="store_true", help="Skip LLM reflection")
    parser.add_argument("--skip-conflict", action="store_true", help="Skip conflict resolution")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

    result = run_consolidation(
        dry_run=args.dry_run,
        skip_reflection=args.skip_reflection,
        skip_conflict=args.skip_conflict,
    )

    import json
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
