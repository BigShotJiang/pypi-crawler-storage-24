"""Memory conflict detection and resolution.

Detects contradictory memories (high similarity but opposing content)
and resolves them using recency bias with user-correction priority.

Per MemoryAgentBench (Hu et al., 2025), conflict resolution is the hardest
memory competency — this implementation takes the pragmatic approach.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from enum import Enum

import numpy as np

from shannon_cortex.embedding.base import EmbeddingProvider
from shannon_cortex.storage.qdrant import QdrantStorage

logger = logging.getLogger(__name__)


class ConflictType(str, Enum):
    CONTRADICTORY = "contradictory"  # New info replaces old
    SUPPLEMENTARY = "supplementary"  # New info extends old
    COMPATIBLE = "compatible"        # Both coexist
    IRRELEVANT = "irrelevant"        # No interaction


# Patterns that indicate negation or contradiction
NEGATION_PATTERNS = [
    re.compile(r"\b(not|no longer|don't|doesn't|isn't|aren't|wasn't|weren't|never|stopped)\b", re.I),
    re.compile(r"\b(instead of|rather than|replaced|migrated from|switched from|moved from)\b", re.I),
    re.compile(r"\b(deprecated|removed|deleted|dropped|disabled)\b", re.I),
]

# Patterns that indicate user correction (highest priority)
USER_CORRECTION_PATTERNS = [
    re.compile(r"\b(actually|correction|no,?\s+(it's|use|the)|wrong|incorrect)\b", re.I),
]


def classify_conflict(
    old_content: str,
    new_content: str,
    similarity: float,
) -> ConflictType:
    """Classify the relationship between two memories.

    Uses simple heuristics based on similarity and content patterns.
    """
    if similarity < 0.5:
        return ConflictType.IRRELEVANT

    if similarity < 0.7:
        return ConflictType.COMPATIBLE

    # High similarity — check for contradiction signals
    has_negation = any(p.search(new_content) for p in NEGATION_PATTERNS)
    if has_negation:
        return ConflictType.CONTRADICTORY

    # High similarity without negation — likely supplementary
    if similarity >= 0.85:
        return ConflictType.SUPPLEMENTARY

    return ConflictType.COMPATIBLE


def detect_conflicts(
    storage: QdrantStorage,
    embedding: EmbeddingProvider,
    similarity_threshold: float = 0.8,
    top_k: int = 10,
) -> list[dict]:
    """Scan for potentially conflicting memories.

    For each memory, find highly similar memories and check for contradictions.
    Returns a list of conflict records for review.
    """
    conflicts = []
    offset = None
    seen_pairs: set[tuple[str, str]] = set()

    while True:
        result = storage.client.scroll(
            collection_name=storage.collection_name,
            limit=50,
            offset=offset,
            with_payload=True,
            with_vectors={"dense": True},
        )
        points, next_offset = result

        for point in points:
            payload = point.payload or {}
            content = payload.get("content", "")
            vector = point.vector.get("dense") if isinstance(point.vector, dict) else None

            if vector is None:
                continue

            # Search for similar memories
            similar = storage.dense_search(
                dense_vector=np.array(vector, dtype=np.float32),
                top_k=top_k,
            )

            for sim_point in similar:
                if str(sim_point.id) == str(point.id):
                    continue

                pair_key = tuple(sorted([str(point.id), str(sim_point.id)]))
                if pair_key in seen_pairs:
                    continue
                seen_pairs.add(pair_key)

                sim_payload = sim_point.payload or {}
                sim_content = sim_payload.get("content", "")
                similarity = sim_point.score or 0.0

                if similarity < similarity_threshold:
                    continue

                conflict_type = classify_conflict(content, sim_content, similarity)

                if conflict_type in (ConflictType.CONTRADICTORY, ConflictType.SUPPLEMENTARY):
                    conflicts.append({
                        "type": conflict_type.value,
                        "similarity": similarity,
                        "memory_a": {
                            "id": str(point.id),
                            "content": content[:200],
                            "created_at": payload.get("created_at", ""),
                            "source": payload.get("source", ""),
                        },
                        "memory_b": {
                            "id": str(sim_point.id),
                            "content": sim_content[:200],
                            "created_at": sim_payload.get("created_at", ""),
                            "source": sim_payload.get("source", ""),
                        },
                    })

        if next_offset is None:
            break
        offset = next_offset

    logger.info("Found %d potential conflicts", len(conflicts))
    return conflicts


def resolve_conflicts(
    conflicts: list[dict],
    storage: QdrantStorage,
    dry_run: bool = False,
) -> dict:
    """Resolve detected conflicts.

    Resolution strategy:
    1. User corrections always win regardless of age
    2. For contradictions: newer memory supersedes older
    3. For supplementary: both preserved, older gets importance reduced

    Returns:
        dict with resolution counts
    """
    resolved = 0
    skipped = 0

    for conflict in conflicts:
        if conflict["type"] == "contradictory":
            mem_a = conflict["memory_a"]
            mem_b = conflict["memory_b"]

            # Determine which is newer
            a_time = mem_a.get("created_at", "")
            b_time = mem_b.get("created_at", "")

            # User corrections always win
            a_is_correction = any(p.search(mem_a["content"]) for p in USER_CORRECTION_PATTERNS)
            b_is_correction = any(p.search(mem_b["content"]) for p in USER_CORRECTION_PATTERNS)

            if a_is_correction and not b_is_correction:
                loser_id = mem_b["id"]
            elif b_is_correction and not a_is_correction:
                loser_id = mem_a["id"]
            elif a_time >= b_time:
                loser_id = mem_b["id"]  # Newer wins
            else:
                loser_id = mem_a["id"]

            if not dry_run:
                # Reduce importance of superseded memory
                storage.client.set_payload(
                    collection_name=storage.collection_name,
                    payload={"importance": 1},
                    points=[loser_id],
                )
            resolved += 1
            logger.info("Resolved contradiction: superseded %s", loser_id)

        elif conflict["type"] == "supplementary":
            # Both preserved — just log
            skipped += 1

    return {"resolved": resolved, "skipped": skipped}
