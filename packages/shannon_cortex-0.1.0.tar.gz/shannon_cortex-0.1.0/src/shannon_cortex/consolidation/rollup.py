"""Weekly semantic memory roll-up.

Report Section 8: "Semantic memories from the same knowledge domain are merged
into comprehensive summaries." Prevents redundant accumulation over months.
"""

from __future__ import annotations

import logging
import uuid
from collections import defaultdict
from datetime import datetime, timezone

import numpy as np

from shannon_cortex.embedding.base import EmbeddingProvider
from shannon_cortex.models.memory import MemoryType, SemanticMemory
from shannon_cortex.storage.markdown import MarkdownStorage
from shannon_cortex.storage.qdrant import QdrantStorage

logger = logging.getLogger(__name__)

ROLLUP_PROMPT = """You are merging multiple related semantic memories into one comprehensive summary.
Preserve all unique information, technical details, and specifics.
Output a single clear paragraph (3-5 sentences).

Memories to merge:
{memories}

Merged summary:"""


def run_weekly_rollup(
    storage: QdrantStorage,
    markdown: MarkdownStorage,
    embedding: EmbeddingProvider,
    min_domain_size: int = 3,
    similarity_threshold: float = 0.8,
    dry_run: bool = False,
) -> dict:
    """Merge redundant semantic memories within the same domain.

    Steps:
    1. Scroll through all semantic memories
    2. Group by domain
    3. For domains with >min_domain_size memories, cluster by similarity
    4. For clusters with >2 members, merge via LLM
    5. Replace cluster members with merged memory
    """
    from shannon_cortex import llm
    from shannon_cortex.consolidation.reflection import cluster_memories

    # 1. Collect all semantic memories
    semantic_memories = []
    offset = None

    while True:
        result = storage.client.scroll(
            collection_name=storage.collection_name,
            limit=100,
            offset=offset,
            scroll_filter={
                "must": [{"key": "memory_type", "match": {"value": "semantic"}}]
            } if False else None,  # Use proper filter below
            with_payload=True,
            with_vectors={"dense": True},
        )
        points, next_offset = result

        for point in points:
            payload = point.payload or {}
            if payload.get("memory_type") != "semantic":
                continue
            semantic_memories.append({
                "id": str(point.id),
                "content": payload.get("content", ""),
                "domain": payload.get("domain", "general"),
                "importance": payload.get("importance", 5),
                "provenance": payload.get("provenance", []),
                "vector": point.vector.get("dense") if isinstance(point.vector, dict) else None,
            })

        if next_offset is None:
            break
        offset = next_offset

    if not semantic_memories:
        return {"semantic_count": 0, "domains": 0, "merged": 0}

    # 2. Group by domain
    by_domain: dict[str, list] = defaultdict(list)
    for mem in semantic_memories:
        by_domain[mem["domain"]].append(mem)

    merged_count = 0
    archived_ids = []

    for domain, members in by_domain.items():
        if len(members) < min_domain_size:
            continue

        # 3. Cluster by similarity within domain
        vectors = [m["vector"] for m in members if m["vector"] is not None]
        if len(vectors) < min_domain_size:
            continue

        embeddings = np.array(vectors, dtype=np.float32)
        clusters = cluster_memories(embeddings, threshold=similarity_threshold)

        for cluster_indices in clusters:
            if len(cluster_indices) < 2:
                continue

            cluster_mems = [members[i] for i in cluster_indices]
            cluster_texts = [m["content"] for m in cluster_mems]

            # 4. Merge via LLM
            memories_text = "\n".join(f"- {t}" for t in cluster_texts)
            prompt = ROLLUP_PROMPT.format(memories=memories_text)

            if dry_run:
                merged_text = f"[DRY RUN] Would merge {len(cluster_mems)} memories in domain '{domain}'"
            else:
                merged_text = llm.generate(prompt, max_new_tokens=300)

            if not merged_text:
                continue

            # Collect all provenance
            all_provenance = []
            for m in cluster_mems:
                all_provenance.extend(m.get("provenance", []))
                all_provenance.append(m["id"])

            # 5. Create merged memory
            max_importance = max(m["importance"] for m in cluster_mems)
            merged = SemanticMemory(
                id=str(uuid.uuid4()),
                content=merged_text,
                importance=min(max_importance + 1, 10),
                source="rollup",
                domain=domain,
                provenance=list(set(all_provenance)),
            )

            if not dry_run:
                vector = embedding.embed_single(merged.content)
                storage.upsert(memory=merged, dense_vector=vector)
                markdown.append(merged)

                # Archive old members
                for m in cluster_mems:
                    storage.delete(m["id"])
                    archived_ids.append(m["id"])

            merged_count += 1
            logger.info("Rolled up %d semantic memories in domain '%s'", len(cluster_mems), domain)

    result = {
        "semantic_count": len(semantic_memories),
        "domains": len(by_domain),
        "merged": merged_count,
        "archived": len(archived_ids),
    }
    logger.info("Weekly rollup: %s", result)
    return result
