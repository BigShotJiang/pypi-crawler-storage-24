"""Shannon-Cortex: Persistent long-term memory for Claude Code."""

__version__ = "0.1.0"
