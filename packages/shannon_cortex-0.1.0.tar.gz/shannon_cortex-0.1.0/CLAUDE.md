# Shannon-Cortex

Persistent long-term memory augmentation for Claude Code.

## Project Structure

- `src/shannon_cortex/` — Main Python package
- `hooks/` — Claude Code hook shell scripts (wrappers that talk to daemon via UDS)
- `scripts/` — Installation and setup scripts
- `systemd/` — Systemd user service unit
- `tests/` — Test suite

## Architecture

- **Daemon**: FastAPI on Unix domain socket (`/run/user/{uid}/shannon-cortex.sock`)
- **Embedding**: Qwen3-Embedding-0.6B via sentence-transformers (GPU, 768-dim Matryoshka)
- **Vector DB**: Qdrant collection `shannon_cortex_memories` (dense + BM25 hybrid search, RRF fusion)
- **Reranker**: NIM llama-3.2-nv-rerankqa-1b-v2 at localhost:8000
- **Source of truth**: Markdown files at `~/.shannon-cortex/memory/`
- **Three memory types**: episodic (events), semantic (facts), procedural (how-to)

## Development

```bash
# Activate venv
source ~/.venvs/shannon-cortex/bin/activate

# Install in dev mode
pip install -e ".[all]"

# Run tests
pytest

# Run daemon
shannon-cortex start
```

## Key Conventions

- Config via `~/.shannon-cortex/config.yaml` + `SC_` env vars
- All Qdrant operations isolated to `shannon_cortex_memories` collection — never touch `nvda_articles`
- Hook latency budget: <150ms for UserPromptSubmit (sync path)
- Importance scoring: 1-10 scale, store only ≥3, inject only ≥5
