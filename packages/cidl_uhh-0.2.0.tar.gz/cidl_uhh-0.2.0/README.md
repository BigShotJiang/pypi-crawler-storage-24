# CIDL - Causal Inference Data Library

CIDL is a read-only Python library for accessing remotely hosted benchmark datasets for causal inference research. It provides a structured and reproducible interface for loading simulation datasets, aligned ground-truth artifacts, and dataset metadata.

The current release focuses on the Atlantic Causal Inference Conference 2022 Data Challenge (ACIC22). CIDL is designed as a broader framework and may support additional dataset contexts in future versions.

Important: CIDL does not include the benchmark datasets themselves. The package provides access logic only. Dataset artifacts are hosted remotely and require separate read-only access credentials.

#### What CIDL provides

CIDL supports:

- index-based dataset selection
- loading simulation datasets
- loading aligned ground-truth artifacts
- sequential iteration over many dataset instances
- local download of selected datasets
- access to dataset metadata and context information

The package is intended for researchers who want reproducible access to benchmark data for developing and evaluating causal inference methods.

#### Installation

Install CIDL via PyPI using `pip install cidl-uhh`. Import the package with `import cidl`.

#### Access requirements

CIDL uses an S3-compatible object store as backend, to host the datasets. Access is credential-based. To request credentials for read-only access, follow:
[ACIC22 — Access Configuration (S3)](https://github.com/JDenzel-UHH/CIDL/blob/main/documentation/ACIC22%20-%20Access%20Configuration%20(S3).md)

#### Documentation
For an overview of the ACIC22 datasets (structure, variables, DGPs, target estimands), see:  
[ACIC22 — Data Info](https://github.com/JDenzel-UHH/CIDL/blob/main/documentation/ACIC22%20-%20Data%20Info.md)


#### Hands-on examples
- [Quickstart.py](https://github.com/JDenzel-UHH/CIDL/blob/main/example/Quickstart.py) — minimal “works end-to-end” example

#### Scope

CIDL is a data access library. It is not an estimator library, an evaluation framework, a data-hosting platform, or a credential management system.

#### Naming convention

ACIC22 refers specifically to the ACIC 2022 Data Challenge dataset collection. CIDL refers to the broader library/framework.

#### License

This project is licensed under the MIT License.

#### Authors

Julian Denzel
Master’s Thesis Project, University of Hamburg
julian.denzel@studium.uni-hamburg.de

Martin Spindler
Head of the Data Science Chair, University of Hamburg Business School
martin.spindler@uni-hamburg.de

First issued: April 2026