"""
CIDL - Causal Inference Data Library

CIDL provides structured, read-only access to remotely hosted benchmark
datasets for causal inference evaluation. The package currently exposes
helpers for:

- connecting to the configured S3-compatible object store,
- loading simulation datasets,
- loading aligned ground-truth artifacts,
- selecting dataset indices,
- retrieving metadata and dataset information,
- switching between supported dataset contexts via configuration.

Example:
    >>> import cidl
    >>> datasets = cidl.load_datasets([1, 2, 3])
    >>> truth = cidl.load_truth([1, 2, 3])
    >>> info = cidl.get_datainfo()
"""

from __future__ import annotations

__version__ = "0.1.0"
__author__ = "Julian Denzel"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------

from .connection import (
    ENDPOINTS,
    bucket,
    connect_s3,
    healthcheck,
    reset_connection,
)


# ---------------------------------------------------------------------------
# Dataset loading
# ---------------------------------------------------------------------------

from .data_loader import (
    download_datasets,
    download_key,
    iter_datasets,
    load_datasets,
    load_parquet_key,
)


# ---------------------------------------------------------------------------
# Truth loading
# ---------------------------------------------------------------------------

from .truth_loader import (
    load_truth,
    clear_cache as clear_truth_cache,
)


# ---------------------------------------------------------------------------
# Metadata and dataset information
# ---------------------------------------------------------------------------

from .metadata_info import (
    get_datainfo,
    get_available_datasets,
    get_available_prefixes,
    clear_cache as clear_metadata_cache,
)


# ---------------------------------------------------------------------------
# Index selection
# ---------------------------------------------------------------------------

from .indices_selection import (
    select_indices,
    select_indices_difficulty,
    select_indices_specific,
    clear_cache as clear_index_cache,
)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

from .config import (
    get_config,
    reset_config,
)


# ---------------------------------------------------------------------------
# Submodule access
# ---------------------------------------------------------------------------

from . import connection
from . import config
from . import data_loader
from . import indices_selection
from . import metadata_info
from . import truth_loader


__all__ = [
    # Package metadata
    "__version__",
    "__author__",

    # Connection
    "ENDPOINTS",
    "connect_s3",
    "bucket",
    "healthcheck",
    "reset_connection",

    # Dataset loading
    "load_datasets",
    "iter_datasets",
    "download_datasets",
    "load_parquet_key",
    "download_key",

    # Truth loading
    "load_truth",
    "clear_truth_cache",

    # Metadata and dataset information
    "get_datainfo",
    "get_available_prefixes",
    "get_available_datasets",
    "clear_metadata_cache",

    # Index selection
    "select_indices",
    "select_indices_difficulty",
    "select_indices_specific",
    "clear_index_cache",

    # Configuration
    "get_config",
    "reset_config",

    # Submodules
    "connection",
    "config",
    "data_loader",
    "indices_selection",
    "metadata_info",
    "truth_loader",
]