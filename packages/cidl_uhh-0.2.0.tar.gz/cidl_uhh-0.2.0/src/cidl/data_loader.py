"""
data_loader.py (CIDL)

Dataset loading helpers for CIDL.

This module provides the main public loading API for simulation datasets stored
in S3-compatible object storage. It supports three access modes:
in-memory loading, iterator-based sequential loading, and direct download to
local disk. In addition, two generic helpers are provided for working with
arbitrary parquet objects or object keys.

Public dataset API:
- load_datasets(indices, ...): load one or more datasets into RAM
- iter_datasets(indices, ...): iterate over datasets sequentially
- download_datasets(indices, ...): download parquet files to a local directory

Generic helpers:
- load_parquet_key(key, ...): load a parquet object by full S3 key
- download_key(key, local_path): download an arbitrary S3 object by full key

Dataset context convention:
- The active dataset root prefix is resolved via ``cidl.config.get_config()``
  (environment variable ``CIDL_PREFIX``; default: ``"acic22"``).
- An optional ``prefix="<PREFIX>"`` argument may be used to switch dataset
  contexts explicitly.
- The metadata location follows a fixed convention and is always derived as:
    <PREFIX>/metadata/<PREFIX>_metadata.json
"""

from __future__ import annotations

import json
import numbers
from io import BytesIO
from pathlib import Path
from typing import Any, Iterator

import pandas as pd

import cidl.config as cfg
import cidl.connection as con


# ---------------------------------------------------------------------------
# Metadata cache
# ---------------------------------------------------------------------------

# Small and safe metadata cache:
# metadata_key -> (metadata_header_dict, item_map)
# Only parsed metadata is cached, never parquet bytes.
_META_CACHE: dict[str, tuple[dict[str, Any], dict[int, dict[str, Any]]]] = {}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _to_int_list(indices) -> list[int]:
    """Normalize a single index or iterable of indices to a list of ints."""
    if isinstance(indices, numbers.Integral):
        return [int(indices)]
    return [int(index) for index in indices]


def _clean_dataset_prefix(prefix: str) -> str:
    """Normalize and validate a dataset root prefix.

    Args:
        prefix: Dataset root prefix, e.g. ``"acic22"``.

    Returns:
        The cleaned dataset prefix.

    Raises:
        ValueError: If the prefix is empty or path-like.
    """
    cleaned = (prefix or "").strip().lstrip("/").rstrip("/")

    if not cleaned:
        raise ValueError("prefix must be a non-empty string.")

    # Disallow path-like values to prevent ambiguity and enforce the contract.
    if "/" in cleaned:
        raise ValueError(
            "prefix must be a dataset root like 'acic22' (no '/'). "
            "Do not pass '.../simulations/...'."
        )

    return cleaned


def _join(prefix: str, name: str) -> str:
    """Join an S3 prefix and a relative object name safely."""
    return prefix.rstrip("/") + "/" + name.lstrip("/")


def _read_json_s3_or_local(source: str) -> Any:
    """Read JSON content from either a local path or an S3 object key."""
    path = Path(source)
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))

    buffer = BytesIO()
    con.bucket().Object(source).download_fileobj(buffer)
    raw = buffer.getvalue()

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("utf-8-sig")

    return json.loads(text)


def _validate_and_index_items(
    header: dict[str, Any],
    *,
    ds_root: str,
) -> dict[int, dict[str, Any]]:
    """Validate metadata fields and build an index-to-record mapping.

    Args:
        header: Parsed metadata object.
        ds_root: Expected dataset root prefix.

    Returns:
        A mapping from dataset index to metadata item record.

    Raises:
        ValueError: If the metadata contract is violated.
    """
    if not isinstance(header, dict):
        raise ValueError("Metadata must be a JSON object (dict).")

    schema_version = header.get("schema_version")
    if schema_version != 1:
        raise ValueError(f"Unsupported schema_version={schema_version!r}. Expected 1.")

    meta_prefix = header.get("prefix")
    if not isinstance(meta_prefix, str) or not meta_prefix.strip():
        raise ValueError("Metadata must contain a non-empty 'prefix' string.")
    if meta_prefix.strip().strip("/") != ds_root:
        raise ValueError(
            f"Metadata prefix mismatch: expected prefix='{ds_root}', found prefix='{meta_prefix}'."
        )

    simulations_prefix = header.get("simulations_prefix")
    if not isinstance(simulations_prefix, str) or not simulations_prefix.strip():
        raise ValueError("Metadata must contain a non-empty 'simulations_prefix' string.")

    items = header.get("items")
    if not isinstance(items, list) or len(items) == 0:
        raise ValueError("Metadata must contain a non-empty 'items' list.")

    out: dict[int, dict[str, Any]] = {}

    for record in items:
        if not isinstance(record, dict):
            raise ValueError("Each entry in 'items' must be a JSON object (dict).")

        if "index" not in record:
            raise ValueError("Each item must contain an 'index'.")

        try:
            idx = int(record["index"])
        except Exception:
            raise ValueError(f"Item index must be int-like, got: {record.get('index')!r}")

        if idx < 1:
            raise ValueError(f"Item index must be >= 1, got: {idx}")
        if idx in out:
            raise ValueError(f"Duplicate index in metadata items: {idx}")

        filename = record.get("filename")
        if not isinstance(filename, str) or not filename.strip():
            raise ValueError(f"Item {idx} must contain a non-empty 'filename' string.")

        uuid = record.get("uuid")
        if not isinstance(uuid, str) or not uuid.strip():
            raise ValueError(f"Item {idx} must contain a non-empty 'uuid' string.")

        # truth is optional
        truth = record.get("truth")
        if truth is not None and (not isinstance(truth, str) or not truth.strip()):
            raise ValueError(f"Item {idx} has invalid 'truth' (must be non-empty string if present).")

        out[idx] = record

    return out


def _load_metadata(
    metadata_key: str,
    *,
    expected_prefix: str,
    use_cache: bool = True,
) -> tuple[dict[str, Any], dict[int, dict[str, Any]]]:
    """Load and validate metadata under the fixed dataset convention.

    Args:
        metadata_key: Metadata object key or local path.
        expected_prefix: Expected dataset root prefix.
        use_cache: If True, reuse cached parsed metadata.

    Returns:
        A tuple of ``(metadata_header, item_map)``.
    """
    if use_cache and metadata_key in _META_CACHE:
        header, item_map = _META_CACHE[metadata_key]

        # Still enforce that cached metadata matches the expected prefix.
        _validate_and_index_items(header, ds_root=expected_prefix)
        return header, item_map

    header = _read_json_s3_or_local(metadata_key)
    if not isinstance(header, dict):
        raise ValueError("Metadata must be a JSON object (dict) at the top level.")

    item_map = _validate_and_index_items(header, ds_root=expected_prefix)

    if use_cache:
        _META_CACHE[metadata_key] = (header, item_map)

    return header, item_map


def _resolve_context(*, prefix: str | None) -> tuple[str, str]:
    """Resolve dataset root prefix and metadata key.

    Args:
        prefix: Optional explicit dataset root prefix.

    Returns:
        A tuple ``(dataset_root, metadata_key)``.
    """
    if prefix is None:
        config = cfg.get_config()
        ds_root = _clean_dataset_prefix(config.prefix)
    else:
        ds_root = _clean_dataset_prefix(prefix)

    # Hard convention: metadata key is always derived from the dataset prefix.
    metadata_key = cfg.standard_metadata_key(ds_root)
    return ds_root, metadata_key


def _download_fileobj(key: str) -> BytesIO:
    """Download an S3 object into an in-memory buffer."""
    buffer = BytesIO()
    con.bucket().Object(key).download_fileobj(buffer)
    buffer.seek(0)
    return buffer


def _read_parquet(buffer: BytesIO, *, columns: list[str] | None = None) -> pd.DataFrame:
    """Read a parquet file from an in-memory buffer into a DataFrame."""
    buffer.seek(0)
    return pd.read_parquet(buffer, columns=columns)


# ---------------------------------------------------------------------------
# Generic public helpers
# ---------------------------------------------------------------------------

def load_parquet_key(key: str, *, columns: list[str] | None = None) -> pd.DataFrame:
    """Load a parquet object from a full S3 key."""
    return _read_parquet(_download_fileobj(key), columns=columns)


def download_key(key: str, local_path: str | Path, *, overwrite: bool = False) -> Path:
    """Download an arbitrary S3 object by full key to a local file path."""
    destination = Path(local_path)
    destination.parent.mkdir(parents=True, exist_ok=True)

    if destination.exists() and not overwrite:
        return destination
    if destination.exists() and overwrite:
        destination.unlink()

    con.bucket().Object(key).download_file(str(destination))
    return destination


# ---------------------------------------------------------------------------
# Dataset API
# ---------------------------------------------------------------------------

def load_datasets(
    indices,
    *,
    prefix: str | None = None,
    use_cache_meta: bool = True,
    max_n: int = 20,
    columns: list[str] | None = None,
) -> dict[int, pd.DataFrame]:
    """Load one or more simulation datasets into RAM.

    Args:
        indices: Single index or iterable of dataset indices.
        prefix: Optional explicit dataset root prefix.
        use_cache_meta: If True, reuse cached metadata.
        max_n: Maximum number of datasets to materialize in memory.
        columns: Optional column subset passed to ``pandas.read_parquet``.

    Returns:
        A dictionary mapping dataset indices to DataFrames.
    """
    idx_list = _to_int_list(indices)
    if len(idx_list) == 0:
        return {}

    if len(idx_list) > max_n:
        raise ValueError(
            f"Attempting to load {len(idx_list)} datasets into RAM (max_n={max_n}). "
            "Use iter_datasets(...) or increase max_n explicitly."
        )

    ds_root, metadata_key = _resolve_context(prefix=prefix)
    header, metadata = _load_metadata(
        metadata_key,
        expected_prefix=ds_root,
        use_cache=use_cache_meta,
    )

    simulations_prefix = str(header["simulations_prefix"]).strip()
    if not simulations_prefix.endswith("/"):
        simulations_prefix += "/"

    out: dict[int, pd.DataFrame] = {}
    for idx in idx_list:
        if idx not in metadata:
            raise KeyError(f"Index {idx} not found in metadata items for prefix '{ds_root}'.")

        filename = metadata[idx]["filename"]
        key = _join(simulations_prefix, filename)
        out[idx] = load_parquet_key(key, columns=columns)

    return out


def iter_datasets(
    indices,
    *,
    prefix: str | None = None,
    use_cache_meta: bool = True,
    columns: list[str] | None = None,
    on_error: str = "raise",
) -> Iterator[tuple[int, pd.DataFrame]]:
    """Iterate over simulation datasets one by one.

    Args:
        indices: Single index or iterable of dataset indices.
        prefix: Optional explicit dataset root prefix.
        use_cache_meta: If True, reuse cached metadata.
        columns: Optional column subset passed to ``pandas.read_parquet``.
        on_error: Error policy, either ``"raise"`` or ``"skip"``.

    Returns:
        An iterator yielding ``(index, DataFrame)`` tuples.
    """
    if on_error not in {"raise", "skip"}:
        raise ValueError("on_error must be one of {'raise','skip'}.")

    idx_list = _to_int_list(indices)
    if len(idx_list) == 0:
        return iter(())

    ds_root, metadata_key = _resolve_context(prefix=prefix)
    header, metadata = _load_metadata(
        metadata_key,
        expected_prefix=ds_root,
        use_cache=use_cache_meta,
    )

    simulations_prefix = str(header["simulations_prefix"]).strip()
    if not simulations_prefix.endswith("/"):
        simulations_prefix += "/"

    def _generator():
        for idx in idx_list:
            try:
                if idx not in metadata:
                    raise KeyError(f"Index {idx} not found in metadata items for prefix '{ds_root}'.")

                filename = metadata[idx]["filename"]
                key = _join(simulations_prefix, filename)
                yield idx, load_parquet_key(key, columns=columns)
            except Exception as exc:
                if on_error == "skip":
                    print(f"[skip] idx={idx}: {exc}")
                    continue
                raise

    return _generator()


def download_datasets(
    indices,
    local_dir: str | Path,
    *,
    prefix: str | None = None,
    use_cache_meta: bool = True,
    overwrite: bool = False,
    skip_existing: bool = True,
) -> list[Path]:
    """Download one or more dataset parquet files to a local directory.

    Args:
        indices: Single index or iterable of dataset indices.
        local_dir: Target local directory.
        prefix: Optional explicit dataset root prefix.
        use_cache_meta: If True, reuse cached metadata.
        overwrite: If True, remove existing files before downloading.
        skip_existing: If True, leave existing files untouched unless
            ``overwrite=True``.

    Returns:
        A list of written local file paths.
    """
    idx_list = _to_int_list(indices)
    if len(idx_list) == 0:
        return []

    local_dir = Path(local_dir)
    local_dir.mkdir(parents=True, exist_ok=True)

    ds_root, metadata_key = _resolve_context(prefix=prefix)
    header, metadata = _load_metadata(
        metadata_key,
        expected_prefix=ds_root,
        use_cache=use_cache_meta,
    )

    simulations_prefix = str(header["simulations_prefix"]).strip()
    if not simulations_prefix.endswith("/"):
        simulations_prefix += "/"

    written: list[Path] = []

    for idx in idx_list:
        if idx not in metadata:
            raise KeyError(f"Index {idx} not found in metadata items for prefix '{ds_root}'.")

        filename = metadata[idx]["filename"]
        key = _join(simulations_prefix, filename)

        # Download to: local_dir / <basename>
        destination = local_dir / Path(filename).name

        if destination.exists():
            if skip_existing and not overwrite:
                continue
            if overwrite:
                destination.unlink()

        con.bucket().Object(key).download_file(str(destination))
        written.append(destination)

    return written


__all__ = [
    "load_datasets",
    "iter_datasets",
    "download_datasets",
    "load_parquet_key",
    "download_key",
]