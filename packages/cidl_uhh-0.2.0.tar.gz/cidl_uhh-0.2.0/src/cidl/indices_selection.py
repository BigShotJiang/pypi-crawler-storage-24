"""
indices_selection.py (CIDL)

Dataset index selection helpers for CIDL.

This module provides both dataset-agnostic and ACIC22-specific helpers for
selecting dataset indices. Generic selection is based on the metadata contract
of the active dataset context. Additional ACIC22 convenience selectors support
sampling by difficulty tier or by specific DGP characteristics.

Public API:
- select_indices: dataset-agnostic sampling via
  <PREFIX>/metadata/<PREFIX>_metadata.json
- select_indices_difficulty: ACIC22-only convenience selector
  (difficulty tier)
- select_indices_specific: ACIC22-only convenience selector
  (DGP knob configuration)

Notes:
- Generic selection reads indices from metadata['items'][].index and does not
  assume contiguous indices from 1..N.
- ACIC22-specific selectors require prefix == "acic22".
"""

from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Any, Iterable

import cidl.config as config
import cidl.connection as con


# ---------------------------------------------------------------------------
# ACIC22-only constants
# ---------------------------------------------------------------------------

_ACIC22_DGP_INFO_KEY = "acic22/metadata/acic22_dgp_info.json"

VALID_DIFFICULTY_LEVELS = {"all", "very_easy", "easy", "medium", "hard", "very_hard"}

VALID_CONFOUNDING_STRENGTH = {"none", "weak", "strong"}
VALID_CONFOUNDING_SOURCE = {"none", "A", "B"}
VALID_IMPACT_HETEROGENEITY = {"small", "large"}
VALID_IDIOSYNCRASY_IMPACTS = {"small", "large"}

VALID_ANY = {"any", "all", "*"}

MAP_CONFOUNDING_STRENGTH = {"none": "None", "weak": "Weak", "strong": "Strong"}
MAP_CONFOUNDING_SOURCE = {"none": "None", "A": "Scenario A", "B": "Scenario B"}
MAP_SIZE = {"small": "Small", "large": "Large"}


# ---------------------------------------------------------------------------
# JSON cache
# ---------------------------------------------------------------------------

_JSON_CACHE: dict[str, object] = {}


def clear_cache() -> None:
    """Clear the in-memory JSON cache.

    This is mainly useful during development or in tests where a fresh read of
    metadata or DGP information is desired.
    """
    _JSON_CACHE.clear()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _clean_root_prefix(prefix: str) -> str:
    """Normalize and validate a dataset root prefix.

    Args:
        prefix: Dataset root prefix such as ``"acic22"``.

    Returns:
        A cleaned dataset root prefix without leading or trailing slashes.

    Raises:
        ValueError: If the prefix is empty or contains ``"/"``.
    """
    cleaned = (prefix or "").strip().strip("/")

    if not cleaned or "/" in cleaned:
        raise ValueError("prefix must be a dataset root like 'acic22' (no '/').")

    return cleaned


def _metadata_key(prefix_root: str) -> str:
    """Construct the standard metadata key for a dataset root prefix."""
    cleaned_prefix = _clean_root_prefix(prefix_root)
    return f"{cleaned_prefix}/metadata/{cleaned_prefix}_metadata.json"


def _read_json(source: str, *, use_cache: bool = True) -> object:
    """Read JSON either from a local path or from the configured S3 bucket.

    Args:
        source: Local path or object key.
        use_cache: If True, reuse previously loaded JSON objects.

    Returns:
        The parsed JSON object.
    """
    if use_cache and source in _JSON_CACHE:
        return _JSON_CACHE[source]

    path = Path(source)
    if path.exists():
        obj = json.loads(path.read_text(encoding="utf-8"))
    else:
        raw = con.bucket().Object(source).get()["Body"].read()
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("utf-8-sig")
        obj = json.loads(text)

    if use_cache:
        _JSON_CACHE[source] = obj

    return obj


def _unique_sorted_ints(values: Iterable[object]) -> list[int]:
    """Convert values to unique integers and return them in sorted order."""
    return sorted({int(value) for value in values})


def _sample(population: list[int], n: int | None, seed: int | None) -> list[int]:
    """Sample indices from a population in a reproducible way.

    Args:
        population: Available dataset indices.
        n: Number of indices to sample. If ``None``, return all.
        seed: Optional random seed.

    Returns:
        A sorted list of selected indices.

    Raises:
        ValueError: If ``n`` is invalid or exceeds the available population.
    """
    pop = sorted(set(population))

    if n is None:
        return pop
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer (or None for all).")
    if n > len(pop):
        raise ValueError(f"Requested n={n}, but only {len(pop)} indices are available.")

    rng = random.Random(seed)
    out = rng.sample(pop, k=n)
    out.sort()
    return out


def _validate_one(name: str, value: str, allowed: set[str]) -> None:
    """Validate a single selector argument against an allowed set."""
    if value not in allowed:
        raise ValueError(f"{name} must be one of {sorted(allowed)}. Got: {value!r}")


def _is_any(value: str) -> bool:
    """Return whether a selector value means 'no restriction'."""
    return value in VALID_ANY


def _require_acic22(prefix_root: str) -> None:
    """Ensure that an ACIC22-only selector is used with the ACIC22 prefix."""
    if prefix_root != "acic22":
        raise ValueError(
            "This selector is ACIC22-only (requires ACIC22 DGP metadata). "
            "Use select_indices(...) for generic datasets."
        )


def _load_indices_from_metadata(prefix_root: str, *, use_cache: bool = True) -> list[int]:
    """Load and validate dataset indices from metadata."""
    key = _metadata_key(prefix_root)
    meta = _read_json(key, use_cache=use_cache)

    if not isinstance(meta, dict):
        raise ValueError("Metadata must be a JSON object (dict) at the top level.")

    items = meta.get("items")
    if not isinstance(items, list) or not items:
        raise ValueError("Metadata must contain a non-empty 'items' list.")

    out: list[int] = []
    seen: set[int] = set()

    for rec in items:
        if not isinstance(rec, dict) or "index" not in rec:
            raise ValueError("Each item in metadata['items'] must be an object with an 'index'.")

        idx = int(rec["index"])
        if idx < 1:
            raise ValueError(f"Item index must be >= 1, got: {idx}")
        if idx in seen:
            raise ValueError(f"Duplicate index in metadata items: {idx}")

        seen.add(idx)
        out.append(idx)

    out.sort()
    return out


def _load_dgp_list(*, use_cache: bool = True) -> list[dict[str, Any]]:
    """Load and validate the ACIC22 DGP information list."""
    obj = _read_json(_ACIC22_DGP_INFO_KEY, use_cache=use_cache)

    if not isinstance(obj, dict) or "dgps" not in obj or not isinstance(obj["dgps"], list):
        raise ValueError("acic22_dgp_info.json must be a dict with a list field 'dgps'.")

    return obj["dgps"]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def select_indices(
    n: int | None = 10,
    seed: int | None = None,
    *,
    prefix: str | None = None,
    use_cache: bool = True,
) -> list[int]:
    """Select dataset indices generically via the metadata contract.

    Args:
        n: Number of indices to sample. If ``None``, return all available
            indices.
        seed: Optional random seed for reproducible sampling.
        prefix: Optional dataset root prefix. If omitted, the active configured
            prefix is used.
        use_cache: If True, reuse cached JSON metadata.

    Returns:
        A sorted list of selected dataset indices.
    """
    dataset_root = _clean_root_prefix(prefix or config.get_config().prefix)
    indices = _load_indices_from_metadata(dataset_root, use_cache=use_cache)
    return _sample(indices, n=n, seed=seed)


def select_indices_difficulty(
    n: int | None = 10,
    seed: int | None = None,
    difficulty: str = "all",
    *,
    prefix: str | None = None,
    use_cache: bool = True,
) -> list[int]:
    """Select ACIC22 dataset indices by difficulty tier.

    Args:
        n: Number of indices to sample. If ``None``, return all eligible
            indices.
        seed: Optional random seed for reproducible sampling.
        difficulty: Difficulty tier to select from.
        prefix: Optional dataset root prefix. Must resolve to ``"acic22"``.
        use_cache: If True, reuse cached JSON metadata.

    Returns:
        A sorted list of selected ACIC22 dataset indices.
    """
    dataset_root = _clean_root_prefix(prefix or config.get_config().prefix)
    _require_acic22(dataset_root)

    _validate_one("difficulty", difficulty, VALID_DIFFICULTY_LEVELS)
    dgps = _load_dgp_list(use_cache=use_cache)

    eligible: list[int] = []
    for rec in dgps:
        tier = rec.get("difficulty_tier")
        if tier is None:
            continue
        if difficulty != "all" and tier != difficulty:
            continue
        eligible.extend(rec.get("dataset_ids", []))

    return _sample(_unique_sorted_ints(eligible), n=n, seed=seed)


def select_indices_specific(
    n: int | None = 10,
    seed: int | None = None,
    *,
    confounding_strength: str = "any",
    confounding_source: str = "any",
    impact_heterogeneity: str = "any",
    idiosyncrasy_impacts: str = "any",
    prefix: str | None = None,
    use_cache: bool = True,
) -> list[int]:
    """Select ACIC22 dataset indices by partial DGP knob configuration.

    Args:
        n: Number of indices to sample. If ``None``, return all eligible
            indices.
        seed: Optional random seed for reproducible sampling.
        confounding_strength: Desired confounding strength or unrestricted value.
        confounding_source: Desired confounding source or unrestricted value.
        impact_heterogeneity: Desired impact heterogeneity or unrestricted value.
        idiosyncrasy_impacts: Desired idiosyncrasy-of-impacts setting or
            unrestricted value.
        prefix: Optional dataset root prefix. Must resolve to ``"acic22"``.
        use_cache: If True, reuse cached JSON metadata.

    Returns:
        A sorted list of selected ACIC22 dataset indices.
    """
    dataset_root = _clean_root_prefix(prefix or config.get_config().prefix)
    _require_acic22(dataset_root)

    if not _is_any(confounding_strength):
        _validate_one("confounding_strength", confounding_strength, VALID_CONFOUNDING_STRENGTH)
    if not _is_any(confounding_source):
        _validate_one("confounding_source", confounding_source, VALID_CONFOUNDING_SOURCE)
    if not _is_any(impact_heterogeneity):
        _validate_one("impact_heterogeneity", impact_heterogeneity, VALID_IMPACT_HETEROGENEITY)
    if not _is_any(idiosyncrasy_impacts):
        _validate_one("idiosyncrasy_impacts", idiosyncrasy_impacts, VALID_IDIOSYNCRASY_IMPACTS)

    cs_json = None if _is_any(confounding_strength) else MAP_CONFOUNDING_STRENGTH[confounding_strength]
    src_json = None if _is_any(confounding_source) else MAP_CONFOUNDING_SOURCE[confounding_source]
    het_json = None if _is_any(impact_heterogeneity) else MAP_SIZE[impact_heterogeneity]
    ido_json = None if _is_any(idiosyncrasy_impacts) else MAP_SIZE[idiosyncrasy_impacts]

    dgps = _load_dgp_list(use_cache=use_cache)

    eligible: list[int] = []
    for rec in dgps:
        if cs_json is not None and rec.get("confounding_strength") != cs_json:
            continue
        if src_json is not None and rec.get("confounding_source") != src_json:
            continue
        if het_json is not None and rec.get("impact_heterogeneity") != het_json:
            continue
        if ido_json is not None and rec.get("idiosyncrasy_of_impacts") != ido_json:
            continue
        eligible.extend(rec.get("dataset_ids", []))

    return _sample(_unique_sorted_ints(eligible), n=n, seed=seed)


__all__ = [
    "select_indices",
    "select_indices_difficulty",
    "select_indices_specific",
    "clear_cache",
]