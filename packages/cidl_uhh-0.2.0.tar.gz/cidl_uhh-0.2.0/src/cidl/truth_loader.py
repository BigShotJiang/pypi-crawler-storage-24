"""
truth_loader.py (CIDL)

Ground-truth loading helpers for CIDL.

This module provides index-based loading of ground-truth parquet files for the
currently active dataset context. Truth objects are resolved via the dataset
metadata contract, analogously to ``data_loader.py``. This allows context
switching across supported dataset prefixes without changing user-facing loader
calls.

Public API:
- load_truth(indices, ...): load one or more truth files into RAM
- clear_cache(): clear cached truth DataFrames and parsed metadata

Dataset context convention:
- The active dataset root prefix is resolved via ``cidl.config.get_config()``
  (environment variable ``CIDL_PREFIX``; default: ``"acic22"``).
- An optional ``prefix="<PREFIX>"`` argument may be used to switch dataset
  contexts explicitly.
- The metadata location follows a fixed convention and is always derived as:
    <PREFIX>/metadata/<PREFIX>_metadata.json

Truth resolution:
- Preferred: use the optional ``truth`` field from the corresponding metadata
  item.
- Fallback: derive the default truth key as:
    <PREFIX>/truth/truth_<INDEX>.parquet
"""

from __future__ import annotations

import json
import numbers
import warnings
from io import BytesIO
from pathlib import Path
from typing import Any

import pandas as pd
from botocore.exceptions import ClientError

import cidl.config as cfg
import cidl.connection as con




# ---------------------------------------------------------------------------
# Caches
# ---------------------------------------------------------------------------

# Tiny truth files -> safe to cache by default
_TRUTH_CACHE: dict[str, pd.DataFrame] = {}

# Small metadata cache:
# metadata_key -> (metadata_header_dict, item_map)
_META_CACHE: dict[str, tuple[dict[str, Any], dict[int, dict[str, Any]]]] = {}


def clear_cache() -> None:
    """Clear cached truth DataFrames and parsed metadata."""
    _TRUTH_CACHE.clear()
    _META_CACHE.clear()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _to_int_list(indices) -> list[int]:
    """Normalize a single index or iterable of indices to a list of ints."""
    if isinstance(indices, numbers.Integral):
        return [int(indices)]
    return [int(index) for index in indices]


def _clean_dataset_prefix(prefix: str) -> str:
    """Normalize and validate a dataset root prefix.

    Args:
        prefix: Dataset root prefix, e.g. ``"acic22"``.

    Returns:
        The cleaned dataset prefix.

    Raises:
        ValueError: If the prefix is empty or path-like.
    """
    cleaned = (prefix or "").strip().lstrip("/").rstrip("/")

    if not cleaned:
        raise ValueError("prefix must be a non-empty string.")

    if "/" in cleaned:
        raise ValueError(
            "prefix must be a dataset root like 'acic22' (no '/'). "
            "Do not pass '.../truth/...'."
        )

    return cleaned


def _join(prefix: str, name: str) -> str:
    """Join an S3 prefix and a relative object name safely."""
    return prefix.rstrip("/") + "/" + name.lstrip("/")


def _read_json_s3_or_local(source: str) -> Any:
    """Read JSON content from either a local path or an S3 object key."""
    path = Path(source)
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))

    buffer = BytesIO()
    con.bucket().Object(source).download_fileobj(buffer)
    raw = buffer.getvalue()

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("utf-8-sig")

    return json.loads(text)


def _validate_and_index_items(
    header: dict[str, Any],
    *,
    ds_root: str,
) -> dict[int, dict[str, Any]]:
    """Validate metadata fields and build an index-to-record mapping.

    Args:
        header: Parsed metadata object.
        ds_root: Expected dataset root prefix.

    Returns:
        A mapping from dataset index to metadata item record.

    Raises:
        ValueError: If the metadata contract is violated.
    """
    if not isinstance(header, dict):
        raise ValueError("Metadata must be a JSON object (dict).")

    schema_version = header.get("schema_version")
    if schema_version != 1:
        raise ValueError(f"Unsupported schema_version={schema_version!r}. Expected 1.")

    meta_prefix = header.get("prefix")
    if not isinstance(meta_prefix, str) or not meta_prefix.strip():
        raise ValueError("Metadata must contain a non-empty 'prefix' string.")
    if meta_prefix.strip().strip("/") != ds_root:
        raise ValueError(
            f"Metadata prefix mismatch: expected prefix='{ds_root}', found prefix='{meta_prefix}'."
        )

    items = header.get("items")
    if not isinstance(items, list) or len(items) == 0:
        raise ValueError("Metadata must contain a non-empty 'items' list.")

    out: dict[int, dict[str, Any]] = {}

    for record in items:
        if not isinstance(record, dict):
            raise ValueError("Each entry in 'items' must be a JSON object (dict).")

        if "index" not in record:
            raise ValueError("Each item must contain an 'index'.")

        try:
            idx = int(record["index"])
        except Exception:
            raise ValueError(f"Item index must be int-like, got: {record.get('index')!r}")

        if idx < 1:
            raise ValueError(f"Item index must be >= 1, got: {idx}")
        if idx in out:
            raise ValueError(f"Duplicate index in metadata items: {idx}")

        truth = record.get("truth")
        if truth is not None and (not isinstance(truth, str) or not truth.strip()):
            raise ValueError(f"Item {idx} has invalid 'truth' (must be non-empty string if present).")

        out[idx] = record

    return out


def _load_metadata(
    metadata_key: str,
    *,
    expected_prefix: str,
    use_cache: bool = True,
) -> tuple[dict[str, Any], dict[int, dict[str, Any]]]:
    """Load and validate metadata under the fixed dataset convention.

    Args:
        metadata_key: Metadata object key or local path.
        expected_prefix: Expected dataset root prefix.
        use_cache: If True, reuse cached parsed metadata.

    Returns:
        A tuple of ``(metadata_header, item_map)``.
    """
    if use_cache and metadata_key in _META_CACHE:
        header, item_map = _META_CACHE[metadata_key]
        _validate_and_index_items(header, ds_root=expected_prefix)
        return header, item_map

    header = _read_json_s3_or_local(metadata_key)
    if not isinstance(header, dict):
        raise ValueError("Metadata must be a JSON object (dict) at the top level.")

    item_map = _validate_and_index_items(header, ds_root=expected_prefix)

    if use_cache:
        _META_CACHE[metadata_key] = (header, item_map)

    return header, item_map


def _resolve_context(*, prefix: str | None) -> tuple[str, str]:
    """Resolve dataset root prefix and metadata key.

    Args:
        prefix: Optional explicit dataset root prefix.

    Returns:
        A tuple ``(dataset_root, metadata_key)``.
    """
    if prefix is None:
        config = cfg.get_config()
        ds_root = _clean_dataset_prefix(config.prefix)
    else:
        ds_root = _clean_dataset_prefix(prefix)

    metadata_key = cfg.standard_metadata_key(ds_root)
    return ds_root, metadata_key


def _download_truth_df(key: str, *, use_cache: bool) -> pd.DataFrame:
    """Download and read a truth parquet object from S3."""
    if use_cache and key in _TRUTH_CACHE:
        return _TRUTH_CACHE[key]

    buffer = BytesIO()
    con.bucket().Object(key).download_fileobj(buffer)
    buffer.seek(0)
    df = pd.read_parquet(buffer)

    if use_cache:
        _TRUTH_CACHE[key] = df

    return df



def _fallback_truth_key(index: int, *, ds_root: str) -> str:
    """Construct the default truth key for a dataset index."""
    return f"{ds_root.strip('/')}/truth/truth_{int(index):04d}.parquet"



def _resolve_truth_key(record: dict[str, Any], *, idx: int, ds_root: str) -> str:
    """Resolve the truth object key for a metadata item.

    Resolution order:
    1) metadata item field ``truth`` if present
    2) fallback convention ``<PREFIX>/truth/truth_<INDEX>.parquet``

    If the metadata ``truth`` field does not contain a slash, it is interpreted
    as a filename relative to ``<PREFIX>/truth``.
    """
    truth_value = record.get("truth")
    truth_prefix = f"{ds_root.strip('/')}/truth"

    if isinstance(truth_value, str) and truth_value.strip():
        cleaned = truth_value.strip().lstrip("/")
        if "/" in cleaned:
            return cleaned
        return _join(truth_prefix, cleaned)

    return _fallback_truth_key(idx, ds_root=ds_root)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_truth(
    indices,
    *,
    prefix: str | None = None,
    use_cache: bool = True,
    strict: bool = True,
) -> dict[int, pd.DataFrame]:
    """Load one or more truth files into RAM.

    Args:
        indices: Single index or iterable of dataset indices.
        prefix: Optional explicit dataset root prefix.
        use_cache: If True, cache loaded truth DataFrames and parsed metadata.
        strict: If True, raise on missing truth files. If False, warn and skip
            missing truth objects.

    Returns:
        A dictionary mapping dataset indices to truth DataFrames.
    """
    idx_list = _to_int_list(indices)
    if len(idx_list) == 0:
        return {}

    ds_root, metadata_key = _resolve_context(prefix=prefix)
    _, metadata = _load_metadata(
        metadata_key,
        expected_prefix=ds_root,
        use_cache=use_cache,
    )

    out: dict[int, pd.DataFrame] = {}

    for idx in idx_list:
        if idx not in metadata:
            raise KeyError(f"Index {idx} not found in metadata items for prefix '{ds_root}'.")

        key = _resolve_truth_key(metadata[idx], idx=idx, ds_root=ds_root)

        try:
            out[idx] = _download_truth_df(key, use_cache=use_cache)
        except ClientError:
            if strict:
                raise
            warnings.warn(
                f"Truth file not found for idx={idx} (key='{key}'). Skipping.",
                UserWarning,
            )

    return out


__all__ = [
    "clear_cache",
    "load_truth",
]