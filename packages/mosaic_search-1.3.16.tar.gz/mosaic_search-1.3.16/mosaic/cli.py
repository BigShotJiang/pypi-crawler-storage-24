"""MOSAIC CLI — Multi-source Scientific Article Indexer and Collector."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Annotated

import typer
from rich import box, print as rprint
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

import mosaic.config as cfg_mod
from mosaic.config import apply_api_keys
from mosaic.db import Cache
from mosaic.downloader import download as dl_paper
from mosaic.search import search_all
from mosaic.services import build_filters, filter_papers
from mosaic.errors import set_verbose_logging
from mosaic.source_registry import SRC_MAP, build_sources


def _version_callback(value: bool) -> None:
    if value:
        from mosaic import __version__

        rprint(f"mosaic {__version__}")
        raise typer.Exit()


app = typer.Typer(help="MOSAIC — Multi-source Scientific Article Indexer and Collector")
notebook_app = typer.Typer(
    help="Create and populate Google NotebookLM notebooks from search results."
)
auth_app = typer.Typer(help="Manage browser sessions for authenticated PDF access.")
cache_app = typer.Typer(help="Inspect and manage the local SQLite cache.")
app.add_typer(notebook_app, name="notebook")
app.add_typer(auth_app, name="auth")
app.add_typer(cache_app, name="cache")


_verbose: bool = False


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-v",
            callback=_version_callback,
            is_eager=True,
            help="Show version and exit",
        ),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Show warnings and per-source stats"),
    ] = False,
) -> None:
    global _verbose
    _verbose = verbose
    set_verbose_logging(verbose)


console = Console()


def warn(msg: str) -> None:
    """Print a warning — only when --verbose is active."""
    if _verbose:
        rprint(msg)


@app.command()
def search(
    query: Annotated[str, typer.Argument(help="Search query")],
    max_results: Annotated[int, typer.Option("--max", "-n", help="Max results per source")] = 10,
    download: Annotated[
        bool, typer.Option("--download", "-d", help="Download available PDFs")
    ] = False,
    oa_only: Annotated[
        bool, typer.Option("--oa-only", help="Show only open access papers")
    ] = False,
    pdf_only: Annotated[
        bool, typer.Option("--pdf-only", help="Show only papers with a downloadable PDF")
    ] = False,
    source: Annotated[
        str,
        typer.Option(
            "--source",
            "-s",
            help="Limit to one source (arxiv, ss, sd, sp, springer, doaj, epmc, oa, base, core, ads, ieee, zenodo, crossref, dblp, hal, pubmed, pmc, rxiv, pedro, scopus)",
            autocompletion=lambda: list(SRC_MAP.keys()),
        ),
    ] = "",
    year: Annotated[
        str,
        typer.Option("--year", "-y", help='Year filter: "2020", "2020-2024", or "2020,2022,2024"'),
    ] = "",
    author: Annotated[
        list[str], typer.Option("--author", "-a", help="Author name filter (repeatable)")
    ] = [],
    journal: Annotated[
        str, typer.Option("--journal", "-j", help="Journal name filter (substring match)")
    ] = "",
    field: Annotated[
        str,
        typer.Option(
            "--field", "-f",
            help='Scope query to "title", "abstract", or "all" (default)',
            autocompletion=lambda: _FIELD_VALUES,
        ),
    ] = "all",
    raw_query: Annotated[
        str,
        typer.Option(
            "--raw-query",
            help="Raw query sent directly to source APIs, bypassing all field transforms",
        ),
    ] = "",
    output: Annotated[
        list[Path],
        typer.Option(
            "--output",
            "-o",
            help="Save results to file (.md, .markdown, .csv, .json, .bib); repeatable",
        ),
    ] = [],
    download_dir: Annotated[
        str, typer.Option("--download-dir", help="Override PDF download directory for this run")
    ] = "",
    sort_by: Annotated[
        str,
        typer.Option(
            "--sort",
            help='Sort results: "citations" (most cited first) or "year" (newest first)',
            autocompletion=lambda: _SORT_VALUES,
        ),
    ] = "",
    zotero: Annotated[bool, typer.Option("--zotero", help="Export results to Zotero")] = False,
    zotero_collection: Annotated[
        str, typer.Option("--zotero-collection", help="Zotero collection name (created if missing)")
    ] = "",
    zotero_local: Annotated[
        bool,
        typer.Option(
            "--zotero-local", help="Force Zotero local API even when an API key is configured"
        ),
    ] = False,
    obsidian: Annotated[
        bool, typer.Option("--obsidian", help="Export results as notes to an Obsidian vault")
    ] = False,
    obsidian_folder: Annotated[
        str,
        typer.Option("--obsidian-folder", help="Override Obsidian vault subfolder for this run"),
    ] = "",
    pedro_fetch_details: Annotated[
        bool,
        typer.Option(
            "--pedro-fetch-details",
            help="Fetch each PEDro record page to get authors, year, DOI and abstract (overrides config for this run)",
        ),
    ] = False,
    stats: Annotated[
        bool, typer.Option("--stats", help="Print per-source counts and deduplication stats")
    ] = False,
    cached: Annotated[
        bool, typer.Option("--cached", help="Search only the local cache — no network requests")
    ] = False,
    prefer_cache: Annotated[
        bool,
        typer.Option(
            "--prefer-cache",
            help="Prefer rich cached records over freshly fetched data for known papers",
        ),
    ] = False,
):
    """Search for papers across all configured sources."""
    cfg = cfg_mod.load()
    if download_dir:
        cfg["download_dir"] = download_dir
    if pedro_fetch_details:
        cfg["sources"]["pedro"]["fetch_details"] = True
    cache = Cache(cfg["db_path"])

    if cached:
        filters, year_warning = build_filters(
            year=year, author=list(author), journal=journal, field=field, raw_query=raw_query
        )
        if year_warning:
            rprint(f"[red]{year_warning}[/red]")
            raise typer.Exit(1)
        rprint(f"[dim]Searching local cache for '{query}'…[/dim]")
        papers = cache.search_local(query)
        if filters:
            papers = [p for p in papers if filters.match(p)]
        _post_process(
            papers,
            cfg,
            cache,
            output=list(output),
            do_download=download,
            sort_by=sort_by,
            oa_only=oa_only,
            pdf_only=pdf_only,
            zotero=zotero,
            zotero_collection=zotero_collection,
            zotero_local=zotero_local,
            obsidian=obsidian,
            obsidian_folder=obsidian_folder,
        )
        return

    sources = build_sources(cfg)

    # filter by source shorthand
    if source:
        key = source.lower()
        if key not in SRC_MAP:
            rprint(f"[red]Unknown source '{source}'. Use: {', '.join(SRC_MAP.keys())}[/red]")
            raise typer.Exit(1)
        name = SRC_MAP[key]
        sources = [s for s in sources if s.name == name]
        if not sources:
            rprint(
                f"[dark_orange]Source '{source}' is not active (missing API key or disabled in config).[/dark_orange]"
            )
            raise typer.Exit(1)

    if field not in ("all", "title", "abstract"):
        rprint('[red]--field must be "title", "abstract", or "all"[/red]')
        raise typer.Exit(1)

    filters, year_warning = build_filters(
        year=year, author=list(author), journal=journal, field=field, raw_query=raw_query
    )
    if year_warning:
        rprint(f"[red]{year_warning}[/red]")
        raise typer.Exit(1)

    errors: list[str] = []
    search_stats: dict = {}
    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True
    ) as prog:
        prog.add_task(f"Searching {len(sources)} source(s) for [bold]{query}[/bold]…")
        papers = search_all(
            sources,
            query,
            max_per_source=max_results,
            filters=filters,
            errors=errors,
            stats=search_stats,
        )

    for err in errors:
        warn(f"[dark_orange]Warning:[/dark_orange] {err}")

    if prefer_cache:
        rich = cache.rich_uids()
        papers = [cache.get_by_uid(p.uid) or p if p.uid in rich else p for p in papers]

    if stats:
        _print_search_stats(search_stats, filters)

    _post_process(
        papers,
        cfg,
        cache,
        output=list(output),
        do_download=download,
        sort_by=sort_by,
        oa_only=oa_only,
        pdf_only=pdf_only,
        zotero=zotero,
        zotero_collection=zotero_collection,
        zotero_local=zotero_local,
        obsidian=obsidian,
        obsidian_folder=obsidian_folder,
    )


@app.command()
def similar(
    identifier: Annotated[
        str,
        typer.Argument(
            help="DOI or arXiv ID of the seed paper (e.g. 10.48550/arXiv.1706.03762 or arxiv:1706.03762)"
        ),
    ],
    max_results: Annotated[
        int, typer.Option("--max", "-n", help="Max similar papers to return")
    ] = 10,
    download: Annotated[
        bool, typer.Option("--download", "-d", help="Download available PDFs")
    ] = False,
    oa_only: Annotated[
        bool, typer.Option("--oa-only", help="Show only open-access papers")
    ] = False,
    pdf_only: Annotated[
        bool, typer.Option("--pdf-only", help="Show only papers with a downloadable PDF")
    ] = False,
    sort_by: Annotated[
        str,
        typer.Option(
            "--sort",
            help='Sort results: "citations" (most cited first) or "year" (newest first)',
            autocompletion=lambda: _SORT_VALUES,
        ),
    ] = "",
    output: Annotated[
        list[Path],
        typer.Option(
            "--output",
            "-o",
            help="Save results to file (.md, .markdown, .csv, .json, .bib); repeatable",
        ),
    ] = [],
    download_dir: Annotated[
        str, typer.Option("--download-dir", help="Override PDF download directory for this run")
    ] = "",
    zotero: Annotated[bool, typer.Option("--zotero", help="Export results to Zotero")] = False,
    zotero_collection: Annotated[
        str, typer.Option("--zotero-collection", help="Zotero collection name (created if missing)")
    ] = "",
    zotero_local: Annotated[
        bool,
        typer.Option(
            "--zotero-local", help="Force Zotero local API even when an API key is configured"
        ),
    ] = False,
    obsidian: Annotated[
        bool, typer.Option("--obsidian", help="Export results as notes to an Obsidian vault")
    ] = False,
    obsidian_folder: Annotated[
        str,
        typer.Option("--obsidian-folder", help="Override Obsidian vault subfolder for this run"),
    ] = "",
):
    """Find papers similar to a given paper by DOI or arXiv ID."""
    from mosaic.similar import find_similar

    cfg = cfg_mod.load()
    if download_dir:
        cfg["download_dir"] = download_dir
    cache = Cache(cfg["db_path"])

    oa_email = cfg.get("unpaywall", {}).get("email", "")
    ss_api_key = cfg.get("sources", {}).get("semantic_scholar", {}).get("api_key", "")

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True
    ) as prog:
        prog.add_task(f"Finding papers similar to [bold]{identifier}[/bold]…")
        try:
            seed_title, papers = find_similar(
                identifier,
                max_results=max_results,
                oa_email=oa_email,
                ss_api_key=ss_api_key,
            )
        except Exception as e:
            rprint(f"[red]Error looking up paper: {e}[/red]")
            raise typer.Exit(1) from None

    if seed_title is None:
        rprint(f"[red]Paper not found:[/red] {identifier}")
        rprint("[dim]Check that the DOI or arXiv ID is correct.[/dim]")
        raise typer.Exit(1)

    rprint(f"[bold]Similar to:[/bold] {seed_title}\n")

    _post_process(
        papers,
        cfg,
        cache,
        output=list(output),
        do_download=download,
        sort_by=sort_by,
        oa_only=oa_only,
        pdf_only=pdf_only,
        zotero=zotero,
        zotero_collection=zotero_collection,
        zotero_local=zotero_local,
        obsidian=obsidian,
        obsidian_folder=obsidian_folder,
    )


@app.command()
def get(
    doi: Annotated[str | None, typer.Argument(help="DOI of the paper to download")] = None,
    from_file: Annotated[
        Path | None,
        typer.Option(
            "--from", help="BibTeX (.bib) or CSV (.csv) file containing DOIs to bulk-download"
        ),
    ] = None,
    oa_only: Annotated[
        bool,
        typer.Option("--oa-only", help="Treat unresolvable papers as skipped rather than failed"),
    ] = False,
    download_dir: Annotated[
        str, typer.Option("--download-dir", help="Override PDF download directory for this run")
    ] = "",
    zotero: Annotated[
        bool, typer.Option("--zotero", help="Export downloaded paper(s) to Zotero")
    ] = False,
    zotero_collection: Annotated[
        str, typer.Option("--zotero-collection", help="Zotero collection name (created if missing)")
    ] = "",
    zotero_local: Annotated[
        bool,
        typer.Option(
            "--zotero-local", help="Force Zotero local API even when an API key is configured"
        ),
    ] = False,
    obsidian: Annotated[
        bool, typer.Option("--obsidian", help="Export paper(s) as notes to an Obsidian vault")
    ] = False,
    obsidian_folder: Annotated[
        str,
        typer.Option("--obsidian-folder", help="Override Obsidian vault subfolder for this run"),
    ] = "",
):
    """Download a paper by DOI, or bulk-download all DOIs from a .bib/.csv file."""
    cfg = cfg_mod.load()
    if download_dir:
        cfg["download_dir"] = download_dir
    cache = Cache(cfg["db_path"])

    if from_file and doi:
        rprint("[red]Provide either a DOI argument or --from, not both.[/red]")
        raise typer.Exit(1)

    if from_file:
        _bulk_download(
            from_file,
            cfg,
            cache,
            oa_only,
            zotero=zotero,
            zotero_collection=zotero_collection,
            zotero_local=zotero_local,
            obsidian=obsidian,
            obsidian_folder=obsidian_folder,
        )
        return

    if doi is None:
        rprint("[red]Provide a DOI argument or use --from <file> for bulk download.[/red]")
        raise typer.Exit(1)

    from mosaic.models import Paper

    _bare = Paper(title=doi, doi=doi, source="manual")
    paper = cache.get_by_uid(_bare.uid) or _bare
    if paper is not _bare:
        rprint(f"[dim]Found in local cache: {paper.title[:80]}[/dim]")
    path = dl_paper(
        paper,
        cfg["download_dir"],
        cache,
        cfg.get("unpaywall", {}).get("email", ""),
        cfg.get("filename_pattern", "{year}_{source}_{author}_{title}"),
    )
    if path:
        rprint(f"[green]Saved:[/green] {path}")
    else:
        rprint("[red]Could not find a downloadable PDF for this DOI.[/red]")

    if zotero:
        pdf_map = {paper.uid: path} if path else {}
        _push_to_zotero(
            [paper],
            cfg,
            collection_name=zotero_collection,
            force_local=zotero_local,
            pdf_map=pdf_map,
        )

    if obsidian:
        _push_to_obsidian([paper], cfg, subfolder_override=obsidian_folder)


@app.command()
def config(
    show: Annotated[bool, typer.Option("--show", help="Print current config")] = False,
    elsevier_key: Annotated[str, typer.Option(help="Set Elsevier API key")] = "",
    ss_key: Annotated[str, typer.Option(help="Set Semantic Scholar API key")] = "",
    ncbi_key: Annotated[str, typer.Option(help="Set NCBI/PubMed API key")] = "",
    zotero_key: Annotated[str, typer.Option(help="Set Zotero API key (web API)")] = "",
    unpaywall_email: Annotated[str, typer.Option(help="Set Unpaywall email")] = "",
    download_dir: Annotated[str, typer.Option(help="Set download directory")] = "",
    filename_pattern: Annotated[
        str,
        typer.Option(
            help="Set PDF filename pattern (placeholders: {year}, {source}, {author}, {title}, {doi})"
        ),
    ] = "",
    pedro_fair_use: Annotated[
        bool,
        typer.Option(
            "--pedro-fair-use/--no-pedro-fair-use",
            help="Acknowledge PEDro fair-use policy to enable the source",
        ),
    ] = None,
    pedro_fetch_details: Annotated[
        bool,
        typer.Option(
            "--pedro-fetch-details/--no-pedro-fetch-details",
            help="Fetch each PEDro record page to get authors, year, DOI and abstract (slower)",
        ),
    ] = None,
):
    """View or update MOSAIC configuration."""
    cfg = cfg_mod.load()

    api_keys_changed = apply_api_keys(
        cfg, {"elsevier_key": elsevier_key, "ss_key": ss_key, "ncbi_key": ncbi_key}
    )
    # Also set PMC key to same NCBI key
    if ncbi_key:
        cfg["sources"]["pmc"]["api_key"] = ncbi_key
    if zotero_key:
        cfg["zotero"]["api_key"] = zotero_key
        # auto-discover and cache the user ID
        from mosaic.zotero import ZoteroClient

        client = ZoteroClient(api_key=zotero_key)
        try:
            uid = client.discover_user_id()
            cfg["zotero"]["user_id"] = uid
            rprint(f"[green]Zotero web API configured for user {uid}[/green]")
        except Exception as e:
            warn(f"[dark_orange]Could not auto-discover Zotero user ID: {e}[/dark_orange]")
    if unpaywall_email:
        cfg["unpaywall"]["email"] = unpaywall_email
    if download_dir:
        cfg["download_dir"] = download_dir
    if filename_pattern:
        cfg["filename_pattern"] = filename_pattern
    if pedro_fair_use is not None:
        cfg["sources"]["pedro"]["acknowledge_fair_use"] = pedro_fair_use
        if pedro_fair_use:
            rprint("[green]PEDro fair-use policy acknowledged. Source is now enabled.[/green]")
        else:
            rprint(
                "[dark_orange]PEDro fair-use acknowledgement removed. Source is now disabled.[/dark_orange]"
            )
    if pedro_fetch_details is not None:
        cfg["sources"]["pedro"]["fetch_details"] = pedro_fetch_details
        if pedro_fetch_details:
            rprint("[green]PEDro detail fetching enabled (authors, year, DOI, abstract).[/green]")
        else:
            warn("[dark_orange]PEDro detail fetching disabled.[/dark_orange]")

    _pedro_changed = pedro_fair_use is not None or pedro_fetch_details is not None
    _any_changed = any(
        [
            api_keys_changed,
            zotero_key,
            unpaywall_email,
            download_dir,
            filename_pattern,
            _pedro_changed,
        ]
    )
    if _any_changed:
        cfg_mod.save(cfg)
        rprint("[green]Config saved to[/green] ~/.config/mosaic/config.toml")

    if show or not _any_changed:
        console.print_json(data=cfg)


def _bulk_download(
    from_file: Path,
    cfg: dict,
    cache: Cache,
    oa_only: bool,
    zotero: bool = False,
    zotero_collection: str = "",
    zotero_local: bool = False,
    obsidian: bool = False,
    obsidian_folder: str = "",
) -> None:
    from mosaic.bulk import read_dois
    from mosaic.models import Paper

    if not from_file.exists():
        rprint(f"[red]File not found: {from_file}[/red]")
        raise typer.Exit(1)

    try:
        dois = read_dois(from_file)
    except ValueError as e:
        rprint(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    if not dois:
        rprint(f"[dark_orange]No DOIs found in {from_file.name}[/dark_orange]")
        raise typer.Exit()

    rprint(f"[dim]Found {len(dois)} DOI(s) in {from_file.name}[/dim]")

    email = cfg.get("unpaywall", {}).get("email", "")
    download_dir = cfg["download_dir"]
    pattern = cfg.get("filename_pattern", "{year}_{source}_{author}_{title}")
    ok = fail = skip = 0
    papers_list: list = []
    pdf_map: dict[str, str] = {}

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=False
    ) as prog:
        for doi in dois:
            _bare = Paper(title=doi, doi=doi, source="manual")
            paper = cache.get_by_uid(_bare.uid) or _bare
            papers_list.append(paper)
            task = prog.add_task(f"{doi}…")
            path = dl_paper(paper, download_dir, cache, email, pattern)
            prog.remove_task(task)
            if path:
                ok += 1
                pdf_map[paper.uid] = path
                rprint(f"  [green]✓[/green] {Path(path).name}")
            elif oa_only:
                skip += 1
                rprint(f"  [dim]–[/dim] {doi} (no OA copy)")
            else:
                fail += 1
                rprint(f"  [red]✗[/red] {doi}")

    parts = [f"[bold]{ok}[/bold] downloaded"]
    if fail:
        parts.append(f"[red]{fail} failed[/red]")
    if skip:
        parts.append(f"[dim]{skip} skipped (no OA copy)[/dim]")
    console.print(f"\n[bold]Done:[/bold] {', '.join(parts)}")

    if zotero and papers_list:
        _push_to_zotero(
            papers_list,
            cfg,
            collection_name=zotero_collection,
            force_local=zotero_local,
            pdf_map=pdf_map,
        )

    if obsidian and papers_list:
        _push_to_obsidian(papers_list, cfg, subfolder_override=obsidian_folder)


def _print_search_stats(stats: dict, filters) -> None:
    per_source = stats.get("per_source", {})
    raw_total = stats.get("raw_total", 0)
    unique = stats.get("unique", 0)
    merged = stats.get("merged", 0)

    table = Table(
        show_header=True,
        header_style="cyan",
        box=box.SIMPLE,
        show_edge=False,
        title="[bold]Search stats[/bold]",
    )
    table.add_column("Source", min_width=20)
    table.add_column("Results", justify="right", no_wrap=True)

    for name, count in per_source.items():
        src_color = _RAINBOW[hash(name) % len(_RAINBOW)]
        label = f"[{src_color}]{name}[/{src_color}]"
        table.add_row(label, f"[cyan]{count}[/cyan]")

    table.add_section()
    table.add_row("[dim]Total raw[/dim]", f"[cyan]{raw_total}[/cyan]")
    table.add_row("[dim]Merged[/dim]",    f"[cyan]{merged}[/cyan]")
    table.add_row("[dim]Unique[/dim]",    f"[cyan]{unique}[/cyan]")

    filter_parts = []
    if filters:
        if filters.year_from and filters.year_to:
            filter_parts.append(f"year={filters.year_from}–{filters.year_to}")
        elif filters.year_from:
            filter_parts.append(f"year={filters.year_from}")
        elif filters.years:
            filter_parts.append(f"year={','.join(str(y) for y in filters.years)}")
        if filters.authors:
            filter_parts.append(f"author={', '.join(filters.authors)}")
        if filters.journal:
            filter_parts.append(f"journal={filters.journal}")
        if filters.field and filters.field != "all":
            filter_parts.append(f"field={filters.field}")
    if filter_parts:
        table.add_section()
        table.add_row("[dim]Filters[/dim]", f"[dim]{', '.join(filter_parts)}[/dim]")

    console.print(table)


def _post_process(
    papers: list,
    cfg: dict,
    cache: Cache,
    *,
    output: list[Path] | None = None,
    do_download: bool = False,
    sort_by: str = "",
    oa_only: bool = False,
    pdf_only: bool = False,
    zotero: bool = False,
    zotero_collection: str = "",
    zotero_local: bool = False,
    obsidian: bool = False,
    obsidian_folder: str = "",
) -> None:
    """Shared post-processing: filter, export, download, push to Zotero/Obsidian."""
    if sort_by and sort_by not in ("citations", "year"):
        rprint(f'[red]Unknown --sort value "{sort_by}". Use: citations, year[/red]')
        raise typer.Exit(1)
    papers = filter_papers(papers, oa_only=oa_only, pdf_only=pdf_only, sort_by=sort_by)

    if not papers:
        rprint("[dark_orange]No results found.[/dark_orange]")
        raise typer.Exit()

    for p in papers:
        cache.save(p)

    _print_results(papers)

    if output:
        from mosaic.exporter import export

        for path in output:
            try:
                export(papers, path)
                rprint(f"[green]Saved:[/green] {path}")
            except ValueError as e:
                rprint(f"[red]{e}[/red]")
                raise typer.Exit(1) from None

    pdf_map: dict[str, str] = {}
    if do_download:
        pdf_map = _download_all(papers, cfg, cache)

    if zotero:
        _push_to_zotero(
            papers,
            cfg,
            collection_name=zotero_collection,
            force_local=zotero_local,
            pdf_map=pdf_map,
        )

    if obsidian:
        _push_to_obsidian(papers, cfg, subfolder_override=obsidian_folder)


_RAINBOW = ["red", "dark_orange", "green", "cyan", "blue", "magenta"]

_SORT_VALUES  = ["citations", "year"]
_FIELD_VALUES = ["title", "abstract", "all"]
_AUTH_PROVIDERS = ["elsevier", "springer", "scopus"]


def _complete_session_names() -> list[str]:
    from mosaic.auth import list_sessions
    return [s["name"] for s in list_sessions()]


def _print_results(papers: list) -> None:
    show_citations = any(p.citation_count is not None for p in papers)

    table = Table(
        show_header=True,
        header_style="cyan",
        box=box.SIMPLE,
        show_edge=False,
        expand=True,
    )
    table.add_column("#", width=3)
    table.add_column("Title", min_width=30, ratio=3)
    table.add_column("Authors", ratio=2)
    table.add_column("Year", width=6)
    table.add_column("DOI", min_width=20, overflow="fold")
    table.add_column("Source", width=16)
    table.add_column("OA", width=4)
    table.add_column("PDF", width=5)
    if show_citations:
        table.add_column("Cited", width=7, justify="right")

    for i, p in enumerate(papers, 1):
        oa = "[green]yes[/green]" if p.is_open_access else "[red]no[/red]"
        pdf = "[green]✓[/green]" if p.pdf_url else "[dim]–[/dim]"
        doi = p.doi or "[dim]–[/dim]"
        color = _RAINBOW[(i - 1) % len(_RAINBOW)]
        src_color = _RAINBOW[hash(p.source) % len(_RAINBOW)]
        source = f"[{src_color}]{p.source}[/{src_color}]"
        row = [f"[{color}]{i}[/{color}]", p.title[:80], p.short_authors, str(p.year or ""), doi, source, oa, pdf]
        if show_citations:
            cited = str(p.citation_count) if p.citation_count is not None else "[dim]–[/dim]"
            row.append(cited)
        table.add_row(*row)

    console.print(table)
    console.print(f"[dim]{len(papers)} result(s)[/dim]")


def _download_all(papers: list, cfg: dict, cache: Cache) -> dict[str, str]:
    """Download PDFs for *papers*. Returns a ``{paper.uid: local_path}`` map."""
    email = cfg.get("unpaywall", {}).get("email", "")
    download_dir = cfg["download_dir"]
    pattern = cfg.get("filename_pattern", "{year}_{source}_{author}_{title}")
    ok = fail = skip = 0
    pdf_map: dict[str, str] = {}

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=False
    ) as prog:
        for p in papers:
            if not (p.pdf_url or p.doi):
                skip += 1
                continue
            task = prog.add_task(f"Downloading: {p.title[:50]}…")
            path = dl_paper(p, download_dir, cache, email, pattern)
            prog.remove_task(task)
            if path:
                ok += 1
                pdf_map[p.uid] = path
                rprint(f"  [green]✓[/green] {Path(path).name}")
            else:
                fail += 1
                rprint(f"  [red]✗[/red] {p.title[:60]}")

    console.print(f"\n[bold]Done:[/bold] {ok} downloaded, {fail} failed, {skip} skipped (no PDF)")
    return pdf_map


def _push_to_zotero(
    papers: list,
    cfg: dict,
    *,
    collection_name: str = "",
    force_local: bool = False,
    pdf_map: dict[str, str] | None = None,
) -> None:
    """Export *papers* to Zotero (local or web API)."""
    from mosaic.workflows import push_to_zotero

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True
    ) as prog:
        prog.add_task(f"Adding {len(papers)} paper(s) to Zotero…")
        result = push_to_zotero(
            papers,
            cfg,
            collection_name=collection_name,
            force_local=force_local,
            pdf_map=pdf_map,
        )

    if not result["ok"]:
        rprint(f"[red]{result['msg']}[/red]")
        raise typer.Exit(1)

    rprint(f"[green]Zotero:[/green] {result['msg']}")
    if result.get("attached"):
        rprint(f"[dim]{result['attached']} PDF(s) linked.[/dim]")


def _push_to_obsidian(
    papers: list,
    cfg: dict,
    *,
    subfolder_override: str = "",
) -> None:
    """Export *papers* as Obsidian notes to the configured vault."""
    from mosaic.workflows import push_to_obsidian

    result = push_to_obsidian(papers, cfg, subfolder_override=subfolder_override)
    if not result["ok"]:
        rprint(f"[red]{result['msg']}[/red]")
        raise typer.Exit(1)

    rprint(f"[green]Obsidian:[/green] {result['msg']}")


@notebook_app.command("create")
def notebook_create(
    name: Annotated[str, typer.Argument(help="Notebook name")],
    query: Annotated[
        str, typer.Option("--query", "-q", help="Search query to populate the notebook")
    ] = "",
    from_dir: Annotated[
        Path | None, typer.Option("--from-dir", help="Import all PDFs from this directory")
    ] = None,
    max_results: Annotated[int, typer.Option("--max", "-n", help="Max results per source")] = 10,
    oa_only: Annotated[
        bool, typer.Option("--oa-only", help="Only include open-access papers")
    ] = False,
    pdf_only: Annotated[
        bool, typer.Option("--pdf-only", help="Only include papers with a downloadable PDF")
    ] = False,
    podcast: Annotated[
        bool, typer.Option("--podcast", help="Queue an Audio Overview after import")
    ] = False,
    video: Annotated[
        bool, typer.Option("--video", help="Queue a Video Overview after import")
    ] = False,
    briefing: Annotated[
        bool, typer.Option("--briefing", help="Queue a Briefing Doc after import")
    ] = False,
    study_guide: Annotated[
        bool, typer.Option("--study-guide", help="Queue a Study Guide after import")
    ] = False,
    quiz: Annotated[bool, typer.Option("--quiz", help="Queue a Quiz after import")] = False,
    flashcards: Annotated[
        bool, typer.Option("--flashcards", help="Queue Flashcards after import")
    ] = False,
    infographic: Annotated[
        bool, typer.Option("--infographic", help="Queue an Infographic after import")
    ] = False,
    slide_deck: Annotated[
        bool, typer.Option("--slide-deck", help="Queue a Slide Deck after import")
    ] = False,
    data_table: Annotated[
        bool, typer.Option("--data-table", help="Queue a Data Table after import")
    ] = False,
    mind_map: Annotated[
        bool, typer.Option("--mind-map", help="Queue a Mind Map after import")
    ] = False,
    year: Annotated[
        str,
        typer.Option("--year", "-y", help='Year filter: "2020", "2020-2024", or "2020,2022,2024"'),
    ] = "",
    author: Annotated[
        list[str], typer.Option("--author", "-a", help="Author name filter (repeatable)")
    ] = [],
    journal: Annotated[
        str, typer.Option("--journal", "-j", help="Journal name filter (substring match)")
    ] = "",
    field: Annotated[
        str,
        typer.Option(
            "--field", "-f",
            help='Scope query to "title", "abstract", or "all" (default)',
            autocompletion=lambda: _FIELD_VALUES,
        ),
    ] = "all",
    raw_query: Annotated[
        str,
        typer.Option(
            "--raw-query",
            help="Raw query sent directly to source APIs, bypassing all field transforms",
        ),
    ] = "",
    download_dir: Annotated[
        str, typer.Option("--download-dir", help="Override PDF download directory for this run")
    ] = "",
):
    """Create a NotebookLM notebook from a search query or a directory of PDFs.

    Requires: pip install 'mosaic-search[notebooklm]' && notebooklm login
    """
    from mosaic.notebooklm_bridge import (
        _require_notebooklm,
        create_notebook,
        create_notebook_from_dir,
    )

    _require_notebooklm()

    if from_dir and query:
        rprint("[red]Use either --query or --from-dir, not both.[/red]")
        raise typer.Exit(1)
    if not from_dir and not query:
        rprint("[red]Provide --query or --from-dir.[/red]")
        raise typer.Exit(1)

    cfg = cfg_mod.load()
    if download_dir:
        cfg["download_dir"] = download_dir

    # collect requested artifacts
    _artifact_flags = {
        "podcast": podcast, "video": video, "briefing": briefing,
        "study_guide": study_guide, "quiz": quiz, "flashcards": flashcards,
        "infographic": infographic, "slide_deck": slide_deck,
        "data_table": data_table, "mind_map": mind_map,
    }
    _artifacts = {name for name, enabled in _artifact_flags.items() if enabled}

    # ── from-dir path ─────────────────────────────────────────────────────────
    if from_dir:
        from_dir = Path(from_dir)
        if not from_dir.is_dir():
            rprint(f"[red]Directory not found: {from_dir}[/red]")
            raise typer.Exit(1)
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True
        ) as prog:
            prog.add_task(f"Creating notebook [bold]{name}[/bold] from {from_dir}…")
            try:
                nb_id = asyncio.run(create_notebook_from_dir(name, from_dir, artifacts=_artifacts))
            except ValueError as e:
                rprint(f"[red]{e}[/red]")
                raise typer.Exit(1) from None
        rprint(f"[green]Notebook created:[/green] https://notebooklm.google.com/notebook/{nb_id}")
        if _artifacts:
            rprint(
                f"[dim]{', '.join(sorted(_artifacts))} queued — check NotebookLM in a few minutes.[/dim]"
            )
        return

    # ── query path: search → download → import ────────────────────────────────
    sources = build_sources(cfg)
    cache = Cache(cfg["db_path"])
    email = cfg.get("unpaywall", {}).get("email", "")

    if field not in ("all", "title", "abstract"):
        rprint('[red]--field must be "title", "abstract", or "all"[/red]')
        raise typer.Exit(1)

    filters, year_warning = build_filters(
        year=year, author=list(author), journal=journal, field=field, raw_query=raw_query
    )
    if year_warning:
        rprint(f"[red]{year_warning}[/red]")
        raise typer.Exit(1)

    errors: list[str] = []
    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True
    ) as prog:
        prog.add_task(f"Searching {len(sources)} source(s) for [bold]{query}[/bold]…")
        papers = search_all(
            sources, query, max_per_source=max_results, filters=filters, errors=errors
        )

    for err in errors:
        warn(f"[dark_orange]Warning:[/dark_orange] {err}")

    papers = filter_papers(papers, oa_only=oa_only, pdf_only=pdf_only)

    if not papers:
        rprint("[dark_orange]No results found.[/dark_orange]")
        raise typer.Exit()

    rprint(f"[dim]Found {len(papers)} paper(s). Downloading PDFs…[/dim]")

    papers_with_paths: list[tuple] = []
    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True
    ) as prog:
        for p in papers:
            task = prog.add_task(f"{p.title[:55]}…")
            path = dl_paper(
                p,
                cfg["download_dir"],
                cache,
                email,
                cfg.get("filename_pattern", "{year}_{source}_{author}_{title}"),
            )
            prog.remove_task(task)
            papers_with_paths.append((p, Path(path) if path else None))

    downloaded = sum(1 for _, path in papers_with_paths if path)
    rprint(
        f"[dim]{downloaded} PDF(s) downloaded, {len(papers) - downloaded} fallback to URL.[/dim]"
    )

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True
    ) as prog:
        prog.add_task(f"Importing into NotebookLM notebook [bold]{name}[/bold]…")
        nb_id = asyncio.run(create_notebook(name, papers_with_paths, artifacts=_artifacts))

    rprint(f"[green]Notebook created:[/green] https://notebooklm.google.com/notebook/{nb_id}")
    if _artifacts:
        rprint(
            f"[dim]{', '.join(sorted(_artifacts))} queued — check NotebookLM in a few minutes.[/dim]"
        )


@app.command()
def ui(
    host: Annotated[str, typer.Option(help="Bind address")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Port number")] = 5555,
    no_browser: Annotated[
        bool, typer.Option("--no-browser", help="Don't auto-open browser")
    ] = False,
    debug: Annotated[bool, typer.Option("--debug", help="Enable Flask debug mode")] = False,
):
    """Launch the MOSAIC web interface."""
    try:
        from mosaic.ui import create_app
    except ImportError:
        rprint("[red]Flask is required for the web UI. Install it with:[/red]")
        rprint("  pip install 'mosaic-search[ui]'")
        raise typer.Exit(1) from None

    flask_app = create_app()
    if not no_browser:
        import threading
        import webbrowser

        threading.Timer(1.0, webbrowser.open, args=[f"http://{host}:{port}"]).start()

    if debug:
        flask_app.run(host=host, port=port, debug=True)
    else:
        from waitress import create_server

        server = create_server(flask_app, host=host, port=port)
        rprint(
            f"[green]MOSAIC[/green] running at [link]http://{host}:{port}[/link]  (Ctrl+C to stop)"
        )
        server.run()


@auth_app.command("login")
def auth_login(
    name: Annotated[
        str,
        typer.Argument(
            help="Session name, e.g. elsevier, springer, myuni",
            autocompletion=lambda: _AUTH_PROVIDERS,
        ),
    ],
    url: Annotated[str, typer.Option("--url", "-u", help="URL to open in the browser for login")],
) -> None:
    """Open a browser, log in to a site, and save the session for future PDF downloads."""
    import asyncio

    from mosaic.auth import login as do_login

    asyncio.run(do_login(name, url))


@auth_app.command("logout")
def auth_logout(
    name: Annotated[
        str,
        typer.Argument(
            help="Session name to remove",
            autocompletion=_complete_session_names,
        ),
    ],
) -> None:
    """Remove a saved browser session."""
    from mosaic.auth import delete_session

    if delete_session(name):
        rprint(f"[green]Session removed:[/green] {name}")
    else:
        warn(f"[dark_orange]No session found for:[/dark_orange] {name}")


@auth_app.command("status")
def auth_status() -> None:
    """List all saved browser sessions."""
    from mosaic.auth import list_sessions

    sessions = list_sessions()
    if not sessions:
        rprint(
            "[dim]No saved sessions. Use [bold]mosaic auth login <name> --url <url>[/bold] to add one.[/dim]"
        )
        return
    table = Table(show_header=True, header_style="cyan", box=box.SIMPLE, show_edge=False)
    table.add_column("Name", style="bold")
    table.add_column("Domain")
    table.add_column("Saved")
    table.add_column("Valid")
    table.add_column("Path", style="dim")
    for s in sessions:
        valid_cell = "[green]✓[/green]" if s["valid"] else "[red]✗ expired[/red]"
        table.add_row(s["name"], s["domain"], s["saved"], valid_cell, s["path"])
    console.print(table)


# ── mosaic cache subcommands ──────────────────────────────────────────────────

def _cache_and_cfg():
    cfg = cfg_mod.load()
    return Cache(cfg["db_path"]), cfg


@cache_app.command("stats")
def cache_stats() -> None:
    """Print a summary of the local cache."""
    cache, _ = _cache_and_cfg()
    s = cache.stats()
    mb = s["db_bytes"] / 1_048_576

    table = Table(show_header=False, box=box.SIMPLE, show_edge=False)
    table.add_column("Key",   style="dim", min_width=20)
    table.add_column("Value", justify="right")
    table.add_row("Papers cached",    f"[cyan]{s['papers']}[/cyan]")
    table.add_row("  with abstract",  f"[dim]{s['with_abstract']}[/dim]")
    table.add_row("  open access",    f"[dim]{s['open_access']}[/dim]")
    table.add_row("  with PDF URL",   f"[dim]{s['with_pdf_url']}[/dim]")
    table.add_row("Downloads (ok)",   f"[green]{s['downloaded']}[/green]")
    table.add_row("Searches logged",  f"[cyan]{s['searches']}[/cyan]")
    table.add_row("Exports tracked",  f"[cyan]{s['exports']}[/cyan]")
    table.add_row("DB size",          f"[dim]{mb:.2f} MB[/dim]")
    console.print(table)


@cache_app.command("list")
def cache_list(
    query: Annotated[str,  typer.Option("--query", "-q", help="Filter by title/abstract")] = "",
    limit: Annotated[int,  typer.Option("--limit", "-n", help="Max rows to show")] = 50,
    offset: Annotated[int, typer.Option("--offset",      help="Skip first N rows")] = 0,
) -> None:
    """List cached papers, newest first."""
    cache, _ = _cache_and_cfg()
    papers = cache.list_papers(limit=limit, offset=offset, query=query)
    total  = cache.count_papers(query=query)

    if not papers:
        rprint("[dim]No papers in cache.[/dim]")
        return

    table = Table(show_header=True, header_style="cyan", box=box.SIMPLE,
                  show_edge=False, expand=True)
    table.add_column("#",       width=5)
    table.add_column("Title",   min_width=30, ratio=3)
    table.add_column("Authors", ratio=2)
    table.add_column("Year",    width=6)
    table.add_column("Source",  width=16)
    table.add_column("OA",      width=4)
    table.add_column("PDF",     width=4)
    table.add_column("Abstr",   width=5)

    for i, p in enumerate(papers, offset + 1):
        color    = _RAINBOW[(i - 1) % len(_RAINBOW)]
        oa       = "[green]✓[/green]" if p.is_open_access else "[red]✗[/red]"
        pdf      = "[green]✓[/green]" if p.pdf_url        else "[dim]–[/dim]"
        abstract = "[green]✓[/green]" if p.abstract       else "[dim]–[/dim]"
        table.add_row(
            f"[{color}]{i}[/{color}]",
            p.title[:80],
            p.short_authors,
            str(p.year or ""),
            p.source,
            oa, pdf, abstract,
        )

    console.print(table)
    showing = offset + len(papers)
    console.print(f"[dim]Showing {offset + 1}–{showing} of {total}[/dim]")


@cache_app.command("show")
def cache_show(
    identifier: Annotated[
        str, typer.Argument(help="DOI, arXiv ID, or full UID of the paper")
    ],
) -> None:
    """Show full cached metadata for a paper."""
    from mosaic.models import Paper as _Paper

    cache, _ = _cache_and_cfg()

    # Try as-is (full UID), then as DOI, then as arXiv ID
    paper = cache.get_by_uid(identifier)
    if paper is None:
        stub = _Paper(title=identifier, doi=identifier, source="")
        paper = cache.get_by_uid(stub.uid)
    if paper is None:
        stub2 = _Paper(title=identifier, arxiv_id=identifier, source="")
        paper = cache.get_by_uid(stub2.uid)
    if paper is None:
        rprint(f"[red]Not found in cache:[/red] {identifier}")
        raise typer.Exit(1)

    dl = cache.get_download(paper.uid)

    table = Table(show_header=False, box=box.SIMPLE, show_edge=False, expand=True)
    table.add_column("Field", style="dim", min_width=18)
    table.add_column("Value")

    def row(k, v):
        table.add_row(k, str(v) if v is not None else "[dim]–[/dim]")

    row("Title",          paper.title)
    row("Authors",        paper.short_authors)
    row("Year",           paper.year)
    row("DOI",            paper.doi)
    row("arXiv ID",       paper.arxiv_id)
    row("Journal",        paper.journal)
    row("Source",         paper.source)
    row("Open access",    "[green]yes[/green]" if paper.is_open_access else "no")
    row("PDF URL",        paper.pdf_url)
    row("Citation count", paper.citation_count)
    row("UID",            paper.uid)
    if paper.abstract:
        row("Abstract", paper.abstract[:300] + ("…" if len(paper.abstract) > 300 else ""))
    if dl:
        table.add_section()
        row("Local file",   dl["local_path"])
        row("Download status", dl["status"])
        row("Downloaded at",   dl["downloaded_at"])

    console.print(table)


@cache_app.command("verify")
def cache_verify() -> None:
    """Check that all tracked download files still exist on disk."""
    cache, _ = _cache_and_cfg()
    results = cache.verify_downloads()

    if not results:
        rprint("[dim]No completed downloads tracked.[/dim]")
        return

    ok      = [r for r in results if r["exists"]]
    missing = [r for r in results if not r["exists"]]

    rprint(f"[green]{len(ok)} file(s) OK[/green], [red]{len(missing)} missing[/red]")

    if missing:
        table = Table(show_header=True, header_style="cyan", box=box.SIMPLE, show_edge=False)
        table.add_column("UID",        style="dim")
        table.add_column("Missing path")
        for r in missing:
            table.add_row(r["uid"], r["local_path"] or "[dim]–[/dim]")
        console.print(table)
        rprint("[dim]Run [bold]mosaic cache clean[/bold] to remove stale records.[/dim]")


@cache_app.command("clean")
def cache_clean() -> None:
    """Remove download records for files that no longer exist on disk."""
    cache, _ = _cache_and_cfg()
    removed = cache.clean_stubs()
    if removed:
        rprint(f"[green]Removed {removed} stale download record(s).[/green]")
    else:
        rprint("[dim]Nothing to clean — all tracked files are present.[/dim]")


@cache_app.command("clear")
def cache_clear(
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation prompt")
    ] = False,
) -> None:
    """Wipe the entire cache (papers, downloads, searches, exports)."""
    cache, _ = _cache_and_cfg()
    s = cache.stats()
    if not yes:
        rprint(
            f"[bold red]This will permanently delete {s['papers']} paper(s), "
            f"{s['downloaded']} download record(s), and {s['searches']} search(es).[/bold red]"
        )
        typer.confirm("Continue?", abort=True)
    cache.clear()
    rprint("[green]Cache cleared.[/green]")


@cache_app.command("export")
def cache_export(
    output: Annotated[
        Path, typer.Argument(help="Output file (.md, .csv, .json, .bib)")
    ],
    query: Annotated[
        str, typer.Option("--query", "-q", help="Filter by title/abstract")
    ] = "",
    limit: Annotated[
        int, typer.Option("--limit", "-n", help="Max papers to export (0 = all)")
    ] = 0,
) -> None:
    """Bulk export cached papers to a file."""
    from mosaic.exporter import export

    cache, _ = _cache_and_cfg()
    papers = cache.list_papers(limit=limit or 999_999, query=query)

    if not papers:
        rprint("[dark_orange]No papers to export.[/dark_orange]")
        raise typer.Exit()

    try:
        export(papers, output)
        rprint(f"[green]Exported {len(papers)} paper(s) to[/green] {output}")
    except ValueError as e:
        rprint(f"[red]{e}[/red]")
        raise typer.Exit(1) from None


if __name__ == "__main__":
    app()
