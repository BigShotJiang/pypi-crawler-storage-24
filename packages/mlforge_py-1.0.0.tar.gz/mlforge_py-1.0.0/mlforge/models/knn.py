"""
knn.py
------
K-Nearest Neighbors — predicts based on the K closest examples.

Imagine you're trying to predict house price.
KNN finds the 5 most similar houses in your training data
and averages their prices.

Simple, no training time, but slow for large datasets.

Usage:
    from mlforge.models import KNN

    model = KNN(task="classification", n_neighbors=5)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
"""

import logging
logger = logging.getLogger(__name__)


class KNN:
    """K-Nearest Neighbors for regression and classification."""

    TASK = "both"

    def __init__(self, task: str = "classification",
                 n_neighbors: int = 5,
                 weights: str = "uniform"):

        self.task        = task
        self.n_neighbors = n_neighbors
        # k=5 means "look at the 5 closest examples"
        # smaller k = more sensitive to noise
        # larger k = smoother predictions

        self.weights = weights
        # "uniform"  → all neighbours count equally
        # "distance" → closer neighbours count more

        self._model = None

    def fit(self, X, y):
        from sklearn.neighbors import (KNeighborsRegressor,
                                        KNeighborsClassifier)
        logger.info(f"Training KNN (k={self.n_neighbors}) [{self.task}]...")
        if self.task == "regression":
            self._model = KNeighborsRegressor(
                n_neighbors = self.n_neighbors,
                weights     = self.weights,
            )
        else:
            self._model = KNeighborsClassifier(
                n_neighbors = self.n_neighbors,
                weights     = self.weights,
            )
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)

    def predict_proba(self, X):
        if self.task != "classification": raise RuntimeError("Classification only.")
        return self._model.predict_proba(X)
