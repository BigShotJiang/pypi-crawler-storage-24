"""
xgboost_model.py
----------------
XGBoost — fast, high-performance gradient boosting.
One of the most popular models for tabular data.

Setup:
    pip install xgboost

Usage:
    from mlforge.models import XGBoost

    model = XGBoost(task="classification")
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
"""

import logging
logger = logging.getLogger(__name__)


class XGBoost:
    """XGBoost for regression and classification."""

    TASK = "both"

    def __init__(self, task: str = "regression",
                 n_estimators:  int   = 100,
                 learning_rate: float = 0.1,
                 max_depth:     int   = 6,
                 random_state:  int   = 42):

        self.task          = task
        self.n_estimators  = n_estimators
        self.learning_rate = learning_rate
        self.max_depth     = max_depth
        self.random_state  = random_state
        self._model        = None

    def fit(self, X, y):
        try:
            from xgboost import XGBRegressor, XGBClassifier
        except ImportError:
            raise ImportError("Run: pip install xgboost")

        logger.info(f"Training XGBoost [{self.task}]...")
        if self.task == "regression":
            self._model = XGBRegressor(
                n_estimators  = self.n_estimators,
                learning_rate = self.learning_rate,
                max_depth     = self.max_depth,
                random_state  = self.random_state,
                verbosity     = 0,
            )
        else:
            self._model = XGBClassifier(
                n_estimators  = self.n_estimators,
                learning_rate = self.learning_rate,
                max_depth     = self.max_depth,
                random_state  = self.random_state,
                verbosity     = 0,
                eval_metric   = "logloss",
            )
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)

    def predict_proba(self, X):
        if self.task != "classification": raise RuntimeError("Classification only.")
        return self._model.predict_proba(X)

    @property
    def feature_importances_(self):
        return self._model.feature_importances_ if self._model else None
