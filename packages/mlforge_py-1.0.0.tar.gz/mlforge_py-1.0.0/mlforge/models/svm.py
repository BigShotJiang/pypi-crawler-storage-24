"""
svm.py
------
Support Vector Machine — finds the best boundary between classes.

Good for:
  - Small to medium datasets
  - When classes are clearly separable
  - Text classification

SVM     → for classification
SVR     → for regression (Support Vector Regression)

Usage:
    from mlforge.models import SVM, SVR

    # Classification
    model = SVM(kernel="rbf")
    model.fit(X_train, y_train)

    # Regression
    model = SVR(kernel="rbf")
    model.fit(X_train, y_train)
"""

import logging
logger = logging.getLogger(__name__)


class SVM:
    """Support Vector Machine for classification."""
    TASK = "classification"

    def __init__(self, kernel: str = "rbf",
                 C: float = 1.0,
                 class_weight: str = None,
                 random_state: int = 42):

        self.kernel       = kernel
        # "rbf"    → radial basis function (default, works for most data)
        # "linear" → linear boundary (faster, good for many features)
        self.C            = C
        # C controls how much to penalise misclassifications
        # higher C = tries harder to classify all points correctly
        self.class_weight = class_weight
        self.random_state = random_state
        self._model       = None

    def fit(self, X, y):
        from sklearn.svm import SVC
        logger.info(f"Training SVM (kernel={self.kernel})...")
        self._model = SVC(
            kernel       = self.kernel,
            C            = self.C,
            class_weight = self.class_weight,
            random_state = self.random_state,
            probability  = True,   # needed for predict_proba
        )
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)

    def predict_proba(self, X):
        return self._model.predict_proba(X)


class SVR:
    """Support Vector Regression."""
    TASK = "regression"

    def __init__(self, kernel: str = "rbf", C: float = 1.0):
        self.kernel = kernel
        self.C      = C
        self._model = None

    def fit(self, X, y):
        from sklearn.svm import SVR as _SVR
        logger.info(f"Training SVR (kernel={self.kernel})...")
        self._model = _SVR(kernel=self.kernel, C=self.C)
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)
