"""
mlforge.models
-----------------
Every model available in mlforge.

Regression (predict a number):
    RandomForest, DecisionTree, GradientBoosting
    XGBoost, LightGBM
    LinearRegression, Ridge, Lasso
    SVR, KNN

Classification (predict a category):
    RandomForest, DecisionTree, GradientBoosting
    XGBoost, LightGBM
    LogisticRegression
    SVM, KNN

Usage:
    from mlforge.models import RandomForest

    model = RandomForest(task="regression")
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

Tip — don't know which model to use?
    Start with RandomForest. It works well on most problems.
"""

from .random_forest       import RandomForest
from .decision_tree       import DecisionTree
from .gradient_boosting   import GradientBoosting
from .xgboost_model       import XGBoost
from .lightgbm_model      import LightGBM
from .linear_models       import (LinearRegression, Ridge,
                                   Lasso, LogisticRegression)
from .svm                 import SVM, SVR
from .knn                 import KNN

__all__ = [
    "RandomForest", "DecisionTree", "GradientBoosting",
    "XGBoost", "LightGBM",
    "LinearRegression", "Ridge", "Lasso", "LogisticRegression",
    "SVM", "SVR", "KNN",
]
