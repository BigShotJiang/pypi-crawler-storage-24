"""
linear_models.py
----------------
Linear models — fast, simple, and easy to interpret.

LinearRegression  — predicts a number using a straight line
Ridge             — like linear but penalises large weights (reduces overfitting)
Lasso             — like ridge but can zero out unimportant features
LogisticRegression — classifies by finding a decision boundary

Good for:
  - Quick baseline before trying complex models
  - When your data is roughly linear
  - When interpretability matters

Usage:
    from mlforge.models import LinearRegression, Ridge, Lasso
    from mlforge.models import LogisticRegression

    model = Ridge(alpha=1.0)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
"""

import logging
logger = logging.getLogger(__name__)


class LinearRegression:
    """Ordinary least squares linear regression."""
    TASK = "regression"

    def __init__(self):
        self._model = None

    def fit(self, X, y):
        from sklearn.linear_model import LinearRegression as _LR
        logger.info("Training Linear Regression...")
        self._model = _LR()
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)


class Ridge:
    """Ridge regression — linear model with L2 regularisation."""
    TASK = "regression"

    def __init__(self, alpha: float = 1.0):
        self.alpha  = alpha
        # alpha controls regularisation strength
        # higher = more penalty on large weights = simpler model
        self._model = None

    def fit(self, X, y):
        from sklearn.linear_model import Ridge as _Ridge
        logger.info(f"Training Ridge (alpha={self.alpha})...")
        self._model = _Ridge(alpha=self.alpha)
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)


class Lasso:
    """Lasso regression — linear model that can zero out features."""
    TASK = "regression"

    def __init__(self, alpha: float = 1.0):
        self.alpha  = alpha
        self._model = None

    def fit(self, X, y):
        from sklearn.linear_model import Lasso as _Lasso
        logger.info(f"Training Lasso (alpha={self.alpha})...")
        self._model = _Lasso(alpha=self.alpha)
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)


class LogisticRegression:
    """Logistic regression — classification using a linear boundary."""
    TASK = "classification"

    def __init__(self, class_weight: str = None,
                 random_state: int = 42):
        self.class_weight = class_weight
        self.random_state = random_state
        self._model       = None

    def fit(self, X, y):
        from sklearn.linear_model import LogisticRegression as _LR
        logger.info("Training Logistic Regression...")
        self._model = _LR(
            class_weight = self.class_weight,
            random_state = self.random_state,
            max_iter     = 1000,
        )
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)

    def predict_proba(self, X):
        return self._model.predict_proba(X)
