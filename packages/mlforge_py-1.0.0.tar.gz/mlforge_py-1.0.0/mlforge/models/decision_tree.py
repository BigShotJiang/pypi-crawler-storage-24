"""
decision_tree.py
----------------
Decision Tree — makes decisions by asking yes/no questions about the data.

Easy to understand and explain — you can literally draw the tree.

Good for:
  - When you need to explain decisions to non-technical people
  - Quick prototyping
  - Small datasets

Note: tends to overfit — use Random Forest for better accuracy.

Usage:
    from mlforge.models import DecisionTree

    model = DecisionTree(task="classification", max_depth=5)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
"""

import logging
logger = logging.getLogger(__name__)


class DecisionTree:
    """Decision Tree for regression and classification."""

    TASK = "both"

    def __init__(self, task: str = "regression",
                 max_depth:    int = None,
                 class_weight: str = None,
                 random_state: int = 42):

        self.task         = task
        self.max_depth    = max_depth
        self.class_weight = class_weight
        self.random_state = random_state
        self._model       = None

    def fit(self, X, y):
        from sklearn.tree import (DecisionTreeRegressor,
                                   DecisionTreeClassifier)
        logger.info(f"Training Decision Tree [{self.task}]...")
        if self.task == "regression":
            self._model = DecisionTreeRegressor(
                max_depth    = self.max_depth,
                random_state = self.random_state,
            )
        else:
            self._model = DecisionTreeClassifier(
                max_depth    = self.max_depth,
                class_weight = self.class_weight,
                random_state = self.random_state,
            )
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)

    def predict_proba(self, X):
        if self.task != "classification": raise RuntimeError("Classification only.")
        return self._model.predict_proba(X)

    @property
    def feature_importances_(self):
        return self._model.feature_importances_ if self._model else None
