"""
gradient_boosting.py
--------------------
Gradient Boosting — builds trees one at a time, each fixing the errors
of the previous one. Often the most accurate model for tabular data.

Good for:
  - High accuracy on structured/tabular data
  - Kaggle competitions
  - When you need the best possible performance

Usage:
    from mlforge.models import GradientBoosting

    model = GradientBoosting(task="regression", n_estimators=200)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
"""

import logging
logger = logging.getLogger(__name__)


class GradientBoosting:
    """Gradient Boosting for regression and classification."""

    TASK = "both"

    def __init__(self, task: str = "regression",
                 n_estimators:  int   = 100,
                 learning_rate: float = 0.1,
                 max_depth:     int   = 3,
                 random_state:  int   = 42):

        self.task          = task
        self.n_estimators  = n_estimators
        self.learning_rate = learning_rate
        self.max_depth     = max_depth
        self.random_state  = random_state
        self._model        = None

    def fit(self, X, y):
        from sklearn.ensemble import (GradientBoostingRegressor,
                                       GradientBoostingClassifier)
        logger.info(f"Training Gradient Boosting [{self.task}]...")
        if self.task == "regression":
            self._model = GradientBoostingRegressor(
                n_estimators  = self.n_estimators,
                learning_rate = self.learning_rate,
                max_depth     = self.max_depth,
                random_state  = self.random_state,
            )
        else:
            self._model = GradientBoostingClassifier(
                n_estimators  = self.n_estimators,
                learning_rate = self.learning_rate,
                max_depth     = self.max_depth,
                random_state  = self.random_state,
            )
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)

    def predict_proba(self, X):
        if self.task != "classification": raise RuntimeError("Classification only.")
        return self._model.predict_proba(X)

    @property
    def feature_importances_(self):
        return self._model.feature_importances_ if self._model else None
