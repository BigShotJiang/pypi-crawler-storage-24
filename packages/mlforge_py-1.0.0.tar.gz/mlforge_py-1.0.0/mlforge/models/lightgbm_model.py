"""
lightgbm_model.py
-----------------
LightGBM — fast gradient boosting, great for large datasets.
Often faster than XGBoost with similar accuracy.

Setup:
    pip install lightgbm

Usage:
    from mlforge.models import LightGBM

    model = LightGBM(task="regression")
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
"""

import logging
logger = logging.getLogger(__name__)


class LightGBM:
    """LightGBM for regression and classification."""

    TASK = "both"

    def __init__(self, task: str = "regression",
                 n_estimators:  int   = 100,
                 learning_rate: float = 0.1,
                 num_leaves:    int   = 31,
                 class_weight:  str   = None,
                 random_state:  int   = 42):

        self.task          = task
        self.n_estimators  = n_estimators
        self.learning_rate = learning_rate
        self.num_leaves    = num_leaves
        self.class_weight  = class_weight
        self.random_state  = random_state
        self._model        = None

    def fit(self, X, y):
        try:
            import lightgbm as lgb
        except ImportError:
            raise ImportError("Run: pip install lightgbm")

        logger.info(f"Training LightGBM [{self.task}]...")
        if self.task == "regression":
            self._model = lgb.LGBMRegressor(
                n_estimators  = self.n_estimators,
                learning_rate = self.learning_rate,
                num_leaves    = self.num_leaves,
                random_state  = self.random_state,
                verbose       = -1,
            )
        else:
            self._model = lgb.LGBMClassifier(
                n_estimators  = self.n_estimators,
                learning_rate = self.learning_rate,
                num_leaves    = self.num_leaves,
                class_weight  = self.class_weight,
                random_state  = self.random_state,
                verbose       = -1,
            )
        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        if self._model is None: raise RuntimeError("Call fit() first.")
        return self._model.predict(X)

    def predict_proba(self, X):
        if self.task != "classification": raise RuntimeError("Classification only.")
        return self._model.predict_proba(X)

    @property
    def feature_importances_(self):
        return self._model.feature_importances_ if self._model else None
