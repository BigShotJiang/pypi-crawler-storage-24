"""
random_forest.py
----------------
Random Forest — builds many decision trees and combines their answers.

Great for:
  - Most regression and classification problems
  - When you don't know which model to use, start here
  - Gives feature importance scores for free

Regression example:
    from mlforge.models import RandomForest
    model = RandomForest(task="regression")
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

Classification example:
    model = RandomForest(task="classification", class_weight="balanced")
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

Options:
    n_estimators  → number of trees (more = slower but better, default 100)
    max_depth     → how deep each tree can grow (None = unlimited)
    class_weight  → "balanced" helps when one class has fewer examples
"""

import logging
logger = logging.getLogger(__name__)


class RandomForest:
    """Random Forest for regression and classification."""

    TASK = "both"

    def __init__(self, task: str = "regression",
                 n_estimators:  int  = 100,
                 max_depth:     int  = None,
                 class_weight:  str  = None,
                 random_state:  int  = 42):

        self.task         = task
        self.n_estimators = n_estimators
        self.max_depth    = max_depth
        self.class_weight = class_weight
        self.random_state = random_state
        self._model       = None

    def fit(self, X, y):
        """Train the Random Forest."""
        from sklearn.ensemble import (RandomForestRegressor,
                                       RandomForestClassifier)
        logger.info(f"Training Random Forest [{self.task}] "
                    f"with {self.n_estimators} trees...")

        if self.task == "regression":
            self._model = RandomForestRegressor(
                n_estimators = self.n_estimators,
                max_depth    = self.max_depth,
                random_state = self.random_state,
            )
        else:
            self._model = RandomForestClassifier(
                n_estimators = self.n_estimators,
                max_depth    = self.max_depth,
                class_weight = self.class_weight,
                random_state = self.random_state,
            )

        self._model.fit(X, y)
        logger.info("Training complete.")
        return self

    def predict(self, X):
        """Make predictions."""
        self._check_fitted()
        return self._model.predict(X)

    def predict_proba(self, X):
        """Return class probabilities (classification only)."""
        self._check_fitted()
        if self.task != "classification":
            raise RuntimeError("predict_proba() is for classification only.")
        return self._model.predict_proba(X)

    @property
    def feature_importances_(self):
        return self._model.feature_importances_ if self._model else None

    def _check_fitted(self):
        if self._model is None:
            raise RuntimeError("Call fit() before predict().")
