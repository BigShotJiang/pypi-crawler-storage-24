"""
AI Agent 模块 - 通过 LLM 函数调用实现智能助手

支持 OpenAI 兼容的 Chat Completion API（含 function calling / tool use）。
"""

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional

import requests

from .auth import DEFAULT_TOKEN_DIR

# AI 配置文件名
AI_CONFIG_FILE = "ai_config.json"

# 默认模型
DEFAULT_AI_MODEL = "deepseek-chat"


# ==================== 配置管理 ====================

def get_ai_config_path(token_dir: Optional[str] = None) -> Path:
    """获取 AI 配置文件路径"""
    base_dir = Path(token_dir) if token_dir else DEFAULT_TOKEN_DIR
    return base_dir / AI_CONFIG_FILE


def save_ai_config(
    api_base: str,
    api_key: str,
    model: str = DEFAULT_AI_MODEL,
    token_dir: Optional[str] = None,
) -> Path:
    """
    保存 AI 配置

    Args:
        api_base: OpenAI 兼容 API 地址（如 https://api.deepseek.com）
        api_key: API 密钥
        model: 模型名称
        token_dir: 配置存储目录（默认: ~/.moha）

    Returns:
        配置文件路径
    """
    config_path = get_ai_config_path(token_dir)
    config_path.parent.mkdir(parents=True, exist_ok=True)

    data = {
        "api_base": api_base.rstrip("/"),
        "api_key": api_key,
        "model": model,
    }

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    os.chmod(config_path, 0o600)
    return config_path


def load_ai_config(token_dir: Optional[str] = None) -> Dict[str, str]:
    """
    加载 AI 配置，环境变量优先级高于配置文件

    环境变量:
        MOHA_AI_API_BASE: API 地址
        MOHA_AI_API_KEY: API 密钥
        MOHA_AI_MODEL: 模型名称

    Returns:
        {"api_base": ..., "api_key": ..., "model": ...}
    """
    config = {}

    # 先从文件读取
    config_path = get_ai_config_path(token_dir)
    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
        except (json.JSONDecodeError, IOError):
            pass

    # 环境变量覆盖
    if os.environ.get("MOHA_AI_API_BASE"):
        config["api_base"] = os.environ["MOHA_AI_API_BASE"]
    if os.environ.get("MOHA_AI_API_KEY"):
        config["api_key"] = os.environ["MOHA_AI_API_KEY"]
    if os.environ.get("MOHA_AI_MODEL"):
        config["model"] = os.environ["MOHA_AI_MODEL"]

    # 默认值
    config.setdefault("model", DEFAULT_AI_MODEL)

    return config


# ==================== 工具定义 ====================

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "list_repositories",
            "description": "列出仓库。可以按类型、范围和组织进行过滤。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "scope": {
                        "type": "string",
                        "enum": ["public", "create", "favorite", "organization"],
                        "description": "查询范围: public=公开, create=我创建的, favorite=我收藏的, organization=组织内的",
                    },
                    "organization": {
                        "type": "string",
                        "description": "组织名称（scope=organization 时必需）",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_clusters",
            "description": "列出组织下的集群",
            "parameters": {
                "type": "object",
                "properties": {
                    "organization": {
                        "type": "string",
                        "description": "组织名称",
                    },
                },
                "required": ["organization"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_cluster_workspaces",
            "description": "列出组织下集群下的工作空间",
            "parameters": {
                "type": "object",
                "properties": {
                    "organization": {
                        "type": "string",
                        "description": "组织名称",
                    },
                    "cluster_id": {
                        "type": "string",
                        "description": "集群 ID",
                    },
                },
                "required": ["organization", "cluster_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_workspace_flavors",
            "description": "列出组织下集群下的工作空间的规格",
            "parameters": {
                "type": "object",
                "properties": {
                    "organization": {
                        "type": "string",
                        "description": "组织名称",
                    },
                    "cluster_id": {
                        "type": "string",
                        "description": "集群 ID",
                    },
                    "workspace_id": {
                        "type": "string",
                        "description": "工作空间 ID",
                    },
                },
                "required": ["organization", "cluster_id", "workspace_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_product",
            "description": "获取组织下的指定产品/模版信息",
            "parameters": {
                "type": "object",
                "properties": {
                    "organization": {
                        "type": "string",
                        "description": "组织名称",
                    },
                    "product_id": {
                        "type": "string",
                        "description": "产品/模版 ID",
                    },
                },
                "required": ["organization", "product_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_products",
            "description": "列出组织下的产品/模版",
            "parameters": {
                "type": "object",
                "properties": {
                    "organization": {
                        "type": "string",
                        "description": "组织名称",
                    },
                },
                "required": ["organization"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_repository_info",
            "description": "获取仓库的详细信息，包括名称、描述、可见性、元数据等。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_space_repository",
            "description": "创建一个新的空间仓库。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "cluster": {
                        "type": "string",
                        "description": "集群 ID（必需）",
                    },
                    "namespace": {
                        "type": "string",
                        "description": "工作空间 ID（必需）",
                    },
                    "product_id": {
                        "type": "string",
                        "enum": ["gradio", "streamlit", "docker-template"],
                        "description": "模版 ID (必须为支持的模版之一)",
                    },
                    "product_version": {
                        "type": "string",
                        "description": "模版版本 (必须为支持的版本之一)",
                    },
                    "visibility": {
                        "type": "string",
                        "enum": ["public", "internal", "private"],
                        "description": "可见性（默认: internal）",
                    },
                    "flavor": {
                        "type": "string",
                        "description": "规格ID",
                    },
                    "env": {
                        "type": "object",
                        "description": "环境变量（键值对）",
                    },
                    "description": {
                        "type": "string",
                        "description": "仓库描述",
                    },
                    "metadata": {
                        "type": "object",
                        "description": "仓库元数据（键值对，值为字符串数组）",
                    },
                },
                "required": ["repo_id","cluster","namespace","product_id","product_version"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_repository",
            "description": "创建一个新的仓库。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "description": {
                        "type": "string",
                        "description": "仓库描述",
                    },
                    "visibility": {
                        "type": "string",
                        "enum": ["public", "internal", "private"],
                        "description": "可见性（默认: internal）",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_repository",
            "description": "更新仓库的信息，如描述、可见性、元数据、标注等。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "description": {
                        "type": "string",
                        "description": "仓库描述",
                    },
                    "visibility": {
                        "type": "string",
                        "enum": ["public", "internal", "private"],
                        "description": "可见性",
                    },
                    "annotations": {
                        "type": "object",
                        "description": "仓库标注（键值对）",
                    },
                    "metadata": {
                        "type": "object",
                        "description": "仓库元数据（键值对，值为字符串数组）",
                    },
                    "base_model": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "基础模型列表（用于模型血缘）",
                    },
                    "relationship": {
                        "type": "string",
                        "description": "与基础模型的关系（用于模型血缘）",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_repository",
            "description": "删除一个仓库。此操作不可恢复，请谨慎使用。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_branches",
            "description": "列出仓库的所有分支。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_branch",
            "description": "为仓库创建一个新分支。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "branch_name": {
                        "type": "string",
                        "description": "新分支名称",
                    },
                    "from_branch": {
                        "type": "string",
                        "description": "基于哪个分支创建（默认: main）",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                },
                "required": ["repo_id", "branch_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_branch",
            "description": "删除仓库的一个分支。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "branch_name": {
                        "type": "string",
                        "description": "要删除的分支名称",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                },
                "required": ["repo_id", "branch_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "download_repository",
            "description": "下载整个仓库到本地目录。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "revision": {
                        "type": "string",
                        "description": "分支或版本（默认: main）",
                    },
                    "local_dir": {
                        "type": "string",
                        "description": "保存文件的本地目录",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "deploy_space",
            "description": "发布一个 Space 应用。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "Space 仓库 ID，格式: 组织/仓库名",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "redeploy_space",
            "description": "重新发布一个 Space 应用。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "Space 仓库 ID，格式: 组织/仓库名",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_space_status",
            "description": "获取 Space 应用的运行状态，包括健康状态、阶段和访问端点。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "Space 仓库 ID，格式: 组织/仓库名",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_repository_content",
            "description": "获取仓库中指定路径的文件/目录内容列表。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "branch": {
                        "type": "string",
                        "description": "分支名称（默认: main）",
                    },
                    "path": {
                        "type": "string",
                        "description": "仓库中的路径（默认: 根目录）",
                    },
                },
                "required": ["repo_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file_content",
            "description": "读取仓库中指定文件的文本内容。仅适用于文本类型文件（如 .py, .json, .yaml, .md, .txt 等）。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "file_path": {
                        "type": "string",
                        "description": "文件在仓库中的路径（如 src/main.py）",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "branch": {
                        "type": "string",
                        "description": "分支名称（默认: main）",
                    },
                },
                "required": ["repo_id", "file_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": "在仓库中创建或更新一个文本文件。适用于创建配置文件、README、代码文件等。如果文件已存在则会覆盖。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "file_path": {
                        "type": "string",
                        "description": "文件在仓库中的路径（如 README.md, config.json）",
                    },
                    "content": {
                        "type": "string",
                        "description": "文件的文本内容",
                    },
                    "message": {
                        "type": "string",
                        "description": "提交消息（可选）",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "branch": {
                        "type": "string",
                        "description": "分支名称（默认: main）",
                    },
                },
                "required": ["repo_id", "file_path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_file",
            "description": "删除仓库中的一个文件。此操作不可恢复，请谨慎使用。",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "file_path": {
                        "type": "string",
                        "description": "文件在仓库中的路径",
                    },
                    "message": {
                        "type": "string",
                        "description": "提交消息（可选）",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "branch": {
                        "type": "string",
                        "description": "分支名称（默认: main）",
                    },
                },
                "required": ["repo_id", "file_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "upload_folder",
            "description": "将本地目录上传到仓库。支持大文件自动使用 LFS 上传，支持文件加密。",
            "parameters": {
                "type": "object",
                "properties": {
                    "folder_path": {
                        "type": "string",
                        "description": "本地目录的路径（绝对路径或相对路径）",
                    },
                    "repo_id": {
                        "type": "string",
                        "description": "仓库 ID，格式: 组织/仓库名",
                    },
                    "repo_type": {
                        "type": "string",
                        "enum": ["models", "datasets", "spaces"],
                        "description": "仓库类型（默认: models）",
                    },
                    "revision": {
                        "type": "string",
                        "description": "上传到的分支（默认: main）",
                    },
                    "commit_message": {
                        "type": "string",
                        "description": "提交消息（可选）",
                    },
                    "encryption_password": {
                        "type": "string",
                        "description": "文件加密密码（可选，仅对>=5MB且支持的模型文件生效）",
                    },
                    "temp_dir": {
                        "type": "string",
                        "description": "加密临时目录（可选，不传则自动创建）",
                    },
                    "algorithm": {
                        "type": "string",
                        "enum": ["AES-256-CTR", "SM4-CTR"],
                        "description": "加密算法（可选，默认: AES-256-CTR）",
                    },
                    "ignore_patterns": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "忽略的文件/目录模式列表（如 [\"*.log\", \"__pycache__\"]）",
                    },
                },
                "required": ["folder_path", "repo_id"],
            },
        },
    },
    # ==================== 本地文件系统工具 ====================
    {
        "type": "function",
        "function": {
            "name": "local_create_directory",
            "description": "在本地文件系统中创建目录。支持递归创建多级目录。如果目录已存在则不报错。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "要创建的目录路径（绝对路径或相对于当前工作目录的相对路径）",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "local_create_file",
            "description": "在本地文件系统中创建或覆盖一个文本文件。如果父目录不存在会自动创建。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "文件路径（绝对路径或相对于当前工作目录的相对路径）",
                    },
                    "content": {
                        "type": "string",
                        "description": "文件的文本内容",
                    },
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "local_list_directory",
            "description": "列出本地目录中的文件和子目录。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "要列出内容的目录路径（绝对路径或相对路径，默认: 当前目录）",
                    },
                    "show_hidden": {
                        "type": "boolean",
                        "description": "是否显示隐藏文件/目录（以 . 开头），默认: false",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "local_read_file",
            "description": "读取本地文件的文本内容。仅适用于文本类型文件。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "文件路径（绝对路径或相对于当前工作目录的相对路径）",
                    },
                    "encoding": {
                        "type": "string",
                        "description": "文件编码（默认: utf-8）",
                    },
                },
                "required": ["path"],
            },
        },
    },
]


# ==================== 工具执行 ====================

def _parse_repo_id(repo_id: str):
    """解析仓库 ID"""
    parts = repo_id.split("/")
    if len(parts) != 2:
        raise ValueError(f"无效的仓库 ID: {repo_id}，格式应为: 组织/仓库名")
    return parts[0], parts[1]


def execute_tool(tool_name: str, arguments: Dict[str, Any], client) -> str:
    """
    执行工具调用，返回结果字符串

    Args:
        tool_name: 工具名称
        arguments: 工具参数
        client: HubClient 实例

    Returns:
        执行结果的字符串描述
    """
    try:
        if tool_name == "list_repositories":
            repo_type = arguments.get("repo_type", "models")
            scope = arguments.get("scope", "public")
            organization = arguments.get("organization")
            repos = client.list_repositories(
                repo_type=repo_type,
                scope=scope,
                organization=organization,
            )
            if not repos:
                return "没有找到仓库。"
            results = []
            for repo in repos:
                desc = f" - {repo.description}" if repo.description else ""
                results.append(f"  {repo.organization}/{repo.name}{desc}")
            return f"找到 {len(repos)} 个仓库:\n" + "\n".join(results)
        
        elif tool_name == "list_clusters":
            organization = arguments.get("organization")
            clusters = client.list_clusters(organization)
            if not clusters:
                return "没有找到集群。"
            results = []
            for cluster in clusters:
                results.append(f" - {cluster.name} (ID: {cluster.id}) (状态: {cluster.state}) (类型: {cluster.type}) (发布状态: {cluster.published}) (描述: {cluster.description or '-'})")
            return f"组织 '{organization}' 下的集群:\n" + "\n".join(results)
        
        elif tool_name == "list_cluster_workspaces":
            organization = arguments.get("organization")
            cluster_id = arguments.get("cluster_id")
            workspaces = client.list_cluster_workspaces(organization, cluster_id)
            if not workspaces:
                return "没有找到工作空间。"
            results = []
            for ws in workspaces:
                results.append(f" - {ws.name} (ID: {ws.id}) (集群: {ws.cluster})")
            return f"集群 '{cluster_id}' 下的工作空间:\n" + "\n".join(results)
        
        elif tool_name == "list_workspace_flavors":
            organization = arguments.get("organization")
            cluster_id = arguments.get("cluster_id")
            workspace_id = arguments.get("workspace_id")
            flavors = client.list_workspace_flavors(organization, cluster_id, workspace_id)
            if not flavors:
                return "没有找到规格。"
            results = []
            for flavor in flavors:
                results.append(f" - {flavor.name} (ID: {flavor.id}, 型号: {flavor.model}, 类型: {flavor.type}, Vendor: {flavor.vendor})")
            return f"工作空间 '{workspace_id}' 的可用规格:\n" + "\n".join(results)
        
        elif tool_name == "get_product":
            organization = arguments.get("organization")
            product_id = arguments.get("product_id")
            product = client.get_product(organization, product_id)
            if not product:
                return f"没有找到产品/模版 '{product_id}'。"
            versions_info = "\n".join([f"    - 版本: {v.version}, App版本: {v.appVersion}, URL: {v.url}" for v in product.versions])
            return f"产品/模版信息:\n - 名称: {product.name}\n - ID: {product.id}\n - 类型: {product.category}\n - 版本信息:\n{versions_info}"
        
        elif tool_name == "list_products":
            organization = arguments.get("organization")
            products = client.list_products(organization)
            if not products:
                return "没有找到产品/模版。"
            results = []
            for prod in products:
                results.append(f" - {prod.name} (ID: {prod.id}) (类型: {prod.category})")
                for version in prod.versions:
                    results.append(f"    - 版本: {version.version}")
            return f"组织 '{organization}' 下的产品/模版:\n" + "\n".join(results)

        elif tool_name == "get_repository_info":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            repo = client.get_repository_info(org, repo_type, name)
            info = {
                "名称": repo.name,
                "组织": repo.organization,
                "所有者": repo.owner,
                "创建者": repo.creator,
                "类型": repo.type,
                "可见性": repo.visibility,
                "描述": repo.description or "无",
            }
            if repo.metadata:
                info["元数据"] = repo.metadata
            if repo.genealogy:
                info["模型血缘"] = repo.genealogy
            if repo.spaceMetadata and repo.spaceMetadata.status:
                space_info = {
                    "健康": repo.spaceMetadata.status.healthy,
                    "阶段": repo.spaceMetadata.status.phase,
                    "消息": repo.spaceMetadata.status.message,
                }
                if repo.spaceMetadata.status.endpoints:
                    space_info["端点"] = [
                        {"name": ep.name, "url": ep.url, "kind": ep.kind}
                        for ep in repo.spaceMetadata.status.endpoints
                    ]
                info["Space状态"] = space_info
            return json.dumps(info, ensure_ascii=False, indent=2)
        
        elif tool_name == "create_space_repository":
            org, name = _parse_repo_id(arguments["repo_id"])
            cluster = arguments["cluster"]
            namespace = arguments["namespace"]
            product_id = arguments["product_id"]
            product_version = arguments["product_version"]
            visibility = arguments.get("visibility", "internal")
            flavor = arguments.get("flavor")
            env = arguments.get("env")
            description = arguments.get("description")
            metadata = arguments.get("metadata")
            client.create_space_repository(
                organization=org,
                repo_name=name,
                cluster=cluster,
                namespace=namespace,
                product_id=product_id,
                product_version=product_version,
                visibility=visibility,
                flavor=flavor,
                env=env,
                description=description,
                metadata=metadata,
            )
            return f"空间仓库创建成功: {org}/{name}"

        elif tool_name == "create_repository":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            description = arguments.get("description")
            visibility = arguments.get("visibility", "internal")
            client.create_repository(
                organization=org,
                repo_type=repo_type,
                repo_name=name,
                description=description,
                visibility=visibility,
            )
            return f"仓库创建成功: {org}/{name}"

        elif tool_name == "update_repository":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            description = arguments.get("description")
            visibility = arguments.get("visibility")
            annotations = arguments.get("annotations")
            metadata = arguments.get("metadata")
            base_model = arguments.get("base_model")
            relationship = arguments.get("relationship")
            client.update_repository(
                organization=org,
                repo_type=repo_type,
                repo_name=name,
                description=description,
                visibility=visibility,
                annotations=annotations,
                metadata=metadata,
                base_model=base_model,
                relationship=relationship,
            )
            updated_fields = []
            if description is not None:
                updated_fields.append(f"描述='{description}'")
            if visibility is not None:
                updated_fields.append(f"可见性={visibility}")
            if annotations is not None:
                updated_fields.append("标注已更新")
            if metadata is not None:
                updated_fields.append("元数据已更新")
            if base_model is not None:
                updated_fields.append(f"基础模型={base_model}")
            if relationship is not None:
                updated_fields.append(f"关系={relationship}")
            fields_str = ", ".join(updated_fields) if updated_fields else "无变更"
            return f"仓库更新成功: {org}/{name}（{fields_str}）"

        elif tool_name == "delete_repository":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            client.delete_repository(
                organization=org,
                repo_type=repo_type,
                repo_name=name,
            )
            return f"仓库删除成功: {org}/{name}"

        elif tool_name == "list_branches":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            refs = client.get_repository_refs(org, repo_type, name)
            if not refs:
                return "没有找到分支。"
            results = []
            for ref in refs:
                commit_hash = ref.hash[:8] if ref.hash else "N/A"
                default_mark = " (默认)" if ref.is_default else ""
                results.append(f"  {ref.name} [{ref.type}] (commit: {commit_hash}){default_mark}")
            return f"分支列表:\n" + "\n".join(results)

        elif tool_name == "create_branch":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            branch_name = arguments["branch_name"]
            from_branch = arguments.get("from_branch", "main")
            client.create_branch(org, repo_type, name, branch_name, from_branch)
            return f"分支创建成功: {branch_name}"

        elif tool_name == "delete_branch":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            branch_name = arguments["branch_name"]
            client.delete_branch(org, repo_type, name, branch_name)
            return f"分支删除成功: {branch_name}"

        elif tool_name == "download_repository":
            from .download import snapshot_download
            repo_id = arguments["repo_id"]
            repo_type = arguments.get("repo_type", "models")
            revision = arguments.get("revision")
            local_dir = arguments.get("local_dir")
            local_path = snapshot_download(
                repo_id=repo_id,
                repo_type=repo_type,
                revision=revision,
                local_dir=local_dir,
                base_url=client.base_url,
                token=client.token,
            )
            return f"仓库下载完成，保存路径: {local_path}"

        elif tool_name == "deploy_space":
            org, name = _parse_repo_id(arguments["repo_id"])
            client.deploy_space(org, name)
            return f"Space 发布成功: {org}/{name}"

        elif tool_name == "redeploy_space":
            org, name = _parse_repo_id(arguments["repo_id"])
            client.redeploy_space(org, name)
            return f"Space 重新发布成功: {org}/{name}"

        elif tool_name == "get_space_status":
            org, name = _parse_repo_id(arguments["repo_id"])
            status = client.get_space_status(org, name)
            info = {
                "健康状态": "健康" if status.healthy else "不健康",
                "阶段": status.phase,
                "消息": status.message,
            }
            if status.endpoints:
                info["端点"] = [
                    {"name": ep.name, "url": ep.url, "kind": ep.kind}
                    for ep in status.endpoints
                ]
            return json.dumps(info, ensure_ascii=False, indent=2)

        elif tool_name == "get_repository_content":
            org, name = _parse_repo_id(arguments["repo_id"])
            repo_type = arguments.get("repo_type", "models")
            branch = arguments.get("branch", "main")
            path = arguments.get("path", "")
            content = client.get_repository_content(org, repo_type, name, branch, path)
            if content.entries:
                results = []
                for entry in content.entries:
                    display_size = entry.size
                    if entry.type == "file" and entry.lfs:
                        if isinstance(entry.lfs, dict):
                            display_size = int(entry.lfs.get("size", entry.size) or entry.size)
                        else:
                            display_size = entry.lfs.size
                    size_str = f" ({display_size} bytes)" if entry.type == "file" else ""
                    results.append(f"  [{entry.type}] {entry.name}{size_str}")
                return f"路径 '{path or '/'}' 下的内容:\n" + "\n".join(results)
            else:
                info = {"名称": content.name, "类型": content.type, "大小": content.size}
                if content.content and not content.content_omitted:
                    info["内容"] = content.content
                return json.dumps(info, ensure_ascii=False, indent=2)

        elif tool_name == "read_file_content":
            org, name = _parse_repo_id(arguments["repo_id"])
            file_path = arguments["file_path"]
            repo_type = arguments.get("repo_type", "models")
            branch = arguments.get("branch", "main")
            content = client.get_repository_content(org, repo_type, name, branch, file_path)
            if content.type != "file":
                return f"错误: '{file_path}' 不是文件，而是 {content.type} 类型"
            if content.content_omitted:
                return f"文件 '{file_path}' 内容过大，无法直接读取（大小: {content.size} bytes）"
            if content.content is None:
                return f"文件 '{file_path}' 没有可读取的文本内容（可能是二进制文件）"
            return f"文件 '{file_path}' 的内容:\n\n{content.content}"

        elif tool_name == "create_file":
            org, name = _parse_repo_id(arguments["repo_id"])
            file_path = arguments["file_path"]
            file_content = arguments["content"]
            message = arguments.get("message", "")
            repo_type = arguments.get("repo_type", "models")
            branch = arguments.get("branch", "main")
            client.create_file(
                organization=org,
                repo_type=repo_type,
                repo_name=name,
                branch=branch,
                file_path=file_path,
                content=file_content,
                message=message,
            )
            return f"文件创建成功: {file_path}（仓库: {org}/{name}，分支: {branch}）"

        elif tool_name == "delete_file":
            org, name = _parse_repo_id(arguments["repo_id"])
            file_path = arguments["file_path"]
            message = arguments.get("message", "")
            repo_type = arguments.get("repo_type", "models")
            branch = arguments.get("branch", "main")
            client.delete_file(
                organization=org,
                repo_type=repo_type,
                repo_name=name,
                branch=branch,
                file_path=file_path,
                message=message,
            )
            return f"文件删除成功: {file_path}（仓库: {org}/{name}，分支: {branch}）"

        elif tool_name == "upload_folder":
            from .upload import upload_folder
            folder_path = arguments["folder_path"]
            repo_id = arguments["repo_id"]
            repo_type = arguments.get("repo_type", "models")
            revision = arguments.get("revision", "main")
            commit_message = arguments.get("commit_message")
            encryption_password = arguments.get("encryption_password")
            temp_dir = arguments.get("temp_dir")
            algorithm = arguments.get("algorithm")
            ignore_patterns = arguments.get("ignore_patterns")
            result = upload_folder(
                folder_path=folder_path,
                repo_id=repo_id,
                repo_type=repo_type,
                revision=revision,
                commit_message=commit_message,
                base_url=client.base_url,
                token=client.token,
                encryption_password=encryption_password,
                temp_dir=temp_dir,
                algorithm=algorithm,
                ignore_patterns=ignore_patterns,
            )
            org, name = _parse_repo_id(repo_id)
            return f"目录上传成功: {folder_path} -> {org}/{name}（分支: {revision}）"

        # ==================== 本地文件系统操作 ====================

        elif tool_name == "local_create_directory":
            dir_path = Path(arguments["path"]).expanduser()
            dir_path.mkdir(parents=True, exist_ok=True)
            return f"目录创建成功: {dir_path.resolve()}"

        elif tool_name == "local_create_file":
            file_path = Path(arguments["path"]).expanduser()
            file_content = arguments["content"]
            # 自动创建父目录
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(file_content, encoding="utf-8")
            return f"文件创建成功: {file_path.resolve()}（大小: {len(file_content.encode('utf-8'))} bytes）"

        elif tool_name == "local_list_directory":
            dir_path = Path(arguments.get("path", ".")).expanduser()
            show_hidden = arguments.get("show_hidden", False)
            if not dir_path.exists():
                return f"错误: 目录不存在: {dir_path}"
            if not dir_path.is_dir():
                return f"错误: '{dir_path}' 不是目录"
            entries = sorted(dir_path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            if not show_hidden:
                entries = [e for e in entries if not e.name.startswith(".")]
            if not entries:
                return f"目录 '{dir_path.resolve()}' 为空。"
            results = []
            for entry in entries:
                if entry.is_dir():
                    results.append(f"  [目录] {entry.name}/")
                elif entry.is_symlink():
                    results.append(f"  [链接] {entry.name} -> {entry.resolve()}")
                else:
                    size = entry.stat().st_size
                    results.append(f"  [文件] {entry.name} ({size} bytes)")
            return f"目录 '{dir_path.resolve()}' 的内容（{len(results)} 项）:\n" + "\n".join(results)

        elif tool_name == "local_read_file":
            file_path = Path(arguments["path"]).expanduser()
            encoding = arguments.get("encoding", "utf-8")
            if not file_path.exists():
                return f"错误: 文件不存在: {file_path}"
            if not file_path.is_file():
                return f"错误: '{file_path}' 不是文件"
            file_size = file_path.stat().st_size
            # 限制读取大小，避免过大文件
            max_size = 512 * 1024  # 512KB
            if file_size > max_size:
                return f"文件 '{file_path}' 太大（{file_size} bytes），超过 {max_size} bytes 的读取限制。"
            try:
                content = file_path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                return f"文件 '{file_path}' 无法以 {encoding} 编码读取（可能是二进制文件）"
            return f"文件 '{file_path.resolve()}' 的内容:\n\n{content}"

        else:
            return f"未知的工具: {tool_name}"

    except Exception as e:
        return f"执行错误: {e}"


# ==================== LLM 调用 ====================

SYSTEM_PROMPT = """你是晓石 AI Hub 的智能助手。你可以帮助用户管理模型仓库、数据集仓库和 Space 应用，以及操作本地文件系统。

你可以执行以下操作：

【仓库管理】
- 列出、查看、创建、删除仓库
- 管理仓库分支（列出、创建、删除）
- 下载仓库内容
- 上传本地目录或文件到仓库 (支持加密上传)
- 查看仓库文件/目录列表
- 读取仓库中文件的文本内容
- 在仓库中创建或更新文本文件（如配置文件、README、代码等）
- 删除仓库中的文件
- 管理 Space 应用（创建、发布、重新发布、查看状态）

【本地文件系统】
- 在本地创建目录（支持递归创建多级目录）
- 在本地创建或覆盖文本文件
- 列出本地目录的文件和子目录
- 读取本地文件的文本内容

仓库 ID 的格式为: 组织名/仓库名（如 myorg/my-model）。
仓库类型有: models（模型）、datasets（数据集）、spaces（应用）。

请用中文回复用户，并在需要时调用工具来完成任务。对于危险操作（如删除仓库、删除文件、删除分支），请先与用户确认。
注意区分仓库操作和本地文件操作：仓库操作需要 repo_id，本地操作使用本地文件路径。"""


def chat_completion(
    messages: List[Dict],
    config: Dict[str, str],
    tools: Optional[List[Dict]] = None,
) -> Dict:
    """
    调用 OpenAI 兼容的 Chat Completion API

    Args:
        messages: 消息列表
        config: AI 配置 {"api_base", "api_key", "model"}
        tools: 工具定义列表

    Returns:
        API 响应 JSON
    """
    api_base = config["api_base"].rstrip("/")
    url = f"{api_base}/chat/completions"

    headers = {
        "Content-Type": "application/json",
    }
    if config.get("api_key"):
        headers["Authorization"] = f"Bearer {config['api_key']}"

    payload = {
        "model": config.get("model", DEFAULT_AI_MODEL),
        "messages": messages,
    }
    if tools:
        payload["tools"] = tools

    response = requests.post(url, headers=headers, json=payload, timeout=120)
    response.raise_for_status()
    return response.json()


def chat_completion_stream(
    messages: List[Dict],
    config: Dict[str, str],
    tools: Optional[List[Dict]] = None,
) -> Generator[Dict, None, None]:
    """
    调用 OpenAI 兼容的 Chat Completion API（流式模式）

    通过 SSE (Server-Sent Events) 逐步返回响应片段。

    Args:
        messages: 消息列表
        config: AI 配置 {"api_base", "api_key", "model"}
        tools: 工具定义列表

    Yields:
        每个 SSE 事件对应的 JSON 字典（delta chunk）
    """
    api_base = config["api_base"].rstrip("/")
    url = f"{api_base}/chat/completions"

    headers = {
        "Content-Type": "application/json",
    }
    if config.get("api_key"):
        headers["Authorization"] = f"Bearer {config['api_key']}"

    payload = {
        "model": config.get("model", DEFAULT_AI_MODEL),
        "messages": messages,
        "stream": True,
    }
    if tools:
        payload["tools"] = tools

    response = requests.post(url, headers=headers, json=payload, timeout=120, stream=True)
    response.raise_for_status()
    response.encoding = "utf-8"

    for line in response.iter_lines(decode_unicode=True):
        if not line:
            continue
        # SSE 格式: "data: {...}" 或 "data: [DONE]"
        if line.startswith("data: "):
            data_str = line[6:]
            if data_str.strip() == "[DONE]":
                break
            try:
                yield json.loads(data_str)
            except json.JSONDecodeError:
                continue


# ==================== Agent 循环 ====================

def run_agent(
    user_input: str,
    messages: List[Dict],
    config: Dict[str, str],
    client,
    max_iterations: int = 10,
) -> str:
    """
    运行 Agent 循环：发送消息 → 处理工具调用 → 返回最终回复

    Args:
        user_input: 用户输入
        messages: 历史消息列表（会被就地修改）
        config: AI 配置
        client: HubClient 实例
        max_iterations: 最大循环次数

    Returns:
        助手最终的文字回复
    """
    messages.append({"role": "user", "content": user_input})

    for _ in range(max_iterations):
        response = chat_completion(messages, config, tools=TOOLS)
        choice = response["choices"][0]
        message = choice["message"]

        # 将助手回复加入消息历史
        messages.append(message)

        # 检查是否需要执行工具调用
        tool_calls = message.get("tool_calls")
        if not tool_calls:
            # 没有工具调用，返回文字回复
            return message.get("content", "")

        # 执行所有工具调用
        for tool_call in tool_calls:
            func = tool_call["function"]
            tool_name = func["name"]
            try:
                arguments = json.loads(func["arguments"])
            except json.JSONDecodeError:
                arguments = {}

            print(f"  ⚙ 调用工具: {tool_name}({json.dumps(arguments, ensure_ascii=False)})", file=sys.stderr)
            result = execute_tool(tool_name, arguments, client)
            print(f"  ✓ 完成", file=sys.stderr)

            # 将工具结果加入消息历史
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call["id"],
                "content": result,
            })

    return "已达到最大迭代次数，请尝试简化您的请求。"


def run_agent_stream(
    user_input: str,
    messages: List[Dict],
    config: Dict[str, str],
    client,
    max_iterations: int = 1000,
) -> Generator[str, None, None]:
    """
    运行 Agent 循环（流式模式）：发送消息 → 流式返回文本 → 处理工具调用 → 继续

    Args:
        user_input: 用户输入
        messages: 历史消息列表（会被就地修改）
        config: AI 配置
        client: HubClient 实例
        max_iterations: 最大循环次数

    Yields:
        助手回复的文本片段
    """
    messages.append({"role": "user", "content": user_input})

    for _ in range(max_iterations):
        stream = chat_completion_stream(messages, config, tools=TOOLS)

        # 直接迭代流，实时 yield content 片段，同时收集 tool_calls
        content_parts: List[str] = []
        tool_calls_map: Dict[int, Dict] = {}

        for chunk in stream:
            choices = chunk.get("choices", [])
            if not choices:
                continue
            delta = choices[0].get("delta", {})

            # 实时 yield content
            if delta.get("content"):
                text = delta["content"]
                content_parts.append(text)
                yield text

            # 收集 tool_calls
            if delta.get("tool_calls"):
                for tc_delta in delta["tool_calls"]:
                    idx = tc_delta["index"]
                    if idx not in tool_calls_map:
                        tool_calls_map[idx] = {
                            "id": tc_delta.get("id", ""),
                            "type": "function",
                            "function": {
                                "name": tc_delta.get("function", {}).get("name", ""),
                                "arguments": "",
                            },
                        }
                    else:
                        if tc_delta.get("id"):
                            tool_calls_map[idx]["id"] = tc_delta["id"]
                        if tc_delta.get("function", {}).get("name"):
                            tool_calls_map[idx]["function"]["name"] = tc_delta["function"]["name"]
                    arg_delta = tc_delta.get("function", {}).get("arguments", "")
                    if arg_delta:
                        tool_calls_map[idx]["function"]["arguments"] += arg_delta

        # 组装完整 message 加入历史
        message: Dict[str, Any] = {"role": "assistant"}
        content = "".join(content_parts)
        message["content"] = content if content else None
        if tool_calls_map:
            message["tool_calls"] = [tool_calls_map[i] for i in sorted(tool_calls_map.keys())]
        messages.append(message)

        # 检查是否需要执行工具调用
        tool_calls = message.get("tool_calls")
        if not tool_calls:
            return

        # 执行所有工具调用
        for tool_call in tool_calls:
            func = tool_call["function"]
            tool_name = func["name"]
            try:
                arguments = json.loads(func["arguments"])
            except json.JSONDecodeError:
                arguments = {}

            print(f"  ⚙ 调用工具: {tool_name}({json.dumps(arguments, ensure_ascii=False)})", file=sys.stderr)
            result = execute_tool(tool_name, arguments, client)
            print(f"  ✓ 完成", file=sys.stderr)

            messages.append({
                "role": "tool",
                "tool_call_id": tool_call["id"],
                "content": result,
            })

    yield "\n已达到最大迭代次数，请尝试简化您的请求。"


# ==================== 交互式聊天 ====================

def interactive_chat(config: Dict[str, str], client, stream: bool = True):
    """
    交互式聊天循环

    Args:
        config: AI 配置
        client: HubClient 实例
        stream: 是否使用流式模式（默认: True）
    """
    # 启用 readline 支持：上下键历史、行编辑（历史跟着用户走）
    try:
        import readline
        from .auth import load_token as _load_token
        _, _, _username = _load_token()
        _history_name = f"ai_history_{_username}" if _username else "ai_history"
        history_path = Path(os.path.expanduser(f"~/.moha/{_history_name}"))
        history_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            readline.read_history_file(str(history_path))
        except (FileNotFoundError, PermissionError):
            pass
        readline.set_history_length(500)
        import atexit
        atexit.register(readline.write_history_file, str(history_path))
    except ImportError:
        pass  # Windows 可能没有 readline

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    print("晓石 AI 助手（输入 'exit' 或 'quit' 退出，'clear' 清除对话历史）")
    print(f"模型: {config.get('model', DEFAULT_AI_MODEL)}")
    print(f"API: {config.get('api_base', '未配置')}")
    print("-" * 50)

    while True:
        try:
            user_input = input("\n你: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit"):
            print("再见！")
            break
        if user_input.lower() == "clear":
            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            print("对话历史已清除。")
            continue

        try:
            if stream:
                print("\n⏳ 思考中...", end="", flush=True)
                first_chunk = True
                for chunk in run_agent_stream(user_input, messages, config, client):
                    if first_chunk:
                        # 清除占位符，打印 "助手: " 前缀
                        print("\r\033[K助手: ", end="", flush=True)
                        first_chunk = False
                    print(chunk, end="", flush=True)
                if first_chunk:
                    # 没有任何输出（纯工具调用无文本）
                    print("\r\033[K助手: (已完成操作)", flush=True)
                else:
                    print()  # 换行
            else:
                reply = run_agent(user_input, messages, config, client)
                print(f"\n助手: {reply}")
        except requests.exceptions.ConnectionError:
            print(f"\n错误: 无法连接到 AI API ({config.get('api_base')})", file=sys.stderr)
            print("请检查 API 地址是否正确，可使用 'moha ai-config' 重新配置。", file=sys.stderr)
            # 移除最后的用户消息，保持消息一致性
            if messages and messages[-1].get("role") == "user":
                messages.pop()
        except requests.exceptions.HTTPError as e:
            print(f"\n错误: AI API 请求失败: {e}", file=sys.stderr)
            if messages and messages[-1].get("role") == "user":
                messages.pop()
        except Exception as e:
            print(f"\n错误: {e}", file=sys.stderr)
            if messages and messages[-1].get("role") == "user":
                messages.pop()
