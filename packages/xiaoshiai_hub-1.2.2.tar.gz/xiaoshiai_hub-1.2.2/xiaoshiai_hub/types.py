"""
Type definitions for XiaoShi AI Hub SDK
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Literal, Dict

@dataclass
class ProductVersion:
    """Product version information."""
    version: str
    url: str
    appVersion: str

   

@dataclass
class Flavor:
    """Flavor information"""
    enabled: bool
    id: str
    model: str
    name: str
    type: str
    vendor: str
    nodeSelector: Dict[str, str] = field(default_factory=dict)
    

@dataclass
class ClusterWorkspace:
    """Cluster workspace information."""
    id: str
    name: str
    tenant: str
    cluster: str



@dataclass
class Product:
    """Product information."""
    id: str
    name: str
    category: str
    versions: List[ProductVersion]
    labels: Dict[str, str] = field(default_factory=dict)
    annotations: Dict[str, str] = field(default_factory=dict)
    

@dataclass
class Cluster:
    """Cluster information."""
    id: str
    name: str
    published: bool
    state: str
    type: str
    description: Optional[str] = None

@dataclass
class SpaceEndpoint:
    """Endpoint information for a Space."""
    name: str
    url: str
    kind: str

@dataclass
class SpaceMetatdataStatus:
    """Status of a Space."""
    healthy: bool
    phase: Optional[str] = None# e.g., "Reconciling" "Terminating" "Installed" "Failed" "Paused" "Healthy" "Degraded" "Unhealthy" ""
    message: Optional[str] = None
    endpoints: Optional[List[SpaceEndpoint]] = None

@dataclass
class SpaceMetadata:
    """Metadata for Spaces repositories."""
    name: str
    namespace: str
    cluster: str
    status: SpaceMetatdataStatus

@dataclass
class Repository:
    """Repository information."""
    name: str
    organization: str
    owner: str
    creator: str
    type: str  # "models" or "datasets" or "spaces"
    visibility: str
    genealogy: Optional[Dict] = None
    description: Optional[str] = None
    metadata: Dict[str, List[str]] = field(default_factory=dict)  # Repository metadata
    annotations: Dict[str, str] = field(default_factory=dict)  # Repository annotations/metadata
    spaceMetadata: Optional[SpaceMetadata] = None  # Only for Spaces repositories




@dataclass
class Signature:
    """Git signature (author/committer)."""
    name: str
    email: str
    when: datetime


@dataclass
class Commit:
    """Git commit information."""
    hash: str
    message: str
    author: Signature
    committer: Signature
    timestamp: datetime
    tree_hash: Optional[str] = None
    parents: Optional[List[str]] = None


@dataclass
class Ref:
    """Git reference (branch/tag)."""
    name: str
    ref: str
    type: str  # "branch" or "tag"
    hash: str
    is_default: bool = False
    last_commit: Optional[Commit] = None


@dataclass
class GitLFSMeta:
    """Git LFS metadata."""
    oid: str
    size: int


@dataclass
class Symlink:
    """Symlink information."""
    target: str


@dataclass
class Submodule:
    """Submodule information."""
    url: str
    path: str
    branch: str


FileType = Literal["file", "dir", "symlink", "submodule"]


@dataclass
class GitContent:
    """Git content (file or directory)."""
    name: str
    path: str
    type: FileType
    size: int = 0
    hash: Optional[str] = None
    content_type: Optional[str] = None
    content: Optional[str] = None
    content_omitted: bool = False
    last_commit: Optional[Commit] = None
    symlink: Optional[Symlink] = None
    submodule: Optional[Submodule] = None
    lfs: Optional[GitLFSMeta] = None
    entries: Optional[List['GitContent']] = None

