"""
XiaoShi AI Hub Client
"""

import base64
import os
from typing import Dict, List, Optional
from urllib.parse import urlparse


import requests
from xiaoshiai_hub.envelope_crypto import DEFAULT_ALGORITHM, DataKey

try:
    from tqdm.auto import tqdm
except ImportError:
    tqdm = None

from .exceptions import (
    AuthenticationError,
    HTTPError,
    RepositoryNotFoundError,
)
from .types import Cluster, ClusterWorkspace, Flavor, Product, ProductVersion, Repository, Ref, GitContent, GitLFSMeta, SpaceMetadata,SpaceMetatdataStatus, SpaceEndpoint


# 默认基础 URL，可通过环境变量 MOHA_ENDPOINT 覆盖
DEFAULT_BASE_URL = os.environ.get(
    "MOHA_ENDPOINT",
    "https://rune.develop.xiaoshiai.cn"
)



class HubClient:
    """Client for interacting with XiaoShi AI Hub API."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        token: Optional[str] = None,
    ):
        """
        Initialize the Hub client.

        Args:
            base_url: Base URL of the Hub API (default: from MOHA_ENDPOINT env var)
            username: Username for authentication
            password: Password for authentication
            token: Token for authentication (alternative to username/password)
        """
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip('/')
        self.username = username
        self.password = password
        self.token = token
        self.session = requests.Session()
        
        # Set up authentication
        if token:
            self.session.headers['Authorization'] = f'Bearer {token}'
        elif username and password:
            auth_string = f"{username}:{password}"
            encoded = base64.b64encode(auth_string.encode()).decode()
            self.session.headers['Authorization'] = f'Basic {encoded}'
    
    def _make_request(
        self,
        method: str,
        url: str,
        **kwargs
    ) -> requests.Response:
        """Make an HTTP request with error handling."""
        try:
            response = self.session.request(method, url, **kwargs)
            
            if response.status_code == 401:
                raise AuthenticationError("Authentication failed")
            elif response.status_code == 404:
                raise RepositoryNotFoundError("Resource not found")
            elif response.status_code >= 400:
                raise HTTPError(
                    f"HTTP {response.status_code}: {response.reason}",
                    status_code=response.status_code
                )
            
            return response
        except requests.RequestException as e:
            raise HTTPError(f"Request failed: {str(e)}")
    
    def cancel_repository_encrypted(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
    ) -> None:
        """Cancel repository encrypted flag."""
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/encryption/cancel"
        response = self._make_request("PUT", url)
        if response.status_code != 200:
            raise HTTPError(f"Failed to cancel repository encrypted flag: {response.text}")
        
    def set_repository_encrypted(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
    ) -> None:
        """Set repository encrypted flag."""
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/encryption/set"
        response = self._make_request("PUT", url)
        if response.status_code != 200:
            raise HTTPError(f"Failed to set repository encrypted flag: {response.text}")
        
    # 创建space的时候，获取集群使用
    def list_clusters(
        self,
        organization: str,
    ) -> List[Cluster]:
        """List remote clusters available for Spaces deployment."""
        url = f"{self.base_url}/moha/v1/organizations/{organization}/clusters"
        response = self._make_request("GET", url)
        data = response.json()

        items = data.get('items', []) if isinstance(data, dict) else data
        clusters = []
        for cluster_data in items:
            clusters.append(Cluster(
                id=cluster_data.get('id', ''),
                name=cluster_data.get('name', ''),
                published=cluster_data.get('published', False),
                state=cluster_data.get('state', ''),
                type=cluster_data.get('type', ''),
                description=cluster_data.get('description'),
            ))

        return clusters
    
    # 创建space的时候，获取集群下面的工作空间
    def list_cluster_workspaces(
        self,
        organization: str,
        cluster_id: str,
    ) -> List[ClusterWorkspace]:
        """List workspaces under clusters for Spaces deployment."""
        url = f"{self.base_url}/moha/v1/organizations/{organization}/clusters/{cluster_id}/workspaces"
        response = self._make_request("GET", url)
        data = response.json()
        items = data.get('items', []) if isinstance(data, dict) else data
        workspaces = []
        for ws_data in items:
            workspaces.append(ClusterWorkspace(
                id=ws_data.get('id', ''),
                name=ws_data.get('name', ''),
                tenant=ws_data.get('tenant', ''),
                cluster=ws_data.get('cluster', ''),
            ))

        return workspaces
    
    # 创建space的时候，获取工作空间下面的flavor
    def list_workspace_flavors(
        self,
        organization: str,
        cluster_id: str,
        workspace_id: str,
    ) -> List[Flavor]:
        """List flavors for Spaces deployment."""
        url = f"{self.base_url}/moha/v1/organizations/{organization}/clusters/{cluster_id}/workspaces/{workspace_id}/flavors"
        response = self._make_request("GET", url)
        data = response.json()
        items = data.get('items', []) if isinstance(data, dict) else data
        flavors = []
        for flavor_data in items:
            flavors.append(Flavor(
                enabled=flavor_data.get('enabled', False),
                id=flavor_data.get('id', ''),
                model=flavor_data.get('model', ''),
                name=flavor_data.get('name', ''),
                type=flavor_data.get('type', ''),
                vendor=flavor_data.get('vendor', ''),
                nodeSelector=flavor_data.get('nodeSelector', {}),
            ))
        return flavors
    
    def get_product(
        self,
        organization: str,
        product_id: str,
    ) -> Product:
        """Get product information by ID."""
        url = f"{self.base_url}/moha/v1/organizations/{organization}/products/{product_id}"
        response = self._make_request("GET", url)
        data = response.json()

        versions = []
        for version_data in data.get('versions', []):
            versions.append(ProductVersion(
                appVersion=version_data.get('appVersion', ''),
                version=version_data.get('version', ''),
                url=version_data.get('url', '')
            ))

        return Product(
            id=data.get('id', ''),
            name=data.get('name', ''),
            category=data.get('category', ''),
            versions=versions,
            labels=data.get('labels', {}),
            annotations=data.get('annotations', {}),
    )

    
    # 创建space的时候，获取产品使用
    def list_products(
        self,
        organization: str,
    ) -> List[Product]:
        """List products available for the organization."""
        params = {
            "category":"app"
        }
        url = f"{self.base_url}/moha/v1/organizations/{organization}/products"
        response = self._make_request("GET", url,params=params)
        data = response.json()

        items = data.get('items', []) if isinstance(data, dict) else data
        products = []
        for product_data in items:
            versions = []
            for version_data in product_data.get('versions', []):
                versions.append(ProductVersion(
                    appVersion=version_data.get('appVersion', ''),
                    version=version_data.get('version', ''),
                    url=version_data.get('url', '')
                ))
            products.append(Product(
                id=product_data.get('id', ''),
                name=product_data.get('name', ''),
                category=product_data.get('category', ''),
                versions=versions,
                labels=product_data.get('labels', {}),
                annotations=product_data.get('annotations', {})
            ))
        return products

    # 创建分支
    def create_branch(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        branch_name: str,
        from_branch: str,
    ) -> None:
        """
        创建新分支。如果分支已存在，则直接返回。

        Args:
            organization: 组织名称
            repo_type: 仓库类型 ("models" 或 "datasets" 或 "spaces")
            repo_name: 仓库名称
            branch_name: 要创建的分支名称
            from_branch: 基于哪个分支创建
        """
        # 先检查分支是否已存在
        refs = self.get_repository_refs(organization, repo_type, repo_name)
        for ref in refs:
            if ref.name == branch_name:
                # 分支已存在，直接返回
                return

        # 分支不存在，创建新分支
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/refs/{branch_name}"
        body = {
            "base": from_branch,
        }
        response = self._make_request("POST", url, json=body)
        if response.status_code != 200:
            raise HTTPError(f"Failed to create branch: {response.text}")

    # 删除分支
    def delete_branch(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        branch_name: str,
    ) -> None:
        """
        删除分支。如果分支不存在，则直接返回。

        Args:
            organization: 组织名称
            repo_type: 仓库类型 ("models" 或 "datasets" 或 "spaces")
            repo_name: 仓库名称
            branch_name: 要删除的分支名称
        """
        # 先检查分支是否存在
        refs = self.get_repository_refs(organization, repo_type, repo_name)
        branch_exists = False
        for ref in refs:
            if ref.name == branch_name:
                branch_exists = True
                break

        if not branch_exists:
            # 分支不存在，直接返回
            return

        # 分支存在，删除它
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/refs/{branch_name}"
        response = self._make_request("DELETE", url)
        if response.status_code != 200:
            raise HTTPError(f"Failed to delete branch: {response.text}")

    def list_repositories(
        self,
        repo_type: str = "models",
        scope: str = "public",
        organization: Optional[str] = None,
        mycreated: Optional[bool] = False,
    ) -> List[Repository]:
        """
        列出仓库。

        Args:
            repo_type: 仓库类型 ("models", "datasets", "spaces")
            scope: 查询范围:
                - "public": 公开仓库 (/moha/v1/{type})
                - "create": 我创建的仓库 (/moha/v1/my-create/{type})
                - "favorite": 我喜欢的仓库 (/moha/v1/my-favorite/{type})
                - "organization": 组织内的仓库 (/moha/v1/organizations/{org}/{type})
            organization: 组织名称（仅当 scope="organization" 时需要）
            mycreated: 是否只显示我创建的仓库（仅当 scope="organization" 时可用，用于过滤该组织内我创建的仓库）

        Returns:
            仓库列表
        """
        params = {}
        
        if scope == "public":
            url = f"{self.base_url}/moha/v1/{repo_type}"
        elif scope == "create":
            url = f"{self.base_url}/moha/v1/my-create/{repo_type}"
        elif scope == "favorite":
            url = f"{self.base_url}/moha/v1/my-favorite/{repo_type}"
        elif scope == "organization":
            if not organization:
                raise ValueError("organization is required when scope is 'organization'")
            url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}"
            params['my-created'] = str(mycreated).lower()
        else:
            raise ValueError(f"Invalid scope: {scope}. Must be one of: public, create, favorite, organization")

        response = self._make_request("GET", url, params=params if params else None)
        data = response.json()

        # 响应格式为 {"items": [...], "total": N}
        items = data.get('items', []) if isinstance(data, dict) else data

        repositories = []
        for repo_data in items:
            repositories.append(Repository(
                name=repo_data.get('name', ''),
                organization=repo_data.get('organization', ''),
                owner=repo_data.get('owner', ''),
                creator=repo_data.get('creator', ''),
                type=repo_data.get('type', ''),
                visibility=repo_data.get('visibility', 'internal'),
                description=repo_data.get('description'),
                metadata=repo_data.get('metadata', {}),
                annotations=repo_data.get('annotations', {}),
                spaceMetadata=repo_data.get('spaceMetadata'),
            ))

        return repositories

    def update_repository(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        description: Optional[str] = None,
        visibility: Optional[str] = None,
        annotations: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, List[str]]] = None,
        base_model: Optional[List[str]] = None,
        relationship: Optional[str] = None,
    ) -> None:
        """更新仓库信息。

        Args:
            organization: 组织名称
            repo_type: 仓库类型 ("models", "datasets", "spaces")
            repo_name: 仓库名称
            description: 仓库描述（None 表示保持原值）
            visibility: 可见性 ("public", "internal", "private"，None 表示保持原值）
            annotations: 仓库标注，会与现有标注合并（新值覆盖旧值）
            metadata: 仓库元数据，会与现有元数据合并（新值覆盖旧值）
            base_model: 基础模型列表（None 表示保持原值）
            relationship: 与基础模型的关系（None 表示保持原值）
        """
        # 获取仓库当前信息
        repo = self.get_repository_info(organization, repo_type, repo_name)

        # 合并各字段：传入的覆盖现有的，未传入的保持原值
        merged_description = description if description is not None else repo.description
        merged_visibility = visibility if visibility is not None else repo.visibility
        merged_owner = self.username if merged_visibility == "private" else repo.owner

        # 合并 annotations
        merged_annotations = dict(repo.annotations) if repo.annotations else {}
        if annotations:
            merged_annotations.update(annotations)

        # 合并 metadata
        merged_metadata = dict(repo.metadata) if repo.metadata else {}
        if metadata:
            merged_metadata.update(metadata)

        # 合并 genealogy
        merged_base_model = base_model
        merged_relationship = relationship
        if repo.genealogy:
            if merged_base_model is None and 'baseModel' in repo.genealogy:
                merged_base_model = repo.genealogy['baseModel']
            if merged_relationship is None and 'relationship' in repo.genealogy:
                merged_relationship = repo.genealogy['relationship']

        # 构建请求体
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}"
        body: Dict = {
            "name": repo_name,
            "organization": organization,
            "type": self._normalize_repo_type(repo_type),
            "owner": merged_owner or "",
            "visibility": merged_visibility,
            "annotations": merged_annotations,
        }
        if merged_description is not None:
            body["description"] = merged_description
        if merged_metadata:
            body["metadata"] = merged_metadata
        if merged_base_model or merged_relationship:
            body["requestgenealogy"] = {}
            if merged_base_model:
                body["requestgenealogy"]["baseModel"] = merged_base_model
            if merged_relationship:
                body["requestgenealogy"]["relationship"] = merged_relationship
        response = self._make_request("PUT", url, json=body)
        if response.status_code != 200:
            raise HTTPError(f"Failed to update repository: {response.text}")    
    
    # 删除仓库
    def delete_repository(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
    ) -> None:
        """Delete repository."""
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}"
        response = self._make_request("DELETE", url)
        if response.status_code != 200:
            raise HTTPError(f"Failed to delete repository: {response.text}")

    
    def _to_base_domain(
            self,
            drop_levels: int = 1
    ) -> str:
        raw = (self.base_url or "").strip().rstrip("/")
        if not raw:
            return ""
        parsed = urlparse(raw if "://" in raw else f"https://{raw}")
        host = parsed.hostname or raw.split("/")[0].split(":")[0]
        parts = host.split(".")
        if drop_levels <= 0 or len(parts) <= drop_levels + 1:
            return host 
        return ".".join(parts[drop_levels:])


    def create_space_repository(
        self,
        organization: str,
        repo_name: str,
        cluster: str,
        namespace: str,
        product_id: str,
        product_version: Optional[str] = None,
        visibility: str = "internal",
        flavor: Optional[str] = None,
        env: Optional[List[Dict[str, str]]] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        """Create a new space repository."""
        product=self.get_product(organization, product_id)
        product_info = {}
        for pr in product.versions:
            if pr.version == product_version:
                product_info["id"] = product.id
                product_info["name"] = product.name
                product_info["url"] = pr.url
                product_info["version"] = pr.version
                break

        if not product_info:
            raise HTTPError(f"Product version '{product_version}' not found for product '{product_id}'.")


        url = f"{self.base_url}/moha/v1/organizations/{organization}/spaces"
        # 构建请求体
        body: Dict = {
            "name": repo_name,
            "organization": organization,
            "visibility": visibility,
            # "creator": self.username or "",
            # "owner": self.username or "",
        }
        if description:
            body["description"] = description
        if metadata:
            body["metadata"] = metadata

        body["spaceMetadata"] = {
            "baseDomain": self._to_base_domain(),
            "cluster": cluster,
            "namespace": namespace,
            "name": repo_name,
            "product": product_info,
            "gitUsername": self.username or "",
            "gitPassword": self.token or self.password or "",
            "gitAddress": self.base_url + f"/moha/{organization}/spaces/{repo_name}.git",
        }
        if flavor:
            body["spaceMetadata"]["flavor"] = flavor
        if env:
            body["spaceMetadata"]["env"] = env

        response = self._make_request("POST", url, json=body)
        if response.status_code != 200:
            raise HTTPError(f"Failed to create repository: {response.text}")

    # 创建仓库
    def create_repository(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        description: Optional[str] = None,
        visibility: str = "internal",
        metadata: Optional[Dict[str, List[str]]] = None,
        base_model: Optional[List[str]] = None,
        relationship: Optional[str] = None,
    ) -> None:
        """
        创建新仓库。

        Args:
            organization: 组织名称
            repo_type: 仓库类型 ("models" 或 "datasets" 或 "spaces")
            repo_name: 仓库名称
            description: 仓库描述
            visibility: 可见性 ("public", "internal", "private")
            metadata: 元数据，包含 license, tasks, languages, tags, frameworks 等
            annotations: 注解
            base_model: 基础模型列表 (如 ["demo/yyyy"])
            relationship: 与基础模型的关系 ("adapter", "finetune", "quantized", "merge", "repackage" 等)

        Returns:
            创建的仓库信息
        """
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}"

        # 构建请求体
        body: Dict = {
            "name": repo_name,
            "organization": organization,
            "visibility": visibility,
            "creator": self.username or "",
            "owner": self.username or "",
        }

        if description:
            body["description"] = description
        if metadata:
            body["metadata"] = metadata

        # 构建 genealogy（模型谱系）
        if base_model or relationship:
            body["requestgenealogy"] = {}
            if base_model:
                body["requestgenealogy"]["baseModel"] = base_model
            if relationship:
                body["requestgenealogy"]["relationship"] = relationship

        response = self._make_request("POST", url, json=body)
        if response.status_code != 200:
            raise HTTPError(f"Failed to create repository: {response.text}")
        
    # 获取仓库信息
    def get_repository_info(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
    ) -> Repository:
        """
        Get repository information.

        Args:
            organization: Organization name
            repo_type: Repository type ("models" or "datasets" or "spaces")
            repo_name: Repository name

        Returns:
            Repository information
        """
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}"
        response = self._make_request("GET", url)
        data = response.json()

        # Parse annotations if present
        annotations: Dict[str, str] = {}
        if 'annotations' in data and isinstance(data['annotations'], dict):
            annotations = data['annotations']

        # Parse metadata if present
        metadata: Dict[str, List[str]] = {}
        if 'metadata' in data and isinstance(data['metadata'], dict):
            metadata = data['metadata']

        # Parse genealogy if present
        genealogy: Optional[Dict] = None
        if 'genealogy' in data and isinstance(data['genealogy'], dict):
            genealogy = data['genealogy']

        # Parse spaceMetadata if present (only for spaces)
        space_metadata: Optional[SpaceMetadata] = None
        if 'spaceMetadata' in data and isinstance(data['spaceMetadata'], dict):
            space_data = data['spaceMetadata']
            # Parse endpoints
            endpoints = None
            status_data = space_data.get('status', {})
            if isinstance(status_data, dict) and 'endpoints' in status_data:
                endpoints_list = status_data.get('endpoints', [])
                if isinstance(endpoints_list, list):
                    endpoints = [
                        SpaceEndpoint(
                            name=ep.get('name', ''),
                            url=ep.get('url', ''),
                            kind=ep.get('kind', ''),
                        )
                        for ep in endpoints_list
                    ]
            
            phase = status_data.get('phase') if isinstance(status_data, dict) else None
            message = status_data.get('message') if isinstance(status_data, dict) else None
            healthy = status_data.get('healthy', False) if isinstance(status_data, dict) else False
            
            space_metadata = SpaceMetadata(
                name=space_data.get('name', ''),
                namespace=space_data.get('namespace', ''),
                cluster=space_data.get('cluster', ''),
                status=SpaceMetatdataStatus(
                    healthy=healthy,
                    phase=phase,
                    message=message,
                    endpoints=endpoints,
                )
            )

        return Repository(
            name=data.get('name', repo_name),
            organization=data.get('organization', organization),
            owner=data.get('owner', ''),
            creator=data.get('creator', ''),
            type=data.get('type', repo_type),
            visibility=data.get('visibility', 'internal'),
            genealogy=genealogy,
            description=data.get('description'),
            metadata=metadata,
            annotations=annotations,
            spaceMetadata=space_metadata,
        )
    
    # 获取仓库的所有分支
    def get_repository_refs(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
    ) -> List[Ref]:
        """
        Get repository references (branches and tags).

        Args:
            organization: Organization name
            repo_type: Repository type ("models" or "datasets" or "spaces")
            repo_name: Repository name

        Returns:
            List of references
        """
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/refs"
        response = self._make_request("GET", url)
        data = response.json()

        refs = []
        for ref_data in data:
            refs.append(Ref(
                name=ref_data.get('name', ''),
                ref=ref_data.get('ref', ''),
                type=ref_data.get('type', ''),
                hash=ref_data.get('hash', ''),
                is_default=ref_data.get('isDefault', False),
            ))

        return refs

    def get_default_branch(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
    ) -> str:
        """
        Get the default branch name for a repository.

        Args:
            organization: Organization name
            repo_type: Repository type ("models" or "datasets" or "spaces")
            repo_name: Repository name

        Returns:
            Default branch name (defaults to "main" if not found)
        """
        refs = self.get_repository_refs(organization, repo_type, repo_name)
        for ref in refs:
            if ref.is_default and ref.type == "branch":
                return ref.name
        return "main"
    
    def get_repository_content(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        branch: str,
        path: str = "",
    ) -> GitContent:
        """
        Get repository content at a specific path.
        
        Args:
            organization: Organization name
            repo_type: Repository type ("models" or "datasets" or "spaces")
            repo_name: Repository name
            branch: Branch name
            path: Path within the repository (empty for root)
            
        Returns:
            Git content information
        """
        if path:
            url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/contents/{branch}/{path}"
        else:
            url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/contents/{branch}"
        
        response = self._make_request("GET", url)
        data = response.json()
        
        return self._parse_git_content(data)
    
    def _parse_git_content(self, data: dict) -> GitContent:
        """Parse GitContent from API response."""
        entries = None
        if 'entries' in data and data['entries']:
            entries = [self._parse_git_content(entry) for entry in data['entries']]

        lfs_meta = None
        lfs_data = data.get('lfs')
        if isinstance(lfs_data, dict):
            lfs_meta = GitLFSMeta(
                oid=lfs_data.get('oid', ''),
                size=int(lfs_data.get('size', 0) or 0),
            )
        elif isinstance(lfs_data, GitLFSMeta):
            lfs_meta = lfs_data
        
        return GitContent(
            name=data.get('name', ''),
            path=data.get('path', ''),
            type=data.get('type', 'file'),
            size=data.get('size', 0),
            hash=data.get('hash'),
            content_type=data.get('contentType'),
            content=data.get('content'),
            content_omitted=data.get('contentOmitted', False),
            lfs=lfs_meta,
            entries=entries,
        )
    
    def create_file(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        branch: str,
        file_path: str,
        content: str,
        message: str = "",
    ) -> dict:
        """
        在仓库中创建或更新一个文件（适用于小型文本文件）。

        通过 upload API 将 base64 编码的内容提交到仓库。

        Args:
            organization: 组织名称
            repo_type: 仓库类型 ("models", "datasets", "spaces")
            repo_name: 仓库名称
            branch: 分支名称
            file_path: 仓库中的文件路径
            content: 文件文本内容
            message: 提交消息

        Returns:
            API 响应
        """
        import base64 as _base64

        api_url = f"{self.base_url}/moha/{organization}/{repo_type}/{repo_name}/api/upload"

        content_bytes = content.encode("utf-8")
        content_b64 = _base64.b64encode(content_bytes).decode("utf-8")

        payload = {
            "files": [
                {
                    "path": file_path,
                    "content": content_b64,
                    "size": len(content_bytes),
                }
            ],
            "message": message or f"Create {file_path}",
            "branch": branch,
        }

        response = self._make_request("POST", api_url, json=payload)
        if response.status_code not in (200, 201):
            raise HTTPError(f"Failed to create file: {response.text}")
        return response.json()

    def delete_file(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        branch: str,
        file_path: str,
        message: str = "",
    ) -> dict:
        """
        删除仓库中的一个文件。

        Args:
            organization: 组织名称
            repo_type: 仓库类型 ("models", "datasets", "spaces")
            repo_name: 仓库名称
            branch: 分支名称
            file_path: 仓库中的文件路径
            message: 提交消息

        Returns:
            API 响应
        """
        api_url = f"{self.base_url}/moha/{organization}/{repo_type}/{repo_name}/api/upload"

        payload = {
            "files": [
                {
                    "path": file_path,
                    "action": "delete",
                }
            ],
            "message": message or f"Delete {file_path}",
            "branch": branch,
        }

        response = self._make_request("POST", api_url, json=payload)
        if response.status_code not in (200, 201):
            raise HTTPError(f"Failed to delete file: {response.text}")
        return response.json()

    def add_download_count(self, organization: str, repo_type: str, repo_name: str) -> None:
        """
        Add download count for a repository.
        
        Args:
            organization: Organization name
            repo_type: Repository type ("models" or "datasets" or "spaces")
            repo_name: Repository name
        """
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/downloads"
        response = self._make_request("POST", url)
        # 检查http code
        if response.status_code != 200:
            raise HTTPError(f"Failed to add download count: {response.text}")
    
    def download_file(
        self,
        organization: str,
        repo_type: str,
        repo_name: str,
        branch: str,
        file_path: str,
        local_path: str,
        show_progress: bool = True,
    ) -> None:
        """
        Download a single file from the repository.

        Args:
            organization: Organization name
            repo_type: Repository type ("models" or "datasets" or "spaces")
            repo_name: Repository name
            branch: Branch name
            file_path: Path to the file in the repository
            local_path: Local path to save the file
            show_progress: Whether to show download progress bar
        """
        url = f"{self.base_url}/moha/v1/organizations/{organization}/{repo_type}/{repo_name}/resolve/{branch}/{file_path}"
        response = self._make_request("GET", url, stream=True)

        # Get file size from headers
        total_size = int(response.headers.get('content-length', 0))

        # Create parent directories if needed
        import os
        os.makedirs(os.path.dirname(local_path) if os.path.dirname(local_path) else '.', exist_ok=True)

        # Prepare progress bar
        progress_bar = None
        if show_progress and tqdm is not None and total_size > 0:
            # Get filename for display
            filename = os.path.basename(file_path)
            progress_bar = tqdm(
                total=total_size,
                unit='B',
                unit_scale=True,
                unit_divisor=1024,
                desc=filename,
                leave=True,
            )

        # Write file with progress
        try:
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        # Ensure chunk is bytes for type safety
                        if isinstance(chunk, str):
                            chunk_bytes = chunk.encode('utf-8')
                        elif isinstance(chunk, bytes):
                            chunk_bytes = chunk
                        else:
                            chunk_bytes = bytes(chunk)
                        f.write(chunk_bytes)
                        if progress_bar is not None:
                            progress_bar.update(len(chunk_bytes))
        finally:
            if progress_bar is not None:
                progress_bar.close()


    def generate_data_key(
            self, 
            algorithm : Optional[str]  = DEFAULT_ALGORITHM,
            password: Optional[str] = None) -> DataKey:
        url = f"{self.base_url}/api/kms/generate-data-key"
        try:
            resp = requests.post(
                url,
                json={
                    "algorithm": algorithm,
                    "password": password,
                },
                timeout=30
            )
            resp.raise_for_status()
            data = resp.json()
            plaintext_key = base64.b64decode(data["plaintextKey"])
            encrypted_key = data["encryptedKey"]
            
            return DataKey(
                plaintext_key=plaintext_key,
                encrypted_key=encrypted_key
            )
            
        except requests.RequestException as e:
            raise e

    # ========== Space 相关方法 ==========

    def deploy_space(
        self,
        organization: str,
        repo_name: str,
    ) -> None:
        """
        发布 Space。

        Args:
            organization: 组织名称
            repo_name: 仓库名称
        """
        url = f"{self.base_url}/moha/v1/organizations/{organization}/spaces/{repo_name}:online"
        response = self._make_request("PUT", url)
        if response.status_code != 200:
            raise HTTPError(f"Failed to deploy space: {response.text}")

    def redeploy_space(
        self,
        organization: str,
        repo_name: str,
    ) -> None:
        """
        重新发布 Space。

        Args:
            organization: 组织名称
            repo_name: 仓库名称
        """
        url = f"{self.base_url}/moha/v1/organizations/{organization}/spaces/{repo_name}:restart"
        response = self._make_request("PUT", url)
        if response.status_code != 200:
            raise HTTPError(f"Failed to redeploy space: {response.text}")

    def get_space_status(
        self,
        organization: str,
        repo_name: str,
    ) -> SpaceMetatdataStatus:
        """
        获取 Space 状态。

        Args:
            organization: 组织名称
            repo_name: 仓库名称

        Returns:
            Space 状态信息
        """
        repo = self.get_repository_info(
            organization=organization,
            repo_type="spaces",
            repo_name=repo_name,
        )
        if repo.spaceMetadata is None:
            return SpaceMetatdataStatus(
                healthy=False,
                phase="Unknown",
                message="Space metadata not available",
                endpoints=None,
            )
        return repo.spaceMetadata.status
    
    @staticmethod
    def _normalize_repo_type(repo_type: str) -> str:
        repo_type = repo_type.strip()
        return repo_type[:-1] if repo_type.endswith("s") else repo_type