"""Utility functions for VizFlow."""

from __future__ import annotations

import polars as pl


def add_tod(
    df: pl.LazyFrame,
    timestamp_col: str = "ticktime",
) -> pl.LazyFrame:
    """Add time-of-day column for plotting.

    Converts HHMMSSMMM integer timestamp to pl.Datetime (epoch date)
    for direct matplotlib/seaborn compatibility.

    Note: Not supported by Delta Lake — use only for plotting.

    Args:
        df: Input LazyFrame with HHMMSSMMM timestamp column
        timestamp_col: Column with integer HHMMSSMMM format timestamps
            e.g., 93012145 = 09:30:12.145, 142058425 = 14:20:58.425

    Returns:
        LazyFrame with tod_{timestamp_col} (pl.Datetime) column added.
        Plots directly with matplotlib — X axis shows HH:MM.

    Example:
        >>> df = vf.add_tod(df, "ticktime")
        >>> pdf = df.collect().to_pandas()
        >>> ax.scatter(pdf["tod_ticktime"], pdf["bid_px0"])  # just works
    """
    _hour = pl.col(timestamp_col) // 10000000
    _minute = pl.col(timestamp_col) // 100000 % 100
    _second = pl.col(timestamp_col) // 1000 % 100
    _ms = pl.col(timestamp_col) % 1000

    tod_expr = pl.datetime(
        year=1970, month=1, day=1,
        hour=_hour,
        minute=_minute,
        second=_second,
        microsecond=_ms * 1000,
    )
    return df.with_columns(tod_expr.alias(f"tod_{timestamp_col}"))


class DurationFormatter:
    """Matplotlib axis formatter for duration values (in seconds).

    Displays tick labels as human-readable durations: "30s", "5m", "1h20m".

    Usage:
        pdf["duration_s"] = pdf["duration"].dt.total_seconds()
        ax.scatter(pdf["duration_s"], pdf["y"])
        ax.xaxis.set_major_formatter(vf.DurationFormatter())

    Or with log scale:
        ax.set_xscale("log")
        ax.xaxis.set_major_formatter(vf.DurationFormatter())
    """

    def __call__(self, x: float, pos: int | None = None) -> str:
        return format_duration(x)

    def __repr__(self) -> str:
        return "DurationFormatter()"


def format_duration(seconds: float) -> str:
    """Format seconds as human-readable duration string.

    Examples:
        0.5   -> "500ms"
        30    -> "30s"
        90    -> "1m30s"
        3600  -> "1h"
        5400  -> "1h30m"
    """
    if seconds == 0:
        return "0s"

    neg = seconds < 0
    s = abs(seconds)

    if s < 1:
        ms = round(s * 1000)
        label = f"{ms}ms"
    elif s < 60:
        if s == int(s):
            label = f"{int(s)}s"
        else:
            label = f"{s:.1f}s"
    elif s < 3600:
        m = int(s // 60)
        rem = int(s % 60)
        label = f"{m}m{rem}s" if rem else f"{m}m"
    else:
        h = int(s // 3600)
        rem_m = int((s % 3600) // 60)
        label = f"{h}h{rem_m}m" if rem_m else f"{h}h"

    return f"-{label}" if neg else label
