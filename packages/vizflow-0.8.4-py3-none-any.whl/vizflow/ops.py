"""Core operations for data transformation."""

from __future__ import annotations

from datetime import timedelta

import polars as pl



def parse_time(
    df: pl.LazyFrame,
    timestamp_col: str = "ticktime",
) -> pl.LazyFrame:
    """Parse HHMMSSMMM timestamp to elapsed trading duration.

    Adds one column:
    - elapsed_{timestamp_col}: pl.Duration (time since market open, noon break compressed)

    For time-of-day column (pl.Time) for plotting, use vf.add_tod() separately.

    Currently supports CN market only (09:30-11:30 morning, 13:00-15:00 afternoon).

    Args:
        df: Input LazyFrame
        timestamp_col: Column with integer HHMMSSMMM format timestamps
            e.g., 93012145 = 09:30:12.145, 142058425 = 14:20:58.425

    Returns:
        LazyFrame with elapsed Duration column added

    Example:
        >>> df = vf.parse_time(df, "ticktime")
        >>> # Creates: elapsed_ticktime (pl.Duration)
    """

    # Parse HHMMSSMMM to components (inline expressions, no temp columns)
    _hour = pl.col(timestamp_col) // 10000000
    _minute = pl.col(timestamp_col) // 100000 % 100
    _second = pl.col(timestamp_col) // 1000 % 100
    _ms = pl.col(timestamp_col) % 1000

    # CN market: 09:30-11:30 (morning), 13:00-15:00 (afternoon)
    # Morning session: elapsed from 09:30
    morning = pl.duration(
        hours=_hour - 9,
        minutes=_minute - 30,
        seconds=_second,
        milliseconds=_ms,
    )
    # Afternoon session: 2h morning + time from 13:00
    afternoon = pl.duration(
        hours=_hour - 11,  # 2 + (_hour - 13)
        minutes=_minute,
        seconds=_second,
        milliseconds=_ms,
    )

    elapsed = pl.when(_hour < 12).then(morning).otherwise(afternoon)
    return df.with_columns(elapsed.alias(f"elapsed_{timestamp_col}"))


def bin(df: pl.LazyFrame, widths: dict[str, float]) -> pl.LazyFrame:
    """Add bin columns for specified columns.

    Args:
        df: Input LazyFrame
        widths: Column name to bin width mapping

    Returns:
        LazyFrame with {col}_bin columns added

    Formula:
        bin_value = round(raw_value / binwidth)
        actual_value = bin_value * binwidth  # To recover
    """
    exprs = [
        (pl.col(col) / width).round().cast(pl.Int64).alias(f"{col}_bin")
        for col, width in widths.items()
    ]
    return df.with_columns(exprs)


def aggregate(
    df: pl.LazyFrame,
    group_by: list[str],
    metrics: dict[str, pl.Expr],
) -> pl.LazyFrame:
    """Aggregate data with custom metrics.

    Args:
        df: Input LazyFrame
        group_by: Columns to group by
        metrics: Name to Polars expression mapping

    Returns:
        Aggregated LazyFrame

    Example:
        metrics = {
            "count": pl.len(),
            "total_qty": pl.col("quantity").sum(),
            "vwap": pl.col("notional").sum() / pl.col("quantity").sum(),
        }
    """
    agg_exprs = [expr.alias(name) for name, expr in metrics.items()]
    return df.group_by(group_by).agg(agg_exprs)


def horizon_suffix(h: timedelta) -> str:
    """Convert timedelta to column-name suffix.

    Uses Polars' native Duration formatting with spaces stripped.
    For negative horizons, negates first then prepends '-'.

    Examples:
        >>> horizon_suffix(timedelta(0))
        '0s'
        >>> horizon_suffix(timedelta(seconds=60))
        '1m'
        >>> horizon_suffix(timedelta(seconds=90))
        '1m30s'
        >>> horizon_suffix(timedelta(minutes=3))
        '3m'
        >>> horizon_suffix(timedelta(hours=1))
        '1h'
        >>> horizon_suffix(timedelta(milliseconds=13))
        '13ms'
        >>> horizon_suffix(timedelta(seconds=-60))
        '-1m'
        >>> horizon_suffix(timedelta(minutes=-1, seconds=-30))
        '-1m30s'
    """
    if h == timedelta(0):
        return "0s"
    neg = h < timedelta(0)
    if neg:
        h = -h
    s = pl.Series([h]).dt.to_string("polars")[0]
    s = s.replace(" ", "")
    return f"-{s}" if neg else s


def horizon_cols(prefix: str, horizons: list[timedelta]) -> list[str]:
    """Generate column names for horizons.

    Examples:
        >>> horizon_cols("mid", [timedelta(seconds=60), timedelta(minutes=3)])
        ['mid_1m', 'mid_3m']
        >>> horizon_cols("mid", [timedelta(milliseconds=13), timedelta(milliseconds=500)])
        ['mid_13ms', 'mid_500ms']
    """
    return [f"{prefix}_{horizon_suffix(h)}" for h in horizons]


def _horizon_to_suffix(horizon_seconds: int) -> str:
    """Convert horizon in seconds to column name suffix.

    DEPRECATED: Use horizon_suffix(timedelta) instead.
    Kept for forward_return() backward compatibility.
    """
    if horizon_seconds <= 60:
        return f"{horizon_seconds}s"
    else:
        minutes = horizon_seconds // 60
        return f"{minutes}m"


def forward_return(
    df_trade: pl.LazyFrame,
    df_alpha: pl.LazyFrame,
    horizons: list[timedelta],
    trade_time_col: str = "elapsed_alpha_ts",
    alpha_time_col: str = "elapsed_ticktime",
    price_col: str = "mid",
    symbol_col: str = "ukey",
    tolerance: timedelta = timedelta(seconds=5),
) -> pl.LazyFrame:
    """Merge alpha's future price to trade and calculate forward returns.

    For each trade row:
    1. Look up alpha price at trade_time + horizon
    2. Add forward_{price_col}_{horizon} column (the future price)
    3. Calculate y_{horizon} = (forward_price - current_price) / current_price

    Args:
        df_trade: Trade LazyFrame with trade_time_col (Duration) and price_col
        df_alpha: Alpha LazyFrame with alpha_time_col (Duration) and price_col
        horizons: List of horizons as timedelta
        trade_time_col: Time column in trade df (default: "elapsed_alpha_ts")
        alpha_time_col: Time column in alpha df (default: "elapsed_ticktime")
        price_col: Column name for price in both dfs (default: "mid")
        symbol_col: Symbol column for grouping (default: "ukey")
        tolerance: Max time difference for asof join (default: 5s)

    Returns:
        Trade LazyFrame with forward_* and y_* columns added

    Example:
        >>> df = vf.forward_return(df_trade, df_alpha,
        ...     horizons=[timedelta(seconds=60), timedelta(minutes=3)])
    """
    # Collect for asof join
    trade = df_trade.collect()
    alpha = df_alpha.collect()

    # Prepare alpha lookup table: (symbol, time) -> price
    alpha_lookup = alpha.select([
        pl.col(symbol_col),
        pl.col(alpha_time_col),
        pl.col(price_col),
    ]).sort([symbol_col, alpha_time_col])

    for horizon in horizons:
        suffix = horizon_suffix(horizon)
        forward_col = f"forward_{price_col}_{suffix}"
        return_col = f"y_{suffix}"

        # Add target time column for this horizon
        trade = trade.with_columns(
            (pl.col(trade_time_col) + horizon).alias("_forward_time")
        )

        # Sort by join columns (required for asof join)
        trade = trade.sort([symbol_col, "_forward_time"])

        # Asof join: find alpha price at forward_time
        joined = trade.join_asof(
            alpha_lookup.rename({alpha_time_col: "_alpha_time", price_col: "_forward_price"}),
            left_on="_forward_time",
            right_on="_alpha_time",
            by=symbol_col,
            strategy="nearest",
            tolerance=tolerance,
        )

        # Add forward price and calculate return (guard against zero price)
        # Explicitly cast to Float64 to ensure consistent schema across dates
        trade = joined.with_columns([
            pl.col("_forward_price").cast(pl.Float64).alias(forward_col),
            pl.when(pl.col(price_col) != 0)
            .then((pl.col("_forward_price") - pl.col(price_col)) / pl.col(price_col))
            .otherwise(pl.lit(None, dtype=pl.Float64))
            .alias(return_col),
        ]).drop(["_forward_time", "_alpha_time", "_forward_price"])

    return trade.lazy()


def mark_to_close(
    df_trade: pl.LazyFrame,
    df_univ: pl.LazyFrame,
    mid_col: str = "mid",
    close_col: str = "close",
    symbol_col: str = "ukey",
) -> pl.LazyFrame:
    """Add mark-to-close return column.

    Joins trade with universe data to get close price, then calculates:
    y_close = (close - mid) / mid

    Args:
        df_trade: Trade LazyFrame with mid_col and symbol_col
        df_univ: Universe LazyFrame with close_col and symbol_col
        mid_col: Column name for mid price in trade df (default: "mid")
        close_col: Column name for close price in univ df (default: "close")
        symbol_col: Symbol column for joining (default: "ukey")

    Returns:
        Trade LazyFrame with y_close column added

    Example:
        >>> df_trade = vf.scan_trade(date)
        >>> df_univ = vf.scan_univ(date)
        >>> df = vf.mark_to_close(df_trade, df_univ)
        >>> # Creates: y_close
    """
    # Select only needed columns from univ to avoid column conflicts
    univ_cols = [symbol_col, close_col]
    # Check if data_date exists in both for multi-day joining
    trade_schema = df_trade.collect_schema()
    univ_schema = df_univ.collect_schema()

    if "data_date" in trade_schema.names() and "data_date" in univ_schema.names():
        # Multi-day case: join on symbol and date
        join_cols = [symbol_col, "data_date"]
        univ_cols.append("data_date")
    else:
        # Single-day case: join on symbol only
        join_cols = [symbol_col]

    # Join with univ to get close price
    df = df_trade.join(
        df_univ.select(univ_cols),
        on=join_cols,
        how="left",
    )

    # Calculate return (guard against zero mid)
    df = df.with_columns(
        pl.when(pl.col(mid_col) != 0)
        .then((pl.col(close_col) - pl.col(mid_col)) / pl.col(mid_col))
        .otherwise(pl.lit(None))
        .alias("y_close")
    )

    return df


def sign_by_side(
    df: pl.LazyFrame,
    cols: list[str],
    side_col: str = "order_side",
    prefix: str = "sided_",
) -> pl.LazyFrame:
    """Create side-signed copies of return columns.

    For Buy trades: keep sign as-is (price going up = positive = good)
    For Sell trades: negate sign (price going down = positive = good)

    Creates new columns with the given prefix. Original columns are unchanged.

    Args:
        df: LazyFrame with return columns
        cols: List of column names to sign (e.g., ["return", "markout"])
        side_col: Column containing order side (default: "order_side")
            Expected values: "Buy" or "Sell"
        prefix: Prefix for new column names (default: "sided_")

    Returns:
        LazyFrame with new sided columns added (originals unchanged)

    Example:
        >>> df = vf.sign_by_side(df, cols=["return", "markout"])
        >>> # Creates sided_return, sided_markout (return, markout unchanged)
    """
    signed_exprs = []
    for col in cols:
        signed = (
            pl.when(pl.col(side_col) == "Sell")
            .then(-pl.col(col))
            .otherwise(pl.col(col))
            .alias(f"{prefix}{col}")
        )
        signed_exprs.append(signed)

    return df.with_columns(signed_exprs)


def merge_forward(
    lf_trade: pl.LazyFrame,
    lf_ref: pl.LazyFrame,
    ref_cols: list[str],
    horizon: timedelta,
    trade_time_col: str,
    ref_time_col: str,
    symbol_col: str = "ukey",
    strategy: str = "backward",
    tolerance: timedelta | None = None,
) -> pl.LazyFrame:
    """Merge forward values from reference LazyFrame at a single horizon.

    Performs an asof join: for each trade row, looks up ref_cols at
    trade_time + horizon. Output columns are renamed to {col}_{suffix}.

    Designed for per-horizon lazy composition:
        partials = [merge_forward(..., horizon=h) for h in HORIZONS]
        df = pl.concat(partials).collect()  # CACHE shares scan+sort

    Args:
        lf_trade: Trade LazyFrame with trade_time_col (Duration)
        lf_ref: Reference LazyFrame with ref_time_col (Duration) and ref_cols
        ref_cols: Columns to bring forward (e.g., ["mid", "bid_px0"])
        horizon: Single timedelta horizon
        trade_time_col: Time column in trade df (Duration)
        ref_time_col: Time column in ref df (Duration)
        symbol_col: Symbol column for grouping (default: "ukey")
        strategy: asof join strategy (default: "backward")
        tolerance: Optional tolerance for asof join

    Returns:
        LazyFrame with {ref_col}_{suffix} columns added

    Example:
        >>> lf = vf.merge_forward(
        ...     lf_trade, lf_quote,
        ...     ref_cols=["bid_px0", "ask_px0"],
        ...     horizon=timedelta(seconds=60),
        ...     trade_time_col="elapsed_update_exchange_ts",
        ...     ref_time_col="elapsed_ticktime",
        ... )
    """
    suffix = horizon_suffix(horizon)

    # Projection pushdown: only needed columns from ref
    lf_ref_proj = lf_ref.select([symbol_col, ref_time_col] + ref_cols)
    lf_ref_sorted = lf_ref_proj.sort([symbol_col, ref_time_col])

    # Add forward time, sort for asof join
    lf_shifted = (
        lf_trade
        .with_columns(
            (pl.col(trade_time_col) + horizon).alias("_forward_time")
        )
        .sort([symbol_col, "_forward_time"])
    )

    # Asof join
    join_kwargs: dict = {
        "left_on": "_forward_time",
        "right_on": ref_time_col,
        "by": symbol_col,
        "strategy": strategy,
    }
    if tolerance is not None:
        join_kwargs["tolerance"] = tolerance

    lf_joined = lf_shifted.join_asof(lf_ref_sorted, **join_kwargs)

    # Rename ref_cols to {col}_{suffix}
    rename_map = {col: f"{col}_{suffix}" for col in ref_cols}
    lf_joined = lf_joined.rename(rename_map)

    # Drop temp columns and any ref_time_col leaked from the join
    cols_to_drop = ["_forward_time"]
    schema = lf_joined.collect_schema()
    trade_schema = lf_trade.collect_schema()
    if f"{ref_time_col}_right" in schema.names():
        cols_to_drop.append(f"{ref_time_col}_right")
    elif ref_time_col in schema.names() and ref_time_col not in trade_schema.names():
        cols_to_drop.append(ref_time_col)

    return lf_joined.drop(cols_to_drop)


def melt_forward(
    df: pl.DataFrame,
    ref_cols: list[str],
    horizons: list[timedelta],
    id_cols: list[str] | None = None,
) -> pl.DataFrame:
    """Convert wide forward columns to long format for Delta Lake storage.

    Transforms columns like bid_px0_0s, bid_px0_1m, ask_px0_0s, ask_px0_1m
    into long format with: id_cols, ref_col, horizon, forward_value.

    Args:
        df: DataFrame with wide forward columns ({ref_col}_{suffix})
        ref_cols: List of ref_cols that were merged (e.g., ["bid_px0", "ask_px0"])
        horizons: List of horizons as timedelta
        id_cols: Columns to keep as identifiers (default: ["seq", "data_date"]).

    Returns:
        Long format DataFrame with columns:
        - id_cols as-is (e.g., seq, data_date)
        - ref_col: "bid_px0", "ask_px0", etc.
        - horizon: Duration value
        - forward_value: the price value

    Example:
        >>> df_long = vf.melt_forward(df, ref_cols=["bid_px0", "ask_px0"],
        ...     horizons=[timedelta(0), timedelta(seconds=60)],
        ...     id_cols=["seq", "data_date"])
    """
    if id_cols is None:
        id_cols = ["seq", "data_date"]

    records = []

    for ref_col in ref_cols:
        for h in horizons:
            suffix = horizon_suffix(h)
            col_name = f"{ref_col}_{suffix}"

            if col_name not in df.columns:
                continue

            # Build select expressions — id_cols kept with original names
            select_exprs = [
                pl.col(id_cols[0]),
            ]
            for extra_col in id_cols[1:]:
                if extra_col in df.columns:
                    select_exprs.append(pl.col(extra_col))

            select_exprs.extend([
                pl.lit(ref_col).alias("ref_col"),
                pl.lit(h).alias("horizon"),
                pl.col(col_name).alias("forward_value"),
            ])

            records.append(df.select(select_exprs))

    if not records:
        return pl.DataFrame()

    return pl.concat(records)


def pivot_horizons(
    df: pl.LazyFrame | pl.DataFrame,
    ref_cols: list[str],
    horizons: list[timedelta],
    *,
    horizon_col: str = "horizon",
) -> pl.DataFrame:
    """Pivot semi-wide table (horizons as rows) to wide format.

    Converts a table where each row is (trade, horizon) with ref_cols as columns
    into a table where each row is a trade with {ref_col}_{suffix} columns.

    Collects internally since pivot is inherently eager.

    Args:
        df: Semi-wide LazyFrame/DataFrame with horizon_col + ref_col columns.
            Non-ref, non-horizon columns are kept as-is (trade-level columns).
        ref_cols: Columns to pivot (e.g., ["bid_px0", "mid", "markout"]).
            Each becomes {col}_{suffix} in the output.
        horizons: Horizons as timedelta. Used for column naming via horizon_suffix().
        horizon_col: Column containing horizon Duration values (default: "horizon").

    Returns:
        Wide DataFrame with trade-level columns + {ref_col}_{suffix} columns.

    Example:
        >>> from datetime import timedelta
        >>> df_wide = vf.pivot_horizons(lf, ref_cols=["bid_px0", "mid"],
        ...     horizons=[timedelta(0), timedelta(seconds=60)])
    """
    if isinstance(df, pl.LazyFrame):
        df = df.collect()

    # Map Duration → suffix string via join (faster than map_elements)
    horizon_map = pl.DataFrame({
        horizon_col: horizons,
        "_horizon_suffix": [horizon_suffix(h) for h in horizons],
    })
    df = df.join(horizon_map, on=horizon_col, how="left")

    # Identify trade-level columns (everything except horizon_col, ref_cols, temp col)
    trade_cols = [c for c in df.columns
                  if c != horizon_col and c != "_horizon_suffix" and c not in ref_cols]

    # Pivot on suffix string
    df_wide = df.drop(horizon_col).pivot(
        on="_horizon_suffix",
        index=trade_cols,
        values=ref_cols,
    )

    # Rename columns: {ref_col}_{suffix} is already correct from pivot
    return df_wide
