"""
VizFlow Templates - Example scripts for common workflows.

Usage:
    import vizflow.templates as templates

    # List available templates
    templates.list_templates()

    # Copy a template to your project
    templates.copy_template("merge_forward_by_date.py", "my_enrich.py")
    templates.copy_template("explore_dashboard.py", "my_dashboard.py")

Available templates:
    - merge_forward_by_date.py:         Forward-merge one date (quote ref) → Delta Lake (--date arg)
    - enrich_alpha_by_date.py:          Alpha enrichment — merge forward quote prices to alpha ticks
    - daily_forward_stats_by_date.py:   Reduce enriched → daily weighted sums (--date arg)
    - explore_dashboard.py:             Read Delta Lake → Interactive Panel dashboard
    - alpha_heatmap.py:                 Alpha heatmap visualization
"""
from __future__ import annotations
from pathlib import Path
import shutil


TEMPLATES_DIR = Path(__file__).parent


def list_templates() -> list[str]:
    """List available template files."""
    return [f.name for f in TEMPLATES_DIR.glob("*.py") if f.name != "__init__.py"]


def get_template_path(name: str) -> Path:
    """Get the full path to a template file."""
    path = TEMPLATES_DIR / name
    if not path.exists():
        available = list_templates()
        raise FileNotFoundError(
            f"Template '{name}' not found. Available: {available}"
        )
    return path


def copy_template(name: str, dest: str | Path) -> Path:
    """Copy a template file to the destination path.

    Args:
        name: Template file name (e.g., "enrich_by_date.py")
        dest: Destination path (file path or directory)

    Returns:
        Path to the copied file
    """
    src = get_template_path(name)
    dest = Path(dest)

    if dest.is_dir():
        dest = dest / name

    shutil.copy2(src, dest)
    return dest
