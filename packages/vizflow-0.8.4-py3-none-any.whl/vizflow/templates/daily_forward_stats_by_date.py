#!/usr/bin/env python
"""Template: Compute daily forward stats for one date -> Delta Lake.

Pipeline:
  scan enriched base + forward (Delta Lake)
  inner join (fills only) → group_by → weighted sums
  write daily_forward_stats/ (Delta Lake, partition by [data_date, horizon])

This is the reduction stage after enrichment. It collapses trade × horizon
level data into daily aggregates (one row per horizon × order_price_type ×
order_side), storing sum of weights and sum of weighted values. Downstream
analysis (markout curves, interday cumsum) reads this tiny table directly.

Column naming convention:
  sum_{weight}              — e.g. sum_fill_notional
  sum_{weight}_x_{value}    — e.g. sum_fill_notional_x_sided_markout

To add a new metric: append to VALUES list, re-run with --force.
To add a new weight: append to WEIGHTS list, re-run with --force.

CLI (same interface as enrich_by_date_quote.py):
  python daily_forward_stats_by_date.py --date 20250112
  python daily_forward_stats_by_date.py --date 20250112 --force

Requires: pip install deltalake vizflow
"""
from __future__ import annotations

import argparse
from collections.abc import Sequence
from datetime import timedelta
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    from deltalake import DeltaTable, write_deltalake
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
ENRICHED_DIR = Path("./enriched")
OUTPUT_DIR   = Path("./enriched")

HORIZONS   = [timedelta(seconds=h) for h in [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]]
GROUP_KEYS = ["horizon", "order_price_type", "order_side"]
WEIGHTS    = ["fill_notional"]
VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]


# ═══════════════════════════════════════════════════════════════
# DELTA LAKE HELPERS
# ═══════════════════════════════════════════════════════════════
def _missing_horizons(
    table_path: str,
    date_iso: str,
    horizons: Sequence[timedelta],
) -> list[timedelta]:
    """Return horizons not yet written for this date (metadata-only)."""
    try:
        dt = DeltaTable(table_path)
    except Exception:
        return list(horizons)
    parts = dt.partitions()
    existing = {p["horizon"] for p in parts if p["data_date"] == date_iso}
    return [h for h in horizons if vf.horizon_suffix(h) not in existing]


def _write_delta(
    df: pl.DataFrame,
    table_path: str,
    partition_by: list[str],
    predicate: str,
) -> None:
    """Write DataFrame to Delta Lake with partition-level overwrite."""
    df = vf.cast_for_delta(df)
    if not DeltaTable.is_deltatable(table_path):
        write_deltalake(table_path, df.to_arrow(), partition_by=partition_by, mode="error")
    else:
        write_deltalake(table_path, df.to_arrow(), mode="overwrite", predicate=predicate)


# ═══════════════════════════════════════════════════════════════
# CORE
# ═══════════════════════════════════════════════════════════════
def compute_daily_forward_stats(date: str, horizons: Sequence[timedelta]) -> pl.DataFrame:
    """Reduce enriched trade × horizon data to daily weighted sums.

    Args:
        date: Date string in YYYYMMDD format.
        horizons: Horizons as timedelta. May be a subset of HORIZONS
            when only missing horizons need to be filled in.

    Returns:
        DataFrame with one row per (horizon, order_price_type, order_side).
    """
    date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"
    date_filter = pl.col("data_date") == pl.lit(date_iso).str.to_date()

    # Filter forward table to requested horizons
    horizon_filter = pl.col("horizon").is_in(list(horizons))

    lf_base = vf.restore_from_delta(pl.scan_delta(str(ENRICHED_DIR / "base"))).filter(date_filter)
    lf_fwd  = vf.restore_from_delta(pl.scan_delta(str(ENRICHED_DIR / "forward"))).filter(date_filter).filter(horizon_filter)

    return (
        lf_fwd.join(
            lf_base
            .filter(pl.col("fill_qty") > 0)
            .with_columns(fill_notional=pl.col("fill_price") * pl.col("fill_qty"))
            .select("seq", "data_date", "fill_notional", "order_price_type", "order_side"),
            on=["seq", "data_date"],
        )
        .group_by(GROUP_KEYS)
        .agg(
            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
            + [
                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                for w in WEIGHTS
                for v in VALUES
            ]
        )
        .with_columns(data_date=pl.lit(date_iso).str.to_date())
        .collect()
    )


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    parser.add_argument("--force", action="store_true",
                        help="Force reprocess even if date is complete")
    args = parser.parse_args()

    date_iso = f"{args.date[:4]}-{args.date[4:6]}-{args.date[6:8]}"
    table_path = str(OUTPUT_DIR / "daily_forward_stats")

    # Determine which horizons need processing
    if args.force:
        missing = list(HORIZONS)
    else:
        missing = _missing_horizons(table_path, date_iso, HORIZONS)

    if not missing:
        print(f"  skip {args.date} (complete)")
        return

    print(f"Processing {args.date}... ({len(missing)}/{len(HORIZONS)} horizons)")
    df = compute_daily_forward_stats(args.date, horizons=missing)
    print(f"  {len(df)} rows, columns: {df.columns}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Per-horizon write (same pattern as enrich_by_date_quote.py)
    if len(df) > 0:
        for h in missing:
            suffix = vf.horizon_suffix(h)
            df_h = df.filter(pl.col("horizon") == h)
            if len(df_h) == 0:
                continue
            predicate = f"data_date = '{date_iso}' AND horizon = '{suffix}'"
            _write_delta(df_h, table_path, ["data_date", "horizon"], predicate)

    print(f"  Saved to {table_path}")


if __name__ == "__main__":
    main()