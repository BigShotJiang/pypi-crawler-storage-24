#!/usr/bin/env python
"""Template: Alpha enrichment — merge forward quote prices to each alpha tick.

Pipeline (fully lazy until final collect):
  scan_alpha -> parse_time                              (lazy, event side)
  scan_quote -> parse_time                              (lazy, ref side)
  per-horizon: merge_forward(event, quote, horizon)     (lazy, CACHE shared)
  pivot_horizons → wide format                          (collect)
  write wide-format Delta Lake

Uses tick-by-tick quote data as the reference source (not alpha self-join).

Output: enriched_alpha/ (Delta Lake, wide format)
  Columns: ukey, data_date, x_10s, x_60s, x_3m, x_30m,
           bid_px0_0s, ask_px0_0s, bid_px0_10s, ..., ask_px0_5m
"""
from __future__ import annotations

import argparse
from datetime import timedelta
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    import deltalake  # noqa: F401
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
ALPHA_DIR = Path("/gpfs/.../jyao/alpha")
ALPHA_PATTERN = "alpha_{date}.feather"
ALPHA_SCHEMA = "jyao_v20251114"

QUOTE_DIR = Path("/gpfs/.../stock_sorted_t5ob")
QUOTE_PATTERN = "{date}.fst"
QUOTE_SCHEMA = "stock_sorted_t5ob"

OUTPUT_DIR = Path("./enriched_alpha")
MARKET = "CN"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG
# ═══════════════════════════════════════════════════════════════
HORIZONS = [timedelta(seconds=h) for h in [0, 10, 30, 60, 120, 180, 300]]
REF_COLS = ["bid_px0", "ask_px0"]
ALPHA_PRED_COLS = ["x_10s", "x_60s", "x_3m", "x_30m"]

ALPHA_TIME_COL = "ticktime"
QUOTE_TIME_COL = "ticktime"

EVENT_COLS = ["ukey", "data_date", ALPHA_TIME_COL] + ALPHA_PRED_COLS


# ═══════════════════════════════════════════════════════════════
# PROCESS ONE DATE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str) -> pl.DataFrame:
    """Process one date: merge forward quote prices to each alpha tick.

    Returns:
        Wide-format DataFrame with event cols + {ref_col}_{suffix} cols.
    """
    elapsed_alpha = f"elapsed_{ALPHA_TIME_COL}"
    elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

    # Alpha: select prediction + id columns only (avoid bid/ask name collision)
    lf_alpha = (
        vf.scan_alpha(date)
        .pipe(vf.parse_time, ALPHA_TIME_COL)
        .select(EVENT_COLS + [elapsed_alpha])
    )

    # Quote: tick-by-tick ref source
    lf_quote = (
        vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + REF_COLS)
        .pipe(vf.parse_time, QUOTE_TIME_COL)
    )

    # Per-horizon lazy merge → wide format (each horizon adds {col}_{suffix})
    partials = []
    for h in HORIZONS:
        lf_h = vf.merge_forward(
            lf_alpha, lf_quote,
            ref_cols=REF_COLS,
            horizon=h,
            trade_time_col=elapsed_alpha,
            ref_time_col=elapsed_quote,
        )
        partials.append(lf_h)

    # Collect first partial (has all alpha cols + first horizon's forward cols)
    df = partials[0].collect()
    # Hstack remaining horizons' forward columns
    for lf_h in partials[1:]:
        df_h = lf_h.collect()
        new_cols = [c for c in df_h.columns if c not in df.columns]
        if new_cols:
            df = df.hstack(df_h.select(new_cols))

    return df


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    args = parser.parse_args()

    config = vf.Config(
        alpha_dir=ALPHA_DIR,
        alpha_pattern=ALPHA_PATTERN,
        alpha_schema=ALPHA_SCHEMA,
        quote_dir=QUOTE_DIR,
        quote_pattern=QUOTE_PATTERN,
        quote_schema=QUOTE_SCHEMA,
        market=MARKET,
    )
    vf.set_config(config)

    print(f"Processing {args.date}...")
    df = process_date(args.date)
    print(f"  {len(df)} events, {len(df.columns)} columns")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    vf.cast_for_delta(df).write_delta(
        str(OUTPUT_DIR),
        mode="append",
        delta_write_options={"partition_by": ["data_date"]},
    )

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
