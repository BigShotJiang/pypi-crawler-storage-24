#!/usr/bin/env python
"""Template: Binned heatmap of alpha predictions vs actual markout.

Reads enriched alpha Delta Lake (wide format from enrich_alpha_by_date.py),
computes mid and markout from bid_px0/ask_px0 forward columns,
bins predictions (x_60s, x_3m) into quantile bins, and plots
average markout at each horizon as a 2D heatmap.

To use:
  1. Copy: vf.templates.copy_template("alpha_heatmap.py", "my_heatmap.py")
  2. Edit CONFIG section
  3. Run: python my_heatmap.py
"""
from __future__ import annotations

from datetime import timedelta
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import polars as pl
import vizflow as vf


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your analysis
# ═══════════════════════════════════════════════════════════════
INPUT_DIR = Path("./enriched_alpha")

# Binning axes
X_COL = "x_60s"
Y_COL = "x_3m"
N_BINS = 20  # quantile bins per axis

# Horizons to plot (must match enrich_alpha_by_date.py, excluding 0)
HORIZONS = [timedelta(seconds=h) for h in [10, 30, 60, 120, 180, 300]]

# Output
OUTPUT_PATH = Path("alpha_markout_heatmap.png")
COLORMAP = "RdBu_r"


# ═══════════════════════════════════════════════════════════════
# DERIVED COLUMNS (computed lazily from wide format)
# ═══════════════════════════════════════════════════════════════
def _add_markout_columns(lf: pl.LazyFrame) -> pl.LazyFrame:
    """Compute mid and markout from bid_px0/ask_px0 forward columns.

    mid_{s} = (bid_px0_{s} + ask_px0_{s}) / 2
    markout_{s} = mid_{s} / mid_0s - 1  (for h > 0)
    """
    # Mid at each horizon (including 0)
    all_horizons = [timedelta(0)] + HORIZONS
    mid_exprs = []
    for h in all_horizons:
        s = vf.horizon_suffix(h)
        mid_exprs.append(
            ((pl.col(f"bid_px0_{s}") + pl.col(f"ask_px0_{s}")) / 2).alias(f"mid_{s}")
        )
    lf = lf.with_columns(mid_exprs)

    # Markout at each non-zero horizon
    markout_exprs = []
    for h in HORIZONS:
        s = vf.horizon_suffix(h)
        markout_exprs.append(
            (pl.col(f"mid_{s}") / pl.col("mid_0s") - 1).alias(f"markout_{s}")
        )
    lf = lf.with_columns(markout_exprs)

    return lf


# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    # Load enriched data from Delta Lake
    print(f"Loading from {INPUT_DIR}...")
    df = (
        vf.restore_from_delta(pl.scan_delta(str(INPUT_DIR)))
        .pipe(_add_markout_columns)
        .collect()
    )
    print(f"  {len(df):,} rows, {len(df.columns)} columns")

    # Convert to numpy for binning
    x_vals = df[X_COL].to_numpy()
    y_vals = df[Y_COL].to_numpy()

    # Drop NaN rows
    valid = ~(np.isnan(x_vals) | np.isnan(y_vals))
    x_vals = x_vals[valid]
    y_vals = y_vals[valid]

    # Quantile bin edges
    x_edges = np.unique(np.quantile(x_vals, np.linspace(0, 1, N_BINS + 1)))
    y_edges = np.unique(np.quantile(y_vals, np.linspace(0, 1, N_BINS + 1)))
    nx, ny = len(x_edges) - 1, len(y_edges) - 1

    # Bin indices (clip to valid range)
    x_idx = np.clip(np.digitize(x_vals, x_edges[1:-1]), 0, nx - 1)
    y_idx = np.clip(np.digitize(y_vals, y_edges[1:-1]), 0, ny - 1)

    # Plot grid: one heatmap per horizon
    n_horizons = len(HORIZONS)
    ncols = min(3, n_horizons)
    nrows = (n_horizons + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(7 * ncols, 6 * nrows))
    if n_horizons == 1:
        axes = np.array([axes])
    axes = np.array(axes).flat

    for ax, h in zip(axes, HORIZONS):
        s = vf.horizon_suffix(h)
        markout_col = f"markout_{s}"

        z_vals = df[markout_col].to_numpy()[valid]

        # Compute mean markout per bin
        grid = np.full((nx, ny), np.nan)
        for xi in range(nx):
            for yi in range(ny):
                mask = (x_idx == xi) & (y_idx == yi)
                if mask.sum() > 0:
                    grid[xi, yi] = np.nanmean(z_vals[mask])

        # Symmetric color limits
        vmax = np.nanmax(np.abs(grid)) if not np.all(np.isnan(grid)) else 0.001
        vmin = -vmax

        # X-axis = Y_COL bins (columns), Y-axis = X_COL bins (rows)
        im = ax.pcolormesh(
            y_edges, x_edges, grid,
            cmap=COLORMAP, vmin=vmin, vmax=vmax,
        )
        fig.colorbar(im, ax=ax, label="avg markout")

        ax.set_xlabel(Y_COL)
        ax.set_ylabel(X_COL)
        ax.set_title(f"Avg Markout @ {s}")

    # Hide unused axes
    for ax in list(axes)[n_horizons:]:
        ax.set_visible(False)

    fig.suptitle(f"Alpha Signal Quality: {X_COL} x {Y_COL} -> markout", fontsize=14)
    fig.tight_layout()
    fig.savefig(OUTPUT_PATH, dpi=150, bbox_inches="tight")
    print(f"Saved: {OUTPUT_PATH}")
    plt.show()


if __name__ == "__main__":
    main()
