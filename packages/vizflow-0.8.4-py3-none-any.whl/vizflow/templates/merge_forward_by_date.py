#!/usr/bin/env python
"""Template: Forward-merge one date (quote ref) -> Delta Lake.

Pipeline (fully lazy until final collect):
  scan_trade -> parse_time                            (lazy)
  scan_quote -> parse_time                            (lazy)
  per-horizon: merge_forward(trade, quote, horizon)   (lazy, CACHE shared)
  pl.concat(partials).collect()                       (single collect)
  base/forward split -> Delta Lake

Uses tick-by-tick quote data as the reference source for merge_forward.
Each horizon is a separate lazy merge_forward call; Polars' optimizer
shares scan + sort via CACHE nodes across horizons.

Forward table format: semi-wide (one row per trade × horizon).
  Each ref_col is a separate column with its native type (no melt).
  Partition: [data_date, horizon]

Delta Lake write strategy:
  - Partition-level overwrite via predicate (concurrent-safe, idempotent)
  - Incremental: auto-detects missing horizons, only computes what's needed
  - Use --force to reprocess even if complete

To use this template:
  1. Copy: vf.templates.copy_template("merge_forward_by_date.py", "my_enrich.py")
  2. Edit CONFIG section with your data paths
  3. Edit FORWARD MERGE CONFIG with your horizons and ref_cols
  4. Run: python my_enrich.py --date 20240827

Adding new horizons: append to HORIZONS list, re-run — only new horizons
are computed. Adding new ref_cols: append to REF_COLS list, re-run with
--force (schema change requires full reprocess for affected dates).

Output: enriched/base/ and enriched/forward/ (Delta Lake)

Requires: pip install deltalake vizflow[fst]
"""
from __future__ import annotations

import argparse
from collections.abc import Sequence
from datetime import timedelta
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    from deltalake import DeltaTable, write_deltalake
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
TRADE_DIR = Path("/cpfs/user2/ylu/projects/.../data/ordlog13/sc_8")
TRADE_PATTERN = "{date}_orders.feather"
TRADE_SCHEMA = "eric_v20260205"

QUOTE_DIR = Path("/gpfs/.../stock_sorted_t5ob")
QUOTE_PATTERN = "{date}.fst"
QUOTE_SCHEMA = "stock_sorted_t5ob"

OUTPUT_DIR = Path("./enriched")
MARKET = "CN"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG — edit for your analysis
# ═══════════════════════════════════════════════════════════════
HORIZONS = [timedelta(seconds=h) for h in [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]]
RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]

TRADE_TIME_COL = "update_exchange_ts"
CREATE_TIME_COL = "create_exchange_ts"
QUOTE_TIME_COL = "ticktime"


# ═══════════════════════════════════════════════════════════════
# DELTA LAKE HELPERS
# ═══════════════════════════════════════════════════════════════
def _missing_horizons(
    forward_path: str,
    date_iso: str,
    horizons: Sequence[timedelta],
) -> list[timedelta]:
    """Return horizons not yet written for this date (metadata-only)."""
    try:
        dt = DeltaTable(forward_path)
    except Exception:
        return list(horizons)
    parts = dt.partitions()
    existing = {p["horizon"] for p in parts if p["data_date"] == date_iso}
    return [h for h in horizons if vf.horizon_suffix(h) not in existing]


def _write_delta(
    df: pl.DataFrame,
    table_path: str,
    partition_by: list[str],
    predicate: str,
) -> None:
    """Write DataFrame to Delta Lake with partition-level overwrite."""
    df = vf.cast_for_delta(df)
    if not DeltaTable.is_deltatable(table_path):
        write_deltalake(table_path, df.to_arrow(), partition_by=partition_by, mode="error")
    else:
        write_deltalake(table_path, df.to_arrow(), mode="overwrite", predicate=predicate)


# ═══════════════════════════════════════════════════════════════
# PROCESS ONE DATE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str, horizons: Sequence[timedelta]) -> tuple[pl.DataFrame, pl.DataFrame]:
    """Process one date: merge forward quote prices to each trade fill.

    Args:
        date: Date string in YYYYMMDD format.
        horizons: Horizons (seconds) to compute. May be a subset of HORIZONS
            when only missing horizons need to be filled in.

    Returns:
        (df_base, df_forward) tuple
    """
    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

    elapsed_create = f"elapsed_{CREATE_TIME_COL}"

    # Load trade (lazy) — all events, sorted for cum_sum correctness
    lf_trade = (
        vf.scan_trade(date)
        .pipe(vf.parse_time, TRADE_TIME_COL)
        .pipe(vf.parse_time, CREATE_TIME_COL)
        .sort(["ukey", elapsed_trade])
        .with_columns(
            pl.col("fill_qty").cum_sum().over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
        )
        .with_columns(
            (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
            (pl.col(elapsed_trade) - pl.col(elapsed_create)).alias("duration"),
        )
    )

    # Load quote (lazy) — t5ob schema: prices auto-scaled /10000
    lf_quote = (
        vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + RAW_REF_COLS)
        .pipe(vf.parse_time, QUOTE_TIME_COL)
    )

    # Forward merge: per-horizon lazy, CACHE shares scan+sort across horizons
    partials = []
    for h in horizons:
        lf_h = vf.merge_forward(
            lf_trade, lf_quote,
            ref_cols=RAW_REF_COLS,
            horizon=h,
            trade_time_col=elapsed_trade,
            ref_time_col=elapsed_quote,
        )
        # Un-rename {col}_{suffix} → {col}, add horizon column
        suffix = vf.horizon_suffix(h)
        rename_map = {f"{rc}_{suffix}": rc for rc in RAW_REF_COLS}
        lf_h = lf_h.rename(rename_map).with_columns(pl.lit(h).alias("horizon"))
        partials.append(lf_h)

    # Single collect — Polars optimizer merges shared subplans via CACHE
    df_all = pl.concat(partials).collect()

    # Base table: trade-level columns (from any single horizon, drop ref+horizon cols)
    base_cols = [c for c in df_all.columns if c not in RAW_REF_COLS and c != "horizon"]
    df_base = df_all.filter(pl.col("horizon") == horizons[0]).select(base_cols)

    # Forward table: already semi-wide (one row per trade × horizon)
    id_cols = ["seq", "data_date"]
    df_forward = df_all.select(id_cols + RAW_REF_COLS + ["horizon"])

    # ───────────────────────────────────────────────────────────
    # DERIVED COLUMNS on forward table
    # ───────────────────────────────────────────────────────────
    # Join with base cols needed for derivation
    df_fwd = df_forward.join(
        df_base.select(["seq", "data_date", "fill_price", "order_side"]),
        on=["seq", "data_date"],
    )
    is_buy = pl.col("order_side") == "Buy"

    # Phase 1: mid, spread, touch
    df_fwd = df_fwd.with_columns([
        ((pl.col("bid_px0") + pl.col("ask_px0")) / 2).alias("mid"),
        (pl.col("ask_px0") - pl.col("bid_px0")).alias("spread"),
        pl.when(is_buy).then(pl.col("ask_px0")).otherwise(pl.col("bid_px0")).alias("near_touch_px"),
        pl.when(is_buy).then(pl.col("bid_px0")).otherwise(pl.col("ask_px0")).alias("far_touch_px"),
        pl.when(is_buy).then(pl.col("ask_size0")).otherwise(pl.col("bid_size0")).alias("near_touch_size"),
        pl.when(is_buy).then(pl.col("bid_size0")).otherwise(pl.col("ask_size0")).alias("far_touch_size"),
    ])
    df_fwd = df_fwd.with_columns(
        (pl.col("spread") / pl.col("mid") * 10000).alias("spread_bps"),
    )

    # Phase 2: markout, fill_to_near_touch
    df_fwd = df_fwd.with_columns([
        (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
        (pl.col("near_touch_px") / pl.col("fill_price") - 1).alias("fill_to_near_touch"),
    ])

    # Phase 3: return (cross-horizon, needs mid_0)
    mid_0 = (
        df_fwd.filter(pl.col("horizon") == timedelta(0))
        .select(["seq", "data_date", pl.col("mid").alias("mid_0")])
    )
    df_fwd = df_fwd.join(mid_0, on=["seq", "data_date"])
    df_fwd = df_fwd.with_columns(
        ((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")
    ).drop("mid_0")

    # Phase 4: sided (creates sided_return, sided_markout, sided_fill_to_near_touch)
    sided_cols = ["return", "markout", "fill_to_near_touch"]
    df_fwd = df_fwd.with_columns([
        pl.when(pl.col("order_side") == "Sell").then(-pl.col(c)).otherwise(pl.col(c)).alias(f"sided_{c}")
        for c in sided_cols
    ])

    # Drop temp join cols
    df_fwd = df_fwd.drop(["fill_price", "order_side"])

    return df_base, df_fwd


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    parser.add_argument("--force", action="store_true",
                        help="Force reprocess even if date is complete")
    args = parser.parse_args()

    vf.set_config(vf.Config(
        trade_dir=TRADE_DIR,
        trade_pattern=TRADE_PATTERN,
        trade_schema=TRADE_SCHEMA,
        quote_dir=QUOTE_DIR,
        quote_pattern=QUOTE_PATTERN,
        quote_schema=QUOTE_SCHEMA,
        market=MARKET,
    ))

    # YYYYMMDD -> YYYY-MM-DD (Delta Lake partition format for pl.Date)
    date_iso = f"{args.date[:4]}-{args.date[4:6]}-{args.date[6:8]}"
    base_path = str(OUTPUT_DIR / "base")
    forward_path = str(OUTPUT_DIR / "forward")

    # Determine which horizons need processing
    if args.force:
        missing = list(HORIZONS)
    else:
        missing = _missing_horizons(forward_path, date_iso, HORIZONS)

    if not missing:
        print(f"  skip {args.date} (complete)")
        return

    print(f"Processing {args.date}... ({len(missing)}/{len(HORIZONS)} horizons)")
    df_base, df_forward = process_date(args.date, horizons=missing)
    print(f"  {len(df_base)} fills, {len(df_base.columns)} base columns")
    print(f"  {len(df_forward)} forward rows ({len(missing)} horizons × {len(df_base)} trades)")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Base: idempotent overwrite for this date
    base_predicate = f"data_date = '{date_iso}'"
    _write_delta(df_base, base_path, ["data_date"], base_predicate)

    # Forward: per-horizon write (safe for incremental append)
    if len(df_forward) > 0:
        for h in missing:
            suffix = vf.horizon_suffix(h)
            df_h = df_forward.filter(pl.col("horizon") == h)
            predicate = f"data_date = '{date_iso}' AND horizon = '{suffix}'"
            _write_delta(df_h, forward_path, ["data_date", "horizon"], predicate)

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
