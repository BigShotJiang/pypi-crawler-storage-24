# pyannotators_spacymatcher

[![license](https://img.shields.io/github/license/oterrier/pyannotators_spacymatcher)](https://github.com/oterrier/pyannotators_spacymatcher/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyannotators_spacymatcher/workflows/tests/badge.svg)](https://github.com/oterrier/pyannotators_spacymatcher/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyannotators_spacymatcher)](https://codecov.io/gh/oterrier/pyannotators_spacymatcher)
[![docs](https://img.shields.io/readthedocs/pyannotators_spacymatcher)](https://pyannotators_spacymatcher.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyannotators_spacymatcher)](https://pypi.org/project/pyannotators_spacymatcher/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyannotators_spacymatcher)](https://pypi.org/project/pyannotators_spacymatcher/)

Annotator based on SpacyMatcher using the spacy rule-matching engine

## Installation

You can simply `pip install pyannotators_spacymatcher`.

## Developing

### Pre-requisites

You will need to install `uv` (for building and managing the package):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyannotators_spacymatcher
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.
