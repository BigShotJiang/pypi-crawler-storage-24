import base64
import mimetypes
import urllib.request

from PyQt6.QtCore import Qt, QUrl
from PyQt6.QtGui import QColor, QPixmap, QDesktopServices
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QSpinBox,
    QDoubleSpinBox,
    QListWidget,
    QListWidgetItem,
    QCheckBox,
    QGroupBox,
    QPushButton,
    QComboBox,
    QFormLayout,
    QMessageBox,
    QColorDialog,
    QToolButton,
    QFrame,
    QAbstractItemView, QLineEdit,
    QDialog,
    QFileDialog,
    QScrollArea,
    QInputDialog,
)
from typing import Dict, List, Optional, Tuple

from weegit import settings
from weegit.gui.dialogs.header_units_management_dialog import HeaderUnitsManagementDialog
from weegit.gui._utils import milliseconds_to_readable
from weegit.gui.qt_weegit_session_manager_wrapper import QtWeegitSessionManagerWrapper
from weegit.core.conversions.filters import (
    ensure_filters_list,
    ButterworthLowPassFilter,
    ButterworthHighPassFilter,
    ButterworthBandPassFilter,
    ChebyshevBandPassFilter,
    NotchFilter,
)


class ChannelReorderDialog(QDialog):
    def __init__(self, channels: List[int], channel_name_getter, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Reorder channels")
        self.resize(480, 520)
        self._channel_name_getter = channel_name_getter

        layout = QVBoxLayout(self)
        info = QLabel("Drag&drop, arrows, or input format: 1,10,12,14-18,20")
        info.setWordWrap(True)
        layout.addWidget(info)

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.list_widget.setDragDropMode(QListWidget.DragDropMode.InternalMove)
        self.list_widget.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.list_widget.setDragEnabled(True)
        self.list_widget.setAcceptDrops(True)
        layout.addWidget(self.list_widget, 1)

        arrows = QHBoxLayout()
        self.up_btn = QPushButton("↑")
        self.down_btn = QPushButton("↓")
        arrows.addWidget(self.up_btn)
        arrows.addWidget(self.down_btn)
        arrows.addStretch(1)
        layout.addLayout(arrows)

        manual_row = QHBoxLayout()
        manual_row.addWidget(QLabel("Manual order:"))
        self.manual_edit = QLineEdit()
        self.apply_manual_btn = QPushButton("Apply")
        manual_row.addWidget(self.manual_edit, 1)
        manual_row.addWidget(self.apply_manual_btn)
        layout.addLayout(manual_row)

        actions = QHBoxLayout()
        actions.addStretch(1)
        self.cancel_btn = QPushButton("Cancel")
        self.ok_btn = QPushButton("Reorder")
        actions.addWidget(self.cancel_btn)
        actions.addWidget(self.ok_btn)
        layout.addLayout(actions)

        self._set_order(channels)
        self.up_btn.clicked.connect(lambda: self._move_selected(-1))
        self.down_btn.clicked.connect(lambda: self._move_selected(1))
        self.apply_manual_btn.clicked.connect(self._apply_manual)
        self.cancel_btn.clicked.connect(self.reject)
        self.ok_btn.clicked.connect(self.accept)

    def _set_order(self, channels: List[int]):
        self.list_widget.clear()
        for ch in channels:
            label = self._channel_name_getter(ch)
            item = QListWidgetItem(f"{ch} [{label}]")
            item.setData(Qt.ItemDataRole.UserRole, ch)
            self.list_widget.addItem(item)

    def _current_order(self) -> List[int]:
        result: List[int] = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            result.append(int(item.data(Qt.ItemDataRole.UserRole)))
        return result

    def _move_selected(self, delta: int):
        row = self.list_widget.currentRow()
        if row < 0:
            return
        new_row = row + delta
        if new_row < 0 or new_row >= self.list_widget.count():
            return
        item = self.list_widget.takeItem(row)
        self.list_widget.insertItem(new_row, item)
        self.list_widget.setCurrentRow(new_row)

    def _apply_manual(self):
        text = self.manual_edit.text().strip()
        if not text:
            return
        current = self._current_order()
        allowed = set(current)
        parsed: List[int] = []
        try:
            for token in text.split(","):
                token = token.strip()
                if not token:
                    continue
                if "-" in token:
                    start_s, end_s = token.split("-", 1)
                    start = int(start_s.strip())
                    end = int(end_s.strip())
                    step = 1 if end >= start else -1
                    for v in range(start, end + step, step):
                        parsed.append(v)
                else:
                    parsed.append(int(token))
        except Exception:
            QMessageBox.warning(self, "Reorder", "Failed to parse manual order.")
            return

        if set(parsed) != allowed or len(parsed) != len(current):
            QMessageBox.warning(self, "Reorder", "Manual order must contain all channels exactly once.")
            return
        self._set_order(parsed)

    def get_order(self) -> List[int]:
        return self._current_order()


class ClickableImageLabel(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._original_pixmap: Optional[QPixmap] = None

    def set_pixmap(self, pixmap: Optional[QPixmap], display_pixmap: Optional[QPixmap] = None):
        self._original_pixmap = pixmap
        if pixmap is None:
            self.clear()
            return
        self.setPixmap(display_pixmap or pixmap)

    def mouseDoubleClickEvent(self, event):
        if self._original_pixmap is None:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Channels mapping image")
        layout = QVBoxLayout(dialog)
        scroll = QScrollArea()
        label = QLabel()
        label.setPixmap(self._original_pixmap)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        scroll.setWidget(label)
        scroll.setWidgetResizable(True)
        layout.addWidget(scroll)
        dialog.resize(800, 600)
        dialog.exec()


class SignalSettingsPanel(QWidget):
    def __init__(self, session_manager: QtWeegitSessionManagerWrapper, parent=None):
        super().__init__(parent)
        self._session_manager = session_manager
        self._updating = False
        self._group_list_widgets: Dict[int, QListWidget] = {}
        self._group_enabled_checkboxes: Dict[Tuple[int, int], QCheckBox] = {}
        self._last_groups_structure_signature: Tuple = tuple()
        self._rebuilding_groups = False
        self._mapping_pixmap: Optional[QPixmap] = None
        self._mapping_text: str = ""
        self._mapping_link_url: str = ""
        self.setup_ui()
        self.connect_signals()

    def _add_collapsible_section(self, parent_layout: QVBoxLayout, title: str):
        header_btn = QToolButton()
        header_btn.setText(title)
        header_btn.setCheckable(True)
        header_btn.setChecked(True)
        header_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        header_btn.setArrowType(Qt.ArrowType.DownArrow)
        header_btn.setStyleSheet("QToolButton { font-weight: bold; border: none; text-align: left; }")

        content = QFrame()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(8, 4, 0, 4)
        content_layout.setSpacing(8)

        def on_toggle(checked: bool):
            content.setVisible(checked)
            header_btn.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)

        header_btn.toggled.connect(on_toggle)
        parent_layout.addWidget(header_btn)
        parent_layout.addWidget(content)
        return content_layout

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(8)

        time_layout = self._add_collapsible_section(layout, "Time Settings")
        self.start_point_spinbox = QSpinBox()
        self.start_point_spinbox.setRange(0, settings.MAX_START_POINT)
        self.start_point_spinbox.setSingleStep(1000)
        self.current_sweep_spinbox = QSpinBox()
        self.current_sweep_spinbox.setRange(1, 1)
        self.current_sweep_spinbox.setSingleStep(1)
        self.current_sweep_spinbox.setSuffix(" sweep")
        self.duration_spinbox = QSpinBox()
        self.duration_spinbox.setRange(settings.MIN_DURATION, settings.MAX_DURATION)
        self.duration_spinbox.setSingleStep(100)
        self.time_step_spinbox = QSpinBox()
        self.time_step_spinbox.setRange(settings.MIN_TIME_STEP, settings.MAX_TIME_STEP)
        self.time_step_spinbox.setSingleStep(100)
        self.autoscroll_step_interval_spinbox = QSpinBox()
        self.autoscroll_step_interval_spinbox.setRange(10, settings.MAX_TIME_STEP)
        self.autoscroll_step_interval_spinbox.setSingleStep(50)
        self.number_of_dots_spinbox = QSpinBox()
        self.number_of_dots_spinbox.setRange(
            settings.MIN_NUMBER_OF_DOTS_TO_DISPLAY,
            settings.MAX_NUMBER_OF_DOTS_TO_DISPLAY,
        )
        self.number_of_dots_spinbox.setSingleStep(100)
        self.duration_label = QLabel("Duration (ms):")
        self.time_step_label = QLabel("Time step (ms):")
        self.number_of_dots_label = QLabel("Number of dots:")
        rows = [
            ("Current sweep:", self.current_sweep_spinbox),
            ("Start point index:", self.start_point_spinbox),
            (self.duration_label, self.duration_spinbox),
            (self.time_step_label, self.time_step_spinbox),
            ("Auto-scroll interval (ms):", self.autoscroll_step_interval_spinbox),
            (self.number_of_dots_label, self.number_of_dots_spinbox),
        ]
        for label, widget in rows:
            row = QHBoxLayout()
            row.addWidget(QLabel(label) if isinstance(label, str) else label)
            row.addWidget(widget)
            row.addStretch(1)
            time_layout.addLayout(row)

        self.channels_layout = self._add_collapsible_section(layout, "Channel Management")

        mapping_group = QGroupBox("Channels mapping image")
        mapping_layout = QVBoxLayout(mapping_group)
        buttons_layout = QHBoxLayout()
        self.btn_attach_link = QPushButton("Attach link")
        self.btn_attach_file = QPushButton("Attach file")
        buttons_layout.addWidget(self.btn_attach_link)
        buttons_layout.addWidget(self.btn_attach_file)
        buttons_layout.addStretch(1)
        mapping_layout.addLayout(buttons_layout)

        self.mapping_text_label = QLabel("")
        self.mapping_text_label.setWordWrap(True)
        self.mapping_text_label.setTextFormat(Qt.TextFormat.RichText)
        self.mapping_text_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        self.mapping_text_label.setOpenExternalLinks(False)
        mapping_layout.addWidget(self.mapping_text_label)

        self.mapping_image_label = ClickableImageLabel()
        self.mapping_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.mapping_image_label.setMinimumWidth(settings.CHANNELS_MAPPING_IMG_DEFAULT_WIDTH)
        mapping_layout.addWidget(self.mapping_image_label)
        self.channels_layout.addWidget(mapping_group)

        instructions = QLabel(
            "Use Reorder to change order (drag&drop, arrows, manual format). "
            "Select multiple channels, then Move selected to target group."
        )
        instructions.setWordWrap(True)
        instructions.setStyleSheet("color: gray; font-size: 9pt;")
        self.channels_layout.addWidget(instructions)
        btn_controls_row = QHBoxLayout()
        self.create_group_btn = QPushButton("Create channel group")
        self.set_units_btn = QPushButton("Set units")
        btn_controls_row.addWidget(self.create_group_btn)
        btn_controls_row.addWidget(self.set_units_btn)
        self.channels_layout.addLayout(btn_controls_row)
        layout.addStretch(1)

    def connect_signals(self):
        self.current_sweep_spinbox.valueChanged.connect(lambda value: self._session_manager.set_current_sweep_idx(value - 1))
        self.start_point_spinbox.valueChanged.connect(self._session_manager.set_start_point)
        self.duration_spinbox.valueChanged.connect(self._session_manager.set_duration_ms)
        self.time_step_spinbox.valueChanged.connect(self._session_manager.set_time_step_ms)
        self.autoscroll_step_interval_spinbox.valueChanged.connect(self._session_manager.set_autoscroll_step_interval_ms)
        self.number_of_dots_spinbox.valueChanged.connect(self._session_manager.set_number_of_dots_to_display)
        self.create_group_btn.clicked.connect(lambda: self._session_manager.add_channel_group("Group"))
        self.set_units_btn.clicked.connect(self.on_set_units_clicked)
        self.btn_attach_link.clicked.connect(self.on_attach_link_clicked)
        self.btn_attach_file.clicked.connect(self.on_attach_file_clicked)
        self.mapping_text_label.linkActivated.connect(self.on_mapping_link_activated)

        self._session_manager.session_loaded.connect(self.on_session_loaded)
        self._session_manager.channels_groups_changed.connect(self._on_channels_groups_changed)
        self._session_manager.start_point_changed.connect(self._sync_time_controls)
        self._session_manager.duration_ms_changed.connect(self._sync_time_controls)
        self._session_manager.current_sweep_idx_changed.connect(self._sync_time_controls)
        self._session_manager.time_step_ms_changed.connect(self._sync_time_controls)
        self._session_manager.autoscroll_step_interval_ms_changed.connect(self._sync_time_controls)
        self._session_manager.number_of_dots_to_display_changed.connect(self._sync_time_controls)
        self._session_manager.filters_changed.connect(self.on_filters_changed)
        self._session_manager.channels_mapping_img_changed.connect(self.on_channels_mapping_img_changed)
        self._session_manager.header_units_changed.connect(lambda _units: self.rebuild_groups_ui())

    def on_session_loaded(self):
        self._sync_time_controls()
        gui_setup = self._session_manager.gui_setup
        if not gui_setup:
            return
        updated_groups = [g.model_copy(deep=True) for g in gui_setup.channels_groups]
        changed = False
        for group in updated_groups:
            ensured = ensure_filters_list(group.filters)
            if ensured != group.filters:
                group.filters = ensured
                changed = True
        if changed:
            self._session_manager.set_channels_groups(updated_groups)
        self._update_mapping_display(gui_setup.channels_mapping_img)
        self.rebuild_groups_ui()

    def _sync_time_controls(self):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup:
            return
        self._updating = True
        current_sweep_idx = int(gui_setup.current_sweep_idx)
        sweeps_num = int(self._session_manager.header.number_of_sweeps) if self._session_manager.header else 1
        self.current_sweep_spinbox.setRange(1, max(1, sweeps_num))
        self.current_sweep_spinbox.setValue(min(max(1, current_sweep_idx + 1), max(1, sweeps_num)))
        self.start_point_spinbox.setValue(gui_setup.start_point)
        self.duration_spinbox.setValue(gui_setup.duration_ms)
        self.time_step_spinbox.setValue(gui_setup.time_step_ms)
        self.autoscroll_step_interval_spinbox.setValue(gui_setup.autoscroll_step_interval_ms)
        self.number_of_dots_spinbox.setValue(gui_setup.number_of_dots_to_display)
        self.duration_label.setText(f"Duration (ms) {milliseconds_to_readable(gui_setup.duration_ms)}")
        self.time_step_label.setText(f"Time step (ms) {milliseconds_to_readable(gui_setup.time_step_ms)}")
        self._updating = False

    def on_filters_changed(self):
        # Do not rebuild filter form here. This signal can be emitted from
        # a filter editor widget (e.g. QDoubleSpinBox.valueChanged); rebuilding
        # that form in the same call stack may delete the active Qt widget and crash.
        pass

    def _build_group_filters_setup(self, layout: QVBoxLayout, group_idx: int, group):
        filters = list(group.filters or [])
        if not filters:
            return

        filter_layout = QVBoxLayout()
        title = QLabel("Group filters")
        title.setStyleSheet("font-weight: bold;")
        filter_layout.addWidget(title)

        add_row = QHBoxLayout()
        add_row.addWidget(QLabel("Choose filter:"))
        selector = QComboBox()
        for flt in filters:
            selector.addItem(flt.filter_name)
        add_row.addWidget(selector, 1)
        filter_layout.addLayout(add_row)

        params_widget = QWidget()
        params_layout = QFormLayout(params_widget)
        params_layout.setContentsMargins(4, 4, 4, 4)
        params_layout.setFormAlignment(Qt.AlignmentFlag.AlignLeft)
        params_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        filter_layout.addWidget(params_widget)

        enabled_label = QLabel()
        filter_layout.addWidget(enabled_label)

        disable_btn = QPushButton("Disable all")
        filter_layout.addWidget(disable_btn)
        layout.addLayout(filter_layout)

        def current_filters() -> List:
            gui_setup = self._session_manager.gui_setup
            if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
                return []
            return list(gui_setup.channels_groups[group_idx].filters or [])

        def save_filters(updated_filters: List):
            self._session_manager.set_channel_group_filters(group_idx, updated_filters)

        def sync_label(local_filters: List):
            enabled = [f.filter_name for f in local_filters if getattr(f, "enabled", False)]
            enabled_label.setText(f"Enabled: {', '.join(enabled) if enabled else 'None'}")

        def clear_form():
            while params_layout.rowCount():
                params_layout.removeRow(0)

        def update_filter_param(index: int, field: str, value):
            updated_filters = current_filters()
            if not (0 <= index < len(updated_filters)):
                return
            flt = updated_filters[index].model_copy()
            setattr(flt, field, value)
            if hasattr(flt, "sos_cache"):
                flt.sos_cache = {}
            updated_filters[index] = flt
            save_filters(updated_filters)
            sync_label(updated_filters)

        def build_form(index: int):
            local_filters = current_filters()
            if not (0 <= index < len(local_filters)):
                clear_form()
                return
            flt = local_filters[index]
            clear_form()
            enabled_checkbox = QCheckBox()
            enabled_checkbox.setChecked(bool(flt.enabled))
            enabled_checkbox.stateChanged.connect(
                lambda state, idx=index: update_filter_param(
                    idx, "enabled", Qt.CheckState(state) == Qt.CheckState.Checked
                )
            )
            params_layout.addRow("Enabled:", enabled_checkbox)
            if isinstance(flt, ButterworthLowPassFilter):
                cutoff = QDoubleSpinBox(); cutoff.setRange(0.1, 1e6); cutoff.setSingleStep(1.0); cutoff.setValue(float(flt.cutoff_hz))
                cutoff.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "cutoff_hz", value))
                order = QSpinBox(); order.setRange(1, 12); order.setValue(int(flt.order))
                order.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "order", value))
                params_layout.addRow("Cutoff (Hz):", cutoff); params_layout.addRow("Order:", order)
            elif isinstance(flt, ButterworthHighPassFilter):
                cutoff = QDoubleSpinBox(); cutoff.setRange(0.1, 1e6); cutoff.setSingleStep(1.0); cutoff.setValue(float(flt.cutoff_hz))
                cutoff.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "cutoff_hz", value))
                order = QSpinBox(); order.setRange(1, 12); order.setValue(int(flt.order))
                order.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "order", value))
                params_layout.addRow("Cutoff (Hz):", cutoff); params_layout.addRow("Order:", order)
            elif isinstance(flt, ButterworthBandPassFilter):
                lowcut = QDoubleSpinBox(); lowcut.setRange(0.1, 1e6); lowcut.setSingleStep(1.0); lowcut.setValue(float(flt.lowcut_hz))
                lowcut.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "lowcut_hz", value))
                highcut = QDoubleSpinBox(); highcut.setRange(0.1, 1e6); highcut.setSingleStep(1.0); highcut.setValue(float(flt.highcut_hz))
                highcut.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "highcut_hz", value))
                order = QSpinBox(); order.setRange(1, 12); order.setValue(int(flt.order))
                order.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "order", value))
                params_layout.addRow("Low cut (Hz):", lowcut); params_layout.addRow("High cut (Hz):", highcut)
                params_layout.addRow("Order:", order)
            elif isinstance(flt, ChebyshevBandPassFilter):
                lowcut = QDoubleSpinBox(); lowcut.setRange(0.1, 1e6); lowcut.setSingleStep(1.0); lowcut.setValue(float(flt.lowcut_hz))
                lowcut.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "lowcut_hz", value))
                highcut = QDoubleSpinBox(); highcut.setRange(0.1, 1e6); highcut.setSingleStep(1.0); highcut.setValue(float(flt.highcut_hz))
                highcut.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "highcut_hz", value))
                order = QSpinBox(); order.setRange(1, 12); order.setValue(int(flt.order))
                order.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "order", value))
                ripple = QDoubleSpinBox(); ripple.setRange(0.1, 10.0); ripple.setSingleStep(0.1); ripple.setValue(float(flt.ripple_db))
                ripple.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "ripple_db", value))
                params_layout.addRow("Low cut (Hz):", lowcut); params_layout.addRow("High cut (Hz):", highcut)
                params_layout.addRow("Order:", order); params_layout.addRow("Ripple (dB):", ripple)
            elif isinstance(flt, NotchFilter):
                freq = QDoubleSpinBox(); freq.setRange(1.0, 1e6); freq.setSingleStep(1.0); freq.setValue(float(flt.notch_freq_hz))
                freq.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "notch_freq_hz", value))
                q_factor = QDoubleSpinBox(); q_factor.setRange(0.1, 200.0); q_factor.setSingleStep(1.0); q_factor.setValue(float(flt.q_factor))
                q_factor.valueChanged.connect(lambda value, idx=index: update_filter_param(idx, "q_factor", value))
                params_layout.addRow("Notch (Hz):", freq); params_layout.addRow("Q factor:", q_factor)
            sync_label(local_filters)

        selector.currentIndexChanged.connect(build_form)

        def disable_all():
            updated_filters = []
            for flt in current_filters():
                copy_flt = flt.model_copy()
                copy_flt.enabled = False
                updated_filters.append(copy_flt)
            save_filters(updated_filters)
            sync_label(updated_filters)
            build_form(selector.currentIndex())

        disable_btn.clicked.connect(disable_all)
        sync_label(filters)
        selector.setCurrentIndex(0)
        build_form(0)

    def rebuild_groups_ui(self):
        gui_setup = self._session_manager.gui_setup
        header = self._session_manager.header
        if not gui_setup or not header:
            return
        self._rebuilding_groups = True
        while self.channels_layout.count() > 3:
            item = self.channels_layout.takeAt(3)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self._group_list_widgets.clear()
        self._group_enabled_checkboxes.clear()

        for group_idx, group in enumerate(gui_setup.channels_groups):
            box = QGroupBox()
            box_layout = QVBoxLayout(box)

            header_row = QHBoxLayout()
            header_row.addWidget(QLabel(f"#{group_idx} Channels group"))
            group_up_btn = QToolButton()
            group_up_btn.setText("↑")
            group_up_btn.clicked.connect(lambda _c=False, idx=group_idx: self._move_group(idx, -1))
            group_down_btn = QToolButton()
            group_down_btn.setText("↓")
            group_down_btn.clicked.connect(lambda _c=False, idx=group_idx: self._move_group(idx, 1))
            header_row.addWidget(group_up_btn)
            header_row.addWidget(group_down_btn)
            remove_btn = QPushButton("Remove")
            remove_btn.clicked.connect(lambda _c=False, idx=group_idx: self._on_remove_group(idx))
            header_row.addWidget(remove_btn)
            header_row.addStretch(1)
            box_layout.addLayout(header_row)

            form = QFormLayout()
            form.setFormAlignment(Qt.AlignmentFlag.AlignLeft)
            form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

            name_edit = QLineEdit()
            name_edit.setText(group.name)
            name_edit.editingFinished.connect(
                lambda idx=group_idx, w=name_edit: self._on_group_name_editing_finished(idx, w)
            )
            form.addRow("Name:", name_edit)

            shown = QCheckBox()
            shown.setChecked(group.is_shown)
            shown.stateChanged.connect(
                lambda state, idx=group_idx: self._session_manager.set_channel_group_field(
                    idx, is_shown=(Qt.CheckState(state) == Qt.CheckState.Checked)
                )
            )
            form.addRow("View:", shown)

            ratio_spin = QSpinBox()
            ratio_spin.setRange(1, 100)
            ratio_spin.setKeyboardTracking(False)
            ratio_spin.setValue(max(1, int(group.height_ratio)))
            ratio_spin.valueChanged.connect(lambda val, idx=group_idx: self._session_manager.set_channel_group_field(idx, height_ratio=val))
            form.addRow("Group height ratio:", ratio_spin)

            if not group.is_auxiliary:
                rows_spin = QSpinBox()
                rows_spin.setRange(1, 512)
                rows_spin.setKeyboardTracking(False)
                rows_spin.setValue(max(1, int(group.number_of_rows_to_show)))
                rows_spin.valueChanged.connect(
                    lambda val, idx=group_idx: self._session_manager.set_channel_group_field(idx, number_of_rows_to_show=val)
                )
                form.addRow("Number to show:", rows_spin)

            aux_checkbox = QCheckBox()
            aux_checkbox.setChecked(group.is_auxiliary)
            aux_checkbox.stateChanged.connect(
                lambda state, idx=group_idx: self._on_aux_changed(
                    idx, Qt.CheckState(state) == Qt.CheckState.Checked
                )
            )
            form.addRow("Auxiliary channels:", aux_checkbox)
            box_layout.addLayout(form)

            self._build_group_filters_setup(box_layout, group_idx, group)

            if not group.is_auxiliary:
                self._build_group_common_setup(box_layout, group.channel_indexes, gui_setup.channels_setup)

            channel_list = QListWidget()
            channel_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
            channel_list.setDragDropMode(QListWidget.DragDropMode.NoDragDrop)
            channel_list.setDragEnabled(False)
            channel_list.setAcceptDrops(False)
            self._group_list_widgets[group_idx] = channel_list
            for channel_idx in group.channel_indexes:
                self._add_channel_row(channel_list, group_idx, group, channel_idx, gui_setup.channels_setup)
            box_layout.addWidget(channel_list)

            btn_row = QHBoxLayout()
            reorder_btn = QPushButton("Reorder")
            reorder_btn.clicked.connect(lambda _c=False, idx=group_idx: self._open_reorder_dialog(idx))
            enable_all = QPushButton("Enable all")
            enable_all.clicked.connect(lambda _c=False, idx=group_idx: self._set_group_enabled(idx, True))
            disable_all = QPushButton("Disable all")
            disable_all.clicked.connect(lambda _c=False, idx=group_idx: self._set_group_enabled(idx, False))
            btn_row.addWidget(reorder_btn)
            btn_row.addWidget(enable_all)
            btn_row.addWidget(disable_all)
            box_layout.addLayout(btn_row)

            move_row = QHBoxLayout()
            move_row.addWidget(QLabel("Move selected to"))
            move_combo = QComboBox()
            for to_idx, to_group in enumerate(gui_setup.channels_groups):
                if to_idx == group_idx:
                    continue
                move_combo.addItem(f"#{to_idx} {to_group.name}", to_idx)
            move_btn = QPushButton("Move")
            move_btn.clicked.connect(
                lambda _c=False, from_idx=group_idx, combo=move_combo: self._move_selected_to_group(
                    from_idx, int(combo.currentData()) if combo.currentData() is not None else -1
                )
            )
            move_row.addWidget(move_combo, 1)
            move_row.addWidget(move_btn)
            box_layout.addLayout(move_row)
            self.channels_layout.addWidget(box)
        self._rebuilding_groups = False
        self._last_groups_structure_signature = self._groups_structure_signature(gui_setup)

    @staticmethod
    def _groups_structure_signature(gui_setup) -> Tuple:
        return tuple(
            (
                group.name,
                tuple(group.channel_indexes),
                tuple(flt.filter_type for flt in (group.filters or [])),
                group.is_auxiliary,
            )
            for group in (gui_setup.channels_groups or [])
        )

    def _on_channels_groups_changed(self, _groups):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup:
            return
        signature = self._groups_structure_signature(gui_setup)
        if signature == self._last_groups_structure_signature and self._group_enabled_checkboxes:
            self._sync_group_enabled_checkboxes()
            return
        self.rebuild_groups_ui()

    def _sync_group_enabled_checkboxes(self):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup:
            return
        for group_idx, group in enumerate(gui_setup.channels_groups):
            enabled_set = set(group.enabled_indexes)
            for channel_idx in group.channel_indexes:
                checkbox = self._group_enabled_checkboxes.get((group_idx, channel_idx))
                if checkbox is None:
                    continue
                should_be_checked = channel_idx in enabled_set
                if checkbox.isChecked() == should_be_checked:
                    continue
                checkbox.blockSignals(True)
                checkbox.setChecked(should_be_checked)
                checkbox.blockSignals(False)

    def _build_group_common_setup(self, layout: QVBoxLayout, channel_indexes: List[int], channels_setup):
        if not channel_indexes:
            return
        sample = channels_setup.get(channel_indexes[0])
        scale_val = float(getattr(sample, "scale", settings.DEFAULT_SCALE))
        y_offset_val = float(getattr(sample, "y_offset", 0.0))
        color_val = str(getattr(sample, "color", "#000000"))

        form = QFormLayout()
        form.setFormAlignment(Qt.AlignmentFlag.AlignLeft)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        scale_spin = QDoubleSpinBox()
        scale_spin.setRange(settings.MIN_SCALE, settings.MAX_SCALE)
        scale_spin.setKeyboardTracking(False)
        scale_spin.setSingleStep(settings.SCALE_STEP)
        scale_spin.setValue(scale_val)
        y_offset_spin = QDoubleSpinBox()
        y_offset_spin.setRange(-1_000_000.0, 1_000_000.0)
        y_offset_spin.setKeyboardTracking(False)
        y_offset_spin.setSingleStep(10.0)
        y_offset_spin.setValue(y_offset_val)
        color_btn = QPushButton()
        color_btn.setProperty("color_str", color_val)
        color_btn.setStyleSheet(f"background-color: {color_val};")
        color_btn.setMaximumWidth(30)

        def apply_to_all():
            color_str = color_btn.property("color_str") or "#000000"
            self._session_manager.set_channels_setup(
                channel_indexes,
                scale=scale_spin.value(),
                y_offset=y_offset_spin.value(),
                color=color_str,
            )

        scale_spin.valueChanged.connect(lambda _v: apply_to_all())
        y_offset_spin.valueChanged.connect(lambda _v: apply_to_all())

        def on_pick_color():
            cur = QColor(color_btn.property("color_str"))
            if not cur.isValid():
                cur = QColor("#000000")
            new = QColorDialog.getColor(cur, self, "Select color")
            if not new.isValid():
                return
            color_btn.setProperty("color_str", new.name())
            color_btn.setStyleSheet(f"background-color: {new.name()};")
            apply_to_all()

        color_btn.clicked.connect(on_pick_color)
        form.addRow("Scale:", scale_spin)
        form.addRow("Y offset:", y_offset_spin)
        form.addRow("Color:", color_btn)
        layout.addLayout(form)

    def _add_channel_row(self, channel_list: QListWidget, group_idx: int, group, channel_idx: int, channels_setup):
        channel_name = self.get_channel_name(channel_idx)
        setup = channels_setup.get(channel_idx)
        info = str(getattr(setup, "info", ""))
        widget = QWidget()
        root = QVBoxLayout(widget)
        root.setContentsMargins(2, 2, 2, 2)
        root.setSpacing(2)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(2)

        enabled_cb = QCheckBox()
        enabled_cb.setChecked(channel_idx in group.enabled_indexes)
        enabled_cb.stateChanged.connect(lambda state, idx=channel_idx, gidx=group_idx: self._on_channel_enabled(gidx, idx, state))
        self._group_enabled_checkboxes[(group_idx, channel_idx)] = enabled_cb
        row.addWidget(enabled_cb)
        row.addSpacing(10)
        row.addWidget(QLabel(f"{channel_idx} [{channel_name}]"), 1)
        info_edit = QLineEdit(info)
        info_edit.setPlaceholderText("Info, e.g. area")
        info_edit.setMinimumWidth(140)

        def apply_info():
            cur_setup = self._session_manager.gui_setup.channels_setup.get(channel_idx)
            self._session_manager.set_channel_setup(
                channel_idx,
                scale=float(getattr(cur_setup, "scale", settings.DEFAULT_SCALE)),
                y_offset=float(getattr(cur_setup, "y_offset", 0.0)),
                color=str(getattr(cur_setup, "color", "#000000")),
                info=info_edit.text().strip(),
            )

        info_edit.editingFinished.connect(apply_info)
        row.addWidget(info_edit)
        root.addLayout(row)

        if group.is_auxiliary:
            color = str(getattr(setup, "color", "#000000"))
            scale = float(getattr(setup, "scale", settings.DEFAULT_SCALE))
            y_offset = float(getattr(setup, "y_offset", 0.0))
            scale_spin = QDoubleSpinBox(); scale_spin.setRange(settings.MIN_SCALE, settings.MAX_SCALE)
            scale_spin.setKeyboardTracking(False)
            scale_spin.setSingleStep(settings.SCALE_STEP); scale_spin.setValue(scale)
            y_spin = QDoubleSpinBox(); y_spin.setRange(-1_000_000.0, 1_000_000.0)
            y_spin.setKeyboardTracking(False)
            y_spin.setSingleStep(10.0); y_spin.setValue(y_offset)
            color_btn = QPushButton(); color_btn.setProperty("color_str", color)
            color_btn.setStyleSheet(f"background-color: {color};"); color_btn.setMaximumWidth(30)

            def apply():
                self._session_manager.set_channel_setup(
                    channel_idx, scale=scale_spin.value(), y_offset=y_spin.value(),
                    color=color_btn.property("color_str") or "#000000",
                    info=info_edit.text().strip(),
                )

            scale_spin.valueChanged.connect(lambda _v: apply())
            y_spin.valueChanged.connect(lambda _v: apply())

            def pick_color():
                cur = QColor(color_btn.property("color_str"))
                new = QColorDialog.getColor(cur, self, "Select color")
                if not new.isValid():
                    return
                color_btn.setProperty("color_str", new.name())
                color_btn.setStyleSheet(f"background-color: {new.name()};")
                apply()

            color_btn.clicked.connect(pick_color)
            aux_row = QHBoxLayout()
            aux_row.addWidget(QLabel("S"))
            aux_row.addWidget(scale_spin)
            aux_row.addWidget(QLabel("Y"))
            aux_row.addWidget(y_spin)
            aux_row.addWidget(QLabel("C"))
            aux_row.addWidget(color_btn)
            aux_row.addStretch(1)
            root.addLayout(aux_row)

        item = QListWidgetItem(channel_list)
        item.setData(Qt.ItemDataRole.UserRole, channel_idx)
        item.setSizeHint(widget.sizeHint())
        channel_list.addItem(item)
        channel_list.setItemWidget(item, widget)

    def _open_reorder_dialog(self, group_idx: int):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
            return
        group = gui_setup.channels_groups[group_idx]
        dialog = ChannelReorderDialog(group.channel_indexes, self.get_channel_name, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        self._apply_group_channel_order(group_idx, dialog.get_order())

    def _apply_group_channel_order(self, group_idx: int, new_order: List[int]):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
            return
        groups = [g.model_copy(deep=True) for g in gui_setup.channels_groups]
        group = groups[group_idx]
        enabled_set = set(group.enabled_indexes)
        group.channel_indexes = list(new_order)
        group.enabled_indexes = {idx for idx in new_order if idx in enabled_set}
        self._session_manager.set_channels_groups(groups)

    def _on_channel_enabled(self, group_idx: int, channel_idx: int, state: int):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
            return
        groups = [g.model_copy(deep=True) for g in gui_setup.channels_groups]
        group = groups[group_idx]
        checked = Qt.CheckState(state) == Qt.CheckState.Checked
        if checked:
            group.enabled_indexes.add(channel_idx)
        else:
            group.enabled_indexes.discard(channel_idx)
        self._session_manager.set_channels_groups(groups)

    def _set_group_enabled(self, group_idx: int, enabled: bool):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
            return
        groups = [g.model_copy(deep=True) for g in gui_setup.channels_groups]
        target = groups[group_idx]
        target.enabled_indexes = set(target.channel_indexes) if enabled else set()
        self._session_manager.set_channels_groups(groups)

    def _move_selected_to_group(self, from_group_idx: int, to_group_idx: int):
        if to_group_idx < 0:
            return
        widget = self._group_list_widgets.get(from_group_idx)
        if widget is None:
            return
        selected = []
        for item in widget.selectedItems():
            idx = item.data(Qt.ItemDataRole.UserRole)
            if idx is not None:
                selected.append(int(idx))
        self._session_manager.move_channels_to_group(selected, to_group_idx)

    def _on_remove_group(self, group_idx: int):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
            return
        group = gui_setup.channels_groups[group_idx]
        if group.channel_indexes:
            QMessageBox.warning(self, "Remove group", "You cannot remove a non-empty group.")
            return
        self._session_manager.remove_channel_group(group_idx)

    def _on_group_name_editing_finished(self, group_idx: int, widget: QLineEdit):
        if self._rebuilding_groups:
            return
        gui_setup = self._session_manager.gui_setup
        if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
            return
        new_name = widget.text().strip() or "Group"
        old_name = gui_setup.channels_groups[group_idx].name
        if new_name == old_name:
            return
        self._session_manager.set_channel_group_field(group_idx, name=new_name)

    def _move_group(self, group_idx: int, delta: int):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup:
            return
        groups = [g.model_copy(deep=True) for g in gui_setup.channels_groups]
        new_idx = group_idx + delta
        if new_idx < 0 or new_idx >= len(groups):
            return
        groups[group_idx], groups[new_idx] = groups[new_idx], groups[group_idx]
        for group in groups:
            group.start_row_idx = 0
        self._session_manager.set_channels_groups(groups)

    def _on_aux_changed(self, group_idx: int, is_auxiliary: bool):
        gui_setup = self._session_manager.gui_setup
        if not gui_setup or not (0 <= group_idx < len(gui_setup.channels_groups)):
            return
        current = gui_setup.channels_groups[group_idx]
        if current.is_auxiliary and not is_auxiliary:
            answer = QMessageBox.question(
                self,
                "Disable auxiliary mode",
                "All channels in this group will be reset to default scale/color/offset. Continue?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
            self._session_manager.set_channels_setup(
                current.channel_indexes,
                scale=settings.DEFAULT_SCALE,
                y_offset=0.0,
                color="#000000",
            )
        self._session_manager.set_channel_group_field(group_idx, is_auxiliary=is_auxiliary)

    def get_channel_name(self, channel_idx: int) -> str:
        header = self._session_manager.header
        if (header and header.channel_info and header.channel_info.name
                and 0 <= channel_idx < len(header.channel_info.name)):
            base_name = header.channel_info.name[channel_idx]
            impedance_values = header.channel_info.impedance_ohm or []
            if channel_idx < len(impedance_values):
                formatted = self._format_impedance(impedance_values[channel_idx])
                if formatted:
                    return f"{base_name} ({formatted})"
            return base_name
        return f"Channel {channel_idx}"

    @staticmethod
    def _format_impedance(impedance_ohm: Optional[float]) -> str:
        if impedance_ohm is None:
            return ""
        try:
            val = float(impedance_ohm)
        except (TypeError, ValueError):
            return ""
        if val < 0:
            return ""
        units = ("Ohm", "kOhm", "MOhm", "GOhm")
        idx = 0
        while val >= 1000.0 and idx < len(units) - 1:
            val /= 1000.0
            idx += 1
        if val >= 100:
            text = f"{val:.0f}"
        elif val >= 10:
            text = f"{val:.1f}".rstrip("0").rstrip(".")
        else:
            text = f"{val:.2f}".rstrip("0").rstrip(".")
        return f"{text} {units[idx]}"

    def on_channels_mapping_img_changed(self, channels_mapping_img: str):
        self._update_mapping_display(channels_mapping_img)

    def on_set_units_clicked(self):
        if not self._session_manager.header:
            return
        HeaderUnitsManagementDialog(self._session_manager, self).exec()

    def on_attach_link_clicked(self):
        link, ok = QInputDialog.getText(self, "Attach link", "Paste image link:")
        if not ok:
            return
        self._session_manager.set_channels_mapping_img(link.strip())

    def on_attach_file_clicked(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select image",
            "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif);;All Files (*)",
        )
        if not file_path:
            return
        try:
            with open(file_path, "rb") as file:
                data = file.read()
        except OSError:
            return
        mime, _ = mimetypes.guess_type(file_path)
        mime = mime or "image/png"
        encoded = base64.b64encode(data).decode("ascii")
        self._session_manager.set_channels_mapping_img(f"data:{mime};base64,{encoded}")

    def _update_mapping_display(self, channels_mapping_img: str):
        self._mapping_text = channels_mapping_img or ""
        self._mapping_pixmap = None
        self._mapping_link_url = ""
        self.mapping_image_label.set_pixmap(None)
        if not self._mapping_text:
            self.mapping_text_label.setText("")
            return

        if self._mapping_text.startswith("http://") or self._mapping_text.startswith("https://"):
            self._mapping_link_url = self._mapping_text
            self.mapping_text_label.setText('<a href="mapping">Attached link (click)</a> (double click to view)')
            try:
                with urllib.request.urlopen(self._mapping_text, timeout=5) as response:
                    raw = response.read()
            except Exception:
                self.mapping_text_label.setText('<a href="mapping">Attached link (click)</a><br>Failed to load image')
                return
            pixmap = QPixmap()
            if pixmap.loadFromData(raw):
                self._set_mapping_pixmap(pixmap)
            else:
                self.mapping_text_label.setText('<a href="mapping">Attached link (click)</a><br>Failed to decode image')
            return

        if self._mapping_text.startswith("data:"):
            self.mapping_text_label.setText("Attached file (double click to view)")
            parts = self._mapping_text.split(",", 1)
            if len(parts) != 2:
                self.mapping_text_label.setText("Failed to decode attached file")
                return
            try:
                raw = base64.b64decode(parts[1])
            except Exception:
                self.mapping_text_label.setText("Failed to decode attached file")
                return
            pixmap = QPixmap()
            if pixmap.loadFromData(raw):
                self._set_mapping_pixmap(pixmap)
            else:
                self.mapping_text_label.setText("Failed to decode attached file")
            return

        self.mapping_text_label.setText(self._mapping_text)

    def on_mapping_link_activated(self, _link: str):
        if self._mapping_link_url:
            QDesktopServices.openUrl(QUrl(self._mapping_link_url))

    def _set_mapping_pixmap(self, pixmap: QPixmap):
        self._mapping_pixmap = pixmap
        self._apply_scaled_pixmap()

    def _apply_scaled_pixmap(self):
        if self._mapping_pixmap is None:
            self.mapping_image_label.set_pixmap(None)
            return
        target_width = self.mapping_image_label.width()
        if target_width <= 1:
            target_width = settings.CHANNELS_MAPPING_IMG_DEFAULT_WIDTH
        display = self._mapping_pixmap.scaledToWidth(
            target_width,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.mapping_image_label.set_pixmap(self._mapping_pixmap, display)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._mapping_pixmap is not None:
            self._apply_scaled_pixmap()

