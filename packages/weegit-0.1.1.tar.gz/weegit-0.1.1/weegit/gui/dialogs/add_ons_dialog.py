from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import urllib
import html

import tomli
from importlib.metadata import PackageNotFoundError, version
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional
from urllib.request import urlopen

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QSizePolicy,
)

from weegit import settings
from weegit.gui.dialogs.loading_dialog import LoadingDialog
from weegit.gui.qt_weegit_session_manager_wrapper import QtWeegitSessionManagerWrapper
from weegit.logger import weegit_logger


@dataclass
class _IndexItem:
    label: str
    module_name: str
    keywords: List[str]
    path: str


class AddOnsDialog(QDialog):
    def __init__(self, session_manager: QtWeegitSessionManagerWrapper, parent=None):
        super().__init__(parent)
        self._session_manager = session_manager
        self._index_items: List[_IndexItem] = []
        self._selected_module_name: Optional[str] = None
        self._is_populating_table = False

        self.setWindowTitle("Add-ons")
        self.resize(980, 620)
        self._build_ui()
        self._load_index_and_refresh(parent)

    def _build_ui(self):
        root_layout = QVBoxLayout(self)
        splitter = QSplitter(Qt.Orientation.Horizontal, self)
        root_layout.addWidget(splitter)

        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)

        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["", "Name"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 28)
        left_layout.addWidget(self.table)

        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)

        self.meta_form = QFormLayout()
        self.meta_form.setFormAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.meta_form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.meta_form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        self.meta_form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.lbl_module_name = QLabel("-")
        self.lbl_version = QLabel("-")
        self.lbl_description = QLabel("-")
        self.lbl_author = QLabel("-")
        self.lbl_keywords = QLabel("-")
        self.lbl_links = QLabel("-")
        for label in (
            self.lbl_module_name,
            self.lbl_version,
            self.lbl_description,
            self.lbl_keywords,
        ):
            label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            label.setWordWrap(True)
        self.lbl_author.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.lbl_author.setWordWrap(True)
        self.lbl_author.setTextFormat(Qt.TextFormat.RichText)
        self.lbl_links.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.lbl_links.setWordWrap(True)
        self.lbl_links.setTextFormat(Qt.TextFormat.RichText)
        self.lbl_keywords.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.lbl_author.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.lbl_keywords.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.lbl_author.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.lbl_links.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.lbl_author.setOpenExternalLinks(True)
        self.lbl_links.setOpenExternalLinks(True)

        self.meta_form.addRow("Module name:", self.lbl_module_name)
        self.meta_form.addRow("Version:", self.lbl_version)
        self.meta_form.addRow("Description:", self.lbl_description)
        self.meta_form.addRow("Author:", self.lbl_author)
        self.meta_form.addRow("Keywords:", self.lbl_keywords)
        self.meta_form.addRow("Links:", self.lbl_links)
        right_layout.addLayout(self.meta_form)
        right_layout.addStretch(1)

        btn_row = QHBoxLayout()
        self.btn_install_toggle = QPushButton("Install")
        self.btn_update = QPushButton("Update")
        self.btn_update.setVisible(False)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_install_toggle)
        btn_row.addWidget(self.btn_update)
        right_layout.addLayout(btn_row)

        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)

        self.table.itemSelectionChanged.connect(self._on_table_selection_changed)
        self.btn_install_toggle.clicked.connect(self._on_install_toggle_clicked)
        self.btn_update.clicked.connect(self._on_update_clicked)

    def _is_installed(self, module_name: str) -> bool:
        return self._session_manager.has_runtime_add_on(module_name)

    def _load_index(self) -> List[_IndexItem]:
        with urlopen(settings.INDEX_RAW_URL, timeout=10) as response:
            payload = json.loads(response.read().decode("utf-8"))
        items: List[_IndexItem] = []
        for row in payload:
            items.append(
                _IndexItem(
                    label=str(row.get("label", "")).strip(),
                    module_name=str(row.get("module_name", "")).strip(),
                    keywords=[str(x) for x in (row.get("keywords") or [])],
                    path=str(row.get("path", "")).strip(),
                )
            )
        return [x for x in items if x.module_name and x.path]

    def _load_index_and_refresh(self, parent):
        loading = LoadingDialog("Loading add-ons information...", parent)
        loading.show()
        loading.raise_()
        loading.activateWindow()
        QApplication.processEvents()
        try:
            self._session_manager.refresh_runtime_add_ons()
            try:
                self._index_items = self._load_index()
            except Exception as exc:
                QMessageBox.warning(self, "Add-ons", f"Failed to load index.json: {exc}")
                self._index_items = []
            self._reload_table()
        finally:
            loading.close()

    def _reload_table(self):
        self._is_populating_table = True
        self.table.setRowCount(0)
        for row_idx, item in enumerate(self._index_items):
            self.table.insertRow(row_idx)

            status_item = QTableWidgetItem()
            status_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            status_item.setCheckState(Qt.CheckState.Checked if self._is_installed(item.module_name) else Qt.CheckState.Unchecked)
            status_item.setData(Qt.ItemDataRole.UserRole, item.module_name)
            self.table.setItem(row_idx, 0, status_item)

            name_item = QTableWidgetItem(item.label or item.module_name)
            name_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.table.setItem(row_idx, 1, name_item)
        self._is_populating_table = False

        if self._selected_module_name:
            self._select_row_by_module(self._selected_module_name)
            self._update_right_panel()
        elif self.table.rowCount() > 0:
            self.table.selectRow(0)
        else:
            self._set_no_selection_state()

    def _select_row_by_module(self, module_name: str):
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item and item.data(Qt.ItemDataRole.UserRole) == module_name:
                self.table.selectRow(row)
                return

    def _set_no_selection_state(self):
        self._selected_module_name = None
        self.lbl_module_name.setText("-")
        self.lbl_version.setText("-")
        self.lbl_description.setText("Select add-on")
        self.lbl_author.setText("-")
        self.lbl_keywords.setText("-")
        self.lbl_links.setText("-")
        self.btn_install_toggle.setEnabled(False)
        self.btn_update.setVisible(False)

    def _selected_index_item(self) -> Optional[_IndexItem]:
        if self._selected_module_name is None:
            return None
        for item in self._index_items:
            if item.module_name == self._selected_module_name:
                return item
        return None

    @staticmethod
    def _repository_web_base_url() -> str:
        repo_url = settings.ADD_ONS_REPOSITORY.strip()
        if repo_url.endswith(".git"):
            return repo_url[:-4]
        return repo_url

    @staticmethod
    def _format_authors_html(authors: object) -> str:
        if not isinstance(authors, list):
            return "-"
        rendered: List[str] = []
        for author in authors:
            if not isinstance(author, dict):
                continue
            name = str(author.get("name", "") or "").strip()
            email = str(author.get("email", "") or "").strip()
            if not name and not email:
                continue

            if name:
                safe_name = html.escape(name)
                name_html = safe_name
            else:
                name_html = "Unknown author"

            if email:
                safe_email = html.escape(email)
                rendered.append(f"{name_html} ({safe_email})")
            else:
                rendered.append(name_html)

        return ", ".join(rendered) if rendered else "-"

    @staticmethod
    def _format_links_html(project_urls: object, add_on_path: str) -> str:
        links: List[str] = []
        if isinstance(project_urls, dict):
            for raw_title, raw_url in project_urls.items():
                title = str(raw_title or "").strip()
                url = str(raw_url or "").strip()
                if not title or not url:
                    continue
                safe_title = html.escape(title)
                safe_url = html.escape(url, quote=True)
                links.append(f'<a href="{safe_url}">{safe_title}</a>')

        homepage_url = f"{AddOnsDialog._repository_web_base_url()}/tree/main/{add_on_path.strip('/')}"
        safe_homepage = html.escape(homepage_url, quote=True)
        links.append(f'<a href="{safe_homepage}">Add-on homepage</a>')
        return "<br>".join(links)

    def _fetch_pyproject_info(self, add_on_path: str) -> Dict[str, str]:
        pyproject_url = f"{settings.REPO_RAW_BASE}/{add_on_path}/pyproject.toml"
        request = urllib.request.Request(pyproject_url)
        request.add_header('Pragma', 'no-cache')
        request.add_header('Cache-Control', 'no-cache')
        with urlopen(request, timeout=10) as response:
            parsed = tomli.loads(response.read().decode("utf-8"))
        project = parsed.get("project", {})
        description = str(project.get("description", "") or "")
        version = str(project.get("version", "") or "")
        authors = project.get("authors") or []
        project_urls = project.get("urls") or {}
        return {
            "description": description,
            "version": version,
            "author": self._format_authors_html(authors),
            "links": self._format_links_html(project_urls, add_on_path),
        }

    def _update_right_panel(self):
        item = self._selected_index_item()
        if item is None:
            self._set_no_selection_state()
            return

        self.lbl_module_name.setText(item.module_name)
        self.lbl_keywords.setText(", ".join(item.keywords) if item.keywords else "-")
        self.btn_install_toggle.setEnabled(True)

        try:
            pyproject = self._fetch_pyproject_info(item.path)
            self.lbl_description.setText(pyproject["description"] or "-")
            self.lbl_version.setText(pyproject["version"] or "-")
            self.lbl_author.setText(pyproject["author"])
            self.lbl_links.setText(pyproject["links"])
        except Exception as exc:
            self.lbl_version.setText("-")
            self.lbl_description.setText("-")
            self.lbl_author.setText("-")
            self.lbl_links.setText("-")
            QMessageBox.warning(self, "Add-ons", f"Failed to load pyproject.toml: {exc}")

        installed = self._is_installed(item.module_name)
        installed_version = "-"
        if installed:
            try:
                installed_version = version(item.module_name)
            except PackageNotFoundError:
                installed_version = "-"

        github_version = self.lbl_version.text().strip() or "-"
        self.lbl_version.setText(f"{github_version} (installed version: {installed_version})")
        self.btn_install_toggle.setText("Uninstall" if installed else "Install")
        self.btn_update.setVisible(installed)

    def _on_table_selection_changed(self):
        if self._is_populating_table:
            return
        selected = self.table.selectedItems()
        if not selected:
            self._set_no_selection_state()
            return
        row = selected[0].row()
        id_item = self.table.item(row, 0)
        if not id_item:
            self._set_no_selection_state()
            return
        self._selected_module_name = id_item.data(Qt.ItemDataRole.UserRole)
        self._update_right_panel()

    def _pip_spec_for(self, add_on_path: str) -> str:
        return f"git+{settings.ADD_ONS_REPOSITORY}#subdirectory={add_on_path}"

    def _run_pip(self, args: List[str], title: str):
        loading = LoadingDialog(title, self)
        loading.show()
        loading.raise_()
        loading.activateWindow()
        QApplication.processEvents()
        pip_cmd = self._resolve_pip_command()
        pip_env = self._pip_env()
        
        process = subprocess.run(
            [*pip_cmd, *args],
            capture_output=True,
            text=True,
            check=False,
            env=pip_env,
        )
        if process.stdout:
            weegit_logger().info(process.stdout)
        if process.stderr: 
            weegit_logger().warning(process.stderr)
        loading.close()
        if process.returncode != 0:
            details = (process.stderr or process.stdout or "Unknown error").strip()
            raise RuntimeError(details)

    def _on_install_toggle_clicked(self):
        item = self._selected_index_item()
        if item is None:
            return
        try:
            installed = self._is_installed(item.module_name)
            if installed:
                self._run_pip(["uninstall", "-y", item.module_name], "Uninstalling add-on...")
                self._session_manager.pop_add_on(item.module_name)
                add_on_data_dir = (
                    Path(self._session_manager.weegit_experiment_folder)
                    / settings.ADD_ONS_SUBFOLDER
                    / settings.ADD_ONS_DATA_SUBFOLDER
                    / item.module_name
                )
                if add_on_data_dir.exists():
                    shutil.rmtree(add_on_data_dir)
            else:
                self._run_pip(["install", self._pip_spec_for(item.path)], "Package installation in progress")
            self._session_manager.refresh_runtime_add_ons()
            if not installed:
                self._session_manager.set_add_on(item.module_name, view_enabled=True, transform_enabled=True)
            self._reload_table()
        except Exception as exc:
            QMessageBox.warning(self, "Add-ons", f"Operation failed: {exc}")

    def _on_update_clicked(self):
        item = self._selected_index_item()
        if item is None:
            return
        try:
            self._run_pip(["install", "-U", self._pip_spec_for(item.path)], "Updating add-on...")
            self._session_manager.refresh_runtime_add_ons()
            self._reload_table()
        except Exception as exc:
            QMessageBox.warning(self, "Add-ons", f"Update failed: {exc}")

    def _ensure_pip(self):
        """Ensure pip is available for current interpreter."""
        pip_env = self._pip_env()
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "--version"],
                check=True,
                capture_output=True,
                text=True,
                env=pip_env,
            )
        except (subprocess.CalledProcessError, FileNotFoundError):
            subprocess.run(
                [sys.executable, "-m", "ensurepip", "--upgrade"],
                check=True,
                env=pip_env,
            )
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
                check=True,
                env=pip_env,
            )

    def _pip_env(self) -> Dict[str, str]:
        # GUI/IDE launchers may set PYTHONHOME/PYTHONPATH that break `-m pip`.
        pip_env = dict(os.environ)
        pip_env.pop("PYTHONHOME", None)
        pip_env.pop("PYTHONPATH", None)
        return pip_env

    def _resolve_pip_command(self) -> List[str]:
        self._ensure_pip()
        pip_env = self._pip_env()
        cmd = [sys.executable, "-m", "pip"]
        probe = subprocess.run(
            [*cmd, "--version"],
            capture_output=True,
            text=True,
            check=False,
            env=pip_env,
        )
        if probe.returncode == 0 and not probe.stderr:
            return cmd

        pip_exe = Path(sys.executable).with_name("pip.exe")
        if pip_exe.exists():
            return [str(pip_exe)]

        raise RuntimeError((probe.stderr or probe.stdout or "pip is unavailable").strip())
