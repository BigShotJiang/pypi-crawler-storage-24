from pathlib import Path
from typing import Dict, Any

from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QDialogButtonBox,
    QCheckBox,
)

from weegit.converter.source_reader.intan_rhs_source_reader import IntanRhsSourceReader
from weegit.converter.source_reader.old_weegit_reader import OldWeegitSourceReader


class ConverterDialog(QDialog):
    def __init__(self, reader, output_folder: Path, parent=None):
        super().__init__(parent)
        self._reader = reader
        self._output_folder = output_folder
        self._group_rhs_checkbox = None
        self.setWindowTitle("Convert to Weegit")
        self.resize(540, 220)
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        if isinstance(self._reader, IntanRhsSourceReader):
            source_name = "Intan RHS"
        elif isinstance(self._reader, OldWeegitSourceReader):
            source_name = "Old Weegit"
        else:
            source_name = self._reader.__class__.__name__

        source_label = QLabel(f"Detected source type: {source_name}")
        source_label.setWordWrap(True)
        layout.addWidget(source_label)

        if isinstance(self._reader, IntanRhsSourceReader):
            rhs_files_count = self._reader.get_rhs_files_count()
            rhs_info = QLabel(f"Detected RHS files: {rhs_files_count}")
            rhs_info.setWordWrap(True)
            layout.addWidget(rhs_info)
            if rhs_files_count > 1:
                self._group_rhs_checkbox = QCheckBox("Group all RHS files into one sweep")
                self._group_rhs_checkbox.setChecked(True)
                layout.addWidget(self._group_rhs_checkbox)
                rhs_hint = QLabel(
                    "If disabled, each RHS file is converted to a separate sweep."
                )
                rhs_hint.setWordWrap(True)
                layout.addWidget(rhs_hint)

        confirmation = QLabel(
            f"Weegit is going to create folder {self._output_folder} with the required files."
        )
        confirmation.setWordWrap(True)
        layout.addWidget(confirmation)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Proceed")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancel")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def conversion_options(self) -> Dict[str, Any]:
        options: Dict[str, Any] = {}
        if self._group_rhs_checkbox is not None:
            options["group_rhs_files_into_single_sweep"] = bool(self._group_rhs_checkbox.isChecked())
        return options
