import importlib
import sys
from importlib.metadata import entry_points
from pathlib import Path
from typing import Dict

from weegit.logger import weegit_logger

from weegit.core.add_ons.base import BaseAddOn


def load_installed_add_ons():
    importlib.invalidate_caches()

    runtime_add_ons: Dict[str, BaseAddOn] = {}
    for ep in entry_points().select(group="add_ons"):
        try:
            module_path = str(getattr(ep, "value", "")).split(":", 1)[0].strip()
            if module_path:
                stale_modules = [
                    name for name in list(sys.modules.keys())
                    if name == module_path or name.startswith(f"{module_path}.")
                ]
                for stale_module_name in stale_modules:
                    sys.modules.pop(stale_module_name, None)

            add_on_cls = ep.load()
            add_on_obj = add_on_cls()
            # dist_name = getattr(getattr(ep, "dist", None), "name", None)
            module_name = ep.dist.name
            add_on_name = make_add_on_name(ep.dist.name, ep.name)
            setattr(add_on_obj, "_weegit_module_name", module_name)
            runtime_add_ons[add_on_name] = add_on_obj
        except Exception as e:
            weegit_logger().debug(str(e))
            continue

    return runtime_add_ons


def load_dev_add_ons():
    runtime_add_ons: Dict[str, BaseAddOn] = {}
    dev_folder = Path("./add_on_development")  # configurable path
    if dev_folder.exists():
        # Add the folder to sys.path (temporarily) to allow imports
        dev_folder_str = str(dev_folder.resolve())
        if dev_folder_str not in sys.path:
            sys.path.insert(0, dev_folder_str)

        for py_file in dev_folder.glob("*.py"):
            if py_file.name == "__init__.py":
                continue

            module_name = py_file.stem  # filename without .py
            try:
                # Remove stale module if it was loaded before
                if module_name in sys.modules:
                    sys.modules.pop(module_name, None)

                # Import the module
                module = importlib.import_module(module_name)

                # Find all classes that are subclasses of BaseAddOn (excluding BaseAddOn itself)
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if isinstance(attr, type) and issubclass(attr, BaseAddOn) and attr != BaseAddOn:
                        add_on_obj = attr()
                        # Use a distinct key prefix to avoid name clashes with installed add-ons
                        dev_key = f"dev_{module_name}"
                        setattr(add_on_obj, "_weegit_module_name", dev_key)
                        runtime_add_ons[dev_key] = add_on_obj
            except Exception as e:
                weegit_logger().debug(str(e))
                continue

    return runtime_add_ons


def make_add_on_name(module_name, entry_point_name):
    return f"{module_name}:{entry_point_name}"


def module_from_add_on_name(add_on_name):
    return add_on_name.split(":")[0]
