# User domain model.
