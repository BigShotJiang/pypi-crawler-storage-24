from setuptools import setup, find_packages

setup(
    name="iel-tools",
    version="0.0.10",
    author="José Manuel Martin Coronado",
    description="Librería unificada con herramientas PromptSQL,CheckSpace y modelo",
    packages=find_packages(),
    author_email="jm@martincoronado.com.pe",
    install_requires=[
        "pandas", "numpy", "openai", "requests", "matplotlib", "seaborn", "statsmodels"
    ],
)
