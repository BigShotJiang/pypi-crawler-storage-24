import pandas, seaborn, statsmodels.api as sm, matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix
from google.colab import files

nombre_archivo = "Carrito-XLSX-20260304-204327.xlsx"

X = "ipc_sinAB"; Y = "bc"

archivo = files.upload()

datos = pandas.read_excel(nombre_archivo, sheet_name="Mensuales", header=1, na_values="n.d.",
                          names = ["meses", "tc_bv", "pgnv", "tarif_elec", "pbi", "it_tumbes",
                                   "var_it_tumbes", "inv_tumbes", "ipc_sinAB", "bc"], index_col = 0)
display(datos)

modelo1 = sm.OLS(datos[Y], sm.add_constant(datos[X]), missing="drop").fit()

plt.figure(figsize=(9,4))
plt.subplot(2,3,1); datos.dropna(subset=[Y, X])[Y].plot()
plt.subplot(2,3,2); datos.dropna(subset=[Y, X])[X].plot()
plt.subplot(2,3,3)
eje_izq = plt.gca(); datos.dropna(subset=[Y, X])[Y].plot(ax = eje_izq, color="green")
eje_der = eje_izq.twinx(); datos.dropna(subset=[Y, X])[X].plot(ax=eje_der, color="orange")
plt.subplot(2,3,4)
datos.dropna(subset=[Y, X]).plot.scatter(x=X, y=Y, ax=plt.gca())
plt.plot(datos.dropna(subset=[Y, X])[X],
             modelo1.predict(sm.add_constant(datos.dropna(subset=[Y, X])[X])),
             color="red")
plt.subplot(2,3,5); datos["error2"].plot(); plt.axhline(y=0, color="red")
plt.subplot(2,3,6); plt.hist(datos["error2"])
plt.tight_layout(); plt.show()

print(modelo1.summary())
