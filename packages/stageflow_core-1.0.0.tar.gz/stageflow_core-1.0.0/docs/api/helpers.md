# Helper Modules API Reference

This page documents the APIs exported by `stageflow.helpers`.

For most application code, prefer `stageflow.api` plus `await pipeline.run(...)`.
Treat `PipelineRunner` and `run_simple_pipeline(...)` as compatibility/utility
helpers when you specifically want `RunResult`, helper-managed event capture, or
their extra runtime helper wiring.

## Key exports

```python
from stageflow.helpers import (
    # Guardrails
    ViolationType,
    PolicyViolation,
    GuardrailCheck,
    ContentLengthCheck,
    GuardrailConfig,
    GuardrailResult,
    GuardrailStage,
    PIIDetector,
    InjectionDetector,
    ContentFilter,
    # Streaming
    BackpressureMonitor,
    ChunkQueue,
    RealtimeStageBus,
    StreamingBuffer,
    AudioChunk,
    AudioFormat,
    StreamConfig,
    create_realtime_stage_context,
    # Analytics
    AnalyticsEvent,
    AnalyticsExporter,
    BufferedExporter,
    ConsoleExporter,
    JSONFileExporter,
)
```

## BackpressureMonitor

```python
BackpressureMonitor(*, high_water_mark: int = 80, low_water_mark: int = 20)
```

- `high_water_mark` / `low_water_mark` are percentage thresholds.
- Use `record_put(queue_size, max_size)` and `should_throttle()`.

## RealtimeStageBus

```python
RealtimeStageBus(
    *,
    default_max_size: int = 100,
    default_drop_on_overflow: bool = False,
    event_emitter: Callable[[str, dict[str, Any]], None] | None = None,
)
```

- Named channel bus for concurrent stage-to-stage streaming.
- Producer: `await bus.publish("llm_to_tts", token)`.
- Consumer: `async for token in bus.subscribe("llm_to_tts")`.
- Close channels explicitly with `await bus.close_channel("llm_to_tts")`.

## create_realtime_stage_context

```python
create_realtime_stage_context(
    snapshot,
    *,
    bus=None,
    bus_max_size: int = 100,
    bus_drop_on_overflow: bool = False,
) -> tuple[StageContext, RealtimeStageBus]
```

- Convenience helper to create a `StageContext` with `realtime_bus` pre-wired in ports.

## BufferedExporter

```python
BufferedExporter(
    exporter: AnalyticsExporter,
    *,
    batch_size: int = 100,
    flush_interval_seconds: float = 10.0,
    max_buffer_size: int = 10000,
    on_overflow: Callable[[int, int], None] | None = None,
    high_water_mark: float = 0.8,
)
```

- Constructor parameter is `exporter` (not `sink`).
- Flush interval parameter is `flush_interval_seconds`.
- `stats` returns keys:
  - `buffer_size`
  - `max_buffer_size`
  - `dropped_count`
  - `fill_ratio`
  - `high_water_warned`

## Example

```python
from stageflow.helpers import ConsoleExporter, BufferedExporter, BackpressureMonitor

exporter = BufferedExporter(ConsoleExporter(), batch_size=50, flush_interval_seconds=2.0)
monitor = BackpressureMonitor(high_water_mark=80, low_water_mark=20)
```
