"""Auth unit tests."""
