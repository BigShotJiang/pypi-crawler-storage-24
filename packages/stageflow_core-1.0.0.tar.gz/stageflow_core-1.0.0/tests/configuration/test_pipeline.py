"""Comprehensive tests for stageflow.pipeline module.

Tests the Pipeline builder and related types:
- Pipeline class (fluent builder)
- UnifiedStageSpec dataclass
- build() method and UnifiedStageGraph creation
- compose() method for merging pipelines
- with_stage() fluent interface
"""

from dataclasses import FrozenInstanceError
from uuid import uuid4

import pytest

from stageflow.core import (
    StageContext,
    StageKind,
    StageOutput,
    StageReturn,
    StageStatus,
    stage_metadata,
)
from stageflow.pipeline.guard_retry import GuardRetryPolicy, GuardRetryStrategy
from stageflow.pipeline.interceptors import BaseInterceptor
from stageflow.pipeline.pipeline import (
    Pipeline,
    UnifiedStageSpec,
    run_stage,
    stage,
)
from stageflow.pipeline.results import PipelineResults
from stageflow.pipeline.spec import CycleDetectedError, PipelineValidationError
from stageflow.stages.context import PipelineContext

# === Test Fixtures ===

class SimpleStage:
    """Simple test stage for pipeline testing."""
    name = "simple_stage"
    kind = StageKind.TRANSFORM

    async def execute(self, _ctx: StageContext) -> StageOutput:
        return StageOutput.ok(result="simple_done")


class TransformStage:
    """Transform stage for testing."""
    name = "transform"
    kind = StageKind.TRANSFORM

    async def execute(self, _ctx: StageContext) -> StageOutput:
        return StageOutput.ok(data={"transformed": True})


class EnrichStage:
    """Enrich stage for testing."""
    name = "enrich"
    kind = StageKind.ENRICH

    async def execute(self, _ctx: StageContext) -> StageOutput:
        return StageOutput.ok(data={"enriched": True})


class GuardStage:
    """Guard stage for testing."""
    name = "guard"
    kind = StageKind.GUARD

    async def execute(self, _ctx: StageContext) -> StageOutput:
        return StageOutput.ok(data={"guarded": True})


class FailingStage:
    """Stage that always fails for error testing."""
    name = "failing"
    kind = StageKind.WORK

    def __init__(self, error_message: str = "Stage failed"):
        self.error_message = error_message

    async def execute(self, _ctx: StageContext) -> StageOutput:
        return StageOutput.fail(error=self.error_message)


class StageWithDelay:
    """Stage with configurable delay for timing tests."""
    name = "delayed"
    kind = StageKind.WORK

    def __init__(self, delay_seconds: float = 0.1):
        self.delay_seconds = delay_seconds

    async def execute(self, _ctx: StageContext) -> StageOutput:
        import time
        time.sleep(self.delay_seconds)
        return StageOutput.ok(data={"delayed": True})


class EchoInputStage:
    """Stage that echoes caller-facing context fields."""

    name = "echo_input"
    kind = StageKind.TRANSFORM

    async def execute(self, ctx: StageContext) -> StageOutput:
        return StageOutput.ok(
            input_text=ctx.snapshot.input_text,
            topology=ctx.snapshot.topology,
        )


class KindlessStage:
    """Stage without a declared kind."""

    async def execute(self, _ctx: StageContext) -> StageOutput:
        return StageOutput.ok(data={"ok": True})


class InvalidKindStage:
    """Stage with an invalid string kind value."""

    kind = "not-a-real-kind"

    async def execute(self, _ctx: StageContext) -> StageOutput:
        return StageOutput.ok(data={"ok": True})


@stage_metadata(name="decorated_echo", kind=StageKind.TRANSFORM)
class DecoratedEchoStage:
    """Stage using the metadata decorator and plain dict return path."""

    async def execute(self, ctx: StageContext) -> StageReturn:
        return {
            "input_text": ctx.snapshot.input_text,
            "topology": ctx.snapshot.topology,
        }


# === Test UnifiedStageSpec ===

class TestUnifiedStageSpec:
    """Tests for UnifiedStageSpec dataclass."""

    def test_spec_creation(self):
        """Test UnifiedStageSpec with required fields."""
        spec = UnifiedStageSpec(
            name="test_stage",
            runner=SimpleStage,
            kind=StageKind.TRANSFORM,
        )
        assert spec.name == "test_stage"
        assert spec.runner == SimpleStage
        assert spec.kind == StageKind.TRANSFORM

    def test_spec_with_dependencies(self):
        """Test UnifiedStageSpec with dependencies."""
        spec = UnifiedStageSpec(
            name="dependent",
            runner=TransformStage,
            kind=StageKind.TRANSFORM,
            dependencies=("stage_a", "stage_b"),
        )
        assert spec.dependencies == ("stage_a", "stage_b")

    def test_spec_with_conditional(self):
        """Test UnifiedStageSpec with conditional flag."""
        spec = UnifiedStageSpec(
            name="conditional_stage",
            runner=GuardStage,
            kind=StageKind.GUARD,
            conditional=True,
        )
        assert spec.conditional is True

    def test_spec_defaults(self):
        """Test UnifiedStageSpec default values."""
        spec = UnifiedStageSpec(
            name="default_stage",
            runner=SimpleStage,
            kind=StageKind.TRANSFORM,
        )
        assert spec.dependencies == ()
        assert spec.conditional is False

    def test_spec_is_frozen(self):
        """Verify UnifiedStageSpec is frozen."""
        spec = UnifiedStageSpec(
            name="test",
            runner=SimpleStage,
            kind=StageKind.TRANSFORM,
        )
        with pytest.raises(FrozenInstanceError):
            spec.name = "changed"

    def test_spec_has_slots(self):
        """Verify UnifiedStageSpec uses slots."""
        assert hasattr(UnifiedStageSpec, "__slots__")


# === Test Pipeline ===

class TestPipeline:
    """Tests for Pipeline class."""

    def test_empty_pipeline(self):
        """Test empty Pipeline has no stages."""
        pipeline = Pipeline()
        assert pipeline.stages == {}
        assert pipeline.name == "pipeline"

    def test_pipeline_with_custom_name(self):
        """Pipeline constructor should accept a friendly name."""
        pipeline = Pipeline(name="demo").with_stage(
            "simple",
            SimpleStage,
            StageKind.TRANSFORM,
        )
        assert pipeline.name == "demo"
        assert "simple" in pipeline.stages

    def test_get_stage(self):
        """Pipeline should expose stage lookup by name."""
        pipeline = Pipeline().with_stage("simple", SimpleStage, StageKind.TRANSFORM)

        assert pipeline.get_stage("simple") is not None
        assert pipeline.get_stage("missing") is None

    def test_has_stage(self):
        """Pipeline should expose stage existence checks."""
        pipeline = Pipeline().with_stage("simple", SimpleStage, StageKind.TRANSFORM)

        assert pipeline.has_stage("simple") is True
        assert pipeline.has_stage("missing") is False

    def test_stage_names_topological_order(self):
        """Pipeline should report stage names in topological order."""
        pipeline = (
            Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM)
            .with_stage("c", EnrichStage, StageKind.ENRICH, dependencies=("b",))
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
        )

        assert pipeline.stage_names() == ["a", "b", "c"]

    def test_with_stage_single(self):
        """Test adding a single stage."""
        pipeline = Pipeline().with_stage(
            "simple",
            SimpleStage,
            StageKind.TRANSFORM,
        )
        assert "simple" in pipeline.stages
        assert pipeline.stages["simple"].name == "simple"
        assert pipeline.stages["simple"].kind == StageKind.TRANSFORM

    def test_with_stage_infers_kind_from_stage_class(self):
        """with_stage should infer StageKind from stage classes when omitted."""
        pipeline = Pipeline().with_stage("simple", SimpleStage)

        assert pipeline.stages["simple"].kind == StageKind.TRANSFORM

    def test_with_stage_infers_kind_from_stage_instance(self):
        """with_stage should infer StageKind from stage instances when omitted."""
        pipeline = Pipeline().with_stage("simple", SimpleStage())

        assert pipeline.stages["simple"].kind == StageKind.TRANSFORM

    def test_with_stage_requires_kind_when_not_inferable(self):
        """with_stage should fail fast when kind cannot be inferred."""
        with pytest.raises(ValueError, match="kind is required"):
            Pipeline().with_stage("kindless", KindlessStage)

    def test_with_stage_rejects_invalid_inferred_kind(self):
        """Invalid string kind metadata should fail clearly."""
        with pytest.raises(ValueError, match="Unsupported stage kind value"):
            Pipeline().with_stage("bad", InvalidKindStage)

    def test_with_stage_after_alias(self):
        """after= should provide a readable dependency alias."""
        pipeline = (
            Pipeline()
            .with_stage("a", SimpleStage)
            .with_stage("b", TransformStage, after="a")
        )

        assert pipeline.stages["b"].dependencies == ("a",)

    def test_with_stage_rejects_dependencies_and_after_together(self):
        """dependencies and after should be mutually exclusive."""
        with pytest.raises(ValueError, match="either dependencies=... or after"):
            Pipeline().with_stage(
                "b",
                TransformStage,
                dependencies=("a",),
                after="a",
            )

    def test_with_stages_and_stage_helper(self):
        """Declarative stage specs should compose cleanly."""
        pipeline = Pipeline(name="demo").with_stages(
            stage("a", SimpleStage),
            stage("b", TransformStage, after="a"),
        )

        assert set(pipeline.stages.keys()) == {"a", "b"}
        assert pipeline.stages["b"].dependencies == ("a",)

    def test_from_stages_classmethod(self):
        """Pipeline.from_stages should support concise declarative definitions."""
        pipeline = Pipeline.from_stages(
            stage("a", SimpleStage),
            stage("b", EnrichStage, after="a"),
            name="demo",
        )

        assert pipeline.name == "demo"
        assert pipeline.stages["b"].dependencies == ("a",)

    def test_with_stage_fluent_interface(self):
        """Test fluent interface returns new Pipeline."""
        pipeline1 = Pipeline()
        pipeline2 = pipeline1.with_stage("stage1", SimpleStage, StageKind.TRANSFORM)
        # Should return a new Pipeline instance
        assert pipeline2 is not pipeline1
        # Original should be unchanged
        assert "stage1" not in pipeline1.stages

    def test_with_stage_multiple(self):
        """Test adding multiple stages via chaining."""
        pipeline = (Pipeline()
            .with_stage("stage1", SimpleStage, StageKind.TRANSFORM)
            .with_stage("stage2", TransformStage, StageKind.TRANSFORM)
            .with_stage("stage3", EnrichStage, StageKind.ENRICH)
        )
        assert len(pipeline.stages) == 3
        assert "stage1" in pipeline.stages
        assert "stage2" in pipeline.stages
        assert "stage3" in pipeline.stages

    def test_with_stage_with_dependencies(self):
        """Test adding stage with dependencies."""
        pipeline = (Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM)
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
            .with_stage("c", EnrichStage, StageKind.ENRICH, dependencies=("a", "b"))
        )
        assert pipeline.stages["b"].dependencies == ("a",)
        assert pipeline.stages["c"].dependencies == ("a", "b")

    def test_with_stage_with_conditional(self):
        """Test adding conditional stage."""
        pipeline = Pipeline().with_stage(
            "conditional",
            GuardStage,
            StageKind.GUARD,
            conditional=True,
        )
        assert pipeline.stages["conditional"].conditional is True

    def test_with_stage_rejects_duplicate_name(self):
        """Test that duplicate stage names are allowed (last wins)."""
        pipeline = (Pipeline()
            .with_stage("duplicate", SimpleStage, StageKind.TRANSFORM)
            .with_stage("duplicate", TransformStage, StageKind.TRANSFORM)
        )
        # Last one wins
        assert pipeline.stages["duplicate"].runner == TransformStage

    def test_with_stage_config_injected_into_class(self):
        """Config kwargs are passed to class-based stages."""

        class StageWithConfig(SimpleStage):  # pragma: no cover - simple helper
            def __init__(self, flag: bool = False):
                self.flag = flag

            async def execute(self, _ctx: StageContext) -> StageOutput:
                return StageOutput.ok(flag=self.flag)

        pipeline = Pipeline().with_stage(
            "configurable",
            StageWithConfig,
            StageKind.TRANSFORM,
            config={"flag": True},
        )
        spec = pipeline.stages["configurable"]
        assert spec.config == {"flag": True}

    def test_with_stage_config_rejects_instances(self):
        """Providing config for stage instances should raise."""
        instance = SimpleStage()
        with pytest.raises(ValueError):
            Pipeline().with_stage(
                "instance",
                instance,
                StageKind.TRANSFORM,
                config={"unused": True},
            )

    def test_compose_empty_with_empty(self):
        """Test composing two empty pipelines."""
        pipeline1 = Pipeline()
        pipeline2 = Pipeline()
        composed = pipeline1.compose(pipeline2)
        assert composed.stages == {}

    def test_compose_with_stages(self):
        """Test composing pipelines with stages."""
        pipeline1 = Pipeline().with_stage("a", SimpleStage, StageKind.TRANSFORM)
        pipeline2 = Pipeline().with_stage("b", TransformStage, StageKind.TRANSFORM)
        composed = pipeline1.compose(pipeline2)
        assert len(composed.stages) == 2
        assert "a" in composed.stages
        assert "b" in composed.stages

    def test_compose_preserves_order(self):
        """Test that compose preserves stage order."""
        pipeline1 = Pipeline().with_stage("a", SimpleStage, StageKind.TRANSFORM)
        pipeline2 = Pipeline().with_stage("b", TransformStage, StageKind.TRANSFORM)
        composed = pipeline1.compose(pipeline2)
        assert composed.stage_names() == ["a", "b"]

    def test_compose_rejects_conflicting_specs(self):
        """Compose should reject incompatible duplicate stage definitions."""
        pipeline1 = Pipeline().with_stage("conflict", SimpleStage, StageKind.TRANSFORM)
        pipeline2 = Pipeline().with_stage("conflict", TransformStage, StageKind.TRANSFORM)

        with pytest.raises(PipelineValidationError, match="different specs"):
            pipeline1.compose(pipeline2)

    def test_compose_returns_new_instance(self):
        """Test that compose returns a new Pipeline instance."""
        pipeline1 = Pipeline().with_stage("a", SimpleStage, StageKind.TRANSFORM)
        pipeline2 = Pipeline().with_stage("b", TransformStage, StageKind.TRANSFORM)
        composed = pipeline1.compose(pipeline2)
        assert composed is not pipeline1
        assert composed is not pipeline2

    def test_compose_multiple(self):
        """Test chaining multiple compose calls."""
        pipeline1 = Pipeline().with_stage("a", SimpleStage, StageKind.TRANSFORM)
        pipeline2 = Pipeline().with_stage("b", TransformStage, StageKind.TRANSFORM)
        pipeline3 = Pipeline().with_stage("c", EnrichStage, StageKind.ENRICH)
        composed = pipeline1.compose(pipeline2).compose(pipeline3)
        assert len(composed.stages) == 3

    def test_compose_with_dependencies(self):
        """Test that dependencies are preserved through compose."""
        pipeline1 = (Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM)
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
        )
        pipeline2 = Pipeline().with_stage("c", EnrichStage, StageKind.ENRICH, dependencies=("a",))
        composed = pipeline1.compose(pipeline2)
        assert composed.stages["b"].dependencies == ("a",)
        assert composed.stages["c"].dependencies == ("a",)

    # === build() method tests ===

    def test_build_empty_pipeline_raises(self):
        """Test that building empty pipeline raises PipelineValidationError."""
        pipeline = Pipeline()
        with pytest.raises(PipelineValidationError) as exc_info:
            pipeline.build()
        assert "Cannot build empty pipeline" in str(exc_info.value)

    def test_build_missing_dependency_raises(self):
        """Build should fail fast on missing dependencies."""
        pipeline = Pipeline().with_stage(
            "orphan",
            SimpleStage,
            StageKind.TRANSFORM,
            dependencies=("missing",),
        )

        with pytest.raises(PipelineValidationError, match="does not exist"):
            pipeline.build()

    def test_build_cycle_raises(self):
        """Build should fail fast on dependency cycles."""
        pipeline = (
            Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM, dependencies=("b",))
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
        )

        with pytest.raises(CycleDetectedError, match="cycle"):
            pipeline.build()

    def test_build_creates_graph(self):
        """Test that build() creates a UnifiedStageGraph."""
        pipeline = Pipeline().with_stage("test", SimpleStage, StageKind.TRANSFORM)
        graph = pipeline.build()
        assert graph is not None

    @pytest.mark.asyncio
    async def test_run_executes_pipeline_with_pipeline_context(self):
        """Pipeline.run should wrap build().run(...) for the common path."""
        pipeline = Pipeline().with_stage("test", SimpleStage, StageKind.TRANSFORM)

        results = await pipeline.run(
            PipelineContext(
                input_text="hello",
                topology="demo",
                execution_mode="default",
            )
        )

        assert results["test"].status == StageStatus.OK
        assert results["test"].data == {"result": "simple_done"}

    @pytest.mark.asyncio
    async def test_run_accepts_direct_context_kwargs(self):
        """Pipeline.run should create PipelineContext from direct keyword args."""
        pipeline = Pipeline(name="demo").with_stage("echo", EchoInputStage)

        results = await pipeline.run(input_text="hello", topology="demo")

        assert isinstance(results, PipelineResults)
        assert results.data("echo")["input_text"] == "hello"
        assert results.data("echo")["topology"] == "demo"

    @pytest.mark.asyncio
    async def test_run_rejects_ctx_and_context_kwargs_together(self):
        """Pipeline.run should avoid ambiguous context construction."""
        pipeline = Pipeline(name="demo").with_stage("echo", EchoInputStage)

        with pytest.raises(ValueError, match="either ctx or PipelineContext keyword fields"):
            await pipeline.run(PipelineContext(topology="demo"), input_text="hello")

    @pytest.mark.asyncio
    async def test_invoke_accepts_positional_input_text(self):
        """Pipeline.invoke should accept the common one-string path."""
        pipeline = Pipeline(name="demo").with_stage("echo", EchoInputStage)

        results = await pipeline.invoke("hello", topology="demo")

        assert results.ok("echo") is True
        assert results.data("echo")["input_text"] == "hello"

    @pytest.mark.asyncio
    async def test_run_stage_executes_single_stage_fast_path(self):
        """run_stage should build a tiny pipeline and return the stage output."""
        output = await run_stage("echo", EchoInputStage, input_text="hello", topology="single")

        assert output.status == StageStatus.OK
        assert output.data["input_text"] == "hello"

    @pytest.mark.asyncio
    async def test_run_normalizes_plain_dict_stage_returns(self):
        """Stages may return plain dict payloads on the happy path."""
        pipeline = Pipeline(name="demo").with_stage("echo", DecoratedEchoStage)

        results = await pipeline.run(input_text="hello", topology="demo")

        assert results.require_ok("echo").data["input_text"] == "hello"
        assert results.data("echo")["topology"] == "demo"

    def test_pipeline_results_helpers(self):
        """PipelineResults should provide nicer stage access helpers."""
        results = PipelineResults(
            {
                "ok_stage": StageOutput.ok(answer=42),
                "failed_stage": StageOutput.fail(error="boom"),
            }
        )

        assert results.require("ok_stage").data["answer"] == 42
        assert results.require_ok("ok_stage").data["answer"] == 42
        assert results.data("ok_stage")["answer"] == 42
        assert results.ok("ok_stage") is True
        assert results.ok("failed_stage") is False
        assert results.failed() == ["failed_stage"]
        with pytest.raises(KeyError):
            results.require("missing")
        with pytest.raises(RuntimeError, match="did not complete with OK status"):
            results.require_ok("failed_stage")

    def test_curated_api_module_exports_happy_path_symbols(self):
        """stageflow.api should expose the streamlined public surface."""
        from stageflow.api import Pipeline as ApiPipeline
        from stageflow.api import PipelineContext as ApiPipelineContext
        from stageflow.api import PipelineResults as ApiPipelineResults
        from stageflow.api import StageReturn as ApiStageReturn
        from stageflow.api import run_stage as api_run_stage
        from stageflow.api import stage as api_stage
        from stageflow.api import stage_metadata as api_stage_metadata

        assert ApiPipeline is Pipeline
        assert ApiPipelineContext is PipelineContext
        assert ApiPipelineResults is PipelineResults
        assert ApiStageReturn is StageReturn
        assert api_run_stage is run_stage
        assert api_stage is stage
        assert api_stage_metadata is stage_metadata

    def test_advanced_module_exports_runtime_symbols(self):
        """stageflow.advanced should provide an explicit advanced import surface."""
        from stageflow.advanced import (
            ContextSnapshot,
            PipelineBuilder,
            UnifiedStageGraph,
            get_default_interceptors,
        )
        from stageflow.advanced import Pipeline as AdvancedPipeline
        from stageflow.advanced import StageReturn as AdvancedStageReturn
        from stageflow.advanced import stage_metadata as advanced_stage_metadata

        assert AdvancedPipeline is Pipeline
        assert AdvancedStageReturn is StageReturn
        assert advanced_stage_metadata is stage_metadata
        assert PipelineBuilder is not None
        assert UnifiedStageGraph is not None
        assert ContextSnapshot is not None
        assert callable(get_default_interceptors)

    @pytest.mark.asyncio
    async def test_run_without_context_uses_default_pipeline_context(self):
        """Pipeline.run should create an empty PipelineContext when omitted."""
        pipeline = Pipeline(name="demo").with_stage("test", SimpleStage, StageKind.TRANSFORM)

        results = await pipeline.run()

        assert results["test"].status == StageStatus.OK

    @pytest.mark.asyncio
    async def test_run_passes_build_options_through(self):
        """Pipeline.run should forward build-time observability options."""

        class CapturingWideEmitter:
            def __init__(self) -> None:
                self.pipeline_events: list[dict[str, object]] = []

            def emit_pipeline_event(
                self,
                *,
                ctx,
                stage_results,
                pipeline_name,
                status,
                duration_ms,
                started_at,
            ) -> None:
                self.pipeline_events.append(
                    {
                        "ctx_topology": ctx.topology,
                        "pipeline_name": pipeline_name,
                        "status": status,
                        "stage_count": len(stage_results),
                        "duration_ms": duration_ms,
                        "started_at": started_at,
                    }
                )

        emitter = CapturingWideEmitter()
        pipeline = Pipeline(name="demo").with_stage("test", SimpleStage, StageKind.TRANSFORM)

        await pipeline.run(
            PipelineContext(topology="demo"),
            emit_pipeline_wide_event=True,
            wide_event_emitter=emitter,
        )

        assert len(emitter.pipeline_events) == 1
        assert emitter.pipeline_events[0]["pipeline_name"] == "demo"

    def test_build_with_single_stage(self):
        """Test building pipeline with single stage."""
        pipeline = Pipeline().with_stage("single", SimpleStage, StageKind.TRANSFORM)
        graph = pipeline.build()
        assert len(graph.stage_specs) == 1
        assert graph.stage_specs[0].name == "single"

    def test_build_with_multiple_stages(self):
        """Test building pipeline with multiple stages."""
        pipeline = (Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM)
            .with_stage("b", TransformStage, StageKind.TRANSFORM)
            .with_stage("c", EnrichStage, StageKind.ENRICH)
        )
        graph = pipeline.build()
        assert len(graph.stage_specs) == 3

    def test_build_preserves_dependencies(self):
        """Test that build() preserves dependencies."""
        pipeline = (Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM)
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
            .with_stage("c", EnrichStage, StageKind.ENRICH, dependencies=("a", "b"))
        )
        graph = pipeline.build()
        spec_dict = {spec.name: spec for spec in graph.stage_specs}
        assert spec_dict["b"].dependencies == ("a",)
        assert spec_dict["c"].dependencies == ("a", "b")

    def test_build_preserves_conditional(self):
        """Test that build() preserves conditional flag."""
        pipeline = Pipeline().with_stage(
            "conditional",
            GuardStage,
            StageKind.GUARD,
            conditional=True,
        )
        graph = pipeline.build()
        assert graph.stage_specs[0].conditional is True

    def test_build_with_stage_instance(self):
        """Test building with a stage instance instead of class."""
        instance = SimpleStage()
        pipeline = Pipeline().with_stage("instance", instance, StageKind.TRANSFORM)
        graph = pipeline.build()
        assert graph.stage_specs[0].name == "instance"

    def test_build_accepts_guard_retry_strategy(self):
        """Pipeline.build should pass guard retry strategies to the graph."""

        pipeline = (
            Pipeline()
            .with_stage("agent", SimpleStage, StageKind.TRANSFORM)
            .with_stage(
                "guard",
                GuardStage,
                StageKind.GUARD,
                dependencies=("agent",),
            )
        )

        strategy = GuardRetryStrategy(
            policies={"guard": GuardRetryPolicy(retry_stage="agent", max_attempts=2)}
        )

        graph = pipeline.build(guard_retry_strategy=strategy)

        assert graph._guard_retry_strategy is strategy

    def test_build_accepts_interceptors(self):
        """Pipeline.build should pass interceptors through to UnifiedStageGraph."""

        class NoOpInterceptor(BaseInterceptor):
            name = "noop"
            priority = 1

            async def before(self, _stage_name, _ctx):
                return None

            async def after(self, _stage_name, _result, _ctx):
                return None

        pipeline = Pipeline().with_stage("test", SimpleStage, StageKind.TRANSFORM)
        custom = [NoOpInterceptor()]

        graph = pipeline.build(interceptors=custom)

        assert graph._interceptors == custom

    def test_build_accepts_wide_event_options(self):
        """Pipeline.build should pass wide-event configuration through."""
        pipeline = Pipeline(name="demo").with_stage("test", SimpleStage, StageKind.TRANSFORM)

        graph = pipeline.build(emit_stage_wide_events=True, emit_pipeline_wide_event=True)

        assert graph._emit_stage_wide_events is True
        assert graph._emit_pipeline_wide_event is True
        assert graph._pipeline_name == "demo"

    def test_build_guard_retry_requires_dependency(self):
        """Guard retry validation should fail when dependency is missing."""

        pipeline = Pipeline().with_stage("guard", GuardStage, StageKind.GUARD)
        strategy = GuardRetryStrategy(
            policies={"guard": GuardRetryPolicy(retry_stage="agent", max_attempts=2)}
        )

        with pytest.raises(ValueError):
            pipeline.build(guard_retry_strategy=strategy)

    def test_build_creates_callable_runner(self):
        """Test that build() creates callable runners for stage classes."""
        pipeline = Pipeline().with_stage("test", SimpleStage, StageKind.TRANSFORM)
        graph = pipeline.build()
        spec = graph.stage_specs[0]
        # The runner should be callable
        assert callable(spec.runner)

    async def test_build_runner_executes_stage(self):
        """Test that built runner actually executes the stage."""
        from stageflow.context import ContextSnapshot, RunIdentity
        from stageflow.core.timer import PipelineTimer
        from stageflow.pipeline.dag import UnifiedStageGraph
        from stageflow.stages.inputs import StageInputs

        pipeline = Pipeline().with_stage("simple", SimpleStage, StageKind.TRANSFORM)
        graph: UnifiedStageGraph = pipeline.build()

        run_id = RunIdentity(
            pipeline_run_id=uuid4(),
            request_id=uuid4(),
            session_id=uuid4(),
            user_id=uuid4(),
            org_id=uuid4(),
            interaction_id=uuid4(),
        )
        snapshot = ContextSnapshot(
            run_id=run_id,
            topology="test",
            execution_mode="test",
        )
        inputs = StageInputs(snapshot=snapshot)
        ctx = StageContext(
            snapshot=snapshot,
            inputs=inputs,
            stage_name="simple",
            timer=PipelineTimer(),
        )

        # The runner should be an async callable
        result = await graph.stage_specs[0].runner(ctx)
        assert isinstance(result, StageOutput)
        assert result.status == StageStatus.OK

    def test_build_with_complex_dependency_graph(self):
        """Test building complex DAG with multiple dependencies."""
        pipeline = (Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM)
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
            .with_stage("c", EnrichStage, StageKind.ENRICH, dependencies=("a",))
            .with_stage("d", GuardStage, StageKind.GUARD, dependencies=("b", "c"))
        )
        graph = pipeline.build()
        spec_dict = {spec.name: spec for spec in graph.stage_specs}
        # "d" depends on both "b" and "c"
        assert spec_dict["d"].dependencies == ("b", "c")

    def test_build_preserves_stage_kind(self):
        """Test that build() preserves StageKind."""
        pipeline = (Pipeline()
            .with_stage("transform", TransformStage, StageKind.TRANSFORM)
            .with_stage("enrich", EnrichStage, StageKind.ENRICH)
            .with_stage("guard", GuardStage, StageKind.GUARD)
        )
        graph = pipeline.build()
        spec_dict = {spec.name: spec for spec in graph.stage_specs}
        assert spec_dict["transform"].kind == StageKind.TRANSFORM
        assert spec_dict["enrich"].kind == StageKind.ENRICH
        assert spec_dict["guard"].kind == StageKind.GUARD


# === Edge Cases ===

class TestPipelineEdgeCases:
    """Edge case tests for Pipeline."""

    def test_stage_with_empty_dependencies_tuple(self):
        """Test stage with explicitly empty dependencies tuple."""
        pipeline = Pipeline().with_stage(
            "no_deps",
            SimpleStage,
            StageKind.TRANSFORM,
            dependencies=(),
        )
        assert pipeline.stages["no_deps"].dependencies == ()

    def test_stage_with_single_dependency_in_tuple(self):
        """Test stage with single dependency as tuple."""
        pipeline = (Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM)
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
        )
        assert pipeline.stages["b"].dependencies == ("a",)

    def test_circular_dependency_rejected_at_build_time(self):
        """Circular dependencies should be rejected during build validation."""
        pipeline = (Pipeline()
            .with_stage("a", SimpleStage, StageKind.TRANSFORM, dependencies=("b",))
            .with_stage("b", TransformStage, StageKind.TRANSFORM, dependencies=("a",))
        )

        with pytest.raises(CycleDetectedError, match="cycle"):
            pipeline.build()

    def test_very_long_stage_name(self):
        """Test pipeline with very long stage names."""
        long_name = "a" * 1000
        pipeline = Pipeline().with_stage(long_name, SimpleStage, StageKind.TRANSFORM)
        assert long_name in pipeline.stages

    def test_unicode_stage_name(self):
        """Test pipeline with unicode stage names."""
        unicode_name = "stage_日本語_🚀"
        pipeline = Pipeline().with_stage(unicode_name, SimpleStage, StageKind.TRANSFORM)
        assert unicode_name in pipeline.stages

    def test_empty_stage_name_raises(self):
        """Test that empty stage name raises error (should be caught at runtime)."""
        # Note: This might not raise immediately depending on implementation
        # but empty names would likely cause issues during execution
        pipeline = Pipeline().with_stage("", SimpleStage, StageKind.TRANSFORM)
        assert "" in pipeline.stages

    def test_many_stages(self):
        """Test pipeline with many stages."""
        pipeline = Pipeline()
        for i in range(100):
            pipeline = pipeline.with_stage(f"stage_{i}", SimpleStage, StageKind.TRANSFORM)
        assert len(pipeline.stages) == 100

    def test_many_compose_operations(self):
        """Test many compose operations."""
        pipeline = Pipeline()
        for i in range(50):
            new_pipeline = Pipeline().with_stage(f"p{i}", SimpleStage, StageKind.TRANSFORM)
            pipeline = pipeline.compose(new_pipeline)
        assert len(pipeline.stages) == 50

    def test_compose_self(self):
        """Test that composing a pipeline with itself works."""
        pipeline = Pipeline().with_stage("a", SimpleStage, StageKind.TRANSFORM)
        # This should work but might have unexpected behavior
        composed = pipeline.compose(pipeline)
        assert "a" in composed.stages
