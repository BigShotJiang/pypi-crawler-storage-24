"""
Minimal terminal UI using Rich.
"""

from rich.console import Console

console = Console()


def print_banner():
    """Display a simple, clean CLI banner."""
    console.print()
    console.print("  [bold cyan]KTU NOTES CLI[/]")
    console.print("  [dim]Fast notes downloader for ktunotes.live[/]")
    console.print()


def show_success(msg: str):
    """Display a styled success message."""
    console.print(f"  [bold green]✔[/] {msg}")


def show_error(msg: str):
    """Display a styled error message."""
    console.print(f"  [bold red]✘[/] {msg}")


def show_info(msg: str):
    """Display a styled info message."""
    console.print(f"  [cyan]→[/] {msg}")
