"""
KTU Notes CLI — Fast notes downloader for ktunotes.live.
"""

__version__ = "1.0.0"
__app_name__ = "ktunotes"
