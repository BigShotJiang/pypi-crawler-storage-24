"""
Utility helpers for the KTU Notes CLI.
"""

import re
import webbrowser


def sanitize_filename(name: str) -> str:
    """
    Clean a string so it can be safely used as a filename.
    Removes special characters and collapses whitespace.
    """
    name = re.sub(r'[<>:"/\\|?*]', '', name)
    name = re.sub(r'\s+', '_', name.strip())
    return name


def open_in_browser(url: str) -> bool:
    """Open a URL in the user's default browser."""
    try:
        webbrowser.open(url)
        return True
    except Exception:
        return False
