"""
Memory Dashboard - TUI Integration for Memory Monitoring
======================================================

Provides live memory monitoring display for the terminal UI and
web dashboard integration.

Features:
- Live memory usage graphs
- Tool-specific memory profiles
- Alert notifications
- Historical data visualization
"""

import asyncio
import time
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime
import logging

try:
    from rich.live import Live
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.progress import BarColumn, Progress, TextColumn
    from rich.text import Text
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from memoryguard.core import MemoryGuard, MemoryAlert


@dataclass
class MemoryDisplayConfig:
    """Configuration for memory dashboard display"""
    refresh_rate: float = 1.0  # seconds
    show_graph: bool = True
    show_alerts: bool = True
    show_tool_breakdown: bool = True
    max_bars: int = 20  # Number of bars in memory graph
    warning_threshold_percent: float = 70.0
    critical_threshold_percent: float = 90.0


class MemoryDashboard:
    """
    Live memory monitoring dashboard for terminal UI.
    
    Usage:
        dashboard = MemoryDashboard(memory_guard)
        
        # Start live display
        with dashboard.live_display():
            # Your long-running operation
            await run_pentest()
    """
    
    def __init__(
        self, 
        memory_guard: MemoryGuard,
        config: Optional[MemoryDisplayConfig] = None
    ):
        self.guard = memory_guard
        self.config = config or MemoryDisplayConfig()
        self.logger = logging.getLogger(__name__)
        
        # History for sparkline
        self._memory_history: List[float] = []
        self._max_history = 60  # 60 seconds of history
        
    def _generate_sparkline(self, values: List[float], width: int = 20) -> str:
        """Generate ASCII sparkline graph"""
        if not values:
            return "─" * width
            
        min_val = min(values)
        max_val = max(values)
        
        if max_val == min_val:
            return "─" * width
            
        bars = "▁▂▃▄▅▆▇█"
        result = ""
        
        # Sample values to fit width
        step = max(1, len(values) // width)
        sampled = values[::step][:width]
        
        for val in sampled:
            normalized = (val - min_val) / (max_val - min_val)
            bar_idx = int(normalized * (len(bars) - 1))
            result += bars[bar_idx]
            
        return result
        
    def _create_memory_table(self) -> Table:
        """Create main memory status table"""
        table = Table(
            title="[bold blue]Memory Status[/bold blue]",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta"
        )
        
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right")
        table.add_column("Status", justify="center")
        
        # Get current memory
        process = self.guard.process
        mem_info = process.memory_info()
        rss_mb = mem_info.rss / 1024 / 1024
        vms_mb = mem_info.vms / 1024 / 1024
        
        # Update history
        self._memory_history.append(rss_mb)
        if len(self._memory_history) > self._max_history:
            self._memory_history.pop(0)
            
        # Calculate status
        threshold = self.guard.threshold_mb
        critical = self.guard.critical_threshold_mb
        
        if rss_mb > critical:
            status = "[bold red]CRITICAL[/bold red]"
        elif rss_mb > threshold:
            status = "[bold yellow]WARNING[/bold yellow]"
        else:
            status = "[bold green]OK[/bold green]"
            
        # Add rows
        table.add_row(
            "Current RSS",
            f"{rss_mb:.1f} MB",
            status
        )
        table.add_row(
            "Virtual Memory",
            f"{vms_mb:.1f} MB",
            "[dim]─[/dim]"
        )
        table.add_row(
            "Threshold",
            f"{threshold:.0f} MB",
            "[dim]─[/dim]"
        )
        table.add_row(
            "Critical",
            f"{critical:.0f} MB",
            "[dim]─[/dim]"
        )
        
        # Sparkline
        if self._memory_history:
            sparkline = self._generate_sparkline(self._memory_history)
            table.add_row(
                "History (60s)",
                sparkline,
                "[dim]─[/dim]"
            )
            
        return table
        
    def _create_alerts_table(self) -> Optional[Table]:
        """Create recent alerts table"""
        if not self.guard._alerts:
            return None
            
        table = Table(
            title="[bold yellow]Recent Alerts[/bold yellow]",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta"
        )
        
        table.add_column("Time", style="dim")
        table.add_column("Level", justify="center")
        table.add_column("Message")
        
        # Show last 5 alerts
        for alert in self.guard._alerts[-5:]:
            time_str = datetime.fromtimestamp(alert.timestamp).strftime("%H:%M:%S")
            
            if alert.level == 'critical':
                level_str = "[red]●[/red]"
            elif alert.level == 'warning':
                level_str = "[yellow]●[/yellow]"
            else:
                level_str = "[blue]●[/blue]"
                
            table.add_row(
                time_str,
                level_str,
                alert.message[:50]
            )
            
        return table
        
    def _create_tools_table(self) -> Optional[Table]:
        """Create tool memory breakdown table"""
        # Get unique tool names from snapshots
        tool_names = set()
        for snapshot in self.guard._snapshots:
            if '_' in snapshot.context:
                tool_name = snapshot.context.split('_')[0]
                tool_names.add(tool_name)
                
        if not tool_names:
            return None
            
        table = Table(
            title="[bold green]Tool Memory Profiles[/bold green]",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta"
        )
        
        table.add_column("Tool", style="cyan")
        table.add_column("Avg MB", justify="right")
        table.add_column("Peak MB", justify="right")
        table.add_column("Samples", justify="right")
        
        for tool_name in sorted(tool_names)[:10]:  # Top 10 tools
            profile = self.guard.get_tool_memory_profile(tool_name)
            
            if 'error' not in profile:
                table.add_row(
                    tool_name,
                    f"{profile['avg_memory_mb']:.1f}",
                    f"{profile['peak_memory_mb']:.1f}",
                    str(profile['samples'])
                )
                
        return table
        
    def _create_progress_bar(self) -> Progress:
        """Create memory usage progress bar"""
        progress = Progress(
            TextColumn("[bold blue]Memory Usage", justify="right"),
            BarColumn(bar_width=None),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.fields[mem_mb]:.0f} MB)")
        )
        
        mem_mb = self.guard.process.memory_info().rss / 1024 / 1024
        critical = self.guard.critical_threshold_mb
        
        percentage = min(100, (mem_mb / critical) * 100)
        
        task = progress.add_task(
            "memory",
            total=100,
            completed=percentage,
            mem_mb=mem_mb
        )
        
        return progress
        
    def create_layout(self) -> Layout:
        """Create full dashboard layout"""
        layout = Layout()
        
        # Split into sections
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="main"),
            Layout(name="footer", size=5)
        )
        
        # Header
        layout["header"].update(
            Panel(
                Text("CLAWDBOT Memory Monitor", justify="center", style="bold cyan"),
                box=box.DOUBLE
            )
        )
        
        # Main section - split horizontally
        layout["main"].split_row(
            Layout(name="left", ratio=2),
            Layout(name="right", ratio=1)
        )
        
        # Left side - memory status and graph
        layout["left"].update(self._create_memory_table())
        
        # Right side - alerts and tools
        right_layout = Layout()
        right_layout.split_column(
            Layout(name="alerts"),
            Layout(name="tools")
        )
        
        alerts_table = self._create_alerts_table()
        if alerts_table:
            right_layout["alerts"].update(alerts_table)
        else:
            right_layout["alerts"].update(Panel("[dim]No alerts[/dim]"))
            
        tools_table = self._create_tools_table()
        if tools_table:
            right_layout["tools"].update(tools_table)
        else:
            right_layout["tools"].update(Panel("[dim]No tool data[/dim]"))
            
        layout["right"].update(right_layout)
        
        # Footer - progress bar
        layout["footer"].update(self._create_progress_bar())
        
        return layout
        
    async def update_loop(self):
        """Background update loop for live display"""
        while True:
            await asyncio.sleep(self.config.refresh_rate)
            
    def get_simple_display(self) -> str:
        """Get simple text display (for non-rich environments)"""
        mem_mb = self.guard.process.memory_info().rss / 1024 / 1024
        threshold = self.guard.threshold_mb
        
        status = "OK"
        if mem_mb > self.guard.critical_threshold_mb:
            status = "CRITICAL"
        elif mem_mb > threshold:
            status = "WARNING"
            
        alerts_count = len([a for a in self.guard._alerts if a.level in ['warning', 'critical']])
        
        return f"[Memory: {mem_mb:.1f}MB | Status: {status} | Alerts: {alerts_count}]"
        
    def live_display(self):
        """Context manager for live dashboard display"""
        if not RICH_AVAILABLE:
            self.logger.warning("Rich not available, using simple display")
            return SimpleDisplayContext(self)
            
        return RichLiveContext(self)


class RichLiveContext:
    """Context manager for Rich live display"""
    
    def __init__(self, dashboard: MemoryDashboard):
        self.dashboard = dashboard
        self.live: Optional[Live] = None
        
    def __enter__(self):
        self.live = Live(
            self.dashboard.create_layout(),
            refresh_per_second=1/self.dashboard.config.refresh_rate,
            screen=False
        )
        self.live.__enter__()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.live:
            self.live.__exit__(exc_type, exc_val, exc_tb)
            
    def update(self):
        """Update the live display"""
        if self.live:
            self.live.update(self.dashboard.create_layout())


class SimpleDisplayContext:
    """Fallback context manager for non-Rich environments"""
    
    def __init__(self, dashboard: MemoryDashboard):
        self.dashboard = dashboard
        self._running = False
        
    def __enter__(self):
        self._running = True
        print(f"Memory monitoring started: {self.dashboard.get_simple_display()}")
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self._running = False
        print(f"Memory monitoring stopped: {self.dashboard.get_simple_display()}")
        
    def update(self):
        """Print current status"""
        if self._running:
            print(f"\r{self.dashboard.get_simple_display()}", end="")


# Web Dashboard Integration (JSON API)

class MemoryDashboardAPI:
    """
    API endpoints for web dashboard integration.
    Provides JSON data for external dashboards.
    """
    
    def __init__(self, memory_guard: MemoryGuard):
        self.guard = memory_guard
        
    def get_current_status(self) -> Dict[str, Any]:
        """Get current memory status for API"""
        mem_info = self.guard.process.memory_info()
        
        return {
            'timestamp': time.time(),
            'memory': {
                'rss_mb': mem_info.rss / 1024 / 1024,
                'vms_mb': mem_info.vms / 1024 / 1024,
                'percent': self.guard.process.memory_percent()
            },
            'thresholds': {
                'warning_mb': self.guard.threshold_mb,
                'critical_mb': self.guard.critical_threshold_mb
            },
            'alerts_count': {
                'total': len(self.guard._alerts),
                'warning': len([a for a in self.guard._alerts if a.level == 'warning']),
                'critical': len([a for a in self.guard._alerts if a.level == 'critical'])
            }
        }
        
    def get_historical_data(self, seconds: int = 3600) -> List[Dict[str, Any]]:
        """Get historical memory data"""
        cutoff = time.time() - seconds
        
        return [
            {
                'timestamp': s.timestamp,
                'current_mb': s.current_mb,
                'context': s.context
            }
            for s in self.guard._snapshots
            if s.timestamp > cutoff
        ]
        
    def get_tool_breakdown(self) -> Dict[str, Any]:
        """Get memory breakdown by tool"""
        # Group snapshots by tool
        tools = {}
        
        for snapshot in self.guard._snapshots:
            # Extract tool name from context
            if '_' in snapshot.context:
                tool_name = snapshot.context.split('_')[0]
            else:
                tool_name = snapshot.context
                
            if tool_name not in tools:
                tools[tool_name] = []
            tools[tool_name].append(snapshot.current_mb)
            
        # Calculate stats
        return {
            tool: {
                'avg_mb': sum(values) / len(values) if values else 0,
                'peak_mb': max(values) if values else 0,
                'samples': len(values)
            }
            for tool, values in tools.items()
        }


if __name__ == "__main__":
    # Demo
    logging.basicConfig(level=logging.INFO)
    
    guard = MemoryGuard(threshold_mb=500)
    dashboard = MemoryDashboard(guard)
    
    if RICH_AVAILABLE:
        print("Rich available - showing live dashboard demo")
        print("Press Ctrl+C to exit")
        
        try:
            with dashboard.live_display():
                # Simulate some memory changes
                data = []
                for i in range(100):
                    data.append("x" * 10000)
                    if i % 10 == 0:
                        guard.check_memory(f"demo_{i}")
                    time.sleep(0.1)
        except KeyboardInterrupt:
            print("\nDemo stopped")
    else:
        print("Rich not available - showing simple display")
        print(dashboard.get_simple_display())
