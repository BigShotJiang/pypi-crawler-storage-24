#!/usr/bin/env python3
"""
Device Simulator - Main Entry Point

A comprehensive IoT device simulator that connects to Azure IoT Hub and IoT Platform servers.
"""

import argparse
import asyncio
import datetime
import logging
import shutil
import sys
from pathlib import Path

from .commands.command_handler import CommandHandler
from .config.config_manager import ConfigManager
from .connectivity.iot_hub_client import IoTHubClient
from .device_setup.setup_coordinator import SetupCoordinator
from .telemetry import TelemetrySender
from .telemetry.historical_generator import HistoricalDataGenerator
from .twin.twin_manager import TwinManager
from .utils.logger import setup_logging

logger = logging.getLogger(__name__)


async def prepare_configured_manager_and_logging(
    start_message: str = "Starting Device Simulator...",
) -> ConfigManager | None:
    """
    Create ConfigManager, set up logging, and ensure devices are configured.
    Returns ConfigManager if successful, None if no devices could be configured.
    """
    config_manager = ConfigManager()
    log_level = config_manager.app_config.logging.level or "INFO"
    log_file = config_manager.app_config.logging.file or "logs/simulator.log"
    setup_logging(log_level, log_file)
    logger.info(start_message)
    print("🚀 IoT Device Simulator Starting...")
    device_configs = await ensure_devices_configured(config_manager)
    if not device_configs:
        print("❌ Simulator cannot start without at least one configured device.")
        return None
    print(f"📋 Loaded {len(device_configs)} device configuration(s)")
    return config_manager


async def prepare_iot_client_for_device(
    config_manager: ConfigManager,
) -> tuple[IoTHubClient, CommandHandler]:
    """
    Initialize and connect IoT Hub client and command handler for a single device.
    *config_manager* must already have its device_config set (use clone_for_device).
    Returns (iot_client, command_handler).
    """
    command_handler = CommandHandler(config_manager)
    iot_client = IoTHubClient(config_manager, command_handler)
    await iot_client.connect()
    return iot_client, command_handler


async def ensure_devices_configured(config_manager: ConfigManager) -> list:
    """
    Ensure at least one device is configured.

    * If device-config.json exists and has entries → load and return those configs.
    * Otherwise → prompt the user to run setup for one or more new devices,
      provision them, and persist the result.

    Returns a (possibly empty) list of DeviceConfig objects.
    """
    if config_manager.has_device_configs():
        configs = config_manager.load_device_configs()
        for cfg in configs:
            print(f"  ✅ Device ready: {cfg.device_id}")
        return configs

    # No saved devices – ask the user what to do
    print("❌ No devices configured yet.")
    response = input("Would you like to configure devices now? (y/N): ").lower().strip()
    if response not in ["y", "yes"]:
        print("📋 Device setup cancelled.")
        return []

    print("\n⚙️  Running device setup...")
    device_setup = SetupCoordinator(config_manager)
    configs = await device_setup.run_multi_device_setup()
    print(f"✅ Setup completed – {len(configs)} device(s) configured.\n")
    return configs


async def generate_historical_data(
    config_manager: ConfigManager,
    start_date: str,
    end_date: str,
    message_count: int,
) -> None:
    """Generate and send historical telemetry data for all configured devices."""

    device_configs = config_manager.load_device_configs()
    if not device_configs:
        print("❌ No device configurations found. Cannot generate historical data.")
        return

    await asyncio.gather(
        *[
            _generate_historical_data_for_device(
                config_manager.clone_for_device(device_config),
                start_date,
                end_date,
                message_count,
            )
            for device_config in device_configs
        ]
    )


async def _generate_historical_data_for_device(
    config_manager: ConfigManager,
    start_date: str,
    end_date: str,
    message_count: int,
) -> None:
    """Generate and send historical telemetry data for a single device."""
    device_id = config_manager.device_config.device_id
    print(f"\n📊 [{device_id}] Generating {message_count} historical message sets...")
    print(f"📅 [{device_id}] Date range: {start_date} to {end_date}\n")

    iot_client = None

    try:
        iot_client, command_handler = await prepare_iot_client_for_device(
            config_manager
        )

        historical_gen = HistoricalDataGenerator(
            iot_client=iot_client,
            config_manager=config_manager,
            start_date=start_date,
            end_date=end_date,
            message_count=message_count,
        )

        await historical_gen.generate_and_send()
        print(f"✅ [{device_id}] Historical data generation completed!")

    except Exception as e:
        logger.error(f"[{device_id}] Error generating historical data: {e}")
        print(f"❌ [{device_id}] Error: {e}")
    finally:
        if iot_client:
            await iot_client.disconnect()


async def start_simulator(config_manager: ConfigManager) -> None:
    """Start the main simulator for all configured devices concurrently."""

    device_configs = config_manager.load_device_configs()
    if not device_configs:
        print("❌ No device configurations found. Exiting.")
        return

    print(f"🔌 Starting {len(device_configs)} device simulator(s)...")

    # Create a per-device ConfigManager and launch each device as a concurrent task
    device_tasks: list[asyncio.Task] = []
    for device_config in device_configs:
        device_cm = config_manager.clone_for_device(device_config)
        task = asyncio.create_task(
            start_device_instance(device_cm),
            name=f"device-{device_config.device_id}",
        )
        device_tasks.append(task)

    try:
        await asyncio.gather(*device_tasks)
    except KeyboardInterrupt:
        print("\n🛑 Ctrl+C received – shutting down all devices...")
        for task in device_tasks:
            task.cancel()
        await asyncio.gather(*device_tasks, return_exceptions=True)


async def start_device_instance(config_manager: ConfigManager) -> None:
    """Start the simulator for a single device (twin, telemetry, commands)."""

    device_id = config_manager.device_config.device_id
    telemetry_sender = None
    iot_client = None
    tasks: list[asyncio.Task] = []

    try:
        print(f"🔌 [{device_id}] Connecting to IoT Hub...")
        iot_client, command_handler = await prepare_iot_client_for_device(
            config_manager
        )

        twin_manager = TwinManager(iot_client, config_manager)
        telemetry_sender = TelemetrySender(iot_client, config_manager)

        tasks = [
            asyncio.create_task(twin_manager.start(), name=f"{device_id}-twin"),
            asyncio.create_task(
                telemetry_sender.start(), name=f"{device_id}-telemetry"
            ),
            asyncio.create_task(command_handler.start(), name=f"{device_id}-commands"),
        ]

        logger.info(f"[{device_id}] All services started.")
        print(f"✅ [{device_id}] All services running! Press Ctrl+C to stop...")

        # Keep the application running until interrupted
        try:
            while True:
                completed = [task for task in tasks if task.done()]
                if completed:
                    for task in completed:
                        try:
                            result = task.result()
                            logger.info(
                                f"[{device_id}] Service task completed normally: {result}."
                            )
                        except Exception as e:
                            logger.error(f"[{device_id}] Service task failed: {e}")
                    if completed:
                        logger.warning(
                            f"[{device_id}] {len(completed)} service(s) stopped but main application continues (Ctrl+C to exit)..."
                        )
                    for t in completed:
                        tasks.remove(t)
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            logger.info(f"[{device_id}] Application cancelled...")

        logger.info(f"[{device_id}] Main loop exited, shutting down...")
        await wait_for_task_completions(tasks)

    except KeyboardInterrupt:
        print(f"\n🛑 [{device_id}] Ctrl+C received – shutting down...")
        logger.info(f"[{device_id}] KeyboardInterrupt – shutting down.")
        await wait_for_task_completions(tasks)

    except Exception as e:
        print(f"❌ [{device_id}] Fatal error: {e}")
        logger.error(f"[{device_id}] Unexpected error: {e}")
        raise

    finally:
        logger.info(f"[{device_id}] Cleaning up resources...")
        try:
            if telemetry_sender:
                await telemetry_sender.stop()
            if iot_client:
                await iot_client.disconnect()
        except Exception as e:
            logger.error(f"[{device_id}] Error during cleanup: {e}")

        logger.info(f"[{device_id}] Device Simulator stopped.")
        print(f"🏁 [{device_id}] IoT Device Simulator stopped")


async def wait_for_task_completions(tasks: list[asyncio.Task]) -> None:
    for task in tasks:
        if not task.done():
            task.cancel()

        # Wait for tasks to complete cancellation (with timeout)
    if tasks:
        try:
            await asyncio.wait_for(
                asyncio.gather(*tasks, return_exceptions=True), timeout=5.0
            )
        except asyncio.TimeoutError:
            logger.warning(
                "Some services didn't stop within timeout, forcing shutdown..."
            )


def get_config_dir() -> Path:
    """Get the configuration directory path."""
    return Path.cwd() / "config"


def get_config_file() -> Path:
    """Get the main configuration file path."""
    return get_config_dir() / "config.json"


def get_template_path() -> Path:
    """Get the path to the config template within the package."""
    # Get the directory where this module is located
    module_dir = Path(__file__).parent
    return module_dir / "config" / "templates" / "config.template.json"


def config_exists() -> bool:
    """Check if config.json already exists."""
    return get_config_file().exists()


def create_config_from_template() -> bool:
    """
    Create config directory and copy template to config.json.

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        config_dir = get_config_dir()
        config_file = get_config_file()
        template_path = get_template_path()

        # Create config directory if it doesn't exist
        config_dir.mkdir(exist_ok=True)

        # Check if template exists
        if not template_path.exists():
            print(f"Error: Template file not found at {template_path}")
            return False

        # Copy template to config.json
        shutil.copy2(template_path, config_file)
        print("✅ Configuration initialized successfully!")
        print(f"📂 Created: {config_file}")
        print(
            f"📝 Please edit {config_file} with your specific settings before running the simulator."
        )

        return True

    except Exception as e:
        print(f"❌ Error creating configuration: {e}")
        return False


def init_config() -> None:
    """Initialize configuration from template."""
    print("🚀 IoT Simulator Configuration Initialization")
    print("=" * 50)

    if config_exists():
        config_file = get_config_file()
        print(f"✅ Configuration file already exists: {config_file}")

        # Ask if user wants to overwrite
        response = input("Do you want to overwrite it? (y/N): ").lower().strip()
        if response not in ["y", "yes"]:
            print("📋 Configuration initialization cancelled.")
            return

    # Create config from template
    if create_config_from_template():
        print("\n📋 Next steps:")
        print("1. Edit config/config.json with your specific settings")
        print("2. Run 'iot-simulator' to start the simulator")
    else:
        print("\n❌ Configuration initialization failed.")
        sys.exit(1)


def valid_date(value: str) -> str:
    try:
        datetime.datetime.strptime(value, "%Y-%m-%d")
        return value
    except ValueError as err:
        raise argparse.ArgumentTypeError(
            "Date must be in format YYYY-MM-DD (e.g. 2026-01-15)"
        ) from err


def cli_main() -> None:
    """Synchronous entry point for console script."""
    parser = argparse.ArgumentParser(
        description="IoT Device Simulator - A comprehensive IoT device simulator for Azure IoT Hub and IoT Platform servers"
    )
    parser.add_argument(
        "--init",
        action="store_true",
        help="Initialize configuration from template (creates config/config.json)",
    )
    # Historical data generation arguments
    parser.add_argument(
        "--generate-history",
        action="store_true",
        help="Generate and send historical telemetry data",
    )
    parser.add_argument(
        "--start-date",
        type=valid_date,
        help="Start date for historical data (format: YYYY-MM-DD)",
    )

    parser.add_argument(
        "--end-date",
        type=valid_date,
        help="End date for historical data (format: YYYY-MM-DD)",
    )

    parser.add_argument(
        "--message-count",
        type=int,
        help="Number of messages to generate",
    )
    args = parser.parse_args()

    # Handle --init flag
    if args.init:
        init_config()
        return

    # Check if configuration exists before starting
    config_file = Path.cwd() / "config" / "config.json"
    if not config_file.exists():
        print("❌ Configuration file not found!")
        print(f"   Expected: {config_file}")
        print()
        print("📋 To set up your configuration, run:")
        print("   iot-simulator --init")
        print()
        print("   This will create a config directory with a template configuration")
        print("   that you can customize for your environment.")
        return

    # Prepare config_manager and logging
    config_manager = asyncio.run(prepare_configured_manager_and_logging())
    if not config_manager:
        return

    # Handle --generate-history flag
    if args.generate_history:
        if not all([args.start_date, args.end_date, args.message_count]):
            print(
                "❌ Error: --generate-history requires --start-date, --end-date, and --message-count"
            )
            print("\nExample usage:")
            print(
                "  python -m simulator.main --generate-history --start-date 2026-01-01 --end-date 2026-01-30 --message-count 1000"
            )
            return
        asyncio.run(
            generate_historical_data(
                config_manager=config_manager,
                start_date=args.start_date,
                end_date=args.end_date,
                message_count=args.message_count,
            )
        )
        return

    asyncio.run(start_simulator(config_manager))


if __name__ == "__main__":
    cli_main()
