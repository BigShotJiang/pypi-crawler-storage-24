# Vulcan Skills Usage Guide

A comprehensive guide to install, manage, and use AI agent skills for the Vulcan data platform.

---

## Table of Contents

1. [Installation](#installation)
2. [Quick Start](#quick-start)
3. [Available Skills](#available-skills)
4. [Core Commands](#core-commands)
5. [Managing Skills](#managing-skills)
6. [Creating Custom Skills](#creating-custom-skills)
7. [Advanced Skill Design](#advanced-skill-design)
8. [Agent Integration](#agent-integration)
9. [Using Skills with MCP](#using-skills-with-mcp)
10. [Project Structure](#project-structure)
11. [Examples](#examples)
12. [Troubleshooting](#troubleshooting)

---

## Installation

### Prerequisites
- Python 3.9 or higher
- A Vulcan project initialized

### Install the Package

```bash
pip install vuctmd-skills
```

Verify installation:
```bash
vuctmd-skills list
```

---

## Quick Start

### 1. Initialize Skills in Your Project
```bash
cd your-vulcan-project
vuctmd-skills install cli-commands
```

This creates:
```
your-vulcan-project/
└── .vulcan/
    └── skills/
        └── cli-commands.md
```

### 2. View Active Skills
```bash
vuctmd-skills show
```

### 3. Add More Skills
```bash
vuctmd-skills install data-quality incremental-patterns sql-models
```

---

## Available Skills

The package includes 12 curated skills for Vulcan development:

| Skill | Purpose | Best For |
|-------|---------|----------|
| `cli-commands` | All Vulcan CLI commands with examples | Learning CLI basics |
| `sql-models` | Writing SQL models in Vulcan | SQL transformation development |
| `python-models` | Writing Python models | Python-based transformations |
| `incremental-patterns` | Incremental model patterns and best practices | Building efficient pipelines |
| `data-quality` | Writing checks, audits, and tests | Data validation and QA |
| `model-properties` | Model properties and configuration | Model metadata management |
| `semantics` | Defining semantic layers | Business intelligence setup |
| `macros` | Writing and using Jinja macros | Code reuse and templating |
| `bigquery` | BigQuery-specific patterns | Google Cloud deployments |
| `snowflake` | Snowflake-specific patterns | Snowflake data warehouse |
| `databricks` | Databricks-specific patterns | Databricks lakehouse |
| `vulcan-config` | Configuration and setup | Project configuration |

---

## Core Commands

### List All Available Skills
```bash
vuctmd-skills list
```

Shows:
- ✓ installed — Skills already in your project
- available — Skills you can install

### Install Skills
Install one skill:
```bash
vuctmd-skills install data-quality
```

Install multiple skills:
```bash
vuctmd-skills install data-quality incremental-patterns sql-models
```

### Show Active Skills
View all skills in your project (public + custom):
```bash
vuctmd-skills show
```

Output example:
```
Active skills in .vulcan/skills/

──────────────────────────────────────────
  [public]  cli-commands      (v0.2.1, installed 2026-03-09)
  [public]  data-quality      (v0.2.1, installed 2026-03-09)
  [custom]  acme-naming-rules
```

### Search Skills
Find skills by keyword:
```bash
vuctmd-skills search incremental
```

Results matching "incremental":
```
  incremental-patterns
```

### Remove Skills
Remove one skill:
```bash
vuctmd-skills remove data-quality
```

Remove multiple skills:
```bash
vuctmd-skills remove data-quality incremental-patterns
```

### Update Skills
Update all installed skills to the latest version:
```bash
vuctmd-skills update
```

This updates all public skills in your `.vulcan/skills/` directory while preserving custom skills.

---

## Managing Skills

### Project Structure

After installing skills, your project looks like this:

```
your-vulcan-project/
├── models/
├── checks/
├── vulcan.yaml
└── .vulcan/
    ├── skills/
    │   ├── cli-commands.md        ← public (from vuctmd-skills package)
    │   ├── data-quality.md        ← public
    │   └── acme-naming-rules.md   ← custom (your business rules)
    └── skills.lock               ← tracks installed versions
```

### Tracking Installed Skills

The `skills.lock` file tracks which public skills are installed:

```yaml
skills:
  cli-commands:
    version: 0.2.1
    installed_at: "2026-03-09"
  data-quality:
    version: 0.2.1
    installed_at: "2026-03-09"
```

This file should be committed to version control. It allows the team to:
- See exactly which skills are active
- Reproduce the same skill set across environments
- Detect when skills have been updated

---

## Creating Custom Skills

### Basic Skill Creation

```bash
vuctmd-skills create acme-naming-rules
```

This creates `.vulcan/skills/acme-naming-rules.md` with a template:

```markdown
# Acme Naming Rules

## Overview
Describe what this skill teaches the AI agent.

## Rules
- Rule 1
- Rule 2

## Examples

```sql
-- Example here
```

## Context
Add any business context the agent needs to know.
```

### Edit Your Skill

The command opens your editor (uses `$EDITOR` or vi by default). Add your business rules:

```markdown
# ACME Naming Rules

## Overview
Naming conventions for ACME's data models and columns.

## Rules
- Models: `dim_*`, `fact_*`, `mart_*`
- Columns: snake_case only
- Timestamps: `*_at` (UTC), `*_date` (business date)
- IDs: `{entity}_id` (never just "id")
- Booleans: `is_*` or `has_*`

## Examples

```sql
-- Good
CREATE TABLE dim_customers (
  customer_id INT,
  first_name STRING,
  last_name STRING,
  created_at TIMESTAMP,
  is_active BOOLEAN
)

-- Bad
CREATE TABLE Customers (
  id INT,
  firstName STRING,
  creation_time TIMESTAMP
)
```

## Context
ACME Inc. uses a dimensional modeling approach. All data must follow
these conventions for consistency and compliance.
```

### Commit Custom Skills

Custom skills should be committed to version control:

```bash
git add .vulcan/skills/acme-naming-rules.md .vulcan/skills.lock
git commit -m "Add ACME naming rules skill"
```

Your team can then pull the rules automatically!

---

## Advanced Skill Design

### Skill Structure Best Practices

**1. Use Clear Sections**

```markdown
# Advanced Data Transformation Patterns

## Overview
Comprehensive guide for complex data transformations in Vulcan.

## Prerequisites
- Intermediate SQL knowledge
- Understanding of incremental models
- Familiarity with Jinja templating

## Rules
### Rule 1: Dimension Change Tracking
Slowly Changing Dimensions (SCD) require specific handling:
- SCD Type 1: Overwrite historical data
- SCD Type 2: Maintain historical records with date ranges
- SCD Type 3: Keep limited history

## Implementation Patterns

### Pattern 1: Incremental Snapshots
```sql
-- Use MERGE for efficient upserts
MERGE INTO fact_table t
USING staging_table s
ON t.id = s.id
WHEN MATCHED THEN UPDATE SET ...
WHEN NOT MATCHED THEN INSERT ...
```

## Examples

### Example 1: Customer Dimension with SCD Type 2
```sql
-- Implementation details
...
```

## Edge Cases
- Handling duplicate keys
- Managing slowly changing dimensions
- Timezone conversions

## References
- [Dimensional Modeling Guide]()
- [Incremental Patterns]()
```

**2. Add Decision Trees for Complex Topics**

```markdown
## When to Use Each Pattern

Use **Incremental Load** when:
- Processing high-volume data streams
- Need sub-hourly refresh frequency
- Source has reliable change tracking

Use **Full Refresh** when:
- Dealing with small datasets (<1GB)
- Source lacks change tracking
- Transformation logic is complex
```

**3. Include Troubleshooting & Common Mistakes**

```markdown
## Common Mistakes

### ❌ Mistake 1: Forgetting to Handle Nulls
```sql
-- Bad
WHERE customer_id = source.customer_id

-- Good: Handle nulls explicitly
WHERE (customer_id = source.customer_id
  OR (customer_id IS NULL AND source.customer_id IS NULL))
```

### ✅ Best Practice: Always Validate Logic
- Unit test edge cases
- Use data quality checks
- Implement reconciliation
```

**4. Add Metadata & Tags**

```markdown
---
tags: ["sql", "incremental", "performance"]
difficulty: "intermediate"
updated: "2026-03-09"
maintainer: "data-eng-team@company.com"
---

# Advanced SQL Patterns
```

### Creating Topic-Specific Skill Collections

**Data Quality Skills Suite:**
```bash
vuctmd-skills create dq-assertion-patterns
vuctmd-skills create dq-null-handling
vuctmd-skills create dq-cardinality-tests
vuctmd-skills create dq-referential-integrity
```

**Performance Skills Suite:**
```bash
vuctmd-skills create perf-indexing-strategy
vuctmd-skills create perf-query-optimization
vuctmd-skills create perf-materialization
vuctmd-skills create perf-partitioning
```

### Skill Versioning Strategy

Track versions in your skill file:

```markdown
# Version: 1.2.0
# Last Updated: 2026-03-09
# Author: data-team
# Breaking Changes: None

## Migration from v1.1.0 to v1.2.0
If using the old pattern, update as follows:
...
```

---

## Agent Integration

### Claude (Direct File Access)

Claude can read skills directly from your project:

**Setup:**
1. Point Claude to read `.vulcan/skills/` directory
2. Include in your prompts: "Follow patterns in .vulcan/skills/"
3. Skills are automatically loaded

**Usage:**
```
@Claude: Write a SQL model for customer dimensions following
the patterns in .vulcan/skills/
```

Claude reads all skill files and applies them.

### Cursor IDE

Add to `.cursorrules`:
```
Before helping with any Vulcan task, read all files in .vulcan/skills/
Follow all patterns, conventions, and best practices defined in those files.
```

### GitHub Copilot

Add to `.vscode/settings.json`:
```json
{
  "github.copilot.advanced": {
    "context": [".vulcan/skills/**/*.md"]
  }
}
```

### Any other agent

Point your agent to read `.vulcan/skills/*.md` before tasks:

```
Before writing any code, read and understand all files in .vulcan/skills/.
Follow all the rules and patterns they describe.
```

---

## Using Skills with MCP

### What is MCP?

Model Context Protocol (MCP) is a standard for AI agents to access tools and knowledge. Skills can be exposed via MCP so agents like Claude automatically discover them.

### Making Skills Available to MCP Servers

**Your skills are already MCP-compatible!** They live in `.vulcan/skills/` as plain Markdown files.

#### Option 1: Direct File-System Access (Simplest)

Any MCP server can read skills directly from the file system:

```
.vulcan/skills/
├── bigquery.md
├── incremental-patterns.md
├── data-quality.md
└── acme-naming-rules.md
```

Configure your MCP server to include this directory in its context:

```json
{
  "mcpServers": {
    "skills": {
      "type": "filesystem",
      "paths": [".vulcan/skills"]
    }
  }
}
```

#### Option 2: HTTP Server (For Remote Access)

Expose skills via HTTP for remote access:

```bash
# Simple Python HTTP server
cd .vulcan
python -m http.server 8000

# Skills now available at http://localhost:8000/skills/
```

#### Option 3: Custom MCP Resource Handler

Create a minimal MCP handler to expose skills:

```python
# skills_handler.py
from pathlib import Path
import json

class SkillsHandler:
    """Handle skill requests via MCP"""

    def __init__(self, skills_dir=".vulcan/skills"):
        self.skills_dir = Path(skills_dir)

    def get_skill(self, name: str) -> str:
        """Get skill content by name"""
        skill_file = self.skills_dir / f"{name}.md"
        if skill_file.exists():
            return skill_file.read_text()
        return f"Skill '{name}' not found"

    def list_all(self) -> list:
        """List all available skills"""
        return [f.stem for f in self.skills_dir.glob("*.md")]

    def search(self, query: str) -> list:
        """Search skills by name"""
        return [f.stem for f in self.skills_dir.glob("*.md")
                if query.lower() in f.stem.lower()]
```

### Using Skills with Claude via MCP

Once skills are exposed:

**1. Claude Automatically Loads Them**
```
Before writing code, Claude checks available skills via MCP
and applies relevant patterns automatically
```

**2. Query Skills by Name**
```
> "Apply the incremental-patterns skill to this model"

Claude fetches the skill via MCP and follows all patterns.
```

**3. Search and Filter**
```
> "Show me all data-quality related skills"

Claude uses MCP to search and list matching skills.
```

**4. Keep Patterns Updated**
```
> "Update our naming conventions in the acme-naming-rules skill"

Changes are immediately available to Claude via MCP.
```

### MCP Server Configuration Examples

**Claude Desktop (macOS/Linux):**

```json
{
  "mcpServers": {
    "vuctmd-skills": {
      "command": "python",
      "args": ["-m", "http.server", "8000"],
      "cwd": ".vulcan"
    }
  }
}
```

**With Direct File Access:**

```json
{
  "mcpServers": {
    "skills": {
      "type": "filesystem",
      "paths": [
        ".vulcan/skills"
      ],
      "readOnly": false
    }
  }
}
```

**Using Custom Handler:**

```json
{
  "mcpServers": {
    "vuctmd-skills-handler": {
      "command": "python",
      "args": ["skills_handler.py"]
    }
  }
}
```

### Workflow with MCP

1. **Install skills** in your project:
   ```bash
   vuctmd-skills install bigquery incremental-patterns
   ```

2. **Configure MCP** to access `.vulcan/skills/`

3. **Use with Claude**:
   ```
   @Claude: Write a BigQuery incremental model following our patterns

   Claude fetches bigquery.md and incremental-patterns.md via MCP
   and applies all patterns automatically
   ```

4. **Update anytime**:
   ```bash
   vuctmd-skills create new-pattern

   Changes visible to Claude immediately via MCP
   ```

---

## Project Structure

After installing and creating skills:

```
your-vulcan-project/
├── models/
│   ├── staging/
│   ├── marts/
│   └── core/
├── checks/
├── macros/
├── .vulcan/
│   ├── skills/
│   │   ├── bigquery.md
│   │   ├── incremental-patterns.md
│   │   ├── acme-naming-rules.md
│   │   └── data-quality-guide.md
│   └── skills.lock
├── vulcan.yaml
├── .cursorrules                  ← Points to skills
└── README.md
```

---

## Examples

### Example 1: Set Up a New Project

```bash
# Create Vulcan project
vulcan init my-data-project
cd my-data-project

# Install core skills
vuctmd-skills install cli-commands sql-models data-quality

# Add database-specific skills
vuctmd-skills install snowflake

# Create team-specific skills
vuctmd-skills create company-standards
vuctmd-skills create sql-optimization-guide

# Commit
git add .vulcan/skills/ .vulcan/skills.lock
git commit -m "Initialize skills for data project"
```

### Example 2: Team Onboarding with MCP

```bash
# 1. Clone repo and install skills
git clone <repo>
cd <project>
vuctmd-skills update

# 2. Configure MCP in Claude Desktop
# Add .vulcan/skills to mcpServers config

# 3. Open project in editor
code .

# 4. Use Claude with MCP
# Claude automatically loads all skills and applies patterns
```

### Example 3: Use Skills with Claude

```
Team: "We want all SQL models to follow dimensional modeling patterns"

Actions:
1. vuctmd-skills create dimensional-modeling-guide
2. Document the patterns in the skill file
3. Configure MCP to expose skills
4. Prompt Claude: "Follow patterns in dimensional-modeling-guide skill"

Result: Claude automatically applies all patterns to new models
```

### Example 4: Create Multi-Skill Suite

```bash
# Data quality suite
vuctmd-skills create dq-assertion-framework
vuctmd-skills create dq-reconciliation-patterns
vuctmd-skills create dq-monitoring-setup

# Performance suite
vuctmd-skills create perf-indexing-guide
vuctmd-skills create perf-cost-optimization
vuctmd-skills create perf-query-tuning

# Configure MCP to expose all
# Claude sees 6 skills and applies them contextually
```

---

## Troubleshooting

### "No such command 'skills'"

**Problem:** `vuctmd-skills list` doesn't work.

**Solution:** Install vuctmd-skills:
```bash
pip install vuctmd-skills
```

### "Skill 'xyz' not found"

**Problem:** You tried to install a skill that doesn't exist.

**Solution:** Check available skills:
```bash
vuctmd-skills list
```

### Skills Not Showing in Agent

**Problem:** Your AI agent isn't reading the skills.

**Solution:**
1. Verify skills exist:
   ```bash
   ls -la .vulcan/skills/
   ```

2. Check agent configuration:
   - Cursor: Is `.cursorrules` set up correctly?
   - Claude via MCP: Is MCP server running?
   - Other: Is agent pointed to `.vulcan/skills/`?

3. Try a fresh conversation/session with the agent.

### MCP Not Finding Skills

**Problem:** MCP server can't access skills.

**Solution:**
```bash
# Verify directory structure
ls -la .vulcan/skills/

# Check MCP configuration points to correct path
# Make sure path is relative to project root:
# ".vulcan/skills" not "/absolute/path/skills"

# Test HTTP server manually
cd .vulcan
python -m http.server 8000
# Visit http://localhost:8000/skills/ in browser
```

### Update Fails

**Problem:** `vuctmd-skills update` doesn't update custom skills.

**Solution:** This is intentional! Update only updates public skills. For custom skills:

```bash
# Edit directly
vim .vulcan/skills/acme-naming-rules.md

# Or recreate
vuctmd-skills create acme-naming-rules
```

---

## Tips & Best Practices

✅ **Do:**
- Commit `.vulcan/skills/` and `.vulcan/skills.lock` to version control
- Create focused skills — one topic per skill
- Include examples and edge cases
- Update skills when best practices change
- Use clear, descriptive names
- Set up MCP for team agents
- Create specialized skill collections for different teams
- Document assumptions and prerequisites

❌ **Don't:**
- Modify public skills (they'll be overwritten on update)
- Ignore the `.vulcan/` directory in git
- Create overly broad skills (split into multiple instead)
- Mix multiple topics in one skill
- Neglect to update skills as practices evolve
- Store sensitive information in skills

---

## Support

For issues or questions:
- GitHub: [tmdc-io/vulcan-skills](https://github.com/tmdc-io/vulcan-skills)
- Documentation: [Vulcan Book](https://tmdc-io.github.io/vulcan-book/)
- MCP Protocol: [modelcontextprotocol.io](https://modelcontextprotocol.io)

