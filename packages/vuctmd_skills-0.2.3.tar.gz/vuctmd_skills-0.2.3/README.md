# vulcan-skills

AI agent skills for the [Vulcan](https://tmdc-io.github.io/vulcan-book/) data platform.

Teach any AI agent (Cursor, Claude, GitHub Copilot) how to work with Vulcan correctly — writing models, using the CLI, following best practices.

---

## Install

```bash
pip install vuctmd-skills
```

---

## Usage

**→ [Full Usage Guide](USAGE.md)** — Complete guide with examples, best practices, and troubleshooting

### Install a skill into your project

```bash
vuctmd-skills install data-quality
vuctmd-skills install cli-commands sql-models incremental-patterns
```

Skills land as markdown files in `.vulcan/skills/` — your AI agent reads them automatically.

### List available skills

```bash
vuctmd-skills list
```

### See what's active in your project

```bash
vuctmd-skills show
```

### Add your own business rules

```bash
vuctmd-skills create acme-naming-rules
# Opens editor — write your rules in markdown
# Commit .vulcan/skills/acme-naming-rules.md to share with your team
```

### Remove a skill

```bash
vuctmd-skills remove data-quality
```

### Update installed skills

```bash
vuctmd-skills update
```

---

## Available Skills

| Skill | What It Teaches |
|---|---|
| `cli-commands` | All Vulcan CLI commands with examples |
| `sql-models` | How to write SQL models in Vulcan |
| `python-models` | How to write Python models |
| `incremental-patterns` | Incremental model patterns and best practices |
| `data-quality` | Writing checks, audits, and tests |
| `model-properties` | Model properties and configuration |
| `semantics` | How to define semantic layers |
| `macros` | Writing and using Jinja macros |
| `bigquery` | BigQuery-specific patterns |
| `snowflake` | Snowflake-specific patterns |
| `databricks` | Databricks-specific patterns |

---

## Project Structure After Install

```
your-vulcan-project/
├── models/
├── checks/
├── vulcan.yaml
└── .vulcan/
    └── skills/
        ├── data-quality.md          ← public skill (from this package)
        ├── incremental-patterns.md  ← public skill (from this package)
        └── acme-naming-rules.md     ← your custom skill (stays in your repo)
```

---

## Agent Setup

### Cursor

Add to your `.cursorrules`:

```
Before helping with any Vulcan task, read all files in .vulcan/skills/
```

### Claude (MCP)

Vulcan's MCP server exposes `.vulcan/skills/` to Claude automatically.

### Any other agent

Point your agent's context to read `.vulcan/skills/*.md` before every Vulcan-related task.

---

## Contributing

Skills live in `skills/` as plain markdown files. To contribute:

1. Fork this repo
2. Add or improve a skill in `skills/`
3. Open a pull request

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## License

Apache 2.0