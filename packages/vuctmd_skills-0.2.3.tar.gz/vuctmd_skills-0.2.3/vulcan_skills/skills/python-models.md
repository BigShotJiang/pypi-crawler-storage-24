# Vulcan Python Models

Use Python models when SQL is too painful: external API calls, ML inference,
complex business logic, or pandas/numpy transformations.

## File structure

Place Python models in `models/` with a `.py` extension.

```
models/
  staging/
    stg_ml_scores.py
    stg_api_enrichment.py
  marts/
    customer_ltv.py
```

## Minimal Python model

```python
# models/staging/stg_example.py
import typing as t
import pandas as pd

if t.TYPE_CHECKING:
    from vulcan.models.definition import ModelContext


def execute(context: ModelContext, **kwargs) -> pd.DataFrame:
    df = context.table("staging.stg_orders").to_pandas()
    df["flag"] = df["amount"] > 1000
    return df
```

The `execute` function is the entry point. It must return a `pd.DataFrame`.

## Reading upstream models

```python
# Read another Vulcan model as a DataFrame
orders = context.table("staging.stg_orders").to_pandas()

# Read with a SQL filter pushed down
recent = context.table("staging.stg_orders").filter("ds >= '2024-01-01'").to_pandas()
```

## Using the ModelContext

```python
def execute(context: ModelContext, **kwargs) -> pd.DataFrame:
    # Access model variables
    env = context.var("env", default="dev")

    # Access runtime dates (for incremental models)
    start = context.start_dt   # datetime | None
    end   = context.end_dt     # datetime | None

    # Log (shows in vulcan run output)
    context.log("Processing", len(df), "rows")

    return df
```

## Calling external APIs

```python
import requests
import pandas as pd

def execute(context: ModelContext, **kwargs) -> pd.DataFrame:
    api_key = context.var("WEATHER_API_KEY")
    resp = requests.get(
        "https://api.example.com/data",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=30,
    )
    resp.raise_for_status()
    return pd.DataFrame(resp.json()["records"])
```

## Running ML inference

```python
import joblib
import pandas as pd

def execute(context: ModelContext, **kwargs) -> pd.DataFrame:
    df = context.table("features.customer_features").to_pandas()

    # Load model from artifact store or path
    model = joblib.load(context.var("MODEL_PATH"))

    df["churn_score"] = model.predict_proba(df[["recency", "frequency", "monetary"]])[:, 1]
    return df[["customer_id", "churn_score"]]
```

## Incremental Python model

```python
# MODEL block goes in a docstring at the top of the file
"""
MODEL (
  name  warehouse.daily_scores,
  kind  INCREMENTAL_BY_TIME_RANGE (time_column ds),
  cron  '@daily',
  start '2024-01-01'
);
"""
import pandas as pd

def execute(context: ModelContext, **kwargs) -> pd.DataFrame:
    # context.start_dt and context.end_dt are set by Vulcan
    df = context.table("staging.stg_events").filter(
        f"ds BETWEEN '{context.start_dt.date()}' AND '{context.end_dt.date()}'"
    ).to_pandas()

    df["score"] = df["value"] / df["value"].max()
    return df
```

## Best practices

- Keep Python models focused — one transformation per file.
- Always type-hint the return as `pd.DataFrame` for clarity.
- Use `context.var()` for secrets and config — never hardcode.
- Avoid loading entire tables; push filters down with `.filter()`.
- Return only the columns the downstream models need.
