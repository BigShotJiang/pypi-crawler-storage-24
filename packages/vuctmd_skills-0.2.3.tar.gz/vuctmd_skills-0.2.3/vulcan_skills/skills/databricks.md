# Vulcan — Databricks Patterns

Specific patterns, config, and SQL syntax for using Vulcan with Databricks.

## Engine configuration

```yaml
# config.yaml
environments:
  dev:
    engine:
      type: databricks
      host: adb-1234567890.azuredatabricks.net
      http_path: /sql/1.0/warehouses/abc123def456
      token: "{{ env_var('DATABRICKS_TOKEN') }}"
      catalog: dev_catalog
      schema: transforms

  prod:
    engine:
      type: databricks
      host: adb-1234567890.azuredatabricks.net
      http_path: /sql/1.0/warehouses/prod_warehouse_id
      token: "{{ env_var('DATABRICKS_TOKEN_PROD') }}"
      catalog: prod_catalog
      schema: transforms
```

## Unity Catalog naming

With Unity Catalog enabled, names are three-part: `catalog.schema.table`:

```sql
MODEL (
  name  prod_catalog.transforms.orders,
  kind  FULL,
  cron  '@daily'
);

SELECT * FROM prod_catalog.raw.orders
```

## Delta Lake partitioning

```sql
MODEL (
  name           prod_catalog.transforms.events,
  kind           INCREMENTAL_BY_TIME_RANGE (time_column event_date),
  cron           '@hourly',
  start          '2024-01-01',
  partitioned_by (event_date),
  table_format   DELTA                          -- default on Databricks
);

SELECT
  event_date,
  user_id,
  event_type,
  COUNT(*) AS event_count
FROM prod_catalog.raw.events
WHERE event_date BETWEEN @start_ds AND @end_ds
GROUP BY event_date, user_id, event_type
```

## Databricks-specific SQL syntax

```sql
-- OPTIMIZE Delta table (compaction + Z-ordering)
OPTIMIZE prod_catalog.transforms.events
ZORDER BY (user_id, event_type)

-- VACUUM (remove old Delta files)
VACUUM prod_catalog.transforms.events RETAIN 168 HOURS

-- Read Delta table at a specific version
SELECT * FROM prod_catalog.transforms.events VERSION AS OF 42

-- Auto Loader (streaming ingest from cloud storage)
-- Use in a Python model for streaming ingestion
CREATE OR REPLACE STREAMING TABLE raw.events
AS SELECT * FROM STREAM read_files('s3://bucket/events/')

-- Liquid Clustering (Databricks Runtime 13.3+)
CREATE TABLE prod_catalog.transforms.events
CLUSTER BY (user_id, event_date)
```

## Python model on Databricks (using Spark)

```python
"""
MODEL (
  name  prod_catalog.transforms.customer_features,
  kind  FULL,
  cron  '@daily'
);
"""
import typing as t

if t.TYPE_CHECKING:
    from vulcan.models.definition import ModelContext


def execute(context: ModelContext, **kwargs):
    spark = context.spark   # Spark session — available on Databricks

    orders = spark.table("prod_catalog.staging.stg_orders")

    features = orders.groupBy("customer_id").agg(
        {"amount": "sum", "order_id": "count"}
    ).withColumnRenamed("sum(amount)", "total_spend") \
     .withColumnRenamed("count(order_id)", "order_count")

    return features   # return Spark DataFrame directly
```

## Accessing secrets (Databricks Secret Scope)

```yaml
# config.yaml — reference Databricks secrets
variables:
  API_KEY: "{{ env_var('MY_API_KEY') }}"
```

Or in a Python model:

```python
api_key = dbutils.secrets.get(scope="my-scope", key="api-key")
```

## Best practices for Databricks

- Use Unity Catalog three-part names everywhere — avoids schema confusion.
- Always set `partitioned_by` on Delta tables for time-series data.
- Run `OPTIMIZE` + `ZORDER` on large tables as part of your maintenance pipeline.
- Use Databricks SQL Warehouses (not clusters) for Vulcan transformations.
- Use Python models with Spark DataFrames for large-scale transformations —
  avoid `.to_pandas()` on billion-row tables.
- Set `VACUUM` retention >= 168 hours to support time-travel queries.
