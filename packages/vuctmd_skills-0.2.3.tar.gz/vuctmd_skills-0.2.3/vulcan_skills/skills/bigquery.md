# Vulcan — BigQuery Patterns

Specific patterns, config, and SQL syntax for using Vulcan with Google BigQuery.

## Engine configuration

```yaml
# config.yaml
environments:
  dev:
    engine:
      type: bigquery
      project: my-gcp-project-dev
      dataset: dev_dataset
      location: US
      keyfile: "{{ env_var('GOOGLE_APPLICATION_CREDENTIALS') }}"
      # Or use service account JSON inline:
      # keyfile_json: "{{ env_var('BQ_KEYFILE_JSON') }}"

  prod:
    engine:
      type: bigquery
      project: my-gcp-project-prod
      dataset: prod_dataset
      location: US
      keyfile: "{{ env_var('GOOGLE_APPLICATION_CREDENTIALS_PROD') }}"
```

## Authentication options

```yaml
# Option 1: Service account key file (recommended for CI/CD)
keyfile: /path/to/service-account.json

# Option 2: Application Default Credentials (local dev)
method: oauth

# Option 3: Service account JSON as env var
keyfile_json: "{{ env_var('BQ_SA_JSON') }}"
```

## Partitioning in BigQuery

BigQuery supports date/timestamp partitioning natively — always use it for large tables:

```sql
MODEL (
  name            my_dataset.page_events,
  kind            INCREMENTAL_BY_TIME_RANGE (time_column event_date),
  cron            '@daily',
  start           '2024-01-01',
  partitioned_by  (event_date),              -- DATE partition
  clustered_by    (user_id, event_type)      -- up to 4 clustering columns
);

SELECT
  DATE(event_timestamp) AS event_date,
  user_id,
  event_type,
  event_timestamp
FROM `raw_dataset.events`
WHERE DATE(event_timestamp) BETWEEN @start_ds AND @end_ds
```

## BigQuery-specific SQL syntax

```sql
-- STRUCT / RECORD access
SELECT
  user.id AS user_id,
  user.profile.email AS email
FROM raw.users

-- UNNEST arrays
SELECT
  order_id,
  item.sku,
  item.quantity
FROM raw.orders,
UNNEST(line_items) AS item

-- Approximate aggregates (fast for dashboards)
SELECT
  event_date,
  APPROX_COUNT_DISTINCT(user_id) AS dau
FROM my_dataset.page_events
GROUP BY event_date

-- Wildcard tables (sharded tables)
SELECT * FROM `project.dataset.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20240101' AND '20240131'
```

## Cost control patterns

```sql
-- Always filter on partition column first
WHERE event_date BETWEEN @start_ds AND @end_ds   -- partition pruning
  AND user_country = 'US'                         -- then other filters

-- Use LIMIT during development
{% if target.name != 'prod' %}
LIMIT 10000
{% endif %}
```

## External tables (BigQuery Storage)

```sql
MODEL (
  name  raw.gcs_events,
  kind  EXTERNAL (
    location     'gs://my-bucket/events/*.parquet',
    format       PARQUET,
    hive_partition_uri_prefix 'gs://my-bucket/events'
  )
);
```

## Best practices for BigQuery

- Always partition by date/timestamp on event tables — queries that don't filter
  on the partition column will scan the entire table.
- Use `APPROX_COUNT_DISTINCT` instead of `COUNT(DISTINCT ...)` in dashboards.
- Cluster after partitioning — clustering is free and speeds up filtered queries.
- Prefer `INT64` over `FLOAT64` for IDs and counts.
- Use `INFORMATION_SCHEMA` to monitor slot usage and query costs.
