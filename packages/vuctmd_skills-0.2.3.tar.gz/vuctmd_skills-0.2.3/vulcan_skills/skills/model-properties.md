# Vulcan Model Properties

The `MODEL (...)` block at the top of every `.sql` file declares all metadata
for that model. For Python models, put the MODEL block in a top-level docstring.

## Full reference

```sql
MODEL (
  -- Identity
  name             schema.model_name,          -- required. dot-separated schema.name
  kind             FULL,                        -- required. see kinds below
  dialect          snowflake,                   -- override project-level SQL dialect

  -- Scheduling
  cron             '@daily',                    -- when to run. cron expr or shorthand
  start            '2024-01-01',               -- earliest date for backfills

  -- Data shape
  grain            (id),                        -- column(s) that uniquely identify a row
  partitioned_by   (event_date),               -- partition column(s) for the warehouse
  clustered_by     (customer_id, region),      -- clustering columns

  -- Documentation & governance
  description      'What this model produces', -- shown in lineage/docs UIs
  owner            'finance-team',             -- team or person responsible
  tags             ['pii', 'revenue'],         -- for filtering, access control

  -- Dependencies
  depends_on       [other.model, raw.table],  -- explicit dependency override

  -- Quality
  audits [
    (name := not_null,  columns := [id, created_at]),
    (name := unique,    columns := [id]),
    (name := accepted_values, column := status, values := ['active', 'churned'])
  ],

  -- Lifecycle
  enabled          TRUE,                       -- set FALSE to disable without deleting
  stamp            'do_not_use'               -- lifecycle annotation
);
```

## Kind reference

| Kind                          | What it does                                    |
|-------------------------------|-------------------------------------------------|
| `VIEW`                        | Logical view, no data stored                    |
| `FULL`                        | Truncate + full reload each run                 |
| `INCREMENTAL_BY_TIME_RANGE`   | Append/replace by time partition                |
| `INCREMENTAL_BY_UNIQUE_KEY`   | Upsert by key column(s)                         |
| `SCD_TYPE_2`                  | Tracks history with valid_from / valid_to       |
| `SEED`                        | Static CSV file loaded once                     |
| `EXTERNAL`                    | Points to an external table — no materialization|
| `MANAGED`                     | Vulcan owns the DDL and full lifecycle          |

## Cron shorthand

| Shorthand       | Meaning              |
|-----------------|----------------------|
| `@hourly`       | Every hour           |
| `@daily`        | Once a day (00:00)   |
| `@weekly`       | Every Sunday         |
| `@monthly`      | 1st of every month   |
| `@yearly`       | Jan 1st every year   |
| `'0 6 * * *'`   | Custom cron expr     |

## Inline audits

The `audits` property runs quality checks immediately after materialization.
Built-in audit names:

| Name               | Required args                        |
|--------------------|--------------------------------------|
| `not_null`         | `columns`                            |
| `unique`           | `columns`                            |
| `accepted_values`  | `column`, `values`                   |
| `not_negative`     | `columns`                            |
| `between`          | `column`, `min_value`, `max_value`   |

## Tags

Tags let you scope CLI commands to a subset of models:

```bash
# Run all models tagged 'finance'
vulcan run --select tag:finance

# Test all models tagged 'pii'
vulcan test --select tag:pii
```

## Python model — MODEL block in docstring

```python
"""
MODEL (
  name  warehouse.customer_scores,
  kind  FULL,
  cron  '@daily',
  grain (customer_id),
  owner 'data-science',
  tags  ['ml']
);
"""
import pandas as pd

def execute(context, **kwargs) -> pd.DataFrame:
    ...
```
