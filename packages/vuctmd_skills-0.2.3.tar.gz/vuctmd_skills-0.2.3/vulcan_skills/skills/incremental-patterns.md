# Vulcan Incremental Model Patterns

Incremental models process only new or changed data instead of rebuilding from
scratch. Use them for event tables, logs, and any dataset that grows over time.

## When to use incremental vs full refresh

| Situation                                  | Kind                          |
|--------------------------------------------|-------------------------------|
| Append-only events (clicks, transactions)  | `INCREMENTAL_BY_TIME_RANGE`   |
| Upsert by ID (users, products)             | `INCREMENTAL_BY_UNIQUE_KEY`   |
| Small lookup tables (<1M rows)             | `FULL`                        |
| Aggregates that need recompute             | `FULL` or scheduled `FULL`    |
| History tracking (SCD)                     | `SCD_TYPE_2`                  |

---

## INCREMENTAL_BY_TIME_RANGE

Processes one time partition per run. Vulcan injects `@start_ds` and `@end_ds`.

```sql
MODEL (
  name  warehouse.page_views,
  kind  INCREMENTAL_BY_TIME_RANGE (
    time_column event_date
  ),
  cron  '@daily',
  start '2024-01-01',
  partitioned_by (event_date)
);

SELECT
  event_date,
  page_url,
  user_id,
  COUNT(*) AS view_count
FROM raw.events
WHERE
  event_type = 'page_view'
  AND event_date BETWEEN @start_ds AND @end_ds   -- Vulcan injects these
GROUP BY event_date, page_url, user_id
```

### Run a backfill

```bash
# Backfill a specific range
vulcan run --select warehouse.page_views --start 2024-01-01 --end 2024-06-30

# Reprocess last 7 days
vulcan run --select warehouse.page_views --start $(date -d '7 days ago' +%Y-%m-%d)
```

---

## INCREMENTAL_BY_UNIQUE_KEY

Upserts rows — inserts new rows, updates existing ones by key.

```sql
MODEL (
  name  warehouse.customers,
  kind  INCREMENTAL_BY_UNIQUE_KEY (
    unique_key customer_id
  ),
  cron  '@daily'
);

SELECT
  customer_id,
  email,
  name,
  updated_at
FROM raw.customers
WHERE updated_at >= @start_ts    -- Vulcan injects start timestamp
```

---

## SCD Type 2 — track history

Keeps the full change history of a dimension. Each change gets a new row with
`valid_from` / `valid_to` timestamps.

```sql
MODEL (
  name  warehouse.dim_customers,
  kind  SCD_TYPE_2 (
    unique_key   customer_id,
    valid_from   valid_from,
    valid_to     valid_to,
    updated_at   updated_at
  ),
  cron '@daily'
);

SELECT
  customer_id,
  email,
  plan,
  updated_at
FROM staging.stg_customers
```

---

## Late-arriving data pattern

Add a lookback buffer for events that arrive late:

```sql
MODEL (
  name  warehouse.orders,
  kind  INCREMENTAL_BY_TIME_RANGE (time_column order_date),
  cron  '@daily',
  start '2024-01-01'
);

-- Look back 3 days to catch late-arriving events
SELECT *
FROM raw.orders
WHERE order_date BETWEEN DATEADD(day, -3, @start_ds) AND @end_ds
```

---

## Common mistakes to avoid

- **Don't aggregate across the full dataset in an incremental model.** Only
  aggregate within the partition window — use a downstream `FULL` model for
  cross-partition aggregates.
- **Always include the time filter.** Without `WHERE ds BETWEEN @start_ds AND @end_ds`,
  Vulcan will scan the full table on every run.
- **Set `start` in the MODEL block.** Without it, Vulcan doesn't know where to
  begin backfilling.
- **Use `partitioned_by`** on your time column for warehouse-level performance.
