# Vulcan Macros

Macros let you write reusable SQL snippets using Jinja2 templating.
Define once in `macros/`, use anywhere in your models.

## File location

```
my_project/
  macros/
    date_trunc.sql
    safe_divide.sql
    is_valid_email.sql
```

## Defining a macro

```sql
-- macros/safe_divide.sql
{% macro safe_divide(numerator, denominator, default=0) %}
  CASE
    WHEN {{ denominator }} = 0 OR {{ denominator }} IS NULL
      THEN {{ default }}
    ELSE {{ numerator }} / {{ denominator }}
  END
{% endmacro %}
```

## Using a macro in a model

```sql
-- models/marts/conversion_rates.sql
MODEL (
  name  marts.conversion_rates,
  kind  FULL,
  cron  '@daily'
);

SELECT
  campaign_id,
  impressions,
  conversions,
  {{ safe_divide('conversions', 'impressions') }} AS conversion_rate
FROM staging.stg_campaigns
```

## Jinja variables and conditionals

```sql
{% macro date_spine(start_date, end_date) %}
  WITH date_range AS (
    SELECT
      DATEADD(day, seq, '{{ start_date }}'::DATE) AS dt
    FROM TABLE(GENERATOR(ROWCOUNT => DATEDIFF(day, '{{ start_date }}', '{{ end_date }}') + 1))
  )
  SELECT dt FROM date_range
{% endmacro %}
```

Conditionals:

```sql
{% if target.name == 'prod' %}
  WHERE ds >= DATEADD(day, -90, CURRENT_DATE)
{% else %}
  WHERE ds >= DATEADD(day, -7, CURRENT_DATE)   -- cheaper in dev
{% endif %}
```

## Built-in Vulcan macros

These are available in every model without importing:

| Macro                   | Description                                      |
|-------------------------|--------------------------------------------------|
| `@start_ds`             | Start date for incremental partition (DATE)      |
| `@end_ds`               | End date for incremental partition (DATE)        |
| `@start_ts`             | Start timestamp for incremental partition        |
| `@end_ts`               | End timestamp for incremental partition          |
| `{{ var('name') }}`     | Access a project variable from config.yaml       |
| `{{ env_var('KEY') }}`  | Read an environment variable                     |
| `{{ this }}`            | Reference the current model's table name         |

## Macro with multiple arguments

```sql
-- macros/classify_amount.sql
{% macro classify_amount(col, small=100, large=1000) %}
  CASE
    WHEN {{ col }} < {{ small }}  THEN 'small'
    WHEN {{ col }} < {{ large }}  THEN 'medium'
    ELSE                               'large'
  END
{% endmacro %}
```

Usage:

```sql
SELECT
  order_id,
  {{ classify_amount('total_amount', small=50, large=500) }} AS size_bucket
FROM staging.stg_orders
```

## Best practices

- One macro per file, file name matches macro name.
- Keep macros pure — no side effects, just SQL generation.
- Use default arguments so macros work without always passing every param.
- Document macro args in a comment at the top of the file.
- Prefer macros over copy-pasting logic across 3+ models.
