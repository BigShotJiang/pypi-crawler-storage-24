"""
vulcan skills CLI — install, list, remove, create, show
"""

import click
import shutil
import yaml
from pathlib import Path
from datetime import date
from importlib import resources

SKILLS_DIR = Path(".vulcan/skills")
LOCK_FILE = Path(".vulcan/skills.lock")


def get_bundled_skills() -> dict:
    """Return all skills bundled in the package."""
    pkg_skills = resources.files("vulcan_skills").joinpath("skills")
    return {
        p.name.replace(".md", ""): p
        for p in pkg_skills.iterdir()
        if p.name.endswith(".md")
    }


def load_lock() -> dict:
    if LOCK_FILE.exists():
        return yaml.safe_load(LOCK_FILE.read_text()) or {"skills": {}}
    return {"skills": {}}


def save_lock(data: dict):
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOCK_FILE.write_text(yaml.dump(data, default_flow_style=False))


@click.group()
def skills():
    """Manage Vulcan AI agent skills."""
    pass


@skills.command()
@click.argument("skill_names", nargs=-1, required=True)
def install(skill_names):
    """Install one or more skills into your project.

    Example: vulcan skills install data-quality incremental-patterns
    """
    bundled = get_bundled_skills()
    lock = load_lock()
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)

    from importlib.metadata import version as pkg_version
    pkg_ver = pkg_version("vulcan-skills")

    for name in skill_names:
        if name not in bundled:
            click.echo(f"  ✗ '{name}' not found. Run `vulcan skills list` to see available skills.", err=True)
            continue

        dest = SKILLS_DIR / f"{name}.md"
        content = bundled[name].read_text()
        dest.write_text(content)

        lock["skills"][name] = {
            "version": pkg_ver,
            "installed_at": str(date.today()),
        }
        click.echo(f"  ✓ Installed: {name}")

    save_lock(lock)
    click.echo(f"\nSkills installed to {SKILLS_DIR}/")


@skills.command("list")
def list_skills():
    """List all available public skills."""
    bundled = get_bundled_skills()
    lock = load_lock()
    installed = set(lock.get("skills", {}).keys())

    click.echo("\nAvailable Vulcan Skills\n" + "─" * 40)
    for name in sorted(bundled.keys()):
        status = "✓ installed" if name in installed else "  available"
        click.echo(f"  {status}  {name}")

    click.echo(f"\n{len(bundled)} skills available. "
               f"{len(installed)} installed in this project.")
    click.echo("Install with: vulcan skills install <skill-name>\n")


@skills.command()
def show():
    """Show all skills active in the current project (public + custom)."""
    if not SKILLS_DIR.exists():
        click.echo("No skills installed. Run `vulcan skills install <name>` to get started.")
        return

    lock = load_lock()
    installed_public = set(lock.get("skills", {}).keys())
    all_files = list(SKILLS_DIR.glob("*.md"))

    click.echo(f"\nActive skills in {SKILLS_DIR}/\n" + "─" * 40)

    for skill_file in sorted(all_files):
        name = skill_file.stem
        if name in installed_public:
            meta = lock["skills"][name]
            click.echo(f"  [public]  {name}  (v{meta['version']}, installed {meta['installed_at']})")
        else:
            click.echo(f"  [custom]  {name}")

    click.echo()


@skills.command()
@click.argument("skill_names", nargs=-1, required=True)
def remove(skill_names):
    """Remove installed skills from your project.

    Example: vulcan skills remove data-quality
    """
    lock = load_lock()

    for name in skill_names:
        skill_file = SKILLS_DIR / f"{name}.md"
        if skill_file.exists():
            skill_file.unlink()
            lock["skills"].pop(name, None)
            click.echo(f"  ✓ Removed: {name}")
        else:
            click.echo(f"  ✗ '{name}' not installed.", err=True)

    save_lock(lock)


@skills.command()
@click.argument("name")
def create(name):
    """Create a new custom skill for your business rules.

    Example: vulcan skills create acme-naming-rules
    """
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    skill_file = SKILLS_DIR / f"{name}.md"

    if skill_file.exists():
        click.echo(f"  Skill '{name}' already exists at {skill_file}")
        return

    template = f"""# {name.replace("-", " ").title()}

## Overview
Describe what this skill teaches the AI agent.

## Rules
- Rule 1
- Rule 2

## Examples

```sql
-- Example here
```

## Context
Add any business context the agent needs to know.
"""

    skill_file.write_text(template)
    click.echo(f"  ✓ Created: {skill_file}")
    click.echo(f"\nEdit the file to add your business rules.")
    click.echo(f"Commit .vulcan/skills/{name}.md to share with your team.\n")

    # Try to open in editor
    import os
    editor = os.environ.get("EDITOR", "")
    if editor:
        import subprocess
        subprocess.run([editor, str(skill_file)])


@skills.command()
def update():
    """Update all installed public skills to the latest version."""
    lock = load_lock()
    installed = list(lock.get("skills", {}).keys())

    if not installed:
        click.echo("No public skills installed.")
        return

    click.echo(f"Updating {len(installed)} skill(s)...")
    bundled = get_bundled_skills()

    from importlib.metadata import version as pkg_version
    pkg_ver = pkg_version("vulcan-skills")

    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    for name in installed:
        if name in bundled:
            dest = SKILLS_DIR / f"{name}.md"
            content = bundled[name].read_text()
            dest.write_text(content)
            lock["skills"][name]["version"] = pkg_ver
            lock["skills"][name]["installed_at"] = str(date.today())
            click.echo(f"  ✓ Updated: {name}")

    save_lock(lock)
    click.echo(f"\nAll skills updated to v{pkg_ver}\n")


@skills.command()
@click.argument("query")
def search(query):
    """Search available skills by name.

    Example: vulcan skills search incremental
    """
    bundled = get_bundled_skills()
    results = [n for n in bundled if query.lower() in n.lower()]

    if not results:
        click.echo(f"No skills found matching '{query}'.")
        return

    click.echo(f"\nResults for '{query}':\n")
    for name in sorted(results):
        click.echo(f"  {name}")
    click.echo()