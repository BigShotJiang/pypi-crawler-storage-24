# Vulcan — Snowflake Patterns

Specific patterns, config, and SQL syntax for using Vulcan with Snowflake.

## Engine configuration

```yaml
# config.yaml
environments:
  dev:
    engine:
      type: snowflake
      account: myorg-myaccount
      user: dev_user
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      database: DEV_DB
      schema: TRANSFORMS
      warehouse: DEV_WH
      role: DEVELOPER
      authenticator: snowflake    # or 'externalbrowser' for SSO

  prod:
    engine:
      type: snowflake
      account: myorg-myaccount
      user: svc_vulcan
      private_key_path: "{{ env_var('SNOWFLAKE_PRIVATE_KEY_PATH') }}"
      database: PROD_DB
      schema: TRANSFORMS
      warehouse: PROD_WH
      role: TRANSFORMER
```

## Key pair authentication (recommended for CI/CD)

```yaml
engine:
  type: snowflake
  account: myorg-myaccount
  user: svc_vulcan
  private_key_path: /secrets/rsa_key.p8
  private_key_passphrase: "{{ env_var('SNOWFLAKE_KEY_PASSPHRASE') }}"
```

## Partitioning and clustering

Snowflake uses **clustering keys** instead of partitions:

```sql
MODEL (
  name         PROD_DB.TRANSFORMS.page_events,
  kind         INCREMENTAL_BY_TIME_RANGE (time_column event_date),
  cron         '@daily',
  start        '2024-01-01',
  clustered_by (event_date, user_id)   -- Snowflake automatic clustering
);
```

## Snowflake-specific SQL syntax

```sql
-- FLATTEN semi-structured data
SELECT
  f.value:order_id::STRING    AS order_id,
  f.value:amount::FLOAT       AS amount
FROM raw.orders_json,
LATERAL FLATTEN(input => items) f

-- VARIANT / OBJECT access
SELECT
  data:user.id::STRING   AS user_id,
  data:event_type::STRING AS event_type
FROM raw.events_variant

-- Time travel (query historical data)
SELECT * FROM staging.stg_orders
AT (OFFSET => -60*60)   -- 1 hour ago

-- MERGE (used internally by INCREMENTAL_BY_UNIQUE_KEY)
MERGE INTO target t
USING source s ON t.id = s.id
WHEN MATCHED THEN UPDATE SET t.value = s.value
WHEN NOT MATCHED THEN INSERT (id, value) VALUES (s.id, s.value)

-- QUALIFY (window function filter — cleaner than subquery)
SELECT *
FROM events
QUALIFY ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY ts DESC) = 1
```

## Dynamic tables (Snowflake native incremental)

```sql
MODEL (
  name  PROD_DB.TRANSFORMS.customer_summary,
  kind  MANAGED,
  -- Use Snowflake Dynamic Tables for sub-minute latency
  table_properties (
    target_lag = '1 minute',
    warehouse   = 'STREAMING_WH'
  )
);

SELECT
  customer_id,
  COUNT(*) AS order_count,
  SUM(amount) AS total_spend
FROM PROD_DB.RAW.orders
GROUP BY customer_id
```

## Cost control patterns

```sql
-- Limit scans with clustering key filter
WHERE event_date BETWEEN @start_ds AND @end_ds   -- uses clustering key
  AND region = 'US'

-- Suspend warehouse when idle (set in Snowflake UI or Terraform)
-- AUTO_SUSPEND = 60 seconds

-- Use smaller warehouse in dev
{% if target.name != 'prod' %}
-- Ensure your dev warehouse is XS
{% endif %}
```

## Best practices for Snowflake

- Use key pair authentication for service accounts in CI/CD — never passwords.
- Set `AUTO_SUSPEND` to 60s on dev warehouses; 5–10 min on prod.
- Use `QUALIFY` instead of nested subqueries for deduplication.
- Cluster large tables on the columns most commonly filtered.
- Use `COPY INTO` for bulk loads from S3/GCS — faster than `INSERT`.
- Store JSON in `VARIANT` columns; Snowflake can query them efficiently.
