"""MCP self-server — exposes proxym CLI commands as tools for LLM.

Mounted at ``/mcp/self/tools/*`` on the FastAPI app. Allows an LLM in a chat
session (e.g. Open WebUI) to manage VMs, accounts, costs, and logs by calling
these endpoints as tool functions.
"""

from __future__ import annotations

from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

router = APIRouter(prefix="/mcp/self", tags=["mcp-self"])
logger = structlog.get_logger()

_VM_ID_DESC = "VM identifier"


# ── Request models ────────────────────────────────────────

class VMCreateRequest(BaseModel):
    tool: str = Field(..., description="AI tool: windsurf | cursor | vscode | roocode")
    account: str = Field("", description="Account ID (empty = cheapest active)")
    project: str = Field(..., description="Project name from ~/github/")


class VMActionRequest(BaseModel):
    vm_id: str = Field(..., description=_VM_ID_DESC)


class VMSnapshotRequest(BaseModel):
    vm_id: str = Field(..., description=_VM_ID_DESC)
    name: str = Field("", description="Snapshot name (empty = auto-timestamp)")


class VMSwitchRequest(BaseModel):
    vm_id: str = Field(..., description=_VM_ID_DESC)
    project: str = Field(..., description="New project name")


class AccountAddRequest(BaseModel):
    provider: str = Field(..., description="Provider: anthropic | openrouter | openai | google | deepseek")
    api_key: str = Field(..., description="API key")
    label: str = Field("", description="Human-readable label")
    budget_usd: float = Field(5.0, description="Daily budget in USD")


# ── Helpers ───────────────────────────────────────────────

def _get_dashboard():
    """Lazy-import dashboard module to avoid circular imports."""
    from proxym.dashboard import _vms, _accounts
    return _vms, _accounts


def _get_orchestrator():
    """Lazy-import VM orchestrator."""
    from proxym.virt import VMOrchestrator
    return VMOrchestrator


# ── VM tools ──────────────────────────────────────────────

@router.post("/tools/vm_list")
async def tool_vm_list() -> dict[str, Any]:
    """List all VMs with their status."""
    try:
        _vms, _ = _get_dashboard()
        vms = _vms().list_vms()
        return {"vms": [v.__dict__ if hasattr(v, "__dict__") else v for v in vms]}
    except Exception as exc:
        logger.warning("self_mcp_vm_list_error", error=str(exc))
        return {"vms": [], "error": str(exc)}


@router.post("/tools/vm_create")
async def tool_vm_create(req: VMCreateRequest) -> dict[str, Any]:
    """Create a new VM with an AI tool."""
    try:
        orch_cls = _get_orchestrator()
        orch = orch_cls()
        result = orch.create_vm(
            tool=req.tool, account=req.account, project=req.project,
        )
        logger.info("self_mcp_vm_created", tool=req.tool, project=req.project)
        return {"status": "created", "vm": result}
    except Exception as exc:
        logger.warning("self_mcp_vm_create_error", error=str(exc))
        return {"status": "error", "error": str(exc)}


@router.post("/tools/vm_start")
async def tool_vm_start(req: VMActionRequest) -> dict[str, Any]:
    """Start a stopped VM."""
    try:
        orch_cls = _get_orchestrator()
        orch = orch_cls()
        orch.start_vm(req.vm_id)
        logger.info("self_mcp_vm_started", vm_id=req.vm_id)
        return {"status": "started", "vm_id": req.vm_id}
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


@router.post("/tools/vm_stop")
async def tool_vm_stop(req: VMActionRequest) -> dict[str, Any]:
    """Stop a running VM."""
    try:
        orch_cls = _get_orchestrator()
        orch = orch_cls()
        orch.stop_vm(req.vm_id)
        logger.info("self_mcp_vm_stopped", vm_id=req.vm_id)
        return {"status": "stopped", "vm_id": req.vm_id}
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


@router.post("/tools/vm_snapshot")
async def tool_vm_snapshot(req: VMSnapshotRequest) -> dict[str, Any]:
    """Create a VM snapshot."""
    try:
        orch_cls = _get_orchestrator()
        orch = orch_cls()
        name = req.name or f"auto-{__import__('time').time():.0f}"
        orch.snapshot_vm(req.vm_id, name)
        return {"status": "snapshot_created", "vm_id": req.vm_id, "name": name}
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


@router.post("/tools/vm_switch_project")
async def tool_vm_switch_project(req: VMSwitchRequest) -> dict[str, Any]:
    """Switch project in a running VM."""
    try:
        orch_cls = _get_orchestrator()
        orch = orch_cls()
        orch.switch_project(req.vm_id, req.project)
        return {"status": "switched", "vm_id": req.vm_id, "project": req.project}
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


# ── Account tools ─────────────────────────────────────────

@router.post("/tools/account_list")
async def tool_account_list() -> dict[str, Any]:
    """List all accounts with costs."""
    try:
        _, _accounts, _ = _get_dashboard()
        accts = _accounts().list_accounts()
        return {"accounts": accts}
    except Exception as exc:
        return {"accounts": [], "error": str(exc)}


@router.post("/tools/account_costs")
async def tool_account_costs() -> dict[str, Any]:
    """Cost summary per account and model."""
    try:
        _, _, _costs = _get_dashboard()
        return _costs().summary()
    except Exception as exc:
        return {"error": str(exc)}


@router.post("/tools/account_add")
async def tool_account_add(req: AccountAddRequest) -> dict[str, Any]:
    """Add a new API account."""
    try:
        _, _accounts, _ = _get_dashboard()
        result = _accounts().add_account(
            provider=req.provider, api_key=req.api_key,
            label=req.label, budget_usd=req.budget_usd,
        )
        return {"status": "added", "account": result}
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


# ── System tools ──────────────────────────────────────────

@router.post("/tools/status")
async def tool_status() -> dict[str, Any]:
    """Full system status: proxy, VMs, accounts, costs."""
    try:
        _vms, _accounts = _get_dashboard()
        return {
            "vms": {"count": len(_vms().list_vms())},
            "accounts": {"count": len(_accounts().list_accounts())},
        }
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


@router.post("/tools/logs")
async def tool_logs(
    lines: Annotated[int, Query(ge=1, le=500)] = 50,
    level: Annotated[str, Query()] = "all",
) -> dict[str, Any]:
    """Recent proxym logs."""
    try:
        from proxym.dashboard import _logs
        return {"logs": _logs(lines=lines, level=level)}
    except Exception as exc:
        return {"logs": [], "error": str(exc)}


@router.post("/tools/models")
async def tool_models() -> dict[str, Any]:
    """List available models with prices."""
    try:
        from proxym.providers import MODELS
        return {
            "models": [
                {
                    "id": m.id,
                    "provider": m.provider,
                    "input_cost": m.input_cost,
                    "output_cost": m.output_cost,
                    "context_window": m.context_window,
                }
                for m in MODELS.values()
            ]
        }
    except Exception as exc:
        return {"models": [], "error": str(exc)}


# ── Tool schema for LLM ──────────────────────────────────

TOOL_SCHEMA: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "vm_list",
            "description": "List all VMs with their current status",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "vm_create",
            "description": "Create a new VM with an AI tool",
            "parameters": {
                "type": "object",
                "properties": {
                    "tool": {
                        "type": "string",
                        "enum": ["windsurf", "cursor", "vscode", "roocode"],
                        "description": "AI tool to install in the VM",
                    },
                    "account": {"type": "string", "description": "API account ID"},
                    "project": {"type": "string", "description": "Project name from ~/github/"},
                },
                "required": ["tool", "project"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "vm_start",
            "description": "Start a stopped VM",
            "parameters": {
                "type": "object",
                "properties": {
                    "vm_id": {"type": "string", "description": _VM_ID_DESC},
                },
                "required": ["vm_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "vm_stop",
            "description": "Stop a running VM",
            "parameters": {
                "type": "object",
                "properties": {
                    "vm_id": {"type": "string", "description": _VM_ID_DESC},
                },
                "required": ["vm_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "vm_snapshot",
            "description": "Create a VM snapshot",
            "parameters": {
                "type": "object",
                "properties": {
                    "vm_id": {"type": "string", "description": _VM_ID_DESC},
                    "name": {"type": "string", "description": "Snapshot name"},
                },
                "required": ["vm_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "status",
            "description": "Full system status: proxy, VMs, accounts, costs",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_costs",
            "description": "Cost summary: daily, monthly, per account, per model",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_logs",
            "description": "Recent proxym logs",
            "parameters": {
                "type": "object",
                "properties": {
                    "lines": {"type": "integer", "description": "Number of log lines (default 50)"},
                    "level": {
                        "type": "string",
                        "enum": ["all", "error", "warn", "info"],
                        "description": "Log level filter",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_models",
            "description": "List available AI models with prices",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
]
