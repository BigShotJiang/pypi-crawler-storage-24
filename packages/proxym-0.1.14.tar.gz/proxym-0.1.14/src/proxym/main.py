"""AI Proxy — FastAPI server exposing an OpenAI-compatible API.

The server wraps LiteLLM with:
  - Content-based routing (analyzer → router → cheapest adequate model)
  - Delta context buffer (inject code2llm diffs into system prompt)
  - Semantic caching (Redis/in-memory)
  - Cost tracking with budget enforcement
  - Fallback chains across providers

Start:
  proxym                    # uses .env defaults
  uvicorn proxym.main:app   # manual

Endpoints are split into sub-routers under proxym.api/:
  - completions.py  — /v1/chat/completions + helpers
  - system.py       — /health, /v1/models, /v1/budget, /favicon.ico
  - context_api.py  — /v1/context/*, /v1/sessions, /v1/mcp/servers
  - frontend.py     — /dashboard-ui, /proxym-dashboard.jsx, /config, JS assets
"""

from __future__ import annotations

import argparse
from contextlib import asynccontextmanager

import litellm
import structlog
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from proxym.api import (
    completions_router,
    context_router,
    frontend_router,
    system_router,
)
from proxym.config import get_settings
from proxym.middleware import AuthMiddleware, CostTrackingMiddleware
from proxym.providers import MODELS

structlog.configure(
    processors=[
        structlog.stdlib.add_log_level,
        structlog.dev.ConsoleRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(),
)

logger = structlog.get_logger()


# ── App lifecycle ────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    providers = settings.available_providers()
    logger.info(
        "proxy_starting",
        port=settings.port,
        providers=list(providers.keys()),
        models=len(MODELS),
        budget_daily=f"${settings.daily_budget_usd}",
        budget_monthly=f"${settings.monthly_budget_usd}",
    )

    # Configure LiteLLM API keys
    if settings.anthropic_api_key:
        litellm.anthropic_key = settings.anthropic_api_key
    if settings.openai_api_key:
        litellm.openai_key = settings.openai_api_key

    # Set LiteLLM to drop unsupported params silently
    litellm.drop_params = True
    litellm.set_verbose = False

    yield

    logger.info("proxy_stopped")


app = FastAPI(
    title="Proxym",
    description="Intelligent multi-provider LLM gateway",
    version="0.1.0",
    lifespan=lifespan,
)

# Mount sub-routers
from proxym.dashboard import router as dashboard_router
from proxym.mcp.self_server import router as self_mcp_router
app.include_router(dashboard_router)
app.include_router(self_mcp_router)
app.include_router(system_router)
app.include_router(frontend_router)
app.include_router(context_router)
app.include_router(completions_router)

# Add middleware
settings = get_settings()

# CORS middleware - allow frontend on different port
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4000", "http://localhost:4001", "http://127.0.0.1:4000", "http://127.0.0.1:4001"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.add_middleware(CostTrackingMiddleware)
app.add_middleware(AuthMiddleware, master_key=settings.master_key)


# ── CLI entry point ──────────────────────────────────────────

def cli():
    parser = argparse.ArgumentParser(description="AI Proxy Server")
    parser.add_argument("--host", default=None, help="Bind host")
    parser.add_argument("--port", type=int, default=None, help="Bind port")
    parser.add_argument("--reload", action="store_true", help="Auto-reload on changes")
    args = parser.parse_args()

    s = get_settings()
    uvicorn.run(
        "proxym.main:app",
        host=args.host or s.host,
        port=args.port or s.port,
        reload=args.reload,
        log_level=s.log_level,
    )


if __name__ == "__main__":
    cli()
