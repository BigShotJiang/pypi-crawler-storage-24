# System Architecture Analysis

## Overview

- **Project**: proxy
- **Language**: python
- **Files**: 45
- **Lines**: 16422
- **Functions**: 504
- **Classes**: 62
- **Avg CC**: 3.4
- **Critical (CC≥10)**: 19

## Architecture

### docs/open-webui-tools/ (1 files, 90L, 9 functions)

- `proxym_tools.py` — 90L, 9 methods, CC↑1

### frontend/ (1 files, 6L, 0 functions)

- `proxym-dashboard.jsx` — 6L, 0 methods, CC↑0

### htmlcov/ (1 files, 735L, 65 functions)

- `coverage_html_cb_dd2e7eb5.js` — 735L, 65 methods, CC↑21

### root/ (1 files, 14L, 0 functions)

- `project.sh` — 14L, 0 methods, CC↑0

### scripts/ (2 files, 136L, 0 functions)

- `jetson-entrypoint.sh` — 43L, 0 methods, CC↑0
- `setup.sh` — 93L, 0 methods, CC↑0

### src/proxym/ (4 files, 554L, 31 functions)

- `ctl.py` — 295L, 26 methods, CC↑4
- `config.py` — 118L, 3 methods, CC↑3
- `main.py` — 138L, 2 methods, CC↑3
- `__init__.py` — 3L, 0 methods, CC↑0

### src/proxym/accounts/ (1 files, 346L, 20 functions)

- `__init__.py` — 346L, 20 methods, CC↑10

### src/proxym/api/ (7 files, 774L, 40 functions)

- `_pipeline.py` — 299L, 16 methods, CC↑7
- `system.py` — 138L, 7 methods, CC↑6
- `frontend.py` — 120L, 6 methods, CC↑5
- `_state.py` — 84L, 6 methods, CC↑2
- `context_api.py` — 86L, 4 methods, CC↑2
- _2 more files_

### src/proxym/cache/ (1 files, 333L, 10 functions)

- `__init__.py` — 333L, 10 methods, CC↑9

### src/proxym/cli/ (10 files, 1076L, 49 functions)

- `system.py` — 159L, 3 methods, CC↑10
- `_client.py` — 39L, 3 methods, CC↑9
- `chat.py` — 215L, 12 methods, CC↑9
- `accounts.py` — 70L, 3 methods, CC↑6
- `browser.py` — 65L, 4 methods, CC↑6
- _5 more files_

### src/proxym/context/ (5 files, 510L, 20 functions)

- `detector.py` — 208L, 9 methods, CC↑9
- `session.py` — 144L, 8 methods, CC↑6
- `tool_selector.py` — 101L, 2 methods, CC↑5
- `_context.py` — 33L, 1 methods, CC↑3
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/dashboard/ (3 files, 1160L, 95 functions)

- `panel.jsx` — 744L, 65 methods, CC↑34
- `__init__.py` — 405L, 24 methods, CC↑13
- `api.js` — 11L, 6 methods, CC↑3

### src/proxym/dashboard/hooks/ (1 files, 148L, 25 functions)

- `useDashboardData.js` — 148L, 25 methods, CC↑8

### src/proxym/mcp/ (5 files, 729L, 30 functions)

- `client.py` — 148L, 4 methods, CC↑6
- `router.py` — 95L, 4 methods, CC↑5
- `registry.py` — 113L, 8 methods, CC↑4
- `self_server.py` — 349L, 14 methods, CC↑4
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/middleware/ (1 files, 60L, 3 functions)

- `__init__.py` — 60L, 3 methods, CC↑5

### src/proxym/providers/ (1 files, 330L, 4 functions)

- `__init__.py` — 330L, 4 methods, CC↑8

### src/proxym/router/ (2 files, 603L, 28 functions)

- `strategy.py` — 263L, 14 methods, CC↑9
- `__init__.py` — 340L, 14 methods, CC↑8

### src/proxym/virt/ (7 files, 1510L, 66 functions)

- `_orchestrator.py` — 806L, 36 methods, CC↑11
- `_config.py` — 94L, 1 methods, CC↑9
- `browser_profiles.py` — 325L, 11 methods, CC↑9
- `clonebox_adapter.py` — 209L, 17 methods, CC↑5
- `_check.py` — 17L, 1 methods, CC↑3
- _2 more files_

### src/proxym/virt/profiles/ (1 files, 69L, 4 functions)

- `__init__.py` — 69L, 4 methods, CC↑5

### src/proxym/watch/ (2 files, 150L, 5 functions)

- `__init__.py` — 146L, 5 methods, CC↑5
- `client.py` — 4L, 0 methods, CC↑0

## Key Exports

- **VMsPanel** (function, CC=34) ⚠ split
- **sortedVms** (function, CC=19) ⚠ split
- **comparison** (function, CC=17) ⚠ split
- **LogPanel** (function, CC=29) ⚠ split
- **table** (function, CC=21) ⚠ split
- **table_body_rows** (function, CC=21) ⚠ split
- **no_rows** (function, CC=21) ⚠ split
- **footer** (function, CC=21) ⚠ split
- **ratio_columns** (function, CC=21) ⚠ split
- **filter_handler** (function, CC=21) ⚠ split
- **_SnapshotMixin** (class, CC̄=5.0)
- **_StateMixin** (class, CC̄=5.0)
- **AccountCredentials** (class, CC̄=5.0)
- **ProjectsConfig** (class, CC̄=9.0)

## Hotspots (High Fan-Out)

- **cmd_status** — fan-out=21: Orchestrates 21 calls
- **useDashboardData** — fan-out=20: Orchestrates 20 calls
- **VMsPanel** — fan-out=18: Orchestrates 18 calls
- **detect_firefox_profiles** — fan-out=17: Detect Firefox profiles by parsing profiles.ini.
- **_detect_chromium_family** — fan-out=17: Detect profiles for Chrome/Chromium from Local State file.
- **_LifecycleMixin._create_vm_clonebox** — fan-out=16: Create VM via clonebox CLI with injected cloud-init config.
- **analyze_request** — fan-out=15: Analysis pipeline, 15 stages

## Refactoring Priorities

| # | Action | Impact | Effort |
|---|--------|--------|--------|
| 1 | Split VMsPanel (CC=34 → target CC<10) | high | low |
| 2 | Split LogPanel (CC=29 → target CC<10) | high | low |
| 3 | Split god module src/proxym/dashboard/panel.jsx (744L, 0 classes) | high | high |
| 4 | Split god module htmlcov/coverage_html_cb_dd2e7eb5.js (735L, 0 classes) | high | high |
| 5 | Split god module src/proxym/virt/_orchestrator.py (806L, 7 classes) | high | high |
| 6 | Split table (CC=21 → target CC<10) | medium | low |
| 7 | Split table_body_rows (CC=21 → target CC<10) | medium | low |
| 8 | Split no_rows (CC=21 → target CC<10) | medium | low |
| 9 | Split footer (CC=21 → target CC<10) | medium | low |
| 10 | Split ratio_columns (CC=21 → target CC<10) | medium | low |

## Context for LLM

When suggesting changes:
1. Start from hotspots and high-CC functions
2. Follow refactoring priorities above
3. Maintain public API surface — keep backward compatibility
4. Prefer minimal, incremental changes

