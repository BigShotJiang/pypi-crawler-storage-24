// match_results.hpp
// Copyright (c) 2015-2023 Ben Hanson (http://www.benhanson.net/)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file licence_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifndef LEXERTL_MATCH_RESULTS_HPP
#define LEXERTL_MATCH_RESULTS_HPP

#include "char_traits.hpp"
#include "enum_operator.hpp"
#include "enums.hpp"

#include <cstdint>
#include <iterator>
#include <stack>
#include <string>
#include <utility>

namespace lexertl
{
    template<typename iter, typename id_t = uint16_t,
        std::size_t flags = +feature_bit::bol | +feature_bit::eol |
        +feature_bit::skip | +feature_bit::again | +feature_bit::multi_state |
        +feature_bit::advance>
    struct match_results
    {
        using id_type = id_t;
        using iter_type = iter;
        using char_type = typename std::iterator_traits<iter_type>::value_type;
        using index_type = typename basic_char_traits<char_type>::index_type;
        using string = std::basic_string<char_type>;

        id_type id = 0;
        id_type user_id = npos();
        iter_type first = iter_type();
        iter_type second = iter_type();
        iter_type eoi = iter_type();
        bool bol = true;
        id_type state = 0;

        match_results() = default;

        match_results(const iter_type& start_, const iter_type& end_,
            const bool bol_ = true, const id_type state_ = 0) :
            first(start_),
            second(start_),
            eoi(end_),
            bol(bol_),
            state(state_)
        {
        }

        virtual ~match_results() = default;

        string str() const
        {
            return string(first, second);
        }

        string substr(const std::size_t soffset_,
            const std::size_t eoffset_) const
        {
            return string(first + soffset_, second - eoffset_);
        }

        virtual void clear()
        {
            id = 0;
            user_id = npos();
            first = eoi;
            second = eoi;
            bol = true;
            state = 0;
        }

        virtual void reset(const iter_type& start_, const iter_type& end_)
        {
            id = 0;
            user_id = npos();
            first = start_;
            second = start_;
            eoi = end_;
            bol = true;
            state = 0;
        }

        std::size_t length() const
        {
            return second - first;
        }

        static id_type npos()
        {
            return static_cast<id_type>(~0);
        }

        static id_type skip()
        {
            return static_cast<id_type>(~1);
        }

        friend bool operator ==(const match_results& lhs_,
            const match_results& rhs_)
        {
            return lhs_.id == rhs_.id &&
                lhs_.user_id == rhs_.user_id &&
                lhs_.first == rhs_.first &&
                lhs_.second == rhs_.second &&
                lhs_.eoi == rhs_.eoi &&
                lhs_.bol == rhs_.bol &&
                lhs_.state == rhs_.state;
        }
    };

    template<typename iter, typename id_type = uint16_t,
        std::size_t flags = +feature_bit::bol | +feature_bit::eol |
        +feature_bit::skip | +feature_bit::again | +feature_bit::multi_state |
        +feature_bit::recursive | +feature_bit::advance>
    struct recursive_match_results :
        public match_results<iter, id_type, flags>
    {
        using id_type_pair = std::pair<id_type, id_type>;
        std::stack<id_type_pair> stack;

        recursive_match_results() :
            match_results<iter, id_type, flags>()
        {
        }

        recursive_match_results(const iter& start_, const iter& end_,
            const bool bol_ = true, const id_type state_ = 0) :
            match_results<iter, id_type, flags>(start_, end_, bol_, state_)
        {
        }

        ~recursive_match_results() override = default;

        void clear() override
        {
            match_results<iter, id_type, flags>::clear();

            while (!stack.empty()) stack.pop();
        }

        void reset(const iter& start_, const iter& end_) override
        {
            match_results<iter, id_type, flags>::reset(start_, end_);

            while (!stack.empty()) stack.pop();
        }
    };

    using smatch = match_results<std::string::const_iterator>;
    using cmatch = match_results<const char*>;
    using wsmatch = match_results<std::wstring::const_iterator>;
    using wcmatch = match_results<const wchar_t*>;
    using u32smatch = match_results<std::u32string::const_iterator>;
    using u32cmatch = match_results<const char32_t*>;

    using srmatch =
        recursive_match_results<std::string::const_iterator>;
    using crmatch = recursive_match_results<const char*>;
    using wsrmatch =
        recursive_match_results<std::wstring::const_iterator>;
    using wcrmatch = recursive_match_results<const wchar_t*>;
    using u32srmatch =
        recursive_match_results<std::u32string::const_iterator>;
    using u32crmatch = recursive_match_results<const char32_t*>;
}

#endif
