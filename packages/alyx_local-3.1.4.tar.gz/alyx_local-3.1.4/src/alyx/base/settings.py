"""
Django settings for alyx project.

For more information on this file, see
https://docs.djangoproject.com/en/stable/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/stable/ref/settings/
"""

import os
import sys
from datetime import datetime
from pathlib import Path
from typing import cast
from zoneinfo import ZoneInfo

import structlog
from django.conf.locale.en import formats as en_formats  # ty:ignore[unresolved-import]
from rich.console import Console
from rich.text import Text

sys.path.append("/app/extra_configuration")

try:
    from custom_settings import *  # type: ignore  # noqa: F403
    from custom_settings import (  # type: ignore  # noqa: F401
        DEBUG,
        DEFAULT_LAB_NAME,
        TIME_ZONE,
    )
except (ImportError, ModuleNotFoundError):
    console = Console()
    console.print(
        Text(
            "!!! The custom_settings.py file is missing. "
            "Proceeding without it, but probably in an erroneous manner !!!",
            style="bold red",
        )
    )
    TIME_ZONE = "Europe/Paris"
    DEBUG = True
    # raise ImportError("The custom_settings.py file is missing. Cannot proceed")

DEBUG = cast(bool, DEBUG)
TIME_ZONE = cast(str, TIME_ZONE)

SERVER_START_TIME = datetime.now(ZoneInfo(TIME_ZONE))

if DEBUG:
    LOG_LEVEL = "INFO"
else:
    LOG_LEVEL = "WARNING"
    # #EDITED BY TIMOTHE ON 22/11/2022 TO BE ABLE TO CONNECT WITH HTTP.
    # CSRF_COOKIE_SECURE = False #previous value was True

    # X_FRAME_OPTIONS = 'DENY'
    # SESSION_COOKIE_SECURE = True
    # #EDITED BY TIMOTHE ON 22/11/2022 TO BE ABLE TO CONNECT WITH HTTP.
    # SECURE_SSL_REDIRECT = False #previous value was True
    # SECURE_BROWSER_XSS_FILTER = True
    # SECURE_CONTENT_TYPE_NOSNIFF = True
    # SECURE_HSTS_SECONDS = 30
    # SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    # SECURE_HSTS_PRELOAD = True

# IN WHAT ENVIRONMENT DO WE RUN ?
IS_DOCKER = os.path.exists("/.dockerenv")
IS_GITHUB_ACTION = "GITHUB_ACTIONS" in os.environ

if IS_DOCKER:

    def read_db_password(secret_file_path: Path | str):
        with open(secret_file_path) as f:
            return f.read().strip()

    DB_PASSWORD_FILE = Path(
        os.environ["POSTGRES_PASSWORD_FILE"]
    )  # "/run/secrets/db-secure-password")
    if not DB_PASSWORD_FILE.is_file():
        raise IOError(
            "No 'db-secure-password' file was found. "
            "You should provide one under the path ./docker/postgres/db-secure-password"
        )
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": "alyx",  # The database name
            "USER": "postgres",  # The database user
            "PASSWORD": read_db_password(DB_PASSWORD_FILE),  # The database password
            "HOST": "db",  # Name of the service defined in docker-compose.yml
            "PORT": "5432",  # The default port for PostgreSQL
        }
    }

elif IS_GITHUB_ACTION:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql_psycopg2",
            "NAME": "githubactions",
            "USER": "postgres",
            "PASSWORD": "postgres",
            "HOST": "localhost",
            "PORT": "5432",
        }
    }


BASE_DIR = Path("/app/src/alyx")  # Path(__file__).resolve().parent.parent
UPLOADED_DIR = BASE_DIR.parent.parent / "uploaded"
DATA_DIR = Path("/app/data")

DATA_UPLOAD_MAX_NUMBER_FIELDS = 10000
DEFAULT_AUTO_FIELD = "django.db.models.AutoField"
# Custom User model with UUID primary key
AUTH_USER_MODEL = "misc.LabMember"

en_formats.DATETIME_FORMAT = "d/m/Y H:i"
DATE_INPUT_FORMATS = ("%d/%m/%Y",)

USE_TZ = True

# Production settings. Used mainly for SSL security. As we go local, i deactiated them.
# There is still authentification, but "risk" for man in the middle attack
# (only, the middle man have to be IN pasteur's private network so it's much less likely and data is backuped regularly.

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "simple": {
            "()": "colorlog.ColoredFormatter",
            "format": "%(log_color)s%(asctime)s [%(levelname)s] "
            + "{%(filename)s:%(lineno)s} %(message)s",
            "datefmt": "%d/%m %H:%M:%S",
            "log_colors": {
                "DEBUG": "cyan",
                "INFO": "white",
                "WARNING": "yellow",
                "ERROR": "red",
                "CRITICAL": "bold_red",
            },
        },
        "json_formatter": {
            "()": structlog.stdlib.ProcessorFormatter,
            "processor": structlog.processors.JSONRenderer(),
        },
    },
    "handlers": {
        "file": {
            "level": f"{LOG_LEVEL}",
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(DATA_DIR / "logs" / "alyx_db.log"),
            "maxBytes": 16777216,
            "backupCount": 5,
            "formatter": "simple",
        },
        "console": {
            "level": f"{LOG_LEVEL}",
            "class": "logging.StreamHandler",
            "formatter": "simple",
        },
        "json_file": {
            "level": f"{LOG_LEVEL}",
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(DATA_DIR / "logs" / "alyx_json_db.json"),
            "maxBytes": 16777216,
            "backupCount": 5,
            "formatter": "json_formatter",
        },
    },
    "loggers": {
        "django": {
            "handlers": ["file"],
            "level": f"{LOG_LEVEL}",
            "propagate": True,
        },
        "django_structlog": {
            "handlers": ["json_file"],
            "level": f"{LOG_LEVEL}",
        },
    },
    "root": {
        "handlers": ["file", "console"],
        "level": f"{LOG_LEVEL}",
        "propagate": True,
    },
}

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
    ],
    context_class=structlog.threadlocal.wrap_dict(dict),
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

# Application definition

DJANGO_APPS = [
    "django_filters",
    "django.contrib.admin",
    "django.contrib.admindocs",
    "django.contrib.contenttypes",
    "django.contrib.auth",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "mptt",
    "polymorphic",  # enhances django model inheritance
]

REST_FRAMEWORK_APPS = [
    "rest_framework",
    "rest_framework.authtoken",
]

REST_FRAMEWORK_DOCS = [
    "drf_spectacular",
    "drf_spectacular_sidecar",
    "reversion",
    "test_without_migrations",
]

EXTERNAL_APPS = [
    "dbbackup"  # Backups and restore https://django-dbbackup.readthedocs.io/en/stable/index.html
]

if DEBUG:
    EXTERNAL_APPS.append(
        "debug_toolbar"
    )  # https://django-debug-toolbar.readthedocs.io/en/latest/installation.html

UI_APPS = [
    "markdownx",  # https://github.com/neutronX/django-markdownx
    "jsoneditor",  # https://github.com/nnseva/django-jsoneditor
    "django_admin_listfilter_dropdown",  # https://github.com/mrts/django-admin-list-filter-dropdown
    "django_password_eye",  # https://pypi.org/project/django-password-eye/
    "rangefilter",
]

INTERNAL_APPS = [
    "alyx.actions",
    "alyx.data",
    "alyx.misc",
    "alyx.experiments",
    "alyx.jobs",
    "alyx.subjects",
    "alyx.apps.AlyxConfig",
    # because alyx toplevel app itself is installed with alyx.apps.AlyxConfig
    # we don't need the STATICFILES_DIRS to define basedir
    # (otherwise, location of static dir in src/alyx/static will be included twice)
]

INSTALLED_APPS = (
    DJANGO_APPS
    + REST_FRAMEWORK_APPS
    + REST_FRAMEWORK_DOCS
    + EXTERNAL_APPS
    + UI_APPS
    + INTERNAL_APPS
    + [
        # needs to be last in the list
        "django_cleanup.apps.CleanupConfig",
    ]
)


JSON_EDITOR_JS = (
    "https://cdnjs.cloudflare.com/ajax/libs/jsoneditor/9.10.2/jsoneditor.js"
)
JSON_EDITOR_CSS = (
    "https://cdnjs.cloudflare.com/ajax/libs/jsoneditor/9.10.2/jsoneditor.css"
)

MIDDLEWARE = [
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "django.contrib.admindocs.middleware.XViewMiddleware",
    "django.middleware.security.SecurityMiddleware",
    # "alyx.base.queries.QueryPrintingMiddleware",
    "django_structlog.middlewares.RequestMiddleware",
]
if DEBUG:
    MIDDLEWARE.append("debug_toolbar.middleware.DebugToolbarMiddleware")

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [str(BASE_DIR / "templates")],
        "APP_DIRS": False,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
            "loaders": [
                # "django.template.loaders.cached.Loader",
                "django.template.loaders.filesystem.Loader",
                "django.template.loaders.app_directories.Loader",
                # "alyx.base.LoggingFilesystemLoader",
                # "alyx.base.LoggingAppDirectoriesLoader",
            ],
        },
    },
]

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework.authentication.SessionAuthentication",
        "rest_framework.authentication.TokenAuthentication",
    ),
    "DEFAULT_FILTER_BACKENDS": ("django_filters.rest_framework.DjangoFilterBackend",),
    "STRICT_JSON": False,
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.LimitOffsetPagination",
    "DEFAULT_RENDERER_CLASSES": (
        "rest_framework.renderers.JSONRenderer",
        # "rest_framework.renderers.BrowsableAPIRenderer",
        # Disabling the BrowsableAPIRenderer (default django API browser)
        # as it is redundant with swagger ui.
        # it also creates a more confusing aesthetics (yet another UI look)
    ),
    "EXCEPTION_HANDLER": "alyx.base.filters.rest_filters_exception_handler",
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "PAGE_SIZE": 250,
}

SPECTACULAR_SETTINGS = {
    "TITLE": "alyx-api",
    "DESCRIPTION": "Alyx neurophysiological database",
    "VERSION": "1.0.0",
    "SCHEMA_PATH_PREFIX": "/api",
    "SERVE_INCLUDE_SCHEMA": False,  # keeping this to False is crucially important
    # to have openapi_parser pakage be able to parse the schema, on alyx-connector's side
}

# Internationalization
USE_I18N = False
USE_L10N = False

# URLS
ROOT_URLCONF = "alyx.base.urls"

# this is where the static assets will be collected to be copied to serving location
STATICFILES_DIRS = (str(BASE_DIR / "static_overrides"),)
# Same comment than above, in INTALLED_APPS :
# because alyx toplevel app itself is installed with alyx.apps.AlyxConfig
# we don't need the STATICFILES_DIRS to define basedir
# (otherwise, location of static dir in src/alyx/static will be included twice)

# this is where the collected static assets will be copied to and served from
STATIC_ROOT = str(UPLOADED_DIR / "static")
# this is the adress suffix at wich the collected static assets will be served
STATIC_URL = "/static/"

# this is where the media uploaded / generated files will be stored and served
MEDIA_ROOT = str(UPLOADED_DIR / "media")
# this is the adress suffix at wich the media uploaded / generated files will be served
MEDIA_URL = "/media/"

# The location for saving and/or serving the cache tables.
# May be a local path, http address or s3 uri (i.e. s3://)
TABLES_ROOT = str(DATA_DIR / "tables/")

STORAGES = {
    # for default media files
    "default": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
        "OPTIONS": {"location": MEDIA_ROOT},
    },
    "staticfiles": {
        "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        "OPTIONS": {"location": STATIC_ROOT, "base_url": STATIC_URL},
        # this is where the collected static assets will be copied to and served from
    },
    "dbbackup": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
        "OPTIONS": {"location": str(DATA_DIR / "backups")},
        # this is where the database backups will be searched for / written to
    },
}


if DEBUG:

    def show_toolbar(request):
        return True

    RESULTS_CACHE_SIZE = 1000  # this is for DEBUG_TOOLBAR to show more infos

    DEBUG_TOOLBAR_CONFIG = {
        # "SHOW_TOOLBAR_CALLBACK": "debug_toolbar.middleware.show_toolbar_with_docker",
        "JQUERY_URL": None,
        "SHOW_TOOLBAR_CALLBACK": show_toolbar,
    }

UPLOADED_IMAGE_WIDTH = 800

WSGI_APPLICATION = "alyx.base.wsgi.application"

# Testing related parameters
DISABLE_MAIL = False

# Parametrable default values

DEFAULT_SUBJECT_SOURCE = "Internal"
DEFAULT_SPECIES = {
    "name": "Mus musculus",
    "nickname": "Laboratory mouse",
    "pk": "60f915ba-bdf4-444a-ada0-be7ebd3c1826",
}
DEFAULT_PROTOCOL = "1"

INTERNAL_IPS = ["127.0.0.1", "localhost"]
