import pandas as pd
from ta_sdk.indicators.moving_averages import sma
from ta_sdk.indicators.volume import volume_sma


def check_entry_signal(df: pd.DataFrame) -> dict:
    """
    Entry Signal SOP (三訊號):
    1. Trend confirmed: price above 50 SMA, 50 SMA rising
    2. Buy point: price near recent high (within 5%) with volume confirmation
    3. Valid stop: identifiable stop level (recent swing low)
    """
    close = df["close"]
    high = df["high"]
    low = df["low"]
    volume = df["volume"]
    current = float(close.iloc[-1])
    n = len(close)

    if n < 50:
        return {"signal": False, "reason": "Not enough data"}

    # 1. Trend confirmed
    sma50 = sma(close, 50)
    sma50_now = float(sma50.iloc[-1])
    sma50_prev = float(sma50.iloc[-10])
    trend_up = current > sma50_now and sma50_now > sma50_prev

    if not trend_up:
        return {"signal": False, "reason": "Trend not confirmed"}

    # 2. Buy point: near recent high with volume
    recent_high = float(high.iloc[-20:].max())
    near_high = current >= recent_high * 0.95

    vol_avg = float(volume_sma(volume, 50).iloc[-1])
    recent_vol = float(volume.iloc[-5:].mean())
    volume_confirm = recent_vol > vol_avg * 1.2

    if not near_high:
        return {"signal": False, "reason": "Price not near buy point"}

    # 3. Valid stop: swing low in last 20 bars
    stop_level = float(low.iloc[-20:].min())
    risk_pct = (current - stop_level) / current * 100

    if risk_pct > 10:
        return {"signal": False, "reason": f"Stop too far ({risk_pct:.1f}%)"}

    return {
        "signal": True,
        "buy_point": round(recent_high, 2),
        "stop": round(stop_level, 2),
        "risk_pct": round(risk_pct, 2),
        "volume_confirm": volume_confirm,
        "reason": "Entry signal: trend up + near buy point + valid stop",
    }
