import pandas as pd
from ta_sdk.indicators.moving_averages import sma


def check_canslim(df: pd.DataFrame, fundamentals: dict) -> dict:
    """
    CANSLIM screening checklist:
    C - Current quarterly EPS growth >= 25%
    A - Annual EPS growth >= 20% and ROE >= 17%
    N - New product, management, or price high
    S - Supply/demand: volume confirmation
    L - Leader: relative strength (price in uptrend)
    I - Institutional sponsorship >= 20%
    M - Market direction (checked via price vs 200 SMA)
    """
    close = df["close"]
    volume = df["volume"]
    current = float(close.iloc[-1])

    # C: Current quarterly EPS growth
    c_pass = fundamentals.get("eps_growth_qtr", 0) >= 25

    # A: Annual EPS growth + ROE
    a_pass = (
        fundamentals.get("eps_growth_annual", 0) >= 20
        and fundamentals.get("roe", 0) >= 17
    )

    # N: New product / management / price high
    n_pass = fundamentals.get("new_product", False)

    # S: Supply/demand - recent volume above average
    if len(volume) >= 50:
        avg_vol = float(volume.iloc[-50:].mean())
        recent_vol = float(volume.iloc[-5:].mean())
        s_pass = recent_vol >= avg_vol * 0.8
    else:
        s_pass = True

    # L: Leader - price above 50 SMA (uptrend)
    if len(close) >= 50:
        sma50_val = float(sma(close, 50).iloc[-1])
        l_pass = current > sma50_val
    else:
        l_pass = False

    # I: Institutional sponsorship
    i_pass = fundamentals.get("institutional_pct", 0) >= 20

    # M: Market direction - price above 200 SMA
    if len(close) >= 200:
        sma200_val = float(sma(close, 200).iloc[-1])
        m_pass = current > sma200_val
    else:
        m_pass = current > float(close.mean())

    checks = {
        "C_current_earnings": c_pass,
        "A_annual_earnings": a_pass,
        "N_new_factor": n_pass,
        "S_supply_demand": s_pass,
        "L_leader": l_pass,
        "I_institutional": i_pass,
        "M_market_direction": m_pass,
    }

    score = sum(bool(v) for v in checks.values())
    return {
        "passes": score >= 5,
        "score": score,
        "max_score": 7,
        "checks": checks,
    }
