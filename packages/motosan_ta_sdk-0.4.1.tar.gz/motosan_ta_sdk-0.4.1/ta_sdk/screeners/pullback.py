import pandas as pd
from ta_sdk.indicators.moving_averages import sma


def check_pullback(df: pd.DataFrame) -> dict:
    """
    Pullback-to-support screener:
    1. Trend confirmed: price above 200 SMA, 50 SMA above 200 SMA
    2. Pullback: price pulled back near 50 SMA (within 3%)
    3. Support holding: price bouncing off support (recent low near 50 SMA)
    4. Volume drying up on pullback or expanding on bounce
    """
    close = df["close"]
    low = df["low"]
    volume = df["volume"]
    current = float(close.iloc[-1])
    n = len(close)

    if n < 200:
        return {"signal": False, "reason": "Not enough data"}

    # 1. Trend confirmed
    sma50_val = float(sma(close, 50).iloc[-1])
    sma200_val = float(sma(close, 200).iloc[-1])
    trend_up = sma50_val > sma200_val and current > sma200_val

    if not trend_up:
        return {"signal": False, "reason": "Trend not confirmed"}

    # 2. Pullback near 50 SMA support (within 8% below to 5% above)
    distance_to_sma50 = (current - sma50_val) / sma50_val * 100
    near_support = -8 <= distance_to_sma50 <= 5

    if not near_support:
        return {
            "signal": False,
            "reason": f"Price not near 50 SMA support ({distance_to_sma50:.1f}%)",
        }

    # 3. Price was higher recently (pulled back from higher level)
    recent_high = float(close.iloc[-30:].max())
    pullback_pct = (recent_high - current) / recent_high * 100
    has_pullback = pullback_pct >= 3

    if not has_pullback:
        return {"signal": False, "reason": "No meaningful pullback detected"}

    # 4. Volume check: recent volume lower than average (selling drying up)
    # or bounce volume expanding
    vol_avg = float(volume.iloc[-50:].mean())
    recent_vol = float(volume.iloc[-5:].mean())

    support_level = float(low.iloc[-20:].min())

    return {
        "signal": True,
        "support_level": round(sma50_val, 2),
        "swing_low": round(support_level, 2),
        "pullback_pct": round(pullback_pct, 2),
        "volume_expanding": recent_vol > vol_avg * 1.1,
        "reason": "Pullback to 50 SMA support in uptrend",
    }
