import pandas as pd
from ta_sdk.indicators.moving_averages import sma


def check_stage2(df: pd.DataFrame) -> dict:
    """
    Minervini's 7-point Stage 2 Trend Template:
    1. Price > 150 SMA
    2. Price > 200 SMA
    3. 150 SMA > 200 SMA
    4. 200 SMA trending up (at least 1 month)
    5. 50 SMA > 150 SMA > 200 SMA
    6. Price > 50 SMA
    7. Price within 25% of 52-week high, at least 30% above 52-week low
    """
    close = df["close"]
    current = close.iloc[-1]

    sma50 = sma(close, 50).iloc[-1]
    sma150 = sma(close, 150).iloc[-1]
    sma200 = sma(close, 200).iloc[-1]
    sma200_1mo = sma(close, 200).iloc[-22] if len(close) > 222 else sma200

    high_52w = close.iloc[-252:].max() if len(close) >= 252 else close.max()
    low_52w = close.iloc[-252:].min() if len(close) >= 252 else close.min()

    checks = {
        "price_above_150sma": bool(current > sma150),
        "price_above_200sma": bool(current > sma200),
        "sma150_above_200sma": bool(sma150 > sma200),
        "sma200_trending_up": bool(sma200 > sma200_1mo),
        "sma50_above_150_above_200": bool(sma50 > sma150 > sma200),
        "price_above_50sma": bool(current > sma50),
        "near_52w_high": bool(current >= high_52w * 0.75)
        and bool(current >= low_52w * 1.30),
    }

    score = sum(bool(v) for v in checks.values())
    return {
        "passes": score >= 5,
        "score": score,
        "max_score": 7,
        "checks": checks,
    }
