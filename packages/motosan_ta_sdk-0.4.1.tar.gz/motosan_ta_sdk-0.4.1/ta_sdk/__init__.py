__version__ = "0.4.1"

# Data
from ta_sdk.data.models import OHLCVData, Quote, PatternResult, AnalysisReport
from ta_sdk.data.yfinance_provider import YFinanceProvider
from ta_sdk.data.binance_provider import BinanceProvider
from ta_sdk.data.multi import MultiProvider

# Indicators
from ta_sdk.indicators.moving_averages import sma, ema, kama, dema, tema, hma, smma
from ta_sdk.indicators.momentum import rsi, macd, aroon, tsi, fisher_transform, trix
from ta_sdk.indicators.volatility import atr, bollinger_bands
from ta_sdk.indicators.volume import obv, cmf

# Screeners
from ta_sdk.screeners.stage2 import check_stage2
from ta_sdk.screeners.entry_signal import check_entry_signal

# Patterns
from ta_sdk.patterns.vcp import detect_vcp
from ta_sdk.patterns.cup_handle import detect_cup_handle
from ta_sdk.patterns.double_bottom import detect_double_bottom

# Analysis
from ta_sdk.analysis.full_analysis import analyze_stock

__all__ = [
    # Data
    "OHLCVData",
    "Quote",
    "PatternResult",
    "AnalysisReport",
    "YFinanceProvider",
    "BinanceProvider",
    "MultiProvider",
    # Indicators
    "sma",
    "ema",
    "kama",
    "dema",
    "tema",
    "hma",
    "smma",
    "rsi",
    "macd",
    "aroon",
    "tsi",
    "fisher_transform",
    "trix",
    "atr",
    "bollinger_bands",
    "obv",
    "cmf",
    # Screeners
    "check_stage2",
    "check_entry_signal",
    # Patterns
    "detect_vcp",
    "detect_cup_handle",
    "detect_double_bottom",
    # Analysis
    "analyze_stock",
]
