import pandas as pd
import numpy as np


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """RSI using Wilder's EWM seeded at bar 1, matching Rust ta-math and pandas-ta."""
    close = close.reset_index(drop=True)
    n = len(close)
    out = np.full(n, np.nan)

    if period == 0 or n < 2:
        return pd.Series(out, index=range(n), dtype="float64")

    alpha = 1.0 / period
    vals = close.values

    gains = np.zeros(n)
    losses = np.zeros(n)
    for i in range(1, n):
        delta = vals[i] - vals[i - 1]
        if delta > 0:
            gains[i] = delta
        else:
            losses[i] = -delta

    avg_gain = gains[1]
    avg_loss = losses[1]

    total = avg_gain + avg_loss
    if total > 0:
        out[1] = np.clip(100.0 * avg_gain / total, 0, 100)

    for i in range(2, n):
        avg_gain = (1.0 - alpha) * avg_gain + alpha * gains[i]
        avg_loss = (1.0 - alpha) * avg_loss + alpha * losses[i]
        total = avg_gain + avg_loss
        if total > 0:
            out[i] = np.clip(100.0 * avg_gain / total, 0, 100)

    return pd.Series(out, index=close.index, dtype="float64")


def macd(
    close: pd.Series, fast: int = 12, slow: int = 26, signal_period: int = 9
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """MACD using SMA-seeded EMA, matching pandas-ta."""
    from ta_sdk.indicators.moving_averages import _sma_seeded_ema

    ema_fast = _sma_seeded_ema(close, fast)
    ema_slow = _sma_seeded_ema(close, slow)
    macd_line = ema_fast - ema_slow
    # pandas-ta slices off leading NaN, then applies presma EMA
    fvi = macd_line.first_valid_index()
    s = macd_line.loc[fvi:].copy()
    sma_nth = s.iloc[:signal_period].mean()
    s.iloc[: signal_period - 1] = np.nan
    s.iloc[signal_period - 1] = sma_nth
    signal_line = (
        s.ewm(span=signal_period, adjust=False).mean().reindex(macd_line.index)
    )
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def stochastic(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    k_period: int = 14,
    d_period: int = 3,
) -> tuple[pd.Series, pd.Series]:
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    k = 100 * (close - lowest_low) / (highest_high - lowest_low)
    d = k.rolling(window=d_period).mean()
    return k, d


def cci(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 20,
    c: float = 0.015,
) -> pd.Series:
    """Commodity Channel Index.

    CCI = (TP - SMA(TP, period)) / (c * MeanDev(TP, period))
    where TP = (high + low + close) / 3
    """
    tp = (high + low + close) / 3.0
    tp_sma = tp.rolling(window=period).mean()

    # Mean deviation: rolling mean of |TP - SMA(TP)|
    def _mean_dev(x: pd.Series) -> float:
        return np.abs(x - x.mean()).mean()

    mad = tp.rolling(window=period).apply(_mean_dev, raw=False)
    return (tp - tp_sma) / (c * mad)


def roc(close: pd.Series, period: int = 10) -> pd.Series:
    """Rate of Change.

    ROC = (close - close_n_ago) / close_n_ago * 100
    """
    close_n = close.shift(period)
    return (close - close_n) / close_n * 100


def williams_r(
    high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14
) -> pd.Series:
    """Williams %R.

    %R = (highest_high - close) / (highest_high - lowest_low) * -100
    """
    highest = high.rolling(window=period).max()
    lowest = low.rolling(window=period).min()
    return (highest - close) / (highest - lowest) * -100


def mfi(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    volume: pd.Series,
    period: int = 14,
) -> pd.Series:
    """Money Flow Index (volume-weighted RSI).

    Uses pandas-ta algorithm: SMA-seeded Wilder's RMA for smoothing.
    """
    tp = (high + low + close) / 3.0
    raw_mf = tp * volume

    # Positive and negative money flow
    delta = tp.diff()
    pos_mf = raw_mf.where(delta > 0, 0.0)
    neg_mf = raw_mf.where(delta < 0, 0.0)

    # Wilder's RMA (same as ewm(alpha=1/period, adjust=False) with SMA seed)
    # pandas-ta uses rolling sum for MFI, not RMA
    pos_sum = pos_mf.rolling(window=period).sum()
    neg_sum = neg_mf.rolling(window=period).sum()

    mfr = pos_sum / neg_sum
    return 100 - (100 / (1 + mfr))


def aroon(
    high: pd.Series, low: pd.Series, period: int = 25
) -> tuple[pd.Series, pd.Series]:
    """Aroon indicator.

    Aroon Up   = ((period - bars since highest high) / period) * 100
    Aroon Down = ((period - bars since lowest low) / period) * 100

    The lookback window is [i-period .. i] (period+1 bars).
    Output starts at index ``period``; earlier values are NaN.
    """
    length = min(len(high), len(low))
    high_arr = high.values[:length]
    low_arr = low.values[:length]

    up = np.full(length, np.nan)
    down = np.full(length, np.nan)

    for i in range(period, length):
        window_start = i - period
        highest_idx = window_start
        lowest_idx = window_start
        for j in range(window_start, i + 1):
            if high_arr[j] >= high_arr[highest_idx]:
                highest_idx = j
            if low_arr[j] <= low_arr[lowest_idx]:
                lowest_idx = j
        bars_since_high = i - highest_idx
        bars_since_low = i - lowest_idx
        up[i] = ((period - bars_since_high) / period) * 100.0
        down[i] = ((period - bars_since_low) / period) * 100.0

    return pd.Series(up, index=high.index[:length]), pd.Series(
        down, index=high.index[:length]
    )


def tsi(close: pd.Series, long_period: int = 25, short_period: int = 13) -> pd.Series:
    """True Strength Index.

    TSI = 100 * EMA(EMA(momentum, long), short) / EMA(EMA(|momentum|, long), short)

    Double-smoothed momentum oscillator bounded by [-100, 100].
    """
    momentum = close.diff()
    abs_momentum = momentum.abs()

    # Double smooth momentum: EMA(EMA(momentum, long_period), short_period)
    ema_mom_long = momentum.ewm(span=long_period, adjust=False).mean()
    double_smoothed_mom = ema_mom_long.ewm(span=short_period, adjust=False).mean()

    # Double smooth absolute momentum
    ema_abs_long = abs_momentum.ewm(span=long_period, adjust=False).mean()
    double_smoothed_abs = ema_abs_long.ewm(span=short_period, adjust=False).mean()

    result = 100.0 * double_smoothed_mom / double_smoothed_abs
    # Where denominator is zero or NaN, output NaN
    result = result.where(double_smoothed_abs.abs() > np.finfo(float).eps, np.nan)
    return result


def fisher_transform(
    high: pd.Series, low: pd.Series, period: int = 9
) -> tuple[pd.Series, pd.Series]:
    """Fisher Transform.

    Transforms price into a Gaussian normal distribution to identify
    turning points. Returns (fisher, signal) where signal is the
    previous bar's fisher value.
    """
    length = min(len(high), len(low))
    hl2 = (high.iloc[:length].values + low.iloc[:length].values) / 2.0

    fisher_arr = np.full(length, np.nan)
    signal_arr = np.full(length, np.nan)

    prev_value = 0.0
    prev_fisher = 0.0

    for i in range(length):
        if i + 1 < period:
            continue

        start = i + 1 - period
        window = hl2[start : i + 1]
        max_hl2 = window.max()
        min_hl2 = window.min()

        rng = max_hl2 - min_hl2
        if rng > np.finfo(float).eps:
            normalized = 2.0 * ((hl2[i] - min_hl2) / rng - 0.5)
        else:
            normalized = 0.0

        value = np.clip(0.33 * normalized + 0.67 * prev_value, -0.999, 0.999)
        f = 0.5 * np.log((1.0 + value) / (1.0 - value)) + 0.5 * prev_fisher

        fisher_arr[i] = f
        signal_arr[i] = prev_fisher

        prev_value = value
        prev_fisher = f

    idx = high.index[:length]
    return pd.Series(fisher_arr, index=idx), pd.Series(signal_arr, index=idx)


def trix(
    close: pd.Series, period: int = 15, signal_period: int = 9
) -> tuple[pd.Series, pd.Series]:
    """TRIX — rate of change of triple-smoothed EMA.

    TRIX = ((EMA3[i] - EMA3[i-1]) / EMA3[i-1]) * 100
    Signal = EMA(TRIX, signal_period)
    """
    ema1 = close.ewm(span=period, adjust=False).mean()
    ema2 = ema1.ewm(span=period, adjust=False).mean()
    ema3 = ema2.ewm(span=period, adjust=False).mean()

    # Rate of change of triple EMA, expressed as percentage
    trix_line = ema3.pct_change() * 100.0

    signal_line = trix_line.ewm(span=signal_period, adjust=False).mean()

    return trix_line, signal_line
