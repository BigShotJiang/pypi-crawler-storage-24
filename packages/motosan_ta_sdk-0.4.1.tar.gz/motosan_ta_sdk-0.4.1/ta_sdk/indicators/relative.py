import pandas as pd


def rs_rating(stock_close: pd.Series, benchmark_close: pd.Series) -> float:
    """
    Simplified RS Rating (0-100).
    Compares stock performance vs benchmark over weighted periods:
    40% recent quarter, 20% each for other 3 quarters.
    """
    if len(stock_close) < 252 or len(benchmark_close) < 252:
        # Fallback: simple relative performance
        stock_ret = stock_close.iloc[-1] / stock_close.iloc[0] - 1
        bench_ret = benchmark_close.iloc[-1] / benchmark_close.iloc[0] - 1
        raw = stock_ret - bench_ret
        return max(0, min(100, 50 + raw * 200))

    def _qtr_return(series, start, end):
        return series.iloc[end] / series.iloc[start] - 1

    n = len(stock_close)
    quarters = [
        (n - 63, n - 1, 0.4),  # most recent quarter: 40%
        (n - 126, n - 64, 0.2),
        (n - 189, n - 127, 0.2),
        (n - 252, n - 190, 0.2),
    ]
    weighted_rs = 0.0
    for start, end, weight in quarters:
        s_ret = _qtr_return(stock_close, start, end)
        b_ret = _qtr_return(benchmark_close, start, end)
        weighted_rs += (s_ret - b_ret) * weight

    return max(0, min(100, 50 + weighted_rs * 200))
