import math

import pandas as pd
import numpy as np


def sma(close: pd.Series, period: int) -> pd.Series:
    return close.rolling(window=period).mean()


def ema(close: pd.Series, period: int) -> pd.Series:
    """SMA-seeded EMA matching pandas-ta."""
    return _sma_seeded_ema(close, period)


def _sma_seeded_ema(close: pd.Series, period: int) -> pd.Series:
    """EMA with SMA seed, matching Rust ta-math EMA behaviour.

    Finds the first window of ``period`` consecutive finite values, seeds with
    their SMA, then applies exponential smoothing with ``alpha = 2/(period+1)``.
    Leading NaN values (common when chaining EMA calls) are preserved.
    """
    vals = close.to_numpy(dtype="float64", na_value=np.nan)
    n = len(vals)
    out = np.full(n, np.nan)

    if period <= 0 or n < period:
        return pd.Series(out, index=close.index, dtype="float64")

    # Find the first index where we have ``period`` consecutive finite values.
    # For raw price data this is index ``period - 1``.  For a prior EMA output
    # that starts with NaNs, this shifts forward accordingly.
    finite_count = 0
    first_finite = -1
    for i in range(n):
        if np.isfinite(vals[i]):
            if first_finite < 0:
                first_finite = i
            finite_count += 1
            if finite_count == period:
                break
        else:
            finite_count = 0
            first_finite = -1

    if finite_count < period:
        return pd.Series(out, index=close.index, dtype="float64")

    seed_idx = first_finite + period - 1
    seed = np.mean(vals[first_finite : seed_idx + 1])
    out[seed_idx] = seed

    alpha = 2.0 / (period + 1)
    for i in range(seed_idx + 1, n):
        if np.isfinite(vals[i]):
            out[i] = alpha * vals[i] + (1.0 - alpha) * out[i - 1]

    return pd.Series(out, index=close.index, dtype="float64")


def _wma(close: pd.Series, period: int) -> pd.Series:
    """Weighted Moving Average with linearly increasing weights."""
    vals = close.to_numpy(dtype="float64", na_value=np.nan)
    n = len(vals)
    out = np.full(n, np.nan)

    if period <= 0 or n < period:
        return pd.Series(out, index=close.index, dtype="float64")

    # weights: 1, 2, ..., period
    weights = np.arange(1, period + 1, dtype="float64")
    weight_sum = weights.sum()

    for i in range(period - 1, n):
        window = vals[i - period + 1 : i + 1]
        if np.any(np.isnan(window)):
            continue
        out[i] = np.dot(window, weights) / weight_sum

    return pd.Series(out, index=close.index, dtype="float64")


def dema(close: pd.Series, period: int) -> pd.Series:
    """Double Exponential Moving Average.

    ``DEMA = 2 * EMA(N) - EMA(EMA(N), N)``
    Uses SMA-seeded EMA to match Rust ta-math parity.
    """
    ema1 = _sma_seeded_ema(close, period)
    ema2 = _sma_seeded_ema(ema1, period)

    out = np.full(len(close), np.nan)
    e1 = ema1.to_numpy()
    e2 = ema2.to_numpy()
    mask = np.isfinite(e1) & np.isfinite(e2)
    out[mask] = 2.0 * e1[mask] - e2[mask]

    return pd.Series(out, index=close.index, dtype="float64")


def tema(close: pd.Series, period: int) -> pd.Series:
    """Triple Exponential Moving Average.

    ``TEMA = 3*EMA - 3*EMA(EMA) + EMA(EMA(EMA))``
    Uses SMA-seeded EMA to match Rust ta-math parity.
    """
    ema1 = _sma_seeded_ema(close, period)
    ema2 = _sma_seeded_ema(ema1, period)
    ema3 = _sma_seeded_ema(ema2, period)

    out = np.full(len(close), np.nan)
    e1 = ema1.to_numpy()
    e2 = ema2.to_numpy()
    e3 = ema3.to_numpy()
    mask = np.isfinite(e1) & np.isfinite(e2) & np.isfinite(e3)
    out[mask] = 3.0 * e1[mask] - 3.0 * e2[mask] + e3[mask]

    return pd.Series(out, index=close.index, dtype="float64")


def hma(close: pd.Series, period: int) -> pd.Series:
    """Hull Moving Average.

    ``HMA = WMA(2*WMA(N/2) - WMA(N), floor(sqrt(N)))``
    """
    half_period = period // 2
    wma_half = _wma(close, half_period)
    wma_full = _wma(close, period)

    h = wma_half.to_numpy()
    f = wma_full.to_numpy()
    diff = np.full(len(close), np.nan)
    mask = np.isfinite(h) & np.isfinite(f)
    diff[mask] = 2.0 * h[mask] - f[mask]

    sqrt_period = int(math.floor(math.sqrt(period)))
    diff_series = pd.Series(diff, index=close.index, dtype="float64")
    return _wma(diff_series, sqrt_period)


def smma(close: pd.Series, period: int) -> pd.Series:
    """Smoothed Moving Average (SMMA / RMA).

    SMA seed followed by recursive smoothing with ``alpha = 1/period``.
    """
    vals = close.to_numpy(dtype="float64", na_value=np.nan)
    n = len(vals)
    out = np.full(n, np.nan)

    if period <= 0 or n < period:
        return pd.Series(out, index=close.index, dtype="float64")

    seed_idx = period - 1
    out[seed_idx] = np.mean(vals[:period])
    p = float(period)

    for i in range(seed_idx + 1, n):
        out[i] = (out[i - 1] * (p - 1.0) + vals[i]) / p

    return pd.Series(out, index=close.index, dtype="float64")


def kama(
    close: pd.Series, period: int = 10, fast: int = 2, slow: int = 30
) -> pd.Series:
    """Kaufman's Adaptive Moving Average.

    Uses efficiency ratio to adapt smoothing constant between fast and slow.
    Matches pandas-ta implementation.
    """
    close = close.copy().reset_index(drop=True)
    n = len(close)

    # Efficiency Ratio
    direction = (close - close.shift(period)).abs()
    volatility = close.diff().abs().rolling(window=period).sum()
    er = direction / volatility

    # Smoothing constants
    fast_sc = 2.0 / (fast + 1.0)
    slow_sc = 2.0 / (slow + 1.0)
    sc = (er * (fast_sc - slow_sc) + slow_sc) ** 2

    result = pd.Series(np.nan, index=close.index, dtype="float64")

    # Seed: pandas-ta seeds KAMA at index (period-1) with SMA of first period values
    seed_idx = period - 1
    if seed_idx >= n:
        return result

    result.iloc[seed_idx] = close.iloc[:period].mean()

    for i in range(seed_idx + 1, n):
        if np.isnan(sc.iloc[i]) or np.isnan(result.iloc[i - 1]):
            continue
        result.iloc[i] = result.iloc[i - 1] + sc.iloc[i] * (
            close.iloc[i] - result.iloc[i - 1]
        )

    return result
