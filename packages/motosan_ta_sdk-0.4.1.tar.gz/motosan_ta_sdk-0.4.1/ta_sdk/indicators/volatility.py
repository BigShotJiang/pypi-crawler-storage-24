import pandas as pd
import numpy as np


def atr(
    high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14
) -> pd.Series:
    """ATR using Wilder's RMA (SMA-seeded), matching pandas-ta."""
    tr = _true_range(high, low, close)
    return _presma_rma(tr, period)


def _true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    """Compute True Range matching pandas-ta (drift=1, prenan=False)."""
    prev_close = close.shift(1)
    tr = pd.concat(
        [
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr


def _sma_seeded_ema(series: pd.Series, period: int) -> pd.Series:
    """SMA-seeded EMA matching pandas-ta's ema(presma=True).

    Replaces first (period-1) values with NaN, sets index (period-1) to
    SMA of first period values, then applies ewm(span=period, adjust=False).
    """
    s = series.copy()
    sma_nth = s.iloc[0:period].mean()
    s.iloc[: period - 1] = np.nan
    s.iloc[period - 1] = sma_nth
    return s.ewm(span=period, adjust=False).mean()


def _presma_rma(series: pd.Series, period: int) -> pd.Series:
    """ATR-style RMA: SMA seed + ewm(alpha=1/period, adjust=False).

    Used by pandas-ta ATR with presma=True: replaces first (period-1) values
    with NaN, sets index (period-1) to SMA of first period values, then
    applies ewm(alpha=1/period, adjust=False).
    """
    s = series.copy()
    sma_nth = s.iloc[0:period].mean()
    s.iloc[: period - 1] = np.nan
    s.iloc[period - 1] = sma_nth
    return s.ewm(alpha=1.0 / period, adjust=False).mean()


def _atr_pta(
    high: pd.Series, low: pd.Series, close: pd.Series, period: int, mamode: str = "rma"
) -> pd.Series:
    """ATR matching pandas-ta (presma=True, given mamode)."""
    tr = _true_range(high, low, close)
    if mamode == "rma":
        return _presma_rma(tr, period)
    else:
        return _sma_seeded_ema(tr, period)


def bollinger_bands(
    close: pd.Series, period: int = 20, std_dev: float = 2.0
) -> tuple[pd.Series, pd.Series, pd.Series]:
    middle = close.rolling(window=period).mean()
    std = close.rolling(window=period).std()
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    return upper, middle, lower


def adx(
    high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Average Directional Index matching pandas-ta.

    Returns (adx, di_plus, di_minus).
    Uses pandas-ta's algorithm: presma ATR, plain ewm RMA for DM, etc.
    """
    high = high.reset_index(drop=True)
    low = low.reset_index(drop=True)
    close = close.reset_index(drop=True)

    # ATR with presma (matching pandas-ta ADX which calls atr(prenan=True))
    tr = _true_range(high, low, close)
    tr.iloc[0] = np.nan  # prenan=True
    atr_val = _presma_rma(tr, period)

    k = 100.0 / atr_val

    # Directional movement (matching pandas-ta: up = high - high.shift(1))
    up = high - high.shift(1)
    dn = low.shift(1) - low

    pos = ((up > dn) & (up > 0)) * up
    neg = ((dn > up) & (dn > 0)) * dn

    # DI+/DI-: k * rma(dm, period) where rma = ewm(alpha=1/period, adjust=False)
    # No presma for DM smoothing
    alpha = 1.0 / period
    dmp = k * pos.ewm(alpha=alpha, adjust=False).mean()
    dmn = k * neg.ewm(alpha=alpha, adjust=False).mean()

    # DX
    dx = 100.0 * (dmp - dmn).abs() / (dmp + dmn)

    # ADX = rma(dx, period), plain ewm, no presma
    adx_val = dx.ewm(alpha=alpha, adjust=False).mean()

    return adx_val, dmp, dmn


def keltner(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 20,
    scalar: float = 2.0,
    atr_length: int = 20,
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Keltner Channels matching pandas-ta.

    basis = SMA-seeded EMA(close)
    band = SMA-seeded EMA(TR)  (not RMA!)
    Returns (lower, basis, upper).
    """
    basis = _sma_seeded_ema(close, period)
    tr = _true_range(high, low, close)
    band = _sma_seeded_ema(tr, atr_length)
    upper = basis + scalar * band
    lower = basis - scalar * band
    return lower, basis, upper


def donchian(
    high: pd.Series, low: pd.Series, period: int = 20
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Donchian Channels: rolling max of high, rolling min of low.

    Returns (lower, mid, upper).
    """
    upper = high.rolling(window=period).max()
    lower = low.rolling(window=period).min()
    mid = (upper + lower) / 2.0
    return lower, mid, upper


def supertrend(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 7,
    multiplier: float = 3.0,
) -> tuple[pd.Series, pd.Series, pd.Series, pd.Series]:
    """Supertrend indicator matching pandas-ta.

    Returns (value, direction, lower_band, upper_band).
    direction: 1.0 = bullish, -1.0 = bearish.
    """
    high = high.reset_index(drop=True)
    low = low.reset_index(drop=True)
    close = close.reset_index(drop=True)
    m = len(close)

    hl2 = (high + low) / 2.0
    matr = multiplier * _atr_pta(high, low, close, period, mamode="rma")

    lb = hl2 - matr  # lower basic band
    ub = hl2 + matr  # upper basic band

    dir_ = [1] * m
    trend = [0.0] * m
    long = [np.nan] * m
    short = [np.nan] * m

    for i in range(1, m):
        if close.iat[i] > ub.iat[i - 1]:
            dir_[i] = 1
        elif close.iat[i] < lb.iat[i - 1]:
            dir_[i] = -1
        else:
            dir_[i] = dir_[i - 1]
            if dir_[i] > 0 and lb.iat[i] < lb.iat[i - 1]:
                lb.iat[i] = lb.iat[i - 1]
            if dir_[i] < 0 and ub.iat[i] > ub.iat[i - 1]:
                ub.iat[i] = ub.iat[i - 1]

        if dir_[i] > 0:
            trend[i] = long[i] = lb.iat[i]
        else:
            trend[i] = short[i] = ub.iat[i]

    # Match pandas-ta: trend[0] = nan, dir[:period] = nan
    trend[0] = np.nan
    dir_[:period] = [np.nan] * period

    value = pd.Series(trend, index=close.index, dtype="float64")
    direction = pd.Series(
        [
            float(d)
            if d is not None and not (isinstance(d, float) and np.isnan(d))
            else np.nan
            for d in dir_
        ],
        index=close.index,
        dtype="float64",
    )
    lower_band = pd.Series(long, index=close.index, dtype="float64")
    upper_band = pd.Series(short, index=close.index, dtype="float64")

    return value, direction, lower_band, upper_band
