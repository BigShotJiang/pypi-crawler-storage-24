import pandas as pd
import numpy as np


def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    direction = close.diff().apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
    return (direction * volume).cumsum()


def volume_sma(volume: pd.Series, period: int = 20) -> pd.Series:
    return volume.rolling(window=period).mean()


def is_high_volume(
    volume: pd.Series, threshold: float = 1.5, period: int = 20
) -> pd.Series:
    avg = volume_sma(volume, period)
    return volume > (avg * threshold)


def cmf(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    volume: pd.Series,
    period: int = 20,
) -> pd.Series:
    """Chaikin Money Flow.

    CMF = SUM(CLV * volume, period) / SUM(volume, period)
    where CLV = ((close - low) - (high - close)) / (high - low).

    Returns values in [-1, 1]. NaN for the first (period - 1) bars.
    """
    hl_range = high - low
    clv = pd.Series(
        np.where(
            hl_range.abs() < 1e-15,
            0.0,
            ((close - low) - (high - close)) / hl_range,
        ),
        index=close.index,
        dtype="float64",
    )

    clv_vol = clv * volume
    sum_clv_vol = clv_vol.rolling(window=period).sum()
    sum_vol = volume.rolling(window=period).sum()

    result = pd.Series(
        np.where(
            sum_vol.abs() < 1e-15,
            0.0,
            sum_clv_vol / sum_vol,
        ),
        index=close.index,
        dtype="float64",
    )

    # First (period - 1) values should be NaN (not enough data)
    result.iloc[: period - 1] = np.nan
    return result


def vwap(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    volume: pd.Series,
    freq: str = "1h",
    anchor: str = "D",
) -> pd.Series:
    """Volume-Weighted Average Price with periodic reset.

    For freq="1h" and anchor="D", resets every 24 bars (daily boundary).
    VWAP = cumulative(TP * volume) / cumulative(volume), reset at each period.
    """
    tp = (high + low + close) / 3.0

    # Determine reset period in bars
    # freq -> bars_per_unit, anchor -> bars_per_anchor
    freq_hours = _parse_freq_hours(freq)
    anchor_hours = _parse_anchor_hours(anchor)
    bars_per_period = int(anchor_hours / freq_hours)

    n = len(close)
    result = pd.Series(np.nan, index=close.index, dtype="float64")

    # Calculate VWAP with periodic resets
    cum_tp_vol = 0.0
    cum_vol = 0.0

    for i in range(n):
        if i % bars_per_period == 0:
            cum_tp_vol = 0.0
            cum_vol = 0.0
        cum_tp_vol += tp.iloc[i] * volume.iloc[i]
        cum_vol += volume.iloc[i]
        if cum_vol > 0:
            result.iloc[i] = cum_tp_vol / cum_vol

    return result


def _parse_freq_hours(freq: str) -> float:
    """Parse frequency string to hours."""
    freq = freq.lower().strip()
    if freq.endswith("h"):
        return float(freq[:-1]) if len(freq) > 1 else 1.0
    elif freq.endswith("min") or freq.endswith("m"):
        val = freq.rstrip("min").rstrip("m")
        return float(val) / 60.0 if val else 1.0 / 60.0
    elif freq.endswith("d"):
        val = freq[:-1]
        return float(val) * 24.0 if val else 24.0
    return 1.0


def _parse_anchor_hours(anchor: str) -> float:
    """Parse anchor string to hours."""
    anchor = anchor.upper().strip()
    if anchor == "D":
        return 24.0
    elif anchor == "W":
        return 168.0
    elif anchor == "M":
        return 720.0  # approximate
    return 24.0
