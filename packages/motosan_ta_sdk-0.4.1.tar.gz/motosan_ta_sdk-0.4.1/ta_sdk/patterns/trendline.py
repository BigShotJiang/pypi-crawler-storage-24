import pandas as pd
import numpy as np
from ta_sdk.data.models import PatternResult


def detect_trendline(
    df: pd.DataFrame, lookback: int = 100, min_touches: int = 3
) -> PatternResult:
    """
    Detect ascending trendline support.
    Finds rising lows that form a support line.
    """
    low = df["low"].iloc[-lookback:]
    close = df["close"].iloc[-lookback:]
    n = len(low)

    if n < 20:
        return PatternResult(
            pattern_type="trendline",
            detected=False,
            confidence=0.0,
            description="Not enough data",
        )

    # Find local lows (swing lows)
    swing_lows = []
    window = 5
    for i in range(window, n - window):
        if low.iloc[i] == low.iloc[i - window : i + window + 1].min():
            swing_lows.append((i, float(low.iloc[i])))

    if len(swing_lows) < min_touches:
        return PatternResult(
            pattern_type="trendline",
            detected=False,
            confidence=0.0,
            description=f"Only {len(swing_lows)} swing lows",
        )

    # Check if swing lows are strictly ascending (not flat)
    ascending = all(
        swing_lows[i][1] < swing_lows[i + 1][1] for i in range(len(swing_lows) - 1)
    )

    if not ascending:
        return PatternResult(
            pattern_type="trendline",
            detected=False,
            confidence=0.0,
            description="Swing lows not ascending",
        )

    # Linear regression on swing lows
    x = np.array([s[0] for s in swing_lows], dtype=float)
    y = np.array([s[1] for s in swing_lows])
    slope, intercept = np.polyfit(x, y, 1)

    min_slope = 1e-6
    if slope < min_slope:
        return PatternResult(
            pattern_type="trendline",
            detected=False,
            confidence=0.0,
            description="Trendline slope not positive",
        )

    # Calculate R-squared for fit quality
    y_pred = slope * x + intercept
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0

    confidence = 0.3
    if len(swing_lows) >= 4:
        confidence += 0.2
    if r_squared > 0.8:
        confidence += 0.3
    if close.iloc[-1] > intercept + slope * (n - 1):
        confidence += 0.2  # price above trendline

    trendline_now = intercept + slope * (n - 1)

    return PatternResult(
        pattern_type="trendline",
        detected=True,
        confidence=min(1.0, confidence),
        key_levels={
            "trendline_support": round(trendline_now, 2),
            "slope_per_bar": round(slope, 4),
        },
        description=(
            f"Ascending trendline: {len(swing_lows)} touches, "
            f"R²={r_squared:.2f}, support at {trendline_now:.2f}"
        ),
    )
