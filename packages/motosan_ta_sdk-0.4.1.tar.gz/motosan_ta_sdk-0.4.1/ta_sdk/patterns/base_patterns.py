import pandas as pd
from ta_sdk.data.models import PatternResult


def detect_flat_base(
    df: pd.DataFrame,
    lookback: int = 60,
    max_range_pct: float = 15.0,
    min_weeks: int = 3,
) -> PatternResult:
    """
    Detect Flat Base pattern.
    Price consolidates in a tight range after uptrend.
    """
    close = df["close"].iloc[-lookback:]
    n = len(close)

    if n < min_weeks * 5:
        return PatternResult(
            pattern_type="flat_base",
            detected=False,
            confidence=0.0,
            description="Not enough data",
        )

    high_price = close.max()
    low_price = close.min()
    range_pct = (high_price - low_price) / high_price * 100

    if range_pct > max_range_pct:
        return PatternResult(
            pattern_type="flat_base",
            detected=False,
            confidence=0.0,
            description=f"Range {range_pct:.1f}% exceeds {max_range_pct}%",
        )

    # Check price is near highs (not a flat base at lows)
    current = close.iloc[-1]
    pct_from_high = (high_price - current) / high_price * 100
    if pct_from_high > max_range_pct:
        return PatternResult(
            pattern_type="flat_base",
            detected=False,
            confidence=0.0,
            description="Price not near base highs",
        )

    confidence = 0.4
    if range_pct < 10:
        confidence += 0.2
    if range_pct < 7:
        confidence += 0.2
    if pct_from_high < 5:
        confidence += 0.2

    return PatternResult(
        pattern_type="flat_base",
        detected=True,
        confidence=min(1.0, confidence),
        key_levels={"pivot": float(high_price), "base_low": float(low_price)},
        description=(
            f"Flat Base: {range_pct:.1f}% range over {n} bars, "
            f"pivot at {high_price:.2f}"
        ),
    )
