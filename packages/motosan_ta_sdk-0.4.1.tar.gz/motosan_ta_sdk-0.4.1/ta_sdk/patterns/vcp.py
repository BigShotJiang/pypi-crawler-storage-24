import pandas as pd
import numpy as np
from ta_sdk.data.models import PatternResult


def detect_vcp(
    df: pd.DataFrame,
    min_contractions: int = 2,
    max_last_contraction_pct: float = 15.0,
    lookback: int = 100,
) -> PatternResult:
    """
    Detect Volatility Contraction Pattern.
    Looks for contracting price swings with declining volume.
    """
    high = df["high"].iloc[-lookback:]
    low = df["low"].iloc[-lookback:]
    volume = df["volume"].iloc[-lookback:]

    # Find swing highs and lows
    swings = _find_swings(high, low, window=5)
    if len(swings) < min_contractions * 2:
        return PatternResult(
            pattern_type="vcp",
            detected=False,
            confidence=0.0,
            description="Not enough swings",
        )

    contractions = _measure_contractions(swings)
    if len(contractions) < min_contractions:
        return PatternResult(
            pattern_type="vcp",
            detected=False,
            confidence=0.0,
            description="Not enough contractions",
        )

    # Check contractions are decreasing
    is_contracting = all(
        contractions[i] >= contractions[i + 1] for i in range(len(contractions) - 1)
    )
    if not is_contracting:
        return PatternResult(
            pattern_type="vcp",
            detected=False,
            confidence=0.0,
            description="Contractions not decreasing",
        )

    # Check last contraction size
    if contractions[-1] > max_last_contraction_pct:
        return PatternResult(
            pattern_type="vcp",
            detected=False,
            confidence=0.0,
            description=f"Last contraction {contractions[-1]:.1f}% > {max_last_contraction_pct}%",
        )

    # Check volume declining (linear regression slope)
    vol_values = volume.values.astype(float)
    slope = np.polyfit(range(len(vol_values)), vol_values, 1)[0]
    volume_declining = slope < 0

    confidence = _calc_confidence(contractions, volume_declining)

    # Pivot = last swing high (more accurate than rolling max)
    last_swing_high = next(
        (s["price"] for s in reversed(swings) if s["type"] == "high"),
        float(high.iloc[-20:].max()),
    )

    return PatternResult(
        pattern_type="vcp",
        detected=True,
        confidence=confidence,
        key_levels={"pivot": last_swing_high, "stop": float(low.iloc[-20:].min())},
        contractions=[round(c, 1) for c in contractions],
        description=(
            f"VCP detected: {len(contractions)} contractions "
            f"({' -> '.join(f'{c:.0f}%' for c in contractions)}), "
            f"volume {'declining' if volume_declining else 'not declining'}"
        ),
    )


def _find_swings(high: pd.Series, low: pd.Series, window: int = 5) -> list[dict]:
    swings = []
    for i in range(window, len(high) - window):
        if high.iloc[i] == high.iloc[i - window : i + window + 1].max():
            swings.append({"type": "high", "idx": i, "price": float(high.iloc[i])})
        if low.iloc[i] == low.iloc[i - window : i + window + 1].min():
            swings.append({"type": "low", "idx": i, "price": float(low.iloc[i])})
    swings.sort(key=lambda s: s["idx"])
    return swings


def _measure_contractions(swings: list[dict]) -> list[float]:
    """Measure contractions from temporally ordered high→low pairs."""
    contractions = []
    i = 0
    while i < len(swings) - 1:
        if swings[i]["type"] == "high" and swings[i + 1]["type"] == "low":
            h = swings[i]["price"]
            lo = swings[i + 1]["price"]
            if h > 0:
                contractions.append((h - lo) / h * 100)
            i += 2
        else:
            i += 1
    return contractions


def _calc_confidence(contractions: list[float], volume_declining: bool) -> float:
    score = 0.3  # base
    if len(contractions) >= 3:
        score += 0.2
    if contractions[-1] < 10:
        score += 0.2
    if volume_declining:
        score += 0.2
    if len(contractions) >= 2 and contractions[-1] < contractions[0] * 0.5:
        score += 0.1
    return min(1.0, score)
