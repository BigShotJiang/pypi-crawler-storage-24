import pandas as pd
from ta_sdk.data.models import PatternResult


def detect_cup_handle(
    df: pd.DataFrame,
    lookback: int = 100,
    min_cup_depth_pct: float = 10.0,
    max_cup_depth_pct: float = 35.0,
) -> PatternResult:
    """
    Detect Cup & Handle pattern.
    Looks for U-shape cup followed by small handle pullback.
    """
    close = df["close"].iloc[-lookback:]
    high = df["high"].iloc[-lookback:]
    low = df["low"].iloc[-lookback:]

    n = len(close)
    if n < 30:
        return PatternResult(
            pattern_type="cup_handle",
            detected=False,
            confidence=0.0,
            description="Not enough data",
        )

    # Find highest point in first third (left lip)
    left_third = int(n * 0.35)
    left_lip_idx = high.iloc[:left_third].idxmax()
    left_lip = float(high.loc[left_lip_idx])

    # Find lowest point in middle (cup bottom)
    mid_start = int(n * 0.2)
    mid_end = int(n * 0.7)
    cup_bottom_idx = low.iloc[mid_start:mid_end].idxmin()
    cup_bottom = float(low.loc[cup_bottom_idx])

    # Find highest in last third (right lip)
    right_third_start = int(n * 0.6)
    right_lip_idx = high.iloc[right_third_start:].idxmax()
    right_lip = float(high.loc[right_lip_idx])

    # Cup depth check
    cup_depth_pct = (left_lip - cup_bottom) / left_lip * 100
    if cup_depth_pct < min_cup_depth_pct or cup_depth_pct > max_cup_depth_pct:
        return PatternResult(
            pattern_type="cup_handle",
            detected=False,
            confidence=0.0,
            description=f"Cup depth {cup_depth_pct:.1f}% out of range",
        )

    # Right lip should be near left lip (within 5%)
    lip_diff = abs(right_lip - left_lip) / left_lip * 100
    if lip_diff > 10:
        return PatternResult(
            pattern_type="cup_handle",
            detected=False,
            confidence=0.0,
            description=f"Lips differ by {lip_diff:.1f}%",
        )

    # Handle: small pullback from right lip
    handle_start = right_lip_idx
    handle_section = close.loc[handle_start:]
    if len(handle_section) < 3:
        handle_depth_pct = 0.0
    else:
        handle_low = float(handle_section.min())
        handle_depth_pct = (right_lip - handle_low) / right_lip * 100

    confidence = 0.4
    if 15 <= cup_depth_pct <= 30:
        confidence += 0.2
    if handle_depth_pct < 12:
        confidence += 0.2
    if lip_diff < 5:
        confidence += 0.2

    pivot = max(left_lip, right_lip)

    return PatternResult(
        pattern_type="cup_handle",
        detected=True,
        confidence=min(1.0, confidence),
        key_levels={"pivot": pivot, "cup_bottom": cup_bottom},
        description=(
            f"Cup & Handle: depth {cup_depth_pct:.1f}%, "
            f"handle {handle_depth_pct:.1f}%, pivot {pivot:.2f}"
        ),
    )
