import pandas as pd
from ta_sdk.data.models import PatternResult


def detect_double_bottom(
    df: pd.DataFrame, lookback: int = 100, tolerance_pct: float = 3.0
) -> PatternResult:
    """
    Detect Double Bottom (W pattern).
    Two lows at similar price with a peak in between.
    """
    close = df["close"].iloc[-lookback:]
    high = df["high"].iloc[-lookback:]
    low = df["low"].iloc[-lookback:]
    n = len(close)

    if n < 30:
        return PatternResult(
            pattern_type="double_bottom",
            detected=False,
            confidence=0.0,
            description="Not enough data",
        )

    # Split into halves and find lowest in each
    mid = n // 2
    first_low_idx = low.iloc[:mid].idxmin()
    first_low = float(low.loc[first_low_idx])

    second_low_idx = low.iloc[mid:].idxmin()
    second_low = float(low.loc[second_low_idx])

    # Find peak between the two lows
    start_idx = first_low_idx
    end_idx = second_low_idx
    if start_idx >= end_idx:
        return PatternResult(
            pattern_type="double_bottom",
            detected=False,
            confidence=0.0,
            description="Invalid low positions",
        )

    between = high.loc[start_idx:end_idx]
    if len(between) < 3:
        return PatternResult(
            pattern_type="double_bottom",
            detected=False,
            confidence=0.0,
            description="No middle peak",
        )

    middle_peak = float(between.max())

    # Check two lows are similar (within tolerance)
    avg_low = (first_low + second_low) / 2
    diff_pct = abs(first_low - second_low) / avg_low * 100
    if diff_pct > tolerance_pct:
        return PatternResult(
            pattern_type="double_bottom",
            detected=False,
            confidence=0.0,
            description=f"Lows differ by {diff_pct:.1f}%",
        )

    # Peak should be meaningful above lows
    peak_above_pct = (middle_peak - avg_low) / avg_low * 100
    if peak_above_pct < 3:
        return PatternResult(
            pattern_type="double_bottom",
            detected=False,
            confidence=0.0,
            description="Middle peak not significant",
        )

    confidence = 0.4
    if diff_pct < 1.5:
        confidence += 0.2
    if peak_above_pct > 5:
        confidence += 0.2
    if close.iloc[-1] > middle_peak:
        confidence += 0.2  # breakout confirmation

    return PatternResult(
        pattern_type="double_bottom",
        detected=True,
        confidence=min(1.0, confidence),
        key_levels={
            "neckline": middle_peak,
            "first_low": first_low,
            "second_low": second_low,
        },
        description=(
            f"Double Bottom: lows at {first_low:.2f}/{second_low:.2f}, "
            f"neckline {middle_peak:.2f}"
        ),
    )
