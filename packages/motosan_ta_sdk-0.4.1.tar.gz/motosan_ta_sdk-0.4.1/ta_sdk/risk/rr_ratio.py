def calc_rr_ratio(entry: float, stop: float, target: float) -> float:
    """Calculate risk-reward ratio."""
    risk = entry - stop
    reward = target - entry
    if risk <= 0:
        return 0.0
    return round(reward / risk, 2)
