def calc_stop_fixed_pct(entry: float, pct: float) -> float:
    """Calculate stop loss at a fixed percentage below entry."""
    return entry * (1 - pct / 100)


def calc_stop_atr(entry: float, atr: float, multiplier: float = 2.0) -> float:
    """Calculate stop loss using ATR-based distance."""
    return entry - (atr * multiplier)


def calc_stop_pattern(
    entry: float, pattern_low: float, buffer_pct: float = 1.0
) -> float:
    """Calculate stop loss below a pattern low with a buffer."""
    return pattern_low * (1 - buffer_pct / 100)
