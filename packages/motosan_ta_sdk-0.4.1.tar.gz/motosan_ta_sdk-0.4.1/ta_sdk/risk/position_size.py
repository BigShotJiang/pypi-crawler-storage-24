def calc_position_size(
    account_value: float, risk_pct: float, entry: float, stop: float
) -> dict:
    """Calculate position size based on account risk percentage."""
    risk_amount = account_value * (risk_pct / 100)
    risk_per_share = entry - stop
    if risk_per_share <= 0:
        return {"shares": 0, "position_value": 0, "risk_amount": 0}
    shares = int(risk_amount / risk_per_share)
    return {
        "shares": shares,
        "position_value": round(shares * entry, 2),
        "position_pct": round(shares * entry / account_value * 100, 2),
        "risk_amount": round(risk_amount, 2),
    }
