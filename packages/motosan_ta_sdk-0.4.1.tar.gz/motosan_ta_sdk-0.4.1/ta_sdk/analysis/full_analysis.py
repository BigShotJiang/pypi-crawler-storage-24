import pandas as pd
from ta_sdk.data.models import AnalysisReport
from ta_sdk.indicators.moving_averages import sma, ema
from ta_sdk.indicators.momentum import rsi, macd
from ta_sdk.indicators.volatility import atr
from ta_sdk.screeners.stage2 import check_stage2
from ta_sdk.screeners.canslim import check_canslim
from ta_sdk.screeners.entry_signal import check_entry_signal


def analyze_stock(
    df: pd.DataFrame, symbol: str = "", fundamentals: dict | None = None
) -> AnalysisReport:
    """
    Full stock analysis orchestrator.
    Combines indicators, screeners, and pattern checks into one report.
    """
    close = df["close"]
    current = float(close.iloc[-1])

    # Indicators
    sma50_val = float(sma(close, 50).iloc[-1]) if len(close) >= 50 else None
    sma200_val = float(sma(close, 200).iloc[-1]) if len(close) >= 200 else None
    ema21_val = float(ema(close, 21).iloc[-1]) if len(close) >= 21 else None
    rsi_val = float(rsi(close, 14).iloc[-1]) if len(close) >= 15 else None
    macd_result = macd(close) if len(close) >= 26 else (None, None, None)
    atr_val = (
        float(atr(df["high"], df["low"], close, 14).iloc[-1])
        if len(close) >= 15
        else None
    )

    indicators = {
        "price": current,
        "sma50": sma50_val,
        "sma200": sma200_val,
        "ema21": ema21_val,
        "rsi": round(rsi_val, 2) if rsi_val else None,
        "atr": round(atr_val, 2) if atr_val else None,
    }

    macd_line, signal_line, _ = macd_result
    if macd_line is not None:
        indicators["macd"] = round(float(macd_line.iloc[-1]), 4)
        indicators["macd_signal"] = round(float(signal_line.iloc[-1]), 4)

    # Trend determination
    if sma50_val and sma200_val:
        if current > sma50_val > sma200_val:
            trend = "stage2_advancing"
        elif current < sma50_val < sma200_val:
            trend = "stage4_declining"
        elif current > sma200_val:
            trend = "stage1_accumulation"
        else:
            trend = "stage3_distribution"
    else:
        trend = "unknown"

    # Screeners
    stage2_result = (
        check_stage2(df)
        if len(close) >= 200
        else {"passes": False, "score": 0, "max_score": 7, "checks": {}}
    )
    entry_result = (
        check_entry_signal(df)
        if len(close) >= 50
        else {"signal": False, "reason": "Not enough data"}
    )

    canslim_result = check_canslim(df, fundamentals) if fundamentals else None

    return AnalysisReport(
        symbol=symbol,
        trend=trend,
        indicators=indicators,
        stage2=stage2_result,
        entry_signal=entry_result,
        canslim=canslim_result,
    )
