import pandas as pd
from ta_sdk.indicators.moving_averages import sma


def check_market_health(sp500_df: pd.DataFrame, vix: float | None = None) -> dict:
    """
    Market health check based on S&P 500 data:
    - Price vs 200 SMA
    - 50 SMA vs 200 SMA (golden/death cross)
    - Optional VIX level
    """
    close = sp500_df["close"]
    current = float(close.iloc[-1])

    sma200_val = float(sma(close, 200).iloc[-1])
    sma50_val = float(sma(close, 50).iloc[-1])

    above_200sma = current > sma200_val
    golden_cross = sma50_val > sma200_val

    # Determine condition
    if above_200sma and golden_cross:
        condition = "bullish"
    elif not above_200sma and not golden_cross:
        condition = "bearish"
    else:
        condition = "neutral"

    # VIX adjustment
    if vix is not None:
        if vix > 30:
            condition = "bearish"
        elif vix > 20 and condition == "bullish":
            condition = "neutral"

    return {
        "condition": condition,
        "sp500_above_200sma": above_200sma,
        "golden_cross": golden_cross,
        "vix": vix,
        "description": f"Market {condition}: SP500 {'above' if above_200sma else 'below'} 200 SMA",
    }
