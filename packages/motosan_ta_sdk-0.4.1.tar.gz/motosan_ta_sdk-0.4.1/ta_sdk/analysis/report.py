def generate_report(analysis: dict) -> str:
    """Generate a markdown report from analysis results."""
    symbol = analysis.get("symbol", "Unknown")
    ind = analysis.get("indicators", {})
    stage2 = analysis.get("stage2", {})
    entry = analysis.get("entry_signal", {})

    lines = [
        f"# {symbol} Technical Analysis Report",
        "",
        "## Trend",
        f"- Stage: **{analysis.get('trend', 'unknown')}**",
        "",
        "## Key Indicators",
        f"- Price: ${ind.get('price', 0):.2f}",
    ]

    if ind.get("sma50"):
        lines.append(f"- 50 SMA: ${ind['sma50']:.2f}")
    if ind.get("sma200"):
        lines.append(f"- 200 SMA: ${ind['sma200']:.2f}")
    if ind.get("rsi"):
        lines.append(f"- RSI(14): {ind['rsi']}")
    if ind.get("atr"):
        lines.append(f"- ATR(14): {ind['atr']}")

    lines += [
        "",
        "## Stage 2 Check",
        f"- Passes: **{'Yes' if stage2.get('passes') else 'No'}** ({stage2.get('score', 0)}/{stage2.get('max_score', 7)})",
    ]

    for check, val in stage2.get("checks", {}).items():
        lines.append(f"  - {check}: {'Pass' if val else 'Fail'}")

    lines += [
        "",
        "## Entry Signal",
        f"- Signal: **{'Yes' if entry.get('signal') else 'No'}**",
        f"- Reason: {entry.get('reason', 'N/A')}",
    ]

    if entry.get("signal"):
        lines.append(f"- Buy point: ${entry.get('buy_point', 0):.2f}")
        lines.append(f"- Stop: ${entry.get('stop', 0):.2f}")
        lines.append(f"- Risk: {entry.get('risk_pct', 0):.2f}%")

    canslim = analysis.get("canslim")
    if canslim:
        lines += [
            "",
            "## CANSLIM",
            f"- Passes: **{'Yes' if canslim.get('passes') else 'No'}** ({canslim.get('score', 0)}/{canslim.get('max_score', 7)})",
        ]

    return "\n".join(lines)
