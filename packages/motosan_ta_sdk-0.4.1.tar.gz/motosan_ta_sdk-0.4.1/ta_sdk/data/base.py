from abc import ABC, abstractmethod
from ta_sdk.data.models import Market, OHLCVData, Quote, Financials, Earnings


class DataProvider(ABC):
    @abstractmethod
    def get_ohlcv(
        self, symbol: str, period: str = "1y", interval: str = "1d"
    ) -> OHLCVData: ...

    @abstractmethod
    def get_quote(self, symbol: str) -> Quote: ...

    @abstractmethod
    def supports_market(self, market: Market) -> bool: ...


class FundamentalProvider(ABC):
    @abstractmethod
    def get_financials(self, symbol: str) -> Financials: ...

    @abstractmethod
    def get_earnings(self, symbol: str, quarters: int = 4) -> list[Earnings]: ...
