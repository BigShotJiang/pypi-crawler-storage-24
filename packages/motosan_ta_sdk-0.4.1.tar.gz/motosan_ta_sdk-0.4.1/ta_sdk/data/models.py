from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any
import pandas as pd


class Market(Enum):
    US = "us"
    TW = "tw"
    CRYPTO = "crypto"


class TrendStage(Enum):
    STAGE1 = "stage1_accumulation"
    STAGE2 = "stage2_advancing"
    STAGE3 = "stage3_distribution"
    STAGE4 = "stage4_declining"
    UNKNOWN = "unknown"


class EntrySignal(Enum):
    GO = "go"
    WAIT = "wait"
    NO = "no"


class MarketCondition(Enum):
    BULLISH = "bullish"
    NEUTRAL = "neutral"
    BEARISH = "bearish"


@dataclass
class OHLCVData:
    symbol: str
    market: Market
    df: pd.DataFrame  # columns: open, high, low, close, volume
    currency: str
    timezone: str


@dataclass
class Quote:
    symbol: str
    price: float
    volume: int
    change_pct: float
    market: Market


@dataclass
class Earnings:
    date: str
    eps_actual: float | None
    eps_estimate: float | None
    revenue_actual: float | None
    revenue_estimate: float | None


@dataclass
class Financials:
    symbol: str
    market_cap: float | None
    pe_ratio: float | None
    eps_ttm: float | None
    revenue_growth_yoy: float | None
    gross_margin: float | None
    earnings: list[Earnings] = field(default_factory=list)


@dataclass
class PatternResult:
    pattern_type: str
    detected: bool
    confidence: float  # 0.0 ~ 1.0
    key_levels: dict = field(default_factory=dict)
    contractions: list = field(default_factory=list)
    description: str = ""


@dataclass
class RiskAssessment:
    stop_price: float
    stop_pct: float
    position_size_pct: float
    risk_reward_ratio: float
    description: str = ""


@dataclass
class MarketHealth:
    condition: MarketCondition
    vix: float | None = None
    sp500_above_200sma: bool | None = None
    description: str = ""


@dataclass
class AnalysisReport:
    symbol: str
    trend: str
    indicators: dict[str, Any] = field(default_factory=dict)
    stage2: dict[str, Any] = field(default_factory=dict)
    entry_signal: dict[str, Any] = field(default_factory=dict)
    canslim: dict[str, Any] | None = None

    # ---------- backward-compat helpers ----------

    def to_dict(self) -> dict[str, Any]:
        """Return a plain dict identical to the legacy format."""
        d: dict[str, Any] = {
            "symbol": self.symbol,
            "trend": self.trend,
            "indicators": self.indicators,
            "stage2": self.stage2,
            "entry_signal": self.entry_signal,
        }
        if self.canslim is not None:
            d["canslim"] = self.canslim
        return d

    # allow dict-style read access so existing callers keep working
    def __getitem__(self, key: str) -> Any:
        return self.to_dict()[key]

    def __contains__(self, key: str) -> bool:
        return key in self.to_dict()

    def get(self, key: str, default: Any = None) -> Any:
        return self.to_dict().get(key, default)
