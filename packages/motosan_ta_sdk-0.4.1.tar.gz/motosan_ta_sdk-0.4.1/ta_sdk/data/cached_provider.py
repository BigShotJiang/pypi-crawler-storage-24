from __future__ import annotations

try:
    import diskcache
except ImportError:
    raise ImportError(
        "diskcache is required for CachedProvider. "
        "Install it with: pip install ta-sdk[cache]"
    )

from ta_sdk.data.base import DataProvider
from ta_sdk.data.models import Market, OHLCVData, Quote


class CachedProvider(DataProvider):
    """A DataProvider wrapper that caches results using diskcache."""

    def __init__(
        self,
        provider: DataProvider,
        cache_dir: str = ".ta_cache",
        ohlcv_ttl: int = 3600,
        quote_ttl: int = 60,
    ):
        self._provider = provider
        self._cache = diskcache.Cache(cache_dir)
        self._ohlcv_ttl = ohlcv_ttl
        self._quote_ttl = quote_ttl

    def get_ohlcv(
        self, symbol: str, period: str = "1y", interval: str = "1d"
    ) -> OHLCVData:
        key = f"ohlcv:{symbol}:{period}:{interval}"
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        result = self._provider.get_ohlcv(symbol, period, interval)
        self._cache.set(key, result, expire=self._ohlcv_ttl)
        return result

    def get_quote(self, symbol: str) -> Quote:
        key = f"quote:{symbol}"
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        result = self._provider.get_quote(symbol)
        self._cache.set(key, result, expire=self._quote_ttl)
        return result

    def supports_market(self, market: Market) -> bool:
        return self._provider.supports_market(market)

    def clear(self) -> None:
        """Clear all cached data."""
        self._cache.clear()

    def close(self) -> None:
        """Close the underlying diskcache."""
        self._cache.close()
