import pandas as pd
from binance.client import Client
from ta_sdk.data.base import DataProvider
from ta_sdk.data.models import Market, OHLCVData, Quote


class BinanceProvider(DataProvider):
    """Binance data provider using public REST API. No API key required."""

    def __init__(self):
        self.client = Client("", "", tld="com")

    def supports_market(self, market: Market) -> bool:
        return market == Market.CRYPTO

    def get_ohlcv(
        self, symbol: str, period: str = "1y", interval: str = "1d"
    ) -> OHLCVData:
        kline_interval = Client.KLINE_INTERVAL_1DAY
        klines = self.client.get_historical_klines(
            symbol, kline_interval, f"{period} ago UTC"
        )
        df = pd.DataFrame(
            klines,
            columns=[
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "close_time",
                "quote_vol",
                "trades",
                "taker_buy_base",
                "taker_buy_quote",
                "ignore",
            ],
        )
        df["date"] = pd.to_datetime(df["timestamp"], unit="ms")
        df = df.set_index("date")
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = df[col].astype(float)
        df = df[["open", "high", "low", "close", "volume"]]
        return OHLCVData(
            symbol=symbol, market=Market.CRYPTO, df=df, currency="USDT", timezone="UTC"
        )

    def get_quote(self, symbol: str) -> Quote:
        ticker = self.client.get_ticker(symbol=symbol)
        return Quote(
            symbol=symbol,
            price=float(ticker["lastPrice"]),
            volume=int(float(ticker["volume"])),
            change_pct=float(ticker["priceChangePercent"]),
            market=Market.CRYPTO,
        )
