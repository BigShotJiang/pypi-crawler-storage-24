import re
from ta_sdk.data.base import DataProvider
from ta_sdk.data.models import Market, OHLCVData, Quote

# Common crypto pairs on Binance end with USDT/BUSD/BTC etc.
_CRYPTO_PATTERN = re.compile(r"^[A-Z0-9]{2,12}(USDT|USDC|BUSD|FDUSD|BTC|ETH|BNB)$")


def detect_market(symbol: str) -> Market:
    if symbol.endswith(".TW") or symbol.endswith(".TWO"):
        return Market.TW
    if _CRYPTO_PATTERN.match(symbol):
        return Market.CRYPTO
    return Market.US


class MultiProvider(DataProvider):
    def __init__(self, providers: dict[Market, DataProvider] | None = None):
        self._providers = providers or {}

    def register(self, market: Market, provider: DataProvider):
        self._providers[market] = provider

    def supports_market(self, market: Market) -> bool:
        return market in self._providers

    def get_ohlcv(
        self, symbol: str, period: str = "1y", interval: str = "1d"
    ) -> OHLCVData:
        market = detect_market(symbol)
        return self._providers[market].get_ohlcv(symbol, period, interval)

    def get_quote(self, symbol: str) -> Quote:
        market = detect_market(symbol)
        return self._providers[market].get_quote(symbol)
