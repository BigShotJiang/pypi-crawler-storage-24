import requests
from ta_sdk.data.base import FundamentalProvider
from ta_sdk.data.models import Financials, Earnings

BASE_URL = "https://financialmodelingprep.com/stable"


class FMPProvider(FundamentalProvider):
    def __init__(self, api_key: str):
        self.api_key = api_key

    def _get(self, endpoint: str, params: dict | None = None) -> dict | list:
        params = params or {}
        params["apikey"] = self.api_key
        r = requests.get(f"{BASE_URL}/{endpoint}", params=params, timeout=10)
        r.raise_for_status()
        return r.json()

    def get_financials(self, symbol: str) -> Financials:
        data = self._get("profile", {"symbol": symbol})
        if isinstance(data, list) and data:
            d = data[0]
        elif isinstance(data, dict):
            d = data
        else:
            return Financials(
                symbol=symbol,
                market_cap=None,
                pe_ratio=None,
                eps_ttm=None,
                revenue_growth_yoy=None,
                gross_margin=None,
            )
        return Financials(
            symbol=symbol,
            market_cap=d.get("mktCap"),
            pe_ratio=d.get("pe"),
            eps_ttm=d.get("eps"),
            revenue_growth_yoy=None,
            gross_margin=None,
        )

    def get_earnings(self, symbol: str, quarters: int = 4) -> list[Earnings]:
        data = self._get("earnings-surprises", {"symbol": symbol})
        if not isinstance(data, list):
            return []
        results = []
        for d in data[:quarters]:
            results.append(
                Earnings(
                    date=d.get("date", ""),
                    eps_actual=d.get("actualEarningResult"),
                    eps_estimate=d.get("estimatedEarning"),
                    revenue_actual=None,
                    revenue_estimate=None,
                )
            )
        return results
