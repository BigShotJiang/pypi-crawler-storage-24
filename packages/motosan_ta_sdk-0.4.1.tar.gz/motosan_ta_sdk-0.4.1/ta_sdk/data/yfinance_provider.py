import yfinance as yf
from ta_sdk.data.base import DataProvider
from ta_sdk.data.models import Market, OHLCVData, Quote
from ta_sdk.data.multi import detect_market


class YFinanceProvider(DataProvider):
    def supports_market(self, market: Market) -> bool:
        return market in (Market.US, Market.TW)

    def get_ohlcv(
        self, symbol: str, period: str = "1y", interval: str = "1d"
    ) -> OHLCVData:
        ticker = yf.Ticker(symbol)
        df = ticker.history(period=period, interval=interval)
        df.columns = [c.lower() for c in df.columns]
        df = df[["open", "high", "low", "close", "volume"]]
        df.index.name = "date"
        market = detect_market(symbol)
        currency = "TWD" if market == Market.TW else "USD"
        tz = "Asia/Taipei" if market == Market.TW else "America/New_York"
        return OHLCVData(
            symbol=symbol, market=market, df=df, currency=currency, timezone=tz
        )

    def get_quote(self, symbol: str) -> Quote:
        ticker = yf.Ticker(symbol)
        info = ticker.fast_info
        market = detect_market(symbol)
        return Quote(
            symbol=symbol,
            price=float(info.last_price),
            volume=int(info.last_volume or 0),
            change_pct=round(
                (info.last_price - info.previous_close) / info.previous_close * 100, 2
            )
            if info.previous_close
            else 0.0,
            market=market,
        )
