from ta_sdk.risk.position_size import calc_position_size


def test_position_size_normal():
    result = calc_position_size(
        account_value=100000, risk_pct=1.0, entry=50.0, stop=46.0
    )
    assert result["shares"] == 250  # 1000 / 4 = 250
    assert result["position_value"] == 12500.0
    assert result["risk_amount"] == 1000.0


def test_position_size_zero_risk():
    result = calc_position_size(
        account_value=100000, risk_pct=1.0, entry=50.0, stop=50.0
    )
    assert result["shares"] == 0
