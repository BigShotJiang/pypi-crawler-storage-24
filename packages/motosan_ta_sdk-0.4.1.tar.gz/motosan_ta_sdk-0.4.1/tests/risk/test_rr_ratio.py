from ta_sdk.risk.rr_ratio import calc_rr_ratio


def test_rr_ratio_normal():
    rr = calc_rr_ratio(entry=100.0, stop=92.0, target=124.0)
    assert rr == 3.0  # 24/8 = 3.0


def test_rr_ratio_zero_risk():
    rr = calc_rr_ratio(entry=100.0, stop=100.0, target=110.0)
    assert rr == 0.0
