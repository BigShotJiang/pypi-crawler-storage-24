from ta_sdk.risk.stop_loss import calc_stop_atr, calc_stop_fixed_pct, calc_stop_pattern


def test_fixed_pct_stop():
    stop = calc_stop_fixed_pct(entry=100.0, pct=8.0)
    assert stop == 92.0


def test_atr_stop():
    stop = calc_stop_atr(entry=100.0, atr=3.0, multiplier=2.0)
    assert stop == 94.0


def test_pattern_stop():
    stop = calc_stop_pattern(entry=100.0, pattern_low=95.0, buffer_pct=1.0)
    assert stop == 94.05
