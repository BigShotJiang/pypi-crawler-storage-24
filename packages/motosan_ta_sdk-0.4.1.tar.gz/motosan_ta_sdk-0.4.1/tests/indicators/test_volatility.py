import pandas as pd
import numpy as np
from ta_sdk.indicators.volatility import (
    atr,
    bollinger_bands,
    adx,
    keltner,
    donchian,
    supertrend,
)


def _sample_ohlcv(n=100, seed=42):
    rng = np.random.default_rng(seed)
    close = pd.Series(100 + np.cumsum(rng.standard_normal(n)))
    high = close + rng.uniform(0.5, 2.0, n)
    low = close - rng.uniform(0.5, 2.0, n)
    return high, low, close


def test_atr_positive():
    high, low, close = _sample_ohlcv()
    result = atr(high, low, close, period=14)
    valid = result.dropna()
    assert (valid > 0).all()


def test_bollinger_upper_gt_lower():
    _, _, close = _sample_ohlcv()
    upper, middle, lower = bollinger_bands(close)
    valid_idx = upper.dropna().index
    assert (upper[valid_idx] >= middle[valid_idx]).all()
    assert (middle[valid_idx] >= lower[valid_idx]).all()


# --- ADX tests ---


def test_adx_returns_three_series():
    high, low, close = _sample_ohlcv()
    adx_val, dip, dim = adx(high, low, close, period=14)
    assert len(adx_val) == len(close)
    assert len(dip) == len(close)
    assert len(dim) == len(close)


def test_adx_bounded():
    high, low, close = _sample_ohlcv(n=200)
    adx_val, dip, dim = adx(high, low, close, period=14)
    valid_adx = adx_val.dropna()
    valid_dip = dip.dropna()
    valid_dim = dim.dropna()
    assert (valid_adx >= 0).all()
    assert (valid_dip >= 0).all()
    assert (valid_dim >= 0).all()


def test_adx_has_nan_warmup():
    high, low, close = _sample_ohlcv(n=50)
    adx_val, _, _ = adx(high, low, close, period=14)
    assert adx_val.iloc[:1].isna().any()
    assert adx_val.iloc[-1:].notna().all()


# --- Keltner tests ---


def test_keltner_returns_three_series():
    high, low, close = _sample_ohlcv()
    lower, basis, upper = keltner(high, low, close)
    assert len(lower) == len(close)
    assert len(basis) == len(close)
    assert len(upper) == len(close)


def test_keltner_upper_gt_lower():
    high, low, close = _sample_ohlcv()
    lower, basis, upper = keltner(high, low, close)
    valid = upper.dropna().index
    assert (upper[valid] >= basis[valid]).all()
    assert (basis[valid] >= lower[valid]).all()


# --- Donchian tests ---


def test_donchian_returns_three_series():
    high, low, _ = _sample_ohlcv()
    lower, mid, upper = donchian(high, low, period=20)
    assert len(lower) == len(high)
    assert len(mid) == len(high)
    assert len(upper) == len(high)


def test_donchian_upper_is_rolling_max():
    high, low, _ = _sample_ohlcv()
    lower, mid, upper = donchian(high, low, period=20)
    valid = upper.dropna().index
    assert (upper[valid] >= lower[valid]).all()
    expected_mid = (upper[valid] + lower[valid]) / 2.0
    np.testing.assert_allclose(mid[valid].values, expected_mid.values, atol=1e-10)


# --- Supertrend tests ---


def test_supertrend_returns_four_series():
    high, low, close = _sample_ohlcv(n=200)
    value, direction, lower_band, upper_band = supertrend(high, low, close)
    assert len(value) == len(close)
    assert len(direction) == len(close)
    assert len(lower_band) == len(close)
    assert len(upper_band) == len(close)


def test_supertrend_direction_values():
    high, low, close = _sample_ohlcv(n=200)
    _, direction, _, _ = supertrend(high, low, close, period=7, multiplier=3.0)
    valid = direction.dropna()
    # direction should be 1.0 (bullish) or -1.0 (bearish)
    assert set(valid.unique()).issubset({1.0, -1.0})
