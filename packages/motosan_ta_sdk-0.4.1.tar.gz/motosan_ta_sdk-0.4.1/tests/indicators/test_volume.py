import pandas as pd
import numpy as np
import pytest
from ta_sdk.indicators.volume import obv, volume_sma, is_high_volume, cmf, vwap


def test_obv_length():
    close = pd.Series([1.0, 2.0, 1.5, 3.0, 2.5])
    volume = pd.Series([100, 200, 150, 300, 100])
    result = obv(close, volume)
    assert len(result) == 5


def test_volume_sma():
    volume = pd.Series([100] * 20)
    result = volume_sma(volume, period=10)
    assert result.iloc[-1] == 100.0


def test_is_high_volume():
    volume = pd.Series([100] * 19 + [200])
    result = is_high_volume(volume, threshold=1.5, period=10)
    assert result.iloc[-1]  # 200 > 100 * 1.5


# --- CMF tests ---


def test_cmf_buying_pressure_positive():
    """When close is near high (buying pressure), CMF should be positive."""
    n = 25
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([109.0] * n)  # close near high
    volume = pd.Series([1000.0] * n)
    result = cmf(high, low, close, volume, period=20)
    assert result.iloc[-1] > 0


def test_cmf_selling_pressure_negative():
    """When close is near low (selling pressure), CMF should be negative."""
    n = 25
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([101.0] * n)  # close near low
    volume = pd.Series([1000.0] * n)
    result = cmf(high, low, close, volume, period=20)
    assert result.iloc[-1] < 0


def test_cmf_midpoint_close_near_zero():
    """When close is at the midpoint of high-low, CMF should be near zero."""
    n = 25
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([105.0] * n)  # midpoint
    volume = pd.Series([1000.0] * n)
    result = cmf(high, low, close, volume, period=20)
    assert abs(result.iloc[-1]) < 1e-10


def test_cmf_bounded():
    """CMF values should always be in [-1, 1]."""
    np.random.seed(42)
    n = 100
    low = pd.Series(np.random.uniform(90, 100, n))
    high = low + np.random.uniform(1, 20, n)
    close = low + np.random.uniform(0, 1, n) * (high - low)
    volume = pd.Series(np.random.uniform(100, 10000, n))
    result = cmf(high, low, close, volume, period=20)
    valid = result.dropna()
    assert (valid >= -1.0 - 1e-10).all()
    assert (valid <= 1.0 + 1e-10).all()


def test_cmf_nan_prefix():
    """First (period - 1) values should be NaN."""
    n = 25
    period = 20
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([105.0] * n)
    volume = pd.Series([1000.0] * n)
    result = cmf(high, low, close, volume, period=period)
    assert result.iloc[: period - 1].isna().all()
    assert result.iloc[period - 1 :].notna().all()


# --- VWAP tests ---


def test_vwap_output_length():
    n = 48
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([105.0] * n)
    volume = pd.Series([1000.0] * n)
    result = vwap(high, low, close, volume, freq="1h", anchor="D")
    assert len(result) == n


def test_vwap_constant_price():
    """VWAP of constant price should equal that price."""
    n = 48
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([105.0] * n)
    volume = pd.Series([1000.0] * n)
    result = vwap(high, low, close, volume, freq="1h", anchor="D")
    tp = (110.0 + 100.0 + 105.0) / 3.0
    valid = result.dropna()
    np.testing.assert_allclose(valid.values, tp, atol=1e-10)


def test_vwap_resets_at_anchor():
    """VWAP should reset at each anchor boundary."""
    n = 48  # 2 days of 1h bars
    high = pd.Series([110.0] * 24 + [120.0] * 24)
    low = pd.Series([100.0] * 24 + [110.0] * 24)
    close = pd.Series([105.0] * 24 + [115.0] * 24)
    volume = pd.Series([1000.0] * n)
    result = vwap(high, low, close, volume, freq="1h", anchor="D")
    # First period TP = (110+100+105)/3 = 105
    # Second period TP = (120+110+115)/3 = 115
    tp1 = (110.0 + 100.0 + 105.0) / 3.0
    tp2 = (120.0 + 110.0 + 115.0) / 3.0
    assert result.iloc[23] == pytest.approx(tp1)
    assert result.iloc[24] == pytest.approx(tp2)  # reset at bar 24


def test_vwap_no_nan():
    """With positive volume, all VWAP values should be non-NaN."""
    n = 24
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([105.0] * n)
    volume = pd.Series([1000.0] * n)
    result = vwap(high, low, close, volume, freq="1h", anchor="D")
    assert result.notna().all()
