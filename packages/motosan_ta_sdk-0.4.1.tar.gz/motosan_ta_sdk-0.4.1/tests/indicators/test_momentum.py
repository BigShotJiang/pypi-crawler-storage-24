import pandas as pd
import numpy as np
import pytest
from ta_sdk.indicators.momentum import (
    rsi,
    macd,
    stochastic,
    cci,
    roc,
    williams_r,
    mfi,
    aroon,
    tsi,
    fisher_transform,
    trix,
)


def _random_close(n=200, seed=42):
    rng = np.random.default_rng(seed)
    return pd.Series(100 + np.cumsum(rng.standard_normal(n)))


def test_rsi_range():
    close = _random_close()
    result = rsi(close, period=14)
    valid = result.dropna()
    assert (valid >= 0).all()
    assert (valid <= 100).all()


def test_macd_returns_three_series():
    close = _random_close()
    macd_line, signal, hist = macd(close)
    assert len(macd_line) == len(close)
    assert len(signal) == len(close)
    assert len(hist) == len(close)


def _random_ohlcv(n=200, seed=42):
    rng = np.random.default_rng(seed)
    close = pd.Series(100 + np.cumsum(rng.standard_normal(n)))
    high = close + rng.uniform(0.5, 2.0, n)
    low = close - rng.uniform(0.5, 2.0, n)
    volume = pd.Series(rng.uniform(1000, 10000, n))
    return high, low, close, volume


def test_stochastic_range():
    high = _random_close() + 5
    low = _random_close() - 5
    close = _random_close()
    k, d = stochastic(high, low, close)
    valid_k = k.dropna()
    assert (valid_k >= 0).all()
    assert (valid_k <= 100).all()


# --- Aroon tests ---


def test_aroon_bounded():
    """Aroon Up and Down must be in [0, 100]."""
    high = _random_close() + 5
    low = _random_close() - 5
    up, down = aroon(high, low, period=25)
    valid_up = up.dropna()
    valid_down = down.dropna()
    assert (valid_up >= 0).all() and (valid_up <= 100).all()
    assert (valid_down >= 0).all() and (valid_down <= 100).all()


def test_aroon_uptrend():
    """In a strong uptrend, Aroon Up should be near 100."""
    n = 60
    high = pd.Series(np.arange(1.0, n + 1))
    low = high - 0.5
    up, down = aroon(high, low, period=25)
    assert (up.dropna() == 100.0).all()


def test_aroon_downtrend():
    """In a strong downtrend, Aroon Down should be near 100."""
    n = 60
    low = pd.Series(np.arange(float(n), 0.0, -1.0))
    high = low + 0.5
    up, down = aroon(high, low, period=25)
    assert (down.dropna() == 100.0).all()


def test_aroon_empty_input():
    """Empty Series should return empty results without error."""
    high = pd.Series([], dtype=float)
    low = pd.Series([], dtype=float)
    up, down = aroon(high, low, period=25)
    assert len(up) == 0
    assert len(down) == 0


def test_aroon_nan_count():
    """First `period` values should be NaN, rest should be valid."""
    n = 100
    period = 25
    high = _random_close(n=n) + 5
    low = _random_close(n=n) - 5
    up, down = aroon(high, low, period=period)
    assert up.isna().sum() == period
    assert down.isna().sum() == period
    assert len(up.dropna()) == n - period


# --- TSI tests ---


def test_tsi_bounded():
    close = _random_close()
    result = tsi(close)
    valid = result.dropna()
    assert len(valid) > 0
    assert (valid >= -100).all()
    assert (valid <= 100).all()


def test_tsi_positive_in_uptrend():
    close = pd.Series(np.linspace(50, 150, 200))
    result = tsi(close)
    assert result.iloc[-1] > 0


def test_tsi_negative_in_downtrend():
    close = pd.Series(np.linspace(150, 50, 200))
    result = tsi(close)
    assert result.iloc[-1] < 0


def test_tsi_length_matches_input():
    close = _random_close()
    result = tsi(close)
    assert len(result) == len(close)


# --- Fisher Transform tests ---


def _random_high_low(n=200, seed=42):
    rng = np.random.default_rng(seed)
    mid = 100 + np.cumsum(rng.standard_normal(n))
    spread = np.abs(rng.standard_normal(n)) * 2 + 0.5
    high = pd.Series(mid + spread)
    low = pd.Series(mid - spread)
    return high, low


def test_fisher_transform_amplifies_extremes():
    """Fisher values should exceed the [-1, 1] range."""
    high, low = _random_high_low(200)
    fisher, signal = fisher_transform(high, low, period=9)
    valid = fisher.dropna()
    assert len(valid) > 0
    assert (valid.abs() > 1.0).any(), "Fisher should amplify values beyond [-1, 1]"


def test_fisher_trigger_is_lagged():
    """Signal (trigger) at index i equals fisher at index i-1."""
    high, low = _random_high_low(200)
    fisher, signal = fisher_transform(high, low, period=9)
    period = 9
    for i in range(period, len(fisher)):
        if not np.isnan(fisher.iloc[i]) and not np.isnan(fisher.iloc[i - 1]):
            assert signal.iloc[i] == pytest.approx(fisher.iloc[i - 1])


def test_fisher_transform_empty_input():
    high = pd.Series([], dtype=float)
    low = pd.Series([], dtype=float)
    fisher, signal = fisher_transform(high, low, period=9)
    assert len(fisher) == 0
    assert len(signal) == 0


def test_fisher_transform_short_input():
    high = pd.Series([10.0, 11.0, 12.0])
    low = pd.Series([9.0, 10.0, 11.0])
    fisher, signal = fisher_transform(high, low, period=9)
    assert len(fisher) == 3
    assert fisher.isna().all()
    assert signal.isna().all()


def test_fisher_transform_output_length():
    high, low = _random_high_low(100)
    period = 9
    fisher, signal = fisher_transform(high, low, period=period)
    assert len(fisher) == 100
    assert len(signal) == 100
    assert fisher.iloc[: period - 1].isna().all()
    assert not np.isnan(fisher.iloc[period - 1])


# --- TRIX tests ---


def test_trix_returns_two_series():
    close = _random_close()
    trix_line, signal_line = trix(close)
    assert len(trix_line) == len(close)
    assert len(signal_line) == len(close)


def test_trix_positive_in_uptrend():
    close = pd.Series(np.linspace(50, 150, 200))
    trix_line, _ = trix(close, period=15, signal_period=9)
    tail = trix_line.iloc[-50:]
    valid = tail.dropna()
    assert len(valid) > 0
    assert (valid > 0).all()


def test_trix_negative_in_downtrend():
    close = pd.Series(np.linspace(150, 50, 200))
    trix_line, _ = trix(close, period=15, signal_period=9)
    tail = trix_line.iloc[-50:]
    valid = tail.dropna()
    assert len(valid) > 0
    assert (valid < 0).all()


def test_trix_signal_smoother_than_line():
    close = _random_close(n=300)
    trix_line, signal_line = trix(close, period=15, signal_period=9)
    valid_mask = trix_line.notna() & signal_line.notna()
    trix_valid = trix_line[valid_mask]
    signal_valid = signal_line[valid_mask]
    assert len(trix_valid) > 30
    assert signal_valid.std() < trix_valid.std()


def test_trix_flat_price_near_zero():
    close = pd.Series([100.0] * 200)
    trix_line, signal_line = trix(close, period=15, signal_period=9)
    valid = trix_line.dropna()
    assert len(valid) > 0
    assert (valid.abs() < 1e-10).all()


# --- CCI tests ---


def test_cci_output_length():
    high, low, close, _ = _random_ohlcv()
    result = cci(high, low, close, period=20)
    assert len(result) == len(close)


def test_cci_nan_prefix():
    high, low, close, _ = _random_ohlcv(n=50)
    result = cci(high, low, close, period=20)
    assert result.iloc[:19].isna().all()
    assert result.iloc[19:].notna().any()


def test_cci_zero_for_constant_price():
    """CCI should be 0 when price is constant (TP == SMA(TP))."""
    n = 30
    high = pd.Series([110.0] * n)
    low = pd.Series([100.0] * n)
    close = pd.Series([105.0] * n)
    result = cci(high, low, close, period=20)
    # mean deviation is 0 → division by zero → NaN, which is expected
    # but TP - SMA(TP) is also 0, so result should be NaN or 0
    valid = result.dropna()
    if len(valid) > 0:
        assert (valid.abs() < 1e-10).all()


# --- ROC tests ---


def test_roc_output_length():
    close = _random_close()
    result = roc(close, period=10)
    assert len(result) == len(close)


def test_roc_nan_prefix():
    close = _random_close(n=20)
    result = roc(close, period=10)
    assert result.iloc[:10].isna().all()
    assert result.iloc[10:].notna().all()


def test_roc_positive_in_uptrend():
    close = pd.Series(np.linspace(50, 150, 100))
    result = roc(close, period=10)
    valid = result.dropna()
    assert (valid > 0).all()


def test_roc_known_value():
    close = pd.Series([100.0, 110.0])
    result = roc(close, period=1)
    assert result.iloc[1] == pytest.approx(10.0)


# --- Williams %R tests ---


def test_williams_r_bounded():
    high, low, close, _ = _random_ohlcv()
    result = williams_r(high, low, close, period=14)
    valid = result.dropna()
    assert (valid >= -100).all()
    assert (valid <= 0).all()


def test_williams_r_nan_prefix():
    high, low, close, _ = _random_ohlcv(n=30)
    result = williams_r(high, low, close, period=14)
    assert result.iloc[:13].isna().all()


def test_williams_r_at_high():
    """When close equals highest high, %R should be 0."""
    n = 20
    high = pd.Series([100.0] * n)
    low = pd.Series([90.0] * n)
    close = pd.Series([100.0] * n)
    result = williams_r(high, low, close, period=14)
    valid = result.dropna()
    assert (valid == 0.0).all()


def test_williams_r_at_low():
    """When close equals lowest low, %R should be -100."""
    n = 20
    high = pd.Series([100.0] * n)
    low = pd.Series([90.0] * n)
    close = pd.Series([90.0] * n)
    result = williams_r(high, low, close, period=14)
    valid = result.dropna()
    np.testing.assert_allclose(valid.values, -100.0, atol=1e-10)


# --- MFI tests ---


def test_mfi_bounded():
    high, low, close, volume = _random_ohlcv()
    result = mfi(high, low, close, volume, period=14)
    valid = result.dropna()
    assert (valid >= 0).all()
    assert (valid <= 100).all()


def test_mfi_output_length():
    high, low, close, volume = _random_ohlcv()
    result = mfi(high, low, close, volume, period=14)
    assert len(result) == len(close)


def test_mfi_nan_prefix():
    high, low, close, volume = _random_ohlcv(n=30)
    result = mfi(high, low, close, volume, period=14)
    # first few values should be NaN (period warmup + diff)
    assert result.iloc[:14].isna().any()
