import pandas as pd
import numpy as np
import pytest
from ta_sdk.indicators.moving_averages import (
    sma,
    ema,
    kama,
    dema,
    tema,
    hma,
    smma,
    _sma_seeded_ema,
    _wma,
)


# ---------------------------------------------------------------------------
# Existing SMA / EMA tests
# ---------------------------------------------------------------------------


def test_sma_basic():
    close = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0])
    result = sma(close, period=3)
    assert np.isnan(result.iloc[0])
    assert np.isnan(result.iloc[1])
    assert result.iloc[2] == pytest.approx(2.0)
    assert result.iloc[3] == pytest.approx(3.0)
    assert result.iloc[4] == pytest.approx(4.0)


def test_ema_length():
    close = pd.Series(range(100), dtype=float)
    result = ema(close, period=20)
    assert len(result) == 100
    assert not np.isnan(result.iloc[-1])


def test_sma_period_larger_than_data():
    close = pd.Series([1.0, 2.0])
    result = sma(close, period=5)
    assert result.isna().all()


# ---------------------------------------------------------------------------
# Helper: _sma_seeded_ema
# ---------------------------------------------------------------------------


class TestSmaSeededEma:
    def test_seed_is_sma(self):
        close = pd.Series([2.0, 4.0, 6.0, 8.0, 10.0])
        result = _sma_seeded_ema(close, period=3)
        # first 2 should be NaN, index 2 = mean(2,4,6) = 4
        assert np.isnan(result.iloc[0])
        assert np.isnan(result.iloc[1])
        assert result.iloc[2] == pytest.approx(4.0)

    def test_short_input(self):
        close = pd.Series([1.0, 2.0])
        result = _sma_seeded_ema(close, period=5)
        assert result.isna().all()

    def test_empty(self):
        close = pd.Series([], dtype=float)
        result = _sma_seeded_ema(close, period=3)
        assert len(result) == 0


# ---------------------------------------------------------------------------
# Helper: _wma
# ---------------------------------------------------------------------------


class TestWma:
    def test_basic(self):
        # period=3, weights 1,2,3 => weight_sum=6
        close = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0])
        result = _wma(close, period=3)
        assert np.isnan(result.iloc[0])
        assert np.isnan(result.iloc[1])
        # index 2: (1*1 + 2*2 + 3*3)/6 = 14/6
        assert result.iloc[2] == pytest.approx(14.0 / 6.0)
        # index 3: (1*2 + 2*3 + 3*4)/6 = 20/6
        assert result.iloc[3] == pytest.approx(20.0 / 6.0)

    def test_short_input(self):
        close = pd.Series([1.0])
        result = _wma(close, period=3)
        assert result.isna().all()


# ---------------------------------------------------------------------------
# DEMA
# ---------------------------------------------------------------------------


class TestDema:
    def test_basic_correctness(self):
        np.random.seed(42)
        close = pd.Series(np.cumsum(np.random.randn(100)) + 100)
        result = dema(close, period=10)
        assert len(result) == 100
        # leading NaNs then finite values
        assert result.isna().any()
        assert result.notna().any()
        # last value should be finite
        assert np.isfinite(result.iloc[-1])

    def test_constant_price(self):
        close = pd.Series([50.0] * 30)
        result = dema(close, period=5)
        # once warmed up, DEMA of constant should be that constant
        finite = result.dropna()
        np.testing.assert_allclose(finite.values, 50.0, atol=1e-10)

    def test_empty_input(self):
        close = pd.Series([], dtype=float)
        result = dema(close, period=5)
        assert len(result) == 0

    def test_short_input(self):
        close = pd.Series([1.0, 2.0])
        result = dema(close, period=10)
        assert result.isna().all()

    def test_less_lag_than_ema(self):
        """DEMA should respond faster to a step change than SMA-seeded EMA."""
        data = [10.0] * 30 + [20.0] * 30
        close = pd.Series(data)
        ema_result = _sma_seeded_ema(close, period=10)
        dema_result = dema(close, period=10)
        # At index 35 (5 bars after step), DEMA should be closer to 20
        idx = 35
        assert abs(dema_result.iloc[idx] - 20.0) < abs(ema_result.iloc[idx] - 20.0)


# ---------------------------------------------------------------------------
# TEMA
# ---------------------------------------------------------------------------


class TestTema:
    def test_basic_correctness(self):
        np.random.seed(42)
        close = pd.Series(np.cumsum(np.random.randn(100)) + 100)
        result = tema(close, period=10)
        assert len(result) == 100
        assert result.isna().any()
        assert np.isfinite(result.iloc[-1])

    def test_constant_price(self):
        close = pd.Series([50.0] * 50)
        result = tema(close, period=5)
        finite = result.dropna()
        np.testing.assert_allclose(finite.values, 50.0, atol=1e-10)

    def test_empty_input(self):
        close = pd.Series([], dtype=float)
        result = tema(close, period=5)
        assert len(result) == 0

    def test_short_input(self):
        close = pd.Series([1.0, 2.0])
        result = tema(close, period=10)
        assert result.isna().all()

    def test_reaches_target_faster_than_dema(self):
        """TEMA should cross the midpoint of a step change before DEMA.

        TEMA may overshoot, so we test time-to-midpoint rather than distance
        at a fixed index.
        """
        data = [10.0] * 40 + [20.0] * 40
        close = pd.Series(data)
        dema_result = dema(close, period=10)
        tema_result = tema(close, period=10)
        midpoint = 15.0  # halfway between 10 and 20

        def first_cross(series: pd.Series) -> int:
            for i in range(40, len(series)):
                if np.isfinite(series.iloc[i]) and series.iloc[i] >= midpoint:
                    return i
            return len(series)

        assert first_cross(tema_result) <= first_cross(dema_result)


# ---------------------------------------------------------------------------
# HMA
# ---------------------------------------------------------------------------


class TestHma:
    def test_basic_correctness(self):
        np.random.seed(42)
        close = pd.Series(np.cumsum(np.random.randn(100)) + 100)
        result = hma(close, period=16)
        assert len(result) == 100
        assert result.isna().any()
        assert np.isfinite(result.iloc[-1])

    def test_constant_price(self):
        close = pd.Series([50.0] * 30)
        result = hma(close, period=9)
        finite = result.dropna()
        np.testing.assert_allclose(finite.values, 50.0, atol=1e-10)

    def test_empty_input(self):
        close = pd.Series([], dtype=float)
        result = hma(close, period=9)
        assert len(result) == 0

    def test_short_input(self):
        close = pd.Series([1.0, 2.0])
        result = hma(close, period=16)
        assert result.isna().all()

    def test_fastest_response(self):
        """HMA should respond fastest to a step change compared to SMA."""
        data = [10.0] * 30 + [20.0] * 30
        close = pd.Series(data)
        sma_result = sma(close, period=9)
        hma_result = hma(close, period=9)
        idx = 35
        if np.isfinite(hma_result.iloc[idx]) and np.isfinite(sma_result.iloc[idx]):
            assert abs(hma_result.iloc[idx] - 20.0) < abs(sma_result.iloc[idx] - 20.0)


# ---------------------------------------------------------------------------
# SMMA
# ---------------------------------------------------------------------------


class TestSmma:
    def test_basic_correctness(self):
        close = pd.Series([2.0, 4.0, 6.0, 8.0, 10.0, 12.0])
        result = smma(close, period=3)
        # seed at index 2 = mean(2,4,6) = 4.0
        assert np.isnan(result.iloc[0])
        assert np.isnan(result.iloc[1])
        assert result.iloc[2] == pytest.approx(4.0)
        # index 3: (4.0 * 2 + 8) / 3 = 16/3
        assert result.iloc[3] == pytest.approx(16.0 / 3.0)

    def test_constant_price(self):
        close = pd.Series([50.0] * 20)
        result = smma(close, period=5)
        finite = result.dropna()
        np.testing.assert_allclose(finite.values, 50.0, atol=1e-10)

    def test_empty_input(self):
        close = pd.Series([], dtype=float)
        result = smma(close, period=5)
        assert len(result) == 0

    def test_short_input(self):
        close = pd.Series([1.0, 2.0])
        result = smma(close, period=5)
        assert result.isna().all()

    def test_smoother_than_sma(self):
        """SMMA should be smoother (less variance in diffs) than SMA."""
        np.random.seed(42)
        close = pd.Series(np.cumsum(np.random.randn(200)) + 100)
        sma_result = sma(close, period=14).dropna()
        smma_result = smma(close, period=14).dropna()
        sma_diff_var = sma_result.diff().dropna().var()
        smma_diff_var = smma_result.diff().dropna().var()
        assert smma_diff_var < sma_diff_var


# ---------------------------------------------------------------------------
# KAMA
# ---------------------------------------------------------------------------


class TestKama:
    def test_basic_correctness(self):
        np.random.seed(42)
        close = pd.Series(np.cumsum(np.random.randn(100)) + 100)
        result = kama(close, period=10)
        assert len(result) == 100
        assert np.isfinite(result.iloc[-1])

    def test_seed_is_sma(self):
        close = pd.Series([2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0])
        result = kama(close, period=10)
        # seed at index 9 = mean of all 10 values = 11.0
        assert result.iloc[9] == pytest.approx(11.0)

    def test_constant_price(self):
        close = pd.Series([50.0] * 30)
        result = kama(close, period=10)
        finite = result.dropna()
        np.testing.assert_allclose(finite.values, 50.0, atol=1e-10)

    def test_empty_input(self):
        close = pd.Series([], dtype=float)
        result = kama(close, period=10)
        assert len(result) == 0

    def test_short_input(self):
        close = pd.Series([1.0, 2.0])
        result = kama(close, period=10)
        assert result.isna().all()

    def test_nan_prefix(self):
        close = pd.Series(range(30), dtype=float)
        result = kama(close, period=10)
        assert result.iloc[:9].isna().all()
        assert result.iloc[9:].notna().all()
