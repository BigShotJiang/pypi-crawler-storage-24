import pandas as pd
import numpy as np
from ta_sdk.indicators.relative import rs_rating


def test_rs_rating_range():
    stock_close = pd.Series(np.linspace(100, 150, 252))  # rising
    bench_close = pd.Series(np.linspace(100, 110, 252))  # slow rise
    result = rs_rating(stock_close, bench_close)
    assert 0 <= result <= 100


def test_rs_rating_strong_stock():
    stock_close = pd.Series(np.linspace(100, 200, 252))
    bench_close = pd.Series(np.linspace(100, 105, 252))
    result = rs_rating(stock_close, bench_close)
    assert result > 80  # strong stock should score high
