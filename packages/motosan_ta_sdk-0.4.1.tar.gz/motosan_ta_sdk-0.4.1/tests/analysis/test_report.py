import pandas as pd
import numpy as np
from ta_sdk.analysis.full_analysis import analyze_stock
from ta_sdk.analysis.report import generate_report


def _make_stock_df(n=300):
    close = pd.Series(np.linspace(50, 150, n))
    return pd.DataFrame(
        {
            "open": close,
            "high": close + 2,
            "low": close - 2,
            "close": close,
            "volume": np.full(n, 3_000_000),
        }
    )


def test_report_generates_markdown():
    df = _make_stock_df()
    analysis = analyze_stock(df, symbol="NVDA")
    report = generate_report(analysis)
    assert isinstance(report, str)
    assert "NVDA" in report
    assert "## " in report  # has markdown headers
