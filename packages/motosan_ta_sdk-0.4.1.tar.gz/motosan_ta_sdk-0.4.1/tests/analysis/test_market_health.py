import pandas as pd
import numpy as np
from ta_sdk.analysis.market_health import check_market_health


def _make_bullish_market(n=300):
    """S&P 500 in uptrend above 200 SMA."""
    close = pd.Series(np.linspace(4000, 5500, n))
    return pd.DataFrame(
        {
            "open": close,
            "high": close + 20,
            "low": close - 20,
            "close": close,
            "volume": np.full(n, 3_000_000_000),
        }
    )


def _make_bearish_market(n=300):
    """S&P 500 in downtrend below 200 SMA."""
    close = pd.Series(np.linspace(5500, 4000, n))
    return pd.DataFrame(
        {
            "open": close,
            "high": close + 20,
            "low": close - 20,
            "close": close,
            "volume": np.full(n, 3_000_000_000),
        }
    )


def test_market_health_bullish():
    df = _make_bullish_market()
    result = check_market_health(df)
    assert result["condition"] == "bullish"
    assert result["sp500_above_200sma"] is True


def test_market_health_bearish():
    df = _make_bearish_market()
    result = check_market_health(df)
    assert result["condition"] == "bearish"
    assert result["sp500_above_200sma"] is False
