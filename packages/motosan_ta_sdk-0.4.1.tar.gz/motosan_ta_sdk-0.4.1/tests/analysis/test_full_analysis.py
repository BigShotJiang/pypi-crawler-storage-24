import pandas as pd
import numpy as np
from ta_sdk.analysis.full_analysis import analyze_stock


def _make_stock_df(n=300):
    """Stock in uptrend for full analysis."""
    close = pd.Series(np.linspace(50, 150, n))
    return pd.DataFrame(
        {
            "open": close,
            "high": close + 2,
            "low": close - 2,
            "close": close,
            "volume": np.full(n, 3_000_000),
        }
    )


def test_full_analysis_returns_all_sections():
    df = _make_stock_df()
    result = analyze_stock(df, symbol="TEST")
    assert "symbol" in result
    assert result["symbol"] == "TEST"
    assert "trend" in result
    assert "indicators" in result
    assert "stage2" in result
    assert "entry_signal" in result


def test_full_analysis_with_fundamentals():
    df = _make_stock_df()
    fundamentals = {
        "eps_growth_qtr": 30.0,
        "eps_growth_annual": 25.0,
        "roe": 20.0,
        "new_product": True,
        "institutional_pct": 40.0,
    }
    result = analyze_stock(df, symbol="TEST", fundamentals=fundamentals)
    assert "canslim" in result
    assert result["canslim"]["score"] >= 0
