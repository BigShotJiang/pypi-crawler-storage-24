import pandas as pd
import numpy as np
import pytest
from ta_sdk.data.models import PatternResult
from ta_sdk.patterns.vcp import detect_vcp, _measure_contractions


def _make_vcp_data():
    """Synthetic VCP: price with contracting swings + declining volume."""
    n = 120
    # Uptrend then contracting base
    prices = list(np.linspace(80, 120, 40))  # uptrend
    # Contraction 1: 120 -> 108 -> 118
    prices += list(np.linspace(120, 108, 10))
    prices += list(np.linspace(108, 118, 10))
    # Contraction 2: 118 -> 112 -> 119
    prices += list(np.linspace(118, 112, 10))
    prices += list(np.linspace(112, 119, 10))
    # Contraction 3: 119 -> 116 -> 120
    prices += list(np.linspace(119, 116, 10))
    prices += list(np.linspace(116, 120, 10))
    # Tight close near pivot
    prices += [120.0] * 10
    close = pd.Series(prices[:n])
    high = close + 1
    low = close - 1
    volume = pd.Series(np.linspace(5000000, 1000000, n))  # declining
    df = pd.DataFrame(
        {"open": close, "high": high, "low": low, "close": close, "volume": volume}
    )
    return df


def test_detect_vcp_on_synthetic():
    df = _make_vcp_data()
    result = detect_vcp(df)
    assert isinstance(result, PatternResult)
    assert result.pattern_type == "vcp"
    assert result.detected is True
    assert len(result.contractions) >= 2


def test_detect_vcp_on_random_noise():
    rng = np.random.default_rng(42)
    df = pd.DataFrame(
        {
            "open": rng.uniform(90, 110, 120),
            "high": rng.uniform(100, 120, 120),
            "low": rng.uniform(80, 100, 120),
            "close": rng.uniform(90, 110, 120),
            "volume": rng.integers(1000000, 5000000, 120),
        }
    )
    result = detect_vcp(df)
    assert result.detected is False


def test_measure_contractions_temporal_order():
    """Contractions must pair high→low in temporal order, not by index."""
    # Correct order: high→low→high→low (two valid pairs)
    swings_ordered = [
        {"type": "high", "idx": 10, "price": 120.0},
        {"type": "low", "idx": 15, "price": 108.0},
        {"type": "high", "idx": 20, "price": 118.0},
        {"type": "low", "idx": 25, "price": 112.0},
    ]
    contractions = _measure_contractions(swings_ordered)
    assert len(contractions) == 2
    assert contractions[0] == pytest.approx(10.0, abs=0.1)  # (120-108)/120
    assert contractions[1] == pytest.approx(5.08, abs=0.1)  # (118-112)/118


def test_measure_contractions_skips_consecutive_highs():
    """Consecutive highs without intervening low should be skipped."""
    swings = [
        {"type": "high", "idx": 10, "price": 120.0},
        {"type": "high", "idx": 12, "price": 119.0},  # consecutive high
        {"type": "low", "idx": 15, "price": 112.0},
        {"type": "high", "idx": 20, "price": 118.0},
        {"type": "low", "idx": 25, "price": 115.0},
    ]
    contractions = _measure_contractions(swings)
    # First high skipped (next is also high), second high pairs with low
    assert len(contractions) == 2


def test_measure_contractions_low_first_ignored():
    """A leading low before any high should be skipped."""
    swings = [
        {"type": "low", "idx": 5, "price": 100.0},  # leading low
        {"type": "high", "idx": 10, "price": 120.0},
        {"type": "low", "idx": 15, "price": 108.0},
    ]
    contractions = _measure_contractions(swings)
    assert len(contractions) == 1
    assert contractions[0] == pytest.approx(10.0, abs=0.1)
