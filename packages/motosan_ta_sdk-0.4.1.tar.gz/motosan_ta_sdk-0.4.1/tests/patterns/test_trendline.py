import pandas as pd
import numpy as np
from ta_sdk.data.models import PatternResult
from ta_sdk.patterns.trendline import detect_trendline


def _make_uptrend_data():
    """Stock in clear uptrend with rising lows."""
    n = 100
    # Sawtooth: up, small dip, up, small dip — creating ascending lows
    base = np.linspace(80, 120, n)
    noise = np.sin(np.linspace(0, 8 * np.pi, n)) * 3
    close = pd.Series(base + noise)
    high = close + 2
    low = close - 2
    volume = pd.Series([2000000] * n)
    return pd.DataFrame(
        {"open": close, "high": high, "low": low, "close": close, "volume": volume}
    )


def test_detect_trendline_uptrend():
    df = _make_uptrend_data()
    result = detect_trendline(df)
    assert isinstance(result, PatternResult)
    assert result.pattern_type == "trendline"
    assert result.detected is True


def test_detect_trendline_flat():
    close = pd.Series([100.0] * 100)
    df = pd.DataFrame(
        {
            "open": close,
            "high": close + 0.5,
            "low": close - 0.5,
            "close": close,
            "volume": [1000000] * 100,
        }
    )
    result = detect_trendline(df)
    # Flat data: swing lows not ascending (all same)
    assert result.detected is False
