import pandas as pd
import numpy as np
from ta_sdk.data.models import PatternResult
from ta_sdk.patterns.double_bottom import detect_double_bottom


def _make_double_bottom_data():
    """Synthetic W pattern."""
    n = 100
    prices = list(np.linspace(110, 90, 20))  # drop to first low
    prices += list(np.linspace(90, 105, 15))  # rise to middle peak
    prices += list(np.linspace(105, 91, 15))  # drop to second low
    prices += list(np.linspace(91, 110, 20))  # rally up
    prices += [110.0] * (n - len(prices))
    close = pd.Series(prices[:n])
    high = close + 1
    low = close - 1
    volume = pd.Series([2000000] * n)
    return pd.DataFrame(
        {"open": close, "high": high, "low": low, "close": close, "volume": volume}
    )


def test_detect_double_bottom_synthetic():
    df = _make_double_bottom_data()
    result = detect_double_bottom(df)
    assert isinstance(result, PatternResult)
    assert result.pattern_type == "double_bottom"
    assert result.detected is True


def test_detect_double_bottom_flat():
    close = pd.Series([100.0] * 100)
    df = pd.DataFrame(
        {
            "open": close,
            "high": close + 0.5,
            "low": close - 0.5,
            "close": close,
            "volume": [1000000] * 100,
        }
    )
    result = detect_double_bottom(df)
    assert result.detected is False
