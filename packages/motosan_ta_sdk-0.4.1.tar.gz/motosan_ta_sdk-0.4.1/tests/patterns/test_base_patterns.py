import pandas as pd
import numpy as np
from ta_sdk.data.models import PatternResult
from ta_sdk.patterns.base_patterns import detect_flat_base


def test_detect_flat_base():
    """Tight consolidation should be detected as flat base."""
    close = pd.Series([100 + np.sin(x) * 3 for x in np.linspace(0, 6, 60)])
    df = pd.DataFrame(
        {
            "open": close,
            "high": close + 1,
            "low": close - 1,
            "close": close,
            "volume": [2000000] * 60,
        }
    )
    result = detect_flat_base(df)
    assert isinstance(result, PatternResult)
    assert result.pattern_type == "flat_base"
    assert result.detected is True


def test_flat_base_wide_range():
    """Wide range should not be flat base."""
    close = pd.Series(np.linspace(80, 120, 60))  # 50% range
    df = pd.DataFrame(
        {
            "open": close,
            "high": close + 1,
            "low": close - 1,
            "close": close,
            "volume": [2000000] * 60,
        }
    )
    result = detect_flat_base(df)
    assert result.detected is False
