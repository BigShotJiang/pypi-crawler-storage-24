import pandas as pd
import numpy as np
from ta_sdk.data.models import PatternResult
from ta_sdk.patterns.cup_handle import detect_cup_handle


def _make_cup_handle_data():
    """Synthetic cup & handle: U-shape + small pullback."""
    n = 120
    # Left lip
    prices = list(np.linspace(100, 110, 20))
    # Cup down
    prices += list(np.linspace(110, 90, 20))
    # Cup bottom
    prices += list(np.linspace(90, 92, 10))
    # Cup up
    prices += list(np.linspace(92, 110, 20))
    # Handle pullback
    prices += list(np.linspace(110, 105, 10))
    prices += list(np.linspace(105, 109, 10))
    # Fill to n
    prices += [109.0] * (n - len(prices))
    close = pd.Series(prices[:n])
    high = close + 1
    low = close - 1
    volume = pd.Series(np.linspace(3000000, 2000000, n))
    df = pd.DataFrame(
        {"open": close, "high": high, "low": low, "close": close, "volume": volume}
    )
    return df


def test_detect_cup_handle_on_synthetic():
    df = _make_cup_handle_data()
    result = detect_cup_handle(df)
    assert isinstance(result, PatternResult)
    assert result.pattern_type == "cup_handle"


def test_detect_cup_handle_on_flat():
    """Flat price data should not detect a cup & handle."""
    close = pd.Series([100.0] * 120)
    df = pd.DataFrame(
        {
            "open": close,
            "high": close + 0.5,
            "low": close - 0.5,
            "close": close,
            "volume": [1000000] * 120,
        }
    )
    result = detect_cup_handle(df)
    assert result.detected is False
