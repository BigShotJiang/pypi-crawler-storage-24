import pytest
from ta_sdk.data.base import DataProvider
from ta_sdk.data.yfinance_provider import YFinanceProvider
from ta_sdk.data.models import Market


def test_yfinance_is_data_provider():
    p = YFinanceProvider()
    assert isinstance(p, DataProvider)


def test_yfinance_supports_us_market():
    p = YFinanceProvider()
    assert p.supports_market(Market.US) is True
    assert p.supports_market(Market.TW) is True
    assert p.supports_market(Market.CRYPTO) is False


@pytest.mark.integration
def test_yfinance_get_ohlcv_us():
    """Integration test — hits real API"""
    p = YFinanceProvider()
    data = p.get_ohlcv("AAPL", period="1mo")
    assert data.symbol == "AAPL"
    assert data.market == Market.US
    assert len(data.df) > 10
    assert list(data.df.columns) == ["open", "high", "low", "close", "volume"]


@pytest.mark.integration
def test_yfinance_get_quote_us():
    p = YFinanceProvider()
    q = p.get_quote("AAPL")
    assert q.symbol == "AAPL"
    assert q.price > 0
