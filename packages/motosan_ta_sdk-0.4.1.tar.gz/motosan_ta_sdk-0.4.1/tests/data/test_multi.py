from unittest.mock import MagicMock
from ta_sdk.data.multi import MultiProvider, detect_market
from ta_sdk.data.models import Market


def test_detect_market_us():
    assert detect_market("NVDA") == Market.US
    assert detect_market("AAPL") == Market.US


def test_detect_market_tw():
    assert detect_market("2330.TW") == Market.TW
    assert detect_market("2317.TWO") == Market.TW


def test_detect_market_crypto():
    assert detect_market("BTCUSDT") == Market.CRYPTO
    assert detect_market("ETHUSDT") == Market.CRYPTO


def test_detect_market_crypto_digit_start():
    """Symbols starting with a digit like 1INCH should be detected as crypto."""
    assert detect_market("1INCHUSDT") == Market.CRYPTO


def test_detect_market_crypto_usdc_pair():
    """USDC quote pairs should be detected as crypto."""
    assert detect_market("WBTCUSDC") == Market.CRYPTO


def test_detect_market_crypto_fdusd_pair():
    """FDUSD quote pairs should be detected as crypto."""
    assert detect_market("BTCFDUSD") == Market.CRYPTO


def test_detect_market_crypto_long_base():
    """Symbols with longer base names (e.g. RENDER) should be detected as crypto."""
    assert detect_market("RENDERUSDT") == Market.CRYPTO


def test_detect_market_not_crypto_stock():
    """Plain US stock tickers should NOT be detected as crypto."""
    assert detect_market("AAPL") == Market.US


def test_detect_market_not_crypto_tw():
    """TW stock symbols should NOT be detected as crypto."""
    assert detect_market("2330.TW") == Market.TW


def test_multi_routes_to_correct_provider():
    mock_us = MagicMock()
    mock_crypto = MagicMock()
    mp = MultiProvider(
        providers={Market.US: mock_us, Market.TW: mock_us, Market.CRYPTO: mock_crypto}
    )
    mp.get_ohlcv("NVDA")
    mock_us.get_ohlcv.assert_called_once_with("NVDA", "1y", "1d")

    mp.get_ohlcv("BTCUSDT")
    mock_crypto.get_ohlcv.assert_called_once_with("BTCUSDT", "1y", "1d")
