from ta_sdk.data.base import DataProvider
from ta_sdk.data.binance_provider import BinanceProvider
from ta_sdk.data.models import Market


def test_binance_is_data_provider():
    p = BinanceProvider()
    assert isinstance(p, DataProvider)


def test_binance_supports_crypto():
    p = BinanceProvider()
    assert p.supports_market(Market.CRYPTO) is True
    assert p.supports_market(Market.US) is False
