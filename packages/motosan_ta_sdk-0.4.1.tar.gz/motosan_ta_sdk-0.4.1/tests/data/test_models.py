import pandas as pd
from ta_sdk.data.models import (
    Market,
    OHLCVData,
    Quote,
    TrendStage,
    EntrySignal,
    MarketCondition,
    Earnings,
    Financials,
    PatternResult,
    RiskAssessment,
    MarketHealth,
    AnalysisReport,
)


def test_market_enum():
    assert Market.US.value == "us"
    assert Market.TW.value == "tw"
    assert Market.CRYPTO.value == "crypto"


def test_ohlcv_data_creation():
    df = pd.DataFrame(
        {
            "open": [100.0],
            "high": [105.0],
            "low": [99.0],
            "close": [103.0],
            "volume": [1000000],
        }
    )
    data = OHLCVData(
        symbol="NVDA",
        market=Market.US,
        df=df,
        currency="USD",
        timezone="America/New_York",
    )
    assert data.symbol == "NVDA"
    assert len(data.df) == 1
    assert data.market == Market.US


def test_quote_creation():
    q = Quote(
        symbol="NVDA", price=130.0, volume=50000000, change_pct=2.5, market=Market.US
    )
    assert q.price == 130.0
    assert q.change_pct == 2.5


# --- Enum tests ---


def test_trend_stage_enum():
    assert TrendStage.STAGE1.value == "stage1_accumulation"
    assert TrendStage.STAGE2.value == "stage2_advancing"
    assert TrendStage.STAGE3.value == "stage3_distribution"
    assert TrendStage.STAGE4.value == "stage4_declining"
    assert TrendStage.UNKNOWN.value == "unknown"


def test_entry_signal_enum():
    assert EntrySignal.GO.value == "go"
    assert EntrySignal.WAIT.value == "wait"
    assert EntrySignal.NO.value == "no"


def test_market_condition_enum():
    assert MarketCondition.BULLISH.value == "bullish"
    assert MarketCondition.NEUTRAL.value == "neutral"
    assert MarketCondition.BEARISH.value == "bearish"


# --- Dataclass tests ---


def test_earnings_creation():
    e = Earnings(
        date="2026-01-01",
        eps_actual=1.5,
        eps_estimate=1.4,
        revenue_actual=100e6,
        revenue_estimate=95e6,
    )
    assert e.date == "2026-01-01"
    assert e.eps_actual == 1.5


def test_financials_creation():
    f = Financials(
        symbol="AAPL",
        market_cap=3e12,
        pe_ratio=30.0,
        eps_ttm=6.5,
        revenue_growth_yoy=0.08,
        gross_margin=0.45,
    )
    assert f.symbol == "AAPL"
    assert f.earnings == []


def test_pattern_result_creation():
    pr = PatternResult(
        pattern_type="vcp", detected=True, confidence=0.85, description="VCP found"
    )
    assert pr.detected is True
    assert pr.confidence == 0.85
    assert pr.key_levels == {}
    assert pr.contractions == []


def test_risk_assessment_creation():
    ra = RiskAssessment(
        stop_price=95.0,
        stop_pct=5.0,
        position_size_pct=2.0,
        risk_reward_ratio=3.0,
    )
    assert ra.stop_price == 95.0
    assert ra.description == ""


def test_market_health_creation():
    mh = MarketHealth(condition=MarketCondition.BULLISH, vix=15.0)
    assert mh.condition == MarketCondition.BULLISH
    assert mh.sp500_above_200sma is None


# --- AnalysisReport backward-compat tests ---


def test_analysis_report_to_dict():
    report = AnalysisReport(
        symbol="AAPL",
        trend="stage2_advancing",
        indicators={"price": 150.0},
        stage2={"passes": True},
        entry_signal={"signal": True},
    )
    d = report.to_dict()
    assert d["symbol"] == "AAPL"
    assert d["indicators"]["price"] == 150.0
    assert "canslim" not in d


def test_analysis_report_to_dict_with_canslim():
    report = AnalysisReport(
        symbol="AAPL",
        trend="stage2_advancing",
        canslim={"score": 5},
    )
    d = report.to_dict()
    assert d["canslim"]["score"] == 5


def test_analysis_report_getitem():
    report = AnalysisReport(symbol="AAPL", trend="up")
    assert report["symbol"] == "AAPL"
    assert report["trend"] == "up"


def test_analysis_report_contains():
    report = AnalysisReport(symbol="AAPL", trend="up")
    assert "symbol" in report
    assert "nonexistent" not in report


def test_analysis_report_get():
    report = AnalysisReport(symbol="AAPL", trend="up")
    assert report.get("symbol") == "AAPL"
    assert report.get("missing", "default") == "default"
