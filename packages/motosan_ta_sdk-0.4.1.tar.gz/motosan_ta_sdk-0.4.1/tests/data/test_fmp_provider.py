import pytest
from ta_sdk.data.base import FundamentalProvider
from ta_sdk.data.fmp_provider import FMPProvider


def test_fmp_is_fundamental_provider():
    p = FMPProvider(api_key="test")
    assert isinstance(p, FundamentalProvider)


@pytest.mark.integration
def test_fmp_get_financials():
    import os

    key = os.environ.get("FMP_API_KEY", "")
    if not key:
        pytest.skip("FMP_API_KEY not set")
    p = FMPProvider(api_key=key)
    f = p.get_financials("AAPL")
    assert f.symbol == "AAPL"
    assert f.market_cap is not None
    assert f.market_cap > 0
