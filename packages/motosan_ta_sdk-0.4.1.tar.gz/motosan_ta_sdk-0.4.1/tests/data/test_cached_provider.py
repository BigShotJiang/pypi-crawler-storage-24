import tempfile

import pandas as pd
import pytest
from unittest.mock import MagicMock

from ta_sdk.data.cached_provider import CachedProvider
from ta_sdk.data.models import Market, OHLCVData, Quote


@pytest.fixture
def mock_provider():
    provider = MagicMock()
    provider.supports_market.return_value = True
    provider.get_ohlcv.return_value = OHLCVData(
        symbol="AAPL",
        market=Market.US,
        df=pd.DataFrame(
            {"open": [1], "high": [2], "low": [0.5], "close": [1.5], "volume": [100]}
        ),
        currency="USD",
        timezone="US/Eastern",
    )
    provider.get_quote.return_value = Quote(
        symbol="AAPL",
        price=150.0,
        volume=1_000_000,
        change_pct=1.5,
        market=Market.US,
    )
    return provider


@pytest.fixture
def cached(mock_provider):
    with tempfile.TemporaryDirectory() as tmpdir:
        cp = CachedProvider(mock_provider, cache_dir=tmpdir)
        yield cp
        cp.close()


def test_get_ohlcv_caches_result(cached, mock_provider):
    result1 = cached.get_ohlcv("AAPL", "1y", "1d")
    result2 = cached.get_ohlcv("AAPL", "1y", "1d")
    assert result1.symbol == "AAPL"
    assert result2.symbol == "AAPL"
    # Provider should only be called once; second call served from cache
    mock_provider.get_ohlcv.assert_called_once_with("AAPL", "1y", "1d")


def test_get_ohlcv_different_params_not_cached(cached, mock_provider):
    cached.get_ohlcv("AAPL", "1y", "1d")
    cached.get_ohlcv("AAPL", "6mo", "1d")
    assert mock_provider.get_ohlcv.call_count == 2


def test_get_quote_caches_result(cached, mock_provider):
    q1 = cached.get_quote("AAPL")
    q2 = cached.get_quote("AAPL")
    assert q1.price == 150.0
    assert q2.price == 150.0
    mock_provider.get_quote.assert_called_once_with("AAPL")


def test_get_quote_different_symbols(cached, mock_provider):
    cached.get_quote("AAPL")
    cached.get_quote("MSFT")
    assert mock_provider.get_quote.call_count == 2


def test_supports_market_delegates(cached, mock_provider):
    assert cached.supports_market(Market.US) is True
    mock_provider.supports_market.assert_called_once_with(Market.US)


def test_clear_invalidates_cache(cached, mock_provider):
    cached.get_ohlcv("AAPL")
    cached.clear()
    cached.get_ohlcv("AAPL")
    assert mock_provider.get_ohlcv.call_count == 2


def test_close_does_not_raise(mock_provider):
    with tempfile.TemporaryDirectory() as tmpdir:
        cp = CachedProvider(mock_provider, cache_dir=tmpdir)
        cp.get_ohlcv("AAPL")
        cp.close()  # should not raise
