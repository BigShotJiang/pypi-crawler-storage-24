import pandas as pd
import numpy as np
from ta_sdk.screeners.pullback import check_pullback


def _make_pullback_stock(n=300):
    """Stock in uptrend pulling back to 50 SMA support."""
    # Strong uptrend then pullback then small bounce
    prices = list(np.linspace(50, 130, 260))  # strong uptrend
    prices += list(np.linspace(130, 112, 35))  # pullback ~14%
    prices += list(np.linspace(112, 114, 5))  # small bounce
    close = pd.Series(prices[:n])
    high = close + 1.5
    low = close - 1.5
    volume = pd.Series(np.full(n, 2000000))
    volume.iloc[-5:] = 3000000
    return pd.DataFrame(
        {
            "open": close,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
        }
    )


def test_pullback_detected():
    df = _make_pullback_stock()
    result = check_pullback(df)
    assert result["signal"] is True
    assert "support_level" in result


def test_pullback_not_detected_downtrend():
    n = 300
    close = pd.Series(np.linspace(150, 50, n))  # downtrend
    df = pd.DataFrame(
        {
            "open": close,
            "high": close + 1,
            "low": close - 1,
            "close": close,
            "volume": np.full(n, 2000000),
        }
    )
    result = check_pullback(df)
    assert result["signal"] is False
