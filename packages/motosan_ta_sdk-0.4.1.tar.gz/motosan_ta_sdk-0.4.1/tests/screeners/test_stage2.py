import pandas as pd
import numpy as np
from ta_sdk.screeners.stage2 import check_stage2


def _make_stage2_stock(n=300):
    """Stock in clear Stage 2 uptrend."""
    close = pd.Series(np.linspace(50, 150, n))  # strong uptrend
    high = close + 2
    low = close - 2
    volume = pd.Series(np.full(n, 3000000))
    df = pd.DataFrame(
        {"open": close, "high": high, "low": low, "close": close, "volume": volume}
    )
    return df


def test_stage2_passes_uptrend():
    df = _make_stage2_stock()
    result = check_stage2(df)
    assert result["passes"] is True
    assert result["score"] >= 5  # at least 5/7


def test_stage2_fails_downtrend():
    df = _make_stage2_stock()
    df["close"] = df["close"].iloc[::-1].values  # reverse = downtrend
    df["high"] = df["close"] + 2
    df["low"] = df["close"] - 2
    result = check_stage2(df)
    assert result["passes"] is False
