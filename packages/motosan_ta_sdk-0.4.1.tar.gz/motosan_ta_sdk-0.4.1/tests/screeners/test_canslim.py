import pandas as pd
import numpy as np
from ta_sdk.screeners.canslim import check_canslim


def _make_uptrend_df(n=300):
    close = pd.Series(np.linspace(50, 150, n))
    return pd.DataFrame(
        {
            "open": close,
            "high": close + 2,
            "low": close - 2,
            "close": close,
            "volume": np.full(n, 3000000),
        }
    )


def _good_fundamentals():
    return {
        "eps_growth_qtr": 25.0,  # C: 25%+ quarterly EPS growth
        "eps_growth_annual": 20.0,  # A: 20%+ annual EPS growth
        "roe": 18.0,  # A: 17%+ ROE
        "new_product": True,  # N: new product/management/price high
        "institutional_pct": 40.0,  # I: institutional sponsorship
    }


def test_canslim_passes_good_stock():
    df = _make_uptrend_df()
    result = check_canslim(df, _good_fundamentals())
    assert result["passes"] is True
    assert result["score"] >= 5


def test_canslim_fails_bad_fundamentals():
    df = _make_uptrend_df()
    bad = {
        "eps_growth_qtr": -5.0,
        "eps_growth_annual": 2.0,
        "roe": 5.0,
        "new_product": False,
        "institutional_pct": 5.0,
    }
    result = check_canslim(df, bad)
    assert result["passes"] is False
