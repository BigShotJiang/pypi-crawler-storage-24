import pandas as pd
import numpy as np
from ta_sdk.screeners.entry_signal import check_entry_signal


def _make_breakout_stock(n=300):
    """Stock breaking out of a base with volume surge."""
    # Uptrend then base then breakout
    prices = list(np.linspace(50, 100, 200))  # uptrend
    prices += [100.0] * 80  # flat base
    prices += list(np.linspace(100, 110, 20))  # breakout
    close = pd.Series(prices[:n])
    high = close + 1
    low = close - 1
    volume = pd.Series(np.full(n, 2000000))
    # Volume surge on breakout
    volume.iloc[-20:] = 5000000
    return pd.DataFrame(
        {
            "open": close,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
        }
    )


def test_entry_signal_valid_breakout():
    df = _make_breakout_stock()
    result = check_entry_signal(df)
    assert result["signal"] is True
    assert "buy_point" in result
    assert "stop" in result


def test_entry_signal_no_signal_downtrend():
    n = 300
    close = pd.Series(np.linspace(150, 50, n))  # downtrend
    df = pd.DataFrame(
        {
            "open": close,
            "high": close + 1,
            "low": close - 1,
            "close": close,
            "volume": np.full(n, 2000000),
        }
    )
    result = check_entry_signal(df)
    assert result["signal"] is False
