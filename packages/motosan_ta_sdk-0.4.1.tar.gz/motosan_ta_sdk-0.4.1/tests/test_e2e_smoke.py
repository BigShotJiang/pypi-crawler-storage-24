"""End-to-end smoke tests for the ta-sdk pipeline.

These tests verify that the full analysis pipeline works end-to-end
using synthetic data (no network calls required).
"""

import numpy as np
import pandas as pd

from ta_sdk.indicators.moving_averages import sma, ema
from ta_sdk.indicators.momentum import rsi, macd
from ta_sdk.indicators.volatility import atr
from ta_sdk.indicators.volume import volume_sma, obv
from ta_sdk.indicators.relative import rs_rating
from ta_sdk.screeners.stage2 import check_stage2
from ta_sdk.screeners.entry_signal import check_entry_signal
from ta_sdk.screeners.pullback import check_pullback
from ta_sdk.patterns.vcp import detect_vcp
from ta_sdk.patterns.cup_handle import detect_cup_handle
from ta_sdk.risk.stop_loss import calc_stop_fixed_pct, calc_stop_atr, calc_stop_pattern
from ta_sdk.risk.position_size import calc_position_size
from ta_sdk.risk.rr_ratio import calc_rr_ratio
from ta_sdk.analysis.full_analysis import analyze_stock
from ta_sdk.analysis.market_health import check_market_health
from ta_sdk.analysis.report import generate_report


def _make_uptrend_df(n: int = 300) -> pd.DataFrame:
    """Create synthetic uptrend OHLCV data."""
    np.random.seed(42)
    base = 50.0
    noise = np.random.normal(0, 0.5, n)
    trend = np.linspace(0, 60, n)
    close = base + trend + np.cumsum(noise * 0.3)
    # Ensure monotonically positive
    close = np.maximum(close, 10.0)
    high = close + np.abs(np.random.normal(0.5, 0.3, n))
    low = close - np.abs(np.random.normal(0.5, 0.3, n))
    open_ = close + np.random.normal(0, 0.3, n)
    volume = np.random.randint(500_000, 2_000_000, n).astype(float)

    dates = pd.date_range(end=pd.Timestamp.now(), periods=n, freq="B")
    return pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": volume},
        index=dates,
    )


class TestE2EIndicators:
    """Verify all indicators work on realistic synthetic data."""

    def test_full_indicator_pipeline(self):
        df = _make_uptrend_df()
        close = df["close"]
        high = df["high"]
        low = df["low"]
        volume = df["volume"]

        # Moving averages
        sma_50 = sma(close, 50)
        sma_200 = sma(close, 200)
        ema_21 = ema(close, 21)
        assert not sma_50.dropna().empty
        assert not sma_200.dropna().empty
        assert not ema_21.dropna().empty

        # Momentum
        rsi_14 = rsi(close, 14)
        macd_line, signal_line, histogram = macd(close)
        assert 0 <= rsi_14.dropna().iloc[-1] <= 100
        assert len(macd_line) == len(close)

        # Volatility
        atr_14 = atr(high, low, close, 14)
        assert atr_14.dropna().iloc[-1] > 0

        # Volume
        vol_sma = volume_sma(volume, 50)
        obv_series = obv(close, volume)
        assert not vol_sma.dropna().empty
        assert len(obv_series) == len(close)

    def test_relative_strength(self):
        df = _make_uptrend_df()
        benchmark = _make_uptrend_df()  # same seed, acts as benchmark
        rating = rs_rating(df["close"], benchmark["close"])
        assert isinstance(rating, float)


class TestE2EScreeners:
    """Verify screeners work on synthetic data."""

    def test_stage2_on_uptrend(self):
        df = _make_uptrend_df()
        result = check_stage2(df)
        assert isinstance(result, dict)
        assert "passes" in result or "passed" in result
        assert "score" in result

    def test_entry_signal_pipeline(self):
        df = _make_uptrend_df()
        result = check_entry_signal(df)
        assert isinstance(result, dict)
        assert "signal" in result

    def test_pullback_pipeline(self):
        df = _make_uptrend_df()
        result = check_pullback(df)
        assert isinstance(result, dict)


class TestE2ERisk:
    """Verify risk calculations work together."""

    def test_full_risk_pipeline(self):
        entry = 100.0
        atr_val = 3.0
        pattern_low = 92.0

        # Calculate stops using all three methods
        stop_fixed = calc_stop_fixed_pct(entry, 7.0)
        stop_atr = calc_stop_atr(entry, atr_val, 2.0)
        stop_pattern = calc_stop_pattern(entry, pattern_low)

        assert stop_fixed < entry
        assert stop_atr < entry
        assert stop_pattern < entry

        # Use the tightest stop (highest value below entry)
        stop = max(stop_fixed, stop_atr, stop_pattern)

        # Position sizing — returns a dict
        result = calc_position_size(
            account_value=100_000,
            risk_pct=1.0,
            entry=entry,
            stop=stop,
        )
        assert isinstance(result, dict)
        assert result["shares"] > 0
        assert result["position_value"] > 0
        assert result["risk_amount"] > 0

        # Risk/Reward
        target = entry + 3 * (entry - stop)  # 3:1 R:R target
        rr = calc_rr_ratio(entry, stop, target)
        assert rr >= 2.5  # Should be ~3:1


class TestE2EAnalysis:
    """Verify analysis orchestrators work end-to-end."""

    def test_analyze_stock_returns_report(self):
        df = _make_uptrend_df()
        result = analyze_stock(df, symbol="TEST")
        assert hasattr(result, "trend")
        assert hasattr(result, "indicators")
        assert hasattr(result, "stage2")
        # dict-style access should also work
        assert "trend" in result
        assert "indicators" in result
        assert "stage2" in result

    def test_market_health_returns_dict(self):
        df = _make_uptrend_df()
        result = check_market_health(df)
        assert isinstance(result, dict)
        assert "condition" in result

    def test_generate_report_returns_markdown(self):
        df = _make_uptrend_df()
        analysis = analyze_stock(df, symbol="TEST")
        report = generate_report(analysis)
        assert isinstance(report, str)
        assert len(report) > 0


class TestE2EPatterns:
    """Verify pattern detection doesn't crash on realistic data."""

    def test_vcp_detection_runs(self):
        df = _make_uptrend_df()
        result = detect_vcp(df)
        # Returns PatternResult dataclass
        assert hasattr(result, "pattern_type")
        assert hasattr(result, "detected")
        assert result.pattern_type == "vcp"

    def test_cup_handle_detection_runs(self):
        df = _make_uptrend_df()
        result = detect_cup_handle(df)
        assert hasattr(result, "pattern_type")
        assert hasattr(result, "detected")
        assert result.pattern_type == "cup_handle"
