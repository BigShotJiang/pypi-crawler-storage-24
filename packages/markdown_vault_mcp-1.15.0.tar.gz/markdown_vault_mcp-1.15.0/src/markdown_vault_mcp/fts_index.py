"""SQLite FTS5 index for full-text search and tag filtering."""

from __future__ import annotations

import datetime
import json
import logging
import sqlite3
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING, Any

from markdown_vault_mcp.types import FTSResult, ParsedNote

if TYPE_CHECKING:
    from collections.abc import Iterable

logger = logging.getLogger(__name__)


def _json_default(obj: Any) -> str:
    """Handle non-JSON-native types from YAML frontmatter.

    YAML parsers auto-detect date-like strings (e.g. ``2024-01-15``) as
    ``datetime.date`` or ``datetime.datetime`` objects, and bare time
    strings (e.g. ``15:30:00``) as ``datetime.time``.  This handler
    converts them to ISO-format strings so ``json.dumps()`` can
    serialise frontmatter without crashing.
    """
    if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# DDL executed once on connection open.
_SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    folder TEXT NOT NULL DEFAULT '',
    frontmatter_json TEXT,
    content_hash TEXT NOT NULL,
    modified_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS sections (
    id INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    heading TEXT,
    heading_level INTEGER NOT NULL,
    content TEXT NOT NULL,
    start_line INTEGER NOT NULL,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS document_tags (
    id INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    tag_key TEXT NOT NULL,
    tag_value TEXT NOT NULL,
    UNIQUE(document_id, tag_key, tag_value),
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_tags_kv ON document_tags(tag_key, tag_value);
CREATE INDEX IF NOT EXISTS idx_tags_docid ON document_tags(document_id);

CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY,
    source_id INTEGER NOT NULL,
    target_path TEXT NOT NULL,
    link_text TEXT NOT NULL DEFAULT '',
    link_type TEXT NOT NULL,
    fragment TEXT,
    raw_target TEXT NOT NULL DEFAULT '',
    FOREIGN KEY (source_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_links_target ON links(target_path);
CREATE INDEX IF NOT EXISTS idx_links_source ON links(source_id);

CREATE INDEX IF NOT EXISTS idx_documents_modified_at
    ON documents(modified_at DESC);

CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(
    path, title, folder, heading, content,
    tokenize='porter unicode61'
);
"""


def _escape_like(value: str) -> str:
    """Escape SQLite LIKE special characters in ``value``.

    SQLite LIKE treats ``%`` and ``_`` as wildcards and ``\\`` as the escape
    character (when ``ESCAPE '\\'`` is declared).  This function escapes all
    three so that a user-supplied folder name is matched literally.

    Args:
        value: Raw string that will be embedded in a LIKE pattern.

    Returns:
        String with ``\\``, ``%``, and ``_`` replaced by their escaped forms.
    """
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _derive_folder(path: str) -> str:
    """Derive the folder from a document's relative path.

    Args:
        path: Document relative path including ``.md`` extension,
            e.g. ``"Journal/2024-01-15.md"`` or ``"README.md"``.

    Returns:
        The parent directory as a forward-slash string, or ``""`` for
        documents at the collection root. Examples::

            "Journal/note.md"             -> "Journal"
            "Journal/2024/January/a.md"   -> "Journal/2024/January"
            "README.md"                   -> ""
    """
    parent = Path(path).parent
    # PurePosixPath('.') means no parent directory.
    folder = parent.as_posix()
    return "" if folder == "." else folder


def _open_connection(db_path: Path | str) -> sqlite3.Connection:
    """Open an SQLite connection with required pragmas and schema applied.

    Args:
        db_path: Filesystem path or ``":memory:"`` for an in-memory database.

    Returns:
        An open :class:`sqlite3.Connection` with the schema applied and
        ``foreign_keys`` enforcement active.
    """
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    # Apply schema; executescript commits implicitly.
    conn.executescript(_SCHEMA_SQL)
    # Migrate existing databases: add columns introduced after initial schema.
    # ALTER TABLE ADD COLUMN is idempotent-guarded via try/except because
    # SQLite only supports ADD COLUMN IF NOT EXISTS from version 3.35 onwards.
    try:
        conn.execute("ALTER TABLE links ADD COLUMN raw_target TEXT NOT NULL DEFAULT ''")
        conn.commit()
    except sqlite3.OperationalError as e:
        if "duplicate column name" not in str(e).lower():
            raise  # Unexpected error — re-raise.
    # Ensure foreign_keys stays ON for subsequent statements (executescript
    # does not guarantee this survives across statement boundaries in all
    # SQLite versions).
    conn.execute("PRAGMA foreign_keys = ON")
    # WAL mode allows concurrent readers during writes — essential for
    # search queries running while reindex or write operations update the DB.
    # In-memory databases do not support WAL; skip the pragma to avoid a
    # spurious warning (SQLite silently uses 'memory' journal mode).
    if str(db_path) != ":memory:":
        result = conn.execute("PRAGMA journal_mode = WAL").fetchone()
        if result is None or result[0].lower() != "wal":
            logger.warning(
                "Could not enable WAL journal mode (got %s); "
                "concurrent reads during writes may block",
                result[0] if result else "no result",
            )
    conn.commit()
    return conn


class FTSIndex:
    """SQLite FTS5 index providing BM25 search and tag filtering.

    Wraps a single SQLite database file (or in-memory database) and exposes
    CRUD operations and full-text search over a collection of markdown
    documents.

    Tag indexing behaviour is controlled by ``indexed_frontmatter_fields``:
    only the listed frontmatter keys are promoted into the ``document_tags``
    table for structured filtering.  Scalar values produce one row each; list
    values produce one row per item (deduplicated per document).  Complex
    types (nested dicts, objects) are stored in the raw JSON blob only and
    are not indexed.

    Args:
        db_path: Path to the SQLite database file.  Pass ``":memory:"`` (the
            default) for a transient in-memory database.
        indexed_frontmatter_fields: Frontmatter keys whose values are
            promoted to the ``document_tags`` table.  ``None`` means no tag
            indexing.
    """

    def __init__(
        self,
        db_path: Path | str = ":memory:",
        indexed_frontmatter_fields: list[str] | None = None,
    ) -> None:
        self._db_path = db_path
        self._indexed_fields: list[str] = indexed_frontmatter_fields or []
        self._conn = _open_connection(db_path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _insert_document(
        self,
        cur: sqlite3.Cursor,
        note: ParsedNote,
        folder: str,
    ) -> int:
        """Insert a row into ``documents`` and return its new ``id``.

        Args:
            cur: Active cursor inside the current transaction.
            note: Parsed document to insert.
            folder: Pre-derived folder string.

        Returns:
            The ``ROWID`` / ``id`` of the newly inserted document row.

        Raises:
            RuntimeError: If the INSERT did not return a row ID.
        """
        cur.execute(
            """
            INSERT INTO documents (path, title, folder, frontmatter_json,
                                   content_hash, modified_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                note.path,
                note.title,
                folder,
                json.dumps(note.frontmatter, default=_json_default),
                note.content_hash,
                note.modified_at,
            ),
        )
        if cur.lastrowid is None:
            raise RuntimeError("INSERT did not return a row ID")
        return cur.lastrowid

    def _insert_sections(
        self,
        cur: sqlite3.Cursor,
        document_id: int,
        note: ParsedNote,
    ) -> None:
        """Insert all chunks for a document into ``sections``.

        Also inserts one row per chunk into the ``notes_fts`` virtual table.

        Args:
            cur: Active cursor inside the current transaction.
            document_id: The ``id`` of the parent document row.
            note: Parsed document whose chunks are to be inserted.
        """
        folder = _derive_folder(note.path)
        for chunk in note.chunks:
            cur.execute(
                """
                INSERT INTO sections (document_id, heading, heading_level,
                                      content, start_line)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    document_id,
                    chunk.heading,
                    chunk.heading_level,
                    chunk.content,
                    chunk.start_line,
                ),
            )
            cur.execute(
                """
                INSERT INTO notes_fts (path, title, folder, heading, content)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    note.path,
                    note.title,
                    folder,
                    chunk.heading or "",
                    chunk.content,
                ),
            )

    def _insert_tags(
        self,
        cur: sqlite3.Cursor,
        document_id: int,
        note: ParsedNote,
    ) -> None:
        """Index frontmatter values into ``document_tags``.

        Only keys listed in ``indexed_frontmatter_fields`` are processed.
        Scalar values produce one row; list values produce one row per item
        (deduplicated per document).  Complex types (dicts, etc.) are skipped.

        Args:
            cur: Active cursor inside the current transaction.
            document_id: The ``id`` of the parent document row.
            note: Parsed document whose frontmatter is to be indexed.
        """
        if not self._indexed_fields:
            return

        for key in self._indexed_fields:
            value = note.frontmatter.get(key)
            if value is None:
                continue

            if isinstance(value, list):
                # One row per item; skip non-scalar elements.
                seen: set[str] = set()
                for item in value:
                    if (
                        isinstance(item, (str, int, float, bool))
                        and not isinstance(item, bool)
                    ) or isinstance(item, bool):
                        # Accept all scalar types.
                        tag_val = str(item)
                        if tag_val not in seen:
                            seen.add(tag_val)
                            cur.execute(
                                """
                                INSERT OR IGNORE INTO document_tags
                                    (document_id, tag_key, tag_value)
                                VALUES (?, ?, ?)
                                """,
                                (document_id, key, tag_val),
                            )
            elif isinstance(value, dict):
                # Complex type — skip.
                logger.debug(
                    "Skipping complex frontmatter value for key %r in %s",
                    key,
                    note.path,
                )
            else:
                # Scalar value.
                cur.execute(
                    """
                    INSERT OR IGNORE INTO document_tags
                        (document_id, tag_key, tag_value)
                    VALUES (?, ?, ?)
                    """,
                    (document_id, key, str(value)),
                )

    def _insert_links(
        self,
        cur: sqlite3.Cursor,
        document_id: int,
        note: ParsedNote,
    ) -> None:
        """Insert all extracted links for a document into ``links``.

        Follows the same delete-then-insert pattern as :meth:`_insert_tags`.
        Any existing links for ``document_id`` are removed first (via ON DELETE
        CASCADE when the document row is deleted), so this method simply inserts.

        Args:
            cur: Active cursor inside the current transaction.
            document_id: The ``id`` of the parent document row.
            note: Parsed document whose links are to be inserted.
        """
        for link in note.links:
            cur.execute(
                """
                INSERT INTO links (source_id, target_path, link_text,
                                   link_type, fragment, raw_target)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    document_id,
                    link.target_path,
                    link.link_text,
                    link.link_type,
                    link.fragment,
                    link.raw_target,
                ),
            )

    def _delete_document(self, cur: sqlite3.Cursor, path: str) -> int:
        """Delete a document row (cascade deletes sections and tags).

        Also removes all FTS rows for the document's path.

        Args:
            cur: Active cursor inside the current transaction.
            path: Relative document path.

        Returns:
            Number of document rows deleted (0 or 1).
        """
        cur.execute("DELETE FROM notes_fts WHERE path = ?", (path,))
        cur.execute("DELETE FROM documents WHERE path = ?", (path,))
        return cur.rowcount

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_from_notes(self, notes: Iterable[ParsedNote]) -> int:
        """Bulk-insert all notes, replacing any existing data.

        Existing documents are upserted (delete + re-insert) so
        ``build_from_notes`` is idempotent when called on an already-populated
        index.  All inserts are wrapped in a single transaction for
        performance and atomicity.

        Args:
            notes: Iterable of parsed documents to index.

        Returns:
            Total number of chunks (sections) indexed.
        """
        total_chunks = 0
        with self._conn:
            cur = self._conn.cursor()
            for note in notes:
                folder = _derive_folder(note.path)
                self._delete_document(cur, note.path)
                doc_id = self._insert_document(cur, note, folder)
                self._insert_sections(cur, doc_id, note)
                self._insert_tags(cur, doc_id, note)
                self._insert_links(cur, doc_id, note)
                total_chunks += len(note.chunks)
                logger.debug(
                    "build_from_notes: indexed %d chunks for %s",
                    len(note.chunks),
                    note.path,
                )
        logger.info("build_from_notes: indexed %d chunks total", total_chunks)
        return total_chunks

    def upsert_note(self, note: ParsedNote) -> int:
        """Insert or replace a single document in the index.

        Deletes any existing rows for ``note.path``, then inserts the
        document, its sections, and its tags in a single transaction.

        Args:
            note: Parsed document to insert or replace.

        Returns:
            Number of chunks (sections) indexed for this document.
        """
        folder = _derive_folder(note.path)
        with self._conn:
            cur = self._conn.cursor()
            self._delete_document(cur, note.path)
            doc_id = self._insert_document(cur, note, folder)
            self._insert_sections(cur, doc_id, note)
            self._insert_tags(cur, doc_id, note)
            self._insert_links(cur, doc_id, note)
        logger.debug(
            "upsert_note: indexed %d chunks for %s", len(note.chunks), note.path
        )
        return len(note.chunks)

    def delete_by_path(self, path: str) -> int:
        """Remove a document and all its data from the index.

        Args:
            path: Relative document path (e.g. ``"Journal/note.md"``).

        Returns:
            Number of document rows deleted (0 if path was not indexed).
        """
        with self._conn:
            cur = self._conn.cursor()
            deleted = self._delete_document(cur, path)
        if deleted:
            logger.debug("delete_by_path: removed %s", path)
        return deleted

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        folder: str | None = None,
        filters: dict[str, str] | None = None,
    ) -> list[FTSResult]:
        """Full-text search using BM25 ranking.

        Optionally filters results by folder prefix and/or frontmatter tag
        key-value pairs.  Each entry in ``filters`` is ANDed.

        Args:
            query: FTS5 query string.
            limit: Maximum number of results to return.
            folder: If provided, only return documents whose ``folder``
                starts with this string.
            filters: Dict of ``{tag_key: tag_value}`` pairs.  All pairs must
                match (AND semantics).

        Returns:
            List of :class:`~markdown_vault_mcp.types.FTSResult` objects ordered by
            descending BM25 score.
        """
        # Build tag subquery filters (one per entry, ANDed).
        tag_clauses: list[str] = []
        tag_params: list[str] = []
        if filters:
            for key, value in filters.items():
                tag_clauses.append(
                    "d.id IN ("
                    "  SELECT document_id FROM document_tags"
                    "  WHERE tag_key = ? AND tag_value = ?"
                    ")"
                )
                tag_params.extend([key, value])

        folder_clause = ""
        folder_params: list[str] = []
        if folder is not None:
            # Match exact folder or sub-folders.  Escape LIKE wildcards in the
            # user-supplied folder value so that literal '%' and '_' characters
            # are matched as-is rather than treated as SQL wildcards.
            escaped = _escape_like(folder)
            folder_clause = "AND (d.folder = ? OR d.folder LIKE ? ESCAPE '\\')"
            folder_params = [folder, escaped + "/%"]

        tag_filter_sql = ""
        if tag_clauses:
            tag_filter_sql = "AND " + " AND ".join(tag_clauses)

        sql = f"""
            SELECT
                f.path,
                d.title,
                d.folder,
                f.heading,
                f.content,
                ABS(f.rank) AS score
            FROM notes_fts f
            JOIN documents d ON d.path = f.path
            WHERE notes_fts MATCH ?
              {folder_clause}
              {tag_filter_sql}
            ORDER BY score DESC
            LIMIT ?
        """

        params: list[object] = [query, *folder_params, *tag_params, limit]
        logger.debug(
            "FTS search: query=%r folder=%r filters=%r limit=%d",
            query,
            folder,
            filters,
            limit,
        )
        cur = self._conn.execute(sql, params)
        rows = cur.fetchall()
        logger.debug("FTS search: %d results for query=%r", len(rows), query)

        results: list[FTSResult] = []
        for row in rows:
            results.append(
                FTSResult(
                    path=row["path"],
                    title=row["title"],
                    folder=row["folder"],
                    heading=row["heading"] or None,
                    content=row["content"],
                    score=row["score"],
                )
            )
        return results

    def get_note(self, path: str) -> dict | None:
        """Return document metadata for a single note.

        Args:
            path: Relative document path.

        Returns:
            A dict with keys ``path``, ``title``, ``folder``,
            ``frontmatter_json``, ``content_hash``, ``modified_at``, or
            ``None`` if the document is not indexed.
        """
        cur = self._conn.execute(
            """
            SELECT path, title, folder, frontmatter_json,
                   content_hash, modified_at
            FROM documents
            WHERE path = ?
            """,
            (path,),
        )
        row = cur.fetchone()
        if row is None:
            return None
        return dict(row)

    def list_notes(self, *, folder: str | None = None) -> list[dict]:
        """List all indexed documents, optionally filtered by folder.

        Args:
            folder: If provided, only return documents whose ``folder``
                matches exactly or is a sub-folder of this value.

        Returns:
            List of dicts with the same shape as :meth:`get_note`.
        """
        if folder is not None:
            # Escape LIKE wildcards in the user-supplied folder value so that
            # literal '%' and '_' characters are matched as-is.
            escaped = _escape_like(folder)
            cur = self._conn.execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       content_hash, modified_at
                FROM documents
                WHERE folder = ? OR folder LIKE ? ESCAPE '\\'
                ORDER BY path
                """,
                (folder, escaped + "/%"),
            )
        else:
            cur = self._conn.execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       content_hash, modified_at
                FROM documents
                ORDER BY path
                """
            )
        return [dict(row) for row in cur.fetchall()]

    def list_folders(self) -> list[str]:
        """Return all distinct folder values across the index.

        Returns:
            Sorted list of folder strings (including ``""`` for the root).
        """
        cur = self._conn.execute(
            "SELECT DISTINCT folder FROM documents ORDER BY folder"
        )
        return [row[0] for row in cur.fetchall()]

    def list_field_values(self, field: str) -> list[str]:
        """Return all distinct tag values for a given frontmatter field.

        If ``field`` was not in ``indexed_frontmatter_fields``, returns an
        empty list.

        Args:
            field: Frontmatter key (e.g. ``"cluster"``).

        Returns:
            Sorted list of distinct value strings.
        """
        cur = self._conn.execute(
            """
            SELECT DISTINCT tag_value
            FROM document_tags
            WHERE tag_key = ?
            ORDER BY tag_value
            """,
            (field,),
        )
        return [row[0] for row in cur.fetchall()]

    def count_chunks(self) -> int:
        """Return the total number of chunk rows in the ``sections`` table.

        Returns:
            Integer count of all indexed chunks across all documents.
        """
        row = self._conn.execute("SELECT COUNT(*) FROM sections").fetchone()
        return row[0] if row else 0

    def get_toc(self, path: str) -> list[dict[str, str | int]]:
        """Return headings for a document, ordered by position.

        Queries the sections table for distinct non-NULL headings, ordered by
        the first row that introduces each heading.

        Args:
            path: Relative document path (e.g. ``"Journal/note.md"``).

        Returns:
            List of ``{"heading": str, "level": int}`` dicts ordered by
            first appearance.  Empty list if the document is not found or
            has no headings.
        """
        cur = self._conn.execute(
            """
            SELECT heading, heading_level
            FROM sections
            WHERE document_id = (SELECT id FROM documents WHERE path = ?)
              AND heading IS NOT NULL
            GROUP BY heading, heading_level
            ORDER BY MIN(rowid)
            """,
            (path,),
        )
        return [
            {"heading": row["heading"], "level": row["heading_level"]}
            for row in cur.fetchall()
        ]

    def get_backlinks(self, path: str, *, limit: int | None = None) -> list[dict]:
        """Return all documents that link TO the given path.

        Args:
            path: Relative document path that is the link target
                (e.g. ``"notes/topic.md"``).
            limit: If provided, return at most this many results.

        Returns:
            List of dicts with keys ``source_path``, ``source_title``,
            ``link_text``, ``link_type``, ``fragment``, ``raw_target``.
        """
        limit_clause = "" if limit is None else "LIMIT ?"
        params: tuple = (path,) if limit is None else (path, limit)
        cur = self._conn.execute(
            f"""
            SELECT d.path AS source_path,
                   d.title AS source_title,
                   l.link_text,
                   l.link_type,
                   l.fragment,
                   l.raw_target
            FROM links l
            JOIN documents d ON d.id = l.source_id
            WHERE l.target_path = ?
            ORDER BY d.path, l.rowid
            {limit_clause}
            """,
            params,
        )
        return [dict(row) for row in cur.fetchall()]

    def get_outlinks(self, path: str, *, limit: int | None = None) -> list[dict]:
        """Return all links FROM the given document.

        Uses a LEFT JOIN to check target existence in a single query,
        avoiding N+1 round-trips.

        Args:
            path: Relative document path that is the link source
                (e.g. ``"notes/topic.md"``).
            limit: If provided, return at most this many results.

        Returns:
            List of dicts with keys ``target_path``, ``link_text``,
            ``link_type``, ``fragment``, ``raw_target``, ``exists`` (bool).
        """
        limit_clause = "" if limit is None else "LIMIT ?"
        params: tuple = (path,) if limit is None else (path, limit)
        cur = self._conn.execute(
            f"""
            SELECT l.target_path,
                   l.link_text,
                   l.link_type,
                   l.fragment,
                   l.raw_target,
                   (t.id IS NOT NULL) AS target_exists
            FROM links l
            JOIN documents d ON d.id = l.source_id
            LEFT JOIN documents t ON t.path = l.target_path
            WHERE d.path = ?
            ORDER BY l.rowid
            {limit_clause}
            """,
            params,
        )
        return [dict(row) for row in cur.fetchall()]

    def resolve_vault_wikilinks(self) -> int:
        """Resolve vault-wide wikilink ``target_path`` values against the document set.

        Obsidian resolves bare wikilinks (e.g. ``[[Note]]``) by searching the
        entire vault for a document whose filename matches, picking the shortest
        path (fewest path components) when multiple candidates exist.  Wikilinks
        with an explicit path (e.g. ``[[folder/Note]]``) are resolved to any
        document whose path ends with ``folder/Note.md``, again preferring the
        shortest match.

        Resolution anchors on ``raw_target`` (the original wikilink text as
        written) rather than the current ``target_path``.  This ensures
        re-resolution works correctly after a target document is moved or
        renamed — the original stem is always available regardless of how many
        times the index has been rebuilt.

        Wikilinks with an explicit relative prefix (``./`` or ``../``) are
        skipped; they are resolved relative to the source document at scan time
        and do not participate in vault-wide resolution.

        Call this method after all documents have been indexed
        (``Collection.build_index()`` and ``Collection.reindex()`` do this
        automatically).  Callers that add documents via :meth:`upsert_note`
        directly are responsible for calling this method once all upserts are
        complete.

        Uses ``substr``/``length`` comparisons instead of ``LIKE`` to avoid
        wildcard-escaping issues with filenames that contain ``%`` or ``_``.

        Returns:
            Number of link rows whose ``target_path`` was updated.
        """
        # Load all document paths once into a Python set/list for in-memory
        # matching — avoids O(N) SQL round-trips (one SELECT per wikilink row).
        doc_paths: list[str] = [
            r["path"]
            for r in self._conn.execute("SELECT path FROM documents").fetchall()
        ]

        # Fetch all wikilinks eligible for vault-wide resolution.
        # Explicit relative prefixes (./  ../) are excluded — those were
        # resolved at scan time and must not be overwritten.
        rows = self._conn.execute(
            """
            SELECT id, raw_target, target_path
            FROM links
            WHERE link_type = 'wikilink'
              AND raw_target NOT LIKE './%'
              AND raw_target NOT LIKE '../%'
            """
        ).fetchall()

        # Resolve each wikilink in Python, then batch-UPDATE.
        updates: list[tuple[str, int]] = []
        for row in rows:
            # Derive the search filename from raw_target:
            # 1. Strip any trailing fragment (#heading).
            stem = row["raw_target"]
            if "#" in stem:
                stem = stem[: stem.index("#")]
            if not stem:
                continue
            # 2. Append .md if not already present.
            search_target = stem if stem.lower().endswith(".md") else stem + ".md"

            # Find the best match: exact path or suffix match, shortest wins.
            candidates = [
                p
                for p in doc_paths
                if p == search_target or p.endswith("/" + search_target)
            ]
            if not candidates:
                continue  # Genuinely broken — no document matches.
            new_path = min(candidates, key=len)
            if new_path != row["target_path"]:
                updates.append((new_path, row["id"]))

        with self._conn:
            self._conn.executemany(
                "UPDATE links SET target_path = ? WHERE id = ?", updates
            )
        updated = len(updates)

        if updated:
            logger.debug("resolve_vault_wikilinks: resolved %d wikilink(s)", updated)
        return updated

    def get_broken_links(self, *, folder: str | None = None) -> list[dict]:
        """Return all links whose target does not exist as an indexed document.

        Args:
            folder: If provided, restrict to source documents in this folder
                (exact match or sub-folder prefix).

        Returns:
            List of dicts with keys ``source_path``, ``source_title``,
            ``target_path``, ``link_text``, ``link_type``, ``fragment``,
            ``raw_target``.
        """
        folder_clause = ""
        params: list[str] = []
        if folder is not None:
            escaped = _escape_like(folder)
            folder_clause = "AND (d.folder = ? OR d.folder LIKE ? ESCAPE '\\')"
            params = [folder, escaped + "/%"]

        sql = f"""
            SELECT d.path AS source_path,
                   d.title AS source_title,
                   l.target_path,
                   l.link_text,
                   l.link_type,
                   l.fragment,
                   l.raw_target
            FROM links l
            JOIN documents d ON d.id = l.source_id
            WHERE NOT EXISTS (
                SELECT 1 FROM documents d2 WHERE d2.path = l.target_path
            )
              {folder_clause}
            ORDER BY d.path, l.rowid
        """
        cur = self._conn.execute(sql, params)
        return [dict(row) for row in cur.fetchall()]

    def get_recent(self, *, limit: int = 20, folder: str | None = None) -> list[dict]:
        """Return the most recently modified documents.

        Args:
            limit: Maximum number of documents to return.
            folder: If provided, restrict to documents in this folder
                (exact match or sub-folder prefix).

        Returns:
            List of dicts with the same shape as :meth:`get_note`, ordered
            by ``modified_at`` descending (most recent first).
        """
        if folder is not None:
            escaped = _escape_like(folder)
            cur = self._conn.execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       modified_at
                FROM documents
                WHERE folder = ? OR folder LIKE ? ESCAPE '\\'
                ORDER BY modified_at DESC
                LIMIT ?
                """,
                (folder, escaped + "/%", limit),
            )
        else:
            cur = self._conn.execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       modified_at
                FROM documents
                ORDER BY modified_at DESC
                LIMIT ?
                """,
                (limit,),
            )
        return [dict(row) for row in cur.fetchall()]

    def get_orphan_notes(self) -> list[dict]:
        """Return all documents with no inbound or outbound links.

        A document is an orphan if it has zero rows in ``links`` as either
        source (no outlinks) AND does not appear as a target in any link row
        (no backlinks).

        Returns:
            List of dicts with keys ``path``, ``title``, ``folder``,
            ``frontmatter_json``, and ``modified_at``, ordered by path.
        """
        cur = self._conn.execute(
            """
            SELECT path, title, folder, frontmatter_json, modified_at
            FROM documents d
            WHERE NOT EXISTS (SELECT 1 FROM links WHERE source_id = d.id)
              AND NOT EXISTS (SELECT 1 FROM links WHERE target_path = d.path)
            ORDER BY path
            """
        )
        return [dict(row) for row in cur.fetchall()]

    def get_most_linked(self, limit: int = 10) -> list[dict]:
        """Return the documents with the most distinct source documents linking to them.

        Args:
            limit: Maximum number of results to return.

        Returns:
            List of dicts with keys ``path``, ``title``, ``backlink_count``,
            ordered by backlink_count descending.
        """
        cur = self._conn.execute(
            """
            SELECT d.path,
                   d.title,
                   COUNT(DISTINCT l.source_id) AS backlink_count
            FROM links l
            JOIN documents d ON d.path = l.target_path
            GROUP BY d.path, d.title
            ORDER BY backlink_count DESC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in cur.fetchall()]

    def get_connection_path(
        self, source_path: str, target_path: str, max_depth: int = 10
    ) -> list[str] | None:
        """Return the shortest undirected path between two notes via BFS.

        Treats the link graph as undirected — a link in either direction
        counts as a connection.  Raises ``ValueError`` if either path is
        not in the documents table.

        Args:
            source_path: Vault-relative path of the starting note.
            target_path: Vault-relative path of the destination note.
            max_depth: Maximum path length (number of edges).  Clamped to
                ``[1, 10]``.  Defaults to ``10``.

        Returns:
            Ordered list of vault-relative paths from *source_path* to
            *target_path* (inclusive), or ``None`` if no path exists within
            *max_depth* hops.

        Raises:
            ValueError: If *source_path* or *target_path* is not found in
                the documents table.
        """
        max_depth = max(1, min(10, max_depth))

        # Validate both endpoints exist.
        for path in (source_path, target_path):
            row = self._conn.execute(
                "SELECT 1 FROM documents WHERE path = ?", (path,)
            ).fetchone()
            if row is None:
                raise ValueError(f"Path not found in index: {path!r}")

        # Trivial case.
        if source_path == target_path:
            return [source_path]

        # Load all edges into an undirected adjacency dict.
        adj: dict[str, set[str]] = {}
        cur = self._conn.execute(
            "SELECT d1.path, d2.path FROM links l"
            " JOIN documents d1 ON d1.id = l.source_id"
            " JOIN documents d2 ON d2.path = l.target_path"
        )
        for src, tgt in cur.fetchall():
            adj.setdefault(src, set()).add(tgt)
            adj.setdefault(tgt, set()).add(src)

        # BFS with depth tracking.
        queue: deque[tuple[str, list[str]]] = deque()
        queue.append((source_path, [source_path]))
        visited: set[str] = {source_path}

        while queue:
            current, path = queue.popleft()
            if len(path) - 1 >= max_depth:
                continue
            for neighbour in adj.get(current, set()):
                if neighbour in visited:
                    continue
                new_path = [*path, neighbour]
                if neighbour == target_path:
                    logger.debug(
                        "get_connection_path: found path %s → %s in %d hops",
                        source_path,
                        target_path,
                        len(new_path) - 1,
                    )
                    return new_path
                visited.add(neighbour)
                queue.append((neighbour, new_path))

        logger.debug(
            "get_connection_path: no path found between %r and %r within depth %d",
            source_path,
            target_path,
            max_depth,
        )
        return None

    def _count_links_query(self, sql: str) -> int:
        """Execute a COUNT query, returning 0 if the links table does not exist.

        Args:
            sql: A SQL statement returning a single COUNT(*) row.

        Returns:
            The integer count, or 0 when the links table is absent (backward
            compatibility with index files predating link tracking).

        Raises:
            sqlite3.OperationalError: For any database error other than a
                missing links table.
        """
        try:
            row = self._conn.execute(sql).fetchone()
            return int(row[0])
        except sqlite3.OperationalError as e:
            if "no such table: links" in str(e).lower():
                return 0
            raise

    def count_links(self) -> int:
        """Return the total number of link rows in the links table.

        Returns:
            Total link count, or 0 if the links table does not exist.
        """
        return self._count_links_query("SELECT COUNT(*) FROM links")

    def count_broken_links(self) -> int:
        """Return the number of links whose target is not in the documents table.

        Returns:
            Broken link count, or 0 if the links table does not exist.
        """
        return self._count_links_query(
            """
            SELECT COUNT(*)
            FROM links
            WHERE NOT EXISTS (
                SELECT 1 FROM documents d WHERE d.path = links.target_path
            )
            """
        )

    def count_orphans(self) -> int:
        """Return the number of documents with no inbound or outbound links.

        Returns:
            Orphan count, or 0 if the links table does not exist.
        """
        return self._count_links_query(
            """
            SELECT COUNT(*)
            FROM documents d
            WHERE NOT EXISTS (SELECT 1 FROM links WHERE source_id = d.id)
              AND NOT EXISTS (SELECT 1 FROM links WHERE target_path = d.path)
            """
        )

    def close(self) -> None:
        """Close the underlying database connection.

        After calling this method, the index must not be used.
        """
        self._conn.close()
        logger.debug("FTSIndex closed (db_path=%s)", self._db_path)
