
class InvalidPluginNameException(Exception):
    pass
