# vorto-utils

Vorto 插件公共工具包，提供青龙面板操作、码支付、二维码生成、支付配置读取等通用功能。

## 安装

```bash
pip install vorto-utils
```

## 快速使用

```python
from vorto_utils import generate_qrcode_url, get_pay_config, QingLongClient, MaPayClient

# 生成二维码
url = generate_qrcode_url("https://example.com")

# 读取支付配置
config = get_pay_config()

# 青龙面板操作
ql = QingLongClient("S_NKF", "http://host:5700丨client_id丨client_secret")
ql.update_env("13800138000", "phone#token#unifyId", "备注信息")

# 码支付
client = MaPayClient(gateway="https://pay.example.com", pid="1001", key="your_key")
result = client.create_order(8.88, "alipay", "order_123", "商品名称")
```

## 模块说明

| 模块 | 功能 |
|------|------|
| `qrcode` | 二维码图片URL生成 |
| `pay_config` | 从 middleware 读取支付方式配置 |
| `qinglong` | 青龙面板环境变量 CRUD |
| `mapay` | 码支付下单、查单、验单 |
