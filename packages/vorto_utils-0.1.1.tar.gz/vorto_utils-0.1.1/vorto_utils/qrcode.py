# vorto_utils/qrcode.py - QR code utility
from urllib.parse import quote as url_quote


def generate_qrcode_url(content):
    """Generate QR code image URL via qrserver API"""
    encoded = url_quote(content)
    return f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={encoded}"
