# vorto_utils/account.py - Account handling utilities


def mask_account(account):
    """账号脱敏处理

    Args:
        account: 账号字符串（手机号、用户名等）

    Returns:
        str: 脱敏后的账号

    Examples:
        >>> mask_account("13800138000")
        '138****8000'
        >>> mask_account("user123456")
        'user****3456'
    """
    if not account or len(account) < 4:
        return account

    # 手机号特殊处理
    if account.isdigit() and len(account) == 11:
        return f"{account[:3]}****{account[7:]}"

    # 短账号（<=16位）
    if len(account) <= 16:
        return f"{account[:4]}****{account[-4:]}"

    # 长账号（>16位）
    return f"{account[:8]}****{account[-8:]}"


def parse_batch_accounts(input_text, separator='#'):
    """解析批量账号输入

    Args:
        input_text: 用户输入的文本，支持多行
        separator: 字段分隔符，默认 '#'

    Returns:
        list: 账号列表，每个账号是一个字典 {'field0': 'xxx', 'field1': 'yyy', ...}

    Examples:
        >>> parse_batch_accounts("13800138000#password123\\n13900139000#password456")
        [
            {'field0': '13800138000', 'field1': 'password123'},
            {'field0': '13900139000', 'field1': 'password456'}
        ]
    """
    lines = [line.strip() for line in input_text.strip().split('\n') if line.strip()]
    account_list = []

    for line in lines:
        if separator in line:
            parts = line.split(separator)
            if len(parts) >= 2:
                account_dict = {}
                for i, part in enumerate(parts):
                    if part.strip():
                        account_dict[f'field{i}'] = part.strip()
                if account_dict:
                    account_list.append(account_dict)

    return account_list
