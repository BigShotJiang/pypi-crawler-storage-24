# vorto_utils - Vorto plugin utility toolkit
# Public API exports

# 二维码和支付配置
from vorto_utils.qrcode import generate_qrcode_url
from vorto_utils.pay_config import get_pay_config

# 青龙和码支付客户端
from vorto_utils.qinglong import QingLongClient
from vorto_utils.mapay import MaPayClient

# 账号处理
from vorto_utils.account import mask_account, parse_batch_accounts

# 授权管理
from vorto_utils.auth import (
    calculate_auth_time,
    process_authorization,
    get_user_points,
    update_user_points,
    process_coin_payment,
)

# 交互工具
from vorto_utils.interaction import select_accounts

# 监控清理
from vorto_utils.monitor import check_auth_status

# 管理员功能
from vorto_utils.admin import admin_auth_all_accounts, admin_auth_by_user

__version__ = "2.0.0"

__all__ = [
    # 二维码和支付
    "generate_qrcode_url",
    "get_pay_config",
    "QingLongClient",
    "MaPayClient",
    # 账号处理
    "mask_account",
    "parse_batch_accounts",
    # 授权管理
    "calculate_auth_time",
    "process_authorization",
    "get_user_points",
    "update_user_points",
    "process_coin_payment",
    # 交互工具
    "select_accounts",
    # 监控清理
    "check_auth_status",
    # 管理员功能
    "admin_auth_all_accounts",
    "admin_auth_by_user",
]
