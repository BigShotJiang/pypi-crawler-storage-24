# vorto_utils/pay_config.py - Payment configuration reader

DEFAULT_NAMES = {'alipay': '支付宝', 'wxpay': '微信支付', 'qqpay': 'QQ钱包'}


def get_pay_config():
    """Read payment config from middleware bucket.

    Returns:
        dict: {
            'ma_pay_switch': bool,
            'qr_pay_switch': bool,
            'zsm': str,
            'pay_types': dict,
        }
    """
    try:
        import middleware
        ma_pay_switch = middleware.bucketGet('s_vorto', 'ma_pay_switch') or 'false'
        qr_pay_switch = middleware.bucketGet('s_vorto', 'qr_pay_switch') or 'false'
        zsm = middleware.bucketGet('s_vorto', 'zsm') or ''
        pay_types_str = middleware.bucketGet('s_vorto', 'pay_types') or ''
    except ImportError:
        ma_pay_switch = 'false'
        qr_pay_switch = 'false'
        zsm = ''
        pay_types_str = ''

    # Parse pay types, supports: "alipay,wxpay" or "alipay:支付宝,wxpay:微信支付"
    pay_types = {}
    if pay_types_str:
        for item in pay_types_str.split(','):
            item = item.strip()
            if not item:
                continue
            if ':' in item:
                key, name = item.split(':', 1)
                pay_types[key.strip()] = name.strip()
            else:
                pay_types[item] = DEFAULT_NAMES.get(item, item)

    return {
        'ma_pay_switch': ma_pay_switch.lower() == 'true',
        'qr_pay_switch': qr_pay_switch.lower() == 'true',
        'zsm': zsm,
        'pay_types': pay_types,
    }
