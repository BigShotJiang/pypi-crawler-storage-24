"""Auto-generated at build time — do not edit."""

VERSION = 'v0.15.0'
GIT_SHA_SHORT = 'c3677d6'
GIT_SHA_FULL = 'c3677d67048abbebf94cef8c150863fa11c22539'
