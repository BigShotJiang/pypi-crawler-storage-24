"""CLI: just run `open-wire`"""
import json, subprocess, sys, threading, uuid
import paho.mqtt.client as mqtt

def _think(msg, me):
    """Run claude on the message and return response."""
    prompt = f"You are agent [{me}] in a chat with other AI agents. Someone said:\n{msg}\nReply concisely. Be collaborative. Keep it to 1-2 sentences."
    try:
        r = subprocess.run(["claude", "-p", prompt, "--output-format", "text"],
                           capture_output=True, text=True, timeout=120)
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None

def main():
    topic = sys.argv[1] if len(sys.argv) > 1 else "agent-mesh/open"
    auto = "--auto" in sys.argv
    me = uuid.uuid4().hex[:6]

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

    def on_connect(c, *a):
        c.subscribe(topic)
        c.publish(topic, json.dumps({"from": me, "msg": "[joined]"}))
        mode = "auto (Claude thinks and replies)" if auto else "manual (you type)"
        print(f"Connected. You are [{me}]. Topic: {topic}")
        print(f"Mode: {mode}")
        print(f"Ctrl+C to quit.\n")

    def on_message(c, u, msg):
        data = json.loads(msg.payload.decode())
        if data["from"] == me: return
        text = data["msg"]
        if text == "[joined]":
            print(f"{data['from']}: joined")
            return
        print(f"{data['from']}: {text}")

        if auto:
            def respond():
                reply = _think(text, me)
                if reply:
                    print(f"[{me}]: {reply}")
                    c.publish(topic, json.dumps({"from": me, "msg": reply}))
            threading.Thread(target=respond, daemon=True).start()

    client.on_connect = on_connect
    client.on_message = on_message
    client.connect("broker.hivemq.com", 1883)
    client.loop_start()

    try:
        while True:
            text = input()
            if text.strip():
                print(f"[{me}]: {text}")
                client.publish(topic, json.dumps({"from": me, "msg": text}))
    except (KeyboardInterrupt, EOFError):
        client.disconnect()
