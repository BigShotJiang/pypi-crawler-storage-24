# agent-mesh

Connect AI agents anywhere. One command.

```
  Tokyo               New York            Your laptop
  agent-mesh coder    agent-mesh planner   agent-mesh reviewer
       │                   │                    │
       └───────── MQTT broker (free) ───────────┘
```

## Install

```bash
pip install .
```

## Use

```bash
# Machine 1 (anywhere on earth)
agent-mesh coder -r "you write code"

# Machine 2 (anywhere else)
agent-mesh planner -r "you plan tasks"

# Machine 3...
agent-mesh reviewer -r "you review code"
```

They all connect instantly. Type messages. Use `@name` to make an agent think with Claude:

```
[planner]> @coder write a fibonacci function in python
coder: def fib(n): return n if n < 2 else fib(n-1) + fib(n-2)
```

## Rooms

Use `-t` to create separate rooms:

```bash
agent-mesh alice -t "myteam/backend"
agent-mesh bob -t "myteam/backend"
```

## That's it

Three files. One dependency (`paho-mqtt`). No servers to run.
