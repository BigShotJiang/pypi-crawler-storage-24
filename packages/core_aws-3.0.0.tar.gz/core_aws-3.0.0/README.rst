core-aws
===============================================================================

This project/library contains common elements related
to AWS services...

===============================================================================

.. image:: https://img.shields.io/pypi/pyversions/core-aws.svg
    :target: https://pypi.org/project/core-aws/
    :alt: Python Versions

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-aws/-/blob/main/LICENSE
    :alt: License

.. image:: https://gitlab.com/bytecode-solutions/core/core-aws/badges/release/pipeline.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-aws/-/pipelines
    :alt: Pipeline Status

.. image:: https://readthedocs.org/projects/core-aws/badge/?version=latest
    :target: https://readthedocs.org/projects/core-aws/
    :alt: Docs Status

.. image:: https://img.shields.io/badge/security-bandit-yellow.svg
    :target: https://github.com/PyCQA/bandit
    :alt: Security

|


Installation
===============================================================================

Install from PyPI using pip:

.. code-block:: bash

    pip install core-aws
    uv pip install core-aws  # Or using UV...


Features
===============================================================================

- **AWS Service Clients**: High-level wrappers for S3, SQS, SNS, Kinesis, SSM, DynamoDB, ECS, and CloudFormation with improved error handling and type safety.
- **ETL Base Classes**: Reusable base classes for building ETL pipelines on AWS (base, S3 bucket-based, SQS-based).
- **Lambda Decorators**: Event processing decorators for SQS, SNS, and Kinesis with automatic batch failure handling.
- **Comprehensive Type Hints**: Full type definitions for Lambda contexts, events (SQS, SNS, Kinesis), SSM parameters, Cognito identity, and mobile clients.
- **CDC Targets**: Change Data Capture targets for streaming data to SQS, SNS, and Kinesis.
- **KMS Cipher**: Utilities for encryption/decryption using AWS KMS.
- **Testing Utilities**: Base classes and helpers for testing AWS-based applications.


Quick Start
===============================================================================

Installation
-------------------------------------------------------------------------------

Install the package:

.. code-block:: bash

    pip install core-aws
    uv pip install core-aws     # Or using UV...
    pip install -e ".[dev]"     # For development...


Setting Up Environment
-------------------------------------------------------------------------------

1. Install required libraries:

.. code-block:: bash

    pip install --upgrade pip
    pip install virtualenv

2. Create Python virtual environment:

.. code-block:: bash

    virtualenv --python=python3.12 .venv

3. Activate the virtual environment:

.. code-block:: bash

    source .venv/bin/activate

Install packages
-------------------------------------------------------------------------------

.. code-block:: bash

    pip install .
    pip install -e ".[dev]"

Check tests and coverage
-------------------------------------------------------------------------------

.. code-block:: shell

    python manager.py run-tests
    python manager.py run-tests --test-type integration
    python manager.py run-coverage

    # Having proper AWS credentials...
    python manager.py run-tests --test-type functional --pattern "*.py"


Contributing
===============================================================================

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass: ``pytest -n auto``
5. Run linting: ``pylint core_aws``
6. Run security checks: ``bandit -r core_aws``
7. Submit a pull request


License
===============================================================================

This project is licensed under the MIT License. See the LICENSE file for details.


Links
===============================================================================

* **Documentation:** https://core-aws.readthedocs.io/en/latest/
* **Repository:** https://gitlab.com/bytecode-solutions/core/core-aws
* **Issues:** https://gitlab.com/bytecode-solutions/core/core-aws/-/issues
* **Changelog:** https://gitlab.com/bytecode-solutions/core/core-aws/-/blob/master/CHANGELOG.md
* **PyPI:** https://pypi.org/project/core-aws/


Support
===============================================================================

For questions or support, please open an issue on GitLab or contact the maintainers.


Authors
===============================================================================

* **Alejandro Cora González** - *Initial work* - alek.cora.glez@gmail.com
