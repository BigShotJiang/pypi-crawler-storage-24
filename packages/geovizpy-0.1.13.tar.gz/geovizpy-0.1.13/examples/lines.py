"""Example script demonstrating how to draw lines on a map."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

lines_data = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "properties": {"destination": "New York", "type": "Long-haul"},
            "geometry": {
                "type": "LineString",
                "coordinates": [[2.35, 48.85], [-74.00, 40.71]]
            }
        },
        {
            "type": "Feature",
            "properties": {"destination": "Beijing", "type": "Long-haul"},
            "geometry": {
                "type": "LineString",
                "coordinates": [[2.35, 48.85], [116.40, 39.90]]
            }
        },
        {
            "type": "Feature",
            "properties": {"destination": "Cape Town", "type": "Long-haul"},
            "geometry": {
                "type": "LineString",
                "coordinates": [[2.35, 48.85], [18.42, -33.92]]
            }
        },
        {
            "type": "Feature",
            "properties": {"destination": "Moscow", "type": "Medium-haul"},
            "geometry": {
                "type": "LineString",
                "coordinates": [[2.35, 48.85], [37.61, 55.75]]
            }
        }
    ]
}

viz = Geoviz(projection="EqualEarth")
viz.outline()
viz.graticule(stroke="white", strokeWidth=0.4)

viz.path(datum=world_data, fill="#e0e0e0", stroke="white")

viz.typo(
    data=lines_data,
    var="destination",
    colors="Set1",
    strokeWidth=2,
    fill="none",
    leg_title="Routes from Paris",
    leg_pos=[10, 250]
)

viz.header(text="Map with Lines (Routes)", fontSize=20)
viz.render_html(os.path.join(output_dir, "lines.html"))
