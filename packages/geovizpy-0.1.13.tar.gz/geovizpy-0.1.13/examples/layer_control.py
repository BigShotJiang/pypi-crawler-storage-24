"""Example script for layer control and export functionality."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

# Load world data
data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

# Create a map
viz = Geoviz(projection="EqualEarth", zoomable=True)
viz.outline(id="outline")
viz.graticule(stroke="white", strokeWidth=0.4, id="graticule")

# Add a choropleth layer with an ID and legend position
viz.choro(
    data=world_data,
    var="gdppc",
    colors="Reds",
    id="choropleth_gdp",
    legend=True,
    leg_title="GDP per Capita",
    leg_pos=[10, 100]  # Position for the choro legend
)

# Add a proportional symbol layer with an ID and legend position
viz.prop(
    data=world_data,
    var="pop",
    fill="#4f8a8b",
    stroke="white",
    id="prop_population",
    legend=True,
    leg_title="Population",
    leg_pos=[10, 250]  # Position for the prop legend
)

# Add the layer control widget (hover to expand)
viz.add_layer_control(
    layers=["choropleth_gdp", "prop_population", "graticule"],
    title="Layers",
    x=10,
    y=10
)

# Add the export control widget (hover to expand)
viz.add_export_control(
    pos="top-right" # Or use x, y
)

# Add opacity control for multiple layers
viz.add_opacity_control(
    layers=["choropleth_gdp", "prop_population"],
    title="Layers Opacity",
    x=10,
    y=90
)

viz.header(text="Map with Layer & Export Controls", fontSize=20)
viz.render_html(os.path.join(output_dir, "layer_control_map.html"))
