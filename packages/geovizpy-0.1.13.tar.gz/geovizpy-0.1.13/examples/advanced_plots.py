"""Example script demonstrating advanced plot types."""

import json
import os
import random
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

continents = ["Africa", "Asia", "Europe", "North America", "South America", "Oceania"]
symbols_list = ["star", "circle", "cross", "diamond", "square", "triangle"]

for f in world_data.get("features", []):
    f["properties"]["random_continent"] = random.choice(continents)
    f["properties"]["random_symbol"] = random.choice(symbols_list)

# 1. Typology Map
viz1 = Geoviz(projection="EqualEarth", width=800)
viz1.outline()
viz1.graticule(stroke="white", strokeWidth=0.4)

viz1.typo(
    data=world_data,
    var="random_continent",
    colors="Pastel",
    strokeWidth=0.5,
    leg_title="Random Continent",
    leg_pos=[10, 200]
)
viz1.header(text="Typology Map (Random Data)", fontSize=20)
viz1.render_html(os.path.join(output_dir, "advanced_typo.html"))

# 2. Proportional Symbols with Typology
viz2 = Geoviz(projection="EqualEarth", width=800)
viz2.outline()
viz2.graticule()
viz2.path(datum=world_data, fill="#eee")

viz2.proptypo(
    data=world_data,
    var1="pop",
    var2="random_continent",
    k=50,
    colors="Set1",
    leg1_title="Population",
    leg2_title="Continent",
    leg1_pos=[10, 300],
    leg2_pos=[10, 150]
)
viz2.header(text="Proportional Symbols + Typology", fontSize=20)
viz2.render_html(os.path.join(output_dir, "advanced_proptypo.html"))

# 3. Symbol Map
viz3 = Geoviz(projection="EqualEarth", width=800)
viz3.outline()
viz3.graticule()
viz3.path(datum=world_data, fill="#ddd")

viz3.picto(
    data=world_data,
    var="random_symbol",
    symbols=["star", "circle", "cross", "diamond", "square", "triangle"],
    colors="black",
    fill="red",
    stroke="white",
    strokeWidth=1,
    k=15,
    leg_title="Random Symbols",
    leg_pos=[10, 200]
)
viz3.header(text="Symbol Map (Picto)", fontSize=20)
viz3.render_html(os.path.join(output_dir, "advanced_symbol.html"))
