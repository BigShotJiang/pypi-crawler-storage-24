"""Example script demonstrating how to use tile layers."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"Data file not found: {data_path}")
    world_data = {}

viz = Geoviz(projection="mercator", zoomable=True)

# Use the keyword for the tile layer, as per geoviz.js documentation
viz.tile(url="worldStreet")

viz.graticule(stroke="white", strokeWidth=0.4)

# This line might fail if world_data is empty
if world_data:
    viz.prop(
        data=world_data,
        var="pop",
        fill="#f07d75",
        tip="$NAMEen",
        leg_title="Population",
        leg_frame=True,
        leg_pos=[30, 30]
    )

viz.text(
    pos=[0,0],
    text="Source: INSEE 2022",
    fontSize=10,
    fill="#666",
    anchor="end"
)


viz.render_html(os.path.join(output_dir, "tiles.html"))
