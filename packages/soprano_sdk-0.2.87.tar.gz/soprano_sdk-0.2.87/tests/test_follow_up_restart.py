"""Tests for the restart flow — clearing all collected data and returning to the first
workflow step. Covers state key cleanup, conversation history clearing, and that state
history is removed to prevent stale rollback snapshots in a subsequent run.
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    follow_up_conv_key,
    fu_intent_change,
    fu_restart,
    llm_structured_response,
    make_tool,
    snap,
)


def _prompt_b(text="Please tell me field B."):
    return llm_structured_response({"bot_response": text, "field_b": None})


def _capture_b(val):
    return llm_structured_response({"bot_response": None, "field_b": val})


@respx.mock
def test_restart_clears_all_state_and_routes_to_first_step():
    """When the follow-up LLM signals a restart, all collected workflow state should be
    cleared and the graph should route back to the first collector for a fresh run.
    The follow-up tracking state (active flag, attempts, outcome_id) must all be removed.
    """
    responses = iter([
        collector_prompt("What is field A?"),                          # LLM#1: initial prompt
        collector_capture("valid_val"),                                # LLM#2: collector captures
        fu_restart("Let's start over."),                               # LLM#3: restart triggered
        collector_prompt("Please tell me field A again."),             # LLM#4: fresh prompt after restart
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="start over", initial_context={})
    s = snap(tool, tid)

    # Back at first step as USER_INPUT
    assert InterruptType.USER_INPUT in str(result3)
    assert s["field_a"] is None
    assert s.get("_follow_up_active") is None
    assert s.get("_outcome_id") is None
    assert s.get("_follow_up_attempts") is None
    assert respx.calls.call_count == 4


@respx.mock
def test_restart_clears_follow_up_conversation_history():
    """When restart fires, the follow-up conversation history should be cleared so that
    the new session does not receive contaminated LLM context from the previous session.
    After restart and re-completion, the follow-up conversation should contain only
    messages from the new session.
    """
    from tests.helpers import fu_answer

    responses = iter([
        collector_prompt(),                             # LLM#1: first session prompt
        collector_capture("first_val"),                 # LLM#2: first session capture
        fu_answer("First session answer."),             # LLM#3: Q&A in first session
        fu_restart("Let's start over."),                # LLM#4: restart triggered
        collector_prompt("Fresh start — field A?"),     # LLM#5: collector re-prompts after restart
        collector_capture("second_val"),                # LLM#6: second session capture
        fu_answer("Second session answer."),            # LLM#7: Q&A in second session
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                          # T1
    tool.execute(thread_id=tid, user_message="first_val", initial_context={})  # T2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="old question", initial_context={})  # T3 Q&A
    tool.execute(thread_id=tid, user_message="start over", initial_context={})   # T4 restart
    tool.execute(thread_id=tid, user_message="second_val", initial_context={})   # T5 FOLLOW_UP
    tool.execute(thread_id=tid, user_message="new question", initial_context={}) # T6 Q&A
    s = snap(tool, tid)

    follow_up_conv = s.get("_conversations", {}).get(follow_up_conv_key(tool), [])
    user_messages = [m for m in follow_up_conv if m["role"] == "user"]

    # Expected: only "new question" (the post-restart Q&A) should be in the conversation.
    assert len(user_messages) == 1, (
        f"Expected 1 user message after restart, "
        f"found {len(user_messages)}: {user_messages}"
    )
    assert user_messages[0]["content"] == "new question"


@respx.mock
def test_restart_clears_state_history_to_prevent_stale_rollback_snapshots():
    """When restart fires, the STATE_HISTORY should be cleared so that a subsequent
    intent_change in the new run uses the new run's snapshots rather than the old run's.
    Without clearing state history, a rollback would restore stale data from the previous
    run, corrupting the second run's state.
    """
    responses = iter([
        # ── Run 1 ──
        collector_prompt(),                                       # LLM#1  collect_a asks
        collector_capture("run1_a"),                              # LLM#2  collect_a captures
        _prompt_b(),                                              # LLM#3  collect_b asks
        _capture_b("run1_b"),                                     # LLM#4  collect_b captures → FOLLOW_UP
        fu_restart("Let's start over!"),                          # LLM#5  follow-up restart
        # ── Run 2 (collect_a re-entered after restart) ──
        collector_prompt("Welcome back. Please give field A."),   # LLM#6  collect_a prompt
        collector_capture("run2_a"),                              # LLM#7  collect_a captures
        _prompt_b("Now please give field B."),                    # LLM#8  collect_b asks
        _capture_b("run2_b"),                                     # LLM#9  collect_b captures → FOLLOW_UP
        fu_intent_change("collect_b", "Let me help you redo field B."),  # LLM#10
        _prompt_b("Please re-enter field B."),                    # LLM#11 collect_b re-prompt after rollback
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_two_step.yaml")
    tid = str(uuid.uuid4())

    # ── Run 1 ──
    tool.execute(thread_id=tid, initial_context={})                              # T1
    tool.execute(thread_id=tid, user_message="run1_a", initial_context={})      # T2
    tool.execute(thread_id=tid, user_message="run1_b", initial_context={})      # T3 → FOLLOW_UP
    result_restart = tool.execute(thread_id=tid, user_message="restart", initial_context={})  # T4

    assert InterruptType.USER_INPUT in str(result_restart), (
        "T4: restart should route back to collect_a (USER_INPUT)"
    )

    # ── Run 2 ──
    tool.execute(thread_id=tid, user_message="run2_a", initial_context={})      # T5
    tool.execute(thread_id=tid, user_message="run2_b", initial_context={})      # T6 → FOLLOW_UP
    result_ic = tool.execute(thread_id=tid, user_message="change B", initial_context={})  # T7

    # T7 should route back to collect_b (USER_INPUT)
    assert InterruptType.USER_INPUT in str(result_ic), (
        "T7: intent_change should route back to collect_b (USER_INPUT)"
    )

    # After rollback to collect_b the state should contain run-2's field_a value
    s = snap(tool, tid)
    field_a_val = str(s.get("field_a", ""))

    assert "run1_a" not in field_a_val, (
        f"After restart + intent_change('collect_b'), "
        f"field_a='{field_a_val}' contains run-1 data. "
        f"_handle_restart does NOT clear STATE_HISTORY — HistoryBasedRollback "
        f"found run-1's snapshot (first match) instead of run-2's snapshot. "
        f"Expected field_a to contain 'run2_a'."
    )
    assert "run2_a" in field_a_val, (
        f"Expected field_a to contain 'run2_a' after "
        f"rollback to run-2 snapshot, but got: '{field_a_val}'"
    )


@respx.mock
def test_restart_enables_fresh_follow_up_after_second_workflow_run():
    """After a restart, the second workflow run should produce a fresh follow-up session
    with a reset attempt counter. All state from the first run should be absent, and the
    second follow-up session should behave as if it is the first time the workflow ran.
    """
    responses = iter([
        collector_prompt(),                          # LLM#1 — initial collector
        collector_capture("valid_val"),              # LLM#2 — captures first value
        fu_restart("Starting fresh!"),               # LLM#3 — restart signal
        collector_prompt("Tell me field A again."),  # LLM#4 — collector re-prompt after restart
        collector_capture("new_val"),                # LLM#5 — captures second value
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                                      # T1 → LLM#1
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})            # T2 → LLM#2 → FOLLOW_UP
    result3 = tool.execute(thread_id=tid, user_message="start over", initial_context={})# T3 → LLM#3 → restart → LLM#4

    # Graph must be back at collector (USER_INPUT) after restart
    assert InterruptType.USER_INPUT in str(result3), (
        f"Expected USER_INPUT at T3 after restart (routed to first collector). "
        f"Got: '{str(result3)[:200]}'"
    )

    # All state must be cleared
    s3 = snap(tool, tid)
    assert s3.get("field_a") is None, (
        f"field_a must be None after restart. Got: {s3.get('field_a')!r}"
    )
    assert s3.get("_outcome_id") is None, (
        f"_outcome_id must be None after restart. Got: {s3.get('_outcome_id')!r}"
    )
    assert s3.get("_follow_up_active") is None, (
        f"_follow_up_active must be None after restart. Got: {s3.get('_follow_up_active')!r}"
    )
    assert s3.get("_follow_up_attempts") is None, (
        f"_follow_up_attempts must be None after restart. Got: {s3.get('_follow_up_attempts')!r}"
    )
    assert s3.get("_follow_up_pending_prompt") is None, (
        f"_follow_up_pending_prompt must be None after restart. Got: {s3.get('_follow_up_pending_prompt')!r}"
    )

    # Second workflow pass: user provides a new value
    result4 = tool.execute(thread_id=tid, user_message="new_val", initial_context={})   # T4 → LLM#5 → FOLLOW_UP

    assert InterruptType.FOLLOW_UP in str(result4), (
        f"Expected FOLLOW_UP on second pass after restart. Got: '{str(result4)[:200]}'"
    )
    assert "new_val" in str(result4), (
        f"Second-pass outcome message should contain 'new_val'. "
        f"Got: '{str(result4)[:200]}'"
    )

    # Second follow-up session must have fresh state
    s4 = snap(tool, tid)
    fa4 = s4.get("field_a")
    assert fa4 is not None and "new_val" in str(fa4), (
        f"field_a must contain 'new_val' after second pass. Got: {fa4!r}"
    )
    # Attempt counter must be None/0 (not carry-over from the first session)
    assert s4.get("_follow_up_attempts") is None or s4.get("_follow_up_attempts") == 0, (
        f"_follow_up_attempts should be None/0 at second-pass first entry (reset by restart). "
        f"Got: {s4.get('_follow_up_attempts')!r}"
    )


@respx.mock
def test_restart_in_two_step_flow_then_recollect_first_routes_to_second_collector():
    """After a restart in a two-step workflow, providing field_a should route to
    collect_b — NOT jump straight back to follow-up. This mirrors the intent_change
    scenario: restart wipes all state just like a rollback to the very first step, so
    the normal collect_a → collect_b step chain must be restored.

    Flow:
    T1  execute({})         → LLM#1 collect_a prompts                      → USER_INPUT
    T2  execute("val_a")    → LLM#2 collect_a captures; LLM#3 collect_b prompts → USER_INPUT
    T3  execute("val_b")    → LLM#4 collect_b captures; FOLLOW_UP entry         → FOLLOW_UP
    T4  execute("restart")  → LLM#5 restart; LLM#6 collect_a re-prompts         → USER_INPUT
    T5  execute("new_a")    → LLM#7 collect_a captures; LLM#8 collect_b prompts → USER_INPUT at collect_b
    """
    responses = iter([
        collector_prompt("What is field A?"),         # LLM#1: collect_a initial prompt
        collector_capture("val_a"),                   # LLM#2: collect_a captures
        _prompt_b("What is field B?"),                # LLM#3: collect_b initial prompt
        _capture_b("val_b"),                          # LLM#4: collect_b captures
        fu_restart("Let's start from scratch."),      # LLM#5: restart signal
        collector_prompt("Please re-enter field A."), # LLM#6: collect_a fresh prompt after restart
        collector_capture("new_val_a"),               # LLM#7: collect_a re-captures
        _prompt_b("Now please enter field B."),       # LLM#8: collect_b re-prompts
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                                   # T1
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})             # T2
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})             # T3 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="restart please", initial_context={})   # T4 → back at collect_a

    result5 = tool.execute(thread_id=tid, user_message="new_val_a", initial_context={})  # T5
    s5 = snap(tool, tid)

    # T5 must land at collect_b waiting for field_b — not back at follow-up
    assert InterruptType.USER_INPUT in str(result5), (
        f"Expected USER_INPUT at collect_b after restart + re-collecting field_a, "
        f"got: '{str(result5)[:300]}'"
    )
    assert InterruptType.FOLLOW_UP not in str(result5), (
        f"Workflow jumped straight back to follow-up without collecting field_b. "
        f"Got: '{str(result5)[:300]}'"
    )

    # field_a has the new value, field_b still empty (waiting to be re-collected)
    assert s5.get("field_b") is None, (
        f"field_b should not be set yet (collect_b hasn't run), got: {s5.get('field_b')!r}"
    )
    field_a_val = s5.get("field_a")
    assert field_a_val is not None and "new_val_a" in str(field_a_val), (
        f"field_a should have the new value after re-collection, got: {field_a_val!r}"
    )
    assert respx.calls.call_count == 8
