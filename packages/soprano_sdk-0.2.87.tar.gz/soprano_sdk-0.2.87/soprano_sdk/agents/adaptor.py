from abc import ABC, abstractmethod
from typing import Any, ClassVar, Dict, List, Optional
from langgraph.graph.state import CompiledStateGraph
from agno.agent import Agent as AgnoAgent
from pydantic import BaseModel
from pydantic_ai.agent import Agent as PydanticAIAgent
from crewai.agent import Agent as CrewAIAgent

from ..utils.parser import convert_to_dict
from ..utils.logger import logger
from ..utils.tracing import tracer
from ..guardrails import GuardrailViolationError, run_guardrails_parallel
from ..guardrails.base_guardrail import BaseGuardrail as Guardrail, DEFAULT_GUARDRAIL_ERROR_MESSAGE
from ..guardrails.functional_guardrail import ThoughtActionGuardrail
import json
import re
import traceback


def _strip_think_tags(text: str) -> str:
    """Remove think-tag artifacts from reasoning models (e.g. Qwen via LiteLLM).

    Handles two cases:
    1. Complete <think>...</think> blocks when the model outputs them inline.
    2. Orphaned </think> closing tag when LiteLLM separates the reasoning content
       into `reasoning_content` but leaves the closing tag in `content`.
    """
    # Remove complete blocks first
    text = re.sub(r'<think(?:ing)?>.*?</think(?:ing)?>', '', text, flags=re.DOTALL | re.IGNORECASE)
    # Strip everything up to and including any remaining </think> closing tag.
    # Handles the case where LiteLLM moves reasoning to reasoning_content but
    # leaves residual text + </think> in content (e.g. "...thinking</think>\nresult").
    text = re.sub(r'^.*?</think(?:ing)?>', '', text, flags=re.DOTALL | re.IGNORECASE)
    return text.strip()


class AgentAdapter(ABC):
    # Subclasses declare adapter-level defaults; configured guardrails override by class type.
    DEFAULT_GUARDRAILS: ClassVar[List[Guardrail]] = []

    def __init__(self):
        self.last_tool_outputs: List[str] = []
        self.guardrails: List[Guardrail] = []
        # Extra kwargs forwarded to each guardrail's check() call (e.g. grounding_source, query).
        # Set by the caller before invoking when context-dependent guardrails (e.g. grounding) are used.
        self.guardrail_context: Dict[str, str] = {}

    def _resolve_guardrails(self, configured_guardrails: Optional[List[Guardrail]]) -> None:
        """Build the final guardrail list by merging adapter defaults with configured guardrails.

        Configured guardrails take precedence: if an entry shares the same class as
        a default (e.g. ThoughtActionGuardrail with is_enabled=False), it replaces
        the default, effectively disabling it.
        """
        guardrail_map: Dict[type, Guardrail] = {type(guardrail): guardrail for guardrail in self.DEFAULT_GUARDRAILS}
        for guardrail in (configured_guardrails or []):
            guardrail_map[type(guardrail)] = guardrail
        self.guardrails = list(guardrail_map.values())

    @abstractmethod
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        pass

    @abstractmethod
    def _call_agent(self, messages: List[Dict[str, str]]) -> Any:
        """Raw agent invocation without guardrail processing."""
        pass

    def _run_guardrails(self, response: Any, messages: List[Dict[str, str]]) -> Any:
        """Run all guardrails with automatic regeneration retry on failure."""
        if not self.guardrails:
            return response

        attempt = 0
        while True:
            response_str = str(response)
            with tracer.start_as_current_span(
                "guardrails.check",
                attributes={"guardrails.count": len(self.guardrails), "guardrails.attempt": attempt},
            ) as span:
                if span and span.is_recording():
                    span.set_attribute("guardrails.input", response_str[:2000])

                results = run_guardrails_parallel(
                    response_str, self.guardrails, self.last_tool_outputs, **self.guardrail_context
                )

                failed_idx = next((i for i, r in enumerate(results) if not r.passed), None)

                if span and span.is_recording():
                    if failed_idx is None:
                        span.set_attribute("guardrails.passed", True)
                        span.set_attribute("guardrails.output", response_str[:2000])
                    else:
                        failed_guardrail_type = type(self.guardrails[failed_idx]).__name__
                        span.set_attribute("guardrails.passed", False)
                        span.set_attribute("guardrails.failed_type", failed_guardrail_type)
                        span.set_attribute("guardrails.output", results[failed_idx].error_message or "")

            if failed_idx is None:
                return response  # all passed

            failed_guardrail = self.guardrails[failed_idx]
            failed_result = results[failed_idx]
            guardrail_type = type(failed_guardrail).__name__

            max_retries = failed_guardrail.max_retries
            logger.warning(
                f"Guardrail '{guardrail_type}' failed on attempt {attempt + 1}"
            )

            if attempt < max_retries:
                logger.info(
                    f"Regenerating response (attempt {attempt + 1}/{max_retries})..."
                )
                messages.append({"role": "assistant", "content": response_str})
                messages.append({"role": "user", "content": failed_guardrail.regeneration_feedback})
                response = self._call_agent(messages)
                attempt += 1
            else:
                raise GuardrailViolationError(failed_result.error_message)


class LangGraphAgentAdapter(AgentAdapter):

    def __init__(self, agent: CompiledStateGraph, guardrails: Optional[List[Guardrail]] = None):
        super().__init__()
        self.agent = agent
        self._resolve_guardrails(guardrails)

    def _call_agent(self, messages: List[Dict[str, str]]) -> Any:
        response = self.agent.invoke({"messages": messages})

        # Capture tool outputs for grounding checks
        all_messages = response.get("messages", [])
        self.last_tool_outputs = [
            str(msg.content) for msg in all_messages
            if hasattr(msg, 'type') and msg.type == 'tool'
        ]

        if structured_response := response.get('structured_response'):
            return structured_response.model_dump()

        if not response or "messages" not in response:
            raise ValueError("Agent response missing 'messages'")

        response_messages = response.get("messages")
        if not response_messages:
            raise ValueError("Agent response 'messages' list is empty")

        return response_messages[-1].content

    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        logger.info("Invoking LangGraphAgentAdapter agent with messages")
        agent_response = self._call_agent(messages)
        return self._run_guardrails(agent_response, messages)


class CrewAIAgentAdapter(AgentAdapter):
    DEFAULT_GUARDRAILS: ClassVar[List[Guardrail]] = [
        ThoughtActionGuardrail(error_message=DEFAULT_GUARDRAIL_ERROR_MESSAGE)
    ]

    def __init__(
        self,
        agent: CrewAIAgent,
        output_schema: BaseModel,
        guardrails: Optional[List[Guardrail]] = None,
    ) -> None:
        super().__init__()
        self.agent = agent
        self.output_schema = output_schema
        self._resolve_guardrails(guardrails)

    def _llm_parse_fallback(self, response_str: str) -> Dict[str, Any] | None:
        """
        Use the agent's LLM to parse a malformed response into the expected schema.

        Args:
            response_str: The raw response string that failed to parse

        Returns:
            Parsed dictionary or None if parsing fails
        """
        with tracer.start_as_current_span(
            "llm.parse_fallback",
            attributes={
                "llm.purpose": "parse_malformed_response",
                "response.length": len(response_str),
                "schema.name": self.output_schema.__name__ if self.output_schema else "none"
            }
        ) as span:
            try:
                # Get schema fields and descriptions
                schema_fields = self.output_schema.model_json_schema().get("properties", {})

                # Build parsing prompt
                parsing_prompt = f"""You are a data extraction assistant. Extract structured data from the following response text.

Required output format (JSON):
{json.dumps(schema_fields, indent=2)}

Response text to parse:
{response_str}

Instructions:
1. Extract ONLY the fields specified in the output format
2. Return valid JSON matching the schema exactly
3. If a field is not found in the response, use appropriate default
4. Do not include any explanatory text, only return the JSON

Return the extracted JSON now:"""

                span.set_attribute("prompt.length", len(parsing_prompt))

                # Call the agent's LLM
                llm_response = self.agent.llm.call(messages=[{"role": "user", "content": parsing_prompt}])
                logger.info(f"LLM response: {llm_response}")
                # Extract content from LLM response
                if hasattr(llm_response, 'content'):
                    parsed_content = llm_response.content
                elif isinstance(llm_response, dict) and 'content' in llm_response:
                    parsed_content = llm_response['content']
                else:
                    parsed_content = str(llm_response)

                span.set_attribute("llm.response.length", len(parsed_content))

                # Try to parse the LLM's response
                # Remove markdown code blocks if present
                parsed_content = parsed_content.strip()
                if parsed_content.startswith('```'):
                    # Remove ```json or ``` at start and ``` at end
                    lines = parsed_content.split('\n')
                    parsed_content = '\n'.join(lines[1:-1])
                    span.set_attribute("llm.response.had_code_blocks", True)

                # Parse JSON
                parsed_dict = json.loads(parsed_content)
                span.set_attribute("parsing.json_parse", "success")

                # Validate against schema
                if self.output_schema:
                    validated = self.output_schema.model_validate(parsed_dict)
                    span.set_attribute("parsing.validation", "success")
                    span.set_attribute("result.fields", len(validated.model_dump()))
                    return validated.model_dump()

                return parsed_dict

            except Exception as e:
                span.set_attribute("error", True)
                span.set_attribute("error.type", type(e).__name__)
                span.set_attribute("error.message", str(e))
                span.add_event("exception", {
                    "exception.type": type(e).__name__,
                    "exception.message": str(e),
                    "exception.stacktrace": traceback.format_exc()
                })
                logger.error(f"LLM parse fallback error: {e}")
                logger.error(f"Traceback:\n{traceback.format_exc()}")
                return None

    def _call_agent(self, messages: List[Dict[str, str]]) -> Any:
        result = self.agent.kickoff(messages, response_format=self.output_schema)

        # Sync tool outputs from CrewAI's tools_results for grounding guardrails
        tools_results = getattr(self.agent, 'tools_results', None) or []
        self.last_tool_outputs = [
            f"[{tr.get('tool_name', 'tool')}] {tr.get('result', '')}"
            for tr in tools_results
            if isinstance(tr, dict)
        ]

        if structured_response := getattr(result, 'pydantic', None):
            logger.info("Got pydantic structured response")
            return structured_response.model_dump()

        agent_response = getattr(result, 'raw', None)
        if agent_response is None:
            agent_response = str(result)
        return _strip_think_tags(agent_response)

    def invoke(self, messages: List[Dict[str, str]]) -> Any:
        try:
            logger.info("Invoking CrewAIAgentAdapter agent with messages")
            agent_response = self._call_agent(messages)
            agent_response = self._run_guardrails(agent_response, messages)

            if not self.output_schema:
                logger.info("No output schema provided, returning raw response")
                return agent_response

            if isinstance(agent_response, dict):
                # Already structured (came from pydantic)
                return agent_response

            # Parse the response
            parsed_dict = convert_to_dict(agent_response)

            # Validate if we have a schema
            if self.output_schema:
                validated = self.output_schema.model_validate(parsed_dict)
                logger.info("Validation passed")
                return validated.model_dump()
            return parsed_dict

        except GuardrailViolationError:
            # Let GuardrailViolationError propagate — do not wrap it in RuntimeError
            raise
        except Exception as e:
            raise RuntimeError(f"CrewAI agent invocation failed: {e}")


class AgnoAgentAdapter(AgentAdapter):

    def __init__(self, agent: AgnoAgent, guardrails: Optional[List[Guardrail]] = None):
        super().__init__()
        self.agent = agent
        self._resolve_guardrails(guardrails)

    def _call_agent(self, messages: List[Dict[str, str]]) -> Any:
        response = self.agent.run(messages)
        return response.content if hasattr(response, 'content') else str(response)

    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        try:
            logger.info("Invoking AgnoAgentAdapter agent with messages")
            agent_response = self._call_agent(messages)
            return self._run_guardrails(agent_response, messages)
        except GuardrailViolationError:
            raise
        except Exception as e:
            raise RuntimeError(f"Agno agent invocation failed: {e}")


class PydanticAIAgentAdapter(AgentAdapter):

    def __init__(self, agent: PydanticAIAgent, guardrails: Optional[List[Guardrail]] = None):
        super().__init__()
        self.agent = agent
        self._resolve_guardrails(guardrails)

    def _call_agent(self, messages: List[Dict[str, str]]) -> Any:
        result = self.agent.run_sync(messages)
        return result.output if hasattr(result, 'output') else str(result)

    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        try:
            logger.info("Invoking PydanticAI agent with messages")
            agent_response = self._call_agent(messages)
            return self._run_guardrails(agent_response, messages)
        except GuardrailViolationError:
            raise
        except Exception as e:
            raise RuntimeError(f"Pydantic-AI agent invocation failed: {e}")
