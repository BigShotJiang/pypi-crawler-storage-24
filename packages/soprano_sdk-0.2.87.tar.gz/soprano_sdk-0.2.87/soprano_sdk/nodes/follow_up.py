"""
Follow-up node strategy.

Activated automatically after any workflow outcome (instead of terminating the graph).
Handles follow-up Q&A, intent changes, restarts, and out-of-scope detection using
structured LLM output.
"""
import json
from typing import Dict, Any, List, Optional

from langgraph.types import interrupt

from .base import ActionStrategy
from ..agents.factory import AgentFactory
from ..agents.structured_output import FollowUpOutput
from ..core.constants import WorkflowKeys, FOLLOW_UP_NODE
from ..core.state import initialize_state
from ..utils.logger import logger
from ..utils.tracing import trace_node_execution, trace_agent_invocation


class FollowUpStrategy(ActionStrategy):
    """
    Workflow-level follow-up node that activates after any outcome.

    Instead of terminating, the graph routes here. This node:
    - Delivers the outcome message to the user on first entry
    - Self-loops to handle follow-up Q&A via structured LLM output
    - Routes back to collector nodes on intent_change (with rollback)
    - Resets the entire graph on restart
    - Raises interrupt on out_of_scope (graph paused, not ended)
    - Ends the graph when max_attempts is exhausted
    """

    # Fallback message when agent.invoke() itself raises (network error, timeout, etc.).
    # Uses the global failure_message if configured, otherwise falls back to this default.
    _DEFAULT_LLM_INVOCATION_ERROR_FALLBACK = "I'm sorry, I'm having trouble right now. Please try again."

    def __init__(self, follow_up_config: Dict[str, Any], engine_context: Any, first_step_id: str, node_id: str = FOLLOW_UP_NODE):

        fake_step_config = {'id': node_id, 'action': 'follow_up'}
        super().__init__(fake_step_config, engine_context)

        self.config = follow_up_config
        self.name = follow_up_config.get('name', 'follow_up')
        self.first_step_id = first_step_id
        self.max_attempts = follow_up_config.get('max_attempts')  # None = infinite
        self.max_history_turns = follow_up_config.get('max_history_turns')  # None = unlimited
        self.on_max_attempts_reached = follow_up_config.get(
            'on_max_attempts_reached', "Our conversation has ended. Thank you."
        )
        self.on_unknown = follow_up_config.get(
            'on_unknown',
            "I don't have enough information to answer that question based on the available context."
        )
        self._LLM_INVOCATION_ERROR_FALLBACK = (
            getattr(engine_context, 'failure_message', None)
            or self._DEFAULT_LLM_INVOCATION_ERROR_FALLBACK
        )

        from .collect_input import _create_rollback_strategy
        rollback_strategy_name = engine_context.get_config_value("rollback_strategy", "history_based")
        self.rollback_strategy = _create_rollback_strategy(rollback_strategy_name)

    @property
    def _conversation_key(self) -> str:
        return f'{self.step_id}_conversation'

    def pre_execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass


    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        with trace_node_execution(
            node_id=self.name,
            node_type="follow_up",
        ) as span:
            state = initialize_state(state)
            conversation = self._get_or_create_conversation(state)

            if pending_prompt := state.get(WorkflowKeys.FOLLOW_UP_PENDING_PROMPT):
                state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = None
                # Fire interrupt to deliver the pending message (outcome or OOS) to the user.
                # On resumption, interrupt() returns the user's response instead of raising.
                # The node then completes normally so all state mutations are checkpointed.
                user_input = interrupt(pending_prompt)
                if pending_prompt.get("type") == "follow_up":
                    # Add outcome message to conversation history on resumption.
                    conversation.append(self._build_conversation_entry(
                        role="assistant",
                        content=pending_prompt["text"],
                        options=pending_prompt.get("options"),
                        is_selectable=pending_prompt.get("is_selectable"),
                    ))
                    self._update_conversation(state, conversation)

            else:
                prompt = self._get_last_interrupt_payload(conversation)
                user_input = interrupt(prompt)
            span.add_event("user.input_received", {"input_length": len(str(user_input))})

            attempts = (state.get(WorkflowKeys.FOLLOW_UP_ATTEMPTS) or 0) + 1
            state[WorkflowKeys.FOLLOW_UP_ATTEMPTS] = attempts

            if self.max_attempts is not None and attempts > self.max_attempts:
                logger.info(f"Follow-up max_attempts ({self.max_attempts}) exhausted")
                span.add_event("follow_up.max_attempts_exhausted", {"attempts": attempts})
                return self._terminate_conversation(state)

            conversation.append({"role": "user", "content": str(user_input)})
            output = self._invoke_llm(state, conversation)

            has_dispatch_signal = bool(output.intent_change or output.out_of_scope or output.restart)
            if not has_dispatch_signal and not (output.bot_response or "").strip():
                logger.warning("Follow-up: empty bot_response in structured output — substituting error fallback.")
                output = output.model_copy(update={"bot_response": self._LLM_INVOCATION_ERROR_FALLBACK})

            if output.intent_change:
                if output.restart:
                    logger.warning("Follow-up: LLM set both restart and intent_change — preferring intent_change")
                if output.out_of_scope:
                    logger.warning("Follow-up: LLM set both intent_change and out_of_scope — preferring intent_change")
                span.add_event("intent_change.detected", {"target": str(output.intent_change)})
                return self._handle_intent_change(output.intent_change, state)

            if output.out_of_scope:
                if output.restart:
                    logger.warning("Follow-up: LLM set both restart and out_of_scope — preferring out_of_scope")
                span.add_event("out_of_scope.detected", {"reason": str(output.out_of_scope)})
                return self._handle_out_of_scope(output, state, conversation, attempts, user_input)

            if output.restart:
                span.add_event("follow_up.restart")
                return self._handle_restart(state)

            conversation.append(self._build_conversation_entry(
                role="assistant",
                content=output.bot_response or "",
                options=output.options,
                is_selectable=output.is_selectable,
            ))
            self._update_conversation(state, conversation)

            self._set_status(state, 'answering')
            return state


    def _invoke_llm(self, state: Dict[str, Any], conversation: List[Dict]) -> FollowUpOutput:
        """Call the follow-up agent and return a parsed FollowUpOutput.

        Falls back to a safe error response on invocation failure, or wraps the raw
        string as bot_response if parsing fails.
        """
        agent = self._create_agent(state)
        raw_response = None
        try:
            with trace_agent_invocation(
                agent_name=self.name,
                model=self.config.get('model', 'default'),
            ):
                raw_response = agent.invoke(self._to_llm_messages(conversation))
            if isinstance(raw_response, dict):
                return FollowUpOutput(**raw_response)
            return FollowUpOutput(**json.loads(str(raw_response)))
        except Exception as e:
            if raw_response is None:
                logger.warning(f"Follow-up LLM invocation failed: {e}. Using error fallback.")
                return FollowUpOutput(bot_response=self._LLM_INVOCATION_ERROR_FALLBACK)
            logger.warning(f"Follow-up structured output parse failed: {e}. Using raw response.")
            return FollowUpOutput(bot_response=str(raw_response))


    def _handle_out_of_scope(
        self,
        output: FollowUpOutput,
        state: Dict[str, Any],
        conversation: List[Dict],
        attempts: int,
        user_input: Any,
    ) -> Dict[str, Any]:
        """Handle an out-of-scope LLM response.

        Stores the OOS bot_response in conversation context, tracks consecutive OOS
        count (with a hard cap), and queues the OOS interrupt payload via
        PENDING_PROMPT so LangGraph fires one interrupt per execution cycle.
        """
        if (output.bot_response or "").strip():
            conversation.append(self._build_conversation_entry(
                role="assistant",
                content=output.bot_response,
                options=output.options,
                is_selectable=output.is_selectable,
            ))
            self._update_conversation(state, conversation)

        logger.info(f"Follow-up out_of_scope: {output.out_of_scope}")
        if self.max_attempts is not None and attempts > self.max_attempts:
            logger.info(f"Follow-up max_attempts ({self.max_attempts}) exhausted on OOS turn")
            return self._terminate_conversation(state)

        state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = self._build_oos_payload(output, user_input)
        self._set_status(state, 'answering')
        return state

    def _handle_restart(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Clear all collected data and restart the graph from step 1."""
        logger.info("Follow-up: restart triggered — clearing all state")
        self.engine_context.reset_workflow_state(state)
        self._set_status(state, 'restart')
        return state

    def _handle_intent_change(self, target_node: str, state: Dict[str, Any]) -> Dict[str, Any]:
        """Rollback state to the target collector node and resume the graph there."""
        logger.info(f"Follow-up: intent change -> '{target_node}'")
        rollback_state = self._rollback_state_to_node(state, target_node)

        if not rollback_state:
            logger.warning(f"Rollback failed for unknown node '{target_node}' — falling back to self-loop")
            self._set_status(state, 'answering')
            return state

        rollback_state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = None
        rollback_state[WorkflowKeys.FOLLOW_UP_ACTIVE] = None
        rollback_state[WorkflowKeys.FOLLOW_UP_ATTEMPTS] = None
        # Clear the follow-up conversation so it starts fresh after re-collection.
        # _clear_future_executions doesn't reach this key because the follow-up node
        # is programmatic (not in engine_context.steps).
        conversations = rollback_state.get(WorkflowKeys.CONVERSATIONS, {})
        conversations.pop(self._conversation_key, None)
        return rollback_state


    def _terminate_conversation(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """End the follow-up conversation after max_attempts is exhausted.

        Sets the terminal message to on_max_attempts_reached and clears all
        follow-up tracking fields so the graph reaches END cleanly.  The
        message is surfaced to the caller by tools.py / streamer.py after
        the graph completes, not via interrupt.
        """
        state[WorkflowKeys.MESSAGES] = [self.on_max_attempts_reached]
        state[WorkflowKeys.OUTCOME_ID] = None
        state[WorkflowKeys.FOLLOW_UP_ACTIVE] = None
        state[WorkflowKeys.FOLLOW_UP_ATTEMPTS] = None
        state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = None
        self._set_status(state, 'done')
        return state


    def _create_agent(self, state: Dict[str, Any]):
        model_config = self.engine_context.get_model_config(self.config)

        instructions = self._build_instructions(state)

        localization = self.engine_context.get_localization_instructions(state)
        if localization:
            instructions = f"{localization}\n\n{instructions}"

        tools = self._load_tools(state)
        framework = self.engine_context.get_config_value('agent_framework', 'langgraph')

        return AgentFactory.create_agent(
            framework=framework,
            name='FollowUp',
            model_config=model_config,
            tools=tools,
            system_prompt=instructions,
            structured_output_model=FollowUpOutput,
        )

    def _build_instructions(self, state: Dict[str, Any]) -> str:
        """Compose the full system prompt for the follow-up LLM."""
        parts = [self._build_purpose_block()]

        custom_instructions = self.config.get('instructions', '').strip()
        if custom_instructions:
            parts.append(f"ROLE & PERSONA:\n{custom_instructions}")

        parts.append(self._build_constraints_block())
        parts.append(self._build_context_summary(state))
        parts.append(self._build_conversation_history(state))

        intent_guidance = self._build_intent_change_guidance(state)
        if intent_guidance:
            parts.append(intent_guidance)

        parts.append(self._build_response_format())
        return "\n\n".join(parts)

    def _build_purpose_block(self) -> str:
        """Return the fixed purpose statement that frames every follow-up interaction."""
        return (
            "You are a post-workflow follow-up assistant.\n"
            "Your sole purpose is to answer the user's INFORMATIONAL questions about the "
            "workflow that just completed — explaining outcomes, clarifying collected data, "
            "and providing factual context.\n"
            "You do NOT perform actions, submit forms, or trigger new processes directly. "
            "Use the appropriate dispatch signal instead:\n"
            "  • intent_change — user wants to modify a specific piece of previously collected data.\n"
            "                    This includes BOTH explicit requests ('change my seat', 'update the date')\n"
            "                    AND implicit requests where the user provides a corrected or alternative\n"
            "                    value for something already collected (e.g. 'actually make it for 3 people',\n"
            "                    'I meant the 7pm show'). Set intent_change to the node that collected\n"
            "                    the data they want to change.\n"
            "  • restart       — user wants to run the workflow again from the beginning.\n"
            "                    This includes BOTH explicit requests ('start over', 'restart', 'try again')\n"
            "                    AND implicit requests where the user asks to perform the workflow's\n"
            "                    primary action again (e.g. 'can you book me a ticket').\n"
            "                    If the user's message is essentially asking to do\n"
            "                    the same thing the workflow does, set restart=true.\n"
            "  • out_of_scope  — user's request falls outside this workflow entirely"
        )

    def _build_constraints_block(self) -> str:
        """Return the anti-hallucination and grounding constraints."""
        return (
            "CONSTRAINTS (strictly enforced):\n"
            "  1. Answer ONLY from the WORKFLOW CONTEXT and CONVERSATION HISTORY provided below.\n"
            "     Do not invent, assume, or infer facts that are not explicitly present.\n"
            f'  2. If the answer is not present in the provided context, respond with the following in bot_response in your Final Answer:\n'
            f'     "{self.on_unknown}"\n'
            "     Do NOT guess, fabricate, or extrapolate beyond what is explicitly stated.\n"
            "  3. Never take an action on behalf of the user in a bot_response.\n"
            "     If an action is needed, set the appropriate dispatch signal (intent_change / "
            "restart / out_of_scope) instead of describing the action in text."
        )

    def _build_context_summary(self, state: Dict[str, Any]) -> str:
        """Return a WORKFLOW CONTEXT block listing the user's original query and all collected field values."""
        lines = ["WORKFLOW CONTEXT:"]

        if user_query := state.get(WorkflowKeys.USER_MESSAGE, ""):
            lines.append(f"  User query: {user_query}")

        for field in self.engine_context.data_fields:
            name = field['name']
            val = state.get(name)
            if val is not None:
                # If val is a structured-output artifact (a dict containing 'bot_response'),
                # the collector stored the full response dict instead of just the field value.
                # Extract the actual field value by key to avoid leaking schema internals.
                if isinstance(val, dict) and 'bot_response' in val:
                    val = val.get(name)
                if val is not None:
                    lines.append(f"  - {name}: {val}")
        if len(lines) == 1:
            lines.append("  (No data collected yet)")
        return "\n".join(lines)

    def _build_conversation_history(self, state: Dict[str, Any]) -> str:
        """Return a CONVERSATION HISTORY block from all prior collector node conversations.

        Collector nodes in structured output mode store raw JSON as message content.
        This method extracts only the user-facing text so the follow-up LLM receives
        clean natural-language history rather than JSON artefacts.
        """
        aggregated = self.engine_context._aggregate_conversation_history(state)
        if not aggregated:
            return "CONVERSATION HISTORY: (none)"

        lines = ["CONVERSATION HISTORY:"]
        for msg in aggregated:
            if msg['role'] == 'assistant':
                content = msg['content']
                try:
                    parsed = json.loads(content)
                    if isinstance(parsed, dict):
                        clean = str(parsed.get('text') or parsed.get('bot_response') or '').strip()
                        if clean:
                            lines.append(f"  ASSISTANT: {clean}")
                        # else: capture-only turn — no user-facing text, skip silently
                        continue
                except (json.JSONDecodeError, ValueError):
                    pass
                # Plain text from pattern-matching mode collectors — use as-is
                if content.strip():
                    lines.append(f"  ASSISTANT: {content.strip()}")
            else:
                lines.append(f"  {msg['role'].upper()}: {msg['content']}")
        return "\n".join(lines)

    def _build_intent_change_guidance(self, state: Dict[str, Any]) -> str:
        """Return an INTENT CHANGE block listing available collector nodes, or '' if none."""
        collector_nodes = state.get(WorkflowKeys.COLLECTOR_NODES, {})
        if not collector_nodes:
            return ""
        nodes_str = "\n".join(
            f"  - {node_id}: {description}"
            for node_id, description in collector_nodes.items()
        )
        return (
            "INTENT CHANGE:\n"
            "Set intent_change to the target node ID when the user wants to update a specific "
            "collected value — whether they say so explicitly ('change my seat') or implicitly "
            "('actually make it for 3 people', 'I meant the 7pm show').\n"
            "Pick the node whose collected field most closely matches what the user wants to change.\n"
            f"Available nodes:\n{nodes_str}"
        )

    def _build_response_format(self) -> str:
        """Return the RESPONSE FORMAT instruction block for the follow-up LLM."""
        return (
            "Final Answer format — your Final Answer must be a valid JSON object with these fields:\n"
            "  - bot_response (str or null, optional): Your message to the user; may be null or omitted when a dispatch signal (intent_change, out_of_scope, restart) carries the intent\n"
            "  - options (list[{text: str, subtext: str | null}] or null): Selectable options if applicable; subtext may be null when there is no secondary detail\n"
            "  - is_selectable (bool or null): True if user must pick from options\n"
            "  - intent_change (str or null): Node ID if user wants to update collected data\n"
            "  - out_of_scope (str or null): Reason if the request is outside this workflow\n"
            "  - restart (bool or null, optional): True if user wants to start over; null or false means no restart\n"
            "Set at most ONE of: intent_change, out_of_scope, restart=true."
        )

    def _load_tools(self, state: Dict[str, Any]) -> List:
        from ..utils.builtin_tools import make_compute_tool, MONTY_TOOL_NAME, MONTY_TOOL_DESCRIPTION

        tool_repo = self.engine_context.tool_repository
        configured_tools = self.config.get('tools')

        if configured_tools and tool_repo:
            tools = [tool_repo.load(name, state) for name in configured_tools]
        else:
            tools = []

        if self.config.get('default_tools', True):
            tools.append((MONTY_TOOL_NAME, MONTY_TOOL_DESCRIPTION, make_compute_tool(state)))

        return tools


    def _to_llm_messages(self, conversation: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """Convert stored conversation entries to plain ``{role, content}`` dicts.

        Entries written by ``_build_conversation_entry`` may have their content
        JSON-serialised (``{"text": ..., "options": ..., "is_selectable": ...}``)
        to preserve UI metadata.  The LLM only needs plain text, so we unwrap
        the ``text`` field here.

        Applies two guards against JSON format drift in long conversations:
        - Truncation: keeps the first message (outcome) + the last
          ``max_history_turns * 2`` messages when ``max_history_turns`` is set.
        - Format reminder: appends a brief JSON schema reminder to the last user
          message so the model stays anchored to the required output format.
        """
        result = []
        for m in conversation:
            content = m["content"]
            try:
                parsed = json.loads(content)
                if isinstance(parsed, dict) and "text" in parsed:
                    content = parsed["text"]
            except (json.JSONDecodeError, TypeError):
                pass
            result.append({"role": m["role"], "content": str(content)})

        # Truncate: keep first message (outcome context) + last N turns
        if self.max_history_turns is not None and len(result) > self.max_history_turns * 2 + 1:
            result = result[:1] + result[-(self.max_history_turns * 2):]

        # Append JSON schema reminder to last user message to counteract format drift
        # in long conversations (model tends to forget structured output requirements).
        _schema_reminder = (
            "\n\nIMPORTANT: Your Final Answer MUST be a valid JSON object with exactly these fields:\n"
            "{\n"
            '  "bot_response": string | null,\n'
            '  "options": [{\"text\": string, \"subtext\": string | null}] | null,\n'
            '  "is_selectable": boolean | null,\n'
            '  "intent_change": string | null,\n'
            '  "out_of_scope": string | null,\n'
            '  "restart": boolean | null\n'
            "}\n"
            "Set at most ONE of: intent_change, out_of_scope, restart=true. "
        )
        for i in range(len(result) - 1, -1, -1):
            if result[i]["role"] == "user":
                result[i] = {
                    "role": "user",
                    "content": result[i]["content"] + _schema_reminder,
                }
                break

        return result

    def _get_or_create_conversation(self, state: Dict[str, Any]) -> List[Dict[str, str]]:
        conversations = state.get(WorkflowKeys.CONVERSATIONS, {})
        if self._conversation_key not in conversations:
            conversations[self._conversation_key] = []
            state[WorkflowKeys.CONVERSATIONS] = conversations
        return conversations[self._conversation_key]

    def _update_conversation(self, state: Dict[str, Any], conversation: List[Dict[str, str]]) -> None:
        state[WorkflowKeys.CONVERSATIONS][self._conversation_key] = conversation

    def _get_last_interrupt_payload(self, conversation: List[Dict[str, str]]) -> Any:
        """Return the last assistant response as an interrupt payload dict.

        Content may be a plain string or a JSON blob (``{"text", "options",
        "is_selectable"}``) written by ``_build_conversation_entry``.
        """
        last_msg = next(
            (msg for msg in reversed(conversation) if msg['role'] == 'assistant'),
            None,
        )
        if last_msg is None:
            return self._make_interrupt_payload("")
        content = last_msg['content']
        try:
            parsed = json.loads(content)
            if isinstance(parsed, dict) and "text" in parsed:
                return self._make_interrupt_payload(
                    parsed["text"],
                    options=parsed.get("options"),
                    is_selectable=parsed.get("is_selectable"),
                )
        except (json.JSONDecodeError, TypeError):
            pass
        return self._make_interrupt_payload(content)

    def _make_interrupt_payload(self,
        message: str,
        options: Optional[List] = None,
        is_selectable: Optional[bool] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"type": "follow_up", "text": message}
        if options is not None:
            payload["options"] = options
        if is_selectable is not None:
            payload["is_selectable"] = is_selectable
        return payload

    def _build_conversation_entry(self,
        role: str,
        content: str,
        options: Optional[List] = None,
        is_selectable: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Build a conversation message dict.

        When options/is_selectable are present, they are serialised into the
        content field as a JSON blob (``{"text": ..., "options": ...,
        "is_selectable": ...}``) so the entry stays ``{role, content}``-only —
        compatible with all agent frameworks (e.g. crewai validates messages
        as ``list[dict[str, str]]``).  ``_get_last_interrupt_payload`` parses
        this blob back out when rebuilding the interrupt payload.
        """
        if options is not None or is_selectable is not None:
            serialised = json.dumps({
                "text": content,
                "options": options,
                "is_selectable": is_selectable,
            })
            return {"role": role, "content": serialised}
        return {"role": role, "content": content}

    def _build_oos_payload(self, output: FollowUpOutput, user_input: Any) -> Dict[str, Any]:
        """Build the OOS pending prompt dict from the LLM's out-of-scope output."""
        payload: Dict[str, Any] = {
            "type": "follow_up_out_of_scope",
            "step_id": self.step_id,
            "reason": output.out_of_scope,
            "bot_response": output.bot_response or "",
            "user_message": str(user_input),
        }
        if output.options is not None:
            payload["options"] = output.options
        if output.is_selectable is not None:
            payload["is_selectable"] = output.is_selectable
        return payload
