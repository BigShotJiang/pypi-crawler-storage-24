"""
Halyn Integration Tests — end-to-end AAP pipeline.
"""
import sys
sys.path.insert(0, "/mnt/data/aap/sdk/python")
sys.path.insert(0, "/mnt/data/nrp-new")
sys.path.insert(0, "..")

import pytest
from aap import AAPKeyPair, AAPIdentity, AAPAuthorization, AuthorizationLevel, AAPPhysicalWorldViolation
from nrp import NRPDriver, NRPNode, NRPManifest, NRPAddress, ActionSpec, ObserveResult, ActionResult, ShieldRule, ShieldOperator
from halyn import HalynControlPlane, ExecutionContext
from datetime import datetime, timezone


# ─── Test nodes ──────────────────────────────────────────────────────────────

class FileWorkerDriver(NRPDriver):
    def manifest(self):
        return NRPManifest(
            address=NRPAddress.parse("nrp://acme/server/files-1"),
            description="File worker",
            version="1.0.0",
            actions=[ActionSpec("write:file", "Write a file", {"path": "str", "content": "str"})],
        )
    def observe(self):
        return ObserveResult("nrp://acme/server/files-1", {"status": "ok"},
                             datetime.now(timezone.utc).isoformat())
    def act(self, action, params):
        return ActionResult("nrp://acme/server/files-1", action, params,
                            success=True, output={"written": params.get("path")})
    def shield_rules(self): return []


class RobotDriver(NRPDriver):
    def manifest(self):
        return NRPManifest(
            address=NRPAddress.parse("nrp://factory/robot/arm-1"),
            description="Robot arm",
            version="1.0.0",
            actions=[ActionSpec("move", "Move arm", {"force_n": "float"})],
        )
    def observe(self):
        return ObserveResult("nrp://factory/robot/arm-1", {"pos": 0},
                             datetime.now(timezone.utc).isoformat())
    def act(self, action, params):
        return ActionResult("nrp://factory/robot/arm-1", action, params, success=True)
    def shield_rules(self):
        return [ShieldRule("force_n", ShieldOperator.MAX, max_value=50.0, unit="N")]


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def supervisor():
    return AAPKeyPair.generate()

@pytest.fixture
def agent():
    return AAPKeyPair.generate()

@pytest.fixture
def cp(supervisor):
    plane = HalynControlPlane(
        supervisor_keypair=supervisor,
        supervisor_did="did:key:z6MkSupervisor",
    )
    plane.register_node(NRPNode(FileWorkerDriver()))
    plane.register_node(NRPNode(RobotDriver()))
    return plane

@pytest.fixture
def ctx(supervisor, agent, cp):
    identity = AAPIdentity.create(
        id="aap://acme/worker/bot@1.0.0",
        scope=["write:file", "read:*", "move:*"],
        agent_keypair=agent,
        parent_keypair=supervisor,
        parent_did="did:key:z6MkSupervisor",
    )
    cp.register_identity(identity)
    auth = cp.grant_authorization(
        agent_id=identity.id,
        level=AuthorizationLevel.SUPERVISED,
        scope=["write:file", "move:*"],
        physical=False,
    )
    return ExecutionContext(identity=identity, authorization=auth, agent_keypair=agent)


# ─── Tests ────────────────────────────────────────────────────────────────────

class TestHalynPipeline:

    def test_successful_execution(self, cp, ctx):
        result = cp.execute(ctx, "nrp://acme/server/files-1", "write:file",
                            {"path": "/app/config.json", "content": "{}"})
        assert result.success is True
        assert result.provenance_id is not None
        assert result.audit_entry_id is not None

    def test_audit_chain_grows(self, cp, ctx):
        for i in range(3):
            cp.execute(ctx, "nrp://acme/server/files-1", "write:file",
                       {"path": f"/file{i}", "content": "x"})
        entries = cp.audit_entries()
        assert len(entries) == 3

    def test_audit_chain_is_valid(self, cp, ctx):
        cp.execute(ctx, "nrp://acme/server/files-1", "write:file", {"path": "/f", "content": "x"})
        valid, count, broken = cp.verify_audit()
        assert valid is True
        assert broken is None

    def test_shield_violation_recorded_in_audit(self, supervisor, agent, cp):
        identity = AAPIdentity.create(
            id="aap://factory/worker/robot-op@1.0.0",
            scope=["move:*"],
            agent_keypair=agent,
            parent_keypair=supervisor,
            parent_did="did:key:z6MkSupervisor",
        )
        auth = cp.grant_authorization(
            agent_id=identity.id,
            level=AuthorizationLevel.SUPERVISED,
            scope=["move:*"],
            physical=True,
        )
        ctx2 = ExecutionContext(identity=identity, authorization=auth, agent_keypair=agent)
        result = cp.execute(ctx2, "nrp://factory/robot/arm-1", "move", {"force_n": 200.0})
        assert result.success is False
        assert result.blocked is True
        assert result.audit_entry_id is not None  # BLOCKED still audited
        entries = cp.audit_entries()
        assert any(e["result"] == "blocked" for e in entries)

    def test_physical_world_rule_at_grant(self, cp):
        with pytest.raises(AAPPhysicalWorldViolation):
            cp.grant_authorization(
                agent_id="aap://factory/robot/arm@1.0.0",
                level=AuthorizationLevel.AUTONOMOUS,
                scope=["move:*"],
                physical=True,
            )

    def test_revoked_identity_blocked(self, cp, ctx):
        ctx.identity.revoked = True
        result = cp.execute(ctx, "nrp://acme/server/files-1", "write:file", {})
        assert result.blocked is True

    def test_out_of_scope_action_blocked(self, cp, ctx):
        result = cp.execute(ctx, "nrp://acme/server/files-1", "delete:file", {})
        assert result.blocked is True
        assert "scope" in (result.block_reason or "").lower()

    def test_unregistered_node_blocked(self, cp, ctx):
        result = cp.execute(ctx, "nrp://ghost/server/x", "write:file", {})
        assert result.blocked is True

    def test_empty_audit_chain_valid(self, cp):
        valid, count, broken = cp.verify_audit()
        assert valid is True
        assert count == 0
