<div align="center">

# Halyn

**AAP in action. AI agents that can prove what they did.**

[![PyPI](https://img.shields.io/pypi/v/halyn?color=0a6e3f)](https://pypi.org/project/halyn/)
[![License: MIT](https://img.shields.io/badge/License-MIT-0a6e3f.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-9%20passed-0a6e3f.svg)](tests/)

The reference implementation of [AAP — Agent Accountability Protocol](https://aap-protocol.dev)

[Website](https://halyn.dev) · [AAP Spec](https://aap-protocol.dev) · [NRP](https://nrprotocol.dev)

</div>

---

## What is Halyn?

Halyn is the complete demonstration of [AAP](https://aap-protocol.dev).

Every agent action goes through 7 steps — none skippable:

```
Identity → Authorization → Scope → Shield → Execute → Provenance → Audit
```

```python
from halyn import HalynControlPlane, ExecutionContext
from aap import AAPKeyPair, AAPIdentity, AAPAuthorization, AuthorizationLevel

# Setup
supervisor = AAPKeyPair.generate()
cp = HalynControlPlane(supervisor_keypair=supervisor, supervisor_did="did:key:z6Mk...")

# Register agent + node
cp.register_identity(identity)
cp.register_node(node)
auth = cp.grant_authorization(agent_id=..., level=AuthorizationLevel.SUPERVISED, scope=["write:file"])

# Execute — full AAP pipeline, fully audited
ctx = ExecutionContext(identity=identity, authorization=auth, agent_keypair=agent_kp)
result = cp.execute(ctx, node_id="nrp://acme/server/files-1", action="write:file", params={...})

# Verify audit chain integrity
valid, count, broken = cp.verify_audit()
```

## AAP Ecosystem

| Layer | Project | Role |
|-------|---------|------|
| Spec | [AAP](https://aap-protocol.dev) | Protocol definition |
| Physical | [NRP](https://nrprotocol.dev) | AAP for robots, IoT, machines |
| Full system | **Halyn** (this) | Complete demonstration |

## License

MIT
