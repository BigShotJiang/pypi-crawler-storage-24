"""
Halyn ControlPlane — the full AAP implementation.
Orchestrates: Identity → Authorization → Execution → Provenance → Audit
"""
from __future__ import annotations
import sys
sys.path.insert(0, "/mnt/data/aap/sdk/python")
sys.path.insert(0, "/mnt/data/nrp-new")

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aap import (
    AAPIdentity, AAPKeyPair, AAPAuthorization, AuthorizationLevel,
    AAPProvenance, AAPAuditChain,
    AAPPhysicalWorldViolation, AAPScopeError, AAPRevocationError,
)
from nrp import NRPNode, ShieldViolation


@dataclass
class ExecutionContext:
    """Full context for a single agent action — identity + authorization."""
    identity: AAPIdentity
    authorization: AAPAuthorization
    agent_keypair: AAPKeyPair

    def check(self) -> None:
        """Validate context before any action."""
        if self.identity.revoked:
            raise AAPRevocationError(f"Identity {self.identity.id} is revoked")
        self.authorization.check()

    @property
    def agent_id(self) -> str:
        return self.identity.id

    @property
    def auth_level(self) -> AuthorizationLevel:
        return self.authorization.level


@dataclass
class ExecutionResult:
    """Result of a Halyn-mediated action."""
    success: bool
    agent_id: str
    action: str
    node_id: str | None
    output: Any
    provenance_id: str | None
    audit_entry_id: str | None
    blocked: bool = False
    block_reason: str | None = None
    detail: str | None = None


class HalynControlPlane:
    """
    AAP reference implementation — full system.

    Flow for every action:
    1. IDENTITY   — verify agent exists and is not revoked
    2. AUTHORIZATION — verify agent has permission at correct level
    3. SCOPE      — verify action is within authorized scope
    4. SHIELD     — verify NRP shield rules (physical nodes only)
    5. EXECUTE    — run the action
    6. PROVENANCE — record what was produced
    7. AUDIT      — append to tamper-evident chain
    """

    def __init__(
        self,
        supervisor_keypair: AAPKeyPair,
        supervisor_did: str,
        audit_path: str | None = None,
    ) -> None:
        self._supervisor_keypair = supervisor_keypair
        self._supervisor_did = supervisor_did
        self._identities: dict[str, AAPIdentity] = {}
        self._nodes: dict[str, NRPNode] = {}
        self._audit = AAPAuditChain(
            storage_path=__import__("pathlib").Path(audit_path) if audit_path else None
        )

    # ── Registration ──────────────────────────────────────────────────────────

    def register_identity(self, identity: AAPIdentity) -> None:
        """Register a known agent identity."""
        self._identities[identity.id] = identity

    def register_node(self, node: NRPNode) -> None:
        """Register a physical or digital node."""
        self._nodes[node.id] = node

    def grant_authorization(
        self,
        agent_id: str,
        level: AuthorizationLevel,
        scope: list[str],
        physical: bool = False,
        expires_in_seconds: int | None = None,
    ) -> AAPAuthorization:
        """
        Grant authorization to a registered agent.
        Enforces Physical World Rule automatically.
        """
        expires_at = None
        if expires_in_seconds is not None:
            from datetime import timedelta
            expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in_seconds)

        return AAPAuthorization.create(
            agent_id=agent_id,
            level=level,
            scope=scope,
            supervisor_keypair=self._supervisor_keypair,
            supervisor_did=self._supervisor_did,
            physical=physical,
            expires_at=expires_at,
        )

    # ── Execution ──────────────────────────────────────────────────────────────

    def execute(
        self,
        ctx: ExecutionContext,
        node_id: str,
        action: str,
        params: dict[str, Any],
        input_description: str = "",
    ) -> ExecutionResult:
        """
        Execute an action through the full AAP pipeline.
        Every step is recorded. Nothing is skipped.
        """
        # 1. Identity + Authorization check
        try:
            ctx.check()
        except (AAPRevocationError, Exception) as e:
            return self._blocked(ctx.agent_id, action, node_id, str(e))

        # 2. Scope check
        if not ctx.identity.allows_action(action):
            return self._blocked(
                ctx.agent_id, action, node_id,
                f"Action '{action}' not in agent scope: {ctx.identity.scope}"
            )

        # 3. Get node
        node = self._nodes.get(node_id)
        if node is None:
            return self._blocked(ctx.agent_id, action, node_id, f"Node {node_id!r} not registered")

        # 4. Shield check + Execute
        try:
            node_result = node.execute(action, params)
        except ShieldViolation as e:
            # Shield blocked — still record to audit
            prov = AAPProvenance.create(
                agent_id=ctx.agent_id,
                action=action,
                input_data=str(params).encode(),
                output_data=b"blocked",
                authorization_id=ctx.authorization.session_id,
                agent_keypair=ctx.agent_keypair,
                target=node_id,
            )
            entry = self._audit.append(
                agent_id=ctx.agent_id,
                action=action,
                result="blocked",
                provenance_id=prov.artifact_id,
                agent_keypair=ctx.agent_keypair,
                authorization_level=int(ctx.auth_level),
                physical=node.is_physical,
                result_detail=str(e),
            )
            return ExecutionResult(
                success=False, agent_id=ctx.agent_id, action=action,
                node_id=node_id, output=None,
                provenance_id=prov.artifact_id,
                audit_entry_id=entry.entry_id,
                blocked=True, block_reason=str(e),
            )

        # 5. Provenance
        prov = AAPProvenance.create(
            agent_id=ctx.agent_id,
            action=action,
            input_data=str(params).encode(),
            output_data=str(node_result.output).encode(),
            authorization_id=ctx.authorization.session_id,
            agent_keypair=ctx.agent_keypair,
            target=node_id,
        )

        # 6. Audit
        result_str = "success" if node_result.success else "failure"
        entry = self._audit.append(
            agent_id=ctx.agent_id,
            action=action,
            result=result_str,
            provenance_id=prov.artifact_id,
            agent_keypair=ctx.agent_keypair,
            authorization_level=int(ctx.auth_level),
            physical=node.is_physical,
        )

        return ExecutionResult(
            success=node_result.success,
            agent_id=ctx.agent_id,
            action=action,
            node_id=node_id,
            output=node_result.output,
            provenance_id=prov.artifact_id,
            audit_entry_id=entry.entry_id,
            detail=node_result.detail,
        )

    def verify_audit(self) -> tuple[bool, int, str | None]:
        """Verify the audit chain integrity."""
        return self._audit.verify()

    def audit_entries(self) -> list[dict]:
        """Export full audit log."""
        return self._audit.to_list()

    # ── Internal ──────────────────────────────────────────────────────────────

    def _blocked(self, agent_id, action, node_id, reason) -> ExecutionResult:
        return ExecutionResult(
            success=False, agent_id=agent_id, action=action,
            node_id=node_id, output=None,
            provenance_id=None, audit_entry_id=None,
            blocked=True, block_reason=reason,
        )
