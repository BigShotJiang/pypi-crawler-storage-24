"""
Halyn — AAP in action. AI agents that can prove what they did.

The reference implementation of AAP — Agent Accountability Protocol.
https://halyn.dev | https://aap-protocol.dev
License: MIT
"""
import sys
sys.path.insert(0, "/mnt/data/aap/sdk/python")
sys.path.insert(0, "/mnt/data/nrp-new")

from .core import HalynControlPlane, ExecutionContext, ExecutionResult

__version__ = "1.0.0"
__all__ = ["HalynControlPlane", "ExecutionContext", "ExecutionResult"]
