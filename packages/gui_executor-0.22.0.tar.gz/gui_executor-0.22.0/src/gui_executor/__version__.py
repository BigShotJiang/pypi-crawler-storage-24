"""
The one and only place for the version number.
"""

VERSION = (0, 22, 0)

__version__ = ".".join(map(str, VERSION))
