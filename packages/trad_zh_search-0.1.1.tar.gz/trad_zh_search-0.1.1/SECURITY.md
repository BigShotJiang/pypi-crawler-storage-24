# Security Policy

## Supported Versions

Only the latest release on the `main` branch receives security fixes.

## Threat Model

trad-zh-search is a **text preprocessing library** — it does not make network requests, run a server, or store user data. The primary risks are:

### CKIP model supply chain

CKIP models are downloaded from HuggingFace Hub on first use. PyTorch model files use pickle serialization, which can execute arbitrary code during deserialization. If the upstream model repository (`ckiplab/albert-tiny-chinese-*`) is compromised, malicious code could run on your machine.

**Mitigations:**
- Model identifiers are centralized in `tokenizer.py` (`CKIP_WS_MODEL`, `CKIP_NER_MODEL`) for audit
- For production: pre-download models and set `TRANSFORMERS_OFFLINE=1`
- Consider using a private model mirror

### Dictionary files

`load_dictionary_file()` reads YAML from arbitrary paths. If the path comes from user input (e.g. an API parameter), path traversal is possible.

**Mitigations:**
- `_check_path_safety()` rejects paths containing `..`
- `yaml.safe_load()` is used everywhere (no code execution via YAML)
- `load_dictionary(name)` validates names with `^[a-z0-9][a-z0-9._-]*$`

### build_dictionary and PII

`build_dictionary()` extracts named entities (person names, organizations, locations) from input texts using CKIP NER. If input documents contain personally identifiable information, extracted names will appear in the output dictionary.

**Mitigations:**
- README and docstrings warn about PII in NER output
- CONTRIBUTING.md instructs contributors to review dictionaries for PII before committing

### Memory consumption

Large inputs can consume significant memory:
- `max_chars` defaults to 12,000 characters
- A hard ceiling of 1,000,000 characters is enforced even when `max_chars=None`
- `_apply_custom_dict` is O(C * N) — large dictionaries with large texts may be slow

## Reporting a Vulnerability

Please **do not** open a public GitHub issue for security vulnerabilities.

Email the maintainer directly (see profile) or open a
[private security advisory](https://github.com/notoriouslab/trad-zh-search/security/advisories/new).

Expect a response within 72 hours.
