# Contributing / 貢獻指南

感謝你有興趣為 trad-zh-search 做出貢獻！

Thank you for your interest in contributing to trad-zh-search!

---

## 貢獻領域字典 / Contributing a Domain Dictionary

這是最有價值的貢獻方式——讓更多領域的繁體中文搜尋變好。

### 字典格式

建立 `dictionaries/<your-domain>/dictionary.yaml`，YAML 格式：

```yaml
# 自訂分詞詞庫——CKIP 容易切錯的領域專有詞
ckip_custom_words:
  - 你的專有詞1
  - 你的專有詞2

# （選填）別名映射
aliases:
  簡稱: 完整名稱

# （選填）同義詞組
synonyms:
  詞A: [詞B, 詞C]
```

### 什麼詞該加入 ckip_custom_words？

加入 CKIP 會切錯的詞。測試方法：

```python
from trad_zh_search import tokenize

result = tokenize("你的專有詞")
print(result.tokens)  # 看 CKIP 有沒有切錯
```

如果 CKIP 把「國家人權委員會」切成「國家/人權/委員會」，就該加入。

**不需要加入**的詞：
- CKIP 本來就切對的通用詞
- 單字（CKIP 不會切更小）
- 純英文通用名（`David`、`Grace` 等）

### 自動提取起步

如果你有一批領域文件，可以用 `build_dictionary` 自動提取起點，再人工微調：

```python
from trad_zh_search import build_dictionary, save_dictionary

texts = [open(f).read() for f in my_files]
my_dict = build_dictionary(texts, min_freq=2)
save_dictionary(my_dict, "dictionaries/my-domain/dictionary.yaml")
# 然後人工檢查：刪除噪音、補充遺漏、移除個資（人名等）
```

### 驗證

提交前請確認字典可以正常載入：

```python
from trad_zh_search import load_dictionary_file

d = load_dictionary_file("dictionaries/my-domain/dictionary.yaml")
print(f"{len(d.ckip_custom_words)} custom words")
```

### PR 流程

1. Fork 本 repo
2. 建立分支：`git checkout -b dict/your-domain`
3. 新增字典檔案到 `trad_zh_search/dictionaries/<your-domain>/dictionary.yaml`
4. 驗證可載入（見上方）
5. 提交 PR，說明：
   - 字典涵蓋的領域
   - 資料來源（NER 自動提取？人工整理？）
   - 大約的詞數

---

## 貢獻程式碼 / Contributing Code

### 開發環境

```bash
git clone https://github.com/notoriouslab/trad-zh-search.git
cd trad-zh-search
pip install -e ".[dev]"

# 跑測試
pytest tests/ -v
```

### 準則

- 繁體中文優先，但程式碼和 docstring 用英文
- 測試覆蓋率：新功能必須附測試
- 不引入硬編碼路徑
- CKIP 相關功能必須 graceful degradation（無 CKIP 時不爆錯）

---

## 授權 / License

貢獻的程式碼和字典皆以 MIT 授權釋出。
