"""Custom exceptions for trad-zh-search."""


class DictionaryLoadError(Exception):
    """Raised when a dictionary file cannot be loaded."""


class DictionaryValidationError(Exception):
    """Raised when a dictionary has severe format errors (wrong types)."""


class DictionaryNotFoundError(Exception):
    """Raised when a built-in dictionary name is not found."""


class CkipRequiredError(Exception):
    """Raised when an operation requires ckip-transformers but it is not installed."""
