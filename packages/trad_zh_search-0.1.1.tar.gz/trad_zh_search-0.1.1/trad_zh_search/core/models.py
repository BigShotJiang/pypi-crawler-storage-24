"""Core data models for trad-zh-search."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TokenResult:
    """Result of tokenizing a text.

    Attributes:
        original: The input text (after truncation if max_chars was applied).
        tokens: CKIP segmented tokens. Empty list if CKIP is not available.
        bigrams: CJK character bigrams. Always produced.
        used_ckip: Whether CKIP segmentation was used.
    """

    original: str
    tokens: list[str] = field(default_factory=list)
    bigrams: list[str] = field(default_factory=list)
    used_ckip: bool = False


@dataclass
class Dictionary:
    """A pluggable dictionary for enhancing tokenization.

    Attributes:
        ckip_custom_words: Terms that should not be split by the tokenizer.
        aliases: Alias mappings (key -> canonical or list of canonicals).
            Used by Phase 2 entity-resolver.
        synonyms: Synonym groups (key -> list of synonyms).
            Used by Phase 2 synonym-expander and adapter synonym output.
    """

    ckip_custom_words: list[str] = field(default_factory=list)
    aliases: dict[str, str | list[str]] = field(default_factory=dict)
    synonyms: dict[str, list[str]] = field(default_factory=dict)
