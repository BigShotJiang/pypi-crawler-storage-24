"""Dictionary loading, validation, merging, and saving."""

from __future__ import annotations

import importlib.resources
import logging
import os
import re
from pathlib import Path

import yaml

from trad_zh_search.core.exceptions import (
    DictionaryLoadError,
    DictionaryNotFoundError,
    DictionaryValidationError,
)
from trad_zh_search.core.models import Dictionary

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def _check_path_safety(path: Path) -> None:
    """Reject paths with '..' components to prevent path traversal."""
    if ".." in path.parts:
        raise DictionaryLoadError(
            f"Path traversal detected (contains '..'): {path}"
        )


def load_dictionary_file(path: str | Path) -> Dictionary:
    """Load a dictionary from a YAML file.

    Args:
        path: Path to the YAML dictionary file.

    Returns:
        A Dictionary object.

    Raises:
        DictionaryLoadError: If the file cannot be read, parsed, or contains
            path traversal components.
    """
    path = Path(path)
    _check_path_safety(path)
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise DictionaryLoadError(f"Dictionary file not found: {path}")
    except yaml.YAMLError as e:
        raise DictionaryLoadError(f"Invalid YAML in {path}: {e}")

    if raw is None:
        raise DictionaryLoadError(f"Dictionary file is empty: {path}")
    if not isinstance(raw, dict):
        raise DictionaryLoadError(
            f"Dictionary root must be a mapping, got {type(raw).__name__}: {path}"
        )

    return _parse_raw(raw, source=str(path))


def load_dictionary(name: str) -> Dictionary:
    """Load a built-in dictionary by name.

    Args:
        name: Name of the built-in dictionary (e.g. "christian-zh-hant").

    Returns:
        A Dictionary object.

    Raises:
        DictionaryNotFoundError: If the name does not match any built-in dictionary.
    """
    _VALID_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")
    if not _VALID_NAME_RE.match(name):
        raise DictionaryNotFoundError(
            f"Invalid dictionary name '{name}'. "
            "Names must be lowercase alphanumeric with hyphens/dots/underscores."
        )

    available = _list_builtin_dictionaries()
    if name not in available:
        raise DictionaryNotFoundError(
            f"Dictionary '{name}' not found. Available: {sorted(available)}"
        )

    dict_dir = importlib.resources.files("trad_zh_search.dictionaries") / name
    yaml_path = dict_dir / "dictionary.yaml"

    # Read via importlib.resources for package compatibility
    raw_text = yaml_path.read_text(encoding="utf-8")
    try:
        raw = yaml.safe_load(raw_text)
    except yaml.YAMLError as e:
        raise DictionaryLoadError(f"Invalid YAML in built-in dictionary '{name}': {e}")

    if raw is None or not isinstance(raw, dict):
        raise DictionaryLoadError(f"Built-in dictionary '{name}' is empty or invalid")

    return _parse_raw(raw, source=f"built-in:{name}")


def _list_builtin_dictionaries() -> set[str]:
    """List available built-in dictionary names."""
    pkg = importlib.resources.files("trad_zh_search.dictionaries")
    names = set()
    for item in pkg.iterdir():
        if item.is_dir() and (item / "dictionary.yaml").is_file():
            names.add(item.name)
    return names


# ---------------------------------------------------------------------------
# Parsing & Validation
# ---------------------------------------------------------------------------


def _parse_raw(raw: dict, source: str) -> Dictionary:
    """Parse a raw YAML dict into a Dictionary with validation."""
    ckip_custom_words = _validate_ckip_custom_words(
        raw.get("ckip_custom_words"), source
    )
    aliases = _validate_aliases(raw.get("aliases"), source)
    synonyms = _validate_synonyms(raw.get("synonyms"), source)

    return Dictionary(
        ckip_custom_words=ckip_custom_words,
        aliases=aliases,
        synonyms=synonyms,
    )


def _validate_ckip_custom_words(
    value: object, source: str
) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise DictionaryValidationError(
            f"ckip_custom_words must be a list, got {type(value).__name__} in {source}"
        )
    cleaned = []
    for item in value:
        if not isinstance(item, str):
            raise DictionaryValidationError(
                f"ckip_custom_words items must be strings, got {type(item).__name__} in {source}"
            )
        stripped = item.strip()
        if not stripped:
            logger.warning("Empty string in ckip_custom_words, skipping (%s)", source)
            continue
        cleaned.append(stripped)
    return cleaned


def _validate_aliases(value: object, source: str) -> dict[str, str | list[str]]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise DictionaryValidationError(
            f"aliases must be a dict, got {type(value).__name__} in {source}"
        )
    for k, v in value.items():
        if not isinstance(k, str):
            raise DictionaryValidationError(
                f"aliases keys must be strings, got {type(k).__name__} in {source}"
            )
        if isinstance(v, str):
            if not v.strip():
                logger.warning("Empty alias value for key '%s' (%s)", k, source)
        elif isinstance(v, list):
            if not v:
                logger.warning("Empty alias list for key '%s' (%s)", k, source)
            elif not all(isinstance(item, str) for item in v):
                raise DictionaryValidationError(
                    f"aliases list items must be strings for key '{k}' in {source}"
                )
        else:
            raise DictionaryValidationError(
                f"aliases values must be str or list[str], got {type(v).__name__} for key '{k}' in {source}"
            )
    return dict(value)


def _validate_synonyms(value: object, source: str) -> dict[str, list[str]]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise DictionaryValidationError(
            f"synonyms must be a dict, got {type(value).__name__} in {source}"
        )
    for k, v in value.items():
        if not isinstance(k, str):
            raise DictionaryValidationError(
                f"synonyms keys must be strings, got {type(k).__name__} in {source}"
            )
        if not isinstance(v, list):
            raise DictionaryValidationError(
                f"synonyms values must be list[str], got {type(v).__name__} for key '{k}' in {source}"
            )
        if not v:
            logger.warning("Empty synonym list for key '%s' (%s)", k, source)
        elif not all(isinstance(item, str) for item in v):
            raise DictionaryValidationError(
                f"synonyms list items must be strings for key '{k}' in {source}"
            )
    return dict(value)


# ---------------------------------------------------------------------------
# Merging
# ---------------------------------------------------------------------------


def merge_dictionaries(*dicts: Dictionary) -> Dictionary:
    """Merge multiple dictionaries in order (base → domain).

    Merge strategy:
        - ckip_custom_words: union, deduplicated
        - aliases: later dict overwrites earlier (same key → later wins)
        - synonyms: same key → values union, deduplicated
    """
    if not dicts:
        return Dictionary()

    merged_words: list[str] = []
    seen_words: set[str] = set()
    merged_aliases: dict[str, str | list[str]] = {}
    merged_synonyms: dict[str, list[str]] = {}

    for d in dicts:
        # ckip_custom_words: union
        for w in d.ckip_custom_words:
            if w not in seen_words:
                seen_words.add(w)
                merged_words.append(w)

        # aliases: overwrite
        merged_aliases.update(d.aliases)

        # synonyms: union values
        for key, values in d.synonyms.items():
            if key in merged_synonyms:
                existing = set(merged_synonyms[key])
                for v in values:
                    if v not in existing:
                        merged_synonyms[key].append(v)
                        existing.add(v)
            else:
                merged_synonyms[key] = list(values)

    return Dictionary(
        ckip_custom_words=merged_words,
        aliases=merged_aliases,
        synonyms=merged_synonyms,
    )


# ---------------------------------------------------------------------------
# Saving
# ---------------------------------------------------------------------------


def save_dictionary(dictionary: Dictionary, path: str | Path) -> None:
    """Save a Dictionary to a YAML file (atomic write via temp file + os.replace).

    Args:
        dictionary: The Dictionary object to save.
        path: Output file path.

    Raises:
        DictionaryLoadError: If path contains traversal components.
    """
    path = Path(path)
    _check_path_safety(path)
    data: dict = {}

    if dictionary.ckip_custom_words:
        data["ckip_custom_words"] = dictionary.ckip_custom_words
    if dictionary.aliases:
        data["aliases"] = dictionary.aliases
    if dictionary.synonyms:
        data["synonyms"] = dictionary.synonyms

    path.parent.mkdir(parents=True, exist_ok=True)
    content = yaml.dump(
        data, allow_unicode=True, default_flow_style=False, sort_keys=False
    )

    # Atomic write: temp file in same directory + os.replace()
    import tempfile

    fd, tmp_path = tempfile.mkstemp(
        dir=path.parent, suffix=".tmp", prefix=".dict_"
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp_path, path)
    except BaseException:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise
