"""Dictionary builder: auto-extract custom words from text using CKIP NER.

Note on build_dictionary output: NER extraction may capture personal names,
organization names, and locations from input texts. If input documents contain
personally identifiable information (PII), the resulting dictionary will too.
Always review the output before committing to version control.
"""

from __future__ import annotations

import logging
import threading
from collections import Counter
from typing import Optional

from trad_zh_search.core.exceptions import CkipRequiredError
from trad_zh_search.core.models import Dictionary

logger = logging.getLogger(__name__)

# NER types worth keeping as custom words for tokenization.
# Excludes DATE, TIME, CARDINAL, MONEY, PERCENT, QUANTITY, ORDINAL, etc.
_USEFUL_NER_TYPES = {"PERSON", "ORG", "LOC", "GPE", "FAC", "NORP", "EVENT"}

# Singleton NER chunker.
# Shared at process level — does not cache input text, but be aware in
# multi-tenant deployments if adding a cache layer in the future.
_ner = None
_ner_lock = threading.Lock()


def _get_ner():
    global _ner
    if _ner is None:
        with _ner_lock:
            if _ner is None:  # double-checked locking
                try:
                    from ckip_transformers.nlp import CkipNerChunker
                except ImportError:
                    raise CkipRequiredError(
                        "dictionary builder requires ckip-transformers. "
                        "Install with: pip install trad-zh-search[ckip]"
                    )
                from trad_zh_search.core.tokenizer import CKIP_NER_MODEL

                _ner = CkipNerChunker(model=CKIP_NER_MODEL, device=-1)
    return _ner


def _reset_ner_cache() -> None:
    """Reset singleton NER model. For testing only."""
    global _ner
    _ner = None


def build_dictionary(
    texts: list[str],
    min_freq: int = 2,
    batch_size: int = 32,
    max_chars: Optional[int] = 12_000,
) -> Dictionary:
    """Build a dictionary by extracting named entities from texts using CKIP NER.

    Extracts PERSON, ORG, LOC (and related) entities, filters by frequency,
    and returns a Dictionary with ckip_custom_words populated. Aliases and
    synonyms are left empty (they require human curation).

    **Privacy note**: extracted entities may contain personal names from the
    input documents. Review the output before saving/committing.

    Args:
        texts: List of input texts to extract entities from.
        min_freq: Minimum occurrence count to include an entity. Default: 2.
        batch_size: Texts per NER batch. Default: 32.
        max_chars: Truncate each text to this length. None = no truncation.

    Returns:
        Dictionary with ckip_custom_words from extracted entities.

    Raises:
        CkipRequiredError: If ckip-transformers is not installed.
    """
    ner = _get_ner()

    # Truncate
    if max_chars is not None:
        texts = [t[:max_chars] for t in texts]

    # Run NER in batches
    entity_counts: Counter[str] = Counter()

    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        batch_results = ner(batch)

        for entities in batch_results:
            for entity in entities:
                # ckip_transformers returns NerToken with .word and .ner attributes.
                # Use attribute access with fallback for forward compatibility.
                word = getattr(entity, "word", None)
                if word is None:
                    word = entity[0] if isinstance(entity, (list, tuple)) else str(entity)

                ner_type = getattr(entity, "ner", None)
                if ner_type is None and isinstance(entity, (list, tuple)) and len(entity) > 1:
                    ner_type = entity[1]

                # Filter by NER type — skip unknown types (None) and non-useful types
                if ner_type is None or ner_type not in _USEFUL_NER_TYPES:
                    continue

                word = word.strip()
                if len(word) >= 2:  # Skip single-char entities
                    entity_counts[word] += 1

    # Filter by frequency
    words = sorted(
        [word for word, count in entity_counts.items() if count >= min_freq]
    )

    logger.info(
        "Extracted %d entities (min_freq=%d) from %d texts",
        len(words),
        min_freq,
        len(texts),
    )

    return Dictionary(ckip_custom_words=words)
