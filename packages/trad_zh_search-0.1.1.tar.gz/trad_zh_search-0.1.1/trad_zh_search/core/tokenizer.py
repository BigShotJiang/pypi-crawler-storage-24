"""Tokenizer: CKIP segmentation + bigram generation with graceful degradation.

Security note: CKIP models are downloaded from HuggingFace Hub on first use.
The models use PyTorch serialization (pickle-based), which carries inherent
deserialization risks if the upstream model repository is compromised.
For production deployments, consider:
  - Setting TRANSFORMERS_OFFLINE=1 with pre-downloaded models
  - Verifying model checksums before deployment
  - Using a private model mirror
"""

from __future__ import annotations

import logging
import re
import threading
from typing import Optional

from trad_zh_search.core.models import Dictionary, TokenResult

logger = logging.getLogger(__name__)

# Model identifiers — centralized for auditability.
# ckip-transformers maps these short names to full HuggingFace repo paths internally.
CKIP_WS_MODEL = "albert-tiny"
CKIP_NER_MODEL = "albert-tiny"

# ---------------------------------------------------------------------------
# CKIP availability check (lazy, one-time)
# ---------------------------------------------------------------------------

_HAS_CKIP: bool | None = None  # None = not yet checked
_ckip_warned = False
_ws = None
_ws_lock = threading.Lock()


def _check_ckip() -> bool:
    global _HAS_CKIP
    if _HAS_CKIP is None:
        with _ws_lock:
            if _HAS_CKIP is None:  # double-checked locking
                try:
                    from ckip_transformers.nlp import CkipWordSegmenter  # noqa: F401

                    _HAS_CKIP = True
                except ImportError:
                    _HAS_CKIP = False
    return _HAS_CKIP


def _get_ws():
    global _ws
    if _ws is None:
        with _ws_lock:
            if _ws is None:  # double-checked locking
                from ckip_transformers.nlp import CkipWordSegmenter

                _ws = CkipWordSegmenter(model=CKIP_WS_MODEL, device=-1)
    return _ws


def _reset_ckip_cache() -> None:
    """Reset CKIP singleton state. For testing only."""
    global _HAS_CKIP, _ws, _ckip_warned
    _HAS_CKIP = None
    _ws = None
    _ckip_warned = False


def _warn_no_ckip() -> None:
    """Log a one-time warning when CKIP is unavailable."""
    global _ckip_warned
    if not _ckip_warned:
        logger.warning("ckip-transformers not available, using bigram-only mode")
        _ckip_warned = True


# ---------------------------------------------------------------------------
# Token filtering
# ---------------------------------------------------------------------------

# CJK Unified + CJK Extension A + ASCII alphanumeric
_KEEP_TOKEN_RE = re.compile(
    r"[\u4e00-\u9fff"   # CJK Unified Ideographs
    r"\u3400-\u4dbf"    # CJK Extension A
    r"a-zA-Z0-9]"       # ASCII alphanumeric
)


def _filter_tokens(tokens: list[str]) -> list[str]:
    """Keep only tokens containing CJK or ASCII alphanumeric characters."""
    return [t for t in tokens if _KEEP_TOKEN_RE.search(t)]


# ---------------------------------------------------------------------------
# Custom dictionary post-processing
# ---------------------------------------------------------------------------


def _apply_custom_dict(
    text: str, tokens: list[str], custom_words: list[str]
) -> list[str]:
    """Merge CKIP tokens that match custom dictionary entries.

    Algorithm: longest-match-first in original text, then merge tokens
    whose character positions fall within a matched range.

    Complexity: O(C * N) where C = len(custom_words), N = len(text).
    With the default max_chars=12000 and ~1400 words this is acceptable.
    For very large dictionaries (10K+) consider using an Aho-Corasick automaton.
    """
    if not custom_words:
        return tokens

    # 1. Find all custom word matches in original text (longest first, no overlap)
    protected: list[tuple[int, int, str]] = []  # (start, end, term)
    for term in sorted(custom_words, key=len, reverse=True):
        start = 0
        while True:
            idx = text.find(term, start)
            if idx == -1:
                break
            end = idx + len(term)
            overlap = any(
                not (end <= ps or idx >= pe) for ps, pe, _ in protected
            )
            if not overlap:
                protected.append((idx, end, term))
            start = idx + 1

    if not protected:
        return tokens

    # 2. Build token position map by greedy forward scan.
    #    Each token is matched to its earliest occurrence at or after `pos`.
    #    If not found forward (CKIP reorder), scan from beginning but skip
    #    positions already claimed by earlier tokens.
    pos = 0
    token_spans: list[tuple[int, int]] = []
    claimed: set[int] = set()  # start positions already used
    for tok in tokens:
        idx = text.find(tok, pos)
        if idx == -1:
            # Not found after pos — scan from beginning, skip claimed positions
            search_start = 0
            idx = -1
            while search_start < len(text):
                candidate = text.find(tok, search_start)
                if candidate == -1:
                    break
                if candidate not in claimed:
                    idx = candidate
                    break
                search_start = candidate + 1
        if idx == -1:
            token_spans.append((-1, -1))
            continue
        claimed.add(idx)
        token_spans.append((idx, idx + len(tok)))
        pos = idx + len(tok)

    # 3. Merge tokens within protected ranges.
    # Use a consumed set to avoid processing the same token twice when
    # unmatchable tokens (-1,-1) appear inside a protected range.
    consumed: set[int] = set()
    result: list[str] = []
    i = 0
    while i < len(tokens):
        if i in consumed:
            i += 1
            continue
        tok_start, tok_end = token_spans[i]
        if tok_start == -1:
            # Unmatchable token — pass through as-is
            result.append(tokens[i])
            i += 1
            continue
        matched = False
        for ps, pe, term in protected:
            if tok_start >= ps and tok_end <= pe:
                # Collect all tokens in this protected range, skipping (-1,-1)
                j = i
                while j < len(tokens):
                    ts, te = token_spans[j]
                    if ts == -1:
                        # Unmatchable token inside range — skip it, keep scanning
                        j += 1
                        continue
                    if ts >= ps and te <= pe:
                        consumed.add(j)
                        j += 1
                    else:
                        break
                result.append(term)
                i = j
                matched = True
                break
        if not matched:
            result.append(tokens[i])
            i += 1

    return result


# ---------------------------------------------------------------------------
# Bigram generation
# ---------------------------------------------------------------------------


def _generate_bigrams(text: str) -> list[str]:
    """Generate CJK character bigrams from text.

    Scans for consecutive CJK character runs and produces sliding-window
    bigrams. Non-CJK characters break the run. Single CJK characters
    (run length < 2) produce no bigrams.
    """
    result: list[str] = []
    run: list[str] = []

    for c in text:
        cp = ord(c)
        if (0x4E00 <= cp <= 0x9FFF) or (0x3400 <= cp <= 0x4DBF):
            run.append(c)
        else:
            if len(run) >= 2:
                for i in range(len(run) - 1):
                    result.append(run[i] + run[i + 1])
            run = []

    # Flush remaining run
    if len(run) >= 2:
        for i in range(len(run) - 1):
            result.append(run[i] + run[i + 1])

    return result


# ---------------------------------------------------------------------------
# Main API
# ---------------------------------------------------------------------------

_DEFAULT_MAX_CHARS = 12_000
_HARD_CEILING_CHARS = 1_000_000  # 1MB safety limit even when max_chars=None


def tokenize(
    text: str,
    dictionary: Optional[Dictionary] = None,
    max_chars: Optional[int] = _DEFAULT_MAX_CHARS,
) -> TokenResult:
    """Tokenize a single text.

    Args:
        text: Input text to tokenize.
        dictionary: Optional dictionary for custom word merging.
        max_chars: Truncate input to this many characters. None = no truncation.
            Default: 12000.

    Returns:
        TokenResult with tokens, bigrams, and used_ckip flag.
    """
    if max_chars is not None:
        text = text[:max_chars]
    text = text[:_HARD_CEILING_CHARS]

    bigrams = _generate_bigrams(text)
    tokens: list[str] = []
    used_ckip = False

    if _check_ckip():
        ws = _get_ws()
        raw_tokens = ws([text])[0]
        raw_tokens = _filter_tokens(raw_tokens)

        if dictionary and dictionary.ckip_custom_words:
            raw_tokens = _apply_custom_dict(
                text, raw_tokens, dictionary.ckip_custom_words
            )

        tokens = raw_tokens
        used_ckip = True
    else:
        _warn_no_ckip()

    return TokenResult(
        original=text,
        tokens=tokens,
        bigrams=bigrams,
        used_ckip=used_ckip,
    )


def tokenize_batch(
    texts: list[str],
    dictionary: Optional[Dictionary] = None,
    max_chars: Optional[int] = _DEFAULT_MAX_CHARS,
    batch_size: int = 32,
) -> list[TokenResult]:
    """Tokenize multiple texts efficiently.

    CKIP model is loaded once and texts are processed in batches.

    Args:
        texts: List of input texts.
        dictionary: Optional dictionary for custom word merging.
        max_chars: Truncate each input. None = no truncation. Default: 12000.
        batch_size: Number of texts per CKIP batch. Default: 32.

    Returns:
        List of TokenResult, one per input text.
    """
    # Truncate
    if max_chars is not None:
        texts = [t[:max_chars] for t in texts]
    texts = [t[:_HARD_CEILING_CHARS] for t in texts]

    # Bigrams for all
    all_bigrams = [_generate_bigrams(t) for t in texts]

    # CKIP
    if _check_ckip():
        ws = _get_ws()
        custom_words = (
            dictionary.ckip_custom_words
            if dictionary and dictionary.ckip_custom_words
            else []
        )

        all_tokens: list[list[str]] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            batch_results = ws(batch)
            for text, raw_tokens in zip(batch, batch_results):
                raw_tokens = _filter_tokens(raw_tokens)
                if custom_words:
                    raw_tokens = _apply_custom_dict(text, raw_tokens, custom_words)
                all_tokens.append(raw_tokens)

        return [
            TokenResult(
                original=texts[i],
                tokens=all_tokens[i],
                bigrams=all_bigrams[i],
                used_ckip=True,
            )
            for i in range(len(texts))
        ]
    else:
        _warn_no_ckip()

        return [
            TokenResult(
                original=texts[i],
                tokens=[],
                bigrams=all_bigrams[i],
                used_ckip=False,
            )
            for i in range(len(texts))
        ]
