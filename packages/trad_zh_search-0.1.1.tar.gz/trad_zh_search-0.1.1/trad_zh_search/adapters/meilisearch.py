"""Meilisearch adapter: convert TokenResult to Meilisearch document format."""

from __future__ import annotations

from typing import Any

from trad_zh_search.core.models import Dictionary, TokenResult


def to_meilisearch(
    fields: dict[str, TokenResult],
    original: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Convert tokenized fields to a Meilisearch document.

    For each field in `fields`, produces:
        - {field}_ckip: space-joined tokens (empty string if no CKIP)
        - {field}_bigram: space-joined bigrams

    Fields in `original` that are not in `fields` are passed through as-is.

    Args:
        fields: Mapping of field name -> TokenResult.
        original: Original document fields to include in output.

    Returns:
        A dict ready for Meilisearch indexing.
    """
    doc: dict[str, Any] = {}

    # Pass through original fields
    if original:
        doc.update(original)

    # Add tokenized fields
    for name, result in fields.items():
        if name not in doc:
            doc[name] = result.original
        doc[f"{name}_ckip"] = " ".join(result.tokens)
        doc[f"{name}_bigram"] = " ".join(result.bigrams)

    return doc


def to_meilisearch_batch(
    fields_list: list[dict[str, TokenResult]],
    originals: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Batch version of to_meilisearch.

    Args:
        fields_list: List of field mappings, one per document.
        originals: List of original documents. If None, no passthrough fields.

    Returns:
        List of Meilisearch document dicts.
    """
    if originals is None:
        originals = [None] * len(fields_list)
    elif len(originals) != len(fields_list):
        raise ValueError(
            f"fields_list and originals must have the same length, "
            f"got {len(fields_list)} and {len(originals)}"
        )

    return [
        to_meilisearch(fields, orig)
        for fields, orig in zip(fields_list, originals)
    ]


class _UnionFind:
    """Disjoint-set / union-find for near-linear group merging.

    Uses path compression only (no union by rank), giving O(N * log(N))
    amortized. Sufficient for typical synonym dictionaries.
    """

    def __init__(self) -> None:
        self._parent: dict[str, str] = {}

    def find(self, x: str) -> str:
        if x not in self._parent:
            self._parent[x] = x
        while self._parent[x] != x:
            self._parent[x] = self._parent[self._parent[x]]  # path compression
            x = self._parent[x]
        return x

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self._parent[ra] = rb

    def groups(self) -> list[set[str]]:
        buckets: dict[str, set[str]] = {}
        for x in self._parent:
            root = self.find(x)
            buckets.setdefault(root, set()).add(x)
        return list(buckets.values())


def to_meilisearch_synonyms(dictionary: Dictionary) -> dict[str, list[str]]:
    """Convert Dictionary synonyms to Meilisearch bidirectional synonym format.

    Meilisearch synonyms are bidirectional: each word must list all other
    words in its synonym group.

    Example:
        Input:  {"敬拜": ["崇拜", "主日"]}
        Output: {"敬拜": ["崇拜", "主日"], "崇拜": ["敬拜", "主日"], "主日": ["敬拜", "崇拜"]}
    """
    # Build groups using union-find for O(N * alpha(N)) merging
    uf = _UnionFind()
    for key, values in dictionary.synonyms.items():
        for v in values:
            uf.union(key, v)

    # Convert groups to Meilisearch format
    result: dict[str, list[str]] = {}
    for group in uf.groups():
        if len(group) < 2:
            continue
        for word in group:
            others = sorted(w for w in group if w != word)
            if others:
                result[word] = others

    return result
