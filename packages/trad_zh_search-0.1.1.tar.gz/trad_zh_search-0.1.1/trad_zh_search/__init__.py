"""trad-zh-search: Traditional Chinese text preprocessing for search engines."""

from trad_zh_search.core.models import Dictionary, TokenResult
from trad_zh_search.core.tokenizer import tokenize, tokenize_batch
from trad_zh_search.core.dictionary import (
    load_dictionary,
    load_dictionary_file,
    merge_dictionaries,
    save_dictionary,
)
from trad_zh_search.core.builder import build_dictionary

__version__ = "0.1.1"

__all__ = [
    "Dictionary",
    "TokenResult",
    "tokenize",
    "tokenize_batch",
    "load_dictionary",
    "load_dictionary_file",
    "merge_dictionaries",
    "save_dictionary",
    "build_dictionary",
]
