# trad-zh-search

Search-engine-agnostic text preprocessing for Traditional Chinese — CKIP segmentation + bigram index generation with pluggable domain dictionaries.

**Requires Python 3.9+** · Part of the [notoriouslab](https://github.com/notoriouslab) open-source toolkit.

> [中文 README](README.md)

---

## What's Inside

```
Your text → trad-zh-search → Search engine (Meilisearch / Elasticsearch / ...)
```

| Component | What it is | Do I need to install it? |
|-----------|-----------|------------------------|
| **CKIP** ([ckip-transformers](https://github.com/ckiplab/ckip-transformers)) | Traditional Chinese NLP toolkit by Academia Sinica, Transformer-based word segmentation | Optional (`pip install trad-zh-search[ckip]`) |
| **albert-tiny** | CKIP's segmentation model, only ~50MB, runs on CPU | Auto-downloaded with CKIP |
| **Bigram** | Pairs consecutive CJK characters ("聖靈充滿" → "聖靈" "靈充" "充滿"), ensures no search miss | Built-in, no install needed |
| **Domain dictionary** | YAML word list telling the tokenizer which terms to keep intact | Ships with a Christian Chinese dictionary; you can build your own |
| **PyYAML** | YAML reader/writer | Auto-installed |

**Minimal install** needs only PyYAML (a few KB) — bigram mode works out of the box. Adding CKIP pulls in PyTorch (~700MB) + model (~50MB), but dramatically improves segmentation quality.

---

## Why This Tool

Most search engines (Meilisearch, Elasticsearch, SQLite FTS5) rely on jieba for Chinese support — trained on Simplified Chinese, poor segmentation quality for Traditional Chinese. See the difference:

| Input | jieba | CKIP + custom dict |
|-------|-------|-------------------|
| 聖靈充滿的經歷 | 聖靈 / 充滿 / 的 / 經歷 | **聖靈充滿** / 的 / 經歷 |
| 因信稱義的教義 | 因信 / **稱義的** / 教義 | 因信 / **稱義** / 的 / **教義** |
| 台北靈糧堂的主日崇拜 | 台北 / 靈糧堂 / 的 / 主日 / 崇拜 | **台北靈糧堂** / 的 / 主日崇拜 |
| 靈糧教牧宣教神學院 | 靈糧 / 教牧 / 宣教 / 神學院 | **靈糧教牧宣教神學院** |

jieba merges "稱義的" into one token, splits "聖靈充滿" into two, and fragments every organization name. CKIP + custom dictionary handles all of these correctly.

### Production Numbers

Benchmarked on a production system with 8,000+ Traditional Chinese articles (80 benchmark queries):

- **CKIP + bigram**: **21% of queries improved** in Top-1 results (17/80 better, 3/80 worse)
- **albert-tiny** vs bert-base: identical segmentation, 4x faster, 10x smaller model
- **Custom dictionary** (915 terms): organization names and person names stay intact

### Features

| Feature | |
|---|---|
| CKIP segmentation | ckip-transformers (albert-tiny) — purpose-built for Traditional Chinese |
| Bigram indexing | CJK character sliding-window bigrams — catches all substring matches |
| Optional CKIP | Without CKIP: `tokens` returns empty list, `used_ckip` is False, bigrams still produced |
| Domain dictionaries | Pluggable YAML format. Ships with a Christian Chinese dictionary (915 custom words) |
| Auto dictionary builder | Feed in documents, CKIP NER extracts named entities automatically |
| Meilisearch adapter | TokenResult → multi-field document format in one call |

---

## Quick Start

```bash
pip install trad-zh-search

# (Optional) CKIP segmentation support
pip install trad-zh-search[ckip]
```

> **CKIP installation note**
>
> `trad-zh-search[ckip]` pulls in PyTorch (~700MB+) as a transitive dependency of ckip-transformers.
> The albert-tiny model (~50MB) is downloaded from HuggingFace on first `tokenize()` call — internet access is required.
> For offline/CI environments, see [HuggingFace offline mode](https://huggingface.co/docs/transformers/installation#offline-mode).
>
> Without CKIP, the library gracefully degrades to bigram-only mode — still better than jieba for Traditional Chinese.

### Three Lines of Code

```python
from trad_zh_search import tokenize

result = tokenize("轉型正義委員會的調查報告")
print(result.bigrams)   # ['轉型', '型正', '正義', '義委', ...]
print(result.tokens)    # CKIP segmented tokens (if CKIP is installed)
print(result.used_ckip) # True / False
```

### With a Domain Dictionary

```python
from trad_zh_search import tokenize, load_dictionary

ck_dict = load_dictionary("christian-zh-hant")
result = tokenize("台北靈糧堂的主日崇拜", dictionary=ck_dict)
# Custom word merging: "台北靈糧堂" stays as one token instead of being split
```

### Auto-build Dictionary from Documents

```python
from trad_zh_search import build_dictionary, save_dictionary

texts = [open(f).read() for f in my_articles]
my_dict = build_dictionary(texts, min_freq=2)  # NER extraction
save_dictionary(my_dict, "my_domain.yaml")       # Save for manual review
```

### Meilisearch Integration

```python
from trad_zh_search import tokenize, load_dictionary
from trad_zh_search.adapters.meilisearch import to_meilisearch, to_meilisearch_synonyms

ck_dict = load_dictionary("christian-zh-hant")

doc = to_meilisearch(
    fields={
        "title": tokenize(title, dictionary=ck_dict),
        "content": tokenize(content, dictionary=ck_dict),
    },
    original={"id": doc_id, "title": title, "content": content},
)
# → {"id": ..., "title": ..., "title_ckip": "...", "title_bigram": "...",
#    "content": ..., "content_ckip": "...", "content_bigram": "...", ...}

synonyms = to_meilisearch_synonyms(ck_dict)
# → {"敬拜": ["崇拜", "主日"], "崇拜": ["敬拜", "主日"], ...}
```

**Search tip**: Add these fields to `searchableAttributes` in this order (order = weight priority):

```
title_ckip → title_bigram → content_ckip → content_bigram
```

CKIP and bigram are complementary — CKIP provides precise word-boundary matching, bigram catches all substring matches.

---

## TokenResult

```python
@dataclass
class TokenResult:
    original: str        # Input text (after truncation)
    tokens: list[str]    # CKIP segmented tokens (empty if CKIP unavailable)
    bigrams: list[str]   # CJK bigrams (always produced)
    used_ckip: bool      # Whether CKIP was used
```

---

## Dictionary Format

YAML with three optional sections:

```yaml
# Custom words for tokenizer (core feature)
ckip_custom_words:
  - 轉型正義
  - 國家人權委員會

# Alias mappings (for future entity-resolver)
aliases:
  人權會: 國家人權委員會

# Synonym groups (adapter can output as search engine synonyms)
synonyms:
  判決: [裁定, 裁判]
```

---

## Dictionary Name Disclaimer

The built-in `christian-zh-hant` dictionary contains names of well-known pastors, theologians, biblical figures, and historical figures, sourced from publicly available church websites and publications. If you are listed and would like your name removed, please [open an issue](https://github.com/notoriouslab/trad-zh-search/issues) and we will address it promptly.

---

## API Reference

| Function | Description |
|----------|-------------|
| `tokenize(text, dictionary?, max_chars?)` | Segment + bigram, returns TokenResult |
| `tokenize_batch(texts, dictionary?, batch_size?)` | Batch version |
| `load_dictionary(name)` | Load a built-in dictionary |
| `load_dictionary_file(path)` | Load a YAML dictionary file |
| `merge_dictionaries(*dicts)` | Merge multiple dictionaries |
| `save_dictionary(dictionary, path)` | Save dictionary to YAML (atomic write) |
| `build_dictionary(texts, min_freq?)` | NER auto-extraction (requires CKIP) |
| `to_meilisearch(fields, original?)` | TokenResult → Meilisearch document |
| `to_meilisearch_batch(fields_list, originals?)` | Batch version |
| `to_meilisearch_synonyms(dictionary)` | Synonyms → Meilisearch bidirectional format |

See each function's docstring for detailed parameter documentation.

---

## Roadmap

v0.1 focuses on core tokenization + bigram + dictionary system. Here's what's planned but not yet built:

### More Search Engine Adapters

| Adapter | Status | Notes |
|---------|--------|-------|
| Meilisearch | v0.1 done | Multi-field format + synonym conversion |
| Elasticsearch / OpenSearch | Planned | Custom analyzer + mapping generation |
| SQLite FTS5 | Planned | Trigram tokenizer + custom tokenize function |
| Orama | Planned | Browser-side full-text search for PWA / offline |
| Typesense | Considering | Another popular open-source search engine |

### Advanced Text Processing

| Feature | Status | Notes |
|---------|--------|-------|
| Entity Resolver (alias expansion) | Planned | Search "周牧師" → auto-expand to "周神助 OR 周巽正" |
| Synonym Expander | Planned | Search "宣教" → auto-expand to "宣教 OR 差傳 OR 宣植" |
| Simplified → Traditional normalization | Considering | Auto-convert Simplified input via opencc s2twp |
| Stop word filtering | Considering | Pluggable stop word lists |

### Tools & Integrations

| Feature | Status | Notes |
|---------|--------|-------|
| CLI tool | Planned | `trad-zh-search tokenize "your text"` |
| More domain dictionaries | Contributions welcome | Legal, medical, education... |
| Dictionary quality report | Considering | Coverage, conflicts, redundancy analysis |

Have ideas or needs? [Open an issue](https://github.com/notoriouslab/trad-zh-search/issues) to discuss.

---

## Contributing

Contributions welcome — domain dictionaries, bug reports, or PRs. See [CONTRIBUTING.md](CONTRIBUTING.md).

---

## License

MIT
