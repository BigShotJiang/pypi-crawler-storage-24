"""llmpm — LLM Package Manager."""

__version__ = "3.0.5"
__author__ = "llmpm contributors"
