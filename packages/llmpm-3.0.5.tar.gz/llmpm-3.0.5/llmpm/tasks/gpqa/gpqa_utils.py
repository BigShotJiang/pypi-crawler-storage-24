def doc_to_target(doc):
    """Return the 0-based index of the correct answer in the choices list."""
    choices = doc["choices"]
    answer = doc["answer"]
    try:
        return choices.index(answer)
    except ValueError:
        return 0
