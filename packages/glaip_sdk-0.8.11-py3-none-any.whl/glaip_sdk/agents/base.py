"""Agent class for GL AIP platform.

This module provides the Agent class that serves as the foundation
for defining agents in glaip-sdk. The Agent class supports both:
- Direct instantiation for simple agents
- Subclassing for complex, reusable agent definitions

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)

Example - Direct Instantiation:
    >>> from glaip_sdk.agents import Agent
    >>>
    >>> agent = Agent(
    ...     name="hello_agent",
    ...     instruction="You are a helpful assistant.",
    ... )
    >>> agent.deploy()
    >>> result = agent.run("Hello!")

Example - Subclassing:
    >>> from glaip_sdk.agents import Agent
    >>>
    >>> class WeatherAgent(Agent):
    ...     @property
    ...     def name(self) -> str:
    ...         return "weather_agent"
    ...
    ...     @property
    ...     def instruction(self) -> str:
    ...         return "You are a helpful weather assistant."
    ...
    ...     @property
    ...     def tools(self) -> list:
    ...         return [WeatherAPITool, "web_search"]
    >>>
    >>> # Deploy and run the agent
    >>> agent = WeatherAgent()
    >>> agent.deploy()
    >>> result = agent.run("What's the weather?")
"""

from __future__ import annotations

import importlib
import inspect
import logging
import warnings
from collections.abc import AsyncGenerator
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from glaip_sdk.agents.types import SkillsInput
from glaip_sdk.transcript._constants import (
    _ASYNC_EXPORT_NOT_SUPPORTED_MSG,
    _EXPORT_DIR_REQUIRES_EXPORT_MSG,
)
from glaip_sdk.exceptions import ValidationError
from glaip_sdk.registry import get_agent_registry, get_mcp_registry, get_tool_registry
from glaip_sdk.utils.resource_refs import is_uuid

if TYPE_CHECKING:
    from glaip_sdk.client.schedules import AgentScheduleManager
    from glaip_sdk.guardrails import GuardrailManager
    from glaip_sdk.models import AgentResponse, Model
    from glaip_sdk.models.agent_runs import AgentRunResult
    from glaip_sdk.models.filesystem import FilesystemConfig
    from glaip_sdk.ptc import PTC
    from glaip_sdk.registry import AgentRegistry, MCPRegistry, ToolRegistry

# Import model validation utility
from glaip_sdk.models._validation import _validate_model
from glaip_sdk.models.filesystem import FilesystemConfig

logger = logging.getLogger(__name__)

_AGENT_NOT_DEPLOYED_MSG = "Agent must be deployed before running. Call deploy() first."
_CLIENT_NOT_AVAILABLE_MSG = "Client not available. Agent may not have been deployed properly."
_FILESYSTEM_UNSET = object()


class Agent:
    """Agent class for GL AIP platform.

    Supports both direct instantiation and subclassing.
    The deploy() method updates the agent in-place, so you can use the
    same instance for deployment and running.

    Direct instantiation (simple):
        >>> agent = Agent(
        ...     name="my_agent",
        ...     instruction="You are helpful.",
        ...     tools=["web_search"],
        ... )
        >>> agent.deploy()
        >>> result = agent.run("Hello!")

    Subclassing (complex):
        >>> class MyAgent(Agent):
        ...     @property
        ...     def name(self) -> str:
        ...         return "my_agent"
        ...
        ...     @property
        ...     def instruction(self) -> str:
        ...         return self.load_instruction_from_file("instructions.md")
        ...
        >>> agent = MyAgent()
        >>> agent.deploy()
        >>> result = agent.run("Hello!")

    Properties (override in subclass OR pass to __init__):
        - name: Agent name on the AIP platform (required)
        - instruction: Agent instruction text (required)
        - description: Agent description (default: "")
        - tools: List of tools (default: [])
        - model: Optional model override (default: None)
        - agents: List of sub-agents (default: [])
        - mcps: List of MCPs (default: [])
        - skills: Optional list of skills for local execution (default: None)
        - timeout: Timeout in seconds (default: 300)
        - metadata: Optional metadata dict (default: None)
        - framework: Agent framework (default: "langchain")
        - version: Agent version (default: "1.0.0")
        - agent_type: Agent type (default: "config")
        - agent_config: Agent execution config (default: None)
        - tool_configs: Per-tool config overrides (default: None)
        - mcp_configs: Per-MCP config overrides (default: None)
        - a2a_profile: A2A profile config (default: None)

    Instance attributes (set after deployment or from_response):
        - id: The agent's unique ID on the platform
        - _client: Client reference for run/update/delete operations
    """

    # Sentinel value to detect unset optional params
    _UNSET = object()

    def __init__(
        self,
        name: str | None = None,
        instruction: str | None = None,
        *,
        id: str | None = None,  # noqa: A002 - Allow shadowing builtin for API compat
        description: str | None = _UNSET,  # type: ignore[assignment]
        tools: list | None = None,
        agents: list | None = None,
        mcps: list | None = None,
        skills: SkillsInput = None,
        model: str | Model | None = _UNSET,  # type: ignore[assignment]
        filesystem: bool | FilesystemConfig | object = _FILESYSTEM_UNSET,
        guardrail: GuardrailManager | None = None,
        ptc: PTC | None = None,
        _client: Any = None,
        **kwargs: Any,
    ) -> None:
        """Initialize an Agent.

        For direct instantiation, name and instruction are required.
        For subclassing, override the properties instead.

        Args:
            name: Agent name (required for direct instantiation).
            instruction: Agent instruction (required for direct instantiation).
            id: Agent ID (set after deployment or when created from API response).
            description: Agent description.
            tools: List of tools (Tool classes, SDK Tool objects, or strings).
            agents: List of sub-agents (Agent classes, instances, or strings).
            mcps: List of MCPs.
            skills: Optional skill input for local execution.
            model: Model identifier or Model configuration object.
            filesystem: Filesystem setting for local runs. Accepts bool or
                FilesystemConfig. Defaults to True when not explicitly provided.
            guardrail: The guardrail manager for content safety.
            ptc: PTC configuration for local and remote runs (sandbox code execution).
            _client: Internal client reference (set automatically).

            **kwargs: Additional configuration parameters:
                - timeout: Execution timeout in seconds.
                - metadata: Optional metadata dictionary.
                - framework: Agent framework identifier.
                - version: Agent version string.
                - agent_type: Agent type identifier.
                - agent_config: Agent execution configuration.
                - tool_configs: Per-tool configuration overrides.
                - mcp_configs: Per-MCP configuration overrides.
                - a2a_profile: A2A profile configuration.
                - ptc: PTC configuration.
        """
        # Instance attributes for deployed agents
        self._id = id
        self._client = _client
        self._created_at: str | None = None
        self._updated_at: str | None = None

        # Store values (None/UNSET means "use property default or override")
        self._name = name
        self._instruction = instruction
        self._description = description
        self._tools = tools
        self._agents = agents
        self._mcps = mcps
        self._skills = skills
        self._model = self._validate_and_set_model(model)
        self._guardrail = guardrail
        self._filesystem = filesystem
        self._ptc = ptc
        self._language_model_id: str | None = None
        # Extract parameters from kwargs with _UNSET defaults
        self._timeout = kwargs.pop("timeout", Agent._UNSET)  # type: ignore[assignment]
        self._metadata = kwargs.pop("metadata", Agent._UNSET)  # type: ignore[assignment]
        self._framework = kwargs.pop("framework", Agent._UNSET)  # type: ignore[assignment]
        self._version = kwargs.pop("version", Agent._UNSET)  # type: ignore[assignment]
        self._agent_type = kwargs.pop("agent_type", Agent._UNSET)  # type: ignore[assignment]

        # Handle 'type' as a legacy alias for 'agent_type'
        legacy_type = kwargs.pop("type", Agent._UNSET)
        if legacy_type is not Agent._UNSET:
            warnings.warn(
                "The 'type' parameter is deprecated and will be removed in a future version. Use 'agent_type' instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            if self._agent_type is Agent._UNSET:
                self._agent_type = legacy_type

        self._agent_config = kwargs.pop("agent_config", Agent._UNSET)  # type: ignore[assignment]
        self._tool_configs = kwargs.pop("tool_configs", Agent._UNSET)  # type: ignore[assignment]
        mcp_configs = kwargs.pop("mcp_configs", Agent._UNSET)
        if mcp_configs is not Agent._UNSET and isinstance(mcp_configs, dict):
            self._mcp_configs = self._normalize_mcp_configs(mcp_configs)
        else:
            self._mcp_configs = mcp_configs  # type: ignore[assignment]
        self._a2a_profile = kwargs.pop("a2a_profile", Agent._UNSET)  # type: ignore[assignment]

        # Warn about unexpected kwargs
        if kwargs:
            warnings.warn(
                f"Unexpected keyword arguments: {list(kwargs.keys())}. These will be ignored.",
                UserWarning,
                stacklevel=2,
            )

    def _validate_and_set_model(self, model: str | Any) -> str | Any:
        """Validate and normalize model parameter.

        Supports both string model identifiers and Model objects:
        - String: Simple model identifier (e.g., "openai/gpt-4o" or OpenAI.GPT_4O)
        - Model: Model object with credentials/hyperparameters for local execution

        Args:
            model: Model identifier (string) or Model object.

        Returns:
            Validated model (string or Model object).
        """
        if model is None or model is Agent._UNSET:
            return model

        from glaip_sdk.models import Model  # noqa: PLC0415

        if isinstance(model, str):
            return _validate_model(model)
        elif isinstance(model, Model):
            return model
        return model

    # ─────────────────────────────────────────────────────────────────
    # Properties (override in subclasses OR pass to __init__)
    # ─────────────────────────────────────────────────────────────────

    @property
    def id(self) -> str | None:  # noqa: A003 - Allow shadowing builtin for API compat
        """Agent ID on the platform.

        This is set after deployment or when created from an API response.

        Returns:
            The unique ID or None if not deployed yet.
        """
        return self._id

    @id.setter
    def id(self, value: str | None) -> None:  # noqa: A003
        """Set the agent ID."""
        self._id = value

    @property
    def created_at(self) -> str | None:
        """Timestamp when the agent was created.

        Returns:
            ISO format timestamp string or None if not deployed.
        """
        return self._created_at

    @created_at.setter
    def created_at(self, value: str | None) -> None:
        """Set the created_at timestamp."""
        self._created_at = value

    @property
    def updated_at(self) -> str | None:
        """Timestamp when the agent was last updated.

        Returns:
            ISO format timestamp string or None if not deployed.
        """
        return self._updated_at

    @updated_at.setter
    def updated_at(self, value: str | None) -> None:
        """Set the updated_at timestamp."""
        self._updated_at = value

    @property
    def name(self) -> str:
        """Agent name on the AIP platform.

        Returns:
            The unique identifier name for this agent.

        Raises:
            ValueError: If name is not provided via __init__ or property override.
        """
        if self._name is None:
            raise ValueError(
                "Agent name is required. Either pass name to __init__() or override the name property in a subclass."
            )
        return self._name

    @property
    def instruction(self) -> str:
        """Agent instruction text.

        Returns:
            The instruction/prompt for the agent.

        Raises:
            ValueError: If instruction is not provided via __init__ or property
                override.
        """
        if self._instruction is None:
            raise ValueError(
                "Agent instruction is required. Either pass instruction to __init__() "
                "or override the instruction property in a subclass."
            )
        return self._instruction

    @property
    def description(self) -> str:
        """Agent description.

        Returns:
            A description of what this agent does. Defaults to empty string.
        """
        if self._description is not self._UNSET:
            return self._description or ""
        return ""

    @property
    def tools(self) -> list:
        """Tools available to this agent.

        Tools can be:
            - Tool class: Custom tool that will be auto-uploaded
            - glaip_sdk.models.Tool: SDK Tool object (uses tool.id)
            - str: Native tool name or ID (resolved by platform)

        Returns:
            List of tool references. Defaults to empty list.
        """
        return self._tools or []

    @property
    def agents(self) -> list:
        """Sub-agents available to this agent.

        Sub-agents can be:
            - Agent class: Will be deployed recursively
            - glaip_sdk.models.Agent: SDK Agent object (uses agent.id)
            - str: Agent name or ID (resolved by platform)

        Returns:
            List of sub-agent references. Defaults to empty list.
        """
        return self._agents or []

    @property
    def timeout(self) -> int:
        """Agent timeout in seconds.

        Returns:
            Timeout value in seconds. Defaults to 300.
        """
        if self._timeout is not self._UNSET and self._timeout is not None:
            return self._timeout
        return 300

    @property
    def metadata(self) -> dict[str, Any] | None:
        """Optional metadata dictionary.

        Returns:
            Metadata dict or None.
        """
        if self._metadata is not self._UNSET:
            return self._metadata
        return None

    @property
    def model(self) -> str | Model | None:
        """Optional model override.

        Returns:
            Model identifier string, Model object, or None to use default.
        """
        if self._model is not self._UNSET:
            return self._model
        return None

    @property
    def language_model_id(self) -> str | None:
        """Language model ID from the API.

        Returns:
            The language model UUID or None.
        """
        return self._language_model_id

    @property
    def framework(self) -> str:
        """Agent framework identifier.

        Returns:
            The framework name. Defaults to "langchain".
        """
        if self._framework is not self._UNSET and self._framework is not None:
            return self._framework
        return "langchain"

    @property
    def version(self) -> str:
        """Agent version string.

        Returns:
            The version identifier. Defaults to "1.0.0".
        """
        if self._version is not self._UNSET and self._version is not None:
            return self._version
        return "1.0.0"

    @property
    def agent_type(self) -> str:
        """Agent type identifier.

        Returns:
            The agent type. Defaults to "config".
        """
        if self._agent_type is not self._UNSET and self._agent_type is not None:
            return self._agent_type
        return "config"

    @property
    def agent_config(self) -> dict[str, Any] | None:
        """Agent configuration for execution settings.

        This is used for agent-level settings like execution_timeout.
        Note: The `timeout` property is a convenience shortcut that
        maps to agent_config.execution_timeout.

        Returns:
            Agent configuration dict or None.
        """
        if self._agent_config is not self._UNSET:
            return self._agent_config
        return None

    @property
    def tool_configs(self) -> dict[Any, dict[str, Any]] | None:
        """Per-tool configuration overrides.

        A mapping of tool references (classes, names, or IDs) to their
        configuration overrides. Supports both class keys and string keys.

        Example:
            >>> @property
            ... def tool_configs(self):
            ...     return {
            ...         MyToolClass: {"api_key": "xxx"},  # Class key
            ...         "other_tool": {"setting": "value"},  # String key
            ...     }

        Returns:
            Tool configurations dict or None.
        """
        if self._tool_configs is not self._UNSET:
            return self._tool_configs
        return None

    @property
    def mcps(self) -> list:
        """MCPs (Model Context Protocols) available to this agent.

        MCPs can be:
            - glaip_sdk.models.MCP: SDK MCP object (uses mcp.id)
            - str: MCP name or ID (resolved by platform)

        Returns:
            List of MCP references. Defaults to empty list.
        """
        return self._mcps or []

    @property
    def skills(self) -> SkillsInput:
        """Skills available to this agent.

        For local execution, this may include ``Skill`` objects and ``SkillConfig``.
        For remote deployment, supported entries are GitHub URLs or skill objects
        with a non-empty ``source`` URL.
        """
        return self._skills

    def _normalize_remote_skills(self) -> list[dict[str, str]] | None:
        """Normalize skill inputs for remote API payloads.

        Delegates to shared normalization logic to avoid duplication.

        Returns:
            List of ``{'url': <github_url>}`` objects, deduplicated in order.
            Returns ``None`` only when skill input is ``None``.
        """
        from glaip_sdk.client.payloads.agent.requests import _normalize_skills  # noqa: PLC0415

        return _normalize_skills(self.skills)

    @staticmethod
    def _warn_filesystem_override_for_skills() -> None:
        """Warn when filesystem is explicitly disabled while skills are set."""
        warnings.warn(
            "Skills require filesystem support. Overriding agent_config['filesystem'] to True for remote deployment.",
            UserWarning,
            stacklevel=3,
        )

    def _apply_remote_skills_to_config(self, config: dict[str, Any], agent_config: dict[str, Any]) -> None:
        """Apply normalized remote skills and enforce filesystem support."""
        normalized_skills = self._normalize_remote_skills()
        if normalized_skills is None:
            return

        config["skills"] = normalized_skills
        if not normalized_skills:
            return

        if agent_config.get("filesystem"):
            return

        if "filesystem" in agent_config and agent_config["filesystem"] is False:
            self._warn_filesystem_override_for_skills()
        agent_config["filesystem"] = True

    @property
    def mcp_configs(self) -> dict[str, Any] | None:
        """Per-MCP configuration overrides.

        A mapping of MCP IDs to their configuration overrides.

        Returns:
            MCP configurations dict or None.
        """
        if self._mcp_configs is not self._UNSET:
            return self._mcp_configs
        return None

    @property
    def guardrail(self) -> GuardrailManager | None:
        """The guardrail manager for content safety."""
        return self._guardrail

    @property
    def ptc(self) -> PTC | None:
        """PTC configuration for local and remote runs (sandbox code execution)."""
        return self._ptc

    @property
    def a2a_profile(self) -> dict[str, Any] | None:
        """A2A (Agent-to-Agent) profile configuration.

        Configuration for agent-to-agent communication capabilities.

        Returns:
            A2A profile dict or None.
        """
        if self._a2a_profile is not self._UNSET:
            return self._a2a_profile
        return None

    @property
    def filesystem(self) -> bool | FilesystemConfig:
        """Filesystem setting used for local runner construction.

        Returns:
            bool | FilesystemConfig: Explicit constructor value when provided,
            otherwise `True` as the default local filesystem behavior.
        """
        if self._filesystem is not _FILESYSTEM_UNSET:
            return cast("bool | FilesystemConfig", self._filesystem)
        return True

    def deploy(self) -> Agent:
        """Deploy this agent (with tools and sub-agents) to GL AIP.

        Performs the following steps:
            1. Upload custom tools (Tool classes) - cached by ToolRegistry
            2. Deploy sub-agents recursively (Agent classes) - cached by AgentRegistry
            3. Resolve tool_configs (requires tools to be in registry first)
            4. Create/update this agent

        Tools and agents are cached globally by their respective registries
        to avoid duplicate uploads across deployments.

        After deployment, this Agent instance is updated in-place with:
            - id: The agent's unique ID on the platform
            - _client: A client reference for run/update/delete operations

        Returns:
            Self with id and _client set, ready for run() calls.

        Raises:
            Exception: If deployment fails due to API error.

        Example:
            >>> agent = Agent(
            ...     name="my_agent",
            ...     instruction="You are helpful.",
            ... )
            >>> agent.deploy()
            >>> print(f"Deployed: {agent.name} (ID: {agent.id})")
            >>> result = agent.run("Hello!")
        """
        logger.info("Deploying agent: %s", self.name)

        # Resolve tools FIRST - this uploads them and populates the registry
        tool_ids = self._resolve_tools(get_tool_registry())

        # Resolve agents
        agent_ids = self._resolve_agents(get_agent_registry())

        # Now build config - tool_configs can be resolved because tools are in registry
        config = self._build_config(get_tool_registry(), get_mcp_registry())
        config["tools"] = tool_ids
        config["agents"] = agent_ids

        from glaip_sdk.utils.client import get_client  # noqa: PLC0415

        client = get_client()
        from glaip_sdk.utils.discovery import find_agent  # noqa: PLC0415

        response = self._create_or_update_agent(config, client, find_agent)

        # Update self with deployed info
        self._id = response.id
        self._client = client

        return self

    def _build_config(self, tool_registry: ToolRegistry, mcp_registry: MCPRegistry) -> dict[str, Any]:
        """Build the base configuration dictionary.

        Args:
            tool_registry: The tool registry for resolving tool configs.
            mcp_registry: The MCP registry for resolving MCPs.

        Returns:
            Dictionary with agent configuration.
        """
        config: dict[str, Any] = {
            "name": self.name,
            "instruction": self.instruction,
            "description": self.description,
            "framework": self.framework,
            "version": self.version,
            "agent_type": self.agent_type,
        }

        self._apply_model_to_config(config)

        # Handle metadata (default to empty dict if None)
        config["metadata"] = self.metadata or {}

        # Handle agent_config (timeout, guardrail, and PTC)
        agent_config = self._build_agent_execution_config()

        self._apply_remote_skills_to_config(config, agent_config)

        config["agent_config"] = agent_config

        # Handle tool_configs - resolve tool names/classes to IDs
        if self.tool_configs:
            config["tool_configs"] = self._resolve_tool_configs(tool_registry)

        # Handle MCPs
        if self.mcps:
            config["mcps"] = self._resolve_mcps(mcp_registry)

        # Handle mcp_configs - normalize keys to MCP IDs
        if self.mcp_configs:
            config["mcp_configs"] = self._resolve_mcp_configs(mcp_registry)

        # Handle a2a_profile
        if self.a2a_profile:
            config["a2a_profile"] = self.a2a_profile

        self._apply_filesystem_to_config(config)

        return config

    def _apply_model_to_config(self, config: dict[str, Any]) -> None:
        """Serialize the model reference into the config dict.

        Args:
            config: The config dict to update in-place.
        """
        if not self.model:
            return
        if isinstance(self.model, str):
            config["model"] = self.model
        else:
            config["model"] = self.model.id

    def _build_agent_execution_config(self) -> dict[str, Any]:
        """Build the agent_config section including timeout and guardrail.

        Returns:
            The agent execution configuration dict.
        """
        raw_config = self.agent_config if self.agent_config is not self._UNSET else {}
        agent_config = dict(raw_config) if raw_config else {}

        if self.timeout and "execution_timeout" not in agent_config:
            agent_config["execution_timeout"] = self.timeout

        if self.guardrail:
            from glaip_sdk.guardrails.serializer import (  # noqa: PLC0415
                serialize_guardrail_manager,
            )

            agent_config["guardrails"] = serialize_guardrail_manager(self.guardrail)

        self._apply_ptc_to_agent_config(agent_config)

        return agent_config

    def _apply_ptc_to_agent_config(self, agent_config: dict[str, Any]) -> None:
        """Apply and validate remote PTC configuration into agent_config."""
        has_agent_config_ptc = "ptc" in agent_config

        if self.ptc is not None and has_agent_config_ptc:
            msg = (
                "Conflicting PTC configuration: both Agent.ptc and agent_config.ptc are set. "
                "Use exactly one PTC source to avoid ambiguous precedence."
            )
            raise ValidationError(msg)

        if self.ptc is not None:
            agent_config["ptc"] = self.ptc.to_dict()

        self._validate_remote_ptc_unsupported_fields(agent_config.get("ptc"))

    def _validate_remote_ptc_unsupported_fields(self, ptc_config: Any) -> None:
        """Reject unsupported remote PTC fields when PTC is enabled."""
        if not isinstance(ptc_config, dict):
            return

        if not ptc_config.get("enabled"):
            return

        if ptc_config.get("ptc_packages") is not None:
            msg = (
                "ptc_packages is not supported for remote deployment when PTC is enabled. "
                "Remove ptc_packages from Agent.ptc or agent_config.ptc, or disable PTC for remote deployment."
            )
            raise ValidationError(msg)

        if ptc_config.get("custom_tools") is not None:
            msg = (
                "custom_tools is not supported for remote deployment when PTC is enabled. "
                "Remove custom_tools from agent_config.ptc for remote deployment."
            )
            raise ValidationError(msg)

    def _apply_filesystem_to_config(self, config: dict[str, Any]) -> None:
        """Serialize the filesystem setting into the config dict.

        Args:
            config: The config dict to update in-place.
        """
        if self._filesystem is _FILESYSTEM_UNSET:
            return
        if isinstance(self._filesystem, FilesystemConfig):
            config["filesystem"] = self._filesystem.model_dump()
        else:
            config["filesystem"] = self._filesystem

    def _resolve_mcps(self, registry: MCPRegistry) -> list[str]:
        """Resolve MCP references to IDs using MCPRegistry.

        Uses the global MCPRegistry to cache MCP objects across deployments.
        The registry handles all MCP types: MCP helpers, strings, dicts,
        and glaip_sdk.models.MCP objects.

        Args:
            registry: The MCP registry.

        Returns:
            List of resolved MCP IDs for the API payload.

        Raises:
            ValueError: If an MCP fails to resolve to a valid ID.
        """
        if not self.mcps:
            return []

        resolved_ids: list[str] = []
        for mcp_ref in self.mcps:
            mcp = registry.resolve(mcp_ref)
            if not mcp.id:
                raise ValueError(f"Failed to resolve ID for MCP: {mcp_ref}")
            resolved_ids.append(mcp.id)
        return resolved_ids

    def _resolve_tools(self, registry: ToolRegistry) -> list[str]:
        """Resolve tool references to IDs using ToolRegistry.

        Uses the global ToolRegistry to cache Tool objects across deployments.
        The registry handles all tool types: Tool classes, LangChain BaseTool,
        glaip_sdk.models.Tool, and string names.

        Args:
            registry: The tool registry.

        Returns:
            List of resolved tool IDs for the API payload.

        Raises:
            ValueError: If a tool fails to resolve to a valid ID.
        """
        if not self.tools:
            return []

        resolved_ids: list[str] = []
        for tool_ref in self.tools:
            tool = registry.resolve(tool_ref)
            if not tool.id:
                raise ValueError(f"Failed to resolve ID for tool: {tool_ref}")
            resolved_ids.append(tool.id)
        return resolved_ids

    def _resolve_tool_configs(self, registry: ToolRegistry) -> dict[str, Any]:
        """Resolve tool_configs keys from tool names/classes to tool IDs.

        Allows tool_configs to be defined with tool names, class names, or
        Tool classes as keys. These are resolved to actual tool IDs using
        the ToolRegistry.

        Supported key formats:
            - Tool class: SyncReportSchedulerTool
            - Tool name string: "sync_report_scheduler"
            - Tool ID (UUID): Passed through unchanged

        Args:
            registry: The tool registry.

        Returns:
            Dict with resolved tool IDs as keys and configs as values.

        Example:
            >>> class MyAgent(Agent):
            ...     @property
            ...     def tool_configs(self):
            ...         return {
            ...             SyncReportSchedulerTool: {"api_key": "xxx"},
            ...             "other_tool": {"setting": "value"},
            ...         }
        """
        if not self.tool_configs:
            return {}

        resolved: dict[str, Any] = {}

        for key, config in self.tool_configs.items():
            # If key is already a UUID-like string, pass through
            if isinstance(key, str) and is_uuid(key):
                resolved[key] = config
                continue

            try:
                # Resolve key (tool name/class) to Tool object, get ID
                tool = registry.resolve(key)
                if not tool.id:
                    raise ValueError(f"Resolved tool has no ID: {key}")
                resolved[tool.id] = config
            except (ValueError, KeyError) as e:
                raise ValueError(f"Failed to resolve tool config key: {key}") from e

        return resolved

    def _resolve_mcp_configs(self, registry: MCPRegistry) -> dict[str, Any]:
        """Resolve mcp_configs keys from MCP names/objects to MCP IDs.

        Allows mcp_configs to be defined with MCP names, MCP objects, or UUIDs
        as keys. Keys are resolved to MCP IDs using the MCPRegistry.

        Supported key formats:
            - MCP object (with id): uses id directly
            - MCP name string: resolved via registry to ID
            - MCP ID (UUID string): passed through unchanged

        Args:
            registry: The MCP registry.

        Returns:
            Dict with resolved MCP IDs as keys and configs as values.
        """
        if not self.mcp_configs:
            return {}

        resolved: dict[str, Any] = {}

        for key, config in self.mcp_configs.items():
            try:
                # If key is already a UUID-like string, pass through
                if isinstance(key, str) and is_uuid(key):
                    resolved_id = key
                else:
                    mcp = registry.resolve(key)
                    if not mcp.id:
                        raise ValueError(f"Resolved MCP has no ID: {key}")
                    resolved_id = mcp.id

                if resolved_id in resolved:
                    raise ValueError(
                        f"Duplicate mcp_configs entries resolve to the same MCP id '{resolved_id}' (key={key!r})"
                    )

                resolved[resolved_id] = config
            except (ValueError, KeyError) as exc:
                raise ValueError(
                    f"Failed to resolve mcp config key {key!r} (type={type(key).__name__}): {exc}"
                ) from exc

        return resolved

    def _normalize_mcp_configs(self, mcp_configs: dict[Any, Any]) -> dict[Any, Any]:
        """Normalize mcp_configs by wrapping misplaced transport keys in 'config'.

        This ensures that flat transport settings (e.g. {'url': '...'}) provided
        by the user are correctly moved into the 'config' block required by the
        Platform, ensuring parity between local and remote execution.

        Args:
            mcp_configs: The raw mcp_configs dictionary.

        Returns:
            Normalized mcp_configs dictionary.
        """
        from glaip_sdk.runner.langgraph import _MCP_TRANSPORT_KEYS  # noqa: PLC0415

        normalized = {}
        for mcp_key, override in mcp_configs.items():
            if not isinstance(override, dict):
                normalized[mcp_key] = override
                continue

            misplaced = {k: v for k, v in override.items() if k in _MCP_TRANSPORT_KEYS}

            if misplaced:
                new_override = override.copy()
                config_block = new_override.get("config", {})
                if not isinstance(config_block, dict):
                    config_block = {}

                config_block.update(misplaced)
                new_override["config"] = config_block

                for k in misplaced:
                    new_override.pop(k, None)

                normalized[mcp_key] = new_override
            else:
                normalized[mcp_key] = override

        return normalized

    def _resolve_agents(self, registry: AgentRegistry) -> list[str]:
        """Resolve sub-agent references using AgentRegistry.

        Uses the global AgentRegistry to cache Agent objects across deployments.
        The registry handles all agent types: Agent classes, instances,
        glaip_sdk.models.Agent, and string names.

        Args:
            registry: The agent registry.

        Returns:
            List of resolved agent IDs for the API payload.

        Raises:
            ValueError: If an agent fails to resolve to a valid ID.
        """
        if not self.agents:
            return []

        resolved_ids: list[str] = []
        for agent_ref in self.agents:
            agent = registry.resolve(agent_ref)
            if not agent.id:
                raise ValueError(f"Failed to resolve ID for agent: {agent_ref}")
            resolved_ids.append(agent.id)
        return resolved_ids

    def _create_or_update_agent(
        self,
        config: dict[str, Any],
        client: Any,
        find_agent_fn: Any,
    ) -> AgentResponse:
        """Create or update the agent on the platform.

        Args:
            config: The agent configuration dictionary.
            client: The API client.
            find_agent_fn: Function to find existing agent by name.

        Returns:
            The created or updated AgentResponse from the API.
        """
        existing = find_agent_fn(self.name)

        if existing:
            logger.info("Updating existing agent: %s", self.name)
            updated = client.update_agent(agent_id=existing.id, **config)
            logger.info("✓ Agent '%s' updated successfully", self.name)
            return updated

        logger.info("Creating new agent: %s", self.name)
        created = client.create_agent(**config)
        logger.info("✓ Agent '%s' created successfully", self.name)
        return created

    @staticmethod
    def load_instruction_from_file(
        path: str,
        base_path: Path | None = None,
        variables: dict[str, str] | None = None,
    ) -> str:
        """Load instruction text from a markdown file.

        Args:
            path: File path (absolute or relative to base_path).
            base_path: Base directory for relative paths. If None, auto-detected
                from the caller's file location.
            variables: Template variables for {{variable}} substitution.

        Returns:
            Loaded instruction text with variables substituted.

        Raises:
            FileNotFoundError: If the instruction file doesn't exist.

        Example:
            >>> instruction = Agent.load_instruction_from_file(
            ...     "instructions/agent.md",
            ...     variables={"agent_name": "Weather Bot"}
            ... )
        """
        file_path = Path(path)

        if not file_path.is_absolute():
            if base_path is None:
                caller_frame = inspect.stack()[1]
                base_path = Path(caller_frame.filename).parent
            file_path = base_path / path

        if not file_path.exists():
            raise FileNotFoundError(f"Instruction file not found: {file_path}")

        content = file_path.read_text(encoding="utf-8")

        if variables:
            for key, value in variables.items():
                content = content.replace(f"{{{{{key}}}}}", value)

        return content

    def to_component(self) -> Any:
        """Convert this Agent into a pipeline-compatible Component.

        The returned AgentComponent wraps this agent instance and allows it
        to be used within a Pipeline (from gllm-pipeline).

        Returns:
            An AgentComponent instance wrapping this agent.
        """
        from glaip_sdk.agents.component import AgentComponent  # noqa: PLC0415

        return AgentComponent(self)

    # =========================================================================
    # API Methods - Available after deploy()
    # =========================================================================

    def model_dump(self, *, exclude_none: bool = False) -> dict[str, Any]:
        """Return a dict representation of the Agent.

        Provides Pydantic-style serialization for backward compatibility.
        This implementation avoids triggering external tool resolution to ensure
        it remains robust even when the environment is not fully configured.

        Args:
            exclude_none: If True, exclude None values from the output.

        Returns:
            Dictionary containing Agent attributes. Note: Mutable fields (dicts, lists)
            are returned as references. Modify with caution or make a deep copy if needed.
        """
        # Map convenience timeout to agent_config if not already present
        agent_config = self.agent_config if self.agent_config is not self._UNSET else {}
        agent_config = dict(agent_config) if agent_config else {}

        if self.timeout and "execution_timeout" not in agent_config:
            agent_config["execution_timeout"] = self.timeout

        # Handle guardrail serialization without full config build
        if self.guardrail:
            try:
                from glaip_sdk.guardrails.serializer import (  # noqa: PLC0415
                    serialize_guardrail_manager,
                )

                agent_config["guardrails"] = serialize_guardrail_manager(self.guardrail)
            except ImportError:
                # Serializer not available (optional dependency); skip guardrail data
                pass

        data = {
            "id": self._id,
            "name": self.name,
            "instruction": self.instruction,
            "description": self.description,
            "agent_type": self.agent_type,
            "type": self.agent_type,  # Legacy key for backward compatibility
            "framework": self.framework,
            "version": self.version,
            "tools": self.tools,
            "agents": self.agents,
            "mcps": self.mcps,
            "skills": self.skills,
            "timeout": self.timeout,
            "metadata": self.metadata,
            "model": self.model,
            "agent_config": agent_config,
            "tool_configs": self.tool_configs,
            "mcp_configs": self.mcp_configs,
            "a2a_profile": self.a2a_profile,
            "guardrail": self.guardrail,
            "created_at": self._created_at,
            "updated_at": self._updated_at,
        }

        # Include filesystem config for remote API support
        filesystem_value = self._filesystem
        if filesystem_value is not _FILESYSTEM_UNSET:
            fs_val: Any = filesystem_value
            if isinstance(fs_val, FilesystemConfig):
                data["filesystem"] = fs_val.model_dump()
            else:
                data["filesystem"] = fs_val

        if exclude_none:
            return {k: v for k, v in data.items() if v is not None}
        return data

    def _set_client(self, client: Any) -> Agent:
        """Set the client for API operations.

        Args:
            client: The Glaip client instance.

        Returns:
            Self for method chaining.
        """
        self._client = client
        return self

    @property
    def schedule(self) -> AgentScheduleManager:
        """Get the schedule manager for this agent.

        Provides a convenient interface for managing schedules scoped to this agent.

        Returns:
            AgentScheduleManager for schedule operations

        Raises:
            ValueError: If agent is not deployed
            RuntimeError: If agent is not bound to a client

        Example:
            >>> agent = client.get_agent_by_id("agent-id")
            >>> schedules = agent.schedule.list()
            >>> new_schedule = agent.schedule.create(
            ...     input="Daily task",
            ...     schedule="0 9 * * 1-5"
            ... )
        """
        if not self.id:
            raise ValueError(_AGENT_NOT_DEPLOYED_MSG)
        if not self._client:
            raise RuntimeError(_CLIENT_NOT_AVAILABLE_MSG)

        from glaip_sdk.client.schedules import AgentScheduleManager  # noqa: PLC0415

        return AgentScheduleManager(self, self._client.schedules)

    def _prepare_run_kwargs(
        self,
        message: str,
        verbose: bool,
        runtime_config: dict[str, Any] | None,
        **kwargs: Any,
    ) -> tuple[Any, dict[str, Any]]:
        """Prepare common arguments for run/arun methods.

        Args:
            message: The message to send to the agent.
            verbose: If True, print streaming output to console.
            runtime_config: Optional runtime configuration.
            **kwargs: Additional arguments to pass to the run API.

        Returns:
            Tuple of (agent_client, call_kwargs).

        Raises:
            ValueError: If the agent hasn't been deployed yet.
            RuntimeError: If client is not available.
        """
        if not self._client:
            raise RuntimeError(_CLIENT_NOT_AVAILABLE_MSG)

        agent_client = getattr(self._client, "agents", self._client)

        call_kwargs: dict[str, Any] = {
            "agent_id": self.id,
            "message": message,
            "verbose": verbose,
        }

        # Note: agent_name is NOT passed here because tests expect exact mock calls.
        # AgentRunResult will use the agent_id as fallback for agent_name.

        # Only add model if it has a meaningful value
        # This maintains backward compatibility with existing tests
        if self.model is not None:
            call_kwargs["model"] = self.model

        if runtime_config is not None:
            from glaip_sdk.utils.runtime_config import (  # noqa: PLC0415
                normalize_runtime_config_keys,
            )

            processed_config: dict[str, Any] = {}
            for key, value in runtime_config.items():
                if isinstance(value, FilesystemConfig):
                    processed_config[key] = value.model_dump()
                else:
                    processed_config[key] = value

            call_kwargs["runtime_config"] = normalize_runtime_config_keys(
                processed_config,
                tool_registry=get_tool_registry(),
                mcp_registry=get_mcp_registry(),
                agent_registry=get_agent_registry(),
            )

        call_kwargs.update(kwargs)

        memory_user_id = call_kwargs.get("memory_user_id")
        if memory_user_id and not call_kwargs.get("user_id"):
            call_kwargs["user_id"] = memory_user_id
        return agent_client, call_kwargs

    def _get_local_runner_or_raise(self) -> Any:
        """Get the local runner if available, otherwise raise ValueError.

        Returns:
            The default local runner instance.

        Raises:
            ValueError: If local runtime is not available.
        """
        from glaip_sdk.runner import get_default_runner  # noqa: PLC0415
        from glaip_sdk.runner.deps import (  # noqa: PLC0415
            check_local_runtime_available,
            get_local_runtime_missing_message,
        )

        if check_local_runtime_available():
            return get_default_runner()

        # If agent is not deployed, it *must* use local runtime
        if not self.id:
            raise ValueError(f"{_AGENT_NOT_DEPLOYED_MSG}\n\n{get_local_runtime_missing_message()}")

        # If agent IS deployed but local execution was forced (local=True)
        raise ValueError(
            f"Local execution override was requested, but local runtime is missing.\n\n"
            f"{get_local_runtime_missing_message()}"
        )

    def _prepare_local_runner_kwargs(
        self,
        message: str,
        verbose: bool,
        runtime_config: dict[str, Any] | None,
        chat_history: list[dict[str, str]] | None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Prepare kwargs for local runner execution.

        Args:
            message: The message to send to the agent.
            verbose: If True, print streaming output to console.
            runtime_config: Optional runtime configuration.
            chat_history: Optional list of prior conversation messages.
            **kwargs: Additional arguments.

        Returns:
            Dictionary of prepared kwargs for runner.run() or runner.arun().
        """
        return {
            "agent": self,
            "message": message,
            "verbose": verbose,
            "runtime_config": runtime_config,
            "chat_history": chat_history,
            **kwargs,
        }

    def run(
        self,
        message: str,
        verbose: bool = False,
        local: bool = False,
        runtime_config: dict[str, Any] | None = None,
        chat_history: list[dict[str, str]] | None = None,
        trace: bool = False,
        export: bool = False,
        export_dir: str | Path | None = None,
        **kwargs: Any,
    ) -> str | AgentRunResult:
        """Run the agent synchronously with a message.

        Supports two execution modes:
        - **Server-backed**: When the agent is deployed (has an ID), execution
          happens via the AIP backend server.
        - **Local**: When the agent is not deployed and glaip-sdk[local] is installed,
          execution happens locally via aip-agents (no server required).

        You can force local execution for a deployed agent by passing `local=True`.

        Args:
            message: The message to send to the agent.
            verbose: If True, print streaming output to console. Defaults to False.
            local: If True, force local execution even if the agent is deployed.
                Defaults to False.
            runtime_config: Optional runtime configuration for tools, MCPs, and agents.
                Keys can be SDK objects, UUIDs, or names. Example:
                {
                    "tool_configs": {"tool-id": {"param": "value"}},
                    "mcp_configs": {"mcp-id": {"setting": "on"}},
                    "agent_config": {"planning": True},
                }
                Defaults to None.
            chat_history: Optional list of prior conversation messages for context.
                Each message is a dict with "role" and "content" keys.
                Defaults to None.
            trace: If True, return an AgentRunResult object with detailed
                execution information including token usage, steps, and events.
                Defaults to False for backward compatibility.
            export: If True, write a transcript JSONL file to disk. Defaults to False.
                Not supported for async runs (arun).
            export_dir: Directory for the export file. Requires export=True.
                Defaults to cwd()/aip-agent-runs if export=True and export_dir is None.
            **kwargs: Additional arguments to pass to the run API.

        Returns:
            The agent's response as a string, or an AgentRunResult if trace=True.

        Raises:
            ValueError: If the agent is not deployed and local runtime is not available.
            RuntimeError: If server-backed execution fails due to client issues.
        """
        if not export and export_dir is not None:
            raise ValueError(_EXPORT_DIR_REQUIRES_EXPORT_MSG)

        if export:
            kwargs["export"] = True
        if export_dir is not None:
            kwargs["export_dir"] = export_dir

        # Backend routing: deployed agents use server, undeployed use local (if available)
        if self.id and not local:
            # Server-backed execution path (agent is deployed)
            effective_runtime_config = runtime_config or kwargs.get("runtime_config")
            agent_client, call_kwargs = self._prepare_run_kwargs(
                message,
                verbose,
                effective_runtime_config,
                **kwargs,
            )
            if chat_history is not None:
                call_kwargs["chat_history"] = chat_history
            if trace:
                call_kwargs["trace"] = trace
            return agent_client.run_agent(**call_kwargs)

        # Local execution path (agent is not deployed OR local=True)
        runner = self._get_local_runner_or_raise()
        local_kwargs = self._prepare_local_runner_kwargs(message, verbose, runtime_config, chat_history, **kwargs)
        local_kwargs["trace"] = trace
        return runner.run(**local_kwargs)

    async def arun(
        self,
        message: str,
        verbose: bool = False,
        local: bool = False,
        runtime_config: dict[str, Any] | None = None,
        chat_history: list[dict[str, str]] | None = None,
        export: bool = False,
        export_dir: str | Path | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[dict, None]:
        """Run the agent asynchronously with streaming output.

        Supports two execution modes:
        - **Server-backed**: When the agent is deployed (has an ID), execution
          happens via the AIP backend server with streaming.
        - **Local**: When the agent is not deployed and glaip-sdk[local] is installed,
          execution happens locally via aip-agents (no server required).

        You can force local execution for a deployed agent by passing `local=True`.

        Args:
            message: The message to send to the agent.
            verbose: If True, print streaming output to console. Defaults to False.
            local: If True, force local execution even if the agent is deployed.
                Defaults to False.
            runtime_config: Optional runtime configuration for tools, MCPs, and agents.
                Keys can be SDK objects, UUIDs, or names. Example:
                {
                    "tool_configs": {"tool-id": {"param": "value"}},
                    "mcp_configs": {"mcp-id": {"setting": "on"}},
                    "agent_config": {"planning": True},
                }
                Defaults to None.
            chat_history: Optional list of prior conversation messages for context.
                Each message is a dict with "role" and "content" keys.
                Defaults to None.
            export: Not supported for async runs. Will raise ValueError if True.
            export_dir: Not supported for async runs. Will raise ValueError if provided.
            **kwargs: Additional arguments to pass to the run API.

        Yields:
            Streaming response chunks from the agent.

        Raises:
            ValueError: If the agent is not deployed and local runtime is not available.
            RuntimeError: If server-backed execution fails due to client issues.
        """
        if export or export_dir is not None:
            raise ValueError(_ASYNC_EXPORT_NOT_SUPPORTED_MSG)

        # Backend routing: deployed agents use server, undeployed use local (if available)
        if self.id and not local:
            # Server-backed execution path (agent is deployed)
            effective_runtime_config = runtime_config or kwargs.get("runtime_config")
            agent_client, call_kwargs = self._prepare_run_kwargs(
                message,
                verbose,
                effective_runtime_config,
                **kwargs,
            )
            if chat_history is not None:
                call_kwargs["chat_history"] = chat_history

            async for chunk in agent_client.arun_agent(**call_kwargs):
                yield chunk
            return

        # Local execution path (agent is not deployed OR local=True)
        runner = self._get_local_runner_or_raise()
        local_kwargs = self._prepare_local_runner_kwargs(message, verbose, runtime_config, chat_history, **kwargs)
        result = await runner.arun(**local_kwargs)
        # Yield a final_response event for consistency with server-backed execution
        # Include event_type for A2A event shape parity
        yield {
            "event_type": "final_response",
            "metadata": {"kind": "final_response"},
            "content": result,
            "is_final": True,
        }

    def update(self, **kwargs: Any) -> Agent:
        """Update the deployed agent with new configuration.

        Args:
            **kwargs: Agent properties to update (name, instruction, etc.).

        Returns:
            Self with updated properties.

        Raises:
            ValueError: If the agent hasn't been deployed yet.
            RuntimeError: If client is not available.
        """
        if not self.id:
            raise ValueError(_AGENT_NOT_DEPLOYED_MSG)
        if not self._client:
            raise RuntimeError(_CLIENT_NOT_AVAILABLE_MSG)

        # _client can be either main Client or AgentClient
        agent_client = getattr(self._client, "agents", self._client)
        response = agent_client.update_agent(agent_id=self.id, **kwargs)

        # Update local properties from response (read-only props via private attrs)
        name = getattr(response, "name", None)
        if name:
            self._name = name

        instruction = getattr(response, "instruction", None)
        if instruction:
            self._instruction = instruction

        # Populate remaining fields like description, metadata, updated_at, etc.
        type(self)._populate_from_response(self, cast("AgentResponse", response))

        return self

    def delete(self) -> None:
        """Delete the deployed agent.

        Raises:
            ValueError: If the agent hasn't been deployed yet.
            RuntimeError: If client is not available.
        """
        if not self.id:
            raise ValueError(_AGENT_NOT_DEPLOYED_MSG)
        if not self._client:
            raise RuntimeError(_CLIENT_NOT_AVAILABLE_MSG)

        # _client can be either main Client or AgentClient
        agent_client = getattr(self._client, "agents", self._client)
        agent_client.delete_agent(self.id)
        self.id = None
        self._client = None

    def create_audio_session(
        self,
        config: Any | None = None,
        *,
        implementation: str | Any | None = None,
        **session_kwargs: Any,
    ) -> Any:
        """Create a new audio session for this agent.

        Args:
            config: AudioSessionConfig or dict containing audio settings.
            implementation: Optional registered implementation name (for
                example ``"livekit"``) or callable session factory/class.
            **session_kwargs: Extra keyword arguments forwarded to the selected
                session implementation.

        Returns:
            An audio session instance from the selected implementation.
        """
        audio_interface = importlib.import_module("glaip_sdk.audio_interface")
        return audio_interface.create_audio_session(
            config=config,
            agent=self,
            implementation=implementation,
            **session_kwargs,
        )

    @classmethod
    def _populate_from_response(cls, agent: Agent, response: AgentResponse) -> None:
        """Populate agent fields from API response."""
        # Field mappings: (response_attr, agent_attr, require_truthy)
        field_mappings = [
            ("description", "_description", True),
            ("model", "_model", True),
            ("type", "_agent_type", True),
            ("framework", "_framework", True),
            ("version", "_version", True),
            ("timeout", "_timeout", True),
            ("metadata", "_metadata", True),
            ("agent_config", "_agent_config", True),
            ("tool_configs", "_tool_configs", True),
            ("mcp_configs", "_mcp_configs", True),
            ("a2a_profile", "_a2a_profile", True),
            ("language_model_id", "_language_model_id", True),
            ("created_at", "_created_at", False),
            ("updated_at", "_updated_at", False),
        ]

        for resp_attr, agent_attr, require_truthy in field_mappings:
            value = getattr(response, resp_attr, None)
            if require_truthy:
                if value:
                    setattr(agent, agent_attr, value)
            else:
                if value is not None:
                    setattr(agent, agent_attr, value)

        # Copy relationship refs as-is (preserve full objects for serialization)
        # Registry resolution handles extracting IDs during deployment
        tools_val = getattr(response, "tools", None)
        if tools_val:
            agent._tools = tools_val

        agents_val = getattr(response, "agents", None)
        if agents_val:
            agent._agents = agents_val

        mcps_val = getattr(response, "mcps", None)
        if mcps_val:
            agent._mcps = mcps_val

        skills_val = getattr(response, "skills", None)
        if skills_val is not None:
            agent._skills = skills_val

    @classmethod
    def from_response(
        cls,
        response: AgentResponse,
        client: Any = None,
    ) -> Agent:
        """Create an Agent instance from an API response.

        This allows you to work with agents retrieved from the API
        as full Agent instances with all methods available.

        Args:
            response: The AgentResponse from an API call.
            client: The Glaip client instance for API operations.

        Returns:
            An Agent instance initialized from the response.

        Example:
            >>> response = client.agents.get("agent-123")
            >>> agent = Agent.from_response(response, client)
            >>> result = agent.run("Hello!")
        """
        agent = cls(
            name=response.name,
            instruction=response.instruction or "",
            id=response.id,
        )

        cls._populate_from_response(agent, response)

        if client:
            agent._set_client(client)

        return agent
