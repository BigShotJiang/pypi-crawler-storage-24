"""Internal SDK transcript export helpers.

This module intentionally writes a single manifestless JSONL artifact and does
not use transcript cache fallback behavior.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from glaip_sdk.cli.transcript import cache as transcript_cache
from glaip_sdk.transcript._constants import DEFAULT_EXPORT_DIRNAME, _EXPORT_DIR_REQUIRES_EXPORT_MSG
from glaip_sdk.transcript import _records
from glaip_sdk.utils.datetime_helpers import coerce_datetime


@dataclass(frozen=True)
class ExportOptions:
    """Resolved SDK transcript export controls."""

    enabled: bool = False
    directory: Path | None = None


def resolve_export_options(export: bool, export_dir: str | Path | None) -> ExportOptions:
    """Resolve and validate SDK export controls.

    Raises:
        ValueError: if export_dir is provided while export is disabled.
        ValueError: if resolved destination already exists as a file.
    """
    if not export:
        if export_dir is not None:
            raise ValueError(_EXPORT_DIR_REQUIRES_EXPORT_MSG)
        return ExportOptions(enabled=False, directory=None)

    if export_dir is None:
        destination = Path.cwd() / DEFAULT_EXPORT_DIRNAME
    else:
        candidate = Path(export_dir).expanduser()
        destination = candidate if candidate.is_absolute() else Path.cwd() / candidate

    if destination.exists() and destination.is_file():
        raise ValueError(f"Export destination must be a directory: {destination}")

    return ExportOptions(enabled=True, directory=destination)


def write_sdk_transcript(
    *,
    events: list[dict[str, Any]],
    created_at: datetime,
    final_output: str,
    renderer_output: str,
    agent_id: str | None,
    agent_name: str | None,
    model: str | None,
    server_run_id: str | None,
    started_at: float | None,
    finished_at: float | None,
    meta: dict[str, Any],
    destination_dir: Path,
    source: Literal["sdk_local", "sdk_remote"],
) -> Path:
    """Write one SDK transcript JSONL file and return the path."""
    if destination_dir.exists() and destination_dir.is_file():
        raise ValueError(f"Export destination must be a directory: {destination_dir}")

    destination_dir.mkdir(parents=True, exist_ok=True)

    created = created_at if created_at.tzinfo else created_at.replace(tzinfo=UTC)

    payload = transcript_cache.TranscriptPayload(
        events=events,
        default_output=renderer_output,
        final_output=final_output,
        agent_id=agent_id,
        agent_name=agent_name,
        model=model,
        server_run_id=server_run_id,
        started_at=started_at,
        finished_at=finished_at,
        created_at=created,
        source=source,
        meta=meta,
        run_id=transcript_cache.generate_run_id(),
    )

    filename = transcript_cache.suggest_filename(
        {
            "run_id": payload.run_id,
            "started_at": _normalise_filename_timestamp(payload.started_at),
            "created_at": payload.created_at.isoformat(),
        }
    )

    target_path = destination_dir / filename
    records: list[dict[str, Any]] = [_records.build_meta_record(payload)]
    records.extend(_records.wrap_event_record(event) for event in payload.events)

    with target_path.open("w", encoding="utf-8") as fh:
        for index, record in enumerate(records):
            if index > 0:
                fh.write("\n\n")
            fh.write(
                json.dumps(
                    record,
                    ensure_ascii=False,
                    indent=2,
                    default=_records.json_default,
                )
            )
        fh.write("\n")

    return target_path


def _normalise_filename_timestamp(value: Any) -> str | None:
    """Normalize timestamp input before suggest_filename()."""
    dt = coerce_datetime(value)
    if dt is None or dt.year < 2000:
        return None
    return dt.isoformat().replace("+00:00", "Z")
