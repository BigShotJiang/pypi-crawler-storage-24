"""Internal transcript package for SDK implementation details."""
