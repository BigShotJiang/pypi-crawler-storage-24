"""Internal helpers for canonical transcript JSONL record shaping.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def json_default(value: Any) -> Any:
    """Ensure non-serializable values degrade to readable strings."""
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, Path):
        return str(value)
    return repr(value)


def build_meta_record(payload: Any) -> dict[str, Any]:
    """Return canonical transcript metadata record from payload-like objects."""
    return {
        "type": "meta",
        "run_id": payload.run_id,
        "agent_id": payload.agent_id,
        "agent_name": payload.agent_name,
        "model": payload.model,
        "created_at": payload.created_at.isoformat(),
        "default_output": payload.default_output,
        "final_output": payload.final_output,
        "server_run_id": payload.server_run_id,
        "started_at": payload.started_at,
        "finished_at": payload.finished_at,
        "meta": payload.meta,
        "source": payload.source,
    }


def wrap_event_record(event: dict[str, Any]) -> dict[str, Any]:
    """Return canonical wrapped event record."""
    return {"type": "event", "event": event}
