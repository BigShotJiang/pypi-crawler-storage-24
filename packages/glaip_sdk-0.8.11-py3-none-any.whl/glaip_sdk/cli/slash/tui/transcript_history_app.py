"""Textual UI for the /transcripts command.

Shows local transcript history with mixed account/agent rows and a detail pane.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from glaip_sdk.cli.account_store import get_account_store
from glaip_sdk.cli.core.output import parse_json_line
from glaip_sdk.cli.slash.tui.background_tasks import cancel_worker_group
from glaip_sdk.cli.slash.tui.clipboard import ClipboardAdapter
from glaip_sdk.cli.slash.tui.context import TUIContext
from glaip_sdk.cli.slash.tui.history_layout import (
    COMPACT_STARTED_COLUMN_WIDTH,
    HISTORY_LEFT_PANE_PERCENT,
    HISTORY_RIGHT_PANE_PERCENT,
    STATUS_COLUMN_WIDTH,
)
from glaip_sdk.cli.slash.tui.screenshot_capture import (
    TranscriptScreenshotCaptureMixin,
)
from glaip_sdk.cli.slash.tui.styles import load_tcss_template
from glaip_sdk.cli.slash.tui.time_format import format_compact_table_timestamp, format_utc_absolute_timestamp
from glaip_sdk.cli.transcript.history import HistoryEntry, HistorySnapshot

logger = logging.getLogger(__name__)

if TYPE_CHECKING:  # pragma: no cover
    from textual.app import App, ComposeResult, ScreenStackError
    from textual.binding import Binding
    from textual.containers import Container, Horizontal, ScrollableContainer
    from textual.coordinate import Coordinate
    from textual.widgets import DataTable, Footer, Input, RichLog, Static, TextArea
else:
    try:  # pragma: no cover
        from textual.app import App, ComposeResult, ScreenStackError
        from textual.binding import Binding
        from textual.containers import Container, Horizontal, ScrollableContainer
        from textual.coordinate import Coordinate
        from textual.widgets import DataTable, Footer, Input, RichLog, Static, TextArea
    except Exception:  # pragma: no cover
        App = None  # type: ignore[assignment]
        ComposeResult = None  # type: ignore[assignment]
        ScreenStackError = Exception  # type: ignore[assignment]
        Binding = None  # type: ignore[assignment]
        Container = None  # type: ignore[assignment]
        Horizontal = None  # type: ignore[assignment]
        ScrollableContainer = None  # type: ignore[assignment]
        DataTable = None  # type: ignore[assignment]
        Footer = None  # type: ignore[assignment]
        Input = None  # type: ignore[assignment]
        RichLog = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]
        TextArea = None  # type: ignore[assignment]
        Coordinate = None  # type: ignore[assignment]


TEXTUAL_SUPPORTED = all(
    dependency is not None
    for dependency in (
        App,
        Binding,
        Container,
        Horizontal,
        ScrollableContainer,
        DataTable,
        Footer,
        Input,
        RichLog,
        Static,
        TextArea,
    )
)

TABLE_ID = "transcripts-history-table"
FILTER_ID = "transcripts-history-filter"
AGENT_COL_WIDTH = 40
AGENT_TRIM_LIMIT = 40
SELECT_RUN_FIRST_MSG = "Select a run first."
TRANSCRIPT_HISTORY_CSS_FILE = "transcript_history.tcss"
TRANSCRIPT_DETAIL_WORKER_GROUP = "transcript-history-detail"


@dataclass(slots=True)
class TranscriptHistoryTUICallbacks:
    """Callbacks for transcript history UI actions."""

    export_transcript: Callable[[HistoryEntry], Path | None] | None = None


def run_transcript_history_textual(
    snapshot: HistorySnapshot,
    *,
    ctx: TUIContext | None = None,
    initial_query: str = "",
    agent_hint: str | None = None,
    page_size: int | None = None,
    callbacks: TranscriptHistoryTUICallbacks | None = None,
) -> bool:
    """Run transcript history Textual page.

    Returns True when the app launched and exited successfully.
    """
    if not TEXTUAL_SUPPORTED:
        return False
    app = _TranscriptHistoryApp(
        snapshot,
        ctx=ctx,
        initial_query=initial_query,
        agent_hint=agent_hint,
        page_size=page_size,
        callbacks=callbacks,
    )
    app.run(mouse=True)
    return True


@dataclass(slots=True)
class _DetailRow:
    entry: HistoryEntry
    input_text: str
    final_text: str
    model_or_provider: str
    server_run_id: str
    task_id: str
    context_id: str
    total_tokens: str
    transcript_events: list[dict[str, Any]]
    is_loaded: bool = False
    is_loading: bool = False
    row_key: Any | None = None


class _TranscriptHistoryApp(App[None], TranscriptScreenshotCaptureMixin):
    BINDINGS = [
        Binding("left", "page_left", "Prev page", priority=True),
        Binding("right", "page_right", "Next page", priority=True),
        Binding("[", "page_left", "Prev page", show=False, priority=True),
        Binding("]", "page_right", "Next page", show=False, priority=True),
        Binding("pageup", "transcript_page_up", "Transcript Up", priority=True),
        Binding("pagedown", "transcript_page_down", "Transcript Down", priority=True),
        Binding("c", "copy_run_id", "Copy Run ID", show=False, priority=True),
        Binding("i", "copy_input", "Copy Input", show=False, priority=True),
        Binding("r", "copy_final_response", "Copy Final Response", show=False, priority=True),
        Binding("t", "copy_transcript", "Copy Transcript", show=False, priority=True),
        Binding("/", "focus_filter", "Filter", priority=True),
        Binding("escape", "clear_or_exit", "Close", priority=True),
        Binding("q", "quit", "Quit", show=False, priority=True),
    ]

    @staticmethod
    def _copy_hint(key: str) -> Text:
        return Text(f"(copy: {key})", style="bold yellow reverse")

    CSS = load_tcss_template(
        TRANSCRIPT_HISTORY_CSS_FILE,
        {
            "left_pane_percent": f"{HISTORY_LEFT_PANE_PERCENT}%",
            "right_pane_percent": f"{HISTORY_RIGHT_PANE_PERCENT}%",
        },
    )

    def __init__(
        self,
        snapshot: HistorySnapshot,
        *,
        ctx: TUIContext | None,
        initial_query: str,
        agent_hint: str | None,
        page_size: int | None,
        callbacks: TranscriptHistoryTUICallbacks | None,
    ) -> None:
        super().__init__()
        self._ctx = ctx
        self._snapshot = snapshot
        self._query = initial_query
        self._agent_hint = agent_hint
        self._callbacks = callbacks
        self._clip_adapter = ClipboardAdapter()
        self._account_identifiers = _build_account_identifier_map()
        self._rows: list[_DetailRow] = [self._build_row(entry) for entry in snapshot.entries]
        default_page_size = snapshot.limit_applied or len(self._rows) or 1
        requested_page_size = page_size if page_size is not None else default_page_size
        self._page_size = max(1, int(requested_page_size))
        self._page_index = 0
        self._filtered_rows: list[_DetailRow] = []
        self._visible_rows: list[_DetailRow] = []

    def compose(self) -> ComposeResult:
        yield Horizontal(
            Container(id="left-pane"),
            Container(id="right-pane"),
            id="content",
        )
        yield Footer()

    def on_mount(self) -> None:
        left = self.query_one("#left-pane", Container)
        right = self.query_one("#right-pane", Container)

        self._page_title = Static("Transcript History (Local Runs)", classes="pane-title")
        context = "Scope: local mixed history across agents/accounts"
        if self._agent_hint:
            context += f" | active agent: {self._agent_hint}"
        scope_label = Static(context, classes="context-line")
        self._table = DataTable(id=TABLE_ID, cursor_type="row", zebra_stripes=True)
        self._table.add_column("St", width=STATUS_COLUMN_WIDTH)
        self._table.add_column("Started", width=COMPACT_STARTED_COLUMN_WIDTH)
        self._table.add_column("Agent", width=AGENT_COL_WIDTH)
        self._table.add_column("Account", width=16)
        self._table.add_column("Input")
        self._filter = Input(placeholder="Filter run_id / agent / account / api_url ...", id=FILTER_ID)
        self._filter.display = False
        self._status = Static("", id="status")

        left.mount(self._page_title)
        left.mount(scope_label)
        left.mount(self._table)
        left.mount(self._filter)
        left.mount(self._status)

        right_scroll = ScrollableContainer(id="right-pane-body")
        right.mount(right_scroll)

        right_scroll.mount(Static("Transcript Detail", classes="pane-title"))
        self._detail_meta = Static(SELECT_RUN_FIRST_MSG)
        right_scroll.mount(self._detail_meta)
        right_scroll.mount(Static(Text.assemble("Input ", self._copy_hint("i")), classes="section-title"))
        self._input_body = TextArea("", read_only=True, show_line_numbers=False, classes="detail-input")
        right_scroll.mount(self._input_body)
        right_scroll.mount(Static(Text.assemble("Final Response ", self._copy_hint("r")), classes="section-title"))
        self._final_body = TextArea("", read_only=True, show_line_numbers=False, classes="detail-final-response")
        right_scroll.mount(self._final_body)
        right_scroll.mount(Static(Text.assemble("Transcript ", self._copy_hint("t")), classes="section-title"))
        self._transcript_log = RichLog(wrap=False, classes="step-list")
        right_scroll.mount(self._transcript_log)

        self._render_rows()
        if self._query:
            self._filter.display = True
            self._filter.value = self._query

    def on_unmount(self) -> None:  # pragma: no cover - UI lifecycle hook
        """Cancel row-detail workers to prevent updates after teardown."""
        cancel_worker_group(self, TRANSCRIPT_DETAIL_WORKER_GROUP)
        parent_on_unmount = getattr(super(), "on_unmount", None)
        if callable(parent_on_unmount):
            parent_on_unmount()  # type: ignore[misc]

    def action_transcript_page_up(self) -> None:
        self._transcript_log.scroll_page_up(animate=False)

    def action_transcript_page_down(self) -> None:
        self._transcript_log.scroll_page_down(animate=False)

    def action_page_left(self) -> None:
        if self._page_index <= 0:
            self._status.update("Already at first page.")
            return
        self._page_index -= 1
        self._render_rows()

    def action_page_right(self) -> None:
        total_pages = self._total_pages(self._filtered_rows)
        if self._page_index >= total_pages - 1:
            self._status.update("Already at last page.")
            return
        self._page_index += 1
        self._render_rows()

    def action_copy_run_id(self) -> None:
        row = self._current_row()
        if row is None:
            self._status.update(SELECT_RUN_FIRST_MSG)
            return
        run_id = row.entry.run_id or ""
        if not run_id:
            self._status.update("Run id unavailable.")
            return
        self._copy_to_clipboard(run_id, "Run ID")

    def action_copy_input(self) -> None:
        row = self._current_row()
        if row is None:
            self._status.update(SELECT_RUN_FIRST_MSG)
            return
        if not row.input_text:
            self._status.update("No input to copy.")
            return
        self._copy_to_clipboard(row.input_text, "Input")

    def action_copy_final_response(self) -> None:
        row = self._current_row()
        if row is None:
            self._status.update(SELECT_RUN_FIRST_MSG)
            return
        if not row.final_text:
            self._status.update("No final response to copy.")
            return
        self._copy_to_clipboard(row.final_text, "Final Response")

    def action_copy_transcript(self) -> None:
        row = self._current_row()
        if row is None:
            self._status.update(SELECT_RUN_FIRST_MSG)
            return
        if not row.transcript_events:
            self._status.update("No transcript to copy.")
            return
        payload = json.dumps(row.transcript_events, indent=2, ensure_ascii=False, default=str)
        self._copy_to_clipboard(payload, "Transcript")

    def action_focus_filter(self) -> None:
        self._filter.display = True
        self._filter.focus()

    def action_clear_or_exit(self) -> None:
        if self._filter.has_focus or self._filter.display:
            self._filter.display = False
            had_filter_text = bool(self._filter.value)
            self._query = ""

            if had_filter_text:
                self._filter.value = ""
            self._render_rows()

            self._table.focus()
            return
        self.exit()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != FILTER_ID:
            return
        if event.value == self._query:
            return
        self._query = event.value
        self._page_index = 0
        self._render_rows()
        if self._filter.display:
            self._schedule_screenshot_capture(allow_repeat=True)

    def _has_active_screen(self) -> bool:
        try:
            _ = self.screen
        except ScreenStackError:
            return False
        return True

    def _handle_row_selection(self, data_table_id: str | None, cursor_row: int | None) -> None:
        """Handle row selection/highlight from data table events."""
        if data_table_id != TABLE_ID or not self._has_active_screen():
            return
        self._render_detail(cursor_row)

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        """Handle row highlight events."""
        self._handle_row_selection(event.data_table.id, event.cursor_row)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle row selection (Enter/click) events."""
        self._handle_row_selection(event.data_table.id, event.cursor_row)

    def _row_matches_query(self, row: _DetailRow, query: str) -> bool:
        """Check if a row matches the search query."""
        entry = row.entry
        return (
            query in (entry.run_id or "").lower()
            or query in (entry.agent_name or "").lower()
            or query in (entry.agent_id or "").lower()
            or query in (entry.api_url or "").lower()
            or query in row.input_text.lower()
        )

    def _apply_filter(self, query: str) -> None:
        """Apply search filter to rows."""
        if not query:
            self._filtered_rows = list(self._rows)
        else:
            self._filtered_rows = [row for row in self._rows if self._row_matches_query(row, query)]

    def _calculate_pagination(self) -> tuple[int, int, int]:
        """Calculate pagination values. Returns (total_pages, page_start, page_end)."""
        total_pages = self._total_pages(self._filtered_rows)
        if self._page_index >= total_pages:
            self._page_index = max(0, total_pages - 1)

        page_start = self._page_index * self._page_size
        page_end = page_start + self._page_size
        return total_pages, page_start, page_end

    def _add_row_to_table(self, row: _DetailRow, idx: int) -> None:
        """Add a single row to the table."""
        entry = row.entry
        has_file = entry.resolved_path is not None and entry.resolved_path.exists()
        status_label, status_style = _status_badge(entry.status, has_file=has_file)
        agent_label = _short(entry.agent_name or entry.agent_id, AGENT_TRIM_LIMIT)
        account_label = _short(_account_identifier(entry.api_url, self._account_identifiers), 16)
        row.row_key = self._table.add_row(
            Text(status_label, style=status_style),
            _fmt_datetime_table(entry.started_at),
            agent_label,
            account_label,
            _short(row.input_text or "(no input)", 40),
        )
        # Defer row detail loading for non-visible rows to reduce startup cost.
        # The selected row is loaded via `_render_detail` below.
        if idx == 0 and not row.is_loaded and not row.is_loading:
            self.run_worker(
                self._load_row_details(row, idx),
                name="transcript-row-detail",
                group=TRANSCRIPT_DETAIL_WORKER_GROUP,
            )

    def _update_status(self, page_start: int) -> None:
        """Update status bar with current view info."""
        query = self._query.strip().lower()
        filtered_count = len(self._filtered_rows)
        showing_from = page_start + 1 if self._visible_rows else 0
        showing_to = page_start + len(self._visible_rows)
        filter_suffix = f" | filter: {filtered_count} matches" if query else ""

        self._status.update(
            "Manifest: "
            f"{self._snapshot.manifest_path} | showing {showing_from}-{showing_to} "
            f"of {self._snapshot.total_entries} local runs"
            f"{filter_suffix}"
        )

    def _render_empty_state(self) -> None:
        """Render empty state when no rows match."""
        self._detail_meta.update("No rows match the current filter.")
        self._input_body.text = ""
        self._final_body.text = ""
        self._transcript_log.clear()

    def _render_rows(self) -> None:
        """Render all visible rows in the table."""
        query = self._query.strip().lower()
        self._apply_filter(query)

        total_pages, page_start, page_end = self._calculate_pagination()
        self._visible_rows = self._filtered_rows[page_start:page_end]

        self._page_title.update(
            f"Transcript History (Page {self._page_index + 1}/{total_pages} | Page size={self._page_size})"
        )

        self._table.clear(columns=False)
        for idx, row in enumerate(self._visible_rows):
            self._add_row_to_table(row, idx)

        self._update_status(page_start)

        if self._visible_rows:
            self._table.move_cursor(row=0, column=0)
            self._render_detail(0)
        else:
            self._render_empty_state()

    def _current_row(self) -> _DetailRow | None:
        if not self._visible_rows:
            return None
        row_index = self._table.cursor_row
        if row_index is None or row_index < 0 or row_index >= len(self._visible_rows):
            return None
        return self._visible_rows[row_index]

    def _total_pages(self, rows: list[_DetailRow]) -> int:
        total = len(rows)
        if total <= 0:
            return 1
        return max(1, (total + self._page_size - 1) // self._page_size)

    def _copy_to_clipboard(self, value: str, label: str) -> None:
        result = self._clip_adapter.copy(value)
        if result.success:
            self._status.update(f"Copied {label} to clipboard.")
            return
        self._status.update(f"Failed to copy {label}: {result.message}")

    def _render_detail(self, row_index: int | None) -> None:
        if not self._has_active_screen():
            return
        if row_index is None or row_index < 0 or row_index >= len(self._visible_rows):
            return
        row = self._visible_rows[row_index]

        # Already handled by _render_rows eager loading, but just in case
        if not row.is_loaded and not row.is_loading:
            self.run_worker(
                self._load_row_details(row, row_index),
                name="transcript-row-detail",
                group=TRANSCRIPT_DETAIL_WORKER_GROUP,
            )

        entry = row.entry
        detail = self._build_detail_grid(row, entry)
        self._detail_meta.update(detail)

        try:
            self._input_body.text = row.input_text or ("(loading...)" if row.is_loading else "(empty)")
            self._final_body.text = row.final_text or ("(loading...)" if row.is_loading else "(empty)")
        except ScreenStackError:
            return

        self._render_transcript_log(row)

    def _build_detail_grid(self, row: _DetailRow, entry: HistoryEntry) -> Table:
        """Build the detail grid table for a row."""
        detail = Table.grid(padding=(0, 1))
        detail.add_column(style="bold cyan", no_wrap=True)
        detail.add_column()

        # Always show core fields
        detail.add_row("Run ID", Text.assemble(entry.run_id or "-", " ", self._copy_hint("c")))
        detail.add_row("Agent ID", entry.agent_id or "-")
        if entry.agent_name:
            detail.add_row("Agent Name", entry.agent_name)
        detail.add_row("Account", _account_identifier(entry.api_url, self._account_identifiers))
        if entry.api_url:
            detail.add_row("API URL", entry.api_url)
        detail.add_row("Status", Text(str(entry.status or "-").upper(), style=_status_style(entry.status)))
        detail.add_row("Started", _fmt_datetime(entry.started_at))
        if entry.finished_at:
            detail.add_row("Completed", _fmt_datetime(entry.finished_at))
        if entry.duration_seconds is not None:
            detail.add_row("Duration", f"{entry.duration_seconds}s")
        detail.add_row("Size", _fmt_size(entry.size_bytes))

        # Only show these fields if they have real values (not "-")
        if row.model_or_provider and row.model_or_provider != "-":
            detail.add_row("Model/Provider", row.model_or_provider)
        if row.total_tokens and row.total_tokens != "-":
            detail.add_row("Total Tokens", row.total_tokens)

        if row.is_loading:
            detail.add_row("", Text("Loading details from file...", style="italic yellow"))

        return detail

    def _render_transcript_log(self, row: _DetailRow) -> None:
        """Render the transcript log content."""
        self._transcript_log.clear()
        if row.is_loading:
            self._transcript_log.write("Loading transcript...")
            return

        if not row.transcript_events:
            self._transcript_log.write("No transcript available.")
            return
        for event in row.transcript_events:
            json_str = json.dumps(event, indent=2, ensure_ascii=False, default=str)
            self._transcript_log.write(Syntax(json_str, "json", theme="monokai", word_wrap=True))
            self._transcript_log.write("")

    def _build_row(self, entry: HistoryEntry) -> _DetailRow:
        input_text = ""
        final_text = ""
        model_or_provider = "-"

        if isinstance(entry.manifest, dict):
            input_text = str(entry.manifest.get("input") or "")
            final_text = str(entry.manifest.get("final_output") or "")
            model_or_provider = str(entry.manifest.get("model") or entry.manifest.get("provider") or "-")

        return _DetailRow(
            entry=entry,
            input_text=input_text,
            final_text=final_text,
            model_or_provider=model_or_provider,
            server_run_id="-",
            task_id="-",
            context_id="-",
            total_tokens="-",
            transcript_events=[],
            is_loaded=False,
            is_loading=False,
            row_key=None,
        )

    def _parse_meta_payload(
        self,
        payload: dict[str, Any],
        current_input: str,
        current_final: str,
        current_model: str,
    ) -> tuple[str, str, str, str]:
        """Parse meta payload and return updated input_text, final_text, model, server_run_id."""
        model_or_provider = str(payload.get("model") or payload.get("provider") or current_model)
        server_run_id = str(payload.get("server_run_id") or "").strip() or "-"
        meta_value = payload.get("meta")
        meta_blob: dict[str, Any] = meta_value if isinstance(meta_value, dict) else {}

        input_text = current_input
        final_text = current_final

        if not input_text:
            input_text = str(
                payload.get("input_message") or payload.get("input") or meta_blob.get("input_message") or ""
            )
        if not final_text:
            final_text = str(
                payload.get("final_output") or payload.get("default_output") or payload.get("output") or ""
            )

        return input_text, final_text, model_or_provider, server_run_id

    def _extract_event_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Extract event payload from the line payload."""
        event_value = payload.get("event")
        return event_value if isinstance(event_value, dict) else payload

    def _extract_id_if_default(self, event_payload: dict[str, Any], current_id: str, key: str) -> str:
        """Extract ID from event payload if current value is default."""
        if current_id != "-":
            return current_id
        return str(event_payload.get(key) or "").strip() or "-"

    def _extract_total_tokens(self, event_payload: dict[str, Any], current_tokens: str) -> str:
        """Extract total tokens from event payload metadata."""
        if current_tokens != "-":
            return current_tokens

        metadata_value = event_payload.get("metadata")
        metadata_blob: dict[str, Any] = metadata_value if isinstance(metadata_value, dict) else {}
        usage_value = metadata_blob.get("total_usage")
        usage_blob: dict[str, Any] = usage_value if isinstance(usage_value, dict) else {}

        candidate = usage_blob.get("total_tokens")
        if candidate is None:
            return "-"
        try:
            return str(int(candidate))
        except (ValueError, TypeError):
            return "-"

    def _add_transcript_event(self, event_payload: dict[str, Any], transcript_events: list[dict[str, Any]]) -> None:
        """Add raw transcript event payload to render/copy list.

        Large transcripts are truncated to prevent UI performance issues.
        Full file is still read; only displayed event count is limited.
        """
        if len(transcript_events) < 256:
            transcript_events.append(event_payload)

    @staticmethod
    def _is_final_response_event(event_payload: dict[str, Any]) -> bool:
        if event_payload.get("event_type") == "final_response":
            return True
        metadata = event_payload.get("metadata")
        if isinstance(metadata, dict) and metadata.get("kind") == "final_response":
            return True
        return event_payload.get("final") is True

    def _extract_event_final_response(self, event_payload: dict[str, Any], current_final: str) -> str:
        """Extract final response text from event payload when available."""
        if current_final:
            return current_final
        if not self._is_final_response_event(event_payload):
            return current_final

        content = event_payload.get("content")
        if content:
            return str(content)

        message = event_payload.get("message")
        if isinstance(message, str) and message.strip():
            return message
        if isinstance(message, dict):
            for key in ("content", "text", "en", "id"):
                value = message.get(key)
                if value:
                    return str(value)

        output_value = event_payload.get("output")
        if output_value:
            return str(output_value)
        return current_final

    def _parse_event_payload(
        self,
        payload: dict[str, Any],
        current_task_id: str,
        current_context_id: str,
        current_tokens: str,
        current_final: str,
        transcript_events: list[dict[str, Any]],
    ) -> tuple[str, str, str, str, list[dict[str, Any]]]:
        """Parse event payload and return updated task/context/tokens/final/events."""
        event_payload = self._extract_event_payload(payload)

        task_id = self._extract_id_if_default(event_payload, current_task_id, "task_id")
        context_id = self._extract_id_if_default(event_payload, current_context_id, "context_id")
        total_tokens = self._extract_total_tokens(event_payload, current_tokens)
        final_text = self._extract_event_final_response(event_payload, current_final)
        self._add_transcript_event(event_payload, transcript_events)

        return task_id, context_id, total_tokens, final_text, transcript_events

    def _read_transcript_file(self, path: Path, row: _DetailRow) -> tuple:
        """Read and parse transcript file."""
        input_text = row.input_text
        final_text = row.final_text
        model_or_provider = row.model_or_provider
        server_run_id = "-"
        task_id = "-"
        context_id = "-"
        total_tokens = "-"
        transcript_events: list[dict[str, Any]] = []

        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                parsed = parse_json_line(line)
                if not isinstance(parsed, dict):
                    continue
                payload: dict[str, Any] = parsed

                if payload.get("type") == "meta":
                    input_text, final_text, model_or_provider, server_run_id = self._parse_meta_payload(
                        payload, input_text, final_text, model_or_provider
                    )
                else:
                    task_id, context_id, total_tokens, final_text, transcript_events = self._parse_event_payload(
                        payload, task_id, context_id, total_tokens, final_text, transcript_events
                    )

        return (
            input_text,
            final_text,
            model_or_provider,
            server_run_id,
            task_id,
            context_id,
            total_tokens,
            transcript_events,
        )

    def _update_table_row(self, row: _DetailRow) -> None:
        """Update table cell with loaded row data."""
        if row.row_key is None or row.row_key not in self._table.rows:
            return
        try:
            row_idx = self._table.get_row_index(row.row_key)
            self._table.update_cell_at(
                Coordinate(row_idx, 4),
                _short(row.input_text or "(no input)", 40),
            )
            self._table.refresh_row(row_idx)
        except (LookupError, RuntimeError):
            # LookupError: row not found in table
            # RuntimeError: table state inconsistency
            pass

    async def _load_row_details(self, row: _DetailRow, visible_index: int | None) -> None:
        """Worker to load detailed metadata from the transcript JSONL file."""
        if row.is_loaded or row.is_loading:
            return

        row.is_loading = True
        if self._table.cursor_row == visible_index:
            self._render_detail(visible_index)

        path = row.entry.resolved_path or row.entry.expected_path
        if path is not None and path.exists():
            try:
                results = await asyncio.to_thread(self._read_transcript_file, path, row)
                (
                    row.input_text,
                    row.final_text,
                    row.model_or_provider,
                    row.server_run_id,
                    row.task_id,
                    row.context_id,
                    row.total_tokens,
                    row.transcript_events,
                ) = results
            except Exception as exc:
                # Log file parsing errors but don't crash the UI
                logger.debug("Failed to load transcript file: %s", exc, exc_info=exc)
                row.transcript_events = []
            finally:
                row.is_loaded = True
                row.is_loading = False
                self._update_table_row(row)
                if self._table.cursor_row == visible_index:
                    self._render_detail(visible_index)
        else:
            row.transcript_events = []
            row.is_loaded = True
            row.is_loading = False
            self._update_table_row(row)
            if self._table.cursor_row == visible_index:
                self._render_detail(visible_index)


def _fmt_datetime(value: Any) -> str:
    return format_utc_absolute_timestamp(value, placeholder="-")


def _fmt_datetime_table(value: Any) -> str:
    return format_compact_table_timestamp(value, placeholder="-")


def _fmt_size(size_bytes: int | None) -> str:
    if not size_bytes or size_bytes <= 0:
        return "-"
    units = ("B", "KB", "MB", "GB")
    size = float(size_bytes)
    unit = 0
    while size >= 1024 and unit < len(units) - 1:
        size /= 1024
        unit += 1
    if unit == 0:
        return f"{int(size)}{units[unit]}"
    return f"{size:.2f}{units[unit]}"


def _short(value: str | None, limit: int) -> str:
    text = (value or "").strip()
    if not text:
        return "-"
    if len(text) <= limit:
        return text
    return text[: max(1, limit - 3)] + "..."


def _normalize_api_url(api_url: str | None) -> tuple[str, str]:
    if not api_url:
        return "", ""
    raw = api_url.strip()
    if not raw:
        return "", ""
    try:
        parsed = urlparse(raw)
    except Exception:
        lowered = raw.lower().rstrip("/")
        return lowered, lowered

    host = parsed.netloc.strip().lower()
    if not host and parsed.path and "://" not in raw:
        host = parsed.path.strip().lower()
    scheme = parsed.scheme.strip().lower()
    normalized = f"{scheme}://{host}" if scheme and host else (host or raw.lower()).rstrip("/")
    return normalized, host


def _build_account_identifier_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    try:
        accounts = get_account_store().list_accounts()
    except Exception:
        return mapping

    for name, payload in accounts.items():
        api_url = str((payload or {}).get("api_url") or "").strip()
        if not api_url:
            continue
        normalized, host = _normalize_api_url(api_url)
        if normalized and normalized not in mapping:
            mapping[normalized] = name
        if host and host not in mapping:
            mapping[host] = name
    return mapping


def _account_identifier(api_url: str | None, mapping: dict[str, str]) -> str:
    if not api_url:
        return "-"
    normalized, host = _normalize_api_url(api_url)
    if normalized and normalized in mapping:
        return mapping[normalized]
    if host and host in mapping:
        return mapping[host]
    return host or api_url


def _status_label(status: str | None) -> str:
    if not status:
        return "-"
    normalized = str(status).strip().lower()
    if normalized in {"ok", "success", "completed", "succeeded", "cached"}:
        return "✔"
    if normalized in {"running", "in_progress"}:
        return "⟳"
    if normalized in {"failed", "error", "errored"}:
        return "✖"
    if normalized in {"aborted", "cancelled", "canceled", "missing"}:
        return "⊘"
    return normalized[:3].upper()


def _status_style(status: str | None) -> str:
    if not status:
        return "dim"
    normalized = str(status).strip().lower()
    if normalized in {"ok", "success", "completed", "succeeded", "cached"}:
        return "green"
    if normalized in {"running", "in_progress", "run"}:
        return "yellow"
    if normalized in {"failed", "error", "errored", "aborted", "cancelled", "canceled", "missing"}:
        return "red"
    return "cyan"


def _status_badge(status: str | None, *, has_file: bool) -> tuple[str, str]:
    if not has_file:
        return "⊘", "red"
    return _status_label(status), _status_style(status)
