"""Centralized screenshot capture mixin for Textual TUI apps.

Provides reusable screenshot functionality that can be mixed into any Textual App.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    pass


class ScreenshotCaptureMixin:
    """Mixin to add screenshot capture capability to Textual apps.

    Usage:
        1. Inherit from this mixin alongside App
        2. Set env vars to control capture:
           - AIP_TUI_CAPTURE_PATH: Path to save screenshot
           - AIP_TUI_CAPTURE_DELAY: Seconds to wait before capture (default: 0.45)
           - AIP_TUI_CAPTURE_COLS / AIP_TUI_CAPTURE_ROWS: Optional viewport size
             for larger or zoomed-out captures

    The mixin schedules one mount capture automatically via ``on_ready``.
    Call ``_schedule_screenshot_capture(allow_repeat=True)`` only when a later
    UI state should be captured again (for example after a filter change).
    """

    # Environment variable names (can be overridden per-app)
    CAPTURE_PATH_ENV: str = "AIP_TUI_CAPTURE_PATH"
    CAPTURE_DELAY_ENV: str = "AIP_TUI_CAPTURE_DELAY"
    CAPTURE_COLS_ENV: str = "AIP_TUI_CAPTURE_COLS"
    CAPTURE_ROWS_ENV: str = "AIP_TUI_CAPTURE_ROWS"
    CAPTURE_PATH_FALLBACK_ENVS: tuple[str, ...] = ()
    CAPTURE_DELAY_FALLBACK_ENVS: tuple[str, ...] = ()
    CAPTURE_COLS_FALLBACK_ENVS: tuple[str, ...] = ()
    CAPTURE_ROWS_FALLBACK_ENVS: tuple[str, ...] = ()
    DEFAULT_DELAY: float = 0.45
    DEFAULT_CAPTURE_COLS: int = 170
    DEFAULT_CAPTURE_ROWS: int = 52
    RESIZE_SETTLE_DELAY: float = 0.05

    def on_ready(self) -> None:  # pragma: no cover - Textual lifecycle hook
        """Auto-schedule first screenshot capture when app becomes ready."""
        self._schedule_screenshot_capture()

    def _schedule_screenshot_capture(self, *, allow_repeat: bool = False) -> None:
        """Schedule screenshot capture when env var is configured."""
        if not allow_repeat and getattr(self, "_screenshot_capture_scheduled", False):
            return

        path_raw = self._get_capture_path()
        if not path_raw:
            return

        delay = self._get_capture_delay()
        schedule_timer = getattr(self, "set_timer", None)  # type: ignore[attr-defined]
        if callable(schedule_timer):
            schedule_timer(delay, lambda: self._capture_screenshot_with_optional_resize(path_raw))
            setattr(self, "_screenshot_capture_scheduled", True)

    def _capture_screenshot_with_optional_resize(self, destination: str) -> None:
        """Capture screenshot, optionally resizing viewport first."""
        viewport = self._get_capture_viewport()
        if self._apply_capture_viewport(*viewport):
            schedule_timer = getattr(self, "set_timer", None)  # type: ignore[attr-defined]
            if callable(schedule_timer):
                schedule_timer(self.RESIZE_SETTLE_DELAY, lambda: self._capture_screenshot(destination))
                return

        self._capture_screenshot(destination)

    def _get_capture_path(self) -> str:
        """Resolve capture path from primary/fallback env vars."""
        for env_name in (self.CAPTURE_PATH_ENV, *self.CAPTURE_PATH_FALLBACK_ENVS):
            value = os.getenv(env_name, "").strip()
            if value:
                return value
        return ""

    def _get_capture_delay(self) -> float:
        """Parse capture delay from environment variable."""
        delay_raw = ""
        for env_name in (self.CAPTURE_DELAY_ENV, *self.CAPTURE_DELAY_FALLBACK_ENVS):
            value = os.getenv(env_name, "").strip()
            if value:
                delay_raw = value  # pragma: no cover - stubborn coverage
                break
        if not delay_raw:
            delay_raw = str(self.DEFAULT_DELAY)
        try:
            return max(0.0, float(delay_raw))
        except ValueError:
            return self.DEFAULT_DELAY

    def _get_capture_viewport(self) -> tuple[int, int]:
        """Resolve capture viewport size as (cols, rows)."""
        cols_raw = self._get_first_non_empty_env(self.CAPTURE_COLS_ENV, self.CAPTURE_COLS_FALLBACK_ENVS)
        rows_raw = self._get_first_non_empty_env(self.CAPTURE_ROWS_ENV, self.CAPTURE_ROWS_FALLBACK_ENVS)

        cols = self._parse_positive_int(cols_raw, self.DEFAULT_CAPTURE_COLS)
        rows = self._parse_positive_int(rows_raw, self.DEFAULT_CAPTURE_ROWS)
        return cols, rows

    def _parse_positive_int(self, raw_value: str, default: int) -> int:
        """Parse positive int, falling back to default when invalid."""
        if not raw_value:
            return default
        try:
            parsed = int(raw_value)
        except ValueError:
            return default
        return parsed if parsed > 0 else default

    def _get_first_non_empty_env(self, primary: str, fallbacks: tuple[str, ...]) -> str:
        """Return first non-empty env var value from primary/fallback chain."""
        for env_name in (primary, *fallbacks):
            value = os.getenv(env_name, "").strip()
            if value:
                return value
        return ""

    def _apply_capture_viewport(self, cols: int, rows: int) -> bool:
        """Best-effort viewport resize before screenshot capture."""
        try:
            from textual import events  # noqa: PLC0415
            from textual.geometry import Size  # noqa: PLC0415
        except Exception:  # pragma: no cover - defensive
            return False

        size = Size(cols, rows)
        applied = False

        driver = getattr(self, "_driver", None)
        if driver is not None and hasattr(driver, "_size"):
            try:
                setattr(driver, "_size", size)
                applied = True
            except Exception:  # pragma: no cover - defensive
                pass

        post_message = getattr(self, "post_message", None)
        if callable(post_message):
            try:
                post_message(events.Resize(size, size, size, None))
                applied = True
            except Exception:  # pragma: no cover - defensive
                pass

        return applied

    def _capture_screenshot(self, destination: str) -> None:
        """Capture screenshot to destination path (best-effort)."""
        path = Path(destination)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Try save_screenshot first (Textual 0.40+)
        if self._try_save_screenshot(path):
            return

        # Fallback to export_screenshot (older Textual)
        self._try_export_screenshot(path)

    def _try_save_screenshot(self, path: Path) -> bool:
        """Try Textual save_screenshot API (returns True on success)."""
        save_method = getattr(self, "save_screenshot", None)
        if not callable(save_method):
            return False

        try:
            result = save_method(str(path))
        except Exception:
            return False

        if path.exists():
            return True

        # Handle case where save_screenshot returns path
        if isinstance(result, (str, Path)):
            result_path = Path(result)
            if result_path.exists():
                if result_path != path:
                    shutil.copy2(result_path, path)
                return True
        return False

    def _try_export_screenshot(self, path: Path) -> bool:
        """Try Textual export_screenshot API (returns True on success)."""
        export_method = getattr(self, "export_screenshot", None)
        if not callable(export_method):
            return False

        try:
            svg = export_method()
        except Exception:
            return False

        if isinstance(svg, str) and svg.strip():
            path.write_text(svg, encoding="utf-8")
            return True
        return False


class WorkspaceScreenshotCaptureMixin(ScreenshotCaptureMixin):
    """Screenshot capture mixin with workspace-specific env var names."""

    CAPTURE_PATH_ENV = "AIP_TUI_CAPTURE_SCREENSHOT_PATH"
    CAPTURE_DELAY_ENV = "AIP_TUI_CAPTURE_SCREENSHOT_DELAY"
    CAPTURE_COLS_ENV = "AIP_TUI_CAPTURE_SCREENSHOT_COLS"
    CAPTURE_ROWS_ENV = "AIP_TUI_CAPTURE_SCREENSHOT_ROWS"
    CAPTURE_PATH_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_PATH",)
    CAPTURE_DELAY_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_DELAY",)
    CAPTURE_COLS_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_COLS",)
    CAPTURE_ROWS_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_ROWS",)


class TranscriptScreenshotCaptureMixin(ScreenshotCaptureMixin):
    """Screenshot capture mixin with transcript-specific env var names."""

    CAPTURE_PATH_ENV = "AIP_TUI_TRANSCRIPT_CAPTURE_PATH"
    CAPTURE_DELAY_ENV = "AIP_TUI_TRANSCRIPT_CAPTURE_DELAY"
    CAPTURE_COLS_ENV = "AIP_TUI_TRANSCRIPT_CAPTURE_COLS"
    CAPTURE_ROWS_ENV = "AIP_TUI_TRANSCRIPT_CAPTURE_ROWS"
    CAPTURE_PATH_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_PATH",)
    CAPTURE_DELAY_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_DELAY",)
    CAPTURE_COLS_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_COLS",)
    CAPTURE_ROWS_FALLBACK_ENVS = ("AIP_TUI_CAPTURE_ROWS",)
