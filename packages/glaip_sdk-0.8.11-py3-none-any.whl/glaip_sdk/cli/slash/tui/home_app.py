"""Home launcher routes powered by the shared workspace shell app."""

from __future__ import annotations

from collections.abc import Callable

from glaip_sdk.cli.slash.tui.agent_workspace_foundation import workspace_label
from glaip_sdk.cli.slash.tui.agent_workspace_shell_app import (
    AgentWorkspaceDetails,
    run_agent_workspace_shell,
)
from glaip_sdk.cli.slash.tui.context import TUIContext

SELECTOR_ROUTE = "open_agents_selector"
COMMAND_ROUTE_PREFIX = "run_command:"
HOME_PLACEHOLDER = "Type / for commands. Press Ctrl+D to exit."
HomeStatusSummaryProvider = Callable[[], list[str]]
HomeTranscriptSink = Callable[[list[str]], None]


def _should_route_selector(raw: str) -> bool:
    """Return True when command should hand off directly to selector table UI."""
    lowered = raw.strip().lower()
    return lowered == "/agents" or lowered.startswith("/agents select") or lowered.startswith("/agents list")


def _build_command_route(raw: str) -> str:
    """Build an app-exit route that asks the launcher to run a slash command."""
    return f"{COMMAND_ROUTE_PREFIX}{raw.strip()}"


def parse_command_route(route: str | None) -> str | None:
    """Return command payload for command routes, else None."""
    if not isinstance(route, str):
        return None
    if not route.startswith(COMMAND_ROUTE_PREFIX):
        return None
    command = route[len(COMMAND_ROUTE_PREFIX) :].strip()
    return command or None


def _home_details() -> AgentWorkspaceDetails:
    """Return shell details payload for home mode."""
    workspace = workspace_label()
    return AgentWorkspaceDetails(
        id="home",
        name="Home Launcher",
        account_id=workspace,
        description="Default slash home",
    )


def run_home_app(
    *,
    ctx: TUIContext | None = None,
    status_summary_provider: HomeStatusSummaryProvider | None = None,
    transcript_lines: list[str] | None = None,
    transcript_sink: HomeTranscriptSink | None = None,
) -> str | None:
    """Run home mode using the shared workspace shell and return launcher routes."""
    _ = ctx
    event = run_agent_workspace_shell(
        details=_home_details(),
        transcript_lines=list(transcript_lines or []),
        composer_placeholder=HOME_PLACEHOLDER,
        status_summary_provider=status_summary_provider,
        transcript_sink=transcript_sink,
        mode="home",
    )
    if event is None or event.kind == "exit":
        return None
    if event.kind != "command":
        return None

    command_text = (event.value or "").strip()
    if not command_text:
        return None
    if _should_route_selector(command_text):
        return SELECTOR_ROUTE
    return _build_command_route(command_text)
