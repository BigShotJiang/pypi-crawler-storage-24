"""Transcript history controller for the /transcripts slash command."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from glaip_sdk.branding import WARNING_STYLE
from glaip_sdk.cli.slash.tui.transcript_history_app import (
    TEXTUAL_SUPPORTED,
    TranscriptHistoryTUICallbacks,
    run_transcript_history_textual,
)
from glaip_sdk.cli.transcript.history import load_history_snapshot

if TYPE_CHECKING:  # pragma: no cover
    from glaip_sdk.cli.slash.session import SlashSession


class TranscriptHistoryController:
    """Controller for local transcript history browsing."""

    def __init__(self, session: SlashSession) -> None:
        """Initialize the transcript history controller.

        Args:
            session: The slash session to use for console output.
        """
        self.session = session
        self.console = session.console
        self.ctx = session.ctx

    def handle_transcripts_command(self, args: list[str], *, invoked_from_agent: bool) -> bool:
        """Handle /transcripts command in both global and agent contexts."""
        if args:
            self.console.print(f"[{WARNING_STYLE}]Usage: /transcripts[/]")
            return self._continue_session()

        snapshot = load_history_snapshot(limit=None, ctx=self.ctx)
        if self.session._handle_transcripts_empty(snapshot, None):
            return self._continue_session()

        if self._should_use_textual_browser():
            page_size = max(1, snapshot.limit_applied or 1)
            full_snapshot = load_history_snapshot(limit=None, ctx=self.ctx, include_all=True)
            current_agent = getattr(self.session, "_current_agent", None)
            agent_hint = None
            if invoked_from_agent and current_agent is not None:
                agent_hint = getattr(current_agent, "name", None) or getattr(current_agent, "id", None)
            launched = run_transcript_history_textual(
                full_snapshot,
                ctx=getattr(self.session, "tui_ctx", None),
                agent_hint=agent_hint,
                page_size=page_size,
                callbacks=TranscriptHistoryTUICallbacks(export_transcript=None),  # Export disabled
            )
            if launched:
                return self._continue_session()

        self.session._render_transcripts_snapshot(snapshot)
        return self._continue_session()

    def _should_use_textual_browser(self) -> bool:
        if not TEXTUAL_SUPPORTED:
            return False

        def _is_tty(stream: object) -> bool:
            isatty = getattr(stream, "isatty", None)
            if not callable(isatty):
                return False
            try:
                return bool(isatty())
            except Exception:
                return False

        return _is_tty(sys.stdin) and _is_tty(sys.stdout)

    def _continue_session(self) -> bool:
        return not getattr(self.session, "_should_exit", False)
