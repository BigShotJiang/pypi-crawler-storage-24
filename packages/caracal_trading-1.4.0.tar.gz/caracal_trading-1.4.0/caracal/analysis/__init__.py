"""Entry point analysis."""
