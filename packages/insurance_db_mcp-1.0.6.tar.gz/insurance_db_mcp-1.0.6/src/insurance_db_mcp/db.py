"""数据库连接与操作模块"""
import pymysql
import json
import re
from decimal import Decimal
from datetime import datetime, date
import time

# 数据库配置
DB_CONFIG = {
    "host": "43.143.125.184",
    "port": 23306,
    "user": "root",
    "password": "12345678q",
    "database": "insurance_db",
    "charset": "utf8mb4",
    "connect_timeout": 10,
    "read_timeout": 30,  # 新增读取超时
    "write_timeout": 30, # 新增写入超时
    "cursorclass": pymysql.cursors.DictCursor,
}

# 数据库Schema信息
SCHEMA_INFO = """
数据库: insurance_db (保险业务数据库)

表结构:

1. customers (客户信息表)
   - customer_id VARCHAR(50) PRIMARY KEY -- 客户ID
   - name VARCHAR(100) -- 客户姓名
   - gender VARCHAR(10) -- 性别
   - birth_date DATE -- 出生日期
   - city VARCHAR(50) -- 城市
   - registration_date DATETIME -- 注册日期
   - customer_level VARCHAR(20) -- 客户等级
   - total_premium DECIMAL(18,2) -- 总保费

2. policies (保单信息表)
   - id INT AUTO_INCREMENT PRIMARY KEY
   - policy_id VARCHAR(50) -- 保单ID
   - customer_id VARCHAR(50) -- 客户ID (关联customers.customer_id)
   - policy_type VARCHAR(50) -- 保单类型
   - premium DECIMAL(18,2) -- 保费
   - start_date DATETIME -- 起始日期
   - end_date DATETIME -- 结束日期
   - status VARCHAR(20) -- 状态
   - INDEX idx_customer_id (customer_id)
   - INDEX idx_policy_type (policy_type)

3. claims (理赔记录表)
   - id INT AUTO_INCREMENT PRIMARY KEY
   - claim_id VARCHAR(50) -- 理赔ID
   - policy_id VARCHAR(50) -- 保单ID (关联policies.policy_id)
   - customer_id VARCHAR(50) -- 客户ID (关联customers.customer_id)
   - claim_amount DECIMAL(18,2) -- 理赔金额
   - claim_date DATETIME -- 理赔日期
   - status VARCHAR(20) -- 状态
   - INDEX idx_customer_id (customer_id)

4. premiums (缴费记录表)
   - id INT AUTO_INCREMENT PRIMARY KEY
   - premium_id VARCHAR(50) -- 缴费ID
   - policy_id VARCHAR(50) -- 保单ID (关联policies.policy_id)
   - customer_id VARCHAR(50) -- 客户ID (关联customers.customer_id)
   - amount DECIMAL(18,2) -- 缴费金额
   - payment_date DATETIME -- 缴费日期
   - payment_method VARCHAR(50) -- 支付方式
   - INDEX idx_customer_id (customer_id)

表之间的关系:
- policies.customer_id -> customers.customer_id
- claims.customer_id -> customers.customer_id
- claims.policy_id -> policies.policy_id
- premiums.customer_id -> customers.customer_id
- premiums.policy_id -> policies.policy_id
""".strip()


class JSONEncoder(json.JSONEncoder):
    """自定义JSON编码器，处理Decimal和datetime等类型"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        return super().default(obj)


def validate_sql(sql: str) -> dict:
    """
    验证SQL的安全性和合理性
    """
    sql_upper = sql.strip().upper()

    # 检查是否包含危险操作
    dangerous_operations = ['DROP', 'TRUNCATE', 'DELETE', 'UPDATE', 'INSERT']
    for op in dangerous_operations:
        if f' {op} ' in sql_upper or f'{op} ' in sql_upper[:len(op)+1]:
            if op in ['DELETE', 'UPDATE', 'INSERT']:
                # 允许这些操作但要特别小心检查
                pass
            else:
                return {
                    "valid": False,
                    "error": f"不允许执行 {op} 操作，出于安全考虑"
                }

    # 检查是否是合理的查询
    allowed_operations = ['SELECT', 'SHOW', 'DESC', 'EXPLAIN']
    is_allowed = any(op in sql_upper for op in allowed_operations)

    if not is_allowed:
        # 对于非SELECT操作，要进一步验证
        if sql_upper.startswith('DELETE') or sql_upper.startswith('UPDATE'):
            # 检查是否有WHERE子句
            if 'WHERE' not in sql_upper:
                return {
                    "valid": False,
                    "error": "DELETE或UPDATE操作必须包含WHERE子句，以防误删数据"
                }

    # 检查是否有无限循环风险的JOIN
    # 检查是否存在笛卡尔积的风险
    from_count = len(re.findall(r'\bFROM\b', sql_upper))
    join_count = len(re.findall(r'\bJOIN\b', sql_upper))
    comma_from = re.search(r'\bFROM\s+\w+\s*,\s*\w+', sql_upper)

    if from_count > 1 and join_count == 0 and comma_from:
        return {
            "valid": False,
            "error": "检测到可能存在笛卡尔积的查询，请使用显式JOIN语法并确保有适当的WHERE条件"
        }

    # 检查是否有过多嵌套
    open_brackets = sql.count('(')
    close_brackets = sql.count(')')
    if abs(open_brackets - close_brackets) > 5:  # 过多括号可能表示复杂嵌套
        return {
            "valid": False,
            "error": "SQL语法错误：括号不匹配"
        }

    # 检查LIMIT子句（如果没有则建议加上）
    has_limit = 'LIMIT' in sql_upper

    return {
        "valid": True,
        "has_limit": has_limit,
        "is_select": sql_upper.startswith('SELECT'),
        "suggest_adding_limit": not has_limit and sql_upper.startswith('SELECT')
    }


def get_connection():
    """获取数据库连接"""
    return pymysql.connect(**DB_CONFIG)


def execute_query(sql: str, params: tuple = None, timeout_seconds: int = 30) -> dict:
    """
    执行SQL查询并返回结果
    """
    # 首先验证SQL
    validation_result = validate_sql(sql)
    if not validation_result["valid"]:
        return {
            "success": False,
            "error": validation_result["error"],
            "validation_error": True
        }

    conn = None
    try:
        # 在SQL中添加超时提示（MySQL的一种方式）
        conn = get_connection()

        # 如果是SELECT查询且没有LIMIT，自动添加一个合理的LIMIT
        sql_upper = sql.strip().upper()
        if sql_upper.startswith("SELECT") and 'LIMIT' not in sql_upper:
            # 检查是否是聚合查询（COUNT, SUM, AVG等），如果是则不需要LIMIT
            aggregate_funcs = ['COUNT(', 'SUM(', 'AVG(', 'MAX(', 'MIN(']
            is_aggregate = any(func in sql_upper for func in aggregate_funcs)

            if not is_aggregate:
                # 对于普通查询，如果结果可能很大，则添加LIMIT
                sql = f"{sql.strip()} LIMIT 1000"  # 默认限制1000条

        start_time = time.time()
        with conn.cursor() as cursor:
            # 设置会话级别的查询超时（MySQL特有方法）
            cursor.execute("SET SESSION MAX_EXECUTION_TIME = %s", (timeout_seconds * 1000,))
            cursor.execute(sql, params)

            # 检查是否为SELECT查询
            if sql_upper.startswith("SELECT") or sql_upper.startswith("SHOW") or sql_upper.startswith("DESC"):
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description] if cursor.description else []

                # 序列化结果
                serialized_rows = json.loads(json.dumps(rows, cls=JSONEncoder))

                execution_time = time.time() - start_time

                return {
                    "success": True,
                    "data": serialized_rows,
                    "columns": columns,
                    "row_count": len(rows),
                    "execution_time": round(execution_time, 2),
                    "query_was_limited": 'LIMIT' in sql_upper
                }
            else:
                conn.commit()
                execution_time = time.time() - start_time

                return {
                    "success": True,
                    "affected_rows": cursor.rowcount,
                    "message": f"操作成功，影响了 {cursor.rowcount} 行",
                    "execution_time": round(execution_time, 2)
                }
    except pymysql.err.TimeoutError:
        return {
            "success": False,
            "error": f"查询超时 ({timeout_seconds}秒)，请尝试简化查询或联系管理员",
            "timeout_error": True
        }
    except pymysql.Error as e:
        error_code = e.args[0] if e.args else None
        if error_code == 1969:  # MySQL执行超时错误码
            return {
                "success": False,
                "error": f"查询超时 ({timeout_seconds}秒)，SQL执行时间过长",
                "timeout_error": True
            }
        return {
            "success": False,
            "error": str(e),
            "error_code": error_code,
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
        }
    finally:
        if conn:
            conn.close()


def test_connection() -> bool:
    """测试数据库连接"""
    try:
        result = execute_query("SELECT 1 as test")
        return result.get("success", False)
    except Exception:
        return False


def get_table_stats() -> dict:
    """获取各表的数据统计"""
    tables = ["customers", "policies", "claims", "premiums"]
    stats = {}
    for table in tables:
        result = execute_query(f"SELECT COUNT(*) as cnt FROM {table}")
        if result["success"] and result.get("data"):
            stats[table] = result["data"][0]["cnt"]
        else:
            stats[table] = "error"
    return stats
