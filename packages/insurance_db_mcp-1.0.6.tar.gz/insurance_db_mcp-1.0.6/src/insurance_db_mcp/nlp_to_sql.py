"""NLP转SQL模块 - 提供SQL验证和辅助功能"""
import re
from insurance_db_mcp.db import SCHEMA_INFO


def validate_and_sanitize_sql(sql: str) -> dict:
    """
    验证和清理SQL语句，防止SQL注入等安全问题
    """
    # 移除可能有害的关键字（仅在非SELECT语句中）
    dangerous_keywords = ['DROP', 'TRUNCATE', 'EXEC', 'UNION', 'SUBSTR', 'ASCII']

    upper_sql = sql.upper()

    # 检查是否有危险关键字
    for keyword in dangerous_keywords:
        if keyword in upper_sql:
            return {
                "valid": False,
                "error": f"SQL包含危险关键字: {keyword}",
                "sanitized_sql": sql
            }

    # 确保SQL长度合理
    if len(sql) > 5000:
        return {
            "valid": False,
            "error": "SQL语句过长，可能存在安全隐患",
            "sanitized_sql": sql[:5000]
        }

    # 基本语法检查
    stripped_sql = sql.strip()
    if not (stripped_sql.upper().startswith('SELECT') or
            stripped_sql.upper().startswith('INSERT') or
            stripped_sql.upper().startswith('UPDATE') or
            stripped_sql.upper().startswith('DELETE')):
        return {
            "valid": False,
            "error": "SQL语句必须是以SELECT, INSERT, UPDATE, 或 DELETE开头的有效语句",
            "sanitized_sql": sql
        }

    return {
        "valid": True,
        "error": None,
        "sanitized_sql": sql.strip()
    }


# ============================
# 辅助功能：提供数据库信息
# ============================

TABLE_MAP = {
    "客户": "customers", "用户": "customers", "customer": "customers",
    "保单": "policies", "保险单": "policies", "policy": "policies",
    "理赔": "claims", "理赔记录": "claims", "claim": "claims",
    "缴费": "premiums", "缴费记录": "premiums", "付款": "premiums",
    "支付": "premiums", "premium": "premiums",
}

FIELD_MAP = {
    "customers": {
        "客户id": "customer_id", "客户编号": "customer_id", "姓名": "name", "名字": "name",
        "性别": "gender", "出生日期": "birth_date", "生日": "birth_date",
        "城市": "city", "地区": "city", "注册日期": "registration_date",
        "客户等级": "customer_level", "等级": "customer_level", "级别": "customer_level",
        "总保费": "total_premium", "保费总额": "total_premium",
    },
    "policies": {
        "保单id": "policy_id", "保单编号": "policy_id", "客户id": "customer_id",
        "保单类型": "policy_type", "类型": "policy_type", "保费": "premium",
        "开始日期": "start_date", "起始日期": "start_date", "生效日期": "start_date",
        "结束日期": "end_date", "到期日期": "end_date", "状态": "status",
    },
    "claims": {
        "理赔id": "claim_id", "理赔编号": "claim_id", "保单id": "policy_id",
        "客户id": "customer_id", "理赔金额": "claim_amount", "金额": "claim_amount",
        "理赔日期": "claim_date", "日期": "claim_date", "状态": "status",
    },
    "premiums": {
        "缴费id": "premium_id", "缴费编号": "premium_id", "保单id": "policy_id",
        "客户id": "customer_id", "缴费金额": "amount", "金额": "amount",
        "缴费日期": "payment_date", "日期": "payment_date",
        "支付方式": "payment_method", "缴费方式": "payment_method",
    },
}

AGG_MAP = {
    "总数": "COUNT(*)", "数量": "COUNT(*)", "个数": "COUNT(*)", "多少": "COUNT(*)", "几个": "COUNT(*)",
    "总计": "SUM", "总额": "SUM", "合计": "SUM", "总和": "SUM",
    "平均": "AVG", "均值": "AVG", "平均值": "AVG",
    "最大": "MAX", "最高": "MAX", "最多": "MAX",
    "最小": "MIN", "最低": "MIN", "最少": "MIN",
}


def _detect_table(query: str) -> str:
    for keyword, table in TABLE_MAP.items():
        if keyword in query:
            return table
    return "customers"


def _detect_aggregation(query: str, table: str) -> tuple:
    for keyword, func in AGG_MAP.items():
        if keyword in query:
            if func == "COUNT(*)":
                return True, "COUNT(*)", None
            # 找聚合字段
            default_fields = {
                "customers": "total_premium", "policies": "premium",
                "claims": "claim_amount", "premiums": "amount",
            }
            field = None
            for fk, fn in FIELD_MAP.get(table, {}).items():
                if fk in query:
                    field = fn
                    break
            if not field:
                field = default_fields.get(table, "*")
            return True, func, field
    return False, None, None


def _detect_group_by(query: str, table: str) -> str:
    triggers = ["按", "每个", "各", "分别", "group by", "各个"]
    if not any(t in query for t in triggers):
        return None
    group_keywords = {
        "城市": "city", "地区": "city", "类型": "policy_type",
        "等级": "customer_level", "级别": "customer_level",
        "状态": "status", "性别": "gender",
        "支付方式": "payment_method", "缴费方式": "payment_method",
    }
    for kw, field in group_keywords.items():
        if kw in query:
            return field
    # 时间分组
    date_field_map = {
        "customers": "registration_date", "policies": "start_date",
        "claims": "claim_date", "premiums": "payment_date",
    }
    df = date_field_map.get(table)
    if df:
        if "月" in query or "月份" in query:
            return f"DATE_FORMAT({df}, '%Y-%m')"
        if "年" in query:
            return f"YEAR({df})"
    return None


def _detect_conditions(query: str, table: str) -> list:
    conditions = []
    # 状态
    status_patterns = [
        (r"(?:有效|生效|active)", "active"),
        (r"(?:过期|失效|expired)", "expired"),
        (r"(?:待处理|pending)", "pending"),
        (r"(?:已完成|completed|已结案|已赔付)", "completed"),
        (r"(?:已拒绝|rejected|拒赔)", "rejected"),
        (r"(?:已取消|cancelled|canceled)", "cancelled"),
    ]
    for pat, val in status_patterns:
        if re.search(pat, query):
            conditions.append(f"status = '{val}'")
            break
    # 通用字段=值
    generic = [
        (r"城市(?:为|是|在|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。|的)", "city"),
        (r"性别(?:为|是|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "gender"),
        (r"(?:等级|级别)(?:为|是|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "customer_level"),
        (r"(?:保单)?类型(?:为|是|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "policy_type"),
        (r"(?:姓名|名字)(?:为|是|叫)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "name"),
    ]
    for pat, field in generic:
        m = re.search(pat, query)
        if m:
            conditions.append(f"{field} = '{m.group(1)}'")
    # 数值比较
    numeric_fields = ["total_premium", "premium", "claim_amount", "amount"]
    cmp_ops = [
        (r"(?:大于|超过|高于)\s*(\d+(?:\.\d+)?)", ">"),
        (r"(?:小于|低于|少于|不足)\s*(\d+(?:\.\d+)?)", "<"),
        (r"(?:大于等于|不小于|至少)\s*(\d+(?:\.\d+)?)", ">="),
        (r"(?:小于等于|不大于|不超过|至多)\s*(\d+(?:\.\d+)?)", "<="),
    ]
    for fk, fn in FIELD_MAP.get(table, {}).items():
        if fn in numeric_fields:
            for pat, op in cmp_ops:
                full_pat = f"{re.escape(fk)}\\s*{pat}"
                m = re.search(full_pat, query)
                if m:
                    conditions.append(f"{fn} {op} {m.group(1)}")
    # 最近X天/月/年
    date_field_map = {
        "customers": "registration_date", "policies": "start_date",
        "claims": "claim_date", "premiums": "payment_date",
    }
    df = date_field_map.get(table)
    if df:
        m = re.search(r"(?:最近|过去)\s*(\d+)\s*(天|月|年)", query)
        if m:
            num, unit = m.group(1), m.group(2)
            u = {"天": "DAY", "月": "MONTH", "年": "YEAR"}[unit]
            conditions.append(f"{df} >= DATE_SUB(NOW(), INTERVAL {num} {u})")
    return conditions


def _detect_order(query: str, table: str) -> str:
    direction = "DESC" if any(k in query for k in ["降序", "从高到低", "从大到小", "倒序"]) else "ASC"
    if any(k in query for k in ["升序", "从低到高", "从小到大", "正序"]):
        direction = "ASC"
    for fk, fn in FIELD_MAP.get(table, {}).items():
        if f"按{fk}" in query or f"根据{fk}" in query:
            return f"{fn} {direction}"
    defaults = {
        "customers": "registration_date DESC", "policies": "start_date DESC",
        "claims": "claim_date DESC", "premiums": "payment_date DESC",
    }
    return defaults.get(table)


def _detect_limit(query: str) -> str:
    m = re.search(r"(?:前|限制|只显示|只要|最多|top)\s*(\d+)", query, re.IGNORECASE)
    if m:
        return f" LIMIT {m.group(1)}"
    return " LIMIT 100"


def nlp_to_sql_builtin(natural_language: str) -> dict:
    """使用内置规则引擎将自然语言转换为SQL"""
    query = natural_language.lower().strip()
    table = _detect_table(query)
    is_agg, agg_func, agg_field = _detect_aggregation(query, table)
    group_by = _detect_group_by(query, table)
    conditions = _detect_conditions(query, table)
    order_by = _detect_order(query, table)
    limit = _detect_limit(query)

    if is_agg:
        if agg_func == "COUNT(*)":
            select = f"{'%s, ' % group_by if group_by else ''}COUNT(*) as count"
        else:
            select = f"{'%s, ' % group_by if group_by else ''}{agg_func}({agg_field}) as value"
        sql = f"SELECT {select} FROM {table}"
    else:
        sql = f"SELECT * FROM {table}"

    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    if group_by:
        sql += f" GROUP BY {group_by}"
    if order_by and not group_by:
        sql += f" ORDER BY {order_by}"
    sql += limit

    return {"sql": sql, "method": "builtin"}


# ============================
# 主入口 - 现在只提供SQL验证功能
# ============================

def get_database_schema_info() -> str:
    """
    获取数据库结构信息，供外部系统（如大模型）使用
    """
    return SCHEMA_INFO


def suggest_sql_for_question(question: str) -> dict:
    """
    基于规则的SQL建议生成（简化版本）
    注意：此函数仅作演示用途，实际应用中应由主模型处理NLP到SQL的转换

    Args:
        question: 用户的问题

    Returns:
        包含SQL建议和说明的字典
    """
    # 这只是一个简单的示例，实际生产环境中应该移除此函数
    # 因为NLP到SQL的转换应在主模型中完成
    return {
        "status": "not_implemented",
        "message": "NLP到SQL的转换应在主模型（如百炼平台的大模型）中实现，而非在此MCP服务中。",
        "suggestion": "请在主模型中结合get_database_schema()获取的数据库结构来生成适当的SQL查询"
    }
