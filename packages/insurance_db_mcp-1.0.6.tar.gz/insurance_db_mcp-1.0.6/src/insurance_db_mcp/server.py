"""
Insurance DB MCP Server - 通过自然语言操作保险数据库的MCP工具

支持通过 uv 方式加载：
  uvx insurance-db-mcp
  或
  uv run insurance-db-mcp
"""
import json
import os
import logging

from mcp.server.fastmcp import FastMCP

from insurance_db_mcp.db import execute_query, test_connection, get_table_stats, SCHEMA_INFO, JSONEncoder
from insurance_db_mcp.nlp_to_sql import nlp_to_sql

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("insurance-db-mcp")

# 创建MCP Server
mcp = FastMCP(
    "insurance-db-mcp",
    instructions="通过自然语言操作保险数据库的MCP工具。支持自然语言查询、SQL执行、数据库Schema查看等功能。",
)




# ============================
# MCP Tools 定义
# ============================


@mcp.tool()
async def query_by_natural_language(question: str) -> str:
    """
    通过自然语言查询保险数据库。此工具已弃用，请使用execute_sql_query工具直接执行SQL查询，
    或让主模型根据get_database_schema()返回的结构自行生成SQL。

    Args:
        question: 自然语言查询问题（此参数将被忽略）
    """
    return json.dumps({
        "success": False,
        "error": "此工具已弃用。请使用execute_sql_query工具执行SQL查询，或结合get_database_schema()获取数据库结构后自行构造SQL。",
        "suggestion": "建议在主模型中实现NLP到SQL的转换逻辑"
    }, ensure_ascii=False, indent=2)


@mcp.tool()
async def execute_sql_query(sql: str) -> str:
    """
    直接执行SQL查询语句。适用于需要精确控制SQL的场景。

    支持SELECT/INSERT/UPDATE/DELETE等所有SQL操作。

    Args:
        sql: 要执行的SQL语句
    """
    try:
        result = execute_query(sql)
        return json.dumps(result, ensure_ascii=False, indent=2, cls=JSONEncoder)
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e),
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_database_schema() -> str:
    """
    获取数据库的完整结构信息，包括所有表名、字段名、字段类型及表之间的关联关系。
    在进行数据库查询前，建议先调用此工具了解数据库结构。
    """
    return SCHEMA_INFO


@mcp.tool()
async def get_database_stats() -> str:
    """
    获取数据库各表的数据统计概览，包括每张表的记录数量。
    可以快速了解数据库的整体数据规模。
    """
    try:
        stats = get_table_stats()
        connected = test_connection()
        result = {
            "connected": connected,
            "database": "insurance_db",
            "tables": stats,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e),
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_table_sample(table_name: str, limit: int = 5) -> str:
    """
    获取指定表的样本数据，帮助了解数据格式和内容。

    Args:
        table_name: 表名，可选值: customers, policies, claims, premiums
        limit: 返回的样本数量，默认5条
    """
    valid_tables = ["customers", "policies", "claims", "premiums"]
    if table_name not in valid_tables:
        return json.dumps({
            "success": False,
            "error": f"无效的表名: {table_name}。可选值: {', '.join(valid_tables)}",
        }, ensure_ascii=False, indent=2)

    try:
        limit = min(limit, 50)  # 最多50条
        sql = f"SELECT * FROM {table_name} LIMIT {limit}"
        result = execute_query(sql)
        return json.dumps(result, ensure_ascii=False, indent=2, cls=JSONEncoder)
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e),
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def test_db_connection() -> str:
    """
    测试数据库连接是否正常。在执行任何数据库操作前，建议先调用此工具确认连接状态。
    """
    try:
        connected = test_connection()
        return json.dumps({
            "success": True,
            "connected": connected,
            "message": "数据库连接正常" if connected else "数据库连接失败",
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "connected": False,
            "error": str(e),
        }, ensure_ascii=False, indent=2)


# ============================
# MCP Resources 定义
# ============================

@mcp.resource("insurance-db://schema")
async def get_schema_resource() -> str:
    """数据库Schema资源"""
    return SCHEMA_INFO


@mcp.resource("insurance-db://stats")
async def get_stats_resource() -> str:
    """数据库统计信息资源"""
    try:
        stats = get_table_stats()
        return json.dumps({
            "database": "insurance_db",
            "tables": stats,
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# ============================
# 主入口
# ============================

def main():
    """MCP Server主入口 - 通过stdio传输"""
    logger.info("Insurance DB MCP Server starting...")
    logger.info("Database: 43.143.125.184:23306/insurance_db")
    logger.info("Ready to serve database queries via MCP protocol")
    mcp.run()


if __name__ == "__main__":
    main()
