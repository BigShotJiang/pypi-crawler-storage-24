"""Insurance DB MCP Tool - 通过自然语言操作保险数据库的MCP工具"""
__version__ = "1.0.0"
