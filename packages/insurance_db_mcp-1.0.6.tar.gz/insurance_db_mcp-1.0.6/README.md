# Insurance DB MCP Tool

通过自然语言操作保险数据库的MCP工具。

## 功能特性

- ✅ **自然语言查询**：用中文描述查询需求，自动转换为SQL
- ✅ **SQL直接执行**：支持直接执行SQL语句
- ✅ **数据库Schema查看**：获取完整的数据库结构信息
- ✅ **数据统计**：快速了解各表的数据规模
- ✅ **样本数据预览**：查看表的样本数据
- ✅ **双模式NLP引擎**：内置规则引擎 + 可选LLM增强

## 安装

```bash
# 使用 uv 安装
uv pip install -e .
```

## 使用方式

### 1. 作为 MCP Server 运行

```bash
# 方式1: 使用 uvx 直接运行
uvx insurance-db-mcp

# 方式2: 在项目中使用
uv run insurance-db-mcp
```

### 2. 在 Claude Desktop 中配置

编辑 `claude_desktop_config.json`：

```json
{
  "mcpServers": {
    "insurance-db": {
      "command": "uvx",
      "args": ["insurance-db-mcp"]
    }
  }
}
```

### 3. 启动HTTP文档服务器

```bash
python -m insurance_db_mcp.web
```

访问 http://localhost:3000 查看完整文档。

## MCP 工具列表

| 工具名 | 说明 |
|--------|------|
| `query_by_natural_language` | 通过自然语言查询数据库 |
| `execute_sql_query` | 直接执行SQL查询 |
| `get_database_schema` | 获取数据库结构信息 |
| `get_database_stats` | 获取数据库统计信息 |
| `get_table_sample` | 获取表的样本数据 |
| `test_db_connection` | 测试数据库连接 |

## 自然语言查询示例

- "查询所有北京的客户"
- "统计每个城市有多少客户"
- "查看状态为有效的保单"
- "最近30天的理赔记录"
- "总保费超过10000的客户"
- "每种保单类型的平均保费"
- "VIP客户的理赔总额"

## 数据库结构

### customers (客户信息表)
- customer_id: 客户ID
- name: 客户姓名
- gender: 性别
- birth_date: 出生日期
- city: 城市
- registration_date: 注册日期
- customer_level: 客户等级
- total_premium: 总保费

### policies (保单信息表)
- policy_id: 保单ID
- customer_id: 客户ID
- policy_type: 保单类型
- premium: 保费
- start_date: 起始日期
- end_date: 结束日期
- status: 状态

### claims (理赔记录表)
- claim_id: 理赔ID
- policy_id: 保单ID
- customer_id: 客户ID
- claim_amount: 理赔金额
- claim_date: 理赔日期
- status: 状态

### premiums (缴费记录表)
- premium_id: 缴费ID
- policy_id: 保单ID
- customer_id: 客户ID
- amount: 缴费金额
- payment_date: 缴费日期
- payment_method: 支付方式

## LLM 配置（可选）

如需使用LLM增强NLP转SQL能力，可设置环境变量：

```bash
export LLM_API_URL="https://api.openai.com/v1/chat/completions"
export LLM_API_KEY="your-api-key"
export LLM_MODEL="gpt-3.5-turbo"
```

## 开发

```bash
# 安装开发依赖
uv pip install -e ".[dev]"

# 运行测试
pytest
```

## 许可证

MIT