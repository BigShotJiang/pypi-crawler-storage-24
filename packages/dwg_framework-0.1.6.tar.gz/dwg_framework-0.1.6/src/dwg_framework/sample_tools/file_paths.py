import tomlkit
from pathlib import Path

from .constants import DEFAULT_TOML_FILE, DEFAULT_LOCAL_SAMPLE_DIR

_THIS_DIR = Path(__file__).resolve().parent

def _safe_toml_write(data: dict, toml_path): # this is because I freaking wiped out my toml using tomli_w.dump() and having a crash at the same time
    tmp_path = toml_path.with_suffix(".toml.tmp")
    with open(tmp_path, "w") as f:
        tomlkit.dump(data, f)
    tmp_path.replace(toml_path)

def _get_toml_path(toml_file: str):
    toml_path = _THIS_DIR / toml_file
    return toml_path
    
def _get_save_dir_path(save_dir_name: str, dataset: str, make_dir=True):
    home = Path.home()
    save_dir = home / save_dir_name / dataset
    if make_dir:
        save_dir.mkdir(parents=True, exist_ok=True)
    return save_dir

def _get_toml_and_save_dir_paths(dataset: str, save_dir_name: str, toml_file: str, make_dir=True):
    toml_path = _get_toml_path(toml_file)
    save_dir = _get_save_dir_path(save_dir_name, dataset, make_dir)
    return toml_path, save_dir

def dump_dataset_names(toml_file: str = DEFAULT_TOML_FILE):
    """
    prints all dataset names in our dataset toml to terminal 
    """
    toml_path = _get_toml_path(toml_file)

    with open(toml_path, "r") as f:
        open_toml = tomlkit.load(f)

    dataset_keys = []
    
    for key in open_toml.keys():
        if key == "cern_redirector" or key == "lpc_redirector" or key == "metadata_keys":
            continue
        dataset_keys.append(key)
    
    print(dataset_keys)

def _update_local_file(dataset: str, save_dir_name: str, toml_file: str):

    toml_path, save_dir_path = _get_toml_and_save_dir_paths(dataset, save_dir_name, toml_file)

    with open(toml_path, "r") as f:
        open_toml = tomlkit.load(f)

    #check that save_dir_path == whats stored in toml:

    stored_local_path = open_toml[dataset]['local_path'] # type: ignore

    if stored_local_path != str(save_dir_path):
        print(f"saved local_path in {dataset} does not match provided save_dir_name (which could be the default path), please check.")
        return
    
    if not save_dir_path.exists():
        print(f"Directory {save_dir_path} does not exist, nothing to update.")
        return
    
    true_local_files = [f.name for f in save_dir_path.iterdir() if f.suffix == ".root"]

    if true_local_files == list(open_toml[dataset]['local_files']): # type: ignore
        print(f"true local_files match stored local_files list for {dataset}")
        print("nothing to do")
        return
    
    else:
        open_toml[dataset]['local_files'] = true_local_files # type: ignore
        

    _safe_toml_write(open_toml, toml_path)
    print(f"Updated local_files for {dataset}: {true_local_files}")
    return

def update_local_files(datasets: list[str], save_dir_name: str=DEFAULT_LOCAL_SAMPLE_DIR, toml_file: str=DEFAULT_TOML_FILE):
    for dataset in datasets:
        _update_local_file(dataset, save_dir_name, toml_file)

def _get_redirector(open_toml: dict, dataset: str): # this is after you've filtered to a single dataset entry
    if open_toml[dataset]["pref_redirector"] == "cern":
        redirector = open_toml["cern_redirector"]
    elif open_toml[dataset]["pref_redirector"] == "lpc":
        redirector = open_toml["lpc_redirector"]
    else:
        raise ValueError(f"Unknown redirector '{open_toml[dataset]['pref_redirector']}' for dataset {dataset}")
    return redirector

if __name__ == "__main__":
    dump_dataset_names()