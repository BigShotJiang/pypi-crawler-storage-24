import tomlkit
import subprocess
from pathlib import Path

from .file_paths import _get_toml_path, _get_toml_and_save_dir_paths, _safe_toml_write, dump_dataset_names, _get_redirector
from .query_DAS import _das_query

from constants import DEFAULT_TOML_FILE, DEFAULT_LOCAL_SAMPLE_DIR, DEFAULT_TXT_FILE_DIR

_THIS_DIR = Path(__file__).resolve().parent

def _make_txt_file(dataset: str, txt_dir_name=DEFAULT_TXT_FILE_DIR, toml_file=DEFAULT_TOML_FILE):
    
    toml_path = _get_toml_path(toml_file)

    with open(toml_path, "r") as f:
        open_toml = tomlkit.load(f)

    if dataset not in open_toml:
        print(f"Dataset '{dataset}' not found in {toml_path}")
        return
    
    name_on_DAS = open_toml[dataset]['name_on_DAS'] # type: ignore

    das_query = _das_query(name_on_DAS) # type: ignore

    txt_dir_path = _THIS_DIR / txt_dir_name
    txt_file_path = txt_dir_path / f"{dataset}.txt"
    
    with open(txt_file_path, "w") as f:
        for line in das_query:
            f.write(f"{line}\n")
    
    #open_toml[dataset]['DAS_txt_file'] = txt_file_path
    open_toml[dataset]['DAS_txt_file'] = str(txt_file_path) # type: ignore

    #with open(toml_path, "wb") as f:
    #    tomli_w.dump(open_toml, f)

    _safe_toml_write(open_toml, toml_path)

def make_text_files(datasets: str, txt_dir_name=DEFAULT_TXT_FILE_DIR, toml_file=DEFAULT_TOML_FILE): # can run this to only make the text files and not download locally
    
    for dataset in datasets:
        _make_txt_file(dataset, txt_dir_name, toml_file)
        print(f"saved .txt file for {dataset} in {DEFAULT_TXT_FILE_DIR}")

def _download_to_local(dataset: str, save_dir_name=DEFAULT_LOCAL_SAMPLE_DIR, toml_file=DEFAULT_TOML_FILE, txt_files_only:bool = False):
    """
    accesses the saved redirector from toml, gets DAS remote paths from txt file, and local path you want to save it to
    combines redirector and remote paths and loops over all paths while calling 
    """

    _make_txt_file(dataset, txt_dir_name=DEFAULT_TXT_FILE_DIR, toml_file=DEFAULT_TOML_FILE)

    if txt_files_only:
        print(f"Finished making text files at {DEFAULT_TXT_FILE_DIR}.")
        return

    toml_path, save_dir = _get_toml_and_save_dir_paths(dataset, save_dir_name, toml_file)


    with open(toml_path, "r") as f:
        open_toml = tomlkit.load(f)

    if dataset not in open_toml:
        print(f"Dataset '{dataset}' not found in {toml_path}")
        return

    #das_file_list = open_toml[dataset]["das_files"]
    #moving to getting this information from the text file

    txt_file_path = open_toml[dataset]['DAS_txt_file'] # type: ignore

    with open(txt_file_path) as f: # type: ignore
        file_list = f.read().splitlines()

    print(file_list) #debug

    red = _get_redirector(open_toml, dataset)

    #home = Path.home()
    print(f"Downloading to {str(save_dir)}...")

    if open_toml[dataset]["download_all"]: # type: ignore
        files_to_download = file_list
    else:
        files_to_download = file_list[:open_toml[dataset]["num_to_download"]] # type: ignore

    save_dir.mkdir(parents=True, exist_ok=True)

    for file in files_to_download:

        full_path = red + file

        filename = Path(file).name # get just the root file name
        dest = save_dir / filename
        print(f"Downloading {filename}...")

        if not dest.exists():
            subprocess.run(["xrdcp", full_path, dest], check=True)
        else:
            print(f"Skipping {dest.name}, already exists")
    
        if filename not in open_toml[dataset]["local_files"]: # type: ignore
            open_toml[dataset]["local_files"].append(filename) # type: ignore # update this list because may not download all the files available on DAS
    open_toml[dataset]["local_path"] = str(save_dir) # type: ignore
    #with open(toml_path, "wb") as f:
    #    tomli_w.dump(open_toml, f)

    _safe_toml_write(open_toml, toml_path)

    print("Finished running.")


def download_ds_to_local(datasets: str, save_dir_name=DEFAULT_LOCAL_SAMPLE_DIR, toml_file=DEFAULT_TOML_FILE, txt_files_only:bool = False):
    
    for dataset in datasets:
        _download_to_local(dataset, save_dir_name, toml_file, txt_files_only)

if __name__ == "__main__":
    dump_dataset_names() 