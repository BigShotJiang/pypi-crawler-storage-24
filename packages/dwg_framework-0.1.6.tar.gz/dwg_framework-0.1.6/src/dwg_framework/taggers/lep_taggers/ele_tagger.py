from .common import global_tight_sip3d
from .vid_unpacked import loose_minus_iso_hoe, tight_minus_iso_hoe
import numpy as np
import awkward as ak

def tag_ele_quality(ele, is_UL=False):  # use on raw Electron collection (Awkward array)
    
    """
    Add 'isGold', 'isSilver', 'isBronze' boolean field to events.Electron based on cuts.
    Add 'qual_tag' integer field to events.Electron, binary numbers
    """

    # define variables
    abs_eta   = np.abs(ele.eta)
    abs_dxy   = np.abs(ele.dxy)
    abs_dz    = np.abs(ele.dz)
    pt        = ele.pt
    iso03pt   = ele.pfRelIso03_all * pt
    miniIsoPt = ele.miniPFRelIso_all * pt

    # --- Baseline selection ---
    baseline_mask = (
        (pt >= 7)
        & ( ((pt >= 10) & (abs_eta < 2.5)) | ((pt < 10) & (abs_eta < 1.442)) )
        & (ele.sip3d < 6)
        & (abs_dxy < 0.05)
        & (abs_dz  < 0.1)
        & (iso03pt   < (20 + 300/pt))
        & (miniIsoPt < (20 + 300/pt))
        & (ele.lostHits == 0)
        & (ele.convVeto == 1) #added this for regular electrons, see how it works
        & loose_minus_iso_hoe(ele)
    )

    # --- Quality tags ---

    low_pt_pass = (
        (pt < 20)
        & (iso03pt <= 4)
        & (miniIsoPt <= 4)
        & tight_minus_iso_hoe(ele)
    )

    if is_UL == False:
        high_pt_pass = (
            (pt >= 20)
            & ele.mvaIso_WP90
        )

    if is_UL == True:
        high_pt_pass = (
            (pt >= 20)
            & ele.mvaFall17V2Iso_WP90
        )


    gold_silver_mask = baseline_mask & (low_pt_pass | high_pt_pass)
    
    
    gold_mask = (
        gold_silver_mask
        & (ele.sip3d < global_tight_sip3d)
    )

    silver_mask = (
        gold_silver_mask
        & (ele.sip3d >= global_tight_sip3d)
    )

    bronze_mask = baseline_mask & ~gold_silver_mask

    
    # Add quality masks
    ele = ak.with_field(ele, ~baseline_mask, 'isFail')
    ele = ak.with_field(ele, baseline_mask, 'isBaseline')
    ele = ak.with_field(ele, gold_mask, 'isGold')
    ele = ak.with_field(ele, silver_mask, 'isSilver')
    ele = ak.with_field(ele, bronze_mask, 'isBronze')

    # Used to have an 'isBaseline' but its redundant since you can add isGold, isSilver, isBronze to get baseline.
    # Assuming my categories are correctly mutually exclusive
    
    # Create qual_tag int for convenient histogram filling
    #qual_tag = ak.full_like(ele.pt, -1, dtype=int)
    #qual_tag = ak.where(ele.isBronze, 1, qual_tag)
    #qual_tag = ak.where(ele.isSilver, 10, qual_tag)
    #qual_tag = ak.where(ele.isGold, 100, qual_tag)
    
    #ele = ak.with_field(ele, qual_tag, "qual_tag")


    ### New masks here!!

    
    if is_UL:
        ID_mask = ak.where(pt >= 20, ele.mvaFall17V2Iso_WP90, tight_minus_iso_hoe(ele))
    else:
        ID_mask = ak.where(pt >= 20, ele.mvaIso_WP90, tight_minus_iso_hoe(ele))
    
    tight_ID = baseline_mask & ID_mask
    
    tight_SIP3D = baseline_mask & (ele.sip3d < global_tight_sip3d)
    
    tight_ISO = baseline_mask & (miniIsoPt <= 4) & (iso03pt <= 4)
    
    ele = ak.with_field(ele, tight_ID, 'tight_ID')
    ele = ak.with_field(ele, tight_SIP3D, 'tight_SIP3D')
    ele = ak.with_field(ele, tight_ISO, 'tight_ISO')

    #qual_tag = ak.where(ele.tight_ID, 20, qual_tag)
    #qual_tag = ak.where(ele.tight_SIP3D, 200, qual_tag)
    #qual_tag = ak.where(ele.tight_ISO, 2000, qual_tag)
    
    #ele = ak.with_field(ele, qual_tag, "qual_tag")

    return ele