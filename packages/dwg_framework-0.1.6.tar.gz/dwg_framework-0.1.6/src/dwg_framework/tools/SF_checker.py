from .calculations import *

def check_SF(
    truth: tuple[tuple, tuple],          # ((h1_num, h1_denom), (h2_num, h2_denom)), SF = eff1/eff2
    comparisons: list[tuple[tuple, tuple]], # [((num, denom), (num, denom)), ...] each entry is one SF, all multiplied together should equal truth
):

    truth_SF, truth_err = scale_factor_with_error_from_hists(truth[0], truth[1])
    
    combined_SF = None
    combined_err = None
    for comp in comparisons:
        sf, err = scale_factor_with_error_from_hists(comp[0], comp[1])
        if combined_SF is None:
            combined_SF = sf
            combined_err = err
        else:
            # error propagation for multiplication
            combined_err = combined_SF.values() * sf.values() * np.sqrt((combined_err/combined_SF.values())**2 + (err/sf.values())**2)
            combined_SF = combined_SF * sf

    return {"truth_SF": truth_SF,
           "truth_err": truth_err,
           "combined_SF": combined_SF,
           "combined_err": combined_err}

def check_SF_dict(
    truth: tuple[tuple, tuple],          # ((h1_num, h1_denom), (h2_num, h2_denom)), SF = eff1/eff2
    comparisons: list[tuple[tuple, tuple]],# [((num, denom), (num, denom)), ...] each entry is one SF, all multiplied together should equal truth
    cut_names: list[str] = None
):

    truth_SF, truth_err = scale_factor_with_error_from_hists(truth[0], truth[1])

    SF_dict = {}
    combined_SF = None
    combined_err = None
    for i, comp in enumerate(comparisons):
        sf, err = scale_factor_with_error_from_hists(comp[0], comp[1])
        if cut_names is None:
            SF_dict[i] = (sf, err)
        else:
            SF_dict[cut_names[i]] = (sf, err)
        if combined_SF is None:
            combined_SF = sf
            combined_err = err
        else:
            # error propagation for multiplication
            combined_err = combined_SF.values() * sf.values() * np.sqrt((combined_err/combined_SF.values())**2 + (err/sf.values())**2)
            combined_SF = combined_SF * sf

    return {
        "truth_SF": truth_SF,
        "truth_err": truth_err,
        "SF_dict": SF_dict,
        "combined_SF": combined_SF,
        "combined_err": combined_err
    }