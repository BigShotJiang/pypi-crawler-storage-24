import numpy as np

def two_d_eff_err(h_num, h_denom): # h_num and h_denom must have same binning in both dimensions

    eff_h = h_num/h_denom # Creating a histogram
    
    err_h = np.sqrt(eff_h.values() * (1 - eff_h.values())/ h_denom.values())

    return eff_h, err_h

def scale_factor_with_error_from_hists(h1_tuple: tuple, h2_tuple: tuple):
    
    eff_1, err_1 = two_d_eff_err(h1_tuple[0], h1_tuple[1])
    eff_2, err_2 = two_d_eff_err(h2_tuple[0], h2_tuple[1])
    
    sf = eff_1 / eff_2
    
    sf_err = sf.values() * np.sqrt((err_1/eff_1.values())**2 + (err_2/eff_2.values())**2)
    
    return sf, sf_err