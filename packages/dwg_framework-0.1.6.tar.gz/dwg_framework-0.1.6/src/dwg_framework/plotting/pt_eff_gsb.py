import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import mplhep
import numpy as np
import os


def make_AN_1d_pt_eff(signal, 
                      fakes, 
                      name="default_name", 
                      title=None, 
                      plot_txt=None, 
                      savefig=False,
                      plot_directory = "plots",
                      lepton_type="Electron",
                      com=13.6, 
                      max_pt=100, 
                      log_scale=False,
                      marker_size = 14,
                      cap_size = 11,
                      fake_label="Misidentified",
                      residual=False):
    
    fig, ax = plt.subplots(figsize=(25, 12))
    # signal and fakes are 4-axis: [pt, pt_long, eta, qual]
    # Integrate over pt and eta to get [pt_long, qual] for plotting
    
    #signal = signal.integrate("pt").integrate("eta")
    #fakes = fakes.integrate("pt").integrate("eta")

    #NO, now we do just a 2 axis of histogram, "pt" and "qual"

    
    # This block is to remove 0-efficiency points, essentially empty values in the histograms
    min_pt = 0
    
    if lepton_type == "Electron":
        min_pt = 2 # the binning of my hists conveniently lines up with the pt we are removing
    if lepton_type == "Muon":
        min_pt = 3

    signal  = signal[min_pt:, :]
    fakes = fakes[min_pt:, :]
    
    #end block of removing 0 eff leptons
        
    
    sig_gold = signal[:, 100j]
    sig_silver = signal[:, 10j]
    sig_bronze = signal[:, 1j]
    
    fake_gold = fakes[:, 100j]
    fake_silver = fakes[:, 10j]
    fake_bronze = fakes[:, 1j]
    
    sig_baseline = (sig_bronze + sig_silver + sig_gold)
    fake_baseline = (fake_bronze + fake_silver + fake_gold)
    
    sig_gold_eff_err = calc_eff_err(sig_gold, sig_baseline) 
    sig_silver_eff_err = calc_eff_err(sig_silver, sig_baseline)
    sig_bronze_eff_err = calc_eff_err(sig_bronze, sig_baseline)
    fake_gold_eff_err = calc_eff_err(fake_gold, fake_baseline)
    fake_silver_eff_err = calc_eff_err(fake_silver, fake_baseline)
    fake_bronze_eff_err = calc_eff_err(fake_bronze, fake_baseline)
    
    edges = signal.axes[0].edges
    xes = (edges[:-1] + edges[1:]) * 0.5
    
    plt.errorbar(xes, y=sig_gold_eff_err[0], yerr=sig_gold_eff_err[1], fmt='o', markersize=marker_size, capsize=cap_size, color='darkorange')
    plt.errorbar(xes, y=sig_silver_eff_err[0], yerr=sig_silver_eff_err[1], fmt='o', markersize=marker_size, capsize=cap_size, color='dodgerblue')
    plt.errorbar(xes, y=sig_bronze_eff_err[0], yerr=sig_bronze_eff_err[1], fmt='o', markersize=marker_size, capsize=cap_size, color='firebrick')
    
    plt.errorbar(xes, y=fake_gold_eff_err[0], yerr=fake_gold_eff_err[1], fmt='s', mfc='none', markersize=marker_size, capsize=cap_size, color='darkorange')
    plt.errorbar(xes, y=fake_silver_eff_err[0], yerr=fake_silver_eff_err[1], fmt='s', mfc='none', markersize=marker_size, capsize=cap_size, color='dodgerblue')
    plt.errorbar(xes, y=fake_bronze_eff_err[0], yerr=fake_bronze_eff_err[1], fmt='s', mfc='none', markersize=marker_size, capsize=cap_size, color='firebrick')
    
    # X-axis settings (always linear)
    plt.xlim(0, max_pt)
    # Adjust xticks based on max_pt
    if max_pt <= 30:
        plt.xticks([5, 10, 15, 20, 25, 30], fontsize=40)
    elif max_pt <= 50:
        plt.xticks([10, 20, 30, 40, 50], fontsize=40)
    else:
        plt.xticks([20, 40, 60, 80, 100], fontsize=40)
    
    plt.xlabel(f"{lepton_type} $p_T$ [GeV]", fontsize=40)
    
    # Y-axis settings - handle log scale vs linear scale
    if log_scale:
        plt.yscale('log')
        plt.ylim(0.001, 1.0)  # Log scale needs to avoid 0
    else:
        plt.ylim(0, 1.0)
    
    #plt.yticks(fontsize=40)
    plt.ylabel(f"Quality Assignment Efficiency", fontsize=40, labelpad = 20)
    plt.tick_params(axis='both', which='both', right=True, labelright=True, size=30)
    plt.yticks(fontsize=30)
    plt.grid(visible=None, which='major', axis='y', linewidth=2.0)
    
    if lepton_type.lower() == "electron":
        plt.axvline(x=7, linestyle='dotted', color='black', linewidth=1.5)
        plt.axvline(x=20, linestyle='dotted', color='black', linewidth=1.5)
    
    #mplhep.cms.label(loc=0, fontsize=30, com=com)
    mplhep.cms.text("Work in Progress", fontsize=40, loc=0)
    
    if plot_txt is not None:
        # Use axes coordinates for positioning
        plt.text(0.7, 1.055, plot_txt,
                 fontsize=35,
                 color='black',
                 ha='center',
                 va='top',
                 transform=ax.transAxes,
                 rotation=0,
                 weight='bold'
                )
    
    if title is not None:
        plt.title(title, fontsize=45, pad=40)
    
    handles = [
        Line2D([0], [0], marker='s', color='firebrick', label='Bronze', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='dodgerblue', label='Silver', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='darkorange', label='Gold', markersize=25, linestyle=''),
        Line2D([0], [0], marker='o', color='black', label='Prompt', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='black', label=fake_label, mfc='none', markersize=25, linestyle='')
    ]
    
    fig.legend(
        handles=handles,
        loc='center left',
        bbox_to_anchor=(0.95, 0.5),
        fontsize=30,
        ncol=1,
        frameon=True,
        facecolor='white',
        edgecolor='black',
        framealpha=1
    )
    
    if savefig:
        os.makedirs(plot_directory, exist_ok=True)
        suffix = "_log" if log_scale else ""
        suffix = suffix + "_" + str(max_pt) + "GeV"
        plt.savefig(f"{plot_directory}/eff_plot_{name}{suffix}.pdf", bbox_inches='tight')
    #plt.close() #cannot close and then return, must close outside of this return
    return fig, ax



def calc_eff_err(hist_1, hist_2): #hist_2 is the denominator of the efficiency

    
    num = hist_1.values()
    denom = hist_2.values()
    
    eff = num/denom
    err = np.sqrt(eff * (1 - eff)/ denom)

    filtered_eff = np.nan_to_num(eff, nan=0).tolist()
    filtered_err = np.nan_to_num(err, nan=0).tolist()
        
    return filtered_eff, filtered_err


def make_1d_pt_eff_comparison_gsb(
    hist1,
    hist2,
    name="default_name",
    raw_collection=False,
    title=None,
    plot_txt=None,
    savefig=False,
    plot_directory = "plots",
    lepton_type="Electron",
    com=13.6,
    max_pt=100,
    log_scale=False,
    marker_size = 14,
    cap_size = 11):
    
    fig, ax = plt.subplots(figsize=(25, 12))
    # signal and fakes are 4-axis: [pt, pt_long, eta, qual]
    # Integrate over pt and eta to get [pt_long, qual] for plotting
    
    #hist1 = hist1.integrate("pt").integrate("eta").integrate("eta_long")
    #hist2 = hist2.integrate("pt").integrate("eta").integrate("eta_long")

    
    # This block is to remove 0-efficiency points, essentially empty values in the histograms
    min_pt = 0
    
    if lepton_type == "Electron":
        min_pt = 2 # the binning of my hists conveniently lines up with the pt we are removing
    if lepton_type == "Muon":
        min_pt = 3

    hist1  = hist1[min_pt:, :]
    hist2 = hist2[min_pt:, :]
    
    #end block of removing 0 eff leptons
        

    
    hist1_gold = hist1[:, 100j]
    hist1_silver = hist1[:, 10j]
    hist1_bronze = hist1[:, 1j]
    hist1_fail = hist1[:, -1j]
    
    hist2_gold = hist2[:, 100j]
    hist2_silver = hist2[:, 10j]
    hist2_bronze = hist2[:, 1j]
    hist2_fail = hist2[:, -1j]

    if not raw_collection:
        hist1_baseline = (hist1_gold + hist1_silver + hist1_bronze)
        hist2_baseline = (hist2_gold + hist2_silver + hist2_bronze)

    if raw_collection:
        hist1_baseline = (hist1_gold + hist1_silver + hist1_bronze + hist1_fail)
        hist2_baseline = (hist2_gold + hist2_silver + hist2_bronze + hist2_fail)
    
    hist1_gold_eff_err = calc_eff_err(hist1_gold, hist1_baseline) 
    hist1_silver_eff_err = calc_eff_err(hist1_silver, hist1_baseline)
    hist1_bronze_eff_err = calc_eff_err(hist1_bronze, hist1_baseline)
    
    hist2_gold_eff_err = calc_eff_err(hist2_gold, hist2_baseline)
    hist2_silver_eff_err = calc_eff_err(hist2_silver, hist2_baseline)
    hist2_bronze_eff_err = calc_eff_err(hist2_bronze, hist2_baseline)
    
    edges = hist1.axes[0].edges
    xes = (edges[:-1] + edges[1:]) * 0.5
    
    plt.errorbar(xes, y=hist1_gold_eff_err[0], yerr=hist1_gold_eff_err[1], fmt='o', markersize=marker_size, capsize=cap_size, color='darkorange')
    plt.errorbar(xes, y=hist1_silver_eff_err[0], yerr=hist1_silver_eff_err[1], fmt='o', markersize=marker_size, capsize=cap_size, color='dodgerblue')
    plt.errorbar(xes, y=hist1_bronze_eff_err[0], yerr=hist1_bronze_eff_err[1], fmt='o', markersize=marker_size, capsize=cap_size, color='firebrick')

    plt.errorbar(xes, y=hist2_gold_eff_err[0], yerr=hist2_gold_eff_err[1], fmt='s', mfc='none', markersize=marker_size, capsize=cap_size, color='orange')
    plt.errorbar(xes, y=hist2_silver_eff_err[0], yerr=hist2_silver_eff_err[1], fmt='s', mfc='none', markersize=marker_size, capsize=cap_size, color='blue')
    plt.errorbar(xes, y=hist2_bronze_eff_err[0], yerr=hist2_bronze_eff_err[1], fmt='s', mfc='none', markersize=marker_size, capsize=cap_size, color='brown')
    
    # X-axis settings (always linear)
    plt.xlim(0, max_pt)
    # Adjust xticks based on max_pt
    if max_pt <= 30:
        plt.xticks([5, 10, 15, 20, 25, 30], fontsize=40)
    elif max_pt <= 50:
        plt.xticks([10, 20, 30, 40, 50], fontsize=40)
    else:
        plt.xticks([20, 40, 60, 80, 100], fontsize=40)
    
    plt.xlabel(f"{lepton_type} $p_T$ [GeV]", fontsize=40)
    
    # Y-axis settings - handle log scale vs linear scale
    if log_scale:
        plt.yscale('log')
        plt.ylim(0.001, 1.0)  # Log scale needs to avoid 0
    else:
        plt.ylim(0, 1.0)
    
    #plt.yticks(fontsize=40)
    plt.ylabel(f"Quality Assignment Efficiency", fontsize=40, labelpad = 20)
    plt.tick_params(axis='both', which='both', right=True, labelright=True, size=30)
    plt.yticks(fontsize=30)
    plt.grid(visible=None, which='major', axis='y', linewidth=2.0)
    
    if lepton_type.lower() == "electron":
        plt.axvline(x=7, linestyle='dotted', color='black', linewidth=1.5)
        plt.axvline(x=20, linestyle='dotted', color='black', linewidth=1.5)
    
    mplhep.cms.label(loc=0, fontsize=40, com=com)
    #mplhep.cms.text("Work in Progress", fontsize=40, loc=0)
    
    if plot_txt is not None:
        # Use axes coordinates for positioning
        plt.text(0.7, 1.055, plot_txt,
                 fontsize=35,
                 color='black',
                 ha='center',
                 va='top',
                 transform=ax.transAxes,
                 rotation=0,
                 weight='bold'
                )
    
    if title is not None:
        plt.title(title, fontsize=45, pad=60)
    
    handles = [
        Line2D([0], [0], marker='s', color='firebrick', label='Fullsim Bronze', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='dodgerblue', label='Fullsim Silver', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='darkorange', label='Fullsim Gold', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='brown', mfc='none', label='Fastsim Bronze', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='blue', mfc='none', label='Fastsim Silver', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='orange', mfc='none', label='Fastsim Gold', markersize=25, linestyle=''),
    ]
    
    fig.legend(
        handles=handles,
        loc='center left',
        bbox_to_anchor=(0.95, 0.5),
        fontsize=30,
        ncol=1,
        frameon=True,
        facecolor='white',
        edgecolor='black',
        framealpha=1
    )
    
    if savefig:
        os.makedirs(plot_directory, exist_ok=True)
        suffix = "_log" if log_scale else ""
        suffix = suffix + "_" + str(max_pt) + "GeV"
        plt.savefig(f"{plot_directory}/eff_plot_{name}{suffix}.pdf", bbox_inches='tight')
    return fig, ax

def ratio_err(eff1, err1, eff2, err2): #from claude, supposedly the error on the residuals
    ratio = eff1 / np.where(eff2 == 0, np.nan, eff2)
    sigma = ratio * np.sqrt((err1/np.where(eff1==0, np.nan, eff1))**2 + 
                            (err2/np.where(eff2==0, np.nan, eff2))**2)
    return ratio, sigma

def make_1d_pt_eff_comparison(
        hist1_num,
        hist1_denom,
        hist2_num,
        hist2_denom,
        hist1_name="hist1",
        hist2_name="hist2",
        title=None,
        plot_txt=None,
        savefig=False,
        plot_directory="plots",
        save_name="",
        lepton_type="Electron",
        com=13.6,
        max_pt=100,
        log_scale=False,
        y_min=0,
        y_max=1,
        marker_size=14,
        cap_size=10,
        residual=False,
        legend_y=None):
    
        if residual:
            fig, (ax, ax_ratio) = plt.subplots(
                2, 1, figsize=(25, 14),
                gridspec_kw={"height_ratios": [3, 1]},
                sharex=False
            )
        else:
            fig, ax = plt.subplots(figsize=(25, 12))
            ax_ratio = None
    
        min_pt = 0
        if lepton_type == "Electron":
            min_pt = 2
        if lepton_type == "Muon":
            min_pt = 3
    
        hist1_num   = hist1_num[min_pt:]
        hist1_denom = hist1_denom[min_pt:]
        hist2_num   = hist2_num[min_pt:]
        hist2_denom = hist2_denom[min_pt:]
    
        hist1_eff_err = calc_eff_err(hist1_num, hist1_denom)
        hist2_eff_err = calc_eff_err(hist2_num, hist2_denom)
    
        edges = hist1_num.axes[0].edges
        xes = (edges[:-1] + edges[1:]) * 0.5
    
        ax.errorbar(xes, y=hist1_eff_err[0], yerr=hist1_eff_err[1], fmt='o', markersize=marker_size, capsize=cap_size, color='indigo')
        ax.errorbar(xes, y=hist2_eff_err[0], yerr=hist2_eff_err[1], fmt='s', mfc='none', markersize=marker_size, capsize=cap_size, color='orchid')
    
        ax.set_xlim(0, max_pt)
        if max_pt <= 30:
            ax.set_xticks([5, 10, 15, 20, 25, 30])
        elif max_pt <= 50:
            ax.set_xticks([10, 20, 30, 40, 50])
        else:
            ax.set_xticks([20, 40, 60, 80, 100])
        ax.tick_params(axis='x', labelsize=40)
    
        ax.set_xlabel(f"{lepton_type} $p_T$ [GeV]", fontsize=40, fontweight="bold")
    
        if log_scale:
            ax.set_yscale('log')
            ax.set_ylim(y_min if y_min != 0 else 0.001, y_max if ((y_max != 0) & (y_max > y_min)) else 1)
        else:
            ax.set_ylim(y_min, y_max)
    
        ax.set_ylabel("Selection Efficiency", fontsize=40, labelpad=20, fontweight="bold")
        ax.tick_params(axis='both', which='both', right=True, labelright=True, length=30, labelsize=40)
        ax.grid(visible=None, which='major', axis='y', linewidth=2.0)
    
        if lepton_type.lower() == "electron":
            ax.axvline(x=7, linestyle='dotted', color='black', linewidth=1.5)
            ax.axvline(x=20, linestyle='dotted', color='black', linewidth=1.5)
    
        mplhep.cms.text("Work in Progress", ax=ax, fontsize=45, loc=0)
    
        if plot_txt is not None:
            ax.text(0.7, 1.06, plot_txt,
                    fontsize=35, color='black', ha='center', va='top',
                    transform=ax.transAxes, rotation=0, weight='bold')
    
        if title is not None:
            ax.set_title(title, fontsize=45, pad=75, fontweight="bold")
    
        handles = [
            Line2D([0], [0], marker='o', color='indigo', label=hist1_name, markersize=25, linestyle=''),
            Line2D([0], [0], marker='s', color='orchid', mfc='none', label=hist2_name, markersize=25, linestyle=''),
        ]

        if legend_y is not None:
            ax.legend(
                handles=handles,
                loc='center left',
                bbox_to_anchor=(0.70, legend_y),
                bbox_transform=ax.transAxes,
                fontsize=35,
                ncol=1,
                frameon=True,
                facecolor='white',
                edgecolor='black',
                framealpha=1
            )
        else:
            ax.legend(
                handles=handles,
                loc='center left',
                bbox_to_anchor=(0.70, 0.5),
                bbox_transform=ax.transAxes,
                fontsize=35,
                ncol=1,
                frameon=True,
                facecolor='white',
                edgecolor='black',
                framealpha=1
            )
    
        if residual and ax_ratio is not None:
            ratio, r_err = ratio_err(hist1_eff_err[0], 
                                         hist1_eff_err[1], 
                                         hist2_eff_err[0], 
                                         hist2_eff_err[1])
            
            ax_ratio.errorbar(xes, ratio, yerr=r_err, fmt='o', color="black", 
                  markersize=10, capsize=5)

            ax_ratio.axhline(1.0, color="gray", linestyle="--", lw=1)
            ax_ratio.set_ylim(0.5, 1.5)
            ax_ratio.set_ylabel(f"{hist1_name} / {hist2_name}", fontsize=29.5, fontweight="bold", labelpad=10)
            ax_ratio.tick_params(which='both', right=True, labelright=True, labelsize=35, length=15)
            ax_ratio.grid(visible=True, which='major', axis='y', linewidth=1.0)
            ax_ratio.set_xlim(ax.get_xlim())
            if lepton_type.lower() == "electron":
                ax_ratio.axvline(x=7, linestyle='dotted', color='black', linewidth=1.5)
                ax_ratio.axvline(x=20, linestyle='dotted', color='black', linewidth=1.5)
    
        plt.tight_layout()
    
        if savefig:
            os.makedirs(plot_directory, exist_ok=True)
            suffix = "_log" if log_scale else ""
            suffix = suffix + "_" + str(max_pt) + "GeV"
            plt.savefig(f"{plot_directory}/comp_plot_{save_name}{suffix}.pdf", bbox_inches='tight')
    
        return fig, ax

def make_1d_pt_eff_ratio(
    hist1,
    hist2,
    name="default_name",
    title=None,
    plot_txt=None,
    savefig=False,
    plot_directory='plots',
    lep_type='Electron',
    com=13.6, 
    max_pt=100, 
    log_scale=False,
    marker_size = 14,
    cap_size = 11,
    hist1_label='hist1',
    hist2_label='hist2'):


    fig, ax = plt.subplots(figsize=(25, 12))

    #hist1 = hist1.integrate("pt").integrate("eta").integrate("eta_long")
    #hist2 = hist2.integrate("pt").integrate("eta").integrate("eta_long")

    # This block is to remove 0-efficiency points, essentially empty values in the histograms
    min_pt = 0
    
    if lep_type == "Electron":
        min_pt = 2 # the binning of my hists conveniently lines up with the pt we are removing
    if lep_type == "Muon":
        min_pt = 3

    hist1  = hist1[min_pt:, :]
    hist2 = hist2[min_pt:, :]

    # LOOK HERE, I believe my hists should only be two axis, pt_long (like, regular axis of pt bins) and qual
    hist1_gold = hist1[:, 100j] 
    hist1_silver = hist1[:, 10j]
    hist1_bronze = hist1[:, 1j]
    
    hist2_gold = hist2[:, 100j]
    hist2_silver = hist2[:, 10j]
    hist2_bronze = hist2[:, 1j]

    hist1_baseline = (hist1_gold + hist1_silver + hist1_bronze)
    hist2_baseline = (hist2_gold + hist2_silver + hist2_bronze)
    
    hist1_gold_eff_err = calc_eff_err(hist1_gold, hist1_baseline) 
    hist1_silver_eff_err = calc_eff_err(hist1_silver, hist1_baseline)
    hist1_bronze_eff_err = calc_eff_err(hist1_bronze, hist1_baseline)
    
    hist2_gold_eff_err = calc_eff_err(hist2_gold, hist2_baseline)
    hist2_silver_eff_err = calc_eff_err(hist2_silver, hist2_baseline)
    hist2_bronze_eff_err = calc_eff_err(hist2_bronze, hist2_baseline)

    

    gold_ratio, gold_ratio_err = ratio_and_err(
        hist1_gold_eff_err[0], hist1_gold_eff_err[1],
        hist2_gold_eff_err[0], hist2_gold_eff_err[1],
    )
    
    silver_ratio, silver_ratio_err = ratio_and_err(
        hist1_silver_eff_err[0], hist1_silver_eff_err[1],
        hist2_silver_eff_err[0], hist2_silver_eff_err[1],
    )
    
    bronze_ratio, bronze_ratio_err = ratio_and_err(
        hist1_bronze_eff_err[0], hist1_bronze_eff_err[1],
        hist2_bronze_eff_err[0], hist2_bronze_eff_err[1],
    )



    edges = hist1.axes[0].edges
    xes = (edges[:-1] + edges[1:]) * 0.5
    
    plt.errorbar(xes, y=gold_ratio, yerr=gold_ratio_err, fmt='o', markersize=marker_size, capsize=cap_size, color='darkorange')
    plt.errorbar(xes, y=silver_ratio, yerr=gold_ratio_err, fmt='o', markersize=marker_size, capsize=cap_size, color='dodgerblue')
    plt.errorbar(xes, y=bronze_ratio, yerr=gold_ratio_err, fmt='o', markersize=marker_size, capsize=cap_size, color='firebrick')
    
    # X-axis settings (always linear)
    plt.xlim(0, max_pt)
    # Adjust xticks based on max_pt
    if max_pt <= 30:
        plt.xticks([5, 10, 15, 20, 25, 30], fontsize=40)
    elif max_pt <= 50:
        plt.xticks([10, 20, 30, 40, 50], fontsize=40)
    else:
        plt.xticks([20, 40, 60, 80, 100], fontsize=40)
    
    plt.xlabel(f"{lep_type} $p_T$ [GeV]", fontsize=40)
    
    # Y-axis settings - handle log scale vs linear scale
    if log_scale:
        plt.yscale('log')
        plt.ylim(0.3, 2.75)  # Log scale needs to avoid 0
    else:
        plt.ylim(0.3, 2.75)
    
    #plt.yticks(fontsize=40)
    plt.ylabel(f"FullSim Efficiency / FastSim Efficiency", fontsize=40, labelpad = 20)
    plt.tick_params(axis='both', which='both', right=True, labelright=True, size=30)
    plt.yticks(fontsize=30)
    plt.grid(visible=None, which='major', axis='y', linewidth=2.0)
    
    if lep_type.lower() == "electron":
        plt.axvline(x=7, linestyle='dotted', color='black', linewidth=1.5)
        plt.axvline(x=20, linestyle='dotted', color='black', linewidth=1.5)
    
    mplhep.cms.label(loc=0, fontsize=40, com=com)
    #mplhep.cms.text("Work in Progress", fontsize=40, loc=0)
    
    if plot_txt is not None:
        # Use axes coordinates for positioning
        plt.text(0.7, 1.055, plot_txt,
                 fontsize=35,
                 color='black',
                 ha='center',
                 va='top',
                 transform=ax.transAxes,
                 rotation=0,
                 weight='bold'
                )
    
    if title is not None:
        plt.title(title, fontsize=45, pad=60)

    
    handles = [
        Line2D([0], [0], marker='s', color='firebrick', label='Bronze', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='dodgerblue', label='Silver', markersize=25, linestyle=''),
        Line2D([0], [0], marker='s', color='darkorange', label='Gold', markersize=25, linestyle=''),
    ]
    
    fig.legend(
        handles=handles,
        loc='center left',
        bbox_to_anchor=(0.95, 0.5),
        fontsize=30,
        ncol=1,
        frameon=True,
        facecolor='white',
        edgecolor='black',
        framealpha=1
    )
    
    if savefig:
        os.makedirs(plot_directory, exist_ok=True)
        suffix = "_log" if log_scale else ""
        suffix = suffix + "_" + str(max_pt) + "GeV"
        plt.savefig(f"{plot_directory}/eff_ratio_plot_{name}{suffix}.pdf", bbox_inches='tight')
        
    plt.close()
    return ax

def ratio_and_err(eff1, err1, eff2, err2):
    
    """
    Compute ratio = eff1 / eff2 and its propagated uncertainty.

    All inputs are numpy arrays of the same shape.
    Assumes eff1 and eff2 are independent.
    """

    eff1 = np.array(eff1)
    err1 = np.array(err1)
    eff2 = np.array(eff2)
    err2 = np.array(err2)

    ratio = eff1 / eff2

    ratio_err = ratio * np.sqrt(
        (err1 / eff1)**2 +
        (err2 / eff2)**2
    )

    return ratio, ratio_err