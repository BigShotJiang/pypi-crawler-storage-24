import abc
from typing import Any


class StateRepository(metaclass=abc.ABCMeta):
    """
    ステートを永続化するためのインターフェースです
    ステートはrunするときにロックされ、排他的に実行されます。
    """

    @abc.abstractmethod
    def read_state(self, name: str, default: Any = None) -> Any:
        raise NotImplementedError()

    @abc.abstractmethod
    def save_state(self, name: str, value: Any) -> None:
        raise NotImplementedError()

    @abc.abstractmethod
    def clear_state(self) -> None:
        raise NotImplementedError()

    @abc.abstractmethod
    def lock_state(self) -> None:
        """ステートを排他的にロックします"""
        raise NotImplementedError()

    @abc.abstractmethod
    def unlock_state(self) -> None:
        """ステートのロックを開放します"""
        raise NotImplementedError()

    @abc.abstractmethod
    def is_locked(self) -> bool:
        """ロック状態を返します"""
        raise NotImplementedError()
