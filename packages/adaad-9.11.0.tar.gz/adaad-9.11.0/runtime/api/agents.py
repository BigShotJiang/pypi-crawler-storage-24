# SPDX-License-Identifier: Apache-2.0
"""Approved runtime facade for legacy agent and mutation entrypoints.

This module intentionally lazily resolves exports to avoid circular imports
between runtime/api and runtime/evolution modules during startup.
"""

from __future__ import annotations

from typing import Any

_EXPORTS: dict[str, tuple[str, str]] = {
    "agent_path_from_id": ("adaad.agents.discovery", "agent_path_from_id"),
    "iter_agent_dirs": ("adaad.agents.discovery", "iter_agent_dirs"),
    "resolve_agent_id": ("adaad.agents.discovery", "resolve_agent_id"),
    "MutationEngine": ("adaad.agents.mutation_engine", "MutationEngine"),
    "MutationRequest": ("adaad.agents.mutation_request", "MutationRequest"),
    "MutationTarget": ("adaad.agents.mutation_request", "MutationTarget"),
    "adapt_generated_request_payload": ("adaad.agents.mutation_strategies", "adapt_generated_request_payload"),
    "load_skill_weights": ("adaad.agents.mutation_strategies", "load_skill_weights"),
    "select_strategy": ("adaad.agents.mutation_strategies", "select_strategy"),
}

__all__ = sorted(_EXPORTS.keys())


def _resolve_module(module_name: str) -> Any:
    # lint:fix forbidden_dynamic_execution — explicit module routing — governance-reviewed
    if module_name == "adaad.agents.discovery":
        from adaad.agents import discovery as module

        return module
    if module_name == "adaad.agents.mutation_engine":
        from adaad.agents import mutation_engine as module

        return module
    if module_name == "adaad.agents.mutation_request":
        from adaad.agents import mutation_request as module

        return module
    if module_name == "adaad.agents.mutation_strategies":
        from adaad.agents import mutation_strategies as module

        return module
    raise ModuleNotFoundError(module_name)


def __getattr__(name: str) -> Any:
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attr_name = _EXPORTS[name]
    module = _resolve_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
