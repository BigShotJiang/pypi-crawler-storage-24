"""TLM Firewall — command risk assessment.

Extracted from hooks.py risky pattern matching.
Returns structured advisory dicts (never blocks).
"""

import json
import re
from pathlib import Path

# Risky command patterns (deploy, destructive, etc.)
_RISKY_PATTERNS = [
    # Deploy/publish
    r'\b(firebase|vercel|netlify|fly|railway|render|heroku)\s+deploy\b',
    r'\b(eb|sam|serverless|cdk)\s+deploy\b',
    r'\bgcloud\s+app\s+deploy\b',
    r'\bkubectl\s+(apply|delete|replace)\b',
    r'\bdocker\s+push\b',
    r'\bhelm\s+(install|upgrade|delete)\b',
    r'\bgit\s+push\s+.*\b(prod|production|main|master)\b',
    r'\bterraform\s+(apply|destroy)\b',
    # Risky keywords in scripts/ or bin/ paths
    r'(scripts|bin)/\S*(deploy|release|publish)',
]

_DESTRUCTIVE_PATTERNS = [
    r'\brm\s+-[rRfF]*[rRfF]\b',
    r'\brm\s+--force\b',
    r'\bdrop\s+(database|table|schema)\b',
    r'\btruncate\s+table\b',
]

_COMPILED_RISKY = [re.compile(p, re.IGNORECASE) for p in _RISKY_PATTERNS]
_COMPILED_DESTRUCTIVE = [re.compile(p, re.IGNORECASE) for p in _DESTRUCTIVE_PATTERNS]


def _load_permanent_overrides(project_root: str) -> list[str]:
    """Load permanently overridden commands from .tlm/permanent_overrides.json."""
    overrides_file = Path(project_root) / ".tlm" / "permanent_overrides.json"
    if not overrides_file.exists():
        return []
    try:
        data = json.loads(overrides_file.read_text())
        return data.get("commands", [])
    except (json.JSONDecodeError, OSError):
        return []


def check_command_risk(command: str, project_root: str = "") -> dict:
    """Assess risk level of a command. Returns advisory dict.

    Returns:
        {"advisory": "safe"|"risky"|"dangerous", "reason": str}
    """
    # Check permanent overrides first
    if project_root:
        overrides = _load_permanent_overrides(project_root)
        if command.strip() in overrides:
            return {"advisory": "safe", "reason": "Command has a permanent override."}

    # Check destructive patterns first (higher severity)
    for pattern in _COMPILED_DESTRUCTIVE:
        if pattern.search(command):
            return {
                "advisory": "dangerous",
                "reason": f"Destructive command detected: matches pattern '{pattern.pattern}'",
            }

    # Check risky patterns
    for pattern in _COMPILED_RISKY:
        if pattern.search(command):
            return {
                "advisory": "risky",
                "reason": f"Risky command detected: matches pattern '{pattern.pattern}'",
            }

    return {"advisory": "safe", "reason": "No risky patterns detected."}
