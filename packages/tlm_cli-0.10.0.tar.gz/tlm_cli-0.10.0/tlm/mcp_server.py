"""TLM MCP Server — advisory tools for Claude Code.

Runs as stdio-based MCP server. Claude calls tools when it judges appropriate.
All tools are advisory — they never block Claude.

Launch: tlm mcp-serve
Config: .mcp.json -> {"mcpServers": {"tlm": {"command": "tlm", "args": ["mcp-serve"]}}}
"""

import json
import subprocess
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from tlm.context import get_knowledge_context
from tlm.firewall import check_command_risk
from tlm.state import read_state, write_state
from tlm.gaps import get_active_gaps

mcp = FastMCP(
    "tlm",
    instructions=(
        "TLM — Tech Lead & Manager. "
        "Call tlm_get_context at the start of significant tasks to load project knowledge. "
        "Use tlm_review_command before running risky commands. "
        "Use tlm_review_plan before implementing complex features. "
        "These tools are advisory — use your judgment."
    ),
)


def _get_review_client(project_root: str = "."):
    """Get a TLMClient for server-backed reviews. Returns None if unavailable."""
    try:
        from tlm.config import load_credentials, load_project_config
        from tlm.client import TLMClient
        creds = load_credentials()
        if creds.get("server_url") and creds.get("api_key"):
            return TLMClient(creds["server_url"], creds["api_key"])
    except Exception:
        pass
    return None


# ── Tools ────────────────────────────────────────────────────


@mcp.tool()
def tlm_get_context(project_root: str = ".", query: str = "") -> str:
    """Get TLM project context: state, knowledge, preferences, gaps, and vector search results.

    Call this at the start of significant engineering tasks.

    Args:
        project_root: Path to project root (default: current directory)
        query: Optional search query for vector-based memory retrieval
    """
    root = Path(project_root).resolve()

    # Load state
    state = {}
    try:
        state = read_state(str(root))
    except Exception:
        pass

    # Load knowledge context
    ctx = get_knowledge_context(str(root), query=query)

    result = {
        "state": state,
        "knowledge": ctx.get("knowledge", []),
        "user_preferences": ctx.get("user_preferences", []),
        "learned_rules": ctx.get("learned_rules", []),
        "vector_results": ctx.get("vector_results", []),
        "gaps": ctx.get("gaps", []),
        "new_learnings": ctx.get("new_learnings", []),
    }
    return json.dumps(result, indent=2)


@mcp.tool()
def tlm_review_command(command: str, project_root: str = ".") -> str:
    """Advisory review of a shell command for risk assessment.

    Returns safe/risky/dangerous advisory. Never blocks execution.

    Args:
        command: The shell command to review
        project_root: Path to project root
    """
    result = check_command_risk(command, project_root=project_root)
    return json.dumps(result)


@mcp.tool()
def tlm_review_plan(plan: str, project_root: str = ".") -> str:
    """Advisory review of an implementation plan before coding.

    Sends plan to TLM server for review. Fails open if server is unavailable.

    Args:
        plan: The implementation plan text to review
        project_root: Path to project root
    """
    client = _get_review_client(project_root)
    if not client:
        return json.dumps({
            "advisory": "approve",
            "reason": "Server unavailable — proceeding without review.",
            "issues": [],
        })

    try:
        from tlm.config import load_project_config
        config = load_project_config(project_root)
        project_id = config.get("project_id", "")

        server_result = client.review_plan(
            project_id=str(project_id),
            plan_text=plan,
        )

        decision = server_result.get("decision", "pass")
        advisory = "approve" if decision in ("pass", "warn") else "revise"

        return json.dumps({
            "advisory": advisory,
            "reason": server_result.get("reason", ""),
            "issues": server_result.get("issues", []),
        })
    except Exception as e:
        return json.dumps({
            "advisory": "approve",
            "reason": f"Server unavailable — proceeding without review. ({e})",
            "issues": [],
        })


@mcp.tool()
def tlm_review_diff(diff: str, project_root: str = ".") -> str:
    """Advisory review of a git diff before committing.

    Args:
        diff: The git diff text to review
        project_root: Path to project root
    """
    client = _get_review_client(project_root)
    if not client:
        return json.dumps({
            "advisory": "pass",
            "reason": "Server unavailable — proceeding without review.",
            "issues": [],
        })

    try:
        from tlm.config import load_project_config
        config = load_project_config(project_root)
        project_id = config.get("project_id", "")

        server_result = client.review_diff(
            project_id=str(project_id),
            diff_text=diff,
        )

        decision = server_result.get("decision", "pass")
        advisory = "pass" if decision in ("pass", "warn") else "warn"

        return json.dumps({
            "advisory": advisory,
            "reason": server_result.get("reason", ""),
            "issues": server_result.get("issues", []),
        })
    except Exception as e:
        return json.dumps({
            "advisory": "pass",
            "reason": f"Server unavailable — proceeding without review. ({e})",
            "issues": [],
        })


@mcp.tool()
def tlm_set_phase(phase: str, activity_type: str = "", project_root: str = ".") -> str:
    """Update TLM project phase in .tlm/state.json.

    Args:
        phase: New phase (idle, tlm_active, implementation, deployment)
        activity_type: Optional activity type (e.g., new_feature, bug_fix)
        project_root: Path to project root
    """
    root = Path(project_root).resolve()

    state = {}
    try:
        state = read_state(str(root))
    except Exception:
        pass

    state["phase"] = phase
    if activity_type:
        state["activity_type"] = activity_type

    write_state(str(root), state)

    return json.dumps(state)


@mcp.tool()
def tlm_check_gaps(query: str = "", project_root: str = ".") -> str:
    """Check for known project gaps, optionally filtered by keyword.

    Args:
        query: Optional keyword to filter gaps
        project_root: Path to project root
    """
    try:
        gaps = get_active_gaps(project_root)
    except Exception:
        gaps = []

    if query:
        query_lower = query.lower()
        gaps = [
            g for g in gaps
            if query_lower in g.get("description", "").lower()
            or query_lower in g.get("category", "").lower()
            or query_lower in g.get("id", "").lower()
        ]

    return json.dumps({"gaps": gaps, "total": len(gaps)})


@mcp.tool()
def tlm_learn(learn_type: str, data: str, project_root: str = ".") -> str:
    """Capture learning data (prompt or session) for background processing.

    Args:
        learn_type: Type of learning ('prompt' or 'session')
        data: The data to learn from (prompt text or session summary)
        project_root: Path to project root
    """
    root = Path(project_root).resolve()
    tlm_dir = root / ".tlm"

    if learn_type == "prompt":
        # Append to session_prompts.jsonl for later processing
        try:
            prompts_file = tlm_dir / "session_prompts.jsonl"
            import time
            entry = json.dumps({"prompt": data, "ts": time.time()})
            with open(prompts_file, "a") as f:
                f.write(entry + "\n")
        except Exception:
            pass

        # Fire background learning
        try:
            subprocess.Popen(
                ["tlm", "_hook", "learn_prompt_bg"],
                cwd=str(root),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass

    elif learn_type == "session":
        # Session end learning — process accumulated prompts
        try:
            subprocess.Popen(
                ["tlm", "_hook", "stop"],
                cwd=str(root),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass

    return json.dumps({"status": "accepted", "type": learn_type})


# ── Resources ────────────────────────────────────────────────


@mcp.resource("tlm://project/state")
def get_state() -> str:
    """Current TLM project state from .tlm/state.json."""
    try:
        state = read_state(".")
        return json.dumps(state, indent=2)
    except Exception:
        return json.dumps({})


@mcp.resource("tlm://project/knowledge")
def get_knowledge() -> str:
    """Combined project knowledge: knowledge.md + learned rules + user preferences."""
    ctx = get_knowledge_context(".")
    return json.dumps(ctx, indent=2)


@mcp.resource("tlm://project/gaps")
def get_gaps() -> str:
    """Active project gaps from .tlm/gaps.json."""
    try:
        gaps = get_active_gaps(".")
        return json.dumps(gaps, indent=2)
    except Exception:
        return json.dumps([])


# ── Entry point ──────────────────────────────────────────────


def run_server():
    """Run the TLM MCP server on stdio transport."""
    mcp.run(transport="stdio")
