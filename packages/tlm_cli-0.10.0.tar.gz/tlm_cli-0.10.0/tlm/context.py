"""TLM Context — knowledge loading and context assembly.

Extracted from hooks.py _load_and_inject_insights().
Returns structured dicts (no stderr side effects).
"""

import json
from pathlib import Path

from tlm.config import load_project_config, load_credentials
from tlm.client import TLMClient
from tlm.gaps import get_active_gaps

# Global TLM dir for user-scoped memories
GLOBAL_TLM_DIR = Path.home() / ".tlm"

# Lazy import to avoid circular deps
KnowledgeDB = None


def _get_knowledge_db_class():
    global KnowledgeDB
    if KnowledgeDB is None:
        from tlm.knowledge_db import KnowledgeDB as _KDB
        KnowledgeDB = _KDB
    return KnowledgeDB


def get_knowledge_context(project_root: str, query: str = "") -> dict:
    """Load all knowledge context for a project.

    Returns structured dict with:
        - knowledge: list[str] — facts from knowledge.md
        - user_preferences: list[str] — from ~/.tlm/knowledge.db
        - learned_rules: list[str] — from project knowledge.db
        - vector_results: list[str] — from MemX vector search
        - gaps: list[dict] — active gaps
        - new_learnings: list[str] — new learnings since last session
    """
    result = {
        "knowledge": [],
        "user_preferences": [],
        "learned_rules": [],
        "vector_results": [],
        "gaps": [],
        "new_learnings": [],
    }

    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return result

    # 1. Knowledge.md facts
    knowledge_file = tlm_dir / "knowledge.md"
    if knowledge_file.exists():
        try:
            content = knowledge_file.read_text()
            facts = [
                line.strip() for line in content.split("\n")
                if line.strip() and not line.startswith(("#", "_", "---"))
            ]
            result["knowledge"] = facts
        except OSError:
            pass

    # 2. Active gaps
    try:
        active_gaps = get_active_gaps(project_root)
        result["gaps"] = active_gaps
    except Exception:
        pass

    # 3. Project-scoped learned rules from knowledge.db
    db_path = tlm_dir / "knowledge.db"
    if db_path.exists():
        try:
            KDB = _get_knowledge_db_class()
            db = KDB(str(tlm_dir))
            learned = db.list_rules(source_prefix="watcher_learned")
            db.close()
            result["learned_rules"] = [
                r["rule_text"] for r in learned
                if r.get("rule_text") and r.get("source") != "watcher_learned_user"
            ]
        except Exception:
            pass

    # 4. User-scoped preferences from ~/.tlm/knowledge.db
    global_db_path = GLOBAL_TLM_DIR / "knowledge.db"
    if global_db_path.exists():
        try:
            KDB = _get_knowledge_db_class()
            gdb = KDB(str(GLOBAL_TLM_DIR))
            user_rules = gdb.list_rules()
            gdb.close()
            result["user_preferences"] = [
                r["rule_text"] for r in user_rules if r.get("rule_text")
            ]
        except Exception:
            pass

    # 5. Vector search via MemX (if query provided)
    if query:
        try:
            creds = load_credentials()
            if creds.get("server_url") and creds.get("api_key"):
                client = TLMClient(creds["server_url"], creds["api_key"])
                config = load_project_config(project_root)
                project_id = config.get("project_id", "")
                search_result = client.search_memories(
                    query=query,
                    project_id=str(project_id) if project_id else "",
                )
                memories = search_result.get("memories", [])
                result["vector_results"] = [m["text"] for m in memories]
        except Exception:
            pass

    # 6. New learnings since last session
    cache_dir = tlm_dir / "cache"
    last_learned = cache_dir / "last_learned.json"
    if last_learned.exists():
        try:
            data = json.loads(last_learned.read_text())
            if data:
                result["new_learnings"] = [m.get("text", "") for m in data if m.get("text")]
        except (json.JSONDecodeError, OSError):
            pass

    return result
