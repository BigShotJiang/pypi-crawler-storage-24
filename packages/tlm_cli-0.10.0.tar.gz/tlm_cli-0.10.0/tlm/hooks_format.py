"""Hook format abstraction — centralizes Claude Code hook entry format.

Claude Code hook format has changed before (commit 0952734) and will change again.
This module ensures future format changes only require updating ONE function.

Current format (2026-02): hooks is a dict keyed by event name, with matcher
as a top-level string (not nested object).
"""


def build_hook_entry(command: str, matcher: str | None = None) -> dict:
    """Build a single hook entry in whatever format Claude Code currently expects.

    Centralizes format so future changes require updating ONE function.
    """
    entry = {"hooks": [{"type": "command", "command": command}]}
    if matcher:
        entry["matcher"] = matcher
    return entry


def build_all_hooks() -> dict:
    """Build the non-blocking TLM hook dict, keyed by event name.

    Three non-blocking hooks (MCP server handles advisory tools):
    - SessionStart → branding banner (visual only, no context injection to Claude)
    - UserPromptSubmit → prompt capture + background learning + stderr knowledge boxes
    - Stop → session cleanup + session learning sync

    Blocking hooks (PreToolUse, PostToolUse) removed — replaced by MCP tools.
    """
    return {
        "SessionStart": [
            build_hook_entry("tlm _hook session_start"),
        ],
        "UserPromptSubmit": [
            build_hook_entry("tlm _hook prompt_submit"),
        ],
        "Stop": [
            build_hook_entry("tlm _hook stop"),
        ],
    }
