"""Tests for injection of knowledge.db learned rules into prompt context."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest


class TestInjectionWithKnowledgeDB:
    def test_injection_includes_learned_rules_from_knowledge_db(self, tmp_path):
        """_load_and_inject_insights includes rules from knowledge.db."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        cache_dir = tlm_dir / "cache"
        cache_dir.mkdir()

        # Create knowledge.db with a learned rule
        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        db.add_rule("Always use bun instead of npm", source="watcher_learned")
        db.add_rule("Prefer PostgreSQL over SQLite", source="watcher_learned")
        db.close()

        # Create empty insights file (so the function runs)
        (cache_dir / "realtime_insights.json").write_text(json.dumps({
            "corrections": [], "rules": [], "shown_corrections": [],
        }))

        from tlm.hooks import _load_and_inject_insights
        result = _load_and_inject_insights(str(tmp_path))

        # Should include knowledge.db rules
        assert result is not None
        assert "bun" in result
        assert "PostgreSQL" in result

    def test_injection_no_knowledge_db(self, tmp_path, monkeypatch):
        """Works without knowledge.db — returns None if no insights at all."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        # Isolate from real ~/.tlm/knowledge.db
        empty_global = tmp_path / "empty_global"
        empty_global.mkdir()
        monkeypatch.setattr("tlm.hooks.GLOBAL_TLM_DIR", empty_global)

        from tlm.hooks import _load_and_inject_insights
        result = _load_and_inject_insights(str(tmp_path))
        assert result is None

    def test_injection_filters_by_source(self, tmp_path):
        """Only includes watcher_learned rules, not other sources."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        cache_dir = tlm_dir / "cache"
        cache_dir.mkdir()

        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        db.add_rule("Always use bun", source="watcher_learned")
        db.add_rule("Some base rule", source="base")
        db.close()

        (cache_dir / "realtime_insights.json").write_text(json.dumps({
            "corrections": [], "rules": [], "shown_corrections": [],
        }))

        from tlm.hooks import _load_and_inject_insights
        result = _load_and_inject_insights(str(tmp_path))

        assert result is not None
        assert "bun" in result
        # base rules should NOT be injected via this mechanism
        assert "Some base rule" not in result
