"""Tests for _load_and_inject_insights() MemX vector search integration."""

import os
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


class TestInsightsMemxSearch:

    def setup_method(self):
        """Create a temporary project directory with minimal .tlm structure."""
        self.tmpdir = tempfile.mkdtemp()
        tlm_dir = Path(self.tmpdir) / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "cache").mkdir()
        # Write minimal config.json so load_project_config works
        import json
        (tlm_dir / "config.json").write_text(json.dumps({"project_id": "test-proj-123"}))

    def test_insights_with_prompt_searches_memx(self):
        """When prompt_text given, calls search_memories() and includes results."""
        mock_client_instance = MagicMock()
        mock_client_instance.search_memories.return_value = {
            "memories": [
                {"text": "run golden tests with run_two_stage_golden.sh", "similarity": 0.9},
                {"text": "golden test timeout is 300s", "similarity": 0.7},
            ]
        }

        with patch("tlm.client.TLMClient", return_value=mock_client_instance) as MockClass, \
             patch("tlm.config.load_credentials", return_value={"server_url": "https://test", "api_key": "key"}):
            from tlm.hooks import _load_and_inject_insights
            result = _load_and_inject_insights(self.tmpdir, prompt_text="how to run golden tests")

            assert result is not None
            assert "[TLM — Relevant knowledge for this task]" in result
            assert "run golden tests with run_two_stage_golden.sh" in result

    def test_insights_without_prompt_uses_sqlite(self):
        """When prompt_text empty, does not call search_memories."""
        with patch("tlm.client.TLMClient") as MockClass:
            from tlm.hooks import _load_and_inject_insights
            # With no prompt_text, MemX search should not be called
            _load_and_inject_insights(self.tmpdir, prompt_text="")
            MockClass.assert_not_called()

    def test_insights_memx_failure_falls_back(self):
        """When search_memories raises, falls through to SQLite without crashing."""
        mock_client_instance = MagicMock()
        mock_client_instance.search_memories.side_effect = Exception("connection refused")

        with patch("tlm.client.TLMClient", return_value=mock_client_instance), \
             patch("tlm.config.load_credentials", return_value={"server_url": "https://test", "api_key": "key"}):
            from tlm.hooks import _load_and_inject_insights
            # Should not raise
            result = _load_and_inject_insights(self.tmpdir, prompt_text="test prompt")
            # Result may be None or contain only SQLite-based content — no crash

    def test_insights_formats_memories_correctly(self):
        """Output contains [TLM — Relevant knowledge for this task] with prefixed lines."""
        mock_client_instance = MagicMock()
        mock_client_instance.search_memories.return_value = {
            "memories": [
                {"text": "always use bun for packages", "similarity": 0.9},
            ]
        }

        with patch("tlm.client.TLMClient", return_value=mock_client_instance), \
             patch("tlm.config.load_credentials", return_value={"server_url": "https://test", "api_key": "key"}):
            from tlm.hooks import _load_and_inject_insights
            result = _load_and_inject_insights(self.tmpdir, prompt_text="package manager")

            assert result is not None
            lines = result.split("\n")
            assert any("[TLM — Relevant knowledge for this task]" in l for l in lines)
            assert any("  - always use bun for packages" in l for l in lines)
