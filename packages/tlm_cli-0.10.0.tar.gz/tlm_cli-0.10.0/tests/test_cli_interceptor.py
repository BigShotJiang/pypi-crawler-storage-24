"""Tests for CLI interceptor commands — sync, rules, rules remove."""

import json
import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from tlm.cli import main
from tlm.client import TLMConnectionError, TLMServerError


# ---------------------------------------------------------------------------
# tlm sync
# ---------------------------------------------------------------------------

class TestSyncCommand:
    """Tests for `tlm sync` (sync_memories — pull memories from server)."""

    @patch("tlm.cli.Installer")
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_sync_with_memories(self, mock_config, mock_client_cls, mock_url, mock_key, mock_installer_cls):
        mock_config.return_value = {"project_id": "42"}
        mock_client = MagicMock()
        mock_client.pull_memories.return_value = {
            "user_memories": [{"text": "prefer bun"}],
            "project_memories": [{"text": "uses firebase"}, {"text": "TDD required"}],
        }
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["sync"])

        assert result.exit_code == 0
        assert "1 user" in result.output
        assert "2 project" in result.output

    @patch("tlm.cli.Installer")
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_sync_no_memories(self, mock_config, mock_client_cls, mock_url, mock_key, mock_installer_cls):
        mock_config.return_value = {"project_id": "42"}
        mock_client = MagicMock()
        mock_client.pull_memories.return_value = {
            "user_memories": [],
            "project_memories": [],
        }
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["sync"])

        assert result.exit_code == 0
        assert "0 user" in result.output

    @patch("tlm.cli.get_api_key", return_value=None)
    def test_sync_no_auth(self, mock_key):
        runner = CliRunner()
        result = runner.invoke(main, ["sync"])

        assert result.exit_code == 1
        assert "auth" in result.output.lower()

    @patch("tlm.cli.Installer")
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_sync_no_project_id(self, mock_config, mock_client_cls, mock_url, mock_key, mock_installer_cls):
        mock_config.return_value = {}
        mock_client = MagicMock()
        mock_client.pull_memories.return_value = {
            "user_memories": [{"text": "a pref"}],
            "project_memories": [],
        }
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["sync"])

        # Should still work (pulls user memories even without project_id)
        assert result.exit_code == 0

    @patch("tlm.cli.Installer")
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_sync_connection_error(self, mock_config, mock_client_cls, mock_url, mock_key, mock_installer_cls):
        mock_config.return_value = {"project_id": "42"}
        mock_client = MagicMock()
        mock_client.pull_memories.side_effect = TLMConnectionError("Cannot reach TLM server")
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["sync"])

        assert result.exit_code == 1
        assert "server" in result.output.lower() or "reach" in result.output.lower()


# ---------------------------------------------------------------------------
# tlm rules
# ---------------------------------------------------------------------------

class TestRulesCommand:

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_rules_list_shows_table(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.get_rules.return_value = {
            "rules": [
                {"id": 1, "rule_text": "Always test", "source": "session_learning"},
                {"id": 2, "rule_text": "Use type hints", "source": "assess"},
            ]
        }
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "Always test" in result.output
        assert "Use type hints" in result.output

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_rules_list_empty(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.get_rules.return_value = {"rules": []}
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "No active rules" in result.output

    @patch("tlm.cli.load_project_config")
    def test_rules_no_project_id(self, mock_config, tmp_path):
        mock_config.return_value = {}
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code == 1

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_rules_connection_error(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.get_rules.side_effect = TLMConnectionError("Cannot reach TLM server")
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code != 0 or "Cannot reach" in result.output or "server" in result.output.lower()


# ---------------------------------------------------------------------------
# tlm rules remove
# ---------------------------------------------------------------------------

class TestRulesRemoveCommand:

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_remove_success(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.delete_rule.return_value = {"status": "deleted"}
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path), "remove", "4"])

        assert result.exit_code == 0
        assert "Rule #4 removed" in result.output

    @patch("tlm.cli.load_project_config")
    def test_remove_no_project_id(self, mock_config, tmp_path):
        mock_config.return_value = {}
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path), "remove", "4"])

        assert result.exit_code == 1

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_remove_server_error(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.delete_rule.side_effect = TLMServerError("Server error (404): Rule not found")
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path), "remove", "99"])

        assert result.exit_code != 0 or "error" in result.output.lower()
