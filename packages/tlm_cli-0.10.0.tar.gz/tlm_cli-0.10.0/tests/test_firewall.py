"""Tests for tlm.firewall — command risk assessment."""

import json
from pathlib import Path

import pytest

from tlm.firewall import check_command_risk


def test_safe_command():
    """Common commands should be safe."""
    result = check_command_risk("ls -la")
    assert result["advisory"] == "safe"

    result = check_command_risk("git status")
    assert result["advisory"] == "safe"

    result = check_command_risk("python -m pytest tests/ -v")
    assert result["advisory"] == "safe"


def test_risky_deploy_command():
    """Deploy commands should be risky."""
    result = check_command_risk("firebase deploy")
    assert result["advisory"] == "risky"
    assert result["reason"]

    result = check_command_risk("gcloud app deploy")
    assert result["advisory"] == "risky"

    result = check_command_risk("kubectl apply -f deployment.yaml")
    assert result["advisory"] == "risky"


def test_destructive_command():
    """Destructive commands should be dangerous."""
    result = check_command_risk("rm -rf /")
    assert result["advisory"] == "dangerous"

    result = check_command_risk("drop database production")
    assert result["advisory"] == "dangerous"


def test_risky_git_push_prod():
    """Pushing to production branches should be risky."""
    result = check_command_risk("git push origin main")
    assert result["advisory"] == "risky"

    result = check_command_risk("git push origin production")
    assert result["advisory"] == "risky"


def test_safe_git_push_feature():
    """Pushing to feature branches should be safe."""
    result = check_command_risk("git push origin feature/my-branch")
    assert result["advisory"] == "safe"


def test_permanent_override(tmp_path):
    """Overridden commands should be safe."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    overrides_file = tlm_dir / "permanent_overrides.json"
    overrides_file.write_text(json.dumps({"commands": ["firebase deploy"]}))

    result = check_command_risk("firebase deploy", project_root=str(tmp_path))
    assert result["advisory"] == "safe"
    assert "override" in result.get("reason", "").lower()


def test_result_structure():
    """All results should have advisory and reason."""
    result = check_command_risk("echo hello")
    assert "advisory" in result
    assert "reason" in result
    assert result["advisory"] in ("safe", "risky", "dangerous")


def test_deploy_script_path():
    """Scripts with deploy in the path should be risky."""
    result = check_command_risk("scripts/deploy.sh")
    assert result["advisory"] == "risky"

    result = check_command_risk("bin/release.sh")
    assert result["advisory"] == "risky"


def test_terraform_commands():
    """Terraform apply/destroy should be risky."""
    result = check_command_risk("terraform apply")
    assert result["advisory"] == "risky"

    result = check_command_risk("terraform destroy")
    assert result["advisory"] == "risky"
