"""
E2E hook output tests — verify actual hook output visible to the user.

These tests call the real hooks against a hello-world project fixture
and check that outputs contain expected TLM branding, TDD warnings,
prompt learning feedback, and plan review messages.

No live server needed — server calls are mocked.
"""

import json
import sys
import time
import io
import subprocess
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from click.testing import CliRunner

from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_auto_interviewer_plan,
    hook_stop,
    _load_and_inject_insights,
)
from tlm.state import write_state, read_state
from tlm.config import save_project_config
from tlm.gaps import add_gap


@pytest.fixture
def hello_world(tmp_path):
    """Create a hello-world project with TLM installed."""
    proj = tmp_path / "hello_world"
    proj.mkdir()
    (proj / "main.py").write_text(
        'def greet(name: str) -> str:\n'
        '    return f"Hello, {name}!"\n'
    )
    (proj / "requirements.txt").write_text("flask==3.0\n")

    tlm_dir = proj / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    (tlm_dir / "knowledge.md").write_text(
        "- Project uses Flask\n- Python 3.12\n"
    )

    write_state(str(proj), {"phase": "idle"})
    save_project_config(str(proj), {
        "quality_control": "standard",
        "project_id": 99,
    })

    return proj


# ── 1. Session Start shows TLM banner ────────────────────────


class TestSessionStartOutput:
    def test_banner_has_tlm_branding(self, hello_world):
        """Session start output should show TLM banner with branding."""
        output = hook_session_start(str(hello_world))
        assert "TLM" in output
        assert "Tech Lead" in output
        assert "ACTIVE" in output

    def test_banner_shows_knowledge(self, hello_world):
        """Session start should show loaded knowledge facts."""
        output = hook_session_start(str(hello_world))
        assert "Knowledge" in output or "Flask" in output

    def test_banner_shows_enforcement_rules(self, hello_world):
        """Session start should show enforcement rules for the quality tier."""
        output = hook_session_start(str(hello_world))
        # Standard tier shows WARNED and ENFORCED
        assert "WARNED" in output or "ENFORCED" in output


# ── 2. Plan review shows "TLM is reviewing" + TDD warning ────


def _mock_plan_client(mock_client_fn, review_response):
    """Helper: set up a mock client for plan review tests."""
    mock_client = MagicMock()
    mock_client.review_plan_or_diff.return_value = review_response
    mock_client_fn.return_value = mock_client
    return mock_client


class TestPlanReviewOutput:
    def test_plan_review_shows_reviewing_message(self, hello_world, tmp_path):
        """Plan review should output 'TLM is reviewing your plan...' on stderr."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "plan.md").write_text("# Add greeting endpoint\n\nAdd /greet route.")

        captured_stderr = io.StringIO()

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            _mock_plan_client(mock_client_fn, {"decision": "pass", "reason": "Looks good", "issues": []})
            with patch("sys.stderr", captured_stderr):
                result = hook_auto_interviewer_plan(str(hello_world), {}, plans_dir=plans_dir)

        stderr_output = captured_stderr.getvalue()
        assert "TLM is reviewing" in stderr_output

    def test_plan_approved_shows_green_ok(self, hello_world, tmp_path):
        """Approved plan should show green TLM PLAN APPROVED."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "plan.md").write_text("# Plan\nWith TDD steps.")

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            _mock_plan_client(mock_client_fn, {"decision": "pass", "reason": "Plan approved", "issues": []})
            result = hook_auto_interviewer_plan(str(hello_world), {}, plans_dir=plans_dir)

        ctx = result.get("additionalContext", "")
        assert "Plan Approved" in ctx
        assert "TLM" in ctx

    def test_plan_tdd_missing_shows_warning(self, hello_world, tmp_path):
        """Plan without TDD should show TDD warning."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "plan.md").write_text("# Plan\nJust code, no tests mentioned.")

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            _mock_plan_client(mock_client_fn, {
                "decision": "pass",
                "reason": "Plan is acceptable",
                "issues": ["Plan does not follow TDD approach — write tests first"],
            })
            result = hook_auto_interviewer_plan(str(hello_world), {}, plans_dir=plans_dir)

        ctx = result.get("additionalContext", "")
        assert "TDD" in ctx
        assert "PLAN" in ctx

    def test_plan_rejected_shows_rejection(self, hello_world, tmp_path):
        """Rejected plan should show rejection message."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "plan.md").write_text("# Incomplete Plan\nThis plan needs more detail to be viable.")

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            _mock_plan_client(mock_client_fn, {
                "decision": "reject",
                "reason": "Plan is incomplete",
                "issues": ["Missing error handling"],
            })
            result = hook_auto_interviewer_plan(str(hello_world), {}, plans_dir=plans_dir)

        ctx = result.get("additionalContext", "")
        assert "Reject" in ctx or "reject" in ctx or "Missing error handling" in ctx


# ── 3. Prompt learning shows LEARNED FROM YOUR FEEDBACK ───────


class TestPromptLearningOutput:
    def test_correction_visible_in_context(self, hello_world):
        """When cached correction exists, insight is printed to stderr — hook returns {}."""
        cache_dir = hello_world / ".tlm" / "cache"
        cache_dir.mkdir(exist_ok=True)
        (cache_dir / "realtime_insights.json").write_text(json.dumps({
            "corrections": [
                {"correction": "Use PostgreSQL, not SQLite", "timestamp": time.time()}
            ],
            "rules": [],
            "shown_corrections": [],
        }))

        result = hook_prompt_submit(str(hello_world), "Build the database layer")
        # Insight box goes to stderr; MCP tools handle context injection
        assert result == {}

    def test_accumulated_rules_visible(self, hello_world):
        """Accumulated rules are printed to stderr as a knowledge box — hook returns {}."""
        cache_dir = hello_world / ".tlm" / "cache"
        cache_dir.mkdir(exist_ok=True)
        (cache_dir / "realtime_insights.json").write_text(json.dumps({
            "corrections": [],
            "rules": [
                {"rule": "Always use dark mode for UI", "confidence": "high"},
            ],
            "shown_corrections": [],
        }))

        result = hook_prompt_submit(str(hello_world), "Build the settings page")
        # Rules box goes to stderr; MCP tools handle context injection
        assert result == {}

    def test_no_insights_no_extra_context(self, hello_world):
        """Without cached insights, no extra learning context should appear."""
        result = hook_prompt_submit(str(hello_world), "Hello")
        ctx = result.get("additionalContext", "")
        assert "LEARNED" not in ctx


# ── 4. Guard enforcement shows correct messages ──────────────


class TestGuardOutput:
    def test_interview_block_shows_tlm_message(self, hello_world):
        """Write during interview should show TLM INTERVIEW MODE block."""
        write_state(str(hello_world), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(hello_world), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(hello_world / "main.py")},
        })

        assert result.get("decision") == "block"
        assert "TLM" in result.get("reason", "")
        assert "INTERVIEW" in result.get("reason", "")

    def test_approved_implementation_allows_writes(self, hello_world):
        """Implementation with approved spec should allow source writes."""
        write_state(str(hello_world), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        result = hook_guard(str(hello_world), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(hello_world / "main.py")},
        })

        assert result.get("decision") != "block"


# ── 5. CLI hook dispatch ─────────────────────────────────────


class TestCLIHookDispatch:
    def test_stop_dispatch(self, hello_world):
        """tlm _hook stop should output JSON and clean up."""
        runner = CliRunner()
        from tlm.cli import main
        result = runner.invoke(main, ["_hook", "stop", "--path", str(hello_world)])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, dict)

    def test_learn_prompt_bg_dispatch(self, hello_world):
        """tlm _hook _learn_prompt_bg should not error with 'Unknown hook'."""
        runner = CliRunner()
        from tlm.cli import main
        result = runner.invoke(
            main,
            ["_hook", "_learn_prompt_bg", "--path", str(hello_world)],
        )
        # Should not show "Unknown hook" error
        assert "Unknown hook" not in result.output
        assert result.exit_code == 0

    def test_auto_interviewer_dispatch(self, hello_world, tmp_path):
        """tlm _hook auto_interviewer should output JSON with review result."""
        plans_dir = tmp_path / "test_plans"
        plans_dir.mkdir()
        (plans_dir / "plan.md").write_text("# Test Plan with enough content for the minimum length check to pass")

        runner = CliRunner()
        from tlm.cli import main

        with patch("tlm.hooks._get_review_client") as mock_client_fn, \
             patch("tlm.hooks._PLANS_DIR", plans_dir):
            _mock_plan_client(mock_client_fn, {"decision": "pass", "reason": "OK", "issues": []})
            result = runner.invoke(
                main,
                ["_hook", "auto_interviewer", "--path", str(hello_world)],
                input=json.dumps({}),
            )

        assert result.exit_code == 0
        output = result.output
        json_start = output.find("{")
        assert json_start >= 0, f"No JSON found in output: {output}"
        data = json.loads(output[json_start:])
        assert "additionalContext" in data


# ── 6. Full flow: idle → plan → review → implementation ──────


class TestFullFlowE2E:
    def test_complete_flow(self, hello_world, tmp_path):
        """Walk through the full TLM flow from idle to implementation."""
        proj = str(hello_world)

        # 1. Session start
        banner = hook_session_start(proj)
        assert "TLM" in banner
        assert "idle" in banner.lower()

        # 2. Prompt submit in idle — hook returns {} (MCP tools handle context injection)
        result = hook_prompt_submit(proj, "Add a /greet endpoint")
        assert result == {}

        # 3. Transition to interview (simulate Claude classifying)
        write_state(proj, {"phase": "tlm_active", "activity_type": "feature"})

        # 4. Guard blocks source writes during interview
        result = hook_guard(proj, {
            "tool_name": "Write",
            "tool_input": {"file_path": str(hello_world / "main.py")},
        })
        assert result.get("decision") == "block"

        # 5. Plan review (simulate ExitPlanMode)
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "greet.md").write_text(
            "# Add /greet endpoint\n\n"
            "## Steps\n"
            "1. Write tests for /greet route\n"
            "2. Verify tests fail\n"
            "3. Implement the route\n"
            "4. Verify tests pass\n"
        )

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            _mock_plan_client(mock_client_fn, {"decision": "pass", "reason": "Plan approved", "issues": []})
            result = hook_auto_interviewer_plan(proj, {}, plans_dir=plans_dir)

        assert "Plan Approved" in result.get("additionalContext", "")

        # 6. Transition to implementation manually (hook doesn't auto-transition)
        write_state(proj, {"phase": "implementation", "spec_review_status": "approved"})

        result = hook_guard(proj, {
            "tool_name": "Write",
            "tool_input": {"file_path": str(hello_world / "main.py")},
        })
        assert result.get("decision") != "block"

        # 7. Session stop
        result = hook_stop(proj)
        assert isinstance(result, dict)
