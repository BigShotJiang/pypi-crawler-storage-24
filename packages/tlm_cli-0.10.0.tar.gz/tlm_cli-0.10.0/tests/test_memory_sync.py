"""Tests for cross-project memory sync — client-side."""

import json
import os
import sqlite3
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


class TestPullMemoriesClient:
    def test_pull_memories_client_method(self):
        """TLMClient.pull_memories() calls GET /api/v2/learn/memories."""
        from tlm.client import TLMClient

        client = TLMClient(server_url="http://test", api_key="key")

        with patch("httpx.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {
                "user_memories": [{"memory_text": "Use bun", "source": "conversation_learning"}],
                "project_memories": [{"rule_text": "Deploy firebase", "source": "conversation_learning"}],
            }
            mock_get.return_value = mock_resp

            result = client.pull_memories(project_id=42)

            mock_get.assert_called_once()
            call_args = mock_get.call_args
            assert "/api/v2/learn/memories" in call_args[0][0] or "/api/v2/learn/memories" in str(call_args)
            assert result["user_memories"][0]["memory_text"] == "Use bun"
            assert result["project_memories"][0]["rule_text"] == "Deploy firebase"

    def test_pull_memories_without_project_id(self):
        """pull_memories(project_id=0) still works, returns user memories only."""
        from tlm.client import TLMClient

        client = TLMClient(server_url="http://test", api_key="key")

        with patch("httpx.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {
                "user_memories": [],
                "project_memories": [],
            }
            mock_get.return_value = mock_resp

            result = client.pull_memories(project_id=0)
            assert "user_memories" in result


class TestWatcherScopeStorage:
    def test_watcher_stores_user_scope_in_global_db(self, tmp_path):
        """User-scoped memories are stored in global ~/.tlm/knowledge.db."""
        from tlm.watcher import _store_memories

        # Set up project dir with .tlm/
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".tlm").mkdir()

        # Fake global home
        global_tlm = tmp_path / "global_tlm"

        mock_client = MagicMock()
        mock_client.embed.return_value = {"embeddings": []}

        memories = [
            {"text": "Always use bun", "confidence": "high", "tags": ["tooling"], "scope": "user"},
        ]

        with patch("tlm.watcher.GLOBAL_TLM_DIR", global_tlm):
            _store_memories(str(project_dir), memories, mock_client)

        # Check global DB was created
        global_db_path = global_tlm / "knowledge.db"
        assert global_db_path.exists()

        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(global_tlm))
        rules = db.list_rules(source_prefix="watcher_learned_user")
        assert len(rules) >= 1
        assert any("bun" in r["rule_text"] for r in rules)
        db.close()

    def test_watcher_stores_project_scope_locally(self, tmp_path):
        """Project-scoped memories stored in project .tlm/knowledge.db."""
        from tlm.watcher import _store_memories

        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".tlm").mkdir()

        global_tlm = tmp_path / "global_tlm"

        mock_client = MagicMock()
        mock_client.embed.return_value = {"embeddings": []}

        memories = [
            {"text": "Deploy with firebase", "confidence": "medium", "tags": ["deploy"], "scope": "project"},
        ]

        with patch("tlm.watcher.GLOBAL_TLM_DIR", global_tlm):
            _store_memories(str(project_dir), memories, mock_client)

        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(project_dir / ".tlm"))
        rules = db.list_rules(source_prefix="watcher_learned")
        assert len(rules) >= 1
        assert any("firebase" in r["rule_text"] for r in rules)
        db.close()

    def test_watcher_default_scope_is_project(self, tmp_path):
        """Memory without scope field defaults to project storage."""
        from tlm.watcher import _store_memories

        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".tlm").mkdir()

        global_tlm = tmp_path / "global_tlm"

        mock_client = MagicMock()
        mock_client.embed.return_value = {"embeddings": []}

        memories = [
            {"text": "Uses React", "confidence": "medium", "tags": []},  # no scope
        ]

        with patch("tlm.watcher.GLOBAL_TLM_DIR", global_tlm):
            _store_memories(str(project_dir), memories, mock_client)

        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(project_dir / ".tlm"))
        rules = db.list_rules(source_prefix="watcher_learned_project")
        assert len(rules) >= 1
        db.close()


class TestInjectionDualScope:
    def test_injection_loads_from_global_db(self, tmp_path):
        """_load_and_inject_insights reads from global ~/.tlm/knowledge.db."""
        from tlm.hooks import _load_and_inject_insights

        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".tlm").mkdir()

        global_tlm = tmp_path / "global_tlm"
        global_tlm.mkdir(parents=True)

        # Create a global knowledge.db with a user memory
        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(global_tlm))
        db.init_db()
        db.add_rule("Always use bun", source="watcher_learned_user", tags=["tooling"])
        db.close()

        with patch("tlm.hooks.GLOBAL_TLM_DIR", global_tlm):
            result = _load_and_inject_insights(str(project_dir))

        assert result is not None
        assert "bun" in result
        assert "all projects" in result.lower()

    def test_injection_no_double_inject(self, tmp_path):
        """User rules from global DB are not duplicated from project DB."""
        from tlm.hooks import _load_and_inject_insights

        project_dir = tmp_path / "project"
        project_dir.mkdir()
        project_tlm = project_dir / ".tlm"
        project_tlm.mkdir()

        global_tlm = tmp_path / "global_tlm"
        global_tlm.mkdir(parents=True)

        from tlm.knowledge_db import KnowledgeDB

        # Add same rule to BOTH global and project DB
        for tlm_dir, source in [(str(global_tlm), "watcher_learned_user"),
                                 (str(project_tlm), "watcher_learned_user")]:
            db = KnowledgeDB(tlm_dir)
            db.init_db()
            db.add_rule("Always use bun", source=source, tags=["tooling"])
            db.close()

        with patch("tlm.hooks.GLOBAL_TLM_DIR", global_tlm):
            result = _load_and_inject_insights(str(project_dir))

        # "bun" should only appear once (from global, not duplicated from project)
        assert result is not None
        assert result.count("Always use bun") == 1


class TestDedupOnPull:
    def test_dedup_on_pull(self, tmp_path):
        """Same memory text is not inserted twice on pull."""
        from tlm.installer import Installer

        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".tlm").mkdir()

        global_tlm = tmp_path / "global_tlm"

        installer = Installer(str(project_dir), server_url="http://test", api_key="key")

        # Pre-populate with existing rule
        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(project_dir / ".tlm"))
        db.init_db()
        db.add_rule("Deploy with firebase", source="server_synced_project")
        db.close()

        pull_response = {
            "user_memories": [{"memory_text": "Use bun", "source": "conversation_learning", "confidence": 0.9, "tags": []}],
            "project_memories": [
                {"rule_text": "Deploy with firebase", "source": "conversation_learning", "confidence": 0.6, "tags": []},
                {"rule_text": "Use PostgreSQL", "source": "conversation_learning", "confidence": 0.6, "tags": []},
            ],
        }

        with patch("tlm.watcher.GLOBAL_TLM_DIR", global_tlm), \
             patch("tlm.installer.GLOBAL_TLM_DIR", global_tlm):
            installer.pull_memories(1, pull_response)

        # Check project DB — "Deploy with firebase" should NOT be duplicated
        db = KnowledgeDB(str(project_dir / ".tlm"))
        rules = db.list_rules()
        firebase_rules = [r for r in rules if "firebase" in r["rule_text"]]
        assert len(firebase_rules) == 1  # no duplicate
        # "Use PostgreSQL" should be added
        pg_rules = [r for r in rules if "PostgreSQL" in r["rule_text"]]
        assert len(pg_rules) == 1
        db.close()

        # Check global DB has user memory
        global_db = KnowledgeDB(str(global_tlm))
        user_rules = global_db.list_rules()
        assert any("bun" in r["rule_text"] for r in user_rules)
        global_db.close()


class TestInstallPullsMemories:
    @patch("tlm.installer.Installer.create_rule_files")
    @patch("tlm.installer.Installer.generate_claude_md")
    @patch("tlm.installer.Installer.install_hooks")
    @patch("tlm.installer.Installer.create_hook_scripts")
    @patch("tlm.installer.Installer.install_git_hooks")
    @patch("tlm.installer.Installer.finalize")
    @patch("tlm.installer.Installer.pull_memories")
    @patch("tlm.installer.load_project_config")
    def test_install_full_calls_pull_memories(
        self, mock_config, mock_pull, mock_finalize, mock_git,
        mock_hooks, mock_hook_scripts, mock_install_hooks, mock_rules,
        tmp_path,
    ):
        """install_full() calls pull_memories() when project_id exists."""
        from tlm.installer import Installer

        mock_config.return_value = {"project_id": 42}

        installer = Installer(str(tmp_path), server_url="http://test", api_key="key")
        installer.install_full()

        mock_pull.assert_called_once_with("42")
