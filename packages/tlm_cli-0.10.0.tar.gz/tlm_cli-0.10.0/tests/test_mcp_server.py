"""Tests for tlm.mcp_server — MCP tool implementations."""

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.mcp_server import (
    tlm_get_context,
    tlm_review_command,
    tlm_review_plan,
    tlm_review_diff,
    tlm_set_phase,
    tlm_check_gaps,
    tlm_learn,
)


@pytest.fixture
def tlm_project(tmp_path):
    """Create a minimal TLM project structure."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "cache").mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))
    (tlm_dir / "knowledge.md").write_text("Project uses Python\nFastAPI for server\n")
    (tlm_dir / "gaps.json").write_text(json.dumps([
        {"id": "g1", "description": "No CI", "status": "active", "category": "ci", "severity": "high"},
    ]))
    (tmp_path / ".tlm" / "config.json").write_text(json.dumps({
        "project_id": "test-project",
        "quality_control": "standard",
    }))
    return tmp_path


# ── tlm_get_context ──────────────────────────────────────────

def test_tlm_get_context_returns_structured_data(tlm_project):
    """Should return all expected fields."""
    result = json.loads(tlm_get_context(project_root=str(tlm_project)))
    assert "knowledge" in result
    assert "user_preferences" in result
    assert "gaps" in result
    assert "state" in result
    assert result["state"]["phase"] == "idle"


def test_tlm_get_context_with_query_triggers_search(tlm_project):
    """Should include vector search results when query provided."""
    mock_ctx = {
        "knowledge": [],
        "user_preferences": [],
        "learned_rules": [],
        "vector_results": ["deploy needs staging"],
        "gaps": [],
        "new_learnings": [],
    }
    with patch("tlm.mcp_server.get_knowledge_context", return_value=mock_ctx):
        result = json.loads(tlm_get_context(project_root=str(tlm_project), query="deploy"))
        assert len(result["vector_results"]) == 1


def test_tlm_get_context_no_tlm_dir(tmp_path):
    """Should work gracefully without .tlm/ dir."""
    result = json.loads(tlm_get_context(project_root=str(tmp_path)))
    # read_state returns default state even without .tlm/
    assert result["state"]["phase"] == "idle"
    assert result["knowledge"] == []


# ── tlm_review_command ───────────────────────────────────────

def test_tlm_review_command_safe():
    """Safe commands should return safe advisory."""
    result = json.loads(tlm_review_command(command="git status"))
    assert result["advisory"] == "safe"


def test_tlm_review_command_risky():
    """Risky commands should return risky advisory."""
    result = json.loads(tlm_review_command(command="firebase deploy"))
    assert result["advisory"] == "risky"
    assert result["reason"]


# ── tlm_review_plan ──────────────────────────────────────────

def test_tlm_review_plan_approved(tlm_project):
    """Should return approved when server approves."""
    mock_client = MagicMock()
    mock_client.review_plan.return_value = {
        "decision": "pass",
        "reason": "Looks good",
        "issues": [],
    }
    with patch("tlm.mcp_server._get_review_client", return_value=mock_client):
        result = json.loads(tlm_review_plan(
            plan="Build a REST API",
            project_root=str(tlm_project),
        ))
        assert result["advisory"] == "approve"


def test_tlm_review_plan_rejected(tlm_project):
    """Should return revise when server rejects."""
    mock_client = MagicMock()
    mock_client.review_plan.return_value = {
        "decision": "reject",
        "reason": "Missing tests",
        "issues": [{"description": "No test plan"}],
    }
    with patch("tlm.mcp_server._get_review_client", return_value=mock_client):
        result = json.loads(tlm_review_plan(
            plan="Build without tests",
            project_root=str(tlm_project),
        ))
        assert result["advisory"] == "revise"
        assert len(result["issues"]) == 1


def test_tlm_review_plan_server_error(tlm_project):
    """Should fail-open on server error."""
    with patch("tlm.mcp_server._get_review_client", return_value=None):
        result = json.loads(tlm_review_plan(
            plan="anything",
            project_root=str(tlm_project),
        ))
        assert result["advisory"] == "approve"
        assert "unavailable" in result["reason"].lower()


# ── tlm_review_diff ──────────────────────────────────────────

def test_tlm_review_diff_pass(tlm_project):
    """Should pass clean diffs."""
    mock_client = MagicMock()
    mock_client.review_diff.return_value = {
        "decision": "pass",
        "reason": "Clean",
        "issues": [],
    }
    with patch("tlm.mcp_server._get_review_client", return_value=mock_client):
        result = json.loads(tlm_review_diff(
            diff="--- a/foo.py\n+++ b/foo.py\n+print('hello')",
            project_root=str(tlm_project),
        ))
        assert result["advisory"] == "pass"


# ── tlm_set_phase ────────────────────────────────────────────

def test_tlm_set_phase_updates_state(tlm_project):
    """Should update state.json phase."""
    result = json.loads(tlm_set_phase(
        phase="implementation",
        project_root=str(tlm_project),
    ))
    assert result["phase"] == "implementation"

    # Verify state file was actually updated
    state = json.loads((tlm_project / ".tlm" / "state.json").read_text())
    assert state["phase"] == "implementation"


def test_tlm_set_phase_with_activity(tlm_project):
    """Should set activity_type when provided."""
    result = json.loads(tlm_set_phase(
        phase="tlm_active",
        activity_type="new_feature",
        project_root=str(tlm_project),
    ))
    assert result["phase"] == "tlm_active"
    assert result["activity_type"] == "new_feature"


# ── tlm_check_gaps ───────────────────────────────────────────

def test_tlm_check_gaps_returns_active(tlm_project):
    """Should return active gaps."""
    result = json.loads(tlm_check_gaps(project_root=str(tlm_project)))
    assert len(result["gaps"]) == 1
    assert result["gaps"][0]["description"] == "No CI"


def test_tlm_check_gaps_keyword_filter(tlm_project):
    """Should filter gaps by keyword."""
    result = json.loads(tlm_check_gaps(query="ci", project_root=str(tlm_project)))
    assert len(result["gaps"]) == 1

    result = json.loads(tlm_check_gaps(query="nonexistent", project_root=str(tlm_project)))
    assert len(result["gaps"]) == 0


# ── tlm_learn ────────────────────────────────────────────────

def test_tlm_learn_prompt_fires_background(tlm_project):
    """Should spawn background learning process."""
    with patch("tlm.mcp_server.subprocess") as mock_sub:
        result = json.loads(tlm_learn(
            learn_type="prompt",
            data="User asked about deployment",
            project_root=str(tlm_project),
        ))
        assert result["status"] == "accepted"


def test_tlm_learn_session_end(tlm_project):
    """Should handle session end learning."""
    with patch("tlm.mcp_server.subprocess"):
        result = json.loads(tlm_learn(
            learn_type="session",
            data="Session ended",
            project_root=str(tlm_project),
        ))
        assert result["status"] == "accepted"


# ── Graceful degradation ────────────────────────────────────

def test_graceful_degradation_no_tlm_dir(tmp_path):
    """Tools should work without .tlm/ dir."""
    # get_context — read_state returns default even without .tlm/
    result = json.loads(tlm_get_context(project_root=str(tmp_path)))
    assert result["state"]["phase"] == "idle"

    # check_gaps
    result = json.loads(tlm_check_gaps(project_root=str(tmp_path)))
    assert result["gaps"] == []

    # set_phase — should still work (creates state)
    result = json.loads(tlm_set_phase(phase="idle", project_root=str(tmp_path)))
    assert result["phase"] == "idle"


def test_graceful_degradation_server_timeout(tlm_project):
    """Should fail-open on timeout."""
    mock_client = MagicMock()
    mock_client.review_plan.side_effect = Exception("timeout")
    with patch("tlm.mcp_server._get_review_client", return_value=mock_client):
        result = json.loads(tlm_review_plan(
            plan="anything",
            project_root=str(tlm_project),
        ))
        assert result["advisory"] == "approve"
