"""Tests for TLM visibility improvements — attribution, stderr messaging, banner enhancements."""

import json
import time
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    _load_and_inject_insights,
    GLOBAL_TLM_DIR,
)
from tlm.gaps import add_gap
from tlm.state import write_state
from tlm.config import save_project_config
from tlm.knowledge_db import KnowledgeDB


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": "proj_1",
    })
    return tmp_path


@pytest.fixture
def global_tlm_dir(tmp_path, monkeypatch):
    """Create a temporary ~/.tlm/ with knowledge.db containing user rules."""
    global_dir = tmp_path / "global_tlm"
    global_dir.mkdir()
    monkeypatch.setattr("tlm.hooks.GLOBAL_TLM_DIR", global_dir)

    db = KnowledgeDB(str(global_dir))
    db.init_db()
    db.add_rule("Always use bun for package management, never npm",
                source="watcher_learned_user")
    db.add_rule("Never auto-commit without asking",
                source="watcher_learned_user")
    db.close()
    return global_dir


@pytest.fixture
def project_rules(tlm_project):
    """Add project-scoped rules to the project's knowledge.db."""
    tlm_dir = tlm_project / ".tlm"
    db = KnowledgeDB(str(tlm_dir))
    db.init_db()
    db.add_rule("This project deploys with Firebase",
                source="watcher_learned_project")
    db.add_rule("Tests go in __tests__/ directory",
                source="watcher_learned_project")
    db.close()
    return tlm_project


class TestAttributionInstruction:
    """Change 1: Attribution instruction in additionalContext."""

    def test_attribution_instruction_in_additional_context(
        self, tlm_project, global_tlm_dir
    ):
        """additionalContext should include instruction telling Claude to attribute TLM."""
        result = _load_and_inject_insights(str(tlm_project))
        assert result is not None
        assert "IMPORTANT: When you apply any of these preferences" in result
        assert "backtick-wrapped" in result

    def test_attribution_instruction_includes_example(
        self, tlm_project, global_tlm_dir
    ):
        """Attribution instruction should include an example format."""
        result = _load_and_inject_insights(str(tlm_project))
        assert result is not None
        assert "TLM:" in result


class TestStderrMessaging:
    """Change 2: Enhanced stderr messaging — colored boxes."""

    def test_stderr_shows_box_not_flat_list(
        self, tlm_project, global_tlm_dir, capsys
    ):
        """stderr should show colored boxes, not flat list format."""
        _load_and_inject_insights(str(tlm_project))
        captured = capsys.readouterr()
        assert "┌─ TLM" in captured.err
        assert "└" in captured.err
        # Old format should be gone
        assert "Applying" not in captured.err
        assert "learned preferences:" not in captured.err

    def test_stderr_shows_separate_boxes_per_scope(
        self, tlm_project, global_tlm_dir, project_rules, capsys
    ):
        """stderr should show separate boxes for user prefs and project rules."""
        _load_and_inject_insights(str(tlm_project))
        captured = capsys.readouterr()
        assert "Your preferences" in captured.err
        assert "Learned from conversations" in captured.err


class TestSessionBanner:
    """Changes 3 & 5: User preferences count and new learnings in banner."""

    def test_session_banner_shows_user_preferences_count(
        self, tlm_project, global_tlm_dir
    ):
        """Banner should show count of user-scoped preferences."""
        result = hook_session_start(str(tlm_project))
        assert "User preferences" in result
        # Should show count of 2 (from global_tlm_dir fixture)
        assert "(2)" in result

    def test_session_banner_shows_new_learnings(
        self, tlm_project, global_tlm_dir
    ):
        """Banner should show new learnings from last_learned.json."""
        # Write last_learned.json with recent memories
        cache_dir = global_tlm_dir / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        last_learned = cache_dir / "last_learned.json"
        last_learned.write_text(json.dumps([
            {"text": "User prefers explicit error messages",
             "timestamp": time.time()},
            {"text": "This project uses pytest-asyncio",
             "timestamp": time.time()},
        ]))

        result = hook_session_start(str(tlm_project))
        assert "New learnings" in result
        assert "User prefers explicit error messages" in result

    def test_session_banner_no_new_learnings_when_empty(
        self, tlm_project, global_tlm_dir
    ):
        """Banner should NOT show new learnings section when no recent learnings."""
        result = hook_session_start(str(tlm_project))
        # No last_learned.json exists, so no section
        assert "New learnings" not in result


class TestWatcherLastLearned:
    """Change 4: Watcher writes last_learned.json."""

    def test_watcher_writes_last_learned_json(self, tmp_path, monkeypatch):
        """_store_memories should write to ~/.tlm/cache/last_learned.json."""
        from tlm.watcher import _store_memories, GLOBAL_TLM_DIR as WATCHER_GLOBAL

        # Set up global dir
        global_dir = tmp_path / "global_tlm"
        global_dir.mkdir()
        (global_dir / "cache").mkdir(parents=True)
        monkeypatch.setattr("tlm.watcher.GLOBAL_TLM_DIR", global_dir)

        # Set up project dir
        project_root = tmp_path / "project"
        project_root.mkdir()
        tlm_dir = project_root / ".tlm"
        tlm_dir.mkdir()

        # Init project knowledge.db
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        db.close()

        # Mock the client (embed call)
        mock_client = type('MockClient', (), {
            'embed': lambda self, texts: {"embeddings": []}
        })()

        memories = [
            {"text": "User prefers bun over npm", "scope": "user", "tags": []},
            {"text": "Project uses Firebase", "scope": "project", "tags": []},
        ]

        _store_memories(str(project_root), memories, mock_client)

        # Check last_learned.json was written
        last_learned_path = global_dir / "cache" / "last_learned.json"
        assert last_learned_path.exists(), "last_learned.json should be created"

        data = json.loads(last_learned_path.read_text())
        assert len(data) >= 2
        texts = [m["text"] for m in data]
        assert "User prefers bun over npm" in texts
        assert "Project uses Firebase" in texts
        # Each entry should have a timestamp
        for entry in data:
            assert "timestamp" in entry

    def test_watcher_appends_to_existing_last_learned(self, tmp_path, monkeypatch):
        """_store_memories should append to existing last_learned.json, not overwrite."""
        from tlm.watcher import _store_memories

        global_dir = tmp_path / "global_tlm"
        global_dir.mkdir()
        cache_dir = global_dir / "cache"
        cache_dir.mkdir(parents=True)
        monkeypatch.setattr("tlm.watcher.GLOBAL_TLM_DIR", global_dir)

        # Pre-existing entry
        last_learned = cache_dir / "last_learned.json"
        last_learned.write_text(json.dumps([
            {"text": "Old memory", "timestamp": time.time() - 3600}
        ]))

        project_root = tmp_path / "project"
        project_root.mkdir()
        tlm_dir = project_root / ".tlm"
        tlm_dir.mkdir()
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        db.close()

        mock_client = type('MockClient', (), {
            'embed': lambda self, texts: {"embeddings": []}
        })()

        _store_memories(str(project_root), [
            {"text": "New memory", "scope": "project", "tags": []}
        ], mock_client)

        data = json.loads(last_learned.read_text())
        texts = [m["text"] for m in data]
        assert "Old memory" in texts
        assert "New memory" in texts


class TestColoredBoxOutput:
    """Colored box output on stderr for each knowledge injection category."""

    def test_user_preferences_show_colored_box(
        self, tlm_project, global_tlm_dir, capsys
    ):
        """User preferences should render as a colored box on stderr."""
        _load_and_inject_insights(str(tlm_project))
        err = capsys.readouterr().err
        assert "┌─ TLM" in err
        assert "Your preferences" in err
        assert "bun" in err
        assert "└" in err

    def test_project_rules_show_colored_box(
        self, tlm_project, global_tlm_dir, project_rules, capsys
    ):
        """Project-scoped learned rules should render as a colored box."""
        _load_and_inject_insights(str(tlm_project))
        err = capsys.readouterr().err
        assert "Learned from conversations" in err
        assert "Firebase" in err

    def test_vector_search_results_show_colored_box(
        self, tlm_project, global_tlm_dir, capsys
    ):
        """MemX vector search results should render as a colored box."""
        mock_client = MagicMock()
        mock_client.search_memories.return_value = {
            "memories": [
                {"text": "Always run lint before commit", "similarity": 0.9},
                {"text": "Use pytest-asyncio for async tests", "similarity": 0.85},
            ]
        }
        with patch("tlm.client.TLMClient", return_value=mock_client), \
             patch("tlm.config.load_credentials", return_value={
                 "server_url": "http://fake", "api_key": "key"
             }):
            _load_and_inject_insights(str(tlm_project), prompt_text="how to test")
        err = capsys.readouterr().err
        assert "Relevant knowledge" in err
        assert "lint before commit" in err

    def test_correction_shows_magenta_box(
        self, tlm_project, global_tlm_dir, capsys
    ):
        """New corrections from feedback should show with star icon."""
        cache_dir = tlm_project / ".tlm" / "cache"
        insights = {
            "corrections": [{"correction": "Use real DB in integration tests"}],
            "shown_corrections": [],
            "rules": [],
        }
        (cache_dir / "realtime_insights.json").write_text(json.dumps(insights))

        _load_and_inject_insights(str(tlm_project))
        err = capsys.readouterr().err
        assert "Learned from your feedback" in err
        assert "real DB" in err
        assert "\u2605" in err  # ★

    def test_gap_warning_shows_yellow_box(self, tlm_project, capsys):
        """Gap warnings should render with yellow styling."""
        add_gap(str(tlm_project), {
            "id": "staging_env",
            "category": "staging environment",
            "description": "No staging env exists",
            "status": "open",
            "severity": "high",
        })
        with patch("tlm.hooks._fire_prompt_learning_bg"):
            result = hook_prompt_submit(
                str(tlm_project), prompt_text="deploy to staging"
            )
        err = capsys.readouterr().err
        assert "Gap Warning" in err or "staging" in err

    def test_no_box_when_no_knowledge(self, tlm_project, capsys, monkeypatch):
        """No box output when there's nothing to inject."""
        # Point GLOBAL_TLM_DIR to empty dir so no user rules are found
        empty = tlm_project / "empty_global"
        empty.mkdir()
        monkeypatch.setattr("tlm.hooks.GLOBAL_TLM_DIR", empty)
        _load_and_inject_insights(str(tlm_project))
        err = capsys.readouterr().err
        assert "\u250c\u2500 TLM" not in err  # ┌─ TLM

    def test_boxes_contain_ansi_color_codes(
        self, tlm_project, global_tlm_dir, capsys
    ):
        """Box output should contain ANSI escape codes for color."""
        _load_and_inject_insights(str(tlm_project))
        err = capsys.readouterr().err
        assert "\033[" in err

    def test_old_flat_format_replaced(
        self, tlm_project, global_tlm_dir, capsys
    ):
        """Old flat format should no longer appear."""
        _load_and_inject_insights(str(tlm_project))
        err = capsys.readouterr().err
        assert "\u25c6" in err  # ◆
        assert "Applying" not in err
        assert "learned preferences:" not in err
