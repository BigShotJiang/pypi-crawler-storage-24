"""Tests for TLMClient.search_memories() method."""

from unittest.mock import patch, MagicMock

import pytest

from tlm.client import TLMClient


class TestClientSearchMemories:

    def setup_method(self):
        self.client = TLMClient("https://test.example.com", "test-api-key")

    def test_search_memories_calls_correct_endpoint(self):
        """Verifies POST to /api/v2/learnings/search."""
        with patch.object(self.client, "_post_v2", return_value={"memories": []}) as mock:
            self.client.search_memories(query="how to deploy")
            mock.assert_called_once()
            args = mock.call_args
            assert args[0][0] == "/learnings/search"

    def test_search_memories_passes_params(self):
        """query, project_id, scope, limit all forwarded."""
        with patch.object(self.client, "_post_v2", return_value={"memories": []}) as mock:
            self.client.search_memories(
                query="deploy steps", project_id="p1", scope="project", limit=5,
            )
            body = mock.call_args[0][1]
            assert body["query"] == "deploy steps"
            assert body["project_id"] == "p1"
            assert body["scope"] == "project"
            assert body["limit"] == 5

    def test_search_memories_returns_memories_list(self):
        """Response parsed correctly."""
        mock_response = {
            "memories": [
                {"id": "m1", "text": "use bun", "similarity": 0.9},
                {"id": "m2", "text": "test first", "similarity": 0.8},
            ]
        }
        with patch.object(self.client, "_post_v2", return_value=mock_response):
            result = self.client.search_memories(query="packages")
            assert len(result["memories"]) == 2
            assert result["memories"][0]["text"] == "use bun"
