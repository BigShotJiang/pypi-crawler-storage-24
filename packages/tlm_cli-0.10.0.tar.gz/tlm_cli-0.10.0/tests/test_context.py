"""Tests for tlm.context — knowledge loading and context assembly."""

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.context import get_knowledge_context


@pytest.fixture
def tlm_project(tmp_path):
    """Create a minimal TLM project structure."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "cache").mkdir()
    (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))
    return tmp_path


def test_get_knowledge_context_returns_structured_data(tlm_project):
    """Should return a dict with expected top-level keys."""
    ctx = get_knowledge_context(str(tlm_project))
    assert isinstance(ctx, dict)
    assert "knowledge" in ctx
    assert "user_preferences" in ctx
    assert "learned_rules" in ctx
    assert "vector_results" in ctx
    assert "gaps" in ctx


def test_get_knowledge_context_empty_project(tmp_path):
    """Should return empty dict for a project without .tlm/ dir."""
    ctx = get_knowledge_context(str(tmp_path))
    assert isinstance(ctx, dict)
    assert ctx["knowledge"] == []
    assert ctx["user_preferences"] == []
    assert ctx["learned_rules"] == []
    assert ctx["vector_results"] == []
    assert ctx["gaps"] == []


def test_get_knowledge_context_with_knowledge_md(tlm_project):
    """Should load facts from knowledge.md."""
    knowledge_md = tlm_project / ".tlm" / "knowledge.md"
    knowledge_md.write_text("# Knowledge\n\nFact one about the project\nFact two about architecture\n")
    ctx = get_knowledge_context(str(tlm_project))
    assert len(ctx["knowledge"]) == 2
    assert "Fact one" in ctx["knowledge"][0]


def test_get_knowledge_context_with_gaps(tlm_project):
    """Should include active gaps."""
    gaps_file = tlm_project / ".tlm" / "gaps.json"
    gaps_file.write_text(json.dumps([
        {"id": "g1", "description": "No tests", "status": "active", "category": "testing", "severity": "high"},
    ]))
    ctx = get_knowledge_context(str(tlm_project))
    assert len(ctx["gaps"]) == 1
    assert ctx["gaps"][0]["description"] == "No tests"


def test_get_knowledge_context_with_project_rules(tlm_project):
    """Should load learned rules from knowledge.db."""
    # Mock KnowledgeDB to avoid SQLite dependency in unit tests
    mock_db = MagicMock()
    mock_db.list_rules.return_value = [
        {"rule_text": "Always use TDD", "source": "watcher_learned"},
        {"rule_text": "Run tests before commit", "source": "watcher_learned"},
    ]

    with patch("tlm.context.KnowledgeDB", return_value=mock_db):
        # Create the db file so the code path is triggered
        (tlm_project / ".tlm" / "knowledge.db").write_text("")
        ctx = get_knowledge_context(str(tlm_project))
        assert len(ctx["learned_rules"]) == 2
        assert "Always use TDD" in ctx["learned_rules"][0]


def test_get_knowledge_context_with_user_prefs(tlm_project):
    """Should load user preferences from ~/.tlm/knowledge.db."""
    mock_db = MagicMock()
    mock_db.list_rules.return_value = [
        {"rule_text": "Always use bun", "source": "server_synced_user"},
    ]

    with patch("tlm.context.GLOBAL_TLM_DIR", tlm_project / "global_tlm"):
        global_dir = tlm_project / "global_tlm"
        global_dir.mkdir()
        (global_dir / "knowledge.db").write_text("")

        with patch("tlm.context.KnowledgeDB", return_value=mock_db):
            ctx = get_knowledge_context(str(tlm_project))
            assert len(ctx["user_preferences"]) == 1
            assert "Always use bun" in ctx["user_preferences"][0]


def test_get_knowledge_context_with_vector_search(tlm_project):
    """Should call MemX search when query is provided."""
    mock_client = MagicMock()
    mock_client.search_memories.return_value = {
        "memories": [{"text": "Deploy requires staging first"}]
    }

    with patch("tlm.context.load_credentials", return_value={"server_url": "http://test", "api_key": "key"}):
        with patch("tlm.context.TLMClient", return_value=mock_client):
            with patch("tlm.context.load_project_config", return_value={"project_id": "p1"}):
                ctx = get_knowledge_context(str(tlm_project), query="deploy")
                assert len(ctx["vector_results"]) == 1
                assert "Deploy requires staging first" in ctx["vector_results"][0]
                mock_client.search_memories.assert_called_once()


def test_get_knowledge_context_server_error(tlm_project):
    """Should gracefully degrade on server failure."""
    with patch("tlm.context.load_credentials", side_effect=Exception("no creds")):
        ctx = get_knowledge_context(str(tlm_project), query="anything")
        # Should not raise, just return empty vector_results
        assert ctx["vector_results"] == []


def test_get_knowledge_context_with_new_learnings(tlm_project):
    """Should include new learnings from cache."""
    cache_dir = tlm_project / ".tlm" / "cache"
    last_learned = cache_dir / "last_learned.json"
    last_learned.write_text(json.dumps([
        {"text": "New thing learned"},
    ]))
    ctx = get_knowledge_context(str(tlm_project))
    assert len(ctx.get("new_learnings", [])) == 1
