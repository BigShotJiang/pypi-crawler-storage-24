from __future__ import annotations

from pathlib import Path

from openclaw_lite.config import ConfigManager
from openclaw_lite.interfaces.web_ui import (
    render_settings_page,
    update_config_from_form,
    update_onboarding_from_form,
    validate_onboarding_form,
)


def test_render_settings_page_contains_key_fields() -> None:
    html = render_settings_page(
        {
            "telegram": {"bot_token": "123", "owner_user_ids": [1]},
            "providers": {
                "default": "claude",
                "items": {
                    "openai": {"api_key": "sk-openai", "default_model": "gpt-test"},
                    "gemini": {"api_key": "gm-key", "default_model": "gemini-test"},
                    "claude": {"api_key": "sk-ant", "default_model": "claude-test"},
                }
            },
        }
    )
    assert "OpenAI API Key" in html
    assert "Gemini API Key" in html
    assert "Claude API Key" in html
    assert "Telegram Bot Token" in html
    assert "Default Provider" in html
    assert "type='text' name='telegram_bot_token'" in html
    assert "type='text' name='openai_api_key'" in html
    assert "type='text' name='gemini_api_key'" in html
    assert "type='text' name='claude_api_key'" in html


def test_update_config_from_form_saves_provider_keys(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    manager = ConfigManager(config_path)
    update_config_from_form(
        manager,
        {
            "telegram_bot_token": "bot:token",
            "telegram_owner_user_ids": "1,2",
            "telegram_allowed_user_ids": "3",
            "telegram_allowed_chat_ids": "-1001",
            "default_provider": "claude",
            "openai_api_key": "sk-openai",
            "openai_default_model": "gpt-x",
            "gemini_api_key": "gm-key",
            "gemini_default_model": "gemini-x",
            "claude_api_key": "ant-key",
            "claude_default_model": "claude-x",
            "openrouter_api_key": "or-key",
            "openrouter_base_url": "https://example.test/v1",
        },
    )
    reloaded = ConfigManager(config_path)
    assert reloaded.get("telegram.bot_token") == "bot:token"
    assert reloaded.get("telegram.owner_user_ids") == [1, 2]
    assert reloaded.get("providers.default") == "claude"
    assert reloaded.get("providers.items.openai.api_key") == "sk-openai"
    assert reloaded.get("providers.items.gemini.api_key") == "gm-key"
    assert reloaded.get("providers.items.claude.api_key") == "ant-key"


def test_validate_onboarding_form_requires_token_and_selected_provider_key() -> None:
    errors = validate_onboarding_form({"default_provider": "gemini", "telegram_bot_token": ""})
    assert any("Telegram Bot Token" in item for item in errors)
    assert any("Gemini API Key" in item for item in errors)


def test_update_onboarding_from_form_sets_default_provider(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    manager = ConfigManager(config_path)
    update_onboarding_from_form(
        manager,
        {
            "telegram_bot_token": "bot:token",
            "telegram_owner_user_ids": "42",
            "telegram_allowed_chat_ids": "-10022",
            "default_provider": "gemini",
            "openai_api_key": "",
            "openai_default_model": "gpt-4.1-mini",
            "gemini_api_key": "gm-key",
            "gemini_default_model": "gemini-2.5-flash",
            "claude_api_key": "",
            "claude_default_model": "claude-3-7-sonnet-latest",
        },
    )
    reloaded = ConfigManager(config_path)
    assert reloaded.get("telegram.bot_token") == "bot:token"
    assert reloaded.get("telegram.owner_user_ids") == [42]
    assert reloaded.get("telegram.allowed_chat_ids") == [-10022]
    assert reloaded.get("providers.default") == "gemini"
    assert reloaded.get("providers.items.gemini.api_key") == "gm-key"
    assert reloaded.get("providers.items.gemini.default_model") == "gemini-2.5-flash"
    assert reloaded.get("providers.items.gemini.type") == "gemini"


def test_update_onboarding_preserves_owner_ids_when_form_omits_field(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    manager = ConfigManager(config_path)
    manager.set("telegram.owner_user_ids", [42], backup_reason="test-owner")
    manager.set("telegram.allowed_user_ids", [7], backup_reason="test-allowed")

    update_onboarding_from_form(
        manager,
        {
            "telegram_bot_token": "bot:token",
            "default_provider": "openai",
            "openai_api_key": "sk-openai",
            "openai_default_model": "gpt-4.1-mini",
        },
    )

    reloaded = ConfigManager(config_path)
    assert reloaded.get("telegram.owner_user_ids") == [42]
    assert reloaded.get("telegram.allowed_user_ids") == [7]
