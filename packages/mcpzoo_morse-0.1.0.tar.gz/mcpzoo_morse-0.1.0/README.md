# mcpzoo-morse

> 摩尔斯电码 — 文本与摩尔斯电码互转

## Installation

```bash
uvx mcpzoo-morse
```

## uvx JSON

```json
{
  "mcpServers": {
    "morse": {
      "args": ["mcpzoo-morse"],
      "command": "uvx"
    }
  }
}
```
