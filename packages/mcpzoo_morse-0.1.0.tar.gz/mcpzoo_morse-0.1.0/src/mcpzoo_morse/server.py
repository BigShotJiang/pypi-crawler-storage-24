from mcp.server.fastmcp import FastMCP

mcp = FastMCP("morse")

CHAR_TO_MORSE = {
    "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".", "F": "..-.",
    "G": "--.", "H": "....", "I": "..", "J": ".---", "K": "-.-", "L": ".-..",
    "M": "--", "N": "-.", "O": "---", "P": ".--.", "Q": "--.-", "R": ".-.",
    "S": "...", "T": "-", "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
    "Y": "-.--", "Z": "--..",
    "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-",
    "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
    " ": "/",
}
MORSE_TO_CHAR = {v: k for k, v in CHAR_TO_MORSE.items()}


@mcp.tool()
def text_to_morse(text: str) -> str:
    """将文本转换为摩尔斯电码。"""
    result = []
    for ch in text.upper():
        if ch in CHAR_TO_MORSE:
            result.append(CHAR_TO_MORSE[ch])
        else:
            result.append(f"[{ch}]")
    return " ".join(result)


@mcp.tool()
def morse_to_text(morse: str) -> str:
    """将摩尔斯电码转换为文本。"""
    result = []
    for code in morse.strip().split(" "):
        if code in MORSE_TO_CHAR:
            result.append(MORSE_TO_CHAR[code])
        elif code == "":
            continue
        else:
            result.append(f"[{code}]")
    return "".join(result)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
