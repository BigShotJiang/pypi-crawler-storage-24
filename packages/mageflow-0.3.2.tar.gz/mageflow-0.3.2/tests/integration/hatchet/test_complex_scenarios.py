import asyncio

import pytest

from tests.integration.hatchet.assertions import (
    assert_chain_done,
    assert_redis_is_clean,
    assert_signature_done,
    assert_signature_not_called,
    assert_swarm_task_done,
    get_runs,
)
from tests.integration.hatchet.conftest import HatchetInitData
from tests.integration.hatchet.models import CommandMessageWithResult
from tests.integration.hatchet.worker import (
    cancel_retry,
    error_callback,
    retry_once,
    task1_callback,
    task2,
    task2_with_result,
    task3,
    task_with_data,
)
from thirdmagic.chain.model import ChainTaskSignature
from thirdmagic.swarm.model import SwarmConfig
from thirdmagic.task import TaskSignature


@pytest.mark.asyncio(loop_scope="session")
async def test__swarm_with_swarms_and_chains__sanity(
    hatchet_client_init: HatchetInitData,
    test_ctx,
    ctx_metadata,
    trigger_options,
):
    # Arrange
    redis_client, hatchet = (
        hatchet_client_init.redis_client,
        hatchet_client_init.hatchet,
    )
    chain_tasks: list[ChainTaskSignature] = []
    field_int_val = 13
    for i in range(4):
        error_signature = await hatchet.asign(task2_with_result)
        task_sign = await hatchet.asign(
            task_with_data, field_int=field_int_val, field_list=[]
        )
        chain = await hatchet.achain(
            [task1_callback, retry_once, task_sign], error=error_signature
        )
        chain_tasks.append(chain)
    triggered_error = await hatchet.asign(error_callback)
    not_triggered_success = await hatchet.asign(task1_callback)
    failed_chain = await hatchet.achain(
        [task3, cancel_retry], error=triggered_error, success=not_triggered_success
    )

    base_kwargs = {"test_ctx": {"base_swarm_ctx": 1}}
    base_swarm = await hatchet.aswarm(
        tasks=[task2, task3], is_swarm_closed=True, **base_kwargs
    )
    final_swarm_success = await hatchet.asign(task2_with_result)

    main_swarm_kwargs = {"more_context": {"main_swarm_data": 2}}
    main_swarm = await hatchet.aswarm(
        tasks=chain_tasks + [failed_chain, base_swarm],
        is_swarm_closed=True,
        success_callbacks=[final_swarm_success],
        config=SwarmConfig(max_concurrency=2),
        **main_swarm_kwargs,
    )
    tasks = await TaskSignature.afind()
    tasks_map = {task.key: task for task in tasks}

    task_res_param = {"2": "chain"}
    msg = CommandMessageWithResult(base_data=test_ctx, task_result=task_res_param)

    # Act
    await main_swarm.aio_run_no_wait(msg, options=trigger_options)

    # Assert
    await asyncio.sleep(40)
    runs = await get_runs(hatchet, ctx_metadata)

    # Check good chains were successful
    msg_dump = msg.model_dump(mode="json", exclude_unset=True)
    for chain in chain_tasks:
        # basic chain check
        assert_chain_done(runs, chain, tasks, check_callbacks=False)

        # Check kwargs for an inner task was called
        signed_task = tasks_map[chain.tasks[-1]]
        assert_signature_done(runs, signed_task, field_int=field_int_val)

        # Check the first task is called with msg params
        first_task = tasks_map[chain.tasks[0]]
        assert_signature_done(runs, first_task, **msg_dump, **main_swarm_kwargs)

        # Check error was not called
        for error in chain.error_callbacks:
            assert_signature_not_called(runs, error)

    # Check error signature triggered for fail chain
    assert_signature_done(runs, triggered_error)
    assert_signature_not_called(runs, not_triggered_success)

    # Check the inner swarm is done
    assert_swarm_task_done(
        runs,
        base_swarm,
        tasks,
        swarm_msg=msg,
        check_callbacks=False,
        **base_kwargs,
        # **main_swarm_kwargs
    )
    # Assert swarms were called with params
    first_task = tasks_map[base_swarm.tasks[0]]
    assert_signature_done(runs, first_task, base_data=test_ctx)
    second_task = tasks_map[base_swarm.tasks[1]]
    assert_signature_done(runs, second_task, **msg_dump)

    # Check final success was called
    assert_signature_done(runs, final_swarm_success)

    # Check that Redis is clean except for persistent keys
    await assert_redis_is_clean(redis_client)


# TODO - test swarm also as callback for task (error and success), and as part of a chain
# TODO - test swarm and chain as sub tasks that start with aio_run_in_swarm
# TODO - test chain also as callback for task (error and success), and as part of a chain
