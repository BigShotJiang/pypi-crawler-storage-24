import asyncio
from datetime import datetime

import pytest

import mageflow
from tests.integration.hatchet.assertions import (
    assert_paused,
    assert_redis_is_clean,
    assert_swarm_task_done,
    assert_task_did_not_repeat,
    get_runs,
)
from tests.integration.hatchet.conftest import HatchetInitData
from tests.integration.hatchet.models import ContextMessage
from tests.integration.hatchet.worker import sleep_task, task1, task2, task3
from thirdmagic.swarm.model import SwarmConfig
from thirdmagic.task import TaskSignature


@pytest.mark.asyncio(loop_scope="session")
async def test__swarm_soft_paused_data_is_saved_in_redis__then_resume_check_finish(
    hatchet_client_init: HatchetInitData, test_ctx, ctx_metadata, trigger_options
):
    # Arrange
    redis_client, hatchet = (
        hatchet_client_init.redis_client,
        hatchet_client_init.hatchet,
    )
    sleep_time = 4
    swarm_sleep_task_sign = await mageflow.asign(sleep_task, sleep_time=sleep_time)
    sleep_tasks = await swarm_sleep_task_sign.aduplicate_many(3)
    swarm_signature = await mageflow.aswarm(
        tasks=[task1, swarm_sleep_task_sign, *sleep_tasks, task1, task2, task3],
        config=SwarmConfig(max_concurrency=3),
    )
    await swarm_signature.close_swarm()
    message = ContextMessage(base_data=test_ctx)

    # Act
    await swarm_signature.pause_task()
    await swarm_signature.aio_run_no_wait(message, options=trigger_options)
    # await asyncio.sleep(1000)
    pause_time = datetime.now()
    await asyncio.sleep(10)
    # await asyncio.sleep(1000)

    from hatchet_sdk.runnables.contextvars import ctx_additional_metadata

    add_metadata = ctx_additional_metadata.get() or {}
    add_metadata.update(ctx_metadata)
    ctx_additional_metadata.set(add_metadata)

    tasks = await TaskSignature.afind()
    resume_time = datetime.now()
    await swarm_signature.resume()
    await asyncio.sleep(70)

    # Assert
    runs = await get_runs(hatchet, ctx_metadata)

    tasks_map = {task.key: task for task in tasks}
    signature_tasks = [tasks_map[sub_task_id] for sub_task_id in swarm_signature.tasks]
    assert_paused(runs, signature_tasks, pause_time, resume_time)
    assert_task_did_not_repeat(runs)

    assert_swarm_task_done(runs, swarm_signature, tasks)
    await assert_redis_is_clean(redis_client)
