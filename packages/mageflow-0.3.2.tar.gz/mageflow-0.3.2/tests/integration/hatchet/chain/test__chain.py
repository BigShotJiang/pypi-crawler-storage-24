import asyncio

import pytest

import mageflow
from tests.integration.hatchet.assertions import (
    assert_chain_done,
    assert_redis_is_clean,
    assert_signature_done,
    assert_signature_failed,
    get_runs,
)
from tests.integration.hatchet.conftest import HatchetInitData
from tests.integration.hatchet.models import ContextMessage
from tests.integration.hatchet.worker import (
    chain_callback,
    error_callback,
    fail_task,
    task2,
    task3,
)
from thirdmagic.task import TaskSignature


@pytest.mark.asyncio(loop_scope="session")
async def test_chain_integration(
    hatchet_client_init: HatchetInitData,
    test_ctx,
    ctx_metadata,
    trigger_options,
    sign_task1,
    sign_callback1,
):
    # Arrange
    redis_client, hatchet = (
        hatchet_client_init.redis_client,
        hatchet_client_init.hatchet,
    )
    additional_text_ctx = {"more_data": True}
    message = ContextMessage(base_data=test_ctx)

    signature2 = await mageflow.asign(task2, success_callbacks=[sign_callback1])
    chain_success_error_callback = await mageflow.asign(error_callback)
    success_chain_signature = await mageflow.asign(
        chain_callback, error_callbacks=[chain_success_error_callback]
    )

    # Act
    chain_signature = await mageflow.achain(
        [sign_task1, signature2.key, task3],
        success=success_chain_signature,
        test_ctx=additional_text_ctx,
    )
    chain_tasks = await TaskSignature.afind()

    await chain_signature.aio_run_no_wait(message, options=trigger_options)

    # Assert
    await asyncio.sleep(10)
    runs = await get_runs(hatchet, ctx_metadata)

    assert_chain_done(
        runs,
        chain_signature,
        chain_tasks + [success_chain_signature],
        test_ctx=additional_text_ctx,
    )

    # Check redis is clean
    await assert_redis_is_clean(redis_client)


@pytest.mark.asyncio(loop_scope="session")
async def test_chain_fail(
    hatchet_client_init: HatchetInitData,
    test_ctx,
    ctx_metadata,
    trigger_options,
    sign_task1,
):
    # Arrange
    redis_client, hatchet = (
        hatchet_client_init.redis_client,
        hatchet_client_init.hatchet,
    )
    message = ContextMessage(base_data=test_ctx)
    base_data = {"fail": True}

    chain_success_error_callback = await mageflow.asign(
        error_callback, base_data=base_data
    )
    success_chain_signature = await mageflow.asign(chain_callback)
    fail_sign = await mageflow.asign(fail_task, base_data=base_data)

    # Act
    chain_signature = await mageflow.achain(
        [sign_task1, fail_sign, task3],
        success=success_chain_signature,
        error=chain_success_error_callback,
    )

    await chain_signature.aio_run_no_wait(message, options=trigger_options)

    # Assert
    await asyncio.sleep(10)
    runs = await get_runs(hatchet, ctx_metadata)
    runs_task_ids = [wf.task_id for wf in runs]

    # Check task was not called
    assert task3.id not in runs_task_ids

    # Check that callback was called
    assert_signature_done(runs, chain_success_error_callback, base_data=base_data)
    assert_signature_failed(runs, fail_sign)

    # Check redis is clean
    await assert_redis_is_clean(redis_client)
