# StressZero Python SDK

Official Python SDK for [StressZero Intelligence API](https://stresszeroentrepreneur.fr/intelligence-api) — Burnout risk scoring for entrepreneurs.

## Installation

```bash
pip install stresszero
```

## Quick Start

```python
from stresszero import StressZero, ResponseItem, AnalysisContext

sz = StressZero("sz_live_your_key_here")

# Quick 3-score check
result = sz.quick_check(physical=65, emotional=70, effectiveness=55)
if result.ok:
    print(f"Score: {result.data['score']['total']}/100")
    print(f"Risk: {result.data['risk']['level']}")

# Full analysis
result = sz.analyze_burnout(
    responses=[
        ResponseItem("physical", "sleep_quality", 65, weight=3),
        ResponseItem("emotional", "motivation", 70, weight=2),
        ResponseItem("effectiveness", "productivity", 55, weight=2),
    ],
    context=AnalysisContext(profession="entrepreneur", hours_per_week=55),
)

# Predictive scoring (J+30)
from stresszero.types import PredictiveContext

result = sz.analyze_burnout_with_prediction(
    responses=[
        ResponseItem("physical", "sleep", 65, weight=3),
        ResponseItem("emotional", "stress", 70, weight=2),
        ResponseItem("effectiveness", "focus", 55, weight=2),
    ],
    predictive_context=PredictiveContext(
        sleep_hours=6,
        exercise_days_per_week=1,
        has_support_network=False,
    ),
)
if result.ok:
    pred = result.data["prediction"]
    print(f"Score J+30: {pred['prediction']['score_j30']}")
    print(f"Trajectory: {pred['prediction']['trajectory']}")
```

## Sandbox Testing

Use `sz_test_` prefixed keys for sandbox mode (no DB, no quota):

```python
sz = StressZero("sz_test_free")  # Free tier sandbox
sz = StressZero("sz_test_pro")   # Pro tier sandbox
```

## API Reference

| Method | Tier | Description |
|--------|------|-------------|
| `analyze_burnout()` | Free+ | Individual burnout scoring |
| `analyze_burnout_with_prediction()` | Free+ | Scoring + J+30 prediction |
| `analyze_team()` | Starter+ | Team analysis |
| `generate_report()` | Starter+ | Detailed report |
| `quick_check()` | Free+ | Quick 3-score check |
| `health()` | Public | API health status |

## License

MIT — [StressZero Entrepreneur](https://stresszeroentrepreneur.fr)
