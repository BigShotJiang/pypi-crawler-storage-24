"""StressZero API client."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Optional

import httpx

from .types import (
    AnalysisContext,
    AnalysisOptions,
    ApiResponse,
    HealthResult,
    Language,
    PredictiveContext,
    PreviousScore,
    ResponseItem,
)


class StressZero:
    """Official Python client for StressZero Intelligence API.

    Example::

        from stresszero import StressZero, ResponseItem

        sz = StressZero("sz_live_your_key_here")

        result = sz.analyze_burnout(
            responses=[
                ResponseItem("physical", "sleep", 65, weight=3),
                ResponseItem("emotional", "motivation", 70, weight=2),
                ResponseItem("effectiveness", "productivity", 55, weight=2),
            ],
            context=AnalysisContext(profession="entrepreneur", hours_per_week=55),
        )

        if result.ok:
            print(result.data["score"]["total"])
            print(result.data["risk"]["level"])

    Docs: https://stresszeroentrepreneur.fr/intelligence-api
    """

    BASE_URL = "https://stresszeroentrepreneur.fr"
    VERSION = "1.0.0"

    def __init__(
        self,
        api_key: str,
        *,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        if not api_key or not (api_key.startswith("sz_live_") or api_key.startswith("sz_test_")):
            raise ValueError(
                "Invalid API key. Must start with 'sz_live_' or 'sz_test_'. "
                "Get your free key at: https://stresszeroentrepreneur.fr/intelligence-api"
            )

        self._api_key = api_key
        self._base_url = (base_url or self.BASE_URL).rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"stresszero-python/{self.VERSION}",
            },
        )

    def _request(self, method: str, path: str, json: Optional[Dict[str, Any]] = None) -> ApiResponse:
        try:
            resp = self._client.request(method, path, json=json)
            data = resp.json()
            return ApiResponse(
                success=data.get("success", False),
                data=data.get("data"),
                error=data.get("error"),
                meta=data.get("meta"),
            )
        except httpx.TimeoutException:
            return ApiResponse(success=False, error={"message": "Request timed out"})
        except Exception as e:
            return ApiResponse(success=False, error={"message": str(e)})

    def analyze_burnout(
        self,
        responses: List[ResponseItem],
        *,
        context: Optional[AnalysisContext] = None,
        options: Optional[AnalysisOptions] = None,
    ) -> ApiResponse:
        """Score burnout risk across 3 dimensions (physical, emotional, effectiveness).

        Args:
            responses: List of ResponseItem (min 3, max 20).
            context: Professional context (profession, hours, experience).
            options: Output options (language, recommendations, dimensions).

        Returns:
            ApiResponse with score, risk, recommendations, suggested product.
        """
        payload: Dict[str, Any] = {
            "responses": [asdict(r) for r in responses],
        }
        if context:
            payload["context"] = {k: v for k, v in asdict(context).items() if v is not None}
        if options:
            payload["options"] = {k: v for k, v in asdict(options).items() if v is not None}

        return self._request("POST", "/api/v1/analyze-burnout", json=payload)

    def analyze_burnout_with_prediction(
        self,
        responses: List[ResponseItem],
        *,
        context: Optional[AnalysisContext] = None,
        predictive_context: Optional[PredictiveContext] = None,
        previous_scores: Optional[List[PreviousScore]] = None,
        language: Language = "fr",
    ) -> ApiResponse:
        """Analyze burnout with J+30 predictive trajectory.

        Args:
            responses: List of ResponseItem.
            context: Professional context.
            predictive_context: Lifestyle factors for prediction.
            previous_scores: Historical scores for trend detection.
            language: Response language ('fr' or 'en').

        Returns:
            ApiResponse with score, risk, recommendations + prediction.
        """
        payload: Dict[str, Any] = {
            "responses": [asdict(r) for r in responses],
            "options": {"include_prediction": True, "language": language},
        }
        if context:
            payload["context"] = {k: v for k, v in asdict(context).items() if v is not None}
        if predictive_context:
            payload["predictive_context"] = {k: v for k, v in asdict(predictive_context).items() if v is not None}
        if previous_scores:
            payload["previous_scores"] = [asdict(s) for s in previous_scores]

        return self._request("POST", "/api/v1/analyze-burnout", json=payload)

    def analyze_team(
        self,
        members: List[Dict[str, Any]],
        *,
        team_name: Optional[str] = None,
        anonymize: bool = True,
        language: Language = "fr",
    ) -> ApiResponse:
        """Analyze burnout risk across a team. Requires Starter+ tier.

        Args:
            members: List of team member data (responses + context).
            team_name: Optional team name.
            anonymize: Anonymize member IDs in response.
            language: Response language.

        Returns:
            ApiResponse with team stats, distribution, alerts, recommendations.
        """
        payload: Dict[str, Any] = {
            "members": members,
            "options": {"anonymize": anonymize, "language": language},
        }
        if team_name:
            payload["team_name"] = team_name

        return self._request("POST", "/api/v1/analyze-team", json=payload)

    def generate_report(
        self,
        responses: List[ResponseItem],
        *,
        context: Optional[Dict[str, Any]] = None,
        language: Language = "fr",
        format: str = "json",
    ) -> ApiResponse:
        """Generate a detailed burnout report. Requires Starter+ tier.

        Args:
            responses: List of ResponseItem.
            context: Report context (profession, company, employee name).
            language: Report language.
            format: Output format ('json' or 'html').

        Returns:
            ApiResponse with full report (summary, dimensions, action plan, resources).
        """
        payload: Dict[str, Any] = {
            "responses": [asdict(r) for r in responses],
            "language": language,
            "format": format,
        }
        if context:
            payload["context"] = context

        return self._request("POST", "/api/v1/generate-report", json=payload)

    def quick_check(
        self,
        physical: int,
        emotional: int,
        effectiveness: int,
        *,
        profession: Optional[str] = None,
        hours_per_week: Optional[int] = None,
    ) -> ApiResponse:
        """Quick 3-score burnout check.

        Args:
            physical: Physical exhaustion score (0-100).
            emotional: Emotional depletion score (0-100).
            effectiveness: Reduced effectiveness score (0-100).

        Returns:
            ApiResponse with score, risk level, recommendations.
        """
        responses = [
            ResponseItem("physical", "overall", physical, weight=2),
            ResponseItem("emotional", "overall", emotional, weight=2),
            ResponseItem("effectiveness", "overall", effectiveness, weight=2),
        ]
        context = AnalysisContext(profession=profession, hours_per_week=hours_per_week)
        return self.analyze_burnout(responses, context=context)

    def health(self) -> HealthResult:
        """Check API health status (no auth required).

        Returns:
            HealthResult with status, version, checks.
        """
        resp = httpx.get(f"{self._base_url}/api/v1/health", timeout=10)
        data = resp.json()
        return HealthResult(
            status=data.get("status", "unknown"),
            version=data.get("version", ""),
            timestamp=data.get("timestamp", ""),
            latency_ms=data.get("latency_ms", 0),
            checks=data.get("checks", {}),
        )

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
