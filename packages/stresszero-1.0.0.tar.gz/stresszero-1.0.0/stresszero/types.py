"""Type definitions for StressZero SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Union


Dimension = Literal["physical", "emotional", "effectiveness"]
RiskLevel = Literal["low", "moderate", "high", "critical"]
Language = Literal["fr", "en"]
Trajectory = Literal["improving", "stable", "worsening", "critical_acceleration"]


@dataclass
class ResponseItem:
    dimension: Dimension
    question_id: str
    value: int
    weight: int = 1


@dataclass
class AnalysisContext:
    profession: Optional[str] = None
    hours_per_week: Optional[int] = None
    team_size: Optional[int] = None
    years_experience: Optional[int] = None


@dataclass
class AnalysisOptions:
    include_recommendations: bool = True
    include_dimensions: bool = True
    include_prediction: bool = False
    language: Language = "fr"


@dataclass
class PredictiveContext:
    has_support_network: Optional[bool] = None
    has_morning_routine: Optional[bool] = None
    exercise_days_per_week: Optional[int] = None
    sleep_hours: Optional[float] = None


@dataclass
class PreviousScore:
    physical: int
    emotional: int
    effectiveness: int
    measured_at: str


@dataclass
class DimensionScore:
    physical: int
    emotional: int
    effectiveness: int


@dataclass
class RiskAssessment:
    level: RiskLevel
    factors: List[str]
    urgency: int


@dataclass
class SuggestedProduct:
    id: str
    url: str


@dataclass
class PredictiveResult:
    prediction: Dict[str, Any]
    risk_factors: List[Dict[str, Any]]
    intervention_urgency: Dict[str, Any]


@dataclass
class AnalysisResult:
    score: Dict[str, Any]
    risk: Dict[str, Any]
    recommendations: Optional[List[str]] = None
    suggested_product: Optional[Dict[str, str]] = None
    disclaimer: Optional[str] = None
    prediction: Optional[PredictiveResult] = None


@dataclass
class ReportResult:
    report: Dict[str, Any]
    summary: Dict[str, Any]
    dimensions: Dict[str, Any]
    action_plan: Dict[str, Any]
    context_factors: Optional[Dict[str, Any]] = None
    resources: Optional[Dict[str, Any]] = None


@dataclass
class TeamMember:
    member_id: str
    score: int
    risk_level: RiskLevel
    dimensions: DimensionScore


@dataclass
class TeamAnalysisResult:
    team: Dict[str, Any]
    distribution: Optional[Dict[str, int]] = None
    department_breakdown: Optional[Dict[str, Any]] = None
    alerts: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    members: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class HealthResult:
    status: str
    version: str
    timestamp: str
    latency_ms: float
    checks: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ApiMeta:
    api_version: str
    latency_ms: float
    quota: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ApiResponse:
    success: bool
    data: Optional[Any] = None
    error: Optional[Dict[str, Any]] = None
    meta: Optional[ApiMeta] = None

    @property
    def ok(self) -> bool:
        return self.success

    def raise_for_error(self) -> None:
        if not self.success and self.error:
            raise StressZeroError(self.error.get("message", "Unknown error"), self.error.get("status"))


class StressZeroError(Exception):
    def __init__(self, message: str, status: Optional[int] = None):
        self.message = message
        self.status = status
        super().__init__(f"[{status}] {message}" if status else message)
