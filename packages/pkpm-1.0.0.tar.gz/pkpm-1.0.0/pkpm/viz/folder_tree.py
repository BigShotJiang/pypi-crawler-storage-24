import os
from pathlib import Path
from rich.tree import Tree
from rich.console import Console
from rich.text import Text

def get_size_str(path: Path) -> str:
    try:
        size = path.stat().st_size
    except Exception:
        size = 0
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024:
            return f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}TB"

def build_tree(dir_path: Path, tree: Tree, depth: int, ignore: set):
    """Recursively build rich tree for folder structure."""
    if depth == 0:
        return
    try:
        paths = sorted(list(dir_path.iterdir()), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return
        
    for p in paths:
        if any(ignored in p.parts for ignored in ignore):
            continue
        if p.name.startswith(".") and p.name not in (".gitignore", ".pkpmignore", ".env"):
            continue
            
        if p.is_dir():
            branch = tree.add(f"[bold cyan]ðŸ“ {p.name}[/bold cyan]")
            build_tree(p, branch, depth - 1, ignore)
        else:
            icon = "ðŸ" if p.suffix == ".py" else "ðŸ“„"
            size = get_size_str(p)
            tree.add(Text(f"{icon} {p.name} ({size})", style="green" if p.suffix == ".py" else "white"))

def print_folder_tree(project_root: Path, max_depth: int = 0):
    console = Console()
    ignore = {".pkpm", "venv", "__pycache__", ".git", "node_modules", ".pytest_cache"}
    
    tree = Tree(f"[bold blue]ðŸ“ {project_root.name}[/bold blue]")
    build_tree(project_root, tree, depth=max_depth if max_depth > 0 else float('inf'), ignore=ignore)
    console.print(tree)

