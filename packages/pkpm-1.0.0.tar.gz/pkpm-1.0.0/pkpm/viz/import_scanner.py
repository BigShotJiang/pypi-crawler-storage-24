import ast
from pathlib import Path
from typing import Dict, Set

def scan_project_imports(project_root: Path) -> Dict[str, Set[str]]:
    """Returns a dict mapping file path (relative to root) to a set of imported modules/files."""
    graph = {}
    
    for py_file in project_root.rglob("*.py"):
        if ".pkpm" in py_file.parts or "venv" in py_file.parts or ".git" in py_file.parts:
            continue
            
        rel_path = str(py_file.relative_to(project_root))
        imports = set()
        try:
            with open(py_file, "r", encoding="utf-8") as f:
                tree = ast.parse(f.read(), filename=str(py_file))
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            imports.add(alias.name)
                    elif isinstance(node, ast.ImportFrom) and node.module:
                        imports.add(node.module)
        except Exception:
            pass
            
        graph[rel_path] = imports
        
    return graph

