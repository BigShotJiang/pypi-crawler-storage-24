import networkx as nx
from typing import Dict, Set

def build_import_graph(imports_map: Dict[str, Set[str]]) -> nx.DiGraph:
    G = nx.DiGraph()
    
    # Nodes
    for src in imports_map:
        G.add_node(src, type="internal")
        
    # Edges
    for src, external_modules in imports_map.items():
        for mod in external_modules:
            # Simple heuristic: if module name aligns with an internal file path part
            # e.g. "src.models.user" might map to "src/models/user.py"
            # Since this is a rough approximation, we just add the node
            possible_path = mod.replace(".", "/") + ".py"
            if possible_path in imports_map:
                target = possible_path
                G.add_edge(src, target)
            else:
                G.add_node(mod, type="external")
                G.add_edge(src, mod)
                
    return G

def find_cycles(G: nx.DiGraph) -> list:
    """Finds simple cycles in the directed graph."""
    try:
        return list(nx.simple_cycles(G))
    except Exception:
        return []
