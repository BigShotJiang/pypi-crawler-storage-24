import networkx as nx
from pathlib import Path
from pyvis.network import Network

def render_html_graph(G: nx.DiGraph, output_path: Path):
    """Render to an interactive HTML using pyvis."""
    net = Network(height="750px", width="100%", bgcolor="#222222", font_color="white", directed=True)
    
    for node, data in G.nodes(data=True):
        node_type = data.get("type", "external")
        color = "#1f78b4" if node_type == "internal" else "#ff7f00"
        
        in_deg = G.in_degree(node)
        out_deg = G.out_degree(node)
        title = f"{node}<br>Imports: {out_deg}<br>Imported By: {in_deg}"
        
        net.add_node(node, label=node.split("/")[-1], title=title, color=color)
        
    for u, v in G.edges():
        net.add_edge(u, v)
        
    # Generate the self-contained HTML
    # Note: to be strictly self-contained without CDN, pyvis requires local assets
    # In practice `notebook=True` and `cdn_resources="in_line"` attempts this roughly.
    net.set_options("""
    var options = {
      "physics": {
        "forceAtlas2Based": {
          "gravitationalConstant": -50,
          "centralGravity": 0.01,
          "springLength": 100,
          "springConstant": 0.08
        },
        "minVelocity": 0.75,
        "solver": "forceAtlas2Based"
      }
    }
    """)
    net.save_graph(str(output_path))
