import httpx
import time
from typing import List

MIRRORS = [
    "https://pypi.org/simple",
    "https://pypi.python.org/simple",
    "https://files.pythonhosted.org",
]

def find_fastest_mirror() -> str:
    """Pings the top PyPI mirrors and picks the lowest-latency one."""
    best_mirror = MIRRORS[0]
    best_time = float("inf")
    
    with httpx.Client(timeout=2.0) as client:
        for mirror in MIRRORS:
            try:
                start = time.time()
                r = client.head(mirror)
                if r.status_code < 400:
                    latency = time.time() - start
                    if latency < best_time:
                        best_time = latency
                        best_mirror = mirror
            except httpx.RequestError:
                continue
                
    return best_mirror
