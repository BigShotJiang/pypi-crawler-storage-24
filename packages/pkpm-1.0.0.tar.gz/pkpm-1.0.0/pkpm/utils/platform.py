import subprocess
import platform
import sys
from pathlib import Path

def get_python_version(python_bin: Path) -> str:
    """Returns the python version of the given binary, e.g. 3.10.4"""
    try:
        res = subprocess.run([str(python_bin), "-c", "import sys; print('.'.join(map(str, sys.version_info[:3])))"],
                             capture_output=True, text=True, check=True)
        return res.stdout.strip()
    except Exception:
        return platform.python_version()

def get_platform_tag(python_bin: Path) -> str:
    """Returns the sysconfig platform tag."""
    try:
        script = "import sysconfig; print(sysconfig.get_platform())"
        res = subprocess.run([str(python_bin), "-c", script], capture_output=True, text=True, check=True)
        return res.stdout.strip()
    except Exception:
        return platform.system().lower()

def get_abi_tag(python_bin: Path) -> str:
    """Returns ABI tag (e.g. cp310)"""
    try:
        script = "import sys; print(f'cp{sys.version_info.major}{sys.version_info.minor}')"
        res = subprocess.run([str(python_bin), "-c", script], capture_output=True, text=True, check=True)
        return res.stdout.strip()
    except Exception:
        return f"cp{sys.version_info.major}{sys.version_info.minor}"
