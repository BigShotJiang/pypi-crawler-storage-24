"""
Adapters package
"""
