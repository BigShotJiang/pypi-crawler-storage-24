import subprocess
import json
from typing import List
from pathlib import Path
from pkpm.adapters.base import BaseAdapter
from pkpm.env.manager import get_python_binary, get_or_create_venv

class PipAdapter(BaseAdapter):
    def __init__(self, project_root: Path):
        super().__init__(project_root)
        self.venv_path = get_or_create_venv(self.project_root)
        self.python_bin = str(get_python_binary(self.venv_path))

    def _run_pip(self, args: List[str]) -> subprocess.CompletedProcess:
        cmd = [self.python_bin, "-m", "pip"] + args
        return subprocess.run(cmd, capture_output=True, text=True)

    def install(self, packages: List[str], console=None) -> bool:
        """
        Uses pip to install packages. Assumes cache logic might have already fetched 
        or pip will use its own cache. We rely on pip install --report for resolution
        in pkpm.core.installer.
        """
        if not packages:
            return True

        if console:
            from rich.progress import Progress, SpinnerColumn, TextColumn
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
                transient=True,
            ) as progress:
                task = progress.add_task(f"Installing {', '.join(packages)}...", total=None)
                res = self._run_pip(["install"] + packages)
                progress.update(task, completed=1)
        else:
            res = self._run_pip(["install"] + packages)
            
        return res.returncode == 0

    def remove(self, packages: List[str]) -> bool:
        if not packages:
            return True
        res = self._run_pip(["uninstall", "-y"] + packages)
        return res.returncode == 0

    def list_installed(self) -> List[str]:
        res = self._run_pip(["list", "--format=json"])
        if res.returncode == 0:
            data = json.loads(res.stdout)
            return [f"{pkg['name']}=={pkg['version']}" for pkg in data]
        return []

    def lock(self) -> bool:
        # In a real tool we'd parse `pip freeze` or use pip report
        res = self._run_pip(["freeze"])
        if res.returncode == 0:
            with open(self.project_root / "requirements.txt", "w", encoding="utf-8") as f:
                f.write(res.stdout)
            return True
        return False

