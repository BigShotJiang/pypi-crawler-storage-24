from abc import ABC, abstractmethod
from typing import List
from pathlib import Path

class BaseAdapter(ABC):
    def __init__(self, project_root: Path):
        self.project_root = project_root

    @abstractmethod
    def install(self, packages: List[str]) -> bool:
        pass

    @abstractmethod
    def remove(self, packages: List[str]) -> bool:
        pass

    @abstractmethod
    def list_installed(self) -> List[str]:
        pass

    @abstractmethod
    def lock(self) -> bool:
        pass
