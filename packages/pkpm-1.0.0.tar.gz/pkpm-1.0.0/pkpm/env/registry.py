import json
from pathlib import Path

class GlobalRegistry:
    def __init__(self):
        self.registry_path = Path.home() / ".pkpm" / "registry.json"
        
    def load(self) -> dict:
        if self.registry_path.exists():
            with open(self.registry_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"packages": {}}

    def save(self, data: dict):
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.registry_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def register_project(self, project_path: Path, packages: dict):
        """packages: dict mapping {pkg_name: version}"""
        data = self.load()
        proj_str = str(project_path.resolve())
        
        # We need a robust reverse mapping but for now we append
        for pkg, ver in packages.items():
            pkg_db = data["packages"].setdefault(pkg, {})
            ver_db = pkg_db.setdefault(ver, [])
            if proj_str not in ver_db:
                ver_db.append(proj_str)
                
        self.save(data)
        
    def doctor(self):
        data = self.load()
        conflicts = 0
        from rich.console import Console
        console = Console()
        
        for pkg, versions_map in data["packages"].items():
            if len(versions_map) > 1:
                conflicts += 1
                console.print(f"ðŸ”´ Conflict Risk: [bold red]{pkg}[/bold red]")
                for ver, projects in versions_map.items():
                    console.print(f"  {ver} â†’ " + ", ".join(projects))
            else:
                for ver, projects in versions_map.items():
                    if len(projects) > 1:
                        console.print(f"ðŸ“¦ [bold cyan]{pkg}[/bold cyan]")
                        console.print(f"  {ver} â†’ used by: " + ", ".join(projects) + " âœ… (same version, safe)")

        if conflicts == 0:
            console.print("âœ… No conflicts detected across registered projects.")

