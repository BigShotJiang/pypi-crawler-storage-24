import venv
import hashlib
from pathlib import Path

def get_or_create_venv(project_root: Path) -> Path:
    """Gets or creates an isolated virtual environment for the project."""
    project_hash = hashlib.sha256(str(project_root.resolve()).encode()).hexdigest()[:12]
    local_venv = project_root / ".pkpm" / "venv"
    global_venv = Path.home() / ".pkpm" / "envs" / project_hash

    if local_venv.exists():
        return local_venv
    if global_venv.exists():
        return global_venv
    
    # Try local first, fall back to global
    try:
        venv.create(local_venv, with_pip=True, clear=False)
        return local_venv
    except PermissionError:
        global_venv.parent.mkdir(parents=True, exist_ok=True)
        venv.create(global_venv, with_pip=True, clear=False)
        return global_venv

def init_shell_hooks(shell: str = "bash"):
    """Initialize shell hooks for auto-activation."""
    # This will append the hook to the user's shell profile later on.
    pass

def get_python_binary(venv_path: Path) -> Path:
    import os
    if os.name == 'nt':
        return venv_path / "Scripts" / "python.exe"
    return venv_path / "bin" / "python"

