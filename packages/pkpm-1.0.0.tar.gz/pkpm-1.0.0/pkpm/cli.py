from __future__ import annotations

import typer
from rich.console import Console
from pkpm import __version__

app = typer.Typer(
    name="pkpm",
    help="pkpm - The Python Package Manager",
    no_args_is_help=True,
    add_completion=False,
)

console = Console()

def version_callback(value: bool):
    if value:
        console.print(f"pkpm version {__version__}")
        raise typer.Exit()

@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    )
):
    """
    pkpm - A Python-based CLI package manager.
    """
    pass

@app.command()
def init():
    """Initialize a new project (generates pkpm.json)"""
    from pathlib import Path
    from pkpm.core.manifest import generate_manifest, generate_ignore_files
    from pkpm.env.manager import get_or_create_venv

    cwd = Path.cwd()
    console.print(f"Initializing pkpm project in [bold cyan]{cwd}[/bold cyan]")
    
    # 1. Generate Manifest
    manifest = generate_manifest(cwd)
    console.print("âœ… Created/verified [bold green]pkpm.json[/bold green]")
    
    # 2. Get or create venv
    console.print("ðŸ“¦ Setting up isolated virtual environment...")
    venv_path = get_or_create_venv(cwd)
    
    # Update manifest with venv info
    from pkpm.core.manifest import update_manifest
    import hashlib
    manifest["pkpm"]["venv"] = str(venv_path.relative_to(cwd)) if cwd in venv_path.parents else str(venv_path)
    manifest["pkpm"]["venvHash"] = hashlib.sha256(str(cwd.resolve()).encode()).hexdigest()[:12]
    update_manifest(cwd, manifest)
    console.print(f"âœ… Virtual environment ready at [bold green]{venv_path}[/bold green]")
    
    # 3. .gitignore and .pkpmignore
    generate_ignore_files(cwd)
    console.print("âœ… Generated ignore files (.gitignore, .pkpmignore)")
    
    console.print("\nâœ¨ Initialization complete! Run `pkpm install <pkg>` to add dependencies.")

@app.command()
def install(
    packages: list[str] = typer.Argument(None, help="Packages to install. If empty, installs from pkpm.json"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would happen without modifying the system")
):
    """Install a package or all packages from pkpm.json"""
    from pathlib import Path
    from pkpm.core.installer import Installer
    from pkpm.core.manifest import read_manifest

    cwd = Path.cwd()
    installer = Installer(cwd)

    if not packages:
        manifest = read_manifest(cwd)
        packages = list(manifest.get("dependencies", {}).keys())
        console.print("Installing from pkpm.json...")
    
    if dry_run:
        console.print(f"[yellow]Dry run executed. Would install: {packages}. No changes made.[/yellow]")
        return
        
    console.print(f"Installing [bold cyan]{', '.join(packages)}[/bold cyan]...")
    if installer.install(packages, console):
        console.print("[bold green]Installation complete![/bold green]")
    else:
        console.print("[bold red]Installation failed![/bold red]")

@app.command()
def remove(
    packages: list[str] = typer.Argument(..., help="Packages to remove"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would happen without modifying the system")
):
    """Uninstall a package"""
    from pathlib import Path
    from pkpm.core.installer import Installer

    cwd = Path.cwd()
    installer = Installer(cwd)
    
    if dry_run:
        console.print(f"[yellow]Dry run executed. Would remove {packages}. No changes made.[/yellow]")
        return
        
    console.print(f"Removing [bold cyan]{', '.join(packages)}[/bold cyan]...")
    if installer.remove(packages):
        console.print("[bold green]Removal complete![/bold green]")
    else:
        console.print("[bold red]Removal failed![/bold red]")


@app.command()
def update(
    packages: list[str] = typer.Argument(None, help="Packages to update. If empty, updates all."),
):
    """Update a package"""
    console.print(f"Updating {packages or 'all'}...")

@app.command()
def run(script: str = typer.Argument(..., help="Run a script defined in pkpm.json")):
    """Run a script defined in pkpm.json"""
    console.print(f"Running script {script}...")

@app.command()
def tree(depth: int = typer.Option(0, help="Max depth of the tree (0 for infinite)")):
    """Show dependency tree"""
    console.print("Showing dependency tree...")

@app.command()
def viz(
    mode: str = typer.Option("folder", help="Visualization mode: 'folder' or 'imports'"),
    depth: int = typer.Option(0, help="Max depth of the visualization (0 for infinite)")
):
    """Open visual dependency graph in browser or print folder tree"""
    from pathlib import Path
    cwd = Path.cwd()
    
    if mode == "folder":
        from pkpm.viz.folder_tree import print_folder_tree
        print_folder_tree(cwd, max_depth=depth)
    elif mode == "imports":
        from pkpm.viz.import_scanner import scan_project_imports
        from pkpm.viz.graph_builder import build_import_graph, find_cycles
        from pkpm.viz.html_renderer import render_html_graph
        import webbrowser
        
        console.print("Scanning imports...")
        imports_map = scan_project_imports(cwd)
        G = build_import_graph(imports_map)
        
        cycles = find_cycles(G)
        if cycles:
            console.print(f"[bold red]âš  Circular import detected: {cycles[0]}[/bold red]")
            
        output_path = cwd / "dependency_graph.html"
        render_html_graph(G, output_path)
        console.print(f"âœ… Generated graph at {output_path}")
        webbrowser.open(output_path.as_uri())
    else:
        console.print(f"[red]Unknown viz mode '{mode}'[/red]")

@app.command()
def scan():
    """Scan project and show file-level import graph"""
    from pathlib import Path
    from pkpm.viz.import_scanner import scan_project_imports
    
    cwd = Path.cwd()
    imports_map = scan_project_imports(cwd)
    
    console.print(f"[bold cyan]Import Scan for {cwd.name}[/bold cyan]")
    for src, targets in sorted(imports_map.items()):
        if not targets:
            continue
        console.print(f"[bold white]{src}[/bold white]")
        for t in sorted(targets):
            console.print(f"  â””â”€â”€ imports: [green]{t}[/green]")


shell_app = typer.Typer(help="Shell environment integration commands")
app.add_typer(shell_app, name="shell")

@shell_app.command("init")
def shell_init(shell: str = typer.Option("bash", help="Target shell (bash, zsh, fish)")):
    """Initialize shell hooks for auto-activation."""
    console.print(f"Initializing shell hooks for {shell}...")
    console.print("""
# Add to ~/.bashrc or ~/.zshrc via: pkpm shell init
pkpm_cd() {
  builtin cd "$@" || return
  if [ -f ".pkpm/venv/bin/activate" ]; then
    source .pkpm/venv/bin/activate
    echo "ðŸ pkpm env activated: $(python --version)"
  fi
}
alias cd=pkpm_cd
""")

@shell_app.command("status")
def shell_status():
    """Shows which venv is currently active."""
    import os
    venv = os.environ.get("VIRTUAL_ENV")
    if venv:
        console.print(f"âœ… Active pkpm env: [bold cyan]{venv}[/bold cyan]")
    else:
        console.print("âŒ No active pkpm env.")

@app.command()
def doctor(global_check: bool = typer.Option(False, "--global", help="Check global registry for conflicts")):
    """Detect conflicts with existing package managers or across projects"""
    if global_check:
        console.print("Scanning global pkpm registry for conflicts...")
        from pkpm.env.registry import GlobalRegistry
        registry = GlobalRegistry()
        registry.doctor()
    else:
        console.print("Scanning local project for setup conflicts...")

env_app = typer.Typer(help="Automatic .env File Generation & Management")
app.add_typer(env_app, name="env")

@env_app.command("generate")
def env_generate(
    environment: str = typer.Option("development", "--env", help="Environment target"),
    all_envs: bool = typer.Option(False, "--all", help="Generate all variants")
):
    """Auto-generate .env from project scan."""
    from pkpm.env.generator import EnvGenerator
    from pathlib import Path
    
    cwd = Path.cwd()
    generator = EnvGenerator(cwd)
    
    envs_to_gen = ["development", "production", "test"] if all_envs else [environment]
    for env in envs_to_gen:
        console.print(f"Scanning project for {env} environment...")
        path = generator.generate(env)
        console.print(f"âœ… Generated [bold green]{path.name}[/bold green]")

@env_app.command("check")
def env_check():
    """Validate current .env against codebase."""
    console.print("Validating current .env against codebase (not fully implemented yet)")

@env_app.command("export")
def env_export(format: str = typer.Option("shell", help="Export format: docker, shell, json")):
    """Export .env as Docker, Shell, or JSON format."""
    console.print(f"Exporting .env in {format} format (not fully implemented yet)")

if __name__ == "__main__":
    app()


