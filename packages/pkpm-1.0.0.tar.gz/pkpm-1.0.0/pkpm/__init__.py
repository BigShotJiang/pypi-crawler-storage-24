"""
pkpm - A Python package manager CLI tool
"""

__version__ = "1.0.0"

