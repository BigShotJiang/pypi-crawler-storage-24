import json
from pathlib import Path

DEFAULT_MANIFEST = {
    "name": "my-project",
    "version": "1.0.0",
    "description": "",
    "python": ">=3.10",
    "dependencies": {},
    "devDependencies": {},
    "scripts": {
        "start": "python main.py",
        "test": "pytest"
    },
    "pkpm": {
        "cache": True,
        "parallelDownloads": 8,
        "preferredResolver": "auto"
    }
}

def generate_manifest(project_root: Path) -> dict:
    """Generates a default pkpm.json for the project in the given root."""
    manifest_path = project_root / "pkpm.json"
    
    if manifest_path.exists():
        with open(manifest_path, "r", encoding="utf-8") as f:
            return json.load(f)
            
    manifest = DEFAULT_MANIFEST.copy()
    manifest["name"] = project_root.name
    
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
        
    return manifest

def read_manifest(project_root: Path) -> dict:
    manifest_path = project_root / "pkpm.json"
    if manifest_path.exists():
        with open(manifest_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def update_manifest(project_root: Path, data: dict):
    manifest_path = project_root / "pkpm.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def generate_ignore_files(project_root: Path):
    """Auto-adds to .gitignore and generates .pkpmignore"""
    gitignore = project_root / ".gitignore"
    pkpmignore = project_root / ".pkpmignore"
    
    gitignore_entries = [
        ".pkpm/venv/",
        "pkpm.lock",
        "*.pyc",
        "__pycache__/",
        ".env",
        ".env.*",
        "!.env.example"
    ]
    
    pkpmignore_entries = [
        ".pkpm/",
        "__pycache__/",
        "*.egg-info/",
        "dist/",
        "build/",
        ".git/",
        "node_modules/"
    ]
    
    if not gitignore.exists():
        gitignore.write_text("\n".join(gitignore_entries) + "\n", encoding="utf-8")
    else:
        existing = gitignore.read_text(encoding="utf-8")
        needs_add = [e for e in gitignore_entries if e not in existing]
        if needs_add:
            with gitignore.open("a", encoding="utf-8") as f:
                f.write("\n" + "\n".join(needs_add) + "\n")
                
    if not pkpmignore.exists():
        pkpmignore.write_text("\n".join(pkpmignore_entries) + "\n", encoding="utf-8")

