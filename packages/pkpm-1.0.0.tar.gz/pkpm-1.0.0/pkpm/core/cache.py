import sqlite3
import hashlib
from pathlib import Path
from typing import Optional
import datetime

class CacheManager:
    def __init__(self, cache_dir: Optional[Path] = None):
        self.cache_dir = cache_dir or Path.home() / ".pkpm" / "cache"
        self.db_path = self.cache_dir / "index.db"
        self.wheels_dir = self.cache_dir / "wheels"
        self.sdist_dir = self.cache_dir / "sdist"
        self._init_db()

    def _init_db(self):
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.wheels_dir.mkdir(parents=True, exist_ok=True)
        self.sdist_dir.mkdir(parents=True, exist_ok=True)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS cache_index (
                    cache_key TEXT PRIMARY KEY,
                    package_name TEXT,
                    version TEXT,
                    file_path TEXT,
                    file_size INTEGER,
                    last_used TIMESTAMP,
                    hit_count INTEGER DEFAULT 0
                )
            ''')

    def build_cache_key(self, name: str, version: str, py_version: str, platform_tag: str, abi_tag: str) -> str:
        raw = f"{name}-{version}-py{py_version}-{platform_tag}-{abi_tag}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def lookup(self, cache_key: str) -> Optional[Path]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT file_path FROM cache_index WHERE cache_key=?", (cache_key,))
            row = cursor.fetchone()
            if row:
                path = Path(row[0])
                if path.exists():
                    return path
        return None

    def record_hit(self, cache_key: str):
        now = datetime.datetime.utcnow().isoformat()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                UPDATE cache_index
                SET hit_count = hit_count + 1, last_used = ?
                WHERE cache_key = ?
            ''', (now, cache_key))

    def store(self, cache_key: str, name: str, version: str, file_path: Path):
        now = datetime.datetime.utcnow().isoformat()
        size = file_path.stat().st_size if file_path.exists() else 0
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                INSERT OR REPLACE INTO cache_index 
                (cache_key, package_name, version, file_path, file_size, last_used, hit_count)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (cache_key, name, version, str(file_path), size, now, 0))

