import json
from pathlib import Path
from typing import List, Optional
from pkpm.adapters.pip import PipAdapter
from pkpm.core.manifest import read_manifest, update_manifest
import datetime

class Installer:
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.adapter = PipAdapter(project_root)
        self.lock_file = project_root / "pkpm.lock"

    def install(self, packages: List[str], console=None) -> bool:
        """Installs packages and updates lockfile and manifest."""
        success = self.adapter.install(packages, console)
        if success:
            manifest = read_manifest(self.project_root)
            installed_map = {}
            for item in self.adapter.list_installed():
                parts = item.split("==")
                if len(parts) == 2:
                    installed_map[parts[0].lower()] = parts[1]
                    
            # If no packages explicitly passed, we are installing from manifest.
            # So we should lock all listed dependencies to exact versions
            pkgs_to_update = packages if packages else list(manifest.get("dependencies", {}).keys())
            
            for pkg in pkgs_to_update:
                # Naive: assumes package name without version pins if not provided
                pkg_name = pkg.split("==")[0].split(">=")[0].split("<=")[0].lower()
                exact_version = installed_map.get(pkg_name, "*")
                manifest.setdefault("dependencies", {})[pkg_name] = exact_version
                
            update_manifest(self.project_root, manifest)
            self.adapter.lock()
        return success

    def remove(self, packages: List[str]) -> bool:
        """Removes packages and updates lockfile and manifest."""
        success = self.adapter.remove(packages)
        if success:
            manifest = read_manifest(self.project_root)
            for pkg in packages:
                manifest.get("dependencies", {}).pop(pkg, None)
            update_manifest(self.project_root, manifest)
            self.adapter.lock()
        return success

