import asyncio
import aiohttp
from pathlib import Path
from urllib.parse import urlparse
import time

class ParallelDownloader:
    def __init__(self, max_workers: int = 8, mirror: str = "https://pypi.org/simple"):
        self.max_workers = max_workers
        self.mirror = mirror.rstrip("/")
        self.semaphore = asyncio.Semaphore(max_workers)
        
    async def download_file(self, session: aiohttp.ClientSession, url: str, dest_path: Path):
        async with self.semaphore:
            # Atomic download: write to temp, rename
            temp_path = dest_path.with_suffix(dest_path.suffix + ".download")
            temp_path.parent.mkdir(parents=True, exist_ok=True)
            
            try:
                async with session.get(url) as response:
                    response.raise_for_status()
                    with open(temp_path, "wb") as f:
                        async for chunk in response.content.iter_chunked(8192):
                            f.write(chunk)
                temp_path.rename(dest_path)
                return dest_path
            except Exception as e:
                if temp_path.exists():
                    temp_path.unlink()
                raise e

    async def download_packages(self, packages: list[tuple[str, str, Path]]):
        """packages is a list of tuples: (url, dest_path)"""
        async with aiohttp.ClientSession() as session:
            tasks = [
                self.download_file(session, url, dest) 
                for url, dest in packages
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            return results
