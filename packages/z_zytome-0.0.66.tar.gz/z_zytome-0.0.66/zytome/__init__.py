"""zytome"""

__version__ = "0.0.66"
__author__ = "Marko Zolo Gozano Untalan"
