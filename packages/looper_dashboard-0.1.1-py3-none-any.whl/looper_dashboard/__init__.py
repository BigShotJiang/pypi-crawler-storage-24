"""looper-dashboard — daily CI dashboards for any QE repo on LooperPro."""

__version__ = "0.1.0"
