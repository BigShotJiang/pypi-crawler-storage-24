"""Monocart-specific Looper MCP operations (WPA-style monocart-report/index.html).

Builds on the shared looper_core utilities and adds:
  - Monocart CDC report URL builder with CDC name-mapping support
  - batch_status and batch_history using explicit job_ids from daily_flows.yml
    (WPA jobs are not discoverable via SCM URL in LooperPro)
"""
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

from .looper_auth import CDC_BASE, http_head_ok
from .looper_core import (
    get_build_history,
    get_job_by_name,
    list_jobs,
    resolve_scm_url,
    search_flow,
)

__all__ = [
    "build_report_url",
    "find_report",
    "batch_status",
    "batch_history",
    "resolve_scm_url",
    "list_jobs",
    "get_job_by_name",
    "get_build_history",
    "search_flow",
]

# CDC paths are lowercase for some jobs whose LooperPro names use camelCase.
_CDC_NAME_MAP: dict[str, str] = {
    "wpa-wmt-adShell": "wpa-wmt-adshell",
}


# ---------------------------------------------------------------------------
# Monocart report URL
# ---------------------------------------------------------------------------

def build_report_url(job_name: str, build_number: int) -> str:
    """Construct the CDC report URL for a monocart build."""
    cdc_job_name = _CDC_NAME_MAP.get(job_name, job_name)
    return f"{CDC_BASE}/{cdc_job_name}/{build_number}/monocart-report/index.html"


# ---------------------------------------------------------------------------
# Flow-entry helpers
# ---------------------------------------------------------------------------

def _best_flow_entry(job_name: str, build: dict) -> dict:
    report_url = build_report_url(job_name, build["buildNumber"])
    return {
        "flowName":    build.get("flowName"),
        "buildNumber": build["buildNumber"],
        "buildStatus": build.get("buildStatus"),
        "startTime":   build.get("startTime"),
        "duration":    build.get("duration"),
        "reportUrl":   report_url,
    }


def _fill_missing_flows(
    job: dict,
    job_name: str,
    missing: set[str],
    best_by_flow: dict[str, dict],
    flows: list[dict],
) -> None:
    """Backfill flows using branch=None (WPA may run on non-main branches)."""
    if not missing or not job.get("id"):
        return
    history = sorted(
        (b for b in get_build_history(job["id"], branch=None, size=50) if b.get("buildNumber") not in (None, 0)),
        key=lambda b: b["buildNumber"],
        reverse=True,
    )
    for build in history:
        bf = build.get("flowName")
        if bf not in missing:
            continue
        candidate_url = build_report_url(job_name, build["buildNumber"])
        if not http_head_ok(candidate_url):
            continue
        entry = _best_flow_entry(job_name, build)
        best_by_flow[bf] = entry
        flows[:] = [f for f in flows if f["flowName"] != bf]
        flows.append(entry)
        missing.discard(bf)
        if not missing:
            break


# ---------------------------------------------------------------------------
# find-report
# ---------------------------------------------------------------------------

def find_report(
    job_name: str | None = None,
    job_id: str | None = None,
    flow_name: str | None = None,
    scm_url: str | None = None,
    branch: str = "main",
) -> dict:
    """Find the latest monocart report URL."""
    if not job_id and job_name:
        job = get_job_by_name(job_name)
        if job:
            job_id = job["id"]
            job_name = job["name"]
        elif scm_url:
            matching = [j for j in list_jobs(scm_url) if job_name.lower() in j["name"].lower()]
            if matching:
                job_id = matching[0]["id"]
                job_name = matching[0]["name"]

    if not job_id and flow_name and scm_url:
        matches = search_flow(flow_name, scm_url=scm_url)
        if matches:
            job_id = matches[0]["jobId"]
            job_name = matches[0]["jobName"]

    if not job_id:
        return {"error": "Could not resolve job. Check --job-name or --flow, or add job_ids to daily_flows.yml."}

    builds = get_build_history(job_id, branch=branch, flow_name=flow_name, size=50)
    if not builds:
        return {"error": f"No builds found for flow '{flow_name}' in '{job_name}'"}

    latest = builds[0]
    if not job_name:
        job_name = latest.get("jobName", "unknown")

    return {
        "jobId":       job_id,
        "jobName":     job_name,
        "buildNumber": latest["buildNumber"],
        "flowName":    latest.get("flowName"),
        "buildStatus": latest.get("buildStatus"),
        "duration":    latest.get("duration"),
        "reportUrl":   build_report_url(job_name, latest["buildNumber"]),
    }


# ---------------------------------------------------------------------------
# batch-status  (supports explicit job_ids for undiscoverable jobs)
# ---------------------------------------------------------------------------

def batch_status(
    scm_url: str | None = None,
    config_path: str | None = None,
) -> dict:
    """Get the latest build status for all monitored monocart jobs."""
    import yaml

    monitored: dict[str, list[str]] | None = None
    config_scm_url: str | None = None
    job_ids_map: dict[str, str] = {}

    if config_path:
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
        monitored = cfg.get("jobs", {})
        config_scm_url = cfg.get("scm_url")
        job_ids_map = cfg.get("job_ids", {})

    effective_url = resolve_scm_url(scm_url or config_scm_url)
    all_raw_jobs = list_jobs(effective_url)

    if monitored is not None:
        monitored_names = set(monitored.keys())
        all_jobs = [j for j in all_raw_jobs if j["name"] in monitored_names]
        found_names = {j["name"] for j in all_jobs}
        for name in monitored_names - found_names:
            job_id = job_ids_map.get(name)
            if job_id:
                all_jobs.append({"id": job_id, "name": name, "looperFile": None, "latestBuilds": []})
            else:
                print(f"Warning: job '{name}' not found and no job_id configured.", file=sys.stderr)
    else:
        all_jobs = all_raw_jobs

    results = []
    for job in all_jobs:
        job_name = job["name"]
        target_flows = set(monitored[job_name]) if monitored else None

        best_by_flow: dict[str, dict] = {}
        for b in job["latestBuilds"]:
            flow = b.get("flowName")
            if target_flows and flow not in target_flows:
                continue
            bnum = b.get("buildNumber", 0)
            if flow not in best_by_flow or bnum > best_by_flow[flow]["buildNumber"]:
                best_by_flow[flow] = _best_flow_entry(job_name, {**b, "buildNumber": bnum})
        flows = list(best_by_flow.values())

        if target_flows:
            missing = target_flows - {f["flowName"] for f in flows}
            _fill_missing_flows(job, job_name, missing, best_by_flow, flows)

        if flows:
            results.append({"jobName": job_name, "jobId": job.get("id"), "flows": flows})

    return {"jobs": results, "fetchedAt": datetime.now(timezone.utc).isoformat()}


# ---------------------------------------------------------------------------
# batch-history  (uses explicit job_ids, branch=None)
# ---------------------------------------------------------------------------

def batch_history(
    config_path: str | None = None,
    scm_url: str | None = None,
    days: int = 30,
) -> dict:
    """Fetch build history for all monitored monocart jobs within a lookback window."""
    import yaml

    monitored: dict[str, list[str]] = {}
    job_ids_map: dict[str, str] = {}

    if config_path:
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
        monitored = cfg.get("jobs", {})
        job_ids_map = cfg.get("job_ids", {})

    cutoff = datetime.now(timezone.utc).timestamp() - days * 86400

    def _fetch_job_history(job_name: str, job_id: str, target_flows: list[str]) -> list[dict]:
        history = sorted(
            (b for b in get_build_history(job_id, branch=None, size=100) if b.get("buildNumber") not in (None, 0)),
            key=lambda b: b["buildNumber"],
            reverse=True,
        )
        entries = []
        for build in history:
            flow = build.get("flowName")
            if flow not in target_flows:
                continue
            start_iso = build.get("startTime")
            if start_iso:
                try:
                    ts = datetime.fromisoformat(start_iso.replace("Z", "+00:00")).timestamp()
                    if ts < cutoff:
                        continue
                except ValueError:
                    pass
            status = build.get("buildStatus", "")
            if status in ("ABORTED", "Accepted", "IN_PROGRESS"):
                continue
            url = build_report_url(job_name, build["buildNumber"])
            if not http_head_ok(url):
                continue
            entries.append({
                "jobName":     job_name,
                "flowName":    flow,
                "buildNumber": build["buildNumber"],
                "buildStatus": status,
                "startTime":   start_iso,
                "duration":    build.get("duration"),
                "reportUrl":   url,
            })
        return entries

    jobs_to_fetch: list[tuple[str, str, list[str]]] = []
    for job_name, flow_names in monitored.items():
        job_id = job_ids_map.get(job_name)
        if job_id:
            jobs_to_fetch.append((job_name, job_id, flow_names))
        else:
            print(f"Warning: no job_id for '{job_name}' in daily_flows.yml — skipping.", file=sys.stderr)

    all_builds: list[dict] = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {
            pool.submit(_fetch_job_history, jn, jid, flows): jn
            for jn, jid, flows in jobs_to_fetch
        }
        for future in as_completed(futures):
            all_builds.extend(future.result())

    all_builds.sort(key=lambda b: b.get("startTime") or "", reverse=True)
    return {"builds": all_builds, "fetchedAt": datetime.now(timezone.utc).isoformat(), "days": days}
