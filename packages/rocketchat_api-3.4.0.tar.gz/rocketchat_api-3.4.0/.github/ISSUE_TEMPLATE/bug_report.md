---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Login as user '...'
2. Use method '....'
3. Then method '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Environment (please complete the following information):**
 - OS: [e.g. Ubuntu 20.04]
 - Rocket.Chat Version: [e.g. 8.1.0]
 - Library Version: [e.g. 3.1.0]

**Additional context**
Add any other context about the problem here.
