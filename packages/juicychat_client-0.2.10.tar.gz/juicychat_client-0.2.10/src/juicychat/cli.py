import getpass
import json
import os
import re
import textwrap
from typing import Any, Callable, Dict, Optional, Sequence

from dotenv import load_dotenv

from .client import Gender, JuicyChatClient, SortName

load_dotenv()  # load environment variables from .env file


def display_message(user: str, message: str, max_width: int = 90) -> None:
    user = user.upper()
    message = re.sub(r"\s+", " ", message).strip()
    combined_message = f"{user}: {message}"
    formatted_message = "\n" + textwrap.fill(
        combined_message, width=max_width, subsequent_indent="  "
    )
    print(formatted_message)


def select_option(
    options: Sequence[Any],
    prompt: str = "Enter option number: ",
    label_func: Optional[Callable[[Any], str]] = None,
    allow_no_selection: bool = False,
) -> Any:
    print("")
    if allow_no_selection:
        print("0: No selection")

    for idx, option in enumerate(options):
        label = label_func(option) if label_func is not None else option
        print(f"{idx + 1}: {label}")

    print("")
    while True:
        try:
            selected_idx = int(input(prompt))
            if allow_no_selection and selected_idx == 0:
                return None
            if 1 <= selected_idx <= len(options):
                return options[selected_idx - 1]
            else:
                print("Invalid option. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a valid index.")


def select_conversation(client: JuicyChatClient) -> Optional[Dict[str, Any]]:
    relations = client.get_chat_relations().get("data", [])
    if not relations:
        print("No chat relation found.")
        return None

    # request user to select a chat relation
    relation = select_option(
        relations,
        prompt="Enter character number: ",
        label_func=lambda x: x["characterInfo"]["characterName"],
        allow_no_selection=True,
    )
    if not relation:
        return
    return relation


def interactive_chat(client: JuicyChatClient, relation: Dict[str, Any]):

    character_id = relation["characterId"]
    character_name = relation["characterInfo"]["characterName"]
    introduction = relation["characterInfo"]["introduction"]
    # print(f"Selected Character: {character_name} (ID: {character_id})")

    print(f"\nIntroduction: {introduction}")

    messages = client.get_chat_messages(character_id).get("data", [])
    print(json.dumps(messages, indent=4))

    for message in reversed(messages):
        user = message["sendType"]
        content = message["content"]
        display_message(user, content)

    while True:
        message = input("\nEnter message (or 'q' to quit): ")
        if message.lower() == "q":
            print("Chat terminated by user. Bye!")
            break
        response = client.send_chat_message(character_id, message)
        display_message(character_name, response)


def search_characters(client: JuicyChatClient) -> Optional[Dict[str, Any]]:
    while True:
        search_terms = input("Enter search terms: ")
        response = client.search_characters(
            search_terms,
            gender=Gender.ALL,
            sort_name=SortName.POPULAR,
            page_no=1,
            page_size=20,
        )
        # print(json.dumps(response, indent=4))
        print("Total matches: ", response.get("total", 0))
        characters = response.get("data", [])
        if not characters:
            print("No character matches the search terms. Please try again.")
            continue
        character = select_option(
            characters,
            prompt="Enter character number: ",
            label_func=lambda x: x["characterName"],
            allow_no_selection=True,
        )
        if character:
            name = character["characterName"]
            id = character["characterId"]
            print(f"Selected Character: {name} (ID: {id})")
            return character
        else:
            print("No character selected")
            return None


def create_persona(client: JuicyChatClient):
    title = input("Enter title: ")
    name = input("Enter name: ")
    description = input("Enter description: ")
    gender = input("Enter gender (male/female/non-binary): ")
    gender = gender.strip().lower()
    if gender == "male":
        gender = Gender.MALE
    elif gender == "female":
        gender = Gender.FEMALE
    elif gender == "non-binary":
        gender = Gender.NON_BINARY
    else:
        raise ValueError("Invalid gender")

    while True:
        try:
            age = int(input("Enter age: "))
            if age > 0:
                break
            else:
                print("Invalid age. Please enter a valid age.")
        except ValueError:
            print("Invalid age. Please enter a valid age.")
            continue

    client.create_persona(title, name, description, gender, age)
    print("Created persona")


def get_tasks(client: JuicyChatClient):
    tasks = client.get_tasks().get("data", {})
    print("Task List:")
    print(json.dumps(tasks, indent=4))


# def claim_task_rewards(client: JuicyChatClient):
#     redeemed_rewards = client.redeem_eligible_task_rewards().get("data", [])
#     if not redeemed_rewards:
#         print("No eligible task rewards")
#         return
#     print("Redeemed rewards:")
#     print(json.dumps(redeemed_rewards, indent=2))


def get_user_number_and_password():
    user_number = os.getenv("JUICYCHAT_USERNUMBER")
    if not user_number:
        user_number = input("Enter user number: ")

    password = os.getenv("JUICYCHAT_PASSWORD")
    if not password:
        password = getpass.getpass("Enter password: ")
    return user_number, password


def user_info(client: JuicyChatClient):
    user_info = client.get_user_info().get("data", {})
    print(json.dumps(user_info, indent=4))


def toggle_content_filter(client: JuicyChatClient):
    user_info = client.get_user_info().get("data", {})
    allow_nsfw = user_info.get("unfiltered", 0) != 1
    client.update_content_filter(allow_nsfw=allow_nsfw)
    print(f"Updated 'Allow NSFW' setting to {allow_nsfw}")


def search_users(client: JuicyChatClient):
    while True:
        search_terms = input("Enter search terms: ")
        response = client.search_users(search_terms, page_no=1, page_size=30)
        # print(json.dumps(response, indent=4))
        total = response.get("total", 0)
        print(f"Total matches: {total:,}")
        if total == 0:
            print("No users found. Please try again.")
            continue

        users = response.get("data", [])
        user = select_option(users, prompt="Enter user number: ", label_func=lambda x: x["userName"], allow_no_selection=True)
        if user:
            user_id = user["userId"]
            user_info = client.get_other_user_info(user_id).get("data", {})
            print(json.dumps(user_info, indent=4))
            return user_info
        else:
            print("No user selected")
            return None


def main() -> None:
    user_number, password = get_user_number_and_password()
    client = JuicyChatClient(
        user_number,
        password,
        key=os.getenv("JUICYCHAT_KEY"),
        iv=os.getenv("JUICYCHAT_IV"),
    )
    print(f"Welcome, {client.user_name}!")

    options = [
        "Continue Conversation",
        "Clear Conversation",
        "Delete Conversation",
        "Select Conversation",
        "Character Detail",
        "Search Characters",
        "Get Task List",
        # "Claim Task Rewards",
        "Create Persona",
        "User Info",
        "Toggle Content Filter",
        "Search Users",
        "Quit",
    ]

    relation = None
    try:
        while True:
            if relation:
                option = select_option(options)
            else:
                option = select_option(options[5:])
            print("")

            if option == "Continue Conversation":
                if not relation:
                    print("No relation selected. Please select a relation first.")
                    continue
                interactive_chat(client, relation)
            elif option == "Clear Conversation":
                if not relation:
                    print("No relation selected. Please select a relation first.")
                    continue
                client.clear_chat_history(relation["characterId"])
                name = relation["characterInfo"]["characterName"]
                print(f"Cleared conversation with {name}")
            elif option == "Delete Conversation":
                if not relation:
                    print("No relation selected. Please select a relation first.")
                    continue
                client.delete_chat_relation(relation["characterId"])
                name = relation["characterInfo"]["characterName"]
                print(f"Deleted conversation with {name}")
                relation = None
            elif option == "Select Conversation":
                relation = select_conversation(client)
                if relation:
                    name = relation["characterInfo"]["characterName"]
                    print(f"Selected conversation with {name}")
            elif option == "Character Detail":
                if not relation:
                    print("No character selected. Please select a character first.")
                    continue
                detail = client.get_character_detail(relation["characterId"]).get(
                    "data", {}
                )
                print(json.dumps(detail, indent=4))
            elif option == "Search Characters":
                relation = search_characters(client)
            elif option == "Get Task List":
                get_tasks(client)
            # elif option == "Claim Task Rewards":
            #     claim_task_rewards(client)
            elif option == "Create Persona":
                create_persona(client)
            elif option == "User Info":
                user_info(client)
            elif option == "Toggle Content Filter":
                toggle_content_filter(client)
            elif option == "Search Users":
                search_users(client)
            elif option == "Quit":
                break
            else:
                print("Invalid option; please try again.")
                continue
    except KeyboardInterrupt:
        print("Keyboard interrupt")
    finally:
        print("Quitting...")
        exit(0)


if __name__ == "__main__":
    main()
