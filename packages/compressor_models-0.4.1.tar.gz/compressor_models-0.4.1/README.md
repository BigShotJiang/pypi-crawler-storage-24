# compressor-models
Monitoring models for compressors. Get time series data and compressor curves from SPD.

# Install
Install from pypi using `pip install compressor-models`.

# Develop / testing
Clone from github and install using `uv sync`.

