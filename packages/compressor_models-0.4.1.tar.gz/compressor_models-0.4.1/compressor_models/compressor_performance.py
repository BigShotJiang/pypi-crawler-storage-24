from pathlib import Path
from typing import List, Union

from compressor_models.curve import Case, CurveFile
from tagmapper import Constant, Model, ModelTemplate
from tagmapper.connector_api import get_mappings

cmp_file = str(
    Path(__file__).resolve().parent / "schemas" / "compressor_performance.yaml"
)


class CompressorPerformance(Model):
    def __init__(self, data: dict[str, str]):
        """Initialize a CompressorPerformance object.

        Args:
            data (dict[str, str]): Input data for the model. The dictionary should contain
                the keys "name", "description", "comment", "owner", and "object_name" to set
                the corresponding attributes.

        Raises:
            ValueError: If the input data is not a dictionary or if required keys are missing.
        """
        super().__init__(data)

    def add_curves(self, curve_file: Union[str, Case, CurveFile]):
        """
        Adds curve mappings from a given curve file, Case or  CurveFile instance to the current object.
        This method processes the provided curve file, extracting design data and associated curve sets.
        For each curve set, it matches the curve type to an attribute in the current object, then adds
        mappings for both interpolated and visualization curves using the `add_mapping` method.
        Args:
            curve_file (Union[str, Case, CurveFile]): The path to a curve file (as a string) a Case instance or a CurveFile instance.
        Raises:
            ValueError: If the input is neither a CurveFile instance nor a valid file path.
        Side Effects:
            Updates the object's mappings by adding new Constant mappings for each curve found in the file.
        """
        if isinstance(curve_file, Case):
            c = CurveFile(self.object_name, curve_file)
        elif isinstance(curve_file, CurveFile):
            c = curve_file
        elif Path(curve_file).is_file():
            c = CurveFile.read_json(curve_file)
        else:
            raise ValueError(
                "Input curve_file must be a CurveFile instance or a filepath."
            )

        for ca in c.designData:
            mode = ca.description
            for cs in ca.curvesets:
                attribute_identifier = ""
                curve_num = 0
                for att in self.attributes:
                    if cs.type.lower() + " curve" in att.identifier.lower():
                        attribute_identifier = att.identifier
                        break

                for cu in cs.interp_curves:
                    if len(attribute_identifier) > 0:
                        curve_num = curve_num + 1
                        self.add_mapping(
                            attribute_identifier=attribute_identifier,
                            mapping=Constant.create(
                                value=f"{cu.curve_data}",
                                comment=f"legend:{cu.legend}",
                                unit_of_measure=f"{cu.units}",
                                mode=f"{mode}_interp_{curve_num}",
                            ),
                        )

                curve_num = 0
                for cu in cs.visualisation_curves:
                    if len(attribute_identifier) > 0:
                        curve_num = curve_num + 1
                        self.add_mapping(
                            attribute_identifier=attribute_identifier,
                            mapping=Constant.create(
                                value=f"{cu.curve_data}",
                                comment=f"legend:{cu.legend}",
                                unit_of_measure=f"{cu.units}",
                                mode=f"{mode}_vis_{curve_num}",
                            ),
                        )

    def get_mappings(self):
        super().get_mappings()

    @staticmethod
    def from_ModelTemplate(
        model_template: ModelTemplate = ModelTemplate(cmp_file),
        object_name: str = "",
        comment: str = "",
    ):
        """
        Creates a CompressorPerformance instance from a given ModelTemplate.

        Args:
            model_template (ModelTemplate): The model template to use for creating the model. Defaults to ModelTemplate(cmp_file).
            object_name (str, optional): The name of the object. Defaults to an empty string.
            comment (str, optional): An optional comment. Defaults to an empty string.

        Returns:
            CompressorPerformance: An instance of CompressorPerformance initialized with data from the provided ModelTemplate.
        """
        return CompressorPerformance(
            data=Model.from_ModelTemplate(model_template, object_name, comment).__dict__
        )

    @staticmethod
    def from_database(functional_location: str):
        """
        Creates and returns a CompressorPerformance instance for the given functional location,
        initializing it with default values and loading its mappings from the database.
        Args:
            functional_location (str): The functional location identifier for the compressor.
        Returns:
            CompressorPerformance: An instance of CompressorPerformance with mappings loaded.
        """

        mod = CompressorPerformance.get_empty(functional_location=functional_location)
        mod.get_mappings()
        return mod

    @staticmethod
    def models_in_database() -> List[str]:
        """
        Retrieves functional location (unique object identifier) for all CompressorPerformance models from the database.
        Returns:
            list[CompressorPerformance]: A list of function locations with compressor performance model mappings.
        """
        mod = CompressorPerformance.get_empty(functional_location="dummy")
        mappings = get_mappings(  # noqa: F821
            model_owner=mod.owner, model_name=mod.name
        )

        return list(
            sorted(
                set(
                    [
                        m["unique_object_identifier"]
                        for m in mappings
                        if m["model_owner"].upper() == mod.owner.upper()
                        and m["model_name"].upper() == mod.name.upper()
                    ]
                )
            )
        )

    @staticmethod
    def get_empty(functional_location: str):
        """
        Creates and returns an empty CompressorPerformance object, e.g., with no mappings, for the specified functional location.
        Args:
            functional_location (str): The identifier for the compressor's functional location.
        Returns:
            CompressorPerformance: An instance of CompressorPerformance initialized from the model template.
        Note:
            The function relies on a predefined model template (cmp_file) to create the CompressorPerformance object.
        """

        return CompressorPerformance.from_ModelTemplate(
            ModelTemplate(cmp_file), object_name=functional_location
        )
