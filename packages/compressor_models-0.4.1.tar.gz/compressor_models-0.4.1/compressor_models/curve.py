import ast
from datetime import date
import json
import os
import re
from enum import Enum
from typing import List, Optional, Union


from tagmapper.generic_model import Model


class CustomEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Enum):
            return obj.value
        elif hasattr(obj, "to_dict"):
            return obj.to_dict()

        return super().default(obj)


class InterpMethod(Enum):
    ZOH = (0,)
    LINEAR = (1,)
    QUADRATIC = 2


class Curve:
    def __init__(self) -> None:
        self.legend = ""
        self.units = []  # List of strings
        self.curve_data = []  # List of lists of floats
        pass

    def num_variables(self) -> int:
        return len(self.units)

    def to_dict(self):
        d = self.__dict__
        d = {"data" if k == "curve_data" else k: v for k, v in d.items()}
        # d["units"] = ast.literal_eval(d["units"])
        # d["data"] = ast.literal_eval(d["data"])
        return d

    def __eq__(self, obj):
        if not isinstance(obj, Curve):
            return False

        return self.to_dict() == obj.to_dict()

    def __str__(self) -> str:
        return f"Curve {self.legend} with {self.num_variables()} variables"

    @staticmethod
    def from_dict(data: dict):
        c = Curve()
        c.legend = data["legend"]
        if "'" in data["units"]:
            c.units = ast.literal_eval(data["units"])
        else:
            c.units = data["units"]

        # ensure that number of units matches number of columns in data
        try:
            c.curve_data = ast.literal_eval(data["data"])
        except:
            c.curve_data = data["data"]
        return c


class Equation:
    # Not implemented yet

    def __init__(self) -> None:
        raise NotImplementedError


class Curveset:
    def __init__(self) -> None:
        self.type = ""
        self.interp_method = ""
        self.interp_curves = []
        self.visualisation_curves = []

    def add_curve(self, curve: Curve, is_interp_curve: bool = True):
        if isinstance(curve, list):
            [self.add_curve(x, is_interp_curve) for x in curve]
            return

        if isinstance(curve, dict):
            curve = Curve.from_dict(curve)

        if is_interp_curve:
            if curve.legend in [x.legend for x in self.interp_curves]:
                raise ValueError(
                    f"Curve with legend {curve.legend} is already defined in Curveset interpolation curves"
                )

            self.interp_curves.append(curve)
        else:
            if curve.legend in [x.legend for x in self.visualisation_curves]:
                raise ValueError(
                    f"Curve with legend {curve.legend} is already defined in Curveset visualisation curves"
                )

            self.visualisation_curves.append(curve)

    def validate(self):
        # ensure that all curves have the same units and in the same order
        pass

    def to_dict(self):
        d = self.__dict__
        # Sort curves by legend
        if "interp_curves" in d:
            d["interp_curves"] = sorted(
                d["interp_curves"],
                key=lambda c: c.legend if hasattr(c, "legend") else c.get("legend", ""),
            )
        if "visualisation_curves" in d:
            d["visualisation_curves"] = sorted(
                d["visualisation_curves"],
                key=lambda c: c.legend if hasattr(c, "legend") else c.get("legend", ""),
            )
        d = {"primaryData" if k == "interp_curves" else k: v for k, v in d.items()}
        d = {
            "secondaryData" if k == "visualisation_curves" else k: v
            for k, v in d.items()
        }
        return d

    def __eq__(self, obj):
        if not isinstance(obj, Curveset):
            return False

        return self.to_dict() == obj.to_dict()

    def __str__(self) -> str:
        return f"Curveset {self.type} with {len(self.interp_curves)} curves"

    @staticmethod
    def from_dict(data: dict) -> "Curveset":
        try:
            cs = Curveset()
            cs.type = data["type"]
            if "interp_method" in data.keys():
                cs.interp_method = InterpMethod(data["interp_method"])
            else:
                cs.interp_method = InterpMethod.QUADRATIC
            [cs.add_curve(x) for x in data["primaryData"]]
            [cs.add_curve(x, False) for x in data["secondaryData"]]

            return cs
        except:  # noqa: E722
            raise ValueError("Not able to create Curveset from input data")


class Case:
    def __init__(self) -> None:
        self.description = ""
        self.docNo = ""
        self.curvesets = []

    def add_Curveset(self, curveset: Curveset):
        if curveset.type in [x.type for x in self.curvesets]:
            raise ValueError(
                f"Curveset of type {curveset.type} is already defined in Curveset"
            )

        self.curvesets.append(curveset)

    def to_dict(self):
        d = self.__dict__
        d = {"caseDescription" if k == "description" else k: v for k, v in d.items()}
        d = {"curveData" if k == "curvesets" else k: v for k, v in d.items()}
        return d

    def __eq__(self, obj, ignore_case_description: bool = False):
        if not isinstance(obj, Case):
            return False

        sd = self.to_dict()
        od = obj.to_dict()

        if ignore_case_description:
            # Ignore caseDescription for comparison
            sd["caseDescription"] = ""
            od["caseDescription"] = ""

        # for cu in sd["curveData"]:
        #    if cu not in od["curveData"]:
        #         return False

        # for cu in od["curveData"]:
        #    if cu not in sd["curveData"]:
        #         return False

        return sd == od

    def __str__(self) -> str:
        return f"Case {self.description} with {len(self.curvesets)} Curve sets"

    @staticmethod
    def from_dict(data: dict) -> List["Case"]:
        cases = []

        if "designData" in data.keys():
            for case_data in data["designData"]:
                case = Case()
                case.description = case_data["caseDescription"]
                [
                    case.add_Curveset(Curveset.from_dict(x))
                    for x in case_data["curveData"]
                ]
        else:
            case = Case()
            case.description = data["caseDescription"]
            [case.add_Curveset(Curveset.from_dict(x)) for x in data["curveData"]]

            # verify that case is not already included
        cases.append(case)

        return cases

    @staticmethod
    def read_json(file_path) -> List["Case"]:
        if isinstance(file_path, str):
            if os.path.isfile(file_path):
                with open(file_path, "r") as JSON:
                    data = json.load(JSON)
            else:
                data = json.loads(file_path)
        elif isinstance(file_path, dict):
            data = file_path

        return Case.from_dict(data)


class CurveFile:
    def __init__(
        self,
        equipmentTag: str,
        designData: Union["Case", List["Case"]] = [],
        fileCreated: str = "",
    ):
        if len(fileCreated) == 0:
            fileCreated = date.today().strftime("%B %d, %Y")
        self.fileCreated = fileCreated

        self.equipmentTag = equipmentTag

        if designData is None:
            designData = []
        if not isinstance(designData, list):
            designData = [designData]

        if len(designData) > 0:
            designData = [Case.from_dict(x)[0] if not isinstance(x, Case) else x for x in designData]  # type: ignore

        if not all([isinstance(x, Case) for x in designData]):  # type: ignore
            raise ValueError("Input designData shall be a Case or a list of Case.")

        # sort designData according to caseDescription
        self.designData = sorted(designData, key=lambda item: item.description.lower())

    def to_dict(self):
        return self.__dict__

    def to_json(self, file_path: str = "", indent: int = 2):
        # self.designData = [self.designData]
        if file_path is None or len(file_path) == 0:
            return json.dumps(self, cls=CustomEncoder, indent=indent)

        with open(file_path, "w") as f:
            json.dump(self, f, cls=CustomEncoder, indent=indent)

        # self.designData = self.designData[0]

    def __eq__(self, obj):
        if not isinstance(obj, CurveFile):
            return False

        return self.to_dict() == obj.to_dict()

    @staticmethod
    def from_dict(data: dict):
        return CurveFile(
            equipmentTag=data["equipmentTag"],
            designData=data["designData"],
            fileCreated=data["fileCreated"],
        )

    @staticmethod
    def read_json(file_path) -> "CurveFile":
        if isinstance(file_path, str):
            if os.path.isfile(file_path):
                with open(file_path, "r") as JSON:
                    data = json.load(JSON)
            else:
                data = json.loads(file_path)
        elif isinstance(file_path, dict):
            data = file_path

        return CurveFile.from_dict(data)

    @staticmethod
    def from_Compressor(cmp: Model) -> "CurveFile":
        cases = []
        # Get all cases
        for att in cmp.attributes:
            if att.type == "constant" and att.identifier.endswith("curve"):
                for map in att.mapping:
                    case_name = map.mode.split("_", 1)[0]
                    if case_name not in [x.description for x in cases]:
                        case = Case()
                        case.description = case_name
                        cases.append(case)

        for att in cmp.attributes:
            if att.type == "constant" and att.identifier.endswith("curve"):
                for map in att.mapping:
                    case_name = map.mode.split("_", 1)[0]
                    for case in cases:
                        if case.description == case_name:
                            curveset_type = att.identifier.replace("_curve", "")
                            if curveset_type.replace("_", " ") not in [
                                x.type for x in case.curvesets
                            ]:
                                cs = Curveset()
                                cs.type = curveset_type.replace("_", " ")
                                case.curvesets.append(cs)

                            for cs in case.curvesets:
                                if cs.type == curveset_type.replace("_", " "):
                                    cs.add_curve(
                                        Curve.from_dict(
                                            {
                                                "legend": map.comment.replace(
                                                    "legend:", ""
                                                ),
                                                "units": map.unit_of_measure,
                                                "data": map.value,
                                            }
                                        ),
                                        "interp" in map.mode,
                                    )

        return CurveFile(equipmentTag=cmp.object_name, designData=cases)

    @staticmethod
    def datafiles_to_json(
        folder_path: str,
        functional_location: str,
        case: str = "Default case",
        file_path: Optional[str] = None,
        file_created: Optional[Union[date, str]] = None,
    ) -> Union[str, None]:
        """Helper function to create json text from data files in folder.

        Args:
            folder_path (str): Folder to search for data files in.
            functional_location (str): Functional location (tag) for equipment.
            case Optional(str): Case for curve definition. Defaults to "Default case".
            file_path Optional(str): File path where curves shall be stored. Returns json as string if None or empty.
            file_created Optional(Union[date, str]): Date when file is created. If None, today's date is used.
        """

        if not isinstance(folder_path, str):
            folder_path = str(folder_path)

        if file_path is None:
            pass
        elif not isinstance(file_path, str):
            file_path = str(file_path)

        if file_created is None:
            file_created = date.today()
        if isinstance(file_created, date):
            file_created = file_created.strftime("%B %d, %Y")

        def getSpeedCurves(directory, files, keywords, units):
            res = [x for x in files if any(y in x for y in keywords)]
            results = []
            for file in res:
                x = re.findall(r"\d", file)
                x = "".join(x)
                n = int(x)
                data = []
                with open(os.path.join(directory, file), "r") as f:
                    lines = f.readlines()
                    for k in range(len(lines)):
                        linetxt = lines[k].strip()
                        float_list = [float(value) for value in linetxt.split()]
                        if len(float_list) == 2:
                            data.append([float(n)] + float_list)
                        elif len(float_list) == 3:
                            pass

                    results.append(dict(legend=x, units=units, data=data))
            return results

        def getCurves(directory, files, keywords, units):
            res = [x for x in files if any(y in x for y in keywords)]
            results = []
            for file in res:
                data = []
                with open(os.path.join(directory, file), "r") as f:
                    lines = f.readlines()
                    for k in range(len(lines)):
                        linetxt = lines[k].strip()
                        float_list = [float(value) for value in linetxt.split()]
                        if len(float_list) == 2:
                            data.append(float_list)
                        elif len(float_list) == 3:
                            pass

                    results.append(dict(legend=keywords[0], units=units, data=data))
            return results

        files = os.listdir(folder_path)

        headCurveData = getSpeedCurves(
            directory=folder_path,
            files=files,
            keywords=["head", "Head"],
            units=["RPM", "m3/hr", "kJ/kg"],
        )
        headCurveData_choke = getCurves(
            directory=folder_path,
            files=files,
            keywords=["choke", "Choke"],
            units=["m3/hr", "kJ/kg"],
        )
        headCurveData_control = getCurves(
            directory=folder_path,
            files=files,
            keywords=["control", "Control"],
            units=["m3/hr", "kJ/kg"],
        )

        secondaryData = headCurveData_choke
        secondaryData.extend(headCurveData_control)

        HeadCurves = dict(
            type="Head vs Flow",
            primaryData=headCurveData,
            secondaryData=secondaryData,
        )

        effCurveData = getSpeedCurves(
            directory=folder_path,
            files=files,
            keywords=["Eff", "eff"],
            units=["RPM", "m3/hr", "%"],
        )
        EfficiencyCurves = dict(
            type="Efficiency vs Flow", primaryData=effCurveData, secondaryData=[]
        )

        allcases = dict(caseDescription=case, curveData=[])
        allcases["curveData"] = [HeadCurves, EfficiencyCurves]
        allData = dict(
            fileCreated=file_created,
            equipmentTag=functional_location,
            designData=allcases,
        )

        indent = 2
        # self.designData = [self.designData]
        if file_path is None or len(file_path) == 0:
            return json.dumps(allData, cls=CustomEncoder, indent=indent)

        with open(file_path, "w") as f:
            json.dump(allData, f, cls=CustomEncoder, indent=indent)
