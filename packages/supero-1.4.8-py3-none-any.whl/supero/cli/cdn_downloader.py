"""
supero.cli.cdn_downloader — CDN downloads + template generation.

Downloads battle-tested UI files from CDN and generates
index.html and server.py from known-good templates.

All files are idempotent — safe to run multiple times.
No external dependencies (uses urllib from stdlib).
"""

import os
import urllib.request
import urllib.error

CDN_BASE = "https://cdn.supero.dev"
LIB_VERSION = os.getenv("SUPERO_LIB_VERSION", "1.0.0")

# ── Battle-tested index.html template ──
# Correct React 18 + Babel + Tailwind CDN paths.
# Script load order is CRITICAL: config.js → supero-ui.js → app.js
INDEX_HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>🚀</text></svg>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{app_name}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/react@18.2.0/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@18.2.0/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone@7.24.0/babel.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {{ font-family: 'Plus Jakarta Sans', 'Inter', sans-serif; }}
        .fade-in {{ animation: fadeIn 0.3s ease-in; }}
        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(6px); }} to {{ opacity: 1; transform: translateY(0); }} }}
        .pulse {{ animation: pulse 2s infinite; }}
        @keyframes pulse {{ 0%, 100% {{ opacity: 1; }} 50% {{ opacity: 0.5; }} }}
        .slide-in {{ animation: slideIn 0.25s ease-out; }}
        @keyframes slideIn {{ from {{ opacity: 0; transform: translateX(-8px); }} to {{ opacity: 1; transform: translateX(0); }} }}
        ::-webkit-scrollbar {{ width: 4px; }}
        ::-webkit-scrollbar-track {{ background: transparent; }}
        ::-webkit-scrollbar-thumb {{ background: #cbd5e1; border-radius: 4px; }}
    </style>
    <script>
        // Dynamic favicon from config — replaces default rocket with app emoji
        document.addEventListener('DOMContentLoaded', function() {{
            var cfg = window.__SUPERO_CONFIG || {{}};
            if (cfg.appEmoji) {{
                var link = document.querySelector("link[rel='icon']");
                if (link) link.href = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>" + cfg.appEmoji + "</text></svg>";
            }}
            if (cfg.appName) document.title = cfg.appName;
        }});
    </script>
</head>
<body class="bg-slate-50 min-h-screen">
    <div id="root"></div>
    <script src="config.js"></script>
    <script src="supero-ui.js?v={version}"></script>
    <script type="text/babel" src="app.js"></script>
</body>
</html>'''

# ── Battle-tested server.py template ──
# Uses supero.server.serve() which handles CORS proxy, login enrichment,
# file serving, and all the edge cases that break in LLM-generated versions.
SERVER_PY_TEMPLATE = '''#!/usr/bin/env python3
"""UI Server — uses supero.server library (battle-tested CORS proxy)."""
import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from supero.server import serve
serve(port=int(os.getenv("PORT", os.getenv("UI_PORT", "5648"))))
'''


class CdnDownloader:
    """
    Downloads CDN assets and generates infrastructure files.

    All operations are idempotent:
    - index.html and server.py are always regenerated (templates may improve)
    - supero-ui.js is only downloaded if not already present
    """

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def ensure_files(self, ui_dir: str, app_name: str = "Supero App"):
        """
        Generate templates and download CDN assets into the UI directory.

        Args:
            ui_dir:   Path to the ui/ directory (e.g., "myapp/ui")
            app_name: Application name for the HTML title tag
        """
        os.makedirs(ui_dir, exist_ok=True)

        # 1. Generate index.html (always — template may improve across versions)
        self._write_index_html(ui_dir, app_name)

        # 2. Generate server.py (always — battle-tested version)
        self._write_server_py(ui_dir)

        # 3. Download supero-ui.js from CDN (skip if exists)
        self._download_ui_js(ui_dir)

    def _write_index_html(self, ui_dir: str, app_name: str):
        """Generate index.html with correct CDN paths and script order."""
        index_path = os.path.join(ui_dir, "index.html")
        content = INDEX_HTML_TEMPLATE.format(
            app_name=app_name,
            version=LIB_VERSION,
        )
        with open(index_path, "w") as f:
            f.write(content)
        print(f"  ✓ Generated index.html")

    def _write_server_py(self, ui_dir: str):
        """Generate battle-tested server.py."""
        server_path = os.path.join(ui_dir, "server.py")
        with open(server_path, "w") as f:
            f.write(SERVER_PY_TEMPLATE)
        print(f"  ✓ Generated server.py")

    def _download_ui_js(self, ui_dir: str):
        """Download supero-ui.js from CDN if not already present."""
        ui_js_path = os.path.join(ui_dir, "supero-ui.js")

        if os.path.exists(ui_js_path):
            size_kb = os.path.getsize(ui_js_path) // 1024
            print(f"  ✓ supero-ui.js exists ({size_kb}KB)")
            return

        cdn_url = f"{CDN_BASE}/web-ui/{LIB_VERSION}/supero-ui.js"
        print(f"  ⬇ Downloading supero-ui.js...")

        if self.verbose:
            print(f"    URL: {cdn_url}")

        try:
            import shutil
            req = urllib.request.Request(cdn_url, headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) supero-cli/1.0"
            })
            with urllib.request.urlopen(req, timeout=30) as resp, open(ui_js_path, 'wb') as f:
                shutil.copyfileobj(resp, f)
            size_kb = os.path.getsize(ui_js_path) // 1024
            print(f"  ✓ Downloaded supero-ui.js ({size_kb}KB)")
        except Exception as e:
            print(f"  ⚠ CDN download failed: {e}")
            # Fallback: try curl
            import subprocess
            try:
                subprocess.run(["curl", "-sL", "-o", ui_js_path, cdn_url], check=True, timeout=30)
                size_kb = os.path.getsize(ui_js_path) // 1024
                print(f"  ✓ Downloaded supero-ui.js via curl ({size_kb}KB)")
            except Exception:
                print(f"    Copy manually: cp ~/supero/libs/supero-ui.js to the ui/ directory")
