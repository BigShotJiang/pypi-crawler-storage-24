"""Organization commands: list, switch, members, invite."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..config import get_config
from ..formatters import format_error, format_members_table, format_success, print_json
from ..models import Organization

app = typer.Typer(name="org", help="Manage organizations.")
console = Console()


@app.command("list")
def list_orgs(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List organizations you belong to."""
    client = CrowdTimeClient(require_auth=True, require_org=False)

    try:
        data = client.get("/api/v1/organizations/", org_scoped=False)
        orgs_list = data if isinstance(data, list) else data.get("results", [])
        orgs = [Organization(**item) for item in orgs_list]

        if output_json:
            print_json(orgs)
            return

        if not orgs:
            console.print("[dim]No organizations found.[/dim]")
            return

        current_slug = client.config.organization

        table = Table(show_header=True, header_style="bold")
        table.add_column("", width=3)
        table.add_column("Name", width=20)
        table.add_column("Slug", width=15)
        table.add_column("Role", width=18)
        table.add_column("Members", justify="right", width=8)

        for org in orgs:
            marker = "[green]*[/green]" if org.slug == current_slug else " "
            table.add_row(
                marker,
                org.name,
                org.slug,
                org.role or "",
                str(org.member_count or ""),
            )

        console.print(table)
        if current_slug:
            console.print(f"\n[dim]* = current organization ({current_slug})[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("create")
def create_org(
    name: str = typer.Argument(..., help="Name for the new organization."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new organization."""
    client = CrowdTimeClient(require_auth=True, require_org=False)

    try:
        data = client.post(
            "/api/v1/organizations/create-personal/",
            data={"name": name},
            org_scoped=False,
        )
        org = data.get("organization", {})

        if output_json:
            print_json(data)
        else:
            slug = org.get("slug", "")
            format_success(f"Organization '{org.get('name', name)}' created (slug: {slug})")
            console.print(f"[dim]Switch to it with: ct org switch {slug}[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("switch")
def switch_org(
    slug: str = typer.Argument(..., help="Organization slug to switch to."),
) -> None:
    """Switch the active organization."""
    # Verify the org exists
    client = CrowdTimeClient(require_auth=True, require_org=False)

    try:
        data = client.get("/api/v1/organizations/", org_scoped=False)
        orgs_list = data if isinstance(data, list) else data.get("results", [])
        slugs = [o.get("slug", "") for o in orgs_list]

        if slug not in slugs:
            format_error(f"Organization '{slug}' not found. Available: {', '.join(slugs)}")
            raise typer.Exit(1)

    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    config = get_config()
    config.set("defaults.organization", slug)
    format_success(f"Switched to organization '{slug}'")


@app.command()
def members(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List members of the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/members/")
        members_list = data if isinstance(data, list) else data.get("results", [])

        if output_json:
            print_json(members_list)
        else:
            format_members_table(members_list)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def invite(
    email: str = typer.Argument(..., help="Email address to invite."),
    role: str = typer.Option(
        "member", "--role", "-r",
        help="Role: admin, manager (account), project_manager, member, viewer.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Invite a member to the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post("/members/invite/", data={
            "email": email,
            "role": role,
        })

        if output_json:
            print_json(data)
        else:
            format_success(f"Invitation sent to {email} (role: {role})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("resend-invite")
def resend_invite(
    invitation_id: str = typer.Argument(..., help="Invitation ID to resend."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Resend a pending invitation email."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invitations/{invitation_id}/resend/")

        if output_json:
            print_json(data)
        else:
            format_success("Invitation email resent.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def invitations(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List pending invitations for the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invitations/")
        inv_list = data if isinstance(data, list) else data.get("results", [])

        if output_json:
            print_json(inv_list)
            return

        pending = [i for i in inv_list if i.get("status") == "pending"]
        if not pending:
            console.print("[dim]No pending invitations.[/dim]")
            return

        table = Table(show_header=True, header_style="bold")
        table.add_column("ID", style="dim")
        table.add_column("Email", width=25)
        table.add_column("Role", width=18)
        table.add_column("Status", width=10)
        table.add_column("Expires", width=12)

        role_labels = {
            "owner": "Owner",
            "admin": "Admin",
            "manager": "Account Manager",
            "project_manager": "Project Manager",
            "member": "Member",
            "viewer": "Viewer",
        }

        for inv in pending:
            table.add_row(
                inv.get("id", ""),
                inv.get("email", ""),
                role_labels.get(inv.get("role", ""), inv.get("role", "")),
                inv.get("status", ""),
                inv.get("expires_at", "")[:10] if inv.get("expires_at") else "",
            )

        console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
