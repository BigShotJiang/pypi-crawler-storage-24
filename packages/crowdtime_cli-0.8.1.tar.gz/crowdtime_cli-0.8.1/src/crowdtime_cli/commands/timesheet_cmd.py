"""Timesheet commands: list, submit, approve, reject, team overview."""

from __future__ import annotations

from datetime import date as date_type, timedelta
from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import format_error, format_success, print_json
from ..utils import format_date, format_duration, parse_date

app = typer.Typer(name="timesheet", help="Manage timesheets and approvals.")
console = Console()


# ─── Helpers ──────────────────────────────────────────────────────


def _status_style(status: str | None) -> str:
    """Return Rich markup style for a timesheet status."""
    styles = {
        "submitted": "blue",
        "approved": "green",
        "rejected": "red",
        "draft": "dim",
    }
    return styles.get(status or "", "yellow")


def _status_label(status: str | None) -> str:
    """Return human-readable label for a timesheet status."""
    if not status:
        return "Not Submitted"
    return status.capitalize()


def _print_timesheets_table(timesheets: list[dict], show_user: bool = False) -> None:
    """Print timesheets in a Rich table."""
    from rich.table import Table

    if not timesheets:
        console.print("[dim]No timesheets found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    if show_user:
        table.add_column("User", width=20)
    table.add_column("Period", width=25)
    table.add_column("Total", justify="right", width=8)
    table.add_column("Billable", justify="right", width=8)
    table.add_column("Status", width=14)
    table.add_column("Reviewer", width=15)

    for ts in timesheets:
        status = ts.get("status", "draft")
        style = _status_style(status)

        row = [str(ts.get("id", ""))]
        if show_user:
            row.append(ts.get("user_name", ts.get("user_email", "")))
        row.extend([
            f"{ts.get('period_start', '')} → {ts.get('period_end', '')}",
            format_duration(Decimal(str(ts.get("total_hours", 0)))),
            format_duration(Decimal(str(ts.get("billable_hours", 0)))),
            f"[{style}]{_status_label(status)}[/{style}]",
            ts.get("reviewer_name") or "—",
        ])
        table.add_row(*row)

    console.print(table)


def _print_team_overview(data: dict) -> None:
    """Print team overview in a Rich table."""
    from rich.table import Table

    members = data.get("members", [])
    period_start = data.get("period_start", "")
    period_end = data.get("period_end", "")

    console.print(f"\n[dim]Period: {period_start} to {period_end}[/dim]")

    if not members:
        console.print("[dim]No team members found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold", title="Team Timesheet Overview")
    table.add_column("Member", width=22)
    table.add_column("Email", width=25, style="dim")
    table.add_column("Hours", justify="right", width=8)
    table.add_column("Billable", justify="right", width=8)
    table.add_column("Entries", justify="right", width=8)
    table.add_column("Status", width=14)

    for m in members:
        status = m.get("timesheet_status")
        style = _status_style(status)

        table.add_row(
            m.get("user_name", ""),
            m.get("user_email", ""),
            format_duration(Decimal(str(m.get("total_hours", 0)))),
            format_duration(Decimal(str(m.get("billable_hours", 0)))),
            str(m.get("entry_count", 0)),
            f"[{style}]{_status_label(status)}[/{style}]",
        )

    console.print(table)


# ─── Commands ─────────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def timesheet_default(ctx: typer.Context) -> None:
    """Manage timesheets and approvals."""
    if ctx.invoked_subcommand is None:
        list_timesheets()


@app.command("list")
def list_timesheets(
    user: Optional[str] = typer.Option(None, "--user", "-u", help="User ID to view (manager+)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List timesheets. Managers can view other users' timesheets.

    Examples:
        ct timesheet list
        ct timesheet list --user <user-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if user:
        params["user_id"] = user

    try:
        data = client.get("/timesheets/", params=params or None)
        results = data.get("results", []) if isinstance(data, dict) else data

        if output_json:
            print_json(results)
        else:
            _print_timesheets_table(results, show_user=bool(user))
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("submit")
def submit_timesheet(
    period_start: str = typer.Option(
        ..., "--from", help="Period start date (YYYY-MM-DD or keyword)."
    ),
    period_end: str = typer.Option(
        ..., "--to", help="Period end date (YYYY-MM-DD or keyword)."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Submit a timesheet for approval.

    Computes total hours from your time entries in the given period.

    Examples:
        ct timesheet submit --from 2026-03-09 --to 2026-03-15
        ct timesheet submit --from monday --to friday
    """
    try:
        start = format_date(parse_date(period_start))
        end = format_date(parse_date(period_end))
    except ValueError as e:
        format_error(str(e))
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        result = client.post("/timesheets/submit/", data={
            "period_start": start,
            "period_end": end,
        })

        if output_json:
            print_json(result)
        else:
            total = format_duration(Decimal(str(result.get("total_hours", 0))))
            billable = format_duration(Decimal(str(result.get("billable_hours", 0))))
            format_success(
                f"Timesheet submitted ({start} → {end}): {total} total, {billable} billable"
            )
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("approve")
def approve_timesheet(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID to approve."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Reviewer notes."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Approve a submitted timesheet (manager+).

    Examples:
        ct timesheet approve <timesheet-id>
        ct timesheet approve <timesheet-id> --notes "Looks good"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data: dict = {}
        if notes:
            data["notes"] = notes

        result = client.post(f"/timesheets/{timesheet_id}/approve/", data=data or None)

        if output_json:
            print_json(result)
        else:
            user_name = result.get("user_name", "user")
            format_success(f"Timesheet from {user_name} approved.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("reject")
def reject_timesheet(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID to reject."),
    notes: str = typer.Option(
        ..., "--notes", "-n", help="Rejection reason (required)."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Reject a submitted timesheet with notes (manager+).

    Examples:
        ct timesheet reject <timesheet-id> --notes "Missing entries for Wednesday"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        result = client.post(f"/timesheets/{timesheet_id}/reject/", data={
            "notes": notes,
        })

        if output_json:
            print_json(result)
        else:
            user_name = result.get("user_name", "user")
            format_success(f"Timesheet from {user_name} rejected.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("recall")
def recall_timesheet(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID to recall."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Recall a submitted timesheet back to draft (owner only, before approval).

    Examples:
        ct timesheet recall <timesheet-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        result = client.post(f"/timesheets/{timesheet_id}/recall/")

        if output_json:
            print_json(result)
        else:
            format_success("Timesheet recalled to draft. You can now edit and resubmit.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("team")
def team_overview(
    period_start: Optional[str] = typer.Option(
        None, "--from", help="Period start date (default: current week)."
    ),
    period_end: Optional[str] = typer.Option(
        None, "--to", help="Period end date."
    ),
    week: bool = typer.Option(False, "--week", "-w", help="This week (default)."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show team timesheet overview for a period (manager+).

    Displays all org members with their hours and timesheet status,
    including those who haven't submitted yet.

    Examples:
        ct timesheet team
        ct timesheet team --last-week
        ct timesheet team --from 2026-03-09 --to 2026-03-15
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}

    if period_start:
        try:
            params["period_start"] = format_date(parse_date(period_start))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if period_end:
        try:
            params["period_end"] = format_date(parse_date(period_end))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if last_week and not period_start:
        today = date_type.today()
        start = today - timedelta(days=today.weekday() + 7)
        end = start + timedelta(days=6)
        params["period_start"] = format_date(start)
        params["period_end"] = format_date(end)

    try:
        data = client.get("/timesheets/team-overview/", params=params or None)

        if output_json:
            print_json(data)
        else:
            _print_team_overview(data)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("viewable-users")
def viewable_users(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List team members whose timesheets you can view (manager+).

    Examples:
        ct timesheet viewable-users
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/timesheets/viewable-users/")
        users = data if isinstance(data, list) else []

        if output_json:
            print_json(users)
        else:
            from rich.table import Table

            if not users:
                console.print("[dim]No viewable users found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=20)
            table.add_column("Email", width=30)

            for u in users:
                table.add_row(
                    u.get("id", ""),
                    u.get("full_name", ""),
                    u.get("email", ""),
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
