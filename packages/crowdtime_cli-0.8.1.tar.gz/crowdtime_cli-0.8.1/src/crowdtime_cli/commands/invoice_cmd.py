"""Invoice commands: list, show, create, send, void, pay, pdf, duplicate, add-item, recurring, retainer."""

from __future__ import annotations

import calendar
from datetime import date as date_type, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import format_error, format_success, print_json
from ..utils import format_date, format_duration, parse_date

app = typer.Typer(name="invoice", help="Manage invoices, payments, and billing.")
console = Console()

# ─── Sub-apps for nested commands ─────────────────────────────────

recurring_app = typer.Typer(name="recurring", help="Manage recurring invoice templates.")
retainer_app = typer.Typer(name="retainer", help="Manage retainer agreements.")
app.add_typer(recurring_app, name="recurring")
app.add_typer(retainer_app, name="retainer")


# ─── Helpers ──────────────────────────────────────────────────────


def _status_style(status: str | None) -> str:
    """Return Rich markup style for an invoice status."""
    styles = {
        "draft": "dim",
        "sent": "blue",
        "viewed": "cyan",
        "partial": "yellow",
        "paid": "green",
        "overdue": "red bold",
        "void": "red dim",
    }
    return styles.get(status or "", "yellow")


def _status_label(status: str | None) -> str:
    """Return human-readable label for an invoice status."""
    if not status:
        return "Draft"
    return status.capitalize()


def _format_currency(amount: str | float | Decimal | None, currency: str = "") -> str:
    """Format a currency amount for display."""
    if amount is None:
        return "$0.00"
    try:
        value = Decimal(str(amount))
    except Exception:
        return "$0.00"
    prefix = f"{currency} " if currency and currency != "USD" else "$"
    return f"{prefix}{value:,.2f}"


def _resolve_period(period: str) -> tuple[str, str]:
    """Resolve a preset period name into (start_date, end_date) ISO strings.

    Uses Monday as the default week start day.
    """
    today = date_type.today()

    if period == "last-week":
        # Monday of last week to Sunday of last week
        monday_this_week = today - timedelta(days=today.weekday())
        start = monday_this_week - timedelta(days=7)
        end = start + timedelta(days=6)
    elif period == "last-2-weeks":
        monday_this_week = today - timedelta(days=today.weekday())
        start = monday_this_week - timedelta(days=14)
        end = monday_this_week - timedelta(days=1)
    elif period == "last-month":
        first_this_month = today.replace(day=1)
        last_day_prev = first_this_month - timedelta(days=1)
        start = last_day_prev.replace(day=1)
        end = last_day_prev
    elif period == "this-month":
        start = today.replace(day=1)
        last_day = calendar.monthrange(today.year, today.month)[1]
        end = today.replace(day=last_day)
    else:
        raise ValueError(
            f"Unknown period '{period}'. "
            "Choose: last-week, last-2-weeks, last-month, this-month."
        )

    return format_date(start), format_date(end)


def _resolve_payment_terms(value: str) -> int | None:
    """Resolve a payment terms string to an integer number of days.

    Returns None if the value is invalid.
    """
    mapping = {
        "receipt": 0,
        "net15": 15,
        "net30": 30,
    }
    lower = value.strip().lower()
    if lower in mapping:
        return mapping[lower]
    try:
        return int(lower)
    except ValueError:
        return None


def _print_invoices_table(invoices: list[dict]) -> None:
    """Print invoices in a Rich table."""
    if not invoices:
        console.print("[dim]No invoices found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Number", width=14)
    table.add_column("Client", width=20)
    table.add_column("Type", width=10)
    table.add_column("Issue Date", width=12)
    table.add_column("Due Date", width=12)
    table.add_column("Total", justify="right", width=12)
    table.add_column("Due", justify="right", width=12)
    table.add_column("Status", width=12)

    for inv in invoices:
        status = inv.get("status", "draft")
        style = _status_style(status)
        currency = inv.get("currency", "USD")
        inv_type = inv.get("invoice_type", inv.get("type", "standard"))

        table.add_row(
            inv.get("invoice_number", inv.get("number", "")),
            inv.get("client_name", ""),
            inv_type.capitalize() if inv_type else "Standard",
            inv.get("issue_date", ""),
            inv.get("due_date", ""),
            _format_currency(inv.get("total_amount", inv.get("total", 0)), currency),
            _format_currency(inv.get("amount_due", inv.get("due", 0)), currency),
            f"[{style}]{_status_label(status)}[/{style}]",
        )

    console.print(table)


def _print_invoice_detail(data: dict) -> None:
    """Print detailed invoice view."""
    currency = data.get("currency", "USD")
    status = data.get("status", "draft")
    style = _status_style(status)

    console.print()
    console.print(f"[bold]Invoice {data.get('invoice_number', data.get('number', ''))}[/bold]")
    console.print(f"  ID:             {data.get('id', '')}")
    console.print(f"  Client:         {data.get('client_name', '')}")
    inv_type = data.get("invoice_type", data.get("type", "standard"))
    console.print(f"  Type:           {inv_type.capitalize() if inv_type else 'Standard'}")
    console.print(f"  Status:         [{style}]{_status_label(status)}[/{style}]")
    console.print(f"  Issue Date:     {data.get('issue_date', '')}")
    console.print(f"  Due Date:       {data.get('due_date', '')}")
    console.print(f"  Currency:       {currency}")

    if data.get("po_number"):
        console.print(f"  PO Number:      {data['po_number']}")

    # Line items
    line_items = data.get("line_items", data.get("items", []))
    if line_items:
        console.print()
        items_table = Table(show_header=True, header_style="bold", title="Line Items")
        items_table.add_column("#", width=4, justify="right")
        items_table.add_column("Description", width=35)
        items_table.add_column("Qty", justify="right", width=8)
        items_table.add_column("Rate", justify="right", width=10)
        items_table.add_column("Amount", justify="right", width=12)
        items_table.add_column("Tax", width=5, justify="center")

        for i, item in enumerate(line_items, 1):
            qty = item.get("quantity", item.get("qty", 0))
            rate = item.get("unit_price", item.get("rate", 0))
            amount = item.get("amount", item.get("total", 0))
            taxable = item.get("taxable", False)

            items_table.add_row(
                str(i),
                item.get("description", ""),
                str(qty),
                _format_currency(rate, currency),
                _format_currency(amount, currency),
                "[green]Y[/green]" if taxable else "[dim]N[/dim]",
            )

        console.print(items_table)

    # Totals
    console.print()
    console.print("[bold]Totals[/bold]")
    console.print(f"  Subtotal:       {_format_currency(data.get('subtotal', data.get('total_amount', 0)), currency)}")
    if data.get("tax_amount"):
        tax_rate = data.get("tax_rate", "")
        tax_label = f" ({tax_rate}%)" if tax_rate else ""
        console.print(f"  Tax{tax_label}:          {_format_currency(data['tax_amount'], currency)}")
    if data.get("discount_amount"):
        console.print(f"  Discount:       -{_format_currency(data['discount_amount'], currency)}")
    console.print(f"  [bold]Total:          {_format_currency(data.get('total_amount', data.get('total', 0)), currency)}[/bold]")
    console.print(f"  Paid:           {_format_currency(data.get('paid_amount', data.get('amount_paid', 0)), currency)}")
    console.print(f"  [bold]Amount Due:     {_format_currency(data.get('amount_due', data.get('due', 0)), currency)}[/bold]")

    # Payments
    payments = data.get("payments", [])
    if payments:
        console.print()
        pay_table = Table(show_header=True, header_style="bold", title="Payments")
        pay_table.add_column("Date", width=12)
        pay_table.add_column("Amount", justify="right", width=12)
        pay_table.add_column("Method", width=15)
        pay_table.add_column("Reference", width=20)
        pay_table.add_column("Notes", width=25)

        for pay in payments:
            pay_table.add_row(
                pay.get("payment_date", pay.get("date", "")),
                _format_currency(pay.get("amount", 0), currency),
                pay.get("payment_method", pay.get("method", "")) or "",
                pay.get("reference", "") or "",
                pay.get("notes", "") or "",
            )

        console.print(pay_table)

    # Notes and terms
    if data.get("notes"):
        console.print(f"\n[dim]Notes:[/dim] {data['notes']}")
    if data.get("terms"):
        console.print(f"[dim]Terms:[/dim] {data['terms']}")

    console.print()


# ─── Commands ─────────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def invoice_default(ctx: typer.Context) -> None:
    """Manage invoices, payments, and billing."""
    if ctx.invoked_subcommand is None:
        list_invoices()


@app.command("list")
def list_invoices(
    status: Optional[str] = typer.Option(
        None, "--status", "-s", help="Filter by status: draft, sent, paid, overdue, void, partial."
    ),
    client_id: Optional[str] = typer.Option(
        None, "--client", "-c", help="Filter by client ID."
    ),
    invoice_type: Optional[str] = typer.Option(
        None, "--type", "-t", help="Filter by type: standard, recurring, retainer."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List invoices in the current organization.

    Examples:
        ct invoice list
        ct invoice list --status sent
        ct invoice list --client <client-id> --status paid
        ct invoice list --type recurring
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if status:
        params["status"] = status
    if client_id:
        params["client"] = client_id
    if invoice_type:
        params["invoice_type"] = invoice_type

    try:
        data = client.get("/invoices/", params=params or None)
        results = data.get("results", []) if isinstance(data, dict) else data

        if output_json:
            print_json(results)
        else:
            _print_invoices_table(results)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("show")
def show_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show detailed view of an invoice.

    Examples:
        ct invoice show <invoice-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/invoices/{invoice_id}/")

        if output_json:
            print_json(data)
        else:
            _print_invoice_detail(data)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("create")
def create_invoice(
    client_id: str = typer.Option(..., "--client", "-c", help="Client ID."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Period start date."),
    to_date: Optional[str] = typer.Option(None, "--to", help="Period end date."),
    period: Optional[str] = typer.Option(
        None, "--period", "-P",
        help="Preset period: last-week, last-2-weeks, last-month, this-month.",
    ),
    group_by: Optional[str] = typer.Option(
        None, "--group-by", "-g", help="Group line items by: project, task, date, entry."
    ),
    tax_rate: Optional[float] = typer.Option(
        None, "--tax-rate", help="Tax rate percentage (e.g. 21 for 21%)."
    ),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Invoice notes."),
    terms: Optional[str] = typer.Option(None, "--terms", help="Payment terms text."),
    payment_terms: Optional[str] = typer.Option(
        None, "--payment-terms",
        help="Payment terms: receipt, net15, net30, or number of days.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create an invoice from tracked time entries.

    Generates an invoice for a client's billable time entries within
    the specified date range. Use --period for preset ranges or
    --from/--to for custom dates.

    Examples:
        ct invoice create --client <id> --from 2026-03-01 --to 2026-03-31
        ct invoice create --client <id> --period last-month --group-by project
        ct invoice create --client <id> --period last-2-weeks --payment-terms net30
        ct invoice create --client <id> --from monday --to friday --payment-terms 15
    """
    # Resolve period dates
    if period:
        if from_date or to_date:
            format_error("Cannot use --period together with --from/--to. Choose one.")
            raise typer.Exit(1)
        try:
            start, end = _resolve_period(period)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    elif from_date and to_date:
        try:
            start = format_date(parse_date(from_date))
            end = format_date(parse_date(to_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    else:
        format_error("Provide either --period or both --from and --to.")
        raise typer.Exit(1)

    # Resolve payment terms
    payment_terms_days: int | None = None
    if payment_terms is not None:
        payment_terms_days = _resolve_payment_terms(payment_terms)
        if payment_terms_days is None:
            format_error(
                f"Invalid --payment-terms: '{payment_terms}'. "
                "Use: receipt, net15, net30, or a number of days."
            )
            raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "client_id": client_id,
        "date_from": start,
        "date_to": end,
    }
    if group_by:
        payload["group_by"] = group_by
    if tax_rate is not None:
        payload["tax_rate"] = str(tax_rate)
    if notes:
        payload["notes"] = notes
    if terms:
        payload["terms"] = terms
    if payment_terms_days is not None:
        payload["payment_terms_days"] = payment_terms_days

    try:
        data = client.post("/invoices/from-time-entries/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", ""))
            currency = data.get("currency", "USD")
            total = _format_currency(data.get("total_amount", data.get("total", 0)), currency)
            line_items = data.get("line_items", data.get("items", []))
            items_count = len(line_items)

            # Count expense line items
            expense_count = sum(
                1 for item in line_items
                if item.get("line_item_type") == "expense"
                or item.get("type") == "expense"
            )

            msg = (
                f"Invoice {inv_number} created as draft: {total} "
                f"({items_count} line item{'s' if items_count != 1 else ''}, "
                f"period {start} to {end})"
            )
            format_success(msg)
            console.print(f"  ID: {data.get('id', '')}")

            if expense_count:
                console.print(
                    f"  [dim]Includes {expense_count} expense"
                    f"{'s' if expense_count != 1 else ''}.[/dim]"
                )
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("create-blank")
def create_blank_invoice(
    client_id: str = typer.Option(..., "--client", "-c", help="Client ID."),
    issue_date: str = typer.Option(..., "--issue-date", help="Issue date."),
    due_date: Optional[str] = typer.Option(None, "--due-date", help="Due date (auto-calculated from --payment-terms if omitted)."),
    subject: Optional[str] = typer.Option(None, "--subject", "-s", help="Invoice subject line."),
    payment_terms: Optional[str] = typer.Option(
        None, "--payment-terms",
        help="Payment terms: receipt, net15, net30, or number of days. Auto-calculates due date.",
    ),
    currency: Optional[str] = typer.Option(None, "--currency", help="Currency code (e.g. USD, EUR)."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Invoice notes."),
    terms: Optional[str] = typer.Option(None, "--terms", help="Payment terms text (e.g. bank account details)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create an empty draft invoice for manual line item addition.

    Examples:
        ct invoice create-blank --client <id> --issue-date today
        ct invoice create-blank --client <id> --issue-date 2026-03-15 --payment-terms net30
        ct invoice create-blank --client <id> --issue-date today --due-date 2026-04-15 --currency EUR
        ct invoice create-blank --client <id> --issue-date today --terms "Wire to IBAN XX" --notes "March work"
    """
    try:
        parsed_issue_date = parse_date(issue_date)
        parsed_issue = format_date(parsed_issue_date)
    except ValueError as e:
        format_error(str(e))
        raise typer.Exit(1)

    # Resolve payment terms days
    payment_terms_days: int | None = None
    if payment_terms is not None:
        payment_terms_days = _resolve_payment_terms(payment_terms)
        if payment_terms_days is None:
            format_error(
                f"Invalid --payment-terms: '{payment_terms}'. "
                "Use: receipt, net15, net30, or a number of days."
            )
            raise typer.Exit(1)

    # Resolve due date: explicit --due-date > calculated from --payment-terms > default net30
    parsed_due = None
    if due_date:
        try:
            parsed_due = format_date(parse_date(due_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    elif payment_terms_days is not None:
        parsed_due = format_date(parsed_issue_date + timedelta(days=payment_terms_days))
    else:
        # Default to net30
        payment_terms_days = 30
        parsed_due = format_date(parsed_issue_date + timedelta(days=30))

    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "client": client_id,
        "issue_date": parsed_issue,
        "due_date": parsed_due,
    }
    if subject:
        payload["subject"] = subject
    if currency:
        payload["currency"] = currency
    if notes:
        payload["notes"] = notes
    if terms:
        payload["terms"] = terms
    if payment_terms_days is not None:
        payload["payment_terms_days"] = payment_terms_days

    try:
        data = api_client.post("/invoices/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", ""))
            format_success(f"Blank invoice {inv_number} created as draft.")
            console.print(f"  ID: {data.get('id', '')}")
            console.print("[dim]Add line items with: ct invoice add-item <invoice-id> ...[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("update")
def update_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to update (must be draft)."),
    invoice_number: Optional[str] = typer.Option(None, "--number", help="Invoice number (e.g. INV-0078)."),
    subject: Optional[str] = typer.Option(None, "--subject", "-s", help="Invoice subject line."),
    issue_date: Optional[str] = typer.Option(None, "--issue-date", help="Issue date."),
    due_date: Optional[str] = typer.Option(None, "--due-date", help="Due date."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Invoice notes."),
    terms: Optional[str] = typer.Option(None, "--terms", help="Payment terms text (e.g. bank account details)."),
    footer: Optional[str] = typer.Option(None, "--footer", help="Invoice footer text."),
    currency: Optional[str] = typer.Option(None, "--currency", help="Currency code (e.g. USD, EUR)."),
    tax_rate: Optional[float] = typer.Option(None, "--tax-rate", help="Tax rate percentage (e.g. 21 for 21%%)."),
    payment_terms: Optional[str] = typer.Option(
        None, "--payment-terms",
        help="Payment terms: receipt, net15, net30, or number of days.",
    ),
    from_name: Optional[str] = typer.Option(None, "--from-name", help="Issuer/sender name."),
    from_email: Optional[str] = typer.Option(None, "--from-email", help="Issuer/sender email."),
    from_address: Optional[str] = typer.Option(None, "--from-address", help="Issuer/sender address."),
    client_name: Optional[str] = typer.Option(None, "--client-name", help="Bill-to client name."),
    client_email: Optional[str] = typer.Option(None, "--client-email", help="Bill-to client email."),
    client_address: Optional[str] = typer.Option(None, "--client-address", help="Bill-to client address."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update a draft invoice's fields.

    Only draft invoices can be edited. Once sent, use void + recreate.

    Examples:
        ct invoice update <id> --subject "March 2026 Development"
        ct invoice update <id> --terms "Wire to IBAN XX" --notes "Net 30"
        ct invoice update <id> --tax-rate 21 --due-date 2026-04-15
        ct invoice update <id> --number "INV-0078"
        ct invoice update <id> --from-name "Acme Inc" --from-email "billing@acme.com"
        ct invoice update <id> --client-name "Beta Corp" --client-email "ap@beta.com"
    """
    # Build payload from provided options
    payload: dict = {}

    if invoice_number is not None:
        payload["invoice_number"] = invoice_number
    if subject is not None:
        payload["subject"] = subject
    if notes is not None:
        payload["notes"] = notes
    if terms is not None:
        payload["terms"] = terms
    if footer is not None:
        payload["footer"] = footer
    if currency is not None:
        payload["currency"] = currency
    if tax_rate is not None:
        payload["tax_rate"] = str(tax_rate)
    if from_name is not None:
        payload["from_name"] = from_name
    if from_email is not None:
        payload["from_email"] = from_email
    if from_address is not None:
        payload["from_address"] = from_address
    if client_name is not None:
        payload["client_name"] = client_name
    if client_email is not None:
        payload["client_email"] = client_email
    if client_address is not None:
        payload["client_address"] = client_address

    if issue_date is not None:
        try:
            payload["issue_date"] = format_date(parse_date(issue_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if due_date is not None:
        try:
            payload["due_date"] = format_date(parse_date(due_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if payment_terms is not None:
        days = _resolve_payment_terms(payment_terms)
        if days is None:
            format_error(
                f"Invalid --payment-terms: '{payment_terms}'. "
                "Use: receipt, net15, net30, or a number of days."
            )
            raise typer.Exit(1)
        payload["payment_terms_days"] = days

    if not payload:
        format_error("No fields to update. Provide at least one option.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.patch(f"/invoices/{invoice_id}/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", invoice_id))
            fields = ", ".join(payload.keys())
            format_success(f"Invoice {inv_number} updated ({fields}).")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("send")
def send_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to send."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Send an invoice to the client.

    Transitions the invoice from draft to sent status.
    This action cannot be undone (use void instead).

    Examples:
        ct invoice send <invoice-id>
        ct invoice send <invoice-id> --force
    """
    if not force:
        if not typer.confirm("Send this invoice? This cannot be undone."):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invoices/{invoice_id}/send/")

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", invoice_id))
            format_success(f"Invoice {inv_number} sent.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("void")
def void_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to void."),
    reason: str = typer.Option(..., "--reason", "-r", help="Reason for voiding (required)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Void an invoice.

    Marks the invoice as void with a reason. Voided invoices
    cannot be edited or sent. Time entries are unlinked.

    Examples:
        ct invoice void <invoice-id> --reason "Duplicate invoice"
        ct invoice void <invoice-id> -r "Client requested cancellation"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invoices/{invoice_id}/void/", data={"void_reason": reason})

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", invoice_id))
            format_success(f"Invoice {inv_number} voided.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("pay")
def record_payment(
    invoice_id: str = typer.Argument(..., help="Invoice ID to record payment for."),
    amount: str = typer.Option(..., "--amount", "-a", help="Payment amount."),
    payment_date: Optional[str] = typer.Option(
        None, "--date", "-d", help="Payment date (default: today)."
    ),
    method: Optional[str] = typer.Option(
        None, "--method", "-m", help="Payment method (e.g. bank_transfer, credit_card, check, cash, other)."
    ),
    reference: Optional[str] = typer.Option(
        None, "--reference", "-r", help="Payment reference number."
    ),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Payment notes."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Record a payment against an invoice.

    Examples:
        ct invoice pay <invoice-id> --amount 1500.00
        ct invoice pay <invoice-id> --amount 500 --date 2026-03-10 --method bank_transfer --reference "TXN-123"
    """
    try:
        parsed_amount = Decimal(amount)
    except Exception:
        format_error(f"Invalid amount: '{amount}'. Provide a numeric value.")
        raise typer.Exit(1)

    parsed_date = None
    if payment_date:
        try:
            parsed_date = format_date(parse_date(payment_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"amount": str(parsed_amount)}
    if parsed_date:
        payload["payment_date"] = parsed_date
    if method:
        payload["payment_method"] = method
    if reference:
        payload["reference"] = reference
    if notes:
        payload["notes"] = notes

    try:
        data = client.post(f"/invoices/{invoice_id}/payments/", data=payload)

        if output_json:
            print_json(data)
        else:
            remaining = data.get("amount_due", data.get("remaining", None))
            inv_status = data.get("invoice_status", data.get("status", ""))
            msg = f"Payment of {_format_currency(parsed_amount)} recorded."
            if remaining is not None:
                msg += f" Remaining: {_format_currency(remaining)}."
            if inv_status == "paid":
                msg += " Invoice is now fully paid."
            format_success(msg)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("pdf")
def download_pdf(
    invoice_id: str = typer.Argument(..., help="Invoice ID."),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path (default: invoice-<number>.pdf)."
    ),
) -> None:
    """Download invoice as PDF.

    Examples:
        ct invoice pdf <invoice-id>
        ct invoice pdf <invoice-id> --output ~/invoices/march-2026.pdf
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        # Get invoice details first for the filename
        invoice_data = client.get(f"/invoices/{invoice_id}/")
        inv_number = invoice_data.get("invoice_number", invoice_data.get("number", invoice_id))

        # Download the PDF
        pdf_data = client.get(f"/invoices/{invoice_id}/pdf/", raw=True)

        if output:
            file_path = Path(output).expanduser()
        else:
            safe_number = inv_number.replace("/", "-").replace("\\", "-")
            file_path = Path(f"invoice-{safe_number}.pdf")

        # Ensure parent directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_bytes(pdf_data if isinstance(pdf_data, bytes) else pdf_data.encode())

        format_success(f"Invoice PDF saved to {file_path}")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
    except OSError as e:
        format_error(f"Could not write file: {e}")
        raise typer.Exit(1)


@app.command("duplicate")
def duplicate_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to duplicate."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Duplicate an existing invoice as a new draft.

    Creates a copy of the invoice with new dates and number,
    preserving line items.

    Examples:
        ct invoice duplicate <invoice-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invoices/{invoice_id}/duplicate/")

        if output_json:
            print_json(data)
        else:
            new_number = data.get("invoice_number", data.get("number", ""))
            format_success(f"Invoice duplicated as {new_number} (draft).")
            console.print(f"  ID: {data.get('id', '')}")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("add-item")
def add_line_item(
    invoice_id: str = typer.Argument(..., help="Invoice ID to add line item to."),
    description: str = typer.Option(..., "--description", "--desc", "-d", help="Line item description."),
    quantity: str = typer.Option(..., "--qty", "-q", help="Quantity (e.g. hours)."),
    rate: str = typer.Option(..., "--rate", "-r", help="Unit rate."),
    taxable: Optional[bool] = typer.Option(None, "--taxable/--no-taxable", help="Whether item is taxable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Add a line item to a draft invoice.

    Examples:
        ct invoice add-item <invoice-id> --desc "Development work" --qty 10 --rate 150
        ct invoice add-item <invoice-id> --desc "Consulting" --qty 5 --rate 200 --taxable
    """
    try:
        parsed_qty = Decimal(quantity)
        parsed_rate = Decimal(rate)
    except Exception:
        format_error("Invalid quantity or rate. Provide numeric values.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "description": description,
        "quantity": str(parsed_qty),
        "unit_price": str(parsed_rate),
    }
    if taxable is not None:
        payload["is_taxable"] = taxable

    try:
        data = client.post(f"/invoices/{invoice_id}/line-items/", data=payload)

        if output_json:
            print_json(data)
        else:
            amount = Decimal(str(parsed_qty)) * Decimal(str(parsed_rate))
            format_success(
                f"Line item added: {description} "
                f"({parsed_qty} x {_format_currency(parsed_rate)} = {_format_currency(amount)})"
            )
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        elif e.status_code == 400:
            format_error(e.message)
        else:
            format_error(e.message)
        raise typer.Exit(1)


# ─── Recurring Templates ─────────────────────────────────────────


@recurring_app.callback(invoke_without_command=True)
def recurring_default(ctx: typer.Context) -> None:
    """Manage recurring invoice templates."""
    if ctx.invoked_subcommand is None:
        list_recurring()


@recurring_app.command("list")
def list_recurring(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List recurring invoice templates.

    Examples:
        ct invoice recurring list
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invoices/recurring-templates/")
        results = data.get("results", []) if isinstance(data, dict) else data

        if output_json:
            print_json(results)
        else:
            if not results:
                console.print("[dim]No recurring templates found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=20)
            table.add_column("Client", width=18)
            table.add_column("Schedule", width=14)
            table.add_column("Active", width=8, justify="center")
            table.add_column("Next Run", width=12)
            table.add_column("Generated", justify="right", width=10)

            for tmpl in results:
                is_active = tmpl.get("is_active", tmpl.get("active", False))
                active_label = "[green]Yes[/green]" if is_active else "[dim]No[/dim]"

                table.add_row(
                    str(tmpl.get("id", "")),
                    tmpl.get("name", tmpl.get("title", "")),
                    tmpl.get("client_name", ""),
                    tmpl.get("schedule", tmpl.get("frequency", "")),
                    active_label,
                    tmpl.get("next_run_date", tmpl.get("next_run", "")) or "",
                    str(tmpl.get("invoices_generated", tmpl.get("generated_count", 0))),
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


# ─── Retainers ────────────────────────────────────────────────────


@retainer_app.callback(invoke_without_command=True)
def retainer_default(ctx: typer.Context) -> None:
    """Manage retainer agreements."""
    if ctx.invoked_subcommand is None:
        list_retainers()


@retainer_app.command("list")
def list_retainers(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List retainer agreements.

    Examples:
        ct invoice retainer list
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invoices/retainers/")
        results = data.get("results", []) if isinstance(data, dict) else data

        if output_json:
            print_json(results)
        else:
            if not results:
                console.print("[dim]No retainers found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=20)
            table.add_column("Client", width=18)
            table.add_column("Monthly", justify="right", width=12)
            table.add_column("Included Hours", justify="right", width=15)
            table.add_column("Status", width=10)

            for ret in results:
                status = ret.get("status", "active")
                style = "green" if status == "active" else "dim"
                currency = ret.get("currency", "USD")

                table.add_row(
                    str(ret.get("id", "")),
                    ret.get("name", ret.get("title", "")),
                    ret.get("client_name", ""),
                    _format_currency(ret.get("monthly_amount", ret.get("monthly", 0)), currency),
                    format_duration(Decimal(str(ret.get("included_hours", 0)))),
                    f"[{style}]{status.capitalize()}[/{style}]",
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("show")
def show_retainer(
    retainer_id: str = typer.Argument(..., help="Retainer ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show retainer details including balance.

    Examples:
        ct invoice retainer show <retainer-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/invoices/retainers/{retainer_id}/")

        if output_json:
            print_json(data)
        else:
            currency = data.get("currency", "USD")
            status = data.get("status", "active")
            style = "green" if status == "active" else "dim"

            console.print()
            console.print(f"[bold]{data.get('name', '')}[/bold]")
            console.print(f"  ID:              {data.get('id', '')}")
            console.print(f"  Client:          {data.get('client_name', '')}")
            console.print(f"  Status:          [{style}]{status.capitalize()}[/{style}]")
            console.print(f"  Monthly Amount:  {_format_currency(data.get('monthly_amount', 0), currency)}")
            console.print(f"  Included Hours:  {data.get('included_hours', 0)}h")
            console.print(f"  Overage Rate:    {_format_currency(data.get('overage_rate', 0), currency)}/h")
            console.print(f"  Start Date:      {data.get('start_date', '')}")
            if data.get("end_date"):
                console.print(f"  End Date:        {data['end_date']}")

            # Balance info
            console.print()
            console.print("[bold]Balance[/bold]")
            console.print(f"  Total Deposited: {_format_currency(data.get('total_deposited', 0), currency)}")
            console.print(f"  Total Withdrawn: {_format_currency(data.get('total_withdrawn', 0), currency)}")
            console.print(f"  [bold]Available:     {_format_currency(data.get('balance', 0), currency)}[/bold]")
            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Retainer '{retainer_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("withdraw")
def retainer_withdraw(
    retainer_id: str = typer.Argument(..., help="Retainer ID to withdraw from."),
    invoice_id: str = typer.Option(..., "--invoice", "-i", help="Target invoice ID to apply credit to."),
    amount: str = typer.Option(..., "--amount", "-a", help="Amount to withdraw."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Notes for the withdrawal."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Withdraw from retainer balance to pay an invoice.

    Applies retainer credit to a standard invoice. The amount is deducted
    from the retainer balance and applied as a payment on the target invoice.

    Examples:
        ct invoice retainer withdraw <retainer-id> --invoice <invoice-id> --amount 500
        ct invoice retainer withdraw <retainer-id> -i <invoice-id> -a 1000 -n "March credit"
    """
    try:
        parsed_amount = Decimal(amount)
    except Exception:
        format_error(f"Invalid amount: '{amount}'. Provide a numeric value.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "invoice_id": invoice_id,
        "amount": str(parsed_amount),
    }
    if notes:
        payload["notes"] = notes

    try:
        data = client.post(f"/invoices/retainers/{retainer_id}/withdraw/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", invoice_id)
            retainer_name = data.get("retainer_name", retainer_id)
            format_success(
                f"Withdrew {_format_currency(parsed_amount)} from retainer "
                f'"{retainer_name}" and applied to invoice {inv_number}.'
            )
    except APIError as e:
        if e.status_code == 404:
            format_error("Retainer or invoice not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("withdrawals")
def list_withdrawals(
    retainer_id: str = typer.Argument(..., help="Retainer ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all withdrawals for a retainer.

    Examples:
        ct invoice retainer withdrawals <retainer-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/invoices/retainers/{retainer_id}/withdrawals/")
        results = data if isinstance(data, list) else data.get("results", [])

        if output_json:
            print_json(results)
        else:
            if not results:
                console.print("[dim]No withdrawals found for this retainer.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Invoice", width=14)
            table.add_column("Amount", justify="right", width=12)
            table.add_column("Date", width=12)
            table.add_column("Status", width=10)
            table.add_column("Notes", width=25)

            for wd in results:
                is_reversed = wd.get("reversed_at") is not None
                status_label = "[red]Reversed[/red]" if is_reversed else "[green]Active[/green]"
                created = wd.get("created_at", "")[:10] if wd.get("created_at") else ""

                table.add_row(
                    str(wd.get("id", "")),
                    wd.get("invoice_number", ""),
                    _format_currency(wd.get("amount", 0)),
                    created,
                    status_label,
                    wd.get("notes", "") or "",
                )

            console.print(table)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Retainer '{retainer_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("reverse-withdrawal")
def reverse_withdrawal(
    retainer_id: str = typer.Argument(..., help="Retainer ID."),
    withdrawal_id: str = typer.Option(..., "--withdrawal", "-w", help="Withdrawal ID to reverse."),
    reason: str = typer.Option(..., "--reason", "-r", help="Reason for reversal (required)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Reverse a retainer withdrawal.

    Returns the amount back to the retainer balance and adjusts the
    target invoice's payment accordingly.

    Examples:
        ct invoice retainer reverse-withdrawal <retainer-id> --withdrawal <id> --reason "Client renegotiation"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(
            f"/invoices/retainers/{retainer_id}/withdrawals/{withdrawal_id}/reverse/",
            data={"reason": reason},
        )

        if output_json:
            print_json(data)
        else:
            format_success(
                f"Withdrawal reversed. {_format_currency(data.get('amount', 0))} "
                f"returned to retainer balance."
            )
    except APIError as e:
        if e.status_code == 404:
            format_error("Retainer or withdrawal not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
