# Code Index MCP

基于 SQLite 的代码仓库索引 MCP 服务器

## 概述

Code Index MCP 是一个 MCP（Model Context Protocol）服务器，用于对代码仓库建立索引并提供强大的搜索能力。它使用 SQLite 存储索引数据，支持全文搜索（FTS5）、符号搜索和结构分析。

### 核心功能

- **代码索引**: 自动扫描代码仓库，提取文件、符号（函数、类、方法）和代码内容
- **全文搜索**: 基于 SQLite FTS5 的高速全文搜索
- **符号搜索**: 按名称搜索函数、类、方法等符号
- **可观测性**: 内置日志系统，记录所有工具调用和性能指标

## 快速开始

### 安装

```bash
pip install code-search-mcp
```

### 使用 MCP 客户端

配置你的 MCP 客户端（如 Claude Code）：

```json
{
  "mcpServers": {
    "code-index": {
      "command": "python",
      "args": ["-m", "code_search_mcp"]
    }
  }
}
```

### 基本使用

```python
from code_search_mcp import CodeIndexServer

server = CodeIndexServer()
```

## MCP 工具

本服务提供 8 个 MCP 工具：

### 1. index_repository

索引整个代码仓库。

```python
{
  "name": "index_repository",
  "arguments": {
    "repo_path": "/path/to/repo",
    "force_rebuild": false
  }
}
```

**参数**:
- `repo_path` (必填): 代码仓库路径
- `force_rebuild` (可选): 是否强制重建索引，默认 false

**返回**:
```python
{
  "success": true,
  "stats": {
    "files_indexed": 150,
    "symbols": 1200,
    "content_blocks": 5000,
    "elapsed_seconds": 2.5
  }
}
```

### 2. find_files

按文件名或路径搜索文件。

```python
{
  "name": "find_files",
  "arguments": {
    "query": "test",
    "extensions": [".py", ".js"],
    "limit": 20
  }
}
```

### 3. find_symbols

搜索代码符号（函数、类、方法等）。

```python
{
  "name": "find_symbols",
  "arguments": {
    "query": "calculate",
    "kind": "function",
    "limit": 20
  }
}
```

### 4. find_content

在代码内容中进行全文搜索。

```python
{
  "name": "find_content",
  "arguments": {
    "query": "def.*main",
    "regex": true,
    "file_pattern": "*.py",
    "limit": 20
  }
}
```

### 5. get_structure

获取单个文件的结构信息。

### 6. get_stats

获取索引统计信息。

### 7. get_logs

查询工具调用日志（可观测性）。

### 8. get_call_stats

获取工具调用统计信息。

## 支持的语言

- Python (.py)
- JavaScript (.js, .jsx)
- TypeScript (.ts, .tsx)
- Go (.go)
- Rust (.rs)
- Java (.java)
- C/C++ (.c, .cpp, .h, .hpp)
- Ruby (.rb)
- PHP (.php)
- Swift (.swift)
- Kotlin (.kt)
- Scala (.scala)
- Vue (.vue)
- Svelte (.svelte)

## CLI 命令

安装后可以使用 CLI 工具：

```bash
# 索引代码仓库
code-index index /path/to/repo

# 重建索引
code-index rebuild /path/to/repo

# 综合搜索
code-index search "query"

# 搜索文件
code-index files "query"

# 搜索符号
code-index symbols "query"

# 搜索内容
code-index content "query"

# 查看日志
code-index logs

# 查看统计
code-index stats

# 查看状态
code-index status

# 清理数据
code-index clean --all
```

## 开发

### 运行测试

```bash
pytest tests/ -v
```

### 代码检查

```bash
ruff check code_search_mcp/
```

## 许可证

MIT
