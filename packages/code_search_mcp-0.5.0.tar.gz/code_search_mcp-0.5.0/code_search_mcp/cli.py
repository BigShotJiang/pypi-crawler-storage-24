"""Code Index CLI - 命令行工具

使用方法:
    code-index index <path>          索引代码仓库
    code-index rebuild <path>        重建索引
    code-index search <query>        搜索文件/符号/内容
    code-index files <query>         搜索文件
    code-index symbols <query>       搜索符号
    code-index content <query>       搜索内容
    code-index logs                 查看日志
    code-index stats                查看统计
    code-index status               查看索引状态
    code-index clean                清理索引/日志
"""
import argparse
import os
import sys

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from code_search_mcp.database import Database
from code_search_mcp.indexer import Indexer
from code_search_mcp.logger import Logger


def cmd_index(args):
    """索引命令（增量）"""
    db = Database()
    logger = Logger()
    indexer = Indexer(db)

    print(f"索引仓库: {args.path}")
    result = indexer.index_repository(args.path, force_rebuild=False, verbose=True)

    stats = result.get("stats", {})
    logger.log("index_cli", stats.get("elapsed_seconds", 0) * 1000,
               stats.get("files_indexed", 0),
               f'{{"path": "{args.path}", "incremental": true}}', True)

    # 显示增量状态
    if result.get("is_incremental"):
        print("\n✓ 增量索引完成")
        print(f"  新增/更新: {stats.get('files_indexed', 0)}")
        print(f"  跳过(未变更): {stats.get('files_skipped', 0)}")
        print(f"  删除: {stats.get('files_deleted', 0)}")
    else:
        print("\n✓ 索引完成")
        print(f"  文件: {stats.get('files_indexed', 0)}")
    print(f"  符号: {stats.get('symbols', 0)}")
    print(f"  耗时: {stats.get('elapsed_seconds', 0)}s")


def cmd_rebuild(args):
    """重建索引命令"""
    db = Database()
    logger = Logger()
    indexer = Indexer(db)

    print(f"重建索引: {args.path}")
    result = indexer.index_repository(args.path, force_rebuild=True, verbose=True)

    stats = result.get("stats", {})
    logger.log("rebuild_cli", stats.get("elapsed_seconds", 0) * 1000,
               stats.get("files_indexed", 0),
               f'{{"path": "{args.path}", "force": true}}', True)

    print("\n✓ 全量索引完成")
    print(f"  文件: {stats.get('files_indexed', 0)}")
    print(f"  符号: {stats.get('symbols', 0)}")
    print(f"  耗时: {stats.get('elapsed_seconds', 0)}s")
    logger = Logger()
    indexer = Indexer(db)

    print(f"重建索引: {args.path}")
    result = indexer.index_repository(args.path, force_rebuild=True)
    logger.log("rebuild_cli", 0, result.get("stats", {}).get("files", 0),
               f'{{"path": "{args.path}", "force": true}}', True)

    print("✓ 重建完成")
    print(f"  文件: {result['stats']['files']}")
    print(f"  符号: {result['stats']['symbols']}")
    print(f"  耗时: {result['stats']['elapsed_seconds']}s")


def cmd_files(args):
    """搜索文件命令"""
    db = Database()

    results = db.find_files(query=args.query, limit=args.limit or 20)

    print(f"搜索文件: '{args.query}'")
    print(f"找到 {len(results)} 个结果:\n")

    for f in results:
        print(f"  {f.path}")


def cmd_symbols(args):
    """搜索符号命令"""
    db = Database()

    results = db.find_symbols(query=args.query, kind=args.kind, limit=args.limit or 20)

    print(f"搜索符号: '{args.query}'" + (f" (类型: {args.kind})" if args.kind else ""))
    print(f"找到 {len(results)} 个结果:\n")

    for s in results:
        print(f"  {s['name']} ({s['kind']}) @ {s['file_path']}:{s['line_start']}")


def cmd_content(args):
    """搜索内容命令"""
    db = Database()

    results = db.find_content(query=args.query, regex=args.regex, limit=args.limit or 20)

    print(f"搜索内容: '{args.query}'" + (" (正则)" if args.regex else ""))
    print(f"找到 {len(results)} 个结果:\n")

    for m in results:
        preview = m['content'][:60].replace('\n', ' ')
        print(f"  {m['file_path']}:{m['line_number']}")
        print(f"    {preview}...")
        print()


def cmd_search(args):
    """综合搜索命令"""
    db = Database()
    query = args.query
    limit = args.limit or 10

    print(f"综合搜索: '{query}'")
    print("=" * 50)

    # 搜索文件
    files = db.find_files(query=query, limit=limit)
    if files:
        print(f"\n📁 文件 ({len(files)}):")
        for f in files[:5]:
            print(f"   {f.path}")

    # 搜索符号
    symbols = db.find_symbols(query=query, limit=limit)
    if symbols:
        print(f"\n🔍 符号 ({len(symbols)}):")
        for s in symbols[:5]:
            print(f"   {s['name']} @ {s['file_path']}:{s['line_start']}")

    # 搜索内容
    content = db.find_content(query=query, limit=limit)
    if content:
        print(f"\n📝 内容 ({len(content)}):")
        for c in content[:5]:
            print(f"   {c['file_path']}:{c['line_number']}")
            print(f"   {c['content'][:50]}...")


def cmd_logs(args):
    """查看日志命令"""
    logger = Logger()

    # 参数
    tool_name = args.tool or None
    success = args.errors_only if args.errors_only else (None if args.success_only is None else True)
    limit = args.limit or 20

    logs = logger.get_logs(tool_name=tool_name, success=success, limit=limit)

    print(f"日志 ({len(logs)} 条)")
    print("=" * 70)

    for log in logs:
        status = "✓" if log['success'] else "✗"
        level = log['level']
        print(f"{status} [{level:7}] {log['tool_name']:20} {log['duration_ms']:8.2f}ms")

        if not log['success']:
            print(f"   错误: {log['error_message'][:50]}")
        elif args.verbose:
            print(f"   查询: {log['query'][:50]}")


def cmd_stats(args):
    """查看统计命令"""
    logger = Logger()

    stats = logger.get_stats()

    print("调用统计")
    print("=" * 40)
    print(f"总调用:    {stats['total_calls']}")
    print(f"成功:      {stats['success_count']}")
    print(f"失败:      {stats['error_count']}")
    print(f"成功率:    {stats['success_rate']}%")
    print(f"平均耗时:  {stats['avg_duration_ms']:.2f}ms")

    if stats['by_tool']:
        print("\n按工具统计:")
        print("-" * 60)
        print(f"{'工具':<20} {'次数':>6} {'平均(ms)':>12} {'最大(ms)':>12}")
        for t in stats['by_tool']:
            print(f"{t['tool_name']:<20} {t['count']:>6} {t['avg_duration']:>12.2f} {t['max_duration']:>12.2f}")


def cmd_status(args):
    """查看状态命令"""
    db = Database()
    logger = Logger()

    # 索引统计
    idx_stats = db.get_stats()

    print("索引状态")
    print("=" * 40)
    print(f"文件:     {idx_stats['files']}")
    print(f"符号:     {idx_stats['symbols']}")
    print(f"内容块:   {idx_stats['content_blocks']}")

    # 日志统计
    log_stats = logger.get_stats()
    print("\n调用统计")
    print("-" * 20)
    print(f"总调用:   {log_stats['total_calls']}")
    print(f"错误:     {log_stats['error_count']}")

    # 数据库路径
    print("\n数据库路径")
    print("-" * 20)
    print(f"索引:     {db.db_path}")
    print(f"日志:     {logger.db_path}")


def cmd_clean(args):
    """清理命令"""
    db = Database()
    logger = Logger()

    if args.all:
        # 清理所有
        confirm = input("确认清理所有索引和日志? (y/n): ")
        if confirm.lower() == 'y':
            db.clear_all()
            logger.clear_old_logs(days=0)
            print("✓ 已清理所有索引和日志")
    elif args.logs:
        # 清理日志
        days = args.logs if args.logs > 0 else 0
        logger.clear_old_logs(days=days)
        print(f"✓ 已清理 {days} 天前的日志")
    elif args.index:
        # 清理索引
        confirm = input("确认清理所有索引? (y/n): ")
        if confirm.lower() == 'y':
            db.clear_all()
            print("✓ 已清理所有索引")


def main():
    """主入口"""
    parser = argparse.ArgumentParser(
        description="Code Index CLI - 代码索引命令行工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # index 命令
    p_index = subparsers.add_parser("index", help="索引代码仓库")
    p_index.add_argument("path", help="代码仓库路径")
    p_index.set_defaults(func=cmd_index)

    # rebuild 命令
    p_rebuild = subparsers.add_parser("rebuild", help="重建索引")
    p_rebuild.add_argument("path", help="代码仓库路径")
    p_rebuild.set_defaults(func=cmd_rebuild)

    # search 命令
    p_search = subparsers.add_parser("search", help="综合搜索")
    p_search.add_argument("query", help="搜索关键词")
    p_search.add_argument("-l", "--limit", type=int, help="结果数量限制")
    p_search.set_defaults(func=cmd_search)

    # files 命令
    p_files = subparsers.add_parser("files", help="搜索文件")
    p_files.add_argument("query", help="搜索关键词")
    p_files.add_argument("-l", "--limit", type=int, help="结果数量限制")
    p_files.set_defaults(func=cmd_files)

    # symbols 命令
    p_symbols = subparsers.add_parser("symbols", help="搜索符号")
    p_symbols.add_argument("query", help="搜索关键词")
    p_symbols.add_argument("-k", "--kind", help="符号类型 (function/class/method)")
    p_symbols.add_argument("-l", "--limit", type=int, help="结果数量限制")
    p_symbols.set_defaults(func=cmd_symbols)

    # content 命令
    p_content = subparsers.add_parser("content", help="搜索内容")
    p_content.add_argument("query", help="搜索关键词")
    p_content.add_argument("-r", "--regex", action="store_true", help="使用正则表达式")
    p_content.add_argument("-l", "--limit", type=int, help="结果数量限制")
    p_content.set_defaults(func=cmd_content)

    # logs 命令
    p_logs = subparsers.add_parser("logs", help="查看日志")
    p_logs.add_argument("-t", "--tool", help="工具名称过滤")
    p_logs.add_argument("-e", "--errors-only", action="store_true", help="只显示错误")
    p_logs.add_argument("-s", "--success-only", action="store_true", help="只显示成功")
    p_logs.add_argument("-l", "--limit", type=int, help="结果数量限制")
    p_logs.add_argument("-v", "--verbose", action="store_true", help="显示详细信息")
    p_logs.set_defaults(func=cmd_logs)

    # stats 命令
    p_stats = subparsers.add_parser("stats", help="查看统计")
    p_stats.set_defaults(func=cmd_stats)

    # status 命令
    p_status = subparsers.add_parser("status", help="查看状态")
    p_status.set_defaults(func=cmd_status)

    # clean 命令
    p_clean = subparsers.add_parser("clean", help="清理数据")
    p_clean.add_argument("-a", "--all", action="store_true", help="清理所有索引和日志")
    p_clean.add_argument("-i", "--index", action="store_true", help="清理索引")
    p_clean.add_argument("-l", "--logs", type=int, nargs="?", const=7, default=0, help="清理日志 (天数，0=全部)")
    p_clean.set_defaults(func=cmd_clean)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return

    args.func(args)


if __name__ == "__main__":
    main()
