"""Input sanitizer — defense-in-depth for all user-facing inputs.

Validates and sanitizes user inputs before they reach any subsystem.
Catches common attack vectors, malformed data, and encoding issues.

Features:
    1. Unicode normalization and control character stripping
    2. Path traversal prevention
    3. Shell metacharacter neutralization
    4. SQL injection pattern detection
    5. XSS pattern detection
    6. Maximum length enforcement
    7. Encoding validation (UTF-8, reject invalid sequences)
    8. Null byte injection prevention
    9. Configurable severity levels
    10. Batch sanitization for message arrays

Usage::

    sanitizer = InputSanitizer()
    result = sanitizer.sanitize(user_input)
    if result.is_safe:
        process(result.clean_text)
    else:
        warn(result.issues)

"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from enum import Enum

import structlog

logger = structlog.get_logger(__name__)


class Severity(Enum):
    """Severity level for detected issues."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class IssueType(Enum):
    """Types of sanitization issues."""

    CONTROL_CHARS = "control_chars"
    NULL_BYTES = "null_bytes"
    PATH_TRAVERSAL = "path_traversal"
    SHELL_METACHAR = "shell_metachar"
    SQL_INJECTION = "sql_injection"
    XSS_PATTERN = "xss_pattern"
    ENCODING_ERROR = "encoding_error"
    EXCESSIVE_LENGTH = "excessive_length"
    UNICODE_CONFUSABLE = "unicode_confusable"
    INVISIBLE_CHARS = "invisible_chars"


@dataclass
class SanitizationIssue:
    """A detected sanitization issue.

    Attributes:
        issue_type: Category of the issue.
        severity: How serious the issue is.
        description: Human-readable description.
        position: Character position where found (or -1).
        original: The problematic substring.
        replacement: What it was replaced with.
    """

    issue_type: IssueType
    severity: Severity
    description: str
    position: int = -1
    original: str = ""
    replacement: str = ""


@dataclass
class SanitizationResult:
    """Result of input sanitization.

    Attributes:
        clean_text: Sanitized text.
        original_text: Original input.
        is_safe: Whether the input was already safe (no issues found).
        issues: List of detected issues.
        modifications_count: Number of modifications made.
    """

    clean_text: str
    original_text: str
    is_safe: bool
    issues: list[SanitizationIssue] = field(default_factory=list)
    modifications_count: int = 0

    @property
    def has_critical(self) -> bool:
        """Whether any critical issues were found."""
        return any(i.severity == Severity.CRITICAL for i in self.issues)


@dataclass
class SanitizerConfig:
    """Sanitizer configuration.

    Attributes:
        max_length: Maximum allowed input length (0 = unlimited).
        strip_control_chars: Whether to remove control characters.
        normalize_unicode: Whether to normalize Unicode to NFC.
        detect_path_traversal: Whether to check for path traversal.
        detect_shell_metachar: Whether to check shell metacharacters.
        detect_sql_injection: Whether to check SQL injection patterns.
        detect_xss: Whether to check XSS patterns.
        reject_null_bytes: Whether to remove null bytes.
        strip_invisible: Whether to remove invisible Unicode characters.
    """

    max_length: int = 100000
    strip_control_chars: bool = True
    normalize_unicode: bool = True
    detect_path_traversal: bool = True
    detect_shell_metachar: bool = True
    detect_sql_injection: bool = True
    detect_xss: bool = True
    reject_null_bytes: bool = True
    strip_invisible: bool = True


# Detection patterns
_PATH_TRAVERSAL_RE = re.compile(r"\.\.[/\\]")
_NULL_BYTE_RE = re.compile(r"\x00")
_SHELL_META_RE = re.compile(r"[;|&`$(){}]")
_SQL_INJECTION_PATTERNS = [
    re.compile(r"('\s*(OR|AND)\s+')", re.IGNORECASE),
    re.compile(r"(UNION\s+SELECT)", re.IGNORECASE),
    re.compile(r"(DROP\s+TABLE)", re.IGNORECASE),
    re.compile(r"(INSERT\s+INTO)", re.IGNORECASE),
    re.compile(r"(DELETE\s+FROM)", re.IGNORECASE),
    re.compile(r"(;\s*--)", re.IGNORECASE),
    re.compile(r"(1\s*=\s*1)", re.IGNORECASE),
]
_XSS_PATTERNS = [
    re.compile(r"<script[^>]*>", re.IGNORECASE),
    re.compile(r"javascript\s*:", re.IGNORECASE),
    re.compile(r"on\w+\s*=", re.IGNORECASE),
    re.compile(r"<iframe[^>]*>", re.IGNORECASE),
    re.compile(r"<object[^>]*>", re.IGNORECASE),
    re.compile(r"<embed[^>]*>", re.IGNORECASE),
    re.compile(r"eval\s*\(", re.IGNORECASE),
    re.compile(r"document\.(cookie|location|write)", re.IGNORECASE),
]
# Unicode invisible characters (zero-width, direction overrides, etc.)
_INVISIBLE_CHARS = {
    "\u200b",  # Zero-width space
    "\u200c",  # Zero-width non-joiner
    "\u200d",  # Zero-width joiner
    "\u200e",  # Left-to-right mark
    "\u200f",  # Right-to-left mark
    "\u2060",  # Word joiner
    "\u2061",  # Function application
    "\u2062",  # Invisible times
    "\u2063",  # Invisible separator
    "\u2064",  # Invisible plus
    "\ufeff",  # Zero-width no-break space (BOM)
    "\u202a",  # Left-to-right embedding
    "\u202b",  # Right-to-left embedding
    "\u202c",  # Pop directional formatting
    "\u202d",  # Left-to-right override
    "\u202e",  # Right-to-left override
}
# Control characters (C0 + C1 except tab, newline, carriage return)
_CONTROL_CHAR_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")


class InputSanitizer:
    """Defense-in-depth input sanitizer.

    Args:
        config: Sanitizer configuration.
    """

    def __init__(self, config: SanitizerConfig | None = None) -> None:
        self._config = config or SanitizerConfig()
        self._stats = _SanitizerStats()

    def sanitize(self, text: str) -> SanitizationResult:
        """Sanitize a text input.

        Args:
            text: Raw input text.

        Returns:
            SanitizationResult with clean text and any issues found.
        """
        if not text:
            return SanitizationResult(
                clean_text="", original_text="", is_safe=True,
            )

        original = text
        issues: list[SanitizationIssue] = []
        clean = text

        # 1. Null byte removal (always first)
        if self._config.reject_null_bytes:
            clean, null_issues = self._remove_null_bytes(clean)
            issues.extend(null_issues)

        # 2. Control character stripping
        if self._config.strip_control_chars:
            clean, ctrl_issues = self._strip_control_chars(clean)
            issues.extend(ctrl_issues)

        # 3. Unicode normalization
        if self._config.normalize_unicode:
            clean = unicodedata.normalize("NFC", clean)

        # 4. Invisible character removal
        if self._config.strip_invisible:
            clean, invis_issues = self._strip_invisible_chars(clean)
            issues.extend(invis_issues)

        # 5. Length enforcement
        if self._config.max_length > 0 and len(clean) > self._config.max_length:
            issues.append(SanitizationIssue(
                issue_type=IssueType.EXCESSIVE_LENGTH,
                severity=Severity.WARNING,
                description=f"Input truncated from {len(clean)} to {self._config.max_length} chars",
            ))
            clean = clean[:self._config.max_length]

        # 6. Detection-only checks (don't modify, just flag)
        if self._config.detect_path_traversal:
            issues.extend(self._detect_path_traversal(clean))

        if self._config.detect_shell_metachar:
            issues.extend(self._detect_shell_meta(clean))

        if self._config.detect_sql_injection:
            issues.extend(self._detect_sql_injection(clean))

        if self._config.detect_xss:
            issues.extend(self._detect_xss(clean))

        is_safe = len(issues) == 0
        modifications = sum(1 for i in issues if i.replacement)

        self._stats.total_sanitized += 1
        if not is_safe:
            self._stats.total_issues += len(issues)
            if any(i.severity == Severity.CRITICAL for i in issues):
                self._stats.total_critical += 1

        return SanitizationResult(
            clean_text=clean,
            original_text=original,
            is_safe=is_safe,
            issues=issues,
            modifications_count=modifications,
        )

    def sanitize_messages(
        self, messages: list[dict[str, str]],
    ) -> list[SanitizationResult]:
        """Sanitize a list of chat messages.

        Args:
            messages: List of {role, content} dicts.

        Returns:
            List of SanitizationResult for each message's content.
        """
        results: list[SanitizationResult] = []
        for msg in messages:
            content = msg.get("content", "")
            results.append(self.sanitize(content))
        return results

    def is_safe(self, text: str) -> bool:
        """Quick check if text is safe (no modifications needed).

        Args:
            text: Input text.

        Returns:
            True if text passes all checks without issues.
        """
        return self.sanitize(text).is_safe

    def get_stats(self) -> dict[str, int]:
        """Get sanitization statistics."""
        return {
            "total_sanitized": self._stats.total_sanitized,
            "total_issues": self._stats.total_issues,
            "total_critical": self._stats.total_critical,
        }

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _remove_null_bytes(self, text: str) -> tuple[str, list[SanitizationIssue]]:
        """Remove null bytes."""
        issues: list[SanitizationIssue] = []
        matches = list(_NULL_BYTE_RE.finditer(text))
        if matches:
            issues.append(SanitizationIssue(
                issue_type=IssueType.NULL_BYTES,
                severity=Severity.CRITICAL,
                description=f"Found {len(matches)} null byte(s)",
                position=matches[0].start(),
                original="\\x00",
                replacement="",
            ))
            text = _NULL_BYTE_RE.sub("", text)
        return text, issues

    def _strip_control_chars(self, text: str) -> tuple[str, list[SanitizationIssue]]:
        """Strip control characters except tab, newline, CR."""
        issues: list[SanitizationIssue] = []
        matches = list(_CONTROL_CHAR_RE.finditer(text))
        if matches:
            issues.append(SanitizationIssue(
                issue_type=IssueType.CONTROL_CHARS,
                severity=Severity.WARNING,
                description=f"Stripped {len(matches)} control character(s)",
                position=matches[0].start(),
                original=repr(matches[0].group()),
                replacement="",
            ))
            text = _CONTROL_CHAR_RE.sub("", text)
        return text, issues

    def _strip_invisible_chars(self, text: str) -> tuple[str, list[SanitizationIssue]]:
        """Strip invisible Unicode characters."""
        issues: list[SanitizationIssue] = []
        found = [c for c in text if c in _INVISIBLE_CHARS]
        if found:
            issues.append(SanitizationIssue(
                issue_type=IssueType.INVISIBLE_CHARS,
                severity=Severity.WARNING,
                description=f"Stripped {len(found)} invisible Unicode character(s)",
                original=repr(found[0]),
                replacement="",
            ))
            text = "".join(c for c in text if c not in _INVISIBLE_CHARS)
        return text, issues

    def _detect_path_traversal(self, text: str) -> list[SanitizationIssue]:
        """Detect path traversal patterns."""
        issues: list[SanitizationIssue] = []
        for match in _PATH_TRAVERSAL_RE.finditer(text):
            issues.append(SanitizationIssue(
                issue_type=IssueType.PATH_TRAVERSAL,
                severity=Severity.CRITICAL,
                description="Path traversal pattern detected",
                position=match.start(),
                original=match.group(),
            ))
        return issues

    def _detect_shell_meta(self, text: str) -> list[SanitizationIssue]:
        """Detect shell metacharacters."""
        issues: list[SanitizationIssue] = []
        found_chars: set[str] = set()
        for match in _SHELL_META_RE.finditer(text):
            char = match.group()
            if char not in found_chars:
                found_chars.add(char)
                issues.append(SanitizationIssue(
                    issue_type=IssueType.SHELL_METACHAR,
                    severity=Severity.WARNING,
                    description=f"Shell metacharacter '{char}' detected",
                    position=match.start(),
                    original=char,
                ))
        return issues

    def _detect_sql_injection(self, text: str) -> list[SanitizationIssue]:
        """Detect SQL injection patterns."""
        issues: list[SanitizationIssue] = []
        for pattern in _SQL_INJECTION_PATTERNS:
            match = pattern.search(text)
            if match:
                issues.append(SanitizationIssue(
                    issue_type=IssueType.SQL_INJECTION,
                    severity=Severity.CRITICAL,
                    description=f"SQL injection pattern: {match.group()[:50]}",
                    position=match.start(),
                    original=match.group()[:50],
                ))
        return issues

    def _detect_xss(self, text: str) -> list[SanitizationIssue]:
        """Detect XSS patterns."""
        issues: list[SanitizationIssue] = []
        for pattern in _XSS_PATTERNS:
            match = pattern.search(text)
            if match:
                issues.append(SanitizationIssue(
                    issue_type=IssueType.XSS_PATTERN,
                    severity=Severity.CRITICAL,
                    description=f"XSS pattern: {match.group()[:50]}",
                    position=match.start(),
                    original=match.group()[:50],
                ))
        return issues


@dataclass
class _SanitizerStats:
    """Internal stats tracker."""

    total_sanitized: int = 0
    total_issues: int = 0
    total_critical: int = 0
