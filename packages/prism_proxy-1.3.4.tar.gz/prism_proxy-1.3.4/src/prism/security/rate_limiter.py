"""Token bucket rate limiter with per-provider and per-model limits.

Prevents exceeding provider rate limits by implementing a token bucket
algorithm with configurable refill rates and burst capacity.

Features:
    1. Per-provider rate limiting (RPM and TPM)
    2. Per-model rate limiting
    3. Token bucket with burst capacity
    4. Adaptive rate adjustment based on 429 responses
    5. Fair queuing when multiple requests compete
    6. Rate limit status exposure for routing decisions

Usage::

    limiter = RateLimiter()
    limiter.configure("openai", rpm=500, tpm=30000)
    if limiter.acquire("openai", tokens=500):
        # Proceed with request
        ...
    else:
        wait_time = limiter.time_until_available("openai", tokens=500)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class RateLimitConfig:
    """Rate limit configuration for a provider/model.

    Attributes:
        name: Provider or model identifier.
        requests_per_minute: Maximum requests per minute.
        tokens_per_minute: Maximum tokens per minute.
        burst_multiplier: Burst capacity as a multiplier of the per-minute rate.
        max_concurrent: Maximum concurrent requests.
    """

    name: str
    requests_per_minute: int = 60
    tokens_per_minute: int = 40000
    burst_multiplier: float = 1.5
    max_concurrent: int = 10


@dataclass
class BucketState:
    """State of a token bucket.

    Attributes:
        tokens: Current available tokens.
        capacity: Maximum tokens (burst capacity).
        refill_rate: Tokens added per second.
        last_refill: Last refill timestamp.
        total_acquired: Total tokens acquired.
        total_rejected: Total tokens rejected.
        last_rejection: Timestamp of last rejection.
    """

    tokens: float
    capacity: float
    refill_rate: float
    last_refill: float = field(default_factory=time.monotonic)
    total_acquired: int = 0
    total_rejected: int = 0
    last_rejection: float = 0.0


@dataclass
class RateLimitStatus:
    """Current rate limit status for a provider.

    Attributes:
        name: Provider/model name.
        rpm_available: Remaining requests this minute.
        rpm_capacity: Total RPM capacity.
        tpm_available: Remaining tokens this minute.
        tpm_capacity: Total TPM capacity.
        concurrent_active: Current concurrent requests.
        concurrent_max: Maximum concurrent requests.
        utilization_pct: Overall utilization percentage.
        is_limited: Whether currently rate limited.
        time_until_available: Seconds until a request can proceed (0 if available).
    """

    name: str
    rpm_available: float
    rpm_capacity: float
    tpm_available: float
    tpm_capacity: float
    concurrent_active: int
    concurrent_max: int
    utilization_pct: float
    is_limited: bool
    time_until_available: float


# Default rate limits for major providers
_DEFAULT_LIMITS: dict[str, dict[str, int]] = {
    "openai": {"rpm": 500, "tpm": 30000},
    "anthropic": {"rpm": 50, "tpm": 40000},
    "google": {"rpm": 60, "tpm": 32000},
    "deepseek": {"rpm": 60, "tpm": 60000},
    "groq": {"rpm": 30, "tpm": 15000},
    "mistral": {"rpm": 60, "tpm": 50000},
    "ollama": {"rpm": 1000, "tpm": 1000000},  # Local, effectively unlimited
}


class RateLimiter:
    """Token bucket rate limiter with per-provider limits.

    Uses the token bucket algorithm for smooth rate limiting with burst
    capacity.  Separate buckets for RPM and TPM per provider.
    """

    def __init__(self) -> None:
        self._configs: dict[str, RateLimitConfig] = {}
        self._rpm_buckets: dict[str, BucketState] = {}
        self._tpm_buckets: dict[str, BucketState] = {}
        self._concurrent: dict[str, int] = {}
        self._backoff_until: dict[str, float] = {}

        # Initialize defaults
        for provider, limits in _DEFAULT_LIMITS.items():
            self.configure(
                provider,
                rpm=limits["rpm"],
                tpm=limits["tpm"],
            )

    def configure(
        self,
        name: str,
        rpm: int = 60,
        tpm: int = 40000,
        burst_multiplier: float = 1.5,
        max_concurrent: int = 10,
    ) -> None:
        """Configure rate limits for a provider or model.

        Args:
            name: Provider/model identifier.
            rpm: Requests per minute limit.
            tpm: Tokens per minute limit.
            burst_multiplier: Burst capacity multiplier.
            max_concurrent: Maximum concurrent requests.
        """
        config = RateLimitConfig(
            name=name,
            requests_per_minute=rpm,
            tokens_per_minute=tpm,
            burst_multiplier=burst_multiplier,
            max_concurrent=max_concurrent,
        )
        self._configs[name] = config

        rpm_capacity = rpm * burst_multiplier
        tpm_capacity = tpm * burst_multiplier

        self._rpm_buckets[name] = BucketState(
            tokens=rpm_capacity,
            capacity=rpm_capacity,
            refill_rate=rpm / 60.0,  # Per second
        )
        self._tpm_buckets[name] = BucketState(
            tokens=tpm_capacity,
            capacity=tpm_capacity,
            refill_rate=tpm / 60.0,
        )
        self._concurrent.setdefault(name, 0)

    def acquire(self, name: str, tokens: int = 1) -> bool:
        """Try to acquire rate limit tokens.

        Args:
            name: Provider/model name.
            tokens: Number of tokens to acquire (for TPM bucket).

        Returns:
            True if acquired, False if rate limited.
        """
        if name not in self._configs:
            return True  # No config = no limit

        # Check backoff
        now = time.monotonic()
        backoff_until = self._backoff_until.get(name, 0)
        if now < backoff_until:
            return False

        # Check concurrent limit
        config = self._configs[name]
        if self._concurrent.get(name, 0) >= config.max_concurrent:
            return False

        # Refill buckets
        rpm_bucket = self._rpm_buckets[name]
        tpm_bucket = self._tpm_buckets[name]
        self._refill(rpm_bucket, now)
        self._refill(tpm_bucket, now)

        # Check RPM
        if rpm_bucket.tokens < 1:
            rpm_bucket.total_rejected += 1
            rpm_bucket.last_rejection = now
            return False

        # Check TPM
        if tpm_bucket.tokens < tokens:
            tpm_bucket.total_rejected += 1
            tpm_bucket.last_rejection = now
            return False

        # Acquire
        rpm_bucket.tokens -= 1
        rpm_bucket.total_acquired += 1
        tpm_bucket.tokens -= tokens
        tpm_bucket.total_acquired += tokens
        self._concurrent[name] = self._concurrent.get(name, 0) + 1

        return True

    def release(self, name: str) -> None:
        """Release a concurrent request slot.

        Call this when a request completes.

        Args:
            name: Provider/model name.
        """
        current = self._concurrent.get(name, 0)
        if current > 0:
            self._concurrent[name] = current - 1

    def record_rate_limit(self, name: str, retry_after: float = 0) -> None:
        """Record a 429 rate limit response.

        Adapts the rate limiter by reducing the bucket and applying backoff.

        Args:
            name: Provider/model name.
            retry_after: Retry-After header value in seconds.
        """
        now = time.monotonic()

        # Apply backoff
        backoff = max(retry_after, 5.0)
        self._backoff_until[name] = now + backoff

        # Reduce bucket capacity by 20%
        if name in self._rpm_buckets:
            bucket = self._rpm_buckets[name]
            bucket.capacity *= 0.8
            bucket.tokens = min(bucket.tokens, bucket.capacity)

        if name in self._tpm_buckets:
            bucket = self._tpm_buckets[name]
            bucket.capacity *= 0.8
            bucket.tokens = min(bucket.tokens, bucket.capacity)

        logger.warning(
            "rate_limit_recorded",
            provider=name,
            backoff_s=backoff,
        )

    def time_until_available(self, name: str, tokens: int = 1) -> float:
        """Estimate time until a request can proceed.

        Args:
            name: Provider/model name.
            tokens: Tokens needed.

        Returns:
            Estimated seconds until available (0 if available now).
        """
        if name not in self._configs:
            return 0.0

        now = time.monotonic()

        # Check backoff
        backoff_until = self._backoff_until.get(name, 0)
        if now < backoff_until:
            return backoff_until - now

        rpm_bucket = self._rpm_buckets[name]
        tpm_bucket = self._tpm_buckets[name]
        self._refill(rpm_bucket, now)
        self._refill(tpm_bucket, now)

        rpm_wait = 0.0
        if rpm_bucket.tokens < 1:
            needed = 1 - rpm_bucket.tokens
            rpm_wait = needed / max(rpm_bucket.refill_rate, 0.001)

        tpm_wait = 0.0
        if tpm_bucket.tokens < tokens:
            needed = tokens - tpm_bucket.tokens
            tpm_wait = needed / max(tpm_bucket.refill_rate, 0.001)

        return max(rpm_wait, tpm_wait)

    def get_status(self, name: str) -> RateLimitStatus:
        """Get current rate limit status for a provider.

        Args:
            name: Provider/model name.

        Returns:
            RateLimitStatus with current state.
        """
        if name not in self._configs:
            return RateLimitStatus(
                name=name,
                rpm_available=0, rpm_capacity=0,
                tpm_available=0, tpm_capacity=0,
                concurrent_active=0, concurrent_max=0,
                utilization_pct=0, is_limited=False,
                time_until_available=0,
            )

        config = self._configs[name]
        now = time.monotonic()

        rpm_bucket = self._rpm_buckets[name]
        tpm_bucket = self._tpm_buckets[name]
        self._refill(rpm_bucket, now)
        self._refill(tpm_bucket, now)

        concurrent = self._concurrent.get(name, 0)

        rpm_util = 1 - (rpm_bucket.tokens / max(rpm_bucket.capacity, 1))
        tpm_util = 1 - (tpm_bucket.tokens / max(tpm_bucket.capacity, 1))
        utilization = max(rpm_util, tpm_util) * 100

        is_limited = (
            rpm_bucket.tokens < 1
            or tpm_bucket.tokens < 1
            or concurrent >= config.max_concurrent
            or time.monotonic() < self._backoff_until.get(name, 0)
        )

        return RateLimitStatus(
            name=name,
            rpm_available=round(rpm_bucket.tokens, 1),
            rpm_capacity=round(rpm_bucket.capacity, 1),
            tpm_available=round(tpm_bucket.tokens, 0),
            tpm_capacity=round(tpm_bucket.capacity, 0),
            concurrent_active=concurrent,
            concurrent_max=config.max_concurrent,
            utilization_pct=round(utilization, 1),
            is_limited=is_limited,
            time_until_available=self.time_until_available(name),
        )

    def get_all_status(self) -> dict[str, RateLimitStatus]:
        """Get rate limit status for all configured providers."""
        return {name: self.get_status(name) for name in self._configs}

    def get_least_loaded(self, providers: list[str]) -> str | None:
        """Get the least loaded provider from a list.

        Args:
            providers: List of provider names to consider.

        Returns:
            Name of least loaded provider, or None if all limited.
        """
        best_name: str | None = None
        best_util = float("inf")

        for name in providers:
            status = self.get_status(name)
            if not status.is_limited and status.utilization_pct < best_util:
                best_util = status.utilization_pct
                best_name = name

        return best_name

    def reset(self, name: str | None = None) -> None:
        """Reset rate limit state.

        Args:
            name: Specific provider to reset, or None for all.
        """
        if name:
            if name in self._configs:
                config = self._configs[name]
                self.configure(
                    name,
                    rpm=config.requests_per_minute,
                    tpm=config.tokens_per_minute,
                    burst_multiplier=config.burst_multiplier,
                    max_concurrent=config.max_concurrent,
                )
            self._backoff_until.pop(name, None)
            self._concurrent[name] = 0
        else:
            for n in list(self._configs):
                self.reset(n)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _refill(self, bucket: BucketState, now: float) -> None:
        """Refill a token bucket based on elapsed time."""
        elapsed = now - bucket.last_refill
        if elapsed <= 0:
            return

        added = elapsed * bucket.refill_rate
        bucket.tokens = min(bucket.capacity, bucket.tokens + added)
        bucket.last_refill = now
