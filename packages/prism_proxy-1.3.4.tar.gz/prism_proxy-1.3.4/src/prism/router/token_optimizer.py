"""Adaptive token budget optimizer — minimize waste without truncation.

Learns optimal ``max_tokens`` settings per model and task type by tracking
the gap between allocated and actually-used tokens.  An EWMA (exponential
weighted moving average) smooths the signal so that the optimizer adapts
to shifting usage patterns without overreacting to outliers.

A configurable *headroom factor* (default 1.2x) ensures the recommended
budget sits comfortably above the EWMA estimate, reducing the risk of
truncation even when usage spikes.

Data is kept entirely in-memory — callers can persist/restore by
serialising ``TokenBudgetOptimizer.export_state()`` and feeding it back
via ``TokenBudgetOptimizer.import_state()``.
"""

from __future__ import annotations

import bisect
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# EWMA smoothing factor — higher = more weight on recent observations.
_DEFAULT_ALPHA: float = 0.15

# Default safety multiplier applied to the EWMA estimate.
_DEFAULT_HEADROOM: float = 1.2

# Minimum observations before a recommendation is considered trustworthy.
_MIN_SAMPLES: int = 5

# Maximum per-(model, task_type) history length before oldest entries are
# evicted.  Keeps memory bounded while retaining enough data for accurate
# percentiles.
_MAX_HISTORY: int = 500

# Hard floor — never recommend fewer tokens than this.
_ABSOLUTE_MIN_TOKENS: int = 64

# Default budget profiles per task type (used when there is no history).
_DEFAULT_BUDGETS: dict[str, int] = {
    "code": 4096,
    "chat": 1024,
    "analysis": 2048,
}

# Fallback when the task type is unknown and there is no history.
_FALLBACK_BUDGET: int = 2048


# ---------------------------------------------------------------------------
# Public data classes
# ---------------------------------------------------------------------------


class TaskType(Enum):
    """Well-known task categories with distinct token profiles."""

    CODE = "code"
    CHAT = "chat"
    ANALYSIS = "analysis"


@dataclass(frozen=True)
class TokenUsageRecord:
    """A single observed token allocation/usage pair.

    Attributes:
        model: LiteLLM model identifier (e.g. ``"gpt-4o"``).
        task_type: Free-form task category (``"code"``, ``"chat"``, etc.).
        allocated_tokens: The ``max_tokens`` value sent in the request.
        used_tokens: Completion tokens actually consumed.
        was_truncated: Whether the response hit the allocation limit.
        timestamp: Unix epoch seconds (defaults to current time).
    """

    model: str
    task_type: str
    allocated_tokens: int
    used_tokens: int
    was_truncated: bool
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class BudgetRecommendation:
    """Recommended ``max_tokens`` for a (model, task_type) pair.

    Attributes:
        model: Model identifier.
        task_type: Task category.
        recommended_max_tokens: Suggested ``max_tokens`` value.
        confidence: Confidence in the recommendation (0.0-1.0).
        waste_reduction_pct: Estimated waste reduction compared to the
            caller's previous average allocation, as a percentage.
    """

    model: str
    task_type: str
    recommended_max_tokens: int
    confidence: float
    waste_reduction_pct: float


@dataclass(frozen=True)
class WasteReport:
    """Aggregate token-waste summary across all recorded usage.

    Attributes:
        total_allocated: Sum of all allocated tokens.
        total_used: Sum of all used tokens.
        waste_pct: Overall waste as a percentage (0.0-100.0).
        waste_by_model: Per-model waste percentages.
        waste_by_task_type: Per-task-type waste percentages.
    """

    total_allocated: int
    total_used: int
    waste_pct: float
    waste_by_model: dict[str, float]
    waste_by_task_type: dict[str, float]


# ---------------------------------------------------------------------------
# Internal bookkeeping
# ---------------------------------------------------------------------------


@dataclass
class _UsageWindow:
    """Per-(model, task_type) sliding window of usage observations."""

    used_values: list[int] = field(default_factory=list)
    sorted_used: list[int] = field(default_factory=list)
    allocated_values: list[int] = field(default_factory=list)
    truncation_count: int = 0
    total_count: int = 0
    ewma: float = 0.0
    ewma_initialised: bool = False
    last_updated: float = 0.0

    def add(
        self,
        allocated: int,
        used: int,
        was_truncated: bool,
        alpha: float,
    ) -> None:
        """Record one observation, updating the EWMA and window."""
        self.used_values.append(used)
        bisect.insort(self.sorted_used, used)
        self.allocated_values.append(allocated)
        self.total_count += 1

        if was_truncated:
            self.truncation_count += 1

        # EWMA update
        if not self.ewma_initialised:
            self.ewma = float(used)
            self.ewma_initialised = True
        else:
            self.ewma = alpha * used + (1 - alpha) * self.ewma

        # Evict oldest if over capacity
        if len(self.used_values) > _MAX_HISTORY:
            evicted = self.used_values.pop(0)
            idx = bisect.bisect_left(self.sorted_used, evicted)
            if idx < len(self.sorted_used) and self.sorted_used[idx] == evicted:
                self.sorted_used.pop(idx)
            self.allocated_values.pop(0)

        self.last_updated = time.monotonic()


# ---------------------------------------------------------------------------
# Main optimizer
# ---------------------------------------------------------------------------


class TokenBudgetOptimizer:
    """Adaptive token budget optimizer.

    Thread-safe.  Learns per-(model, task_type) optimal ``max_tokens``
    values from historical usage, applying an EWMA with a configurable
    headroom factor to balance waste reduction against truncation risk.

    Usage::

        opt = TokenBudgetOptimizer()

        # After each LLM call, record what happened:
        opt.record_usage(TokenUsageRecord(
            model="gpt-4o",
            task_type="code",
            allocated_tokens=4096,
            used_tokens=1823,
            was_truncated=False,
        ))

        # Before the next call, ask for a recommendation:
        rec = opt.recommend_budget("gpt-4o", "code")
        # rec.recommended_max_tokens ≈ 2188  (1823 EWMA * 1.2 headroom)
    """

    def __init__(
        self,
        alpha: float = _DEFAULT_ALPHA,
        headroom: float = _DEFAULT_HEADROOM,
    ) -> None:
        """Initialise the optimizer.

        Args:
            alpha: EWMA smoothing factor in (0, 1].  Higher values make
                the optimizer react faster to recent observations.
            headroom: Safety multiplier applied on top of the EWMA
                estimate.  1.2 means "recommend 20% more than the
                smoothed average".
        """
        if not 0 < alpha <= 1:
            raise ValueError(f"alpha must be in (0, 1], got {alpha}")
        if headroom < 1.0:
            raise ValueError(f"headroom must be >= 1.0, got {headroom}")

        self._alpha = alpha
        self._headroom = headroom
        self._windows: dict[tuple[str, str], _UsageWindow] = defaultdict(
            _UsageWindow,
        )
        self._lock = threading.Lock()

        logger.debug(
            "token_budget_optimizer.init",
            alpha=alpha,
            headroom=headroom,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def record_usage(self, record: TokenUsageRecord) -> None:
        """Record a completed request's token usage.

        Args:
            record: Observed allocation and consumption for one request.

        Raises:
            ValueError: If ``used_tokens`` or ``allocated_tokens`` is
                negative.
        """
        if record.allocated_tokens < 0:
            raise ValueError(
                f"allocated_tokens must be >= 0, got {record.allocated_tokens}",
            )
        if record.used_tokens < 0:
            raise ValueError(
                f"used_tokens must be >= 0, got {record.used_tokens}",
            )

        key = (record.model, record.task_type)
        with self._lock:
            self._windows[key].add(
                allocated=record.allocated_tokens,
                used=record.used_tokens,
                was_truncated=record.was_truncated,
                alpha=self._alpha,
            )

        logger.debug(
            "token_budget_optimizer.record",
            model=record.model,
            task_type=record.task_type,
            allocated=record.allocated_tokens,
            used=record.used_tokens,
            truncated=record.was_truncated,
        )

    def recommend_budget(
        self,
        model: str,
        task_type: str,
        prompt_tokens: int = 0,
    ) -> BudgetRecommendation:
        """Recommend an optimal ``max_tokens`` value.

        If there is sufficient history for the given (model, task_type)
        pair, the recommendation is the EWMA estimate multiplied by the
        headroom factor, clamped to the P99 of observed usage (so we
        don't accidentally clip long responses).

        If no history exists, a sensible default for the task type is
        returned with low confidence.

        Args:
            model: LiteLLM model identifier.
            task_type: Task category (``"code"``, ``"chat"``, etc.).
            prompt_tokens: Number of prompt tokens (reserved for future
                context-aware budgeting; currently unused).

        Returns:
            A ``BudgetRecommendation`` with the suggested budget,
            confidence score, and estimated waste reduction.
        """
        key = (model, task_type)
        with self._lock:
            window = self._windows.get(key)

            if window is None or len(window.used_values) < _MIN_SAMPLES:
                return self._default_recommendation(model, task_type)

            return self._compute_recommendation(model, task_type, window)

    def get_waste_report(self) -> WasteReport:
        """Summarise token waste across all recorded usage.

        Returns:
            A ``WasteReport`` with totals and per-model / per-task
            breakdowns.
        """
        with self._lock:
            total_alloc = 0
            total_used = 0
            alloc_by_model: dict[str, int] = defaultdict(int)
            used_by_model: dict[str, int] = defaultdict(int)
            alloc_by_task: dict[str, int] = defaultdict(int)
            used_by_task: dict[str, int] = defaultdict(int)

            for (mdl, task), window in self._windows.items():
                a = sum(window.allocated_values)
                u = sum(window.used_values)
                total_alloc += a
                total_used += u
                alloc_by_model[mdl] += a
                used_by_model[mdl] += u
                alloc_by_task[task] += a
                used_by_task[task] += u

        waste_pct = (
            _waste_pct(total_alloc, total_used) if total_alloc > 0 else 0.0
        )

        waste_by_model = {
            m: _waste_pct(alloc_by_model[m], used_by_model[m])
            for m in alloc_by_model
            if alloc_by_model[m] > 0
        }
        waste_by_task = {
            t: _waste_pct(alloc_by_task[t], used_by_task[t])
            for t in alloc_by_task
            if alloc_by_task[t] > 0
        }

        return WasteReport(
            total_allocated=total_alloc,
            total_used=total_used,
            waste_pct=round(waste_pct, 2),
            waste_by_model={k: round(v, 2) for k, v in waste_by_model.items()},
            waste_by_task_type={k: round(v, 2) for k, v in waste_by_task.items()},
        )

    def get_model_profile(self, model: str) -> dict[str, Any]:
        """Return P50 / P90 / P99 usage statistics for a model.

        Aggregates across all task types recorded for the given model.

        Args:
            model: LiteLLM model identifier.

        Returns:
            Dictionary with keys ``p50``, ``p90``, ``p99``,
            ``mean``, ``min``, ``max``, ``sample_count``,
            ``truncation_rate``, and ``task_types``.  Returns an
            empty dict if there is insufficient data.
        """
        with self._lock:
            merged_sorted: list[int] = []
            total_truncations = 0
            total_count = 0
            task_types: list[str] = []

            for (mdl, task), window in self._windows.items():
                if mdl != model:
                    continue
                if len(window.sorted_used) < 1:
                    continue
                merged_sorted.extend(window.sorted_used)
                total_truncations += window.truncation_count
                total_count += window.total_count
                task_types.append(task)

            if len(merged_sorted) < _MIN_SAMPLES:
                return {}

            merged_sorted.sort()

        trunc_rate = (
            total_truncations / total_count if total_count > 0 else 0.0
        )

        return {
            "p50": _percentile(merged_sorted, 0.50),
            "p90": _percentile(merged_sorted, 0.90),
            "p99": _percentile(merged_sorted, 0.99),
            "mean": round(sum(merged_sorted) / len(merged_sorted), 1),
            "min": merged_sorted[0],
            "max": merged_sorted[-1],
            "sample_count": len(merged_sorted),
            "truncation_rate": round(trunc_rate, 4),
            "task_types": sorted(set(task_types)),
        }

    def reset(self) -> None:
        """Clear all learned data and start fresh."""
        with self._lock:
            self._windows.clear()
        logger.info("token_budget_optimizer.reset")

    def export_state(self) -> dict[str, Any]:
        """Export internal state for persistence.

        Returns:
            Serialisable dictionary that can later be fed to
            ``import_state`` to restore the optimizer.
        """
        with self._lock:
            state: dict[str, Any] = {
                "alpha": self._alpha,
                "headroom": self._headroom,
                "windows": {},
            }
            for (mdl, task), window in self._windows.items():
                state["windows"][f"{mdl}::{task}"] = {
                    "used_values": list(window.used_values),
                    "allocated_values": list(window.allocated_values),
                    "truncation_count": window.truncation_count,
                    "total_count": window.total_count,
                    "ewma": window.ewma,
                    "ewma_initialised": window.ewma_initialised,
                }
        return state

    def import_state(self, state: dict[str, Any]) -> None:
        """Restore internal state from a previous ``export_state`` call.

        Args:
            state: Dictionary previously returned by ``export_state``.

        Raises:
            KeyError: If the state dictionary is malformed.
        """
        with self._lock:
            self._windows.clear()
            self._alpha = state["alpha"]
            self._headroom = state["headroom"]

            for composite_key, wdata in state.get("windows", {}).items():
                mdl, task = composite_key.split("::", 1)
                window = _UsageWindow()
                window.used_values = list(wdata["used_values"])
                window.sorted_used = sorted(window.used_values)
                window.allocated_values = list(wdata["allocated_values"])
                window.truncation_count = wdata["truncation_count"]
                window.total_count = wdata["total_count"]
                window.ewma = wdata["ewma"]
                window.ewma_initialised = wdata["ewma_initialised"]
                window.last_updated = time.monotonic()
                self._windows[(mdl, task)] = window

        logger.info(
            "token_budget_optimizer.import_state",
            num_windows=len(self._windows),
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _default_recommendation(
        self,
        model: str,
        task_type: str,
    ) -> BudgetRecommendation:
        """Return a low-confidence default when there is no history."""
        budget = _DEFAULT_BUDGETS.get(task_type, _FALLBACK_BUDGET)
        return BudgetRecommendation(
            model=model,
            task_type=task_type,
            recommended_max_tokens=budget,
            confidence=0.0,
            waste_reduction_pct=0.0,
        )

    def _compute_recommendation(
        self,
        model: str,
        task_type: str,
        window: _UsageWindow,
    ) -> BudgetRecommendation:
        """Compute a recommendation from an existing usage window.

        The recommended budget is::

            max(EWMA * headroom, P99)

        This ensures we accommodate typical requests (EWMA + headroom)
        while also not clipping long-tail responses (P99 floor).

        Confidence scales from 0.3 (at ``_MIN_SAMPLES``) to 1.0
        (at 100+ samples), and is penalised if the truncation rate is
        high.
        """
        ewma_budget = int(window.ewma * self._headroom)
        p99 = _percentile(window.sorted_used, 0.99)
        recommended = max(ewma_budget, p99, _ABSOLUTE_MIN_TOKENS)

        # Confidence: scales with sample count, penalised by truncation.
        n = len(window.used_values)
        base_confidence = min(n / 100.0, 1.0)
        trunc_rate = (
            window.truncation_count / window.total_count
            if window.total_count > 0
            else 0.0
        )
        confidence = max(base_confidence * (1.0 - trunc_rate), 0.0)

        # Waste reduction: compare recommendation to average past allocation.
        avg_alloc = (
            sum(window.allocated_values) / len(window.allocated_values)
            if window.allocated_values
            else 0
        )
        waste_reduction = (
            ((avg_alloc - recommended) / avg_alloc * 100.0)
            if avg_alloc > 0
            else 0.0
        )

        return BudgetRecommendation(
            model=model,
            task_type=task_type,
            recommended_max_tokens=recommended,
            confidence=round(confidence, 3),
            waste_reduction_pct=round(max(waste_reduction, 0.0), 2),
        )


# ---------------------------------------------------------------------------
# Module-level utilities
# ---------------------------------------------------------------------------


def _percentile(sorted_values: list[int], p: float) -> int:
    """Compute a percentile from pre-sorted integer values.

    Uses linear interpolation, rounded to the nearest integer.

    Args:
        sorted_values: Pre-sorted list of integers.
        p: Percentile in [0, 1].

    Returns:
        The interpolated percentile value.
    """
    if not sorted_values:
        return 0
    k = (len(sorted_values) - 1) * p
    f = int(k)
    c = f + 1
    if c >= len(sorted_values):
        return sorted_values[-1]
    d = k - f
    return round(sorted_values[f] * (1 - d) + sorted_values[c] * d)


def _waste_pct(allocated: int, used: int) -> float:
    """Compute waste percentage.

    Args:
        allocated: Total tokens allocated.
        used: Total tokens consumed.

    Returns:
        Waste as a percentage (0-100).
    """
    if allocated <= 0:
        return 0.0
    return (allocated - used) / allocated * 100.0
