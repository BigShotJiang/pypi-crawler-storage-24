"""Intelligent multi-tier fallback chain engine.

Provides automatic failover across AI providers with health-based ordering,
cost-aware selection, EWMA latency tracking, configurable retry policies,
provider exclusion lists, chain validation, time-of-day scheduling, and
full chain-traversal event logging.

Usage::

    config = FallbackConfig()
    engine = FallbackEngine(config)

    # Register chains for different task types
    engine.register_chain("code", FallbackChainDef(tiers=[
        FallbackTier(model="anthropic/claude-sonnet-4-20250514", provider="anthropic",
                     max_retries=2, timeout_ms=30_000, cost_per_1k=0.003),
        FallbackTier(model="openai/gpt-4o", provider="openai",
                     max_retries=2, timeout_ms=25_000, cost_per_1k=0.005),
        FallbackTier(model="deepseek/deepseek-chat", provider="deepseek",
                     max_retries=1, timeout_ms=20_000, cost_per_1k=0.0014),
    ]))

    # Execute with automatic fallback
    result = engine.execute("code", request_fn=my_api_call)
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from collections.abc import Callable

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DEFAULT_HEALTH_WINDOW: int = 50
_DEFAULT_EXCLUSION_THRESHOLD: float = 0.3
_DEFAULT_READMIT_AFTER_S: float = 300.0
_DEFAULT_EWMA_ALPHA: float = 0.3
_DEFAULT_LATENCY_WEIGHT: float = 0.2
_DEFAULT_COST_WEIGHT: float = 0.3
_DEFAULT_HEALTH_WEIGHT: float = 0.5

# Off-peak hours (UTC): 02:00 - 08:00
_OFF_PEAK_START: int = 2
_OFF_PEAK_END: int = 8


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class FailureReason(Enum):
    """Categorised reasons for a fallback event."""

    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    SERVER_ERROR = "server_error"
    AUTH_ERROR = "auth_error"
    PROVIDER_UNAVAILABLE = "provider_unavailable"
    UNKNOWN = "unknown"


class TaskType(Enum):
    """Well-known task types with default chain definitions."""

    CODE = "code"
    CHAT = "chat"
    ANALYSIS = "analysis"
    CREATIVE = "creative"
    EMBEDDING = "embedding"
    SUMMARISATION = "summarisation"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FallbackTier:
    """Single tier in a fallback chain.

    Attributes:
        model: LiteLLM model identifier (e.g. ``"anthropic/claude-sonnet-4-20250514"``).
        provider: Provider name (e.g. ``"anthropic"``).
        max_retries: Maximum retries within this tier before escalating.
        timeout_ms: Per-attempt timeout in milliseconds.
        cost_per_1k: Cost per 1 000 tokens (used for cost-aware ordering).
        off_peak_only: If ``True``, this tier is only used during off-peak hours.
    """

    model: str
    provider: str
    max_retries: int = 2
    timeout_ms: int = 30_000
    cost_per_1k: float = 0.0
    off_peak_only: bool = False


@dataclass
class FallbackChainDef:
    """Definition of a complete fallback chain for a task type.

    Attributes:
        tiers: Ordered list of fallback tiers (first = primary).
        name: Optional human-readable name.
        description: Optional description for logging/debugging.
    """

    tiers: list[FallbackTier]
    name: str = ""
    description: str = ""


@dataclass(frozen=True)
class FallbackEvent:
    """Log entry for a single fallback transition.

    Attributes:
        from_model: Model that failed (empty string for the initial attempt).
        to_model: Model we fell back to.
        reason: Why the previous model failed.
        latency_ms: Time spent on the failed attempt.
        attempt: Attempt number (1-based).
        timestamp: Unix epoch timestamp of the event.
        error_message: Raw error message (truncated to 500 chars).
    """

    from_model: str
    to_model: str
    reason: FailureReason
    latency_ms: float
    attempt: int
    timestamp: float
    error_message: str = ""


@dataclass(frozen=True)
class FallbackResult:
    """Outcome of executing a request through the fallback engine.

    Attributes:
        success: Whether any model succeeded.
        model_used: Model that ultimately handled the request (empty if all failed).
        response: The successful response payload, or ``None``.
        attempts: Total number of attempts across all tiers.
        fallback_events: Ordered list of fallback transitions.
        total_latency_ms: End-to-end latency including all retries.
    """

    success: bool
    model_used: str
    response: Any
    attempts: int
    fallback_events: list[FallbackEvent]
    total_latency_ms: float


@dataclass
class ProviderHealth:
    """Health state for a single provider.

    Attributes:
        provider: Provider name.
        successes: Number of successes in the current window.
        failures: Number of failures in the current window.
        success_rate: Rolling success rate (0.0 - 1.0).
        avg_latency_ms: EWMA-smoothed average latency.
        last_error: Most recent error message.
        last_error_time: Timestamp of the most recent error.
        is_excluded: Whether the provider is temporarily excluded.
        excluded_until: Timestamp after which the provider may be readmitted.
    """

    provider: str
    successes: int = 0
    failures: int = 0
    success_rate: float = 1.0
    avg_latency_ms: float = 0.0
    last_error: str = ""
    last_error_time: float = 0.0
    is_excluded: bool = False
    excluded_until: float = 0.0
    _outcomes: deque[bool] = field(default_factory=lambda: deque(maxlen=_DEFAULT_HEALTH_WINDOW))

    def record_success(self, latency_ms: float, *, ewma_alpha: float = _DEFAULT_EWMA_ALPHA) -> None:
        """Record a successful request.

        Args:
            latency_ms: Observed latency for this request.
            ewma_alpha: Smoothing factor for EWMA latency (0 < alpha <= 1).
        """
        self._outcomes.append(True)
        self.successes += 1
        self._update_rate()
        self._update_latency(latency_ms, ewma_alpha)

    def record_failure(
        self,
        error: str,
        latency_ms: float,
        *,
        ewma_alpha: float = _DEFAULT_EWMA_ALPHA,
    ) -> None:
        """Record a failed request.

        Args:
            error: Error description.
            latency_ms: Observed latency for the failed request.
            ewma_alpha: Smoothing factor for EWMA latency.
        """
        self._outcomes.append(False)
        self.failures += 1
        self.last_error = error[:500]
        self.last_error_time = time.time()
        self._update_rate()
        self._update_latency(latency_ms, ewma_alpha)

    def _update_rate(self) -> None:
        """Recompute success rate from the rolling window."""
        if not self._outcomes:
            self.success_rate = 1.0
            return
        self.success_rate = sum(1 for o in self._outcomes if o) / len(self._outcomes)

    def _update_latency(self, latency_ms: float, alpha: float) -> None:
        """Update EWMA latency estimate.

        Args:
            latency_ms: Latest latency observation.
            alpha: EWMA smoothing factor.
        """
        if self.avg_latency_ms == 0.0:
            self.avg_latency_ms = latency_ms
        else:
            self.avg_latency_ms = alpha * latency_ms + (1 - alpha) * self.avg_latency_ms


@dataclass
class FallbackConfig:
    """Configuration for the fallback engine.

    Attributes:
        health_window_size: Number of recent outcomes to track per provider.
        exclusion_threshold: Exclude providers whose success rate drops below this.
        readmit_after_s: Seconds before an excluded provider is reconsidered.
        ewma_alpha: Smoothing factor for EWMA latency (0 < alpha <= 1).
        latency_weight: Weight of latency in tier ordering (0.0 - 1.0).
        cost_weight: Weight of cost in tier ordering (0.0 - 1.0).
        health_weight: Weight of health/success-rate in tier ordering (0.0 - 1.0).
        enable_time_of_day: Enable time-of-day-based chain adjustment.
        off_peak_start_utc: Hour (0-23) at which off-peak begins.
        off_peak_end_utc: Hour (0-23) at which off-peak ends.
        max_events_per_request: Maximum fallback events to keep per request.
    """

    health_window_size: int = _DEFAULT_HEALTH_WINDOW
    exclusion_threshold: float = _DEFAULT_EXCLUSION_THRESHOLD
    readmit_after_s: float = _DEFAULT_READMIT_AFTER_S
    ewma_alpha: float = _DEFAULT_EWMA_ALPHA
    latency_weight: float = _DEFAULT_LATENCY_WEIGHT
    cost_weight: float = _DEFAULT_COST_WEIGHT
    health_weight: float = _DEFAULT_HEALTH_WEIGHT
    enable_time_of_day: bool = False
    off_peak_start_utc: int = _OFF_PEAK_START
    off_peak_end_utc: int = _OFF_PEAK_END
    max_events_per_request: int = 50


# ---------------------------------------------------------------------------
# Chain validation
# ---------------------------------------------------------------------------


class ChainValidationError(Exception):
    """Raised when a fallback chain definition is invalid."""

    def __init__(self, message: str, chain_name: str = "") -> None:
        self.chain_name = chain_name
        prefix = f"Chain '{chain_name}': " if chain_name else ""
        super().__init__(f"{prefix}{message}")


def validate_chain(chain_def: FallbackChainDef, name: str = "") -> list[str]:
    """Validate a fallback chain definition.

    Checks:
        - Chain is non-empty.
        - No duplicate models (cycle detection).
        - At least one tier is not off-peak-only (terminal model always available).
        - All tiers have valid parameters.

    Args:
        chain_def: The chain definition to validate.
        name: Optional chain name for error messages.

    Returns:
        List of warning strings (empty = clean).

    Raises:
        ChainValidationError: If the chain has a fatal issue.
    """
    warnings: list[str] = []

    if not chain_def.tiers:
        raise ChainValidationError("Chain has no tiers", name)

    # Check for duplicate models (cycles)
    seen_models: set[str] = set()
    for tier in chain_def.tiers:
        if tier.model in seen_models:
            raise ChainValidationError(
                f"Duplicate model '{tier.model}' creates a cycle", name
            )
        seen_models.add(tier.model)

    # Ensure at least one always-available terminal tier
    always_available = [t for t in chain_def.tiers if not t.off_peak_only]
    if not always_available:
        raise ChainValidationError(
            "All tiers are off_peak_only; no terminal model available during peak hours",
            name,
        )

    # Parameter validation
    for i, tier in enumerate(chain_def.tiers):
        if tier.max_retries < 0:
            raise ChainValidationError(
                f"Tier {i} ({tier.model}): max_retries cannot be negative", name
            )
        if tier.timeout_ms <= 0:
            raise ChainValidationError(
                f"Tier {i} ({tier.model}): timeout_ms must be positive", name
            )
        if tier.cost_per_1k < 0:
            warnings.append(f"Tier {i} ({tier.model}): negative cost_per_1k")

    return warnings


# ---------------------------------------------------------------------------
# Fallback Engine
# ---------------------------------------------------------------------------


class FallbackEngine:
    """Engine that manages multiple fallback chains and provider health.

    Thread-safe. Tracks per-provider health, applies EWMA latency smoothing,
    performs cost-aware and health-based reordering, manages exclusion lists,
    supports time-of-day scheduling, and logs full chain traversal history.

    Usage::

        engine = FallbackEngine(FallbackConfig())
        engine.register_chain("code", chain_def)

        result = engine.execute("code", request_fn=my_call)
        if result.success:
            print(result.response)
        else:
            print(f"All {result.attempts} attempts failed")
    """

    def __init__(self, config: FallbackConfig | None = None) -> None:
        """Initialise the fallback engine.

        Args:
            config: Engine configuration. Uses defaults if ``None``.
        """
        self._config = config or FallbackConfig()
        self._chains: dict[str, FallbackChainDef] = {}
        self._health: dict[str, ProviderHealth] = {}
        self._lock = threading.Lock()
        self._event_log: list[FallbackEvent] = []

    # ------------------------------------------------------------------
    # Chain management
    # ------------------------------------------------------------------

    def register_chain(
        self,
        task_type: str,
        chain_def: FallbackChainDef,
        *,
        validate: bool = True,
    ) -> list[str]:
        """Register a fallback chain for a task type.

        Args:
            task_type: Task type key (e.g. ``"code"``, ``"chat"``).
            chain_def: The chain definition.
            validate: Whether to validate the chain (raises on fatal issues).

        Returns:
            List of validation warnings (empty = clean).

        Raises:
            ChainValidationError: If validation is enabled and chain is invalid.
        """
        warnings: list[str] = []
        if validate:
            warnings = validate_chain(chain_def, name=task_type)

        with self._lock:
            self._chains[task_type] = chain_def
            # Ensure health entries exist for all providers in the chain
            for tier in chain_def.tiers:
                if tier.provider not in self._health:
                    self._health[tier.provider] = ProviderHealth(
                        provider=tier.provider,
                        _outcomes=deque(maxlen=self._config.health_window_size),
                    )

        logger.info(
            "fallback_chain_registered",
            task_type=task_type,
            tiers=len(chain_def.tiers),
            warnings=len(warnings),
        )
        return warnings

    def get_chain(self, task_type: str) -> FallbackChainDef | None:
        """Retrieve a registered chain definition.

        Args:
            task_type: Task type key.

        Returns:
            The chain definition, or ``None`` if not registered.
        """
        with self._lock:
            return self._chains.get(task_type)

    def list_chains(self) -> list[str]:
        """List all registered task types.

        Returns:
            Sorted list of registered task type keys.
        """
        with self._lock:
            return sorted(self._chains.keys())

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(
        self,
        task_type: str,
        *,
        request_fn: Callable[[str, int], Any],
        now: float | None = None,
    ) -> FallbackResult:
        """Execute a request with automatic fallback.

        The ``request_fn`` callable receives ``(model_id, timeout_ms)`` and must
        either return a response or raise an exception. The engine catches all
        exceptions, classifies the failure, and falls back to the next tier.

        Args:
            task_type: The task type key identifying which chain to use.
            request_fn: ``(model, timeout_ms) -> response``. Raise on failure.
            now: Override current timestamp (for testing). Defaults to ``time.time()``.

        Returns:
            FallbackResult describing the outcome.
        """
        start = time.monotonic()
        current_time = now if now is not None else time.time()

        with self._lock:
            chain_def = self._chains.get(task_type)
        if chain_def is None:
            logger.warning("fallback_chain_not_found", task_type=task_type)
            return FallbackResult(
                success=False,
                model_used="",
                response=None,
                attempts=0,
                fallback_events=[],
                total_latency_ms=0.0,
            )

        # Build effective tier ordering
        effective_tiers = self._build_effective_tiers(chain_def, current_time)

        events: list[FallbackEvent] = []
        attempts = 0
        prev_model = ""

        for tier in effective_tiers:
            for retry in range(tier.max_retries + 1):
                attempts += 1
                attempt_start = time.monotonic()

                try:
                    response = request_fn(tier.model, tier.timeout_ms)
                except Exception as exc:
                    attempt_latency = (time.monotonic() - attempt_start) * 1000
                    reason = self._classify_error(exc)
                    error_msg = str(exc)[:500]

                    event = FallbackEvent(
                        from_model=prev_model,
                        to_model=tier.model,
                        reason=reason,
                        latency_ms=round(attempt_latency, 2),
                        attempt=attempts,
                        timestamp=time.time(),
                        error_message=error_msg,
                    )
                    events.append(event)

                    # Update health
                    with self._lock:
                        health = self._health.get(tier.provider)
                        if health:
                            health.record_failure(
                                error_msg,
                                attempt_latency,
                                ewma_alpha=self._config.ewma_alpha,
                            )
                            self._maybe_exclude(health)

                    logger.debug(
                        "fallback_attempt_failed",
                        model=tier.model,
                        attempt=attempts,
                        retry=retry,
                        reason=reason.value,
                        latency_ms=round(attempt_latency, 2),
                    )

                    prev_model = tier.model
                    continue

                # Success
                attempt_latency = (time.monotonic() - attempt_start) * 1000
                with self._lock:
                    health = self._health.get(tier.provider)
                    if health:
                        health.record_success(
                            attempt_latency,
                            ewma_alpha=self._config.ewma_alpha,
                        )

                total_latency = (time.monotonic() - start) * 1000

                logger.info(
                    "fallback_chain_success",
                    task_type=task_type,
                    model_used=tier.model,
                    attempts=attempts,
                    fallbacks=len(events),
                    total_latency_ms=round(total_latency, 2),
                )

                # Persist events
                with self._lock:
                    self._event_log.extend(events)
                    self._trim_event_log()

                return FallbackResult(
                    success=True,
                    model_used=tier.model,
                    response=response,
                    attempts=attempts,
                    fallback_events=events,
                    total_latency_ms=round(total_latency, 2),
                )

            # All retries for this tier exhausted — move to next tier
            prev_model = tier.model

        # All tiers exhausted
        total_latency = (time.monotonic() - start) * 1000

        logger.warning(
            "fallback_chain_exhausted",
            task_type=task_type,
            attempts=attempts,
            tiers_tried=len(effective_tiers),
            total_latency_ms=round(total_latency, 2),
        )

        with self._lock:
            self._event_log.extend(events)
            self._trim_event_log()

        return FallbackResult(
            success=False,
            model_used="",
            response=None,
            attempts=attempts,
            fallback_events=events,
            total_latency_ms=round(total_latency, 2),
        )

    # ------------------------------------------------------------------
    # Health management
    # ------------------------------------------------------------------

    def get_provider_health(self, provider: str) -> ProviderHealth | None:
        """Get health status for a provider.

        Args:
            provider: Provider name.

        Returns:
            ProviderHealth, or ``None`` if not tracked.
        """
        with self._lock:
            return self._health.get(provider)

    def get_all_health(self) -> dict[str, ProviderHealth]:
        """Get health status for all tracked providers.

        Returns:
            Dict of provider name to ProviderHealth.
        """
        with self._lock:
            return dict(self._health)

    def reset_provider_health(self, provider: str) -> None:
        """Reset health tracking for a provider.

        Args:
            provider: Provider name.
        """
        with self._lock:
            if provider in self._health:
                self._health[provider] = ProviderHealth(
                    provider=provider,
                    _outcomes=deque(maxlen=self._config.health_window_size),
                )
                logger.info("provider_health_reset", provider=provider)

    def exclude_provider(self, provider: str, *, duration_s: float | None = None) -> None:
        """Manually exclude a provider from fallback chains.

        Args:
            provider: Provider name.
            duration_s: How long to exclude (uses config default if ``None``).
        """
        duration = duration_s if duration_s is not None else self._config.readmit_after_s
        with self._lock:
            health = self._health.get(provider)
            if health:
                health.is_excluded = True
                health.excluded_until = time.time() + duration
                logger.info(
                    "provider_excluded",
                    provider=provider,
                    duration_s=duration,
                )

    def readmit_provider(self, provider: str) -> None:
        """Manually readmit an excluded provider.

        Args:
            provider: Provider name.
        """
        with self._lock:
            health = self._health.get(provider)
            if health:
                health.is_excluded = False
                health.excluded_until = 0.0
                logger.info("provider_readmitted", provider=provider)

    # ------------------------------------------------------------------
    # Event log
    # ------------------------------------------------------------------

    def get_event_log(self, *, limit: int = 100) -> list[FallbackEvent]:
        """Retrieve recent fallback events.

        Args:
            limit: Maximum number of events to return.

        Returns:
            List of recent FallbackEvents, newest first.
        """
        with self._lock:
            return list(reversed(self._event_log[-limit:]))

    def clear_event_log(self) -> None:
        """Clear the in-memory event log."""
        with self._lock:
            self._event_log.clear()

    # ------------------------------------------------------------------
    # Internal: tier ordering and filtering
    # ------------------------------------------------------------------

    def _build_effective_tiers(
        self,
        chain_def: FallbackChainDef,
        current_time: float,
    ) -> list[FallbackTier]:
        """Build an effective tier list with health/cost/latency reordering.

        Steps:
            1. Filter out off-peak-only tiers if not off-peak.
            2. Filter out excluded providers (auto-readmit if timer expired).
            3. Score remaining tiers by health, latency, and cost.
            4. Sort by score (higher is better).

        Args:
            chain_def: The chain definition.
            current_time: Current unix timestamp.

        Returns:
            Ordered list of effective tiers.
        """
        is_off_peak = self._is_off_peak(current_time)

        eligible: list[tuple[FallbackTier, float]] = []

        for tier in chain_def.tiers:
            # Time-of-day filter
            if tier.off_peak_only and not is_off_peak and self._config.enable_time_of_day:
                continue

            # Exclusion check (with auto-readmission)
            with self._lock:
                health = self._health.get(tier.provider)
                if health and health.is_excluded:
                    if current_time >= health.excluded_until:
                        health.is_excluded = False
                        health.excluded_until = 0.0
                        logger.info(
                            "provider_auto_readmitted",
                            provider=tier.provider,
                        )
                    else:
                        continue

            # Score the tier
            score = self._score_tier(tier)
            eligible.append((tier, score))

        # Sort by score descending (higher = better)
        eligible.sort(key=lambda pair: pair[1], reverse=True)

        return [tier for tier, _score in eligible]

    def _score_tier(self, tier: FallbackTier) -> float:
        """Compute a composite score for tier ordering.

        The score blends:
            - Health: provider success rate (higher = better)
            - Latency: inverse of EWMA latency (lower = better)
            - Cost: inverse of cost_per_1k (cheaper = better)

        Args:
            tier: The fallback tier to score.

        Returns:
            Composite score (higher is better).
        """
        cfg = self._config

        # Health component
        with self._lock:
            health = self._health.get(tier.provider)
        health_score = health.success_rate if health else 1.0

        # Latency component (normalise so 100ms = 1.0, higher latency = lower score)
        latency_ms = health.avg_latency_ms if health and health.avg_latency_ms > 0 else 500.0
        latency_score = 100.0 / max(latency_ms, 1.0)

        # Cost component (normalise so $0.001/1k = 1.0, free models get max score)
        cost_score = 10.0 if tier.cost_per_1k <= 0 else 0.001 / max(tier.cost_per_1k, 0.0001)

        # Weighted composite
        composite = (
            cfg.health_weight * health_score
            + cfg.latency_weight * latency_score
            + cfg.cost_weight * cost_score
        )

        return composite

    def _is_off_peak(self, current_time: float) -> bool:
        """Check whether the current time falls in the off-peak window.

        Args:
            current_time: Unix timestamp.

        Returns:
            True if currently off-peak.
        """
        if not self._config.enable_time_of_day:
            return False
        hour = time.gmtime(current_time).tm_hour
        start = self._config.off_peak_start_utc
        end = self._config.off_peak_end_utc
        if start < end:
            return start <= hour < end
        # Wraps midnight (e.g. 22:00 - 06:00)
        return hour >= start or hour < end

    def _maybe_exclude(self, health: ProviderHealth) -> None:
        """Exclude a provider if its success rate is below the threshold.

        Must be called with ``self._lock`` held.

        Args:
            health: Provider health object.
        """
        # Need a minimum number of observations before excluding
        if len(health._outcomes) < 5:
            return
        if health.success_rate < self._config.exclusion_threshold:
            health.is_excluded = True
            health.excluded_until = time.time() + self._config.readmit_after_s
            logger.warning(
                "provider_auto_excluded",
                provider=health.provider,
                success_rate=round(health.success_rate, 3),
                readmit_after_s=self._config.readmit_after_s,
            )

    def _trim_event_log(self) -> None:
        """Trim the event log to prevent unbounded growth.

        Must be called with ``self._lock`` held.
        """
        max_events = 10_000
        if len(self._event_log) > max_events:
            self._event_log = self._event_log[-max_events:]

    # ------------------------------------------------------------------
    # Error classification
    # ------------------------------------------------------------------

    @staticmethod
    def _classify_error(exc: Exception) -> FailureReason:
        """Classify an exception into a FailureReason.

        Inspects the exception type name and message to infer the category.
        This avoids hard dependencies on provider-specific exception classes.

        Args:
            exc: The caught exception.

        Returns:
            Appropriate FailureReason.
        """
        exc_type = type(exc).__name__.lower()
        exc_msg = str(exc).lower()

        # Timeout detection
        if "timeout" in exc_type or "timeout" in exc_msg:
            return FailureReason.TIMEOUT

        # Rate limit detection
        if "ratelimit" in exc_type or "rate_limit" in exc_type:
            return FailureReason.RATE_LIMIT
        if "429" in exc_msg or "rate limit" in exc_msg or "too many requests" in exc_msg:
            return FailureReason.RATE_LIMIT

        # Auth errors
        if "auth" in exc_type or "401" in exc_msg or "403" in exc_msg:
            return FailureReason.AUTH_ERROR

        # Server errors (5xx)
        if any(code in exc_msg for code in ("500", "502", "503", "504")):
            return FailureReason.SERVER_ERROR
        if "server" in exc_type or "internal" in exc_msg:
            return FailureReason.SERVER_ERROR

        # Provider unavailable
        if "unavailable" in exc_msg or "connection" in exc_type:
            return FailureReason.PROVIDER_UNAVAILABLE

        return FailureReason.UNKNOWN

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def get_effective_order(
        self,
        task_type: str,
        *,
        now: float | None = None,
    ) -> list[str]:
        """Preview the effective tier order for a task type without executing.

        Useful for debugging and dashboard displays.

        Args:
            task_type: Task type key.
            now: Override current timestamp (for testing).

        Returns:
            Ordered list of model IDs.
        """
        current_time = now if now is not None else time.time()
        with self._lock:
            chain_def = self._chains.get(task_type)
        if chain_def is None:
            return []
        effective = self._build_effective_tiers(chain_def, current_time)
        return [t.model for t in effective]

    def stats_summary(self) -> dict[str, Any]:
        """Return a summary of engine state for dashboards.

        Returns:
            Dict with chain count, provider health summaries, event log size.
        """
        with self._lock:
            providers = {
                name: {
                    "success_rate": round(h.success_rate, 3),
                    "avg_latency_ms": round(h.avg_latency_ms, 1),
                    "is_excluded": h.is_excluded,
                    "total_requests": h.successes + h.failures,
                }
                for name, h in self._health.items()
            }
            return {
                "chains": len(self._chains),
                "providers": providers,
                "event_log_size": len(self._event_log),
            }
