"""Prism intelligent routing engine."""

from prism.router.classifier import TaskClassifier
from prism.router.dedup import (
    Batch,
    BatchConfig,
    DedupStats,
    RequestBatcher,
    RequestDeduplicator,
    RequestFingerprint,
)
from prism.router.fallback import FallbackChain
from prism.router.fingerprint import (
    ModelFingerprint,
    ProviderCapability,
    ProviderFingerprinter,
)
from prism.router.learning import AdaptiveLearner
from prism.router.pareto import (
    ModelScore,
    ObjectiveWeight,
    ParetoRouter,
    RoutingConstraint,
)
from prism.router.rate_limiter import RateLimiter
from prism.router.selector import ModelSelection, ModelSelector
from prism.router.token_optimizer import (
    BudgetRecommendation,
    TokenBudgetOptimizer,
    TokenUsageRecord,
    WasteReport,
)

__all__ = [
    "AdaptiveLearner",
    "Batch",
    "BatchConfig",
    "BudgetRecommendation",
    "DedupStats",
    "FallbackChain",
    "ModelFingerprint",
    "ModelScore",
    "ModelSelection",
    "ModelSelector",
    "ObjectiveWeight",
    "ParetoRouter",
    "ProviderCapability",
    "ProviderFingerprinter",
    "RateLimiter",
    "RequestBatcher",
    "RequestDeduplicator",
    "RequestFingerprint",
    "RoutingConstraint",
    "TaskClassifier",
    "TokenBudgetOptimizer",
    "TokenUsageRecord",
    "WasteReport",
]
