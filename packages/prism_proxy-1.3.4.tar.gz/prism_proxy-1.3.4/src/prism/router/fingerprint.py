"""Provider fingerprinting and capability detection.

Maintains a comprehensive registry of model capabilities, costs, and
constraints across all major providers. Enables capability-aware routing,
fallback selection, and request validation without any real API calls.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from enum import StrEnum, auto

import structlog

logger = structlog.get_logger(__name__)


class ProviderCapability(StrEnum):
    """Capabilities that a model/provider may support."""

    STREAMING = auto()
    TOOL_CALLING = auto()
    VISION = auto()
    JSON_MODE = auto()
    EXTENDED_THINKING = auto()
    FUNCTION_CALLING = auto()
    SYSTEM_MESSAGES = auto()
    SEED_CONTROL = auto()
    LOGPROBS = auto()
    EMBEDDING = auto()
    FINE_TUNING = auto()
    BATCH_API = auto()


@dataclass(frozen=True)
class ModelFingerprint:
    """Full capability and cost profile for a single model.

    Attributes:
        model_id: Canonical model identifier (e.g. ``gpt-4o``, ``claude-4-opus``).
        provider: Provider name (e.g. ``openai``, ``anthropic``).
        max_context_window: Maximum total tokens (input + output).
        max_output_tokens: Maximum tokens the model can generate in one call.
        capabilities: Set of supported :class:`ProviderCapability` values.
        supports_temperature: Whether the ``temperature`` parameter is accepted.
        supports_top_p: Whether the ``top_p`` parameter is accepted.
        supports_stop_sequences: Whether ``stop`` / ``stop_sequences`` is accepted.
        supports_frequency_penalty: Whether ``frequency_penalty`` is accepted.
        supports_presence_penalty: Whether ``presence_penalty`` is accepted.
        cost_per_1k_input: USD cost per 1 000 input tokens.
        cost_per_1k_output: USD cost per 1 000 output tokens.
        typical_latency_ms: Estimated median latency (TTFB) in milliseconds.
        release_date: When the model became generally available (or ``None``).
        deprecation_date: Scheduled deprecation date (or ``None``).
    """

    model_id: str
    provider: str
    max_context_window: int
    max_output_tokens: int
    capabilities: frozenset[ProviderCapability] = field(default_factory=frozenset)
    supports_temperature: bool = True
    supports_top_p: bool = True
    supports_stop_sequences: bool = True
    supports_frequency_penalty: bool = False
    supports_presence_penalty: bool = False
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    typical_latency_ms: float = 0.0
    release_date: datetime.date | None = None
    deprecation_date: datetime.date | None = None

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def has_capability(self, cap: ProviderCapability) -> bool:
        """Check whether this model supports *cap*.

        Args:
            cap: The capability to test.

        Returns:
            ``True`` if the capability is present.
        """
        return cap in self.capabilities

    def estimated_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate the USD cost for a single request.

        Args:
            input_tokens: Number of input tokens.
            output_tokens: Number of output tokens.

        Returns:
            Estimated cost in USD.
        """
        return (
            (input_tokens / 1000.0) * self.cost_per_1k_input
            + (output_tokens / 1000.0) * self.cost_per_1k_output
        )

    def is_deprecated(self, reference_date: datetime.date | None = None) -> bool:
        """Return ``True`` if the model is past its deprecation date.

        Args:
            reference_date: Date to check against. Defaults to today.

        Returns:
            ``True`` when the model is deprecated.
        """
        if self.deprecation_date is None:
            return False
        ref = reference_date or datetime.date.today()
        return ref >= self.deprecation_date


# ======================================================================
# Built-in model registry
# ======================================================================

def _openai_caps(*, logprobs: bool = True, vision: bool = True) -> frozenset[ProviderCapability]:
    """Return the standard OpenAI capability set."""
    caps: set[ProviderCapability] = {
        ProviderCapability.STREAMING,
        ProviderCapability.TOOL_CALLING,
        ProviderCapability.FUNCTION_CALLING,
        ProviderCapability.JSON_MODE,
        ProviderCapability.SYSTEM_MESSAGES,
        ProviderCapability.SEED_CONTROL,
        ProviderCapability.BATCH_API,
    }
    if logprobs:
        caps.add(ProviderCapability.LOGPROBS)
    if vision:
        caps.add(ProviderCapability.VISION)
    return frozenset(caps)


def _anthropic_caps(*, thinking: bool = False) -> frozenset[ProviderCapability]:
    """Return the standard Anthropic capability set."""
    caps: set[ProviderCapability] = {
        ProviderCapability.STREAMING,
        ProviderCapability.TOOL_CALLING,
        ProviderCapability.VISION,
        ProviderCapability.SYSTEM_MESSAGES,
        ProviderCapability.BATCH_API,
    }
    if thinking:
        caps.add(ProviderCapability.EXTENDED_THINKING)
    return frozenset(caps)


def _google_caps() -> frozenset[ProviderCapability]:
    """Return the standard Google Gemini capability set."""
    return frozenset({
        ProviderCapability.STREAMING,
        ProviderCapability.TOOL_CALLING,
        ProviderCapability.FUNCTION_CALLING,
        ProviderCapability.VISION,
        ProviderCapability.JSON_MODE,
        ProviderCapability.SYSTEM_MESSAGES,
    })


def _deepseek_caps() -> frozenset[ProviderCapability]:
    """Return the standard DeepSeek capability set."""
    return frozenset({
        ProviderCapability.STREAMING,
        ProviderCapability.TOOL_CALLING,
        ProviderCapability.FUNCTION_CALLING,
        ProviderCapability.JSON_MODE,
        ProviderCapability.SYSTEM_MESSAGES,
    })


def _groq_caps() -> frozenset[ProviderCapability]:
    """Return the standard Groq capability set."""
    return frozenset({
        ProviderCapability.STREAMING,
        ProviderCapability.TOOL_CALLING,
        ProviderCapability.JSON_MODE,
        ProviderCapability.SYSTEM_MESSAGES,
    })


def _mistral_caps(*, vision: bool = False) -> frozenset[ProviderCapability]:
    """Return the standard Mistral capability set."""
    caps: set[ProviderCapability] = {
        ProviderCapability.STREAMING,
        ProviderCapability.TOOL_CALLING,
        ProviderCapability.FUNCTION_CALLING,
        ProviderCapability.JSON_MODE,
        ProviderCapability.SYSTEM_MESSAGES,
    }
    if vision:
        caps.add(ProviderCapability.VISION)
    return frozenset(caps)


# fmt: off
_BUILTIN_FINGERPRINTS: list[ModelFingerprint] = [
    # ------------------------------------------------------------------
    # OpenAI
    # ------------------------------------------------------------------
    ModelFingerprint(
        model_id="gpt-4o",
        provider="openai",
        max_context_window=128_000,
        max_output_tokens=16_384,
        capabilities=_openai_caps(),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=True,
        supports_presence_penalty=True,
        cost_per_1k_input=0.0025,
        cost_per_1k_output=0.010,
        typical_latency_ms=800,
        release_date=datetime.date(2024, 5, 13),
    ),
    ModelFingerprint(
        model_id="gpt-4o-mini",
        provider="openai",
        max_context_window=128_000,
        max_output_tokens=16_384,
        capabilities=_openai_caps(),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=True,
        supports_presence_penalty=True,
        cost_per_1k_input=0.00015,
        cost_per_1k_output=0.0006,
        typical_latency_ms=500,
        release_date=datetime.date(2024, 7, 18),
    ),
    ModelFingerprint(
        model_id="o3",
        provider="openai",
        max_context_window=200_000,
        max_output_tokens=100_000,
        capabilities=_openai_caps(logprobs=False) | frozenset({ProviderCapability.EXTENDED_THINKING}),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.010,
        cost_per_1k_output=0.040,
        typical_latency_ms=15_000,
        release_date=datetime.date(2025, 4, 16),
    ),
    ModelFingerprint(
        model_id="o3-mini",
        provider="openai",
        max_context_window=200_000,
        max_output_tokens=100_000,
        capabilities=_openai_caps(logprobs=False, vision=False) | frozenset({ProviderCapability.EXTENDED_THINKING}),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.0011,
        cost_per_1k_output=0.0044,
        typical_latency_ms=8_000,
        release_date=datetime.date(2025, 1, 31),
    ),
    ModelFingerprint(
        model_id="o4-mini",
        provider="openai",
        max_context_window=200_000,
        max_output_tokens=100_000,
        capabilities=_openai_caps() | frozenset({ProviderCapability.EXTENDED_THINKING}),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.0011,
        cost_per_1k_output=0.0044,
        typical_latency_ms=6_000,
        release_date=datetime.date(2025, 4, 16),
    ),

    # ------------------------------------------------------------------
    # Anthropic
    # ------------------------------------------------------------------
    ModelFingerprint(
        model_id="claude-4-opus",
        provider="anthropic",
        max_context_window=200_000,
        max_output_tokens=32_000,
        capabilities=_anthropic_caps(thinking=True),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.015,
        cost_per_1k_output=0.075,
        typical_latency_ms=2_000,
        release_date=datetime.date(2025, 5, 22),
    ),
    ModelFingerprint(
        model_id="claude-4-sonnet",
        provider="anthropic",
        max_context_window=200_000,
        max_output_tokens=16_000,
        capabilities=_anthropic_caps(thinking=True),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.003,
        cost_per_1k_output=0.015,
        typical_latency_ms=1_200,
        release_date=datetime.date(2025, 5, 22),
    ),
    ModelFingerprint(
        model_id="claude-3.5-haiku",
        provider="anthropic",
        max_context_window=200_000,
        max_output_tokens=8_192,
        capabilities=_anthropic_caps(thinking=False),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.0008,
        cost_per_1k_output=0.004,
        typical_latency_ms=600,
        release_date=datetime.date(2024, 10, 29),
    ),

    # ------------------------------------------------------------------
    # Google
    # ------------------------------------------------------------------
    ModelFingerprint(
        model_id="gemini-2.5-pro",
        provider="google",
        max_context_window=1_000_000,
        max_output_tokens=65_536,
        capabilities=_google_caps() | frozenset({ProviderCapability.EXTENDED_THINKING}),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.00125,
        cost_per_1k_output=0.010,
        typical_latency_ms=1_500,
        release_date=datetime.date(2025, 3, 25),
    ),
    ModelFingerprint(
        model_id="gemini-2.5-flash",
        provider="google",
        max_context_window=1_000_000,
        max_output_tokens=65_536,
        capabilities=_google_caps() | frozenset({ProviderCapability.EXTENDED_THINKING}),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.000075,
        cost_per_1k_output=0.0003,
        typical_latency_ms=400,
        release_date=datetime.date(2025, 4, 17),
    ),

    # ------------------------------------------------------------------
    # DeepSeek
    # ------------------------------------------------------------------
    ModelFingerprint(
        model_id="deepseek-v3",
        provider="deepseek",
        max_context_window=128_000,
        max_output_tokens=8_192,
        capabilities=_deepseek_caps(),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=True,
        supports_presence_penalty=True,
        cost_per_1k_input=0.00027,
        cost_per_1k_output=0.0011,
        typical_latency_ms=900,
        release_date=datetime.date(2024, 12, 26),
    ),
    ModelFingerprint(
        model_id="deepseek-r1",
        provider="deepseek",
        max_context_window=128_000,
        max_output_tokens=8_192,
        capabilities=_deepseek_caps() | frozenset({ProviderCapability.EXTENDED_THINKING}),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=True,
        supports_presence_penalty=True,
        cost_per_1k_input=0.00055,
        cost_per_1k_output=0.0022,
        typical_latency_ms=5_000,
        release_date=datetime.date(2025, 1, 20),
    ),

    # ------------------------------------------------------------------
    # Groq
    # ------------------------------------------------------------------
    ModelFingerprint(
        model_id="groq/llama-3.3-70b-versatile",
        provider="groq",
        max_context_window=128_000,
        max_output_tokens=32_768,
        capabilities=_groq_caps(),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=True,
        supports_presence_penalty=True,
        cost_per_1k_input=0.00059,
        cost_per_1k_output=0.00079,
        typical_latency_ms=200,
        release_date=datetime.date(2024, 12, 6),
    ),
    ModelFingerprint(
        model_id="groq/mixtral-8x7b-32768",
        provider="groq",
        max_context_window=32_768,
        max_output_tokens=32_768,
        capabilities=_groq_caps(),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=True,
        supports_presence_penalty=True,
        cost_per_1k_input=0.00024,
        cost_per_1k_output=0.00024,
        typical_latency_ms=250,
        release_date=datetime.date(2024, 3, 1),
    ),

    # ------------------------------------------------------------------
    # Mistral
    # ------------------------------------------------------------------
    ModelFingerprint(
        model_id="mistral-large-latest",
        provider="mistral",
        max_context_window=128_000,
        max_output_tokens=8_192,
        capabilities=_mistral_caps(vision=True),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.002,
        cost_per_1k_output=0.006,
        typical_latency_ms=1_000,
        release_date=datetime.date(2024, 11, 18),
    ),
    ModelFingerprint(
        model_id="mistral-small-latest",
        provider="mistral",
        max_context_window=128_000,
        max_output_tokens=8_192,
        capabilities=_mistral_caps(vision=False),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.0001,
        cost_per_1k_output=0.0003,
        typical_latency_ms=350,
        release_date=datetime.date(2024, 9, 18),
    ),
    ModelFingerprint(
        model_id="codestral-latest",
        provider="mistral",
        max_context_window=256_000,
        max_output_tokens=8_192,
        capabilities=_mistral_caps(vision=False),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.0003,
        cost_per_1k_output=0.0009,
        typical_latency_ms=400,
        release_date=datetime.date(2025, 1, 14),
    ),

    # ------------------------------------------------------------------
    # Ollama (local placeholder — zero-cost, limited capabilities)
    # ------------------------------------------------------------------
    ModelFingerprint(
        model_id="ollama/local",
        provider="ollama",
        max_context_window=32_768,
        max_output_tokens=4_096,
        capabilities=frozenset({
            ProviderCapability.STREAMING,
            ProviderCapability.SYSTEM_MESSAGES,
        }),
        supports_temperature=True,
        supports_top_p=True,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.0,
        cost_per_1k_output=0.0,
        typical_latency_ms=1_500,
    ),
]
# fmt: on


class ProviderFingerprinter:
    """Registry-backed capability detection for AI models and providers.

    Maintains an in-memory map of :class:`ModelFingerprint` objects and
    exposes query, comparison, and validation helpers.  The registry is
    pre-populated with well-known models; callers may register additional
    fingerprints at runtime via :meth:`register`.

    Example::

        fp = ProviderFingerprinter()
        print(fp.supports("gpt-4o", ProviderCapability.VISION))
        # True
    """

    def __init__(self) -> None:
        """Initialize with the built-in model registry."""
        self._registry: dict[str, ModelFingerprint] = {}
        for fp in _BUILTIN_FINGERPRINTS:
            self._registry[fp.model_id] = fp
        logger.debug(
            "fingerprinter_initialized",
            model_count=len(self._registry),
        )

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, fingerprint: ModelFingerprint) -> None:
        """Add or replace a model fingerprint in the registry.

        Args:
            fingerprint: The fingerprint to register.
        """
        self._registry[fingerprint.model_id] = fingerprint
        logger.info(
            "model_fingerprint_registered",
            model_id=fingerprint.model_id,
            provider=fingerprint.provider,
        )

    def unregister(self, model_id: str) -> bool:
        """Remove a model fingerprint from the registry.

        Args:
            model_id: Identifier of the model to remove.

        Returns:
            ``True`` if the model was found and removed.
        """
        if model_id in self._registry:
            del self._registry[model_id]
            logger.info("model_fingerprint_unregistered", model_id=model_id)
            return True
        return False

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_fingerprint(self, model_id: str) -> ModelFingerprint | None:
        """Retrieve the full capability profile for a model.

        Args:
            model_id: Canonical model identifier.

        Returns:
            The :class:`ModelFingerprint`, or ``None`` if not found.
        """
        fp = self._registry.get(model_id)
        if fp is None:
            logger.warning("model_fingerprint_not_found", model_id=model_id)
        return fp

    def supports(self, model_id: str, capability: ProviderCapability) -> bool:
        """Check whether *model_id* supports a given capability.

        Args:
            model_id: Canonical model identifier.
            capability: The capability to check.

        Returns:
            ``True`` if the model is registered **and** has the capability.
        """
        fp = self._registry.get(model_id)
        if fp is None:
            logger.warning(
                "supports_check_unknown_model",
                model_id=model_id,
                capability=capability.value,
            )
            return False
        return fp.has_capability(capability)

    def find_models(
        self,
        requirements: set[ProviderCapability],
        *,
        max_cost_per_1k: float | None = None,
        provider: str | None = None,
    ) -> list[ModelFingerprint]:
        """Find all models that satisfy a set of capability requirements.

        Results are sorted by ``cost_per_1k_input`` ascending (cheapest first).

        Args:
            requirements: Set of capabilities every returned model must have.
            max_cost_per_1k: Optional ceiling on ``cost_per_1k_input``.
            provider: Optional provider filter (e.g. ``"openai"``).

        Returns:
            List of matching :class:`ModelFingerprint` objects, cheapest first.
        """
        frozen_reqs = frozenset(requirements)
        matches: list[ModelFingerprint] = []

        for fp in self._registry.values():
            if not frozen_reqs.issubset(fp.capabilities):
                continue
            if max_cost_per_1k is not None and fp.cost_per_1k_input > max_cost_per_1k:
                continue
            if provider is not None and fp.provider != provider:
                continue
            matches.append(fp)

        matches.sort(key=lambda m: m.cost_per_1k_input)

        logger.debug(
            "find_models",
            requirements=[r.value for r in requirements],
            max_cost=max_cost_per_1k,
            provider=provider,
            matches=len(matches),
        )
        return matches

    def get_compatible_fallbacks(
        self,
        model_id: str,
        *,
        max_results: int = 5,
    ) -> list[str]:
        """Find models with similar capabilities suitable as fallbacks.

        The primary model's capabilities form the requirement set.  Results
        are ordered by the number of *extra* shared capabilities (descending),
        then by cost (ascending).

        Args:
            model_id: The model to find fallbacks for.
            max_results: Maximum number of fallback IDs to return.

        Returns:
            List of model IDs (excluding *model_id* itself).
        """
        primary = self._registry.get(model_id)
        if primary is None:
            logger.warning(
                "fallback_lookup_unknown_model",
                model_id=model_id,
            )
            return []

        primary_caps = primary.capabilities
        scored: list[tuple[int, float, str]] = []

        for fp in self._registry.values():
            if fp.model_id == model_id:
                continue
            # Must have at least all capabilities of the primary
            if not primary_caps.issubset(fp.capabilities):
                continue
            extra = len(fp.capabilities - primary_caps)
            scored.append((extra, fp.cost_per_1k_input, fp.model_id))

        # Sort: more extra caps first, then cheaper
        scored.sort(key=lambda t: (-t[0], t[1]))

        result = [mid for _, _, mid in scored[:max_results]]
        logger.debug(
            "compatible_fallbacks",
            model_id=model_id,
            fallback_count=len(result),
        )
        return result

    def compare(self, model_a: str, model_b: str) -> dict[str, object]:
        """Produce a side-by-side comparison of two models.

        Args:
            model_a: First model ID.
            model_b: Second model ID.

        Returns:
            Dictionary with keys ``model_a``, ``model_b``,
            ``capabilities_only_a``, ``capabilities_only_b``,
            ``capabilities_shared``, ``context_window``, ``max_output``,
            ``cost_input``, ``cost_output``, ``latency``.

        Raises:
            ValueError: If either model is not in the registry.
        """
        fp_a = self._registry.get(model_a)
        fp_b = self._registry.get(model_b)

        if fp_a is None:
            raise ValueError(f"Unknown model: {model_a}")
        if fp_b is None:
            raise ValueError(f"Unknown model: {model_b}")

        caps_a = set(fp_a.capabilities)
        caps_b = set(fp_b.capabilities)

        return {
            "model_a": model_a,
            "model_b": model_b,
            "capabilities_only_a": sorted(c.value for c in caps_a - caps_b),
            "capabilities_only_b": sorted(c.value for c in caps_b - caps_a),
            "capabilities_shared": sorted(c.value for c in caps_a & caps_b),
            "context_window": {
                model_a: fp_a.max_context_window,
                model_b: fp_b.max_context_window,
            },
            "max_output": {
                model_a: fp_a.max_output_tokens,
                model_b: fp_b.max_output_tokens,
            },
            "cost_input": {
                model_a: fp_a.cost_per_1k_input,
                model_b: fp_b.cost_per_1k_input,
            },
            "cost_output": {
                model_a: fp_a.cost_per_1k_output,
                model_b: fp_b.cost_per_1k_output,
            },
            "latency_ms": {
                model_a: fp_a.typical_latency_ms,
                model_b: fp_b.typical_latency_ms,
            },
        }

    def validate_request(
        self,
        model_id: str,
        **kwargs: object,
    ) -> list[str]:
        """Validate request parameters against a model's known capabilities.

        This does **not** make any API calls; it only checks parameter
        compatibility against the registry.

        Args:
            model_id: Target model.
            **kwargs: Request keyword arguments to validate.  Recognised
                keys: ``temperature``, ``top_p``, ``stop``, ``frequency_penalty``,
                ``presence_penalty``, ``tools``, ``response_format``, ``logprobs``,
                ``seed``, ``stream``.

        Returns:
            List of human-readable warning strings.  Empty means all good.
        """
        fp = self._registry.get(model_id)
        if fp is None:
            return [f"Unknown model '{model_id}' — cannot validate parameters."]

        warnings: list[str] = []

        # Parameter → capability / flag mapping
        _param_checks: list[tuple[str, str, bool]] = [
            ("temperature", "temperature", fp.supports_temperature),
            ("top_p", "top_p", fp.supports_top_p),
            ("stop", "stop sequences", fp.supports_stop_sequences),
            ("frequency_penalty", "frequency_penalty", fp.supports_frequency_penalty),
            ("presence_penalty", "presence_penalty", fp.supports_presence_penalty),
        ]

        for param_key, display, supported in _param_checks:
            if param_key in kwargs and not supported:
                warnings.append(
                    f"Parameter '{display}' is not supported by {model_id}."
                )

        # Capability-gated parameters
        if "tools" in kwargs and not fp.has_capability(ProviderCapability.TOOL_CALLING):
            warnings.append(f"{model_id} does not support tool calling.")

        if "response_format" in kwargs:
            rf = kwargs["response_format"]
            if isinstance(rf, dict) and rf.get("type") == "json_object" and not fp.has_capability(ProviderCapability.JSON_MODE):
                warnings.append(f"{model_id} does not support JSON mode.")

        if "logprobs" in kwargs and not fp.has_capability(ProviderCapability.LOGPROBS):
            warnings.append(f"{model_id} does not support logprobs.")

        if "seed" in kwargs and not fp.has_capability(ProviderCapability.SEED_CONTROL):
            warnings.append(f"{model_id} does not support seed control.")

        if "stream" in kwargs and kwargs["stream"] is True and not fp.has_capability(ProviderCapability.STREAMING):
            warnings.append(f"{model_id} does not support streaming.")

        # Token-budget checks
        max_tokens_value = kwargs.get("max_tokens")
        if max_tokens_value is not None and isinstance(max_tokens_value, (int, float)) and int(max_tokens_value) > fp.max_output_tokens:
                warnings.append(
                    f"Requested max_tokens ({int(max_tokens_value)}) exceeds "
                    f"{model_id}'s limit of {fp.max_output_tokens}."
                )

        logger.debug(
            "validate_request",
            model_id=model_id,
            param_count=len(kwargs),
            warning_count=len(warnings),
        )
        return warnings

    def get_provider_summary(self) -> dict[str, dict[str, object]]:
        """Summarize all registered providers and their models.

        Returns:
            Dictionary keyed by provider name, each value containing
            ``model_count``, ``models`` (list of IDs), ``capabilities``
            (union of all model capabilities), and ``cost_range``
            (min/max input cost per 1k tokens).
        """
        provider_data: dict[str, list[ModelFingerprint]] = {}
        for fp in self._registry.values():
            provider_data.setdefault(fp.provider, []).append(fp)

        summary: dict[str, dict[str, object]] = {}
        for prov, fps in sorted(provider_data.items()):
            all_caps: set[ProviderCapability] = set()
            costs: list[float] = []
            model_ids: list[str] = []

            for fp in fps:
                all_caps.update(fp.capabilities)
                costs.append(fp.cost_per_1k_input)
                model_ids.append(fp.model_id)

            summary[prov] = {
                "model_count": len(fps),
                "models": sorted(model_ids),
                "capabilities": sorted(c.value for c in all_caps),
                "cost_range": {
                    "min_per_1k_input": min(costs) if costs else 0.0,
                    "max_per_1k_input": max(costs) if costs else 0.0,
                },
            }

        return summary

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    @property
    def model_ids(self) -> list[str]:
        """Return all registered model IDs, sorted alphabetically."""
        return sorted(self._registry.keys())

    @property
    def providers(self) -> list[str]:
        """Return all distinct provider names, sorted alphabetically."""
        return sorted({fp.provider for fp in self._registry.values()})

    def __len__(self) -> int:
        """Return the number of registered models."""
        return len(self._registry)

    def __contains__(self, model_id: str) -> bool:
        """Check if a model is in the registry."""
        return model_id in self._registry
