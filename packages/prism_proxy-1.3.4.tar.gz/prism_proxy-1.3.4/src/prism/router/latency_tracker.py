"""Latency-aware routing — track P50/P95/P99 per model and provider.

Records response latencies and exposes percentile statistics that the
model selector uses to break ties: when two models have similar
quality/cost scores, the faster model wins.

Also detects latency spikes (P95 > 3x P50) and temporarily deprioritises
models that are experiencing degraded performance.

Data structure: rolling window of the last N latencies per model,
stored in-memory with periodic flush to SQLite for persistence across
sessions.
"""

from __future__ import annotations

import bisect
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field

import structlog

logger = structlog.get_logger(__name__)

# Rolling window size per model
_WINDOW_SIZE = 200

# Spike detection: P95 > multiplier x P50 → degraded
_SPIKE_MULTIPLIER = 3.0

# Minimum samples before percentile stats are meaningful
_MIN_SAMPLES = 5


@dataclass(frozen=True)
class LatencyStats:
    """Percentile latency statistics for a model.

    Attributes:
        model: Model identifier.
        p50_ms: Median latency in milliseconds.
        p95_ms: 95th percentile latency.
        p99_ms: 99th percentile latency.
        avg_ms: Mean latency.
        min_ms: Minimum observed latency.
        max_ms: Maximum observed latency.
        sample_count: Number of latency samples.
        is_degraded: True if P95 indicates a latency spike.
        ttfb_p50_ms: Median time-to-first-byte (streaming).
    """

    model: str
    p50_ms: float
    p95_ms: float
    p99_ms: float
    avg_ms: float
    min_ms: float
    max_ms: float
    sample_count: int
    is_degraded: bool
    ttfb_p50_ms: float = 0.0


@dataclass
class _ModelWindow:
    """Rolling window of latency samples for one model."""

    latencies: list[float] = field(default_factory=list)
    sorted_latencies: list[float] = field(default_factory=list)
    ttfb_latencies: list[float] = field(default_factory=list)
    last_updated: float = 0.0

    def add(self, latency_ms: float, ttfb_ms: float = 0.0) -> None:
        """Add a latency sample, evicting oldest if at capacity."""
        self.latencies.append(latency_ms)
        bisect.insort(self.sorted_latencies, latency_ms)

        if ttfb_ms > 0:
            self.ttfb_latencies.append(ttfb_ms)

        # Evict oldest
        if len(self.latencies) > _WINDOW_SIZE:
            evicted = self.latencies.pop(0)
            idx = bisect.bisect_left(self.sorted_latencies, evicted)
            if idx < len(self.sorted_latencies) and self.sorted_latencies[idx] == evicted:
                self.sorted_latencies.pop(idx)

        if len(self.ttfb_latencies) > _WINDOW_SIZE:
            self.ttfb_latencies.pop(0)

        self.last_updated = time.monotonic()


class LatencyTracker:
    """Track and report per-model latency percentiles.

    Thread-safe.  Records latencies from completion calls and exposes
    percentile statistics used by the model selector for tie-breaking
    and spike detection.

    Usage::

        tracker = LatencyTracker()
        tracker.record("gpt-4o", latency_ms=450.0, ttfb_ms=120.0)
        stats = tracker.get_stats("gpt-4o")
        print(f"P50: {stats.p50_ms}ms, degraded: {stats.is_degraded}")
    """

    def __init__(self) -> None:
        self._windows: dict[str, _ModelWindow] = defaultdict(_ModelWindow)
        self._lock = threading.Lock()

    def record(
        self,
        model: str,
        latency_ms: float,
        ttfb_ms: float = 0.0,
    ) -> None:
        """Record a latency observation.

        Args:
            model: LiteLLM model identifier.
            latency_ms: Total request latency in milliseconds.
            ttfb_ms: Time-to-first-byte for streaming (0 if non-streaming).
        """
        with self._lock:
            self._windows[model].add(latency_ms, ttfb_ms)

    def get_stats(self, model: str) -> LatencyStats | None:
        """Get latency statistics for a model.

        Args:
            model: LiteLLM model identifier.

        Returns:
            LatencyStats if enough samples exist, else None.
        """
        with self._lock:
            window = self._windows.get(model)
            if window is None or len(window.sorted_latencies) < _MIN_SAMPLES:
                return None
            return self._compute_stats(model, window)

    def get_all_stats(self) -> list[LatencyStats]:
        """Get latency statistics for all tracked models.

        Returns:
            List of LatencyStats for models with enough samples.
        """
        results: list[LatencyStats] = []
        with self._lock:
            for model, window in self._windows.items():
                if len(window.sorted_latencies) >= _MIN_SAMPLES:
                    results.append(self._compute_stats(model, window))
        return results

    def get_p50(self, model: str) -> float | None:
        """Quick P50 lookup for routing decisions.

        Args:
            model: LiteLLM model identifier.

        Returns:
            P50 latency in ms, or None if insufficient data.
        """
        with self._lock:
            window = self._windows.get(model)
            if window is None or len(window.sorted_latencies) < _MIN_SAMPLES:
                return None
            return self._percentile(window.sorted_latencies, 0.5)

    def is_degraded(self, model: str) -> bool:
        """Check if a model is experiencing a latency spike.

        Args:
            model: LiteLLM model identifier.

        Returns:
            True if P95 > SPIKE_MULTIPLIER x P50.
        """
        stats = self.get_stats(model)
        return stats.is_degraded if stats else False

    def get_fastest_model(self, candidates: list[str]) -> str | None:
        """Return the fastest candidate by P50 latency.

        Args:
            candidates: List of model identifiers to compare.

        Returns:
            Model with lowest P50, or None if no data.
        """
        best_model: str | None = None
        best_p50 = float("inf")

        with self._lock:
            for model in candidates:
                window = self._windows.get(model)
                if window and len(window.sorted_latencies) >= _MIN_SAMPLES:
                    p50 = self._percentile(window.sorted_latencies, 0.5)
                    if p50 < best_p50:
                        best_p50 = p50
                        best_model = model

        return best_model

    def get_routing_bonus(self, model: str) -> float:
        """Get a routing score bonus/penalty based on latency.

        Returns a multiplier between 0.5 (very slow/degraded) and 1.2 (very fast).
        Used by the selector to adjust rank scores.

        Args:
            model: LiteLLM model identifier.

        Returns:
            Multiplier for the model's rank score.
        """
        stats = self.get_stats(model)
        if stats is None:
            return 1.0  # No data → neutral

        if stats.is_degraded:
            return 0.7  # Penalise degraded models

        # Bonus for low latency, penalty for high
        if stats.p50_ms < 500:
            return 1.15
        if stats.p50_ms < 1000:
            return 1.05
        if stats.p50_ms < 3000:
            return 1.0
        if stats.p50_ms < 5000:
            return 0.9
        return 0.8

    def clear(self, model: str | None = None) -> None:
        """Clear latency data.

        Args:
            model: If specified, clear only this model.  Otherwise clear all.
        """
        with self._lock:
            if model:
                self._windows.pop(model, None)
            else:
                self._windows.clear()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _percentile(sorted_values: list[float], p: float) -> float:
        """Compute percentile from pre-sorted values."""
        if not sorted_values:
            return 0.0
        k = (len(sorted_values) - 1) * p
        f = int(k)
        c = f + 1
        if c >= len(sorted_values):
            return sorted_values[-1]
        d = k - f
        return sorted_values[f] * (1 - d) + sorted_values[c] * d

    def _compute_stats(self, model: str, window: _ModelWindow) -> LatencyStats:
        """Compute full stats from a window (caller holds lock)."""
        sv = window.sorted_latencies
        p50 = self._percentile(sv, 0.5)
        p95 = self._percentile(sv, 0.95)
        p99 = self._percentile(sv, 0.99)
        avg = sum(sv) / len(sv)

        # TTFB
        ttfb_p50 = 0.0
        if len(window.ttfb_latencies) >= _MIN_SAMPLES:
            sorted_ttfb = sorted(window.ttfb_latencies)
            ttfb_p50 = self._percentile(sorted_ttfb, 0.5)

        is_degraded = p95 > _SPIKE_MULTIPLIER * p50 if p50 > 0 else False

        return LatencyStats(
            model=model,
            p50_ms=round(p50, 1),
            p95_ms=round(p95, 1),
            p99_ms=round(p99, 1),
            avg_ms=round(avg, 1),
            min_ms=round(sv[0], 1),
            max_ms=round(sv[-1], 1),
            sample_count=len(sv),
            is_degraded=is_degraded,
            ttfb_p50_ms=round(ttfb_p50, 1),
        )
