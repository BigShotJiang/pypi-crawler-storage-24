"""Request deduplication and batching for the Prism routing engine.

Detects identical and near-identical concurrent requests, coalesces them
so only one API call is made, and groups compatible requests into batches
for providers that support batch APIs.  All operations are thread-safe
using async locks and designed to work in a fully asynchronous pipeline.

Features:
    1. Content-hash fingerprinting (prompt + model + temperature)
    2. Pending request coalescing (waiters share an in-flight result)
    3. Near-duplicate detection via configurable similarity threshold
    4. Request batching with per-provider size limits
    5. Batch timeout to avoid waiting indefinitely
    6. TTL on pending entries to prevent deadlocks from slow requests
    7. Comprehensive statistics tracking

Usage::

    dedup = RequestDeduplicator()
    fp = dedup.fingerprint("gpt-4o", "Explain quantum computing", 0.7)

    # Submit a request — identical concurrent requests will coalesce.
    result = await dedup.submit(fp, execute_fn=my_api_call)

    # Batching
    batcher = RequestBatcher(BatchConfig(max_batch_size=10))
    batch = await batcher.add(fp, request_payload)
    if batch is not None:
        results = await execute_batch(batch.items)
"""

from __future__ import annotations

import asyncio
import hashlib
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Default configuration constants
# ---------------------------------------------------------------------------

_DEFAULT_MAX_BATCH_SIZE: int = 10
_DEFAULT_BATCH_TIMEOUT_MS: int = 500
_DEFAULT_DEDUP_SIMILARITY: float = 0.95
_DEFAULT_PENDING_TTL_SECONDS: float = 120.0


# ======================================================================
# Data structures
# ======================================================================


@dataclass(frozen=True)
class RequestFingerprint:
    """Immutable fingerprint for a single API request.

    Two requests with the same fingerprint are considered semantically
    identical and can be deduplicated (one call, shared result).

    Attributes:
        hash: SHA-256 hex digest of the canonical request content.
        prompt_hash: SHA-256 hex digest of the prompt text alone.
        model: Target model identifier (e.g. ``gpt-4o``).
        temperature: Sampling temperature (``None`` means default).
        prompt_text: Raw prompt text, retained for near-dedup similarity.
    """

    hash: str
    prompt_hash: str
    model: str
    temperature: float | None
    prompt_text: str = field(repr=False, compare=False, hash=False)


@dataclass
class PendingRequest:
    """Tracks an in-flight request that other callers may wait on.

    Attributes:
        fingerprint: The request fingerprint.
        future: Asyncio future that will hold the result.
        timestamp: Monotonic time when the request was registered.
        ttl_seconds: Maximum seconds to keep this entry alive.
        waiter_count: Number of callers waiting on this result.
    """

    fingerprint: RequestFingerprint
    future: asyncio.Future[Any]
    timestamp: float
    ttl_seconds: float = _DEFAULT_PENDING_TTL_SECONDS
    waiter_count: int = 1

    @property
    def is_expired(self) -> bool:
        """Return ``True`` if the pending entry has exceeded its TTL."""
        return (time.monotonic() - self.timestamp) > self.ttl_seconds


@dataclass
class DedupStats:
    """Aggregate deduplication and batching statistics.

    Attributes:
        dedup_count: Number of exact-duplicate requests coalesced.
        near_dedup_count: Number of near-duplicate requests coalesced.
        batch_count: Number of batches formed.
        total_requests: Total requests submitted.
        saved_requests: Requests that did not require a separate API call.
        saved_cost_usd: Estimated USD saved via deduplication.
    """

    dedup_count: int = 0
    near_dedup_count: int = 0
    batch_count: int = 0
    total_requests: int = 0
    saved_requests: int = 0
    saved_cost_usd: float = 0.0

    def record_dedup(self, *, near: bool = False, estimated_cost: float = 0.0) -> None:
        """Record a deduplication event.

        Args:
            near: ``True`` if this was a near-duplicate (vs. exact).
            estimated_cost: Estimated USD cost of the saved request.
        """
        if near:
            self.near_dedup_count += 1
        else:
            self.dedup_count += 1
        self.saved_requests += 1
        self.saved_cost_usd += estimated_cost

    def record_batch(self, batch_size: int) -> None:
        """Record a batch formation.

        Args:
            batch_size: Number of requests in the batch.
        """
        self.batch_count += 1
        # Batching saves (batch_size - 1) individual calls
        saved = max(0, batch_size - 1)
        self.saved_requests += saved

    def record_request(self) -> None:
        """Record an incoming request."""
        self.total_requests += 1

    def to_dict(self) -> dict[str, int | float]:
        """Serialize statistics to a plain dictionary.

        Returns:
            Dictionary with all statistics fields.
        """
        return {
            "dedup_count": self.dedup_count,
            "near_dedup_count": self.near_dedup_count,
            "batch_count": self.batch_count,
            "total_requests": self.total_requests,
            "saved_requests": self.saved_requests,
            "saved_cost_usd": round(self.saved_cost_usd, 6),
        }


# ======================================================================
# Batching
# ======================================================================


@dataclass
class BatchConfig:
    """Configuration for the request batcher.

    Attributes:
        max_batch_size: Maximum requests per batch.
        batch_timeout_ms: Milliseconds to wait for a batch to fill.
        dedup_similarity: Minimum similarity ratio (0.0-1.0) for
            near-duplicate detection.
        pending_ttl_seconds: TTL for pending entries in seconds.
    """

    max_batch_size: int = _DEFAULT_MAX_BATCH_SIZE
    batch_timeout_ms: int = _DEFAULT_BATCH_TIMEOUT_MS
    dedup_similarity: float = _DEFAULT_DEDUP_SIMILARITY
    pending_ttl_seconds: float = _DEFAULT_PENDING_TTL_SECONDS

    def __post_init__(self) -> None:
        """Validate configuration values."""
        if self.max_batch_size < 1:
            raise ValueError("max_batch_size must be >= 1")
        if self.batch_timeout_ms < 0:
            raise ValueError("batch_timeout_ms must be >= 0")
        if not 0.0 <= self.dedup_similarity <= 1.0:
            raise ValueError("dedup_similarity must be between 0.0 and 1.0")
        if self.pending_ttl_seconds <= 0:
            raise ValueError("pending_ttl_seconds must be > 0")


@dataclass
class Batch:
    """A group of compatible requests ready for batch execution.

    Attributes:
        items: List of ``(fingerprint, payload)`` tuples in the batch.
        model: The common model for all items.
        created_at: Monotonic timestamp when the batch was created.
        timeout_ms: Milliseconds before the batch should be dispatched.
    """

    items: list[tuple[RequestFingerprint, dict[str, Any]]]
    model: str
    created_at: float
    timeout_ms: int

    @property
    def size(self) -> int:
        """Return the number of items in the batch."""
        return len(self.items)

    @property
    def is_timed_out(self) -> bool:
        """Return ``True`` if the batch has exceeded its timeout."""
        elapsed_ms = (time.monotonic() - self.created_at) * 1000.0
        return elapsed_ms >= self.timeout_ms


class RequestBatcher:
    """Groups compatible requests into batches for batch API calls.

    Requests are batched by model. A batch is "ready" when either
    the max size is reached or the timeout has elapsed.
    """

    def __init__(self, config: BatchConfig | None = None) -> None:
        """Initialize the batcher.

        Args:
            config: Batch configuration. Uses defaults if ``None``.
        """
        self._config = config or BatchConfig()
        self._batches: dict[str, Batch] = {}
        self._lock = asyncio.Lock()
        self._stats = DedupStats()
        logger.debug(
            "request_batcher_initialized",
            max_batch_size=self._config.max_batch_size,
            batch_timeout_ms=self._config.batch_timeout_ms,
        )

    @property
    def stats(self) -> DedupStats:
        """Return batching statistics."""
        return self._stats

    @property
    def pending_batch_count(self) -> int:
        """Return the number of pending (incomplete) batches."""
        return len(self._batches)

    async def add(
        self,
        fingerprint: RequestFingerprint,
        payload: dict[str, Any],
    ) -> Batch | None:
        """Add a request to the appropriate batch.

        If the batch reaches ``max_batch_size`` after this addition,
        the full batch is returned and removed from the pending set.
        Otherwise returns ``None`` (caller should wait for timeout).

        Args:
            fingerprint: The request fingerprint.
            payload: The full request payload dictionary.

        Returns:
            A ready :class:`Batch` if the batch is full, else ``None``.
        """
        async with self._lock:
            self._stats.record_request()
            model = fingerprint.model

            if model not in self._batches:
                self._batches[model] = Batch(
                    items=[],
                    model=model,
                    created_at=time.monotonic(),
                    timeout_ms=self._config.batch_timeout_ms,
                )

            batch = self._batches[model]
            batch.items.append((fingerprint, payload))

            if batch.size >= self._config.max_batch_size:
                ready_batch = self._batches.pop(model)
                self._stats.record_batch(ready_batch.size)
                logger.info(
                    "batch_ready_size_limit",
                    model=model,
                    batch_size=ready_batch.size,
                )
                return ready_batch

            return None

    async def flush(self, model: str | None = None) -> list[Batch]:
        """Flush pending batches, returning them for execution.

        Args:
            model: If given, flush only the batch for this model.
                Otherwise flush all pending batches.

        Returns:
            List of batches that were flushed.
        """
        async with self._lock:
            flushed: list[Batch] = []

            if model is not None:
                batch = self._batches.pop(model, None)
                if batch is not None and batch.size > 0:
                    self._stats.record_batch(batch.size)
                    flushed.append(batch)
            else:
                for m in list(self._batches):
                    batch = self._batches.pop(m)
                    if batch.size > 0:
                        self._stats.record_batch(batch.size)
                        flushed.append(batch)

            if flushed:
                logger.info(
                    "batches_flushed",
                    count=len(flushed),
                    total_items=sum(b.size for b in flushed),
                )
            return flushed

    async def flush_timed_out(self) -> list[Batch]:
        """Flush only batches whose timeout has elapsed.

        Returns:
            List of timed-out batches.
        """
        async with self._lock:
            flushed: list[Batch] = []
            for m in list(self._batches):
                if self._batches[m].is_timed_out:
                    batch = self._batches.pop(m)
                    if batch.size > 0:
                        self._stats.record_batch(batch.size)
                        flushed.append(batch)

            if flushed:
                logger.debug(
                    "timed_out_batches_flushed",
                    count=len(flushed),
                )
            return flushed

    async def clear(self) -> None:
        """Discard all pending batches without flushing."""
        async with self._lock:
            self._batches.clear()


# ======================================================================
# Deduplicator
# ======================================================================


class RequestDeduplicator:
    """Main deduplication engine for concurrent API requests.

    Maintains a map of in-flight requests indexed by fingerprint.
    When a new request arrives whose fingerprint matches (exactly or
    near-match) an existing in-flight request, the new caller waits
    on the same future instead of issuing a redundant API call.
    """

    def __init__(self, config: BatchConfig | None = None) -> None:
        """Initialize the deduplicator.

        Args:
            config: Configuration for dedup similarity, TTL, etc.
        """
        self._config = config or BatchConfig()
        self._pending: dict[str, PendingRequest] = {}
        self._lock = asyncio.Lock()
        self._stats = DedupStats()
        logger.debug(
            "request_deduplicator_initialized",
            similarity_threshold=self._config.dedup_similarity,
            pending_ttl=self._config.pending_ttl_seconds,
        )

    @property
    def stats(self) -> DedupStats:
        """Return deduplication statistics."""
        return self._stats

    @property
    def pending_count(self) -> int:
        """Return the number of currently pending requests."""
        return len(self._pending)

    # ------------------------------------------------------------------
    # Fingerprinting
    # ------------------------------------------------------------------

    @staticmethod
    def fingerprint(
        model: str,
        prompt: str,
        temperature: float | None = None,
    ) -> RequestFingerprint:
        """Create a fingerprint for a request.

        The hash combines model, prompt, and temperature into a single
        deterministic SHA-256 digest.

        Args:
            model: Target model identifier.
            prompt: The prompt text.
            temperature: Sampling temperature (or ``None`` for default).

        Returns:
            A frozen :class:`RequestFingerprint`.
        """
        prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()

        # Canonical string: model|temperature|prompt
        temp_str = f"{temperature:.6f}" if temperature is not None else "default"
        canonical = f"{model}|{temp_str}|{prompt}"
        full_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

        return RequestFingerprint(
            hash=full_hash,
            prompt_hash=prompt_hash,
            model=model,
            temperature=temperature,
            prompt_text=prompt,
        )

    # ------------------------------------------------------------------
    # Similarity
    # ------------------------------------------------------------------

    def _compute_similarity(self, a: str, b: str) -> float:
        """Compute similarity ratio between two strings.

        Uses :class:`~difflib.SequenceMatcher` for efficient
        near-duplicate detection.

        Args:
            a: First string.
            b: Second string.

        Returns:
            Similarity ratio between 0.0 and 1.0.
        """
        return SequenceMatcher(None, a, b).ratio()

    def _find_exact_match(self, fingerprint: RequestFingerprint) -> PendingRequest | None:
        """Find an exact pending match for the fingerprint.

        Args:
            fingerprint: The fingerprint to look up.

        Returns:
            The matching :class:`PendingRequest`, or ``None``.
        """
        pending = self._pending.get(fingerprint.hash)
        if pending is not None and not pending.is_expired:
            return pending
        return None

    def _find_near_match(self, fingerprint: RequestFingerprint) -> PendingRequest | None:
        """Find a near-duplicate pending request.

        Only checks requests targeting the same model and temperature.

        Args:
            fingerprint: The fingerprint to compare against.

        Returns:
            The best matching :class:`PendingRequest` above the
            similarity threshold, or ``None``.
        """
        threshold = self._config.dedup_similarity
        best_match: PendingRequest | None = None
        best_similarity: float = 0.0

        for pending in self._pending.values():
            if pending.is_expired:
                continue
            if pending.fingerprint.model != fingerprint.model:
                continue
            if pending.fingerprint.temperature != fingerprint.temperature:
                continue
            # Skip exact matches (handled separately)
            if pending.fingerprint.hash == fingerprint.hash:
                continue

            similarity = self._compute_similarity(
                fingerprint.prompt_text,
                pending.fingerprint.prompt_text,
            )
            if similarity >= threshold and similarity > best_similarity:
                best_similarity = similarity
                best_match = pending

        return best_match

    # ------------------------------------------------------------------
    # Submission
    # ------------------------------------------------------------------

    async def submit(
        self,
        fingerprint: RequestFingerprint,
        execute_fn: Callable[[], Coroutine[Any, Any, Any]],
        *,
        estimated_cost: float = 0.0,
    ) -> Any:
        """Submit a request, deduplicating against in-flight requests.

        If an identical or near-identical request is already pending,
        the caller waits on that result instead of making a new call.
        Otherwise, *execute_fn* is invoked and the result shared with
        any future callers that arrive before it completes.

        Args:
            fingerprint: The request fingerprint.
            execute_fn: Async callable that performs the actual API call.
            estimated_cost: Estimated USD cost of this request (for stats).

        Returns:
            The result from *execute_fn* (or the shared result if deduped).
        """
        shared_future: asyncio.Future[Any] | None = None
        is_owner = False

        async with self._lock:
            self._stats.record_request()
            self._purge_expired()

            # Check for exact match
            exact = self._find_exact_match(fingerprint)
            if exact is not None:
                exact.waiter_count += 1
                self._stats.record_dedup(near=False, estimated_cost=estimated_cost)
                logger.info(
                    "request_deduplicated_exact",
                    model=fingerprint.model,
                    waiters=exact.waiter_count,
                )
                shared_future = exact.future

            # Check for near match (only if no exact match)
            if shared_future is None:
                near = self._find_near_match(fingerprint)
                if near is not None:
                    near.waiter_count += 1
                    self._stats.record_dedup(near=True, estimated_cost=estimated_cost)
                    logger.info(
                        "request_deduplicated_near",
                        model=fingerprint.model,
                        waiters=near.waiter_count,
                    )
                    shared_future = near.future

            # No match — register as new pending request
            if shared_future is None:
                is_owner = True
                loop = asyncio.get_running_loop()
                shared_future = loop.create_future()
                pending = PendingRequest(
                    fingerprint=fingerprint,
                    future=shared_future,
                    timestamp=time.monotonic(),
                    ttl_seconds=self._config.pending_ttl_seconds,
                )
                self._pending[fingerprint.hash] = pending

        # Lock released — either await the shared future or execute
        if is_owner:
            try:
                result = await execute_fn()
                shared_future.set_result(result)
            except BaseException as exc:
                shared_future.set_exception(exc)
                raise
            finally:
                async with self._lock:
                    self._pending.pop(fingerprint.hash, None)
            return result

        return await shared_future

    # ------------------------------------------------------------------
    # Housekeeping
    # ------------------------------------------------------------------

    def _purge_expired(self) -> int:
        """Remove pending entries that have exceeded their TTL.

        Returns:
            Number of entries purged.
        """
        expired_keys = [
            key for key, pending in self._pending.items() if pending.is_expired
        ]
        for key in expired_keys:
            pending = self._pending.pop(key)
            if not pending.future.done():
                pending.future.set_exception(
                    TimeoutError(
                        f"Pending request expired after {pending.ttl_seconds}s"
                    )
                )
            logger.warning(
                "pending_request_expired",
                model=pending.fingerprint.model,
                ttl=pending.ttl_seconds,
            )
        return len(expired_keys)

    async def clear(self) -> None:
        """Cancel all pending requests and clear state."""
        async with self._lock:
            for pending in self._pending.values():
                if not pending.future.done():
                    pending.future.cancel()
            self._pending.clear()
            logger.info("deduplicator_cleared")

    def reset_stats(self) -> None:
        """Reset all statistics to zero."""
        self._stats = DedupStats()
