"""Intelligent load balancer — distributes requests across providers.

Implements multiple load-balancing strategies for distributing AI requests
across available providers while respecting rate limits, health status,
and cost constraints.

Strategies:
    1. Round-robin with weighted distribution
    2. Least-connections (fewest in-flight requests)
    3. Latency-based (route to fastest healthy provider)
    4. Cost-optimized (cheapest provider that meets quality threshold)
    5. Adaptive (learns optimal distribution from outcomes)

Usage::

    lb = LoadBalancer(strategy=BalancingStrategy.ADAPTIVE)
    lb.register("openai", weight=3, cost_per_1k=0.03)
    lb.register("anthropic", weight=2, cost_per_1k=0.015)
    provider = lb.select(task_type="code")

"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from enum import Enum

import structlog

logger = structlog.get_logger(__name__)


class BalancingStrategy(Enum):
    """Load balancing strategy."""

    ROUND_ROBIN = "round_robin"
    LEAST_CONNECTIONS = "least_connections"
    LATENCY_BASED = "latency_based"
    COST_OPTIMIZED = "cost_optimized"
    ADAPTIVE = "adaptive"
    STICKY = "sticky"


@dataclass
class ProviderEndpoint:
    """A registered provider endpoint.

    Attributes:
        name: Provider identifier.
        weight: Relative weight for weighted round-robin.
        cost_per_1k_input: Cost per 1K input tokens.
        cost_per_1k_output: Cost per 1K output tokens.
        max_concurrent: Maximum concurrent requests.
        active_connections: Current in-flight requests.
        total_requests: Lifetime request count.
        total_failures: Lifetime failure count.
        avg_latency_ms: EWMA of response latency.
        last_failure_time: Timestamp of most recent failure.
        is_healthy: Whether the provider is considered healthy.
        quality_score: Average quality score (0-1).
        models: Models available on this provider.
    """

    name: str
    weight: int = 1
    cost_per_1k_input: float = 0.01
    cost_per_1k_output: float = 0.03
    max_concurrent: int = 10
    active_connections: int = 0
    total_requests: int = 0
    total_failures: int = 0
    avg_latency_ms: float = 500.0
    last_failure_time: float = 0.0
    is_healthy: bool = True
    quality_score: float = 0.8
    models: list[str] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Success rate as a fraction."""
        if self.total_requests == 0:
            return 1.0
        return 1.0 - (self.total_failures / self.total_requests)

    @property
    def utilization(self) -> float:
        """Current utilization as a fraction."""
        if self.max_concurrent == 0:
            return 1.0
        return self.active_connections / self.max_concurrent


@dataclass
class SelectionResult:
    """Result of a load balancer selection.

    Attributes:
        provider: Selected provider name.
        model: Selected model (if applicable).
        strategy_used: Which strategy made the decision.
        score: Selection score/confidence.
        alternatives: Other considered providers.
        reason: Human-readable explanation.
    """

    provider: str
    model: str = ""
    strategy_used: BalancingStrategy = BalancingStrategy.ROUND_ROBIN
    score: float = 0.0
    alternatives: list[str] = field(default_factory=list)
    reason: str = ""


@dataclass
class LoadBalancerStats:
    """Aggregate load balancer statistics.

    Attributes:
        total_selections: Total selection calls.
        selections_by_strategy: Count per strategy.
        selections_by_provider: Count per provider.
        avg_selection_time_us: Average selection time in microseconds.
        rebalance_count: Number of times weights were rebalanced.
        failover_count: Number of failovers triggered.
    """

    total_selections: int = 0
    selections_by_strategy: dict[str, int] = field(default_factory=dict)
    selections_by_provider: dict[str, int] = field(default_factory=dict)
    avg_selection_time_us: float = 0.0
    rebalance_count: int = 0
    failover_count: int = 0


@dataclass
class LoadBalancerConfig:
    """Load balancer configuration.

    Attributes:
        strategy: Default balancing strategy.
        health_check_interval_s: Seconds between health checks.
        failure_threshold: Failures before marking unhealthy.
        recovery_time_s: Seconds before re-checking an unhealthy provider.
        latency_ewma_alpha: EWMA smoothing factor for latency.
        quality_threshold: Minimum quality to be eligible.
        sticky_session_ttl_s: TTL for sticky session affinity.
        adaptive_learning_rate: How fast adaptive weights change.
    """

    strategy: BalancingStrategy = BalancingStrategy.ADAPTIVE
    health_check_interval_s: float = 60.0
    failure_threshold: int = 5
    recovery_time_s: float = 120.0
    latency_ewma_alpha: float = 0.3
    quality_threshold: float = 0.3
    sticky_session_ttl_s: float = 300.0
    adaptive_learning_rate: float = 0.1


class LoadBalancer:
    """Intelligent multi-strategy load balancer.

    Args:
        config: Load balancer configuration.
    """

    def __init__(self, config: LoadBalancerConfig | None = None) -> None:
        self._config = config or LoadBalancerConfig()
        self._endpoints: dict[str, ProviderEndpoint] = {}
        self._rr_index = 0
        self._stats = LoadBalancerStats()
        self._sticky_map: dict[str, tuple[str, float]] = {}
        self._selection_times: list[float] = []

    def register(
        self,
        name: str,
        weight: int = 1,
        cost_per_1k_input: float = 0.01,
        cost_per_1k_output: float = 0.03,
        max_concurrent: int = 10,
        models: list[str] | None = None,
    ) -> None:
        """Register a provider endpoint.

        Args:
            name: Provider identifier.
            weight: Relative weight for round-robin.
            cost_per_1k_input: Cost per 1K input tokens.
            cost_per_1k_output: Cost per 1K output tokens.
            max_concurrent: Maximum concurrent requests.
            models: Available models on this provider.
        """
        self._endpoints[name] = ProviderEndpoint(
            name=name,
            weight=weight,
            cost_per_1k_input=cost_per_1k_input,
            cost_per_1k_output=cost_per_1k_output,
            max_concurrent=max_concurrent,
            models=models or [],
        )
        logger.debug("provider_registered", name=name, weight=weight)

    def unregister(self, name: str) -> bool:
        """Remove a provider endpoint.

        Args:
            name: Provider to remove.

        Returns:
            True if removed, False if not found.
        """
        if name in self._endpoints:
            del self._endpoints[name]
            return True
        return False

    def select(
        self,
        task_type: str = "",
        model: str = "",
        session_id: str = "",
        strategy: BalancingStrategy | None = None,
    ) -> SelectionResult:
        """Select the best provider for a request.

        Args:
            task_type: Type of task (code, chat, etc.).
            model: Specific model requirement.
            session_id: Session ID for sticky routing.
            strategy: Override the default strategy.

        Returns:
            SelectionResult with chosen provider.
        """
        start = time.perf_counter()
        strat = strategy or self._config.strategy

        # Filter to healthy, available endpoints
        candidates = self._get_candidates(model)
        if not candidates:
            elapsed = (time.perf_counter() - start) * 1_000_000
            self._record_selection_time(elapsed)
            return SelectionResult(
                provider="",
                strategy_used=strat,
                reason="no healthy providers available",
            )

        # Check sticky session first
        if session_id and strat != BalancingStrategy.STICKY:
            sticky = self._check_sticky(session_id)
            if sticky and sticky in self._endpoints and self._endpoints[sticky].is_healthy:
                candidates_with_sticky = [c for c in candidates if c.name == sticky]
                if candidates_with_sticky:
                    result = SelectionResult(
                        provider=sticky,
                        strategy_used=BalancingStrategy.STICKY,
                        score=1.0,
                        reason="sticky session affinity",
                    )
                    self._finalize_selection(result, start, session_id)
                    return result

        # Dispatch to strategy
        if strat == BalancingStrategy.ROUND_ROBIN:
            result = self._select_round_robin(candidates)
        elif strat == BalancingStrategy.LEAST_CONNECTIONS:
            result = self._select_least_connections(candidates)
        elif strat == BalancingStrategy.LATENCY_BASED:
            result = self._select_latency_based(candidates)
        elif strat == BalancingStrategy.COST_OPTIMIZED:
            result = self._select_cost_optimized(candidates, task_type)
        elif strat == BalancingStrategy.ADAPTIVE:
            result = self._select_adaptive(candidates, task_type)
        elif strat == BalancingStrategy.STICKY:
            result = self._select_sticky(candidates, session_id)
        else:
            result = self._select_round_robin(candidates)

        self._finalize_selection(result, start, session_id)
        return result

    def record_success(
        self,
        provider: str,
        latency_ms: float,
        quality: float = 0.8,
    ) -> None:
        """Record a successful request completion.

        Args:
            provider: Provider that handled the request.
            latency_ms: Request latency in milliseconds.
            quality: Quality score of the response (0-1).
        """
        ep = self._endpoints.get(provider)
        if not ep:
            return

        ep.total_requests += 1
        ep.active_connections = max(0, ep.active_connections - 1)

        # EWMA latency update
        alpha = self._config.latency_ewma_alpha
        ep.avg_latency_ms = alpha * latency_ms + (1 - alpha) * ep.avg_latency_ms

        # EWMA quality update
        ep.quality_score = alpha * quality + (1 - alpha) * ep.quality_score

        # Re-enable if was unhealthy
        if not ep.is_healthy:
            ep.is_healthy = True
            logger.info("provider_recovered", provider=provider)

    def record_failure(self, provider: str, latency_ms: float = 0) -> None:
        """Record a failed request.

        Args:
            provider: Provider that failed.
            latency_ms: Request latency before failure.
        """
        ep = self._endpoints.get(provider)
        if not ep:
            return

        ep.total_requests += 1
        ep.total_failures += 1
        ep.active_connections = max(0, ep.active_connections - 1)
        ep.last_failure_time = time.monotonic()

        # Check if we should mark unhealthy
        recent_failure_rate = ep.total_failures / max(ep.total_requests, 1)
        if (
            ep.total_failures >= self._config.failure_threshold
            and recent_failure_rate > 0.5
        ):
            ep.is_healthy = False
            logger.warning("provider_marked_unhealthy", provider=provider)

        self._stats.failover_count += 1

    def record_connection(self, provider: str) -> None:
        """Increment active connection count for a provider.

        Args:
            provider: Provider name.
        """
        ep = self._endpoints.get(provider)
        if ep:
            ep.active_connections += 1

    def get_stats(self) -> LoadBalancerStats:
        """Get load balancer statistics."""
        return self._stats

    def get_endpoint(self, name: str) -> ProviderEndpoint | None:
        """Get endpoint info for a provider."""
        return self._endpoints.get(name)

    def get_all_endpoints(self) -> dict[str, ProviderEndpoint]:
        """Get all registered endpoints."""
        return dict(self._endpoints)

    def reset_stats(self) -> None:
        """Reset all statistics."""
        self._stats = LoadBalancerStats()
        self._selection_times.clear()

    def rebalance(self) -> None:
        """Rebalance weights based on current performance.

        Adjusts weights proportionally to success rate * inverse latency.
        """
        if not self._endpoints:
            return

        for ep in self._endpoints.values():
            if not ep.is_healthy:
                continue
            # Score = success_rate / normalized_latency * quality
            latency_factor = 1000.0 / max(ep.avg_latency_ms, 1.0)
            score = ep.success_rate * latency_factor * ep.quality_score
            new_weight = max(1, int(score * 10))
            ep.weight = new_weight

        self._stats.rebalance_count += 1
        logger.debug("rebalanced", endpoints={
            n: e.weight for n, e in self._endpoints.items()
        })

    # ------------------------------------------------------------------
    # Strategy implementations
    # ------------------------------------------------------------------

    def _select_round_robin(
        self, candidates: list[ProviderEndpoint],
    ) -> SelectionResult:
        """Weighted round-robin selection."""
        # Build weighted list
        weighted: list[ProviderEndpoint] = []
        for c in candidates:
            weighted.extend([c] * c.weight)

        if not weighted:
            return SelectionResult(provider=candidates[0].name)

        self._rr_index = self._rr_index % len(weighted)
        selected = weighted[self._rr_index]
        self._rr_index += 1

        return SelectionResult(
            provider=selected.name,
            strategy_used=BalancingStrategy.ROUND_ROBIN,
            score=selected.weight / max(sum(c.weight for c in candidates), 1),
            alternatives=[c.name for c in candidates if c.name != selected.name],
            reason=f"round-robin index {self._rr_index - 1}, weight={selected.weight}",
        )

    def _select_least_connections(
        self, candidates: list[ProviderEndpoint],
    ) -> SelectionResult:
        """Select provider with fewest active connections."""
        best = min(candidates, key=lambda c: c.active_connections)
        return SelectionResult(
            provider=best.name,
            strategy_used=BalancingStrategy.LEAST_CONNECTIONS,
            score=1.0 - best.utilization,
            alternatives=[c.name for c in candidates if c.name != best.name],
            reason=f"fewest connections: {best.active_connections}/{best.max_concurrent}",
        )

    def _select_latency_based(
        self, candidates: list[ProviderEndpoint],
    ) -> SelectionResult:
        """Select provider with lowest average latency."""
        best = min(candidates, key=lambda c: c.avg_latency_ms)
        return SelectionResult(
            provider=best.name,
            strategy_used=BalancingStrategy.LATENCY_BASED,
            score=1000.0 / max(best.avg_latency_ms, 1.0),
            alternatives=[c.name for c in candidates if c.name != best.name],
            reason=f"lowest latency: {best.avg_latency_ms:.1f}ms",
        )

    def _select_cost_optimized(
        self, candidates: list[ProviderEndpoint], task_type: str,
    ) -> SelectionResult:
        """Select cheapest provider that meets quality threshold."""
        # Filter by quality threshold
        quality_ok = [
            c for c in candidates
            if c.quality_score >= self._config.quality_threshold
        ]
        pool = quality_ok or candidates  # Fall back to all if none meet threshold

        best = min(pool, key=lambda c: c.cost_per_1k_input + c.cost_per_1k_output)
        return SelectionResult(
            provider=best.name,
            strategy_used=BalancingStrategy.COST_OPTIMIZED,
            score=1.0 / max(best.cost_per_1k_input + best.cost_per_1k_output, 0.001),
            alternatives=[c.name for c in pool if c.name != best.name],
            reason=(
                f"cheapest: ${best.cost_per_1k_input + best.cost_per_1k_output:.4f}/1K, "
                f"quality={best.quality_score:.2f}"
            ),
        )

    def _select_adaptive(
        self, candidates: list[ProviderEndpoint], task_type: str,
    ) -> SelectionResult:
        """Adaptive selection combining multiple signals."""
        scores: list[tuple[float, ProviderEndpoint]] = []

        for c in candidates:
            # Composite score: quality * speed * cost-efficiency * reliability
            latency_norm = 1.0 / max(c.avg_latency_ms / 1000.0, 0.01)
            cost_norm = 1.0 / max(c.cost_per_1k_input + c.cost_per_1k_output, 0.001)
            utilization_penalty = 1.0 - (c.utilization * 0.5)

            score = (
                c.quality_score * 0.35
                + min(latency_norm, 5.0) / 5.0 * 0.25
                + min(cost_norm, 200.0) / 200.0 * 0.20
                + c.success_rate * 0.10
                + utilization_penalty * 0.10
            )
            scores.append((score, c))

        scores.sort(key=lambda x: x[0], reverse=True)
        best_score, best = scores[0]

        return SelectionResult(
            provider=best.name,
            strategy_used=BalancingStrategy.ADAPTIVE,
            score=best_score,
            alternatives=[c.name for _, c in scores[1:4]],
            reason=(
                f"adaptive score={best_score:.3f} "
                f"(q={best.quality_score:.2f}, lat={best.avg_latency_ms:.0f}ms, "
                f"cost=${best.cost_per_1k_input:.3f})"
            ),
        )

    def _select_sticky(
        self, candidates: list[ProviderEndpoint], session_id: str,
    ) -> SelectionResult:
        """Sticky session selection using consistent hashing."""
        if not session_id:
            return self._select_adaptive(candidates, "")

        # Consistent hash-based selection
        hash_val = int(hashlib.md5(session_id.encode()).hexdigest(), 16)  # noqa: S324
        idx = hash_val % len(candidates)
        selected = candidates[idx]

        self._sticky_map[session_id] = (selected.name, time.monotonic())

        return SelectionResult(
            provider=selected.name,
            strategy_used=BalancingStrategy.STICKY,
            score=1.0,
            alternatives=[c.name for c in candidates if c.name != selected.name],
            reason=f"sticky hash for session {session_id[:8]}...",
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_candidates(self, model: str) -> list[ProviderEndpoint]:
        """Get healthy, available provider candidates."""
        now = time.monotonic()
        candidates: list[ProviderEndpoint] = []

        for ep in self._endpoints.values():
            # Check health with recovery
            if not ep.is_healthy:
                if now - ep.last_failure_time > self._config.recovery_time_s:
                    ep.is_healthy = True
                    logger.debug("provider_recovery_check", provider=ep.name)
                else:
                    continue

            # Check capacity
            if ep.active_connections >= ep.max_concurrent:
                continue

            # Check model availability
            if model and ep.models and model not in ep.models:
                continue

            candidates.append(ep)

        return candidates

    def _check_sticky(self, session_id: str) -> str | None:
        """Check if there's a sticky session mapping."""
        entry = self._sticky_map.get(session_id)
        if entry is None:
            return None
        provider, ts = entry
        if time.monotonic() - ts > self._config.sticky_session_ttl_s:
            del self._sticky_map[session_id]
            return None
        return provider

    def _finalize_selection(
        self, result: SelectionResult, start: float, session_id: str,
    ) -> None:
        """Finalize selection: update stats, sticky map, connection count."""
        elapsed = (time.perf_counter() - start) * 1_000_000
        self._record_selection_time(elapsed)

        self._stats.total_selections += 1
        strat_key = result.strategy_used.value
        self._stats.selections_by_strategy[strat_key] = (
            self._stats.selections_by_strategy.get(strat_key, 0) + 1
        )
        if result.provider:
            self._stats.selections_by_provider[result.provider] = (
                self._stats.selections_by_provider.get(result.provider, 0) + 1
            )

        # Update sticky map
        if session_id and result.provider:
            self._sticky_map[session_id] = (result.provider, time.monotonic())

        logger.debug(
            "lb_selected",
            provider=result.provider,
            strategy=result.strategy_used.value,
            score=round(result.score, 3),
        )

    def _record_selection_time(self, elapsed_us: float) -> None:
        """Record selection time and update rolling average."""
        self._selection_times.append(elapsed_us)
        if len(self._selection_times) > 1000:
            self._selection_times = self._selection_times[-500:]
        self._stats.avg_selection_time_us = (
            sum(self._selection_times) / len(self._selection_times)
        )
