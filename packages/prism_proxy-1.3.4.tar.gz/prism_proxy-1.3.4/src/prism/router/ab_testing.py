"""A/B testing framework for model routing experiments.

Enables controlled experiments to compare model performance, cost, and user
satisfaction across different routing strategies.  This is critical for
data-driven routing improvements — instead of guessing which model is best,
run a statistically sound experiment.

Features:
    1. Define experiments with control/treatment groups
    2. Consistent user assignment (hash-based, deterministic)
    3. Track metrics per variant: latency, cost, quality, user feedback
    4. Statistical significance testing (chi-squared, Mann-Whitney U)
    5. Auto-conclude experiments when significance is reached
    6. Experiment history and reporting

Usage::

    ab = ABTestingEngine()
    ab.create_experiment("gpt4o_vs_sonnet", {
        "control": {"model": "gpt-4o"},
        "treatment": {"model": "claude-sonnet-4-20250514"},
    })
    variant = ab.assign("gpt4o_vs_sonnet", user_id="user123")
    # ... run request with variant's model ...
    ab.record_outcome("gpt4o_vs_sonnet", "user123", {
        "latency_ms": 450, "cost_usd": 0.003, "quality_score": 0.85,
    })
    report = ab.get_report("gpt4o_vs_sonnet")
"""

from __future__ import annotations

import hashlib
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class ExperimentStatus(Enum):
    """Status of an A/B experiment."""

    DRAFT = "draft"
    RUNNING = "running"
    PAUSED = "paused"
    CONCLUDED = "concluded"


@dataclass
class Variant:
    """A single variant (control or treatment) in an experiment.

    Attributes:
        name: Variant identifier (e.g., "control", "treatment_a").
        config: Configuration for this variant (model, params, etc.).
        weight: Traffic allocation weight (0.0 to 1.0).
    """

    name: str
    config: dict[str, Any]
    weight: float = 0.5


@dataclass
class OutcomeRecord:
    """A single outcome measurement for an experiment variant.

    Attributes:
        user_id: The user/session that produced this outcome.
        variant_name: Which variant was assigned.
        metrics: Measured outcomes (latency_ms, cost_usd, quality_score, etc.).
        timestamp: When the outcome was recorded.
    """

    user_id: str
    variant_name: str
    metrics: dict[str, float]
    timestamp: float = field(default_factory=time.time)


@dataclass
class Experiment:
    """An A/B test experiment definition.

    Attributes:
        name: Unique experiment identifier.
        description: Human-readable description.
        variants: The variants being compared.
        status: Current experiment status.
        created_at: Creation timestamp.
        concluded_at: Conclusion timestamp (0 if not concluded).
        min_samples_per_variant: Minimum samples before significance testing.
        confidence_level: Required confidence level (default 0.95).
        outcomes: All recorded outcomes.
        winner: Name of winning variant (empty if not concluded).
    """

    name: str
    description: str = ""
    variants: dict[str, Variant] = field(default_factory=dict)
    status: ExperimentStatus = ExperimentStatus.DRAFT
    created_at: float = field(default_factory=time.time)
    concluded_at: float = 0.0
    min_samples_per_variant: int = 30
    confidence_level: float = 0.95
    outcomes: list[OutcomeRecord] = field(default_factory=list)
    winner: str = ""


# ---------------------------------------------------------------------------
# Statistical helpers
# ---------------------------------------------------------------------------


def _mean(values: list[float]) -> float:
    """Compute arithmetic mean."""
    if not values:
        return 0.0
    return sum(values) / len(values)


def _variance(values: list[float]) -> float:
    """Compute sample variance."""
    if len(values) < 2:
        return 0.0
    m = _mean(values)
    return sum((x - m) ** 2 for x in values) / (len(values) - 1)


def _std(values: list[float]) -> float:
    """Compute sample standard deviation."""
    return math.sqrt(_variance(values))


def _mann_whitney_u(a: list[float], b: list[float]) -> tuple[float, float]:
    """Compute Mann-Whitney U statistic and approximate p-value.

    Uses normal approximation for large samples.

    Args:
        a: First sample.
        b: Second sample.

    Returns:
        Tuple of (U statistic, approximate p-value).
    """
    n1, n2 = len(a), len(b)
    if n1 == 0 or n2 == 0:
        return 0.0, 1.0

    # Rank all observations
    combined = [(v, 0) for v in a] + [(v, 1) for v in b]
    combined.sort(key=lambda x: x[0])

    # Assign ranks (handle ties with average rank)
    ranks: list[float] = []
    i = 0
    while i < len(combined):
        j = i
        while j < len(combined) and combined[j][0] == combined[i][0]:
            j += 1
        avg_rank = (i + j + 1) / 2  # 1-indexed average
        for _ in range(i, j):
            ranks.append(avg_rank)
        i = j

    # Sum ranks for group a
    r1 = sum(ranks[k] for k in range(len(combined)) if combined[k][1] == 0)

    u1 = r1 - n1 * (n1 + 1) / 2
    u2 = n1 * n2 - u1

    u_stat = min(u1, u2)

    # Normal approximation
    mu = n1 * n2 / 2
    sigma = math.sqrt(n1 * n2 * (n1 + n2 + 1) / 12)

    if sigma == 0:
        return u_stat, 1.0

    z = (u_stat - mu) / sigma
    # Two-tailed p-value using approximation of standard normal CDF
    p_value = 2 * _normal_cdf(-abs(z))

    return u_stat, p_value


def _normal_cdf(x: float) -> float:
    """Approximate standard normal CDF using Abramowitz & Stegun."""
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _cohens_d(a: list[float], b: list[float]) -> float:
    """Compute Cohen's d effect size.

    Args:
        a: First sample.
        b: Second sample.

    Returns:
        Cohen's d (positive means a > b).
    """
    n1, n2 = len(a), len(b)
    if n1 < 2 or n2 < 2:
        return 0.0

    m1, m2 = _mean(a), _mean(b)
    v1, v2 = _variance(a), _variance(b)

    # Pooled standard deviation
    pooled_var = ((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2)
    pooled_std = math.sqrt(pooled_var)

    if pooled_std == 0:
        return 0.0

    return (m1 - m2) / pooled_std


# ---------------------------------------------------------------------------
# Experiment report
# ---------------------------------------------------------------------------


@dataclass
class VariantStats:
    """Aggregated statistics for a single variant.

    Attributes:
        variant_name: Name of the variant.
        sample_count: Number of outcomes recorded.
        metrics: Per-metric statistics.
    """

    variant_name: str
    sample_count: int
    metrics: dict[str, dict[str, float]] = field(default_factory=dict)
    # metrics[metric_name] = {"mean": ..., "std": ..., "min": ..., "max": ...}


@dataclass
class MetricComparison:
    """Statistical comparison of a metric across two variants.

    Attributes:
        metric_name: Name of the metric compared.
        control_mean: Mean value in control group.
        treatment_mean: Mean value in treatment group.
        difference_pct: Percentage difference (treatment vs control).
        p_value: Statistical significance (p-value).
        effect_size: Cohen's d effect size.
        is_significant: Whether the difference is statistically significant.
        winner: Which variant is better for this metric ("control", "treatment", "tie").
        direction: "lower_is_better" or "higher_is_better".
    """

    metric_name: str
    control_mean: float
    treatment_mean: float
    difference_pct: float
    p_value: float
    effect_size: float
    is_significant: bool
    winner: str
    direction: str


@dataclass
class ExperimentReport:
    """Full report for an A/B experiment.

    Attributes:
        experiment_name: Name of the experiment.
        status: Current status.
        total_samples: Total outcomes across all variants.
        variant_stats: Per-variant statistics.
        comparisons: Statistical comparisons across metrics.
        recommendation: Human-readable recommendation.
        can_conclude: Whether enough data exists to conclude.
    """

    experiment_name: str
    status: ExperimentStatus
    total_samples: int
    variant_stats: dict[str, VariantStats]
    comparisons: list[MetricComparison]
    recommendation: str
    can_conclude: bool


# Metrics where lower is better
_LOWER_IS_BETTER = {"latency_ms", "cost_usd", "error_rate", "time_to_first_token_ms"}


# ---------------------------------------------------------------------------
# ABTestingEngine
# ---------------------------------------------------------------------------


class ABTestingEngine:
    """Engine for managing A/B testing experiments.

    Provides deterministic user assignment, outcome tracking, and
    statistical analysis for comparing routing strategies.
    """

    def __init__(self) -> None:
        self._experiments: dict[str, Experiment] = {}

    def create_experiment(
        self,
        name: str,
        variants: dict[str, dict[str, Any]],
        description: str = "",
        min_samples: int = 30,
        confidence_level: float = 0.95,
        weights: dict[str, float] | None = None,
    ) -> Experiment:
        """Create a new A/B experiment.

        Args:
            name: Unique experiment name.
            variants: Dict of variant_name → config dict.
            description: Human-readable description.
            min_samples: Minimum samples per variant before analysis.
            confidence_level: Required confidence (e.g. 0.95).
            weights: Optional traffic allocation weights per variant.

        Returns:
            The created Experiment.

        Raises:
            ValueError: If experiment name already exists or < 2 variants.
        """
        if name in self._experiments:
            msg = f"Experiment '{name}' already exists"
            raise ValueError(msg)

        if len(variants) < 2:
            msg = "Need at least 2 variants for an experiment"
            raise ValueError(msg)

        default_weight = 1.0 / len(variants)
        variant_objs: dict[str, Variant] = {}
        for vname, config in variants.items():
            w = (weights or {}).get(vname, default_weight)
            variant_objs[vname] = Variant(name=vname, config=config, weight=w)

        exp = Experiment(
            name=name,
            description=description,
            variants=variant_objs,
            status=ExperimentStatus.DRAFT,
            min_samples_per_variant=min_samples,
            confidence_level=confidence_level,
        )
        self._experiments[name] = exp

        logger.info(
            "experiment_created",
            name=name,
            variants=list(variants.keys()),
        )
        return exp

    def start_experiment(self, name: str) -> None:
        """Start an experiment (begin accepting assignments).

        Args:
            name: Experiment name.

        Raises:
            KeyError: If experiment doesn't exist.
            ValueError: If experiment is not in DRAFT or PAUSED state.
        """
        exp = self._get_experiment(name)
        if exp.status not in (ExperimentStatus.DRAFT, ExperimentStatus.PAUSED):
            msg = f"Cannot start experiment in {exp.status.value} state"
            raise ValueError(msg)
        exp.status = ExperimentStatus.RUNNING
        logger.info("experiment_started", name=name)

    def pause_experiment(self, name: str) -> None:
        """Pause a running experiment.

        Args:
            name: Experiment name.
        """
        exp = self._get_experiment(name)
        if exp.status == ExperimentStatus.RUNNING:
            exp.status = ExperimentStatus.PAUSED
            logger.info("experiment_paused", name=name)

    def conclude_experiment(self, name: str, winner: str = "") -> None:
        """Conclude an experiment with an optional declared winner.

        Args:
            name: Experiment name.
            winner: Optional winner variant name.
        """
        exp = self._get_experiment(name)
        exp.status = ExperimentStatus.CONCLUDED
        exp.concluded_at = time.time()
        exp.winner = winner
        logger.info("experiment_concluded", name=name, winner=winner)

    def assign(self, experiment_name: str, user_id: str) -> Variant:
        """Assign a user to a variant deterministically.

        Uses consistent hashing so the same user always gets the same
        variant for a given experiment.

        Args:
            experiment_name: Name of the experiment.
            user_id: Unique user or session identifier.

        Returns:
            The assigned Variant.

        Raises:
            ValueError: If experiment is not running.
        """
        exp = self._get_experiment(experiment_name)
        if exp.status != ExperimentStatus.RUNNING:
            msg = f"Experiment '{experiment_name}' is not running (status={exp.status.value})"
            raise ValueError(msg)

        # Deterministic hash-based assignment
        hash_input = f"{experiment_name}:{user_id}".encode()
        hash_val = int(hashlib.sha256(hash_input).hexdigest(), 16)
        bucket = (hash_val % 10000) / 10000.0  # [0, 1)

        # Assign to variant based on cumulative weights
        cumulative = 0.0
        variant_list = sorted(exp.variants.values(), key=lambda v: v.name)
        for variant in variant_list:
            cumulative += variant.weight
            if bucket < cumulative:
                return variant

        # Fallback to last variant
        return variant_list[-1]

    def record_outcome(
        self,
        experiment_name: str,
        user_id: str,
        metrics: dict[str, float],
    ) -> OutcomeRecord:
        """Record an outcome for a user's experiment variant.

        Args:
            experiment_name: Name of the experiment.
            user_id: The user who produced this outcome.
            metrics: Dict of metric_name → value.

        Returns:
            The recorded OutcomeRecord.
        """
        exp = self._get_experiment(experiment_name)
        variant = self.assign(experiment_name, user_id) if exp.status == ExperimentStatus.RUNNING else self._find_user_variant(exp, user_id)

        record = OutcomeRecord(
            user_id=user_id,
            variant_name=variant.name if variant else "unknown",
            metrics=metrics,
        )
        exp.outcomes.append(record)

        logger.debug(
            "outcome_recorded",
            experiment=experiment_name,
            variant=record.variant_name,
            metrics=metrics,
        )
        return record

    def get_report(self, experiment_name: str) -> ExperimentReport:
        """Generate a statistical report for an experiment.

        Args:
            experiment_name: Name of the experiment.

        Returns:
            ExperimentReport with statistical analysis.
        """
        exp = self._get_experiment(experiment_name)

        # Group outcomes by variant
        outcomes_by_variant: dict[str, list[OutcomeRecord]] = {}
        for outcome in exp.outcomes:
            outcomes_by_variant.setdefault(outcome.variant_name, []).append(outcome)

        # Compute per-variant stats
        variant_stats: dict[str, VariantStats] = {}
        for vname in exp.variants:
            outcomes = outcomes_by_variant.get(vname, [])
            metric_stats: dict[str, dict[str, float]] = {}

            if outcomes:
                # Collect all metric names
                all_metrics: set[str] = set()
                for o in outcomes:
                    all_metrics.update(o.metrics.keys())

                for metric_name in sorted(all_metrics):
                    values = [o.metrics[metric_name] for o in outcomes if metric_name in o.metrics]
                    if values:
                        metric_stats[metric_name] = {
                            "mean": round(_mean(values), 4),
                            "std": round(_std(values), 4),
                            "min": round(min(values), 4),
                            "max": round(max(values), 4),
                            "count": len(values),
                        }

            variant_stats[vname] = VariantStats(
                variant_name=vname,
                sample_count=len(outcomes),
                metrics=metric_stats,
            )

        # Statistical comparisons (pairwise between first two variants)
        comparisons: list[MetricComparison] = []
        variant_names = sorted(exp.variants.keys())
        if len(variant_names) >= 2:
            control_name = variant_names[0]
            treatment_name = variant_names[1]
            control_outcomes = outcomes_by_variant.get(control_name, [])
            treatment_outcomes = outcomes_by_variant.get(treatment_name, [])

            # Collect all metrics
            all_metrics = set()
            for o in control_outcomes + treatment_outcomes:
                all_metrics.update(o.metrics.keys())

            for metric_name in sorted(all_metrics):
                control_vals = [o.metrics[metric_name] for o in control_outcomes if metric_name in o.metrics]
                treatment_vals = [o.metrics[metric_name] for o in treatment_outcomes if metric_name in o.metrics]

                if len(control_vals) >= 2 and len(treatment_vals) >= 2:
                    c_mean = _mean(control_vals)
                    t_mean = _mean(treatment_vals)
                    diff_pct = ((t_mean - c_mean) / c_mean * 100) if c_mean != 0 else 0.0

                    _, p_value = _mann_whitney_u(control_vals, treatment_vals)
                    effect = _cohens_d(treatment_vals, control_vals)
                    is_sig = p_value < (1 - exp.confidence_level)

                    direction = "lower_is_better" if metric_name in _LOWER_IS_BETTER else "higher_is_better"

                    if not is_sig:
                        winner = "tie"
                    elif direction == "lower_is_better":
                        winner = treatment_name if t_mean < c_mean else control_name
                    else:
                        winner = treatment_name if t_mean > c_mean else control_name

                    comparisons.append(MetricComparison(
                        metric_name=metric_name,
                        control_mean=round(c_mean, 4),
                        treatment_mean=round(t_mean, 4),
                        difference_pct=round(diff_pct, 2),
                        p_value=round(p_value, 4),
                        effect_size=round(effect, 4),
                        is_significant=is_sig,
                        winner=winner,
                        direction=direction,
                    ))

        # Can we conclude?
        min_ok = all(
            len(outcomes_by_variant.get(v, [])) >= exp.min_samples_per_variant
            for v in exp.variants
        )
        has_significant = any(c.is_significant for c in comparisons)
        can_conclude = min_ok and has_significant

        # Generate recommendation
        recommendation = self._generate_recommendation(comparisons, variant_names, can_conclude)

        return ExperimentReport(
            experiment_name=experiment_name,
            status=exp.status,
            total_samples=len(exp.outcomes),
            variant_stats=variant_stats,
            comparisons=comparisons,
            recommendation=recommendation,
            can_conclude=can_conclude,
        )

    def list_experiments(self) -> list[dict[str, Any]]:
        """List all experiments with summary info.

        Returns:
            List of experiment summaries.
        """
        result = []
        for exp in self._experiments.values():
            result.append({
                "name": exp.name,
                "status": exp.status.value,
                "variants": list(exp.variants.keys()),
                "total_outcomes": len(exp.outcomes),
                "winner": exp.winner,
            })
        return result

    def delete_experiment(self, name: str) -> None:
        """Delete an experiment.

        Args:
            name: Experiment name.
        """
        if name in self._experiments:
            del self._experiments[name]
            logger.info("experiment_deleted", name=name)

    def get_experiment(self, name: str) -> Experiment | None:
        """Get an experiment by name, or None if not found."""
        return self._experiments.get(name)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_experiment(self, name: str) -> Experiment:
        """Get experiment or raise KeyError."""
        exp = self._experiments.get(name)
        if exp is None:
            msg = f"Experiment '{name}' not found"
            raise KeyError(msg)
        return exp

    def _find_user_variant(self, exp: Experiment, user_id: str) -> Variant | None:
        """Find which variant a user was previously assigned to."""
        for outcome in exp.outcomes:
            if outcome.user_id == user_id:
                return exp.variants.get(outcome.variant_name)
        return None

    def _generate_recommendation(
        self,
        comparisons: list[MetricComparison],
        variant_names: list[str],
        can_conclude: bool,
    ) -> str:
        """Generate a human-readable recommendation."""
        if not comparisons:
            return "Insufficient data for analysis."

        if not can_conclude:
            return "Not enough data to reach statistical significance. Continue collecting samples."

        # Count wins per variant
        wins: dict[str, int] = {}
        for comp in comparisons:
            if comp.is_significant and comp.winner != "tie":
                wins[comp.winner] = wins.get(comp.winner, 0) + 1

        if not wins:
            return "No statistically significant differences found between variants."

        best = max(wins, key=lambda k: wins[k])
        total_sig = sum(1 for c in comparisons if c.is_significant)
        return (
            f"Recommend '{best}' — wins {wins[best]}/{total_sig} significant metrics. "
            f"Consider concluding the experiment."
        )
