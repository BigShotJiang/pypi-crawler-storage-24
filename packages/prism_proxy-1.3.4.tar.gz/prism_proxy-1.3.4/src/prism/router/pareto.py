"""Pareto-optimal multi-objective routing.

Balances cost, latency, and quality simultaneously when selecting a model.
Instead of collapsing everything into a single score, this module preserves
the Pareto front — the set of models where no other model is strictly
better on every objective — so the caller can make an informed choice
given their constraints.

Example::

    weights = ObjectiveWeight(cost_weight=0.5, latency_weight=0.2, quality_weight=0.3)
    router = ParetoRouter(weights=weights)
    ranked = router.rank_models(["gpt-4o", "o4-mini", "deepseek/deepseek-chat"], "medium")
    best = router.select_best(ranked, RoutingConstraint(max_cost_usd=0.01))
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import structlog

from prism.cost.pricing import MODEL_PRICING

if TYPE_CHECKING:
    from prism.cost.tracker import CostTracker
    from prism.router.latency_tracker import LatencyTracker

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Default model quality scores by provider/tier when no historical data exists
_DEFAULT_QUALITY: dict[str, float] = {
    "anthropic/claude-opus-4-20250514": 0.95,
    "anthropic/claude-sonnet-4-20250514": 0.90,
    "gpt-4o": 0.88,
    "gpt-4.1": 0.88,
    "o3": 0.92,
    "o4-mini": 0.85,
    "o3-mini": 0.83,
    "gpt-4o-mini": 0.78,
    "gpt-4.1-mini": 0.78,
    "gpt-4.1-nano": 0.65,
    "gemini/gemini-2.5-pro": 0.87,
    "gemini/gemini-2.5-flash": 0.76,
    "gemini/gemini-2.0-flash": 0.72,
    "deepseek/deepseek-chat": 0.75,
    "deepseek/deepseek-reasoner": 0.82,
    "mistral/mistral-large-latest": 0.80,
    "mistral/mistral-small-latest": 0.68,
    "groq/llama-3.3-70b-versatile": 0.74,
    "groq/mixtral-8x7b-32768": 0.70,
}

# Default latency estimates (P50 ms) when no tracker data available
_DEFAULT_LATENCY_MS: dict[str, float] = {
    "anthropic/claude-opus-4-20250514": 8000.0,
    "anthropic/claude-sonnet-4-20250514": 3000.0,
    "gpt-4o": 2500.0,
    "gpt-4.1": 2500.0,
    "o3": 12000.0,
    "o4-mini": 4000.0,
    "o3-mini": 5000.0,
    "gpt-4o-mini": 1200.0,
    "gpt-4.1-mini": 1200.0,
    "gpt-4.1-nano": 800.0,
    "gemini/gemini-2.5-pro": 3500.0,
    "gemini/gemini-2.5-flash": 900.0,
    "gemini/gemini-2.0-flash": 700.0,
    "deepseek/deepseek-chat": 2000.0,
    "deepseek/deepseek-reasoner": 6000.0,
    "mistral/mistral-large-latest": 2800.0,
    "mistral/mistral-small-latest": 1100.0,
    "groq/llama-3.3-70b-versatile": 500.0,
    "groq/mixtral-8x7b-32768": 400.0,
}

# Estimated tokens for cost normalisation (1000 input + 500 output)
_DEFAULT_ESTIMATED_INPUT_TOKENS = 1000
_DEFAULT_ESTIMATED_OUTPUT_TOKENS = 500

# Model feature capabilities
_MODEL_FEATURES: dict[str, set[str]] = {
    "anthropic/claude-opus-4-20250514": {"vision", "tool_use", "thinking", "streaming"},
    "anthropic/claude-sonnet-4-20250514": {"vision", "tool_use", "thinking", "streaming"},
    "gpt-4o": {"vision", "tool_use", "streaming"},
    "gpt-4.1": {"vision", "tool_use", "streaming"},
    "o3": {"tool_use", "thinking"},
    "o4-mini": {"tool_use", "thinking"},
    "o3-mini": {"tool_use", "thinking"},
    "gpt-4o-mini": {"vision", "tool_use", "streaming"},
    "gpt-4.1-mini": {"vision", "tool_use", "streaming"},
    "gpt-4.1-nano": {"tool_use", "streaming"},
    "gemini/gemini-2.5-pro": {"vision", "tool_use", "thinking", "streaming"},
    "gemini/gemini-2.5-flash": {"vision", "tool_use", "streaming"},
    "gemini/gemini-2.0-flash": {"vision", "tool_use", "streaming"},
    "deepseek/deepseek-chat": {"tool_use", "streaming"},
    "deepseek/deepseek-reasoner": {"thinking", "streaming"},
    "mistral/mistral-large-latest": {"tool_use", "streaming"},
    "mistral/mistral-small-latest": {"tool_use", "streaming"},
    "groq/llama-3.3-70b-versatile": {"tool_use", "streaming"},
    "groq/mixtral-8x7b-32768": {"streaming"},
}

# Complexity tier quality adjustment multipliers
_COMPLEXITY_QUALITY_ADJUSTMENT: dict[str, float] = {
    "simple": 1.0,     # All models handle simple tasks well
    "medium": 0.95,    # Slight penalty — cheaper models may struggle
    "complex": 0.85,   # Significant penalty for weaker models
}


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ObjectiveWeight:
    """Weights for the three routing objectives.

    Attributes:
        cost_weight: Importance of low cost (0-1).
        latency_weight: Importance of low latency (0-1).
        quality_weight: Importance of high quality (0-1).
    """

    cost_weight: float = 0.4
    latency_weight: float = 0.3
    quality_weight: float = 0.3

    def __post_init__(self) -> None:
        """Validate that weights are non-negative and sum to 1.0."""
        for name, value in [
            ("cost_weight", self.cost_weight),
            ("latency_weight", self.latency_weight),
            ("quality_weight", self.quality_weight),
        ]:
            if value < 0 or value > 1:
                msg = f"{name} must be between 0 and 1, got {value}"
                raise ValueError(msg)

        total = self.cost_weight + self.latency_weight + self.quality_weight
        if abs(total - 1.0) > 0.01:
            msg = f"Weights must sum to 1.0, got {total:.3f}"
            raise ValueError(msg)


@dataclass
class ModelScore:
    """Scoring result for a single model across all objectives.

    Attributes:
        model_id: LiteLLM model identifier.
        cost_score: Normalised cost score (0-1, higher = cheaper).
        latency_score: Normalised latency score (0-1, higher = faster).
        quality_score: Normalised quality score (0-1, higher = better).
        weighted_score: Combined weighted score.
        is_pareto_optimal: Whether this model is on the Pareto front.
        dominated_by: List of model IDs that dominate this one.
    """

    model_id: str
    cost_score: float = 0.0
    latency_score: float = 0.0
    quality_score: float = 0.0
    weighted_score: float = 0.0
    is_pareto_optimal: bool = False
    dominated_by: list[str] = field(default_factory=list)


@dataclass
class RoutingConstraint:
    """Hard constraints that a model must satisfy.

    Attributes:
        max_cost_usd: Maximum acceptable cost per request.
        max_latency_ms: Maximum acceptable P50 latency.
        min_quality_score: Minimum acceptable quality score.
        required_features: Features the model must support.
    """

    max_cost_usd: float | None = None
    max_latency_ms: float | None = None
    min_quality_score: float | None = None
    required_features: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Normalisation helpers (module-level for testability)
# ---------------------------------------------------------------------------


def _normalize_cost(
    model: str,
    estimated_tokens: int = _DEFAULT_ESTIMATED_INPUT_TOKENS + _DEFAULT_ESTIMATED_OUTPUT_TOKENS,
) -> float:
    """Normalise cost to a 0-1 score where higher = cheaper.

    Args:
        model: LiteLLM model identifier.
        estimated_tokens: Estimated total tokens for cost calculation.

    Returns:
        Score between 0.0 and 1.0.
    """
    pricing = MODEL_PRICING.get(model)
    if pricing is None:
        return 0.5  # Unknown model — neutral score

    # Estimate cost for a typical request
    input_tokens = int(estimated_tokens * 0.67)
    output_tokens = estimated_tokens - input_tokens
    cost = (
        (input_tokens / 1_000_000) * pricing.input_cost_per_1m
        + (output_tokens / 1_000_000) * pricing.output_cost_per_1m
    )

    if cost <= 0:
        return 1.0  # Free model

    # Logarithmic normalisation: $0.001 → ~0.9, $0.01 → ~0.7, $0.1 → ~0.3
    # Using inverse scaling with a reference cost
    reference_cost = 0.05  # $0.05 maps to score 0.5
    score = reference_cost / (reference_cost + cost)

    return max(0.0, min(1.0, score))


def _normalize_latency(
    model: str,
    latency_tracker: LatencyTracker | None = None,
) -> float:
    """Normalise latency to a 0-1 score where higher = faster.

    Args:
        model: LiteLLM model identifier.
        latency_tracker: Optional tracker with real latency data.

    Returns:
        Score between 0.0 and 1.0.
    """
    latency_ms: float | None = None

    if latency_tracker is not None:
        latency_ms_value = latency_tracker.get_p50(model)
        if latency_ms_value is not None:
            latency_ms = latency_ms_value

    if latency_ms is None:
        latency_ms = _DEFAULT_LATENCY_MS.get(model, 3000.0)

    # Inverse scaling: 200ms → ~0.95, 1000ms → ~0.8, 5000ms → ~0.4, 15000ms → ~0.15
    reference_ms = 2000.0  # 2 seconds maps to score 0.5
    score = reference_ms / (reference_ms + latency_ms)

    return max(0.0, min(1.0, score))


def _normalize_quality(
    model: str,
    success_rate: float | None = None,
    complexity: str = "medium",
) -> float:
    """Normalise quality to a 0-1 score.

    Combines default model quality with optional historical success rate
    and adjusts for task complexity.

    Args:
        model: LiteLLM model identifier.
        success_rate: Historical success rate (0-1), or None for default.
        complexity: Task complexity tier.

    Returns:
        Score between 0.0 and 1.0.
    """
    base_quality = _DEFAULT_QUALITY.get(model, 0.70)

    quality = (0.4 * base_quality + 0.6 * success_rate) if success_rate is not None else base_quality

    # Apply complexity adjustment for weaker models
    adjustment = _COMPLEXITY_QUALITY_ADJUSTMENT.get(complexity, 0.90)
    if quality < 0.80:
        # Only penalise weaker models on harder tasks
        quality *= adjustment

    return max(0.0, min(1.0, quality))


def _is_dominated(score_a: ModelScore, score_b: ModelScore) -> bool:
    """Check if model B dominates model A.

    B dominates A if B is at least as good as A on ALL objectives
    and strictly better on at least one.

    Args:
        score_a: The potentially dominated model score.
        score_b: The potentially dominating model score.

    Returns:
        True if B dominates A (A is dominated by B).
    """
    at_least_as_good = (
        score_b.cost_score >= score_a.cost_score
        and score_b.latency_score >= score_a.latency_score
        and score_b.quality_score >= score_a.quality_score
    )

    strictly_better = (
        score_b.cost_score > score_a.cost_score
        or score_b.latency_score > score_a.latency_score
        or score_b.quality_score > score_a.quality_score
    )

    return at_least_as_good and strictly_better


# ---------------------------------------------------------------------------
# ParetoRouter
# ---------------------------------------------------------------------------


class ParetoRouter:
    """Multi-objective router using Pareto-optimal selection.

    Evaluates models on cost, latency, and quality simultaneously,
    identifies the Pareto front (non-dominated set), and selects the
    best model given optional hard constraints.

    Args:
        weights: Objective weights for the weighted score.
        latency_tracker: Optional latency tracker for real P50 data.
        cost_tracker: Optional cost tracker (reserved for future budget checks).
    """

    def __init__(
        self,
        weights: ObjectiveWeight | None = None,
        latency_tracker: LatencyTracker | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        self._weights = weights or ObjectiveWeight()
        self._latency_tracker = latency_tracker
        self._cost_tracker = cost_tracker

    def rank_models(
        self,
        candidates: list[str],
        task_complexity: str = "medium",
    ) -> list[ModelScore]:
        """Rank candidate models by weighted multi-objective score.

        Args:
            candidates: List of LiteLLM model identifiers.
            task_complexity: Task complexity tier (simple, medium, complex).

        Returns:
            List of ModelScore sorted by weighted_score descending.
        """
        if not candidates:
            return []

        scores: list[ModelScore] = []

        for model_id in candidates:
            cost_s = _normalize_cost(model_id)
            latency_s = _normalize_latency(model_id, self._latency_tracker)
            quality_s = _normalize_quality(model_id, complexity=task_complexity)

            weighted = (
                cost_s * self._weights.cost_weight
                + latency_s * self._weights.latency_weight
                + quality_s * self._weights.quality_weight
            )

            scores.append(
                ModelScore(
                    model_id=model_id,
                    cost_score=round(cost_s, 4),
                    latency_score=round(latency_s, 4),
                    quality_score=round(quality_s, 4),
                    weighted_score=round(weighted, 4),
                )
            )

        # Identify Pareto front
        self._mark_pareto_front(scores)

        # Sort by weighted score descending
        scores.sort(key=lambda s: s.weighted_score, reverse=True)

        logger.info(
            "models_ranked",
            count=len(scores),
            complexity=task_complexity,
            top_model=scores[0].model_id if scores else None,
            pareto_count=sum(1 for s in scores if s.is_pareto_optimal),
        )

        return scores

    def find_pareto_front(
        self,
        candidates: list[ModelScore],
    ) -> list[ModelScore]:
        """Extract the Pareto front from a list of scored models.

        The Pareto front is the subset of models that are not dominated
        by any other model — no other option is strictly better on all
        three objectives.

        Args:
            candidates: List of scored models.

        Returns:
            Non-dominated subset sorted by weighted_score descending.
        """
        if not candidates:
            return []

        # Ensure domination is computed
        self._mark_pareto_front(candidates)

        front = [s for s in candidates if s.is_pareto_optimal]
        front.sort(key=lambda s: s.weighted_score, reverse=True)
        return front

    def select_best(
        self,
        candidates: list[ModelScore],
        constraint: RoutingConstraint | None = None,
    ) -> ModelScore | None:
        """Select the best model given optional hard constraints.

        First filters candidates by constraints, then returns the one
        with the highest weighted score. Prefers Pareto-optimal models
        when weighted scores are close (within 5%).

        Args:
            candidates: List of scored models (from rank_models).
            constraint: Optional hard constraints to filter by.

        Returns:
            Best ModelScore, or None if no candidate satisfies constraints.
        """
        if not candidates:
            return None

        filtered = self._apply_constraints(candidates, constraint)
        if not filtered:
            logger.warning(
                "no_model_satisfies_constraints",
                total_candidates=len(candidates),
                constraint_cost=constraint.max_cost_usd if constraint else None,
                constraint_latency=constraint.max_latency_ms if constraint else None,
                constraint_quality=constraint.min_quality_score if constraint else None,
            )
            return None

        # Sort by weighted score
        filtered.sort(key=lambda s: s.weighted_score, reverse=True)

        # If the top candidate is not Pareto-optimal but a Pareto-optimal
        # candidate is within 5% of its score, prefer the Pareto one
        top = filtered[0]
        if not top.is_pareto_optimal:
            threshold = top.weighted_score * 0.95
            for candidate in filtered[1:]:
                if candidate.is_pareto_optimal and candidate.weighted_score >= threshold:
                    logger.info(
                        "pareto_preference",
                        original=top.model_id,
                        preferred=candidate.model_id,
                        score_diff=round(
                            top.weighted_score - candidate.weighted_score, 4,
                        ),
                    )
                    top = candidate
                    break

        logger.info(
            "model_selected",
            model=top.model_id,
            weighted_score=top.weighted_score,
            is_pareto=top.is_pareto_optimal,
        )

        return top

    def explain_selection(self, selection: ModelScore) -> str:
        """Generate a human-readable explanation of why a model was selected.

        Args:
            selection: The selected model score.

        Returns:
            Multi-line explanation string.
        """
        lines: list[str] = [
            f"Selected: {selection.model_id}",
            f"  Weighted score: {selection.weighted_score:.3f}",
            f"  Cost score:     {selection.cost_score:.3f} "
            f"(weight: {self._weights.cost_weight:.1f})",
            f"  Latency score:  {selection.latency_score:.3f} "
            f"(weight: {self._weights.latency_weight:.1f})",
            f"  Quality score:  {selection.quality_score:.3f} "
            f"(weight: {self._weights.quality_weight:.1f})",
        ]

        if selection.is_pareto_optimal:
            lines.append("  Status: Pareto-optimal (no model is better on all axes)")
        else:
            lines.append(
                f"  Status: Dominated by {', '.join(selection.dominated_by)}"
            )

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _mark_pareto_front(scores: list[ModelScore]) -> None:
        """Mark which models are Pareto-optimal in-place.

        A model is Pareto-optimal if no other model dominates it
        (i.e., is at least as good on all objectives and strictly
        better on at least one).

        Args:
            scores: List of model scores to annotate.
        """
        for score in scores:
            score.is_pareto_optimal = True
            score.dominated_by = []

        for i, score_a in enumerate(scores):
            for j, score_b in enumerate(scores):
                if i == j:
                    continue
                if _is_dominated(score_a, score_b):
                    score_a.is_pareto_optimal = False
                    if score_b.model_id not in score_a.dominated_by:
                        score_a.dominated_by.append(score_b.model_id)

    def _apply_constraints(
        self,
        candidates: list[ModelScore],
        constraint: RoutingConstraint | None,
    ) -> list[ModelScore]:
        """Filter candidates by hard constraints.

        Args:
            candidates: Scored model list.
            constraint: Optional constraints.

        Returns:
            Filtered list satisfying all constraints.
        """
        if constraint is None:
            return list(candidates)

        filtered: list[ModelScore] = []

        for score in candidates:
            # Cost constraint
            if constraint.max_cost_usd is not None:
                estimated_cost = self._estimate_cost_usd(score.model_id)
                if estimated_cost > constraint.max_cost_usd:
                    continue

            # Latency constraint
            if constraint.max_latency_ms is not None:
                latency = self._get_latency_ms(score.model_id)
                if latency > constraint.max_latency_ms:
                    continue

            # Quality constraint
            if constraint.min_quality_score is not None and score.quality_score < constraint.min_quality_score:
                continue

            # Feature constraints
            if constraint.required_features:
                model_features = _MODEL_FEATURES.get(score.model_id, set())
                if not all(f in model_features for f in constraint.required_features):
                    continue

            filtered.append(score)

        return filtered

    @staticmethod
    def _estimate_cost_usd(model_id: str) -> float:
        """Estimate cost for a typical request in USD."""
        pricing = MODEL_PRICING.get(model_id)
        if pricing is None:
            return 0.05  # Assume moderate cost for unknown models

        input_tokens = _DEFAULT_ESTIMATED_INPUT_TOKENS
        output_tokens = _DEFAULT_ESTIMATED_OUTPUT_TOKENS

        return (
            (input_tokens / 1_000_000) * pricing.input_cost_per_1m
            + (output_tokens / 1_000_000) * pricing.output_cost_per_1m
        )

    def _get_latency_ms(self, model_id: str) -> float:
        """Get P50 latency for a model."""
        if self._latency_tracker is not None:
            p50 = self._latency_tracker.get_p50(model_id)
            if p50 is not None:
                return p50

        return _DEFAULT_LATENCY_MS.get(model_id, 3000.0)
