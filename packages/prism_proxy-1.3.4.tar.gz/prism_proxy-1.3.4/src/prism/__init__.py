"""Prism — Multi-API Intelligent Router CLI."""

__version__ = "1.3.4"
__app_name__ = "prism"
