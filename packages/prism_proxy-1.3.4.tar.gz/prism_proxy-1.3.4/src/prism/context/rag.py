"""Retrieval-Augmented Generation (RAG) — semantic search over project files.

Provides automatic document chunking, embedding via lightweight TF-IDF
vectors (no external API calls), and semantic retrieval for context
augmentation.

Unlike heavy vector-DB RAG that requires embedding API calls, this uses
a pure-Python TF-IDF + cosine similarity approach that:
    - Works offline and costs zero API tokens
    - Indexes a full codebase in <2 seconds
    - Returns relevant code chunks for any natural language query
    - Auto-updates when files change

Usage::

    rag = RAGEngine(project_root=Path("."))
    rag.index()  # Index all code files
    results = rag.search("authentication middleware", top_k=5)
    for chunk in results:
        print(chunk.file_path, chunk.score, chunk.content[:100])
"""

from __future__ import annotations

import math
import re
import time
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    pass

logger = structlog.get_logger(__name__)

# File extensions to index
_CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java",
    ".rb", ".php", ".c", ".cpp", ".h", ".hpp", ".cs", ".swift",
    ".kt", ".scala", ".sh", ".bash", ".zsh", ".sql", ".yaml",
    ".yml", ".toml", ".json", ".md", ".txt", ".cfg", ".ini",
    ".env.example", ".dockerfile", ".tf", ".hcl",
}

# Directories to skip
_SKIP_DIRS = {
    ".git", "__pycache__", "node_modules", ".venv", "venv",
    ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "dist", "build", ".eggs", "*.egg-info", ".next",
    "target", "vendor", ".terraform",
}

# Maximum file size to index (256KB)
_MAX_FILE_SIZE = 256 * 1024

# Chunk size in lines
_DEFAULT_CHUNK_LINES = 50
_CHUNK_OVERLAP_LINES = 10


@dataclass(frozen=True)
class RAGChunk:
    """A chunk of code/text from a file.

    Attributes:
        file_path: Relative path to the source file.
        start_line: 1-indexed start line in the file.
        end_line: 1-indexed end line (inclusive).
        content: The raw text content of the chunk.
        language: Detected programming language.
    """

    file_path: str
    start_line: int
    end_line: int
    content: str
    language: str


@dataclass
class RAGResult:
    """A search result with relevance score.

    Attributes:
        chunk: The matched code chunk.
        score: Relevance score (0.0 to 1.0, higher = more relevant).
        matched_terms: Terms from the query that matched.
    """

    chunk: RAGChunk
    score: float
    matched_terms: list[str] = field(default_factory=list)


@dataclass
class RAGStats:
    """Index statistics.

    Attributes:
        total_files: Number of indexed files.
        total_chunks: Number of indexed chunks.
        total_tokens: Estimated total tokens indexed.
        index_time_ms: Time to build the index.
        languages: Count of files per language.
    """

    total_files: int
    total_chunks: int
    total_tokens: int
    index_time_ms: float
    languages: dict[str, int]


# ---------------------------------------------------------------------------
# TF-IDF engine (pure Python, no dependencies)
# ---------------------------------------------------------------------------

_STOP_WORDS = frozenset({
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "it", "this", "that", "these",
    "those", "i", "you", "we", "they", "he", "she", "my", "your",
    "and", "or", "but", "if", "then", "else", "when", "while", "not",
    "no", "so", "as", "than", "too", "very", "self", "none", "true",
    "false", "return", "import", "from", "class", "def", "pass",
})

_WORD_PATTERN = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")
_CAMEL_SPLIT = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def _tokenize_code(text: str) -> list[str]:
    """Tokenize code/text into searchable terms.

    Handles camelCase splitting, snake_case splitting, and stop word removal.
    """
    words = _WORD_PATTERN.findall(text)
    tokens: list[str] = []
    for word in words:
        lower = word.lower()
        if lower in _STOP_WORDS or len(lower) < 2:
            continue
        tokens.append(lower)
        # Split camelCase
        parts = _CAMEL_SPLIT.split(word)
        if len(parts) > 1:
            tokens.extend(p.lower() for p in parts if len(p) >= 2)
        # Split snake_case
        if "_" in word:
            tokens.extend(
                p.lower() for p in word.split("_") if len(p) >= 2
            )
    return tokens


class _TFIDFIndex:
    """Lightweight TF-IDF index over document chunks."""

    def __init__(self) -> None:
        self._documents: list[tuple[RAGChunk, list[str]]] = []
        self._df: Counter[str] = Counter()  # document frequency
        self._idf: dict[str, float] = {}
        self._built = False

    def add_document(self, chunk: RAGChunk, tokens: list[str]) -> None:
        """Add a document to the index."""
        self._documents.append((chunk, tokens))
        unique_terms = set(tokens)
        for term in unique_terms:
            self._df[term] += 1
        self._built = False

    def build(self) -> None:
        """Compute IDF values. Must be called after all documents are added."""
        n = len(self._documents)
        if n == 0:
            self._built = True
            return
        for term, df in self._df.items():
            self._idf[term] = math.log((n + 1) / (df + 1)) + 1.0
        self._built = True

    def search(self, query: str, top_k: int = 10) -> list[RAGResult]:
        """Search for documents matching the query.

        Args:
            query: Natural language query.
            top_k: Maximum results to return.

        Returns:
            List of RAGResult sorted by relevance (highest first).
        """
        if not self._built:
            self.build()

        query_tokens = _tokenize_code(query)
        if not query_tokens:
            return []

        # Compute query TF-IDF vector
        query_tf = Counter(query_tokens)
        query_vec: dict[str, float] = {}
        for term, count in query_tf.items():
            idf = self._idf.get(term, 0.0)
            query_vec[term] = count * idf

        query_norm = math.sqrt(sum(v * v for v in query_vec.values()))
        if query_norm == 0:
            return []

        results: list[tuple[float, RAGChunk, list[str]]] = []

        for chunk, doc_tokens in self._documents:
            doc_tf = Counter(doc_tokens)
            # Compute dot product and doc norm
            dot = 0.0
            doc_norm_sq = 0.0
            matched: list[str] = []

            for term, count in doc_tf.items():
                idf = self._idf.get(term, 0.0)
                tfidf = count * idf
                doc_norm_sq += tfidf * tfidf
                if term in query_vec:
                    dot += tfidf * query_vec[term]
                    matched.append(term)

            doc_norm = math.sqrt(doc_norm_sq)
            if doc_norm == 0 or not matched:
                continue

            score = dot / (query_norm * doc_norm)
            results.append((score, chunk, matched))

        results.sort(key=lambda x: x[0], reverse=True)

        return [
            RAGResult(chunk=chunk, score=round(score, 4), matched_terms=matched)
            for score, chunk, matched in results[:top_k]
        ]

    @property
    def document_count(self) -> int:
        """Number of indexed documents."""
        return len(self._documents)

    def clear(self) -> None:
        """Clear the index."""
        self._documents.clear()
        self._df.clear()
        self._idf.clear()
        self._built = False


# ---------------------------------------------------------------------------
# RAG Engine
# ---------------------------------------------------------------------------

def _detect_language(path: str) -> str:
    """Detect programming language from file extension."""
    ext = Path(path).suffix.lower()
    lang_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".go": "go",
        ".rs": "rust", ".java": "java", ".rb": "ruby",
        ".php": "php", ".c": "c", ".cpp": "cpp", ".h": "c",
        ".hpp": "cpp", ".cs": "csharp", ".swift": "swift",
        ".kt": "kotlin", ".scala": "scala", ".sh": "shell",
        ".sql": "sql", ".yaml": "yaml", ".yml": "yaml",
        ".toml": "toml", ".json": "json", ".md": "markdown",
    }
    return lang_map.get(ext, "text")


class RAGEngine:
    """Retrieval-Augmented Generation engine for project files.

    Indexes code files using TF-IDF and provides semantic search
    for context augmentation in LLM prompts.

    Args:
        project_root: Root directory of the project to index.
        chunk_lines: Number of lines per chunk.
        chunk_overlap: Overlap between consecutive chunks.
        extensions: File extensions to index.  If None, uses defaults.
    """

    def __init__(
        self,
        project_root: Path,
        chunk_lines: int = _DEFAULT_CHUNK_LINES,
        chunk_overlap: int = _CHUNK_OVERLAP_LINES,
        extensions: set[str] | None = None,
    ) -> None:
        self._root = project_root
        self._chunk_lines = chunk_lines
        self._chunk_overlap = chunk_overlap
        self._extensions = extensions or _CODE_EXTENSIONS
        self._index = _TFIDFIndex()
        self._stats: RAGStats | None = None
        self._file_mtimes: dict[str, float] = {}

    def index(self, force: bool = False) -> RAGStats:
        """Index all code files in the project.

        Args:
            force: If True, re-index everything.  If False, only index
                   new or modified files.

        Returns:
            RAGStats with indexing statistics.
        """
        start = time.perf_counter()

        if force:
            self._index.clear()
            self._file_mtimes.clear()

        total_files = 0
        total_chunks = 0
        total_tokens = 0
        languages: Counter[str] = Counter()

        for file_path in self._walk_files():
            rel_path = str(file_path.relative_to(self._root))
            mtime = file_path.stat().st_mtime

            # Skip unchanged files
            if not force and self._file_mtimes.get(rel_path) == mtime:
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except (OSError, PermissionError):
                continue

            lang = _detect_language(rel_path)
            languages[lang] += 1
            total_files += 1

            chunks = self._chunk_file(rel_path, content, lang)
            for chunk in chunks:
                tokens = _tokenize_code(chunk.content)
                self._index.add_document(chunk, tokens)
                total_chunks += 1
                total_tokens += len(tokens)

            self._file_mtimes[rel_path] = mtime

        self._index.build()
        elapsed_ms = (time.perf_counter() - start) * 1000

        self._stats = RAGStats(
            total_files=total_files,
            total_chunks=total_chunks,
            total_tokens=total_tokens,
            index_time_ms=round(elapsed_ms, 1),
            languages=dict(languages),
        )

        logger.info(
            "rag_indexed",
            files=total_files,
            chunks=total_chunks,
            tokens=total_tokens,
            time_ms=round(elapsed_ms, 1),
        )

        return self._stats

    def search(self, query: str, top_k: int = 10) -> list[RAGResult]:
        """Search for relevant code chunks.

        Args:
            query: Natural language query describing what you're looking for.
            top_k: Maximum number of results.

        Returns:
            List of RAGResult sorted by relevance.
        """
        if self._index.document_count == 0:
            self.index()

        return self._index.search(query, top_k=top_k)

    def get_context_for_prompt(
        self,
        query: str,
        max_tokens: int = 4000,
        top_k: int = 10,
    ) -> str:
        """Get formatted context string for LLM prompt augmentation.

        Searches the index and formats results as a context block
        suitable for including in an LLM prompt.

        Args:
            query: The user's question or task description.
            max_tokens: Approximate token budget for the context.
            top_k: Maximum number of chunks to consider.

        Returns:
            Formatted context string with file references.
        """
        results = self.search(query, top_k=top_k)
        if not results:
            return ""

        parts: list[str] = ["Relevant code from the project:\n"]
        token_estimate = 10  # Header tokens

        for result in results:
            chunk = result.chunk
            chunk_text = (
                f"\n--- {chunk.file_path}:{chunk.start_line}-{chunk.end_line} "
                f"(relevance: {result.score:.2f}) ---\n"
                f"```{chunk.language}\n{chunk.content}\n```\n"
            )
            chunk_tokens = len(chunk_text.split()) * 0.75
            if token_estimate + chunk_tokens > max_tokens:
                break
            parts.append(chunk_text)
            token_estimate += chunk_tokens

        return "".join(parts)

    def get_stats(self) -> RAGStats | None:
        """Get indexing statistics, or None if not yet indexed."""
        return self._stats

    def clear(self) -> None:
        """Clear the index."""
        self._index.clear()
        self._file_mtimes.clear()
        self._stats = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _walk_files(self) -> list[Path]:
        """Walk project tree and collect indexable files."""
        files: list[Path] = []

        def _should_skip_dir(name: str) -> bool:
            return name in _SKIP_DIRS or name.startswith(".")

        for item in sorted(self._root.rglob("*")):
            if item.is_dir():
                continue

            # Check if any parent directory should be skipped
            skip = False
            for parent in item.relative_to(self._root).parents:
                if _should_skip_dir(parent.name):
                    skip = True
                    break
            if skip:
                continue

            if item.suffix.lower() not in self._extensions:
                continue

            if item.stat().st_size > _MAX_FILE_SIZE:
                continue

            files.append(item)

        return files

    def _chunk_file(
        self,
        rel_path: str,
        content: str,
        language: str,
    ) -> list[RAGChunk]:
        """Split a file into overlapping chunks.

        Uses function/class boundaries when possible (for Python, JS, etc.),
        falls back to line-based chunking.
        """
        lines = content.split("\n")
        if not lines:
            return []

        # For small files, return as a single chunk
        if len(lines) <= self._chunk_lines:
            return [
                RAGChunk(
                    file_path=rel_path,
                    start_line=1,
                    end_line=len(lines),
                    content=content,
                    language=language,
                )
            ]

        chunks: list[RAGChunk] = []
        step = self._chunk_lines - self._chunk_overlap

        for start in range(0, len(lines), max(1, step)):
            end = min(start + self._chunk_lines, len(lines))
            chunk_lines = lines[start:end]
            chunk_content = "\n".join(chunk_lines)

            if chunk_content.strip():
                chunks.append(
                    RAGChunk(
                        file_path=rel_path,
                        start_line=start + 1,
                        end_line=end,
                        content=chunk_content,
                        language=language,
                    )
                )

            if end >= len(lines):
                break

        return chunks
