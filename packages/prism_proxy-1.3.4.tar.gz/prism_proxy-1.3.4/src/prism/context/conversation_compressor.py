"""Conversation history compressor — intelligent context window management.

When conversation history exceeds the model's context window, this module
intelligently compresses older turns while preserving the information most
relevant to the current task.

Unlike naive truncation, this uses multiple strategies:
    1. Rolling summarization of old turns
    2. Importance scoring per message (tool calls > user intents > chit-chat)
    3. Code block preservation (never summarize code)
    4. Recency weighting (recent turns preserved verbatim)
    5. Reference tracking (keep messages referenced by recent turns)

Usage::

    compressor = ConversationCompressor(max_tokens=8000)
    compressed = compressor.compress(messages, current_query="fix the bug")
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class MessageImportance:
    """Importance scoring for a message.

    Attributes:
        index: Message index in the conversation.
        role: Message role (system, user, assistant).
        score: Importance score (0-1).
        reasons: Why this score was assigned.
        has_code: Whether the message contains code blocks.
        estimated_tokens: Estimated token count.
    """

    index: int
    role: str
    score: float
    reasons: list[str] = field(default_factory=list)
    has_code: bool = False
    estimated_tokens: int = 0


@dataclass
class CompressionResult:
    """Result of conversation compression.

    Attributes:
        messages: Compressed messages.
        original_tokens: Token estimate before compression.
        compressed_tokens: Token estimate after compression.
        messages_removed: Number of messages removed.
        messages_summarized: Number of messages summarized.
        compression_ratio: Ratio of compressed to original.
    """

    messages: list[dict[str, str]]
    original_tokens: int
    compressed_tokens: int
    messages_removed: int
    messages_summarized: int
    compression_ratio: float


# Patterns indicating high-importance content
_CODE_BLOCK_RE = re.compile(r"```[\s\S]*?```")
_FILE_PATH_RE = re.compile(r"[a-zA-Z_/\\][a-zA-Z0-9_./\\]+\.[a-zA-Z]{1,5}")
_ERROR_KEYWORDS = {"error", "exception", "traceback", "failed", "bug", "issue", "crash"}
_INTENT_KEYWORDS = {"please", "could you", "can you", "i need", "i want", "help me", "fix", "create", "build", "add", "remove", "update", "change", "modify"}
_TOOL_INDICATORS = {"executed", "result:", "output:", "file:", "created", "modified", "deleted", "wrote", "read"}


class ConversationCompressor:
    """Intelligent conversation history compressor.

    Args:
        max_tokens: Maximum total tokens for the compressed conversation.
        preserve_recent: Number of recent turns to always preserve verbatim.
        summary_ratio: Target compression ratio for summarized messages.
    """

    def __init__(
        self,
        max_tokens: int = 8000,
        preserve_recent: int = 4,
        summary_ratio: float = 0.3,
    ) -> None:
        self._max_tokens = max_tokens
        self._preserve_recent = preserve_recent
        self._summary_ratio = summary_ratio

    def compress(
        self,
        messages: list[dict[str, str]],
        current_query: str = "",
    ) -> CompressionResult:
        """Compress conversation history to fit within token budget.

        Args:
            messages: Full conversation history.
            current_query: The current user query (for relevance scoring).

        Returns:
            CompressionResult with compressed messages.
        """
        if not messages:
            return CompressionResult(
                messages=[],
                original_tokens=0,
                compressed_tokens=0,
                messages_removed=0,
                messages_summarized=0,
                compression_ratio=1.0,
            )

        original_tokens = self._estimate_tokens(messages)

        # If already within budget, return as-is
        if original_tokens <= self._max_tokens:
            return CompressionResult(
                messages=list(messages),
                original_tokens=original_tokens,
                compressed_tokens=original_tokens,
                messages_removed=0,
                messages_summarized=0,
                compression_ratio=1.0,
            )

        # Score importance of each message
        importance = self._score_importance(messages, current_query)

        # Separate into buckets
        system_msgs = [m for m in messages if m.get("role") == "system"]
        recent_msgs = messages[-self._preserve_recent:] if len(messages) > self._preserve_recent else messages
        middle_msgs = messages[len(system_msgs):-self._preserve_recent] if len(messages) > self._preserve_recent + len(system_msgs) else []

        # Always keep: system messages + recent messages
        kept: list[dict[str, str]] = list(system_msgs)
        removed = 0
        summarized = 0

        if middle_msgs:
            # Score middle messages
            middle_importance = [
                imp for imp in importance
                if imp.index >= len(system_msgs) and imp.index < len(messages) - self._preserve_recent
            ]
            middle_importance.sort(key=lambda x: x.score, reverse=True)

            # Calculate budget for middle section
            system_tokens = self._estimate_tokens(system_msgs)
            recent_tokens = self._estimate_tokens(recent_msgs)
            middle_budget = self._max_tokens - system_tokens - recent_tokens

            if middle_budget > 0:
                # Group low-importance messages for summarization
                high_importance = [imp for imp in middle_importance if imp.score >= 0.6]
                low_importance = [imp for imp in middle_importance if imp.score < 0.6]

                # Keep high-importance messages
                high_msgs: list[tuple[int, dict[str, str]]] = []
                for imp in high_importance:
                    high_msgs.append((imp.index, messages[imp.index]))

                high_msgs.sort(key=lambda x: x[0])
                budget_used = sum(
                    self._estimate_tokens([m]) for _, m in high_msgs
                )

                # Summarize low-importance messages if there's budget
                if low_importance and budget_used < middle_budget:
                    summary_budget = middle_budget - budget_used
                    low_msgs = [messages[imp.index] for imp in low_importance]
                    low_msgs.sort(key=messages.index)  # Preserve order

                    summary = self._summarize_messages(low_msgs, summary_budget)
                    if summary:
                        kept.append({
                            "role": "system",
                            "content": f"[Previous conversation summary: {summary}]",
                        })
                        summarized = len(low_msgs)
                    else:
                        removed = len(low_msgs)

                # Add high-importance middle messages
                for _, msg in high_msgs:
                    if self._estimate_tokens([*kept, msg]) < self._max_tokens - recent_tokens:
                        kept.append(msg)
                    else:
                        removed += 1
            else:
                removed = len(middle_msgs)

        # Add recent messages
        kept.extend(recent_msgs)

        compressed_tokens = self._estimate_tokens(kept)
        ratio = compressed_tokens / max(original_tokens, 1)

        return CompressionResult(
            messages=kept,
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            messages_removed=removed,
            messages_summarized=summarized,
            compression_ratio=round(ratio, 3),
        )

    def score_messages(
        self, messages: list[dict[str, str]], query: str = "",
    ) -> list[MessageImportance]:
        """Score importance of all messages.

        Args:
            messages: Conversation messages.
            query: Current query for relevance scoring.

        Returns:
            List of MessageImportance scores.
        """
        return self._score_importance(messages, query)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _score_importance(
        self,
        messages: list[dict[str, str]],
        query: str,
    ) -> list[MessageImportance]:
        """Score each message's importance."""
        scores: list[MessageImportance] = []
        n = len(messages)
        query_words = set(query.lower().split()) if query else set()

        for i, msg in enumerate(messages):
            role = msg.get("role", "")
            content = msg.get("content", "")
            content_lower = content.lower()
            reasons: list[str] = []
            score = 0.3  # Base score

            # Role-based scoring
            if role == "system":
                score = 0.95
                reasons.append("system message")
            elif role == "user":
                score = 0.5
                reasons.append("user message")

            # Recency bonus
            recency = i / max(n - 1, 1)
            score += recency * 0.2
            if recency > 0.8:
                reasons.append("recent")

            # Code content
            has_code = bool(_CODE_BLOCK_RE.search(content))
            if has_code:
                score += 0.15
                reasons.append("contains code")

            # File references
            if _FILE_PATH_RE.search(content):
                score += 0.1
                reasons.append("references files")

            # Error/debugging content
            if any(kw in content_lower for kw in _ERROR_KEYWORDS):
                score += 0.1
                reasons.append("error-related")

            # Intent detection (user asking for something specific)
            if role == "user" and any(kw in content_lower for kw in _INTENT_KEYWORDS):
                score += 0.1
                reasons.append("contains intent")

            # Tool execution results
            if any(ind in content_lower for ind in _TOOL_INDICATORS):
                score += 0.1
                reasons.append("tool result")

            # Query relevance (high weight — this is the user's current focus)
            if query_words:
                msg_words = set(content_lower.split())
                overlap = len(query_words & msg_words) / max(len(query_words), 1)
                if overlap > 0.2:
                    score += overlap * 0.35
                    reasons.append("relevant to query")

            # Length penalty for very long messages with low information density
            est_tokens = self._estimate_tokens_single(content)
            if est_tokens > 500 and not has_code:
                score -= 0.05
                reasons.append("long non-code message")

            scores.append(MessageImportance(
                index=i,
                role=role,
                score=min(1.0, score),
                reasons=reasons,
                has_code=has_code,
                estimated_tokens=est_tokens,
            ))

        return scores

    def _summarize_messages(
        self, messages: list[dict[str, str]], budget: int,
    ) -> str:
        """Create a brief summary of messages.

        This uses extractive summarization (key phrases) rather than
        generative summarization to avoid hallucination.
        """
        if not messages:
            return ""

        # Extract key information
        topics: list[str] = []
        actions: list[str] = []
        files: set[str] = set()

        for msg in messages:
            content = msg.get("content", "")
            role = msg.get("role", "")

            # Extract file references
            file_matches = _FILE_PATH_RE.findall(content)
            files.update(file_matches[:3])  # Limit per message

            # Extract first sentence of each user message (likely the intent)
            if role == "user":
                first_sentence = content.split(".")[0].strip()
                if len(first_sentence) > 10:
                    topics.append(first_sentence[:100])

            # Extract action descriptions from assistant messages
            if role == "assistant":
                for indicator in _TOOL_INDICATORS:
                    if indicator in content.lower():
                        line = next(
                            (ln.strip() for ln in content.split("\n")
                             if indicator in ln.lower()),
                            "",
                        )
                        if line:
                            actions.append(line[:80])
                        break

        parts: list[str] = []
        if topics:
            parts.append("Topics: " + "; ".join(topics[:5]))
        if actions:
            parts.append("Actions: " + "; ".join(actions[:5]))
        if files:
            parts.append("Files: " + ", ".join(sorted(files)[:10]))

        summary = " | ".join(parts)

        # Truncate to budget
        max_chars = int(budget * 4)  # Rough chars per token
        if len(summary) > max_chars:
            summary = summary[:max_chars] + "..."

        return summary

    def _estimate_tokens(self, messages: list[dict[str, str]]) -> int:
        """Estimate total tokens in messages."""
        total = sum(
            self._estimate_tokens_single(m.get("content", ""))
            for m in messages
        )
        return total + len(messages) * 4  # Message overhead

    def _estimate_tokens_single(self, text: str) -> int:
        """Estimate tokens in a single text."""
        return max(1, int(len(text.split()) * 0.75))
