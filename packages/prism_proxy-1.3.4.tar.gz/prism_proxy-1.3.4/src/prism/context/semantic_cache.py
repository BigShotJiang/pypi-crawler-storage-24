"""Semantic cache — intelligent prompt-response caching with similarity matching.

Stores prompt-response pairs and retrieves cached responses when a new prompt
is semantically similar (not just identical) to a previously seen one.  Uses
TF-IDF cosine similarity so no external vector database is required.

Key features:

- Per-model cache buckets (hits only match the same model).
- TTL-based expiration with configurable lifetime.
- LRU eviction when the cache exceeds its maximum size.
- Hit / miss / eviction statistics.
- Optional SQLite-backed persistence.
- Thread-safe via ``threading.Lock``.
"""

from __future__ import annotations

import math
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import structlog

from prism.exceptions import ContextError

if TYPE_CHECKING:
    from pathlib import Path

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Tokeniser helpers (stdlib only)
# ---------------------------------------------------------------------------

_WORD_RE = re.compile(r"[a-zA-Z0-9]+")


def _tokenize(text: str) -> list[str]:
    """Split *text* into lowercase alphanumeric tokens.

    Args:
        text: The input string to tokenise.

    Returns:
        A list of lower-cased word tokens.
    """
    return [m.group().lower() for m in _WORD_RE.finditer(text)]


# ---------------------------------------------------------------------------
# TF-IDF helpers
# ---------------------------------------------------------------------------


def _term_frequency(tokens: list[str]) -> dict[str, float]:
    """Compute normalised term-frequency vector for *tokens*.

    Args:
        tokens: Pre-tokenised word list.

    Returns:
        Mapping of token to its TF value.
    """
    if not tokens:
        return {}
    counts: dict[str, int] = {}
    for tok in tokens:
        counts[tok] = counts.get(tok, 0) + 1
    total = len(tokens)
    return {tok: count / total for tok, count in counts.items()}


def _idf(corpus_tfs: list[dict[str, float]]) -> dict[str, float]:
    """Compute inverse-document-frequency across a corpus of TF vectors.

    Uses smooth IDF:  ``log((1 + N) / (1 + df)) + 1`` to avoid division
    by zero and to never produce a zero weight.

    Args:
        corpus_tfs: List of TF dictionaries — one per document.

    Returns:
        Mapping of token to its IDF value.
    """
    n = len(corpus_tfs)
    df: dict[str, int] = {}
    for tf_vec in corpus_tfs:
        for tok in tf_vec:
            df[tok] = df.get(tok, 0) + 1
    return {tok: math.log((1 + n) / (1 + doc_freq)) + 1 for tok, doc_freq in df.items()}


def _tfidf_vector(tf: dict[str, float], idf_map: dict[str, float]) -> dict[str, float]:
    """Multiply TF and IDF to produce a TF-IDF vector.

    Args:
        tf: Term-frequency mapping.
        idf_map: Inverse-document-frequency mapping.

    Returns:
        Sparse TF-IDF vector as a dict.
    """
    return {tok: tf_val * idf_map.get(tok, 1.0) for tok, tf_val in tf.items()}


def _cosine_similarity(vec_a: dict[str, float], vec_b: dict[str, float]) -> float:
    """Compute cosine similarity between two sparse vectors.

    Args:
        vec_a: First sparse vector.
        vec_b: Second sparse vector.

    Returns:
        Cosine similarity in ``[0.0, 1.0]``.  Returns ``0.0`` when either
        vector is empty.
    """
    if not vec_a or not vec_b:
        return 0.0

    # Dot product — iterate over the smaller set for speed.
    if len(vec_a) > len(vec_b):
        vec_a, vec_b = vec_b, vec_a
    dot = sum(val * vec_b[tok] for tok, val in vec_a.items() if tok in vec_b)

    norm_a = math.sqrt(sum(v * v for v in vec_a.values()))
    norm_b = math.sqrt(sum(v * v for v in vec_b.values()))

    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0

    return dot / (norm_a * norm_b)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class CacheConfig:
    """Configuration for :class:`SemanticCache`.

    Args:
        max_size: Maximum number of entries per model bucket.
        ttl_seconds: Time-to-live for cache entries in seconds.
            ``0`` means entries never expire.
        similarity_threshold: Minimum cosine similarity for a cache hit.
        persist_path: Optional filesystem path for SQLite persistence.
            When *None* (default) the cache lives only in memory.
    """

    max_size: int = 256
    ttl_seconds: int = 3600
    similarity_threshold: float = 0.85
    persist_path: Path | None = None

    def __post_init__(self) -> None:
        if self.max_size < 1:
            msg = "max_size must be >= 1"
            raise ContextError(msg)
        if self.ttl_seconds < 0:
            msg = "ttl_seconds must be >= 0"
            raise ContextError(msg)
        if not 0.0 <= self.similarity_threshold <= 1.0:
            msg = "similarity_threshold must be in [0.0, 1.0]"
            raise ContextError(msg)


@dataclass
class CacheEntry:
    """A single cached prompt-response pair.

    Attributes:
        prompt: The original user prompt.
        response: The cached LLM response.
        model: The model that generated *response*.
        timestamp: Epoch seconds when the entry was created.
        tf: Pre-computed term-frequency vector for *prompt*.
        hit_count: Number of times this entry has been returned as a hit.
        last_accessed: Epoch seconds of the most recent access (for LRU).
    """

    prompt: str
    response: str
    model: str
    timestamp: float
    tf: dict[str, float] = field(default_factory=dict)
    hit_count: int = 0
    last_accessed: float = 0.0

    def __post_init__(self) -> None:
        if self.last_accessed == 0.0:
            self.last_accessed = self.timestamp


@dataclass
class CacheStats:
    """Aggregate statistics for the semantic cache.

    Attributes:
        hits: Total number of cache hits.
        misses: Total number of cache misses.
        evictions: Total number of LRU evictions.
        total_similarity_sum: Running sum of similarities for hits
            (used to compute *avg_similarity*).
    """

    hits: int = 0
    misses: int = 0
    evictions: int = 0
    total_similarity_sum: float = 0.0

    @property
    def avg_similarity(self) -> float:
        """Average cosine similarity across all cache hits."""
        if self.hits == 0:
            return 0.0
        return self.total_similarity_sum / self.hits

    @property
    def total_requests(self) -> int:
        """Total number of look-ups (hits + misses)."""
        return self.hits + self.misses

    @property
    def hit_rate(self) -> float:
        """Fraction of look-ups that were cache hits."""
        if self.total_requests == 0:
            return 0.0
        return self.hits / self.total_requests


# ---------------------------------------------------------------------------
# SemanticCache
# ---------------------------------------------------------------------------


class SemanticCache:
    """Intelligent prompt-response cache with TF-IDF cosine similarity matching.

    Entries are partitioned by *model* so a prompt that was answered by GPT-4
    will never be returned when the caller requests Claude.

    Args:
        config: Cache configuration.  Uses sensible defaults when *None*.
    """

    def __init__(self, config: CacheConfig | None = None) -> None:
        self._config = config or CacheConfig()
        # model -> list[CacheEntry]   (newest entries appended at the end)
        self._buckets: dict[str, list[CacheEntry]] = {}
        self._stats = CacheStats()
        self._lock = threading.Lock()
        self._db: sqlite3.Connection | None = None

        if self._config.persist_path is not None:
            self._init_db()

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def config(self) -> CacheConfig:
        """Return the active cache configuration."""
        return self._config

    @property
    def stats(self) -> CacheStats:
        """Return current cache statistics (read-only snapshot)."""
        with self._lock:
            return CacheStats(
                hits=self._stats.hits,
                misses=self._stats.misses,
                evictions=self._stats.evictions,
                total_similarity_sum=self._stats.total_similarity_sum,
            )

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def get(self, prompt: str, model: str) -> str | None:
        """Look up a cached response for *prompt* using semantic similarity.

        Args:
            prompt: The user prompt to look up.
            model: Only consider entries generated by this model.

        Returns:
            The cached response string, or *None* on a miss.
        """
        if not prompt or not prompt.strip():
            return None

        query_tokens = _tokenize(prompt)
        query_tf = _term_frequency(query_tokens)

        with self._lock:
            entries = self._buckets.get(model)
            if not entries:
                self._stats.misses += 1
                logger.debug("cache_miss", model=model, reason="no_bucket")
                return None

            # Expire stale entries first.
            self._evict_expired(model)
            entries = self._buckets.get(model)
            if not entries:
                self._stats.misses += 1
                logger.debug("cache_miss", model=model, reason="all_expired")
                return None

            # Build IDF from the current bucket + query.
            all_tfs = [e.tf for e in entries] + [query_tf]
            idf_map = _idf(all_tfs)

            query_vec = _tfidf_vector(query_tf, idf_map)

            best_entry: CacheEntry | None = None
            best_sim = 0.0

            for entry in entries:
                entry_vec = _tfidf_vector(entry.tf, idf_map)
                sim = _cosine_similarity(query_vec, entry_vec)
                if sim > best_sim:
                    best_sim = sim
                    best_entry = entry

            if best_entry is not None and best_sim >= self._config.similarity_threshold:
                best_entry.hit_count += 1
                best_entry.last_accessed = time.time()
                self._stats.hits += 1
                self._stats.total_similarity_sum += best_sim
                logger.debug(
                    "cache_hit",
                    model=model,
                    similarity=round(best_sim, 4),
                    hit_count=best_entry.hit_count,
                )
                return best_entry.response

            self._stats.misses += 1
            logger.debug(
                "cache_miss",
                model=model,
                best_similarity=round(best_sim, 4),
                threshold=self._config.similarity_threshold,
            )
            return None

    def put(self, prompt: str, response: str, model: str) -> None:
        """Store a prompt-response pair in the cache.

        If the bucket for *model* is full, the least-recently-used entry
        is evicted.

        Args:
            prompt: The user prompt.
            response: The LLM response to cache.
            model: The model that generated *response*.

        Raises:
            ContextError: If *prompt* or *response* is empty.
        """
        if not prompt or not prompt.strip():
            msg = "Cannot cache an empty prompt"
            raise ContextError(msg)
        if not response or not response.strip():
            msg = "Cannot cache an empty response"
            raise ContextError(msg)
        if not model or not model.strip():
            msg = "Cannot cache without a model identifier"
            raise ContextError(msg)

        tokens = _tokenize(prompt)
        tf = _term_frequency(tokens)
        now = time.time()

        entry = CacheEntry(
            prompt=prompt,
            response=response,
            model=model,
            timestamp=now,
            tf=tf,
            hit_count=0,
            last_accessed=now,
        )

        with self._lock:
            bucket = self._buckets.setdefault(model, [])

            # LRU eviction when at capacity.
            while len(bucket) >= self._config.max_size:
                self._evict_lru(model)

            bucket.append(entry)

            if self._db is not None:
                self._persist_entry(entry)

        logger.debug("cache_put", model=model, prompt_tokens=len(tokens))

    def clear(self, model: str | None = None) -> int:
        """Remove cache entries.

        Args:
            model: If provided, only clear entries for this model.
                Otherwise clear everything.

        Returns:
            The number of entries removed.
        """
        with self._lock:
            if model is not None:
                bucket = self._buckets.pop(model, [])
                removed = len(bucket)
            else:
                removed = sum(len(b) for b in self._buckets.values())
                self._buckets.clear()

            if self._db is not None:
                self._clear_persisted(model)

        logger.debug("cache_cleared", model=model, removed=removed)
        return removed

    def size(self, model: str | None = None) -> int:
        """Return the number of entries currently cached.

        Args:
            model: If provided, count only this model's entries.
        """
        with self._lock:
            if model is not None:
                return len(self._buckets.get(model, []))
            return sum(len(b) for b in self._buckets.values())

    def warm(self, entries: list[tuple[str, str, str]]) -> int:
        """Pre-load the cache from historical data.

        Args:
            entries: Sequence of ``(prompt, response, model)`` tuples.

        Returns:
            The number of entries successfully loaded.
        """
        loaded = 0
        for prompt, response, model in entries:
            try:
                self.put(prompt, response, model)
                loaded += 1
            except ContextError:
                logger.debug(
                    "cache_warm_skip",
                    prompt_preview=prompt[:40] if prompt else "",
                )
        logger.info("cache_warmed", loaded=loaded, total=len(entries))
        return loaded

    def reset_stats(self) -> None:
        """Reset all statistics counters to zero."""
        with self._lock:
            self._stats = CacheStats()

    def all_entries(self, model: str | None = None) -> list[CacheEntry]:
        """Return a shallow copy of all current entries.

        Args:
            model: If provided, only return entries for this model.

        Returns:
            List of :class:`CacheEntry` objects.
        """
        with self._lock:
            if model is not None:
                return list(self._buckets.get(model, []))
            result: list[CacheEntry] = []
            for bucket in self._buckets.values():
                result.extend(bucket)
            return result

    # ------------------------------------------------------------------
    # Eviction helpers (caller must hold ``_lock``)
    # ------------------------------------------------------------------

    def _evict_expired(self, model: str) -> None:
        """Remove entries that have exceeded the TTL."""
        if self._config.ttl_seconds == 0:
            return
        now = time.time()
        cutoff = now - self._config.ttl_seconds
        bucket = self._buckets.get(model)
        if not bucket:
            return
        before = len(bucket)
        self._buckets[model] = [e for e in bucket if e.timestamp > cutoff]
        evicted = before - len(self._buckets[model])
        self._stats.evictions += evicted
        if evicted:
            logger.debug("cache_ttl_evict", model=model, evicted=evicted)

    def _evict_lru(self, model: str) -> None:
        """Remove the least-recently-used entry from *model*'s bucket."""
        bucket = self._buckets.get(model)
        if not bucket:
            return
        lru_idx = 0
        lru_time = bucket[0].last_accessed
        for idx, entry in enumerate(bucket):
            if entry.last_accessed < lru_time:
                lru_time = entry.last_accessed
                lru_idx = idx
        bucket.pop(lru_idx)
        self._stats.evictions += 1
        logger.debug("cache_lru_evict", model=model)

    # ------------------------------------------------------------------
    # SQLite persistence
    # ------------------------------------------------------------------

    def _init_db(self) -> None:
        """Open (or create) the SQLite database for persistence."""
        persist_path = self._config.persist_path
        if persist_path is None:
            return
        try:
            self._db = sqlite3.connect(str(persist_path), check_same_thread=False)
            self._db.execute(
                """
                CREATE TABLE IF NOT EXISTS cache_entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    prompt TEXT NOT NULL,
                    response TEXT NOT NULL,
                    model TEXT NOT NULL,
                    timestamp REAL NOT NULL,
                    hit_count INTEGER NOT NULL DEFAULT 0,
                    last_accessed REAL NOT NULL
                )
                """
            )
            self._db.commit()
            self._load_persisted()
        except sqlite3.Error as exc:
            logger.warning("cache_db_init_failed", error=str(exc))
            self._db = None

    def _load_persisted(self) -> None:
        """Load all persisted entries back into memory."""
        if self._db is None:
            return
        try:
            cursor = self._db.execute(
                "SELECT prompt, response, model, timestamp, hit_count, last_accessed "
                "FROM cache_entries ORDER BY last_accessed"
            )
            for row in cursor.fetchall():
                prompt, response, model, ts, hit_count, last_accessed = row
                tokens = _tokenize(prompt)
                tf = _term_frequency(tokens)
                entry = CacheEntry(
                    prompt=prompt,
                    response=response,
                    model=model,
                    timestamp=ts,
                    tf=tf,
                    hit_count=hit_count,
                    last_accessed=last_accessed,
                )
                bucket = self._buckets.setdefault(model, [])
                # Respect max_size during load — drop oldest if over limit.
                if len(bucket) >= self._config.max_size:
                    continue
                bucket.append(entry)
        except sqlite3.Error as exc:
            logger.warning("cache_db_load_failed", error=str(exc))

    def _persist_entry(self, entry: CacheEntry) -> None:
        """Write a single entry to the database."""
        if self._db is None:
            return
        try:
            self._db.execute(
                "INSERT INTO cache_entries (prompt, response, model, timestamp, "
                "hit_count, last_accessed) VALUES (?, ?, ?, ?, ?, ?)",
                (
                    entry.prompt,
                    entry.response,
                    entry.model,
                    entry.timestamp,
                    entry.hit_count,
                    entry.last_accessed,
                ),
            )
            self._db.commit()
        except sqlite3.Error as exc:
            logger.warning("cache_db_persist_failed", error=str(exc))

    def _clear_persisted(self, model: str | None) -> None:
        """Delete persisted entries from the database."""
        if self._db is None:
            return
        try:
            if model is not None:
                self._db.execute("DELETE FROM cache_entries WHERE model = ?", (model,))
            else:
                self._db.execute("DELETE FROM cache_entries")
            self._db.commit()
        except sqlite3.Error as exc:
            logger.warning("cache_db_clear_failed", error=str(exc))

    def close(self) -> None:
        """Close the underlying database connection (if any)."""
        if self._db is not None:
            import contextlib
            with contextlib.suppress(sqlite3.Error):
                self._db.close()
            self._db = None

    def __del__(self) -> None:
        self.close()
