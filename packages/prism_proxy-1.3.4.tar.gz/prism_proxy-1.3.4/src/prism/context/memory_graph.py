"""Conversation memory graph — persistent graph-structured memory for conversations.

Provides a graph-based memory system where facts, preferences, entities,
events, and concepts are stored as nodes connected by typed edges.  Supports
TF-IDF similarity search, BFS traversal, temporal decay, deduplication via
consolidation, and DOT export for visualization.

All storage is backed by SQLite (thread-safe, WAL mode) with no external
dependencies beyond the standard library and structlog.

Usage::

    graph = MemoryGraph(db_path=Path("memory.db"))
    node_id = graph.add_memory("User prefers dark mode", "preference", importance=0.8)
    graph.connect(node_id, other_id, "related_to")
    results = graph.search("dark mode", top_k=5)
    context = graph.get_context_memories("theme settings", budget_tokens=500)

    tracker = ConversationTracker(graph)
    tracker.process_turn("user", "I prefer Python and use pytest for testing.")
    memories = tracker.get_conversation_context("testing framework")
"""

from __future__ import annotations

import hashlib
import math
import re
import sqlite3
import threading
import time
import uuid
from collections import Counter, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from pathlib import Path

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class NodeType(Enum):
    """Types of memory nodes."""

    FACT = "fact"
    PREFERENCE = "preference"
    ENTITY = "entity"
    EVENT = "event"
    CONCEPT = "concept"


class Relationship(Enum):
    """Types of edges between memory nodes."""

    REFERENCES = "references"
    DEPENDS_ON = "depends_on"
    CONTRADICTS = "contradicts"
    SUPERSEDES = "supersedes"
    RELATED_TO = "related_to"


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class MemoryNode:
    """A single memory node in the graph.

    Attributes:
        id: Unique identifier (UUID hex string).
        content: The textual content of this memory.
        node_type: Category of memory (fact, preference, entity, event, concept).
        timestamp: Unix timestamp when the memory was created.
        importance_score: Relevance weight from 0.0 to 1.0.
        access_count: Number of times this memory has been retrieved.
        embedding_hash: SHA-256 hash of the tokenized content for dedup.
    """

    id: str
    content: str
    node_type: str
    timestamp: float
    importance_score: float
    access_count: int
    embedding_hash: str


@dataclass
class MemoryEdge:
    """A directed edge between two memory nodes.

    Attributes:
        source_id: ID of the source memory node.
        target_id: ID of the target memory node.
        relationship: Type of relationship between the nodes.
        weight: Strength of the connection from 0.0 to 1.0.
        timestamp: Unix timestamp when the edge was created.
    """

    source_id: str
    target_id: str
    relationship: str
    weight: float
    timestamp: float


@dataclass
class MemorySearchResult:
    """A memory search hit with its relevance score.

    Attributes:
        node: The matched memory node.
        score: TF-IDF cosine similarity score (0.0 to 1.0).
        matched_terms: Query terms that matched the node content.
    """

    node: MemoryNode
    score: float
    matched_terms: list[str] = field(default_factory=list)


@dataclass
class GraphStats:
    """Aggregate statistics about the memory graph.

    Attributes:
        node_count: Total number of memory nodes.
        edge_count: Total number of edges.
        avg_importance: Mean importance score across all nodes.
        node_type_counts: Count of nodes per type.
        relationship_counts: Count of edges per relationship type.
        oldest_memory: Timestamp of the oldest node, or None if empty.
        newest_memory: Timestamp of the newest node, or None if empty.
    """

    node_count: int
    edge_count: int
    avg_importance: float
    node_type_counts: dict[str, int]
    relationship_counts: dict[str, int]
    oldest_memory: float | None
    newest_memory: float | None


# ---------------------------------------------------------------------------
# TF-IDF tokenizer (reuses pattern from prism.context.rag)
# ---------------------------------------------------------------------------

_STOP_WORDS = frozenset({
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "it", "this", "that", "these",
    "those", "i", "you", "we", "they", "he", "she", "my", "your",
    "and", "or", "but", "if", "then", "else", "when", "while", "not",
    "no", "so", "as", "than", "too", "very",
})

_WORD_PATTERN = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")
_CAMEL_SPLIT = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def _tokenize(text: str) -> list[str]:
    """Tokenize text into searchable terms.

    Handles camelCase splitting, snake_case splitting, and stop-word removal.

    Args:
        text: Raw text to tokenize.

    Returns:
        List of lowercase tokens with stop words removed.
    """
    words = _WORD_PATTERN.findall(text)
    tokens: list[str] = []
    for word in words:
        lower = word.lower()
        if lower in _STOP_WORDS or len(lower) < 2:
            continue
        tokens.append(lower)
        # Split camelCase
        parts = _CAMEL_SPLIT.split(word)
        if len(parts) > 1:
            tokens.extend(p.lower() for p in parts if len(p) >= 2)
        # Split snake_case
        if "_" in word:
            tokens.extend(p.lower() for p in word.split("_") if len(p) >= 2)
    return tokens


def _compute_embedding_hash(content: str) -> str:
    """Compute a SHA-256 hash of the tokenized content for deduplication.

    Args:
        content: Raw text content.

    Returns:
        Hex digest of the hash.
    """
    tokens = sorted(set(_tokenize(content)))
    return hashlib.sha256(" ".join(tokens).encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# SQLite schema
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS memory_nodes (
    id             TEXT PRIMARY KEY,
    content        TEXT NOT NULL,
    node_type      TEXT NOT NULL,
    timestamp      REAL NOT NULL,
    importance_score REAL NOT NULL DEFAULT 0.5,
    access_count   INTEGER NOT NULL DEFAULT 0,
    embedding_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_edges (
    source_id    TEXT NOT NULL,
    target_id    TEXT NOT NULL,
    relationship TEXT NOT NULL,
    weight       REAL NOT NULL DEFAULT 1.0,
    timestamp    REAL NOT NULL,
    PRIMARY KEY (source_id, target_id, relationship),
    FOREIGN KEY (source_id) REFERENCES memory_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (target_id) REFERENCES memory_nodes(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_nodes_type ON memory_nodes(node_type);
CREATE INDEX IF NOT EXISTS idx_nodes_importance ON memory_nodes(importance_score);
CREATE INDEX IF NOT EXISTS idx_nodes_hash ON memory_nodes(embedding_hash);
CREATE INDEX IF NOT EXISTS idx_edges_source ON memory_edges(source_id);
CREATE INDEX IF NOT EXISTS idx_edges_target ON memory_edges(target_id);
"""


# ---------------------------------------------------------------------------
# MemoryGraph
# ---------------------------------------------------------------------------


class MemoryGraph:
    """Graph-structured conversation memory backed by SQLite.

    Stores memory nodes (facts, preferences, entities, events, concepts)
    and typed edges between them.  Provides TF-IDF search, BFS traversal,
    temporal decay, consolidation, and DOT export.

    Thread safety is achieved via a ``threading.Lock`` guarding all database
    writes, and SQLite WAL mode for concurrent reads.

    Args:
        db_path: Path to the SQLite database file.  Use ``":memory:"`` for
            an ephemeral in-memory database (useful for testing).
    """

    def __init__(self, db_path: Path | str = ":memory:") -> None:
        self._db_path = str(db_path)
        self._lock = threading.Lock()
        self._conn = self._connect()
        self._ensure_schema()

    # ------------------------------------------------------------------
    # Connection helpers
    # ------------------------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        """Create and configure a SQLite connection.

        Returns:
            Configured sqlite3.Connection with WAL mode and foreign keys.
        """
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        """Create tables and indexes if they do not exist."""
        with self._lock:
            self._conn.executescript(_SCHEMA_SQL)
            self._conn.commit()

    # ------------------------------------------------------------------
    # Node operations
    # ------------------------------------------------------------------

    def add_memory(
        self,
        content: str,
        node_type: str,
        importance: float = 0.5,
        *,
        node_id: str | None = None,
        timestamp: float | None = None,
    ) -> str:
        """Add a new memory node to the graph.

        Args:
            content: Textual content of the memory.
            node_type: One of ``"fact"``, ``"preference"``, ``"entity"``,
                ``"event"``, ``"concept"``.
            importance: Importance score between 0.0 and 1.0.
            node_id: Optional explicit ID.  If ``None``, a UUID is generated.
            timestamp: Optional explicit timestamp.  If ``None``, uses now.

        Returns:
            The ID of the newly created node.

        Raises:
            ValueError: If *content* is empty or *importance* is out of range.
        """
        if not content or not content.strip():
            raise ValueError("Memory content must not be empty")
        if not (0.0 <= importance <= 1.0):
            raise ValueError(f"Importance must be between 0.0 and 1.0, got {importance}")

        # Validate node_type
        valid_types = {t.value for t in NodeType}
        if node_type not in valid_types:
            raise ValueError(
                f"Invalid node_type '{node_type}'. "
                f"Must be one of: {', '.join(sorted(valid_types))}"
            )

        nid = node_id or uuid.uuid4().hex
        ts = timestamp or time.time()
        emb_hash = _compute_embedding_hash(content)

        with self._lock:
            self._conn.execute(
                """
                INSERT INTO memory_nodes
                    (id, content, node_type, timestamp, importance_score, access_count, embedding_hash)
                VALUES (?, ?, ?, ?, ?, 0, ?)
                """,
                (nid, content.strip(), node_type, ts, importance, emb_hash),
            )
            self._conn.commit()

        logger.debug(
            "memory_node_added",
            node_id=nid,
            node_type=node_type,
            importance=importance,
        )
        return nid

    def get_node(self, node_id: str) -> MemoryNode | None:
        """Retrieve a single memory node by ID.

        Args:
            node_id: The node identifier.

        Returns:
            The MemoryNode if found, otherwise None.
        """
        row = self._conn.execute(
            "SELECT * FROM memory_nodes WHERE id = ?", (node_id,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_node(row)

    def remove_node(self, node_id: str) -> bool:
        """Remove a memory node and all its edges.

        Args:
            node_id: The node identifier.

        Returns:
            True if the node existed and was removed.
        """
        with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM memory_nodes WHERE id = ?", (node_id,)
            )
            # Edges are removed by ON DELETE CASCADE
            self._conn.commit()
        removed = cursor.rowcount > 0
        if removed:
            logger.debug("memory_node_removed", node_id=node_id)
        return removed

    # ------------------------------------------------------------------
    # Edge operations
    # ------------------------------------------------------------------

    def connect(
        self,
        source_id: str,
        target_id: str,
        relationship: str,
        weight: float = 1.0,
        *,
        timestamp: float | None = None,
    ) -> None:
        """Create a directed edge between two memory nodes.

        If an edge with the same (source, target, relationship) triple already
        exists, its weight and timestamp are updated.

        Args:
            source_id: ID of the source node.
            target_id: ID of the target node.
            relationship: One of ``"references"``, ``"depends_on"``,
                ``"contradicts"``, ``"supersedes"``, ``"related_to"``.
            weight: Edge weight between 0.0 and 1.0.
            timestamp: Optional explicit timestamp.

        Raises:
            ValueError: If either node does not exist, or *relationship* is
                invalid, or *weight* is out of range.
        """
        valid_rels = {r.value for r in Relationship}
        if relationship not in valid_rels:
            raise ValueError(
                f"Invalid relationship '{relationship}'. "
                f"Must be one of: {', '.join(sorted(valid_rels))}"
            )
        if not (0.0 <= weight <= 1.0):
            raise ValueError(f"Weight must be between 0.0 and 1.0, got {weight}")

        # Verify both nodes exist
        if self.get_node(source_id) is None:
            raise ValueError(f"Source node '{source_id}' does not exist")
        if self.get_node(target_id) is None:
            raise ValueError(f"Target node '{target_id}' does not exist")

        ts = timestamp or time.time()

        with self._lock:
            self._conn.execute(
                """
                INSERT INTO memory_edges (source_id, target_id, relationship, weight, timestamp)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT (source_id, target_id, relationship)
                DO UPDATE SET weight = excluded.weight, timestamp = excluded.timestamp
                """,
                (source_id, target_id, relationship, weight, ts),
            )
            self._conn.commit()

        logger.debug(
            "memory_edge_added",
            source=source_id,
            target=target_id,
            relationship=relationship,
        )

    def get_edges(self, node_id: str) -> list[MemoryEdge]:
        """Get all edges connected to a node (both directions).

        Args:
            node_id: The node identifier.

        Returns:
            List of MemoryEdge instances connected to the node.
        """
        rows = self._conn.execute(
            """
            SELECT source_id, target_id, relationship, weight, timestamp
            FROM memory_edges
            WHERE source_id = ? OR target_id = ?
            """,
            (node_id, node_id),
        ).fetchall()
        return [
            MemoryEdge(
                source_id=r["source_id"],
                target_id=r["target_id"],
                relationship=r["relationship"],
                weight=r["weight"],
                timestamp=r["timestamp"],
            )
            for r in rows
        ]

    def remove_edge(
        self, source_id: str, target_id: str, relationship: str
    ) -> bool:
        """Remove a specific edge.

        Args:
            source_id: ID of the source node.
            target_id: ID of the target node.
            relationship: The relationship type.

        Returns:
            True if the edge existed and was removed.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                DELETE FROM memory_edges
                WHERE source_id = ? AND target_id = ? AND relationship = ?
                """,
                (source_id, target_id, relationship),
            )
            self._conn.commit()
        return cursor.rowcount > 0

    # ------------------------------------------------------------------
    # Search (TF-IDF cosine similarity)
    # ------------------------------------------------------------------

    def search(self, query: str, top_k: int = 10) -> list[MemorySearchResult]:
        """Search memories by TF-IDF cosine similarity.

        Builds an ephemeral TF-IDF index over all stored nodes and ranks
        them against the query.  Access counts of returned nodes are
        incremented.

        Args:
            query: Natural language search query.
            top_k: Maximum number of results to return.

        Returns:
            List of MemorySearchResult sorted by score (highest first).
        """
        query_tokens = _tokenize(query)
        if not query_tokens:
            return []

        rows = self._conn.execute(
            "SELECT * FROM memory_nodes ORDER BY importance_score DESC"
        ).fetchall()
        if not rows:
            return []

        # Build per-document token lists and IDF
        doc_data: list[tuple[MemoryNode, list[str]]] = []
        df: Counter[str] = Counter()
        for row in rows:
            node = self._row_to_node(row)
            tokens = _tokenize(node.content)
            doc_data.append((node, tokens))
            for term in set(tokens):
                df[term] += 1

        n_docs = len(doc_data)
        idf: dict[str, float] = {}
        for term, count in df.items():
            idf[term] = math.log((n_docs + 1) / (count + 1)) + 1.0

        # Query TF-IDF vector
        query_tf = Counter(query_tokens)
        query_vec: dict[str, float] = {}
        for term, count in query_tf.items():
            query_vec[term] = count * idf.get(term, 0.0)

        query_norm = math.sqrt(sum(v * v for v in query_vec.values()))
        if query_norm == 0:
            return []

        scored: list[tuple[float, MemoryNode, list[str]]] = []
        for node, doc_tokens in doc_data:
            doc_tf = Counter(doc_tokens)
            dot = 0.0
            doc_norm_sq = 0.0
            matched: list[str] = []

            for term, count in doc_tf.items():
                tfidf = count * idf.get(term, 0.0)
                doc_norm_sq += tfidf * tfidf
                if term in query_vec:
                    dot += tfidf * query_vec[term]
                    matched.append(term)

            doc_norm = math.sqrt(doc_norm_sq)
            if doc_norm == 0 or not matched:
                continue

            # Combine TF-IDF score with importance boost
            cosine = dot / (query_norm * doc_norm)
            boosted = cosine * (0.7 + 0.3 * node.importance_score)
            scored.append((boosted, node, matched))

        scored.sort(key=lambda x: x[0], reverse=True)
        results = scored[:top_k]

        # Increment access counts for returned nodes
        if results:
            returned_ids = [node.id for _, node, _ in results]
            placeholders = ", ".join("?" for _ in returned_ids)
            with self._lock:
                self._conn.execute(
                    f"UPDATE memory_nodes SET access_count = access_count + 1 "  # noqa: S608
                    f"WHERE id IN ({placeholders})",
                    returned_ids,
                )
                self._conn.commit()

        return [
            MemorySearchResult(
                node=node,
                score=round(score, 4),
                matched_terms=matched,
            )
            for score, node, matched in results
        ]

    # ------------------------------------------------------------------
    # Graph traversal
    # ------------------------------------------------------------------

    def get_related(self, node_id: str, depth: int = 2) -> list[MemoryNode]:
        """Find related memories via BFS traversal.

        Args:
            node_id: Starting node ID.
            depth: Maximum BFS depth (number of hops).

        Returns:
            List of related MemoryNode instances (excluding the start node),
            ordered by distance then importance.
        """
        if depth < 1:
            return []
        if self.get_node(node_id) is None:
            return []

        visited: set[str] = {node_id}
        queue: deque[tuple[str, int]] = deque([(node_id, 0)])
        found: list[tuple[int, MemoryNode]] = []

        while queue:
            current_id, current_depth = queue.popleft()
            if current_depth >= depth:
                continue

            edges = self.get_edges(current_id)
            for edge in edges:
                neighbor_id = (
                    edge.target_id if edge.source_id == current_id else edge.source_id
                )
                if neighbor_id in visited:
                    continue
                visited.add(neighbor_id)

                neighbor = self.get_node(neighbor_id)
                if neighbor is not None:
                    found.append((current_depth + 1, neighbor))
                    queue.append((neighbor_id, current_depth + 1))

        # Sort by distance (ascending), then importance (descending)
        found.sort(key=lambda x: (x[0], -x[1].importance_score))
        return [node for _, node in found]

    # ------------------------------------------------------------------
    # Temporal decay
    # ------------------------------------------------------------------

    def decay(self, half_life_seconds: float = 86400.0) -> int:
        """Apply exponential decay to importance scores based on age.

        Nodes that have not been accessed recently lose importance.
        A higher access count slows the decay.

        Args:
            half_life_seconds: Time in seconds for importance to halve.
                Defaults to 86400 (one day).

        Returns:
            Number of nodes whose importance was updated.
        """
        now = time.time()
        rows = self._conn.execute(
            "SELECT id, timestamp, importance_score, access_count FROM memory_nodes"
        ).fetchall()

        updated = 0
        with self._lock:
            for row in rows:
                age = now - row["timestamp"]
                if age <= 0:
                    continue
                # Access count dampens decay: effective_age = age / (1 + log(1 + access_count))
                damping = 1.0 + math.log(1.0 + row["access_count"])
                effective_age = age / damping
                decay_factor = math.pow(0.5, effective_age / half_life_seconds)
                new_importance = row["importance_score"] * decay_factor

                # Clamp to a minimum floor so nodes are not zeroed out
                new_importance = max(new_importance, 0.01)

                if abs(new_importance - row["importance_score"]) > 1e-6:
                    self._conn.execute(
                        "UPDATE memory_nodes SET importance_score = ? WHERE id = ?",
                        (round(new_importance, 6), row["id"]),
                    )
                    updated += 1
            self._conn.commit()

        logger.debug("memory_decay_applied", updated_nodes=updated)
        return updated

    # ------------------------------------------------------------------
    # Consolidation
    # ------------------------------------------------------------------

    def consolidate(self, similarity_threshold: float = 0.85) -> int:
        """Merge highly similar memories to prevent bloat.

        Nodes with the same embedding hash are merged: the older node absorbs
        the newer one's content (appended), importance is maxed, and edges
        are re-pointed.

        Nodes with different hashes but high TF-IDF cosine similarity above
        *similarity_threshold* are also merged.

        Args:
            similarity_threshold: Cosine similarity threshold (0.0 to 1.0)
                above which two nodes are considered duplicates.

        Returns:
            Number of nodes that were merged (removed).
        """
        merged_count = 0

        # Phase 1: exact hash duplicates
        rows = self._conn.execute(
            """
            SELECT embedding_hash, GROUP_CONCAT(id) AS ids
            FROM memory_nodes
            GROUP BY embedding_hash
            HAVING COUNT(*) > 1
            """
        ).fetchall()

        for row in rows:
            ids = row["ids"].split(",")
            nodes = [self.get_node(nid) for nid in ids]
            nodes = [n for n in nodes if n is not None]
            if len(nodes) < 2:
                continue
            # Keep the one with highest importance
            nodes.sort(key=lambda n: (-n.importance_score, n.timestamp))
            keeper = nodes[0]
            for duplicate in nodes[1:]:
                self._merge_nodes(keeper.id, duplicate.id)
                merged_count += 1

        # Phase 2: near-duplicate detection via pairwise TF-IDF similarity
        all_rows = self._conn.execute(
            "SELECT * FROM memory_nodes ORDER BY importance_score DESC"
        ).fetchall()
        all_nodes = [self._row_to_node(r) for r in all_rows]

        if len(all_nodes) < 2:
            return merged_count

        # Precompute token lists
        node_tokens: dict[str, list[str]] = {}
        for node in all_nodes:
            node_tokens[node.id] = _tokenize(node.content)

        removed_ids: set[str] = set()
        for i, node_a in enumerate(all_nodes):
            if node_a.id in removed_ids:
                continue
            tokens_a = node_tokens[node_a.id]
            if not tokens_a:
                continue

            for node_b in all_nodes[i + 1 :]:
                if node_b.id in removed_ids:
                    continue
                if node_a.embedding_hash == node_b.embedding_hash:
                    continue  # Already handled in phase 1

                tokens_b = node_tokens[node_b.id]
                if not tokens_b:
                    continue

                sim = self._cosine_similarity(tokens_a, tokens_b)
                if sim >= similarity_threshold:
                    self._merge_nodes(node_a.id, node_b.id)
                    removed_ids.add(node_b.id)
                    merged_count += 1

        logger.debug("memory_consolidated", merged_count=merged_count)
        return merged_count

    def _merge_nodes(self, keeper_id: str, removed_id: str) -> None:
        """Merge *removed_id* into *keeper_id*.

        The keeper's content is extended, its importance is set to the max
        of both, and all edges pointing to *removed_id* are re-pointed to
        *keeper_id*.  The removed node is then deleted.

        Args:
            keeper_id: ID of the node to keep.
            removed_id: ID of the node to absorb and delete.
        """
        keeper = self.get_node(keeper_id)
        removed = self.get_node(removed_id)
        if keeper is None or removed is None:
            return

        new_importance = max(keeper.importance_score, removed.importance_score)
        new_access = keeper.access_count + removed.access_count

        # Append unique content from the removed node
        if removed.content.strip() not in keeper.content:
            merged_content = f"{keeper.content} | {removed.content}"
        else:
            merged_content = keeper.content

        new_hash = _compute_embedding_hash(merged_content)

        with self._lock:
            self._conn.execute(
                """
                UPDATE memory_nodes
                SET content = ?, importance_score = ?, access_count = ?, embedding_hash = ?
                WHERE id = ?
                """,
                (merged_content, new_importance, new_access, new_hash, keeper_id),
            )

            # Re-point edges from removed to keeper
            # For source edges: only update if it won't create a self-loop or duplicate
            edges = self._conn.execute(
                "SELECT source_id, target_id, relationship, weight, timestamp "
                "FROM memory_edges WHERE source_id = ? OR target_id = ?",
                (removed_id, removed_id),
            ).fetchall()

            for edge in edges:
                new_source = keeper_id if edge["source_id"] == removed_id else edge["source_id"]
                new_target = keeper_id if edge["target_id"] == removed_id else edge["target_id"]

                # Skip self-loops
                if new_source == new_target:
                    continue

                # Upsert the re-pointed edge
                self._conn.execute(
                    """
                    INSERT INTO memory_edges (source_id, target_id, relationship, weight, timestamp)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT (source_id, target_id, relationship)
                    DO UPDATE SET weight = MAX(excluded.weight, memory_edges.weight)
                    """,
                    (
                        new_source,
                        new_target,
                        edge["relationship"],
                        edge["weight"],
                        edge["timestamp"],
                    ),
                )

            # Delete the removed node (CASCADE removes its old edges)
            self._conn.execute("DELETE FROM memory_nodes WHERE id = ?", (removed_id,))
            self._conn.commit()

        logger.debug(
            "memory_nodes_merged",
            keeper=keeper_id,
            removed=removed_id,
        )

    @staticmethod
    def _cosine_similarity(tokens_a: list[str], tokens_b: list[str]) -> float:
        """Compute cosine similarity between two token lists using term frequency.

        Args:
            tokens_a: First token list.
            tokens_b: Second token list.

        Returns:
            Cosine similarity between 0.0 and 1.0.
        """
        tf_a = Counter(tokens_a)
        tf_b = Counter(tokens_b)
        all_terms = set(tf_a) | set(tf_b)

        dot = sum(tf_a.get(t, 0) * tf_b.get(t, 0) for t in all_terms)
        norm_a = math.sqrt(sum(v * v for v in tf_a.values()))
        norm_b = math.sqrt(sum(v * v for v in tf_b.values()))

        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    # ------------------------------------------------------------------
    # Context retrieval
    # ------------------------------------------------------------------

    def get_context_memories(
        self, query: str, budget_tokens: int = 2000
    ) -> str:
        """Get the most relevant memories formatted for prompt injection.

        Searches the graph and formats results within a token budget,
        suitable for including in an LLM system prompt.

        Args:
            query: The current user query or topic.
            budget_tokens: Approximate maximum token budget.

        Returns:
            Formatted context string, or empty string if no relevant
            memories exist.
        """
        results = self.search(query, top_k=20)
        if not results:
            return ""

        parts: list[str] = ["[Conversation Memory]"]
        token_estimate = 5  # header

        for result in results:
            node = result.node
            line = (
                f"- [{node.node_type}] {node.content} "
                f"(relevance: {result.score:.2f})"
            )
            line_tokens = len(line.split()) * 1.3  # rough estimate
            if token_estimate + line_tokens > budget_tokens:
                break
            parts.append(line)
            token_estimate += line_tokens

        if len(parts) <= 1:
            return ""
        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Pruning
    # ------------------------------------------------------------------

    def prune(self, max_nodes: int = 1000) -> int:
        """Remove least important memories when graph exceeds capacity.

        Nodes are ranked by ``importance_score * (1 + log(1 + access_count))``
        and the lowest-ranked nodes beyond *max_nodes* are removed.

        Args:
            max_nodes: Maximum number of nodes to retain.

        Returns:
            Number of nodes removed.
        """
        count = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM memory_nodes"
        ).fetchone()["cnt"]

        if count <= max_nodes:
            return 0

        to_remove = count - max_nodes

        # Fetch all nodes and compute effective importance in Python
        # (avoids reliance on SQLite math functions which require 3.35+)
        rows = self._conn.execute(
            "SELECT id, importance_score, access_count FROM memory_nodes"
        ).fetchall()

        scored_ids: list[tuple[float, str]] = []
        for row in rows:
            effective = row["importance_score"] * (
                1.0 + math.log(1.0 + row["access_count"])
            )
            scored_ids.append((effective, row["id"]))

        # Sort ascending by effective importance — lowest first
        scored_ids.sort(key=lambda x: x[0])
        ids_to_remove = [sid for _, sid in scored_ids[:to_remove]]

        removed = 0
        with self._lock:
            for nid in ids_to_remove:
                self._conn.execute(
                    "DELETE FROM memory_nodes WHERE id = ?", (nid,)
                )
                removed += 1
            self._conn.commit()

        logger.debug("memory_pruned", removed=removed, remaining=count - removed)
        return removed

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_dot(self) -> str:
        """Export the graph in DOT format for Graphviz visualization.

        Returns:
            A string containing the complete DOT graph definition.
        """
        lines: list[str] = ["digraph MemoryGraph {"]
        lines.append('    rankdir=LR;')
        lines.append('    node [shape=box, style=filled];')

        # Color mapping for node types
        colors = {
            "fact": "#AED6F1",
            "preference": "#A9DFBF",
            "entity": "#F9E79F",
            "event": "#F5B7B1",
            "concept": "#D7BDE2",
        }

        nodes = self._conn.execute("SELECT * FROM memory_nodes").fetchall()
        for row in nodes:
            node = self._row_to_node(row)
            color = colors.get(node.node_type, "#D5D8DC")
            # Escape quotes in content for DOT label
            label = node.content[:60].replace('"', '\\"').replace("\n", " ")
            lines.append(
                f'    "{node.id}" '
                f'[label="{label}\\n({node.node_type}, imp={node.importance_score:.2f})", '
                f'fillcolor="{color}"];'
            )

        edges = self._conn.execute("SELECT * FROM memory_edges").fetchall()
        for row in edges:
            edge = MemoryEdge(
                source_id=row["source_id"],
                target_id=row["target_id"],
                relationship=row["relationship"],
                weight=row["weight"],
                timestamp=row["timestamp"],
            )
            lines.append(
                f'    "{edge.source_id}" -> "{edge.target_id}" '
                f'[label="{edge.relationship}\\nw={edge.weight:.2f}"];'
            )

        lines.append("}")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def stats(self) -> GraphStats:
        """Compute aggregate statistics about the memory graph.

        Returns:
            A GraphStats instance with counts, averages, and timestamps.
        """
        node_count = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM memory_nodes"
        ).fetchone()["cnt"]

        edge_count = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM memory_edges"
        ).fetchone()["cnt"]

        avg_row = self._conn.execute(
            "SELECT AVG(importance_score) as avg_imp FROM memory_nodes"
        ).fetchone()
        avg_importance = avg_row["avg_imp"] if avg_row["avg_imp"] is not None else 0.0

        type_rows = self._conn.execute(
            "SELECT node_type, COUNT(*) as cnt FROM memory_nodes GROUP BY node_type"
        ).fetchall()
        node_type_counts = {row["node_type"]: row["cnt"] for row in type_rows}

        rel_rows = self._conn.execute(
            "SELECT relationship, COUNT(*) as cnt FROM memory_edges GROUP BY relationship"
        ).fetchall()
        relationship_counts = {row["relationship"]: row["cnt"] for row in rel_rows}

        time_row = self._conn.execute(
            "SELECT MIN(timestamp) as oldest, MAX(timestamp) as newest FROM memory_nodes"
        ).fetchone()
        oldest = time_row["oldest"]
        newest = time_row["newest"]

        return GraphStats(
            node_count=node_count,
            edge_count=edge_count,
            avg_importance=round(avg_importance, 4),
            node_type_counts=node_type_counts,
            relationship_counts=relationship_counts,
            oldest_memory=oldest,
            newest_memory=newest,
        )

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_node(row: sqlite3.Row) -> MemoryNode:
        """Convert a sqlite3.Row to a MemoryNode.

        Args:
            row: A row from the memory_nodes table.

        Returns:
            A MemoryNode instance.
        """
        return MemoryNode(
            id=row["id"],
            content=row["content"],
            node_type=row["node_type"],
            timestamp=row["timestamp"],
            importance_score=row["importance_score"],
            access_count=row["access_count"],
            embedding_hash=row["embedding_hash"],
        )


# ---------------------------------------------------------------------------
# ConversationTracker
# ---------------------------------------------------------------------------

# Heuristic patterns for extracting memorizable content
_PREFERENCE_PATTERNS = [
    re.compile(r"\bi\s+(?:prefer|like|want|love|enjoy|favor)\s+(.+?)(?:\.|$)", re.IGNORECASE),
    re.compile(r"\bmy\s+(?:preference|favorite|choice)\s+(?:is|are)\s+(.+?)(?:\.|$)", re.IGNORECASE),
    re.compile(r"\bplease\s+(?:use|always|remember)\s+(.+?)(?:\.|$)", re.IGNORECASE),
]

_FACT_PATTERNS = [
    re.compile(r"\b(?:we|our\s+team)\s+(?:use|are using|run|deploy)\s+(.+?)(?:\.|$)", re.IGNORECASE),
    re.compile(r"\bthe\s+(?:project|codebase|system|app|application)\s+(?:is|uses|runs)\s+(.+?)(?:\.|$)", re.IGNORECASE),
    re.compile(r"\b(?:it|this)\s+(?:is|was|requires|needs)\s+(.+?)(?:\.|$)", re.IGNORECASE),
]

_ENTITY_PATTERN = re.compile(
    r"\b(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b"  # Capitalized multi-word names
)

_EVENT_PATTERNS = [
    re.compile(r"\b(?:yesterday|today|tomorrow|last\s+\w+|next\s+\w+)\b.*?(?:\.|$)", re.IGNORECASE),
    re.compile(r"\b(?:just|recently|earlier)\s+(.+?)(?:\.|$)", re.IGNORECASE),
]


class ConversationTracker:
    """Automatically extracts and stores memorizable content from conversations.

    Uses regex-based heuristics to identify facts, preferences, entities,
    and events from conversation turns.  Extracted items are stored in a
    MemoryGraph and cross-referenced via entity co-occurrence edges.

    Args:
        graph: The MemoryGraph instance to store memories in.
        min_content_length: Minimum extracted text length to store.
    """

    def __init__(
        self,
        graph: MemoryGraph,
        min_content_length: int = 10,
    ) -> None:
        self._graph = graph
        self._min_length = min_content_length
        self._turn_count = 0
        self._recent_entity_ids: list[str] = []

    @property
    def turn_count(self) -> int:
        """Number of conversation turns processed."""
        return self._turn_count

    def process_turn(self, role: str, content: str) -> list[str]:
        """Process a single conversation turn and extract memories.

        Scans the turn content for preferences, facts, entities, and events
        using regex heuristics.  Extracted items are stored as nodes in the
        graph.  Entities mentioned together in the same turn are connected
        with ``related_to`` edges.

        Args:
            role: The speaker role (e.g., ``"user"``, ``"assistant"``).
            content: The text content of the turn.

        Returns:
            List of node IDs for newly created memories.
        """
        if not content or not content.strip():
            return []

        self._turn_count += 1
        created_ids: list[str] = []

        # Extract preferences (user turns only)
        if role == "user":
            for pattern in _PREFERENCE_PATTERNS:
                for match in pattern.finditer(content):
                    text = match.group(1).strip()
                    if len(text) >= self._min_length:
                        nid = self._graph.add_memory(text, "preference", importance=0.7)
                        created_ids.append(nid)

        # Extract facts
        for pattern in _FACT_PATTERNS:
            for match in pattern.finditer(content):
                text = match.group(1).strip()
                if len(text) >= self._min_length:
                    nid = self._graph.add_memory(text, "fact", importance=0.6)
                    created_ids.append(nid)

        # Extract named entities (capitalized multi-word sequences)
        entity_ids_this_turn: list[str] = []
        seen_entities: set[str] = set()
        for match in _ENTITY_PATTERN.finditer(content):
            entity_name = match.group(0).strip()
            if entity_name in seen_entities:
                continue
            if len(entity_name) < self._min_length:
                continue
            seen_entities.add(entity_name)
            nid = self._graph.add_memory(entity_name, "entity", importance=0.5)
            created_ids.append(nid)
            entity_ids_this_turn.append(nid)

        # Extract events
        for pattern in _EVENT_PATTERNS:
            for match in pattern.finditer(content):
                text = match.group(0).strip()
                if len(text) >= self._min_length:
                    nid = self._graph.add_memory(text, "event", importance=0.4)
                    created_ids.append(nid)

        # Connect entities mentioned together in this turn
        for i, eid_a in enumerate(entity_ids_this_turn):
            for eid_b in entity_ids_this_turn[i + 1 :]:
                self._graph.connect(eid_a, eid_b, "related_to", weight=0.6)

        # Connect current-turn entities to previous-turn entities
        for prev_id in self._recent_entity_ids:
            if self._graph.get_node(prev_id) is None:
                continue
            for curr_id in entity_ids_this_turn:
                self._graph.connect(prev_id, curr_id, "references", weight=0.4)

        self._recent_entity_ids = entity_ids_this_turn

        logger.debug(
            "conversation_turn_processed",
            role=role,
            turn=self._turn_count,
            extracted=len(created_ids),
        )
        return created_ids

    def get_conversation_context(
        self, query: str, budget_tokens: int = 1500
    ) -> str:
        """Get relevant memories formatted for the current query.

        Delegates to :meth:`MemoryGraph.get_context_memories`.

        Args:
            query: The current user query.
            budget_tokens: Token budget for the context block.

        Returns:
            Formatted context string.
        """
        return self._graph.get_context_memories(query, budget_tokens=budget_tokens)
