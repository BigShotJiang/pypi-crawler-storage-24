"""Prism CLI interface."""
