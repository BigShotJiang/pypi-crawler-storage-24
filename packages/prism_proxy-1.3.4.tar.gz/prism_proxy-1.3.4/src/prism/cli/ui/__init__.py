"""Prism CLI UI — minimal for proxy mode."""

from __future__ import annotations

__all__: list[str] = []
