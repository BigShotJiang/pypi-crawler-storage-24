"""Conversation, session, and report exporters for Prism.

Provides three main classes:
- ``ConversationExporter`` — serialize a message list to JSON / Markdown / HTML / plain text.
- ``SessionExporter`` — export full sessions with cost data and model selections.
- ``ReportGenerator`` — produce cost / usage / quality-trend reports as Markdown tables.
"""

from __future__ import annotations

import html as html_mod
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Message:
    """A single conversation message."""

    role: str
    content: str
    timestamp: str = ""
    model: str = ""
    tokens: int = 0
    cost: float = 0.0


@dataclass(frozen=True)
class ExportMetadata:
    """Metadata attached to a conversation export."""

    session_id: str = ""
    model_used: str = ""
    total_cost: float = 0.0
    timestamp: str = ""
    files_referenced: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class SessionData:
    """Full session data for export."""

    session_id: str
    messages: list[Message] = field(default_factory=list)
    model_selections: list[dict[str, Any]] = field(default_factory=list)
    total_cost: float = 0.0
    total_tokens: int = 0
    start_time: str = ""
    end_time: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CostEntry:
    """A single cost record for report generation."""

    date: str
    model: str
    requests: int = 0
    tokens: int = 0
    cost: float = 0.0


@dataclass(frozen=True)
class QualityEntry:
    """A single quality observation for trend reports."""

    date: str
    model: str
    success_rate: float = 0.0
    avg_latency_ms: float = 0.0
    error_count: int = 0


# ---------------------------------------------------------------------------
# ConversationExporter
# ---------------------------------------------------------------------------

class ConversationExporter:
    """Export a conversation (list of messages) in multiple formats.

    Supported formats:
    - JSON (pretty-printed)
    - Markdown (headers, code blocks, model info)
    - HTML (styled with syntax highlighting)
    - Plain text (role prefixes)
    """

    # -- JSON ---------------------------------------------------------------

    @staticmethod
    def to_json(messages: list[Message], metadata: ExportMetadata | None = None) -> str:
        """Serialize messages and metadata to pretty-printed JSON.

        Args:
            messages: Ordered conversation messages.
            metadata: Optional export metadata.

        Returns:
            A JSON string.
        """
        payload: dict[str, Any] = {}
        if metadata is not None:
            payload["metadata"] = asdict(metadata)
        payload["messages"] = [asdict(m) for m in messages]
        return json.dumps(payload, indent=2, ensure_ascii=False)

    # -- Markdown -----------------------------------------------------------

    @staticmethod
    def to_markdown(messages: list[Message], metadata: ExportMetadata | None = None) -> str:
        """Render conversation as Markdown.

        Args:
            messages: Ordered conversation messages.
            metadata: Optional export metadata.

        Returns:
            A Markdown-formatted string.
        """
        parts: list[str] = ["# Conversation Export", ""]

        if metadata is not None:
            parts.append("## Metadata")
            parts.append("")
            if metadata.session_id:
                parts.append(f"- **Session ID:** {metadata.session_id}")
            if metadata.model_used:
                parts.append(f"- **Model:** {metadata.model_used}")
            if metadata.total_cost > 0:
                parts.append(f"- **Total Cost:** ${metadata.total_cost:.6f}")
            if metadata.timestamp:
                parts.append(f"- **Timestamp:** {metadata.timestamp}")
            if metadata.files_referenced:
                files_str = ", ".join(f"`{fp}`" for fp in metadata.files_referenced)
                parts.append(f"- **Files Referenced:** {files_str}")
            parts.append("")

        parts.append("## Messages")
        parts.append("")

        for msg in messages:
            role_label = msg.role.capitalize()
            parts.append(f"### {role_label}")
            if msg.model:
                parts.append(f"*Model: {msg.model}*")
            if msg.timestamp:
                parts.append(f"*{msg.timestamp}*")
            parts.append("")
            parts.append(_wrap_code_blocks(msg.content))
            parts.append("")
            parts.append("---")
            parts.append("")

        return "\n".join(parts)

    # -- HTML ---------------------------------------------------------------

    @staticmethod
    def to_html(messages: list[Message], metadata: ExportMetadata | None = None) -> str:
        """Render conversation as styled HTML with basic syntax highlighting.

        Args:
            messages: Ordered conversation messages.
            metadata: Optional export metadata.

        Returns:
            An HTML document string.
        """
        body_parts: list[str] = []

        if metadata is not None:
            body_parts.append("<div class='metadata'>")
            body_parts.append("<h2>Metadata</h2>")
            body_parts.append("<ul>")
            if metadata.session_id:
                body_parts.append(
                    f"<li><strong>Session ID:</strong> "
                    f"{html_mod.escape(metadata.session_id)}</li>"
                )
            if metadata.model_used:
                body_parts.append(
                    f"<li><strong>Model:</strong> "
                    f"{html_mod.escape(metadata.model_used)}</li>"
                )
            if metadata.total_cost > 0:
                body_parts.append(
                    f"<li><strong>Total Cost:</strong> ${metadata.total_cost:.6f}</li>"
                )
            if metadata.timestamp:
                body_parts.append(
                    f"<li><strong>Timestamp:</strong> "
                    f"{html_mod.escape(metadata.timestamp)}</li>"
                )
            if metadata.files_referenced:
                escaped = ", ".join(
                    f"<code>{html_mod.escape(fp)}</code>" for fp in metadata.files_referenced
                )
                body_parts.append(
                    f"<li><strong>Files Referenced:</strong> {escaped}</li>"
                )
            body_parts.append("</ul>")
            body_parts.append("</div>")

        for msg in messages:
            role_class = html_mod.escape(msg.role)
            body_parts.append(f"<div class='message {role_class}'>")
            body_parts.append(f"<h3>{html_mod.escape(msg.role.capitalize())}</h3>")
            if msg.model:
                body_parts.append(f"<span class='model'>Model: {html_mod.escape(msg.model)}</span>")
            content_html = _content_to_html(msg.content)
            body_parts.append(f"<div class='content'>{content_html}</div>")
            body_parts.append("</div>")

        body = "\n".join(body_parts)
        return _html_template(body)

    # -- Plain text ---------------------------------------------------------

    @staticmethod
    def to_text(messages: list[Message], metadata: ExportMetadata | None = None) -> str:
        """Render conversation as plain text with role prefixes.

        Args:
            messages: Ordered conversation messages.
            metadata: Optional export metadata.

        Returns:
            A plain-text string.
        """
        lines: list[str] = []

        if metadata is not None:
            lines.append("=== Conversation Export ===")
            if metadata.session_id:
                lines.append(f"Session: {metadata.session_id}")
            if metadata.model_used:
                lines.append(f"Model: {metadata.model_used}")
            if metadata.total_cost > 0:
                lines.append(f"Cost: ${metadata.total_cost:.6f}")
            if metadata.timestamp:
                lines.append(f"Time: {metadata.timestamp}")
            if metadata.files_referenced:
                lines.append(f"Files: {', '.join(metadata.files_referenced)}")
            lines.append("")

        for msg in messages:
            prefix = msg.role.upper()
            lines.append(f"[{prefix}]")
            lines.append(msg.content)
            lines.append("")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# SessionExporter
# ---------------------------------------------------------------------------

class SessionExporter:
    """Export full sessions including cost data and model selections."""

    @staticmethod
    def export_full(session: SessionData) -> dict[str, Any]:
        """Export a complete session as a dictionary.

        Args:
            session: The session data to export.

        Returns:
            A dictionary representation of the full session.
        """
        return {
            "session_id": session.session_id,
            "start_time": session.start_time,
            "end_time": session.end_time,
            "total_cost": session.total_cost,
            "total_tokens": session.total_tokens,
            "model_selections": session.model_selections,
            "messages": [asdict(m) for m in session.messages],
            "metadata": session.metadata,
        }

    @staticmethod
    def export_summary(session: SessionData) -> dict[str, Any]:
        """Export session statistics only (no message content).

        Args:
            session: The session data to summarize.

        Returns:
            A dictionary with summary statistics.
        """
        model_counts: dict[str, int] = {}
        for sel in session.model_selections:
            model = sel.get("model", "unknown")
            model_counts[model] = model_counts.get(model, 0) + 1

        role_counts: dict[str, int] = {}
        for msg in session.messages:
            role_counts[msg.role] = role_counts.get(msg.role, 0) + 1

        return {
            "session_id": session.session_id,
            "start_time": session.start_time,
            "end_time": session.end_time,
            "total_cost": session.total_cost,
            "total_tokens": session.total_tokens,
            "message_count": len(session.messages),
            "messages_by_role": role_counts,
            "models_used": model_counts,
        }

    @staticmethod
    def batch_export(sessions: list[SessionData]) -> list[dict[str, Any]]:
        """Export multiple sessions.

        Args:
            sessions: List of sessions to export.

        Returns:
            A list of full-export dictionaries, one per session.
        """
        return [SessionExporter.export_full(s) for s in sessions]


# ---------------------------------------------------------------------------
# ReportGenerator
# ---------------------------------------------------------------------------

class ReportGenerator:
    """Generate Markdown-table reports for cost, model usage, and quality trends."""

    @staticmethod
    def cost_report(
        entries: list[CostEntry],
        period: str = "daily",
    ) -> str:
        """Generate a cost report grouped by period.

        Args:
            entries: Cost records.
            period: One of ``"daily"``, ``"weekly"``, ``"monthly"``.

        Returns:
            A Markdown-formatted report string.
        """
        if not entries:
            return f"# Cost Report ({period.capitalize()})\n\nNo data available."

        grouped = _group_cost_entries(entries, period)

        lines: list[str] = [
            f"# Cost Report ({period.capitalize()})",
            "",
            "| Period | Requests | Tokens | Cost |",
            "|--------|----------|--------|------|",
        ]

        grand_requests = 0
        grand_tokens = 0
        grand_cost = 0.0

        for key in sorted(grouped):
            bucket = grouped[key]
            total_req = sum(e.requests for e in bucket)
            total_tok = sum(e.tokens for e in bucket)
            total_cost = sum(e.cost for e in bucket)
            grand_requests += total_req
            grand_tokens += total_tok
            grand_cost += total_cost
            lines.append(f"| {key} | {total_req} | {total_tok} | ${total_cost:.4f} |")

        lines.append(f"| **Total** | **{grand_requests}** | **{grand_tokens}** "
                      f"| **${grand_cost:.4f}** |")

        return "\n".join(lines)

    @staticmethod
    def model_usage_report(entries: list[CostEntry]) -> str:
        """Generate a model-usage report.

        Args:
            entries: Cost records.

        Returns:
            A Markdown-formatted report string.
        """
        if not entries:
            return "# Model Usage Report\n\nNo data available."

        by_model: dict[str, list[CostEntry]] = {}
        for e in entries:
            by_model.setdefault(e.model, []).append(e)

        lines: list[str] = [
            "# Model Usage Report",
            "",
            "| Model | Requests | Tokens | Cost | Avg Cost/Req |",
            "|-------|----------|--------|------|--------------|",
        ]

        for model in sorted(by_model):
            bucket = by_model[model]
            total_req = sum(e.requests for e in bucket)
            total_tok = sum(e.tokens for e in bucket)
            total_cost = sum(e.cost for e in bucket)
            avg = total_cost / total_req if total_req > 0 else 0.0
            lines.append(
                f"| {model} | {total_req} | {total_tok} | ${total_cost:.4f} | ${avg:.6f} |"
            )

        return "\n".join(lines)

    @staticmethod
    def quality_trend_report(entries: list[QualityEntry]) -> str:
        """Generate a quality-trend report.

        Args:
            entries: Quality observations.

        Returns:
            A Markdown-formatted report string.
        """
        if not entries:
            return "# Quality Trend Report\n\nNo data available."

        lines: list[str] = [
            "# Quality Trend Report",
            "",
            "| Date | Model | Success Rate | Avg Latency (ms) | Errors |",
            "|------|-------|-------------|-------------------|--------|",
        ]

        for entry in sorted(entries, key=lambda e: (e.date, e.model)):
            lines.append(
                f"| {entry.date} | {entry.model} | {entry.success_rate:.1%} "
                f"| {entry.avg_latency_ms:.0f} | {entry.error_count} |"
            )

        # Summary
        if entries:
            avg_success = sum(e.success_rate for e in entries) / len(entries)
            avg_latency = sum(e.avg_latency_ms for e in entries) / len(entries)
            total_errors = sum(e.error_count for e in entries)
            lines.append("")
            lines.append(f"**Overall:** {avg_success:.1%} success, "
                          f"{avg_latency:.0f}ms avg latency, {total_errors} total errors")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _wrap_code_blocks(text: str) -> str:
    """Ensure fenced code blocks survive Markdown rendering unchanged."""
    return text


def _content_to_html(content: str) -> str:
    """Convert message content to HTML, highlighting fenced code blocks."""
    escaped = html_mod.escape(content)
    # Replace fenced code blocks with <pre><code>
    pattern = r"```(\w*)\n(.*?)```"
    escaped = re.sub(
        pattern,
        lambda m: (
            f"<pre><code class='language-{html_mod.escape(m.group(1))}'>"
            f"{m.group(2)}</code></pre>"
        ),
        escaped,
        flags=re.DOTALL,
    )
    # Replace inline code
    escaped = re.sub(r"`([^`]+)`", r"<code>\1</code>", escaped)
    # Newlines to <br>
    escaped = escaped.replace("\n", "<br>\n")
    return escaped


def _html_template(body: str) -> str:
    """Wrap body content in a minimal HTML document with CSS."""
    return (
        "<!DOCTYPE html>\n"
        "<html lang='en'>\n"
        "<head>\n"
        "<meta charset='UTF-8'>\n"
        "<title>Prism Conversation Export</title>\n"
        "<style>\n"
        "body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, "
        "sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; "
        "background: #f8f9fa; }\n"
        ".message { margin: 16px 0; padding: 12px; border-radius: 8px; "
        "background: #fff; border: 1px solid #e0e0e0; }\n"
        ".message.user { border-left: 4px solid #2196F3; }\n"
        ".message.assistant { border-left: 4px solid #4CAF50; }\n"
        ".message.system { border-left: 4px solid #FF9800; }\n"
        ".model { font-size: 0.85em; color: #666; }\n"
        ".metadata { background: #e8f5e9; padding: 12px; border-radius: 8px; "
        "margin-bottom: 20px; }\n"
        "pre { background: #263238; color: #eeffff; padding: 12px; "
        "border-radius: 4px; overflow-x: auto; }\n"
        "code { font-family: 'Fira Code', monospace; }\n"
        "h3 { margin-top: 0; }\n"
        "</style>\n"
        "</head>\n"
        "<body>\n"
        "<h1>Prism Conversation Export</h1>\n"
        f"{body}\n"
        "</body>\n"
        "</html>"
    )


def _group_cost_entries(
    entries: list[CostEntry], period: str
) -> dict[str, list[CostEntry]]:
    """Group cost entries by the given period key.

    Args:
        entries: Cost records with ISO date strings.
        period: ``"daily"``, ``"weekly"``, or ``"monthly"``.

    Returns:
        Mapping from period key to entries in that period.
    """
    grouped: dict[str, list[CostEntry]] = {}
    for entry in entries:
        key = _period_key(entry.date, period)
        grouped.setdefault(key, []).append(entry)
    return grouped


def _period_key(date_str: str, period: str) -> str:
    """Derive a grouping key from a date string.

    Args:
        date_str: ISO-format date (YYYY-MM-DD or datetime).
        period: ``"daily"``, ``"weekly"``, or ``"monthly"``.

    Returns:
        The grouping key string.
    """
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return date_str

    if period == "monthly":
        return dt.strftime("%Y-%m")
    if period == "weekly":
        iso_year, iso_week, _ = dt.isocalendar()
        return f"{iso_year}-W{iso_week:02d}"
    # daily (default)
    return dt.strftime("%Y-%m-%d")
