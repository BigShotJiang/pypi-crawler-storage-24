"""Prism Prompt Template Engine.

Provides:

- :class:`PromptTemplate` — composable templates with variable interpolation.
- :class:`TemplateRegistry` — versioned template storage and lookup.
- :class:`PromptChain` — sequential template pipelines with branching.
- :class:`FewShotBuilder` — few-shot prompt construction with example selection.
- :func:`create_default_registry` — registry pre-loaded with built-in templates.
"""

from __future__ import annotations

from prism.prompts.templates import (
    ChainStep,
    ChainStepResult,
    Example,
    FewShotBuilder,
    PromptChain,
    PromptTemplate,
    SelectionStrategy,
    TemplateError,
    TemplateNotFoundError,
    TemplateRegistry,
    TemplateRenderError,
    TemplateValidationError,
    create_default_registry,
)

__all__ = [
    "ChainStep",
    "ChainStepResult",
    "Example",
    "FewShotBuilder",
    "PromptChain",
    "PromptTemplate",
    "SelectionStrategy",
    "TemplateError",
    "TemplateNotFoundError",
    "TemplateRegistry",
    "TemplateRenderError",
    "TemplateValidationError",
    "create_default_registry",
]
