"""Prompt Template Engine — composable, versioned prompt templates.

Provides:

- :class:`PromptTemplate` — variable interpolation, conditionals, composition.
- :class:`TemplateRegistry` — versioned template storage and lookup.
- :class:`PromptChain` — sequential template pipelines with branching.
- :class:`FewShotBuilder` — few-shot prompt construction with example selection.
"""

from __future__ import annotations

import hashlib
import math
import random
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from prism.exceptions import PrismError

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class TemplateError(PrismError):
    """Base exception for template operations."""


class TemplateRenderError(TemplateError):
    """Raised when a template cannot be rendered."""

    def __init__(self, template_name: str, reason: str) -> None:
        self.template_name = template_name
        self.reason = reason
        super().__init__(f"Failed to render template '{template_name}': {reason}")


class TemplateNotFoundError(TemplateError):
    """Raised when a referenced template does not exist."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Template not found: {name}")


class TemplateValidationError(TemplateError):
    """Raised when template variable validation fails."""

    def __init__(self, missing_vars: set[str], template_name: str = "") -> None:
        self.missing_vars = missing_vars
        self.template_name = template_name
        vars_str = ", ".join(sorted(missing_vars))
        name_part = f" in template '{template_name}'" if template_name else ""
        super().__init__(f"Missing required variables{name_part}: {vars_str}")


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# {variable} — simple variable interpolation
_VAR_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")

# {@template_name} — template composition
_INCLUDE_RE = re.compile(r"\{@([a-zA-Z_][a-zA-Z0-9_]*)\}")

# {?variable}content{/variable} — conditional blocks
_COND_RE = re.compile(
    r"\{\?([a-zA-Z_][a-zA-Z0-9_]*)\}(.*?)\{/\1\}",
    re.DOTALL,
)


# ---------------------------------------------------------------------------
# PromptTemplate
# ---------------------------------------------------------------------------


@dataclass
class PromptTemplate:
    """A named prompt template with variable interpolation and composition.

    Templates support three constructs:

    - ``{variable}`` — replaced with the variable value.
    - ``{@template_name}`` — replaced with another rendered template.
    - ``{?variable}...{/variable}`` — conditional block, included only when
      *variable* is present in the rendering context.

    Args:
        template: The template string with interpolation markers.
        name: A human-readable name for identification.
        description: Optional description of the template's purpose.
        version: Version string (semver recommended).
        defaults: Default values for template variables.
    """

    template: str
    name: str = ""
    description: str = ""
    version: str = "1.0.0"
    defaults: dict[str, str] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def variables(self) -> set[str]:
        """Return all variable names referenced in this template.

        This includes simple ``{var}`` references but excludes
        conditional block markers and include directives.
        """
        # Exclude variables that are only used in conditional/include markers
        all_vars = set(_VAR_RE.findall(self.template))
        includes = set(_INCLUDE_RE.findall(self.template))
        cond_vars = {m.group(1) for m in _COND_RE.finditer(self.template)}
        return all_vars - includes - cond_vars

    @property
    def required_variables(self) -> set[str]:
        """Return variables that have no default and are not conditional-only.

        A variable is *required* if it appears as ``{var}`` (not inside a
        conditional block or as an include) and has no default value.
        """
        # Variables in simple {var} positions (not in conditionals or includes)
        simple_vars = self.variables

        # Variables that appear ONLY inside conditional blocks are optional
        cond_only: set[str] = set()
        # Strip conditional blocks and see which vars remain
        stripped = _COND_RE.sub("", self.template)
        surviving = set(_VAR_RE.findall(stripped)) - set(_INCLUDE_RE.findall(stripped))
        for var in simple_vars:
            if var not in surviving:
                cond_only.add(var)

        required = simple_vars - cond_only - set(self.defaults.keys())
        return required

    @property
    def includes(self) -> set[str]:
        """Return all template names referenced via ``{@template_name}``."""
        return set(_INCLUDE_RE.findall(self.template))

    @property
    def conditional_variables(self) -> set[str]:
        """Return variables used in conditional blocks."""
        return {m.group(1) for m in _COND_RE.finditer(self.template)}

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(self, variables: dict[str, str]) -> list[str]:
        """Check that all required variables are provided.

        Args:
            variables: The variables to validate against.

        Returns:
            A list of error messages (empty if valid).
        """
        merged = {**self.defaults, **variables}
        missing = self.required_variables - set(merged.keys())
        errors: list[str] = []
        if missing:
            errors.append(
                f"Missing required variables: {', '.join(sorted(missing))}"
            )
        return errors

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def render(
        self,
        variables: dict[str, str] | None = None,
        *,
        registry: TemplateRegistry | None = None,
        _depth: int = 0,
    ) -> str:
        """Render the template with the given variables.

        Args:
            variables: Variable name-to-value mapping.
            registry: Optional registry for resolving ``{@include}`` directives.
            _depth: Internal recursion guard (max 20 levels).

        Returns:
            The fully rendered template string.

        Raises:
            TemplateRenderError: If rendering fails (missing vars, recursion, etc.).
            TemplateValidationError: If required variables are missing.
        """
        if _depth > 20:
            raise TemplateRenderError(
                self.name, "Maximum template inclusion depth (20) exceeded"
            )

        vars_merged = {**self.defaults, **(variables or {})}

        # Validate required variables
        missing = self.required_variables - set(vars_merged.keys())
        if missing:
            raise TemplateValidationError(missing, template_name=self.name)

        result = self.template

        # 1. Process conditional blocks
        def _replace_cond(match: re.Match[str]) -> str:
            var_name = match.group(1)
            content = match.group(2)
            if vars_merged.get(var_name):
                return content
            return ""

        result = _COND_RE.sub(_replace_cond, result)

        # 2. Process includes
        if registry is not None:
            def _replace_include(match: re.Match[str]) -> str:
                inc_name = match.group(1)
                try:
                    inc_template = registry.get(inc_name)
                except TemplateNotFoundError as exc:
                    raise TemplateRenderError(
                        self.name,
                        f"Included template '{inc_name}' not found in registry",
                    ) from exc
                return inc_template.render(
                    vars_merged, registry=registry, _depth=_depth + 1
                )

            result = _INCLUDE_RE.sub(_replace_include, result)
        else:
            # If no registry, remove include markers that can't be resolved
            remaining_includes = set(_INCLUDE_RE.findall(result))
            if remaining_includes:
                raise TemplateRenderError(
                    self.name,
                    f"Template includes {remaining_includes} but no registry provided",
                )

        # 3. Variable substitution
        def _replace_var(match: re.Match[str]) -> str:
            var_name = match.group(1)
            if var_name in vars_merged:
                return vars_merged[var_name]
            # Variable not provided and not required — leave empty
            return ""

        result = _VAR_RE.sub(_replace_var, result)

        return result


# ---------------------------------------------------------------------------
# TemplateRegistry
# ---------------------------------------------------------------------------


class TemplateRegistry:
    """Versioned registry for prompt templates.

    Supports storing multiple versions of the same template and retrieving
    the latest or a specific version.
    """

    def __init__(self) -> None:
        # Mapping: name -> list of (version_tuple, template) sorted ascending
        self._templates: dict[str, list[tuple[tuple[int, ...], PromptTemplate]]] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, template: PromptTemplate) -> None:
        """Register a template.

        If a template with the same name and version already exists it will be
        replaced.

        Args:
            template: The template to register.

        Raises:
            TemplateError: If the template has no name.
        """
        if not template.name:
            raise TemplateError("Cannot register a template without a name")

        version_tuple = self._parse_version(template.version)

        if template.name not in self._templates:
            self._templates[template.name] = []

        entries = self._templates[template.name]

        # Replace existing entry with same version
        for i, (ver, _) in enumerate(entries):
            if ver == version_tuple:
                entries[i] = (version_tuple, template)
                return

        entries.append((version_tuple, template))
        entries.sort(key=lambda x: x[0])

    def get(self, name: str, version: str | None = None) -> PromptTemplate:
        """Retrieve a template by name and optional version.

        Args:
            name: The template name.
            version: Specific version to retrieve.  If *None*, returns the
                latest (highest) version.

        Returns:
            The matching :class:`PromptTemplate`.

        Raises:
            TemplateNotFoundError: If no template matches.
        """
        if name not in self._templates or not self._templates[name]:
            raise TemplateNotFoundError(name)

        entries = self._templates[name]

        if version is None:
            # Return latest (last in sorted list)
            return entries[-1][1]

        version_tuple = self._parse_version(version)
        for ver, tmpl in entries:
            if ver == version_tuple:
                return tmpl

        raise TemplateNotFoundError(f"{name}@{version}")

    def list_templates(self) -> list[dict[str, str]]:
        """List all registered templates with their latest version.

        Returns:
            A list of dicts with keys ``name``, ``version``, ``description``.
        """
        result: list[dict[str, str]] = []
        for name in sorted(self._templates.keys()):
            entries = self._templates[name]
            if entries:
                latest = entries[-1][1]
                result.append({
                    "name": latest.name,
                    "version": latest.version,
                    "description": latest.description,
                })
        return result

    def list_versions(self, name: str) -> list[str]:
        """List all available versions for a template name.

        Args:
            name: The template name.

        Returns:
            A sorted list of version strings.

        Raises:
            TemplateNotFoundError: If the template name is not registered.
        """
        if name not in self._templates:
            raise TemplateNotFoundError(name)

        return [tmpl.version for _, tmpl in self._templates[name]]

    def has(self, name: str) -> bool:
        """Check whether a template with the given name exists."""
        return name in self._templates and len(self._templates[name]) > 0

    def remove(self, name: str, version: str | None = None) -> bool:
        """Remove a template (specific version or all versions).

        Args:
            name: The template name.
            version: Specific version to remove, or *None* to remove all.

        Returns:
            *True* if anything was removed.
        """
        if name not in self._templates:
            return False

        if version is None:
            del self._templates[name]
            return True

        version_tuple = self._parse_version(version)
        entries = self._templates[name]
        original_len = len(entries)
        self._templates[name] = [
            (ver, tmpl) for ver, tmpl in entries if ver != version_tuple
        ]
        if not self._templates[name]:
            del self._templates[name]
        return len(self._templates.get(name, [])) < original_len

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_version(version: str) -> tuple[int, ...]:
        """Parse a dotted version string into a comparable tuple.

        Non-numeric segments are hashed to an integer so that arbitrary
        version strings can still be compared deterministically.
        """
        parts: list[int] = []
        for segment in version.split("."):
            try:
                parts.append(int(segment))
            except ValueError:
                # Hash non-numeric segment for deterministic ordering
                parts.append(
                    int(hashlib.md5(  # noqa: S324
                        segment.encode()
                    ).hexdigest()[:8], 16)
                )
        return tuple(parts)


# ---------------------------------------------------------------------------
# Built-in templates
# ---------------------------------------------------------------------------


def _create_builtin_templates() -> list[PromptTemplate]:
    """Create the set of built-in prompt templates."""
    return [
        PromptTemplate(
            name="code_generation",
            description="Generate code from a natural-language specification.",
            version="1.0.0",
            template=(
                "You are an expert {language} developer.\n\n"
                "Generate code that fulfills the following requirement:\n\n"
                "{requirement}\n\n"
                "{?context}Additional context:\n{context}\n\n{/context}"
                "{?constraints}Constraints:\n{constraints}\n\n{/constraints}"
                "Provide only the code with brief inline comments."
            ),
            defaults={"language": "Python"},
        ),
        PromptTemplate(
            name="code_review",
            description="Review code for quality, bugs, and improvements.",
            version="1.0.0",
            template=(
                "You are a senior software engineer performing a code review.\n\n"
                "Review the following {language} code:\n\n"
                "```{language}\n{code}\n```\n\n"
                "{?focus}Focus on: {focus}\n\n{/focus}"
                "Provide feedback on:\n"
                "1. Correctness and potential bugs\n"
                "2. Performance considerations\n"
                "3. Code style and readability\n"
                "4. Security concerns\n"
                "5. Suggested improvements"
            ),
            defaults={"language": "Python"},
        ),
        PromptTemplate(
            name="explain_code",
            description="Explain what a piece of code does.",
            version="1.0.0",
            template=(
                "Explain the following {language} code in detail.\n\n"
                "```{language}\n{code}\n```\n\n"
                "{?audience}Explain for an audience of: {audience}\n\n{/audience}"
                "{?focus}Focus on: {focus}\n\n{/focus}"
                "Break down the logic step by step."
            ),
            defaults={"language": "Python"},
        ),
        PromptTemplate(
            name="fix_bug",
            description="Diagnose and fix a bug in code.",
            version="1.0.0",
            template=(
                "You are a debugging expert.\n\n"
                "The following {language} code has a bug:\n\n"
                "```{language}\n{code}\n```\n\n"
                "Error or symptom: {error}\n\n"
                "{?expected}Expected behavior: {expected}\n\n{/expected}"
                "{?stack_trace}Stack trace:\n```\n{stack_trace}\n```\n\n{/stack_trace}"
                "Diagnose the root cause and provide the fixed code."
            ),
            defaults={"language": "Python"},
        ),
        PromptTemplate(
            name="refactor",
            description="Refactor code for better structure or performance.",
            version="1.0.0",
            template=(
                "You are a refactoring expert.\n\n"
                "Refactor the following {language} code:\n\n"
                "```{language}\n{code}\n```\n\n"
                "{?goal}Refactoring goal: {goal}\n\n{/goal}"
                "{?constraints}Constraints: {constraints}\n\n{/constraints}"
                "Maintain the same external behavior while improving the "
                "internal structure."
            ),
            defaults={"language": "Python"},
        ),
        PromptTemplate(
            name="test_generation",
            description="Generate tests for a piece of code.",
            version="1.0.0",
            template=(
                "You are a testing expert.\n\n"
                "Generate comprehensive tests for the following {language} code:\n\n"
                "```{language}\n{code}\n```\n\n"
                "{?framework}Use the {framework} testing framework.\n\n{/framework}"
                "{?coverage}Cover these scenarios: {coverage}\n\n{/coverage}"
                "Include edge cases and both positive and negative tests."
            ),
            defaults={"language": "Python", "framework": "pytest"},
        ),
        PromptTemplate(
            name="summarize",
            description="Summarize text or code.",
            version="1.0.0",
            template=(
                "Summarize the following content:\n\n"
                "{content}\n\n"
                "{?length}Target length: {length}\n\n{/length}"
                "{?format}Output format: {format}\n\n{/format}"
                "{?audience}Target audience: {audience}\n\n{/audience}"
                "Provide a clear, concise summary."
            ),
        ),
        PromptTemplate(
            name="translate",
            description="Translate code between programming languages.",
            version="1.0.0",
            template=(
                "Translate the following code from {source_language} to "
                "{target_language}:\n\n"
                "```{source_language}\n{code}\n```\n\n"
                "{?idioms}Use idiomatic {target_language} patterns.\n\n{/idioms}"
                "{?preserve_comments}Preserve and translate all comments.\n\n"
                "{/preserve_comments}"
                "Ensure the translated code is functionally equivalent."
            ),
        ),
    ]


def create_default_registry() -> TemplateRegistry:
    """Create a :class:`TemplateRegistry` pre-loaded with built-in templates.

    Returns:
        A registry containing all built-in templates.
    """
    registry = TemplateRegistry()
    for tmpl in _create_builtin_templates():
        registry.register(tmpl)
    return registry


# ---------------------------------------------------------------------------
# PromptChain
# ---------------------------------------------------------------------------


class ChainStepResult:
    """Result of executing a single chain step.

    Attributes:
        step_name: Identifier for the step.
        output: The rendered template output.
        variables: The variables used for rendering.
    """

    __slots__ = ("output", "step_name", "variables")

    def __init__(
        self,
        step_name: str,
        output: str,
        variables: dict[str, str],
    ) -> None:
        self.step_name = step_name
        self.output = output
        self.variables = dict(variables)

    def __repr__(self) -> str:
        return f"ChainStepResult(step_name={self.step_name!r}, output_len={len(self.output)})"


@dataclass
class ChainStep:
    """A single step in a prompt chain.

    Args:
        template: The template to render.
        name: Step identifier.
        output_key: Variable name under which this step's output is stored
            for subsequent steps.
        condition: Optional callable that receives the accumulated variables
            dict and returns *True* if this step should execute.
    """

    template: PromptTemplate
    name: str = ""
    output_key: str = "previous_output"
    condition: Callable[[dict[str, str]], bool] | None = None


class PromptChain:
    """Execute a sequence of template renders, piping outputs forward.

    Each step receives all accumulated variables (including outputs from
    previous steps).  Steps can be conditionally skipped via a predicate
    function.

    Example::

        chain = PromptChain()
        chain.add_step(analysis_template, output_key="analysis")
        chain.add_step(
            fix_template,
            output_key="fix",
            condition=lambda v: "error" in v.get("analysis", "").lower(),
        )
        results = chain.execute({"code": source_code})
    """

    def __init__(self, *, registry: TemplateRegistry | None = None) -> None:
        self._steps: list[ChainStep] = []
        self._registry = registry

    @property
    def steps(self) -> list[ChainStep]:
        """Return a copy of the chain steps."""
        return list(self._steps)

    def add_step(
        self,
        template: PromptTemplate,
        *,
        name: str = "",
        output_key: str = "previous_output",
        condition: Callable[[dict[str, str]], bool] | None = None,
    ) -> PromptChain:
        """Append a step to the chain.

        Args:
            template: The template for this step.
            name: Human-readable step name (defaults to template name).
            output_key: Key under which the rendered output is stored.
            condition: Optional predicate; step is skipped when it returns
                *False*.

        Returns:
            *self* for fluent chaining.
        """
        step_name = name or template.name or f"step_{len(self._steps)}"
        self._steps.append(
            ChainStep(
                template=template,
                name=step_name,
                output_key=output_key,
                condition=condition,
            )
        )
        return self

    def execute(
        self,
        variables: dict[str, str] | None = None,
    ) -> list[ChainStepResult]:
        """Execute all steps in sequence.

        Args:
            variables: Initial variable context.

        Returns:
            A list of :class:`ChainStepResult` for every step that executed
            (skipped steps are omitted).

        Raises:
            TemplateRenderError: If any step fails to render.
        """
        accumulated: dict[str, str] = dict(variables or {})
        results: list[ChainStepResult] = []

        for step in self._steps:
            # Evaluate condition
            if step.condition is not None and not step.condition(accumulated):
                continue

            output = step.template.render(
                accumulated,
                registry=self._registry,
            )
            accumulated[step.output_key] = output

            results.append(
                ChainStepResult(
                    step_name=step.name,
                    output=output,
                    variables=dict(accumulated),
                )
            )

        return results


# ---------------------------------------------------------------------------
# FewShotBuilder
# ---------------------------------------------------------------------------


class SelectionStrategy(Enum):
    """Strategy for selecting examples in few-shot prompts."""

    RANDOM = "random"
    SIMILARITY = "similarity"
    DIVERSE = "diverse"


@dataclass
class Example:
    """A single few-shot example.

    Attributes:
        input_text: The example input/question.
        output_text: The expected output/answer.
        metadata: Optional metadata for similarity/filtering.
    """

    input_text: str
    output_text: str
    metadata: dict[str, Any] = field(default_factory=dict)


class FewShotBuilder:
    """Build few-shot prompts from a pool of examples.

    Supports three selection strategies:

    - **random** — uniformly random selection.
    - **similarity** — pick examples most similar to the query (cosine
      similarity on character trigram vectors).
    - **diverse** — pick examples that maximise pairwise dissimilarity.

    Args:
        examples: Initial pool of examples.
        num_examples: Default number of examples to include.
        strategy: Default selection strategy.
        example_format: A :class:`PromptTemplate` controlling how each example
            is rendered.  Must accept ``{input}`` and ``{output}`` variables.
    """

    _DEFAULT_FORMAT = PromptTemplate(
        name="_few_shot_example",
        template="Input: {input}\nOutput: {output}",
    )

    def __init__(
        self,
        examples: Sequence[Example] | None = None,
        *,
        num_examples: int = 3,
        strategy: SelectionStrategy = SelectionStrategy.RANDOM,
        example_format: PromptTemplate | None = None,
    ) -> None:
        self._examples: list[Example] = list(examples or [])
        self._num_examples = max(1, num_examples)
        self._strategy = strategy
        self._example_format = example_format or self._DEFAULT_FORMAT

    # ------------------------------------------------------------------
    # Pool management
    # ------------------------------------------------------------------

    def add_example(self, example: Example) -> FewShotBuilder:
        """Add an example to the pool.

        Returns:
            *self* for fluent chaining.
        """
        self._examples.append(example)
        return self

    def add_examples(self, examples: Sequence[Example]) -> FewShotBuilder:
        """Add multiple examples to the pool.

        Returns:
            *self* for fluent chaining.
        """
        self._examples.extend(examples)
        return self

    @property
    def pool_size(self) -> int:
        """Number of examples in the pool."""
        return len(self._examples)

    # ------------------------------------------------------------------
    # Selection
    # ------------------------------------------------------------------

    def select(
        self,
        query: str = "",
        *,
        num_examples: int | None = None,
        strategy: SelectionStrategy | None = None,
    ) -> list[Example]:
        """Select examples from the pool.

        Args:
            query: Reference text for similarity-based selection.
            num_examples: Override the default count.
            strategy: Override the default strategy.

        Returns:
            A list of selected examples.
        """
        n = num_examples if num_examples is not None else self._num_examples
        strat = strategy or self._strategy

        if not self._examples:
            return []

        n = min(n, len(self._examples))

        if strat == SelectionStrategy.RANDOM:
            return self._select_random(n)
        if strat == SelectionStrategy.SIMILARITY:
            return self._select_similarity(query, n)
        if strat == SelectionStrategy.DIVERSE:
            return self._select_diverse(n)

        return self._select_random(n)  # pragma: no cover — defensive fallback

    def _select_random(self, n: int) -> list[Example]:
        """Uniformly random selection without replacement."""
        return random.sample(self._examples, n)

    def _select_similarity(self, query: str, n: int) -> list[Example]:
        """Select examples most similar to *query* via trigram cosine similarity."""
        if not query:
            return self._select_random(n)

        query_vec = self._trigram_vector(query)
        scored: list[tuple[float, int, Example]] = []

        for idx, ex in enumerate(self._examples):
            ex_vec = self._trigram_vector(ex.input_text)
            sim = self._cosine_similarity(query_vec, ex_vec)
            scored.append((sim, idx, ex))

        scored.sort(key=lambda x: (-x[0], x[1]))
        return [ex for _, _, ex in scored[:n]]

    def _select_diverse(self, n: int) -> list[Example]:
        """Greedy maximal-marginal-relevance selection for diversity."""
        if n >= len(self._examples):
            return list(self._examples)

        vectors = [self._trigram_vector(ex.input_text) for ex in self._examples]
        selected_indices: list[int] = []
        remaining = set(range(len(self._examples)))

        # Seed with the first example (deterministic)
        first_idx = 0
        selected_indices.append(first_idx)
        remaining.discard(first_idx)

        while len(selected_indices) < n and remaining:
            best_idx = -1
            best_min_sim = float("inf")

            for cand in remaining:
                # Minimum similarity to any already-selected example
                min_sim = min(
                    self._cosine_similarity(vectors[cand], vectors[sel])
                    for sel in selected_indices
                )
                if min_sim < best_min_sim:
                    best_min_sim = min_sim
                    best_idx = cand

            if best_idx < 0:
                break  # pragma: no cover

            selected_indices.append(best_idx)
            remaining.discard(best_idx)

        return [self._examples[i] for i in selected_indices]

    # ------------------------------------------------------------------
    # Building
    # ------------------------------------------------------------------

    def build(
        self,
        *,
        instruction: str = "",
        query: str = "",
        num_examples: int | None = None,
        strategy: SelectionStrategy | None = None,
        separator: str = "\n\n",
    ) -> str:
        """Build a complete few-shot prompt.

        Args:
            instruction: System/instruction text placed before examples.
            query: The actual user query (also used for similarity selection).
            num_examples: Override default example count.
            strategy: Override default selection strategy.
            separator: String between examples.

        Returns:
            The assembled few-shot prompt.
        """
        selected = self.select(
            query,
            num_examples=num_examples,
            strategy=strategy,
        )

        parts: list[str] = []

        if instruction:
            parts.append(instruction)

        if selected:
            rendered_examples: list[str] = []
            for ex in selected:
                rendered = self._example_format.render({
                    "input": ex.input_text,
                    "output": ex.output_text,
                })
                rendered_examples.append(rendered)
            parts.append(separator.join(rendered_examples))

        if query:
            # Add the query using the same format but without the output
            parts.append(f"Input: {query}\nOutput:")

        return separator.join(parts)

    # ------------------------------------------------------------------
    # Vector helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _trigram_vector(text: str) -> dict[str, float]:
        """Build a character trigram frequency vector."""
        text = text.lower().strip()
        if len(text) < 3:
            return {text: 1.0} if text else {}

        trigrams: dict[str, float] = {}
        for i in range(len(text) - 2):
            tri = text[i : i + 3]
            trigrams[tri] = trigrams.get(tri, 0.0) + 1.0
        return trigrams

    @staticmethod
    def _cosine_similarity(
        vec_a: dict[str, float],
        vec_b: dict[str, float],
    ) -> float:
        """Compute cosine similarity between two sparse vectors."""
        if not vec_a or not vec_b:
            return 0.0

        dot = 0.0
        for key, val_a in vec_a.items():
            if key in vec_b:
                dot += val_a * vec_b[key]

        norm_a = math.sqrt(sum(v * v for v in vec_a.values()))
        norm_b = math.sqrt(sum(v * v for v in vec_b.values()))

        if norm_a == 0.0 or norm_b == 0.0:
            return 0.0

        return dot / (norm_a * norm_b)
