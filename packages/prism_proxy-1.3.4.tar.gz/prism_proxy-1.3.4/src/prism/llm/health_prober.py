"""Background provider health prober — detect failures before routing.

Runs periodic async health checks against all configured providers.
When a provider is detected as down, the router avoids it *before*
a user request fails, eliminating the latency penalty of failed
attempts and retries.

Features:
    1. Parallel health probes every 60 seconds (configurable).
    2. Lightweight probe: sends a minimal completion request
       (1 token max_tokens) to verify the API key and endpoint work.
    3. Records probe latency for latency-aware routing.
    4. Exponential backoff for providers that are repeatedly down.
    5. Health status exposed to the model selector.

Usage::

    prober = HealthProber(engine, registry, tracker)
    await prober.start()   # Starts background probing
    ...
    await prober.stop()
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from dataclasses import dataclass
from enum import Enum

import structlog

logger = structlog.get_logger(__name__)


class ProviderHealth(Enum):
    """Health status of a provider."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"  # Slow but functional
    DOWN = "down"  # Not responding
    UNKNOWN = "unknown"  # Not yet probed


@dataclass
class HealthReport:
    """Health report for a single provider.

    Attributes:
        provider: Provider name.
        status: Current health status.
        latency_ms: Last probe latency (0 if down).
        last_check: Monotonic timestamp of last check.
        consecutive_failures: How many probes have failed in a row.
        error_message: Last error message (empty if healthy).
    """

    provider: str
    status: ProviderHealth = ProviderHealth.UNKNOWN
    latency_ms: float = 0.0
    last_check: float = 0.0
    consecutive_failures: int = 0
    error_message: str = ""


class HealthProber:
    """Background health prober for all configured providers.

    Args:
        probe_interval: Seconds between probe cycles.
        probe_timeout: Timeout for each individual probe.
        degraded_threshold_ms: Latency above this → DEGRADED.
        max_backoff: Maximum seconds between probes for a failing provider.
    """

    def __init__(
        self,
        probe_interval: float = 60.0,
        probe_timeout: float = 10.0,
        degraded_threshold_ms: float = 5000.0,
        max_backoff: float = 300.0,
    ) -> None:
        self._interval = probe_interval
        self._timeout = probe_timeout
        self._degraded_ms = degraded_threshold_ms
        self._max_backoff = max_backoff
        self._reports: dict[str, HealthReport] = {}
        self._task: asyncio.Task[None] | None = None
        self._running = False

        # Probe functions registered by provider name
        self._probe_fns: dict[str, object] = {}

    def register_probe(self, provider: str, probe_fn: object) -> None:
        """Register a probe function for a provider.

        The probe function should be an async callable that raises
        on failure and returns on success.

        Args:
            provider: Provider name.
            probe_fn: Async callable for probing.
        """
        self._probe_fns[provider] = probe_fn
        if provider not in self._reports:
            self._reports[provider] = HealthReport(provider=provider)

    def get_status(self, provider: str) -> ProviderHealth:
        """Get the current health status of a provider.

        Args:
            provider: Provider name.

        Returns:
            ProviderHealth enum value.
        """
        report = self._reports.get(provider)
        return report.status if report else ProviderHealth.UNKNOWN

    def get_report(self, provider: str) -> HealthReport | None:
        """Get the full health report for a provider.

        Args:
            provider: Provider name.

        Returns:
            HealthReport or None if not tracked.
        """
        return self._reports.get(provider)

    def get_all_reports(self) -> dict[str, HealthReport]:
        """Get health reports for all providers."""
        return dict(self._reports)

    def is_healthy(self, provider: str) -> bool:
        """Check if a provider is healthy or unknown (give benefit of doubt)."""
        status = self.get_status(provider)
        return status in (ProviderHealth.HEALTHY, ProviderHealth.UNKNOWN)

    def get_healthy_providers(self) -> list[str]:
        """Return list of providers that are healthy or degraded."""
        return [
            p for p, r in self._reports.items()
            if r.status in (ProviderHealth.HEALTHY, ProviderHealth.DEGRADED, ProviderHealth.UNKNOWN)
        ]

    async def probe_provider(self, provider: str) -> HealthReport:
        """Probe a single provider and update its health report.

        Args:
            provider: Provider name to probe.

        Returns:
            Updated HealthReport.
        """
        report = self._reports.get(provider)
        if report is None:
            report = HealthReport(provider=provider)
            self._reports[provider] = report

        probe_fn = self._probe_fns.get(provider)
        if probe_fn is None:
            # No probe registered — mark as unknown
            report.status = ProviderHealth.UNKNOWN
            return report

        start = time.monotonic()
        try:
            await asyncio.wait_for(
                probe_fn(),  # type: ignore[operator]
                timeout=self._timeout,
            )
            latency_ms = (time.monotonic() - start) * 1000

            report.latency_ms = latency_ms
            report.last_check = time.monotonic()
            report.consecutive_failures = 0
            report.error_message = ""

            if latency_ms > self._degraded_ms:
                report.status = ProviderHealth.DEGRADED
                logger.info(
                    "provider_degraded",
                    provider=provider,
                    latency_ms=round(latency_ms, 1),
                )
            else:
                report.status = ProviderHealth.HEALTHY

        except TimeoutError:
            report.status = ProviderHealth.DOWN
            report.consecutive_failures += 1
            report.error_message = f"Probe timed out ({self._timeout}s)"
            report.last_check = time.monotonic()
            logger.warning(
                "provider_probe_timeout",
                provider=provider,
                failures=report.consecutive_failures,
            )
        except Exception as exc:
            report.status = ProviderHealth.DOWN
            report.consecutive_failures += 1
            report.error_message = str(exc)[:200]
            report.last_check = time.monotonic()
            logger.warning(
                "provider_probe_failed",
                provider=provider,
                error=str(exc)[:100],
                failures=report.consecutive_failures,
            )

        return report

    async def probe_all(self) -> dict[str, HealthReport]:
        """Probe all registered providers in parallel.

        Returns:
            Dict of provider → HealthReport.
        """
        if not self._probe_fns:
            return {}

        tasks = {
            provider: asyncio.create_task(self.probe_provider(provider))
            for provider in self._probe_fns
        }

        results: dict[str, HealthReport] = {}
        for provider, task in tasks.items():
            try:
                results[provider] = await task
            except Exception as exc:
                logger.warning("probe_task_error", provider=provider, error=str(exc))

        return results

    async def start(self) -> None:
        """Start the background probing loop."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._probe_loop())
        logger.info("health_prober_started", interval=self._interval)

    async def stop(self) -> None:
        """Stop the background probing loop."""
        self._running = False
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
            self._task = None
        logger.info("health_prober_stopped")

    async def _probe_loop(self) -> None:
        """Background loop that probes providers periodically."""
        while self._running:
            try:
                await self.probe_all()
            except Exception as exc:
                logger.warning("probe_loop_error", error=str(exc))

            # Wait with backoff awareness
            await asyncio.sleep(self._interval)

    def mark_healthy(self, provider: str) -> None:
        """Manually mark a provider as healthy (e.g., after a successful request)."""
        report = self._reports.get(provider)
        if report:
            report.status = ProviderHealth.HEALTHY
            report.consecutive_failures = 0
            report.error_message = ""

    def mark_down(self, provider: str, reason: str = "") -> None:
        """Manually mark a provider as down (e.g., after a request failure)."""
        report = self._reports.get(provider)
        if report is None:
            report = HealthReport(provider=provider)
            self._reports[provider] = report
        report.status = ProviderHealth.DOWN
        report.consecutive_failures += 1
        report.error_message = reason
