"""Extended thinking support for reasoning/thinking models.

Provides a unified adapter layer for models that support extended thinking
or chain-of-thought reasoning, including:

- OpenAI o-series (o3, o3-mini, o4-mini) via ``reasoning_effort``
- Anthropic Claude with extended thinking via ``thinking`` content blocks
- DeepSeek-R1 via ``<think>...</think>`` tag extraction

The adapter prepares LiteLLM request kwargs and parses provider-specific
response formats into a uniform :class:`ThinkingResult`.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

import structlog

from prism.cost.pricing import MODEL_PRICING

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

THINKING_MODELS: set[str] = {
    # OpenAI o-series
    "o3",
    "o3-mini",
    "o4-mini",
    # Anthropic extended thinking
    "anthropic/claude-sonnet-4-20250514",
    "anthropic/claude-opus-4-20250514",
    # DeepSeek reasoner
    "deepseek/deepseek-reasoner",
}

# Regex to extract <think>...</think> blocks (DeepSeek-R1 format)
_THINK_TAG_RE = re.compile(r"<think>(.*?)</think>", re.DOTALL)

# Keywords that suggest a prompt would benefit from extended thinking
_THINKING_KEYWORDS: set[str] = {
    "prove", "proof", "theorem", "lemma",
    "derive", "derivation",
    "step by step", "step-by-step",
    "explain your reasoning", "show your work",
    "solve", "calculate", "compute",
    "why does", "why is", "why are",
    "compare and contrast",
    "trade-off", "tradeoff", "trade off",
    "architecture", "design pattern",
    "optimise", "optimize",
    "debug", "root cause",
    "logic", "logical",
    "algorithm", "complexity",
    "mathematical", "equation",
    "induction", "recursion",
    "analyze", "analyse",
    "multi-step", "multistep",
}

# Keywords that suggest thinking is unnecessary — use word-boundary matching
# to avoid false positives (e.g. "hi" matching inside "architecture")
_SIMPLE_KEYWORDS: set[str] = {
    "translate", "translation",
    "summarize", "summarise", "summary",
    "hello", "hey",
    "thank", "thanks",
    "what is your name",
    "creative writing", "write a poem", "write a story",
    "generate a name", "suggest a name",
    "enumerate",
    "reformat",
    "convert", "rename",
}

# Short simple keywords that need word-boundary matching
_SIMPLE_WORD_BOUNDARY: set[str] = {"hi", "list", "format"}

# Pre-compiled patterns for word-boundary keywords
_SIMPLE_BOUNDARY_RE = {
    kw: re.compile(rf"\b{re.escape(kw)}\b") for kw in _SIMPLE_WORD_BOUNDARY
}

# Reasoning effort mapping for OpenAI o-series
_OPENAI_EFFORT_MAP: dict[str, str] = {
    "NONE": "low",
    "BASIC": "low",
    "EXTENDED": "medium",
    "MAX": "high",
}

# Cost multiplier for thinking tokens (thinking tokens are typically
# charged at the output token rate)
_THINKING_COST_MULTIPLIER = 1.0


# ---------------------------------------------------------------------------
# Enums and dataclasses
# ---------------------------------------------------------------------------


class ThinkingMode(StrEnum):
    """Thinking intensity levels."""

    NONE = "NONE"
    BASIC = "BASIC"
    EXTENDED = "EXTENDED"
    MAX = "MAX"


@dataclass
class ThinkingConfig:
    """Configuration for extended thinking behaviour.

    Attributes:
        enabled: Whether to use extended thinking.
        max_thinking_tokens: Budget for reasoning tokens.
        show_thinking: Whether to display the thinking process to the user.
        thinking_model_ids: Set of model IDs that support extended thinking.
    """

    enabled: bool = False
    max_thinking_tokens: int = 8192
    show_thinking: bool = False
    thinking_model_ids: set[str] = field(default_factory=lambda: set(THINKING_MODELS))

    def __post_init__(self) -> None:
        """Validate configuration values."""
        if self.max_thinking_tokens < 0:
            msg = "max_thinking_tokens must be non-negative"
            raise ValueError(msg)


@dataclass(frozen=True)
class ThinkingResult:
    """Result of a thinking-enabled completion.

    Attributes:
        thinking_content: The reasoning trace produced by the model.
        output_content: The final answer after reasoning.
        thinking_tokens: Number of tokens used for thinking.
        output_tokens: Number of tokens in the final output.
        total_tokens: Combined thinking + output tokens.
        thinking_time_ms: Wall-clock time spent on the thinking phase.
        mode_used: The thinking mode that was applied.
    """

    thinking_content: str
    output_content: str
    thinking_tokens: int
    output_tokens: int
    total_tokens: int
    thinking_time_ms: float
    mode_used: ThinkingMode


# ---------------------------------------------------------------------------
# Provider detection helpers
# ---------------------------------------------------------------------------


def _is_openai_reasoning(model: str) -> bool:
    """Check if a model is an OpenAI o-series reasoning model."""
    base = model.rsplit("/", maxsplit=1)[-1] if "/" in model else model
    return base in {"o3", "o3-mini", "o4-mini"}


def _is_anthropic_thinking(model: str) -> bool:
    """Check if a model is an Anthropic model with extended thinking support."""
    return model in {
        "anthropic/claude-sonnet-4-20250514",
        "anthropic/claude-opus-4-20250514",
    }


def _is_deepseek_reasoner(model: str) -> bool:
    """Check if a model is a DeepSeek reasoning model."""
    return model in {"deepseek/deepseek-reasoner"}


# ---------------------------------------------------------------------------
# ThinkingAdapter
# ---------------------------------------------------------------------------


class ThinkingAdapter:
    """Unified adapter for extended thinking across providers.

    Prepares request kwargs and parses responses for models that support
    chain-of-thought reasoning, providing a consistent interface regardless
    of the underlying provider's format.
    """

    def prepare_request(
        self,
        model: str,
        messages: list[dict[str, Any]],
        config: ThinkingConfig,
    ) -> dict[str, Any]:
        """Prepare additional kwargs for a LiteLLM completion call.

        Args:
            model: LiteLLM model identifier.
            messages: Chat messages to send.
            config: Thinking configuration.

        Returns:
            Dictionary of extra kwargs to merge into the LiteLLM call.
        """
        if not config.enabled:
            return {}

        if model not in THINKING_MODELS:
            logger.debug(
                "thinking_not_supported",
                model=model,
                reason="model not in THINKING_MODELS",
            )
            return {}

        mode = self._determine_mode(config)

        if _is_openai_reasoning(model):
            return self._prepare_openai(mode, config)
        if _is_anthropic_thinking(model):
            return self._prepare_anthropic(messages, mode, config)
        if _is_deepseek_reasoner(model):
            return self._prepare_deepseek(messages, mode)

        return {}

    def parse_response(
        self,
        raw_response: dict[str, Any],
        model: str,
    ) -> ThinkingResult:
        """Parse a raw LiteLLM response into a ThinkingResult.

        Extracts thinking content from the provider-specific format:
        - OpenAI o-series: ``reasoning_content`` field in the message
        - Anthropic: ``thinking`` content blocks in the message
        - DeepSeek-R1: ``<think>...</think>`` tags in the content

        Args:
            raw_response: Raw response dict from LiteLLM.
            model: LiteLLM model identifier.

        Returns:
            ThinkingResult with separated thinking and output content.
        """
        start_time = time.monotonic()

        if _is_openai_reasoning(model):
            result = self._parse_openai(raw_response)
        elif _is_anthropic_thinking(model):
            result = self._parse_anthropic(raw_response)
        elif _is_deepseek_reasoner(model):
            result = self._parse_deepseek(raw_response)
        else:
            result = self._parse_generic(raw_response)

        elapsed_ms = (time.monotonic() - start_time) * 1000

        logger.info(
            "thinking_parsed",
            model=model,
            mode=result.mode_used.value,
            thinking_tokens=result.thinking_tokens,
            output_tokens=result.output_tokens,
            thinking_length=len(result.thinking_content),
        )

        # Return a new result with the measured parse time added
        return ThinkingResult(
            thinking_content=result.thinking_content,
            output_content=result.output_content,
            thinking_tokens=result.thinking_tokens,
            output_tokens=result.output_tokens,
            total_tokens=result.total_tokens,
            thinking_time_ms=result.thinking_time_ms + elapsed_ms,
            mode_used=result.mode_used,
        )

    def should_use_thinking(
        self,
        prompt: str,
        complexity_tier: str = "medium",
    ) -> bool:
        """Recommend whether to enable extended thinking for a prompt.

        Analyses the prompt for keywords indicating tasks that benefit from
        chain-of-thought reasoning (math, logic, multi-step, architecture)
        versus tasks where thinking is unnecessary (translation, simple
        creative writing, greetings).

        Args:
            prompt: The user's prompt text.
            complexity_tier: Task complexity tier (simple, medium, complex).

        Returns:
            True if extended thinking is recommended.
        """
        if not prompt or not prompt.strip():
            return False

        prompt_lower = prompt.lower()

        # Always recommend thinking for complex tasks
        if complexity_tier == "complex":
            return True

        # Never recommend for simple greetings/trivial prompts
        if complexity_tier == "simple":
            # Still allow if explicitly requesting reasoning
            for kw in ("step by step", "prove", "derive", "reasoning"):
                if kw in prompt_lower:
                    return True
            return False

        # Check thinking keywords FIRST (higher priority than simple keywords)
        for kw in _THINKING_KEYWORDS:
            if kw in prompt_lower:
                return True

        # Check for simple-task keywords (skip thinking)
        for kw in _SIMPLE_KEYWORDS:
            if kw in prompt_lower:
                return False
        # Word-boundary matching for short keywords to avoid false positives
        for _kw, pattern in _SIMPLE_BOUNDARY_RE.items():
            if pattern.search(prompt_lower):
                return False

        # Medium complexity without strong signals — default to no thinking
        # to save cost
        return False

    def estimate_thinking_cost(
        self,
        model: str,
        max_thinking_tokens: int = 8192,
    ) -> float:
        """Estimate the additional cost of enabling extended thinking.

        Thinking tokens are typically charged at the output token rate.

        Args:
            model: LiteLLM model identifier.
            max_thinking_tokens: Maximum thinking tokens budgeted.

        Returns:
            Estimated additional cost in USD.
        """
        if max_thinking_tokens <= 0:
            return 0.0

        pricing = MODEL_PRICING.get(model)
        if pricing is None:
            # Try without provider prefix
            base_model = model.rsplit("/", maxsplit=1)[-1] if "/" in model else model
            pricing = MODEL_PRICING.get(base_model)

        if pricing is None:
            logger.debug(
                "thinking_cost_unknown",
                model=model,
                reason="model not in pricing table",
            )
            return 0.0

        # Thinking tokens charged at output rate
        cost_per_token = pricing.output_cost_per_1m / 1_000_000
        return cost_per_token * max_thinking_tokens * _THINKING_COST_MULTIPLIER

    # ------------------------------------------------------------------
    # Internal: mode determination
    # ------------------------------------------------------------------

    @staticmethod
    def _determine_mode(config: ThinkingConfig) -> ThinkingMode:
        """Determine the thinking mode from the config's token budget."""
        budget = config.max_thinking_tokens
        if budget <= 0:
            return ThinkingMode.NONE
        if budget <= 2048:
            return ThinkingMode.BASIC
        if budget <= 16384:
            return ThinkingMode.EXTENDED
        return ThinkingMode.MAX

    # ------------------------------------------------------------------
    # Internal: OpenAI o-series
    # ------------------------------------------------------------------

    @staticmethod
    def _prepare_openai(
        mode: ThinkingMode,
        config: ThinkingConfig,
    ) -> dict[str, Any]:
        """Prepare kwargs for OpenAI o-series models."""
        effort = _OPENAI_EFFORT_MAP.get(mode.value, "medium")
        kwargs: dict[str, Any] = {
            "reasoning_effort": effort,
        }
        if config.max_thinking_tokens > 0:
            kwargs["max_completion_tokens"] = (
                config.max_thinking_tokens + 4096  # reasoning + output budget
            )
        return kwargs

    @staticmethod
    def _parse_openai(raw: dict[str, Any]) -> ThinkingResult:
        """Parse OpenAI o-series response with reasoning_content."""
        choices = raw.get("choices", [])
        message = choices[0].get("message", {}) if choices else {}

        reasoning_content = message.get("reasoning_content", "")
        output_content = message.get("content", "")

        usage = raw.get("usage", {})
        reasoning_tokens = usage.get("completion_tokens_details", {}).get(
            "reasoning_tokens", 0,
        )
        output_tokens = usage.get("completion_tokens", 0)

        # If reasoning_tokens not broken out, estimate from content length
        if not reasoning_tokens and reasoning_content:
            reasoning_tokens = max(1, len(reasoning_content.split()) * 2)

        total = reasoning_tokens + output_tokens

        return ThinkingResult(
            thinking_content=reasoning_content or "",
            output_content=output_content or "",
            thinking_tokens=reasoning_tokens,
            output_tokens=output_tokens,
            total_tokens=total,
            thinking_time_ms=0.0,
            mode_used=ThinkingMode.EXTENDED if reasoning_content else ThinkingMode.NONE,
        )

    # ------------------------------------------------------------------
    # Internal: Anthropic extended thinking
    # ------------------------------------------------------------------

    @staticmethod
    def _prepare_anthropic(
        messages: list[dict[str, Any]],
        mode: ThinkingMode,
        config: ThinkingConfig,
    ) -> dict[str, Any]:
        """Prepare kwargs for Anthropic models with extended thinking.

        Anthropic extended thinking is controlled by including a ``thinking``
        parameter in the request.
        """
        return {
            "thinking": {
                "type": "enabled",
                "budget_tokens": config.max_thinking_tokens,
            },
        }

    @staticmethod
    def _parse_anthropic(raw: dict[str, Any]) -> ThinkingResult:
        """Parse Anthropic response with thinking content blocks."""
        content_blocks = raw.get("content", [])

        # Also check nested in choices for LiteLLM wrapper format
        if not content_blocks:
            choices = raw.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content_blocks = message.get("content", [])
                # If content is a plain string, wrap it
                if isinstance(content_blocks, str):
                    content_blocks = [{"type": "text", "text": content_blocks}]

        thinking_parts: list[str] = []
        output_parts: list[str] = []

        if isinstance(content_blocks, list):
            for block in content_blocks:
                if isinstance(block, dict):
                    if block.get("type") == "thinking":
                        thinking_parts.append(block.get("thinking", ""))
                    elif block.get("type") == "text":
                        output_parts.append(block.get("text", ""))
        elif isinstance(content_blocks, str):
            output_parts.append(content_blocks)

        thinking_content = "\n".join(thinking_parts)
        output_content = "\n".join(output_parts)

        usage = raw.get("usage", {})
        thinking_tokens = usage.get("cache_creation_input_tokens", 0)
        # If the API provides explicit thinking token count, use that
        if "thinking_tokens" in usage:
            thinking_tokens = usage["thinking_tokens"]
        output_tokens = usage.get("output_tokens", usage.get("completion_tokens", 0))

        # Estimate thinking tokens from content if not provided
        if not thinking_tokens and thinking_content:
            thinking_tokens = max(1, len(thinking_content.split()) * 2)

        total = thinking_tokens + output_tokens

        return ThinkingResult(
            thinking_content=thinking_content,
            output_content=output_content,
            thinking_tokens=thinking_tokens,
            output_tokens=output_tokens,
            total_tokens=total,
            thinking_time_ms=0.0,
            mode_used=ThinkingMode.EXTENDED if thinking_content else ThinkingMode.NONE,
        )

    # ------------------------------------------------------------------
    # Internal: DeepSeek-R1
    # ------------------------------------------------------------------

    @staticmethod
    def _prepare_deepseek(
        messages: list[dict[str, Any]],
        mode: ThinkingMode,
    ) -> dict[str, Any]:
        """Prepare kwargs for DeepSeek-R1 reasoning model.

        DeepSeek-R1 uses a system prompt or prefix to trigger thinking.
        The model natively outputs ``<think>...</think>`` blocks.
        """
        # DeepSeek-R1 produces thinking natively; we enable it via
        # the API's enable_thinking parameter rather than prompt manipulation
        # to avoid mutating the caller's message list.
        return {
            "extra_body": {"enable_thinking": True},
        }

    @staticmethod
    def _parse_deepseek(raw: dict[str, Any]) -> ThinkingResult:
        """Parse DeepSeek-R1 response by extracting <think> tags."""
        choices = raw.get("choices", [])
        message = choices[0].get("message", {}) if choices else {}
        full_content = message.get("content", "")

        # Also check for reasoning_content field (DeepSeek API native)
        reasoning_content = message.get("reasoning_content", "")

        thinking_content = ""
        output_content = full_content

        if reasoning_content:
            thinking_content = reasoning_content
        else:
            # Extract <think>...</think> tags
            think_matches = _THINK_TAG_RE.findall(full_content)
            if think_matches:
                thinking_content = "\n".join(think_matches)
                # Remove think tags from output
                output_content = _THINK_TAG_RE.sub("", full_content).strip()

        usage = raw.get("usage", {})
        reasoning_tokens = usage.get("completion_tokens_details", {}).get(
            "reasoning_tokens", 0,
        )
        output_tokens = usage.get("completion_tokens", 0)

        if not reasoning_tokens and thinking_content:
            reasoning_tokens = max(1, len(thinking_content.split()) * 2)

        total = reasoning_tokens + output_tokens

        return ThinkingResult(
            thinking_content=thinking_content,
            output_content=output_content,
            thinking_tokens=reasoning_tokens,
            output_tokens=output_tokens,
            total_tokens=total,
            thinking_time_ms=0.0,
            mode_used=ThinkingMode.EXTENDED if thinking_content else ThinkingMode.NONE,
        )

    # ------------------------------------------------------------------
    # Internal: generic fallback
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_generic(raw: dict[str, Any]) -> ThinkingResult:
        """Parse a generic response with no thinking support."""
        choices = raw.get("choices", [])
        message = choices[0].get("message", {}) if choices else {}
        content = message.get("content", "")

        usage = raw.get("usage", {})
        output_tokens = usage.get("completion_tokens", 0)

        return ThinkingResult(
            thinking_content="",
            output_content=content or "",
            thinking_tokens=0,
            output_tokens=output_tokens,
            total_tokens=output_tokens,
            thinking_time_ms=0.0,
            mode_used=ThinkingMode.NONE,
        )
