"""Streaming response handler for LiteLLM async streams."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

import structlog

from prism.cost.pricing import calculate_cost, estimate_input_tokens, get_provider_for_model
from prism.llm.result import CompletionResult

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable

logger = structlog.get_logger(__name__)

# Repetition detection constants
_REPEAT_CHECK_INTERVAL = 200  # Check every N chars accumulated
_MIN_CONTENT_FOR_CHECK = 600  # Don't check until this much content


def _detect_repetition(content: str) -> bool:
    """Detect if the model is stuck in a repetition loop.

    Uses multiple strategies to catch different repetition patterns:
    1. Sliding window: checks if any recent block of text (200-500 chars)
       has appeared earlier in the content.
    2. Line-based: checks if recent lines are duplicating earlier lines.

    Args:
        content: The accumulated content so far.

    Returns:
        True if repetition detected, False otherwise.
    """
    if len(content) < _MIN_CONTENT_FOR_CHECK:
        return False

    # Strategy 1: Check if a block from the recent tail already appeared
    # earlier. Try multiple window sizes to catch different repeat lengths.
    for window_size in (300, 200, 100):
        if len(content) < window_size * 2:
            continue
        # Take a block from the recent part (not the very end to avoid
        # partial matches)
        tail = content[-window_size:]
        # Search in the content BEFORE the tail
        earlier = content[: len(content) - window_size]
        if tail in earlier:
            logger.warning(
                "repetition_detected_window",
                window_size=window_size,
                content_len=len(content),
            )
            return True

    # Strategy 2: Line-based repetition detection.
    # If the last 5 non-empty lines all appear earlier, it's a loop.
    lines = [ln for ln in content.split("\n") if ln.strip()]
    if len(lines) >= 10:
        recent_lines = lines[-5:]
        earlier_lines = lines[:-5]
        earlier_text = "\n".join(earlier_lines)
        matches = sum(1 for ln in recent_lines if ln in earlier_text)
        if matches >= 4:
            logger.warning(
                "repetition_detected_lines",
                matching_lines=matches,
                total_lines=len(lines),
            )
            return True

    return False


class StreamingHandler:
    """Processes streaming chunks from LiteLLM, accumulating the full result.

    Usage::

        handler = StreamingHandler()
        result = await handler.handle_stream(
            stream=litellm_stream,
            model="gpt-4o",
            input_text="Hello",
            on_token=print,
        )
    """

    async def handle_stream(
        self,
        stream: AsyncIterator[Any],
        model: str,
        input_text: str = "",
        on_token: Callable[[str], None] | None = None,
    ) -> CompletionResult:
        """Consume an async stream of chunks and assemble a :class:`CompletionResult`.

        Args:
            stream: Async iterator yielding LiteLLM-style ``ModelResponse`` chunks.
            model: The model identifier (needed for pricing).
            input_text: Original input text (for token estimation).
            on_token: Optional callback invoked with each content delta.

        Returns:
            A fully assembled :class:`CompletionResult`.
        """
        start = time.perf_counter()
        content_parts: list[str] = []
        # Tool calls assembled by index — streaming sends incremental
        # deltas with an ``index`` field that must be merged.
        _tool_call_map: dict[int, dict] = {}
        finish_reason = "stop"
        _raw_usage: dict[str, int] = {}
        _chars_since_check = 0
        _repetition_aborted = False

        async for chunk in stream:
            # Handle both dict-like and attribute-style chunks.
            choices = _get(chunk, "choices", [])
            if not choices:
                continue
            delta = _get(choices[0], "delta", {})
            chunk_finish = _get(choices[0], "finish_reason", None)

            if chunk_finish is not None:
                finish_reason = chunk_finish

            # Content delta
            text = _get(delta, "content", None)
            if text:
                content_parts.append(text)
                _chars_since_check += len(text)
                if on_token is not None:
                    on_token(text)

                # Periodic repetition check
                if _chars_since_check >= _REPEAT_CHECK_INTERVAL:
                    _chars_since_check = 0
                    full_so_far = "".join(content_parts)
                    if _detect_repetition(full_so_far):
                        _repetition_aborted = True
                        finish_reason = "repetition_stopped"
                        break

            # Tool-call deltas — assemble by index.
            # Streaming tool calls arrive as incremental fragments:
            #   chunk 1: {index: 0, id: "call_X", function: {name: "search_web", arguments: ""}}
            #   chunk 2: {index: 0, function: {arguments: '{"qu'}}
            #   chunk 3: {index: 0, function: {arguments: 'ery": "test"}'}}
            # We merge them into complete tool calls keyed by index.
            tc = _get(delta, "tool_calls", None)
            if tc:
                for call_delta in tc:
                    d = _to_dict(call_delta)
                    idx = d.get("index", 0)
                    if idx not in _tool_call_map:
                        # First chunk for this tool call — initialize
                        _tool_call_map[idx] = {
                            "id": d.get("id", ""),
                            "type": d.get("type", "function"),
                            "function": {
                                "name": _get(
                                    d.get("function", {}), "name", ""
                                ),
                                "arguments": _get(
                                    d.get("function", {}), "arguments", ""
                                ),
                            },
                        }
                    else:
                        # Subsequent chunks — merge fields
                        existing = _tool_call_map[idx]
                        if d.get("id"):
                            existing["id"] = d["id"]
                        fn_delta = d.get("function", {})
                        if isinstance(fn_delta, dict):
                            if fn_delta.get("name"):
                                existing["function"]["name"] = fn_delta["name"]
                            if fn_delta.get("arguments"):
                                existing["function"]["arguments"] += fn_delta[
                                    "arguments"
                                ]

            # Some providers include usage on the final chunk.
            usage = _get(chunk, "usage", None)
            if usage is not None:
                _raw_usage = _to_dict(usage)

        elapsed_ms = (time.perf_counter() - start) * 1000
        full_content = "".join(content_parts)

        # If repetition was detected, trim to first occurrence of the
        # repeated block to return clean content
        if _repetition_aborted and len(full_content) > _MIN_CONTENT_FOR_CHECK:
            trimmed = False
            for ws in (300, 200, 100):
                if len(full_content) < ws * 2:
                    continue
                tail = full_content[-ws:]
                earlier = full_content[: len(full_content) - ws]
                pos = earlier.find(tail)
                if pos >= 0:
                    full_content = full_content[: pos + ws]
                    trimmed = True
                    break
            if trimmed:
                logger.info(
                    "repetition_trimmed",
                    original_len=sum(len(p) for p in content_parts),
                    trimmed_len=len(full_content),
                )

        # Token counting: prefer reported usage, fall back to estimates.
        input_tokens = int(_raw_usage.get("prompt_tokens", 0))
        output_tokens = int(
            _raw_usage.get("completion_tokens", 0)
        )
        cached_tokens = int(_raw_usage.get("cached_tokens", 0))

        if input_tokens == 0 and input_text:
            input_tokens = estimate_input_tokens(input_text)
        if output_tokens == 0 and full_content:
            # Rough estimate: ~0.75 tokens per word
            output_tokens = max(1, int(len(full_content.split()) * 0.75))

        try:
            cost = calculate_cost(model, input_tokens, output_tokens, cached_tokens)
        except ValueError:
            cost = 0.0

        provider = get_provider_for_model(model)

        return CompletionResult(
            content=full_content,
            model=model,
            provider=provider,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_tokens=cached_tokens,
            cost_usd=cost,
            latency_ms=elapsed_ms,
            finish_reason=finish_reason,
            tool_calls=(
                [_tool_call_map[i] for i in sorted(_tool_call_map)]
                if _tool_call_map
                else None
            ),
        )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _get(obj: Any, key: str, default: Any = None) -> Any:
    """Retrieve *key* from *obj* whether it is a dict or has attributes."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _to_dict(obj: Any) -> dict:
    """Coerce *obj* to a plain dict."""
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if hasattr(obj, "__dict__"):
        return dict(obj.__dict__)
    return {"value": obj}
