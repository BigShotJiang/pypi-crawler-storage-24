"""Output format detection and intelligent response formatting.

Auto-detects LLM response formats (markdown, JSON, code, plain text, table,
list, XML, YAML, mixed) and provides:

    1. **Format detection** with confidence scoring and language identification
    2. **JSON validation** — schema checks, trailing-comma repair, pretty-print
    3. **Code block extraction** with language detection
    4. **Table detection** — markdown tables normalised to structured data
    5. **Smart truncation** — never cuts mid-sentence or mid-code-block
    6. **Multi-format splitting** — separate code from explanation from examples
    7. **Token counting** per section (word-based approximation, no tiktoken)
    8. **Response quality scoring** — completeness and coherence heuristics
    9. **Format conversion** — JSON to YAML, table to CSV, markdown to plain text

Usage::

    formatter = OutputFormatter()
    detection = formatter.detect_format(response_text)
    formatted = formatter.format_response(response_text)
    truncated = formatter.truncate(response_text, TruncationConfig(max_tokens=500))
"""

from __future__ import annotations

import csv
import io
import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Enums and data structures
# ---------------------------------------------------------------------------


class FormatType(Enum):
    """Detected format type for a response or section."""

    MARKDOWN = "markdown"
    JSON = "json"
    CODE = "code"
    PLAIN = "plain"
    TABLE = "table"
    LIST = "list"
    XML = "xml"
    YAML = "yaml"
    MIXED = "mixed"


class BoundaryMode(Enum):
    """How smart truncation respects content boundaries."""

    SENTENCE = "sentence"
    CODE_BLOCK = "code_block"
    PARAGRAPH = "paragraph"
    HARD = "hard"


@dataclass(frozen=True)
class TruncationConfig:
    """Configuration for smart truncation.

    Attributes:
        max_tokens: Maximum token count (word-based estimate).
        max_chars: Maximum character count (0 = unlimited).
        boundary_mode: Which boundary to respect when truncating.
        ellipsis: String appended after truncation.
    """

    max_tokens: int = 1000
    max_chars: int = 0
    boundary_mode: BoundaryMode = BoundaryMode.SENTENCE
    ellipsis: str = "\n\n... [truncated]"


@dataclass
class OutputSection:
    """A single section within a multi-format response.

    Attributes:
        content: The raw text of this section.
        format_type: Detected format for this section.
        language: Programming language (if CODE section).
        start_line: Starting line number (0-based) in the original response.
        end_line: Ending line number (0-based, inclusive) in the original response.
        token_count: Estimated token count for this section.
    """

    content: str
    format_type: FormatType
    language: str = ""
    start_line: int = 0
    end_line: int = 0
    token_count: int = 0


@dataclass
class FormatDetection:
    """Result of format auto-detection.

    Attributes:
        format_type: The primary detected format.
        confidence: Confidence in the detection (0.0 to 1.0).
        language: Detected programming language (if code).
        sections: Individual sections if the response is multi-format.
    """

    format_type: FormatType
    confidence: float
    language: str = ""
    sections: list[OutputSection] = field(default_factory=list)


@dataclass
class FormattedOutput:
    """Result of formatting a response.

    Attributes:
        sections: All output sections with formatting metadata.
        total_tokens: Total estimated token count across all sections.
        quality_score: Heuristic quality score (0.0 to 1.0).
        detected_format: The format detection result.
        metadata: Arbitrary metadata about the formatting process.
    """

    sections: list[OutputSection]
    total_tokens: int
    quality_score: float
    detected_format: FormatDetection
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# Fenced code blocks: ```lang\n...\n```
_CODE_FENCE = re.compile(r"```(\w*)\n([\s\S]*?)```")

# Markdown heading
_MD_HEADING = re.compile(r"^#{1,6}\s", re.MULTILINE)

# Markdown bold/italic
_MD_EMPHASIS = re.compile(r"\*{1,3}[^*]+\*{1,3}|_{1,3}[^_]+_{1,3}")

# Markdown bullet lists
_MD_BULLET = re.compile(r"^[ \t]*[-*+]\s", re.MULTILINE)

# Markdown ordered lists
_MD_ORDERED = re.compile(r"^[ \t]*\d+\.\s", re.MULTILINE)

# Markdown link
_MD_LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")

# Markdown table row: | col | col |
_MD_TABLE_ROW = re.compile(r"^\|(.+\|)+$", re.MULTILINE)

# Markdown table separator: |---|---|
_MD_TABLE_SEP = re.compile(r"^\|[\s:]*-{3,}[\s:]*(\|[\s:]*-{3,}[\s:]*)*\|$", re.MULTILINE)

# XML tags
_XML_TAG = re.compile(r"<(/?\w[\w.-]*)((?:\s+\w[\w.-]*\s*=\s*\"[^\"]*\")*)\s*/?>")

# YAML key-value at line start
_YAML_KV = re.compile(r"^[\w][\w\s]*:\s", re.MULTILINE)

# YAML document separator
_YAML_DOC = re.compile(r"^---\s*$", re.MULTILINE)

# YAML list item
_YAML_LIST = re.compile(r"^- ", re.MULTILINE)

# JSON trailing comma before } or ]
_JSON_TRAILING_COMMA = re.compile(r",\s*([}\]])")

# Sentence boundary — period, exclamation, or question followed by space or end
_SENTENCE_END = re.compile(r"[.!?](?:\s|$)")

# Common code keywords (for language-agnostic detection)
_CODE_KEYWORDS = re.compile(
    r"\b(?:def |class |function |const |let |var |import |from |return |if |for |while )\b"
)


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------


def estimate_tokens(text: str) -> int:
    """Estimate token count using a word-based heuristic.

    LLM tokenisers typically produce ~1.3 tokens per whitespace-delimited
    word for English prose and ~1.5 for code.  We use 1.3 as a reasonable
    middle ground; callers needing precision should use a real tokeniser.

    Args:
        text: Input text.

    Returns:
        Estimated token count.
    """
    if not text:
        return 0
    words = text.split()
    return max(1, int(len(words) * 1.3))


# ---------------------------------------------------------------------------
# OutputFormatter — main class
# ---------------------------------------------------------------------------


class OutputFormatter:
    """Intelligent LLM response formatter.

    Detects output format, splits multi-format responses into sections,
    applies pretty-printing, and provides quality scoring and truncation.
    """

    # ----- public API -----

    def detect_format(self, text: str) -> FormatDetection:
        """Auto-detect the format of a response.

        Examines structural cues (headings, fences, braces, tags, indentation)
        and returns the best-matching ``FormatType`` with a confidence score.

        Args:
            text: Raw LLM response text.

        Returns:
            FormatDetection describing the detected format.
        """
        if not text or not text.strip():
            return FormatDetection(
                format_type=FormatType.PLAIN, confidence=1.0, sections=[]
            )

        scores: dict[FormatType, float] = {ft: 0.0 for ft in FormatType}

        stripped = text.strip()

        # --- JSON ---
        if self._looks_like_json(stripped):
            scores[FormatType.JSON] += 0.9

        # --- XML ---
        xml_score = self._score_xml(stripped)
        scores[FormatType.XML] += xml_score

        # --- YAML ---
        yaml_score = self._score_yaml(stripped)
        scores[FormatType.YAML] += yaml_score

        # --- Table ---
        table_score = self._score_table(stripped)
        scores[FormatType.TABLE] += table_score

        # --- List ---
        list_score = self._score_list(stripped)
        scores[FormatType.LIST] += list_score

        # --- Code ---
        code_score, language = self._score_code(stripped)
        scores[FormatType.CODE] += code_score

        # --- Markdown ---
        md_score = self._score_markdown(stripped)
        scores[FormatType.MARKDOWN] += md_score

        # --- Plain text fallback ---
        scores[FormatType.PLAIN] = 0.1  # low default

        # Pick winner
        best_type = max(scores, key=lambda k: scores[k])
        best_score = scores[best_type]

        # Check for MIXED: if runner-up is close and of a different family
        sorted_types = sorted(scores, key=lambda k: scores[k], reverse=True)
        runner_up = sorted_types[1] if len(sorted_types) > 1 else FormatType.PLAIN
        if (
            best_score > 0.0
            and scores[runner_up] > 0.4
            and best_score - scores[runner_up] < 0.25
            and best_type != runner_up
        ):
            best_type = FormatType.MIXED
            best_score = max(best_score, scores[runner_up])

        # Plain gets full confidence when nothing else matched
        if best_type == FormatType.PLAIN and best_score < 0.2:
            best_score = 0.8

        confidence = min(1.0, best_score)
        lang = language if best_type in (FormatType.CODE, FormatType.MIXED) else ""

        # Build sections
        sections = self._split_sections(text)

        return FormatDetection(
            format_type=best_type,
            confidence=round(confidence, 3),
            language=lang,
            sections=sections,
        )

    def format_response(self, text: str) -> FormattedOutput:
        """Detect format and produce a fully annotated FormattedOutput.

        Args:
            text: Raw LLM response text.

        Returns:
            FormattedOutput with sections, token counts, and quality score.
        """
        detection = self.detect_format(text)
        sections = detection.sections or self._split_sections(text)

        # Annotate each section with token count
        for sec in sections:
            sec.token_count = estimate_tokens(sec.content)

        total_tokens = sum(s.token_count for s in sections)
        quality = self.score_quality(text)

        return FormattedOutput(
            sections=sections,
            total_tokens=total_tokens,
            quality_score=quality,
            detected_format=detection,
            metadata={
                "section_count": len(sections),
                "char_count": len(text),
            },
        )

    # ----- JSON helpers -----

    def validate_json(self, text: str) -> tuple[Any | None, list[str]]:
        """Parse and validate JSON, repairing common LLM mistakes.

        Handles:
        - Trailing commas before ``}`` or ``]``
        - JSON wrapped in markdown code fences
        - Single quotes instead of double quotes (simple cases)

        Args:
            text: Text that should contain JSON.

        Returns:
            Tuple of (parsed object or None, list of issue descriptions).
        """
        issues: list[str] = []
        stripped = text.strip()

        # Fast path — valid as-is
        parsed = self._try_parse_json(stripped)
        if parsed is not None:
            return parsed, issues

        # Try extracting from code fences
        fence_match = _CODE_FENCE.search(stripped)
        if fence_match:
            inner = fence_match.group(2).strip()
            parsed = self._try_parse_json(inner)
            if parsed is not None:
                issues.append("JSON was wrapped in a code fence")
                return parsed, issues
            # Continue with the inner content for repair attempts
            stripped = inner

        # Repair: trailing commas
        repaired = _JSON_TRAILING_COMMA.sub(r"\1", stripped)
        parsed = self._try_parse_json(repaired)
        if parsed is not None:
            issues.append("Repaired trailing comma(s)")
            return parsed, issues

        # Repair: single quotes → double quotes (only simple cases)
        repaired_sq = stripped.replace("'", '"')
        parsed = self._try_parse_json(repaired_sq)
        if parsed is not None:
            issues.append("Replaced single quotes with double quotes")
            return parsed, issues

        # Repair: combined
        repaired_combined = _JSON_TRAILING_COMMA.sub(r"\1", repaired_sq)
        parsed = self._try_parse_json(repaired_combined)
        if parsed is not None:
            issues.append("Repaired trailing commas and replaced single quotes")
            return parsed, issues

        issues.append("Could not parse or repair JSON")
        return None, issues

    def pretty_print_json(self, data: Any, indent: int = 2) -> str:
        """Pretty-print a parsed JSON value.

        Args:
            data: A JSON-serialisable Python object.
            indent: Number of spaces per indentation level.

        Returns:
            Indented JSON string.
        """
        return json.dumps(data, indent=indent, ensure_ascii=False, sort_keys=False)

    # ----- Code block extraction -----

    def extract_code_blocks(self, text: str) -> list[OutputSection]:
        """Extract fenced code blocks from a response.

        Args:
            text: Response text potentially containing ```...``` blocks.

        Returns:
            List of OutputSection instances (one per code block).
        """
        blocks: list[OutputSection] = []
        lines = text.split("\n")
        for match in _CODE_FENCE.finditer(text):
            lang = match.group(1) or self._guess_language(match.group(2))
            code = match.group(2)
            start_offset = text[: match.start()].count("\n")
            end_offset = start_offset + code.count("\n") + 1  # +1 for closing fence
            blocks.append(
                OutputSection(
                    content=code,
                    format_type=FormatType.CODE,
                    language=lang,
                    start_line=start_offset,
                    end_line=min(end_offset, len(lines) - 1),
                    token_count=estimate_tokens(code),
                )
            )
        return blocks

    # ----- Table detection and normalisation -----

    def detect_table(self, text: str) -> list[list[str]] | None:
        """Detect and parse a markdown table into a list of rows.

        Each row is a list of cell strings.  The first row is the header.
        The separator row (``|---|---|``) is omitted.

        Args:
            text: Text that may contain a markdown table.

        Returns:
            Parsed rows, or ``None`` if no table detected.
        """
        table_rows = _MD_TABLE_ROW.findall(text)
        if len(table_rows) < 2:
            return None

        # Collect contiguous table lines
        lines = text.split("\n")
        table_lines: list[str] = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("|") and stripped.endswith("|"):
                table_lines.append(stripped)
            elif table_lines:
                # End of contiguous table block
                break

        if len(table_lines) < 2:
            return None

        rows: list[list[str]] = []
        for line in table_lines:
            # Skip separator rows
            if _MD_TABLE_SEP.match(line):
                continue
            cells = [c.strip() for c in line.strip("|").split("|")]
            rows.append(cells)

        return rows if rows else None

    def table_to_csv(self, rows: list[list[str]]) -> str:
        """Convert parsed table rows to CSV.

        Args:
            rows: List of rows from ``detect_table``.

        Returns:
            CSV-formatted string.
        """
        buf = io.StringIO()
        writer = csv.writer(buf)
        for row in rows:
            writer.writerow(row)
        return buf.getvalue()

    # ----- Smart truncation -----

    def truncate(self, text: str, config: TruncationConfig | None = None) -> str:
        """Truncate text respecting content boundaries.

        Args:
            text: Input text.
            config: Truncation configuration.  Defaults are used if ``None``.

        Returns:
            Truncated text (with ellipsis appended if truncation occurred).
        """
        if config is None:
            config = TruncationConfig()

        tokens = estimate_tokens(text)
        within_tokens = tokens <= config.max_tokens
        within_chars = config.max_chars <= 0 or len(text) <= config.max_chars

        if within_tokens and within_chars:
            return text  # No truncation needed

        # Determine the hard character limit we must respect
        char_limit = len(text)
        if config.max_chars > 0:
            char_limit = min(char_limit, config.max_chars)

        # Also derive a char limit from token budget (rough inverse of estimate_tokens)
        token_char_limit = int(config.max_tokens / 1.3 * 5)  # ~5 chars/word
        char_limit = min(char_limit, token_char_limit)

        # Ensure we don't add ellipsis longer than the limit
        ellipsis_len = len(config.ellipsis)
        if char_limit <= ellipsis_len:
            return text[:char_limit]

        usable = char_limit - ellipsis_len

        if config.boundary_mode == BoundaryMode.HARD:
            return text[:usable] + config.ellipsis

        if config.boundary_mode == BoundaryMode.SENTENCE:
            return self._truncate_sentence(text, usable, config.ellipsis)

        if config.boundary_mode == BoundaryMode.PARAGRAPH:
            return self._truncate_paragraph(text, usable, config.ellipsis)

        if config.boundary_mode == BoundaryMode.CODE_BLOCK:
            return self._truncate_code_block(text, usable, config.ellipsis)

        # Fallback
        return text[:usable] + config.ellipsis

    # ----- Multi-section splitting -----

    def split_sections(self, text: str) -> list[OutputSection]:
        """Public wrapper for section splitting.

        Args:
            text: Raw response text.

        Returns:
            List of OutputSection instances.
        """
        return self._split_sections(text)

    # ----- Quality scoring -----

    def score_quality(self, text: str) -> float:
        """Heuristic quality score for a response.

        Evaluates:
        - Non-empty content
        - No mid-sentence cutoff
        - Balanced brackets in code
        - No excessive repetition
        - Structural completeness

        Args:
            text: Response text.

        Returns:
            Score between 0.0 and 1.0.
        """
        if not text or not text.strip():
            return 0.0

        score = 0.5  # Base for non-empty

        stripped = text.rstrip()

        # Ending punctuation or code fence closure → complete
        if (stripped and stripped[-1] in ".!?`>)];\"'") or stripped.endswith("```"):
            score += 0.15

        # Balanced brackets
        bracket_pairs = {"{": "}", "[": "]", "(": ")"}
        balanced = True
        for open_b, close_b in bracket_pairs.items():
            if text.count(open_b) != text.count(close_b):
                balanced = False
                break
        if balanced:
            score += 0.15

        # No excessive repetition (same 40+ char substring repeated 3+ times)
        if not re.search(r"(.{40,})\1{2,}", text):
            score += 0.10

        # Has some structure (headings, code blocks, paragraphs > 1)
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        if len(paragraphs) > 1 or _CODE_FENCE.search(text) or _MD_HEADING.search(text):
            score += 0.10

        return round(min(1.0, score), 3)

    # ----- Format conversion -----

    def json_to_yaml(self, text: str) -> str:
        """Convert a JSON string to YAML format.

        Uses a simple recursive serialiser (no PyYAML dependency).

        Args:
            text: JSON string.

        Returns:
            YAML-formatted string.

        Raises:
            ValueError: If the input is not valid JSON.
        """
        parsed = self._try_parse_json(text.strip())
        if parsed is None:
            raise ValueError("Input is not valid JSON")
        return self._to_yaml(parsed, indent=0)

    def table_to_csv_from_text(self, text: str) -> str:
        """Detect a markdown table in *text* and convert it to CSV.

        Args:
            text: Text containing a markdown table.

        Returns:
            CSV string, or empty string if no table found.
        """
        rows = self.detect_table(text)
        if rows is None:
            return ""
        return self.table_to_csv(rows)

    def markdown_to_plain(self, text: str) -> str:
        """Strip markdown formatting to produce plain text.

        Removes headings markers, emphasis markers, link syntax, code fences,
        and horizontal rules.

        Args:
            text: Markdown text.

        Returns:
            Plain text with formatting removed.
        """
        result = text

        # Remove code fences but keep code content
        result = _CODE_FENCE.sub(r"\2", result)

        # Remove inline code backticks
        result = re.sub(r"`([^`]+)`", r"\1", result)

        # Remove heading markers
        result = re.sub(r"^#{1,6}\s+", "", result, flags=re.MULTILINE)

        # Remove bold/italic markers
        result = re.sub(r"\*{1,3}([^*]+)\*{1,3}", r"\1", result)
        result = re.sub(r"_{1,3}([^_]+)_{1,3}", r"\1", result)

        # Remove link syntax → keep link text
        result = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", result)

        # Remove images
        result = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", result)

        # Remove horizontal rules
        result = re.sub(r"^[-*_]{3,}\s*$", "", result, flags=re.MULTILINE)

        # Remove blockquote markers
        result = re.sub(r"^>\s?", "", result, flags=re.MULTILINE)

        # Collapse multiple blank lines
        result = re.sub(r"\n{3,}", "\n\n", result)

        return result.strip()

    # ------------------------------------------------------------------
    # Private helpers — format scoring
    # ------------------------------------------------------------------

    @staticmethod
    def _looks_like_json(text: str) -> bool:
        """Return True if *text* can be parsed as JSON."""
        stripped = text.strip()
        if not stripped:
            return False
        if stripped[0] not in ("{", "["):
            return False
        try:
            json.loads(stripped)
        except (json.JSONDecodeError, ValueError):
            return False
        return True

    @staticmethod
    def _score_xml(text: str) -> float:
        """Score how XML-like the text is."""
        tags = _XML_TAG.findall(text)
        if len(tags) < 2:
            return 0.0
        # Check for matching open/close pairs
        stripped = text.strip()
        if stripped.startswith("<") and stripped.endswith(">"):
            return min(1.0, 0.3 + len(tags) * 0.05)
        return min(0.7, len(tags) * 0.05)

    @staticmethod
    def _score_yaml(text: str) -> float:
        """Score how YAML-like the text is."""
        kv_matches = _YAML_KV.findall(text)
        has_doc_sep = bool(_YAML_DOC.search(text))
        list_items = _YAML_LIST.findall(text)

        if not kv_matches and not has_doc_sep:
            return 0.0

        score = 0.0
        if kv_matches:
            score += min(0.5, len(kv_matches) * 0.08)
        if has_doc_sep:
            score += 0.2
        if list_items:
            score += min(0.2, len(list_items) * 0.03)

        # Penalise if it also looks like markdown (headings, bold)
        if _MD_HEADING.search(text):
            score *= 0.5

        return min(1.0, score)

    @staticmethod
    def _score_table(text: str) -> float:
        """Score how table-like the text is."""
        rows = _MD_TABLE_ROW.findall(text)
        sep = _MD_TABLE_SEP.search(text)
        if sep and len(rows) >= 3:
            return 0.9
        if len(rows) >= 3:
            return 0.6
        return 0.0

    @staticmethod
    def _score_list(text: str) -> float:
        """Score how list-like the text is."""
        bullets = _MD_BULLET.findall(text)
        ordered = _MD_ORDERED.findall(text)
        total = len(bullets) + len(ordered)
        lines = text.strip().split("\n")
        if total == 0:
            return 0.0
        ratio = total / max(1, len(lines))
        if ratio > 0.6:
            return 0.85
        if ratio > 0.3:
            return 0.5
        return 0.2

    @staticmethod
    def _score_code(text: str) -> tuple[float, str]:
        """Score how code-like the text is and guess the language."""
        fences = _CODE_FENCE.findall(text)
        language = ""

        # If fenced code blocks dominate the response, it's code
        if fences:
            fence_chars = sum(len(code) for _, code in fences)
            ratio = fence_chars / max(1, len(text))
            if fences[0][0]:
                language = fences[0][0]
            if ratio > 0.5:
                return (0.85, language)
            return (0.4, language)

        # No fences — check for raw code patterns
        keyword_hits = len(_CODE_KEYWORDS.findall(text))
        if keyword_hits >= 5:
            return (0.7, "")
        if keyword_hits >= 2:
            return (0.35, "")
        return (0.0, "")

    @staticmethod
    def _score_markdown(text: str) -> float:
        """Score how markdown-like the text is."""
        score = 0.0
        if _MD_HEADING.search(text):
            score += 0.35
        if _MD_EMPHASIS.search(text):
            score += 0.15
        if _MD_LINK.search(text):
            score += 0.1
        if _MD_BULLET.search(text) or _MD_ORDERED.search(text):
            score += 0.15
        if _CODE_FENCE.search(text):
            score += 0.15
        return min(1.0, score)

    # ------------------------------------------------------------------
    # Private helpers — section splitting
    # ------------------------------------------------------------------

    def _split_sections(self, text: str) -> list[OutputSection]:
        """Split a response into typed sections.

        Recognises fenced code blocks, markdown tables, and prose paragraphs.
        """
        if not text or not text.strip():
            return []

        sections: list[OutputSection] = []
        lines = text.split("\n")
        num_lines = len(lines)

        # Build a line-level classification
        # 'code_start', 'code_body', 'code_end', 'table', 'text'
        line_types: list[str] = ["text"] * num_lines
        in_fence = False

        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("```"):
                if not in_fence:
                    in_fence = True
                    line_types[i] = "code_start"
                else:
                    in_fence = False
                    line_types[i] = "code_end"
            elif in_fence:
                line_types[i] = "code_body"
            elif stripped.startswith("|") and stripped.endswith("|") and "|" in stripped[1:-1]:
                line_types[i] = "table"

        # Merge contiguous runs
        current_type = ""
        current_lines: list[str] = []
        current_start = 0
        current_lang = ""

        def _flush() -> None:
            if not current_lines:
                return
            content = "\n".join(current_lines)
            if not content.strip():
                return
            ft = _line_type_to_format(current_type)
            sections.append(
                OutputSection(
                    content=content,
                    format_type=ft,
                    language=current_lang if ft == FormatType.CODE else "",
                    start_line=current_start,
                    end_line=current_start + len(current_lines) - 1,
                    token_count=estimate_tokens(content),
                )
            )

        for i, line in enumerate(lines):
            lt = line_types[i]

            if lt == "code_start":
                _flush()
                current_type = "code"
                current_lines = []
                current_start = i
                fence_lang_match = line.strip()[3:].strip()
                current_lang = fence_lang_match
            elif lt == "code_end":
                # Include closing fence content in section
                ft = FormatType.CODE
                code_content = "\n".join(current_lines)
                if code_content.strip() or current_lines:
                    sections.append(
                        OutputSection(
                            content=code_content,
                            format_type=ft,
                            language=current_lang,
                            start_line=current_start,
                            end_line=i,
                            token_count=estimate_tokens(code_content),
                        )
                    )
                current_type = ""
                current_lines = []
                current_start = i + 1
                current_lang = ""
            elif lt == "code_body":
                current_lines.append(line)
            elif lt == "table":
                if current_type != "table":
                    _flush()
                    current_type = "table"
                    current_lines = [line]
                    current_start = i
                else:
                    current_lines.append(line)
            elif current_type not in ("text", ""):
                _flush()
                current_type = "text"
                current_lines = [line]
                current_start = i
            else:
                if current_type == "":
                    current_start = i
                current_type = "text"
                current_lines.append(line)

        _flush()
        return sections

    # ------------------------------------------------------------------
    # Private helpers — truncation
    # ------------------------------------------------------------------

    def _truncate_sentence(self, text: str, usable: int, ellipsis: str) -> str:
        """Truncate at the last sentence boundary before *usable* chars."""
        if usable <= 0:
            return ellipsis.lstrip()
        window = text[:usable]
        # Find last sentence ending
        last_end = -1
        for m in _SENTENCE_END.finditer(window):
            last_end = m.end()
        if last_end > 0:
            return text[:last_end].rstrip() + ellipsis
        # No sentence end found — fall back to last space
        last_space = window.rfind(" ")
        if last_space > 0:
            return text[:last_space].rstrip() + ellipsis
        return text[:usable] + ellipsis

    def _truncate_paragraph(self, text: str, usable: int, ellipsis: str) -> str:
        """Truncate at the last paragraph boundary before *usable* chars."""
        if usable <= 0:
            return ellipsis.lstrip()
        window = text[:usable]
        last_para = window.rfind("\n\n")
        if last_para > 0:
            return text[:last_para].rstrip() + ellipsis
        # Fall back to sentence
        return self._truncate_sentence(text, usable, ellipsis)

    def _truncate_code_block(self, text: str, usable: int, ellipsis: str) -> str:
        """Truncate without splitting a fenced code block.

        If the cut point falls inside a code fence, back up to just before
        that fence opened.
        """
        if usable <= 0:
            return ellipsis.lstrip()
        window = text[:usable]
        # Check whether we're mid-fence
        open_fences = [m.start() for m in re.finditer(r"```", window)]
        if len(open_fences) % 2 != 0:
            # Odd number of fences — we're inside a block.  Back up.
            last_open = open_fences[-1]
            # Go to the newline before the opening fence
            boundary = text.rfind("\n", 0, last_open)
            if boundary > 0:
                return text[:boundary].rstrip() + ellipsis
        # Even fences — safe to cut at sentence/paragraph
        return self._truncate_sentence(text, usable, ellipsis)

    # ------------------------------------------------------------------
    # Private helpers — language guessing
    # ------------------------------------------------------------------

    @staticmethod
    def _guess_language(code: str) -> str:
        """Guess programming language from code content."""
        indicators: dict[str, list[str]] = {
            "python": ["def ", "import ", "class ", "self.", "elif ", "print("],
            "javascript": ["const ", "let ", "var ", "function ", "=> ", "console.log"],
            "typescript": ["interface ", ": string", ": number", "export ", "import type"],
            "java": ["public class", "System.out", "void ", "private ", "protected "],
            "go": ["func ", "package ", "fmt.", "import (", ":= "],
            "rust": ["fn ", "let mut ", "impl ", "pub fn", "use "],
            "ruby": ["def ", "end\n", "puts ", "require ", "attr_"],
            "bash": ["#!/bin/bash", "echo ", "if [", "fi\n", "done\n"],
            "sql": ["SELECT ", "FROM ", "WHERE ", "INSERT ", "CREATE TABLE"],
            "html": ["<!DOCTYPE", "<html", "<div", "<span", "<body"],
            "css": ["{", "color:", "margin:", "padding:", "display:"],
        }
        best_lang = ""
        best_count = 0
        for lang, patterns in indicators.items():
            count = sum(1 for p in patterns if p in code)
            if count > best_count:
                best_count = count
                best_lang = lang
        return best_lang if best_count >= 2 else ""

    # ------------------------------------------------------------------
    # Private helpers — YAML serialisation
    # ------------------------------------------------------------------

    def _to_yaml(self, obj: Any, indent: int = 0) -> str:
        """Recursively serialise a Python object to YAML (stdlib only)."""
        prefix = "  " * indent
        if obj is None:
            return "null\n"
        if isinstance(obj, bool):
            return ("true" if obj else "false") + "\n"
        if isinstance(obj, (int, float)):
            return str(obj) + "\n"
        if isinstance(obj, str):
            if "\n" in obj:
                lines = obj.split("\n")
                result = "|\n"
                for line in lines:
                    result += prefix + "  " + line + "\n"
                return result
            # Quote if it contains special chars
            if any(c in obj for c in ":{},[]&*?|>!%@`"):
                return json.dumps(obj) + "\n"
            if not obj:
                return "''" + "\n"
            return obj + "\n"
        if isinstance(obj, list):
            if not obj:
                return "[]\n"
            result = "\n"
            for item in obj:
                item_yaml = self._to_yaml(item, indent + 1).lstrip("\n")
                result += prefix + "- " + item_yaml
            return result
        if isinstance(obj, dict):
            if not obj:
                return "{}\n"
            result = "\n"
            for key, value in obj.items():
                key_str = str(key)
                val_yaml = self._to_yaml(value, indent + 1)
                if isinstance(value, (dict, list)) and value:
                    result += prefix + key_str + ":" + val_yaml
                else:
                    result += prefix + key_str + ": " + val_yaml.lstrip("\n")
            return result
        return str(obj) + "\n"

    # ------------------------------------------------------------------
    # Private helpers — JSON parsing
    # ------------------------------------------------------------------

    @staticmethod
    def _try_parse_json(text: str) -> Any | None:
        """Attempt to parse JSON, returning ``None`` on failure."""
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            return None


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _line_type_to_format(lt: str) -> FormatType:
    """Map an internal line-type string to a ``FormatType``."""
    mapping: dict[str, FormatType] = {
        "code": FormatType.CODE,
        "table": FormatType.TABLE,
        "text": FormatType.PLAIN,
    }
    return mapping.get(lt, FormatType.PLAIN)
