"""Accurate token counting using tiktoken with graceful fallback."""

from __future__ import annotations

import functools
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

# ---------------------------------------------------------------------------
# Lazy tiktoken import with fallback
# ---------------------------------------------------------------------------

_tiktoken = None
_tiktoken_lock = threading.Lock()
_tiktoken_available: bool | None = None


def _ensure_tiktoken() -> bool:
    """Try to import tiktoken once; cache the result."""
    global _tiktoken, _tiktoken_available  # noqa: PLW0603
    if _tiktoken_available is not None:
        return _tiktoken_available
    with _tiktoken_lock:
        if _tiktoken_available is not None:
            return _tiktoken_available
        try:
            import tiktoken as _tk

            _tiktoken = _tk
            _tiktoken_available = True
        except ImportError:
            _tiktoken_available = False
    return _tiktoken_available


# ---------------------------------------------------------------------------
# Model -> encoding mapping
# ---------------------------------------------------------------------------

# Maps model prefixes/names to tiktoken encoding names
_MODEL_ENCODING_MAP: dict[str, str] = {
    # OpenAI
    "gpt-4o": "o200k_base",
    "gpt-4-turbo": "cl100k_base",
    "gpt-4": "cl100k_base",
    "gpt-3.5-turbo": "cl100k_base",
    "o1": "o200k_base",
    "o3": "o200k_base",
    # Anthropic -- tiktoken doesn't have Claude's tokenizer,
    # but cl100k_base is a reasonable approximation (~5% off)
    "claude": "cl100k_base",
    # Google -- approximate with cl100k_base
    "gemini": "cl100k_base",
    # DeepSeek -- approximate
    "deepseek": "cl100k_base",
    # Mistral -- approximate
    "mistral": "cl100k_base",
    # Groq hosts open models -- approximate
    "llama": "cl100k_base",
    # Fallback
    "default": "cl100k_base",
}


@functools.lru_cache(maxsize=32)
def _get_encoding(model: str) -> str:
    """Resolve a model name to a tiktoken encoding name."""
    model_lower = model.lower()
    for prefix, encoding in _MODEL_ENCODING_MAP.items():
        if model_lower.startswith(prefix):
            return encoding
    return _MODEL_ENCODING_MAP["default"]


@functools.lru_cache(maxsize=8)
def _get_encoder(encoding_name: str):
    """Get a cached tiktoken encoder.

    Returns a tiktoken ``Encoding`` instance or ``None`` when tiktoken is
    unavailable.  The return type is untyped because tiktoken is optional.
    """
    if not _ensure_tiktoken():
        return None
    return _tiktoken.get_encoding(encoding_name)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def count_tokens(text: str, model: str = "gpt-4o") -> int:
    """Count tokens in text using tiktoken (or fallback heuristic).

    Args:
        text: The text to count tokens for.
        model: Model name to select the right tokenizer.

    Returns:
        Token count (exact with tiktoken, approximate without).
    """
    if not text:
        return 0

    encoding_name = _get_encoding(model)
    encoder = _get_encoder(encoding_name)

    if encoder is not None:
        return len(encoder.encode(text, disallowed_special=()))

    # Fallback: improved heuristic
    return _heuristic_count(text)


def count_tokens_batch(texts: Sequence[str], model: str = "gpt-4o") -> list[int]:
    """Count tokens for multiple texts efficiently."""
    if not texts:
        return []

    encoding_name = _get_encoding(model)
    encoder = _get_encoder(encoding_name)

    if encoder is not None:
        return [len(encoder.encode(t, disallowed_special=())) for t in texts]

    return [_heuristic_count(t) for t in texts]


def count_message_tokens(
    messages: Sequence[dict],
    model: str = "gpt-4o",
) -> int:
    """Count tokens for a list of chat messages (OpenAI format).

    Accounts for message framing overhead per the OpenAI token counting guide:
    - Each message adds ~4 tokens of overhead (role, content delimiters)
    - The overall conversation adds ~3 tokens of overhead
    """
    if not messages:
        return 0

    # Per-message overhead varies by model, but 4 is a good average
    per_message_overhead = 4
    base_overhead = 3  # every reply is primed with <|start|>assistant<|message|>

    total = base_overhead
    for msg in messages:
        total += per_message_overhead
        # Count content
        content = msg.get("content", "")
        if isinstance(content, str):
            total += count_tokens(content, model)
        elif isinstance(content, list):
            # Multi-part content (text + images)
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    total += count_tokens(part.get("text", ""), model)
                elif isinstance(part, dict) and part.get("type") == "image_url":
                    # Images cost ~85 tokens for low detail, ~765 for high
                    detail = part.get("image_url", {}).get("detail", "auto")
                    total += 85 if detail == "low" else 765

        # Count role
        total += count_tokens(msg.get("role", ""), model)

        # Count name if present
        if "name" in msg:
            total += count_tokens(msg["name"], model) + 1  # +1 for name field

        # Count tool calls if present
        tool_calls = msg.get("tool_calls", [])
        for tc in tool_calls:
            if isinstance(tc, dict):
                fn = tc.get("function", {})
                total += count_tokens(fn.get("name", ""), model)
                total += count_tokens(fn.get("arguments", ""), model)
                total += 4  # tool call framing

    return total


def count_tool_tokens(tools: Sequence[dict], model: str = "gpt-4o") -> int:
    """Count tokens consumed by tool/function definitions.

    Tool definitions consume tokens from the context window.
    """
    if not tools:
        return 0

    import json

    # Tool definitions are serialized to the prompt -- count the JSON representation
    tools_text = json.dumps(tools, separators=(",", ":"))
    return count_tokens(tools_text, model)


def estimate_max_output_tokens(
    model: str,
    input_tokens: int,
    max_context: int | None = None,
) -> int:
    """Estimate remaining tokens available for output.

    Args:
        model: Model name.
        input_tokens: Tokens already consumed by input.
        max_context: Override for model's context window size.

    Returns:
        Estimated available output tokens.
    """
    if max_context is None:
        max_context = _get_context_window(model)

    remaining = max_context - input_tokens
    # Most models cap output at 4096-8192 even if context is larger
    model_lower = model.lower()
    if "claude" in model_lower:
        max_output = 8192
    elif "gpt-4o" in model_lower:
        max_output = 16384
    elif "gemini" in model_lower or "deepseek" in model_lower:
        max_output = 8192
    else:
        max_output = 4096

    return min(remaining, max_output)


def has_tiktoken() -> bool:
    """Check if tiktoken is available."""
    return _ensure_tiktoken()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _heuristic_count(text: str) -> int:
    """Improved heuristic token count when tiktoken is unavailable.

    Uses a more accurate model than simple word count:
    - English text: ~1.3 tokens per word
    - Code: ~1.5 tokens per word (more symbols)
    - CJK/Unicode: ~2 tokens per character
    """
    if not text:
        return 0

    # Detect if text is primarily code
    code_indicators = {
        "{", "}", "(", ")", ";", "=>", "->", "//", "/*", "def ", "class ", "import ",
    }
    is_code = sum(1 for ind in code_indicators if ind in text) >= 3

    # Count words
    words = text.split()
    word_count = len(words)

    # Count non-ASCII characters (CJK, emoji, etc.)
    non_ascii = sum(1 for c in text if ord(c) > 127)

    base = int(word_count * 1.5) if is_code else int(word_count * 1.3)

    # Add extra for non-ASCII
    base += non_ascii

    return max(1, base)


def _get_context_window(model: str) -> int:
    """Get the context window size for a model."""
    model_lower = model.lower()
    context_windows = {
        "claude-opus-4": 200000,
        "claude-sonnet-4": 200000,
        "claude-haiku-4": 200000,
        "claude-3.5": 200000,
        "claude-3-opus": 200000,
        "claude-3-sonnet": 200000,
        "claude-3-haiku": 200000,
        "gpt-4o": 128000,
        "gpt-4-turbo": 128000,
        "gpt-4": 8192,
        "gpt-3.5-turbo": 16385,
        "o1": 200000,
        "o3": 200000,
        "gemini-2": 1048576,
        "gemini-1.5-pro": 1048576,
        "gemini-1.5-flash": 1048576,
        "deepseek": 64000,
        "mistral": 32000,
        "llama": 131072,
    }
    for prefix, size in context_windows.items():
        if model_lower.startswith(prefix):
            return size
    return 8192  # Conservative default
