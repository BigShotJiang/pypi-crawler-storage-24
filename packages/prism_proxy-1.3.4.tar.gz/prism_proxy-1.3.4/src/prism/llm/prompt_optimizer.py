"""Prompt optimization engine — maximize quality while minimizing tokens.

Analyzes prompts and applies optimization strategies to improve response
quality and reduce token consumption.  This is not simple compression —
it's intelligent restructuring based on how LLMs process prompts.

Features:
    1. System prompt deduplication and distillation
    2. Example selection (pick most relevant few-shot examples)
    3. Instruction clarity scoring and improvement
    4. Token-aware prompt truncation (preserve high-signal content)
    5. Prompt template variable injection
    6. Multi-model prompt adaptation (different models prefer different styles)

Usage::

    optimizer = PromptOptimizer()
    optimized = optimizer.optimize(messages, model="gpt-4o", max_tokens=4000)
    score = optimizer.score_prompt(messages)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class PromptScore:
    """Quality assessment of a prompt.

    Attributes:
        overall: Overall quality score (0-1).
        clarity: How clear the instructions are.
        specificity: How specific the request is.
        conciseness: Token efficiency.
        structure: How well-structured the prompt is.
        issues: List of identified issues.
        suggestions: List of improvement suggestions.
        estimated_tokens: Estimated token count.
    """

    overall: float
    clarity: float
    specificity: float
    conciseness: float
    structure: float
    issues: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    estimated_tokens: int = 0


@dataclass
class OptimizationResult:
    """Result of prompt optimization.

    Attributes:
        messages: Optimized messages.
        original_tokens: Estimated original token count.
        optimized_tokens: Estimated optimized token count.
        savings_pct: Token savings percentage.
        changes_applied: List of optimizations applied.
    """

    messages: list[dict[str, str]]
    original_tokens: int
    optimized_tokens: int
    savings_pct: float
    changes_applied: list[str]


# ---------------------------------------------------------------------------
# Model-specific prompt style preferences
# ---------------------------------------------------------------------------

_MODEL_PREFERENCES: dict[str, dict[str, Any]] = {
    "gpt-4o": {
        "prefers_structured": True,
        "prefers_examples": True,
        "system_prompt_style": "concise",
        "max_system_tokens": 500,
    },
    "gpt-4o-mini": {
        "prefers_structured": True,
        "prefers_examples": True,
        "system_prompt_style": "detailed",
        "max_system_tokens": 300,
    },
    "claude": {
        "prefers_structured": True,
        "prefers_examples": False,
        "system_prompt_style": "natural",
        "max_system_tokens": 800,
    },
    "deepseek": {
        "prefers_structured": True,
        "prefers_examples": True,
        "system_prompt_style": "concise",
        "max_system_tokens": 400,
    },
}

# Filler phrases that add no value
_FILLER_PHRASES = [
    "please note that",
    "it is important to note that",
    "it should be noted that",
    "as mentioned above",
    "as previously stated",
    "in the context of",
    "it is worth mentioning that",
    "i would like you to",
    "could you please",
    "i need you to",
    "please make sure to",
    "please ensure that",
    "i want you to",
    "can you please",
]

# Redundant instruction patterns
_REDUNDANT_PATTERNS = [
    (re.compile(r"be concise and brief", re.I), "be concise"),
    (re.compile(r"short and concise", re.I), "concise"),
    (re.compile(r"respond in (a )?clear and concise (manner|way)", re.I), "respond concisely"),
    (re.compile(r"provide (a )?detailed and comprehensive", re.I), "provide comprehensive"),
    (re.compile(r"make sure (to |that )?you (always )?", re.I), ""),
]


class PromptOptimizer:
    """Intelligent prompt optimization engine.

    Analyzes and optimizes prompts for maximum quality and minimum tokens.
    """

    def __init__(self) -> None:
        self._word_approx_factor = 0.75  # Approx tokens per word

    def optimize(
        self,
        messages: list[dict[str, str]],
        model: str = "",
        max_tokens: int | None = None,
    ) -> OptimizationResult:
        """Optimize a prompt for a specific model.

        Args:
            messages: List of message dicts with "role" and "content".
            model: Target model identifier.
            max_tokens: Optional token budget for the prompt.

        Returns:
            OptimizationResult with optimized messages.
        """
        original_tokens = self._estimate_tokens(messages)
        changes: list[str] = []

        # Work on a copy
        optimized = [dict(m) for m in messages]

        # 1. Deduplicate system instructions
        optimized, dedup_changes = self._dedup_system(optimized)
        changes.extend(dedup_changes)

        # 2. Remove filler phrases
        optimized, filler_changes = self._remove_fillers(optimized)
        changes.extend(filler_changes)

        # 3. Collapse redundant patterns
        optimized, redundant_changes = self._collapse_redundant(optimized)
        changes.extend(redundant_changes)

        # 4. Collapse whitespace
        optimized = self._collapse_whitespace(optimized)

        # 5. Model-specific adaptation
        model_key = self._model_key(model)
        prefs = _MODEL_PREFERENCES.get(model_key, {})
        if prefs:
            optimized, model_changes = self._apply_model_prefs(optimized, prefs)
            changes.extend(model_changes)

        # 6. Token budget enforcement
        if max_tokens:
            optimized, budget_changes = self._enforce_budget(optimized, max_tokens)
            changes.extend(budget_changes)

        optimized_tokens = self._estimate_tokens(optimized)

        savings = (1 - optimized_tokens / original_tokens) * 100 if original_tokens > 0 else 0.0

        return OptimizationResult(
            messages=optimized,
            original_tokens=original_tokens,
            optimized_tokens=optimized_tokens,
            savings_pct=round(max(0, savings), 1),
            changes_applied=changes,
        )

    def score_prompt(self, messages: list[dict[str, str]]) -> PromptScore:
        """Score a prompt's quality.

        Args:
            messages: List of message dicts.

        Returns:
            PromptScore with quality assessment.
        """
        issues: list[str] = []
        suggestions: list[str] = []

        all_text = " ".join(m.get("content", "") for m in messages)
        tokens = self._estimate_tokens(messages)

        # Clarity: check for ambiguous instructions
        clarity = self._score_clarity(all_text, issues, suggestions)

        # Specificity: check for vague requests
        specificity = self._score_specificity(all_text, issues, suggestions)

        # Conciseness: token efficiency
        conciseness = self._score_conciseness(messages, issues, suggestions)

        # Structure: check message organization
        structure = self._score_structure(messages, issues, suggestions)

        overall = (clarity * 0.3 + specificity * 0.3 + conciseness * 0.2 + structure * 0.2)

        return PromptScore(
            overall=round(overall, 3),
            clarity=round(clarity, 3),
            specificity=round(specificity, 3),
            conciseness=round(conciseness, 3),
            structure=round(structure, 3),
            issues=issues,
            suggestions=suggestions,
            estimated_tokens=tokens,
        )

    def merge_system_messages(
        self, messages: list[dict[str, str]],
    ) -> list[dict[str, str]]:
        """Merge multiple system messages into one.

        Args:
            messages: List of messages.

        Returns:
            Messages with system messages merged.
        """
        system_parts: list[str] = []
        non_system: list[dict[str, str]] = []

        for msg in messages:
            if msg.get("role") == "system":
                content = msg.get("content", "").strip()
                if content:
                    system_parts.append(content)
            else:
                non_system.append(msg)

        result: list[dict[str, str]] = []
        if system_parts:
            merged = "\n\n".join(system_parts)
            result.append({"role": "system", "content": merged})
        result.extend(non_system)

        return result

    def add_output_format(
        self,
        messages: list[dict[str, str]],
        format_type: str = "json",
        schema: dict[str, Any] | None = None,
    ) -> list[dict[str, str]]:
        """Add output format instructions to the prompt.

        Args:
            messages: Current messages.
            format_type: Desired output format ("json", "markdown", "code").
            schema: Optional JSON schema for structured output.

        Returns:
            Messages with format instructions appended.
        """
        result = [dict(m) for m in messages]

        if format_type == "json":
            instruction = "Respond with valid JSON only. No markdown, no explanation."
            if schema:
                props = schema.get("properties", {})
                if props:
                    fields = ", ".join(f'"{k}": {v.get("type", "any")}' for k, v in props.items())
                    instruction += f" Format: {{{fields}}}"
        elif format_type == "markdown":
            instruction = "Format your response in markdown with appropriate headers and structure."
        elif format_type == "code":
            instruction = "Respond with code only. Use appropriate code blocks with language tags."
        else:
            instruction = f"Format your response as {format_type}."

        # Append to last user message or add as system message
        if result and result[-1].get("role") == "user":
            result[-1] = dict(result[-1])
            result[-1]["content"] = result[-1].get("content", "") + f"\n\n{instruction}"
        else:
            result.append({"role": "system", "content": instruction})

        return result

    # ------------------------------------------------------------------
    # Internal optimization methods
    # ------------------------------------------------------------------

    def _dedup_system(
        self, messages: list[dict[str, str]],
    ) -> tuple[list[dict[str, str]], list[str]]:
        """Deduplicate system message content."""
        changes: list[str] = []
        system_msgs = [m for m in messages if m.get("role") == "system"]

        if len(system_msgs) <= 1:
            return messages, changes

        # Merge duplicate system messages
        merged = self.merge_system_messages(messages)
        if len(merged) < len(messages):
            changes.append(f"Merged {len(system_msgs)} system messages into 1")

        return merged, changes

    def _remove_fillers(
        self, messages: list[dict[str, str]],
    ) -> tuple[list[dict[str, str]], list[str]]:
        """Remove filler phrases."""
        changes: list[str] = []
        result = []

        for msg in messages:
            content = msg.get("content", "")
            original = content
            for filler in _FILLER_PHRASES:
                content = re.sub(re.escape(filler), "", content, flags=re.IGNORECASE)

            if content != original:
                changes.append("Removed filler phrases")
                result.append({**msg, "content": content})
            else:
                result.append(msg)

        return result, changes

    def _collapse_redundant(
        self, messages: list[dict[str, str]],
    ) -> tuple[list[dict[str, str]], list[str]]:
        """Collapse redundant instruction patterns."""
        changes: list[str] = []
        result = []

        for msg in messages:
            content = msg.get("content", "")
            original = content
            for pattern, replacement in _REDUNDANT_PATTERNS:
                content = pattern.sub(replacement, content)

            if content != original:
                changes.append("Collapsed redundant instructions")
                result.append({**msg, "content": content})
            else:
                result.append(msg)

        return result, changes

    def _collapse_whitespace(
        self, messages: list[dict[str, str]],
    ) -> list[dict[str, str]]:
        """Collapse excessive whitespace."""
        result = []
        for msg in messages:
            content = msg.get("content", "")
            # Collapse multiple blank lines to double
            content = re.sub(r"\n{3,}", "\n\n", content)
            # Collapse multiple spaces
            content = re.sub(r"  +", " ", content)
            result.append({**msg, "content": content.strip()})
        return result

    def _apply_model_prefs(
        self,
        messages: list[dict[str, str]],
        prefs: dict[str, Any],
    ) -> tuple[list[dict[str, str]], list[str]]:
        """Apply model-specific preferences."""
        changes: list[str] = []
        result = list(messages)

        max_sys_tokens = prefs.get("max_system_tokens", 500)
        for i, msg in enumerate(result):
            if msg.get("role") == "system":
                content = msg.get("content", "")
                est_tokens = int(len(content.split()) * self._word_approx_factor)
                if est_tokens > max_sys_tokens:
                    # Truncate system prompt to budget
                    words = content.split()
                    max_words = int(max_sys_tokens / self._word_approx_factor)
                    truncated = " ".join(words[:max_words])
                    result[i] = {**msg, "content": truncated}
                    changes.append(f"Truncated system prompt to ~{max_sys_tokens} tokens")

        return result, changes

    def _enforce_budget(
        self,
        messages: list[dict[str, str]],
        max_tokens: int,
    ) -> tuple[list[dict[str, str]], list[str]]:
        """Enforce token budget by truncating oldest messages."""
        changes: list[str] = []
        current = self._estimate_tokens(messages)

        if current <= max_tokens:
            return messages, changes

        result = list(messages)

        # Keep system and last user message, truncate middle
        while self._estimate_tokens(result) > max_tokens and len(result) > 2:
            # Remove oldest non-system message
            for i, msg in enumerate(result):
                if msg.get("role") != "system" and i < len(result) - 1:
                    result.pop(i)
                    changes.append("Removed oldest message to fit budget")
                    break
            else:
                break

        return result, changes

    # ------------------------------------------------------------------
    # Scoring methods
    # ------------------------------------------------------------------

    def _score_clarity(
        self, text: str, issues: list[str], suggestions: list[str],
    ) -> float:
        """Score instruction clarity."""
        score = 0.8  # Base score

        # Penalize vague language
        vague_words = ["maybe", "perhaps", "somehow", "something", "stuff", "things", "etc"]
        vague_count = sum(1 for w in vague_words if f" {w} " in f" {text.lower()} ")
        if vague_count > 0:
            score -= 0.1 * min(vague_count, 3)
            issues.append(f"Found {vague_count} vague word(s)")
            suggestions.append("Replace vague words with specific terms")

        # Reward explicit instructions
        if any(w in text.lower() for w in ["must", "should", "always", "never"]):
            score += 0.1

        # Reward examples
        if "example" in text.lower() or "e.g." in text.lower() or "for instance" in text.lower():
            score += 0.1

        return min(1.0, max(0.0, score))

    def _score_specificity(
        self, text: str, issues: list[str], suggestions: list[str],
    ) -> float:
        """Score request specificity."""
        score = 0.7

        words = text.split()
        if len(words) < 5:
            score -= 0.3
            issues.append("Prompt is very short")
            suggestions.append("Add more context and specific requirements")
        elif len(words) < 15:
            score -= 0.1
            issues.append("Prompt could be more detailed")

        # Check for output format specification
        if any(w in text.lower() for w in ["json", "markdown", "format", "structure"]):
            score += 0.1

        # Check for constraints
        if any(w in text.lower() for w in ["maximum", "minimum", "limit", "constraint", "must not"]):
            score += 0.1

        return min(1.0, max(0.0, score))

    def _score_conciseness(
        self,
        messages: list[dict[str, str]],
        issues: list[str],
        suggestions: list[str],
    ) -> float:
        """Score token efficiency."""
        tokens = self._estimate_tokens(messages)

        if tokens < 10:
            return 0.5
        if tokens > 8000:
            issues.append("Prompt is very long (>8000 tokens)")
            suggestions.append("Consider removing redundant instructions")
            return 0.3
        if tokens > 4000:
            issues.append("Prompt is long (>4000 tokens)")
            return 0.5

        # Check for filler content
        all_text = " ".join(m.get("content", "") for m in messages).lower()
        filler_count = sum(1 for f in _FILLER_PHRASES if f in all_text)
        if filler_count > 0:
            issues.append(f"Contains {filler_count} filler phrase(s)")
            suggestions.append("Remove unnecessary filler phrases")
            return max(0.3, 0.8 - filler_count * 0.1)

        return 0.8

    def _score_structure(
        self,
        messages: list[dict[str, str]],
        issues: list[str],
        suggestions: list[str],
    ) -> float:
        """Score message structure."""
        score = 0.7

        # Check for system message
        has_system = any(m.get("role") == "system" for m in messages)
        if has_system:
            score += 0.1

        # Check for proper turn-taking
        roles = [m.get("role") for m in messages]
        if roles and roles[-1] == "user":
            score += 0.1  # Good: ends with user message

        # Penalize multiple consecutive same-role messages (except system)
        for i in range(1, len(roles)):
            if roles[i] == roles[i - 1] and roles[i] != "system":
                score -= 0.1
                issues.append("Consecutive messages with same role")
                break

        return min(1.0, max(0.0, score))

    def _estimate_tokens(self, messages: list[dict[str, str]]) -> int:
        """Estimate total tokens in messages."""
        total_words = sum(
            len(m.get("content", "").split()) for m in messages
        )
        # Add overhead for message formatting
        overhead = len(messages) * 4
        return int(total_words * self._word_approx_factor) + overhead

    def _model_key(self, model: str) -> str:
        """Normalize model name to a key for preferences lookup."""
        lower = model.lower()
        if "gpt-4o-mini" in lower:
            return "gpt-4o-mini"
        if "gpt-4o" in lower or "gpt-4" in lower:
            return "gpt-4o"
        if "claude" in lower:
            return "claude"
        if "deepseek" in lower:
            return "deepseek"
        return ""
