"""Model performance profiling — learn from every request.

Maintains detailed performance profiles for every model used, enabling
data-driven routing decisions based on actual measured performance rather
than static assumptions.

Features:
    1. Per-model latency distributions (P50/P75/P90/P95/P99)
    2. Per-model quality distributions
    3. Per-model error rate tracking
    4. Time-of-day performance patterns
    5. Task-type affinity scoring
    6. Automatic model ranking across dimensions

Usage::

    profiler = ModelProfiler()
    profiler.record("gpt-4o", latency_ms=450, quality=0.85, tokens_out=200)
    profile = profiler.get_profile("gpt-4o")
    ranking = profiler.rank_models("code_generation")
"""

from __future__ import annotations

import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class PerformanceRecord:
    """A single performance measurement.

    Attributes:
        model: Model identifier.
        latency_ms: Response latency in milliseconds.
        quality_score: Quality assessment (0-1).
        tokens_in: Input tokens.
        tokens_out: Output tokens.
        cost_usd: Cost of this request.
        error: Whether this request errored.
        error_type: Type of error if any.
        task_type: Task classification.
        hour_of_day: Hour (0-23) when request was made.
        timestamp: Unix timestamp.
    """

    model: str
    latency_ms: float = 0.0
    quality_score: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    error: bool = False
    error_type: str = ""
    task_type: str = "general"
    hour_of_day: int = field(default_factory=lambda: time.localtime().tm_hour)
    timestamp: float = field(default_factory=time.time)


@dataclass
class LatencyProfile:
    """Latency distribution for a model.

    Attributes:
        p50: Median latency (ms).
        p75: 75th percentile.
        p90: 90th percentile.
        p95: 95th percentile.
        p99: 99th percentile.
        mean: Average latency.
        min_ms: Minimum observed latency.
        max_ms: Maximum observed latency.
        sample_count: Number of measurements.
    """

    p50: float
    p75: float
    p90: float
    p95: float
    p99: float
    mean: float
    min_ms: float
    max_ms: float
    sample_count: int


@dataclass
class QualityProfile:
    """Quality distribution for a model.

    Attributes:
        mean: Average quality score.
        median: Median quality score.
        std: Standard deviation.
        min_score: Minimum observed quality.
        max_score: Maximum observed quality.
        below_threshold_pct: Percentage of responses below 0.5 quality.
    """

    mean: float
    median: float
    std: float
    min_score: float
    max_score: float
    below_threshold_pct: float


@dataclass
class TaskAffinity:
    """How well a model performs on a specific task type.

    Attributes:
        task_type: The task type.
        avg_quality: Average quality for this task.
        avg_latency_ms: Average latency for this task.
        sample_count: Number of measurements.
        score: Composite affinity score (0-1, higher = better fit).
    """

    task_type: str
    avg_quality: float
    avg_latency_ms: float
    sample_count: int
    score: float


@dataclass
class ModelProfile:
    """Complete performance profile for a model.

    Attributes:
        model: Model identifier.
        total_requests: Total requests recorded.
        error_rate: Fraction of requests that errored.
        latency: Latency distribution.
        quality: Quality distribution.
        task_affinities: Performance by task type.
        hourly_latency: Average latency by hour of day.
        avg_cost_per_request: Average cost.
        tokens_per_second: Average output throughput.
        last_updated: Timestamp of last update.
    """

    model: str
    total_requests: int
    error_rate: float
    latency: LatencyProfile
    quality: QualityProfile
    task_affinities: list[TaskAffinity]
    hourly_latency: dict[int, float]
    avg_cost_per_request: float
    tokens_per_second: float
    last_updated: float


@dataclass
class ModelRanking:
    """Ranking of a model for a specific task type.

    Attributes:
        model: Model identifier.
        overall_score: Composite ranking score (0-1).
        quality_score: Quality component.
        speed_score: Speed component.
        cost_score: Cost efficiency component.
        reliability_score: Error rate component.
        sample_count: Measurements backing this ranking.
    """

    model: str
    overall_score: float
    quality_score: float
    speed_score: float
    cost_score: float
    reliability_score: float
    sample_count: int


class ModelProfiler:
    """Performance profiling engine for AI models.

    Records performance measurements and builds detailed profiles
    that enable data-driven model selection.

    Args:
        max_records_per_model: Maximum records to keep per model (FIFO).
        quality_weight: Weight for quality in composite scores.
        speed_weight: Weight for speed in composite scores.
        cost_weight: Weight for cost in composite scores.
        reliability_weight: Weight for reliability in composite scores.
    """

    def __init__(
        self,
        max_records_per_model: int = 1000,
        quality_weight: float = 0.4,
        speed_weight: float = 0.2,
        cost_weight: float = 0.25,
        reliability_weight: float = 0.15,
    ) -> None:
        self._records: dict[str, list[PerformanceRecord]] = defaultdict(list)
        self._max_records = max_records_per_model
        self._weights = {
            "quality": quality_weight,
            "speed": speed_weight,
            "cost": cost_weight,
            "reliability": reliability_weight,
        }

    def record(
        self,
        model: str,
        latency_ms: float = 0.0,
        quality_score: float = 0.0,
        tokens_in: int = 0,
        tokens_out: int = 0,
        cost_usd: float = 0.0,
        error: bool = False,
        error_type: str = "",
        task_type: str = "general",
    ) -> PerformanceRecord:
        """Record a performance measurement.

        Args:
            model: Model identifier.
            latency_ms: Response latency.
            quality_score: Quality assessment.
            tokens_in: Input tokens used.
            tokens_out: Output tokens generated.
            cost_usd: Cost of request.
            error: Whether request errored.
            error_type: Error classification.
            task_type: Task type classification.

        Returns:
            The recorded PerformanceRecord.
        """
        rec = PerformanceRecord(
            model=model,
            latency_ms=latency_ms,
            quality_score=quality_score,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            cost_usd=cost_usd,
            error=error,
            error_type=error_type,
            task_type=task_type,
        )

        records = self._records[model]
        records.append(rec)

        # FIFO eviction
        if len(records) > self._max_records:
            self._records[model] = records[-self._max_records:]

        return rec

    def get_profile(self, model: str) -> ModelProfile | None:
        """Get the complete performance profile for a model.

        Args:
            model: Model identifier.

        Returns:
            ModelProfile or None if no data.
        """
        records = self._records.get(model)
        if not records:
            return None

        successful = [r for r in records if not r.error]
        error_rate = sum(1 for r in records if r.error) / len(records)

        latencies = [r.latency_ms for r in successful if r.latency_ms > 0]
        qualities = [r.quality_score for r in successful if r.quality_score > 0]
        costs = [r.cost_usd for r in successful if r.cost_usd > 0]

        latency_profile = self._compute_latency_profile(latencies)
        quality_profile = self._compute_quality_profile(qualities)
        task_affinities = self._compute_task_affinities(successful)
        hourly = self._compute_hourly_latency(successful)

        # Throughput
        throughput_records = [r for r in successful if r.latency_ms > 0 and r.tokens_out > 0]
        if throughput_records:
            tps = _safe_mean([
                r.tokens_out / (r.latency_ms / 1000) for r in throughput_records
            ])
        else:
            tps = 0.0

        return ModelProfile(
            model=model,
            total_requests=len(records),
            error_rate=round(error_rate, 4),
            latency=latency_profile,
            quality=quality_profile,
            task_affinities=task_affinities,
            hourly_latency=hourly,
            avg_cost_per_request=round(_safe_mean(costs), 6),
            tokens_per_second=round(tps, 1),
            last_updated=records[-1].timestamp,
        )

    def rank_models(
        self,
        task_type: str = "general",
        min_samples: int = 5,
    ) -> list[ModelRanking]:
        """Rank all profiled models for a specific task type.

        Args:
            task_type: Task type to rank for.
            min_samples: Minimum samples required to rank a model.

        Returns:
            List of ModelRanking sorted by overall_score (best first).
        """
        rankings: list[ModelRanking] = []

        # Collect stats for normalization
        all_qualities: list[float] = []
        all_latencies: list[float] = []
        all_costs: list[float] = []

        model_stats: dict[str, dict[str, Any]] = {}

        for model, records in self._records.items():
            task_records = [r for r in records if r.task_type == task_type and not r.error]
            if not task_records:
                task_records = [r for r in records if not r.error]
            if len(task_records) < min_samples:
                continue

            qualities = [r.quality_score for r in task_records if r.quality_score > 0]
            latencies = [r.latency_ms for r in task_records if r.latency_ms > 0]
            costs = [r.cost_usd for r in task_records if r.cost_usd > 0]
            error_count = sum(1 for r in records if r.error)

            avg_q = _safe_mean(qualities)
            avg_l = _safe_mean(latencies)
            avg_c = _safe_mean(costs)
            err_rate = error_count / max(len(records), 1)

            all_qualities.append(avg_q)
            all_latencies.append(avg_l)
            all_costs.append(avg_c)

            model_stats[model] = {
                "quality": avg_q,
                "latency": avg_l,
                "cost": avg_c,
                "error_rate": err_rate,
                "samples": len(task_records),
            }

        if not model_stats:
            return []

        # Normalize to 0-1 range
        max_q = max(all_qualities) if all_qualities else 1.0
        max_l = max(all_latencies) if all_latencies else 1.0
        max_c = max(all_costs) if all_costs else 1.0

        for model, stats in model_stats.items():
            q_score = stats["quality"] / max(max_q, 0.001)
            s_score = 1.0 - (stats["latency"] / max(max_l, 0.001))  # Lower is better
            c_score = 1.0 - (stats["cost"] / max(max_c, 0.001))  # Lower is better
            r_score = 1.0 - stats["error_rate"]

            overall = (
                self._weights["quality"] * q_score
                + self._weights["speed"] * s_score
                + self._weights["cost"] * c_score
                + self._weights["reliability"] * r_score
            )

            rankings.append(ModelRanking(
                model=model,
                overall_score=round(overall, 4),
                quality_score=round(q_score, 4),
                speed_score=round(s_score, 4),
                cost_score=round(c_score, 4),
                reliability_score=round(r_score, 4),
                sample_count=stats["samples"],
            ))

        rankings.sort(key=lambda r: r.overall_score, reverse=True)
        return rankings

    def get_best_model(
        self,
        task_type: str = "general",
        min_samples: int = 5,
    ) -> str | None:
        """Get the best-ranked model for a task type.

        Args:
            task_type: Task type to optimize for.
            min_samples: Minimum samples to consider a model.

        Returns:
            Model identifier or None if insufficient data.
        """
        rankings = self.rank_models(task_type=task_type, min_samples=min_samples)
        return rankings[0].model if rankings else None

    def get_all_models(self) -> list[str]:
        """Get all profiled model names."""
        return list(self._records.keys())

    def get_record_count(self, model: str) -> int:
        """Get number of records for a model."""
        return len(self._records.get(model, []))

    def clear(self, model: str | None = None) -> None:
        """Clear records for a model or all models.

        Args:
            model: Specific model to clear, or None for all.
        """
        if model:
            self._records.pop(model, None)
        else:
            self._records.clear()

    # ------------------------------------------------------------------
    # Internal computation
    # ------------------------------------------------------------------

    def _compute_latency_profile(self, latencies: list[float]) -> LatencyProfile:
        """Compute latency distribution."""
        if not latencies:
            return LatencyProfile(
                p50=0, p75=0, p90=0, p95=0, p99=0,
                mean=0, min_ms=0, max_ms=0, sample_count=0,
            )

        sorted_vals = sorted(latencies)
        n = len(sorted_vals)

        return LatencyProfile(
            p50=_pct(sorted_vals, 0.50),
            p75=_pct(sorted_vals, 0.75),
            p90=_pct(sorted_vals, 0.90),
            p95=_pct(sorted_vals, 0.95),
            p99=_pct(sorted_vals, 0.99),
            mean=round(_safe_mean(latencies), 1),
            min_ms=round(sorted_vals[0], 1),
            max_ms=round(sorted_vals[-1], 1),
            sample_count=n,
        )

    def _compute_quality_profile(self, qualities: list[float]) -> QualityProfile:
        """Compute quality distribution."""
        if not qualities:
            return QualityProfile(
                mean=0, median=0, std=0, min_score=0, max_score=0, below_threshold_pct=0,
            )

        sorted_vals = sorted(qualities)
        below = sum(1 for q in qualities if q < 0.5)

        return QualityProfile(
            mean=round(_safe_mean(qualities), 3),
            median=round(_pct(sorted_vals, 0.50), 3),
            std=round(_safe_std(qualities), 3),
            min_score=round(sorted_vals[0], 3),
            max_score=round(sorted_vals[-1], 3),
            below_threshold_pct=round(below / len(qualities) * 100, 1),
        )

    def _compute_task_affinities(
        self, records: list[PerformanceRecord],
    ) -> list[TaskAffinity]:
        """Compute per-task-type performance."""
        by_task: dict[str, list[PerformanceRecord]] = defaultdict(list)
        for r in records:
            by_task[r.task_type].append(r)

        affinities = []
        for task, task_records in by_task.items():
            qualities = [r.quality_score for r in task_records if r.quality_score > 0]
            latencies = [r.latency_ms for r in task_records if r.latency_ms > 0]

            avg_q = _safe_mean(qualities)
            avg_l = _safe_mean(latencies)

            # Composite score: quality-weighted, latency-penalized
            speed_factor = 1.0 / (1.0 + avg_l / 1000)  # Sigmoid-like
            score = avg_q * 0.7 + speed_factor * 0.3

            affinities.append(TaskAffinity(
                task_type=task,
                avg_quality=round(avg_q, 3),
                avg_latency_ms=round(avg_l, 1),
                sample_count=len(task_records),
                score=round(score, 3),
            ))

        affinities.sort(key=lambda a: a.score, reverse=True)
        return affinities

    def _compute_hourly_latency(
        self, records: list[PerformanceRecord],
    ) -> dict[int, float]:
        """Compute average latency by hour of day."""
        by_hour: dict[int, list[float]] = defaultdict(list)
        for r in records:
            if r.latency_ms > 0:
                by_hour[r.hour_of_day].append(r.latency_ms)

        return {
            hour: round(_safe_mean(latencies), 1)
            for hour, latencies in sorted(by_hour.items())
        }


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def _safe_mean(values: list[float]) -> float:
    """Mean with empty check."""
    return sum(values) / len(values) if values else 0.0


def _safe_std(values: list[float]) -> float:
    """Standard deviation with empty check."""
    if len(values) < 2:
        return 0.0
    mean = _safe_mean(values)
    variance = sum((x - mean) ** 2 for x in values) / (len(values) - 1)
    return math.sqrt(variance)


def _pct(sorted_values: list[float], percentile: float) -> float:
    """Compute percentile from sorted values."""
    if not sorted_values:
        return 0.0
    idx = int(len(sorted_values) * percentile)
    idx = min(idx, len(sorted_values) - 1)
    return round(sorted_values[idx], 1)
