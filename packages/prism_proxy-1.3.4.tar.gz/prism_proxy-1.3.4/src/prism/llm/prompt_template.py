"""Prompt template engine — typed, composable prompt templates.

A type-safe prompt templating system that supports variable interpolation,
conditional sections, model-specific adaptations, and template inheritance.
Prevents prompt injection and validates all variables before rendering.

Features:
    1. Variable interpolation with type validation
    2. Conditional sections (if/unless blocks)
    3. Model-specific template variants
    4. Template inheritance (base templates + overrides)
    5. Built-in prompt injection protection
    6. Template composition (chain multiple templates)
    7. Token budget enforcement (truncate long variables)
    8. Template versioning
    9. Built-in system/user/assistant role templates
    10. Template registry for reuse

Usage::

    registry = TemplateRegistry()
    registry.register(PromptTemplate(
        name="code_review",
        template="Review this {{language}} code:\\n```{{language}}\\n{{code}}\\n```",
        variables={"language": TemplateVar("language", str), "code": TemplateVar("code", str)},
    ))
    result = registry.render("code_review", language="python", code="def foo(): pass")

"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import Enum

import structlog

logger = structlog.get_logger(__name__)


# Variable interpolation pattern: {{variable_name}}
_VAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")

# Prompt injection indicators
_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?previous\s+instructions", re.IGNORECASE),
    re.compile(r"forget\s+(all\s+)?previous", re.IGNORECASE),
    re.compile(r"system\s*:\s*you\s+are", re.IGNORECASE),
    re.compile(r"<\|im_start\|>", re.IGNORECASE),
    re.compile(r"<\|endoftext\|>", re.IGNORECASE),
    re.compile(r"\[INST\]", re.IGNORECASE),
]

# Conditional block pattern: {{#if var}}...{{/if}} and {{#unless var}}...{{/unless}}
_IF_PATTERN = re.compile(
    r"\{\{#if\s+(\w+)\}\}(.*?)\{\{/if\}\}", re.DOTALL,
)
_UNLESS_PATTERN = re.compile(
    r"\{\{#unless\s+(\w+)\}\}(.*?)\{\{/unless\}\}", re.DOTALL,
)
_EACH_PATTERN = re.compile(
    r"\{\{#each\s+(\w+)\}\}(.*?)\{\{/each\}\}", re.DOTALL,
)


class VarType(Enum):
    """Supported variable types."""

    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    LIST = "list"


@dataclass
class TemplateVar:
    """Template variable definition.

    Attributes:
        name: Variable name.
        var_type: Expected type.
        required: Whether the variable must be provided.
        default: Default value if not provided.
        max_length: Maximum character length (for strings).
        description: Human-readable description.
        sanitize: Whether to check for prompt injection.
    """

    name: str
    var_type: VarType = VarType.STRING
    required: bool = True
    default: str = ""
    max_length: int = 0
    description: str = ""
    sanitize: bool = True


@dataclass
class RenderResult:
    """Result of template rendering.

    Attributes:
        text: Rendered template text.
        template_name: Name of the template.
        variables_used: Variables that were interpolated.
        estimated_tokens: Rough token estimate.
        render_time_ms: Time to render in milliseconds.
        warnings: Any warnings during rendering.
        truncated_vars: Variables that were truncated.
    """

    text: str
    template_name: str = ""
    variables_used: list[str] = field(default_factory=list)
    estimated_tokens: int = 0
    render_time_ms: float = 0.0
    warnings: list[str] = field(default_factory=list)
    truncated_vars: list[str] = field(default_factory=list)


@dataclass
class PromptTemplate:
    """A prompt template with typed variables.

    Attributes:
        name: Template name/identifier.
        template: Template string with {{variable}} placeholders.
        variables: Variable definitions.
        description: Human-readable description.
        version: Template version string.
        role: Message role (system, user, assistant).
        model_variants: Model-specific template overrides.
        parent: Parent template name for inheritance.
        tags: Tags for categorization.
    """

    name: str
    template: str
    variables: dict[str, TemplateVar] = field(default_factory=dict)
    description: str = ""
    version: str = "1.0"
    role: str = "user"
    model_variants: dict[str, str] = field(default_factory=dict)
    parent: str = ""
    tags: list[str] = field(default_factory=list)

    def get_template_for_model(self, model: str) -> str:
        """Get the template variant for a specific model.

        Args:
            model: Model identifier.

        Returns:
            Model-specific template or the default.
        """
        # Check exact match first
        if model in self.model_variants:
            return self.model_variants[model]
        # Check prefix match (e.g., "gpt-4" matches "gpt-4o-mini")
        for prefix, variant in self.model_variants.items():
            if model.startswith(prefix):
                return variant
        return self.template

    def get_required_vars(self) -> list[str]:
        """Get names of all required variables."""
        return [v.name for v in self.variables.values() if v.required]

    def get_all_var_names(self) -> set[str]:
        """Get all variable names referenced in the template."""
        return set(_VAR_PATTERN.findall(self.template))


class TemplateRenderer:
    """Renders prompt templates with variable substitution.

    Args:
        check_injection: Whether to check for prompt injection in values.
        max_token_budget: Maximum tokens for rendered output (0 = unlimited).
    """

    def __init__(
        self,
        check_injection: bool = True,
        max_token_budget: int = 0,
    ) -> None:
        self._check_injection = check_injection
        self._max_token_budget = max_token_budget

    def render(
        self,
        template: PromptTemplate,
        model: str = "",
        **kwargs: str | int | float | bool | list[str],
    ) -> RenderResult:
        """Render a template with provided variables.

        Args:
            template: The template to render.
            model: Model to use for variant selection.
            **kwargs: Variable values.

        Returns:
            RenderResult with rendered text.

        Raises:
            ValueError: If required variables are missing or types don't match.
        """
        start = time.perf_counter()
        warnings: list[str] = []
        truncated: list[str] = []

        # Get the right template variant
        tmpl_str = template.get_template_for_model(model) if model else template.template

        # Validate required variables
        for var_name, var_def in template.variables.items():
            if var_def.required and var_name not in kwargs:
                if var_def.default:
                    kwargs[var_name] = var_def.default
                else:
                    msg = f"Required variable '{var_name}' not provided"
                    raise ValueError(msg)

        # Process conditional blocks
        tmpl_str = self._process_conditionals(tmpl_str, kwargs)

        # Process each blocks
        tmpl_str = self._process_each(tmpl_str, kwargs)

        # Validate and substitute variables
        variables_used: list[str] = []
        for match in _VAR_PATTERN.finditer(tmpl_str):
            var_name = match.group(1)
            if var_name not in kwargs:
                warnings.append(f"Variable '{var_name}' not provided, left as placeholder")
                continue

            value = kwargs[var_name]
            var_def = template.variables.get(var_name)

            # Type validation
            if var_def:
                self._validate_type(var_name, value, var_def)

            # Convert to string
            str_value = str(value)

            # Injection check
            if self._check_injection and var_def and var_def.sanitize:
                injection = self._check_for_injection(str_value)
                if injection:
                    warnings.append(
                        f"Potential prompt injection in '{var_name}': {injection}"
                    )

            # Truncation
            if var_def and var_def.max_length > 0 and len(str_value) > var_def.max_length:
                str_value = str_value[:var_def.max_length] + "..."
                truncated.append(var_name)

            tmpl_str = tmpl_str.replace(f"{{{{{var_name}}}}}", str_value)
            variables_used.append(var_name)

        # Token budget enforcement
        if self._max_token_budget > 0:
            est_tokens = self._estimate_tokens(tmpl_str)
            if est_tokens > self._max_token_budget:
                # Truncate at word boundary
                max_chars = self._max_token_budget * 4
                if len(tmpl_str) > max_chars:
                    tmpl_str = tmpl_str[:max_chars].rsplit(" ", 1)[0] + "..."
                    warnings.append("Output truncated to fit token budget")

        elapsed = (time.perf_counter() - start) * 1000

        return RenderResult(
            text=tmpl_str,
            template_name=template.name,
            variables_used=variables_used,
            estimated_tokens=self._estimate_tokens(tmpl_str),
            render_time_ms=elapsed,
            warnings=warnings,
            truncated_vars=truncated,
        )

    def _process_conditionals(
        self, template: str, values: dict[str, str | int | float | bool | list[str]],
    ) -> str:
        """Process {{#if var}}...{{/if}} and {{#unless var}}...{{/unless}} blocks."""

        def replace_if(match: re.Match[str]) -> str:
            var_name = match.group(1)
            content = match.group(2)
            val = values.get(var_name)
            if val and str(val).lower() not in ("false", "0", "", "none"):
                return content
            return ""

        def replace_unless(match: re.Match[str]) -> str:
            var_name = match.group(1)
            content = match.group(2)
            val = values.get(var_name)
            if not val or str(val).lower() in ("false", "0", "", "none"):
                return content
            return ""

        result = _IF_PATTERN.sub(replace_if, template)
        return _UNLESS_PATTERN.sub(replace_unless, result)

    def _process_each(
        self, template: str, values: dict[str, str | int | float | bool | list[str]],
    ) -> str:
        """Process {{#each var}}...{{/each}} blocks."""

        def replace_each(match: re.Match[str]) -> str:
            var_name = match.group(1)
            body = match.group(2)
            val = values.get(var_name)
            if not isinstance(val, list):
                return ""
            parts: list[str] = []
            for item in val:
                parts.append(body.replace("{{this}}", str(item)))
            return "".join(parts)

        return _EACH_PATTERN.sub(replace_each, template)

    def _validate_type(
        self, name: str, value: str | int | float | bool | list[str], var_def: TemplateVar,
    ) -> None:
        """Validate that a value matches the expected type."""
        type_map = {
            VarType.STRING: str,
            VarType.INTEGER: int,
            VarType.FLOAT: (int, float),
            VarType.BOOLEAN: bool,
            VarType.LIST: list,
        }
        expected = type_map.get(var_def.var_type)
        if expected and not isinstance(value, expected):
            msg = (
                f"Variable '{name}' expected type {var_def.var_type.value}, "
                f"got {type(value).__name__}"
            )
            raise TypeError(msg)

    def _check_for_injection(self, value: str) -> str:
        """Check if a value contains prompt injection patterns.

        Returns:
            Description of the injection pattern found, or empty string.
        """
        for pattern in _INJECTION_PATTERNS:
            if pattern.search(value):
                return f"matches pattern: {pattern.pattern}"
        return ""

    def _estimate_tokens(self, text: str) -> int:
        """Rough token estimate."""
        return max(1, int(len(text.split()) * 0.75))


class TemplateRegistry:
    """Registry for prompt templates.

    Manages template storage, lookup, and rendering.
    """

    def __init__(self, check_injection: bool = True) -> None:
        self._templates: dict[str, PromptTemplate] = {}
        self._renderer = TemplateRenderer(check_injection=check_injection)

    def register(self, template: PromptTemplate) -> None:
        """Register a template.

        Args:
            template: Template to register.
        """
        self._templates[template.name] = template
        logger.debug("template_registered", name=template.name, version=template.version)

    def unregister(self, name: str) -> bool:
        """Remove a template.

        Args:
            name: Template name.

        Returns:
            True if removed.
        """
        if name in self._templates:
            del self._templates[name]
            return True
        return False

    def get(self, name: str) -> PromptTemplate | None:
        """Get a template by name.

        Args:
            name: Template name.

        Returns:
            Template or None.
        """
        return self._templates.get(name)

    def render(
        self,
        template_name: str,
        target_model: str = "",
        **kwargs: str | int | float | bool | list[str],
    ) -> RenderResult:
        """Render a registered template.

        Args:
            template_name: Template name.
            target_model: Model for variant selection.
            **kwargs: Variable values.

        Returns:
            RenderResult.

        Raises:
            KeyError: If template not found.
        """
        template = self._templates.get(template_name)
        if template is None:
            msg = f"Template '{template_name}' not found"
            raise KeyError(msg)

        # Handle inheritance
        if template.parent:
            parent = self._templates.get(template.parent)
            if parent:
                template = self._resolve_inheritance(template, parent)

        return self._renderer.render(template, model=target_model, **kwargs)

    def list_templates(self, tag: str = "") -> list[str]:
        """List registered template names.

        Args:
            tag: Filter by tag (empty = all).

        Returns:
            List of template names.
        """
        if not tag:
            return list(self._templates.keys())
        return [
            name for name, tmpl in self._templates.items()
            if tag in tmpl.tags
        ]

    def _resolve_inheritance(
        self, child: PromptTemplate, parent: PromptTemplate,
    ) -> PromptTemplate:
        """Resolve template inheritance by merging parent and child."""
        # Merge variables (child overrides parent)
        merged_vars = dict(parent.variables)
        merged_vars.update(child.variables)

        # Merge model variants
        merged_variants = dict(parent.model_variants)
        merged_variants.update(child.model_variants)

        return PromptTemplate(
            name=child.name,
            template=child.template or parent.template,
            variables=merged_vars,
            description=child.description or parent.description,
            version=child.version,
            role=child.role or parent.role,
            model_variants=merged_variants,
            parent="",  # Already resolved
            tags=list({*parent.tags, *child.tags}),
        )


# ---------------------------------------------------------------------------
# Built-in templates
# ---------------------------------------------------------------------------


def create_builtin_templates() -> list[PromptTemplate]:
    """Create the built-in prompt templates.

    Returns:
        List of built-in templates.
    """
    return [
        PromptTemplate(
            name="code_review",
            template=(
                "Review the following {{language}} code for bugs, "
                "security issues, and best practices:\n"
                "```{{language}}\n{{code}}\n```\n"
                "{{#if focus}}Focus on: {{focus}}{{/if}}"
            ),
            variables={
                "language": TemplateVar("language", VarType.STRING),
                "code": TemplateVar("code", VarType.STRING, max_length=50000),
                "focus": TemplateVar("focus", VarType.STRING, required=False),
            },
            description="Code review prompt",
            tags=["code", "review"],
        ),
        PromptTemplate(
            name="explain_code",
            template=(
                "Explain this {{language}} code in detail:\n"
                "```{{language}}\n{{code}}\n```\n"
                "{{#if audience}}Explain for: {{audience}}{{/if}}"
            ),
            variables={
                "language": TemplateVar("language", VarType.STRING),
                "code": TemplateVar("code", VarType.STRING, max_length=50000),
                "audience": TemplateVar("audience", VarType.STRING, required=False),
            },
            description="Code explanation prompt",
            tags=["code", "explain"],
        ),
        PromptTemplate(
            name="summarize",
            template=(
                "Summarize the following text"
                "{{#if max_words}} in {{max_words}} words or fewer{{/if}}:\n\n"
                "{{text}}"
            ),
            variables={
                "text": TemplateVar("text", VarType.STRING, max_length=100000),
                "max_words": TemplateVar("max_words", VarType.STRING, required=False),
            },
            description="Text summarization prompt",
            tags=["text", "summary"],
        ),
        PromptTemplate(
            name="translate",
            template=(
                "Translate the following text from {{source_lang}} to "
                "{{target_lang}}:\n\n{{text}}"
            ),
            variables={
                "source_lang": TemplateVar("source_lang", VarType.STRING),
                "target_lang": TemplateVar("target_lang", VarType.STRING),
                "text": TemplateVar("text", VarType.STRING, max_length=50000),
            },
            description="Translation prompt",
            tags=["text", "translate"],
        ),
    ]
