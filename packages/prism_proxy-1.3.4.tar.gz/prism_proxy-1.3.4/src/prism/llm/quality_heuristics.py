"""Response quality heuristics — estimate quality without expensive judge calls.

The confidence cascade uses a separate LLM call to assess response quality.
This module provides fast, zero-cost heuristic quality estimation that can
replace or supplement judge calls for straightforward cases.

Heuristics:
    1. **Completeness**: Does the response contain expected structural elements?
       (code blocks, explanations, imports for code tasks)
    2. **Coherence**: Is the response internally consistent? (no contradictions,
       no mid-sentence cutoffs, balanced brackets)
    3. **Relevance**: Does the response address keywords from the prompt?
    4. **Hallucination markers**: Detect common hallucination patterns
       (made-up URLs, fake citations, confident-but-wrong patterns)
    5. **Code quality**: For code responses, check syntax validity, import
       consistency, and structural completeness.
    6. **Length adequacy**: Is the response length appropriate for the task?

Each heuristic returns a score between 0.0 and 1.0.  The final quality
score is a weighted combination, calibrated so that:
    - >= 0.85: High confidence, likely correct (skip judge call)
    - 0.60-0.84: Moderate confidence (consider judge call)
    - < 0.60: Low confidence (judge call recommended)
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import structlog

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Hallucination detection patterns
# ---------------------------------------------------------------------------

# Fake URLs that LLMs commonly hallucinate
_FAKE_URL_PATTERNS = [
    re.compile(r"https?://(?:www\.)?example\d*\.com/\S+"),
    re.compile(r"https?://docs\.(?:fake|example|placeholder)\.\S+"),
    re.compile(r"\[(?:source|reference|citation)\]\(https?://\S+\)"),
]

# "According to" + specific fake source
_FAKE_CITATION = re.compile(
    r"according to (?:the )?"
    r"(?:official documentation|research|studies|experts|sources)",
    re.IGNORECASE,
)

# Confident hedging — says "certainly" then hedges
_CONFIDENT_HEDGE = re.compile(
    r"(?:certainly|definitely|absolutely|obviously).*"
    r"(?:however|but|although|might|may|possibly)",
    re.IGNORECASE | re.DOTALL,
)

# Repeated phrases (model stuck in a loop)
_REPETITION = re.compile(r"(.{30,})\1{2,}")

# Mid-sentence cutoff markers
_CUTOFF_MARKERS = [
    re.compile(r"\w+$"),  # Ends mid-word (no punctuation)
    re.compile(r",\s*$"),  # Ends with trailing comma
    re.compile(r":\s*$"),  # Ends with colon (expecting content)
]

# Code structural patterns
_UNCLOSED_BRACKETS = {
    "{": "}",
    "[": "]",
    "(": ")",
}

# Common code block indicators
_CODE_FENCE = re.compile(r"```(\w*)\n([\s\S]*?)```")
_INLINE_CODE = re.compile(r"`[^`]+`")


@dataclass(frozen=True)
class QualityAssessment:
    """Heuristic quality assessment of a response.

    Attributes:
        overall_score: Combined quality score (0.0 to 1.0).
        completeness: Response structural completeness score.
        coherence: Internal consistency score.
        relevance: Prompt-response relevance score.
        hallucination_risk: Hallucination risk (0=none, 1=high risk).
        code_quality: Code structural quality (if code detected).
        length_adequacy: Response length appropriateness.
        issues: List of detected quality issues.
        skip_judge: Whether heuristics are confident enough to skip judge.
    """

    overall_score: float
    completeness: float
    coherence: float
    relevance: float
    hallucination_risk: float
    code_quality: float
    length_adequacy: float
    issues: list[str]
    skip_judge: bool


class QualityEstimator:
    """Fast, zero-cost quality estimation for LLM responses.

    Analyses response text using structural and linguistic heuristics
    to estimate quality without making additional API calls.

    Args:
        skip_judge_threshold: Minimum overall score to skip judge call.
        force_judge_threshold: Maximum overall score that forces a judge call.
    """

    def __init__(
        self,
        skip_judge_threshold: float = 0.85,
        force_judge_threshold: float = 0.60,
    ) -> None:
        self._skip_threshold = skip_judge_threshold
        self._force_threshold = force_judge_threshold

    def assess(self, response: str, prompt: str) -> QualityAssessment:
        """Assess response quality using heuristics.

        Args:
            response: The LLM's response text.
            prompt: The original user prompt.

        Returns:
            QualityAssessment with scores and recommendations.
        """
        issues: list[str] = []

        # Fast path: empty or whitespace-only response
        if not response or not response.strip():
            issues.append("Empty response")
            return QualityAssessment(
                overall_score=0.0,
                completeness=0.0,
                coherence=0.0,
                relevance=0.0,
                hallucination_risk=0.0,
                code_quality=0.0,
                length_adequacy=0.0,
                issues=issues,
                skip_judge=False,
            )

        completeness = self._check_completeness(response, prompt, issues)
        coherence = self._check_coherence(response, issues)
        relevance = self._check_relevance(response, prompt, issues)
        hallucination = self._check_hallucination(response, issues)
        code_quality = self._check_code_quality(response, issues)
        length_score = self._check_length(response, prompt, issues)

        # Weighted combination
        weights = {
            "completeness": 0.20,
            "coherence": 0.20,
            "relevance": 0.25,
            "hallucination": 0.15,
            "code_quality": 0.10,
            "length": 0.10,
        }

        # Hallucination is inverted (high = bad)
        hallucination_safe = 1.0 - hallucination

        overall = (
            completeness * weights["completeness"]
            + coherence * weights["coherence"]
            + relevance * weights["relevance"]
            + hallucination_safe * weights["hallucination"]
            + code_quality * weights["code_quality"]
            + length_score * weights["length"]
        )

        overall = max(0.0, min(1.0, overall))
        skip_judge = overall >= self._skip_threshold and not issues

        return QualityAssessment(
            overall_score=round(overall, 3),
            completeness=round(completeness, 3),
            coherence=round(coherence, 3),
            relevance=round(relevance, 3),
            hallucination_risk=round(hallucination, 3),
            code_quality=round(code_quality, 3),
            length_adequacy=round(length_score, 3),
            issues=issues,
            skip_judge=skip_judge,
        )

    # ------------------------------------------------------------------
    # Individual heuristics
    # ------------------------------------------------------------------

    def _check_completeness(
        self, response: str, prompt: str, issues: list[str]
    ) -> float:
        """Check if the response has expected structural elements."""
        if not response.strip():
            issues.append("Empty response")
            return 0.0

        score = 0.7  # Base score for non-empty

        prompt_lower = prompt.lower()
        has_code_request = any(
            kw in prompt_lower
            for kw in ("code", "implement", "write", "function", "class", "fix", "create")
        )

        if has_code_request:
            # Expect code blocks
            if _CODE_FENCE.search(response):
                score += 0.2
            elif _INLINE_CODE.search(response):
                score += 0.1
            else:
                score -= 0.1
                issues.append("Code request but no code blocks in response")

        # Check for explanation alongside code
        has_explanation = any(
            kw in prompt_lower for kw in ("explain", "why", "how", "describe")
        )
        if has_explanation and len(response.split()) < 30:
            score -= 0.1
            issues.append("Explanation request but response is very short")

        return max(0.0, min(1.0, score))

    def _check_coherence(self, response: str, issues: list[str]) -> float:
        """Check internal consistency of the response."""
        score = 1.0

        # Check for mid-sentence cutoff
        stripped = response.rstrip()
        if stripped and stripped[-1] not in ".!?`>)]:;\"'":
            last_line = stripped.split("\n")[-1].strip()
            if last_line and not last_line.startswith(("```", "---", "***", "- ", "* ")):
                score -= 0.15
                issues.append("Response may be truncated (no ending punctuation)")

        # Check for repetition
        if _REPETITION.search(response):
            score -= 0.3
            issues.append("Repetitive content detected")

        # Check bracket balance in code
        code_blocks = _CODE_FENCE.findall(response)
        for _, code in code_blocks:
            for open_br, close_br in _UNCLOSED_BRACKETS.items():
                if code.count(open_br) != code.count(close_br):
                    score -= 0.1
                    issues.append(f"Unbalanced {open_br}{close_br} in code block")
                    break

        return max(0.0, score)

    def _check_relevance(
        self, response: str, prompt: str, issues: list[str]
    ) -> float:
        """Check if the response addresses the prompt's key topics."""
        prompt_words = set(prompt.lower().split())
        response_words = set(response.lower().split())

        # Remove stop words
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "being", "have", "has", "had", "do", "does", "did", "will",
            "would", "could", "should", "may", "might", "can", "shall",
            "to", "of", "in", "for", "on", "with", "at", "by", "from",
            "it", "this", "that", "these", "those", "i", "you", "we",
            "they", "he", "she", "my", "your", "his", "her", "its",
            "and", "or", "but", "if", "then", "else", "when", "while",
            "not", "no", "so", "as", "than", "too", "very",
        }

        prompt_keywords = prompt_words - stop_words
        if not prompt_keywords:
            return 0.8  # Can't assess — neutral

        # What fraction of prompt keywords appear in response?
        overlap = prompt_keywords & response_words
        coverage = len(overlap) / len(prompt_keywords) if prompt_keywords else 0

        if coverage < 0.2:
            issues.append("Response addresses few keywords from the prompt")

        # Scale: 0 overlap → 0.1, full overlap → 1.0
        return min(1.0, 0.1 + coverage * 0.9)

    def _check_hallucination(
        self, response: str, issues: list[str]
    ) -> float:
        """Estimate hallucination risk.  Returns 0.0 (safe) to 1.0 (likely hallucinating)."""
        risk = 0.0

        for pattern in _FAKE_URL_PATTERNS:
            if pattern.search(response):
                risk += 0.2
                issues.append("Potentially hallucinated URL detected")
                break

        if _FAKE_CITATION.search(response):
            risk += 0.15

        if _CONFIDENT_HEDGE.search(response):
            risk += 0.1

        return min(1.0, risk)

    def _check_code_quality(
        self, response: str, issues: list[str]
    ) -> float:
        """Check structural quality of code blocks."""
        code_blocks = _CODE_FENCE.findall(response)
        if not code_blocks:
            return 0.8  # No code → neutral score

        total_score = 0.0
        for lang, code in code_blocks:
            block_score = 0.7

            # Check non-trivial content
            lines = [ln for ln in code.strip().split("\n") if ln.strip()]
            if len(lines) >= 3:
                block_score += 0.1

            # Check for imports in Python
            if lang in ("python", "py", "") and any(
                ln.strip().startswith(("import ", "from ")) for ln in lines
            ):
                block_score += 0.1

            # Check for function/class definitions
            if any(
                re.match(r"^\s*(?:def |class |function |const |let |var |async )", ln)
                for ln in lines
            ):
                block_score += 0.1

            total_score += min(1.0, block_score)

        return total_score / len(code_blocks)

    def _check_length(
        self, response: str, prompt: str, issues: list[str]
    ) -> float:
        """Check if response length is appropriate for the task."""
        response_words = len(response.split())
        prompt_words = len(prompt.split())

        if response_words == 0:
            return 0.0

        # Response-to-prompt word ratio — very short responses to detailed prompts
        ratio = response_words / max(1, prompt_words)

        # Very short response to a complex prompt (ratio < 0.5 and prompt is substantial)
        if prompt_words > 15 and ratio < 0.5 and response_words < 20:
            issues.append("Response seems too short for the prompt complexity")
            return 0.2

        # Short response to a moderately complex prompt
        if prompt_words > 30 and response_words < 15:
            issues.append("Response seems too short for the prompt complexity")
            return 0.3

        # Extremely long response to a simple prompt
        if prompt_words < 20 and response_words > 2000:
            issues.append("Response seems excessively long for a simple prompt")
            return 0.6

        return 0.9  # Most lengths are fine


def quick_quality_check(response: str, prompt: str) -> float:
    """Quick quality score for use in routing decisions.

    Returns a score between 0.0 and 1.0.

    Args:
        response: LLM response text.
        prompt: Original prompt text.

    Returns:
        Quality estimate.
    """
    estimator = QualityEstimator()
    assessment = estimator.assess(response, prompt)
    return assessment.overall_score
