"""Automatic response quality evaluation engine.

Evaluates LLM responses across multiple quality dimensions — relevance,
completeness, coherence, conciseness, and correctness — using lightweight
heuristics that require no external API calls.

Features:
    1. **Multi-dimensional scoring**: Relevance, completeness, coherence,
       conciseness, and correctness each scored 0.0-1.0.
    2. **Prompt-response alignment**: Keyword overlap and TF-IDF weighting
       to measure how well a response addresses the prompt.
    3. **Code quality assessment**: Syntax error detection, TODO/FIXME
       markers, import completeness checks.
    4. **Hallucination indicators**: Confidence phrases, contradiction
       detection, hedging patterns.
    5. **Response length analysis**: Too short = incomplete, too long =
       verbose, with task-appropriate expectations.
    6. **Format compliance checking**: Validates whether the response
       matches the requested output format.
    7. **Comparative quality scoring**: Compare two responses to the same
       prompt and determine a winner per dimension.
    8. **Quality history tracking**: Per-model quality statistics with
       trend detection over a sliding window.
    9. **Configurable scoring weights**: Fully tunable dimension weights
       and detection thresholds.
    10. **Quality-based reward signals**: Emits reward scores suitable
        for adaptive routing decisions.

Usage::

    evaluator = QualityEvaluator()
    score = evaluator.evaluate("prompt text", "response text")
    print(score.overall, score.relevance, score.issues)

    # Compare two responses
    comparison = evaluator.compare("prompt", "response A", "response B")
    print(comparison.winner, comparison.margin)

    # Track model quality
    evaluator.record_quality("gpt-4o", score)
    history = evaluator.get_model_history("gpt-4o")
    print(history.avg_score, history.trend)
"""

from __future__ import annotations

import ast
import json
import math
import re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum

import structlog

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_STOP_WORDS: frozenset[str] = frozenset({
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "it", "this", "that", "these",
    "those", "i", "you", "we", "they", "he", "she", "my", "your", "his",
    "her", "its", "and", "or", "but", "if", "then", "else", "when",
    "while", "not", "no", "so", "as", "than", "too", "very", "just",
    "about", "up", "out", "what", "how", "which", "who", "where", "why",
    "all", "each", "every", "both", "few", "more", "most", "other",
    "some", "such", "only", "own", "same", "also", "into", "over",
    "after", "before", "between", "through", "during", "above", "below",
    "any", "there", "here", "me", "him", "them", "us",
})

_CODE_FENCE_RE = re.compile(r"```(\w*)\n([\s\S]*?)```")

# Hallucination confidence phrases
_CONFIDENCE_PHRASES: list[re.Pattern[str]] = [
    re.compile(
        r"\bI am (?:100%|absolutely|completely) (?:sure|certain|confident)\b",
        re.IGNORECASE,
    ),
    re.compile(r"\bwithout (?:a )?doubt\b", re.IGNORECASE),
    re.compile(r"\bthere is no question\b", re.IGNORECASE),
    re.compile(r"\bI guarantee\b", re.IGNORECASE),
]

# Contradiction patterns (says X then says not X)
_CONTRADICTION_PAIRS: list[tuple[re.Pattern[str], re.Pattern[str]]] = [
    (
        re.compile(r"\bis (?:always|never)\b", re.IGNORECASE),
        re.compile(r"\bis (?:sometimes|not always|not never)\b", re.IGNORECASE),
    ),
    (
        re.compile(r"\byou (?:should|must)\b", re.IGNORECASE),
        re.compile(
            r"\byou (?:should not|must not|shouldn't|mustn't)\b", re.IGNORECASE,
        ),
    ),
    (re.compile(r"\byes\b", re.IGNORECASE), re.compile(r"\bno\b", re.IGNORECASE)),
]

# Hedge words that weaken confidence
_HEDGE_WORDS: list[str] = [
    "maybe", "perhaps", "possibly", "might", "could be",
    "I think", "I believe", "not sure", "not certain",
    "it seems", "it appears", "arguably", "supposedly",
]

# Markers that indicate incomplete code (todo, fixme, etc.)
_TODO_FIXME_RE = re.compile(r"\b(?:TODO|FIXME|HACK|XXX|TEMP)\b", re.IGNORECASE)

# Format-specific validators
_MARKDOWN_INDICATORS = re.compile(
    r"(?:^#{1,6}\s|\*\*|__|\[.*\]\(.*\)|```)", re.MULTILINE,
)
_LIST_INDICATOR = re.compile(r"^(?:\d+\.|[-*+])\s", re.MULTILINE)

# Bracket pairs for balance checking
_BRACKET_PAIRS: dict[str, str] = {"{": "}", "[": "]", "(": ")"}


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class IssueSeverity(Enum):
    """Severity level for detected quality issues."""

    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


class QualityDimension(Enum):
    """Quality dimension that an issue belongs to."""

    RELEVANCE = "relevance"
    COMPLETENESS = "completeness"
    COHERENCE = "coherence"
    CONCISENESS = "conciseness"
    CORRECTNESS = "correctness"


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class QualityIssue:
    """A detected quality issue in a response.

    Attributes:
        severity: How severe the issue is.
        dimension: Which quality dimension is affected.
        description: Human-readable description of the issue.
        location: Where in the response the issue was found.
    """

    severity: IssueSeverity
    dimension: QualityDimension
    description: str
    location: str = ""


@dataclass(frozen=True)
class QualityScore:
    """Multi-dimensional quality scores for a response.

    All dimension scores range from 0.0 (worst) to 1.0 (best).

    Attributes:
        relevance: How well the response addresses the prompt.
        completeness: Whether the response fully answers the question.
        coherence: Logical consistency and structural integrity.
        conciseness: Whether response length is appropriate (not verbose).
        correctness: Format/syntax correctness (code, JSON, etc.).
        overall: Weighted combination of all dimensions.
        issues: All detected quality issues.
        reward_signal: Score suitable for adaptive routing (0.0-1.0).
        evaluated_at: Unix timestamp of evaluation.
    """

    relevance: float
    completeness: float
    coherence: float
    conciseness: float
    correctness: float
    overall: float
    issues: tuple[QualityIssue, ...] = ()
    reward_signal: float = 0.0
    evaluated_at: float = 0.0


@dataclass(frozen=True)
class QualityComparison:
    """Result of comparing two responses to the same prompt.

    Attributes:
        winner: Which response is better ("a", "b", or "tie").
        margin: How much better the winner is (0.0-1.0).
        score_a: Quality score for response A.
        score_b: Quality score for response B.
        dimension_winners: Per-dimension winner mapping.
    """

    winner: str
    margin: float
    score_a: QualityScore
    score_b: QualityScore
    dimension_winners: dict[str, str] = field(default_factory=dict)


@dataclass
class ModelQualityHistory:
    """Per-model quality tracking over time.

    Attributes:
        model: Model identifier.
        avg_score: Rolling average overall score.
        trend: Score trend direction ("improving", "declining", "stable").
        sample_count: Number of evaluated responses.
        dimension_averages: Average score per quality dimension.
        recent_scores: Sliding window of recent overall scores.
    """

    model: str
    avg_score: float = 0.0
    trend: str = "stable"
    sample_count: int = 0
    dimension_averages: dict[str, float] = field(default_factory=dict)
    recent_scores: list[float] = field(default_factory=list)


@dataclass
class QualityConfig:
    """Configuration for quality evaluation weights and thresholds.

    Attributes:
        weight_relevance: Weight for relevance dimension.
        weight_completeness: Weight for completeness dimension.
        weight_coherence: Weight for coherence dimension.
        weight_conciseness: Weight for conciseness dimension.
        weight_correctness: Weight for correctness dimension.
        min_response_words: Minimum acceptable response word count.
        max_response_ratio: Maximum response/prompt word ratio before penalising.
        short_response_threshold: Word count below which response is "short".
        verbose_response_threshold: Word count above which response may be verbose.
        history_window_size: Number of recent scores to keep per model.
        trend_min_samples: Minimum samples before computing trend.
    """

    weight_relevance: float = 0.25
    weight_completeness: float = 0.25
    weight_coherence: float = 0.20
    weight_conciseness: float = 0.15
    weight_correctness: float = 0.15
    min_response_words: int = 3
    max_response_ratio: float = 100.0
    short_response_threshold: int = 15
    verbose_response_threshold: int = 2000
    history_window_size: int = 50
    trend_min_samples: int = 5

    @property
    def weights(self) -> dict[str, float]:
        """Return dimension weights as a dictionary."""
        return {
            "relevance": self.weight_relevance,
            "completeness": self.weight_completeness,
            "coherence": self.weight_coherence,
            "conciseness": self.weight_conciseness,
            "correctness": self.weight_correctness,
        }

    def validate(self) -> None:
        """Validate that weights sum to approximately 1.0.

        Raises:
            ValueError: If weights are invalid.
        """
        total = sum(self.weights.values())
        if not (0.95 <= total <= 1.05):
            msg = f"Quality weights must sum to ~1.0, got {total:.3f}"
            raise ValueError(msg)
        for name, w in self.weights.items():
            if w < 0.0:
                msg = f"Weight for '{name}' must be non-negative, got {w}"
                raise ValueError(msg)


# ---------------------------------------------------------------------------
# TF-IDF helpers (stdlib only)
# ---------------------------------------------------------------------------


def _tokenize(text: str) -> list[str]:
    """Tokenize text into lowercase words, stripping punctuation.

    Args:
        text: Input text.

    Returns:
        List of lowercase word tokens.
    """
    return [w.lower() for w in re.findall(r"\b[a-zA-Z_]\w*\b", text)]


def _compute_tf(tokens: list[str]) -> dict[str, float]:
    """Compute term frequency for a token list.

    Args:
        tokens: List of tokens.

    Returns:
        Mapping of token to its frequency.
    """
    counts: dict[str, int] = defaultdict(int)
    for t in tokens:
        counts[t] += 1
    total = len(tokens) or 1
    return {t: c / total for t, c in counts.items()}


def _compute_idf(documents: list[list[str]]) -> dict[str, float]:
    """Compute inverse document frequency across documents.

    Args:
        documents: List of token lists (one per document).

    Returns:
        Mapping of token to its IDF score.
    """
    n_docs = len(documents) or 1
    doc_freq: dict[str, int] = defaultdict(int)
    for doc in documents:
        seen: set[str] = set()
        for token in doc:
            if token not in seen:
                doc_freq[token] += 1
                seen.add(token)
    return {t: math.log(n_docs / df) + 1.0 for t, df in doc_freq.items()}


def _tfidf_similarity(text_a: str, text_b: str) -> float:
    """Compute TF-IDF cosine similarity between two texts.

    Args:
        text_a: First text.
        text_b: Second text.

    Returns:
        Cosine similarity score (0.0-1.0).
    """
    tokens_a = _tokenize(text_a)
    tokens_b = _tokenize(text_b)
    if not tokens_a or not tokens_b:
        return 0.0

    idf = _compute_idf([tokens_a, tokens_b])
    tf_a = _compute_tf(tokens_a)
    tf_b = _compute_tf(tokens_b)

    # Build TF-IDF vectors
    all_terms = set(tf_a) | set(tf_b)
    vec_a = {t: tf_a.get(t, 0.0) * idf.get(t, 1.0) for t in all_terms}
    vec_b = {t: tf_b.get(t, 0.0) * idf.get(t, 1.0) for t in all_terms}

    # Cosine similarity
    dot = sum(vec_a[t] * vec_b[t] for t in all_terms)
    mag_a = math.sqrt(sum(v * v for v in vec_a.values())) or 1.0
    mag_b = math.sqrt(sum(v * v for v in vec_b.values())) or 1.0

    return max(0.0, min(1.0, dot / (mag_a * mag_b)))


# ---------------------------------------------------------------------------
# Main evaluator
# ---------------------------------------------------------------------------


class QualityEvaluator:
    """Automatic response quality evaluation engine.

    Evaluates LLM responses across multiple quality dimensions using
    lightweight heuristics — no external API calls required.

    Args:
        config: Quality configuration with weights and thresholds.
    """

    def __init__(self, config: QualityConfig | None = None) -> None:
        self._config = config or QualityConfig()
        self._config.validate()
        self._model_histories: dict[str, ModelQualityHistory] = {}

    @property
    def config(self) -> QualityConfig:
        """Return the current quality configuration."""
        return self._config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(
        self,
        prompt: str,
        response: str,
        *,
        expected_format: str | None = None,
    ) -> QualityScore:
        """Evaluate response quality across all dimensions.

        Args:
            prompt: The original user prompt.
            response: The LLM response text.
            expected_format: Expected output format ("json", "code",
                "markdown", "list", "plain").

        Returns:
            QualityScore with per-dimension and overall scores.
        """
        issues: list[QualityIssue] = []

        if not response or not response.strip():
            issues.append(QualityIssue(
                severity=IssueSeverity.CRITICAL,
                dimension=QualityDimension.COMPLETENESS,
                description="Empty response",
            ))
            return QualityScore(
                relevance=0.0,
                completeness=0.0,
                coherence=0.0,
                conciseness=0.0,
                correctness=0.0,
                overall=0.0,
                issues=tuple(issues),
                reward_signal=0.0,
                evaluated_at=time.time(),
            )

        relevance = self._score_relevance(prompt, response, issues)
        completeness = self._score_completeness(prompt, response, issues)
        coherence = self._score_coherence(response, issues)
        conciseness = self._score_conciseness(prompt, response, issues)
        correctness = self._score_correctness(response, issues, expected_format)

        weights = self._config.weights
        overall = (
            relevance * weights["relevance"]
            + completeness * weights["completeness"]
            + coherence * weights["coherence"]
            + conciseness * weights["conciseness"]
            + correctness * weights["correctness"]
        )
        overall = max(0.0, min(1.0, overall))

        # Reward signal: overall score penalised by critical issues
        critical_count = sum(
            1 for i in issues if i.severity == IssueSeverity.CRITICAL
        )
        reward = max(0.0, overall - critical_count * 0.15)

        score = QualityScore(
            relevance=round(relevance, 3),
            completeness=round(completeness, 3),
            coherence=round(coherence, 3),
            conciseness=round(conciseness, 3),
            correctness=round(correctness, 3),
            overall=round(overall, 3),
            issues=tuple(issues),
            reward_signal=round(reward, 3),
            evaluated_at=time.time(),
        )

        logger.debug(
            "quality_evaluation_complete",
            overall=score.overall,
            relevance=score.relevance,
            completeness=score.completeness,
            coherence=score.coherence,
            conciseness=score.conciseness,
            correctness=score.correctness,
            issue_count=len(issues),
        )

        return score

    def compare(
        self,
        prompt: str,
        response_a: str,
        response_b: str,
        *,
        expected_format: str | None = None,
    ) -> QualityComparison:
        """Compare two responses to the same prompt.

        Args:
            prompt: The original user prompt.
            response_a: First response.
            response_b: Second response.
            expected_format: Expected output format.

        Returns:
            QualityComparison with winner and per-dimension breakdown.
        """
        score_a = self.evaluate(prompt, response_a, expected_format=expected_format)
        score_b = self.evaluate(prompt, response_b, expected_format=expected_format)

        dimension_winners: dict[str, str] = {}
        for dim in ("relevance", "completeness", "coherence", "conciseness", "correctness"):
            val_a = getattr(score_a, dim)
            val_b = getattr(score_b, dim)
            if abs(val_a - val_b) < 0.05:
                dimension_winners[dim] = "tie"
            elif val_a > val_b:
                dimension_winners[dim] = "a"
            else:
                dimension_winners[dim] = "b"

        margin = abs(score_a.overall - score_b.overall)
        if margin < 0.03:
            winner = "tie"
        elif score_a.overall > score_b.overall:
            winner = "a"
        else:
            winner = "b"

        return QualityComparison(
            winner=winner,
            margin=round(margin, 3),
            score_a=score_a,
            score_b=score_b,
            dimension_winners=dimension_winners,
        )

    def record_quality(self, model: str, score: QualityScore) -> None:
        """Record a quality score for a model.

        Args:
            model: Model identifier (e.g. "gpt-4o", "claude-3-opus").
            score: Quality score to record.
        """
        if model not in self._model_histories:
            self._model_histories[model] = ModelQualityHistory(model=model)

        history = self._model_histories[model]
        history.recent_scores.append(score.overall)

        # Trim to window size
        if len(history.recent_scores) > self._config.history_window_size:
            history.recent_scores = history.recent_scores[
                -self._config.history_window_size :
            ]

        history.sample_count += 1

        # Update running average
        history.avg_score = sum(history.recent_scores) / len(history.recent_scores)

        # Update dimension averages
        for dim in ("relevance", "completeness", "coherence", "conciseness", "correctness"):
            prev_avg = history.dimension_averages.get(dim, 0.0)
            new_val = getattr(score, dim)
            n = history.sample_count
            history.dimension_averages[dim] = prev_avg + (new_val - prev_avg) / n

        # Compute trend
        history.trend = self._compute_trend(history)

        logger.debug(
            "model_quality_recorded",
            model=model,
            avg_score=round(history.avg_score, 3),
            trend=history.trend,
            sample_count=history.sample_count,
        )

    def get_model_history(self, model: str) -> ModelQualityHistory | None:
        """Get quality history for a specific model.

        Args:
            model: Model identifier.

        Returns:
            ModelQualityHistory or None if no data exists.
        """
        return self._model_histories.get(model)

    def get_all_model_histories(self) -> dict[str, ModelQualityHistory]:
        """Get quality histories for all tracked models.

        Returns:
            Mapping of model name to its quality history.
        """
        return dict(self._model_histories)

    def get_reward_signal(self, model: str) -> float:
        """Get the current reward signal for a model, suitable for routing.

        Returns the rolling average score, or 0.5 as a neutral default
        when no data exists.

        Args:
            model: Model identifier.

        Returns:
            Reward signal between 0.0 and 1.0.
        """
        history = self._model_histories.get(model)
        if history is None or history.sample_count == 0:
            return 0.5
        return round(history.avg_score, 3)

    # ------------------------------------------------------------------
    # Dimension scorers
    # ------------------------------------------------------------------

    def _score_relevance(
        self, prompt: str, response: str, issues: list[QualityIssue],
    ) -> float:
        """Score how well the response addresses the prompt.

        Uses keyword overlap and TF-IDF similarity.

        Args:
            prompt: User prompt.
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            Relevance score (0.0-1.0).
        """
        # Keyword overlap (filtered)
        prompt_words = set(_tokenize(prompt)) - _STOP_WORDS
        response_words = set(_tokenize(response)) - _STOP_WORDS

        if not prompt_words:
            return 0.8  # Cannot assess — neutral

        overlap = prompt_words & response_words
        keyword_coverage = len(overlap) / len(prompt_words)

        # TF-IDF similarity
        tfidf_score = _tfidf_similarity(prompt, response)

        # Blend: 40% keyword, 60% TF-IDF
        blended = 0.4 * keyword_coverage + 0.6 * tfidf_score

        # Scale to 0.0-1.0 with a floor
        score = min(1.0, 0.1 + blended * 0.9)

        if score < 0.3:
            issues.append(QualityIssue(
                severity=IssueSeverity.WARNING,
                dimension=QualityDimension.RELEVANCE,
                description="Response has very low relevance to the prompt",
            ))
        elif score < 0.5:
            issues.append(QualityIssue(
                severity=IssueSeverity.INFO,
                dimension=QualityDimension.RELEVANCE,
                description="Response has limited relevance to the prompt",
            ))

        return score

    def _score_completeness(
        self, prompt: str, response: str, issues: list[QualityIssue],
    ) -> float:
        """Score whether the response fully answers the question.

        Checks for structural completeness based on prompt expectations.

        Args:
            prompt: User prompt.
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            Completeness score (0.0-1.0).
        """
        score = 0.7  # Base score for non-empty responses
        prompt_lower = prompt.lower()
        response_lower = response.lower()
        response_words = len(response.split())

        # Check if prompt asks for code
        code_keywords = {"code", "implement", "write", "function", "class", "create", "fix"}
        asks_code = any(kw in prompt_lower for kw in code_keywords)
        has_code_block = bool(_CODE_FENCE_RE.search(response))

        if asks_code:
            if has_code_block:
                score += 0.15
            else:
                score -= 0.15
                issues.append(QualityIssue(
                    severity=IssueSeverity.WARNING,
                    dimension=QualityDimension.COMPLETENESS,
                    description="Code was requested but no code block found",
                ))

        # Check if prompt asks for explanation
        explain_keywords = {"explain", "why", "how", "describe", "elaborate"}
        asks_explanation = any(kw in prompt_lower for kw in explain_keywords)
        if asks_explanation and response_words < 30:
            score -= 0.15
            issues.append(QualityIssue(
                severity=IssueSeverity.INFO,
                dimension=QualityDimension.COMPLETENESS,
                description="Explanation requested but response is very brief",
            ))

        # Check if prompt asks for a list
        list_keywords = {"list", "enumerate", "steps", "examples"}
        asks_list = any(kw in prompt_lower for kw in list_keywords)
        has_list = bool(_LIST_INDICATOR.search(response))
        if asks_list:
            if has_list:
                score += 0.1
            else:
                score -= 0.1

        # Check for very short responses to complex prompts
        prompt_words = len(prompt.split())
        if prompt_words > 20 and response_words < self._config.min_response_words:
            score -= 0.3
            issues.append(QualityIssue(
                severity=IssueSeverity.CRITICAL,
                dimension=QualityDimension.COMPLETENESS,
                description="Response is too short to adequately address the prompt",
            ))

        # Question-answer completeness: check if response contains "answer" patterns
        question_words = {"what", "when", "where", "who", "which", "how many"}
        asks_question = any(kw in prompt_lower for kw in question_words)
        if asks_question:
            # Boost if response contains definitive statement patterns
            definitive = any(
                p in response_lower
                for p in ("the answer is", "it is", "there are", "you can", "this is")
            )
            if definitive:
                score += 0.05

        return max(0.0, min(1.0, score))

    def _score_coherence(
        self, response: str, issues: list[QualityIssue],
    ) -> float:
        """Score logical consistency and structural integrity.

        Checks for truncation, repetition, contradictions, and
        hallucination indicators.

        Args:
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            Coherence score (0.0-1.0).
        """
        score = 1.0

        # Truncation detection
        stripped = response.rstrip()
        if stripped:
            last_char = stripped[-1]
            if last_char not in ".!?`>)]:;\"'*-":
                last_line = stripped.split("\n")[-1].strip()
                # Exclude code blocks, list items, headings
                if last_line and not last_line.startswith(("```", "---", "***", "- ", "* ", "#")):
                    score -= 0.12
                    issues.append(QualityIssue(
                        severity=IssueSeverity.WARNING,
                        dimension=QualityDimension.COHERENCE,
                        description="Response may be truncated (no ending punctuation)",
                        location="end of response",
                    ))

        # Repetition detection (30+ chars repeated 3+ times)
        repetition_re = re.compile(r"(.{30,})\1{2,}")
        if repetition_re.search(response):
            score -= 0.25
            issues.append(QualityIssue(
                severity=IssueSeverity.WARNING,
                dimension=QualityDimension.COHERENCE,
                description="Repetitive content detected (looping)",
            ))

        # Sentence-level repetition (same sentence appears 3+ times)
        sentences = [s.strip() for s in re.split(r"[.!?]+", response) if s.strip()]
        if sentences:
            sentence_counts: dict[str, int] = defaultdict(int)
            for s in sentences:
                normalised = s.lower().strip()
                if len(normalised) > 10:
                    sentence_counts[normalised] += 1
            max_repeats = max(sentence_counts.values()) if sentence_counts else 1
            if max_repeats >= 3:
                score -= 0.15
                issues.append(QualityIssue(
                    severity=IssueSeverity.WARNING,
                    dimension=QualityDimension.COHERENCE,
                    description=f"Same sentence repeated {max_repeats} times",
                ))

        # Hallucination confidence phrases
        confidence_count = sum(
            1 for p in _CONFIDENCE_PHRASES if p.search(response)
        )
        if confidence_count > 0:
            score -= 0.08 * confidence_count
            issues.append(QualityIssue(
                severity=IssueSeverity.INFO,
                dimension=QualityDimension.COHERENCE,
                description=f"Overconfidence indicators detected ({confidence_count})",
            ))

        # Contradiction detection
        for pat_a, pat_b in _CONTRADICTION_PAIRS:
            if pat_a.search(response) and pat_b.search(response):
                score -= 0.1
                issues.append(QualityIssue(
                    severity=IssueSeverity.WARNING,
                    dimension=QualityDimension.COHERENCE,
                    description="Potential contradiction detected in response",
                ))
                break

        # Bracket balance in code blocks
        code_blocks = _CODE_FENCE_RE.findall(response)
        for _, code in code_blocks:
            for open_br, close_br in _BRACKET_PAIRS.items():
                if code.count(open_br) != code.count(close_br):
                    score -= 0.08
                    issues.append(QualityIssue(
                        severity=IssueSeverity.WARNING,
                        dimension=QualityDimension.COHERENCE,
                        description=f"Unbalanced {open_br}{close_br} in code block",
                    ))
                    break

        return max(0.0, score)

    def _score_conciseness(
        self, prompt: str, response: str, issues: list[QualityIssue],
    ) -> float:
        """Score whether the response length is appropriate.

        Penalises both too-short and too-long responses relative to
        the prompt complexity.

        Args:
            prompt: User prompt.
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            Conciseness score (0.0-1.0).
        """
        response_words = len(response.split())
        prompt_words = len(prompt.split())

        if response_words == 0:
            return 0.0

        # Too short
        if response_words < self._config.short_response_threshold and prompt_words > 10:
            issues.append(QualityIssue(
                severity=IssueSeverity.WARNING,
                dimension=QualityDimension.CONCISENESS,
                description=f"Response is very short ({response_words} words) for the prompt",
            ))
            return 0.3

        # Too long — verbose
        ratio = response_words / max(1, prompt_words)
        if ratio > self._config.max_response_ratio:
            issues.append(QualityIssue(
                severity=IssueSeverity.INFO,
                dimension=QualityDimension.CONCISENESS,
                description=f"Response is very verbose (ratio {ratio:.0f}:1)",
            ))
            return 0.5

        if response_words > self._config.verbose_response_threshold:
            # Check for filler content
            hedge_count = sum(1 for h in _HEDGE_WORDS if h.lower() in response.lower())
            if hedge_count >= 3:
                issues.append(QualityIssue(
                    severity=IssueSeverity.INFO,
                    dimension=QualityDimension.CONCISENESS,
                    description=f"Response contains {hedge_count} hedging phrases",
                ))
                return 0.65

        # Simple prompt but very long response
        if prompt_words < 15 and response_words > 1500:
            issues.append(QualityIssue(
                severity=IssueSeverity.INFO,
                dimension=QualityDimension.CONCISENESS,
                description="Response seems overly long for a simple prompt",
            ))
            return 0.6

        return 0.9

    def _score_correctness(
        self,
        response: str,
        issues: list[QualityIssue],
        expected_format: str | None = None,
    ) -> float:
        """Score format and syntax correctness.

        For code responses: checks Python syntax, TODO markers, imports.
        For JSON responses: validates JSON parsing.
        For other formats: checks format compliance.

        Args:
            response: LLM response.
            issues: Mutable list to append issues to.
            expected_format: Expected output format.

        Returns:
            Correctness score (0.0-1.0).
        """
        score = 0.85  # Base score

        # Code quality checks
        code_blocks = _CODE_FENCE_RE.findall(response)
        if code_blocks:
            code_score = self._assess_code_blocks(code_blocks, issues)
            score = min(score, code_score)

        # Format compliance
        if expected_format:
            format_score = self._check_format_compliance(
                response, expected_format, issues,
            )
            score = min(score, format_score)

        return max(0.0, min(1.0, score))

    # ------------------------------------------------------------------
    # Code quality helpers
    # ------------------------------------------------------------------

    def _assess_code_blocks(
        self,
        code_blocks: list[tuple[str, str]],
        issues: list[QualityIssue],
    ) -> float:
        """Assess quality of code blocks in the response.

        Args:
            code_blocks: List of (language, code) tuples from regex.
            issues: Mutable list to append issues to.

        Returns:
            Code quality score (0.0-1.0).
        """
        if not code_blocks:
            return 0.85

        total_score = 0.0

        for lang, code in code_blocks:
            block_score = 0.8

            # Python syntax check
            if lang in ("python", "py", ""):
                block_score = self._check_python_syntax(code, issues, block_score)

            # TODO/FIXME markers
            todo_matches = _TODO_FIXME_RE.findall(code)
            if todo_matches:
                block_score -= 0.05 * len(todo_matches)
                issues.append(QualityIssue(
                    severity=IssueSeverity.INFO,
                    dimension=QualityDimension.CORRECTNESS,
                    description=f"Code contains {len(todo_matches)} TODO/FIXME marker(s)",
                ))

            # Empty or trivial code
            lines = [ln for ln in code.strip().split("\n") if ln.strip()]
            if not lines:
                block_score = 0.2
                issues.append(QualityIssue(
                    severity=IssueSeverity.WARNING,
                    dimension=QualityDimension.CORRECTNESS,
                    description="Empty code block",
                ))
            elif len(lines) == 1 and lines[0].strip() in ("pass", "...", "# TODO"):
                block_score = 0.3
                issues.append(QualityIssue(
                    severity=IssueSeverity.WARNING,
                    dimension=QualityDimension.CORRECTNESS,
                    description="Code block contains only a placeholder",
                ))

            # Import completeness: check if identifiers are used without import
            if lang in ("python", "py", ""):
                block_score = self._check_import_completeness(
                    code, issues, block_score,
                )

            total_score += max(0.0, min(1.0, block_score))

        return total_score / len(code_blocks)

    def _check_python_syntax(
        self, code: str, issues: list[QualityIssue], current_score: float,
    ) -> float:
        """Check Python code for syntax errors.

        Args:
            code: Python source code.
            issues: Mutable list to append issues to.
            current_score: Current score to adjust.

        Returns:
            Adjusted score.
        """
        try:
            ast.parse(code)
        except SyntaxError as exc:
            current_score -= 0.25
            location = f"line {exc.lineno}" if exc.lineno else "unknown"
            issues.append(QualityIssue(
                severity=IssueSeverity.CRITICAL,
                dimension=QualityDimension.CORRECTNESS,
                description=f"Python syntax error: {exc.msg}",
                location=location,
            ))
        return current_score

    def _check_import_completeness(
        self, code: str, issues: list[QualityIssue], current_score: float,
    ) -> float:
        """Check if Python code uses names that appear to need imports.

        Uses a heuristic: common stdlib/third-party module names used as
        function calls or attribute accesses without a corresponding import.

        Args:
            code: Python source code.
            issues: Mutable list to append issues to.
            current_score: Current score to adjust.

        Returns:
            Adjusted score.
        """
        common_modules = {
            "os", "sys", "json", "re", "math", "datetime", "pathlib",
            "collections", "itertools", "functools", "typing", "logging",
            "subprocess", "shutil", "hashlib", "base64", "time", "random",
            "requests", "numpy", "pandas", "torch", "flask", "django",
            "pytest", "asyncio", "dataclasses",
        }

        # Find what is imported
        import_re = re.compile(
            r"^\s*(?:import\s+([\w.]+)|from\s+([\w.]+)\s+import)", re.MULTILINE,
        )
        imported: set[str] = set()
        for match in import_re.finditer(code):
            name = match.group(1) or match.group(2)
            if name:
                imported.add(name.split(".")[0])

        # Find module-level usages (module.something or module(...))
        usage_re = re.compile(r"\b([a-z_]\w*)\s*[.(]")
        used: set[str] = set()
        for match in usage_re.finditer(code):
            name = match.group(1)
            if name in common_modules:
                used.add(name)

        missing = used - imported
        if missing:
            current_score -= 0.05 * len(missing)
            issues.append(QualityIssue(
                severity=IssueSeverity.INFO,
                dimension=QualityDimension.CORRECTNESS,
                description=f"Potentially missing imports: {', '.join(sorted(missing))}",
            ))

        return current_score

    # ------------------------------------------------------------------
    # Format compliance
    # ------------------------------------------------------------------

    def _check_format_compliance(
        self,
        response: str,
        expected_format: str,
        issues: list[QualityIssue],
    ) -> float:
        """Check if the response matches the expected format.

        Args:
            response: LLM response.
            expected_format: Expected format name.
            issues: Mutable list to append issues to.

        Returns:
            Format compliance score (0.0-1.0).
        """
        if expected_format == "json":
            return self._check_json_format(response, issues)
        if expected_format == "code":
            return self._check_code_format(response, issues)
        if expected_format == "markdown":
            return self._check_markdown_format(response, issues)
        if expected_format == "list":
            return self._check_list_format(response, issues)
        # "plain" or unknown format — no specific checks
        return 0.85

    def _check_json_format(
        self, response: str, issues: list[QualityIssue],
    ) -> float:
        """Validate JSON format compliance.

        Args:
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            JSON compliance score (0.0-1.0).
        """
        # Try direct parse
        try:
            json.loads(response.strip())
            return 1.0
        except json.JSONDecodeError:
            pass

        # Try extracting from code block
        code_blocks = _CODE_FENCE_RE.findall(response)
        for lang, code in code_blocks:
            if lang in ("json", ""):
                try:
                    json.loads(code.strip())
                    return 0.85  # Valid but wrapped in markdown
                except json.JSONDecodeError:
                    continue

        # Try finding JSON-like content
        for start, end in [("{", "}"), ("[", "]")]:
            s_idx = response.find(start)
            e_idx = response.rfind(end)
            if s_idx != -1 and e_idx > s_idx:
                try:
                    json.loads(response[s_idx : e_idx + 1])
                    return 0.7  # Valid JSON buried in text
                except json.JSONDecodeError:
                    continue

        issues.append(QualityIssue(
            severity=IssueSeverity.CRITICAL,
            dimension=QualityDimension.CORRECTNESS,
            description="Expected JSON format but no valid JSON found",
        ))
        return 0.2

    def _check_code_format(
        self, response: str, issues: list[QualityIssue],
    ) -> float:
        """Validate code format compliance.

        Args:
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            Code compliance score (0.0-1.0).
        """
        if _CODE_FENCE_RE.search(response):
            return 0.95

        # Check if raw response looks like code
        code_indicators = [
            "def ", "class ", "function ", "const ", "let ", "var ",
            "import ", "from ", "require(", "return ", "async ", "if (",
        ]
        indicator_count = sum(1 for ind in code_indicators if ind in response)
        if indicator_count >= 2:
            return 0.7  # Code present but not in fenced block

        issues.append(QualityIssue(
            severity=IssueSeverity.WARNING,
            dimension=QualityDimension.CORRECTNESS,
            description="Expected code format but no code blocks found",
        ))
        return 0.3

    def _check_markdown_format(
        self, response: str, issues: list[QualityIssue],
    ) -> float:
        """Validate markdown format compliance.

        Args:
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            Markdown compliance score (0.0-1.0).
        """
        if _MARKDOWN_INDICATORS.search(response):
            return 0.95

        if len(response) < 100:
            return 0.8  # Short responses don't need markdown

        issues.append(QualityIssue(
            severity=IssueSeverity.INFO,
            dimension=QualityDimension.CORRECTNESS,
            description="Expected markdown format but no markdown indicators found",
        ))
        return 0.5

    def _check_list_format(
        self, response: str, issues: list[QualityIssue],
    ) -> float:
        """Validate list format compliance.

        Args:
            response: LLM response.
            issues: Mutable list to append issues to.

        Returns:
            List compliance score (0.0-1.0).
        """
        if _LIST_INDICATOR.search(response):
            return 0.95

        # Check for numbered items without standard formatting
        if re.search(r"\d+[.)]\s", response):
            return 0.8

        issues.append(QualityIssue(
            severity=IssueSeverity.WARNING,
            dimension=QualityDimension.CORRECTNESS,
            description="Expected list format but no list structure found",
        ))
        return 0.3

    # ------------------------------------------------------------------
    # Trend computation
    # ------------------------------------------------------------------

    def _compute_trend(self, history: ModelQualityHistory) -> str:
        """Compute quality trend for a model.

        Compares the average of the first half of the window to the
        second half.

        Args:
            history: Model quality history.

        Returns:
            Trend string: "improving", "declining", or "stable".
        """
        scores = history.recent_scores
        if len(scores) < self._config.trend_min_samples:
            return "stable"

        midpoint = len(scores) // 2
        first_half = scores[:midpoint]
        second_half = scores[midpoint:]

        avg_first = sum(first_half) / len(first_half) if first_half else 0.0
        avg_second = sum(second_half) / len(second_half) if second_half else 0.0

        diff = avg_second - avg_first
        if diff > 0.05:
            return "improving"
        if diff < -0.05:
            return "declining"
        return "stable"
