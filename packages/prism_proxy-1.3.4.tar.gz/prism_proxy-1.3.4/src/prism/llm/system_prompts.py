"""System prompt management — generates context-aware system prompts for optimal LLM output."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TaskMode(Enum):
    """Operating modes that affect system prompt content."""

    GENERAL = "general"
    CODE_GENERATION = "code_generation"
    CODE_REVIEW = "code_review"
    DEBUGGING = "debugging"
    ARCHITECTURE = "architecture"
    CREATIVE = "creative"
    ANALYSIS = "analysis"
    TOOL_USE = "tool_use"


@dataclass
class SystemPromptConfig:
    """Configuration for system prompt generation."""

    mode: TaskMode = TaskMode.GENERAL
    project_language: str | None = None
    project_framework: str | None = None
    available_tools: list[str] = field(default_factory=list)
    custom_instructions: str = ""
    include_safety: bool = True
    include_tool_instructions: bool = True
    max_prompt_tokens: int = 2000
    provider: str = "anthropic"  # Affects prompt format


class SystemPromptBuilder:
    """Builds optimized system prompts for different providers and tasks."""

    def __init__(self, config: SystemPromptConfig | None = None) -> None:
        self._config = config or SystemPromptConfig()

    def build(self, **overrides: Any) -> str:
        """Build a complete system prompt.

        Args:
            **overrides: Override any config field for this call.

        Returns:
            Complete system prompt string.
        """
        config = self._config
        if overrides:
            import dataclasses

            config = dataclasses.replace(
                config,
                **{k: v for k, v in overrides.items() if hasattr(config, k)},
            )

        sections: list[str] = []

        # Core identity
        sections.append(self._build_identity(config))

        # Mode-specific instructions
        sections.append(self._build_mode_instructions(config))

        # Tool instructions
        if config.include_tool_instructions and config.available_tools:
            sections.append(self._build_tool_instructions(config))

        # Project context
        if config.project_language or config.project_framework:
            sections.append(self._build_project_context(config))

        # Safety guardrails
        if config.include_safety:
            sections.append(self._build_safety(config))

        # Custom user instructions
        if config.custom_instructions:
            sections.append(
                f"\n## Custom Instructions\n{config.custom_instructions}"
            )

        # Quality enforcement
        sections.append(self._build_quality_enforcement(config))

        return "\n".join(s for s in sections if s)

    def build_for_provider(self, provider: str, **kwargs: Any) -> str:
        """Build a provider-optimized system prompt."""
        return self.build(provider=provider, **kwargs)

    def _build_identity(self, config: SystemPromptConfig) -> str:
        return (
            "You are Prism, an expert AI coding assistant. "
            "You help users with software engineering tasks including "
            "writing code, "
            "debugging, architecture design, code review, and analysis. "
            "You produce production-ready, well-tested, secure code."
        )

    def _build_mode_instructions(self, config: SystemPromptConfig) -> str:
        instructions: dict[TaskMode, str] = {
            TaskMode.GENERAL: "",
            TaskMode.CODE_GENERATION: (
                "\n## Code Generation Mode\n"
                "- Write complete, production-ready implementations\n"
                "- Include proper error handling and input validation\n"
                "- Follow the project's existing patterns and conventions\n"
                "- Add type hints to all function signatures\n"
                "- Never use placeholders or TODO comments"
            ),
            TaskMode.CODE_REVIEW: (
                "\n## Code Review Mode\n"
                "- Analyze code for bugs, security issues, and "
                "performance problems\n"
                "- Check for OWASP top 10 vulnerabilities\n"
                "- Suggest specific improvements with code examples\n"
                "- Rate severity: critical > high > medium > low > info"
            ),
            TaskMode.DEBUGGING: (
                "\n## Debugging Mode\n"
                "- Identify root causes, not just symptoms\n"
                "- Trace the execution flow step by step\n"
                "- Check for common pitfalls: off-by-one, null refs, "
                "race conditions\n"
                "- Provide the minimal fix, don't refactor unrelated code"
            ),
            TaskMode.ARCHITECTURE: (
                "\n## Architecture Mode\n"
                "- Consider scalability, maintainability, and "
                "testability\n"
                "- Identify separation of concerns and interface "
                "boundaries\n"
                "- Evaluate trade-offs explicitly\n"
                "- Prefer simple solutions over clever ones"
            ),
            TaskMode.CREATIVE: (
                "\n## Creative Mode\n"
                "- Explore novel approaches and unconventional "
                "solutions\n"
                "- Consider multiple alternatives before recommending\n"
                "- Balance innovation with practicality"
            ),
            TaskMode.ANALYSIS: (
                "\n## Analysis Mode\n"
                "- Be thorough and systematic\n"
                "- Support claims with evidence from the code\n"
                "- Quantify where possible (complexity, performance, "
                "coverage)"
            ),
            TaskMode.TOOL_USE: (
                "\n## Tool Use Mode\n"
                "- Use tools to gather information before answering\n"
                "- Read files before suggesting changes\n"
                "- Verify your work by running tests after edits\n"
                "- Prefer targeted reads over full file dumps"
            ),
        }
        return instructions.get(config.mode, "")

    def _build_tool_instructions(
        self, config: SystemPromptConfig
    ) -> str:
        tools_list = ", ".join(config.available_tools)
        return (
            f"\n## Available Tools\n"
            f"You have access to: {tools_list}\n\n"
            "When using tools:\n"
            "- Read files before editing them\n"
            "- Use search before making assumptions about code "
            "structure\n"
            "- Execute commands in the sandbox for safety\n"
            "- Report tool results clearly to the user"
        )

    def _build_project_context(
        self, config: SystemPromptConfig
    ) -> str:
        parts = ["\n## Project Context"]
        if config.project_language:
            parts.append(f"- Primary language: {config.project_language}")
        if config.project_framework:
            parts.append(f"- Framework: {config.project_framework}")
        return "\n".join(parts)

    def _build_safety(self, _config: SystemPromptConfig) -> str:
        return (
            "\n## Safety\n"
            "- Never expose API keys, passwords, or secrets\n"
            "- Validate all file paths to prevent traversal attacks\n"
            "- Sanitize user inputs before using in commands\n"
            "- Flag potential security vulnerabilities proactively"
        )

    def _build_quality_enforcement(
        self, _config: SystemPromptConfig
    ) -> str:
        return (
            "\n## Quality Standards\n"
            "- Be concise. Lead with the answer.\n"
            "- Show code changes as diffs when modifying existing "
            "code.\n"
            "- If uncertain, say so rather than guessing.\n"
            "- Explain trade-offs when multiple approaches exist."
        )


def format_tool_result(
    tool_name: str,
    result: Any,
    success: bool = True,
    provider: str = "anthropic",
) -> dict[str, Any]:
    """Format a tool execution result for optimal LLM consumption.

    Different providers handle tool results differently:
    - Anthropic: tool_result content blocks with is_error flag
    - OpenAI: tool message with tool_call_id
    - Generic: user message with clear structure

    Args:
        tool_name: Name of the tool that was called.
        result: The tool's output (string, dict, list, or any
            serializable).
        success: Whether the tool executed successfully.
        provider: Target provider for format optimization.

    Returns:
        Properly formatted message dict for the provider.
    """
    # Serialize result to string if needed
    if isinstance(result, (dict, list)):
        result_str = json.dumps(result, indent=2, default=str)
    elif result is None:
        result_str = "(no output)"
    else:
        result_str = str(result)

    # Truncate very long results
    max_result_length = 50000
    if len(result_str) > max_result_length:
        result_str = (
            result_str[:max_result_length]
            + f"\n\n... (truncated, {len(result_str)} total chars)"
        )

    if provider.startswith("anthropic") or provider.startswith("claude"):
        return _format_anthropic_tool_result(
            tool_name, result_str, success
        )
    if (
        provider.startswith("openai")
        or provider.startswith("gpt")
        or provider.startswith("o1")
        or provider.startswith("o3")
    ):
        return _format_openai_tool_result(
            tool_name, result_str, success
        )
    return _format_generic_tool_result(tool_name, result_str, success)


def _format_anthropic_tool_result(
    tool_name: str, result_str: str, success: bool
) -> dict[str, Any]:
    """Format tool result for Anthropic Claude.

    Claude works best with structured XML-like tool results.
    """
    if success:
        content = (
            f'<tool_result tool="{tool_name}">\n'
            f"{result_str}\n"
            f"</tool_result>"
        )
    else:
        content = (
            f'<tool_error tool="{tool_name}">\n'
            f"{result_str}\n"
            f"</tool_error>"
        )

    return {
        "role": "user",
        "content": content,
    }


def _format_openai_tool_result(
    tool_name: str, result_str: str, success: bool
) -> dict[str, Any]:
    """Format tool result for OpenAI models.

    OpenAI expects a 'tool' role message with the tool_call_id.
    """
    if not success:
        result_str = f"Error: {result_str}"

    return {
        "role": "tool",
        "content": result_str,
        "name": tool_name,
    }


def _format_generic_tool_result(
    tool_name: str, result_str: str, success: bool
) -> dict[str, Any]:
    """Format tool result for generic/unknown providers.

    Falls back to a user message with clear structure.
    """
    status = "SUCCESS" if success else "ERROR"
    content = f"[Tool: {tool_name}] [{status}]\n{result_str}"

    return {
        "role": "user",
        "content": content,
    }
