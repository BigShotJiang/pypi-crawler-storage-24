"""Response validation and repair engine.

Validates LLM responses against expected schemas, formats, and quality
criteria.  When validation fails, attempts automatic repair before
returning to the caller.

Features:
    1. JSON schema validation — ensure response matches expected structure
    2. Code block extraction and syntax validation
    3. Format enforcement (markdown, JSON, YAML, plain text)
    4. Content safety checks (PII detection, secret detection)
    5. Truncation detection and repair
    6. Automatic retry with targeted repair prompts

Usage::

    validator = ResponseValidator()
    result = validator.validate(response, schema={"type": "object", ...})
    if not result.is_valid:
        repaired = validator.repair(response, result.issues)
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class ValidationSeverity(Enum):
    """Severity of a validation issue."""

    ERROR = "error"  # Must fix — response is unusable
    WARNING = "warning"  # Should fix — response is degraded
    INFO = "info"  # FYI — minor quality issue


class ValidationType(Enum):
    """Type of validation check performed."""

    JSON_SCHEMA = "json_schema"
    CODE_SYNTAX = "code_syntax"
    FORMAT = "format"
    CONTENT_SAFETY = "content_safety"
    TRUNCATION = "truncation"
    LENGTH = "length"
    COMPLETENESS = "completeness"


@dataclass(frozen=True)
class ValidationIssue:
    """A single validation issue found in a response.

    Attributes:
        severity: How serious the issue is.
        validation_type: What kind of check found it.
        message: Human-readable description.
        location: Where in the response the issue was found (line/char/path).
        suggestion: How to fix it.
    """

    severity: ValidationSeverity
    validation_type: ValidationType
    message: str
    location: str = ""
    suggestion: str = ""


@dataclass
class ValidationResult:
    """Result of validating a response.

    Attributes:
        is_valid: Whether the response passes all error-level checks.
        issues: All validation issues found.
        score: Overall quality score (0.0 to 1.0).
        repaired_content: If repair was attempted, the repaired response.
        metadata: Additional validation metadata.
    """

    is_valid: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    score: float = 1.0
    repaired_content: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def errors(self) -> list[ValidationIssue]:
        """Get error-severity issues only."""
        return [i for i in self.issues if i.severity == ValidationSeverity.ERROR]

    @property
    def warnings(self) -> list[ValidationIssue]:
        """Get warning-severity issues only."""
        return [i for i in self.issues if i.severity == ValidationSeverity.WARNING]


# ---------------------------------------------------------------------------
# PII and secret detection patterns
# ---------------------------------------------------------------------------

_PII_PATTERNS = {
    "email": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"),
    "phone_us": re.compile(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b"),
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "credit_card": re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"),
    "ip_address": re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"),
}

_SECRET_PATTERNS = {
    "aws_key": re.compile(r"AKIA[0-9A-Z]{16}"),
    "github_token": re.compile(r"gh[ps]_[A-Za-z0-9_]{36,}"),
    "generic_api_key": re.compile(r"(?:api[_-]?key|apikey|secret[_-]?key)\s*[:=]\s*['\"]?[A-Za-z0-9+/=_-]{20,}"),
    "jwt": re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"),
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----"),
}

# Truncation indicators
_TRUNCATION_INDICATORS = [
    "...",
    "// ...",
    "# ...",
    "/* ... */",
    "[truncated]",
    "[continued]",
    "(continued)",
    "etc.",
]

# Common unclosed bracket patterns
_BRACKET_PAIRS = {"{": "}", "[": "]", "(": ")"}


class ResponseValidator:
    """Validates and repairs LLM responses.

    Args:
        max_length: Maximum acceptable response length in characters.
        min_length: Minimum acceptable response length.
        check_pii: Whether to check for PII in responses.
        check_secrets: Whether to check for secrets in responses.
    """

    def __init__(
        self,
        max_length: int = 100000,
        min_length: int = 1,
        check_pii: bool = True,
        check_secrets: bool = True,
    ) -> None:
        self._max_length = max_length
        self._min_length = min_length
        self._check_pii = check_pii
        self._check_secrets = check_secrets

    def validate(
        self,
        response: str,
        expected_format: str | None = None,
        json_schema: dict[str, Any] | None = None,
        expected_language: str | None = None,
    ) -> ValidationResult:
        """Validate a response against multiple criteria.

        Args:
            response: The LLM response text to validate.
            expected_format: Expected format ("json", "markdown", "code", "yaml").
            json_schema: Optional JSON schema to validate against.
            expected_language: Expected programming language for code responses.

        Returns:
            ValidationResult with all issues found.
        """
        issues: list[ValidationIssue] = []

        # Length checks
        issues.extend(self._check_length(response))

        # Truncation detection
        issues.extend(self._check_truncation(response))

        # Format validation
        if expected_format:
            issues.extend(self._check_format(response, expected_format))

        # JSON schema validation
        if json_schema:
            issues.extend(self._check_json_schema(response, json_schema))

        # Code syntax validation
        if expected_language:
            issues.extend(self._check_code_syntax(response, expected_language))

        # Content safety
        if self._check_pii:
            issues.extend(self._check_pii_leakage(response))
        if self._check_secrets:
            issues.extend(self._check_secret_leakage(response))

        # Bracket balancing
        issues.extend(self._check_brackets(response))

        # Calculate score
        score = self._calculate_score(issues)
        is_valid = not any(i.severity == ValidationSeverity.ERROR for i in issues)

        return ValidationResult(
            is_valid=is_valid,
            issues=issues,
            score=score,
            metadata={
                "response_length": len(response),
                "issue_count": len(issues),
                "error_count": sum(1 for i in issues if i.severity == ValidationSeverity.ERROR),
            },
        )

    def repair(self, response: str, issues: list[ValidationIssue]) -> str:
        """Attempt to automatically repair a response based on validation issues.

        Args:
            response: The original response.
            issues: Validation issues to address.

        Returns:
            Repaired response (may be identical if no repair is possible).
        """
        repaired = response

        for issue in issues:
            if issue.validation_type == ValidationType.TRUNCATION:
                # Can't really fix truncation without re-querying
                continue

            if issue.validation_type == ValidationType.FORMAT:
                repaired = self._repair_format(repaired, issue)

            if issue.validation_type == ValidationType.JSON_SCHEMA:
                repaired = self._repair_json(repaired, issue)

            if issue.validation_type == ValidationType.CONTENT_SAFETY:
                repaired = self._redact_sensitive(repaired, issue)

        return repaired

    def extract_json(self, response: str) -> tuple[Any | None, list[ValidationIssue]]:
        """Extract and parse JSON from a response that may contain markdown.

        Handles common LLM patterns like wrapping JSON in ```json code blocks.

        Args:
            response: Response text potentially containing JSON.

        Returns:
            Tuple of (parsed JSON object or None, list of issues).
        """
        issues: list[ValidationIssue] = []

        # Try direct parse first
        try:
            return json.loads(response), issues
        except json.JSONDecodeError:
            pass

        # Try extracting from code blocks
        code_block_re = re.compile(r"```(?:json)?\s*\n(.*?)\n```", re.DOTALL)
        match = code_block_re.search(response)
        if match:
            try:
                return json.loads(match.group(1)), issues
            except json.JSONDecodeError as exc:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.ERROR,
                    validation_type=ValidationType.JSON_SCHEMA,
                    message=f"JSON in code block is malformed: {exc}",
                    suggestion="Fix JSON syntax errors",
                ))
                return None, issues

        # Try finding JSON-like content
        for start_char, end_char in [("{", "}"), ("[", "]")]:
            start = response.find(start_char)
            end = response.rfind(end_char)
            if start != -1 and end > start:
                try:
                    return json.loads(response[start : end + 1]), issues
                except json.JSONDecodeError:
                    continue

        issues.append(ValidationIssue(
            severity=ValidationSeverity.ERROR,
            validation_type=ValidationType.JSON_SCHEMA,
            message="No valid JSON found in response",
            suggestion="Ensure the response contains properly formatted JSON",
        ))
        return None, issues

    def extract_code_blocks(self, response: str) -> list[dict[str, str]]:
        """Extract all code blocks from a markdown response.

        Args:
            response: Markdown response text.

        Returns:
            List of dicts with "language" and "code" keys.
        """
        pattern = re.compile(r"```(\w*)\n(.*?)```", re.DOTALL)
        blocks: list[dict[str, str]] = []
        for match in pattern.finditer(response):
            blocks.append({
                "language": match.group(1) or "unknown",
                "code": match.group(2).strip(),
            })
        return blocks

    # ------------------------------------------------------------------
    # Internal validation methods
    # ------------------------------------------------------------------

    def _check_length(self, response: str) -> list[ValidationIssue]:
        """Check response length constraints."""
        issues: list[ValidationIssue] = []

        if len(response) < self._min_length:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                validation_type=ValidationType.LENGTH,
                message=f"Response too short ({len(response)} < {self._min_length} chars)",
                suggestion="Retry with a more specific prompt",
            ))

        if len(response) > self._max_length:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                validation_type=ValidationType.LENGTH,
                message=f"Response exceeds max length ({len(response)} > {self._max_length} chars)",
                suggestion="Consider breaking the request into smaller parts",
            ))

        return issues

    def _check_truncation(self, response: str) -> list[ValidationIssue]:
        """Detect if the response appears truncated."""
        issues: list[ValidationIssue] = []

        # Check for truncation indicators at end
        stripped = response.rstrip()
        for indicator in _TRUNCATION_INDICATORS:
            if stripped.endswith(indicator):
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    validation_type=ValidationType.TRUNCATION,
                    message=f"Response appears truncated (ends with '{indicator}')",
                    suggestion="Increase max_tokens or break into smaller requests",
                ))
                break

        # Check for incomplete sentences at the end
        if stripped and stripped[-1] not in ".!?;:)]\"\n`" and len(stripped) > 100:
            # Check if it looks like mid-word truncation
            last_line = stripped.split("\n")[-1].strip()
            if last_line and not last_line.endswith((":", "{", "[", "(", ",")):
                words = last_line.split()
                if words and len(words[-1]) < 3:  # Likely mid-word
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        validation_type=ValidationType.TRUNCATION,
                        message="Response may be truncated (incomplete final sentence)",
                        suggestion="Increase max_tokens",
                    ))

        return issues

    def _check_format(self, response: str, expected: str) -> list[ValidationIssue]:
        """Validate response matches expected format."""
        issues: list[ValidationIssue] = []

        if expected == "json":
            try:
                json.loads(response)
            except json.JSONDecodeError as exc:
                # Try extracting from code block
                extracted, _ = self.extract_json(response)
                if extracted is None:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        validation_type=ValidationType.FORMAT,
                        message=f"Expected JSON but got invalid JSON: {exc}",
                        suggestion="Wrap response in valid JSON",
                    ))

        elif expected == "markdown":
            # Check for basic markdown structure
            has_headers = bool(re.search(r"^#{1,6}\s", response, re.MULTILINE))
            has_formatting = any(
                marker in response for marker in ("**", "__", "```", "- ", "1. ")
            )
            if not has_headers and not has_formatting and len(response) > 200:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.INFO,
                    validation_type=ValidationType.FORMAT,
                    message="Expected markdown but response lacks markdown formatting",
                    suggestion="Add headers and formatting for better readability",
                ))

        elif expected == "code" and "```" not in response and not self._looks_like_code(response):
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    validation_type=ValidationType.FORMAT,
                    message="Expected code but response doesn't contain code blocks",
                    suggestion="Wrap code in ``` code blocks",
                ))

        return issues

    def _check_json_schema(
        self, response: str, schema: dict[str, Any],
    ) -> list[ValidationIssue]:
        """Validate response against a JSON schema (basic validation)."""
        issues: list[ValidationIssue] = []

        parsed, extract_issues = self.extract_json(response)
        issues.extend(extract_issues)

        if parsed is None:
            return issues

        # Basic type checking
        expected_type = schema.get("type")
        if expected_type == "object" and not isinstance(parsed, dict):
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                validation_type=ValidationType.JSON_SCHEMA,
                message=f"Expected JSON object but got {type(parsed).__name__}",
            ))
        elif expected_type == "array" and not isinstance(parsed, list):
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                validation_type=ValidationType.JSON_SCHEMA,
                message=f"Expected JSON array but got {type(parsed).__name__}",
            ))

        # Check required properties
        if isinstance(parsed, dict):
            required = schema.get("required", [])
            for prop in required:
                if prop not in parsed:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        validation_type=ValidationType.JSON_SCHEMA,
                        message=f"Missing required property: '{prop}'",
                        location=f"$.{prop}",
                        suggestion=f"Add the '{prop}' field to the JSON response",
                    ))

            # Check property types
            properties = schema.get("properties", {})
            for prop, prop_schema in properties.items():
                if prop in parsed:
                    prop_type = prop_schema.get("type")
                    value = parsed[prop]
                    if not self._check_json_type(value, prop_type):
                        issues.append(ValidationIssue(
                            severity=ValidationSeverity.ERROR,
                            validation_type=ValidationType.JSON_SCHEMA,
                            message=f"Property '{prop}' has wrong type: expected {prop_type}, got {type(value).__name__}",
                            location=f"$.{prop}",
                        ))

        return issues

    def _check_json_type(self, value: Any, expected: str | None) -> bool:
        """Check if a value matches an expected JSON type."""
        if expected is None:
            return True
        type_map = {
            "string": str,
            "number": (int, float),
            "integer": int,
            "boolean": bool,
            "array": list,
            "object": dict,
            "null": type(None),
        }
        expected_type = type_map.get(expected)
        if expected_type is None:
            return True
        return isinstance(value, expected_type)

    def _check_code_syntax(
        self, response: str, language: str,
    ) -> list[ValidationIssue]:
        """Basic syntax validation for code responses."""
        issues: list[ValidationIssue] = []

        blocks = self.extract_code_blocks(response)
        if not blocks:
            # Try treating entire response as code
            code = response.strip()
            if code:
                issues.extend(self._validate_code_block(code, language))
        else:
            for block in blocks:
                issues.extend(self._validate_code_block(block["code"], language))

        return issues

    def _validate_code_block(
        self, code: str, language: str,
    ) -> list[ValidationIssue]:
        """Validate a single code block."""
        issues: list[ValidationIssue] = []

        if language in ("python", "py"):
            # Check for common Python syntax issues
            if code.count("def ") > 0 or code.count("class ") > 0:
                # Check indentation consistency
                lines = code.split("\n")
                indent_chars: set[str] = set()
                for line in lines:
                    if line and line[0] in (" ", "\t"):
                        indent_chars.add(line[0])
                if len(indent_chars) > 1:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        validation_type=ValidationType.CODE_SYNTAX,
                        message="Mixed indentation (tabs and spaces)",
                        suggestion="Use consistent indentation",
                    ))

            # Check for unclosed strings
            for quote in ('"""', "'''"):
                if code.count(quote) % 2 != 0:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        validation_type=ValidationType.CODE_SYNTAX,
                        message=f"Unclosed triple-quote string ({quote})",
                        suggestion="Close the triple-quoted string",
                    ))

        elif language in ("javascript", "js", "typescript", "ts"):
            # Check for unclosed template literals
            if code.count("`") % 2 != 0:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    validation_type=ValidationType.CODE_SYNTAX,
                    message="Unclosed template literal (backtick)",
                    suggestion="Close the template literal",
                ))

        return issues

    def _check_pii_leakage(self, response: str) -> list[ValidationIssue]:
        """Check for potential PII in response."""
        issues: list[ValidationIssue] = []

        for pii_type, pattern in _PII_PATTERNS.items():
            matches = pattern.findall(response)
            if matches:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    validation_type=ValidationType.CONTENT_SAFETY,
                    message=f"Potential {pii_type.replace('_', ' ')} detected ({len(matches)} occurrence(s))",
                    suggestion="Review and redact PII before sharing",
                ))

        return issues

    def _check_secret_leakage(self, response: str) -> list[ValidationIssue]:
        """Check for potential secrets in response."""
        issues: list[ValidationIssue] = []

        for secret_type, pattern in _SECRET_PATTERNS.items():
            if pattern.search(response):
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.ERROR,
                    validation_type=ValidationType.CONTENT_SAFETY,
                    message=f"Potential {secret_type.replace('_', ' ')} detected in response",
                    suggestion="Remove secrets before using this response",
                ))

        return issues

    def _check_brackets(self, response: str) -> list[ValidationIssue]:
        """Check for unbalanced brackets in code-heavy responses."""
        issues: list[ValidationIssue] = []

        # Only check if response looks code-heavy
        if not self._looks_like_code(response):
            return issues

        # Remove string contents to avoid false positives
        cleaned = re.sub(r'(""".*?"""|\'\'\'.*?\'\'\'|".*?"|\'.*?\')', '', response, flags=re.DOTALL)

        stack: list[str] = []
        for char in cleaned:
            if char in _BRACKET_PAIRS:
                stack.append(char)
            elif char in _BRACKET_PAIRS.values():
                if not stack:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        validation_type=ValidationType.CODE_SYNTAX,
                        message=f"Unmatched closing bracket: '{char}'",
                        suggestion="Check bracket balancing",
                    ))
                    break
                expected = _BRACKET_PAIRS[stack[-1]]
                if char == expected:
                    stack.pop()
                else:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        validation_type=ValidationType.CODE_SYNTAX,
                        message=f"Mismatched brackets: expected '{expected}', got '{char}'",
                        suggestion="Fix bracket matching",
                    ))
                    break

        if stack:
            unclosed = "".join(stack[-3:])  # Show last 3 unclosed
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                validation_type=ValidationType.CODE_SYNTAX,
                message=f"Unclosed brackets: {unclosed}",
                suggestion="Close all open brackets",
            ))

        return issues

    def _looks_like_code(self, text: str) -> bool:
        """Heuristic check if text appears to be code."""
        code_indicators = [
            "def ", "class ", "function ", "const ", "let ", "var ",
            "import ", "from ", "require(", "module.exports",
            "if (", "for (", "while (", "switch (",
            "return ", "async ", "await ",
        ]
        indicator_count = sum(1 for ind in code_indicators if ind in text)
        return indicator_count >= 2

    def _calculate_score(self, issues: list[ValidationIssue]) -> float:
        """Calculate overall quality score based on issues."""
        if not issues:
            return 1.0

        penalty = 0.0
        for issue in issues:
            if issue.severity == ValidationSeverity.ERROR:
                penalty += 0.3
            elif issue.severity == ValidationSeverity.WARNING:
                penalty += 0.1
            else:
                penalty += 0.02

        return max(0.0, 1.0 - penalty)

    # ------------------------------------------------------------------
    # Repair methods
    # ------------------------------------------------------------------

    def _repair_format(self, response: str, issue: ValidationIssue) -> str:
        """Attempt to repair format issues."""
        if "Expected JSON" in issue.message:
            # Try to extract JSON from markdown code blocks
            extracted, _ = self.extract_json(response)
            if extracted is not None:
                return json.dumps(extracted, indent=2)
        return response

    def _repair_json(self, response: str, issue: ValidationIssue) -> str:
        """Attempt to repair JSON issues."""
        # Try common JSON repairs
        text = response.strip()

        # Remove trailing commas before } or ]
        text = re.sub(r",\s*([}\]])", r"\1", text)

        # Try parsing after repair
        try:
            parsed = json.loads(text)
            return json.dumps(parsed, indent=2)
        except json.JSONDecodeError:
            return response

    def _redact_sensitive(self, response: str, issue: ValidationIssue) -> str:
        """Redact detected sensitive content."""
        result = response

        # Redact secrets
        for pattern in _SECRET_PATTERNS.values():
            result = pattern.sub("[REDACTED]", result)

        return result
