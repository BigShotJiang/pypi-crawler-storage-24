"""Circuit breaker with smart retry logic for LLM provider resilience.

Implements the circuit breaker pattern per provider, a smart retry strategy
that adapts to error types, and an orchestrator that combines both with
provider fallback for robust multi-provider execution.

Typical usage::

    config = CircuitBreakerConfig(failure_threshold=5, recovery_timeout_s=30)
    breaker = CircuitBreaker(config)
    retry = SmartRetryStrategy(max_retries=3)
    orchestrator = RetryOrchestrator(breaker, retry)

    result = await orchestrator.execute_with_retry(
        providers=["openai", "anthropic", "google"],
        fn=my_completion_call,
    )
"""

from __future__ import annotations

import asyncio
import enum
import random
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, TypeVar

import structlog

from prism.exceptions import (
    AllProvidersFailedError,
    ProviderAuthError,
    ProviderQuotaError,
    ProviderRateLimitError,
    ProviderUnavailableError,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

logger = structlog.get_logger(__name__)

T = TypeVar("T")


# ======================================================================
# Error type classification
# ======================================================================


class ErrorType(enum.Enum):
    """Classification of errors for retry strategy decisions."""

    RATE_LIMIT = "rate_limit"
    SERVER_ERROR = "server_error"
    AUTH_ERROR = "auth_error"
    TIMEOUT = "timeout"
    CONNECTION_ERROR = "connection_error"
    QUOTA_EXHAUSTED = "quota_exhausted"
    UNKNOWN = "unknown"


def classify_error(
    error: Exception,
    response_status: int | None = None,
) -> ErrorType:
    """Classify an exception into an ErrorType for retry decisions.

    Args:
        error: The exception that occurred.
        response_status: Optional HTTP status code from the response.

    Returns:
        The classified ErrorType.
    """
    if isinstance(error, ProviderAuthError):
        return ErrorType.AUTH_ERROR
    if isinstance(error, ProviderQuotaError):
        return ErrorType.QUOTA_EXHAUSTED
    if isinstance(error, ProviderRateLimitError):
        return ErrorType.RATE_LIMIT
    if isinstance(error, ProviderUnavailableError):
        return ErrorType.SERVER_ERROR
    if isinstance(error, TimeoutError | asyncio.TimeoutError):
        return ErrorType.TIMEOUT
    if isinstance(error, ConnectionError | OSError):
        return ErrorType.CONNECTION_ERROR

    # Fall back to HTTP status code classification.
    if response_status is not None:
        if response_status == 429:
            return ErrorType.RATE_LIMIT
        if response_status in {401, 403}:
            return ErrorType.AUTH_ERROR
        if response_status >= 500:
            return ErrorType.SERVER_ERROR

    return ErrorType.UNKNOWN


# ======================================================================
# Circuit breaker state machine
# ======================================================================


class CircuitState(enum.Enum):
    """State of a circuit breaker.

    CLOSED: Normal operation, requests flow through.
    OPEN: Too many failures, requests are rejected immediately.
    HALF_OPEN: Recovery testing, a limited number of requests are allowed.
    """

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class _ProviderCircuit:
    """Internal mutable state for a single provider's circuit."""

    state: CircuitState = CircuitState.CLOSED
    consecutive_failures: int = 0
    consecutive_successes_in_half_open: int = 0
    half_open_calls: int = 0
    total_failures: int = 0
    total_successes: int = 0
    last_failure_time: float | None = None
    last_failure_error: str | None = None
    last_state_change_time: float = field(default_factory=time.monotonic)
    transition_history: list[tuple[float, CircuitState, CircuitState]] = field(
        default_factory=list,
    )


@dataclass(frozen=True)
class CircuitBreakerConfig:
    """Configuration for the circuit breaker.

    Attributes:
        failure_threshold: Number of consecutive failures before opening.
        recovery_timeout_s: Seconds to wait in OPEN before moving to HALF_OPEN.
        half_open_max_calls: Max probe calls allowed in HALF_OPEN state.
        success_threshold_to_close: Consecutive successes in HALF_OPEN needed
            to transition back to CLOSED.
    """

    failure_threshold: int = 5
    recovery_timeout_s: float = 60.0
    half_open_max_calls: int = 3
    success_threshold_to_close: int = 2


class CircuitBreaker:
    """Per-provider circuit breaker implementing the three-state pattern.

    Tracks consecutive failures for each provider and transitions through
    CLOSED -> OPEN -> HALF_OPEN -> CLOSED (or back to OPEN) automatically.

    Thread-safe via asyncio lock (single event loop assumed).

    Args:
        config: Circuit breaker configuration. Uses defaults if not provided.
    """

    def __init__(self, config: CircuitBreakerConfig | None = None) -> None:
        self._config = config or CircuitBreakerConfig()
        self._circuits: dict[str, _ProviderCircuit] = {}
        self._lock = asyncio.Lock()

    def _get_or_create(self, provider: str) -> _ProviderCircuit:
        """Get or lazily create the circuit state for a provider.

        Args:
            provider: Provider identifier.

        Returns:
            The mutable circuit state for the provider.
        """
        if provider not in self._circuits:
            self._circuits[provider] = _ProviderCircuit()
        return self._circuits[provider]

    def _transition(
        self,
        circuit: _ProviderCircuit,
        provider: str,
        new_state: CircuitState,
    ) -> None:
        """Record a state transition.

        Args:
            circuit: The circuit to transition.
            provider: Provider name for logging.
            new_state: The target state.
        """
        old_state = circuit.state
        if old_state == new_state:
            return
        now = time.monotonic()
        circuit.transition_history.append((now, old_state, new_state))
        circuit.state = new_state
        circuit.last_state_change_time = now

        logger.info(
            "circuit_state_transition",
            provider=provider,
            from_state=old_state.value,
            to_state=new_state.value,
        )

    def _maybe_transition_to_half_open(
        self,
        circuit: _ProviderCircuit,
        provider: str,
    ) -> None:
        """If circuit is OPEN and recovery timeout has elapsed, move to HALF_OPEN.

        Args:
            circuit: The circuit to check.
            provider: Provider name for logging.
        """
        if circuit.state != CircuitState.OPEN:
            return
        elapsed = time.monotonic() - circuit.last_state_change_time
        if elapsed >= self._config.recovery_timeout_s:
            circuit.consecutive_successes_in_half_open = 0
            circuit.half_open_calls = 0
            self._transition(circuit, provider, CircuitState.HALF_OPEN)

    async def can_execute(self, provider: str) -> bool:
        """Check whether a request to the given provider is allowed.

        Automatically transitions OPEN -> HALF_OPEN when the recovery
        timeout has elapsed.

        Args:
            provider: Provider identifier.

        Returns:
            True if the circuit is CLOSED or HALF_OPEN (with capacity).
        """
        async with self._lock:
            circuit = self._get_or_create(provider)
            self._maybe_transition_to_half_open(circuit, provider)

            if circuit.state == CircuitState.CLOSED:
                return True
            if circuit.state == CircuitState.HALF_OPEN:
                return circuit.half_open_calls < self._config.half_open_max_calls
            # OPEN
            return False

    async def record_success(self, provider: str) -> None:
        """Record a successful call to the provider.

        In HALF_OPEN state, increments the success counter and transitions
        to CLOSED once the success threshold is reached.

        Args:
            provider: Provider identifier.
        """
        async with self._lock:
            circuit = self._get_or_create(provider)
            self._maybe_transition_to_half_open(circuit, provider)
            circuit.total_successes += 1
            circuit.consecutive_failures = 0

            if circuit.state == CircuitState.HALF_OPEN:
                circuit.consecutive_successes_in_half_open += 1
                circuit.half_open_calls += 1
                if (
                    circuit.consecutive_successes_in_half_open
                    >= self._config.success_threshold_to_close
                ):
                    self._transition(circuit, provider, CircuitState.CLOSED)
                    circuit.consecutive_successes_in_half_open = 0
                    circuit.half_open_calls = 0

            logger.debug(
                "circuit_record_success",
                provider=provider,
                state=circuit.state.value,
                total_successes=circuit.total_successes,
            )

    async def record_failure(
        self,
        provider: str,
        error: Exception,
    ) -> None:
        """Record a failed call to the provider.

        Increments failure counters and transitions CLOSED -> OPEN when
        the failure threshold is reached, or HALF_OPEN -> OPEN on any
        failure.

        Args:
            provider: Provider identifier.
            error: The exception that occurred.
        """
        async with self._lock:
            circuit = self._get_or_create(provider)
            self._maybe_transition_to_half_open(circuit, provider)
            circuit.total_failures += 1
            circuit.consecutive_failures += 1
            circuit.last_failure_time = time.monotonic()
            circuit.last_failure_error = str(error)

            if circuit.state == CircuitState.HALF_OPEN:
                # Any failure in HALF_OPEN trips back to OPEN.
                circuit.half_open_calls += 1
                circuit.consecutive_successes_in_half_open = 0
                self._transition(circuit, provider, CircuitState.OPEN)

            elif circuit.state == CircuitState.CLOSED:
                if circuit.consecutive_failures >= self._config.failure_threshold:
                    self._transition(circuit, provider, CircuitState.OPEN)

            logger.warning(
                "circuit_record_failure",
                provider=provider,
                state=circuit.state.value,
                consecutive_failures=circuit.consecutive_failures,
                error=str(error),
            )

    async def get_state(self, provider: str) -> CircuitState:
        """Get the current circuit state for a provider.

        Automatically checks for OPEN -> HALF_OPEN transitions.

        Args:
            provider: Provider identifier.

        Returns:
            The current CircuitState.
        """
        async with self._lock:
            circuit = self._get_or_create(provider)
            self._maybe_transition_to_half_open(circuit, provider)
            return circuit.state

    async def get_all_states(self) -> dict[str, CircuitState]:
        """Get the current circuit state for every tracked provider.

        Returns:
            Dict mapping provider name to CircuitState.
        """
        async with self._lock:
            result: dict[str, CircuitState] = {}
            for provider, circuit in self._circuits.items():
                self._maybe_transition_to_half_open(circuit, provider)
                result[provider] = circuit.state
            return result

    async def force_open(self, provider: str) -> None:
        """Manually trip the circuit to OPEN state.

        Args:
            provider: Provider identifier.
        """
        async with self._lock:
            circuit = self._get_or_create(provider)
            self._transition(circuit, provider, CircuitState.OPEN)

    async def force_close(self, provider: str) -> None:
        """Manually close the circuit (return to normal operation).

        Resets failure counters so the circuit stays closed.

        Args:
            provider: Provider identifier.
        """
        async with self._lock:
            circuit = self._get_or_create(provider)
            circuit.consecutive_failures = 0
            circuit.consecutive_successes_in_half_open = 0
            circuit.half_open_calls = 0
            self._transition(circuit, provider, CircuitState.CLOSED)

    async def reset(self, provider: str) -> None:
        """Reset a provider's circuit to its initial state.

        Removes all tracked history and counters.

        Args:
            provider: Provider identifier.
        """
        async with self._lock:
            self._circuits[provider] = _ProviderCircuit()
            logger.info("circuit_reset", provider=provider)

    async def get_stats(self, provider: str) -> dict[str, Any]:
        """Get detailed statistics for a provider's circuit.

        Args:
            provider: Provider identifier.

        Returns:
            Dict containing failure_count, success_count, consecutive_failures,
            last_failure_time, last_failure_error, state, and transition_history.
        """
        async with self._lock:
            circuit = self._get_or_create(provider)
            self._maybe_transition_to_half_open(circuit, provider)
            return {
                "state": circuit.state.value,
                "failure_count": circuit.total_failures,
                "success_count": circuit.total_successes,
                "consecutive_failures": circuit.consecutive_failures,
                "last_failure_time": circuit.last_failure_time,
                "last_failure_error": circuit.last_failure_error,
                "transition_history": [
                    {
                        "timestamp": ts,
                        "from_state": from_s.value,
                        "to_state": to_s.value,
                    }
                    for ts, from_s, to_s in circuit.transition_history
                ],
            }


# ======================================================================
# Smart retry strategy
# ======================================================================


# Errors that should never be retried.
_NO_RETRY_ERRORS: frozenset[ErrorType] = frozenset({
    ErrorType.AUTH_ERROR,
    ErrorType.QUOTA_EXHAUSTED,
})

# Base delays per error type (seconds).
_BASE_DELAY_OVERRIDES: dict[ErrorType, float] = {
    ErrorType.RATE_LIMIT: 2.0,
    ErrorType.SERVER_ERROR: 1.0,
    ErrorType.TIMEOUT: 0.5,
    ErrorType.CONNECTION_ERROR: 1.0,
    ErrorType.UNKNOWN: 1.0,
}


@dataclass(frozen=True)
class SmartRetryConfig:
    """Configuration for the smart retry strategy.

    Attributes:
        max_retries: Maximum number of retry attempts (0 = no retries).
        base_delay: Default base delay in seconds.
        max_delay: Maximum delay cap in seconds.
        exponential_base: Multiplier for exponential backoff.
    """

    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 30.0
    exponential_base: float = 2.0


class SmartRetryStrategy:
    """Adaptive retry strategy that varies behavior by error type.

    Uses decorrelated jitter for backoff timing, respects Retry-After
    headers from rate-limited responses, and refuses to retry
    authentication or quota errors.

    Args:
        config: Retry configuration. Uses defaults if not provided.
    """

    def __init__(self, config: SmartRetryConfig | None = None) -> None:
        self._config = config or SmartRetryConfig()
        # Tracks the last delay per provider for decorrelated jitter.
        self._last_delay: dict[str, float] = {}

    @property
    def max_retries(self) -> int:
        """The configured maximum number of retries."""
        return self._config.max_retries

    def should_retry(
        self,
        attempt: int,
        error: Exception,
        response_status: int | None = None,
        retry_after: float | None = None,
    ) -> tuple[bool, float]:
        """Determine whether to retry and the delay before doing so.

        Args:
            attempt: Zero-based attempt index (0 = first attempt that just failed).
            error: The exception that occurred.
            response_status: Optional HTTP status code.
            retry_after: Optional Retry-After value from the response (seconds).

        Returns:
            Tuple of (should_retry, delay_seconds). If should_retry is False,
            delay_seconds is 0.0.
        """
        error_type = classify_error(error, response_status)

        # Never retry auth or quota errors.
        if error_type in _NO_RETRY_ERRORS:
            logger.debug(
                "retry_skipped_non_retryable",
                error_type=error_type.value,
                attempt=attempt,
            )
            return (False, 0.0)

        # Check attempt limit.
        if attempt >= self._config.max_retries:
            logger.debug(
                "retry_skipped_max_attempts",
                attempt=attempt,
                max_retries=self._config.max_retries,
            )
            return (False, 0.0)

        # Calculate delay.
        delay = self.get_retry_delay(attempt, error_type)

        # Respect Retry-After header for rate limits.
        if error_type == ErrorType.RATE_LIMIT and retry_after is not None:
            delay = max(delay, retry_after)

        # Also check ProviderRateLimitError.retry_after attribute.
        if (
            error_type == ErrorType.RATE_LIMIT
            and isinstance(error, ProviderRateLimitError)
            and error.retry_after is not None
            and retry_after is None
        ):
            delay = max(delay, error.retry_after)

        delay = min(delay, self._config.max_delay)

        logger.info(
            "retry_decision",
            should_retry=True,
            attempt=attempt,
            error_type=error_type.value,
            delay_s=round(delay, 3),
        )
        return (True, delay)

    def get_retry_delay(
        self,
        attempt: int,
        error_type: ErrorType,
        *,
        provider: str = "__default__",
    ) -> float:
        """Calculate the retry delay using decorrelated jitter.

        The decorrelated jitter algorithm::

            delay = random(base_delay, last_delay * 3)
            delay = min(delay, max_delay)

        This produces less correlated backoff than full jitter while
        avoiding the thundering herd problem.

        Args:
            attempt: Zero-based attempt index.
            error_type: The classified error type.
            provider: Provider name for tracking decorrelated state.

        Returns:
            Delay in seconds.
        """
        base = _BASE_DELAY_OVERRIDES.get(error_type, self._config.base_delay)

        if attempt == 0:
            # First retry: use base delay with some jitter.
            delay = random.uniform(base * 0.5, base * 1.5)  # noqa: S311
            self._last_delay[provider] = delay
            return min(delay, self._config.max_delay)

        # Decorrelated jitter: delay = random(base, last_delay * 3)
        last = self._last_delay.get(provider, base)
        upper = last * self._config.exponential_base * 1.5
        delay = random.uniform(base, max(base, upper))  # noqa: S311
        delay = min(delay, self._config.max_delay)
        self._last_delay[provider] = delay
        return delay

    def reset(self, provider: str | None = None) -> None:
        """Reset decorrelated jitter state.

        Args:
            provider: Provider to reset. If None, resets all.
        """
        if provider is None:
            self._last_delay.clear()
        else:
            self._last_delay.pop(provider, None)


# ======================================================================
# Retry orchestrator
# ======================================================================


class RetryOrchestrator:
    """Combines CircuitBreaker + SmartRetryStrategy + provider fallback.

    Given a list of providers in preference order, the orchestrator:

    1. Skips providers whose circuits are OPEN.
    2. Attempts the call on the first available provider.
    3. On failure, applies the smart retry strategy.
    4. Once retries are exhausted for a provider, falls back to the next.
    5. Raises ``AllProvidersFailedError`` if every provider is exhausted.

    Args:
        circuit_breaker: CircuitBreaker instance for gating.
        retry_strategy: SmartRetryStrategy instance for retry decisions.
    """

    def __init__(
        self,
        circuit_breaker: CircuitBreaker,
        retry_strategy: SmartRetryStrategy,
    ) -> None:
        self._breaker = circuit_breaker
        self._retry = retry_strategy

    async def execute_with_retry(
        self,
        providers: list[str],
        fn: Callable[[str], Awaitable[T]],
    ) -> T:
        """Execute an async function with circuit breaker gating, retry, and fallback.

        The callable ``fn`` receives the provider name as its sole argument
        and should perform the actual API call.

        Args:
            providers: Providers in preference order.
            fn: Async callable that takes a provider name and returns a result.

        Returns:
            The result from the first successful call.

        Raises:
            AllProvidersFailedError: If all providers fail after retries.
        """
        if not providers:
            raise AllProvidersFailedError(
                tried_models=[],
                last_error="No providers supplied",
            )

        tried: list[str] = []
        last_error_str = ""

        for provider in providers:
            # Check circuit breaker.
            allowed = await self._breaker.can_execute(provider)
            if not allowed:
                state = await self._breaker.get_state(provider)
                logger.info(
                    "orchestrator_skip_provider",
                    provider=provider,
                    circuit_state=state.value,
                )
                continue

            tried.append(provider)
            result = await self._try_provider(provider, fn)
            if result is not _SENTINEL:
                return result  # type: ignore[return-value]

            # Provider exhausted, update last error.
            stats = await self._breaker.get_stats(provider)
            last_error_str = stats.get("last_failure_error", "unknown error")

        # All providers failed.
        logger.error(
            "orchestrator_all_providers_failed",
            tried=tried,
            total_providers=len(providers),
            last_error=last_error_str,
        )
        raise AllProvidersFailedError(
            tried_models=tried,
            last_error=last_error_str,
        )

    async def _try_provider(
        self,
        provider: str,
        fn: Callable[[str], Awaitable[Any]],
    ) -> Any:
        """Attempt to call fn on a single provider with retries.

        Args:
            provider: The provider to try.
            fn: The async callable.

        Returns:
            The result on success, or _SENTINEL if all attempts failed.
        """
        for attempt in range(self._retry.max_retries + 1):
            try:
                result = await fn(provider)
                await self._breaker.record_success(provider)
                logger.info(
                    "orchestrator_call_success",
                    provider=provider,
                    attempt=attempt,
                )
                return result

            except Exception as exc:
                await self._breaker.record_failure(provider, exc)

                # Extract retry_after from ProviderRateLimitError.
                retry_after: float | None = None
                if isinstance(exc, ProviderRateLimitError):
                    retry_after = exc.retry_after

                # Extract status code if available.
                response_status: int | None = getattr(exc, "status_code", None)

                should_retry, delay = self._retry.should_retry(
                    attempt=attempt,
                    error=exc,
                    response_status=response_status,
                    retry_after=retry_after,
                )

                if not should_retry:
                    logger.warning(
                        "orchestrator_no_retry",
                        provider=provider,
                        attempt=attempt,
                        error=str(exc),
                        error_type=classify_error(exc, response_status).value,
                    )
                    break

                # Check if circuit breaker still allows calls.
                allowed = await self._breaker.can_execute(provider)
                if not allowed:
                    logger.info(
                        "orchestrator_circuit_opened_during_retry",
                        provider=provider,
                        attempt=attempt,
                    )
                    break

                logger.info(
                    "orchestrator_retry",
                    provider=provider,
                    attempt=attempt,
                    delay_s=round(delay, 3),
                    error=str(exc),
                )
                await asyncio.sleep(delay)

        return _SENTINEL


# Sentinel object used internally to indicate "no result" without conflicting
# with None (which is a valid return value from fn).
_SENTINEL = object()
