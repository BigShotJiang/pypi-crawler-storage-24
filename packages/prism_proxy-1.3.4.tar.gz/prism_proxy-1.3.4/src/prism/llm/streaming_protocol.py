"""Server-Sent Events (SSE) streaming protocol engine.

Provides a production-quality, composable streaming infrastructure for LLM
responses. Includes:

- ``StreamChunk``: typed representation of a single SSE frame.
- ``StreamAccumulator``: assembles chunks into a complete response.
- ``StreamTransformer``: token-by-token transformations and code-block detection.
- ``StreamTee``: fans a single async stream out to multiple consumers.
- ``BackpressureController``: bounded-buffer flow control for slow consumers.

All classes implement the async iterator protocol (``__aiter__`` / ``__anext__``)
so they compose naturally::

    source = some_async_stream()
    controlled = BackpressureController(source, max_buffer=64)
    tee1, tee2 = StreamTee(controlled, fan_out=2).streams()
    async for chunk in tee1:
        ...
"""

from __future__ import annotations

import asyncio
import enum
import re
import time
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_CODE_FENCE_RE = re.compile(r"^```(\w*)", re.MULTILINE)

# Default backpressure settings
_DEFAULT_MAX_BUFFER = 128
_DEFAULT_HIGH_WATERMARK = 0.75
_DEFAULT_LOW_WATERMARK = 0.25


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ContentType(enum.StrEnum):
    """Content types that may appear in a streaming response."""

    TEXT = "text"
    CODE = "code"
    IMAGE = "image"
    AUDIO = "audio"
    TOOL_CALL = "tool_call"
    THINKING = "thinking"


class FinishReason(enum.StrEnum):
    """Standardised finish reasons across providers."""

    STOP = "stop"
    LENGTH = "length"
    TOOL_CALLS = "tool_calls"
    CONTENT_FILTER = "content_filter"
    ERROR = "error"


# ---------------------------------------------------------------------------
# StreamChunk — a single SSE frame
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class StreamChunk:
    """A single chunk from an SSE streaming response.

    Attributes:
        delta: Incremental text content (may be empty).
        finish_reason: Non-None on the final chunk.
        content_type: The type of content this chunk carries.
        usage: Token usage statistics (typically only on the final chunk).
        tool_call_delta: Incremental tool-call data, if any.
        thinking_delta: Incremental thinking/reasoning content, if any.
        latency_ms: Time since the previous chunk (set by the source).
        chunk_index: Monotonically increasing index within the stream.
        raw: The original provider-specific payload, for debugging.
    """

    delta: str = ""
    finish_reason: FinishReason | None = None
    content_type: ContentType = ContentType.TEXT
    usage: UsageStats | None = None
    tool_call_delta: ToolCallDelta | None = None
    thinking_delta: ThinkingDelta | None = None
    latency_ms: float = 0.0
    chunk_index: int = 0
    raw: dict[str, Any] | None = field(default=None, repr=False)

    @property
    def is_final(self) -> bool:
        """Whether this chunk terminates the stream."""
        return self.finish_reason is not None

    @property
    def has_content(self) -> bool:
        """Whether this chunk carries any displayable content."""
        return bool(self.delta) or self.tool_call_delta is not None or self.thinking_delta is not None


@dataclass(frozen=True, slots=True)
class UsageStats:
    """Token usage statistics reported by the provider.

    Attributes:
        prompt_tokens: Tokens consumed by the input prompt.
        completion_tokens: Tokens generated in the response.
        cached_tokens: Tokens served from cache (provider-dependent).
        thinking_tokens: Tokens used for chain-of-thought reasoning.
        total_tokens: Sum of all token categories.
    """

    prompt_tokens: int = 0
    completion_tokens: int = 0
    cached_tokens: int = 0
    thinking_tokens: int = 0
    total_tokens: int = 0


@dataclass(frozen=True, slots=True)
class ToolCallDelta:
    """Incremental data for an in-progress tool call.

    Attributes:
        index: The tool-call index (for parallel tool calls).
        call_id: Unique identifier for this tool call (first chunk only).
        function_name: Function name (first chunk only, or empty).
        arguments_delta: Incremental JSON fragment for the arguments.
    """

    index: int = 0
    call_id: str = ""
    function_name: str = ""
    arguments_delta: str = ""


@dataclass(frozen=True, slots=True)
class ThinkingDelta:
    """Incremental data for a thinking / reasoning block.

    Attributes:
        content: Incremental thinking text.
        thinking_tokens: Tokens consumed so far (if reported).
    """

    content: str = ""
    thinking_tokens: int = 0


# ---------------------------------------------------------------------------
# StreamAccumulator — assembles chunks into a complete response
# ---------------------------------------------------------------------------


@dataclass
class _ToolCallAccumulator:
    """Internal accumulator for a single tool call being assembled."""

    call_id: str = ""
    function_name: str = ""
    arguments: str = ""


class StreamAccumulator:
    """Accumulates ``StreamChunk`` objects into a complete response.

    Handles text content, tool calls (assembled by index), and thinking
    blocks. Implements the async iterator protocol — feed it a source
    stream and iterate to get chunks while accumulation happens in the
    background.

    Usage::

        acc = StreamAccumulator()
        async for chunk in acc.consume(source_stream):
            print(chunk.delta, end="")
        result = acc.result()
    """

    def __init__(self) -> None:
        self._text_parts: list[str] = []
        self._thinking_parts: list[str] = []
        self._tool_calls: dict[int, _ToolCallAccumulator] = {}
        self._finish_reason: FinishReason | None = None
        self._usage: UsageStats | None = None
        self._chunk_count: int = 0
        self._start_time: float = 0.0
        self._end_time: float = 0.0
        self._source: AsyncIterator[StreamChunk] | None = None

    # -- Async iterator protocol -------------------------------------------

    def consume(self, source: AsyncIterator[StreamChunk]) -> StreamAccumulator:
        """Bind a source stream and return self for async iteration.

        Args:
            source: Async iterator of ``StreamChunk`` objects.

        Returns:
            Self, for ``async for chunk in acc.consume(source):`` usage.
        """
        self._source = source
        self._start_time = time.monotonic()
        return self

    def __aiter__(self) -> StreamAccumulator:
        return self

    async def __anext__(self) -> StreamChunk:
        if self._source is None:
            raise StopAsyncIteration

        try:
            chunk = await self._source.__anext__()
        except StopAsyncIteration:
            self._end_time = time.monotonic()
            raise

        self._accumulate(chunk)
        return chunk

    # -- Accumulation logic -------------------------------------------------

    def _accumulate(self, chunk: StreamChunk) -> None:
        """Incorporate a single chunk into the accumulated state."""
        self._chunk_count += 1

        # Text content
        if chunk.delta:
            self._text_parts.append(chunk.delta)

        # Thinking content
        if chunk.thinking_delta is not None and chunk.thinking_delta.content:
            self._thinking_parts.append(chunk.thinking_delta.content)

        # Tool-call deltas — assemble by index
        if chunk.tool_call_delta is not None:
            td = chunk.tool_call_delta
            if td.index not in self._tool_calls:
                self._tool_calls[td.index] = _ToolCallAccumulator(
                    call_id=td.call_id,
                    function_name=td.function_name,
                    arguments=td.arguments_delta,
                )
            else:
                existing = self._tool_calls[td.index]
                if td.call_id:
                    existing.call_id = td.call_id
                if td.function_name:
                    existing.function_name = td.function_name
                existing.arguments += td.arguments_delta

        # Usage — typically only on the final chunk
        if chunk.usage is not None:
            self._usage = chunk.usage

        # Finish reason
        if chunk.finish_reason is not None:
            self._finish_reason = chunk.finish_reason
            self._end_time = time.monotonic()

    # -- Result accessors ---------------------------------------------------

    @property
    def text(self) -> str:
        """The full accumulated text content."""
        return "".join(self._text_parts)

    @property
    def thinking_text(self) -> str:
        """The full accumulated thinking/reasoning content."""
        return "".join(self._thinking_parts)

    @property
    def tool_calls(self) -> list[dict[str, Any]]:
        """Assembled tool calls as a list of dicts (sorted by index).

        Returns:
            List of tool-call dicts with ``id``, ``type``, and ``function``
            keys matching the OpenAI tool-call schema.
        """
        result: list[dict[str, Any]] = []
        for idx in sorted(self._tool_calls):
            tc = self._tool_calls[idx]
            result.append({
                "id": tc.call_id,
                "type": "function",
                "function": {
                    "name": tc.function_name,
                    "arguments": tc.arguments,
                },
            })
        return result

    @property
    def finish_reason(self) -> FinishReason | None:
        """The finish reason from the final chunk, or None if still streaming."""
        return self._finish_reason

    @property
    def usage(self) -> UsageStats | None:
        """Token usage statistics, if reported by the provider."""
        return self._usage

    @property
    def chunk_count(self) -> int:
        """Number of chunks accumulated so far."""
        return self._chunk_count

    @property
    def elapsed_ms(self) -> float:
        """Wall-clock time from first consume() call to final chunk (or now)."""
        end = self._end_time if self._end_time > 0 else time.monotonic()
        start = self._start_time if self._start_time > 0 else end
        return (end - start) * 1000

    def result(self) -> AccumulatedResult:
        """Build a frozen snapshot of the accumulated state.

        Returns:
            An ``AccumulatedResult`` capturing text, tool calls, thinking,
            usage, timing, and finish reason.
        """
        return AccumulatedResult(
            text=self.text,
            thinking_text=self.thinking_text,
            tool_calls=self.tool_calls,
            finish_reason=self._finish_reason,
            usage=self._usage,
            chunk_count=self._chunk_count,
            elapsed_ms=self.elapsed_ms,
        )


@dataclass(frozen=True)
class AccumulatedResult:
    """Immutable snapshot of a fully accumulated stream.

    Attributes:
        text: The complete text content.
        thinking_text: The complete thinking/reasoning content.
        tool_calls: Assembled tool calls.
        finish_reason: Why the stream ended.
        usage: Token usage statistics.
        chunk_count: Total number of chunks received.
        elapsed_ms: Total wall-clock time in milliseconds.
    """

    text: str = ""
    thinking_text: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    finish_reason: FinishReason | None = None
    usage: UsageStats | None = None
    chunk_count: int = 0
    elapsed_ms: float = 0.0


# ---------------------------------------------------------------------------
# StreamTransformer — token-by-token transformations
# ---------------------------------------------------------------------------


class StreamTransformer:
    """Applies token-by-token transformations to a chunk stream.

    Supports registering custom transformation functions, automatic
    code-block detection (tracking open/close fences), and content-type
    annotation for multi-modal streams.

    Usage::

        transformer = StreamTransformer()
        transformer.add_transform(lambda text: text.upper())
        async for chunk in transformer.transform(source):
            ...
    """

    def __init__(self) -> None:
        self._transforms: list[Callable[[str], str]] = []
        self._accumulated_text: str = ""
        self._in_code_block: bool = False
        self._code_language: str = ""
        self._fence_count: int = 0
        self._source: AsyncIterator[StreamChunk] | None = None
        self._chunk_index: int = 0

    def add_transform(self, fn: Callable[[str], str]) -> StreamTransformer:
        """Register a text transformation function.

        Transforms are applied in registration order to each chunk's delta
        text. They are only applied to text content (not tool calls or
        thinking blocks).

        Args:
            fn: A callable that takes a string and returns a transformed string.

        Returns:
            Self, for chaining.
        """
        self._transforms.append(fn)
        return self

    def clear_transforms(self) -> None:
        """Remove all registered transformation functions."""
        self._transforms.clear()

    @property
    def in_code_block(self) -> bool:
        """Whether the stream is currently inside a fenced code block."""
        return self._in_code_block

    @property
    def code_language(self) -> str:
        """The language hint of the current code block (empty if none)."""
        return self._code_language

    def transform(self, source: AsyncIterator[StreamChunk]) -> StreamTransformer:
        """Bind a source stream and return self for async iteration.

        Args:
            source: Async iterator of ``StreamChunk`` objects.

        Returns:
            Self, for ``async for chunk in transformer.transform(source):``.
        """
        self._source = source
        self._accumulated_text = ""
        self._in_code_block = False
        self._code_language = ""
        self._fence_count = 0
        self._chunk_index = 0
        return self

    def __aiter__(self) -> StreamTransformer:
        return self

    async def __anext__(self) -> StreamChunk:
        if self._source is None:
            raise StopAsyncIteration

        chunk = await self._source.__anext__()
        return self._apply(chunk)

    def _apply(self, chunk: StreamChunk) -> StreamChunk:
        """Apply transformations and code-block tracking to a single chunk."""
        delta = chunk.delta
        self._chunk_index += 1

        if not delta:
            # Still classify thinking/tool_call chunks even without text delta
            if chunk.thinking_delta is not None:
                return StreamChunk(
                    delta=chunk.delta, finish_reason=chunk.finish_reason,
                    content_type=ContentType.THINKING, usage=chunk.usage,
                    tool_call_delta=chunk.tool_call_delta,
                    thinking_delta=chunk.thinking_delta,
                    latency_ms=chunk.latency_ms,
                    chunk_index=chunk.chunk_index, raw=chunk.raw,
                )
            if chunk.tool_call_delta is not None:
                return StreamChunk(
                    delta=chunk.delta, finish_reason=chunk.finish_reason,
                    content_type=ContentType.TOOL_CALL, usage=chunk.usage,
                    tool_call_delta=chunk.tool_call_delta,
                    thinking_delta=chunk.thinking_delta,
                    latency_ms=chunk.latency_ms,
                    chunk_index=chunk.chunk_index, raw=chunk.raw,
                )
            return chunk

        # Update accumulated text for code-block detection
        self._accumulated_text += delta
        self._detect_code_blocks(delta)

        # Determine content type based on state
        content_type = chunk.content_type
        if chunk.thinking_delta is not None:
            content_type = ContentType.THINKING
        elif chunk.tool_call_delta is not None:
            content_type = ContentType.TOOL_CALL
        elif self._in_code_block:
            content_type = ContentType.CODE

        # Apply text transforms (only to text/code content, not tool calls / thinking)
        transformed_delta = delta
        if content_type in (ContentType.TEXT, ContentType.CODE):
            for fn in self._transforms:
                transformed_delta = fn(transformed_delta)

        return StreamChunk(
            delta=transformed_delta,
            finish_reason=chunk.finish_reason,
            content_type=content_type,
            usage=chunk.usage,
            tool_call_delta=chunk.tool_call_delta,
            thinking_delta=chunk.thinking_delta,
            latency_ms=chunk.latency_ms,
            chunk_index=chunk.chunk_index,
            raw=chunk.raw,
        )

    def _detect_code_blocks(self, delta: str) -> None:
        """Track code fence state across incremental deltas.

        Handles the tricky case where a fence marker may be split across
        multiple chunks by checking the full accumulated text rather than
        just the delta.

        Args:
            delta: The latest text delta to process.
        """
        # Find all code fences in the accumulated text
        open_fences = list(_CODE_FENCE_RE.finditer(self._accumulated_text))

        # Each fence with a language hint is an opener;
        # a bare ``` toggles between open and close. We process them
        # in positional order to track nesting state.
        events: list[tuple[int, str, str]] = []  # (pos, "open"|"close", language)
        for m in open_fences:
            lang = m.group(1)
            # A fence with a language hint is always an opener
            if lang:
                events.append((m.start(), "open", lang))
            else:
                # Bare ``` — need to determine from context
                events.append((m.start(), "bare", ""))

        # Resolve bare fences: the first is an opener, each subsequent
        # toggles (close, open, close, ...).
        events.sort(key=lambda e: e[0])
        resolved_open = 0
        resolved_close = 0
        current_lang = ""
        for _pos, kind, lang in events:
            if kind == "open":
                resolved_open += 1
                current_lang = lang
            elif kind == "bare":
                if resolved_open > resolved_close:
                    resolved_close += 1
                else:
                    resolved_open += 1
                    current_lang = ""

        self._in_code_block = resolved_open > resolved_close
        self._code_language = current_lang if self._in_code_block else ""
        self._fence_count = resolved_open

    def detect_content_type(self, chunk: StreamChunk) -> ContentType:
        """Classify the content type of a chunk without transforming it.

        Useful for routing logic that needs to know the content type but
        should not alter the chunk.

        Args:
            chunk: The chunk to classify.

        Returns:
            The detected ``ContentType``.
        """
        if chunk.thinking_delta is not None:
            return ContentType.THINKING
        if chunk.tool_call_delta is not None:
            return ContentType.TOOL_CALL
        if self._in_code_block:
            return ContentType.CODE
        return chunk.content_type


# ---------------------------------------------------------------------------
# StreamTee — fork one stream to multiple consumers
# ---------------------------------------------------------------------------


class _TeeChannel:
    """Internal channel for a single consumer in a StreamTee.

    Each channel has its own buffer and can be iterated independently.
    """

    def __init__(self, channel_id: int) -> None:
        self._channel_id = channel_id
        self._buffer: asyncio.Queue[StreamChunk | None] = asyncio.Queue()
        self._done = False

    async def put(self, chunk: StreamChunk | None) -> None:
        """Enqueue a chunk (or None as sentinel)."""
        await self._buffer.put(chunk)

    def __aiter__(self) -> _TeeChannel:
        return self

    async def __anext__(self) -> StreamChunk:
        if self._done:
            raise StopAsyncIteration

        item = await self._buffer.get()
        if item is None:
            self._done = True
            raise StopAsyncIteration
        return item


class StreamTee:
    """Forks a single ``StreamChunk`` async stream to multiple consumers.

    Each consumer gets its own independent async iterator that yields the
    same chunks. The source stream is consumed once; chunks are replicated
    to all channels.

    Usage::

        tee = StreamTee(source, fan_out=3)
        display_stream, log_stream, metrics_stream = tee.streams()

        # Start consumers concurrently
        await asyncio.gather(
            display(display_stream),
            log(log_stream),
            collect_metrics(metrics_stream),
        )
        # Alternatively, call tee.start() to begin pumping in the background
        # and iterate each stream from separate coroutines.

    Args:
        source: The upstream async iterator of ``StreamChunk`` objects.
        fan_out: Number of consumer channels to create.
    """

    def __init__(self, source: AsyncIterator[StreamChunk], fan_out: int = 2) -> None:
        if fan_out < 1:
            msg = f"fan_out must be >= 1, got {fan_out}"
            raise ValueError(msg)
        self._source = source
        self._channels: list[_TeeChannel] = [
            _TeeChannel(i) for i in range(fan_out)
        ]
        self._pump_task: asyncio.Task[None] | None = None
        self._started = False
        self._done = False

    def streams(self) -> tuple[_TeeChannel, ...]:
        """Return the consumer channels as a tuple.

        Returns:
            Tuple of async iterators, one per ``fan_out`` count.
        """
        return tuple(self._channels)

    def start(self) -> asyncio.Task[None]:
        """Start the background pump task that reads the source and fans out.

        Must be called before iterating any consumer channel. The pump runs
        until the source is exhausted, then sends sentinels to all channels.

        Returns:
            The asyncio.Task running the pump.

        Raises:
            RuntimeError: If already started.
        """
        if self._started:
            msg = "StreamTee pump already started"
            raise RuntimeError(msg)
        self._started = True
        self._pump_task = asyncio.create_task(self._pump())
        return self._pump_task

    async def _pump(self) -> None:
        """Read chunks from the source and replicate to all channels."""
        try:
            async for chunk in self._source:
                for ch in self._channels:
                    await ch.put(chunk)
        except Exception:
            logger.exception("stream_tee_pump_error")
        finally:
            self._done = True
            for ch in self._channels:
                await ch.put(None)  # sentinel

    async def pump_sync(self) -> None:
        """Synchronously (within this coroutine) pump all chunks.

        Use this when you do not need background pumping and prefer to
        drive the pump from the caller's coroutine. Consumers must be
        started concurrently (e.g. via ``asyncio.gather``) before calling
        this, or they will deadlock.

        This is provided as an alternative to ``start()`` for contexts
        where creating a background task is undesirable.
        """
        try:
            async for chunk in self._source:
                for ch in self._channels:
                    await ch.put(chunk)
        except Exception:
            logger.exception("stream_tee_pump_sync_error")
        finally:
            self._done = True
            for ch in self._channels:
                await ch.put(None)

    @property
    def is_done(self) -> bool:
        """Whether the source stream has been fully consumed."""
        return self._done


# ---------------------------------------------------------------------------
# BackpressureController — bounded-buffer flow control
# ---------------------------------------------------------------------------


class BackpressureController:
    """Bounded-buffer flow control for streaming chunks.

    Buffers up to ``max_buffer`` chunks. When the buffer exceeds the high
    watermark, applies backpressure (pauses reading from source). Resumes
    when the consumer drains below the low watermark.

    The controller implements the async iterator protocol, so it can be
    inserted transparently into any stream pipeline::

        source = some_async_stream()
        controlled = BackpressureController(source, max_buffer=64)
        async for chunk in controlled:
            slow_consumer(chunk)

    Args:
        source: The upstream async iterator of ``StreamChunk`` objects.
        max_buffer: Maximum number of chunks to buffer.
        high_watermark: Fraction of ``max_buffer`` that triggers backpressure.
        low_watermark: Fraction of ``max_buffer`` that releases backpressure.
    """

    def __init__(
        self,
        source: AsyncIterator[StreamChunk],
        max_buffer: int = _DEFAULT_MAX_BUFFER,
        high_watermark: float = _DEFAULT_HIGH_WATERMARK,
        low_watermark: float = _DEFAULT_LOW_WATERMARK,
    ) -> None:
        if max_buffer < 1:
            msg = f"max_buffer must be >= 1, got {max_buffer}"
            raise ValueError(msg)
        if not (0.0 < low_watermark < high_watermark <= 1.0):
            msg = (
                f"Watermarks must satisfy 0 < low < high <= 1, "
                f"got low={low_watermark}, high={high_watermark}"
            )
            raise ValueError(msg)

        self._source = source
        self._max_buffer = max_buffer
        self._high_watermark = high_watermark
        self._low_watermark = low_watermark

        self._buffer: deque[StreamChunk] = deque(maxlen=max_buffer)
        self._backpressure_active = False
        self._source_exhausted = False
        self._dropped_count = 0
        self._total_received = 0
        self._total_delivered = 0

        # Synchronisation primitives
        self._buffer_not_empty: asyncio.Event = asyncio.Event()
        self._backpressure_released: asyncio.Event = asyncio.Event()
        self._backpressure_released.set()  # starts released

        self._pump_task: asyncio.Task[None] | None = None
        self._pump_started = False
        self._pump_error: BaseException | None = None

    # -- Async iterator protocol -------------------------------------------

    def __aiter__(self) -> BackpressureController:
        if not self._pump_started:
            self._pump_started = True
            self._pump_task = asyncio.create_task(self._pump())
        return self

    async def __anext__(self) -> StreamChunk:
        # Ensure pump is started (may be called without __aiter__)
        if not self._pump_started:
            self._pump_started = True
            self._pump_task = asyncio.create_task(self._pump())

        while True:
            if self._buffer:
                chunk = self._buffer.popleft()
                self._total_delivered += 1
                self._check_low_watermark()
                return chunk

            if self._source_exhausted:
                if self._pump_error is not None:
                    raise self._pump_error
                raise StopAsyncIteration

            # Wait for data — clear only when buffer is truly empty
            # and source is still active, then wait for pump to signal.
            self._buffer_not_empty.clear()
            # Re-check after clearing to avoid race with pump
            if self._buffer or self._source_exhausted:
                continue
            await self._buffer_not_empty.wait()

    # -- Background pump ----------------------------------------------------

    async def _pump(self) -> None:
        """Background task that reads from source into the buffer."""
        try:
            async for chunk in self._source:
                self._total_received += 1

                # If backpressure is active, wait for it to release
                if self._backpressure_active:
                    logger.debug(
                        "backpressure_waiting",
                        buffer_size=len(self._buffer),
                        max_buffer=self._max_buffer,
                    )
                    await self._backpressure_released.wait()

                if len(self._buffer) >= self._max_buffer:
                    # Buffer is full — drop the oldest chunk
                    self._buffer.popleft()
                    self._dropped_count += 1
                    logger.warning(
                        "backpressure_chunk_dropped",
                        dropped_total=self._dropped_count,
                        buffer_size=len(self._buffer),
                    )

                self._buffer.append(chunk)
                self._buffer_not_empty.set()
                self._check_high_watermark()

        except Exception as exc:
            logger.exception("backpressure_pump_error")
            self._pump_error = exc
        finally:
            self._source_exhausted = True
            self._buffer_not_empty.set()  # wake consumer

    def _check_high_watermark(self) -> None:
        """Engage backpressure if buffer exceeds the high watermark."""
        threshold = int(self._max_buffer * self._high_watermark)
        if len(self._buffer) >= threshold and not self._backpressure_active:
            self._backpressure_active = True
            self._backpressure_released.clear()
            logger.debug(
                "backpressure_engaged",
                buffer_size=len(self._buffer),
                threshold=threshold,
            )

    def _check_low_watermark(self) -> None:
        """Release backpressure if buffer drops below the low watermark."""
        threshold = int(self._max_buffer * self._low_watermark)
        if len(self._buffer) <= threshold and self._backpressure_active:
            self._backpressure_active = False
            self._backpressure_released.set()
            logger.debug(
                "backpressure_released",
                buffer_size=len(self._buffer),
                threshold=threshold,
            )

    # -- Diagnostics --------------------------------------------------------

    @property
    def buffer_size(self) -> int:
        """Current number of chunks in the buffer."""
        return len(self._buffer)

    @property
    def is_backpressure_active(self) -> bool:
        """Whether backpressure is currently engaged."""
        return self._backpressure_active

    @property
    def dropped_count(self) -> int:
        """Number of chunks dropped due to buffer overflow."""
        return self._dropped_count

    @property
    def total_received(self) -> int:
        """Total chunks received from the source."""
        return self._total_received

    @property
    def total_delivered(self) -> int:
        """Total chunks delivered to the consumer."""
        return self._total_delivered

    def stats(self) -> dict[str, Any]:
        """Return a diagnostics snapshot.

        Returns:
            Dict with buffer_size, backpressure_active, dropped_count,
            total_received, total_delivered, and source_exhausted.
        """
        return {
            "buffer_size": len(self._buffer),
            "max_buffer": self._max_buffer,
            "backpressure_active": self._backpressure_active,
            "dropped_count": self._dropped_count,
            "total_received": self._total_received,
            "total_delivered": self._total_delivered,
            "source_exhausted": self._source_exhausted,
        }
