"""Core trace and span data structures for Prism request tracing.

Provides:
- ``TraceId`` / ``SpanId`` — typed identifiers.
- ``Span`` — a single operation within a trace.
- ``Trace`` — the root container collecting all spans for a request.
"""

from __future__ import annotations

import secrets
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

# ---------------------------------------------------------------------------
# Identifiers
# ---------------------------------------------------------------------------

class TraceId:
    """128-bit trace identifier backed by a UUID.

    Args:
        value: Optional UUID string; auto-generated when omitted.
    """

    __slots__ = ("_value",)

    def __init__(self, value: str | None = None) -> None:
        if value is not None:
            # Validate
            uuid.UUID(value)
            self._value = value
        else:
            self._value = str(uuid.uuid4())

    @property
    def value(self) -> str:
        """Return the string representation of the trace id."""
        return self._value

    def __str__(self) -> str:
        return self._value

    def __repr__(self) -> str:
        return f"TraceId({self._value!r})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, TraceId):
            return self._value == other._value
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._value)


class SpanId:
    """64-bit span identifier.

    Args:
        value: Optional hex string (16 chars); auto-generated when omitted.
    """

    __slots__ = ("_value",)

    def __init__(self, value: str | None = None) -> None:
        if value is not None:
            if len(value) != 16:
                msg = f"SpanId must be 16 hex characters, got {len(value)}"
                raise ValueError(msg)
            # Validate hex
            int(value, 16)
            self._value = value
        else:
            self._value = secrets.token_hex(8)

    @property
    def value(self) -> str:
        """Return the hex string representation of the span id."""
        return self._value

    def __str__(self) -> str:
        return self._value

    def __repr__(self) -> str:
        return f"SpanId({self._value!r})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SpanId):
            return self._value == other._value
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._value)


# ---------------------------------------------------------------------------
# Span status
# ---------------------------------------------------------------------------

class SpanStatus(Enum):
    """Status of a completed span."""

    OK = "OK"
    ERROR = "ERROR"
    UNSET = "UNSET"


# ---------------------------------------------------------------------------
# Span event
# ---------------------------------------------------------------------------

@dataclass
class SpanEvent:
    """A timestamped log entry within a span."""

    name: str
    timestamp: str = field(default_factory=lambda: datetime.now(tz=UTC).isoformat())
    attributes: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Span
# ---------------------------------------------------------------------------

@dataclass
class Span:
    """A single timed operation within a trace.

    Attributes:
        trace_id: Owning trace identifier.
        span_id: Unique span identifier.
        parent_span_id: Parent span (None for root).
        operation_name: Human-readable name (e.g. "completion", "routing").
        start_time: ISO timestamp of span start.
        end_time: ISO timestamp of span end (empty until finished).
        duration_ms: Elapsed milliseconds (0 until finished).
        attributes: Arbitrary key-value metadata.
        status: Completion status.
        events: Timestamped log entries.
        children: Child spans.
    """

    trace_id: TraceId
    span_id: SpanId = field(default_factory=SpanId)
    parent_span_id: SpanId | None = None
    operation_name: str = ""
    start_time: str = field(default_factory=lambda: datetime.now(tz=UTC).isoformat())
    end_time: str = ""
    duration_ms: float = 0.0
    attributes: dict[str, Any] = field(default_factory=dict)
    status: SpanStatus = SpanStatus.UNSET
    events: list[SpanEvent] = field(default_factory=list)
    children: list[Span] = field(default_factory=list)

    # -- Mutation helpers ---------------------------------------------------

    def finish(self, status: SpanStatus = SpanStatus.OK) -> None:
        """Mark the span as finished, recording end time and duration.

        Args:
            status: The final status of the span.
        """
        now = datetime.now(tz=UTC)
        self.end_time = now.isoformat()
        start_dt = datetime.fromisoformat(self.start_time)
        self.duration_ms = (now - start_dt).total_seconds() * 1000
        self.status = status

    def add_event(self, name: str, attributes: dict[str, Any] | None = None) -> SpanEvent:
        """Append a timestamped event to this span.

        Args:
            name: Event name.
            attributes: Optional event metadata.

        Returns:
            The created ``SpanEvent``.
        """
        event = SpanEvent(name=name, attributes=attributes or {})
        self.events.append(event)
        return event

    def set_attribute(self, key: str, value: Any) -> None:
        """Set an attribute on this span.

        Args:
            key: Attribute key.
            value: Attribute value.
        """
        self.attributes[key] = value

    def add_child(self, child: Span) -> None:
        """Register a child span.

        Args:
            child: The child span to add.
        """
        self.children.append(child)

    def to_dict(self) -> dict[str, Any]:
        """Serialize span (and children) to a dictionary.

        Returns:
            A nested dictionary representation.
        """
        return {
            "trace_id": str(self.trace_id),
            "span_id": str(self.span_id),
            "parent_span_id": str(self.parent_span_id) if self.parent_span_id else None,
            "operation_name": self.operation_name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "attributes": self.attributes,
            "status": self.status.value,
            "events": [
                {"name": e.name, "timestamp": e.timestamp, "attributes": e.attributes}
                for e in self.events
            ],
            "children": [c.to_dict() for c in self.children],
        }


# ---------------------------------------------------------------------------
# Trace
# ---------------------------------------------------------------------------

class Trace:
    """Collects all spans for a single user request in a tree structure.

    Args:
        trace_id: Optional trace identifier; auto-generated when omitted.
        root_operation: Name for the implicit root span.
    """

    def __init__(
        self,
        trace_id: TraceId | None = None,
        root_operation: str = "request",
    ) -> None:
        self._trace_id = trace_id or TraceId()
        self._root_span = Span(
            trace_id=self._trace_id,
            operation_name=root_operation,
        )
        self._spans: dict[str, Span] = {str(self._root_span.span_id): self._root_span}

    # -- Properties ---------------------------------------------------------

    @property
    def trace_id(self) -> TraceId:
        """Return the trace identifier."""
        return self._trace_id

    @property
    def root_span(self) -> Span:
        """Return the root span."""
        return self._root_span

    @property
    def spans(self) -> list[Span]:
        """Return all spans in insertion order."""
        return list(self._spans.values())

    @property
    def total_duration_ms(self) -> float:
        """Return the root span's duration (trace wall-clock time)."""
        return self._root_span.duration_ms

    @property
    def total_cost(self) -> float:
        """Sum cost attributes across all spans."""
        total = 0.0
        for span in self._spans.values():
            total += float(span.attributes.get("cost", 0.0))
        return total

    # -- Span management ----------------------------------------------------

    def add_span(self, span: Span) -> None:
        """Register a span within this trace.

        Args:
            span: The span to add.  Its ``trace_id`` is forced to match.
        """
        span.trace_id = self._trace_id
        self._spans[str(span.span_id)] = span
        # Attach to parent if parent exists
        if span.parent_span_id:
            parent = self._spans.get(str(span.parent_span_id))
            if parent is not None:
                parent.add_child(span)

    def get_span(self, span_id: SpanId | str) -> Span | None:
        """Retrieve a span by id.

        Args:
            span_id: A ``SpanId`` or its string representation.

        Returns:
            The matching ``Span`` or ``None``.
        """
        key = str(span_id)
        return self._spans.get(key)

    def finish(self, status: SpanStatus = SpanStatus.OK) -> None:
        """Finish the root span (and thereby the trace).

        Args:
            status: Final status for the root span.
        """
        self._root_span.finish(status)

    # -- Analysis -----------------------------------------------------------

    def critical_path(self) -> list[Span]:
        """Compute the critical path (longest chain of spans by duration).

        Returns:
            Ordered list of spans forming the longest duration chain.
        """
        return _longest_path(self._root_span)

    def waterfall(self, indent: int = 2) -> str:
        """Render a text-based waterfall timeline of spans.

        Args:
            indent: Number of spaces per nesting level.

        Returns:
            A multi-line string showing the span tree with durations.
        """
        lines: list[str] = []
        _waterfall_recursive(self._root_span, 0, indent, lines)
        return "\n".join(lines)

    # -- Serialization ------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize the entire trace to a dictionary.

        Returns:
            A dictionary with trace metadata and the span tree.
        """
        return {
            "trace_id": str(self._trace_id),
            "total_duration_ms": self.total_duration_ms,
            "total_cost": self.total_cost,
            "span_count": len(self._spans),
            "root_span": self._root_span.to_dict(),
        }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _longest_path(span: Span) -> list[Span]:
    """Recursively find the longest-duration path from *span* downward.

    Args:
        span: Starting span.

    Returns:
        List of spans forming the critical path.
    """
    if not span.children:
        return [span]

    best: list[Span] = []
    best_dur = 0.0
    for child in span.children:
        path = _longest_path(child)
        dur = sum(s.duration_ms for s in path)
        if dur > best_dur:
            best = path
            best_dur = dur

    return [span, *best]


def _waterfall_recursive(
    span: Span, depth: int, indent: int, lines: list[str]
) -> None:
    """Build waterfall lines recursively.

    Args:
        span: Current span.
        depth: Nesting level.
        indent: Spaces per level.
        lines: Accumulator.
    """
    prefix = " " * (depth * indent)
    dur_str = f"{span.duration_ms:.1f}ms" if span.duration_ms > 0 else "running"
    status_str = span.status.value
    lines.append(f"{prefix}[{status_str}] {span.operation_name} ({dur_str})")
    for child in span.children:
        _waterfall_recursive(child, depth + 1, indent, lines)
