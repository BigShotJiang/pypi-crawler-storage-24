"""High-level tracer for managing traces and spans.

Provides a ``Tracer`` singleton that creates traces and spans via context
managers, stores completed traces, and supports retrieval and export.
"""

from __future__ import annotations

import threading
from collections import deque
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

from prism.tracing.trace import Span, SpanStatus, Trace, TraceId

if TYPE_CHECKING:
    from collections.abc import Iterator


class Tracer:
    """Singleton-like tracer that manages the lifecycle of traces and spans.

    Args:
        max_traces: Maximum number of completed traces to retain in memory.
    """

    _instance: Tracer | None = None
    _lock: threading.Lock = threading.Lock()

    def __init__(self, max_traces: int = 1000) -> None:
        self._max_traces = max_traces
        self._completed: deque[Trace] = deque(maxlen=max_traces)
        self._active_trace: threading.local = threading.local()

    # -- Singleton access ---------------------------------------------------

    @classmethod
    def get_instance(cls, max_traces: int = 1000) -> Tracer:
        """Return the global tracer instance, creating it if needed.

        Args:
            max_traces: Maximum completed traces to store.

        Returns:
            The singleton ``Tracer``.
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(max_traces=max_traces)
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """Reset the singleton (primarily for testing)."""
        with cls._lock:
            cls._instance = None

    # -- Properties ---------------------------------------------------------

    @property
    def max_traces(self) -> int:
        """Return the maximum number of stored traces."""
        return self._max_traces

    # -- Trace lifecycle ----------------------------------------------------

    @contextmanager
    def start_trace(self, operation: str = "request") -> Iterator[Trace]:
        """Create and activate a new trace as a context manager.

        Args:
            operation: Name for the root span.

        Yields:
            The active ``Trace``.
        """
        trace = Trace(root_operation=operation)
        self._set_active(trace, trace.root_span)
        try:
            yield trace
        except Exception:
            trace.finish(SpanStatus.ERROR)
            self._store(trace)
            raise
        else:
            if trace.root_span.status == SpanStatus.UNSET:
                trace.finish(SpanStatus.OK)
            self._store(trace)
        finally:
            self._clear_active()

    @contextmanager
    def start_span(
        self,
        operation: str,
        parent: Span | None = None,
    ) -> Iterator[Span]:
        """Create a child span within the active trace.

        Args:
            operation: Operation name for the span.
            parent: Explicit parent span; defaults to the current span.

        Yields:
            The new ``Span``.

        Raises:
            RuntimeError: If no trace is active.
        """
        trace = self.current_trace()
        if trace is None:
            msg = "Cannot start a span without an active trace"
            raise RuntimeError(msg)

        parent_span = parent or self._get_current_span()
        parent_id = parent_span.span_id if parent_span else None

        span = Span(
            trace_id=trace.trace_id,
            parent_span_id=parent_id,
            operation_name=operation,
        )
        trace.add_span(span)

        previous_span = self._get_current_span()
        self._set_current_span(span)
        try:
            yield span
        except Exception:
            span.finish(SpanStatus.ERROR)
            raise
        else:
            if span.status == SpanStatus.UNSET:
                span.finish(SpanStatus.OK)
        finally:
            self._set_current_span(previous_span)

    # -- Active trace access ------------------------------------------------

    def current_trace(self) -> Trace | None:
        """Return the currently active trace (thread-local).

        Returns:
            The active ``Trace`` or ``None``.
        """
        return getattr(self._active_trace, "trace", None)

    def add_event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        """Add an event to the current span.

        Args:
            name: Event name.
            attributes: Optional event metadata.

        Raises:
            RuntimeError: If no span is active.
        """
        span = self._get_current_span()
        if span is None:
            msg = "Cannot add event without an active span"
            raise RuntimeError(msg)
        span.add_event(name, attributes)

    def set_attribute(self, key: str, value: Any) -> None:
        """Set an attribute on the current span.

        Args:
            key: Attribute key.
            value: Attribute value.

        Raises:
            RuntimeError: If no span is active.
        """
        span = self._get_current_span()
        if span is None:
            msg = "Cannot set attribute without an active span"
            raise RuntimeError(msg)
        span.set_attribute(key, value)

    # -- Completed trace retrieval ------------------------------------------

    def get_trace(self, trace_id: TraceId | str) -> Trace | None:
        """Retrieve a completed trace by its id.

        Args:
            trace_id: A ``TraceId`` or its string representation.

        Returns:
            The matching ``Trace`` or ``None``.
        """
        key = str(trace_id)
        for trace in self._completed:
            if str(trace.trace_id) == key:
                return trace
        return None

    def get_recent_traces(self, n: int = 10) -> list[Trace]:
        """Return the *n* most recent completed traces.

        Args:
            n: Number of traces to return.

        Returns:
            A list of traces, most recent last.
        """
        items = list(self._completed)
        return items[-n:] if len(items) > n else items

    def export_traces(self) -> list[dict[str, Any]]:
        """Export all completed traces as serializable dictionaries.

        Returns:
            A list of trace dictionaries.
        """
        return [t.to_dict() for t in self._completed]

    def clear(self) -> None:
        """Remove all stored traces."""
        self._completed.clear()

    # -- Internal helpers ---------------------------------------------------

    def _set_active(self, trace: Trace, span: Span) -> None:
        """Set the thread-local active trace and span."""
        self._active_trace.trace = trace
        self._active_trace.span = span

    def _clear_active(self) -> None:
        """Clear thread-local active trace and span."""
        self._active_trace.trace = None
        self._active_trace.span = None

    def _get_current_span(self) -> Span | None:
        """Return the current thread-local span."""
        return getattr(self._active_trace, "span", None)

    def _set_current_span(self, span: Span | None) -> None:
        """Set the current thread-local span."""
        self._active_trace.span = span

    def _store(self, trace: Trace) -> None:
        """Store a completed trace, evicting the oldest if at capacity."""
        self._completed.append(trace)
