"""Prism git operations — Claude Code handles git, minimal here."""

from __future__ import annotations

try:
    from prism.git.operations import GitLogEntry, GitRepo, GitStatus
except ImportError:
    pass

__all__: list[str] = []
