"""Eval metrics — exact match, fuzzy match, keyword recall, code check, and more."""

from __future__ import annotations

import ast
import difflib
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


def exact_match(predicted: str, expected: str) -> bool:
    """Check if the predicted output exactly matches the expected output.

    Comparison is done after stripping leading/trailing whitespace from
    both strings.

    Args:
        predicted: The model's response.
        expected: The reference answer.

    Returns:
        ``True`` if the stripped strings are identical.
    """
    return predicted.strip() == expected.strip()


def fuzzy_match(predicted: str, expected: str, threshold: float = 0.6) -> float:
    """Compute a fuzzy similarity score between predicted and expected text.

    Uses :func:`difflib.SequenceMatcher` to compute a ratio in ``[0, 1]``.

    Args:
        predicted: The model's response.
        expected: The reference answer.
        threshold: Not used in the score calculation but kept for API
            consistency (callers can use it to gate pass/fail externally).

    Returns:
        A float in ``[0.0, 1.0]`` representing textual similarity.
    """
    if not predicted and not expected:
        return 1.0
    if not predicted or not expected:
        return 0.0
    return difflib.SequenceMatcher(None, predicted.strip(), expected.strip()).ratio()


def keyword_recall(predicted: str, keywords: list[str]) -> float:
    """Measure what fraction of expected keywords appear in the prediction.

    Matching is case-insensitive.

    Args:
        predicted: The model's response.
        keywords: Keywords that should appear in the response.

    Returns:
        A float in ``[0.0, 1.0]``.  Returns ``1.0`` if *keywords* is empty.
    """
    if not keywords:
        return 1.0
    predicted_lower = predicted.lower()
    matched = sum(1 for kw in keywords if kw.lower() in predicted_lower)
    return matched / len(keywords)


def code_execution_check(code: str) -> bool:
    """Check whether a code string has valid Python syntax.

    This performs a **static** syntax check only (via :func:`ast.parse`).
    No code is ever executed.

    Args:
        code: A string of Python source code.

    Returns:
        ``True`` if the code parses without syntax errors.
    """
    try:
        ast.parse(code)
    except SyntaxError:
        return False
    return True


def response_length_ratio(predicted: str, expected: str) -> float:
    """Compute the length ratio of predicted to expected response.

    A ratio of ``1.0`` means the responses are the same length.
    Values above ``1.0`` mean the prediction is longer; below ``1.0`` means
    shorter.

    Args:
        predicted: The model's response.
        expected: The reference answer.

    Returns:
        A non-negative float.  Returns ``0.0`` when both are empty, and
        ``float('inf')`` when only *expected* is empty.
    """
    pred_len = len(predicted.strip())
    exp_len = len(expected.strip())

    if exp_len == 0 and pred_len == 0:
        return 0.0
    if exp_len == 0:
        return float("inf")
    return pred_len / exp_len


@dataclass(frozen=True)
class MetricResult:
    """The output of running a :class:`MetricSuite` against a single sample.

    Attributes:
        scores: Mapping from metric name to its numeric score.
        passed: Mapping from metric name to a boolean pass/fail verdict.
        details: Optional free-form details for any metric that provides them.
    """

    scores: dict[str, float]
    passed: dict[str, bool]
    details: dict[str, str] = field(default_factory=dict)

    @property
    def aggregate_score(self) -> float:
        """Mean of all numeric scores.

        Returns:
            The arithmetic mean, or ``0.0`` if no scores exist.
        """
        if not self.scores:
            return 0.0
        return sum(self.scores.values()) / len(self.scores)

    @property
    def all_passed(self) -> bool:
        """Whether every metric passed."""
        return all(self.passed.values()) if self.passed else True

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "scores": dict(self.scores),
            "passed": dict(self.passed),
            "details": dict(self.details),
            "aggregate_score": self.aggregate_score,
            "all_passed": self.all_passed,
        }


# Type alias for a metric function that takes (predicted, expected | keywords) and
# returns a numeric value.
MetricFn = Callable[..., float | bool]


class MetricSuite:
    """A configurable collection of metrics to evaluate model responses.

    Register metrics with thresholds, then call :meth:`evaluate` to run
    them all on a single prediction.

    Args:
        name: Human-readable name for the suite.
    """

    def __init__(self, name: str = "default") -> None:
        self._name = name
        self._metrics: list[_RegisteredMetric] = []

    @property
    def name(self) -> str:
        """The suite name."""
        return self._name

    @property
    def metric_names(self) -> list[str]:
        """Names of all registered metrics."""
        return [m.name for m in self._metrics]

    # ------------------------------------------------------------------
    # Registration helpers
    # ------------------------------------------------------------------

    def add_exact_match(self, threshold: float = 1.0) -> None:
        """Register an exact-match metric.

        Args:
            threshold: Score at or above which the metric is considered passed
                (default ``1.0`` meaning it must be an exact match).
        """
        def _fn(predicted: str, expected: str, **_kwargs: Any) -> float:
            return 1.0 if exact_match(predicted, expected) else 0.0

        self._metrics.append(_RegisteredMetric(name="exact_match", fn=_fn, threshold=threshold))

    def add_fuzzy_match(self, threshold: float = 0.6) -> None:
        """Register a fuzzy-match metric.

        Args:
            threshold: Minimum similarity ratio to pass.
        """
        def _fn(predicted: str, expected: str, **_kwargs: Any) -> float:
            return fuzzy_match(predicted, expected, threshold=threshold)

        self._metrics.append(_RegisteredMetric(name="fuzzy_match", fn=_fn, threshold=threshold))

    def add_keyword_recall(self, threshold: float = 0.5) -> None:
        """Register a keyword-recall metric.

        When evaluated, the ``keywords`` kwarg must be supplied or it defaults
        to extracting significant words from the expected output.

        Args:
            threshold: Minimum recall fraction to pass.
        """
        def _fn(predicted: str, expected: str, **kwargs: Any) -> float:
            kws: list[str] = kwargs.get("keywords", [])
            if not kws and expected:
                # Auto-extract meaningful words (length >= 4) from expected output
                kws = [w for w in expected.split() if len(w) >= 4]
            return keyword_recall(predicted, kws)

        self._metrics.append(
            _RegisteredMetric(name="keyword_recall", fn=_fn, threshold=threshold)
        )

    def add_code_syntax_check(self) -> None:
        """Register a code-syntax-check metric (pass/fail, score 0 or 1)."""
        def _fn(predicted: str, _expected: str, **_kwargs: Any) -> float:
            return 1.0 if code_execution_check(predicted) else 0.0

        self._metrics.append(_RegisteredMetric(name="code_syntax_check", fn=_fn, threshold=1.0))

    def add_length_ratio(self, min_ratio: float = 0.5, max_ratio: float = 2.0) -> None:
        """Register a response-length-ratio metric.

        Passes if the ratio falls within ``[min_ratio, max_ratio]``.

        Args:
            min_ratio: Lower bound of acceptable ratio.
            max_ratio: Upper bound of acceptable ratio.
        """
        def _fn(predicted: str, expected: str, **_kwargs: Any) -> float:
            ratio = response_length_ratio(predicted, expected)
            if ratio == float("inf"):
                return 0.0
            return ratio

        self._metrics.append(
            _RegisteredMetric(
                name="length_ratio",
                fn=_fn,
                threshold=min_ratio,
                extra={"min_ratio": min_ratio, "max_ratio": max_ratio},
            )
        )

    def add_custom(self, name: str, fn: Callable[..., float], threshold: float = 0.5) -> None:
        """Register a custom metric function.

        The function must accept ``(predicted: str, expected: str, **kwargs)``
        and return a float.

        Args:
            name: Metric name.
            fn: The metric function.
            threshold: Pass/fail threshold.
        """
        self._metrics.append(_RegisteredMetric(name=name, fn=fn, threshold=threshold))

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(
        self,
        predicted: str,
        expected: str | None = None,
        **kwargs: Any,
    ) -> MetricResult:
        """Run all registered metrics on a single prediction.

        Args:
            predicted: The model's response text.
            expected: The reference/expected output (may be ``None`` for
                open-ended prompts — metrics requiring it will score 0).
            **kwargs: Extra keyword arguments forwarded to each metric function
                (e.g. ``keywords=["foo", "bar"]``).

        Returns:
            A :class:`MetricResult` with scores and pass/fail verdicts.
        """
        scores: dict[str, float] = {}
        passed: dict[str, bool] = {}
        details: dict[str, str] = {}

        effective_expected = expected or ""

        for metric in self._metrics:
            try:
                score = metric.fn(predicted, effective_expected, **kwargs)
                score_float = float(score)
            except Exception as exc:
                score_float = 0.0
                details[metric.name] = f"Error: {exc}"

            scores[metric.name] = score_float

            # Determine pass/fail
            if metric.name == "length_ratio" and metric.extra:
                min_r = metric.extra.get("min_ratio", 0.5)
                max_r = metric.extra.get("max_ratio", 2.0)
                passed[metric.name] = min_r <= score_float <= max_r
            else:
                passed[metric.name] = score_float >= metric.threshold

        return MetricResult(scores=scores, passed=passed, details=details)


@dataclass
class _RegisteredMetric:
    """Internal wrapper for a registered metric."""

    name: str
    fn: Callable[..., float]
    threshold: float
    extra: dict[str, Any] = field(default_factory=dict)
