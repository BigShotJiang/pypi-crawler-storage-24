"""Eval runner — execute benchmarks across models and produce reports."""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from prism.eval.dataset import EvalDataset, EvalSample
    from prism.eval.metrics import MetricResult, MetricSuite

# ---------------------------------------------------------------------------
# Completion engine protocol (so we can accept mocks or real engines)
# ---------------------------------------------------------------------------


class CompletionFn(Protocol):
    """Protocol for an async completion function.

    Accepts a model ID and a prompt, returns the generated text along with
    cost and token metadata.
    """

    async def __call__(
        self, model: str, prompt: str
    ) -> CompletionOutput: ...


@dataclass(frozen=True)
class CompletionOutput:
    """Output from a single model completion call.

    Attributes:
        text: The generated text.
        input_tokens: Number of input tokens consumed.
        output_tokens: Number of output tokens generated.
        cost_usd: Estimated cost in USD.
    """

    text: str
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0


# ---------------------------------------------------------------------------
# Per-sample result
# ---------------------------------------------------------------------------


@dataclass
class SampleResult:
    """Result of evaluating a single sample against a single model.

    Attributes:
        sample_index: Position of the sample in the dataset.
        model_id: The model that produced the response.
        predicted: The model's generated text.
        expected: The reference answer (may be ``None``).
        metric_result: Scores and pass/fail from the metric suite.
        latency_ms: Wall-clock time for the completion in milliseconds.
        cost_usd: Estimated cost in USD for this completion.
        input_tokens: Tokens consumed.
        output_tokens: Tokens generated.
    """

    sample_index: int
    model_id: str
    predicted: str
    expected: str | None
    metric_result: MetricResult
    latency_ms: float
    cost_usd: float
    input_tokens: int = 0
    output_tokens: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "sample_index": self.sample_index,
            "model_id": self.model_id,
            "predicted": self.predicted,
            "expected": self.expected,
            "metric_result": self.metric_result.to_dict(),
            "latency_ms": self.latency_ms,
            "cost_usd": self.cost_usd,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
        }


# ---------------------------------------------------------------------------
# Per-model aggregate
# ---------------------------------------------------------------------------


@dataclass
class ModelScore:
    """Aggregated evaluation scores for a single model.

    Attributes:
        model_id: The model identifier.
        mean_score: Average aggregate metric score across all samples.
        total_cost_usd: Cumulative cost for all samples.
        mean_latency_ms: Average latency across all samples.
        pass_rate: Fraction of samples that passed all metrics.
        per_metric_means: Mean score for each metric name.
        sample_count: Number of samples evaluated.
    """

    model_id: str
    mean_score: float
    total_cost_usd: float
    mean_latency_ms: float
    pass_rate: float
    per_metric_means: dict[str, float] = field(default_factory=dict)
    sample_count: int = 0

    @property
    def cost_efficiency(self) -> float:
        """Quality per dollar (higher is better).

        Returns:
            ``mean_score / total_cost_usd``, or ``float('inf')`` when cost is zero.
        """
        if self.total_cost_usd <= 0:
            return float("inf") if self.mean_score > 0 else 0.0
        return self.mean_score / self.total_cost_usd

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "model_id": self.model_id,
            "mean_score": self.mean_score,
            "total_cost_usd": self.total_cost_usd,
            "mean_latency_ms": self.mean_latency_ms,
            "pass_rate": self.pass_rate,
            "per_metric_means": dict(self.per_metric_means),
            "sample_count": self.sample_count,
            "cost_efficiency": self.cost_efficiency,
        }


# ---------------------------------------------------------------------------
# Eval report
# ---------------------------------------------------------------------------


@dataclass
class EvalReport:
    """Full evaluation report containing per-model scores and per-sample breakdowns.

    Attributes:
        dataset_name: Name of the evaluated dataset.
        model_scores: Per-model aggregate scores.
        sample_results: Every individual sample result.
        rankings_by_quality: Model IDs ranked best-to-worst by mean score.
        rankings_by_cost: Model IDs ranked cheapest-to-most-expensive.
        rankings_by_efficiency: Model IDs ranked by cost-efficiency.
    """

    dataset_name: str
    model_scores: dict[str, ModelScore] = field(default_factory=dict)
    sample_results: list[SampleResult] = field(default_factory=list)
    rankings_by_quality: list[str] = field(default_factory=list)
    rankings_by_cost: list[str] = field(default_factory=list)
    rankings_by_efficiency: list[str] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Statistical significance (basic)
    # ------------------------------------------------------------------

    def p_value(self, model_a: str, model_b: str) -> float | None:
        """Compute a basic p-value for the quality difference between two models.

        Uses a two-sample paired permutation test approximation.  For small
        samples, falls back to a simple sign test.

        Args:
            model_a: First model ID.
            model_b: Second model ID.

        Returns:
            A p-value in ``[0, 1]`` or ``None`` if the models cannot be compared
            (e.g. different sample counts or unknown model ID).
        """
        scores_a = self._per_sample_scores(model_a)
        scores_b = self._per_sample_scores(model_b)
        if scores_a is None or scores_b is None:
            return None
        if len(scores_a) != len(scores_b) or len(scores_a) == 0:
            return None

        n = len(scores_a)
        diffs = [a - b for a, b in zip(scores_a, scores_b, strict=False)]
        observed_diff = abs(sum(diffs) / n)

        # Sign-test based p-value approximation
        if observed_diff == 0.0:
            return 1.0

        # Count how many permutations (sign flips) yield >= observed diff
        # For efficiency, cap at 2^20 and use sampling beyond that.
        num_permutations = min(2**n, 2**16)
        exceed_count = 0

        import random as _random

        rng = _random.Random(42)  # noqa: S311 — deterministic

        if n <= 16:
            # Exact enumeration
            for mask in range(2**n):
                perm_diffs = [
                    diffs[i] * (1 if (mask >> i) & 1 else -1) for i in range(n)
                ]
                if abs(sum(perm_diffs) / n) >= observed_diff:
                    exceed_count += 1
            return exceed_count / (2**n)
        else:
            # Monte Carlo approximation
            for _ in range(num_permutations):
                perm_diffs = [d * rng.choice([1, -1]) for d in diffs]
                if abs(sum(perm_diffs) / n) >= observed_diff:
                    exceed_count += 1
            return exceed_count / num_permutations

    def _per_sample_scores(self, model_id: str) -> list[float] | None:
        """Extract ordered per-sample aggregate scores for a model."""
        results = [r for r in self.sample_results if r.model_id == model_id]
        if not results:
            return None
        results.sort(key=lambda r: r.sample_index)
        return [r.metric_result.aggregate_score for r in results]

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize the full report to a dictionary."""
        return {
            "dataset_name": self.dataset_name,
            "model_scores": {k: v.to_dict() for k, v in self.model_scores.items()},
            "sample_results": [r.to_dict() for r in self.sample_results],
            "rankings_by_quality": self.rankings_by_quality,
            "rankings_by_cost": self.rankings_by_cost,
            "rankings_by_efficiency": self.rankings_by_efficiency,
        }

    def to_json(self, indent: int = 2) -> str:
        """Serialize to a JSON string.

        Args:
            indent: JSON indentation level.

        Returns:
            A JSON-formatted string.
        """
        return json.dumps(self.to_dict(), indent=indent, default=str)


# ---------------------------------------------------------------------------
# Progress callback type
# ---------------------------------------------------------------------------

ProgressCallback = Callable[[int, int, str], None]
"""Signature: (completed, total, current_description) -> None"""


# ---------------------------------------------------------------------------
# Eval runner
# ---------------------------------------------------------------------------


class EvalRunner:
    """Runs an evaluation benchmark across multiple models.

    Args:
        dataset: The evaluation dataset.
        model_ids: List of model identifiers to benchmark.
        metric_suite: The metric suite to apply.
        completion_fn: An async callable matching :class:`CompletionFn`.
        max_concurrent: Maximum number of concurrent completion calls.
        progress_callback: Optional callback invoked after each sample completes.
    """

    def __init__(
        self,
        dataset: EvalDataset,
        model_ids: list[str],
        metric_suite: MetricSuite,
        completion_fn: CompletionFn,
        max_concurrent: int = 5,
        progress_callback: ProgressCallback | None = None,
    ) -> None:
        if not model_ids:
            raise ValueError("At least one model_id is required")
        if len(dataset) == 0:
            raise ValueError("Dataset must contain at least one sample")

        self._dataset = dataset
        self._model_ids = list(model_ids)
        self._metrics = metric_suite
        self._completion_fn = completion_fn
        self._max_concurrent = max(1, max_concurrent)
        self._progress_cb = progress_callback

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def run(self) -> EvalReport:
        """Execute the full evaluation and return a report.

        Runs each sample against each model, collects metrics, and builds
        an :class:`EvalReport` with aggregate scores and rankings.

        Returns:
            A completed :class:`EvalReport`.
        """
        total_tasks = len(self._dataset) * len(self._model_ids)
        completed = 0
        sample_results: list[SampleResult] = []

        semaphore = asyncio.Semaphore(self._max_concurrent)

        async def _eval_one(
            sample_idx: int, sample: EvalSample, model_id: str
        ) -> SampleResult:
            nonlocal completed
            async with semaphore:
                start = time.monotonic()
                output = await self._completion_fn(model_id, sample.input_prompt)
                elapsed_ms = (time.monotonic() - start) * 1000.0

                metric_result = self._metrics.evaluate(
                    predicted=output.text,
                    expected=sample.expected_output,
                )

                result = SampleResult(
                    sample_index=sample_idx,
                    model_id=model_id,
                    predicted=output.text,
                    expected=sample.expected_output,
                    metric_result=metric_result,
                    latency_ms=elapsed_ms,
                    cost_usd=output.cost_usd,
                    input_tokens=output.input_tokens,
                    output_tokens=output.output_tokens,
                )

                completed += 1
                if self._progress_cb:
                    self._progress_cb(
                        completed,
                        total_tasks,
                        f"{model_id} sample {sample_idx}",
                    )

                return result

        # Build tasks
        tasks: list[asyncio.Task[SampleResult]] = []
        for sample_idx, sample in enumerate(self._dataset):
            for model_id in self._model_ids:
                task = asyncio.create_task(
                    _eval_one(sample_idx, sample, model_id)
                )
                tasks.append(task)

        # Await all
        results = await asyncio.gather(*tasks)
        sample_results = list(results)

        # Build report
        return self._build_report(sample_results)

    def run_sync(self) -> EvalReport:
        """Synchronous wrapper around :meth:`run`.

        Creates a new event loop if none is running.

        Returns:
            A completed :class:`EvalReport`.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            # We're inside an existing async context — use nest_asyncio pattern
            # or just create a new thread.  For simplicity, use a new thread.
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, self.run())
                return future.result()
        else:
            return asyncio.run(self.run())

    # ------------------------------------------------------------------
    # Report building
    # ------------------------------------------------------------------

    def _build_report(self, sample_results: list[SampleResult]) -> EvalReport:
        """Aggregate sample results into a full report."""
        model_scores: dict[str, ModelScore] = {}

        for model_id in self._model_ids:
            model_results = [r for r in sample_results if r.model_id == model_id]
            if not model_results:
                continue

            n = len(model_results)
            mean_score = sum(r.metric_result.aggregate_score for r in model_results) / n
            total_cost = sum(r.cost_usd for r in model_results)
            mean_latency = sum(r.latency_ms for r in model_results) / n
            pass_rate = sum(1 for r in model_results if r.metric_result.all_passed) / n

            # Per-metric means
            metric_names: set[str] = set()
            for r in model_results:
                metric_names.update(r.metric_result.scores.keys())

            per_metric_means: dict[str, float] = {}
            for mn in sorted(metric_names):
                vals = [
                    r.metric_result.scores.get(mn, 0.0) for r in model_results
                ]
                per_metric_means[mn] = sum(vals) / len(vals)

            model_scores[model_id] = ModelScore(
                model_id=model_id,
                mean_score=mean_score,
                total_cost_usd=total_cost,
                mean_latency_ms=mean_latency,
                pass_rate=pass_rate,
                per_metric_means=per_metric_means,
                sample_count=n,
            )

        # Rankings
        quality_ranking = sorted(
            model_scores.keys(), key=lambda m: model_scores[m].mean_score, reverse=True
        )
        cost_ranking = sorted(
            model_scores.keys(), key=lambda m: model_scores[m].total_cost_usd
        )
        efficiency_ranking = sorted(
            model_scores.keys(),
            key=lambda m: model_scores[m].cost_efficiency,
            reverse=True,
        )

        return EvalReport(
            dataset_name=self._dataset.name,
            model_scores=model_scores,
            sample_results=sample_results,
            rankings_by_quality=quality_ranking,
            rankings_by_cost=cost_ranking,
            rankings_by_efficiency=efficiency_ranking,
        )
