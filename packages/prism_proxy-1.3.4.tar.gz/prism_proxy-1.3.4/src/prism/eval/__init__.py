"""Prism eval/benchmark framework — dataset loading, metrics, runner, and comparison."""

from prism.eval.comparator import ComparisonSummary, Improvement, ModelComparator, Regression
from prism.eval.dataset import EvalDataset, EvalSample
from prism.eval.metrics import MetricResult, MetricSuite
from prism.eval.runner import EvalReport, EvalRunner, ModelScore, SampleResult

__all__ = [
    "ComparisonSummary",
    "EvalDataset",
    "EvalReport",
    "EvalRunner",
    "EvalSample",
    "Improvement",
    "MetricResult",
    "MetricSuite",
    "ModelComparator",
    "ModelScore",
    "Regression",
    "SampleResult",
]
