"""Eval dataset — loading, filtering, splitting, and built-in sample sets."""

from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Iterator


@dataclass
class EvalSample:
    """A single evaluation sample.

    Attributes:
        input_prompt: The prompt to send to the model.
        expected_output: The expected/reference response (optional for open-ended).
        metadata: Arbitrary key-value metadata for this sample.
        tags: Tags for filtering (e.g. ``["coding", "python"]``).
    """

    input_prompt: str
    expected_output: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the sample to a plain dictionary."""
        return {
            "input_prompt": self.input_prompt,
            "expected_output": self.expected_output,
            "metadata": self.metadata,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EvalSample:
        """Deserialize a sample from a dictionary.

        Args:
            data: Dictionary with at least ``input_prompt``.

        Returns:
            A new ``EvalSample`` instance.

        Raises:
            ValueError: If ``input_prompt`` is missing.
        """
        if "input_prompt" not in data:
            raise ValueError("EvalSample requires 'input_prompt' key")
        return cls(
            input_prompt=data["input_prompt"],
            expected_output=data.get("expected_output"),
            metadata=data.get("metadata", {}),
            tags=data.get("tags", []),
        )


class EvalDataset:
    """A collection of :class:`EvalSample` instances with convenience methods.

    Supports loading from JSON/JSONL files, programmatic construction,
    tag-based filtering, train/test splitting, shuffling, and iteration.

    Args:
        name: Human-readable name for the dataset.
        samples: Optional initial list of samples.
    """

    def __init__(self, name: str = "unnamed", samples: list[EvalSample] | None = None) -> None:
        self._name = name
        self._samples: list[EvalSample] = list(samples) if samples else []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """The dataset name."""
        return self._name

    @property
    def samples(self) -> list[EvalSample]:
        """All samples in the dataset (read-only copy)."""
        return list(self._samples)

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def add_sample(self, sample: EvalSample) -> None:
        """Append a single sample to the dataset.

        Args:
            sample: The evaluation sample to add.
        """
        self._samples.append(sample)

    def add_samples(self, samples: list[EvalSample]) -> None:
        """Append multiple samples to the dataset.

        Args:
            samples: List of evaluation samples to add.
        """
        self._samples.extend(samples)

    # ------------------------------------------------------------------
    # File I/O
    # ------------------------------------------------------------------

    @classmethod
    def from_json(cls, path: str | Path, name: str | None = None) -> EvalDataset:
        """Load a dataset from a JSON file containing a list of sample dicts.

        Args:
            path: Filesystem path to the JSON file.
            name: Optional name override (defaults to filename stem).

        Returns:
            A new ``EvalDataset`` loaded from disk.

        Raises:
            FileNotFoundError: If the file does not exist.
            ValueError: If the file is not valid JSON or not a list.
        """
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"Dataset file not found: {file_path}")

        raw = file_path.read_text(encoding="utf-8")
        data = json.loads(raw)

        if not isinstance(data, list):
            raise ValueError(f"Expected a JSON list, got {type(data).__name__}")

        dataset_name = name or file_path.stem
        samples = [EvalSample.from_dict(item) for item in data]
        return cls(name=dataset_name, samples=samples)

    @classmethod
    def from_jsonl(cls, path: str | Path, name: str | None = None) -> EvalDataset:
        """Load a dataset from a JSONL file (one sample per line).

        Args:
            path: Filesystem path to the JSONL file.
            name: Optional name override (defaults to filename stem).

        Returns:
            A new ``EvalDataset`` loaded from disk.

        Raises:
            FileNotFoundError: If the file does not exist.
        """
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"Dataset file not found: {file_path}")

        dataset_name = name or file_path.stem
        samples: list[EvalSample] = []
        for line_no, line in enumerate(file_path.read_text(encoding="utf-8").splitlines(), 1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                data = json.loads(stripped)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON on line {line_no}: {exc}") from exc
            samples.append(EvalSample.from_dict(data))

        return cls(name=dataset_name, samples=samples)

    def to_json(self, path: str | Path) -> None:
        """Write the dataset to a JSON file.

        Args:
            path: Destination filesystem path.
        """
        file_path = Path(path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        data = [s.to_dict() for s in self._samples]
        file_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def to_jsonl(self, path: str | Path) -> None:
        """Write the dataset to a JSONL file.

        Args:
            path: Destination filesystem path.
        """
        file_path = Path(path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        lines = [json.dumps(s.to_dict(), ensure_ascii=False) for s in self._samples]
        file_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # ------------------------------------------------------------------
    # Filtering
    # ------------------------------------------------------------------

    def filter_by_tags(self, tags: list[str], match_all: bool = False) -> EvalDataset:
        """Return a new dataset containing only samples matching the given tags.

        Args:
            tags: Tags to filter on.
            match_all: If ``True``, a sample must have **all** tags.
                If ``False`` (default), at least **one** matching tag suffices.

        Returns:
            A new ``EvalDataset`` with the filtered subset.
        """
        tag_set = set(tags)
        if match_all:
            filtered = [s for s in self._samples if tag_set.issubset(set(s.tags))]
        else:
            filtered = [s for s in self._samples if tag_set.intersection(set(s.tags))]
        return EvalDataset(name=f"{self._name}_filtered", samples=filtered)

    # ------------------------------------------------------------------
    # Splitting / Shuffling
    # ------------------------------------------------------------------

    def split(
        self, train_ratio: float = 0.8, seed: int | None = None
    ) -> tuple[EvalDataset, EvalDataset]:
        """Split the dataset into train and test subsets.

        Args:
            train_ratio: Fraction of samples in the training set (0.0-1.0).
            seed: Optional random seed for reproducibility.

        Returns:
            A tuple ``(train_dataset, test_dataset)``.

        Raises:
            ValueError: If ``train_ratio`` is not in (0, 1).
        """
        if not 0.0 < train_ratio < 1.0:
            raise ValueError(f"train_ratio must be between 0 and 1 exclusive, got {train_ratio}")

        indices = list(range(len(self._samples)))
        rng = random.Random(seed)  # noqa: S311
        rng.shuffle(indices)

        split_idx = max(1, int(len(indices) * train_ratio))
        train_indices = indices[:split_idx]
        test_indices = indices[split_idx:]

        train_samples = [self._samples[i] for i in train_indices]
        test_samples = [self._samples[i] for i in test_indices]

        return (
            EvalDataset(name=f"{self._name}_train", samples=train_samples),
            EvalDataset(name=f"{self._name}_test", samples=test_samples),
        )

    def shuffle(self, seed: int | None = None) -> EvalDataset:
        """Return a new dataset with samples in random order.

        Args:
            seed: Optional random seed for reproducibility.

        Returns:
            A new ``EvalDataset`` with shuffled samples.
        """
        shuffled = list(self._samples)
        rng = random.Random(seed)  # noqa: S311
        rng.shuffle(shuffled)
        return EvalDataset(name=self._name, samples=shuffled)

    # ------------------------------------------------------------------
    # Iteration & dunder methods
    # ------------------------------------------------------------------

    def __iter__(self) -> Iterator[EvalSample]:
        """Iterate over samples."""
        return iter(self._samples)

    def __len__(self) -> int:
        """Number of samples in the dataset."""
        return len(self._samples)

    def __getitem__(self, index: int) -> EvalSample:
        """Get a sample by index.

        Args:
            index: Zero-based index.

        Returns:
            The sample at the given index.
        """
        return self._samples[index]

    def __repr__(self) -> str:
        return f"EvalDataset(name={self._name!r}, samples={len(self._samples)})"

    # ------------------------------------------------------------------
    # Built-in datasets
    # ------------------------------------------------------------------

    @classmethod
    def builtin(cls, name: str) -> EvalDataset:
        """Load a built-in dataset by name.

        Args:
            name: One of ``"coding_basic"``, ``"reasoning"``, ``"creative"``.

        Returns:
            A pre-populated ``EvalDataset``.

        Raises:
            ValueError: If the name is not recognised.
        """
        builders: dict[str, Any] = {
            "coding_basic": cls._builtin_coding_basic,
            "reasoning": cls._builtin_reasoning,
            "creative": cls._builtin_creative,
        }
        builder = builders.get(name)
        if builder is None:
            available = ", ".join(sorted(builders))
            raise ValueError(f"Unknown built-in dataset {name!r}. Available: {available}")
        return builder()

    @classmethod
    def _builtin_coding_basic(cls) -> EvalDataset:
        """10 basic coding samples."""
        samples = [
            EvalSample(
                input_prompt="Write a Python function that returns the factorial of n.",
                expected_output="def factorial(n):\n    if n <= 1:\n        return 1\n    return n * factorial(n - 1)",
                tags=["coding", "python", "recursion"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="Write a Python function to check if a string is a palindrome.",
                expected_output="def is_palindrome(s):\n    return s == s[::-1]",
                tags=["coding", "python", "string"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="Write a Python function to find the maximum element in a list.",
                expected_output="def find_max(lst):\n    if not lst:\n        return None\n    return max(lst)",
                tags=["coding", "python", "list"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="Write a Python function that computes the nth Fibonacci number.",
                expected_output="def fibonacci(n):\n    if n <= 0:\n        return 0\n    if n == 1:\n        return 1\n    a, b = 0, 1\n    for _ in range(2, n + 1):\n        a, b = b, a + b\n    return b",
                tags=["coding", "python", "math"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="Write a Python function to reverse a linked list.",
                expected_output="def reverse_linked_list(head):\n    prev = None\n    curr = head\n    while curr:\n        nxt = curr.next\n        curr.next = prev\n        prev = curr\n        curr = nxt\n    return prev",
                tags=["coding", "python", "data-structure"],
                metadata={"difficulty": "medium"},
            ),
            EvalSample(
                input_prompt="Write a Python function to merge two sorted lists.",
                expected_output="def merge_sorted(a, b):\n    result = []\n    i = j = 0\n    while i < len(a) and j < len(b):\n        if a[i] <= b[j]:\n            result.append(a[i])\n            i += 1\n        else:\n            result.append(b[j])\n            j += 1\n    result.extend(a[i:])\n    result.extend(b[j:])\n    return result",
                tags=["coding", "python", "sorting"],
                metadata={"difficulty": "medium"},
            ),
            EvalSample(
                input_prompt="Write a Python function to count the vowels in a string.",
                expected_output="def count_vowels(s):\n    return sum(1 for c in s.lower() if c in 'aeiou')",
                tags=["coding", "python", "string"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="Write a Python function to flatten a nested list.",
                expected_output="def flatten(lst):\n    result = []\n    for item in lst:\n        if isinstance(item, list):\n            result.extend(flatten(item))\n        else:\n            result.append(item)\n    return result",
                tags=["coding", "python", "recursion"],
                metadata={"difficulty": "medium"},
            ),
            EvalSample(
                input_prompt="Write a Python class implementing a stack with push, pop, and peek.",
                expected_output="class Stack:\n    def __init__(self):\n        self._items = []\n    def push(self, item):\n        self._items.append(item)\n    def pop(self):\n        if not self._items:\n            raise IndexError('pop from empty stack')\n        return self._items.pop()\n    def peek(self):\n        if not self._items:\n            raise IndexError('peek from empty stack')\n        return self._items[-1]",
                tags=["coding", "python", "data-structure"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="Write a Python function to perform binary search on a sorted list.",
                expected_output="def binary_search(lst, target):\n    lo, hi = 0, len(lst) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if lst[mid] == target:\n            return mid\n        elif lst[mid] < target:\n            lo = mid + 1\n        else:\n            hi = mid - 1\n    return -1",
                tags=["coding", "python", "search"],
                metadata={"difficulty": "medium"},
            ),
        ]
        return cls(name="coding_basic", samples=samples)

    @classmethod
    def _builtin_reasoning(cls) -> EvalDataset:
        """10 reasoning samples."""
        samples = [
            EvalSample(
                input_prompt="If all roses are flowers and some flowers fade quickly, can we conclude that some roses fade quickly?",
                expected_output="No, we cannot conclude that. The fact that some flowers fade quickly does not mean those specific flowers are roses.",
                tags=["reasoning", "logic"],
                metadata={"difficulty": "medium"},
            ),
            EvalSample(
                input_prompt="A bat and a ball cost $1.10 in total. The bat costs $1.00 more than the ball. How much does the ball cost?",
                expected_output="The ball costs $0.05.",
                tags=["reasoning", "math"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?",
                expected_output="5 minutes. Each machine makes one widget in 5 minutes, so 100 machines make 100 widgets in 5 minutes.",
                tags=["reasoning", "math"],
                metadata={"difficulty": "medium"},
            ),
            EvalSample(
                input_prompt="In a lake, there is a patch of lily pads. Every day, the patch doubles in size. If it takes 48 days for the patch to cover the entire lake, how long would it take for the patch to cover half of the lake?",
                expected_output="47 days. Since the patch doubles every day, it was half the size the day before it covered the entire lake.",
                tags=["reasoning", "math"],
                metadata={"difficulty": "medium"},
            ),
            EvalSample(
                input_prompt="There are three boxes. One contains only apples, one contains only oranges, and one contains both. All labels are wrong. You pick one fruit from the box labeled 'both'. It is an apple. What does each box contain?",
                expected_output="The box labeled 'both' contains only apples. The box labeled 'oranges' contains both. The box labeled 'apples' contains only oranges.",
                tags=["reasoning", "logic", "puzzle"],
                metadata={"difficulty": "hard"},
            ),
            EvalSample(
                input_prompt="What is the next number in the sequence: 1, 1, 2, 3, 5, 8, 13, ?",
                expected_output="21. This is the Fibonacci sequence where each number is the sum of the two preceding ones.",
                tags=["reasoning", "math", "pattern"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="A farmer has 17 sheep. All but 9 die. How many sheep does the farmer have left?",
                expected_output="9 sheep. 'All but 9' means 9 survive.",
                tags=["reasoning", "trick-question"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="You have two jugs: one holds 5 liters and the other 3 liters. How do you measure exactly 4 liters?",
                expected_output="Fill the 5-liter jug. Pour into the 3-liter jug until full (leaving 2 liters in the 5-liter jug). Empty the 3-liter jug. Pour the 2 liters from the 5-liter jug into the 3-liter jug. Fill the 5-liter jug again. Pour from the 5-liter jug into the 3-liter jug until full (1 liter poured). The 5-liter jug now has 4 liters.",
                tags=["reasoning", "logic", "puzzle"],
                metadata={"difficulty": "hard"},
            ),
            EvalSample(
                input_prompt="Is the following argument valid? All mammals are warm-blooded. Whales are mammals. Therefore, whales are warm-blooded.",
                expected_output="Yes, the argument is valid. It follows the form of a categorical syllogism (modus ponens): if all A are B, and C is A, then C is B.",
                tags=["reasoning", "logic"],
                metadata={"difficulty": "easy"},
            ),
            EvalSample(
                input_prompt="A clock shows 3:15. What is the angle between the hour hand and the minute hand?",
                expected_output="7.5 degrees. At 3:15, the minute hand is at 90 degrees (pointing at 3). The hour hand has moved past the 3 by 1/4 of the way to 4, which is 7.5 degrees. So the angle is 7.5 degrees.",
                tags=["reasoning", "math", "geometry"],
                metadata={"difficulty": "medium"},
            ),
        ]
        return cls(name="reasoning", samples=samples)

    @classmethod
    def _builtin_creative(cls) -> EvalDataset:
        """5 creative writing samples (no expected output — open-ended)."""
        samples = [
            EvalSample(
                input_prompt="Write a haiku about programming.",
                expected_output=None,
                tags=["creative", "poetry"],
                metadata={"difficulty": "easy", "open_ended": True},
            ),
            EvalSample(
                input_prompt="Write a short story (100 words) about a robot learning to paint.",
                expected_output=None,
                tags=["creative", "fiction"],
                metadata={"difficulty": "medium", "open_ended": True},
            ),
            EvalSample(
                input_prompt="Describe the color blue to someone who has never seen it.",
                expected_output=None,
                tags=["creative", "descriptive"],
                metadata={"difficulty": "medium", "open_ended": True},
            ),
            EvalSample(
                input_prompt="Write a limerick about artificial intelligence.",
                expected_output=None,
                tags=["creative", "poetry", "humor"],
                metadata={"difficulty": "easy", "open_ended": True},
            ),
            EvalSample(
                input_prompt="Invent a new word and write its dictionary entry, including pronunciation, part of speech, definition, and example usage.",
                expected_output=None,
                tags=["creative", "language"],
                metadata={"difficulty": "medium", "open_ended": True},
            ),
        ]
        return cls(name="creative", samples=samples)
