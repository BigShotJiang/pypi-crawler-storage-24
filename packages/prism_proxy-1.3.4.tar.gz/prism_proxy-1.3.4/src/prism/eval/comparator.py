"""Model comparator — compare eval reports, identify regressions and improvements."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from prism.eval.runner import EvalReport


@dataclass(frozen=True)
class Regression:
    """A quality regression detected between two reports.

    Attributes:
        model_id: The model that regressed.
        metric_name: The metric that dropped.
        old_score: Score in the baseline report.
        new_score: Score in the new report.
        delta: Absolute drop (``old_score - new_score``).
        pct_change: Percentage change (negative means regression).
    """

    model_id: str
    metric_name: str
    old_score: float
    new_score: float
    delta: float
    pct_change: float


@dataclass(frozen=True)
class Improvement:
    """A quality improvement detected between two reports.

    Attributes:
        model_id: The model that improved.
        metric_name: The metric that improved.
        old_score: Score in the baseline report.
        new_score: Score in the new report.
        delta: Absolute gain (``new_score - old_score``).
        pct_change: Percentage change (positive means improvement).
    """

    model_id: str
    metric_name: str
    old_score: float
    new_score: float
    delta: float
    pct_change: float


@dataclass
class CostEfficiencyEntry:
    """Cost-efficiency comparison for a single model.

    Attributes:
        model_id: The model identifier.
        old_efficiency: Quality-per-dollar in the baseline report.
        new_efficiency: Quality-per-dollar in the new report.
        delta: Change in efficiency.
    """

    model_id: str
    old_efficiency: float
    new_efficiency: float
    delta: float


@dataclass
class ComparisonSummary:
    """Summary of a comparison between two :class:`EvalReport` instances.

    Attributes:
        baseline_dataset: Name of the baseline dataset.
        new_dataset: Name of the new dataset.
        common_models: Models present in both reports.
        regressions: Detected quality regressions.
        improvements: Detected quality improvements.
        cost_efficiency: Per-model cost-efficiency comparison.
        overall_quality_delta: Mean quality change across all common models.
        overall_cost_delta: Mean cost change across all common models.
    """

    baseline_dataset: str
    new_dataset: str
    common_models: list[str] = field(default_factory=list)
    regressions: list[Regression] = field(default_factory=list)
    improvements: list[Improvement] = field(default_factory=list)
    cost_efficiency: list[CostEfficiencyEntry] = field(default_factory=list)
    overall_quality_delta: float = 0.0
    overall_cost_delta: float = 0.0

    @property
    def has_regressions(self) -> bool:
        """Whether any regressions were detected."""
        return len(self.regressions) > 0

    @property
    def has_improvements(self) -> bool:
        """Whether any improvements were detected."""
        return len(self.improvements) > 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "baseline_dataset": self.baseline_dataset,
            "new_dataset": self.new_dataset,
            "common_models": self.common_models,
            "regressions": [
                {
                    "model_id": r.model_id,
                    "metric_name": r.metric_name,
                    "old_score": r.old_score,
                    "new_score": r.new_score,
                    "delta": r.delta,
                    "pct_change": r.pct_change,
                }
                for r in self.regressions
            ],
            "improvements": [
                {
                    "model_id": i.model_id,
                    "metric_name": i.metric_name,
                    "old_score": i.old_score,
                    "new_score": i.new_score,
                    "delta": i.delta,
                    "pct_change": i.pct_change,
                }
                for i in self.improvements
            ],
            "cost_efficiency": [
                {
                    "model_id": c.model_id,
                    "old_efficiency": c.old_efficiency,
                    "new_efficiency": c.new_efficiency,
                    "delta": c.delta,
                }
                for c in self.cost_efficiency
            ],
            "overall_quality_delta": self.overall_quality_delta,
            "overall_cost_delta": self.overall_cost_delta,
            "has_regressions": self.has_regressions,
            "has_improvements": self.has_improvements,
        }


class ModelComparator:
    """Compare two :class:`EvalReport` instances and surface regressions/improvements.

    Args:
        regression_threshold: Minimum absolute score drop to flag as a regression.
            Default is ``0.05`` (5%).
        improvement_threshold: Minimum absolute score gain to flag as an improvement.
            Default is ``0.05`` (5%).
    """

    def __init__(
        self,
        regression_threshold: float = 0.05,
        improvement_threshold: float = 0.05,
    ) -> None:
        if regression_threshold < 0:
            raise ValueError("regression_threshold must be non-negative")
        if improvement_threshold < 0:
            raise ValueError("improvement_threshold must be non-negative")

        self._regression_threshold = regression_threshold
        self._improvement_threshold = improvement_threshold

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compare(self, baseline: EvalReport, new: EvalReport) -> ComparisonSummary:
        """Compare a baseline report against a new report.

        Only models present in **both** reports are compared.

        Args:
            baseline: The reference/baseline evaluation report.
            new: The new evaluation report to compare against.

        Returns:
            A :class:`ComparisonSummary` with regressions, improvements,
            and cost-efficiency analysis.
        """
        common_models = sorted(
            set(baseline.model_scores.keys()) & set(new.model_scores.keys())
        )

        regressions: list[Regression] = []
        improvements: list[Improvement] = []
        cost_entries: list[CostEfficiencyEntry] = []
        quality_deltas: list[float] = []
        cost_deltas: list[float] = []

        for model_id in common_models:
            old_ms = baseline.model_scores[model_id]
            new_ms = new.model_scores[model_id]

            # Aggregate quality delta
            q_delta = new_ms.mean_score - old_ms.mean_score
            quality_deltas.append(q_delta)

            # Cost delta
            c_delta = new_ms.total_cost_usd - old_ms.total_cost_usd
            cost_deltas.append(c_delta)

            # Per-metric regressions and improvements
            all_metrics = set(old_ms.per_metric_means.keys()) | set(
                new_ms.per_metric_means.keys()
            )
            for metric_name in sorted(all_metrics):
                old_val = old_ms.per_metric_means.get(metric_name, 0.0)
                new_val = new_ms.per_metric_means.get(metric_name, 0.0)
                delta = new_val - old_val

                pct = self._pct_change(old_val, new_val)

                if delta < -self._regression_threshold:
                    regressions.append(
                        Regression(
                            model_id=model_id,
                            metric_name=metric_name,
                            old_score=old_val,
                            new_score=new_val,
                            delta=abs(delta),
                            pct_change=pct,
                        )
                    )
                elif delta > self._improvement_threshold:
                    improvements.append(
                        Improvement(
                            model_id=model_id,
                            metric_name=metric_name,
                            old_score=old_val,
                            new_score=new_val,
                            delta=delta,
                            pct_change=pct,
                        )
                    )

            # Also check aggregate mean_score
            agg_delta = new_ms.mean_score - old_ms.mean_score
            agg_pct = self._pct_change(old_ms.mean_score, new_ms.mean_score)

            if agg_delta < -self._regression_threshold:
                regressions.append(
                    Regression(
                        model_id=model_id,
                        metric_name="_aggregate",
                        old_score=old_ms.mean_score,
                        new_score=new_ms.mean_score,
                        delta=abs(agg_delta),
                        pct_change=agg_pct,
                    )
                )
            elif agg_delta > self._improvement_threshold:
                improvements.append(
                    Improvement(
                        model_id=model_id,
                        metric_name="_aggregate",
                        old_score=old_ms.mean_score,
                        new_score=new_ms.mean_score,
                        delta=agg_delta,
                        pct_change=agg_pct,
                    )
                )

            # Cost efficiency
            cost_entries.append(
                CostEfficiencyEntry(
                    model_id=model_id,
                    old_efficiency=old_ms.cost_efficiency,
                    new_efficiency=new_ms.cost_efficiency,
                    delta=new_ms.cost_efficiency - old_ms.cost_efficiency,
                )
            )

        overall_q = sum(quality_deltas) / len(quality_deltas) if quality_deltas else 0.0
        overall_c = sum(cost_deltas) / len(cost_deltas) if cost_deltas else 0.0

        return ComparisonSummary(
            baseline_dataset=baseline.dataset_name,
            new_dataset=new.dataset_name,
            common_models=common_models,
            regressions=regressions,
            improvements=improvements,
            cost_efficiency=cost_entries,
            overall_quality_delta=overall_q,
            overall_cost_delta=overall_c,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _pct_change(old: float, new: float) -> float:
        """Compute percentage change from old to new.

        Returns ``0.0`` when old is zero.
        """
        if old == 0.0:
            return 0.0
        return ((new - old) / abs(old)) * 100.0
