"""Cost analytics and optimization intelligence.

Provides deep analysis of spending patterns, identifies waste, and
recommends actionable optimizations.  Goes far beyond simple cost
tracking — this is the intelligence layer that turns raw cost data
into money-saving insights.

Features:
    1. Spending trend analysis (daily/weekly/monthly)
    2. Per-model ROI calculation (cost vs quality)
    3. Waste detection (over-provisioned tokens, cache misses)
    4. Budget forecasting with confidence intervals
    5. Optimization recommendations ranked by savings potential
    6. Provider cost comparison for actual workload

Usage::

    analytics = CostAnalytics()
    analytics.record(model="gpt-4o", tokens_in=500, tokens_out=200, cost=0.005, quality=0.85)
    report = analytics.get_spending_report(period_days=30)
    recs = analytics.get_recommendations()
"""

from __future__ import annotations

import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class Period(Enum):
    """Time period for aggregation."""

    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"


@dataclass
class CostRecord:
    """A single cost event.

    Attributes:
        model: Model identifier.
        provider: Provider name.
        tokens_in: Input tokens consumed.
        tokens_out: Output tokens generated.
        cost_usd: Total cost in USD.
        quality_score: Quality assessment (0-1).
        latency_ms: Response latency.
        cached: Whether this was served from cache.
        timestamp: Unix timestamp.
        task_type: Task classification (code, chat, analysis).
    """

    model: str
    provider: str = ""
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    quality_score: float = 0.0
    latency_ms: float = 0.0
    cached: bool = False
    timestamp: float = field(default_factory=time.time)
    task_type: str = "general"


@dataclass
class ModelROI:
    """Return on investment for a model.

    Attributes:
        model: Model identifier.
        total_cost: Total spent.
        total_requests: Number of requests.
        avg_quality: Average quality score.
        avg_latency_ms: Average latency.
        quality_per_dollar: Quality points per dollar spent.
        cache_hit_rate: Fraction of requests served from cache.
    """

    model: str
    total_cost: float
    total_requests: int
    avg_quality: float
    avg_latency_ms: float
    quality_per_dollar: float
    cache_hit_rate: float


@dataclass
class SpendingTrend:
    """Spending trend over time.

    Attributes:
        period: Time period.
        data_points: List of (timestamp, cost_usd) tuples.
        total: Total cost in period.
        average_daily: Average daily spend.
        trend_direction: "increasing", "decreasing", or "stable".
        trend_pct: Percentage change over the period.
    """

    period: Period
    data_points: list[tuple[float, float]]
    total: float
    average_daily: float
    trend_direction: str
    trend_pct: float


@dataclass
class BudgetForecast:
    """Budget forecast with confidence intervals.

    Attributes:
        predicted_monthly_usd: Predicted monthly spend.
        lower_bound: 90% CI lower bound.
        upper_bound: 90% CI upper bound.
        days_until_budget_exceeded: Days until budget is exceeded (0 = never).
        confidence: Forecast confidence (0-1).
    """

    predicted_monthly_usd: float
    lower_bound: float
    upper_bound: float
    days_until_budget_exceeded: int
    confidence: float


@dataclass
class Recommendation:
    """An optimization recommendation.

    Attributes:
        title: Short recommendation title.
        description: Detailed explanation.
        estimated_savings_usd: Monthly savings potential.
        confidence: How confident we are (0-1).
        priority: 1 (highest) to 5 (lowest).
        action: Concrete action to take.
    """

    title: str
    description: str
    estimated_savings_usd: float
    confidence: float
    priority: int
    action: str


@dataclass
class SpendingReport:
    """Comprehensive spending analysis.

    Attributes:
        total_cost_usd: Total cost in the period.
        total_requests: Total requests.
        cost_by_model: Cost breakdown by model.
        cost_by_provider: Cost breakdown by provider.
        cost_by_task: Cost breakdown by task type.
        model_roi: ROI analysis per model.
        trend: Spending trend.
        forecast: Budget forecast.
        recommendations: Optimization recommendations.
        cache_savings_usd: Total savings from caching.
        waste_pct: Percentage of spend that was wasted.
    """

    total_cost_usd: float
    total_requests: int
    cost_by_model: dict[str, float]
    cost_by_provider: dict[str, float]
    cost_by_task: dict[str, float]
    model_roi: list[ModelROI]
    trend: SpendingTrend
    forecast: BudgetForecast
    recommendations: list[Recommendation]
    cache_savings_usd: float
    waste_pct: float


class CostAnalytics:
    """Cost analytics and optimization intelligence engine.

    Args:
        monthly_budget_usd: Monthly budget cap for forecasting.
    """

    def __init__(self, monthly_budget_usd: float = 50.0) -> None:
        self._records: list[CostRecord] = []
        self._monthly_budget = monthly_budget_usd

    def record(self, **kwargs: Any) -> CostRecord:
        """Record a cost event.

        Args:
            **kwargs: Fields for CostRecord.

        Returns:
            The recorded CostRecord.
        """
        rec = CostRecord(**kwargs)
        self._records.append(rec)
        return rec

    def add_record(self, record: CostRecord) -> None:
        """Add a pre-built cost record.

        Args:
            record: The cost record to add.
        """
        self._records.append(record)

    def get_spending_report(self, period_days: int = 30) -> SpendingReport:
        """Generate a comprehensive spending report.

        Args:
            period_days: Number of days to analyze.

        Returns:
            SpendingReport with full analysis.
        """
        cutoff = time.time() - (period_days * 86400)
        records = [r for r in self._records if r.timestamp >= cutoff]

        if not records:
            return SpendingReport(
                total_cost_usd=0.0,
                total_requests=0,
                cost_by_model={},
                cost_by_provider={},
                cost_by_task={},
                model_roi=[],
                trend=SpendingTrend(
                    period=Period.DAY, data_points=[], total=0.0,
                    average_daily=0.0, trend_direction="stable", trend_pct=0.0,
                ),
                forecast=BudgetForecast(
                    predicted_monthly_usd=0.0, lower_bound=0.0, upper_bound=0.0,
                    days_until_budget_exceeded=0, confidence=0.0,
                ),
                recommendations=[],
                cache_savings_usd=0.0,
                waste_pct=0.0,
            )

        total_cost = sum(r.cost_usd for r in records)
        total_requests = len(records)

        # Cost breakdowns
        cost_by_model = self._aggregate_cost(records, "model")
        cost_by_provider = self._aggregate_cost(records, "provider")
        cost_by_task = self._aggregate_cost(records, "task_type")

        # Model ROI
        model_roi = self._compute_model_roi(records)

        # Spending trend
        trend = self._compute_trend(records, period_days)

        # Forecast
        forecast = self._compute_forecast(records, period_days)

        # Cache savings
        cached_records = [r for r in records if r.cached]
        cache_savings = sum(r.cost_usd for r in cached_records) if cached_records else 0.0

        # Waste analysis
        waste_pct = self._compute_waste(records)

        # Recommendations
        recommendations = self._generate_recommendations(
            records, model_roi, cost_by_model, waste_pct,
        )

        return SpendingReport(
            total_cost_usd=round(total_cost, 4),
            total_requests=total_requests,
            cost_by_model=cost_by_model,
            cost_by_provider=cost_by_provider,
            cost_by_task=cost_by_task,
            model_roi=model_roi,
            trend=trend,
            forecast=forecast,
            recommendations=recommendations,
            cache_savings_usd=round(cache_savings, 4),
            waste_pct=round(waste_pct, 2),
        )

    def get_model_comparison(self) -> list[dict[str, Any]]:
        """Compare all models across key metrics.

        Returns:
            List of model comparison dicts.
        """
        by_model: dict[str, list[CostRecord]] = defaultdict(list)
        for r in self._records:
            by_model[r.model].append(r)

        comparisons = []
        for model, records in sorted(by_model.items()):
            costs = [r.cost_usd for r in records]
            qualities = [r.quality_score for r in records if r.quality_score > 0]
            latencies = [r.latency_ms for r in records if r.latency_ms > 0]

            comparisons.append({
                "model": model,
                "requests": len(records),
                "total_cost": round(sum(costs), 4),
                "avg_cost": round(_safe_mean(costs), 6),
                "avg_quality": round(_safe_mean(qualities), 3),
                "avg_latency_ms": round(_safe_mean(latencies), 1),
                "p95_latency_ms": round(_percentile(latencies, 0.95), 1),
                "tokens_per_dollar": round(
                    sum(r.tokens_out for r in records) / max(sum(costs), 0.0001), 0,
                ),
            })

        return comparisons

    def get_daily_costs(self, days: int = 30) -> list[dict[str, Any]]:
        """Get daily cost breakdown.

        Args:
            days: Number of days to include.

        Returns:
            List of daily cost summaries.
        """
        cutoff = time.time() - (days * 86400)
        records = [r for r in self._records if r.timestamp >= cutoff]

        by_day: dict[str, list[CostRecord]] = defaultdict(list)
        for r in records:
            day_key = time.strftime("%Y-%m-%d", time.localtime(r.timestamp))
            by_day[day_key].append(r)

        result = []
        for day, day_records in sorted(by_day.items()):
            result.append({
                "date": day,
                "cost_usd": round(sum(r.cost_usd for r in day_records), 4),
                "requests": len(day_records),
                "tokens_in": sum(r.tokens_in for r in day_records),
                "tokens_out": sum(r.tokens_out for r in day_records),
            })

        return result

    def clear(self) -> None:
        """Clear all records."""
        self._records.clear()

    @property
    def record_count(self) -> int:
        """Number of recorded events."""
        return len(self._records)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _aggregate_cost(
        self, records: list[CostRecord], attr: str,
    ) -> dict[str, float]:
        """Aggregate cost by a record attribute."""
        result: dict[str, float] = defaultdict(float)
        for r in records:
            key = getattr(r, attr, "unknown")
            result[key] += r.cost_usd
        return {k: round(v, 4) for k, v in sorted(result.items(), key=lambda x: -x[1])}

    def _compute_model_roi(self, records: list[CostRecord]) -> list[ModelROI]:
        """Compute ROI per model."""
        by_model: dict[str, list[CostRecord]] = defaultdict(list)
        for r in records:
            by_model[r.model].append(r)

        roi_list = []
        for model, model_records in by_model.items():
            total_cost = sum(r.cost_usd for r in model_records)
            qualities = [r.quality_score for r in model_records if r.quality_score > 0]
            latencies = [r.latency_ms for r in model_records if r.latency_ms > 0]
            cached = sum(1 for r in model_records if r.cached)

            avg_quality = _safe_mean(qualities)
            quality_per_dollar = avg_quality / max(total_cost, 0.0001)

            roi_list.append(ModelROI(
                model=model,
                total_cost=round(total_cost, 4),
                total_requests=len(model_records),
                avg_quality=round(avg_quality, 3),
                avg_latency_ms=round(_safe_mean(latencies), 1),
                quality_per_dollar=round(quality_per_dollar, 2),
                cache_hit_rate=round(cached / max(len(model_records), 1), 3),
            ))

        # Sort by quality_per_dollar (best ROI first)
        roi_list.sort(key=lambda x: x.quality_per_dollar, reverse=True)
        return roi_list

    def _compute_trend(
        self, records: list[CostRecord], period_days: int,
    ) -> SpendingTrend:
        """Compute spending trend."""
        # Group by day
        by_day: dict[str, float] = defaultdict(float)
        for r in records:
            day = time.strftime("%Y-%m-%d", time.localtime(r.timestamp))
            by_day[day] += r.cost_usd

        data_points = [(0.0, v) for v in by_day.values()]
        total = sum(by_day.values())
        avg_daily = total / max(len(by_day), 1)

        # Simple trend: compare first half vs second half
        days = sorted(by_day.items())
        if len(days) >= 4:
            mid = len(days) // 2
            first_half_avg = sum(v for _, v in days[:mid]) / mid
            second_half_avg = sum(v for _, v in days[mid:]) / (len(days) - mid)

            if first_half_avg > 0:
                trend_pct = ((second_half_avg - first_half_avg) / first_half_avg) * 100
            else:
                trend_pct = 0.0

            if trend_pct > 10:
                direction = "increasing"
            elif trend_pct < -10:
                direction = "decreasing"
            else:
                direction = "stable"
        else:
            trend_pct = 0.0
            direction = "stable"

        return SpendingTrend(
            period=Period.DAY,
            data_points=data_points,
            total=round(total, 4),
            average_daily=round(avg_daily, 4),
            trend_direction=direction,
            trend_pct=round(trend_pct, 1),
        )

    def _compute_forecast(
        self, records: list[CostRecord], period_days: int,
    ) -> BudgetForecast:
        """Compute budget forecast."""
        if not records:
            return BudgetForecast(
                predicted_monthly_usd=0.0,
                lower_bound=0.0,
                upper_bound=0.0,
                days_until_budget_exceeded=0,
                confidence=0.0,
            )

        total = sum(r.cost_usd for r in records)
        actual_days = max(1, period_days)
        daily_avg = total / actual_days

        # Simple forecast: project daily average
        monthly_predicted = daily_avg * 30

        # Variance-based confidence interval
        by_day: dict[str, float] = defaultdict(float)
        for r in records:
            day = time.strftime("%Y-%m-%d", time.localtime(r.timestamp))
            by_day[day] += r.cost_usd

        daily_costs = list(by_day.values())
        if len(daily_costs) >= 3:
            std = _safe_std(daily_costs)
            # 90% CI: ~1.645 standard deviations
            margin = 1.645 * std * math.sqrt(30)
            lower = max(0, monthly_predicted - margin)
            upper = monthly_predicted + margin
            confidence = min(0.9, len(daily_costs) / 30)
        else:
            lower = monthly_predicted * 0.5
            upper = monthly_predicted * 2.0
            confidence = 0.3

        # Days until budget exceeded
        if daily_avg > 0 and self._monthly_budget > 0:
            days_left = int(self._monthly_budget / daily_avg)
        else:
            days_left = 0  # Never exceeded

        return BudgetForecast(
            predicted_monthly_usd=round(monthly_predicted, 4),
            lower_bound=round(lower, 4),
            upper_bound=round(upper, 4),
            days_until_budget_exceeded=days_left,
            confidence=round(confidence, 2),
        )

    def _compute_waste(self, records: list[CostRecord]) -> float:
        """Estimate percentage of spending that is wasted."""
        if not records:
            return 0.0

        total_cost = sum(r.cost_usd for r in records)
        if total_cost == 0:
            return 0.0

        waste = 0.0

        # Low quality responses are waste
        for r in records:
            if r.quality_score > 0 and r.quality_score < 0.3:
                waste += r.cost_usd * 0.8  # 80% waste if quality < 0.3
            elif r.quality_score > 0 and r.quality_score < 0.5:
                waste += r.cost_usd * 0.4  # 40% waste if quality < 0.5

        return (waste / total_cost) * 100

    def _generate_recommendations(
        self,
        records: list[CostRecord],
        model_roi: list[ModelROI],
        cost_by_model: dict[str, float],
        waste_pct: float,
    ) -> list[Recommendation]:
        """Generate optimization recommendations."""
        recs: list[Recommendation] = []

        # Check for cache opportunity
        non_cached = [r for r in records if not r.cached]
        if len(non_cached) > 10:
            cache_potential = sum(r.cost_usd for r in non_cached) * 0.3
            if cache_potential > 0.01:
                recs.append(Recommendation(
                    title="Enable semantic caching",
                    description=(
                        f"{len(non_cached)} non-cached requests detected. "
                        f"Semantic caching could save ~30% of these costs."
                    ),
                    estimated_savings_usd=round(cache_potential, 4),
                    confidence=0.7,
                    priority=1,
                    action="Enable semantic_cache in prism settings",
                ))

        # Check for expensive model overuse
        if model_roi and len(model_roi) >= 2:
            best_roi = model_roi[0]
            for roi in model_roi[1:]:
                if roi.total_cost > best_roi.total_cost * 2 and roi.avg_quality <= best_roi.avg_quality * 1.1:
                    savings = roi.total_cost - (roi.total_requests * best_roi.total_cost / max(best_roi.total_requests, 1))
                    recs.append(Recommendation(
                        title=f"Replace {roi.model} with {best_roi.model}",
                        description=(
                            f"{roi.model} costs {roi.total_cost:.4f} USD with quality {roi.avg_quality:.2f}. "
                            f"{best_roi.model} achieves similar quality ({best_roi.avg_quality:.2f}) at lower cost."
                        ),
                        estimated_savings_usd=round(max(0, savings), 4),
                        confidence=0.6,
                        priority=2,
                        action=f"Update routing to prefer {best_roi.model} for tasks currently using {roi.model}",
                    ))

        # High waste warning
        if waste_pct > 20:
            total_cost = sum(r.cost_usd for r in records)
            recs.append(Recommendation(
                title="Reduce low-quality responses",
                description=(
                    f"{waste_pct:.1f}% of spending produces low-quality results. "
                    f"Consider adjusting prompts or model selection."
                ),
                estimated_savings_usd=round(total_cost * waste_pct / 100 * 0.5, 4),
                confidence=0.5,
                priority=2,
                action="Review and improve prompts for low-scoring requests",
            ))

        # Sort by savings potential
        recs.sort(key=lambda r: r.estimated_savings_usd, reverse=True)
        return recs


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def _safe_mean(values: list[float]) -> float:
    """Compute mean, returning 0 for empty list."""
    if not values:
        return 0.0
    return sum(values) / len(values)


def _safe_std(values: list[float]) -> float:
    """Compute standard deviation, returning 0 for insufficient data."""
    if len(values) < 2:
        return 0.0
    mean = _safe_mean(values)
    variance = sum((x - mean) ** 2 for x in values) / (len(values) - 1)
    return math.sqrt(variance)


def _percentile(values: list[float], p: float) -> float:
    """Compute percentile."""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    idx = int(len(sorted_vals) * p)
    idx = min(idx, len(sorted_vals) - 1)
    return sorted_vals[idx]
