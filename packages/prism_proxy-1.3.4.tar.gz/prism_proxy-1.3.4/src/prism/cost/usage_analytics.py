"""Usage analytics engine — request volume, latency, error rates, and anomaly detection.

Provides comprehensive usage analytics beyond cost tracking.  Tracks request
volume (RPM/RPH/RPD), token consumption ratios, error rates, latency
percentiles, session-level analytics, peak usage detection, provider
comparison reports, time-series aggregation, and anomaly detection.

Usage::

    engine = UsageAnalytics()
    engine.record(UsageRecord(
        timestamp=time.time(), model="gpt-4o", provider="openai",
        tokens_in=500, tokens_out=200, latency_ms=320.0,
        cost_usd=0.005, success=True,
    ))
    report = engine.provider_report("openai")
    anomalies = engine.detect_anomalies()
    export = engine.export()
"""

from __future__ import annotations

import math
import statistics
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class BucketSize(Enum):
    """Time-series aggregation bucket sizes."""

    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"


@dataclass
class AnalyticsConfig:
    """Configuration for the usage analytics engine.

    Attributes:
        retention_days: How many days of records to retain for queries.
        bucket_size: Default time-series bucket size.
        anomaly_sensitivity: Z-score threshold for anomaly detection (lower = more sensitive).
        session_gap_seconds: Max gap between requests in the same session.
    """

    retention_days: int = 90
    bucket_size: BucketSize = BucketSize.HOURLY
    anomaly_sensitivity: float = 2.0
    session_gap_seconds: int = 1800  # 30 minutes


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class UsageRecord:
    """A single API request record.

    Attributes:
        timestamp: Unix timestamp of the request.
        model: Model identifier (e.g. ``gpt-4o``).
        provider: Provider name (e.g. ``openai``).
        tokens_in: Input tokens consumed.
        tokens_out: Output tokens generated.
        latency_ms: End-to-end latency in milliseconds.
        cost_usd: Cost in USD.
        success: Whether the request succeeded.
        error_type: Error category if ``success`` is False.
        session_id: Session identifier for session-level analytics.
    """

    timestamp: float = field(default_factory=time.time)
    model: str = ""
    provider: str = ""
    tokens_in: int = 0
    tokens_out: int = 0
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    success: bool = True
    error_type: str = ""
    session_id: str = ""


@dataclass
class TimeSeriesBucket:
    """Aggregated metrics for a single time bucket.

    Attributes:
        period_start: Unix timestamp for the bucket start.
        period_end: Unix timestamp for the bucket end.
        request_count: Total requests in the bucket.
        token_count: Total tokens (in + out) in the bucket.
        avg_latency: Average latency in milliseconds.
        error_count: Number of failed requests.
        cost_total: Total cost in USD.
    """

    period_start: float = 0.0
    period_end: float = 0.0
    request_count: int = 0
    token_count: int = 0
    avg_latency: float = 0.0
    error_count: int = 0
    cost_total: float = 0.0


@dataclass
class ProviderReport:
    """Per-provider summary report.

    Attributes:
        provider: Provider name.
        request_count: Total requests.
        success_rate: Fraction of successful requests (0.0-1.0).
        avg_latency: Average latency in milliseconds.
        p50_latency: 50th-percentile latency.
        p75_latency: 75th-percentile latency.
        p90_latency: 90th-percentile latency.
        p95_latency: 95th-percentile latency.
        p99_latency: 99th-percentile latency.
        total_cost: Total cost in USD.
        avg_quality: Average quality score (reserved, defaults to 0.0).
        error_breakdown: Counts per error type.
        models_used: Set of models used with this provider.
    """

    provider: str = ""
    request_count: int = 0
    success_rate: float = 1.0
    avg_latency: float = 0.0
    p50_latency: float = 0.0
    p75_latency: float = 0.0
    p90_latency: float = 0.0
    p95_latency: float = 0.0
    p99_latency: float = 0.0
    total_cost: float = 0.0
    avg_quality: float = 0.0
    error_breakdown: dict[str, int] = field(default_factory=dict)
    models_used: list[str] = field(default_factory=list)


@dataclass
class SessionReport:
    """Session-level analytics.

    Attributes:
        session_id: Session identifier.
        start_time: Unix timestamp of the first request.
        end_time: Unix timestamp of the last request.
        duration_seconds: Session wall-clock duration.
        request_count: Total requests in the session.
        total_cost: Total cost in USD.
        total_tokens: Total tokens (in + out).
        error_count: Number of errors.
        models_used: Distinct models used.
    """

    session_id: str = ""
    start_time: float = 0.0
    end_time: float = 0.0
    duration_seconds: float = 0.0
    request_count: int = 0
    total_cost: float = 0.0
    total_tokens: int = 0
    error_count: int = 0
    models_used: list[str] = field(default_factory=list)


@dataclass
class AnomalyDetection:
    """A detected usage anomaly.

    Attributes:
        metric: Name of the anomalous metric (e.g. ``request_count``).
        expected: Expected value (mean of the baseline).
        actual: Observed value.
        severity: Severity score (absolute z-score).
        timestamp: Unix timestamp of the anomalous bucket.
        direction: ``"spike"`` or ``"drop"``.
    """

    metric: str = ""
    expected: float = 0.0
    actual: float = 0.0
    severity: float = 0.0
    timestamp: float = 0.0
    direction: str = ""


@dataclass
class PeakUsage:
    """Peak usage period.

    Attributes:
        period_label: Human-readable period label (e.g. ``"2025-03-13 14:00"``).
        period_start: Unix timestamp of the period start.
        request_count: Number of requests in that period.
        total_tokens: Total tokens in that period.
        total_cost: Total cost in that period.
    """

    period_label: str = ""
    period_start: float = 0.0
    request_count: int = 0
    total_tokens: int = 0
    total_cost: float = 0.0


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------


class UsageAnalytics:
    """Comprehensive usage analytics engine.

    Tracks request volume, token consumption, error rates, latency
    percentiles, session analytics, peak usage, and detects anomalies.

    Args:
        config: Analytics configuration.  Uses defaults if not provided.
    """

    def __init__(self, config: AnalyticsConfig | None = None) -> None:
        self._config = config or AnalyticsConfig()
        self._records: list[UsageRecord] = []

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record(self, rec: UsageRecord) -> None:
        """Record a single usage event.

        Args:
            rec: The usage record to store.
        """
        self._records.append(rec)
        logger.debug(
            "usage_recorded",
            model=rec.model,
            provider=rec.provider,
            success=rec.success,
            latency_ms=rec.latency_ms,
        )

    def record_many(self, records: list[UsageRecord]) -> None:
        """Record multiple usage events at once.

        Args:
            records: List of usage records to store.
        """
        self._records.extend(records)

    @property
    def record_count(self) -> int:
        """Total number of stored records."""
        return len(self._records)

    def clear(self) -> None:
        """Remove all stored records."""
        self._records.clear()

    # ------------------------------------------------------------------
    # Request volume
    # ------------------------------------------------------------------

    def requests_per_minute(
        self,
        model: str | None = None,
        provider: str | None = None,
        window_minutes: int = 60,
    ) -> float:
        """Calculate average requests per minute over a window.

        Args:
            model: Filter by model (optional).
            provider: Filter by provider (optional).
            window_minutes: Lookback window in minutes.

        Returns:
            Average RPM over the window.
        """
        records = self._filter(model=model, provider=provider, window_minutes=window_minutes)
        if not records:
            return 0.0
        return len(records) / max(window_minutes, 1)

    def requests_per_hour(
        self,
        model: str | None = None,
        provider: str | None = None,
        window_hours: int = 24,
    ) -> float:
        """Calculate average requests per hour over a window.

        Args:
            model: Filter by model (optional).
            provider: Filter by provider (optional).
            window_hours: Lookback window in hours.

        Returns:
            Average RPH over the window.
        """
        records = self._filter(model=model, provider=provider, window_minutes=window_hours * 60)
        if not records:
            return 0.0
        return len(records) / max(window_hours, 1)

    def requests_per_day(
        self,
        model: str | None = None,
        provider: str | None = None,
        window_days: int = 30,
    ) -> float:
        """Calculate average requests per day over a window.

        Args:
            model: Filter by model (optional).
            provider: Filter by provider (optional).
            window_days: Lookback window in days.

        Returns:
            Average RPD over the window.
        """
        records = self._filter(model=model, provider=provider, window_minutes=window_days * 1440)
        if not records:
            return 0.0
        return len(records) / max(window_days, 1)

    # ------------------------------------------------------------------
    # Token consumption
    # ------------------------------------------------------------------

    def token_consumption(
        self,
        model: str | None = None,
        provider: str | None = None,
    ) -> dict[str, Any]:
        """Analyze token consumption patterns.

        Args:
            model: Filter by model (optional).
            provider: Filter by provider (optional).

        Returns:
            Dict with ``total_in``, ``total_out``, ``ratio``, ``avg_in``,
            ``avg_out``, and ``total`` keys.
        """
        records = self._filter(model=model, provider=provider)
        if not records:
            return {
                "total_in": 0,
                "total_out": 0,
                "ratio": 0.0,
                "avg_in": 0.0,
                "avg_out": 0.0,
                "total": 0,
            }

        total_in = sum(r.tokens_in for r in records)
        total_out = sum(r.tokens_out for r in records)
        count = len(records)

        return {
            "total_in": total_in,
            "total_out": total_out,
            "ratio": total_in / max(total_out, 1),
            "avg_in": total_in / count,
            "avg_out": total_out / count,
            "total": total_in + total_out,
        }

    # ------------------------------------------------------------------
    # Error rates
    # ------------------------------------------------------------------

    def error_rate(
        self,
        provider: str | None = None,
        window_minutes: int | None = None,
    ) -> float:
        """Calculate error rate as a fraction (0.0 - 1.0).

        Args:
            provider: Filter by provider (optional).
            window_minutes: Lookback window (optional).

        Returns:
            Error rate between 0.0 and 1.0.
        """
        records = self._filter(provider=provider, window_minutes=window_minutes)
        if not records:
            return 0.0
        errors = sum(1 for r in records if not r.success)
        return errors / len(records)

    def error_breakdown(
        self,
        provider: str | None = None,
    ) -> dict[str, int]:
        """Get error counts categorized by error type.

        Args:
            provider: Filter by provider (optional).

        Returns:
            Dict mapping error_type to count.
        """
        records = self._filter(provider=provider)
        breakdown: dict[str, int] = defaultdict(int)
        for r in records:
            if not r.success and r.error_type:
                breakdown[r.error_type] += 1
        return dict(breakdown)

    # ------------------------------------------------------------------
    # Latency percentiles
    # ------------------------------------------------------------------

    def latency_percentiles(
        self,
        model: str | None = None,
        provider: str | None = None,
    ) -> dict[str, float]:
        """Calculate latency percentiles (P50, P75, P90, P95, P99).

        Args:
            model: Filter by model (optional).
            provider: Filter by provider (optional).

        Returns:
            Dict with ``p50``, ``p75``, ``p90``, ``p95``, ``p99`` keys.
        """
        records = self._filter(model=model, provider=provider)
        latencies = [r.latency_ms for r in records if r.latency_ms > 0]

        if not latencies:
            return {"p50": 0.0, "p75": 0.0, "p90": 0.0, "p95": 0.0, "p99": 0.0}

        latencies_sorted = sorted(latencies)
        return {
            "p50": _percentile(latencies_sorted, 0.50),
            "p75": _percentile(latencies_sorted, 0.75),
            "p90": _percentile(latencies_sorted, 0.90),
            "p95": _percentile(latencies_sorted, 0.95),
            "p99": _percentile(latencies_sorted, 0.99),
        }

    # ------------------------------------------------------------------
    # Session analytics
    # ------------------------------------------------------------------

    def session_reports(self) -> list[SessionReport]:
        """Generate analytics for each distinct session.

        Returns:
            List of SessionReport, one per session_id found in records.
        """
        by_session: dict[str, list[UsageRecord]] = defaultdict(list)
        for r in self._records:
            key = r.session_id or "_default"
            by_session[key].append(r)

        reports: list[SessionReport] = []
        for sid, recs in by_session.items():
            recs_sorted = sorted(recs, key=lambda rec: rec.timestamp)
            start = recs_sorted[0].timestamp
            end = recs_sorted[-1].timestamp
            models = sorted({r.model for r in recs if r.model})

            reports.append(SessionReport(
                session_id=sid,
                start_time=start,
                end_time=end,
                duration_seconds=end - start,
                request_count=len(recs),
                total_cost=sum(r.cost_usd for r in recs),
                total_tokens=sum(r.tokens_in + r.tokens_out for r in recs),
                error_count=sum(1 for r in recs if not r.success),
                models_used=models,
            ))

        return reports

    def session_summary(self) -> dict[str, float]:
        """Compute aggregate session statistics.

        Returns:
            Dict with ``avg_duration_seconds``, ``avg_requests``,
            ``avg_cost``, ``total_sessions`` keys.
        """
        reports = self.session_reports()
        if not reports:
            return {
                "avg_duration_seconds": 0.0,
                "avg_requests": 0.0,
                "avg_cost": 0.0,
                "total_sessions": 0.0,
            }

        return {
            "avg_duration_seconds": _safe_mean([r.duration_seconds for r in reports]),
            "avg_requests": _safe_mean([float(r.request_count) for r in reports]),
            "avg_cost": _safe_mean([r.total_cost for r in reports]),
            "total_sessions": float(len(reports)),
        }

    # ------------------------------------------------------------------
    # Peak usage detection
    # ------------------------------------------------------------------

    def peak_usage(
        self,
        bucket_size: BucketSize | None = None,
        top_n: int = 5,
    ) -> list[PeakUsage]:
        """Identify the busiest time periods.

        Args:
            bucket_size: Bucket size for grouping. Defaults to config value.
            top_n: Number of top periods to return.

        Returns:
            List of PeakUsage sorted by request count descending.
        """
        bs = bucket_size or self._config.bucket_size
        buckets = self._build_time_series(bs)
        if not buckets:
            return []

        peaks: list[PeakUsage] = []
        for bucket in buckets:
            label = _format_timestamp(bucket.period_start, bs)
            peaks.append(PeakUsage(
                period_label=label,
                period_start=bucket.period_start,
                request_count=bucket.request_count,
                total_tokens=bucket.token_count,
                total_cost=bucket.cost_total,
            ))

        peaks.sort(key=lambda p: p.request_count, reverse=True)
        return peaks[:top_n]

    # ------------------------------------------------------------------
    # Provider comparison
    # ------------------------------------------------------------------

    def provider_report(self, provider: str) -> ProviderReport:
        """Generate a detailed report for a single provider.

        Args:
            provider: Provider name to report on.

        Returns:
            ProviderReport with full metrics.
        """
        records = [r for r in self._records if r.provider == provider]
        if not records:
            return ProviderReport(provider=provider)

        latencies = [r.latency_ms for r in records if r.latency_ms > 0]
        latencies_sorted = sorted(latencies)
        errors = [r for r in records if not r.success]
        models = sorted({r.model for r in records if r.model})

        err_breakdown: dict[str, int] = defaultdict(int)
        for r in errors:
            if r.error_type:
                err_breakdown[r.error_type] += 1

        return ProviderReport(
            provider=provider,
            request_count=len(records),
            success_rate=1.0 - (len(errors) / len(records)),
            avg_latency=_safe_mean(latencies),
            p50_latency=_percentile(latencies_sorted, 0.50),
            p75_latency=_percentile(latencies_sorted, 0.75),
            p90_latency=_percentile(latencies_sorted, 0.90),
            p95_latency=_percentile(latencies_sorted, 0.95),
            p99_latency=_percentile(latencies_sorted, 0.99),
            total_cost=sum(r.cost_usd for r in records),
            error_breakdown=dict(err_breakdown),
            models_used=models,
        )

    def provider_comparison(self) -> list[ProviderReport]:
        """Generate comparison reports for all providers.

        Returns:
            List of ProviderReport, one per distinct provider.
        """
        providers = sorted({r.provider for r in self._records if r.provider})
        return [self.provider_report(p) for p in providers]

    # ------------------------------------------------------------------
    # Time-series aggregation
    # ------------------------------------------------------------------

    def time_series(
        self,
        bucket_size: BucketSize | None = None,
        model: str | None = None,
        provider: str | None = None,
    ) -> list[TimeSeriesBucket]:
        """Build time-series data from stored records.

        Args:
            bucket_size: Aggregation granularity. Defaults to config value.
            model: Filter by model (optional).
            provider: Filter by provider (optional).

        Returns:
            List of TimeSeriesBucket ordered chronologically.
        """
        bs = bucket_size or self._config.bucket_size
        records = self._filter(model=model, provider=provider)
        return self._build_time_series(bs, records)

    # ------------------------------------------------------------------
    # Anomaly detection
    # ------------------------------------------------------------------

    def detect_anomalies(
        self,
        bucket_size: BucketSize | None = None,
    ) -> list[AnomalyDetection]:
        """Detect usage anomalies (sudden spikes or drops).

        Uses z-score analysis on time-series buckets to identify outliers.

        Args:
            bucket_size: Bucket size for grouping. Defaults to config value.

        Returns:
            List of AnomalyDetection sorted by severity descending.
        """
        bs = bucket_size or self._config.bucket_size
        buckets = self._build_time_series(bs)

        if len(buckets) < 3:
            return []

        anomalies: list[AnomalyDetection] = []
        threshold = self._config.anomaly_sensitivity

        # Check request_count anomalies
        request_counts = [float(b.request_count) for b in buckets]
        anomalies.extend(
            self._detect_metric_anomalies(
                "request_count", request_counts, buckets, threshold,
            )
        )

        # Check cost_total anomalies
        costs = [b.cost_total for b in buckets]
        anomalies.extend(
            self._detect_metric_anomalies(
                "cost_total", costs, buckets, threshold,
            )
        )

        # Check error_count anomalies
        error_counts = [float(b.error_count) for b in buckets]
        anomalies.extend(
            self._detect_metric_anomalies(
                "error_count", error_counts, buckets, threshold,
            )
        )

        anomalies.sort(key=lambda a: a.severity, reverse=True)
        return anomalies

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export(self) -> dict[str, Any]:
        """Export all analytics to a structured dict for rendering.

        Returns:
            Dict with keys ``summary``, ``providers``, ``time_series``,
            ``sessions``, ``peaks``, ``anomalies``, ``token_consumption``,
            ``latency_percentiles``.
        """
        providers = self.provider_comparison()
        ts = self.time_series()
        sessions = self.session_reports()
        peaks = self.peak_usage()
        anomalies = self.detect_anomalies()
        tokens = self.token_consumption()
        latency = self.latency_percentiles()

        total_requests = len(self._records)
        total_cost = sum(r.cost_usd for r in self._records)
        total_errors = sum(1 for r in self._records if not r.success)

        return {
            "summary": {
                "total_requests": total_requests,
                "total_cost_usd": round(total_cost, 6),
                "total_errors": total_errors,
                "error_rate": round(total_errors / max(total_requests, 1), 4),
                "unique_models": len({r.model for r in self._records if r.model}),
                "unique_providers": len({r.provider for r in self._records if r.provider}),
            },
            "providers": [
                {
                    "provider": p.provider,
                    "request_count": p.request_count,
                    "success_rate": round(p.success_rate, 4),
                    "avg_latency": round(p.avg_latency, 2),
                    "p95_latency": round(p.p95_latency, 2),
                    "total_cost": round(p.total_cost, 6),
                    "models_used": p.models_used,
                }
                for p in providers
            ],
            "time_series": [
                {
                    "period_start": b.period_start,
                    "period_end": b.period_end,
                    "request_count": b.request_count,
                    "token_count": b.token_count,
                    "avg_latency": round(b.avg_latency, 2),
                    "error_count": b.error_count,
                    "cost_total": round(b.cost_total, 6),
                }
                for b in ts
            ],
            "sessions": [
                {
                    "session_id": s.session_id,
                    "duration_seconds": round(s.duration_seconds, 2),
                    "request_count": s.request_count,
                    "total_cost": round(s.total_cost, 6),
                    "error_count": s.error_count,
                }
                for s in sessions
            ],
            "peaks": [
                {
                    "period_label": p.period_label,
                    "request_count": p.request_count,
                    "total_tokens": p.total_tokens,
                    "total_cost": round(p.total_cost, 6),
                }
                for p in peaks
            ],
            "anomalies": [
                {
                    "metric": a.metric,
                    "expected": round(a.expected, 4),
                    "actual": round(a.actual, 4),
                    "severity": round(a.severity, 4),
                    "direction": a.direction,
                }
                for a in anomalies
            ],
            "token_consumption": tokens,
            "latency_percentiles": {
                k: round(v, 2) for k, v in latency.items()
            },
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _filter(
        self,
        model: str | None = None,
        provider: str | None = None,
        window_minutes: int | None = None,
    ) -> list[UsageRecord]:
        """Filter records by model, provider, and time window.

        Args:
            model: Optional model filter.
            provider: Optional provider filter.
            window_minutes: Optional time window in minutes from now.

        Returns:
            Filtered list of records.
        """
        records = self._records

        if window_minutes is not None:
            cutoff = time.time() - (window_minutes * 60)
            records = [r for r in records if r.timestamp >= cutoff]

        if model is not None:
            records = [r for r in records if r.model == model]

        if provider is not None:
            records = [r for r in records if r.provider == provider]

        return records

    def _build_time_series(
        self,
        bucket_size: BucketSize,
        records: list[UsageRecord] | None = None,
    ) -> list[TimeSeriesBucket]:
        """Build aggregated time-series buckets.

        Args:
            bucket_size: Granularity of the buckets.
            records: Records to aggregate (defaults to all stored records).

        Returns:
            List of TimeSeriesBucket ordered chronologically.
        """
        recs = records if records is not None else self._records
        if not recs:
            return []

        bucket_seconds = _bucket_seconds(bucket_size)
        grouped: dict[float, list[UsageRecord]] = defaultdict(list)

        for r in recs:
            bucket_start = math.floor(r.timestamp / bucket_seconds) * bucket_seconds
            grouped[bucket_start].append(r)

        buckets: list[TimeSeriesBucket] = []
        for start in sorted(grouped):
            group = grouped[start]
            latencies = [r.latency_ms for r in group if r.latency_ms > 0]

            buckets.append(TimeSeriesBucket(
                period_start=start,
                period_end=start + bucket_seconds,
                request_count=len(group),
                token_count=sum(r.tokens_in + r.tokens_out for r in group),
                avg_latency=_safe_mean(latencies),
                error_count=sum(1 for r in group if not r.success),
                cost_total=sum(r.cost_usd for r in group),
            ))

        return buckets

    def _detect_metric_anomalies(
        self,
        metric_name: str,
        values: list[float],
        buckets: list[TimeSeriesBucket],
        threshold: float,
    ) -> list[AnomalyDetection]:
        """Detect anomalies in a single metric series.

        Args:
            metric_name: Name of the metric.
            values: Metric values aligned with buckets.
            buckets: Corresponding time-series buckets.
            threshold: Z-score threshold.

        Returns:
            List of detected anomalies.
        """
        if len(values) < 3:
            return []

        mean = statistics.mean(values)
        stdev = statistics.pstdev(values)

        if stdev == 0:
            return []

        anomalies: list[AnomalyDetection] = []
        for i, val in enumerate(values):
            z = abs(val - mean) / stdev
            if z >= threshold:
                direction = "spike" if val > mean else "drop"
                anomalies.append(AnomalyDetection(
                    metric=metric_name,
                    expected=mean,
                    actual=val,
                    severity=z,
                    timestamp=buckets[i].period_start,
                    direction=direction,
                ))

        return anomalies


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def _safe_mean(values: list[float]) -> float:
    """Compute mean, returning 0.0 for an empty list.

    Args:
        values: List of numeric values.

    Returns:
        Arithmetic mean, or 0.0 if empty.
    """
    if not values:
        return 0.0
    return sum(values) / len(values)


def _percentile(sorted_values: list[float], p: float) -> float:
    """Compute percentile from a pre-sorted list using linear interpolation.

    Args:
        sorted_values: Pre-sorted list of values.
        p: Percentile as a fraction (0.0 to 1.0).

    Returns:
        Interpolated percentile value, or 0.0 if list is empty.
    """
    if not sorted_values:
        return 0.0

    n = len(sorted_values)
    if n == 1:
        return sorted_values[0]

    # Use the "exclusive" method: rank = p * (n + 1) - 1 (0-indexed)
    rank = p * (n - 1)
    lower = math.floor(rank)
    upper = min(lower + 1, n - 1)
    fraction = rank - lower
    return sorted_values[lower] + fraction * (sorted_values[upper] - sorted_values[lower])


def _bucket_seconds(bucket_size: BucketSize) -> float:
    """Return the number of seconds per bucket.

    Args:
        bucket_size: The bucket granularity.

    Returns:
        Seconds per bucket.
    """
    if bucket_size == BucketSize.HOURLY:
        return 3600.0
    if bucket_size == BucketSize.DAILY:
        return 86400.0
    # WEEKLY
    return 604800.0


def _format_timestamp(ts: float, bucket_size: BucketSize) -> str:
    """Format a timestamp into a human-readable label for the given bucket size.

    Args:
        ts: Unix timestamp.
        bucket_size: Bucket granularity (determines format).

    Returns:
        Formatted string.
    """
    t = time.localtime(ts)
    if bucket_size == BucketSize.HOURLY:
        return time.strftime("%Y-%m-%d %H:00", t)
    if bucket_size == BucketSize.DAILY:
        return time.strftime("%Y-%m-%d", t)
    return time.strftime("Week of %Y-%m-%d", t)
