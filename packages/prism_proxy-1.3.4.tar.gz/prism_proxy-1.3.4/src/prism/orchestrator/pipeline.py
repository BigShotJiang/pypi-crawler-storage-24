"""Request pipeline — the unified execution path for every LLM request.

Orchestrates the full lifecycle of an AI request through all Prism subsystems:
classification → routing → caching → compression → rate limiting →
execution → validation → cost tracking → learning.

This is the single entry point that wires all Prism intelligence modules
together into a coherent, observable pipeline.

Usage::

    pipeline = RequestPipeline(config)
    result = await pipeline.execute(
        prompt="Fix the authentication bug",
        context=conversation_history,
    )
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class PipelineStage(Enum):
    """Stages in the request pipeline."""

    CLASSIFY = "classify"
    ROUTE = "route"
    CACHE_CHECK = "cache_check"
    COMPRESS = "compress"
    RATE_LIMIT = "rate_limit"
    EXECUTE = "execute"
    VALIDATE = "validate"
    CACHE_STORE = "cache_store"
    TRACK_COST = "track_cost"
    LEARN = "learn"


@dataclass
class StageResult:
    """Result from a single pipeline stage.

    Attributes:
        stage: Which stage produced this.
        success: Whether the stage succeeded.
        duration_ms: Time spent in this stage.
        data: Output data from the stage.
        skipped: Whether the stage was skipped.
        error: Error message if failed.
    """

    stage: PipelineStage
    success: bool = True
    duration_ms: float = 0.0
    data: dict[str, Any] = field(default_factory=dict)
    skipped: bool = False
    error: str = ""


@dataclass
class PipelineResult:
    """Full result from pipeline execution.

    Attributes:
        content: The final response content.
        model_used: Which model served the request.
        provider: Which provider was used.
        total_duration_ms: Total pipeline execution time.
        stages: Results from each pipeline stage.
        from_cache: Whether the response came from cache.
        cost_usd: Cost of this request.
        tokens_in: Input tokens consumed.
        tokens_out: Output tokens generated.
        quality_score: Quality assessment of the response.
        metadata: Additional metadata.
    """

    content: str = ""
    model_used: str = ""
    provider: str = ""
    total_duration_ms: float = 0.0
    stages: list[StageResult] = field(default_factory=list)
    from_cache: bool = False
    cost_usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    quality_score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        """Whether the pipeline completed successfully."""
        return bool(self.content)

    @property
    def stage_timings(self) -> dict[str, float]:
        """Timing breakdown by stage."""
        return {s.stage.value: s.duration_ms for s in self.stages if not s.skipped}


@dataclass
class PipelineConfig:
    """Pipeline configuration.

    Attributes:
        enable_cache: Whether to check/store semantic cache.
        enable_compression: Whether to compress prompts.
        enable_rate_limiting: Whether to enforce rate limits.
        enable_validation: Whether to validate responses.
        enable_learning: Whether to update learning models.
        max_retries: Maximum provider retries on failure.
        timeout_ms: Overall pipeline timeout.
        quality_threshold: Minimum quality score to accept.
    """

    enable_cache: bool = True
    enable_compression: bool = True
    enable_rate_limiting: bool = True
    enable_validation: bool = True
    enable_learning: bool = True
    max_retries: int = 2
    timeout_ms: float = 60000
    quality_threshold: float = 0.3


class PipelineMiddleware:
    """Base class for pipeline middleware.

    Middleware can intercept and modify requests/responses at any stage.
    """

    def __init__(self, name: str) -> None:
        self.name = name

    async def before_execute(
        self,
        prompt: str,
        model: str,
        context: dict[str, Any],
    ) -> tuple[str, str, dict[str, Any]]:
        """Called before LLM execution. Can modify prompt/model/context.

        Args:
            prompt: The prompt to send.
            model: The selected model.
            context: Request context.

        Returns:
            Possibly modified (prompt, model, context).
        """
        return prompt, model, context

    async def after_execute(
        self,
        result: PipelineResult,
        context: dict[str, Any],
    ) -> PipelineResult:
        """Called after LLM execution. Can modify result.

        Args:
            result: The pipeline result.
            context: Request context.

        Returns:
            Possibly modified result.
        """
        return result


class RequestPipeline:
    """Unified request pipeline orchestrating all Prism subsystems.

    Args:
        config: Pipeline configuration.
    """

    def __init__(self, config: PipelineConfig | None = None) -> None:
        self._config = config or PipelineConfig()
        self._middleware: list[PipelineMiddleware] = []

        # Pluggable stage handlers (injected by the application)
        self._classifier: Any = None
        self._router: Any = None
        self._cache: Any = None
        self._compressor: Any = None
        self._rate_limiter: Any = None
        self._executor: Any = None
        self._validator: Any = None
        self._cost_tracker: Any = None
        self._learner: Any = None

    def add_middleware(self, middleware: PipelineMiddleware) -> None:
        """Add middleware to the pipeline.

        Args:
            middleware: Middleware instance.
        """
        self._middleware.append(middleware)
        logger.debug("middleware_added", name=middleware.name)

    def set_classifier(self, classifier: Any) -> None:
        """Set the task classifier."""
        self._classifier = classifier

    def set_router(self, router: Any) -> None:
        """Set the model router/selector."""
        self._router = router

    def set_cache(self, cache: Any) -> None:
        """Set the semantic cache."""
        self._cache = cache

    def set_compressor(self, compressor: Any) -> None:
        """Set the prompt compressor."""
        self._compressor = compressor

    def set_rate_limiter(self, rate_limiter: Any) -> None:
        """Set the rate limiter."""
        self._rate_limiter = rate_limiter

    def set_executor(self, executor: Any) -> None:
        """Set the LLM executor."""
        self._executor = executor

    def set_validator(self, validator: Any) -> None:
        """Set the response validator."""
        self._validator = validator

    def set_cost_tracker(self, cost_tracker: Any) -> None:
        """Set the cost tracker."""
        self._cost_tracker = cost_tracker

    def set_learner(self, learner: Any) -> None:
        """Set the adaptive learning module."""
        self._learner = learner

    async def execute(
        self,
        prompt: str,
        messages: list[dict[str, str]] | None = None,
        model_hint: str = "",
        task_type: str = "",
        context: dict[str, Any] | None = None,
    ) -> PipelineResult:
        """Execute the full request pipeline.

        Args:
            prompt: User prompt text.
            messages: Optional full message history.
            model_hint: Optional model preference.
            task_type: Optional task type hint.
            context: Additional context for middleware.

        Returns:
            PipelineResult with response and metadata.
        """
        pipeline_start = time.perf_counter()
        result = PipelineResult()
        ctx = context or {}
        ctx["prompt"] = prompt
        ctx["messages"] = messages or []

        try:
            # Stage 1: Classify
            stage = await self._run_stage(
                PipelineStage.CLASSIFY,
                self._stage_classify, prompt, task_type,
            )
            result.stages.append(stage)
            complexity = stage.data.get("complexity", "medium")
            ctx["complexity"] = complexity

            # Stage 2: Route
            stage = await self._run_stage(
                PipelineStage.ROUTE,
                self._stage_route, prompt, model_hint, complexity,
            )
            result.stages.append(stage)
            model = stage.data.get("model", model_hint or "gpt-4o-mini")
            provider = stage.data.get("provider", "")
            result.model_used = model
            result.provider = provider

            # Stage 3: Cache check
            if self._config.enable_cache and self._cache:
                stage = await self._run_stage(
                    PipelineStage.CACHE_CHECK,
                    self._stage_cache_check, prompt, model,
                )
                result.stages.append(stage)
                if stage.data.get("hit"):
                    result.content = stage.data["content"]
                    result.from_cache = True
                    result.total_duration_ms = (time.perf_counter() - pipeline_start) * 1000
                    return result
            else:
                result.stages.append(StageResult(stage=PipelineStage.CACHE_CHECK, skipped=True))

            # Stage 4: Compress
            if self._config.enable_compression and self._compressor:
                stage = await self._run_stage(
                    PipelineStage.COMPRESS,
                    self._stage_compress, prompt, messages,
                )
                result.stages.append(stage)
                prompt = stage.data.get("prompt", prompt)
            else:
                result.stages.append(StageResult(stage=PipelineStage.COMPRESS, skipped=True))

            # Stage 5: Rate limit
            if self._config.enable_rate_limiting and self._rate_limiter:
                stage = await self._run_stage(
                    PipelineStage.RATE_LIMIT,
                    self._stage_rate_limit, provider,
                )
                result.stages.append(stage)
                if not stage.success:
                    result.content = ""
                    result.metadata["rate_limited"] = True
                    result.total_duration_ms = (time.perf_counter() - pipeline_start) * 1000
                    return result
            else:
                result.stages.append(StageResult(stage=PipelineStage.RATE_LIMIT, skipped=True))

            # Run middleware before_execute
            for mw in self._middleware:
                prompt, model, ctx = await mw.before_execute(prompt, model, ctx)

            # Stage 6: Execute
            stage = await self._run_stage(
                PipelineStage.EXECUTE,
                self._stage_execute, prompt, model, messages,
            )
            result.stages.append(stage)

            if not stage.success:
                result.content = ""
                result.metadata["error"] = stage.error
                result.total_duration_ms = (time.perf_counter() - pipeline_start) * 1000
                return result

            result.content = stage.data.get("content", "")
            result.tokens_in = stage.data.get("tokens_in", 0)
            result.tokens_out = stage.data.get("tokens_out", 0)

            # Stage 7: Validate
            if self._config.enable_validation and self._validator:
                stage = await self._run_stage(
                    PipelineStage.VALIDATE,
                    self._stage_validate, result.content,
                )
                result.stages.append(stage)
                result.quality_score = stage.data.get("score", 0.0)
            else:
                result.stages.append(StageResult(stage=PipelineStage.VALIDATE, skipped=True))

            # Stage 8: Cache store
            if self._config.enable_cache and self._cache and result.content:
                stage = await self._run_stage(
                    PipelineStage.CACHE_STORE,
                    self._stage_cache_store, prompt, model, result.content,
                )
                result.stages.append(stage)
            else:
                result.stages.append(StageResult(stage=PipelineStage.CACHE_STORE, skipped=True))

            # Stage 9: Track cost
            stage = await self._run_stage(
                PipelineStage.TRACK_COST,
                self._stage_track_cost, model, result.tokens_in, result.tokens_out,
            )
            result.stages.append(stage)
            result.cost_usd = stage.data.get("cost_usd", 0.0)

            # Stage 10: Learn
            if self._config.enable_learning and self._learner:
                stage = await self._run_stage(
                    PipelineStage.LEARN,
                    self._stage_learn, model, result.quality_score, result.cost_usd,
                )
                result.stages.append(stage)
            else:
                result.stages.append(StageResult(stage=PipelineStage.LEARN, skipped=True))

            # Run middleware after_execute
            for mw in self._middleware:
                result = await mw.after_execute(result, ctx)

        except Exception as exc:
            logger.warning("pipeline_error", error=str(exc))
            result.metadata["pipeline_error"] = str(exc)

        result.total_duration_ms = (time.perf_counter() - pipeline_start) * 1000
        return result

    # ------------------------------------------------------------------
    # Stage implementations
    # ------------------------------------------------------------------

    async def _run_stage(
        self,
        stage: PipelineStage,
        fn: Any,
        *args: Any,
    ) -> StageResult:
        """Run a pipeline stage with timing and error handling."""
        start = time.perf_counter()
        try:
            data = await fn(*args)
            elapsed = (time.perf_counter() - start) * 1000
            return StageResult(stage=stage, success=True, duration_ms=elapsed, data=data or {})
        except Exception as exc:
            elapsed = (time.perf_counter() - start) * 1000
            logger.debug("stage_failed", stage=stage.value, error=str(exc))
            return StageResult(stage=stage, success=False, duration_ms=elapsed, error=str(exc))

    async def _stage_classify(
        self, prompt: str, task_type: str,
    ) -> dict[str, Any]:
        """Classify task complexity."""
        if task_type:
            return {"complexity": task_type}
        if self._classifier:
            result = self._classifier.classify(prompt)
            return {"complexity": getattr(result, "tier", "medium")}
        # Simple heuristic
        words = len(prompt.split())
        if words < 10:
            return {"complexity": "simple"}
        if words > 100:
            return {"complexity": "complex"}
        return {"complexity": "medium"}

    async def _stage_route(
        self, prompt: str, model_hint: str, complexity: str,
    ) -> dict[str, Any]:
        """Select the best model."""
        if model_hint:
            return {"model": model_hint, "provider": ""}
        if self._router:
            model = self._router.select(prompt, complexity)
            return {"model": model, "provider": ""}
        # Default routing by complexity
        default_map = {
            "simple": "gpt-4o-mini",
            "medium": "gpt-4o",
            "complex": "claude-sonnet-4-20250514",
        }
        return {"model": default_map.get(complexity, "gpt-4o-mini"), "provider": ""}

    async def _stage_cache_check(
        self, prompt: str, model: str,
    ) -> dict[str, Any]:
        """Check semantic cache for a match."""
        if self._cache is None:
            return {"hit": False}
        cached = self._cache.get(prompt, model=model)
        if cached:
            return {"hit": True, "content": cached.content}
        return {"hit": False}

    async def _stage_compress(
        self, prompt: str, messages: list[dict[str, str]] | None,
    ) -> dict[str, Any]:
        """Compress prompt if needed."""
        if self._compressor and messages:
            compressed = self._compressor.compress(messages)
            return {"prompt": prompt, "messages": compressed}
        return {"prompt": prompt}

    async def _stage_rate_limit(self, provider: str) -> dict[str, Any]:
        """Check rate limits."""
        if self._rate_limiter:
            ok = self._rate_limiter.acquire(provider)
            return {"allowed": ok}
        return {"allowed": True}

    async def _stage_execute(
        self,
        prompt: str,
        model: str,
        messages: list[dict[str, str]] | None,
    ) -> dict[str, Any]:
        """Execute the LLM call."""
        if self._executor is None:
            return {"content": "", "tokens_in": 0, "tokens_out": 0}

        result = await self._executor(prompt, model, messages)
        if isinstance(result, dict):
            return result
        # Assume result has .content attribute
        return {
            "content": getattr(result, "content", str(result)),
            "tokens_in": getattr(result, "tokens_in", 0),
            "tokens_out": getattr(result, "tokens_out", 0),
        }

    async def _stage_validate(self, content: str) -> dict[str, Any]:
        """Validate response quality."""
        if self._validator:
            result = self._validator.validate(content)
            return {"score": result.score, "issues": len(result.issues)}
        return {"score": 1.0, "issues": 0}

    async def _stage_cache_store(
        self, prompt: str, model: str, content: str,
    ) -> dict[str, Any]:
        """Store response in cache."""
        if self._cache:
            self._cache.put(prompt, model=model, content=content)
        return {"stored": True}

    async def _stage_track_cost(
        self, model: str, tokens_in: int, tokens_out: int,
    ) -> dict[str, Any]:
        """Track request cost."""
        if self._cost_tracker:
            cost = self._cost_tracker.track(model, tokens_in, tokens_out)
            return {"cost_usd": cost}
        # Rough estimate
        cost = (tokens_in * 0.000003 + tokens_out * 0.000015)
        return {"cost_usd": round(cost, 6)}

    async def _stage_learn(
        self, model: str, quality: float, cost: float,
    ) -> dict[str, Any]:
        """Update learning models."""
        if self._learner:
            self._learner.record(model=model, quality=quality, cost=cost)
        return {"recorded": True}
