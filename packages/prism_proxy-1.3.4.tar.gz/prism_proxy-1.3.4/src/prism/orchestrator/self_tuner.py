"""Self-tuning cascade thresholds using Bayesian-inspired online learning.

Standard confidence cascading uses fixed thresholds (e.g. 0.85 for cheap,
0.75 for medium, 0.6 for premium).  But the optimal thresholds depend on:

    1. **Task distribution** — some domains produce consistently high
       confidence, others are inherently ambiguous.
    2. **Model capability drift** — models get updated, performance shifts.
    3. **User quality expectations** — some users tolerate lower quality
       for cost savings, others need premium results.

This module maintains a running estimate of the *ideal threshold* for each
cascade tier, adjusting based on observed outcomes:

    - If a tier's outputs are frequently **escalated** (threshold too high),
      lower the threshold to save money.
    - If a tier's outputs are frequently **accepted but receive negative
      feedback**, raise the threshold to improve quality.
    - Use exponential weighted moving average (EWMA) for smooth adaptation.

The result: the cascade automatically finds the sweet spot between cost
and quality for each user's workload, without any manual tuning.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import structlog

logger = structlog.get_logger(__name__)

# Bounds to prevent thresholds from becoming degenerate
_MIN_THRESHOLD = 0.3
_MAX_THRESHOLD = 0.95


@dataclass
class TierStats:
    """Running statistics for a single cascade tier.

    Attributes:
        tier: Tier name (e.g. "cheap", "medium", "premium").
        current_threshold: Current confidence threshold for this tier.
        total_attempts: Total attempts at this tier.
        accepted_count: Number of attempts accepted at this tier.
        escalated_count: Number of attempts escalated from this tier.
        negative_feedback_count: Accepted outputs that got negative feedback.
        positive_feedback_count: Accepted outputs that got positive feedback.
        avg_confidence: Running average of confidence scores seen.
        last_updated: Timestamp of last update.
    """

    tier: str
    current_threshold: float
    total_attempts: int = 0
    accepted_count: int = 0
    escalated_count: int = 0
    negative_feedback_count: int = 0
    positive_feedback_count: int = 0
    avg_confidence: float = 0.0
    last_updated: float = field(default_factory=time.time)


@dataclass
class TuningEvent:
    """A single threshold adjustment event for observability.

    Attributes:
        tier: Which tier was adjusted.
        old_threshold: Previous threshold value.
        new_threshold: New threshold value.
        reason: Why the adjustment was made.
        timestamp: When the adjustment occurred.
    """

    tier: str
    old_threshold: float
    new_threshold: float
    reason: str
    timestamp: float = field(default_factory=time.time)


class CascadeSelfTuner:
    """Self-tuning cascade threshold manager.

    Observes cascade outcomes (accept / escalate / feedback) and
    adjusts tier thresholds using EWMA to optimise the cost/quality
    trade-off automatically.

    Args:
        initial_thresholds: Starting thresholds per tier.  If ``None``,
            defaults to ``{"cheap": 0.85, "medium": 0.75, "premium": 0.6}``.
        alpha: EWMA smoothing factor (0 < alpha < 1).  Higher values
            make the tuner more reactive.  Default 0.1.
        escalation_penalty: How much to lower threshold when a tier
            escalates too often.  Default 0.02.
        feedback_reward: How much to adjust threshold on feedback.
            Default 0.03.
        min_samples: Minimum observations before tuning kicks in.
            Default 10.
    """

    def __init__(
        self,
        initial_thresholds: dict[str, float] | None = None,
        alpha: float = 0.1,
        escalation_penalty: float = 0.02,
        feedback_reward: float = 0.03,
        min_samples: int = 10,
    ) -> None:
        defaults = {"cheap": 0.85, "medium": 0.75, "premium": 0.6}
        thresholds = initial_thresholds or defaults

        self._alpha = max(0.01, min(0.5, alpha))
        self._escalation_penalty = escalation_penalty
        self._feedback_reward = feedback_reward
        self._min_samples = min_samples
        self._history: list[TuningEvent] = []

        self._tiers: dict[str, TierStats] = {}
        for tier, threshold in thresholds.items():
            self._tiers[tier] = TierStats(
                tier=tier,
                current_threshold=max(_MIN_THRESHOLD, min(_MAX_THRESHOLD, threshold)),
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_threshold(self, tier: str) -> float:
        """Get the current threshold for a tier.

        Args:
            tier: Tier name.

        Returns:
            Current confidence threshold, or 0.7 for unknown tiers.
        """
        stats = self._tiers.get(tier)
        if stats is None:
            return 0.7
        return stats.current_threshold

    def get_all_thresholds(self) -> dict[str, float]:
        """Get all current thresholds.

        Returns:
            Dict mapping tier names to their current thresholds.
        """
        return {t: s.current_threshold for t, s in self._tiers.items()}

    def record_acceptance(self, tier: str, confidence: float) -> None:
        """Record that a tier's output was accepted.

        A high acceptance rate at a tier suggests the threshold may be
        too low (accepting too eagerly) or just right.

        Args:
            tier: Which tier produced the accepted output.
            confidence: The confidence score of the accepted output.
        """
        stats = self._ensure_tier(tier)
        stats.total_attempts += 1
        stats.accepted_count += 1
        stats.avg_confidence = (
            stats.avg_confidence * (1 - self._alpha)
            + confidence * self._alpha
        )
        stats.last_updated = time.time()
        self._maybe_tune(tier)

    def record_escalation(self, tier: str, confidence: float) -> None:
        """Record that a tier's output was escalated to a higher tier.

        Frequent escalation suggests the threshold is too high — the tier
        can handle more tasks than we're letting it.

        Args:
            tier: Which tier was escalated from.
            confidence: The confidence score that triggered escalation.
        """
        stats = self._ensure_tier(tier)
        stats.total_attempts += 1
        stats.escalated_count += 1
        stats.avg_confidence = (
            stats.avg_confidence * (1 - self._alpha)
            + confidence * self._alpha
        )
        stats.last_updated = time.time()
        self._maybe_tune(tier)

    def record_feedback(self, tier: str, positive: bool) -> None:
        """Record user feedback on a tier's accepted output.

        Negative feedback suggests the threshold should be raised
        (more stringent).  Positive feedback confirms current level.

        Args:
            tier: Which tier produced the output.
            positive: Whether the feedback was positive.
        """
        stats = self._ensure_tier(tier)
        if positive:
            stats.positive_feedback_count += 1
        else:
            stats.negative_feedback_count += 1
        stats.last_updated = time.time()
        self._maybe_tune(tier)

    def get_stats(self, tier: str) -> TierStats | None:
        """Get statistics for a tier.

        Args:
            tier: Tier name.

        Returns:
            TierStats or None if tier doesn't exist.
        """
        return self._tiers.get(tier)

    def get_all_stats(self) -> dict[str, TierStats]:
        """Get statistics for all tiers.

        Returns:
            Dict mapping tier names to their stats.
        """
        return dict(self._tiers)

    def get_tuning_history(self) -> list[TuningEvent]:
        """Get the history of threshold adjustments.

        Returns:
            List of TuningEvent objects, oldest first.
        """
        return list(self._history)

    def reset(self, tier: str | None = None) -> None:
        """Reset tuning state.

        Args:
            tier: Tier to reset.  If None, reset all tiers.
        """
        if tier is not None:
            stats = self._tiers.get(tier)
            if stats:
                default_thresholds = {"cheap": 0.85, "medium": 0.75, "premium": 0.6}
                stats.current_threshold = default_thresholds.get(tier, 0.7)
                stats.total_attempts = 0
                stats.accepted_count = 0
                stats.escalated_count = 0
                stats.negative_feedback_count = 0
                stats.positive_feedback_count = 0
                stats.avg_confidence = 0.0
        else:
            for t in self._tiers:
                self.reset(t)
            self._history.clear()

    # ------------------------------------------------------------------
    # Internal tuning logic
    # ------------------------------------------------------------------

    def _ensure_tier(self, tier: str) -> TierStats:
        """Get or create stats for a tier."""
        if tier not in self._tiers:
            self._tiers[tier] = TierStats(tier=tier, current_threshold=0.7)
        return self._tiers[tier]

    def _maybe_tune(self, tier: str) -> None:
        """Adjust threshold if enough data has been collected."""
        stats = self._tiers[tier]
        if stats.total_attempts < self._min_samples:
            return

        old_threshold = stats.current_threshold

        # Calculate escalation rate
        escalation_rate = stats.escalated_count / max(1, stats.total_attempts)

        # Calculate negative feedback rate among accepted outputs
        total_feedback = stats.positive_feedback_count + stats.negative_feedback_count
        negative_rate = (
            stats.negative_feedback_count / max(1, total_feedback)
            if total_feedback > 0
            else 0.0
        )

        adjustment = 0.0

        # High escalation rate → lower threshold (save cost)
        if escalation_rate > 0.5:
            adjustment -= self._escalation_penalty * (escalation_rate - 0.3)
            reason = f"high escalation rate ({escalation_rate:.2f})"
        # Low escalation rate + no negative feedback → slightly lower (optimise cost)
        elif escalation_rate < 0.2 and negative_rate < 0.1:
            adjustment -= self._escalation_penalty * 0.5
            reason = "low escalation + good feedback → cost optimisation"
        # High negative feedback → raise threshold (improve quality)
        elif negative_rate > 0.3:
            adjustment += self._feedback_reward * (negative_rate - 0.1)
            reason = f"high negative feedback ({negative_rate:.2f})"
        else:
            return  # No adjustment needed

        # Apply EWMA smoothing
        new_threshold = old_threshold + adjustment * self._alpha

        # Clamp to bounds
        new_threshold = max(_MIN_THRESHOLD, min(_MAX_THRESHOLD, new_threshold))

        # Only record if change is meaningful (> 0.001)
        if abs(new_threshold - old_threshold) < 0.001:
            return

        stats.current_threshold = new_threshold

        event = TuningEvent(
            tier=tier,
            old_threshold=old_threshold,
            new_threshold=new_threshold,
            reason=reason,
        )
        self._history.append(event)

        logger.info(
            "cascade_threshold_tuned",
            tier=tier,
            old=round(old_threshold, 4),
            new=round(new_threshold, 4),
            reason=reason,
            escalation_rate=round(escalation_rate, 3),
            negative_rate=round(negative_rate, 3),
            total_attempts=stats.total_attempts,
        )
