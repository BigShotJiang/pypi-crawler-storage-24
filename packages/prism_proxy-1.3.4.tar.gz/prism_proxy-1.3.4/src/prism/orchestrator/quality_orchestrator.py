"""Quality Orchestrator — exceeds single-model quality using multi-model ensemble strategies.

This module implements research-backed techniques to produce output that is measurably
better than any single model:

1. **Generate-Critique-Refine**: Model A generates, Model B critiques, Model A refines
2. **Best-of-N with Verification**: Generate N responses, score each, pick the best
3. **Ensemble Synthesis**: Multiple models answer, synthesizer merges the best parts
4. **Iterative Self-Improvement**: Generate -> evaluate -> improve until quality threshold
5. **Specialized Routing**: Route sub-tasks to the best model for each
   (code->DeepSeek, reasoning->o3, writing->Claude)
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol

# ---------------------------------------------------------------------------
# Types & Configuration
# ---------------------------------------------------------------------------


class QualityStrategy(Enum):
    """Available quality enhancement strategies."""

    SINGLE = "single"                    # Baseline: just use one model
    BEST_OF_N = "best_of_n"             # Generate N, pick best
    GENERATE_CRITIQUE_REFINE = "gcr"    # Generate -> Critique -> Refine
    ENSEMBLE_SYNTHESIS = "ensemble"      # Multiple models -> synthesize
    ITERATIVE_REFINEMENT = "iterative"   # Loop until quality threshold
    SPECIALIZED_ROUTING = "specialized"  # Route sub-tasks to best model
    FULL_PIPELINE = "full_pipeline"      # All strategies combined


class TaskDomain(Enum):
    """Task domains for specialized routing."""

    CODE = "code"
    REASONING = "reasoning"
    MATH = "math"
    CREATIVE_WRITING = "creative_writing"
    ANALYSIS = "analysis"
    GENERAL = "general"


@dataclass
class ModelConfig:
    """Configuration for a model in the ensemble."""

    model_id: str
    provider: str
    strengths: list[TaskDomain] = field(default_factory=list)
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    max_tokens: int = 4096
    supports_thinking: bool = False


@dataclass
class QualityConfig:
    """Configuration for quality orchestration."""

    strategy: QualityStrategy = QualityStrategy.GENERATE_CRITIQUE_REFINE
    models: list[ModelConfig] = field(default_factory=list)
    quality_threshold: float = 0.85  # 0-1, target quality score
    max_iterations: int = 3          # Max refinement loops
    best_of_n: int = 3              # Number of candidates for best-of-N
    timeout_seconds: float = 120.0   # Max total time
    budget_limit: float | None = None  # Max cost in dollars
    enable_thinking: bool = True     # Use extended thinking where available
    parallel_generation: bool = True  # Generate candidates in parallel


@dataclass
class QualityResult:
    """Result from quality orchestration."""

    content: str
    quality_score: float  # 0-1 composite score
    strategy_used: QualityStrategy
    models_used: list[str]
    iterations: int
    total_tokens: int
    total_cost: float
    elapsed_ms: float
    thinking_content: str | None = None
    critique: str | None = None
    alternatives_considered: int = 0
    scores_breakdown: dict[str, float] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


class CompletionFn(Protocol):
    """Protocol for model completion function."""

    async def __call__(
        self,
        model: str,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]: ...


# ---------------------------------------------------------------------------
# Quality Scoring
# ---------------------------------------------------------------------------


class ResponseScorer:
    """Scores response quality across multiple dimensions."""

    def score(
        self,
        prompt: str,
        response: str,
        domain: TaskDomain = TaskDomain.GENERAL,
    ) -> dict[str, float]:
        """Score a response on multiple quality dimensions.

        Returns dict with scores 0-1 for:
        - completeness: Does it fully address the prompt?
        - coherence: Is it logically structured?
        - accuracy_signals: Does it show high-confidence indicators?
        - conciseness: Is it appropriately concise?
        - specificity: Does it provide specific, actionable content?
        - code_quality: (for code) Proper structure, error handling, types?
        """
        scores: dict[str, float] = {}

        # Completeness: check if key terms from prompt appear in response
        prompt_words = set(prompt.lower().split())
        response_lower = response.lower()
        key_terms = {w for w in prompt_words if len(w) > 4}
        if key_terms:
            covered = sum(1 for t in key_terms if t in response_lower)
            scores["completeness"] = min(
                1.0, covered / max(len(key_terms), 1),
            )
        else:
            scores["completeness"] = 0.5 if len(response) > 50 else 0.3

        # Coherence: paragraph structure, transition words, logical flow
        paragraphs = [p for p in response.split("\n\n") if p.strip()]
        has_structure = len(paragraphs) > 1 or len(response) < 200
        transition_words = {
            "however", "therefore", "because", "additionally",
            "furthermore", "first", "second", "finally",
            "in conclusion", "for example", "specifically",
            "moreover", "consequently", "thus",
        }
        transition_count = sum(
            1 for w in transition_words if w in response_lower
        )
        structure_score = 0.6 if has_structure else 0.3
        transition_score = min(1.0, transition_count / 3)
        scores["coherence"] = (
            0.5 * structure_score + 0.5 * transition_score
        )

        # Accuracy signals: confidence indicators, hedging balance
        confident_phrases = {
            "the answer is", "this works because", "the solution",
            "here's how", "the result is", "this will",
        }
        hedge_phrases = {
            "i think", "probably", "might be", "not sure",
            "i believe", "it seems", "possibly", "arguably",
        }
        confident = sum(
            1 for p in confident_phrases if p in response_lower
        )
        hedging = sum(1 for p in hedge_phrases if p in response_lower)
        if confident + hedging > 0:
            scores["accuracy_signals"] = confident / (confident + hedging)
        else:
            scores["accuracy_signals"] = 0.5

        # Conciseness: penalize excessive verbosity
        words = response.split()
        word_count = len(words)
        prompt_complexity = len(prompt.split())
        # Expected length: roughly 3-30x the prompt length
        expected_min = max(20, prompt_complexity * 3)
        expected_max = max(200, prompt_complexity * 30)
        if expected_min <= word_count <= expected_max:
            scores["conciseness"] = 1.0
        elif word_count < expected_min:
            scores["conciseness"] = max(0.2, word_count / expected_min)
        else:
            scores["conciseness"] = max(0.3, expected_max / word_count)

        # Specificity: concrete details, numbers, code, examples
        has_code = (
            "```" in response
            or "def " in response
            or "function " in response
        )
        has_numbers = any(c.isdigit() for c in response)
        has_examples = (
            "example" in response_lower
            or "e.g." in response_lower
            or "for instance" in response_lower
        )
        specificity_indicators = sum([has_code, has_numbers, has_examples])
        scores["specificity"] = min(
            1.0, 0.4 + specificity_indicators * 0.2,
        )

        # Code quality (only for code domain)
        if domain == TaskDomain.CODE or has_code:
            scores["code_quality"] = self._score_code_quality(response)

        # Composite score
        weights = self._get_weights(domain)
        total_weight = sum(weights.get(k, 0) for k in scores)
        if total_weight > 0:
            scores["composite"] = (
                sum(scores[k] * weights.get(k, 0) for k in scores)
                / total_weight
            )
        else:
            scores["composite"] = sum(scores.values()) / len(scores)

        return scores

    def _score_code_quality(self, response: str) -> float:
        """Score code quality indicators in the response."""
        indicators = 0
        total = 6

        # Error handling
        if any(
            kw in response
            for kw in ("try:", "except", "catch", "Error", "raise")
        ):
            indicators += 1

        # Type hints / types
        if any(
            kw in response
            for kw in (
                "-> ", ": str", ": int", ": list", ": dict",
                "Optional", "Union", "Type",
            )
        ):
            indicators += 1

        # Docstrings / comments
        if (
            '"""' in response
            or "'''" in response
            or "# " in response
            or "//" in response
        ):
            indicators += 1

        # Input validation
        if any(
            kw in response
            for kw in (
                "if not ", "ValueError", "TypeError",
                "assert ", "validate",
            )
        ):
            indicators += 1

        # Proper structure (functions/classes)
        if any(
            kw in response
            for kw in ("def ", "class ", "function ", "const ", "async def")
        ):
            indicators += 1

        # Return statements (not just side effects)
        if "return " in response:
            indicators += 1

        return indicators / total

    def _get_weights(self, domain: TaskDomain) -> dict[str, float]:
        """Get scoring weights based on task domain."""
        base: dict[str, float] = {
            "completeness": 0.25,
            "coherence": 0.20,
            "accuracy_signals": 0.20,
            "conciseness": 0.15,
            "specificity": 0.20,
        }
        if domain == TaskDomain.CODE:
            base["code_quality"] = 0.30
            base["completeness"] = 0.25
            base["specificity"] = 0.15
            base["conciseness"] = 0.10
        elif domain == TaskDomain.MATH:
            base["accuracy_signals"] = 0.35
            base["specificity"] = 0.25
            base["conciseness"] = 0.10
        elif domain == TaskDomain.CREATIVE_WRITING:
            base["coherence"] = 0.30
            base["specificity"] = 0.25
            base["accuracy_signals"] = 0.10
        return base


# ---------------------------------------------------------------------------
# Domain Classifier
# ---------------------------------------------------------------------------


class DomainClassifier:
    """Classifies user prompts into task domains for specialized routing."""

    _CODE_SIGNALS = frozenset({
        "write", "code", "function", "class", "implement", "bug", "fix",
        "refactor", "test", "debug", "compile", "error", "syntax",
        "api", "endpoint", "database", "query", "script", "program",
        "python", "javascript", "typescript", "java", "rust", "go",
    })

    _MATH_SIGNALS = frozenset({
        "calculate", "equation", "formula", "proof", "theorem",
        "integral", "derivative", "probability", "statistics",
        "algebra", "geometry", "solve", "compute", "mathematical",
        "optimization", "matrix",
    })

    _REASONING_SIGNALS = frozenset({
        "why", "explain", "reason", "logic", "argue", "because",
        "therefore", "analyze", "evaluate", "compare", "contrast",
        "implications", "consequences", "trade-off", "decision",
    })

    _CREATIVE_SIGNALS = frozenset({
        "story", "poem", "creative", "imagine", "design",
        "brainstorm", "narrative", "character", "plot", "essay",
    })

    def classify(self, prompt: str) -> TaskDomain:
        """Classify a prompt into a task domain."""
        words = set(prompt.lower().split())

        code_score = len(words & self._CODE_SIGNALS)
        math_score = len(words & self._MATH_SIGNALS)
        reasoning_score = len(words & self._REASONING_SIGNALS)
        creative_score = len(words & self._CREATIVE_SIGNALS)

        # Code blocks are a strong signal
        if "```" in prompt or "def " in prompt or "function " in prompt:
            code_score += 3

        scores = {
            TaskDomain.CODE: code_score,
            TaskDomain.MATH: math_score,
            TaskDomain.REASONING: reasoning_score,
            TaskDomain.CREATIVE_WRITING: creative_score,
        }

        best = max(scores, key=lambda k: scores[k])
        if scores[best] >= 2:
            return best
        return TaskDomain.GENERAL


# ---------------------------------------------------------------------------
# Model Selector for Specialized Routing
# ---------------------------------------------------------------------------

_DOMAIN_MODEL_RANKING: dict[TaskDomain, list[str]] = {
    TaskDomain.CODE: [
        "deepseek/deepseek-coder",
        "anthropic/claude-opus-4",
        "openai/gpt-4o",
        "anthropic/claude-sonnet-4",
        "google/gemini-2.0-flash",
    ],
    TaskDomain.REASONING: [
        "openai/o3",
        "openai/o1",
        "anthropic/claude-opus-4",
        "deepseek/deepseek-reasoner",
        "anthropic/claude-sonnet-4",
    ],
    TaskDomain.MATH: [
        "openai/o3",
        "openai/o1",
        "deepseek/deepseek-reasoner",
        "anthropic/claude-opus-4",
        "google/gemini-2.0-flash",
    ],
    TaskDomain.CREATIVE_WRITING: [
        "anthropic/claude-opus-4",
        "anthropic/claude-sonnet-4",
        "openai/gpt-4o",
        "google/gemini-2.0-flash",
    ],
    TaskDomain.ANALYSIS: [
        "anthropic/claude-opus-4",
        "openai/o3",
        "openai/gpt-4o",
        "google/gemini-2.0-flash",
    ],
    TaskDomain.GENERAL: [
        "anthropic/claude-opus-4",
        "openai/gpt-4o",
        "anthropic/claude-sonnet-4",
        "google/gemini-2.0-flash",
    ],
}


class SpecializedRouter:
    """Routes sub-tasks to the best available model for each domain."""

    def __init__(self, available_models: list[str]) -> None:
        self._available = set(available_models)

    def select(self, domain: TaskDomain) -> str | None:
        """Select the best available model for a domain."""
        ranking = _DOMAIN_MODEL_RANKING.get(
            domain, _DOMAIN_MODEL_RANKING[TaskDomain.GENERAL],
        )
        for model in ranking:
            if model in self._available:
                return model
        # Return any available model
        return next(iter(self._available), None)

    def select_diverse(
        self, domain: TaskDomain, n: int = 3,
    ) -> list[str]:
        """Select N diverse models, prioritized for the domain."""
        ranking = _DOMAIN_MODEL_RANKING.get(
            domain, _DOMAIN_MODEL_RANKING[TaskDomain.GENERAL],
        )
        selected: list[str] = []
        seen_providers: set[str] = set()

        for model in ranking:
            if model in self._available:
                provider = (
                    model.split("/")[0] if "/" in model else model
                )
                if provider not in seen_providers or len(selected) < n:
                    selected.append(model)
                    seen_providers.add(provider)
                    if len(selected) >= n:
                        break

        # Fill remaining slots
        for model in sorted(self._available):
            if model not in selected and len(selected) < n:
                selected.append(model)

        return selected[:n]


# ---------------------------------------------------------------------------
# Core Orchestrator
# ---------------------------------------------------------------------------


class QualityOrchestrator:
    """Orchestrates multi-model strategies to exceed single-model quality.

    Usage::

        orchestrator = QualityOrchestrator(
            completion_fn=my_completion_fn,
            config=QualityConfig(
                strategy=QualityStrategy.GENERATE_CRITIQUE_REFINE,
                models=[
                    ModelConfig(
                        model_id="anthropic/claude-opus-4",
                        provider="anthropic",
                    ),
                    ModelConfig(
                        model_id="openai/gpt-4o",
                        provider="openai",
                    ),
                ],
            ),
        )
        result = await orchestrator.execute(
            "Write a binary search in Python",
        )
    """

    def __init__(
        self,
        completion_fn: CompletionFn,
        config: QualityConfig | None = None,
    ) -> None:
        self._complete = completion_fn
        self._config = config or QualityConfig()
        self._scorer = ResponseScorer()
        self._classifier = DomainClassifier()
        self._total_tokens = 0
        self._total_cost = 0.0

    @property
    def scorer(self) -> ResponseScorer:
        """Expose the scorer for external use."""
        return self._scorer

    @property
    def classifier(self) -> DomainClassifier:
        """Expose the classifier for external use."""
        return self._classifier

    async def execute(
        self,
        prompt: str,
        messages: list[dict[str, Any]] | None = None,
        strategy: QualityStrategy | None = None,
        **kwargs: Any,
    ) -> QualityResult:
        """Execute quality-enhanced completion.

        Args:
            prompt: The user's prompt.
            messages: Optional conversation history.
            strategy: Override the default strategy.
            **kwargs: Additional parameters passed to completion.

        Returns:
            QualityResult with the best possible response.
        """
        strategy = strategy or self._config.strategy
        start = time.monotonic()
        self._total_tokens = 0
        self._total_cost = 0.0

        # Build messages
        if messages is None:
            messages = [{"role": "user", "content": prompt}]

        domain = self._classifier.classify(prompt)

        # Select strategy executor
        executors: dict[QualityStrategy, Any] = {
            QualityStrategy.SINGLE: self._execute_single,
            QualityStrategy.BEST_OF_N: self._execute_best_of_n,
            QualityStrategy.GENERATE_CRITIQUE_REFINE: self._execute_gcr,
            QualityStrategy.ENSEMBLE_SYNTHESIS: self._execute_ensemble,
            QualityStrategy.ITERATIVE_REFINEMENT: (
                self._execute_iterative
            ),
            QualityStrategy.SPECIALIZED_ROUTING: (
                self._execute_specialized
            ),
            QualityStrategy.FULL_PIPELINE: self._execute_full_pipeline,
        }

        executor = executors.get(strategy, self._execute_single)
        result = await executor(prompt, messages, domain, **kwargs)

        elapsed = (time.monotonic() - start) * 1000
        result.elapsed_ms = elapsed
        result.total_tokens = self._total_tokens
        result.total_cost = self._total_cost

        return result

    async def _call_model(
        self,
        model: str,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> tuple[str, dict[str, Any]]:
        """Call a model and track usage."""
        response = await self._complete(
            model=model, messages=messages, **kwargs,
        )

        # Track tokens
        usage = response.get("usage", {})
        input_tokens = usage.get(
            "input_tokens", usage.get("prompt_tokens", 0),
        )
        output_tokens = usage.get(
            "output_tokens", usage.get("completion_tokens", 0),
        )
        self._total_tokens += input_tokens + output_tokens

        # Track cost (find model config)
        for mc in self._config.models:
            if mc.model_id == model:
                self._total_cost += (
                    (input_tokens / 1000) * mc.cost_per_1k_input
                )
                self._total_cost += (
                    (output_tokens / 1000) * mc.cost_per_1k_output
                )
                break

        content = ""
        choices = response.get("choices", [])
        if choices:
            msg = choices[0].get("message", {})
            content = msg.get("content", "") or ""
        elif "content" in response:
            content = response["content"]

        return content, response

    # --- Strategy: Single Model ---

    async def _execute_single(
        self,
        prompt: str,
        messages: list[dict[str, Any]],
        domain: TaskDomain,
        **kwargs: Any,
    ) -> QualityResult:
        """Execute with a single model — the baseline strategy."""
        model = (
            self._config.models[0].model_id
            if self._config.models
            else "anthropic/claude-sonnet-4"
        )
        content, _ = await self._call_model(model, messages, **kwargs)
        scores = self._scorer.score(prompt, content, domain)

        return QualityResult(
            content=content,
            quality_score=scores.get("composite", 0.0),
            strategy_used=QualityStrategy.SINGLE,
            models_used=[model],
            iterations=1,
            total_tokens=0,
            total_cost=0.0,
            elapsed_ms=0.0,
            scores_breakdown=scores,
        )

    # --- Strategy: Best-of-N ---

    async def _execute_best_of_n(
        self,
        prompt: str,
        messages: list[dict[str, Any]],
        domain: TaskDomain,
        **kwargs: Any,
    ) -> QualityResult:
        """Generate N responses (possibly different models), pick best."""
        n = self._config.best_of_n
        available_models = [m.model_id for m in self._config.models]
        if not available_models:
            available_models = ["anthropic/claude-sonnet-4"]

        # Generate N candidates in parallel
        tasks = []
        models_used = []
        for i in range(n):
            model = available_models[i % len(available_models)]
            models_used.append(model)
            # Vary temperature slightly for diversity
            call_kwargs = dict(kwargs)
            call_kwargs["temperature"] = 0.3 + (i * 0.2)
            tasks.append(
                self._call_model(model, messages, **call_kwargs),
            )

        if self._config.parallel_generation:
            results = await asyncio.gather(
                *tasks, return_exceptions=True,
            )
        else:
            results = []
            for t in tasks:
                results.append(await t)

        # Score each candidate
        best_content = ""
        best_score = -1.0
        best_scores: dict[str, float] = {}
        valid_count = 0

        for r in results:
            if isinstance(r, BaseException):
                continue
            content, _ = r
            if not content:
                continue
            valid_count += 1
            scores = self._scorer.score(prompt, content, domain)
            composite = scores.get("composite", 0.0)
            if composite > best_score:
                best_score = composite
                best_content = content
                best_scores = scores

        return QualityResult(
            content=best_content,
            quality_score=best_score,
            strategy_used=QualityStrategy.BEST_OF_N,
            models_used=list(set(models_used)),
            iterations=1,
            total_tokens=0,
            total_cost=0.0,
            elapsed_ms=0.0,
            alternatives_considered=valid_count,
            scores_breakdown=best_scores,
        )

    # --- Strategy: Generate-Critique-Refine (GCR) ---

    async def _execute_gcr(
        self,
        prompt: str,
        messages: list[dict[str, Any]],
        domain: TaskDomain,
        **kwargs: Any,
    ) -> QualityResult:
        """Generate with Model A, critique with Model B, refine with A.

        This is the most reliable strategy for exceeding single-model
        quality.  Research shows that models can identify issues in
        other models' outputs that they wouldn't catch in their own.
        """
        models = [m.model_id for m in self._config.models]
        generator = models[0] if models else "anthropic/claude-opus-4"
        critic = models[1] if len(models) > 1 else models[0] if models else "anthropic/claude-opus-4"

        # Step 1: Generate initial response
        gen_content, _ = await self._call_model(
            generator, messages, **kwargs,
        )

        # Step 2: Critique
        critique_messages = [
            {
                "role": "system",
                "content": (
                    "You are an expert reviewer. Analyze the "
                    "following response to a user's question. "
                    "Identify specific issues with:\n"
                    "1. Correctness — any factual errors or bugs?\n"
                    "2. Completeness — anything missing or not "
                    "addressed?\n"
                    "3. Clarity — any confusing or poorly explained "
                    "parts?\n"
                    "4. Best practices — any anti-patterns or "
                    "suboptimal approaches?\n\n"
                    "Be specific and constructive. Only flag real "
                    "issues, not nitpicks."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Original question:\n{prompt}\n\n"
                    f"Response to review:\n{gen_content}"
                ),
            },
        ]
        critique_content, _ = await self._call_model(
            critic, critique_messages, **kwargs,
        )

        # Step 3: Refine based on critique
        refine_messages = [*messages, {
            "role": "assistant",
            "content": gen_content,
        }, {
            "role": "user",
            "content": (
                "An expert reviewer found these issues with your "
                f"response:\n\n{critique_content}\n\n"
                "Please provide an improved response that addresses "
                "all the valid criticisms. Keep what was good, fix "
                "what was wrong, and add anything that was missing."
            ),
        }]
        refined_content, _ = await self._call_model(
            generator, refine_messages, **kwargs,
        )

        # Score the refined version
        scores = self._scorer.score(prompt, refined_content, domain)

        return QualityResult(
            content=refined_content,
            quality_score=scores.get("composite", 0.0),
            strategy_used=QualityStrategy.GENERATE_CRITIQUE_REFINE,
            models_used=list({generator, critic}),
            iterations=3,
            total_tokens=0,
            total_cost=0.0,
            elapsed_ms=0.0,
            critique=critique_content,
            scores_breakdown=scores,
        )

    # --- Strategy: Ensemble Synthesis ---

    async def _execute_ensemble(
        self,
        prompt: str,
        messages: list[dict[str, Any]],
        domain: TaskDomain,
        **kwargs: Any,
    ) -> QualityResult:
        """Get responses from multiple models, synthesize the best.

        A synthesizer model reads ALL responses and produces a merged
        answer that takes the best parts from each.
        """
        models = [m.model_id for m in self._config.models]
        if not models:
            return await self._execute_single(
                prompt, messages, domain, **kwargs,
            )

        # Step 1: Get responses from all models in parallel
        tasks = [
            self._call_model(m, messages, **kwargs) for m in models
        ]
        if self._config.parallel_generation:
            results = await asyncio.gather(
                *tasks, return_exceptions=True,
            )
        else:
            results = [await t for t in tasks]

        # Collect valid responses
        responses: list[tuple[str, str]] = []  # (model, content)
        for model, r in zip(models, results, strict=False):
            if isinstance(r, BaseException):
                continue
            content, _ = r
            if content:
                responses.append((model, content))

        if not responses:
            return QualityResult(
                content="All models failed to respond.",
                quality_score=0.0,
                strategy_used=QualityStrategy.ENSEMBLE_SYNTHESIS,
                models_used=models,
                iterations=1,
                total_tokens=0,
                total_cost=0.0,
                elapsed_ms=0.0,
            )

        if len(responses) == 1:
            content = responses[0][1]
            scores = self._scorer.score(prompt, content, domain)
            return QualityResult(
                content=content,
                quality_score=scores.get("composite", 0.0),
                strategy_used=QualityStrategy.ENSEMBLE_SYNTHESIS,
                models_used=[responses[0][0]],
                iterations=1,
                total_tokens=0,
                total_cost=0.0,
                elapsed_ms=0.0,
                scores_breakdown=scores,
            )

        # Step 2: Synthesize
        response_sections = []
        for model, content in responses:
            response_sections.append(
                f"### Response from {model}:\n{content}",
            )

        synthesis_messages = [
            {
                "role": "system",
                "content": (
                    "You are an expert synthesizer. You have received "
                    "multiple AI responses to the same question. "
                    "Your job is to produce the BEST possible answer "
                    "by:\n"
                    "1. Taking the most accurate and complete parts "
                    "from each response\n"
                    "2. Resolving any contradictions by picking the "
                    "most well-reasoned position\n"
                    "3. Adding any missing details that no single "
                    "response covered\n"
                    "4. Ensuring the final answer is coherent and "
                    "well-structured\n\n"
                    "Do NOT simply concatenate responses. Produce a "
                    "single, unified, superior answer."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Original question:\n{prompt}\n\n"
                    + "\n\n".join(response_sections)
                    + "\n\nNow synthesize the best possible answer "
                    "from the above responses."
                ),
            },
        ]

        # Use the first (presumably strongest) model as synthesizer
        synthesizer = models[0]
        synthesized, _ = await self._call_model(
            synthesizer, synthesis_messages, **kwargs,
        )

        scores = self._scorer.score(prompt, synthesized, domain)

        return QualityResult(
            content=synthesized,
            quality_score=scores.get("composite", 0.0),
            strategy_used=QualityStrategy.ENSEMBLE_SYNTHESIS,
            models_used=list({m for m, _ in responses}),
            iterations=len(responses) + 1,
            total_tokens=0,
            total_cost=0.0,
            elapsed_ms=0.0,
            alternatives_considered=len(responses),
            scores_breakdown=scores,
        )

    # --- Strategy: Iterative Refinement ---

    async def _execute_iterative(
        self,
        prompt: str,
        messages: list[dict[str, Any]],
        domain: TaskDomain,
        **kwargs: Any,
    ) -> QualityResult:
        """Generate, score, iteratively improve until threshold met."""
        model = (
            self._config.models[0].model_id
            if self._config.models
            else "anthropic/claude-opus-4"
        )

        content, _ = await self._call_model(model, messages, **kwargs)
        scores = self._scorer.score(prompt, content, domain)
        iteration = 1

        while (
            scores.get("composite", 0.0) < self._config.quality_threshold
            and iteration < self._config.max_iterations
        ):
            # Identify weakest dimension
            dimension_scores = {
                k: v for k, v in scores.items() if k != "composite"
            }
            weakest = (
                min(dimension_scores, key=lambda k: dimension_scores[k])
                if dimension_scores
                else "completeness"
            )

            improvement_prompts = {
                "completeness": (
                    "Your response was incomplete. Make sure to "
                    "address ALL parts of the question."
                ),
                "coherence": (
                    "Your response lacked clear structure. "
                    "Reorganize with better flow and transitions."
                ),
                "accuracy_signals": (
                    "Your response seemed uncertain. Be more "
                    "definitive where you're confident."
                ),
                "conciseness": (
                    "Your response was too verbose. Be more concise "
                    "while keeping all key information."
                ),
                "specificity": (
                    "Your response was too vague. Add specific "
                    "examples, numbers, or code."
                ),
                "code_quality": (
                    "Your code needs better error handling, type "
                    "hints, and documentation."
                ),
            }

            improve_messages = [*messages, {
                "role": "assistant",
                "content": content,
            }, {
                "role": "user",
                "content": (
                    "Please improve your response. "
                    f"{improvement_prompts.get(weakest, 'Make it better.')} "
                    "Provide the complete improved response."
                ),
            }]

            content, _ = await self._call_model(
                model, improve_messages, **kwargs,
            )
            scores = self._scorer.score(prompt, content, domain)
            iteration += 1

        return QualityResult(
            content=content,
            quality_score=scores.get("composite", 0.0),
            strategy_used=QualityStrategy.ITERATIVE_REFINEMENT,
            models_used=[model],
            iterations=iteration,
            total_tokens=0,
            total_cost=0.0,
            elapsed_ms=0.0,
            scores_breakdown=scores,
        )

    # --- Strategy: Specialized Routing ---

    async def _execute_specialized(
        self,
        prompt: str,
        messages: list[dict[str, Any]],
        domain: TaskDomain,
        **kwargs: Any,
    ) -> QualityResult:
        """Route to the best model for the detected domain."""
        available = [m.model_id for m in self._config.models]
        router = SpecializedRouter(available)

        model = router.select(domain)
        if not model:
            model = (
                available[0]
                if available
                else "anthropic/claude-sonnet-4"
            )

        # If thinking model is available and domain is
        # math/reasoning, enable it
        call_kwargs = dict(kwargs)
        model_config = next(
            (m for m in self._config.models if m.model_id == model),
            None,
        )
        if (
            model_config
            and model_config.supports_thinking
            and domain in (TaskDomain.MATH, TaskDomain.REASONING)
        ):
            call_kwargs["enable_thinking"] = True

        content, _ = await self._call_model(
            model, messages, **call_kwargs,
        )
        scores = self._scorer.score(prompt, content, domain)

        return QualityResult(
            content=content,
            quality_score=scores.get("composite", 0.0),
            strategy_used=QualityStrategy.SPECIALIZED_ROUTING,
            models_used=[model],
            iterations=1,
            total_tokens=0,
            total_cost=0.0,
            elapsed_ms=0.0,
            scores_breakdown=scores,
            metadata={
                "domain": domain.value,
                "selected_model": model,
            },
        )

    # --- Strategy: Full Pipeline ---

    async def _execute_full_pipeline(
        self,
        prompt: str,
        messages: list[dict[str, Any]],
        domain: TaskDomain,
        **kwargs: Any,
    ) -> QualityResult:
        """The ultimate quality strategy: combines everything.

        1. Best-of-N selects the best candidate from diverse models
        2. GCR refines the best candidate with cross-model critique
        3. If still below threshold, iterative improvement kicks in
        """
        # Step 1: Best-of-N with diverse models
        bon_result = await self._execute_best_of_n(
            prompt, messages, domain, **kwargs,
        )

        if bon_result.quality_score >= self._config.quality_threshold:
            bon_result.strategy_used = QualityStrategy.FULL_PIPELINE
            return bon_result

        # Step 2: GCR on the best candidate
        gcr_messages = list(messages)  # Start fresh
        gcr_result = await self._execute_gcr(
            prompt, gcr_messages, domain, **kwargs,
        )

        # Pick the better result
        best = gcr_result if gcr_result.quality_score > bon_result.quality_score else bon_result

        # Step 3: If still below threshold, iterate
        if best.quality_score < self._config.quality_threshold:
            iter_messages = [
                {"role": "user", "content": prompt},
                {"role": "assistant", "content": best.content},
                {
                    "role": "user",
                    "content": (
                        "Please improve this response further."
                    ),
                },
            ]

            model = (
                self._config.models[0].model_id
                if self._config.models
                else "anthropic/claude-sonnet-4"
            )
            improved, _ = await self._call_model(
                model, iter_messages, **kwargs,
            )
            improved_scores = self._scorer.score(
                prompt, improved, domain,
            )

            if (
                improved_scores.get("composite", 0.0)
                > best.quality_score
            ):
                best = QualityResult(
                    content=improved,
                    quality_score=improved_scores.get(
                        "composite", 0.0,
                    ),
                    strategy_used=QualityStrategy.FULL_PIPELINE,
                    models_used=list(set(
                        bon_result.models_used
                        + gcr_result.models_used
                    )),
                    iterations=(
                        bon_result.iterations
                        + gcr_result.iterations
                        + 1
                    ),
                    total_tokens=0,
                    total_cost=0.0,
                    elapsed_ms=0.0,
                    scores_breakdown=improved_scores,
                )

        best.strategy_used = QualityStrategy.FULL_PIPELINE
        best.models_used = list(set(
            bon_result.models_used + gcr_result.models_used
        ))
        return best


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------


def detect_best_strategy(
    prompt: str,
    available_models: int,
    time_budget_ms: float = 30000,
) -> QualityStrategy:
    """Auto-detect the best quality strategy based on context.

    Args:
        prompt: The user's prompt.
        available_models: Number of models available.
        time_budget_ms: How much time we can spend.

    Returns:
        Recommended QualityStrategy.
    """
    prompt_len = len(prompt.split())

    # Simple/short prompts — single model is fine
    if prompt_len < 20 and available_models == 1:
        return QualityStrategy.SINGLE

    # Multiple models available — use ensemble or GCR
    if available_models >= 3 and time_budget_ms >= 30000:
        return QualityStrategy.FULL_PIPELINE

    if available_models >= 2 and time_budget_ms >= 20000:
        return QualityStrategy.GENERATE_CRITIQUE_REFINE

    if available_models >= 2:
        return QualityStrategy.BEST_OF_N

    # Single model, complex prompt — iterative
    if prompt_len > 100:
        return QualityStrategy.ITERATIVE_REFINEMENT

    return QualityStrategy.SINGLE
