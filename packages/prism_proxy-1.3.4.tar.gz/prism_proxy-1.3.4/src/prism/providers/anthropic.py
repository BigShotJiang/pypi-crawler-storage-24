"""Anthropic provider — Claude-specific optimizations and parameter handling.

Provides Anthropic-specific request preparation, response parsing,
prompt caching, extended thinking support, and model capability metadata.
All API interactions are routed through LiteLLM — this module handles
the provider-specific parameter transformations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class AnthropicModel(Enum):
    """Supported Anthropic models with their API identifiers."""

    CLAUDE_OPUS_4 = "claude-opus-4-20250514"
    CLAUDE_SONNET_4 = "claude-sonnet-4-20250514"
    CLAUDE_HAIKU_35 = "claude-3-5-haiku-20241022"
    CLAUDE_SONNET_35 = "claude-3-5-sonnet-20241022"
    CLAUDE_OPUS_3 = "claude-3-opus-20240229"


@dataclass
class AnthropicConfig:
    """Anthropic-specific configuration for request handling.

    Attributes:
        api_version: Anthropic API version header.
        max_tokens_default: Default max_tokens when not specified.
        enable_prompt_caching: Whether to apply cache_control breakpoints.
        enable_extended_thinking: Whether to enable extended thinking mode.
        thinking_budget_tokens: Token budget for extended thinking.
        beta_features: List of beta feature strings for the anthropic-beta header.
    """

    api_version: str = "2023-06-01"
    max_tokens_default: int = 8192
    enable_prompt_caching: bool = True
    enable_extended_thinking: bool = False
    thinking_budget_tokens: int = 10000
    beta_features: list[str] = field(
        default_factory=lambda: ["prompt-caching-2024-07-31"],
    )


class AnthropicProvider:
    """Anthropic-specific request/response handling.

    Handles Claude-specific optimizations including prompt caching,
    extended thinking parameters, tool format conversion, and
    response parsing with thinking block extraction.
    """

    def __init__(self, config: AnthropicConfig | None = None) -> None:
        """Initialize the Anthropic provider.

        Args:
            config: Anthropic-specific configuration. Uses defaults if None.
        """
        self._config = config or AnthropicConfig()
        self._model_capabilities = self._build_capability_map()

    @property
    def config(self) -> AnthropicConfig:
        """Return the current configuration."""
        return self._config

    def prepare_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Prepare an Anthropic-optimized request.

        Handles:
        - Prompt caching via cache_control headers on system/large messages
        - Extended thinking parameters
        - Proper max_tokens defaults
        - Beta headers for prompt caching

        Args:
            messages: Chat messages in standard format.
            model: Anthropic model identifier.
            **kwargs: Additional parameters (temperature, top_p, stop,
                      tools, enable_thinking, thinking_budget_tokens).

        Returns:
            Dictionary of request parameters ready for the Anthropic API.
        """
        params: dict[str, Any] = {
            "model": model,
            "messages": list(messages),
            "max_tokens": kwargs.get("max_tokens", self._config.max_tokens_default),
        }

        # Add optional standard parameters
        if "temperature" in kwargs:
            params["temperature"] = kwargs["temperature"]
        if "top_p" in kwargs:
            params["top_p"] = kwargs["top_p"]
        if "stop" in kwargs:
            params["stop_sequences"] = kwargs["stop"]

        # Prompt caching optimization
        if self._config.enable_prompt_caching:
            params["messages"] = self._apply_cache_control(params["messages"])
            params["extra_headers"] = {
                "anthropic-beta": ",".join(self._config.beta_features),
            }

        # Extended thinking
        if self._config.enable_extended_thinking or kwargs.get("enable_thinking"):
            thinking_budget = kwargs.get(
                "thinking_budget_tokens",
                self._config.thinking_budget_tokens,
            )
            params["thinking"] = {
                "type": "enabled",
                "budget_tokens": thinking_budget,
            }
            # Thinking requires temperature=1 and no top_p
            params["temperature"] = 1.0
            params.pop("top_p", None)

        # Tool use
        if kwargs.get("tools"):
            params["tools"] = self._convert_tools(kwargs["tools"])

        return params

    def _apply_cache_control(
        self,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Apply cache_control breakpoints to messages for prompt caching.

        Anthropic's prompt caching works by marking cache breakpoints.
        Strategy:
        - Always cache the system message (if present and >100 chars)
        - Cache the first large user message (>1000 chars)
        - Leave other messages untouched

        Args:
            messages: Chat messages to annotate.

        Returns:
            Messages with cache_control headers applied where appropriate.
        """
        result: list[dict[str, Any]] = []
        system_cached = False
        large_message_cached = False

        for msg in messages:
            msg_copy = dict(msg)
            content = msg_copy.get("content", "")

            # Cache system messages
            if msg_copy.get("role") == "system" and not system_cached:
                if isinstance(content, str) and len(content) > 100:
                    msg_copy["content"] = [
                        {
                            "type": "text",
                            "text": content,
                            "cache_control": {"type": "ephemeral"},
                        }
                    ]
                    system_cached = True

            # Cache first large user message
            elif msg_copy.get("role") == "user" and not large_message_cached and isinstance(content, str) and len(content) > 1000:
                    msg_copy["content"] = [
                        {
                            "type": "text",
                            "text": content,
                            "cache_control": {"type": "ephemeral"},
                        }
                    ]
                    large_message_cached = True

            result.append(msg_copy)

        return result

    def _convert_tools(self, tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert OpenAI-format tools to Anthropic format.

        OpenAI format uses {"type": "function", "function": {...}} while
        Anthropic uses {"name": ..., "description": ..., "input_schema": ...}.

        Args:
            tools: Tools in OpenAI format or already in Anthropic format.

        Returns:
            Tools in Anthropic format.
        """
        anthropic_tools: list[dict[str, Any]] = []
        for tool in tools:
            if tool.get("type") == "function":
                fn = tool["function"]
                anthropic_tools.append(
                    {
                        "name": fn["name"],
                        "description": fn.get("description", ""),
                        "input_schema": fn.get(
                            "parameters",
                            {"type": "object", "properties": {}},
                        ),
                    }
                )
            else:
                # Already in Anthropic format or passthrough
                anthropic_tools.append(tool)
        return anthropic_tools

    def parse_response(self, response: dict[str, Any]) -> dict[str, Any]:
        """Parse Anthropic response, extracting thinking blocks and tool use.

        Handles the content block format used by the Anthropic API, which
        returns a list of typed blocks (text, thinking, tool_use) rather
        than a single content string.

        Args:
            response: Raw Anthropic API response.

        Returns:
            Normalized response dict with:
            - content: str (main text output)
            - thinking: str | None (thinking/reasoning content)
            - tool_calls: list[dict] | None (tool use requests)
            - usage: dict with input/output/cache token counts
            - stop_reason: str | None
        """
        result: dict[str, Any] = {
            "content": "",
            "thinking": None,
            "tool_calls": None,
            "usage": {},
            "stop_reason": None,
        }

        # Extract content blocks
        content_blocks = response.get("content", [])
        text_parts: list[str] = []
        thinking_parts: list[str] = []
        tool_uses: list[dict[str, Any]] = []

        for block in content_blocks:
            if isinstance(block, dict):
                block_type = block.get("type", "")
                if block_type == "text":
                    text_parts.append(block.get("text", ""))
                elif block_type == "thinking":
                    thinking_parts.append(block.get("thinking", ""))
                elif block_type == "tool_use":
                    tool_uses.append(
                        {
                            "id": block.get("id", ""),
                            "type": "function",
                            "function": {
                                "name": block.get("name", ""),
                                "arguments": block.get("input", {}),
                            },
                        }
                    )
            elif isinstance(block, str):
                text_parts.append(block)

        result["content"] = "\n".join(text_parts)
        if thinking_parts:
            result["thinking"] = "\n".join(thinking_parts)
        if tool_uses:
            result["tool_calls"] = tool_uses

        # Usage statistics
        usage = response.get("usage", {})
        result["usage"] = {
            "input_tokens": usage.get("input_tokens", 0),
            "output_tokens": usage.get("output_tokens", 0),
            "cache_creation_input_tokens": usage.get(
                "cache_creation_input_tokens", 0,
            ),
            "cache_read_input_tokens": usage.get("cache_read_input_tokens", 0),
        }

        result["stop_reason"] = response.get("stop_reason")

        return result

    def get_model_capabilities(self, model: str) -> dict[str, Any]:
        """Get capability flags for a specific Anthropic model.

        Args:
            model: Model identifier or partial name.

        Returns:
            Dictionary of capability flags and limits.
        """
        model_lower = model.lower()
        for key, caps in self._model_capabilities.items():
            if key in model_lower:
                return dict(caps)
        return self._default_capabilities()

    def _build_capability_map(self) -> dict[str, dict[str, Any]]:
        """Build the model capability lookup table."""
        return {
            "opus-4": {
                "vision": True,
                "tool_use": True,
                "extended_thinking": True,
                "prompt_caching": True,
                "streaming": True,
                "pdf_input": True,
                "citations": True,
                "max_output": 16384,
            },
            "sonnet-4": {
                "vision": True,
                "tool_use": True,
                "extended_thinking": True,
                "prompt_caching": True,
                "streaming": True,
                "pdf_input": True,
                "citations": True,
                "max_output": 16384,
            },
            "haiku": {
                "vision": True,
                "tool_use": True,
                "extended_thinking": False,
                "prompt_caching": True,
                "streaming": True,
                "pdf_input": True,
                "citations": False,
                "max_output": 8192,
            },
            "opus-3": {
                "vision": True,
                "tool_use": True,
                "extended_thinking": False,
                "prompt_caching": True,
                "streaming": True,
                "pdf_input": False,
                "citations": False,
                "max_output": 4096,
            },
        }

    @staticmethod
    def _default_capabilities() -> dict[str, Any]:
        """Return default capabilities for unknown Anthropic models."""
        return {
            "vision": False,
            "tool_use": True,
            "extended_thinking": False,
            "prompt_caching": False,
            "streaming": True,
            "pdf_input": False,
            "citations": False,
            "max_output": 4096,
        }

    def estimate_cache_savings(
        self,
        messages: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Estimate potential savings from prompt caching.

        Anthropic prompt caching pricing:
        - Cache write: 25% more expensive than base input price
        - Cache read: 90% cheaper than base input price
        - Breakeven: approximately 5 requests with the same cached prefix

        Args:
            messages: Chat messages to analyze for cacheability.

        Returns:
            Dictionary with caching analysis:
            - cacheable_tokens: estimated number of cacheable tokens
            - cache_write_cost_multiplier: cost factor for cache write
            - cache_read_cost_multiplier: cost factor for cache read
            - breakeven_requests: number of requests to break even
            - potential_savings_pct: savings percentage after breakeven
        """
        total_chars = sum(
            len(m.get("content", ""))
            for m in messages
            if isinstance(m.get("content"), str)
        )
        # Rough estimate: ~4 characters per token
        estimated_cacheable_tokens = total_chars // 4

        return {
            "cacheable_tokens": estimated_cacheable_tokens,
            "cache_write_cost_multiplier": 1.25,
            "cache_read_cost_multiplier": 0.10,
            "breakeven_requests": 5,
            "potential_savings_pct": (
                0.90 if estimated_cacheable_tokens > 1024 else 0.0
            ),
        }
