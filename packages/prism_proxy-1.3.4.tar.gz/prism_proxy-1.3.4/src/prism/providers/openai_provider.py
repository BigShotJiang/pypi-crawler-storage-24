"""OpenAI provider — GPT/o-series specific optimizations and parameter handling.

Provides OpenAI-specific request preparation, response parsing,
reasoning effort configuration for o-series models, JSON mode,
logprobs, and model capability metadata.  All API interactions are
routed through LiteLLM — this module handles the provider-specific
parameter transformations.

Named ``openai_provider`` (not ``openai``) to avoid shadowing the
``openai`` package.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class OpenAIModel(Enum):
    """Supported OpenAI models with their API identifiers."""

    GPT_4O = "gpt-4o"
    GPT_4O_MINI = "gpt-4o-mini"
    GPT_4_TURBO = "gpt-4-turbo"
    GPT_4 = "gpt-4"
    GPT_35_TURBO = "gpt-3.5-turbo"
    O1 = "o1"
    O1_MINI = "o1-mini"
    O3 = "o3"
    O3_MINI = "o3-mini"
    O4_MINI = "o4-mini"


class ReasoningEffort(Enum):
    """Reasoning effort levels for o-series models.

    Controls how much computation the model uses for reasoning:
    - LOW: faster, cheaper, less thorough reasoning
    - MEDIUM: balanced reasoning (default)
    - HIGH: thorough, more expensive reasoning
    """

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class OpenAIConfig:
    """OpenAI-specific configuration for request handling.

    Attributes:
        default_max_tokens: Default max_tokens when not specified.
        enable_structured_output: Whether to allow JSON mode / structured output.
        enable_logprobs: Whether to request log probabilities.
        top_logprobs: Number of top logprobs to return per token.
        reasoning_effort: Default reasoning effort for o-series models.
        seed: Optional seed for reproducible outputs.
        response_format: Optional response format (e.g. {"type": "json_object"}).
        parallel_tool_calls: Whether to allow parallel tool calls.
    """

    default_max_tokens: int = 4096
    enable_structured_output: bool = True
    enable_logprobs: bool = False
    top_logprobs: int = 5
    reasoning_effort: ReasoningEffort = ReasoningEffort.MEDIUM
    seed: int | None = None
    response_format: dict[str, str] | None = None
    parallel_tool_calls: bool = True


class OpenAIProvider:
    """OpenAI-specific request/response handling.

    Handles GPT and o-series model differences including:
    - o-series reasoning_effort and max_completion_tokens
    - Temperature/top_p restrictions for reasoning models
    - JSON mode and structured outputs
    - Logprobs for confidence analysis
    - Parallel tool calls
    """

    def __init__(self, config: OpenAIConfig | None = None) -> None:
        """Initialize the OpenAI provider.

        Args:
            config: OpenAI-specific configuration. Uses defaults if None.
        """
        self._config = config or OpenAIConfig()
        self._model_capabilities = self._build_capability_map()

    @property
    def config(self) -> OpenAIConfig:
        """Return the current configuration."""
        return self._config

    def prepare_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Prepare an OpenAI-optimized request.

        Handles:
        - o-series reasoning_effort parameter
        - max_completion_tokens vs max_tokens
        - Temperature/top_p restrictions for reasoning models
        - Structured output / JSON mode
        - Logprobs
        - Seed for reproducibility
        - Parallel tool calls

        Args:
            messages: Chat messages in OpenAI format.
            model: OpenAI model identifier.
            **kwargs: Additional parameters (temperature, top_p, stop, tools,
                      max_tokens, reasoning_effort, response_format,
                      frequency_penalty, presence_penalty).

        Returns:
            Dictionary of request parameters ready for the OpenAI API.
        """
        params: dict[str, Any] = {
            "model": model,
            "messages": list(messages),
        }

        is_reasoning = self._is_reasoning_model(model)

        # Max tokens — o-series uses max_completion_tokens, not max_tokens
        if is_reasoning:
            params["max_completion_tokens"] = kwargs.get("max_tokens", 16384)
        else:
            params["max_tokens"] = kwargs.get(
                "max_tokens",
                self._config.default_max_tokens,
            )

        # Temperature — o-series doesn't support temperature
        if not is_reasoning and "temperature" in kwargs:
            params["temperature"] = kwargs["temperature"]

        # Reasoning effort for o-series
        if is_reasoning:
            effort = kwargs.get("reasoning_effort", self._config.reasoning_effort)
            if isinstance(effort, ReasoningEffort):
                effort = effort.value
            params["reasoning_effort"] = effort

        # Top P — not supported by o-series
        if not is_reasoning and "top_p" in kwargs:
            params["top_p"] = kwargs["top_p"]

        # Stop sequences
        if "stop" in kwargs:
            params["stop"] = kwargs["stop"]

        # Logprobs — not available for reasoning models
        if self._config.enable_logprobs and not is_reasoning:
            params["logprobs"] = True
            params["top_logprobs"] = self._config.top_logprobs

        # Seed for reproducibility
        if self._config.seed is not None:
            params["seed"] = self._config.seed

        # Response format (JSON mode) — not supported by o-series
        response_format = kwargs.get("response_format", self._config.response_format)
        if response_format and not is_reasoning:
            params["response_format"] = response_format

        # Tools
        if kwargs.get("tools"):
            params["tools"] = kwargs["tools"]  # Already in OpenAI format
            if self._config.parallel_tool_calls:
                params["parallel_tool_calls"] = True

        # Frequency/presence penalty — not supported by o-series
        if not is_reasoning:
            if "frequency_penalty" in kwargs:
                params["frequency_penalty"] = kwargs["frequency_penalty"]
            if "presence_penalty" in kwargs:
                params["presence_penalty"] = kwargs["presence_penalty"]

        return params

    def parse_response(self, response: dict[str, Any]) -> dict[str, Any]:
        """Parse OpenAI response, normalizing to common format.

        Handles both GPT and o-series response formats, including
        reasoning_content for o-series models.

        Args:
            response: Raw OpenAI API response.

        Returns:
            Normalized response dict with:
            - content: str (main text output)
            - reasoning: str | None (for o-series reasoning content)
            - tool_calls: list[dict] | None
            - usage: dict with prompt/completion/reasoning/cached tokens
            - logprobs: list | None
            - finish_reason: str | None
        """
        result: dict[str, Any] = {
            "content": "",
            "reasoning": None,
            "tool_calls": None,
            "usage": {},
            "logprobs": None,
            "finish_reason": None,
        }

        choices = response.get("choices", [])
        if not choices:
            return result

        choice = choices[0]
        message = choice.get("message", {})

        result["content"] = message.get("content", "") or ""
        result["finish_reason"] = choice.get("finish_reason")

        # Reasoning content (o-series)
        if "reasoning_content" in message:
            result["reasoning"] = message["reasoning_content"]

        # Tool calls
        tool_calls = message.get("tool_calls")
        if tool_calls:
            result["tool_calls"] = tool_calls

        # Usage
        usage = response.get("usage", {})
        completion_details = usage.get("completion_tokens_details", {})
        prompt_details = usage.get("prompt_tokens_details", {})
        result["usage"] = {
            "prompt_tokens": usage.get("prompt_tokens", 0),
            "completion_tokens": usage.get("completion_tokens", 0),
            "total_tokens": usage.get("total_tokens", 0),
            "reasoning_tokens": completion_details.get("reasoning_tokens", 0),
            "cached_tokens": prompt_details.get("cached_tokens", 0),
        }

        # Logprobs
        if choice.get("logprobs"):
            result["logprobs"] = choice["logprobs"]

        return result

    def get_model_capabilities(self, model: str) -> dict[str, Any]:
        """Get capability flags for a specific OpenAI model.

        Args:
            model: Model identifier or partial name.

        Returns:
            Dictionary of capability flags and limits.
        """
        model_lower = model.lower()
        for key, caps in self._model_capabilities.items():
            if key in model_lower:
                return dict(caps)
        return self._default_capabilities()

    def _is_reasoning_model(self, model: str) -> bool:
        """Check if model is an o-series reasoning model.

        Args:
            model: Model identifier.

        Returns:
            True if the model is an o-series reasoning model.
        """
        model_lower = model.lower()
        return any(model_lower.startswith(p) for p in ("o1", "o3", "o4"))

    def _build_capability_map(self) -> dict[str, dict[str, Any]]:
        """Build the model capability lookup table."""
        return {
            "gpt-4o-mini": {
                "vision": True,
                "tool_use": True,
                "json_mode": True,
                "streaming": True,
                "logprobs": True,
                "reasoning": False,
                "context_window": 128000,
                "max_output": 16384,
            },
            "gpt-4o": {
                "vision": True,
                "tool_use": True,
                "json_mode": True,
                "streaming": True,
                "logprobs": True,
                "reasoning": False,
                "context_window": 128000,
                "max_output": 16384,
            },
            "gpt-4-turbo": {
                "vision": True,
                "tool_use": True,
                "json_mode": True,
                "streaming": True,
                "logprobs": True,
                "reasoning": False,
                "context_window": 128000,
                "max_output": 4096,
            },
            "o1": {
                "vision": True,
                "tool_use": True,
                "json_mode": False,
                "streaming": True,
                "logprobs": False,
                "reasoning": True,
                "context_window": 200000,
                "max_output": 100000,
            },
            "o3": {
                "vision": True,
                "tool_use": True,
                "json_mode": False,
                "streaming": True,
                "logprobs": False,
                "reasoning": True,
                "context_window": 200000,
                "max_output": 100000,
            },
            "o4-mini": {
                "vision": True,
                "tool_use": True,
                "json_mode": False,
                "streaming": True,
                "logprobs": False,
                "reasoning": True,
                "context_window": 200000,
                "max_output": 100000,
            },
        }

    @staticmethod
    def _default_capabilities() -> dict[str, Any]:
        """Return default capabilities for unknown OpenAI models."""
        return {
            "vision": False,
            "tool_use": True,
            "json_mode": False,
            "streaming": True,
            "logprobs": False,
            "reasoning": False,
            "context_window": 8192,
            "max_output": 4096,
        }

    def optimize_for_speed(self, params: dict[str, Any]) -> dict[str, Any]:
        """Optimize request parameters for lowest latency.

        Reduces max_tokens, enables streaming, and disables logprobs
        to minimize response time.

        Args:
            params: Existing request parameters.

        Returns:
            Modified parameters optimized for speed.
        """
        params = dict(params)
        if "max_tokens" in params:
            params["max_tokens"] = min(params["max_tokens"], 1024)
        params["stream"] = True
        params.pop("logprobs", None)
        params.pop("top_logprobs", None)
        return params

    def optimize_for_quality(self, params: dict[str, Any]) -> dict[str, Any]:
        """Optimize request parameters for highest quality output.

        Lowers temperature, enables logprobs for confidence analysis,
        and ensures sufficient output budget.

        Args:
            params: Existing request parameters.

        Returns:
            Modified parameters optimized for quality.
        """
        params = dict(params)
        params["temperature"] = params.get("temperature", 0.2)
        params["logprobs"] = True
        params["top_logprobs"] = 5
        return params
