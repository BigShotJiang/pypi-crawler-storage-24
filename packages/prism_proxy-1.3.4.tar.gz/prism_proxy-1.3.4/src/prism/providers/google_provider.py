"""Google provider — Gemini-specific optimizations and parameter handling.

Provides Google/Gemini-specific request preparation, response parsing,
safety settings, grounding configuration, and model capability metadata.
All API interactions are routed through LiteLLM — this module handles
the provider-specific parameter transformations.

Named ``google_provider`` (not ``google``) to avoid shadowing stdlib or
third-party packages.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class GoogleModel(Enum):
    """Supported Google/Gemini models with their API identifiers."""

    GEMINI_25_PRO = "gemini/gemini-2.5-pro"
    GEMINI_20_FLASH = "gemini/gemini-2.0-flash"
    GEMINI_20_FLASH_LITE = "gemini/gemini-2.0-flash-lite"
    GEMINI_15_PRO = "gemini/gemini-1.5-pro"
    GEMINI_15_FLASH = "gemini/gemini-1.5-flash"


class SafetySetting(Enum):
    """Safety threshold levels for content filtering.

    Controls how aggressively the model filters potentially harmful content.
    """

    BLOCK_NONE = "BLOCK_NONE"
    BLOCK_ONLY_HIGH = "BLOCK_ONLY_HIGH"
    BLOCK_MEDIUM_AND_ABOVE = "BLOCK_MEDIUM_AND_ABOVE"
    BLOCK_LOW_AND_ABOVE = "BLOCK_LOW_AND_ABOVE"


class HarmCategory(Enum):
    """Harm categories for safety settings."""

    HARASSMENT = "HARM_CATEGORY_HARASSMENT"
    HATE_SPEECH = "HARM_CATEGORY_HATE_SPEECH"
    SEXUALLY_EXPLICIT = "HARM_CATEGORY_SEXUALLY_EXPLICIT"
    DANGEROUS_CONTENT = "HARM_CATEGORY_DANGEROUS_CONTENT"


@dataclass
class GoogleConfig:
    """Google/Gemini-specific configuration for request handling.

    Attributes:
        default_max_tokens: Default max output tokens when not specified.
        safety_threshold: Default safety filtering threshold.
        enable_grounding: Whether to enable Google Search grounding.
        enable_code_execution: Whether to enable built-in code execution.
        candidate_count: Number of response candidates to generate.
        safety_settings: Per-category safety overrides (overrides safety_threshold).
    """

    default_max_tokens: int = 8192
    safety_threshold: SafetySetting = SafetySetting.BLOCK_MEDIUM_AND_ABOVE
    enable_grounding: bool = False
    enable_code_execution: bool = False
    candidate_count: int = 1
    safety_settings: dict[HarmCategory, SafetySetting] = field(
        default_factory=dict,
    )


class GoogleProvider:
    """Google/Gemini-specific request/response handling.

    Handles Gemini-specific features including safety settings,
    grounding with Google Search, code execution, and the unique
    response format with candidate-based outputs.
    """

    def __init__(self, config: GoogleConfig | None = None) -> None:
        """Initialize the Google provider.

        Args:
            config: Google-specific configuration. Uses defaults if None.
        """
        self._config = config or GoogleConfig()
        self._model_capabilities = self._build_capability_map()

    @property
    def config(self) -> GoogleConfig:
        """Return the current configuration."""
        return self._config

    def prepare_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Prepare a Gemini-optimized request.

        Handles:
        - Safety settings per harm category
        - Google Search grounding
        - Code execution tool
        - Candidate count
        - Proper max_tokens defaults

        Args:
            messages: Chat messages in standard format.
            model: Gemini model identifier.
            **kwargs: Additional parameters (temperature, top_p, stop,
                      max_tokens, tools, safety_threshold,
                      enable_grounding, enable_code_execution).

        Returns:
            Dictionary of request parameters ready for the Gemini API.
        """
        params: dict[str, Any] = {
            "model": model,
            "messages": list(messages),
            "max_tokens": kwargs.get("max_tokens", self._config.default_max_tokens),
        }

        # Standard optional parameters
        if "temperature" in kwargs:
            params["temperature"] = kwargs["temperature"]
        if "top_p" in kwargs:
            params["top_p"] = kwargs["top_p"]
        if "stop" in kwargs:
            params["stop"] = kwargs["stop"]

        # Safety settings
        safety_settings = self._build_safety_settings(
            kwargs.get("safety_threshold"),
        )
        if safety_settings:
            params["safety_settings"] = safety_settings

        # Grounding with Google Search
        enable_grounding = kwargs.get(
            "enable_grounding",
            self._config.enable_grounding,
        )
        if enable_grounding:
            tools = list(kwargs.get("tools", []) or [])
            tools.append({"google_search_retrieval": {}})
            kwargs["tools"] = tools

        # Code execution
        enable_code_exec = kwargs.get(
            "enable_code_execution",
            self._config.enable_code_execution,
        )
        if enable_code_exec:
            tools = list(kwargs.get("tools", []) or [])
            tools.append({"code_execution": {}})
            kwargs["tools"] = tools

        # Tools
        if kwargs.get("tools"):
            params["tools"] = kwargs["tools"]

        # Candidate count
        if self._config.candidate_count > 1:
            params["candidate_count"] = self._config.candidate_count

        return params

    def _build_safety_settings(
        self,
        override_threshold: SafetySetting | None = None,
    ) -> list[dict[str, str]]:
        """Build safety settings for the request.

        Uses per-category overrides from config if set, otherwise
        falls back to the threshold parameter or the default threshold.

        Args:
            override_threshold: Optional threshold to use for all categories.

        Returns:
            List of safety setting dicts for the API.
        """
        threshold = override_threshold or self._config.safety_threshold
        settings: list[dict[str, str]] = []

        for category in HarmCategory:
            cat_threshold = self._config.safety_settings.get(category, threshold)
            settings.append(
                {
                    "category": category.value,
                    "threshold": cat_threshold.value,
                }
            )

        return settings

    def parse_response(self, response: dict[str, Any]) -> dict[str, Any]:
        """Parse Gemini response, normalizing to common format.

        Handles the candidate-based response format used by the Gemini API,
        including grounding metadata and safety ratings.

        Args:
            response: Raw Gemini API response.

        Returns:
            Normalized response dict with:
            - content: str (main text output)
            - tool_calls: list[dict] | None
            - usage: dict with prompt/completion token counts
            - finish_reason: str | None
            - safety_ratings: list[dict] | None
            - grounding_metadata: dict | None
        """
        result: dict[str, Any] = {
            "content": "",
            "tool_calls": None,
            "usage": {},
            "finish_reason": None,
            "safety_ratings": None,
            "grounding_metadata": None,
        }

        # Handle standard LiteLLM-wrapped response (choices format)
        choices = response.get("choices", [])
        if choices:
            choice = choices[0]
            message = choice.get("message", {})
            result["content"] = message.get("content", "") or ""
            result["finish_reason"] = choice.get("finish_reason")

            tool_calls = message.get("tool_calls")
            if tool_calls:
                result["tool_calls"] = tool_calls

        # Handle native Gemini candidate format
        candidates = response.get("candidates", [])
        if candidates and not choices:
            candidate = candidates[0]
            content_obj = candidate.get("content", {})
            parts = content_obj.get("parts", [])

            text_parts: list[str] = []
            tool_calls_list: list[dict[str, Any]] = []

            for part in parts:
                if isinstance(part, dict):
                    if "text" in part:
                        text_parts.append(part["text"])
                    elif "functionCall" in part:
                        fc = part["functionCall"]
                        tool_calls_list.append(
                            {
                                "type": "function",
                                "function": {
                                    "name": fc.get("name", ""),
                                    "arguments": fc.get("args", {}),
                                },
                            }
                        )
                elif isinstance(part, str):
                    text_parts.append(part)

            result["content"] = "\n".join(text_parts)
            if tool_calls_list:
                result["tool_calls"] = tool_calls_list
            result["finish_reason"] = candidate.get("finishReason")

            # Safety ratings
            safety_ratings = candidate.get("safetyRatings")
            if safety_ratings:
                result["safety_ratings"] = safety_ratings

            # Grounding metadata
            grounding = candidate.get("groundingMetadata")
            if grounding:
                result["grounding_metadata"] = grounding

        # Usage
        usage = response.get("usage", {})
        # Gemini uses usageMetadata in native format
        usage_meta = response.get("usageMetadata", usage)
        result["usage"] = {
            "prompt_tokens": (
                usage_meta.get("prompt_tokens", 0)
                or usage_meta.get("promptTokenCount", 0)
            ),
            "completion_tokens": (
                usage_meta.get("completion_tokens", 0)
                or usage_meta.get("candidatesTokenCount", 0)
            ),
            "total_tokens": (
                usage_meta.get("total_tokens", 0)
                or usage_meta.get("totalTokenCount", 0)
            ),
        }

        return result

    def get_model_capabilities(self, model: str) -> dict[str, Any]:
        """Get capability flags for a specific Gemini model.

        Args:
            model: Model identifier or partial name.

        Returns:
            Dictionary of capability flags and limits.
        """
        model_lower = model.lower()
        for key, caps in self._model_capabilities.items():
            if key in model_lower:
                return dict(caps)
        return self._default_capabilities()

    def _build_capability_map(self) -> dict[str, dict[str, Any]]:
        """Build the model capability lookup table."""
        return {
            "2.5-pro": {
                "vision": True,
                "tool_use": True,
                "grounding": True,
                "code_execution": True,
                "json_mode": True,
                "streaming": True,
                "context_window": 2_097_152,
                "max_output": 8192,
            },
            "2.0-flash": {
                "vision": True,
                "tool_use": True,
                "grounding": True,
                "code_execution": True,
                "json_mode": True,
                "streaming": True,
                "context_window": 1_048_576,
                "max_output": 8192,
            },
            "1.5-pro": {
                "vision": True,
                "tool_use": True,
                "grounding": True,
                "code_execution": True,
                "json_mode": True,
                "streaming": True,
                "context_window": 2_097_152,
                "max_output": 8192,
            },
            "1.5-flash": {
                "vision": True,
                "tool_use": True,
                "grounding": True,
                "code_execution": True,
                "json_mode": True,
                "streaming": True,
                "context_window": 1_048_576,
                "max_output": 8192,
            },
        }

    @staticmethod
    def _default_capabilities() -> dict[str, Any]:
        """Return default capabilities for unknown Gemini models."""
        return {
            "vision": False,
            "tool_use": True,
            "grounding": False,
            "code_execution": False,
            "json_mode": False,
            "streaming": True,
            "context_window": 32768,
            "max_output": 4096,
        }

    def estimate_free_tier_usage(
        self,
        messages: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Estimate token usage for free tier budget planning.

        Google AI Studio offers a generous free tier. This helps
        track usage against the free tier limits.

        Args:
            messages: Chat messages to analyze.

        Returns:
            Dictionary with usage estimates:
            - estimated_input_tokens: approximate input token count
            - estimated_output_tokens: estimated output tokens
            - free_tier_rpm: requests per minute limit
            - free_tier_rpd: requests per day limit
        """
        total_chars = sum(
            len(m.get("content", ""))
            for m in messages
            if isinstance(m.get("content"), str)
        )
        # Rough estimate: ~4 characters per token
        estimated_input_tokens = total_chars // 4

        return {
            "estimated_input_tokens": estimated_input_tokens,
            "estimated_output_tokens": min(
                self._config.default_max_tokens,
                estimated_input_tokens,
            ),
            "free_tier_rpm": 15,
            "free_tier_rpd": 1500,
        }
