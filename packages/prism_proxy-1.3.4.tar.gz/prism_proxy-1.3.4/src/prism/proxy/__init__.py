"""Prism API proxy — Anthropic-compatible server for Claude Code integration."""
