"""Translate between Anthropic Messages API format and OpenAI format.

Claude Code sends requests in Anthropic's Messages API format.  Prism's
CompletionEngine (via LiteLLM) expects OpenAI format.  This module
handles the bidirectional translation.

Anthropic format:
    - Messages use ``content`` as a list of content blocks
    - Tool results are sent as ``tool_result`` content blocks
    - Tool calls are ``tool_use`` content blocks in the response

OpenAI format:
    - Messages use ``content`` as a string
    - Tool results are separate ``tool`` role messages
    - Tool calls are in ``tool_calls`` array on the assistant message
"""

from __future__ import annotations

import json
import uuid
from typing import Any


def anthropic_to_openai_messages(
    messages: list[dict[str, Any]],
    system: str | list[dict[str, Any]] = "",
) -> list[dict[str, Any]]:
    """Convert Anthropic Messages API format to OpenAI format.

    Args:
        messages: Messages in Anthropic format.
        system: System prompt (string or list of content blocks).

    Returns:
        Messages in OpenAI format.
    """
    result: list[dict[str, Any]] = []

    # System message
    if system:
        if isinstance(system, list):
            # Anthropic allows system as list of content blocks
            system_text = " ".join(
                block.get("text", "") for block in system
                if block.get("type") == "text"
            )
        else:
            system_text = system
        if system_text:
            result.append({"role": "system", "content": system_text})

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if role == "user":
            result.extend(_convert_user_message(content))
        elif role == "assistant":
            result.extend(_convert_assistant_message(content))
        else:
            # Pass through unknown roles
            if isinstance(content, str):
                result.append({"role": role, "content": content})
            else:
                text = _extract_text(content)
                result.append({"role": role, "content": text})

    return result


def _convert_user_message(
    content: str | list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert a user message from Anthropic to OpenAI format.

    Handles:
    - Plain string content
    - List of content blocks (text, image, tool_result)
    """
    if isinstance(content, str):
        return [{"role": "user", "content": content}]

    messages: list[dict[str, Any]] = []
    text_parts: list[str] = []
    tool_results: list[dict[str, Any]] = []

    for block in content:
        block_type = block.get("type", "")

        if block_type == "text":
            text_parts.append(block.get("text", ""))

        elif block_type == "tool_result":
            # Anthropic sends tool results as content blocks in user messages
            tc_id = block.get("tool_use_id", "")
            result_content = block.get("content", "")
            if isinstance(result_content, list):
                result_text = " ".join(
                    b.get("text", "") for b in result_content
                    if b.get("type") == "text"
                )
            else:
                result_text = str(result_content)

            tool_results.append({
                "role": "tool",
                "tool_call_id": tc_id,
                "content": result_text,
            })

        elif block_type == "image":
            # Convert Anthropic image blocks to OpenAI vision format
            source = block.get("source", {})
            if source.get("type") == "base64":
                text_parts.append("[Image attached]")

    # Add text content as user message
    if text_parts:
        messages.append({"role": "user", "content": "\n".join(text_parts)})

    # Add tool results as separate messages
    messages.extend(tool_results)

    # If nothing was added (empty content blocks), add empty user message
    if not messages:
        messages.append({"role": "user", "content": ""})

    return messages


def _convert_assistant_message(
    content: str | list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert an assistant message from Anthropic to OpenAI format.

    Handles:
    - Plain string content
    - List of content blocks (text, tool_use)
    """
    if isinstance(content, str):
        return [{"role": "assistant", "content": content}]

    text_parts: list[str] = []
    tool_calls: list[dict[str, Any]] = []

    for block in content:
        block_type = block.get("type", "")

        if block_type == "text":
            text_parts.append(block.get("text", ""))

        elif block_type == "tool_use":
            # Anthropic tool_use → OpenAI tool_calls
            tool_calls.append({
                "id": block.get("id", f"call_{uuid.uuid4().hex[:8]}"),
                "type": "function",
                "function": {
                    "name": block.get("name", ""),
                    "arguments": json.dumps(block.get("input", {})),
                },
            })

    msg: dict[str, Any] = {
        "role": "assistant",
        "content": "\n".join(text_parts) if text_parts else None,
    }

    if tool_calls:
        msg["tool_calls"] = tool_calls

    return [msg]


def _extract_text(content: str | list[dict[str, Any]]) -> str:
    """Extract plain text from content (string or blocks)."""
    if isinstance(content, str):
        return content
    return "\n".join(
        block.get("text", "") for block in content
        if isinstance(block, dict) and block.get("type") == "text"
    )


# ---------------------------------------------------------------------------
# Response translation: OpenAI → Anthropic
# ---------------------------------------------------------------------------


def build_anthropic_response(
    content: str,
    model: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
    tool_calls: list[dict[str, Any]] | None = None,
    finish_reason: str = "stop",
) -> dict[str, Any]:
    """Build an Anthropic Messages API response from completion results.

    Args:
        content: Text content from the model.
        model: Model ID that was used.
        input_tokens: Number of input tokens.
        output_tokens: Number of output tokens.
        tool_calls: Tool calls in Anthropic format (already translated).
        finish_reason: Finish reason from the model.

    Returns:
        Response dict in Anthropic Messages API format.
    """
    content_blocks: list[dict[str, Any]] = []

    # Text content
    if content:
        content_blocks.append({"type": "text", "text": content})

    # Tool use blocks
    if tool_calls:
        content_blocks.extend(tool_calls)

    # Map finish reason
    stop_reason = _map_finish_reason(finish_reason, bool(tool_calls))

    return {
        "id": f"msg_{uuid.uuid4().hex[:24]}",
        "type": "message",
        "role": "assistant",
        "content": content_blocks,
        "model": model,
        "stop_reason": stop_reason,
        "stop_sequence": None,
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        },
    }


def openai_tool_calls_to_anthropic(
    tool_calls: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert OpenAI tool_calls to Anthropic tool_use content blocks.

    OpenAI format::

        {"id": "call_123", "type": "function",
         "function": {"name": "read_file", "arguments": "{\"path\": \"x\"}"}}

    Anthropic format::

        {"type": "tool_use", "id": "call_123",
         "name": "read_file", "input": {"path": "x"}}
    """
    result: list[dict[str, Any]] = []
    for tc in tool_calls:
        fn = tc.get("function", {})
        args_str = fn.get("arguments", "{}")

        try:
            args = json.loads(args_str) if isinstance(args_str, str) else args_str
        except json.JSONDecodeError:
            args = {}

        tc_id = tc.get("id", f"toolu_{uuid.uuid4().hex[:20]}")
        # Anthropic expects tool IDs to start with "toolu_"
        if not tc_id.startswith("toolu_"):
            tc_id = f"toolu_{tc_id}"

        result.append({
            "type": "tool_use",
            "id": tc_id,
            "name": fn.get("name", ""),
            "input": args,
        })

    return result


def build_anthropic_stream_events(
    content: str,
    model: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
    tool_calls: list[dict[str, Any]] | None = None,
) -> list[tuple[str, dict[str, Any]]]:
    """Build the full sequence of SSE events for a streamed response.

    Useful for testing or for converting a non-streaming response
    into stream format.

    Returns:
        List of (event_name, data_dict) tuples.
    """
    msg_id = f"msg_{uuid.uuid4().hex[:24]}"
    events: list[tuple[str, dict[str, Any]]] = []

    # message_start
    events.append(("message_start", {
        "type": "message_start",
        "message": {
            "id": msg_id,
            "type": "message",
            "role": "assistant",
            "content": [],
            "model": model,
            "stop_reason": None,
            "stop_sequence": None,
            "usage": {"input_tokens": input_tokens, "output_tokens": 0},
        },
    }))

    # content_block_start + deltas + stop for text
    if content:
        events.append(("content_block_start", {
            "type": "content_block_start",
            "index": 0,
            "content_block": {"type": "text", "text": ""},
        }))
        events.append(("content_block_delta", {
            "type": "content_block_delta",
            "index": 0,
            "delta": {"type": "text_delta", "text": content},
        }))
        events.append(("content_block_stop", {
            "type": "content_block_stop",
            "index": 0,
        }))

    # Tool use blocks
    if tool_calls:
        anthropic_tcs = openai_tool_calls_to_anthropic(tool_calls)
        for idx, tc in enumerate(anthropic_tcs, start=1 if content else 0):
            events.append(("content_block_start", {
                "type": "content_block_start",
                "index": idx,
                "content_block": tc,
            }))
            events.append(("content_block_stop", {
                "type": "content_block_stop",
                "index": idx,
            }))

    # message_delta
    stop_reason = "tool_use" if tool_calls else "end_turn"
    events.append(("message_delta", {
        "type": "message_delta",
        "delta": {"stop_reason": stop_reason, "stop_sequence": None},
        "usage": {"output_tokens": output_tokens},
    }))

    # message_stop
    events.append(("message_stop", {"type": "message_stop"}))

    return events


def _map_finish_reason(reason: str, has_tool_calls: bool) -> str:
    """Map OpenAI finish reasons to Anthropic stop reasons.

    OpenAI: ``stop``, ``length``, ``tool_calls``, ``content_filter``
    Anthropic: ``end_turn``, ``max_tokens``, ``tool_use``, ``stop_sequence``
    """
    if has_tool_calls:
        return "tool_use"

    mapping = {
        "stop": "end_turn",
        "length": "max_tokens",
        "tool_calls": "tool_use",
        "content_filter": "end_turn",
    }
    return mapping.get(reason, "end_turn")
