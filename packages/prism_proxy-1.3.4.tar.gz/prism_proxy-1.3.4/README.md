# Prism Proxy

> Multi-agent AI orchestrator that makes Claude Code smarter and cheaper. Multiple AI models collaborate, debate, and cross-review to produce output better than any single model.

## What is Prism?

Prism is an Anthropic-compatible proxy that sits between Claude Code and your AI providers. Instead of one model answering alone, Prism orchestrates multiple models (GPT, Gemini, Groq, Mistral, Ollama) to work as a team -- researching, debating, reviewing each other's work, and delivering a consensus answer.

```
Claude Code (UI + tools)
       |
       v
Prism Proxy (localhost:8080)
       |
       | classifies task, orchestrates models
       v
+----------+  +----------+  +----------+  +----------+
| Gemini   |  | GPT-4o   |  | Groq     |  | Mistral  |
| researches|  | writes   |  | reviews  |  | validates|
+----------+  +----------+  +----------+  +----------+
       |           |              |             |
       +------+----+----+---------+-------------+
              |         |
         debate + cross-review
              |
       final consensus answer
              |
              v
       Claude Code executes
       (file edits, terminal, git)
```

## Why?

- **Better quality** -- multiple models catch errors, debate approaches, and cross-review. Output is better than any single model alone.
- **Lower cost** -- simple tasks go to cheap/free models. Only complex tasks use premium models.
- **Resilience** -- if one provider is down, others pick up. No single point of failure.
- **Full Claude Code experience** -- you keep all of Claude Code's tools, UI, and agentic capabilities.

## Quick Start

### 1. Install

```bash
# macOS
brew install python@3.12 node
python3.12 -m pip install --break-system-packages prism-proxy
npm install -g @anthropic-ai/claude-code
```

### 2. Add API keys (at least 2 for multi-agent)

```bash
prism auth add groq      # free: https://console.groq.com/keys
prism auth add google    # free: https://aistudio.google.com/apikey
prism auth add mistral   # free: https://console.mistral.ai/api-keys
```

### 3. Skip Claude Code login (first time only)

```bash
echo '{"hasCompletedOnboarding": true}' > ~/.claude.json
```

### 4. Start Prism (Terminal 1)

```bash
prism serve
```

### 5. Start Claude Code (Terminal 2)

```bash
ANTHROPIC_BASE_URL=http://localhost:8080 ANTHROPIC_AUTH_TOKEN=prism ANTHROPIC_API_KEY="" claude
```

Done. Claude Code now routes through Prism's multi-agent engine.

## Multi-Agent Strategies

Prism uses 5 research-backed strategies, tried in order:

| Strategy | What it does | When it's used |
|---|---|---|
| **Confidence Cascade** | Try cheap model first, escalate if confidence is low | Most requests |
| **Mixture of Agents** | Multiple models generate in parallel, best parts merged | Design, architecture |
| **Debate** | Models argue positions across rounds, synthesize consensus | Ambiguous questions |
| **Swarm** | Decompose into subtasks, assign to models, cross-review | Large multi-step tasks |
| **Parallel Consensus** | Run 2 models, pick the better answer | Fallback |

Simple tasks (quick questions) skip multi-agent and use a single cheap model for speed.

## Provider Setup

Add API keys with `prism auth add <name>`:

| Provider | Free Tier | Best For |
|---|---|---|
| Groq | Yes | Ultra-fast inference (Llama 3) |
| Google | Yes | Long context (Gemini 2.5 Pro, 1M tokens) |
| Mistral | Yes | Code generation (Codestral) |
| DeepSeek | Yes | Code + reasoning (DeepSeek-V3, R1) |
| Ollama | Local/Free | Offline, privacy-sensitive tasks |
| OpenAI | No | GPT-4o, o1 reasoning |
| Anthropic | No | Claude Opus, Sonnet |
| OpenRouter | No | Access to 100+ models |

The more providers you add, the better the multi-agent collaboration.

## Configuration

```yaml
# ~/.prism/config.yaml
multi_agent:
  enabled: true
  strategies: [cascade, moa, debate, swarm, consensus]
  debate_rounds: 2
  quality_threshold: 0.85
  budget_per_request: 0.50
  min_complexity: medium    # simple tasks skip multi-agent

budget:
  daily_limit: 5.0
  monthly_limit: 50.0

routing:
  quality_weight: 0.7
```

```bash
prism config get multi_agent.enabled
prism config set multi_agent.debate_rounds 3
```

## How It Works

1. Claude Code sends a request to Prism (thinks it's talking to Anthropic)
2. Prism classifies the task complexity (simple/medium/complex)
3. **Simple**: single cheap model responds instantly
4. **Medium/Complex**: multi-agent pipeline runs:
   - Multiple models generate responses
   - Models review and critique each other's output
   - Disagreements are debated and resolved
   - Final consensus answer is returned
5. Claude Code receives the answer and executes tools (file edits, terminal, git)
6. User sees the collaboration process in the response

## Cost Savings

| Scenario | Claude Code alone | With Prism |
|---|---|---|
| Simple question | Opus ($15/M) | Gemini Flash ($0.075/M) |
| Code review | Opus ($15/M) | Groq + Mistral ($0) |
| Complex refactor | Opus ($15/M) | Multi-agent team (~$0.50) |
| Typical session | ~$5-10 | ~$0.50-2.00 |

## Status

```bash
prism status       # check provider health
prism auth status  # check API keys
prism --version    # check version
```

## License

Apache 2.0
