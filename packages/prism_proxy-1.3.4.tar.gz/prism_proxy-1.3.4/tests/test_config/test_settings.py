"""Tests for configuration settings."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
import yaml

from prism.config.schema import BudgetConfig, MultiAgentConfig, PrismConfig, RoutingConfig
from prism.config.settings import Settings, _deep_merge, load_config_file, load_settings

if TYPE_CHECKING:
    from pathlib import Path


class TestPrismConfig:
    def test_default_config_is_valid(self) -> None:
        config = PrismConfig()
        assert config.routing.simple_threshold == 0.3
        assert config.routing.medium_threshold == 0.55
        assert config.budget.daily_limit is None
        assert config.tools.web_enabled is False

    def test_routing_threshold_validation(self) -> None:
        with pytest.raises(ValueError, match="simple_threshold"):
            RoutingConfig(simple_threshold=0.8, medium_threshold=0.7)

    def test_routing_equal_thresholds_rejected(self) -> None:
        with pytest.raises(ValueError):
            RoutingConfig(simple_threshold=0.5, medium_threshold=0.5)

    def test_tool_use_minimum_tier_default(self) -> None:
        config = RoutingConfig()
        assert config.tool_use_minimum_tier == "medium"

    def test_escalate_on_tool_use_default(self) -> None:
        config = RoutingConfig()
        assert config.escalate_on_tool_use is True

    def test_tool_use_minimum_tier_valid_values(self) -> None:
        for tier in ("simple", "medium", "complex"):
            config = RoutingConfig(tool_use_minimum_tier=tier)
            assert config.tool_use_minimum_tier == tier

    def test_tool_use_minimum_tier_invalid_rejected(self) -> None:
        with pytest.raises(ValueError, match="tool_use_minimum_tier"):
            RoutingConfig(tool_use_minimum_tier="ultra")

    def test_escalate_on_tool_use_false(self) -> None:
        config = RoutingConfig(escalate_on_tool_use=False)
        assert config.escalate_on_tool_use is False

    def test_budget_limits_accept_none(self) -> None:
        budget = BudgetConfig(daily_limit=None, monthly_limit=None)
        assert budget.daily_limit is None

    def test_budget_negative_rejected(self) -> None:
        with pytest.raises(ValueError):
            BudgetConfig(daily_limit=-1.0)


class TestSettings:
    def test_create_with_defaults(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        assert settings.project_root == tmp_path.resolve()

    def test_prism_home_default(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        assert settings.prism_home == (tmp_path / ".prism").resolve()

    def test_db_path(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        assert settings.db_path == (tmp_path / ".prism" / "prism.db").resolve()

    def test_ensure_directories(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        settings.ensure_directories()
        assert settings.prism_home.is_dir()
        assert settings.sessions_dir.is_dir()
        assert settings.cache_dir.is_dir()

    def test_get_nested_value(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        assert settings.get("routing.simple_threshold") == 0.3
        assert settings.get("budget.daily_limit") is None

    def test_get_missing_key_returns_default(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        assert settings.get("nonexistent.key", "fallback") == "fallback"

    def test_set_override(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        settings.set_override("routing.simple_threshold", 0.2)
        assert settings.config.routing.simple_threshold == 0.2

    def test_prism_home_from_env(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        custom_home = tmp_path / "custom_prism"
        monkeypatch.setenv("PRISM_HOME", str(custom_home))
        config = PrismConfig()
        settings = Settings(config=config, project_root=tmp_path)
        assert settings.prism_home == custom_home.resolve()


class TestLoadConfigFile:
    def test_nonexistent_file_returns_empty(self, tmp_path: Path) -> None:
        result = load_config_file(tmp_path / "nonexistent.yaml")
        assert result == {}

    def test_valid_yaml(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            yaml.dump({"routing": {"simple_threshold": 0.2}, "budget": {"daily_limit": 5.0}})
        )
        result = load_config_file(config_file)
        assert result["routing"]["simple_threshold"] == 0.2
        assert result["budget"]["daily_limit"] == 5.0

    def test_invalid_yaml(self, tmp_path: Path) -> None:
        config_file = tmp_path / "bad.yaml"
        config_file.write_text("{{invalid yaml::")
        result = load_config_file(config_file)
        assert result == {}

    def test_non_dict_yaml(self, tmp_path: Path) -> None:
        config_file = tmp_path / "list.yaml"
        config_file.write_text("- item1\n- item2\n")
        result = load_config_file(config_file)
        assert result == {}


class TestDeepMerge:
    def test_simple_merge(self) -> None:
        base = {"a": 1, "b": 2}
        override = {"b": 3, "c": 4}
        _deep_merge(base, override)
        assert base == {"a": 1, "b": 3, "c": 4}

    def test_nested_merge(self) -> None:
        base = {"routing": {"threshold": 0.3, "mode": "auto"}}
        override = {"routing": {"threshold": 0.5}}
        _deep_merge(base, override)
        assert base == {"routing": {"threshold": 0.5, "mode": "auto"}}

    def test_override_replaces_non_dict(self) -> None:
        base = {"key": "old"}
        override = {"key": {"nested": "value"}}
        _deep_merge(base, override)
        assert base == {"key": {"nested": "value"}}


class TestLoadSettings:
    def test_load_defaults(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("PRISM_HOME", str(tmp_path / ".prism"))
        settings = load_settings(project_root=tmp_path)
        assert settings.config.routing.simple_threshold == 0.3

    def test_load_with_user_config(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        prism_home = tmp_path / ".prism"
        prism_home.mkdir(parents=True)
        config_file = prism_home / "config.yaml"
        config_file.write_text(
            yaml.dump({"routing": {"simple_threshold": 0.15}})
        )
        monkeypatch.setenv("PRISM_HOME", str(prism_home))
        settings = load_settings(project_root=tmp_path)
        assert settings.config.routing.simple_threshold == 0.15

    def test_load_with_overrides(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("PRISM_HOME", str(tmp_path / ".prism"))
        settings = load_settings(
            project_root=tmp_path,
            config_overrides={"routing.simple_threshold": 0.1},
        )
        assert settings.config.routing.simple_threshold == 0.1

    def test_env_budget_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("PRISM_HOME", str(tmp_path / ".prism"))
        monkeypatch.setenv("PRISM_BUDGET_DAILY", "10.0")
        settings = load_settings(project_root=tmp_path)
        assert settings.config.budget.daily_limit == 10.0


class TestMultiAgentConfig:
    """Tests for the multi_agent configuration section."""

    def test_default_values(self) -> None:
        config = MultiAgentConfig()
        assert config.enabled is True
        assert config.strategies == ["cascade", "moa", "debate", "swarm", "consensus"]
        assert config.debate_rounds == 2
        assert config.quality_threshold == 0.85
        assert config.budget_per_request == 0.50
        assert config.min_complexity == "medium"

    def test_prism_config_includes_multi_agent(self) -> None:
        config = PrismConfig()
        assert hasattr(config, "multi_agent")
        assert isinstance(config.multi_agent, MultiAgentConfig)
        assert config.multi_agent.enabled is True

    def test_disable_multi_agent(self) -> None:
        config = MultiAgentConfig(enabled=False)
        assert config.enabled is False

    def test_custom_strategies(self) -> None:
        config = MultiAgentConfig(strategies=["cascade", "debate"])
        assert config.strategies == ["cascade", "debate"]

    def test_invalid_strategy_rejected(self) -> None:
        with pytest.raises(ValueError, match="Invalid multi-agent strategy"):
            MultiAgentConfig(strategies=["cascade", "unknown_strategy"])

    def test_empty_strategies_allowed(self) -> None:
        config = MultiAgentConfig(strategies=[])
        assert config.strategies == []

    def test_debate_rounds_range(self) -> None:
        config = MultiAgentConfig(debate_rounds=5)
        assert config.debate_rounds == 5

    def test_debate_rounds_min_rejected(self) -> None:
        with pytest.raises(ValueError):
            MultiAgentConfig(debate_rounds=0)

    def test_debate_rounds_max_rejected(self) -> None:
        with pytest.raises(ValueError):
            MultiAgentConfig(debate_rounds=11)

    def test_quality_threshold_range(self) -> None:
        config = MultiAgentConfig(quality_threshold=0.5)
        assert config.quality_threshold == 0.5

    def test_quality_threshold_out_of_range(self) -> None:
        with pytest.raises(ValueError):
            MultiAgentConfig(quality_threshold=1.5)

    def test_budget_per_request(self) -> None:
        config = MultiAgentConfig(budget_per_request=1.25)
        assert config.budget_per_request == 1.25

    def test_budget_per_request_negative_rejected(self) -> None:
        with pytest.raises(ValueError):
            MultiAgentConfig(budget_per_request=-0.10)

    def test_min_complexity_valid_values(self) -> None:
        for level in ("simple", "medium", "complex"):
            config = MultiAgentConfig(min_complexity=level)
            assert config.min_complexity == level

    def test_min_complexity_invalid_rejected(self) -> None:
        with pytest.raises(ValueError, match="min_complexity"):
            MultiAgentConfig(min_complexity="ultra")

    def test_settings_get_multi_agent(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        assert settings.get("multi_agent.enabled") is True
        assert settings.get("multi_agent.debate_rounds") == 2

    def test_settings_override_multi_agent(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        settings.set_override("multi_agent.enabled", False)
        assert settings.config.multi_agent.enabled is False

    def test_settings_override_debate_rounds(self, tmp_path: Path) -> None:
        config = PrismConfig(prism_home=tmp_path / ".prism")
        settings = Settings(config=config, project_root=tmp_path)
        settings.set_override("multi_agent.debate_rounds", 5)
        assert settings.config.multi_agent.debate_rounds == 5

    def test_load_from_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        prism_home = tmp_path / ".prism"
        prism_home.mkdir(parents=True)
        config_file = prism_home / "config.yaml"
        config_file.write_text(
            yaml.dump({
                "multi_agent": {
                    "enabled": False,
                    "strategies": ["cascade", "consensus"],
                    "debate_rounds": 4,
                    "quality_threshold": 0.90,
                    "budget_per_request": 0.25,
                    "min_complexity": "complex",
                }
            })
        )
        monkeypatch.setenv("PRISM_HOME", str(prism_home))
        settings = load_settings(project_root=tmp_path)
        ma = settings.config.multi_agent
        assert ma.enabled is False
        assert ma.strategies == ["cascade", "consensus"]
        assert ma.debate_rounds == 4
        assert ma.quality_threshold == 0.90
        assert ma.budget_per_request == 0.25
        assert ma.min_complexity == "complex"

    def test_save_and_reload_multi_agent(self, tmp_path: Path) -> None:
        config = PrismConfig(
            prism_home=tmp_path / ".prism",
            multi_agent=MultiAgentConfig(
                enabled=False,
                strategies=["debate"],
                debate_rounds=3,
            ),
        )
        settings = Settings(config=config, project_root=tmp_path)
        saved_path = settings.save_to_file(tmp_path / "test_config.yaml")
        loaded_data = yaml.safe_load(saved_path.read_text())
        assert loaded_data["multi_agent"]["enabled"] is False
        assert loaded_data["multi_agent"]["strategies"] == ["debate"]
        assert loaded_data["multi_agent"]["debate_rounds"] == 3


class TestMultiAgentServerHelpers:
    """Tests for the multi-agent helper functions in the proxy server."""

    def test_complexity_meets_minimum_simple(self) -> None:
        from prism.proxy.server import _complexity_meets_minimum
        assert _complexity_meets_minimum("simple", "simple") is True
        assert _complexity_meets_minimum("medium", "simple") is True
        assert _complexity_meets_minimum("complex", "simple") is True

    def test_complexity_meets_minimum_medium(self) -> None:
        from prism.proxy.server import _complexity_meets_minimum
        assert _complexity_meets_minimum("simple", "medium") is False
        assert _complexity_meets_minimum("medium", "medium") is True
        assert _complexity_meets_minimum("complex", "medium") is True

    def test_complexity_meets_minimum_complex(self) -> None:
        from prism.proxy.server import _complexity_meets_minimum
        assert _complexity_meets_minimum("simple", "complex") is False
        assert _complexity_meets_minimum("medium", "complex") is False
        assert _complexity_meets_minimum("complex", "complex") is True

    def test_complexity_meets_minimum_unknown_defaults_to_medium(self) -> None:
        from prism.proxy.server import _complexity_meets_minimum
        assert _complexity_meets_minimum("unknown", "medium") is True
        assert _complexity_meets_minimum("unknown", "complex") is False

    def test_get_multi_agent_config_none_without_settings(self) -> None:
        from prism.proxy import server
        original = server._settings
        try:
            server._settings = None
            result = server._get_multi_agent_config()
            assert result is None
        finally:
            server._settings = original

    def test_get_multi_agent_config_returns_config(self, tmp_path: Path) -> None:
        from prism.proxy import server
        original = server._settings
        try:
            config = PrismConfig(
                prism_home=tmp_path / ".prism",
                multi_agent=MultiAgentConfig(
                    enabled=False,
                    debate_rounds=5,
                ),
            )
            server._settings = Settings(config=config, project_root=tmp_path)
            result = server._get_multi_agent_config()
            assert result is not None
            assert result.enabled is False
            assert result.debate_rounds == 5
        finally:
            server._settings = original
