"""Tests for prism.prompts.templates — Prompt Template Engine."""

from __future__ import annotations

import pytest

from prism.prompts.templates import (
    ChainStepResult,
    Example,
    FewShotBuilder,
    PromptChain,
    PromptTemplate,
    SelectionStrategy,
    TemplateError,
    TemplateNotFoundError,
    TemplateRegistry,
    TemplateRenderError,
    TemplateValidationError,
    create_default_registry,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def registry() -> TemplateRegistry:
    """Create an empty template registry."""
    return TemplateRegistry()


@pytest.fixture
def default_registry() -> TemplateRegistry:
    """Create a registry pre-loaded with built-in templates."""
    return create_default_registry()


@pytest.fixture
def simple_template() -> PromptTemplate:
    """Simple template with two variables."""
    return PromptTemplate(
        name="greeting",
        template="Hello, {name}! Welcome to {place}.",
        version="1.0.0",
    )


@pytest.fixture
def template_with_defaults() -> PromptTemplate:
    """Template with default values."""
    return PromptTemplate(
        name="styled_greeting",
        template="Hello, {name}! Your role is {role}.",
        version="1.0.0",
        defaults={"role": "developer"},
    )


@pytest.fixture
def conditional_template() -> PromptTemplate:
    """Template with conditional blocks."""
    return PromptTemplate(
        name="conditional",
        template="Base content.{?extra}\nExtra: {extra}{/extra}",
        version="1.0.0",
    )


@pytest.fixture
def example_pool() -> list[Example]:
    """Pool of few-shot examples."""
    return [
        Example(input_text="What is 2+2?", output_text="4"),
        Example(input_text="What is 3+3?", output_text="6"),
        Example(input_text="What is 10*5?", output_text="50"),
        Example(input_text="What is 100/4?", output_text="25"),
        Example(input_text="Translate hello to French", output_text="Bonjour"),
        Example(input_text="Translate goodbye to French", output_text="Au revoir"),
    ]


# ===========================================================================
# PromptTemplate
# ===========================================================================


class TestPromptTemplateVariables:
    """Test variable detection and introspection."""

    def test_variables_detected(self, simple_template: PromptTemplate) -> None:
        assert simple_template.variables == {"name", "place"}

    def test_required_variables_no_defaults(
        self, simple_template: PromptTemplate
    ) -> None:
        assert simple_template.required_variables == {"name", "place"}

    def test_required_variables_with_defaults(
        self, template_with_defaults: PromptTemplate
    ) -> None:
        assert template_with_defaults.required_variables == {"name"}

    def test_conditional_variables_detected(
        self, conditional_template: PromptTemplate
    ) -> None:
        assert conditional_template.conditional_variables == {"extra"}

    def test_includes_detected(self) -> None:
        tmpl = PromptTemplate(
            name="composed",
            template="Start\n{@header}\nMiddle\n{@footer}",
        )
        assert tmpl.includes == {"header", "footer"}

    def test_no_variables_in_plain_text(self) -> None:
        tmpl = PromptTemplate(name="plain", template="No variables here.")
        assert tmpl.variables == set()
        assert tmpl.required_variables == set()


class TestPromptTemplateValidation:
    """Test variable validation."""

    def test_validate_all_provided(self, simple_template: PromptTemplate) -> None:
        errors = simple_template.validate({"name": "Alice", "place": "Prism"})
        assert errors == []

    def test_validate_missing_variable(self, simple_template: PromptTemplate) -> None:
        errors = simple_template.validate({"name": "Alice"})
        assert len(errors) == 1
        assert "place" in errors[0]

    def test_validate_defaults_satisfy(
        self, template_with_defaults: PromptTemplate
    ) -> None:
        errors = template_with_defaults.validate({"name": "Bob"})
        assert errors == []


class TestPromptTemplateRender:
    """Test template rendering."""

    def test_simple_render(self, simple_template: PromptTemplate) -> None:
        result = simple_template.render({"name": "Alice", "place": "Prism"})
        assert result == "Hello, Alice! Welcome to Prism."

    def test_render_with_defaults(
        self, template_with_defaults: PromptTemplate
    ) -> None:
        result = template_with_defaults.render({"name": "Bob"})
        assert result == "Hello, Bob! Your role is developer."

    def test_render_override_defaults(
        self, template_with_defaults: PromptTemplate
    ) -> None:
        result = template_with_defaults.render({"name": "Bob", "role": "designer"})
        assert result == "Hello, Bob! Your role is designer."

    def test_render_missing_required_raises(
        self, simple_template: PromptTemplate
    ) -> None:
        with pytest.raises(TemplateValidationError, match="place"):
            simple_template.render({"name": "Alice"})

    def test_conditional_block_present(
        self, conditional_template: PromptTemplate
    ) -> None:
        result = conditional_template.render({"extra": "bonus info"})
        assert "Extra: bonus info" in result

    def test_conditional_block_absent(
        self, conditional_template: PromptTemplate
    ) -> None:
        result = conditional_template.render({})
        assert result == "Base content."
        assert "Extra" not in result

    def test_conditional_block_empty_string(
        self, conditional_template: PromptTemplate
    ) -> None:
        result = conditional_template.render({"extra": ""})
        assert result == "Base content."

    def test_template_composition(self, registry: TemplateRegistry) -> None:
        header = PromptTemplate(
            name="header",
            template="=== Header ===",
        )
        body = PromptTemplate(
            name="composed",
            template="{@header}\nBody: {content}",
        )
        registry.register(header)
        result = body.render({"content": "hello"}, registry=registry)
        assert result == "=== Header ===\nBody: hello"

    def test_composition_missing_registry_raises(self) -> None:
        tmpl = PromptTemplate(name="bad", template="{@missing}")
        with pytest.raises(TemplateRenderError, match="no registry"):
            tmpl.render({})

    def test_composition_missing_template_raises(
        self, registry: TemplateRegistry
    ) -> None:
        tmpl = PromptTemplate(name="bad", template="{@nonexistent}")
        with pytest.raises(TemplateRenderError, match="not found"):
            tmpl.render({}, registry=registry)

    def test_deep_recursion_guard(self, registry: TemplateRegistry) -> None:
        recursive = PromptTemplate(
            name="recursive",
            template="Loop: {@recursive}",
        )
        registry.register(recursive)
        with pytest.raises(TemplateRenderError, match="depth"):
            recursive.render({}, registry=registry)

    def test_render_none_variables_uses_empty(self) -> None:
        tmpl = PromptTemplate(name="test", template="No vars here.")
        result = tmpl.render(None)
        assert result == "No vars here."


# ===========================================================================
# TemplateRegistry
# ===========================================================================


class TestTemplateRegistry:
    """Test template registration, versioning, and retrieval."""

    def test_register_and_get(self, registry: TemplateRegistry) -> None:
        tmpl = PromptTemplate(name="test", template="Hello", version="1.0.0")
        registry.register(tmpl)
        assert registry.get("test").template == "Hello"

    def test_get_latest_version(self, registry: TemplateRegistry) -> None:
        v1 = PromptTemplate(name="t", template="v1", version="1.0.0")
        v2 = PromptTemplate(name="t", template="v2", version="2.0.0")
        registry.register(v1)
        registry.register(v2)
        assert registry.get("t").template == "v2"

    def test_get_specific_version(self, registry: TemplateRegistry) -> None:
        v1 = PromptTemplate(name="t", template="v1", version="1.0.0")
        v2 = PromptTemplate(name="t", template="v2", version="2.0.0")
        registry.register(v1)
        registry.register(v2)
        assert registry.get("t", version="1.0.0").template == "v1"

    def test_get_nonexistent_raises(self, registry: TemplateRegistry) -> None:
        with pytest.raises(TemplateNotFoundError):
            registry.get("nonexistent")

    def test_get_nonexistent_version_raises(
        self, registry: TemplateRegistry
    ) -> None:
        tmpl = PromptTemplate(name="t", template="v1", version="1.0.0")
        registry.register(tmpl)
        with pytest.raises(TemplateNotFoundError, match="9.9.9"):
            registry.get("t", version="9.9.9")

    def test_register_replaces_same_version(
        self, registry: TemplateRegistry
    ) -> None:
        v1a = PromptTemplate(name="t", template="original", version="1.0.0")
        v1b = PromptTemplate(name="t", template="replaced", version="1.0.0")
        registry.register(v1a)
        registry.register(v1b)
        assert registry.get("t", version="1.0.0").template == "replaced"
        assert len(registry.list_versions("t")) == 1

    def test_register_no_name_raises(self, registry: TemplateRegistry) -> None:
        tmpl = PromptTemplate(name="", template="hello")
        with pytest.raises(TemplateError, match="without a name"):
            registry.register(tmpl)

    def test_list_templates(self, registry: TemplateRegistry) -> None:
        registry.register(PromptTemplate(name="a", template="A", description="Alpha"))
        registry.register(PromptTemplate(name="b", template="B", description="Beta"))
        listing = registry.list_templates()
        assert len(listing) == 2
        names = {item["name"] for item in listing}
        assert names == {"a", "b"}

    def test_list_versions(self, registry: TemplateRegistry) -> None:
        registry.register(PromptTemplate(name="t", template="v1", version="1.0.0"))
        registry.register(PromptTemplate(name="t", template="v2", version="2.0.0"))
        registry.register(PromptTemplate(name="t", template="v3", version="1.5.0"))
        versions = registry.list_versions("t")
        assert versions == ["1.0.0", "1.5.0", "2.0.0"]

    def test_has(self, registry: TemplateRegistry) -> None:
        assert not registry.has("missing")
        registry.register(PromptTemplate(name="exists", template="yes"))
        assert registry.has("exists")

    def test_remove_all_versions(self, registry: TemplateRegistry) -> None:
        registry.register(PromptTemplate(name="t", template="v1", version="1.0.0"))
        registry.register(PromptTemplate(name="t", template="v2", version="2.0.0"))
        assert registry.remove("t")
        assert not registry.has("t")

    def test_remove_specific_version(self, registry: TemplateRegistry) -> None:
        registry.register(PromptTemplate(name="t", template="v1", version="1.0.0"))
        registry.register(PromptTemplate(name="t", template="v2", version="2.0.0"))
        assert registry.remove("t", version="1.0.0")
        assert registry.has("t")
        assert registry.get("t").version == "2.0.0"

    def test_remove_nonexistent_returns_false(
        self, registry: TemplateRegistry
    ) -> None:
        assert not registry.remove("ghost")

    def test_list_versions_nonexistent_raises(
        self, registry: TemplateRegistry
    ) -> None:
        with pytest.raises(TemplateNotFoundError):
            registry.list_versions("ghost")


class TestDefaultRegistry:
    """Test the built-in template registry."""

    def test_builtin_count(self, default_registry: TemplateRegistry) -> None:
        listing = default_registry.list_templates()
        assert len(listing) == 8

    def test_builtin_names(self, default_registry: TemplateRegistry) -> None:
        names = {item["name"] for item in default_registry.list_templates()}
        expected = {
            "code_generation",
            "code_review",
            "explain_code",
            "fix_bug",
            "refactor",
            "test_generation",
            "summarize",
            "translate",
        }
        assert names == expected

    def test_builtin_code_generation_render(
        self, default_registry: TemplateRegistry
    ) -> None:
        tmpl = default_registry.get("code_generation")
        result = tmpl.render({"requirement": "Sort a list of integers"})
        assert "Sort a list of integers" in result
        assert "Python" in result  # default language

    def test_builtin_fix_bug_render(
        self, default_registry: TemplateRegistry
    ) -> None:
        tmpl = default_registry.get("fix_bug")
        result = tmpl.render({
            "code": "def add(a, b): return a - b",
            "error": "returns wrong result for add(2, 3)",
        })
        assert "def add(a, b): return a - b" in result
        assert "wrong result" in result

    def test_builtin_summarize_no_required_besides_content(
        self, default_registry: TemplateRegistry
    ) -> None:
        tmpl = default_registry.get("summarize")
        result = tmpl.render({"content": "Long text here."})
        assert "Long text here." in result

    def test_builtin_translate_render(
        self, default_registry: TemplateRegistry
    ) -> None:
        tmpl = default_registry.get("translate")
        result = tmpl.render({
            "source_language": "Python",
            "target_language": "JavaScript",
            "code": "print('hello')",
        })
        assert "Python" in result
        assert "JavaScript" in result


# ===========================================================================
# PromptChain
# ===========================================================================


class TestPromptChain:
    """Test chained template execution."""

    def test_basic_chain(self) -> None:
        step1 = PromptTemplate(name="s1", template="Analyze: {input}")
        step2 = PromptTemplate(name="s2", template="Review: {previous_output}")

        chain = PromptChain()
        chain.add_step(step1, output_key="previous_output")
        chain.add_step(step2, output_key="review")

        results = chain.execute({"input": "some code"})
        assert len(results) == 2
        assert "Analyze: some code" in results[0].output
        assert "Analyze: some code" in results[1].output  # piped forward

    def test_chain_fluent_api(self) -> None:
        step1 = PromptTemplate(name="s1", template="Step 1")
        step2 = PromptTemplate(name="s2", template="Step 2")

        chain = PromptChain().add_step(step1).add_step(step2)
        assert len(chain.steps) == 2

    def test_chain_condition_skip(self) -> None:
        step1 = PromptTemplate(name="s1", template="Output: {input}")
        step2 = PromptTemplate(
            name="s2",
            template="Fix: {previous_output}",
        )

        chain = PromptChain()
        chain.add_step(step1, output_key="previous_output")
        chain.add_step(
            step2,
            output_key="fix",
            condition=lambda v: "error" in v.get("previous_output", "").lower(),
        )

        # Step 2 should be skipped — no "error" in output
        results = chain.execute({"input": "clean code"})
        assert len(results) == 1

    def test_chain_condition_execute(self) -> None:
        step1 = PromptTemplate(name="s1", template="Error found in {input}")
        step2 = PromptTemplate(
            name="s2",
            template="Fixing: {previous_output}",
        )

        chain = PromptChain()
        chain.add_step(step1, output_key="previous_output")
        chain.add_step(
            step2,
            output_key="fix",
            condition=lambda v: "error" in v.get("previous_output", "").lower(),
        )

        results = chain.execute({"input": "broken code"})
        assert len(results) == 2
        assert "Fixing" in results[1].output

    def test_chain_result_has_step_name(self) -> None:
        step = PromptTemplate(name="analysis", template="Analyze: {input}")
        chain = PromptChain()
        chain.add_step(step, name="my_analysis")
        results = chain.execute({"input": "data"})
        assert results[0].step_name == "my_analysis"

    def test_chain_empty(self) -> None:
        chain = PromptChain()
        results = chain.execute({"input": "nothing"})
        assert results == []

    def test_chain_step_default_name(self) -> None:
        step = PromptTemplate(name="", template="No name")
        chain = PromptChain()
        chain.add_step(step)
        assert chain.steps[0].name == "step_0"

    def test_chain_result_repr(self) -> None:
        result = ChainStepResult(step_name="test", output="hello", variables={})
        assert "test" in repr(result)


# ===========================================================================
# FewShotBuilder
# ===========================================================================


class TestFewShotBuilder:
    """Test few-shot prompt construction."""

    def test_build_random(self, example_pool: list[Example]) -> None:
        builder = FewShotBuilder(
            example_pool, num_examples=2, strategy=SelectionStrategy.RANDOM
        )
        prompt = builder.build(query="What is 5+5?")
        assert "Input:" in prompt
        assert "Output:" in prompt

    def test_build_similarity(self, example_pool: list[Example]) -> None:
        builder = FewShotBuilder(
            example_pool, num_examples=2, strategy=SelectionStrategy.SIMILARITY
        )
        prompt = builder.build(query="What is 7+7?")
        # Math-related examples should be selected over translation
        assert "Input:" in prompt

    def test_build_diverse(self, example_pool: list[Example]) -> None:
        builder = FewShotBuilder(
            example_pool, num_examples=3, strategy=SelectionStrategy.DIVERSE
        )
        prompt = builder.build(query="Test")
        assert "Input:" in prompt

    def test_pool_management(self) -> None:
        builder = FewShotBuilder()
        assert builder.pool_size == 0
        builder.add_example(Example(input_text="a", output_text="b"))
        assert builder.pool_size == 1
        builder.add_examples([
            Example(input_text="c", output_text="d"),
            Example(input_text="e", output_text="f"),
        ])
        assert builder.pool_size == 3

    def test_empty_pool_returns_empty(self) -> None:
        builder = FewShotBuilder()
        selected = builder.select(query="anything")
        assert selected == []

    def test_select_respects_num_examples(
        self, example_pool: list[Example]
    ) -> None:
        builder = FewShotBuilder(example_pool, num_examples=2)
        selected = builder.select()
        assert len(selected) == 2

    def test_select_override_num_examples(
        self, example_pool: list[Example]
    ) -> None:
        builder = FewShotBuilder(example_pool, num_examples=2)
        selected = builder.select(num_examples=4)
        assert len(selected) == 4

    def test_select_capped_at_pool_size(
        self, example_pool: list[Example]
    ) -> None:
        builder = FewShotBuilder(example_pool, num_examples=100)
        selected = builder.select()
        assert len(selected) == len(example_pool)

    def test_build_with_instruction(self, example_pool: list[Example]) -> None:
        builder = FewShotBuilder(example_pool, num_examples=1)
        prompt = builder.build(
            instruction="You are a calculator.",
            query="What is 9+9?",
        )
        assert prompt.startswith("You are a calculator.")
        assert "What is 9+9?" in prompt

    def test_custom_example_format(self) -> None:
        custom_fmt = PromptTemplate(
            name="custom",
            template="Q: {input}\nA: {output}",
        )
        builder = FewShotBuilder(
            [Example(input_text="hello", output_text="world")],
            num_examples=1,
            example_format=custom_fmt,
        )
        prompt = builder.build()
        assert "Q: hello" in prompt
        assert "A: world" in prompt

    def test_fluent_api(self) -> None:
        builder = (
            FewShotBuilder()
            .add_example(Example(input_text="a", output_text="1"))
            .add_examples([Example(input_text="b", output_text="2")])
        )
        assert builder.pool_size == 2

    def test_similarity_without_query_falls_back_to_random(
        self, example_pool: list[Example]
    ) -> None:
        builder = FewShotBuilder(
            example_pool, num_examples=2, strategy=SelectionStrategy.SIMILARITY
        )
        selected = builder.select(query="")
        assert len(selected) == 2

    def test_diverse_selects_different_examples(self) -> None:
        examples = [
            Example(input_text="aaa aaa aaa", output_text="1"),
            Example(input_text="aaa aaa bbb", output_text="2"),
            Example(input_text="zzz zzz zzz", output_text="3"),
            Example(input_text="zzz zzz yyy", output_text="4"),
        ]
        builder = FewShotBuilder(
            examples, num_examples=2, strategy=SelectionStrategy.DIVERSE
        )
        selected = builder.select()
        inputs = {ex.input_text for ex in selected}
        # Should pick dissimilar examples — not two "aaa" variants together
        assert len(inputs) == 2

    def test_cosine_similarity_identical(self) -> None:
        vec = {"abc": 3.0, "bcd": 2.0}
        sim = FewShotBuilder._cosine_similarity(vec, vec)
        assert sim == pytest.approx(1.0)

    def test_cosine_similarity_orthogonal(self) -> None:
        vec_a = {"abc": 1.0}
        vec_b = {"xyz": 1.0}
        sim = FewShotBuilder._cosine_similarity(vec_a, vec_b)
        assert sim == pytest.approx(0.0)

    def test_cosine_similarity_empty(self) -> None:
        assert FewShotBuilder._cosine_similarity({}, {"a": 1.0}) == 0.0
        assert FewShotBuilder._cosine_similarity({"a": 1.0}, {}) == 0.0

    def test_trigram_short_text(self) -> None:
        vec = FewShotBuilder._trigram_vector("ab")
        assert vec == {"ab": 1.0}

    def test_trigram_empty_text(self) -> None:
        vec = FewShotBuilder._trigram_vector("")
        assert vec == {}


# ===========================================================================
# Integration
# ===========================================================================


class TestIntegration:
    """End-to-end integration tests combining multiple components."""

    def test_chain_with_registry_includes(self) -> None:
        registry = TemplateRegistry()
        preamble = PromptTemplate(name="preamble", template="You are an expert.")
        step = PromptTemplate(
            name="with_preamble",
            template="{@preamble}\n\nAnalyze: {code}",
        )
        registry.register(preamble)

        chain = PromptChain(registry=registry)
        chain.add_step(step, output_key="analysis")
        results = chain.execute({"code": "x = 1"})
        assert "You are an expert." in results[0].output
        assert "x = 1" in results[0].output

    def test_few_shot_with_chain(self) -> None:
        builder = FewShotBuilder(
            [
                Example(input_text="sort [3,1,2]", output_text="[1,2,3]"),
                Example(input_text="reverse [1,2,3]", output_text="[3,2,1]"),
            ],
            num_examples=2,
            strategy=SelectionStrategy.RANDOM,
        )
        few_shot_prompt = builder.build(
            instruction="You transform lists.",
            query="sort [5,4,3]",
        )

        step = PromptTemplate(
            name="answer",
            template="{context}\n\nNow answer.",
        )
        chain = PromptChain()
        chain.add_step(step, output_key="final")
        results = chain.execute({"context": few_shot_prompt})
        assert "sort [5,4,3]" in results[0].output

    def test_nested_composition(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplate(
            name="role",
            template="You are a {role}.",
            defaults={"role": "developer"},
        ))
        registry.register(PromptTemplate(
            name="task",
            template="{@role}\n\nTask: {description}",
        ))
        registry.register(PromptTemplate(
            name="full",
            template="{@task}\n\nContext: {context}",
        ))

        full = registry.get("full")
        result = full.render(
            {"description": "Fix the bug", "context": "Tests failing"},
            registry=registry,
        )
        assert "You are a developer." in result
        assert "Fix the bug" in result
        assert "Tests failing" in result
