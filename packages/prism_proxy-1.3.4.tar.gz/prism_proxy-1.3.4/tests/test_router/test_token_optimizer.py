"""Tests for the adaptive token budget optimizer."""

from __future__ import annotations

import threading

import pytest

from prism.router.token_optimizer import (
    BudgetRecommendation,
    TaskType,
    TokenBudgetOptimizer,
    TokenUsageRecord,
    WasteReport,
    _percentile,
    _waste_pct,
)

# -------------------------------------------------------------------
# Fixtures
# -------------------------------------------------------------------


@pytest.fixture()
def optimizer() -> TokenBudgetOptimizer:
    """Return a default-configured optimizer."""
    return TokenBudgetOptimizer()


@pytest.fixture()
def seeded_optimizer() -> TokenBudgetOptimizer:
    """Return an optimizer pre-loaded with usage data for gpt-4o / code."""
    opt = TokenBudgetOptimizer()
    for i in range(20):
        opt.record_usage(
            TokenUsageRecord(
                model="gpt-4o",
                task_type="code",
                allocated_tokens=4096,
                used_tokens=1500 + i * 10,
                was_truncated=False,
            ),
        )
    return opt


# -------------------------------------------------------------------
# Constructor validation
# -------------------------------------------------------------------


class TestConstructorValidation:
    """Verify that invalid init parameters are rejected."""

    def test_alpha_zero_rejected(self) -> None:
        with pytest.raises(ValueError, match="alpha"):
            TokenBudgetOptimizer(alpha=0.0)

    def test_alpha_negative_rejected(self) -> None:
        with pytest.raises(ValueError, match="alpha"):
            TokenBudgetOptimizer(alpha=-0.1)

    def test_alpha_above_one_rejected(self) -> None:
        with pytest.raises(ValueError, match="alpha"):
            TokenBudgetOptimizer(alpha=1.5)

    def test_alpha_one_accepted(self) -> None:
        opt = TokenBudgetOptimizer(alpha=1.0)
        assert opt._alpha == 1.0

    def test_headroom_below_one_rejected(self) -> None:
        with pytest.raises(ValueError, match="headroom"):
            TokenBudgetOptimizer(headroom=0.9)

    def test_headroom_one_accepted(self) -> None:
        opt = TokenBudgetOptimizer(headroom=1.0)
        assert opt._headroom == 1.0


# -------------------------------------------------------------------
# record_usage
# -------------------------------------------------------------------


class TestRecordUsage:
    """Verify recording and input validation."""

    def test_record_single(self, optimizer: TokenBudgetOptimizer) -> None:
        rec = TokenUsageRecord(
            model="gpt-4o",
            task_type="code",
            allocated_tokens=4096,
            used_tokens=2000,
            was_truncated=False,
        )
        optimizer.record_usage(rec)
        # No error means success — also confirm window exists.
        profile = optimizer.get_model_profile("gpt-4o")
        # Below MIN_SAMPLES, profile should be empty.
        assert profile == {}

    def test_negative_allocated_rejected(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        with pytest.raises(ValueError, match="allocated_tokens"):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="chat",
                    allocated_tokens=-1,
                    used_tokens=0,
                    was_truncated=False,
                ),
            )

    def test_negative_used_rejected(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        with pytest.raises(ValueError, match="used_tokens"):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="chat",
                    allocated_tokens=100,
                    used_tokens=-5,
                    was_truncated=False,
                ),
            )

    def test_zero_allocation_accepted(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        """Zero-allocation edge case (e.g., streaming with unknown cap)."""
        rec = TokenUsageRecord(
            model="m",
            task_type="chat",
            allocated_tokens=0,
            used_tokens=0,
            was_truncated=False,
        )
        optimizer.record_usage(rec)  # Should not raise


# -------------------------------------------------------------------
# recommend_budget — defaults
# -------------------------------------------------------------------


class TestRecommendBudgetDefaults:
    """Verify default recommendations when no history is present."""

    def test_default_code_budget(self, optimizer: TokenBudgetOptimizer) -> None:
        rec = optimizer.recommend_budget("gpt-4o", "code")
        assert isinstance(rec, BudgetRecommendation)
        assert rec.recommended_max_tokens == 4096
        assert rec.confidence == 0.0
        assert rec.waste_reduction_pct == 0.0

    def test_default_chat_budget(self, optimizer: TokenBudgetOptimizer) -> None:
        rec = optimizer.recommend_budget("gpt-4o", "chat")
        assert rec.recommended_max_tokens == 1024

    def test_default_analysis_budget(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        rec = optimizer.recommend_budget("gpt-4o", "analysis")
        assert rec.recommended_max_tokens == 2048

    def test_default_unknown_task_type(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        rec = optimizer.recommend_budget("gpt-4o", "summarise")
        assert rec.recommended_max_tokens == 2048  # fallback

    def test_insufficient_samples_returns_default(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        """Only 3 records (below MIN_SAMPLES=5) — should use default."""
        for _ in range(3):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=500,
                    was_truncated=False,
                ),
            )
        rec = optimizer.recommend_budget("m", "code")
        assert rec.confidence == 0.0
        assert rec.recommended_max_tokens == 4096


# -------------------------------------------------------------------
# recommend_budget — learned
# -------------------------------------------------------------------


class TestRecommendBudgetLearned:
    """Verify recommendations improve with recorded history."""

    def test_recommendation_below_original_allocation(
        self, seeded_optimizer: TokenBudgetOptimizer
    ) -> None:
        """With usage ~1500-1700, recommendation should be < 4096."""
        rec = seeded_optimizer.recommend_budget("gpt-4o", "code")
        assert rec.recommended_max_tokens < 4096
        assert rec.confidence > 0.0
        assert rec.waste_reduction_pct > 0.0

    def test_headroom_applied(self) -> None:
        """Recommendation should be higher than the raw EWMA."""
        opt = TokenBudgetOptimizer(headroom=1.5)
        for _ in range(20):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="chat",
                    allocated_tokens=4096,
                    used_tokens=1000,
                    was_truncated=False,
                ),
            )
        rec = opt.recommend_budget("m", "chat")
        # With constant 1000 usage and 1.5x headroom → ~1500
        assert rec.recommended_max_tokens >= 1400
        assert rec.recommended_max_tokens <= 1600

    def test_p99_floor(self) -> None:
        """If a few responses are very long, P99 floor should kick in."""
        opt = TokenBudgetOptimizer()
        for _ in range(95):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=500,
                    was_truncated=False,
                ),
            )
        # Inject a few very long responses.
        for _ in range(5):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=3800,
                    was_truncated=False,
                ),
            )
        rec = opt.recommend_budget("m", "code")
        # P99 should be close to 3800 — recommendation must be at least that.
        assert rec.recommended_max_tokens >= 3000

    def test_confidence_increases_with_samples(self) -> None:
        opt = TokenBudgetOptimizer()
        for n in (5, 50, 100):
            opt.reset()
            for _ in range(n):
                opt.record_usage(
                    TokenUsageRecord(
                        model="m",
                        task_type="code",
                        allocated_tokens=4096,
                        used_tokens=1000,
                        was_truncated=False,
                    ),
                )
            rec = opt.recommend_budget("m", "code")
            if n == 5:
                low_conf = rec.confidence
            elif n == 100:
                high_conf = rec.confidence
        assert high_conf > low_conf  # type: ignore[possibly-undefined]

    def test_truncation_penalises_confidence(self) -> None:
        opt = TokenBudgetOptimizer()
        for _ in range(50):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=500,
                    used_tokens=500,
                    was_truncated=True,
                ),
            )
        rec = opt.recommend_budget("m", "code")
        assert rec.confidence < 0.1  # Heavily penalised

    def test_ewma_adapts_to_shift(self) -> None:
        """After usage shifts upward, the recommendation should increase."""
        opt = TokenBudgetOptimizer(alpha=0.3)
        # Phase 1: low usage
        for _ in range(20):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=500,
                    was_truncated=False,
                ),
            )
        rec_low = opt.recommend_budget("m", "code")

        # Phase 2: high usage
        for _ in range(20):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=3000,
                    was_truncated=False,
                ),
            )
        rec_high = opt.recommend_budget("m", "code")
        assert rec_high.recommended_max_tokens > rec_low.recommended_max_tokens

    def test_absolute_min_floor(self) -> None:
        """Even with tiny usage, never recommend below _ABSOLUTE_MIN_TOKENS."""
        opt = TokenBudgetOptimizer()
        for _ in range(10):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="chat",
                    allocated_tokens=100,
                    used_tokens=5,
                    was_truncated=False,
                ),
            )
        rec = opt.recommend_budget("m", "chat")
        assert rec.recommended_max_tokens >= 64


# -------------------------------------------------------------------
# get_waste_report
# -------------------------------------------------------------------


class TestWasteReport:
    """Verify waste reporting accuracy."""

    def test_empty_report(self, optimizer: TokenBudgetOptimizer) -> None:
        report = optimizer.get_waste_report()
        assert report.total_allocated == 0
        assert report.total_used == 0
        assert report.waste_pct == 0.0
        assert report.waste_by_model == {}
        assert report.waste_by_task_type == {}

    def test_basic_waste_calculation(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        for _ in range(10):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="gpt-4o",
                    task_type="code",
                    allocated_tokens=1000,
                    used_tokens=500,
                    was_truncated=False,
                ),
            )
        report = optimizer.get_waste_report()
        assert report.total_allocated == 10_000
        assert report.total_used == 5_000
        assert report.waste_pct == pytest.approx(50.0, abs=0.1)

    def test_waste_by_model(self, optimizer: TokenBudgetOptimizer) -> None:
        for _ in range(10):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="gpt-4o",
                    task_type="code",
                    allocated_tokens=1000,
                    used_tokens=200,
                    was_truncated=False,
                ),
            )
            optimizer.record_usage(
                TokenUsageRecord(
                    model="claude",
                    task_type="code",
                    allocated_tokens=1000,
                    used_tokens=800,
                    was_truncated=False,
                ),
            )
        report = optimizer.get_waste_report()
        assert report.waste_by_model["gpt-4o"] > report.waste_by_model["claude"]

    def test_waste_by_task_type(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        for _ in range(10):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=3000,
                    was_truncated=False,
                ),
            )
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="chat",
                    allocated_tokens=4096,
                    used_tokens=200,
                    was_truncated=False,
                ),
            )
        report = optimizer.get_waste_report()
        assert report.waste_by_task_type["chat"] > report.waste_by_task_type["code"]

    def test_no_waste_when_fully_used(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        for _ in range(10):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=1000,
                    used_tokens=1000,
                    was_truncated=False,
                ),
            )
        report = optimizer.get_waste_report()
        assert report.waste_pct == pytest.approx(0.0, abs=0.01)


# -------------------------------------------------------------------
# get_model_profile
# -------------------------------------------------------------------


class TestModelProfile:
    """Verify per-model profiling."""

    def test_empty_profile(self, optimizer: TokenBudgetOptimizer) -> None:
        assert optimizer.get_model_profile("unknown") == {}

    def test_profile_with_data(
        self, seeded_optimizer: TokenBudgetOptimizer
    ) -> None:
        profile = seeded_optimizer.get_model_profile("gpt-4o")
        assert profile != {}
        assert "p50" in profile
        assert "p90" in profile
        assert "p99" in profile
        assert "mean" in profile
        assert profile["sample_count"] == 20
        assert profile["truncation_rate"] == 0.0
        assert "code" in profile["task_types"]

    def test_profile_aggregates_task_types(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        """Profile for a model should merge data from all its task types."""
        for _ in range(10):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=2000,
                    was_truncated=False,
                ),
            )
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="chat",
                    allocated_tokens=1024,
                    used_tokens=500,
                    was_truncated=False,
                ),
            )
        profile = optimizer.get_model_profile("m")
        assert profile["sample_count"] == 20
        assert set(profile["task_types"]) == {"code", "chat"}

    def test_profile_truncation_rate(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        for i in range(10):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=500,
                    used_tokens=500,
                    was_truncated=(i < 3),  # 3 out of 10 truncated
                ),
            )
        profile = optimizer.get_model_profile("m")
        assert profile["truncation_rate"] == pytest.approx(0.3, abs=0.01)

    def test_profile_percentile_ordering(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        for i in range(50):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=100 + i * 50,
                    was_truncated=False,
                ),
            )
        profile = optimizer.get_model_profile("m")
        assert profile["p50"] <= profile["p90"]
        assert profile["p90"] <= profile["p99"]
        assert profile["min"] <= profile["p50"]
        assert profile["p99"] <= profile["max"]


# -------------------------------------------------------------------
# reset
# -------------------------------------------------------------------


class TestReset:
    """Verify reset clears all state."""

    def test_reset_clears_data(
        self, seeded_optimizer: TokenBudgetOptimizer
    ) -> None:
        seeded_optimizer.reset()
        assert seeded_optimizer.get_model_profile("gpt-4o") == {}
        report = seeded_optimizer.get_waste_report()
        assert report.total_allocated == 0

    def test_reset_then_record(
        self, seeded_optimizer: TokenBudgetOptimizer
    ) -> None:
        seeded_optimizer.reset()
        for _ in range(10):
            seeded_optimizer.record_usage(
                TokenUsageRecord(
                    model="new-model",
                    task_type="chat",
                    allocated_tokens=1024,
                    used_tokens=300,
                    was_truncated=False,
                ),
            )
        profile = seeded_optimizer.get_model_profile("new-model")
        assert profile["sample_count"] == 10


# -------------------------------------------------------------------
# export / import state
# -------------------------------------------------------------------


class TestExportImportState:
    """Verify round-trip serialisation."""

    def test_round_trip(self, seeded_optimizer: TokenBudgetOptimizer) -> None:
        state = seeded_optimizer.export_state()
        assert "windows" in state
        assert "alpha" in state
        assert "headroom" in state

        new_opt = TokenBudgetOptimizer()
        new_opt.import_state(state)

        old_rec = seeded_optimizer.recommend_budget("gpt-4o", "code")
        new_rec = new_opt.recommend_budget("gpt-4o", "code")
        assert old_rec.recommended_max_tokens == new_rec.recommended_max_tokens

    def test_import_restores_waste_report(
        self, seeded_optimizer: TokenBudgetOptimizer
    ) -> None:
        state = seeded_optimizer.export_state()
        new_opt = TokenBudgetOptimizer()
        new_opt.import_state(state)

        old_report = seeded_optimizer.get_waste_report()
        new_report = new_opt.get_waste_report()
        assert old_report.total_allocated == new_report.total_allocated
        assert old_report.total_used == new_report.total_used


# -------------------------------------------------------------------
# Thread safety
# -------------------------------------------------------------------


class TestThreadSafety:
    """Verify that concurrent access does not corrupt state."""

    def test_concurrent_record_usage(self) -> None:
        opt = TokenBudgetOptimizer()
        errors: list[Exception] = []

        def worker(tid: int) -> None:
            try:
                for i in range(50):
                    opt.record_usage(
                        TokenUsageRecord(
                            model=f"model-{tid % 3}",
                            task_type="code",
                            allocated_tokens=4096,
                            used_tokens=500 + i,
                            was_truncated=False,
                        ),
                    )
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == []
        report = opt.get_waste_report()
        assert report.total_allocated > 0


# -------------------------------------------------------------------
# TaskType enum
# -------------------------------------------------------------------


class TestTaskTypeEnum:
    """Verify TaskType enum values."""

    def test_values(self) -> None:
        assert TaskType.CODE.value == "code"
        assert TaskType.CHAT.value == "chat"
        assert TaskType.ANALYSIS.value == "analysis"

    def test_usable_as_task_type_string(
        self, optimizer: TokenBudgetOptimizer
    ) -> None:
        for _ in range(10):
            optimizer.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type=TaskType.CODE,
                    allocated_tokens=4096,
                    used_tokens=1000,
                    was_truncated=False,
                ),
            )
        rec = optimizer.recommend_budget("m", TaskType.CODE)
        assert rec.recommended_max_tokens > 0


# -------------------------------------------------------------------
# Window eviction
# -------------------------------------------------------------------


class TestWindowEviction:
    """Verify rolling window stays bounded."""

    def test_window_caps_at_max_history(self) -> None:
        opt = TokenBudgetOptimizer()
        for i in range(600):
            opt.record_usage(
                TokenUsageRecord(
                    model="m",
                    task_type="code",
                    allocated_tokens=4096,
                    used_tokens=1000 + (i % 100),
                    was_truncated=False,
                ),
            )
        profile = opt.get_model_profile("m")
        assert profile["sample_count"] == 500


# -------------------------------------------------------------------
# Module-level utility functions
# -------------------------------------------------------------------


class TestUtilities:
    """Test the module-level helper functions."""

    def test_percentile_empty(self) -> None:
        assert _percentile([], 0.5) == 0

    def test_percentile_single(self) -> None:
        assert _percentile([42], 0.5) == 42

    def test_percentile_median(self) -> None:
        vals = list(range(1, 101))
        p50 = _percentile(vals, 0.50)
        assert 49 <= p50 <= 51

    def test_percentile_p99(self) -> None:
        vals = list(range(1, 101))
        p99 = _percentile(vals, 0.99)
        assert p99 >= 98

    def test_waste_pct_zero_allocated(self) -> None:
        assert _waste_pct(0, 0) == 0.0

    def test_waste_pct_half(self) -> None:
        assert _waste_pct(1000, 500) == pytest.approx(50.0)

    def test_waste_pct_no_waste(self) -> None:
        assert _waste_pct(1000, 1000) == pytest.approx(0.0)


# -------------------------------------------------------------------
# Dataclass immutability
# -------------------------------------------------------------------


class TestDataclassImmutability:
    """Verify frozen dataclasses are truly immutable."""

    def test_token_usage_record_frozen(self) -> None:
        rec = TokenUsageRecord(
            model="m",
            task_type="code",
            allocated_tokens=100,
            used_tokens=50,
            was_truncated=False,
        )
        with pytest.raises(AttributeError):
            rec.model = "other"  # type: ignore[misc]

    def test_budget_recommendation_frozen(self) -> None:
        br = BudgetRecommendation(
            model="m",
            task_type="code",
            recommended_max_tokens=1000,
            confidence=0.9,
            waste_reduction_pct=30.0,
        )
        with pytest.raises(AttributeError):
            br.confidence = 0.5  # type: ignore[misc]

    def test_waste_report_frozen(self) -> None:
        wr = WasteReport(
            total_allocated=1000,
            total_used=500,
            waste_pct=50.0,
            waste_by_model={},
            waste_by_task_type={},
        )
        with pytest.raises(AttributeError):
            wr.waste_pct = 10.0  # type: ignore[misc]
