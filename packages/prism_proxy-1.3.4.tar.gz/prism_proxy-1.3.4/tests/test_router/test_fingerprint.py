"""Tests for prism.router.fingerprint — provider fingerprinting and capability detection."""

from __future__ import annotations

import datetime

import pytest

from prism.router.fingerprint import (
    ModelFingerprint,
    ProviderCapability,
    ProviderFingerprinter,
)

# ======================================================================
# Fixtures
# ======================================================================

@pytest.fixture
def fingerprinter() -> ProviderFingerprinter:
    """Return a freshly-initialized fingerprinter with the built-in registry."""
    return ProviderFingerprinter()


@pytest.fixture
def custom_fingerprint() -> ModelFingerprint:
    """A minimal custom fingerprint for registration tests."""
    return ModelFingerprint(
        model_id="custom/test-model",
        provider="custom",
        max_context_window=8_192,
        max_output_tokens=2_048,
        capabilities=frozenset({
            ProviderCapability.STREAMING,
            ProviderCapability.SYSTEM_MESSAGES,
        }),
        supports_temperature=True,
        supports_top_p=False,
        supports_stop_sequences=True,
        supports_frequency_penalty=False,
        supports_presence_penalty=False,
        cost_per_1k_input=0.001,
        cost_per_1k_output=0.002,
        typical_latency_ms=500.0,
        release_date=datetime.date(2025, 1, 1),
    )


# ======================================================================
# ProviderCapability enum
# ======================================================================

class TestProviderCapability:
    """Tests for the ProviderCapability enum."""

    def test_all_members_present(self) -> None:
        """All 12 expected capabilities exist."""
        expected = {
            "STREAMING", "TOOL_CALLING", "VISION", "JSON_MODE",
            "EXTENDED_THINKING", "FUNCTION_CALLING", "SYSTEM_MESSAGES",
            "SEED_CONTROL", "LOGPROBS", "EMBEDDING", "FINE_TUNING",
            "BATCH_API",
        }
        actual = {c.name for c in ProviderCapability}
        assert actual == expected

    def test_strenum_values_are_strings(self) -> None:
        """Each member's value is a non-empty string (StrEnum auto())."""
        for cap in ProviderCapability:
            assert isinstance(cap.value, str)
            assert len(cap.value) > 0


# ======================================================================
# ModelFingerprint dataclass
# ======================================================================

class TestModelFingerprint:
    """Tests for the ModelFingerprint dataclass."""

    def test_has_capability_true(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            capabilities=frozenset({ProviderCapability.STREAMING}),
        )
        assert fp.has_capability(ProviderCapability.STREAMING) is True

    def test_has_capability_false(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            capabilities=frozenset(),
        )
        assert fp.has_capability(ProviderCapability.VISION) is False

    def test_estimated_cost_calculation(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            cost_per_1k_input=0.01,
            cost_per_1k_output=0.03,
        )
        # 2000 input tokens at $0.01/1k = $0.02
        # 500 output tokens at $0.03/1k = $0.015
        cost = fp.estimated_cost(2000, 500)
        assert cost == pytest.approx(0.035)

    def test_estimated_cost_zero(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            cost_per_1k_input=0.0,
            cost_per_1k_output=0.0,
        )
        assert fp.estimated_cost(10_000, 5_000) == 0.0

    def test_is_deprecated_no_date(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
        )
        assert fp.is_deprecated() is False

    def test_is_deprecated_future_date(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            deprecation_date=datetime.date(2099, 12, 31),
        )
        assert fp.is_deprecated() is False

    def test_is_deprecated_past_date(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            deprecation_date=datetime.date(2020, 1, 1),
        )
        assert fp.is_deprecated() is True

    def test_is_deprecated_explicit_reference_date(self) -> None:
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            deprecation_date=datetime.date(2025, 6, 1),
        )
        assert fp.is_deprecated(datetime.date(2025, 5, 31)) is False
        assert fp.is_deprecated(datetime.date(2025, 6, 1)) is True
        assert fp.is_deprecated(datetime.date(2025, 6, 2)) is True

    def test_frozen_dataclass(self) -> None:
        """ModelFingerprint instances are immutable."""
        fp = ModelFingerprint(
            model_id="test",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
        )
        with pytest.raises(AttributeError):
            fp.model_id = "changed"  # type: ignore[misc]


# ======================================================================
# ProviderFingerprinter — registration
# ======================================================================

class TestRegistration:
    """Tests for register / unregister / contains."""

    def test_builtin_models_loaded(self, fingerprinter: ProviderFingerprinter) -> None:
        """The built-in registry contains at least 15 models."""
        assert len(fingerprinter) >= 15

    def test_register_new_model(
        self,
        fingerprinter: ProviderFingerprinter,
        custom_fingerprint: ModelFingerprint,
    ) -> None:
        before = len(fingerprinter)
        fingerprinter.register(custom_fingerprint)
        assert len(fingerprinter) == before + 1
        assert "custom/test-model" in fingerprinter

    def test_register_replaces_existing(
        self,
        fingerprinter: ProviderFingerprinter,
    ) -> None:
        replacement = ModelFingerprint(
            model_id="gpt-4o",
            provider="openai",
            max_context_window=256_000,
            max_output_tokens=32_000,
        )
        fingerprinter.register(replacement)
        fp = fingerprinter.get_fingerprint("gpt-4o")
        assert fp is not None
        assert fp.max_context_window == 256_000

    def test_unregister_existing(self, fingerprinter: ProviderFingerprinter) -> None:
        assert "gpt-4o" in fingerprinter
        removed = fingerprinter.unregister("gpt-4o")
        assert removed is True
        assert "gpt-4o" not in fingerprinter

    def test_unregister_nonexistent(self, fingerprinter: ProviderFingerprinter) -> None:
        assert fingerprinter.unregister("nonexistent-model") is False

    def test_contains_known(self, fingerprinter: ProviderFingerprinter) -> None:
        assert "gpt-4o" in fingerprinter

    def test_contains_unknown(self, fingerprinter: ProviderFingerprinter) -> None:
        assert "totally-fake-model" not in fingerprinter


# ======================================================================
# ProviderFingerprinter — get_fingerprint
# ======================================================================

class TestGetFingerprint:
    """Tests for get_fingerprint."""

    def test_known_model(self, fingerprinter: ProviderFingerprinter) -> None:
        fp = fingerprinter.get_fingerprint("gpt-4o")
        assert fp is not None
        assert fp.model_id == "gpt-4o"
        assert fp.provider == "openai"

    def test_unknown_model_returns_none(self, fingerprinter: ProviderFingerprinter) -> None:
        assert fingerprinter.get_fingerprint("nonexistent") is None

    def test_gpt4o_has_vision(self, fingerprinter: ProviderFingerprinter) -> None:
        fp = fingerprinter.get_fingerprint("gpt-4o")
        assert fp is not None
        assert ProviderCapability.VISION in fp.capabilities

    def test_claude_opus_has_thinking(self, fingerprinter: ProviderFingerprinter) -> None:
        fp = fingerprinter.get_fingerprint("claude-4-opus")
        assert fp is not None
        assert ProviderCapability.EXTENDED_THINKING in fp.capabilities

    def test_ollama_minimal_capabilities(self, fingerprinter: ProviderFingerprinter) -> None:
        fp = fingerprinter.get_fingerprint("ollama/local")
        assert fp is not None
        assert fp.capabilities == frozenset({
            ProviderCapability.STREAMING,
            ProviderCapability.SYSTEM_MESSAGES,
        })

    def test_gemini_large_context(self, fingerprinter: ProviderFingerprinter) -> None:
        fp = fingerprinter.get_fingerprint("gemini-2.5-pro")
        assert fp is not None
        assert fp.max_context_window == 1_000_000


# ======================================================================
# ProviderFingerprinter — supports
# ======================================================================

class TestSupports:
    """Tests for the supports() shorthand."""

    def test_supports_true(self, fingerprinter: ProviderFingerprinter) -> None:
        assert fingerprinter.supports("gpt-4o", ProviderCapability.STREAMING) is True

    def test_supports_false(self, fingerprinter: ProviderFingerprinter) -> None:
        assert fingerprinter.supports("ollama/local", ProviderCapability.VISION) is False

    def test_supports_unknown_model(self, fingerprinter: ProviderFingerprinter) -> None:
        assert fingerprinter.supports("fake-model", ProviderCapability.STREAMING) is False


# ======================================================================
# ProviderFingerprinter — find_models
# ======================================================================

class TestFindModels:
    """Tests for find_models."""

    def test_find_vision_models(self, fingerprinter: ProviderFingerprinter) -> None:
        results = fingerprinter.find_models({ProviderCapability.VISION})
        assert len(results) > 0
        for fp in results:
            assert ProviderCapability.VISION in fp.capabilities

    def test_find_with_cost_ceiling(self, fingerprinter: ProviderFingerprinter) -> None:
        results = fingerprinter.find_models(
            {ProviderCapability.STREAMING},
            max_cost_per_1k=0.001,
        )
        for fp in results:
            assert fp.cost_per_1k_input <= 0.001

    def test_find_with_provider_filter(self, fingerprinter: ProviderFingerprinter) -> None:
        results = fingerprinter.find_models(
            {ProviderCapability.STREAMING},
            provider="anthropic",
        )
        for fp in results:
            assert fp.provider == "anthropic"

    def test_find_sorted_by_cost(self, fingerprinter: ProviderFingerprinter) -> None:
        results = fingerprinter.find_models({ProviderCapability.STREAMING})
        costs = [fp.cost_per_1k_input for fp in results]
        assert costs == sorted(costs)

    def test_find_no_matches(self, fingerprinter: ProviderFingerprinter) -> None:
        # EMBEDDING + FINE_TUNING — no built-in model has both
        results = fingerprinter.find_models({
            ProviderCapability.EMBEDDING,
            ProviderCapability.FINE_TUNING,
        })
        assert results == []

    def test_find_extended_thinking_models(self, fingerprinter: ProviderFingerprinter) -> None:
        results = fingerprinter.find_models({ProviderCapability.EXTENDED_THINKING})
        ids = {fp.model_id for fp in results}
        # At minimum, o3, o3-mini, o4-mini, claude-4-opus, claude-4-sonnet, gemini models
        assert "o3" in ids
        assert "claude-4-opus" in ids

    def test_find_with_multiple_requirements(self, fingerprinter: ProviderFingerprinter) -> None:
        results = fingerprinter.find_models({
            ProviderCapability.VISION,
            ProviderCapability.TOOL_CALLING,
            ProviderCapability.JSON_MODE,
        })
        assert len(results) > 0
        for fp in results:
            assert ProviderCapability.VISION in fp.capabilities
            assert ProviderCapability.TOOL_CALLING in fp.capabilities
            assert ProviderCapability.JSON_MODE in fp.capabilities


# ======================================================================
# ProviderFingerprinter — get_compatible_fallbacks
# ======================================================================

class TestGetCompatibleFallbacks:
    """Tests for get_compatible_fallbacks."""

    def test_fallbacks_for_gpt4o(self, fingerprinter: ProviderFingerprinter) -> None:
        fallbacks = fingerprinter.get_compatible_fallbacks("gpt-4o")
        assert isinstance(fallbacks, list)
        assert "gpt-4o" not in fallbacks  # Primary excluded

    def test_fallbacks_unknown_model(self, fingerprinter: ProviderFingerprinter) -> None:
        assert fingerprinter.get_compatible_fallbacks("fake-model") == []

    def test_fallbacks_respects_max_results(self, fingerprinter: ProviderFingerprinter) -> None:
        fallbacks = fingerprinter.get_compatible_fallbacks("gpt-4o-mini", max_results=2)
        assert len(fallbacks) <= 2

    def test_fallbacks_contain_superset_capabilities(
        self,
        fingerprinter: ProviderFingerprinter,
    ) -> None:
        """Every fallback must have at least the primary model's capabilities."""
        primary = fingerprinter.get_fingerprint("claude-3.5-haiku")
        assert primary is not None
        fallbacks = fingerprinter.get_compatible_fallbacks("claude-3.5-haiku")
        for fid in fallbacks:
            fb = fingerprinter.get_fingerprint(fid)
            assert fb is not None
            assert primary.capabilities.issubset(fb.capabilities)


# ======================================================================
# ProviderFingerprinter — compare
# ======================================================================

class TestCompare:
    """Tests for compare."""

    def test_compare_known_models(self, fingerprinter: ProviderFingerprinter) -> None:
        result = fingerprinter.compare("gpt-4o", "claude-4-opus")
        assert result["model_a"] == "gpt-4o"
        assert result["model_b"] == "claude-4-opus"
        assert isinstance(result["capabilities_shared"], list)
        assert isinstance(result["capabilities_only_a"], list)
        assert isinstance(result["capabilities_only_b"], list)
        assert "gpt-4o" in result["context_window"]
        assert "claude-4-opus" in result["context_window"]

    def test_compare_unknown_model_a(self, fingerprinter: ProviderFingerprinter) -> None:
        with pytest.raises(ValueError, match="Unknown model: fake"):
            fingerprinter.compare("fake", "gpt-4o")

    def test_compare_unknown_model_b(self, fingerprinter: ProviderFingerprinter) -> None:
        with pytest.raises(ValueError, match="Unknown model: fake"):
            fingerprinter.compare("gpt-4o", "fake")

    def test_compare_same_model(self, fingerprinter: ProviderFingerprinter) -> None:
        result = fingerprinter.compare("gpt-4o", "gpt-4o")
        assert result["capabilities_only_a"] == []
        assert result["capabilities_only_b"] == []
        # Shared should be non-empty (gpt-4o has capabilities)
        assert len(result["capabilities_shared"]) > 0

    def test_compare_cost_data(self, fingerprinter: ProviderFingerprinter) -> None:
        result = fingerprinter.compare("gpt-4o-mini", "gpt-4o")
        cost_in = result["cost_input"]
        assert cost_in["gpt-4o-mini"] < cost_in["gpt-4o"]


# ======================================================================
# ProviderFingerprinter — validate_request
# ======================================================================

class TestValidateRequest:
    """Tests for validate_request."""

    def test_valid_request_no_warnings(self, fingerprinter: ProviderFingerprinter) -> None:
        warnings = fingerprinter.validate_request(
            "gpt-4o",
            temperature=0.7,
            top_p=0.9,
            stream=True,
        )
        assert warnings == []

    def test_unknown_model(self, fingerprinter: ProviderFingerprinter) -> None:
        warnings = fingerprinter.validate_request("fake-model", temperature=0.5)
        assert len(warnings) == 1
        assert "Unknown model" in warnings[0]

    def test_unsupported_frequency_penalty(self, fingerprinter: ProviderFingerprinter) -> None:
        # Anthropic models don't support frequency_penalty
        warnings = fingerprinter.validate_request(
            "claude-4-opus",
            frequency_penalty=0.5,
        )
        assert any("frequency_penalty" in w for w in warnings)

    def test_unsupported_presence_penalty(self, fingerprinter: ProviderFingerprinter) -> None:
        warnings = fingerprinter.validate_request(
            "claude-4-sonnet",
            presence_penalty=0.3,
        )
        assert any("presence_penalty" in w for w in warnings)

    def test_tools_on_model_without_tool_calling(
        self,
        fingerprinter: ProviderFingerprinter,
    ) -> None:
        warnings = fingerprinter.validate_request(
            "ollama/local",
            tools=[{"type": "function", "function": {"name": "test"}}],
        )
        assert any("tool calling" in w for w in warnings)

    def test_json_mode_on_unsupported_model(
        self,
        fingerprinter: ProviderFingerprinter,
    ) -> None:
        warnings = fingerprinter.validate_request(
            "ollama/local",
            response_format={"type": "json_object"},
        )
        assert any("JSON mode" in w for w in warnings)

    def test_logprobs_on_unsupported_model(
        self,
        fingerprinter: ProviderFingerprinter,
    ) -> None:
        # Anthropic models don't support logprobs
        warnings = fingerprinter.validate_request(
            "claude-4-opus",
            logprobs=True,
        )
        assert any("logprobs" in w for w in warnings)

    def test_seed_on_unsupported_model(
        self,
        fingerprinter: ProviderFingerprinter,
    ) -> None:
        warnings = fingerprinter.validate_request(
            "claude-4-opus",
            seed=42,
        )
        assert any("seed" in w for w in warnings)

    def test_streaming_on_unsupported_model(
        self,
        fingerprinter: ProviderFingerprinter,
        custom_fingerprint: ModelFingerprint,
    ) -> None:
        # Register a model that does NOT support streaming
        no_stream = ModelFingerprint(
            model_id="no-stream-model",
            provider="test",
            max_context_window=4096,
            max_output_tokens=1024,
            capabilities=frozenset(),
        )
        fingerprinter.register(no_stream)
        warnings = fingerprinter.validate_request("no-stream-model", stream=True)
        assert any("streaming" in w for w in warnings)

    def test_max_tokens_exceeds_limit(self, fingerprinter: ProviderFingerprinter) -> None:
        warnings = fingerprinter.validate_request(
            "claude-3.5-haiku",
            max_tokens=999_999,
        )
        assert any("max_tokens" in w for w in warnings)

    def test_max_tokens_within_limit(self, fingerprinter: ProviderFingerprinter) -> None:
        warnings = fingerprinter.validate_request(
            "gpt-4o",
            max_tokens=4096,
        )
        assert warnings == []

    def test_multiple_warnings(self, fingerprinter: ProviderFingerprinter) -> None:
        """A single request can trigger multiple warnings."""
        warnings = fingerprinter.validate_request(
            "ollama/local",
            tools=[{"type": "function"}],
            logprobs=True,
            seed=42,
            response_format={"type": "json_object"},
        )
        assert len(warnings) >= 3


# ======================================================================
# ProviderFingerprinter — get_provider_summary
# ======================================================================

class TestGetProviderSummary:
    """Tests for get_provider_summary."""

    def test_summary_has_all_providers(self, fingerprinter: ProviderFingerprinter) -> None:
        summary = fingerprinter.get_provider_summary()
        expected = {"openai", "anthropic", "google", "deepseek", "groq", "mistral", "ollama"}
        assert expected.issubset(set(summary.keys()))

    def test_summary_model_count(self, fingerprinter: ProviderFingerprinter) -> None:
        summary = fingerprinter.get_provider_summary()
        assert summary["openai"]["model_count"] >= 4
        assert summary["anthropic"]["model_count"] >= 3

    def test_summary_cost_range(self, fingerprinter: ProviderFingerprinter) -> None:
        summary = fingerprinter.get_provider_summary()
        ollama_cost = summary["ollama"]["cost_range"]
        assert ollama_cost["min_per_1k_input"] == 0.0
        assert ollama_cost["max_per_1k_input"] == 0.0

    def test_summary_capabilities_are_sorted(self, fingerprinter: ProviderFingerprinter) -> None:
        summary = fingerprinter.get_provider_summary()
        for prov_data in summary.values():
            caps = prov_data["capabilities"]
            assert caps == sorted(caps)

    def test_summary_models_are_sorted(self, fingerprinter: ProviderFingerprinter) -> None:
        summary = fingerprinter.get_provider_summary()
        for prov_data in summary.values():
            models = prov_data["models"]
            assert models == sorted(models)


# ======================================================================
# ProviderFingerprinter — introspection helpers
# ======================================================================

class TestIntrospection:
    """Tests for model_ids, providers, len, contains."""

    def test_model_ids_sorted(self, fingerprinter: ProviderFingerprinter) -> None:
        ids = fingerprinter.model_ids
        assert ids == sorted(ids)

    def test_providers_sorted(self, fingerprinter: ProviderFingerprinter) -> None:
        provs = fingerprinter.providers
        assert provs == sorted(provs)

    def test_len_matches_model_ids(self, fingerprinter: ProviderFingerprinter) -> None:
        assert len(fingerprinter) == len(fingerprinter.model_ids)


# ======================================================================
# Built-in model data integrity
# ======================================================================

class TestBuiltinDataIntegrity:
    """Verify consistency of the pre-populated model data."""

    def test_all_models_have_positive_context(self, fingerprinter: ProviderFingerprinter) -> None:
        for mid in fingerprinter.model_ids:
            fp = fingerprinter.get_fingerprint(mid)
            assert fp is not None
            assert fp.max_context_window > 0, f"{mid} has zero context window"

    def test_all_models_have_positive_max_output(
        self, fingerprinter: ProviderFingerprinter,
    ) -> None:
        for mid in fingerprinter.model_ids:
            fp = fingerprinter.get_fingerprint(mid)
            assert fp is not None
            assert fp.max_output_tokens > 0, f"{mid} has zero max output"

    def test_output_does_not_exceed_context(
        self, fingerprinter: ProviderFingerprinter,
    ) -> None:
        for mid in fingerprinter.model_ids:
            fp = fingerprinter.get_fingerprint(mid)
            assert fp is not None
            assert fp.max_output_tokens <= fp.max_context_window, (
                f"{mid}: max_output ({fp.max_output_tokens}) > context ({fp.max_context_window})"
            )

    def test_no_negative_costs(self, fingerprinter: ProviderFingerprinter) -> None:
        for mid in fingerprinter.model_ids:
            fp = fingerprinter.get_fingerprint(mid)
            assert fp is not None
            assert fp.cost_per_1k_input >= 0.0, f"{mid} has negative input cost"
            assert fp.cost_per_1k_output >= 0.0, f"{mid} has negative output cost"

    def test_no_negative_latency(self, fingerprinter: ProviderFingerprinter) -> None:
        for mid in fingerprinter.model_ids:
            fp = fingerprinter.get_fingerprint(mid)
            assert fp is not None
            assert fp.typical_latency_ms >= 0.0, f"{mid} has negative latency"

    def test_every_model_has_at_least_streaming(
        self, fingerprinter: ProviderFingerprinter,
    ) -> None:
        """All models in the built-in registry support streaming."""
        for mid in fingerprinter.model_ids:
            fp = fingerprinter.get_fingerprint(mid)
            assert fp is not None
            assert ProviderCapability.STREAMING in fp.capabilities, (
                f"{mid} is missing STREAMING"
            )

    def test_every_model_has_provider(self, fingerprinter: ProviderFingerprinter) -> None:
        for mid in fingerprinter.model_ids:
            fp = fingerprinter.get_fingerprint(mid)
            assert fp is not None
            assert fp.provider, f"{mid} has empty provider"
