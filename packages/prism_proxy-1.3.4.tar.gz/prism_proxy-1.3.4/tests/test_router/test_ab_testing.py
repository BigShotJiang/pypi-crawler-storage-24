"""Tests for the A/B testing framework."""

from __future__ import annotations

import pytest

from prism.router.ab_testing import (
    ABTestingEngine,
    ExperimentReport,
    ExperimentStatus,
    MetricComparison,
    OutcomeRecord,
    Variant,
    _cohens_d,
    _mann_whitney_u,
    _mean,
    _normal_cdf,
    _std,
    _variance,
)


# ---------------------------------------------------------------------------
# Statistical helper tests
# ---------------------------------------------------------------------------


class TestStatHelpers:
    """Tests for statistical utility functions."""

    def test_mean_basic(self) -> None:
        assert _mean([1.0, 2.0, 3.0]) == 2.0

    def test_mean_empty(self) -> None:
        assert _mean([]) == 0.0

    def test_mean_single(self) -> None:
        assert _mean([5.0]) == 5.0

    def test_variance_basic(self) -> None:
        v = _variance([2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0])
        assert abs(v - 4.571) < 0.01

    def test_variance_empty(self) -> None:
        assert _variance([]) == 0.0

    def test_variance_single(self) -> None:
        assert _variance([5.0]) == 0.0

    def test_std_basic(self) -> None:
        s = _std([2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0])
        assert abs(s - 2.138) < 0.01

    def test_normal_cdf_zero(self) -> None:
        assert abs(_normal_cdf(0) - 0.5) < 0.001

    def test_normal_cdf_large_positive(self) -> None:
        assert _normal_cdf(5.0) > 0.999

    def test_normal_cdf_large_negative(self) -> None:
        assert _normal_cdf(-5.0) < 0.001

    def test_mann_whitney_identical(self) -> None:
        a = [1.0, 2.0, 3.0, 4.0, 5.0]
        b = [1.0, 2.0, 3.0, 4.0, 5.0]
        _, p = _mann_whitney_u(a, b)
        assert p > 0.05  # Not significant

    def test_mann_whitney_different(self) -> None:
        a = [1.0, 2.0, 3.0, 4.0, 5.0] * 10
        b = [10.0, 11.0, 12.0, 13.0, 14.0] * 10
        _, p = _mann_whitney_u(a, b)
        assert p < 0.05  # Significant

    def test_mann_whitney_empty(self) -> None:
        u, p = _mann_whitney_u([], [1.0, 2.0])
        assert u == 0.0
        assert p == 1.0

    def test_cohens_d_no_difference(self) -> None:
        a = [5.0, 5.0, 5.0, 5.0, 5.0]
        b = [5.0, 5.0, 5.0, 5.0, 5.0]
        assert _cohens_d(a, b) == 0.0

    def test_cohens_d_large_effect(self) -> None:
        a = [10.0, 11.0, 12.0, 10.0, 11.0]
        b = [1.0, 2.0, 3.0, 1.0, 2.0]
        d = _cohens_d(a, b)
        assert d > 2.0  # Very large effect

    def test_cohens_d_insufficient_data(self) -> None:
        assert _cohens_d([1.0], [2.0]) == 0.0


# ---------------------------------------------------------------------------
# Experiment lifecycle tests
# ---------------------------------------------------------------------------


class TestExperimentLifecycle:
    """Tests for experiment creation, state transitions, and management."""

    def setup_method(self) -> None:
        self.engine = ABTestingEngine()

    def test_create_experiment(self) -> None:
        exp = self.engine.create_experiment(
            "test_exp",
            {"control": {"model": "gpt-4o"}, "treatment": {"model": "claude-sonnet"}},
        )
        assert exp.name == "test_exp"
        assert len(exp.variants) == 2
        assert exp.status == ExperimentStatus.DRAFT

    def test_create_duplicate_raises(self) -> None:
        self.engine.create_experiment("dup", {"a": {}, "b": {}})
        with pytest.raises(ValueError, match="already exists"):
            self.engine.create_experiment("dup", {"a": {}, "b": {}})

    def test_create_single_variant_raises(self) -> None:
        with pytest.raises(ValueError, match="at least 2"):
            self.engine.create_experiment("bad", {"only_one": {}})

    def test_start_experiment(self) -> None:
        self.engine.create_experiment("exp", {"a": {}, "b": {}})
        self.engine.start_experiment("exp")
        exp = self.engine.get_experiment("exp")
        assert exp is not None
        assert exp.status == ExperimentStatus.RUNNING

    def test_start_concluded_raises(self) -> None:
        self.engine.create_experiment("exp", {"a": {}, "b": {}})
        self.engine.start_experiment("exp")
        self.engine.conclude_experiment("exp")
        with pytest.raises(ValueError, match="Cannot start"):
            self.engine.start_experiment("exp")

    def test_pause_experiment(self) -> None:
        self.engine.create_experiment("exp", {"a": {}, "b": {}})
        self.engine.start_experiment("exp")
        self.engine.pause_experiment("exp")
        exp = self.engine.get_experiment("exp")
        assert exp is not None
        assert exp.status == ExperimentStatus.PAUSED

    def test_resume_after_pause(self) -> None:
        self.engine.create_experiment("exp", {"a": {}, "b": {}})
        self.engine.start_experiment("exp")
        self.engine.pause_experiment("exp")
        self.engine.start_experiment("exp")
        exp = self.engine.get_experiment("exp")
        assert exp is not None
        assert exp.status == ExperimentStatus.RUNNING

    def test_conclude_experiment(self) -> None:
        self.engine.create_experiment("exp", {"a": {}, "b": {}})
        self.engine.start_experiment("exp")
        self.engine.conclude_experiment("exp", winner="a")
        exp = self.engine.get_experiment("exp")
        assert exp is not None
        assert exp.status == ExperimentStatus.CONCLUDED
        assert exp.winner == "a"

    def test_delete_experiment(self) -> None:
        self.engine.create_experiment("exp", {"a": {}, "b": {}})
        self.engine.delete_experiment("exp")
        assert self.engine.get_experiment("exp") is None

    def test_delete_nonexistent_is_noop(self) -> None:
        self.engine.delete_experiment("nope")  # Should not raise

    def test_list_experiments(self) -> None:
        self.engine.create_experiment("exp1", {"a": {}, "b": {}})
        self.engine.create_experiment("exp2", {"c": {}, "d": {}})
        listing = self.engine.list_experiments()
        assert len(listing) == 2
        names = {e["name"] for e in listing}
        assert "exp1" in names
        assert "exp2" in names

    def test_get_nonexistent_returns_none(self) -> None:
        assert self.engine.get_experiment("nope") is None


# ---------------------------------------------------------------------------
# Assignment tests
# ---------------------------------------------------------------------------


class TestAssignment:
    """Tests for deterministic variant assignment."""

    def setup_method(self) -> None:
        self.engine = ABTestingEngine()
        self.engine.create_experiment(
            "exp",
            {"control": {"model": "gpt-4o"}, "treatment": {"model": "claude"}},
        )
        self.engine.start_experiment("exp")

    def test_assign_returns_variant(self) -> None:
        variant = self.engine.assign("exp", "user1")
        assert isinstance(variant, Variant)
        assert variant.name in ("control", "treatment")

    def test_consistent_assignment(self) -> None:
        """Same user always gets the same variant."""
        v1 = self.engine.assign("exp", "user42")
        v2 = self.engine.assign("exp", "user42")
        v3 = self.engine.assign("exp", "user42")
        assert v1.name == v2.name == v3.name

    def test_different_users_may_differ(self) -> None:
        """With enough users, both variants should be assigned."""
        variants_seen = set()
        for i in range(100):
            v = self.engine.assign("exp", f"user_{i}")
            variants_seen.add(v.name)
        assert len(variants_seen) == 2

    def test_assign_not_running_raises(self) -> None:
        self.engine.create_experiment("draft_exp", {"a": {}, "b": {}})
        with pytest.raises(ValueError, match="not running"):
            self.engine.assign("draft_exp", "user1")

    def test_custom_weights(self) -> None:
        """Heavy weighting should skew assignment."""
        self.engine.create_experiment(
            "weighted",
            {"control": {}, "treatment": {}},
            weights={"control": 0.9, "treatment": 0.1},
        )
        self.engine.start_experiment("weighted")

        counts: dict[str, int] = {"control": 0, "treatment": 0}
        for i in range(200):
            v = self.engine.assign("weighted", f"user_{i}")
            counts[v.name] += 1

        # Control should get significantly more
        assert counts["control"] > counts["treatment"]


# ---------------------------------------------------------------------------
# Outcome recording tests
# ---------------------------------------------------------------------------


class TestOutcomes:
    """Tests for recording and tracking outcomes."""

    def setup_method(self) -> None:
        self.engine = ABTestingEngine()
        self.engine.create_experiment("exp", {"control": {}, "treatment": {}})
        self.engine.start_experiment("exp")

    def test_record_outcome(self) -> None:
        record = self.engine.record_outcome(
            "exp", "user1", {"latency_ms": 200.0, "cost_usd": 0.001},
        )
        assert isinstance(record, OutcomeRecord)
        assert record.user_id == "user1"
        assert record.metrics["latency_ms"] == 200.0

    def test_outcomes_accumulated(self) -> None:
        for i in range(10):
            self.engine.record_outcome("exp", f"user_{i}", {"latency_ms": float(i * 100)})
        exp = self.engine.get_experiment("exp")
        assert exp is not None
        assert len(exp.outcomes) == 10

    def test_nonexistent_experiment_raises(self) -> None:
        with pytest.raises(KeyError):
            self.engine.record_outcome("nope", "user1", {"x": 1.0})


# ---------------------------------------------------------------------------
# Reporting tests
# ---------------------------------------------------------------------------


class TestReporting:
    """Tests for experiment reporting and statistical analysis."""

    def setup_method(self) -> None:
        self.engine = ABTestingEngine()
        self.engine.create_experiment(
            "exp",
            {"control": {"model": "gpt-4o"}, "treatment": {"model": "claude"}},
            min_samples=5,
        )
        self.engine.start_experiment("exp")

    def _add_outcomes(
        self, n: int, control_latency: float, treatment_latency: float,
    ) -> None:
        """Add n outcomes for each variant with specified mean latencies."""
        import random
        rng = random.Random(42)
        for i in range(n * 2):
            user_id = f"user_{i}"
            variant = self.engine.assign("exp", user_id)
            if variant.name == "control":
                lat = control_latency + rng.gauss(0, 10)
            else:
                lat = treatment_latency + rng.gauss(0, 10)
            self.engine.record_outcome("exp", user_id, {
                "latency_ms": lat,
                "quality_score": 0.8 + rng.gauss(0, 0.05),
            })

    def test_report_structure(self) -> None:
        self._add_outcomes(20, 500.0, 300.0)
        report = self.engine.get_report("exp")
        assert isinstance(report, ExperimentReport)
        assert report.experiment_name == "exp"
        assert report.total_samples > 0

    def test_report_variant_stats(self) -> None:
        self._add_outcomes(20, 500.0, 300.0)
        report = self.engine.get_report("exp")
        for vname in ("control", "treatment"):
            assert vname in report.variant_stats
            stats = report.variant_stats[vname]
            assert stats.sample_count > 0

    def test_report_comparisons(self) -> None:
        self._add_outcomes(50, 500.0, 200.0)
        report = self.engine.get_report("exp")
        assert len(report.comparisons) > 0
        lat_comp = next(
            (c for c in report.comparisons if c.metric_name == "latency_ms"), None,
        )
        assert lat_comp is not None
        assert isinstance(lat_comp, MetricComparison)

    def test_significant_difference_detected(self) -> None:
        """Large difference should be statistically significant."""
        self._add_outcomes(50, 1000.0, 100.0)
        report = self.engine.get_report("exp")
        lat_comp = next(
            (c for c in report.comparisons if c.metric_name == "latency_ms"), None,
        )
        assert lat_comp is not None
        assert lat_comp.is_significant

    def test_can_conclude_with_enough_data(self) -> None:
        self._add_outcomes(50, 1000.0, 100.0)
        report = self.engine.get_report("exp")
        assert report.can_conclude

    def test_cannot_conclude_insufficient_data(self) -> None:
        self._add_outcomes(2, 500.0, 300.0)
        report = self.engine.get_report("exp")
        assert not report.can_conclude

    def test_empty_report(self) -> None:
        report = self.engine.get_report("exp")
        assert report.total_samples == 0
        assert "Insufficient" in report.recommendation

    def test_recommendation_text(self) -> None:
        self._add_outcomes(50, 1000.0, 100.0)
        report = self.engine.get_report("exp")
        assert isinstance(report.recommendation, str)
        assert len(report.recommendation) > 0

    def test_lower_is_better_direction(self) -> None:
        self._add_outcomes(50, 1000.0, 100.0)
        report = self.engine.get_report("exp")
        lat_comp = next(
            (c for c in report.comparisons if c.metric_name == "latency_ms"), None,
        )
        assert lat_comp is not None
        assert lat_comp.direction == "lower_is_better"

    def test_higher_is_better_direction(self) -> None:
        self._add_outcomes(50, 1000.0, 100.0)
        report = self.engine.get_report("exp")
        qual_comp = next(
            (c for c in report.comparisons if c.metric_name == "quality_score"), None,
        )
        assert qual_comp is not None
        assert qual_comp.direction == "higher_is_better"
