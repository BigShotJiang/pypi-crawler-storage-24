"""Tests for prism.router.fallback_chain — intelligent multi-tier fallback engine."""

from __future__ import annotations

import calendar
import time
from typing import Any

import pytest

from prism.router.fallback_chain import (
    ChainValidationError,
    FailureReason,
    FallbackChainDef,
    FallbackConfig,
    FallbackEngine,
    FallbackTier,
    ProviderHealth,
    validate_chain,
)

# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _tier(
    model: str = "anthropic/claude-sonnet",
    provider: str = "anthropic",
    max_retries: int = 1,
    timeout_ms: int = 10_000,
    cost_per_1k: float = 0.003,
    *,
    off_peak_only: bool = False,
) -> FallbackTier:
    """Build a FallbackTier for testing."""
    return FallbackTier(
        model=model,
        provider=provider,
        max_retries=max_retries,
        timeout_ms=timeout_ms,
        cost_per_1k=cost_per_1k,
        off_peak_only=off_peak_only,
    )


def _chain(*tiers: FallbackTier, name: str = "test") -> FallbackChainDef:
    """Build a FallbackChainDef for testing."""
    return FallbackChainDef(tiers=list(tiers), name=name)


def _success_fn(response: str = "ok") -> Any:
    """Return a request_fn that always succeeds."""

    def fn(model: str, timeout_ms: int) -> str:
        return response

    return fn


def _fail_fn(exc: Exception | None = None) -> Any:
    """Return a request_fn that always raises."""
    error = exc or RuntimeError("provider down")

    def fn(model: str, timeout_ms: int) -> str:
        raise error

    return fn


def _fail_then_succeed(fail_count: int, response: str = "ok") -> Any:
    """Return a request_fn that fails N times then succeeds."""
    call_count = {"n": 0}

    def fn(model: str, timeout_ms: int) -> str:
        call_count["n"] += 1
        if call_count["n"] <= fail_count:
            raise RuntimeError("transient error")
        return response

    return fn


def _selective_fn(
    fail_models: set[str],
    response: str = "ok",
    exc: Exception | None = None,
) -> Any:
    """Return a request_fn that fails for specific models and succeeds for others."""
    error = exc or RuntimeError("model unavailable")

    def fn(model: str, timeout_ms: int) -> str:
        if model in fail_models:
            raise error
        return response

    return fn


def _tracking_fn(calls: list[tuple[str, int]], response: str = "ok") -> Any:
    """Return a request_fn that records calls and succeeds."""

    def fn(model: str, timeout_ms: int) -> str:
        calls.append((model, timeout_ms))
        return response

    return fn


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------


@pytest.fixture
def config() -> FallbackConfig:
    return FallbackConfig()


@pytest.fixture
def engine(config: FallbackConfig) -> FallbackEngine:
    return FallbackEngine(config)


@pytest.fixture
def three_tier_chain() -> FallbackChainDef:
    """Three-tier chain with identical cost so order is stable (no cost reordering)."""
    return _chain(
        _tier("anthropic/claude-sonnet", "anthropic", cost_per_1k=0.003),
        _tier("openai/gpt-4o", "openai", cost_per_1k=0.003),
        _tier("deepseek/deepseek-chat", "deepseek", cost_per_1k=0.003),
    )


# ------------------------------------------------------------------
# 1. Basic chain traversal
# ------------------------------------------------------------------


class TestBasicChainTraversal:
    """Test that the engine traverses tiers in order."""

    def test_first_tier_success(self, engine: FallbackEngine, three_tier_chain: FallbackChainDef) -> None:
        engine.register_chain("code", three_tier_chain)
        result = engine.execute("code", request_fn=_success_fn("response"))
        assert result.success
        assert result.model_used == "anthropic/claude-sonnet"
        assert result.attempts == 1
        assert len(result.fallback_events) == 0

    def test_falls_to_second_tier(self, engine: FallbackEngine, three_tier_chain: FallbackChainDef) -> None:
        engine.register_chain("code", three_tier_chain)
        result = engine.execute(
            "code",
            request_fn=_selective_fn({"anthropic/claude-sonnet"}, response="from-gpt"),
        )
        assert result.success
        assert result.model_used == "openai/gpt-4o"
        assert result.attempts > 1

    def test_falls_to_last_tier(self, engine: FallbackEngine, three_tier_chain: FallbackChainDef) -> None:
        engine.register_chain("code", three_tier_chain)
        result = engine.execute(
            "code",
            request_fn=_selective_fn(
                {"anthropic/claude-sonnet", "openai/gpt-4o"},
                response="from-deepseek",
            ),
        )
        assert result.success
        assert result.model_used == "deepseek/deepseek-chat"

    def test_all_tiers_fail(self, engine: FallbackEngine, three_tier_chain: FallbackChainDef) -> None:
        engine.register_chain("code", three_tier_chain)
        result = engine.execute("code", request_fn=_fail_fn())
        assert not result.success
        assert result.model_used == ""
        assert result.response is None
        assert result.attempts > 0

    def test_unregistered_chain_returns_failure(self, engine: FallbackEngine) -> None:
        result = engine.execute("nonexistent", request_fn=_success_fn())
        assert not result.success
        assert result.attempts == 0


# ------------------------------------------------------------------
# 2. Fallback on timeout
# ------------------------------------------------------------------


class TestTimeoutFallback:
    """Test fallback triggered by timeout errors."""

    def test_timeout_triggers_fallback(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("chat", chain)
        result = engine.execute(
            "chat",
            request_fn=_selective_fn(
                {"model-a"}, exc=TimeoutError("request timed out"),
            ),
        )
        assert result.success
        assert result.model_used == "model-b"
        assert len(result.fallback_events) == 1
        assert result.fallback_events[0].reason == FailureReason.TIMEOUT


# ------------------------------------------------------------------
# 3. Fallback on rate limit
# ------------------------------------------------------------------


class TestRateLimitFallback:
    """Test fallback triggered by rate limit errors."""

    def test_rate_limit_triggers_fallback(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("chat", chain)
        result = engine.execute(
            "chat",
            request_fn=_selective_fn(
                {"model-a"}, exc=RuntimeError("429 Too Many Requests"),
            ),
        )
        assert result.success
        assert result.model_used == "model-b"
        assert result.fallback_events[0].reason == FailureReason.RATE_LIMIT

    def test_rate_limit_class_name_detection(self, engine: FallbackEngine) -> None:
        class RateLimitError(Exception):
            pass

        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("chat", chain)
        result = engine.execute(
            "chat",
            request_fn=_selective_fn({"model-a"}, exc=RateLimitError("slow down")),
        )
        assert result.fallback_events[0].reason == FailureReason.RATE_LIMIT


# ------------------------------------------------------------------
# 4. Fallback on provider error (5xx)
# ------------------------------------------------------------------


class TestProviderErrorFallback:
    """Test fallback triggered by server/provider errors."""

    def test_500_error_triggers_fallback(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        result = engine.execute(
            "code",
            request_fn=_selective_fn(
                {"model-a"}, exc=RuntimeError("500 Internal Server Error"),
            ),
        )
        assert result.success
        assert result.fallback_events[0].reason == FailureReason.SERVER_ERROR

    def test_503_error_triggers_fallback(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        result = engine.execute(
            "code",
            request_fn=_selective_fn(
                {"model-a"}, exc=RuntimeError("503 Service Unavailable"),
            ),
        )
        assert result.fallback_events[0].reason == FailureReason.SERVER_ERROR


# ------------------------------------------------------------------
# 5. Health-based reordering
# ------------------------------------------------------------------


class TestHealthBasedReordering:
    """Test that unhealthy providers are deprioritised in ordering."""

    def test_unhealthy_provider_deprioritised(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", cost_per_1k=0.003),
            _tier("model-b", "prov-b", cost_per_1k=0.003),
        )
        engine.register_chain("code", chain)

        # Degrade prov-a health
        health = engine.get_provider_health("prov-a")
        assert health is not None
        for _ in range(10):
            health.record_failure("error", 1000.0)

        # prov-b should now rank first
        order = engine.get_effective_order("code")
        assert order[0] == "model-b"

    def test_healthy_provider_preferred(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", cost_per_1k=0.003),
            _tier("model-b", "prov-b", cost_per_1k=0.003),
        )
        engine.register_chain("code", chain)

        # Make both have history, but prov-b with some failures
        health_a = engine.get_provider_health("prov-a")
        health_b = engine.get_provider_health("prov-b")
        assert health_a is not None
        assert health_b is not None
        for _ in range(10):
            health_a.record_success(200.0)
        for _ in range(10):
            health_b.record_success(200.0)
        for _ in range(5):
            health_b.record_failure("err", 500.0)

        order = engine.get_effective_order("code")
        assert order[0] == "model-a"


# ------------------------------------------------------------------
# 6. Provider exclusion and readmission
# ------------------------------------------------------------------


class TestProviderExclusion:
    """Test provider exclusion and automatic readmission."""

    def test_manual_exclusion(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a"),
            _tier("model-b", "prov-b"),
        )
        engine.register_chain("code", chain)
        engine.exclude_provider("prov-a")

        order = engine.get_effective_order("code")
        assert "model-a" not in order
        assert "model-b" in order

    def test_manual_readmission(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a"),
            _tier("model-b", "prov-b"),
        )
        engine.register_chain("code", chain)
        engine.exclude_provider("prov-a")
        engine.readmit_provider("prov-a")

        order = engine.get_effective_order("code")
        assert "model-a" in order

    def test_auto_exclusion_on_low_success_rate(self) -> None:
        config = FallbackConfig(exclusion_threshold=0.3)
        engine = FallbackEngine(config)
        # Single-tier chain so model-a is always attempted
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
        )
        engine.register_chain("code", chain)

        # Fail model-a repeatedly to trigger auto-exclusion
        # Need >= 5 observations with success_rate < 0.3
        for _ in range(6):
            engine.execute("code", request_fn=_fail_fn())

        health = engine.get_provider_health("prov-a")
        assert health is not None
        assert health.is_excluded

    def test_auto_readmission_after_timer(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a"),
            _tier("model-b", "prov-b"),
        )
        engine.register_chain("code", chain)
        engine.exclude_provider("prov-a", duration_s=60.0)

        # Should be excluded now
        order = engine.get_effective_order("code", now=time.time())
        assert "model-a" not in order

        # Should be readmitted after the timer
        order = engine.get_effective_order("code", now=time.time() + 120)
        assert "model-a" in order


# ------------------------------------------------------------------
# 7. Cost-aware selection
# ------------------------------------------------------------------


class TestCostAwareSelection:
    """Test that cheaper models are preferred when health is comparable."""

    def test_cheaper_model_preferred(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("expensive-model", "prov-a", cost_per_1k=0.01),
            _tier("cheap-model", "prov-b", cost_per_1k=0.0001),
        )
        engine.register_chain("chat", chain)

        order = engine.get_effective_order("chat")
        # Cheaper model should be first (both providers equally healthy)
        assert order[0] == "cheap-model"

    def test_free_model_gets_top_score(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("paid-model", "prov-a", cost_per_1k=0.003),
            _tier("free-model", "prov-b", cost_per_1k=0.0),
        )
        engine.register_chain("chat", chain)

        order = engine.get_effective_order("chat")
        assert order[0] == "free-model"


# ------------------------------------------------------------------
# 8. Chain validation
# ------------------------------------------------------------------


class TestChainValidation:
    """Test chain validation logic."""

    def test_empty_chain_raises(self) -> None:
        with pytest.raises(ChainValidationError, match="no tiers"):
            validate_chain(FallbackChainDef(tiers=[]))

    def test_duplicate_model_raises(self) -> None:
        chain = _chain(
            _tier("model-a", "prov-a"),
            _tier("model-a", "prov-b"),  # duplicate model
        )
        with pytest.raises(ChainValidationError, match="Duplicate.*cycle"):
            validate_chain(chain)

    def test_all_off_peak_raises(self) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", off_peak_only=True),
            _tier("model-b", "prov-b", off_peak_only=True),
        )
        with pytest.raises(ChainValidationError, match="no terminal model"):
            validate_chain(chain)

    def test_negative_retries_raises(self) -> None:
        chain = _chain(
            FallbackTier(
                model="model-a", provider="prov-a", max_retries=-1, timeout_ms=1000,
            ),
        )
        with pytest.raises(ChainValidationError, match="max_retries cannot be negative"):
            validate_chain(chain)

    def test_zero_timeout_raises(self) -> None:
        chain = _chain(
            FallbackTier(
                model="model-a", provider="prov-a", max_retries=0, timeout_ms=0,
            ),
        )
        with pytest.raises(ChainValidationError, match="timeout_ms must be positive"):
            validate_chain(chain)

    def test_negative_cost_warns(self) -> None:
        chain = _chain(
            FallbackTier(
                model="model-a", provider="prov-a", max_retries=0,
                timeout_ms=1000, cost_per_1k=-0.5,
            ),
        )
        warnings = validate_chain(chain)
        assert any("negative cost_per_1k" in w for w in warnings)

    def test_valid_chain_passes(self) -> None:
        chain = _chain(
            _tier("model-a", "prov-a"),
            _tier("model-b", "prov-b"),
        )
        warnings = validate_chain(chain)
        assert len(warnings) == 0

    def test_register_with_validation_raises(self, engine: FallbackEngine) -> None:
        chain = FallbackChainDef(tiers=[])
        with pytest.raises(ChainValidationError):
            engine.register_chain("code", chain)

    def test_register_without_validation(self, engine: FallbackEngine) -> None:
        # Should not raise even with empty chain
        chain = FallbackChainDef(tiers=[])
        engine.register_chain("code", chain, validate=False)
        assert engine.get_chain("code") is not None


# ------------------------------------------------------------------
# 9. Empty chain behaviour
# ------------------------------------------------------------------


class TestEmptyChainBehavior:
    """Test edge cases with empty or minimal chains."""

    def test_single_tier_success(self, engine: FallbackEngine) -> None:
        chain = _chain(_tier("model-a", "prov-a"))
        engine.register_chain("code", chain)
        result = engine.execute("code", request_fn=_success_fn())
        assert result.success
        assert result.model_used == "model-a"

    def test_single_tier_failure(self, engine: FallbackEngine) -> None:
        chain = _chain(_tier("model-a", "prov-a", max_retries=0))
        engine.register_chain("code", chain)
        result = engine.execute("code", request_fn=_fail_fn())
        assert not result.success
        assert result.attempts == 1


# ------------------------------------------------------------------
# 10. Multiple simultaneous fallbacks (retry within tiers)
# ------------------------------------------------------------------


class TestRetryWithinTier:
    """Test retry logic within a single tier."""

    def test_retries_within_tier(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=3),
        )
        engine.register_chain("code", chain)
        result = engine.execute("code", request_fn=_fail_then_succeed(2))
        assert result.success
        assert result.attempts == 3  # 2 failures + 1 success

    def test_max_retries_respected(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=2),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        result = engine.execute(
            "code",
            request_fn=_selective_fn({"model-a"}, response="from-b"),
        )
        assert result.success
        assert result.model_used == "model-b"
        # model-a: 1 initial + 2 retries = 3 attempts, then model-b: 1 = 4 total
        assert result.attempts == 4


# ------------------------------------------------------------------
# 11. Latency tracking accuracy
# ------------------------------------------------------------------


class TestLatencyTracking:
    """Test EWMA latency tracking in ProviderHealth."""

    def test_initial_latency_set(self) -> None:
        health = ProviderHealth(provider="test")
        health.record_success(500.0)
        assert health.avg_latency_ms == 500.0

    def test_ewma_smoothing(self) -> None:
        health = ProviderHealth(provider="test")
        health.record_success(1000.0, ewma_alpha=0.5)
        assert health.avg_latency_ms == 1000.0
        health.record_success(500.0, ewma_alpha=0.5)
        # EWMA: 0.5 * 500 + 0.5 * 1000 = 750
        assert health.avg_latency_ms == pytest.approx(750.0)

    def test_ewma_converges(self) -> None:
        health = ProviderHealth(provider="test")
        health.record_success(1000.0, ewma_alpha=0.3)
        for _ in range(50):
            health.record_success(200.0, ewma_alpha=0.3)
        # After many observations at 200, EWMA should converge near 200
        assert health.avg_latency_ms == pytest.approx(200.0, abs=5.0)

    def test_failure_also_updates_latency(self) -> None:
        health = ProviderHealth(provider="test")
        health.record_failure("err", 2000.0, ewma_alpha=0.5)
        assert health.avg_latency_ms == 2000.0


# ------------------------------------------------------------------
# 12. Event logging completeness
# ------------------------------------------------------------------


class TestEventLogging:
    """Test that fallback events are fully logged."""

    def test_events_recorded_on_fallback(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        result = engine.execute(
            "code",
            request_fn=_selective_fn({"model-a"}),
        )
        assert result.success
        assert len(result.fallback_events) == 1
        event = result.fallback_events[0]
        assert event.to_model == "model-a"
        assert event.attempt == 1
        assert event.latency_ms >= 0
        assert event.timestamp > 0

    def test_no_events_on_first_success(self, engine: FallbackEngine) -> None:
        chain = _chain(_tier("model-a", "prov-a"))
        engine.register_chain("code", chain)
        result = engine.execute("code", request_fn=_success_fn())
        assert len(result.fallback_events) == 0

    def test_global_event_log(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        engine.execute("code", request_fn=_selective_fn({"model-a"}))

        log = engine.get_event_log()
        assert len(log) == 1

    def test_event_log_accumulates(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        engine.execute("code", request_fn=_selective_fn({"model-a"}))
        engine.execute("code", request_fn=_selective_fn({"model-a"}))

        log = engine.get_event_log()
        # At least 1 fallback event; the engine may skip model-a on second call
        assert len(log) >= 1

    def test_clear_event_log(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        engine.execute("code", request_fn=_selective_fn({"model-a"}))
        engine.clear_event_log()
        assert len(engine.get_event_log()) == 0

    def test_error_message_in_event(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("model-a", "prov-a", max_retries=0),
            _tier("model-b", "prov-b", max_retries=0),
        )
        engine.register_chain("code", chain)
        result = engine.execute(
            "code",
            request_fn=_selective_fn(
                {"model-a"}, exc=RuntimeError("detailed error message"),
            ),
        )
        assert "detailed error message" in result.fallback_events[0].error_message


# ------------------------------------------------------------------
# 13. Error classification
# ------------------------------------------------------------------


class TestErrorClassification:
    """Test that exceptions are correctly classified."""

    def test_classify_timeout(self) -> None:
        reason = FallbackEngine._classify_error(TimeoutError("timed out"))
        assert reason == FailureReason.TIMEOUT

    def test_classify_rate_limit_429(self) -> None:
        reason = FallbackEngine._classify_error(RuntimeError("429 Too Many Requests"))
        assert reason == FailureReason.RATE_LIMIT

    def test_classify_server_error_500(self) -> None:
        reason = FallbackEngine._classify_error(RuntimeError("500 Internal Server Error"))
        assert reason == FailureReason.SERVER_ERROR

    def test_classify_auth_error_401(self) -> None:
        reason = FallbackEngine._classify_error(RuntimeError("401 Unauthorized"))
        assert reason == FailureReason.AUTH_ERROR

    def test_classify_unavailable(self) -> None:
        reason = FallbackEngine._classify_error(
            RuntimeError("Service unavailable, try again later"),
        )
        assert reason == FailureReason.PROVIDER_UNAVAILABLE

    def test_classify_unknown(self) -> None:
        reason = FallbackEngine._classify_error(ValueError("something weird"))
        assert reason == FailureReason.UNKNOWN


# ------------------------------------------------------------------
# 14. Time-of-day scheduling
# ------------------------------------------------------------------


class TestTimeOfDay:
    """Test off-peak scheduling logic."""

    def test_off_peak_only_tier_excluded_during_peak(self) -> None:
        config = FallbackConfig(enable_time_of_day=True, off_peak_start_utc=2, off_peak_end_utc=8)
        engine = FallbackEngine(config)
        chain = _chain(
            _tier("cheap-model", "prov-a", cost_per_1k=0.0001, off_peak_only=True),
            _tier("always-model", "prov-b", cost_per_1k=0.003),
        )
        engine.register_chain("chat", chain)

        # Simulate peak hour (12:00 UTC) — Jan 1 2025 12:00 UTC
        peak_time = calendar.timegm(time.strptime("2025-01-01 12:00:00", "%Y-%m-%d %H:%M:%S"))
        order = engine.get_effective_order("chat", now=peak_time)
        assert "cheap-model" not in order
        assert "always-model" in order

    def test_off_peak_only_tier_included_during_off_peak(self) -> None:
        config = FallbackConfig(enable_time_of_day=True, off_peak_start_utc=2, off_peak_end_utc=8)
        engine = FallbackEngine(config)
        chain = _chain(
            _tier("cheap-model", "prov-a", cost_per_1k=0.0001, off_peak_only=True),
            _tier("always-model", "prov-b", cost_per_1k=0.003),
        )
        engine.register_chain("chat", chain)

        # Simulate off-peak hour (04:00 UTC) — Jan 1 2025 04:00 UTC
        off_peak_time = calendar.timegm(time.strptime("2025-01-01 04:00:00", "%Y-%m-%d %H:%M:%S"))
        order = engine.get_effective_order("chat", now=off_peak_time)
        assert "cheap-model" in order


# ------------------------------------------------------------------
# 15. ProviderHealth unit tests
# ------------------------------------------------------------------


class TestProviderHealth:
    """Test ProviderHealth data class behaviour."""

    def test_initial_state(self) -> None:
        health = ProviderHealth(provider="test")
        assert health.success_rate == 1.0
        assert health.avg_latency_ms == 0.0
        assert not health.is_excluded
        assert health.successes == 0
        assert health.failures == 0

    def test_success_rate_calculation(self) -> None:
        health = ProviderHealth(provider="test")
        for _ in range(8):
            health.record_success(100.0)
        for _ in range(2):
            health.record_failure("err", 100.0)
        assert health.success_rate == pytest.approx(0.8)

    def test_error_message_truncation(self) -> None:
        health = ProviderHealth(provider="test")
        long_msg = "x" * 1000
        health.record_failure(long_msg, 100.0)
        assert len(health.last_error) == 500


# ------------------------------------------------------------------
# 16. FallbackResult structure
# ------------------------------------------------------------------


class TestFallbackResult:
    """Test FallbackResult immutability and content."""

    def test_total_latency_tracked(self, engine: FallbackEngine) -> None:
        chain = _chain(_tier("model-a", "prov-a"))
        engine.register_chain("code", chain)
        result = engine.execute("code", request_fn=_success_fn())
        assert result.total_latency_ms >= 0

    def test_response_passthrough(self, engine: FallbackEngine) -> None:
        chain = _chain(_tier("model-a", "prov-a"))
        engine.register_chain("code", chain)
        result = engine.execute("code", request_fn=_success_fn("my-response"))
        assert result.response == "my-response"


# ------------------------------------------------------------------
# 17. Engine utility methods
# ------------------------------------------------------------------


class TestEngineUtilities:
    """Test list_chains, stats_summary, get/reset health."""

    def test_list_chains(self, engine: FallbackEngine) -> None:
        engine.register_chain("code", _chain(_tier("m-a", "p-a")))
        engine.register_chain("chat", _chain(_tier("m-b", "p-b")))
        chains = engine.list_chains()
        assert chains == ["chat", "code"]

    def test_stats_summary(self, engine: FallbackEngine) -> None:
        engine.register_chain("code", _chain(_tier("m-a", "p-a")))
        summary = engine.stats_summary()
        assert summary["chains"] == 1
        assert "p-a" in summary["providers"]
        assert summary["event_log_size"] == 0

    def test_reset_provider_health(self, engine: FallbackEngine) -> None:
        engine.register_chain("code", _chain(_tier("m-a", "p-a")))
        health = engine.get_provider_health("p-a")
        assert health is not None
        for _ in range(5):
            health.record_failure("err", 500.0)
        assert health.success_rate < 1.0

        engine.reset_provider_health("p-a")
        health = engine.get_provider_health("p-a")
        assert health is not None
        assert health.success_rate == 1.0
        assert health.failures == 0

    def test_get_all_health(self, engine: FallbackEngine, three_tier_chain: FallbackChainDef) -> None:
        engine.register_chain("code", three_tier_chain)
        all_health = engine.get_all_health()
        assert len(all_health) == 3
        assert "anthropic" in all_health
        assert "openai" in all_health
        assert "deepseek" in all_health


# ------------------------------------------------------------------
# 18. Call order tracking
# ------------------------------------------------------------------


class TestCallOrderTracking:
    """Verify models are called in the expected order with correct timeouts."""

    def test_models_called_in_order(self, engine: FallbackEngine) -> None:
        chain = _chain(
            _tier("m-1", "p-1", max_retries=0, timeout_ms=5000),
            _tier("m-2", "p-2", max_retries=0, timeout_ms=10000),
            _tier("m-3", "p-3", max_retries=0, timeout_ms=15000),
        )
        engine.register_chain("code", chain)

        calls: list[tuple[str, int]] = []
        engine.execute("code", request_fn=_tracking_fn(calls))
        # Only first model should be called on success
        assert len(calls) == 1
        assert calls[0][0] == "m-1"
        assert calls[0][1] == 5000
