"""Tests for prism.router.pareto — Pareto-optimal multi-objective routing."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from prism.router.pareto import (
    ModelScore,
    ObjectiveWeight,
    ParetoRouter,
    RoutingConstraint,
    _is_dominated,
    _normalize_cost,
    _normalize_latency,
    _normalize_quality,
)

# ---------------------------------------------------------------------------
# ObjectiveWeight tests
# ---------------------------------------------------------------------------


class TestObjectiveWeight:
    """Tests for ObjectiveWeight validation."""

    def test_default_weights(self) -> None:
        """Default weights sum to 1.0."""
        w = ObjectiveWeight()
        assert w.cost_weight == 0.4
        assert w.latency_weight == 0.3
        assert w.quality_weight == 0.3
        assert abs(w.cost_weight + w.latency_weight + w.quality_weight - 1.0) < 0.01

    def test_custom_weights_valid(self) -> None:
        """Custom weights summing to 1.0 are accepted."""
        w = ObjectiveWeight(cost_weight=0.5, latency_weight=0.2, quality_weight=0.3)
        assert w.cost_weight == 0.5

    def test_weights_not_summing_to_one_rejected(self) -> None:
        """Weights not summing to 1.0 raise ValueError."""
        with pytest.raises(ValueError, match="sum to 1.0"):
            ObjectiveWeight(cost_weight=0.5, latency_weight=0.5, quality_weight=0.5)

    def test_negative_weight_rejected(self) -> None:
        """Negative weights raise ValueError."""
        with pytest.raises(ValueError, match="between 0 and 1"):
            ObjectiveWeight(cost_weight=-0.1, latency_weight=0.6, quality_weight=0.5)

    def test_weight_above_one_rejected(self) -> None:
        """Weight above 1.0 raises ValueError."""
        with pytest.raises(ValueError, match="between 0 and 1"):
            ObjectiveWeight(cost_weight=1.5, latency_weight=-0.3, quality_weight=-0.2)

    def test_equal_weights(self) -> None:
        """Equal weights at ~0.333 are accepted."""
        w = ObjectiveWeight(
            cost_weight=0.34, latency_weight=0.33, quality_weight=0.33,
        )
        total = w.cost_weight + w.latency_weight + w.quality_weight
        assert abs(total - 1.0) < 0.01


# ---------------------------------------------------------------------------
# ModelScore tests
# ---------------------------------------------------------------------------


class TestModelScore:
    """Tests for ModelScore dataclass."""

    def test_default_values(self) -> None:
        """Default values are zeros/empty."""
        ms = ModelScore(model_id="test-model")
        assert ms.cost_score == 0.0
        assert ms.latency_score == 0.0
        assert ms.quality_score == 0.0
        assert ms.weighted_score == 0.0
        assert ms.is_pareto_optimal is False
        assert ms.dominated_by == []

    def test_mutable(self) -> None:
        """ModelScore fields are mutable (needed for in-place updates)."""
        ms = ModelScore(model_id="test-model")
        ms.is_pareto_optimal = True
        ms.weighted_score = 0.85
        assert ms.is_pareto_optimal is True
        assert ms.weighted_score == 0.85


# ---------------------------------------------------------------------------
# RoutingConstraint tests
# ---------------------------------------------------------------------------


class TestRoutingConstraint:
    """Tests for RoutingConstraint dataclass."""

    def test_no_constraints(self) -> None:
        """Default constraint has no limits."""
        rc = RoutingConstraint()
        assert rc.max_cost_usd is None
        assert rc.max_latency_ms is None
        assert rc.min_quality_score is None
        assert rc.required_features == []

    def test_all_constraints_set(self) -> None:
        """All constraints can be set."""
        rc = RoutingConstraint(
            max_cost_usd=0.01,
            max_latency_ms=2000.0,
            min_quality_score=0.8,
            required_features=["vision", "tool_use"],
        )
        assert rc.max_cost_usd == 0.01
        assert rc.max_latency_ms == 2000.0
        assert rc.min_quality_score == 0.8
        assert rc.required_features == ["vision", "tool_use"]


# ---------------------------------------------------------------------------
# Normalisation function tests
# ---------------------------------------------------------------------------


class TestNormalizeCost:
    """Tests for _normalize_cost."""

    def test_free_model_gets_perfect_score(self) -> None:
        """Free model (ollama) gets score 1.0."""
        score = _normalize_cost("ollama/qwen2.5-coder:7b")
        assert score == 1.0

    def test_expensive_model_gets_lower_score(self) -> None:
        """Expensive model gets a lower score than cheap model."""
        expensive = _normalize_cost("o3")
        cheap = _normalize_cost("gpt-4o-mini")
        assert cheap > expensive

    def test_unknown_model_gets_neutral(self) -> None:
        """Unknown model gets neutral score."""
        score = _normalize_cost("unknown/model-xyz")
        assert score == 0.5

    def test_score_bounded_zero_to_one(self) -> None:
        """Score is always between 0 and 1."""
        for model_id in ["o3", "gpt-4o-mini", "ollama/llama3.2:3b"]:
            score = _normalize_cost(model_id)
            assert 0.0 <= score <= 1.0


class TestNormalizeLatency:
    """Tests for _normalize_latency."""

    def test_fast_model_scores_higher(self) -> None:
        """Fast model (Groq) scores higher than slow model (o3)."""
        fast = _normalize_latency("groq/mixtral-8x7b-32768")
        slow = _normalize_latency("o3")
        assert fast > slow

    def test_with_tracker_data(self) -> None:
        """Uses tracker data when available."""
        tracker = MagicMock()
        tracker.get_p50.return_value = 500.0  # Very fast
        score = _normalize_latency("gpt-4o", tracker)
        assert score > 0.7

    def test_tracker_no_data_falls_back(self) -> None:
        """Falls back to defaults when tracker has no data."""
        tracker = MagicMock()
        tracker.get_p50.return_value = None
        score_with_tracker = _normalize_latency("gpt-4o", tracker)
        score_without = _normalize_latency("gpt-4o")
        assert score_with_tracker == score_without

    def test_score_bounded_zero_to_one(self) -> None:
        """Score is always between 0 and 1."""
        for model_id in ["o3", "groq/mixtral-8x7b-32768", "gpt-4o"]:
            score = _normalize_latency(model_id)
            assert 0.0 <= score <= 1.0


class TestNormalizeQuality:
    """Tests for _normalize_quality."""

    def test_top_model_scores_high(self) -> None:
        """Top-tier model gets high quality score."""
        score = _normalize_quality("anthropic/claude-opus-4-20250514")
        assert score >= 0.9

    def test_lower_model_scores_lower(self) -> None:
        """Budget model gets lower quality score."""
        top = _normalize_quality("anthropic/claude-opus-4-20250514")
        budget = _normalize_quality("groq/mixtral-8x7b-32768")
        assert top > budget

    def test_success_rate_blending(self) -> None:
        """Historical success rate is blended with default quality."""
        high_success = _normalize_quality("gpt-4o", success_rate=0.95)
        low_success = _normalize_quality("gpt-4o", success_rate=0.50)
        assert high_success > low_success

    def test_complex_penalises_weak_models(self) -> None:
        """Complex tasks penalise weaker models."""
        simple_score = _normalize_quality("groq/mixtral-8x7b-32768", complexity="simple")
        complex_score = _normalize_quality("groq/mixtral-8x7b-32768", complexity="complex")
        assert simple_score > complex_score

    def test_unknown_model_gets_default(self) -> None:
        """Unknown model gets a reasonable default."""
        score = _normalize_quality("unknown/model")
        assert 0.5 <= score <= 0.8


# ---------------------------------------------------------------------------
# _is_dominated tests
# ---------------------------------------------------------------------------


class TestIsDominated:
    """Tests for the _is_dominated function."""

    def test_dominated_on_all_axes(self) -> None:
        """A model strictly worse on all axes is dominated."""
        worse = ModelScore(
            model_id="worse", cost_score=0.3, latency_score=0.3, quality_score=0.3,
        )
        better = ModelScore(
            model_id="better", cost_score=0.8, latency_score=0.8, quality_score=0.8,
        )
        assert _is_dominated(worse, better) is True
        assert _is_dominated(better, worse) is False

    def test_equal_on_all_axes_not_dominated(self) -> None:
        """Equal models do not dominate each other."""
        a = ModelScore(model_id="a", cost_score=0.5, latency_score=0.5, quality_score=0.5)
        b = ModelScore(model_id="b", cost_score=0.5, latency_score=0.5, quality_score=0.5)
        assert _is_dominated(a, b) is False
        assert _is_dominated(b, a) is False

    def test_tradeoff_not_dominated(self) -> None:
        """Models with trade-offs do not dominate each other."""
        # A is cheaper but lower quality
        a = ModelScore(model_id="a", cost_score=0.9, latency_score=0.5, quality_score=0.3)
        # B is more expensive but higher quality
        b = ModelScore(model_id="b", cost_score=0.3, latency_score=0.5, quality_score=0.9)
        assert _is_dominated(a, b) is False
        assert _is_dominated(b, a) is False

    def test_dominated_on_two_equal_on_one(self) -> None:
        """Dominated when worse on 2 and equal on 1."""
        a = ModelScore(model_id="a", cost_score=0.5, latency_score=0.3, quality_score=0.3)
        b = ModelScore(model_id="b", cost_score=0.5, latency_score=0.8, quality_score=0.8)
        assert _is_dominated(a, b) is True


# ---------------------------------------------------------------------------
# ParetoRouter.rank_models tests
# ---------------------------------------------------------------------------


class TestParetoRouterRankModels:
    """Tests for ParetoRouter.rank_models."""

    def test_empty_candidates(self) -> None:
        """Empty candidate list returns empty result."""
        router = ParetoRouter()
        result = router.rank_models([])
        assert result == []

    def test_single_candidate_is_pareto_optimal(self) -> None:
        """Single candidate is always Pareto-optimal."""
        router = ParetoRouter()
        result = router.rank_models(["gpt-4o"])
        assert len(result) == 1
        assert result[0].is_pareto_optimal is True

    def test_multiple_candidates_ranked(self) -> None:
        """Multiple candidates are ranked by weighted score."""
        router = ParetoRouter()
        result = router.rank_models(["gpt-4o", "gpt-4o-mini", "o3"])
        assert len(result) == 3
        # Verify descending order
        for i in range(len(result) - 1):
            assert result[i].weighted_score >= result[i + 1].weighted_score

    def test_pareto_front_identified(self) -> None:
        """At least one model is Pareto-optimal."""
        router = ParetoRouter()
        result = router.rank_models(
            ["gpt-4o", "gpt-4o-mini", "o3", "groq/mixtral-8x7b-32768"],
        )
        pareto_count = sum(1 for s in result if s.is_pareto_optimal)
        assert pareto_count >= 1

    def test_scores_bounded(self) -> None:
        """All scores are between 0 and 1."""
        router = ParetoRouter()
        result = router.rank_models(["gpt-4o", "o3", "gpt-4o-mini"])
        for score in result:
            assert 0.0 <= score.cost_score <= 1.0
            assert 0.0 <= score.latency_score <= 1.0
            assert 0.0 <= score.quality_score <= 1.0
            assert 0.0 <= score.weighted_score <= 1.0

    def test_complexity_affects_ranking(self) -> None:
        """Different complexity tiers may produce different rankings."""
        router = ParetoRouter()
        simple = router.rank_models(["gpt-4o", "gpt-4o-mini"], "simple")
        complex_result = router.rank_models(["gpt-4o", "gpt-4o-mini"], "complex")
        # Results should exist for both
        assert len(simple) == 2
        assert len(complex_result) == 2

    def test_with_latency_tracker(self) -> None:
        """Latency tracker data is used when available."""
        tracker = MagicMock()
        tracker.get_p50.return_value = 200.0  # Very fast for all models
        router = ParetoRouter(latency_tracker=tracker)
        result = router.rank_models(["gpt-4o", "o3"])
        # All models should have high latency scores due to mock
        for score in result:
            assert score.latency_score > 0.8


# ---------------------------------------------------------------------------
# ParetoRouter.find_pareto_front tests
# ---------------------------------------------------------------------------


class TestParetoRouterFindParetoFront:
    """Tests for ParetoRouter.find_pareto_front."""

    def test_empty_list(self) -> None:
        """Empty list returns empty front."""
        router = ParetoRouter()
        assert router.find_pareto_front([]) == []

    def test_all_identical_are_pareto(self) -> None:
        """Identical models are all Pareto-optimal."""
        scores = [
            ModelScore(model_id="a", cost_score=0.5, latency_score=0.5, quality_score=0.5),
            ModelScore(model_id="b", cost_score=0.5, latency_score=0.5, quality_score=0.5),
        ]
        router = ParetoRouter()
        front = router.find_pareto_front(scores)
        assert len(front) == 2

    def test_dominated_excluded_from_front(self) -> None:
        """Dominated model is excluded from Pareto front."""
        scores = [
            ModelScore(
                model_id="dominated",
                cost_score=0.3, latency_score=0.3, quality_score=0.3,
            ),
            ModelScore(
                model_id="dominant",
                cost_score=0.9, latency_score=0.9, quality_score=0.9,
            ),
        ]
        router = ParetoRouter()
        front = router.find_pareto_front(scores)
        assert len(front) == 1
        assert front[0].model_id == "dominant"

    def test_tradeoff_models_both_on_front(self) -> None:
        """Models with genuine trade-offs are both on the front."""
        scores = [
            ModelScore(
                model_id="cheap_slow",
                cost_score=0.9, latency_score=0.2, quality_score=0.5,
            ),
            ModelScore(
                model_id="expensive_fast",
                cost_score=0.2, latency_score=0.9, quality_score=0.5,
            ),
        ]
        router = ParetoRouter()
        front = router.find_pareto_front(scores)
        assert len(front) == 2


# ---------------------------------------------------------------------------
# ParetoRouter.select_best tests
# ---------------------------------------------------------------------------


class TestParetoRouterSelectBest:
    """Tests for ParetoRouter.select_best."""

    def test_empty_candidates_returns_none(self) -> None:
        """Empty candidate list returns None."""
        router = ParetoRouter()
        assert router.select_best([]) is None

    def test_selects_highest_weighted(self) -> None:
        """Selects the model with highest weighted score."""
        scores = [
            ModelScore(
                model_id="low",
                cost_score=0.3, latency_score=0.3, quality_score=0.3,
                weighted_score=0.3, is_pareto_optimal=False,
            ),
            ModelScore(
                model_id="high",
                cost_score=0.9, latency_score=0.9, quality_score=0.9,
                weighted_score=0.9, is_pareto_optimal=True,
            ),
        ]
        router = ParetoRouter()
        best = router.select_best(scores)
        assert best is not None
        assert best.model_id == "high"

    def test_cost_constraint_filters(self) -> None:
        """Cost constraint filters out expensive models."""
        router = ParetoRouter()
        ranked = router.rank_models(["o3", "gpt-4o-mini"])
        # o3 is expensive, gpt-4o-mini is cheap
        result = router.select_best(
            ranked,
            RoutingConstraint(max_cost_usd=0.001),
        )
        if result is not None:
            assert result.model_id == "gpt-4o-mini"

    def test_quality_constraint_filters(self) -> None:
        """Quality constraint filters out low-quality models."""
        scores = [
            ModelScore(
                model_id="low_quality",
                cost_score=0.9, latency_score=0.9, quality_score=0.3,
                weighted_score=0.7, is_pareto_optimal=True,
            ),
            ModelScore(
                model_id="high_quality",
                cost_score=0.5, latency_score=0.5, quality_score=0.9,
                weighted_score=0.6, is_pareto_optimal=True,
            ),
        ]
        router = ParetoRouter()
        result = router.select_best(scores, RoutingConstraint(min_quality_score=0.8))
        assert result is not None
        assert result.model_id == "high_quality"

    def test_no_model_satisfies_constraints_returns_none(self) -> None:
        """Returns None when no model satisfies all constraints."""
        scores = [
            ModelScore(
                model_id="model_a",
                cost_score=0.5, latency_score=0.5, quality_score=0.5,
                weighted_score=0.5, is_pareto_optimal=True,
            ),
        ]
        router = ParetoRouter()
        result = router.select_best(
            scores,
            RoutingConstraint(min_quality_score=0.99),
        )
        assert result is None

    def test_feature_constraint_filters(self) -> None:
        """Feature constraint filters models missing required features."""
        router = ParetoRouter()
        ranked = router.rank_models(
            ["gpt-4o", "groq/mixtral-8x7b-32768"],
        )
        result = router.select_best(
            ranked,
            RoutingConstraint(required_features=["vision", "tool_use"]),
        )
        if result is not None:
            assert result.model_id == "gpt-4o"

    def test_no_constraint_selects_best(self) -> None:
        """No constraint selects highest weighted score."""
        router = ParetoRouter()
        ranked = router.rank_models(["gpt-4o", "gpt-4o-mini"])
        result = router.select_best(ranked)
        assert result is not None
        assert result.weighted_score == ranked[0].weighted_score


# ---------------------------------------------------------------------------
# ParetoRouter.explain_selection tests
# ---------------------------------------------------------------------------


class TestParetoRouterExplainSelection:
    """Tests for ParetoRouter.explain_selection."""

    def test_pareto_optimal_explanation(self) -> None:
        """Pareto-optimal model gets appropriate explanation."""
        router = ParetoRouter()
        score = ModelScore(
            model_id="gpt-4o",
            cost_score=0.7,
            latency_score=0.6,
            quality_score=0.9,
            weighted_score=0.73,
            is_pareto_optimal=True,
        )
        explanation = router.explain_selection(score)
        assert "gpt-4o" in explanation
        assert "Pareto-optimal" in explanation
        assert "0.73" in explanation

    def test_dominated_explanation(self) -> None:
        """Dominated model explanation mentions dominating models."""
        router = ParetoRouter()
        score = ModelScore(
            model_id="weak-model",
            cost_score=0.3,
            latency_score=0.3,
            quality_score=0.3,
            weighted_score=0.3,
            is_pareto_optimal=False,
            dominated_by=["gpt-4o", "o3"],
        )
        explanation = router.explain_selection(score)
        assert "Dominated by" in explanation
        assert "gpt-4o" in explanation

    def test_weights_shown(self) -> None:
        """Explanation includes weight information."""
        weights = ObjectiveWeight(cost_weight=0.5, latency_weight=0.2, quality_weight=0.3)
        router = ParetoRouter(weights=weights)
        score = ModelScore(
            model_id="test",
            cost_score=0.5,
            latency_score=0.5,
            quality_score=0.5,
            weighted_score=0.5,
            is_pareto_optimal=True,
        )
        explanation = router.explain_selection(score)
        assert "0.5" in explanation
        assert "0.2" in explanation
        assert "0.3" in explanation
