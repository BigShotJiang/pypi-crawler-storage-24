"""Tests for latency-aware routing tracker."""

from __future__ import annotations

import pytest

from prism.router.latency_tracker import LatencyTracker, LatencyStats


class TestLatencyTracker:
    """Tests for the LatencyTracker class."""

    @pytest.fixture()
    def tracker(self) -> LatencyTracker:
        return LatencyTracker()

    def test_record_and_get_stats(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("gpt-4o", latency_ms=500.0)
        stats = tracker.get_stats("gpt-4o")
        assert stats is not None
        assert stats.model == "gpt-4o"
        assert stats.p50_ms == pytest.approx(500.0, abs=1.0)
        assert stats.sample_count == 10

    def test_no_stats_for_unknown_model(self, tracker: LatencyTracker) -> None:
        assert tracker.get_stats("unknown-model") is None

    def test_insufficient_samples(self, tracker: LatencyTracker) -> None:
        tracker.record("gpt-4o", latency_ms=100.0)
        # Only 1 sample, need 5
        assert tracker.get_stats("gpt-4o") is None

    def test_percentiles(self, tracker: LatencyTracker) -> None:
        # Record a range of latencies
        for ms in [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]:
            tracker.record("model-a", latency_ms=float(ms))
        stats = tracker.get_stats("model-a")
        assert stats is not None
        assert stats.p50_ms == pytest.approx(550.0, abs=50)
        assert stats.p95_ms > stats.p50_ms
        assert stats.p99_ms >= stats.p95_ms
        assert stats.min_ms == pytest.approx(100.0, abs=1)
        assert stats.max_ms == pytest.approx(1000.0, abs=1)

    def test_degradation_detection(self, tracker: LatencyTracker) -> None:
        # Most requests fast, but some very slow → degraded
        for _ in range(90):
            tracker.record("model-b", latency_ms=100.0)
        for _ in range(10):
            tracker.record("model-b", latency_ms=5000.0)
        stats = tracker.get_stats("model-b")
        assert stats is not None
        # P95 should be very high relative to P50
        assert stats.is_degraded

    def test_not_degraded_consistent(self, tracker: LatencyTracker) -> None:
        for _ in range(20):
            tracker.record("model-c", latency_ms=500.0)
        stats = tracker.get_stats("model-c")
        assert stats is not None
        assert not stats.is_degraded

    def test_get_p50(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("model-d", latency_ms=200.0)
        p50 = tracker.get_p50("model-d")
        assert p50 is not None
        assert p50 == pytest.approx(200.0, abs=1)

    def test_get_fastest_model(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("slow-model", latency_ms=2000.0)
        for _ in range(10):
            tracker.record("fast-model", latency_ms=200.0)
        fastest = tracker.get_fastest_model(["slow-model", "fast-model"])
        assert fastest == "fast-model"

    def test_get_fastest_no_data(self, tracker: LatencyTracker) -> None:
        assert tracker.get_fastest_model(["a", "b"]) is None

    def test_routing_bonus_fast(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("fast", latency_ms=300.0)
        bonus = tracker.get_routing_bonus("fast")
        assert bonus > 1.0  # Fast models get a bonus

    def test_routing_bonus_slow(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("slow", latency_ms=8000.0)
        bonus = tracker.get_routing_bonus("slow")
        assert bonus < 1.0  # Slow models get a penalty

    def test_routing_bonus_unknown(self, tracker: LatencyTracker) -> None:
        bonus = tracker.get_routing_bonus("unknown")
        assert bonus == 1.0  # Neutral

    def test_ttfb_tracking(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("model-e", latency_ms=1000.0, ttfb_ms=200.0)
        stats = tracker.get_stats("model-e")
        assert stats is not None
        assert stats.ttfb_p50_ms == pytest.approx(200.0, abs=1)

    def test_clear_single(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("m1", latency_ms=100.0)
            tracker.record("m2", latency_ms=200.0)
        tracker.clear("m1")
        assert tracker.get_stats("m1") is None
        assert tracker.get_stats("m2") is not None

    def test_clear_all(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("m1", latency_ms=100.0)
        tracker.clear()
        assert tracker.get_all_stats() == []

    def test_get_all_stats(self, tracker: LatencyTracker) -> None:
        for _ in range(10):
            tracker.record("m1", latency_ms=100.0)
            tracker.record("m2", latency_ms=200.0)
        all_stats = tracker.get_all_stats()
        assert len(all_stats) == 2
        models = {s.model for s in all_stats}
        assert models == {"m1", "m2"}

    def test_rolling_window_eviction(self, tracker: LatencyTracker) -> None:
        # Record more than window size
        for i in range(250):
            tracker.record("m", latency_ms=float(i))
        stats = tracker.get_stats("m")
        assert stats is not None
        assert stats.sample_count == 200  # Window size cap
