"""Tests for the intelligent load balancer."""

from __future__ import annotations

import time

import pytest

from prism.router.load_balancer import (
    BalancingStrategy,
    LoadBalancer,
    LoadBalancerConfig,
    ProviderEndpoint,
)


@pytest.fixture()
def lb() -> LoadBalancer:
    """Basic load balancer with default config."""
    return LoadBalancer()


@pytest.fixture()
def multi_provider_lb() -> LoadBalancer:
    """Load balancer with multiple providers registered."""
    lb = LoadBalancer()
    lb.register("openai", weight=3, cost_per_1k_input=0.03, cost_per_1k_output=0.06)
    lb.register("anthropic", weight=2, cost_per_1k_input=0.015, cost_per_1k_output=0.075)
    lb.register("google", weight=1, cost_per_1k_input=0.005, cost_per_1k_output=0.015)
    return lb


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


class TestRegistration:
    """Tests for provider registration."""

    def test_register_provider(self, lb: LoadBalancer) -> None:
        lb.register("openai", weight=3)
        ep = lb.get_endpoint("openai")
        assert ep is not None
        assert ep.name == "openai"
        assert ep.weight == 3

    def test_register_with_models(self, lb: LoadBalancer) -> None:
        lb.register("openai", models=["gpt-4o", "gpt-4o-mini"])
        ep = lb.get_endpoint("openai")
        assert ep is not None
        assert "gpt-4o" in ep.models

    def test_unregister(self, lb: LoadBalancer) -> None:
        lb.register("openai")
        assert lb.unregister("openai") is True
        assert lb.get_endpoint("openai") is None

    def test_unregister_nonexistent(self, lb: LoadBalancer) -> None:
        assert lb.unregister("nonexistent") is False

    def test_get_all_endpoints(self, multi_provider_lb: LoadBalancer) -> None:
        eps = multi_provider_lb.get_all_endpoints()
        assert len(eps) == 3
        assert "openai" in eps


# ---------------------------------------------------------------------------
# Round Robin
# ---------------------------------------------------------------------------


class TestRoundRobin:
    """Tests for round-robin strategy."""

    def test_basic_round_robin(self, multi_provider_lb: LoadBalancer) -> None:
        results = [
            multi_provider_lb.select(strategy=BalancingStrategy.ROUND_ROBIN)
            for _ in range(6)
        ]
        providers = [r.provider for r in results]
        # Should cycle through all providers
        assert "openai" in providers
        assert "anthropic" in providers
        assert "google" in providers

    def test_weighted_round_robin(self) -> None:
        lb = LoadBalancer()
        lb.register("heavy", weight=3)
        lb.register("light", weight=1)
        results = [
            lb.select(strategy=BalancingStrategy.ROUND_ROBIN).provider
            for _ in range(8)
        ]
        heavy_count = results.count("heavy")
        light_count = results.count("light")
        assert heavy_count > light_count

    def test_single_provider_round_robin(self, lb: LoadBalancer) -> None:
        lb.register("only")
        result = lb.select(strategy=BalancingStrategy.ROUND_ROBIN)
        assert result.provider == "only"


# ---------------------------------------------------------------------------
# Least Connections
# ---------------------------------------------------------------------------


class TestLeastConnections:
    """Tests for least-connections strategy."""

    def test_selects_fewest_connections(self, multi_provider_lb: LoadBalancer) -> None:
        # Give openai 5 active connections
        ep = multi_provider_lb.get_endpoint("openai")
        assert ep is not None
        ep.active_connections = 5

        result = multi_provider_lb.select(strategy=BalancingStrategy.LEAST_CONNECTIONS)
        assert result.provider != "openai"
        assert result.strategy_used == BalancingStrategy.LEAST_CONNECTIONS

    def test_all_equal_connections(self, multi_provider_lb: LoadBalancer) -> None:
        result = multi_provider_lb.select(strategy=BalancingStrategy.LEAST_CONNECTIONS)
        assert result.provider != ""


# ---------------------------------------------------------------------------
# Latency Based
# ---------------------------------------------------------------------------


class TestLatencyBased:
    """Tests for latency-based strategy."""

    def test_selects_lowest_latency(self, multi_provider_lb: LoadBalancer) -> None:
        ep = multi_provider_lb.get_endpoint("google")
        assert ep is not None
        ep.avg_latency_ms = 50.0

        ep2 = multi_provider_lb.get_endpoint("openai")
        assert ep2 is not None
        ep2.avg_latency_ms = 2000.0

        result = multi_provider_lb.select(strategy=BalancingStrategy.LATENCY_BASED)
        assert result.provider == "google"

    def test_latency_updated_on_success(self, multi_provider_lb: LoadBalancer) -> None:
        ep_before = multi_provider_lb.get_endpoint("openai")
        assert ep_before is not None
        old_latency = ep_before.avg_latency_ms

        multi_provider_lb.record_success("openai", latency_ms=100.0)
        assert ep_before.avg_latency_ms != old_latency


# ---------------------------------------------------------------------------
# Cost Optimized
# ---------------------------------------------------------------------------


class TestCostOptimized:
    """Tests for cost-optimized strategy."""

    def test_selects_cheapest(self, multi_provider_lb: LoadBalancer) -> None:
        result = multi_provider_lb.select(strategy=BalancingStrategy.COST_OPTIMIZED)
        # Google is cheapest (0.005 + 0.015 = 0.02)
        assert result.provider == "google"

    def test_respects_quality_threshold(self) -> None:
        lb = LoadBalancer(LoadBalancerConfig(quality_threshold=0.7))
        lb.register("cheap", cost_per_1k_input=0.001, cost_per_1k_output=0.001)
        lb.register("expensive", cost_per_1k_input=0.1, cost_per_1k_output=0.1)
        ep = lb.get_endpoint("cheap")
        assert ep is not None
        ep.quality_score = 0.3  # Below threshold

        result = lb.select(strategy=BalancingStrategy.COST_OPTIMIZED)
        assert result.provider == "expensive"


# ---------------------------------------------------------------------------
# Adaptive
# ---------------------------------------------------------------------------


class TestAdaptive:
    """Tests for adaptive strategy."""

    def test_adaptive_selection(self, multi_provider_lb: LoadBalancer) -> None:
        result = multi_provider_lb.select(strategy=BalancingStrategy.ADAPTIVE)
        assert result.provider != ""
        assert result.strategy_used == BalancingStrategy.ADAPTIVE
        assert result.score > 0

    def test_adaptive_prefers_quality(self) -> None:
        lb = LoadBalancer()
        lb.register("low_q", cost_per_1k_input=0.001, cost_per_1k_output=0.001)
        lb.register("high_q", cost_per_1k_input=0.01, cost_per_1k_output=0.01)
        ep_low = lb.get_endpoint("low_q")
        ep_high = lb.get_endpoint("high_q")
        assert ep_low is not None
        assert ep_high is not None
        ep_low.quality_score = 0.3
        ep_high.quality_score = 0.95

        result = lb.select(strategy=BalancingStrategy.ADAPTIVE)
        assert result.provider == "high_q"


# ---------------------------------------------------------------------------
# Sticky Sessions
# ---------------------------------------------------------------------------


class TestStickySessions:
    """Tests for sticky session routing."""

    def test_sticky_same_session(self, multi_provider_lb: LoadBalancer) -> None:
        r1 = multi_provider_lb.select(
            strategy=BalancingStrategy.STICKY, session_id="sess-1"
        )
        r2 = multi_provider_lb.select(
            strategy=BalancingStrategy.STICKY, session_id="sess-1"
        )
        assert r1.provider == r2.provider

    def test_sticky_different_sessions(self, multi_provider_lb: LoadBalancer) -> None:
        results = set()
        for i in range(20):
            r = multi_provider_lb.select(
                strategy=BalancingStrategy.STICKY, session_id=f"sess-{i}"
            )
            results.add(r.provider)
        # Should distribute across providers
        assert len(results) > 1

    def test_sticky_affinity_with_other_strategy(
        self, multi_provider_lb: LoadBalancer,
    ) -> None:
        # First select establishes affinity
        r1 = multi_provider_lb.select(session_id="sticky-sess")
        # Second select should use sticky affinity
        r2 = multi_provider_lb.select(session_id="sticky-sess")
        assert r1.provider == r2.provider


# ---------------------------------------------------------------------------
# Health Management
# ---------------------------------------------------------------------------


class TestHealthManagement:
    """Tests for provider health tracking."""

    def test_failure_marks_unhealthy(self, multi_provider_lb: LoadBalancer) -> None:
        config = LoadBalancerConfig(failure_threshold=2)
        lb = LoadBalancer(config)
        lb.register("fragile")

        # Record enough failures
        for _ in range(10):
            lb.record_failure("fragile")

        ep = lb.get_endpoint("fragile")
        assert ep is not None
        assert not ep.is_healthy

    def test_unhealthy_excluded_from_selection(self) -> None:
        lb = LoadBalancer(LoadBalancerConfig(failure_threshold=2))
        lb.register("healthy")
        lb.register("unhealthy")

        for _ in range(10):
            lb.record_failure("unhealthy")

        result = lb.select()
        assert result.provider == "healthy"

    def test_recovery_after_timeout(self) -> None:
        config = LoadBalancerConfig(failure_threshold=2, recovery_time_s=0.01)
        lb = LoadBalancer(config)
        lb.register("recovering")
        lb.register("backup")

        for _ in range(10):
            lb.record_failure("recovering")

        time.sleep(0.02)

        # Should be re-checked after recovery time
        result = lb.select()
        # Provider should be available again
        assert result.provider != ""

    def test_success_restores_health(self, multi_provider_lb: LoadBalancer) -> None:
        ep = multi_provider_lb.get_endpoint("openai")
        assert ep is not None
        ep.is_healthy = False

        multi_provider_lb.record_success("openai", latency_ms=100)
        assert ep.is_healthy

    def test_no_providers_available(self, lb: LoadBalancer) -> None:
        result = lb.select()
        assert result.provider == ""
        assert "no healthy" in result.reason


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------


class TestStatistics:
    """Tests for load balancer statistics."""

    def test_selection_counted(self, multi_provider_lb: LoadBalancer) -> None:
        multi_provider_lb.select()
        multi_provider_lb.select()
        stats = multi_provider_lb.get_stats()
        assert stats.total_selections == 2

    def test_strategy_breakdown(self, multi_provider_lb: LoadBalancer) -> None:
        multi_provider_lb.select(strategy=BalancingStrategy.ROUND_ROBIN)
        multi_provider_lb.select(strategy=BalancingStrategy.LATENCY_BASED)
        stats = multi_provider_lb.get_stats()
        assert "round_robin" in stats.selections_by_strategy
        assert "latency_based" in stats.selections_by_strategy

    def test_provider_breakdown(self, multi_provider_lb: LoadBalancer) -> None:
        for _ in range(5):
            multi_provider_lb.select()
        stats = multi_provider_lb.get_stats()
        assert len(stats.selections_by_provider) > 0

    def test_selection_time_tracked(self, multi_provider_lb: LoadBalancer) -> None:
        multi_provider_lb.select()
        stats = multi_provider_lb.get_stats()
        assert stats.avg_selection_time_us > 0

    def test_failover_counted(self, multi_provider_lb: LoadBalancer) -> None:
        multi_provider_lb.record_failure("openai")
        stats = multi_provider_lb.get_stats()
        assert stats.failover_count == 1

    def test_reset_stats(self, multi_provider_lb: LoadBalancer) -> None:
        multi_provider_lb.select()
        multi_provider_lb.reset_stats()
        stats = multi_provider_lb.get_stats()
        assert stats.total_selections == 0


# ---------------------------------------------------------------------------
# Rebalancing
# ---------------------------------------------------------------------------


class TestRebalancing:
    """Tests for weight rebalancing."""

    def test_rebalance_adjusts_weights(self, multi_provider_lb: LoadBalancer) -> None:
        # Give google great stats
        ep = multi_provider_lb.get_endpoint("google")
        assert ep is not None
        ep.avg_latency_ms = 50.0
        ep.quality_score = 0.99

        # Give openai poor stats
        ep2 = multi_provider_lb.get_endpoint("openai")
        assert ep2 is not None
        ep2.avg_latency_ms = 5000.0
        ep2.quality_score = 0.5

        multi_provider_lb.rebalance()
        assert ep.weight >= ep2.weight

    def test_rebalance_count_tracked(self, multi_provider_lb: LoadBalancer) -> None:
        multi_provider_lb.rebalance()
        multi_provider_lb.rebalance()
        stats = multi_provider_lb.get_stats()
        assert stats.rebalance_count == 2


# ---------------------------------------------------------------------------
# Model Filtering
# ---------------------------------------------------------------------------


class TestModelFiltering:
    """Tests for model-aware selection."""

    def test_filter_by_model(self) -> None:
        lb = LoadBalancer()
        lb.register("openai", models=["gpt-4o", "gpt-4o-mini"])
        lb.register("anthropic", models=["claude-sonnet-4-20250514"])

        result = lb.select(model="claude-sonnet-4-20250514")
        assert result.provider == "anthropic"

    def test_no_model_filter(self, multi_provider_lb: LoadBalancer) -> None:
        result = multi_provider_lb.select()
        assert result.provider != ""

    def test_model_not_found(self) -> None:
        lb = LoadBalancer()
        lb.register("openai", models=["gpt-4o"])
        result = lb.select(model="nonexistent-model")
        assert result.provider == ""


# ---------------------------------------------------------------------------
# Connection Management
# ---------------------------------------------------------------------------


class TestConnectionManagement:
    """Tests for connection tracking."""

    def test_record_connection(self, multi_provider_lb: LoadBalancer) -> None:
        multi_provider_lb.record_connection("openai")
        ep = multi_provider_lb.get_endpoint("openai")
        assert ep is not None
        assert ep.active_connections == 1

    def test_success_decrements_connection(
        self, multi_provider_lb: LoadBalancer,
    ) -> None:
        multi_provider_lb.record_connection("openai")
        multi_provider_lb.record_success("openai", latency_ms=100)
        ep = multi_provider_lb.get_endpoint("openai")
        assert ep is not None
        assert ep.active_connections == 0

    def test_failure_decrements_connection(
        self, multi_provider_lb: LoadBalancer,
    ) -> None:
        multi_provider_lb.record_connection("openai")
        multi_provider_lb.record_failure("openai")
        ep = multi_provider_lb.get_endpoint("openai")
        assert ep is not None
        assert ep.active_connections == 0

    def test_full_capacity_excluded(self, multi_provider_lb: LoadBalancer) -> None:
        ep = multi_provider_lb.get_endpoint("openai")
        assert ep is not None
        ep.active_connections = ep.max_concurrent

        result = multi_provider_lb.select(strategy=BalancingStrategy.LEAST_CONNECTIONS)
        assert result.provider != "openai"


# ---------------------------------------------------------------------------
# Endpoint properties
# ---------------------------------------------------------------------------


class TestEndpointProperties:
    """Tests for ProviderEndpoint computed properties."""

    def test_success_rate_no_requests(self) -> None:
        ep = ProviderEndpoint(name="test")
        assert ep.success_rate == 1.0

    def test_success_rate_with_failures(self) -> None:
        ep = ProviderEndpoint(name="test", total_requests=10, total_failures=3)
        assert ep.success_rate == pytest.approx(0.7, abs=0.01)

    def test_utilization(self) -> None:
        ep = ProviderEndpoint(
            name="test", active_connections=5, max_concurrent=10,
        )
        assert ep.utilization == pytest.approx(0.5)

    def test_utilization_zero_max(self) -> None:
        ep = ProviderEndpoint(name="test", max_concurrent=0)
        assert ep.utilization == 1.0
