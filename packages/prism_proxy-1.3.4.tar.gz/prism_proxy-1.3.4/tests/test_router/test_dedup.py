"""Tests for prism.router.dedup — RequestDeduplicator and RequestBatcher."""

from __future__ import annotations

import asyncio
import time

import pytest

from prism.router.dedup import (
    Batch,
    BatchConfig,
    DedupStats,
    PendingRequest,
    RequestBatcher,
    RequestDeduplicator,
)

# ======================================================================
# RequestFingerprint
# ======================================================================


class TestRequestFingerprint:
    """Tests for the RequestFingerprint dataclass and factory method."""

    def test_fingerprint_deterministic(self) -> None:
        """Same inputs always produce the same hash."""
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        assert fp1.hash == fp2.hash
        assert fp1.prompt_hash == fp2.prompt_hash

    def test_fingerprint_different_prompts(self) -> None:
        """Different prompts produce different hashes."""
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "goodbye", 0.7)
        assert fp1.hash != fp2.hash
        assert fp1.prompt_hash != fp2.prompt_hash

    def test_fingerprint_different_models(self) -> None:
        """Different models produce different hashes."""
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        fp2 = RequestDeduplicator.fingerprint("claude-4-opus", "hello", 0.7)
        assert fp1.hash != fp2.hash
        # Prompt hash should be the same — same prompt text
        assert fp1.prompt_hash == fp2.prompt_hash

    def test_fingerprint_different_temperatures(self) -> None:
        """Different temperatures produce different hashes."""
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.3)
        assert fp1.hash != fp2.hash

    def test_fingerprint_none_temperature(self) -> None:
        """None temperature is handled distinctly from any float."""
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", None)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.0)
        assert fp1.hash != fp2.hash
        assert fp1.temperature is None
        assert fp2.temperature == 0.0

    def test_fingerprint_preserves_prompt_text(self) -> None:
        """The raw prompt text is stored on the fingerprint."""
        fp = RequestDeduplicator.fingerprint("gpt-4o", "test prompt", 0.5)
        assert fp.prompt_text == "test prompt"

    def test_fingerprint_is_frozen(self) -> None:
        """RequestFingerprint is immutable (frozen dataclass)."""
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hi", 0.5)
        with pytest.raises(AttributeError):
            fp.model = "other"  # type: ignore[misc]

    def test_fingerprint_equality_ignores_prompt_text(self) -> None:
        """Two fingerprints with same hash/model/temp compare equal
        even though prompt_text is compare=False."""
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "same", 0.5)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "same", 0.5)
        assert fp1 == fp2

    def test_fingerprint_hashable(self) -> None:
        """Fingerprints can be used as dict keys or set members."""
        fp = RequestDeduplicator.fingerprint("gpt-4o", "test", 0.5)
        s = {fp}
        assert fp in s


# ======================================================================
# DedupStats
# ======================================================================


class TestDedupStats:
    """Tests for the DedupStats data tracker."""

    def test_initial_values(self) -> None:
        stats = DedupStats()
        assert stats.dedup_count == 0
        assert stats.near_dedup_count == 0
        assert stats.batch_count == 0
        assert stats.total_requests == 0
        assert stats.saved_requests == 0
        assert stats.saved_cost_usd == 0.0

    def test_record_exact_dedup(self) -> None:
        stats = DedupStats()
        stats.record_dedup(near=False, estimated_cost=0.01)
        assert stats.dedup_count == 1
        assert stats.near_dedup_count == 0
        assert stats.saved_requests == 1
        assert stats.saved_cost_usd == pytest.approx(0.01)

    def test_record_near_dedup(self) -> None:
        stats = DedupStats()
        stats.record_dedup(near=True, estimated_cost=0.005)
        assert stats.dedup_count == 0
        assert stats.near_dedup_count == 1
        assert stats.saved_requests == 1
        assert stats.saved_cost_usd == pytest.approx(0.005)

    def test_record_batch(self) -> None:
        stats = DedupStats()
        stats.record_batch(5)
        assert stats.batch_count == 1
        assert stats.saved_requests == 4  # 5 - 1

    def test_record_batch_single_item(self) -> None:
        stats = DedupStats()
        stats.record_batch(1)
        assert stats.batch_count == 1
        assert stats.saved_requests == 0  # no savings from a batch of 1

    def test_record_request(self) -> None:
        stats = DedupStats()
        stats.record_request()
        stats.record_request()
        assert stats.total_requests == 2

    def test_to_dict(self) -> None:
        stats = DedupStats()
        stats.record_request()
        stats.record_dedup(near=False, estimated_cost=0.01)
        d = stats.to_dict()
        assert d["dedup_count"] == 1
        assert d["total_requests"] == 1
        assert d["saved_cost_usd"] == pytest.approx(0.01)

    def test_to_dict_rounds_cost(self) -> None:
        stats = DedupStats()
        stats.record_dedup(near=False, estimated_cost=0.1234567)
        d = stats.to_dict()
        assert d["saved_cost_usd"] == pytest.approx(0.123457)


# ======================================================================
# PendingRequest
# ======================================================================


class TestPendingRequest:
    """Tests for the PendingRequest tracker."""

    def test_not_expired_initially(self) -> None:
        fp = RequestDeduplicator.fingerprint("gpt-4o", "test", 0.5)
        loop = asyncio.new_event_loop()
        future = loop.create_future()
        pending = PendingRequest(
            fingerprint=fp,
            future=future,
            timestamp=time.monotonic(),
            ttl_seconds=60.0,
        )
        assert pending.is_expired is False
        loop.close()

    def test_expired_after_ttl(self) -> None:
        fp = RequestDeduplicator.fingerprint("gpt-4o", "test", 0.5)
        loop = asyncio.new_event_loop()
        future = loop.create_future()
        pending = PendingRequest(
            fingerprint=fp,
            future=future,
            timestamp=time.monotonic() - 200.0,
            ttl_seconds=60.0,
        )
        assert pending.is_expired is True
        loop.close()

    def test_waiter_count_default(self) -> None:
        fp = RequestDeduplicator.fingerprint("gpt-4o", "test", 0.5)
        loop = asyncio.new_event_loop()
        future = loop.create_future()
        pending = PendingRequest(
            fingerprint=fp,
            future=future,
            timestamp=time.monotonic(),
        )
        assert pending.waiter_count == 1
        loop.close()


# ======================================================================
# BatchConfig validation
# ======================================================================


class TestBatchConfig:
    """Tests for BatchConfig validation."""

    def test_defaults(self) -> None:
        cfg = BatchConfig()
        assert cfg.max_batch_size == 10
        assert cfg.batch_timeout_ms == 500
        assert cfg.dedup_similarity == pytest.approx(0.95)
        assert cfg.pending_ttl_seconds == pytest.approx(120.0)

    def test_custom_values(self) -> None:
        cfg = BatchConfig(
            max_batch_size=32,
            batch_timeout_ms=1000,
            dedup_similarity=0.8,
            pending_ttl_seconds=60.0,
        )
        assert cfg.max_batch_size == 32
        assert cfg.dedup_similarity == pytest.approx(0.8)

    def test_invalid_batch_size(self) -> None:
        with pytest.raises(ValueError, match="max_batch_size"):
            BatchConfig(max_batch_size=0)

    def test_invalid_timeout(self) -> None:
        with pytest.raises(ValueError, match="batch_timeout_ms"):
            BatchConfig(batch_timeout_ms=-1)

    def test_invalid_similarity_too_high(self) -> None:
        with pytest.raises(ValueError, match="dedup_similarity"):
            BatchConfig(dedup_similarity=1.5)

    def test_invalid_similarity_negative(self) -> None:
        with pytest.raises(ValueError, match="dedup_similarity"):
            BatchConfig(dedup_similarity=-0.1)

    def test_invalid_ttl(self) -> None:
        with pytest.raises(ValueError, match="pending_ttl_seconds"):
            BatchConfig(pending_ttl_seconds=0)


# ======================================================================
# Batch
# ======================================================================


class TestBatch:
    """Tests for the Batch data structure."""

    def test_batch_size(self) -> None:
        fp = RequestDeduplicator.fingerprint("gpt-4o", "test", 0.5)
        batch = Batch(
            items=[(fp, {"prompt": "test"})],
            model="gpt-4o",
            created_at=time.monotonic(),
            timeout_ms=500,
        )
        assert batch.size == 1

    def test_batch_not_timed_out_initially(self) -> None:
        batch = Batch(
            items=[],
            model="gpt-4o",
            created_at=time.monotonic(),
            timeout_ms=5000,
        )
        assert batch.is_timed_out is False

    def test_batch_timed_out(self) -> None:
        batch = Batch(
            items=[],
            model="gpt-4o",
            created_at=time.monotonic() - 10.0,
            timeout_ms=100,
        )
        assert batch.is_timed_out is True


# ======================================================================
# RequestBatcher
# ======================================================================


class TestRequestBatcher:
    """Tests for the RequestBatcher grouping engine."""

    @pytest.fixture()
    def batcher(self) -> RequestBatcher:
        return RequestBatcher(BatchConfig(max_batch_size=3, batch_timeout_ms=500))

    @pytest.mark.asyncio()
    async def test_add_returns_none_below_limit(self, batcher: RequestBatcher) -> None:
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        result = await batcher.add(fp, {"prompt": "hello"})
        assert result is None

    @pytest.mark.asyncio()
    async def test_add_returns_batch_at_limit(self, batcher: RequestBatcher) -> None:
        for i in range(2):
            fp = RequestDeduplicator.fingerprint("gpt-4o", f"msg{i}", 0.7)
            result = await batcher.add(fp, {"prompt": f"msg{i}"})
            assert result is None

        fp3 = RequestDeduplicator.fingerprint("gpt-4o", "msg2", 0.7)
        result = await batcher.add(fp3, {"prompt": "msg2"})
        assert result is not None
        assert result.size == 3
        assert result.model == "gpt-4o"

    @pytest.mark.asyncio()
    async def test_different_models_separate_batches(
        self, batcher: RequestBatcher
    ) -> None:
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        fp2 = RequestDeduplicator.fingerprint("claude-4-opus", "hello", 0.7)
        await batcher.add(fp1, {"prompt": "hello"})
        await batcher.add(fp2, {"prompt": "hello"})
        assert batcher.pending_batch_count == 2

    @pytest.mark.asyncio()
    async def test_flush_all(self, batcher: RequestBatcher) -> None:
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "a", 0.7)
        fp2 = RequestDeduplicator.fingerprint("claude-4-opus", "b", 0.7)
        await batcher.add(fp1, {"prompt": "a"})
        await batcher.add(fp2, {"prompt": "b"})

        flushed = await batcher.flush()
        assert len(flushed) == 2
        assert batcher.pending_batch_count == 0

    @pytest.mark.asyncio()
    async def test_flush_specific_model(self, batcher: RequestBatcher) -> None:
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "a", 0.7)
        fp2 = RequestDeduplicator.fingerprint("claude-4-opus", "b", 0.7)
        await batcher.add(fp1, {"prompt": "a"})
        await batcher.add(fp2, {"prompt": "b"})

        flushed = await batcher.flush(model="gpt-4o")
        assert len(flushed) == 1
        assert flushed[0].model == "gpt-4o"
        assert batcher.pending_batch_count == 1

    @pytest.mark.asyncio()
    async def test_flush_empty(self, batcher: RequestBatcher) -> None:
        flushed = await batcher.flush()
        assert flushed == []

    @pytest.mark.asyncio()
    async def test_flush_timed_out(self) -> None:
        batcher = RequestBatcher(BatchConfig(max_batch_size=100, batch_timeout_ms=50))
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        await batcher.add(fp, {"prompt": "hello"})
        # Wait for timeout
        await asyncio.sleep(0.1)
        flushed = await batcher.flush_timed_out()
        assert len(flushed) == 1

    @pytest.mark.asyncio()
    async def test_flush_timed_out_skips_fresh(self) -> None:
        batcher = RequestBatcher(BatchConfig(max_batch_size=100, batch_timeout_ms=10000))
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        await batcher.add(fp, {"prompt": "hello"})
        flushed = await batcher.flush_timed_out()
        assert len(flushed) == 0

    @pytest.mark.asyncio()
    async def test_clear(self, batcher: RequestBatcher) -> None:
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        await batcher.add(fp, {"prompt": "hello"})
        await batcher.clear()
        assert batcher.pending_batch_count == 0

    @pytest.mark.asyncio()
    async def test_stats_after_batch(self, batcher: RequestBatcher) -> None:
        for i in range(3):
            fp = RequestDeduplicator.fingerprint("gpt-4o", f"msg{i}", 0.7)
            await batcher.add(fp, {"prompt": f"msg{i}"})

        assert batcher.stats.batch_count == 1
        assert batcher.stats.total_requests == 3
        assert batcher.stats.saved_requests == 2  # batch of 3 saves 2


# ======================================================================
# RequestDeduplicator — exact dedup
# ======================================================================


class TestExactDedup:
    """Tests for exact fingerprint deduplication."""

    @pytest.mark.asyncio()
    async def test_identical_requests_share_result(self) -> None:
        dedup = RequestDeduplicator()
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello world", 0.7)

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return "response"

        results = await asyncio.gather(
            dedup.submit(fp, execute_fn),
            dedup.submit(fp, execute_fn),
            dedup.submit(fp, execute_fn),
        )
        assert all(r == "response" for r in results)
        assert call_count == 1
        assert dedup.stats.dedup_count == 2  # 2 out of 3 were deduped

    @pytest.mark.asyncio()
    async def test_different_prompts_not_deduped(self) -> None:
        dedup = RequestDeduplicator()
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "completely different", 0.7)

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return f"response-{call_count}"

        results = await asyncio.gather(
            dedup.submit(fp1, execute_fn),
            dedup.submit(fp2, execute_fn),
        )
        assert call_count == 2
        # Both executed independently (may return same string due to race)

    @pytest.mark.asyncio()
    async def test_different_models_not_deduped(self) -> None:
        dedup = RequestDeduplicator()
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        fp2 = RequestDeduplicator.fingerprint("claude-4-opus", "hello", 0.7)

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return f"response-{call_count}"

        await asyncio.gather(
            dedup.submit(fp1, execute_fn),
            dedup.submit(fp2, execute_fn),
        )
        assert call_count == 2
        assert dedup.stats.dedup_count == 0

    @pytest.mark.asyncio()
    async def test_different_temperatures_not_deduped(self) -> None:
        dedup = RequestDeduplicator()
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.3)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.9)

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return f"response-{call_count}"

        await asyncio.gather(
            dedup.submit(fp1, execute_fn),
            dedup.submit(fp2, execute_fn),
        )
        assert call_count == 2
        assert dedup.stats.dedup_count == 0


# ======================================================================
# RequestDeduplicator — near dedup
# ======================================================================


class TestNearDedup:
    """Tests for near-duplicate detection."""

    @pytest.mark.asyncio()
    async def test_near_identical_prompts_coalesced(self) -> None:
        config = BatchConfig(dedup_similarity=0.85)
        dedup = RequestDeduplicator(config=config)

        fp1 = RequestDeduplicator.fingerprint(
            "gpt-4o", "Explain quantum computing in detail", 0.7
        )
        fp2 = RequestDeduplicator.fingerprint(
            "gpt-4o", "Explain quantum computing in details", 0.7
        )

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return "quantum response"

        results = await asyncio.gather(
            dedup.submit(fp1, execute_fn),
            dedup.submit(fp2, execute_fn),
        )
        assert all(r == "quantum response" for r in results)
        assert call_count == 1
        assert dedup.stats.near_dedup_count == 1

    @pytest.mark.asyncio()
    async def test_dissimilar_prompts_not_near_deduped(self) -> None:
        config = BatchConfig(dedup_similarity=0.95)
        dedup = RequestDeduplicator(config=config)

        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "Write a poem about cats", 0.7)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "Solve this math equation", 0.7)

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return f"response-{call_count}"

        await asyncio.gather(
            dedup.submit(fp1, execute_fn),
            dedup.submit(fp2, execute_fn),
        )
        assert call_count == 2
        assert dedup.stats.near_dedup_count == 0

    @pytest.mark.asyncio()
    async def test_near_dedup_respects_model_boundary(self) -> None:
        """Near-dedup only applies within the same model."""
        config = BatchConfig(dedup_similarity=0.85)
        dedup = RequestDeduplicator(config=config)

        fp1 = RequestDeduplicator.fingerprint(
            "gpt-4o", "Explain quantum computing in detail", 0.7
        )
        fp2 = RequestDeduplicator.fingerprint(
            "claude-4-opus", "Explain quantum computing in details", 0.7
        )

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return f"response-{call_count}"

        await asyncio.gather(
            dedup.submit(fp1, execute_fn),
            dedup.submit(fp2, execute_fn),
        )
        assert call_count == 2
        assert dedup.stats.near_dedup_count == 0

    @pytest.mark.asyncio()
    async def test_near_dedup_respects_temperature_boundary(self) -> None:
        """Near-dedup only applies with the same temperature."""
        config = BatchConfig(dedup_similarity=0.85)
        dedup = RequestDeduplicator(config=config)

        fp1 = RequestDeduplicator.fingerprint(
            "gpt-4o", "Explain quantum computing in detail", 0.3
        )
        fp2 = RequestDeduplicator.fingerprint(
            "gpt-4o", "Explain quantum computing in details", 0.9
        )

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return f"response-{call_count}"

        await asyncio.gather(
            dedup.submit(fp1, execute_fn),
            dedup.submit(fp2, execute_fn),
        )
        assert call_count == 2
        assert dedup.stats.near_dedup_count == 0


# ======================================================================
# TTL expiration
# ======================================================================


class TestTTLExpiration:
    """Tests for pending entry TTL expiration."""

    @pytest.mark.asyncio()
    async def test_expired_entry_not_matched(self) -> None:
        """An expired pending entry should not be reused."""
        config = BatchConfig(pending_ttl_seconds=0.05)
        dedup = RequestDeduplicator(config=config)
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)

        call_count = 0

        async def slow_execute() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.1)
            return f"response-{call_count}"

        async def fast_execute() -> str:
            nonlocal call_count
            call_count += 1
            return f"response-{call_count}"

        # First request is slow, second arrives after TTL
        task1 = asyncio.create_task(dedup.submit(fp, slow_execute))
        await asyncio.sleep(0.08)  # Wait past TTL
        # The pending entry should be expired now; second call makes its own
        task2 = asyncio.create_task(dedup.submit(fp, fast_execute))

        results = await asyncio.gather(task1, task2, return_exceptions=True)
        # Both should complete (no TimeoutError from TTL purge since
        # task1 future was already being awaited)
        successful = [r for r in results if isinstance(r, str)]
        assert len(successful) >= 1

    @pytest.mark.asyncio()
    async def test_purge_sets_timeout_error(self) -> None:
        """Purging expired entries sets TimeoutError on their futures."""
        config = BatchConfig(pending_ttl_seconds=0.01)
        dedup = RequestDeduplicator(config=config)
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)

        # Manually insert a pending entry that's already expired
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        pending = PendingRequest(
            fingerprint=fp,
            future=future,
            timestamp=time.monotonic() - 10.0,
            ttl_seconds=0.01,
        )
        dedup._pending[fp.hash] = pending

        # Trigger purge via a new submit
        async def noop() -> str:
            return "ok"

        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "different", 0.7)
        await dedup.submit(fp2, noop)

        # The expired entry's future should have TimeoutError
        assert future.done()
        with pytest.raises(TimeoutError):
            future.result()


# ======================================================================
# Error propagation
# ======================================================================


class TestErrorPropagation:
    """Tests for error handling in deduplication."""

    @pytest.mark.asyncio()
    async def test_exception_propagated_to_waiters(self) -> None:
        dedup = RequestDeduplicator()
        fp = RequestDeduplicator.fingerprint("gpt-4o", "fail", 0.7)

        async def failing_execute() -> str:
            await asyncio.sleep(0.05)
            raise RuntimeError("API error")

        results = await asyncio.gather(
            dedup.submit(fp, failing_execute),
            dedup.submit(fp, failing_execute),
            return_exceptions=True,
        )
        errors = [r for r in results if isinstance(r, RuntimeError)]
        assert len(errors) >= 1
        assert "API error" in str(errors[0])

    @pytest.mark.asyncio()
    async def test_pending_cleared_after_exception(self) -> None:
        dedup = RequestDeduplicator()
        fp = RequestDeduplicator.fingerprint("gpt-4o", "fail", 0.7)

        async def failing_execute() -> str:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError):
            await dedup.submit(fp, failing_execute)

        assert dedup.pending_count == 0


# ======================================================================
# Statistics tracking
# ======================================================================


class TestStatisticsTracking:
    """Tests for statistics accumulation."""

    @pytest.mark.asyncio()
    async def test_total_requests_counted(self) -> None:
        dedup = RequestDeduplicator()

        async def noop() -> str:
            return "ok"

        for i in range(5):
            fp = RequestDeduplicator.fingerprint("gpt-4o", f"unique-{i}", 0.7)
            await dedup.submit(fp, noop)

        assert dedup.stats.total_requests == 5

    @pytest.mark.asyncio()
    async def test_dedup_with_cost_tracking(self) -> None:
        dedup = RequestDeduplicator()
        fp = RequestDeduplicator.fingerprint("gpt-4o", "same request", 0.7)

        async def execute_fn() -> str:
            await asyncio.sleep(0.05)
            return "result"

        await asyncio.gather(
            dedup.submit(fp, execute_fn, estimated_cost=0.01),
            dedup.submit(fp, execute_fn, estimated_cost=0.01),
            dedup.submit(fp, execute_fn, estimated_cost=0.01),
        )
        assert dedup.stats.saved_cost_usd == pytest.approx(0.02)
        assert dedup.stats.saved_requests == 2

    @pytest.mark.asyncio()
    async def test_reset_stats(self) -> None:
        dedup = RequestDeduplicator()

        async def noop() -> str:
            return "ok"

        fp = RequestDeduplicator.fingerprint("gpt-4o", "test", 0.7)
        await dedup.submit(fp, noop)
        assert dedup.stats.total_requests == 1

        dedup.reset_stats()
        assert dedup.stats.total_requests == 0
        assert dedup.stats.dedup_count == 0


# ======================================================================
# Thread safety / concurrent access
# ======================================================================


class TestConcurrency:
    """Tests for thread safety with concurrent async operations."""

    @pytest.mark.asyncio()
    async def test_many_concurrent_identical_requests(self) -> None:
        dedup = RequestDeduplicator()
        fp = RequestDeduplicator.fingerprint("gpt-4o", "concurrent test", 0.7)

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.1)
            return "shared"

        tasks = [dedup.submit(fp, execute_fn) for _ in range(20)]
        results = await asyncio.gather(*tasks)
        assert all(r == "shared" for r in results)
        assert call_count == 1
        assert dedup.stats.dedup_count == 19

    @pytest.mark.asyncio()
    async def test_mixed_concurrent_requests(self) -> None:
        dedup = RequestDeduplicator()

        call_count = 0

        async def execute_fn() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return f"result-{call_count}"

        fps = [
            RequestDeduplicator.fingerprint("gpt-4o", "query-a", 0.7),
            RequestDeduplicator.fingerprint("gpt-4o", "query-a", 0.7),
            RequestDeduplicator.fingerprint("gpt-4o", "query-b", 0.7),
            RequestDeduplicator.fingerprint("gpt-4o", "query-b", 0.7),
            RequestDeduplicator.fingerprint("claude-4-opus", "query-a", 0.7),
        ]

        tasks = [dedup.submit(fp, execute_fn) for fp in fps]
        await asyncio.gather(*tasks)
        # 3 unique (gpt-4o/query-a, gpt-4o/query-b, claude/query-a)
        assert call_count == 3
        assert dedup.stats.dedup_count == 2


# ======================================================================
# Clear
# ======================================================================


class TestClear:
    """Tests for clearing deduplicator state."""

    @pytest.mark.asyncio()
    async def test_clear_removes_all_pending(self) -> None:
        dedup = RequestDeduplicator()
        # Manually insert a pending entry
        fp = RequestDeduplicator.fingerprint("gpt-4o", "hello", 0.7)
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        pending = PendingRequest(
            fingerprint=fp,
            future=future,
            timestamp=time.monotonic(),
        )
        dedup._pending[fp.hash] = pending

        await dedup.clear()
        assert dedup.pending_count == 0
        assert future.cancelled()


# ======================================================================
# RequestBatcher — batch timeout integration
# ======================================================================


class TestBatchTimeoutIntegration:
    """Integration tests for batch timeout behaviour."""

    @pytest.mark.asyncio()
    async def test_batch_timeout_flushes_partial(self) -> None:
        batcher = RequestBatcher(
            BatchConfig(max_batch_size=100, batch_timeout_ms=50)
        )
        fp1 = RequestDeduplicator.fingerprint("gpt-4o", "a", 0.7)
        fp2 = RequestDeduplicator.fingerprint("gpt-4o", "b", 0.7)
        await batcher.add(fp1, {"prompt": "a"})
        await batcher.add(fp2, {"prompt": "b"})

        await asyncio.sleep(0.1)
        flushed = await batcher.flush_timed_out()
        assert len(flushed) == 1
        assert flushed[0].size == 2

    @pytest.mark.asyncio()
    async def test_batch_stats_accumulate(self) -> None:
        batcher = RequestBatcher(BatchConfig(max_batch_size=2, batch_timeout_ms=5000))
        for i in range(4):
            fp = RequestDeduplicator.fingerprint("gpt-4o", f"msg{i}", 0.7)
            await batcher.add(fp, {"prompt": f"msg{i}"})

        assert batcher.stats.batch_count == 2
        assert batcher.stats.total_requests == 4
        # Each batch of 2 saves 1
        assert batcher.stats.saved_requests == 2
