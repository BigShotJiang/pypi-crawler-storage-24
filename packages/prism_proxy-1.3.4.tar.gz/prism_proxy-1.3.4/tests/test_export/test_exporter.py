"""Tests for prism.export.exporter — conversation, session, and report export."""

from __future__ import annotations

import json

import pytest

from prism.export.exporter import (
    ConversationExporter,
    CostEntry,
    ExportMetadata,
    Message,
    QualityEntry,
    ReportGenerator,
    SessionData,
    SessionExporter,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_messages() -> list[Message]:
    """A minimal two-message conversation."""
    return [
        Message(role="user", content="Hello, world!", timestamp="2026-03-13T10:00:00Z"),
        Message(
            role="assistant",
            content="Hi! How can I help you?",
            timestamp="2026-03-13T10:00:01Z",
            model="gpt-4o",
            tokens=12,
            cost=0.0001,
        ),
    ]


@pytest.fixture
def sample_metadata() -> ExportMetadata:
    """Metadata with all fields populated."""
    return ExportMetadata(
        session_id="sess-001",
        model_used="gpt-4o",
        total_cost=0.0042,
        timestamp="2026-03-13T10:00:00Z",
        files_referenced=["src/main.py", "README.md"],
    )


@pytest.fixture
def sample_session(sample_messages: list[Message]) -> SessionData:
    """A complete session."""
    return SessionData(
        session_id="sess-001",
        messages=sample_messages,
        model_selections=[
            {"model": "gpt-4o", "reason": "cost"},
            {"model": "claude-3-opus", "reason": "quality"},
        ],
        total_cost=0.005,
        total_tokens=500,
        start_time="2026-03-13T10:00:00Z",
        end_time="2026-03-13T10:05:00Z",
        metadata={"project": "prism"},
    )


@pytest.fixture
def cost_entries() -> list[CostEntry]:
    """Sample cost entries spanning multiple days and models."""
    return [
        CostEntry(date="2026-03-10", model="gpt-4o", requests=5, tokens=1000, cost=0.01),
        CostEntry(date="2026-03-10", model="claude-3-opus", requests=3, tokens=800, cost=0.02),
        CostEntry(date="2026-03-11", model="gpt-4o", requests=7, tokens=1500, cost=0.015),
        CostEntry(date="2026-03-12", model="gpt-4o", requests=2, tokens=400, cost=0.004),
    ]


@pytest.fixture
def quality_entries() -> list[QualityEntry]:
    """Sample quality observations."""
    return [
        QualityEntry(
            date="2026-03-10", model="gpt-4o",
            success_rate=0.95, avg_latency_ms=200, error_count=1,
        ),
        QualityEntry(
            date="2026-03-11", model="gpt-4o",
            success_rate=0.90, avg_latency_ms=250, error_count=2,
        ),
        QualityEntry(
            date="2026-03-10", model="claude-3-opus",
            success_rate=1.0, avg_latency_ms=300, error_count=0,
        ),
    ]


# ===========================================================================
# ConversationExporter — JSON
# ===========================================================================

class TestConversationExporterJson:
    """Tests for ConversationExporter.to_json."""

    def test_json_valid_output(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_json(sample_messages, sample_metadata)
        parsed = json.loads(result)
        assert "messages" in parsed
        assert len(parsed["messages"]) == 2

    def test_json_includes_metadata(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_json(sample_messages, sample_metadata)
        parsed = json.loads(result)
        assert parsed["metadata"]["session_id"] == "sess-001"
        assert parsed["metadata"]["model_used"] == "gpt-4o"

    def test_json_without_metadata(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_json(sample_messages)
        parsed = json.loads(result)
        assert "metadata" not in parsed
        assert len(parsed["messages"]) == 2

    def test_json_empty_messages(self) -> None:
        result = ConversationExporter.to_json([])
        parsed = json.loads(result)
        assert parsed["messages"] == []

    def test_json_message_fields_preserved(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_json(sample_messages)
        parsed = json.loads(result)
        msg = parsed["messages"][1]
        assert msg["role"] == "assistant"
        assert msg["model"] == "gpt-4o"
        assert msg["tokens"] == 12
        assert msg["cost"] == 0.0001


# ===========================================================================
# ConversationExporter — Markdown
# ===========================================================================

class TestConversationExporterMarkdown:
    """Tests for ConversationExporter.to_markdown."""

    def test_markdown_has_header(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_markdown(sample_messages, sample_metadata)
        assert result.startswith("# Conversation Export")

    def test_markdown_includes_model_info(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_markdown(sample_messages, sample_metadata)
        assert "gpt-4o" in result

    def test_markdown_includes_cost(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_markdown(sample_messages, sample_metadata)
        assert "$0.004200" in result

    def test_markdown_includes_files(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_markdown(sample_messages, sample_metadata)
        assert "`src/main.py`" in result
        assert "`README.md`" in result

    def test_markdown_role_headers(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_markdown(sample_messages)
        assert "### User" in result
        assert "### Assistant" in result

    def test_markdown_without_metadata(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_markdown(sample_messages)
        assert "## Metadata" not in result
        assert "## Messages" in result


# ===========================================================================
# ConversationExporter — HTML
# ===========================================================================

class TestConversationExporterHtml:
    """Tests for ConversationExporter.to_html."""

    def test_html_is_complete_document(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_html(sample_messages, sample_metadata)
        assert "<!DOCTYPE html>" in result
        assert "</html>" in result

    def test_html_includes_style(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_html(sample_messages)
        assert "<style>" in result

    def test_html_escapes_content(self) -> None:
        msgs = [Message(role="user", content="<script>alert('xss')</script>")]
        result = ConversationExporter.to_html(msgs)
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_html_metadata_section(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_html(sample_messages, sample_metadata)
        assert "sess-001" in result
        assert "class='metadata'" in result

    def test_html_message_classes(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_html(sample_messages)
        assert "class='message user'" in result
        assert "class='message assistant'" in result


# ===========================================================================
# ConversationExporter — Text
# ===========================================================================

class TestConversationExporterText:
    """Tests for ConversationExporter.to_text."""

    def test_text_role_prefixes(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_text(sample_messages)
        assert "[USER]" in result
        assert "[ASSISTANT]" in result

    def test_text_with_metadata(
        self, sample_messages: list[Message], sample_metadata: ExportMetadata
    ) -> None:
        result = ConversationExporter.to_text(sample_messages, sample_metadata)
        assert "=== Conversation Export ===" in result
        assert "Session: sess-001" in result

    def test_text_content_preserved(self, sample_messages: list[Message]) -> None:
        result = ConversationExporter.to_text(sample_messages)
        assert "Hello, world!" in result

    def test_text_empty_messages(self) -> None:
        result = ConversationExporter.to_text([])
        assert result == ""


# ===========================================================================
# SessionExporter
# ===========================================================================

class TestSessionExporter:
    """Tests for SessionExporter."""

    def test_export_full_has_all_fields(self, sample_session: SessionData) -> None:
        result = SessionExporter.export_full(sample_session)
        assert result["session_id"] == "sess-001"
        assert result["total_cost"] == 0.005
        assert len(result["messages"]) == 2
        assert len(result["model_selections"]) == 2

    def test_export_summary_no_content(self, sample_session: SessionData) -> None:
        result = SessionExporter.export_summary(sample_session)
        assert "messages" not in result
        assert result["message_count"] == 2

    def test_export_summary_model_counts(self, sample_session: SessionData) -> None:
        result = SessionExporter.export_summary(sample_session)
        assert result["models_used"]["gpt-4o"] == 1
        assert result["models_used"]["claude-3-opus"] == 1

    def test_export_summary_role_counts(self, sample_session: SessionData) -> None:
        result = SessionExporter.export_summary(sample_session)
        assert result["messages_by_role"]["user"] == 1
        assert result["messages_by_role"]["assistant"] == 1

    def test_batch_export(self, sample_session: SessionData) -> None:
        result = SessionExporter.batch_export([sample_session, sample_session])
        assert len(result) == 2
        assert result[0]["session_id"] == "sess-001"

    def test_batch_export_empty(self) -> None:
        result = SessionExporter.batch_export([])
        assert result == []


# ===========================================================================
# ReportGenerator
# ===========================================================================

class TestReportGeneratorCost:
    """Tests for ReportGenerator.cost_report."""

    def test_daily_report_has_table(self, cost_entries: list[CostEntry]) -> None:
        result = ReportGenerator.cost_report(cost_entries, period="daily")
        assert "| Period |" in result
        assert "2026-03-10" in result

    def test_monthly_report_groups(self, cost_entries: list[CostEntry]) -> None:
        result = ReportGenerator.cost_report(cost_entries, period="monthly")
        assert "2026-03" in result

    def test_weekly_report_groups(self, cost_entries: list[CostEntry]) -> None:
        result = ReportGenerator.cost_report(cost_entries, period="weekly")
        assert "-W" in result

    def test_cost_report_totals(self, cost_entries: list[CostEntry]) -> None:
        result = ReportGenerator.cost_report(cost_entries, period="daily")
        assert "**Total**" in result

    def test_cost_report_empty(self) -> None:
        result = ReportGenerator.cost_report([])
        assert "No data available" in result


class TestReportGeneratorModelUsage:
    """Tests for ReportGenerator.model_usage_report."""

    def test_model_report_has_table(self, cost_entries: list[CostEntry]) -> None:
        result = ReportGenerator.model_usage_report(cost_entries)
        assert "| Model |" in result
        assert "gpt-4o" in result
        assert "claude-3-opus" in result

    def test_model_report_empty(self) -> None:
        result = ReportGenerator.model_usage_report([])
        assert "No data available" in result


class TestReportGeneratorQuality:
    """Tests for ReportGenerator.quality_trend_report."""

    def test_quality_report_has_table(self, quality_entries: list[QualityEntry]) -> None:
        result = ReportGenerator.quality_trend_report(quality_entries)
        assert "| Date |" in result
        assert "gpt-4o" in result

    def test_quality_report_summary(self, quality_entries: list[QualityEntry]) -> None:
        result = ReportGenerator.quality_trend_report(quality_entries)
        assert "**Overall:**" in result

    def test_quality_report_empty(self) -> None:
        result = ReportGenerator.quality_trend_report([])
        assert "No data available" in result
