"""Tests for the request pipeline orchestrator."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from prism.orchestrator.pipeline import (
    PipelineConfig,
    PipelineMiddleware,
    PipelineResult,
    PipelineStage,
    RequestPipeline,
    StageResult,
)


@pytest.fixture()
def pipeline() -> RequestPipeline:
    return RequestPipeline()


@pytest.fixture()
def configured_pipeline() -> RequestPipeline:
    """Pipeline with mock executor."""
    p = RequestPipeline(PipelineConfig(
        enable_cache=False,
        enable_compression=False,
        enable_rate_limiting=False,
        enable_validation=False,
        enable_learning=False,
    ))

    async def mock_executor(prompt: str, model: str, messages: list | None) -> dict:
        return {
            "content": f"Response to: {prompt[:20]}",
            "tokens_in": 100,
            "tokens_out": 50,
        }

    p.set_executor(mock_executor)
    return p


# ---------------------------------------------------------------------------
# Basic execution tests
# ---------------------------------------------------------------------------


class TestBasicExecution:
    """Tests for basic pipeline execution."""

    @pytest.mark.asyncio()
    async def test_execute_with_executor(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Hello, world!")
        assert isinstance(result, PipelineResult)
        assert result.content.startswith("Response to:")
        assert result.success

    @pytest.mark.asyncio()
    async def test_execute_without_executor(self, pipeline: RequestPipeline) -> None:
        result = await pipeline.execute("Hello")
        assert result.content == ""

    @pytest.mark.asyncio()
    async def test_result_has_timing(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test prompt")
        assert result.total_duration_ms > 0

    @pytest.mark.asyncio()
    async def test_result_has_stages(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test prompt")
        assert len(result.stages) > 0
        for stage in result.stages:
            assert isinstance(stage, StageResult)

    @pytest.mark.asyncio()
    async def test_model_selection_default(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Simple question")
        assert result.model_used != ""

    @pytest.mark.asyncio()
    async def test_model_hint_respected(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test", model_hint="my-model")
        assert result.model_used == "my-model"


# ---------------------------------------------------------------------------
# Classification tests
# ---------------------------------------------------------------------------


class TestClassification:
    """Tests for task classification stage."""

    @pytest.mark.asyncio()
    async def test_short_prompt_simple(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Hi")
        classify_stage = next(
            s for s in result.stages if s.stage == PipelineStage.CLASSIFY
        )
        assert classify_stage.data.get("complexity") == "simple"

    @pytest.mark.asyncio()
    async def test_task_type_override(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test", task_type="complex")
        classify_stage = next(
            s for s in result.stages if s.stage == PipelineStage.CLASSIFY
        )
        assert classify_stage.data.get("complexity") == "complex"

    @pytest.mark.asyncio()
    async def test_long_prompt_complex(self, configured_pipeline: RequestPipeline) -> None:
        long_prompt = " ".join(["word"] * 150)
        result = await configured_pipeline.execute(long_prompt)
        classify_stage = next(
            s for s in result.stages if s.stage == PipelineStage.CLASSIFY
        )
        assert classify_stage.data.get("complexity") == "complex"


# ---------------------------------------------------------------------------
# Routing tests
# ---------------------------------------------------------------------------


class TestRouting:
    """Tests for model routing stage."""

    @pytest.mark.asyncio()
    async def test_default_routing_simple(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Hi", task_type="simple")
        assert result.model_used == "gpt-4o-mini"

    @pytest.mark.asyncio()
    async def test_default_routing_complex(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("complex task", task_type="complex")
        assert "claude" in result.model_used or "sonnet" in result.model_used

    @pytest.mark.asyncio()
    async def test_custom_router(self) -> None:
        p = RequestPipeline(PipelineConfig(
            enable_cache=False, enable_compression=False,
            enable_rate_limiting=False, enable_validation=False,
            enable_learning=False,
        ))
        router = MagicMock()
        router.select.return_value = "custom-model"
        p.set_router(router)

        async def mock_exec(prompt, model, messages):
            return {"content": "ok", "tokens_in": 10, "tokens_out": 5}

        p.set_executor(mock_exec)
        result = await p.execute("Test")
        assert result.model_used == "custom-model"


# ---------------------------------------------------------------------------
# Cache tests
# ---------------------------------------------------------------------------


class TestCache:
    """Tests for caching stages."""

    @pytest.mark.asyncio()
    async def test_cache_hit(self) -> None:
        p = RequestPipeline(PipelineConfig(
            enable_cache=True, enable_compression=False,
            enable_rate_limiting=False, enable_validation=False,
            enable_learning=False,
        ))

        cache = MagicMock()
        cached_entry = MagicMock()
        cached_entry.content = "Cached response"
        cache.get.return_value = cached_entry
        p.set_cache(cache)

        result = await p.execute("Test prompt")
        assert result.from_cache
        assert result.content == "Cached response"

    @pytest.mark.asyncio()
    async def test_cache_miss(self) -> None:
        p = RequestPipeline(PipelineConfig(
            enable_cache=True, enable_compression=False,
            enable_rate_limiting=False, enable_validation=False,
            enable_learning=False,
        ))

        cache = MagicMock()
        cache.get.return_value = None
        p.set_cache(cache)

        async def mock_exec(prompt, model, messages):
            return {"content": "Fresh response", "tokens_in": 10, "tokens_out": 5}

        p.set_executor(mock_exec)
        result = await p.execute("Test prompt")
        assert not result.from_cache
        assert result.content == "Fresh response"

    @pytest.mark.asyncio()
    async def test_cache_disabled(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test")
        cache_stages = [s for s in result.stages if s.stage == PipelineStage.CACHE_CHECK]
        assert all(s.skipped for s in cache_stages)


# ---------------------------------------------------------------------------
# Middleware tests
# ---------------------------------------------------------------------------


class TestMiddleware:
    """Tests for pipeline middleware."""

    @pytest.mark.asyncio()
    async def test_middleware_before_execute(self, configured_pipeline: RequestPipeline) -> None:
        class UpperMiddleware(PipelineMiddleware):
            async def before_execute(self, prompt, model, context):
                return prompt.upper(), model, context

        configured_pipeline.add_middleware(UpperMiddleware("upper"))
        result = await configured_pipeline.execute("hello")
        # The executor receives the uppercased prompt
        assert result.success

    @pytest.mark.asyncio()
    async def test_middleware_after_execute(self, configured_pipeline: RequestPipeline) -> None:
        class TagMiddleware(PipelineMiddleware):
            async def after_execute(self, result, context):
                result.metadata["tagged"] = True
                return result

        configured_pipeline.add_middleware(TagMiddleware("tagger"))
        result = await configured_pipeline.execute("Test")
        assert result.metadata.get("tagged") is True

    @pytest.mark.asyncio()
    async def test_multiple_middleware(self, configured_pipeline: RequestPipeline) -> None:
        calls: list[str] = []

        class MW1(PipelineMiddleware):
            async def before_execute(self, prompt, model, ctx):
                calls.append("mw1")
                return prompt, model, ctx

        class MW2(PipelineMiddleware):
            async def before_execute(self, prompt, model, ctx):
                calls.append("mw2")
                return prompt, model, ctx

        configured_pipeline.add_middleware(MW1("mw1"))
        configured_pipeline.add_middleware(MW2("mw2"))
        await configured_pipeline.execute("Test")
        assert calls == ["mw1", "mw2"]


# ---------------------------------------------------------------------------
# Cost tracking tests
# ---------------------------------------------------------------------------


class TestCostTracking:
    """Tests for cost tracking stage."""

    @pytest.mark.asyncio()
    async def test_cost_estimated(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test")
        assert result.cost_usd >= 0

    @pytest.mark.asyncio()
    async def test_tokens_tracked(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test")
        assert result.tokens_in > 0 or result.tokens_out > 0


# ---------------------------------------------------------------------------
# Stage timing tests
# ---------------------------------------------------------------------------


class TestStageTiming:
    """Tests for stage timing."""

    @pytest.mark.asyncio()
    async def test_stage_timings_available(self, configured_pipeline: RequestPipeline) -> None:
        result = await configured_pipeline.execute("Test")
        timings = result.stage_timings
        assert isinstance(timings, dict)
        assert "classify" in timings
        assert "route" in timings
        assert "execute" in timings


# ---------------------------------------------------------------------------
# Error handling tests
# ---------------------------------------------------------------------------


class TestErrorHandling:
    """Tests for pipeline error handling."""

    @pytest.mark.asyncio()
    async def test_executor_error_handled(self) -> None:
        p = RequestPipeline(PipelineConfig(
            enable_cache=False, enable_compression=False,
            enable_rate_limiting=False, enable_validation=False,
            enable_learning=False,
        ))

        async def failing_executor(prompt, model, messages):
            msg = "API error"
            raise RuntimeError(msg)

        p.set_executor(failing_executor)
        result = await p.execute("Test")
        assert not result.success
        execute_stage = next(
            (s for s in result.stages if s.stage == PipelineStage.EXECUTE), None,
        )
        assert execute_stage is not None
        assert not execute_stage.success

    @pytest.mark.asyncio()
    async def test_pipeline_doesnt_crash(self, pipeline: RequestPipeline) -> None:
        """Pipeline should never raise — always return a result."""
        result = await pipeline.execute("")
        assert isinstance(result, PipelineResult)


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


class TestConfig:
    """Tests for pipeline configuration."""

    def test_default_config(self) -> None:
        config = PipelineConfig()
        assert config.enable_cache is True
        assert config.max_retries == 2

    def test_custom_config(self) -> None:
        config = PipelineConfig(enable_cache=False, max_retries=5)
        assert config.enable_cache is False
        assert config.max_retries == 5

    @pytest.mark.asyncio()
    async def test_stages_skipped_when_disabled(self) -> None:
        p = RequestPipeline(PipelineConfig(
            enable_cache=False,
            enable_compression=False,
            enable_rate_limiting=False,
            enable_validation=False,
            enable_learning=False,
        ))

        async def mock_exec(prompt, model, messages):
            return {"content": "ok", "tokens_in": 1, "tokens_out": 1}

        p.set_executor(mock_exec)
        result = await p.execute("Test")
        skipped = [s for s in result.stages if s.skipped]
        assert len(skipped) >= 4  # cache, compress, validate, learn
