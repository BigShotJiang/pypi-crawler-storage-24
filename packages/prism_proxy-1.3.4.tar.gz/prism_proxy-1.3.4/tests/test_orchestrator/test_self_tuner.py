"""Tests for self-tuning cascade thresholds."""

from __future__ import annotations

import pytest

from prism.orchestrator.self_tuner import CascadeSelfTuner, TierStats, TuningEvent


class TestCascadeSelfTuner:
    """Tests for the CascadeSelfTuner class."""

    @pytest.fixture()
    def tuner(self) -> CascadeSelfTuner:
        return CascadeSelfTuner(min_samples=5)

    def test_default_thresholds(self, tuner: CascadeSelfTuner) -> None:
        thresholds = tuner.get_all_thresholds()
        assert thresholds["cheap"] == pytest.approx(0.85, abs=0.01)
        assert thresholds["medium"] == pytest.approx(0.75, abs=0.01)
        assert thresholds["premium"] == pytest.approx(0.6, abs=0.01)

    def test_custom_thresholds(self) -> None:
        tuner = CascadeSelfTuner(
            initial_thresholds={"fast": 0.9, "slow": 0.5},
        )
        assert tuner.get_threshold("fast") == pytest.approx(0.9, abs=0.01)
        assert tuner.get_threshold("slow") == pytest.approx(0.5, abs=0.01)

    def test_unknown_tier_default(self, tuner: CascadeSelfTuner) -> None:
        assert tuner.get_threshold("nonexistent") == 0.7

    def test_record_acceptance(self, tuner: CascadeSelfTuner) -> None:
        tuner.record_acceptance("cheap", 0.9)
        stats = tuner.get_stats("cheap")
        assert stats is not None
        assert stats.accepted_count == 1
        assert stats.total_attempts == 1

    def test_record_escalation(self, tuner: CascadeSelfTuner) -> None:
        tuner.record_escalation("cheap", 0.5)
        stats = tuner.get_stats("cheap")
        assert stats is not None
        assert stats.escalated_count == 1

    def test_record_feedback(self, tuner: CascadeSelfTuner) -> None:
        tuner.record_feedback("cheap", positive=True)
        tuner.record_feedback("cheap", positive=False)
        stats = tuner.get_stats("cheap")
        assert stats is not None
        assert stats.positive_feedback_count == 1
        assert stats.negative_feedback_count == 1

    def test_high_escalation_lowers_threshold(self) -> None:
        tuner = CascadeSelfTuner(
            initial_thresholds={"test": 0.85},
            min_samples=5,
            alpha=0.3,
            escalation_penalty=0.1,
        )
        # Record mostly escalations
        for _ in range(8):
            tuner.record_escalation("test", 0.7)
        for _ in range(2):
            tuner.record_acceptance("test", 0.9)

        threshold = tuner.get_threshold("test")
        assert threshold < 0.85  # Should have lowered

    def test_negative_feedback_raises_threshold(self) -> None:
        tuner = CascadeSelfTuner(
            initial_thresholds={"test": 0.6},
            min_samples=5,
            alpha=0.3,
            feedback_reward=0.1,
        )
        # Record acceptances first to get enough samples
        for _ in range(6):
            tuner.record_acceptance("test", 0.65)

        # Then record lots of negative feedback
        for _ in range(5):
            tuner.record_feedback("test", positive=False)
        tuner.record_feedback("test", positive=True)

        threshold = tuner.get_threshold("test")
        assert threshold >= 0.6  # Should stay same or increase

    def test_no_tuning_below_min_samples(self) -> None:
        tuner = CascadeSelfTuner(
            initial_thresholds={"test": 0.8},
            min_samples=20,
        )
        # Only 5 samples — not enough
        for _ in range(5):
            tuner.record_escalation("test", 0.5)

        assert tuner.get_threshold("test") == pytest.approx(0.8, abs=0.01)
        assert len(tuner.get_tuning_history()) == 0

    def test_threshold_bounds(self) -> None:
        tuner = CascadeSelfTuner(
            initial_thresholds={"low": 0.35, "high": 0.93},
            min_samples=3,
            alpha=0.5,
            escalation_penalty=0.5,
        )
        # Try to push threshold below minimum
        for _ in range(20):
            tuner.record_escalation("low", 0.1)

        assert tuner.get_threshold("low") >= 0.3  # Min bound

    def test_tuning_history(self) -> None:
        tuner = CascadeSelfTuner(
            initial_thresholds={"test": 0.85},
            min_samples=5,
            alpha=0.3,
            escalation_penalty=0.1,
        )
        for _ in range(10):
            tuner.record_escalation("test", 0.6)

        history = tuner.get_tuning_history()
        assert len(history) >= 1
        assert all(isinstance(e, TuningEvent) for e in history)
        assert history[0].tier == "test"
        assert history[0].old_threshold != history[0].new_threshold

    def test_reset_single_tier(self, tuner: CascadeSelfTuner) -> None:
        for _ in range(10):
            tuner.record_acceptance("cheap", 0.9)
        tuner.reset("cheap")
        stats = tuner.get_stats("cheap")
        assert stats is not None
        assert stats.total_attempts == 0
        assert stats.current_threshold == pytest.approx(0.85, abs=0.01)

    def test_reset_all(self, tuner: CascadeSelfTuner) -> None:
        for _ in range(10):
            tuner.record_acceptance("cheap", 0.9)
            tuner.record_escalation("medium", 0.5)
        tuner.reset()
        for tier in ["cheap", "medium", "premium"]:
            stats = tuner.get_stats(tier)
            assert stats is not None
            assert stats.total_attempts == 0

    def test_get_all_stats(self, tuner: CascadeSelfTuner) -> None:
        tuner.record_acceptance("cheap", 0.9)
        all_stats = tuner.get_all_stats()
        assert "cheap" in all_stats
        assert isinstance(all_stats["cheap"], TierStats)

    def test_new_tier_created_on_record(self, tuner: CascadeSelfTuner) -> None:
        # Recording for a new tier should auto-create it
        tuner.record_acceptance("brand-new", 0.8)
        stats = tuner.get_stats("brand-new")
        assert stats is not None
        assert stats.tier == "brand-new"
        assert stats.current_threshold == 0.7  # default for new tiers

    def test_stable_workload_optimises_cost(self) -> None:
        tuner = CascadeSelfTuner(
            initial_thresholds={"test": 0.85},
            min_samples=5,
            alpha=0.2,
            escalation_penalty=0.05,
        )
        # Simulate a stable workload with low escalation, good results
        for _ in range(15):
            tuner.record_acceptance("test", 0.9)
        for _ in range(2):
            tuner.record_escalation("test", 0.8)
        # No negative feedback
        for _ in range(5):
            tuner.record_feedback("test", positive=True)

        # Threshold should have decreased slightly (cost optimisation)
        threshold = tuner.get_threshold("test")
        assert threshold <= 0.85
