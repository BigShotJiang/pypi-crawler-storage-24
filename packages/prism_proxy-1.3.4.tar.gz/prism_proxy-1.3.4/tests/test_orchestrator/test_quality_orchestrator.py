"""Tests for the quality orchestrator module.

All tests use async mock completion functions — no real API calls.
"""

from __future__ import annotations

from typing import Any

import pytest

from prism.orchestrator.quality_orchestrator import (
    DomainClassifier,
    ModelConfig,
    QualityConfig,
    QualityOrchestrator,
    QualityResult,
    QualityStrategy,
    ResponseScorer,
    SpecializedRouter,
    TaskDomain,
    detect_best_strategy,
)

# ======================================================================
# Mock completion function
# ======================================================================


async def mock_completion(
    model: str,
    messages: list[dict[str, Any]],
    **kwargs: Any,
) -> dict[str, Any]:
    """Mock completion that returns varied responses based on input."""
    # Detect if this is a critique request
    system_content = ""
    user_content = ""
    for msg in messages:
        if msg.get("role") == "system":
            system_content += msg.get("content", "")
        if msg.get("role") == "user":
            user_content += msg.get("content", "")

    if "expert reviewer" in system_content.lower():
        content = (
            "The response has a few issues:\n"
            "1. Missing error handling for edge cases\n"
            "2. Could be more specific with examples\n"
            "3. The explanation of time complexity is incomplete"
        )
    elif "expert synthesizer" in system_content.lower():
        content = (
            "Here's a comprehensive, well-structured answer. "
            "The solution involves the following steps. "
            "First, we initialize the data structure. "
            "For example, consider this specific case with 42 items. "
            "The answer is that the algorithm runs in O(log n) time. "
            "```python\ndef search(arr: list[int], target: int) -> int:\n"
            '    """Binary search implementation."""\n'
            "    if not arr:\n"
            '        raise ValueError("Empty array")\n'
            "    left, right = 0, len(arr) - 1\n"
            "    while left <= right:\n"
            "        mid = (left + right) // 2\n"
            "        if arr[mid] == target:\n"
            "            return mid\n"
            "    return -1\n```"
        )
    elif "improve" in user_content.lower():
        content = (
            "Here is the improved response. "
            "The answer is clear and well-structured. "
            "First, we handle the edge cases properly. "
            "For example, when the input is empty we return -1. "
            "Additionally, we validate all inputs. "
            "The solution handles 100 different scenarios. "
            "```python\ndef improved() -> str:\n"
            '    """Improved function."""\n'
            "    return 'better'\n```"
        )
    elif "opus" in model or "gpt-4o" in model:
        content = (
            "Here's a comprehensive, well-structured answer with "
            "specific examples. First, we need to consider the "
            "problem carefully. The answer is that we should use "
            "a binary search approach because it provides O(log n) "
            "time complexity. For example, given an array of 1000 "
            "elements, we only need about 10 comparisons. "
            "Additionally, this approach handles edge cases well. "
            "```python\ndef binary_search(arr: list, target: int) -> int:\n"
            '    """Search for target in sorted array."""\n'
            "    if not arr:\n"
            '        raise ValueError("Empty array")\n'
            "    left, right = 0, len(arr) - 1\n"
            "    while left <= right:\n"
            "        mid = (left + right) // 2\n"
            "        if arr[mid] == target:\n"
            "            return mid\n"
            "        elif arr[mid] < target:\n"
            "            left = mid + 1\n"
            "        else:\n"
            "            right = mid - 1\n"
            "    return -1\n```"
        )
    elif "mini" in model or "flash" in model:
        content = "Short answer."
    elif "deepseek" in model:
        content = (
            "```python\ndef solve(n: int) -> int:\n"
            '    """Solve the problem efficiently."""\n'
            "    if n <= 0:\n"
            '        raise ValueError("n must be positive")\n'
            "    # Use dynamic programming\n"
            "    dp = [0] * (n + 1)\n"
            "    for i in range(1, n + 1):\n"
            "        dp[i] = dp[i-1] + i\n"
            "    return dp[n]\n```\n\n"
            "The solution uses dynamic programming. "
            "The answer is O(n) time and O(n) space."
        )
    else:
        content = (
            f"Response from {model}: This is a detailed answer "
            "with some explanation. The result is clear. "
            "For example, consider the case where n equals 5."
        )

    return {
        "choices": [
            {
                "message": {"content": content},
                "finish_reason": "stop",
            },
        ],
        "usage": {
            "prompt_tokens": 100,
            "completion_tokens": 200,
            "total_tokens": 300,
        },
    }


async def mock_completion_failing(
    model: str,
    messages: list[dict[str, Any]],
    **kwargs: Any,
) -> dict[str, Any]:
    """Mock completion that raises for specific models."""
    if "fail" in model:
        msg = f"Model {model} is unavailable"
        raise ConnectionError(msg)
    return await mock_completion(model, messages, **kwargs)


async def mock_completion_empty(
    model: str,
    messages: list[dict[str, Any]],
    **kwargs: Any,
) -> dict[str, Any]:
    """Mock completion that returns empty content."""
    return {
        "choices": [
            {
                "message": {"content": ""},
                "finish_reason": "stop",
            },
        ],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 0,
            "total_tokens": 10,
        },
    }


async def mock_completion_alt_format(
    model: str,
    messages: list[dict[str, Any]],
    **kwargs: Any,
) -> dict[str, Any]:
    """Mock completion returning content in alt format (no choices)."""
    return {
        "content": "Alternative format response with specific data 42.",
        "usage": {
            "input_tokens": 50,
            "output_tokens": 100,
        },
    }


# ======================================================================
# Fixtures
# ======================================================================


@pytest.fixture()
def scorer() -> ResponseScorer:
    """Fresh ResponseScorer instance."""
    return ResponseScorer()


@pytest.fixture()
def classifier() -> DomainClassifier:
    """Fresh DomainClassifier instance."""
    return DomainClassifier()


@pytest.fixture()
def two_model_config() -> QualityConfig:
    """Config with two models from different providers."""
    return QualityConfig(
        models=[
            ModelConfig(
                model_id="anthropic/claude-opus-4",
                provider="anthropic",
                strengths=[TaskDomain.CREATIVE_WRITING, TaskDomain.CODE],
                cost_per_1k_input=0.015,
                cost_per_1k_output=0.075,
            ),
            ModelConfig(
                model_id="openai/gpt-4o",
                provider="openai",
                strengths=[TaskDomain.GENERAL],
                cost_per_1k_input=0.005,
                cost_per_1k_output=0.015,
            ),
        ],
    )


@pytest.fixture()
def three_model_config() -> QualityConfig:
    """Config with three models from different providers."""
    return QualityConfig(
        models=[
            ModelConfig(
                model_id="anthropic/claude-opus-4",
                provider="anthropic",
                cost_per_1k_input=0.015,
                cost_per_1k_output=0.075,
            ),
            ModelConfig(
                model_id="openai/gpt-4o",
                provider="openai",
                cost_per_1k_input=0.005,
                cost_per_1k_output=0.015,
            ),
            ModelConfig(
                model_id="deepseek/deepseek-coder",
                provider="deepseek",
                cost_per_1k_input=0.001,
                cost_per_1k_output=0.002,
            ),
        ],
    )


@pytest.fixture()
def thinking_model_config() -> QualityConfig:
    """Config with a model that supports extended thinking."""
    return QualityConfig(
        models=[
            ModelConfig(
                model_id="openai/o3",
                provider="openai",
                supports_thinking=True,
                strengths=[TaskDomain.MATH, TaskDomain.REASONING],
            ),
            ModelConfig(
                model_id="anthropic/claude-opus-4",
                provider="anthropic",
            ),
        ],
    )


# ======================================================================
# ResponseScorer tests
# ======================================================================


class TestResponseScorer:
    """Tests for ResponseScorer."""

    def test_high_quality_response_scores_high(
        self, scorer: ResponseScorer,
    ) -> None:
        """A detailed, well-structured response should score high."""
        prompt = "Write a binary search function in Python"
        response = (
            "Here's how to implement binary search. "
            "The answer is that we use a divide-and-conquer approach. "
            "First, we compare the target with the middle element. "
            "For example, searching for 42 in [1, 5, 42, 99]:\n\n"
            "```python\ndef binary_search(arr: list[int], target: int)"
            " -> int:\n"
            '    """Search for target in sorted array."""\n'
            "    if not arr:\n"
            '        raise ValueError("Empty")\n'
            "    left, right = 0, len(arr) - 1\n"
            "    while left <= right:\n"
            "        mid = (left + right) // 2\n"
            "        if arr[mid] == target:\n"
            "            return mid\n"
            "    return -1\n```"
        )
        scores = scorer.score(prompt, response, TaskDomain.CODE)
        assert scores["composite"] > 0.5
        assert "completeness" in scores
        assert "coherence" in scores
        assert "code_quality" in scores

    def test_low_quality_response_scores_low(
        self, scorer: ResponseScorer,
    ) -> None:
        """A vague, short response should score low."""
        prompt = "Explain the theory of relativity and its implications"
        response = "It's about stuff."
        scores = scorer.score(prompt, response)
        assert scores["composite"] < 0.5
        assert scores["specificity"] <= 0.5

    def test_code_domain_includes_code_quality(
        self, scorer: ResponseScorer,
    ) -> None:
        """Code domain responses should include code_quality dimension."""
        prompt = "Write a function to sort a list"
        response = (
            "```python\ndef sort_list(items: list) -> list:\n"
            '    """Sort and return list."""\n'
            "    if not items:\n"
            '        raise ValueError("Empty list")\n'
            "    return sorted(items)\n```"
        )
        scores = scorer.score(prompt, response, TaskDomain.CODE)
        assert "code_quality" in scores
        assert scores["code_quality"] > 0.5

    def test_math_domain_weights_accuracy_higher(
        self, scorer: ResponseScorer,
    ) -> None:
        """Math domain should weight accuracy_signals more heavily."""
        weights = scorer._get_weights(TaskDomain.MATH)
        general_weights = scorer._get_weights(TaskDomain.GENERAL)
        assert weights["accuracy_signals"] > general_weights["accuracy_signals"]

    def test_creative_domain_weights_coherence_higher(
        self, scorer: ResponseScorer,
    ) -> None:
        """Creative writing domain should weight coherence more heavily."""
        weights = scorer._get_weights(TaskDomain.CREATIVE_WRITING)
        general_weights = scorer._get_weights(TaskDomain.GENERAL)
        assert weights["coherence"] > general_weights["coherence"]

    def test_score_code_quality_good_code(
        self, scorer: ResponseScorer,
    ) -> None:
        """Code with error handling, types, docs should score well."""
        code = (
            '```python\ndef process(data: list[str]) -> dict:\n'
            '    """Process data into results."""\n'
            '    if not data:\n'
            '        raise ValueError("Empty input")\n'
            '    # Transform items\n'
            '    result = {}\n'
            '    try:\n'
            '        for item in data:\n'
            '            result[item] = len(item)\n'
            '    except TypeError:\n'
            '        return {}\n'
            '    return result\n```'
        )
        quality = scorer._score_code_quality(code)
        # Should have: error handling, types, docstring, validation,
        # structure, return = 6/6
        assert quality >= 5 / 6

    def test_score_code_quality_bad_code(
        self, scorer: ResponseScorer,
    ) -> None:
        """Code without error handling/types/docs should score poorly."""
        code = "x = 5\nprint(x)"
        quality = scorer._score_code_quality(code)
        assert quality < 0.5

    def test_empty_response_scores_low(
        self, scorer: ResponseScorer,
    ) -> None:
        """An empty response should score low on all dimensions."""
        prompt = "Explain quantum computing"
        scores = scorer.score(prompt, "")
        assert scores["composite"] < 0.4
        assert scores["completeness"] <= 0.3
        assert scores["conciseness"] < 0.5

    def test_verbose_response_penalized_on_conciseness(
        self, scorer: ResponseScorer,
    ) -> None:
        """An excessively verbose response should be penalized."""
        prompt = "What is 2+2?"
        # Generate a very long response
        response = "The answer is four. " * 500
        scores = scorer.score(prompt, response)
        assert scores["conciseness"] < 0.7

    def test_specific_examples_score_high(
        self, scorer: ResponseScorer,
    ) -> None:
        """Response with examples, numbers, code scores high on specificity."""
        prompt = "How does a hash table work?"
        response = (
            "A hash table works by mapping keys to indices. "
            "For example, the key 'name' might hash to index 42. "
            "Here is an example implementation:\n"
            "```python\ndef hash_fn(key: str) -> int:\n"
            "    return hash(key) % 100\n```\n"
            "The average lookup time is O(1)."
        )
        scores = scorer.score(prompt, response)
        assert scores["specificity"] >= 0.8

    def test_confident_response_high_accuracy_signals(
        self, scorer: ResponseScorer,
    ) -> None:
        """Response with confident phrasing should score high on accuracy."""
        prompt = "What is the capital of France?"
        response = "The answer is Paris. This will help with geography."
        scores = scorer.score(prompt, response)
        assert scores["accuracy_signals"] > 0.5

    def test_hedging_response_low_accuracy_signals(
        self, scorer: ResponseScorer,
    ) -> None:
        """Response with hedging should score low on accuracy signals."""
        prompt = "What is the capital of France?"
        response = "I think it might be Paris. I'm not sure, but I believe it is probably Paris."
        scores = scorer.score(prompt, response)
        assert scores["accuracy_signals"] < 0.5

    def test_well_structured_response_high_coherence(
        self, scorer: ResponseScorer,
    ) -> None:
        """Response with transitions and structure should score high on coherence."""
        prompt = "Explain machine learning"
        response = (
            "Machine learning is a subset of AI.\n\n"
            "First, algorithms learn from data. "
            "Furthermore, they improve with more examples. "
            "Therefore, performance gets better over time. "
            "In conclusion, ML is a powerful tool."
        )
        scores = scorer.score(prompt, response)
        assert scores["coherence"] > 0.5

    def test_no_key_terms_short_response(
        self, scorer: ResponseScorer,
    ) -> None:
        """Short prompt with no key terms yields appropriate completeness."""
        prompt = "Hi"
        response = "Hello! How can I help you today? I'm here to assist you with anything."
        scores = scorer.score(prompt, response)
        # "Hi" has no words > 4 chars, and response > 50 chars -> 0.5
        assert scores["completeness"] == 0.5

    def test_no_key_terms_very_short_response(
        self, scorer: ResponseScorer,
    ) -> None:
        """Short prompt + short response uses the < 50 branch."""
        prompt = "Hi"
        response = "Hey."
        scores = scorer.score(prompt, response)
        assert scores["completeness"] == 0.3

    def test_no_confident_or_hedge_phrases(
        self, scorer: ResponseScorer,
    ) -> None:
        """Response with neither confident nor hedge phrases -> 0.5."""
        prompt = "What time is it?"
        response = "The current time in UTC is 12:00."
        scores = scorer.score(prompt, response)
        assert scores["accuracy_signals"] == 0.5

    def test_composite_uses_domain_weights(
        self, scorer: ResponseScorer,
    ) -> None:
        """Composite score uses domain-specific weights."""
        prompt = "Write a sorting function in Python"
        response = (
            "```python\ndef sort(arr: list) -> list:\n"
            '    """Sort array."""\n'
            "    if not arr:\n"
            '        raise ValueError("empty")\n'
            "    return sorted(arr)\n```"
        )
        code_scores = scorer.score(prompt, response, TaskDomain.CODE)
        general_scores = scorer.score(
            prompt, response, TaskDomain.GENERAL,
        )
        # Both should have composite, but weights differ
        assert "composite" in code_scores
        assert "composite" in general_scores
        assert code_scores["composite"] != general_scores["composite"]


# ======================================================================
# DomainClassifier tests
# ======================================================================


class TestDomainClassifier:
    """Tests for DomainClassifier."""

    def test_classify_code_prompt(
        self, classifier: DomainClassifier,
    ) -> None:
        """Code keywords should classify as CODE."""
        prompt = "Write a Python function to implement binary search"
        assert classifier.classify(prompt) == TaskDomain.CODE

    def test_classify_math_prompt(
        self, classifier: DomainClassifier,
    ) -> None:
        """Math keywords should classify as MATH."""
        prompt = "Solve this equation and compute the integral of x^2"
        assert classifier.classify(prompt) == TaskDomain.MATH

    def test_classify_reasoning_prompt(
        self, classifier: DomainClassifier,
    ) -> None:
        """Reasoning keywords should classify as REASONING."""
        prompt = "Explain why this logic is flawed and analyze the implications"
        assert classifier.classify(prompt) == TaskDomain.REASONING

    def test_classify_creative_prompt(
        self, classifier: DomainClassifier,
    ) -> None:
        """Creative keywords should classify as CREATIVE_WRITING."""
        prompt = "Write a story about a character who discovers a hidden plot"
        assert classifier.classify(prompt) == TaskDomain.CREATIVE_WRITING

    def test_classify_generic_prompt(
        self, classifier: DomainClassifier,
    ) -> None:
        """Generic prompt with no strong signals should be GENERAL."""
        prompt = "Hello, how are you?"
        assert classifier.classify(prompt) == TaskDomain.GENERAL

    def test_classify_code_blocks(
        self, classifier: DomainClassifier,
    ) -> None:
        """Presence of code blocks should strongly signal CODE."""
        prompt = "What does this do?\n```python\nx = 5\n```"
        assert classifier.classify(prompt) == TaskDomain.CODE

    def test_classify_ambiguous_prompt(
        self, classifier: DomainClassifier,
    ) -> None:
        """Ambiguous prompt with weak signals should be GENERAL."""
        prompt = "Tell me something interesting about the world"
        assert classifier.classify(prompt) == TaskDomain.GENERAL

    def test_classify_def_keyword_signals_code(
        self, classifier: DomainClassifier,
    ) -> None:
        """'def ' in prompt should boost code score."""
        prompt = "Please review this: def foo(): pass"
        assert classifier.classify(prompt) == TaskDomain.CODE

    def test_classify_function_keyword_signals_code(
        self, classifier: DomainClassifier,
    ) -> None:
        """'function ' in prompt should boost code score."""
        prompt = "How does this JavaScript work: function bar() {}"
        result = classifier.classify(prompt)
        assert result == TaskDomain.CODE

    def test_classify_mixed_signals_picks_strongest(
        self, classifier: DomainClassifier,
    ) -> None:
        """When multiple domains have signals, the strongest wins."""
        prompt = (
            "Write a Python script to calculate the probability "
            "and compute the statistics for this dataset"
        )
        # Has code signals: write, python, script
        # Has math signals: calculate, probability, compute, statistics
        result = classifier.classify(prompt)
        assert result in (TaskDomain.CODE, TaskDomain.MATH)


# ======================================================================
# SpecializedRouter tests
# ======================================================================


class TestSpecializedRouter:
    """Tests for SpecializedRouter."""

    def test_select_best_available_for_code(self) -> None:
        """Should return deepseek-coder for code if available."""
        router = SpecializedRouter([
            "deepseek/deepseek-coder",
            "openai/gpt-4o",
        ])
        assert router.select(TaskDomain.CODE) == "deepseek/deepseek-coder"

    def test_select_skips_unavailable(self) -> None:
        """Should skip models not in the available set."""
        router = SpecializedRouter(["openai/gpt-4o"])
        # deepseek-coder is ranked higher for CODE but not available
        result = router.select(TaskDomain.CODE)
        assert result == "openai/gpt-4o"

    def test_select_none_when_empty(self) -> None:
        """Should return None when no models are available."""
        router = SpecializedRouter([])
        assert router.select(TaskDomain.CODE) is None

    def test_select_diverse_returns_different_providers(self) -> None:
        """Should prefer different providers for diversity."""
        router = SpecializedRouter([
            "anthropic/claude-opus-4",
            "openai/gpt-4o",
            "google/gemini-2.0-flash",
        ])
        result = router.select_diverse(TaskDomain.GENERAL, n=3)
        assert len(result) == 3
        providers = {m.split("/")[0] for m in result}
        assert len(providers) == 3  # All different providers

    def test_select_diverse_handles_fewer_than_n(self) -> None:
        """Should handle when fewer models available than requested."""
        router = SpecializedRouter(["openai/gpt-4o"])
        result = router.select_diverse(TaskDomain.GENERAL, n=3)
        assert len(result) == 1
        assert result[0] == "openai/gpt-4o"

    def test_select_for_math_prefers_o3(self) -> None:
        """Math domain should prefer o3 when available."""
        router = SpecializedRouter([
            "openai/o3",
            "anthropic/claude-opus-4",
        ])
        assert router.select(TaskDomain.MATH) == "openai/o3"

    def test_select_for_creative_prefers_claude(self) -> None:
        """Creative writing should prefer Claude when available."""
        router = SpecializedRouter([
            "anthropic/claude-opus-4",
            "openai/gpt-4o",
        ])
        result = router.select(TaskDomain.CREATIVE_WRITING)
        assert result == "anthropic/claude-opus-4"

    def test_select_diverse_fills_remaining_from_available(self) -> None:
        """When ranking doesn't fill N, remaining come from available."""
        router = SpecializedRouter([
            "openai/gpt-4o",
            "custom/my-model",
        ])
        result = router.select_diverse(TaskDomain.GENERAL, n=3)
        assert "custom/my-model" in result

    def test_select_for_analysis_domain(self) -> None:
        """Analysis domain should route correctly."""
        router = SpecializedRouter(["anthropic/claude-opus-4"])
        result = router.select(TaskDomain.ANALYSIS)
        assert result == "anthropic/claude-opus-4"

    def test_select_for_reasoning_prefers_o3(self) -> None:
        """Reasoning domain should prefer o3."""
        router = SpecializedRouter([
            "openai/o3",
            "anthropic/claude-opus-4",
        ])
        assert router.select(TaskDomain.REASONING) == "openai/o3"


# ======================================================================
# QualityOrchestrator tests
# ======================================================================


class TestQualityOrchestratorSingle:
    """Tests for single-model strategy."""

    @pytest.mark.asyncio()
    async def test_execute_single_strategy(
        self, two_model_config: QualityConfig,
    ) -> None:
        """SINGLE strategy should call one model and return result."""
        two_model_config.strategy = QualityStrategy.SINGLE
        orch = QualityOrchestrator(mock_completion, two_model_config)
        result = await orch.execute(
            "Write a binary search in Python",
        )
        assert isinstance(result, QualityResult)
        assert result.content
        assert result.strategy_used == QualityStrategy.SINGLE
        assert len(result.models_used) == 1
        assert result.iterations == 1
        assert result.quality_score > 0.0
        assert result.elapsed_ms > 0
        assert "composite" in result.scores_breakdown

    @pytest.mark.asyncio()
    async def test_execute_single_no_models_uses_default(self) -> None:
        """SINGLE with no models should use default model."""
        config = QualityConfig(strategy=QualityStrategy.SINGLE)
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Hello world")
        assert result.content
        assert result.models_used == ["anthropic/claude-sonnet-4"]

    @pytest.mark.asyncio()
    async def test_execute_tracks_tokens(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Token usage should be tracked across calls."""
        two_model_config.strategy = QualityStrategy.SINGLE
        orch = QualityOrchestrator(mock_completion, two_model_config)
        result = await orch.execute("Hello")
        assert result.total_tokens == 300  # 100 + 200

    @pytest.mark.asyncio()
    async def test_execute_tracks_cost(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Cost should be calculated from model pricing."""
        two_model_config.strategy = QualityStrategy.SINGLE
        orch = QualityOrchestrator(mock_completion, two_model_config)
        result = await orch.execute("Hello")
        # Model: anthropic/claude-opus-4, 100 input tokens, 200 output
        # Cost: (100/1000)*0.015 + (200/1000)*0.075 = 0.0015 + 0.015
        expected_cost = 0.0015 + 0.015
        assert abs(result.total_cost - expected_cost) < 0.0001


class TestQualityOrchestratorBestOfN:
    """Tests for best-of-N strategy."""

    @pytest.mark.asyncio()
    async def test_execute_best_of_n(
        self, three_model_config: QualityConfig,
    ) -> None:
        """BEST_OF_N should generate N responses and pick the best."""
        three_model_config.strategy = QualityStrategy.BEST_OF_N
        three_model_config.best_of_n = 3
        orch = QualityOrchestrator(
            mock_completion, three_model_config,
        )
        result = await orch.execute(
            "Write a binary search algorithm",
        )
        assert result.strategy_used == QualityStrategy.BEST_OF_N
        assert result.content
        assert result.quality_score > 0.0
        assert result.alternatives_considered >= 1

    @pytest.mark.asyncio()
    async def test_best_of_n_picks_highest_quality(self) -> None:
        """Best-of-N should select the response with highest score."""
        call_count = 0

        async def varying_completion(
            model: str,
            messages: list[dict[str, Any]],
            **kwargs: Any,
        ) -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            # Third call returns the best response
            if call_count == 3:
                content = (
                    "The answer is that binary search works by "
                    "dividing the array. First, check the middle. "
                    "For example, with 100 elements, you need "
                    "about 7 steps. The solution is O(log n). "
                    "```python\ndef search(arr: list, t: int) -> int:\n"
                    '    """Find target."""\n'
                    "    return -1\n```"
                )
            elif call_count == 1:
                content = "Short."
            else:
                content = "Another short answer here."
            return {
                "choices": [
                    {"message": {"content": content}},
                ],
                "usage": {"prompt_tokens": 50, "completion_tokens": 50},
            }

        config = QualityConfig(
            strategy=QualityStrategy.BEST_OF_N,
            best_of_n=3,
            models=[
                ModelConfig(model_id="m1", provider="a"),
                ModelConfig(model_id="m2", provider="b"),
                ModelConfig(model_id="m3", provider="c"),
            ],
        )
        orch = QualityOrchestrator(varying_completion, config)
        result = await orch.execute("Explain binary search algorithm")
        assert "binary search" in result.content.lower()
        assert result.alternatives_considered == 3

    @pytest.mark.asyncio()
    async def test_best_of_n_handles_failures(self) -> None:
        """BEST_OF_N should handle model failures gracefully."""
        config = QualityConfig(
            strategy=QualityStrategy.BEST_OF_N,
            best_of_n=3,
            models=[
                ModelConfig(model_id="fail/model-1", provider="fail"),
                ModelConfig(model_id="openai/gpt-4o", provider="openai"),
                ModelConfig(model_id="fail/model-2", provider="fail"),
            ],
        )
        orch = QualityOrchestrator(
            mock_completion_failing, config,
        )
        result = await orch.execute("Hello")
        # Should still get a result from the one working model
        assert result.content
        assert result.alternatives_considered >= 1

    @pytest.mark.asyncio()
    async def test_best_of_n_sequential_mode(self) -> None:
        """BEST_OF_N with parallel_generation=False should work."""
        config = QualityConfig(
            strategy=QualityStrategy.BEST_OF_N,
            best_of_n=2,
            parallel_generation=False,
            models=[
                ModelConfig(model_id="openai/gpt-4o", provider="openai"),
            ],
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Hello")
        assert result.content
        assert result.alternatives_considered >= 1


class TestQualityOrchestratorGCR:
    """Tests for Generate-Critique-Refine strategy."""

    @pytest.mark.asyncio()
    async def test_execute_gcr(
        self, two_model_config: QualityConfig,
    ) -> None:
        """GCR should generate, critique, then refine."""
        two_model_config.strategy = (
            QualityStrategy.GENERATE_CRITIQUE_REFINE
        )
        orch = QualityOrchestrator(
            mock_completion, two_model_config,
        )
        result = await orch.execute(
            "Write a binary search algorithm",
        )
        assert result.strategy_used == (
            QualityStrategy.GENERATE_CRITIQUE_REFINE
        )
        assert result.content
        assert result.critique  # Should have critique text
        assert result.iterations == 3  # generate + critique + refine
        assert len(result.models_used) >= 1

    @pytest.mark.asyncio()
    async def test_gcr_uses_two_different_models(
        self, two_model_config: QualityConfig,
    ) -> None:
        """GCR should use different models for generate vs critique."""
        two_model_config.strategy = (
            QualityStrategy.GENERATE_CRITIQUE_REFINE
        )
        models_called: list[str] = []

        async def tracking_completion(
            model: str,
            messages: list[dict[str, Any]],
            **kwargs: Any,
        ) -> dict[str, Any]:
            models_called.append(model)
            return await mock_completion(model, messages, **kwargs)

        orch = QualityOrchestrator(
            tracking_completion, two_model_config,
        )
        await orch.execute("Write a search function")
        # Should have called: generator, critic, generator (refine)
        assert len(models_called) == 3
        assert models_called[0] != models_called[1]  # Different models
        assert models_called[0] == models_called[2]  # Same for refine

    @pytest.mark.asyncio()
    async def test_gcr_single_model_fallback(self) -> None:
        """GCR with one model should use it for both roles."""
        config = QualityConfig(
            strategy=QualityStrategy.GENERATE_CRITIQUE_REFINE,
            models=[
                ModelConfig(
                    model_id="anthropic/claude-opus-4",
                    provider="anthropic",
                ),
            ],
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Explain recursion")
        assert result.content
        assert result.models_used == ["anthropic/claude-opus-4"]

    @pytest.mark.asyncio()
    async def test_gcr_no_models_uses_defaults(self) -> None:
        """GCR with no configured models should use default model."""
        config = QualityConfig(
            strategy=QualityStrategy.GENERATE_CRITIQUE_REFINE,
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Hello")
        assert result.content
        assert "anthropic/claude-opus-4" in result.models_used


class TestQualityOrchestratorEnsemble:
    """Tests for Ensemble Synthesis strategy."""

    @pytest.mark.asyncio()
    async def test_execute_ensemble(
        self, three_model_config: QualityConfig,
    ) -> None:
        """Ensemble should get responses from all models and synthesize."""
        three_model_config.strategy = (
            QualityStrategy.ENSEMBLE_SYNTHESIS
        )
        orch = QualityOrchestrator(
            mock_completion, three_model_config,
        )
        result = await orch.execute(
            "Write a binary search algorithm",
        )
        assert result.strategy_used == (
            QualityStrategy.ENSEMBLE_SYNTHESIS
        )
        assert result.content
        assert result.quality_score > 0.0
        assert result.alternatives_considered >= 2

    @pytest.mark.asyncio()
    async def test_ensemble_no_models_falls_back_to_single(
        self,
    ) -> None:
        """Ensemble with no models should fall back to single."""
        config = QualityConfig(
            strategy=QualityStrategy.ENSEMBLE_SYNTHESIS,
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Hello")
        assert result.content

    @pytest.mark.asyncio()
    async def test_ensemble_single_response_no_synthesis(
        self,
    ) -> None:
        """Ensemble with only one valid response should skip synthesis."""
        config = QualityConfig(
            strategy=QualityStrategy.ENSEMBLE_SYNTHESIS,
            models=[
                ModelConfig(model_id="fail/m1", provider="fail"),
                ModelConfig(
                    model_id="openai/gpt-4o", provider="openai",
                ),
            ],
        )
        orch = QualityOrchestrator(
            mock_completion_failing, config,
        )
        result = await orch.execute("Hello")
        assert result.content
        assert result.models_used == ["openai/gpt-4o"]

    @pytest.mark.asyncio()
    async def test_ensemble_all_fail(self) -> None:
        """Ensemble should handle all models failing."""
        config = QualityConfig(
            strategy=QualityStrategy.ENSEMBLE_SYNTHESIS,
            models=[
                ModelConfig(model_id="fail/m1", provider="fail"),
                ModelConfig(model_id="fail/m2", provider="fail"),
            ],
        )
        orch = QualityOrchestrator(
            mock_completion_failing, config,
        )
        result = await orch.execute("Hello")
        assert result.quality_score == 0.0
        assert "failed" in result.content.lower()

    @pytest.mark.asyncio()
    async def test_ensemble_sequential_mode(self) -> None:
        """Ensemble with parallel_generation=False should work."""
        config = QualityConfig(
            strategy=QualityStrategy.ENSEMBLE_SYNTHESIS,
            parallel_generation=False,
            models=[
                ModelConfig(
                    model_id="anthropic/claude-opus-4",
                    provider="anthropic",
                ),
                ModelConfig(
                    model_id="openai/gpt-4o", provider="openai",
                ),
            ],
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Explain sorting")
        assert result.content
        assert result.alternatives_considered >= 2


class TestQualityOrchestratorIterative:
    """Tests for Iterative Refinement strategy."""

    @pytest.mark.asyncio()
    async def test_execute_iterative(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Iterative strategy should refine until threshold."""
        two_model_config.strategy = (
            QualityStrategy.ITERATIVE_REFINEMENT
        )
        two_model_config.max_iterations = 3
        two_model_config.quality_threshold = 0.99  # Very high
        orch = QualityOrchestrator(
            mock_completion, two_model_config,
        )
        result = await orch.execute(
            "Write a search function in Python",
        )
        assert result.strategy_used == (
            QualityStrategy.ITERATIVE_REFINEMENT
        )
        assert result.content
        assert result.iterations >= 1
        assert result.iterations <= 3  # max_iterations

    @pytest.mark.asyncio()
    async def test_iterative_stops_at_threshold(self) -> None:
        """Should stop early if quality threshold is met."""
        config = QualityConfig(
            strategy=QualityStrategy.ITERATIVE_REFINEMENT,
            quality_threshold=0.01,  # Very low — should stop at 1
            max_iterations=5,
            models=[
                ModelConfig(
                    model_id="anthropic/claude-opus-4",
                    provider="anthropic",
                ),
            ],
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Write a search algorithm")
        assert result.iterations == 1  # Should stop immediately

    @pytest.mark.asyncio()
    async def test_iterative_no_models_uses_default(self) -> None:
        """Iterative with no models should use default model."""
        config = QualityConfig(
            strategy=QualityStrategy.ITERATIVE_REFINEMENT,
            max_iterations=2,
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Hello")
        assert result.content
        assert "anthropic/claude-opus-4" in result.models_used


class TestQualityOrchestratorSpecialized:
    """Tests for Specialized Routing strategy."""

    @pytest.mark.asyncio()
    async def test_execute_specialized_routing(
        self, three_model_config: QualityConfig,
    ) -> None:
        """Specialized routing should pick the best model for domain."""
        three_model_config.strategy = (
            QualityStrategy.SPECIALIZED_ROUTING
        )
        orch = QualityOrchestrator(
            mock_completion, three_model_config,
        )
        result = await orch.execute(
            "Write a Python function to implement binary search",
        )
        assert result.strategy_used == (
            QualityStrategy.SPECIALIZED_ROUTING
        )
        assert result.content
        assert result.metadata.get("domain") == "code"

    @pytest.mark.asyncio()
    async def test_specialized_enables_thinking_for_math(
        self, thinking_model_config: QualityConfig,
    ) -> None:
        """Should enable thinking for math/reasoning prompts."""
        thinking_model_config.strategy = (
            QualityStrategy.SPECIALIZED_ROUTING
        )
        kwargs_received: dict[str, Any] = {}

        async def capture_completion(
            model: str,
            messages: list[dict[str, Any]],
            **kwargs: Any,
        ) -> dict[str, Any]:
            kwargs_received.update(kwargs)
            return await mock_completion(model, messages, **kwargs)

        orch = QualityOrchestrator(
            capture_completion, thinking_model_config,
        )
        await orch.execute(
            "Solve this equation and compute the integral",
        )
        assert kwargs_received.get("enable_thinking") is True

    @pytest.mark.asyncio()
    async def test_specialized_no_models_uses_default(self) -> None:
        """Specialized with no models should use default."""
        config = QualityConfig(
            strategy=QualityStrategy.SPECIALIZED_ROUTING,
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Hello")
        assert result.content


class TestQualityOrchestratorFullPipeline:
    """Tests for Full Pipeline strategy."""

    @pytest.mark.asyncio()
    async def test_execute_full_pipeline(
        self, three_model_config: QualityConfig,
    ) -> None:
        """Full pipeline should combine multiple strategies."""
        three_model_config.strategy = QualityStrategy.FULL_PIPELINE
        three_model_config.quality_threshold = 0.99  # Force all stages
        orch = QualityOrchestrator(
            mock_completion, three_model_config,
        )
        result = await orch.execute(
            "Write a binary search algorithm in Python",
        )
        assert result.strategy_used == QualityStrategy.FULL_PIPELINE
        assert result.content
        assert len(result.models_used) >= 1

    @pytest.mark.asyncio()
    async def test_full_pipeline_early_exit_if_bon_meets_threshold(
        self,
    ) -> None:
        """Full pipeline should exit early if best-of-N meets threshold."""
        config = QualityConfig(
            strategy=QualityStrategy.FULL_PIPELINE,
            quality_threshold=0.01,  # Very low threshold
            best_of_n=2,
            models=[
                ModelConfig(
                    model_id="anthropic/claude-opus-4",
                    provider="anthropic",
                ),
                ModelConfig(
                    model_id="openai/gpt-4o",
                    provider="openai",
                ),
            ],
        )
        call_count = 0

        async def counting_completion(
            model: str,
            messages: list[dict[str, Any]],
            **kwargs: Any,
        ) -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            return await mock_completion(model, messages, **kwargs)

        orch = QualityOrchestrator(counting_completion, config)
        result = await orch.execute("Hello world")
        assert result.strategy_used == QualityStrategy.FULL_PIPELINE
        # Should only have called best-of-N (2 calls), not GCR
        assert call_count == 2


class TestQualityOrchestratorEdgeCases:
    """Tests for edge cases and error handling."""

    @pytest.mark.asyncio()
    async def test_result_contains_scores_breakdown(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Result should contain detailed score breakdown."""
        two_model_config.strategy = QualityStrategy.SINGLE
        orch = QualityOrchestrator(
            mock_completion, two_model_config,
        )
        result = await orch.execute("Write code in Python")
        assert "completeness" in result.scores_breakdown
        assert "coherence" in result.scores_breakdown
        assert "composite" in result.scores_breakdown

    @pytest.mark.asyncio()
    async def test_result_elapsed_ms_positive(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Elapsed time should be a positive number."""
        two_model_config.strategy = QualityStrategy.SINGLE
        orch = QualityOrchestrator(
            mock_completion, two_model_config,
        )
        result = await orch.execute("Hello")
        assert result.elapsed_ms > 0

    @pytest.mark.asyncio()
    async def test_strategy_override_in_execute(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Passing strategy to execute() should override config."""
        two_model_config.strategy = QualityStrategy.FULL_PIPELINE
        orch = QualityOrchestrator(
            mock_completion, two_model_config,
        )
        result = await orch.execute(
            "Hello", strategy=QualityStrategy.SINGLE,
        )
        assert result.strategy_used == QualityStrategy.SINGLE

    @pytest.mark.asyncio()
    async def test_custom_messages_passed_through(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Custom messages should be used instead of prompt-only."""
        two_model_config.strategy = QualityStrategy.SINGLE
        orch = QualityOrchestrator(
            mock_completion, two_model_config,
        )
        custom_messages = [
            {"role": "system", "content": "You are a helpful tutor."},
            {"role": "user", "content": "What is 2+2?"},
        ]
        result = await orch.execute(
            "What is 2+2?", messages=custom_messages,
        )
        assert result.content

    @pytest.mark.asyncio()
    async def test_alt_response_format(self) -> None:
        """Should handle responses with 'content' field (no choices)."""
        config = QualityConfig(
            strategy=QualityStrategy.SINGLE,
            models=[
                ModelConfig(model_id="custom/m1", provider="custom"),
            ],
        )
        orch = QualityOrchestrator(
            mock_completion_alt_format, config,
        )
        result = await orch.execute("Hello")
        assert "Alternative format" in result.content

    @pytest.mark.asyncio()
    async def test_alt_response_format_tracks_tokens(self) -> None:
        """Alt format with input_tokens field should track correctly."""
        config = QualityConfig(
            strategy=QualityStrategy.SINGLE,
            models=[
                ModelConfig(model_id="custom/m1", provider="custom"),
            ],
        )
        orch = QualityOrchestrator(
            mock_completion_alt_format, config,
        )
        result = await orch.execute("Hello")
        assert result.total_tokens == 150  # 50 + 100

    @pytest.mark.asyncio()
    async def test_empty_response_handled(self) -> None:
        """Empty response should be handled without crashing."""
        config = QualityConfig(
            strategy=QualityStrategy.SINGLE,
            models=[
                ModelConfig(model_id="m1", provider="p1"),
            ],
        )
        orch = QualityOrchestrator(mock_completion_empty, config)
        result = await orch.execute("Hello")
        assert result.content == ""

    @pytest.mark.asyncio()
    async def test_default_config_works(self) -> None:
        """Orchestrator with default config should not crash."""
        orch = QualityOrchestrator(mock_completion)
        result = await orch.execute("Hello world")
        assert result.content

    @pytest.mark.asyncio()
    async def test_scorer_property_exposed(
        self, two_model_config: QualityConfig,
    ) -> None:
        """Orchestrator should expose scorer and classifier."""
        orch = QualityOrchestrator(
            mock_completion, two_model_config,
        )
        assert isinstance(orch.scorer, ResponseScorer)
        assert isinstance(orch.classifier, DomainClassifier)

    @pytest.mark.asyncio()
    async def test_best_of_n_all_empty_responses(self) -> None:
        """Best-of-N with all empty responses should not crash."""
        config = QualityConfig(
            strategy=QualityStrategy.BEST_OF_N,
            best_of_n=2,
            models=[
                ModelConfig(model_id="m1", provider="p1"),
            ],
        )
        orch = QualityOrchestrator(mock_completion_empty, config)
        result = await orch.execute("Hello")
        assert result.quality_score == -1.0  # No valid candidates
        assert result.alternatives_considered == 0

    @pytest.mark.asyncio()
    async def test_best_of_n_no_models_uses_default(self) -> None:
        """Best-of-N with no configured models should use default."""
        config = QualityConfig(
            strategy=QualityStrategy.BEST_OF_N,
            best_of_n=2,
        )
        orch = QualityOrchestrator(mock_completion, config)
        result = await orch.execute("Hello")
        assert result.content
        assert "anthropic/claude-sonnet-4" in result.models_used


# ======================================================================
# detect_best_strategy tests
# ======================================================================


class TestDetectBestStrategy:
    """Tests for detect_best_strategy convenience function."""

    def test_short_prompt_one_model_returns_single(self) -> None:
        """Short prompt with 1 model should return SINGLE."""
        result = detect_best_strategy("Hello there", 1)
        assert result == QualityStrategy.SINGLE

    def test_long_prompt_one_model_returns_iterative(self) -> None:
        """Long prompt with 1 model should return ITERATIVE."""
        prompt = " ".join(["word"] * 150)
        result = detect_best_strategy(prompt, 1)
        assert result == QualityStrategy.ITERATIVE_REFINEMENT

    def test_two_models_enough_time_returns_gcr(self) -> None:
        """2 models with enough time should return GCR."""
        result = detect_best_strategy(
            "Explain something", 2, time_budget_ms=25000,
        )
        assert result == QualityStrategy.GENERATE_CRITIQUE_REFINE

    def test_three_models_enough_time_returns_full_pipeline(
        self,
    ) -> None:
        """3+ models with enough time should return FULL_PIPELINE."""
        result = detect_best_strategy(
            "Explain something", 3, time_budget_ms=30000,
        )
        assert result == QualityStrategy.FULL_PIPELINE

    def test_two_models_tight_time_returns_best_of_n(self) -> None:
        """2 models with tight time budget should return BEST_OF_N."""
        result = detect_best_strategy(
            "Explain something", 2, time_budget_ms=5000,
        )
        assert result == QualityStrategy.BEST_OF_N

    def test_one_model_medium_prompt_returns_single(self) -> None:
        """1 model, medium prompt, should return SINGLE."""
        prompt = " ".join(["word"] * 50)
        result = detect_best_strategy(prompt, 1)
        assert result == QualityStrategy.SINGLE

    def test_many_models_tight_budget_returns_best_of_n(self) -> None:
        """Many models but tight time should return BEST_OF_N."""
        result = detect_best_strategy(
            "Explain something", 5, time_budget_ms=5000,
        )
        assert result == QualityStrategy.BEST_OF_N


# ======================================================================
# Data class / Enum tests
# ======================================================================


class TestDataClasses:
    """Tests for data classes and enums."""

    def test_quality_strategy_values(self) -> None:
        """All strategy enum values should be unique strings."""
        values = [s.value for s in QualityStrategy]
        assert len(values) == len(set(values))

    def test_task_domain_values(self) -> None:
        """All domain enum values should be unique strings."""
        values = [d.value for d in TaskDomain]
        assert len(values) == len(set(values))

    def test_model_config_defaults(self) -> None:
        """ModelConfig should have sensible defaults."""
        mc = ModelConfig(model_id="test/model", provider="test")
        assert mc.cost_per_1k_input == 0.0
        assert mc.cost_per_1k_output == 0.0
        assert mc.max_tokens == 4096
        assert mc.supports_thinking is False
        assert mc.strengths == []

    def test_quality_config_defaults(self) -> None:
        """QualityConfig should have sensible defaults."""
        qc = QualityConfig()
        assert qc.strategy == QualityStrategy.GENERATE_CRITIQUE_REFINE
        assert qc.quality_threshold == 0.85
        assert qc.max_iterations == 3
        assert qc.best_of_n == 3
        assert qc.timeout_seconds == 120.0
        assert qc.budget_limit is None
        assert qc.enable_thinking is True
        assert qc.parallel_generation is True

    def test_quality_result_defaults(self) -> None:
        """QualityResult should have sensible defaults."""
        qr = QualityResult(
            content="test",
            quality_score=0.8,
            strategy_used=QualityStrategy.SINGLE,
            models_used=["m1"],
            iterations=1,
            total_tokens=100,
            total_cost=0.01,
            elapsed_ms=500.0,
        )
        assert qr.thinking_content is None
        assert qr.critique is None
        assert qr.alternatives_considered == 0
        assert qr.scores_breakdown == {}
        assert qr.metadata == {}
