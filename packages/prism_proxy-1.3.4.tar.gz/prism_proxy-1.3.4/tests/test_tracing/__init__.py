"""Tests for prism.tracing."""
