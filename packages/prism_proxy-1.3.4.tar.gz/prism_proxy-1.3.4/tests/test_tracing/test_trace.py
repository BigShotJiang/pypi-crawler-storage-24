"""Tests for prism.tracing — TraceId, SpanId, Span, Trace, and Tracer."""

from __future__ import annotations

import time

import pytest

from prism.tracing.trace import (
    Span,
    SpanEvent,
    SpanId,
    SpanStatus,
    Trace,
    TraceId,
)
from prism.tracing.tracer import Tracer

# ===========================================================================
# TraceId
# ===========================================================================

class TestTraceId:
    """Tests for the TraceId identifier."""

    def test_auto_generated(self) -> None:
        tid = TraceId()
        assert len(tid.value) == 36  # UUID format

    def test_from_explicit_value(self) -> None:
        val = "12345678-1234-5678-1234-567812345678"
        tid = TraceId(val)
        assert tid.value == val

    def test_invalid_uuid_raises(self) -> None:
        with pytest.raises(ValueError):
            TraceId("not-a-uuid")

    def test_equality(self) -> None:
        val = "12345678-1234-5678-1234-567812345678"
        assert TraceId(val) == TraceId(val)

    def test_inequality(self) -> None:
        assert TraceId() != TraceId()

    def test_hash_consistent(self) -> None:
        val = "12345678-1234-5678-1234-567812345678"
        assert hash(TraceId(val)) == hash(TraceId(val))

    def test_str(self) -> None:
        val = "12345678-1234-5678-1234-567812345678"
        assert str(TraceId(val)) == val

    def test_repr(self) -> None:
        tid = TraceId()
        assert "TraceId" in repr(tid)


# ===========================================================================
# SpanId
# ===========================================================================

class TestSpanId:
    """Tests for the SpanId identifier."""

    def test_auto_generated(self) -> None:
        sid = SpanId()
        assert len(sid.value) == 16

    def test_from_explicit_value(self) -> None:
        val = "abcdef0123456789"
        sid = SpanId(val)
        assert sid.value == val

    def test_wrong_length_raises(self) -> None:
        with pytest.raises(ValueError, match="16 hex"):
            SpanId("abc")

    def test_non_hex_raises(self) -> None:
        with pytest.raises(ValueError):
            SpanId("zzzzzzzzzzzzzzzz")

    def test_equality(self) -> None:
        val = "abcdef0123456789"
        assert SpanId(val) == SpanId(val)

    def test_hash_consistent(self) -> None:
        val = "abcdef0123456789"
        assert hash(SpanId(val)) == hash(SpanId(val))


# ===========================================================================
# SpanEvent
# ===========================================================================

class TestSpanEvent:
    """Tests for SpanEvent."""

    def test_creation_defaults(self) -> None:
        ev = SpanEvent(name="test-event")
        assert ev.name == "test-event"
        assert ev.timestamp != ""
        assert ev.attributes == {}

    def test_creation_with_attributes(self) -> None:
        ev = SpanEvent(name="err", attributes={"code": 500})
        assert ev.attributes["code"] == 500


# ===========================================================================
# Span
# ===========================================================================

class TestSpan:
    """Tests for the Span dataclass."""

    def test_creation(self) -> None:
        tid = TraceId()
        span = Span(trace_id=tid, operation_name="test-op")
        assert span.operation_name == "test-op"
        assert span.status == SpanStatus.UNSET

    def test_finish_sets_duration(self) -> None:
        tid = TraceId()
        span = Span(trace_id=tid, operation_name="op")
        time.sleep(0.01)
        span.finish()
        assert span.duration_ms > 0
        assert span.status == SpanStatus.OK
        assert span.end_time != ""

    def test_finish_with_error(self) -> None:
        tid = TraceId()
        span = Span(trace_id=tid, operation_name="op")
        span.finish(SpanStatus.ERROR)
        assert span.status == SpanStatus.ERROR

    def test_add_event(self) -> None:
        tid = TraceId()
        span = Span(trace_id=tid, operation_name="op")
        ev = span.add_event("checkpoint", {"step": 1})
        assert len(span.events) == 1
        assert ev.name == "checkpoint"

    def test_set_attribute(self) -> None:
        tid = TraceId()
        span = Span(trace_id=tid, operation_name="op")
        span.set_attribute("model", "gpt-4o")
        assert span.attributes["model"] == "gpt-4o"

    def test_add_child(self) -> None:
        tid = TraceId()
        parent = Span(trace_id=tid, operation_name="parent")
        child = Span(trace_id=tid, operation_name="child", parent_span_id=parent.span_id)
        parent.add_child(child)
        assert len(parent.children) == 1
        assert parent.children[0].operation_name == "child"

    def test_to_dict(self) -> None:
        tid = TraceId()
        span = Span(trace_id=tid, operation_name="op")
        span.set_attribute("k", "v")
        span.finish()
        d = span.to_dict()
        assert d["operation_name"] == "op"
        assert d["status"] == "OK"
        assert d["attributes"]["k"] == "v"

    def test_to_dict_with_children(self) -> None:
        tid = TraceId()
        parent = Span(trace_id=tid, operation_name="parent")
        child = Span(trace_id=tid, operation_name="child")
        parent.add_child(child)
        child.finish()
        parent.finish()
        d = parent.to_dict()
        assert len(d["children"]) == 1
        assert d["children"][0]["operation_name"] == "child"


# ===========================================================================
# Trace
# ===========================================================================

class TestTrace:
    """Tests for the Trace class."""

    def test_creation_generates_id(self) -> None:
        trace = Trace()
        assert trace.trace_id is not None
        assert trace.root_span.operation_name == "request"

    def test_custom_root_operation(self) -> None:
        trace = Trace(root_operation="completion")
        assert trace.root_span.operation_name == "completion"

    def test_add_span(self) -> None:
        trace = Trace()
        child = Span(
            trace_id=trace.trace_id,
            operation_name="routing",
            parent_span_id=trace.root_span.span_id,
        )
        trace.add_span(child)
        assert len(trace.spans) == 2
        assert len(trace.root_span.children) == 1

    def test_get_span(self) -> None:
        trace = Trace()
        root_id = trace.root_span.span_id
        assert trace.get_span(root_id) is trace.root_span

    def test_get_span_missing(self) -> None:
        trace = Trace()
        assert trace.get_span(SpanId()) is None

    def test_finish(self) -> None:
        trace = Trace()
        time.sleep(0.01)
        trace.finish()
        assert trace.root_span.status == SpanStatus.OK
        assert trace.total_duration_ms > 0

    def test_total_cost(self) -> None:
        trace = Trace()
        trace.root_span.set_attribute("cost", 0.01)
        child = Span(
            trace_id=trace.trace_id,
            operation_name="child",
            parent_span_id=trace.root_span.span_id,
        )
        child.set_attribute("cost", 0.02)
        trace.add_span(child)
        assert abs(trace.total_cost - 0.03) < 1e-9

    def test_critical_path_single_span(self) -> None:
        trace = Trace()
        trace.root_span.finish()
        path = trace.critical_path()
        assert len(path) == 1
        assert path[0] is trace.root_span

    def test_critical_path_picks_longest(self) -> None:
        trace = Trace()
        short = Span(
            trace_id=trace.trace_id,
            operation_name="short",
            parent_span_id=trace.root_span.span_id,
        )
        short.finish()
        short.duration_ms = 10

        long = Span(
            trace_id=trace.trace_id,
            operation_name="long",
            parent_span_id=trace.root_span.span_id,
        )
        long.finish()
        long.duration_ms = 100

        trace.add_span(short)
        trace.add_span(long)
        trace.root_span.finish()

        path = trace.critical_path()
        ops = [s.operation_name for s in path]
        assert "long" in ops

    def test_waterfall_output(self) -> None:
        trace = Trace()
        child = Span(
            trace_id=trace.trace_id,
            operation_name="routing",
            parent_span_id=trace.root_span.span_id,
        )
        trace.add_span(child)
        child.finish()
        trace.root_span.finish()
        wf = trace.waterfall()
        assert "request" in wf
        assert "routing" in wf
        # Child should be indented
        lines = wf.split("\n")
        assert len(lines) == 2
        assert lines[1].startswith("  ")

    def test_to_dict(self) -> None:
        trace = Trace()
        trace.finish()
        d = trace.to_dict()
        assert "trace_id" in d
        assert "root_span" in d
        assert d["span_count"] == 1


# ===========================================================================
# Tracer
# ===========================================================================

class TestTracer:
    """Tests for the Tracer class."""

    def setup_method(self) -> None:
        Tracer.reset_instance()

    def test_singleton(self) -> None:
        t1 = Tracer.get_instance()
        t2 = Tracer.get_instance()
        assert t1 is t2

    def test_start_trace_context_manager(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("test-op") as trace:
            assert trace.root_span.operation_name == "test-op"
            assert tracer.current_trace() is trace
        # After context, trace is stored
        assert tracer.current_trace() is None
        assert len(tracer.get_recent_traces()) == 1

    def test_start_span_context_manager(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("root") as trace:
            with tracer.start_span("child-op") as span:
                assert span.operation_name == "child-op"
                assert span.parent_span_id == trace.root_span.span_id
            assert span.status == SpanStatus.OK

    def test_start_span_without_trace_raises(self) -> None:
        tracer = Tracer()
        with pytest.raises(RuntimeError, match="active trace"):
            with tracer.start_span("orphan"):
                pass

    def test_nested_spans(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("root") as trace:
            with tracer.start_span("level1") as s1:
                with tracer.start_span("level2") as s2:
                    assert s2.parent_span_id == s1.span_id
        assert len(trace.spans) == 3  # root + level1 + level2

    def test_add_event(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("root"):
            tracer.add_event("checkpoint", {"step": 1})
        traces = tracer.get_recent_traces()
        root = traces[0].root_span
        assert len(root.events) == 1
        assert root.events[0].name == "checkpoint"

    def test_add_event_without_span_raises(self) -> None:
        tracer = Tracer()
        with pytest.raises(RuntimeError, match="active span"):
            tracer.add_event("orphan")

    def test_set_attribute(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("root"):
            tracer.set_attribute("model", "gpt-4o")
        traces = tracer.get_recent_traces()
        assert traces[0].root_span.attributes["model"] == "gpt-4o"

    def test_set_attribute_without_span_raises(self) -> None:
        tracer = Tracer()
        with pytest.raises(RuntimeError, match="active span"):
            tracer.set_attribute("k", "v")

    def test_get_trace_by_id(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("root") as trace:
            tid = trace.trace_id
        found = tracer.get_trace(tid)
        assert found is not None
        assert found.trace_id == tid

    def test_get_trace_not_found(self) -> None:
        tracer = Tracer()
        assert tracer.get_trace(TraceId()) is None

    def test_get_recent_traces_limit(self) -> None:
        tracer = Tracer()
        for i in range(5):
            with tracer.start_trace(f"op-{i}"):
                pass
        recent = tracer.get_recent_traces(3)
        assert len(recent) == 3

    def test_export_traces(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("op"):
            pass
        exported = tracer.export_traces()
        assert len(exported) == 1
        assert "trace_id" in exported[0]

    def test_max_traces_eviction(self) -> None:
        tracer = Tracer(max_traces=3)
        for i in range(5):
            with tracer.start_trace(f"op-{i}"):
                pass
        assert len(tracer.get_recent_traces(10)) == 3

    def test_clear(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("op"):
            pass
        tracer.clear()
        assert len(tracer.get_recent_traces()) == 0

    def test_error_in_trace_marks_error(self) -> None:
        tracer = Tracer()
        with pytest.raises(ValueError, match="boom"):
            with tracer.start_trace("err") as _trace:
                raise ValueError("boom")
        stored = tracer.get_recent_traces()
        assert len(stored) == 1
        assert stored[0].root_span.status == SpanStatus.ERROR

    def test_error_in_span_marks_span_error(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("root"):
            with pytest.raises(ValueError, match="child-boom"):
                with tracer.start_span("bad-child") as span:
                    raise ValueError("child-boom")
            assert span.status == SpanStatus.ERROR

    def test_span_restores_previous_span(self) -> None:
        tracer = Tracer()
        with tracer.start_trace("root") as trace:
            root_span = trace.root_span
            with tracer.start_span("child"):
                pass
            # After child context exits, current span should be root again
            assert tracer._get_current_span() is root_span
