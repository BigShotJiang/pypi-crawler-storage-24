"""Tests for prism.llm.system_prompts — system prompt builder and tool result formatting."""

from __future__ import annotations

import pytest

from prism.llm.system_prompts import (
    SystemPromptBuilder,
    SystemPromptConfig,
    TaskMode,
    format_tool_result,
)

# =====================================================================
# SystemPromptBuilder — core build()
# =====================================================================


class TestSystemPromptBuilderIdentity:
    """Test the core identity section is always present."""

    def test_build_default_contains_identity(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build()
        assert "Prism" in prompt
        assert "AI coding assistant" in prompt

    def test_build_returns_string(self) -> None:
        builder = SystemPromptBuilder()
        result = builder.build()
        assert isinstance(result, str)
        assert len(result) > 50


# =====================================================================
# TaskMode instructions
# =====================================================================


class TestTaskModeInstructions:
    """Each TaskMode should produce distinct instructions."""

    def test_general_mode_no_extra_heading(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.GENERAL)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        # GENERAL mode adds no mode-specific section heading
        assert "## Code Generation Mode" not in prompt
        assert "## Code Review Mode" not in prompt

    def test_code_generation_mode(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.CODE_GENERATION)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Code Generation Mode" in prompt
        assert "production-ready" in prompt
        assert "type hints" in prompt

    def test_code_review_mode(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.CODE_REVIEW)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Code Review Mode" in prompt
        assert "OWASP" in prompt
        assert "severity" in prompt

    def test_debugging_mode(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.DEBUGGING)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Debugging Mode" in prompt
        assert "root cause" in prompt

    def test_architecture_mode(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.ARCHITECTURE)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Architecture Mode" in prompt
        assert "scalability" in prompt

    def test_creative_mode(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.CREATIVE)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Creative Mode" in prompt
        assert "novel approaches" in prompt

    def test_analysis_mode(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.ANALYSIS)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Analysis Mode" in prompt
        assert "thorough" in prompt

    def test_tool_use_mode(self) -> None:
        config = SystemPromptConfig(mode=TaskMode.TOOL_USE)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Tool Use Mode" in prompt
        assert "Read files before suggesting" in prompt

    @pytest.mark.parametrize("mode", list(TaskMode))
    def test_all_modes_produce_valid_prompt(self, mode: TaskMode) -> None:
        """Every TaskMode should produce a non-empty prompt."""
        config = SystemPromptConfig(mode=mode)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert isinstance(prompt, str)
        assert len(prompt) > 50
        assert "Prism" in prompt  # identity always present


# =====================================================================
# build_for_provider
# =====================================================================


class TestBuildForProvider:
    """Test provider-specific prompt building."""

    def test_build_for_anthropic(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build_for_provider("anthropic")
        assert isinstance(prompt, str)
        assert "Prism" in prompt

    def test_build_for_openai(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build_for_provider("openai")
        assert isinstance(prompt, str)
        assert "Prism" in prompt

    def test_build_for_provider_with_mode_override(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build_for_provider(
            "anthropic", mode=TaskMode.DEBUGGING
        )
        assert "Debugging Mode" in prompt

    def test_build_for_unknown_provider(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build_for_provider("some_custom_provider")
        assert isinstance(prompt, str)
        assert len(prompt) > 50


# =====================================================================
# Tool instructions inclusion/exclusion
# =====================================================================


class TestToolInstructions:
    """Tool instructions appear only when configured."""

    def test_tool_instructions_present_when_tools_available(self) -> None:
        config = SystemPromptConfig(
            available_tools=["read_file", "write_file", "search"],
            include_tool_instructions=True,
        )
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Available Tools" in prompt
        assert "read_file" in prompt
        assert "write_file" in prompt
        assert "search" in prompt

    def test_tool_instructions_absent_when_disabled(self) -> None:
        config = SystemPromptConfig(
            available_tools=["read_file"],
            include_tool_instructions=False,
        )
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Available Tools" not in prompt

    def test_tool_instructions_absent_when_no_tools(self) -> None:
        config = SystemPromptConfig(
            available_tools=[],
            include_tool_instructions=True,
        )
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Available Tools" not in prompt

    def test_tool_instructions_include_usage_guidance(self) -> None:
        config = SystemPromptConfig(
            available_tools=["execute_command"],
        )
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "sandbox" in prompt.lower()


# =====================================================================
# Project context
# =====================================================================


class TestProjectContext:
    """Project context section responds to language/framework config."""

    def test_project_context_with_language(self) -> None:
        config = SystemPromptConfig(project_language="Python")
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Project Context" in prompt
        assert "Python" in prompt

    def test_project_context_with_framework(self) -> None:
        config = SystemPromptConfig(project_framework="Django")
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Project Context" in prompt
        assert "Django" in prompt

    def test_project_context_with_both(self) -> None:
        config = SystemPromptConfig(
            project_language="TypeScript",
            project_framework="Next.js",
        )
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "TypeScript" in prompt
        assert "Next.js" in prompt

    def test_no_project_context_when_unset(self) -> None:
        config = SystemPromptConfig()
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Project Context" not in prompt


# =====================================================================
# Safety section
# =====================================================================


class TestSafetySection:
    """Safety guardrails should be toggleable."""

    def test_safety_present_by_default(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build()
        assert "Safety" in prompt
        assert "API keys" in prompt

    def test_safety_absent_when_disabled(self) -> None:
        config = SystemPromptConfig(include_safety=False)
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "## Safety" not in prompt

    def test_safety_mentions_path_traversal(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build()
        assert "traversal" in prompt


# =====================================================================
# Custom instructions
# =====================================================================


class TestCustomInstructions:
    """Custom user instructions are appended."""

    def test_custom_instructions_included(self) -> None:
        config = SystemPromptConfig(
            custom_instructions="Always respond in French."
        )
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Custom Instructions" in prompt
        assert "Always respond in French." in prompt

    def test_empty_custom_instructions_excluded(self) -> None:
        config = SystemPromptConfig(custom_instructions="")
        builder = SystemPromptBuilder(config)
        prompt = builder.build()
        assert "Custom Instructions" not in prompt


# =====================================================================
# Quality enforcement
# =====================================================================


class TestQualityEnforcement:
    """Quality standards section is always present."""

    def test_quality_standards_present(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build()
        assert "Quality Standards" in prompt
        assert "concise" in prompt

    def test_quality_mentions_trade_offs(self) -> None:
        builder = SystemPromptBuilder()
        prompt = builder.build()
        assert "trade-offs" in prompt


# =====================================================================
# Overrides via build()
# =====================================================================


class TestBuildOverrides:
    """Overrides in build() should not mutate the builder's config."""

    def test_override_mode(self) -> None:
        builder = SystemPromptBuilder(
            SystemPromptConfig(mode=TaskMode.GENERAL)
        )
        prompt = builder.build(mode=TaskMode.CODE_REVIEW)
        assert "Code Review Mode" in prompt

        # Original config unchanged
        default_prompt = builder.build()
        assert "Code Review Mode" not in default_prompt

    def test_override_unknown_field_ignored(self) -> None:
        builder = SystemPromptBuilder()
        # Should not raise
        prompt = builder.build(nonexistent_field="value")
        assert isinstance(prompt, str)


# =====================================================================
# format_tool_result — Anthropic provider
# =====================================================================


class TestFormatToolResultAnthropic:
    """Anthropic tool result formatting."""

    def test_success_result(self) -> None:
        msg = format_tool_result(
            "read_file", "file contents here", success=True, provider="anthropic"
        )
        assert msg["role"] == "user"
        assert "<tool_result" in msg["content"]
        assert "read_file" in msg["content"]
        assert "file contents here" in msg["content"]
        assert "</tool_result>" in msg["content"]

    def test_error_result(self) -> None:
        msg = format_tool_result(
            "write_file", "Permission denied", success=False, provider="anthropic"
        )
        assert msg["role"] == "user"
        assert "<tool_error" in msg["content"]
        assert "write_file" in msg["content"]
        assert "Permission denied" in msg["content"]
        assert "</tool_error>" in msg["content"]

    def test_claude_provider_prefix(self) -> None:
        msg = format_tool_result(
            "search", "results", provider="claude-3-opus"
        )
        assert msg["role"] == "user"
        assert "<tool_result" in msg["content"]


# =====================================================================
# format_tool_result — OpenAI provider
# =====================================================================


class TestFormatToolResultOpenAI:
    """OpenAI tool result formatting."""

    def test_success_result(self) -> None:
        msg = format_tool_result(
            "read_file", "contents", success=True, provider="openai"
        )
        assert msg["role"] == "tool"
        assert msg["name"] == "read_file"
        assert msg["content"] == "contents"

    def test_error_result_prefixed(self) -> None:
        msg = format_tool_result(
            "cmd", "not found", success=False, provider="openai"
        )
        assert msg["role"] == "tool"
        assert msg["content"].startswith("Error:")

    def test_gpt_provider_prefix(self) -> None:
        msg = format_tool_result(
            "tool", "ok", provider="gpt-4o"
        )
        assert msg["role"] == "tool"

    def test_o1_provider_prefix(self) -> None:
        msg = format_tool_result(
            "tool", "ok", provider="o1-preview"
        )
        assert msg["role"] == "tool"

    def test_o3_provider_prefix(self) -> None:
        msg = format_tool_result(
            "tool", "ok", provider="o3-mini"
        )
        assert msg["role"] == "tool"


# =====================================================================
# format_tool_result — generic provider
# =====================================================================


class TestFormatToolResultGeneric:
    """Generic/unknown provider tool result formatting."""

    def test_success_result(self) -> None:
        msg = format_tool_result(
            "search", "found 5 results", provider="deepseek"
        )
        assert msg["role"] == "user"
        assert "[Tool: search]" in msg["content"]
        assert "[SUCCESS]" in msg["content"]
        assert "found 5 results" in msg["content"]

    def test_error_result(self) -> None:
        msg = format_tool_result(
            "cmd", "timeout", success=False, provider="mistral"
        )
        assert msg["role"] == "user"
        assert "[ERROR]" in msg["content"]
        assert "timeout" in msg["content"]


# =====================================================================
# format_tool_result — different input types
# =====================================================================


class TestFormatToolResultInputTypes:
    """Test serialization of various result types."""

    def test_dict_result(self) -> None:
        data = {"files": ["a.py", "b.py"], "count": 2}
        msg = format_tool_result("list_dir", data, provider="anthropic")
        assert '"files"' in msg["content"]
        assert '"count"' in msg["content"]
        assert "a.py" in msg["content"]

    def test_list_result(self) -> None:
        data = [1, 2, 3, "four"]
        msg = format_tool_result("numbers", data, provider="openai")
        assert "1" in msg["content"]
        assert '"four"' in msg["content"]

    def test_none_result(self) -> None:
        msg = format_tool_result("void_tool", None, provider="anthropic")
        assert "(no output)" in msg["content"]

    def test_string_result(self) -> None:
        msg = format_tool_result(
            "echo", "hello world", provider="anthropic"
        )
        assert "hello world" in msg["content"]

    def test_integer_result(self) -> None:
        msg = format_tool_result("count", 42, provider="openai")
        assert "42" in msg["content"]

    def test_bool_result(self) -> None:
        msg = format_tool_result("check", True, provider="anthropic")
        assert "True" in msg["content"]


# =====================================================================
# format_tool_result — truncation
# =====================================================================


class TestFormatToolResultTruncation:
    """Long results should be truncated."""

    def test_truncation_at_50k_chars(self) -> None:
        long_result = "x" * 60000
        msg = format_tool_result(
            "big_read", long_result, provider="anthropic"
        )
        assert "truncated" in msg["content"]
        assert "60000 total chars" in msg["content"]
        # Should contain the first 50k characters
        assert msg["content"].count("x") >= 50000

    def test_no_truncation_for_short_results(self) -> None:
        short = "short result"
        msg = format_tool_result(
            "small_read", short, provider="anthropic"
        )
        assert "truncated" not in msg["content"]
        assert "short result" in msg["content"]

    def test_truncation_boundary(self) -> None:
        """Exactly at the boundary should not truncate."""
        boundary = "y" * 50000
        msg = format_tool_result(
            "boundary", boundary, provider="anthropic"
        )
        assert "truncated" not in msg["content"]


# =====================================================================
# TaskMode enum
# =====================================================================


class TestTaskModeEnum:
    """TaskMode enum has expected members."""

    def test_all_modes_exist(self) -> None:
        expected = {
            "GENERAL", "CODE_GENERATION", "CODE_REVIEW",
            "DEBUGGING", "ARCHITECTURE", "CREATIVE",
            "ANALYSIS", "TOOL_USE",
        }
        actual = {m.name for m in TaskMode}
        assert actual == expected

    def test_enum_values_are_lowercase(self) -> None:
        for mode in TaskMode:
            assert mode.value == mode.value.lower()


# =====================================================================
# SystemPromptConfig defaults
# =====================================================================


class TestSystemPromptConfigDefaults:
    """Verify sensible defaults on SystemPromptConfig."""

    def test_default_mode_is_general(self) -> None:
        config = SystemPromptConfig()
        assert config.mode == TaskMode.GENERAL

    def test_default_safety_enabled(self) -> None:
        config = SystemPromptConfig()
        assert config.include_safety is True

    def test_default_tool_instructions_enabled(self) -> None:
        config = SystemPromptConfig()
        assert config.include_tool_instructions is True

    def test_default_no_tools(self) -> None:
        config = SystemPromptConfig()
        assert config.available_tools == []

    def test_default_no_custom_instructions(self) -> None:
        config = SystemPromptConfig()
        assert config.custom_instructions == ""

    def test_default_provider_anthropic(self) -> None:
        config = SystemPromptConfig()
        assert config.provider == "anthropic"

    def test_default_max_prompt_tokens(self) -> None:
        config = SystemPromptConfig()
        assert config.max_prompt_tokens == 2000
