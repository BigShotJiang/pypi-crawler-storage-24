"""Tests for the SSE streaming protocol engine — 40+ tests, fully offline.

Covers StreamChunk, StreamAccumulator, StreamTransformer, StreamTee,
and BackpressureController with edge cases, concurrency, and error paths.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import pytest

from prism.llm.streaming_protocol import (
    AccumulatedResult,
    BackpressureController,
    ContentType,
    FinishReason,
    StreamAccumulator,
    StreamChunk,
    StreamTee,
    StreamTransformer,
    ThinkingDelta,
    ToolCallDelta,
    UsageStats,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _async_chunks(items: list[StreamChunk]) -> AsyncIterator[StreamChunk]:
    """Create an async iterator from a list of StreamChunk objects."""
    for item in items:
        yield item


async def _slow_async_chunks(
    items: list[StreamChunk], delay: float = 0.01,
) -> AsyncIterator[StreamChunk]:
    """Create a slow async iterator that sleeps between yields."""
    for item in items:
        await asyncio.sleep(delay)
        yield item


def _text_chunk(text: str, index: int = 0) -> StreamChunk:
    """Build a simple text StreamChunk."""
    return StreamChunk(delta=text, chunk_index=index)


def _final_chunk(
    reason: FinishReason = FinishReason.STOP,
    usage: UsageStats | None = None,
    index: int = 0,
) -> StreamChunk:
    """Build a final StreamChunk with a finish reason."""
    return StreamChunk(finish_reason=reason, usage=usage, chunk_index=index)


# ===========================================================================
# StreamChunk tests
# ===========================================================================


class TestStreamChunk:
    """StreamChunk dataclass properties and behaviour."""

    def test_default_values(self) -> None:
        chunk = StreamChunk()
        assert chunk.delta == ""
        assert chunk.finish_reason is None
        assert chunk.content_type == ContentType.TEXT
        assert chunk.usage is None
        assert chunk.tool_call_delta is None
        assert chunk.thinking_delta is None
        assert chunk.latency_ms == 0.0
        assert chunk.chunk_index == 0
        assert chunk.raw is None

    def test_is_final_false_for_normal_chunk(self) -> None:
        chunk = _text_chunk("hello")
        assert chunk.is_final is False

    def test_is_final_true_for_stop(self) -> None:
        chunk = _final_chunk(FinishReason.STOP)
        assert chunk.is_final is True

    def test_has_content_with_delta(self) -> None:
        chunk = _text_chunk("data")
        assert chunk.has_content is True

    def test_has_content_empty_delta(self) -> None:
        chunk = StreamChunk()
        assert chunk.has_content is False

    def test_has_content_with_tool_call(self) -> None:
        chunk = StreamChunk(
            tool_call_delta=ToolCallDelta(index=0, function_name="search"),
        )
        assert chunk.has_content is True

    def test_has_content_with_thinking(self) -> None:
        chunk = StreamChunk(
            thinking_delta=ThinkingDelta(content="Let me think..."),
        )
        assert chunk.has_content is True

    def test_frozen(self) -> None:
        chunk = _text_chunk("immutable")
        with pytest.raises(AttributeError):
            chunk.delta = "changed"  # type: ignore[misc]


class TestUsageStats:
    """UsageStats dataclass."""

    def test_defaults(self) -> None:
        stats = UsageStats()
        assert stats.prompt_tokens == 0
        assert stats.completion_tokens == 0
        assert stats.cached_tokens == 0
        assert stats.thinking_tokens == 0
        assert stats.total_tokens == 0

    def test_with_values(self) -> None:
        stats = UsageStats(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
        )
        assert stats.prompt_tokens == 100
        assert stats.total_tokens == 150


# ===========================================================================
# StreamAccumulator tests
# ===========================================================================


class TestStreamAccumulator:
    """StreamAccumulator assembles chunks correctly."""

    async def test_basic_text_accumulation(self) -> None:
        chunks = [
            _text_chunk("Hello ", 0),
            _text_chunk("world!", 1),
            _final_chunk(FinishReason.STOP, index=2),
        ]
        acc = StreamAccumulator()
        collected: list[StreamChunk] = []
        async for chunk in acc.consume(_async_chunks(chunks)):
            collected.append(chunk)

        assert len(collected) == 3
        assert acc.text == "Hello world!"
        assert acc.finish_reason == FinishReason.STOP
        assert acc.chunk_count == 3

    async def test_empty_stream(self) -> None:
        acc = StreamAccumulator()
        collected: list[StreamChunk] = []
        async for chunk in acc.consume(_async_chunks([])):
            collected.append(chunk)

        assert collected == []
        assert acc.text == ""
        assert acc.finish_reason is None
        assert acc.chunk_count == 0

    async def test_single_chunk_stream(self) -> None:
        chunks = [StreamChunk(delta="all-at-once", finish_reason=FinishReason.STOP)]
        acc = StreamAccumulator()
        async for _ in acc.consume(_async_chunks(chunks)):
            pass

        assert acc.text == "all-at-once"
        assert acc.finish_reason == FinishReason.STOP

    async def test_tool_call_assembly(self) -> None:
        chunks = [
            StreamChunk(
                tool_call_delta=ToolCallDelta(
                    index=0, call_id="call_abc", function_name="search_web",
                    arguments_delta='{"qu',
                ),
                chunk_index=0,
            ),
            StreamChunk(
                tool_call_delta=ToolCallDelta(
                    index=0, arguments_delta='ery": "test"}',
                ),
                chunk_index=1,
            ),
            _final_chunk(FinishReason.TOOL_CALLS, index=2),
        ]
        acc = StreamAccumulator()
        async for _ in acc.consume(_async_chunks(chunks)):
            pass

        tool_calls = acc.tool_calls
        assert len(tool_calls) == 1
        assert tool_calls[0]["id"] == "call_abc"
        assert tool_calls[0]["function"]["name"] == "search_web"
        assert tool_calls[0]["function"]["arguments"] == '{"query": "test"}'

    async def test_multiple_tool_calls(self) -> None:
        chunks = [
            StreamChunk(
                tool_call_delta=ToolCallDelta(
                    index=0, call_id="c1", function_name="search",
                    arguments_delta='{"q": "a"}',
                ),
            ),
            StreamChunk(
                tool_call_delta=ToolCallDelta(
                    index=1, call_id="c2", function_name="read_file",
                    arguments_delta='{"path": "/x"}',
                ),
            ),
            _final_chunk(FinishReason.TOOL_CALLS),
        ]
        acc = StreamAccumulator()
        async for _ in acc.consume(_async_chunks(chunks)):
            pass

        assert len(acc.tool_calls) == 2
        assert acc.tool_calls[0]["function"]["name"] == "search"
        assert acc.tool_calls[1]["function"]["name"] == "read_file"

    async def test_thinking_accumulation(self) -> None:
        chunks = [
            StreamChunk(
                thinking_delta=ThinkingDelta(content="Step 1: "),
                chunk_index=0,
            ),
            StreamChunk(
                thinking_delta=ThinkingDelta(content="analyze the problem."),
                chunk_index=1,
            ),
            _text_chunk("The answer is 42.", 2),
            _final_chunk(FinishReason.STOP, index=3),
        ]
        acc = StreamAccumulator()
        async for _ in acc.consume(_async_chunks(chunks)):
            pass

        assert acc.thinking_text == "Step 1: analyze the problem."
        assert acc.text == "The answer is 42."

    async def test_usage_stats_captured(self) -> None:
        usage = UsageStats(
            prompt_tokens=50, completion_tokens=25,
            total_tokens=75, cached_tokens=10,
        )
        chunks = [
            _text_chunk("response"),
            _final_chunk(FinishReason.STOP, usage=usage),
        ]
        acc = StreamAccumulator()
        async for _ in acc.consume(_async_chunks(chunks)):
            pass

        assert acc.usage is not None
        assert acc.usage.prompt_tokens == 50
        assert acc.usage.completion_tokens == 25
        assert acc.usage.cached_tokens == 10

    async def test_result_snapshot(self) -> None:
        chunks = [
            _text_chunk("data", 0),
            _final_chunk(FinishReason.LENGTH, index=1),
        ]
        acc = StreamAccumulator()
        async for _ in acc.consume(_async_chunks(chunks)):
            pass

        result = acc.result()
        assert isinstance(result, AccumulatedResult)
        assert result.text == "data"
        assert result.finish_reason == FinishReason.LENGTH
        assert result.chunk_count == 2
        assert result.elapsed_ms >= 0

    async def test_elapsed_ms_non_negative(self) -> None:
        chunks = [_text_chunk("x"), _final_chunk()]
        acc = StreamAccumulator()
        async for _ in acc.consume(_async_chunks(chunks)):
            pass
        assert acc.elapsed_ms >= 0

    async def test_consume_returns_self(self) -> None:
        acc = StreamAccumulator()
        result = acc.consume(_async_chunks([]))
        assert result is acc


# ===========================================================================
# StreamTransformer tests
# ===========================================================================


class TestStreamTransformer:
    """StreamTransformer applies transforms and detects code blocks."""

    async def test_identity_transform(self) -> None:
        """With no transforms registered, chunks pass through unchanged."""
        chunks = [_text_chunk("hello"), _final_chunk()]
        transformer = StreamTransformer()
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        assert collected[0].delta == "hello"

    async def test_uppercase_transform(self) -> None:
        chunks = [_text_chunk("hello"), _final_chunk()]
        transformer = StreamTransformer()
        transformer.add_transform(str.upper)
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        assert collected[0].delta == "HELLO"

    async def test_chained_transforms(self) -> None:
        """Multiple transforms are applied in registration order."""
        chunks = [_text_chunk("hello world"), _final_chunk()]
        transformer = StreamTransformer()
        transformer.add_transform(str.upper)
        transformer.add_transform(lambda s: s.replace(" ", "-"))

        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        assert collected[0].delta == "HELLO-WORLD"

    async def test_clear_transforms(self) -> None:
        transformer = StreamTransformer()
        transformer.add_transform(str.upper)
        transformer.clear_transforms()

        chunks = [_text_chunk("hello"), _final_chunk()]
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        assert collected[0].delta == "hello"

    async def test_add_transform_returns_self(self) -> None:
        transformer = StreamTransformer()
        result = transformer.add_transform(str.upper)
        assert result is transformer

    async def test_code_block_detection_open(self) -> None:
        chunks = [
            _text_chunk("Here is code:\n```python\n"),
            _text_chunk("print('hi')\n"),
            _final_chunk(),
        ]
        transformer = StreamTransformer()
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        assert transformer.in_code_block is True
        assert transformer.code_language == "python"

    async def test_code_block_detection_closed(self) -> None:
        chunks = [
            _text_chunk("```python\ncode()\n```\n"),
            _text_chunk("after code"),
            _final_chunk(),
        ]
        transformer = StreamTransformer()
        async for _ in transformer.transform(_async_chunks(chunks)):
            pass

        assert transformer.in_code_block is False
        assert transformer.code_language == ""

    async def test_code_content_type_annotation(self) -> None:
        """Chunks inside a code block get ContentType.CODE."""
        chunks = [
            _text_chunk("```python\n"),
            _text_chunk("x = 1\n"),
            _final_chunk(),
        ]
        transformer = StreamTransformer()
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        # The second chunk should be classified as code
        assert collected[1].content_type == ContentType.CODE

    async def test_thinking_content_type(self) -> None:
        chunks = [
            StreamChunk(thinking_delta=ThinkingDelta(content="reasoning...")),
            _final_chunk(),
        ]
        transformer = StreamTransformer()
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        assert collected[0].content_type == ContentType.THINKING

    async def test_tool_call_content_type(self) -> None:
        chunks = [
            StreamChunk(
                tool_call_delta=ToolCallDelta(index=0, function_name="search"),
            ),
            _final_chunk(),
        ]
        transformer = StreamTransformer()
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        assert collected[0].content_type == ContentType.TOOL_CALL

    async def test_transforms_not_applied_to_thinking(self) -> None:
        """Text transforms should not alter thinking deltas."""
        chunks = [
            StreamChunk(
                delta="",
                thinking_delta=ThinkingDelta(content="think lower"),
            ),
            _final_chunk(),
        ]
        transformer = StreamTransformer()
        transformer.add_transform(str.upper)
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)

        # The thinking delta content is not transformed via the delta field
        assert collected[0].thinking_delta is not None
        assert collected[0].thinking_delta.content == "think lower"

    async def test_detect_content_type_without_transform(self) -> None:
        transformer = StreamTransformer()
        chunk = StreamChunk(thinking_delta=ThinkingDelta(content="..."))
        assert transformer.detect_content_type(chunk) == ContentType.THINKING

        chunk2 = StreamChunk(tool_call_delta=ToolCallDelta(index=0))
        assert transformer.detect_content_type(chunk2) == ContentType.TOOL_CALL

        chunk3 = _text_chunk("plain text")
        assert transformer.detect_content_type(chunk3) == ContentType.TEXT

    async def test_empty_delta_passes_through(self) -> None:
        chunks = [StreamChunk(), _final_chunk()]
        transformer = StreamTransformer()
        transformer.add_transform(str.upper)
        collected: list[StreamChunk] = []
        async for chunk in transformer.transform(_async_chunks(chunks)):
            collected.append(chunk)
        # Empty delta should not cause errors
        assert collected[0].delta == ""


# ===========================================================================
# StreamTee tests
# ===========================================================================


class TestStreamTee:
    """StreamTee forks a stream to multiple consumers."""

    async def test_two_consumers_get_same_chunks(self) -> None:
        chunks = [_text_chunk("A", 0), _text_chunk("B", 1), _final_chunk(index=2)]
        tee = StreamTee(_async_chunks(chunks), fan_out=2)
        s1, s2 = tee.streams()

        tee.start()

        result1: list[str] = []
        async for chunk in s1:
            result1.append(chunk.delta)

        result2: list[str] = []
        async for chunk in s2:
            result2.append(chunk.delta)

        assert result1 == ["A", "B", ""]
        assert result2 == ["A", "B", ""]

    async def test_three_consumers(self) -> None:
        chunks = [_text_chunk("X"), _final_chunk()]
        tee = StreamTee(_async_chunks(chunks), fan_out=3)
        s1, s2, s3 = tee.streams()
        tee.start()

        r1 = [c.delta async for c in s1]
        r2 = [c.delta async for c in s2]
        r3 = [c.delta async for c in s3]

        assert r1 == r2 == r3

    async def test_fan_out_validation(self) -> None:
        with pytest.raises(ValueError, match="fan_out must be >= 1"):
            StreamTee(_async_chunks([]), fan_out=0)

    async def test_double_start_raises(self) -> None:
        tee = StreamTee(_async_chunks([_final_chunk()]), fan_out=1)
        tee.start()
        with pytest.raises(RuntimeError, match="already started"):
            tee.start()
        # Let the pump complete
        await asyncio.sleep(0.05)

    async def test_is_done_after_exhaustion(self) -> None:
        chunks = [_text_chunk("done"), _final_chunk()]
        tee = StreamTee(_async_chunks(chunks), fan_out=1)
        (s1,) = tee.streams()
        tee.start()

        async for _ in s1:
            pass

        # Give pump time to finish
        await asyncio.sleep(0.05)
        assert tee.is_done is True

    async def test_pump_sync(self) -> None:
        """pump_sync drives the pump from the caller's coroutine."""
        chunks = [_text_chunk("sync"), _final_chunk()]
        tee = StreamTee(_async_chunks(chunks), fan_out=1)
        (s1,) = tee.streams()

        collected: list[str] = []

        async def consumer() -> None:
            async for chunk in s1:
                collected.append(chunk.delta)

        await asyncio.gather(consumer(), tee.pump_sync())
        assert "sync" in collected

    async def test_empty_source(self) -> None:
        tee = StreamTee(_async_chunks([]), fan_out=2)
        s1, s2 = tee.streams()
        tee.start()

        r1 = [c async for c in s1]
        r2 = [c async for c in s2]
        assert r1 == []
        assert r2 == []


# ===========================================================================
# BackpressureController tests
# ===========================================================================


class TestBackpressureController:
    """BackpressureController handles flow control correctly."""

    async def test_basic_passthrough(self) -> None:
        """All chunks pass through when consumer is fast enough."""
        chunks = [_text_chunk(f"c{i}", i) for i in range(5)]
        chunks.append(_final_chunk(index=5))

        ctrl = BackpressureController(
            _async_chunks(chunks), max_buffer=128,
        )
        collected: list[str] = []
        async for chunk in ctrl:
            collected.append(chunk.delta)

        assert "c0" in collected
        assert "c4" in collected
        assert ctrl.total_received == 6
        assert ctrl.total_delivered == 6

    async def test_validation_max_buffer(self) -> None:
        with pytest.raises(ValueError, match="max_buffer must be >= 1"):
            BackpressureController(_async_chunks([]), max_buffer=0)

    async def test_validation_watermarks(self) -> None:
        with pytest.raises(ValueError, match="Watermarks must satisfy"):
            BackpressureController(
                _async_chunks([]),
                max_buffer=10,
                high_watermark=0.3,
                low_watermark=0.5,  # low > high
            )

    async def test_stats_snapshot(self) -> None:
        chunks = [_text_chunk("a"), _final_chunk()]
        ctrl = BackpressureController(_async_chunks(chunks), max_buffer=10)
        async for _ in ctrl:
            pass

        stats = ctrl.stats()
        assert stats["total_received"] == 2
        assert stats["total_delivered"] == 2
        assert stats["source_exhausted"] is True
        assert stats["max_buffer"] == 10

    async def test_empty_source(self) -> None:
        ctrl = BackpressureController(_async_chunks([]), max_buffer=10)
        collected: list[StreamChunk] = []
        async for chunk in ctrl:
            collected.append(chunk)
        assert collected == []
        assert ctrl.total_received == 0

    async def test_buffer_size_tracks_correctly(self) -> None:
        """Buffer size reflects unconsumed chunks."""
        chunks = [_text_chunk(f"c{i}", i) for i in range(3)]
        chunks.append(_final_chunk(index=3))

        ctrl = BackpressureController(_async_chunks(chunks), max_buffer=64)
        results: list[str] = []
        async for chunk in ctrl:
            results.append(chunk.delta)

        # After full consumption, buffer should be empty
        assert ctrl.buffer_size == 0

    async def test_dropped_count_zero_when_fast(self) -> None:
        chunks = [_text_chunk(f"c{i}") for i in range(3)]
        chunks.append(_final_chunk())
        ctrl = BackpressureController(_async_chunks(chunks), max_buffer=128)
        async for _ in ctrl:
            pass
        assert ctrl.dropped_count == 0


# ===========================================================================
# Integration / composition tests
# ===========================================================================


class TestStreamComposition:
    """Verify that stream components compose correctly."""

    async def test_accumulator_with_transformer(self) -> None:
        """Transformer feeds into accumulator."""
        chunks = [_text_chunk("hello"), _text_chunk(" world"), _final_chunk()]

        transformer = StreamTransformer()
        transformer.add_transform(str.upper)

        acc = StreamAccumulator()
        async for _ in acc.consume(transformer.transform(_async_chunks(chunks))):
            pass

        assert acc.text == "HELLO WORLD"

    async def test_backpressure_into_accumulator(self) -> None:
        """BackpressureController feeds into accumulator."""
        chunks = [_text_chunk(f"tok{i} ") for i in range(10)]
        chunks.append(_final_chunk())

        ctrl = BackpressureController(_async_chunks(chunks), max_buffer=64)
        acc = StreamAccumulator()
        async for _ in acc.consume(ctrl):
            pass

        assert "tok0" in acc.text
        assert "tok9" in acc.text
        assert acc.chunk_count == 11

    async def test_full_pipeline(self) -> None:
        """Source -> Transformer -> Accumulator."""
        usage = UsageStats(prompt_tokens=10, completion_tokens=5, total_tokens=15)
        chunks = [
            _text_chunk("```python\n", 0),
            _text_chunk("x = 1\n", 1),
            _text_chunk("```\n", 2),
            _text_chunk("Done.", 3),
            _final_chunk(FinishReason.STOP, usage=usage, index=4),
        ]

        transformer = StreamTransformer()
        acc = StreamAccumulator()

        async for _ in acc.consume(transformer.transform(_async_chunks(chunks))):
            pass

        result = acc.result()
        assert result.text == "```python\nx = 1\n```\nDone."
        assert result.finish_reason == FinishReason.STOP
        assert result.usage is not None
        assert result.usage.prompt_tokens == 10
        assert result.chunk_count == 5

    async def test_tee_into_accumulator_and_list(self) -> None:
        """StreamTee splits a stream for concurrent consumption."""
        chunks = [_text_chunk("split"), _final_chunk()]
        tee = StreamTee(_async_chunks(chunks), fan_out=2)
        s1, s2 = tee.streams()

        acc = StreamAccumulator()
        log_chunks: list[str] = []

        async def consumer1() -> None:
            async for _ in acc.consume(s1):
                pass

        async def consumer2() -> None:
            async for chunk in s2:
                log_chunks.append(chunk.delta)

        tee.start()
        await asyncio.gather(consumer1(), consumer2())

        assert acc.text == "split"
        assert "split" in log_chunks
