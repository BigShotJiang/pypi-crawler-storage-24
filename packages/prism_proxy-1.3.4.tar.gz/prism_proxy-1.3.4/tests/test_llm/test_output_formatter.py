"""Tests for the output format detection and formatting module."""

from __future__ import annotations

import textwrap

import pytest

from prism.llm.output_formatter import (
    BoundaryMode,
    FormatDetection,
    FormattedOutput,
    FormatType,
    OutputFormatter,
    TruncationConfig,
    estimate_tokens,
)


@pytest.fixture()
def formatter() -> OutputFormatter:
    return OutputFormatter()


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------


class TestTokenEstimation:
    """Tests for the word-based token estimator."""

    def test_empty_string(self) -> None:
        assert estimate_tokens("") == 0

    def test_single_word(self) -> None:
        assert estimate_tokens("hello") >= 1

    def test_longer_text(self) -> None:
        tokens = estimate_tokens("The quick brown fox jumps over the lazy dog")
        # 9 words * 1.3 ≈ 11-12
        assert 10 <= tokens <= 15

    def test_code_text(self) -> None:
        code = "def foo(x):\n    return x + 1"
        assert estimate_tokens(code) > 0


# ---------------------------------------------------------------------------
# Format detection — one test per format type
# ---------------------------------------------------------------------------


class TestFormatDetection:
    """Tests for auto-detecting response format types."""

    def test_detect_json_object(self, formatter: OutputFormatter) -> None:
        text = '{"name": "Alice", "age": 30}'
        det = formatter.detect_format(text)
        assert det.format_type == FormatType.JSON
        assert det.confidence >= 0.8

    def test_detect_json_array(self, formatter: OutputFormatter) -> None:
        text = '[1, 2, 3, "hello"]'
        det = formatter.detect_format(text)
        assert det.format_type == FormatType.JSON

    def test_detect_markdown(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            # Title

            Some **bold** text and a [link](http://example.com).

            - bullet one
            - bullet two
        """)
        det = formatter.detect_format(text)
        assert det.format_type in (FormatType.MARKDOWN, FormatType.MIXED)
        assert det.confidence > 0.4

    def test_detect_code_fenced(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            ```python
            def greet(name):
                return f"Hello, {name}"

            class Greeter:
                def __init__(self):
                    self.count = 0

                def greet(self, name):
                    self.count += 1
                    return f"Hello, {name} (#{self.count})"
            ```
        """)
        det = formatter.detect_format(text)
        assert det.format_type in (FormatType.CODE, FormatType.MARKDOWN, FormatType.MIXED)

    def test_detect_plain_text(self, formatter: OutputFormatter) -> None:
        text = "This is just a simple sentence with no special formatting."
        det = formatter.detect_format(text)
        assert det.format_type == FormatType.PLAIN

    def test_detect_table(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            | Name  | Age | City     |
            |-------|-----|----------|
            | Alice | 30  | New York |
            | Bob   | 25  | London   |
            | Carol | 35  | Paris    |
        """)
        det = formatter.detect_format(text)
        assert det.format_type == FormatType.TABLE

    def test_detect_list(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            - First item
            - Second item
            - Third item
            - Fourth item
            - Fifth item
        """)
        det = formatter.detect_format(text)
        assert det.format_type in (FormatType.LIST, FormatType.MARKDOWN)

    def test_detect_xml(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            <root>
              <person name="Alice">
                <age>30</age>
                <city>New York</city>
              </person>
              <person name="Bob">
                <age>25</age>
              </person>
            </root>
        """)
        det = formatter.detect_format(text)
        assert det.format_type == FormatType.XML

    def test_detect_yaml(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            ---
            name: Alice
            age: 30
            hobbies:
              - reading
              - hiking
            address:
              city: New York
              zip: "10001"
        """)
        det = formatter.detect_format(text)
        assert det.format_type == FormatType.YAML

    def test_detect_empty(self, formatter: OutputFormatter) -> None:
        det = formatter.detect_format("")
        assert det.format_type == FormatType.PLAIN
        assert det.confidence == 1.0

    def test_detect_whitespace_only(self, formatter: OutputFormatter) -> None:
        det = formatter.detect_format("   \n\n  ")
        assert det.format_type == FormatType.PLAIN


# ---------------------------------------------------------------------------
# JSON validation and repair
# ---------------------------------------------------------------------------


class TestJsonValidation:
    """Tests for JSON parsing, validation, and repair."""

    def test_valid_json(self, formatter: OutputFormatter) -> None:
        parsed, issues = formatter.validate_json('{"key": "value"}')
        assert parsed == {"key": "value"}
        assert not issues

    def test_valid_json_array(self, formatter: OutputFormatter) -> None:
        parsed, issues = formatter.validate_json("[1, 2, 3]")
        assert parsed == [1, 2, 3]
        assert not issues

    def test_trailing_comma_object(self, formatter: OutputFormatter) -> None:
        parsed, issues = formatter.validate_json('{"a": 1, "b": 2,}')
        assert parsed is not None
        assert parsed["a"] == 1
        assert parsed["b"] == 2
        assert any("trailing" in i.lower() for i in issues)

    def test_trailing_comma_array(self, formatter: OutputFormatter) -> None:
        parsed, _issues = formatter.validate_json("[1, 2, 3,]")
        assert parsed == [1, 2, 3]

    def test_json_in_code_fence(self, formatter: OutputFormatter) -> None:
        text = '```json\n{"result": true}\n```'
        parsed, issues = formatter.validate_json(text)
        assert parsed == {"result": True}
        assert any("code fence" in i.lower() for i in issues)

    def test_single_quotes_repair(self, formatter: OutputFormatter) -> None:
        parsed, _issues = formatter.validate_json("{'name': 'Alice'}")
        assert parsed is not None
        assert parsed["name"] == "Alice"

    def test_unparseable_json(self, formatter: OutputFormatter) -> None:
        parsed, issues = formatter.validate_json("This is not JSON at all.")
        assert parsed is None
        assert len(issues) > 0

    def test_pretty_print_json(self, formatter: OutputFormatter) -> None:
        data = {"a": 1, "b": [2, 3]}
        result = formatter.pretty_print_json(data)
        assert '"a": 1' in result
        assert "\n" in result  # indented


# ---------------------------------------------------------------------------
# Code block extraction
# ---------------------------------------------------------------------------


class TestCodeBlockExtraction:
    """Tests for extracting fenced code blocks."""

    def test_single_code_block(self, formatter: OutputFormatter) -> None:
        text = "Here is code:\n\n```python\nprint('hello')\n```\n\nEnd."
        blocks = formatter.extract_code_blocks(text)
        assert len(blocks) == 1
        assert blocks[0].language == "python"
        assert "print" in blocks[0].content

    def test_multiple_code_blocks(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            First block:

            ```javascript
            console.log("hi");
            ```

            Second block:

            ```python
            print("hi")
            ```
        """)
        blocks = formatter.extract_code_blocks(text)
        assert len(blocks) == 2
        assert blocks[0].language == "javascript"
        assert blocks[1].language == "python"

    def test_no_language_specified(self, formatter: OutputFormatter) -> None:
        text = "```\ndef foo():\n    pass\n```"
        blocks = formatter.extract_code_blocks(text)
        assert len(blocks) == 1
        # Should attempt language guessing
        assert blocks[0].format_type == FormatType.CODE

    def test_no_code_blocks(self, formatter: OutputFormatter) -> None:
        text = "Just plain text, no code."
        blocks = formatter.extract_code_blocks(text)
        assert len(blocks) == 0

    def test_code_block_line_numbers(self, formatter: OutputFormatter) -> None:
        text = "Line 0\nLine 1\n```python\ncode line\n```\nLine 5"
        blocks = formatter.extract_code_blocks(text)
        assert len(blocks) == 1
        assert blocks[0].start_line >= 2
        assert blocks[0].token_count > 0


# ---------------------------------------------------------------------------
# Table detection
# ---------------------------------------------------------------------------


class TestTableDetection:
    """Tests for markdown table detection and normalisation."""

    def test_simple_table(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            | Name  | Age |
            |-------|-----|
            | Alice | 30  |
            | Bob   | 25  |
        """)
        rows = formatter.detect_table(text)
        assert rows is not None
        assert len(rows) == 3  # header + 2 data rows (separator stripped)
        assert rows[0] == ["Name", "Age"]
        assert rows[1] == ["Alice", "30"]

    def test_no_table(self, formatter: OutputFormatter) -> None:
        rows = formatter.detect_table("Just some text without any table.")
        assert rows is None

    def test_table_to_csv(self, formatter: OutputFormatter) -> None:
        rows = [["Name", "Age"], ["Alice", "30"], ["Bob", "25"]]
        csv_str = formatter.table_to_csv(rows)
        assert "Name" in csv_str
        assert "Alice" in csv_str
        lines = csv_str.strip().split("\n")
        assert len(lines) == 3

    def test_table_to_csv_from_text(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            | Fruit  | Price |
            |--------|-------|
            | Apple  | 1.20  |
            | Banana | 0.50  |
        """)
        csv_str = formatter.table_to_csv_from_text(text)
        assert "Apple" in csv_str
        assert "Banana" in csv_str

    def test_table_to_csv_no_table(self, formatter: OutputFormatter) -> None:
        assert formatter.table_to_csv_from_text("no table here") == ""


# ---------------------------------------------------------------------------
# Smart truncation
# ---------------------------------------------------------------------------


class TestSmartTruncation:
    """Tests for truncation with smart boundary detection."""

    def test_no_truncation_needed(self, formatter: OutputFormatter) -> None:
        text = "Short text."
        config = TruncationConfig(max_tokens=1000)
        result = formatter.truncate(text, config)
        assert result == text

    def test_sentence_boundary(self, formatter: OutputFormatter) -> None:
        text = "First sentence. Second sentence. Third sentence. Fourth sentence."
        config = TruncationConfig(max_tokens=10, boundary_mode=BoundaryMode.SENTENCE)
        result = formatter.truncate(text, config)
        # Should end at a sentence boundary, not mid-sentence
        assert result.rstrip().replace("\n\n... [truncated]", "").endswith(".")

    def test_paragraph_boundary(self, formatter: OutputFormatter) -> None:
        text = "Para one.\n\nPara two.\n\nPara three.\n\nPara four."
        config = TruncationConfig(max_tokens=8, boundary_mode=BoundaryMode.PARAGRAPH)
        result = formatter.truncate(text, config)
        assert "... [truncated]" in result

    def test_hard_truncation(self, formatter: OutputFormatter) -> None:
        text = "A" * 500
        config = TruncationConfig(max_chars=100, boundary_mode=BoundaryMode.HARD)
        result = formatter.truncate(text, config)
        assert len(result) <= 100

    def test_code_block_boundary(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            Some intro text here.

            ```python
            def very_long_function():
                x = 1
                y = 2
                z = 3
                return x + y + z
            ```

            More text after.
        """)
        config = TruncationConfig(max_tokens=12, boundary_mode=BoundaryMode.CODE_BLOCK)
        result = formatter.truncate(text, config)
        # Should not cut in the middle of the code block
        fence_count = result.count("```")
        # Either 0 fences (cut before code) or 2 (complete block)
        assert fence_count % 2 == 0 or "... [truncated]" in result

    def test_custom_ellipsis(self, formatter: OutputFormatter) -> None:
        text = "Word " * 200
        config = TruncationConfig(max_tokens=10, ellipsis=" [...]")
        result = formatter.truncate(text, config)
        assert result.endswith("[...]")

    def test_max_chars_truncation(self, formatter: OutputFormatter) -> None:
        text = "Hello world. " * 100
        config = TruncationConfig(max_tokens=99999, max_chars=50, boundary_mode=BoundaryMode.SENTENCE)
        result = formatter.truncate(text, config)
        assert len(result) <= 50


# ---------------------------------------------------------------------------
# Multi-section splitting
# ---------------------------------------------------------------------------


class TestSectionSplitting:
    """Tests for splitting responses into typed sections."""

    def test_code_and_prose(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            Here is how to do it:

            ```python
            print("hello")
            ```

            That prints a greeting.
        """)
        sections = formatter.split_sections(text)
        types = [s.format_type for s in sections]
        assert FormatType.CODE in types
        assert FormatType.PLAIN in types

    def test_single_prose_section(self, formatter: OutputFormatter) -> None:
        text = "Just a single paragraph of text."
        sections = formatter.split_sections(text)
        assert len(sections) >= 1
        assert sections[0].format_type == FormatType.PLAIN

    def test_empty_text(self, formatter: OutputFormatter) -> None:
        assert formatter.split_sections("") == []
        assert formatter.split_sections("   ") == []

    def test_table_section(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            Results:

            | A | B |
            |---|---|
            | 1 | 2 |

            Done.
        """)
        sections = formatter.split_sections(text)
        types = [s.format_type for s in sections]
        assert FormatType.TABLE in types

    def test_sections_have_token_counts(self, formatter: OutputFormatter) -> None:
        text = "Hello world.\n\n```python\nx = 1\n```\n\nGoodbye."
        sections = formatter.split_sections(text)
        for sec in sections:
            assert sec.token_count >= 0


# ---------------------------------------------------------------------------
# Format conversion
# ---------------------------------------------------------------------------


class TestFormatConversion:
    """Tests for converting between formats."""

    def test_json_to_yaml_simple(self, formatter: OutputFormatter) -> None:
        j = '{"name": "Alice", "age": 30}'
        yaml_str = formatter.json_to_yaml(j)
        assert "name:" in yaml_str
        assert "Alice" in yaml_str
        assert "age:" in yaml_str

    def test_json_to_yaml_nested(self, formatter: OutputFormatter) -> None:
        j = '{"person": {"name": "Bob", "hobbies": ["reading", "hiking"]}}'
        yaml_str = formatter.json_to_yaml(j)
        assert "person:" in yaml_str
        assert "hobbies:" in yaml_str
        assert "- reading" in yaml_str

    def test_json_to_yaml_invalid_raises(self, formatter: OutputFormatter) -> None:
        with pytest.raises(ValueError, match="not valid JSON"):
            formatter.json_to_yaml("not json")

    def test_json_to_yaml_empty_object(self, formatter: OutputFormatter) -> None:
        yaml_str = formatter.json_to_yaml("{}")
        assert yaml_str.strip() == "{}"

    def test_json_to_yaml_empty_array(self, formatter: OutputFormatter) -> None:
        yaml_str = formatter.json_to_yaml("[]")
        assert yaml_str.strip() == "[]"

    def test_json_to_yaml_booleans(self, formatter: OutputFormatter) -> None:
        yaml_str = formatter.json_to_yaml('{"active": true, "deleted": false}')
        assert "true" in yaml_str
        assert "false" in yaml_str

    def test_json_to_yaml_null(self, formatter: OutputFormatter) -> None:
        yaml_str = formatter.json_to_yaml('{"value": null}')
        assert "null" in yaml_str

    def test_markdown_to_plain(self, formatter: OutputFormatter) -> None:
        md = textwrap.dedent("""\
            # My Title

            Some **bold** and *italic* text.

            ```python
            x = 1
            ```

            > A quote

            [Click here](http://example.com)
        """)
        plain = formatter.markdown_to_plain(md)
        assert "#" not in plain.split("\n")[0]  # heading marker removed
        assert "**" not in plain
        assert "*italic*" not in plain  # asterisks stripped
        assert "```" not in plain
        assert "Click here" in plain
        assert "http://example.com" not in plain  # link URL removed
        assert ">" not in plain or plain.count(">") == 0  # blockquote stripped


# ---------------------------------------------------------------------------
# Quality scoring
# ---------------------------------------------------------------------------


class TestQualityScoring:
    """Tests for response quality heuristics."""

    def test_empty_response(self, formatter: OutputFormatter) -> None:
        assert formatter.score_quality("") == 0.0

    def test_well_formed_response(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            # Explanation

            Here is how it works.

            ```python
            def foo():
                return 42
            ```

            This function returns 42.
        """)
        score = formatter.score_quality(text)
        assert score >= 0.7

    def test_cutoff_response(self, formatter: OutputFormatter) -> None:
        text = "This sentence does not end properly and has unbalanced brackets ({["
        score = formatter.score_quality(text)
        # Should be penalised
        assert score < 0.8

    def test_repetitive_response(self, formatter: OutputFormatter) -> None:
        chunk = "A" * 50
        text = chunk * 5
        score = formatter.score_quality(text)
        assert score < 0.9


# ---------------------------------------------------------------------------
# FormattedOutput integration
# ---------------------------------------------------------------------------


class TestFormattedOutput:
    """Integration tests for format_response producing FormattedOutput."""

    def test_format_response_basic(self, formatter: OutputFormatter) -> None:
        text = "Hello, world!"
        out = formatter.format_response(text)
        assert isinstance(out, FormattedOutput)
        assert out.total_tokens > 0
        assert 0.0 <= out.quality_score <= 1.0
        assert isinstance(out.detected_format, FormatDetection)
        assert len(out.sections) >= 1

    def test_format_response_mixed(self, formatter: OutputFormatter) -> None:
        text = textwrap.dedent("""\
            # Answer

            Here is the solution:

            ```python
            print("done")
            ```

            That's all.
        """)
        out = formatter.format_response(text)
        assert out.total_tokens > 0
        assert out.metadata["section_count"] >= 1
        assert out.metadata["char_count"] == len(text)

    def test_format_response_json(self, formatter: OutputFormatter) -> None:
        text = '{"status": "ok", "count": 42}'
        out = formatter.format_response(text)
        assert out.detected_format.format_type == FormatType.JSON


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Edge case and boundary tests."""

    def test_very_long_text_detection(self, formatter: OutputFormatter) -> None:
        text = "word " * 10_000
        det = formatter.detect_format(text)
        assert det.format_type is not None  # should not crash

    def test_nested_code_fences(self, formatter: OutputFormatter) -> None:
        # Inner fences are tricky but the regex should handle the first match
        text = "```python\nprint('```')\n```"
        blocks = formatter.extract_code_blocks(text)
        assert len(blocks) >= 1

    def test_unicode_content(self, formatter: OutputFormatter) -> None:
        text = "Ici c'est du francais. Les accents: e, e, a, u."
        det = formatter.detect_format(text)
        assert det.format_type == FormatType.PLAIN

    def test_only_code_fence_markers(self, formatter: OutputFormatter) -> None:
        text = "```\n```"
        blocks = formatter.extract_code_blocks(text)
        # Empty code block — may or may not produce a section
        assert isinstance(blocks, list)

    def test_truncation_tiny_limit(self, formatter: OutputFormatter) -> None:
        text = "Hello world, this is a test."
        config = TruncationConfig(max_chars=5, boundary_mode=BoundaryMode.HARD)
        result = formatter.truncate(text, config)
        assert len(result) <= 5

    def test_format_detection_returns_sections(self, formatter: OutputFormatter) -> None:
        text = "Line one.\n\n```js\nalert(1)\n```\n\nLine three."
        det = formatter.detect_format(text)
        assert isinstance(det.sections, list)
        assert len(det.sections) >= 1

    def test_score_quality_whitespace(self, formatter: OutputFormatter) -> None:
        assert formatter.score_quality("   \n\t  ") == 0.0

    def test_json_to_yaml_with_special_chars(self, formatter: OutputFormatter) -> None:
        j = '{"key": "value: with colons & ampersands"}'
        yaml_str = formatter.json_to_yaml(j)
        assert "key:" in yaml_str

    def test_markdown_to_plain_image(self, formatter: OutputFormatter) -> None:
        md = "Look at this: ![alt text](http://img.png)"
        plain = formatter.markdown_to_plain(md)
        assert "![" not in plain
        assert "alt text" in plain
