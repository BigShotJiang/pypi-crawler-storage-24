"""Tests for prism.llm.thinking — extended thinking support."""

from __future__ import annotations

import pytest

from prism.llm.thinking import (
    THINKING_MODELS,
    ThinkingAdapter,
    ThinkingConfig,
    ThinkingMode,
    ThinkingResult,
    _is_anthropic_thinking,
    _is_deepseek_reasoner,
    _is_openai_reasoning,
)

# ---------------------------------------------------------------------------
# ThinkingConfig tests
# ---------------------------------------------------------------------------


class TestThinkingConfig:
    """Tests for ThinkingConfig dataclass."""

    def test_default_values(self) -> None:
        """Default config has sensible defaults."""
        cfg = ThinkingConfig()
        assert cfg.enabled is False
        assert cfg.max_thinking_tokens == 8192
        assert cfg.show_thinking is False
        assert cfg.thinking_model_ids == THINKING_MODELS

    def test_custom_values(self) -> None:
        """Custom values are accepted."""
        cfg = ThinkingConfig(
            enabled=True,
            max_thinking_tokens=16384,
            show_thinking=True,
            thinking_model_ids={"o3"},
        )
        assert cfg.enabled is True
        assert cfg.max_thinking_tokens == 16384
        assert cfg.show_thinking is True
        assert cfg.thinking_model_ids == {"o3"}

    def test_negative_thinking_tokens_rejected(self) -> None:
        """Negative token budget raises ValueError."""
        with pytest.raises(ValueError, match="non-negative"):
            ThinkingConfig(max_thinking_tokens=-1)

    def test_zero_thinking_tokens_accepted(self) -> None:
        """Zero token budget is valid (disables thinking)."""
        cfg = ThinkingConfig(max_thinking_tokens=0)
        assert cfg.max_thinking_tokens == 0


# ---------------------------------------------------------------------------
# ThinkingMode tests
# ---------------------------------------------------------------------------


class TestThinkingMode:
    """Tests for ThinkingMode enum."""

    def test_all_modes_defined(self) -> None:
        """All expected modes exist."""
        assert ThinkingMode.NONE == "NONE"
        assert ThinkingMode.BASIC == "BASIC"
        assert ThinkingMode.EXTENDED == "EXTENDED"
        assert ThinkingMode.MAX == "MAX"

    def test_mode_count(self) -> None:
        """Exactly 4 modes defined."""
        assert len(ThinkingMode) == 4


# ---------------------------------------------------------------------------
# ThinkingResult tests
# ---------------------------------------------------------------------------


class TestThinkingResult:
    """Tests for ThinkingResult dataclass."""

    def test_frozen(self) -> None:
        """ThinkingResult is immutable."""
        result = ThinkingResult(
            thinking_content="reasoning here",
            output_content="answer",
            thinking_tokens=100,
            output_tokens=50,
            total_tokens=150,
            thinking_time_ms=42.0,
            mode_used=ThinkingMode.EXTENDED,
        )
        with pytest.raises(AttributeError):
            result.thinking_content = "changed"  # type: ignore[misc]

    def test_field_access(self) -> None:
        """All fields are accessible."""
        result = ThinkingResult(
            thinking_content="step 1, step 2",
            output_content="42",
            thinking_tokens=200,
            output_tokens=10,
            total_tokens=210,
            thinking_time_ms=100.5,
            mode_used=ThinkingMode.MAX,
        )
        assert result.thinking_content == "step 1, step 2"
        assert result.output_content == "42"
        assert result.thinking_tokens == 200
        assert result.output_tokens == 10
        assert result.total_tokens == 210
        assert result.thinking_time_ms == 100.5
        assert result.mode_used == ThinkingMode.MAX


# ---------------------------------------------------------------------------
# Provider detection helpers
# ---------------------------------------------------------------------------


class TestProviderDetection:
    """Tests for provider detection helper functions."""

    def test_openai_reasoning_detection(self) -> None:
        """Detect OpenAI o-series models."""
        assert _is_openai_reasoning("o3") is True
        assert _is_openai_reasoning("o3-mini") is True
        assert _is_openai_reasoning("o4-mini") is True
        assert _is_openai_reasoning("gpt-4o") is False
        assert _is_openai_reasoning("deepseek/deepseek-reasoner") is False

    def test_anthropic_thinking_detection(self) -> None:
        """Detect Anthropic extended thinking models."""
        assert _is_anthropic_thinking("anthropic/claude-sonnet-4-20250514") is True
        assert _is_anthropic_thinking("anthropic/claude-opus-4-20250514") is True
        assert _is_anthropic_thinking("claude-sonnet-4-20250514") is False
        assert _is_anthropic_thinking("o3") is False

    def test_deepseek_reasoner_detection(self) -> None:
        """Detect DeepSeek reasoning model."""
        assert _is_deepseek_reasoner("deepseek/deepseek-reasoner") is True
        assert _is_deepseek_reasoner("deepseek/deepseek-chat") is False
        assert _is_deepseek_reasoner("o3") is False


# ---------------------------------------------------------------------------
# THINKING_MODELS constant
# ---------------------------------------------------------------------------


class TestThinkingModels:
    """Tests for the THINKING_MODELS constant."""

    def test_contains_expected_models(self) -> None:
        """All expected models are in the set."""
        assert "o3" in THINKING_MODELS
        assert "o3-mini" in THINKING_MODELS
        assert "o4-mini" in THINKING_MODELS
        assert "anthropic/claude-sonnet-4-20250514" in THINKING_MODELS
        assert "anthropic/claude-opus-4-20250514" in THINKING_MODELS
        assert "deepseek/deepseek-reasoner" in THINKING_MODELS

    def test_non_thinking_models_excluded(self) -> None:
        """Non-thinking models are not in the set."""
        assert "gpt-4o" not in THINKING_MODELS
        assert "gpt-4o-mini" not in THINKING_MODELS
        assert "deepseek/deepseek-chat" not in THINKING_MODELS


# ---------------------------------------------------------------------------
# ThinkingAdapter.prepare_request tests
# ---------------------------------------------------------------------------


class TestPrepareRequest:
    """Tests for ThinkingAdapter.prepare_request."""

    def setup_method(self) -> None:
        """Create adapter instance."""
        self.adapter = ThinkingAdapter()
        self.messages = [{"role": "user", "content": "Solve this math problem."}]

    def test_disabled_returns_empty(self) -> None:
        """When thinking is disabled, returns empty dict."""
        cfg = ThinkingConfig(enabled=False)
        result = self.adapter.prepare_request("o3", self.messages, cfg)
        assert result == {}

    def test_unsupported_model_returns_empty(self) -> None:
        """Unsupported model returns empty dict even if enabled."""
        cfg = ThinkingConfig(enabled=True)
        result = self.adapter.prepare_request("gpt-4o", self.messages, cfg)
        assert result == {}

    def test_openai_o3_preparation(self) -> None:
        """OpenAI o3 gets reasoning_effort parameter."""
        cfg = ThinkingConfig(enabled=True, max_thinking_tokens=8192)
        result = self.adapter.prepare_request("o3", self.messages, cfg)
        assert "reasoning_effort" in result
        assert result["reasoning_effort"] == "medium"

    def test_openai_low_budget_gets_low_effort(self) -> None:
        """Low token budget maps to low reasoning effort."""
        cfg = ThinkingConfig(enabled=True, max_thinking_tokens=1024)
        result = self.adapter.prepare_request("o3", self.messages, cfg)
        assert result["reasoning_effort"] == "low"

    def test_openai_high_budget_gets_high_effort(self) -> None:
        """High token budget maps to high reasoning effort."""
        cfg = ThinkingConfig(enabled=True, max_thinking_tokens=32768)
        result = self.adapter.prepare_request("o3", self.messages, cfg)
        assert result["reasoning_effort"] == "high"

    def test_anthropic_preparation(self) -> None:
        """Anthropic models get thinking parameter."""
        cfg = ThinkingConfig(enabled=True, max_thinking_tokens=4096)
        result = self.adapter.prepare_request(
            "anthropic/claude-sonnet-4-20250514",
            self.messages,
            cfg,
        )
        assert "thinking" in result
        assert result["thinking"]["type"] == "enabled"
        assert result["thinking"]["budget_tokens"] == 4096

    def test_deepseek_preparation(self) -> None:
        """DeepSeek reasoner gets extra_body with enable_thinking."""
        cfg = ThinkingConfig(enabled=True, max_thinking_tokens=8192)
        result = self.adapter.prepare_request(
            "deepseek/deepseek-reasoner",
            self.messages,
            cfg,
        )
        assert "extra_body" in result
        assert result["extra_body"]["enable_thinking"] is True


# ---------------------------------------------------------------------------
# ThinkingAdapter.parse_response tests
# ---------------------------------------------------------------------------


class TestParseResponse:
    """Tests for ThinkingAdapter.parse_response."""

    def setup_method(self) -> None:
        """Create adapter instance."""
        self.adapter = ThinkingAdapter()

    def test_openai_with_reasoning_content(self) -> None:
        """Parse OpenAI response with reasoning_content."""
        raw = {
            "choices": [{
                "message": {
                    "reasoning_content": "Let me think step by step...",
                    "content": "The answer is 42.",
                },
            }],
            "usage": {
                "completion_tokens": 50,
                "completion_tokens_details": {"reasoning_tokens": 30},
            },
        }
        result = self.adapter.parse_response(raw, "o3")
        assert result.thinking_content == "Let me think step by step..."
        assert result.output_content == "The answer is 42."
        assert result.thinking_tokens == 30
        assert result.mode_used == ThinkingMode.EXTENDED

    def test_openai_without_reasoning(self) -> None:
        """Parse OpenAI response without reasoning content."""
        raw = {
            "choices": [{"message": {"content": "Simple answer."}}],
            "usage": {"completion_tokens": 10},
        }
        result = self.adapter.parse_response(raw, "o3")
        assert result.thinking_content == ""
        assert result.output_content == "Simple answer."
        assert result.mode_used == ThinkingMode.NONE

    def test_deepseek_think_tags(self) -> None:
        """Parse DeepSeek response with <think> tags."""
        raw = {
            "choices": [{
                "message": {
                    "content": (
                        "<think>First I need to consider...</think>"
                        "The answer is 7."
                    ),
                },
            }],
            "usage": {"completion_tokens": 40},
        }
        result = self.adapter.parse_response(raw, "deepseek/deepseek-reasoner")
        assert "First I need to consider" in result.thinking_content
        assert result.output_content == "The answer is 7."
        assert result.mode_used == ThinkingMode.EXTENDED

    def test_deepseek_reasoning_content_field(self) -> None:
        """Parse DeepSeek response with reasoning_content field."""
        raw = {
            "choices": [{
                "message": {
                    "reasoning_content": "Step 1... Step 2...",
                    "content": "Final answer: 3.",
                },
            }],
            "usage": {"completion_tokens": 30},
        }
        result = self.adapter.parse_response(raw, "deepseek/deepseek-reasoner")
        assert result.thinking_content == "Step 1... Step 2..."
        assert result.output_content == "Final answer: 3."

    def test_anthropic_thinking_blocks(self) -> None:
        """Parse Anthropic response with thinking content blocks."""
        raw = {
            "content": [
                {"type": "thinking", "thinking": "Let me reason about this..."},
                {"type": "text", "text": "The solution is X."},
            ],
            "usage": {"output_tokens": 25, "thinking_tokens": 50},
        }
        result = self.adapter.parse_response(
            raw, "anthropic/claude-sonnet-4-20250514",
        )
        assert "Let me reason about this" in result.thinking_content
        assert result.output_content == "The solution is X."
        assert result.mode_used == ThinkingMode.EXTENDED

    def test_generic_model_no_thinking(self) -> None:
        """Generic model returns NONE mode with no thinking."""
        raw = {
            "choices": [{"message": {"content": "Hello!"}}],
            "usage": {"completion_tokens": 5},
        }
        result = self.adapter.parse_response(raw, "gpt-4o")
        assert result.thinking_content == ""
        assert result.output_content == "Hello!"
        assert result.mode_used == ThinkingMode.NONE

    def test_empty_response_handled(self) -> None:
        """Empty response is handled gracefully."""
        raw = {"choices": [], "usage": {}}
        result = self.adapter.parse_response(raw, "o3")
        assert result.thinking_content == ""
        assert result.output_content == ""
        assert result.mode_used == ThinkingMode.NONE


# ---------------------------------------------------------------------------
# ThinkingAdapter.should_use_thinking tests
# ---------------------------------------------------------------------------


class TestShouldUseThinking:
    """Tests for ThinkingAdapter.should_use_thinking."""

    def setup_method(self) -> None:
        """Create adapter instance."""
        self.adapter = ThinkingAdapter()

    def test_complex_tier_always_recommends(self) -> None:
        """Complex tasks always get thinking recommendation."""
        assert self.adapter.should_use_thinking("hello world", "complex") is True

    def test_simple_tier_usually_skips(self) -> None:
        """Simple tasks skip thinking unless reasoning is requested."""
        assert self.adapter.should_use_thinking("hello world", "simple") is False

    def test_simple_tier_with_reasoning_request(self) -> None:
        """Simple tasks with explicit reasoning request get thinking."""
        assert self.adapter.should_use_thinking(
            "prove that 2+2=4", "simple",
        ) is True

    def test_math_keywords_trigger_thinking(self) -> None:
        """Math-related keywords recommend thinking."""
        assert self.adapter.should_use_thinking(
            "calculate the derivative of x^2", "medium",
        ) is True

    def test_step_by_step_triggers_thinking(self) -> None:
        """Step-by-step requests trigger thinking."""
        assert self.adapter.should_use_thinking(
            "explain step by step how sorting works", "medium",
        ) is True

    def test_translation_skips_thinking(self) -> None:
        """Translation requests skip thinking."""
        assert self.adapter.should_use_thinking(
            "translate this to French", "medium",
        ) is False

    def test_creative_writing_skips_thinking(self) -> None:
        """Creative writing skips thinking."""
        assert self.adapter.should_use_thinking(
            "write a poem about the ocean", "medium",
        ) is False

    def test_empty_prompt_returns_false(self) -> None:
        """Empty prompt returns False."""
        assert self.adapter.should_use_thinking("", "medium") is False

    def test_whitespace_only_returns_false(self) -> None:
        """Whitespace-only prompt returns False."""
        assert self.adapter.should_use_thinking("   ", "medium") is False

    def test_architecture_triggers_thinking(self) -> None:
        """Architecture design questions trigger thinking."""
        assert self.adapter.should_use_thinking(
            "design the architecture for a microservices system", "medium",
        ) is True

    def test_debug_triggers_thinking(self) -> None:
        """Debugging requests trigger thinking."""
        assert self.adapter.should_use_thinking(
            "debug this null pointer exception", "medium",
        ) is True


# ---------------------------------------------------------------------------
# ThinkingAdapter.estimate_thinking_cost tests
# ---------------------------------------------------------------------------


class TestEstimateThinkingCost:
    """Tests for ThinkingAdapter.estimate_thinking_cost."""

    def setup_method(self) -> None:
        """Create adapter instance."""
        self.adapter = ThinkingAdapter()

    def test_known_model_returns_positive_cost(self) -> None:
        """Known model returns a positive cost estimate."""
        cost = self.adapter.estimate_thinking_cost("o3", 8192)
        assert cost > 0.0

    def test_zero_tokens_returns_zero(self) -> None:
        """Zero thinking tokens returns zero cost."""
        cost = self.adapter.estimate_thinking_cost("o3", 0)
        assert cost == 0.0

    def test_negative_tokens_returns_zero(self) -> None:
        """Negative thinking tokens returns zero cost."""
        cost = self.adapter.estimate_thinking_cost("o3", -100)
        assert cost == 0.0

    def test_unknown_model_returns_zero(self) -> None:
        """Unknown model returns zero cost."""
        cost = self.adapter.estimate_thinking_cost("unknown/model", 8192)
        assert cost == 0.0

    def test_more_tokens_costs_more(self) -> None:
        """Higher token budget results in higher cost."""
        cost_low = self.adapter.estimate_thinking_cost("o3", 1000)
        cost_high = self.adapter.estimate_thinking_cost("o3", 10000)
        assert cost_high > cost_low

    def test_expensive_model_costs_more(self) -> None:
        """Expensive model has higher thinking cost than cheap model."""
        cost_expensive = self.adapter.estimate_thinking_cost("o3", 8192)
        cost_cheap = self.adapter.estimate_thinking_cost("o4-mini", 8192)
        assert cost_expensive > cost_cheap

    def test_anthropic_model_with_prefix(self) -> None:
        """Anthropic model with provider prefix works."""
        cost = self.adapter.estimate_thinking_cost(
            "anthropic/claude-sonnet-4-20250514", 8192,
        )
        assert cost > 0.0
