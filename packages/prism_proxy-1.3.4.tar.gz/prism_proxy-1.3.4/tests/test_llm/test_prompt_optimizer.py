"""Tests for the prompt optimization engine."""

from __future__ import annotations

import pytest

from prism.llm.prompt_optimizer import (
    OptimizationResult,
    PromptOptimizer,
    PromptScore,
)


@pytest.fixture()
def optimizer() -> PromptOptimizer:
    return PromptOptimizer()


# ---------------------------------------------------------------------------
# Optimization tests
# ---------------------------------------------------------------------------


class TestOptimize:
    """Tests for prompt optimization."""

    def test_basic_optimization(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Write a function to add two numbers."},
        ]
        result = optimizer.optimize(messages)
        assert isinstance(result, OptimizationResult)
        assert len(result.messages) >= 1

    def test_preserves_content(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "user", "content": "Hello world"},
        ]
        result = optimizer.optimize(messages)
        assert any("Hello world" in m["content"] for m in result.messages)

    def test_removes_filler_phrases(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "user", "content": "Please note that I need you to write code. It is important to note that it should work."},
        ]
        result = optimizer.optimize(messages)
        content = result.messages[0]["content"]
        assert "please note that" not in content.lower()
        assert "it is important to note that" not in content.lower()

    def test_merges_system_messages(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "system", "content": "You are concise."},
            {"role": "user", "content": "Hello"},
        ]
        result = optimizer.optimize(messages)
        system_count = sum(1 for m in result.messages if m["role"] == "system")
        assert system_count <= 1

    def test_collapses_whitespace(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "user", "content": "Hello\n\n\n\nWorld   with   spaces"},
        ]
        result = optimizer.optimize(messages)
        content = result.messages[0]["content"]
        assert "\n\n\n" not in content
        assert "   " not in content

    def test_token_savings_reported(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "user", "content": "Please note that I would like you to please make sure to write code."},
        ]
        result = optimizer.optimize(messages)
        assert result.original_tokens > 0
        assert result.optimized_tokens >= 0

    def test_changes_tracked(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "Be helpful."},
            {"role": "system", "content": "Be concise."},
            {"role": "user", "content": "Please note that I need help."},
        ]
        result = optimizer.optimize(messages)
        assert len(result.changes_applied) > 0

    def test_budget_enforcement(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "System prompt."},
            {"role": "user", "content": "First question " * 50},
            {"role": "assistant", "content": "Response " * 50},
            {"role": "user", "content": "Second question " * 50},
            {"role": "assistant", "content": "Another response " * 50},
            {"role": "user", "content": "Final question"},
        ]
        result = optimizer.optimize(messages, max_tokens=50)
        assert result.optimized_tokens <= result.original_tokens

    def test_model_specific_optimization(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": " ".join(["instruction"] * 200)},
            {"role": "user", "content": "Hello"},
        ]
        result = optimizer.optimize(messages, model="gpt-4o-mini")
        # Should truncate system prompt for mini model
        assert isinstance(result, OptimizationResult)


# ---------------------------------------------------------------------------
# Scoring tests
# ---------------------------------------------------------------------------


class TestScoring:
    """Tests for prompt quality scoring."""

    def test_basic_score(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "You are a helpful coding assistant."},
            {"role": "user", "content": "Write a Python function that sorts a list of integers in ascending order."},
        ]
        score = optimizer.score_prompt(messages)
        assert isinstance(score, PromptScore)
        assert 0 <= score.overall <= 1

    def test_vague_prompt_penalized(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "user", "content": "Do something with stuff and things maybe"},
        ]
        score = optimizer.score_prompt(messages)
        assert score.clarity < 0.8

    def test_short_prompt_penalized(self, optimizer: PromptOptimizer) -> None:
        messages = [{"role": "user", "content": "Help"}]
        score = optimizer.score_prompt(messages)
        assert score.specificity < 0.6

    def test_well_structured_prompt(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "You are a code review assistant. Always provide specific, actionable feedback."},
            {"role": "user", "content": "Review this Python function for bugs, performance issues, and style. Format your response in markdown with separate sections for each category. Maximum 500 words."},
        ]
        score = optimizer.score_prompt(messages)
        assert score.overall >= 0.5
        assert score.structure >= 0.5

    def test_score_has_suggestions(self, optimizer: PromptOptimizer) -> None:
        messages = [{"role": "user", "content": "Do something"}]
        score = optimizer.score_prompt(messages)
        assert len(score.suggestions) > 0 or len(score.issues) > 0

    def test_estimated_tokens(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "user", "content": "This is a test prompt with some words in it."},
        ]
        score = optimizer.score_prompt(messages)
        assert score.estimated_tokens > 0

    def test_filler_phrases_detected(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "user", "content": "Please note that it is important to note that you should respond."},
        ]
        score = optimizer.score_prompt(messages)
        assert score.conciseness < 0.8


# ---------------------------------------------------------------------------
# Helper method tests
# ---------------------------------------------------------------------------


class TestHelpers:
    """Tests for helper methods."""

    def test_merge_system_messages(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "Rule 1"},
            {"role": "system", "content": "Rule 2"},
            {"role": "user", "content": "Hello"},
        ]
        merged = optimizer.merge_system_messages(messages)
        system_msgs = [m for m in merged if m["role"] == "system"]
        assert len(system_msgs) == 1
        assert "Rule 1" in system_msgs[0]["content"]
        assert "Rule 2" in system_msgs[0]["content"]

    def test_merge_preserves_order(self, optimizer: PromptOptimizer) -> None:
        messages = [
            {"role": "system", "content": "System"},
            {"role": "user", "content": "User 1"},
            {"role": "assistant", "content": "Assistant 1"},
        ]
        merged = optimizer.merge_system_messages(messages)
        roles = [m["role"] for m in merged]
        assert roles == ["system", "user", "assistant"]

    def test_add_json_format(self, optimizer: PromptOptimizer) -> None:
        messages = [{"role": "user", "content": "Get data"}]
        result = optimizer.add_output_format(messages, "json")
        assert "JSON" in result[-1]["content"]

    def test_add_json_with_schema(self, optimizer: PromptOptimizer) -> None:
        messages = [{"role": "user", "content": "Get data"}]
        schema = {"properties": {"name": {"type": "string"}, "age": {"type": "integer"}}}
        result = optimizer.add_output_format(messages, "json", schema=schema)
        content = result[-1]["content"]
        assert "name" in content
        assert "age" in content

    def test_add_markdown_format(self, optimizer: PromptOptimizer) -> None:
        messages = [{"role": "user", "content": "Explain AI"}]
        result = optimizer.add_output_format(messages, "markdown")
        assert "markdown" in result[-1]["content"].lower()

    def test_add_code_format(self, optimizer: PromptOptimizer) -> None:
        messages = [{"role": "user", "content": "Write a sort"}]
        result = optimizer.add_output_format(messages, "code")
        assert "code" in result[-1]["content"].lower()
