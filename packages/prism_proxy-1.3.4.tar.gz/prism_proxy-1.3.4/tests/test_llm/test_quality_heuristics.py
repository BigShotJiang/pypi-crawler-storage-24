"""Tests for response quality heuristics."""

from __future__ import annotations

import pytest

from prism.llm.quality_heuristics import QualityEstimator, quick_quality_check


class TestQualityEstimator:
    """Tests for the QualityEstimator class."""

    @pytest.fixture()
    def estimator(self) -> QualityEstimator:
        return QualityEstimator()

    def test_good_code_response(self, estimator: QualityEstimator) -> None:
        prompt = "Write a Python function to sort a list"
        response = """Here's a function to sort a list:

```python
from typing import List

def sort_list(items: List[int]) -> List[int]:
    return sorted(items)
```

This uses Python's built-in `sorted()` function which implements Timsort."""
        assessment = estimator.assess(response, prompt)
        assert assessment.overall_score >= 0.7
        assert assessment.completeness >= 0.7
        assert assessment.code_quality >= 0.7

    def test_empty_response(self, estimator: QualityEstimator) -> None:
        assessment = estimator.assess("", "Write something")
        assert assessment.overall_score < 0.3
        assert "Empty response" in assessment.issues

    def test_truncated_response(self, estimator: QualityEstimator) -> None:
        prompt = "Explain how databases work"
        response = "Databases store data in tables. Each table has columns and rows. The data is"
        assessment = estimator.assess(response, prompt)
        assert assessment.coherence < 1.0
        assert any("truncated" in issue.lower() for issue in assessment.issues)

    def test_repetitive_response(self, estimator: QualityEstimator) -> None:
        prompt = "Write a poem"
        repeated = "The cat sat on the mat and looked around. " * 20
        assessment = estimator.assess(repeated, prompt)
        assert assessment.coherence < 0.8

    def test_irrelevant_response(self, estimator: QualityEstimator) -> None:
        prompt = "How do I configure nginx"
        response = "The weather today is sunny with temperatures around 75°F."
        assessment = estimator.assess(response, prompt)
        assert assessment.relevance < 0.5

    def test_hallucination_detection_fake_url(self, estimator: QualityEstimator) -> None:
        prompt = "How do I use the API?"
        response = "Check the docs at https://docs.fake.example.com/api/v2 for details."
        assessment = estimator.assess(response, prompt)
        assert assessment.hallucination_risk > 0.0

    def test_code_with_unbalanced_brackets(self, estimator: QualityEstimator) -> None:
        prompt = "Write a function"
        response = """```python
def foo():
    if True:
        return {
            "key": "value"
```"""
        assessment = estimator.assess(response, prompt)
        assert assessment.coherence < 1.0

    def test_good_explanation_response(self, estimator: QualityEstimator) -> None:
        prompt = "Explain how Python generators work"
        response = (
            "Python generators are functions that use the `yield` keyword to produce "
            "a sequence of values lazily. Instead of computing all values at once "
            "and storing them in memory, a generator produces values one at a time "
            "and only when requested.\n\n"
            "Key benefits:\n"
            "- Memory efficient for large datasets\n"
            "- Can represent infinite sequences\n"
            "- Composable with other generators\n\n"
            "Example:\n```python\ndef count_up(n):\n    i = 0\n    while i < n:\n"
            "        yield i\n        i += 1\n```"
        )
        assessment = estimator.assess(response, prompt)
        assert assessment.overall_score >= 0.7

    def test_skip_judge_recommendation(self, estimator: QualityEstimator) -> None:
        prompt = "Calculate the sum of 2+2"
        response = "The sum of 2 + 2 equals 4. This is a basic arithmetic calculation."
        assessment = estimator.assess(response, prompt)
        # Simple, correct, no issues → should have decent score
        assert assessment.overall_score >= 0.65

    def test_short_response_to_complex_prompt(self, estimator: QualityEstimator) -> None:
        prompt = (
            "Design a microservice architecture for a real-time chat application "
            "with support for WebSocket connections, message persistence, "
            "user authentication, and horizontal scaling."
        )
        response = "Use WebSockets."
        assessment = estimator.assess(response, prompt)
        assert assessment.length_adequacy < 0.5


class TestQuickQualityCheck:
    """Tests for the convenience quick_quality_check function."""

    def test_returns_float(self) -> None:
        score = quick_quality_check("Hello world.", "Say hello")
        assert isinstance(score, float)
        assert 0.0 <= score <= 1.0

    def test_empty_response_low_score(self) -> None:
        score = quick_quality_check("", "Do something")
        assert score < 0.3
