"""Tests for the response quality evaluation engine."""

from __future__ import annotations

import pytest

from prism.llm.quality_evaluator import (
    IssueSeverity,
    ModelQualityHistory,
    QualityComparison,
    QualityConfig,
    QualityDimension,
    QualityEvaluator,
    QualityIssue,
    QualityScore,
    _tfidf_similarity,
    _tokenize,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def evaluator() -> QualityEvaluator:
    """Default quality evaluator with standard config."""
    return QualityEvaluator()


@pytest.fixture()
def custom_evaluator() -> QualityEvaluator:
    """Evaluator with custom weights emphasising relevance."""
    config = QualityConfig(
        weight_relevance=0.40,
        weight_completeness=0.20,
        weight_coherence=0.15,
        weight_conciseness=0.10,
        weight_correctness=0.15,
    )
    return QualityEvaluator(config=config)


# ---------------------------------------------------------------------------
# High quality response scoring
# ---------------------------------------------------------------------------


class TestHighQualityResponses:
    """Verify that genuinely good responses score well."""

    def test_good_code_response_scores_high(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a Python function to reverse a string"
        response = (
            "Here's a function to reverse a string:\n\n"
            "```python\n"
            "def reverse_string(text: str) -> str:\n"
            '    """Reverse the input string."""\n'
            "    return text[::-1]\n"
            "```\n\n"
            "This uses Python's slice notation with a step of -1 to reverse the string."
        )
        score = evaluator.evaluate(prompt, response)
        assert score.overall >= 0.7
        assert score.relevance >= 0.5
        assert score.completeness >= 0.7
        assert score.correctness >= 0.7

    def test_good_explanation_response(self, evaluator: QualityEvaluator) -> None:
        prompt = "Explain how Python generators work"
        response = (
            "Python generators are functions that use the `yield` keyword to produce "
            "a sequence of values lazily. Instead of computing all values at once "
            "and storing them in memory, a generator produces values one at a time "
            "and only when requested.\n\n"
            "Key benefits:\n"
            "- Memory efficient for large datasets\n"
            "- Can represent infinite sequences\n"
            "- Composable with other generators\n\n"
            "Example:\n"
            "```python\n"
            "def count_up(n: int) -> int:\n"
            "    i = 0\n"
            "    while i < n:\n"
            "        yield i\n"
            "        i += 1\n"
            "```"
        )
        score = evaluator.evaluate(prompt, response)
        assert score.overall >= 0.7
        assert score.coherence >= 0.7

    def test_factual_answer_scores_well(self, evaluator: QualityEvaluator) -> None:
        prompt = "What is the capital of France?"
        response = "The capital of France is Paris."
        score = evaluator.evaluate(prompt, response)
        assert score.overall >= 0.6
        assert score.relevance >= 0.4


# ---------------------------------------------------------------------------
# Low quality response detection
# ---------------------------------------------------------------------------


class TestLowQualityDetection:
    """Verify that poor responses are flagged appropriately."""

    def test_empty_response(self, evaluator: QualityEvaluator) -> None:
        score = evaluator.evaluate("Write something useful", "")
        assert score.overall == 0.0
        assert score.completeness == 0.0
        assert len(score.issues) > 0
        assert any(i.severity == IssueSeverity.CRITICAL for i in score.issues)

    def test_whitespace_only_response(self, evaluator: QualityEvaluator) -> None:
        score = evaluator.evaluate("Explain recursion", "   \n\n   ")
        assert score.overall == 0.0

    def test_very_short_response_to_complex_prompt(
        self, evaluator: QualityEvaluator,
    ) -> None:
        prompt = (
            "Design a microservice architecture for a real-time chat application "
            "with support for WebSocket connections, message persistence, "
            "user authentication, and horizontal scaling."
        )
        response = "Use WebSockets."
        score = evaluator.evaluate(prompt, response)
        assert score.conciseness < 0.5
        assert any(
            i.dimension == QualityDimension.CONCISENESS for i in score.issues
        )

    def test_truncated_response_detected(self, evaluator: QualityEvaluator) -> None:
        prompt = "Explain how databases work"
        response = (
            "Databases store data in structured tables. Each table has "
            "columns that define the schema and rows that contain the "
            "actual data records. The data is"
        )
        score = evaluator.evaluate(prompt, response)
        assert score.coherence < 1.0
        assert any(
            "truncated" in i.description.lower() for i in score.issues
        )


# ---------------------------------------------------------------------------
# Code quality assessment
# ---------------------------------------------------------------------------


class TestCodeQualityAssessment:
    """Verify code-specific quality checks."""

    def test_python_syntax_error_detected(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a Python function"
        response = (
            "```python\n"
            "def broken_function(\n"
            "    return 42\n"
            "```"
        )
        score = evaluator.evaluate(prompt, response)
        assert score.correctness < 0.8
        assert any(
            "syntax error" in i.description.lower()
            for i in score.issues
        )

    def test_todo_markers_detected(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a sort function"
        response = (
            "```python\n"
            "def sort_items(items: list) -> list:\n"
            "    # TODO: implement actual sorting\n"
            "    # FIXME: handle edge cases\n"
            "    return items\n"
            "```"
        )
        score = evaluator.evaluate(prompt, response)
        assert any(
            "TODO" in i.description or "FIXME" in i.description
            for i in score.issues
        )

    def test_empty_code_block_penalised(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a function"
        response = "Here's the function:\n\n```python\n\n```"
        score = evaluator.evaluate(prompt, response)
        assert score.correctness < 0.7

    def test_placeholder_code_penalised(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a function"
        response = "```python\npass\n```"
        score = evaluator.evaluate(prompt, response)
        assert score.correctness < 0.7

    def test_valid_python_code_scores_well(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a function to add two numbers"
        response = (
            "```python\n"
            "def add(a: int, b: int) -> int:\n"
            '    """Add two integers."""\n'
            "    return a + b\n"
            "```"
        )
        score = evaluator.evaluate(prompt, response)
        assert score.correctness >= 0.7

    def test_missing_import_detected(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a function to list files"
        response = (
            "```python\n"
            "def list_files(directory: str) -> list:\n"
            "    return os.listdir(directory)\n"
            "```"
        )
        score = evaluator.evaluate(prompt, response)
        assert any(
            "missing import" in i.description.lower()
            for i in score.issues
        )


# ---------------------------------------------------------------------------
# Relevance scoring
# ---------------------------------------------------------------------------


class TestRelevanceScoring:
    """Verify prompt-response relevance assessment."""

    def test_irrelevant_response_low_score(self, evaluator: QualityEvaluator) -> None:
        prompt = "How do I configure nginx for load balancing"
        response = "The weather today is sunny with temperatures around 75F."
        score = evaluator.evaluate(prompt, response)
        assert score.relevance < 0.5

    def test_relevant_response_high_score(self, evaluator: QualityEvaluator) -> None:
        prompt = "How do I configure nginx for load balancing"
        response = (
            "To configure nginx for load balancing, you need to define an "
            "upstream block in your nginx configuration file. The upstream "
            "block lists the backend servers that nginx will distribute "
            "traffic to."
        )
        score = evaluator.evaluate(prompt, response)
        assert score.relevance >= 0.5

    def test_empty_prompt_neutral_relevance(self, evaluator: QualityEvaluator) -> None:
        score = evaluator.evaluate("", "Here is some text.")
        # Empty prompt — cannot assess
        assert score.relevance >= 0.7


# ---------------------------------------------------------------------------
# Length analysis
# ---------------------------------------------------------------------------


class TestLengthAnalysis:
    """Verify response length scoring."""

    def test_short_response_penalised(self, evaluator: QualityEvaluator) -> None:
        prompt = "Explain the differences between TCP and UDP protocols in detail"
        response = "TCP is reliable."
        score = evaluator.evaluate(prompt, response)
        # Short response to a detailed question should have low completeness
        assert score.completeness < 0.8

    def test_verbose_response_penalised(self, evaluator: QualityEvaluator) -> None:
        prompt = "What is 2+2?"
        response = "Let me think about this. " * 200
        score = evaluator.evaluate(prompt, response)
        assert score.conciseness < 0.8

    def test_appropriate_length_scores_well(self, evaluator: QualityEvaluator) -> None:
        prompt = "What is the capital of France?"
        response = "The capital of France is Paris, a city located in northern France."
        score = evaluator.evaluate(prompt, response)
        assert score.conciseness >= 0.8


# ---------------------------------------------------------------------------
# Format compliance
# ---------------------------------------------------------------------------


class TestFormatCompliance:
    """Verify format compliance checking."""

    def test_valid_json_format(self, evaluator: QualityEvaluator) -> None:
        prompt = "Return the data as JSON"
        response = '{"name": "Alice", "age": 30}'
        score = evaluator.evaluate(prompt, response, expected_format="json")
        assert score.correctness >= 0.85

    def test_invalid_json_format(self, evaluator: QualityEvaluator) -> None:
        prompt = "Return the data as JSON"
        response = "Here is the data: name=Alice, age=30"
        score = evaluator.evaluate(prompt, response, expected_format="json")
        assert score.correctness < 0.5
        assert any(
            "JSON" in i.description for i in score.issues
        )

    def test_json_in_code_block(self, evaluator: QualityEvaluator) -> None:
        prompt = "Return JSON"
        response = '```json\n{"key": "value"}\n```'
        score = evaluator.evaluate(prompt, response, expected_format="json")
        assert score.correctness >= 0.7

    def test_code_format_with_fenced_block(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write code"
        response = "```python\nprint('hello')\n```"
        score = evaluator.evaluate(prompt, response, expected_format="code")
        assert score.correctness >= 0.8

    def test_code_format_without_fencing(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write code"
        response = "Here is some text without any code at all."
        score = evaluator.evaluate(prompt, response, expected_format="code")
        assert score.correctness < 0.5

    def test_markdown_format_compliance(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a markdown document"
        response = "# Title\n\nSome **bold** text and a [link](http://example.com)."
        score = evaluator.evaluate(prompt, response, expected_format="markdown")
        assert score.correctness >= 0.8

    def test_list_format_compliance(self, evaluator: QualityEvaluator) -> None:
        prompt = "List the items"
        response = "1. First item\n2. Second item\n3. Third item"
        score = evaluator.evaluate(prompt, response, expected_format="list")
        assert score.correctness >= 0.8

    def test_list_format_missing(self, evaluator: QualityEvaluator) -> None:
        prompt = "List the items"
        response = "The items are first, second, and third."
        score = evaluator.evaluate(prompt, response, expected_format="list")
        assert score.correctness < 0.5


# ---------------------------------------------------------------------------
# Comparative scoring
# ---------------------------------------------------------------------------


class TestComparativeScoring:
    """Verify comparison of two responses."""

    def test_better_response_wins(self, evaluator: QualityEvaluator) -> None:
        prompt = "Write a Python function to sort a list"
        good = (
            "```python\n"
            "def sort_list(items: list[int]) -> list[int]:\n"
            '    """Sort a list of integers."""\n'
            "    return sorted(items)\n"
            "```\n\n"
            "This uses Python's built-in `sorted()` function."
        )
        bad = "Just use sort."
        comparison = evaluator.compare(prompt, good, bad)
        assert comparison.winner == "a"
        assert comparison.margin > 0.0
        assert isinstance(comparison.score_a, QualityScore)
        assert isinstance(comparison.score_b, QualityScore)

    def test_similar_responses_tie(self, evaluator: QualityEvaluator) -> None:
        prompt = "What is 2+2?"
        response_a = "The answer is 4."
        response_b = "2 plus 2 equals 4."
        comparison = evaluator.compare(prompt, response_a, response_b)
        assert comparison.winner == "tie" or comparison.margin < 0.1

    def test_comparison_has_dimension_winners(
        self, evaluator: QualityEvaluator,
    ) -> None:
        prompt = "Write code"
        response_a = "```python\nprint('hello')\n```"
        response_b = "Hello is a common greeting."
        comparison = evaluator.compare(prompt, response_a, response_b)
        assert isinstance(comparison.dimension_winners, dict)
        assert "relevance" in comparison.dimension_winners
        assert "completeness" in comparison.dimension_winners

    def test_comparison_with_expected_format(
        self, evaluator: QualityEvaluator,
    ) -> None:
        prompt = "Return data as JSON"
        response_a = '{"data": [1, 2, 3]}'
        response_b = "data = [1, 2, 3]"
        comparison = evaluator.compare(
            prompt, response_a, response_b, expected_format="json",
        )
        # Response A should score at least as well as B (JSON format matches)
        assert comparison.winner in ("a", "tie")


# ---------------------------------------------------------------------------
# Hallucination indicators
# ---------------------------------------------------------------------------


class TestHallucinationIndicators:
    """Verify detection of hallucination signals."""

    def test_overconfidence_detected(self, evaluator: QualityEvaluator) -> None:
        prompt = "Is this statement true?"
        response = "I am 100% certain that this is correct. I guarantee this is true."
        score = evaluator.evaluate(prompt, response)
        assert any(
            "overconfidence" in i.description.lower() or "confidence" in i.description.lower()
            for i in score.issues
        )

    def test_contradiction_detected(self, evaluator: QualityEvaluator) -> None:
        prompt = "Should I use X?"
        response = (
            "You should always use X for best results. "
            "However, you should not use X in production environments."
        )
        score = evaluator.evaluate(prompt, response)
        assert any(
            "contradiction" in i.description.lower()
            for i in score.issues
        )

    def test_clean_response_no_hallucination_flags(
        self, evaluator: QualityEvaluator,
    ) -> None:
        prompt = "What is Python?"
        response = (
            "Python is a high-level, interpreted programming language "
            "known for its clean syntax and readability."
        )
        score = evaluator.evaluate(prompt, response)
        hallucination_issues = [
            i for i in score.issues
            if "overconfidence" in i.description.lower()
            or "contradiction" in i.description.lower()
        ]
        assert len(hallucination_issues) == 0


# ---------------------------------------------------------------------------
# Per-model history tracking
# ---------------------------------------------------------------------------


class TestModelHistoryTracking:
    """Verify per-model quality history management."""

    def test_record_and_retrieve_history(self, evaluator: QualityEvaluator) -> None:
        score = evaluator.evaluate("Say hello", "Hello! How are you?")
        evaluator.record_quality("gpt-4o", score)
        history = evaluator.get_model_history("gpt-4o")
        assert history is not None
        assert history.model == "gpt-4o"
        assert history.sample_count == 1
        assert history.avg_score > 0.0

    def test_multiple_recordings_update_average(
        self, evaluator: QualityEvaluator,
    ) -> None:
        for i in range(5):
            text = f"Response number {i}. " * 10
            score = evaluator.evaluate("Tell me something", text)
            evaluator.record_quality("claude-3", score)

        history = evaluator.get_model_history("claude-3")
        assert history is not None
        assert history.sample_count == 5
        assert len(history.recent_scores) == 5

    def test_unknown_model_returns_none(self, evaluator: QualityEvaluator) -> None:
        assert evaluator.get_model_history("nonexistent-model") is None

    def test_trend_detection_improving(self, evaluator: QualityEvaluator) -> None:
        # Simulate improving quality
        config = QualityConfig(trend_min_samples=3)
        ev = QualityEvaluator(config=config)

        # Record low scores first
        for _ in range(3):
            low_score = QualityScore(
                relevance=0.3, completeness=0.3, coherence=0.3,
                conciseness=0.3, correctness=0.3, overall=0.3,
            )
            ev.record_quality("test-model", low_score)

        # Then high scores
        for _ in range(3):
            high_score = QualityScore(
                relevance=0.9, completeness=0.9, coherence=0.9,
                conciseness=0.9, correctness=0.9, overall=0.9,
            )
            ev.record_quality("test-model", high_score)

        history = ev.get_model_history("test-model")
        assert history is not None
        assert history.trend == "improving"

    def test_trend_detection_declining(self, evaluator: QualityEvaluator) -> None:
        config = QualityConfig(trend_min_samples=3)
        ev = QualityEvaluator(config=config)

        # Record high scores first
        for _ in range(3):
            high_score = QualityScore(
                relevance=0.9, completeness=0.9, coherence=0.9,
                conciseness=0.9, correctness=0.9, overall=0.9,
            )
            ev.record_quality("test-model", high_score)

        # Then low scores
        for _ in range(3):
            low_score = QualityScore(
                relevance=0.3, completeness=0.3, coherence=0.3,
                conciseness=0.3, correctness=0.3, overall=0.3,
            )
            ev.record_quality("test-model", low_score)

        history = ev.get_model_history("test-model")
        assert history is not None
        assert history.trend == "declining"

    def test_get_all_model_histories(self, evaluator: QualityEvaluator) -> None:
        score = evaluator.evaluate("Hello", "World.")
        evaluator.record_quality("model-a", score)
        evaluator.record_quality("model-b", score)
        histories = evaluator.get_all_model_histories()
        assert "model-a" in histories
        assert "model-b" in histories

    def test_reward_signal_default(self, evaluator: QualityEvaluator) -> None:
        # No data recorded
        assert evaluator.get_reward_signal("unknown") == 0.5

    def test_reward_signal_after_recording(self, evaluator: QualityEvaluator) -> None:
        score = evaluator.evaluate("Hello", "Hello there, how may I help you?")
        evaluator.record_quality("gpt-4o", score)
        reward = evaluator.get_reward_signal("gpt-4o")
        assert 0.0 <= reward <= 1.0
        assert reward != 0.5  # Should reflect actual score

    def test_history_window_size_respected(self) -> None:
        config = QualityConfig(history_window_size=3)
        ev = QualityEvaluator(config=config)
        for _ in range(10):
            score = QualityScore(
                relevance=0.8, completeness=0.8, coherence=0.8,
                conciseness=0.8, correctness=0.8, overall=0.8,
            )
            ev.record_quality("model-x", score)

        history = ev.get_model_history("model-x")
        assert history is not None
        assert len(history.recent_scores) == 3
        assert history.sample_count == 10


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Verify correct handling of edge cases."""

    def test_response_with_only_code_no_explanation(
        self, evaluator: QualityEvaluator,
    ) -> None:
        prompt = "Write a hello world"
        response = "```python\nprint('Hello, world!')\n```"
        score = evaluator.evaluate(prompt, response)
        assert score.overall > 0.0
        assert score.correctness >= 0.7

    def test_very_long_response(self, evaluator: QualityEvaluator) -> None:
        prompt = "Summarise this."
        response = "This is a sentence. " * 500
        score = evaluator.evaluate(prompt, response)
        assert 0.0 <= score.overall <= 1.0
        assert 0.0 <= score.conciseness <= 1.0

    def test_unicode_response(self, evaluator: QualityEvaluator) -> None:
        prompt = "Translate to Japanese"
        response = "This translates to Japanese."
        score = evaluator.evaluate(prompt, response)
        assert 0.0 <= score.overall <= 1.0

    def test_response_with_special_characters(
        self, evaluator: QualityEvaluator,
    ) -> None:
        prompt = "Show regex example"
        response = r"The regex `\d+\.?\d*` matches numbers like 3.14 or 42."
        score = evaluator.evaluate(prompt, response)
        assert score.overall > 0.0

    def test_all_scores_bounded(self, evaluator: QualityEvaluator) -> None:
        prompt = "Test prompt"
        response = "Test response with some content for evaluation."
        score = evaluator.evaluate(prompt, response)
        for dim in ("relevance", "completeness", "coherence", "conciseness",
                     "correctness", "overall", "reward_signal"):
            value = getattr(score, dim)
            assert 0.0 <= value <= 1.0, f"{dim} = {value} is out of bounds"


# ---------------------------------------------------------------------------
# Configuration customisation
# ---------------------------------------------------------------------------


class TestConfigurationCustomisation:
    """Verify that configuration changes affect scoring."""

    def test_custom_weights_affect_overall(self) -> None:
        config = QualityConfig(
            weight_relevance=0.50,
            weight_completeness=0.20,
            weight_coherence=0.10,
            weight_conciseness=0.10,
            weight_correctness=0.10,
        )
        ev = QualityEvaluator(config=config)
        score = ev.evaluate("How do I sort?", "Use the sort function in Python.")
        assert score.overall > 0.0

    def test_invalid_weights_raise_error(self) -> None:
        config = QualityConfig(
            weight_relevance=0.5,
            weight_completeness=0.5,
            weight_coherence=0.5,
            weight_conciseness=0.5,
            weight_correctness=0.5,
        )
        with pytest.raises(ValueError, match="weights must sum"):
            QualityEvaluator(config=config)

    def test_negative_weight_raises_error(self) -> None:
        config = QualityConfig(weight_relevance=-0.1)
        with pytest.raises(ValueError, match="weights must sum"):
            QualityEvaluator(config=config)

    def test_config_weights_property(self) -> None:
        config = QualityConfig()
        weights = config.weights
        assert "relevance" in weights
        assert "completeness" in weights
        total = sum(weights.values())
        assert 0.99 <= total <= 1.01


# ---------------------------------------------------------------------------
# TF-IDF helpers
# ---------------------------------------------------------------------------


class TestTFIDFHelpers:
    """Verify the internal TF-IDF utility functions."""

    def test_tokenize_basic(self) -> None:
        tokens = _tokenize("Hello, world! This is a test.")
        assert "hello" in tokens
        assert "world" in tokens
        assert "test" in tokens

    def test_tokenize_empty(self) -> None:
        assert _tokenize("") == []

    def test_tfidf_similarity_identical(self) -> None:
        text = "The quick brown fox jumps over the lazy dog"
        sim = _tfidf_similarity(text, text)
        assert sim > 0.9

    def test_tfidf_similarity_unrelated(self) -> None:
        text_a = "Python programming language syntax"
        text_b = "Cooking pasta with tomato sauce recipe"
        sim = _tfidf_similarity(text_a, text_b)
        assert sim < 0.3

    def test_tfidf_similarity_empty(self) -> None:
        assert _tfidf_similarity("", "some text") == 0.0
        assert _tfidf_similarity("some text", "") == 0.0


# ---------------------------------------------------------------------------
# Dataclass integrity
# ---------------------------------------------------------------------------


class TestDataclassIntegrity:
    """Verify dataclass construction and properties."""

    def test_quality_score_is_frozen(self) -> None:
        score = QualityScore(
            relevance=0.8, completeness=0.9, coherence=0.7,
            conciseness=0.85, correctness=0.95, overall=0.86,
        )
        with pytest.raises(AttributeError):
            score.overall = 0.5  # type: ignore[misc]

    def test_quality_issue_is_frozen(self) -> None:
        issue = QualityIssue(
            severity=IssueSeverity.WARNING,
            dimension=QualityDimension.RELEVANCE,
            description="Test issue",
        )
        with pytest.raises(AttributeError):
            issue.description = "changed"  # type: ignore[misc]

    def test_quality_comparison_fields(self) -> None:
        score = QualityScore(
            relevance=0.8, completeness=0.9, coherence=0.7,
            conciseness=0.85, correctness=0.95, overall=0.86,
        )
        comparison = QualityComparison(
            winner="a", margin=0.1, score_a=score, score_b=score,
            dimension_winners={"relevance": "tie"},
        )
        assert comparison.winner == "a"
        assert comparison.margin == 0.1

    def test_model_quality_history_defaults(self) -> None:
        history = ModelQualityHistory(model="test")
        assert history.avg_score == 0.0
        assert history.trend == "stable"
        assert history.sample_count == 0
        assert history.recent_scores == []

    def test_quality_config_defaults(self) -> None:
        config = QualityConfig()
        assert config.weight_relevance == 0.25
        assert config.history_window_size == 50
        assert config.trend_min_samples == 5
