"""Tests for circuit breaker, smart retry, and retry orchestrator — fully offline.

At least 35 tests covering all three classes, state transitions, error
classification, retry logic, decorrelated jitter, and the orchestrator's
fallback behavior.
"""

from __future__ import annotations

import asyncio
import time

import pytest

from prism.exceptions import (
    AllProvidersFailedError,
    ProviderAuthError,
    ProviderQuotaError,
    ProviderRateLimitError,
    ProviderUnavailableError,
)
from prism.llm.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitState,
    ErrorType,
    RetryOrchestrator,
    SmartRetryConfig,
    SmartRetryStrategy,
    classify_error,
)

# ======================================================================
# Error classification
# ======================================================================


class TestClassifyError:
    """Tests for the classify_error helper."""

    def test_classify_rate_limit_error(self) -> None:
        err = ProviderRateLimitError("openai", retry_after=5.0)
        assert classify_error(err) == ErrorType.RATE_LIMIT

    def test_classify_auth_error(self) -> None:
        err = ProviderAuthError("openai")
        assert classify_error(err) == ErrorType.AUTH_ERROR

    def test_classify_quota_error(self) -> None:
        err = ProviderQuotaError("openai")
        assert classify_error(err) == ErrorType.QUOTA_EXHAUSTED

    def test_classify_unavailable_error(self) -> None:
        err = ProviderUnavailableError("openai", "down")
        assert classify_error(err) == ErrorType.SERVER_ERROR

    def test_classify_timeout_error(self) -> None:
        err = TimeoutError("timed out")
        assert classify_error(err) == ErrorType.TIMEOUT

    def test_classify_asyncio_timeout(self) -> None:
        err = TimeoutError()
        assert classify_error(err) == ErrorType.TIMEOUT

    def test_classify_connection_error(self) -> None:
        err = ConnectionError("refused")
        assert classify_error(err) == ErrorType.CONNECTION_ERROR

    def test_classify_os_error(self) -> None:
        err = OSError("network unreachable")
        assert classify_error(err) == ErrorType.CONNECTION_ERROR

    def test_classify_by_status_429(self) -> None:
        err = RuntimeError("something")
        assert classify_error(err, response_status=429) == ErrorType.RATE_LIMIT

    def test_classify_by_status_401(self) -> None:
        err = RuntimeError("something")
        assert classify_error(err, response_status=401) == ErrorType.AUTH_ERROR

    def test_classify_by_status_403(self) -> None:
        err = RuntimeError("something")
        assert classify_error(err, response_status=403) == ErrorType.AUTH_ERROR

    def test_classify_by_status_500(self) -> None:
        err = RuntimeError("something")
        assert classify_error(err, response_status=500) == ErrorType.SERVER_ERROR

    def test_classify_by_status_503(self) -> None:
        err = RuntimeError("something")
        assert classify_error(err, response_status=503) == ErrorType.SERVER_ERROR

    def test_classify_unknown(self) -> None:
        err = ValueError("unexpected")
        assert classify_error(err) == ErrorType.UNKNOWN


# ======================================================================
# CircuitBreaker — state transitions
# ======================================================================


class TestCircuitBreakerClosed:
    """Tests for normal (CLOSED) state behavior."""

    async def test_initial_state_is_closed(self) -> None:
        cb = CircuitBreaker()
        state = await cb.get_state("openai")
        assert state == CircuitState.CLOSED

    async def test_can_execute_when_closed(self) -> None:
        cb = CircuitBreaker()
        assert await cb.can_execute("openai") is True

    async def test_success_keeps_closed(self) -> None:
        cb = CircuitBreaker()
        await cb.record_success("openai")
        assert await cb.get_state("openai") == CircuitState.CLOSED

    async def test_failures_below_threshold_stay_closed(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=5)
        cb = CircuitBreaker(config)
        for _ in range(4):
            await cb.record_failure("openai", RuntimeError("err"))
        assert await cb.get_state("openai") == CircuitState.CLOSED

    async def test_success_resets_consecutive_failures(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=3)
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("e1"))
        await cb.record_failure("openai", RuntimeError("e2"))
        await cb.record_success("openai")
        # After success, consecutive failures reset. Two more won't open.
        await cb.record_failure("openai", RuntimeError("e3"))
        await cb.record_failure("openai", RuntimeError("e4"))
        assert await cb.get_state("openai") == CircuitState.CLOSED


class TestCircuitBreakerOpen:
    """Tests for OPEN state transitions."""

    async def test_opens_after_threshold(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=3)
        cb = CircuitBreaker(config)
        for i in range(3):
            await cb.record_failure("openai", RuntimeError(f"err{i}"))
        assert await cb.get_state("openai") == CircuitState.OPEN

    async def test_cannot_execute_when_open(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=1)
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        assert await cb.can_execute("openai") is False

    async def test_stays_open_before_recovery_timeout(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=1, recovery_timeout_s=1000)
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        # Even after checking, should stay open.
        assert await cb.get_state("openai") == CircuitState.OPEN


class TestCircuitBreakerHalfOpen:
    """Tests for HALF_OPEN recovery behavior."""

    async def test_transitions_to_half_open_after_timeout(self) -> None:
        config = CircuitBreakerConfig(
            failure_threshold=1,
            recovery_timeout_s=0.01,
        )
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        assert await cb.get_state("openai") == CircuitState.OPEN
        await asyncio.sleep(0.02)
        assert await cb.get_state("openai") == CircuitState.HALF_OPEN

    async def test_can_execute_in_half_open(self) -> None:
        config = CircuitBreakerConfig(
            failure_threshold=1,
            recovery_timeout_s=0.01,
            half_open_max_calls=2,
        )
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        await asyncio.sleep(0.02)
        assert await cb.can_execute("openai") is True

    async def test_half_open_max_calls_enforced(self) -> None:
        config = CircuitBreakerConfig(
            failure_threshold=1,
            recovery_timeout_s=0.01,
            half_open_max_calls=1,
            success_threshold_to_close=2,
        )
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        await asyncio.sleep(0.02)
        # First call allowed in half-open.
        assert await cb.can_execute("openai") is True
        # Record success but not enough to close (need 2).
        await cb.record_success("openai")
        # Half open calls = 1 = max, so no more.
        # But the success should have transitioned back... let's check:
        # Actually with success_threshold=2 and only 1 success, still half-open.
        # And half_open_calls is now 1 = max.
        assert await cb.can_execute("openai") is False

    async def test_half_open_closes_on_enough_successes(self) -> None:
        config = CircuitBreakerConfig(
            failure_threshold=1,
            recovery_timeout_s=0.01,
            half_open_max_calls=5,
            success_threshold_to_close=2,
        )
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        await asyncio.sleep(0.02)
        await cb.record_success("openai")
        assert await cb.get_state("openai") == CircuitState.HALF_OPEN
        await cb.record_success("openai")
        assert await cb.get_state("openai") == CircuitState.CLOSED

    async def test_half_open_failure_trips_back_to_open(self) -> None:
        config = CircuitBreakerConfig(
            failure_threshold=1,
            recovery_timeout_s=0.01,
            half_open_max_calls=3,
        )
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        await asyncio.sleep(0.02)
        # Now HALF_OPEN.
        await cb.record_failure("openai", RuntimeError("fail again"))
        assert await cb.get_state("openai") == CircuitState.OPEN


class TestCircuitBreakerManualControls:
    """Tests for force_open, force_close, reset."""

    async def test_force_open(self) -> None:
        cb = CircuitBreaker()
        await cb.force_open("openai")
        assert await cb.get_state("openai") == CircuitState.OPEN

    async def test_force_close(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=1)
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("err"))
        assert await cb.get_state("openai") == CircuitState.OPEN
        await cb.force_close("openai")
        assert await cb.get_state("openai") == CircuitState.CLOSED
        assert await cb.can_execute("openai") is True

    async def test_reset(self) -> None:
        cb = CircuitBreaker()
        await cb.record_failure("openai", RuntimeError("err"))
        await cb.record_success("openai")
        await cb.reset("openai")
        stats = await cb.get_stats("openai")
        assert stats["failure_count"] == 0
        assert stats["success_count"] == 0
        assert stats["state"] == "closed"

    async def test_get_all_states(self) -> None:
        cb = CircuitBreaker(CircuitBreakerConfig(failure_threshold=1))
        await cb.record_success("openai")
        await cb.record_failure("anthropic", RuntimeError("e"))
        states = await cb.get_all_states()
        assert states["openai"] == CircuitState.CLOSED
        assert states["anthropic"] == CircuitState.OPEN


class TestCircuitBreakerStats:
    """Tests for get_stats."""

    async def test_stats_counts(self) -> None:
        cb = CircuitBreaker()
        await cb.record_success("openai")
        await cb.record_success("openai")
        await cb.record_failure("openai", RuntimeError("x"))
        stats = await cb.get_stats("openai")
        assert stats["success_count"] == 2
        assert stats["failure_count"] == 1
        assert stats["consecutive_failures"] == 1
        assert stats["last_failure_error"] == "x"

    async def test_stats_transition_history(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=1, recovery_timeout_s=0.01)
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("e"))
        await asyncio.sleep(0.02)
        _ = await cb.get_state("openai")  # Trigger HALF_OPEN transition.
        stats = await cb.get_stats("openai")
        history = stats["transition_history"]
        assert len(history) >= 1
        # First transition should be CLOSED -> OPEN.
        assert history[0]["from_state"] == "closed"
        assert history[0]["to_state"] == "open"


class TestCircuitBreakerIsolation:
    """Tests that providers are isolated from each other."""

    async def test_independent_providers(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=2)
        cb = CircuitBreaker(config)
        await cb.record_failure("openai", RuntimeError("e1"))
        await cb.record_failure("openai", RuntimeError("e2"))
        # openai is open, anthropic should still be closed.
        assert await cb.get_state("openai") == CircuitState.OPEN
        assert await cb.get_state("anthropic") == CircuitState.CLOSED
        assert await cb.can_execute("anthropic") is True


# ======================================================================
# SmartRetryStrategy
# ======================================================================


class TestSmartRetryDecisions:
    """Tests for should_retry logic."""

    def test_no_retry_on_auth_error(self) -> None:
        strategy = SmartRetryStrategy()
        should, delay = strategy.should_retry(
            attempt=0,
            error=ProviderAuthError("openai"),
        )
        assert should is False
        assert delay == 0.0

    def test_no_retry_on_quota_error(self) -> None:
        strategy = SmartRetryStrategy()
        should, _delay = strategy.should_retry(
            attempt=0,
            error=ProviderQuotaError("openai"),
        )
        assert should is False

    def test_retry_on_server_error(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3))
        should, delay = strategy.should_retry(
            attempt=0,
            error=ProviderUnavailableError("openai", "500"),
        )
        assert should is True
        assert delay > 0

    def test_retry_on_timeout(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3))
        should, delay = strategy.should_retry(
            attempt=0,
            error=TimeoutError("timed out"),
        )
        assert should is True
        assert delay > 0

    def test_retry_on_connection_error(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3))
        should, _delay = strategy.should_retry(
            attempt=0,
            error=ConnectionError("refused"),
        )
        assert should is True

    def test_no_retry_after_max_attempts(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=2))
        should, _ = strategy.should_retry(
            attempt=2,
            error=ProviderUnavailableError("openai", "500"),
        )
        assert should is False

    def test_respects_retry_after_header(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3, base_delay=0.5))
        should, delay = strategy.should_retry(
            attempt=0,
            error=ProviderRateLimitError("openai"),
            retry_after=10.0,
        )
        assert should is True
        assert delay >= 10.0

    def test_respects_rate_limit_error_retry_after(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3, base_delay=0.5))
        err = ProviderRateLimitError("openai", retry_after=8.0)
        should, delay = strategy.should_retry(attempt=0, error=err)
        assert should is True
        assert delay >= 8.0

    def test_delay_capped_at_max(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3, max_delay=5.0))
        should, delay = strategy.should_retry(
            attempt=0,
            error=ProviderRateLimitError("openai", retry_after=100.0),
        )
        assert should is True
        assert delay <= 5.0

    def test_retry_on_status_429(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3))
        should, _delay = strategy.should_retry(
            attempt=0,
            error=RuntimeError("rate limited"),
            response_status=429,
        )
        assert should is True

    def test_no_retry_on_status_401(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(max_retries=3))
        should, _ = strategy.should_retry(
            attempt=0,
            error=RuntimeError("unauthorized"),
            response_status=401,
        )
        assert should is False


class TestSmartRetryDelay:
    """Tests for the decorrelated jitter delay calculation."""

    def test_delay_is_positive(self) -> None:
        strategy = SmartRetryStrategy(SmartRetryConfig(base_delay=1.0))
        delay = strategy.get_retry_delay(0, ErrorType.SERVER_ERROR)
        assert delay > 0

    def test_delay_never_exceeds_max(self) -> None:
        strategy = SmartRetryStrategy(
            SmartRetryConfig(base_delay=1.0, max_delay=3.0),
        )
        for attempt in range(10):
            delay = strategy.get_retry_delay(attempt, ErrorType.SERVER_ERROR)
            assert delay <= 3.0

    def test_jitter_produces_varied_delays(self) -> None:
        strategy = SmartRetryStrategy(
            SmartRetryConfig(base_delay=1.0, max_delay=100.0),
        )
        delays = [
            strategy.get_retry_delay(1, ErrorType.SERVER_ERROR, provider=f"p{i}")
            for i in range(50)
        ]
        unique = set(delays)
        assert len(unique) > 1

    def test_rate_limit_has_higher_base_delay(self) -> None:
        strategy = SmartRetryStrategy(
            SmartRetryConfig(base_delay=0.5, max_delay=100.0),
        )
        # Sample enough to confirm the average is higher for rate limit.
        rl_delays = [
            strategy.get_retry_delay(0, ErrorType.RATE_LIMIT, provider=f"rl{i}")
            for i in range(100)
        ]
        se_delays = [
            strategy.get_retry_delay(0, ErrorType.SERVER_ERROR, provider=f"se{i}")
            for i in range(100)
        ]
        avg_rl = sum(rl_delays) / len(rl_delays)
        avg_se = sum(se_delays) / len(se_delays)
        # RATE_LIMIT base is 2.0, SERVER_ERROR base is 1.0.
        assert avg_rl > avg_se

    def test_reset_clears_state(self) -> None:
        strategy = SmartRetryStrategy()
        strategy.get_retry_delay(0, ErrorType.SERVER_ERROR, provider="openai")
        strategy.reset("openai")
        assert "openai" not in strategy._last_delay

    def test_reset_all(self) -> None:
        strategy = SmartRetryStrategy()
        strategy.get_retry_delay(0, ErrorType.SERVER_ERROR, provider="a")
        strategy.get_retry_delay(0, ErrorType.SERVER_ERROR, provider="b")
        strategy.reset()
        assert len(strategy._last_delay) == 0


# ======================================================================
# RetryOrchestrator — integration of breaker + retry + fallback
# ======================================================================


class TestRetryOrchestratorSuccess:
    """Happy paths for the orchestrator."""

    async def test_first_provider_succeeds(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=2))
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            return f"result-{provider}"

        result = await orch.execute_with_retry(["openai", "anthropic"], fn)
        assert result == "result-openai"

    async def test_returns_none_if_fn_returns_none(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=0))
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> None:
            return None

        result = await orch.execute_with_retry(["openai"], fn)
        assert result is None


class TestRetryOrchestratorFallback:
    """Tests for fallback to next provider."""

    async def test_falls_back_on_auth_error(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=1, base_delay=0.001))
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            if provider == "openai":
                raise ProviderAuthError("openai")
            return f"result-{provider}"

        result = await orch.execute_with_retry(
            ["openai", "anthropic"], fn,
        )
        assert result == "result-anthropic"

    async def test_falls_back_after_retries_exhausted(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=1, base_delay=0.001))
        orch = RetryOrchestrator(breaker, retry)
        call_counts: dict[str, int] = {}

        async def fn(provider: str) -> str:
            call_counts[provider] = call_counts.get(provider, 0) + 1
            if provider == "openai":
                raise ProviderUnavailableError("openai", "down")
            return f"result-{provider}"

        result = await orch.execute_with_retry(
            ["openai", "anthropic"], fn,
        )
        assert result == "result-anthropic"
        # openai should have been tried 2 times (1 initial + 1 retry).
        assert call_counts["openai"] == 2
        assert call_counts["anthropic"] == 1

    async def test_skips_provider_with_open_circuit(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=1)
        breaker = CircuitBreaker(config)
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=0))
        orch = RetryOrchestrator(breaker, retry)

        # Trip openai circuit.
        await breaker.record_failure("openai", RuntimeError("err"))

        called_providers: list[str] = []

        async def fn(provider: str) -> str:
            called_providers.append(provider)
            return f"result-{provider}"

        result = await orch.execute_with_retry(
            ["openai", "anthropic"], fn,
        )
        assert result == "result-anthropic"
        assert "openai" not in called_providers

    async def test_all_providers_fail_raises(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=0))
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            raise ProviderUnavailableError(provider, "down")

        with pytest.raises(AllProvidersFailedError):
            await orch.execute_with_retry(["openai", "anthropic"], fn)

    async def test_empty_providers_raises(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy()
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            return "ok"

        with pytest.raises(AllProvidersFailedError, match="No providers"):
            await orch.execute_with_retry([], fn)

    async def test_all_circuits_open_raises(self) -> None:
        config = CircuitBreakerConfig(failure_threshold=1)
        breaker = CircuitBreaker(config)
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=0))
        orch = RetryOrchestrator(breaker, retry)

        await breaker.record_failure("openai", RuntimeError("e"))
        await breaker.record_failure("anthropic", RuntimeError("e"))

        async def fn(provider: str) -> str:
            return "ok"

        with pytest.raises(AllProvidersFailedError):
            await orch.execute_with_retry(["openai", "anthropic"], fn)


class TestRetryOrchestratorCircuitInteraction:
    """Tests for orchestrator interaction with circuit breaker state."""

    async def test_successful_call_records_success(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy()
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            return "ok"

        await orch.execute_with_retry(["openai"], fn)
        stats = await breaker.get_stats("openai")
        assert stats["success_count"] == 1

    async def test_failed_call_records_failure(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=0))
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            raise ProviderUnavailableError(provider, "down")

        with pytest.raises(AllProvidersFailedError):
            await orch.execute_with_retry(["openai"], fn)

        stats = await breaker.get_stats("openai")
        assert stats["failure_count"] == 1

    async def test_circuit_opens_during_retry_stops_retrying(self) -> None:
        """If the circuit trips open during retries, we stop and fall back."""
        config = CircuitBreakerConfig(failure_threshold=1)
        breaker = CircuitBreaker(config)
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=5, base_delay=0.001))
        orch = RetryOrchestrator(breaker, retry)

        call_count = 0

        async def fn(provider: str) -> str:
            nonlocal call_count
            call_count += 1
            if provider == "openai":
                raise ProviderUnavailableError("openai", "down")
            return "ok-anthropic"

        result = await orch.execute_with_retry(
            ["openai", "anthropic"], fn,
        )
        assert result == "ok-anthropic"
        # openai circuit opens after 1 failure, so only 1 call.
        assert call_count == 2  # 1 openai + 1 anthropic

    async def test_retry_with_rate_limit_respects_retry_after(self) -> None:
        """Rate limit errors respect retry_after timing."""
        breaker = CircuitBreaker(CircuitBreakerConfig(failure_threshold=10))
        retry = SmartRetryStrategy(
            SmartRetryConfig(max_retries=1, base_delay=0.001, max_delay=0.05),
        )
        orch = RetryOrchestrator(breaker, retry)
        call_count = 0

        async def fn(provider: str) -> str:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ProviderRateLimitError("openai", retry_after=0.01)
            return "ok"

        start = time.monotonic()
        result = await orch.execute_with_retry(["openai"], fn)
        elapsed = time.monotonic() - start
        assert result == "ok"
        assert call_count == 2
        # Should have waited at least 0.01s (the retry_after).
        assert elapsed >= 0.008  # Slight tolerance for timing.


class TestRetryOrchestratorMultiProvider:
    """Tests exercising the full fallback chain with multiple providers."""

    async def test_three_provider_fallback(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=0))
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            if provider in {"openai", "anthropic"}:
                raise ProviderUnavailableError(provider, "down")
            return f"result-{provider}"

        result = await orch.execute_with_retry(
            ["openai", "anthropic", "google"], fn,
        )
        assert result == "result-google"

    async def test_records_failures_for_all_tried_providers(self) -> None:
        breaker = CircuitBreaker()
        retry = SmartRetryStrategy(SmartRetryConfig(max_retries=0))
        orch = RetryOrchestrator(breaker, retry)

        async def fn(provider: str) -> str:
            raise ProviderUnavailableError(provider, "down")

        with pytest.raises(AllProvidersFailedError):
            await orch.execute_with_retry(
                ["openai", "anthropic", "google"], fn,
            )

        for p in ["openai", "anthropic", "google"]:
            stats = await breaker.get_stats(p)
            assert stats["failure_count"] == 1
