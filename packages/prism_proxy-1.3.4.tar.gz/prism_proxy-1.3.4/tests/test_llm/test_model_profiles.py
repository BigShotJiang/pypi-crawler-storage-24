"""Tests for the model performance profiling engine."""

from __future__ import annotations

import pytest

from prism.llm.model_profiles import (
    LatencyProfile,
    ModelProfile,
    ModelProfiler,
    ModelRanking,
    PerformanceRecord,
    QualityProfile,
    TaskAffinity,
)


@pytest.fixture()
def profiler() -> ModelProfiler:
    return ModelProfiler()


@pytest.fixture()
def populated_profiler() -> ModelProfiler:
    """Profiler with diverse performance data."""
    p = ModelProfiler()

    # GPT-4o — high quality, moderate latency, expensive
    for i in range(50):
        p.record(
            model="gpt-4o",
            latency_ms=400 + (i % 10) * 20,
            quality_score=0.85 + (i % 5) * 0.02,
            tokens_in=500,
            tokens_out=200,
            cost_usd=0.005,
            task_type="code" if i % 3 == 0 else "chat",
        )

    # Claude Haiku — decent quality, fast, cheap
    for i in range(40):
        p.record(
            model="claude-haiku",
            latency_ms=150 + (i % 8) * 10,
            quality_score=0.72 + (i % 5) * 0.02,
            tokens_in=500,
            tokens_out=200,
            cost_usd=0.001,
            task_type="chat" if i % 2 == 0 else "analysis",
        )

    # DeepSeek — good quality, variable latency, very cheap
    for i in range(30):
        p.record(
            model="deepseek-v3",
            latency_ms=300 + (i % 15) * 30,
            quality_score=0.78 + (i % 4) * 0.03,
            tokens_in=500,
            tokens_out=200,
            cost_usd=0.0005,
            task_type="code",
        )

    # Add some errors for GPT-4o
    for _ in range(3):
        p.record(model="gpt-4o", error=True, error_type="rate_limit")

    return p


# ---------------------------------------------------------------------------
# Recording tests
# ---------------------------------------------------------------------------


class TestRecording:
    """Tests for performance recording."""

    def test_record_creates_entry(self, profiler: ModelProfiler) -> None:
        rec = profiler.record("gpt-4o", latency_ms=450, quality_score=0.85)
        assert isinstance(rec, PerformanceRecord)
        assert rec.model == "gpt-4o"

    def test_records_accumulate(self, profiler: ModelProfiler) -> None:
        for i in range(10):
            profiler.record("gpt-4o", latency_ms=float(i * 100))
        assert profiler.get_record_count("gpt-4o") == 10

    def test_fifo_eviction(self) -> None:
        p = ModelProfiler(max_records_per_model=5)
        for i in range(10):
            p.record("test", latency_ms=float(i))
        assert p.get_record_count("test") == 5

    def test_multiple_models(self, profiler: ModelProfiler) -> None:
        profiler.record("model_a", latency_ms=100)
        profiler.record("model_b", latency_ms=200)
        assert profiler.get_record_count("model_a") == 1
        assert profiler.get_record_count("model_b") == 1

    def test_get_all_models(self, populated_profiler: ModelProfiler) -> None:
        models = populated_profiler.get_all_models()
        assert "gpt-4o" in models
        assert "claude-haiku" in models
        assert "deepseek-v3" in models


# ---------------------------------------------------------------------------
# Profile tests
# ---------------------------------------------------------------------------


class TestProfile:
    """Tests for model profile generation."""

    def test_profile_nonexistent(self, profiler: ModelProfiler) -> None:
        assert profiler.get_profile("nonexistent") is None

    def test_profile_structure(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        assert isinstance(profile, ModelProfile)
        assert profile.model == "gpt-4o"
        assert profile.total_requests > 0

    def test_latency_profile(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        lat = profile.latency
        assert isinstance(lat, LatencyProfile)
        assert lat.p50 > 0
        assert lat.p50 <= lat.p75 <= lat.p90 <= lat.p95 <= lat.p99
        assert lat.min_ms <= lat.p50
        assert lat.max_ms >= lat.p99
        assert lat.sample_count > 0

    def test_quality_profile(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        q = profile.quality
        assert isinstance(q, QualityProfile)
        assert 0 <= q.mean <= 1
        assert q.min_score <= q.median <= q.max_score
        assert q.std >= 0

    def test_error_rate(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        assert 0 < profile.error_rate < 1  # Has some errors

    def test_no_errors(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("claude-haiku")
        assert profile is not None
        assert profile.error_rate == 0.0

    def test_task_affinities(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        assert len(profile.task_affinities) > 0
        for aff in profile.task_affinities:
            assert isinstance(aff, TaskAffinity)
            assert aff.sample_count > 0
            assert 0 <= aff.score <= 1

    def test_hourly_latency(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        assert isinstance(profile.hourly_latency, dict)

    def test_throughput(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        assert profile.tokens_per_second > 0

    def test_avg_cost(self, populated_profiler: ModelProfiler) -> None:
        profile = populated_profiler.get_profile("gpt-4o")
        assert profile is not None
        assert profile.avg_cost_per_request > 0


# ---------------------------------------------------------------------------
# Ranking tests
# ---------------------------------------------------------------------------


class TestRanking:
    """Tests for model ranking."""

    def test_rank_models(self, populated_profiler: ModelProfiler) -> None:
        rankings = populated_profiler.rank_models()
        assert len(rankings) >= 2
        for r in rankings:
            assert isinstance(r, ModelRanking)
            assert 0 <= r.overall_score <= 1

    def test_ranking_sorted(self, populated_profiler: ModelProfiler) -> None:
        rankings = populated_profiler.rank_models()
        for i in range(len(rankings) - 1):
            assert rankings[i].overall_score >= rankings[i + 1].overall_score

    def test_ranking_by_task(self, populated_profiler: ModelProfiler) -> None:
        code_ranks = populated_profiler.rank_models(task_type="code")
        chat_ranks = populated_profiler.rank_models(task_type="chat")
        # Both should have results
        assert len(code_ranks) > 0
        assert len(chat_ranks) > 0

    def test_min_samples_filter(self, profiler: ModelProfiler) -> None:
        profiler.record("test", latency_ms=100, quality_score=0.8)
        rankings = profiler.rank_models(min_samples=5)
        assert len(rankings) == 0  # Not enough samples

    def test_get_best_model(self, populated_profiler: ModelProfiler) -> None:
        best = populated_profiler.get_best_model()
        assert best is not None
        assert isinstance(best, str)

    def test_get_best_model_insufficient_data(self, profiler: ModelProfiler) -> None:
        assert profiler.get_best_model() is None

    def test_component_scores(self, populated_profiler: ModelProfiler) -> None:
        rankings = populated_profiler.rank_models()
        for r in rankings:
            assert 0 <= r.quality_score <= 1
            assert 0 <= r.speed_score <= 1
            assert 0 <= r.cost_score <= 1
            assert 0 <= r.reliability_score <= 1


# ---------------------------------------------------------------------------
# Clear tests
# ---------------------------------------------------------------------------


class TestClear:
    """Tests for clearing records."""

    def test_clear_specific_model(self, populated_profiler: ModelProfiler) -> None:
        populated_profiler.clear("gpt-4o")
        assert populated_profiler.get_record_count("gpt-4o") == 0
        assert populated_profiler.get_record_count("claude-haiku") > 0

    def test_clear_all(self, populated_profiler: ModelProfiler) -> None:
        populated_profiler.clear()
        assert populated_profiler.get_all_models() == []

    def test_clear_nonexistent(self, profiler: ModelProfiler) -> None:
        profiler.clear("nonexistent")  # Should not raise
