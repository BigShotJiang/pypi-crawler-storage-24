"""Tests for the background health prober."""

from __future__ import annotations

import asyncio

import pytest

from prism.llm.health_prober import HealthProber, ProviderHealth


class TestHealthProber:
    """Tests for the HealthProber class."""

    @pytest.fixture()
    def prober(self) -> HealthProber:
        return HealthProber(
            probe_interval=1.0,
            probe_timeout=2.0,
            degraded_threshold_ms=1000.0,
        )

    @pytest.mark.asyncio()
    async def test_healthy_probe(self, prober: HealthProber) -> None:
        async def fast_probe() -> None:
            await asyncio.sleep(0.01)

        prober.register_probe("openai", fast_probe)
        report = await prober.probe_provider("openai")
        assert report.status == ProviderHealth.HEALTHY
        assert report.latency_ms > 0
        assert report.consecutive_failures == 0

    @pytest.mark.asyncio()
    async def test_down_probe(self, prober: HealthProber) -> None:
        async def failing_probe() -> None:
            raise ConnectionError("Connection refused")

        prober.register_probe("openai", failing_probe)
        report = await prober.probe_provider("openai")
        assert report.status == ProviderHealth.DOWN
        assert report.consecutive_failures == 1
        assert "Connection refused" in report.error_message

    @pytest.mark.asyncio()
    async def test_timeout_probe(self, prober: HealthProber) -> None:
        async def slow_probe() -> None:
            await asyncio.sleep(10.0)

        prober.register_probe("slow-provider", slow_probe)
        report = await prober.probe_provider("slow-provider")
        assert report.status == ProviderHealth.DOWN
        assert "timed out" in report.error_message.lower()

    @pytest.mark.asyncio()
    async def test_degraded_probe(self, prober: HealthProber) -> None:
        async def slow_but_working() -> None:
            await asyncio.sleep(1.5)  # > degraded_threshold_ms (1000ms)

        prober.register_probe("slow", slow_but_working)
        report = await prober.probe_provider("slow")
        assert report.status == ProviderHealth.DEGRADED

    @pytest.mark.asyncio()
    async def test_probe_all(self, prober: HealthProber) -> None:
        async def fast() -> None:
            await asyncio.sleep(0.01)

        async def fail() -> None:
            raise RuntimeError("Down")

        prober.register_probe("good", fast)
        prober.register_probe("bad", fail)
        reports = await prober.probe_all()
        assert reports["good"].status == ProviderHealth.HEALTHY
        assert reports["bad"].status == ProviderHealth.DOWN

    def test_get_status_unknown(self, prober: HealthProber) -> None:
        assert prober.get_status("unknown") == ProviderHealth.UNKNOWN

    def test_is_healthy_unknown(self, prober: HealthProber) -> None:
        # Unknown providers should get benefit of the doubt
        assert prober.is_healthy("new-provider")

    @pytest.mark.asyncio()
    async def test_healthy_providers_list(self, prober: HealthProber) -> None:
        async def ok() -> None:
            pass

        async def fail() -> None:
            raise RuntimeError("Down")

        prober.register_probe("good1", ok)
        prober.register_probe("good2", ok)
        prober.register_probe("bad", fail)

        await prober.probe_all()
        healthy = prober.get_healthy_providers()
        assert "good1" in healthy
        assert "good2" in healthy
        assert "bad" not in healthy

    def test_manual_mark_healthy(self, prober: HealthProber) -> None:
        prober.register_probe("test", lambda: None)
        prober.mark_down("test", "manually marked")
        assert prober.get_status("test") == ProviderHealth.DOWN
        prober.mark_healthy("test")
        assert prober.get_status("test") == ProviderHealth.HEALTHY

    def test_consecutive_failures(self, prober: HealthProber) -> None:
        prober.register_probe("test", lambda: None)
        prober.mark_down("test", "fail 1")
        prober.mark_down("test", "fail 2")
        prober.mark_down("test", "fail 3")
        report = prober.get_report("test")
        assert report is not None
        assert report.consecutive_failures == 3

    @pytest.mark.asyncio()
    async def test_start_stop(self, prober: HealthProber) -> None:
        async def ok() -> None:
            pass

        prober.register_probe("test", ok)
        await prober.start()
        await asyncio.sleep(0.1)
        await prober.stop()
        # Should not raise
