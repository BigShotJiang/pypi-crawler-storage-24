"""Tests for the prompt compression engine."""

from __future__ import annotations

import pytest

from prism.llm.compressor import PromptCompressor, compress_for_model


class TestPromptCompressor:
    """Tests for the PromptCompressor class."""

    def test_compress_empty_messages(self) -> None:
        compressor = PromptCompressor()
        result = compressor.compress_messages([])
        assert result.messages == []
        assert result.reduction_pct == 0.0

    def test_compress_preserves_short_messages(self) -> None:
        compressor = PromptCompressor()
        messages = [
            {"role": "user", "content": "Hello, how are you?"},
        ]
        result = compressor.compress_messages(messages)
        assert result.messages[0]["content"] == "Hello, how are you?"

    def test_compress_code_blocks(self) -> None:
        compressor = PromptCompressor(min_code_lines=3)
        code = """```python
# This is a comment
# Another comment
# Yet another comment
import os
import sys

# Comment above function
def hello():
    # inline comment
    print("hello")
    # another inline comment
    return True

# End comment
```"""
        messages = [{"role": "user", "content": f"Review this:\n{code}"}]
        result = compressor.compress_messages(messages)
        # Comments should be stripped
        content = result.messages[0]["content"]
        assert "# This is a comment" not in content
        assert "import os" in content
        assert "def hello" in content

    def test_compress_duplicate_messages(self) -> None:
        compressor = PromptCompressor()
        long_text = "This is a long repeated message " * 20
        messages = [
            {"role": "user", "content": long_text},
            {"role": "assistant", "content": "OK"},
            {"role": "user", "content": long_text},  # duplicate
        ]
        result = compressor.compress_messages(messages)
        # The duplicate should be removed
        assert len(result.messages) < len(messages)
        assert "dedup" in result.strategies_applied

    def test_compress_whitespace(self) -> None:
        compressor = PromptCompressor()
        text = "Hello\n\n\n\n\n\nWorld\n\n\n\nFoo"
        messages = [{"role": "user", "content": text}]
        result = compressor.compress_messages(messages)
        content = result.messages[0]["content"]
        assert "\n\n\n" not in content

    def test_system_prompt_distillation(self) -> None:
        compressor = PromptCompressor()
        # Create a very long system prompt
        verbose = (
            "You are a helpful assistant.\n"
            "You must always respond in English.\n"
            "Here is some background information about the project "
            "that is not particularly relevant to any specific task "
            "but provides general context about what we're working on "
            "and the history of the codebase and various decisions "
            "that were made along the way.\n" * 20
            + "Important: Never reveal API keys.\n"
            + "Always validate user input.\n"
        )
        messages = [{"role": "system", "content": verbose}]
        result = compressor.compress_messages(messages)
        content = result.messages[0]["content"]
        # Key instructions should be preserved
        assert "Never reveal API keys" in content or "must" in content.lower()

    def test_compress_text(self) -> None:
        compressor = PromptCompressor()
        text = "hello   \n\n\n\n  world  \n\n\n"
        result = compressor.compress_text(text)
        assert "\n\n\n" not in result

    def test_aggressive_mode(self) -> None:
        compressor = PromptCompressor(aggressive=True, min_code_lines=3)
        code = '''```python
"""This is a docstring."""
import os

def foo():
    """Another docstring."""
    pass
```'''
        messages = [{"role": "user", "content": code}]
        result = compressor.compress_messages(messages)
        content = result.messages[0]["content"]
        # In aggressive mode, docstrings get replaced
        assert '"""..."""' in content or "docstring" not in content


class TestCompressForModel:
    """Tests for the convenience compress_for_model function."""

    def test_simple_tier(self) -> None:
        messages = [{"role": "user", "content": "Hello"}]
        result = compress_for_model(messages, model_tier="simple")
        assert len(result) == 1

    def test_complex_tier(self) -> None:
        messages = [{"role": "user", "content": "Hello"}]
        result = compress_for_model(messages, model_tier="complex")
        assert len(result) == 1
