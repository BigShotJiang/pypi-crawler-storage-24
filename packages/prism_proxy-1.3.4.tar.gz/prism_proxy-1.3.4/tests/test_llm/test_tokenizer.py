"""Tests for the token counting module."""

from __future__ import annotations

import threading
from unittest.mock import MagicMock, patch

import pytest

from prism.llm.tokenizer import (
    _get_context_window,
    _get_encoding,
    _heuristic_count,
    count_message_tokens,
    count_tokens,
    count_tokens_batch,
    count_tool_tokens,
    estimate_max_output_tokens,
    has_tiktoken,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _reset_tiktoken_state() -> None:
    """Reset the module-level tiktoken caching so tests are independent."""
    import prism.llm.tokenizer as mod

    mod._tiktoken = None
    mod._tiktoken_available = None
    # Clear LRU caches so encoder is re-fetched
    mod._get_encoder.cache_clear()
    mod._get_encoding.cache_clear()


@pytest.fixture(autouse=True)
def _clean_caches():
    """Ensure LRU caches are cleared between tests for isolation."""
    from prism.llm.tokenizer import _get_encoder, _get_encoding

    _get_encoding.cache_clear()
    _get_encoder.cache_clear()
    yield
    _get_encoding.cache_clear()
    _get_encoder.cache_clear()


# ===========================================================================
# count_tokens — basic
# ===========================================================================


class TestCountTokensBasic:
    """Tests for count_tokens with various input types."""

    def test_empty_string(self) -> None:
        assert count_tokens("") == 0

    def test_single_word(self) -> None:
        result = count_tokens("hello")
        assert result >= 1

    def test_paragraph(self) -> None:
        text = (
            "The quick brown fox jumps over the lazy dog. "
            "This is a simple English paragraph with common words."
        )
        result = count_tokens(text)
        assert result > 0
        # A ~20-word paragraph should produce roughly 15-30 tokens
        assert result < 100

    def test_code_snippet(self) -> None:
        code = 'def hello():\n    print("Hello, world!")\n    return True'
        result = count_tokens(code)
        assert result > 0

    def test_whitespace_only(self) -> None:
        # Whitespace-only text may tokenize to a few tokens
        result = count_tokens("   \n\t  ")
        assert result >= 0

    def test_special_characters(self) -> None:
        result = count_tokens("!@#$%^&*()_+-=[]{}|;':\",./<>?")
        assert result >= 1

    def test_long_text(self) -> None:
        text = "word " * 1000
        result = count_tokens(text)
        assert result > 500

    def test_unicode_text(self) -> None:
        result = count_tokens("Hello, world!")
        assert result >= 1

    def test_multiline_text(self) -> None:
        text = "line one\nline two\nline three"
        result = count_tokens(text)
        assert result >= 3


# ===========================================================================
# count_tokens — model selection
# ===========================================================================


class TestCountTokensModels:
    """Tests for count_tokens with different model names."""

    def test_gpt4o_model(self) -> None:
        result = count_tokens("hello world", model="gpt-4o")
        assert result >= 1

    def test_claude_model(self) -> None:
        result = count_tokens("hello world", model="claude-3-opus-20240229")
        assert result >= 1

    def test_gemini_model(self) -> None:
        result = count_tokens("hello world", model="gemini-1.5-pro")
        assert result >= 1

    def test_deepseek_model(self) -> None:
        result = count_tokens("hello world", model="deepseek-chat")
        assert result >= 1

    def test_mistral_model(self) -> None:
        result = count_tokens("hello world", model="mistral-large")
        assert result >= 1

    def test_unknown_model_uses_default(self) -> None:
        result = count_tokens("hello world", model="unknown-model-xyz")
        assert result >= 1

    def test_consistent_results(self) -> None:
        """Same text and model should always produce the same count."""
        text = "The quick brown fox"
        r1 = count_tokens(text, "gpt-4o")
        r2 = count_tokens(text, "gpt-4o")
        assert r1 == r2


# ===========================================================================
# count_tokens_batch
# ===========================================================================


class TestCountTokensBatch:
    """Tests for count_tokens_batch."""

    def test_empty_list(self) -> None:
        assert count_tokens_batch([]) == []

    def test_single_item(self) -> None:
        result = count_tokens_batch(["hello"])
        assert len(result) == 1
        assert result[0] >= 1

    def test_multiple_items(self) -> None:
        texts = ["hello", "world", "foo bar baz"]
        result = count_tokens_batch(texts)
        assert len(result) == 3
        assert all(r >= 1 for r in result)

    def test_matches_individual_counts(self) -> None:
        """Batch counts should match individual counts."""
        texts = ["hello world", "def foo(): pass", "The quick brown fox"]
        batch = count_tokens_batch(texts, model="gpt-4o")
        individual = [count_tokens(t, model="gpt-4o") for t in texts]
        assert batch == individual

    def test_with_empty_strings(self) -> None:
        result = count_tokens_batch(["", "hello", ""])
        assert result[0] == 0
        assert result[1] >= 1
        assert result[2] == 0


# ===========================================================================
# count_message_tokens
# ===========================================================================


class TestCountMessageTokens:
    """Tests for count_message_tokens with various message formats."""

    def test_empty_messages(self) -> None:
        assert count_message_tokens([]) == 0

    def test_single_user_message(self) -> None:
        msgs = [{"role": "user", "content": "Hello"}]
        result = count_message_tokens(msgs)
        # At minimum: 3 (base) + 4 (per-msg) + tokens for "Hello" + tokens for "user"
        assert result >= 7

    def test_conversation(self) -> None:
        msgs = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "What is 2+2?"},
            {"role": "assistant", "content": "4"},
        ]
        result = count_message_tokens(msgs)
        # 3 base + 3*4 per-message + content tokens + role tokens
        assert result >= 15

    def test_multipart_content_text(self) -> None:
        msgs = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Describe this image"},
                ],
            },
        ]
        result = count_message_tokens(msgs)
        assert result > 0

    def test_multipart_content_image_low(self) -> None:
        msgs = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What's in this?"},
                    {
                        "type": "image_url",
                        "image_url": {"url": "http://example.com/img.png", "detail": "low"},
                    },
                ],
            },
        ]
        result = count_message_tokens(msgs)
        # Should include 85 tokens for low-detail image
        assert result >= 85

    def test_multipart_content_image_high(self) -> None:
        msgs = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": "http://example.com/img.png", "detail": "high"},
                    },
                ],
            },
        ]
        result = count_message_tokens(msgs)
        # Should include 765 tokens for high-detail image
        assert result >= 765

    def test_multipart_content_image_auto(self) -> None:
        msgs = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": "http://example.com/img.png", "detail": "auto"},
                    },
                ],
            },
        ]
        result = count_message_tokens(msgs)
        # Auto detail defaults to high (765)
        assert result >= 765

    def test_message_with_name(self) -> None:
        msgs = [{"role": "user", "content": "Hello", "name": "alice"}]
        without_name = count_message_tokens([{"role": "user", "content": "Hello"}])
        with_name = count_message_tokens(msgs)
        # Name adds tokens
        assert with_name > without_name

    def test_message_with_tool_calls(self) -> None:
        msgs = [
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {
                        "id": "call_123",
                        "type": "function",
                        "function": {
                            "name": "get_weather",
                            "arguments": '{"city": "London"}',
                        },
                    },
                ],
            },
        ]
        result = count_message_tokens(msgs)
        # Should include tokens for function name, arguments, and framing
        assert result > 10

    def test_empty_content(self) -> None:
        msgs = [{"role": "assistant", "content": ""}]
        result = count_message_tokens(msgs)
        # Should at least have base + per-message + role tokens
        assert result >= 7

    def test_multiple_tool_calls(self) -> None:
        msgs = [
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "fn1", "arguments": "{}"},
                    },
                    {
                        "id": "call_2",
                        "type": "function",
                        "function": {"name": "fn2", "arguments": '{"a":1}'},
                    },
                ],
            },
        ]
        single_tc = count_message_tokens(
            [
                {
                    "role": "assistant",
                    "content": "",
                    "tool_calls": [
                        {
                            "id": "call_1",
                            "type": "function",
                            "function": {"name": "fn1", "arguments": "{}"},
                        },
                    ],
                },
            ]
        )
        result = count_message_tokens(msgs)
        # Two tool calls should cost more than one
        assert result > single_tc


# ===========================================================================
# count_tool_tokens
# ===========================================================================


class TestCountToolTokens:
    """Tests for count_tool_tokens."""

    def test_empty_tools(self) -> None:
        assert count_tool_tokens([]) == 0

    def test_single_tool(self) -> None:
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "Get weather for a city",
                    "parameters": {
                        "type": "object",
                        "properties": {"city": {"type": "string"}},
                    },
                },
            },
        ]
        result = count_tool_tokens(tools)
        assert result > 0

    def test_multiple_tools(self) -> None:
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "fn1",
                    "description": "First function",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "fn2",
                    "description": "Second function",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
        ]
        single = count_tool_tokens(tools[:1])
        both = count_tool_tokens(tools)
        assert both > single


# ===========================================================================
# estimate_max_output_tokens
# ===========================================================================


class TestEstimateMaxOutputTokens:
    """Tests for estimate_max_output_tokens."""

    def test_gpt4o(self) -> None:
        result = estimate_max_output_tokens("gpt-4o", input_tokens=1000)
        # gpt-4o: 128k context, 16384 max output
        assert result == 16384

    def test_claude(self) -> None:
        result = estimate_max_output_tokens("claude-3-opus", input_tokens=1000)
        # claude: 200k context, 8192 max output
        assert result == 8192

    def test_gemini(self) -> None:
        result = estimate_max_output_tokens("gemini-2-pro", input_tokens=1000)
        assert result == 8192

    def test_deepseek(self) -> None:
        result = estimate_max_output_tokens("deepseek-chat", input_tokens=1000)
        assert result == 8192

    def test_unknown_model(self) -> None:
        result = estimate_max_output_tokens("unknown-model", input_tokens=1000)
        # Conservative: 8192 context - 1000 = 7192, capped at 4096
        assert result == 4096

    def test_custom_max_context(self) -> None:
        result = estimate_max_output_tokens("gpt-4o", input_tokens=1000, max_context=5000)
        # remaining = 4000, min(4000, 16384) = 4000
        assert result == 4000

    def test_input_exceeds_context(self) -> None:
        result = estimate_max_output_tokens("gpt-4o", input_tokens=200000, max_context=128000)
        # remaining = -72000, negative is min with max_output
        assert result < 0

    def test_large_input_small_remaining(self) -> None:
        # When remaining is less than max_output, remaining wins
        result = estimate_max_output_tokens("gpt-4o", input_tokens=127000)
        assert result == 1000  # 128000 - 127000


# ===========================================================================
# _heuristic_count
# ===========================================================================


class TestHeuristicCount:
    """Tests for the fallback heuristic token counter."""

    def test_empty_text(self) -> None:
        assert _heuristic_count("") == 0

    def test_english_text(self) -> None:
        text = "The quick brown fox jumps over the lazy dog"
        result = _heuristic_count(text)
        # 9 words * 1.3 = 11.7 -> 11
        assert result == 11

    def test_code_text(self) -> None:
        code = "def hello(name): { return f'Hello {name}'; } // end; import os; class Foo():"
        result = _heuristic_count(code)
        # Should use 1.5 multiplier (code detected)
        words = len(code.split())
        expected = int(words * 1.5)
        assert result == max(1, expected)

    def test_minimum_one(self) -> None:
        # A single short word should return at least 1
        assert _heuristic_count("a") >= 1

    def test_non_ascii_adds_tokens(self) -> None:
        ascii_text = "hello world"
        unicode_text = "hello world\u4e16\u754c"  # Chinese characters appended
        ascii_count = _heuristic_count(ascii_text)
        unicode_count = _heuristic_count(unicode_text)
        # Unicode version should have more tokens
        assert unicode_count > ascii_count

    def test_code_detection_threshold(self) -> None:
        # Less than 3 code indicators should NOT trigger code mode
        not_code = "hello world (test)"  # only 1 indicator: "("
        code = "def foo() { return; } // end"  # 5+ indicators
        not_code_count = _heuristic_count(not_code)
        code_count = _heuristic_count(code)
        # Code should produce higher count for same word count
        not_code_words = len(not_code.split())
        code_words = len(code.split())
        # Check multipliers: not_code uses 1.3, code uses 1.5
        assert not_code_count == max(1, int(not_code_words * 1.3))
        assert code_count == max(1, int(code_words * 1.5))


# ===========================================================================
# _get_encoding
# ===========================================================================


class TestGetEncoding:
    """Tests for model-to-encoding resolution."""

    def test_gpt4o(self) -> None:
        assert _get_encoding("gpt-4o") == "o200k_base"

    def test_gpt4o_mini(self) -> None:
        assert _get_encoding("gpt-4o-mini") == "o200k_base"

    def test_gpt4_turbo(self) -> None:
        assert _get_encoding("gpt-4-turbo") == "cl100k_base"

    def test_gpt4(self) -> None:
        assert _get_encoding("gpt-4") == "cl100k_base"

    def test_gpt35_turbo(self) -> None:
        assert _get_encoding("gpt-3.5-turbo") == "cl100k_base"

    def test_o1(self) -> None:
        assert _get_encoding("o1") == "o200k_base"

    def test_o3(self) -> None:
        assert _get_encoding("o3") == "o200k_base"

    def test_claude(self) -> None:
        assert _get_encoding("claude-3-opus") == "cl100k_base"

    def test_gemini(self) -> None:
        assert _get_encoding("gemini-1.5-pro") == "cl100k_base"

    def test_deepseek(self) -> None:
        assert _get_encoding("deepseek-chat") == "cl100k_base"

    def test_mistral(self) -> None:
        assert _get_encoding("mistral-large") == "cl100k_base"

    def test_llama(self) -> None:
        assert _get_encoding("llama-3-70b") == "cl100k_base"

    def test_unknown_model_returns_default(self) -> None:
        assert _get_encoding("totally-unknown") == "cl100k_base"

    def test_case_insensitive(self) -> None:
        assert _get_encoding("GPT-4o") == _get_encoding("gpt-4o")

    def test_cache_returns_same_result(self) -> None:
        """LRU cache should return the same result on repeated calls."""
        r1 = _get_encoding("gpt-4o")
        r2 = _get_encoding("gpt-4o")
        assert r1 == r2


# ===========================================================================
# _get_context_window
# ===========================================================================


class TestGetContextWindow:
    """Tests for context window size lookup."""

    def test_claude_opus_4(self) -> None:
        assert _get_context_window("claude-opus-4") == 200000

    def test_claude_sonnet_4(self) -> None:
        assert _get_context_window("claude-sonnet-4") == 200000

    def test_claude_haiku_4(self) -> None:
        assert _get_context_window("claude-haiku-4") == 200000

    def test_claude_35(self) -> None:
        assert _get_context_window("claude-3.5-sonnet") == 200000

    def test_gpt4o(self) -> None:
        assert _get_context_window("gpt-4o") == 128000

    def test_gpt4_turbo(self) -> None:
        assert _get_context_window("gpt-4-turbo") == 128000

    def test_gpt4_base(self) -> None:
        assert _get_context_window("gpt-4") == 8192

    def test_gpt35_turbo(self) -> None:
        assert _get_context_window("gpt-3.5-turbo") == 16385

    def test_o1(self) -> None:
        assert _get_context_window("o1-preview") == 200000

    def test_o3(self) -> None:
        assert _get_context_window("o3-mini") == 200000

    def test_gemini_2(self) -> None:
        assert _get_context_window("gemini-2-pro") == 1048576

    def test_gemini_15_pro(self) -> None:
        assert _get_context_window("gemini-1.5-pro") == 1048576

    def test_deepseek(self) -> None:
        assert _get_context_window("deepseek-chat") == 64000

    def test_mistral(self) -> None:
        assert _get_context_window("mistral-large") == 32000

    def test_llama(self) -> None:
        assert _get_context_window("llama-3-70b") == 131072

    def test_unknown_model_conservative_default(self) -> None:
        assert _get_context_window("some-unknown-model") == 8192


# ===========================================================================
# has_tiktoken
# ===========================================================================


class TestHasTiktoken:
    """Tests for has_tiktoken."""

    def test_returns_bool(self) -> None:
        result = has_tiktoken()
        assert isinstance(result, bool)

    def test_consistent_results(self) -> None:
        r1 = has_tiktoken()
        r2 = has_tiktoken()
        assert r1 == r2


# ===========================================================================
# Tiktoken unavailable (mocked)
# ===========================================================================


class TestWithoutTiktoken:
    """Tests with tiktoken mocked away to test fallback paths."""

    def setup_method(self) -> None:
        _reset_tiktoken_state()

    def teardown_method(self) -> None:
        _reset_tiktoken_state()

    def test_count_tokens_falls_back_to_heuristic(self) -> None:
        _reset_tiktoken_state()
        import prism.llm.tokenizer as mod

        with patch.dict("sys.modules", {"tiktoken": None}):
            mod._tiktoken_available = None
            mod._tiktoken = None
            mod._get_encoder.cache_clear()
            # Force re-check
            mod._tiktoken_available = False
            result = count_tokens("hello world test")
            # Heuristic: 3 words * 1.3 = 3.9 -> 3
            assert result == 3

    def test_count_tokens_batch_falls_back(self) -> None:
        _reset_tiktoken_state()
        import prism.llm.tokenizer as mod

        mod._tiktoken_available = False
        mod._get_encoder.cache_clear()

        result = count_tokens_batch(["hello", "world test"])
        assert len(result) == 2
        assert result[0] >= 1
        assert result[1] >= 1

    def test_has_tiktoken_false(self) -> None:
        _reset_tiktoken_state()
        import prism.llm.tokenizer as mod

        mod._tiktoken_available = False
        assert not has_tiktoken()

    def test_count_message_tokens_falls_back(self) -> None:
        _reset_tiktoken_state()
        import prism.llm.tokenizer as mod

        mod._tiktoken_available = False
        mod._get_encoder.cache_clear()

        msgs = [{"role": "user", "content": "Hello world"}]
        result = count_message_tokens(msgs)
        assert result > 0


# ===========================================================================
# Tiktoken available (mocked encoder)
# ===========================================================================


class TestWithMockedTiktoken:
    """Tests with a mocked tiktoken encoder to control exact token counts."""

    def setup_method(self) -> None:
        _reset_tiktoken_state()

    def teardown_method(self) -> None:
        _reset_tiktoken_state()

    def test_uses_encoder_when_available(self) -> None:
        import prism.llm.tokenizer as mod

        mock_encoder = MagicMock()
        mock_encoder.encode.return_value = [1, 2, 3]  # 3 tokens

        mod._tiktoken_available = True
        mod._tiktoken = MagicMock()
        mod._tiktoken.get_encoding.return_value = mock_encoder
        mod._get_encoder.cache_clear()

        result = count_tokens("hello world")
        assert result == 3
        mock_encoder.encode.assert_called_once_with("hello world", disallowed_special=())

    def test_batch_uses_encoder(self) -> None:
        import prism.llm.tokenizer as mod

        mock_encoder = MagicMock()
        mock_encoder.encode.side_effect = [[1, 2], [3, 4, 5]]

        mod._tiktoken_available = True
        mod._tiktoken = MagicMock()
        mod._tiktoken.get_encoding.return_value = mock_encoder
        mod._get_encoder.cache_clear()

        result = count_tokens_batch(["hi", "hey there"])
        assert result == [2, 3]


# ===========================================================================
# Thread safety
# ===========================================================================


class TestThreadSafety:
    """Test that concurrent calls do not corrupt state."""

    def test_concurrent_count_tokens(self) -> None:
        results: list[int] = []
        errors: list[Exception] = []
        text = "The quick brown fox jumps over the lazy dog"

        def worker() -> None:
            try:
                r = count_tokens(text)
                results.append(r)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        assert not errors
        assert len(results) == 10
        # All results should be identical
        assert len(set(results)) == 1

    def test_concurrent_ensure_tiktoken(self) -> None:
        """_ensure_tiktoken should be safe under concurrent access."""
        results: list[bool] = []
        errors: list[Exception] = []

        def worker() -> None:
            try:
                r = has_tiktoken()
                results.append(r)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        assert not errors
        assert len(results) == 10
        assert len(set(results)) == 1


# ===========================================================================
# LRU cache verification
# ===========================================================================


class TestLRUCache:
    """Verify that caches return consistent results."""

    def test_get_encoding_cached(self) -> None:
        r1 = _get_encoding("gpt-4o")
        r2 = _get_encoding("gpt-4o")
        assert r1 is r2  # Same object from cache

    def test_count_tokens_deterministic(self) -> None:
        text = "Deterministic token counting test"
        r1 = count_tokens(text, "gpt-4o")
        r2 = count_tokens(text, "gpt-4o")
        assert r1 == r2


# ===========================================================================
# Edge cases
# ===========================================================================


class TestEdgeCases:
    """Edge case tests."""

    def test_none_like_empty(self) -> None:
        # Empty string
        assert count_tokens("") == 0

    def test_very_long_text(self) -> None:
        text = "a " * 10000
        result = count_tokens(text)
        assert result > 1000

    def test_newlines_only(self) -> None:
        result = count_tokens("\n\n\n")
        assert result >= 0

    def test_tabs_only(self) -> None:
        result = count_tokens("\t\t\t")
        assert result >= 0

    def test_mixed_whitespace(self) -> None:
        result = count_tokens(" \t\n \t\n ")
        assert result >= 0

    def test_tool_tokens_with_no_tools(self) -> None:
        assert count_tool_tokens([]) == 0

    def test_message_tokens_missing_content_key(self) -> None:
        msgs = [{"role": "user"}]
        result = count_message_tokens(msgs)
        # Should handle missing content gracefully
        assert result > 0

    def test_message_tokens_non_dict_tool_call(self) -> None:
        msgs = [
            {
                "role": "assistant",
                "content": "",
                "tool_calls": ["not_a_dict"],
            },
        ]
        # Should not crash on non-dict tool calls
        result = count_message_tokens(msgs)
        assert result > 0

    def test_count_tokens_batch_preserves_order(self) -> None:
        texts = ["short", "a much longer sentence with many words in it"]
        result = count_tokens_batch(texts)
        assert result[0] < result[1]
