"""Tests for the response validation and repair engine."""

from __future__ import annotations

import json

import pytest

from prism.llm.response_validator import (
    ResponseValidator,
    ValidationIssue,
    ValidationResult,
    ValidationSeverity,
    ValidationType,
)


@pytest.fixture()
def validator() -> ResponseValidator:
    return ResponseValidator()


# ---------------------------------------------------------------------------
# Length validation
# ---------------------------------------------------------------------------


class TestLengthValidation:
    """Tests for response length checks."""

    def test_empty_response_fails(self, validator: ResponseValidator) -> None:
        result = validator.validate("")
        assert not result.is_valid
        assert any(i.validation_type == ValidationType.LENGTH for i in result.issues)

    def test_normal_response_passes(self, validator: ResponseValidator) -> None:
        result = validator.validate("This is a valid response.")
        assert result.is_valid

    def test_very_long_response_warns(self) -> None:
        v = ResponseValidator(max_length=100)
        result = v.validate("x" * 200)
        assert any(
            i.validation_type == ValidationType.LENGTH
            and i.severity == ValidationSeverity.WARNING
            for i in result.issues
        )

    def test_min_length_enforced(self) -> None:
        v = ResponseValidator(min_length=10)
        result = v.validate("short")
        assert not result.is_valid


# ---------------------------------------------------------------------------
# Truncation detection
# ---------------------------------------------------------------------------


class TestTruncationDetection:
    """Tests for detecting truncated responses."""

    def test_ellipsis_ending(self, validator: ResponseValidator) -> None:
        result = validator.validate("This response is incomplete...")
        assert any(i.validation_type == ValidationType.TRUNCATION for i in result.issues)

    def test_truncated_tag(self, validator: ResponseValidator) -> None:
        result = validator.validate("Some content [truncated]")
        assert any(i.validation_type == ValidationType.TRUNCATION for i in result.issues)

    def test_continued_tag(self, validator: ResponseValidator) -> None:
        result = validator.validate("Some content [continued]")
        assert any(i.validation_type == ValidationType.TRUNCATION for i in result.issues)

    def test_clean_ending_no_truncation(self, validator: ResponseValidator) -> None:
        result = validator.validate("This is a complete response.")
        truncation_issues = [i for i in result.issues if i.validation_type == ValidationType.TRUNCATION]
        assert len(truncation_issues) == 0


# ---------------------------------------------------------------------------
# Format validation
# ---------------------------------------------------------------------------


class TestFormatValidation:
    """Tests for format-specific validation."""

    def test_valid_json(self, validator: ResponseValidator) -> None:
        result = validator.validate('{"key": "value"}', expected_format="json")
        json_errors = [
            i for i in result.errors if i.validation_type == ValidationType.FORMAT
        ]
        assert len(json_errors) == 0

    def test_invalid_json(self, validator: ResponseValidator) -> None:
        result = validator.validate("not json at all", expected_format="json")
        assert any(
            i.validation_type == ValidationType.FORMAT
            and i.severity == ValidationSeverity.ERROR
            for i in result.issues
        )

    def test_json_in_code_block(self, validator: ResponseValidator) -> None:
        response = '```json\n{"key": "value"}\n```'
        result = validator.validate(response, expected_format="json")
        json_errors = [
            i for i in result.errors if i.validation_type == ValidationType.FORMAT
        ]
        assert len(json_errors) == 0

    def test_markdown_with_headers(self, validator: ResponseValidator) -> None:
        result = validator.validate(
            "# Title\n\nSome **bold** text with a list:\n- Item 1\n- Item 2",
            expected_format="markdown",
        )
        format_issues = [
            i for i in result.issues if i.validation_type == ValidationType.FORMAT
        ]
        assert len(format_issues) == 0

    def test_code_with_blocks(self, validator: ResponseValidator) -> None:
        result = validator.validate(
            "Here's the code:\n```python\ndef hello():\n    print('hi')\n```",
            expected_format="code",
        )
        format_issues = [
            i for i in result.issues
            if i.validation_type == ValidationType.FORMAT
        ]
        assert len(format_issues) == 0

    def test_code_without_blocks_warns(self, validator: ResponseValidator) -> None:
        result = validator.validate(
            "The answer is 42.",
            expected_format="code",
        )
        assert any(
            i.validation_type == ValidationType.FORMAT for i in result.issues
        )


# ---------------------------------------------------------------------------
# JSON schema validation
# ---------------------------------------------------------------------------


class TestJSONSchemaValidation:
    """Tests for JSON schema validation."""

    def test_valid_schema(self, validator: ResponseValidator) -> None:
        schema = {
            "type": "object",
            "required": ["name", "age"],
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
        }
        result = validator.validate(
            '{"name": "Alice", "age": 30}',
            json_schema=schema,
        )
        schema_errors = [
            i for i in result.errors if i.validation_type == ValidationType.JSON_SCHEMA
        ]
        assert len(schema_errors) == 0

    def test_missing_required_property(self, validator: ResponseValidator) -> None:
        schema = {
            "type": "object",
            "required": ["name", "age"],
        }
        result = validator.validate(
            '{"name": "Alice"}',
            json_schema=schema,
        )
        assert any(
            "Missing required" in i.message for i in result.issues
        )

    def test_wrong_property_type(self, validator: ResponseValidator) -> None:
        schema = {
            "type": "object",
            "properties": {"age": {"type": "integer"}},
        }
        result = validator.validate(
            '{"age": "thirty"}',
            json_schema=schema,
        )
        assert any("wrong type" in i.message for i in result.issues)

    def test_expected_object_got_array(self, validator: ResponseValidator) -> None:
        schema = {"type": "object"}
        result = validator.validate("[1, 2, 3]", json_schema=schema)
        assert any(
            "Expected JSON object" in i.message for i in result.issues
        )

    def test_expected_array_got_object(self, validator: ResponseValidator) -> None:
        schema = {"type": "array"}
        result = validator.validate('{"key": "value"}', json_schema=schema)
        assert any(
            "Expected JSON array" in i.message for i in result.issues
        )


# ---------------------------------------------------------------------------
# Code syntax validation
# ---------------------------------------------------------------------------


class TestCodeSyntax:
    """Tests for code syntax validation."""

    def test_python_mixed_indentation(self, validator: ResponseValidator) -> None:
        code = "```python\ndef foo():\n    x = 1\n\ty = 2\n```"
        result = validator.validate(code, expected_language="python")
        assert any("indentation" in i.message.lower() for i in result.issues)

    def test_python_unclosed_triple_quote(self, validator: ResponseValidator) -> None:
        code = '```python\nx = """\nunclosed string\n```'
        result = validator.validate(code, expected_language="python")
        assert any("triple-quote" in i.message.lower() for i in result.issues)

    def test_javascript_unclosed_template(self, validator: ResponseValidator) -> None:
        code = "```js\nconst x = `unclosed template\n```"
        result = validator.validate(code, expected_language="js")
        assert any("template literal" in i.message.lower() for i in result.issues)

    def test_clean_python_code(self, validator: ResponseValidator) -> None:
        code = "```python\ndef add(a, b):\n    return a + b\n```"
        result = validator.validate(code, expected_language="python")
        syntax_issues = [
            i for i in result.issues if i.validation_type == ValidationType.CODE_SYNTAX
        ]
        assert len(syntax_issues) == 0


# ---------------------------------------------------------------------------
# Content safety
# ---------------------------------------------------------------------------


class TestContentSafety:
    """Tests for PII and secret detection."""

    def test_email_detection(self, validator: ResponseValidator) -> None:
        result = validator.validate("Contact me at john@example.com for details.")
        assert any("email" in i.message.lower() for i in result.issues)

    def test_phone_detection(self, validator: ResponseValidator) -> None:
        result = validator.validate("Call me at 555-123-4567.")
        assert any("phone" in i.message.lower() for i in result.issues)

    def test_ssn_detection(self, validator: ResponseValidator) -> None:
        result = validator.validate("SSN: 123-45-6789")
        assert any("ssn" in i.message.lower() for i in result.issues)

    def test_aws_key_detection(self, validator: ResponseValidator) -> None:
        result = validator.validate("Use key AKIAIOSFODNN7EXAMPLE for access.")
        assert any(
            i.severity == ValidationSeverity.ERROR
            and i.validation_type == ValidationType.CONTENT_SAFETY
            for i in result.issues
        )

    def test_github_token_detection(self, validator: ResponseValidator) -> None:
        result = validator.validate("Token: ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx1234")
        assert any(
            i.validation_type == ValidationType.CONTENT_SAFETY for i in result.issues
        )

    def test_private_key_detection(self, validator: ResponseValidator) -> None:
        result = validator.validate("-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAK...")
        assert any(
            i.validation_type == ValidationType.CONTENT_SAFETY for i in result.issues
        )

    def test_pii_check_disabled(self) -> None:
        v = ResponseValidator(check_pii=False)
        result = v.validate("Contact john@example.com")
        pii_issues = [
            i for i in result.issues
            if i.validation_type == ValidationType.CONTENT_SAFETY
            and i.severity == ValidationSeverity.WARNING
        ]
        assert len(pii_issues) == 0

    def test_clean_response(self, validator: ResponseValidator) -> None:
        result = validator.validate(
            "Here is a function that adds two numbers and returns the result."
        )
        safety_issues = [
            i for i in result.issues if i.validation_type == ValidationType.CONTENT_SAFETY
        ]
        assert len(safety_issues) == 0


# ---------------------------------------------------------------------------
# JSON extraction
# ---------------------------------------------------------------------------


class TestJSONExtraction:
    """Tests for extracting JSON from responses."""

    def test_direct_json(self, validator: ResponseValidator) -> None:
        parsed, issues = validator.extract_json('{"key": "value"}')
        assert parsed == {"key": "value"}
        assert len(issues) == 0

    def test_json_in_code_block(self, validator: ResponseValidator) -> None:
        parsed, issues = validator.extract_json(
            'Here is the result:\n```json\n{"key": "value"}\n```'
        )
        assert parsed == {"key": "value"}

    def test_json_embedded_in_text(self, validator: ResponseValidator) -> None:
        parsed, issues = validator.extract_json(
            'The result is {"key": "value"} as expected.'
        )
        assert parsed is not None
        assert parsed["key"] == "value"

    def test_no_json_found(self, validator: ResponseValidator) -> None:
        parsed, issues = validator.extract_json("No JSON here at all!")
        assert parsed is None
        assert len(issues) > 0

    def test_array_extraction(self, validator: ResponseValidator) -> None:
        parsed, issues = validator.extract_json("Result: [1, 2, 3]")
        assert parsed == [1, 2, 3]


# ---------------------------------------------------------------------------
# Code block extraction
# ---------------------------------------------------------------------------


class TestCodeBlockExtraction:
    """Tests for extracting code blocks."""

    def test_single_block(self, validator: ResponseValidator) -> None:
        blocks = validator.extract_code_blocks(
            "```python\nprint('hello')\n```"
        )
        assert len(blocks) == 1
        assert blocks[0]["language"] == "python"
        assert "print" in blocks[0]["code"]

    def test_multiple_blocks(self, validator: ResponseValidator) -> None:
        blocks = validator.extract_code_blocks(
            "```python\nx = 1\n```\nSome text\n```javascript\nlet y = 2\n```"
        )
        assert len(blocks) == 2

    def test_no_blocks(self, validator: ResponseValidator) -> None:
        blocks = validator.extract_code_blocks("No code here.")
        assert len(blocks) == 0

    def test_unnamed_block(self, validator: ResponseValidator) -> None:
        blocks = validator.extract_code_blocks("```\nsome code\n```")
        assert len(blocks) == 1
        assert blocks[0]["language"] == "unknown"


# ---------------------------------------------------------------------------
# Repair
# ---------------------------------------------------------------------------


class TestRepair:
    """Tests for response repair functionality."""

    def test_repair_redacts_secrets(self, validator: ResponseValidator) -> None:
        issues = [
            ValidationIssue(
                severity=ValidationSeverity.ERROR,
                validation_type=ValidationType.CONTENT_SAFETY,
                message="Secret detected",
            ),
        ]
        repaired = validator.repair(
            "Key: AKIAIOSFODNN7EXAMPLE is secret",
            issues,
        )
        assert "AKIAIOSFODNN7EXAMPLE" not in repaired
        assert "[REDACTED]" in repaired

    def test_repair_fixes_trailing_comma_json(self, validator: ResponseValidator) -> None:
        issues = [
            ValidationIssue(
                severity=ValidationSeverity.ERROR,
                validation_type=ValidationType.JSON_SCHEMA,
                message="Invalid JSON",
            ),
        ]
        repaired = validator.repair('{"a": 1, "b": 2,}', issues)
        parsed = json.loads(repaired)
        assert parsed["a"] == 1

    def test_repair_extracts_json_from_markdown(self, validator: ResponseValidator) -> None:
        issues = [
            ValidationIssue(
                severity=ValidationSeverity.ERROR,
                validation_type=ValidationType.FORMAT,
                message="Expected JSON",
            ),
        ]
        repaired = validator.repair(
            'Here:\n```json\n{"key": "value"}\n```',
            issues,
        )
        parsed = json.loads(repaired)
        assert parsed["key"] == "value"


# ---------------------------------------------------------------------------
# Score calculation
# ---------------------------------------------------------------------------


class TestScoring:
    """Tests for validation score calculation."""

    def test_perfect_score(self, validator: ResponseValidator) -> None:
        result = validator.validate("A perfectly fine response.")
        assert result.score == 1.0

    def test_errors_reduce_score(self, validator: ResponseValidator) -> None:
        result = validator.validate("", expected_format="json")
        assert result.score < 1.0

    def test_score_never_negative(self, validator: ResponseValidator) -> None:
        # Many issues should still keep score >= 0
        result = validator.validate(
            "AKIAIOSFODNN7EXAMPLE ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx1234 "
            "john@example.com 555-123-4567 123-45-6789 "
            "-----BEGIN RSA PRIVATE KEY----- [truncated]",
        )
        assert result.score >= 0.0

    def test_metadata_populated(self, validator: ResponseValidator) -> None:
        result = validator.validate("Some text")
        assert "response_length" in result.metadata
        assert "issue_count" in result.metadata


# ---------------------------------------------------------------------------
# Bracket validation
# ---------------------------------------------------------------------------


class TestBracketValidation:
    """Tests for bracket balancing checks."""

    def test_balanced_brackets(self, validator: ResponseValidator) -> None:
        code = "def foo():\n    return {'a': [1, 2, (3,)]}\n"
        result = validator.validate(code, expected_language="python")
        bracket_issues = [
            i for i in result.issues
            if "bracket" in i.message.lower() and i.validation_type == ValidationType.CODE_SYNTAX
        ]
        assert len(bracket_issues) == 0

    def test_unclosed_brace_in_code(self, validator: ResponseValidator) -> None:
        code = "```python\ndef foo():\n    return {\n        'a': 1,\n        'b': 2\n```"
        result = validator.validate(code, expected_language="python")
        # May detect unclosed bracket
        # Note: code blocks are parsed, so the { may be detected
        assert isinstance(result, ValidationResult)
