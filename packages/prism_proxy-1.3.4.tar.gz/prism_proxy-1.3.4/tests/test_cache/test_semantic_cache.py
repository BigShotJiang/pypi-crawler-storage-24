"""Tests for semantic fuzzy cache with SimHash."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from prism.cache.semantic_cache import (
    SemanticCache,
    compute_simhash,
    hamming_distance,
    text_similarity,
)


class TestSimHash:
    """Tests for the SimHash algorithm."""

    def test_identical_text_same_hash(self) -> None:
        text = "how do I implement a binary search in Python"
        assert compute_simhash(text) == compute_simhash(text)

    def test_similar_text_low_hamming_distance(self) -> None:
        a = "how do I implement a binary search in Python"
        b = "how do I implement binary search in Python code"
        dist = hamming_distance(compute_simhash(a), compute_simhash(b))
        assert dist <= 20  # Similar texts should have lower Hamming distance

    def test_different_text_high_hamming_distance(self) -> None:
        a = "how do I implement a binary search in Python"
        b = "what is the weather forecast for tomorrow in New York"
        dist = hamming_distance(compute_simhash(a), compute_simhash(b))
        assert dist >= 20  # Very different texts should diverge more

    def test_empty_text(self) -> None:
        assert compute_simhash("") == 0

    def test_single_word(self) -> None:
        h = compute_simhash("hello")
        assert isinstance(h, int)
        assert h >= 0


class TestHammingDistance:
    """Tests for Hamming distance calculation."""

    def test_identical(self) -> None:
        assert hamming_distance(42, 42) == 0

    def test_one_bit_diff(self) -> None:
        assert hamming_distance(0b1000, 0b1001) == 1

    def test_all_bits_diff(self) -> None:
        # 64-bit all zeros vs all ones
        assert hamming_distance(0, (1 << 64) - 1) == 64


class TestTextSimilarity:
    """Tests for Jaccard text similarity."""

    def test_identical(self) -> None:
        assert text_similarity("hello world", "hello world") == 1.0

    def test_no_overlap(self) -> None:
        assert text_similarity("hello world", "foo bar") == 0.0

    def test_partial_overlap(self) -> None:
        sim = text_similarity("hello world foo", "hello world bar")
        assert 0.3 < sim < 0.8

    def test_empty_both(self) -> None:
        assert text_similarity("", "") == 1.0

    def test_empty_one(self) -> None:
        assert text_similarity("hello", "") == 0.0


class TestSemanticCache:
    """Tests for the SemanticCache class."""

    @pytest.fixture()
    def cache(self, tmp_path: Path) -> SemanticCache:
        return SemanticCache(
            cache_dir=tmp_path,
            hamming_threshold=28,
            text_similarity_threshold=0.4,
            max_entries=100,
            ttl=3600,
        )

    def test_put_and_exact_get(self, cache: SemanticCache) -> None:
        """Store and retrieve the exact same prompt."""
        prompt = "how do I sort a list in Python"
        cache.put(
            prompt=prompt,
            exact_key="abc123",
            model="gpt-4o-mini",
            content="Use sorted() or .sort()",
            cost_usd=0.001,
        )
        result = cache.get(prompt)
        assert result is not None
        assert result.content == "Use sorted() or .sort()"
        assert result.model == "gpt-4o-mini"

    def test_similar_prompt_hits(self, cache: SemanticCache) -> None:
        """A similar prompt should hit the cache."""
        cache.put(
            prompt="how do I sort a list in Python",
            exact_key="abc123",
            model="gpt-4o-mini",
            content="Use sorted() or .sort()",
            cost_usd=0.001,
        )
        # Similar but not identical
        result = cache.get("how to sort a list in Python code")
        assert result is not None
        assert "sorted" in result.content

    def test_different_prompt_misses(self, cache: SemanticCache) -> None:
        """A very different prompt should miss."""
        cache.put(
            prompt="how do I sort a list in Python",
            exact_key="abc123",
            model="gpt-4o-mini",
            content="Use sorted()",
            cost_usd=0.001,
        )
        result = cache.get("what is the capital of France")
        assert result is None

    def test_model_filter(self, cache: SemanticCache) -> None:
        """Model filter should restrict matches."""
        cache.put(
            prompt="how do I sort a list",
            exact_key="abc",
            model="gpt-4o-mini",
            content="answer",
            cost_usd=0.001,
        )
        # Same prompt but filtering for a different model
        result = cache.get("how do I sort a list", model="claude-sonnet-4-20250514")
        assert result is None

    def test_clear(self, cache: SemanticCache) -> None:
        cache.put(prompt="test", exact_key="k", model="m", content="c", cost_usd=0.0)
        deleted = cache.clear()
        assert deleted >= 1
        assert cache.get("test") is None

    def test_stats(self, cache: SemanticCache) -> None:
        cache.put(prompt="test", exact_key="k", model="m", content="c", cost_usd=0.01)
        cache.get("test")  # hit
        cache.get("totally different query about weather")  # miss
        stats = cache.get_stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["entries"] == 1

    def test_eviction(self, tmp_path: Path) -> None:
        """Cache should evict oldest entries when full."""
        cache = SemanticCache(
            cache_dir=tmp_path,
            max_entries=5,
            ttl=3600,
        )
        for i in range(10):
            cache.put(
                prompt=f"unique prompt number {i} about topic {i * 7}",
                exact_key=f"key{i}",
                model="m",
                content=f"answer{i}",
                cost_usd=0.0,
            )
        stats = cache.get_stats()
        assert stats["entries"] <= 6  # After eviction

    def test_close(self, cache: SemanticCache) -> None:
        cache.put(prompt="test", exact_key="k", model="m", content="c", cost_usd=0.0)
        cache.get("test")
        cache.close()  # Should not raise
