"""Tests for the input sanitizer."""

from __future__ import annotations

import pytest

from prism.security.input_sanitizer import (
    InputSanitizer,
    IssueType,
    SanitizationResult,
    SanitizerConfig,
)


@pytest.fixture()
def sanitizer() -> InputSanitizer:
    return InputSanitizer()


# ---------------------------------------------------------------------------
# Basic sanitization
# ---------------------------------------------------------------------------


class TestBasicSanitization:
    """Tests for basic input sanitization."""

    def test_clean_input_unchanged(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("Hello, world!")
        assert result.clean_text == "Hello, world!"
        assert result.is_safe

    def test_empty_input(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("")
        assert result.clean_text == ""
        assert result.is_safe

    def test_result_structure(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("test")
        assert isinstance(result, SanitizationResult)
        assert result.original_text == "test"

    def test_is_safe_helper(self, sanitizer: InputSanitizer) -> None:
        assert sanitizer.is_safe("Hello, world!")
        assert not sanitizer.is_safe("../../../etc/passwd")


# ---------------------------------------------------------------------------
# Null bytes
# ---------------------------------------------------------------------------


class TestNullBytes:
    """Tests for null byte handling."""

    def test_null_bytes_removed(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("hello\x00world")
        assert result.clean_text == "helloworld"
        assert not result.is_safe

    def test_null_byte_critical(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("test\x00")
        assert result.has_critical
        assert any(i.issue_type == IssueType.NULL_BYTES for i in result.issues)


# ---------------------------------------------------------------------------
# Control characters
# ---------------------------------------------------------------------------


class TestControlChars:
    """Tests for control character stripping."""

    def test_control_chars_stripped(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("hello\x01world")
        assert result.clean_text == "helloworld"
        assert any(i.issue_type == IssueType.CONTROL_CHARS for i in result.issues)

    def test_tab_preserved(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("hello\tworld")
        assert "\t" in result.clean_text

    def test_newline_preserved(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("hello\nworld")
        assert "\n" in result.clean_text


# ---------------------------------------------------------------------------
# Path traversal
# ---------------------------------------------------------------------------


class TestPathTraversal:
    """Tests for path traversal detection."""

    def test_unix_path_traversal(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("../../etc/passwd")
        assert not result.is_safe
        assert any(i.issue_type == IssueType.PATH_TRAVERSAL for i in result.issues)

    def test_windows_path_traversal(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("..\\..\\windows\\system32")
        assert any(i.issue_type == IssueType.PATH_TRAVERSAL for i in result.issues)

    def test_normal_path_safe(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("src/prism/main.py")
        path_issues = [i for i in result.issues if i.issue_type == IssueType.PATH_TRAVERSAL]
        assert len(path_issues) == 0


# ---------------------------------------------------------------------------
# Shell metacharacters
# ---------------------------------------------------------------------------


class TestShellMeta:
    """Tests for shell metacharacter detection."""

    def test_semicolon_detected(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("ls; rm -rf /")
        assert any(i.issue_type == IssueType.SHELL_METACHAR for i in result.issues)

    def test_pipe_detected(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("cat file | grep secret")
        assert any(i.issue_type == IssueType.SHELL_METACHAR for i in result.issues)

    def test_backtick_detected(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("echo `whoami`")
        assert any(i.issue_type == IssueType.SHELL_METACHAR for i in result.issues)

    def test_plain_text_safe(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("Hello world, this is fine.")
        shell_issues = [i for i in result.issues if i.issue_type == IssueType.SHELL_METACHAR]
        assert len(shell_issues) == 0


# ---------------------------------------------------------------------------
# SQL injection
# ---------------------------------------------------------------------------


class TestSQLInjection:
    """Tests for SQL injection detection."""

    def test_or_injection(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("' OR '1'='1")
        assert any(i.issue_type == IssueType.SQL_INJECTION for i in result.issues)

    def test_union_select(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("UNION SELECT * FROM users")
        assert any(i.issue_type == IssueType.SQL_INJECTION for i in result.issues)

    def test_drop_table(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("DROP TABLE users")
        assert any(i.issue_type == IssueType.SQL_INJECTION for i in result.issues)

    def test_comment_injection(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("admin'; --")
        assert any(i.issue_type == IssueType.SQL_INJECTION for i in result.issues)

    def test_normal_sql_words_safe(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("Please select the best option from the table")
        sql_issues = [i for i in result.issues if i.issue_type == IssueType.SQL_INJECTION]
        assert len(sql_issues) == 0


# ---------------------------------------------------------------------------
# XSS
# ---------------------------------------------------------------------------


class TestXSS:
    """Tests for XSS pattern detection."""

    def test_script_tag(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("<script>alert('xss')</script>")
        assert any(i.issue_type == IssueType.XSS_PATTERN for i in result.issues)

    def test_javascript_uri(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("javascript: alert(1)")
        assert any(i.issue_type == IssueType.XSS_PATTERN for i in result.issues)

    def test_event_handler(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize('<img onerror="alert(1)">')
        assert any(i.issue_type == IssueType.XSS_PATTERN for i in result.issues)

    def test_iframe(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize('<iframe src="evil.com">')
        assert any(i.issue_type == IssueType.XSS_PATTERN for i in result.issues)

    def test_normal_html_mention_safe(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("Use <b> tags for bold text")
        xss_issues = [i for i in result.issues if i.issue_type == IssueType.XSS_PATTERN]
        assert len(xss_issues) == 0


# ---------------------------------------------------------------------------
# Invisible characters
# ---------------------------------------------------------------------------


class TestInvisibleChars:
    """Tests for invisible Unicode character removal."""

    def test_zero_width_space(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("hello\u200bworld")
        assert result.clean_text == "helloworld"
        assert any(i.issue_type == IssueType.INVISIBLE_CHARS for i in result.issues)

    def test_bidi_override(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("hello\u202eworld")
        assert "\u202e" not in result.clean_text

    def test_bom_removed(self, sanitizer: InputSanitizer) -> None:
        result = sanitizer.sanitize("\ufeffhello")
        assert result.clean_text == "hello"


# ---------------------------------------------------------------------------
# Length enforcement
# ---------------------------------------------------------------------------


class TestLengthEnforcement:
    """Tests for max length enforcement."""

    def test_long_input_truncated(self) -> None:
        sanitizer = InputSanitizer(SanitizerConfig(max_length=10))
        result = sanitizer.sanitize("a" * 100)
        assert len(result.clean_text) == 10
        assert any(i.issue_type == IssueType.EXCESSIVE_LENGTH for i in result.issues)

    def test_short_input_unchanged(self) -> None:
        sanitizer = InputSanitizer(SanitizerConfig(max_length=100))
        result = sanitizer.sanitize("hello")
        assert result.clean_text == "hello"

    def test_unlimited_length(self) -> None:
        sanitizer = InputSanitizer(SanitizerConfig(max_length=0))
        long_text = "a" * 200000
        result = sanitizer.sanitize(long_text)
        assert len(result.clean_text) == 200000


# ---------------------------------------------------------------------------
# Batch sanitization
# ---------------------------------------------------------------------------


class TestBatchSanitization:
    """Tests for message array sanitization."""

    def test_sanitize_messages(self, sanitizer: InputSanitizer) -> None:
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi\x00there"},
        ]
        results = sanitizer.sanitize_messages(messages)
        assert len(results) == 2
        assert results[0].is_safe
        assert not results[1].is_safe


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class TestConfiguration:
    """Tests for configurable detection."""

    def test_disable_path_traversal(self) -> None:
        s = InputSanitizer(SanitizerConfig(detect_path_traversal=False))
        result = s.sanitize("../../etc/passwd")
        path_issues = [i for i in result.issues if i.issue_type == IssueType.PATH_TRAVERSAL]
        assert len(path_issues) == 0

    def test_disable_sql_detection(self) -> None:
        s = InputSanitizer(SanitizerConfig(detect_sql_injection=False))
        result = s.sanitize("DROP TABLE users")
        sql_issues = [i for i in result.issues if i.issue_type == IssueType.SQL_INJECTION]
        assert len(sql_issues) == 0

    def test_disable_xss_detection(self) -> None:
        s = InputSanitizer(SanitizerConfig(detect_xss=False))
        result = s.sanitize("<script>alert(1)</script>")
        xss_issues = [i for i in result.issues if i.issue_type == IssueType.XSS_PATTERN]
        assert len(xss_issues) == 0


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------


class TestStatistics:
    """Tests for sanitizer statistics."""

    def test_stats_tracked(self, sanitizer: InputSanitizer) -> None:
        sanitizer.sanitize("hello")
        sanitizer.sanitize("world\x00")
        stats = sanitizer.get_stats()
        assert stats["total_sanitized"] == 2
        assert stats["total_issues"] >= 1
        assert stats["total_critical"] >= 1
