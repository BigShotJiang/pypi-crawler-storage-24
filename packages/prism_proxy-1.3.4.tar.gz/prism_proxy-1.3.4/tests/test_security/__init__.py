"""Security module tests."""
