"""Tests for the token bucket rate limiter."""

from __future__ import annotations

import time

import pytest

from prism.security.rate_limiter import (
    RateLimiter,
    RateLimitConfig,
    RateLimitStatus,
)


@pytest.fixture()
def limiter() -> RateLimiter:
    return RateLimiter()


# ---------------------------------------------------------------------------
# Configuration tests
# ---------------------------------------------------------------------------


class TestConfiguration:
    """Tests for rate limiter configuration."""

    def test_default_providers_configured(self, limiter: RateLimiter) -> None:
        status = limiter.get_status("openai")
        assert status.rpm_capacity > 0

    def test_custom_configuration(self, limiter: RateLimiter) -> None:
        limiter.configure("custom", rpm=100, tpm=50000)
        status = limiter.get_status("custom")
        assert status.rpm_capacity > 0
        assert status.tpm_capacity > 0

    def test_unconfigured_provider(self, limiter: RateLimiter) -> None:
        status = limiter.get_status("nonexistent")
        assert status.rpm_capacity == 0
        assert not status.is_limited

    def test_burst_multiplier(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=100, tpm=10000, burst_multiplier=2.0)
        status = limiter.get_status("test")
        assert status.rpm_capacity == 200.0  # 100 * 2.0


# ---------------------------------------------------------------------------
# Acquire/release tests
# ---------------------------------------------------------------------------


class TestAcquireRelease:
    """Tests for acquiring and releasing rate limit tokens."""

    def test_acquire_succeeds(self, limiter: RateLimiter) -> None:
        assert limiter.acquire("openai", tokens=100)

    def test_acquire_unconfigured_succeeds(self, limiter: RateLimiter) -> None:
        assert limiter.acquire("unknown_provider")

    def test_acquire_reduces_tokens(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=10, tpm=1000, burst_multiplier=1.0)
        before = limiter.get_status("test")
        limiter.acquire("test", tokens=100)
        after = limiter.get_status("test")
        assert after.rpm_available < before.rpm_available
        assert after.tpm_available < before.tpm_available

    def test_rpm_exhaustion(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=3, tpm=100000, burst_multiplier=1.0)
        assert limiter.acquire("test")
        assert limiter.acquire("test")
        assert limiter.acquire("test")
        assert not limiter.acquire("test")  # RPM exhausted

    def test_tpm_exhaustion(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=1000, tpm=100, burst_multiplier=1.0)
        assert limiter.acquire("test", tokens=100)
        assert not limiter.acquire("test", tokens=50)  # TPM exhausted

    def test_concurrent_limit(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=100, tpm=100000, max_concurrent=2)
        assert limiter.acquire("test")
        assert limiter.acquire("test")
        assert not limiter.acquire("test")  # Concurrent limit

    def test_release_frees_slot(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=100, tpm=100000, max_concurrent=1)
        assert limiter.acquire("test")
        assert not limiter.acquire("test")
        limiter.release("test")
        assert limiter.acquire("test")

    def test_release_nonexistent(self, limiter: RateLimiter) -> None:
        limiter.release("nonexistent")  # Should not raise


# ---------------------------------------------------------------------------
# Rate limit response handling
# ---------------------------------------------------------------------------


class TestRateLimitHandling:
    """Tests for 429 response handling."""

    def test_backoff_applied(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=100, tpm=100000)
        limiter.record_rate_limit("test", retry_after=10)
        assert not limiter.acquire("test")

    def test_capacity_reduced(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=100, tpm=100000, burst_multiplier=1.0)
        before = limiter.get_status("test")
        limiter.record_rate_limit("test")
        after = limiter.get_status("test")
        assert after.rpm_capacity < before.rpm_capacity


# ---------------------------------------------------------------------------
# Status and query tests
# ---------------------------------------------------------------------------


class TestStatus:
    """Tests for status querying."""

    def test_status_structure(self, limiter: RateLimiter) -> None:
        status = limiter.get_status("openai")
        assert isinstance(status, RateLimitStatus)
        assert status.name == "openai"

    def test_utilization_increases(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=10, tpm=10000, burst_multiplier=1.0)
        before = limiter.get_status("test")
        for _ in range(5):
            limiter.acquire("test", tokens=100)
        after = limiter.get_status("test")
        assert after.utilization_pct > before.utilization_pct

    def test_all_status(self, limiter: RateLimiter) -> None:
        all_status = limiter.get_all_status()
        assert "openai" in all_status
        assert "anthropic" in all_status

    def test_time_until_available_when_free(self, limiter: RateLimiter) -> None:
        wait = limiter.time_until_available("openai", tokens=100)
        assert wait == 0.0

    def test_time_until_available_when_exhausted(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=1, tpm=100000, burst_multiplier=1.0)
        limiter.acquire("test")
        wait = limiter.time_until_available("test")
        assert wait > 0

    def test_time_until_available_unconfigured(self, limiter: RateLimiter) -> None:
        assert limiter.time_until_available("unknown") == 0.0


# ---------------------------------------------------------------------------
# Least loaded selection
# ---------------------------------------------------------------------------


class TestLeastLoaded:
    """Tests for least-loaded provider selection."""

    def test_least_loaded_basic(self, limiter: RateLimiter) -> None:
        result = limiter.get_least_loaded(["openai", "anthropic", "google"])
        assert result is not None
        assert result in ("openai", "anthropic", "google")

    def test_least_loaded_prefers_unused(self, limiter: RateLimiter) -> None:
        limiter.configure("busy", rpm=3, tpm=100000, burst_multiplier=1.0)
        limiter.configure("free", rpm=100, tpm=100000, burst_multiplier=1.0)
        for _ in range(3):
            limiter.acquire("busy")
        result = limiter.get_least_loaded(["busy", "free"])
        assert result == "free"

    def test_least_loaded_all_limited(self, limiter: RateLimiter) -> None:
        limiter.configure("a", rpm=1, tpm=100000, burst_multiplier=1.0)
        limiter.configure("b", rpm=1, tpm=100000, burst_multiplier=1.0)
        limiter.acquire("a")
        limiter.acquire("b")
        result = limiter.get_least_loaded(["a", "b"])
        # Both exhausted RPM — may return None
        # Note: depends on exact refill timing, just check type
        assert result is None or isinstance(result, str)

    def test_least_loaded_empty_list(self, limiter: RateLimiter) -> None:
        assert limiter.get_least_loaded([]) is None


# ---------------------------------------------------------------------------
# Reset tests
# ---------------------------------------------------------------------------


class TestReset:
    """Tests for resetting rate limit state."""

    def test_reset_specific(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=3, tpm=100000, burst_multiplier=1.0)
        limiter.acquire("test")
        limiter.acquire("test")
        limiter.reset("test")
        status = limiter.get_status("test")
        assert status.rpm_available > 2  # Should be refilled

    def test_reset_clears_backoff(self, limiter: RateLimiter) -> None:
        limiter.configure("test", rpm=100, tpm=100000)
        limiter.record_rate_limit("test", retry_after=60)
        assert not limiter.acquire("test")
        limiter.reset("test")
        assert limiter.acquire("test")

    def test_reset_all(self, limiter: RateLimiter) -> None:
        for provider in ("openai", "anthropic"):
            limiter.record_rate_limit(provider, retry_after=60)
        limiter.reset()
        assert limiter.acquire("openai")
        assert limiter.acquire("anthropic")
