"""Tests for the Anthropic ↔ OpenAI message translator."""

from __future__ import annotations

import json

import pytest

from prism.proxy.translator import (
    anthropic_to_openai_messages,
    build_anthropic_response,
    build_anthropic_stream_events,
    openai_tool_calls_to_anthropic,
)


# ---------------------------------------------------------------------------
# anthropic_to_openai_messages
# ---------------------------------------------------------------------------


class TestAnthropicToOpenAI:
    """Tests for converting Anthropic messages to OpenAI format."""

    def test_simple_user_message(self) -> None:
        messages = [{"role": "user", "content": "Hello"}]
        result = anthropic_to_openai_messages(messages)
        assert result == [{"role": "user", "content": "Hello"}]

    def test_system_string(self) -> None:
        messages = [{"role": "user", "content": "Hi"}]
        result = anthropic_to_openai_messages(messages, system="You are helpful.")
        assert result[0] == {"role": "system", "content": "You are helpful."}
        assert result[1] == {"role": "user", "content": "Hi"}

    def test_system_content_blocks(self) -> None:
        system = [{"type": "text", "text": "Part 1"}, {"type": "text", "text": "Part 2"}]
        messages = [{"role": "user", "content": "Hi"}]
        result = anthropic_to_openai_messages(messages, system=system)
        assert result[0]["role"] == "system"
        assert "Part 1" in result[0]["content"]
        assert "Part 2" in result[0]["content"]

    def test_assistant_string_content(self) -> None:
        messages = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello!"},
        ]
        result = anthropic_to_openai_messages(messages)
        assert result[1] == {"role": "assistant", "content": "Hello!"}

    def test_user_content_blocks(self) -> None:
        messages = [{
            "role": "user",
            "content": [
                {"type": "text", "text": "Look at this"},
                {"type": "text", "text": "and this"},
            ],
        }]
        result = anthropic_to_openai_messages(messages)
        assert result[0]["role"] == "user"
        assert "Look at this" in result[0]["content"]
        assert "and this" in result[0]["content"]

    def test_tool_result_in_user_message(self) -> None:
        """Anthropic sends tool results as content blocks in user messages."""
        messages = [{
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu_123",
                    "content": "File contents here",
                },
            ],
        }]
        result = anthropic_to_openai_messages(messages)
        # Should produce a tool role message
        tool_msg = [m for m in result if m.get("role") == "tool"]
        assert len(tool_msg) == 1
        assert tool_msg[0]["tool_call_id"] == "toolu_123"
        assert tool_msg[0]["content"] == "File contents here"

    def test_assistant_with_tool_use(self) -> None:
        """Anthropic tool_use blocks → OpenAI tool_calls."""
        messages = [{
            "role": "assistant",
            "content": [
                {"type": "text", "text": "Let me read that."},
                {
                    "type": "tool_use",
                    "id": "toolu_abc",
                    "name": "read_file",
                    "input": {"path": "main.py"},
                },
            ],
        }]
        result = anthropic_to_openai_messages(messages)
        assert result[0]["role"] == "assistant"
        assert result[0]["content"] == "Let me read that."
        assert len(result[0]["tool_calls"]) == 1
        tc = result[0]["tool_calls"][0]
        assert tc["id"] == "toolu_abc"
        assert tc["function"]["name"] == "read_file"
        assert json.loads(tc["function"]["arguments"]) == {"path": "main.py"}

    def test_multi_turn_conversation(self) -> None:
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
            {"role": "user", "content": "How are you?"},
            {"role": "assistant", "content": "I'm good!"},
        ]
        result = anthropic_to_openai_messages(messages)
        assert len(result) == 4
        assert [m["role"] for m in result] == [
            "user", "assistant", "user", "assistant",
        ]

    def test_empty_messages(self) -> None:
        result = anthropic_to_openai_messages([])
        assert result == []

    def test_empty_system(self) -> None:
        messages = [{"role": "user", "content": "Hi"}]
        result = anthropic_to_openai_messages(messages, system="")
        assert len(result) == 1
        assert result[0]["role"] == "user"

    def test_tool_result_with_content_blocks(self) -> None:
        """Tool result content can itself be a list of blocks."""
        messages = [{
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu_456",
                    "content": [
                        {"type": "text", "text": "line 1"},
                        {"type": "text", "text": "line 2"},
                    ],
                },
            ],
        }]
        result = anthropic_to_openai_messages(messages)
        tool_msg = [m for m in result if m.get("role") == "tool"]
        assert len(tool_msg) == 1
        assert "line 1" in tool_msg[0]["content"]
        assert "line 2" in tool_msg[0]["content"]


# ---------------------------------------------------------------------------
# build_anthropic_response
# ---------------------------------------------------------------------------


class TestBuildAnthropicResponse:
    """Tests for building Anthropic-format responses."""

    def test_simple_text(self) -> None:
        resp = build_anthropic_response(
            content="Hello!", model="gpt-4o", input_tokens=10, output_tokens=5
        )
        assert resp["type"] == "message"
        assert resp["role"] == "assistant"
        assert resp["content"][0]["type"] == "text"
        assert resp["content"][0]["text"] == "Hello!"
        assert resp["stop_reason"] == "end_turn"
        assert resp["usage"]["input_tokens"] == 10
        assert resp["usage"]["output_tokens"] == 5

    def test_with_tool_calls(self) -> None:
        tool_calls = [{
            "type": "tool_use",
            "id": "toolu_123",
            "name": "read_file",
            "input": {"path": "x.py"},
        }]
        resp = build_anthropic_response(
            content="Reading file.", model="gpt-4o",
            tool_calls=tool_calls,
        )
        assert resp["stop_reason"] == "tool_use"
        assert len(resp["content"]) == 2
        assert resp["content"][0]["type"] == "text"
        assert resp["content"][1]["type"] == "tool_use"

    def test_empty_content(self) -> None:
        resp = build_anthropic_response(content="", model="test")
        assert resp["content"] == []
        assert resp["stop_reason"] == "end_turn"

    def test_message_id_format(self) -> None:
        resp = build_anthropic_response(content="Hi", model="test")
        assert resp["id"].startswith("msg_")

    def test_max_tokens_stop_reason(self) -> None:
        resp = build_anthropic_response(
            content="Cut off", model="test", finish_reason="length"
        )
        assert resp["stop_reason"] == "max_tokens"


# ---------------------------------------------------------------------------
# openai_tool_calls_to_anthropic
# ---------------------------------------------------------------------------


class TestToolCallConversion:
    """Tests for OpenAI → Anthropic tool call conversion."""

    def test_single_tool_call(self) -> None:
        tc = [{
            "id": "call_123",
            "type": "function",
            "function": {
                "name": "read_file",
                "arguments": '{"path": "main.py"}',
            },
        }]
        result = openai_tool_calls_to_anthropic(tc)
        assert len(result) == 1
        assert result[0]["type"] == "tool_use"
        assert result[0]["name"] == "read_file"
        assert result[0]["input"] == {"path": "main.py"}
        assert result[0]["id"].startswith("toolu_")

    def test_multiple_tool_calls(self) -> None:
        tcs = [
            {
                "id": "call_1",
                "type": "function",
                "function": {"name": "read_file", "arguments": '{"path": "a.py"}'},
            },
            {
                "id": "call_2",
                "type": "function",
                "function": {"name": "read_file", "arguments": '{"path": "b.py"}'},
            },
        ]
        result = openai_tool_calls_to_anthropic(tcs)
        assert len(result) == 2
        assert result[0]["name"] == "read_file"
        assert result[1]["name"] == "read_file"

    def test_invalid_json_arguments(self) -> None:
        tc = [{
            "id": "call_bad",
            "type": "function",
            "function": {"name": "test", "arguments": "not json"},
        }]
        result = openai_tool_calls_to_anthropic(tc)
        assert result[0]["input"] == {}

    def test_id_prefix(self) -> None:
        """IDs should always start with toolu_."""
        tc = [{
            "id": "toolu_already",
            "type": "function",
            "function": {"name": "test", "arguments": "{}"},
        }]
        result = openai_tool_calls_to_anthropic(tc)
        assert result[0]["id"] == "toolu_already"

        tc2 = [{
            "id": "call_123",
            "type": "function",
            "function": {"name": "test", "arguments": "{}"},
        }]
        result2 = openai_tool_calls_to_anthropic(tc2)
        assert result2[0]["id"].startswith("toolu_")


# ---------------------------------------------------------------------------
# build_anthropic_stream_events
# ---------------------------------------------------------------------------


class TestStreamEvents:
    """Tests for SSE event generation."""

    def test_text_only_events(self) -> None:
        events = build_anthropic_stream_events(
            content="Hello!", model="test",
            input_tokens=10, output_tokens=5,
        )
        event_types = [e[0] for e in events]
        assert "message_start" in event_types
        assert "content_block_start" in event_types
        assert "content_block_delta" in event_types
        assert "content_block_stop" in event_types
        assert "message_delta" in event_types
        assert "message_stop" in event_types

    def test_stream_with_tool_calls(self) -> None:
        tc = [{
            "id": "call_1",
            "type": "function",
            "function": {"name": "read_file", "arguments": '{"path": "x"}'},
        }]
        events = build_anthropic_stream_events(
            content="Reading.", model="test", tool_calls=tc,
        )
        # Should have message_delta with tool_use stop reason
        delta_events = [e for e in events if e[0] == "message_delta"]
        assert delta_events[0][1]["delta"]["stop_reason"] == "tool_use"

    def test_empty_content_events(self) -> None:
        events = build_anthropic_stream_events(content="", model="test")
        # No content blocks for empty content
        event_types = [e[0] for e in events]
        assert "message_start" in event_types
        assert "message_stop" in event_types
        assert "content_block_delta" not in event_types
