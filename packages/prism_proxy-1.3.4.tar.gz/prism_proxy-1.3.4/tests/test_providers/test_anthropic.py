"""Tests for the Anthropic provider module."""

from __future__ import annotations

import pytest

from prism.providers.anthropic import (
    AnthropicConfig,
    AnthropicModel,
    AnthropicProvider,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> AnthropicProvider:
    """Provider with default configuration."""
    return AnthropicProvider()


@pytest.fixture
def provider_no_cache() -> AnthropicProvider:
    """Provider with prompt caching disabled."""
    config = AnthropicConfig(enable_prompt_caching=False)
    return AnthropicProvider(config)


@pytest.fixture
def provider_with_thinking() -> AnthropicProvider:
    """Provider with extended thinking enabled."""
    config = AnthropicConfig(
        enable_extended_thinking=True,
        thinking_budget_tokens=20000,
    )
    return AnthropicProvider(config)


@pytest.fixture
def simple_messages() -> list[dict]:
    """Simple user/assistant message pair."""
    return [
        {"role": "user", "content": "Hello, how are you?"},
    ]


@pytest.fixture
def messages_with_system() -> list[dict]:
    """Messages including a system message long enough for caching."""
    return [
        {"role": "system", "content": "You are a helpful assistant. " * 20},
        {"role": "user", "content": "What is Python?"},
    ]


@pytest.fixture
def messages_with_large_user() -> list[dict]:
    """Messages with a large user message (>1000 chars) for caching."""
    return [
        {"role": "system", "content": "You are a helpful assistant. " * 20},
        {"role": "user", "content": "Explain this code:\n" + "x = 1\n" * 250},
    ]


@pytest.fixture
def openai_format_tools() -> list[dict]:
    """Tools in OpenAI format."""
    return [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"},
                    },
                    "required": ["location"],
                },
            },
        },
    ]


@pytest.fixture
def anthropic_response_text() -> dict:
    """A mock Anthropic response with text content."""
    return {
        "content": [
            {"type": "text", "text": "Hello! I am doing well."},
        ],
        "usage": {
            "input_tokens": 10,
            "output_tokens": 8,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        },
        "stop_reason": "end_turn",
    }


@pytest.fixture
def anthropic_response_thinking() -> dict:
    """A mock Anthropic response with thinking and text blocks."""
    return {
        "content": [
            {"type": "thinking", "thinking": "Let me reason about this..."},
            {"type": "text", "text": "The answer is 42."},
        ],
        "usage": {
            "input_tokens": 15,
            "output_tokens": 12,
            "cache_creation_input_tokens": 5,
            "cache_read_input_tokens": 0,
        },
        "stop_reason": "end_turn",
    }


@pytest.fixture
def anthropic_response_tool_use() -> dict:
    """A mock Anthropic response with tool use."""
    return {
        "content": [
            {"type": "text", "text": "Let me check the weather."},
            {
                "type": "tool_use",
                "id": "toolu_abc123",
                "name": "get_weather",
                "input": {"location": "San Francisco"},
            },
        ],
        "usage": {
            "input_tokens": 20,
            "output_tokens": 15,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        },
        "stop_reason": "tool_use",
    }


# ---------------------------------------------------------------------------
# AnthropicModel enum tests
# ---------------------------------------------------------------------------


class TestAnthropicModel:
    def test_model_values(self) -> None:
        assert AnthropicModel.CLAUDE_OPUS_4.value == "claude-opus-4-20250514"
        assert AnthropicModel.CLAUDE_SONNET_4.value == "claude-sonnet-4-20250514"
        assert AnthropicModel.CLAUDE_HAIKU_35.value == "claude-3-5-haiku-20241022"
        assert AnthropicModel.CLAUDE_SONNET_35.value == "claude-3-5-sonnet-20241022"
        assert AnthropicModel.CLAUDE_OPUS_3.value == "claude-3-opus-20240229"

    def test_all_members(self) -> None:
        assert len(AnthropicModel) == 5


# ---------------------------------------------------------------------------
# AnthropicConfig tests
# ---------------------------------------------------------------------------


class TestAnthropicConfig:
    def test_defaults(self) -> None:
        config = AnthropicConfig()
        assert config.api_version == "2023-06-01"
        assert config.max_tokens_default == 8192
        assert config.enable_prompt_caching is True
        assert config.enable_extended_thinking is False
        assert config.thinking_budget_tokens == 10000
        assert "prompt-caching-2024-07-31" in config.beta_features

    def test_custom_config(self) -> None:
        config = AnthropicConfig(
            max_tokens_default=4096,
            enable_prompt_caching=False,
            thinking_budget_tokens=50000,
        )
        assert config.max_tokens_default == 4096
        assert config.enable_prompt_caching is False
        assert config.thinking_budget_tokens == 50000


# ---------------------------------------------------------------------------
# prepare_request tests
# ---------------------------------------------------------------------------


class TestPrepareRequest:
    def test_basic_request(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
        )
        assert params["model"] == "claude-sonnet-4-20250514"
        assert params["max_tokens"] == 8192
        assert "messages" in params

    def test_custom_max_tokens(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            max_tokens=1024,
        )
        assert params["max_tokens"] == 1024

    def test_temperature_passed(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            temperature=0.5,
        )
        assert params["temperature"] == 0.5

    def test_top_p_passed(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            top_p=0.9,
        )
        assert params["top_p"] == 0.9

    def test_stop_sequences(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            stop=["STOP", "END"],
        )
        assert params["stop_sequences"] == ["STOP", "END"]

    def test_prompt_caching_enabled_adds_headers(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
        )
        assert "extra_headers" in params
        assert "anthropic-beta" in params["extra_headers"]
        assert "prompt-caching" in params["extra_headers"]["anthropic-beta"]

    def test_prompt_caching_disabled_no_headers(
        self, provider_no_cache: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_no_cache.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
        )
        assert "extra_headers" not in params

    def test_extended_thinking_via_config(
        self, provider_with_thinking: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_with_thinking.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
        )
        assert "thinking" in params
        assert params["thinking"]["type"] == "enabled"
        assert params["thinking"]["budget_tokens"] == 20000
        # Thinking forces temperature=1 and removes top_p
        assert params["temperature"] == 1.0
        assert "top_p" not in params

    def test_extended_thinking_via_kwarg(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            enable_thinking=True,
            thinking_budget_tokens=5000,
        )
        assert params["thinking"]["budget_tokens"] == 5000
        assert params["temperature"] == 1.0

    def test_thinking_removes_top_p(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            top_p=0.9,
            enable_thinking=True,
        )
        assert "top_p" not in params

    def test_tools_converted(
        self,
        provider: AnthropicProvider,
        simple_messages: list[dict],
        openai_format_tools: list[dict],
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            tools=openai_format_tools,
        )
        assert "tools" in params
        assert len(params["tools"]) == 1
        tool = params["tools"][0]
        assert tool["name"] == "get_weather"
        assert "input_schema" in tool

    def test_empty_tools_not_added(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "claude-sonnet-4-20250514",
            tools=[],
        )
        assert "tools" not in params

    def test_does_not_mutate_input_messages(
        self, provider: AnthropicProvider, simple_messages: list[dict]
    ) -> None:
        original = [dict(m) for m in simple_messages]
        provider.prepare_request(simple_messages, "claude-sonnet-4-20250514")
        assert simple_messages == original


# ---------------------------------------------------------------------------
# _apply_cache_control tests
# ---------------------------------------------------------------------------


class TestApplyCacheControl:
    def test_caches_system_message(
        self, provider: AnthropicProvider, messages_with_system: list[dict]
    ) -> None:
        result = provider._apply_cache_control(messages_with_system)
        system_msg = result[0]
        assert isinstance(system_msg["content"], list)
        assert system_msg["content"][0]["cache_control"]["type"] == "ephemeral"

    def test_short_system_not_cached(self, provider: AnthropicProvider) -> None:
        messages = [
            {"role": "system", "content": "Be helpful."},
            {"role": "user", "content": "Hi"},
        ]
        result = provider._apply_cache_control(messages)
        assert isinstance(result[0]["content"], str)

    def test_caches_large_user_message(
        self, provider: AnthropicProvider, messages_with_large_user: list[dict]
    ) -> None:
        result = provider._apply_cache_control(messages_with_large_user)
        user_msg = result[1]
        assert isinstance(user_msg["content"], list)
        assert user_msg["content"][0]["cache_control"]["type"] == "ephemeral"

    def test_only_first_large_user_cached(self, provider: AnthropicProvider) -> None:
        messages = [
            {"role": "user", "content": "x " * 600},
            {"role": "user", "content": "y " * 600},
        ]
        result = provider._apply_cache_control(messages)
        # First user message should be cached
        assert isinstance(result[0]["content"], list)
        # Second should not
        assert isinstance(result[1]["content"], str)


# ---------------------------------------------------------------------------
# _convert_tools tests
# ---------------------------------------------------------------------------


class TestConvertTools:
    def test_openai_to_anthropic(
        self, provider: AnthropicProvider, openai_format_tools: list[dict]
    ) -> None:
        result = provider._convert_tools(openai_format_tools)
        assert len(result) == 1
        tool = result[0]
        assert tool["name"] == "get_weather"
        assert tool["description"] == "Get weather for a location"
        assert "input_schema" in tool
        assert tool["input_schema"]["type"] == "object"

    def test_anthropic_format_passthrough(self, provider: AnthropicProvider) -> None:
        anthropic_tools = [
            {
                "name": "search",
                "description": "Search the web",
                "input_schema": {"type": "object", "properties": {}},
            },
        ]
        result = provider._convert_tools(anthropic_tools)
        assert result == anthropic_tools

    def test_missing_description_defaults_empty(
        self, provider: AnthropicProvider
    ) -> None:
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "no_desc",
                },
            },
        ]
        result = provider._convert_tools(tools)
        assert result[0]["description"] == ""

    def test_missing_parameters_defaults(self, provider: AnthropicProvider) -> None:
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "no_params",
                    "description": "A tool",
                },
            },
        ]
        result = provider._convert_tools(tools)
        assert result[0]["input_schema"] == {"type": "object", "properties": {}}


# ---------------------------------------------------------------------------
# parse_response tests
# ---------------------------------------------------------------------------


class TestParseResponse:
    def test_text_response(
        self, provider: AnthropicProvider, anthropic_response_text: dict
    ) -> None:
        result = provider.parse_response(anthropic_response_text)
        assert result["content"] == "Hello! I am doing well."
        assert result["thinking"] is None
        assert result["tool_calls"] is None
        assert result["usage"]["input_tokens"] == 10
        assert result["usage"]["output_tokens"] == 8
        assert result["stop_reason"] == "end_turn"

    def test_thinking_response(
        self, provider: AnthropicProvider, anthropic_response_thinking: dict
    ) -> None:
        result = provider.parse_response(anthropic_response_thinking)
        assert result["content"] == "The answer is 42."
        assert result["thinking"] == "Let me reason about this..."
        assert result["usage"]["cache_creation_input_tokens"] == 5

    def test_tool_use_response(
        self, provider: AnthropicProvider, anthropic_response_tool_use: dict
    ) -> None:
        result = provider.parse_response(anthropic_response_tool_use)
        assert result["content"] == "Let me check the weather."
        assert result["tool_calls"] is not None
        assert len(result["tool_calls"]) == 1
        tc = result["tool_calls"][0]
        assert tc["id"] == "toolu_abc123"
        assert tc["function"]["name"] == "get_weather"
        assert tc["function"]["arguments"]["location"] == "San Francisco"
        assert result["stop_reason"] == "tool_use"

    def test_empty_response(self, provider: AnthropicProvider) -> None:
        result = provider.parse_response({"content": [], "usage": {}})
        assert result["content"] == ""
        assert result["thinking"] is None
        assert result["tool_calls"] is None

    def test_string_blocks(self, provider: AnthropicProvider) -> None:
        response = {
            "content": ["Hello", "World"],
            "usage": {"input_tokens": 1, "output_tokens": 2},
            "stop_reason": "end_turn",
        }
        result = provider.parse_response(response)
        assert result["content"] == "Hello\nWorld"

    def test_multiple_thinking_blocks(self, provider: AnthropicProvider) -> None:
        response = {
            "content": [
                {"type": "thinking", "thinking": "Step 1"},
                {"type": "thinking", "thinking": "Step 2"},
                {"type": "text", "text": "Final answer"},
            ],
            "usage": {},
        }
        result = provider.parse_response(response)
        assert result["thinking"] == "Step 1\nStep 2"
        assert result["content"] == "Final answer"

    def test_missing_usage_fields_default_to_zero(
        self, provider: AnthropicProvider
    ) -> None:
        response = {"content": [], "usage": {}}
        result = provider.parse_response(response)
        assert result["usage"]["input_tokens"] == 0
        assert result["usage"]["output_tokens"] == 0
        assert result["usage"]["cache_creation_input_tokens"] == 0
        assert result["usage"]["cache_read_input_tokens"] == 0


# ---------------------------------------------------------------------------
# get_model_capabilities tests
# ---------------------------------------------------------------------------


class TestGetModelCapabilities:
    def test_opus_4(self, provider: AnthropicProvider) -> None:
        caps = provider.get_model_capabilities("claude-opus-4-20250514")
        assert caps["vision"] is True
        assert caps["extended_thinking"] is True
        assert caps["pdf_input"] is True
        assert caps["citations"] is True
        assert caps["max_output"] == 16384

    def test_sonnet_4(self, provider: AnthropicProvider) -> None:
        caps = provider.get_model_capabilities("claude-sonnet-4-20250514")
        assert caps["extended_thinking"] is True
        assert caps["prompt_caching"] is True

    def test_haiku(self, provider: AnthropicProvider) -> None:
        caps = provider.get_model_capabilities("claude-3-5-haiku-20241022")
        assert caps["extended_thinking"] is False
        assert caps["citations"] is False
        assert caps["max_output"] == 8192

    def test_opus_3(self, provider: AnthropicProvider) -> None:
        caps = provider.get_model_capabilities("claude-3-opus-20240229")
        assert caps["extended_thinking"] is False
        assert caps["pdf_input"] is False
        assert caps["max_output"] == 4096

    def test_unknown_model_defaults(self, provider: AnthropicProvider) -> None:
        caps = provider.get_model_capabilities("claude-unknown-model")
        assert caps["vision"] is False
        assert caps["extended_thinking"] is False
        assert caps["max_output"] == 4096

    def test_capabilities_returns_copy(self, provider: AnthropicProvider) -> None:
        caps1 = provider.get_model_capabilities("claude-opus-4-20250514")
        caps2 = provider.get_model_capabilities("claude-opus-4-20250514")
        caps1["vision"] = False
        assert caps2["vision"] is True


# ---------------------------------------------------------------------------
# estimate_cache_savings tests
# ---------------------------------------------------------------------------


class TestEstimateCacheSavings:
    def test_large_messages(self, provider: AnthropicProvider) -> None:
        messages = [
            {"role": "system", "content": "x" * 10000},
            {"role": "user", "content": "y" * 5000},
        ]
        savings = provider.estimate_cache_savings(messages)
        assert savings["cacheable_tokens"] == 15000 // 4
        assert savings["cache_write_cost_multiplier"] == 1.25
        assert savings["cache_read_cost_multiplier"] == 0.10
        assert savings["breakeven_requests"] == 5
        assert savings["potential_savings_pct"] == 0.90

    def test_small_messages_no_savings(self, provider: AnthropicProvider) -> None:
        messages = [{"role": "user", "content": "Hi"}]
        savings = provider.estimate_cache_savings(messages)
        assert savings["potential_savings_pct"] == 0.0

    def test_non_string_content_skipped(self, provider: AnthropicProvider) -> None:
        messages = [
            {"role": "user", "content": [{"type": "text", "text": "test"}]},
        ]
        savings = provider.estimate_cache_savings(messages)
        assert savings["cacheable_tokens"] == 0

    def test_empty_messages(self, provider: AnthropicProvider) -> None:
        savings = provider.estimate_cache_savings([])
        assert savings["cacheable_tokens"] == 0


# ---------------------------------------------------------------------------
# Config property test
# ---------------------------------------------------------------------------


class TestProviderProperties:
    def test_config_property(self, provider: AnthropicProvider) -> None:
        assert isinstance(provider.config, AnthropicConfig)

    def test_custom_config_persisted(self) -> None:
        config = AnthropicConfig(max_tokens_default=2048)
        provider = AnthropicProvider(config)
        assert provider.config.max_tokens_default == 2048
