"""Tests for the Google/Gemini provider module."""

from __future__ import annotations

import pytest

from prism.providers.google_provider import (
    GoogleConfig,
    GoogleModel,
    GoogleProvider,
    HarmCategory,
    SafetySetting,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> GoogleProvider:
    """Provider with default configuration."""
    return GoogleProvider()


@pytest.fixture
def provider_with_grounding() -> GoogleProvider:
    """Provider with grounding enabled."""
    config = GoogleConfig(enable_grounding=True)
    return GoogleProvider(config)


@pytest.fixture
def provider_with_code_exec() -> GoogleProvider:
    """Provider with code execution enabled."""
    config = GoogleConfig(enable_code_execution=True)
    return GoogleProvider(config)


@pytest.fixture
def provider_custom_safety() -> GoogleProvider:
    """Provider with custom per-category safety settings."""
    config = GoogleConfig(
        safety_settings={
            HarmCategory.HARASSMENT: SafetySetting.BLOCK_NONE,
            HarmCategory.HATE_SPEECH: SafetySetting.BLOCK_ONLY_HIGH,
        },
    )
    return GoogleProvider(config)


@pytest.fixture
def simple_messages() -> list[dict]:
    """Simple user message."""
    return [{"role": "user", "content": "Hello!"}]


@pytest.fixture
def litellm_response() -> dict:
    """A mock Gemini response in LiteLLM-wrapped format."""
    return {
        "choices": [
            {
                "message": {"content": "Hello! How can I help?"},
                "finish_reason": "stop",
            },
        ],
        "usage": {
            "prompt_tokens": 5,
            "completion_tokens": 7,
            "total_tokens": 12,
        },
    }


@pytest.fixture
def native_gemini_response() -> dict:
    """A mock response in native Gemini candidate format."""
    return {
        "candidates": [
            {
                "content": {
                    "parts": [
                        {"text": "The capital of France is Paris."},
                    ],
                },
                "finishReason": "STOP",
                "safetyRatings": [
                    {
                        "category": "HARM_CATEGORY_HARASSMENT",
                        "probability": "NEGLIGIBLE",
                    },
                ],
            },
        ],
        "usageMetadata": {
            "promptTokenCount": 10,
            "candidatesTokenCount": 8,
            "totalTokenCount": 18,
        },
    }


@pytest.fixture
def native_tool_response() -> dict:
    """A mock native Gemini response with function calls."""
    return {
        "candidates": [
            {
                "content": {
                    "parts": [
                        {
                            "functionCall": {
                                "name": "get_weather",
                                "args": {"location": "Tokyo"},
                            },
                        },
                    ],
                },
                "finishReason": "STOP",
            },
        ],
        "usageMetadata": {
            "promptTokenCount": 12,
            "candidatesTokenCount": 5,
            "totalTokenCount": 17,
        },
    }


@pytest.fixture
def grounding_response() -> dict:
    """A mock native Gemini response with grounding metadata."""
    return {
        "candidates": [
            {
                "content": {
                    "parts": [{"text": "According to search results..."}],
                },
                "finishReason": "STOP",
                "groundingMetadata": {
                    "searchEntryPoint": {"renderedContent": "<html>...</html>"},
                    "groundingChunks": [
                        {"web": {"uri": "https://example.com", "title": "Example"}},
                    ],
                },
            },
        ],
        "usageMetadata": {
            "promptTokenCount": 15,
            "candidatesTokenCount": 10,
            "totalTokenCount": 25,
        },
    }


# ---------------------------------------------------------------------------
# GoogleModel enum tests
# ---------------------------------------------------------------------------


class TestGoogleModel:
    def test_model_values(self) -> None:
        assert GoogleModel.GEMINI_25_PRO.value == "gemini/gemini-2.5-pro"
        assert GoogleModel.GEMINI_20_FLASH.value == "gemini/gemini-2.0-flash"
        assert GoogleModel.GEMINI_15_PRO.value == "gemini/gemini-1.5-pro"

    def test_all_members(self) -> None:
        assert len(GoogleModel) == 5


# ---------------------------------------------------------------------------
# SafetySetting / HarmCategory enum tests
# ---------------------------------------------------------------------------


class TestSafetyEnums:
    def test_safety_settings(self) -> None:
        assert SafetySetting.BLOCK_NONE.value == "BLOCK_NONE"
        assert SafetySetting.BLOCK_ONLY_HIGH.value == "BLOCK_ONLY_HIGH"
        assert SafetySetting.BLOCK_MEDIUM_AND_ABOVE.value == "BLOCK_MEDIUM_AND_ABOVE"
        assert SafetySetting.BLOCK_LOW_AND_ABOVE.value == "BLOCK_LOW_AND_ABOVE"

    def test_harm_categories(self) -> None:
        assert HarmCategory.HARASSMENT.value == "HARM_CATEGORY_HARASSMENT"
        assert HarmCategory.HATE_SPEECH.value == "HARM_CATEGORY_HATE_SPEECH"
        assert len(HarmCategory) == 4


# ---------------------------------------------------------------------------
# GoogleConfig tests
# ---------------------------------------------------------------------------


class TestGoogleConfig:
    def test_defaults(self) -> None:
        config = GoogleConfig()
        assert config.default_max_tokens == 8192
        assert config.safety_threshold == SafetySetting.BLOCK_MEDIUM_AND_ABOVE
        assert config.enable_grounding is False
        assert config.enable_code_execution is False
        assert config.candidate_count == 1
        assert config.safety_settings == {}

    def test_custom_config(self) -> None:
        config = GoogleConfig(
            default_max_tokens=4096,
            enable_grounding=True,
            candidate_count=3,
        )
        assert config.default_max_tokens == 4096
        assert config.enable_grounding is True
        assert config.candidate_count == 3


# ---------------------------------------------------------------------------
# prepare_request tests
# ---------------------------------------------------------------------------


class TestPrepareRequest:
    def test_basic_request(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro"
        )
        assert params["model"] == "gemini/gemini-2.5-pro"
        assert params["max_tokens"] == 8192
        assert "messages" in params

    def test_custom_max_tokens(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro", max_tokens=1024
        )
        assert params["max_tokens"] == 1024

    def test_temperature(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro", temperature=0.3
        )
        assert params["temperature"] == 0.3

    def test_top_p(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro", top_p=0.95
        )
        assert params["top_p"] == 0.95

    def test_stop_sequences(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro", stop=["END"]
        )
        assert params["stop"] == ["END"]

    def test_safety_settings_included(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro"
        )
        assert "safety_settings" in params
        assert len(params["safety_settings"]) == 4  # One per HarmCategory
        for setting in params["safety_settings"]:
            assert "category" in setting
            assert "threshold" in setting

    def test_grounding_adds_tool(
        self, provider_with_grounding: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_with_grounding.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro"
        )
        assert "tools" in params
        tool_types = [
            next(iter(t.keys())) if isinstance(t, dict) else None
            for t in params["tools"]
        ]
        assert "google_search_retrieval" in tool_types

    def test_code_execution_adds_tool(
        self, provider_with_code_exec: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_with_code_exec.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro"
        )
        assert "tools" in params
        tool_types = [
            next(iter(t.keys())) if isinstance(t, dict) else None
            for t in params["tools"]
        ]
        assert "code_execution" in tool_types

    def test_grounding_via_kwarg(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "gemini/gemini-2.5-pro",
            enable_grounding=True,
        )
        assert "tools" in params

    def test_custom_safety_overrides(
        self, provider_custom_safety: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_custom_safety.prepare_request(
            simple_messages, "gemini/gemini-2.5-pro"
        )
        settings_map = {
            s["category"]: s["threshold"]
            for s in params["safety_settings"]
        }
        assert settings_map["HARM_CATEGORY_HARASSMENT"] == "BLOCK_NONE"
        assert settings_map["HARM_CATEGORY_HATE_SPEECH"] == "BLOCK_ONLY_HIGH"
        # Others should use default threshold
        assert (
            settings_map["HARM_CATEGORY_SEXUALLY_EXPLICIT"]
            == "BLOCK_MEDIUM_AND_ABOVE"
        )

    def test_does_not_mutate_input_messages(
        self, provider: GoogleProvider, simple_messages: list[dict]
    ) -> None:
        original = [dict(m) for m in simple_messages]
        provider.prepare_request(simple_messages, "gemini/gemini-2.5-pro")
        assert simple_messages == original


# ---------------------------------------------------------------------------
# _build_safety_settings tests
# ---------------------------------------------------------------------------


class TestBuildSafetySettings:
    def test_default_threshold_applied(self, provider: GoogleProvider) -> None:
        settings = provider._build_safety_settings()
        for s in settings:
            assert s["threshold"] == "BLOCK_MEDIUM_AND_ABOVE"

    def test_override_threshold(self, provider: GoogleProvider) -> None:
        settings = provider._build_safety_settings(SafetySetting.BLOCK_NONE)
        for s in settings:
            assert s["threshold"] == "BLOCK_NONE"

    def test_per_category_overrides(
        self, provider_custom_safety: GoogleProvider
    ) -> None:
        settings = provider_custom_safety._build_safety_settings()
        settings_map = {s["category"]: s["threshold"] for s in settings}
        assert settings_map["HARM_CATEGORY_HARASSMENT"] == "BLOCK_NONE"


# ---------------------------------------------------------------------------
# parse_response tests
# ---------------------------------------------------------------------------


class TestParseResponse:
    def test_litellm_wrapped_response(
        self, provider: GoogleProvider, litellm_response: dict
    ) -> None:
        result = provider.parse_response(litellm_response)
        assert result["content"] == "Hello! How can I help?"
        assert result["finish_reason"] == "stop"
        assert result["usage"]["prompt_tokens"] == 5
        assert result["usage"]["completion_tokens"] == 7

    def test_native_gemini_response(
        self, provider: GoogleProvider, native_gemini_response: dict
    ) -> None:
        result = provider.parse_response(native_gemini_response)
        assert result["content"] == "The capital of France is Paris."
        assert result["finish_reason"] == "STOP"
        assert result["safety_ratings"] is not None
        assert result["usage"]["prompt_tokens"] == 10
        assert result["usage"]["completion_tokens"] == 8

    def test_native_tool_response(
        self, provider: GoogleProvider, native_tool_response: dict
    ) -> None:
        result = provider.parse_response(native_tool_response)
        assert result["tool_calls"] is not None
        assert len(result["tool_calls"]) == 1
        tc = result["tool_calls"][0]
        assert tc["function"]["name"] == "get_weather"
        assert tc["function"]["arguments"]["location"] == "Tokyo"

    def test_grounding_metadata(
        self, provider: GoogleProvider, grounding_response: dict
    ) -> None:
        result = provider.parse_response(grounding_response)
        assert result["grounding_metadata"] is not None
        assert "groundingChunks" in result["grounding_metadata"]

    def test_empty_response(self, provider: GoogleProvider) -> None:
        result = provider.parse_response({"choices": [], "usage": {}})
        assert result["content"] == ""
        assert result["tool_calls"] is None

    def test_litellm_tool_calls(self, provider: GoogleProvider) -> None:
        response = {
            "choices": [
                {
                    "message": {
                        "content": "",
                        "tool_calls": [
                            {
                                "type": "function",
                                "function": {
                                    "name": "search",
                                    "arguments": "{}",
                                },
                            },
                        ],
                    },
                    "finish_reason": "tool_calls",
                },
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        }
        result = provider.parse_response(response)
        assert result["tool_calls"] is not None
        assert result["tool_calls"][0]["function"]["name"] == "search"


# ---------------------------------------------------------------------------
# get_model_capabilities tests
# ---------------------------------------------------------------------------


class TestGetModelCapabilities:
    def test_gemini_25_pro(self, provider: GoogleProvider) -> None:
        caps = provider.get_model_capabilities("gemini/gemini-2.5-pro")
        assert caps["vision"] is True
        assert caps["grounding"] is True
        assert caps["code_execution"] is True
        assert caps["context_window"] == 2_097_152

    def test_gemini_20_flash(self, provider: GoogleProvider) -> None:
        caps = provider.get_model_capabilities("gemini/gemini-2.0-flash")
        assert caps["vision"] is True
        assert caps["context_window"] == 1_048_576

    def test_gemini_15_pro(self, provider: GoogleProvider) -> None:
        caps = provider.get_model_capabilities("gemini/gemini-1.5-pro")
        assert caps["grounding"] is True
        assert caps["context_window"] == 2_097_152

    def test_unknown_model_defaults(self, provider: GoogleProvider) -> None:
        caps = provider.get_model_capabilities("gemini/unknown-model")
        assert caps["vision"] is False
        assert caps["grounding"] is False
        assert caps["context_window"] == 32768

    def test_capabilities_returns_copy(self, provider: GoogleProvider) -> None:
        caps1 = provider.get_model_capabilities("gemini/gemini-2.5-pro")
        caps2 = provider.get_model_capabilities("gemini/gemini-2.5-pro")
        caps1["vision"] = False
        assert caps2["vision"] is True


# ---------------------------------------------------------------------------
# estimate_free_tier_usage tests
# ---------------------------------------------------------------------------


class TestEstimateFreeTierUsage:
    def test_basic_estimate(self, provider: GoogleProvider) -> None:
        messages = [{"role": "user", "content": "x" * 4000}]
        usage = provider.estimate_free_tier_usage(messages)
        assert usage["estimated_input_tokens"] == 1000
        assert usage["free_tier_rpm"] == 15
        assert usage["free_tier_rpd"] == 1500

    def test_empty_messages(self, provider: GoogleProvider) -> None:
        usage = provider.estimate_free_tier_usage([])
        assert usage["estimated_input_tokens"] == 0

    def test_non_string_content_skipped(self, provider: GoogleProvider) -> None:
        messages = [{"role": "user", "content": [{"type": "image"}]}]
        usage = provider.estimate_free_tier_usage(messages)
        assert usage["estimated_input_tokens"] == 0


# ---------------------------------------------------------------------------
# Config property test
# ---------------------------------------------------------------------------


class TestProviderProperties:
    def test_config_property(self, provider: GoogleProvider) -> None:
        assert isinstance(provider.config, GoogleConfig)

    def test_custom_config_persisted(self) -> None:
        config = GoogleConfig(default_max_tokens=2048)
        provider = GoogleProvider(config)
        assert provider.config.default_max_tokens == 2048
