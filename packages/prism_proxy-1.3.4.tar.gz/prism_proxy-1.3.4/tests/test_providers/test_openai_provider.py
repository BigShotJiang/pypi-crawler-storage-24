"""Tests for the OpenAI provider module."""

from __future__ import annotations

import pytest

from prism.providers.openai_provider import (
    OpenAIConfig,
    OpenAIModel,
    OpenAIProvider,
    ReasoningEffort,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> OpenAIProvider:
    """Provider with default configuration."""
    return OpenAIProvider()


@pytest.fixture
def provider_with_logprobs() -> OpenAIProvider:
    """Provider with logprobs enabled."""
    config = OpenAIConfig(enable_logprobs=True, top_logprobs=3)
    return OpenAIProvider(config)


@pytest.fixture
def provider_with_seed() -> OpenAIProvider:
    """Provider with a deterministic seed."""
    config = OpenAIConfig(seed=42)
    return OpenAIProvider(config)


@pytest.fixture
def provider_high_effort() -> OpenAIProvider:
    """Provider with high reasoning effort."""
    config = OpenAIConfig(reasoning_effort=ReasoningEffort.HIGH)
    return OpenAIProvider(config)


@pytest.fixture
def simple_messages() -> list[dict]:
    """Simple user message."""
    return [{"role": "user", "content": "Hello!"}]


@pytest.fixture
def openai_tools() -> list[dict]:
    """Tools in OpenAI format."""
    return [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get the weather",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"},
                    },
                },
            },
        },
    ]


@pytest.fixture
def gpt4o_response() -> dict:
    """A mock GPT-4o response."""
    return {
        "choices": [
            {
                "message": {
                    "content": "Hello! How can I help?",
                },
                "finish_reason": "stop",
            },
        ],
        "usage": {
            "prompt_tokens": 5,
            "completion_tokens": 6,
            "total_tokens": 11,
        },
    }


@pytest.fixture
def o3_response() -> dict:
    """A mock o3 response with reasoning content."""
    return {
        "choices": [
            {
                "message": {
                    "content": "The answer is 42.",
                    "reasoning_content": "I need to think about this carefully...",
                },
                "finish_reason": "stop",
            },
        ],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 50,
            "total_tokens": 60,
            "completion_tokens_details": {
                "reasoning_tokens": 40,
            },
            "prompt_tokens_details": {
                "cached_tokens": 5,
            },
        },
    }


@pytest.fixture
def tool_call_response() -> dict:
    """A mock response with tool calls."""
    return {
        "choices": [
            {
                "message": {
                    "content": None,
                    "tool_calls": [
                        {
                            "id": "call_abc123",
                            "type": "function",
                            "function": {
                                "name": "get_weather",
                                "arguments": '{"location": "NYC"}',
                            },
                        },
                    ],
                },
                "finish_reason": "tool_calls",
            },
        ],
        "usage": {
            "prompt_tokens": 15,
            "completion_tokens": 20,
            "total_tokens": 35,
        },
    }


@pytest.fixture
def logprobs_response() -> dict:
    """A mock response with logprobs."""
    return {
        "choices": [
            {
                "message": {"content": "Yes."},
                "finish_reason": "stop",
                "logprobs": {
                    "content": [
                        {"token": "Yes", "logprob": -0.1, "top_logprobs": []},
                        {"token": ".", "logprob": -0.01, "top_logprobs": []},
                    ],
                },
            },
        ],
        "usage": {
            "prompt_tokens": 3,
            "completion_tokens": 2,
            "total_tokens": 5,
        },
    }


# ---------------------------------------------------------------------------
# OpenAIModel enum tests
# ---------------------------------------------------------------------------


class TestOpenAIModel:
    def test_model_values(self) -> None:
        assert OpenAIModel.GPT_4O.value == "gpt-4o"
        assert OpenAIModel.O3.value == "o3"
        assert OpenAIModel.O4_MINI.value == "o4-mini"
        assert OpenAIModel.GPT_35_TURBO.value == "gpt-3.5-turbo"

    def test_all_members(self) -> None:
        assert len(OpenAIModel) == 10


# ---------------------------------------------------------------------------
# ReasoningEffort enum tests
# ---------------------------------------------------------------------------


class TestReasoningEffort:
    def test_values(self) -> None:
        assert ReasoningEffort.LOW.value == "low"
        assert ReasoningEffort.MEDIUM.value == "medium"
        assert ReasoningEffort.HIGH.value == "high"


# ---------------------------------------------------------------------------
# OpenAIConfig tests
# ---------------------------------------------------------------------------


class TestOpenAIConfig:
    def test_defaults(self) -> None:
        config = OpenAIConfig()
        assert config.default_max_tokens == 4096
        assert config.enable_structured_output is True
        assert config.enable_logprobs is False
        assert config.top_logprobs == 5
        assert config.reasoning_effort == ReasoningEffort.MEDIUM
        assert config.seed is None
        assert config.response_format is None
        assert config.parallel_tool_calls is True

    def test_custom_config(self) -> None:
        config = OpenAIConfig(
            default_max_tokens=2048,
            seed=123,
            reasoning_effort=ReasoningEffort.HIGH,
        )
        assert config.default_max_tokens == 2048
        assert config.seed == 123
        assert config.reasoning_effort == ReasoningEffort.HIGH


# ---------------------------------------------------------------------------
# prepare_request tests — GPT models
# ---------------------------------------------------------------------------


class TestPrepareRequestGPT:
    def test_basic_request(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(simple_messages, "gpt-4o")
        assert params["model"] == "gpt-4o"
        assert params["max_tokens"] == 4096
        assert "messages" in params
        assert "reasoning_effort" not in params

    def test_custom_max_tokens(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", max_tokens=1024
        )
        assert params["max_tokens"] == 1024

    def test_temperature(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", temperature=0.5
        )
        assert params["temperature"] == 0.5

    def test_top_p(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", top_p=0.9
        )
        assert params["top_p"] == 0.9

    def test_stop_sequences(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", stop=["END"]
        )
        assert params["stop"] == ["END"]

    def test_frequency_penalty(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", frequency_penalty=0.5
        )
        assert params["frequency_penalty"] == 0.5

    def test_presence_penalty(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", presence_penalty=0.3
        )
        assert params["presence_penalty"] == 0.3

    def test_response_format_json(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "gpt-4o",
            response_format={"type": "json_object"},
        )
        assert params["response_format"] == {"type": "json_object"}

    def test_tools_passed(
        self,
        provider: OpenAIProvider,
        simple_messages: list[dict],
        openai_tools: list[dict],
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", tools=openai_tools
        )
        assert params["tools"] == openai_tools
        assert params["parallel_tool_calls"] is True

    def test_empty_tools_not_added(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "gpt-4o", tools=[]
        )
        assert "tools" not in params

    def test_logprobs_when_enabled(
        self, provider_with_logprobs: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_with_logprobs.prepare_request(
            simple_messages, "gpt-4o"
        )
        assert params["logprobs"] is True
        assert params["top_logprobs"] == 3

    def test_logprobs_disabled_by_default(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(simple_messages, "gpt-4o")
        assert "logprobs" not in params

    def test_seed_when_configured(
        self, provider_with_seed: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_with_seed.prepare_request(simple_messages, "gpt-4o")
        assert params["seed"] == 42


# ---------------------------------------------------------------------------
# prepare_request tests — o-series reasoning models
# ---------------------------------------------------------------------------


class TestPrepareRequestReasoning:
    def test_o3_uses_max_completion_tokens(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(simple_messages, "o3")
        assert "max_completion_tokens" in params
        assert "max_tokens" not in params
        assert params["max_completion_tokens"] == 16384

    def test_o4_mini_reasoning_effort(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(simple_messages, "o4-mini")
        assert params["reasoning_effort"] == "medium"

    def test_custom_reasoning_effort(
        self, provider_high_effort: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_high_effort.prepare_request(simple_messages, "o3")
        assert params["reasoning_effort"] == "high"

    def test_reasoning_effort_kwarg_override(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "o3", reasoning_effort=ReasoningEffort.LOW
        )
        assert params["reasoning_effort"] == "low"

    def test_reasoning_effort_string_passthrough(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "o3", reasoning_effort="high"
        )
        assert params["reasoning_effort"] == "high"

    def test_no_temperature_for_reasoning(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "o3", temperature=0.5
        )
        assert "temperature" not in params

    def test_no_top_p_for_reasoning(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages, "o3", top_p=0.9
        )
        assert "top_p" not in params

    def test_no_logprobs_for_reasoning(
        self, provider_with_logprobs: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider_with_logprobs.prepare_request(
            simple_messages, "o3"
        )
        assert "logprobs" not in params

    def test_no_response_format_for_reasoning(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "o1",
            response_format={"type": "json_object"},
        )
        assert "response_format" not in params

    def test_no_penalties_for_reasoning(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        params = provider.prepare_request(
            simple_messages,
            "o3",
            frequency_penalty=0.5,
            presence_penalty=0.3,
        )
        assert "frequency_penalty" not in params
        assert "presence_penalty" not in params

    def test_o1_is_reasoning_model(self, provider: OpenAIProvider) -> None:
        assert provider._is_reasoning_model("o1") is True

    def test_o1_mini_is_reasoning_model(self, provider: OpenAIProvider) -> None:
        assert provider._is_reasoning_model("o1-mini") is True

    def test_gpt4o_is_not_reasoning_model(self, provider: OpenAIProvider) -> None:
        assert provider._is_reasoning_model("gpt-4o") is False


# ---------------------------------------------------------------------------
# parse_response tests
# ---------------------------------------------------------------------------


class TestParseResponse:
    def test_gpt4o_response(
        self, provider: OpenAIProvider, gpt4o_response: dict
    ) -> None:
        result = provider.parse_response(gpt4o_response)
        assert result["content"] == "Hello! How can I help?"
        assert result["reasoning"] is None
        assert result["tool_calls"] is None
        assert result["usage"]["prompt_tokens"] == 5
        assert result["usage"]["completion_tokens"] == 6
        assert result["finish_reason"] == "stop"

    def test_o3_response_with_reasoning(
        self, provider: OpenAIProvider, o3_response: dict
    ) -> None:
        result = provider.parse_response(o3_response)
        assert result["content"] == "The answer is 42."
        assert result["reasoning"] == "I need to think about this carefully..."
        assert result["usage"]["reasoning_tokens"] == 40
        assert result["usage"]["cached_tokens"] == 5

    def test_tool_call_response(
        self, provider: OpenAIProvider, tool_call_response: dict
    ) -> None:
        result = provider.parse_response(tool_call_response)
        assert result["content"] == ""
        assert result["tool_calls"] is not None
        assert len(result["tool_calls"]) == 1
        tc = result["tool_calls"][0]
        assert tc["function"]["name"] == "get_weather"
        assert result["finish_reason"] == "tool_calls"

    def test_logprobs_response(
        self, provider: OpenAIProvider, logprobs_response: dict
    ) -> None:
        result = provider.parse_response(logprobs_response)
        assert result["logprobs"] is not None
        assert len(result["logprobs"]["content"]) == 2

    def test_empty_response(self, provider: OpenAIProvider) -> None:
        result = provider.parse_response({"choices": [], "usage": {}})
        assert result["content"] == ""
        assert result["reasoning"] is None
        assert result["tool_calls"] is None

    def test_no_choices(self, provider: OpenAIProvider) -> None:
        result = provider.parse_response({"usage": {}})
        assert result["content"] == ""

    def test_missing_usage_details(self, provider: OpenAIProvider) -> None:
        response = {
            "choices": [
                {"message": {"content": "OK"}, "finish_reason": "stop"},
            ],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }
        result = provider.parse_response(response)
        assert result["usage"]["reasoning_tokens"] == 0
        assert result["usage"]["cached_tokens"] == 0

    def test_null_content_coerced_to_empty(self, provider: OpenAIProvider) -> None:
        response = {
            "choices": [
                {"message": {"content": None}, "finish_reason": "stop"},
            ],
            "usage": {},
        }
        result = provider.parse_response(response)
        assert result["content"] == ""


# ---------------------------------------------------------------------------
# get_model_capabilities tests
# ---------------------------------------------------------------------------


class TestGetModelCapabilities:
    def test_gpt4o(self, provider: OpenAIProvider) -> None:
        caps = provider.get_model_capabilities("gpt-4o")
        assert caps["vision"] is True
        assert caps["reasoning"] is False
        assert caps["json_mode"] is True
        assert caps["context_window"] == 128000

    def test_gpt4o_mini(self, provider: OpenAIProvider) -> None:
        caps = provider.get_model_capabilities("gpt-4o-mini")
        assert caps["vision"] is True
        assert caps["max_output"] == 16384

    def test_o3(self, provider: OpenAIProvider) -> None:
        caps = provider.get_model_capabilities("o3")
        assert caps["reasoning"] is True
        assert caps["json_mode"] is False
        assert caps["logprobs"] is False
        assert caps["context_window"] == 200000

    def test_o4_mini(self, provider: OpenAIProvider) -> None:
        caps = provider.get_model_capabilities("o4-mini")
        assert caps["reasoning"] is True
        assert caps["max_output"] == 100000

    def test_unknown_model_defaults(self, provider: OpenAIProvider) -> None:
        caps = provider.get_model_capabilities("gpt-unknown")
        assert caps["vision"] is False
        assert caps["reasoning"] is False
        assert caps["context_window"] == 8192

    def test_capabilities_returns_copy(self, provider: OpenAIProvider) -> None:
        caps1 = provider.get_model_capabilities("gpt-4o")
        caps2 = provider.get_model_capabilities("gpt-4o")
        caps1["vision"] = False
        assert caps2["vision"] is True


# ---------------------------------------------------------------------------
# optimize_for_speed tests
# ---------------------------------------------------------------------------


class TestOptimizeForSpeed:
    def test_caps_max_tokens(self, provider: OpenAIProvider) -> None:
        params = {"max_tokens": 4096, "temperature": 0.7}
        result = provider.optimize_for_speed(params)
        assert result["max_tokens"] == 1024

    def test_enables_streaming(self, provider: OpenAIProvider) -> None:
        params = {"max_tokens": 512}
        result = provider.optimize_for_speed(params)
        assert result["stream"] is True

    def test_removes_logprobs(self, provider: OpenAIProvider) -> None:
        params = {"logprobs": True, "top_logprobs": 5}
        result = provider.optimize_for_speed(params)
        assert "logprobs" not in result
        assert "top_logprobs" not in result

    def test_does_not_mutate_input(self, provider: OpenAIProvider) -> None:
        params = {"max_tokens": 4096}
        provider.optimize_for_speed(params)
        assert params["max_tokens"] == 4096

    def test_no_max_tokens_key(self, provider: OpenAIProvider) -> None:
        params = {"temperature": 0.5}
        result = provider.optimize_for_speed(params)
        assert "max_tokens" not in result
        assert result["stream"] is True


# ---------------------------------------------------------------------------
# optimize_for_quality tests
# ---------------------------------------------------------------------------


class TestOptimizeForQuality:
    def test_sets_low_temperature(self, provider: OpenAIProvider) -> None:
        params = {}
        result = provider.optimize_for_quality(params)
        assert result["temperature"] == 0.2

    def test_preserves_existing_temperature(self, provider: OpenAIProvider) -> None:
        params = {"temperature": 0.1}
        result = provider.optimize_for_quality(params)
        assert result["temperature"] == 0.1

    def test_enables_logprobs(self, provider: OpenAIProvider) -> None:
        params = {}
        result = provider.optimize_for_quality(params)
        assert result["logprobs"] is True
        assert result["top_logprobs"] == 5

    def test_does_not_mutate_input(self, provider: OpenAIProvider) -> None:
        params = {"temperature": 0.7}
        provider.optimize_for_quality(params)
        assert params["temperature"] == 0.7


# ---------------------------------------------------------------------------
# Config property test
# ---------------------------------------------------------------------------


class TestProviderProperties:
    def test_config_property(self, provider: OpenAIProvider) -> None:
        assert isinstance(provider.config, OpenAIConfig)

    def test_custom_config_persisted(self) -> None:
        config = OpenAIConfig(default_max_tokens=2048)
        provider = OpenAIProvider(config)
        assert provider.config.default_max_tokens == 2048

    def test_does_not_mutate_input_messages(
        self, provider: OpenAIProvider, simple_messages: list[dict]
    ) -> None:
        original = [dict(m) for m in simple_messages]
        provider.prepare_request(simple_messages, "gpt-4o")
        assert simple_messages == original
