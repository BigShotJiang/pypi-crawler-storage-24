"""Tests for the usage analytics engine."""

from __future__ import annotations

import time

import pytest

from prism.cost.usage_analytics import (
    AnalyticsConfig,
    AnomalyDetection,
    BucketSize,
    PeakUsage,
    ProviderReport,
    SessionReport,
    TimeSeriesBucket,
    UsageAnalytics,
    UsageRecord,
    _bucket_seconds,
    _format_timestamp,
    _percentile,
    _safe_mean,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def engine() -> UsageAnalytics:
    """Empty analytics engine with default config."""
    return UsageAnalytics()


@pytest.fixture()
def config() -> AnalyticsConfig:
    """Custom config with daily buckets and lower anomaly sensitivity."""
    return AnalyticsConfig(
        retention_days=30,
        bucket_size=BucketSize.DAILY,
        anomaly_sensitivity=1.5,
    )


@pytest.fixture()
def populated_engine() -> UsageAnalytics:
    """Engine pre-loaded with diverse multi-provider records."""
    eng = UsageAnalytics()
    now = time.time()

    # OpenAI records — 40 requests spread over 40 hours
    for i in range(40):
        eng.record(UsageRecord(
            timestamp=now - (i * 3600),
            model="gpt-4o",
            provider="openai",
            tokens_in=500,
            tokens_out=200,
            latency_ms=300.0 + (i % 10) * 50,
            cost_usd=0.005,
            success=True,
            session_id="session-1" if i < 20 else "session-2",
        ))

    # Anthropic records — 30 requests
    for i in range(30):
        eng.record(UsageRecord(
            timestamp=now - (i * 3600),
            model="claude-haiku",
            provider="anthropic",
            tokens_in=400,
            tokens_out=150,
            latency_ms=150.0 + (i % 5) * 20,
            cost_usd=0.001,
            success=True,
            session_id="session-1",
        ))

    # Some errors from openai
    for i in range(5):
        eng.record(UsageRecord(
            timestamp=now - (i * 7200),
            model="gpt-4o",
            provider="openai",
            tokens_in=500,
            tokens_out=0,
            latency_ms=50.0,
            cost_usd=0.0,
            success=False,
            error_type="rate_limit" if i < 3 else "timeout",
            session_id="session-2",
        ))

    # Google records — 10 requests
    for i in range(10):
        eng.record(UsageRecord(
            timestamp=now - (i * 3600),
            model="gemini-pro",
            provider="google",
            tokens_in=600,
            tokens_out=300,
            latency_ms=500.0,
            cost_usd=0.003,
            success=True,
            session_id="session-3",
        ))

    return eng


# ---------------------------------------------------------------------------
# Utility function tests
# ---------------------------------------------------------------------------


class TestUtilities:
    """Tests for statistical utility helpers."""

    def test_safe_mean_basic(self) -> None:
        assert _safe_mean([1.0, 2.0, 3.0]) == 2.0

    def test_safe_mean_empty(self) -> None:
        assert _safe_mean([]) == 0.0

    def test_safe_mean_single(self) -> None:
        assert _safe_mean([42.0]) == 42.0

    def test_percentile_empty(self) -> None:
        assert _percentile([], 0.5) == 0.0

    def test_percentile_single(self) -> None:
        assert _percentile([10.0], 0.95) == 10.0

    def test_percentile_p50(self) -> None:
        vals = sorted([1.0, 2.0, 3.0, 4.0, 5.0])
        p50 = _percentile(vals, 0.50)
        assert p50 == 3.0

    def test_percentile_p95_large(self) -> None:
        vals = sorted([float(x) for x in range(1, 101)])
        p95 = _percentile(vals, 0.95)
        assert p95 >= 94.0
        assert p95 <= 96.0

    def test_percentile_interpolation(self) -> None:
        """Verify linear interpolation between elements."""
        vals = sorted([10.0, 20.0, 30.0, 40.0])
        p50 = _percentile(vals, 0.50)
        # 0.50 * 3 = 1.5 -> between index 1 (20) and index 2 (30)
        assert abs(p50 - 25.0) < 0.01

    def test_bucket_seconds_hourly(self) -> None:
        assert _bucket_seconds(BucketSize.HOURLY) == 3600.0

    def test_bucket_seconds_daily(self) -> None:
        assert _bucket_seconds(BucketSize.DAILY) == 86400.0

    def test_bucket_seconds_weekly(self) -> None:
        assert _bucket_seconds(BucketSize.WEEKLY) == 604800.0

    def test_format_timestamp_hourly(self) -> None:
        ts = 1710000000.0  # Known unix timestamp
        label = _format_timestamp(ts, BucketSize.HOURLY)
        assert ":00" in label

    def test_format_timestamp_daily(self) -> None:
        ts = 1710000000.0
        label = _format_timestamp(ts, BucketSize.DAILY)
        assert ":" not in label
        assert "-" in label

    def test_format_timestamp_weekly(self) -> None:
        ts = 1710000000.0
        label = _format_timestamp(ts, BucketSize.WEEKLY)
        assert label.startswith("Week of")


# ---------------------------------------------------------------------------
# Recording tests
# ---------------------------------------------------------------------------


class TestRecording:
    """Tests for recording usage events."""

    def test_record_single(self, engine: UsageAnalytics) -> None:
        rec = UsageRecord(model="gpt-4o", provider="openai", cost_usd=0.005)
        engine.record(rec)
        assert engine.record_count == 1

    def test_record_many(self, engine: UsageAnalytics) -> None:
        records = [
            UsageRecord(model="gpt-4o", provider="openai"),
            UsageRecord(model="claude-haiku", provider="anthropic"),
        ]
        engine.record_many(records)
        assert engine.record_count == 2

    def test_clear(self, engine: UsageAnalytics) -> None:
        engine.record(UsageRecord(model="test"))
        engine.clear()
        assert engine.record_count == 0

    def test_record_preserves_fields(self, engine: UsageAnalytics) -> None:
        rec = UsageRecord(
            model="gpt-4o",
            provider="openai",
            tokens_in=500,
            tokens_out=200,
            latency_ms=320.0,
            cost_usd=0.005,
            success=True,
            session_id="s1",
        )
        engine.record(rec)
        exported = engine.export()
        assert exported["summary"]["total_requests"] == 1


# ---------------------------------------------------------------------------
# Request volume tests
# ---------------------------------------------------------------------------


class TestRequestVolume:
    """Tests for RPM, RPH, RPD calculations."""

    def test_rpm_empty(self, engine: UsageAnalytics) -> None:
        assert engine.requests_per_minute() == 0.0

    def test_rpm_basic(self, populated_engine: UsageAnalytics) -> None:
        rpm = populated_engine.requests_per_minute(window_minutes=60)
        # Should have some records in the last 60 minutes
        assert rpm >= 0.0

    def test_rph_empty(self, engine: UsageAnalytics) -> None:
        assert engine.requests_per_hour() == 0.0

    def test_rph_basic(self, populated_engine: UsageAnalytics) -> None:
        rph = populated_engine.requests_per_hour(window_hours=24)
        assert rph > 0.0

    def test_rpd_basic(self, populated_engine: UsageAnalytics) -> None:
        rpd = populated_engine.requests_per_day(window_days=30)
        assert rpd > 0.0

    def test_rpm_filtered_by_model(self, populated_engine: UsageAnalytics) -> None:
        rpm_all = populated_engine.requests_per_minute(window_minutes=10000)
        rpm_gpt = populated_engine.requests_per_minute(model="gpt-4o", window_minutes=10000)
        assert rpm_gpt <= rpm_all

    def test_rpm_filtered_by_provider(self, populated_engine: UsageAnalytics) -> None:
        rpm_openai = populated_engine.requests_per_minute(
            provider="openai", window_minutes=10000,
        )
        rpm_google = populated_engine.requests_per_minute(
            provider="google", window_minutes=10000,
        )
        assert rpm_openai > rpm_google


# ---------------------------------------------------------------------------
# Token consumption tests
# ---------------------------------------------------------------------------


class TestTokenConsumption:
    """Tests for token consumption analytics."""

    def test_empty(self, engine: UsageAnalytics) -> None:
        result = engine.token_consumption()
        assert result["total_in"] == 0
        assert result["total_out"] == 0
        assert result["ratio"] == 0.0

    def test_basic_consumption(self, populated_engine: UsageAnalytics) -> None:
        result = populated_engine.token_consumption()
        assert result["total_in"] > 0
        assert result["total_out"] > 0
        assert result["ratio"] > 0.0
        assert result["total"] == result["total_in"] + result["total_out"]

    def test_consumption_by_model(self, populated_engine: UsageAnalytics) -> None:
        gpt = populated_engine.token_consumption(model="gpt-4o")
        claude = populated_engine.token_consumption(model="claude-haiku")
        assert gpt["avg_in"] == 500.0  # All gpt-4o records have 500 tokens_in
        assert claude["avg_in"] == 400.0

    def test_input_output_ratio(self) -> None:
        eng = UsageAnalytics()
        eng.record(UsageRecord(tokens_in=1000, tokens_out=500))
        result = eng.token_consumption()
        assert result["ratio"] == 2.0


# ---------------------------------------------------------------------------
# Error rate tests
# ---------------------------------------------------------------------------


class TestErrorRate:
    """Tests for error rate tracking."""

    def test_no_records(self, engine: UsageAnalytics) -> None:
        assert engine.error_rate() == 0.0

    def test_no_errors(self) -> None:
        eng = UsageAnalytics()
        eng.record(UsageRecord(success=True))
        eng.record(UsageRecord(success=True))
        assert eng.error_rate() == 0.0

    def test_some_errors(self, populated_engine: UsageAnalytics) -> None:
        rate = populated_engine.error_rate(provider="openai")
        # 5 errors out of 45 openai records
        assert 0.0 < rate < 1.0

    def test_all_errors(self) -> None:
        eng = UsageAnalytics()
        for _ in range(5):
            eng.record(UsageRecord(success=False, error_type="timeout"))
        assert eng.error_rate() == 1.0

    def test_error_breakdown(self, populated_engine: UsageAnalytics) -> None:
        breakdown = populated_engine.error_breakdown(provider="openai")
        assert "rate_limit" in breakdown
        assert "timeout" in breakdown
        assert breakdown["rate_limit"] == 3
        assert breakdown["timeout"] == 2

    def test_error_breakdown_empty(self, engine: UsageAnalytics) -> None:
        breakdown = engine.error_breakdown()
        assert breakdown == {}


# ---------------------------------------------------------------------------
# Latency percentile tests
# ---------------------------------------------------------------------------


class TestLatencyPercentiles:
    """Tests for latency percentile calculations."""

    def test_empty(self, engine: UsageAnalytics) -> None:
        result = engine.latency_percentiles()
        assert result["p50"] == 0.0
        assert result["p99"] == 0.0

    def test_all_percentiles_present(self, populated_engine: UsageAnalytics) -> None:
        result = populated_engine.latency_percentiles()
        for key in ("p50", "p75", "p90", "p95", "p99"):
            assert key in result
            assert result[key] > 0.0

    def test_percentile_ordering(self, populated_engine: UsageAnalytics) -> None:
        result = populated_engine.latency_percentiles()
        assert result["p50"] <= result["p75"]
        assert result["p75"] <= result["p90"]
        assert result["p90"] <= result["p95"]
        assert result["p95"] <= result["p99"]

    def test_percentile_by_model(self, populated_engine: UsageAnalytics) -> None:
        gpt = populated_engine.latency_percentiles(model="gpt-4o")
        claude = populated_engine.latency_percentiles(model="claude-haiku")
        # GPT-4o has higher latency in our fixture
        assert gpt["p50"] > claude["p50"]

    def test_single_record_percentiles(self) -> None:
        eng = UsageAnalytics()
        eng.record(UsageRecord(latency_ms=100.0))
        result = eng.latency_percentiles()
        assert result["p50"] == 100.0
        assert result["p99"] == 100.0

    def test_percentile_accuracy_known_distribution(self) -> None:
        """Verify percentile accuracy with a known set of values."""
        eng = UsageAnalytics()
        for ms in range(100, 1100, 100):  # 100, 200, ..., 1000
            eng.record(UsageRecord(latency_ms=float(ms)))
        result = eng.latency_percentiles()
        # P50 of [100..1000] should be around 550
        assert 500.0 <= result["p50"] <= 600.0


# ---------------------------------------------------------------------------
# Session analytics tests
# ---------------------------------------------------------------------------


class TestSessionAnalytics:
    """Tests for session-level analytics."""

    def test_empty_sessions(self, engine: UsageAnalytics) -> None:
        reports = engine.session_reports()
        assert reports == []

    def test_session_reports_populated(self, populated_engine: UsageAnalytics) -> None:
        reports = populated_engine.session_reports()
        assert len(reports) >= 2
        for report in reports:
            assert isinstance(report, SessionReport)
            assert report.request_count > 0

    def test_session_duration(self, populated_engine: UsageAnalytics) -> None:
        reports = populated_engine.session_reports()
        for report in reports:
            assert report.duration_seconds >= 0.0

    def test_session_cost(self, populated_engine: UsageAnalytics) -> None:
        reports = populated_engine.session_reports()
        total_session_cost = sum(r.total_cost for r in reports)
        total_cost = sum(r.cost_usd for r in populated_engine._records)
        assert abs(total_session_cost - total_cost) < 0.0001

    def test_session_error_count(self, populated_engine: UsageAnalytics) -> None:
        reports = populated_engine.session_reports()
        total_errors = sum(r.error_count for r in reports)
        assert total_errors == 5  # 5 errors in fixture

    def test_session_summary(self, populated_engine: UsageAnalytics) -> None:
        summary = populated_engine.session_summary()
        assert summary["total_sessions"] > 0
        assert summary["avg_requests"] > 0.0
        assert summary["avg_cost"] >= 0.0

    def test_session_summary_empty(self, engine: UsageAnalytics) -> None:
        summary = engine.session_summary()
        assert summary["total_sessions"] == 0.0
        assert summary["avg_requests"] == 0.0

    def test_session_models_used(self, populated_engine: UsageAnalytics) -> None:
        reports = populated_engine.session_reports()
        # session-1 uses both gpt-4o and claude-haiku
        session_1 = [r for r in reports if r.session_id == "session-1"]
        if session_1:
            assert len(session_1[0].models_used) >= 2


# ---------------------------------------------------------------------------
# Peak usage tests
# ---------------------------------------------------------------------------


class TestPeakUsage:
    """Tests for peak usage detection."""

    def test_empty(self, engine: UsageAnalytics) -> None:
        peaks = engine.peak_usage()
        assert peaks == []

    def test_peaks_detected(self, populated_engine: UsageAnalytics) -> None:
        peaks = populated_engine.peak_usage(top_n=3)
        assert len(peaks) <= 3
        assert len(peaks) > 0

    def test_peaks_sorted_descending(self, populated_engine: UsageAnalytics) -> None:
        peaks = populated_engine.peak_usage(top_n=10)
        for i in range(len(peaks) - 1):
            assert peaks[i].request_count >= peaks[i + 1].request_count

    def test_peak_has_label(self, populated_engine: UsageAnalytics) -> None:
        peaks = populated_engine.peak_usage(
            bucket_size=BucketSize.HOURLY, top_n=1,
        )
        assert peaks[0].period_label != ""

    def test_peak_daily_buckets(self, populated_engine: UsageAnalytics) -> None:
        peaks = populated_engine.peak_usage(bucket_size=BucketSize.DAILY)
        for p in peaks:
            assert isinstance(p, PeakUsage)
            assert p.request_count > 0


# ---------------------------------------------------------------------------
# Provider comparison tests
# ---------------------------------------------------------------------------


class TestProviderComparison:
    """Tests for provider reports and comparison."""

    def test_single_provider_report(self, populated_engine: UsageAnalytics) -> None:
        report = populated_engine.provider_report("openai")
        assert isinstance(report, ProviderReport)
        assert report.provider == "openai"
        assert report.request_count == 45  # 40 success + 5 errors

    def test_provider_success_rate(self, populated_engine: UsageAnalytics) -> None:
        report = populated_engine.provider_report("openai")
        expected_rate = 40 / 45  # 40 success out of 45
        assert abs(report.success_rate - expected_rate) < 0.01

    def test_provider_latency_percentiles(self, populated_engine: UsageAnalytics) -> None:
        report = populated_engine.provider_report("openai")
        assert report.p50_latency > 0.0
        assert report.p95_latency >= report.p50_latency

    def test_provider_error_breakdown(self, populated_engine: UsageAnalytics) -> None:
        report = populated_engine.provider_report("openai")
        assert "rate_limit" in report.error_breakdown
        assert "timeout" in report.error_breakdown

    def test_provider_comparison_all(self, populated_engine: UsageAnalytics) -> None:
        comparison = populated_engine.provider_comparison()
        providers = {r.provider for r in comparison}
        assert "openai" in providers
        assert "anthropic" in providers
        assert "google" in providers

    def test_unknown_provider(self, populated_engine: UsageAnalytics) -> None:
        report = populated_engine.provider_report("nonexistent")
        assert report.request_count == 0
        assert report.success_rate == 1.0  # default

    def test_provider_models_used(self, populated_engine: UsageAnalytics) -> None:
        report = populated_engine.provider_report("openai")
        assert "gpt-4o" in report.models_used

    def test_provider_total_cost(self, populated_engine: UsageAnalytics) -> None:
        report = populated_engine.provider_report("anthropic")
        assert report.total_cost == pytest.approx(0.001 * 30, abs=0.001)


# ---------------------------------------------------------------------------
# Time-series aggregation tests
# ---------------------------------------------------------------------------


class TestTimeSeries:
    """Tests for time-series bucket aggregation."""

    def test_empty(self, engine: UsageAnalytics) -> None:
        ts = engine.time_series()
        assert ts == []

    def test_hourly_buckets(self, populated_engine: UsageAnalytics) -> None:
        ts = populated_engine.time_series(bucket_size=BucketSize.HOURLY)
        assert len(ts) > 0
        for bucket in ts:
            assert isinstance(bucket, TimeSeriesBucket)
            assert bucket.period_end - bucket.period_start == 3600.0

    def test_daily_buckets(self, populated_engine: UsageAnalytics) -> None:
        ts = populated_engine.time_series(bucket_size=BucketSize.DAILY)
        assert len(ts) > 0
        for bucket in ts:
            assert bucket.period_end - bucket.period_start == 86400.0

    def test_weekly_buckets(self, populated_engine: UsageAnalytics) -> None:
        ts = populated_engine.time_series(bucket_size=BucketSize.WEEKLY)
        assert len(ts) > 0

    def test_buckets_chronological(self, populated_engine: UsageAnalytics) -> None:
        ts = populated_engine.time_series(bucket_size=BucketSize.HOURLY)
        for i in range(len(ts) - 1):
            assert ts[i].period_start <= ts[i + 1].period_start

    def test_bucket_totals_match(self, populated_engine: UsageAnalytics) -> None:
        ts = populated_engine.time_series(bucket_size=BucketSize.HOURLY)
        total_requests = sum(b.request_count for b in ts)
        assert total_requests == populated_engine.record_count

    def test_filtered_time_series(self, populated_engine: UsageAnalytics) -> None:
        ts_all = populated_engine.time_series(bucket_size=BucketSize.DAILY)
        ts_openai = populated_engine.time_series(
            bucket_size=BucketSize.DAILY, provider="openai",
        )
        total_all = sum(b.request_count for b in ts_all)
        total_openai = sum(b.request_count for b in ts_openai)
        assert total_openai < total_all


# ---------------------------------------------------------------------------
# Anomaly detection tests
# ---------------------------------------------------------------------------


class TestAnomalyDetection:
    """Tests for usage anomaly detection."""

    def test_no_anomalies_empty(self, engine: UsageAnalytics) -> None:
        anomalies = engine.detect_anomalies()
        assert anomalies == []

    def test_no_anomalies_uniform(self) -> None:
        """Uniform traffic should produce no anomalies."""
        eng = UsageAnalytics(config=AnalyticsConfig(anomaly_sensitivity=2.0))
        now = time.time()
        for i in range(24):
            eng.record(UsageRecord(
                timestamp=now - (i * 3600),
                model="gpt-4o",
                provider="openai",
                cost_usd=0.005,
            ))
        anomalies = eng.detect_anomalies(bucket_size=BucketSize.HOURLY)
        # All buckets have exactly 1 request, so stdev=0 -> no anomalies
        assert len(anomalies) == 0

    def test_spike_detected(self) -> None:
        """A sudden spike in one bucket should be detected."""
        eng = UsageAnalytics(config=AnalyticsConfig(anomaly_sensitivity=1.5))
        now = time.time()
        # Normal: 1 request per hour for 10 hours
        for i in range(1, 11):
            eng.record(UsageRecord(
                timestamp=now - (i * 3600),
                model="gpt-4o",
                provider="openai",
                cost_usd=0.005,
            ))
        # Spike: 20 requests in the current hour
        for _ in range(20):
            eng.record(UsageRecord(
                timestamp=now,
                model="gpt-4o",
                provider="openai",
                cost_usd=0.005,
            ))
        anomalies = eng.detect_anomalies(bucket_size=BucketSize.HOURLY)
        spike_anomalies = [a for a in anomalies if a.direction == "spike"]
        assert len(spike_anomalies) > 0

    def test_anomaly_has_severity(self) -> None:
        eng = UsageAnalytics(config=AnalyticsConfig(anomaly_sensitivity=1.0))
        now = time.time()
        for i in range(1, 11):
            eng.record(UsageRecord(
                timestamp=now - (i * 3600),
                cost_usd=0.001,
            ))
        for _ in range(50):
            eng.record(UsageRecord(timestamp=now, cost_usd=0.01))
        anomalies = eng.detect_anomalies(bucket_size=BucketSize.HOURLY)
        for a in anomalies:
            assert isinstance(a, AnomalyDetection)
            assert a.severity > 0.0

    def test_anomalies_sorted_by_severity(self) -> None:
        eng = UsageAnalytics(config=AnalyticsConfig(anomaly_sensitivity=1.0))
        now = time.time()
        for i in range(1, 11):
            eng.record(UsageRecord(timestamp=now - (i * 3600), cost_usd=0.001))
        for _ in range(50):
            eng.record(UsageRecord(timestamp=now, cost_usd=0.05))
        anomalies = eng.detect_anomalies(bucket_size=BucketSize.HOURLY)
        for i in range(len(anomalies) - 1):
            assert anomalies[i].severity >= anomalies[i + 1].severity

    def test_too_few_buckets(self) -> None:
        """With fewer than 3 buckets, no anomalies should be detected."""
        eng = UsageAnalytics()
        now = time.time()
        eng.record(UsageRecord(timestamp=now, cost_usd=0.01))
        eng.record(UsageRecord(timestamp=now - 3600, cost_usd=0.01))
        anomalies = eng.detect_anomalies(bucket_size=BucketSize.HOURLY)
        assert anomalies == []


# ---------------------------------------------------------------------------
# Export tests
# ---------------------------------------------------------------------------


class TestExport:
    """Tests for the export method."""

    def test_export_structure(self, populated_engine: UsageAnalytics) -> None:
        data = populated_engine.export()
        required_keys = {
            "summary", "providers", "time_series", "sessions",
            "peaks", "anomalies", "token_consumption", "latency_percentiles",
        }
        assert required_keys.issubset(data.keys())

    def test_export_summary(self, populated_engine: UsageAnalytics) -> None:
        data = populated_engine.export()
        summary = data["summary"]
        assert summary["total_requests"] == populated_engine.record_count
        assert summary["total_cost_usd"] > 0
        assert summary["total_errors"] == 5
        assert summary["unique_providers"] == 3

    def test_export_empty(self, engine: UsageAnalytics) -> None:
        data = engine.export()
        assert data["summary"]["total_requests"] == 0
        assert data["providers"] == []
        assert data["time_series"] == []

    def test_export_providers_list(self, populated_engine: UsageAnalytics) -> None:
        data = populated_engine.export()
        provider_names = {p["provider"] for p in data["providers"]}
        assert "openai" in provider_names
        assert "anthropic" in provider_names

    def test_export_latency_percentiles(self, populated_engine: UsageAnalytics) -> None:
        data = populated_engine.export()
        lp = data["latency_percentiles"]
        assert "p50" in lp
        assert "p99" in lp


# ---------------------------------------------------------------------------
# Edge case tests
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Tests for edge cases and boundary conditions."""

    def test_single_record_export(self) -> None:
        eng = UsageAnalytics()
        eng.record(UsageRecord(
            model="gpt-4o",
            provider="openai",
            tokens_in=100,
            tokens_out=50,
            latency_ms=200.0,
            cost_usd=0.001,
            success=True,
            session_id="s1",
        ))
        data = eng.export()
        assert data["summary"]["total_requests"] == 1
        assert len(data["providers"]) == 1

    def test_all_failures(self) -> None:
        eng = UsageAnalytics()
        for _ in range(10):
            eng.record(UsageRecord(
                success=False,
                error_type="server_error",
                provider="openai",
            ))
        assert eng.error_rate() == 1.0
        breakdown = eng.error_breakdown()
        assert breakdown["server_error"] == 10

    def test_zero_latency_records(self) -> None:
        eng = UsageAnalytics()
        eng.record(UsageRecord(latency_ms=0.0))
        result = eng.latency_percentiles()
        assert result["p50"] == 0.0

    def test_custom_config(self, config: AnalyticsConfig) -> None:
        eng = UsageAnalytics(config=config)
        assert eng._config.bucket_size == BucketSize.DAILY
        assert eng._config.anomaly_sensitivity == 1.5

    def test_mixed_sessions_and_no_session(self) -> None:
        eng = UsageAnalytics()
        eng.record(UsageRecord(session_id="s1", cost_usd=0.01))
        eng.record(UsageRecord(session_id="", cost_usd=0.02))
        eng.record(UsageRecord(session_id="s1", cost_usd=0.03))
        reports = eng.session_reports()
        # Should have 2 sessions: "s1" and "_default"
        assert len(reports) == 2
        session_ids = {r.session_id for r in reports}
        assert "s1" in session_ids
        assert "_default" in session_ids

    def test_provider_report_no_errors_full_success(self) -> None:
        eng = UsageAnalytics()
        for _ in range(10):
            eng.record(UsageRecord(
                provider="anthropic",
                success=True,
                latency_ms=100.0,
            ))
        report = eng.provider_report("anthropic")
        assert report.success_rate == 1.0
        assert report.error_breakdown == {}
