"""Tests for the cost analytics and optimization intelligence engine."""

from __future__ import annotations

import time

import pytest

from prism.cost.analytics import (
    BudgetForecast,
    CostAnalytics,
    CostRecord,
    ModelROI,
    Period,
    Recommendation,
    SpendingReport,
    SpendingTrend,
    _percentile,
    _safe_mean,
    _safe_std,
)


@pytest.fixture()
def analytics() -> CostAnalytics:
    return CostAnalytics(monthly_budget_usd=50.0)


@pytest.fixture()
def populated_analytics() -> CostAnalytics:
    """Analytics engine with diverse cost data."""
    a = CostAnalytics(monthly_budget_usd=50.0)
    now = time.time()

    # GPT-4o records — expensive, high quality
    for i in range(20):
        a.add_record(CostRecord(
            model="gpt-4o",
            provider="openai",
            tokens_in=500,
            tokens_out=200,
            cost_usd=0.005,
            quality_score=0.85,
            latency_ms=450.0,
            timestamp=now - (i * 3600),
            task_type="code",
        ))

    # Claude Haiku records — cheap, decent quality
    for i in range(30):
        a.add_record(CostRecord(
            model="claude-haiku",
            provider="anthropic",
            tokens_in=500,
            tokens_out=200,
            cost_usd=0.001,
            quality_score=0.75,
            latency_ms=200.0,
            timestamp=now - (i * 3600),
            task_type="chat",
        ))

    # Some cached records
    for i in range(10):
        a.add_record(CostRecord(
            model="gpt-4o",
            provider="openai",
            tokens_in=500,
            tokens_out=200,
            cost_usd=0.005,
            quality_score=0.85,
            latency_ms=5.0,
            cached=True,
            timestamp=now - (i * 3600),
            task_type="code",
        ))

    # Some low quality records (waste)
    for i in range(5):
        a.add_record(CostRecord(
            model="gpt-4o",
            provider="openai",
            tokens_in=500,
            tokens_out=50,
            cost_usd=0.004,
            quality_score=0.2,
            latency_ms=300.0,
            timestamp=now - (i * 7200),
            task_type="analysis",
        ))

    return a


# ---------------------------------------------------------------------------
# Utility function tests
# ---------------------------------------------------------------------------


class TestUtilities:
    """Tests for statistical utility functions."""

    def test_safe_mean_basic(self) -> None:
        assert _safe_mean([1.0, 2.0, 3.0]) == 2.0

    def test_safe_mean_empty(self) -> None:
        assert _safe_mean([]) == 0.0

    def test_safe_std_basic(self) -> None:
        std = _safe_std([2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0])
        assert abs(std - 2.138) < 0.01

    def test_safe_std_single(self) -> None:
        assert _safe_std([5.0]) == 0.0

    def test_percentile_empty(self) -> None:
        assert _percentile([], 0.95) == 0.0

    def test_percentile_p50(self) -> None:
        assert _percentile([1.0, 2.0, 3.0, 4.0, 5.0], 0.5) == 3.0

    def test_percentile_p95(self) -> None:
        vals = list(range(1, 101))
        p95 = _percentile([float(x) for x in vals], 0.95)
        assert p95 >= 95.0


# ---------------------------------------------------------------------------
# Recording tests
# ---------------------------------------------------------------------------


class TestRecording:
    """Tests for cost event recording."""

    def test_record_creates_entry(self, analytics: CostAnalytics) -> None:
        rec = analytics.record(model="gpt-4o", cost_usd=0.005)
        assert isinstance(rec, CostRecord)
        assert rec.model == "gpt-4o"
        assert rec.cost_usd == 0.005

    def test_record_count(self, analytics: CostAnalytics) -> None:
        analytics.record(model="gpt-4o", cost_usd=0.01)
        analytics.record(model="claude-haiku", cost_usd=0.001)
        assert analytics.record_count == 2

    def test_add_record(self, analytics: CostAnalytics) -> None:
        rec = CostRecord(model="test", cost_usd=0.01)
        analytics.add_record(rec)
        assert analytics.record_count == 1

    def test_clear(self, analytics: CostAnalytics) -> None:
        analytics.record(model="test", cost_usd=0.01)
        analytics.clear()
        assert analytics.record_count == 0


# ---------------------------------------------------------------------------
# Spending report tests
# ---------------------------------------------------------------------------


class TestSpendingReport:
    """Tests for the spending report."""

    def test_empty_report(self, analytics: CostAnalytics) -> None:
        report = analytics.get_spending_report()
        assert report.total_cost_usd == 0.0
        assert report.total_requests == 0

    def test_report_structure(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report(period_days=30)
        assert isinstance(report, SpendingReport)
        assert report.total_cost_usd > 0
        assert report.total_requests > 0

    def test_cost_by_model(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert "gpt-4o" in report.cost_by_model
        assert "claude-haiku" in report.cost_by_model

    def test_cost_by_provider(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert "openai" in report.cost_by_provider
        assert "anthropic" in report.cost_by_provider

    def test_cost_by_task(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert "code" in report.cost_by_task
        assert "chat" in report.cost_by_task

    def test_model_roi_computed(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert len(report.model_roi) > 0
        for roi in report.model_roi:
            assert isinstance(roi, ModelROI)
            assert roi.total_cost >= 0
            assert roi.quality_per_dollar >= 0

    def test_roi_sorted_by_quality_per_dollar(
        self, populated_analytics: CostAnalytics,
    ) -> None:
        report = populated_analytics.get_spending_report()
        if len(report.model_roi) >= 2:
            for i in range(len(report.model_roi) - 1):
                assert (
                    report.model_roi[i].quality_per_dollar
                    >= report.model_roi[i + 1].quality_per_dollar
                )

    def test_trend_computed(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert isinstance(report.trend, SpendingTrend)
        assert report.trend.total > 0

    def test_forecast_computed(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert isinstance(report.forecast, BudgetForecast)
        assert report.forecast.predicted_monthly_usd >= 0

    def test_cache_savings(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert report.cache_savings_usd > 0

    def test_waste_pct(self, populated_analytics: CostAnalytics) -> None:
        report = populated_analytics.get_spending_report()
        assert report.waste_pct >= 0


# ---------------------------------------------------------------------------
# Recommendation tests
# ---------------------------------------------------------------------------


class TestRecommendations:
    """Tests for optimization recommendations."""

    def test_recommendations_generated(
        self, populated_analytics: CostAnalytics,
    ) -> None:
        report = populated_analytics.get_spending_report()
        assert len(report.recommendations) > 0

    def test_recommendation_structure(
        self, populated_analytics: CostAnalytics,
    ) -> None:
        report = populated_analytics.get_spending_report()
        for rec in report.recommendations:
            assert isinstance(rec, Recommendation)
            assert len(rec.title) > 0
            assert len(rec.description) > 0
            assert rec.estimated_savings_usd >= 0
            assert 0 <= rec.confidence <= 1
            assert 1 <= rec.priority <= 5

    def test_recommendations_sorted_by_savings(
        self, populated_analytics: CostAnalytics,
    ) -> None:
        report = populated_analytics.get_spending_report()
        if len(report.recommendations) >= 2:
            for i in range(len(report.recommendations) - 1):
                assert (
                    report.recommendations[i].estimated_savings_usd
                    >= report.recommendations[i + 1].estimated_savings_usd
                )

    def test_high_waste_triggers_recommendation(self) -> None:
        a = CostAnalytics()
        now = time.time()
        # All low quality
        for i in range(50):
            a.add_record(CostRecord(
                model="bad-model",
                cost_usd=0.01,
                quality_score=0.1,
                timestamp=now - (i * 3600),
            ))
        report = a.get_spending_report()
        titles = [r.title for r in report.recommendations]
        assert any("low-quality" in t.lower() for t in titles)


# ---------------------------------------------------------------------------
# Model comparison tests
# ---------------------------------------------------------------------------


class TestModelComparison:
    """Tests for model comparison."""

    def test_comparison(self, populated_analytics: CostAnalytics) -> None:
        comparison = populated_analytics.get_model_comparison()
        assert len(comparison) >= 2
        for entry in comparison:
            assert "model" in entry
            assert "requests" in entry
            assert "total_cost" in entry
            assert "avg_quality" in entry

    def test_comparison_empty(self, analytics: CostAnalytics) -> None:
        comparison = analytics.get_model_comparison()
        assert len(comparison) == 0


# ---------------------------------------------------------------------------
# Daily costs tests
# ---------------------------------------------------------------------------


class TestDailyCosts:
    """Tests for daily cost breakdown."""

    def test_daily_costs(self, populated_analytics: CostAnalytics) -> None:
        daily = populated_analytics.get_daily_costs(days=30)
        assert len(daily) > 0
        for entry in daily:
            assert "date" in entry
            assert "cost_usd" in entry
            assert "requests" in entry

    def test_daily_costs_empty(self, analytics: CostAnalytics) -> None:
        daily = analytics.get_daily_costs()
        assert len(daily) == 0
