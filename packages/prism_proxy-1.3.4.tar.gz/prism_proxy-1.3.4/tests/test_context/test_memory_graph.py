"""Tests for the conversation memory graph system."""

from __future__ import annotations

import threading
import time
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from pathlib import Path

from prism.context.memory_graph import (
    ConversationTracker,
    MemoryEdge,
    MemoryGraph,
    MemoryNode,
    NodeType,
    Relationship,
    _compute_embedding_hash,
    _tokenize,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def graph() -> MemoryGraph:
    """Create an in-memory MemoryGraph for testing."""
    g = MemoryGraph(db_path=":memory:")
    yield g
    g.close()


@pytest.fixture()
def populated_graph(graph: MemoryGraph) -> MemoryGraph:
    """Create a graph with several pre-populated nodes and edges."""
    n1 = graph.add_memory("Python is the primary language", "fact", importance=0.8)
    n2 = graph.add_memory("User prefers dark mode", "preference", importance=0.7)
    n3 = graph.add_memory("FastAPI framework for web", "fact", importance=0.6)
    n4 = graph.add_memory("Deployed last Friday", "event", importance=0.4)
    n5 = graph.add_memory("Authentication system", "concept", importance=0.9)

    graph.connect(n1, n3, "related_to", weight=0.8)
    graph.connect(n3, n5, "depends_on", weight=0.9)
    graph.connect(n4, n5, "references", weight=0.5)
    graph.connect(n2, n1, "related_to", weight=0.3)

    return graph


@pytest.fixture()
def tracker(graph: MemoryGraph) -> ConversationTracker:
    """Create a ConversationTracker backed by an in-memory graph."""
    return ConversationTracker(graph)


@pytest.fixture()
def disk_graph(tmp_path: Path) -> MemoryGraph:
    """Create a MemoryGraph backed by a temp SQLite file."""
    db = tmp_path / "test_memory.db"
    g = MemoryGraph(db_path=db)
    yield g
    g.close()


# ---------------------------------------------------------------------------
# Tokenizer tests
# ---------------------------------------------------------------------------


class TestTokenizer:
    """Tests for the _tokenize helper."""

    def test_basic_tokenization(self) -> None:
        tokens = _tokenize("hello world testing")
        assert "hello" in tokens
        assert "world" in tokens
        assert "testing" in tokens

    def test_stop_words_removed(self) -> None:
        tokens = _tokenize("the user is very happy with this")
        assert "the" not in tokens
        assert "is" not in tokens
        assert "very" not in tokens
        assert "happy" in tokens

    def test_camel_case_split(self) -> None:
        tokens = _tokenize("getUserName processPayment")
        assert "get" in tokens
        assert "user" in tokens
        assert "name" in tokens

    def test_snake_case_split(self) -> None:
        tokens = _tokenize("get_user_name")
        assert "get" in tokens
        assert "user" in tokens
        assert "name" in tokens

    def test_empty_input(self) -> None:
        assert _tokenize("") == []

    def test_short_words_removed(self) -> None:
        tokens = _tokenize("a b c dd ee")
        assert "a" not in tokens
        assert "b" not in tokens
        assert "dd" in tokens


class TestEmbeddingHash:
    """Tests for _compute_embedding_hash."""

    def test_same_content_same_hash(self) -> None:
        h1 = _compute_embedding_hash("hello world")
        h2 = _compute_embedding_hash("hello world")
        assert h1 == h2

    def test_different_content_different_hash(self) -> None:
        h1 = _compute_embedding_hash("hello world")
        h2 = _compute_embedding_hash("goodbye universe")
        assert h1 != h2

    def test_order_independent(self) -> None:
        # Tokens are sorted before hashing, so word order should not matter
        h1 = _compute_embedding_hash("hello world")
        h2 = _compute_embedding_hash("world hello")
        assert h1 == h2

    def test_returns_hex_string(self) -> None:
        h = _compute_embedding_hash("testing")
        assert isinstance(h, str)
        assert len(h) == 64  # SHA-256 hex digest


# ---------------------------------------------------------------------------
# MemoryNode / MemoryEdge dataclass tests
# ---------------------------------------------------------------------------


class TestDataclasses:
    """Tests for MemoryNode and MemoryEdge dataclasses."""

    def test_memory_node_fields(self) -> None:
        node = MemoryNode(
            id="abc",
            content="test",
            node_type="fact",
            timestamp=1000.0,
            importance_score=0.5,
            access_count=0,
            embedding_hash="deadbeef",
        )
        assert node.id == "abc"
        assert node.content == "test"
        assert node.node_type == "fact"

    def test_memory_edge_fields(self) -> None:
        edge = MemoryEdge(
            source_id="a",
            target_id="b",
            relationship="related_to",
            weight=0.8,
            timestamp=1000.0,
        )
        assert edge.source_id == "a"
        assert edge.target_id == "b"
        assert edge.weight == 0.8

    def test_node_type_enum(self) -> None:
        assert NodeType.FACT.value == "fact"
        assert NodeType.PREFERENCE.value == "preference"
        assert NodeType.ENTITY.value == "entity"
        assert NodeType.EVENT.value == "event"
        assert NodeType.CONCEPT.value == "concept"

    def test_relationship_enum(self) -> None:
        assert Relationship.REFERENCES.value == "references"
        assert Relationship.DEPENDS_ON.value == "depends_on"
        assert Relationship.CONTRADICTS.value == "contradicts"
        assert Relationship.SUPERSEDES.value == "supersedes"
        assert Relationship.RELATED_TO.value == "related_to"


# ---------------------------------------------------------------------------
# MemoryGraph — Node operations
# ---------------------------------------------------------------------------


class TestMemoryGraphNodes:
    """Tests for node CRUD operations."""

    def test_add_memory_returns_id(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("test fact", "fact", importance=0.5)
        assert isinstance(nid, str)
        assert len(nid) > 0

    def test_add_memory_with_explicit_id(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("test", "fact", node_id="custom_id")
        assert nid == "custom_id"

    def test_add_memory_with_explicit_timestamp(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("test", "fact", timestamp=42.0)
        node = graph.get_node(nid)
        assert node is not None
        assert node.timestamp == 42.0

    def test_get_node_exists(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("Python is great", "fact", importance=0.8)
        node = graph.get_node(nid)
        assert node is not None
        assert node.content == "Python is great"
        assert node.node_type == "fact"
        assert node.importance_score == 0.8
        assert node.access_count == 0

    def test_get_node_not_found(self, graph: MemoryGraph) -> None:
        assert graph.get_node("nonexistent") is None

    def test_remove_node(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("to be removed", "fact")
        assert graph.remove_node(nid) is True
        assert graph.get_node(nid) is None

    def test_remove_node_not_found(self, graph: MemoryGraph) -> None:
        assert graph.remove_node("nonexistent") is False

    def test_remove_node_cascades_edges(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        n2 = graph.add_memory("node 2", "fact")
        graph.connect(n1, n2, "related_to")
        graph.remove_node(n1)
        # Edge should be gone too
        edges = graph.get_edges(n2)
        assert len(edges) == 0

    def test_add_memory_empty_content_raises(self, graph: MemoryGraph) -> None:
        with pytest.raises(ValueError, match="content must not be empty"):
            graph.add_memory("", "fact")

    def test_add_memory_whitespace_content_raises(self, graph: MemoryGraph) -> None:
        with pytest.raises(ValueError, match="content must not be empty"):
            graph.add_memory("   ", "fact")

    def test_add_memory_invalid_importance_raises(self, graph: MemoryGraph) -> None:
        with pytest.raises(ValueError, match="Importance must be between"):
            graph.add_memory("test", "fact", importance=1.5)

    def test_add_memory_negative_importance_raises(self, graph: MemoryGraph) -> None:
        with pytest.raises(ValueError, match="Importance must be between"):
            graph.add_memory("test", "fact", importance=-0.1)

    def test_add_memory_invalid_type_raises(self, graph: MemoryGraph) -> None:
        with pytest.raises(ValueError, match="Invalid node_type"):
            graph.add_memory("test", "invalid_type")

    def test_content_is_stripped(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("  padded content  ", "fact")
        node = graph.get_node(nid)
        assert node is not None
        assert node.content == "padded content"


# ---------------------------------------------------------------------------
# MemoryGraph — Edge operations
# ---------------------------------------------------------------------------


class TestMemoryGraphEdges:
    """Tests for edge CRUD operations."""

    def test_connect_creates_edge(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        n2 = graph.add_memory("node 2", "fact")
        graph.connect(n1, n2, "related_to", weight=0.7)
        edges = graph.get_edges(n1)
        assert len(edges) == 1
        assert edges[0].source_id == n1
        assert edges[0].target_id == n2
        assert edges[0].relationship == "related_to"
        assert edges[0].weight == 0.7

    def test_connect_upsert(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        n2 = graph.add_memory("node 2", "fact")
        graph.connect(n1, n2, "related_to", weight=0.3)
        graph.connect(n1, n2, "related_to", weight=0.9)
        edges = graph.get_edges(n1)
        assert len(edges) == 1
        assert edges[0].weight == 0.9

    def test_connect_invalid_relationship_raises(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        n2 = graph.add_memory("node 2", "fact")
        with pytest.raises(ValueError, match="Invalid relationship"):
            graph.connect(n1, n2, "invalid_rel")

    def test_connect_invalid_weight_raises(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        n2 = graph.add_memory("node 2", "fact")
        with pytest.raises(ValueError, match="Weight must be between"):
            graph.connect(n1, n2, "related_to", weight=2.0)

    def test_connect_missing_source_raises(self, graph: MemoryGraph) -> None:
        n2 = graph.add_memory("node 2", "fact")
        with pytest.raises(ValueError, match="Source node.*does not exist"):
            graph.connect("nonexistent", n2, "related_to")

    def test_connect_missing_target_raises(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        with pytest.raises(ValueError, match="Target node.*does not exist"):
            graph.connect(n1, "nonexistent", "related_to")

    def test_get_edges_both_directions(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        n2 = graph.add_memory("node 2", "fact")
        n3 = graph.add_memory("node 3", "fact")
        graph.connect(n1, n2, "related_to")
        graph.connect(n3, n1, "references")
        edges = graph.get_edges(n1)
        assert len(edges) == 2

    def test_remove_edge(self, graph: MemoryGraph) -> None:
        n1 = graph.add_memory("node 1", "fact")
        n2 = graph.add_memory("node 2", "fact")
        graph.connect(n1, n2, "related_to")
        assert graph.remove_edge(n1, n2, "related_to") is True
        assert len(graph.get_edges(n1)) == 0

    def test_remove_edge_not_found(self, graph: MemoryGraph) -> None:
        assert graph.remove_edge("a", "b", "related_to") is False


# ---------------------------------------------------------------------------
# MemoryGraph — Search
# ---------------------------------------------------------------------------


class TestMemoryGraphSearch:
    """Tests for TF-IDF search."""

    def test_search_finds_relevant(self, populated_graph: MemoryGraph) -> None:
        results = populated_graph.search("Python programming language")
        assert len(results) > 0
        assert any("Python" in r.node.content for r in results)

    def test_search_returns_scores(self, populated_graph: MemoryGraph) -> None:
        results = populated_graph.search("authentication system")
        assert len(results) > 0
        for r in results:
            assert 0.0 <= r.score <= 2.0  # boosted scores can exceed 1.0

    def test_search_results_sorted_by_score(self, populated_graph: MemoryGraph) -> None:
        results = populated_graph.search("Python FastAPI web")
        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_search_empty_query(self, graph: MemoryGraph) -> None:
        graph.add_memory("test content", "fact")
        results = graph.search("")
        assert results == []

    def test_search_no_matches(self, graph: MemoryGraph) -> None:
        graph.add_memory("hello world", "fact")
        results = graph.search("xyzxyzxyz completely unrelated gibberish")
        assert results == []

    def test_search_top_k_limit(self, graph: MemoryGraph) -> None:
        for i in range(20):
            graph.add_memory(f"memory about testing item number {i}", "fact")
        results = graph.search("testing", top_k=5)
        assert len(results) <= 5

    def test_search_increments_access_count(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("database query optimization", "concept", importance=0.9)
        graph.search("database query")
        node = graph.get_node(nid)
        assert node is not None
        assert node.access_count >= 1

    def test_search_matched_terms(self, populated_graph: MemoryGraph) -> None:
        results = populated_graph.search("Python language")
        assert len(results) > 0
        assert len(results[0].matched_terms) > 0

    def test_search_empty_graph(self, graph: MemoryGraph) -> None:
        results = graph.search("anything")
        assert results == []

    def test_search_importance_boost(self, graph: MemoryGraph) -> None:
        # Two nodes with same content but different importance
        graph.add_memory(
            "important testing content for search",
            "fact",
            importance=0.9,
            node_id="high",
        )
        graph.add_memory(
            "important testing content for search",
            "fact",
            importance=0.1,
            node_id="low",
        )
        results = graph.search("important testing content")
        assert len(results) == 2
        # Higher importance node should rank first
        assert results[0].node.id == "high"


# ---------------------------------------------------------------------------
# MemoryGraph — Graph traversal
# ---------------------------------------------------------------------------


class TestMemoryGraphTraversal:
    """Tests for BFS traversal (get_related)."""

    def test_get_related_direct_neighbors(self, populated_graph: MemoryGraph) -> None:
        populated_graph.stats()
        # Get the first node (Python fact)
        rows = populated_graph._conn.execute(
            "SELECT id FROM memory_nodes WHERE content LIKE '%Python%'"
        ).fetchall()
        python_id = rows[0]["id"]
        related = populated_graph.get_related(python_id, depth=1)
        assert len(related) > 0

    def test_get_related_depth_2(self, populated_graph: MemoryGraph) -> None:
        rows = populated_graph._conn.execute(
            "SELECT id FROM memory_nodes WHERE content LIKE '%Python%'"
        ).fetchall()
        python_id = rows[0]["id"]
        # Depth 2 should find more nodes than depth 1
        related_1 = populated_graph.get_related(python_id, depth=1)
        related_2 = populated_graph.get_related(python_id, depth=2)
        assert len(related_2) >= len(related_1)

    def test_get_related_excludes_start(self, populated_graph: MemoryGraph) -> None:
        rows = populated_graph._conn.execute(
            "SELECT id FROM memory_nodes LIMIT 1"
        ).fetchall()
        start_id = rows[0]["id"]
        related = populated_graph.get_related(start_id, depth=3)
        assert all(n.id != start_id for n in related)

    def test_get_related_depth_zero(self, populated_graph: MemoryGraph) -> None:
        rows = populated_graph._conn.execute(
            "SELECT id FROM memory_nodes LIMIT 1"
        ).fetchall()
        assert populated_graph.get_related(rows[0]["id"], depth=0) == []

    def test_get_related_nonexistent_node(self, graph: MemoryGraph) -> None:
        assert graph.get_related("nonexistent", depth=2) == []

    def test_get_related_isolated_node(self, graph: MemoryGraph) -> None:
        nid = graph.add_memory("isolated node", "fact")
        assert graph.get_related(nid, depth=2) == []


# ---------------------------------------------------------------------------
# MemoryGraph — Decay
# ---------------------------------------------------------------------------


class TestMemoryGraphDecay:
    """Tests for temporal importance decay."""

    def test_decay_reduces_importance(self, graph: MemoryGraph) -> None:
        # Create a node with old timestamp
        old_time = time.time() - 172800  # 2 days ago
        nid = graph.add_memory(
            "old memory content", "fact", importance=1.0, timestamp=old_time
        )
        updated = graph.decay(half_life_seconds=86400)
        assert updated > 0
        node = graph.get_node(nid)
        assert node is not None
        assert node.importance_score < 1.0

    def test_decay_respects_access_count(self, graph: MemoryGraph) -> None:
        old_time = time.time() - 172800
        n1 = graph.add_memory(
            "rarely accessed memory node", "fact", importance=1.0, timestamp=old_time
        )
        n2 = graph.add_memory(
            "frequently accessed memory node", "fact", importance=1.0, timestamp=old_time
        )
        # Simulate many accesses on n2 by directly updating
        graph._conn.execute(
            "UPDATE memory_nodes SET access_count = 100 WHERE id = ?", (n2,)
        )
        graph._conn.commit()

        graph.decay(half_life_seconds=86400)
        node1 = graph.get_node(n1)
        node2 = graph.get_node(n2)
        assert node1 is not None and node2 is not None
        # Frequently accessed node should retain more importance
        assert node2.importance_score > node1.importance_score

    def test_decay_minimum_floor(self, graph: MemoryGraph) -> None:
        very_old = time.time() - 365 * 86400  # 1 year ago
        nid = graph.add_memory(
            "ancient memory content", "fact", importance=0.1, timestamp=very_old
        )
        graph.decay(half_life_seconds=86400)
        node = graph.get_node(nid)
        assert node is not None
        assert node.importance_score >= 0.01

    def test_decay_no_update_for_recent(self, graph: MemoryGraph) -> None:
        # Very recent node should barely change
        nid = graph.add_memory("fresh memory content here", "fact", importance=0.5)
        graph.decay(half_life_seconds=86400)
        node = graph.get_node(nid)
        assert node is not None
        # Within a second, decay should be negligible
        assert node.importance_score > 0.49


# ---------------------------------------------------------------------------
# MemoryGraph — Consolidation
# ---------------------------------------------------------------------------


class TestMemoryGraphConsolidate:
    """Tests for memory consolidation (deduplication)."""

    def test_consolidate_exact_duplicates(self, graph: MemoryGraph) -> None:
        graph.add_memory("duplicate content here", "fact", importance=0.5)
        graph.add_memory("duplicate content here", "fact", importance=0.8)
        merged = graph.consolidate()
        assert merged >= 1
        assert graph.stats().node_count == 1

    def test_consolidate_keeps_higher_importance(self, graph: MemoryGraph) -> None:
        graph.add_memory("same content words", "fact", importance=0.3)
        graph.add_memory("same content words", "fact", importance=0.9)
        graph.consolidate()
        nodes = graph._conn.execute("SELECT * FROM memory_nodes").fetchall()
        assert len(nodes) == 1
        assert nodes[0]["importance_score"] == 0.9

    def test_consolidate_near_duplicates(self, graph: MemoryGraph) -> None:
        graph.add_memory(
            "python programming language backend",
            "fact",
            importance=0.6,
        )
        graph.add_memory(
            "python programming language backend development",
            "fact",
            importance=0.5,
        )
        merged = graph.consolidate(similarity_threshold=0.7)
        assert merged >= 1

    def test_consolidate_distinct_nodes_untouched(self, graph: MemoryGraph) -> None:
        graph.add_memory("python programming language", "fact")
        graph.add_memory("chocolate cake recipe", "fact")
        merged = graph.consolidate()
        assert merged == 0
        assert graph.stats().node_count == 2

    def test_consolidate_repoints_edges(self, graph: MemoryGraph) -> None:
        _n1 = graph.add_memory("original content alpha", "fact", importance=0.9)
        n2 = graph.add_memory("original content alpha", "fact", importance=0.3)
        n3 = graph.add_memory("completely different topic here", "fact")
        graph.connect(n2, n3, "related_to", weight=0.7)
        graph.consolidate()
        # The edge from n2->n3 should now be n1->n3
        edges = graph.get_edges(n3)
        assert len(edges) >= 1
        # n2 should be gone
        assert graph.get_node(n2) is None


# ---------------------------------------------------------------------------
# MemoryGraph — Context retrieval
# ---------------------------------------------------------------------------


class TestContextMemories:
    """Tests for get_context_memories."""

    def test_returns_formatted_string(self, populated_graph: MemoryGraph) -> None:
        context = populated_graph.get_context_memories("Python programming")
        assert isinstance(context, str)
        assert "[Conversation Memory]" in context

    def test_empty_for_no_matches(self, graph: MemoryGraph) -> None:
        graph.add_memory("hello world greeting", "fact")
        context = graph.get_context_memories("xyzxyz nonexistent gibberish")
        assert context == ""

    def test_respects_budget(self, graph: MemoryGraph) -> None:
        for i in range(50):
            graph.add_memory(
                f"memory about software engineering topic number {i} with extra words",
                "fact",
                importance=0.8,
            )
        context = graph.get_context_memories("software engineering", budget_tokens=50)
        # Should not include all 50 memories
        assert context.count("- [fact]") < 50

    def test_empty_graph_returns_empty(self, graph: MemoryGraph) -> None:
        assert graph.get_context_memories("anything") == ""


# ---------------------------------------------------------------------------
# MemoryGraph — Pruning
# ---------------------------------------------------------------------------


class TestMemoryGraphPrune:
    """Tests for graph pruning."""

    def test_prune_removes_least_important(self, graph: MemoryGraph) -> None:
        for i in range(20):
            graph.add_memory(
                f"memory item {i}",
                "fact",
                importance=i / 20.0,
            )
        removed = graph.prune(max_nodes=10)
        assert removed == 10
        assert graph.stats().node_count == 10

    def test_prune_no_op_under_limit(self, graph: MemoryGraph) -> None:
        for i in range(5):
            graph.add_memory(f"item {i}", "fact")
        removed = graph.prune(max_nodes=10)
        assert removed == 0
        assert graph.stats().node_count == 5

    def test_prune_keeps_important(self, graph: MemoryGraph) -> None:
        important_id = graph.add_memory(
            "critical memory", "fact", importance=1.0, node_id="important"
        )
        for i in range(10):
            graph.add_memory(f"low importance item {i}", "fact", importance=0.01)
        graph.prune(max_nodes=5)
        assert graph.get_node(important_id) is not None


# ---------------------------------------------------------------------------
# MemoryGraph — DOT export
# ---------------------------------------------------------------------------


class TestMemoryGraphExport:
    """Tests for DOT export."""

    def test_export_dot_empty(self, graph: MemoryGraph) -> None:
        dot = graph.export_dot()
        assert "digraph MemoryGraph" in dot
        assert dot.strip().endswith("}")

    def test_export_dot_with_nodes(self, populated_graph: MemoryGraph) -> None:
        dot = populated_graph.export_dot()
        assert "digraph MemoryGraph" in dot
        assert "Python" in dot
        assert "related_to" in dot
        assert "fillcolor" in dot

    def test_export_dot_escapes_quotes(self, graph: MemoryGraph) -> None:
        graph.add_memory('content with "quotes" inside', "fact")
        dot = graph.export_dot()
        # Should not break DOT syntax
        assert '\\"' in dot


# ---------------------------------------------------------------------------
# MemoryGraph — Statistics
# ---------------------------------------------------------------------------


class TestMemoryGraphStats:
    """Tests for graph statistics."""

    def test_stats_empty_graph(self, graph: MemoryGraph) -> None:
        s = graph.stats()
        assert s.node_count == 0
        assert s.edge_count == 0
        assert s.avg_importance == 0.0
        assert s.oldest_memory is None
        assert s.newest_memory is None

    def test_stats_populated(self, populated_graph: MemoryGraph) -> None:
        s = populated_graph.stats()
        assert s.node_count == 5
        assert s.edge_count == 4
        assert s.avg_importance > 0
        assert "fact" in s.node_type_counts
        assert "preference" in s.node_type_counts
        assert s.oldest_memory is not None
        assert s.newest_memory is not None
        assert s.newest_memory >= s.oldest_memory

    def test_stats_relationship_counts(self, populated_graph: MemoryGraph) -> None:
        s = populated_graph.stats()
        assert "related_to" in s.relationship_counts
        assert "depends_on" in s.relationship_counts
        assert "references" in s.relationship_counts


# ---------------------------------------------------------------------------
# MemoryGraph — Thread safety
# ---------------------------------------------------------------------------


class TestMemoryGraphThreadSafety:
    """Tests for concurrent access."""

    def test_concurrent_writes(self, graph: MemoryGraph) -> None:
        errors: list[Exception] = []

        def add_nodes(prefix: str) -> None:
            try:
                for i in range(20):
                    graph.add_memory(f"{prefix} memory item {i}", "fact")
            except Exception as exc:
                errors.append(exc)

        threads = [
            threading.Thread(target=add_nodes, args=(f"thread_{t}",))
            for t in range(4)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        assert graph.stats().node_count == 80


# ---------------------------------------------------------------------------
# MemoryGraph — Persistence
# ---------------------------------------------------------------------------


class TestMemoryGraphPersistence:
    """Tests for disk-backed persistence."""

    def test_persists_to_disk(self, tmp_path: Path) -> None:
        db_path = tmp_path / "persist.db"
        g1 = MemoryGraph(db_path=db_path)
        nid = g1.add_memory("persisted content", "fact", importance=0.7)
        g1.close()

        g2 = MemoryGraph(db_path=db_path)
        node = g2.get_node(nid)
        assert node is not None
        assert node.content == "persisted content"
        assert node.importance_score == 0.7
        g2.close()


# ---------------------------------------------------------------------------
# ConversationTracker
# ---------------------------------------------------------------------------


class TestConversationTracker:
    """Tests for the ConversationTracker."""

    def test_process_turn_preference(self, tracker: ConversationTracker) -> None:
        ids = tracker.process_turn(
            "user", "I prefer Python over JavaScript for backend development."
        )
        assert len(ids) > 0
        assert tracker.turn_count == 1

    def test_process_turn_fact(self, tracker: ConversationTracker) -> None:
        ids = tracker.process_turn(
            "user", "The project uses FastAPI with PostgreSQL."
        )
        assert len(ids) > 0

    def test_process_turn_entity(self, tracker: ConversationTracker) -> None:
        ids = tracker.process_turn(
            "user", "John Smith and Jane Doe are working on the feature."
        )
        # Should extract "John Smith" and "Jane Doe" as entities
        assert len(ids) > 0

    def test_process_turn_event(self, tracker: ConversationTracker) -> None:
        ids = tracker.process_turn(
            "user", "Yesterday we deployed the new authentication service."
        )
        assert len(ids) > 0

    def test_process_turn_empty_content(self, tracker: ConversationTracker) -> None:
        ids = tracker.process_turn("user", "")
        assert ids == []
        assert tracker.turn_count == 0

    def test_process_turn_assistant_no_preferences(
        self, tracker: ConversationTracker
    ) -> None:
        tracker.process_turn(
            "assistant", "I prefer to use structured responses."
        )
        # Assistant preferences should NOT be extracted
        pref_nodes = tracker._graph._conn.execute(
            "SELECT * FROM memory_nodes WHERE node_type = 'preference'"
        ).fetchall()
        assert len(pref_nodes) == 0

    def test_entity_cross_referencing(self, tracker: ConversationTracker) -> None:
        # Two entities in the same turn should be connected
        tracker.process_turn(
            "user", "John Smith and Jane Doe collaborate on Project Alpha."
        )
        stats = tracker._graph.stats()
        # At least one edge between co-occurring entities
        if stats.node_count >= 2:
            assert stats.edge_count >= 0  # Edges may or may not be created depending on extraction

    def test_get_conversation_context(
        self, tracker: ConversationTracker
    ) -> None:
        tracker.process_turn(
            "user", "We use pytest for testing our Python applications."
        )
        tracker.process_turn(
            "user", "The project runs on Docker containers in production."
        )
        context = tracker.get_conversation_context("testing framework")
        assert isinstance(context, str)

    def test_turn_count_increments(self, tracker: ConversationTracker) -> None:
        assert tracker.turn_count == 0
        tracker.process_turn("user", "Hello there, how are you doing today.")
        assert tracker.turn_count == 1
        tracker.process_turn("assistant", "Fine, thanks for asking about that.")
        assert tracker.turn_count == 2

    def test_min_content_length_filter(self, graph: MemoryGraph) -> None:
        tracker = ConversationTracker(graph, min_content_length=50)
        # Short preference should be filtered out
        tracker.process_turn("user", "I prefer dark mode.")
        pref_nodes = graph._conn.execute(
            "SELECT * FROM memory_nodes WHERE node_type = 'preference'"
        ).fetchall()
        assert len(pref_nodes) == 0

    def test_cross_turn_entity_references(
        self, tracker: ConversationTracker
    ) -> None:
        tracker.process_turn("user", "John Smith is the project lead for Team Alpha.")
        tracker.process_turn("user", "Jane Doe reports to John Smith on Team Alpha.")
        stats = tracker._graph.stats()
        # Should have created some cross-turn references
        assert stats.node_count >= 2


# ---------------------------------------------------------------------------
# Integration test
# ---------------------------------------------------------------------------


class TestIntegration:
    """End-to-end integration test."""

    def test_full_workflow(self, graph: MemoryGraph) -> None:
        """Test a complete workflow: add, search, traverse, decay, consolidate, prune."""
        # Add memories
        n1 = graph.add_memory("Python web framework", "concept", importance=0.9)
        n2 = graph.add_memory("User authentication login system", "concept", importance=0.8)
        n3 = graph.add_memory("Database migration scripts", "fact", importance=0.6)
        graph.add_memory("User prefers dark theme", "preference", importance=0.5)
        graph.add_memory("Sprint planning meeting yesterday", "event", importance=0.3)

        # Connect
        graph.connect(n1, n2, "related_to", weight=0.7)
        graph.connect(n2, n3, "depends_on", weight=0.8)
        graph.connect(n1, n3, "related_to", weight=0.4)

        # Search
        results = graph.search("authentication login")
        assert len(results) > 0

        # Traverse
        related = graph.get_related(n2, depth=2)
        assert len(related) > 0

        # Context
        context = graph.get_context_memories("web development", budget_tokens=500)
        assert "[Conversation Memory]" in context

        # Stats
        s = graph.stats()
        assert s.node_count == 5
        assert s.edge_count == 3

        # DOT export
        dot = graph.export_dot()
        assert "digraph" in dot

        # Decay (should not change much since nodes are fresh)
        graph.decay()

        # Consolidate (all unique, should not merge)
        graph.consolidate()
        assert graph.stats().node_count == 5

        # Prune to 3 nodes
        removed = graph.prune(max_nodes=3)
        assert removed == 2
        assert graph.stats().node_count == 3
