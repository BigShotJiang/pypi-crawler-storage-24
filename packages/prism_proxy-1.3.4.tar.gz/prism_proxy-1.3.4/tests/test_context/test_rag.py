"""Tests for the RAG (Retrieval-Augmented Generation) engine."""

from __future__ import annotations

from pathlib import Path

import pytest

from prism.context.rag import (
    RAGChunk,
    RAGEngine,
    RAGResult,
    RAGStats,
    _TFIDFIndex,
    _tokenize_code,
)


class TestTokenizer:
    """Tests for the code tokenizer."""

    def test_basic_words(self) -> None:
        tokens = _tokenize_code("hello world foo bar")
        assert "hello" in tokens
        assert "world" in tokens

    def test_camel_case_split(self) -> None:
        tokens = _tokenize_code("getUserName processPayment")
        assert "get" in tokens
        assert "user" in tokens
        assert "name" in tokens

    def test_snake_case_split(self) -> None:
        tokens = _tokenize_code("get_user_name process_payment")
        assert "get" in tokens
        assert "user" in tokens
        assert "name" in tokens

    def test_stop_words_removed(self) -> None:
        tokens = _tokenize_code("the quick brown fox is very fast")
        assert "the" not in tokens
        assert "is" not in tokens
        assert "very" not in tokens
        assert "quick" in tokens

    def test_short_words_removed(self) -> None:
        tokens = _tokenize_code("a b c dd eee")
        assert "a" not in tokens
        assert "b" not in tokens
        assert "dd" in tokens

    def test_empty_input(self) -> None:
        assert _tokenize_code("") == []

    def test_code_tokens(self) -> None:
        tokens = _tokenize_code("def authenticate_user(username, password):")
        assert "authenticate" in tokens
        assert "username" in tokens
        assert "password" in tokens


class TestTFIDFIndex:
    """Tests for the TF-IDF index."""

    @pytest.fixture()
    def index(self) -> _TFIDFIndex:
        idx = _TFIDFIndex()
        chunks = [
            RAGChunk("auth.py", 1, 10, "authenticate user login password", "python"),
            RAGChunk("db.py", 1, 10, "database query select insert update", "python"),
            RAGChunk("api.py", 1, 10, "http request response endpoint route", "python"),
            RAGChunk("auth.py", 11, 20, "token jwt verify session cookie", "python"),
        ]
        for chunk in chunks:
            tokens = _tokenize_code(chunk.content)
            idx.add_document(chunk, tokens)
        idx.build()
        return idx

    def test_search_relevant(self, index: _TFIDFIndex) -> None:
        results = index.search("user authentication login")
        assert len(results) > 0
        assert results[0].chunk.file_path == "auth.py"

    def test_search_database(self, index: _TFIDFIndex) -> None:
        results = index.search("database query")
        assert len(results) > 0
        assert results[0].chunk.file_path == "db.py"

    def test_search_no_results(self, index: _TFIDFIndex) -> None:
        results = index.search("xxxxxxxxxx yyyyyyyyy")
        assert len(results) == 0

    def test_search_empty_query(self, index: _TFIDFIndex) -> None:
        results = index.search("")
        assert len(results) == 0

    def test_top_k_limit(self, index: _TFIDFIndex) -> None:
        results = index.search("authenticate", top_k=2)
        assert len(results) <= 2

    def test_scores_in_range(self, index: _TFIDFIndex) -> None:
        results = index.search("authentication")
        for result in results:
            assert 0.0 <= result.score <= 1.0

    def test_results_sorted_by_score(self, index: _TFIDFIndex) -> None:
        results = index.search("user login session")
        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_matched_terms(self, index: _TFIDFIndex) -> None:
        results = index.search("database query")
        assert len(results) > 0
        assert len(results[0].matched_terms) > 0

    def test_document_count(self, index: _TFIDFIndex) -> None:
        assert index.document_count == 4

    def test_clear(self, index: _TFIDFIndex) -> None:
        index.clear()
        assert index.document_count == 0
        assert index.search("anything") == []


class TestRAGEngine:
    """Tests for the RAG engine with real filesystem."""

    @pytest.fixture()
    def project_dir(self, tmp_path: Path) -> Path:
        """Create a minimal project structure."""
        (tmp_path / "auth.py").write_text(
            "def authenticate(username, password):\n"
            "    # Check credentials against database\n"
            "    user = find_user_by_name(username)\n"
            "    if user and verify_password(password, user.hash):\n"
            "        return create_session(user)\n"
            "    return None\n\n"
            "def create_session(user):\n"
            "    token = generate_jwt(user.id)\n"
            "    return token\n"
        )
        (tmp_path / "database.py").write_text(
            "import sqlite3\n\n"
            "def connect():\n"
            "    return sqlite3.connect('app.db')\n\n"
            "def query(sql, params=None):\n"
            "    conn = connect()\n"
            "    cursor = conn.execute(sql, params or ())\n"
            "    return cursor.fetchall()\n"
        )
        (tmp_path / "api.py").write_text(
            "from flask import Flask, request, jsonify\n\n"
            "app = Flask(__name__)\n\n"
            "@app.route('/login', methods=['POST'])\n"
            "def login():\n"
            "    data = request.json\n"
            "    token = authenticate(data['username'], data['password'])\n"
            "    if token:\n"
            "        return jsonify({'token': token})\n"
            "    return jsonify({'error': 'Invalid credentials'}), 401\n"
        )
        (tmp_path / "readme.txt").write_text("This is a sample project.")
        # Create a file that should be skipped
        (tmp_path / "image.png").write_bytes(b"\x89PNG")
        return tmp_path

    @pytest.fixture()
    def engine(self, project_dir: Path) -> RAGEngine:
        return RAGEngine(project_root=project_dir)

    def test_index(self, engine: RAGEngine) -> None:
        stats = engine.index()
        assert isinstance(stats, RAGStats)
        assert stats.total_files >= 3
        assert stats.total_chunks >= 3
        assert stats.index_time_ms > 0

    def test_search_authentication(self, engine: RAGEngine) -> None:
        engine.index()
        results = engine.search("user authentication login")
        assert len(results) > 0
        # Should find auth.py
        file_paths = {r.chunk.file_path for r in results}
        assert any("auth" in fp for fp in file_paths)

    def test_search_database(self, engine: RAGEngine) -> None:
        engine.index()
        results = engine.search("database connection query")
        assert len(results) > 0
        file_paths = {r.chunk.file_path for r in results}
        assert any("database" in fp for fp in file_paths)

    def test_get_context_for_prompt(self, engine: RAGEngine) -> None:
        engine.index()
        context = engine.get_context_for_prompt("how does login work")
        assert isinstance(context, str)
        assert "Relevant code" in context
        assert "```" in context

    def test_get_context_empty_for_no_match(self, engine: RAGEngine) -> None:
        engine.index()
        context = engine.get_context_for_prompt("xyzxyzxyz nonexistent")
        # May still match some terms
        assert isinstance(context, str)

    def test_auto_index_on_search(self, engine: RAGEngine) -> None:
        # Should auto-index if not indexed yet
        results = engine.search("authenticate")
        assert isinstance(results, list)

    def test_incremental_index(self, engine: RAGEngine, project_dir: Path) -> None:
        stats1 = engine.index()
        # Second index (no changes) should be fast
        stats2 = engine.index()
        assert stats2.total_files == 0  # No new files

    def test_force_reindex(self, engine: RAGEngine) -> None:
        engine.index()
        stats = engine.index(force=True)
        assert stats.total_files >= 3

    def test_clear(self, engine: RAGEngine) -> None:
        engine.index()
        engine.clear()
        assert engine.get_stats() is None

    def test_get_stats(self, engine: RAGEngine) -> None:
        assert engine.get_stats() is None
        engine.index()
        stats = engine.get_stats()
        assert stats is not None
        assert stats.total_files >= 3

    def test_language_detection(self, engine: RAGEngine) -> None:
        engine.index()
        stats = engine.get_stats()
        assert stats is not None
        assert "python" in stats.languages

    def test_skips_binary_files(self, engine: RAGEngine) -> None:
        engine.index()
        results = engine.search("PNG")
        # Should not have indexed the binary file
        for result in results:
            assert not result.chunk.file_path.endswith(".png")

    def test_max_tokens_limit(self, engine: RAGEngine) -> None:
        engine.index()
        context = engine.get_context_for_prompt("authenticate", max_tokens=50)
        # Should be relatively short
        assert len(context.split()) < 200

    def test_chunk_overlap(self, project_dir: Path) -> None:
        # Create a large file
        large_content = "\n".join(
            f"def function_{i}():\n    return {i}" for i in range(100)
        )
        (project_dir / "large.py").write_text(large_content)
        engine = RAGEngine(project_root=project_dir, chunk_lines=20, chunk_overlap=5)
        engine.index()
        stats = engine.get_stats()
        assert stats is not None
        assert stats.total_chunks > 5  # Multiple chunks from large file
