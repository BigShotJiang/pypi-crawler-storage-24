"""Tests for the conversation history compressor."""

from __future__ import annotations

import pytest

from prism.context.conversation_compressor import (
    CompressionResult,
    ConversationCompressor,
    MessageImportance,
)


@pytest.fixture()
def compressor() -> ConversationCompressor:
    return ConversationCompressor(max_tokens=200, preserve_recent=2)


def _make_messages(n: int, words_per: int = 20) -> list[dict[str, str]]:
    """Create n alternating user/assistant messages."""
    msgs: list[dict[str, str]] = []
    for i in range(n):
        role = "user" if i % 2 == 0 else "assistant"
        content = f"Message {i}: " + " ".join(f"word{j}" for j in range(words_per))
        msgs.append({"role": role, "content": content})
    return msgs


# ---------------------------------------------------------------------------
# Basic compression
# ---------------------------------------------------------------------------


class TestBasicCompression:
    """Tests for basic compression behavior."""

    def test_empty_messages(self, compressor: ConversationCompressor) -> None:
        result = compressor.compress([])
        assert result.messages == []
        assert result.original_tokens == 0

    def test_short_conversation_unchanged(self) -> None:
        c = ConversationCompressor(max_tokens=5000)
        msgs = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]
        result = c.compress(msgs)
        assert len(result.messages) == 2
        assert result.compression_ratio == 1.0

    def test_long_conversation_compressed(self, compressor: ConversationCompressor) -> None:
        msgs = _make_messages(20, words_per=30)
        result = compressor.compress(msgs)
        assert isinstance(result, CompressionResult)
        assert result.compressed_tokens <= result.original_tokens
        assert len(result.messages) < len(msgs)

    def test_recent_messages_preserved(self, compressor: ConversationCompressor) -> None:
        msgs = _make_messages(20, words_per=30)
        result = compressor.compress(msgs)
        # Last 2 messages should be preserved
        assert result.messages[-1]["content"] == msgs[-1]["content"]
        assert result.messages[-2]["content"] == msgs[-2]["content"]

    def test_system_messages_preserved(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "system", "content": "You are a helpful assistant."},
            *_make_messages(20, words_per=30),
        ]
        result = compressor.compress(msgs)
        system_msgs = [m for m in result.messages if m["role"] == "system"]
        assert any("helpful assistant" in m["content"] for m in system_msgs)


# ---------------------------------------------------------------------------
# Importance scoring
# ---------------------------------------------------------------------------


class TestImportanceScoring:
    """Tests for message importance scoring."""

    def test_system_message_highest(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "system", "content": "System instruction."},
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi"},
        ]
        scores = compressor.score_messages(msgs)
        system_score = scores[0].score
        assert system_score > scores[1].score

    def test_code_content_boosted(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "user", "content": "plain text"},
            {"role": "assistant", "content": "Here is code:\n```python\ndef foo(): pass\n```"},
        ]
        scores = compressor.score_messages(msgs)
        assert scores[1].has_code
        assert scores[1].score > scores[0].score

    def test_recent_messages_boosted(self, compressor: ConversationCompressor) -> None:
        msgs = _make_messages(10)
        scores = compressor.score_messages(msgs)
        # Last message should score higher than first (same role)
        last_user = [s for s in scores if s.role == "user"]
        assert last_user[-1].score > last_user[0].score

    def test_error_content_boosted(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "user", "content": "some general text here"},
            {"role": "assistant", "content": "Error: traceback exception occurred in the code"},
        ]
        scores = compressor.score_messages(msgs)
        assert scores[1].score > scores[0].score

    def test_query_relevance(self, compressor: ConversationCompressor) -> None:
        # Use 3+ messages so recency doesn't dominate the comparison
        msgs = [
            {"role": "user", "content": "Tell me about authentication and login security."},
            {"role": "user", "content": "What's the weather like?"},
            {"role": "user", "content": "Another generic message here."},
        ]
        scores = compressor.score_messages(msgs, query="how does authentication login work")
        # First message should be more relevant to the query than second
        assert scores[0].score > scores[1].score

    def test_intent_detection(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "user", "content": "Please fix the bug in the login module and create tests"},
            {"role": "assistant", "content": "ok"},
            {"role": "user", "content": "ok thanks"},
        ]
        scores = compressor.score_messages(msgs)
        # First user msg has intent + error keywords, should beat last user
        assert scores[0].score >= scores[2].score

    def test_file_references_boosted(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "assistant", "content": "Modified src/auth/login.py executed successfully created file"},
            {"role": "user", "content": "filler message here"},
            {"role": "assistant", "content": "Done with that task."},
        ]
        scores = compressor.score_messages(msgs)
        # First assistant msg has file refs + tool indicators, should beat last
        assert scores[0].score >= scores[2].score

    def test_score_structure(self, compressor: ConversationCompressor) -> None:
        msgs = [{"role": "user", "content": "Hello world"}]
        scores = compressor.score_messages(msgs)
        assert len(scores) == 1
        assert isinstance(scores[0], MessageImportance)
        assert 0 <= scores[0].score <= 1
        assert scores[0].estimated_tokens > 0


# ---------------------------------------------------------------------------
# Compression result
# ---------------------------------------------------------------------------


class TestCompressionResult:
    """Tests for compression result structure."""

    def test_result_structure(self, compressor: ConversationCompressor) -> None:
        msgs = _make_messages(20, words_per=30)
        result = compressor.compress(msgs)
        assert isinstance(result, CompressionResult)
        assert result.original_tokens > 0
        assert result.compressed_tokens > 0
        assert result.compression_ratio > 0
        assert result.compression_ratio <= 1.0

    def test_compression_ratio_decreases(self, compressor: ConversationCompressor) -> None:
        msgs = _make_messages(30, words_per=50)
        result = compressor.compress(msgs)
        assert result.compression_ratio < 1.0

    def test_messages_accounted(self, compressor: ConversationCompressor) -> None:
        msgs = _make_messages(20, words_per=30)
        result = compressor.compress(msgs)
        total_accounted = (
            len(result.messages)
            + result.messages_removed
            + result.messages_summarized
        )
        # Should account for approximately all messages
        # (summarized messages become a single summary message)
        assert total_accounted >= len(msgs) - 5  # Allow some slack


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Tests for edge cases."""

    def test_only_system_messages(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "system", "content": "Rule 1"},
            {"role": "system", "content": "Rule 2"},
        ]
        result = compressor.compress(msgs)
        assert len(result.messages) >= 1

    def test_single_message(self, compressor: ConversationCompressor) -> None:
        msgs = [{"role": "user", "content": "Hello"}]
        result = compressor.compress(msgs)
        assert len(result.messages) == 1

    def test_all_code_messages(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "user", "content": "```python\ndef foo(): pass\n```"},
            {"role": "assistant", "content": "```python\ndef bar(): pass\n```"},
        ]
        result = compressor.compress(msgs)
        assert len(result.messages) >= 1

    def test_empty_content_messages(self, compressor: ConversationCompressor) -> None:
        msgs = [
            {"role": "user", "content": ""},
            {"role": "assistant", "content": "Response"},
        ]
        result = compressor.compress(msgs)
        assert isinstance(result, CompressionResult)

    def test_very_tight_budget(self) -> None:
        c = ConversationCompressor(max_tokens=10, preserve_recent=1)
        msgs = _make_messages(10, words_per=50)
        result = c.compress(msgs)
        # Should at least have the last message
        assert len(result.messages) >= 1
