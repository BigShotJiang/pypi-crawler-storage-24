"""Tests for smart context packing."""

from __future__ import annotations

import pytest

from prism.context.packer import ContextPacker, PackingResult


class TestContextPacker:
    """Tests for the ContextPacker class."""

    @pytest.fixture()
    def packer(self) -> ContextPacker:
        return ContextPacker(max_tokens=500, system_budget_pct=0.25)

    def test_empty_messages(self, packer: ContextPacker) -> None:
        result = packer.pack([])
        assert result.messages == []
        assert result.total_tokens == 0
        assert result.dropped_count == 0
        assert result.compressed_count == 0

    def test_single_message_fits(self, packer: ContextPacker) -> None:
        messages = [{"role": "user", "content": "Hello world"}]
        result = packer.pack(messages)
        assert len(result.messages) == 1
        assert result.messages[0]["content"] == "Hello world"
        assert result.dropped_count == 0

    def test_system_message_priority(self, packer: ContextPacker) -> None:
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hi"},
        ]
        result = packer.pack(messages)
        assert result.messages[0]["role"] == "system"
        assert result.messages[1]["role"] == "user"

    def test_last_user_message_highest_priority(self, packer: ContextPacker) -> None:
        messages = [
            {"role": "user", "content": "First question about A"},
            {"role": "assistant", "content": "Answer about A"},
            {"role": "user", "content": "Follow-up about B"},
        ]
        result = packer.pack(messages, current_prompt="Follow-up about B")
        # Last user message should always be present
        contents = [m["content"] for m in result.messages]
        assert "Follow-up about B" in contents

    def test_keyword_relevance_boost(self, packer: ContextPacker) -> None:
        messages = [
            {"role": "user", "content": "Tell me about Python sorting algorithms"},
            {"role": "assistant", "content": "Sorting in Python uses Timsort..."},
            {"role": "user", "content": "What about weather forecasting methods"},
            {"role": "assistant", "content": "Weather uses numerical models..."},
            {"role": "user", "content": "More about Python sorting performance"},
        ]
        result = packer.pack(messages, current_prompt="Python sorting performance")
        # Should prioritise messages about Python sorting over weather
        contents = " ".join(m["content"] for m in result.messages)
        assert "sorting" in contents.lower() or "Python" in contents

    def test_compression_when_over_budget(self) -> None:
        # Tiny budget forces compression
        packer = ContextPacker(max_tokens=20, system_budget_pct=0.25)
        long_content = "word " * 200
        messages = [{"role": "user", "content": long_content}]
        result = packer.pack(messages)
        assert result.total_tokens <= result.original_tokens
        assert result.compressed_count > 0 or result.dropped_count > 0

    def test_system_message_compression(self) -> None:
        packer = ContextPacker(max_tokens=50, system_budget_pct=0.2)
        long_system = "You must follow these rules. " * 100
        messages = [
            {"role": "system", "content": long_system},
            {"role": "user", "content": "Hello"},
        ]
        result = packer.pack(messages)
        # System message should be compressed, not dropped
        assert any(m["role"] == "system" for m in result.messages)
        assert result.compressed_count >= 1

    def test_code_aware_truncation(self) -> None:
        packer = ContextPacker(max_tokens=30, system_budget_pct=0.1)
        code = (
            "import os\n"
            "import sys\n\n"
            "def hello():\n"
            "    x = 1\n"
            "    y = 2\n"
            "    z = 3\n"
            "    w = 4\n"
            "    v = 5\n"
            "    return x + y + z\n\n"
            "def world():\n"
            "    a = 10\n"
            "    b = 20\n"
            "    c = 30\n"
            "    d = 40\n"
            "    e = 50\n"
            "    return a + b\n"
        )
        messages = [{"role": "user", "content": code}]
        result = packer.pack(messages)
        content = result.messages[0]["content"]
        # Should preserve imports and function signatures
        assert "import os" in content
        assert "def hello" in content

    def test_prose_truncation_at_sentence_boundary(self) -> None:
        # Budget allows some but not all content
        packer = ContextPacker(max_tokens=15, system_budget_pct=0.1, min_message_tokens=1)
        prose = (
            "First sentence here about algorithms. Second sentence about data structures. "
            "Third sentence about databases. Fourth sentence about networking. "
            "Fifth sentence about security. Sixth sentence about testing. "
            "Seventh sentence about deployment. Eighth sentence about monitoring."
        )
        messages = [{"role": "user", "content": prose}]
        result = packer.pack(messages)
        # Message should survive but may be compressed
        assert len(result.messages) >= 1
        if result.compressed_count > 0:
            content = result.messages[0]["content"]
            assert len(content) < len(prose)

    def test_multiple_messages_drop_low_priority(self) -> None:
        packer = ContextPacker(max_tokens=30, system_budget_pct=0.1)
        messages = [
            {"role": "user", "content": "First long message " * 20},
            {"role": "assistant", "content": "First response " * 20},
            {"role": "user", "content": "Second long message " * 20},
            {"role": "assistant", "content": "Second response " * 20},
            {"role": "user", "content": "Current question"},
        ]
        result = packer.pack(messages, current_prompt="Current question")
        # Current question should survive; some older ones may be dropped
        contents = [m["content"] for m in result.messages]
        assert "Current question" in contents
        assert result.dropped_count > 0 or result.compressed_count > 0

    def test_packing_result_fields(self, packer: ContextPacker) -> None:
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there"},
        ]
        result = packer.pack(messages)
        assert isinstance(result, PackingResult)
        assert isinstance(result.messages, list)
        assert isinstance(result.total_tokens, int)
        assert isinstance(result.dropped_count, int)
        assert isinstance(result.compressed_count, int)
        assert isinstance(result.original_tokens, int)
        assert result.original_tokens >= result.total_tokens

    def test_recency_bonus(self) -> None:
        packer = ContextPacker(max_tokens=25, system_budget_pct=0.1)
        messages = [
            {"role": "user", "content": "Very old message " * 15},
            {"role": "assistant", "content": "Old response " * 15},
            {"role": "user", "content": "Recent message"},
        ]
        result = packer.pack(messages)
        contents = [m["content"] for m in result.messages]
        # Recent message should always survive
        assert "Recent message" in contents

    def test_estimate_tokens(self) -> None:
        assert ContextPacker._estimate_tokens("") == 0
        assert ContextPacker._estimate_tokens("hello world foo bar") > 0
        # ~0.75 tokens per word
        tokens = ContextPacker._estimate_tokens("one two three four")
        assert tokens == 3  # 4 words * 0.75 = 3

    def test_min_message_tokens_drop(self) -> None:
        packer = ContextPacker(max_tokens=100, min_message_tokens=50)
        messages = [
            {"role": "user", "content": "tiny"},
            {"role": "user", "content": "Also tiny"},
        ]
        # With very high min_message_tokens, small messages may be dropped
        # during compression phase (but they still fit within budget normally)
        result = packer.pack(messages)
        # These should still fit since they're under budget total
        assert len(result.messages) >= 1
