"""Tests for prism.context.semantic_cache — SemanticCache."""

from __future__ import annotations

import threading
import time
from typing import TYPE_CHECKING

import pytest

from prism.context.semantic_cache import (
    CacheConfig,
    CacheEntry,
    CacheStats,
    SemanticCache,
    _cosine_similarity,
    _term_frequency,
    _tfidf_vector,
    _tokenize,
)
from prism.exceptions import ContextError

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def cache() -> SemanticCache:
    """Create a default in-memory SemanticCache."""
    return SemanticCache()


@pytest.fixture
def small_cache() -> SemanticCache:
    """Create a tiny cache (max 3 entries per model) for eviction tests."""
    return SemanticCache(CacheConfig(max_size=3, ttl_seconds=0))


@pytest.fixture
def short_ttl_cache() -> SemanticCache:
    """Cache with a 1-second TTL for expiration tests."""
    return SemanticCache(CacheConfig(ttl_seconds=1))


@pytest.fixture
def low_threshold_cache() -> SemanticCache:
    """Cache with a very low similarity threshold."""
    return SemanticCache(CacheConfig(similarity_threshold=0.3))


@pytest.fixture
def persisted_cache(tmp_path: Path) -> SemanticCache:
    """Create a SQLite-backed SemanticCache."""
    db_path = tmp_path / "cache.db"
    return SemanticCache(CacheConfig(persist_path=db_path))


# ---------------------------------------------------------------------------
# CacheConfig validation
# ---------------------------------------------------------------------------


class TestCacheConfig:
    def test_defaults(self) -> None:
        cfg = CacheConfig()
        assert cfg.max_size == 256
        assert cfg.ttl_seconds == 3600
        assert cfg.similarity_threshold == 0.85
        assert cfg.persist_path is None

    def test_max_size_zero_raises(self) -> None:
        with pytest.raises(ContextError, match="max_size"):
            CacheConfig(max_size=0)

    def test_negative_ttl_raises(self) -> None:
        with pytest.raises(ContextError, match="ttl_seconds"):
            CacheConfig(ttl_seconds=-1)

    def test_threshold_above_one_raises(self) -> None:
        with pytest.raises(ContextError, match="similarity_threshold"):
            CacheConfig(similarity_threshold=1.5)

    def test_threshold_below_zero_raises(self) -> None:
        with pytest.raises(ContextError, match="similarity_threshold"):
            CacheConfig(similarity_threshold=-0.1)

    def test_zero_ttl_valid(self) -> None:
        cfg = CacheConfig(ttl_seconds=0)
        assert cfg.ttl_seconds == 0

    def test_boundary_threshold_valid(self) -> None:
        cfg_low = CacheConfig(similarity_threshold=0.0)
        cfg_high = CacheConfig(similarity_threshold=1.0)
        assert cfg_low.similarity_threshold == 0.0
        assert cfg_high.similarity_threshold == 1.0


# ---------------------------------------------------------------------------
# CacheEntry
# ---------------------------------------------------------------------------


class TestCacheEntry:
    def test_defaults(self) -> None:
        now = time.time()
        entry = CacheEntry(
            prompt="hello", response="hi", model="gpt-4", timestamp=now
        )
        assert entry.hit_count == 0
        assert entry.last_accessed == now

    def test_last_accessed_auto_set(self) -> None:
        ts = 1000.0
        entry = CacheEntry(
            prompt="a", response="b", model="m", timestamp=ts
        )
        assert entry.last_accessed == ts


# ---------------------------------------------------------------------------
# CacheStats
# ---------------------------------------------------------------------------


class TestCacheStats:
    def test_initial_values(self) -> None:
        stats = CacheStats()
        assert stats.hits == 0
        assert stats.misses == 0
        assert stats.evictions == 0
        assert stats.avg_similarity == 0.0
        assert stats.hit_rate == 0.0
        assert stats.total_requests == 0

    def test_avg_similarity(self) -> None:
        stats = CacheStats(hits=2, total_similarity_sum=1.8)
        assert stats.avg_similarity == pytest.approx(0.9)

    def test_hit_rate(self) -> None:
        stats = CacheStats(hits=3, misses=7)
        assert stats.hit_rate == pytest.approx(0.3)

    def test_total_requests(self) -> None:
        stats = CacheStats(hits=5, misses=10)
        assert stats.total_requests == 15


# ---------------------------------------------------------------------------
# Tokeniser helpers
# ---------------------------------------------------------------------------


class TestTokenize:
    def test_basic(self) -> None:
        tokens = _tokenize("Hello World")
        assert tokens == ["hello", "world"]

    def test_with_punctuation(self) -> None:
        tokens = _tokenize("Hello, World! How's it?")
        assert "hello" in tokens
        assert "world" in tokens

    def test_empty_string(self) -> None:
        assert _tokenize("") == []

    def test_numbers(self) -> None:
        tokens = _tokenize("Python 3.12 is fast")
        assert "3" in tokens
        assert "12" in tokens
        assert "python" in tokens


# ---------------------------------------------------------------------------
# TF-IDF helpers
# ---------------------------------------------------------------------------


class TestTFIDF:
    def test_term_frequency_uniform(self) -> None:
        tf = _term_frequency(["a", "b", "c"])
        assert tf["a"] == pytest.approx(1 / 3)
        assert tf["b"] == pytest.approx(1 / 3)

    def test_term_frequency_repeated(self) -> None:
        tf = _term_frequency(["a", "a", "b"])
        assert tf["a"] == pytest.approx(2 / 3)
        assert tf["b"] == pytest.approx(1 / 3)

    def test_term_frequency_empty(self) -> None:
        assert _term_frequency([]) == {}

    def test_cosine_identical(self) -> None:
        vec = {"a": 1.0, "b": 2.0}
        assert _cosine_similarity(vec, vec) == pytest.approx(1.0)

    def test_cosine_orthogonal(self) -> None:
        vec_a = {"a": 1.0}
        vec_b = {"b": 1.0}
        assert _cosine_similarity(vec_a, vec_b) == pytest.approx(0.0)

    def test_cosine_empty(self) -> None:
        assert _cosine_similarity({}, {"a": 1.0}) == 0.0
        assert _cosine_similarity({"a": 1.0}, {}) == 0.0
        assert _cosine_similarity({}, {}) == 0.0

    def test_tfidf_vector_basic(self) -> None:
        tf = {"a": 0.5, "b": 0.5}
        idf_map = {"a": 2.0, "b": 1.0}
        vec = _tfidf_vector(tf, idf_map)
        assert vec["a"] == pytest.approx(1.0)
        assert vec["b"] == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# Exact-match cache hit
# ---------------------------------------------------------------------------


class TestExactMatch:
    def test_exact_prompt_returns_response(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "A programming language.", "gpt-4")
        result = cache.get("What is Python?", "gpt-4")
        assert result == "A programming language."

    def test_exact_match_increments_hit_count(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "A programming language.", "gpt-4")
        cache.get("What is Python?", "gpt-4")
        cache.get("What is Python?", "gpt-4")
        entries = cache.all_entries("gpt-4")
        assert entries[0].hit_count == 2


# ---------------------------------------------------------------------------
# Similar (but not identical) cache hit
# ---------------------------------------------------------------------------


class TestSimilarMatch:
    def test_similar_prompt_hits(self, low_threshold_cache: SemanticCache) -> None:
        low_threshold_cache.put(
            "Explain how Python decorators work",
            "Decorators wrap functions.",
            "gpt-4",
        )
        result = low_threshold_cache.get(
            "How do Python decorators work?", "gpt-4"
        )
        assert result == "Decorators wrap functions."

    def test_paraphrased_prompt_hits(self, low_threshold_cache: SemanticCache) -> None:
        low_threshold_cache.put(
            "What are the benefits of using TypeScript over JavaScript?",
            "Type safety, better tooling, maintainability.",
            "claude",
        )
        result = low_threshold_cache.get(
            "What are the benefits of TypeScript over JavaScript?", "claude"
        )
        assert result == "Type safety, better tooling, maintainability."


# ---------------------------------------------------------------------------
# Cache miss with dissimilar prompt
# ---------------------------------------------------------------------------


class TestCacheMiss:
    def test_completely_different_prompt(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "A programming language.", "gpt-4")
        result = cache.get("How to bake a chocolate cake?", "gpt-4")
        assert result is None

    def test_miss_increments_stat(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "A language.", "gpt-4")
        cache.get("How to bake a cake?", "gpt-4")
        assert cache.stats.misses == 1

    def test_empty_prompt_returns_none(self, cache: SemanticCache) -> None:
        cache.put("test prompt", "response", "model")
        assert cache.get("", "model") is None

    def test_whitespace_prompt_returns_none(self, cache: SemanticCache) -> None:
        cache.put("test prompt", "response", "model")
        assert cache.get("   ", "model") is None


# ---------------------------------------------------------------------------
# Per-model isolation
# ---------------------------------------------------------------------------


class TestModelIsolation:
    def test_different_models_isolated(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "Response from GPT", "gpt-4")
        cache.put("What is Python?", "Response from Claude", "claude-3")
        assert cache.get("What is Python?", "gpt-4") == "Response from GPT"
        assert cache.get("What is Python?", "claude-3") == "Response from Claude"

    def test_no_cross_model_hits(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "A language.", "gpt-4")
        assert cache.get("What is Python?", "claude-3") is None

    def test_clear_single_model(self, cache: SemanticCache) -> None:
        cache.put("prompt", "resp1", "gpt-4")
        cache.put("prompt", "resp2", "claude-3")
        cache.clear("gpt-4")
        assert cache.size("gpt-4") == 0
        assert cache.size("claude-3") == 1


# ---------------------------------------------------------------------------
# TTL expiration
# ---------------------------------------------------------------------------


class TestTTLExpiration:
    def test_entry_expires_after_ttl(self, short_ttl_cache: SemanticCache) -> None:
        short_ttl_cache.put("question", "answer", "gpt-4")
        assert short_ttl_cache.get("question", "gpt-4") == "answer"
        time.sleep(1.2)
        assert short_ttl_cache.get("question", "gpt-4") is None

    def test_zero_ttl_never_expires(self) -> None:
        cache = SemanticCache(CacheConfig(ttl_seconds=0))
        cache.put("question", "answer", "gpt-4")
        # We can't really wait forever, but confirm it works immediately.
        assert cache.get("question", "gpt-4") == "answer"

    def test_expiration_counted_as_eviction(
        self, short_ttl_cache: SemanticCache
    ) -> None:
        short_ttl_cache.put("q", "a", "m")
        time.sleep(1.2)
        short_ttl_cache.get("q", "m")
        assert short_ttl_cache.stats.evictions >= 1


# ---------------------------------------------------------------------------
# LRU eviction
# ---------------------------------------------------------------------------


class TestLRUEviction:
    def test_evicts_when_full(self, small_cache: SemanticCache) -> None:
        small_cache.put("prompt1", "resp1", "m")
        small_cache.put("prompt2", "resp2", "m")
        small_cache.put("prompt3", "resp3", "m")
        assert small_cache.size("m") == 3
        small_cache.put("prompt4", "resp4", "m")
        assert small_cache.size("m") == 3

    def test_evicts_least_recently_used(self, small_cache: SemanticCache) -> None:
        small_cache.put("alpha prompt", "resp1", "m")
        time.sleep(0.01)
        small_cache.put("beta prompt", "resp2", "m")
        time.sleep(0.01)
        small_cache.put("gamma prompt", "resp3", "m")

        # Access 'alpha' so it becomes recently used.
        small_cache.get("alpha prompt", "m")

        # Add a fourth entry — 'beta' (oldest access) should be evicted.
        small_cache.put("delta prompt", "resp4", "m")

        entries = small_cache.all_entries("m")
        prompts = {e.prompt for e in entries}
        assert "beta prompt" not in prompts
        assert "alpha prompt" in prompts

    def test_eviction_increments_stat(self, small_cache: SemanticCache) -> None:
        for i in range(4):
            small_cache.put(f"prompt number {i}", f"resp{i}", "m")
        assert small_cache.stats.evictions >= 1


# ---------------------------------------------------------------------------
# Statistics tracking
# ---------------------------------------------------------------------------


class TestStatistics:
    def test_hit_recorded(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "A language.", "gpt-4")
        cache.get("What is Python?", "gpt-4")
        assert cache.stats.hits == 1

    def test_miss_recorded(self, cache: SemanticCache) -> None:
        cache.get("anything", "gpt-4")
        assert cache.stats.misses == 1

    def test_hit_rate_calculated(self, cache: SemanticCache) -> None:
        cache.put("q", "a", "m")
        cache.get("q", "m")  # hit
        cache.get("something else entirely", "m")  # miss
        assert cache.stats.hit_rate == pytest.approx(0.5)

    def test_avg_similarity_positive_on_hit(self, cache: SemanticCache) -> None:
        cache.put("What is Python?", "A language.", "gpt-4")
        cache.get("What is Python?", "gpt-4")
        assert cache.stats.avg_similarity > 0.0

    def test_reset_stats(self, cache: SemanticCache) -> None:
        cache.put("q", "a", "m")
        cache.get("q", "m")
        cache.reset_stats()
        assert cache.stats.hits == 0
        assert cache.stats.misses == 0


# ---------------------------------------------------------------------------
# Thread safety
# ---------------------------------------------------------------------------


class TestThreadSafety:
    def test_concurrent_puts(self, cache: SemanticCache) -> None:
        errors: list[Exception] = []

        def writer(thread_id: int) -> None:
            try:
                for i in range(20):
                    cache.put(
                        f"thread {thread_id} prompt {i}",
                        f"response {i}",
                        "gpt-4",
                    )
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=writer, args=(t,)) for t in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert cache.size("gpt-4") > 0

    def test_concurrent_gets_and_puts(self, cache: SemanticCache) -> None:
        cache.put("initial prompt", "initial response", "m")
        errors: list[Exception] = []

        def reader() -> None:
            try:
                for _ in range(30):
                    cache.get("initial prompt", "m")
            except Exception as exc:
                errors.append(exc)

        def writer() -> None:
            try:
                for i in range(30):
                    cache.put(f"new prompt {i}", f"response {i}", "m")
            except Exception as exc:
                errors.append(exc)

        threads = [
            threading.Thread(target=reader),
            threading.Thread(target=writer),
            threading.Thread(target=reader),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors


# ---------------------------------------------------------------------------
# Empty cache behaviour
# ---------------------------------------------------------------------------


class TestEmptyCache:
    def test_get_empty_cache(self, cache: SemanticCache) -> None:
        assert cache.get("anything", "gpt-4") is None

    def test_size_empty(self, cache: SemanticCache) -> None:
        assert cache.size() == 0
        assert cache.size("gpt-4") == 0

    def test_clear_empty(self, cache: SemanticCache) -> None:
        assert cache.clear() == 0

    def test_all_entries_empty(self, cache: SemanticCache) -> None:
        assert cache.all_entries() == []


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------


class TestInputValidation:
    def test_put_empty_prompt_raises(self, cache: SemanticCache) -> None:
        with pytest.raises(ContextError, match="empty prompt"):
            cache.put("", "response", "model")

    def test_put_empty_response_raises(self, cache: SemanticCache) -> None:
        with pytest.raises(ContextError, match="empty response"):
            cache.put("prompt", "", "model")

    def test_put_empty_model_raises(self, cache: SemanticCache) -> None:
        with pytest.raises(ContextError, match="model"):
            cache.put("prompt", "response", "")

    def test_put_whitespace_prompt_raises(self, cache: SemanticCache) -> None:
        with pytest.raises(ContextError, match="empty prompt"):
            cache.put("   ", "response", "model")

    def test_put_whitespace_response_raises(self, cache: SemanticCache) -> None:
        with pytest.raises(ContextError, match="empty response"):
            cache.put("prompt", "   ", "model")

    def test_put_whitespace_model_raises(self, cache: SemanticCache) -> None:
        with pytest.raises(ContextError, match="model"):
            cache.put("prompt", "response", "   ")


# ---------------------------------------------------------------------------
# Persistence to disk
# ---------------------------------------------------------------------------


class TestPersistence:
    def test_persist_and_reload(self, tmp_path: Path) -> None:
        db_path = tmp_path / "cache.db"
        cache1 = SemanticCache(CacheConfig(persist_path=db_path))
        cache1.put("What is Python?", "A programming language.", "gpt-4")
        cache1.close()

        cache2 = SemanticCache(CacheConfig(persist_path=db_path))
        result = cache2.get("What is Python?", "gpt-4")
        assert result == "A programming language."
        cache2.close()

    def test_persist_multiple_models(self, tmp_path: Path) -> None:
        db_path = tmp_path / "cache.db"
        cache1 = SemanticCache(CacheConfig(persist_path=db_path))
        cache1.put("prompt", "gpt_resp", "gpt-4")
        cache1.put("prompt", "claude_resp", "claude")
        cache1.close()

        cache2 = SemanticCache(CacheConfig(persist_path=db_path))
        assert cache2.get("prompt", "gpt-4") == "gpt_resp"
        assert cache2.get("prompt", "claude") == "claude_resp"
        cache2.close()

    def test_clear_persisted(self, persisted_cache: SemanticCache) -> None:
        persisted_cache.put("q", "a", "m")
        persisted_cache.clear()
        assert persisted_cache.size() == 0


# ---------------------------------------------------------------------------
# Cache warming
# ---------------------------------------------------------------------------


class TestCacheWarming:
    def test_warm_from_history(self, cache: SemanticCache) -> None:
        history = [
            ("What is Python?", "A language.", "gpt-4"),
            ("What is Rust?", "A systems language.", "gpt-4"),
            ("Explain async", "Concurrent execution.", "claude"),
        ]
        loaded = cache.warm(history)
        assert loaded == 3
        assert cache.size() == 3

    def test_warm_skips_invalid(self, cache: SemanticCache) -> None:
        history = [
            ("valid", "response", "model"),
            ("", "response", "model"),  # empty prompt — should skip
            ("valid2", "", "model"),  # empty response — should skip
        ]
        loaded = cache.warm(history)
        assert loaded == 1
        assert cache.size() == 1

    def test_warm_respects_max_size(self) -> None:
        cache = SemanticCache(CacheConfig(max_size=2, ttl_seconds=0))
        history = [
            ("prompt1", "resp1", "m"),
            ("prompt2", "resp2", "m"),
            ("prompt3", "resp3", "m"),
        ]
        loaded = cache.warm(history)
        assert loaded == 3
        # Only 2 should remain (LRU eviction during warm).
        assert cache.size("m") == 2


# ---------------------------------------------------------------------------
# Similarity threshold edge cases
# ---------------------------------------------------------------------------


class TestSimilarityThreshold:
    def test_threshold_zero_matches_anything(self) -> None:
        cache = SemanticCache(CacheConfig(similarity_threshold=0.0))
        cache.put("What is Python?", "A language.", "m")
        # Even an unrelated prompt should match at threshold 0.
        # (As long as there are *some* overlapping tokens after TF-IDF.)
        result = cache.get("What is the meaning of life?", "m")
        # With threshold 0, any non-zero similarity is a hit.
        # 'what' and 'is' overlap, so similarity > 0.
        assert result == "A language."

    def test_threshold_one_requires_identical(self) -> None:
        cache = SemanticCache(CacheConfig(similarity_threshold=1.0))
        cache.put("What is Python?", "A language.", "m")
        # Exact match should hit (cosine of identical vectors = 1.0).
        assert cache.get("What is Python?", "m") == "A language."
        # Slightly different prompt should miss.
        assert cache.get("What is Python programming?", "m") is None

    def test_high_threshold_rejects_low_similarity(self) -> None:
        cache = SemanticCache(CacheConfig(similarity_threshold=0.95))
        cache.put(
            "Explain the differences between Python and JavaScript",
            "Many differences.",
            "m",
        )
        result = cache.get("How do Python and Ruby compare?", "m")
        assert result is None


# ---------------------------------------------------------------------------
# Misc / edge cases
# ---------------------------------------------------------------------------


class TestMisc:
    def test_size_per_model(self, cache: SemanticCache) -> None:
        cache.put("p1", "r1", "gpt-4")
        cache.put("p2", "r2", "gpt-4")
        cache.put("p3", "r3", "claude")
        assert cache.size("gpt-4") == 2
        assert cache.size("claude") == 1
        assert cache.size() == 3

    def test_all_entries_returns_copy(self, cache: SemanticCache) -> None:
        cache.put("p", "r", "m")
        entries = cache.all_entries()
        entries.clear()
        assert cache.size() == 1

    def test_config_accessible(self, cache: SemanticCache) -> None:
        assert cache.config.max_size == 256

    def test_close_idempotent(self, cache: SemanticCache) -> None:
        cache.close()
        cache.close()  # should not raise

    def test_stats_snapshot_is_independent(self, cache: SemanticCache) -> None:
        cache.put("q", "a", "m")
        cache.get("q", "m")
        stats1 = cache.stats
        cache.get("q", "m")
        stats2 = cache.stats
        assert stats1.hits == 1
        assert stats2.hits == 2
