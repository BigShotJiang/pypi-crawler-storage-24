"""Tests for prism.eval.metrics — individual metrics and MetricSuite."""

from __future__ import annotations

import pytest

from prism.eval.metrics import (
    MetricResult,
    MetricSuite,
    code_execution_check,
    exact_match,
    fuzzy_match,
    keyword_recall,
    response_length_ratio,
)

# ===================================================================
# exact_match
# ===================================================================


class TestExactMatch:
    """Tests for the exact_match function."""

    def test_identical_strings(self) -> None:
        assert exact_match("hello", "hello") is True

    def test_whitespace_stripping(self) -> None:
        assert exact_match("  hello  ", "hello") is True

    def test_different_strings(self) -> None:
        assert exact_match("hello", "world") is False

    def test_case_sensitive(self) -> None:
        assert exact_match("Hello", "hello") is False

    def test_empty_strings(self) -> None:
        assert exact_match("", "") is True

    def test_multiline(self) -> None:
        a = "line1\nline2"
        b = "line1\nline2"
        assert exact_match(a, b) is True


# ===================================================================
# fuzzy_match
# ===================================================================


class TestFuzzyMatch:
    """Tests for the fuzzy_match function."""

    def test_identical_strings(self) -> None:
        assert fuzzy_match("hello world", "hello world") == 1.0

    def test_completely_different(self) -> None:
        score = fuzzy_match("aaa", "zzz")
        assert score < 0.5

    def test_partial_overlap(self) -> None:
        score = fuzzy_match("hello world", "hello earth")
        assert 0.3 < score < 0.9

    def test_empty_both(self) -> None:
        assert fuzzy_match("", "") == 1.0

    def test_empty_predicted(self) -> None:
        assert fuzzy_match("", "something") == 0.0

    def test_empty_expected(self) -> None:
        assert fuzzy_match("something", "") == 0.0


# ===================================================================
# keyword_recall
# ===================================================================


class TestKeywordRecall:
    """Tests for the keyword_recall function."""

    def test_all_keywords_present(self) -> None:
        assert keyword_recall("The cat sat on the mat", ["cat", "mat"]) == 1.0

    def test_no_keywords_present(self) -> None:
        assert keyword_recall("The dog ran", ["cat", "mat"]) == 0.0

    def test_partial_keywords(self) -> None:
        assert keyword_recall("The cat ran", ["cat", "mat"]) == 0.5

    def test_case_insensitive(self) -> None:
        assert keyword_recall("The CAT sat", ["cat"]) == 1.0

    def test_empty_keywords_list(self) -> None:
        assert keyword_recall("anything", []) == 1.0

    def test_empty_predicted(self) -> None:
        assert keyword_recall("", ["word"]) == 0.0


# ===================================================================
# code_execution_check
# ===================================================================


class TestCodeExecutionCheck:
    """Tests for the code_execution_check function."""

    def test_valid_python(self) -> None:
        assert code_execution_check("x = 1 + 2") is True

    def test_valid_function(self) -> None:
        code = "def foo(x):\n    return x * 2"
        assert code_execution_check(code) is True

    def test_invalid_syntax(self) -> None:
        assert code_execution_check("def foo(") is False

    def test_empty_string(self) -> None:
        assert code_execution_check("") is True

    def test_plain_text_not_code(self) -> None:
        # Natural language usually parses as valid Python expressions
        # but deliberate syntax errors don't
        assert code_execution_check("if while for") is False


# ===================================================================
# response_length_ratio
# ===================================================================


class TestResponseLengthRatio:
    """Tests for the response_length_ratio function."""

    def test_equal_length(self) -> None:
        ratio = response_length_ratio("hello", "world")
        assert ratio == 1.0

    def test_predicted_longer(self) -> None:
        ratio = response_length_ratio("hello world", "hi")
        assert ratio > 1.0

    def test_predicted_shorter(self) -> None:
        ratio = response_length_ratio("hi", "hello world")
        assert ratio < 1.0

    def test_both_empty(self) -> None:
        assert response_length_ratio("", "") == 0.0

    def test_expected_empty(self) -> None:
        assert response_length_ratio("hello", "") == float("inf")


# ===================================================================
# MetricResult
# ===================================================================


class TestMetricResult:
    """Tests for the MetricResult dataclass."""

    def test_aggregate_score(self) -> None:
        mr = MetricResult(
            scores={"a": 0.8, "b": 0.6},
            passed={"a": True, "b": True},
        )
        assert mr.aggregate_score == pytest.approx(0.7)

    def test_aggregate_score_empty(self) -> None:
        mr = MetricResult(scores={}, passed={})
        assert mr.aggregate_score == 0.0

    def test_all_passed_true(self) -> None:
        mr = MetricResult(
            scores={"a": 1.0},
            passed={"a": True},
        )
        assert mr.all_passed is True

    def test_all_passed_false(self) -> None:
        mr = MetricResult(
            scores={"a": 1.0, "b": 0.3},
            passed={"a": True, "b": False},
        )
        assert mr.all_passed is False

    def test_to_dict(self) -> None:
        mr = MetricResult(
            scores={"x": 0.5},
            passed={"x": True},
            details={"x": "ok"},
        )
        d = mr.to_dict()
        assert d["scores"] == {"x": 0.5}
        assert d["all_passed"] is True
        assert "aggregate_score" in d


# ===================================================================
# MetricSuite
# ===================================================================


class TestMetricSuite:
    """Tests for the MetricSuite class."""

    def test_empty_suite(self) -> None:
        suite = MetricSuite()
        result = suite.evaluate("pred", "exp")
        assert result.scores == {}
        assert result.all_passed is True

    def test_exact_match_pass(self) -> None:
        suite = MetricSuite()
        suite.add_exact_match()
        result = suite.evaluate("hello", "hello")
        assert result.scores["exact_match"] == 1.0
        assert result.passed["exact_match"] is True

    def test_exact_match_fail(self) -> None:
        suite = MetricSuite()
        suite.add_exact_match()
        result = suite.evaluate("hello", "world")
        assert result.scores["exact_match"] == 0.0
        assert result.passed["exact_match"] is False

    def test_fuzzy_match_above_threshold(self) -> None:
        suite = MetricSuite()
        suite.add_fuzzy_match(threshold=0.5)
        result = suite.evaluate("hello world", "hello earth")
        assert result.scores["fuzzy_match"] > 0.5
        assert result.passed["fuzzy_match"] is True

    def test_keyword_recall_with_auto_extract(self) -> None:
        suite = MetricSuite()
        suite.add_keyword_recall(threshold=0.3)
        result = suite.evaluate(
            "The function returns the factorial value",
            "This function computes factorial recursively",
        )
        # Auto-extracts words >= 4 chars: function, computes, factorial, recursively
        assert result.scores["keyword_recall"] > 0.0

    def test_code_syntax_check_valid(self) -> None:
        suite = MetricSuite()
        suite.add_code_syntax_check()
        result = suite.evaluate("x = 1 + 2", "")
        assert result.scores["code_syntax_check"] == 1.0

    def test_code_syntax_check_invalid(self) -> None:
        suite = MetricSuite()
        suite.add_code_syntax_check()
        result = suite.evaluate("def foo(", "")
        assert result.scores["code_syntax_check"] == 0.0

    def test_length_ratio_in_range(self) -> None:
        suite = MetricSuite()
        suite.add_length_ratio(min_ratio=0.5, max_ratio=2.0)
        result = suite.evaluate("hello", "world")
        assert result.passed["length_ratio"] is True

    def test_length_ratio_out_of_range(self) -> None:
        suite = MetricSuite()
        suite.add_length_ratio(min_ratio=0.9, max_ratio=1.1)
        result = suite.evaluate("hi", "hello world this is long")
        assert result.passed["length_ratio"] is False

    def test_custom_metric(self) -> None:
        suite = MetricSuite()

        def always_half(predicted: str, expected: str, **_kw: object) -> float:
            return 0.5

        suite.add_custom("half", always_half, threshold=0.4)
        result = suite.evaluate("any", "thing")
        assert result.scores["half"] == 0.5
        assert result.passed["half"] is True

    def test_metric_names(self, full_metric_suite: MetricSuite) -> None:
        names = full_metric_suite.metric_names
        assert "exact_match" in names
        assert "fuzzy_match" in names
        assert "keyword_recall" in names
        assert "length_ratio" in names

    def test_none_expected_handled(self) -> None:
        suite = MetricSuite()
        suite.add_exact_match()
        suite.add_fuzzy_match()
        result = suite.evaluate("hello", expected=None)
        # Should not crash; expected becomes ""
        assert "exact_match" in result.scores

    def test_metric_error_handled(self) -> None:
        suite = MetricSuite()

        def _boom(predicted: str, expected: str, **_kw: object) -> float:
            raise RuntimeError("boom")

        suite.add_custom("boom", _boom, threshold=0.5)
        result = suite.evaluate("hello", "world")
        assert result.scores["boom"] == 0.0
        assert "Error" in result.details["boom"]
