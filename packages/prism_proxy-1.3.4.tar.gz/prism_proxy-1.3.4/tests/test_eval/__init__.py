"""Tests for the prism.eval benchmark framework."""
