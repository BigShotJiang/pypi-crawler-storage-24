"""Shared fixtures for eval framework tests."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from prism.eval.dataset import EvalDataset, EvalSample
from prism.eval.metrics import MetricResult, MetricSuite
from prism.eval.runner import CompletionOutput, EvalReport, ModelScore, SampleResult

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Sample fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_basic() -> EvalSample:
    """A simple coding eval sample with expected output."""
    return EvalSample(
        input_prompt="Write a function that adds two numbers.",
        expected_output="def add(a, b):\n    return a + b",
        tags=["coding", "python"],
        metadata={"difficulty": "easy"},
    )


@pytest.fixture
def sample_no_expected() -> EvalSample:
    """An open-ended sample with no expected output."""
    return EvalSample(
        input_prompt="Write a poem about the sea.",
        expected_output=None,
        tags=["creative"],
        metadata={"open_ended": True},
    )


@pytest.fixture
def sample_reasoning() -> EvalSample:
    """A reasoning sample."""
    return EvalSample(
        input_prompt="What is 2 + 2?",
        expected_output="4",
        tags=["reasoning", "math"],
        metadata={"difficulty": "easy"},
    )


# ---------------------------------------------------------------------------
# Dataset fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def small_dataset(sample_basic: EvalSample, sample_reasoning: EvalSample) -> EvalDataset:
    """A small 2-sample dataset for quick tests."""
    return EvalDataset(name="small_test", samples=[sample_basic, sample_reasoning])


@pytest.fixture
def tagged_dataset() -> EvalDataset:
    """A dataset with diverse tags for filter testing."""
    return EvalDataset(
        name="tagged",
        samples=[
            EvalSample(input_prompt="q1", expected_output="a1", tags=["coding", "python"]),
            EvalSample(input_prompt="q2", expected_output="a2", tags=["coding", "java"]),
            EvalSample(input_prompt="q3", expected_output="a3", tags=["reasoning"]),
            EvalSample(input_prompt="q4", expected_output="a4", tags=["creative"]),
            EvalSample(input_prompt="q5", expected_output="a5", tags=["coding", "python", "hard"]),
        ],
    )


# ---------------------------------------------------------------------------
# Metric suite fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def basic_metric_suite() -> MetricSuite:
    """A metric suite with exact match and fuzzy match."""
    suite = MetricSuite(name="basic")
    suite.add_exact_match()
    suite.add_fuzzy_match(threshold=0.5)
    return suite


@pytest.fixture
def full_metric_suite() -> MetricSuite:
    """A metric suite with all built-in metrics."""
    suite = MetricSuite(name="full")
    suite.add_exact_match()
    suite.add_fuzzy_match(threshold=0.5)
    suite.add_keyword_recall(threshold=0.3)
    suite.add_length_ratio(min_ratio=0.3, max_ratio=3.0)
    return suite


# ---------------------------------------------------------------------------
# Mock completion function
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_completion_fn():
    """A mock async completion function that echoes the prompt with a prefix."""
    responses: dict[str, str] = {}

    async def _complete(model: str, prompt: str) -> CompletionOutput:
        text = responses.get(model, f"Response from {model}: {prompt[:50]}")
        return CompletionOutput(
            text=text,
            input_tokens=len(prompt.split()),
            output_tokens=len(text.split()),
            cost_usd=0.001 * len(text.split()),
        )

    _complete.responses = responses  # type: ignore[attr-defined]
    return _complete


# ---------------------------------------------------------------------------
# EvalReport fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_report() -> EvalReport:
    """A pre-built EvalReport for comparator tests."""
    return EvalReport(
        dataset_name="test_ds",
        model_scores={
            "model-a": ModelScore(
                model_id="model-a",
                mean_score=0.85,
                total_cost_usd=0.10,
                mean_latency_ms=200.0,
                pass_rate=0.8,
                per_metric_means={"exact_match": 0.7, "fuzzy_match": 0.9},
                sample_count=10,
            ),
            "model-b": ModelScore(
                model_id="model-b",
                mean_score=0.70,
                total_cost_usd=0.05,
                mean_latency_ms=100.0,
                pass_rate=0.6,
                per_metric_means={"exact_match": 0.5, "fuzzy_match": 0.8},
                sample_count=10,
            ),
        },
        sample_results=[
            SampleResult(
                sample_index=i,
                model_id=model,
                predicted="pred",
                expected="exp",
                metric_result=MetricResult(
                    scores={"exact_match": score, "fuzzy_match": score + 0.1},
                    passed={"exact_match": score >= 0.5, "fuzzy_match": True},
                ),
                latency_ms=150.0,
                cost_usd=0.01,
            )
            for i in range(10)
            for model, score in [("model-a", 0.8), ("model-b", 0.6)]
        ],
        rankings_by_quality=["model-a", "model-b"],
        rankings_by_cost=["model-b", "model-a"],
        rankings_by_efficiency=["model-b", "model-a"],
    )


@pytest.fixture
def improved_report() -> EvalReport:
    """A report where model-a improved and model-b regressed vs sample_report."""
    return EvalReport(
        dataset_name="test_ds_v2",
        model_scores={
            "model-a": ModelScore(
                model_id="model-a",
                mean_score=0.95,
                total_cost_usd=0.12,
                mean_latency_ms=180.0,
                pass_rate=0.9,
                per_metric_means={"exact_match": 0.9, "fuzzy_match": 0.95},
                sample_count=10,
            ),
            "model-b": ModelScore(
                model_id="model-b",
                mean_score=0.50,
                total_cost_usd=0.04,
                mean_latency_ms=90.0,
                pass_rate=0.4,
                per_metric_means={"exact_match": 0.3, "fuzzy_match": 0.6},
                sample_count=10,
            ),
        },
        sample_results=[
            SampleResult(
                sample_index=i,
                model_id=model,
                predicted="pred",
                expected="exp",
                metric_result=MetricResult(
                    scores={"exact_match": score, "fuzzy_match": score + 0.05},
                    passed={"exact_match": score >= 0.5, "fuzzy_match": True},
                ),
                latency_ms=130.0,
                cost_usd=0.01,
            )
            for i in range(10)
            for model, score in [("model-a", 0.9), ("model-b", 0.45)]
        ],
        rankings_by_quality=["model-a", "model-b"],
        rankings_by_cost=["model-b", "model-a"],
        rankings_by_efficiency=["model-a", "model-b"],
    )


# ---------------------------------------------------------------------------
# Temporary file helpers
# ---------------------------------------------------------------------------


@pytest.fixture
def json_dataset_file(tmp_path: Path) -> Path:
    """Write a small JSON dataset file and return its path."""
    import json

    data = [
        {"input_prompt": "q1", "expected_output": "a1", "tags": ["t1"]},
        {"input_prompt": "q2", "expected_output": "a2", "tags": ["t2"]},
    ]
    p = tmp_path / "test_dataset.json"
    p.write_text(json.dumps(data))
    return p


@pytest.fixture
def jsonl_dataset_file(tmp_path: Path) -> Path:
    """Write a small JSONL dataset file and return its path."""
    import json

    lines = [
        json.dumps({"input_prompt": "q1", "expected_output": "a1", "tags": ["t1"]}),
        json.dumps({"input_prompt": "q2", "expected_output": "a2", "tags": ["t2"]}),
        json.dumps({"input_prompt": "q3", "expected_output": "a3", "tags": ["t1", "t2"]}),
    ]
    p = tmp_path / "test_dataset.jsonl"
    p.write_text("\n".join(lines) + "\n")
    return p
