"""Tests for prism.eval.dataset — EvalSample and EvalDataset."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from prism.eval.dataset import EvalDataset, EvalSample

if TYPE_CHECKING:
    from pathlib import Path

# ===================================================================
# EvalSample
# ===================================================================


class TestEvalSample:
    """Tests for the EvalSample dataclass."""

    def test_create_with_defaults(self) -> None:
        """Sample created with only the prompt gets sensible defaults."""
        sample = EvalSample(input_prompt="Hello?")
        assert sample.input_prompt == "Hello?"
        assert sample.expected_output is None
        assert sample.metadata == {}
        assert sample.tags == []

    def test_create_full(self) -> None:
        """Sample with all fields populated."""
        sample = EvalSample(
            input_prompt="q",
            expected_output="a",
            metadata={"k": "v"},
            tags=["t1", "t2"],
        )
        assert sample.expected_output == "a"
        assert sample.metadata == {"k": "v"}
        assert sample.tags == ["t1", "t2"]

    def test_to_dict_roundtrip(self, sample_basic: EvalSample) -> None:
        """to_dict -> from_dict produces an equivalent sample."""
        d = sample_basic.to_dict()
        restored = EvalSample.from_dict(d)
        assert restored.input_prompt == sample_basic.input_prompt
        assert restored.expected_output == sample_basic.expected_output
        assert restored.metadata == sample_basic.metadata
        assert restored.tags == sample_basic.tags

    def test_from_dict_missing_prompt_raises(self) -> None:
        """from_dict raises ValueError when input_prompt is absent."""
        with pytest.raises(ValueError, match="input_prompt"):
            EvalSample.from_dict({"expected_output": "a"})

    def test_from_dict_minimal(self) -> None:
        """from_dict works with only input_prompt."""
        sample = EvalSample.from_dict({"input_prompt": "q"})
        assert sample.input_prompt == "q"
        assert sample.expected_output is None


# ===================================================================
# EvalDataset — construction & properties
# ===================================================================


class TestEvalDatasetConstruction:
    """Tests for EvalDataset creation and basic properties."""

    def test_empty_dataset(self) -> None:
        """An empty dataset has len 0 and default name."""
        ds = EvalDataset()
        assert len(ds) == 0
        assert ds.name == "unnamed"

    def test_named_dataset_with_samples(self, small_dataset: EvalDataset) -> None:
        """Dataset stores name and samples correctly."""
        assert small_dataset.name == "small_test"
        assert len(small_dataset) == 2

    def test_add_sample(self) -> None:
        """add_sample appends to the dataset."""
        ds = EvalDataset(name="test")
        ds.add_sample(EvalSample(input_prompt="q1"))
        assert len(ds) == 1
        ds.add_sample(EvalSample(input_prompt="q2"))
        assert len(ds) == 2

    def test_add_samples_bulk(self) -> None:
        """add_samples appends multiple at once."""
        ds = EvalDataset(name="test")
        ds.add_samples([
            EvalSample(input_prompt="q1"),
            EvalSample(input_prompt="q2"),
            EvalSample(input_prompt="q3"),
        ])
        assert len(ds) == 3

    def test_samples_property_returns_copy(self, small_dataset: EvalDataset) -> None:
        """The samples property returns a copy, not the internal list."""
        samples = small_dataset.samples
        samples.clear()
        assert len(small_dataset) == 2  # internal unaffected

    def test_iteration(self, small_dataset: EvalDataset) -> None:
        """Iterating over a dataset yields each sample."""
        prompts = [s.input_prompt for s in small_dataset]
        assert len(prompts) == 2

    def test_getitem(self, small_dataset: EvalDataset) -> None:
        """Indexing into a dataset returns the correct sample."""
        assert small_dataset[0].input_prompt == "Write a function that adds two numbers."
        assert small_dataset[1].input_prompt == "What is 2 + 2?"

    def test_repr(self, small_dataset: EvalDataset) -> None:
        """repr includes name and sample count."""
        r = repr(small_dataset)
        assert "small_test" in r
        assert "2" in r


# ===================================================================
# EvalDataset — file I/O
# ===================================================================


class TestEvalDatasetFileIO:
    """Tests for JSON/JSONL loading and saving."""

    def test_from_json(self, json_dataset_file: Path) -> None:
        """Load a dataset from a JSON file."""
        ds = EvalDataset.from_json(json_dataset_file)
        assert len(ds) == 2
        assert ds[0].input_prompt == "q1"
        assert ds.name == "test_dataset"

    def test_from_json_custom_name(self, json_dataset_file: Path) -> None:
        """Load with a custom name override."""
        ds = EvalDataset.from_json(json_dataset_file, name="custom")
        assert ds.name == "custom"

    def test_from_json_not_found(self, tmp_path: Path) -> None:
        """FileNotFoundError for a missing file."""
        with pytest.raises(FileNotFoundError):
            EvalDataset.from_json(tmp_path / "nope.json")

    def test_from_json_invalid(self, tmp_path: Path) -> None:
        """ValueError for a file that is not a JSON list."""
        p = tmp_path / "bad.json"
        p.write_text('{"not": "a list"}')
        with pytest.raises(ValueError, match="JSON list"):
            EvalDataset.from_json(p)

    def test_from_jsonl(self, jsonl_dataset_file: Path) -> None:
        """Load a dataset from a JSONL file."""
        ds = EvalDataset.from_jsonl(jsonl_dataset_file)
        assert len(ds) == 3
        assert ds[2].tags == ["t1", "t2"]

    def test_from_jsonl_not_found(self, tmp_path: Path) -> None:
        """FileNotFoundError for a missing JSONL file."""
        with pytest.raises(FileNotFoundError):
            EvalDataset.from_jsonl(tmp_path / "nope.jsonl")

    def test_to_json_roundtrip(self, small_dataset: EvalDataset, tmp_path: Path) -> None:
        """to_json then from_json preserves samples."""
        out = tmp_path / "out.json"
        small_dataset.to_json(out)
        restored = EvalDataset.from_json(out)
        assert len(restored) == len(small_dataset)
        assert restored[0].input_prompt == small_dataset[0].input_prompt

    def test_to_jsonl_roundtrip(self, small_dataset: EvalDataset, tmp_path: Path) -> None:
        """to_jsonl then from_jsonl preserves samples."""
        out = tmp_path / "out.jsonl"
        small_dataset.to_jsonl(out)
        restored = EvalDataset.from_jsonl(out)
        assert len(restored) == len(small_dataset)


# ===================================================================
# EvalDataset — filtering
# ===================================================================


class TestEvalDatasetFilter:
    """Tests for tag-based filtering."""

    def test_filter_single_tag(self, tagged_dataset: EvalDataset) -> None:
        """Filtering by one tag returns samples that have it."""
        coding = tagged_dataset.filter_by_tags(["coding"])
        assert len(coding) == 3  # q1, q2, q5

    def test_filter_match_any(self, tagged_dataset: EvalDataset) -> None:
        """Default match_all=False returns samples matching ANY tag."""
        result = tagged_dataset.filter_by_tags(["python", "reasoning"])
        # q1 (python), q3 (reasoning), q5 (python)
        assert len(result) == 3

    def test_filter_match_all(self, tagged_dataset: EvalDataset) -> None:
        """match_all=True requires ALL tags to be present."""
        result = tagged_dataset.filter_by_tags(["coding", "python"], match_all=True)
        # q1 and q5 have both coding and python
        assert len(result) == 2

    def test_filter_no_match(self, tagged_dataset: EvalDataset) -> None:
        """Filtering with a tag that no sample has returns empty."""
        result = tagged_dataset.filter_by_tags(["nonexistent"])
        assert len(result) == 0


# ===================================================================
# EvalDataset — split & shuffle
# ===================================================================


class TestEvalDatasetSplitShuffle:
    """Tests for train/test splitting and shuffling."""

    def test_split_sizes(self) -> None:
        """Split produces correct train/test sizes."""
        ds = EvalDataset(
            name="split_test",
            samples=[EvalSample(input_prompt=f"q{i}") for i in range(10)],
        )
        train, test = ds.split(train_ratio=0.8, seed=42)
        assert len(train) == 8
        assert len(test) == 2

    def test_split_deterministic(self) -> None:
        """Same seed produces the same split."""
        ds = EvalDataset(
            name="det",
            samples=[EvalSample(input_prompt=f"q{i}") for i in range(20)],
        )
        t1, v1 = ds.split(train_ratio=0.7, seed=123)
        t2, v2 = ds.split(train_ratio=0.7, seed=123)
        assert [s.input_prompt for s in t1] == [s.input_prompt for s in t2]
        assert [s.input_prompt for s in v1] == [s.input_prompt for s in v2]

    def test_split_invalid_ratio(self) -> None:
        """Invalid train_ratio raises ValueError."""
        ds = EvalDataset(name="x", samples=[EvalSample(input_prompt="q")])
        with pytest.raises(ValueError, match="train_ratio"):
            ds.split(train_ratio=0.0)
        with pytest.raises(ValueError, match="train_ratio"):
            ds.split(train_ratio=1.0)

    def test_shuffle_deterministic(self) -> None:
        """Same seed produces the same shuffle order."""
        ds = EvalDataset(
            name="shuf",
            samples=[EvalSample(input_prompt=f"q{i}") for i in range(10)],
        )
        s1 = ds.shuffle(seed=99)
        s2 = ds.shuffle(seed=99)
        assert [s.input_prompt for s in s1] == [s.input_prompt for s in s2]

    def test_shuffle_changes_order(self) -> None:
        """Shuffling (without lucky seed) changes sample order."""
        ds = EvalDataset(
            name="shuf",
            samples=[EvalSample(input_prompt=f"q{i}") for i in range(20)],
        )
        shuffled = ds.shuffle(seed=42)
        original_order = [s.input_prompt for s in ds]
        shuffled_order = [s.input_prompt for s in shuffled]
        # With 20 items, extremely unlikely to stay identical
        assert shuffled_order != original_order


# ===================================================================
# EvalDataset — built-in datasets
# ===================================================================


class TestBuiltinDatasets:
    """Tests for the built-in sample datasets."""

    def test_coding_basic(self) -> None:
        """coding_basic has 10 samples with coding tag."""
        ds = EvalDataset.builtin("coding_basic")
        assert len(ds) == 10
        assert ds.name == "coding_basic"
        assert all("coding" in s.tags for s in ds)

    def test_reasoning(self) -> None:
        """reasoning has 10 samples with reasoning tag."""
        ds = EvalDataset.builtin("reasoning")
        assert len(ds) == 10
        assert ds.name == "reasoning"
        assert all("reasoning" in s.tags for s in ds)

    def test_creative(self) -> None:
        """creative has 5 samples, all with no expected output."""
        ds = EvalDataset.builtin("creative")
        assert len(ds) == 5
        assert ds.name == "creative"
        assert all(s.expected_output is None for s in ds)

    def test_unknown_builtin_raises(self) -> None:
        """Unknown name raises ValueError."""
        with pytest.raises(ValueError, match="Unknown built-in"):
            EvalDataset.builtin("nonexistent")
