"""Tests for prism.eval.runner — EvalRunner, EvalReport, and comparator."""

from __future__ import annotations

import json

import pytest

from prism.eval.comparator import ModelComparator
from prism.eval.dataset import EvalDataset, EvalSample
from prism.eval.metrics import MetricSuite
from prism.eval.runner import (
    CompletionOutput,
    EvalReport,
    EvalRunner,
    ModelScore,
    SampleResult,
)

# ===================================================================
# Helper: deterministic mock completion
# ===================================================================


def _make_mock_fn(
    responses: dict[str, str] | None = None,
    cost_per_call: float = 0.001,
):
    """Build a mock async completion function with per-model responses."""
    _responses = responses or {}

    async def _fn(model: str, prompt: str) -> CompletionOutput:
        text = _responses.get(model, f"mock-{model}")
        return CompletionOutput(
            text=text,
            input_tokens=10,
            output_tokens=5,
            cost_usd=cost_per_call,
        )

    return _fn


# ===================================================================
# EvalRunner — construction validation
# ===================================================================


class TestEvalRunnerValidation:
    """Tests for EvalRunner constructor validation."""

    def test_no_models_raises(self, small_dataset: EvalDataset) -> None:
        suite = MetricSuite()
        with pytest.raises(ValueError, match="model_id"):
            EvalRunner(
                dataset=small_dataset,
                model_ids=[],
                metric_suite=suite,
                completion_fn=_make_mock_fn(),
            )

    def test_empty_dataset_raises(self) -> None:
        suite = MetricSuite()
        with pytest.raises(ValueError, match="at least one sample"):
            EvalRunner(
                dataset=EvalDataset(name="empty"),
                model_ids=["gpt-4o"],
                metric_suite=suite,
                completion_fn=_make_mock_fn(),
            )


# ===================================================================
# EvalRunner — execution
# ===================================================================


class TestEvalRunnerExecution:
    """Tests for running evaluations end-to-end."""

    @pytest.mark.asyncio
    async def test_single_model_single_sample(self) -> None:
        """Run one model against one sample and verify report structure."""
        ds = EvalDataset(
            name="tiny",
            samples=[
                EvalSample(input_prompt="say hello", expected_output="hello"),
            ],
        )
        suite = MetricSuite()
        suite.add_exact_match()

        mock_fn = _make_mock_fn({"gpt-4o": "hello"})

        runner = EvalRunner(
            dataset=ds,
            model_ids=["gpt-4o"],
            metric_suite=suite,
            completion_fn=mock_fn,
        )
        report = await runner.run()

        assert report.dataset_name == "tiny"
        assert len(report.sample_results) == 1
        assert "gpt-4o" in report.model_scores
        assert report.model_scores["gpt-4o"].mean_score == 1.0
        assert report.model_scores["gpt-4o"].sample_count == 1

    @pytest.mark.asyncio
    async def test_multiple_models(self) -> None:
        """Run two models and verify rankings."""
        ds = EvalDataset(
            name="multi",
            samples=[
                EvalSample(input_prompt="q1", expected_output="answer"),
                EvalSample(input_prompt="q2", expected_output="result"),
            ],
        )
        suite = MetricSuite()
        suite.add_exact_match()

        # model-good returns exact answers, model-bad returns garbage
        mock_fn = _make_mock_fn({"model-good": "answer", "model-bad": "nope"})

        runner = EvalRunner(
            dataset=ds,
            model_ids=["model-good", "model-bad"],
            metric_suite=suite,
            completion_fn=mock_fn,
        )
        report = await runner.run()

        assert len(report.sample_results) == 4  # 2 samples x 2 models
        assert report.rankings_by_quality[0] == "model-good"

    @pytest.mark.asyncio
    async def test_progress_callback(self) -> None:
        """Progress callback is invoked for each sample-model combination."""
        ds = EvalDataset(
            name="cb",
            samples=[
                EvalSample(input_prompt="q1", expected_output="a1"),
                EvalSample(input_prompt="q2", expected_output="a2"),
            ],
        )
        suite = MetricSuite()
        suite.add_fuzzy_match()

        progress_log: list[tuple[int, int, str]] = []

        def _on_progress(completed: int, total: int, desc: str) -> None:
            progress_log.append((completed, total, desc))

        runner = EvalRunner(
            dataset=ds,
            model_ids=["m1"],
            metric_suite=suite,
            completion_fn=_make_mock_fn(),
            progress_callback=_on_progress,
        )
        await runner.run()

        assert len(progress_log) == 2
        assert progress_log[-1][0] == 2  # all completed
        assert progress_log[-1][1] == 2  # total

    @pytest.mark.asyncio
    async def test_cost_tracking(self) -> None:
        """Total cost is correctly accumulated."""
        ds = EvalDataset(
            name="cost",
            samples=[EvalSample(input_prompt=f"q{i}", expected_output=f"a{i}") for i in range(5)],
        )
        suite = MetricSuite()
        suite.add_exact_match()

        runner = EvalRunner(
            dataset=ds,
            model_ids=["m1"],
            metric_suite=suite,
            completion_fn=_make_mock_fn(cost_per_call=0.01),
        )
        report = await runner.run()

        assert report.model_scores["m1"].total_cost_usd == pytest.approx(0.05)

    @pytest.mark.asyncio
    async def test_latency_recorded(self) -> None:
        """Latency is positive for each sample result."""
        ds = EvalDataset(
            name="lat",
            samples=[EvalSample(input_prompt="q", expected_output="a")],
        )
        suite = MetricSuite()
        runner = EvalRunner(
            dataset=ds,
            model_ids=["m1"],
            metric_suite=suite,
            completion_fn=_make_mock_fn(),
        )
        report = await runner.run()

        for sr in report.sample_results:
            assert sr.latency_ms >= 0

    def test_run_sync(self) -> None:
        """run_sync works without an existing event loop."""
        ds = EvalDataset(
            name="sync",
            samples=[EvalSample(input_prompt="q", expected_output="a")],
        )
        suite = MetricSuite()
        suite.add_exact_match()

        runner = EvalRunner(
            dataset=ds,
            model_ids=["m1"],
            metric_suite=suite,
            completion_fn=_make_mock_fn({"m1": "a"}),
        )
        report = runner.run_sync()

        assert report.model_scores["m1"].mean_score == 1.0


# ===================================================================
# EvalReport
# ===================================================================


class TestEvalReport:
    """Tests for EvalReport serialization and statistics."""

    def test_to_dict(self, sample_report: EvalReport) -> None:
        """to_dict produces all expected top-level keys."""
        d = sample_report.to_dict()
        assert "dataset_name" in d
        assert "model_scores" in d
        assert "sample_results" in d
        assert "rankings_by_quality" in d

    def test_to_json(self, sample_report: EvalReport) -> None:
        """to_json produces valid JSON."""
        j = sample_report.to_json()
        parsed = json.loads(j)
        assert parsed["dataset_name"] == "test_ds"

    def test_p_value_same_model(self, sample_report: EvalReport) -> None:
        """p_value comparing a model to itself should be 1.0."""
        p = sample_report.p_value("model-a", "model-a")
        assert p is not None
        assert p == 1.0

    def test_p_value_different_models(self, sample_report: EvalReport) -> None:
        """p_value between different models returns a value in [0, 1]."""
        p = sample_report.p_value("model-a", "model-b")
        assert p is not None
        assert 0.0 <= p <= 1.0

    def test_p_value_unknown_model(self, sample_report: EvalReport) -> None:
        """p_value with an unknown model returns None."""
        assert sample_report.p_value("model-a", "unknown") is None

    def test_rankings_order(self, sample_report: EvalReport) -> None:
        """Quality ranking has the better model first."""
        assert sample_report.rankings_by_quality[0] == "model-a"


# ===================================================================
# ModelScore
# ===================================================================


class TestModelScore:
    """Tests for the ModelScore dataclass."""

    def test_cost_efficiency_normal(self) -> None:
        ms = ModelScore(
            model_id="m",
            mean_score=0.8,
            total_cost_usd=0.10,
            mean_latency_ms=100.0,
            pass_rate=0.7,
            sample_count=10,
        )
        assert ms.cost_efficiency == pytest.approx(8.0)

    def test_cost_efficiency_zero_cost(self) -> None:
        ms = ModelScore(
            model_id="m",
            mean_score=0.5,
            total_cost_usd=0.0,
            mean_latency_ms=100.0,
            pass_rate=0.7,
            sample_count=10,
        )
        assert ms.cost_efficiency == float("inf")

    def test_cost_efficiency_zero_both(self) -> None:
        ms = ModelScore(
            model_id="m",
            mean_score=0.0,
            total_cost_usd=0.0,
            mean_latency_ms=0.0,
            pass_rate=0.0,
            sample_count=0,
        )
        assert ms.cost_efficiency == 0.0

    def test_to_dict(self) -> None:
        ms = ModelScore(
            model_id="m",
            mean_score=0.8,
            total_cost_usd=0.10,
            mean_latency_ms=200.0,
            pass_rate=0.8,
            per_metric_means={"exact_match": 0.7},
            sample_count=5,
        )
        d = ms.to_dict()
        assert d["model_id"] == "m"
        assert "cost_efficiency" in d


# ===================================================================
# SampleResult
# ===================================================================


class TestSampleResult:
    """Tests for SampleResult serialization."""

    def test_to_dict(self) -> None:
        from prism.eval.metrics import MetricResult

        sr = SampleResult(
            sample_index=0,
            model_id="m1",
            predicted="hello",
            expected="hello",
            metric_result=MetricResult(scores={"em": 1.0}, passed={"em": True}),
            latency_ms=50.0,
            cost_usd=0.001,
        )
        d = sr.to_dict()
        assert d["sample_index"] == 0
        assert d["model_id"] == "m1"
        assert d["metric_result"]["scores"]["em"] == 1.0


# ===================================================================
# ModelComparator
# ===================================================================


class TestModelComparator:
    """Tests for comparing two evaluation reports."""

    def test_detect_regression(
        self, sample_report: EvalReport, improved_report: EvalReport
    ) -> None:
        """model-b quality dropped, should be flagged as regression."""
        comparator = ModelComparator(regression_threshold=0.05)
        summary = comparator.compare(sample_report, improved_report)

        assert summary.has_regressions
        reg_models = {r.model_id for r in summary.regressions}
        assert "model-b" in reg_models

    def test_detect_improvement(
        self, sample_report: EvalReport, improved_report: EvalReport
    ) -> None:
        """model-a quality improved, should be flagged."""
        comparator = ModelComparator(improvement_threshold=0.05)
        summary = comparator.compare(sample_report, improved_report)

        assert summary.has_improvements
        imp_models = {i.model_id for i in summary.improvements}
        assert "model-a" in imp_models

    def test_common_models(
        self, sample_report: EvalReport, improved_report: EvalReport
    ) -> None:
        """Both reports share model-a and model-b."""
        comparator = ModelComparator()
        summary = comparator.compare(sample_report, improved_report)
        assert set(summary.common_models) == {"model-a", "model-b"}

    def test_cost_efficiency_entries(
        self, sample_report: EvalReport, improved_report: EvalReport
    ) -> None:
        """Cost efficiency is reported for each common model."""
        comparator = ModelComparator()
        summary = comparator.compare(sample_report, improved_report)
        assert len(summary.cost_efficiency) == 2

    def test_no_common_models(self) -> None:
        """Comparing reports with disjoint models yields empty summary."""
        r1 = EvalReport(
            dataset_name="a",
            model_scores={
                "m1": ModelScore(
                    model_id="m1",
                    mean_score=0.5,
                    total_cost_usd=0.01,
                    mean_latency_ms=100.0,
                    pass_rate=0.5,
                    sample_count=1,
                )
            },
        )
        r2 = EvalReport(
            dataset_name="b",
            model_scores={
                "m2": ModelScore(
                    model_id="m2",
                    mean_score=0.6,
                    total_cost_usd=0.02,
                    mean_latency_ms=80.0,
                    pass_rate=0.6,
                    sample_count=1,
                )
            },
        )
        comparator = ModelComparator()
        summary = comparator.compare(r1, r2)
        assert summary.common_models == []
        assert not summary.has_regressions
        assert not summary.has_improvements

    def test_summary_to_dict(
        self, sample_report: EvalReport, improved_report: EvalReport
    ) -> None:
        """ComparisonSummary serializes to dict without error."""
        comparator = ModelComparator()
        summary = comparator.compare(sample_report, improved_report)
        d = summary.to_dict()
        assert "regressions" in d
        assert "improvements" in d
        assert "cost_efficiency" in d
        assert isinstance(d["has_regressions"], bool)

    def test_high_threshold_no_regression(
        self, sample_report: EvalReport, improved_report: EvalReport
    ) -> None:
        """With a very high threshold, nothing is flagged."""
        comparator = ModelComparator(regression_threshold=10.0, improvement_threshold=10.0)
        summary = comparator.compare(sample_report, improved_report)
        assert not summary.has_regressions
        assert not summary.has_improvements

    def test_invalid_threshold_raises(self) -> None:
        """Negative thresholds raise ValueError."""
        with pytest.raises(ValueError, match="regression_threshold"):
            ModelComparator(regression_threshold=-0.1)
        with pytest.raises(ValueError, match="improvement_threshold"):
            ModelComparator(improvement_threshold=-0.1)
