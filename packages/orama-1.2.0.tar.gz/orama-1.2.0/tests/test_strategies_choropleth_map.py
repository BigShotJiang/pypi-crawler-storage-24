"""
Unit tests for ChoroplethMapChartStrategy._prepare_plot_data().
"""

from typing import Any
from unittest.mock import MagicMock

import polars as pl
import pytest
from fields_metadata import FieldMetadata
from polychromos import HSLColor

from orama.color import (
    ColorAssignerByCategory,
    ColorRule,
    ColorSelectorStrategy,
)
from orama.strategies.choropleth_map import ChoroplethMapChartStrategy
from orama.variables import Aggregation


def _country_meta() -> MagicMock:
    m = MagicMock(spec=FieldMetadata)
    m.categorical = False
    m.numeric = False
    m.derived = False
    m.effective_type = str
    m.extra = {"suggested_validation": "iso_a2"}
    return m


def _make_choropleth(**kwargs: Any) -> ChoroplethMapChartStrategy:
    return ChoroplethMapChartStrategy(
        fields_metadata={"country": _country_meta()},
        country_variable="country",
        aggregation=Aggregation(name="count", function="count"),
        **kwargs,
    )


@pytest.fixture
def choropleth_df() -> pl.DataFrame:
    return pl.DataFrame({"country": ["US", "DE"], "count": [100, 200]})


def test_prepare_plot_data_returns_country_codes_names_values(
    choropleth_df: pl.DataFrame,
    tr: Any,
    theme: Any,
) -> None:
    instance = _make_choropleth()
    result = instance._prepare_plot_data({"main": choropleth_df}, tr, theme)
    # sorted alphabetically by country code
    assert result["country_codes"] == ["DE", "US"]
    assert len(result["country_names"]) == 2
    assert "Germany" in result["country_names"]
    assert "United States" in result["country_names"]
    assert len(result["values"]) == 2


def test_prepare_plot_data_continuous_mode_sets_color_scale(
    choropleth_df: pl.DataFrame,
    tr: Any,
    theme: Any,
) -> None:
    instance = _make_choropleth()
    result = instance._prepare_plot_data({"main": choropleth_df}, tr, theme)
    assert result["_use_discrete"] is False
    assert result["_color_scale"] is not None
    assert result["_discrete_colors"] is None


def test_prepare_plot_data_discrete_mode_with_categorical_rule(
    choropleth_df: pl.DataFrame,
    anchor_colors: list[HSLColor],
    tr: Any,
    theme: Any,
) -> None:
    rule = ColorRule(
        assigner=ColorAssignerByCategory(anchor_colors=anchor_colors),
        selector=ColorSelectorStrategy(),
    )
    instance = _make_choropleth(color_rules=[rule])
    result = instance._prepare_plot_data({"main": choropleth_df}, tr, theme)
    assert result["_use_discrete"] is True
    assert isinstance(result["_discrete_colors"], list)
    assert len(result["_discrete_colors"]) == 2
    assert all(c.startswith("#") for c in result["_discrete_colors"])
