import pytest

from orama.enums import GeoProjection, LineInterpolation, LinePlacement, LineSortOrder, SortOrder


@pytest.mark.parametrize(
    "member,expected",
    [
        (SortOrder.ASCENDING, 1),
        (SortOrder.DESCENDING, -1),
        (SortOrder.NONE, 0),
    ],
)
def test_sort_order_values(member: SortOrder, expected: int) -> None:
    assert member == expected


@pytest.mark.parametrize(
    "member,expected",
    [
        (LinePlacement.OVERLAPPING, "overlapping"),
        (LinePlacement.STACKED, "stacked"),
        (LinePlacement.STACKED_RELATIVE, "stacked_relative"),
        (LinePlacement.RIDGELINE, "ridgeline"),
    ],
)
def test_line_placement_values(member: LinePlacement, expected: str) -> None:
    assert member == expected
    assert isinstance(member, str)


@pytest.mark.parametrize(
    "member,expected",
    [
        (LineInterpolation.LINEAR, "linear"),
        (LineInterpolation.SPLINE, "spline"),
        (LineInterpolation.STEP_HV, "hv"),
        (LineInterpolation.STEP_VH, "vh"),
    ],
)
def test_line_interpolation_values(member: LineInterpolation, expected: str) -> None:
    assert member == expected
    assert isinstance(member, str)


@pytest.mark.parametrize(
    "member,expected",
    [
        (LineSortOrder.NONE, "none"),
        (LineSortOrder.ALPHABETICAL_ASC, "alpha_asc"),
        (LineSortOrder.ALPHABETICAL_DESC, "alpha_desc"),
        (LineSortOrder.FIRST_VALUE_ASC, "first_asc"),
        (LineSortOrder.FIRST_VALUE_DESC, "first_desc"),
        (LineSortOrder.LAST_VALUE_ASC, "last_asc"),
        (LineSortOrder.LAST_VALUE_DESC, "last_desc"),
    ],
)
def test_line_sort_order_values(member: LineSortOrder, expected: str) -> None:
    assert member == expected
    assert isinstance(member, str)


@pytest.mark.parametrize(
    "member,expected",
    [
        (GeoProjection.NATURAL_EARTH, "natural earth"),
        (GeoProjection.MERCATOR, "mercator"),
        (GeoProjection.ORTHOGRAPHIC, "orthographic"),
        (GeoProjection.EQUIRECTANGULAR, "equirectangular"),
        (GeoProjection.ROBINSON, "robinson"),
        (GeoProjection.KAVRAYSKIY7, "kavrayskiy7"),
    ],
)
def test_geo_projection_values(member: GeoProjection, expected: str) -> None:
    assert member == expected
    assert isinstance(member, str)
