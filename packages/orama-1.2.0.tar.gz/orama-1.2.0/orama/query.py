"""
Module defining query parameters for chart data retrieval.
"""

from dataclasses import dataclass

import polars as pl
from therismos.grouping import Aggregation


@dataclass(frozen=True)
class QueryParams:
    """
    Encapsulates parameters for grouped aggregation queries.

    :param group_fields: Fields to group by.
    :type group_fields: list[str]
    :param aggregations: Aggregation specifications to apply.
    :type aggregations: list[Aggregation]
    :param dataframe_schema: Expected Polars schema of the resulting DataFrame.
    :type dataframe_schema: pl.Schema
    """

    group_fields: list[str]
    aggregations: list[Aggregation]
    dataframe_schema: pl.Schema


__all__ = [
    "QueryParams",
]
