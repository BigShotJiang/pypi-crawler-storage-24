"""
Figure strategy implementations for orama.
"""

from orama.strategies.bar import AbstractBarChartStrategy, BarChartStrategy
from orama.strategies.base import FigureStrategy, FigureStrategyDescription, FigureView
from orama.strategies.boxplot import AbstractBoxplotChartStrategy, BoxplotChartStrategy
from orama.strategies.categorical_line import CategoricalLineChartStrategy
from orama.strategies.choropleth_map import ChoroplethMapChartStrategy
from orama.strategies.grouped_bar import GroupedBarChartStrategy
from orama.strategies.grouped_boxplot import GroupedBoxplotChartStrategy
from orama.strategies.heatmap import HeatMapChartStrategy
from orama.strategies.line import LineChartStrategy
from orama.strategies.pie import PieChartStrategy
from orama.strategies.sunburst import SunburstChartStrategy

__all__ = [
    "FigureStrategy",
    "FigureStrategyDescription",
    "FigureView",
    "AbstractBarChartStrategy",
    "BarChartStrategy",
    "GroupedBarChartStrategy",
    "LineChartStrategy",
    "CategoricalLineChartStrategy",
    "PieChartStrategy",
    "SunburstChartStrategy",
    "HeatMapChartStrategy",
    "AbstractBoxplotChartStrategy",
    "BoxplotChartStrategy",
    "GroupedBoxplotChartStrategy",
    "ChoroplethMapChartStrategy",
]
