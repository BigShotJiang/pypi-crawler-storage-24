"""
Static WTForms subform classes for the orama web layer.
"""

from wtforms import FieldList, FloatField, Form, FormField, StringField
from wtforms.validators import Optional


class PathVariableEntryForm(Form):  # type: ignore[misc]
    """
    Subform representing one level in an ordered categorical variable list.

    :ivar variable: The field path or variable name for this level.
    :vartype variable: StringField
    """

    variable = StringField("Variable")


class AnchorColorForm(Form):  # type: ignore[misc]
    """
    Subform representing a single anchor color entry.

    :ivar name: Theme color name (resolved via the active Theme).
    :vartype name: StringField
    :ivar hex: Hex color string (e.g. ``"#ff9a00"``), used when ``name`` is blank.
    :vartype hex: StringField
    """

    name = StringField("Name")
    hex = StringField("Color", validators=[Optional()])


class ColorRuleForm(Form):  # type: ignore[misc]
    """
    Subform representing a single color rule (selector + assigner pair).

    :ivar assigner_type: Type identifier string for the color assigner strategy
        (e.g. ``"ByCategory"``, ``"ByGroup"``, ``"ByValue"``).
    :vartype assigner_type: StringField
    :ivar selector_type: Type identifier string for the color selector strategy
        (e.g. ``"All"``, ``"ByCategoryName"``, ``"ValuesBelow"``).
    :vartype selector_type: StringField
    :ivar selector_threshold: Numeric threshold used by ``"ValuesBelow"`` and
        ``"ValuesAbove"`` selectors.
    :vartype selector_threshold: FloatField
    :ivar selector_category: Comma-separated category names used by
        ``"ByCategoryName"`` selector.
    :vartype selector_category: StringField
    :ivar assigner_range_min: Minimum value of the color scale range for
        ``"ByValue"`` assigner.
    :vartype assigner_range_min: FloatField
    :ivar assigner_range_max: Maximum value of the color scale range for
        ``"ByValue"`` assigner.
    :vartype assigner_range_max: FloatField
    :ivar assigner_range_center: Center value of the color scale range for
        ``"ByValue"`` assigner (enables symmetric diverging scales).
    :vartype assigner_range_center: FloatField
    :ivar anchor_colors: FieldList of AnchorColorForm entries defining the
        color palette anchors.
    :vartype anchor_colors: FieldList
    """

    assigner_type = StringField("Assigner type")
    selector_type = StringField("Selector type")
    selector_threshold = FloatField("Threshold", validators=[Optional()])
    selector_category = StringField("Category name", validators=[Optional()])
    assigner_range_min = FloatField("Range min", validators=[Optional()])
    assigner_range_max = FloatField("Range max", validators=[Optional()])
    assigner_range_center = FloatField("Range center at", validators=[Optional()])
    anchor_colors = FieldList(FormField(AnchorColorForm), min_entries=0)


__all__ = [
    "PathVariableEntryForm",
    "AnchorColorForm",
    "ColorRuleForm",
]
