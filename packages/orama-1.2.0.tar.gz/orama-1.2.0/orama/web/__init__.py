"""
orama web layer — WTForms binding. Requires ``orama[web]`` to be installed.
"""

try:
    from orama.web.figureview import FigureView
except ImportError as exc:
    raise ImportError("orama.web requires WTForms. Install it with: pip install 'orama[web]'") from exc

__all__ = ["FigureView"]
