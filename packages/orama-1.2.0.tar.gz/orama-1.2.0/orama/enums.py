"""
Various enumerations used in orama.
"""

from enum import Enum, StrEnum


class SortOrder(int, Enum):
    """
    Enumeration of possible sort orders.
    """

    ASCENDING = 1
    DESCENDING = -1
    NONE = 0


class LinePlacement(StrEnum):
    """
    Enumeration of placement modes for line chart series.
    """

    OVERLAPPING = "overlapping"
    STACKED = "stacked"
    STACKED_RELATIVE = "stacked_relative"
    RIDGELINE = "ridgeline"


class LineInterpolation(StrEnum):
    """
    Enumeration of interpolation modes for line chart traces.
    """

    LINEAR = "linear"
    SPLINE = "spline"
    STEP_HV = "hv"
    STEP_VH = "vh"


class LineSortOrder(StrEnum):
    """
    Enumeration of sort orders for line chart series/categories.
    """

    NONE = "none"
    ALPHABETICAL_ASC = "alpha_asc"
    ALPHABETICAL_DESC = "alpha_desc"
    FIRST_VALUE_ASC = "first_asc"
    FIRST_VALUE_DESC = "first_desc"
    LAST_VALUE_ASC = "last_asc"
    LAST_VALUE_DESC = "last_desc"


class GeoProjection(StrEnum):
    """
    Enumeration of geo projection types for choropleth maps.
    """

    NATURAL_EARTH = "natural earth"
    MERCATOR = "mercator"
    ORTHOGRAPHIC = "orthographic"
    EQUIRECTANGULAR = "equirectangular"
    ROBINSON = "robinson"
    KAVRAYSKIY7 = "kavrayskiy7"


__all__ = [
    "SortOrder",
    "LinePlacement",
    "LineInterpolation",
    "LineSortOrder",
    "GeoProjection",
]
