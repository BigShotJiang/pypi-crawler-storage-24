# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from ...CLI                       import konsol
from abc                          import ABC, abstractmethod
from curl_cffi.requests           import AsyncSession
from httpx                        import AsyncClient
from .PluginModels                import MainPageResult, SearchResult, MovieInfo, SeriesInfo
from ..Media.MediaHandler         import MediaHandler
from ..Extractor.ExtractorManager import ExtractorManager
from ..Extractor.ExtractorModels  import ExtractResult, Subtitle
from ..Helpers.MethodCache        import method_cache
from urllib.parse                 import urljoin
import asyncio

class PluginBase(ABC):
    name        = "Plugin"
    language    = "tr"
    main_url    = "https://example.com"
    favicon     = f"https://www.google.com/s2/favicons?domain={main_url}&sz=64"
    description = "No description provided."

    main_page                = {}
    method_cache_ttl         = 3600
    method_cache_max_entries = 512
    cached_methods           = ("search", "get_main_page", "load_item")

    async def url_update(self, new_url: str):
        self.favicon   = self.favicon.replace(self.main_url, new_url)
        self.main_page = {url.replace(self.main_url, new_url): category for url, category in self.main_page.items()}
        self.main_url  = new_url

    def __init__(self, proxy: str | dict | None = None, ex_manager: str | ExtractorManager = "Extractors"):
        # curl_cffi - for bypassing Cloudflare TLS/HTTP2 fingerprints
        self._cf_session = AsyncSession(impersonate="chrome")
        self._cf_session.headers.update({
            "User-Agent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 15.7; rv:135.0) Gecko/20100101 Firefox/135.0",
            "Accept"     : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        })

        if proxy:
            proxy_str                = proxy if isinstance(proxy, str) else (proxy.get("https") or proxy.get("http"))
            self._cf_session.proxies = {"http": proxy_str, "https": proxy_str}

        # Convert dict proxy to string for httpx if necessary
        httpx_proxy = proxy
        if isinstance(proxy, dict):
            httpx_proxy = proxy.get("https") or proxy.get("http")

        # httpx - lightweight and safe for most HTTP requests
        self.httpx = AsyncClient(
            timeout          = 10,
            follow_redirects = True,
            proxy            = httpx_proxy
        )
        self.httpx.headers.update(self._cf_session.headers)
        self.httpx.headers.update({
            "User-Agent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 15.7; rv:135.0) Gecko/20100101 Firefox/135.0",
            "Accept"     : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        })

        self.media_handler = MediaHandler()

        # If an instance is passed, use it; otherwise create a new one
        if isinstance(ex_manager, ExtractorManager):
            self.ex_manager = ex_manager
        else:
            self.ex_manager = ExtractorManager(extractor_dir=ex_manager)

        self.failed_extractions: list[dict] = []

        self._cache_namespace = f"{self.__class__.__module__}.{self.__class__.__name__}"
        self._setup_default_method_caches()

    def _setup_default_method_caches(self):
        self._setup_method_cache(
            "search",
            self._cache_key_search,
            should_cache=self._should_cache_search,
        )
        self._setup_method_cache(
            "get_main_page",
            self._cache_key_get_main_page,
            should_cache=self._should_cache_get_main_page,
        )
        self._setup_method_cache(
            "load_item",
            self._cache_key_load_item,
            should_cache=self._should_cache_load_item,
        )

    def _setup_method_cache(self, method_name: str, key_builder, should_cache=None):
        base_method  = getattr(PluginBase, method_name, None)
        class_method = getattr(self.__class__, method_name, None)
        if class_method is base_method:
            return

        original_method = getattr(self, method_name, None)
        if not callable(original_method):
            return
        if getattr(original_method, "__wb_cached_method__", False):
            return

        async def cached_method(*args, **kwargs):
            key = key_builder(*args, **kwargs)
            return await method_cache.run(
                namespace    = self._cache_namespace,
                method_name  = method_name,
                key          = key,
                producer     = lambda: original_method(*args, **kwargs),
                should_cache = should_cache,
                ttl          = self.method_cache_ttl,
                max_entries  = self.method_cache_max_entries
            )

        cached_method.__wb_cached_method__      = True
        cached_method.__wb_cached_method_name__ = method_name
        setattr(self, method_name, cached_method)

    @staticmethod
    def _normalize_cache_key_part(value: object, *, casefold: bool = False) -> str:
        part = " ".join(str(value or "").split()).strip()
        return part.casefold() if casefold else part

    @staticmethod
    def _pick_arg(args: tuple, kwargs: dict, pos: int, names: tuple[str, ...], default: object = "") -> object:
        for name in names:
            if name in kwargs:
                return kwargs[name]
        return args[pos] if len(args) > pos else default

    def _cache_key_search(self, *args, **kwargs) -> str:
        query = self._pick_arg(args, kwargs, 0, ("query",))
        return self._normalize_cache_key_part(query, casefold=True)

    def _cache_key_get_main_page(self, *args, **kwargs) -> str:
        page     = self._pick_arg(args, kwargs, 0, ("page",), 1)
        url      = self._pick_arg(args, kwargs, 1, ("url", "encoded_url"))
        category = self._pick_arg(args, kwargs, 2, ("category", "encoded_category"))
        return (
            f"page={self._normalize_cache_key_part(page)}"
            f"|url={self._normalize_cache_key_part(url)}"
            f"|category={self._normalize_cache_key_part(category)}"
        )

    def _cache_key_load_item(self, *args, **kwargs) -> str:
        url = self._pick_arg(args, kwargs, 0, ("url", "encoded_url"))
        return self._normalize_cache_key_part(url)

    @staticmethod
    def _should_cache_search(payload) -> bool:
        return isinstance(payload, list) and len(payload) > 0

    @staticmethod
    def _should_cache_get_main_page(payload) -> bool:
        return isinstance(payload, list) and len(payload) > 0

    @staticmethod
    def _should_cache_load_item(payload) -> bool:
        if payload is None:
            return False
        if isinstance(payload, dict):
            return bool(payload)
        return True

    @abstractmethod
    async def get_main_page(self, page: int, url: str, category: str) -> list[MainPageResult]:
        """Ana sayfadaki popüler içerikleri döndürür."""
        pass

    @abstractmethod
    async def search(self, query: str) -> list[SearchResult]:
        """Kullanıcı arama sorgusuna göre sonuç döndürür."""
        pass

    @abstractmethod
    async def load_item(self, url: str) -> MovieInfo | SeriesInfo:
        """Bir medya öğesi hakkında detaylı bilgi döndürür."""
        pass

    @abstractmethod
    async def load_links(self, url: str) -> list[ExtractResult]:
        """
        Bir medya öğesi için oynatma bağlantılarını döndürür.

        Args:
            url: Medya URL'si

        Returns:
            ExtractResult listesi, her biri şu alanları içerir:
            - url (str, zorunlu): Video URL'si
            - name (str, zorunlu): Gösterim adı (tüm bilgileri içerir)
            - referer (str, opsiyonel): Referer header
            - subtitles (list[Subtitle], opsiyonel): Altyazı listesi

        Example:
            [
                ExtractResult(
                    url  = "https://example.com/video.m3u8",
                    name = "HDFilmCehennemi | 1080p TR Dublaj"
                )
            ]
        """
        pass

    # ========================
    # YARDIMCI METOTLAR
    # ========================

    def collect_results(self, results: list[ExtractResult], data: ExtractResult | list[ExtractResult] | None):
        """
        extract() dönüşünü (tekil, liste veya None) sonuç listesine ekler.
        28+ plugin'de tekrar eden pattern'i ortadan kaldırır.

        Kullanım:
            data = await self.extract(url)
            self.collect_results(results, data)
        """
        if data:
            results.extend(data if isinstance(data, list) else [data])

    @staticmethod
    def deduplicate(results: list[ExtractResult], key: str = "url") -> list[ExtractResult]:
        """
        Sonuç listesinden tekrar eden URL'leri kaldırır.

        Args:
            results : ExtractResult listesi
            key     : Deduplicate anahtarı ("url" veya "url+name")
        """
        seen    = set()
        uniques = []
        for res in results:
            k = (res.url, res.name) if key == "url+name" else res.url
            if k and k not in seen:
                uniques.append(res)
                seen.add(k)
        return uniques

    @staticmethod
    async def gather_with_limit(tasks: list, limit: int = 5):
        """
        Semaphore ile rate-limited paralel çalıştırma.

        Kullanım:
            tasks   = [self.extract(url) for url in urls]
            results = await self.gather_with_limit(tasks, limit=5)
        """
        sem = asyncio.Semaphore(limit)
        async def limited(coro):
            async with sem:
                return await coro
        return await asyncio.gather(*(limited(t) for t in tasks))

    async def async_cf_get(self, url: str, **kwargs):
        """
        curl_cffi.AsyncSession ile Cloudflare bypasslı GET isteği.
        Cloudflare korumalı sitelerde kullanılır.
        """
        return await self._cf_session.get(url, **kwargs)

    async def async_cf_post(self, url: str, **kwargs):
        """
        curl_cffi.AsyncSession ile Cloudflare bypasslı POST isteği.
        Cloudflare korumalı sitelerde kullanılır.
        """
        return await self._cf_session.post(url, **kwargs)

    @staticmethod
    def new_subtitle(url: str, name: str = "Altyazı") -> Subtitle:
        """Hızlı Subtitle nesnesi oluşturur."""
        return Subtitle(name=name, url=url)

    @staticmethod
    def sync_subtitles(results: list[ExtractResult]) -> list[ExtractResult]:
        """
        Tüm ExtractResult'lardaki altyazıları birleştirir ve her sonuca dağıtır.

        - Aynı URL'ye sahip altyazılar tekrarlanmaz.
        - Aynı isme sahip farklı URL'ler "İsim", "İsim (2)" şeklinde numaralandırılır.
        - Engine tarafından her load_links çağrısından sonra otomatik uygulanır.
        """
        if not results:
            return results

        # 1. Tüm altyazıları URL'ye göre topla (dedup)
        seen_urls: dict[str, Subtitle] = {}
        for res in results:
            for sub in res.subtitles:
                if sub.url not in seen_urls:
                    seen_urls[sub.url] = sub

        if not seen_urls:
            return results

        # 2. Aynı isimli farklı URL'leri numaralandır
        merged                      = list(seen_urls.values())
        name_count : dict[str, int] = {}
        for sub in merged:
            name_count[sub.name] = name_count.get(sub.name, 0) + 1

        name_idx   : dict[str, int] = {}
        final_subs : list[Subtitle] = []
        for sub in merged:
            if name_count[sub.name] > 1:
                idx              = name_idx.get(sub.name, 0) + 1
                name_idx[sub.name] = idx
                label            = sub.name if idx == 1 else f"{sub.name} ({idx})"
                final_subs.append(Subtitle(name=label, url=sub.url))
            else:
                final_subs.append(sub)

        # 3. Birleşik listeyi tüm sonuçlara ata
        for res in results:
            res.subtitles = list(final_subs)

        return results

    async def close(self):
        """Close HTTP client."""
        await self.httpx.aclose()
        await self._cf_session.close()

    def fix_url(self, url: str) -> str:
        if not url:
            return ""

        if url.startswith("http") or url.startswith("{\""):
            return url.replace("\\", "")

        url = f"https:{url}" if url.startswith("//") else urljoin(self.main_url, url)
        return url.replace("\\", "")

    async def extract(
        self,
        url: str,
        referer: str = None,
        prefix: str | None = None,
        name_override: str | None = None
    ) -> ExtractResult | list[ExtractResult] | None:
        """
        Extractor ile video URL'sini çıkarır.

        Args:
            url: Iframe veya video URL'si
            referer: Referer header (varsayılan: plugin main_url)
            prefix: İsmin başına eklenecek opsiyonel etiket (örn: "Türkçe Dublaj")
            name_override: İsmi tamamen değiştirecek opsiyonel etiket (Extractor adını ezer)

        Returns:
            ExtractResult: Extractor sonucu (name prefix ile birleştirilmiş) veya None

        Extractor bulunamadığında veya hata oluştuğunda uyarı verir.
        """
        if referer is None:
            referer = f"{self.main_url}/"

        extractor = self.ex_manager.find_extractor(url)
        if not extractor:
            konsol.log(f"[magenta][?] {self.name} » Extractor bulunamadı: {url}")
            self.failed_extractions.append({"url": url, "extractor": "", "name": name_override or prefix or "", "error": "Extractor bulunamadı"})
            return None

        try:
            data = await extractor.extract(url, referer=referer)

            # Liste ise her bir öğe için prefix/override ekle
            if isinstance(data, list):
                for item in data:
                    item.extractor = extractor.name
                    if name_override:
                        item.name = name_override
                    elif prefix and item.name:
                        if item.name.lower() in prefix.lower():
                            item.name = prefix
                        else:
                            item.name = f"{prefix} | {item.name}"
                return data

            # Tekil öğe ise
            data.extractor = extractor.name
            if name_override:
                data.name = name_override
            elif prefix and data.name:
                if data.name.lower() in prefix.lower():
                    data.name = prefix
                else:
                    data.name = f"{prefix} | {data.name}"

            return data
        except Exception as hata:
            konsol.log(f"[red][!] {self.name} » Extractor hatası ({extractor.name}): {hata}")
            self.failed_extractions.append({"url": url, "extractor": extractor.name, "name": name_override or prefix or "", "error": str(hata)})
            return None

    async def play(self, **kwargs):
        """
        Varsayılan oynatma metodu.
        Tüm pluginlerde ortak kullanılır.
        """
        extract_result = ExtractResult(**kwargs)
        self.media_handler.title = kwargs.get("name")
        if self.name not in self.media_handler.title:
            self.media_handler.title = f"{self.name} | {self.media_handler.title}"

        self.media_handler.play_media(extract_result)
