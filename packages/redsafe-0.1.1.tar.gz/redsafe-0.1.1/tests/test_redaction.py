from core.data_models import Detection
from redaction.placeholder_mapper import PlaceholderMapper
from redaction.redact_text import redact_text_content


def test_placeholder_mapper_is_consistent_for_repeated_values():
    mapper = PlaceholderMapper()
    a = mapper.get_or_create("john@example.com", "EMAIL")
    b = mapper.get_or_create("john@example.com", "EMAIL")
    c = mapper.get_or_create("admin@example.com", "EMAIL")

    assert a == b
    assert a != c
    assert a == "<EMAIL_1>"
    assert c == "<EMAIL_2>"


def test_redact_text_preserves_http_structure():
    text = (
        "POST /login HTTP/1.1\n"
        "Authorization: Bearer eyJhbGciOiJIUzI1Ni.abc.def\n"
        "\n"
        "email=john@example.com&password=Secret123"
    )
    detections = [
        Detection(kind="JWT_TOKEN", value="eyJhbGciOiJIUzI1Ni.abc.def"),
        Detection(kind="EMAIL", value="john@example.com"),
        Detection(kind="PASSWORD", value="Secret123"),
    ]

    redacted = redact_text_content(text, detections, PlaceholderMapper())
    assert "POST /login HTTP/1.1" in redacted
    assert "Authorization: Bearer <JWT_TOKEN_1>" in redacted
    assert "email=<EMAIL_1>&password=<PASSWORD_1>" in redacted
