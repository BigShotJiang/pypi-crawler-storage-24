from pathlib import Path

from core.redaction_pipeline import RedactionPipeline


ROOT = Path(__file__).resolve().parent


def test_http_pipeline_outputs_sanitized_file(tmp_path):
    pipeline = RedactionPipeline()
    input_path = str(ROOT / "sample_http.txt")
    out_dir = tmp_path / "sanitized"

    result = pipeline.process_http(input_path, str(out_dir))

    out_file = out_dir / "sample_http.sanitized.txt"
    assert out_file.exists()
    text = out_file.read_text(encoding="utf-8")

    assert "admin@example.com" not in text
    assert "<EMAIL_" in text
    assert result.summary.detected_count >= 1
    assert result.summary.redacted_count >= 1
    assert len(result.summary.mappings) >= 1


def test_http_protocol_aware_redaction_for_auth_cookie_and_json(tmp_path):
    pipeline = RedactionPipeline()
    out_dir = tmp_path / "sanitized"

    raw_http = (
        "POST /api/login HTTP/1.1\n"
        "Host: app.local\n"
        "Authorization: Bearer eyJhbGciOiJIUzI1Ni.eyJzdWIiOiIxMjMifQ.signature123456\n"
        "Cookie: sessionid=abcDEF1234567890; csrftoken=csrfValue123456\n"
        "Content-Type: application/json\n\n"
        '{"email":"admin@example.com","access_token":"tok_1234567890ABCDEF","client_secret":"sec_ABC123456789"}'
    )

    input_path = tmp_path / "proto_http.txt"
    input_path.write_text(raw_http, encoding="utf-8")

    pipeline.process_http(str(input_path), str(out_dir))

    out_file = out_dir / "proto_http.sanitized.txt"
    text = out_file.read_text(encoding="utf-8")

    assert "Authorization: Bearer eyJ" not in text
    assert "sessionid=abcDEF1234567890" not in text
    assert "csrftoken=csrfValue123456" not in text
    assert "tok_1234567890ABCDEF" not in text
    assert "sec_ABC123456789" not in text

    assert "Authorization: Bearer <" in text
    assert "sessionid=<" in text
    assert "csrftoken=<" in text
    assert "\"access_token\":\"<" in text
    assert "\"client_secret\":\"<" in text


def test_burp_pipeline_outputs_sanitized_file(tmp_path):
    pipeline = RedactionPipeline()
    input_path = str(ROOT / "sample_burp.xml")
    out_dir = tmp_path / "sanitized"

    result = pipeline.process_burp(input_path, str(out_dir))

    out_file = out_dir / "sample_burp.sanitized.txt"
    assert out_file.exists()
    text = out_file.read_text(encoding="utf-8")

    assert "john@example.com" not in text
    assert "<EMAIL_" in text
    assert result.summary.detected_count >= 1
