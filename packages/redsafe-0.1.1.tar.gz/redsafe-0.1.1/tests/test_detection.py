from detection.context_detection import ContextDetector
from detection.entropy_detection import EntropyDetector
from detection.entity_detection import EntityDetector
from detection.secret_detection import SecretDetectionConfig, SecretDetector


def test_entropy_detector_flags_high_entropy_token():
    value = "a8F92kLm1QwZx7VbP0n3RtY5uHc6JdE4"
    assert EntropyDetector.is_high_entropy(value, threshold=3.5, min_len=16)


def test_secret_detector_detects_jwt_aws_and_session_cookie():
    text = (
        "Authorization: Bearer eyJhbGciOiJIUzI1Ni.eyJzdWIiOiIxMjM0NTYifQ.signature123456789\n"
        "X-Api-Key: AKIA1234567890ABCD12\n"
        "Cookie: sessionid=abcDEF1234567890"
    )
    detector = SecretDetector()
    kinds = {d.kind for d in detector.detect(text)}
    assert "JWT_TOKEN" in kinds
    assert "AWS_KEY" in kinds
    assert "SESSION_COOKIE" in kinds


def test_secret_detector_ignores_configured_values():
    cfg = SecretDetectionConfig(ignore_exact_values={"application/x-www-form-urlencoded"})
    detector = SecretDetector(config=cfg)
    text = "Content-Type: application/x-www-form-urlencoded"
    found = detector.detect(text)
    assert all(d.value.lower() != "application/x-www-form-urlencoded" for d in found)


def test_context_detector_marks_sensitive_keys():
    pairs = {"password": "secret123", "token": "abcxyz123456", "normal": "ok"}
    dets = ContextDetector().detect_pairs(pairs)
    kinds = {d.kind for d in dets}
    assert "PASSWORD" in kinds
    assert "TOKEN" in kinds


def test_entity_detector_finds_email_and_phone_without_spacy_model_requirement():
    text = "Contact admin@example.com or +1 212-555-1212"
    dets = EntityDetector().detect(text)
    kinds = {d.kind for d in dets}
    assert "EMAIL" in kinds
    assert "PHONE" in kinds
