from __future__ import annotations

from typing import List

from core.data_models import ImageOCRToken

try:
    import cv2  # type: ignore
    import pytesseract  # type: ignore
except Exception:  # pragma: no cover
    cv2 = None
    pytesseract = None


def extract_ocr_tokens(image_path: str) -> List[ImageOCRToken]:
    if cv2 is None or pytesseract is None:
        raise RuntimeError("Image redaction dependencies missing: install opencv-python and pytesseract")

    image = cv2.imread(image_path)
    if image is None:
        return []

    data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
    tokens: List[ImageOCRToken] = []

    n = len(data.get("text", []))
    for i in range(n):
        text = (data["text"][i] or "").strip()
        if not text:
            continue
        tokens.append(
            ImageOCRToken(
                text=text,
                left=int(data["left"][i]),
                top=int(data["top"][i]),
                width=int(data["width"][i]),
                height=int(data["height"][i]),
            )
        )

    return tokens
