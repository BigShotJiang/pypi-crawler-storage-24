from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List

from core.data_models import HTTPExchange
from parsers.http_parser import HTTP_METHODS, parse_http_file, parse_http_request, parse_http_response
from utils.encoding_utils import safe_b64decode


class BurpParseError(ValueError):
    pass


def _format_hint(path: str) -> str:
    p = Path(path)
    if not p.exists():
        return f"Input file not found: {path}"

    raw = p.read_bytes()[:256]
    stripped = raw.lstrip()

    if raw.startswith(b"\x1f\x8b"):
        return (
            "Input appears to be GZip-compressed, not plain Burp XML. "
            "The engine can still attempt binary extraction, or you can export HTTP history from Burp as XML."
        )

    if raw.startswith(b"SQLite format 3"):
        return (
            "Input appears to be a SQLite Burp project/session file, not Burp XML export. "
            "The engine will attempt best-effort HTTP extraction from binary content."
        )

    if stripped.startswith(b"{") or stripped.startswith(b"["):
        return "Input appears to be JSON, not Burp XML."

    if not stripped.startswith(b"<"):
        return (
            "Input is not XML at the first non-whitespace byte. "
            "Expected Burp XML export with <items><item>...; falling back to binary extraction."
        )

    return "Malformed Burp XML file. Falling back to best-effort binary extraction."


def parse_burp_xml(xml_path: str) -> List[HTTPExchange]:
    try:
        tree = ET.parse(xml_path)
    except ET.ParseError as exc:
        hint = _format_hint(xml_path)
        raise BurpParseError(f"Failed to parse Burp XML: {exc}. {hint}") from exc

    root = tree.getroot()
    exchanges: List[HTTPExchange] = []

    for item in root.findall(".//item"):
        request_node = item.find("request")
        response_node = item.find("response")

        raw_req = ""
        raw_resp = ""

        if request_node is not None and request_node.text:
            if request_node.attrib.get("base64", "false").lower() == "true":
                raw_req = safe_b64decode(request_node.text.strip())
            else:
                raw_req = request_node.text

        if response_node is not None and response_node.text:
            if response_node.attrib.get("base64", "false").lower() == "true":
                raw_resp = safe_b64decode(response_node.text.strip())
            else:
                raw_resp = response_node.text

        if not raw_req and not raw_resp:
            continue

        request = parse_http_request(raw_req) if raw_req else parse_http_request("")
        response = parse_http_response(raw_resp) if raw_resp else None
        exchanges.append(HTTPExchange(request=request, response=response, source=xml_path))

    return exchanges


def _extract_binary_http_chunks(blob: bytes) -> List[str]:
    text = blob.decode("latin-1", errors="ignore")
    chunks: List[str] = []

    leading_noise_re = re.compile(r"^[^A-Z]*(?=(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|HTTP/))")

    for part in text.split("\x00"):
        if "HTTP/1." not in part and not any(f"{m} " in part for m in HTTP_METHODS):
            continue
        cleaned = leading_noise_re.sub("", part).strip()
        if len(cleaned) >= 20:
            chunks.append(cleaned)

    if chunks:
        return chunks

    # Fallback: slice around request start-lines.
    req_re = re.compile(r"(?:GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\s+\S+\s+HTTP/1\.[01]")
    starts = [m.start() for m in req_re.finditer(text)]
    if not starts:
        return []

    max_window = 64 * 1024
    for i, start in enumerate(starts):
        end = starts[i + 1] if i + 1 < len(starts) else min(len(text), start + max_window)
        candidate = text[start:end].strip()
        if len(candidate) >= 20:
            chunks.append(candidate)

    return chunks


def parse_burp_binary_fallback(path: str) -> List[HTTPExchange]:
    blob = Path(path).read_bytes()
    chunks = _extract_binary_http_chunks(blob)

    exchanges: List[HTTPExchange] = []
    for chunk in chunks:
        exchanges.extend(parse_http_file(chunk, source=path))

    # Final fallback: if parser couldn't split structures, at least capture raw request lines.
    if not exchanges:
        text = blob.decode("latin-1", errors="ignore")
        for line in text.splitlines():
            s = line.strip()
            parts = s.split()
            if len(parts) >= 3 and parts[0] in HTTP_METHODS and parts[2].startswith("HTTP/"):
                req = parse_http_request(s + "\r\n\r\n")
                exchanges.append(HTTPExchange(request=req, response=None, source=path))

    return exchanges


def parse_burp_input(path: str) -> List[HTTPExchange]:
    try:
        exchanges = parse_burp_xml(path)
        if exchanges:
            return exchanges
    except BurpParseError:
        pass

    return parse_burp_binary_fallback(path)
