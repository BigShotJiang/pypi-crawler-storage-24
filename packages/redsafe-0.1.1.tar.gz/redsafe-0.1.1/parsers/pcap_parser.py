from __future__ import annotations

import re
from pathlib import Path
from typing import List

from core.data_models import HTTPExchange
from parsers.http_parser import parse_http_file


HTTP_HINT = re.compile(r"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\s+\S+\s+HTTP/1\.[01]")
LEADING_NOISE_RE = re.compile(r"^[^A-Z]*(?=(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|HTTP/))")


def _normalize_candidate(chunk: str) -> str:
    # Remove leading binary/garbage bytes before HTTP start line.
    return LEADING_NOISE_RE.sub("", chunk)


def parse_pcap_basic(path: str) -> List[HTTPExchange]:
    """
    Basic PCAP parsing without external packet libraries.
    Reads binary bytes, extracts printable text windows, and tries HTTP parsing.
    """
    data = Path(path).read_bytes()
    text = data.decode("latin-1", errors="ignore")

    candidates: List[str] = []
    for chunk in text.split("\x00"):
        if "HTTP/1." in chunk or HTTP_HINT.search(chunk):
            cleaned = _normalize_candidate(chunk)
            if len(cleaned.strip()) > 20:
                candidates.append(cleaned)

    exchanges: List[HTTPExchange] = []
    for c in candidates:
        exchanges.extend(parse_http_file(c, source=path))

    return exchanges
