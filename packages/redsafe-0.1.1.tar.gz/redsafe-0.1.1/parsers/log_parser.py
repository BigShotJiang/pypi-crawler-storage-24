from __future__ import annotations

import re
from typing import Dict, List


def parse_network_log(text: str) -> List[Dict[str, str]]:
    entries: List[Dict[str, str]] = []
    lines = [line.strip() for line in text.splitlines() if line.strip()]

    kv_pattern = re.compile(r"([A-Za-z0-9_\-]+)=([^\s]+)")

    for line in lines:
        entry: Dict[str, str] = {"raw": line}
        for key, value in kv_pattern.findall(line):
            entry[key] = value
        entries.append(entry)

    return entries
