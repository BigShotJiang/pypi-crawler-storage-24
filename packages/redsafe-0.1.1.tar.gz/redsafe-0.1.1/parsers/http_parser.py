from __future__ import annotations

from dataclasses import asdict
from typing import Dict, List, Optional, Tuple
from urllib.parse import parse_qsl, urlsplit

from core.data_models import HTTPExchange, HTTPMessage, HTTPResponse


HTTP_METHODS = {"GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS", "TRACE", "CONNECT"}


def _split_headers_body(raw: str) -> Tuple[str, str]:
    if "\r\n\r\n" in raw:
        return raw.split("\r\n\r\n", 1)
    if "\n\n" in raw:
        return raw.split("\n\n", 1)
    return raw, ""


def _parse_headers(header_lines: List[str]) -> Dict[str, str]:
    headers: Dict[str, str] = {}
    for line in header_lines:
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        headers[k.strip()] = v.strip()
    return headers


def _extract_params(path: str, body: str, headers: Dict[str, str]) -> Dict[str, str]:
    params = dict(parse_qsl(urlsplit(path).query, keep_blank_values=True))
    content_type = headers.get("Content-Type", "").lower()
    if "application/x-www-form-urlencoded" in content_type and body:
        params.update(dict(parse_qsl(body, keep_blank_values=True)))
    return params


def parse_http_request(raw_request: str) -> HTTPMessage:
    header_raw, body = _split_headers_body(raw_request)
    lines = [l for l in header_raw.replace("\r\n", "\n").split("\n") if l is not None]
    if not lines or not lines[0].strip():
        return HTTPMessage(body=body)

    request_line = lines[0].strip()
    parts = request_line.split()
    if len(parts) >= 3 and parts[0].upper() in HTTP_METHODS:
        method, path, version = parts[0], parts[1], parts[2]
    else:
        method, path, version = "", "", ""

    headers = _parse_headers(lines[1:])
    params = _extract_params(path, body, headers)

    return HTTPMessage(
        method=method,
        path=path,
        version=version,
        headers=headers,
        parameters=params,
        body=body,
    )


def parse_http_response(raw_response: str) -> HTTPResponse:
    header_raw, body = _split_headers_body(raw_response)
    lines = [l for l in header_raw.replace("\r\n", "\n").split("\n") if l is not None]
    if not lines or not lines[0].strip():
        return HTTPResponse(body=body)

    status_line = lines[0].strip()
    parts = status_line.split(maxsplit=2)
    version = parts[0] if len(parts) > 0 else ""
    status_code = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
    reason = parts[2] if len(parts) > 2 else ""
    headers = _parse_headers(lines[1:])

    return HTTPResponse(
        version=version,
        status_code=status_code,
        reason=reason,
        headers=headers,
        body=body,
    )


def parse_http_file(raw_text: str, source: str = "") -> List[HTTPExchange]:
    normalized = raw_text.replace("\r\n", "\n")

    blocks = [b.strip("\n") for b in normalized.split("\n\n###\n") if b.strip()]
    if not blocks:
        blocks = [normalized]

    exchanges: List[HTTPExchange] = []

    for block in blocks:
        lines = [l for l in block.split("\n") if l.strip()]
        if not lines:
            continue

        first = lines[0].split()
        if first and first[0].upper() in HTTP_METHODS:
            request = parse_http_request(block)
            exchanges.append(HTTPExchange(request=request, response=None, source=source))
            continue

        if first and first[0].startswith("HTTP/"):
            response = parse_http_response(block)
            exchanges.append(HTTPExchange(request=HTTPMessage(), response=response, source=source))
            continue

        if "HTTP/" in block and any(m + " " in block for m in HTTP_METHODS):
            # Best effort split: request up to first response line.
            marker = "\nHTTP/"
            if marker in block:
                req_part, resp_part = block.split(marker, 1)
                response = parse_http_response("HTTP/" + resp_part)
                request = parse_http_request(req_part)
                exchanges.append(HTTPExchange(request=request, response=response, source=source))
            else:
                request = parse_http_request(block)
                exchanges.append(HTTPExchange(request=request, response=None, source=source))

    return exchanges
