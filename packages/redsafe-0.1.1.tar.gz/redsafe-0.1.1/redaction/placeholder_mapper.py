from __future__ import annotations

from collections import defaultdict
from typing import Dict


class PlaceholderMapper:
    def __init__(self) -> None:
        self.value_to_placeholder: Dict[str, str] = {}
        self.counters = defaultdict(int)

    def _normalize_kind(self, kind: str) -> str:
        return kind.upper().replace(" ", "_")

    def get_or_create(self, value: str, kind: str) -> str:
        if value in self.value_to_placeholder:
            return self.value_to_placeholder[value]

        k = self._normalize_kind(kind)
        self.counters[k] += 1
        placeholder = f"<{k}_{self.counters[k]}>"
        self.value_to_placeholder[value] = placeholder
        return placeholder

    def mapping(self) -> Dict[str, str]:
        return dict(self.value_to_placeholder)
