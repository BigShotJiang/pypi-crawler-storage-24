from __future__ import annotations

from typing import Iterable

from core.data_models import Detection, ImageOCRToken
from redaction.placeholder_mapper import PlaceholderMapper

try:
    import cv2  # type: ignore
except Exception:  # pragma: no cover
    cv2 = None


def _is_sensitive_token(token_text: str, detection_value: str) -> bool:
    t = token_text.strip().lower()
    d = detection_value.strip().lower()
    if not t or not d:
        return False
    return t == d or t in d or d in t


def redact_image_tokens(
    image_path: str,
    output_path: str,
    tokens: Iterable[ImageOCRToken],
    detections: Iterable[Detection],
    mapper: PlaceholderMapper,
) -> None:
    if cv2 is None:
        raise RuntimeError("Image redaction dependency missing: install opencv-python")

    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Could not load image: {image_path}")

    sensitive = [(d.value, d.kind) for d in detections if d.value]

    for token in tokens:
        for value, kind in sensitive:
            if _is_sensitive_token(token.text, value):
                mapper.get_or_create(value, kind)
                x1, y1 = max(token.left, 0), max(token.top, 0)
                x2, y2 = x1 + max(token.width, 1), y1 + max(token.height, 1)
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 0), thickness=-1)
                break

    cv2.imwrite(output_path, image)
