from __future__ import annotations

from typing import Iterable, Tuple

from core.data_models import Detection
from redaction.placeholder_mapper import PlaceholderMapper


def _unique_values(detections: Iterable[Detection]) -> list[Tuple[str, str]]:
    seen = set()
    pairs = []
    for d in detections:
        if not d.value:
            continue
        key = (d.value, d.kind)
        if key in seen:
            continue
        seen.add(key)
        pairs.append(key)
    return pairs


def redact_text_content(text: str, detections: Iterable[Detection], mapper: PlaceholderMapper) -> str:
    redacted = text

    # Longer strings first to avoid partial replacement conflicts.
    for value, kind in sorted(_unique_values(detections), key=lambda x: len(x[0]), reverse=True):
        placeholder = mapper.get_or_create(value, kind)
        redacted = redacted.replace(value, placeholder)

    return redacted
