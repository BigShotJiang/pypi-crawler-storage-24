import base64


def safe_b64decode(value: str) -> str:
    try:
        return base64.b64decode(value).decode("utf-8", errors="replace")
    except Exception:
        return value


def safe_decode_bytes(value: bytes) -> str:
    return value.decode("utf-8", errors="replace")
