from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class HTTPMessage:
    method: str = ""
    path: str = ""
    version: str = ""
    headers: Dict[str, str] = field(default_factory=dict)
    parameters: Dict[str, str] = field(default_factory=dict)
    body: str = ""


@dataclass
class HTTPResponse:
    status_code: int = 0
    reason: str = ""
    version: str = ""
    headers: Dict[str, str] = field(default_factory=dict)
    body: str = ""


@dataclass
class HTTPExchange:
    request: HTTPMessage
    response: Optional[HTTPResponse] = None
    source: str = ""


@dataclass
class Detection:
    kind: str
    value: str
    start: int = -1
    end: int = -1
    confidence: float = 1.0
    source: str = ""


@dataclass
class RedactionSummary:
    detected_count: int = 0
    redacted_count: int = 0
    mappings: Dict[str, str] = field(default_factory=dict)


@dataclass
class ImageOCRToken:
    text: str
    left: int
    top: int
    width: int
    height: int


@dataclass
class PipelineResult:
    sanitized_text: Optional[str] = None
    sanitized_image_path: Optional[str] = None
    detections: List[Detection] = field(default_factory=list)
    summary: RedactionSummary = field(default_factory=RedactionSummary)
