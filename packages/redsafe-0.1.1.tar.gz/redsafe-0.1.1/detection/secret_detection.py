from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import List, Set

from core.data_models import Detection
from detection.entropy_detection import EntropyDetector


JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")
AWS_ACCESS_RE = re.compile(r"\bAKIA[0-9A-Z]{16}\b")
GENERIC_API_KEY_RE = re.compile(r"\b(?:api[_-]?key|apikey|token|secret)[\s:=\"']+([A-Za-z0-9_\-]{16,}|[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,})", re.IGNORECASE)
SESSION_COOKIE_RE = re.compile(r"\b(?:sessionid|phpsessid|jsessionid|sid)=([A-Za-z0-9\-]{8,})\b", re.IGNORECASE)
SSH_PRIVATE_KEY_RE = re.compile(r"-----BEGIN (?:RSA|OPENSSH|EC|DSA) PRIVATE KEY-----")
BASE64_LONG_RE = re.compile(r"\b[A-Za-z0-9+/]{32,}={0,2}\b")
GENERIC_TOKEN_RE = re.compile(r"\b[A-Za-z0-9_\-+/]{20,}={0,2}\b")


@dataclass
class SecretDetectionConfig:
    entropy_threshold: float = 4.0
    min_token_len: int = 20
    min_base64_len: int = 24
    ignore_prefixes: tuple[str, ...] = (
        "http://",
        "https://",
        "application/",
        "text/",
        "image/",
        "multipart/",
    )
    ignore_exact_values: Set[str] = field(default_factory=set)

    @staticmethod
    def from_env() -> "SecretDetectionConfig":
        ignore_csv = os.getenv("REDACTION_IGNORE_VALUES", "")
        ignore_exact_values = {v.strip().lower() for v in ignore_csv.split(",") if v.strip()}

        threshold = float(os.getenv("REDACTION_ENTROPY_THRESHOLD", "4.0"))
        min_len = int(os.getenv("REDACTION_MIN_SECRET_LEN", "20"))
        min_b64_len = int(os.getenv("REDACTION_MIN_BASE64_LEN", "24"))

        return SecretDetectionConfig(
            entropy_threshold=threshold,
            min_token_len=min_len,
            min_base64_len=min_b64_len,
            ignore_exact_values=ignore_exact_values,
        )


class SecretDetector:
    def __init__(self, config: SecretDetectionConfig | None = None) -> None:
        self.entropy = EntropyDetector()
        self.config = config or SecretDetectionConfig.from_env()

    def _looks_like_secret(self, value: str) -> bool:
        low = value.lower()
        if low in self.config.ignore_exact_values:
            return False
        if low.startswith(self.config.ignore_prefixes):
            return False
        if " " in value:
            return False
        if value.count("=") > 2:
            return False

        has_alpha = any(c.isalpha() for c in value)
        has_digit = any(c.isdigit() for c in value)
        return has_alpha and has_digit

    def detect(self, text: str) -> List[Detection]:
        detections: List[Detection] = []

        for m in JWT_RE.finditer(text):
            detections.append(Detection(kind="JWT_TOKEN", value=m.group(0), start=m.start(), end=m.end(), source="regex"))

        for m in AWS_ACCESS_RE.finditer(text):
            detections.append(Detection(kind="AWS_KEY", value=m.group(0), start=m.start(), end=m.end(), source="regex"))

        for m in GENERIC_API_KEY_RE.finditer(text):
            secret_val = m.group(1)
            detections.append(Detection(kind="API_KEY", value=secret_val, start=m.start(1), end=m.end(1), source="regex"))

        for m in SESSION_COOKIE_RE.finditer(text):
            detections.append(Detection(kind="SESSION_COOKIE", value=m.group(1), start=m.start(1), end=m.end(1), source="regex"))

        for m in SSH_PRIVATE_KEY_RE.finditer(text):
            detections.append(Detection(kind="SSH_PRIVATE_KEY", value=m.group(0), start=m.start(), end=m.end(), source="regex"))

        for m in BASE64_LONG_RE.finditer(text):
            candidate = m.group(0)
            if len(candidate) < self.config.min_base64_len:
                continue
            if not self._looks_like_secret(candidate):
                continue
            if self.entropy.is_high_entropy(candidate, threshold=self.config.entropy_threshold, min_len=self.config.min_base64_len):
                detections.append(Detection(kind="HIGH_ENTROPY_SECRET", value=candidate, start=m.start(), end=m.end(), source="entropy"))

        for m in GENERIC_TOKEN_RE.finditer(text):
            token = m.group(0)
            if len(token) < self.config.min_token_len:
                continue
            if not self._looks_like_secret(token):
                continue
            if self.entropy.is_high_entropy(token, threshold=self.config.entropy_threshold, min_len=self.config.min_token_len):
                detections.append(Detection(kind="HIGH_ENTROPY_SECRET", value=token, start=m.start(), end=m.end(), source="entropy"))

        return detections
