from __future__ import annotations

import re
from typing import List

from core.data_models import Detection

try:
    import spacy  # type: ignore
except Exception:  # pragma: no cover
    spacy = None


EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
PHONE_RE = re.compile(r"\b(?:\+?\d{1,3}[\s.-]?)?(?:\(?\d{2,4}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}\b")
ADDRESS_HINT_RE = re.compile(r"\b\d{1,6}\s+[A-Za-z0-9\s]{3,}\s(?:Street|St|Road|Rd|Avenue|Ave|Lane|Ln|Boulevard|Blvd|Drive|Dr)\b", re.IGNORECASE)


class EntityDetector:
    def __init__(self) -> None:
        self._nlp = None
        self._load_model()

    def _load_model(self) -> None:
        if spacy is None:
            return
        for model in ("en_core_web_sm", "en_core_web_md"):
            try:
                self._nlp = spacy.load(model)
                return
            except Exception:
                continue

    def detect(self, text: str) -> List[Detection]:
        detections: List[Detection] = []

        for m in EMAIL_RE.finditer(text):
            detections.append(Detection(kind="EMAIL", value=m.group(0), start=m.start(), end=m.end(), source="regex"))

        for m in PHONE_RE.finditer(text):
            if len(re.sub(r"\D", "", m.group(0))) >= 7:
                detections.append(Detection(kind="PHONE", value=m.group(0), start=m.start(), end=m.end(), source="regex"))

        for m in ADDRESS_HINT_RE.finditer(text):
            detections.append(Detection(kind="ADDRESS", value=m.group(0), start=m.start(), end=m.end(), source="regex"))

        if self._nlp is None:
            return detections

        doc = self._nlp(text)
        for ent in doc.ents:
            label_map = {
                "PERSON": "NAME",
                "ORG": "ORGANIZATION",
                "GPE": "ADDRESS",
                "LOC": "ADDRESS",
                "FAC": "ADDRESS",
            }
            mapped = label_map.get(ent.label_)
            if mapped:
                detections.append(
                    Detection(
                        kind=mapped,
                        value=ent.text,
                        start=ent.start_char,
                        end=ent.end_char,
                        source="spacy",
                        confidence=0.9,
                    )
                )

        return detections
