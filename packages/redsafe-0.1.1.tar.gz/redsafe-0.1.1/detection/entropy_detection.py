from __future__ import annotations

import math
from collections import Counter


class EntropyDetector:
    @staticmethod
    def shannon_entropy(value: str) -> float:
        if not value:
            return 0.0
        counts = Counter(value)
        length = len(value)
        entropy = 0.0
        for count in counts.values():
            p = count / length
            entropy -= p * math.log2(p)
        return entropy

    @staticmethod
    def is_high_entropy(value: str, threshold: float = 3.5, min_len: int = 16) -> bool:
        if len(value) < min_len:
            return False
        return EntropyDetector.shannon_entropy(value) >= threshold
