from __future__ import annotations

from typing import Dict, List, Optional

from core.data_models import Detection


SENSITIVE_KEYS = {
    "password": "PASSWORD",
    "passwd": "PASSWORD",
    "passphrase": "PASSWORD",
    "secret": "SECRET",
    "token": "TOKEN",
    "access_token": "TOKEN",
    "refresh_token": "TOKEN",
    "id_token": "TOKEN",
    "apikey": "API_KEY",
    "api_key": "API_KEY",
    "client_secret": "SECRET",
    "authorization": "AUTHORIZATION",
    "auth": "AUTHORIZATION",
    "session": "SESSION",
    "cookie": "COOKIE",
    "csrf": "TOKEN",
    "private_key": "PRIVATE_KEY",
    "ssh_key": "PRIVATE_KEY",
}


class ContextDetector:
    def _kind_for_key(self, key: str) -> Optional[str]:
        key_lower = key.lower()
        for skey, kind in SENSITIVE_KEYS.items():
            if skey in key_lower:
                return kind
        return None

    def detect_pairs(self, pairs: Dict[str, str], source: str = "context") -> List[Detection]:
        detections: List[Detection] = []
        for key, value in pairs.items():
            if not value:
                continue
            kind = self._kind_for_key(key)
            if kind:
                detections.append(Detection(kind=kind, value=value, source=source, confidence=0.95))
        return detections
