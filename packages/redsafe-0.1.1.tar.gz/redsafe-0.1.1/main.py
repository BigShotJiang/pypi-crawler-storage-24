from __future__ import annotations

import argparse
from pathlib import Path

from core.redaction_pipeline import RedactionPipeline


def print_summary(result) -> None:
    print("\n=== Redaction Summary ===")
    print(f"Sensitive values detected: {result.summary.detected_count}")
    print(f"Sensitive values redacted: {result.summary.redacted_count}")
    print("Placeholder mappings:")

    if not result.summary.mappings:
        print("  (none)")
        return

    for original, placeholder in result.summary.mappings.items():
        print(f"  {original} -> {placeholder}")


def main() -> None:
    parser = argparse.ArgumentParser(description="AI Safe Redaction Engine")
    parser.add_argument("--input", required=True, help="Input file path")
    parser.add_argument("--type", required=True, choices=["burp", "http", "log", "pcap", "image"], help="Input type")
    parser.add_argument("--output", default="sanitized_output", help="Output directory")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: input file not found: {args.input}")
        return

    pipeline = RedactionPipeline()

    try:
        if args.type == "burp":
            result = pipeline.process_burp(args.input, args.output)
        elif args.type == "http":
            result = pipeline.process_http(args.input, args.output)
        elif args.type == "log":
            result = pipeline.process_log(args.input, args.output)
        elif args.type == "pcap":
            result = pipeline.process_pcap(args.input, args.output)
        else:
            result = pipeline.process_image(args.input, args.output)
    except Exception as exc:
        print(f"Error: {exc}")
        return

    print_summary(result)
    if result.sanitized_text is not None:
        out_file = Path(args.output) / (Path(args.input).stem + ".sanitized.txt")
        print(f"\nSanitized text written to: {out_file}")
    if result.sanitized_image_path is not None:
        print(f"\nSanitized image written to: {result.sanitized_image_path}")


if __name__ == "__main__":
    main()
