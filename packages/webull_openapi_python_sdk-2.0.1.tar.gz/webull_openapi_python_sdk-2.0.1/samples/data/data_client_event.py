# Copyright 2022 Webull
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# 	http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from webull.data.common.timespan import Timespan

# coding=utf-8

from webull.data.common.category import Category
from webull.core.client import ApiClient
from webull.data.data_client import DataClient

optional_api_endpoint = "<api_endpoint>"
your_app_key = "<your_app_key>"
your_app_secret = "<your_app_secret>"
region_id = "<region_id>"
# The token_dir parameter can be used to specify the directory for storing the 2FA token. Both absolute and relative paths are supported and this option has the highest priority.
# Alternatively, the storage directory can be configured via an environment variable with the key WEBULL_OPENAPI_TOKEN_DIR, which also supports both absolute and relative paths.
# If neither is specified, the default configuration will be used, and the token will be stored at conf/token.txt under the current working directory.
# token_dir = "<your_token_dir>"
# api_client.set_token_dir(token_dir)

api_client = ApiClient(your_app_key, your_app_secret, region_id)
api_client.add_endpoint(region_id, optional_api_endpoint)


if __name__ == '__main__':
    data_client = DataClient(api_client)

    res = data_client.instrument.get_event_categories()
    if res.status_code == 200:
        print('get_event_categories:', res.json())

    res = data_client.instrument.get_event_series("ECONOMICS")
    if res.status_code == 200:
        print('get_event_series:', res.json())

    res = data_client.instrument.get_event_events("KXRATECUTCOUNT")
    if res.status_code == 200:
        print('get_event_events:', res.json())

    res = data_client.instrument.get_event_instrument("KXRATECUTCOUNT")
    if res.status_code == 200:
        print('get_event_instrument:', res.json())

    res = data_client.event_market_data.get_event_snapshot("KXRATECUTCOUNT-25DEC31-T10", Category.US_EVENT.name)
    if res.status_code == 200:
        print('get_event_snapshot:', res.json())

    res = data_client.event_market_data.get_event_depth("KXRATECUTCOUNT-25DEC31-T10", Category.US_EVENT.name)
    if res.status_code == 200:
        print('get_event_depth:', res.json())

    res = data_client.event_market_data.get_event_bars("KXRATECUTCOUNT-25DEC31-T10", Timespan.M1, Category.US_EVENT.name, 200, False)
    if res.status_code == 200:
        print('get_event_bars:', res.json())

    res = data_client.event_market_data.get_event_tick("KXRATECUTCOUNT-25DEC31-T10", Category.US_EVENT.name, 30)
    if res.status_code == 200:
        print('get_event_tick:', res.json())