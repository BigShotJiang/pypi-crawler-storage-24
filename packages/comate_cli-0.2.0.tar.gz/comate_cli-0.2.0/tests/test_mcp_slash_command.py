from __future__ import annotations

import asyncio
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from comate_cli.terminal_agent.tui_parts.commands import CommandsMixin
from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []

    def append_system_message(self, text: str, *, severity: str = "info") -> None:
        self.messages.append((text, severity))


class _FakeSelectionUI:
    def __init__(self, *, set_options_ok: bool = True) -> None:
        self.set_options_ok = set_options_ok
        self.last_kwargs: dict | None = None
        self.on_confirm = None
        self.on_cancel = None
        self.refresh_calls = 0
        self.clear_calls = 0

    def set_options(self, **kwargs) -> bool:  # type: ignore[no-untyped-def]
        self.last_kwargs = kwargs
        self.on_confirm = kwargs.get("on_confirm")
        self.on_cancel = kwargs.get("on_cancel")
        return self.set_options_ok

    def refresh(self) -> None:
        self.refresh_calls += 1

    def clear(self) -> None:
        self.clear_calls += 1

    def cancel(self):  # type: ignore[no-untyped-def]
        if self.on_cancel is not None:
            self.on_cancel()
        return SimpleNamespace(confirmed=False, value=None, label=None)


class _Harness(CommandsMixin):
    def __init__(
        self,
        *,
        session: object,
        renderer: _FakeRenderer,
        selection_ui: _FakeSelectionUI,
    ) -> None:
        self._session = session
        self._renderer = renderer
        self._selection_ui = selection_ui
        self._ui_mode = UIMode.NORMAL
        self._sync_focus_calls = 0
        self._invalidate_calls = 0
        self._refresh_calls = 0
        self._scheduled_tasks: list[asyncio.Task[None]] = []

    def _terminal_width(self) -> int:
        return 100

    def _sync_focus_for_mode(self) -> None:
        self._sync_focus_calls += 1

    def _invalidate(self) -> None:
        self._invalidate_calls += 1

    def _refresh_layers(self) -> None:
        self._refresh_calls += 1

    def _schedule_background(self, coroutine):  # type: ignore[no-untyped-def]
        task = asyncio.create_task(coroutine)
        self._scheduled_tasks.append(task)

    async def drain_scheduled_tasks(self) -> None:
        while self._scheduled_tasks:
            tasks = list(self._scheduled_tasks)
            self._scheduled_tasks = []
            await asyncio.gather(*tasks)


def _build_session(*, manager: object | None) -> object:
    return SimpleNamespace(
        _cwd=Path("/tmp/project"),
        _agent=SimpleNamespace(_mcp_manager=manager),
    )


class TestMcpSlashCommand(unittest.IsolatedAsyncioTestCase):
    async def test_slash_mcp_usage_error(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(manager=None),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        await app._slash_mcp("--refresh")

        self.assertEqual(renderer.messages[-1], ("Usage: /mcp", "error"))
        self.assertIsNone(selection_ui.last_kwargs)

    async def test_slash_mcp_no_servers(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(manager=None),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        with (
            patch(
                "comate_agent_sdk.mcp.config.resolve_mcp_servers",
                return_value={},
            ),
            patch(
                "comate_agent_sdk.mcp.load_scope_servers",
                return_value={},
            ),
            patch(
                "comate_agent_sdk.mcp.scope_mcp_path",
                return_value=Path("/tmp/.agent/.mcp.json"),
            ),
        ):
            await app._slash_mcp("")

        self.assertEqual(renderer.messages[-1], ("No MCP servers configured.", "info"))
        self.assertIsNone(selection_ui.last_kwargs)

    async def test_slash_mcp_opens_selection_menu_without_scrollback_output(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        manager = SimpleNamespace(
            tool_infos=[
                SimpleNamespace(
                    server_alias="context7",
                    remote_name="resolve-library-id",
                    mapped_name="mcp__context7__resolve-library-id",
                    description="resolve library id",
                ),
                SimpleNamespace(
                    server_alias="context7",
                    remote_name="query-docs",
                    mapped_name="mcp__context7__query-docs",
                    description="query docs",
                ),
            ],
            failed_servers=[],
        )
        app = _Harness(
            session=_build_session(manager=manager),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        with (
            patch(
                "comate_agent_sdk.mcp.config.resolve_mcp_servers",
                return_value={
                    "context7": {
                        "type": "http",
                        "url": "https://mcp.context7.com/mcp",
                    }
                },
            ),
            patch(
                "comate_agent_sdk.mcp.load_scope_servers",
                side_effect=[
                    {},
                    {"context7": {"type": "http", "url": "https://mcp.context7.com/mcp"}},
                ],
            ),
            patch(
                "comate_agent_sdk.mcp.scope_mcp_path",
                side_effect=[
                    Path("/tmp/project/.agent/.mcp.json"),
                    Path("/home/test/.agent/.mcp.json"),
                ],
            ),
        ):
            await app._slash_mcp("")

        self.assertEqual(renderer.messages, [])
        self.assertEqual(app._ui_mode, UIMode.SELECTION)
        self.assertIsNotNone(selection_ui.last_kwargs)
        assert selection_ui.last_kwargs is not None
        self.assertEqual(selection_ui.last_kwargs["title"], "MCP Servers")
        self.assertEqual(selection_ui.last_kwargs["options"][0]["label"], "context7")
        self.assertIn("✓ Connected", selection_ui.last_kwargs["options"][0]["description"])
        self.assertNotIn(
            "https://mcp.context7.com/mcp",
            selection_ui.last_kwargs["options"][0]["description"],
        )
        self.assertIsNotNone(selection_ui.on_confirm)

    async def test_slash_mcp_hides_stdio_command_in_server_list(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(manager=None),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        with (
            patch(
                "comate_agent_sdk.mcp.config.resolve_mcp_servers",
                return_value={
                    "context7": {
                        "type": "stdio",
                        "command": "npx",
                        "args": ["-y", "@upstash/context7-mcp"],
                    }
                },
            ),
            patch(
                "comate_agent_sdk.mcp.load_scope_servers",
                side_effect=[
                    {},
                    {
                        "context7": {
                            "type": "stdio",
                            "command": "npx",
                            "args": ["-y", "@upstash/context7-mcp"],
                        }
                    },
                ],
            ),
            patch(
                "comate_agent_sdk.mcp.scope_mcp_path",
                side_effect=[
                    Path("/tmp/project/.agent/.mcp.json"),
                    Path("/home/test/.agent/.mcp.json"),
                ],
            ),
        ):
            await app._slash_mcp("")

        assert selection_ui.last_kwargs is not None
        self.assertEqual(selection_ui.last_kwargs["title"], "MCP Servers")
        self.assertEqual(
            selection_ui.last_kwargs["options"][0]["description"],
            "… Not initialized",
        )
        self.assertNotIn(
            "npx",
            selection_ui.last_kwargs["options"][0]["description"],
        )
        self.assertIsNotNone(selection_ui.on_confirm)

    async def test_slash_mcp_selection_keeps_tools_detail_without_url(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        manager = SimpleNamespace(
            tool_infos=[
                SimpleNamespace(
                    server_alias="context7",
                    remote_name="resolve-library-id",
                    mapped_name="mcp__context7__resolve-library-id",
                    description="resolve library id",
                ),
                SimpleNamespace(
                    server_alias="context7",
                    remote_name="query-docs",
                    mapped_name="mcp__context7__query-docs",
                    description="query docs",
                ),
            ],
            failed_servers=[],
        )
        app = _Harness(
            session=_build_session(manager=manager),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        with (
            patch(
                "comate_agent_sdk.mcp.config.resolve_mcp_servers",
                return_value={
                    "context7": {
                        "type": "http",
                        "url": "https://mcp.context7.com/mcp",
                    }
                },
            ),
            patch(
                "comate_agent_sdk.mcp.load_scope_servers",
                side_effect=[
                    {},
                    {"context7": {"type": "http", "url": "https://mcp.context7.com/mcp"}},
                ],
            ),
            patch(
                "comate_agent_sdk.mcp.scope_mcp_path",
                side_effect=[
                    Path("/tmp/project/.agent/.mcp.json"),
                    Path("/home/test/.agent/.mcp.json"),
                ],
            ),
        ):
            await app._slash_mcp("")

        assert selection_ui.on_confirm is not None
        selection_ui.on_confirm("context7")
        await app.drain_scheduled_tasks()

        assert selection_ui.last_kwargs is not None
        self.assertEqual(selection_ui.last_kwargs["title"], "context7 MCP Server")
        context = "\n".join(selection_ui.last_kwargs["context_lines"])
        self.assertIn("Tools: 2 tools", context)
        self.assertNotIn("URL:", context)

    async def test_slash_mcp_cancel_exits_selection_mode(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        manager = SimpleNamespace(
            tool_infos=[
                SimpleNamespace(
                    server_alias="context7",
                    remote_name="query-docs",
                    mapped_name="mcp__context7__query-docs",
                    description="query docs",
                ),
            ],
            failed_servers=[],
        )
        app = _Harness(
            session=_build_session(manager=manager),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        with (
            patch(
                "comate_agent_sdk.mcp.config.resolve_mcp_servers",
                return_value={
                    "context7": {
                        "type": "http",
                        "url": "https://mcp.context7.com/mcp",
                    }
                },
            ),
            patch(
                "comate_agent_sdk.mcp.load_scope_servers",
                side_effect=[
                    {},
                    {"context7": {"type": "http", "url": "https://mcp.context7.com/mcp"}},
                ],
            ),
            patch(
                "comate_agent_sdk.mcp.scope_mcp_path",
                side_effect=[
                    Path("/tmp/project/.agent/.mcp.json"),
                    Path("/home/test/.agent/.mcp.json"),
                ],
            ),
        ):
            await app._slash_mcp("")

        self.assertEqual(app._ui_mode, UIMode.SELECTION)
        assert selection_ui.on_cancel is not None
        result = selection_ui.cancel()
        app._handle_selection_result(result)
        await app.drain_scheduled_tasks()

        self.assertEqual(app._ui_mode, UIMode.NORMAL)


if __name__ == "__main__":
    unittest.main()
