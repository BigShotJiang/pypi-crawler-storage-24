from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from comate_cli.terminal_agent.custom_slash_commands import (
    CustomSlashCommand,
    CustomSlashExpandError,
    discover_custom_slash_commands,
    render_custom_slash_prompt,
)


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


class TestCustomSlashCommandDiscovery(unittest.TestCase):
    def test_discovery_respects_scope_priority_and_namespace(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            project_root = root / "project"
            user_root = root / "home"

            _write(
                project_root / ".agent" / "commands" / "review.md",
                "---\ndescription: project review\nargument-hint: [scope]\n---\nProject review body",
            )
            _write(
                project_root / ".agent" / "commands" / "frontend" / "component.md",
                "---\ndescription: make component\n---\nComponent body",
            )
            _write(
                project_root / ".agent" / "commands" / "help.md",
                "---\ndescription: conflict help\n---\nBad body",
            )
            _write(
                user_root / ".agent" / "commands" / "review.md",
                "---\ndescription: user review\n---\nUser review body",
            )

            result = discover_custom_slash_commands(
                project_root=project_root,
                builtin_names={"help", "h"},
                user_root=user_root,
            )

            self.assertEqual([item.name for item in result.commands], ["component", "review"])
            review = next(item for item in result.commands if item.name == "review")
            component = next(item for item in result.commands if item.name == "component")
            self.assertEqual(review.source_scope, "project")
            self.assertEqual(review.argument_hint, "[scope]")
            self.assertEqual(component.namespace, "frontend")
            self.assertTrue(any("conflicts with builtin" in w for w in result.warnings))
            self.assertTrue(any("already provided by project scope" in w for w in result.warnings))

    def test_discovery_skips_missing_frontmatter(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            project_root = Path(td) / "project"
            _write(
                project_root / ".agent" / "commands" / "broken.md",
                "description: no-frontmatter\ntext",
            )

            result = discover_custom_slash_commands(
                project_root=project_root,
                builtin_names=set(),
                user_root=Path(td) / "home",
            )
            self.assertEqual(result.commands, ())
            self.assertEqual(len(result.warnings), 1)
            self.assertIn("missing YAML frontmatter", result.warnings[0])

    def test_discovery_accepts_str_roots(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            project_root = Path(td) / "project"
            user_root = Path(td) / "home"
            _write(
                project_root / ".agent" / "commands" / "review.md",
                "---\ndescription: project review\n---\nProject review body",
            )

            result = discover_custom_slash_commands(
                project_root=str(project_root),
                builtin_names=set(),
                user_root=str(user_root),
            )

            self.assertEqual([item.name for item in result.commands], ["review"])


class TestCustomSlashCommandRendering(unittest.IsolatedAsyncioTestCase):
    async def test_render_replaces_positional_and_arguments_placeholders(self) -> None:
        command = CustomSlashCommand(
            name="fix-issue",
            description="Fix issue",
            template="Fix $1 with $ARGUMENTS[1]. raw=$ARGUMENTS",
            source_scope="project",
            namespace="",
            source_path=Path("/tmp/fix-issue.md"),
            argument_hint="[issue-number] [priority]",
        )

        rendered = await render_custom_slash_prompt(
            command=command,
            raw_args="123 high",
            project_root=Path.cwd(),
        )

        self.assertEqual(rendered, "Fix 123 with high. raw=123 high")

    async def test_render_appends_arguments_when_no_placeholder_used(self) -> None:
        command = CustomSlashCommand(
            name="test",
            description="Run tests",
            template="Run tests now.",
            source_scope="project",
            namespace="",
            source_path=Path("/tmp/test.md"),
            argument_hint="[pattern]",
        )

        rendered = await render_custom_slash_prompt(
            command=command,
            raw_args="unit smoke",
            project_root=Path.cwd(),
        )
        self.assertIn("Run tests now.", rendered)
        self.assertTrue(rendered.endswith("ARGUMENTS: unit smoke"))

    async def test_render_raises_for_missing_argument(self) -> None:
        command = CustomSlashCommand(
            name="need-two",
            description="Need two args",
            template="Need $2",
            source_scope="project",
            namespace="",
            source_path=Path("/tmp/need-two.md"),
        )

        with self.assertRaises(CustomSlashExpandError):
            await render_custom_slash_prompt(
                command=command,
                raw_args="onlyone",
                project_root=Path.cwd(),
            )

    async def test_render_supports_bash_and_file_references(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            project_root = Path(td)
            _write(project_root / "package.json", "{\n  \"name\": \"demo\"\n}\n")

            command = CustomSlashCommand(
                name="review-config",
                description="review",
                template="Status: !`printf 'ok'`\nConfig: @package.json",
                source_scope="project",
                namespace="",
                source_path=project_root / ".agent" / "commands" / "review-config.md",
            )

            rendered = await render_custom_slash_prompt(
                command=command,
                raw_args="",
                project_root=project_root,
            )
            self.assertIn("### Bash Command Output", rendered)
            self.assertIn("ok", rendered)
            self.assertIn("### File Content", rendered)
            self.assertIn("\"name\": \"demo\"", rendered)

    async def test_render_raises_when_bash_command_fails(self) -> None:
        command = CustomSlashCommand(
            name="git-commit",
            description="commit",
            template="Run: !`exit 2`",
            source_scope="project",
            namespace="",
            source_path=Path("/tmp/git-commit.md"),
        )

        with self.assertRaises(CustomSlashExpandError):
            await render_custom_slash_prompt(
                command=command,
                raw_args="",
                project_root=Path.cwd(),
            )

    async def test_render_rejects_absolute_file_reference(self) -> None:
        command = CustomSlashCommand(
            name="bad-file",
            description="bad",
            template="Ref: @/etc/passwd",
            source_scope="project",
            namespace="",
            source_path=Path("/tmp/bad-file.md"),
        )

        with self.assertRaises(CustomSlashExpandError):
            await render_custom_slash_prompt(
                command=command,
                raw_args="",
                project_root=Path.cwd(),
            )

    async def test_render_accepts_str_project_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            project_root = Path(td)
            _write(project_root / "README.md", "demo\n")
            command = CustomSlashCommand(
                name="show-readme",
                description="show",
                template="Ref: @README.md",
                source_scope="project",
                namespace="",
                source_path=project_root / ".agent" / "commands" / "show-readme.md",
            )

            rendered = await render_custom_slash_prompt(
                command=command,
                raw_args="",
                project_root=str(project_root),
            )

            self.assertIn("### File Content", rendered)
            self.assertIn("demo", rendered)


if __name__ == "__main__":
    unittest.main(verbosity=2)
