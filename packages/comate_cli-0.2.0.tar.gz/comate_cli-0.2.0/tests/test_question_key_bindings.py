from __future__ import annotations

import unittest

from prompt_toolkit.application import Application
from prompt_toolkit.application.current import set_app
from prompt_toolkit.layout import Layout

from comate_cli.terminal_agent.question_view import AskUserQuestionUI
from comate_cli.terminal_agent.tui_parts.key_bindings import KeyBindingsMixin
from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode


class _StubSelectionUI:
    def confirm(self):  # noqa: ANN201
        return None

    def move_selection(self, _delta: int) -> None:
        return None

    def cancel(self):  # noqa: ANN201
        return None

    def focus_target(self):  # noqa: ANN201
        return None


class _StubRunController:
    def interrupt(self, reason: str) -> None:  # noqa: ARG002
        return None


class _StubSession:
    def __init__(self) -> None:
        self.run_controller = _StubRunController()

    def request_exit(self) -> None:
        return None


class _StubRenderer:
    def interrupt_turn(self) -> None:
        return None

    def append_system_message(self, *_args, **_kwargs) -> None:
        return None


class _StubMentionCompleter:
    def extract_context(self, _text: str):  # noqa: ANN201
        return None


class _StubKeyBindingHost(KeyBindingsMixin):
    def __init__(self) -> None:
        self._ui_mode = UIMode.QUESTION
        self._question_ui = AskUserQuestionUI()
        self._question_ui.set_questions(
            [
                {
                    "question": "Q",
                    "header": "H",
                    "options": [{"label": "A", "description": ""}],
                    "multiSelect": False,
                }
            ]
        )
        self._selection_ui = _StubSelectionUI()
        self._mention_completer = _StubMentionCompleter()
        self._queued_messages = []
        self._busy = False
        self._initializing = False
        self._app = None
        self._stream_task = None
        self._interrupt_requested_at = None
        self._interrupt_force_window_seconds = 1.5
        self._session = _StubSession()
        self._renderer = _StubRenderer()
        self._waiting_for_input = False
        self._pending_questions = None
        self._esc_press_count = 0
        self._esc_last_pressed_at = 0.0
        self._esc_clear_window_seconds = 1.0
        self._ctrl_c_press_count = 0
        self._ctrl_c_last_pressed_at = 0.0
        self._ctrl_c_exit_window_seconds = 1.0
        self._input_area = type("InputArea", (), {"window": None})()

    def _handle_selection_result(self, *_args, **_kwargs) -> None:
        return None

    def _invalidate(self) -> None:
        return None

    def _sync_focus_for_mode(self) -> None:
        return None

    def _handle_question_action(self, *_args, **_kwargs) -> None:
        return None

    def _submit_from_input(self) -> None:
        return None

    def _cycle_agent_mode(self) -> None:
        return None

    def _move_completion_selection(self, *_args, **_kwargs) -> bool:
        return False

    def _move_cursor_visual(self, *_args, **_kwargs) -> bool:
        return False

    def _should_handle_history(self) -> bool:
        return False

    def _clear_input_area(self) -> None:
        return None

    def _set_busy(self, *_args, **_kwargs) -> None:
        return None

    def _exit_question_mode(self) -> None:
        return None

    def _refresh_layers(self) -> None:
        return None


def _is_named_key(binding, name: str) -> bool:
    if len(binding.keys) != 1:
        return False
    return str(binding.keys[0]).lower().endswith(name)


def _find_binding(host: _StubKeyBindingHost, key_name: str):
    bindings = host._build_key_bindings().bindings
    for binding in bindings:
        if _is_named_key(binding, key_name):
            return binding
    raise AssertionError(f"Cannot find key binding for '{key_name}'.")


class TestQuestionKeyBindings(unittest.TestCase):
    def _create_host_and_app(self) -> tuple[_StubKeyBindingHost, Application]:
        host = _StubKeyBindingHost()
        key_bindings = host._build_key_bindings()
        app = Application(
            layout=Layout(host._question_ui.container),
            key_bindings=key_bindings,
            full_screen=False,
        )
        host._app = app
        return host, app

    def test_left_right_disabled_when_custom_input_has_focus(self) -> None:
        host, app = self._create_host_and_app()
        left_binding = _find_binding(host, "left")
        right_binding = _find_binding(host, "right")

        host._question_ui.move_option(1)
        host._question_ui.handle_enter()
        app.layout.focus(host._question_ui.custom_input_window)

        with set_app(app):
            self.assertFalse(left_binding.filter())
            self.assertFalse(right_binding.filter())

    def test_left_right_enabled_when_options_have_focus(self) -> None:
        host, app = self._create_host_and_app()
        left_binding = _find_binding(host, "left")
        right_binding = _find_binding(host, "right")

        app.layout.focus(host._question_ui.focus_target())

        with set_app(app):
            self.assertTrue(left_binding.filter())
            self.assertTrue(right_binding.filter())


if __name__ == "__main__":
    unittest.main(verbosity=2)
