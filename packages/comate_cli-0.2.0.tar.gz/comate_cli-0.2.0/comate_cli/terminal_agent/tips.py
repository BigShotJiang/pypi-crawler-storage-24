"""Tips displayed to users at startup."""
from __future__ import annotations

TIPS: list[str] = [
    "Shift+Tab to switch between act / plan mode",
    "/compact to manually compress context and free up token space",
    "Ctrl+C to interrupt the current AI operation",
    "/rewind to undo the last conversation and return to the previous checkpoint",
    "/clear to clear the current session and start fresh",
    "/context to view current token usage and remaining context",
    "/model to switch model tier (LOW / MID / HIGH)",
    "/mcp to browse loaded MCP services and tools",
    "@filename to reference project files in your input",
    "Tab to trigger command completion, press Tab again to cycle through options",
]
