"""Tests for literalizer."""
