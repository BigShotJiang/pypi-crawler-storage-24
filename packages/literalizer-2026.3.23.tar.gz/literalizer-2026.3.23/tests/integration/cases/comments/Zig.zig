const ZVal = union(enum) {
    nil,
    bool: bool,
    int: i64,
    float: f64,
    str: []const u8,
    arr: []const ZVal,
    map: []const ZKV,
    set: []const ZVal,
};
const ZKV = struct { key: []const u8, val: ZVal };
pub fn main() void {
    const v: ZVal = .{ .map = &.{
        // Server configuration
        .{ .key = "host", .val = .{ .str = "localhost" } },  // default host
        .{ .key = "port", .val = .{ .int = 8080 } },
        // Enable debug mode
        .{ .key = "debug", .val = .{ .bool = true } },
    }};
    _ = v;
}
