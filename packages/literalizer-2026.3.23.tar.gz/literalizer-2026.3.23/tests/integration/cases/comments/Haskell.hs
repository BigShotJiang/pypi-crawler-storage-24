{-# LANGUAGE OverloadedStrings #-}
module Check where
import Data.String (IsString(fromString))
import Data.Time (Day, UTCTime(..), fromGregorian, secondsToDiffTime, picosecondsToDiffTime)
data Val = HNull | HBool Bool | HInt Integer | HFloat Double | HStr String | HList [Val] | HMap [(String, Val)] | HSet [Val] | HDate Day | HDatetime UTCTime
instance IsString Val where
    fromString = HStr
instance Num Val where
    fromInteger = HInt
    a + b = error "not implemented"
    a * b = error "not implemented"
    abs a = error "not implemented"
    signum a = error "not implemented"
    negate (HInt n) = HInt (negate n)
    negate (HFloat f) = HFloat (negate f)
    negate _ = error "not implemented"
x :: Val
x = HMap [
    -- Server configuration
    ("host", "localhost"),  -- default host
    ("port", 8080),
    -- Enable debug mode
    ("debug", HBool True)
    ]
