module fval_m
  implicit none
  type :: fval_t
    integer :: t = 0
  end type fval_t
contains
  function fnull() result(v); type(fval_t) :: v; end function
  function fbool(b) result(v); logical, intent(in) :: b; type(fval_t) :: v; end function
  function fint(n) result(v); integer, intent(in) :: n; type(fval_t) :: v; end function
  function freal(x) result(v); real, intent(in) :: x; type(fval_t) :: v; end function
  function fstr(s) result(v); character(len=*), intent(in) :: s; type(fval_t) :: v; end function
  function flist(a) result(v); type(fval_t), intent(in) :: a(:); type(fval_t) :: v; end function
  function fmap(a) result(v); type(fval_t), intent(in) :: a(:); type(fval_t) :: v; end function
  function fset(a) result(v); type(fval_t), intent(in) :: a(:); type(fval_t) :: v; end function
  function fentry(k, u) result(v); character(len=*), intent(in) :: k; type(fval_t), intent(in) :: u; type(fval_t) :: v; end function
end module fval_m
subroutine check_declaration()
  use fval_m
  implicit none
  type(fval_t) :: my_data
  my_data = fmap([fval_t :: &
      ! Server configuration
      fentry('host', fstr('localhost')), &  ! default host
      fentry('port', fint(8080)), &
      ! Enable debug mode
      fentry('debug', fbool(.true.)) &
  ])
end subroutine check_declaration

subroutine check_assignment()
  use fval_m
  implicit none
  type(fval_t) :: my_data
  my_data = fmap([fval_t :: &
      ! Server configuration
      fentry('host', fstr('localhost')), &  ! default host
      fentry('port', fint(8080)), &
      ! Enable debug mode
      fentry('debug', fbool(.true.)) &
  ])
end subroutine check_assignment

program main
  call check_declaration()
  call check_assignment()
end program main
