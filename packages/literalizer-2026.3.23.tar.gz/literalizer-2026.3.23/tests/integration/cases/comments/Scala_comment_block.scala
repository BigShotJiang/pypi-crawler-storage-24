object Check {
val x: Any = Map(
    /* Server configuration */
    "host" -> "localhost",  /* default host */
    "port" -> 8080,
    /* Enable debug mode */
    "debug" -> true,
)
}
