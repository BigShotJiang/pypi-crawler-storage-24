#include <string>
#include <vector>
#include <initializer_list>
struct _Any {
    template<class T> _Any(T&&) noexcept {}
    _Any(std::initializer_list<_Any>) noexcept {}
};
void _check() {
_Any my_data = std::vector<std::string>{
    "48656c6c6f",
};
my_data = std::vector<std::string>{
    "48656c6c6f",
};
}
