#lang racket
(define my_data (list
    "48656c6c6f"
))
(set! my_data (list
    "48656c6c6f"
))
