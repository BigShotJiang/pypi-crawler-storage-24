x = {
    true,
    false,
    true
};
