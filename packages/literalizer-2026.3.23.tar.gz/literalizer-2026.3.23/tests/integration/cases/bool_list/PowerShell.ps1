$x = @(
    $true;
    $false;
    $true
)
