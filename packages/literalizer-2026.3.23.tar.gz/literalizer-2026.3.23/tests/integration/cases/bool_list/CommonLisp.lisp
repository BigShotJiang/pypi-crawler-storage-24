(list
    t
    nil
    t
)
