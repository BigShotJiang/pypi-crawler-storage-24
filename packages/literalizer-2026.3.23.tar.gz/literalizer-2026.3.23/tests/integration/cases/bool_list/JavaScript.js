void (
[
    true,
    false,
    true,
]
)
