my $my_data = [
    1,
    0,
    1,
];
$my_data = [
    1,
    0,
    1,
];
