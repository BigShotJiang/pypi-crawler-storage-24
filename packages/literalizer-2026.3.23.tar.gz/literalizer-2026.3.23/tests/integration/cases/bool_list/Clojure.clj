[
    true
    false
    true
]
