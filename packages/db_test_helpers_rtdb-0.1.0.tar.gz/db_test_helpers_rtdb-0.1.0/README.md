# db-test-helpers-rtdb

Firebase Realtime Database adapter for [db-test-helpers](https://github.com/takaaa220/db-test-helpers).

## Installation

```bash
pip install db-test-helpers-rtdb
```

## Documentation

See the [main repository](https://github.com/takaaa220/db-test-helpers) for usage and documentation.
