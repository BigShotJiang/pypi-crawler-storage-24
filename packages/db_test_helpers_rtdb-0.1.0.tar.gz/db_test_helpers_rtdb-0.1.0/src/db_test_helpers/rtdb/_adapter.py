"""Firebase Realtime Database adapter for db-test-helpers."""

from __future__ import annotations

from typing import Any


class RtdbAdapter:
    """DatabaseAdapter for Firebase Realtime Database.

    Args:
        root_ref: A ``db.reference()`` pointing to the database root.
    """

    def __init__(self, root_ref: Any) -> None:
        self._root = root_ref

    def clear_group(self, group: str, parent_path: str) -> None:
        path = f"{parent_path}/{group}" if parent_path else group
        self._root.child(path).delete()

    def write_record(self, group: str, parent_path: str, data: dict[str, Any]) -> dict[str, Any]:
        path = f"{parent_path}/{group}" if parent_path else group
        data = dict(data)
        doc_id = data.pop("__document_id__", None)
        if doc_id is None:
            ref = self._root.child(path).push(data)
            doc_id = ref.key
        else:
            self._root.child(f"{path}/{doc_id}").set(data)
        return {"__document_id__": doc_id, **data}

    def read_records(self, group: str, parent_path: str) -> list[dict[str, Any]]:
        path = f"{parent_path}/{group}" if parent_path else group
        snapshot = self._root.child(path).get()
        if snapshot is None:
            return []
        return [{"__document_id__": key, **_strip_child_groups(val)} for key, val in snapshot.items()]

    def build_child_path(self, parent_path: str, group: str, record: dict[str, Any]) -> str:
        col_path = f"{parent_path}/{group}" if parent_path else group
        return f"{col_path}/{record['__document_id__']}"


def _strip_child_groups(data: dict[str, Any]) -> dict[str, Any]:
    """Remove keys whose values look like child groups (dict of dicts).

    In RTDB, child groups written via __children__ appear as nested dicts
    under the parent node.  A child group has the structure {id: {fields}, ...}
    where every value is a dict.  Regular nested-object fields (e.g. address)
    contain at least one non-dict value, so they are kept.
    """
    return {
        k: v
        for k, v in data.items()
        if not (isinstance(v, dict) and v and all(isinstance(vv, dict) for vv in v.values()))
    }
