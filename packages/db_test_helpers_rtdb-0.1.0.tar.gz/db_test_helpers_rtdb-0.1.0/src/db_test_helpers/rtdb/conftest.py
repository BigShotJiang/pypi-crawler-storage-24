"""Shared fixtures for RTDB adapter tests."""

from __future__ import annotations

import os

import firebase_admin
import pytest
from firebase_admin import db


@pytest.fixture
def root_ref():
    port = os.environ.get("RTDB_PORT", "9000")
    database_url = f"http://localhost:{port}/?ns=demo-project"
    if not firebase_admin._apps:
        firebase_admin.initialize_app(None, {"databaseURL": database_url})
    ref = db.reference("/", url=database_url)
    yield ref
    ref.delete()
