"""Tests for RtdbAdapter."""

from __future__ import annotations

from db_test_helpers.rtdb._adapter import RtdbAdapter


class TestWriteRecord:
    def test_write_with_doc_id(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        result = adapter.write_record("users", "", {"__document_id__": "user-1", "name": "Alice"})

        assert result["__document_id__"] == "user-1"
        assert result["name"] == "Alice"

        snapshot = root_ref.child("users/user-1").get()
        assert snapshot is not None
        assert snapshot["name"] == "Alice"
        assert "__document_id__" not in snapshot

    def test_write_without_doc_id_auto_generates(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        result = adapter.write_record("users", "", {"name": "Bob"})

        assert "__document_id__" in result
        assert result["__document_id__"] is not None
        assert len(result["__document_id__"]) > 0
        assert result["name"] == "Bob"

    def test_write_with_none_doc_id_auto_generates(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        result = adapter.write_record("users", "", {"__document_id__": None, "name": "Carol"})

        assert result["__document_id__"] is not None
        assert len(result["__document_id__"]) > 0

    def test_write_with_parent_path(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        root_ref.child("users/user-1").set({"name": "Alice"})
        result = adapter.write_record("posts", "users/user-1", {"__document_id__": "post-1", "title": "Hello"})

        snapshot = root_ref.child("users/user-1/posts/post-1").get()
        assert snapshot is not None
        assert snapshot["title"] == "Hello"
        assert result["__document_id__"] == "post-1"


class TestReadRecords:
    def test_read_empty(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        result = adapter.read_records("users", "")
        assert result == []

    def test_read_records(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        root_ref.child("users/user-1").set({"name": "Alice", "age": 30})
        root_ref.child("users/user-2").set({"name": "Bob", "age": 25})

        result = adapter.read_records("users", "")
        assert len(result) == 2

        ids = {r["__document_id__"] for r in result}
        assert ids == {"user-1", "user-2"}

        for r in result:
            assert "__document_id__" in r
            assert "name" in r

    def test_read_with_parent_path(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        root_ref.child("users/user-1").set({"name": "Alice"})
        root_ref.child("users/user-1/posts/post-1").set({"title": "Hello"})

        result = adapter.read_records("posts", "users/user-1")
        assert len(result) == 1
        assert result[0]["__document_id__"] == "post-1"
        assert result[0]["title"] == "Hello"

    def test_read_strips_child_groups(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        root_ref.child("users/user-1").set({"name": "Alice"})
        root_ref.child("users/user-1/posts/post-1").set({"title": "Hello"})

        result = adapter.read_records("users", "")
        assert len(result) == 1
        assert result[0]["name"] == "Alice"
        assert "posts" not in result[0]


class TestClearGroup:
    def test_clear_group(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        root_ref.child("users/user-1").set({"name": "Alice"})
        root_ref.child("users/user-2").set({"name": "Bob"})

        adapter.clear_group("users", "")
        snapshot = root_ref.child("users").get()
        assert snapshot is None

    def test_clear_group_with_parent_path(self, root_ref):
        adapter = RtdbAdapter(root_ref)
        root_ref.child("users/user-1/posts/post-1").set({"title": "Hello"})

        adapter.clear_group("posts", "users/user-1")
        snapshot = root_ref.child("users/user-1/posts").get()
        assert snapshot is None


class TestBuildChildPath:
    def test_root_level(self):
        adapter = RtdbAdapter(None)
        result = adapter.build_child_path("", "users", {"__document_id__": "user-1", "name": "Alice"})
        assert result == "users/user-1"

    def test_nested(self):
        adapter = RtdbAdapter(None)
        result = adapter.build_child_path("users/user-1", "posts", {"__document_id__": "post-1", "title": "Hello"})
        assert result == "users/user-1/posts/post-1"
