"""db-test-helpers-rtdb: Firebase Realtime Database adapter for db-test-helpers."""

from db_test_helpers.rtdb._adapter import RtdbAdapter

__all__ = ["RtdbAdapter"]
