from py_agent.models.parameter import Parameter
from py_agent.services.dependency_extractor.dependency_collector import (
    DEPENDENCY_EXTRACTION_DEPTH,
    DependencyCollector,
)
from py_agent.services.dependency_extractor.dependency_info import DependencyInfo
from py_agent.services.dependency_extractor.type_metadata_converter import TypeMetadataConverter


class DependencyInfoExtractor:
    @staticmethod
    def get_dependencies_info(
        parameter: Parameter, extraction_depth: int = DEPENDENCY_EXTRACTION_DEPTH
    ) -> list[DependencyInfo]:
        dependency_collector = DependencyCollector(extraction_depth=extraction_depth)
        dependency_infos: list[DependencyInfo] = []
        for t in parameter.types_raw:
            type_metadata = TypeMetadataConverter.convert(parameter, t)
            dependency_infos.extend(
                dependency_collector.collect_dependencies(type_metadata, t, parameter.id)
            )
        return dependency_infos
