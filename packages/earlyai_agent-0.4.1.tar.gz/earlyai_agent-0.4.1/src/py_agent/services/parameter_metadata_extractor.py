from libcst import Annotation

from py_agent.models.parameter import Parameter, ParameterTypeItem, RawTypeMetadata
from py_agent.models.parameter_type_kind import ParameterTypeKind
from py_agent.services.type_metadata_extractor import TypeMetadataExtractor


class ParameterMetadataExtractor:
    def __init__(
        self,
        name: str,
        annotation: Annotation | None,
        absolute_file_path: str,
        project_path: str,
    ):
        self.name = name
        self.annotation = annotation
        self.absolute_file_path = absolute_file_path
        self.project_path = project_path
        self.type_extractor = TypeMetadataExtractor(
            absolute_file_path=self.absolute_file_path,
            project_path=self.project_path,
        )

    def convert_types_metadata(self, types: list[RawTypeMetadata]) -> list[ParameterTypeItem]:
        result: list[ParameterTypeItem] = []
        for t in types:
            item = ParameterTypeItem(
                name=t.name,
                kind=t.kind,
                isDataObject=t.is_leaf_DTO,
                isCoreModule=t.is_core_module,
                import_path=t.import_from.as_posix(),
            )
            result.append(item)
        return result

    def extract(self) -> Parameter:
        raw_types = self.type_extractor.extract(self.annotation)
        types = self.convert_types_metadata(raw_types)

        return Parameter(
            name=self.name,
            types=types,
            types_raw=raw_types,
            isOptional=self.is_optional(),
            isCollection=self.is_collection(),
            isReadOnly=self.is_readonly(),
            isPrimitive=self.is_primitive(),
            kind=self.kind(),
            importPath=self.import_path(),
            resolved=self.resolved(),
            isCoreModule=self.is_core_module(),
        )

    def is_optional(self) -> bool:
        return False

    def is_collection(self) -> bool:
        return False

    def is_readonly(self) -> bool:
        return False

    def is_primitive(self) -> bool:
        return False

    def kind(self) -> ParameterTypeKind:
        return ParameterTypeKind.ANY

    def import_path(self) -> str:
        return ""

    def resolved(self) -> bool:
        return False

    def is_core_module(self) -> bool:
        return False
