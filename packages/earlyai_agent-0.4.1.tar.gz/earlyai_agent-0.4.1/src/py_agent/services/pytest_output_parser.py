"""Parse pytest stdout to extract pass/fail counts for the prune hook."""

from __future__ import annotations

import re


def parse_pytest_output(output: str) -> tuple[int, int] | None:
    """Extract (passed, failed) from pytest stdout.

    Returns ``None`` when the output cannot be parsed (e.g. a non-test command).
    """
    passed = 0
    failed = 0

    m = re.search(r"(\d+) passed", output)
    if m:
        passed = int(m.group(1))

    m = re.search(r"(\d+) failed", output)
    if m:
        failed = int(m.group(1))

    m = re.search(r"(\d+) error", output)
    if m:
        failed += int(m.group(1))

    if passed == 0 and failed == 0:
        return None

    return (passed, failed)
