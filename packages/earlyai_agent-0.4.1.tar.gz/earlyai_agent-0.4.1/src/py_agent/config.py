from typing import Literal

from pydantic import BaseModel, Field


class PyAgentConfig(BaseModel):
    api_key: str | None = None
    api_base_url: str = "https://api.startearly.ai"
    request_source: str = "CLI"
    client_source: str = "github-action"

    test_framework: Literal["pytest", "unittest"] = "pytest"
    test_structure: Literal["siblingFolder", "rootFolder"] = "siblingFolder"
    test_file_name: Literal["camelCase", "kebabCase"] = "camelCase"

    concurrency: int = Field(default=5, ge=1, le=50)
    max_iterations: int = Field(default=3, ge=1, le=10)
    dependency_extraction_depth: int = Field(default=4, ge=1, le=20)

    cleanup_strategy: Literal["keep", "remove", "comment"] = "remove"

    linter: Literal["ruff", "flake8", "none"] = "ruff"
    formatter: Literal["black", "ruff", "none"] = "ruff"
    type_checker: Literal["mypy", "pyright", "none"] = "mypy"

    workflow_run_id: str | None = None

    cache_enabled: bool = True
    log_level: str = "INFO"
