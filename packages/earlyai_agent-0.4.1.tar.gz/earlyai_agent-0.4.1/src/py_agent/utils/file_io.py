import asyncio

import aiofiles


async def read_file(file_path: str) -> str:
    async with aiofiles.open(file_path, encoding="utf-8") as f:
        content: str = await f.read()
        return content


async def read_multiple_files(
    absolute_file_paths: list[str], file_relative_paths: list[str]
) -> dict[str, dict[str, str]]:
    tasks = [
        (rel_path, abs_path, read_file(abs_path))
        for rel_path, abs_path in zip(file_relative_paths, absolute_file_paths, strict=False)
    ]
    results = await asyncio.gather(*(task for _, _, task in tasks))

    return {
        rel_path: {
            "content": result,
            "absolute_path": abs_path,
            "relative_path": rel_path,
        }
        for (rel_path, abs_path, _), result in zip(tasks, results, strict=False)
    }
