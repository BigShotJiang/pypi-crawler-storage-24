from pydantic import Field

from py_agent.models.base import CustomBaseModel
from py_agent.models.class_metadata import ClassMetadata
from py_agent.models.parameter import Parameter


class MethodMetadata(CustomBaseModel):
    name: str
    is_async: bool = Field(..., alias="isAsync")
    return_parameter: Parameter | None = Field(alias="returnParam", default=None)
    description: str | None = None
    is_static: bool = Field(..., alias="isStatic")
    parameters: list[Parameter]
    ctor_parameters: list[Parameter]
    decorators: list[Parameter]
    code: str
    access_modifier_type: str | None = Field(alias="accessModifierType", default=None)
    signature: str
    method_class: ClassMetadata | None = Field(..., exclude=True)
