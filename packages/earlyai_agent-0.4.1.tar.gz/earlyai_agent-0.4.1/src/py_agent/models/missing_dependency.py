from uuid import UUID

from pydantic import Field

from py_agent.models.base import CustomBaseModel
from py_agent.models.class_metadata import ClassMetadata
from py_agent.models.code_comments import CodeComments
from py_agent.models.method_metadata import MethodMetadata
from py_agent.models.parameter_type_kind import ParameterTypeKind


class DependencyMetadata(CustomBaseModel):
    class_metadata: ClassMetadata | None = Field(alias="classMetadata")
    methods_metadata: list[MethodMetadata] | None = Field(
        alias="methodsMetadata", default_factory=list
    )


class MissingDependency(CustomBaseModel):
    name: str
    kind: ParameterTypeKind
    import_path: str | None = Field(alias="importPath", default=None)
    code: str | None = None
    is_core_module: bool | None = Field(alias="isCoreModule", default=None)
    contained_in_tested_file: bool = Field(alias="containedInTestedFile", default=False)
    is_data_object: bool = Field(alias="isDataObject", default=False)
    code_comments: CodeComments | None = Field(alias="codeComments", default=None)
    parent_parameter_ids: list[UUID] = Field(alias="parentParameterIds", default=[])
    dependency_metadata: DependencyMetadata | None = Field(alias="dependencyMetadata", default=None)
