from uuid import UUID

from pydantic import Field

from py_agent.models.base import CustomBaseModel
from py_agent.models.parameter_type_kind import ParameterTypeKind


class ParentParameterRelations(CustomBaseModel):
    parameter_parent_id: UUID = Field(alias="parameterParentId")
    depth_level_in_parent: int = Field(alias="depthLevelInParent")


class CodeDependency(CustomBaseModel):
    name: str
    kind: ParameterTypeKind
    code: str
    module_name: str | None = Field(alias="moduleName", default=None)
    import_path: str | None = Field(alias="importPath", default=None)
    contained_in_tested_file: bool = Field(alias="containedInTestedFile", default=False)
    is_data_object: bool = Field(alias="isDataObject", default=False)
    parent_parameter_ids: list[UUID] = Field(alias="parentParameterIds", default=[])
    parent_parameter_relations: list[ParentParameterRelations] = Field(
        alias="parentParameterRelations", default=[]
    )
