from pydantic import Field

from py_agent.models.base import CustomBaseModel
from py_agent.models.parameter import Parameter


class ConstructorMetadata(CustomBaseModel):
    code: str
    parameters: list[Parameter]


class ClassMetadata(CustomBaseModel):
    name: str
    code: str
    constructor_metadata: ConstructorMetadata | None = Field(
        alias="constructorMetadata", default=None
    )
    properties: list[Parameter] = []
    is_abstract: bool = Field(..., alias="isAbstract")
