from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from py_agent.models.base import FrozenModel
from py_agent.models.enum_metadata import EnumMetadata
from py_agent.services.import_jedi_extractor import JediMetadata


class ExternalMethodInfo(FrozenModel):
    name: str
    jedi_metadata: JediMetadata

    model_config = FrozenModel.model_config


@dataclass
class FocusedCodeDTO:
    is_extracted: bool
    file_path: str
    function_name: str
    class_name: str | None
    focused_code: str | None
    called_methods: list[str] | None
    all_methods_list: list[str] | None
    all_external_methods_list: dict[str, Any] | None
    enums: list[EnumMetadata]
