from pathlib import Path
from uuid import UUID, uuid4

from pydantic import Field

from py_agent.models.base import CustomBaseModel, FrozenModel
from py_agent.models.parameter_type_kind import ParameterTypeKind


class RawParentTypeMetadata(FrozenModel):
    name: str
    import_from: Path
    project_path: Path
    is_core_module: bool


class RawTypeMetadata(FrozenModel):
    name: str
    kind: ParameterTypeKind
    import_from: Path
    project_path: Path
    module_name: str
    is_leaf_DTO: bool
    is_core_module: bool
    code: str
    parents: frozenset[RawParentTypeMetadata]
    attributes: frozenset[RawParentTypeMetadata]


class KnownTypeMetadata(CustomBaseModel):
    name: str
    kind: ParameterTypeKind
    import_from: Path
    module_name: str
    is_DTO: bool
    is_core_module: bool
    is_known: bool
    code: str
    level: int


class ParameterTypeItem(CustomBaseModel):
    name: str
    kind: ParameterTypeKind
    is_data_object: bool = Field(..., alias="isDataObject")
    is_core_module: bool = Field(..., alias="isCoreModule")
    import_path: str = Field(..., exclude=True)


class Parameter(CustomBaseModel):
    name: str
    types: list[ParameterTypeItem]
    types_raw: list[RawTypeMetadata] = Field(default_factory=list, exclude=True)
    is_optional: bool = Field(..., alias="isOptional")
    is_collection: bool = Field(..., alias="isCollection")
    is_readonly: bool = Field(..., alias="isReadOnly")
    is_primitive: bool = Field(..., alias="isPrimitive")
    kind: ParameterTypeKind
    import_path: str = Field(..., alias="importPath")
    resolved: bool
    is_core_module: bool = Field(..., alias="isCoreModule")
    id: UUID = Field(default_factory=uuid4)
