import pytest

from py_agent import PyAgent, PyAgentConfig


@pytest.mark.asyncio
async def test_py_agent_init():
    agent = PyAgent()
    assert agent._initialized is False

    await agent.init(api_key="test-key")

    assert agent._initialized is True
    assert agent._config.api_key == "test-key"


def test_config_defaults():
    config = PyAgentConfig()

    assert config.test_framework == "pytest"
    assert config.concurrency == 5
    assert config.test_structure == "siblingFolder"
