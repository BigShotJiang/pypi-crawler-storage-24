# SPDX-License-Identifier: AGPL-3.0-or-later | Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SC-NeuroCore — Tests for Rust-accelerated Kuramoto solver

"""Tests for Rust-accelerated Kuramoto solver."""

import numpy as np

import pytest

pytest.importorskip("sc_neurocore_engine", reason="Rust engine not built", exc_type=ImportError)

from sc_neurocore_engine import KuramotoSolver


class TestKuramotoSolver:
    def test_synchronization(self):
        n = 100
        omega = np.ones(n)
        coupling = np.full((n, n), 1.0)
        phases = np.random.RandomState(42).uniform(0, 2 * np.pi, n)

        solver = KuramotoSolver(omega, coupling, phases, noise_amp=0.0)
        order_values = solver.run(n_steps=2000, dt=0.01)

        assert order_values[-1] > 0.8, (
            f"Strong coupling should synchronize: R={order_values[-1]:.4f}"
        )

    def test_order_parameter_range(self):
        solver = KuramotoSolver(
            np.ones(50),
            np.zeros((50, 50)),
            np.random.RandomState(42).uniform(0, 2 * np.pi, 50),
        )
        order_value = solver.order_parameter()
        assert 0.0 <= order_value <= 1.0

    def test_phase_roundtrip(self):
        phases = np.array([0.1, 0.2, 0.3, 0.4])
        solver = KuramotoSolver(np.ones(4), np.zeros((4, 4)), phases)
        np.testing.assert_allclose(solver.phases, phases, atol=1e-12)
