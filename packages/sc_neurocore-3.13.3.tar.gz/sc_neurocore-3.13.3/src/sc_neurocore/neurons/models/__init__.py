# SPDX-License-Identifier: AGPL-3.0-or-later | Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SC-NeuroCore — Individual neuron model files — one class per file

"""Individual neuron model files — one class per file.

All 122 models are lazy-loaded on first access to keep import fast.
``from sc_neurocore.neurons.models import HodgkinHuxleyNeuron`` loads
only that one file, not all 109.
"""

_CLASS_TO_MODULE = {
    "AdExNeuron": "adex",
    "AdaptiveThresholdIFNeuron": "adaptive_threshold_if",
    "AkidaNeuron": "akida_neuron",
    "AlphaNeuron": "alpha",
    "AmariNeuralField": "amari_field",
    "ArcaneNeuron": "arcane_neuron",
    "AstrocyteModel": "astrocyte",
    "AstrocyteNeuron": "astrocyte_adapter",
    "AttentionGatedNeuron": "ai_optimized",
    "AvRonCardiacNeuron": "av_ron_cardiac",
    "BendaHerzNeuron": "benda_herz",
    "BertramPhantomBurster": "bertram_phantom",
    "BoothRinzelNeuron": "booth_rinzel",
    "BrainScaleSAdExNeuron": "brainscales_adex",
    "ButeraRespiratoryNeuron": "butera_respiratory",
    "COBALIFNeuron": "coba_lif",
    "CazellesMapNeuron": "cazelles_map",
    "ChayKeizerNeuron": "chay_keizer",
    "ChayNeuron": "chay",
    "ChialvoMapNeuron": "chialvo_map",
    "ClosedFormContinuousNeuron": "cfc",
    "ComplementaryLIFNeuron": "clif",
    "CompositionalBindingNeuron": "ai_optimized",
    "CompteWMNeuron": "compte_wm",
    "ConnorStevensNeuron": "connor_stevens",
    "ContinuousAttractorNeuron": "ai_optimized",
    "CourageNekorkinMapNeuron": "courage_nekorkin_map",
    "DPINeuron": "dpi_neuron",
    "DeSchutterPurkinjeNeuron": "de_schutter_purkinje",
    "DendrifyNeuron": "dendrify",
    "DestexheThalamicNeuron": "destexhe_thalamic",
    "DifferentiableSurrogateNeuron": "ai_optimized",
    "DurstewitzDopamineNeuron": "durstewitz_dopamine",
    "EPropALIFNeuron": "e_prop_alif",
    "EnergyLIFNeuron": "energy_lif",
    "ErmentroutKopellPopulation": "ermentrout_kopell_pop",
    "EscapeRateNeuron": "escape_rate",
    "ExpIFNeuron": "expif",
    "FitzHughNagumoNeuron": "fitzhugh_nagumo",
    "FitzHughRinzelNeuron": "fitzhugh_rinzel",
    "FractionalLIFNeuron": "fractional_lif",
    "GIFPopulationNeuron": "gif_population",
    "GLIFNeuron": "glif",
    "GLMNeuron": "glm_neuron",
    "GalvesLocherbachNeuron": "galves_locherbach",
    "GammaRenewalNeuron": "gamma_renewal",
    "GatedLIFNeuron": "gated_lif",
    "GolombFSNeuron": "golomb_fs",
    "GutkinErmentroutNeuron": "gutkin_ermentrout",
    "HayL5PyramidalNeuron": "hay_l5",
    "HillTononiNeuron": "hill_tononi",
    "HindmarshRoseNeuron": "hindmarsh_rose",
    "HodgkinHuxleyNeuron": "hodgkin_huxley",
    "HuberBraunNeuron": "huber_braun",
    "IbarzTanakaMapNeuron": "ibarz_tanaka_map",
    "InhibitoryLIFNeuron": "ilif",
    "InhomogeneousPoissonNeuron": "inhomogeneous_poisson",
    "IntegerQIFNeuron": "iqif",
    "JansenRitUnit": "jansen_rit",
    "KLIFNeuron": "klif",
    "LapicqueNeuron": "lapicque",
    "LarterBreakspearNeuron": "larter_breakspear",
    "LeakyCompeteFireNeuron": "leaky_compete_fire",
    "LearnableNeuronModel": "lnm",
    "LiquidTimeConstantNeuron": "ltc",
    "Loihi2Neuron": "loihi2",
    "LoihiCUBANeuron": "loihi_cuba",
    "MATNeuron": "mat",
    "MainenSejnowskiNeuron": "mainen_sejnowski",
    "MarderSTGNeuron": "marder_stg",
    "McCullochPittsNeuron": "mcculloch_pitts",
    "McKeanNeuron": "mckean",
    "MedvedevMapNeuron": "medvedev_map",
    "MetaPlasticNeuron": "ai_optimized",
    "MihalasNieburNeuron": "mihalas_niebur",
    "MorrisLecarNeuron": "morris_lecar",
    "MultiTimescaleNeuron": "ai_optimized",
    "NeuroGridNeuron": "neurogrid",
    "NonResettingLIFNeuron": "non_resetting_lif",
    "NonlinearLIFNeuron": "nlif",
    "ParallelSpikingNeuron": "psn",
    "ParametricLIFNeuron": "plif",
    "PerfectIntegratorNeuron": "perfect_integrator",
    "PernarowskiNeuron": "pernarowski",
    "PinskyRinzelNeuron": "pinsky_rinzel",
    "PlantR15Neuron": "plant_r15",
    "PoissonNeuron": "poisson",
    "PospischilNeuron": "pospischil",
    "PredictiveCodingNeuron": "ai_optimized",
    "PrescottNeuron": "prescott",
    "QuadraticIFNeuron": "quadratic_if",
    "RallCableNeuron": "rall_cable",
    "ResonateAndFireNeuron": "resonate_and_fire",
    "RulkovMapNeuron": "rulkov_map",
    "SFANeuron": "sfa",
    "SelfReferentialNeuron": "ai_optimized",
    "ShermanRinzelKeizerNeuron": "sherman_rinzel_keizer",
    "SiegertTransferFunction": "siegert",
    "SigmaDeltaNeuron": "sigma_delta",
    "SigmoidRateNeuron": "sigmoid_rate",
    "SpiNNaker2Neuron": "spinnaker2",
    "SpiNNakerLIFNeuron": "spinnaker_lif",
    "SpikeResponseNeuron": "spike_response",
    "StochasticIFNeuron": "stochastic_if",
    "SuperSpikeNeuron": "superspike_neuron",
    "TermanWangOscillator": "terman_wang",
    "ThetaNeuron": "theta",
    "ThresholdLinearRateNeuron": "threshold_linear_rate",
    "TraubMilesNeuron": "traub_miles",
    "TrueNorthNeuron": "truenorth",
    "TsodyksMarkramNeuron": "tsodyks_markram",
    "TwoCompartmentLIFNeuron": "tc_lif",
    "WangBuzsakiNeuron": "wang_buzsaki",
    "WendlingNeuron": "wendling",
    "WilsonCowanUnit": "wilson_cowan",
    "WilsonHRNeuron": "wilson_hr",
    "WongWangUnit": "wong_wang",
    "YamadaNeuron": "yamada",
}

__all__ = sorted(_CLASS_TO_MODULE.keys())


def __getattr__(name: str):
    if name in _CLASS_TO_MODULE:
        import importlib

        module = importlib.import_module(f".{_CLASS_TO_MODULE[name]}", __name__)
        obj = getattr(module, name)
        globals()[name] = obj
        return obj
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
