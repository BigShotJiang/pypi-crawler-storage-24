# SPDX-License-Identifier: AGPL-3.0-or-later | Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SC-NeuroCore — Compiler Package Init

from .equation_compiler import compile_to_verilog, equation_to_fpga, Q88
from .pipeline import CompilerPipeline
from .mlir_emitter import MLIREmitter
from .quantizer import (
    QFormat,
    quantize_weights,
    dequantize_weights,
    q_weights_to_sc_probabilities,
    quantization_error,
)
from .ir_type_checker import (
    check_ir_types,
    IRNode,
    IREdge,
    IRTypeError,
    SignalType,
)

__all__ = [
    "compile_to_verilog",
    "equation_to_fpga",
    "Q88",
    "CompilerPipeline",
    "MLIREmitter",
    "QFormat",
    "quantize_weights",
    "dequantize_weights",
    "q_weights_to_sc_probabilities",
    "quantization_error",
    "check_ir_types",
    "IRNode",
    "IREdge",
    "IRTypeError",
    "SignalType",
]
