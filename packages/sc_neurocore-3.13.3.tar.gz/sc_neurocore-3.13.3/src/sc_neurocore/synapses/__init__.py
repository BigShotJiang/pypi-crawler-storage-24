# SPDX-License-Identifier: AGPL-3.0-or-later | Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SC-NeuroCore — Synapses Package Init

from .sc_synapse import BitstreamSynapse
from .dot_product import BitstreamDotProduct
from .stochastic_stdp import StochasticSTDPSynapse
from .r_stdp import RewardModulatedSTDPSynapse
from .triplet_stdp import TripletSTDP
from .bcm import BCMSynapse
from .clopath_stdp import ClopathSTDP
from .tripartite import TripartiteSynapse

__all__ = [
    "BitstreamSynapse",
    "BitstreamDotProduct",
    "StochasticSTDPSynapse",
    "RewardModulatedSTDPSynapse",
    "TripletSTDP",
    "BCMSynapse",
    "ClopathSTDP",
    "TripartiteSynapse",
]
