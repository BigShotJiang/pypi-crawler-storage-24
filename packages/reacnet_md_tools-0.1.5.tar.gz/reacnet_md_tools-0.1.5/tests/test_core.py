from pathlib import Path

from reacnet_md_tools.infer_atomnames import parse_masses, match_element
from reacnet_md_tools.rng_tools.formula import check_mass_balance, formula_nominal_mass, parse_formula
from reacnet_md_tools.rng_tools.network import ReactionNetwork, parse_reactionabcd, smiles_to_formula_fast
from reacnet_md_tools.xs2x import main as xs2x_main


def test_parse_formula_and_mass_balance():
    assert parse_formula("C2H6O") == {"C": 2, "H": 6, "O": 1}
    ok, msg = check_mass_balance("C2H6+O2", "C2H6O2")
    assert ok is True
    assert msg == "OK"
    assert formula_nominal_mass("H2O") == 18


def test_infer_atomnames_helpers():
    text = """
LAMMPS data file

4 atom types

Masses

1 12.0107
2 1.00794
3 15.9994
4 35.453

Atoms
"""
    masses = parse_masses(text)
    assert masses == {1: 12.0107, 2: 1.00794, 3: 15.9994, 4: 35.453}
    assert [match_element(masses[i]) for i in sorted(masses)] == ["C", "H", "O", "Cl"]


def test_network_from_reactionabcd(tmp_path: Path):
    reac = tmp_path / "sample.reactionabcd"
    reac.write_text(
        "\n".join(
            [
                "10 [CH3][CH3]+[O][O]->[CH3][CH2][O][O]",
                "3 [CH3][CH2][O][O]->[CH3][CH3]+[O][O]",
                "5 [CH3][CH2][O][O]->[CH3][CH2][O]+[O]",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    reactions = parse_reactionabcd(str(reac))
    assert len(reactions) == 3
    net = ReactionNetwork(reactions)

    assert "C2" in {sp.formula for sp in net.species.values()}
    assert smiles_to_formula_fast("[CH3][CH3]") == "C2"
    ethane = "[CH3][CH3]"
    assert net.total_consume_tp(ethane) == 10
    assert net.total_produce_tp(ethane) == 3


def test_xs2x_cli_conversion(tmp_path: Path, capsys):
    src = tmp_path / "in.lammpstrj"
    dst = tmp_path / "out.lammpstrj"
    src.write_text(
        """ITEM: TIMESTEP
0
ITEM: NUMBER OF ATOMS
2
ITEM: BOX BOUNDS pp pp pp
0 10
0 20
0 30
ITEM: ATOMS id type xs ys zs
1 1 0.5 0.25 0.1
2 2 0.0 1.0 0.5
""",
        encoding="utf-8",
    )

    xs2x_main(["-i", str(src), "-o", str(dst), "--precision", "3"])
    out = dst.read_text(encoding="utf-8")
    assert "ITEM: ATOMS id type x y z" in out
    assert "1 1 5.000 5.000 3.000" in out
    assert "2 2 0.000 20.000 15.000" in out
    assert "Converted 1 frame(s)" in capsys.readouterr().out
