from reacnet_md_tools import query_cli
from reacnet_md_tools.webapp import server


def test_query_cli_default_reaction_file_uses_package_root_fallback():
    p = query_cli.detect_default_reaction_file()
    assert p.name.endswith('.reactionabcd')


def test_webapp_default_reaction_file_uses_package_root_fallback():
    p = server.detect_default_reaction_file()
    assert p.name.endswith('.reactionabcd')
