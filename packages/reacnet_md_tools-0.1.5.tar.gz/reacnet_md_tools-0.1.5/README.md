# reacnet-md-tools

Small, dependency-light helpers around reactive MD post-processing workflows, built to make **ReacNetGenerator** runs more repeatable.

Design goals:
- minimal dependencies for the core pipeline
- safe subprocess execution (no `shell=True`)
- clear, agent-friendly CLIs
- packaged analysis helpers that can be called directly from Agent Skills

## Package layout

Reusable code now lives inside the installable package:

- `src/reacnet_md_tools/`
  - core CLIs: `pipeline.py`, `xs2x.py`, `infer_atomnames.py`
  - analysis/query CLI: `query_cli.py`
  - reusable analysis modules: `rng_tools/`
  - lightweight browser backend: `webapp/`

For automation and skills, prefer the packaged entry points below.

## Install / run

### Run without installing (recommended)

```bash
uvx --from reacnet-md-tools rng-pipeline --help
uvx --from reacnet-md-tools rng-query --help
```

### Install into an environment

```bash
python -m pip install -U reacnet-md-tools
```

Optional analysis extras for richer query/web workflows:

```bash
python -m pip install -U 'reacnet-md-tools[analysis]'
```

## Commands

### `rng-xs2x`

Convert a LAMMPS dump with scaled coordinates `xs/ys/zs` into absolute coordinates `x/y/z`.

```bash
rng-xs2x -i in.lammpstrj -o out.lammpstrj
```

Current packaged converter supports orthorhombic boxes in the standalone CLI.

### `rng-infer-atomnames`

Infer `reacnetgenerator -a` atomname order from a LAMMPS data file by parsing the `Masses` section and matching masses to common elements.

```bash
rng-infer-atomnames path/to/system.data
# -> e.g. "C H O Cl"
```

### `rng-pipeline`

End-to-end helper:
1. If the input is a LAMMPS dump and uses `xs/ys/zs`, convert it to `x/y/z` into `out/<basename>/dump_with_xyz.lammpstrj`.
2. If `--atomnames` is not provided, try to infer them from a nearby LAMMPS data file (or ask you to pick one with `--pick-data`).
3. Run ReacNetGenerator, writing everything into `out/<basename>/`.

Example:

```bash
rng-pipeline \
  --input /path/to/traj.lammpstrj \
  --type dump \
  --outroot out \
  --pick-data \
  --stepinterval 10 \
  --maxspecies 50
```

**ReacNetGenerator runner selection**
- default `--runner auto`:
  - use local `reacnetgenerator` if found on PATH
  - otherwise run via: `uvx --from reacnetgenerator reacnetgenerator ...`

### `rng-query`

Unified CLI for post-analysis on `.reactionabcd` / `.species` outputs.

Typical uses:

```bash
rng-query species --reac path/to/run.reactionabcd --formula C6H6
rng-query next --reac path/to/run.reactionabcd --smiles '[H][H]'
rng-query rxn-formula --reac path/to/run.reactionabcd --reactants C6H6 --products C6H5+H
```

### `rng-webapp`

Launch the lightweight local browser backend for interactive exploration of reaction datasets.

```bash
rng-webapp --reac path/to/run.reactionabcd --host 127.0.0.1 --port 8000
```

## For Agent Skills / automation

Prefer these stable commands:

- `rng-pipeline` for generating outputs from trajectories
- `rng-query` for species / reaction / pathway / CSV summary queries
- `rng-webapp` only when the user explicitly wants an interactive local browser UI

Preferred import surface for Python code:

```python
from reacnet_md_tools.rng_tools.network import ReactionNetwork, parse_reactionabcd
from reacnet_md_tools.rng_tools.reaction import parse_species_file
```

## Development

Build (wheel + sdist):

```bash
python -m pip install -U build
python -m build
```

Run tests:

```bash
python -m pip install -U '.[dev]'
pytest
```

## Publishing

This package is intended to be published from GitHub Actions via **PyPI Trusted Publishing**.

Typical release flow:

1. Push commits to GitHub
2. Create a version tag such as `v0.1.5`
3. Let the GitHub Actions publish workflow build and upload to PyPI
4. Install/run with `uvx --from reacnet-md-tools ...`

## License

MIT (see `LICENSE`).
