"""Web helpers for browsing ReacNetGenerator reaction datasets."""
