"""Welcome page HTML template — Bluefox Stack design system."""

WELCOME_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{app_name}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,300&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    :root {{
      --bg: #FAFAF8;
      --bg-warm: #F5F4F0;
      --text: #1A1A18;
      --text-secondary: #6B6B64;
      --accent: #3178C6;
      --accent-light: #DBEAFE;
      --border: #E4E3DF;
      --code-bg: #1A1A18;
      --code-text: #E8E6E1;
      --code-keyword: #3178C6;
      --code-string: #8FA67A;
      --code-comment: #6B6B64;
      --code-func: #C9A86C;
      --op: #8B8B84;
      --green: #4A7A5B;
      --green-bg: #E8F0EB;
      --red: #B44040;
      --red-bg: #F5E8E8;
      --gray: #8B8B84;
      --gray-bg: #F0EFEC;
    }}

    * {{ margin: 0; padding: 0; box-sizing: border-box; }}

    body {{
      font-family: "DM Sans", sans-serif;
      font-size: 17px;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      -webkit-font-smoothing: antialiased;
    }}

    /* --- Layout --- */
    .container {{
      max-width: 720px;
      margin: 0 auto;
      padding: 0 2rem;
    }}

    /* --- Fade-in --- */
    .fade-in {{
      opacity: 0;
      transform: translateY(8px);
      animation: fadeUp 0.6s ease forwards;
    }}
    .fade-in:nth-child(1) {{ animation-delay: 0.05s; }}
    .fade-in:nth-child(2) {{ animation-delay: 0.12s; }}
    .fade-in:nth-child(3) {{ animation-delay: 0.19s; }}
    .fade-in:nth-child(4) {{ animation-delay: 0.26s; }}
    @keyframes fadeUp {{
      to {{ opacity: 1; transform: translateY(0); }}
    }}

    /* --- Hero --- */
    .hero {{
      padding: 8rem 0 4rem;
      text-align: center;
    }}
    .hero-icon {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      background: var(--accent-light);
      border-radius: 12px;
      margin-bottom: 1.5rem;
    }}
    .hero-icon svg {{
      width: 26px;
      height: 26px;
    }}
    .hero h1 {{
      font-size: 2.8rem;
      font-weight: 600;
      letter-spacing: -0.035em;
      line-height: 1.1;
      margin-bottom: 0.75rem;
    }}
    .hero h1 em {{
      font-weight: 300;
      font-style: italic;
      color: var(--text-secondary);
    }}
    .hero .subtitle {{
      font-size: 1.1rem;
      color: var(--text-secondary);
      line-height: 1.7;
      margin-bottom: 2rem;
    }}

    /* --- Status badges --- */
    .status {{
      display: flex;
      gap: 0.6rem;
      justify-content: center;
      flex-wrap: wrap;
      margin-bottom: 1.5rem;
    }}
    .badge {{
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      padding: 0.3rem 0.75rem;
      border-radius: 4px;
      font-family: "JetBrains Mono", monospace;
      font-size: 0.72rem;
      font-weight: 500;
      letter-spacing: 0.02em;
    }}
    .badge .dot {{
      width: 7px;
      height: 7px;
      border-radius: 50%;
    }}
    .badge-green {{
      background: var(--green-bg);
      color: var(--green);
    }}
    .badge-green .dot {{ background: var(--green); }}
    .badge-red {{
      background: var(--red-bg);
      color: var(--red);
    }}
    .badge-red .dot {{ background: var(--red); }}
    .badge-gray {{
      background: var(--gray-bg);
      color: var(--gray);
    }}
    .badge-gray .dot {{ background: var(--gray); }}

    /* --- Nav links --- */
    .nav-links {{
      display: flex;
      gap: 1.5rem;
      justify-content: center;
    }}
    .nav-links a {{
      font-size: 0.85rem;
      color: var(--text-secondary);
      text-decoration: none;
      transition: color 0.15s;
    }}
    .nav-links a:hover {{
      color: var(--text);
    }}

    /* --- Section --- */
    section {{
      border-top: 1px solid var(--border);
      padding: 3rem 0;
    }}
    .label {{
      font-family: "JetBrains Mono", monospace;
      font-size: 0.72rem;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--text-secondary);
      margin-bottom: 1.25rem;
    }}

    /* --- Code blocks --- */
    .code-block {{
      background: var(--code-bg);
      border-radius: 10px;
      overflow: hidden;
      margin-bottom: 1rem;
    }}
    .code-header {{
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.25rem;
      border-bottom: 1px solid rgba(255,255,255,0.06);
    }}
    .code-dot {{
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: rgba(255,255,255,0.12);
    }}
    .code-filename {{
      font-family: "JetBrains Mono", monospace;
      font-size: 0.72rem;
      color: rgba(255,255,255,0.35);
      margin-left: 0.4rem;
    }}
    .code-block pre {{
      padding: 1.25rem 1.5rem;
      font-family: "JetBrains Mono", monospace;
      font-size: 0.82rem;
      line-height: 1.75;
      color: var(--code-text);
      overflow-x: auto;
      margin: 0;
      background: transparent;
      border: none;
      border-radius: 0;
    }}
    .kw {{ color: var(--code-keyword); }}
    .fn {{ color: var(--code-func); }}
    .st {{ color: var(--code-string); }}
    .cm {{ color: var(--code-comment); }}
    .op {{ color: var(--op); }}

    /* Inline code */
    code.ic {{
      background: var(--bg-warm);
      padding: 0.1em 0.35em;
      border-radius: 4px;
      font-family: "JetBrains Mono", monospace;
      font-size: 0.85em;
    }}

    /* --- Playground --- */
    .playground-form {{
      display: flex;
      gap: 0.5rem;
      margin-bottom: 1rem;
    }}
    .playground-form input {{
      flex: 1;
      padding: 0.55rem 0.85rem;
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 6px;
      color: var(--text);
      font-size: 0.88rem;
      font-family: "DM Sans", sans-serif;
      transition: border-color 0.15s;
    }}
    .playground-form input:focus {{
      outline: none;
      border-color: var(--accent);
    }}
    .playground-form input::placeholder {{
      color: var(--text-secondary);
      opacity: 0.6;
    }}
    .btn {{
      padding: 0.55rem 1.1rem;
      background: var(--accent);
      color: #fff;
      border: none;
      border-radius: 6px;
      font-family: "DM Sans", sans-serif;
      font-size: 0.85rem;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      transition: opacity 0.15s;
    }}
    .btn:hover {{ opacity: 0.85; }}
    .btn-sm {{
      padding: 0.2rem 0.45rem;
      background: transparent;
      border: 1px solid var(--border);
      color: var(--text-secondary);
      border-radius: 4px;
      font-size: 0.72rem;
      cursor: pointer;
      transition: all 0.15s;
    }}
    .btn-sm:hover {{
      border-color: var(--red);
      color: var(--red);
    }}
    .messages-list {{
      list-style: none;
    }}
    .messages-list li {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.55rem 0;
      border-bottom: 1px solid var(--border);
      font-size: 0.88rem;
    }}
    .messages-list li:last-child {{ border-bottom: none; }}
    .msg-text {{
      flex: 1;
      color: var(--text);
    }}
    .msg-time {{
      font-family: "JetBrains Mono", monospace;
      color: var(--text-secondary);
      font-size: 0.7rem;
      margin: 0 0.75rem;
    }}
    .empty-state {{
      color: var(--text-secondary);
      font-size: 0.85rem;
      font-style: italic;
      padding: 0.5rem 0;
    }}
    .hint {{
      font-size: 0.82rem;
      color: var(--text-secondary);
      line-height: 1.6;
      margin-top: 0.75rem;
    }}

    /* --- Steps --- */
    .steps {{ counter-reset: step; }}
    .step {{
      position: relative;
      padding-left: 2.2rem;
      margin-bottom: 1.75rem;
    }}
    .step::before {{
      counter-increment: step;
      content: counter(step);
      position: absolute;
      left: 0;
      top: 0;
      width: 1.4rem;
      height: 1.4rem;
      background: var(--accent);
      color: #fff;
      border-radius: 50%;
      font-size: 0.72rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    .step p {{
      margin-bottom: 0.6rem;
      font-size: 0.9rem;
      line-height: 1.6;
    }}

    /* --- Footer --- */
    footer {{
      border-top: 1px solid var(--border);
      padding: 2.5rem 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.8rem;
      color: var(--text-secondary);
    }}
    footer a {{
      color: var(--text-secondary);
      text-decoration: none;
      transition: color 0.15s;
    }}
    footer a:hover {{ color: var(--text); }}
    footer .footer-links {{
      display: flex;
      gap: 1.25rem;
    }}

    /* --- Responsive --- */
    @media (max-width: 640px) {{
      body {{ font-size: 16px; }}
      .container {{ padding: 0 1.5rem; }}
      .hero {{ padding: 5rem 0 3rem; }}
      .hero h1 {{ font-size: 2rem; }}
      footer {{ flex-direction: column; gap: 0.75rem; text-align: center; }}
    }}
  </style>
</head>
<body>
  <div class="container">

    <!-- Hero -->
    <div class="hero fade-in">
      <div class="hero-icon">
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 15 L85 40 L85 75 L50 95 L15 75 L15 40 Z" stroke="var(--accent)" stroke-width="5" fill="none"/>
          <path d="M50 15 L50 95" stroke="var(--accent)" stroke-width="3" opacity="0.4"/>
          <path d="M15 40 L85 40" stroke="var(--accent)" stroke-width="3" opacity="0.4"/>
          <path d="M15 75 L85 75" stroke="var(--accent)" stroke-width="3" opacity="0.2"/>
        </svg>
      </div>
      <h1>{app_name} <em>is running</em></h1>
      <p class="subtitle">Your Bluefox app is ready for development</p>
      <div class="status">
        <span class="badge badge-green"><span class="dot"></span> App</span>
        <span class="badge badge-{db_status_color}"><span class="dot"></span> Database{db_status_detail}</span>
        <span class="badge badge-{redis_status_color}"><span class="dot"></span> Redis{redis_status_detail}</span>
      </div>
      <div class="nav-links">
        <a href="/health">Health</a>
        <a href="/docs">API Docs</a>
        <a href="/redoc">ReDoc</a>
      </div>
    </div>

    <!-- Playground -->
    <section class="fade-in">
      <p class="label">Playground</p>
      <p style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 1.25rem; line-height: 1.6;">
        An in-memory message board to verify your API layer works end-to-end.
        Messages reset when the server restarts.
      </p>
      <form class="playground-form" onsubmit="addMessage(event)">
        <input type="text" id="msg-input" placeholder="Type a message..." autocomplete="off" />
        <button type="submit" class="btn">Send</button>
      </form>
      <ul class="messages-list" id="messages-list">
        <li class="empty-state">No messages yet &mdash; try sending one!</li>
      </ul>
    </section>

    <!-- Getting started -->
    <section class="fade-in">
      <p class="label">Getting started</p>
      <div class="steps">
        <div class="step">
          <p>Create a module with an <code class="ic">api.py</code> file:</p>
          <div class="code-block">
            <div class="code-header">
              <span class="code-dot"></span><span class="code-dot"></span><span class="code-dot"></span>
              <span class="code-filename">items/api.py</span>
            </div>
<pre><span class="kw">from</span> fastapi <span class="kw">import</span> APIRouter

router <span class="op">=</span> <span class="fn">APIRouter</span>()

<span class="kw">@</span>router.<span class="fn">get</span>(<span class="st">"/"</span>)
<span class="kw">async def</span> <span class="fn">list_items</span>():
    <span class="kw">return</span> {{"items": []}}</pre>
          </div>
          <p class="hint">
            Routes are auto-discovered &mdash; any <code class="ic">*/api.py</code>
            with a <code class="ic">router</code> is mounted at
            <code class="ic">/module_name</code> automatically.
          </p>
        </div>
        <div class="step">
          <p>Remove this welcome page when you&rsquo;re ready:</p>
          <div class="code-block">
            <div class="code-header">
              <span class="code-dot"></span><span class="code-dot"></span><span class="code-dot"></span>
              <span class="code-filename">main.py</span>
            </div>
<pre><span class="cm"># Just remove welcome=True</span>
app <span class="op">=</span> <span class="fn">create_bluefox_app</span>(settings)</pre>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="fade-in">
      <span>{app_name} &middot; part of the <a href="https://bluefox.software">Bluefox Stack</a></span>
      <div class="footer-links">
        <a href="https://bluefox-core.bluefox.software">Docs</a>
        <a href="https://github.com/blue-fox-software/bluefox-core">GitHub</a>
        <a href="https://bluefox.software">bluefox.software</a>
      </div>
    </footer>

  </div>

  <script>
    const API = "/welcome/messages";

    async function loadMessages() {{
      const res = await fetch(API);
      const messages = await res.json();
      const list = document.getElementById("messages-list");
      if (messages.length === 0) {{
        list.innerHTML = '<li class="empty-state">No messages yet \u2014 try sending one!</li>';
        return;
      }}
      list.innerHTML = messages.map(m => {{
        const time = new Date(m.created_at * 1000).toLocaleTimeString();
        return `<li>
          <span class="msg-text">${{m.text}}</span>
          <span class="msg-time">${{time}}</span>
          <button class="btn-sm" onclick="deleteMessage(${{m.id}})">&times;</button>
        </li>`;
      }}).join("");
    }}

    async function addMessage(e) {{
      e.preventDefault();
      const input = document.getElementById("msg-input");
      const text = input.value.trim();
      if (!text) return;
      await fetch(API, {{
        method: "POST",
        headers: {{"Content-Type": "application/json"}},
        body: JSON.stringify({{text}})
      }});
      input.value = "";
      loadMessages();
    }}

    async function deleteMessage(id) {{
      await fetch(`${{API}}/${{id}}`, {{method: "DELETE"}});
      loadMessages();
    }}

    loadMessages();
  </script>
</body>
</html>
"""
