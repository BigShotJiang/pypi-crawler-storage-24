"""Welcome page router — mounted at / by default."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import text as sa_text
from starlette.responses import HTMLResponse

from bluefox_core.welcome.page import WELCOME_HTML
from bluefox_core.welcome.store import message_store

welcome_router = APIRouter(tags=["welcome"])


class MessageCreate(BaseModel):
    text: str


class MessageResponse(BaseModel):
    id: int
    text: str
    created_at: float


async def _check_db(request: Request) -> tuple[str, str]:
    """Check database connectivity. Returns (color, detail)."""
    db_manager = getattr(request.app.state, "db", None)
    if not db_manager or not db_manager.engine:
        return "gray", " — not configured"
    try:
        async with db_manager.engine.connect() as conn:
            await conn.execute(sa_text("SELECT 1"))
        return "green", " — connected"
    except Exception:
        return "red", " — unreachable"


async def _check_redis(request: Request) -> tuple[str, str]:
    """Check Redis connectivity. Returns (color, detail)."""
    redis_manager = getattr(request.app.state, "redis", None)
    if not redis_manager or not redis_manager.client:
        return "gray", " — not configured"
    try:
        await redis_manager.client.ping()
        return "green", " — connected"
    except Exception:
        return "red", " — unreachable"


@welcome_router.get("/", response_class=HTMLResponse, include_in_schema=False)
async def welcome_page(request: Request):
    settings = request.app.state.settings
    db_color, db_detail = await _check_db(request)
    redis_color, redis_detail = await _check_redis(request)

    html = WELCOME_HTML.format(
        app_name=settings.APP_NAME,
        db_status_color=db_color,
        db_status_detail=db_detail,
        redis_status_color=redis_color,
        redis_status_detail=redis_detail,
    )
    return HTMLResponse(html)


@welcome_router.get("/welcome/messages", response_model=list[MessageResponse])
async def list_messages():
    return [
        MessageResponse(id=m.id, text=m.text, created_at=m.created_at)
        for m in message_store.list()
    ]


@welcome_router.post(
    "/welcome/messages", response_model=MessageResponse, status_code=201
)
async def create_message(data: MessageCreate):
    msg = message_store.add(data.text)
    return MessageResponse(id=msg.id, text=msg.text, created_at=msg.created_at)


@welcome_router.delete("/welcome/messages/{message_id}", status_code=204)
async def delete_message(message_id: int):
    if not message_store.delete(message_id):
        raise HTTPException(404, "Message not found")
