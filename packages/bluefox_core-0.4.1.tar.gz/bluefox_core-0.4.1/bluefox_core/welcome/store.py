"""In-memory message store for the welcome page playground."""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class Message:
    id: int
    text: str
    created_at: float = field(default_factory=time.time)


class MessageStore:
    def __init__(self) -> None:
        self._messages: list[Message] = []
        self._next_id: int = 1

    def list(self) -> list[Message]:
        return list(self._messages)

    def add(self, text: str) -> Message:
        msg = Message(id=self._next_id, text=text)
        self._next_id += 1
        self._messages.append(msg)
        return msg

    def delete(self, message_id: int) -> bool:
        for i, msg in enumerate(self._messages):
            if msg.id == message_id:
                self._messages.pop(i)
                return True
        return False

    def reset(self) -> None:
        """Clear all messages and reset the ID counter."""
        self._messages.clear()
        self._next_id = 1


# Singleton — lives for the lifetime of the process
message_store = MessageStore()
