from bluefox_core.welcome.router import welcome_router

__all__ = ["welcome_router"]
