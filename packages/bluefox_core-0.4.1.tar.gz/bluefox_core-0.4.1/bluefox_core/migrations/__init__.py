from bluefox_core.migrations.configure import configure_alembic

__all__ = ["configure_alembic"]
