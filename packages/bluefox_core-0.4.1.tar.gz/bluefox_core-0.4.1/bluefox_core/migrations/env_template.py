"""Bluefox Alembic env.py template.

Copy this file to your project's migrations/env.py after running:
    uv run alembic init -t async migrations

Or simply replace the generated env.py with this file.

All configuration (database URL, model discovery, async engine) is handled
by configure_alembic(). Set MODELS_MODULE in your .env if your models
are not in "app.models".
"""

from alembic import context
from bluefox_core.migrations import configure_alembic

configure_alembic(context)
