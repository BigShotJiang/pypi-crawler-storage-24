from collections.abc import AsyncGenerator

from fastapi import HTTPException, Request
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from bluefox_core.settings import BluefoxSettings


class BluefoxBase(DeclarativeBase):
    pass


def normalize_database_url(url: str) -> str:
    """Convert postgresql:// to postgresql+asyncpg:// for async drivers."""
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+asyncpg://", 1)
    return url


def create_engine(settings: BluefoxSettings) -> AsyncEngine | None:
    if not settings.DATABASE_URL:
        return None

    url = normalize_database_url(settings.DATABASE_URL)
    return create_async_engine(url, echo=settings.DEBUG, pool_pre_ping=True)


class DatabaseManager:
    def __init__(self, settings: BluefoxSettings):
        self.engine = create_engine(settings)
        self.session_factory = (
            async_sessionmaker(self.engine, expire_on_commit=False) if self.engine else None
        )

    async def startup(self) -> None:
        if self.engine:
            async with self.engine.connect() as conn:
                await conn.execute(text("SELECT 1"))

    async def shutdown(self) -> None:
        if self.engine:
            await self.engine.dispose()


async def get_session(request: Request) -> AsyncGenerator[AsyncSession, None]:
    db_manager: DatabaseManager | None = request.app.state.db
    if db_manager is None or db_manager.session_factory is None:
        raise HTTPException(503, "Database not configured")
    async with db_manager.session_factory() as session:
        yield session
