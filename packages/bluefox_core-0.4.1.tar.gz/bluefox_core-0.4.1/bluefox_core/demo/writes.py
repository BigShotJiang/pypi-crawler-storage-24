from sqlalchemy.ext.asyncio import AsyncSession

from .models import DemoTodo
from .schemas import TodoCreate, TodoUpdate


async def create_todo(session: AsyncSession, data: TodoCreate) -> DemoTodo:
    todo = DemoTodo(**data.model_dump())
    session.add(todo)
    await session.flush()
    return todo


async def update_todo(session: AsyncSession, todo: DemoTodo, data: TodoUpdate) -> DemoTodo:
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(todo, field, value)
    await session.flush()
    return todo


async def complete_todo(session: AsyncSession, todo: DemoTodo) -> DemoTodo:
    todo.is_completed = True
    await session.flush()
    return todo


async def delete_todo(session: AsyncSession, todo: DemoTodo) -> None:
    await session.delete(todo)
    await session.flush()
