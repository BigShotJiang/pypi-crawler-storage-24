from bluefox_test import BaseFactory, Faker, register

from bluefox_core.demo.models import DemoTodo


class DemoTodoFactory(BaseFactory):
    class Meta:
        model = DemoTodo

    title = Faker("sentence", nb_words=4)
    description = Faker("paragraph")
    is_completed = False


create_demo_todo = register(DemoTodoFactory)
