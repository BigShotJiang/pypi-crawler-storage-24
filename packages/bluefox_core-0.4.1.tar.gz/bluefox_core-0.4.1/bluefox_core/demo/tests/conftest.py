import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from bluefox_core.app import create_bluefox_app
from bluefox_core.database import get_session
from bluefox_core.settings import BluefoxSettings

from .factories import create_demo_todo  # noqa: F401


@pytest.fixture
def app(db):
    settings = BluefoxSettings(APP_NAME="demo-test")
    application = create_bluefox_app(settings, demo=True)

    async def _override_session():
        yield db

    application.dependency_overrides[get_session] = _override_session
    yield application
    application.dependency_overrides.clear()


@pytest_asyncio.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac
