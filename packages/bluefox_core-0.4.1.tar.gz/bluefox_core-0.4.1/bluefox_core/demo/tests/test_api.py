async def test_list_todos__returns_empty_list(client):
    response = await client.get("/demo/todos")
    assert response.status_code == 200
    assert response.json() == []


async def test_list_todos__returns_all_todos(client, create_demo_todo):
    await create_demo_todo()
    await create_demo_todo()
    await create_demo_todo()
    response = await client.get("/demo/todos")
    assert response.status_code == 200
    assert len(response.json()) == 3


async def test_create_todo__returns_201_with_todo(client):
    response = await client.post("/demo/todos", json={"title": "Buy milk"})
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Buy milk"
    assert data["id"] is not None


async def test_create_todo__defaults_to_not_completed(client):
    response = await client.post("/demo/todos", json={"title": "Test todo"})
    assert response.status_code == 201
    assert response.json()["is_completed"] is False


async def test_get_todo__returns_todo_by_id(client, create_demo_todo):
    todo = await create_demo_todo(title="Find me")
    response = await client.get(f"/demo/todos/{todo.id}")
    assert response.status_code == 200
    assert response.json()["title"] == "Find me"


async def test_get_todo__returns_404_when_not_found(client):
    response = await client.get("/demo/todos/99999")
    assert response.status_code == 404


async def test_update_todo__updates_title(client, create_demo_todo):
    todo = await create_demo_todo(title="Old title")
    response = await client.patch(f"/demo/todos/{todo.id}", json={"title": "New title"})
    assert response.status_code == 200
    assert response.json()["title"] == "New title"


async def test_update_todo__partial_update(client, create_demo_todo):
    todo = await create_demo_todo(title="Keep this", description="Change this")
    response = await client.patch(
        f"/demo/todos/{todo.id}", json={"description": "Updated"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Keep this"
    assert data["description"] == "Updated"


async def test_complete_todo__marks_as_completed(client, create_demo_todo):
    todo = await create_demo_todo()
    response = await client.patch(f"/demo/todos/{todo.id}/complete")
    assert response.status_code == 200
    assert response.json()["is_completed"] is True


async def test_delete_todo__removes_todo(client, create_demo_todo):
    todo = await create_demo_todo()
    response = await client.delete(f"/demo/todos/{todo.id}")
    assert response.status_code == 204

    response = await client.get(f"/demo/todos/{todo.id}")
    assert response.status_code == 404
