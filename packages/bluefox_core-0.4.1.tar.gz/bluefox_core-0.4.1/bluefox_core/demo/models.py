from sqlalchemy import Boolean, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from bluefox_core.database import BluefoxBase


class DemoTodo(BluefoxBase):
    __tablename__ = "demo_todos"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str] = mapped_column(Text, default="")
    is_completed: Mapped[bool] = mapped_column(Boolean, default=False)
