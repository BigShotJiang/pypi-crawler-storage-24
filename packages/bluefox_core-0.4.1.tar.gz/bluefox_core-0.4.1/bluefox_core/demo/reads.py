from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import DemoTodo


async def list_todos(session: AsyncSession) -> list[DemoTodo]:
    result = await session.execute(select(DemoTodo))
    return list(result.scalars().all())


async def get_todo(session: AsyncSession, todo_id: int) -> DemoTodo | None:
    return await session.get(DemoTodo, todo_id)
