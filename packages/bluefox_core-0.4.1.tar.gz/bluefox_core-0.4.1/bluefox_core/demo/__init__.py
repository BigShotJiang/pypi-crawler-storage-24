from fastapi import FastAPI


def mount_demo(app: FastAPI) -> None:
    from .api import router
    app.include_router(router)
