from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from bluefox_core.database import get_session

from .reads import get_todo, list_todos
from .schemas import TodoCreate, TodoResponse, TodoUpdate
from .writes import complete_todo, create_todo, delete_todo, update_todo

router = APIRouter(prefix="/demo/todos", tags=["demo"])


@router.get("", response_model=list[TodoResponse])
async def list_todos_endpoint(session: AsyncSession = Depends(get_session)):
    return await list_todos(session)


@router.post("", response_model=TodoResponse, status_code=201)
async def create_todo_endpoint(data: TodoCreate, session: AsyncSession = Depends(get_session)):
    todo = await create_todo(session, data)
    await session.commit()
    return todo


@router.get("/{todo_id}", response_model=TodoResponse)
async def get_todo_endpoint(todo_id: int, session: AsyncSession = Depends(get_session)):
    todo = await get_todo(session, todo_id)
    if not todo:
        raise HTTPException(404, "Todo not found")
    return todo


@router.patch("/{todo_id}", response_model=TodoResponse)
async def update_todo_endpoint(
    todo_id: int, data: TodoUpdate, session: AsyncSession = Depends(get_session)
):
    todo = await get_todo(session, todo_id)
    if not todo:
        raise HTTPException(404, "Todo not found")
    todo = await update_todo(session, todo, data)
    await session.commit()
    return todo


@router.patch("/{todo_id}/complete", response_model=TodoResponse)
async def complete_todo_endpoint(todo_id: int, session: AsyncSession = Depends(get_session)):
    todo = await get_todo(session, todo_id)
    if not todo:
        raise HTTPException(404, "Todo not found")
    todo = await complete_todo(session, todo)
    await session.commit()
    return todo


@router.delete("/{todo_id}", status_code=204)
async def delete_todo_endpoint(todo_id: int, session: AsyncSession = Depends(get_session)):
    todo = await get_todo(session, todo_id)
    if not todo:
        raise HTTPException(404, "Todo not found")
    await delete_todo(session, todo)
    await session.commit()
