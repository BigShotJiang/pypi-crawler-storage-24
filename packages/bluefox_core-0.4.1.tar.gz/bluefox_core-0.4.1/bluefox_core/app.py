from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from bluefox_core.database import DatabaseManager
from bluefox_core.discovery import discover_routers
from bluefox_core.health import health_router
from bluefox_core.log import configure_logging, logger
from bluefox_core.middleware import RequestIDMiddleware
from bluefox_core.redis import RedisManager
from bluefox_core.settings import BluefoxSettings
from bluefox_core.templates import setup_templates
from bluefox_core.welcome import welcome_router


def create_bluefox_app(
    settings: BluefoxSettings,
    welcome: bool = False,
    demo: bool = False,
) -> FastAPI:
    configure_logging(settings)

    db_manager = DatabaseManager(settings)
    redis_manager = RedisManager(settings)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await db_manager.startup()
        await redis_manager.startup()
        logger.info("app started", app_name=settings.APP_NAME)
        try:
            yield
        finally:
            await db_manager.shutdown()
            await redis_manager.shutdown()
            logger.info("app stopped", app_name=settings.APP_NAME)

    app = FastAPI(title=settings.APP_NAME, lifespan=lifespan)

    app.add_middleware(RequestIDMiddleware)

    if settings.is_production:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=[],
            allow_credentials=False,
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
            allow_headers=["*"],
        )
    else:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    app.state.db = db_manager
    app.state.redis = redis_manager
    app.state.settings = settings

    setup_templates(app)

    app.include_router(health_router)

    if welcome:
        app.include_router(welcome_router)

    # Auto-discover user routers (*/api.py with a `router` attribute)
    discover_routers(app)

    if demo:
        # Lazy import: importing demo registers its Todo model in
        # BluefoxBase.metadata, which would pollute user migrations
        # when demo=False.
        from bluefox_core.demo import mount_demo
        mount_demo(app)

    return app
