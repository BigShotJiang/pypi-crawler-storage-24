"""Redis client management with lifespan hooks and FastAPI dependency."""

import redis.asyncio as aioredis
from fastapi import HTTPException, Request
from redis.asyncio import Redis

from bluefox_core.settings import BluefoxSettings


class RedisManager:
    """Manages an async Redis client with lifespan hooks."""

    def __init__(self, settings: BluefoxSettings):
        self.client: Redis | None = None
        if settings.has_redis:
            self.client = aioredis.from_url(settings.REDIS_URL)

    async def startup(self) -> None:
        if self.client:
            await self.client.ping()

    async def shutdown(self) -> None:
        if self.client:
            await self.client.aclose()


async def get_redis(request: Request) -> Redis:
    """FastAPI dependency that yields the Redis client.

    Usage::

        @router.get("/cached")
        async def cached_value(redis: Redis = Depends(get_redis)):
            return await redis.get("key")
    """
    redis_manager: RedisManager | None = getattr(request.app.state, "redis", None)
    if redis_manager is None or redis_manager.client is None:
        raise HTTPException(503, "Redis not configured")
    return redis_manager.client
