"""Jinja2 template environment with extensible search paths.

The loader is a FileSystemLoader initialized with a list of directories.
Other packages (e.g. bluefox-components) can append their own template
directories via ``add_template_directory()``.  The app's own templates
directory is always searched first.
"""

from pathlib import Path

from fastapi import FastAPI
from jinja2 import Environment, FileSystemLoader, select_autoescape

from bluefox_core.log import logger


def setup_templates(app: FastAPI) -> Environment:
    """Create a Jinja2 environment and store it on ``app.state.templates``.

    If a ``templates/`` directory exists in the working directory it is
    added as the first search path.  Returns the environment so callers
    can use it directly.
    """
    searchpath: list[str] = []

    # App's own templates directory gets highest priority
    app_templates = Path("templates")
    if app_templates.is_dir():
        searchpath.append(str(app_templates.resolve()))
    else:
        logger.debug("no templates/ directory found, Jinja2 loader has no app paths")

    env = Environment(
        loader=FileSystemLoader(searchpath),
        autoescape=select_autoescape(["html", "xml"]),
    )
    app.state.templates = env
    return env


def add_template_directory(app: FastAPI, path: str | Path) -> None:
    """Register an additional template search directory.

    Appended after existing paths, so app templates take priority.
    Called by extension packages like bluefox-components::

        # Inside bluefox_components.setup_components(app):
        pkg_dir = Path(__file__).parent / "templates"
        add_template_directory(app, pkg_dir)
    """
    env: Environment | None = getattr(app.state, "templates", None)
    if env is None:
        env = setup_templates(app)

    loader = env.loader
    if isinstance(loader, FileSystemLoader):
        resolved = str(Path(path).resolve())
        if resolved not in loader.searchpath:
            loader.searchpath.append(resolved)
