from pydantic_settings import BaseSettings, SettingsConfigDict


class BluefoxSettings(BaseSettings):
    APP_NAME: str = "bluefox-app"
    ENVIRONMENT: str = "development"
    DEBUG: bool = False

    DATABASE_URL: str = ""
    REDIS_URL: str = ""
    SECRET_KEY: str = "change-me-in-production"
    LOG_LEVEL: str = "INFO"
    MODELS_MODULE: str = ""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"

    @property
    def is_development(self) -> bool:
        return self.ENVIRONMENT == "development"

    @property
    def has_database(self) -> bool:
        return bool(self.DATABASE_URL)

    @property
    def has_redis(self) -> bool:
        return bool(self.REDIS_URL)
