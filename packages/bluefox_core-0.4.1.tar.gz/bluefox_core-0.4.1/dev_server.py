"""Dev server for previewing the welcome page."""

import uvicorn

from bluefox_core import BluefoxSettings, create_bluefox_app

settings = BluefoxSettings()
app = create_bluefox_app(settings, welcome=True)

if __name__ == "__main__":
    uvicorn.run("dev_server:app", host="127.0.0.1", port=8080, reload=True)
