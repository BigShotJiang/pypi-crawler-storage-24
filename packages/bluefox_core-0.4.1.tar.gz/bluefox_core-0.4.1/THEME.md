# Bluefox Landing Page Design System

Shared design tokens and conventions for all Bluefox package landing pages.
Every landing page in the Bluefox Stack must follow these guidelines to maintain visual consistency.

## Fonts

- **Body:** DM Sans (weights: 300, 400, 500, 600)
- **Mono:** JetBrains Mono (weights: 400, 500)
- Load via Google Fonts with `display=swap`

## Color Tokens

```css
:root {
  --bg: #FAFAF8;
  --bg-warm: #F5F4F0;
  --text: #1A1A18;
  --text-secondary: #6B6B64;
  --accent: #D4652A;
  --accent-light: #F0DED2;
  --border: #E4E3DF;
  --code-bg: #1A1A18;
  --code-text: #E8E6E1;
  --code-keyword: #D4652A;
  --code-string: #8FA67A;
  --code-comment: #6B6B64;
  --code-func: #C9A86C;
}
```

Operator color: `#8B8B84` (applied directly via `.op` class).

## Layout

- Max content width: **720px**, centered
- Body padding: `2rem` horizontal, `1.5rem` on mobile
- Sections separated by `border-top: 1px solid var(--border)`
- Base font size: `17px` (desktop), `16px` (mobile)

## Nav

- Fixed top, `rgba(250, 250, 248, 0.85)` background with `blur(12px)` backdrop
- `border-bottom: 1px solid var(--border)`
- Brand: fox SVG + package name, `0.95rem`, weight 600
- Fox SVG: `22x22px`
- Links: `0.85rem`, `var(--text-secondary)`, hover to `var(--text)`
- Install pill (`.nav-pip`): `var(--code-bg)` background, `0.78rem` mono, `0.35rem 0.85rem` padding, `6px` radius

## Hero

- Padding: `10rem` top, `5rem` bottom
- Badge: mono `0.72rem`, uppercase, `var(--accent)` text on `var(--accent-light)` background, `0.3rem 0.75rem` padding, `4px` radius
- H1: `3rem`, weight 600, `letter-spacing: -0.035em`, `line-height: 1.1`
- H1 `<em>`: weight 300, italic, `var(--text-secondary)`
- Subtitle: `1.15rem`, `var(--text-secondary)`, max-width `540px`

## Section Labels

- Mono `0.72rem`, weight 500, uppercase, `letter-spacing: 0.08em`
- Color: `var(--text-secondary)`

## Code Blocks

- Background: `var(--code-bg)`, border-radius: **10px**
- Header: `0.75rem 1.25rem` padding, bottom border `rgba(255,255,255,0.06)`
- Dots: **8px**, `rgba(255,255,255,0.12)`
- Filename: mono `0.72rem`, `rgba(255,255,255,0.35)`
- Code text: mono `0.82rem`, `line-height: 1.75`, padding `1.25rem 1.5rem`
- Terminal variant: `0.85rem 1.25rem` padding, `line-height: 1.6`
- Prompt (`$`): `rgba(255,255,255,0.3)`, `user-select: none`

## Inline Code

- `background: var(--bg-warm)`, `padding: 0.1em 0.35em`, `border-radius: 4px`
- Font size: `0.85em`

## Features Grid

- Two columns: `1fr 1fr`, gap `2.5rem 3rem`
- Single column on mobile (`max-width: 640px`)
- Feature title: `0.95rem`, weight 600
- Feature description: `0.88rem`, `var(--text-secondary)`, `line-height: 1.6`

## Footer

- `3rem 2rem` padding
- Text: `0.8rem`, `var(--text-secondary)`
- Format: `{package-name} · part of the Bluefox Stack` | `bluefox.software`

## Animation

- Fade-in: `translateY(8px)`, `0.6s ease`, staggered delays (`0.05s`, `0.12s`, `0.19s`, `0.26s`)

## Responsive (max-width: 640px)

- Font size: `16px`
- Hero padding: `7rem` top, `3rem` bottom
- H1: `2.2rem`
- Section padding: `1.5rem` horizontal
- Feature grid: single column, `2rem` gap
- Hide desktop-only nav labels (`.label-desktop`)

## Fox SVG

Shared across all packages — same markup, colored with `var(--accent)`.

## Analytics

Each package uses Plausible with its own subdomain:
`data-domain="{package-name}.bluefox.software"`
