from bluefox_test import bluefox_test_setup
from bluefox_core.database import BluefoxBase

globals().update(bluefox_test_setup(
    base=BluefoxBase,
    app_factory=None,
    session_dependency=None,
))
