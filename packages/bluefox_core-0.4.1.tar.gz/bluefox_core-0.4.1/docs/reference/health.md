# Health endpoints

Two endpoints for monitoring and orchestration.

## GET /health

Always returns `200 OK`:

```json
{"status": "ok"}
```

Use this for liveness probes (e.g. Kubernetes `livenessProbe`). It confirms the process is running and accepting requests.

## GET /readiness

Checks connected services and returns their status:

```json
{"status": "ready", "checks": {"database": "ok", "redis": "ok"}}
```

Returns `200` when all checks pass, `503` when any check fails:

```json
{"status": "not_ready", "checks": {"database": "error: connection refused"}}
```

Use this for readiness probes (e.g. Kubernetes `readinessProbe`). It confirms the app can serve traffic.

### What gets checked

| Service | Checked when | How |
|---|---|---|
| Database | `DATABASE_URL` is set | Executes `SELECT 1` |
| Redis | `REDIS_URL` is set | Calls `PING` |

If neither is configured, `/readiness` returns `200` with an empty `checks` object.
