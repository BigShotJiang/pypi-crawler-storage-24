# Settings

`BluefoxSettings` extends pydantic-settings `BaseSettings` to provide typed, validated configuration with environment variable and `.env` file support.

## BluefoxSettings

```python
from bluefox_core import BluefoxSettings

settings = BluefoxSettings()
```

### Fields

| Field | Type | Default | Description |
|---|---|---|---|
| `APP_NAME` | `str` | `"bluefox-app"` | Application name |
| `ENVIRONMENT` | `str` | `"development"` | `"development"` or `"production"` |
| `DEBUG` | `bool` | `False` | Enables SQLAlchemy echo |
| `DATABASE_URL` | `str` | `""` | PostgreSQL connection string |
| `REDIS_URL` | `str` | `""` | Redis connection string |
| `SECRET_KEY` | `str` | `"change-me-in-production"` | Application secret |
| `LOG_LEVEL` | `str` | `"INFO"` | Python logging level |

### Properties

| Property | Returns | Description |
|---|---|---|
| `is_production` | `bool` | `True` when `ENVIRONMENT == "production"` |
| `is_development` | `bool` | `True` when `ENVIRONMENT == "development"` |
| `has_database` | `bool` | `True` when `DATABASE_URL` is non-empty |
| `has_redis` | `bool` | `True` when `REDIS_URL` is non-empty |

### Configuration

Settings are loaded from environment variables and `.env` files. Field names are **case-sensitive** — use uppercase in your `.env` file:

```bash
# .env
APP_NAME=my-app
ENVIRONMENT=production
DATABASE_URL=postgresql://user:pass@localhost:5432/mydb
```

Unknown environment variables are ignored (`extra="ignore"`), so you can safely have variables in your `.env` that aren't part of the settings.

## Subclassing

Add custom fields for your application:

```python
from bluefox_core import BluefoxSettings

class MySettings(BluefoxSettings):
    STRIPE_API_KEY: str = ""
    FEATURE_FLAG_X: bool = False
```

Your subclass inherits all base fields, properties, and the `.env` loading behavior. The app factory accepts any `BluefoxSettings` subclass:

```python
settings = MySettings()
app = create_bluefox_app(settings)

# Access your custom fields via app.state.settings
assert app.state.settings.STRIPE_API_KEY == ""
```
