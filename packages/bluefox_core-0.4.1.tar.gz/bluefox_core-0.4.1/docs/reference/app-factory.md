# App factory

`create_bluefox_app()` builds a fully configured FastAPI application.

## Usage

```python
from bluefox_core import BluefoxSettings, create_bluefox_app

settings = BluefoxSettings()
app = create_bluefox_app(settings)
```

## What it does

1. **Configures logging** via `configure_logging(settings)`
2. **Creates a DatabaseManager** (no-op if `DATABASE_URL` is empty)
3. **Creates a RedisManager** (no-op if `REDIS_URL` is empty)
4. **Sets up the lifespan** — startup verifies DB/Redis connectivity, shutdown disposes resources (wrapped in `try/finally` for safe cleanup)
5. **Adds middleware**:
    - `RequestIDMiddleware` — injects `X-Request-ID` headers and log context
    - `CORSMiddleware` — permissive in development, restrictive in production
6. **Stores state** — `app.state.db`, `app.state.redis`, `app.state.settings`
7. **Sets up Jinja2 templates** — extensible `FileSystemLoader` with `templates/` auto-detected
8. **Mounts the health router** — `/health` and `/readiness`
9. **Mounts the welcome page** (if `welcome=True`) — interactive landing page at `/`
10. **Auto-discovers routers** — scans `*/api.py` and mounts routers by convention
11. **Mounts the demo app** (if `demo=True`) — Todo CRUD at `/demo/todos`

## Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `settings` | `BluefoxSettings` | required | Application settings |
| `welcome` | `bool` | `False` | Mount the welcome page at `/` |
| `demo` | `bool` | `False` | Mount the demo Todo CRUD app |

## CORS behavior

| Setting | Development | Production |
|---|---|---|
| `allow_origins` | `["*"]` | `[]` |
| `allow_credentials` | `True` | `False` |
| `allow_methods` | `["*"]` | `["GET", "POST", "PUT", "PATCH", "DELETE"]` |
| `allow_headers` | `["*"]` | `["*"]` |

## App state

After creation, the following are available on `app.state`:

| Attribute | Type | Description |
|---|---|---|
| `app.state.settings` | `BluefoxSettings` | The settings instance |
| `app.state.db` | `DatabaseManager` | Database manager (engine may be `None`) |
| `app.state.redis` | `RedisManager` | Redis manager (client may be `None`) |
| `app.state.templates` | `jinja2.Environment` | Jinja2 environment with extensible loader |

## Welcome page

The welcome page is served at `GET /` when `welcome=True`. It shows status badges for the app, database, and Redis, plus an interactive message playground.

Remove it by dropping the `welcome=True` parameter:

```python
# Welcome page shown
app = create_bluefox_app(settings, welcome=True)

# No welcome page — the default
app = create_bluefox_app(settings)
```
