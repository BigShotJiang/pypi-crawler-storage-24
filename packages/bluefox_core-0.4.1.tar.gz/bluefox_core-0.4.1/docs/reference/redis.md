# Redis

bluefox-core manages an async Redis client via `RedisManager`, following the same pattern as `DatabaseManager`.

## Configuration

Set `REDIS_URL` in your `.env` file:

```bash
REDIS_URL=redis://localhost:6379/0
```

When `REDIS_URL` is empty (the default), Redis is disabled — no client is created and the app runs without it.

## RedisManager

`RedisManager` wraps the async Redis client with lifespan hooks:

- **Startup** — pings Redis to verify connectivity
- **Shutdown** — closes the client connection

The manager is created automatically by `create_bluefox_app()` and stored at `app.state.redis`.

## get_redis dependency

Use the `get_redis` dependency to inject the Redis client into your routes:

```python
from fastapi import APIRouter, Depends
from redis.asyncio import Redis
from bluefox_core import get_redis

router = APIRouter()

@router.get("/cached")
async def get_cached_value(redis: Redis = Depends(get_redis)):
    value = await redis.get("my-key")
    return {"value": value}

@router.post("/cache")
async def set_cached_value(key: str, value: str, redis: Redis = Depends(get_redis)):
    await redis.set(key, value)
    return {"stored": True}
```

If Redis is not configured, `get_redis` returns a `503 Service Unavailable` response.

## Direct access

You can also access the Redis client directly from app state:

```python
@router.get("/ping-redis")
async def ping_redis(request: Request):
    redis_manager = request.app.state.redis
    if redis_manager.client:
        await redis_manager.client.ping()
        return {"redis": "ok"}
    return {"redis": "not configured"}
```

## Health checks

The `/readiness` endpoint automatically checks Redis connectivity when configured. See [Health endpoints](health.md) for details.
