# bluefox-core

The foundation of every Bluefox app — settings, database, logging, health, and app factory.

## What it provides

- **Settings** — `BluefoxSettings` powered by pydantic-settings, with `.env` file support
- **Database** — async SQLAlchemy engine, session management, and `get_session` FastAPI dependency
- **Redis** — async Redis client via `RedisManager`, with `get_redis` FastAPI dependency
- **Templates** — Jinja2 environment with extensible loader for package-provided templates
- **Logging** — structured logging via structlog (JSON in production, console in development)
- **Health endpoints** — `/health` and `/readiness` with database and Redis checks
- **App factory** — `create_bluefox_app()` wires everything together into a FastAPI application
- **Request ID middleware** — injects `X-Request-ID` headers and binds them to log context
- **Auto-discovery** — convention-based scanning for `*/models.py` and `*/api.py` — models register in metadata, routers mount automatically
- **Migrations** — Alembic integration with automatic model discovery and inheritance validation
- **Welcome page** — interactive landing page with status badges and message playground (opt-in via `welcome=True`)
- **Demo app** — a working Todo CRUD example to reference

## Quick start

```bash
uv add bluefox-core
```

```python
from bluefox_core import BluefoxSettings, create_bluefox_app

settings = BluefoxSettings()
app = create_bluefox_app(settings)
```

```bash
uv run uvicorn main:app --reload
```

Visit `http://localhost:8000` to see the welcome page, `/health` for the health check, and `/docs` for the interactive API docs.

## Requirements

- Python 3.12+
- PostgreSQL (optional — the app runs without a database)
- Redis (optional — used for readiness checks when configured)
