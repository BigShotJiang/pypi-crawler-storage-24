# Testing

bluefox-core uses [bluefox-test](https://bluefox-test.bluefox.software/docs) for its test infrastructure.

## Setup

Install test dependencies:

```bash
uv sync --group test
```

### Root conftest.py

```python
from bluefox_test import bluefox_test_setup
from bluefox_core.database import BluefoxBase

globals().update(bluefox_test_setup(
    base=BluefoxBase,
    app_factory=None,
    session_dependency=None,
))
```

Since bluefox-core is a library (not an app), `app_factory` and `session_dependency` are set to `None`. This provides the core fixtures (`infra`, `engine`, `db`) without app-specific wiring.

### App-specific test fixtures

For tests that need an HTTP client, create fixtures in your test conftest:

```python
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from bluefox_core.app import create_bluefox_app
from bluefox_core.database import get_session
from bluefox_core.settings import BluefoxSettings

@pytest.fixture
def app(db):
    settings = BluefoxSettings()
    application = create_bluefox_app(settings, demo=True)

    async def _override_session():
        yield db

    application.dependency_overrides[get_session] = _override_session
    yield application
    application.dependency_overrides.clear()

@pytest_asyncio.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac
```

The `db` fixture (provided by bluefox-test) gives you a transactional session that rolls back after each test.

## Running tests

```bash
uv run pytest -v
```

## Factories

Use bluefox-test's factory system for test data:

```python
from bluefox_test import BaseFactory, Faker, register
from myapp.models import User

class UserFactory(BaseFactory):
    class Meta:
        model = User
    name = Faker("name")
    email = Faker("email")

create_user = register(UserFactory)
```

Then use in tests:

```python
async def test_something(create_user):
    user = await create_user(name="Alice")
    assert user.name == "Alice"
```
