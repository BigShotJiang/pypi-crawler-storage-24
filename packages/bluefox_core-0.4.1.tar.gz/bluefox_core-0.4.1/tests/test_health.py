import httpx

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings


def _make_client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")


async def test_health__always_returns_ok():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


async def test_readiness__returns_ready_with_healthy_db(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/readiness")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ready"
    assert data["checks"]["database"] == "ok"


async def test_readiness__returns_503_with_dead_db():
    settings = BluefoxSettings(DATABASE_URL="postgresql+asyncpg://localhost:59999/nonexistent")
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/readiness")
    assert response.status_code == 503
    data = response.json()
    assert data["status"] == "not_ready"
    assert "error" in data["checks"]["database"]


async def test_readiness__returns_ready_without_db_configured(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/readiness")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ready"
    assert data["checks"] == {}
