import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

from bluefox_core.database import BluefoxBase, DatabaseManager, create_engine
from bluefox_core.settings import BluefoxSettings


def test_create_engine__returns_engine_when_url_set(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    engine = create_engine(settings)
    assert engine is not None
    assert isinstance(engine, AsyncEngine)


def test_create_engine__returns_none_when_url_empty():
    settings = BluefoxSettings(DATABASE_URL="")
    engine = create_engine(settings)
    assert engine is None


def test_create_engine__normalizes_url(infra):
    _, _, async_url, _, _ = infra
    # Replace asyncpg URL with plain postgresql:// to test normalization
    plain_url = async_url.replace("postgresql+asyncpg://", "postgresql://")
    settings = BluefoxSettings(DATABASE_URL=plain_url)
    engine = create_engine(settings)
    assert engine is not None
    assert "asyncpg" in str(engine.url)


async def test_database_manager__startup_verifies_connectivity(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    manager = DatabaseManager(settings)
    await manager.startup()  # should not raise
    await manager.shutdown()


async def test_database_manager__startup_noop_without_database():
    settings = BluefoxSettings(DATABASE_URL="")
    manager = DatabaseManager(settings)
    await manager.startup()  # should not raise, no-op


async def test_database_manager__shutdown_disposes_engine(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    manager = DatabaseManager(settings)
    await manager.startup()
    await manager.shutdown()
    # After dispose, the engine pool is closed
    assert manager.engine is not None  # engine object still exists, but pool is disposed


async def test_get_session__yields_working_session(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    manager = DatabaseManager(settings)
    await manager.startup()

    try:
        async with manager.session_factory() as session:
            result = await session.execute(text("SELECT 1"))
            assert result.scalar() == 1
    finally:
        await manager.shutdown()
