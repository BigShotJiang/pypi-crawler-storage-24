import httpx

from bluefox_core.app import create_bluefox_app
from bluefox_core.database import DatabaseManager
from bluefox_core.settings import BluefoxSettings


def _make_client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")


def test_create_bluefox_app__returns_fastapi_instance():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    assert app is not None
    assert app.title == "bluefox-app"


async def test_create_bluefox_app__health_returns_200():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


async def test_create_bluefox_app__readiness_returns_200_without_db(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/readiness")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ready"
    assert data["checks"] == {}


async def test_create_bluefox_app__readiness_checks_db_when_configured(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/readiness")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ready"
    assert data["checks"]["database"] == "ok"


async def test_create_bluefox_app__request_id_header_injected():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/health")
    assert "x-request-id" in response.headers
    assert len(response.headers["x-request-id"]) > 0


async def test_create_bluefox_app__request_id_from_client_preserved():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/health", headers={"X-Request-ID": "custom-id-123"})
    assert response.headers["x-request-id"] == "custom-id-123"


def test_create_bluefox_app__stores_settings_in_state():
    settings = BluefoxSettings(APP_NAME="test-app")
    app = create_bluefox_app(settings)
    assert app.state.settings is settings
    assert app.state.settings.APP_NAME == "test-app"


def test_create_bluefox_app__stores_db_manager_in_state():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    assert isinstance(app.state.db, DatabaseManager)
