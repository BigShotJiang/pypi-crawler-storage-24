import json

import httpx
from fastapi import APIRouter

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings


def _make_client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")


async def test_minimal_app__no_database(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)

    async with _make_client(app) as client:
        health = await client.get("/health")
        assert health.status_code == 200

        # welcome defaults to False — no root page unless explicitly enabled
        root = await client.get("/")
        assert root.status_code == 404


async def test_minimal_app__with_database(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    app = create_bluefox_app(settings)

    async with _make_client(app) as client:
        health = await client.get("/health")
        assert health.status_code == 200

        readiness = await client.get("/readiness")
        assert readiness.status_code == 200
        assert readiness.json()["checks"]["database"] == "ok"


async def test_demo_app__full_crud_cycle(infra):
    _, _, async_url, _, _ = infra
    settings = BluefoxSettings(DATABASE_URL=async_url)
    app = create_bluefox_app(settings, demo=True)

    # Create tables for demo
    from bluefox_core.database import BluefoxBase
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine(async_url)
    async with engine.begin() as conn:
        await conn.run_sync(BluefoxBase.metadata.create_all)
    await engine.dispose()

    async with _make_client(app) as client:
        # Create
        resp = await client.post("/demo/todos", json={"title": "Integration test todo"})
        assert resp.status_code == 201
        todo_id = resp.json()["id"]

        # Read
        resp = await client.get(f"/demo/todos/{todo_id}")
        assert resp.status_code == 200
        assert resp.json()["title"] == "Integration test todo"

        # Complete
        resp = await client.patch(f"/demo/todos/{todo_id}/complete")
        assert resp.status_code == 200
        assert resp.json()["is_completed"] is True

        # Delete
        resp = await client.delete(f"/demo/todos/{todo_id}")
        assert resp.status_code == 204

        # Verify deleted
        resp = await client.get(f"/demo/todos/{todo_id}")
        assert resp.status_code == 404


async def test_user_router__replaces_welcome_when_disabled(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=False)

    router = APIRouter()

    @router.get("/")
    async def home():
        return {"message": "custom home"}

    app.include_router(router)

    async with _make_client(app) as client:
        resp = await client.get("/")
        assert resp.status_code == 200
        assert resp.json() == {"message": "custom home"}


async def test_logging__request_id_in_output(monkeypatch, capsys):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings(ENVIRONMENT="production")
    app = create_bluefox_app(settings)

    router = APIRouter()

    @router.get("/log-it")
    async def log_it():
        from bluefox_core.log import logger
        logger.info("integration log test")
        return {"ok": True}

    app.include_router(router)

    async with _make_client(app) as client:
        resp = await client.get("/log-it", headers={"X-Request-ID": "integ-123"})
        assert resp.status_code == 200

    captured = capsys.readouterr()
    lines = [line for line in captured.err.strip().splitlines() if "integration log test" in line]
    assert len(lines) >= 1
    parsed = json.loads(lines[0])
    assert parsed["request_id"] == "integ-123"


def test_settings_subclass__custom_fields(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)

    class MySettings(BluefoxSettings):
        CUSTOM_FLAG: bool = True

    settings = MySettings()
    app = create_bluefox_app(settings)
    assert app.state.settings.CUSTOM_FLAG is True
    assert isinstance(app.state.settings, MySettings)
