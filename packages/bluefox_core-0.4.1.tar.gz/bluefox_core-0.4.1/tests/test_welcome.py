import httpx

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_core.welcome.store import MessageStore, message_store


def _make_client(app):
    return httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    )


# --- Welcome page ---


async def test_welcome_page__shows_when_enabled(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert response.status_code == 200
    assert "is ready for development" in response.text


async def test_welcome_page__includes_app_name(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings(APP_NAME="My Cool App")
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert response.status_code == 200
    assert "My Cool App" in response.text


async def test_welcome_page__links_to_docs(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert "/docs" in response.text
    assert "/health" in response.text
    assert "/redoc" in response.text


async def test_welcome_page__shows_db_not_configured(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert "not configured" in response.text


async def test_welcome_page__hidden_by_default(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert response.status_code == 404


async def test_welcome_page__health_still_works(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


async def test_welcome_page__shows_create_module_instructions(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert "Getting started" in response.text
    assert "remove welcome=True" in response.text


# --- Message board playground ---


async def test_messages__list_empty(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    message_store.reset()
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        response = await client.get("/welcome/messages")
    assert response.status_code == 200
    assert response.json() == []


async def test_messages__create_and_list(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    message_store.reset()
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        res = await client.post(
            "/welcome/messages", json={"text": "Hello from test!"}
        )
        assert res.status_code == 201
        msg = res.json()
        assert msg["text"] == "Hello from test!"
        assert msg["id"] == 1

        res = await client.get("/welcome/messages")
        assert len(res.json()) == 1
        assert res.json()[0]["text"] == "Hello from test!"


async def test_messages__delete(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    message_store.reset()
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        await client.post("/welcome/messages", json={"text": "delete me"})
        res = await client.delete("/welcome/messages/1")
        assert res.status_code == 204

        res = await client.get("/welcome/messages")
        assert res.json() == []


async def test_messages__delete_not_found(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    message_store.reset()
    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=True)
    async with _make_client(app) as client:
        res = await client.delete("/welcome/messages/999")
        assert res.status_code == 404


# --- Message store unit tests ---


def test_message_store__add_and_list():
    store = MessageStore()
    msg = store.add("test message")
    assert msg.id == 1
    assert msg.text == "test message"
    assert len(store.list()) == 1


def test_message_store__auto_increments_id():
    store = MessageStore()
    m1 = store.add("first")
    m2 = store.add("second")
    assert m1.id == 1
    assert m2.id == 2


def test_message_store__delete():
    store = MessageStore()
    store.add("to delete")
    assert store.delete(1) is True
    assert len(store.list()) == 0


def test_message_store__delete_nonexistent():
    store = MessageStore()
    assert store.delete(99) is False


def test_message_store__reset():
    store = MessageStore()
    store.add("one")
    store.add("two")
    store.reset()
    assert store.list() == []
    msg = store.add("after reset")
    assert msg.id == 1
