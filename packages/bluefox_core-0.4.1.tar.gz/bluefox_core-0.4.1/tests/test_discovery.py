"""Tests for convention-based auto-discovery of models and routers."""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import httpx
from fastapi import APIRouter

from bluefox_core.app import create_bluefox_app
from bluefox_core.discovery import (
    _ROUTER_PATTERNS,
    _find_modules,
    _prefix_from_path,
    discover_models,
    discover_routers,
)
from bluefox_core.settings import BluefoxSettings


def _make_client(app):
    return httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    )


# --- _find_modules for routers ---


def test_find_router_modules__finds_api_py(tmp_path, monkeypatch):
    (tmp_path / "api.py").write_text("# api")
    monkeypatch.chdir(tmp_path)
    modules = [m for m, _ in _find_modules(_ROUTER_PATTERNS)]
    assert "api" in modules


def test_find_router_modules__finds_nested_api(tmp_path, monkeypatch):
    pkg = tmp_path / "items"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "api.py").write_text("# api")
    monkeypatch.chdir(tmp_path)
    modules = [m for m, _ in _find_modules(_ROUTER_PATTERNS)]
    assert "items.api" in modules


def test_find_router_modules__empty_when_no_api(tmp_path, monkeypatch):
    (tmp_path / "main.py").write_text("# main")
    monkeypatch.chdir(tmp_path)
    modules = [m for m, _ in _find_modules(_ROUTER_PATTERNS)]
    assert modules == []


def test_find_router_modules__deduplicates_app(tmp_path, monkeypatch):
    pkg = tmp_path / "app"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "api.py").write_text("# api")
    monkeypatch.chdir(tmp_path)
    modules = [m for m, _ in _find_modules(_ROUTER_PATTERNS)]
    assert modules.count("app.api") == 1


# --- _prefix_from_path ---


def test_prefix_from_path__root_api(tmp_path):
    path = tmp_path / "api.py"
    assert _prefix_from_path(path, tmp_path) == ""


def test_prefix_from_path__app_api(tmp_path):
    path = tmp_path / "app" / "api.py"
    assert _prefix_from_path(path, tmp_path) == ""


def test_prefix_from_path__module_api(tmp_path):
    path = tmp_path / "items" / "api.py"
    assert _prefix_from_path(path, tmp_path) == "/items"


def test_prefix_from_path__users_api(tmp_path):
    path = tmp_path / "users" / "api.py"
    assert _prefix_from_path(path, tmp_path) == "/users"


# --- discover_routers integration ---


async def test_discover_routers__mounts_api_py(tmp_path, monkeypatch):
    """Router from items/api.py is auto-mounted at /items."""
    pkg = tmp_path / "items"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "api.py").write_text(
        "from fastapi import APIRouter\n"
        "router = APIRouter()\n"
        "@router.get('/')\n"
        "async def list_items():\n"
        "    return {'items': []}\n"
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(tmp_path)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)

    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=False)

    async with _make_client(app) as client:
        resp = await client.get("/items/")
        assert resp.status_code == 200
        assert resp.json() == {"items": []}


async def test_discover_routers__skips_api_without_router(tmp_path, monkeypatch):
    """api.py without a `router` attribute is silently skipped."""
    (tmp_path / "api.py").write_text("# no router here\nx = 42\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(tmp_path)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)

    settings = BluefoxSettings()
    # Should not raise
    app = create_bluefox_app(settings, welcome=False)
    assert app is not None


async def test_discover_routers__multiple_modules(tmp_path, monkeypatch):
    """Multiple modules are discovered and mounted at their prefixes."""
    for name in ("items", "users"):
        pkg = tmp_path / name
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "api.py").write_text(
            f"from fastapi import APIRouter\n"
            f"router = APIRouter()\n"
            f"@router.get('/')\n"
            f"async def list_{name}():\n"
            f"    return {{'{name}': []}}\n"
        )
    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(tmp_path)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)

    settings = BluefoxSettings()
    app = create_bluefox_app(settings, welcome=False)

    async with _make_client(app) as client:
        resp = await client.get("/items/")
        assert resp.status_code == 200
        assert resp.json() == {"items": []}

        resp = await client.get("/users/")
        assert resp.status_code == 200
        assert resp.json() == {"users": []}


# --- Entry point model discovery ---


def test_discover_models__loads_entry_points(tmp_path, monkeypatch):
    """Entry points in the 'bluefox.models' group are loaded."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)

    mock_ep = MagicMock()
    mock_ep.name = "auth_models"

    with patch(
        "bluefox_core.discovery.entry_points", return_value=[mock_ep]
    ):
        settings = BluefoxSettings()
        discover_models(settings)

    mock_ep.load.assert_called_once()


def test_discover_models__skips_failing_entry_point(tmp_path, monkeypatch):
    """Entry points that fail to import are skipped gracefully."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)

    mock_ep = MagicMock()
    mock_ep.name = "broken_models"
    mock_ep.load.side_effect = ImportError("no such module")

    with patch(
        "bluefox_core.discovery.entry_points", return_value=[mock_ep]
    ):
        settings = BluefoxSettings()
        # Should not raise
        discover_models(settings)

    mock_ep.load.assert_called_once()


def test_discover_models__entry_points_skipped_when_models_module_set(
    tmp_path, monkeypatch
):
    """When MODELS_MODULE is set explicitly, entry points are not loaded."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)

    # Create a dummy module for MODELS_MODULE to import
    (tmp_path / "mymodels.py").write_text("# empty models\n")
    monkeypatch.syspath_prepend(tmp_path)

    mock_ep = MagicMock()
    mock_ep.name = "should_not_load"

    with patch(
        "bluefox_core.discovery.entry_points", return_value=[mock_ep]
    ):
        settings = BluefoxSettings(MODELS_MODULE="mymodels")
        discover_models(settings)

    mock_ep.load.assert_not_called()
