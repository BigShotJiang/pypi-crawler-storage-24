from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_core.templates import add_template_directory, setup_templates


def _make_app(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    return create_bluefox_app(settings)


# --- setup_templates ---


def test_setup_templates__creates_environment(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    assert isinstance(env, Environment)
    assert isinstance(env.loader, FileSystemLoader)


def test_setup_templates__autoescape_enabled(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    # select_autoescape returns a callable, not a bool
    assert callable(env.autoescape)
    # HTML templates should be autoescaped
    assert env.autoescape("template.html") is True
    # Plain text should not be autoescaped
    assert env.autoescape("template.txt") is False


# --- add_template_directory ---


def test_add_template_directory__appends_path(monkeypatch, tmp_path):
    app = _make_app(monkeypatch)
    pkg_templates = tmp_path / "templates"
    pkg_templates.mkdir()

    add_template_directory(app, pkg_templates)

    loader = app.state.templates.loader
    assert isinstance(loader, FileSystemLoader)
    assert str(pkg_templates.resolve()) in loader.searchpath


def test_add_template_directory__no_duplicates(monkeypatch, tmp_path):
    app = _make_app(monkeypatch)
    pkg_templates = tmp_path / "templates"
    pkg_templates.mkdir()

    add_template_directory(app, pkg_templates)
    add_template_directory(app, pkg_templates)

    loader = app.state.templates.loader
    count = loader.searchpath.count(str(pkg_templates.resolve()))
    assert count == 1


def test_add_template_directory__creates_env_if_missing(monkeypatch, tmp_path):
    app = _make_app(monkeypatch)
    # Remove the templates env to simulate it not being set up
    del app.state.templates

    pkg_templates = tmp_path / "templates"
    pkg_templates.mkdir()

    add_template_directory(app, pkg_templates)

    assert isinstance(app.state.templates, Environment)
    assert str(pkg_templates.resolve()) in app.state.templates.loader.searchpath


def test_add_template_directory__app_templates_searched_first(monkeypatch, tmp_path):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    monkeypatch.chdir(tmp_path)

    # Create app templates dir
    app_templates = tmp_path / "templates"
    app_templates.mkdir()

    settings = BluefoxSettings()
    app = create_bluefox_app(settings)

    # Add a package templates dir
    pkg_templates = tmp_path / "pkg" / "templates"
    pkg_templates.mkdir(parents=True)
    add_template_directory(app, pkg_templates)

    loader = app.state.templates.loader
    assert loader.searchpath[0] == str(app_templates.resolve())
    assert loader.searchpath[1] == str(pkg_templates.resolve())


def test_template_rendering__from_added_directory(monkeypatch, tmp_path):
    app = _make_app(monkeypatch)

    # Create a template in a package directory
    pkg_templates = tmp_path / "templates"
    pkg_templates.mkdir()
    (pkg_templates / "hello.html").write_text("Hello, {{ name }}!")

    add_template_directory(app, pkg_templates)

    result = app.state.templates.get_template("hello.html").render(name="Bluefox")
    assert result == "Hello, Bluefox!"


def test_template_rendering__app_overrides_package(monkeypatch, tmp_path):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    monkeypatch.chdir(tmp_path)

    # App templates (higher priority)
    app_templates = tmp_path / "templates"
    app_templates.mkdir()
    (app_templates / "greeting.html").write_text("App version: {{ name }}")

    # Package templates (lower priority)
    pkg_templates = tmp_path / "pkg" / "templates"
    pkg_templates.mkdir(parents=True)
    (pkg_templates / "greeting.html").write_text("Package version: {{ name }}")

    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    add_template_directory(app, pkg_templates)

    result = app.state.templates.get_template("greeting.html").render(name="test")
    assert result == "App version: test"
