import importlib
import logging
import sys
import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from bluefox_core.database import BluefoxBase, normalize_database_url
from bluefox_core.discovery import (
    _check_base_inheritance,
    _find_modules,
    _MODEL_PATTERNS,
    discover_models,
)
from bluefox_core.settings import BluefoxSettings


# --- normalize_database_url ---


def test_normalize_database_url__converts_postgresql():
    url = "postgresql://user:pass@localhost:5432/mydb"
    assert normalize_database_url(url) == "postgresql+asyncpg://user:pass@localhost:5432/mydb"


def test_normalize_database_url__preserves_asyncpg():
    url = "postgresql+asyncpg://user:pass@localhost:5432/mydb"
    assert normalize_database_url(url) == url


def test_normalize_database_url__preserves_other_schemes():
    url = "sqlite:///test.db"
    assert normalize_database_url(url) == url


def test_normalize_database_url__empty_string():
    assert normalize_database_url("") == ""


# --- model discovery ---


def test_discover_models__imports_explicit_module():
    settings = BluefoxSettings(MODELS_MODULE="json")
    with patch("bluefox_core.discovery.importlib.import_module") as mock_import:
        discover_models(settings)
        mock_import.assert_called_once_with("json")


def test_discover_models__explicit_module_raises_on_import_error():
    settings = BluefoxSettings(MODELS_MODULE="nonexistent.module")
    with patch(
        "bluefox_core.discovery.importlib.import_module",
        side_effect=ImportError("No module named 'nonexistent'"),
    ):
        with pytest.raises(ImportError):
            discover_models(settings)


# --- convention-based file discovery ---


def test_find_model_modules__finds_models_py(tmp_path, monkeypatch):
    (tmp_path / "models.py").write_text("# models")
    monkeypatch.chdir(tmp_path)
    assert "models" in [m for m, _ in _find_modules(_MODEL_PATTERNS)]


def test_find_model_modules__finds_nested_models(tmp_path, monkeypatch):
    pkg = tmp_path / "myapp"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "models.py").write_text("# models")
    monkeypatch.chdir(tmp_path)
    assert "myapp.models" in [m for m, _ in _find_modules(_MODEL_PATTERNS)]


def test_find_model_modules__empty_when_no_models(tmp_path, monkeypatch):
    (tmp_path / "main.py").write_text("# main")
    monkeypatch.chdir(tmp_path)
    assert [m for m, _ in _find_modules(_MODEL_PATTERNS)] == []


def test_find_model_modules__deduplicates(tmp_path, monkeypatch):
    """app/models.py matches both 'app/models.py' and '*/models.py' patterns."""
    pkg = tmp_path / "app"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "models.py").write_text("# models")
    monkeypatch.chdir(tmp_path)
    modules = [m for m, _ in _find_modules(_MODEL_PATTERNS)]
    assert modules.count("app.models") == 1


def test_discover_models__convention_imports_found_modules(tmp_path, monkeypatch):
    """Convention mode imports discovered model files."""
    pkg = tmp_path / "myapp"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "models.py").write_text(
        "from bluefox_core.database import BluefoxBase\n"
        "class MyModel(BluefoxBase):\n"
        "    __tablename__ = 'test_convention'\n"
        "    __abstract__ = True\n"
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(tmp_path)

    settings = BluefoxSettings(MODELS_MODULE="")
    discover_models(settings)

    assert "myapp.models" in sys.modules


def test_discover_models__convention_skips_bad_imports(tmp_path, monkeypatch):
    """Convention mode silently skips modules that fail to import."""
    (tmp_path / "models.py").write_text("import nonexistent_package_xyz")
    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(tmp_path)

    settings = BluefoxSettings(MODELS_MODULE="")
    discover_models(settings)  # should not raise


# --- base inheritance lint check ---


def test_check_base_inheritance__warns_on_wrong_base(tmp_path, monkeypatch, caplog):
    """Models using DeclarativeBase directly (not BluefoxBase) get a warning."""
    pkg = tmp_path / "badmodels"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "models.py").write_text(
        textwrap.dedent("""\
        from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

        class WrongBase(DeclarativeBase):
            pass

        class BadModel(WrongBase):
            __tablename__ = "bad_table"
            id: Mapped[int] = mapped_column(primary_key=True)
        """)
    )
    monkeypatch.syspath_prepend(tmp_path)

    importlib.import_module("badmodels.models")

    with caplog.at_level(logging.WARNING, logger="bluefox.discovery"):
        _check_base_inheritance("badmodels.models")

    assert any("WrongBase" in msg for msg in caplog.messages)
    assert any("BluefoxBase" in msg for msg in caplog.messages)


def test_check_base_inheritance__silent_for_bluefox_base(caplog):
    """Models inheriting from BluefoxBase should not produce warnings."""
    # The demo module uses BluefoxBase — no warnings expected
    importlib.import_module("bluefox_core.demo.models")

    with caplog.at_level(logging.WARNING, logger="bluefox.discovery"):
        _check_base_inheritance("bluefox_core.demo.models")

    assert not any("BluefoxBase" in msg for msg in caplog.messages)


def test_check_base_inheritance__ignores_non_sqlalchemy_classes(tmp_path, monkeypatch, caplog):
    """Regular classes (not SQLAlchemy models) should be ignored."""
    pkg = tmp_path / "plainmodels"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "models.py").write_text(
        textwrap.dedent("""\
        class PlainClass:
            pass

        class AnotherClass(PlainClass):
            pass
        """)
    )
    monkeypatch.syspath_prepend(tmp_path)
    importlib.import_module("plainmodels.models")

    with caplog.at_level(logging.WARNING, logger="bluefox.discovery"):
        _check_base_inheritance("plainmodels.models")

    assert not caplog.messages


# --- env_template is valid Python ---


def test_env_template_is_valid_python():
    """Verify the env template file is syntactically valid Python."""
    import ast

    template_path = Path(__file__).parent.parent / "bluefox_core" / "migrations" / "env_template.py"
    source = template_path.read_text()
    ast.parse(source)  # raises SyntaxError if invalid
