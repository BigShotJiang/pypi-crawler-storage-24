import httpx

from bluefox_core.app import create_bluefox_app
from bluefox_core.redis import RedisManager
from bluefox_core.settings import BluefoxSettings


def _make_client(app):
    return httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    )


# --- RedisManager unit tests ---


def test_redis_manager__no_client_when_url_empty(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    manager = RedisManager(settings)
    assert manager.client is None


def test_redis_manager__creates_client_when_url_set(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("REDIS_URL", "redis://localhost:6379/0")
    settings = BluefoxSettings()
    manager = RedisManager(settings)
    assert manager.client is not None


async def test_redis_manager__startup_noop_without_client(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    manager = RedisManager(settings)
    # Should not raise
    await manager.startup()


async def test_redis_manager__shutdown_noop_without_client(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    manager = RedisManager(settings)
    # Should not raise
    await manager.shutdown()


# --- get_redis dependency ---


async def test_get_redis__503_when_not_configured(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)

    from fastapi import APIRouter, Depends

    from bluefox_core.redis import get_redis

    test_router = APIRouter()

    @test_router.get("/test-redis")
    async def test_endpoint(redis=Depends(get_redis)):
        return {"ok": True}

    app.include_router(test_router)

    async with _make_client(app) as client:
        response = await client.get("/test-redis")
    assert response.status_code == 503


# --- App state ---


def test_app_state__redis_is_redis_manager(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    assert isinstance(app.state.redis, RedisManager)
