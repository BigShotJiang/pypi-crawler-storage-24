from bluefox_core.settings import BluefoxSettings


def test_bluefox_settings__loads_defaults(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    assert settings.APP_NAME == "bluefox-app"
    assert settings.ENVIRONMENT == "development"
    assert settings.DEBUG is False
    assert settings.DATABASE_URL == ""
    assert settings.REDIS_URL == ""
    assert settings.SECRET_KEY == "change-me-in-production"
    assert settings.LOG_LEVEL == "INFO"


def test_bluefox_settings__reads_from_env(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql+asyncpg://localhost/testdb")
    settings = BluefoxSettings()
    assert settings.DATABASE_URL == "postgresql+asyncpg://localhost/testdb"


def test_bluefox_settings__empty_database_url_means_no_db(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    settings = BluefoxSettings()
    assert settings.has_database is False


def test_bluefox_settings__has_database_when_url_set(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql+asyncpg://localhost/mydb")
    settings = BluefoxSettings()
    assert settings.has_database is True


def test_bluefox_settings__is_production__matches_environment(monkeypatch):
    monkeypatch.setenv("ENVIRONMENT", "production")
    settings = BluefoxSettings()
    assert settings.is_production is True
    assert settings.is_development is False


def test_bluefox_settings__is_development__matches_environment():
    settings = BluefoxSettings()
    assert settings.is_development is True
    assert settings.is_production is False


def test_bluefox_settings__has_redis_when_url_set(monkeypatch):
    monkeypatch.setenv("REDIS_URL", "redis://localhost:6379/0")
    settings = BluefoxSettings()
    assert settings.has_redis is True


def test_bluefox_settings__has_redis_false_when_empty(monkeypatch):
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    assert settings.has_redis is False


def test_bluefox_settings__extra_ignore_allows_unknown_vars(monkeypatch):
    monkeypatch.setenv("UNKNOWN_VAR", "some-value")
    settings = BluefoxSettings()
    assert settings.APP_NAME == "bluefox-app"  # no error raised


def test_bluefox_settings__subclass_adds_custom_fields(monkeypatch):
    class AppSettings(BluefoxSettings):
        STRIPE_KEY: str = ""

    monkeypatch.setenv("STRIPE_KEY", "sk_test_123")
    settings = AppSettings()
    assert settings.STRIPE_KEY == "sk_test_123"
    assert settings.APP_NAME == "bluefox-app"


def test_bluefox_settings__case_sensitive(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("database_url", "postgresql+asyncpg://localhost/lowercase")
    settings = BluefoxSettings()
    assert settings.DATABASE_URL == ""  # lowercase not picked up

    monkeypatch.setenv("DATABASE_URL", "postgresql+asyncpg://localhost/uppercase")
    settings = BluefoxSettings()
    assert settings.DATABASE_URL == "postgresql+asyncpg://localhost/uppercase"
