import json
import uuid

import httpx

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings


def _make_client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")


async def test_request_id_middleware__generates_uuid_when_missing():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/health")
    request_id = response.headers["x-request-id"]
    # Should be a valid UUID4
    parsed = uuid.UUID(request_id, version=4)
    assert str(parsed) == request_id


async def test_request_id_middleware__preserves_client_id():
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/health", headers={"X-Request-ID": "my-custom-id"})
    assert response.headers["x-request-id"] == "my-custom-id"


async def test_request_id_middleware__binds_to_log_context(capsys):
    settings = BluefoxSettings(ENVIRONMENT="production")
    app = create_bluefox_app(settings)

    from fastapi import APIRouter
    test_router = APIRouter()

    @test_router.get("/log-test")
    async def log_test():
        from bluefox_core.log import logger
        logger.info("middleware log test")
        return {"ok": True}

    app.include_router(test_router)

    async with _make_client(app) as client:
        response = await client.get("/log-test", headers={"X-Request-ID": "traced-id-456"})

    assert response.status_code == 200
    captured = capsys.readouterr()
    lines = [line for line in captured.err.strip().splitlines() if "middleware log test" in line]
    assert len(lines) >= 1
    parsed = json.loads(lines[0])
    assert parsed["request_id"] == "traced-id-456"
