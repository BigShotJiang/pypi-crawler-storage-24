import asyncio
import json
import logging

import structlog

from bluefox_core.log import bind_request_context, clear_request_context, configure_logging, logger
from bluefox_core.settings import BluefoxSettings


def test_logger__exists_and_is_callable():
    assert callable(logger.info)
    assert callable(logger.error)
    assert callable(logger.warning)
    assert callable(logger.debug)


def test_configure_logging__development_uses_console(capsys):
    settings = BluefoxSettings(ENVIRONMENT="development")
    configure_logging(settings)

    structlog.get_logger().info("dev test message")

    captured = capsys.readouterr()
    assert "dev test message" in captured.err
    # Console renderer output is NOT valid JSON
    for line in captured.err.strip().splitlines():
        try:
            json.loads(line)
            assert False, f"Expected non-JSON output but got valid JSON: {line}"
        except (json.JSONDecodeError, ValueError):
            pass


def test_configure_logging__production_uses_json(capsys):
    settings = BluefoxSettings(ENVIRONMENT="production")
    configure_logging(settings)

    structlog.get_logger().info("prod test message")

    captured = capsys.readouterr()
    assert "prod test message" in captured.err
    # At least one line should be valid JSON
    lines = [line for line in captured.err.strip().splitlines() if line.strip()]
    parsed = json.loads(lines[-1])
    assert parsed["event"] == "prod test message"
    assert "timestamp" in parsed


def test_logger__includes_bound_context(capsys):
    settings = BluefoxSettings(ENVIRONMENT="production")
    configure_logging(settings)
    clear_request_context()

    bind_request_context("abc-123")
    structlog.get_logger().info("with context")

    captured = capsys.readouterr()
    lines = [line for line in captured.err.strip().splitlines() if line.strip()]
    parsed = json.loads(lines[-1])
    assert parsed["request_id"] == "abc-123"

    clear_request_context()


async def test_bind_request_context__scopes_to_current_task(capsys):
    settings = BluefoxSettings(ENVIRONMENT="production")
    configure_logging(settings)
    clear_request_context()

    results = {}

    async def task_a():
        bind_request_context("task-a-id")
        await asyncio.sleep(0.01)
        structlog.get_logger().info("from task a")

    async def task_b():
        bind_request_context("task-b-id")
        await asyncio.sleep(0.01)
        structlog.get_logger().info("from task b")

    await asyncio.gather(task_a(), task_b())

    captured = capsys.readouterr()
    lines = [line for line in captured.err.strip().splitlines() if line.strip()]

    for line in lines:
        parsed = json.loads(line)
        if parsed["event"] == "from task a":
            results["a"] = parsed["request_id"]
        elif parsed["event"] == "from task b":
            results["b"] = parsed["request_id"]

    assert results["a"] == "task-a-id"
    assert results["b"] == "task-b-id"

    clear_request_context()
