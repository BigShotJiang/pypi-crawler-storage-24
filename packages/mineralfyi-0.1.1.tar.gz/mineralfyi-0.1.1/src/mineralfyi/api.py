"""HTTP API client for mineralfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install mineralfyi[api]``

Usage::

    from mineralfyi.api import MineralFYI

    with MineralFYI() as api:
        items = api.list_classes()
        detail = api.get_classe("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class MineralFYI:
    """API client for the mineralfyi.com REST API.

    Provides typed access to all mineralfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://mineralfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://mineralfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_classes(self, **params: Any) -> dict[str, Any]:
        """List all classes."""
        return self._get("/api/v1/classes/", **params)

    def get_classe(self, slug: str) -> dict[str, Any]:
        """Get classe by slug."""
        return self._get(f"/api/v1/classes/" + slug + "/")

    def list_comparisons(self, **params: Any) -> dict[str, Any]:
        """List all comparisons."""
        return self._get("/api/v1/comparisons/", **params)

    def get_comparison(self, slug: str) -> dict[str, Any]:
        """Get comparison by slug."""
        return self._get(f"/api/v1/comparisons/" + slug + "/")

    def list_countries(self, **params: Any) -> dict[str, Any]:
        """List all countries."""
        return self._get("/api/v1/countries/", **params)

    def get_country(self, slug: str) -> dict[str, Any]:
        """Get country by slug."""
        return self._get(f"/api/v1/countries/" + slug + "/")

    def list_crystal_systems(self, **params: Any) -> dict[str, Any]:
        """List all crystal systems."""
        return self._get("/api/v1/crystal-systems/", **params)

    def get_crystal_system(self, slug: str) -> dict[str, Any]:
        """Get crystal system by slug."""
        return self._get(f"/api/v1/crystal-systems/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_glossary(self, **params: Any) -> dict[str, Any]:
        """List all glossary."""
        return self._get("/api/v1/glossary/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/glossary/" + slug + "/")

    def list_glossary_categories(self, **params: Any) -> dict[str, Any]:
        """List all glossary categories."""
        return self._get("/api/v1/glossary-categories/", **params)

    def get_glossary_category(self, slug: str) -> dict[str, Any]:
        """Get glossary category by slug."""
        return self._get(f"/api/v1/glossary-categories/" + slug + "/")

    def list_guide_series(self, **params: Any) -> dict[str, Any]:
        """List all guide series."""
        return self._get("/api/v1/guide-series/", **params)

    def get_guide_sery(self, slug: str) -> dict[str, Any]:
        """Get guide sery by slug."""
        return self._get(f"/api/v1/guide-series/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/guides/" + slug + "/")

    def list_localities(self, **params: Any) -> dict[str, Any]:
        """List all localities."""
        return self._get("/api/v1/localities/", **params)

    def get_locality(self, slug: str) -> dict[str, Any]:
        """Get locality by slug."""
        return self._get(f"/api/v1/localities/" + slug + "/")

    def list_minerals(self, **params: Any) -> dict[str, Any]:
        """List all minerals."""
        return self._get("/api/v1/minerals/", **params)

    def get_mineral(self, slug: str) -> dict[str, Any]:
        """Get mineral by slug."""
        return self._get(f"/api/v1/minerals/" + slug + "/")

    def list_rock_types(self, **params: Any) -> dict[str, Any]:
        """List all rock types."""
        return self._get("/api/v1/rock-types/", **params)

    def get_rock_type(self, slug: str) -> dict[str, Any]:
        """Get rock type by slug."""
        return self._get(f"/api/v1/rock-types/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> MineralFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
