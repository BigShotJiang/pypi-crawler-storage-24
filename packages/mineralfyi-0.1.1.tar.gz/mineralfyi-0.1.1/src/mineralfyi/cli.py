"""Command-line interface for mineralfyi."""

from __future__ import annotations

import json

import typer

from mineralfyi.api import MineralFYI

app = typer.Typer(help="MineralFYI — Mineral encyclopedia and crystal systems API client.")


@app.command()
def search(query: str) -> None:
    """Search mineralfyi.com."""
    with MineralFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
