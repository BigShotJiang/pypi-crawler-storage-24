"""Python API client for mineralfyi.com."""

__version__ = "0.1.0"
