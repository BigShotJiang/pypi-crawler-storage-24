"""Hashward scheme handlers."""
