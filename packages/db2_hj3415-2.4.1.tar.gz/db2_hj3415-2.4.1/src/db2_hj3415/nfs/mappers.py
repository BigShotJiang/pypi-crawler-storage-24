from __future__ import annotations

from typing import Any, cast

from contracts_hj3415.common import make_empty_envelope_meta, make_nfs_envelope
from contracts_hj3415.common.envelope import NfsEnvelopeDTO
from contracts_hj3415.nfs.payloads import NfsPayloadDTO
from db2_hj3415.common.types import MongoDoc
from db2_hj3415.nfs.domain import (
    EndpointEnum,
    NfsLatestDoc,
    NfsSnapshotDoc,
    build_latest_doc,
    build_snapshot_doc,
)


def envelope_to_latest_doc(env: NfsEnvelopeDTO) -> NfsLatestDoc:
    nfs_payload = cast(NfsPayloadDTO, cast(object, env["payload"]))
    meta = nfs_payload["meta"]
    contents = nfs_payload["contents"]

    endpoint = meta.get("endpoint")
    labels = meta.get("labels")

    return build_latest_doc(
        code=env["key"],
        asof=env["asof"],
        endpoint=EndpointEnum(endpoint),
        contents=contents,
        labels={} if labels is None else labels,
    )


def envelope_to_snapshot_doc(env: NfsEnvelopeDTO) -> NfsSnapshotDoc:
    nfs_payload = cast(NfsPayloadDTO, cast(object, env["payload"]))
    meta = nfs_payload["meta"]
    contents = nfs_payload["contents"]

    endpoint = meta.get("endpoint")
    labels = meta.get("labels")

    return build_snapshot_doc(
        code=env["key"],
        asof=env["asof"],
        endpoint=EndpointEnum(endpoint),
        contents=contents,
        labels={} if labels is None else labels,
    )


def mongo_to_latest_doc(mongo_doc: MongoDoc) -> NfsLatestDoc:
    return {
        "_id": str(mongo_doc["_id"]),  # pyright: ignore[reportAny]
        "code": str(mongo_doc["code"]),  # pyright: ignore[reportAny]
        "asof": mongo_doc["asof"],
        "endpoint": EndpointEnum(mongo_doc["endpoint"]),
        "contents": dict[str, Any](mongo_doc["contents"]),  # pyright: ignore[reportAny, reportExplicitAny]
        "contents_hash": str(mongo_doc["contents_hash"]),  # pyright: ignore[reportAny]
        "labels": dict[str, Any](mongo_doc["labels"]),  # pyright: ignore[reportAny, reportExplicitAny]
    }

def mongo_to_snapshot_doc(mongo_doc: MongoDoc) -> NfsSnapshotDoc:
    return {
        "code": str(mongo_doc["code"]),  # pyright: ignore[reportAny]
        "asof": mongo_doc["asof"],
        "endpoint": EndpointEnum(mongo_doc["endpoint"]),
        "contents": dict[str, Any](mongo_doc["contents"]),  # pyright: ignore[reportAny, reportExplicitAny]
        "contents_hash": str(mongo_doc["contents_hash"]),  # pyright: ignore[reportAny]
        "labels": dict[str, Any](mongo_doc["labels"]),  # pyright: ignore[reportAny, reportExplicitAny]
    }


def latest_doc_to_envelope_dto(doc: NfsLatestDoc) -> NfsEnvelopeDTO:
    return make_nfs_envelope(
        code=doc["code"],
        asof=doc["asof"],
        labels=doc["labels"],
        endpoint=doc["endpoint"].value,
        contents=doc["contents"],
        meta=make_empty_envelope_meta(source="scraper2"),
    )
