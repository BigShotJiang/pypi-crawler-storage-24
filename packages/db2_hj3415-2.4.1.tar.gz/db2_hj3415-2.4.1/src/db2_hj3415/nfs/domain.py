# db2_hj3415/nfs/domain.py
from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import TypedDict

from db2_hj3415.common.hash_utils import stable_sha256
from db2_hj3415.common.types import ContentsMap, LabelsMap

LATEST_COL = "nfs_latest"
SNAPSHOTS_COL = "nfs_snapshots"


class EndpointEnum(StrEnum):
    C101 = "c101"
    C103 = "c103"
    C104 = "c104"
    C106 = "c106"
    C108 = "c108"


class NfsLatestDoc(TypedDict):
    _id: str
    code: str
    asof: datetime
    endpoint: EndpointEnum
    contents: ContentsMap
    contents_hash: str
    labels: LabelsMap


class NfsSnapshotDoc(TypedDict):
    code: str
    asof: datetime
    endpoint: EndpointEnum
    contents: ContentsMap
    contents_hash: str
    labels: LabelsMap


def clean_code(code: str) -> str:
    """code 정규화(공백 제거)."""
    return str(code).strip()


def latest_id(endpoint: EndpointEnum, code: str) -> str:
    """latest _id 규칙: '{endpoint}:{code}'"""
    return f"{endpoint.value}:{clean_code(code)}"


def compute_contents_hash(contents: ContentsMap) -> str:
    return stable_sha256(contents)


def build_latest_doc(
    *,
    code: str,
    asof: datetime,
    endpoint: EndpointEnum,
    contents: ContentsMap,
    labels: LabelsMap,
) -> NfsLatestDoc:
    """latest 문서 빌더(규칙: _id, contents_hash 포함)."""
    code_s = clean_code(code)
    if not code_s:
        raise ValueError("code must be non-empty")

    return {
        "_id": latest_id(endpoint, code_s),
        "code": code_s,
        "asof": asof,
        "endpoint": endpoint,
        "contents": contents,
        "contents_hash": compute_contents_hash(contents),
        "labels": labels,
    }


def build_snapshot_doc(
    *,
    code: str,
    asof: datetime,
    endpoint: EndpointEnum,
    contents: ContentsMap,
    labels: LabelsMap,
) -> NfsSnapshotDoc:
    """snapshot 문서 빌더(contents_hash 포함)."""
    code_s = clean_code(code)
    if not code_s:
        raise ValueError("code must be non-empty")

    return {
        "code": code_s,
        "asof": asof,
        "endpoint": endpoint,
        "contents": contents,
        "contents_hash": compute_contents_hash(contents),
        "labels": labels,
    }
