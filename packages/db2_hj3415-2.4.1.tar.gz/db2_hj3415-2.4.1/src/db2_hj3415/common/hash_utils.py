# db2_hj3415/common/hash_utils.py
from __future__ import annotations

import hashlib
import json

from db2_hj3415.common.types import ContentsMap


def stable_sha256(value: ContentsMap) -> str:
    """
    dict/list 등 JSON-serializable 객체를 정렬된 JSON 문자열로 만든 뒤 sha256 해시를 반환.
    (기존 구현이 있으면 그대로 사용)
    """
    s = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(s.encode("utf-8")).hexdigest()
