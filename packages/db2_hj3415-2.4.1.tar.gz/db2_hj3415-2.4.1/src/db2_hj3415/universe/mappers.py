from __future__ import annotations

from typing import Any, cast

from contracts_hj3415.common import make_empty_envelope_meta, make_universe_envelope
from contracts_hj3415.common.envelope import UniverseEnvelopeDTO
from contracts_hj3415.universe.payloads import UniversePayloadDTO
from db2_hj3415.common.types import MongoDoc
from db2_hj3415.universe.domain import (
    SourceEnum,
    UniverseEnum,
    UniverseLatestDoc,
    UniverseSnapshotDoc,
    build_latest_doc,
    build_snapshot_doc,
)


def envelope_to_latest_doc(env: UniverseEnvelopeDTO) -> UniverseLatestDoc:
    universe_payload = cast(UniversePayloadDTO, cast(object, env["payload"]))
    meta = universe_payload["meta"]
    contents = universe_payload["contents"]

    source: str = meta.get("source")

    return build_latest_doc(
        universe=UniverseEnum(env["key"]),
        asof=env["asof"],
        source=SourceEnum(source),
        contents=contents,
    )


def envelope_to_snapshot_doc(env: UniverseEnvelopeDTO) -> UniverseSnapshotDoc:
    universe_payload = cast(UniversePayloadDTO, cast(object, env["payload"]))
    meta = universe_payload["meta"]
    contents = universe_payload["contents"]

    source: str = meta.get("source")

    return build_snapshot_doc(
        universe=UniverseEnum(env["key"]),
        asof=env["asof"],
        source=SourceEnum(source),
        contents=contents,
    )


def mongo_to_latest_doc(mongo_doc: MongoDoc) -> UniverseLatestDoc:
    return {
        "_id": str(mongo_doc["_id"]),  # pyright: ignore[reportAny]
        "universe": UniverseEnum(mongo_doc["universe"]),
        "asof": mongo_doc["asof"],
        "source": SourceEnum(mongo_doc["source"]),
        "contents": dict[str, Any](mongo_doc["contents"]),  # pyright: ignore[reportAny, reportExplicitAny]
    }

def mongo_to_snapshot_doc(mongo_doc: MongoDoc) -> UniverseSnapshotDoc:
    return {
        "universe": UniverseEnum(mongo_doc["universe"]),
        "asof": mongo_doc["asof"],
        "source": SourceEnum(mongo_doc["source"]),
        "contents": dict[str, Any](mongo_doc["contents"]),  # pyright: ignore[reportAny, reportExplicitAny]
    }

def latest_doc_to_envelope(doc: UniverseLatestDoc) -> UniverseEnvelopeDTO:
    return make_universe_envelope(
        universe=doc["universe"].value,
        asof=doc["asof"],
        source=doc["source"].value,
        contents=doc["contents"],
        meta=make_empty_envelope_meta(source="krx"),
    )
