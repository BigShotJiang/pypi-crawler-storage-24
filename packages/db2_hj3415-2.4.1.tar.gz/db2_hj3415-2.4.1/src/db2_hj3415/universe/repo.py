from __future__ import annotations

from collections.abc import Sequence
from typing import cast

from db2_hj3415.common.types import MongoDoc
from db2_hj3415.universe.mappers import mongo_to_latest_doc, mongo_to_snapshot_doc
from pymongo import ASCENDING, DESCENDING
from pymongo.asynchronous.database import AsyncDatabase

from .domain import (
    LATEST_COL,
    SNAPSHOTS_COL,
    UniverseEnum,
    UniverseItem,
    UniverseLatestDoc,
    UniverseSnapshotDoc,
    latest_id,
)


async def ensure_indexes(
    db: AsyncDatabase[MongoDoc],
    *,
    snapshot_ttl_days: int | None,
) -> None:
    """universe latest/snapshots 인덱스를 보장한다."""
    latest = db.get_collection(LATEST_COL)
    snapshots = db.get_collection(SNAPSHOTS_COL)

    # latest: _id=universe 가 유니크, 보조 조회용
    _ = await latest.create_index([("universe", ASCENDING)])
    _ = await latest.create_index([("asof", DESCENDING)])

    # snapshots: universe 타임라인 조회
    _ = await snapshots.create_index([("universe", ASCENDING), ("asof", DESCENDING)])

    if snapshot_ttl_days is not None:
        expire_seconds = int(snapshot_ttl_days) * 24 * 60 * 60
        _ = await snapshots.create_index(
            [("asof", ASCENDING)],
            expireAfterSeconds=expire_seconds,
            name="ttl_asof",
        )


# -----------------------------------------------------------------------------
# Writes (doc-only)
# -----------------------------------------------------------------------------


async def upsert_latest_doc(
    db: AsyncDatabase[MongoDoc],
    *,
    doc: UniverseLatestDoc,
) -> UniverseLatestDoc:
    """latest 문서를 _id 기준으로 upsert한다."""
    col = db.get_collection(LATEST_COL)
    _ = await col.replace_one({"_id": doc["_id"]}, doc, upsert=True)
    return doc


async def insert_snapshot_doc(
    db: AsyncDatabase[MongoDoc],
    *,
    doc: UniverseSnapshotDoc,
) -> UniverseSnapshotDoc:
    """snapshot 문서를 insert한다(멱등/중복 방지는 상위에서 결정)."""
    col = db.get_collection(SNAPSHOTS_COL)
    _ = await col.insert_one(doc)
    return doc


# -----------------------------------------------------------------------------
# Reads
# -----------------------------------------------------------------------------


async def get_latest(
    db: AsyncDatabase[MongoDoc],
    *,
    universe: str,
) -> UniverseLatestDoc | None:
    """universe latest 문서를 조회한다."""
    col = db.get_collection(LATEST_COL)
    _id = latest_id(UniverseEnum(universe))
    mongo_doc = await col.find_one({"_id": _id})
    if not mongo_doc:
        return None
    return mongo_to_latest_doc(mongo_doc)


async def list_snapshots(
    db: AsyncDatabase[MongoDoc],
    *,
    universe: str,
    limit: int = 30,
    desc: bool = True,
) -> list[UniverseSnapshotDoc]:
    """universe snapshot 이력을 조회한다."""
    u = UniverseEnum(universe)  # invalid면 ValueError

    order = DESCENDING if desc else ASCENDING
    col = db.get_collection(SNAPSHOTS_COL)
    cur = col.find({"universe": str(u)}).sort("asof", order).limit(limit)
    return [mongo_to_snapshot_doc(mongo_doc) async for mongo_doc in cur]


def _extract_codes(items: Sequence[UniverseItem]) -> list[str]:
    codes: list[str] = []
    for it in items:
        code = (it.get("code") or "").strip()
        if code:
            codes.append(code)
    return codes


async def list_latest_universe_codes(
    db: AsyncDatabase[MongoDoc], *, universe: str
) -> list[str]:
    doc = await get_latest(db, universe=universe)
    if not doc:
        return []
    items = doc["contents"].get("items")
    return _extract_codes(cast(Sequence[UniverseItem], items))
