from __future__ import annotations

from typing import cast

from contracts_hj3415.analysis.payloads import AnalysisPayloadDTO
from contracts_hj3415.common import make_analysis_envelope, make_empty_envelope_meta
from contracts_hj3415.common.envelope import AnalysisEnvelopeDTO
from db2_hj3415.analysis.domain import (
    AnalysisLatestDoc,
    AnalysisServiceEnum,
    AnalysisSnapshotDoc,
    EndpointEnum,
    build_latest_doc,
    build_snapshot_doc,
)
from db2_hj3415.common.types import MongoDoc


def envelope_to_latest_doc(env: AnalysisEnvelopeDTO) -> AnalysisLatestDoc:
    analysis_payload = cast(AnalysisPayloadDTO, cast(object, env["payload"]))
    meta = analysis_payload["meta"]
    contents = analysis_payload["contents"]

    service = meta.get("service")
    endpoint = meta.get("endpoint")

    return build_latest_doc(
        code=env["key"],
        asof=env["asof"],
        service=AnalysisServiceEnum(service),
        endpoint=EndpointEnum(endpoint) if endpoint is not None else None,
        contents=contents,
    )


def envelope_to_snapshot_doc(env: AnalysisEnvelopeDTO) -> AnalysisSnapshotDoc:
    analysis_payload = cast(AnalysisPayloadDTO, cast(object, env["payload"]))
    meta = analysis_payload["meta"]
    contents = analysis_payload["contents"]

    service = meta.get("service")
    endpoint = meta.get("endpoint")

    return build_snapshot_doc(
        code=env["key"],
        asof=env["asof"],
        service=AnalysisServiceEnum(service),
        endpoint=EndpointEnum(endpoint) if endpoint is not None else None,
        contents=contents,
    )


def latest_doc_to_envelope_dto(doc: AnalysisLatestDoc) -> AnalysisEnvelopeDTO:
    ep = "" if doc["endpoint"] is None else doc["endpoint"].value

    return make_analysis_envelope(
        code=doc["code"],
        asof=doc["asof"],
        service=doc["service"].value,
        endpoint=ep,
        contents=doc["contents"],
        meta=make_empty_envelope_meta(source="analyser2"),
    )


def _coerce_service(v: object) -> AnalysisServiceEnum:
    return v if isinstance(v, AnalysisServiceEnum) else AnalysisServiceEnum(str(v))


def _coerce_endpoint(v: object | None) -> EndpointEnum | None:
    if v is None:
        return None
    return v if isinstance(v, EndpointEnum) else EndpointEnum(str(v))


def mongo_to_latest_doc(mongo_doc: MongoDoc) -> AnalysisLatestDoc:
    """
    DB에서 읽은 primitive dict(MongoDoc)을
    AnalysisLatestDoc(Enums 포함)으로 복원한다.
    """
    d = dict(mongo_doc)

    # Enum 복원
    d["service"] = _coerce_service(d.get("service"))
    d["endpoint"] = _coerce_endpoint(d.get("endpoint"))

    return cast(AnalysisLatestDoc, cast(object, d))


def mongo_to_snapshot_doc(mongo_doc: MongoDoc) -> AnalysisSnapshotDoc:
    """
    DB에서 읽은 primitive dict(MongoDoc)을
    AnalysisSnapshotDoc(Enums 포함)으로 복원한다.
    """
    d = dict(mongo_doc)

    # Enum 복원
    d["service"] = _coerce_service(d.get("service"))
    d["endpoint"] = _coerce_endpoint(d.get("endpoint"))

    return cast(AnalysisSnapshotDoc, cast(object, d))
