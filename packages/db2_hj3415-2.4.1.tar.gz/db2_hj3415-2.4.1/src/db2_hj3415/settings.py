# db2_hj3415/settings.py
from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=True,
    )

    MONGO_URI: str = "mongodb://localhost:27017"
    DB_NAME: str = "hj3415"

    MONGO_CONNECT_TIMEOUT_MS: int = 5_000
    MONGO_SERVER_SELECTION_TIMEOUT_MS: int = 5_000

    SNAPSHOT_TTL_DAYS: int | None = 730

    @property
    def snapshot_ttl_enabled(self) -> bool:
        return self.SNAPSHOT_TTL_DAYS is not None and self.SNAPSHOT_TTL_DAYS > 0


@lru_cache
def get_settings() -> Settings:
    return Settings()
