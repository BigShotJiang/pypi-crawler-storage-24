# Copyright 2026 Valuein LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""HTTP transport layer for the Valuein SDK.

Wraps httpx with:
- Bearer token auth on every request
- 30s connect / 120s read timeouts
- Retry with exponential backoff + jitter (3 attempts) on transient errors
- Gateway HTTP status codes mapped to the custom exception hierarchy
"""

from __future__ import annotations

import logging
import random
import time
import warnings
from typing import IO

import httpx

from .exceptions import (
    ValueinAPIError,
    ValueinAuthError,
    ValueinNotFoundError,
    ValueinPlanError,
    ValueinRateLimitError,
)

logger = logging.getLogger("valuein_sdk")

_CONNECT_TIMEOUT = 30.0
_READ_TIMEOUT = 120.0  # Generous overhead for large Parquet streams
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0

_RETRYABLE_STATUS = frozenset({429, 502, 503, 504})


def _backoff(attempt: int) -> float:
    """Return exponential backoff delay with jitter (0-indexed attempt)."""
    return _RETRY_BASE_DELAY * (2**attempt) + random.uniform(0.0, 0.5)


def _raise_for_status(response: httpx.Response) -> None:
    """Map gateway HTTP status codes to Valuein exceptions."""
    code = response.status_code
    # Capture ID from X-Request-ID or Cloudflare Ray
    request_id = response.headers.get("X-Request-ID") or response.headers.get("CF-Ray")

    if code == 401:
        raise ValueinAuthError("Invalid API key. Check valuein.biz/portal.", request_id=request_id)

    if code == 402:
        raise ValueinAuthError("Account suspended — payment required.", request_id=request_id)

    if code == 403:
        body = response.text.lower() if hasattr(response, "text") else ""
        if any(word in body for word in ["plan", "upgrade", "full"]):
            raise ValueinPlanError(
                "This resource requires a Full Dataset plan.", request_id=request_id
            )
        # Added request_id here for consistency
        raise ValueinAuthError("API token has been revoked.", request_id=request_id)

    if code in (400, 404):
        try:
            url_str = str(response.url)
        except RuntimeError:
            url_str = "(unknown)"
        raise ValueinNotFoundError(f"Resource not found: {url_str}", request_id=request_id)

    if code == 429:
        retry_after = response.headers.get("Retry-After")
        wait_sec = int(retry_after) if retry_after and retry_after.isdigit() else None
        msg = f"Rate limited. Retry after {wait_sec}s." if wait_sec else "Rate limited."
        raise ValueinRateLimitError(msg, retry_after=wait_sec, request_id=request_id)

    if code >= 500:
        raise ValueinAPIError(
            f"Gateway server error (HTTP {code}).", status_code=code, request_id=request_id
        )

    if not (200 <= code < 300):
        raise ValueinAPIError(f"Unexpected HTTP {code}.", status_code=code, request_id=request_id)


class Transport:
    """Authenticated HTTP client for the Valuein gateway."""

    def __init__(self, api_key: str, gateway_url: str) -> None:
        self._gateway_url = gateway_url.rstrip("/")

        # Defensive HTTP/2 configuration
        use_http2 = False
        try:
            import h2  # noqa: F401

            use_http2 = True
        except ImportError:
            warnings.warn(
                "The 'h2' package is not installed. Valuein SDK is falling back to HTTP/1.1. "
                "For faster data downloads, install the SDK with HTTP/2 support: "
                "`pip install valuein-sdk` (or `pip install httpx[http2]`).",
                stacklevel=2,
            )

        # We use a persistent Client to benefit from connection pooling
        self._client = httpx.Client(
            base_url=self._gateway_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=httpx.Timeout(
                connect=_CONNECT_TIMEOUT, read=_READ_TIMEOUT, write=30.0, pool=30.0
            ),
            http2=use_http2,
        )

    def get(self, path: str) -> httpx.Response:
        """Standard GET for small JSON payloads (manifests, health)."""
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.get(path)

                if response.status_code not in _RETRYABLE_STATUS:
                    _raise_for_status(response)
                    return response

                # Trigger retry logic for 502/503/etc. by throwing the exception
                _raise_for_status(response)

            except (ValueinAuthError, ValueinPlanError, ValueinNotFoundError):
                # Hard failures should immediately bubble up to the user
                raise
            except (ValueinRateLimitError, ValueinAPIError, httpx.TimeoutException) as exc:
                last_exc = exc
                delay = getattr(exc, "retry_after", None) or _backoff(attempt)
                logger.warning("Transient error on %s; retrying in %.1fs", path, delay)
                time.sleep(delay)
            except httpx.ConnectError as exc:
                raise ConnectionError(f"Could not reach {self._gateway_url}.") from exc

        raise ValueinAPIError(
            f"Request failed after {_MAX_RETRIES} attempts: {last_exc}"
        ) from last_exc

    def download_to_file(self, path: str, dest_file: IO[bytes]) -> None:
        """Stream a large response directly to an open file object.

        This prevents OOM crashes by never buffering the entire file in RAM.
        If a retryable error interrupts the stream, it resets the file pointer
        and tries again safely.
        """
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                # CRITICAL: Reset file pointer to 0. If this is attempt #2 after a
                # mid-stream failure, we must overwrite the corrupted partial data.
                dest_file.seek(0)
                dest_file.truncate()

                with self._client.stream("GET", path) as response:
                    # FIXED: If the gateway sends an error (like a 403 or 503), we MUST
                    # call response.read() to load the error body into memory before
                    # we pass it to _raise_for_status, otherwise httpx throws a ResponseNotRead error.
                    if response.status_code >= 400:
                        response.read()

                    if response.status_code not in _RETRYABLE_STATUS:
                        _raise_for_status(response)

                        # Stream in 64KB chunks directly to the file
                        for chunk in response.iter_bytes(chunk_size=65536):
                            dest_file.write(chunk)

                        # Ensure OS flushes buffer to disk before DuckDB tries to read it
                        dest_file.flush()
                        return

                    # Trigger retry logic for 502/503/etc.
                    _raise_for_status(response)

            except (ValueinAuthError, ValueinPlanError, ValueinNotFoundError):
                raise
            except (
                ValueinRateLimitError,
                ValueinAPIError,
                httpx.ReadError,
                httpx.TimeoutException,
            ) as exc:
                last_exc = exc
                delay = getattr(exc, "retry_after", None) or _backoff(attempt)
                logger.warning("Stream interrupted on %s; retrying in %.1fs", path, delay)
                time.sleep(delay)
            except httpx.ConnectError as exc:
                raise ConnectionError(f"Could not reach {self._gateway_url}.") from exc

        raise ValueinAPIError(
            f"Download failed after {_MAX_RETRIES} attempts: {last_exc}"
        ) from last_exc

    def close(self) -> None:
        """Release connection pool resources."""
        self._client.close()

    def __enter__(self) -> Transport:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
