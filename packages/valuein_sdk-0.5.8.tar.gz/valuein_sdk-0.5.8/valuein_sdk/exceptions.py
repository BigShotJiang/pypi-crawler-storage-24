# Copyright 2026 Valuein LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Custom exception hierarchy for the Valuein SDK."""

from __future__ import annotations


class ValueinError(Exception):
    """Base class for all Valuein SDK errors."""

    def __init__(self, message: str, request_id: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.request_id = request_id

    def __str__(self) -> str:
        base = self.message
        if self.request_id:
            base += f" [Request ID: {self.request_id}]"
        return base


class ValueinAuthError(ValueinError):
    """Raised when the API token is invalid, expired, or revoked (HTTP 401/403)."""


class ValueinPlanError(ValueinError):
    """Raised when the requested resource requires a higher-tier plan (HTTP 403)."""


class ValueinNotFoundError(ValueinError):
    """Raised when a requested resource or table does not exist (HTTP 404)."""


class ValueinRateLimitError(ValueinError):
    """Raised when the gateway returns HTTP 429 (Too Many Requests)."""

    def __init__(
        self, message: str, retry_after: int | None = None, request_id: str | None = None
    ) -> None:
        super().__init__(message, request_id=request_id)
        self.retry_after = retry_after


class ValueinAPIError(ValueinError):
    """Raised for unexpected server-side errors (HTTP 5xx)."""

    def __init__(
        self, message: str, status_code: int | None = None, request_id: str | None = None
    ) -> None:
        super().__init__(message, request_id=request_id)
        self.status_code = status_code

    def __str__(self) -> str:
        msg = super().__str__()
        if self.status_code:
            return f"({self.status_code}) {msg}"
        return msg


class ValueinDataError(ValueinError):
    """
    Raised when the gateway returns data that the SDK cannot parse.

    This is useful if, for example, a Parquet file is truncated or
    a JSON manifest is malformed, distinguishing it from network issues.
    """


class ValueinConnectionError(ValueinError):
    """Raised when the SDK cannot reach the Valuein gateway (DNS/Network)."""


class ValueinConfigError(ValueinError):
    """Raised when provided hardware or client configuration is invalid."""
