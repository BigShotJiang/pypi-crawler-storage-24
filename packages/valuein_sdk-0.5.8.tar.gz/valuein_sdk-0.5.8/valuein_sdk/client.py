# Copyright 2026 Valuein LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Valuein SDK — Python client for US Core Fundamentals data.

The client authenticates against the Valuein edge gateway, discovers the
user's plan and current data snapshot, then downloads Parquet tables into
an in-process DuckDB instance for zero-latency SQL analytics.

Users never interact with storage directly.  The gateway resolves the
correct bucket, snapshot folder, and Parquet path from the token alone.
"""

from __future__ import annotations

import contextlib
import importlib.resources as pkg_resources
import io
import logging
import os
import pathlib
import tempfile
import time
import warnings
from dataclasses import dataclass
from typing import Any

import duckdb
import pandas as pd
import pyarrow.parquet as pq
from dotenv import load_dotenv

from .exceptions import (
    ValueinAuthError,
    ValueinConfigError,
    ValueinConnectionError,
    ValueinDataError,
    ValueinError,
    ValueinPlanError,
)
from .transport import Transport

_logger = logging.getLogger("valuein_sdk")

_DEFAULT_GATEWAY = "https://data.valuein.biz"

# The 7 tables the edge-gateway exposes.  Used as fallback only when
# the manifest does not include a "tables" key.
_KNOWN_TABLES = frozenset(
    [
        "entity",
        "security",
        "filing",
        "fact",
        "taxonomy_guide",
        "index_membership",
    ]
)


@dataclass
class ValueinConfig:
    """Hardware and resource constraints for the Valuein SDK."""

    # RAM limit (e.g., '2GB', '512MB').
    # DuckDB will spill to disk once this is hit.
    memory_limit: str = "4GB"

    # Where to store temporary spill files.
    # Defaults to a secure OS-provided temp directory.
    temp_directory: str | None = None

    # Hard cap on disk usage to prevent filling up the host SSD.
    max_temp_directory_size: str = "20GB"

    # Number of CPU threads DuckDB is allowed to use.
    threads: int = 4

    def __post_init__(self) -> None:
        """Sanitize inputs to prevent DuckDB parser crashes."""
        self.memory_limit = self.memory_limit.strip().upper()
        self.max_temp_directory_size = self.max_temp_directory_size.strip().upper()

        # Ensure standard formatting (e.g., replacing 'G' with 'GB')
        if self.memory_limit.endswith("G"):
            self.memory_limit += "B"
        if self.max_temp_directory_size.endswith("G"):
            self.max_temp_directory_size += "B"


class ValueinClient:
    """Client for the Valuein Financial Data API.

    Connects to the Valuein edge gateway, authenticates with a Bearer
    token, and loads Parquet tables into DuckDB for SQL querying.

    Args:
        api_key: Valuein API token. Falls back to ``VALUEIN_API_KEY`` env var.
        gateway_url: Override the gateway URL (development only).
        tables: Restrict which tables are loaded at init.
        config: Hardware constraints (RAM/Disk/Threads) for the local engine.
    """

    def __init__(
        self,
        api_key: str | None = None,
        gateway_url: str | None = None,
        tables: list[str] | None = None,
        config: ValueinConfig | None = None,
    ) -> None:
        load_dotenv()

        # 1. Validation Logic
        raw_key = api_key or os.getenv("VALUEIN_API_KEY", "")
        if not raw_key:
            raise ValueinConfigError(
                "Missing API key. Register at https://valuein.biz to obtain a token."
            )
        self.api_key = raw_key

        self.gateway_url: str = (
            gateway_url or os.getenv("VALUEIN_GATEWAY_URL") or _DEFAULT_GATEWAY
        ).rstrip("/")

        self._transport = Transport(
            api_key=self.api_key,
            gateway_url=self.gateway_url,
        )

        # ── Discover plan & snapshot ──────────────────────────────────────
        try:
            self._me_data: dict[str, Any] = self._fetch_me()
            self._plan: str = self._me_data.get("plan", "sp500")
            self._manifest_data: dict[str, Any] = self._fetch_manifest()
        except ValueinError:
            # Auth/plan/rate-limit errors must propagate with their original type
            raise
        except Exception as e:
            # Wrap unexpected boot errors (DNS, SSL, etc.) in a ConnectionError
            raise ValueinConnectionError(f"Failed to initialize session: {e}") from e

        # ── Resolve table list ────────────────────────────────────────────
        manifest_tables = list(self._manifest_data.get("tables", []))
        available = manifest_tables if manifest_tables else sorted(_KNOWN_TABLES)

        if tables is not None:
            unknown = set(tables) - set(available)
            if unknown:
                raise ValueinConfigError(f"Unknown table(s): {', '.join(sorted(unknown))}")
            self._tables: list[str] = list(tables)
        else:
            self._tables = available

        # ── Resource Management ───────────────────────────────────────────
        self.config = config or ValueinConfig()
        self._managed_temp: tempfile.TemporaryDirectory | None = None

        if self.config.temp_directory:
            # User provided a custom directory; we will NOT clean this up
            self._temp_dir_path = self.config.temp_directory
            os.makedirs(self._temp_dir_path, exist_ok=True)
        else:
            # SDK creates a temp directory; we MUST clean this up
            self._managed_temp = tempfile.TemporaryDirectory()
            self._temp_dir_path = self._managed_temp.name

        # ── Initialization ────────────────────────────────────────────────
        self._setup_duckdb()
        self.query_cache: dict[str, str] = {}

        if self._tables:
            self._load_tables()

        self._build_query_map()

    def _setup_duckdb(self) -> None:
        self.con: duckdb.DuckDBPyConnection = duckdb.connect()
        self.con.execute("SET preserve_insertion_order = false")
        self.con.execute(f"SET memory_limit = '{self.config.memory_limit}'")
        self.con.execute(f"SET temp_directory = '{self._temp_dir_path}'")
        self.con.execute(f"SET max_temp_directory_size = '{self.config.max_temp_directory_size}'")
        self.con.execute(f"SET threads = {self.config.threads}")

    def _fetch_me(self) -> dict[str, Any]:
        return self._transport.get("/v1/me").json()

    def _fetch_manifest(self) -> dict[str, Any]:
        return self._transport.get("/v1/manifest").json()

    def _table_endpoint(self, table: str) -> str:
        prefix = "full" if self._plan == "full" else "sp500"
        return f"/v1/{prefix}/{table}"

    def _load_tables(self) -> None:
        """Download and register tables with retry resilience."""
        loaded: list[str] = []
        t0 = time.monotonic()

        for table in self._tables:
            endpoint = self._table_endpoint(table)
            pq_path = pathlib.Path(self._temp_dir_path) / f"{table}.parquet"

            try:
                with open(pq_path, "wb") as f:
                    self._transport.download_to_file(endpoint, f)

                # Use string formatting safely for the path
                self.con.execute(
                    f"CREATE OR REPLACE VIEW {table} AS SELECT * FROM read_parquet('{pq_path}')"
                )
                loaded.append(table)
            except ValueinPlanError:
                _logger.warning("Table '%s' requires a higher plan — skipping.", table)
            except Exception as exc:
                _logger.error("Failed to load table '%s': %s", table, exc)

        if not loaded and self._tables:
            raise ValueinDataError("Valuein engine failed to load any requested tables.")

        self._tables = loaded
        _logger.info("Engine ready. %d tables loaded in %.2fs", len(loaded), time.monotonic() - t0)

    def _build_query_map(self) -> None:
        self.query_cache = {}
        try:
            queries_root = str(pkg_resources.files("valuein_sdk").joinpath("queries"))
            for dirpath, _, filenames in os.walk(queries_root):
                for fname in filenames:
                    if fname.endswith(".sql"):
                        key = fname.removesuffix(".sql")
                        self.query_cache[key] = os.path.join(dirpath, fname)
        except Exception as exc:
            warnings.warn(f"Could not index SQL templates: {exc}", stacklevel=2)

    def me(self) -> dict[str, Any]:
        return dict(self._me_data)

    def manifest(self) -> dict[str, Any]:
        return self._fetch_manifest()

    def health(self) -> dict[str, Any]:
        return self._transport.get("/health").json()

    def get(self, table: str) -> pd.DataFrame:
        all_known = sorted(set(list(self._manifest_data.get("tables", []))) | _KNOWN_TABLES)
        if table not in all_known:
            raise ValueError(f"Unknown table '{table}'. Available: {', '.join(all_known)}")

        endpoint = self._table_endpoint(table)
        try:
            response = self._transport.get(endpoint)
        except (ValueinAuthError, ValueinPlanError):
            raise
        except Exception as exc:
            raise ConnectionError(f"Failed to download '{table}': {exc}") from exc

        return pq.read_table(io.BytesIO(response.content)).to_pandas()

    def query(self, sql: str) -> pd.DataFrame:
        """Execute a raw SQL query against the loaded tables."""
        try:
            return self.con.execute(sql).df()
        except Exception as e:
            raise ValueinDataError(f"SQL Execution failed: {e}") from e

    def run_template(self, name: str, **kwargs: object) -> pd.DataFrame:
        path = self.query_cache.get(name)
        if not path:
            available = sorted(self.query_cache) or ["(none)"]
            raise FileNotFoundError(
                f"Template '{name}' not found. Available: {', '.join(available)}"
            )

        with open(path) as fh:
            sql = fh.read()

        fmt: dict[str, object] = {}
        for key, val in kwargs.items():
            if isinstance(val, (list, tuple)):
                fmt[key] = ", ".join(f"'{v}'" for v in val)
            else:
                fmt[key] = val

        return self.con.execute(sql.format(**fmt)).df()

    def tables(self) -> list[str]:
        return sorted(self._tables)

    def __repr__(self) -> str:
        return (
            f"ValueinClient(plan={self._plan!r}, "
            f"snapshot={self._manifest_data.get('snapshot', 'unknown')!r}, "
            f"tables={len(self._tables)})"
        )

    def close(self) -> None:
        """Explicitly close database connections and clean up managed temp files."""
        if hasattr(self, "con"):
            with contextlib.suppress(Exception):
                self.con.close()

        if hasattr(self, "_transport"):
            with contextlib.suppress(Exception):
                self._transport.close()

        if hasattr(self, "_managed_temp") and self._managed_temp is not None:
            with contextlib.suppress(Exception):
                self._managed_temp.cleanup()
                self._managed_temp = None

    def __enter__(self) -> ValueinClient:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __del__(self) -> None:
        self.close()
