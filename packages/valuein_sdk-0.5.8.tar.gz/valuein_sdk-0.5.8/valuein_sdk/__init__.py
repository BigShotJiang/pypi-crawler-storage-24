from importlib.metadata import PackageNotFoundError, version

from .client import ValueinClient, ValueinConfig
from .exceptions import (
    ValueinAPIError,
    ValueinAuthError,
    ValueinConfigError,
    ValueinConnectionError,
    ValueinDataError,
    ValueinError,
    ValueinNotFoundError,
    ValueinPlanError,
    ValueinRateLimitError,
)

try:
    __version__ = version("valuein-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

__all__ = [
    "ValueinClient",
    "ValueinConfig",
    "__version__",
    "ValueinError",
    "ValueinAuthError",
    "ValueinPlanError",
    "ValueinNotFoundError",
    "ValueinRateLimitError",
    "ValueinAPIError",
    "ValueinConfigError",
    "ValueinConnectionError",
    "ValueinDataError",
]
