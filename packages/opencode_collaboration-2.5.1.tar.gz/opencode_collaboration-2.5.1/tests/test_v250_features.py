"""
oc-collab v2.5.0 功能测试

测试双Git仓库配置和测试结果接收功能
"""

import pytest
import os
import tempfile
import yaml
from pathlib import Path

from src.core.git_config import GitConfigManager, GitRemote


class TestGitConfigManager:
    """测试GitConfigManager"""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.config_path = os.path.join(self.temp_dir, "git_config.yaml")
        self.config_mgr = GitConfigManager(config_path=self.config_path)

    def teardown_method(self):
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_add_remote(self):
        """测试添加远程仓库"""
        remote = GitRemote(
            name="gitea",
            url="http://8.149.137.233:3000/test/repo.git",
            auth_type="token",
            token="test_token_123",
            default_branch="main",
        )
        
        success, msg = self.config_mgr.add_or_update_remote(remote)
        assert success
        assert "gitea" in msg
        
        saved_remote = self.config_mgr.get_remote("gitea")
        assert saved_remote is not None
        assert saved_remote.url == remote.url
        assert saved_remote.auth_type == "token"
        assert saved_remote.token == "test_token_123"

    def test_list_remotes(self):
        """测试列出远程仓库"""
        remote1 = GitRemote(name="origin", url="git@gitee.com:test/repo.git")
        remote2 = GitRemote(name="gitea", url="http://8.149.137.233:3000/test/repo.git")
        
        self.config_mgr.add_or_update_remote(remote1)
        self.config_mgr.add_or_update_remote(remote2)
        
        remotes = self.config_mgr.list_remotes()
        assert "origin" in remotes
        assert "gitea" in remotes

    def test_delete_remote(self):
        """测试删除远程仓库"""
        remote = GitRemote(name="gitea", url="http://8.149.137.233:3000/test/repo.git")
        self.config_mgr.add_or_update_remote(remote)
        
        success, msg = self.config_mgr.delete_remote("gitea")
        assert success
        assert self.config_mgr.get_remote("gitea") is None

    def test_token_env_var_resolution(self):
        """测试token环境变量解析"""
        os.environ["TEST_TOKEN"] = "env_token_value"
        
        remote = GitRemote(
            name="gitea",
            url="http://8.149.137.233:3000/test/repo.git",
            auth_type="token",
            token="${TEST_TOKEN}",
        )
        
        self.config_mgr.add_or_update_remote(remote)
        
        saved_remote = self.config_mgr.get_remote("gitea")
        assert saved_remote.token == "${TEST_TOKEN}"
        
        resolved = self.config_mgr._resolve_token("${TEST_TOKEN}")
        assert resolved == "env_token_value"
        
        os.environ.pop("TEST_TOKEN", None)

    def test_token_masking(self):
        """测试token脱敏"""
        remote = GitRemote(
            name="gitea",
            url="http://8.149.137.233:3000/test/repo.git",
            auth_type="token",
            token="secret12345",
        )
        self.config_mgr.add_or_update_remote(remote)
        
        info = self.config_mgr.get_remote_info("gitea")
        assert info["token"] == "se****45"
        assert self.config_mgr.get_remote("gitea").token == "secret12345"

    def test_get_remote_for_git(self):
        """测试获取git命令用URL"""
        remote = GitRemote(
            name="gitea",
            url="http://8.149.137.233:3000/test/repo.git",
            auth_type="token",
            token="auth_token",
        )
        self.config_mgr.add_or_update_remote(remote)
        
        success, url = self.config_mgr.get_remote_for_git("gitea")
        assert success
        assert "auth_token" in url
        assert "8.149.137.233" in url


class TestTestResultStorage:
    """测试TestResultStorage"""
    
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.storage_path = os.path.join(self.temp_dir, "test_results.yaml")
        from src.api.test_routes import TestResultStorage
        self.storage = TestResultStorage(storage_path=self.storage_path)

    def teardown_method(self):
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_save_result(self):
        """测试保存测试结果"""
        from src.api.test_routes import TestResult
        
        result = TestResult(
            task_id="T-001",
            subsystem="test-agent",
            project="oc-collab",
            version="v2.5.0",
            status="passed",
            passed=100,
            failed=0,
            errors=0,
            skipped=5,
            duration=120.5,
            report_url="http://test/report.html",
            timestamp="2026-03-22T12:00:00Z",
        )
        
        result_id = self.storage.save_result(result)
        assert result_id is not None
        assert len(result_id) == 8

    def test_get_result(self):
        """测试获取测试结果"""
        from src.api.test_routes import TestResult
        
        result = TestResult(
            task_id="T-001",
            subsystem="test-agent",
            project="oc-collab",
            version="v2.5.0",
            status="passed",
            passed=100,
            failed=0,
            errors=0,
            skipped=5,
            duration=120.5,
            timestamp="2026-03-22T12:00:00Z",
        )
        
        result_id = self.storage.save_result(result)
        saved = self.storage.get_result(result_id)
        
        assert saved is not None
        assert saved["task_id"] == "T-001"
        assert saved["status"] == "passed"
        assert saved["passed"] == 100

    def test_list_results(self):
        """测试列出测试结果"""
        from src.api.test_routes import TestResult
        
        result1 = TestResult(
            task_id="T-001",
            subsystem="test-agent",
            project="oc-collab",
            version="v2.5.0",
            status="passed",
            passed=100,
            failed=0,
            errors=0,
            skipped=5,
            duration=120.5,
            timestamp="2026-03-22T12:00:00Z",
        )
        
        result2 = TestResult(
            task_id="T-002",
            subsystem="test-agent",
            project="pm-agent",
            version="v1.0",
            status="failed",
            passed=80,
            failed=5,
            errors=0,
            skipped=10,
            duration=200.0,
            timestamp="2026-03-22T13:00:00Z",
        )
        
        self.storage.save_result(result1)
        self.storage.save_result(result2)
        
        all_results = self.storage.list_results()
        assert len(all_results) == 2
        
        oc_results = self.storage.list_results(project="oc-collab")
        assert len(oc_results) == 1
        assert oc_results[0]["task_id"] == "T-001"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
