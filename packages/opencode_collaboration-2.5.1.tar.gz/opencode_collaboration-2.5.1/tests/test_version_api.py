"""
版本管理API测试用例

测试 src/api/version_routes.py 的功能
"""

import pytest
import sys
import os
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api.serve import create_app


@pytest.fixture
def client():
    """创建测试客户端"""
    app = create_app()
    return TestClient(app)


@pytest.fixture(autouse=True)
def clean_versions_db():
    """每个测试前清理版本数据库"""
    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "state", "versions.db")
    if os.path.exists(db_path):
        os.remove(db_path)
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


class TestVersionAPI:
    """版本API测试"""

    def test_register_version(self, client):
        """TC-V001: 测试版本登记"""
        response = client.post(
            "/api/v1/versions",
            json={
                "version": "3.0.0",
                "project_id": "test-agent",
                "git_commit_hash": "abc123def456",
                "manifest": '{"components": [{"name": "test-agent"}]}'
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "3.0.0"
        assert data["project_id"] == "test-agent"
        assert data["git_commit_hash"] == "abc123def456"
        assert data["status"] == "registered"
        assert "id" in data

    def test_register_duplicate_version(self, client):
        """TC-V002: 测试重复版本登记"""
        client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent"}
        )
        response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent"}
        )
        assert response.status_code == 400
        assert "already exists" in response.json()["detail"]

    def test_list_versions(self, client):
        """TC-V003: 测试列出版本"""
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "test-agent"}
        )
        client.post(
            "/api/v1/versions",
            json={"version": "2.0.0", "project_id": "test-agent"}
        )
        
        response = client.get("/api/v1/versions")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2

    def test_list_versions_by_project(self, client):
        """TC-V004: 测试按项目筛选"""
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "test-agent"}
        )
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "pm-agent"}
        )
        
        response = client.get("/api/v1/versions?project_id=test-agent")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["project_id"] == "test-agent"

    def test_get_version(self, client):
        """TC-V005: 测试获取版本详情"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent"}
        )
        version_id = reg_response.json()["id"]
        
        response = client.get(f"/api/v1/versions/{version_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "3.0.0"

    def test_get_version_not_found(self, client):
        """TC-V006: 测试获取不存在的版本"""
        response = client.get("/api/v1/versions/999")
        assert response.status_code == 404

    def test_update_version(self, client):
        """TC-V007: 测试更新版本"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent"}
        )
        version_id = reg_response.json()["id"]
        
        response = client.put(
            f"/api/v1/versions/{version_id}",
            json={"version": "3.0.1", "git_commit_hash": "newhash123"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "3.0.1"
        assert data["git_commit_hash"] == "newhash123"

    def test_trigger_release(self, client):
        """TC-V008: 测试触发发布"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent"}
        )
        version_id = reg_response.json()["id"]
        
        response = client.post(f"/api/v1/versions/{version_id}/release")
        assert response.status_code == 200
        assert response.json()["success"] is True
        
        get_response = client.get(f"/api/v1/versions/{version_id}")
        assert get_response.json()["status"] == "released"

    def test_trigger_release_already_released(self, client):
        """TC-V009: 测试重复发布"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent"}
        )
        version_id = reg_response.json()["id"]
        
        client.post(f"/api/v1/versions/{version_id}/release")
        response = client.post(f"/api/v1/versions/{version_id}/release")
        
        assert response.status_code == 400
        assert "already released" in response.json()["detail"]

    def test_delete_version(self, client):
        """TC-V010: 测试删除版本"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent"}
        )
        version_id = reg_response.json()["id"]
        
        response = client.delete(f"/api/v1/versions/{version_id}")
        assert response.status_code == 200
        
        get_response = client.get(f"/api/v1/versions/{version_id}")
        assert get_response.status_code == 404


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
