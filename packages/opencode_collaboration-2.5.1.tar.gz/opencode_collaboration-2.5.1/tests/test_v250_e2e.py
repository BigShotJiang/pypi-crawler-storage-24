"""
oc-collab v2.5.0 E2E测试

端到端集成测试，验证完整业务流程。
E-01/E-04使用真实git仓库；E-02/E-03使用真实存储层。
"""

import os
import subprocess
import pytest


class TestSubmitFlow:
    """E-01: 代码提交流程 E2E"""

    def test_submit_flow(self, tmp_path):
        """验证完整提交流程：init → add remote → add file → commit → submit"""
        repo_dir = tmp_path / "test_repo"
        repo_dir.mkdir()
        bare_dir = tmp_path / "bare_repo.git"

        subprocess.run(["git", "init"], cwd=repo_dir, capture_output=True)
        subprocess.run(["git", "init", "--bare", str(bare_dir)], capture_output=True)
        subprocess.run(
            ["git", "config", "user.email", "test@test.com"],
            cwd=repo_dir, capture_output=True
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=repo_dir, capture_output=True
        )
        subprocess.run(
            ["git", "remote", "add", "origin", str(bare_dir)],
            cwd=repo_dir, capture_output=True
        )
        subprocess.run(["git", "branch", "-M", "main"], cwd=repo_dir, capture_output=True)

        test_file = repo_dir / "test.txt"
        test_file.write_text("hello world")
        subprocess.run(["git", "add", "."], cwd=repo_dir, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "initial commit"],
            cwd=repo_dir, capture_output=True
        )

        extra_file = repo_dir / "extra.txt"
        extra_file.write_text("change for submit test")

        from fastapi.testclient import TestClient
        from src.api.serve import create_app
        from src.core.git_config import GitConfigManager, GitRemote

        os.environ["GIT_DIR"] = str(repo_dir / ".git")
        os.environ["GIT_WORK_TREE"] = str(repo_dir)

        config_mgr = GitConfigManager(config_path=str(tmp_path / "git_config.yaml"))
        config_mgr.add_or_update_remote(
            GitRemote(name="origin", url=str(bare_dir), auth_type="none")
        )

        from src.core import git_config
        import src.api.git_routes as gr
        original_get_gc = git_config.get_config_manager
        original_get_gr = gr.get_config_manager
        git_config.get_config_manager = lambda: config_mgr
        gr.get_config_manager = lambda: config_mgr

        try:
            app = create_app()
            client = TestClient(app)
            resp = client.post("/api/v1/git/submit", json={
                "message": "E2E test commit",
                "author": "E2E Tester",
                "dual_push": False,
            })
            assert resp.status_code == 200
            data = resp.json()
            assert data["success"] is True
            assert "E2E test commit" in data["details"]["message"]

            log = subprocess.run(
                ["git", "log", "--oneline"],
                cwd=repo_dir, capture_output=True, text=True
            )
            assert "E2E test commit" in log.stdout
        finally:
            git_config.get_config_manager = original_get_gc
            gr.get_config_manager = original_get_gr
            os.environ.pop("GIT_DIR", None)
            os.environ.pop("GIT_WORK_TREE", None)


class TestResultLifecycle:
    """E-02: 测试结果全生命周期 E2E"""

    def test_test_result_lifecycle(self, tmp_path):
        """POST → list → get-by-id → 验证数据字段完整性"""
        from fastapi.testclient import TestClient
        from src.api.serve import create_app
        from src.api.test_routes import TestResultStorage

        storage = TestResultStorage(storage_path=str(tmp_path / "test_results.yaml"))
        result_data = {
            "task_id": "T-E2E-001",
            "subsystem": "test-agent",
            "project": "oc-collab",
            "version": "v2.5.0",
            "status": "passed",
            "passed": 100,
            "failed": 2,
            "errors": 1,
            "skipped": 5,
            "duration": 150.5,
            "report_url": "http://example.com/report.html",
            "timestamp": "2026-03-23T10:00:00Z",
        }

        app = create_app()
        client = TestClient(app)

        from src.api import test_routes
        original = test_routes._storage
        test_routes._storage = storage

        try:
            resp_post = client.post("/api/v1/test-results", json=result_data)
            assert resp_post.status_code == 200
            assert resp_post.json()["success"] is True
            result_id = resp_post.json()["data"]["id"]
            assert len(result_id) == 8

            resp_list = client.get("/api/v1/test-results")
            assert resp_list.status_code == 200
            assert resp_list.json()["data"]["count"] >= 1

            resp_get = client.get(f"/api/v1/test-results/{result_id}")
            assert resp_get.status_code == 200
            saved = resp_get.json()["data"]
            assert saved["task_id"] == "T-E2E-001"
            assert saved["project"] == "oc-collab"
            assert saved["status"] == "passed"
            assert saved["passed"] == 100
            assert saved["failed"] == 2
            assert saved["errors"] == 1
            assert saved["skipped"] == 5
            assert saved["duration"] == 150.5
            assert saved["report_url"] == "http://example.com/report.html"
        finally:
            test_routes._storage = original


class TestConcurrentResults:
    """E-03: 并发测试结果 E2E"""

    def test_concurrent_test_results(self, tmp_path):
        """连续POST 3条不同结果 → list验证count=3"""
        from fastapi.testclient import TestClient
        from src.api.serve import create_app
        from src.api.test_routes import TestResultStorage

        storage = TestResultStorage(storage_path=str(tmp_path / "test_results.yaml"))
        app = create_app()
        client = TestClient(app)

        from src.api import test_routes
        original = test_routes._storage
        test_routes._storage = storage

        try:
            for i in range(3):
                resp = client.post("/api/v1/test-results", json={
                    "task_id": f"T-E2E-{i:03d}",
                    "subsystem": "test-agent",
                    "project": f"project-{i}",
                    "version": "v2.5.0",
                    "status": "passed",
                    "passed": 100 - i * 10,
                    "failed": i,
                    "errors": 0,
                    "skipped": 5,
                    "duration": 100.0 + i * 10,
                    "timestamp": f"2026-03-23T{10+i:02d}:00:00Z",
                })
                assert resp.status_code == 200
                assert resp.json()["success"] is True

            resp_list = client.get("/api/v1/test-results")
            assert resp_list.json()["data"]["count"] == 3
        finally:
            test_routes._storage = original


class TestErrorIsolation:
    """E-04: 错误隔离 E2E"""

    def test_submit_error_isolation(self, tmp_path):
        """使用side_effect mock：origin成功、gitea失败 → submit → 验证partial success"""
        from fastapi.testclient import TestClient
        from src.api.serve import create_app
        from src.core.git_config import GitConfigManager, GitRemote

        config_mgr = GitConfigManager(config_path=str(tmp_path / "git_config.yaml"))
        config_mgr.add_or_update_remote(
            GitRemote(name="origin", url="git@gitee.com:org/repo.git", auth_type="ssh")
        )
        config_mgr.add_or_update_remote(
            GitRemote(name="gitea", url="http://8.149.137.233:3000/org/repo.git", auth_type="token")
        )

        from src.core import git_config
        import src.api.git_routes as gr
        original_get_gc = git_config.get_config_manager
        original_get_gr = gr.get_config_manager
        original_run_git = gr._run_git

        def side_effect(*args):
            args_list = list(args)
            if "gitea" in args_list:
                return (False, "Connection refused")
            return (True, f"mocked: {' '.join(args_list)}")

        git_config.get_config_manager = lambda: config_mgr
        gr.get_config_manager = lambda: config_mgr
        gr._run_git = side_effect

        try:
            app = create_app()
            client = TestClient(app)
            resp = client.post("/api/v1/git/submit", json={
                "message": "test error isolation",
                "author": "tester",
                "dual_push": True,
            })
            assert resp.status_code == 200
            data = resp.json()
            assert data["success"] is True
            assert data["message"] == "代码提交成功，推送完成 1/2 个仓库"
            assert data["details"]["remotes"]["origin"]["success"] is True
            assert data["details"]["remotes"]["gitea"]["success"] is False
            assert "Connection refused" in data["details"]["remotes"]["gitea"]["error"]
        finally:
            git_config.get_config_manager = original_get_gc
            gr.get_config_manager = original_get_gr
            gr._run_git = original_run_git
