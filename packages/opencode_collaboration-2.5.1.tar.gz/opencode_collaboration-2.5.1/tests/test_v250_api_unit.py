"""
oc-collab v2.5.0 API层单元测试

使用 FastAPI.TestClient 测试所有API端点，配合conftest.py中的fixtures实现隔离。
覆盖：git_routes.py (5端点) + test_routes.py (3端点) + serve.py (/health)
"""

import pytest
from fastapi.testclient import TestClient


class TestGitConfigAPI:
    """Git配置API测试 (GET/POST /api/v1/git/config)"""

    def test_get_git_config_empty(self, test_client):
        """A-01: 无配置时返回空remotes列表"""
        resp = test_client.get("/api/v1/git/config")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["data"]["remotes"] == []
        assert data["data"]["details"] == {}

    def test_get_git_config_populated(self, test_client, test_config_manager):
        """A-02: 有配置时返回完整详情+脱敏token"""
        from src.core.git_config import GitRemote
        remote = GitRemote(
            name="gitea",
            url="http://8.149.137.233:3000/test/repo.git",
            auth_type="token",
            token="secret12345",
            default_branch="main",
        )
        test_config_manager.add_or_update_remote(remote)

        resp = test_client.get("/api/v1/git/config")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert "gitea" in data["data"]["remotes"]
        assert data["data"]["details"]["gitea"]["token"] == "se****45"

    def test_add_git_config_success(self, test_client):
        """A-03: 新增远程仓库成功"""
        resp = test_client.post("/api/v1/git/config", json={
            "name": "gitea",
            "url": "http://8.149.137.233:3000/test/repo.git",
            "auth_type": "token",
            "token": "test_token",
            "default_branch": "main",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert "gitea" in data["message"]

    def test_get_git_config_by_name_found(self, test_client, test_config_manager):
        """A-04: 仓库存在时返回详情"""
        from src.core.git_config import GitRemote
        remote = GitRemote(
            name="gitea",
            url="http://8.149.137.233:3000/test/repo.git",
            auth_type="token",
            token="mypassword123",
        )
        test_config_manager.add_or_update_remote(remote)

        resp = test_client.get("/api/v1/git/config/gitea")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["data"]["name"] == "gitea"
        assert data["data"]["url"] == "http://8.149.137.233:3000/test/repo.git"
        assert data["data"]["token"] == "my****23"

    def test_get_git_config_by_name_not_found(self, test_client):
        """A-05: 仓库不存在时返回404"""
        resp = test_client.get("/api/v1/git/config/nonexistent")
        assert resp.status_code == 404

    def test_delete_git_config_success(self, test_client, test_config_manager):
        """A-06: 删除非origin仓库成功"""
        from src.core.git_config import GitRemote
        remote = GitRemote(name="gitea", url="http://example.com/repo.git")
        test_config_manager.add_or_update_remote(remote)

        resp = test_client.delete("/api/v1/git/config/gitea")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert test_config_manager.get_remote("gitea") is None

    def test_delete_git_config_origin_blocked(self, test_client, test_config_manager):
        """A-07: 删除origin返回400"""
        from src.core.git_config import GitRemote
        remote = GitRemote(name="origin", url="git@gitee.com:org/repo.git")
        test_config_manager.add_or_update_remote(remote)

        resp = test_client.delete("/api/v1/git/config/origin")
        assert resp.status_code == 400
        assert "origin" in resp.json()["detail"]


class TestGitPushAPI:
    """Git推送API测试 (POST /api/v1/git/push)"""

    def test_push_single_target_success(self, test_client, test_config_manager):
        """A-08: 指定target推送成功"""
        from src.core.git_config import GitRemote
        remote = GitRemote(name="gitea", url="http://example.com/repo.git")
        test_config_manager.add_or_update_remote(remote)

        resp = test_client.post("/api/v1/git/push", json={
            "target": "gitea",
            "branch": "main",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert "gitea" in data["data"]["results"]
        assert data["data"]["results"]["gitea"]["success"] is True

    def test_push_partial_failure(self, test_client, test_config_manager, monkeypatch):
        """A-09: 多仓库推送部分失败"""
        from src.core.git_config import GitRemote
        test_config_manager.add_or_update_remote(
            GitRemote(name="origin", url="git@gitee.com:org/repo.git")
        )
        test_config_manager.add_or_update_remote(
            GitRemote(name="gitea", url="http://example.com/repo.git")
        )

        def side_effect(*args):
            args_list = list(args)
            if "gitea" in args_list:
                return (False, "Connection refused")
            return (True, f"mocked: {' '.join(args_list)}")

        monkeypatch.setattr("src.api.git_routes._run_git", side_effect)

        resp = test_client.post("/api/v1/git/push", json={"branch": "main"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is False
        assert data["data"]["results"]["origin"]["success"] is True
        assert data["data"]["results"]["gitea"]["success"] is False
        assert "Connection refused" in data["data"]["results"]["gitea"]["error"]


class TestGitSubmitAPI:
    """代码提交API测试 (POST /api/v1/git/submit)"""

    def test_submit_success(self, test_client, test_config_manager, mock_run_git):
        """A-10: 正常提交+双推成功"""
        from src.core.git_config import GitRemote
        test_config_manager.add_or_update_remote(
            GitRemote(name="origin", url="git@gitee.com:org/repo.git")
        )
        test_config_manager.add_or_update_remote(
            GitRemote(name="gitea", url="http://example.com/repo.git")
        )

        resp = test_client.post("/api/v1/git/submit", json={
            "message": "test: add feature",
            "author": "tester",
            "dual_push": True,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["message"] == "代码提交成功，推送完成 2/2 个仓库"
        assert data["details"]["remotes"]["origin"]["success"] is True
        assert data["details"]["remotes"]["gitea"]["success"] is True

    def test_submit_nothing_to_commit(self, test_client, mock_run_git):
        """A-11: 无变更时返回success=True"""
        mock_run_git.results = {
            ("add", "."): (True, ""),
            ("commit", "-m", "test"): (False, "nothing to commit, working tree clean"),
        }

        resp = test_client.post("/api/v1/git/submit", json={
            "message": "test",
            "author": "tester",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert "没有需要提交" in data["message"]

    def test_submit_dual_push_partial(self, test_client, test_config_manager, monkeypatch):
        """A-12: 双推部分失败但整体返回partial success"""
        from src.core.git_config import GitRemote
        test_config_manager.add_or_update_remote(
            GitRemote(name="origin", url="git@gitee.com:org/repo.git")
        )
        test_config_manager.add_or_update_remote(
            GitRemote(name="gitea", url="http://example.com/repo.git")
        )

        def side_effect(*args):
            args_list = list(args)
            if args_list == ["push", "gitea", "main"]:
                return (False, "Connection refused")
            return (True, f"mocked: {' '.join(args_list)}")

        monkeypatch.setattr("src.api.git_routes._run_git", side_effect)

        resp = test_client.post("/api/v1/git/submit", json={
            "message": "test",
            "author": "tester",
            "dual_push": True,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["message"] == "代码提交成功，推送完成 1/2 个仓库"
        assert data["details"]["remotes"]["origin"]["success"] is True
        assert data["details"]["remotes"]["gitea"]["success"] is False


class TestTestResultAPI:
    """测试结果API测试 (POST/GET /api/v1/test-results)"""

    def test_post_test_result(self, test_client):
        """A-13: 保存测试结果返回8位ID"""
        resp = test_client.post("/api/v1/test-results", json={
            "task_id": "T-001",
            "subsystem": "test-agent",
            "project": "oc-collab",
            "version": "v2.5.0",
            "status": "passed",
            "passed": 100,
            "failed": 0,
            "errors": 0,
            "skipped": 5,
            "duration": 120.5,
            "report_url": "http://test/report.html",
            "timestamp": "2026-03-22T12:00:00Z",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert len(data["data"]["id"]) == 8

    def test_list_test_results(self, test_client, test_storage):
        """A-14: 无筛选/按project/按subsystem/组合筛选"""
        from src.api.test_routes import TestResult
        r1 = TestResult(
            task_id="T-001", subsystem="test-agent", project="oc-collab",
            version="v2.5.0", status="passed", passed=100, failed=0,
            errors=0, skipped=5, duration=120.5,
            timestamp="2026-03-22T12:00:00Z",
        )
        r2 = TestResult(
            task_id="T-002", subsystem="test-agent", project="pm-agent",
            version="v1.0", status="failed", passed=80, failed=5,
            errors=0, skipped=10, duration=200.0,
            timestamp="2026-03-22T13:00:00Z",
        )
        r3 = TestResult(
            task_id="T-003", subsystem="conf-man", project="oc-collab",
            version="v2.5.0", status="passed", passed=90, failed=2,
            errors=0, skipped=8, duration=95.0,
            timestamp="2026-03-22T14:00:00Z",
        )
        test_storage.save_result(r1)
        test_storage.save_result(r2)
        test_storage.save_result(r3)

        resp_all = test_client.get("/api/v1/test-results")
        assert resp_all.status_code == 200
        assert resp_all.json()["data"]["count"] == 3

        resp_proj = test_client.get("/api/v1/test-results?project=oc-collab")
        assert resp_proj.json()["data"]["count"] == 2

        resp_sub = test_client.get("/api/v1/test-results?subsystem=test-agent")
        assert resp_sub.json()["data"]["count"] == 2

        resp_both = test_client.get("/api/v1/test-results?project=oc-collab&subsystem=conf-man")
        assert resp_both.json()["data"]["count"] == 1
        assert resp_both.json()["data"]["results"][0]["task_id"] == "T-003"

    def test_get_test_result_by_id(self, test_client, test_storage):
        """A-15: 存在返回详情，不存在返回404"""
        from src.api.test_routes import TestResult
        r = TestResult(
            task_id="T-001", subsystem="test-agent", project="oc-collab",
            version="v2.5.0", status="passed", passed=100, failed=0,
            errors=0, skipped=5, duration=120.5,
            timestamp="2026-03-22T12:00:00Z",
        )
        result_id = test_storage.save_result(r)

        resp_found = test_client.get(f"/api/v1/test-results/{result_id}")
        assert resp_found.status_code == 200
        data = resp_found.json()
        assert data["success"] is True
        assert data["data"]["task_id"] == "T-001"
        assert data["data"]["status"] == "passed"

        resp_not_found = test_client.get("/api/v1/test-results/nonexistent")
        assert resp_not_found.status_code == 404


class TestServeApp:
    """API服务启动测试 (serve.py)"""

    def test_health_endpoint(self, test_client):
        """A-16: /health返回status=ok和version"""
        resp = test_client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["service"] == "oc-collab-api"
        assert data["version"] == "2.5.0"
