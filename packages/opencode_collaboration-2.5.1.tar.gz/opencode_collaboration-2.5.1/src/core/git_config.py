"""
Git配置管理模块

管理双Git仓库配置持久化
"""

import os
import re
from pathlib import Path
from typing import Optional
import yaml
from pydantic import BaseModel
from datetime import datetime


class GitRemote(BaseModel):
    name: str
    url: str
    auth_type: str = "none"
    token: Optional[str] = None
    default_branch: str = "main"
    
    def resolve_token(self, env_var: str) -> Optional[str]:
        """解析token"""
        if self.token and self.token.startswith("${") and self.token.endswith("}"):
            env_name = self.token[2:-1]
            return os.getenv(env_name, "")
        return self.token


class GitConfig(BaseModel):
    remotes: dict[str, GitRemote] = {}


class GitConfigManager:
    CONFIG_PATH = "./config/git_config.yaml"

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = Path(config_path or self.CONFIG_PATH)
        self._ensure_config_dir()

    def _ensure_config_dir(self):
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

    def _resolve_token(self, token: Optional[str]) -> Optional[str]:
        """解析token，支持环境变量引用"""
        if token and token.startswith("${") and token.endswith("}"):
            env_var = token[2:-1]
            return os.getenv(env_var, "")
        return token

    def _mask_token(self, token: Optional[str]) -> str:
        """脱敏token"""
        if not token:
            return ""
        if len(token) <= 4:
            return "****"
        return token[:2] + "****" + token[-2:]

    def load_config(self) -> GitConfig:
        """加载配置"""
        if not self.config_path.exists():
            return GitConfig()
        
        with open(self.config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        
        remotes = {}
        for name, remote_data in data.get("remotes", {}).items():
            remotes[name] = GitRemote(
                name=name,
                url=remote_data.get("url", ""),
                auth_type=remote_data.get("auth_type", "none"),
                token=remote_data.get("token"),
                default_branch=remote_data.get("default_branch", "main"),
            )
        
        return GitConfig(remotes=remotes)

    def save_config(self, config: GitConfig):
        """保存配置"""
        data = {
            "remotes": {
                name: {
                    "url": remote.url,
                    "auth_type": remote.auth_type,
                    "token": remote.token,
                    "default_branch": remote.default_branch,
                }
                for name, remote in config.remotes.items()
            }
        }
        
        with open(self.config_path, "w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, allow_unicode=True, default_flow_style=False)

    def get_remote(self, name: str) -> Optional[GitRemote]:
        """获取指定远程仓库配置"""
        config = self.load_config()
        return config.remotes.get(name)

    def list_remotes(self) -> list[str]:
        """列出所有远程仓库"""
        config = self.load_config()
        return list(config.remotes.keys())

    def add_or_update_remote(self, remote: GitRemote) -> tuple[bool, str]:
        """添加或更新远程仓库"""
        config = self.load_config()
        config.remotes[remote.name] = remote
        self.save_config(config)
        return True, f"远程仓库 {remote.name} 配置已保存"

    def delete_remote(self, name: str) -> tuple[bool, str]:
        """删除远程仓库"""
        config = self.load_config()
        
        if name not in config.remotes:
            return False, f"远程仓库 {name} 不存在"
        
        del config.remotes[name]
        self.save_config(config)
        
        return True, f"远程仓库 {name} 已删除"

    def get_remote_for_git(self, name: str) -> tuple[bool, str]:
        """获取远程仓库URL（用于git命令）"""
        remote = self.get_remote(name)
        if not remote:
            return False, f"远程仓库 {name} 未配置"
        
        url = remote.url
        
        if remote.auth_type == "token" and remote.token:
            if "@" in url:
                url = url.replace("@", f":{remote.token}@")
            elif "://" in url:
                url = url.replace("://", f"://:{remote.token}@")
        
        return True, url

    def get_remote_info(self, name: str) -> Optional[dict]:
        """获取远程仓库详细信息（脱敏）"""
        remote = self.get_remote(name)
        if not remote:
            return None
        
        return {
            "name": remote.name,
            "url": remote.url,
            "auth_type": remote.auth_type,
            "token": self._mask_token(remote.token),
            "default_branch": remote.default_branch,
        }


_config_manager_instance: Optional[GitConfigManager] = None


def get_config_manager() -> GitConfigManager:
    """获取配置管理器单例"""
    global _config_manager_instance
    if _config_manager_instance is None:
        _config_manager_instance = GitConfigManager()
    return _config_manager_instance
