from phantomtrace.core import (
    AbsentNumber as AbsentNumber,
    Void as Void,
    VOID as VOID,
    Unresolved as Unresolved,
    ErasureResult as ErasureResult,
    ErasedExcess as ErasedExcess,
    add as add,
    subtract as subtract,
    multiply as multiply,
    divide as divide,
    erase as erase,
    erased as erased,
    erased_n as erased_n,
    negative as negative,
    combine as combine,
    compare as compare,
    trace as trace,
    join as join,
    present as present,
    absent as absent,
    smallest as smallest,
    largest as largest,
    ordering as ordering,
    solve as solve,
    format_result as format_result,
    parse_number as parse_number,
    ALL_OPERATIONS as ALL_OPERATIONS,
)
from phantomtrace import toggle as toggle
from phantomtrace.toggle import tensor as tensor
from phantomtrace import builder as builder
from phantomtrace.builder import (
    StateSpace as StateSpace,
    State as State,
    StateNumber as StateNumber,
    StateTransition as StateTransition,
    StateRule as StateRule,
    presence_absence_space as presence_absence_space,
)


def n(value, absence_level=0):
    return AbsentNumber(value, absence_level)


__version__ = "0.9.8"
