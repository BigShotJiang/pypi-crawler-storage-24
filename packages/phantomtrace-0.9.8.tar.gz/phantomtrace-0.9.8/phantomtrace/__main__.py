from phantomtrace.calculator import interactive_calculator
if __name__ == '__main__':
    interactive_calculator()
