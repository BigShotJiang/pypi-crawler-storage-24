"""Error classes for the Presa SDK."""

from __future__ import annotations


class PresaError(Exception):
    """Base error class for all Presa SDK errors."""


class AuthenticationError(PresaError):
    """Raised when the API key is missing or invalid."""

    def __init__(self, message: str | None = None) -> None:
        super().__init__(
            message
            or (
                "Missing API key. Set the PRESA_API_KEY environment variable "
                "or pass api_key to the Presa constructor.\n"
                "  Sign up at https://presa.dev to get your API key.\n"
                "  Or install via the Vercel Marketplace: "
                "https://vercel.com/integrations/presa"
            )
        )


class ApiError(PresaError):
    """Raised when the API returns an error response."""

    def __init__(self, code: str, message: str, status: int) -> None:
        super().__init__(message)
        self.code = code
        """Machine-readable error code (e.g., 'QUOTA_EXCEEDED')."""
        self.status = status
        """HTTP status code."""


class TimeoutError(PresaError):
    """Raised when the request times out."""

    def __init__(self, timeout: float) -> None:
        super().__init__(f"Request timed out after {timeout}s")
