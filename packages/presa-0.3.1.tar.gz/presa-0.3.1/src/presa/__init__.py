"""Official Python SDK for the Presa HTML-to-PDF API."""

from __future__ import annotations

from presa.client import Presa
from presa.errors import ApiError, AuthenticationError, PresaError, TimeoutError
from presa.types import (
    AssetInfo,
    AssetListResponse,
    AsyncJobResponse,
    BatchItem,
    BatchResult,
    BatchStatus,
    CreateTemplateInput,
    CursorPage,
    GenerateOptions,
    GenerateResult,
    JobStatus,
    ListTemplatesOptions,
    Margins,
    PdfMetadata,
    PresaConfig,
    RenderOptions,
    StoredResponse,
    TemplateInfo,
    UpdateTemplateInput,
)

__all__ = [
    "ApiError",
    "AssetInfo",
    "AssetListResponse",
    "AsyncJobResponse",
    "AuthenticationError",
    "BatchItem",
    "BatchResult",
    "BatchStatus",
    "CreateTemplateInput",
    "CursorPage",
    "GenerateOptions",
    "GenerateResult",
    "JobStatus",
    "ListTemplatesOptions",
    "Margins",
    "PDF",
    "PdfMetadata",
    "Presa",
    "PresaConfig",
    "PresaError",
    "RenderOptions",
    "StoredResponse",
    "TemplateInfo",
    "TimeoutError",
    "UpdateTemplateInput",
]


class _PDFNamespace:
    """Convenience namespace for static-style usage.

    Example::

        from presa import PDF

        result = PDF.generate(html="<h1>Hello</h1>")
        result = PDF.from_url(url="https://example.com")
    """

    @staticmethod
    def generate(
        html: str,
        **kwargs: object,
    ) -> GenerateResult:
        """Generate a PDF from HTML using a default client.

        Reads ``PRESA_API_KEY`` from the environment automatically.
        """
        client = Presa()
        return client.generate(GenerateOptions(html=html, **kwargs))  # type: ignore[arg-type]

    @staticmethod
    def from_url(
        url: str,
        **kwargs: object,
    ) -> GenerateResult:
        """Generate a PDF from a URL using a default client.

        Reads ``PRESA_API_KEY`` from the environment automatically.
        """
        client = Presa()
        return client.from_url(GenerateOptions(html="", url=url, **kwargs))  # type: ignore[arg-type]


PDF = _PDFNamespace()
