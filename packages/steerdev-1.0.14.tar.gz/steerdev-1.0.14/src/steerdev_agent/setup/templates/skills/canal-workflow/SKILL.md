# Canal Workflow Skill

Canal-based verification workflow for batching and reviewing agent PRs. Use when completing tasks in projects with canal workflow enabled. Canals are ephemeral integration branches that batch related PRs for consolidated human review. Replaces direct-to-dev merging when canals are active.

## When to Use

- After creating a PR, when merging to integration branch
- When checking canal status
- When a project uses canal-based verification (canal workflow enabled)

## Overview

Canals batch multiple feature PRs into consolidated, reviewable units. Instead of merging directly to dev, agents merge to a canal branch. Humans review the canal as one unit, then squash-merge to dev.

```
Agent work:     task/abc123  wave/1  task/def456  wave/2
                    |          |         |          |
Gate 1 (CI):    [unit tests, lint, typecheck, build pass?]
                    |          |         |          |
Canal merge:    [gh CLI merge to canal branch]
                    \         /           \        /
                   canal/1               canal/2
                      |                     |
Gate 2 (CI):    [integration tests on canal branch]
                      |                     |
Canal PR:       canal/1 -> dev         canal/2 -> dev
                      |                     |
Gate 3:         [human review & approval]
```

## Available Commands

### Check Canal Status
```bash
steerdev canal list
steerdev canal status CANAL_ID
steerdev canal next
```

### Create Canal (if none available)
```bash
steerdev canal create [--project-id ID] [--repo-id REPO_ID] [--base-branch BRANCH]
```

### Merge to Canal (after your PR's CI passes)
```bash
steerdev canal merge [--canal-id ID] [--task-id TASK_ID]
```

### Create Canal PR for Review (when canal is complete)
```bash
steerdev canal pr CANAL_ID
```

### Close a Canal
```bash
steerdev canal close CANAL_ID
```

## Workflow

1. Complete your task implementation normally (commit, push, create PR)
2. Wait for CI to pass on your feature branch (Gate 1)
3. Run `steerdev canal next` to find the target canal
4. If no canal available: `steerdev canal create`
5. Run `steerdev canal merge --task-id TASK_ID`
6. If merge succeeds: done. Canal integration tests will run automatically (Gate 2)
7. If merge conflicts: report blocker, do NOT force-push or resolve manually
8. When all tasks for this canal are complete: `steerdev canal pr CANAL_ID`

## Complete Workflow Example

```bash
# 1. Complete task and create PR normally
steerdev tasks update abc12345... --status started
steerdev git branch abc12345...
# ... implement task, commit changes ...
git push -u origin HEAD
steerdev git pr --title "Add user auth" --task-id abc12345...

# 2. Wait for CI to pass on feature branch (Gate 1)

# 3. Find target canal
steerdev canal next

# 4. If no canal available, create one
steerdev canal create

# 5. Merge to canal
steerdev canal merge --task-id abc12345...
# This merges your current branch into the canal via GitHub API

# 6. Mark task complete
steerdev tasks update abc12345... --status completed \
  --result "Implemented auth. Merged to canal/1."

# 7. When all tasks for this canal are done, create canal PR
steerdev canal pr <canal-id>
# Creates: canal/1 -> dev PR with summary of all merged branches
```

## Constraints

- Do NOT merge to a canal with failed CI
- Do NOT create a canal if max concurrent canals reached (the server enforces this)
- Do NOT attempt to resolve canal merge conflicts -- report a blocker
- Always check canal status before merging
- Canals are ephemeral -- each cascade starts fresh

## Prerequisites

- **GitHub CLI**: Required for merge operations. Install: https://cli.github.com
- **SteerDev API Key**: Set `STEERDEV_API_KEY` environment variable
- **Project ID**: Set `STEERDEV_PROJECT_ID` or use `--project-id` option
