"""Modal screen for selecting a workflow interactively."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label, OptionList
from textual.widgets.option_list import Option

from steerdev_agent.api.workflows import WorkflowsClient

if TYPE_CHECKING:
    from textual.app import ComposeResult


class WorkflowSelectScreen(ModalScreen[str | None]):
    """Fetch workflows from the API and let the user pick one.

    Dismisses with the selected workflow ID or ``None``.
    """

    DEFAULT_CSS = """
    WorkflowSelectScreen {
        align: center middle;
    }
    WorkflowSelectScreen > Vertical {
        width: 60;
        height: auto;
        max-height: 80%;
        background: $surface;
        border: thick $primary;
        padding: 1 2;
    }
    WorkflowSelectScreen OptionList {
        height: auto;
        max-height: 20;
        margin: 1 0;
    }
    WorkflowSelectScreen .buttons {
        height: auto;
        layout: horizontal;
        align: center middle;
    }
    WorkflowSelectScreen .buttons Button {
        margin: 0 1;
    }
    """

    def __init__(
        self,
        project_id: str,
        api_key: str | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(**kwargs)
        self._project_id = project_id
        self._api_key = api_key
        self._workflows: list[dict[str, str]] = []

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("[bold]Select a Workflow[/bold]")
            yield OptionList(id="workflow-list")
            with Vertical(classes="buttons"):
                yield Button("Select", variant="primary", id="btn-select")
                yield Button("No Workflow", variant="default", id="btn-none")

    async def on_mount(self) -> None:
        """Fetch workflows and populate the list."""
        option_list = self.query_one("#workflow-list", OptionList)

        try:
            async with WorkflowsClient(api_key=self._api_key) as client:
                workflows = await client.list_workflows(project_id=self._project_id)

            for wf in workflows:
                phases = len(wf.phases)
                desc = f" - {wf.description}" if wf.description else ""
                default_tag = " (default)" if wf.is_default else ""
                label = f"{wf.name}{desc} ({phases} phases){default_tag}"
                self._workflows.append({"id": wf.id, "name": wf.name})
                option_list.add_option(Option(label, id=wf.id))

            if not workflows:
                option_list.add_option(Option("No workflows available", id="__empty__"))

        except Exception:
            option_list.add_option(Option("Failed to fetch workflows", id="__error__"))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-none":
            self.dismiss(None)
        elif event.button.id == "btn-select":
            option_list = self.query_one("#workflow-list", OptionList)
            idx = option_list.highlighted
            if idx is not None and idx < len(self._workflows):
                self.dismiss(self._workflows[idx]["id"])
            else:
                self.dismiss(None)

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Double-click / enter on an option selects it."""
        idx = event.option_index
        if idx < len(self._workflows):
            self.dismiss(self._workflows[idx]["id"])
