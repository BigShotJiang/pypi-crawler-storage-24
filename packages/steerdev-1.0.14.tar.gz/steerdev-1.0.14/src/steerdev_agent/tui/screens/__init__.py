"""TUI screens for the SteerDev agent dashboard."""
