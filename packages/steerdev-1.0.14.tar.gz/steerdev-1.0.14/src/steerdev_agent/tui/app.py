"""Main Textual App for the SteerDev agent TUI dashboard."""

from __future__ import annotations

import socket
from pathlib import Path
from typing import Any, ClassVar

from textual.app import App, ComposeResult
from textual.binding import Binding, BindingType
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Label

from steerdev_agent.runner import Runner, RunState
from steerdev_agent.tui.runner_bridge import (
    AgentEvent,
    RunnerStateChanged,
    SessionCreated,
    StatsUpdated,
    TaskCompleted,
    TaskStarted,
    TUIRunnerBridge,
)
from steerdev_agent.tui.widgets.event_log import EventLogWidget
from steerdev_agent.tui.widgets.project_info import ProjectInfoWidget
from steerdev_agent.tui.widgets.stats_panel import StatsPanel
from steerdev_agent.tui.widgets.status_bar import StatusBarWidget
from steerdev_agent.tui.widgets.task_panel import TaskPanel
from steerdev_agent.tui.widgets.task_queue import TaskQueueWidget

_CSS_PATH = Path(__file__).parent / "styles.tcss"


class SteerDevTUI(App[None]):
    """Terminal dashboard for the SteerDev agent runner."""

    TITLE = "SteerDev Agent TUI"
    CSS_PATH = _CSS_PATH

    BINDINGS: ClassVar[list[BindingType]] = [
        Binding("q", "quit", "Quit"),
        Binding("ctrl+c", "stop_agent", "Stop Agent", priority=True),
        Binding("f5", "refresh_tasks", "Refresh"),
    ]

    def __init__(
        self,
        runner_kwargs: dict[str, Any],
        task_id: str | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(**kwargs)
        self._runner_kwargs = runner_kwargs
        self._task_id = task_id
        self._runner: Runner | None = None
        self._bridge: TUIRunnerBridge | None = None
        self._stop_requested = False

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        yield Header()

        with Horizontal():
            with Vertical(id="sidebar"):
                yield Label("PROJECT", classes="sidebar-section-title")
                yield ProjectInfoWidget(
                    project_id=self._runner_kwargs.get("project_id", "?"),
                    working_dir=self._runner_kwargs.get("working_directory", ".") or ".",
                    model=self._runner_kwargs.get("model"),
                    workflow_id=self._runner_kwargs.get("workflow_id"),
                    agent_name=self._runner_kwargs.get("agent_name"),
                    dry_run=self._runner_kwargs.get("dry_run", False),
                    classes="sidebar-section",
                )

                yield Label("TASK", classes="sidebar-section-title")
                yield TaskPanel(classes="sidebar-section", id="task-panel")

                yield Label("STATS", classes="sidebar-section-title")
                yield StatsPanel(classes="sidebar-section", id="stats-panel")

                yield Label("QUEUE", classes="sidebar-section-title")
                yield TaskQueueWidget(classes="sidebar-section", id="task-queue")

                yield Label("STATUS", classes="sidebar-section-title")
                yield StatusBarWidget(classes="sidebar-section", id="status-bar")

            with Vertical(id="event-log-container"):
                yield EventLogWidget(id="event-log")

        yield Footer()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def on_mount(self) -> None:
        """Create the runner, attach the bridge, and start in a worker."""
        self._runner = Runner(**self._runner_kwargs)
        self._bridge = TUIRunnerBridge(self)
        self._runner.set_observer(self._bridge)

        event_log = self.query_one("#event-log", EventLogWidget)
        dry_tag = " [DRY RUN]" if self._runner_kwargs.get("dry_run") else ""
        event_log.append_system_message(f"Session started{dry_tag}")

        # Kick off task queue refresh
        self._refresh_task_queue()

        # Register agent and create run record for platform visibility
        self.run_worker(self._register_and_start(), exclusive=True, name="runner")

    async def _register_and_start(self) -> None:
        """Register agent on the platform, create a run record, then start the runner."""
        event_log = self.query_one("#event-log", EventLogWidget)
        status_bar = self.query_one("#status-bar", StatusBarWidget)

        if not self._runner:
            return

        dry_run = self._runner_kwargs.get("dry_run", False)

        if not dry_run:
            # Step 1: Register agent on the platform
            agent_id = await self._register_agent()
            if agent_id:
                event_log.append_system_message(f"Agent registered: {agent_id[:12]}...")
                status_bar.mark_connected()
            else:
                event_log.append_system_message("Warning: agent registration failed")
                status_bar.mark_error()

            # Step 2: Create a run record for platform visibility
            try:
                db_run_id = await self._runner.create_run_record()
                if db_run_id:
                    self._runner.db_run_id = db_run_id
                    event_log.append_system_message(f"Run record: {db_run_id[:12]}...")
                else:
                    event_log.append_system_message("Warning: could not create run record")
            except Exception as exc:
                event_log.append_system_message(f"Run record error: {exc}")

        # Step 3: Run the agent
        await self._run_runner()

    async def _register_agent(self) -> str | None:
        """Register this agent on the platform via POST /agents."""
        import httpx

        from steerdev_agent.api.client import get_api_endpoint, get_api_key

        api_key = self._runner_kwargs.get("api_key") or get_api_key()
        api_base = get_api_endpoint()
        project_id = self._runner_kwargs.get("project_id", "")
        agent_name = self._runner_kwargs.get("agent_name") or f"tui-{socket.gethostname()}"
        agent_type = "claude"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{api_base}/agents",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "name": agent_name,
                        "project_id": project_id,
                        "application": agent_type,
                        "hostname": socket.gethostname(),
                    },
                )
                if response.status_code in (200, 201):
                    return response.json().get("id")
                return None
        except Exception:
            return None

    async def _run_runner(self) -> None:
        """Execute the runner's main loop."""
        if not self._runner:
            return
        try:
            await self._runner.run(task_id=self._task_id)
        except KeyboardInterrupt:
            pass
        except Exception as exc:
            event_log = self.query_one("#event-log", EventLogWidget)
            event_log.append_system_message(f"Runner error: {exc}")

        # After runner finishes, update status
        status = self.query_one("#status-bar", StatusBarWidget)
        status.run_state = "finished"

    # ------------------------------------------------------------------
    # Message handlers (from TUIRunnerBridge)
    # ------------------------------------------------------------------

    def on_runner_state_changed(self, message: RunnerStateChanged) -> None:
        status = self.query_one("#status-bar", StatusBarWidget)
        status.update_from_state(message.state)

        if message.state == RunState.RUNNING:
            status.mark_connected()

    def on_task_started(self, message: TaskStarted) -> None:
        panel = self.query_one("#task-panel", TaskPanel)
        panel.update_task(message.task, message.wave_context)

        event_log = self.query_one("#event-log", EventLogWidget)
        title = message.task.get("title", "Unknown")
        event_log.append_system_message(f"--- Task started: {title} ---")

    def on_task_completed(self, message: TaskCompleted) -> None:
        panel = self.query_one("#task-panel", TaskPanel)
        panel.mark_completed(message.result)

        event_log = self.query_one("#event-log", EventLogWidget)
        success = message.result.get("success", False)
        tag = "completed" if success else "failed"
        event_log.append_system_message(f"--- Task {tag} ---")

        # Refresh task queue after completion
        self._refresh_task_queue()

    def on_agent_event(self, message: AgentEvent) -> None:
        event_log = self.query_one("#event-log", EventLogWidget)
        event_log.append_event(message.event)

    def on_stats_updated(self, message: StatsUpdated) -> None:
        stats = self.query_one("#stats-panel", StatsPanel)
        stats.update_stats(message.stats)

        status = self.query_one("#status-bar", StatusBarWidget)
        status.increment_activity()

    def on_session_created(self, message: SessionCreated) -> None:
        event_log = self.query_one("#event-log", EventLogWidget)
        event_log.append_system_message(f"Session: {message.session_id[:12]}...")

        status = self.query_one("#status-bar", StatusBarWidget)
        status.mark_connected()

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def action_stop_agent(self) -> None:
        """First ctrl+c stops the agent subprocess; second exits the TUI."""
        if self._stop_requested:
            self.exit()
            return

        self._stop_requested = True
        event_log = self.query_one("#event-log", EventLogWidget)
        event_log.append_system_message("Stopping agent... (press Ctrl+C again to exit)")

        if self._runner and self._runner._executor and self._runner._executor.is_running:
            self.run_worker(self._runner._executor.stop(), name="stop-agent")

    def action_refresh_tasks(self) -> None:
        """Refresh the task queue from the API."""
        self._refresh_task_queue()

    def _refresh_task_queue(self) -> None:
        """Fetch upcoming tasks in a worker."""
        self.run_worker(self._fetch_tasks(), name="fetch-tasks")

    async def _fetch_tasks(self) -> None:
        """Fetch tasks from the API and update the queue widget."""
        project_id = self._runner_kwargs.get("project_id", "")
        api_key = self._runner_kwargs.get("api_key")
        if not project_id:
            return

        try:
            from steerdev_agent.api.tasks import TasksClient

            with TasksClient(api_key=api_key) as client:
                tasks = client.list_tasks(project_id=project_id, limit=15)

            queue = self.query_one("#task-queue", TaskQueueWidget)
            queue.set_tasks(tasks)
        except Exception:
            pass  # Silently handle — status bar already shows connectivity
