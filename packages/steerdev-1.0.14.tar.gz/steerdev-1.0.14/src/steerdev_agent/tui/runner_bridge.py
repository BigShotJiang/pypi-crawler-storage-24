"""Bridge between Runner observer callbacks and Textual messages."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from textual.message import Message

if TYPE_CHECKING:
    from textual.app import App

    from steerdev_agent.executor.base import StreamEvent
    from steerdev_agent.prompt.builder import WaveContext
    from steerdev_agent.runner import RunState


# ---------------------------------------------------------------------------
# Textual Messages posted by the bridge
# ---------------------------------------------------------------------------


class RunnerStateChanged(Message):
    """Runner state machine changed."""

    def __init__(self, state: RunState) -> None:
        super().__init__()
        self.state = state


class TaskStarted(Message):
    """A task has begun execution."""

    def __init__(self, task: dict[str, Any], wave_context: WaveContext | None) -> None:
        super().__init__()
        self.task = task
        self.wave_context = wave_context


class TaskCompleted(Message):
    """A task has finished (success or failure)."""

    def __init__(self, task: dict[str, Any], result: dict[str, Any]) -> None:
        super().__init__()
        self.task = task
        self.result = result


class AgentEvent(Message):
    """A streamed event from the agent subprocess."""

    def __init__(self, event: StreamEvent) -> None:
        super().__init__()
        self.event = event


class StatsUpdated(Message):
    """Run statistics have been updated."""

    def __init__(self, stats: dict[str, Any]) -> None:
        super().__init__()
        self.stats = stats


class SessionCreated(Message):
    """A new session was created for a task."""

    def __init__(self, session_id: str) -> None:
        super().__init__()
        self.session_id = session_id


# ---------------------------------------------------------------------------
# TUIRunnerBridge — implements RunnerObserver, posts Textual messages
# ---------------------------------------------------------------------------


class TUIRunnerBridge:
    """Adapts RunnerObserver callbacks into Textual Message posts.

    Instantiate with a reference to the Textual App, then pass to
    ``runner.set_observer(bridge)``.
    """

    def __init__(self, app: App[object]) -> None:
        self._app = app

    # -- RunnerObserver protocol methods ------------------------------------

    async def on_state_change(self, state: RunState) -> None:
        self._app.post_message(RunnerStateChanged(state))

    async def on_task_started(self, task: dict[str, Any], wave_context: WaveContext | None) -> None:
        self._app.post_message(TaskStarted(task, wave_context))

    async def on_task_completed(self, task: dict[str, Any], result: dict[str, Any]) -> None:
        self._app.post_message(TaskCompleted(task, result))

    async def on_event(self, event: StreamEvent) -> None:
        self._app.post_message(AgentEvent(event))

    async def on_stats_update(self, stats: dict[str, Any]) -> None:
        self._app.post_message(StatsUpdated(stats))

    async def on_session_created(self, session_id: str) -> None:
        self._app.post_message(SessionCreated(session_id))
