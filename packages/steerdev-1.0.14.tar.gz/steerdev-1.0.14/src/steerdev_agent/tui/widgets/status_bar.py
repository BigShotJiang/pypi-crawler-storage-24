"""Bottom status bar showing API connection and run state."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.reactive import reactive
from textual.widgets import Static

if TYPE_CHECKING:
    from steerdev_agent.runner import RunState


class StatusBarWidget(Static):
    """Shows API connectivity, activity report count, and runner state."""

    DEFAULT_CSS = """
    StatusBarWidget {
        height: auto;
        padding: 0 1;
    }
    """

    api_status: reactive[str] = reactive("Connecting")
    activity_count: reactive[int] = reactive(0)
    run_state: reactive[str] = reactive("starting")

    def render(self) -> str:
        if self.api_status == "Connected":
            api = "[green]Connected[/green]"
        elif self.api_status == "Error":
            api = "[red]Error[/red]"
        else:
            api = f"[yellow]{self.api_status}[/yellow]"

        return f"API: {api} | Reports: {self.activity_count} | {self.run_state}"

    def update_from_state(self, state: RunState) -> None:
        """Update the run state display."""
        self.run_state = state.value

    def mark_connected(self) -> None:
        """Mark the API as connected (inferred from successful calls)."""
        self.api_status = "Connected"

    def mark_error(self) -> None:
        """Mark the API as errored."""
        self.api_status = "Error"

    def increment_activity(self) -> None:
        """Bump the activity report counter."""
        self.activity_count += 1
