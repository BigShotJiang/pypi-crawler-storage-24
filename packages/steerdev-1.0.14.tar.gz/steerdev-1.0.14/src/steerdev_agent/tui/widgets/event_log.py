"""Scrolling event log widget with color-coded entries by event type."""

from __future__ import annotations

from rich.text import Text
from textual.widgets import RichLog

from steerdev_agent.executor.base import EventType, StreamEvent

# Color map for event types
_EVENT_STYLES: dict[EventType, str] = {
    EventType.SYSTEM: "dim",
    EventType.USER: "blue",
    EventType.ASSISTANT: "cyan",
    EventType.TOOL_USE: "yellow",
    EventType.TOOL_RESULT: "dim green",
    EventType.ERROR: "bold red",
    EventType.RESULT: "bold green",
}

# Friendly labels for the event log
_EVENT_LABELS: dict[EventType, str] = {
    EventType.SYSTEM: "system",
    EventType.USER: "user",
    EventType.ASSISTANT: "assistant",
    EventType.TOOL_USE: "tool",
    EventType.TOOL_RESULT: "result",
    EventType.ERROR: "error",
    EventType.RESULT: "done",
}

# Tool classification sets (mirrors the web app's categories)
_CODE_CHANGE_TOOLS = {
    "Write",
    "write",
    "StrReplace",
    "str_replace",
    "str_replace_editor",
    "EditNotebook",
    "edit_notebook",
    "Edit",
    "edit",
    "Delete",
    "delete",
    "NotebookEdit",
}
_FILE_READ_TOOLS = {"Read", "read", "ReadFile", "read_file"}
_SEARCH_TOOLS = {
    "Grep",
    "grep",
    "Glob",
    "glob",
    "SemanticSearch",
    "semantic_search",
    "Search",
    "search",
}
_SHELL_TOOLS = {"Shell", "shell", "Bash", "bash", "execute_command"}


class EventLogWidget(RichLog):
    """RichLog-based event stream, color-coded by EventType."""

    DEFAULT_CSS = """
    EventLogWidget {
        height: 1fr;
        border: none;
    }
    """

    def __init__(self, **kwargs: object) -> None:
        super().__init__(auto_scroll=True, max_lines=10_000, wrap=True, **kwargs)

    def append_event(self, event: StreamEvent) -> None:
        """Format and append an event to the log."""
        ts = event.timestamp.strftime("%H:%M:%S")
        style = _EVENT_STYLES.get(event.event_type, "white")
        label = _EVENT_LABELS.get(event.event_type, event.event_type.value)

        # Build content based on event type
        content = _format_event_content(event)
        if not content:
            return  # Skip empty events

        line = Text()
        line.append(f"[{ts}] ", style="dim")
        line.append(f"{label}: ", style=style)
        line.append(content)

        self.write(line)

    def append_system_message(self, message: str) -> None:
        """Append a plain system-level message."""
        line = Text()
        line.append(message, style="dim italic")
        self.write(line)


# ---------------------------------------------------------------------------
# Smart formatting helpers
# ---------------------------------------------------------------------------


def _extract_text(value: object) -> str:
    """Pull readable text from nested content structures."""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                parts.append(str(item.get("text", item.get("content", ""))))
        return " ".join(p for p in parts if p)
    if isinstance(value, dict):
        return _extract_text(value.get("text", value.get("content", "")))
    return ""


def _tool_summary(tool_name: str, args: dict[str, object]) -> str:
    """Build a human-friendly one-line summary for a tool invocation."""
    path = str(
        args.get("path", "")
        or args.get("file_path", "")
        or args.get("filepath", "")
        or args.get("target_notebook", "")
    )

    if tool_name in _CODE_CHANGE_TOOLS:
        if tool_name in {"Write", "write"}:
            return f"Writing {path}" if path else "Writing file"
        if tool_name in {"Delete", "delete"}:
            return f"Deleting {path}" if path else "Deleting file"
        return f"Editing {path}" if path else "Editing file"

    if tool_name in _FILE_READ_TOOLS:
        return f"Reading {path}" if path else "Reading file"

    if tool_name in _SEARCH_TOOLS:
        pattern = str(
            args.get("pattern", "")
            or args.get("query", "")
            or args.get("glob_pattern", "")
            or args.get("search_term", "")
        )
        if pattern:
            return f"Searching: {pattern[:80]}"
        return "Searching..."

    if tool_name in _SHELL_TOOLS:
        command = str(args.get("command", ""))
        if command:
            return command[:100] + ("..." if len(command) > 100 else "")
        return "Running command"

    # Generic fallback: just show tool name
    return tool_name


def _format_event_content(event: StreamEvent) -> str:
    """Extract a human-readable summary from the event data."""
    data = event.data
    etype = event.event_type

    if etype == EventType.ASSISTANT:
        # Extract text content from the message
        message = data.get("message", {})
        content = ""
        if isinstance(message, dict):
            content = _extract_text(message.get("content", ""))
        else:
            content = _extract_text(data.get("content", data.get("message", "")))

        if not content or not content.strip():
            return "Thinking..."
        # Show a brief preview of the assistant's response
        text = content.strip()
        if len(text) > 120:
            return text[:120] + "..."
        return text

    if etype == EventType.TOOL_USE:
        tool = str(data.get("tool", data.get("name", data.get("tool_name", "unknown"))))
        args = data.get("args", data.get("input", data.get("parameters", {})))
        summary = _tool_summary(tool, args) if isinstance(args, dict) else tool
        return f"Executing: {summary}"

    if etype == EventType.TOOL_RESULT:
        is_error = bool(data.get("is_error") or data.get("error"))
        tool_name = str(data.get("tool_name", data.get("name", "")))
        if is_error:
            err = str(data.get("error", data.get("message", "failed")))
            return f"✗ {tool_name + ': ' if tool_name else ''}{err[:100]}"
        # Brief success message
        if tool_name in _CODE_CHANGE_TOOLS:
            return f"✓ {tool_name} completed"
        if tool_name in _FILE_READ_TOOLS:
            content = data.get("content", data.get("output", ""))
            size = len(str(content)) if content else 0
            return f"✓ {tool_name} ({size} chars)"
        # For other tools, show a short preview
        content = data.get("content", data.get("output", data.get("result", "")))
        if isinstance(content, str) and content.strip():
            preview = content.strip()[:80]
            return f"✓ {preview}{'...' if len(str(content)) > 80 else ''}"
        return f"✓ Done{' (' + tool_name + ')' if tool_name else ''}"

    if etype == EventType.ERROR:
        return str(data.get("error", data.get("message", str(data))))[:200]

    if etype == EventType.RESULT:
        result = data.get("result", data)
        if isinstance(result, dict):
            code = result.get("exit_code", "?")
            return f"Finished (exit code {code})"
        return str(result)[:200]

    if etype == EventType.SYSTEM:
        return str(data.get("message", data.get("text", str(data))))[:200]

    if etype == EventType.USER:
        content = _extract_text(data.get("content", data.get("message", "")))
        if content:
            return content[:200] + ("..." if len(content) > 200 else "")
        return ""

    return str(data)[:200]
