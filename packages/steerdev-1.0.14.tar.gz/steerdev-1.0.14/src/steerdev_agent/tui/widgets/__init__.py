"""TUI widgets for the SteerDev agent dashboard."""
