"""Static project information panel."""

from __future__ import annotations

from textual.widgets import Static


class ProjectInfoWidget(Static):
    """Displays static project/run configuration details."""

    DEFAULT_CSS = """
    ProjectInfoWidget {
        height: auto;
        padding: 0 1;
    }
    """

    def __init__(
        self,
        *,
        project_id: str,
        working_dir: str,
        model: str | None = None,
        workflow_id: str | None = None,
        agent_name: str | None = None,
        dry_run: bool = False,
        **kwargs: object,
    ) -> None:
        super().__init__(**kwargs)
        self._project_id = project_id
        self._working_dir = working_dir
        self._model = model or "default"
        self._workflow_id = workflow_id or "none"
        self._agent_name = agent_name or "auto"
        self._dry_run = dry_run

    def render(self) -> str:
        lines = [
            f"[bold]{self._project_id[:12]}[/bold]",
            f"[dim]{self._working_dir}[/dim]",
            f"Model: {self._model}",
        ]
        if self._workflow_id != "none":
            lines.append(f"Workflow: {self._workflow_id[:12]}")
        if self._agent_name != "auto":
            lines.append(f"Agent: {self._agent_name}")
        if self._dry_run:
            lines.append("[bold yellow][DRY RUN][/bold yellow]")
        return "\n".join(lines)
