"""Live run statistics panel with timer."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from textual.reactive import reactive
from textual.widgets import Static


class StatsPanel(Static):
    """Shows tasks executed/succeeded/failed, events sent, and live duration."""

    DEFAULT_CSS = """
    StatsPanel {
        height: auto;
        padding: 0 1;
    }
    """

    tasks_executed: reactive[int] = reactive(0)
    tasks_succeeded: reactive[int] = reactive(0)
    tasks_failed: reactive[int] = reactive(0)
    events_sent: reactive[int] = reactive(0)
    _duration_str: reactive[str] = reactive("0s")

    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)
        self._start_time: datetime | None = None

    def on_mount(self) -> None:
        """Start the timer on mount."""
        self._start_time = datetime.now(UTC)
        self.set_interval(1.0, self._update_duration)

    def _update_duration(self) -> None:
        """Tick the duration counter."""
        if self._start_time:
            elapsed = (datetime.now(UTC) - self._start_time).total_seconds()
            mins, secs = divmod(int(elapsed), 60)
            if mins > 0:
                self._duration_str = f"{mins}m {secs:02d}s"
            else:
                self._duration_str = f"{secs}s"

    def render(self) -> str:
        return (
            f"Tasks: {self.tasks_executed} "
            f"([green]{self.tasks_succeeded}[/green] ok"
            f" / [red]{self.tasks_failed}[/red] fail)\n"
            f"Events: {self.events_sent}\n"
            f"Duration: {self._duration_str}"
        )

    def update_stats(self, stats: dict[str, Any]) -> None:
        """Bulk-update stats from the runner."""
        self.tasks_executed = stats.get("tasks_executed", self.tasks_executed)
        self.tasks_succeeded = stats.get("tasks_succeeded", self.tasks_succeeded)
        self.tasks_failed = stats.get("tasks_failed", self.tasks_failed)
        self.events_sent = stats.get("events_sent", self.events_sent)
