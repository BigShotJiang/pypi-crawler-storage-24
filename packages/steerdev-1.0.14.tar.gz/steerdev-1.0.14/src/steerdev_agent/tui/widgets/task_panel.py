"""Panel showing the current task and wave context."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from textual.reactive import reactive
from textual.widgets import Static

if TYPE_CHECKING:
    from steerdev_agent.prompt.builder import WaveContext


class TaskPanel(Static):
    """Displays the current task title, ID, priority, wave info, and status."""

    DEFAULT_CSS = """
    TaskPanel {
        height: auto;
        padding: 0 1;
    }
    """

    task_title: reactive[str] = reactive("Waiting...")
    task_id: reactive[str] = reactive("")
    priority: reactive[int] = reactive(3)
    status: reactive[str] = reactive("pending")
    wave_number: reactive[int] = reactive(0)
    total_waves: reactive[int] = reactive(0)

    def render(self) -> str:
        lines: list[str] = []
        lines.append(f"[bold]{self.task_title}[/bold]")
        if self.task_id:
            lines.append(f"[dim]{self.task_id[:12]}[/dim]")

        priority_names = {1: "urgent", 2: "high", 3: "medium", 4: "low", 0: "none"}
        pri = priority_names.get(self.priority, "?")
        lines.append(f"Priority: {pri} | {self.status}")

        if self.wave_number > 0:
            lines.append(f"Wave {self.wave_number}/{self.total_waves}")

        return "\n".join(lines)

    def update_task(self, task: dict[str, Any], wave_context: WaveContext | None) -> None:
        """Update the panel with a new task."""
        self.task_title = task.get("title", "Unknown")
        self.task_id = task.get("id", "")
        self.priority = task.get("priority", 3)
        self.status = "running"
        if wave_context:
            self.wave_number = wave_context.wave_number
            self.total_waves = wave_context.total_waves
        else:
            self.wave_number = 0
            self.total_waves = 0

    def mark_completed(self, result: dict[str, Any]) -> None:
        """Update the panel to reflect task completion."""
        if result.get("success"):
            self.status = "[green]completed[/green]"
        else:
            self.status = f"[red]failed[/red]: {result.get('error', '')[:40]}"
