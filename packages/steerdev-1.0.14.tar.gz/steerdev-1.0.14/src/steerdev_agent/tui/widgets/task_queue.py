"""Upcoming tasks queue panel."""

from __future__ import annotations

from typing import Any

from textual.reactive import reactive
from textual.widgets import Static

_STATUS_ICONS: dict[str, str] = {
    "completed": "[green]done[/green]",
    "started": "[yellow]>>>[/yellow]",
    "unstarted": "[cyan]todo[/cyan]",
    "backlog": "[dim]backlog[/dim]",
    "canceled": "[dim]cancel[/dim]",
}


class TaskQueueWidget(Static):
    """Shows upcoming tasks with status icons. Refreshable."""

    DEFAULT_CSS = """
    TaskQueueWidget {
        height: auto;
        padding: 0 1;
    }
    """

    _tasks: reactive[list[dict[str, Any]]] = reactive(list, always_update=True)

    def render(self) -> str:
        if not self._tasks:
            return "[dim]No queued tasks[/dim]"
        lines: list[str] = []
        for t in self._tasks[:8]:
            icon = _STATUS_ICONS.get(t.get("status", ""), "[dim]?[/dim]")
            title = t.get("title", "Untitled")[:35]
            lines.append(f"  {icon} {title}")
        if len(self._tasks) > 8:
            lines.append(f"  [dim]... +{len(self._tasks) - 8} more[/dim]")
        return "\n".join(lines)

    def set_tasks(self, tasks: list[dict[str, Any]]) -> None:
        """Replace the task list."""
        self._tasks = list(tasks)
