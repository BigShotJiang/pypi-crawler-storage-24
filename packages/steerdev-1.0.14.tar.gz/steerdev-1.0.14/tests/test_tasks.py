"""Tests for task management utilities."""

from steerdev_agent.api.tasks import (
    VALID_STATUS_TRANSITIONS,
    VALID_STATUSES,
    get_priority_display,
    validate_status_transition,
)


class TestValidateStatusTransition:
    """Tests for validate_status_transition."""

    def test_same_status_is_valid(self):
        """Transitioning to the same status should always be valid."""
        for status in VALID_STATUSES:
            is_valid, error = validate_status_transition(status, status)
            assert is_valid is True
            assert error is None

    def test_backlog_to_unstarted(self):
        """backlog -> unstarted is allowed."""
        is_valid, error = validate_status_transition("backlog", "unstarted")
        assert is_valid is True
        assert error is None

    def test_backlog_to_canceled(self):
        """backlog -> canceled is allowed."""
        is_valid, error = validate_status_transition("backlog", "canceled")
        assert is_valid is True
        assert error is None

    def test_backlog_to_started_invalid(self):
        """backlog -> started is not allowed (must go through unstarted)."""
        is_valid, error = validate_status_transition("backlog", "started")
        assert is_valid is False
        assert error is not None
        assert "backlog" in error
        assert "started" in error

    def test_backlog_to_completed_invalid(self):
        """backlog -> completed is not allowed."""
        is_valid, error = validate_status_transition("backlog", "completed")
        assert is_valid is False
        assert error is not None

    def test_unstarted_to_started(self):
        """unstarted -> started is allowed."""
        is_valid, error = validate_status_transition("unstarted", "started")
        assert is_valid is True
        assert error is None

    def test_unstarted_to_backlog(self):
        """unstarted -> backlog is allowed (move back)."""
        is_valid, error = validate_status_transition("unstarted", "backlog")
        assert is_valid is True
        assert error is None

    def test_unstarted_to_canceled(self):
        """unstarted -> canceled is allowed."""
        is_valid, error = validate_status_transition("unstarted", "canceled")
        assert is_valid is True
        assert error is None

    def test_unstarted_to_completed_invalid(self):
        """unstarted -> completed is not allowed (must start first)."""
        is_valid, error = validate_status_transition("unstarted", "completed")
        assert is_valid is False
        assert error is not None

    def test_started_to_completed(self):
        """started -> completed is allowed."""
        is_valid, error = validate_status_transition("started", "completed")
        assert is_valid is True
        assert error is None

    def test_started_to_canceled(self):
        """started -> canceled is allowed."""
        is_valid, error = validate_status_transition("started", "canceled")
        assert is_valid is True
        assert error is None

    def test_started_to_backlog_invalid(self):
        """started -> backlog is not allowed."""
        is_valid, error = validate_status_transition("started", "backlog")
        assert is_valid is False
        assert error is not None

    def test_started_to_unstarted_invalid(self):
        """started -> unstarted is not allowed."""
        is_valid, error = validate_status_transition("started", "unstarted")
        assert is_valid is False
        assert error is not None

    def test_completed_is_terminal(self):
        """completed is a terminal state - no transitions allowed."""
        for target in ["backlog", "unstarted", "started", "canceled"]:
            is_valid, error = validate_status_transition("completed", target)
            assert is_valid is False
            assert error is not None
            assert "terminal state" in error.lower() or "none" in error.lower()

    def test_canceled_is_terminal(self):
        """canceled is a terminal state - no transitions allowed."""
        for target in ["backlog", "unstarted", "started", "completed"]:
            is_valid, error = validate_status_transition("canceled", target)
            assert is_valid is False
            assert error is not None

    def test_unknown_current_status(self):
        """Unknown current status should fail (not in transitions map)."""
        is_valid, error = validate_status_transition("unknown", "started")
        assert is_valid is False
        assert error is not None

    def test_all_valid_transitions_covered(self):
        """Every defined transition should validate as valid."""
        for current, targets in VALID_STATUS_TRANSITIONS.items():
            for target in targets:
                is_valid, error = validate_status_transition(current, target)
                assert is_valid is True, f"{current} -> {target} should be valid"
                assert error is None


class TestGetPriorityDisplay:
    """Tests for get_priority_display."""

    def test_urgent(self):
        assert get_priority_display(1) == "Urgent (1)"

    def test_high(self):
        assert get_priority_display(2) == "High (2)"

    def test_medium(self):
        assert get_priority_display(3) == "Medium (3)"

    def test_low(self):
        assert get_priority_display(4) == "Low (4)"

    def test_none_priority(self):
        assert get_priority_display(0) == "None (0)"

    def test_null_priority(self):
        assert get_priority_display(None) == "N/A"

    def test_unknown_priority(self):
        result = get_priority_display(99)
        assert "Unknown" in result
        assert "99" in result
