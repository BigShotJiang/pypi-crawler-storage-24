#!/bin/sh
echo the argument count is $#
