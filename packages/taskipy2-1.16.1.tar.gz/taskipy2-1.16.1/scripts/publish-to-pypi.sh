#!/bin/sh
set -e

PYPI_TOKEN=""
ANNOUNCE_MAILING_LIST="~eugenetriguba/taskipy2-announce@lists.sr.ht"

main() {
  parse_args "$@"
  uv build
  uv publish --token "$PYPI_TOKEN"
  send_announcement_email
}

usage() {
  echo "Usage: $0 [-h|--help] -t|--token TOKEN"
  echo ""
  echo "Options:"
  echo "  -h, --help    Show this help message and exit"
  echo "  -t, --token   Required PyPI token for publishing the package"
  echo ""
  echo "Environment Variables:"
  echo "  SMTP_HOST: The SMTP host to send an announcement email from."
  echo "  SMTP_FROM: The email address in the announcement email 'from' field."
  echo "  SMTP_USER: The username to login the SMTP host with."
  echo "  SMTP_PASSWORD: The password associated with the username in the SMTP host."
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
    -h | --help)
      usage
      exit 0
      ;;
    -t | --token)
      PYPI_TOKEN="$2"
      shift 2
      ;;
    *)
      usage
      exit 1
      ;;
    esac
  done
}

send_announcement_email() {
  _pyproject_version=$(grep '^version = ' pyproject.toml | sed 's/version = "\(.*\)"/\1/')
  _changelog_body=$(extract_changelog_section "$_pyproject_version")

  cat <<EOF >mail.txt
From: ${SMTP_FROM}
To: ${ANNOUNCE_MAILING_LIST}
Subject: [taskipy2] v${_pyproject_version} released
Message-ID: <$(date +%s).$$@${SMTP_HOST}>
Date: $(date -R)

Hi all,

taskipy2 v${_pyproject_version} has been released and is now available on PyPI.

  pip install --upgrade taskipy2

What's new in v${_pyproject_version}:

${_changelog_body}

Full changelog: https://git.sr.ht/~eugenetriguba/taskipy2/tree/main/item/CHANGELOG.md

Regards,
Eugene Triguba
EOF

  curl \
    --silent \
    --show-error \
    --ssl-reqd \
    --url "smtp://${SMTP_HOST}:587" \
    --user "${SMTP_USER}:${SMTP_PASSWORD}" \
    --mail-from "$SMTP_FROM" \
    --mail-rcpt "$ANNOUNCE_MAILING_LIST" \
    --upload-file mail.txt

  echo "Announcement email sent to $ANNOUNCE_MAILING_LIST"
}

extract_changelog_section() {
  _changelog_version="$1"
  awk "
    /^\#\# \[$_changelog_version\]/ { found=1; next }
    found && /^\#\# \[/  { exit }
    found                { print }
  " CHANGELOG.md |
    sed -e 's/^### \(.*\)/\1:/' \
      -e '/./,$!d'
}

main "$@"
