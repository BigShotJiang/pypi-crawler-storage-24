#!/bin/sh
set -e

PYTHON_VERSION="3.14"

main() {
  uv python install "$PYTHON_VERSION"
  uv python pin "$PYTHON_VERSION"
  uv sync --group lint
  uv run task lint
}

main "$@"
