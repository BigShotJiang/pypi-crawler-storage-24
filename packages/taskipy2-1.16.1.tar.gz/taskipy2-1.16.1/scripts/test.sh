#!/bin/sh
set -e

PYTHON_VERSION="3.14"

main() {
  parse_args "$@"

  # NOTE: Python versions <= 3.8 do not have pre-built binary support with uv.
  # Therefore, instead, we're using docker to download a pre-built image with
  # an older version of Python installed.
  if echo "3.6" | grep -qw "$PYTHON_VERSION"; then
    export_requirements_txt_file_for_py36
    run_in_docker "$PYTHON_VERSION" "
      pip install -r requirements.txt
      pytest -v
    "
  elif echo "3.7 3.8" | grep -qw "$PYTHON_VERSION"; then
    uv_install_script=$(get_uv_install_script_commands)
    run_in_docker "$PYTHON_VERSION" "
      $uv_install_script
      export UV_PROJECT_ENVIRONMENT=\".venv-$PYTHON_VERSION\"
      uv sync --group test
      uv run task test
    "
  else
    export UV_PROJECT_ENVIRONMENT=".venv-$PYTHON_VERSION"
    uv python install "$PYTHON_VERSION"
    uv python pin "$PYTHON_VERSION"
    uv sync --group test
    uv run task test
  fi
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
    --python-version)
      shift
      PYTHON_VERSION="$1"
      ;;
    *)
      echo "Unknown argument: $1"
      exit 1
      ;;
    esac
    shift
  done
}

run_in_docker() {
  version="$1"
  script="
    echo \"$version\" > .python-version
    $2
  "
  docker run \
    --rm \
    --volume "$(pwd)":/app \
    --workdir /app \
    "python:$version-alpine" \
    sh -c "$script"
}

export_requirements_txt_file_for_py36() {
  # Python 3.6 isn't supported at all by uv (uv tries to use a 'text' keyword
  # argument in a subprocess open call which doesn't exist until Python 3.7).
  # Therefore, we need to export a requirements.txt file on-demand and then
  # install it in a 3.6 container via pip.
  uv_install_script=$(get_uv_install_script_commands)
  run_in_docker "3.7" "
    $uv_install_script
    uv export --group test --no-editable --no-hashes > requirements.txt
  "
}

get_uv_install_script_commands() {
  echo "
    apk add curl
    curl -fsSL https://astral.sh/uv/install.sh | sh
    export PATH=\"\$HOME/.local/bin:\$PATH\"
  "
}

main "$@"
