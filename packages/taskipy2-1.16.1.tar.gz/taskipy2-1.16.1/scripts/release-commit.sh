#!/bin/sh
set -e

main() {
  if [ $# -ne 1 ]; then
    echo "Usage: $0 <version>"
    exit 1
  fi

  VERSION="$1"
  DATE=$(date +%Y-%m-%d)

  sed -i "" "s/^version = \".*\"/version = \"$VERSION\"/" pyproject.toml
  sed -i "" "s/^## \[Unreleased\]/## [$VERSION] - $DATE/" CHANGELOG.md

  git add pyproject.toml CHANGELOG.md
  git commit -m "Release version v$VERSION"
  git tag "$VERSION"

  git show HEAD
  echo ""
  git log --oneline -5
  echo ""

  printf "Push commit and tag v%s? [y/N] " "$VERSION"
  read -r CONFIRM
  case "$CONFIRM" in
  [yY]) ;;
  *)
    echo "Aborted."
    exit 1
    ;;
  esac

  git push
  git push origin "$VERSION"
}

main "$@"
