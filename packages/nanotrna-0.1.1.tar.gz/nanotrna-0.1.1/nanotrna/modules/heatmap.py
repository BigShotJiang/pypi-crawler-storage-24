import time
import typer
from typing import Optional
from typing_extensions import Annotated
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..utils.heatmap import generate_heatmap

app = typer.Typer()

@app.command()
def heatmap(
    fasta: Annotated[str, typer.Option("--fasta", "-f", help="Input tRNA alignment FASTA file.")],
    errfile: Annotated[str, typer.Option("--errfile", "-e", help="Error rate data file (TSV or gzipped TSV).")],
    output: Annotated[str, typer.Option("--output", "-o", help="Output file prefix.")] = "tRNA_heatmap",
    title: Annotated[str, typer.Option("--title", help="Title for the heatmap.")] = "tRNA Modification Error Rates",
    cmap: Annotated[str, typer.Option("--cmap", help="Color map for heatmap.")] = "RdBu_r",
    maxv: Annotated[Optional[float], typer.Option("--maxv", help="Maximum absolute value for color scale (auto if not set).")] = None,
    figwidth: Annotated[float, typer.Option("--figwidth", help="Figure width in inches.")] = 25,
    figheight: Annotated[float, typer.Option("--figheight", help="Figure height in inches.")] = 8,
    dpi: Annotated[int, typer.Option("--dpi", help="DPI for output image.")] = 300,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Enable verbose output.")] = False,
    save_csv: Annotated[bool, typer.Option("--save-csv", help="Save data matrix as CSV file.")] = False,
):
    """
    Generate heatmap of tRNA modification error rates from alignment data.
    """
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        try:
            progress.add_task(description="Generating heatmap...", total=None)
            start = time.time()
            generate_heatmap(
                fasta=fasta,
                errfile=errfile,
                output=output,
                title=title,
                cmap=cmap,
                maxv=maxv,
                figsize=(figwidth, figheight),
                dpi=dpi,
                verbose=verbose,
                save_csv=save_csv,
            )
            end = time.time()
            time_cost = f"{(end - start) // 3600}h{((end - start) % 3600) // 60}m{(end - start) % 60:.2f}s"
            print(f"Heatmap generation Done, time cost: {time_cost}")
            progress.add_task(description=f"Heatmap generation Done, time cost: {time_cost}", total=None)
        except Exception as e:
            print(f"Error: {e}")
            progress.add_task(description="Heatmap generation Failed", total=None)
            exit(1)