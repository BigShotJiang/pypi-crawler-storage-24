import time
import typer
from typing_extensions import Annotated
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..utils.annotate import add_base_column

app = typer.Typer()

@app.command()
def addBaseColumn(
    mismatch: Annotated[str, typer.Option("--mismatch", "-m", help="Mismatch rate file (TSV, possibly gzipped).")],
    reference: Annotated[str, typer.Option("--reference", "-r", help="Reference FASTA file.")],
    output: Annotated[str, typer.Option("--output", "-o", help="Output file path.")],
    ):
    """
    Add a column of actual base to mismatch rate file.
    """
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        try:
            progress.add_task(description="Adding base column...", total=None)
            start = time.time()
            add_base_column(mismatch, reference, output)
            end = time.time()
            time_cost = f"{(end - start) // 3600}h{((end - start) % 3600) // 60}m{(end - start) % 60:.2f}s"
            print(f"Adding base column Done, time cost: {time_cost}")
            progress.add_task(description=f"Adding base column Done, time cost: {time_cost}", total=None)
        except Exception as e:
            print(f"Error: {e}")
            progress.add_task(description="Adding base column Failed", total=None)
            exit(1)