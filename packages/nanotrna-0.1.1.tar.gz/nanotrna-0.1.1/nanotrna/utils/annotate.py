# -*- coding: utf-8 -*-
__author__ = "legendzdy@dingtalk.com"
"""
Author: legendzdy@dingtalk.com
Data: 20250319
Description:
Add base column to mismatch rate file.
"""

import gzip
from typing import Dict, TextIO

def parse_fasta(fasta_file: str) -> Dict[str, str]:
    """
    Parse FASTA file into dictionary of tRNA name -> sequence.
    Args:
        fasta_file: Path to FASTA file.
    Returns:
        Dictionary mapping tRNA name (without '>') to sequence string.
    """
    seqs = {}
    current_name = None
    current_seq = []
    with open(fasta_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith('>'):
                if current_name is not None:
                    seqs[current_name] = ''.join(current_seq)
                current_name = line[1:].strip()
                current_seq = []
            else:
                current_seq.append(line)
        if current_name is not None:
            seqs[current_name] = ''.join(current_seq)
    return seqs

def add_base_column(mismatch_file: str, fasta_file: str, output_file: str):
    """
    Add a column of actual base to mismatch rate file.
    Args:
        mismatch_file: Path to mismatch rate file (TSV, possibly gzipped).
        fasta_file: Path to reference FASTA file.
        output_file: Path to output file (will be gzipped if mismatch_file ends with .gz).
    Returns:
        None.
    """
    # Parse FASTA
    seqs = parse_fasta(fasta_file)
    
    # Open input file
    if mismatch_file.endswith('.gz'):
        fin = gzip.open(mismatch_file, 'rt')
    else:
        fin = open(mismatch_file, 'r')
    
    # Open output file
    if output_file.endswith('.gz'):
        fout = gzip.open(output_file, 'wt')
    else:
        fout = open(output_file, 'w')
    
    try:
        header = fin.readline().strip()
        # Split header
        fields = header.split('\t')
        # Insert 'base' column as third column (index 2)
        fields.insert(2, 'base')
        fout.write('\t'.join(fields) + '\n')
        
        for line in fin:
            line = line.strip()
            if not line:
                continue
            cols = line.split('\t')
            # Ensure we have at least 4 columns (some rows may have empty third column)
            while len(cols) < 4:
                cols.append('')
            chrom = cols[0]
            pos_str = cols[1]
            # Convert position to 1-based index
            try:
                pos = int(pos_str) - 1  # convert to 0-based
            except ValueError:
                # If position is not integer, keep as is and base as NA
                cols.insert(2, 'NA')
                fout.write('\t'.join(cols) + '\n')
                continue
            
            # Get sequence
            seq = seqs.get(chrom)
            if seq is None:
                base = 'NA'
            elif pos < 0 or pos >= len(seq):
                base = 'NA'
            else:
                base = seq[pos]
            # Insert base column at position 2 (third column)
            cols.insert(2, base)
            fout.write('\t'.join(cols) + '\n')
    finally:
        fin.close()
        fout.close()