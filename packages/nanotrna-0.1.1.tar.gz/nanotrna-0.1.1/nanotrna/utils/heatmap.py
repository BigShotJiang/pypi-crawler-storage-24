#!/usr/bin/env python3
import gzip
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import argparse
import re
import sys
from collections import defaultdict

def parse_tRNA_alignment(fasta_file):
    """
    解析tRNA对齐文件，提取序列和位置映射信息
    """
    # 读取文件内容
    with open(fasta_file, 'r') as f:
        lines = f.readlines()
    
    # 提取tRNA序列信息
    tRNA_records = {}
    current_record = None
    current_seq = []
    
    for line in lines:
        line = line.strip()
        if line.startswith('>'):
            if current_record is not None and current_record != 'ALN':
                tRNA_records[current_record] = ''.join(current_seq)
            current_record = line[1:]
            current_seq = []
        elif line and current_record is not None:
            current_seq.append(line)
    
    # 添加最后一个记录
    if current_record is not None and current_record != 'ALN':
        tRNA_records[current_record] = ''.join(current_seq)
    
    # 位置映射信息
    ticks = "0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,17a,18,19,20,20a,20b,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,V1,V2,V3,V4,V5,V11,V12,V13,V14,V15,V16,V17,V21,V22,V23,V24,V25,V26,V27,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76"
    tick_list = ticks.split(',')
    
    if len(tick_list) != 97:  # 0-76 + 额外的V位置
        print(f"Warning: Expected 97 ticks, got {len(tick_list)}")
    
    # 创建两种映射：
    # 1. 标准位置 -> 对齐索引
    # 2. 对齐索引 -> 标准位置
    pos_to_aln = {}
    aln_to_pos = {}
    standard_positions = []
    
    for i, tick in enumerate(tick_list):
        # 处理数字位置（包括带字母的）
        if re.match(r'^\d+[a-z]?$', tick):
            aln_to_pos[i] = tick
            if tick not in ['0', '76']:  # 排除0和76，只关心1-75
                # 提取数字部分作为主要位置
                match = re.match(r'(\d+)', tick)
                if match:
                    num = int(match.group(1))
                    if 1 <= num <= 75:
                        pos_to_aln[tick] = i
                        standard_positions.append(tick)
        # 处理V位置（可变臂）
        elif re.match(r'^V\d+$', tick):
            aln_to_pos[i] = tick
            # V位置也添加到映射中
            pos_to_aln[tick] = i
    
    # 添加76位置（如果存在）
    if '76' in aln_to_pos.values():
        for aln_idx, pos in aln_to_pos.items():
            if pos == '76':
                pos_to_aln['76'] = aln_idx
                standard_positions.append('76')
                break
    
    # 对标准位置进行排序：先数字，再带字母的，最后V位置
    def sort_key(pos):
        if re.match(r'^\d+$', pos):
            return (0, int(pos))
        elif re.match(r'^\d+[a-z]$', pos):
            num = int(re.match(r'(\d+)', pos).group(1)) # type: ignore
            letter = re.search(r'([a-z])', pos).group(1) # type: ignore
            return (1, num, letter)
        elif re.match(r'^V\d+$', pos):
            num = int(re.match(r'V(\d+)', pos).group(1)) # type: ignore
            return (2, num)
        else:
            return (3, pos)
    
    standard_positions.sort(key=sort_key)
    
    return tRNA_records, pos_to_aln, aln_to_pos, standard_positions

def build_position_mapping(sequence, aln_to_pos):
    """
    为特定序列构建序列位置到标准位置的映射
    """
    seq_to_std = {}
    std_to_seq = {}
    
    seq_pos = 0
    for aln_idx, char in enumerate(sequence):
        if aln_idx in aln_to_pos:
            std_pos = aln_to_pos[aln_idx]
            if char != '-':  # 如果不是gap
                seq_pos += 1
                seq_to_std[seq_pos] = std_pos
                std_to_seq[std_pos] = seq_pos
    
    return seq_to_std, std_to_seq

def create_heatmap_data(tRNA_records, err_diff_file, aln_to_pos, standard_positions, verbose=False):
    """
    创建热图数据矩阵
    """
    # 初始化数据矩阵
    n_rows = len(tRNA_records)
    n_cols = len(standard_positions)
    data_matrix = np.full((n_rows, n_cols), np.nan)
    
    # 创建tRNA名称列表
    tRNA_names = list(tRNA_records.keys())
    
    if verbose:
        print(f"Found {n_rows} tRNA sequences")
        print(f"Using {n_cols} standard positions")
        print(f"Standard positions: {standard_positions}")
    
    # 读取错误率数据
    try:
        if err_diff_file.endswith('.gz'):
            with gzip.open(err_diff_file, 'rt') as f:
                err_data = pd.read_csv(f, sep='\t', header=None, 
                                     names=['chrom', 'pos', 'name', 'wt'])
        else:
            err_data = pd.read_csv(err_diff_file, sep='\t', header=None,
                                 names=['chrom', 'pos', 'name', 'wt'])
    except Exception as e:
        print(f"Error reading error data file: {e}")
        sys.exit(1)
    
    if verbose:
        print(f"Loaded {len(err_data)} error rate data points")
        print(f"Unique tRNA names in error data: {err_data['chrom'].unique()[:10]}")
    
    # 统计信息
    stats = defaultdict(int)
    
    # 为每个tRNA创建映射
    for idx, tRNA_name in enumerate(tRNA_names):
        sequence = tRNA_records[tRNA_name]
        
        # 为这个序列构建位置映射
        seq_to_std, std_to_seq = build_position_mapping(sequence, aln_to_pos)
        
        if verbose and idx < 3:  # 只显示前几个的详细信息
            print(f"\nSequence: {tRNA_name}")
            print(f"Sequence length (no gaps): {len(sequence.replace('-', ''))}")
            print(f"Mapped positions (seq->std): {len(seq_to_std)}")
            
            # 显示60-76位置的映射
            print("Positions 60-76 mapping:")
            for seq_pos in range(60, 77):
                if seq_pos in seq_to_std:
                    print(f"  Seq {seq_pos} -> Std {seq_to_std[seq_pos]}")
                else:
                    print(f"  Seq {seq_pos} -> No mapping")
        
        # 获取该tRNA的错误率数据
        # 尝试完全匹配
        tRNA_err_data = err_data[err_data['chrom'] == tRNA_name]
        
        # 如果找不到完全匹配，尝试部分匹配
        if tRNA_err_data.empty:
            # 尝试移除可能的后缀
            base_name = tRNA_name.split('-')[0] if '-' in tRNA_name else tRNA_name
            for chrom_name in err_data['chrom'].unique():
                if base_name in chrom_name or chrom_name in tRNA_name:
                    tRNA_err_data = err_data[err_data['chrom'] == chrom_name]
                    if not tRNA_err_data.empty:
                        if verbose:
                            print(f"Matched {tRNA_name} with {chrom_name}")
                        break
        
        if not tRNA_err_data.empty:
            stats['tRNAs_with_data'] += 1
            stats['data_points_total'] += len(tRNA_err_data)
            
            for _, row in tRNA_err_data.iterrows():
                try:
                    seq_pos = int(row['pos'])
                    wt_value = float(row['wt'])
                    
                    # 获取这个序列位置对应的标准位置
                    if seq_pos in seq_to_std:
                        std_pos = seq_to_std[seq_pos]
                        
                        if std_pos in standard_positions:
                            col_idx = standard_positions.index(std_pos)
                            data_matrix[idx, col_idx] = wt_value
                            stats['mapped_points'] += 1
                        else:
                            stats['std_pos_not_in_list'] += 1
                    else:
                        stats['seq_pos_no_mapping'] += 1
                        
                except (ValueError, TypeError) as e:
                    stats['value_errors'] += 1
                    continue
    
    if verbose:
        print(f"\n=== Statistics ===")
        print(f"tRNAs with data: {stats['tRNAs_with_data']}/{n_rows}")
        print(f"Total data points: {stats['data_points_total']}")
        print(f"Mapped points: {stats['mapped_points']}")
        print(f"Points with seq position not mapped: {stats['seq_pos_no_mapping']}")
        print(f"Points with std position not in list: {stats['std_pos_not_in_list']}")
        print(f"Value errors: {stats['value_errors']}")
        
        # 检查60-76位置是否有数据
        print(f"\n=== Data in positions 60-76 ===")
        sixty_to_seventy_six = [str(i) for i in range(60, 77)]
        for pos in sixty_to_seventy_six:
            if pos in standard_positions:
                col_idx = standard_positions.index(pos)
                non_nan_count = np.sum(~np.isnan(data_matrix[:, col_idx]))
                if non_nan_count > 0:
                    print(f"Position {pos}: {non_nan_count} non-NaN values")
                else:
                    print(f"Position {pos}: No data")
    
    return data_matrix, tRNA_names, standard_positions

def plot_heatmap(data_matrix, tRNA_names, positions, output_prefix="tRNA_heatmap", 
                title="tRNA Modification Error Rates", cmap="RdBu_r", maxv=None, 
                figsize=(25, 8), dpi=300, verbose=False):
    """
    绘制热图
    """
    if data_matrix.size == 0 or np.all(np.isnan(data_matrix)):
        print("Warning: No valid data to plot!")
        return None, None, []
    
    # 计算最大绝对值，用于对称的颜色映射
    valid_data = data_matrix[~np.isnan(data_matrix)]
    if len(valid_data) == 0:
        print("Warning: All data values are NaN!")
        return None, None, []
    
    if maxv is None:
        maxv = np.nanmax(np.abs(data_matrix))
    
    # 确保有合理的最大值
    if np.isnan(maxv) or maxv == 0:
        maxv = 1.0
    
    fig, ax = plt.subplots(figsize=figsize)
    
    # 创建掩码用于处理NaN值
    mask = np.isnan(data_matrix)
    
    # 绘制热图
    try:
        g = sns.heatmap(data_matrix, ax=ax, cmap=cmap, vmin=-maxv, vmax=maxv,
                        mask=mask, cbar_kws={'label': 'Error Rate', 'location': 'right'})
    except Exception as e:
        print(f"Error plotting heatmap: {e}")
        return None, None, []
    
    # 设置x轴刻度为位置编号
    ax.set_xticks(np.arange(len(positions)) + 0.5)
    ax.set_xticklabels(positions, rotation=90, fontsize=8)
    
    # 设置y轴刻度为tRNA名称 - 旋转90度并放在右侧
    ax.set_yticks(np.arange(len(tRNA_names)) + 0.5)
    # 将y轴标签移到右侧
    ax.yaxis.tick_right()
    # 设置y轴标签旋转90度
    ax.set_yticklabels(tRNA_names, rotation=0, fontsize=8, va='center')
    
    ax.tick_params(axis="x", labelrotation=90)
    ax.set_title(title, fontsize=14)
    ax.set_xlabel("tRNA Position", fontsize=12)
    
    # 移除左侧的y轴标签（因为我们已经移到右侧）
    ax.set_ylabel("")
    
    # 设置缺失值为灰色
    g.set_facecolor(".85")
    
    fig.tight_layout()
    
    # 保存图像
    output_files = []
    for ext in ['png', 'pdf']:
        output_file = f"{output_prefix}.{ext}"
        fig.savefig(output_file, dpi=dpi, bbox_inches='tight')
        output_files.append(output_file)
    
    if verbose:
        print(f"Saved heatmap to {output_prefix}.png and {output_prefix}.pdf")
    
    # 显示数据矩阵的统计信息
    print(f"\n=== Heatmap Data Summary ===")
    print(f"Data matrix shape: {data_matrix.shape}")
    print(f"Total cells: {data_matrix.size}")
    print(f"Non-NaN cells: {np.sum(~np.isnan(data_matrix))} ({np.sum(~np.isnan(data_matrix))/data_matrix.size*100:.1f}%)")
    print(f"NaN cells: {np.sum(np.isnan(data_matrix))} ({np.sum(np.isnan(data_matrix))/data_matrix.size*100:.1f}%)")
    
    # 检查60-76位置的数据
    sixty_to_seventy_six = [str(i) for i in range(60, 77)]
    print(f"\n=== Data coverage for positions 60-76 ===")
    for pos in sixty_to_seventy_six:
        if pos in positions:
            col_idx = positions.index(pos)
            col_data = data_matrix[:, col_idx]
            non_nan = np.sum(~np.isnan(col_data))
            total = len(col_data)
            if non_nan > 0:
                print(f"Position {pos}: {non_nan}/{total} ({non_nan/total*100:.1f}%)")
            else:
                print(f"Position {pos}: No data")
    
    return fig, ax, output_files

def generate_heatmap(fasta, errfile, output='tRNA_heatmap', title='tRNA Modification Error Rates',
                     cmap='RdBu_r', maxv=None, figsize=(25, 8), dpi=300, verbose=False, save_csv=False):
    """
    生成tRNA修饰错误率热图
    
    Parameters
    ----------
    fasta : str
        Input tRNA alignment FASTA file
    errfile : str
        Error rate data file (TSV or gzipped TSV)
    output : str, optional
        Output file prefix (default: tRNA_heatmap)
    title : str, optional
        Title for the heatmap (default: tRNA Modification Error Rates)
    cmap : str, optional
        Color map for heatmap (default: RdBu_r)
    maxv : float, optional
        Maximum absolute value for color scale (default: auto)
    figsize : tuple, optional
        Figure size as (width, height) (default: (25, 8))
    dpi : int, optional
        DPI for output image (default: 300)
    verbose : bool, optional
        Enable verbose output (default: False)
    save_csv : bool, optional
        Save data matrix as CSV file (default: False)
    
    Returns
    -------
    tuple
        (fig, ax, output_files) if successful, (None, None, []) otherwise
    """
    if verbose:
        print(f"Starting tRNA heatmap generation")
        print(f"Input FASTA: {fasta}")
        print(f"Error data: {errfile}")
        print(f"Output prefix: {output}")
    
    # 1. 解析tRNA对齐文件
    if verbose:
        print("Parsing tRNA alignment file...")
    
    tRNA_records, pos_to_aln, aln_to_pos, standard_positions = parse_tRNA_alignment(fasta)
    
    if not tRNA_records:
        print("Error: No tRNA sequences found in FASTA file!")
        sys.exit(1)
    
    # 2. 创建热图数据
    if verbose:
        print("Creating heatmap data...")
    
    data_matrix, tRNA_names, positions = create_heatmap_data(
        tRNA_records, errfile, aln_to_pos, standard_positions, verbose
    )
    
    # 3. 保存数据矩阵为CSV文件（如果请求）
    if save_csv:
        csv_file = f"{output}_data.csv"
        df = pd.DataFrame(data_matrix, index=tRNA_names, columns=positions)
        df.to_csv(csv_file)
        if verbose:
            print(f"Data matrix saved to {csv_file}")
    
    # 4. 绘制热图
    if verbose:
        print("Plotting heatmap...")
    
    fig, ax, output_files = plot_heatmap(
        data_matrix, tRNA_names, positions, 
        output_prefix=output,
        title=title,
        cmap=cmap,
        maxv=maxv,
        figsize=figsize,
        dpi=dpi,
        verbose=verbose
    )
    
    if fig is not None and verbose:
        print(f"Successfully generated heatmap!")
        print(f"Output files: {', '.join(output_files)}")
    
    return fig, ax, output_files


def main():
    parser = argparse.ArgumentParser(
        description="Generate heatmap of tRNA modification error rates from alignment data",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Example usage:
  python plot_tRNA_heatmap.py -f tRNA.modomics.aln.fa -e err_diff.tsv.gz -o output_prefix
  python plot_tRNA_heatmap.py -f tRNA.modomics.aln.fa -e err_diff.tsv.gz -o my_heatmap --cmap coolwarm --figsize 20 10
        """
    )
    
    parser.add_argument('-f', '--fasta', required=True,
                       help='Input tRNA alignment FASTA file')
    parser.add_argument('-e', '--errfile', required=True,
                       help='Error rate data file (TSV or gzipped TSV)')
    parser.add_argument('-o', '--output', default='tRNA_heatmap',
                       help='Output file prefix (default: tRNA_heatmap)')
    parser.add_argument('--title', default='tRNA Modification Error Rates',
                       help='Title for the heatmap (default: tRNA Modification Error Rates)')
    parser.add_argument('--cmap', default='RdBu_r',
                       help='Color map for heatmap (default: RdBu_r)')
    parser.add_argument('--maxv', type=float, default=None,
                       help='Maximum absolute value for color scale (default: auto)')
    parser.add_argument('--figsize', nargs=2, type=float, default=[25, 8],
                       help='Figure size as width height (default: 25 8)')
    parser.add_argument('--dpi', type=int, default=300,
                       help='DPI for output image (default: 300)')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Enable verbose output')
    parser.add_argument('--save_csv', action='store_true',
                       help='Save data matrix as CSV file')
    
    args = parser.parse_args()
    
    generate_heatmap(
        fasta=args.fasta,
        errfile=args.errfile,
        output=args.output,
        title=args.title,
        cmap=args.cmap,
        maxv=args.maxv,
        figsize=tuple(args.figsize),
        dpi=args.dpi,
        verbose=args.verbose,
        save_csv=args.save_csv
    )

if __name__ == "__main__":
    main()