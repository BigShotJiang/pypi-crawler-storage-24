import typer
from .modules.heatmap import heatmap
from .modules.addBaseColumn import addBaseColumn

app = typer.Typer(add_completion=False)

@app.callback()
def callback():
    """
    nanotRNA is a tool for counting and detecting modifications in nanopore sequencing data of tRNA.
    """

app.command(name="heatmap")(heatmap)
app.command(name="addBaseColumn")(addBaseColumn)


if __name__ == "__main__":
    app()