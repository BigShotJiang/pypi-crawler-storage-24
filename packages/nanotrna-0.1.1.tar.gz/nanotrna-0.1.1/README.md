# nanotrna
<!-- TOC -->

- [nanotrna](#nanotrna)
- [Overview](#overview)
- [Requirements](#requirements)
- [nanotrna modules](#nanotrna-modules)
    - [nanotrna gene](#nanotrna-gene)
    - [Usage](#usage)
- [Docker](#docker)
- [Conda Environment](#conda-environment)
- [Cite nanotrna](#cite-nanotrna)

<!-- /TOC -->


# Overview

nanotrna is a pipeline for analyzing ONT tRNA sequencing data. It includes several modules for analyzing the data, including gene mapping, transcript quantification, polyA analysis, modification detection, and nascent RNA detection

It is recommended to use the docker or conda environment to run the pipeline.

# Requirements

1. Python 3.10+
2. Python modules:
    - pandas
    - numpy
    - scipy
    - sklearn
    - matplotlib
    - seaborn
    - pysam
3. minimap2
4. samtools
5. bedtools

# nanotrna modules

nanotrna is the main module of nanotrna, which includes the following sub-modules:
- gene
- count
- polyA
- matrix
- detectMod
- nascentRNA

## nanotrna gene

## Usage

`nanotrna gene -i ../input/{}/pass.fq.gz -r ../reference/fasta/genome.fa -o ./{}_gene.sam --parms '--secondary=no --cs -a --sam-hit-only'`

# Docker

If the user has docker installed, the following command can be used to run the pipeline in a docker container:

```
docker run -v /path/to/data:/data -it nanotrna/nanotrna:latest /bin/bash
```

# Conda Environment

If the user has conda installed, the following command can be used to create a conda environment for nanotrna:

1. Install conda
2. Create a new conda environment: `conda create -n nanotrna python=3.12`
3. Activate the environment: `conda activate nanotrna`
4. Install the required packages: `conda install -c bioconda minimap2 samtools bedtools`
5. Install the required python packages: `pip install pandas numpy scipy sklearn matplotlib seaborn pysam`
6. Clone the nanotrna repository: `git clone https://github.com/LegendZDY/nanotrna.git`
7. Run the pipeline: `nanotrna gene -i ../input/{}/pass.fq.gz -r ../reference/fasta/genome.fa -o ./{}_gene.sam --parms '--secondary=no --cs -a --sam-hit-only'`

# Cite nanotrna

If you use nanotrna in your research, please cite the following paper: