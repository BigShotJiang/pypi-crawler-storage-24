from imports import *
POSTGRES_DSN = {
    "name":"ae_clients_db",
    "user":"ae_ext_rw",

}
conn_mgr = get_db_env_value(name='TDD',user='putkoff')
input(get_env_path())
input(conn_mgr)
