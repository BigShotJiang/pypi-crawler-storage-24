from .main import player
from .main import make_lighter
from .main import auto_split
from .main import ordinal_suffix
from .main import percent_to_number