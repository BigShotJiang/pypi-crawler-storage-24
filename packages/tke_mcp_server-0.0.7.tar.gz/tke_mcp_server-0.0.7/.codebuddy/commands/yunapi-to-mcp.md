你作为AI助手，必须严格按照下面流程帮助用户完成云API转换，确保每一步都正确执行：

## 严格工作流程
1. **转换工具安装**: 
   go install github.com/higress-group/openapi-to-mcpserver/cmd/openapi-to-mcp@latest
2. **自动转换**: 将OpenAPI JSON转换为MCP API YAML
   
   **2.1 检测新增文件**: 对比 `openapi/` 目录下的 JSON 文件与 `src/mcp_server_tke/mcpapi/` 目录下的 YAML 文件，找出尚未转换的 JSON 文件
   - openapi 文件命名格式: `tke_2018-05-25_<ActionName>.json`
   - mcpapi 文件命名格式: `2018-05-25_<ActionName>.yaml`
   - 对比逻辑: 提取 JSON 文件中的 `2018-05-25_<ActionName>` 部分，检查对应的 `.yaml` 是否存在
   
   **2.2 批量转换**: 对所有新增的 JSON 文件执行转换
   ```bash
   # 对每个新增的 JSON 文件执行:
   openapi-to-mcp --input openapi/tke_2018-05-25_<ActionName>.json --output src/mcp_server_tke/mcpapi/2018-05-25_<ActionName>.yaml
   ```
   
   **2.3 指定文件转换** (可选): 如果用户指定了具体文件，则只转换指定文件
   ```bash
   openapi-to-mcp --input {{args}} --output src/mcp_server_tke/mcpapi/<对应文件名>.yaml
   ```
   
   **重要约束**:
   - 输出文件名必须基于输入文件自动生成（如：tke_2018-05-25_DescribeClusters.json → 2018-05-25_DescribeClusters.yaml）
   - 只能优化生成的 YAML 中 args 和 outputSchema.properties 字段下的 description
   - 其他字段绝对不能修改，否则会导致MCP加载失败

3. **工具验证**: 验证新工具是否正常加载
   npx @modelcontextprotocol/inspector uv --directory ./ run mcp-server-tke