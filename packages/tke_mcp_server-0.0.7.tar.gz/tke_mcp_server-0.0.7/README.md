# 腾讯云 TKE MCP Server（中文版）

腾讯云容器服务(TKE) Model Context Protocol (MCP) 服务器，提供标准化的TKE集群管理接口。

## 功能特性
- **集群生命周期管理**：创建、删除、修改属性、查询列表
- **动态工具加载**：支持通过McpAPI YAML文件自动生成MCP工具
- **模拟模式支持**：在没有腾讯云凭证时使用模拟响应
- **完整参数验证**：严格的输入参数验证和错误处理

## 工具列表（Tools）

### 静态工具
| 工具名称 | 功能说明 |
|---|---|
| `CreateCluster` | 创建TKE集群 |

### 动态工具（通过McpAPI文件自动生成）

#### API 版本 2018-05-25
| 工具名称 | 功能说明 |
|---|---|
| `DescribeClusters` | 查询集群列表 |
| `DescribeClusterStatus` | 查看集群状态列表 |
| `DescribeClusterKubeconfig` | 获取集群kubeconfig |
| `DeleteCluster` | 删除集群 |
| `ModifyClusterAttribute` | 修改集群属性 |
| `CreateClusterEndpoint` | 创建集群访问端点 |
| `DeleteClusterEndpoint` | 删除集群访问端点 |
| `DescribeClusterEndpoints` | 查询集群访问端点 |
| `DescribeClusterEndpointStatus` | 查询集群端点状态 |
| `EnableClusterDeletionProtection` | 开启集群删除保护 |
| `DisableClusterDeletionProtection` | 关闭集群删除保护 |

#### API 版本 2022-05-01
| 工具名称 | 功能说明 |
|---|---|
| `DescribeNodePools` | 查询节点池列表 |

## 快速开始
### 1. 准备腾讯云凭证
- 登录 [腾讯云控制台](https://console.cloud.tencent.com/)，进入「访问管理」→「访问密钥」获取 `SecretId` 与 `SecretKey`

### 2. 配置环境变量
```bash
export TENCENTCLOUD_SECRET_ID=你的SecretId
export TENCENTCLOUD_SECRET_KEY=你的SecretKey
```

### 3. 安装
```bash
# 从PyPI安装
pip install tke-mcp-server

# 或从源码安装
pip install .
```

### 4. 启动服务器
```bash
# 直接运行
uv run tke-mcp-server

# 或通过Python模块
python -m mcp_server_tke
```

### 5. Claude Desktop 配置
编辑 `claude_desktop_config.json`（Mac 默认路径 `~/Library/Application Support/Claude/claude_desktop_config.json`），加入：

```json
{
  "mcpServers": {
    "tencent-tke": {
      "command": "uv",
      "args": ["run", "tke-mcp-server"],
      "env": {
        "TENCENTCLOUD_SECRET_ID": "你的SecretId",
        "TENCENTCLOUD_SECRET_KEY": "你的SecretKey"
      }
    }
  }
}
```

## 开发贡献

### 开发工具安装
```bash
npm install -g --registry=https://mirrors.tencent.com/npm @tencent/codebuddy-cli
```

### 项目结构
```
tke-mcp/
├── src/mcp_server_tke/          # 主源代码目录
│   ├── __init__.py             # 模块入口点
│   ├── server.py               # MCP服务器主逻辑
│   ├── tool_tke.py             # TKE静态工具实现
│   ├── client.py               # 腾讯云客户端封装
│   ├── mcpapi_loader.py        # McpAPI YAML文件加载器
│   ├── dynamic_tool_handler.py # 动态工具处理器
│   └── mcpapi/                 # 动态工具定义文件
├── openapi/                    # 云API导出的OpenAPI源文件
├── tests/                      # 单元测试
├── docs/                       # 文档
└── pyproject.toml              # Python项目配置
```

### AI 辅助扩展开发

### 添加新工具
有两种方式添加新工具：

#### 1. 静态工具（在代码中实现）
1. 在 `tool_tke.py` 中添加新函数
2. 在 `server.py` 的 `handle_list_tools()` 中添加工具定义
3. 在 `handle_call_tool()` 中添加调用逻辑

#### 2. 动态工具（通过YAML文件）
1. 使用CodeBuddy CLI的`/yunapi`Command，可以将云API转成MCP。 
```
/yunapi openapi/tke_2018-05-25_DescribeClusterKubeconfig.json
```

### 测试
```bash
# 运行所有测试
python -m unittest discover tests/

# 运行特定测试
python -m unittest tests/test_tool_tke.py
python -m unittest tests/test_mcp_integration.py
```

### 构建包
```bash
# 使用hatch构建
hatch build
```

## 许可证
MIT License，详见 LICENSE 文件。
