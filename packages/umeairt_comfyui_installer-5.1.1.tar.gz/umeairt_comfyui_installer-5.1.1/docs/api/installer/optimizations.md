# Optimizations

::: src.installer.optimizations
