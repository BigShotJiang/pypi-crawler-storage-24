from importlib.metadata import PackageNotFoundError, version

from .base_pv_interface import PV, BasePVInterface, PVField
from .daemon import BridgeDaemon
from .daemon_status import TaskStatus
from .io import BridgeIO
from .log_config import configure_daemon_logging
from .payload import PVPayload

try:
    __version__ = version("epics-bridge")
except PackageNotFoundError:
    __version__ = "3.0.0"

__all__ = [
    "BridgeDaemon",
    "BasePVInterface",
    "BridgeIO",
    "PV",
    "PVField",
    "PVPayload",
    "TaskStatus",
    "__version__",
    "configure_daemon_logging",
]
