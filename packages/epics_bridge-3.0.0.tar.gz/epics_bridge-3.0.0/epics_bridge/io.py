import logging
from typing import Any, List, Union

from p4p.client.thread import Context, Value
from p4p.nt.enum import ntenum
from p4p.nt.ndarray import ntndarray
from p4p.nt.scalar import ntbool, ntfloat, ntint, ntnumericarray, ntstr, ntstringarray

from .pv import PV, PVField

logger = logging.getLogger(__name__)


def unwrap_p4p_structure(res: Any) -> Any:
    """
    Unwraps P4P structures to get clean Python types.
    """
    raw_data = res.raw
    raw_dict = raw_data.todict()
    if isinstance(res, (ntbool, ntint, ntfloat, ntnumericarray, ntstr, ntstringarray)):
        val = raw_dict["value"]
    elif isinstance(res, ntenum):
        val = raw_dict["value"]["index"]
    elif isinstance(res, ntndarray):
        val = raw_dict["value"]
    else:
        val = None

    return val


def _expand_pvs(pv_list: List[PV], skip_none_values: bool = False) -> List[PVField]:
    """
    Flatten a list of PVs into a list of PVFields for batch get/put.

    PV sets each field's ``name`` to PV base + "." + field (e.g. MY:PV.VAL),
    so the channel name for get/put is ``field.pv_name``.

    Args:
        pv_list: Parent PVs; their ``fields`` are yielded in order.
        skip_none_values: If True, omit fields whose ``val`` is None (for pvput).

    Returns:
        Flat list of PVField; use ``field.pv_name`` for channel names, ``field.val`` for put.
    """
    expanded: List[PVField] = []
    for pv in pv_list:
        for field in pv.fields:
            if not isinstance(field, PVField):
                continue
            if skip_none_values and field.val is None:
                continue
            expanded.append(field)
    return expanded


class BridgeIO:
    """
    Handles synchronous Input/Output operations for Process Variables (PVs) via p4p.

    PVs are read and written by passing PV objects. Each PV's fields (PVField)
    are expanded to full names and batch get/put; pvget mutates each field's
    .val and .raw in-place.
    """

    def __init__(self) -> None:
        """Create a PVA context for synchronous get/put. One instance per control loop."""
        self._ctx = Context("pva")

    def pvget(self, pvs: Union[PV, List[PV]], timeout: float = 5.0) -> None:
        """
        Reads PVs synchronously by expanding each PV's fields and mutates each
        field's .val and .raw in-place.

        Args:
            pvs: A single PV or a list of PVs. Each PV's fields are batch-read by full name.
            timeout: Maximum seconds to wait for the network response.

        On success: each field's .val is set to the unwrapped Python value, .raw to the p4p response.
        On failure (per-field or catastrophic): that field's .val and .raw are set to None.
        """
        pv_list: List[PV] = [pvs] if isinstance(pvs, PV) else list(pvs)
        if not pv_list:
            return

        expanded = _expand_pvs(pv_list)
        names = [field.pv_name for field in expanded]
        raw_results: List[Union[Value, Exception]] = self._ctx.get(
            names, throw=False, timeout=timeout
        )

        for field, raw in zip(expanded, raw_results):
            if isinstance(raw, Exception):
                field.val = None
                field.raw = None
                logger.error("Error getting PV %s: %s", field.pv_name, raw)
            else:
                field.raw = raw
                field.val = unwrap_p4p_structure(raw)

        logger.debug("pvget result: %s", pv_list)

    def pvput(self, pvs: Union[PV, List[PV]], timeout: float = 5.0) -> bool:
        """
        Writes to a batch of PVs synchronously by expanding each PV's fields.
        Uses each field's .name and .val; fields with .val None are skipped.

        Blocks until the server confirms the write.

        Args:
            pvs: A single PV or a list of PVs; each field's .val is written to the field's full .name.
            timeout: Maximum seconds to wait for write confirmation.

        Returns:
            True if the write was successful and acknowledged, False otherwise.
        """
        logger.debug("pvput: %s", pvs)

        pv_list: List[PV] = [pvs] if isinstance(pvs, PV) else list(pvs)
        if not pv_list:
            return False

        expanded = _expand_pvs(pv_list, skip_none_values=True)
        names = [field.pv_name for field in expanded]
        vals = [field.val for field in expanded]

        self._ctx.put(names, vals, wait=True, timeout=timeout)
        return True
