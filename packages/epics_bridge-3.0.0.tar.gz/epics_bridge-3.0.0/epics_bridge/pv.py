import logging
from typing import Any, List, Type

logger = logging.getLogger(__name__)


class PVField:
    """
    Record-field descriptor for an EPICS PV (e.g. NELM, NORD).

    Always has ``val`` and ``raw``; full ``name`` is set by the parent PV
    during prefix formatting. When ``type`` is set, assigning to ``val``
    casts to that type.
    """

    def __init__(
        self,
        name: str,
        type: Type[Any] | None = None,
    ) -> None:
        self.name = name
        self.type = type

        self.pv_name = None
        self._val: Any = None
        self._raw: Any = None

    @property
    def val(self) -> Any:
        return self._val

    @val.setter
    def val(self, v: Any) -> None:
        if v is None or self.type is None:
            self._val = v
        else:
            self._val = self.type(v)

    @property
    def raw(self) -> Any:
        return self._raw

    @raw.setter
    def raw(self, v: Any) -> None:
        if hasattr(v, "todict") and callable(getattr(v, "todict", None)):
            self._raw = v.todict()
        else:
            self._raw = v

    def __str__(self) -> str:
        return f"PVField(name={self.name!r}, type={self.type}, val={self.val}, raw={self.raw})"

    def __repr__(self) -> str:
        return f"PVField({self.name!r}, type={self.type})"


class PV:
    """Process Variable descriptor: name, metadata, and live value/raw from IOC.

    When ``type`` is set (e.g. int, float), assigning to ``val`` casts the
    value to that type. Casting is done by the class; invalid casts raise
    (e.g. int("hello")).

    Optional ``fields`` is a list of PVField instances; each field's full name
    becomes ``parent.name + "." + name`` after formatting. Each field is
    exposed as a lowercase attribute (e.g. pv.nelm). Assigning to that
    attribute sets the field's ``val`` (e.g. pv.nelm = 5).
    """

    _PV_RESERVED_ATTRS = frozenset({"name", "type", "fields"})

    @staticmethod
    def _normalize_fields(
        fields: List[PVField] | None,
        field_type: Type[Any] | None,
    ) -> List[PVField]:
        """Return a copy of fields, appending a VAL field if none is present."""
        user_fields = list(fields) if fields is not None else []
        has_val = any(f.name.lower() == "val" for f in user_fields)
        return (
            user_fields if has_val else user_fields + [PVField("VAL", type=field_type)]
        )

    def __init__(
        self,
        name: str,
        type: Type[Any] | None = None,
        fields: List[PVField] | None = None,
        tags: List[str] | None = None,
    ) -> None:
        self.name = name
        self.type = type
        self.fields = self._normalize_fields(fields, type)
        self._format_field_names()
        self._bind_fields()
        self.tags = tags
        logger.debug("PV initialized: %s", self)
        logger.debug("Attributes: %s", self.__dict__)

    def _format_field_names(self) -> None:
        """Set each field's name to PV base + '.' + field short name (e.g. MY:PV.VAL)."""
        for field in self.fields:
            field.pv_name = f"{self.name}.{field.name.upper()}"

    def _bind_fields(self) -> None:
        """Validate each field is a PVField, not reserved, and bind it as a lowercase attribute."""
        for field in self.fields:
            if not isinstance(field, PVField):
                raise TypeError(
                    f"fields must be a list of PVField instances; got {type(field).__name__}."
                )
            attr = field.name.lower()
            if attr in self._PV_RESERVED_ATTRS:
                raise ValueError(
                    f"PV field name '{field.name}' (attribute '{attr}') shadows a reserved PV attribute."
                )
            object.__setattr__(self, attr, field)

    def __getattribute__(self, name: str) -> Any:
        """When reading a field attribute (e.g. pv.nelm), return the field's value so pv.nelm is pv.nelm.val."""
        value = object.__getattribute__(self, name)
        if isinstance(value, PVField):
            return value.val
        return value

    def __setattr__(self, name: str, value: Any) -> None:
        """When setting a field attribute (e.g. nelm), set the field's val instead of replacing the attr."""
        if "fields" in self.__dict__ and not isinstance(value, PVField):
            for field in self.fields:
                if field.name.lower() == name:
                    field.val = value
                    return

        object.__setattr__(self, name, value)

    def _field_vals_for_display(self) -> list[dict[str, Any]]:
        """Field name, val, and raw for string/repr display."""
        return [{"name": f.name, "val": f.val, "raw": f.raw} for f in self.fields]

    def __str__(self) -> str:
        return f"PV(name={self.name!r}, type={self.type}, fields={self._field_vals_for_display()})"

    def __repr__(self) -> str:
        return f"PV({self.name!r}, type={self.type}, fields={self._field_vals_for_display()})"
