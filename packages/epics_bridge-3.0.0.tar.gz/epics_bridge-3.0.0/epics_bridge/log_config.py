"""
Logging configuration and log-directory setup for daemon entrypoints.

Clients can use the high-level :func:`configure_daemon_logging` for one-shot
setup, or call :func:`parse_log_level`, :func:`ensure_log_dir`, and
:func:`setup_logging` separately for finer control.
"""

import logging
import os
import sys
from logging.handlers import QueueHandler, QueueListener, RotatingFileHandler
from pathlib import Path
from queue import Queue
from typing import Union

logger = logging.getLogger(__name__)

__all__ = [
    "configure_daemon_logging",
    "ensure_log_dir",
    "parse_log_level",
    "setup_logging",
]


def parse_log_level(level_name: str) -> int:
    """
    Return the logging level constant for the given name.

    Args:
        level_name: e.g. 'INFO', 'DEBUG'.

    Returns:
        logging.INFO etc.

    Raises:
        ValueError: If level_name is not a valid logging level.
    """
    level = getattr(logging, level_name.upper(), None)
    if not isinstance(level, int):
        raise ValueError(f"Invalid log level: {level_name}")
    return level


def ensure_log_dir(prefix: str, log_dir_arg: str) -> Path:
    """
    Resolve log directory: create it, or fall back to ~/epics_logs/<safe_prefix>
    on PermissionError.

    Exits the process with code 1 if both the requested dir and fallback
    cannot be created.

    Args:
        prefix: PV or device prefix (e.g. 'TestAD:', 'CAM1:'). Used to build
            a safe subdir name.
        log_dir_arg: User-supplied or default log directory path.

    Returns:
        Path to the log directory to use.
    """
    safe_prefix = prefix.replace(":", "_").strip("_")
    base_dir = Path(log_dir_arg)
    log_dir = base_dir / safe_prefix

    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir
    except PermissionError as e:
        logger.error("CRITICAL ERROR: Could not write to log dir: %s", log_dir)
        logger.error("Reason: %s", e)
        if not base_dir.exists():
            logger.warning("Hint: Base directory '%s' does not exist.", base_dir)
        elif not os.access(base_dir, os.W_OK):
            logger.warning("Hint: Base directory '%s' is not writable.", base_dir)
        fallback_dir = Path.home() / "epics_logs" / safe_prefix
        logger.warning("Falling back to: %s", fallback_dir)
        try:
            fallback_dir.mkdir(parents=True, exist_ok=True)
            return fallback_dir
        except Exception as e2:
            logger.critical("FATAL: Could not create fallback log dir: %s", e2)
            sys.exit(1)


_THIRD_PARTY_LOG_FLOOR = logging.WARNING
_NOISY_THIRD_PARTY_LOGGERS = (
    "jax",
    "p4p",
    "absl",
)


def setup_logging(log_dir: Path, log_level: int) -> QueueListener:
    """
    Configure RotatingFileHandler and StreamHandler via QueueListener.

    Replaces root logger handlers with a QueueHandler; the listener runs file
    and console handlers in a background thread.

    Third-party loggers listed in ``_NOISY_THIRD_PARTY_LOGGERS`` are clamped to
    WARNING regardless of the requested log_level so their internal DEBUG/INFO
    output does not flood daemon logs.

    Args:
        log_dir: Directory containing daemon.log.
        log_level: Root logger level (e.g. logging.INFO).

    Returns:
        Started QueueListener. Caller must call listener.stop() in a finally
        block (or at shutdown).
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    for name in _NOISY_THIRD_PARTY_LOGGERS:
        logging.getLogger(name).setLevel(_THIRD_PARTY_LOG_FLOOR)

    log_file = log_dir / "daemon.log"
    log_formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )
    max_bytes = 1024 * 1024 * 1024  # 1GB
    file_handler = RotatingFileHandler(log_file, maxBytes=max_bytes, backupCount=5)
    file_handler.setFormatter(log_formatter)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_formatter)

    log_queue = Queue(-1)
    queue_handler = QueueHandler(log_queue)
    if root_logger.hasHandlers():
        root_logger.handlers.clear()
    root_logger.addHandler(queue_handler)

    listener = QueueListener(
        log_queue, file_handler, console_handler, respect_handler_level=True
    )
    listener.start()
    return listener


def configure_daemon_logging(
    prefix: str,
    log_dir: str,
    log_level: Union[str, int],
) -> QueueListener:
    """
    One-shot daemon logging setup: resolve log directory and start file + console
    logging via a background QueueListener.

    Convenience wrapper around :func:`ensure_log_dir` and :func:`setup_logging`.
    Use this in daemon entrypoints (e.g. ``if __name__ == "__main__"``).

    Args:
        prefix: PV or device prefix (e.g. 'TestAD:', 'CAM1:'). Used for log
            subdir and fallback path.
        log_dir: Base log directory path (e.g. '/var/log/daemons' or '.').
        log_level: Root log level as string ('INFO', 'DEBUG') or int
            (e.g. logging.INFO).

    Returns:
        Started QueueListener. Caller must call ``listener.stop()`` in a finally
        block or at process shutdown so logs are flushed.

    Example:
        >>> listener = configure_daemon_logging("TestAD:", "/var/log", "INFO")
        >>> try:
        ...     main()
        ... finally:
        ...     listener.stop()
    """
    level = parse_log_level(log_level) if isinstance(log_level, str) else log_level
    resolved_dir = ensure_log_dir(prefix, log_dir)
    return setup_logging(resolved_dir, level)
