"""Batch container for PV reads and writes."""

from typing import List, Optional

from .io import BridgeIO
from .pv import PV


class PVPayload:
    """
    Holds PVs to be read or written in batch.

    Use add() to register PVs, or pass an initial list to the constructor.
    Then pass .pvs to pvget or pvput. Set pv.val on each PV before calling
    pvput when writing. If io is provided, get() and put() can be used to
    read/write the current PVs.
    """

    def __init__(
        self,
        pvs: List[PV] | None = None,
        io: Optional[BridgeIO] = None,
    ) -> None:
        self._pvs: List[PV] = list(pvs) if pvs is not None else []
        self._io: Optional[BridgeIO] = io

    def add(self, pv: PV) -> "PVPayload":
        """Register a PV for batch read or write. Returns self for chaining."""
        self._pvs.append(pv)
        return self

    @property
    def pvs(self) -> List[PV]:
        """PVs in this payload (for pvget or pvput)."""
        return self._pvs

    def get(self, timeout: float = 5.0) -> None:
        """
        Read current PVs via the configured BridgeIO.
        Mutates each PV's .val and .raw in-place.

        Raises:
            RuntimeError: If this payload was created without an io (BridgeIO) instance.
        """
        if self._io is None:
            raise RuntimeError(
                "PVPayload.get() requires an io (BridgeIO) instance; none was passed to the constructor."
            )
        self._io.pvget(self._pvs, timeout=timeout)

    def put(self, timeout: float = 5.0) -> bool:
        """
        Write current PVs via the configured BridgeIO.
        Uses each PV's .name and .val.

        Returns:
            True if the write was successful.

        Raises:
            RuntimeError: If this payload was created without an io (BridgeIO) instance.
            TimeoutError: If the write times out. Other IO errors may propagate.
        """
        if self._io is None:
            raise RuntimeError(
                "PVPayload.put() requires an io (BridgeIO) instance; none was passed to the constructor."
            )
        return self._io.pvput(self._pvs, timeout=timeout)

    def __len__(self) -> int:
        return len(self._pvs)

    def __bool__(self) -> bool:
        return len(self._pvs) > 0

    def __str__(self) -> str:
        return f"PVPayload(n={len(self._pvs)}, pvs={self._pvs})"

    def __repr__(self) -> str:
        names = [pv.name for pv in self._pvs]
        return f"PVPayload(pvs={names!r}, io={self._io!r})"
