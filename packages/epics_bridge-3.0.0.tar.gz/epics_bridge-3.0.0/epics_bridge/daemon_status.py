from enum import IntEnum


class TaskStatus(IntEnum):
    """
    Simple status tracking for task completion.
    Maps to an EPICS mbbi record.
    """

    SUCCESS = 0  # ZRST="Success",    ZRSV=NO_ALARM
    LOGIC_FAILURE = 1  # ONST="Task Fail",  ONSV=MINOR (Business logic said no)
    IO_FAILURE = 2  # TWST="IO Fail",    ONSV=MINOR (Network/IO operation failed)
    EXCEPTION = 3  # THST="Code Crash", ONSV=MAJOR (Python traceback occurred)
    SKIPPED = 4  # SKST="Skipped",    SKSV=NO_ALARM (Task was skipped)
