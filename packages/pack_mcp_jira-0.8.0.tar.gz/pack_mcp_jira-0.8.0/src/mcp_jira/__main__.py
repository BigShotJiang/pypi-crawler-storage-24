"""Permite executar o MCP Server do Jira com `python -m mcp_jira`."""

import asyncio
import logging
import sys

from mcp_jira.server import main

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    asyncio.run(main())
