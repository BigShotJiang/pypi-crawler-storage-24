"""Cliente HTTP do Jira com autenticação Basic Auth via REST API v2.

Usa header Authorization: Basic <token> direto na API REST.
Simples, sem estado, sem gerenciamento de sessão.
"""

import logging
import re

import requests

logger = logging.getLogger(__name__)


# --- Exceções ---


class JiraError(Exception):
    """Erro base para operações do Jira."""


class JiraConnectionError(JiraError):
    """Falha de conexão com o Jira."""


class JiraAuthError(JiraError):
    """Falha de autenticação no Jira."""


class JiraValidationError(JiraError):
    """Erro de validação de campos."""


# --- Cliente ---


class JiraClient:
    """Cliente HTTP para Jira via REST API v2 com Basic Auth."""

    def __init__(self, jira_url: str, token: str) -> None:
        self.jira_url = jira_url.rstrip("/")
        self._headers = {
            "Authorization": f"Basic {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        timeout: int = 30,
    ) -> requests.Response:
        """Executa request na REST API v2."""
        url = f"{self.jira_url}{path}"

        response = requests.request(
            method,
            url,
            headers=self._headers,
            json=json,
            params=params,
            timeout=timeout,
        )

        if response.status_code == 401:
            raise JiraAuthError("Token inválido ou expirado (401)")
        if response.status_code == 403:
            raise JiraAuthError("Sem permissão para esta operação (403)")

        return response

    def get_issue(self, issue_key: str) -> dict:
        """Busca uma issue pelo key."""
        response = self._request(
            "GET",
            f"/rest/api/2/issue/{issue_key}",
            params={"expand": "names,renderedFields"},
        )
        response.raise_for_status()

        data = response.json()
        fields = data.get("fields", {})
        names = data.get("names", {})

        # Coleta campos customizados relevantes
        custom_fields = {}
        for field_key, field_value in fields.items():
            if field_key.startswith("customfield_") and field_value:
                field_name = names.get(field_key, field_key)
                if isinstance(field_value, str) and len(field_value.strip()) > 50:
                    clean = re.sub(r"<[^>]+>", "", field_value).strip()
                    if clean and not clean.isdigit() and len(clean.split()) > 5:
                        custom_fields[field_name] = clean[:500]
                elif isinstance(field_value, dict):
                    if "value" in field_value:
                        custom_fields[field_name] = str(field_value["value"])
                    elif "name" in field_value:
                        custom_fields[field_name] = str(field_value["name"])

        status_obj = fields.get("status", {})
        priority_obj = fields.get("priority", {})
        issuetype_obj = fields.get("issuetype", {})
        assignee_obj = fields.get("assignee") or {}
        reporter_obj = fields.get("reporter") or {}

        description = fields.get("description", "") or ""
        if isinstance(description, str):
            description = re.sub(r"<[^>]+>", "", description).strip()

        return {
            "key": data.get("key", issue_key),
            "summary": fields.get("summary", f"Issue {issue_key}"),
            "description": description[:1000],
            "status": status_obj.get("name", "") if isinstance(status_obj, dict) else str(status_obj),
            "priority": priority_obj.get("name", "") if isinstance(priority_obj, dict) else str(priority_obj),
            "issuetype": issuetype_obj.get("name", "") if isinstance(issuetype_obj, dict) else str(issuetype_obj),
            "assignee": assignee_obj.get("displayName", "Não atribuído"),
            "reporter": reporter_obj.get("displayName", ""),
            "created": fields.get("created", ""),
            "updated": fields.get("updated", ""),
            "labels": fields.get("labels", []),
            "components": [c.get("name", "") for c in fields.get("components", [])],
            "custom_fields": custom_fields,
            "url": f"{self.jira_url}/browse/{data.get('key', issue_key)}",
        }

    def _resolve_custom_field_ids(self, project_key: str, issue_type_name: str) -> dict[str, str]:
        """Retorna mapa {nome_campo_lower: customfield_id} para campos customizados."""
        response = self._request(
            "GET",
            "/rest/api/2/issue/createmeta",
            params={
                "projectKeys": project_key,
                "issuetypeNames": issue_type_name,
                "expand": "projects.issuetypes.fields",
            },
        )
        if response.status_code != 200:
            return {}

        result: dict[str, str] = {}
        data = response.json()
        for project in data.get("projects", []):
            for issuetype in project.get("issuetypes", []):
                for field_key, field_info in issuetype.get("fields", {}).items():
                    if field_key.startswith("customfield_"):
                        result[field_info.get("name", "").lower()] = field_key
        return result

    def create_issue(
        self,
        project_key: str,
        summary: str,
        description: str,
        issue_type: str = "Bug",
        priority: str | None = None,
        labels: list[str] | None = None,
        components: list[str] | None = None,
        custom_fields: dict[str, str] | None = None,
    ) -> dict:
        """Cria uma nova issue no Jira."""
        missing = []
        if not project_key:
            missing.append("project_key")
        if not summary:
            missing.append("summary")
        if not description:
            missing.append("description")
        if missing:
            raise JiraValidationError(
                f"Campos obrigatórios ausentes: {', '.join(missing)}"
            )

        fields: dict = {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": issue_type},
        }
        if priority:
            fields["priority"] = {"name": priority}
        if labels:
            fields["labels"] = labels
        if components:
            fields["components"] = [{"name": c} for c in components]

        # Resolve campos customizados pelo nome usando createmeta
        if custom_fields:
            meta = self._resolve_custom_field_ids(project_key, issue_type)
            for field_name, field_value in custom_fields.items():
                field_id = meta.get(field_name.lower())
                if field_id:
                    fields[field_id] = {"value": field_value}

        response = self._request("POST", "/rest/api/2/issue", json={"fields": fields})

        if response.status_code in (200, 201):
            data = response.json()
            return {
                "key": data["key"],
                "url": f"{self.jira_url}/browse/{data['key']}",
            }

        # Tenta extrair mensagem de erro do Jira
        try:
            error_data = response.json()
            errors = error_data.get("errors", {})
            messages = error_data.get("errorMessages", [])
            detail = "; ".join(
                [f"{k}: {v}" for k, v in errors.items()] + messages
            )
        except Exception:
            detail = response.text[:300]

        raise JiraError(f"Erro ao criar issue (status {response.status_code}): {detail}")

    def search_issues(
        self,
        jql: str,
        max_results: int = 50,
        fields: list[str] | None = None,
    ) -> list[dict]:
        """Busca issues via JQL."""
        params: dict = {
            "jql": jql,
            "maxResults": max_results,
        }
        if fields:
            params["fields"] = ",".join(fields)

        response = self._request("GET", "/rest/api/2/search", params=params)
        response.raise_for_status()
        return response.json().get("issues", [])

    def update_issue(self, issue_key: str, fields: dict) -> None:
        """Atualiza campos de uma issue existente."""
        response = self._request(
            "PUT",
            f"/rest/api/2/issue/{issue_key}",
            json={"fields": fields},
        )

        if response.status_code not in (200, 204):
            try:
                detail = str(response.json())
            except Exception:
                detail = response.text[:300]
            raise JiraError(
                f"Erro ao atualizar {issue_key} (status {response.status_code}): {detail}"
            )

    def list_issue_types(self, project_key: str | None = None) -> list[dict]:
        """Lista os tipos de issue disponíveis, opcionalmente filtrados por projeto."""
        if project_key:
            response = self._request(
                "GET",
                f"/rest/api/2/project/{project_key}",
            )
            if response.status_code == 200:
                data = response.json()
                return [
                    {"id": it.get("id", ""), "name": it.get("name", ""), "subtask": it.get("subtask", False)}
                    for it in data.get("issueTypes", [])
                ]
            try:
                detail = str(response.json())
            except Exception:
                detail = response.text[:300]
            raise JiraError(
                f"Erro ao buscar tipos do projeto {project_key} (status {response.status_code}): {detail}"
            )

        response = self._request("GET", "/rest/api/2/issuetype")
        response.raise_for_status()
        return [
            {"id": it.get("id", ""), "name": it.get("name", ""), "subtask": it.get("subtask", False)}
            for it in response.json()
        ]

    def add_comment(self, issue_key: str, body: str) -> dict:
        """Adiciona um comentário a uma issue."""
        response = self._request(
            "POST",
            f"/rest/api/2/issue/{issue_key}/comment",
            json={"body": body},
        )

        if response.status_code in (200, 201):
            return response.json()

        try:
            detail = str(response.json())
        except Exception:
            detail = response.text[:300]
        raise JiraError(
            f"Erro ao comentar em {issue_key} (status {response.status_code}): {detail}"
        )
    def list_components(self, project_key: str) -> list[dict]:
        """Lista os componentes (funcionalidades) disponíveis em um projeto."""
        if not project_key:
            raise JiraValidationError("Campo obrigatório ausente: project_key")

        response = self._request(
            "GET",
            f"/rest/api/2/project/{project_key}/components",
        )

        if response.status_code == 200:
            return [
                {"id": c.get("id", ""), "name": c.get("name", ""), "description": c.get("description", "")}
                for c in response.json()
            ]

        try:
            detail = str(response.json())
        except Exception:
            detail = response.text[:300]
        raise JiraError(
            f"Erro ao buscar componentes do projeto {project_key} (status {response.status_code}): {detail}"
        )

    def list_custom_field_options(self, project_key: str, issue_type_name: str, field_name: str) -> list[dict]:
        """Lista as opções de um campo customizado para um projeto e tipo de issue."""
        if not project_key or not issue_type_name or not field_name:
            raise JiraValidationError("Campos obrigatórios: project_key, issue_type_name, field_name")

        # Busca metadados de criação para encontrar o field_id e allowedValues
        response = self._request(
            "GET",
            "/rest/api/2/issue/createmeta",
            params={
                "projectKeys": project_key,
                "issuetypeNames": issue_type_name,
                "expand": "projects.issuetypes.fields",
            },
        )

        if response.status_code != 200:
            try:
                detail = str(response.json())
            except Exception:
                detail = response.text[:300]
            raise JiraError(
                f"Erro ao buscar metadados de criação (status {response.status_code}): {detail}"
            )

        data = response.json()
        field_name_lower = field_name.lower()
        field_id = None

        for project in data.get("projects", []):
            project_id = project.get("id", "")
            for issuetype in project.get("issuetypes", []):
                issue_type_id = issuetype.get("id", "")
                fields = issuetype.get("fields", {})
                for field_key, field_info in fields.items():
                    if field_info.get("name", "").lower() == field_name_lower:
                        field_id = field_key
                        allowed = field_info.get("allowedValues", [])
                        if allowed:
                            return [
                                {
                                    "id": v.get("id", ""),
                                    "name": v.get("name", v.get("value", "")),
                                    "value": v.get("value", v.get("name", "")),
                                }
                                for v in allowed
                            ]

        # Fallback: tenta API do nFeed (plugin de campos dinâmicos)
        if field_id and field_id.startswith("customfield_"):
            return self._list_nfeed_options(field_id, project_id, issue_type_id)

        return []

    def _list_nfeed_options(self, field_id: str, project_id: str, issue_type_id: str) -> list[dict]:
        """Busca opções de um campo nFeed via API REST do plugin."""
        response = self._request(
            "POST",
            "/rest/nfeed/3.0/nFeed/field/input/options",
            json={
                "fieldId": field_id,
                "projectId": project_id,
                "issueTypeId": issue_type_id,
                "query": "",
            },
        )

        if response.status_code != 200:
            return []

        data = response.json()
        options = data if isinstance(data, list) else data.get("options", data.get("results", []))
        result = []
        for opt in options:
            if isinstance(opt, dict):
                result.append({
                    "id": str(opt.get("id", opt.get("value", ""))),
                    "name": opt.get("label", opt.get("name", opt.get("value", ""))),
                    "value": opt.get("value", opt.get("label", opt.get("name", ""))),
                })
            elif isinstance(opt, str):
                result.append({"id": opt, "name": opt, "value": opt})
        return result
