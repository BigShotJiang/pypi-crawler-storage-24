"""MCP Server para criação e gestão de tickets no Jira."""
