"""Configuração do MCP_Jira via variáveis de ambiente."""

import os


def load_env() -> tuple[str, str]:
    """Carrega configuração do Jira.

    Variáveis obrigatórias:
        JIRA_URL: URL base do Jira (ex: https://jira.sua-empresa.com)
        JIRA_TOKEN: Token Basic Auth em base64 (user:pass encodado)

    Returns:
        Tupla (jira_url, token).

    Raises:
        EnvironmentError: Se alguma variável obrigatória não estiver definida.
    """
    required = ["JIRA_URL", "JIRA_TOKEN"]
    missing = [v for v in required if not os.environ.get(v)]

    if missing:
        raise EnvironmentError(
            f"Variáveis de ambiente obrigatórias não definidas: {', '.join(missing)}"
        )

    return (
        os.environ["JIRA_URL"].rstrip("/"),
        os.environ["JIRA_TOKEN"].strip(),
    )
