"""MCP Server do Jira — inicialização via stdio."""

import asyncio
import logging
import sys

from mcp.server import Server
from mcp.server.stdio import stdio_server

from mcp_jira.config import load_env
from mcp_jira.jira_client import JiraClient
from mcp_jira.tools import register_tools

logger = logging.getLogger(__name__)


async def main() -> None:
    """Ponto de entrada principal do MCP Server do Jira."""
    jira_url, token = load_env()

    client = JiraClient(jira_url=jira_url, token=token)

    app = Server("mcp-jira")
    register_tools(app, client)

    logger.info("MCP Server do Jira iniciado (stdio)")

    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options(),
        )


def run() -> None:
    """Entry point síncrono para execução via `project.scripts`."""
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    asyncio.run(main())


if __name__ == "__main__":
    run()
