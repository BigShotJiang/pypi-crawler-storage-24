"""Testes unitários para mcp_jira/config.py."""

import pytest

from mcp_jira.config import load_env


class TestLoadEnv:
    """Testes para load_env."""

    def test_load_all_vars_set(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.exemplo.com/")
        monkeypatch.setenv("JIRA_TOKEN", "dGVzdDoxMjM=")

        jira_url, token = load_env()

        assert jira_url == "https://jira.exemplo.com"
        assert token == "dGVzdDoxMjM="

    def test_missing_jira_url(self, monkeypatch):
        monkeypatch.delenv("JIRA_URL", raising=False)
        monkeypatch.setenv("JIRA_TOKEN", "abc")

        with pytest.raises(EnvironmentError) as exc_info:
            load_env()
        assert "JIRA_URL" in str(exc_info.value)

    def test_missing_token(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.exemplo.com")
        monkeypatch.delenv("JIRA_TOKEN", raising=False)

        with pytest.raises(EnvironmentError) as exc_info:
            load_env()
        assert "JIRA_TOKEN" in str(exc_info.value)

    def test_missing_all_vars(self, monkeypatch):
        monkeypatch.delenv("JIRA_URL", raising=False)
        monkeypatch.delenv("JIRA_TOKEN", raising=False)

        with pytest.raises(EnvironmentError) as exc_info:
            load_env()
        error_msg = str(exc_info.value)
        assert "JIRA_URL" in error_msg
        assert "JIRA_TOKEN" in error_msg

    def test_empty_var_treated_as_missing(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "")
        monkeypatch.setenv("JIRA_TOKEN", "abc")

        with pytest.raises(EnvironmentError):
            load_env()

    def test_strips_trailing_slash(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.test.com///")
        monkeypatch.setenv("JIRA_TOKEN", "tok")

        jira_url, _ = load_env()
        assert jira_url == "https://jira.test.com"

    def test_strips_whitespace_from_token(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.test.com")
        monkeypatch.setenv("JIRA_TOKEN", "  tok123  ")

        _, token = load_env()
        assert token == "tok123"
