"""Testes unitários para mcp_jira/server.py."""

from unittest.mock import MagicMock

import pytest

from mcp_jira.config import load_env


class TestLoadEnvIntegration:
    """Testes de integração para o wiring do server."""

    def test_server_loads_env_and_creates_client(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.test.com")
        monkeypatch.setenv("JIRA_TOKEN", "dGVzdDoxMjM=")

        jira_url, token = load_env()
        assert jira_url == "https://jira.test.com"
        assert token == "dGVzdDoxMjM="

    def test_server_register_tools_wiring(self):
        from mcp.server import Server
        from mcp_jira.tools import register_tools

        app = Server("mcp-jira-test")
        mock_client = MagicMock()
        register_tools(app, mock_client)

    def test_server_fails_on_missing_env(self, monkeypatch):
        monkeypatch.delenv("JIRA_URL", raising=False)
        monkeypatch.delenv("JIRA_TOKEN", raising=False)

        with pytest.raises(EnvironmentError):
            load_env()
