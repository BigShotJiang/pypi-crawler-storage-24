"""Testes unitários para o cliente HTTP do Jira (Basic Auth)."""

from unittest.mock import MagicMock, patch

import pytest
import requests

from mcp_jira.jira_client import (
    JiraAuthError,
    JiraClient,
    JiraConnectionError,
    JiraError,
    JiraValidationError,
)


# --- Helpers ---


def _make_response(
    status_code: int = 200,
    json_data: dict | None = None,
    text: str = "",
    headers: dict | None = None,
) -> MagicMock:
    """Cria um mock de requests.Response."""
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status_code
    resp.text = text
    resp.json.return_value = json_data or {}
    resp.headers = headers or {"Content-Type": "application/json"}
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = requests.HTTPError(response=resp)
    return resp


def _make_client() -> JiraClient:
    """Cria um JiraClient para testes."""
    return JiraClient("https://jira.example.com", "dGVzdDoxMjM=")


# --- Testes de Exceções ---


class TestExceptions:
    def test_exception_hierarchy(self):
        assert issubclass(JiraConnectionError, JiraError)
        assert issubclass(JiraAuthError, JiraError)
        assert issubclass(JiraValidationError, JiraError)

    def test_jira_error_is_exception(self):
        assert issubclass(JiraError, Exception)


# --- Testes de __init__ ---


class TestInit:
    def test_strips_trailing_slash_from_url(self):
        client = JiraClient("https://jira.example.com/", "token")
        assert client.jira_url == "https://jira.example.com"

    def test_sets_auth_header(self):
        client = JiraClient("https://jira.example.com", "mytoken123")
        assert client._headers["Authorization"] == "Basic mytoken123"

    def test_sets_json_headers(self):
        client = _make_client()
        assert client._headers["Accept"] == "application/json"
        assert client._headers["Content-Type"] == "application/json"


# --- Testes de _request ---


class TestRequest:
    @patch("mcp_jira.jira_client.requests.request")
    def test_successful_get(self, mock_request):
        mock_request.return_value = _make_response(json_data={"ok": True})
        client = _make_client()
        resp = client._request("GET", "/rest/api/2/myself")
        assert resp.status_code == 200
        mock_request.assert_called_once()

    @patch("mcp_jira.jira_client.requests.request")
    def test_401_raises_auth_error(self, mock_request):
        mock_request.return_value = _make_response(status_code=401)
        client = _make_client()
        with pytest.raises(JiraAuthError, match="401"):
            client._request("GET", "/rest/api/2/myself")

    @patch("mcp_jira.jira_client.requests.request")
    def test_403_raises_auth_error(self, mock_request):
        mock_request.return_value = _make_response(status_code=403)
        client = _make_client()
        with pytest.raises(JiraAuthError, match="403"):
            client._request("GET", "/rest/api/2/issue/X-1")

    @patch("mcp_jira.jira_client.requests.request")
    def test_passes_headers_and_params(self, mock_request):
        mock_request.return_value = _make_response()
        client = _make_client()
        client._request("GET", "/rest/api/2/search", params={"jql": "x"})
        call_kwargs = mock_request.call_args
        assert call_kwargs.kwargs["params"] == {"jql": "x"}
        assert "Basic" in call_kwargs.kwargs["headers"]["Authorization"]

    @patch("mcp_jira.jira_client.requests.request")
    def test_passes_json_body(self, mock_request):
        mock_request.return_value = _make_response(status_code=201)
        client = _make_client()
        client._request("POST", "/rest/api/2/issue", json={"fields": {}})
        call_kwargs = mock_request.call_args
        assert call_kwargs.kwargs["json"] == {"fields": {}}


# --- Testes de get_issue ---


class TestGetIssue:
    @patch("mcp_jira.jira_client.requests.request")
    def test_returns_issue_data(self, mock_request):
        issue_data = {
            "key": "PROJ-123",
            "names": {},
            "fields": {
                "summary": "Test issue",
                "description": "Some desc",
                "status": {"name": "Open"},
                "priority": {"name": "High"},
                "issuetype": {"name": "Bug"},
                "assignee": {"displayName": "Dev"},
                "reporter": {"displayName": "QA"},
                "created": "2025-01-01",
                "updated": "2025-01-02",
                "labels": ["test"],
                "components": [{"name": "backend"}],
            },
        }
        mock_request.return_value = _make_response(json_data=issue_data)
        client = _make_client()
        result = client.get_issue("PROJ-123")
        assert result["key"] == "PROJ-123"
        assert result["summary"] == "Test issue"
        assert result["status"] == "Open"
        assert result["assignee"] == "Dev"
        assert result["url"] == "https://jira.example.com/browse/PROJ-123"


# --- Testes de create_issue ---


class TestCreateIssue:
    def test_missing_project_key_raises_validation_error(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="project_key"):
            client.create_issue("", "summary", "desc")

    def test_missing_summary_raises_validation_error(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="summary"):
            client.create_issue("PROJ", "", "desc")

    def test_missing_description_raises_validation_error(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="description"):
            client.create_issue("PROJ", "summary", "")

    def test_missing_multiple_fields_lists_all(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="project_key.*summary.*description"):
            client.create_issue("", "", "")

    @patch("mcp_jira.jira_client.requests.request")
    def test_successful_create_returns_key_and_url(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=201, json_data={"key": "PROJ-456", "id": "10001"}
        )
        client = _make_client()
        result = client.create_issue("PROJ", "Bug title", "Bug description")
        assert result["key"] == "PROJ-456"
        assert result["url"] == "https://jira.example.com/browse/PROJ-456"

    @patch("mcp_jira.jira_client.requests.request")
    def test_create_with_optional_fields(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=201, json_data={"key": "PROJ-789"}
        )
        client = _make_client()
        client.create_issue(
            "PROJ", "Title", "Desc",
            issue_type="Task", priority="High",
            labels=["urgent"], components=["backend"],
        )
        body = mock_request.call_args.kwargs["json"]["fields"]
        assert body["issuetype"]["name"] == "Task"
        assert body["priority"]["name"] == "High"
        assert body["labels"] == ["urgent"]
        assert body["components"] == [{"name": "backend"}]

    @patch("mcp_jira.jira_client.requests.request")
    def test_create_error_raises_jira_error(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=400,
            json_data={"errors": {"issuetype": "Tipo inválido"}, "errorMessages": []},
        )
        client = _make_client()
        with pytest.raises(JiraError, match="Tipo inválido"):
            client.create_issue("PROJ", "Title", "Desc")


# --- Testes de search_issues ---


class TestSearchIssues:
    @patch("mcp_jira.jira_client.requests.request")
    def test_returns_list_of_issues(self, mock_request):
        issues = [
            {"key": "PROJ-1", "fields": {"summary": "A"}},
            {"key": "PROJ-2", "fields": {"summary": "B"}},
        ]
        mock_request.return_value = _make_response(json_data={"issues": issues, "total": 2})
        client = _make_client()
        result = client.search_issues("project = PROJ")
        assert len(result) == 2
        assert result[0]["key"] == "PROJ-1"

    @patch("mcp_jira.jira_client.requests.request")
    def test_passes_fields_parameter(self, mock_request):
        mock_request.return_value = _make_response(json_data={"issues": []})
        client = _make_client()
        client.search_issues("project = PROJ", fields=["summary", "status"])
        params = mock_request.call_args.kwargs["params"]
        assert params["fields"] == "summary,status"


# --- Testes de update_issue ---


class TestUpdateIssue:
    @patch("mcp_jira.jira_client.requests.request")
    def test_update_success(self, mock_request):
        mock_request.return_value = _make_response(status_code=204)
        client = _make_client()
        client.update_issue("PROJ-1", {"summary": "Updated"})
        assert mock_request.call_args.args[0] == "PUT"

    @patch("mcp_jira.jira_client.requests.request")
    def test_update_error_raises_jira_error(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=400, json_data={"errors": {"summary": "obrigatório"}}
        )
        client = _make_client()
        with pytest.raises(JiraError, match="obrigatório"):
            client.update_issue("PROJ-1", {"summary": ""})


# --- Testes de add_comment ---


class TestAddComment:
    @patch("mcp_jira.jira_client.requests.request")
    def test_returns_comment_data(self, mock_request):
        comment_data = {"id": "10001", "body": "Test comment"}
        mock_request.return_value = _make_response(
            status_code=201, json_data=comment_data
        )
        client = _make_client()
        result = client.add_comment("PROJ-1", "Test comment")
        assert result["id"] == "10001"

    @patch("mcp_jira.jira_client.requests.request")
    def test_comment_error_raises_jira_error(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=404, json_data={"errorMessages": ["Issue não encontrada"]}
        )
        client = _make_client()
        with pytest.raises(JiraError, match="404"):
            client.add_comment("PROJ-999", "comment")
