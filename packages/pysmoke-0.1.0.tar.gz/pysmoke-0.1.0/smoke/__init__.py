"""
smoke - Small Molecule Octet/BLI Kinetics Experiment

Bio-Layer Interferometry (BLI) is a technology to determine the binding
kinetics between biomolecules. BLI signals are small and noisy when small
molecules are investigated as ligands (analytes). This package processes
and analyzes BLI data acquired on Octet Red96 from Fortebio more accurately.

Reference: Sun Q., Li X., et al (2020) <doi:10.1038/s41467-019-14238-3>
"""

from .bli import Bli

__version__ = "0.1.0"
__all__ = ["Bli"]
