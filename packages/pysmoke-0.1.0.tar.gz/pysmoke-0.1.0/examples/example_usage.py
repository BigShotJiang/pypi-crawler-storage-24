import os
import pandas as pd
import matplotlib.pyplot as plt
from smoke.bli import Bli

# Load the sample dataset (resolves path relative to this script)
_dir = os.path.dirname(os.path.abspath(__file__))
traces_df = pd.read_csv(os.path.join(_dir, 'traces.csv'), header=None)

# Create an instance of the Bli class
bli_experiment = Bli()

# Set the traces DataFrame
bli_experiment.traces = traces_df

# Set ligand concentrations (example values, adjust as necessary)
bli_experiment.ligand = [16.00,  8.00,  4.00,  2.00,  1.00,  0.50,  0.25]

# Set the experimental times for association and dissociation start
bli_experiment.t_exp = [1260, 1860]  # Example times, adjust based on your data

# Processing pipeline
bli_experiment.align_load(load_start=180, load_end=780)
bli_experiment.double_blank()
bli_experiment.baseline_correct(t_start=1080, t_end=1260)
 
# Estimate initial rates 
bli_experiment.estimate()

# Perform the integrated kinetics fitting (option 1)
bli_experiment.fit_kinetics()

# Perform the ODE kinetics fitting (option 2)
bli_experiment.ode_kinetics(negative_response=False)

# Print the fitted parameters
print(bli_experiment.get_kinetics())

# Plot
bli_experiment.plot_traces()
bli_experiment.plot_kinetics()
bli_experiment.plot_residuals()
bli_experiment.plot_confidence_contours()
plt.show()
