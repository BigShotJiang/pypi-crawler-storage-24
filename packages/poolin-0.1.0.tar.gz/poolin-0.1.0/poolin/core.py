from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO, StringIO
import csv
import json
from pathlib import Path
import re
from typing import Iterable
import zipfile

import numpy as np

POOLING_METHODS: list[tuple[str, str]] = [
    ("auto", "Auto (recommended)"),
    ("mean", "Mean pooling across chunk embeddings"),
    ("max", "Elementwise max pooling"),
    ("weighted_char_mean", "Weighted mean using character counts"),
    ("weighted_word_mean", "Weighted mean using word counts"),
    ("mean_sqrt_len", "Mean scaled by sqrt(number of chunks)"),
]

SUMMARY_FILES = {"pooling_summary.json", "embedding_summary.json"}
JSONL_SUFFIX = ".jsonl"
NPZ_SUFFIX = ".npz"


@dataclass
class EmbeddedRecord:
    item_id: str
    source_file: str
    text: str
    char_count: int
    word_count: int
    embedding_dim: int
    model_name: str
    embedding: np.ndarray


@dataclass
class PooledRecord:
    pooled_id: str
    group_key: str
    source_files: list[str]
    member_count: int
    total_characters: int
    total_words: int
    embedding_dim: int
    source_model_name: str
    pooling_method: str
    embedding: np.ndarray


class PoolingError(RuntimeError):
    pass


def supported_pooling_methods() -> list[tuple[str, str]]:
    return POOLING_METHODS.copy()


def infer_default_pooling(model_name: str, normalized: bool | None = None) -> str:
    """Post-embedding pooling heuristic.

    This is not token pooling inside the original embedding model. It aggregates
    already-produced embedding vectors into higher-level grouped vectors.
    """
    _ = model_name.lower()
    if normalized is True:
        return "mean"
    return "weighted_char_mean"


def _safe_stem(filename: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", Path(filename).stem).strip("_") or "pooling_output"


def _group_key_from_filename(source_file: str) -> str:
    stem = Path(source_file).stem
    patterns = [
        r"^(?P<base>.+?)_rcs_\d+$",
        r"^(?P<base>.+?)_chunk_\d+$",
        r"^(?P<base>.+?)_part_\d+$",
        r"^(?P<base>.+?)_split_\d+$",
    ]
    for pat in patterns:
        m = re.match(pat, stem)
        if m:
            return m.group("base")
    return stem


def _load_summary_from_zip(zf: zipfile.ZipFile) -> dict:
    for name in zf.namelist():
        if Path(name).name in SUMMARY_FILES:
            return json.loads(zf.read(name).decode("utf-8"))
    return {}


def _load_records_from_npz(npz_bytes: bytes, summary: dict) -> list[EmbeddedRecord]:
    data = np.load(BytesIO(npz_bytes), allow_pickle=True)
    if not {"ids", "source_files", "texts", "embeddings"}.issubset(set(data.files)):
        raise PoolingError("The NPZ file does not contain the expected embedding arrays.")

    ids = data["ids"]
    source_files = data["source_files"]
    texts = data["texts"]
    embeddings = data["embeddings"]

    model_name = str(summary.get("model_name", "unknown"))
    records: list[EmbeddedRecord] = []
    for i in range(len(ids)):
        text = str(texts[i])
        records.append(
            EmbeddedRecord(
                item_id=str(ids[i]),
                source_file=str(source_files[i]),
                text=text,
                char_count=len(text),
                word_count=len(text.split()),
                embedding_dim=int(embeddings.shape[1]),
                model_name=model_name,
                embedding=np.asarray(embeddings[i], dtype=np.float32),
            )
        )
    return records


def _load_records_from_jsonl(jsonl_text: str) -> list[EmbeddedRecord]:
    records: list[EmbeddedRecord] = []
    for line in jsonl_text.splitlines():
        line = line.strip()
        if not line:
            continue
        obj = json.loads(line)
        records.append(
            EmbeddedRecord(
                item_id=str(obj.get("id", "")),
                source_file=str(obj.get("source_file", "")),
                text=str(obj.get("text", "")),
                char_count=int(obj.get("char_count", 0)),
                word_count=int(obj.get("word_count", 0)),
                embedding_dim=int(obj.get("embedding_dim", 0)),
                model_name=str(obj.get("model_name", "unknown")),
                embedding=np.asarray(obj.get("embedding", []), dtype=np.float32),
            )
        )
    return records


def load_embedding_zip_bytes(zip_bytes: bytes) -> tuple[list[EmbeddedRecord], dict]:
    with zipfile.ZipFile(BytesIO(zip_bytes), "r") as zf:
        summary = _load_summary_from_zip(zf)

        npz_name = next((name for name in zf.namelist() if name.lower().endswith(NPZ_SUFFIX)), None)
        if npz_name:
            records = _load_records_from_npz(zf.read(npz_name), summary)
            if records:
                return records, summary

        jsonl_name = next((name for name in zf.namelist() if name.lower().endswith(JSONL_SUFFIX)), None)
        if jsonl_name:
            records = _load_records_from_jsonl(zf.read(jsonl_name).decode("utf-8"))
            if records:
                return records, summary

    raise PoolingError(
        "Could not find a supported embedding payload inside the zip. Expected an embeddings .npz or .jsonl file."
    )


def _l2_normalize(vec: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vec))
    if norm <= 0:
        return vec
    return vec / norm


def _pool_vectors(vectors: np.ndarray, weights: np.ndarray | None, method: str) -> np.ndarray:
    if vectors.ndim != 2:
        raise PoolingError("Expected a 2D embedding array for pooling.")
    if len(vectors) == 1:
        return vectors[0].copy()

    if method == "mean":
        return vectors.mean(axis=0)
    if method == "max":
        return vectors.max(axis=0)
    if method == "weighted_char_mean" or method == "weighted_word_mean":
        if weights is None:
            return vectors.mean(axis=0)
        weights = np.asarray(weights, dtype=np.float32)
        if weights.sum() <= 0:
            return vectors.mean(axis=0)
        weights = weights / weights.sum()
        return np.average(vectors, axis=0, weights=weights)
    if method == "mean_sqrt_len":
        return vectors.mean(axis=0) / np.sqrt(float(len(vectors)))
    raise PoolingError(f"Unsupported pooling method: {method}")


def pool_embedding_records(
    records: list[EmbeddedRecord],
    pooling_method: str = "auto",
    normalize_output: bool = True,
) -> tuple[list[dict], list[PooledRecord], dict]:
    if not records:
        raise PoolingError("No embedding records were found in the input zip.")

    source_model_name = records[0].model_name
    input_dim = records[0].embedding_dim
    inferred_normalized = None
    if records[0].embedding.size:
        inferred_normalized = bool(abs(float(np.linalg.norm(records[0].embedding)) - 1.0) < 0.05)

    resolved_method = pooling_method
    if pooling_method == "auto":
        resolved_method = infer_default_pooling(source_model_name, inferred_normalized)

    grouped: dict[str, list[EmbeddedRecord]] = {}
    for rec in records:
        key = _group_key_from_filename(rec.source_file)
        grouped.setdefault(key, []).append(rec)

    manifest: list[dict] = []
    pooled_records: list[PooledRecord] = []
    for idx, key in enumerate(sorted(grouped.keys()), start=1):
        members = grouped[key]
        vectors = np.stack([m.embedding for m in members]).astype(np.float32)
        weights = None
        if resolved_method == "weighted_char_mean":
            weights = np.asarray([max(m.char_count, 1) for m in members], dtype=np.float32)
        elif resolved_method == "weighted_word_mean":
            weights = np.asarray([max(m.word_count, 1) for m in members], dtype=np.float32)

        pooled = _pool_vectors(vectors, weights, resolved_method)
        if normalize_output:
            pooled = _l2_normalize(pooled)

        pooled_id = f"pool_{idx:03d}"
        total_chars = sum(m.char_count for m in members)
        total_words = sum(m.word_count for m in members)
        source_files = [m.source_file for m in members]

        pooled_rec = PooledRecord(
            pooled_id=pooled_id,
            group_key=key,
            source_files=source_files,
            member_count=len(members),
            total_characters=total_chars,
            total_words=total_words,
            embedding_dim=int(pooled.shape[0]),
            source_model_name=source_model_name,
            pooling_method=resolved_method,
            embedding=pooled.astype(np.float32),
        )
        pooled_records.append(pooled_rec)
        manifest.append(
            {
                "pooled_id": pooled_id,
                "group_key": key,
                "member_count": len(members),
                "total_characters": total_chars,
                "total_words": total_words,
                "embedding_dim": int(pooled.shape[0]),
                "source_model_name": source_model_name,
                "pooling_method": resolved_method,
            }
        )

    summary = {
        "input_embeddings": len(records),
        "pooled_outputs": len(pooled_records),
        "input_embedding_dim": input_dim,
        "output_embedding_dim": input_dim,
        "source_model_name": source_model_name,
        "pooling_method": resolved_method,
        "normalize_output": normalize_output,
        "grouping_rule": "filename auto-grouping by removing trailing _rcs_N / _chunk_N / _part_N / _split_N",
    }
    return manifest, pooled_records, summary


def _manifest_csv_bytes(manifest: list[dict]) -> bytes:
    sio = StringIO()
    fieldnames = [
        "pooled_id",
        "group_key",
        "member_count",
        "total_characters",
        "total_words",
        "embedding_dim",
        "source_model_name",
        "pooling_method",
    ]
    writer = csv.DictWriter(sio, fieldnames=fieldnames)
    writer.writeheader()
    for row in manifest:
        writer.writerow(row)
    return sio.getvalue().encode("utf-8")


def _pooled_jsonl_bytes(items: list[PooledRecord]) -> bytes:
    lines = []
    for item in items:
        lines.append(
            json.dumps(
                {
                    "pooled_id": item.pooled_id,
                    "group_key": item.group_key,
                    "source_files": item.source_files,
                    "member_count": item.member_count,
                    "total_characters": item.total_characters,
                    "total_words": item.total_words,
                    "embedding_dim": item.embedding_dim,
                    "source_model_name": item.source_model_name,
                    "pooling_method": item.pooling_method,
                    "embedding": item.embedding.tolist(),
                },
                ensure_ascii=False,
            )
        )
    return ("\n".join(lines) + "\n").encode("utf-8")


def _pooled_csv_bytes(items: list[PooledRecord]) -> bytes:
    sio = StringIO()
    writer = csv.writer(sio)
    writer.writerow(
        [
            "pooled_id",
            "group_key",
            "member_count",
            "total_characters",
            "total_words",
            "embedding_dim",
            "source_model_name",
            "pooling_method",
            "source_files",
            "embedding",
        ]
    )
    for item in items:
        writer.writerow(
            [
                item.pooled_id,
                item.group_key,
                item.member_count,
                item.total_characters,
                item.total_words,
                item.embedding_dim,
                item.source_model_name,
                item.pooling_method,
                " | ".join(item.source_files),
                json.dumps(item.embedding.tolist()),
            ]
        )
    return sio.getvalue().encode("utf-8")


def _pooled_npz_bytes(items: list[PooledRecord]) -> bytes:
    ids = np.asarray([item.pooled_id for item in items], dtype=object)
    group_keys = np.asarray([item.group_key for item in items], dtype=object)
    source_files = np.asarray([" | ".join(item.source_files) for item in items], dtype=object)
    embeddings = np.stack([item.embedding for item in items]).astype(np.float32)
    member_counts = np.asarray([item.member_count for item in items], dtype=np.int32)

    buffer = BytesIO()
    np.savez_compressed(
        buffer,
        ids=ids,
        group_keys=group_keys,
        source_files=source_files,
        member_counts=member_counts,
        embeddings=embeddings,
    )
    return buffer.getvalue()


def _summary_json_bytes(summary: dict) -> bytes:
    return json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8")


def build_output_zip_bytes(
    manifest: list[dict],
    items: list[PooledRecord],
    summary: dict,
    input_zip_name: str,
    formats: list[str] | tuple[str, ...],
) -> bytes:
    selected = set(formats)
    base_name = _safe_stem(input_zip_name)

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("pooling_summary.json", _summary_json_bytes(summary))
        zf.writestr("pooling_manifest.csv", _manifest_csv_bytes(manifest))

        if "jsonl" in selected:
            zf.writestr(f"{base_name}_pooled_embeddings.jsonl", _pooled_jsonl_bytes(items))
        if "csv" in selected:
            zf.writestr(f"{base_name}_pooled_embeddings.csv", _pooled_csv_bytes(items))
        if "npz" in selected:
            zf.writestr(f"{base_name}_pooled_embeddings.npz", _pooled_npz_bytes(items))

    return buffer.getvalue()
