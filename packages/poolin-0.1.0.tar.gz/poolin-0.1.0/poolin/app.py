from __future__ import annotations

import streamlit as st

from poolin.core import (
    build_output_zip_bytes,
    load_embedding_zip_bytes,
    pool_embedding_records,
    supported_pooling_methods,
)

st.set_page_config(
    page_title="poolin",
    page_icon="🧩",
    layout="wide",
)

st.title("poolin")
st.caption(
    "Pool existing embedding vectors from an embedding zip into grouped higher-level vectors with a local UI."
)

with st.sidebar:
    st.header("Settings")
    method_options = supported_pooling_methods()
    labels = [f"{name} — {desc}" for name, desc in method_options]
    selected_label = st.selectbox("Pooling method", labels, index=0)
    pooling_method = method_options[labels.index(selected_label)][0]

    normalize_output = st.checkbox("Normalize pooled embeddings", value=True)
    formats = st.multiselect(
        "Output formats inside export zip",
        options=["jsonl", "csv", "npz"],
        default=["jsonl", "npz"],
        help="jsonl = readable records, csv = spreadsheet-friendly, npz = direct NumPy arrays.",
    )

uploaded = st.file_uploader("Drag the embeddings zip here", type=["zip"])

if uploaded is None:
    st.info(
        "Upload a zip produced by your embedding step. It should contain an embeddings .npz or .jsonl payload."
    )
    st.stop()

if not formats:
    st.warning("Select at least one export format.")
    st.stop()

with st.expander("What this step actually does", expanded=False):
    st.write(
        "This app performs post-embedding vector pooling across related chunk embeddings. "
        "It does not replace the token-pooling layer that originally produced each sentence embedding inside the embedding model."
    )

if st.button("Generate pooled vectors", type="primary"):
    with st.spinner("Reading embedding zip and pooling vectors..."):
        try:
            records, input_summary = load_embedding_zip_bytes(uploaded.read())
            manifest, items, summary = pool_embedding_records(
                records,
                pooling_method=pooling_method,
                normalize_output=normalize_output,
            )
            export_bytes = build_output_zip_bytes(
                manifest,
                items,
                summary,
                input_zip_name=uploaded.name,
                formats=formats,
            )
        except Exception as exc:
            st.error(str(exc))
            st.stop()

    col1, col2 = st.columns([1, 2])
    with col1:
        st.metric("Input embeddings", summary["input_embeddings"])
        st.metric("Pooled outputs", summary["pooled_outputs"])
        st.metric("Embedding dimension", summary["output_embedding_dim"])
        st.metric("Pooling method", summary["pooling_method"])

    with col2:
        st.subheader("Input model")
        st.write(input_summary.get("model_name", summary.get("source_model_name", "unknown")))
        st.subheader("Preview")
        st.dataframe(manifest[:10], use_container_width=True)

    st.download_button(
        "Download poolin zip",
        data=export_bytes,
        file_name=f"{uploaded.name.rsplit('.', 1)[0]}_pooled.zip",
        mime="application/zip",
    )
