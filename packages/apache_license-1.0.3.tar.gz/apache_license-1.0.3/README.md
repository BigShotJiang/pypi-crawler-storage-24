# Apache License Check

A command-line tool for verifying that Python source files contain proper Apache License 2.0 headers.

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python Version](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)

## Overview

Apache License Check automates the process of ensuring all Python files in your project include the required Apache License 2.0 header. This tool is essential for maintaining license compliance in open-source projects and enterprise codebases.

## Features

- 🔍 Recursively scans directories for Python files
- ✅ Validates Apache License 2.0 header presence
- 📝 Optional copyright notice verification
- 🎨 Color-coded terminal output for easy scanning
- 🚫 Flexible file and directory exclusion
- 🔧 CI/CD integration ready
- ⚡ Fast and lightweight

## Installation

### From PyPI

```bash
pip install apache_license
```

### From Source

```bash
git clone https://github.com/facultyai/apache_license.git
cd apache_license
pip install .
```

## Usage

### Basic Usage

Check all Python files in the current directory:

```bash
apache_license
```

### Specify Paths

Check specific files or directories:

```bash
apache_license src/ tests/ setup.py
```

### Copyright Verification

Verify that files include a copyright notice with specific text:

```bash
apache_license --copyright "Your Company Name"
```

### Advanced Options

```bash
# Include hidden files and directories
apache_license --include-hidden

# Include empty files (e.g., __init__.py)
apache_license --include-empty

# Exclude specific paths
apache_license --exclude build/ dist/ venv/

# Combine multiple options
apache_license src/ --copyright "Acme Corp" --exclude tests/
```

## Command-Line Options

| Option | Description |
|--------|-------------|
| `path` | Path(s) of files or directories to check (default: current directory) |
| `--include-hidden` | Check hidden files and directories |
| `--include-empty` | Require license headers in empty files |
| `--exclude` | Path(s) of files or directories to ignore |
| `--copyright` | Verify copyright notice contains the specified substring |

## Expected License Header Format

The tool checks for the following Apache License 2.0 header:

```python
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
```

## CI/CD Integration

### GitHub Actions

```yaml
name: License Check

on: [push, pull_request]

jobs:
  license-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.x'
      - name: Install apache_license
        run: pip install apache_license
      - name: Check license headers
        run: apache_license --copyright "Your Company"
```

### GitLab CI

```yaml
license-check:
  image: python:3.9
  script:
    - pip install apache_license
    - apache_license --copyright "Your Company"
```

### Pre-commit Hook

Add to `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: local
    hooks:
      - id: apache_license
        name: Apache License Check
        entry: apache_license
        language: system
        types: [python]
```

## Exit Codes

- `0`: All files pass the license check
- `1`: One or more files are missing the required license header

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the Apache License 2.0 - see the LICENSE file for details.

## Authors

- Faculty Science Limited

## Links

- [GitHub Repository](https://github.com/facultyai/apache_license)
- [Homepage](https://faculty.ai/)
