"""AgentBase Memory Store implementation following BaseStore pattern.

This implementation uses the ops pattern and batch function handlers,
directly calling the AgentBase Memory API for create_event and retrieve_memory_records.
"""

import logging
import uuid
from collections.abc import Iterable
from datetime import datetime, timezone
from typing import Any

from langchain_core.messages import BaseMessage
from langgraph.store.base import (
    BaseStore,
    GetOp,
    Item,
    ListNamespacesOp,
    Op,
    PutOp,
    Result,
    SearchItem,
    SearchOp,
)

from greennode_agentbase.memory import MemoryClient
from greennode_agentbase.memory.models import EventCreateRequest, EventPayload

from greennode_agent_bridge.langgraph.memory.helpers import (
    convert_langchain_messages_to_event_messages,
)

logger = logging.getLogger(__name__)


class AgentBaseMemoryRecords(BaseStore):
    """
    AgentBase Memory Store implementation using BaseStore pattern.

    This store saves chat messages as conversational events in AgentBase Memory
    and retrieves processed memories through semantic search. The embedding and
    memory processing happens automatically in the AgentBase Memory service.

    Args:
        memory_id: The AgentBase Memory resource ID
        memory_client: Optional MemoryClient instance. If not provided, creates a new one.

    Example:
        ```python
        store = AgentBaseMemoryRecords(
            memory_id="memory_abc123"
        )

        # Store a message
        from langchain_core.messages import HumanMessage
        store.put(("user123", "session456"), "msg1", {
            "message": HumanMessage("I love coffee")
        })

        # Search for processed memories
        results = store.search(("facts", "user123"), query="user preferences")
        # With minimum score threshold
        results = store.search(("facts", "user123"), query="...", score=5)
        ```
    """

    supports_ttl: bool = False
    ttl_config = None

    def __init__(self, *, memory_id: str, memory_client: MemoryClient | None = None):
        self.memory_id = memory_id
        self.memory_client = memory_client or MemoryClient()

    def search(
        self,
        namespace_prefix: tuple[str, ...],
        /,
        *,
        query: str | None = None,
        filter: dict[str, Any] | None = None,
        limit: int = 10,
        offset: int = 0,
        refresh_ttl: bool | None = None,
        score: float | None = None,
    ) -> list[SearchItem]:
        """Search for items with optional minimum score threshold."""
        merged_filter = dict(filter) if filter else {}
        if score is not None:
            merged_filter["score"] = score
        return super().search(
            namespace_prefix,
            query=query,
            filter=merged_filter or None,
            limit=limit,
            offset=offset,
            refresh_ttl=refresh_ttl,
        )

    async def asearch(
        self,
        namespace_prefix: tuple[str, ...],
        /,
        *,
        query: str | None = None,
        filter: dict[str, Any] | None = None,
        limit: int = 10,
        offset: int = 0,
        refresh_ttl: bool | None = None,
        score: float | None = None,
    ) -> list[SearchItem]:
        """Asynchronously search for items with optional minimum score threshold."""
        merged_filter = dict(filter) if filter else {}
        if score is not None:
            merged_filter["score"] = score
        return await super().asearch(
            namespace_prefix,
            query=query,
            filter=merged_filter or None,
            limit=limit,
            offset=offset,
            refresh_ttl=refresh_ttl,
        )

    def batch(self, ops: Iterable[Op]) -> list[Result]:
        """Execute multiple operations in a single batch."""
        results: list[Result] = []

        for op in ops:
            if isinstance(op, PutOp):
                self._handle_put(op)
                results.append(None)
            elif isinstance(op, SearchOp):
                result = self._handle_search(op)
                results.append(result)
            elif isinstance(op, GetOp):
                result = self._handle_get(op)
                results.append(result)
            elif isinstance(op, ListNamespacesOp):
                # ListNamespacesOp not supported for AgentBase Memory
                results.append([])
            else:
                raise ValueError(f"Unknown operation type: {type(op)}")

        return results

    async def abatch(self, ops: Iterable[Op]) -> list[Result]:
        """Execute multiple operations asynchronously."""
        results: list[Result] = []

        for op in ops:
            if isinstance(op, PutOp):
                await self._handle_put_async(op)
                results.append(None)
            elif isinstance(op, SearchOp):
                result = await self._handle_search_async(op)
                results.append(result)
            elif isinstance(op, GetOp):
                result = await self._handle_get_async(op)
                results.append(result)
            elif isinstance(op, ListNamespacesOp):
                # ListNamespacesOp not supported for AgentBase Memory
                results.append([])
            else:
                raise ValueError(f"Unknown operation type: {type(op)}")

        return results

    def _handle_put(self, op: PutOp) -> None:
        """Handle PutOp by creating conversational events in AgentBase Memory."""
        if op.value is None:
            # TODO: Delete operation support - need to figure out if we are deleting events or records
            logger.warning("Delete operations not supported in AgentBase Memory")
            return

        message = op.value.get("message")
        if not isinstance(message, BaseMessage):
            raise ValueError(
                "Value must contain a 'message' key with a BaseMessage object"
            )

        # Convert namespace tuple to actor_id and session_id
        if len(op.namespace) != 2:
            raise ValueError("Namespace must be a tuple of (actor_id, session_id)")

        actor_id, session_id = op.namespace
        event_messages = convert_langchain_messages_to_event_messages([message])

        if not event_messages:
            logger.warning(
                f"No valid event messages to create for message type: {message.type}"
            )
            return

        for text, role in event_messages:
            payload = EventPayload(type="conversational", message=text, role=role)
            request = EventCreateRequest(payload=payload)

            self.memory_client.create_event(
                id=self.memory_id,
                actorId=actor_id,
                sessionId=session_id,
                request=request,
            )

        logger.debug(f"Created event for message in namespace {op.namespace}")

    async def _handle_put_async(self, op: PutOp) -> None:
        """Handle PutOp asynchronously by creating conversational events in AgentBase Memory."""
        if op.value is None:
            logger.warning("Delete operations not supported in AgentBase Memory")
            return

        message = op.value.get("message")
        if not isinstance(message, BaseMessage):
            raise ValueError(
                "Value must contain a 'message' key with a BaseMessage object"
            )

        if len(op.namespace) != 2:
            raise ValueError("Namespace must be a tuple of (actor_id, session_id)")

        actor_id, session_id = op.namespace
        event_messages = convert_langchain_messages_to_event_messages([message])

        if not event_messages:
            logger.warning(
                f"No valid event messages to create for message type: {message.type}"
            )
            return

        for text, role in event_messages:
            payload = EventPayload(type="conversational", message=text, role=role)
            request = EventCreateRequest(payload=payload)

            self.memory_client.create_event(
                id=self.memory_id,
                actorId=actor_id,
                sessionId=session_id,
                request=request,
            )

        logger.debug(f"Created event for message in namespace {op.namespace}")

    def _handle_get(self, op: GetOp) -> Result:
        """Handle GetOp by retrieving a specific memory record from AgentBase Memory.

        Uses list_memory_records (spec has no get-by-id) and filters by op.key.
        """
        try:
            namespace_str = self._convert_namespace_to_string(op.namespace)
            records = self.memory_client.list_memory_records(
                id=self.memory_id,
                namespace=namespace_str,
            )

            if not isinstance(records, list):
                records = getattr(records, "list_data", []) or []
            for record in records:
                record_id = record.get("id") if isinstance(record, dict) else getattr(record, "id", None)
                if record_id == op.key:
                    record_dict = record if isinstance(record, dict) else {
                        "id": getattr(record, "id", None),
                        "memory_record_id": getattr(record, "memory_record_id", None),
                        "memory": getattr(record, "memory", "") or getattr(record, "content", ""),
                        "content": getattr(record, "content", "") or getattr(record, "memory", ""),
                        "memory_strategy_id": getattr(record, "memory_strategy_id", None),
                        "namespaces": getattr(record, "namespaces", []),
                    }
                    return self._convert_memory_record_to_item(record_dict, op.namespace)
            return None

        except Exception as e:
            error_code = getattr(e, "status_code", None)
            if error_code == 404:
                return None
            logger.error(f"Failed to get memory record: {e}")
            raise

    async def _handle_get_async(self, op: GetOp) -> Result:
        """Handle GetOp asynchronously by retrieving a specific memory record.

        Uses list_memory_records (spec has no get-by-id) and filters by op.key.
        """
        try:
            namespace_str = self._convert_namespace_to_string(op.namespace)
            records = self.memory_client.list_memory_records(
                id=self.memory_id,
                namespace=namespace_str,
            )
            if not isinstance(records, list):
                records = getattr(records, "list_data", []) or []
            for record in records:
                record_id = record.get("id") if isinstance(record, dict) else getattr(record, "id", None)
                if record_id == op.key:
                    record_dict = record if isinstance(record, dict) else {
                        "id": getattr(record, "id", None),
                        "memory_record_id": getattr(record, "memory_record_id", None),
                        "memory": getattr(record, "memory", "") or getattr(record, "content", ""),
                        "content": getattr(record, "content", "") or getattr(record, "memory", ""),
                        "memory_strategy_id": getattr(record, "memory_strategy_id", None),
                        "namespaces": getattr(record, "namespaces", []),
                    }
                    return self._convert_memory_record_to_item(record_dict, op.namespace)
            return None

        except Exception as e:
            error_code = getattr(e, "status_code", None)
            if error_code == 404:
                return None
            logger.error(f"Failed to get memory record: {e}")
            raise

    def _handle_search(self, op: SearchOp) -> Result:
        """Handle SearchOp by retrieving memory records from AgentBase Memory."""
        if not op.query:
            logger.warning("Search requires a query for AgentBase Memory")
            return []

        namespace_str = self._convert_namespace_to_string(op.namespace_prefix)

        from greennode_agentbase.memory.models import MemoryRecordSearchRequest

        score = op.filter.get("score") if op.filter else None
        search_request = MemoryRecordSearchRequest(query=op.query, limit=op.limit, scoreThreshold=score)

        response = self.memory_client.search_memory_records(
            id=self.memory_id,
            namespace=namespace_str,
            request=search_request,
        )

        memory_records = (
            response
            if isinstance(response, list)
            else (getattr(response, "list_data", None) or [])
        )
        return self._convert_memory_records_to_search_items(
            memory_records, op.namespace_prefix, score=score
        )

    async def _handle_search_async(self, op: SearchOp) -> Result:
        """Handle SearchOp asynchronously by retrieving memory records."""
        if not op.query:
            logger.warning("Search requires a query for AgentBase Memory")
            return []

        namespace_str = self._convert_namespace_to_string(op.namespace_prefix)

        from greennode_agentbase.memory.models import MemoryRecordSearchRequest

        score = op.filter.get("score") if op.filter else None
        search_request = MemoryRecordSearchRequest(query=op.query, limit=op.limit, scoreThreshold=score)

        response = self.memory_client.search_memory_records(
            id=self.memory_id,
            namespace=namespace_str,
            request=search_request,
        )

        memory_records = (
            response
            if isinstance(response, list)
            else (getattr(response, "list_data", None) or [])
        )
        return self._convert_memory_records_to_search_items(
            memory_records, op.namespace_prefix, score=score
        )

    def _convert_namespace_to_string(self, namespace_tuple: tuple[str, ...]) -> str:
        """Convert namespace tuple to AgentBase namespace string."""
        if not isinstance(namespace_tuple, tuple):
            raise TypeError("namespace_tuple must be a tuple")
        if not namespace_tuple:
            return "/"
        return "/" + "/".join(namespace_tuple)

    def _convert_memory_record_to_item(
        self, memory_record: dict, namespace: tuple[str, ...]
    ) -> Item:
        """Convert a single AgentBase memory record (dict) to an Item object."""
        content = memory_record.get("memory", "") or memory_record.get("content", "")
        text = str(content)
        created_at = memory_record.get("created_at", None)

        memory_record_id = (
            memory_record.get("id")
            or memory_record.get("memory_record_id")
            or str(uuid.uuid4())
        )

        return Item(
            namespace=namespace,
            key=str(memory_record_id),
            value={
                "content": text,
                "memory_strategy_id": memory_record.get("memory_strategy_id"),
                "namespaces": memory_record.get("namespaces", []),
            },
            created_at=created_at,
            updated_at=created_at,
        )

    def _convert_memory_records_to_search_items(
        self,
        memory_records: list,
        namespace: tuple[str, ...],
        score: int | float | None = None,
    ) -> list[SearchItem]:
        """Convert AgentBase memory records to SearchItem objects."""
        results = []
        for record in memory_records:
            score = (
                record.get("score")
                if isinstance(record, dict)
                else getattr(record, "score", None)
            )
            if score is not None and (score is None or score < score):
                continue

            content = (
                record.get("memory", "")
                if isinstance(record, dict)
                else getattr(record, "memory", "") or ""
            )
            text = str(content)
            memory_record_id = (
                record.get("id") or record.get("memory_record_id") or str(uuid.uuid4())
                if isinstance(record, dict)
                else getattr(record, "id", None)
                or getattr(record, "memory_record_id", None)
                or str(uuid.uuid4())
            )
            created_at = (
                record.get("created_at")
                if isinstance(record, dict)
                else getattr(record, "created_at", None)
            )

            if isinstance(created_at, str):
                created_at_dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
            else:
                created_at_dt = created_at or datetime.now()

            search_item = SearchItem(
                namespace=namespace,
                key=str(memory_record_id),
                value={
                    "content": text,
                    "memory_strategy_id": memory_record_id,
                    "namespaces": namespace,
                },
                created_at=created_at_dt,  
                updated_at=created_at_dt,
                score=float(score) if score is not None else None,
            )
            results.append(search_item)

        return results