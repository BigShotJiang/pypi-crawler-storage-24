"""Helper classes for AgentBase Memory Checkpoint Saver."""

from __future__ import annotations

import base64
import datetime
import json
import logging
import warnings
from collections import defaultdict
from typing import Any, cast

from langchain_core.messages import AIMessage, BaseMessage, ToolMessage
from langgraph.checkpoint.base import (
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
    RunnableConfig,
    SerializerProtocol,
)

from greennode_agentbase.memory import MemoryClient
from greennode_agentbase.memory.models import EventCreateRequest, EventPayload

from greennode_agent_bridge.langgraph.memory.constants import (
    EMPTY_CHANNEL_VALUE,
    EventDecodingError,
)
from greennode_agent_bridge.langgraph.memory.models import (
    ChannelDataEvent,
    CheckpointerConfig,
    CheckpointEvent,
    WriteItem,
    WritesEvent,
)

logger = logging.getLogger(__name__)

# Union type for all events
EventType = CheckpointEvent | ChannelDataEvent | WritesEvent

# Default retry configuration
DEFAULT_MAX_RETRIES = 3
DEFAULT_INITIAL_BACKOFF = 0.1  # 100ms
DEFAULT_MAX_BACKOFF = 2.0  # 2 seconds


class EventSerializer:
    """Handles serialization and deserialization of events to store in AgentBase Memory."""

    def __init__(self, serde: SerializerProtocol):
        self.serde = serde

    def serialize_value(self, value: Any) -> dict[str, Any]:
        """Serialize a value using the serde protocol."""
        type_tag, binary_data = self.serde.dumps_typed(value)
        return {"type": type_tag, "data": base64.b64encode(binary_data).decode("utf-8")}

    def deserialize_value(self, serialized: dict[str, Any]) -> Any:
        """Deserialize a value using the serde protocol."""
        try:
            type_tag = serialized["type"]
            binary_data = base64.b64decode(serialized["data"])
            return self.serde.loads_typed((type_tag, binary_data))
        except Exception as e:
            raise EventDecodingError(f"Failed to deserialize value: {e}") from e

    def serialize_event(self, event: EventType) -> str:
        """Serialize an event to JSON string."""

        # Create a custom serializer for Pydantic models
        def custom_serializer(obj):
            if hasattr(obj, "model_dump"):
                return obj.model_dump()
            raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

        # Get the base dictionary
        event_dict = event.model_dump(exclude_none=True)

        # Handle special serialization for specific fields
        if isinstance(event, CheckpointEvent):
            event_dict["checkpoint_data"] = self.serialize_value(event.checkpoint_data)
            event_dict["metadata"] = self.serialize_value(event.metadata)

        elif isinstance(event, ChannelDataEvent):
            if event.value != EMPTY_CHANNEL_VALUE:
                event_dict["value"] = self.serialize_value(event.value)

        elif isinstance(event, WritesEvent):
            event_dict["writes"] = [
                {
                    **write.model_dump(exclude_none=True),
                    "value": self.serialize_value(write.value),
                }
                for write in event.writes
            ]

        return json.dumps(event_dict, default=custom_serializer)

    def deserialize_event(self, data: str) -> EventType:
        """Deserialize JSON string to event."""
        try:
            event_dict = json.loads(data)
            event_type = event_dict.get("event_type")

            if event_type == "checkpoint":
                # Deserialize checkpoint data and metadata
                event_dict["checkpoint_data"] = self.deserialize_value(
                    event_dict["checkpoint_data"]
                )
                event_dict["metadata"] = self.deserialize_value(event_dict["metadata"])
                return CheckpointEvent(**event_dict)

            elif event_type == "channel_data":
                # Deserialize channel value if not empty
                if "value" in event_dict and isinstance(event_dict["value"], dict):
                    event_dict["value"] = self.deserialize_value(event_dict["value"])
                return ChannelDataEvent(**event_dict)

            elif event_type == "writes":
                # Deserialize write values
                for write in event_dict["writes"]:
                    if isinstance(write["value"], dict):
                        write["value"] = self.deserialize_value(write["value"])
                return WritesEvent(**event_dict)

            else:
                raise EventDecodingError(f"Unknown event type: {event_type}")

        except json.JSONDecodeError as e:
            raise EventDecodingError(f"Failed to parse JSON: {e}") from e
        except Exception as e:
            raise EventDecodingError(f"Failed to deserialize event: {e}") from e


class AgentBaseEventClient:
    """Handles low-level event storage and retrieval from AgentBase Memory for checkpoints."""

    def __init__(
        self,
        memory_id: str,
        serializer: EventSerializer | None = None,
        *,
        memory_client: MemoryClient | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        initial_backoff: float = DEFAULT_INITIAL_BACKOFF,
        max_backoff: float = DEFAULT_MAX_BACKOFF,
    ):
        """Initialize the AgentBase event client.

        Args:
            memory_id: The ID of the AgentBase memory to use
            serializer: Optional custom event serializer
            memory_client: Optional MemoryClient instance. If not provided, creates a new one.
            max_retries: Maximum number of retry attempts for retryable errors
            initial_backoff: Initial backoff time in seconds for exponential backoff
            max_backoff: Maximum backoff time in seconds
        """
        self.memory_id = memory_id
        # mypy: need to set actual serializer if None
        if serializer is None:
            from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer

            self.serializer = EventSerializer(JsonPlusSerializer())
        else:
            self.serializer = serializer

        self.memory_client = memory_client or MemoryClient()
        self.max_retries = max_retries
        self.initial_backoff = initial_backoff
        self.max_backoff = max_backoff

    def store_blob_event(
        self, event: EventType, session_id: str, actor_id: str
    ) -> None:
        """Store an event in AgentBase Memory."""
        serialized = self.serializer.serialize_event(event)
        base64_content = base64.b64encode(serialized.encode("utf-8")).decode("utf-8")

        payload = EventPayload(type="binary", binary_data=base64_content)
        request = EventCreateRequest(payload=payload)

        self.memory_client.create_event(
            id=self.memory_id,
            actorId=actor_id,
            sessionId=session_id,
            request=request,
        )

    def store_blob_events_batch(
        self, events: list[EventType], session_id: str, actor_id: str
    ) -> None:
        """Store multiple events in a single API call to AgentBase Memory."""
        for event in events:
            serialized = self.serializer.serialize_event(event)
            base64_content = base64.b64encode(serialized.encode("utf-8")).decode(
                "utf-8"
            )
            payload = EventPayload(type="binary", binary_data=base64_content)
            request = EventCreateRequest(payload=payload)

            self.memory_client.create_event(
                id=self.memory_id,
                actorId=actor_id,
                sessionId=session_id,
                request=request,
            )


    def get_events(
        self,
        session_id: str,
        actor_id: str,
        limit: int | None = None,
        max_results: int | None = 100,
    ) -> list[EventType]:
        """Retrieve events from AgentBase Memory.

        Args:
            session_id: The session ID to retrieve events for
            actor_id: The actor ID to retrieve events for
            limit: The maximum number of events to parse from ListEvents
            max_results: Maximum number of results to retrieve. Defaults to 100.

        Returns:
            List of retrieved events
        """

        if max_results is not None and max_results <= 0:
            return []

        all_events = []
        page = 1
        limit_reached = False

        


        while True:
            response = self.memory_client.list_events(
                id=self.memory_id,
                actorId=actor_id,
                sessionId=session_id,
                page=page,
                size=max_results or 100,
            )

            events_list = response.list_data or []

            for event in events_list:
                payload = getattr(event, "payload", None)
                if payload is None:
                    continue
                # Binary type (checkpoint blobs)
                if getattr(payload, "type", None) == "binary":
                    raw = getattr(payload, "binary_data", None)
                    if raw:
                        try:
                            content = base64.b64decode(raw).decode("utf-8")
                            parsed_event = self.serializer.deserialize_event(content)
                            all_events.append(parsed_event)
                        except EventDecodingError as e:
                            logger.warning(f"Failed to decode event: {e}")

                if limit is not None and len(all_events) >= limit:
                    limit_reached = True
                    break

            if limit_reached:
                if page < (response.total_page or 1):
                    warnings.warn(
                        f"Stopped retrieving events at limit of {limit}. "
                        f"There may be additional checkpoints that were not retrieved. "
                        f"Consider increasing the limit parameter, or set None for no "
                        f"limit.",
                        UserWarning,
                        stacklevel=2,
                    )
                break

            # Check if there are more pages
            if page >= (response.total_page or 1):
                break
            page += 1

        return all_events

    def delete_events(self, session_id: str, actor_id: str) -> None:
        """Delete all events for a session."""
        page = 1
        size = 100

        while True:
            response = self.memory_client.list_events(
                id=self.memory_id,
                actorId=actor_id,
                sessionId=session_id,
                page=page,
                size=size,
            )

            events_list = response.list_data or []

            if not events_list:
                break

            for event in events_list:
                if event.id:
                    self.memory_client.delete_event(
                        id=self.memory_id,
                        actorId=actor_id,
                        sessionId=session_id,
                        eventId=event.id,
                    )

            if page >= (response.total_page or 1):
                break
            page += 1


class EventProcessor:
    """Processes events into checkpoint data structures."""

    @staticmethod
    def process_events(
        events: list[EventType],
    ) -> tuple[
        dict[str, CheckpointEvent],
        dict[str, list[WriteItem]],
        dict[tuple[str, str], Any],
    ]:
        """Process events into organized data structures."""
        checkpoints = {}
        writes_by_checkpoint = defaultdict(list)
        channel_data_by_version = {}

        for event in events:
            if isinstance(event, CheckpointEvent):
                checkpoints[event.checkpoint_id] = event

            elif isinstance(event, WritesEvent):
                writes_by_checkpoint[event.checkpoint_id].extend(event.writes)

            elif isinstance(event, ChannelDataEvent):
                if event.value != EMPTY_CHANNEL_VALUE:
                    channel_data_by_version[(event.channel, event.version)] = (
                        event.value
                    )

        return checkpoints, writes_by_checkpoint, channel_data_by_version

    @staticmethod
    def build_checkpoint_tuple(
        checkpoint_event: CheckpointEvent,
        writes: list[WriteItem],
        channel_data: dict[tuple[str, str], Any],
        config: CheckpointerConfig,
    ) -> CheckpointTuple:
        """Build a CheckpointTuple from processed data."""
        # Build pending writes
        pending_writes = [
            (write.task_id, write.channel, write.value) for write in writes
        ]
        # Check if there are interrupts in pending writes
        has_interrupts = pending_writes and any(
            write[1] == "__interrupt__" and write[2] for write in pending_writes
        )
        # Build parent config
        parent_config = None
        if checkpoint_event.parent_checkpoint_id:
            parent_config = {
                "configurable": {
                    "thread_id": config.thread_id,
                    "actor_id": config.actor_id,
                    "checkpoint_ns": config.checkpoint_ns,
                    "checkpoint_id": checkpoint_event.parent_checkpoint_id,
                }
            }

        # Build checkpoint with channel values
        checkpoint = checkpoint_event.checkpoint_data.copy()
        channel_values = {}

        for channel, version in checkpoint.get("channel_versions", {}).items():
            if (channel, version) in channel_data:
                channel_values[channel] = channel_data[(channel, version)]

        # Validate if messages are present and no langchain interrupts detected
        # Then patch orphan tool_calls from messages
        # This ensures messages loaded from checkpoints are valid for LLM providers
        if "messages" in channel_values and not has_interrupts:
            channel_values["messages"] = patch_orphan_tool_calls(
                channel_values["messages"]
            )

        checkpoint["channel_values"] = channel_values

        return CheckpointTuple(
            config={
                "configurable": {
                    "thread_id": config.thread_id,
                    "actor_id": config.actor_id,
                    "checkpoint_ns": config.checkpoint_ns,
                    "checkpoint_id": checkpoint_event.checkpoint_id,
                }
            },
            checkpoint=cast(Checkpoint, checkpoint),
            metadata=cast(CheckpointMetadata, checkpoint_event.metadata),
            parent_config=cast(RunnableConfig, parent_config)
            if parent_config
            else None,
            pending_writes=pending_writes,
        )


def patch_orphan_tool_calls(messages: list[Any]) -> list[Any]:
    """Add placeholder ToolMessages for orphaned tool_calls in AIMessages.

    When a checkpoint is saved mid-tool-execution, there may be AIMessages with
    tool_calls that don't have corresponding ToolMessages. This would cause
    LLM providers to throw a ValidationException. This function patches the state by
    adding placeholder ToolMessages with status="error" for each orphaned tool_call.

    Args:
        messages: List of messages from checkpoint channel_values

    Returns:
        List of messages with placeholder ToolMessages added for orphaned tool_calls
    """
    if not messages:
        return messages

    patched_messages = []

    for i, msg in enumerate(messages):
        patched_messages.append(msg)

        if isinstance(msg, AIMessage) and msg.tool_calls:
            for tool_call in msg.tool_calls:
                tc_id = tool_call.get("id")
                tc_name = tool_call.get("name", "unknown")

                corresponding_tool_msg = next(
                    (
                        m
                        for m in messages[i + 1 :]
                        if isinstance(m, ToolMessage) and m.tool_call_id == tc_id
                    ),
                    None,
                )

                if corresponding_tool_msg is None:
                    logger.warning(
                        f"Adding placeholder ToolMessage for orphaned tool_call "
                        f"'{tc_name}' (id: {tc_id}) during checkpoint load"
                    )
                    patched_messages.append(
                        ToolMessage(
                            content=(
                                f"Tool call '{tc_name}' with id '{tc_id}' was "
                                f"interrupted before completion."
                            ),
                            name=tc_name,
                            tool_call_id=tc_id,
                            status="error",
                        )
                    )

    return patched_messages


def convert_langchain_messages_to_event_messages(
    messages: list[BaseMessage],
) -> list[tuple[str, str]]:
    """Convert LangChain messages to AgentBase event messages.

    Args:
        messages: List of Langchain messages (BaseMessage)

    Returns:
        List of AgentBase event tuples (text, role)
    """
    converted_messages = []
    for msg in messages:
        # Skip if event already saved
        if msg.additional_kwargs.get("event_id") is not None:
            continue

        text = msg.text()
        if not text.strip():
            continue

        # Map LangChain roles to AgentBase roles
        if msg.type == "human":
            role = "user"
        elif msg.type == "ai":
            role = "assistant"
        elif msg.type == "tool":
            role = "tool"
        elif msg.type == "system":
            role = "system"
        else:
            logger.warning(f"Skipping unsupported message type: {msg.type}")
            continue

        converted_messages.append((text, role))

    return converted_messages
