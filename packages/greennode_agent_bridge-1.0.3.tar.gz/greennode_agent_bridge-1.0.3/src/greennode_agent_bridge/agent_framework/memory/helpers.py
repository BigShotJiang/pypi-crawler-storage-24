"""Helper functions for Agent Framework Memory adaptor."""

from __future__ import annotations

import json
import logging
import warnings
from typing import TYPE_CHECKING, Any

from greennode_agentbase.memory import MemoryClient
from greennode_agentbase.memory.models import EventCreateRequest, EventPayload

if TYPE_CHECKING:
    from agent_framework import Message

logger = logging.getLogger(__name__)


def convert_af_message_to_event_payload(af_message: "Message") -> EventPayload:
    """Convert an Agent Framework Message to GreenNode EventPayload format."""
    from agent_framework import Message

    return EventPayload(
        type="conversational",
        message=json.dumps(af_message.to_dict()),
        role=af_message.role,
    )


def convert_event_payload_to_af_message(payload: Any) -> "Message":
    """Convert a GreenNode event payload to Agent Framework Message format."""
    from agent_framework import Message

    message_content = getattr(payload, "message", None)
    role = getattr(payload, "role", "user")

    if not message_content:
        return Message(
            role=role,
            contents=[],
        )

    content_dict: dict = json.loads(message_content)
    return Message.from_dict(content_dict)


def get_chat_history_sync(
    memory_client: MemoryClient,
    memory_id: str,
    session_id: str,
    actor_id: str | None = None,
    limit: int | None = None,
    max_results: int | None = 100,
) -> list["Message"]:
    """Retrieve chat history from AgentBase Memory using sync list_events."""
    from agent_framework import Message

    if max_results is not None and max_results <= 0:
        return []

    all_events: list[Message] = []
    page = 1
    limit_reached = False

    while True:
        response = memory_client.list_events(
            id=memory_id,
            actorId=actor_id,
            sessionId=session_id,
            page=page,
            size=max_results or 100,
        )

        events_list = response.list_data or []

        for event in events_list:
            payload = getattr(event, "payload", None)
            if payload is None:
                continue
            if getattr(payload, "type", None) != "conversational":
                continue
            try:
                parsed_event = convert_event_payload_to_af_message(payload)
                all_events.append(parsed_event)
            except Exception as e:
                logger.warning("Failed to decode event: %s", e)

            if limit is not None and len(all_events) >= limit:
                limit_reached = True
                break

        if limit_reached:
            if page < (response.total_page or 1):
                warnings.warn(
                    f"Stopped retrieving events at limit of {limit}. "
                    "There may be additional events that were not retrieved. "
                    "Consider increasing the limit parameter, or set None for no limit.",
                    UserWarning,
                    stacklevel=2,
                )
            break

        if page >= (response.total_page or 1):
            break
        page += 1

    return all_events
