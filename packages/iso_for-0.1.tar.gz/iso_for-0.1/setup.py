from setuptools import setup, find_packages

setup(
    name="iso_for",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    package_data={"iso_for": ["data.txt"]},
)
