from importlib.resources import files
print(files("iso_for").joinpath("data.txt").read_text())
