# -*- coding: utf-8 -*-

#    Copyright (C) 2016-2025 Mathew Topper
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import time
import traceback
import warnings
from logging.handlers import RotatingFileHandler
from pathlib import Path

from polite_config.configuration import Logger
from polite_config.paths import ModPath, UserDataPath
from PySide6 import QtGui, QtWidgets
from PySide6.QtCore import Qt

from .utils.qtlog import QtHandler

PARENT_PATH = Path(__file__).parent


def warn_with_traceback(
    message, category, filename, lineno, file=None, line=None
):
    log = file if hasattr(file, "write") else sys.stderr
    assert log is not None
    traceback.print_stack(file=log)
    log.write(warnings.formatwarning(message, category, filename, lineno, line))


def start_logging(debug=False):
    # Disable the logging QtHandler if the debug flag is set
    QtHandler.debug = debug

    # Pick up the configuration from the user directory if it exists
    userdir = UserDataPath("dtocean_app", "DTOcean", "config")
    logging_config = userdir / "logging.yaml"

    # Look for logging.yaml
    if logging_config.is_file():
        configdir = userdir
    else:
        configdir = ModPath("dtocean_app", "config")

    # Get the logger configuration
    log = Logger(configdir)
    log_config_dict = log.read()

    # Get Directory to place logs
    log_dir = get_log_dir()

    # Update the file logger if present
    if "file" in log_config_dict["handlers"]:
        log_filename = log_config_dict["handlers"]["file"]["filename"]
        log_path = log_dir / log_filename
        log_config_dict["handlers"]["file"]["filename"] = str(log_path)
        log_dir.mkdir(exist_ok=True, parents=True)

    log.configure_logger(log_config_dict)
    logger = log.get_named_logger("dtocean_app")

    # Rotate any rotating file handlers
    for handler in logger.handlers:
        if isinstance(handler, RotatingFileHandler):
            try:
                handler.doRollover()
            except OSError:
                pass

    logger.info("Welcome to DTOcean")


def get_log_dir():
    userdir = UserDataPath("dtocean_app", "DTOcean")
    log_path = userdir / "logs"
    return log_path


# def main(debug=False, trace_warnings=False):
#    """An example of profiling"""
#    import cProfile
#    cProfile.runctx("main_(debug, trace_warnings)",
#                    globals(),
#                    locals(),
#                    "profile.stat")


def main_(debug=False, trace_warnings=False, force_quit=False):
    """Run the DTOcean tool"""

    # Add traces to warnings
    if trace_warnings:
        warnings.showwarning = warn_with_traceback

    # Bring up the logger
    start_logging(debug)

    # Build the main app
    app = QtWidgets.QApplication(sys.argv)

    # Create and display the splash screen
    splash_path = PARENT_PATH / "resources" / "dtocean_splash_20251712.png"
    splash_pix = QtGui.QPixmap(splash_path)
    splash = QtWidgets.QSplashScreen(
        splash_pix,
        Qt.WindowType.WindowStaysOnTopHint,
    )
    splash_font = QtGui.QFont()
    splash_font.setFamily("Verdana")
    splash_font.setPointSize(8)
    splash.setMask(splash_pix.mask())
    splash.setFont(splash_font)
    splash.show()
    app.processEvents()

    time.sleep(0.2)

    message_allignment = (
        Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom
    )
    message_color = Qt.GlobalColor.white

    splash.showMessage("Loading matplotlib", message_allignment, message_color)

    import matplotlib
    import matplotlib.pyplot  # noqa: F401

    splash.showMessage("Loading pandas", message_allignment, message_color)

    import pandas  # noqa: F401

    splash.showMessage(
        "Loading DTOcean core", message_allignment, message_color
    )

    import dtocean_core.core  # noqa: F401

    from .core import GUICore

    splash.showMessage(
        "Loading DTOcean interface", message_allignment, message_color
    )

    from .shell import Shell
    from .window import DTOceanWindow

    splash.showMessage(
        "Preparing data catalogue", message_allignment, message_color
    )

    core = GUICore()
    core._create_data_catalog()

    splash.showMessage("Preparing modules", message_allignment, message_color)

    core._create_control()

    splash.showMessage("Preparing IO", message_allignment, message_color)

    core._create_sockets()
    core._init_plots()

    splash.showMessage(
        "Starting DTOcean application", message_allignment, message_color
    )

    time.sleep(0.2)

    shell = Shell(core)
    main_window = DTOceanWindow(shell, debug)
    main_window.show()

    splash.finish(main_window)

    if not force_quit:
        sys.exit(app.exec())
