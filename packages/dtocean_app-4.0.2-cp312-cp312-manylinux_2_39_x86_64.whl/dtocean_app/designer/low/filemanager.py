# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'filemanager.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QButtonGroup, QDialogButtonBox,
    QFrame, QHBoxLayout, QLabel, QLayout,
    QLineEdit, QRadioButton, QSizePolicy, QSpacerItem,
    QToolButton, QVBoxLayout, QWidget)

class Ui_FileManagerWidget(object):
    def setupUi(self, FileManagerWidget):
        if not FileManagerWidget.objectName():
            FileManagerWidget.setObjectName(u"FileManagerWidget")
        FileManagerWidget.resize(372, 216)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(FileManagerWidget.sizePolicy().hasHeightForWidth())
        FileManagerWidget.setSizePolicy(sizePolicy)
        FileManagerWidget.setMinimumSize(QSize(350, 0))
        self.verticalLayout = QVBoxLayout(FileManagerWidget)
        self.verticalLayout.setSpacing(4)
        self.verticalLayout.setContentsMargins(4, 4, 4, 4)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.headingLabel = QLabel(FileManagerWidget)
        self.headingLabel.setObjectName(u"headingLabel")
        self.headingLabel.setTextFormat(Qt.TextFormat.RichText)

        self.verticalLayout.addWidget(self.headingLabel)

        self.line = QFrame(FileManagerWidget)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label_3 = QLabel(FileManagerWidget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setMinimumSize(QSize(65, 0))

        self.horizontalLayout.addWidget(self.label_3)

        self.loadButton = QRadioButton(FileManagerWidget)
        self.modeButtonGroup = QButtonGroup(FileManagerWidget)
        self.modeButtonGroup.setObjectName(u"modeButtonGroup")
        self.modeButtonGroup.addButton(self.loadButton)
        self.loadButton.setObjectName(u"loadButton")
        self.loadButton.setMinimumSize(QSize(60, 0))

        self.horizontalLayout.addWidget(self.loadButton)

        self.saveButton = QRadioButton(FileManagerWidget)
        self.modeButtonGroup.addButton(self.saveButton)
        self.saveButton.setObjectName(u"saveButton")
        self.saveButton.setMinimumSize(QSize(60, 0))

        self.horizontalLayout.addWidget(self.saveButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_2 = QLabel(FileManagerWidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(65, 0))

        self.horizontalLayout_2.addWidget(self.label_2)

        self.pathEdit = QLineEdit(FileManagerWidget)
        self.pathEdit.setObjectName(u"pathEdit")

        self.horizontalLayout_2.addWidget(self.pathEdit)

        self.getPathButton = QToolButton(FileManagerWidget)
        self.getPathButton.setObjectName(u"getPathButton")

        self.horizontalLayout_2.addWidget(self.getPathButton)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.verticalSpacer = QSpacerItem(20, 80, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(FileManagerWidget)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Ok)

        self.verticalLayout.addWidget(self.buttonBox)

        self.buttonBox.raise_()
        self.line.raise_()
        self.headingLabel.raise_()

        self.retranslateUi(FileManagerWidget)

        QMetaObject.connectSlotsByName(FileManagerWidget)
    # setupUi

    def retranslateUi(self, FileManagerWidget):
        FileManagerWidget.setWindowTitle(QCoreApplication.translate("FileManagerWidget", u"Form", None))
        self.headingLabel.setText(QCoreApplication.translate("FileManagerWidget", u"<html><head/><body><p><span style=\" font-weight:600;\">Variable File Manager:</span></p></body></html>", None))
        self.label_3.setText(QCoreApplication.translate("FileManagerWidget", u"File mode: ", None))
        self.loadButton.setText(QCoreApplication.translate("FileManagerWidget", u"LOAD", None))
        self.saveButton.setText(QCoreApplication.translate("FileManagerWidget", u"SAVE", None))
        self.label_2.setText(QCoreApplication.translate("FileManagerWidget", u"File path: ", None))
        self.getPathButton.setText(QCoreApplication.translate("FileManagerWidget", u"...", None))
    # retranslateUi

