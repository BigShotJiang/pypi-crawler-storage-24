# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'levelcomparison.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QButtonGroup, QCheckBox,
    QDialogButtonBox, QFrame, QHBoxLayout, QLabel,
    QRadioButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_LevelComparisonWidget(object):
    def setupUi(self, LevelComparisonWidget):
        if not LevelComparisonWidget.objectName():
            LevelComparisonWidget.setObjectName(u"LevelComparisonWidget")
        LevelComparisonWidget.resize(320, 192)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(LevelComparisonWidget.sizePolicy().hasHeightForWidth())
        LevelComparisonWidget.setSizePolicy(sizePolicy)
        LevelComparisonWidget.setMinimumSize(QSize(320, 0))
        self.verticalLayout = QVBoxLayout(LevelComparisonWidget)
        self.verticalLayout.setSpacing(4)
        self.verticalLayout.setContentsMargins(4, 4, 4, 4)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.headingLabel = QLabel(LevelComparisonWidget)
        self.headingLabel.setObjectName(u"headingLabel")
        font = QFont()
        font.setBold(True)
        self.headingLabel.setFont(font)
        self.headingLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.verticalLayout.addWidget(self.headingLabel)

        self.line = QFrame(LevelComparisonWidget)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.topHorizontalLayout = QHBoxLayout()
        self.topHorizontalLayout.setObjectName(u"topHorizontalLayout")
        self.label_3 = QLabel(LevelComparisonWidget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setMinimumSize(QSize(40, 0))

        self.topHorizontalLayout.addWidget(self.label_3)

        self.plotButton = QRadioButton(LevelComparisonWidget)
        self.modeButtonGroup = QButtonGroup(LevelComparisonWidget)
        self.modeButtonGroup.setObjectName(u"modeButtonGroup")
        self.modeButtonGroup.addButton(self.plotButton)
        self.plotButton.setObjectName(u"plotButton")
        self.plotButton.setMinimumSize(QSize(55, 0))
        self.plotButton.setChecked(True)

        self.topHorizontalLayout.addWidget(self.plotButton)

        self.dataButton = QRadioButton(LevelComparisonWidget)
        self.modeButtonGroup.addButton(self.dataButton)
        self.dataButton.setObjectName(u"dataButton")
        self.dataButton.setEnabled(True)
        self.dataButton.setMinimumSize(QSize(55, 0))

        self.topHorizontalLayout.addWidget(self.dataButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.topHorizontalLayout.addItem(self.horizontalSpacer)

        self.strategyBox = QCheckBox(LevelComparisonWidget)
        self.strategyBox.setObjectName(u"strategyBox")
        self.strategyBox.setEnabled(False)
        self.strategyBox.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.strategyBox.setChecked(True)

        self.topHorizontalLayout.addWidget(self.strategyBox)


        self.verticalLayout.addLayout(self.topHorizontalLayout)

        self.verticalSpacer_2 = QSpacerItem(20, 2, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.bottomHorizontalLayout = QHBoxLayout()
        self.bottomHorizontalLayout.setObjectName(u"bottomHorizontalLayout")
        self.label_2 = QLabel(LevelComparisonWidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(65, 0))

        self.bottomHorizontalLayout.addWidget(self.label_2)


        self.verticalLayout.addLayout(self.bottomHorizontalLayout)

        self.verticalSpacer = QSpacerItem(20, 80, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(LevelComparisonWidget)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Save)

        self.verticalLayout.addWidget(self.buttonBox)

        self.buttonBox.raise_()
        self.line.raise_()
        self.headingLabel.raise_()

        self.retranslateUi(LevelComparisonWidget)

        QMetaObject.connectSlotsByName(LevelComparisonWidget)
    # setupUi

    def retranslateUi(self, LevelComparisonWidget):
        LevelComparisonWidget.setWindowTitle(QCoreApplication.translate("LevelComparisonWidget", u"Form", None))
        self.headingLabel.setText(QCoreApplication.translate("LevelComparisonWidget", u"Module Comparison:", None))
        self.label_3.setText(QCoreApplication.translate("LevelComparisonWidget", u"Mode:", None))
        self.plotButton.setText(QCoreApplication.translate("LevelComparisonWidget", u"PLOT", None))
        self.dataButton.setText(QCoreApplication.translate("LevelComparisonWidget", u"DATA", None))
        self.strategyBox.setText(QCoreApplication.translate("LevelComparisonWidget", u"Ignore Strategy", None))
        self.label_2.setText(QCoreApplication.translate("LevelComparisonWidget", u"Variable:", None))
    # retranslateUi

