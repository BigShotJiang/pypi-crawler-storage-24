# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'pipelinedock.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QButtonGroup, QDockWidget, QFrame,
    QHBoxLayout, QHeaderView, QLabel, QLayout,
    QLineEdit, QPushButton, QRadioButton, QSizePolicy,
    QSpacerItem, QTreeView, QVBoxLayout, QWidget)
from . import resources_pipeline_rc

class Ui_PipeLineDock(object):
    def setupUi(self, PipeLineDock):
        if not PipeLineDock.objectName():
            PipeLineDock.setObjectName(u"PipeLineDock")
        PipeLineDock.resize(404, 853)
        PipeLineDock.setMinimumSize(QSize(404, 299))
        PipeLineDock.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable|QDockWidget.DockWidgetFeature.DockWidgetMovable)
        PipeLineDock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea)
        self.dockWidgetContents = QWidget()
        self.dockWidgetContents.setObjectName(u"dockWidgetContents")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.dockWidgetContents.sizePolicy().hasHeightForWidth())
        self.dockWidgetContents.setSizePolicy(sizePolicy)
        self.dockWidgetContents.setMinimumSize(QSize(400, 0))
        self.verticalLayout = QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(5, 5, 0, 2)
        self.scopeFrame = QFrame(self.dockWidgetContents)
        self.scopeFrame.setObjectName(u"scopeFrame")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.scopeFrame.sizePolicy().hasHeightForWidth())
        self.scopeFrame.setSizePolicy(sizePolicy1)
        self.scopeFrame.setMaximumSize(QSize(16777215, 16777215))
        self.scopeFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.horizontalLayout = QHBoxLayout(self.scopeFrame)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout.setContentsMargins(3, 2, 0, 2)
        self.scopeLabel = QLabel(self.scopeFrame)
        self.scopeLabel.setObjectName(u"scopeLabel")
        sizePolicy1.setHeightForWidth(self.scopeLabel.sizePolicy().hasHeightForWidth())
        self.scopeLabel.setSizePolicy(sizePolicy1)
        self.scopeLabel.setMinimumSize(QSize(150, 0))
        font = QFont()
        font.setBold(True)
        self.scopeLabel.setFont(font)

        self.horizontalLayout.addWidget(self.scopeLabel)

        self.localRadioButton = QRadioButton(self.scopeFrame)
        self.scopeButtonGroup = QButtonGroup(PipeLineDock)
        self.scopeButtonGroup.setObjectName(u"scopeButtonGroup")
        self.scopeButtonGroup.addButton(self.localRadioButton)
        self.localRadioButton.setObjectName(u"localRadioButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.localRadioButton.sizePolicy().hasHeightForWidth())
        self.localRadioButton.setSizePolicy(sizePolicy2)
        self.localRadioButton.setMinimumSize(QSize(110, 0))
        self.localRadioButton.setChecked(False)

        self.horizontalLayout.addWidget(self.localRadioButton)

        self.globalRadioButton = QRadioButton(self.scopeFrame)
        self.scopeButtonGroup.addButton(self.globalRadioButton)
        self.globalRadioButton.setObjectName(u"globalRadioButton")
        sizePolicy2.setHeightForWidth(self.globalRadioButton.sizePolicy().hasHeightForWidth())
        self.globalRadioButton.setSizePolicy(sizePolicy2)
        self.globalRadioButton.setChecked(True)

        self.horizontalLayout.addWidget(self.globalRadioButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)


        self.verticalLayout.addWidget(self.scopeFrame)

        self.filterFrame = QFrame(self.dockWidgetContents)
        self.filterFrame.setObjectName(u"filterFrame")
        self.filterFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.filterFrame.setFrameShadow(QFrame.Shadow.Plain)
        self.horizontalLayout_2 = QHBoxLayout(self.filterFrame)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(3, 2, 2, 3)
        self.filterLabel = QLabel(self.filterFrame)
        self.filterLabel.setObjectName(u"filterLabel")
        self.filterLabel.setFont(font)

        self.horizontalLayout_2.addWidget(self.filterLabel)

        self.filterLineEdit = QLineEdit(self.filterFrame)
        self.filterLineEdit.setObjectName(u"filterLineEdit")

        self.horizontalLayout_2.addWidget(self.filterLineEdit)

        self.clearButton = QPushButton(self.filterFrame)
        self.clearButton.setObjectName(u"clearButton")
        icon = QIcon()
        icon.addFile(u":/icons/icons/button_cancel-128.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.clearButton.setIcon(icon)

        self.horizontalLayout_2.addWidget(self.clearButton)


        self.verticalLayout.addWidget(self.filterFrame)

        self.treeView = QTreeView(self.dockWidgetContents)
        self.treeView.setObjectName(u"treeView")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.treeView.sizePolicy().hasHeightForWidth())
        self.treeView.setSizePolicy(sizePolicy3)
        self.treeView.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.treeView.header().setVisible(True)

        self.verticalLayout.addWidget(self.treeView)

        PipeLineDock.setWidget(self.dockWidgetContents)

        self.retranslateUi(PipeLineDock)

        QMetaObject.connectSlotsByName(PipeLineDock)
    # setupUi

    def retranslateUi(self, PipeLineDock):
        PipeLineDock.setWindowTitle(QCoreApplication.translate("PipeLineDock", u"Pipeline", None))
        self.scopeLabel.setText(QCoreApplication.translate("PipeLineDock", u"Assessment scope:", None))
        self.localRadioButton.setText(QCoreApplication.translate("PipeLineDock", u"Module", None))
        self.globalRadioButton.setText(QCoreApplication.translate("PipeLineDock", u"Global", None))
        self.filterLabel.setText(QCoreApplication.translate("PipeLineDock", u"Filter:", None))
#if QT_CONFIG(tooltip)
        self.clearButton.setToolTip(QCoreApplication.translate("PipeLineDock", u"Clear filter", None))
#endif // QT_CONFIG(tooltip)
        self.clearButton.setText("")
    # retranslateUi

