# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'pathselect.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialogButtonBox, QGridLayout,
    QLabel, QLineEdit, QSizePolicy, QSpacerItem,
    QToolButton, QVBoxLayout, QWidget)

class Ui_PathSelect(object):
    def setupUi(self, PathSelect):
        if not PathSelect.objectName():
            PathSelect.setObjectName(u"PathSelect")
        PathSelect.resize(750, 200)
        self.verticalLayout = QVBoxLayout(PathSelect)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.staticLabel = QLabel(PathSelect)
        self.staticLabel.setObjectName(u"staticLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.staticLabel.sizePolicy().hasHeightForWidth())
        self.staticLabel.setSizePolicy(sizePolicy)
        self.staticLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.staticLabel, 0, 0, 1, 1)

        self.valueLabel = QLabel(PathSelect)
        self.valueLabel.setObjectName(u"valueLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.valueLabel.sizePolicy().hasHeightForWidth())
        self.valueLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.valueLabel, 0, 1, 1, 2)

        self.questionLabel = QLabel(PathSelect)
        self.questionLabel.setObjectName(u"questionLabel")
        sizePolicy.setHeightForWidth(self.questionLabel.sizePolicy().hasHeightForWidth())
        self.questionLabel.setSizePolicy(sizePolicy)
        self.questionLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.questionLabel, 1, 0, 1, 1)

        self.lineEdit = QLineEdit(PathSelect)
        self.lineEdit.setObjectName(u"lineEdit")

        self.gridLayout.addWidget(self.lineEdit, 1, 1, 1, 1)

        self.toolButton = QToolButton(PathSelect)
        self.toolButton.setObjectName(u"toolButton")

        self.gridLayout.addWidget(self.toolButton, 1, 2, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(20, 86, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(PathSelect)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)
        self.buttonBox.setCenterButtons(False)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(PathSelect)

        QMetaObject.connectSlotsByName(PathSelect)
    # setupUi

    def retranslateUi(self, PathSelect):
        PathSelect.setWindowTitle(QCoreApplication.translate("PathSelect", u"Form", None))
        self.staticLabel.setText(QCoreApplication.translate("PathSelect", u"Current value:", None))
        self.valueLabel.setText(QCoreApplication.translate("PathSelect", u"None", None))
        self.questionLabel.setText(QCoreApplication.translate("PathSelect", u"Please enter a path:", None))
        self.toolButton.setText(QCoreApplication.translate("PathSelect", u"...", None))
    # retranslateUi

