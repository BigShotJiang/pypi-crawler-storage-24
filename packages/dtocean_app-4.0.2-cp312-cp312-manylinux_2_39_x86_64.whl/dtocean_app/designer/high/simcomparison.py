# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'simcomparison.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QButtonGroup, QCheckBox,
    QDialogButtonBox, QFrame, QHBoxLayout, QLabel,
    QLayout, QRadioButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_SimComparisonWidget(object):
    def setupUi(self, SimComparisonWidget):
        if not SimComparisonWidget.objectName():
            SimComparisonWidget.setObjectName(u"SimComparisonWidget")
        SimComparisonWidget.resize(439, 189)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(SimComparisonWidget.sizePolicy().hasHeightForWidth())
        SimComparisonWidget.setSizePolicy(sizePolicy)
        SimComparisonWidget.setMinimumSize(QSize(320, 0))
        self.verticalLayout = QVBoxLayout(SimComparisonWidget)
        self.verticalLayout.setSpacing(4)
        self.verticalLayout.setContentsMargins(4, 4, 4, 4)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.headingLabel = QLabel(SimComparisonWidget)
        self.headingLabel.setObjectName(u"headingLabel")
        font = QFont()
        font.setBold(True)
        self.headingLabel.setFont(font)
        self.headingLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.verticalLayout.addWidget(self.headingLabel)

        self.line = QFrame(SimComparisonWidget)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.topHorizontalLayout = QHBoxLayout()
        self.topHorizontalLayout.setObjectName(u"topHorizontalLayout")
        self.topHorizontalLayout.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.label_3 = QLabel(SimComparisonWidget)
        self.label_3.setObjectName(u"label_3")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy1)
        self.label_3.setMinimumSize(QSize(50, 0))

        self.topHorizontalLayout.addWidget(self.label_3)

        self.plotButton = QRadioButton(SimComparisonWidget)
        self.modeButtonGroup = QButtonGroup(SimComparisonWidget)
        self.modeButtonGroup.setObjectName(u"modeButtonGroup")
        self.modeButtonGroup.addButton(self.plotButton)
        self.plotButton.setObjectName(u"plotButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.plotButton.sizePolicy().hasHeightForWidth())
        self.plotButton.setSizePolicy(sizePolicy2)
        self.plotButton.setMinimumSize(QSize(75, 0))
        self.plotButton.setChecked(True)

        self.topHorizontalLayout.addWidget(self.plotButton)

        self.dataButton = QRadioButton(SimComparisonWidget)
        self.modeButtonGroup.addButton(self.dataButton)
        self.dataButton.setObjectName(u"dataButton")
        self.dataButton.setEnabled(True)
        sizePolicy2.setHeightForWidth(self.dataButton.sizePolicy().hasHeightForWidth())
        self.dataButton.setSizePolicy(sizePolicy2)
        self.dataButton.setMinimumSize(QSize(75, 0))

        self.topHorizontalLayout.addWidget(self.dataButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.topHorizontalLayout.addItem(self.horizontalSpacer)

        self.strategyBox = QCheckBox(SimComparisonWidget)
        self.strategyBox.setObjectName(u"strategyBox")
        self.strategyBox.setEnabled(False)
        sizePolicy2.setHeightForWidth(self.strategyBox.sizePolicy().hasHeightForWidth())
        self.strategyBox.setSizePolicy(sizePolicy2)
        self.strategyBox.setMinimumSize(QSize(150, 0))
        self.strategyBox.setMaximumSize(QSize(150, 16777215))
        self.strategyBox.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.strategyBox.setChecked(True)

        self.topHorizontalLayout.addWidget(self.strategyBox)


        self.verticalLayout.addLayout(self.topHorizontalLayout)

        self.verticalSpacer_2 = QSpacerItem(20, 2, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.bottomHorizontalLayout = QHBoxLayout()
        self.bottomHorizontalLayout.setObjectName(u"bottomHorizontalLayout")
        self.bottomHorizontalLayout.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.label_2 = QLabel(SimComparisonWidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(65, 0))

        self.bottomHorizontalLayout.addWidget(self.label_2)


        self.verticalLayout.addLayout(self.bottomHorizontalLayout)

        self.middleHorizontalLayout = QHBoxLayout()
        self.middleHorizontalLayout.setObjectName(u"middleHorizontalLayout")
        self.label_4 = QLabel(SimComparisonWidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setMinimumSize(QSize(65, 0))

        self.middleHorizontalLayout.addWidget(self.label_4)


        self.verticalLayout.addLayout(self.middleHorizontalLayout)

        self.verticalSpacer = QSpacerItem(20, 80, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(SimComparisonWidget)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Save)

        self.verticalLayout.addWidget(self.buttonBox)

        self.buttonBox.raise_()
        self.line.raise_()
        self.headingLabel.raise_()

        self.retranslateUi(SimComparisonWidget)

        QMetaObject.connectSlotsByName(SimComparisonWidget)
    # setupUi

    def retranslateUi(self, SimComparisonWidget):
        SimComparisonWidget.setWindowTitle(QCoreApplication.translate("SimComparisonWidget", u"Form", None))
        self.headingLabel.setText(QCoreApplication.translate("SimComparisonWidget", u"Simulation Comparison:", None))
        self.label_3.setText(QCoreApplication.translate("SimComparisonWidget", u"Mode:", None))
        self.plotButton.setText(QCoreApplication.translate("SimComparisonWidget", u"PLOT", None))
        self.dataButton.setText(QCoreApplication.translate("SimComparisonWidget", u"DATA", None))
        self.strategyBox.setText(QCoreApplication.translate("SimComparisonWidget", u"Ignore Strategy", None))
        self.label_2.setText(QCoreApplication.translate("SimComparisonWidget", u"Variable:", None))
        self.label_4.setText(QCoreApplication.translate("SimComparisonWidget", u"Module:", None))
    # retranslateUi

