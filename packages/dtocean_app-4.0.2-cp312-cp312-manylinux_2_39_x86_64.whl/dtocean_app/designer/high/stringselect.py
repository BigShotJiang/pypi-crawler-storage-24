# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'stringselect.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialogButtonBox, QGridLayout,
    QLabel, QLineEdit, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_StringSelect(object):
    def setupUi(self, StringSelect):
        if not StringSelect.objectName():
            StringSelect.setObjectName(u"StringSelect")
        StringSelect.resize(750, 200)
        self.verticalLayout = QVBoxLayout(StringSelect)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.staticLabel = QLabel(StringSelect)
        self.staticLabel.setObjectName(u"staticLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.staticLabel.sizePolicy().hasHeightForWidth())
        self.staticLabel.setSizePolicy(sizePolicy)
        self.staticLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.staticLabel, 0, 0, 1, 1)

        self.valueLabel = QLabel(StringSelect)
        self.valueLabel.setObjectName(u"valueLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.valueLabel.sizePolicy().hasHeightForWidth())
        self.valueLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.valueLabel, 0, 1, 1, 2)

        self.questionLabel = QLabel(StringSelect)
        self.questionLabel.setObjectName(u"questionLabel")
        sizePolicy.setHeightForWidth(self.questionLabel.sizePolicy().hasHeightForWidth())
        self.questionLabel.setSizePolicy(sizePolicy)
        self.questionLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.questionLabel, 1, 0, 1, 1)

        self.lineEdit = QLineEdit(StringSelect)
        self.lineEdit.setObjectName(u"lineEdit")

        self.gridLayout.addWidget(self.lineEdit, 1, 1, 1, 1)

        self.unitsLabel = QLabel(StringSelect)
        self.unitsLabel.setObjectName(u"unitsLabel")
        sizePolicy.setHeightForWidth(self.unitsLabel.sizePolicy().hasHeightForWidth())
        self.unitsLabel.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.unitsLabel, 1, 2, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(20, 86, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(StringSelect)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)
        self.buttonBox.setCenterButtons(False)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(StringSelect)

        QMetaObject.connectSlotsByName(StringSelect)
    # setupUi

    def retranslateUi(self, StringSelect):
        StringSelect.setWindowTitle(QCoreApplication.translate("StringSelect", u"Form", None))
        self.staticLabel.setText(QCoreApplication.translate("StringSelect", u"Current value:", None))
        self.valueLabel.setText(QCoreApplication.translate("StringSelect", u"None", None))
        self.questionLabel.setText(QCoreApplication.translate("StringSelect", u"Please enter a string:", None))
        self.unitsLabel.setText(QCoreApplication.translate("StringSelect", u"(unit)", None))
    # retranslateUi

