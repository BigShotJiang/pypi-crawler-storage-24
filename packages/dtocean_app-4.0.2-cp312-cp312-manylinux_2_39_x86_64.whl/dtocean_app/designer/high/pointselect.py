# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'pointselect.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QDialogButtonBox,
    QDoubleSpinBox, QGridLayout, QLabel, QLayout,
    QSizePolicy, QSpacerItem, QVBoxLayout, QWidget)

class Ui_PointSelect(object):
    def setupUi(self, PointSelect):
        if not PointSelect.objectName():
            PointSelect.setObjectName(u"PointSelect")
        PointSelect.resize(973, 329)
        self.verticalLayout = QVBoxLayout(PointSelect)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.staticLabel = QLabel(PointSelect)
        self.staticLabel.setObjectName(u"staticLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.staticLabel.sizePolicy().hasHeightForWidth())
        self.staticLabel.setSizePolicy(sizePolicy)
        self.staticLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.staticLabel, 0, 0, 1, 1)

        self.valueLabel = QLabel(PointSelect)
        self.valueLabel.setObjectName(u"valueLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.valueLabel.sizePolicy().hasHeightForWidth())
        self.valueLabel.setSizePolicy(sizePolicy1)
        self.valueLabel.setTextInteractionFlags(Qt.TextInteractionFlag.LinksAccessibleByMouse|Qt.TextInteractionFlag.TextSelectableByMouse)

        self.gridLayout.addWidget(self.valueLabel, 0, 1, 1, 2)

        self.questionLabel = QLabel(PointSelect)
        self.questionLabel.setObjectName(u"questionLabel")
        sizePolicy.setHeightForWidth(self.questionLabel.sizePolicy().hasHeightForWidth())
        self.questionLabel.setSizePolicy(sizePolicy)
        self.questionLabel.setMinimumSize(QSize(225, 0))

        self.gridLayout.addWidget(self.questionLabel, 1, 0, 1, 1)

        self.label_1 = QLabel(PointSelect)
        self.label_1.setObjectName(u"label_1")
        sizePolicy.setHeightForWidth(self.label_1.sizePolicy().hasHeightForWidth())
        self.label_1.setSizePolicy(sizePolicy)
        self.label_1.setMinimumSize(QSize(25, 0))
        self.label_1.setMaximumSize(QSize(25, 16777215))

        self.gridLayout.addWidget(self.label_1, 1, 1, 1, 1)

        self.doubleSpinBox_1 = QDoubleSpinBox(PointSelect)
        self.doubleSpinBox_1.setObjectName(u"doubleSpinBox_1")
        sizePolicy1.setHeightForWidth(self.doubleSpinBox_1.sizePolicy().hasHeightForWidth())
        self.doubleSpinBox_1.setSizePolicy(sizePolicy1)
        self.doubleSpinBox_1.setMinimumSize(QSize(0, 0))
        self.doubleSpinBox_1.setKeyboardTracking(False)
        self.doubleSpinBox_1.setMinimum(-1000000000.000000000000000)
        self.doubleSpinBox_1.setMaximum(1000000000.000000000000000)

        self.gridLayout.addWidget(self.doubleSpinBox_1, 1, 2, 1, 1)

        self.label_2 = QLabel(PointSelect)
        self.label_2.setObjectName(u"label_2")
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)
        self.label_2.setMinimumSize(QSize(25, 0))
        self.label_2.setMaximumSize(QSize(25, 16777215))

        self.gridLayout.addWidget(self.label_2, 1, 3, 1, 1)

        self.doubleSpinBox_2 = QDoubleSpinBox(PointSelect)
        self.doubleSpinBox_2.setObjectName(u"doubleSpinBox_2")
        sizePolicy1.setHeightForWidth(self.doubleSpinBox_2.sizePolicy().hasHeightForWidth())
        self.doubleSpinBox_2.setSizePolicy(sizePolicy1)
        self.doubleSpinBox_2.setMinimumSize(QSize(0, 0))
        self.doubleSpinBox_2.setKeyboardTracking(False)
        self.doubleSpinBox_2.setMinimum(-1000000000.000000000000000)
        self.doubleSpinBox_2.setMaximum(1000000000.000000000000000)

        self.gridLayout.addWidget(self.doubleSpinBox_2, 1, 4, 1, 1)

        self.label_3 = QLabel(PointSelect)
        self.label_3.setObjectName(u"label_3")
        sizePolicy.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy)
        self.label_3.setMinimumSize(QSize(25, 0))
        self.label_3.setMaximumSize(QSize(25, 16777215))

        self.gridLayout.addWidget(self.label_3, 1, 5, 1, 1)

        self.doubleSpinBox_3 = QDoubleSpinBox(PointSelect)
        self.doubleSpinBox_3.setObjectName(u"doubleSpinBox_3")
        sizePolicy1.setHeightForWidth(self.doubleSpinBox_3.sizePolicy().hasHeightForWidth())
        self.doubleSpinBox_3.setSizePolicy(sizePolicy1)
        self.doubleSpinBox_3.setMinimumSize(QSize(0, 0))
        self.doubleSpinBox_3.setKeyboardTracking(False)
        self.doubleSpinBox_3.setMinimum(-1000000000.000000000000000)
        self.doubleSpinBox_3.setValue(0.000000000000000)

        self.gridLayout.addWidget(self.doubleSpinBox_3, 1, 6, 1, 1)

        self.unitsLabel = QLabel(PointSelect)
        self.unitsLabel.setObjectName(u"unitsLabel")
        sizePolicy.setHeightForWidth(self.unitsLabel.sizePolicy().hasHeightForWidth())
        self.unitsLabel.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.unitsLabel, 1, 7, 1, 1)

        self.checkBox = QCheckBox(PointSelect)
        self.checkBox.setObjectName(u"checkBox")
        sizePolicy1.setHeightForWidth(self.checkBox.sizePolicy().hasHeightForWidth())
        self.checkBox.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.checkBox, 2, 0, 1, 8)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(725, 188, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(PointSelect)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)
        self.buttonBox.setCenterButtons(False)

        self.verticalLayout.addWidget(self.buttonBox)

        QWidget.setTabOrder(self.doubleSpinBox_1, self.doubleSpinBox_2)
        QWidget.setTabOrder(self.doubleSpinBox_2, self.doubleSpinBox_3)
        QWidget.setTabOrder(self.doubleSpinBox_3, self.buttonBox)

        self.retranslateUi(PointSelect)

        QMetaObject.connectSlotsByName(PointSelect)
    # setupUi

    def retranslateUi(self, PointSelect):
        PointSelect.setWindowTitle(QCoreApplication.translate("PointSelect", u"Form", None))
        self.staticLabel.setText(QCoreApplication.translate("PointSelect", u"Current value:", None))
        self.valueLabel.setText(QCoreApplication.translate("PointSelect", u"None", None))
        self.questionLabel.setText(QCoreApplication.translate("PointSelect", u"Please enter the coordinates:", None))
        self.label_1.setText(QCoreApplication.translate("PointSelect", u"   x", None))
        self.label_2.setText(QCoreApplication.translate("PointSelect", u"   y", None))
        self.label_3.setText(QCoreApplication.translate("PointSelect", u"   z", None))
        self.unitsLabel.setText(QCoreApplication.translate("PointSelect", u"(unit)", None))
        self.checkBox.setText(QCoreApplication.translate("PointSelect", u"Enable z-coordinate", None))
    # retranslateUi

