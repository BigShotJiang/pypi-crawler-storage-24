# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'about.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QFrame, QLabel,
    QLayout, QScrollArea, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)
from . import resources_about_rc

class Ui_AboutDialog(object):
    def setupUi(self, AboutDialog):
        if not AboutDialog.objectName():
            AboutDialog.setObjectName(u"AboutDialog")
        AboutDialog.resize(450, 671)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(AboutDialog.sizePolicy().hasHeightForWidth())
        AboutDialog.setSizePolicy(sizePolicy)
        AboutDialog.setMinimumSize(QSize(450, 0))
        AboutDialog.setMaximumSize(QSize(450, 16777215))
        AboutDialog.setAutoFillBackground(False)
        AboutDialog.setStyleSheet(u"")
        self.verticalLayout_2 = QVBoxLayout(AboutDialog)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.scrollArea = QScrollArea(AboutDialog)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 448, 669))
        self.scrollAreaWidgetContents.setStyleSheet(u"background: white;")
        self.verticalLayout_3 = QVBoxLayout(self.scrollAreaWidgetContents)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalSpacer_4 = QSpacerItem(20, 10, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer_4)

        self.logoLabel = QLabel(self.scrollAreaWidgetContents)
        self.logoLabel.setObjectName(u"logoLabel")
        self.logoLabel.setMaximumSize(QSize(16777214, 16777215))
        self.logoLabel.setPixmap(QPixmap(u":/logos/dtocean_padded_20251712.png"))
        self.logoLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.logoLabel)

        self.verticalSpacer_2 = QSpacerItem(20, 5, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer_2)

        self.versionLabel = QLabel(self.scrollAreaWidgetContents)
        self.versionLabel.setObjectName(u"versionLabel")
        font = QFont()
        font.setBold(True)
        self.versionLabel.setFont(font)
        self.versionLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.versionLabel)

        self.longLabel = QLabel(self.scrollAreaWidgetContents)
        self.longLabel.setObjectName(u"longLabel")
        self.longLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.longLabel)

        self.verticalSpacer_3 = QSpacerItem(20, 5, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer_3)

        self.line_1 = QFrame(self.scrollAreaWidgetContents)
        self.line_1.setObjectName(u"line_1")
        self.line_1.setFrameShape(QFrame.Shape.HLine)
        self.line_1.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_3.addWidget(self.line_1)

        self.DOGIntroLabel = QLabel(self.scrollAreaWidgetContents)
        self.DOGIntroLabel.setObjectName(u"DOGIntroLabel")
        self.DOGIntroLabel.setStyleSheet(u"QMenu::item{\n"
"  background-color: rgb(255, 255, 255);\n"
"  color:  rgb(0, 0, 0);\n"
" }\n"
"QMenu::item:selected{\n"
"  background-color: rgb(252, 124, 1);\n"
"  color:  rgb(0, 0, 0);\n"
"}")
        self.DOGIntroLabel.setTextFormat(Qt.TextFormat.AutoText)
        self.DOGIntroLabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.DOGIntroLabel.setOpenExternalLinks(True)

        self.verticalLayout_3.addWidget(self.DOGIntroLabel)

        self.verticalSpacer_7 = QSpacerItem(20, 2, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer_7)

        self.DOGlogoLabel = QLabel(self.scrollAreaWidgetContents)
        self.DOGlogoLabel.setObjectName(u"DOGlogoLabel")
        self.DOGlogoLabel.setPixmap(QPixmap(u":/logos/dog_logo_wide_300.png"))
        self.DOGlogoLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.DOGlogoLabel)

        self.supportLabel = QLabel(self.scrollAreaWidgetContents)
        self.supportLabel.setObjectName(u"supportLabel")
        self.supportLabel.setStyleSheet(u"QMenu::item{\n"
"  background-color: rgb(255, 255, 255);\n"
"  color:  rgb(0, 0, 0);\n"
" }\n"
"QMenu::item:selected{\n"
"  background-color: rgb(252, 124, 1);\n"
"  color:  rgb(0, 0, 0);\n"
"}")
        self.supportLabel.setWordWrap(True)
        self.supportLabel.setOpenExternalLinks(True)

        self.verticalLayout_3.addWidget(self.supportLabel)

        self.verticalSpacer_9 = QSpacerItem(20, 2, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer_9)

        self.line_3 = QFrame(self.scrollAreaWidgetContents)
        self.line_3.setObjectName(u"line_3")
        self.line_3.setFrameShape(QFrame.Shape.HLine)
        self.line_3.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_3.addWidget(self.line_3)

        self.freeSoftwareLabel = QLabel(self.scrollAreaWidgetContents)
        self.freeSoftwareLabel.setObjectName(u"freeSoftwareLabel")
        font1 = QFont()
        font1.setBold(False)
        font1.setItalic(False)
        font1.setUnderline(False)
        self.freeSoftwareLabel.setFont(font1)
        self.freeSoftwareLabel.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)

        self.verticalLayout_3.addWidget(self.freeSoftwareLabel)

        self.copyrightLabel = QLabel(self.scrollAreaWidgetContents)
        self.copyrightLabel.setObjectName(u"copyrightLabel")
        self.copyrightLabel.setTextFormat(Qt.TextFormat.RichText)
        self.copyrightLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.copyrightLabel)

        self.GPLLabel = QLabel(self.scrollAreaWidgetContents)
        self.GPLLabel.setObjectName(u"GPLLabel")
        self.GPLLabel.setStyleSheet(u"QMenu::item{\n"
"  background-color: rgb(255, 255, 255);\n"
"  color:  rgb(0, 0, 0);\n"
" }\n"
"QMenu::item:selected{\n"
"  background-color: rgb(252, 124, 1);\n"
"  color:  rgb(0, 0, 0);\n"
"}")
        self.GPLLabel.setTextFormat(Qt.TextFormat.RichText)
        self.GPLLabel.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.GPLLabel.setOpenExternalLinks(True)

        self.verticalLayout_3.addWidget(self.GPLLabel)

        self.iconsLabel = QLabel(self.scrollAreaWidgetContents)
        self.iconsLabel.setObjectName(u"iconsLabel")
        font2 = QFont()
        font2.setPointSize(7)
        self.iconsLabel.setFont(font2)
        self.iconsLabel.setMidLineWidth(-4)
        self.iconsLabel.setTextFormat(Qt.TextFormat.RichText)
        self.iconsLabel.setWordWrap(True)

        self.verticalLayout_3.addWidget(self.iconsLabel)

        self.line_4 = QFrame(self.scrollAreaWidgetContents)
        self.line_4.setObjectName(u"line_4")
        self.line_4.setFrameShape(QFrame.Shape.HLine)
        self.line_4.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_3.addWidget(self.line_4)

        self.softwareLabel = QLabel(self.scrollAreaWidgetContents)
        self.softwareLabel.setObjectName(u"softwareLabel")
        self.softwareLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.softwareLabel)

        self.packagesLabel = QLabel(self.scrollAreaWidgetContents)
        self.packagesLabel.setObjectName(u"packagesLabel")
        self.packagesLabel.setAlignment(Qt.AlignmentFlag.AlignJustify|Qt.AlignmentFlag.AlignVCenter)
        self.packagesLabel.setWordWrap(True)

        self.verticalLayout_3.addWidget(self.packagesLabel)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.logoLabel.raise_()
        self.versionLabel.raise_()
        self.DOGIntroLabel.raise_()
        self.line_3.raise_()
        self.freeSoftwareLabel.raise_()
        self.GPLLabel.raise_()
        self.line_1.raise_()
        self.copyrightLabel.raise_()
        self.line_4.raise_()
        self.softwareLabel.raise_()
        self.packagesLabel.raise_()
        self.iconsLabel.raise_()
        self.DOGlogoLabel.raise_()
        self.supportLabel.raise_()
        self.longLabel.raise_()

        self.verticalLayout_2.addWidget(self.scrollArea)


        self.retranslateUi(AboutDialog)

        QMetaObject.connectSlotsByName(AboutDialog)
    # setupUi

    def retranslateUi(self, AboutDialog):
        AboutDialog.setWindowTitle(QCoreApplication.translate("AboutDialog", u"About", None))
        self.logoLabel.setText("")
        self.versionLabel.setText(QCoreApplication.translate("AboutDialog", u"DTOcean Version", None))
        self.longLabel.setText(QCoreApplication.translate("AboutDialog", u"Optimal Design Tools for Ocean Energy Arrays", None))
        self.DOGIntroLabel.setText(QCoreApplication.translate("AboutDialog", u"DTOcean is maintained by Mathew Topper @ <a href='http://www.dataonlygreater.com/'>Data Only Greater</a>:", None))
        self.DOGlogoLabel.setText("")
        self.supportLabel.setText(QCoreApplication.translate("AboutDialog", u"For free community support please go to <a href='https://github.com/dtocean/dtocean'>github.com/DTOcean</a>. For training and consultation services see <a href='http://www.dataonlygreater.com/'>dataonlygreater.com</a>.", None))
        self.freeSoftwareLabel.setText(QCoreApplication.translate("AboutDialog", u"DTOcean is free software", None))
        self.copyrightLabel.setText(QCoreApplication.translate("AboutDialog", u"Copyright Statement", None))
        self.GPLLabel.setText(QCoreApplication.translate("AboutDialog", u"<html><head/><body><p><a href=\"https://www.gnu.org/licenses/gpl.html\"><span style=\" text-decoration: underline; color:#0000ff;\">GNU General Public License</span></a></p></body></html>", None))
        self.iconsLabel.setText(QCoreApplication.translate("AboutDialog", u"The icons used in DTOcean are adapted from the Crystal Clear icon set (&copy; Everaldo Coelho), the GNOME Desktop Tango icon set (&copy; GNOME icon artists) and the ScreenRuler Tango icon (&copy; Jaanos) ", None))
        self.softwareLabel.setText(QCoreApplication.translate("AboutDialog", u"Packages Versions", None))
        self.packagesLabel.setText(QCoreApplication.translate("AboutDialog", u"Please see the individual DTOcean packages for further details regarding module dependencies and licensing", None))
    # retranslateUi

