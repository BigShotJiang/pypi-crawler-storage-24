# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'shuttle.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QDialog,
    QDialogButtonBox, QFrame, QGridLayout, QLabel,
    QLayout, QListView, QPushButton, QSizePolicy,
    QVBoxLayout, QWidget)

class Ui_ShuttleDialog(object):
    def setupUi(self, ShuttleDialog):
        if not ShuttleDialog.objectName():
            ShuttleDialog.setObjectName(u"ShuttleDialog")
        ShuttleDialog.resize(648, 348)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(ShuttleDialog.sizePolicy().hasHeightForWidth())
        ShuttleDialog.setSizePolicy(sizePolicy)
        ShuttleDialog.setMinimumSize(QSize(560, 252))
        ShuttleDialog.setMaximumSize(QSize(100000, 100000))
        self.verticalLayout_2 = QVBoxLayout(ShuttleDialog)
        self.verticalLayout_2.setSpacing(9)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setSizeConstraint(QLayout.SizeConstraint.SetFixedSize)
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setHorizontalSpacing(14)
        self.gridLayout.setVerticalSpacing(6)
        self.leftLabel = QLabel(ShuttleDialog)
        self.leftLabel.setObjectName(u"leftLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.leftLabel.sizePolicy().hasHeightForWidth())
        self.leftLabel.setSizePolicy(sizePolicy1)
        font = QFont()
        font.setFamilies([u"Segoe UI Semibold"])
        font.setPointSize(10)
        font.setItalic(False)
        font.setKerning(True)
        self.leftLabel.setFont(font)
        self.leftLabel.setStyleSheet(u"font: 75 10pt \"Segoe UI Semibold\";")
        self.leftLabel.setTextFormat(Qt.TextFormat.AutoText)
        self.leftLabel.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)

        self.gridLayout.addWidget(self.leftLabel, 0, 0, 1, 1)

        self.blankLabel = QLabel(ShuttleDialog)
        self.blankLabel.setObjectName(u"blankLabel")
        sizePolicy1.setHeightForWidth(self.blankLabel.sizePolicy().hasHeightForWidth())
        self.blankLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.blankLabel, 0, 1, 1, 1)

        self.rightLabel = QLabel(ShuttleDialog)
        self.rightLabel.setObjectName(u"rightLabel")
        sizePolicy1.setHeightForWidth(self.rightLabel.sizePolicy().hasHeightForWidth())
        self.rightLabel.setSizePolicy(sizePolicy1)
        self.rightLabel.setStyleSheet(u"font: 75 10pt \"Segoe UI Semibold\";")
        self.rightLabel.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)

        self.gridLayout.addWidget(self.rightLabel, 0, 2, 1, 1)

        self.leftListView = QListView(ShuttleDialog)
        self.leftListView.setObjectName(u"leftListView")
        font1 = QFont()
        font1.setPointSize(8)
        self.leftListView.setFont(font1)
        self.leftListView.setFrameShape(QFrame.Shape.Box)
        self.leftListView.setFrameShadow(QFrame.Shadow.Plain)
        self.leftListView.setLineWidth(1)
        self.leftListView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)

        self.gridLayout.addWidget(self.leftListView, 2, 0, 1, 1)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.addButton = QPushButton(ShuttleDialog)
        self.addButton.setObjectName(u"addButton")

        self.verticalLayout.addWidget(self.addButton)

        self.removeButton = QPushButton(ShuttleDialog)
        self.removeButton.setObjectName(u"removeButton")

        self.verticalLayout.addWidget(self.removeButton)


        self.gridLayout.addLayout(self.verticalLayout, 2, 1, 1, 1)

        self.rightListView = QListView(ShuttleDialog)
        self.rightListView.setObjectName(u"rightListView")
        self.rightListView.setFont(font1)
        self.rightListView.setFrameShape(QFrame.Shape.Box)
        self.rightListView.setFrameShadow(QFrame.Shadow.Plain)
        self.rightListView.setLineWidth(1)
        self.rightListView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)

        self.gridLayout.addWidget(self.rightListView, 2, 2, 1, 1)

        self.line = QFrame(ShuttleDialog)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.gridLayout.addWidget(self.line, 1, 0, 1, 1)

        self.line_2 = QFrame(ShuttleDialog)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setFrameShape(QFrame.Shape.HLine)
        self.line_2.setFrameShadow(QFrame.Shadow.Sunken)

        self.gridLayout.addWidget(self.line_2, 1, 2, 1, 1)


        self.verticalLayout_2.addLayout(self.gridLayout)

        self.buttonBox = QDialogButtonBox(ShuttleDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.verticalLayout_2.addWidget(self.buttonBox)


        self.retranslateUi(ShuttleDialog)
        self.buttonBox.accepted.connect(ShuttleDialog.accept)
        self.buttonBox.rejected.connect(ShuttleDialog.reject)

        QMetaObject.connectSlotsByName(ShuttleDialog)
    # setupUi

    def retranslateUi(self, ShuttleDialog):
        ShuttleDialog.setWindowTitle(QCoreApplication.translate("ShuttleDialog", u"Dialog", None))
        self.leftLabel.setText("")
        self.blankLabel.setText("")
        self.rightLabel.setText("")
        self.addButton.setText(QCoreApplication.translate("ShuttleDialog", u"Add", None))
        self.removeButton.setText(QCoreApplication.translate("ShuttleDialog", u"Remove", None))
    # retranslateUi

