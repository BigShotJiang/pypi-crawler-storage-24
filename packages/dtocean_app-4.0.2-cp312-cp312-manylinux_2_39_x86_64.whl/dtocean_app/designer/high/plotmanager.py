# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'plotmanager.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QComboBox,
    QDialogButtonBox, QDoubleSpinBox, QFrame, QHBoxLayout,
    QLabel, QLineEdit, QSizePolicy, QSpacerItem,
    QToolButton, QVBoxLayout, QWidget)

class Ui_PlotManagerWidget(object):
    def setupUi(self, PlotManagerWidget):
        if not PlotManagerWidget.objectName():
            PlotManagerWidget.setObjectName(u"PlotManagerWidget")
        PlotManagerWidget.resize(679, 216)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(PlotManagerWidget.sizePolicy().hasHeightForWidth())
        PlotManagerWidget.setSizePolicy(sizePolicy)
        PlotManagerWidget.setMinimumSize(QSize(350, 0))
        self.verticalLayout = QVBoxLayout(PlotManagerWidget)
        self.verticalLayout.setSpacing(4)
        self.verticalLayout.setContentsMargins(4, 4, 4, 4)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.headingLabel = QLabel(PlotManagerWidget)
        self.headingLabel.setObjectName(u"headingLabel")
        self.headingLabel.setTextFormat(Qt.TextFormat.RichText)

        self.verticalLayout.addWidget(self.headingLabel)

        self.line = QFrame(PlotManagerWidget)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(PlotManagerWidget)
        self.label.setObjectName(u"label")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy1)
        self.label.setMinimumSize(QSize(65, 0))

        self.horizontalLayout.addWidget(self.label)

        self.plotBox = QComboBox(PlotManagerWidget)
        self.plotBox.setObjectName(u"plotBox")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.plotBox.sizePolicy().hasHeightForWidth())
        self.plotBox.setSizePolicy(sizePolicy2)
        self.plotBox.setMinimumSize(QSize(75, 0))

        self.horizontalLayout.addWidget(self.plotBox)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_2 = QLabel(PlotManagerWidget)
        self.label_2.setObjectName(u"label_2")
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)
        self.label_2.setMinimumSize(QSize(65, 0))

        self.horizontalLayout_2.addWidget(self.label_2)

        self.pathEdit = QLineEdit(PlotManagerWidget)
        self.pathEdit.setObjectName(u"pathEdit")

        self.horizontalLayout_2.addWidget(self.pathEdit)

        self.getPathButton = QToolButton(PlotManagerWidget)
        self.getPathButton.setObjectName(u"getPathButton")

        self.horizontalLayout_2.addWidget(self.getPathButton)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_5 = QLabel(PlotManagerWidget)
        self.label_5.setObjectName(u"label_5")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy3)
        self.label_5.setMinimumSize(QSize(0, 0))

        self.horizontalLayout_3.addWidget(self.label_5)

        self.checkBox = QCheckBox(PlotManagerWidget)
        self.checkBox.setObjectName(u"checkBox")
        self.checkBox.setLayoutDirection(Qt.LayoutDirection.RightToLeft)

        self.horizontalLayout_3.addWidget(self.checkBox)

        self.label_3 = QLabel(PlotManagerWidget)
        self.label_3.setObjectName(u"label_3")

        self.horizontalLayout_3.addWidget(self.label_3)

        self.widthSpinBox = QDoubleSpinBox(PlotManagerWidget)
        self.widthSpinBox.setObjectName(u"widthSpinBox")
        self.widthSpinBox.setEnabled(False)

        self.horizontalLayout_3.addWidget(self.widthSpinBox)

        self.label_4 = QLabel(PlotManagerWidget)
        self.label_4.setObjectName(u"label_4")

        self.horizontalLayout_3.addWidget(self.label_4)

        self.heightSpinBox = QDoubleSpinBox(PlotManagerWidget)
        self.heightSpinBox.setObjectName(u"heightSpinBox")
        self.heightSpinBox.setEnabled(False)

        self.horizontalLayout_3.addWidget(self.heightSpinBox)

        self.label_6 = QLabel(PlotManagerWidget)
        self.label_6.setObjectName(u"label_6")

        self.horizontalLayout_3.addWidget(self.label_6)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.verticalSpacer = QSpacerItem(20, 80, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(PlotManagerWidget)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.NoButton)

        self.verticalLayout.addWidget(self.buttonBox)

        self.buttonBox.raise_()
        self.line.raise_()
        self.headingLabel.raise_()

        self.retranslateUi(PlotManagerWidget)

        QMetaObject.connectSlotsByName(PlotManagerWidget)
    # setupUi

    def retranslateUi(self, PlotManagerWidget):
        PlotManagerWidget.setWindowTitle(QCoreApplication.translate("PlotManagerWidget", u"Form", None))
        self.headingLabel.setText(QCoreApplication.translate("PlotManagerWidget", u"<html><head/><body><p><span style=\" font-weight:600;\">Plot Manager:</span></p></body></html>", None))
        self.label.setText(QCoreApplication.translate("PlotManagerWidget", u"Plot name: ", None))
        self.label_2.setText(QCoreApplication.translate("PlotManagerWidget", u"File path: ", None))
        self.getPathButton.setText(QCoreApplication.translate("PlotManagerWidget", u"...", None))
        self.label_5.setText("")
        self.checkBox.setText(QCoreApplication.translate("PlotManagerWidget", u"Custom size", None))
        self.label_3.setText(QCoreApplication.translate("PlotManagerWidget", u"Width", None))
        self.label_4.setText(QCoreApplication.translate("PlotManagerWidget", u"Height", None))
        self.label_6.setText(QCoreApplication.translate("PlotManagerWidget", u"(inches)", None))
    # retranslateUi

