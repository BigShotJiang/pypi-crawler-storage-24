# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'multisensitivity.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QDoubleSpinBox, QFrame,
    QGridLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QPushButton, QSizePolicy, QSpacerItem,
    QTableView, QVBoxLayout, QWidget)

class Ui_MultiSensitivityWidget(object):
    def setupUi(self, MultiSensitivityWidget):
        if not MultiSensitivityWidget.objectName():
            MultiSensitivityWidget.setObjectName(u"MultiSensitivityWidget")
        MultiSensitivityWidget.resize(600, 450)
        self.horizontalLayout_2 = QHBoxLayout(MultiSensitivityWidget)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.frame = QFrame(MultiSensitivityWidget)
        self.frame.setObjectName(u"frame")
        self.frame.setMaximumSize(QSize(600, 16777215))
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout = QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.instructionsLabel = QLabel(self.frame)
        self.instructionsLabel.setObjectName(u"instructionsLabel")
        self.instructionsLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.instructionsLabel)

        self.verticalSpacer_2 = QSpacerItem(20, 10, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.modLabel = QLabel(self.frame)
        self.modLabel.setObjectName(u"modLabel")

        self.gridLayout.addWidget(self.modLabel, 0, 0, 1, 1)

        self.varLabel = QLabel(self.frame)
        self.varLabel.setObjectName(u"varLabel")

        self.gridLayout.addWidget(self.varLabel, 1, 0, 1, 1)

        self.lineLabel = QLabel(self.frame)
        self.lineLabel.setObjectName(u"lineLabel")

        self.gridLayout.addWidget(self.lineLabel, 2, 0, 1, 1)

        self.lineEdit = QLineEdit(self.frame)
        self.lineEdit.setObjectName(u"lineEdit")

        self.gridLayout.addWidget(self.lineEdit, 2, 1, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.line = QFrame(self.frame)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.tableLabel = QLabel(self.frame)
        self.tableLabel.setObjectName(u"tableLabel")
        font = QFont()
        font.setBold(True)
        self.tableLabel.setFont(font)

        self.verticalLayout.addWidget(self.tableLabel)

        self.tableView = QTableView(self.frame)
        self.tableView.setObjectName(u"tableView")
        self.tableView.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tableView.horizontalHeader().setDefaultSectionSize(150)
        self.tableView.horizontalHeader().setStretchLastSection(True)

        self.verticalLayout.addWidget(self.tableView)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.addButton = QPushButton(self.frame)
        self.addButton.setObjectName(u"addButton")

        self.horizontalLayout.addWidget(self.addButton)

        self.removeButton = QPushButton(self.frame)
        self.removeButton.setObjectName(u"removeButton")

        self.horizontalLayout.addWidget(self.removeButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.subsetLabel = QLabel(self.frame)
        self.subsetLabel.setObjectName(u"subsetLabel")

        self.horizontalLayout.addWidget(self.subsetLabel)

        self.subsetSpinBox = QDoubleSpinBox(self.frame)
        self.subsetSpinBox.setObjectName(u"subsetSpinBox")
        self.subsetSpinBox.setMaximum(100.000000000000000)
        self.subsetSpinBox.setSingleStep(5.000000000000000)
        self.subsetSpinBox.setValue(100.000000000000000)

        self.horizontalLayout.addWidget(self.subsetSpinBox)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.verticalSpacer_3 = QSpacerItem(20, 10, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_3)

        self.infoLabel = QLabel(self.frame)
        self.infoLabel.setObjectName(u"infoLabel")
        self.infoLabel.setFont(font)

        self.verticalLayout.addWidget(self.infoLabel)


        self.horizontalLayout_2.addWidget(self.frame)

        self.horizontalSpacer_2 = QSpacerItem(1, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)

        self.horizontalLayout_2.setStretch(0, 1)

        self.retranslateUi(MultiSensitivityWidget)

        QMetaObject.connectSlotsByName(MultiSensitivityWidget)
    # setupUi

    def retranslateUi(self, MultiSensitivityWidget):
        MultiSensitivityWidget.setWindowTitle(QCoreApplication.translate("MultiSensitivityWidget", u"Form", None))
        self.instructionsLabel.setText(QCoreApplication.translate("MultiSensitivityWidget", u"<html><head/><body><p>Select a variable from a module to vary, and click the Add button to include it in the search space. The range of values must be supplied using commas to separate them.</p><p>Note that the project may contain only one existing simulation.</p></body></html>", None))
        self.modLabel.setText(QCoreApplication.translate("MultiSensitivityWidget", u"Module: ", None))
        self.varLabel.setText(QCoreApplication.translate("MultiSensitivityWidget", u"Variable: ", None))
        self.lineLabel.setText(QCoreApplication.translate("MultiSensitivityWidget", u"Values: ", None))
        self.tableLabel.setText(QCoreApplication.translate("MultiSensitivityWidget", u"Chosen variable ranges:", None))
        self.addButton.setText(QCoreApplication.translate("MultiSensitivityWidget", u"Add", None))
        self.removeButton.setText(QCoreApplication.translate("MultiSensitivityWidget", u"Remove", None))
        self.subsetLabel.setText(QCoreApplication.translate("MultiSensitivityWidget", u"Subset percentage:", None))
        self.infoLabel.setText(QCoreApplication.translate("MultiSensitivityWidget", u"TextLabel", None))
    # retranslateUi

