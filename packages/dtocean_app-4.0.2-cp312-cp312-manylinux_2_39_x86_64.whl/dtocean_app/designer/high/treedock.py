# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'treedock.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDockWidget, QHeaderView, QSizePolicy,
    QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

class Ui_TreeDock(object):
    def setupUi(self, TreeDock):
        if not TreeDock.objectName():
            TreeDock.setObjectName(u"TreeDock")
        TreeDock.resize(404, 853)
        TreeDock.setMinimumSize(QSize(404, 224))
        TreeDock.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable|QDockWidget.DockWidgetFeature.DockWidgetMovable)
        TreeDock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea)
        self.dockWidgetContents = QWidget()
        self.dockWidgetContents.setObjectName(u"dockWidgetContents")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.dockWidgetContents.sizePolicy().hasHeightForWidth())
        self.dockWidgetContents.setSizePolicy(sizePolicy)
        self.dockWidgetContents.setMinimumSize(QSize(400, 0))
        self.verticalLayout = QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 0, 2)
        self.treeWidget = QTreeWidget(self.dockWidgetContents)
        self.treeWidget.setObjectName(u"treeWidget")
        self.treeWidget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

        self.verticalLayout.addWidget(self.treeWidget)

        TreeDock.setWidget(self.dockWidgetContents)

        self.retranslateUi(TreeDock)

        QMetaObject.connectSlotsByName(TreeDock)
    # setupUi

    def retranslateUi(self, TreeDock):
        TreeDock.setWindowTitle(QCoreApplication.translate("TreeDock", u"Tree", None))
        ___qtreewidgetitem = self.treeWidget.headerItem()
        ___qtreewidgetitem.setText(0, QCoreApplication.translate("TreeDock", u"Root:", None));
    # retranslateUi

