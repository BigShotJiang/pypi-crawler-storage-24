# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'intselect.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialogButtonBox, QGridLayout,
    QLabel, QSizePolicy, QSpacerItem, QSpinBox,
    QVBoxLayout, QWidget)

class Ui_IntSelect(object):
    def setupUi(self, IntSelect):
        if not IntSelect.objectName():
            IntSelect.setObjectName(u"IntSelect")
        IntSelect.resize(750, 200)
        self.verticalLayout = QVBoxLayout(IntSelect)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.staticLabel = QLabel(IntSelect)
        self.staticLabel.setObjectName(u"staticLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.staticLabel.sizePolicy().hasHeightForWidth())
        self.staticLabel.setSizePolicy(sizePolicy)
        self.staticLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.staticLabel, 0, 0, 1, 1)

        self.valueLabel = QLabel(IntSelect)
        self.valueLabel.setObjectName(u"valueLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.valueLabel.sizePolicy().hasHeightForWidth())
        self.valueLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.valueLabel, 0, 1, 1, 2)

        self.questionLabel = QLabel(IntSelect)
        self.questionLabel.setObjectName(u"questionLabel")
        sizePolicy.setHeightForWidth(self.questionLabel.sizePolicy().hasHeightForWidth())
        self.questionLabel.setSizePolicy(sizePolicy)
        self.questionLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.questionLabel, 1, 0, 1, 1)

        self.spinBox = QSpinBox(IntSelect)
        self.spinBox.setObjectName(u"spinBox")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.spinBox.sizePolicy().hasHeightForWidth())
        self.spinBox.setSizePolicy(sizePolicy2)
        self.spinBox.setMinimumSize(QSize(0, 0))
        self.spinBox.setKeyboardTracking(False)
        self.spinBox.setMinimum(-999999999)
        self.spinBox.setMaximum(999999999)

        self.gridLayout.addWidget(self.spinBox, 1, 1, 1, 1)

        self.unitsLabel = QLabel(IntSelect)
        self.unitsLabel.setObjectName(u"unitsLabel")
        sizePolicy.setHeightForWidth(self.unitsLabel.sizePolicy().hasHeightForWidth())
        self.unitsLabel.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.unitsLabel, 1, 2, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(20, 86, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(IntSelect)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)
        self.buttonBox.setCenterButtons(False)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(IntSelect)

        QMetaObject.connectSlotsByName(IntSelect)
    # setupUi

    def retranslateUi(self, IntSelect):
        IntSelect.setWindowTitle(QCoreApplication.translate("IntSelect", u"Form", None))
        self.staticLabel.setText(QCoreApplication.translate("IntSelect", u"Current value:", None))
        self.valueLabel.setText(QCoreApplication.translate("IntSelect", u"None", None))
        self.questionLabel.setText(QCoreApplication.translate("IntSelect", u"Please enter a number:", None))
        self.unitsLabel.setText(QCoreApplication.translate("IntSelect", u"(unit)", None))
    # retranslateUi

