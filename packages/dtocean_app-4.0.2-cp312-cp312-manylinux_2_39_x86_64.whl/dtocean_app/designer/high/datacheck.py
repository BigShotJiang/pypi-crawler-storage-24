# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'datacheck.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QFrame, QHBoxLayout, QHeaderView, QLabel,
    QSizePolicy, QSpacerItem, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget)

class Ui_DataCheckDialog(object):
    def setupUi(self, DataCheckDialog):
        if not DataCheckDialog.objectName():
            DataCheckDialog.setObjectName(u"DataCheckDialog")
        DataCheckDialog.resize(600, 398)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(DataCheckDialog.sizePolicy().hasHeightForWidth())
        DataCheckDialog.setSizePolicy(sizePolicy)
        DataCheckDialog.setMinimumSize(QSize(600, 300))
        DataCheckDialog.setMaximumSize(QSize(16777215, 16777215))
        DataCheckDialog.setSizeGripEnabled(False)
        self.verticalLayout = QVBoxLayout(DataCheckDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(DataCheckDialog)
        self.label.setObjectName(u"label")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy1)
        font = QFont()
        font.setFamilies([u"MS Shell Dlg 2"])
        self.label.setFont(font)
        self.label.setAlignment(Qt.AlignmentFlag.AlignBottom|Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft)

        self.horizontalLayout.addWidget(self.label)

        self.resultLabel = QLabel(DataCheckDialog)
        self.resultLabel.setObjectName(u"resultLabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.resultLabel.sizePolicy().hasHeightForWidth())
        self.resultLabel.setSizePolicy(sizePolicy2)
        self.resultLabel.setMinimumSize(QSize(100, 0))
        self.resultLabel.setAlignment(Qt.AlignmentFlag.AlignBottom|Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft)

        self.horizontalLayout.addWidget(self.resultLabel)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.line = QFrame(DataCheckDialog)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.verticalSpacer = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.provideLabel = QLabel(DataCheckDialog)
        self.provideLabel.setObjectName(u"provideLabel")
        font1 = QFont()
        font1.setPointSize(6)
        self.provideLabel.setFont(font1)

        self.verticalLayout.addWidget(self.provideLabel)

        self.tableWidget = QTableWidget(DataCheckDialog)
        if (self.tableWidget.columnCount() < 3):
            self.tableWidget.setColumnCount(3)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setEnabled(False)
        self.tableWidget.horizontalHeader().setCascadingSectionResizes(False)
        self.tableWidget.horizontalHeader().setMinimumSectionSize(175)
        self.tableWidget.horizontalHeader().setDefaultSectionSize(175)
        self.tableWidget.horizontalHeader().setHighlightSections(True)
        self.tableWidget.horizontalHeader().setStretchLastSection(True)
        self.tableWidget.verticalHeader().setVisible(False)

        self.verticalLayout.addWidget(self.tableWidget)

        self.verticalSpacer_2 = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.buttonBox = QDialogButtonBox(DataCheckDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(DataCheckDialog)
        self.buttonBox.accepted.connect(DataCheckDialog.accept)
        self.buttonBox.rejected.connect(DataCheckDialog.reject)

        QMetaObject.connectSlotsByName(DataCheckDialog)
    # setupUi

    def retranslateUi(self, DataCheckDialog):
        DataCheckDialog.setWindowTitle(QCoreApplication.translate("DataCheckDialog", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("DataCheckDialog", u"<html><head/><body><p><span style=\" font-size:10pt;\">Checking data requirements...</span></p></body></html>", None))
        self.resultLabel.setText("")
        self.provideLabel.setText(QCoreApplication.translate("DataCheckDialog", u"<html><head/><body><p><span style=\" font-size:8pt; font-weight:600;\">The following data is required and must be provided:</span></p></body></html>", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("DataCheckDialog", u"Section", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("DataCheckDialog", u"Branch", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("DataCheckDialog", u"Item", None));
    # retranslateUi

