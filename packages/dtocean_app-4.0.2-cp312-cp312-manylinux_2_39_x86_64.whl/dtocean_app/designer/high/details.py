# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'details.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QLabel, QLayout,
    QScrollArea, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_DetailsWidget(object):
    def setupUi(self, DetailsWidget):
        if not DetailsWidget.objectName():
            DetailsWidget.setObjectName(u"DetailsWidget")
        DetailsWidget.resize(518, 208)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(DetailsWidget.sizePolicy().hasHeightForWidth())
        DetailsWidget.setSizePolicy(sizePolicy)
        self.verticalLayout_2 = QVBoxLayout(DetailsWidget)
        self.verticalLayout_2.setSpacing(4)
        self.verticalLayout_2.setContentsMargins(4, 4, 4, 4)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.headingLabel = QLabel(DetailsWidget)
        self.headingLabel.setObjectName(u"headingLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.headingLabel.sizePolicy().hasHeightForWidth())
        self.headingLabel.setSizePolicy(sizePolicy1)
        self.headingLabel.setTextFormat(Qt.TextFormat.RichText)

        self.verticalLayout_2.addWidget(self.headingLabel)

        self.line = QFrame(DetailsWidget)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_2.addWidget(self.line)

        self.scrollArea = QScrollArea(DetailsWidget)
        self.scrollArea.setObjectName(u"scrollArea")
        sizePolicy.setHeightForWidth(self.scrollArea.sizePolicy().hasHeightForWidth())
        self.scrollArea.setSizePolicy(sizePolicy)
        self.scrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.scrollArea.setFrameShadow(QFrame.Shadow.Raised)
        self.scrollArea.setLineWidth(0)
        self.scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 510, 173))
        sizePolicy.setHeightForWidth(self.scrollAreaWidgetContents.sizePolicy().hasHeightForWidth())
        self.scrollAreaWidgetContents.setSizePolicy(sizePolicy)
        self.verticalLayout = QVBoxLayout(self.scrollAreaWidgetContents)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 0, 0, 2)
        self.staticLabel_1 = QLabel(self.scrollAreaWidgetContents)
        self.staticLabel_1.setObjectName(u"staticLabel_1")
        sizePolicy.setHeightForWidth(self.staticLabel_1.sizePolicy().hasHeightForWidth())
        self.staticLabel_1.setSizePolicy(sizePolicy)
        self.staticLabel_1.setMinimumSize(QSize(75, 0))
        font = QFont()
        font.setBold(True)
        self.staticLabel_1.setFont(font)
        self.staticLabel_1.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)

        self.verticalLayout.addWidget(self.staticLabel_1)

        self.titleLabel = QLabel(self.scrollAreaWidgetContents)
        self.titleLabel.setObjectName(u"titleLabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.titleLabel.sizePolicy().hasHeightForWidth())
        self.titleLabel.setSizePolicy(sizePolicy2)
        self.titleLabel.setMinimumSize(QSize(0, 0))
        self.titleLabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.titleLabel.setWordWrap(True)
        self.titleLabel.setIndent(2)
        self.titleLabel.setTextInteractionFlags(Qt.TextInteractionFlag.LinksAccessibleByMouse|Qt.TextInteractionFlag.TextSelectableByMouse)

        self.verticalLayout.addWidget(self.titleLabel)

        self.staticLabel_2 = QLabel(self.scrollAreaWidgetContents)
        self.staticLabel_2.setObjectName(u"staticLabel_2")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.staticLabel_2.sizePolicy().hasHeightForWidth())
        self.staticLabel_2.setSizePolicy(sizePolicy3)
        self.staticLabel_2.setMinimumSize(QSize(110, 0))
        self.staticLabel_2.setFont(font)
        self.staticLabel_2.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)

        self.verticalLayout.addWidget(self.staticLabel_2)

        self.descriptionLabel = QLabel(self.scrollAreaWidgetContents)
        self.descriptionLabel.setObjectName(u"descriptionLabel")
        sizePolicy2.setHeightForWidth(self.descriptionLabel.sizePolicy().hasHeightForWidth())
        self.descriptionLabel.setSizePolicy(sizePolicy2)
        self.descriptionLabel.setMinimumSize(QSize(0, 0))
        self.descriptionLabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.descriptionLabel.setWordWrap(True)
        self.descriptionLabel.setMargin(0)
        self.descriptionLabel.setIndent(2)
        self.descriptionLabel.setTextInteractionFlags(Qt.TextInteractionFlag.LinksAccessibleByMouse|Qt.TextInteractionFlag.TextSelectableByMouse)

        self.verticalLayout.addWidget(self.descriptionLabel)

        self.verticalSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.titleLabel.raise_()
        self.staticLabel_2.raise_()
        self.descriptionLabel.raise_()
        self.staticLabel_1.raise_()

        self.verticalLayout_2.addWidget(self.scrollArea)


        self.retranslateUi(DetailsWidget)

        QMetaObject.connectSlotsByName(DetailsWidget)
    # setupUi

    def retranslateUi(self, DetailsWidget):
        DetailsWidget.setWindowTitle(QCoreApplication.translate("DetailsWidget", u"Details", None))
        self.headingLabel.setText(QCoreApplication.translate("DetailsWidget", u"<html><head/><body><p><span style=\" font-weight:600;\">Variable Details:</span></p></body></html>", None))
        self.staticLabel_1.setText(QCoreApplication.translate("DetailsWidget", u"Title:", None))
        self.titleLabel.setText(QCoreApplication.translate("DetailsWidget", u"TextLabel", None))
        self.staticLabel_2.setText(QCoreApplication.translate("DetailsWidget", u"Description:", None))
        self.descriptionLabel.setText(QCoreApplication.translate("DetailsWidget", u"TextLabel", None))
    # retranslateUi

