# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'boolselect.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QDialogButtonBox,
    QGridLayout, QLabel, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_BoolSelect(object):
    def setupUi(self, BoolSelect):
        if not BoolSelect.objectName():
            BoolSelect.setObjectName(u"BoolSelect")
        BoolSelect.resize(694, 200)
        self.verticalLayout = QVBoxLayout(BoolSelect)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.staticLabel = QLabel(BoolSelect)
        self.staticLabel.setObjectName(u"staticLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.staticLabel.sizePolicy().hasHeightForWidth())
        self.staticLabel.setSizePolicy(sizePolicy)
        self.staticLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.staticLabel, 0, 0, 1, 1)

        self.valueLabel = QLabel(BoolSelect)
        self.valueLabel.setObjectName(u"valueLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.valueLabel.sizePolicy().hasHeightForWidth())
        self.valueLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.valueLabel, 0, 1, 1, 2)

        self.questionLabel = QLabel(BoolSelect)
        self.questionLabel.setObjectName(u"questionLabel")
        sizePolicy.setHeightForWidth(self.questionLabel.sizePolicy().hasHeightForWidth())
        self.questionLabel.setSizePolicy(sizePolicy)
        self.questionLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.questionLabel, 1, 0, 1, 1)

        self.checkBox = QCheckBox(BoolSelect)
        self.checkBox.setObjectName(u"checkBox")

        self.gridLayout.addWidget(self.checkBox, 1, 1, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(20, 86, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(BoolSelect)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel)
        self.buttonBox.setCenterButtons(False)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(BoolSelect)

        QMetaObject.connectSlotsByName(BoolSelect)
    # setupUi

    def retranslateUi(self, BoolSelect):
        BoolSelect.setWindowTitle(QCoreApplication.translate("BoolSelect", u"Form", None))
        self.staticLabel.setText(QCoreApplication.translate("BoolSelect", u"Current value:", None))
        self.valueLabel.setText(QCoreApplication.translate("BoolSelect", u"None", None))
        self.questionLabel.setText(QCoreApplication.translate("BoolSelect", u"Select if True:", None))
        self.checkBox.setText("")
    # retranslateUi

