# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'listframeeditor.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_ListFrameEditor(object):
    def setupUi(self, ListFrameEditor):
        if not ListFrameEditor.objectName():
            ListFrameEditor.setObjectName(u"ListFrameEditor")
        ListFrameEditor.resize(920, 636)
        self.verticalLayout = QVBoxLayout(ListFrameEditor)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.topStaticLabel = QLabel(ListFrameEditor)
        self.topStaticLabel.setObjectName(u"topStaticLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.topStaticLabel.sizePolicy().hasHeightForWidth())
        self.topStaticLabel.setSizePolicy(sizePolicy)
        font = QFont()
        font.setBold(False)
        self.topStaticLabel.setFont(font)

        self.horizontalLayout.addWidget(self.topStaticLabel)

        self.topDynamicLabel = QLabel(ListFrameEditor)
        self.topDynamicLabel.setObjectName(u"topDynamicLabel")
        font1 = QFont()
        font1.setBold(True)
        self.topDynamicLabel.setFont(font1)

        self.horizontalLayout.addWidget(self.topDynamicLabel)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.line = QFrame(ListFrameEditor)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.verticalSpacer = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.gridLayout = QGridLayout()
        self.gridLayout.setSpacing(20)
        self.gridLayout.setObjectName(u"gridLayout")
        self.listLabel = QLabel(ListFrameEditor)
        self.listLabel.setObjectName(u"listLabel")
        self.listLabel.setFont(font1)

        self.gridLayout.addWidget(self.listLabel, 0, 0, 1, 1)

        self.mainLabel = QLabel(ListFrameEditor)
        self.mainLabel.setObjectName(u"mainLabel")
        self.mainLabel.setFont(font1)

        self.gridLayout.addWidget(self.mainLabel, 0, 1, 1, 1)

        self.listWidget = QListWidget(ListFrameEditor)
        self.listWidget.setObjectName(u"listWidget")
        self.listWidget.setMaximumSize(QSize(250, 16777215))

        self.gridLayout.addWidget(self.listWidget, 1, 0, 1, 1)

        self.mainFrame = QFrame(ListFrameEditor)
        self.mainFrame.setObjectName(u"mainFrame")
        self.mainFrame.setFrameShape(QFrame.Shape.Panel)
        self.mainFrame.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout.addWidget(self.mainFrame, 1, 1, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer_3 = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_3)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.resetButton = QPushButton(ListFrameEditor)
        self.resetButton.setObjectName(u"resetButton")
        self.resetButton.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.resetButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)

        self.closeButton = QPushButton(ListFrameEditor)
        self.closeButton.setObjectName(u"closeButton")
        self.closeButton.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.closeButton)

        self.applyButton = QPushButton(ListFrameEditor)
        self.applyButton.setObjectName(u"applyButton")
        self.applyButton.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.applyButton)


        self.verticalLayout.addLayout(self.horizontalLayout_2)


        self.retranslateUi(ListFrameEditor)

        QMetaObject.connectSlotsByName(ListFrameEditor)
    # setupUi

    def retranslateUi(self, ListFrameEditor):
        ListFrameEditor.setWindowTitle(QCoreApplication.translate("ListFrameEditor", u"Dialog", None))
        self.topStaticLabel.setText(QCoreApplication.translate("ListFrameEditor", u"TextLabel", None))
        self.topDynamicLabel.setText(QCoreApplication.translate("ListFrameEditor", u"TextLabel", None))
        self.listLabel.setText(QCoreApplication.translate("ListFrameEditor", u"Some text:", None))
        self.mainLabel.setText(QCoreApplication.translate("ListFrameEditor", u"Some more text:", None))
        self.resetButton.setText(QCoreApplication.translate("ListFrameEditor", u"Reset", None))
        self.closeButton.setText(QCoreApplication.translate("ListFrameEditor", u"Close", None))
        self.applyButton.setText(QCoreApplication.translate("ListFrameEditor", u"Apply", None))
    # retranslateUi

