# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'listselect.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QComboBox, QDialogButtonBox,
    QGridLayout, QHBoxLayout, QLabel, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_ListSelect(object):
    def setupUi(self, ListSelect):
        if not ListSelect.objectName():
            ListSelect.setObjectName(u"ListSelect")
        ListSelect.resize(905, 211)
        self.verticalLayout = QVBoxLayout(ListSelect)
        self.verticalLayout.setSpacing(9)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.staticLabel = QLabel(ListSelect)
        self.staticLabel.setObjectName(u"staticLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.staticLabel.sizePolicy().hasHeightForWidth())
        self.staticLabel.setSizePolicy(sizePolicy)
        self.staticLabel.setMinimumSize(QSize(200, 0))

        self.gridLayout.addWidget(self.staticLabel, 0, 0, 1, 1)

        self.valueLabel = QLabel(ListSelect)
        self.valueLabel.setObjectName(u"valueLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.valueLabel.sizePolicy().hasHeightForWidth())
        self.valueLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.valueLabel, 0, 1, 1, 1)

        self.questionLabel = QLabel(ListSelect)
        self.questionLabel.setObjectName(u"questionLabel")
        sizePolicy.setHeightForWidth(self.questionLabel.sizePolicy().hasHeightForWidth())
        self.questionLabel.setSizePolicy(sizePolicy)
        self.questionLabel.setMinimumSize(QSize(200, 0))
        self.questionLabel.setScaledContents(False)
        self.questionLabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.questionLabel.setWordWrap(False)

        self.gridLayout.addWidget(self.questionLabel, 1, 0, 1, 1)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.comboBox = QComboBox(ListSelect)
        self.comboBox.setObjectName(u"comboBox")
        sizePolicy1.setHeightForWidth(self.comboBox.sizePolicy().hasHeightForWidth())
        self.comboBox.setSizePolicy(sizePolicy1)

        self.horizontalLayout.addWidget(self.comboBox)

        self.unitsLabel = QLabel(ListSelect)
        self.unitsLabel.setObjectName(u"unitsLabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.unitsLabel.sizePolicy().hasHeightForWidth())
        self.unitsLabel.setSizePolicy(sizePolicy2)
        self.unitsLabel.setMargin(1)

        self.horizontalLayout.addWidget(self.unitsLabel)


        self.gridLayout.addLayout(self.horizontalLayout, 1, 1, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(20, 97, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(ListSelect)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)
        self.buttonBox.setCenterButtons(False)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(ListSelect)

        QMetaObject.connectSlotsByName(ListSelect)
    # setupUi

    def retranslateUi(self, ListSelect):
        ListSelect.setWindowTitle(QCoreApplication.translate("ListSelect", u"Form", None))
        self.staticLabel.setText(QCoreApplication.translate("ListSelect", u"Current value:", None))
        self.valueLabel.setText(QCoreApplication.translate("ListSelect", u"None", None))
        self.questionLabel.setText(QCoreApplication.translate("ListSelect", u"Select a new value from the list:", None))
        self.unitsLabel.setText(QCoreApplication.translate("ListSelect", u"(unit)", None))
    # retranslateUi

