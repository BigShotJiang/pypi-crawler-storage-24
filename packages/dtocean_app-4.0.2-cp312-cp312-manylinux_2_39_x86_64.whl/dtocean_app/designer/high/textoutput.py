# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'textoutput.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QSizePolicy, QTextBrowser, QVBoxLayout,
    QWidget)

class Ui_TextOutput(object):
    def setupUi(self, TextOutput):
        if not TextOutput.objectName():
            TextOutput.setObjectName(u"TextOutput")
        TextOutput.resize(750, 121)
        self.verticalLayout = QVBoxLayout(TextOutput)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.textBrowser = QTextBrowser(TextOutput)
        self.textBrowser.setObjectName(u"textBrowser")

        self.verticalLayout.addWidget(self.textBrowser)


        self.retranslateUi(TextOutput)

        QMetaObject.connectSlotsByName(TextOutput)
    # setupUi

    def retranslateUi(self, TextOutput):
        TextOutput.setWindowTitle(QCoreApplication.translate("TextOutput", u"Form", None))
    # retranslateUi

