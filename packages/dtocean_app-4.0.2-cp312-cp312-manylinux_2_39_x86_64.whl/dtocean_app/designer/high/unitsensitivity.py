# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'unitsensitivity.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_UnitSensitivityWidget(object):
    def setupUi(self, UnitSensitivityWidget):
        if not UnitSensitivityWidget.objectName():
            UnitSensitivityWidget.setObjectName(u"UnitSensitivityWidget")
        UnitSensitivityWidget.resize(600, 450)
        self.horizontalLayout = QHBoxLayout(UnitSensitivityWidget)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.frame = QFrame(UnitSensitivityWidget)
        self.frame.setObjectName(u"frame")
        self.frame.setMaximumSize(QSize(600, 16777215))
        self.frame.setFrameShape(QFrame.Shape.NoFrame)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout = QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setWordWrap(True)

        self.verticalLayout.addWidget(self.label_2)

        self.verticalSpacer_2 = QSpacerItem(17, 13, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")

        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.label_3 = QLabel(self.frame)
        self.label_3.setObjectName(u"label_3")

        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)

        self.label_4 = QLabel(self.frame)
        self.label_4.setObjectName(u"label_4")

        self.gridLayout.addWidget(self.label_4, 2, 0, 1, 1)

        self.lineEdit = QLineEdit(self.frame)
        self.lineEdit.setObjectName(u"lineEdit")

        self.gridLayout.addWidget(self.lineEdit, 2, 1, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(20, 277, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)


        self.horizontalLayout.addWidget(self.frame)

        self.horizontalSpacer = QSpacerItem(1, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.horizontalLayout.setStretch(0, 1)

        self.retranslateUi(UnitSensitivityWidget)

        QMetaObject.connectSlotsByName(UnitSensitivityWidget)
    # setupUi

    def retranslateUi(self, UnitSensitivityWidget):
        UnitSensitivityWidget.setWindowTitle(QCoreApplication.translate("UnitSensitivityWidget", u"Form", None))
        self.label_2.setText(QCoreApplication.translate("UnitSensitivityWidget", u"<html><head/><body><p>Select a variable from a module to vary. The range of values must be supplied using commas to separate them.</p><p>Note that the project may contain only one existing simulation.</p></body></html>", None))
        self.label.setText(QCoreApplication.translate("UnitSensitivityWidget", u"Module: ", None))
        self.label_3.setText(QCoreApplication.translate("UnitSensitivityWidget", u"Variable: ", None))
        self.label_4.setText(QCoreApplication.translate("UnitSensitivityWidget", u"Values: ", None))
    # retranslateUi

