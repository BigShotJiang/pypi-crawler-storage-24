# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'testdatapicker.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QDialog,
    QDialogButtonBox, QGridLayout, QLabel, QLayout,
    QLineEdit, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_TestDataPicker(object):
    def setupUi(self, TestDataPicker):
        if not TestDataPicker.objectName():
            TestDataPicker.setObjectName(u"TestDataPicker")
        TestDataPicker.resize(565, 135)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TestDataPicker.sizePolicy().hasHeightForWidth())
        TestDataPicker.setSizePolicy(sizePolicy)
        TestDataPicker.setMinimumSize(QSize(0, 135))
        TestDataPicker.setMaximumSize(QSize(16777215, 135))
        self.verticalLayout = QVBoxLayout(TestDataPicker)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setSizeConstraint(QLayout.SizeConstraint.SetFixedSize)
        self.label = QLabel(TestDataPicker)
        self.label.setObjectName(u"label")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy1)
        self.label.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.label.setStyleSheet(u"")
        self.label.setTextFormat(Qt.TextFormat.PlainText)
        self.label.setScaledContents(False)
        self.label.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.pathLineEdit = QLineEdit(TestDataPicker)
        self.pathLineEdit.setObjectName(u"pathLineEdit")
        self.pathLineEdit.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout.addWidget(self.pathLineEdit, 0, 1, 1, 1)

        self.overwriteBox = QCheckBox(TestDataPicker)
        self.overwriteBox.setObjectName(u"overwriteBox")
        self.overwriteBox.setLayoutDirection(Qt.LayoutDirection.RightToLeft)

        self.gridLayout.addWidget(self.overwriteBox, 1, 0, 1, 2)


        self.verticalLayout.addLayout(self.gridLayout)

        self.verticalSpacer = QSpacerItem(10, 5, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonBox = QDialogButtonBox(TestDataPicker)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(TestDataPicker)
        self.buttonBox.accepted.connect(TestDataPicker.accept)
        self.buttonBox.rejected.connect(TestDataPicker.reject)

        QMetaObject.connectSlotsByName(TestDataPicker)
    # setupUi

    def retranslateUi(self, TestDataPicker):
        TestDataPicker.setWindowTitle(QCoreApplication.translate("TestDataPicker", u"Load Test Data", None))
        self.label.setText(QCoreApplication.translate("TestDataPicker", u"Test data path: ", None))
        self.overwriteBox.setText(QCoreApplication.translate("TestDataPicker", u"Overwrite existing data:", None))
    # retranslateUi

