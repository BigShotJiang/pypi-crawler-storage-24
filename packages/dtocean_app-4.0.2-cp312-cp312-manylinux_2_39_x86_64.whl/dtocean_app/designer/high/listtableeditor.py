# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'listtableeditor.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QFrame, QGridLayout, QHBoxLayout, QHeaderView,
    QLabel, QLayout, QListWidget, QListWidgetItem,
    QPushButton, QSizePolicy, QSpacerItem, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_ListTableEditor(object):
    def setupUi(self, ListTableEditor):
        if not ListTableEditor.objectName():
            ListTableEditor.setObjectName(u"ListTableEditor")
        ListTableEditor.resize(553, 419)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(ListTableEditor.sizePolicy().hasHeightForWidth())
        ListTableEditor.setSizePolicy(sizePolicy)
        ListTableEditor.setMinimumSize(QSize(0, 0))
        ListTableEditor.setMaximumSize(QSize(100000, 100000))
        ListTableEditor.setSizeGripEnabled(False)
        self.verticalLayout_2 = QVBoxLayout(ListTableEditor)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setSizeConstraint(QLayout.SizeConstraint.SetFixedSize)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.topStaticLabel = QLabel(ListTableEditor)
        self.topStaticLabel.setObjectName(u"topStaticLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.topStaticLabel.sizePolicy().hasHeightForWidth())
        self.topStaticLabel.setSizePolicy(sizePolicy1)
        font = QFont()
        font.setBold(False)
        self.topStaticLabel.setFont(font)

        self.horizontalLayout.addWidget(self.topStaticLabel)

        self.topDynamicLabel = QLabel(ListTableEditor)
        self.topDynamicLabel.setObjectName(u"topDynamicLabel")
        font1 = QFont()
        font1.setBold(True)
        self.topDynamicLabel.setFont(font1)

        self.horizontalLayout.addWidget(self.topDynamicLabel)


        self.verticalLayout_2.addLayout(self.horizontalLayout)

        self.line = QFrame(ListTableEditor)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_2.addWidget(self.line)

        self.extraLabel = QLabel(ListTableEditor)
        self.extraLabel.setObjectName(u"extraLabel")
        self.extraLabel.setWordWrap(True)

        self.verticalLayout_2.addWidget(self.extraLabel)

        self.verticalSpacer = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setHorizontalSpacing(14)
        self.blankLabel = QLabel(ListTableEditor)
        self.blankLabel.setObjectName(u"blankLabel")
        self.blankLabel.setEnabled(True)
        sizePolicy1.setHeightForWidth(self.blankLabel.sizePolicy().hasHeightForWidth())
        self.blankLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.blankLabel, 0, 0, 1, 1)

        self.listLabel = QLabel(ListTableEditor)
        self.listLabel.setObjectName(u"listLabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.listLabel.sizePolicy().hasHeightForWidth())
        self.listLabel.setSizePolicy(sizePolicy2)
        self.listLabel.setFont(font1)

        self.gridLayout.addWidget(self.listLabel, 0, 1, 1, 1)

        self.tableLabel = QLabel(ListTableEditor)
        self.tableLabel.setObjectName(u"tableLabel")
        sizePolicy2.setHeightForWidth(self.tableLabel.sizePolicy().hasHeightForWidth())
        self.tableLabel.setSizePolicy(sizePolicy2)
        self.tableLabel.setFont(font1)

        self.gridLayout.addWidget(self.tableLabel, 0, 2, 1, 1)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(9)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setSizeConstraint(QLayout.SizeConstraint.SetFixedSize)
        self.addButton = QPushButton(ListTableEditor)
        self.addButton.setObjectName(u"addButton")
        sizePolicy.setHeightForWidth(self.addButton.sizePolicy().hasHeightForWidth())
        self.addButton.setSizePolicy(sizePolicy)
        self.addButton.setAutoDefault(False)

        self.verticalLayout.addWidget(self.addButton)

        self.deleteButton = QPushButton(ListTableEditor)
        self.deleteButton.setObjectName(u"deleteButton")
        sizePolicy.setHeightForWidth(self.deleteButton.sizePolicy().hasHeightForWidth())
        self.deleteButton.setSizePolicy(sizePolicy)
        self.deleteButton.setAutoDefault(False)

        self.verticalLayout.addWidget(self.deleteButton)

        self.saveButton = QPushButton(ListTableEditor)
        self.saveButton.setObjectName(u"saveButton")
        sizePolicy.setHeightForWidth(self.saveButton.sizePolicy().hasHeightForWidth())
        self.saveButton.setSizePolicy(sizePolicy)
        self.saveButton.setAutoDefault(False)

        self.verticalLayout.addWidget(self.saveButton)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer_2)


        self.gridLayout.addLayout(self.verticalLayout, 1, 0, 1, 1)

        self.listWidget = QListWidget(ListTableEditor)
        self.listWidget.setObjectName(u"listWidget")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.listWidget.sizePolicy().hasHeightForWidth())
        self.listWidget.setSizePolicy(sizePolicy3)
        self.listWidget.setMinimumSize(QSize(0, 0))
        self.listWidget.setMaximumSize(QSize(150, 100000))

        self.gridLayout.addWidget(self.listWidget, 1, 1, 1, 1)

        self.tableWidget = QTableWidget(ListTableEditor)
        self.tableWidget.setObjectName(u"tableWidget")
        sizePolicy3.setHeightForWidth(self.tableWidget.sizePolicy().hasHeightForWidth())
        self.tableWidget.setSizePolicy(sizePolicy3)
        self.tableWidget.setMinimumSize(QSize(0, 250))
        self.tableWidget.setMaximumSize(QSize(300, 1000000))

        self.gridLayout.addWidget(self.tableWidget, 1, 2, 1, 1)

        self.gridLayout.setColumnStretch(0, 1)
        self.gridLayout.setColumnStretch(1, 1)
        self.gridLayout.setColumnStretch(2, 2)

        self.verticalLayout_2.addLayout(self.gridLayout)

        self.verticalSpacer_3 = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_2.addItem(self.verticalSpacer_3)

        self.buttonBox = QDialogButtonBox(ListTableEditor)
        self.buttonBox.setObjectName(u"buttonBox")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.buttonBox.sizePolicy().hasHeightForWidth())
        self.buttonBox.setSizePolicy(sizePolicy4)
        self.buttonBox.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Apply|QDialogButtonBox.StandardButton.Close|QDialogButtonBox.StandardButton.Reset)

        self.verticalLayout_2.addWidget(self.buttonBox)


        self.retranslateUi(ListTableEditor)
        self.buttonBox.accepted.connect(ListTableEditor.accept)
        self.buttonBox.rejected.connect(ListTableEditor.reject)

        QMetaObject.connectSlotsByName(ListTableEditor)
    # setupUi

    def retranslateUi(self, ListTableEditor):
        ListTableEditor.setWindowTitle(QCoreApplication.translate("ListTableEditor", u"Dialog", None))
        self.topStaticLabel.setText(QCoreApplication.translate("ListTableEditor", u"TextLabel", None))
        self.topDynamicLabel.setText(QCoreApplication.translate("ListTableEditor", u"TextLabel", None))
        self.extraLabel.setText("")
        self.blankLabel.setText("")
        self.listLabel.setText(QCoreApplication.translate("ListTableEditor", u"TextLabel", None))
        self.tableLabel.setText(QCoreApplication.translate("ListTableEditor", u"TextLabel", None))
        self.addButton.setText(QCoreApplication.translate("ListTableEditor", u"Add", None))
        self.deleteButton.setText(QCoreApplication.translate("ListTableEditor", u"Delete", None))
        self.saveButton.setText(QCoreApplication.translate("ListTableEditor", u"Save", None))
    # retranslateUi

