# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'systemdock.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDockWidget, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_SystemDock(object):
    def setupUi(self, SystemDock):
        if not SystemDock.objectName():
            SystemDock.setObjectName(u"SystemDock")
        SystemDock.resize(726, 268)
        SystemDock.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable|QDockWidget.DockWidgetFeature.DockWidgetMovable)
        SystemDock.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea)
        self.dockWidgetContents = QWidget()
        self.dockWidgetContents.setObjectName(u"dockWidgetContents")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.dockWidgetContents.sizePolicy().hasHeightForWidth())
        self.dockWidgetContents.setSizePolicy(sizePolicy)
        self.verticalLayout = QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 2, 2, 2)
        SystemDock.setWidget(self.dockWidgetContents)

        self.retranslateUi(SystemDock)

        QMetaObject.connectSlotsByName(SystemDock)
    # setupUi

    def retranslateUi(self, SystemDock):
        SystemDock.setWindowTitle(QCoreApplication.translate("SystemDock", u"System", None))
    # retranslateUi

