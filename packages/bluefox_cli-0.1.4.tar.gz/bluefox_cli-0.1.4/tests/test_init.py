"""Tests for the bluefox init command."""

import os

from click.testing import CliRunner

from bluefox_cli.main import cli


def test_init_creates_project(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    result = runner.invoke(cli, ["init", "myapp"], catch_exceptions=False)

    # Command should fail because uv add can't resolve bluefox-core in test env,
    # but the directory and files should still be created before that point.
    # So we test file generation separately.
    project_dir = tmp_path / "myapp"
    assert project_dir.exists()


def test_init_creates_all_expected_files(tmp_path):
    """Verify all expected files are written (before uv commands run)."""
    from bluefox_cli.templates import TEMPLATES

    runner = CliRunner()
    os.chdir(tmp_path)
    # This will fail at the uv step, but files should exist
    runner.invoke(cli, ["init", "myapp"])

    project_dir = tmp_path / "myapp"
    for rel_path in TEMPLATES:
        assert (project_dir / rel_path).exists(), f"Missing: {rel_path}"


def test_init_creates_migrations_versions_dir(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    assert (tmp_path / "myapp" / "migrations" / "versions").is_dir()


def test_init_aborts_if_directory_exists(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    (tmp_path / "myapp").mkdir()

    result = runner.invoke(cli, ["init", "myapp"])
    assert result.exit_code != 0
    assert "already exists" in result.output or "already exists" in (result.stderr or "")


def test_init_main_py_content(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    content = (tmp_path / "myapp" / "main.py").read_text()
    assert "from bluefox_core import BluefoxSettings, create_bluefox_app" in content
    assert "create_app" in content
    assert 'MODELS_MODULE="models"' in content


def test_init_models_py_content(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    content = (tmp_path / "myapp" / "models.py").read_text()
    assert "BluefoxBase" in content
    assert "Example" in content


def test_init_env_files(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    env_example = (tmp_path / "myapp" / ".env.example").read_text()
    assert "DATABASE_URL=" in env_example
    assert "myapp" in env_example

    env = (tmp_path / "myapp" / ".env").read_text()
    assert "DEBUG=true" in env


def test_init_makefile_content(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    content = (tmp_path / "myapp" / "Makefile").read_text()
    assert "docker compose" in content
    assert "dev:" in content
    assert "dev-down:" in content
    assert "test:" in content
    assert "migrate:" in content
    assert "migrate-make:" in content


def test_init_dockerfile_content(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    content = (tmp_path / "myapp" / "Dockerfile").read_text()
    assert "FROM ghcr.io/astral-sh/uv" in content
    assert "uvicorn" in content


def test_init_docker_compose_content(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    prod = (tmp_path / "myapp" / "docker-compose.yml").read_text()
    assert "dokploy-network" in prod
    assert "external: true" in prod
    assert "service_completed_successfully" in prod

    dev = (tmp_path / "myapp" / "docker-compose.dev.yml").read_text()
    assert "myapp" in dev
    assert "pgdata" in dev


def test_init_alembic_config(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    ini = (tmp_path / "myapp" / "alembic.ini").read_text()
    assert "script_location = migrations" in ini

    env_py = (tmp_path / "myapp" / "migrations" / "env.py").read_text()
    assert "configure_alembic" in env_py


def test_init_test_files(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    conftest = (tmp_path / "myapp" / "tests" / "conftest.py").read_text()
    assert "bluefox_test_setup" in conftest

    test_health = (tmp_path / "myapp" / "tests" / "test_health.py").read_text()
    assert "/health" in test_health


def test_init_project_name_in_env(tmp_path):
    """Project name should appear in DATABASE_URL and APP_NAME."""
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "cool_project"])

    env = (tmp_path / "cool_project" / ".env").read_text()
    assert "cool_project" in env
    assert "APP_NAME=cool-project" in env


def test_init_dev_compose_mounts_source_files(tmp_path):
    """Dev compose should mount source files for hot reload, not the whole project."""
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    dev = (tmp_path / "myapp" / "docker-compose.dev.yml").read_text()
    assert "./main.py:/app/main.py" in dev
    assert "./models.py:/app/models.py" in dev
    assert "./migrations:/app/migrations" in dev
    # Should NOT mount the whole project (which would shadow .venv)
    assert "- .:/app" not in dev


def test_init_conftest_has_app_factory(tmp_path):
    """conftest.py should pass app_factory to bluefox_test_setup."""
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp"])

    conftest = (tmp_path / "myapp" / "tests" / "conftest.py").read_text()
    assert 'app_factory="main:create_app"' in conftest


def test_init_no_args_shows_help():
    """Running without arguments should show usage info."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "Bluefox" in result.output


def test_init_missing_project_name():
    """Running init without a project name should fail."""
    runner = CliRunner()
    result = runner.invoke(cli, ["init"])
    assert result.exit_code != 0
