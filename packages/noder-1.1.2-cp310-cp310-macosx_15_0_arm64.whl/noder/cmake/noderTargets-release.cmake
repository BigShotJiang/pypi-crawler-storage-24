#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "noder::core_shared" for configuration "Release"
set_property(TARGET noder::core_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(noder::core_shared PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hdf5-shared"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/noder/libcore_shared.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libcore_shared.dylib"
  )

list(APPEND _cmake_import_check_targets noder::core_shared )
list(APPEND _cmake_import_check_files_for_noder::core_shared "${_IMPORT_PREFIX}/noder/libcore_shared.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
