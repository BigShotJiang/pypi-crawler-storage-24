# datarep

A trusted local service that retrieves data from arbitrary sources on behalf of your application. Your app describes what data it wants — datarep figures out how to get it.

## Quick start

```bash
pip install -e ".[dev]"
datarep init
export ANTHROPIC_API_KEY="sk-ant-..."
datarep start
```

Register your app and get an API key:

```bash
datarep app register my-app
```

Retrieve data:

```bash
curl -X POST http://127.0.0.1:7080/get \
  -H "Authorization: Bearer dr_<your-api-key>" \
  -H "Content-Type: application/json" \
  -d '{"source": "my_source", "query": "get recent records"}'
```

## What it does

Instead of every app building its own integrations, datarep:

- **Manages credentials** — encrypted storage, browser-based OAuth, automatic token refresh
- **Writes retrieval code** — a Claude agent inspects sources and generates Python code dynamically
- **Executes in a sandbox** — network and filesystem restrictions via macOS `sandbox-exec`
- **Caches as recipes** — working code is saved for instant, deterministic replay
- **Authenticates apps** — per-app API keys with source-level access control and audit logging

Users grant trust once (to datarep). Every consuming app gets safe data access through it.

## Interfaces

| Interface | Use case |
|-----------|----------|
| **HTTP API** (`localhost:7080`) | Primary interface for all apps. Bearer token auth. |
| **MCP server** | Native interface for agentic/LLM-powered apps. |
| **CLI** (`datarep`) | Setup, source management, debugging. |

## Source types

| Type | Example | Sandbox |
|------|---------|---------|
| `local_db` | iMessage `chat.db`, WhatsApp, any SQLite | No network. Read-only DB access. |
| `rest_api` | Square, Gmail, Quickbooks | Network restricted to source domain. |
| `local_files` | Photos, documents, exports | No network. Read-only directory access. |

## Integration guide

See **[docs/integration-guide.md](docs/integration-guide.md)** for the full walkthrough: API reference, authentication, handling permissions, MCP setup, recipes, and code examples.

## Development

```bash
pip install -e ".[dev]"
pytest
```
