"""FastAPI local HTTP API for datarep — the primary interface for consuming apps."""

from __future__ import annotations

import json
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel

from datarep.db import get_connection
from datarep.config import ensure_home
from datarep.app_auth import AppAuthManager
from datarep.agent import RetrievalAgent
from datarep.credentials import CredentialStore, OAuthFlow
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry
from datarep.sync_state import SyncStateManager
from datarep.webhooks import handle_webhook


app = FastAPI(title="datarep", version="1.0.0")

_conn = None
_registry = None
_cred_store = None
_recipe_store = None
_sync_state = None
_app_auth = None
_agent = None


def _init():
    global _conn, _registry, _cred_store, _recipe_store, _sync_state, _app_auth, _agent
    if _conn is not None:
        return
    ensure_home()
    _conn = get_connection()
    _registry = SourceRegistry(_conn)
    _cred_store = CredentialStore(_conn)
    _recipe_store = RecipeStore(_conn)
    _sync_state = SyncStateManager(_conn)
    _app_auth = AppAuthManager(_conn)
    try:
        _agent = RetrievalAgent(
            _conn,
            registry=_registry,
            cred_store=_cred_store,
            recipe_store=_recipe_store,
            sync_state=_sync_state,
        )
    except ValueError:
        _agent = None


@app.on_event("startup")
async def startup():
    _init()


def _authenticate(authorization: str | None) -> dict[str, Any]:
    """Verify API key from Authorization header."""
    _init()
    if authorization is None:
        raise HTTPException(status_code=401, detail="Missing Authorization header.")
    parts = authorization.split(" ", 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(status_code=401, detail="Invalid Authorization header format. Use: Bearer <api_key>")
    app_info = _app_auth.verify_key(parts[1])
    if app_info is None:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key.")
    return app_info


def _check_source_access(app_info: dict, source_name: str):
    if not _app_auth.check_source_access(app_info, source_name):
        raise HTTPException(status_code=403, detail=f"App '{app_info['name']}' does not have access to source '{source_name}'.")


# --- Models ---

class GetRequest(BaseModel):
    source: str
    query: str

class SyncRequest(BaseModel):
    source: str
    query: str = ""

class RecipeRunRequest(BaseModel):
    recipe_id: str

class SourceAddRequest(BaseModel):
    name: str
    source_type: str
    config: dict[str, Any] = {}

class CredentialStoreRequest(BaseModel):
    source: str
    cred_type: str
    data: dict[str, Any]
    expires_at: str | None = None

class OAuthInitRequest(BaseModel):
    source: str


# --- Endpoints ---

@app.get("/health")
async def health():
    return {"status": "ok", "service": "datarep", "version": "1.0.0"}


@app.post("/get")
async def get_data(req: GetRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    _check_source_access(app_info, req.source)

    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not available. Check ANTHROPIC_API_KEY.")

    _app_auth.log(app_info["app_id"], "get", req.source, "started")
    result = await _agent.run(req.source, req.query)

    status = result.get("status", "error")
    _app_auth.log(app_info["app_id"], "get", req.source, status, details={"query": req.query})
    return result


@app.post("/sync")
async def sync_data(req: SyncRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    _check_source_access(app_info, req.source)

    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not available. Check ANTHROPIC_API_KEY.")

    _app_auth.log(app_info["app_id"], "sync", req.source, "started")
    query = req.query or f"Incremental sync for {req.source}"
    result = await _agent.run(req.source, query)

    status = result.get("status", "error")
    _app_auth.log(app_info["app_id"], "sync", req.source, status)
    return result


@app.post("/recipe/run")
async def run_recipe(req: RecipeRunRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)

    recipe = _recipe_store.get(req.recipe_id)
    if recipe is None:
        raise HTTPException(status_code=404, detail=f"Recipe '{req.recipe_id}' not found.")

    _check_source_access(app_info, recipe["source_name"])
    _app_auth.log(app_info["app_id"], "recipe_run", recipe["source_name"], "started",
                  details={"recipe_id": req.recipe_id})

    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not available. Check ANTHROPIC_API_KEY.")

    result = await _agent.run_recipe(req.recipe_id)
    status = result.get("status", "error")
    _app_auth.log(app_info["app_id"], "recipe_run", recipe["source_name"], status,
                  details={"recipe_id": req.recipe_id})
    return result


@app.get("/sources")
async def list_sources(authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    allowed = app_info.get("allowed_sources")
    sources = _registry.list(names=allowed)

    for source in sources:
        state = _sync_state.get(source["name"])
        source["sync_state"] = state
    return {"sources": sources}


@app.post("/sources")
async def add_source(req: SourceAddRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    try:
        source = _registry.add(req.name, req.source_type, req.config)
        _app_auth.log(app_info["app_id"], "source_add", req.name, "success")
        return source
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.delete("/sources/{name}")
async def remove_source(name: str, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    if _registry.remove(name):
        _app_auth.log(app_info["app_id"], "source_remove", name, "success")
        return {"message": f"Source '{name}' removed."}
    raise HTTPException(status_code=404, detail=f"Source '{name}' not found.")


@app.post("/auth/credentials")
async def store_credentials(req: CredentialStoreRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    _cred_store.store(req.source, req.cred_type, req.data, req.expires_at)
    _app_auth.log(app_info["app_id"], "auth_store", req.source, "success")
    return {"message": f"Credentials stored for '{req.source}'."}


@app.post("/auth/oauth")
async def initiate_oauth(req: OAuthInitRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    source = _registry.get(req.source)
    if source is None:
        raise HTTPException(status_code=404, detail=f"Source '{req.source}' not found.")

    config = source["config"]
    required = ["auth_url", "token_url", "client_id", "client_secret"]
    missing = [k for k in required if k not in config]
    if missing:
        raise HTTPException(status_code=400, detail=f"Source config missing: {', '.join(missing)}")

    flow = OAuthFlow(
        auth_url=config["auth_url"],
        token_url=config["token_url"],
        client_id=config["client_id"],
        client_secret=config["client_secret"],
        scopes=config.get("scopes", []),
    )
    try:
        tokens = flow.run()
        _cred_store.store(req.source, "oauth2", {
            **tokens,
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "token_url": config["token_url"],
        })
        _app_auth.log(app_info["app_id"], "oauth", req.source, "success")
        return {"message": f"OAuth flow completed for '{req.source}'."}
    except Exception as e:
        _app_auth.log(app_info["app_id"], "oauth", req.source, "failed", details={"error": str(e)})
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/recipes")
async def list_recipes(source: str | None = None, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    recipes = _recipe_store.list(source_name=source)
    return {"recipes": recipes}


@app.get("/recipes/{recipe_id}")
async def get_recipe(recipe_id: str, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    recipe = _recipe_store.get(recipe_id)
    if recipe is None:
        raise HTTPException(status_code=404, detail=f"Recipe '{recipe_id}' not found.")
    return recipe


@app.post("/webhooks/{source}")
async def receive_webhook(source: str, request: Request):
    body = await request.body()
    headers = dict(request.headers)
    _init()
    result = await handle_webhook(source, body, headers, _registry, _agent, _app_auth)
    return result


def create_app() -> FastAPI:
    """Factory for creating the app (useful for testing)."""
    _init()
    return app
