"""Claude-powered retrieval agent with tool use — the core of datarep."""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import tempfile
from pathlib import Path
from typing import Any

import anthropic

from datarep.config import get_anthropic_api_key, get_anthropic_model
from datarep.credentials import CredentialStore
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry
from datarep.sandbox import execute_code, SandboxResult
from datarep.sync_state import SyncStateManager


AGENT_TOOLS = [
    {
        "name": "list_sources",
        "description": "List all registered data sources and their types.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "inspect_source",
        "description": (
            "Inspect a data source. For local_db: returns table names, schema (PRAGMA table_info), "
            "and sample rows. For rest_api: returns base URL, docs URL, and config. "
            "For local_files: returns file listing."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "source_name": {"type": "string", "description": "Name of the source to inspect."},
            },
            "required": ["source_name"],
        },
    },
    {
        "name": "query_source_db",
        "description": (
            "Run read-only SQL against a local SQLite source database. "
            "Only SELECT, PRAGMA, and WITH statements are allowed. "
            "The database is copied to a temp location first for macOS TCC safety."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "source_name": {"type": "string", "description": "Name of the local_db source."},
                "sql": {"type": "string", "description": "SQL query to run (read-only)."},
            },
            "required": ["source_name", "sql"],
        },
    },
    {
        "name": "run_code",
        "description": (
            "Execute Python code in a sandboxed subprocess. Credentials for the source are injected "
            "as environment variables (DATAREP_ACCESS_TOKEN, DATAREP_API_KEY, DATAREP_CRED_JSON). "
            "Output data by printing JSON lines to stdout. DATAREP_OUTPUT_FILE is also available "
            "as an alternative output path. Network access is restricted to the source's registered domains."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute."},
                "source_name": {
                    "type": "string",
                    "description": "Source name (for credential injection and network allow-list).",
                },
            },
            "required": ["code", "source_name"],
        },
    },
    {
        "name": "get_sync_state",
        "description": "Get the last sync cursor/timestamp for a source.",
        "input_schema": {
            "type": "object",
            "properties": {
                "source_name": {"type": "string"},
            },
            "required": ["source_name"],
        },
    },
    {
        "name": "set_sync_state",
        "description": "Update the sync cursor after a successful retrieval.",
        "input_schema": {
            "type": "object",
            "properties": {
                "source_name": {"type": "string"},
                "recipe_id": {"type": "string"},
                "cursor": {"description": "Opaque cursor value (timestamp, offset, page token, etc.)"},
                "items_retrieved": {"type": "integer"},
            },
            "required": ["source_name", "recipe_id"],
        },
    },
    {
        "name": "save_recipe",
        "description": "Save working retrieval code as a reusable recipe.",
        "input_schema": {
            "type": "object",
            "properties": {
                "recipe_id": {"type": "string", "description": "Unique ID like 'imessage_messages_v1'."},
                "source_name": {"type": "string"},
                "code": {"type": "string", "description": "The Python code that worked."},
                "description": {"type": "string", "description": "What this recipe does."},
            },
            "required": ["recipe_id", "source_name", "code"],
        },
    },
    {
        "name": "load_recipe",
        "description": "Load a previously saved recipe by ID.",
        "input_schema": {
            "type": "object",
            "properties": {
                "recipe_id": {"type": "string"},
            },
            "required": ["recipe_id"],
        },
    },
]

SYSTEM_PROMPT = """\
You are datarep, a data retrieval agent. Your job is to get data from sources on behalf of \
downstream applications. You have tools to inspect sources, query databases, run code, \
and save working recipes.

WORKFLOW:
1. Check if a recipe already exists for this source (load_recipe or check sync_state).
2. If a recipe exists, try running it. If it works, you're done.
3. If no recipe or the recipe fails: inspect the source to understand its structure.
4. For local databases: use query_source_db to explore schema and sample data.
5. For REST APIs: review the config/docs, then write Python code to call the API.
6. Write Python retrieval code and execute it with run_code.
7. If execution fails, READ THE ERROR, adapt your code, and try again. Keep pushing \
until you succeed or hit a truly terminal condition.
8. On success: save the recipe, update sync state, and return the data.

OUTPUT FORMAT:
- Print retrieved data as JSON lines to stdout (one JSON object per line).
- Print progress messages to stderr so they don't mix with data output.

CREDENTIAL ACCESS:
- Credentials are injected as environment variables: DATAREP_ACCESS_TOKEN, DATAREP_API_KEY, \
DATAREP_CRED_JSON (full credential JSON).
- For OAuth APIs, use DATAREP_ACCESS_TOKEN as a Bearer token.
- For API key sources, use DATAREP_API_KEY.

LOCAL DATABASE ACCESS:
- For macOS protected databases (iMessage, etc.), copy the DB to a temp location first \
using shutil.copy2() to bypass TCC restrictions.
- Always use read-only access on source databases.

TERMINAL CONDITIONS (the only reasons to stop):
- Credentials are missing or invalid and cannot be refreshed → return action_required
- Source does not exist
- Source genuinely has no data matching the request
- User explicitly cancels

NEVER give up after a fixed number of retries. Every failure is information to adapt from.\
"""


class RetrievalAgent:
    """The core datarep agent that inspects sources and writes retrieval code."""

    def __init__(
        self,
        conn: sqlite3.Connection,
        registry: SourceRegistry | None = None,
        cred_store: CredentialStore | None = None,
        recipe_store: RecipeStore | None = None,
        sync_state: SyncStateManager | None = None,
    ):
        self._conn = conn
        self._registry = registry or SourceRegistry(conn)
        self._creds = cred_store or CredentialStore(conn)
        self._recipes = recipe_store or RecipeStore(conn)
        self._sync_state = sync_state or SyncStateManager(conn)

        api_key = get_anthropic_api_key()
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY environment variable is required.")
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = get_anthropic_model()

    async def run(self, source_name: str, query: str) -> dict[str, Any]:
        """Run a retrieval request. Returns the result or an action_required response."""
        action_needed = self._creds.needs_action(source_name)
        if action_needed:
            return action_needed

        source = self._registry.get(source_name)
        if source is None:
            return {
                "status": "error",
                "error": f"Source '{source_name}' not found.",
            }

        user_message = self._build_user_message(source, query)
        messages: list[dict[str, Any]] = [{"role": "user", "content": user_message}]

        max_turns = 50
        for _ in range(max_turns):
            response = self._client.messages.create(
                model=self._model,
                max_tokens=8192,
                system=SYSTEM_PROMPT,
                tools=AGENT_TOOLS,
                messages=messages,
            )

            if response.stop_reason == "end_turn":
                final_text = ""
                for block in response.content:
                    if block.type == "text":
                        final_text += block.text
                return {"status": "success", "result": final_text}

            if response.stop_reason == "tool_use":
                messages.append({"role": "assistant", "content": response.content})
                tool_results = []
                for block in response.content:
                    if block.type == "tool_use":
                        result = await self._handle_tool(block.name, block.input)

                        if isinstance(result, dict) and result.get("status") == "action_required":
                            return result

                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": json.dumps(result) if not isinstance(result, str) else result,
                        })
                messages.append({"role": "user", "content": tool_results})
            else:
                return {"status": "error", "error": f"Unexpected stop reason: {response.stop_reason}"}

        return {"status": "error", "error": "Agent exceeded maximum turn limit."}

    async def run_recipe(self, recipe_id: str) -> dict[str, Any]:
        """Run a saved recipe directly (no LLM call)."""
        recipe = self._recipes.get(recipe_id)
        if recipe is None:
            return {"status": "error", "error": f"Recipe '{recipe_id}' not found."}

        source_name = recipe["source_name"]
        source = self._registry.get(source_name)
        if source is None:
            return {"status": "error", "error": f"Source '{source_name}' not found."}

        action_needed = self._creds.needs_action(source_name)
        if action_needed:
            return action_needed

        cred_env = self._creds.get_for_injection(source_name)
        allowed_domains = self._registry.get_allowed_domains(source_name)
        source_path = source["config"].get("path")

        result = await execute_code(
            code=recipe["code"],
            env=cred_env,
            allowed_domains=allowed_domains,
            source_path=source_path,
        )

        self._recipes.record_use(recipe_id)

        if result.success:
            self._sync_state.set(
                source_name=source_name,
                recipe_id=recipe_id,
                status="success",
            )
            return {"status": "success", "stdout": result.stdout, "stderr": result.stderr}
        else:
            return {
                "status": "error",
                "error": result.stderr or f"Recipe exited with code {result.exit_code}",
                "stdout": result.stdout,
            }

    def _build_user_message(self, source: dict[str, Any], query: str) -> str:
        parts = [
            f"Retrieve data from source '{source['name']}' (type: {source['source_type']}).",
            f"Request: {query}",
            f"Source config: {json.dumps(source['config'], indent=2)}",
        ]

        state = self._sync_state.get(source["name"])
        if state:
            parts.append(f"Last sync state: {json.dumps(state)}")

        existing_recipe = self._recipes.find_for_source(source["name"])
        if existing_recipe:
            parts.append(
                f"Existing recipe '{existing_recipe['id']}' available "
                f"(used {existing_recipe['times_used']} times). "
                f"Try loading and running it first."
            )

        return "\n\n".join(parts)

    async def _handle_tool(self, tool_name: str, tool_input: dict[str, Any]) -> Any:
        handler = {
            "list_sources": self._tool_list_sources,
            "inspect_source": self._tool_inspect_source,
            "query_source_db": self._tool_query_source_db,
            "run_code": self._tool_run_code,
            "get_sync_state": self._tool_get_sync_state,
            "set_sync_state": self._tool_set_sync_state,
            "save_recipe": self._tool_save_recipe,
            "load_recipe": self._tool_load_recipe,
        }.get(tool_name)

        if handler is None:
            return {"error": f"Unknown tool: {tool_name}"}
        return await handler(tool_input)

    async def _tool_list_sources(self, _input: dict) -> Any:
        return self._registry.list()

    async def _tool_inspect_source(self, tool_input: dict) -> Any:
        name = tool_input["source_name"]
        source = self._registry.get(name)
        if source is None:
            return {"error": f"Source '{name}' not found."}

        result: dict[str, Any] = {"source": source}

        if source["source_type"] == "local_db":
            db_path = source["config"].get("path", "")
            expanded = os.path.expanduser(db_path)
            if not os.path.exists(expanded):
                return {
                    "status": "action_required",
                    "action_type": "os_permission",
                    "source": name,
                    "explanation": f"Database file not found at {expanded}. It may require Full Disk Access.",
                    "steps": [
                        "Open System Preferences > Privacy & Security > Full Disk Access",
                        "Enable access for the application",
                    ],
                    "deep_link": "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles",
                    "retryable": True,
                    "context": {"attempted_path": expanded},
                }

            try:
                tmp_path = _copy_db_to_temp(expanded)
                conn = sqlite3.connect(tmp_path)
                conn.row_factory = sqlite3.Row
                tables = [
                    r[0]
                    for r in conn.execute(
                        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
                    ).fetchall()
                ]
                schema_info = {}
                for table in tables[:20]:
                    cols = conn.execute(f"PRAGMA table_info('{table}')").fetchall()
                    sample = conn.execute(f"SELECT * FROM '{table}' LIMIT 3").fetchall()
                    schema_info[table] = {
                        "columns": [dict(c) for c in cols],
                        "sample_rows": [dict(r) for r in sample],
                        "row_count": conn.execute(f"SELECT COUNT(*) FROM '{table}'").fetchone()[0],
                    }
                conn.close()
                os.unlink(tmp_path)
                result["tables"] = tables
                result["schema"] = schema_info
            except Exception as e:
                if "Operation not permitted" in str(e) or "not authorized" in str(e):
                    return {
                        "status": "action_required",
                        "action_type": "os_permission",
                        "source": name,
                        "explanation": f"Cannot read {expanded}. macOS Full Disk Access is required.",
                        "steps": [
                            "Open System Preferences > Privacy & Security > Full Disk Access",
                            "Enable access for the application",
                        ],
                        "deep_link": "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles",
                        "retryable": True,
                        "context": {"attempted_path": expanded, "error": str(e)},
                    }
                result["error"] = str(e)

        elif source["source_type"] == "rest_api":
            result["note"] = "Use run_code to call this API. Credentials will be injected as env vars."

        elif source["source_type"] == "local_files":
            file_path = source["config"].get("path", "")
            expanded = os.path.expanduser(file_path)
            if os.path.isdir(expanded):
                try:
                    files = os.listdir(expanded)[:50]
                    result["files"] = files
                    result["total_files"] = len(os.listdir(expanded))
                except PermissionError:
                    return {
                        "status": "action_required",
                        "action_type": "os_permission",
                        "source": name,
                        "explanation": f"Cannot list files at {expanded}. Permission is required.",
                        "retryable": True,
                        "context": {"attempted_path": expanded},
                    }

        return result

    async def _tool_query_source_db(self, tool_input: dict) -> Any:
        name = tool_input["source_name"]
        sql = tool_input["sql"]

        sql_upper = sql.strip().upper()
        if not any(sql_upper.startswith(kw) for kw in ("SELECT", "PRAGMA", "WITH")):
            return {"error": "Only SELECT, PRAGMA, and WITH statements are allowed."}

        source = self._registry.get(name)
        if source is None:
            return {"error": f"Source '{name}' not found."}
        if source["source_type"] != "local_db":
            return {"error": f"Source '{name}' is not a local_db."}

        db_path = os.path.expanduser(source["config"].get("path", ""))
        try:
            tmp_path = _copy_db_to_temp(db_path)
            conn = sqlite3.connect(tmp_path)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql).fetchall()
            result = [dict(r) for r in rows[:500]]
            conn.close()
            os.unlink(tmp_path)
            return {"rows": result, "count": len(result), "truncated": len(rows) > 500}
        except Exception as e:
            if "Operation not permitted" in str(e):
                return {
                    "status": "action_required",
                    "action_type": "os_permission",
                    "source": name,
                    "explanation": f"Cannot read database. macOS Full Disk Access is required.",
                    "retryable": True,
                    "context": {"error": str(e)},
                }
            return {"error": str(e)}

    async def _tool_run_code(self, tool_input: dict) -> Any:
        code = tool_input["code"]
        source_name = tool_input.get("source_name", "")

        env = {}
        source_path = None
        allowed_domains: list[str] = []

        if source_name:
            env = self._creds.get_for_injection(source_name)
            source = self._registry.get(source_name)
            if source:
                source_path = source["config"].get("path")
                if source_path:
                    source_path = os.path.expanduser(source_path)
                allowed_domains = self._registry.get_allowed_domains(source_name)
                env["DATAREP_SOURCE_CONFIG"] = json.dumps(source["config"])

        result = await execute_code(
            code=code,
            env=env,
            allowed_domains=allowed_domains,
            source_path=source_path,
        )
        return result.to_dict()

    async def _tool_get_sync_state(self, tool_input: dict) -> Any:
        state = self._sync_state.get(tool_input["source_name"])
        return state or {"message": "No sync state found for this source."}

    async def _tool_set_sync_state(self, tool_input: dict) -> Any:
        self._sync_state.set(
            source_name=tool_input["source_name"],
            recipe_id=tool_input["recipe_id"],
            cursor=tool_input.get("cursor"),
            items_retrieved=tool_input.get("items_retrieved", 0),
        )
        return {"message": "Sync state updated."}

    async def _tool_save_recipe(self, tool_input: dict) -> Any:
        return self._recipes.save(
            recipe_id=tool_input["recipe_id"],
            source_name=tool_input["source_name"],
            code=tool_input["code"],
            description=tool_input.get("description"),
        )

    async def _tool_load_recipe(self, tool_input: dict) -> Any:
        recipe = self._recipes.get(tool_input["recipe_id"])
        return recipe or {"error": f"Recipe '{tool_input['recipe_id']}' not found."}


def _copy_db_to_temp(db_path: str) -> str:
    """Copy a database file to /tmp for TCC-safe read access."""
    tmp_dir = tempfile.mkdtemp(prefix="datarep_db_")
    basename = os.path.basename(db_path)
    tmp_path = os.path.join(tmp_dir, basename)
    shutil.copy2(db_path, tmp_path)
    wal_path = db_path + "-wal"
    if os.path.exists(wal_path):
        shutil.copy2(wal_path, tmp_path + "-wal")
    shm_path = db_path + "-shm"
    if os.path.exists(shm_path):
        shutil.copy2(shm_path, tmp_path + "-shm")
    return tmp_path
