"""Visualization tool for tiatoolbox."""
