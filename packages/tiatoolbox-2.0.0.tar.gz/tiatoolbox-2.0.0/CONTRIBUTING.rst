.. highlight:: shell

=============
Contributing
=============

Contributions are welcome and greatly appreciated! Every little bit helps, and credit will always be given.

You can contribute in many ways:

Types of Contributions
----------------------

Report Bugs
~~~~~~~~~~~

Report bugs at https://github.com/TissueImageAnalytics/tiatoolbox/issues.

If you are reporting a bug, please include:

* Your operating system name and version.
* Any details about your local setup that might be helpful in troubleshooting.
* Detailed steps to reproduce the bug.

Fix Bugs
~~~~~~~~

Look through the GitHub issues for bugs. Anything tagged with "bug" and "help wanted" is open to whoever wants to implement it.

Implement Features
~~~~~~~~~~~~~~~~~~

Look through the GitHub issues for features. Anything tagged with "enhancement" and "help wanted" is open to whoever wants to implement it.

Write Documentation
~~~~~~~~~~~~~~~~~~~

TIA Toolbox could always use more documentation, whether as part of the official TIA Toolbox docs, in docstrings, or even on the web in blog posts, articles, and such.

Submit Feedback
~~~~~~~~~~~~~~~

The best way to send feedback is to file an issue at https://github.com/TissueImageAnalytics/tiatoolbox/issues.

If you are proposing a feature:

* Explain in detail how it would work.
* Keep the scope as narrow as possible to make it easier to implement.
* Remember that this is a volunteer-driven project, and contributions are welcome :)

Get Started!
------------

Ready to contribute? Here's how to set up ``tiatoolbox`` for local development.

1. Fork the ``tiatoolbox`` repo on GitHub.
2. Clone your fork locally::

    $ git clone git@github.com:your_name_here/tiatoolbox.git

3. Install your local copy into a virtual environment. Assuming you have virtualenvwrapper installed, this is how you set up your fork for local development::

    $ mkvirtualenv tiatoolbox
    $ cd tiatoolbox/
    $ python setup.py develop

4. Create a branch for local development::

    $ git checkout -b name-of-your-bugfix-or-feature

   Now you can make your changes locally.

5. When you're done making changes, check that your changes pass pre-commit and the tests::

    $ pre-commit run --all-files
    $ python setup.py test or pytest

   To get `pre-commit <https://pre-commit.com/#install>`_, just pip install it into your virtual environment using::

    $ pip install pre-commit

   To set up the git hook for pre-commit, run the following command after installing pre-commit::

    $ pre-commit install

6. Commit your changes and push your branch to GitHub::

    $ git add .
    $ git commit -m "Your detailed description of your changes."
    $ git push origin name-of-your-bugfix-or-feature

7. Submit a pull request through the GitHub website.

Pull Request Guidelines
-----------------------

Before you submit a pull request, check that it meets these guidelines:

1. The pull request should include tests.
2. If the pull request adds functionality, the docs should be updated. Put your new functionality into a function with a docstring, and add the feature to the pull request description.
3. The pull request should work for Python 3.10, 3.11, 3.12 and 3.13, and for PyPy. Check https://github.com/TissueImageAnalytics/tiatoolbox/actions/workflows/python-package.yml and make sure that the tests pass for all supported Python versions.

Tips
----

To run a subset of tests::

    $ pytest tests.test_tiatoolbox

Deploying
---------

A reminder for the maintainers on how to deploy.
Make sure all your changes are committed (including an entry in HISTORY.rst).
Then run::

    $ poetry version patch  # use: "poetry version --help" for other options
    $ git push
    $ git push --tags

GitHub Actions will then deploy to PyPI if tests pass.
