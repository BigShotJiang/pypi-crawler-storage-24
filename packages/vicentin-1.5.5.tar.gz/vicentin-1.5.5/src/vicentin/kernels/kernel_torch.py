from typing import Callable, Optional
from abc import ABC

import torch
import torch.nn as nn
from vicentin.utils.logging import debug


class KernelBackendTorch(nn.Module, ABC):
    def __init__(
        self,
        func: Callable,
        X: Optional[torch.Tensor] = None,
        alpha: float = 1e-6,
        chunk_size: Optional[int] = None,
        cache_size: int = 1000,
    ):
        super().__init__()

        if X is None:
            X = torch.empty((0, 0))

        self.register_buffer("_X", X)
        self._N = int(X.shape[0])

        self.func = func
        self.alpha = alpha
        self.chunk_size = chunk_size
        self.cache_size = cache_size
        self._cache = {}

        self._full_K = None

    @property
    def X(self) -> torch.Tensor:
        if isinstance(self._X, torch.Tensor):
            return self._X
        raise RuntimeError("Buffer _X is not a tensor.")

    @property
    def N(self) -> int:
        return self._N

    def _get_full_matrix(self) -> torch.Tensor:
        if self._full_K is None:
            debug(
                f"Torch Backend: Instantiating full {self.N}x{self.N} matrix on {self.X.device}."
            )
            K = self.func(self.X, self.X)
            if self.alpha > 0:
                K.diagonal().add_(self.alpha)
            self._full_K = K
        return self._full_K

    def forward(
        self, x: torch.Tensor, y: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        n_x = x.shape[0]
        y_eval = y if y is not None else self.X
        n_y = y_eval.shape[0]

        if self.chunk_size is None:
            K = self.func(x, y_eval)
            if self.alpha > 0 and (y is None or x is y):
                K.diagonal().add_(self.alpha)
            return K

        chunk = self.chunk_size
        debug(
            f"Torch Backend: Evaluating {n_x}x{n_y} matrix in chunks of {chunk}."
        )
        result = torch.zeros((n_x, n_y), device=x.device, dtype=x.dtype)

        for i in range(0, n_x, chunk):
            end_i = min(i + chunk, n_x)
            x_chunk = x[i:end_i]

            for j in range(0, n_y, chunk):
                end_j = min(j + chunk, n_y)
                y_chunk = y_eval[j:end_j]

                K_block = self.func(x_chunk, y_chunk)

                if self.alpha > 0 and (y is None or x is y):
                    rel_start = max(i, j)
                    rel_end = min(end_i, end_j)
                    for k in range(rel_start, rel_end):
                        K_block[k - i, k - j] += self.alpha

                result[i:end_i, j:end_j] = K_block

        return result

    def __getitem__(self, key):
        with torch.no_grad():
            if isinstance(key, int):
                if key not in self._cache:
                    if len(self._cache) >= self.cache_size:
                        self._cache.pop(next(iter(self._cache)))

                    row = self.forward(self.X[key : key + 1], self.X).view(-1)
                    self._cache[key] = row
                return self._cache[key]

            if self.chunk_size is None:
                return self._get_full_matrix()[key]

            if isinstance(key, tuple):
                row_idx, col_idx = key
                x_eval = self.X[row_idx]
                y_eval = self.X[col_idx]
                if x_eval.ndim == 1:
                    x_eval = x_eval.unsqueeze(0)
                if y_eval.ndim == 1:
                    y_eval = y_eval.unsqueeze(0)
                return self.forward(x_eval, y_eval)

            x_eval = self.X[key]
            if x_eval.ndim == 1:
                x_eval = x_eval.unsqueeze(0)
            return self.forward(x_eval, self.X)

    def __matmul__(self, v: torch.Tensor) -> torch.Tensor:
        if self.chunk_size is None:
            return torch.matmul(self._get_full_matrix(), v)

        debug(
            f"Torch Backend: Matmul ({self.N}x{self.N}) in chunks of {self.chunk_size}."
        )
        N = self.N
        D = v.shape[1] if v.ndim > 1 else 1
        v_reshaped = v.view(N, D)
        result = torch.zeros((N, D), device=self.X.device, dtype=self.X.dtype)
        chunk = self.chunk_size

        for i in range(0, N, chunk):
            end_i = min(i + chunk, N)
            x_chunk = self.X[i:end_i]

            for j in range(0, N, chunk):
                end_j = min(j + chunk, N)
                y_chunk = self.X[j:end_j]
                v_chunk = v_reshaped[j:end_j]

                K_block = self.func(x_chunk, y_chunk)
                result[i:end_i] += torch.mm(K_block, v_chunk)

        out = result + self.alpha * v_reshaped
        return out.view(v.shape)

    def apply_v(self, X: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        N_new = X.shape[0]
        D_v = v.shape[1] if v.ndim > 1 else 1
        v_reshaped = v.view(self.N, D_v)
        result = torch.zeros((N_new, D_v), device=X.device, dtype=X.dtype)
        chunk = self.chunk_size if self.chunk_size is not None else N_new

        if self.chunk_size:
            debug(
                f"Torch Backend: Applying kernel operator on {X.device} (chunked)."
            )

        for i in range(0, N_new, chunk):
            end_i = min(i + chunk, N_new)
            x_chunk = X[i:end_i]

            for j in range(0, self.N, chunk):
                end_j = min(j + chunk, self.N)
                y_chunk = self.X[j:end_j]
                v_chunk = v_reshaped[j:end_j]

                K_block = self.func(x_chunk, y_chunk)
                result[i:end_i] += torch.mm(K_block, v_chunk)

        if self.alpha > 0 and X is self.X:
            result += self.alpha * v_reshaped

        return result.view(X.shape[0], -1) if v.ndim > 1 else result.view(-1)

    def trace(self):
        if self.chunk_size is None:
            return float(torch.trace(self._get_full_matrix()).item())

        debug("Torch Backend: Computing trace via chunked diagonals.")
        trace_val = 0
        for i in range(0, self.N, self.chunk_size):
            end = min(i + self.chunk_size, self.N)
            x_chunk = self.X[i:end]

            K_diag = torch.diagonal(self.func(x_chunk, x_chunk))
            trace_val += torch.sum(K_diag).item() + (end - i) * self.alpha

        return float(trace_val)
