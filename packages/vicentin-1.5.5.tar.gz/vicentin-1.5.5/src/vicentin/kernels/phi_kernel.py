from typing import Any, Callable, Optional
from vicentin.kernels import LinearKernel
from vicentin.utils.logging import debug


class PhiKernel(LinearKernel):
    def __init__(
        self, phi: Callable, X: Optional[Any] = None, **kwargs
    ) -> None:
        self.phi = phi
        debug(
            f"PhiKernel: applying projection function {getattr(phi, '__name__', 'phi')}"
        )
        phi_X = self.phi(X) if X is not None else None

        super().__init__(phi_X, **kwargs)

    def _compute(self, x: Any, y: Optional[Any] = None):
        x_phi = self.phi(x)
        y_phi = self.phi(y) if y is not None else None

        return super()._compute(x_phi, y_phi)
