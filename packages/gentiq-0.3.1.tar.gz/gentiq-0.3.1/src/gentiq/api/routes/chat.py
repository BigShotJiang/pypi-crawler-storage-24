import asyncio
import base64
import logging
import mimetypes
from datetime import UTC, datetime
from http import HTTPStatus
from json import dumps
from typing import Annotated, Any

from fastapi import APIRouter, BackgroundTasks, Depends, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse
from pydantic import ValidationError
from pydantic_ai.ui import SSE_CONTENT_TYPE
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from pydantic_ai.ui.vercel_ai.request_types import FileUIPart
from pydantic_ai.ui.vercel_ai.response_types import DataChunk, TextDeltaChunk

from ...agents.title_agent import generate_title
from ...constants import MAX_ATTACHMENT_SIZE
from ...database import UserDocument
from ..dependencies import Database, Storage, authenticate_with_bearer, get_database, get_storage
from ..inputs import MessageFeedbackInput, ThreadUpdateInput


router = APIRouter()
logger = logging.getLogger(__name__)


# ===========================================================================
# 1. Message Parsing Helpers
# ===========================================================================


def _extract_text_from_message(msg: Any) -> str:
    """Extract plain text from a Vercel AI SDK message object (dict or Pydantic model)."""
    if isinstance(msg, dict):
        msg_content = msg.get("content", "")
        if isinstance(msg_content, list):
            return " ".join(
                str(p.get("text", "")) for p in msg_content if isinstance(p, dict) and p.get("type") == "text"
            )
        return str(msg_content)
    elif hasattr(msg, "parts") and isinstance(msg.parts, list):
        parts_content = []
        for part in msg.parts:
            if hasattr(part, "text"):
                parts_content.append(str(part.text))
            elif hasattr(part, "content"):
                parts_content.append(str(part.content))
            elif isinstance(part, dict):
                parts_content.append(str(part.get("text", part.get("content", ""))))
        return " ".join(parts_content)
    elif hasattr(msg, "content"):
        return str(msg.content)
    return str(msg)


def _get_message_role(msg: Any) -> str:
    """Get role from a message object."""
    if isinstance(msg, dict):
        return msg.get("role", "user")
    elif hasattr(msg, "role"):
        return str(msg.role)
    return "user"


# ===========================================================================
# 2. Attachments & Storage Helpers
# ===========================================================================


def _decode_data_uri(data_uri: str) -> tuple[bytes, str] | None:
    """Decode a data URI into raw bytes and its media type. Returns None on failure."""
    try:
        if not data_uri.startswith("data:"):
            return None
        header, encoded = data_uri.split(",", 1)
        meta = header[len("data:") :]
        media_type = meta.split(";")[0] if ";base64" in meta else meta
        content = base64.b64decode(encoded)
        return content, media_type
    except Exception as e:
        logger.warning(f"Failed to decode data URI: {e}")
        return None


def _attachment_key(
    user_id: str, thread_id: str, msg_id: str, index: int, media_type: str, filename: str | None
) -> str:
    ext = ""
    if filename and "." in filename:
        ext = "." + filename.rsplit(".", 1)[-1]
    elif not ext:
        ext = mimetypes.guess_extension(media_type) or ""
    return f"attachments/{user_id}/{thread_id}/{msg_id}/{index}{ext}"


def _upload_file_parts(
    msg: Any,
    storage: Storage,
    database: Database,
    user_id: str,
    thread_id: str,
    msg_id: str,
) -> list[dict]:
    """
    Inspect message parts for FileUIParts, upload binaries to Minio, and
    return a parts list safe to store in MongoDB (no raw base64 blobs).
    """
    parts: list[dict] = []
    file_index = 0

    raw_parts = []
    if hasattr(msg, "parts") and isinstance(msg.parts, list):
        raw_parts = msg.parts
    elif isinstance(msg, dict) and isinstance(msg.get("parts"), list):
        raw_parts = msg["parts"]

    def _handle_data_uri(url: str, media_type: str, filename: str | None) -> bool:
        nonlocal file_index
        decoded = _decode_data_uri(url)
        if not decoded:
            return False

        content, actual_media_type = decoded
        if len(content) > MAX_ATTACHMENT_SIZE:
            logger.warning(f"Attachment too large ({len(content)} bytes), skipping")
            return False

        object_name = _attachment_key(user_id, thread_id, msg_id, file_index, actual_media_type, filename)
        try:
            storage.insert_attachment(content=content, object_name=object_name)
            try:
                database.save_attachment(
                    attachment_id=object_name,
                    thread_id=thread_id,
                    user_id=user_id,
                    media_type=actual_media_type,
                    filename=filename,
                )
            except Exception as db_err:
                logger.warning(f"Failed to save attachment metadata: {db_err}")

            parts.append({
                "type": "file",
                "object_name": object_name,
                "media_type": actual_media_type,
                "mediaType": actual_media_type,
                "filename": filename,
            })
            file_index += 1
            return True
        except Exception as e:
            logger.error(f"Failed to upload attachment to Minio: {e}")
            return False

    for part in raw_parts:
        if isinstance(part, FileUIPart):
            if part.url.startswith("data:"):
                _handle_data_uri(part.url, part.media_type, part.filename)
            else:
                parts.append({
                    "type": "file",
                    "url": part.url,
                    "media_type": part.media_type,
                    "mediaType": part.media_type,
                    "filename": part.filename,
                })
                file_index += 1
        elif isinstance(part, dict) and part.get("type") == "file":
            url = part.get("url", "")
            media_type = part.get("media_type") or part.get("mediaType") or "application/octet-stream"
            filename = part.get("filename")

            if url.startswith("data:"):
                _handle_data_uri(url, media_type, filename)
            else:
                parts.append({
                    "type": "file",
                    "url": url,
                    "media_type": media_type,
                    "mediaType": media_type,
                    "filename": filename,
                })
                file_index += 1

    return parts


# ===========================================================================
# 3. Chat Flow Handlers
# ===========================================================================


@router.post("/chat/feedback", tags=["Chat"])
async def save_feedback(
    data: MessageFeedbackInput,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    database: Annotated[Database, Depends(get_database)],
) -> Response:
    """Save user feedback for an assistant message."""
    try:
        await database.save_feedback(
            thread_id=data.thread_id,
            item_ids=[data.message_id],
            sentiment=data.sentiment,
            user_id=user.id,
        )
        return JSONResponse({"status": "success"}, status_code=HTTPStatus.OK)
    except Exception as e:
        logger.error(f"Error saving feedback: {e}")
        return JSONResponse(
            {"error": f"Failed to save feedback: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


def _handle_pre_stream_user_message(
    run_input: Any,
    thread_id: str,
    user_id: str,
    database: Database,
    storage: Storage,
) -> None:
    try:
        if run_input.messages:
            # The Vercel AI SDK sends the full message history on every request.
            # Find the last user message — that is the new one for this turn.
            last_user_msg = next(
                (msg for msg in reversed(run_input.messages) if _get_message_role(msg) == "user"), None
            )

            # Thread title from the first user message
            first_msg_text = ""
            for msg in run_input.messages:
                if _get_message_role(msg) == "user":
                    first_msg_text = _extract_text_from_message(msg).strip()
                    break

            if first_msg_text:
                title = (first_msg_text[:35] + "...") if len(first_msg_text) > 35 else first_msg_text
                database.update_thread_info(thread_id, title=title, user_id=user_id)
            else:
                database.update_thread_info(thread_id, user_id=user_id)

            # Save the latest user message to thread_items
            if last_user_msg is not None:
                user_text = _extract_text_from_message(last_user_msg).strip()
                # Use the id from the request if provided (Vercel AI SDK sends it)
                provided_id = None
                if isinstance(last_user_msg, dict):
                    provided_id = last_user_msg.get("id")
                elif hasattr(last_user_msg, "id"):
                    provided_id = last_user_msg.id

                user_msg_id = provided_id or f"msg_user_{thread_id}_{int(datetime.now(UTC).timestamp() * 1000)}"

                # Check for retry: if this message ID already exists, clear everything after it
                existing_msg = database.fetch_thread_item(thread_id, user_msg_id)
                if existing_msg and "created_at" in existing_msg:
                    # It's a retry. We need to preserve matching behavior:
                    # delete responses and subsequent messages to keep history clean.
                    deleted_count = database.clear_thread_items_after(thread_id, existing_msg["created_at"])
                    logger.info(f"Retry detected for message {user_msg_id}. Cleared {deleted_count} forward items.")

                # Extract and upload any attached files to Minio
                file_parts = _upload_file_parts(
                    msg=last_user_msg,
                    storage=storage,
                    database=database,
                    user_id=user_id,
                    thread_id=thread_id,
                    msg_id=user_msg_id,
                )

                text_part = {"type": "text", "text": user_text} if user_text else None
                parts = ([text_part] if text_part else []) + file_parts

                database.save_thread_item(
                    thread_id,
                    {
                        "id": user_msg_id,
                        "role": "user",
                        "content": user_text,
                        "parts": parts,
                    },
                )
        else:
            database.update_thread_info(thread_id, user_id=user_id)
    except Exception as e:
        logger.error(f"Error saving chat pre-stream: {e}")


async def _handle_post_stream_assistant_message(
    run_result_holder: list[Any],
    run_input: Any,
    # adapter is now Generic[Any] or we just use it without explicit type here if it's too complex
    adapter: VercelAIAdapter[Any],
    thread_id: str,
    user_id: str,
    assistant_content: str,
    database: Database,
    streamed_id: str | None = None,
    explicit_asst_id: str | None = None,
    assistant_parts: list[dict] | None = None,
) -> str | None:

    try:
        if run_result_holder or assistant_content:
            run_result = run_result_holder[0] if run_result_holder else None

            # Convert PydanticAI messages to Vercel AI SDK format
            if run_result:
                ui_messages = adapter.dump_messages(run_result.new_messages())
            else:
                # If we don't have a run_result, we might still have assistant_content from a partial stream
                ui_messages = []
            all_asst_parts = []
            asst_id = explicit_asst_id or streamed_id

            for ui_msg in ui_messages:
                if ui_msg.role == "user":
                    continue  # User messages are already saved at the beginning of the turn

                if ui_msg.role == "assistant":
                    if not asst_id:
                        asst_id = explicit_asst_id or streamed_id or ui_msg.id
                    # Convert UIMessagePart objects to dicts for MongoDB
                    all_asst_parts.extend([p.model_dump(mode="json") for p in ui_msg.parts])

            if asst_id:
                # Merge accumulated parts from the stream if we don't have structured parts from RunResult
                if not all_asst_parts and assistant_parts:
                    all_asst_parts = assistant_parts

                # Fallback to plain text if we still have nothing but have content
                if not all_asst_parts and assistant_content:
                    all_asst_parts = [{"type": "text", "text": assistant_content}]

                database.save_thread_item(
                    thread_id,
                    {
                        "id": asst_id,
                        "role": "assistant",
                        "content": assistant_content,
                        "parts": all_asst_parts,
                    },
                )
            usage = None
            if run_result:
                usage = run_result.usage() if callable(getattr(run_result, "usage", None)) else None
            if usage:
                await database.update_usage(user_id=user_id, thread_id=thread_id, usage=usage)

        # Generate AI title if not already finalized
        thread = database.fetch_thread(thread_id)
        is_finalized = thread.get("title_finalized", False) if thread else False

        user_msg_count = sum(1 for m in run_input.messages if _get_message_role(m) == "user")
        if not is_finalized and user_msg_count <= 3 and assistant_content:
            first_msg_text = ""
            for msg in run_input.messages:
                if _get_message_role(msg) == "user":
                    first_msg_text = _extract_text_from_message(msg).strip()
                    break
            if first_msg_text:
                return await generate_title(first_msg_text, assistant_content, database, thread_id)
    except Exception as e:
        logger.error(f"Error saving chat history: {e}")
    return None


# ===========================================================================
# 4. Endpoints: Chat Core
# ===========================================================================


@router.post("/chat", tags=["Chat"])
@router.post("/chat/{agent_name}", tags=["Chat"])
async def chat(
    request: Request,
    background_tasks: BackgroundTasks,
    database: Annotated[Database, Depends(get_database)],
    storage: Annotated[Storage, Depends(get_storage)],
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    agent_name: str = "default",
) -> Response:
    """Chat endpoint. Streams responses tailored for the Vercel AI SDK."""
    accept = request.headers.get("accept", SSE_CONTENT_TYPE)
    try:
        body = await request.body()
        try:
            from json import loads

            body_dict = loads(body)
            # Create a clean version of the body to avoid extra fields issues (pydantic-ai uses extra='forbid')
            clean_messages = []

            for msg in body_dict.get("messages", []):
                # pydantic-ai's UIMessage forbids 'content' and requires 'parts'
                raw_content = msg.get("content")
                raw_parts = msg.get("parts") or []

                # Convert content to parts if parts are missing
                if not raw_parts and raw_content:
                    raw_parts = [{"type": "text", "text": str(raw_content)}]

                clean_parts = []
                for part in raw_parts:
                    if not isinstance(part, dict):
                        clean_parts.append(part)
                        continue

                    p_type = part.get("type")
                    if p_type == "file":
                        object_name = part.pop("object_name", None)
                        # Map camelCase to snake_case
                        m_type = part.get("media_type") or part.get("mediaType") or "application/octet-stream"
                        url = part.get("url")

                        if object_name:
                            try:
                                content = storage.download_attachment(object_name)
                                encoded = base64.b64encode(content).decode("ascii")
                                url = f"data:{m_type};base64,{encoded}"
                            except Exception as dl_err:
                                logger.warning(f"Failed to fetch attachment {object_name}: {dl_err}")
                                clean_parts.append({
                                    "type": "text",
                                    "text": f"[Attachment {part.get('filename', 'file')} unavailable]",
                                })
                                continue

                        clean_parts.append({
                            "type": "file",
                            "media_type": m_type,
                            "filename": part.get("filename"),
                            "url": url,
                        })
                    elif p_type == "text":
                        clean_parts.append({
                            "type": "text",
                            "text": part.get("text"),
                            "state": part.get("state"),
                        })
                    elif p_type == "reasoning":
                        clean_parts.append({
                            "type": "reasoning",
                            "text": part.get("text") or part.get("reasoning"),
                            "state": part.get("state"),
                        })
                    else:
                        # For other types, ideally we should also strip unknown fields
                        # but we'll pass them through if they are tool calls/results
                        clean_parts.append(part)

                clean_messages.append({
                    "id": msg.get("id"),
                    "role": msg.get("role"),
                    "metadata": msg.get("metadata", {}),
                    "parts": clean_parts,
                })

            # Preservation of root fields is critical for build_run_input
            clean_body = {
                "messages": clean_messages,
                "trigger": body_dict.get("trigger"),
                "id": body_dict.get("id"),
                "message_id": body_dict.get("message_id") or body_dict.get("messageId"),
            }
            # Remove None values to avoid extra fields warning/error
            clean_body = {k: v for k, v in clean_body.items() if v is not None}
            body = dumps(clean_body).encode("utf-8")
        except Exception as preprocess_err:
            logger.warning(f"Failed to pre-process body for object_name removal: {preprocess_err}")

        run_input = VercelAIAdapter.build_run_input(body)
    except ValidationError as e:
        return Response(
            content=dumps(e.json()),
            media_type="application/json",
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
        )

    # Resolve agent from registry
    agents = request.app.state.agents
    agent = agents.get(agent_name)
    if not agent:
        return JSONResponse(
            {"error": f"Agent '{agent_name}' not found"},
            status_code=HTTPStatus.NOT_FOUND,
        )

    deps = request.app.state.create_agent_deps(user)

    # 1. Verification
    if not database.check_user_balance(user.id):
        return JSONResponse(
            {"error": "Insufficient balance. Please recharge your account to continue."},
            status_code=HTTPStatus.PAYMENT_REQUIRED,
        )

    adapter = VercelAIAdapter(agent=agent, run_input=run_input, accept=accept)
    thread_id = request.headers.get("X-Thread-Id")

    # 2. Pre-stream User Message Processing
    if thread_id:
        _handle_pre_stream_user_message(
            run_input=run_input,
            thread_id=thread_id,
            user_id=user.id,
            database=database,
            storage=storage,
        )

    # 3. Stream Generator Setup
    run_result_holder: list[Any] = []

    async def on_complete(result: Any):
        run_result_holder.append(result)
        return
        yield  # make it an async generator

    async def save_history_stream():
        assistant_content: str = ""
        assistant_parts: list[dict] = []
        streamed_id: str | None = None

        explicit_asst_id = f"msg_asst_{thread_id}_{int(datetime.now(UTC).timestamp() * 1000)}" if thread_id else None
        if explicit_asst_id:
            yield DataChunk(data=[{"message_id": explicit_asst_id}], type="data-message-id")

        async def get_next(iterator):
            return await anext(iterator)

        saved = False

        try:
            stream_iter = aiter(adapter.run_stream(deps=deps, on_complete=on_complete))
            event_stream_iter = aiter(deps.stream_events())

            stream_task = asyncio.create_task(get_next(stream_iter))
            queue_task = asyncio.create_task(get_next(event_stream_iter))

            pending = {stream_task, queue_task}

            while pending:
                done, _ = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)

                if stream_task in done:
                    try:
                        event = stream_task.result()
                        if hasattr(event, "id") and streamed_id is None:
                            streamed_id = event.id

                        if isinstance(event, TextDeltaChunk):
                            assistant_content += event.delta
                            # Also track as a part for fallback
                            if not assistant_parts or assistant_parts[-1]["type"] != "text":
                                assistant_parts.append({"type": "text", "text": event.delta})
                            else:
                                assistant_parts[-1]["text"] += event.delta
                        elif hasattr(event, "model_dump"):
                            # Other chunks like reasoning/tool-calls
                            event_data = event.model_dump(mode="json")
                            if event_data.get("type") in ["reasoning", "tool-call", "tool-invocation", "tool-result"]:
                                assistant_parts.append(event_data)
                        yield event
                        stream_task = asyncio.create_task(get_next(stream_iter))
                        pending.add(stream_task)
                    except (StopAsyncIteration, GeneratorExit):
                        pending.remove(stream_task)
                        if deps._event_queue:
                            await deps._event_queue.put(None)
                        break

                if queue_task in done:
                    try:
                        msg = queue_task.result()
                        # stream message wrapped in DataChunk
                        yield DataChunk(data=[msg.model_dump(mode="json")], type="data-progress-update")
                        queue_task = asyncio.create_task(get_next(event_stream_iter))
                        pending.add(queue_task)
                    except (StopAsyncIteration, GeneratorExit):
                        pending.remove(queue_task)
        except GeneratorExit:
            # Re-raise GeneratorExit for clean exit
            raise
        finally:
            # Clean up pending tasks
            for task in pending:
                if not task.done():
                    task.cancel()
            # 4. Post-stream Assistant Message Processing (always run even on cancel)
            if thread_id and not saved:
                saved = True

                try:
                    # We MUST shield this so it finishes even if the generator is closed/cancelled by the client.
                    # This ensures the assistant message is saved and the title is generated in the DB.
                    new_title = await asyncio.shield(
                        _handle_post_stream_assistant_message(
                            run_result_holder=run_result_holder,
                            run_input=run_input,
                            adapter=adapter,
                            thread_id=thread_id,
                            user_id=user.id,
                            assistant_content=assistant_content,
                            database=database,
                            streamed_id=streamed_id,
                            explicit_asst_id=explicit_asst_id,
                            assistant_parts=assistant_parts,
                        )
                    )

                    if new_title:
                        yield DataChunk(data=[{"title": new_title}], type="data-title")

                    yield DataChunk(data=[{"finished": True}], type="data-chat-finished")
                except (asyncio.CancelledError, GeneratorExit):
                    # Connection closed, but shield ensured post-processing finished in background.
                    pass
                except Exception as e:
                    logger.error(f"Error in post-stream processing: {e}")

    sse_event_stream = adapter.encode_stream(save_history_stream())
    return StreamingResponse(sse_event_stream, media_type=accept)


# ===========================================================================
# 5. Endpoints: Threads & Attachments
# ===========================================================================


@router.get("/chat/threads", tags=["Chat"])
async def list_threads(
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    database: Annotated[Database, Depends(get_database)],
    skip: int = 0,
    limit: int = 50,
) -> Response:
    """List chat threads for the authenticated user."""
    try:
        threads = database.list_user_threads(user_id=user.id, skip=skip, limit=limit)
        return JSONResponse(
            {
                "threads": threads,
                "skip": skip,
                "limit": limit,
                "count": len(threads),
            },
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to fetch threads: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.get("/chat/threads/{thread_id}", tags=["Chat"])
async def get_thread_messages(
    thread_id: str,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    database: Annotated[Database, Depends(get_database)],
) -> Response:
    """Get all messages for a specific chat thread."""
    try:
        items = database.get_thread_items(user_id=user.id, thread_id=thread_id)
        if items is None:
            return JSONResponse({"items": []}, status_code=HTTPStatus.OK)
        return JSONResponse({"items": items}, status_code=HTTPStatus.OK)
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to fetch thread messages: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.patch("/chat/threads/{thread_id}", tags=["Chat"])
async def update_thread(
    thread_id: str,
    data: ThreadUpdateInput,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    database: Annotated[Database, Depends(get_database)],
) -> Response:
    """Update a chat thread title for the authenticated user."""
    try:
        thread = database.fetch_thread(thread_id)
        if not thread or thread.get("user_id") != user.id:
            return JSONResponse(
                {"error": "Thread not found or doesn't belong to current user"},
                status_code=HTTPStatus.NOT_FOUND,
            )

        database.update_thread_info(thread_id, title=data.title, user_id=user.id)
        return JSONResponse(
            {"status": "success", "message": "Thread updated successfully"},
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        logger.error(f"Error updating thread: {e}")
        return JSONResponse(
            {"error": f"Failed to update thread: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.delete("/chat/threads/{thread_id}", tags=["Chat"])
async def delete_thread(
    thread_id: str,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    database: Annotated[Database, Depends(get_database)],
) -> Response:
    """Delete a chat thread for the authenticated user."""
    try:
        success = database.delete_user_thread(user_id=user.id, thread_id=thread_id)
        if not success:
            return JSONResponse(
                {"error": "Thread not found or doesn't belong to current user"},
                status_code=HTTPStatus.NOT_FOUND,
            )
        return JSONResponse(
            {"status": "success", "message": "Thread deleted successfully"},
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to delete thread: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.get("/chat/attachments/{object_name:path}", tags=["Chat"])
async def get_attachment(
    object_name: str,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    storage: Annotated[Storage, Depends(get_storage)],
) -> Response:
    """Securely proxy a Minio attachment to the authenticated user."""
    try:
        content = storage.download_attachment(object_name)
        media_type, _ = mimetypes.guess_type(object_name)
        if not media_type:
            media_type = "application/octet-stream"
        return Response(content=content, media_type=media_type)
    except Exception as e:
        logger.error(f"Failed to serve attachment {object_name}: {e}")
        return JSONResponse(
            {"error": "Attachment not found"},
            status_code=HTTPStatus.NOT_FOUND,
        )
