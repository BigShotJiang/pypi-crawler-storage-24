from typing import Any

from pydantic_ai import Agent, RunContext

from ..constants import OPENAI_HTTP_PROXY
from .deps import AgentDeps
from .utils import get_openai_model


DEFAULT_AGENT_INSTRUCTIONS = """
You are a helpful AI assistant. Answer user questions clearly and concisely.
You can help with a wide range of topics including general knowledge, writing, analysis, and more.

Always be polite, accurate, and helpful. If you are unsure about something, let the user know.
""".strip()


def get_default_agent(
    model_name: str = "gpt-5.1",
    instructions: str | list[str] | None = None,
) -> Agent[AgentDeps[Any]]:
    """
    Factory method to create a default agent with a customizable model and instructions.
    """
    model = get_openai_model(model_name, proxy=OPENAI_HTTP_PROXY)

    combined_instructions = DEFAULT_AGENT_INSTRUCTIONS
    if instructions:
        if isinstance(instructions, list):
            combined_instructions += "\n" + "\n".join(instructions)
        else:
            combined_instructions += "\n" + instructions

    agent = Agent[AgentDeps[Any]](
        name="Agent",
        instructions=combined_instructions,
        model=model,
    )

    @agent.instructions
    def add_user_info(ctx: RunContext[AgentDeps[Any]]):
        info = ""
        if ctx.deps.user is not None:
            info += f"User's name and surname is '{ctx.deps.user.name} {ctx.deps.user.surname}'"
        return info

    return agent


# Default instance for legacy support or internal use
default_agent = get_default_agent()
