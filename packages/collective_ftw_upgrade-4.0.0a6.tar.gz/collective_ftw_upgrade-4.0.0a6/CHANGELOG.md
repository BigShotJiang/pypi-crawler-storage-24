# Changelog

<!-- towncrier release notes start -->

## 4.0.0a6 (2026-03-12)


### New features:

- New upgrade step directories are now created with a `v` prefix (e.g., `v20260301125502_plone_6_upgrade`) to make them importable as Python modules. Existing directories without the prefix continue to work. [#24](https://github.com/collective/collective.ftw.upgrade/issues/24)

## 4.0.0a5 (2026-02-27)


### New features:

- Allow to specify the zope  URL using the `UPGRADE_ZOPE_URL` environment variable.
  This helps when using the package in non buildout installed Plone sites. [#22](https://github.com/collective/collective.ftw.upgrade/issues/22)
- Allow to specify the directory that stores the authentication file
  with the `UPGRADE_TEMPFILE_AUTH_DIR` environment variable.
  This helps when using the package in non buildout installed Plone sites. [#22](https://github.com/collective/collective.ftw.upgrade/issues/22)

## 4.0.0a4 (2026-02-17)


### New features:

- Reimplement manage-uprades view displaying the actual result of the upgrade. [mathias.leimgruber] [#20](https://github.com/collective/collective.ftw.upgrade/issues/20)

## 4.0.0a3 (2026-02-12)


### Bug fixes:

- Change directive namespace to collective.ftw.upgrade. [mathias.leigmruber] [#18](https://github.com/collective/collective.ftw.upgrade/issues/18)

## 4.0.0a2 (2026-02-10)


### New features:

- Clean up the leftovers of `ftw.upgrade` [ale-rt] [#14](https://github.com/collective/collective.ftw.upgrade/issues/14)


### Bug fixes:

- Fix the installation profile title and add an uninstall profile [ale-rt] [#16](https://github.com/collective/collective.ftw.upgrade/issues/16)

## 4.0.0a1 (2026-02-09)

> [!NOTE]
> This is the first alpha release of version 4.0.0 happening after the fork of ftw.upgrade to the new repository [`collective/collective.ftw.upgrade`](https://github.com/collective/collective.ftw.upgrade) on GitHub.

### Breaking:

- Remove streaming the upgrade results, since it only worked with
  Zope2 server. [mathias.leimgruber]

- Remove ftw.testbrowser dependency [mathias.leimgruber]

- Remove combine_bundle [mathias.leimgruber]

- Remove recook feature [mathias.leimgruber]

### New features:

- Added the possibility to group upgrade steps in subdirectories. [ale-rt] [#5](https://github.com/collective/collective.ftw.upgrade/issues/5)

### Internal:

- Remove the dependency from `pkg_resources`
- Update configuration files.
  [plone devs]

### Documentation:

- Update the documentation

## 3.3.1 (2022-07-08)

- Support dead brains in WorkflowSecurityUpdater. [njohner]

## 3.3.0 (2022-03-28)

- Allow choosing a specific instance to run upgrade commands.
  [njohner]

## 3.2.0 (2022-01-31)

- Log memory usage during upgrade steps. [njohner]
- Write upgrade step durations to a file. [njohner]
- Sweep cache during upgrade if memory is critical. [njohner]

## 3.1.1 (2021-09-07)

- Add method to iterate over brains in upgrade step. [njohner]

## 3.1.0 (2021-06-21)

- Add intermediate commit option to commit the transaction after each
  installed upgrade. [deiferni]

## 3.0.4 (2021-01-21)

- Do not call `cookResources` on dummy old resource registry tools.
  [maurits]

- When using Python3, use importlib instead of the deprecated imp
  module to look for upgrade steps. This removes the warning displayed
  about unclosed resources. Fixes
  `issue 211 <https://github.com/4teamwork/ftw.upgrade/issues/211>`.
  [ale-rt]

## 3.0.3 (2020-10-10)

- Do not depend anymore on argparse because it is already included in
  Python 2.7 and in Python 3 since version 3.2 Fixes
  `issue 209 <https://github.com/4teamwork/ftw.upgrade/issues/209>`.
  [ale-rt]

## 3.0.2 (2020-08-27)

- Properly compute `find_start_version` when the profile has combined
  upgrade steps Fixes
  `issue 207 <https://github.com/4teamwork/ftw.upgrade/issues/207>`.
  [ale-rt]
- Check for six.binary_type to avoid AttributeErrors when running
  under Python3. [erral]

## 3.0.1 (2020-06-09)

- This Plone add-on now requires six >= 1.12.0. [mbaechtold]

- Instance port number discovery in `wsgi.ini` works also when the
  fast listen option is chosen. Fixes
  `issue 200 <https://github.com/4teamwork/ftw.upgrade/issues/200>`.
  [ale-rt]

- The plone_upgrade subcommand does not break on Python3 Fixes
  `issue 202 <https://github.com/4teamwork/ftw.upgrade/issues/202>`.
  [ale-rt]

- Remove a bunch of deprecation warnings Fixes
  `issue 204 <https://github.com/4teamwork/ftw.upgrade/issues/204>`.
  [ale-rt]

## 3.0.0 (2020-03-23)

- Add support for Plone 5.2 and Python 3. [buchi]
- Also look for the instance port number in `wsgi.ini`. [maurits]

## 2.16.0 (2020-02-14)

- Allow additional indexes to be reindexed in the
  WorkflowChainUpdater. [tinagerber]

## 2.15.2 (2020-01-27)

- Fix missing values in IntIds catalog as we go within
  migrate_intid(). [djowett-ftw]

## 2.15.1 (2019-12-16)

- Cleanup broken catalog brains on `NotFound`. [jone]

## 2.15.0 (2019-12-12)

- Add context manager for disabling upgrade step marking. [jone]

- Do not mark upgrade steps as installed when not doing a full import.
  [jone]

## 2.14.1 (2019-11-08)

- Migrate creators even when dublin core behaviors are not enabled.
  [jone]

- Migrate empty values in RichTextFields correctly. Fixes
  `https://github.com/4teamwork/izug.refegovservice/issues/2`.
  [djowett-ftw]

## 2.14.0 (2019-10-31)

- Added `--allow-outdated` option to `install` command. This allows
  installing upgrades or profiles on a not up-to-date site. Fixes
  `issue 182 <https://github.com/4teamwork/ftw.upgrade/issues/182>`.
  [maurits]

## 2.13.0 (2019-08-22)

- Added combine_bundles command for Plone 5. This combines JS/CSS
  bundles together. [maurits]

## 2.12.2 (2019-06-19)

- Make sure to always use a portal_migration tool wrapped in a
  RequestContainer. (Fixes "AttributeError: REQUEST" on a Plone 5.1.x
  upgrade) [lgraf]

## 2.12.1 (2019-06-18)

- Choose actual port used by ZServer layer to run CommandAndInstance
  tests against. [lgraf]
- Disable Diazo on upgrades-plain for Plone 5.1.5 support. [jone]

## 2.12.0 (2018-07-26)

- Allow marking upgrades as deferred so they won't be proposed by
  default. [deiferni]

## 2.11.1 (2018-04-05)

- Fix connection problem when zope.conf contains ip-address. [jone]
- Make sure remove_broken_browserlayer() helper doesn't fail if the
  browser layer registration to be removed doesn't exist (any more).
  [lgraf]

## 2.11.0 (2018-01-31)

- Provide upgrade step handler interfaces and handler class in
  wrapper. [jone]
- Do not propose executed upgrades newer than current db version.
  [jone]

## 2.10.0 (2018-01-08)

- Support installing proposed upgrades of specific Generic Setup
  profiles. Use `bin/upgrade install --proposed the.package:default`.
  [jone]

## 2.9.0 (2017-12-14)

- Optimize memory footprint after every upgrade step. [jone]
- Reduce memory footprint in SavepointIterator by garbage-collecting
  connection cache. [jone]
- Set the default savepoint threshold to 1000; make it configurable.
  [jone]
- Enable savepoint iterator by default. Affects `self.objects`.
  [jone]
- Use a SavepointIterator in the WorkflowSecurityUpdater in order not
  to exceed memory. [mbaechtold]

## 2.8.1 (2017-10-13)

- Also catch AttributeErrors when accessing objects of broken brains.
  [buchi]

## 2.8.0 (2017-07-27)

- The upgrade step methods will remove and skip broken catalog brains.
  [jone]

## 2.7.2 (2017-07-13)

- Fix encoding issues in ASCII terminals. [jone]

## 2.7.1 (2017-06-28)

- Fix tempfile authentication when created by different user. [jone]

## 2.7.0 (2017-06-28)

- Support using `bin/upgrade` by another user than the Zope server
  with less strict security checks.[jone]

## 2.6.1 (2017-06-28)

- Fix a bug which caused `bin/upgrade` to fail when the `var`
  directory had the setguid flag active. [jone]

## 2.6.0 (2017-06-08)

- Log (re/un)-indexing progress if collective.indexing is installed.
  [deiferni]

## 2.5.0 (2017-06-07)

- Add support for Plone 5.1. [jone]

## 2.4.0 (2017-06-07)

- Escape < and > in browser logger. [lknoepfel]

- Log current item in ProcessLogger if logger exits unexpectedly.
  [lknoepfel]

## 2.3.1 (2017-02-15)

- Fix bug causing that versions are not properly set after upgrading
  when switching versioning system. [jone]

- Avoid overriding customizations by reinstalling already installed
  profiles while upgrading (Plone>=4.3.8). [jone]

## 2.3.0 (2017-02-14)

- InplaceMigrator: Preserve object position in parent. [lknoepfel]

- Do not downgrade installed version when installing an orphan upgrade
  step. [jone]

- Add "soft_dependencies" option to "upgrade-step:directory"
  directive. [jone]

## 2.2.0 (2017-01-30)

- Add method to remove a previously uninstalled portlet manager from
  the persistent registry. [deiferni]

## 2.1.1 (2016-12-13)

- Fix support for GS import by tarball upload. [jone]

## 2.1.0 (2016-12-06)

- Add upgrade step method `ensure_profile_installed(profileid)`.
  [jone]

- Add upgrade step method `is_profile_installed(profileid)`. [jone]

- Add upgrade step method `is_product_installed(product_name)`.
  [jone]

## 2.0.5 (2016-10-24)

- Migration: fix error when file obj is an empty string. [jone]

## 2.0.4 (2016-10-24)

- Migration: do not migrate empty blobs. [jone]

## 2.0.3 (2016-09-27)

- Migration: support all types of standard relation fields. [jone]

## 2.0.2 (2016-09-27)

- Migration: skip invalid relations. [jone]

## 2.0.1 (2016-09-02)

- Added support for jQuery 1.9+ on @@manage-upgrades control panel.
  [neilferreira]

## 2.0.0 (2016-08-18)

- Fix NoneType AttributeError with newest requests module. [jone]

- Drop Plone 4.1 and 4.2 support. [jone]

- Implement inplace migrator. [jone]

## 1.19.0 (2016-04-11)

- Add option to force reinstall already installed profiles. [jone]

## 1.18.1 (2016-03-09)

- Disable automatic CSRF protection for authorized jsonapi requests.
  [jone]

## 1.18.0 (2016-02-16)

- Provide the attributes `base_profile` and `target_version` on
  upgrade steps when using the `upgrade-step:directory` directive.
  [jone]

- Fix profile version when using `upgrade-step:directory` and having
  old upgrade steps but no new ones. [jone]

## 1.17.0 (2016-01-22)

- Add `bin/upgrade plone_upgrade_needed` command. [jone]

## 1.16.3 (2016-01-22)

- Fix upgrade scaffolding when having dots or other non-alphanumeric
  characters. [jone]

## 1.16.2 (2016-01-15)

- Actually the same as 1.16.1, but pypi was broken when I released it
  and now it does not let me use the same version number. :-( [jone]

## 1.16.1 (2016-01-13)

- Added documentation for the additions of the previous release.
  [maurits]

## 1.16.0 (2016-01-05)

- Added `--all-sites` option. This iterates over all sites and
  performs the specified command on each of them. A failing command
  for one site will stop the entire command. [maurits]

- Configure logging for the command line utility. By default print
  only our own logging, on info level or higher. With the new
  `--verbose` option print all loggers (so also from other packages
  like `requests`) at debug level and higher. [maurits]

- Added `plone_upgrade` command to upgrade a Plone Site. This is what
  you would manually do in the `@@plone-upgrade` view. [maurits]

- Added support for installing profiles. Profiles are only applied
  once. Example command line:
  `bin/upgrade install --site Plone   --profiles Products.PloneFormGen:default`.
  [maurits]

- Prevented UnicodeEncodeError when piping output of
  `bin/upgrade   sites`. This would fail when a site had non-ascii
  characters in its title. [maurits]

## 1.15.1 (2015-11-11)

- Change instance detection to support any name. Before only
  `instance*` was supported. [jone]

## 1.15.0 (2015-10-30)

- Make "blessed" dependency optional in the "colors" extras. [jone]

- Update references to class-migrated objects in the intid utility.
  [deiferni]

## 1.14.8 (2015-09-21)

- Migrate workflow states with wfhistory migration and do not set
  state manually unless necessary. [tschanzt]

## 1.14.7 (2015-08-27)

- Add an afterCommitHook that notifies about the transaction having
  been committed (or aborted) after installing upgrades. [lgraf]

- Fix authentication problem with bin/upgrade command. [jone]

## 1.14.6 (2015-07-22)

- Return context manager to allow "as" statements. [lknoepfel]

## 1.14.5 (2015-05-20)

- Update quickinstaller product version when upgrading a package.
  [jone]

## 1.14.4 (2015-04-09)

- Fix post upgrade ordering which was broken since 1.11.0. [jone]

## 1.14.3 (2015-03-29)

- Fix error in upgrade-step:directory directive. The error occurred
  when the directory was a subdirectory relative to the ZCML
  directory, causing the package module to be replaced with the
  upgrades package directory in sys.modules. [jone]

- Fix issue with transaction note length when a large not already
  exists. When the transaction note already has maximum length
  (e.g. with Archetypes notes), nothing more should be added. Also
  increased the threshold back (reduced in 1.14.2). [jone]

## 1.14.2 (2015-03-25)

- Reduce maximum transaction note length used by ftw.upgrade. [jone]

## 1.14.1 (2015-03-18)

- Command: fix instance discover when bound to public interface.
  [jone]

## 1.14.0 (2015-02-24)

- Command: add fake terminal fallback when blessed cannot be loaded.
  This can happen for example when Python is built without curses
  support. [jone]

- `bin/upgrade recook` command for recooking resources. [jone]

- Recook resources after installing upgrades. [jone]

- plone.reload support for upgrade step directory. [jone]

## 1.13.0 (2015-02-20)

- `bin/upgrade`: automatically authenticate with a tempfile
  negotiation mechanism when no other authentication information is
  provided. [jone]

- New `bin/upgrade user` command for testing authentication. [jone]

## 1.12.0 (2015-02-16)

- Add `bin/upgrade` commands `sites`, `list` and `install`. This makes
  it possible to install upgrades from the console. [jone]

- Update upgrade step scaffold to support plone.reload. [jone]

- New JSON API implemented, accessible with `/upgrades-api`. [jone]

- Executioner: `install_upgrades_by_api_ids` was added, allowing to
  install a selection of upgrades identified by API upgrade ids.
  [jone]

- Gatherer: `get_upgrades_by_api_ids` was added, returning upgrade
  infos for a selection of API upgrade ids. [jone]

- Gatherer: `get_upgrades` is deprecated and replaced by
  `get_profiles`. `get_profiles` now has a `proposed_only` flag.
  [jone]

## 1.11.0 (2015-01-08)

- Reverse post upgrade adapter ordering. The order was reversed, it
  should execute dependencies first. [jone]

- create-upgrade: Make sure to quote argument passed to bin/upgrade.
  [lgraf]

- Add a `create-upgrade` script which can be installed globally.
  [jone]

- Create a `bin/upgrade` script:
  - the `create` command creates a upgrade step in the "upgrades"
    directory.
  - the `touch` command can be used for reordering upgrade steps.

  [jone]

- New `upgrade-step:directory` directive for registering a directory
  with upgrade steps which are automatically detected and registered.
  [jone]

- Extend the importProfile directive so that a handler can be defined.
  The handler may import the associated upgrade step profile with the
  new method `self.install_upgrade_profile()`. [jone]

## 1.10.2 (2014-11-19)

- Exclude uninstalled products from upgrades view. [jone]

- Make upgrades appear in undo form again. The transaction note fix in
  1.7.4 caused upgrade transaction to not appear in the undo form.
  [jone]

## 1.10.1 (2014-10-27)

- Update upgrade view ordering for root nodes. The dependency graph
  does not define any order for root profiles (e.g. included in
  buildout directly), which causes random sorting in the upgrade view
  for those profiles. This change sorts those root profiles by name
  without changing the order of profiles which is depended on.
  [jone]

## 1.10.0 (2014-08-28)

- Wrap step.objects in a SavepointIterator that creates a savepoint
  every n items. [lgraf]

## 1.9.0 (2014-08-27)

- Add @@manage-upgrades-plain fallback view for @@manage-upgrades. It
  does not include Plone's and thus might be able to
  render when the default view fails for some reason. [deiferni]

## 1.8.0 (2014-08-11)

- Prevent portal*quickinstaller from picking upgrade-steps instead of
  the default-profile by prefixing the profile-id with `upgrade_to*`
  (fix #45) [pbauer]

- Flag profiles whose filesystem version is outdated. Highlights
  profiles with upgrades that lead to a destination version that is
  higher than the corresponding profile's current filesystem version.
  This usually means someone forgot to update the version in
  metadata.xml of the corresponding profile. [lgraf]

## 1.7.4 (2014-05-12)

- Extend workflow updater to migrate workflow history. [jone]

- Fix workflow updater to always update objects. The objects are
  updated even when it seems that the object was not update or has no
  longer a workflow. This fixes issues when updating a workflow, in
  which case the old workflow and the new workflow has the same ID.
  [jone]

- Make sure the transaction note does not get too long. Zope limits
  the transaction note length. By actively managing the transaction
  note we can provide fallbacks for when it gets too long because a
  lot of upgrade steps are installed at the same time. [jone]

## 1.7.3 (2014-04-30)

- Add `uninstall_product` method to upgrade step class. [jone]

## 1.7.2 (2014-02-28)

- Update provided interfaces when migrating objects to new class.
  [jone]

## 1.7.1 (2014-01-09)

- Fix LocationError on manage-upgrades view on cyclic dependencies.
  [jone]

## 1.7.0 (2013-09-24)

- Add a `update_workflow_security` helper function to the upgrade
  step. [jone]

## 1.6.0 (2013-08-30)

- Fix inplace modification bug when updating the catalog while
  iterating over a catalog result. [jone]

- Implement new `importProfile` directive for creating upgrade steps
  that just import a specific upgrade step generic setup profile.
  [jone]

## 1.5 (2013-08-16)

- Add a `WorkflowChainUpdater` for changing workflow chains without
  resetting existing objects to the initial review state of the new
  workflow. [jone]

## 1.4.0 (2013-07-18)

- Added helper for adding a type_action. [phgross]

- Add `objects` method to `UpgradeStep` for easy querying the catalog
  and doing stuff with progress logging combined. [jone]

- Make ProgressLogger an iterator too, because it is easier to use.
  [jone]

- Improve logging while installing upgrade steps. Show duration for
  installing. [jone]

- Fix upgrade step icons for Plone 4.3. [jone]

- Add `update_security` helper. [jone]

- Fix incomplete status info entry produced by placeful workflow
  policy activator. [jone]

## 1.3 (2013-06-13)

- Implement a placeful workflow policy activator. [jone]

- Added remove_broken_browserlayer method to step class. [lgraf]

## 1.2.1 (2013-04-23)

- Keep modification date on reindexObject without idxs.
  [mathias.leimgruber]

## 1.2 (2013-01-24)

- onegov.ch approved: add badge to readme. [jone]

- Remove 'step' and 'for' values from internal data structure. This is
  needed for allowing us to serialize the data (json). [jone]

- Add IPostUpgrade adapter hook. [jone]

- Refactor dependency sorting into separate function. [jone]

- Add security declarations. [jone]

- Fix wrong tool usage when installing a profile in step class.
  [jone]

## 1.1 (2012-10-08)

- Add catalog_unrestricted_get_object and catalog_unrestricted_search
  methods to step class. [jone]

- Handle profiles of packages which were removed but have leftover
  generic setup entries. [jone]

## 1.0 (2012-08-13)

- Add installed upgrades to transaction note. Closes #7 [jone]

- Add `migrate_class` helper with `_p_changed` implementation
  supporting BTreeFolder2Base containers. [jone]

- Remove `purge_resource_registries()` helper because it does not
  behave as expected. [jone]

- Set min-height of upgrade output frame to 500px. [jone]

- Print exceptions to browser log stream. [jone]

## 1.0b2 (2012-07-04)

- Fix the upgrade registration problem (using a classmethod does not
  work since registration fails). [jone]

- Let @@manage-upgrade be usable without actually installing the GS
  profile. [maethu]

## 1.0b1 (2012-06-27)

- First implementation. [jone]
