"""Integration tests against real Incus containers.

These tests require:
- Incus installed and available
- base image built (run: bubble images build base)

Mark: @pytest.mark.integration
Skip locally with: pytest -m "not integration"
"""

import uuid

import pytest

from bubble.network import apply_allowlist, remove_allowlist
from bubble.runtime.incus import IncusRuntime

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def runtime():
    """IncusRuntime instance (shared across all integration tests)."""
    rt = IncusRuntime()
    if not rt.is_available():
        pytest.skip("Incus not available")
    return rt


@pytest.fixture(scope="session")
def _check_base_image(runtime):
    """Skip all integration tests if base image isn't built."""
    if not runtime.image_exists("base"):
        pytest.skip("base image not built")


@pytest.fixture
def container(runtime, _check_base_image):
    """Launch a fresh container from base, delete on teardown."""
    name = f"ci-test-{uuid.uuid4().hex[:8]}"
    runtime.launch(name, "base")
    # Wait for container to be ready
    for _ in range(15):
        try:
            runtime.exec(name, ["true"])
            break
        except Exception:
            import time

            time.sleep(0.5)
    yield name
    try:
        runtime.delete(name, force=True)
    except Exception:
        pass


@pytest.fixture
def container_with_allowlist(runtime, container):
    """Container with network allowlist applied (waits for DNS readiness)."""
    import time

    # Wait for DNS resolver to be available (needed for allowlist)
    for _ in range(20):
        try:
            resolver = runtime.exec(
                container,
                ["bash", "-c", "grep -m1 nameserver /etc/resolv.conf | awk '{print $2}'"],
            ).strip()
            if resolver:
                break
        except Exception:
            pass
        time.sleep(0.5)
    apply_allowlist(runtime, container, ["github.com", "*.githubusercontent.com"])
    return container


# ---------------------------------------------------------------------------
# Security: No Privilege Escalation
# ---------------------------------------------------------------------------


class TestNoPrivilegeEscalation:
    def test_user_cannot_sudo(self, runtime, container):
        """user has no sudo access."""
        with pytest.raises(RuntimeError):
            runtime.exec(
                container,
                [
                    "su",
                    "-",
                    "user",
                    "-c",
                    "sudo whoami",
                ],
            )

    def test_password_locked(self, runtime, container):
        """user's password is locked (! or * prefix in shadow)."""
        shadow = runtime.exec(
            container,
            [
                "grep",
                "^user:",
                "/etc/shadow",
            ],
        )
        # Locked password has ! or * after the first colon
        password_field = shadow.split(":")[1]
        assert password_field.startswith("!") or password_field.startswith("*")

    def test_no_sudoers_file(self, runtime, container):
        """No sudoers entry for user."""
        with pytest.raises(RuntimeError):
            runtime.exec(
                container,
                [
                    "cat",
                    "/etc/sudoers.d/user",
                ],
            )


# ---------------------------------------------------------------------------
# Security: Network Allowlist
# ---------------------------------------------------------------------------


class TestNetworkAllowlist:
    def test_iptables_default_deny(self, runtime, container_with_allowlist):
        """OUTPUT chain default policy is DROP."""
        output = runtime.exec(
            container_with_allowlist,
            [
                "iptables",
                "-L",
                "OUTPUT",
                "-n",
            ],
        )
        assert "policy DROP" in output

    def test_ipv6_blocked(self, runtime, container_with_allowlist):
        """IPv6 OUTPUT is DROP."""
        output = runtime.exec(
            container_with_allowlist,
            [
                "ip6tables",
                "-L",
                "OUTPUT",
                "-n",
            ],
        )
        assert "policy DROP" in output

    def test_no_outbound_ssh_rule(self, runtime, container_with_allowlist):
        """No iptables rules for port 22."""
        output = runtime.exec(
            container_with_allowlist,
            [
                "iptables",
                "-L",
                "OUTPUT",
                "-n",
            ],
        )
        assert "dpt:22" not in output

    def test_dns_restricted_to_resolver(self, runtime, container_with_allowlist):
        """DNS rules only target the container's resolver."""
        # Use -S for machine-readable output (shows --dport 53)
        output = runtime.exec(
            container_with_allowlist,
            [
                "iptables",
                "-S",
                "OUTPUT",
            ],
        )
        resolver = runtime.exec(
            container_with_allowlist,
            [
                "bash",
                "-c",
                "grep -m1 nameserver /etc/resolv.conf | awk '{print $2}'",
            ],
        ).strip()
        # DNS rules should reference the stub resolver or upstream DNS servers
        lines = [ln for ln in output.splitlines() if "--dport 53" in ln]
        assert len(lines) > 0, "Expected DNS rules"
        # At minimum, the stub resolver must be in the rules
        assert any(resolver in ln for ln in lines), (
            f"Stub resolver {resolver} not found in DNS rules"
        )

    def test_blocked_destination_unreachable(self, runtime, container_with_allowlist):
        """Connections to non-allowlisted hosts are blocked."""
        result = runtime.exec(
            container_with_allowlist,
            [
                "bash",
                "-c",
                "timeout 3 bash -c 'echo > /dev/tcp/1.1.1.1/80' 2>&1 || echo BLOCKED",
            ],
        )
        assert "BLOCKED" in result

    def test_allowlisted_destination_has_accept_rules(self, runtime, container_with_allowlist):
        """iptables has ACCEPT rules for allowlisted domain IPs."""
        output = runtime.exec(
            container_with_allowlist,
            ["iptables", "-S", "OUTPUT"],
        )
        # The allowlist resolves domains to IPs and adds -d <ip> -j ACCEPT rules.
        # Filter out loopback, ESTABLISHED, and DNS rules to find domain IP rules.
        ip_accept = [
            ln
            for ln in output.splitlines()
            if "-j ACCEPT" in ln and "-d " in ln and "--dport 53" not in ln and "-o lo" not in ln
        ]
        assert len(ip_accept) > 0, f"Expected ACCEPT rules for domain IPs, got:\n{output}"


# ---------------------------------------------------------------------------
# Security: SSH Configuration
# ---------------------------------------------------------------------------


class TestSSHConfiguration:
    def test_password_auth_disabled(self, runtime, container):
        """SSH password authentication is disabled."""
        config = runtime.exec(
            container,
            [
                "bash",
                "-c",
                "grep -E '^PasswordAuthentication' /etc/ssh/sshd_config || echo 'NOT_SET'",
            ],
        )
        if "NOT_SET" not in config:
            assert "no" in config.lower()

    def test_root_login_disabled(self, runtime, container):
        """SSH root login is disabled."""
        config = runtime.exec(
            container,
            [
                "bash",
                "-c",
                "grep -E '^PermitRootLogin' /etc/ssh/sshd_config || echo 'NOT_SET'",
            ],
        )
        if "NOT_SET" not in config:
            assert "no" in config.lower()


# ---------------------------------------------------------------------------
# Functional: Container Lifecycle
# ---------------------------------------------------------------------------


class TestContainerLifecycle:
    def test_launch_exec_delete(self, runtime, _check_base_image):
        """Can launch a container, execute commands, and delete it."""
        name = f"ci-test-lifecycle-{uuid.uuid4().hex[:8]}"
        try:
            runtime.launch(name, "base")
            output = runtime.exec(name, ["echo", "hello"])
            assert "hello" in output
        finally:
            try:
                runtime.delete(name, force=True)
            except Exception:
                pass

    def test_user_exists(self, runtime, container):
        """Container has a 'user' user."""
        output = runtime.exec(container, ["id", "user"])
        assert "uid=" in output

    def test_network_allowlist_apply_remove(self, runtime, container):
        """Can apply and remove network allowlist."""
        apply_allowlist(runtime, container, ["github.com"])
        output = runtime.exec(container, ["iptables", "-L", "OUTPUT", "-n"])
        assert "policy DROP" in output

        remove_allowlist(runtime, container)
        output = runtime.exec(container, ["iptables", "-L", "OUTPUT", "-n"])
        assert "policy ACCEPT" in output
