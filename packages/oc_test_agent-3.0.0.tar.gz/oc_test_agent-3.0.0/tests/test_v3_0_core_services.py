"""test-agent v3.0 单元测试 - 增强覆盖率"""

import pytest
import os
import tempfile
import shutil
from pathlib import Path
from datetime import datetime
import json

from src.core.code_sync_service import SyncStatus


class TestResultStorageService:
    """测试ResultStorageService"""
    
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test.db")
        
        from src.core.result_storage_service import ResultStorageService
        self.storage = ResultStorageService({
            'storage': {'database': {'path': self.db_path}},
            'report': {'export': {'dir': self.temp_dir, 'max_size': 1000}}
        })
    
    def teardown_method(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_save_case_result(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-001",
            case_name="测试用例1",
            status="passed",
            duration=1.5
        )
        
        result_id = self.storage.save_case_result(result)
        
        assert result_id is not None
        assert len(result_id) > 0
    
    def test_get_case_history(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-001",
            case_name="测试用例1",
            status="passed",
            duration=1.5
        )
        
        self.storage.save_case_result(result)
        
        history = self.storage.get_case_history("TC-001", 1, 10)
        
        assert history['total'] >= 1
        assert len(history['history']) >= 1
    
    def test_export_case_report_json(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-001",
            case_name="测试用例1",
            status="passed",
            duration=1.5
        )
        
        self.storage.save_case_result(result)
        
        export_result = self.storage.export_case_report("TC-001", "json")
        
        assert export_result.format == "json"
        assert os.path.exists(export_result.file_path)
    
    def test_get_case_statistics(self):
        from src.core.result_storage_service import TestCaseResult
        
        for i in range(5):
            result = TestCaseResult(
                id="",
                test_id=f"test_{i:03d}",
                case_id="TC-001",
                case_name="测试用例1",
                status="passed" if i < 4 else "failed",
                duration=1.0 + i * 0.1
            )
            self.storage.save_case_result(result)
        
        stats = self.storage.get_case_statistics("TC-001")
        
        assert stats.total_runs == 5
        assert stats.passed_count == 4
        assert stats.failed_count == 1
        assert stats.pass_rate == 0.8
    
    def test_save_batch(self):
        from src.core.result_storage_service import TestBatch
        
        batch = TestBatch(
            id="",
            project="test-project",
            status="running"
        )
        
        batch_id = self.storage.save_batch(batch)
        
        assert batch_id is not None
        
        retrieved = self.storage.get_batch(batch_id)
        
        assert retrieved is not None
        assert retrieved.project == "test-project"
        assert retrieved.status == "running"
    
    def test_bulk_save_results(self):
        from src.core.result_storage_service import TestCaseResult
        
        results = [
            TestCaseResult(
                id="",
                test_id="test_batch",
                case_id=f"TC-{i:03d}",
                case_name=f"测试用例{i}",
                status="passed",
                duration=1.0 + i * 0.1
            )
            for i in range(10)
        ]
        
        self.storage.bulk_save_results(results)
        
        history = self.storage.get_case_history("TC-001", 1, 10)
        assert history['total'] >= 1
    
    def test_export_case_report_csv(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-CSV",
            case_name="测试用例CSV",
            status="passed",
            duration=1.5
        )
        
        self.storage.save_case_result(result)
        
        export_result = self.storage.export_case_report("TC-CSV", "csv")
        
        assert export_result.format == "csv"
        assert os.path.exists(export_result.file_path)
    
    def test_export_case_report_html(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-HTML",
            case_name="测试用例HTML",
            status="passed",
            duration=1.5
        )
        
        self.storage.save_case_result(result)
        
        export_result = self.storage.export_case_report("TC-HTML", "html")
        
        assert export_result.format == "html"
        assert os.path.exists(export_result.file_path)
    
    def test_update_batch_status(self):
        from src.core.result_storage_service import TestBatch
        
        batch = TestBatch(
            id="",
            project="test-project",
            status="running"
        )
        
        batch_id = self.storage.save_batch(batch)
        
        self.storage.update_batch_status(batch_id, "completed")
        
        retrieved = self.storage.get_batch(batch_id)
        assert retrieved.status == "completed"
    
    def test_get_case_statistics_empty(self):
        from src.core.result_storage_service import CaseStatistics
        
        stats = self.storage.get_case_statistics("NONEXISTENT")
        
        assert stats.total_runs == 0
        assert stats.pass_rate == 0.0
    
    def test_validate_result_invalid_status(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-001",
            case_name="测试",
            status="invalid_status",
            duration=1.0
        )
        
        with pytest.raises(ValueError):
            self.storage.save_case_result(result)
    
    def test_validate_result_negative_duration(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-001",
            case_name="测试",
            status="passed",
            duration=-1.0
        )
        
        with pytest.raises(ValueError):
            self.storage.save_case_result(result)
    
    def test_get_bugs(self):
        from src.core.result_storage_service import BugReport
        
        bug = BugReport(
            id="",
            test_id="test_001",
            case_id="TC-001",
            title="测试Bug",
            severity="high",
            status="open"
        )
        
        bug_id = self.storage.save_bug_report(bug)
        
        assert bug_id is not None
        
        bugs = self.storage.get_bugs(test_id="test_001")
        assert bugs['total'] >= 1
    
    def test_get_bugs_with_filter(self):
        from src.core.result_storage_service import BugReport
        
        bug = BugReport(
            id="",
            test_id="test_filter",
            case_id="TC-001",
            title="测试Bug",
            severity="high",
            status="open"
        )
        
        self.storage.save_bug_report(bug)
        
        bugs = self.storage.get_bugs(status="open", severity="high")
        assert bugs['total'] >= 1
    
    def test_get_all_batches(self):
        from src.core.result_storage_service import TestBatch
        
        for i in range(3):
            batch = TestBatch(
                id="",
                project=f"project-{i}",
                status="running"
            )
            self.storage.save_batch(batch)
        
        batches = self.storage.get_all_batches()
        assert batches['total'] >= 3
    
    def test_get_statistics(self):
        from src.core.result_storage_service import TestCaseResult
        
        for i in range(5):
            result = TestCaseResult(
                id="",
                test_id=f"test_{i}",
                case_id="TC-001",
                case_name="测试",
                status="passed",
                duration=1.0
            )
            self.storage.save_case_result(result)
        
        stats = self.storage.get_statistics()
        assert stats['total_tests'] >= 5


class TestCodeSyncService:
    """测试CodeSyncService"""
    
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        
        from src.core.code_sync_service import CodeSyncService
        self.code_sync = CodeSyncService({
            'cache': {
                'dir': self.temp_dir,
                'max_size_gb': 1,
                'cleanup_delay_seconds': 1,
                'disk_threshold': 0.2,
                'lru_enabled': True
            },
            'git': {
                'timeout': 10,
                'retry_count': 1,
                'clone_depth': 1
            },
            'conf_man': {
                'api_url': 'http://localhost:8000'
            },
            'concurrency': {
                'max_parallel_syncs': 2
            }
        })
    
    def teardown_method(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_cache_directory_created(self):
        assert os.path.exists(self.temp_dir)
    
    def test_enforce_cache_limit_empty(self):
        removed = self.code_sync.enforce_cache_limit()
        assert removed == 0
    
    def test_check_disk_space(self):
        result = self.code_sync.check_disk_space()
        assert isinstance(result, bool)
    
    def test_get_cache_info_empty(self):
        info = self.code_sync.get_cache_info("nonexistent")
        assert info == []
    
    def test_cleanup_nonexistent(self):
        self.code_sync.cleanup_code("nonexistent")
    
    def test_get_cache_total_size(self):
        size = self.code_sync._get_cache_total_size()
        assert size >= 0
    
    def test_get_all_cache_entries_empty(self):
        entries = self.code_sync._get_all_cache_entries()
        assert entries == []
    
    def test_version_mapping_error(self):
        from src.core.code_sync_service import VersionMappingError
        with pytest.raises(VersionMappingError):
            self.code_sync.get_commit_from_version("nonexistent", "v1.0.0")
    
    def test_sync_without_version_or_commit(self):
        result = self.code_sync.sync_subsystem("test")
        assert result.status == SyncStatus.FAILED
        assert result.error is not None
    
    def test_sync_with_version_not_found(self):
        result = self.code_sync.sync_subsystem("test", version="v999.0.0")
        assert result.status == SyncStatus.FAILED
        assert result.error is not None
    
    def test_cache_path_generation(self):
        path = self.code_sync._get_cache_path("oc-collab", "abc123")
        assert "oc-collab" in str(path)
        assert "abc123" in str(path)
    
    def test_remove_cache_entry(self):
        from src.core.code_sync_service import CacheInfo
        entry = CacheInfo(
            subsystem="test",
            version="v1.0",
            commit="abc123",
            size=1000,
            last_accessed=datetime.now(),
            local_path=self.temp_dir
        )
        self.code_sync._remove_cache_entry(entry)
    
    def test_update_access_time(self):
        path = Path(self.temp_dir) / "test"
        path.mkdir()
        self.code_sync._update_access_time(path)
        assert path.exists()
    
    def test_get_subsystem_config(self):
        config = self.code_sync._get_subsystem_config("nonexistent")
        assert config == {}
    
    def test_sync_with_cache_hit(self):
        subsystem = "oc-collab"
        commit = "abc123def"
        
        cache_path = self.code_sync._get_cache_path(subsystem, commit)
        cache_path.mkdir(parents=True, exist_ok=True)
        
        result = self.code_sync.sync_subsystem(subsystem, commit=commit)
        
        assert result.status == SyncStatus.SYNCED
        assert result.subsystem == subsystem
    
    def test_get_commit_from_version_config(self):
        import yaml
        from pathlib import Path
        
        mapping_file = Path('config/version_mapping.yaml')
        mapping_file.parent.mkdir(parents=True, exist_ok=True)
        
        mapping_data = {
            'mappings': {
                'test-subsystem': {
                    'v1.0.0': 'commit123'
                }
            }
        }
        with open(mapping_file, 'w') as f:
            yaml.dump(mapping_data, f)
        
        try:
            commit = self.code_sync.get_commit_from_version("test-subsystem", "v1.0.0")
            assert commit == 'commit123'
        finally:
            if mapping_file.exists():
                mapping_file.unlink()
    
    def test_get_version_from_commit(self):
        import yaml
        from pathlib import Path
        
        subsystem = "test-subsystem"
        commit = "commit456"
        version = "v2.0.0"
        
        cache_path = self.code_sync._get_cache_path(subsystem, commit)
        cache_path.mkdir(parents=True, exist_ok=True)
        (cache_path / ".version").write_text(version)
        
        result_version = self.code_sync.get_version_from_commit(subsystem, commit)
        assert result_version == version
    
    def test_cleanup_code_actual(self):
        subsystem = "test-cleanup"
        cache_path = self.code_sync.cache_dir / subsystem
        cache_path.mkdir(parents=True, exist_ok=True)
        
        assert cache_path.exists()
        
        self.code_sync.cleanup_code(subsystem)
        
        assert not cache_path.exists()
    
    def test_enforce_cache_limit_with_data(self):
        subsystem = "test-lru"
        commit = "commit789"
        
        cache_path = self.code_sync._get_cache_path(subsystem, commit)
        cache_path.mkdir(parents=True, exist_ok=True)
        
        dummy_file = cache_path / "dummy.txt"
        dummy_file.write_text("x" * 1000)
        
        self.code_sync.max_cache_size = 500
        
        removed = self.code_sync.enforce_cache_limit()
        
        assert removed >= 0
    
    def test_get_cache_info_with_entries(self):
        subsystem = "test-info"
        commit = "commitinfo"
        
        cache_path = self.code_sync._get_cache_path(subsystem, commit)
        cache_path.mkdir(parents=True, exist_ok=True)
        (cache_path / ".version").write_text("v1.0.0")
        
        info = self.code_sync.get_cache_info(subsystem)
        
        assert len(info) >= 1
        assert info[0].subsystem == subsystem
    
    def test_get_cache_total_size_with_data(self):
        subsystem = "test-size"
        commit = "commitsize"
        
        cache_path = self.code_sync._get_cache_path(subsystem, commit)
        cache_path.mkdir(parents=True, exist_ok=True)
        (cache_path / "file.txt").write_text("test content")
        
        size = self.code_sync._get_cache_total_size()
        
        assert size > 0
    
    def test_get_all_cache_entries_with_data(self):
        subsystem = "test-entries"
        commit = "commitentries"
        
        cache_path = self.code_sync._get_cache_path(subsystem, commit)
        cache_path.mkdir(parents=True, exist_ok=True)
        (cache_path / ".version").write_text("v1.0.0")
        
        entries = self.code_sync._get_all_cache_entries()
        
        assert len(entries) >= 1
    
    def test_force_cleanup(self):
        for i in range(3):
            subsystem = f"test-force-{i}"
            commit = f"commit{i}"
            cache_path = self.code_sync._get_cache_path(subsystem, commit)
            cache_path.mkdir(parents=True, exist_ok=True)
            (cache_path / "file.txt").write_text("x" * 100)
        
        self.code_sync._force_cleanup()
        
        entries = self.code_sync._get_all_cache_entries()
        assert len(entries) < 3
    
    def test_version_from_config_lookup(self):
        import yaml
        from pathlib import Path
        
        mapping_file = Path('config/version_mapping.yaml')
        mapping_file.parent.mkdir(parents=True, exist_ok=True)
        
        mapping_data = {
            'mappings': {
                'test-sub': {
                    'v3.0.0': 'abc999'
                }
            }
        }
        with open(mapping_file, 'w') as f:
            yaml.dump(mapping_data, f)
        
        try:
            self.code_sync._version_mapping = {}
            version = self.code_sync._get_version_from_config('test-sub', 'abc999')
            assert version == 'v3.0.0'
        finally:
            if mapping_file.exists():
                mapping_file.unlink()
    
    def test_get_subsystem_config_success(self):
        import yaml
        from pathlib import Path
        
        config_file = Path('config/subsystems.yaml')
        config_file.parent.mkdir(parents=True, exist_ok=True)
        
        config_data = {
            'subsystems': {
                'my-subsystem': {
                    'git_url': 'https://github.com/test/repo.git'
                }
            }
        }
        with open(config_file, 'w') as f:
            yaml.dump(config_data, f)
        
        try:
            config = self.code_sync._get_subsystem_config('my-subsystem')
            assert config.get('git_url') == 'https://github.com/test/repo.git'
        finally:
            if config_file.exists():
                config_file.unlink()


class TestReportService:
    """测试ReportService"""
    
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test.db")
        
        from src.core.result_storage_service import ResultStorageService
        from src.core.report_service import ReportService
        
        self.storage = ResultStorageService({
            'storage': {'database': {'path': self.db_path}},
            'report': {'export': {'dir': self.temp_dir}, 'pagination': {'default_page_size': 20, 'max_page_size': 100}}
        })
        
        self.report = ReportService(self.storage)
    
    def teardown_method(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_get_test_results_empty(self):
        from src.core.report_service import ResultFilter
        
        filters = ResultFilter(limit=10, offset=0)
        results = self.report.get_test_results(filters)
        
        assert 'results' in results or 'history' in results
    
    def test_generate_report_not_found(self):
        with pytest.raises(ValueError):
            self.report.generate_report("nonexistent_test_id")
    
    def test_get_case_history(self):
        from src.core.result_storage_service import TestCaseResult
        
        result = TestCaseResult(
            id="",
            test_id="test_001",
            case_id="TC-001",
            case_name="测试用例1",
            status="passed",
            duration=1.5
        )
        
        self.storage.save_case_result(result)
        
        history = self.report.get_case_history("TC-001", 1, 10)
        
        assert history.case_id == "TC-001"
        assert len(history.history) >= 1
    
    def test_get_test_results_with_filter(self):
        from src.core.result_storage_service import TestCaseResult
        from src.core.report_service import ResultFilter
        
        for i in range(5):
            result = TestCaseResult(
                id="",
                test_id=f"test_{i}",
                case_id="TC-FILTER",
                case_name="测试用例",
                status="passed" if i < 3 else "failed",
                duration=1.0
            )
            self.storage.save_case_result(result)
        
        filters = ResultFilter(status="passed", limit=10, offset=0)
        results = self.report.get_test_results(filters)
        
        assert 'results' in results or 'history' in results
    
    def test_get_bug_reports(self):
        bugs = self.report.get_bug_reports(None)
        assert 'bugs' in bugs
    
    def test_get_bug_reports_with_filter(self):
        from src.core.report_service import BugFilter
        
        filters = BugFilter(status="open", limit=10, offset=0)
        bugs = self.report.get_bug_reports(filters)
        
        assert 'bugs' in bugs
    
    def test_get_test_summary(self):
        from src.core.report_service import TestFilter
        
        summary = self.report.get_test_summary(TestFilter())
        assert hasattr(summary, 'passed')
        assert hasattr(summary, 'failed')
    
    def test_aggregate_by_project(self):
        from src.core.report_service import TestFilter
        
        result = self.report.aggregate_by_project(TestFilter())
        assert isinstance(result, list)
    
    def test_aggregate_by_version(self):
        result = self.report.aggregate_by_version("test-project")
        assert isinstance(result, list)
    
    def test_generate_report_with_batch(self):
        from src.core.result_storage_service import TestBatch
        
        batch = TestBatch(
            id="test_batch_001",
            project="test-project",
            status="completed",
            started_at=datetime.now(),
            completed_at=datetime.now(),
            duration=10.0
        )
        
        self.storage.save_batch(batch)
        
        from src.core.result_storage_service import TestCaseResult
        result = TestCaseResult(
            id="",
            test_id="test_batch_001",
            case_id="TC-001",
            case_name="测试",
            status="passed",
            duration=1.0
        )
        self.storage.save_case_result(result)
        
        report = self.report.generate_report("test_batch_001")
        
        assert report.test_id == "test_batch_001"
        assert report.status == "completed"


class TestDatabaseManager:
    """测试DatabaseManager"""
    
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test.db")
    
    def teardown_method(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_database_created(self):
        from src.core.result_storage_service import DatabaseManager
        
        db = DatabaseManager(self.db_path)
        
        assert os.path.exists(self.db_path)
    
    def test_tables_created(self):
        from src.core.result_storage_service import DatabaseManager
        import sqlite3
        
        db = DatabaseManager(self.db_path)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        assert 'test_batches' in tables
        assert 'test_results' in tables
        assert 'bug_reports' in tables


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
