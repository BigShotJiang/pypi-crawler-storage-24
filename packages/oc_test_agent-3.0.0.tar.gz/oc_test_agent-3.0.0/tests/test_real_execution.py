"""
test-agent v3.0 真正执行能力测试

测试真正的测试执行能力：
1. 测试执行后，test_results表有记录
2. 用例级结果被正确保存
3. 报告包含真实的测试结果数据
"""

import pytest
import requests
import time
import os
import sqlite3
import subprocess
import threading


BASE_URL = os.environ.get("TEST_AGENT_API_URL", "http://localhost:8001")
API_KEY = os.environ.get("TEST_AGENT_API_KEY", "test-agent-secret")


class HTTPTestServer:
    """HTTP测试服务器管理器"""
    
    def __init__(self, host="127.0.0.1", port=8001):
        self.host = host
        self.port = port
        self.process = None
        self.base_url = f"http://{host}:{port}"
    
    def start(self, timeout=30):
        env = os.environ.copy()
        env["PYTHONPATH"] = os.getcwd()
        
        self.process = subprocess.Popen(
            ["python3", "-m", "uvicorn", "src.api:app", "--host", self.host, "--port", str(self.port)],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=os.getcwd()
        )
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                response = requests.get(f"{self.base_url}/health", timeout=1)
                if response.status_code == 200:
                    return True
            except:
                time.sleep(0.5)
        return False
    
    def stop(self):
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except:
                self.process.kill()


@pytest.fixture(scope="module")
def test_server():
    server = HTTPTestServer(host="127.0.0.1", port=8001)
    if not server.start(timeout=30):
        pytest.skip("无法启动HTTP测试服务器")
    yield server
    server.stop()


@pytest.fixture
def api_client(test_server):
    class APIClient:
        def __init__(self, base_url, api_key):
            self.base_url = base_url
            self.api_key = api_key
            self.headers = {"X-API-Key": api_key}
        
        def post(self, path, json=None):
            return requests.post(f"{self.base_url}{path}", json=json, headers=self.headers)
        
        def get(self, path):
            return requests.get(f"{self.base_url}{path}", headers=self.headers)
    
    return APIClient(test_server.base_url, API_KEY)


@pytest.fixture
def db_path(test_server):
    """获取测试数据库路径"""
    return os.path.join(os.getcwd(), "state", "test_results.db")


class TestRealExecution:
    """真正执行能力测试"""
    
    def test_execution_creates_test_results(self, api_client, db_path):
        """测试执行后必须创建test_results记录"""
        
        # 执行测试
        payload = {
            "project": "test-execution",
            "subsystems": [
                {"name": "test-agent", "version": "v1.0.0"}
            ],
            "test_cases_version": "v1.0"
        }
        
        response = api_client.post("/api/v1/tests/execute", json=payload)
        assert response.status_code in [200, 202], f"执行失败: {response.status_code}"
        
        data = response.json()
        test_id = data.get("test_id")
        assert test_id, "响应缺少test_id"
        
        # 等待测试完成
        time.sleep(5)
        
        # 查询test_results表，必须有记录
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM test_results WHERE test_id = ?", (test_id,))
        count = cursor.fetchone()[0]
        
        conn.close()
        
        assert count > 0, f"测试执行后test_results表为空！test_id={test_id}，这意味着测试没有真正执行"
    
    def test_results_have_case_data(self, api_client, db_path):
        """测试结果必须包含用例级数据"""
        
        # 执行测试
        payload = {
            "project": "test-case-data",
            "subsystems": [
                {"name": "test-agent", "version": "v1.0.0"}
            ]
        }
        
        response = api_client.post("/api/v1/tests/execute", json=payload)
        assert response.status_code in [200, 202]
        
        data = response.json()
        test_id = data.get("test_id")
        
        time.sleep(5)
        
        # 检查test_results表有case_id字段
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT case_id, case_name, status, duration FROM test_results WHERE test_id = ?", (test_id,))
        rows = cursor.fetchall()
        
        conn.close()
        
        assert len(rows) > 0, f"test_results表没有用例数据！test_id={test_id}"
        
        for row in rows:
            case_id, case_name, status, duration = row
            assert case_id, "case_id不能为空"
            assert status in ["passed", "failed", "error", "skipped"], f"无效的status: {status}"
    
    def test_report_has_real_summary(self, api_client, db_path):
        """测试报告必须包含真实汇总数据"""
        
        # 执行测试
        payload = {
            "project": "test-summary",
            "subsystems": [
                {"name": "test-agent", "version": "v1.0.0"}
            ]
        }
        
        response = api_client.post("/api/v1/tests/execute", json=payload)
        assert response.status_code in [200, 202]
        
        data = response.json()
        test_id = data.get("test_id")
        
        time.sleep(5)
        
        # 获取报告
        response = api_client.get(f"/api/v1/tests/{test_id}/report")
        assert response.status_code == 200
        
        report = response.json()
        summary = report.get("data", {}).get("summary", {})
        
        # 汇总不能全为0
        total = summary.get("total", 0)
        passed = summary.get("passed", 0)
        failed = summary.get("failed", 0)
        
        assert total > 0, f"报告的total为0，测试没有真正执行！"
        assert passed + failed + summary.get("errors", 0) + summary.get("skipped", 0) == total, "汇总数据不一致"
    
    def test_results_api_returns_data(self, api_client, db_path):
        """results API必须返回真实数据"""
        
        # 先执行一个测试
        payload = {
            "project": "test-results-api",
            "subsystems": [
                {"name": "test-agent", "version": "v1.0.0"}
            ]
        }
        
        response = api_client.post("/api/v1/tests/execute", json=payload)
        assert response.status_code in [200, 202]
        
        time.sleep(5)
        
        # 查询results API
        response = api_client.get("/api/v1/results")
        assert response.status_code == 200
        
        data = response.json()
        results = data.get("data", {}).get("results", [])
        
        assert len(results) > 0, "results API返回空数据，测试没有真正执行"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
