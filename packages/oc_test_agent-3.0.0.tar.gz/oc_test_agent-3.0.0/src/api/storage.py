"""TODO存储接口抽象 - 便于未来迁移到todo-core"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional


class ITodoStorage(ABC):
    """TODO存储接口 - 便于未来迁移到todo-core"""
    
    @abstractmethod
    def list_todos(self, filters: Optional[Dict] = None) -> List[Dict]:
        pass
    
    @abstractmethod
    def get_todo(self, todo_id: str) -> Optional[Dict]:
        pass
    
    @abstractmethod
    def create_todo(self, data: Dict) -> str:
        pass
    
    @abstractmethod
    def update_todo(self, todo_id: str, data: Dict) -> bool:
        pass
    
    @abstractmethod
    def delete_todo(self, todo_id: str) -> bool:
        pass


class TodoStorageAdapter(ITodoStorage):
    """TodoStorage适配器 - 适配现有TodoStorage"""
    
    def __init__(self, storage):
        self.storage = storage
    
    def list_todos(self, filters: Optional[Dict] = None) -> List[Dict]:
        todos = self.storage.list(
            receiver=filters.get("receiver") if filters else None,
            status=filters.get("status") if filters else None,
        )
        return [dict(todo) for todo in todos]
    
    def get_todo(self, todo_id: str) -> Optional[Dict]:
        todo = self.storage.get(todo_id)
        return dict(todo) if todo else None
    
    def create_todo(self, data: Dict) -> str:
        import uuid
        todo_id = f"TODO-{uuid.uuid4().hex[:8]}"
        data["id"] = todo_id
        success, result = self.storage.add(data)
        if success:
            return todo_id
        raise Exception(result)
    
    def update_todo(self, todo_id: str, data: Dict) -> bool:
        if "status" in data:
            return self.storage.update_status(todo_id, data["status"])
        return False
    
    def delete_todo(self, todo_id: str) -> bool:
        return self.storage.delete(todo_id)


def get_storage() -> ITodoStorage:
    """获取TODO存储实例"""
    from src.core.todo_queue_manager import TodoQueueManager
    storage = TodoQueueManager()._get_storage()
    return TodoStorageAdapter(storage)
