"""版本管理API路由"""
import os
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Optional, List

VERSIONS_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "state", "versions.db")


def get_db():
    """获取数据库连接"""
    db_dir = os.path.dirname(VERSIONS_DB_PATH)
    os.makedirs(db_dir, exist_ok=True)
    conn = sqlite3.connect(VERSIONS_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """初始化数据库"""
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version TEXT NOT NULL UNIQUE,
            project_id TEXT DEFAULT 'default',
            git_commit_hash TEXT,
            manifest TEXT,
            test_report TEXT,
            status TEXT DEFAULT 'registered',
            registered_at TEXT NOT NULL,
            released_at TEXT,
            updated_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()
