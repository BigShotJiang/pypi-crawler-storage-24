"""API服务入口"""
import os
import re
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, FastAPI, HTTPException, Query
from pydantic import BaseModel, field_validator


router = APIRouter(prefix="/api/v1/versions", tags=["versions"])

VERSIONS_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "state", "versions.db")

SEMVER_PATTERN = re.compile(r'^\d+\.\d+\.\d+$')


class VersionCreate(BaseModel):
    version: str
    project_id: str = "default"
    git_commit_hash: Optional[str] = None
    manifest: Optional[str] = None

    @field_validator('version')
    @classmethod
    def validate_version(cls, v):
        if not v or not v.strip():
            raise ValueError('Version cannot be empty')
        if not SEMVER_PATTERN.match(v):
            raise ValueError('Version must be in semver format (e.g., 1.0.0)')
        return v


class VersionUpdate(BaseModel):
    version: Optional[str] = None
    git_commit_hash: Optional[str] = None
    manifest: Optional[str] = None
    test_report: Optional[str] = None

    @field_validator('version')
    @classmethod
    def validate_version(cls, v):
        if v is not None:
            if not v or not v.strip():
                raise ValueError('Version cannot be empty')
            if not SEMVER_PATTERN.match(v):
                raise ValueError('Version must be in semver format (e.g., 1.0.0)')
        return v


class VersionResponse(BaseModel):
    id: int
    version: str
    project_id: str
    git_commit_hash: Optional[str]
    manifest: Optional[str]
    test_report: Optional[str]
    status: str
    registered_at: str
    released_at: Optional[str]
    updated_at: str


def get_db():
    """获取数据库连接"""
    db_dir = os.path.dirname(VERSIONS_DB_PATH)
    os.makedirs(db_dir, exist_ok=True)
    conn = sqlite3.connect(VERSIONS_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """初始化数据库"""
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version TEXT NOT NULL UNIQUE,
            project_id TEXT DEFAULT 'default',
            git_commit_hash TEXT,
            manifest TEXT,
            test_report TEXT,
            status TEXT DEFAULT 'registered',
            registered_at TEXT NOT NULL,
            released_at TEXT,
            updated_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


init_db()


def create_app():
    """创建FastAPI应用"""
    init_db()
    app = FastAPI(title="conf-man API", version="2.0.0")
    app.include_router(router)
    return app


app = create_app()


@router.post("", response_model=VersionResponse, status_code=201)
def register_version(version: VersionCreate):
    """TC-v2-E001: 登记新版本"""
    conn = get_db()
    now = datetime.now().isoformat()
    try:
        conn.execute(
            """INSERT INTO versions (version, project_id, git_commit_hash, manifest, registered_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (version.version, version.project_id, version.git_commit_hash, version.manifest, now, now)
        )
        conn.commit()
        version_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="Version already exists")
    finally:
        conn.close()
    
    conn = get_db()
    row = conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
    conn.close()
    return dict(row)


@router.get("", response_model=List[VersionResponse])
def list_versions(
    project_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: Optional[int] = Query(None)
):
    """TC-v2-E003: 列出版本"""
    conn = get_db()
    query = "SELECT * FROM versions WHERE 1=1"
    params = []
    if project_id:
        query += " AND project_id = ?"
        params.append(project_id)
    if status:
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY id DESC"
    if limit:
        query += f" LIMIT {limit}"
    
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(row) for row in rows]


@router.get("/{version_id}", response_model=VersionResponse)
def get_version(version_id: int):
    """TC-v2-E005: 获取版本详情"""
    conn = get_db()
    row = conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Version not found")
    return dict(row)


@router.put("/{version_id}", response_model=VersionResponse)
def update_version(version_id: int, version: VersionUpdate):
    """TC-v2-E007: 更新版本"""
    conn = get_db()
    existing = conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Version not found")
    
    updates = []
    params = []
    if version.version is not None:
        updates.append("version = ?")
        params.append(version.version)
    if version.git_commit_hash is not None:
        updates.append("git_commit_hash = ?")
        params.append(version.git_commit_hash)
    if version.manifest is not None:
        updates.append("manifest = ?")
        params.append(version.manifest)
    if version.test_report is not None:
        updates.append("test_report = ?")
        params.append(version.test_report)
    
    updates.append("updated_at = ?")
    params.append(datetime.now().isoformat())
    params.append(version_id)
    
    conn.execute(f"UPDATE versions SET {', '.join(updates)} WHERE id = ?", params)
    conn.commit()
    conn.close()
    
    conn = get_db()
    row = conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
    conn.close()
    return dict(row)


@router.post("/{version_id}/release")
def trigger_release(version_id: int):
    """TC-v2-E008: 触发发布"""
    conn = get_db()
    row = conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Version not found")
    
    if row["status"] == "released":
        conn.close()
        raise HTTPException(status_code=400, detail="Version already released")
    
    conn.execute(
        "UPDATE versions SET status = ?, released_at = ?, updated_at = ? WHERE id = ?",
        ("released", datetime.now().isoformat(), datetime.now().isoformat(), version_id)
    )
    conn.commit()
    conn.close()
    return {"success": True, "status": "released"}


@router.delete("/{version_id}")
def delete_version(version_id: int):
    """TC-v2-E010: 删除版本"""
    conn = get_db()
    row = conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Version not found")
    
    conn.execute("DELETE FROM versions WHERE id = ?", (version_id,))
    conn.commit()
    conn.close()
    return {"success": True}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("src.api.serve:app", host="0.0.0.0", port=8002, reload=True)
