"""TODO API路由"""
from typing import Dict, Optional
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from src.api.storage import get_storage

router = APIRouter(prefix="/api/todo", tags=["todo"])


class ApiResponse(BaseModel):
    success: bool
    data: Optional[Dict] = None
    error: Optional[str] = None


class CreateTodoRequest(BaseModel):
    content: str
    priority: str = "medium"
    receiver: Optional[str] = None
    metadata: Optional[Dict] = None


class UpdateTodoRequest(BaseModel):
    content: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None


# 导出接口需要放在 {todo_id} 之前
@router.get("/export")
def export_todos() -> ApiResponse:
    """导出所有TODO数据（迁移用）"""
    try:
        storage = get_storage()
        todos = storage.list_todos()
        return ApiResponse(success=True, data={"todos": todos, "count": len(todos)})
    except Exception as e:
        return ApiResponse(success=False, error=str(e))


@router.get("/list")
def list_todos(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    receiver: Optional[str] = Query(None),
) -> ApiResponse:
    """获取TODO列表"""
    try:
        storage = get_storage()
        filters = {}
        if status:
            filters["status"] = status
        if priority:
            filters["priority"] = priority
        if receiver:
            filters["receiver"] = receiver
        todos = storage.list_todos(filters if filters else None)
        return ApiResponse(success=True, data={"todos": todos})
    except Exception as e:
        return ApiResponse(success=False, error=str(e))


@router.get("/{todo_id}")
def get_todo(todo_id: str) -> ApiResponse:
    """获取TODO详情"""
    try:
        storage = get_storage()
        todo = storage.get_todo(todo_id)
        if not todo:
            raise HTTPException(status_code=404, detail="TODO not found")
        return ApiResponse(success=True, data=todo)
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(success=False, error=str(e))


@router.post("/create")
def create_todo(request: CreateTodoRequest) -> ApiResponse:
    """创建TODO"""
    try:
        storage = get_storage()
        data = {
            "content": request.content,
            "priority": request.priority,
        }
        if request.receiver:
            data["receiver"] = request.receiver
        if request.metadata:
            data["metadata"] = request.metadata
        todo_id = storage.create_todo(data)
        return ApiResponse(success=True, data={"id": todo_id})
    except Exception as e:
        return ApiResponse(success=False, error=str(e))


@router.put("/{todo_id}")
def update_todo(todo_id: str, request: UpdateTodoRequest) -> ApiResponse:
    """更新TODO"""
    try:
        storage = get_storage()
        data = {}
        if request.content:
            data["content"] = request.content
        if request.priority:
            data["priority"] = request.priority
        if request.status:
            data["status"] = request.status
        success = storage.update_todo(todo_id, data)
        if not success:
            raise HTTPException(status_code=404, detail="TODO not found")
        return ApiResponse(success=True, data={"updated": True})
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(success=False, error=str(e))


@router.delete("/{todo_id}")
def delete_todo(todo_id: str) -> ApiResponse:
    """删除TODO"""
    try:
        storage = get_storage()
        success = storage.delete_todo(todo_id)
        if not success:
            raise HTTPException(status_code=404, detail="TODO not found")
        return ApiResponse(success=True, data={"deleted": True})
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(success=False, error=str(e))


@router.post("/{todo_id}/complete")
def complete_todo(todo_id: str) -> ApiResponse:
    """标记TODO完成"""
    try:
        storage = get_storage()
        success = storage.update_todo(todo_id, {"status": "completed"})
        if not success:
            raise HTTPException(status_code=404, detail="TODO not found")
        return ApiResponse(success=True, data={"completed": True})
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(success=False, error=str(e))


@router.post("/{todo_id}/ack")
def ack_todo(todo_id: str) -> ApiResponse:
    """确认TODO"""
    try:
        storage = get_storage()
        todo = storage.get_todo(todo_id)
        if not todo:
            raise HTTPException(status_code=404, detail="TODO not found")
        return ApiResponse(success=True, data={"acknowledged": True})
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(success=False, error=str(e))
