"""Test execution and query routes"""

import os
import json
import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from enum import Enum

logger = logging.getLogger(__name__)

from ...db.database import Database, TEST_RESULTS_DB_PATH
from ...core.result_service import ResultService
from ...models.test_result import TestStatus

router = APIRouter()


class SubsystemRequest(BaseModel):
    """子系统请求"""
    name: str
    commit: Optional[str] = None
    version: Optional[str] = None


class SubsystemStatus(str, Enum):
    """子系统同步状态"""
    PENDING = "pending"
    SYNCING = "syncing"
    SYNCED = "synced"
    FAILED = "failed"


class SubsystemResponse(BaseModel):
    """子系统响应"""
    name: str
    commit: Optional[str] = None
    version: Optional[str] = None
    status: SubsystemStatus = SubsystemStatus.PENDING
    error: Optional[str] = None


class TestExecuteRequest(BaseModel):
    project: str
    version: Optional[str] = None
    subsystems: Optional[List[SubsystemRequest]] = None
    test_type: str = "all"
    agents: Optional[List[str]] = None
    commands: Optional[List[str]] = None
    timeout: int = 3600
    test_cases_version: Optional[str] = None


class TestExecuteResponse(BaseModel):
    test_id: str
    status: str
    project: Optional[str] = None
    subsystems: Optional[List[SubsystemResponse]] = None
    created_at: Optional[str] = None


class TestDetailResponse(BaseModel):
    test_id: str
    project: str
    version: str
    status: str
    passed: int
    failed: int
    errors: int
    total: int
    duration: Optional[float] = None
    created_at: Optional[str] = None


# ==================== v3.0 API Endpoints ====================

class SubsystemInfo(BaseModel):
    name: str
    commit: Optional[str] = None
    version: Optional[str] = None
    status: Optional[str] = "pending"


class TestExecuteV3Request(BaseModel):
    project: str
    subsystems: List[SubsystemInfo]
    test_cases_version: Optional[str] = None


class TestExecuteV3Response(BaseModel):
    test_id: str
    project: str
    status: str
    subsystems: List[dict]
    started_at: Optional[str] = None


class ResultFilterRequest(BaseModel):
    project: Optional[str] = None
    version: Optional[str] = None
    case_id: Optional[str] = None
    status: Optional[str] = None
    limit: int = 20
    offset: int = 0


class BugFilterRequest(BaseModel):
    project: Optional[str] = None
    version: Optional[str] = None
    case_id: Optional[str] = None
    status: Optional[str] = None
    severity: Optional[str] = None
    limit: int = 20
    offset: int = 0


@router.post("/tests/execute", response_model=TestExecuteV3Response, status_code=202)
async def execute_test_v3(request: TestExecuteV3Request, background_tasks: BackgroundTasks):
    """Execute test with version control (v3.0)"""
    from datetime import datetime
    import uuid
    import json
    
    test_id = f"test_{datetime.now().strftime('%Y%m%d_%H')}_{uuid.uuid4().hex[:6]}"
    
    from ...core.result_storage_service import ResultStorageService, TestBatch
    storage = ResultStorageService()
    
    batch = TestBatch(
        id=test_id,
        project=request.project,
        status="running",
        test_cases_version=request.test_cases_version,
        subsystems=json.dumps([{
            "name": s.name,
            "commit": s.commit,
            "version": s.version,
            "status": "pending"
        } for s in request.subsystems]),
        started_at=datetime.now()
    )
    
    storage.save_batch(batch)
    
    def run_test():
        try:
            import json
            from ...core.code_sync_service import CodeSyncService
            code_sync = CodeSyncService()
            
            synced_subsystems = []
            project_path = None
            
            for subsystem in request.subsystems:
                result = code_sync.sync_subsystem(
                    name=subsystem.name,
                    version=subsystem.version,
                    commit=subsystem.commit
                )
                synced_subsystems.append({
                    "name": subsystem.name,
                    "commit": result.commit,
                    "version": result.version,
                    "status": result.status.value
                })
                if result.local_path:
                    project_path = result.local_path
                    print(f"[DEBUG] 代码同步返回路径: {project_path}")
            
            batch = storage.get_batch(test_id)
            if batch:
                batch.subsystems = json.dumps(synced_subsystems)
                storage.save_batch(batch)
            
            print(f"[DEBUG] project_path = '{project_path}', bool = {bool(project_path)}")
            
            test_path = project_path if (project_path and os.path.exists(project_path)) else os.getcwd()
            logger.info(f"使用测试路径: {test_path}")
            print(f"[DEBUG] 使用测试路径: {test_path}")
            
            import subprocess
            import re
            
            logger.info("开始执行pytest测试...")
            print(f"[DEBUG] 开始执行pytest测试...")
            
            # 使用TestDispatcher获取测试文件路径
            try:
                from ...core.test_dispatcher import TestDispatcher
                dispatcher = TestDispatcher()
                project = request.project
                test_paths = dispatcher.get_test_paths(project)
                logger.info(f"项目 {project} 对应的测试文件: {test_paths}")
                print(f"[DEBUG] 项目 {project} 对应的测试文件: {test_paths}")
            except Exception as e:
                logger.error(f"获取测试路径失败: {e}")
                test_paths = [
                    "tests/test_agent_daemon.py",
                    "tests/test_agent_behavior.py",
                    "tests/test_v3_0_core_services.py"
                ]
            
            # 执行pytest
            result = subprocess.run(
                ["python3", "-m", "pytest"] + test_paths + ["-v", "--tb=short", "-x", "-q"],
                cwd=test_path,
                capture_output=True,
                text=True,
                timeout=600
            )
            
            output = result.stdout + result.stderr
            logger.info(f"pytest输出: {output[:1000]}")
            print(f"[DEBUG] pytest完成: returncode={result.returncode}")
            print(f"[DEBUG] pytest输出: {output[:500]}")
            
            passed = failed = errors = total = 0
            
            passed_match = re.search(r'(\d+) passed', output)
            if passed_match:
                passed = int(passed_match.group(1))
            
            failed_match = re.search(r'(\d+) failed', output)
            if failed_match:
                failed = int(failed_match.group(1))
            
            errors_match = re.search(r'(\d+) error', output)
            if errors_match:
                errors = int(errors_match.group(1))
            
            total = passed + failed + errors
            
            test_status = "passed" if failed == 0 and errors == 0 else "failed"
            
            from ...core.result_storage_service import TestCaseResult
            case_result = TestCaseResult(
                id=str(uuid.uuid4()),
                test_id=test_id,
                case_id="FULL-TEST-SUITE",
                case_name="Full Test Suite",
                status=test_status,
                duration=float(result.returncode or 0),
                error_message=output[:2000] if result.returncode != 0 else None,
                executed_at=datetime.now()
            )
            storage.save_case_result(case_result)
            
            batch = storage.get_batch(test_id)
            if batch:
                batch.passed = passed
                batch.failed = failed
                batch.errors = errors
                batch.total = total
                import json
                batch.summary = json.dumps({
                    "passed": passed,
                    "failed": failed,
                    "errors": errors,
                    "total": total
                })
                storage.save_batch(batch)
            
            logger.info(f"测试完成: passed={passed}, failed={failed}, errors={errors}, total={total}")
            print(f"[DEBUG] 测试完成: passed={passed}, failed={failed}, errors={errors}, total={total}")
            
            storage.update_batch_status(test_id, "completed")
        except Exception as e:
            print(f"Test execution failed: {e}")
            import traceback
            traceback.print_exc()
            storage.update_batch_status(test_id, "failed")
    
    run_test()
    # background_tasks.add_task(run_test)
    
    resolved_subsystems = []
    for s in request.subsystems:
        commit = s.commit
        status = s.status or "pending"
        if s.version and not commit:
            try:
                from ...core.code_sync_service import CodeSyncService
                code_sync = CodeSyncService()
                commit = code_sync.get_commit_from_version(s.name, s.version)
            except Exception:
                pass
        resolved_subsystems.append({
            "name": s.name,
            "commit": commit,
            "version": s.version,
            "status": status
        })
    
    return TestExecuteV3Response(
        test_id=test_id,
        project=request.project,
        status="running",
        subsystems=resolved_subsystems,
        started_at=datetime.now().isoformat()
    )


@router.get("/results")
async def get_results_v3(
    project: Optional[str] = None,
    version: Optional[str] = None,
    case_id: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 20,
    offset: int = 0
):
    """Get test results (v3.0)"""
    from ...core.result_storage_service import ResultStorageService
    from ...core.report_service import ReportService, ResultFilter
    
    storage = ResultStorageService()
    report_svc = ReportService(storage)
    
    filters = ResultFilter(
        project=project,
        version=version,
        case_id=case_id,
        status=status,
        limit=limit,
        offset=offset
    )
    
    results = report_svc.get_test_results(filters)
    
    return {
        "success": True,
        "data": results
    }


@router.get("/bugs")
async def get_bugs_v3(
    project: Optional[str] = None,
    version: Optional[str] = None,
    case_id: Optional[str] = None,
    status: Optional[str] = None,
    severity: Optional[str] = None,
    limit: int = 20,
    offset: int = 0
):
    """Get bug reports (v3.0)"""
    from ...core.report_service import ReportService, BugFilter
    
    from ...core.result_storage_service import ResultStorageService
    storage = ResultStorageService()
    report_svc = ReportService(storage)
    
    filters = BugFilter(
        project=project,
        version=version,
        case_id=case_id,
        status=status,
        severity=severity,
        limit=limit,
        offset=offset
    )
    
    results = report_svc.get_bug_reports(filters)
    
    return {
        "success": True,
        "data": results
    }


@router.get("/tests/{test_id}/report")
async def get_test_report(test_id: str, include_details: bool = False):
    """Get test report (v3.0)"""
    from ...core.result_storage_service import ResultStorageService
    from ...core.report_service import ReportService
    
    storage = ResultStorageService()
    report_svc = ReportService(storage)
    
    try:
        report = report_svc.generate_report(test_id, include_details)
        return {
            "success": True,
            "data": {
                "test_id": report.test_id,
                "project": report.project,
                "status": report.status,
                "subsystems": report.subsystems,
                "summary": report.summary,
                "report_git_commit": report.report_git_commit,
                "bugs": report.bugs,
                "duration": report.duration,
                "started_at": report.started_at,
                "completed_at": report.completed_at
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/cases/{case_id}/history")
async def get_case_history(case_id: str, limit: int = 10, offset: int = 0):
    """Get case execution history (v3.0)"""
    from ...core.result_storage_service import ResultStorageService
    from ...core.report_service import ReportService
    
    storage = ResultStorageService()
    report_svc = ReportService(storage)
    
    page = (offset // limit) + 1
    result = report_svc.get_case_history(case_id, page, limit)
    
    return {
        "success": True,
        "data": {
            "case_id": case_id,
            "history": [
                {
                    "result_id": h.result_id,
                    "test_id": h.test_id,
                    "version": h.version,
                    "status": h.status,
                    "duration": h.duration,
                    "executed_at": h.executed_at
                }
                for h in result.history
            ],
            "total": result.total,
            "limit": limit,
            "offset": offset
        }
    }


@router.get("/cases/{case_id}/statistics")
async def get_case_statistics(case_id: str):
    """Get case execution statistics (v3.0)"""
    from ...core.result_storage_service import ResultStorageService
    
    storage = ResultStorageService()
    
    stats = storage.get_case_statistics(case_id)
    
    return {
        "success": True,
        "data": {
            "case_id": stats.case_id,
            "total_runs": stats.total_runs,
            "passed_count": stats.passed_count,
            "failed_count": stats.failed_count,
            "error_count": stats.error_count,
            "pass_rate": stats.pass_rate,
            "avg_duration": stats.avg_duration,
            "last_executed": stats.last_executed.isoformat() if stats.last_executed else None,
            "first_executed": stats.first_executed.isoformat() if stats.first_executed else None
        }
    }


@router.get("/tests")
async def list_tests_v3(
    project: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 20,
    offset: int = 0
):
    """List test batches (v3.0)"""
    from ...core.result_storage_service import ResultStorageService
    
    storage = ResultStorageService()
    
    result = storage.get_all_batches(
        project=project,
        status=status,
        limit=limit,
        offset=offset
    )
    
    return {
        "success": True,
        "data": result
    }
