"""版本管理CLI命令"""
import click
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api.version_routes import get_db, init_db


@click.group()
def version_group():
    """版本管理命令组"""
    pass


@version_group.command("register")
@click.option("--version", required=True, help="版本号")
@click.option("--project", default="default", help="项目ID")
@click.option("--manifest", default="", help="版本清单文件路径")
@click.option("--test-report", default="", help="测试报告文件路径")
@click.option("--git-commit", default="", help="Git commit hash")
def register_cmd(version, project, manifest, test_report, git_commit):
    """登记新版本"""
    init_db()
    conn = get_db()
    from datetime import datetime
    now = datetime.now().isoformat()
    
    try:
        cursor = conn.execute(
            """INSERT INTO versions (version, project_id, git_commit_hash, manifest, test_report, status, registered_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (version, project, git_commit, manifest, test_report, "registered", now, now)
        )
        conn.commit()
        version_id = cursor.lastrowid
        click.echo(f"版本 {version} 登记成功 (ID: {version_id})")
    except Exception as e:
        click.echo(f"错误: {str(e)}", err=True)
        sys.exit(1)
    finally:
        conn.close()


@version_group.command("list")
@click.option("--project", default=None, help="项目ID筛选")
@click.option("--status", default=None, help="状态筛选")
@click.option("--limit", default=50, help="返回数量限制")
def list_cmd(project, status, limit):
    """列出版本"""
    init_db()
    conn = get_db()
    
    query = "SELECT * FROM versions"
    conditions = []
    params = []
    
    if project:
        conditions.append("project_id = ?")
        params.append(project)
    if status:
        conditions.append("status = ?")
        params.append(status)
    
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    
    query += f" ORDER BY registered_at DESC LIMIT {limit}"
    
    results = conn.execute(query, params).fetchall()
    conn.close()
    
    if not results:
        click.echo("没有找到版本记录")
        return
    
    for row in results:
        click.echo(f"[{row['id']}] {row['version']} - {row['project_id']} - {row['status']}")


@version_group.command("show")
@click.argument("version")
def show_cmd(version):
    """显示版本详情"""
    init_db()
    conn = get_db()
    
    result = conn.execute(
        "SELECT * FROM versions WHERE version = ? OR id = ?",
        (version, version)
    ).fetchone()
    conn.close()
    
    if not result:
        click.echo(f"版本 {version} 不存在", err=True)
        sys.exit(1)
    
    click.echo(f"版本: {result['version']}")
    click.echo(f"项目: {result['project_id']}")
    click.echo(f"状态: {result['status']}")
    click.echo(f"Git Commit: {result['git_commit_hash']}")
    click.echo(f"登记时间: {result['registered_at']}")
    if result['released_at']:
        click.echo(f"发布时间: {result['released_at']}")


@version_group.command("release")
@click.option("--version", required=True, help="版本号或ID")
def release_cmd(version):
    """触发版本发布"""
    init_db()
    conn = get_db()
    
    result = conn.execute(
        "SELECT * FROM versions WHERE version = ? OR id = ?",
        (version, version)
    ).fetchone()
    
    if not result:
        click.echo(f"版本 {version} 不存在", err=True)
        sys.exit(1)
    
    if result["status"] == "released":
        click.echo(f"版本 {version} 已发布", err=True)
        sys.exit(1)
    
    from datetime import datetime
    now = datetime.now().isoformat()
    
    conn.execute(
        "UPDATE versions SET status = ?, released_at = ?, updated_at = ? WHERE id = ?",
        ("released", now, now, result["id"])
    )
    conn.commit()
    conn.close()
    
    click.echo(f"版本 {version} 已发布")


@version_group.command("compare")
@click.option("--version-a", required=True, help="版本A")
@click.option("--version-b", required=True, help="版本B")
def compare_cmd(version_a, version_b):
    """比较两个版本的差异"""
    init_db()
    conn = get_db()
    
    result_a = conn.execute("SELECT * FROM versions WHERE version = ? OR id = ?", (version_a, version_a)).fetchone()
    result_b = conn.execute("SELECT * FROM versions WHERE version = ? OR id = ?", (version_b, version_b)).fetchone()
    conn.close()
    
    if not result_a:
        click.echo(f"版本 {version_a} 不存在", err=True)
        sys.exit(1)
    if not result_b:
        click.echo(f"版本 {version_b} 不存在", err=True)
        sys.exit(1)
    
    click.echo(f"=== 版本比较 ===")
    click.echo(f"版本A: {result_a['version']} ({result_a['project_id']})")
    click.echo(f"版本B: {result_b['version']} ({result_b['project_id']})")
    click.echo(f"状态: {result_a['status']} vs {result_b['status']}")
    click.echo(f"Git: {result_a['git_commit_hash']} vs {result_b['git_commit_hash']}")


@version_group.command("tag")
@click.option("--version", required=True, help="版本号")
@click.option("--tag", required=True, help="标签名")
@click.option("--message", default="", help="标签说明")
def tag_cmd(version, tag, message):
    """为版本添加标签"""
    init_db()
    conn = get_db()
    
    result = conn.execute("SELECT * FROM versions WHERE version = ? OR id = ?", (version, version)).fetchone()
    
    if not result:
        click.echo(f"版本 {version} 不存在", err=True)
        sys.exit(1)
    
    click.echo(f"版本 {version} 已标记为 {tag}")
    if message:
        click.echo(f"说明: {message}")


@version_group.command("export")
@click.option("--version", required=True, help="版本号")
@click.option("--output", required=True, help="输出文件路径")
def export_cmd(version, output):
    """导出版本信息到文件"""
    init_db()
    conn = get_db()
    
    result = conn.execute("SELECT * FROM versions WHERE version = ? OR id = ?", (version, version)).fetchone()
    conn.close()
    
    if not result:
        click.echo(f"版本 {version} 不存在", err=True)
        sys.exit(1)
    
    import json
    data = {
        "version": result["version"],
        "project_id": result["project_id"],
        "git_commit_hash": result["git_commit_hash"],
        "manifest": result["manifest"],
        "status": result["status"],
        "registered_at": result["registered_at"]
    }
    
    with open(output, "w") as f:
        json.dump(data, f, indent=2)
    click.echo(f"版本 {version} 已导出到 {output}")


@version_group.command("import")
@click.option("--file", required=True, help="导入文件路径")
def import_cmd(file):
    """从文件导入版本信息"""
    if not os.path.exists(file):
        click.echo(f"文件 {file} 不存在", err=True)
        sys.exit(1)
    
    import json
    with open(file, "r") as f:
        data = json.load(f)
    
    init_db()
    conn = get_db()
    from datetime import datetime
    now = datetime.now().isoformat()
    
    try:
        cursor = conn.execute(
            """INSERT INTO versions (version, project_id, git_commit_hash, manifest, status, registered_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (data.get("version"), data.get("project_id"), data.get("git_commit_hash"), 
             data.get("manifest"), "imported", now, now)
        )
        conn.commit()
        click.echo(f"版本 {data.get('version')} 已导入")
    except Exception as e:
        click.echo(f"导入失败: {str(e)}", err=True)
        sys.exit(1)
    finally:
        conn.close()


@version_group.command("rollback")
@click.option("--version", required=True, help="要回滚的版本")
@click.option("--to", required=True, help="回滚到目标版本")
def rollback_cmd(version, to):
    """回滚版本"""
    init_db()
    conn = get_db()
    
    result = conn.execute("SELECT * FROM versions WHERE version = ? OR id = ?", (version, version)).fetchone()
    
    if not result:
        click.echo(f"版本 {version} 不存在", err=True)
        sys.exit(1)
    
    from datetime import datetime
    now = datetime.now().isoformat()
    
    conn.execute(
        "UPDATE versions SET status = ?, updated_at = ? WHERE id = ?",
        (f"rolledback-to-{to}", now, result["id"])
    )
    conn.commit()
    conn.close()
    
    click.echo(f"版本 {version} 已回滚到 {to}")


if __name__ == "__main__":
    version_group()
