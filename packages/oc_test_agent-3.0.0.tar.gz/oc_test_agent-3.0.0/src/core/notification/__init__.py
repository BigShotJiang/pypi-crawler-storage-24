"""
test-agent Notification Module
"""

from .webhook import WebhookManager, WebhookConfig, WebhookPayload, get_notification_manager
from .bug_report import BugReportGenerator

class NotificationService:
    """Notification service stub for testing"""
    def __init__(self, storage=None):
        self.storage = storage

__all__ = ["WebhookManager", "WebhookConfig", "WebhookPayload", "WebhookManager", "BugReportGenerator", "get_notification_manager", "NotificationService"]
