"""TODO模块接口定义。

定义 TODO 系统相关的抽象接口，支持依赖注入和测试。
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Protocol
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime


class ITodoStorage(Protocol):
    """TODO存储接口"""
    
    @abstractmethod
    def add(self, todo: dict) -> tuple[bool, str]:
        """添加TODO
        
        Args:
            todo: TODO字典
        
        Returns:
            (success, todo_id): 成功返回(True, id)，失败返回(False, error_msg)
        """
        ...
    
    @abstractmethod
    def get(self, todo_id: str) -> Optional[dict]:
        """获取TODO
        
        Args:
            todo_id: TODO ID
        
        Returns:
            TODO字典，不存在返回None
        """
        ...
    
    @abstractmethod
    def list(
        self,
        receiver: Optional[str] = None,
        status: Optional[str] = None,
        unread_only: bool = False
    ) -> List[dict]:
        """列出TODO
        
        Args:
            receiver: 接收者筛选
            status: 状态筛选
            unread_only: 只返回未读
        
        Returns:
            TODO列表
        """
        ...
    
    @abstractmethod
    def update(self, todo_id: str, updates: dict) -> bool:
        """更新TODO
        
        Args:
            todo_id: TODO ID
            updates: 更新内容
        
        Returns:
            是否成功
        """
        ...
    
    @abstractmethod
    def delete(self, todo_id: str) -> bool:
        """删除TODO
        
        Args:
            todo_id: TODO ID
        
        Returns:
            是否成功
        """
        ...
    
    @abstractmethod
    def mark_read(self, todo_id: str, receiver: str) -> bool:
        """标记已读
        
        Args:
            todo_id: TODO ID
            receiver: 接收者
        
        Returns:
            是否成功
        """
        ...


class ITodoIdGenerator(Protocol):
    """TODO ID生成器接口"""
    
    @abstractmethod
    def generate(self, creator: Optional[str] = None, receiver: Optional[str] = None) -> str:
        """生成TODO ID
        
        Args:
            creator: 创建者
            receiver: 接收者
        
        Returns:
            TODO ID字符串
        """
        ...
    
    @abstractmethod
    def parse(self, todo_id: str) -> Optional[Dict[str, Any]]:
        """解析TODO ID
        
        Args:
            todo_id: TODO ID
        
        Returns:
            解析后的字典，包含 creator, receiver, timestamp 等
        """
        ...
    
    @abstractmethod
    def is_valid(self, todo_id: str) -> bool:
        """验证TODO ID格式
        
        Args:
            todo_id: TODO ID
        
        Returns:
            是否有效
        """
        ...


@dataclass
class TodoItem:
    """TODO数据模型"""
    id: str
    content: str
    creator: str
    receiver: str
    priority: str = "medium"
    status: str = "pending"
    created_at: str = None
    updated_at: str = None
    read: bool = False
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()
        if self.updated_at is None:
            self.updated_at = self.created_at


@dataclass
class TodoQueueItem:
    """队列TODO项"""
    id: str
    content: str
    from_agent: str
    to_agent: str
    priority: str = "medium"
    created_at: str = None
    read: bool = False
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()
