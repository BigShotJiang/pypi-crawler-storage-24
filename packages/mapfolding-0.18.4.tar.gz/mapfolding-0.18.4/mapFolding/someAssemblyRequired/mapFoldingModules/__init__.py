"""Multidimensional map folding."""
