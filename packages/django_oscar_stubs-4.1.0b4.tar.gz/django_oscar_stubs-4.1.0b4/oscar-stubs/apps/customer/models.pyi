from oscar.apps.customer.abstract_models import AbstractProductAlert

class ProductAlert(AbstractProductAlert):
    id: int
