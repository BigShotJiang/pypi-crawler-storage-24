class Error(Exception):
    def __init__(self, msg, pos=None):
        self.msg = msg
        self.pos = pos
    def __str__(self):
        return f"{self.msg} at {self.pos}" if self.pos is not None else self.msg


class Token:
    def __init__(self, t, v=None, pos=0):
        self.t = t
        self.v = v
        self.pos = pos


class Lexer:
    def __init__(self, text):
        self.text = text
        self.i = 0

    def peek(self):
        return self.text[self.i] if self.i < len(self.text) else ""

    def advance(self):
        self.i += 1

    def tokenize(self):
        tokens = []
        while self.i < len(self.text):
            c = self.peek()

            if c.isspace():
                self.advance()

            elif c.isdigit():
                start = self.i
                num = ""
                while self.peek().isdigit():
                    num += self.peek()
                    self.advance()

                if self.peek() == ".":
                    self.advance()
                    dec = ""
                    while self.peek().isdigit():
                        dec += self.peek()
                        self.advance()
                    if dec == "":
                        dec = "0"
                    denom = 10 ** len(dec)
                    n = int(num) * denom + int(dec)
                    tokens.append(Token("NUM", (n, denom), start))
                else:
                    tokens.append(Token("NUM", (int(num), 1), start))

            elif c == '"':
                start = self.i
                self.advance()
                s = ""
                while self.peek() != '"':
                    if self.peek() == "":
                        raise Error("Unterminated string", start)
                    s += self.peek()
                    self.advance()
                self.advance()
                tokens.append(Token("STR", s, start))

            elif c.isalpha():
                start = self.i
                ident = ""
                while self.peek().isalnum() or self.peek() == "_":
                    ident += self.peek()
                    self.advance()
                tokens.append(Token("ID", ident, start))

            elif c in "+-*/%^(),{};":
                tokens.append(Token(c, None, self.i))
                self.advance()

            elif c == "=":
                start = self.i
                self.advance()
                if self.peek() == "=":
                    self.advance()
                    tokens.append(Token("==", None, start))
                else:
                    tokens.append(Token("=", None, start))

            elif c == "!":
                start = self.i
                self.advance()
                if self.peek() == "=":
                    self.advance()
                    tokens.append(Token("!=", None, start))
                else:
                    raise Error("Unexpected !", start)

            elif c == "<":
                start = self.i
                self.advance()
                if self.peek() == "=":
                    self.advance()
                    tokens.append(Token("<=", None, start))
                else:
                    tokens.append(Token("<", None, start))

            elif c == ">":
                start = self.i
                self.advance()
                if self.peek() == "=":
                    self.advance()
                    tokens.append(Token(">=", None, start))
                else:
                    tokens.append(Token(">", None, start))

            else:
                raise Error(f"Unknown char {c}", self.i)

        tokens.append(Token("EOF", None, self.i))
        return tokens


class AST: pass

class Num(AST):
    def __init__(self, v): self.v = v

class Str(AST):
    def __init__(self, v): self.v = v

class Var(AST):
    def __init__(self, n): self.n = n

class Bin(AST):
    def __init__(self, l, o, r): self.l, self.o, self.r = l, o, r

class Unary(AST):
    def __init__(self, o, e): self.o, self.e = o, e

class Assign(AST):
    def __init__(self, n, e): self.n, self.e = n, e

class Block(AST):
    def __init__(self, s): self.s = s

class If(AST):
    def __init__(self, c, t, e): self.c, self.t, self.e = c, t, e

class While(AST):
    def __init__(self, c, b): self.c, self.b = c, b

class Func(AST):
    def __init__(self, n, p, b): self.n, self.p, self.b = n, p, b

class Call(AST):
    def __init__(self, n, a): self.n, self.a = n, a


class Parser:
    def __init__(self, tokens):
        self.t = tokens
        self.i = 0

    def peek(self):
        return self.t[self.i]

    def eat(self, t=None):
        tok = self.peek()
        if t and tok.t != t:
            raise Error("syntax error", tok.pos)
        self.i += 1
        return tok

    def parse(self):
        stmts = []
        while self.peek().t != "EOF":
            stmts.append(self.statement())
            if self.peek().t == ";":
                self.eat()
        return Block(stmts)

    def statement(self):
        tok = self.peek()

        if tok.t == "ID" and tok.v == "if":
            self.eat()
            cond = self.expr()
            then = self.block()
            elseb = None
            if self.peek().t == "ID" and self.peek().v == "else":
                self.eat()
                elseb = self.block()
            return If(cond, then, elseb)

        if tok.t == "ID" and tok.v == "while":
            self.eat()
            cond = self.expr()
            body = self.block()
            return While(cond, body)

        if tok.t == "ID" and tok.v == "def":
            self.eat()
            name = self.eat("ID").v
            self.eat("(")
            params = []
            while self.peek().t != ")":
                params.append(self.eat("ID").v)
                if self.peek().t == ",":
                    self.eat()
            self.eat(")")
            self.eat("=")
            body = self.expr()
            return Func(name, params, body)

        expr = self.expr()

        if isinstance(expr, Var) and self.peek().t == "=":
            self.eat("=")
            return Assign(expr.n, self.expr())

        return expr

    def block(self):
        if self.peek().t == "{":
            self.eat()
            stmts = []
            while self.peek().t != "}":
                stmts.append(self.statement())
                if self.peek().t == ";":
                    self.eat()
            self.eat("}")
            return Block(stmts)
        return self.statement()

    def expr(self):
        node = self.term()
        while self.peek().t in ["+","-","==","!=","<",">","<=",">="]:
            op = self.eat().t
            node = Bin(node, op, self.term())
        return node

    def term(self):
        node = self.factor()
        while self.peek().t in ["*","/","%"]:
            op = self.eat().t
            node = Bin(node, op, self.factor())
        return node

    def factor(self):
        if self.peek().t in ["+","-"]:
            op = self.eat().t
            return Unary(op, self.factor())
        return self.primary()

    def primary(self):
        tok = self.peek()

        if tok.t == "NUM":
            self.eat()
            return Num(tok.v)

        if tok.t == "STR":
            self.eat()
            return Str(tok.v)

        if tok.t == "ID":
            name = self.eat().v
            if self.peek().t == "(":
                self.eat()
                args = []
                while self.peek().t != ")":
                    args.append(self.expr())
                    if self.peek().t == ",":
                        self.eat()
                self.eat(")")
                return Call(name, args)
            return Var(name)

        if tok.t == "{":
            return self.block()

        if tok.t == "(":
            self.eat()
            e = self.expr()
            self.eat(")")
            return e

        raise Error("unexpected token", tok.pos)


class Env:
    def __init__(self):
        self.frames = [{}]
        self.funcs = {}

    def push(self):
        self.frames.append({})

    def pop(self):
        self.frames.pop()

    def set(self, k, v):
        self.frames[-1][k] = v

    def get(self, k):
        for f in reversed(self.frames):
            if k in f:
                return f[k]
        if k in self.funcs:
            return self.funcs[k]
        raise Error("undefined " + k)


env = Env()


def truth(v):
    if isinstance(v, bool): return v
    if isinstance(v, str): return len(v) > 0
    return v != 0


def eval_ast(n):
    if isinstance(n, Num):
        return n.v[0] / n.v[1]

    if isinstance(n, Str):
        return n.v

    if isinstance(n, Var):
        return env.get(n.n)

    if isinstance(n, Unary):
        v = eval_ast(n.e)
        return -v if n.o == "-" else v

    if isinstance(n, Bin):
        a = eval_ast(n.l)
        b = eval_ast(n.r)

        if n.o == "+": return a + b
        if n.o == "-": return a - b
        if n.o == "*": return a * b
        if n.o == "/": return a / b
        if n.o == "%": return a % b

        if n.o == "==": return a == b
        if n.o == "!=": return a != b
        if n.o == "<": return a < b
        if n.o == ">": return a > b
        if n.o == "<=": return a <= b
        if n.o == ">=": return a >= b

    if isinstance(n, Assign):
        v = eval_ast(n.e)
        env.set(n.n, v)
        return v

    if isinstance(n, Block):
        r = None
        for s in n.s:
            r = eval_ast(s)
        return r

    if isinstance(n, If):
        if truth(eval_ast(n.c)):
            return eval_ast(n.t)
        elif n.e:
            return eval_ast(n.e)

    if isinstance(n, While):
        r = None
        while truth(eval_ast(n.c)):
            r = eval_ast(n.b)
        return r

    if isinstance(n, Func):
        env.funcs[n.n] = (n.p, n.b)
        return None

    if isinstance(n, Call):
        if n.n == "print":
            args = [eval_ast(a) for a in n.a]
            print(*args)
            return None

        if n.n in env.funcs:
            p, b = env.funcs[n.n]
            args = [eval_ast(a) for a in n.a]
            env.push()
            for i in range(len(p)):
                env.set(p[i], args[i])
            r = eval_ast(b)
            env.pop()
            return r

        raise Error("undefined function " + n.n)


def run(code):
    lex = Lexer(code)
    tokens = lex.tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    return eval_ast(ast)


class Module:
    def run(self, code):
        return run(code)


math = Module()
