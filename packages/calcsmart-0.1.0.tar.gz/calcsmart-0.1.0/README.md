# calcsmart

Single-file math interpreter.

Usage:
import calcsmart as math
math.run("1 + 1")
