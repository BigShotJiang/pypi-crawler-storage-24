# deeptrace

A simple hello world package.

## Usage

```python
from deeptrace import hello

print(hello())
