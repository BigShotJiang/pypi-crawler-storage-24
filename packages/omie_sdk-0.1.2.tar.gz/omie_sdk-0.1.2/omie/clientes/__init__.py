from __future__ import annotations

from typing import Optional

from omie._core.base import _BaseContext
from omie._core.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride
from omie._core.retry import RetryConfig, RetryOverride
from omie.clientes.models import (
    ClienteParam,
    ConsultarClienteParam,
    ListarClientesParam,
    UpsertClienteParam,
)

_PATH = "geral/clientes"


class OmieClientes(_BaseContext):
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry:      Optional[RetryConfig]     = None,
        timeout:    Optional[TimeoutConfig]   = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        super().__init__(app_key, app_secret, retry=retry, timeout=timeout, time_range=time_range)

    def incluir_cliente(
        self,
        param: ClienteParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "IncluirCliente", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar_cliente(
        self,
        param: ClienteParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "AlterarCliente", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def consultar_cliente(
        self,
        param: ConsultarClienteParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ConsultarCliente", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def listar_clientes(
        self,
        param: Optional[ListarClientesParam] = None,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        p = param or ListarClientesParam()
        return self._http.post(
            _PATH, "ListarClientes", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def upsert_cliente(
        self,
        param: UpsertClienteParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "UpsertCliente", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )
