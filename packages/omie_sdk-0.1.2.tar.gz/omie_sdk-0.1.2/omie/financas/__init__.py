from __future__ import annotations

from typing import Optional

from omie._core.base import _BaseContext
from omie._core.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride
from omie._core.retry import RetryConfig, RetryOverride
from omie.financas.models import (
    ConsultarContaPagarParam,
    ConsultarContaReceberParam,
    ContaPagarParam,
    ContaReceberParam,
    ListarContasPagarParam,
    ListarContasReceberParam,
)

_PATH_RECEBER = "financas/contareceber"
_PATH_PAGAR   = "financas/contapagar"


class OmieFinancas(_BaseContext):
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry:      Optional[RetryConfig]     = None,
        timeout:    Optional[TimeoutConfig]   = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        super().__init__(app_key, app_secret, retry=retry, timeout=timeout, time_range=time_range)

    def incluir_conta_receber(
        self,
        param: ContaReceberParam,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        return self._http.post(
            _PATH_RECEBER, "IncluirContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar_conta_receber(
        self,
        param: ContaReceberParam,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        return self._http.post(
            _PATH_RECEBER, "AlterarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def consultar_conta_receber(
        self,
        param: ConsultarContaReceberParam,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        return self._http.post(
            _PATH_RECEBER, "ConsultarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def listar_contas_receber(
        self,
        param: Optional[ListarContasReceberParam] = None,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        p = param or ListarContasReceberParam()
        return self._http.post(
            _PATH_RECEBER, "ListarContasReceber", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def incluir_conta_pagar(
        self,
        param: ContaPagarParam,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        return self._http.post(
            _PATH_PAGAR, "IncluirContaPagar", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar_conta_pagar(
        self,
        param: ContaPagarParam,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        return self._http.post(
            _PATH_PAGAR, "AlterarContaPagar", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def consultar_conta_pagar(
        self,
        param: ConsultarContaPagarParam,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        return self._http.post(
            _PATH_PAGAR, "ConsultarContaPagar", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def listar_contas_pagar(
        self,
        param: Optional[ListarContasPagarParam] = None,
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        p = param or ListarContasPagarParam()
        return self._http.post(
            _PATH_PAGAR, "ListarContasPagar", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )
