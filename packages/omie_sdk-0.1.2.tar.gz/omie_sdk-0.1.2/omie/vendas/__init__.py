from __future__ import annotations

from typing import Optional

from omie._core.base import _BaseContext
from omie._core.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride
from omie._core.retry import RetryConfig, RetryOverride
from omie.vendas.models import (
    ConsultarPedidoParam,
    ListarPedidosParam,
    PedidoVendaParam,
)

_PATH = "produtos/pedido"


class OmieVendas(_BaseContext):
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry:      Optional[RetryConfig]     = None,
        timeout:    Optional[TimeoutConfig]   = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        super().__init__(app_key, app_secret, retry=retry, timeout=timeout, time_range=time_range)

    def incluir_pedido(
        self,
        param: PedidoVendaParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "IncluirPedido", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar_pedido(
        self,
        param: PedidoVendaParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "AlterarPedidoVenda", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def consultar_pedido(
        self,
        param: ConsultarPedidoParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ConsultarPedido", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def listar_pedidos(
        self,
        param: Optional[ListarPedidosParam] = None,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        p = param or ListarPedidosParam()
        return self._http.post(
            _PATH, "ListarPedidos", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )
