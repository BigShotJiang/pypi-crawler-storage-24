from __future__ import annotations

from typing import Optional

from omie._core.base import _BaseContext
from omie._core.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride
from omie._core.retry import RetryConfig, RetryOverride
from omie.produtos.models import (
    ConsultarProdutoParam,
    ListarProdutosParam,
    ProdutoParam,
)

_PATH = "produtos/produto"


class OmieProdutos(_BaseContext):
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry:      Optional[RetryConfig]     = None,
        timeout:    Optional[TimeoutConfig]   = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        super().__init__(app_key, app_secret, retry=retry, timeout=timeout, time_range=time_range)

    def incluir_produto(
        self,
        param: ProdutoParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "IncluirProduto", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar_produto(
        self,
        param: ProdutoParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "AlterarProduto", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def consultar_produto(
        self,
        param: ConsultarProdutoParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ConsultarProduto", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def listar_produtos(
        self,
        param: Optional[ListarProdutosParam] = None,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        p = param or ListarProdutosParam()
        return self._http.post(
            _PATH, "ListarProdutos", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )
