from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Optional

import requests

from omie.errors import OmieClientError, OmieServerError, parse_omie_response
from omie._core.retry import RetryConfig, RetryOverride


@dataclass
class TimeoutConfig:
    connect: float = 5.0
    read:    float = 30.0

    def as_tuple(self) -> tuple[float, float]:
        return (self.connect, self.read)


@dataclass
class TimeoutOverride:
    connect: Optional[float] = None
    read:    Optional[float] = None

    def apply_to(self, base: TimeoutConfig) -> TimeoutConfig:
        return TimeoutConfig(
            connect = self.connect if self.connect is not None else base.connect,
            read    = self.read    if self.read    is not None else base.read,
        )


@dataclass
class TimeRangeConfig:
    min_interval: float = 0.0


@dataclass
class TimeRangeOverride:
    min_interval: Optional[float] = None

    def apply_to(self, base: TimeRangeConfig) -> TimeRangeConfig:
        return TimeRangeConfig(
            min_interval = self.min_interval if self.min_interval is not None else base.min_interval,
        )


class OmieHttp:
    """Executa chamadas autenticadas à API Omie com retry, throttle e timeout configuráveis."""

    BASE_URL = "https://app.omie.com.br/api/v1"
    HEADERS  = {"Content-Type": "application/json"}

    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry:      Optional[RetryConfig]      = None,
        timeout:    Optional[TimeoutConfig]    = None,
        time_range: Optional[TimeRangeConfig]  = None,
    ) -> None:
        if not app_key or not app_secret:
            raise ValueError("app_key e app_secret são obrigatórios")
        self._app_key    = app_key
        self._app_secret = app_secret
        self._retry      = retry      if retry      is not None else RetryConfig()
        self._timeout    = timeout    if timeout    is not None else TimeoutConfig()
        self._time_range = time_range if time_range is not None else TimeRangeConfig()
        self._last_call  = 0.0

    def post(
        self,
        path: str,
        call: str,
        param: list[dict[str, Any]],
        *,
        retry:      Optional[RetryOverride]      = None,
        timeout:    Optional[TimeoutOverride]    = None,
        time_range: Optional[TimeRangeOverride]  = None,
    ) -> dict:
        cfg_retry      = retry.apply_to(self._retry)           if retry      else self._retry
        cfg_timeout    = timeout.apply_to(self._timeout)       if timeout    else self._timeout
        cfg_time_range = time_range.apply_to(self._time_range) if time_range else self._time_range

        url     = f"{self.BASE_URL}/{path.strip('/')}/"
        payload = json.dumps({
            "app_key":    self._app_key,
            "app_secret": self._app_secret,
            "call":       call,
            "param":      param,
        })

        last_exc: BaseException = RuntimeError("nenhuma tentativa realizada")

        for attempt in range(1, cfg_retry.attempts + 1):
            self._throttle(cfg_time_range)
            try:
                response = requests.post(
                    url,
                    headers=self.HEADERS,
                    data=payload,
                    timeout=cfg_timeout.as_tuple(),
                )
                try:
                    data = response.json()
                except requests.exceptions.JSONDecodeError:
                    response.raise_for_status()
                    return {}
                return parse_omie_response(data)
            except OmieClientError:
                raise
            except OmieServerError as e:
                last_exc = e
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                last_exc = e

            if attempt < cfg_retry.attempts:
                time.sleep(cfg_retry.delay_for(attempt))

        raise last_exc

    def _throttle(self, cfg: TimeRangeConfig) -> None:
        if cfg.min_interval <= 0:
            return
        elapsed = time.monotonic() - self._last_call
        wait = cfg.min_interval - elapsed
        if wait > 0:
            time.sleep(wait)
        self._last_call = time.monotonic()
