from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class BackoffStrategy(str, Enum):
    LINEAR      = "linear"
    EXPONENTIAL = "exponential"


@dataclass
class RetryConfig:
    attempts:   int             = 3
    base_delay: float           = 1.0
    max_delay:  float           = 60.0
    strategy:   BackoffStrategy = BackoffStrategy.EXPONENTIAL

    def delay_for(self, attempt: int) -> float:
        if self.strategy == BackoffStrategy.LINEAR:
            delay = self.base_delay * attempt
        else:
            delay = self.base_delay * (2 ** (attempt - 1))
        return min(delay, self.max_delay)


@dataclass
class RetryOverride:
    attempts:   Optional[int]             = None
    base_delay: Optional[float]           = None
    max_delay:  Optional[float]           = None
    strategy:   Optional[BackoffStrategy] = None

    def apply_to(self, base: RetryConfig) -> RetryConfig:
        return RetryConfig(
            attempts   = self.attempts   if self.attempts   is not None else base.attempts,
            base_delay = self.base_delay if self.base_delay is not None else base.base_delay,
            max_delay  = self.max_delay  if self.max_delay  is not None else base.max_delay,
            strategy   = self.strategy   if self.strategy   is not None else base.strategy,
        )
