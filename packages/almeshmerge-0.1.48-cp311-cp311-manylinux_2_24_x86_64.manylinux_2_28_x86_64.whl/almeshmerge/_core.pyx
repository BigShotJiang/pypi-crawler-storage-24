# distutils: language = c++

from libcpp.string cimport string
from libcpp.vector cimport vector
import json

cdef extern from "../cpp/core.hpp" namespace "almeshmerge":
    string run_merge_pipeline(
        const vector[string]& input_objs,
        const string& output_dir,
        bint split_o,
        bint split_g,
        const string& front_axis,
        const string& up_axis,
        bint right_handed,
        int atlas_max_size,
        int atlas_padding,
        bint atlas_pow2,
        bint atlas_allow_rotate_90,
        int atlas_max_count,
        float spatial_cluster_radius,
        float atlas_target_utilization,
        bint uv_repeat_exclude_merge,
        float simplify_ratio,
        const string& vertex_key_mode
    ) except +


cdef vector[string] _to_cpp_vec(list vals):
    cdef vector[string] out
    cdef object it
    for it in vals:
        out.push_back(str(it).encode("utf-8"))
    return out


def merge_pipeline(
    list input_objs,
    str output_dir,
    bint split_o,
    bint split_g,
    str front_axis,
    str up_axis,
    bint right_handed,
    int atlas_max_size,
    int atlas_padding,
    bint atlas_pow2,
    bint atlas_allow_rotate_90,
    int atlas_max_count,
    float spatial_cluster_radius,
    float atlas_target_utilization,
    bint uv_repeat_exclude_merge,
    float simplify_ratio,
    str vertex_key_mode,
):
    cdef vector[string] cpp_inputs = _to_cpp_vec(input_objs)
    cdef string result = run_merge_pipeline(
        cpp_inputs,
        output_dir.encode("utf-8"),
        split_o,
        split_g,
        front_axis.encode("utf-8"),
        up_axis.encode("utf-8"),
        right_handed,
        atlas_max_size,
        atlas_padding,
        atlas_pow2,
        atlas_allow_rotate_90,
        atlas_max_count,
        spatial_cluster_radius,
        atlas_target_utilization,
        uv_repeat_exclude_merge,
        simplify_ratio,
        vertex_key_mode.encode("utf-8"),
    )
    return json.loads(result.decode("utf-8"))
