from __future__ import annotations

"""SDK configuration primitives.

Provides typed configuration objects and helpers to centralize service
endpoints, agent metadata, and basic runtime knobs. Defaults are sourced from
``sw4rm.constants`` so applications and examples have a single source of truth.

This module supports configuration loading from multiple sources:
- Environment variables (SW4RM_* prefix)
- JSON configuration files
- YAML configuration files (requires PyYAML)
- Programmatic configuration
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional
import json
import logging
import os

from . import constants as C


@dataclass
class Endpoints:
    """Addresses for all SW4RM services.

    Router and registry are required for basic operation. Additional services
    are set to default ports matching the Rust SDK.
    """

    router_addr: str = field(default_factory=C.get_default_router_addr)
    registry_addr: str = field(default_factory=C.get_default_registry_addr)
    scheduler_addr: str = "http://localhost:50053"
    hitl_addr: str = "http://localhost:50054"
    worktree_addr: str = "http://localhost:50055"
    tool_addr: str = "http://localhost:50056"
    connector_addr: str = "http://localhost:50057"
    negotiation_addr: str = "http://localhost:50058"
    reasoning_addr: str = "http://localhost:50059"
    logging_addr: str = "http://localhost:50060"


@dataclass
class RetryPolicy:
    """Simple retry policy for unary calls."""

    max_attempts: int = 3
    initial_backoff_s: float = 0.2
    max_backoff_s: float = 2.0
    backoff_multiplier: float = 2.0


@dataclass
class AgentConfig:
    """Agent runtime configuration.

    - ``agent_id`` and ``name`` identify the agent.
    - ``endpoints`` provides service addresses.
    - ``timeout_ms`` applies to unary calls unless overridden.
    - ``retry`` controls basic retry for transient failures.
    """

    agent_id: str = "agent-1"
    name: str = "Agent"
    endpoints: Endpoints = field(default_factory=Endpoints)
    timeout_ms: int = 30000
    stream_keepalive_s: float = 60.0
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    description: Optional[str] = None
    version: str = "0.1.0"
    capabilities: list[str] = field(default_factory=list)
    heartbeat_interval_ms: int = 30000
    communication_class: int = 2
    modalities_supported: list[str] = field(
        default_factory=lambda: ["application/json"]
    )
    reasoning_connectors: list[str] = field(default_factory=list)
    public_key: Optional[bytes] = None
    metadata: dict[str, str] = field(default_factory=dict)

    @property
    def request_timeout_s(self) -> float:
        """Backward-compatible timeout in seconds."""
        return self.timeout_ms / 1000


def from_env() -> AgentConfig:
    """Construct ``AgentConfig`` using environment overrides where available.

    Uses ``AGENT_ID`` and ``AGENT_NAME`` if set, and respects the endpoint
    environment variables defined in ``sw4rm.constants``.
    """

    agent_id = os.getenv("AGENT_ID", "agent-1")
    name = os.getenv("AGENT_NAME", "Agent")
    endpoints = Endpoints()  # picks up env via default_factory
    return AgentConfig(agent_id=agent_id, name=name, endpoints=endpoints)


# ---------------------------------------------------------------------------
# Enhanced configuration system (Phase 3.6)
# ---------------------------------------------------------------------------


@dataclass
class SW4RMConfig:
    """Comprehensive SW4RM SDK configuration.

    This configuration object centralizes all SDK settings including service
    endpoints, timeouts, retry policies, observability flags, and feature flags.

    Configuration can be loaded from:
    - Environment variables (SW4RM_* prefix)
    - JSON files
    - YAML files
    - Programmatic defaults

    Attributes:
        router_addr: Address of the router service
        registry_addr: Address of the registry service
        default_timeout_ms: Default timeout for operations in milliseconds
        max_retries: Maximum number of retry attempts for failed operations
        enable_metrics: Whether to collect and export metrics
        enable_tracing: Whether to enable distributed tracing
        metrics_backend: Metrics backend selector (noop|memory|statsd|datadog)
        metrics_host: Hostname for statsd/dogstatsd backend
        metrics_port: Port for statsd/dogstatsd backend
        metrics_namespace: Optional namespace prefix for metric names
        metrics_tags: Labels attached to every metric
        metrics_sample_rate: Sample rate for histogram/counter emissions
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        feature_flags: Dictionary of feature flag name to value mappings
    """

    router_addr: str = field(default_factory=C.get_default_router_addr)
    registry_addr: str = field(default_factory=C.get_default_registry_addr)
    default_timeout_ms: int = 30000
    max_retries: int = 3
    enable_metrics: bool = True
    enable_tracing: bool = True
    metrics_backend: str = "noop"
    metrics_host: str = "localhost"
    metrics_port: int = 8125
    metrics_namespace: str = "sw4rm"
    metrics_tags: list[str] = field(default_factory=list)
    metrics_sample_rate: float = 1.0
    log_level: str = "INFO"
    feature_flags: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SW4RMConfig":
        """Create configuration from a dictionary.

        Args:
            data: Dictionary containing configuration values

        Returns:
            SW4RMConfig instance
        """
        # Extract known fields
        config_data = {}
        for field_name in [
            "router_addr",
            "registry_addr",
            "default_timeout_ms",
            "max_retries",
            "enable_metrics",
            "enable_tracing",
            "metrics_backend",
            "metrics_host",
            "metrics_port",
            "metrics_namespace",
            "metrics_tags",
            "metrics_sample_rate",
            "log_level",
            "feature_flags",
        ]:
            if field_name in data:
                config_data[field_name] = data[field_name]

        return cls(**config_data)

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to a dictionary.

        Returns:
            Dictionary representation of the configuration
        """
        return {
            "router_addr": self.router_addr,
            "registry_addr": self.registry_addr,
            "default_timeout_ms": self.default_timeout_ms,
            "max_retries": self.max_retries,
            "enable_metrics": self.enable_metrics,
            "enable_tracing": self.enable_tracing,
            "metrics_backend": self.metrics_backend,
            "metrics_host": self.metrics_host,
            "metrics_port": self.metrics_port,
            "metrics_namespace": self.metrics_namespace,
            "metrics_tags": self.metrics_tags,
            "metrics_sample_rate": self.metrics_sample_rate,
            "log_level": self.log_level,
            "feature_flags": self.feature_flags,
        }


def load_config(path: Optional[str] = None) -> SW4RMConfig:
    """Load SW4RM configuration from file or environment.

    Configuration loading order (later sources override earlier ones):
    1. Default values from SW4RMConfig dataclass
    2. Configuration file (if path provided)
    3. Environment variables (SW4RM_* prefix)

    Args:
        path: Optional path to configuration file (JSON or YAML)
              If None, only environment variables are used

    Returns:
        SW4RMConfig instance

    Raises:
        FileNotFoundError: If path is provided but file doesn't exist
        ValueError: If file format is invalid or unsupported

    Example:
        # Load from file and environment
        config = load_config("/etc/sw4rm/config.json")

        # Load from environment only
        config = load_config()

    Environment variables:
        SW4RM_ROUTER_ADDR: Router service address
        SW4RM_REGISTRY_ADDR: Registry service address
        SW4RM_DEFAULT_TIMEOUT_MS: Default timeout in milliseconds
        SW4RM_MAX_RETRIES: Maximum retry attempts
        SW4RM_ENABLE_METRICS: Enable metrics collection (true/false)
        SW4RM_ENABLE_TRACING: Enable tracing (true/false)
        SW4RM_METRICS_BACKEND: Metrics backend (noop|memory|statsd|datadog)
        SW4RM_METRICS_HOST: StatsD/DogStatsD host
        SW4RM_METRICS_PORT: StatsD/DogStatsD port
        SW4RM_METRICS_NAMESPACE: Optional metric namespace prefix
        SW4RM_METRICS_TAGS: Comma-separated tags attached to all metrics
        SW4RM_METRICS_SAMPLE_RATE: Sample rate between 0.0 and 1.0
        SW4RM_LOG_LEVEL: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    # Start with defaults
    config_data: dict[str, Any] = {}

    # Load from file if provided
    if path is not None:
        config_path = Path(path)
        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {path}")

        # Determine file format from extension
        suffix = config_path.suffix.lower()

        if suffix == ".json":
            with open(config_path, "r") as f:
                file_config = json.load(f)
                config_data.update(file_config)

        elif suffix in (".yaml", ".yml"):
            try:
                import yaml
            except ImportError:
                raise ValueError(
                    "YAML support requires PyYAML: pip install pyyaml"
                )

            with open(config_path, "r") as f:
                file_config = yaml.safe_load(f)
                if file_config:
                    config_data.update(file_config)

        else:
            raise ValueError(
                f"Unsupported configuration file format: {suffix}. "
                "Supported formats: .json, .yaml, .yml"
            )

    # Override with environment variables
    env_overrides = _load_from_env()
    config_data.update(env_overrides)

    # Create config object
    return SW4RMConfig.from_dict(config_data)


def _load_from_env() -> dict[str, Any]:
    """Load configuration overrides from environment variables.

    Returns:
        Dictionary of configuration values from environment
    """
    env_config: dict[str, Any] = {}

    # Service addresses
    if "SW4RM_ROUTER_ADDR" in os.environ:
        env_config["router_addr"] = os.environ["SW4RM_ROUTER_ADDR"]

    if "SW4RM_REGISTRY_ADDR" in os.environ:
        env_config["registry_addr"] = os.environ["SW4RM_REGISTRY_ADDR"]

    # Numeric values
    if "SW4RM_DEFAULT_TIMEOUT_MS" in os.environ:
        try:
            env_config["default_timeout_ms"] = int(
                os.environ["SW4RM_DEFAULT_TIMEOUT_MS"]
            )
        except ValueError:
            logging.warning(
                "Invalid SW4RM_DEFAULT_TIMEOUT_MS value, using default"
            )

    if "SW4RM_MAX_RETRIES" in os.environ:
        try:
            env_config["max_retries"] = int(os.environ["SW4RM_MAX_RETRIES"])
        except ValueError:
            logging.warning("Invalid SW4RM_MAX_RETRIES value, using default")

    # Boolean values
    if "SW4RM_ENABLE_METRICS" in os.environ:
        env_config["enable_metrics"] = _parse_bool(
            os.environ["SW4RM_ENABLE_METRICS"]
        )

    if "SW4RM_ENABLE_TRACING" in os.environ:
        env_config["enable_tracing"] = _parse_bool(
            os.environ["SW4RM_ENABLE_TRACING"]
        )

    if "SW4RM_METRICS_BACKEND" in os.environ:
        env_config["metrics_backend"] = _normalize_metrics_backend(
            os.environ["SW4RM_METRICS_BACKEND"]
        )

    if "SW4RM_METRICS_HOST" in os.environ:
        env_config["metrics_host"] = os.environ["SW4RM_METRICS_HOST"]

    if "SW4RM_METRICS_PORT" in os.environ:
        try:
            env_config["metrics_port"] = int(os.environ["SW4RM_METRICS_PORT"])
        except ValueError:
            logging.warning("Invalid SW4RM_METRICS_PORT value, using default")

    if "SW4RM_METRICS_NAMESPACE" in os.environ:
        env_config["metrics_namespace"] = os.environ["SW4RM_METRICS_NAMESPACE"]

    if "SW4RM_METRICS_TAGS" in os.environ:
        env_config["metrics_tags"] = _parse_tags(
            os.environ["SW4RM_METRICS_TAGS"]
        )

    if "SW4RM_METRICS_SAMPLE_RATE" in os.environ:
        try:
            env_config["metrics_sample_rate"] = float(
                os.environ["SW4RM_METRICS_SAMPLE_RATE"]
            )
        except ValueError:
            logging.warning("Invalid SW4RM_METRICS_SAMPLE_RATE value, using default")

    # Log level
    if "SW4RM_LOG_LEVEL" in os.environ:
        env_config["log_level"] = os.environ["SW4RM_LOG_LEVEL"].upper()

    return env_config


def _parse_bool(value: str) -> bool:
    """Parse a boolean value from string.

    Args:
        value: String value to parse

    Returns:
        Boolean value
    """
    return value.lower() in ("true", "1", "yes", "on")


def _normalize_metrics_backend(value: str) -> str:
    """Normalize metrics backend names to known aliases."""
    normalized = value.strip().lower()
    if normalized in {"true", "1", "yes", "on"}:
        return "statsd"
    return normalized


def _parse_tags(raw: str) -> list[str]:
    """Parse tags from a comma-separated env value."""
    parts = [part.strip() for part in raw.split(",")]
    return [part for part in parts if part]


# Global singleton config instance
_global_config: Optional[SW4RMConfig] = None


def get_config() -> SW4RMConfig:
    """Get the global SW4RM configuration.

    Returns the singleton configuration instance. If no configuration has been
    loaded yet, creates a new one using environment variables.

    Returns:
        Global SW4RMConfig instance

    Example:
        config = get_config()
        print(f"Router: {config.router_addr}")
        print(f"Metrics enabled: {config.enable_metrics}")
    """
    global _global_config

    if _global_config is None:
        # Load default config from environment
        _global_config = load_config()

    return _global_config


def set_config(config: SW4RMConfig) -> None:
    """Set the global SW4RM configuration.

    This allows applications to programmatically configure the SDK
    instead of using files or environment variables.

    Args:
        config: SW4RMConfig instance to set as global

    Example:
        config = SW4RMConfig(
            router_addr="localhost:50051",
            enable_metrics=False,
            log_level="DEBUG"
        )
        set_config(config)
    """
    global _global_config
    _global_config = config
