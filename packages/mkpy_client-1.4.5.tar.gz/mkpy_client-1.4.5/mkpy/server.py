"""HTTP server for mkpy."""

from __future__ import annotations

import json
import mimetypes
import os
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .docs import Docs


class DocsHandler(BaseHTTPRequestHandler):
    docs: Docs = None

    def do_GET(self) -> None:
        path = self.path.split("?")[0].rstrip("/") or "/"

        if path == "/sitemap.xml":
            sitemap = self.docs.generate_sitemap(
                f"http://{self.docs.host}:{self.docs.port}"
            )
            self.send_response(200)
            self.send_header("Content-Type", "application/xml")
            self.end_headers()
            self.wfile.write(sitemap.encode("utf-8"))
            return

        if path == "/search-index.json":
            index = self.docs.generate_search_index()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(index.encode("utf-8"))
            return

        if path == "/livereload":
            self._serve_livereload()
            return

        if self._serve_static(path):
            return

        if path in self.docs.routes:
            html = self.docs.render(self.docs.routes[path], search_index=True)

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(html.encode("utf-8"))

        elif path + "/" in self.docs.routes:
            self.send_response(302)
            self.send_header("Location", path + "/")
            self.end_headers()

        else:
            html = self.docs.render_error(404, "Page Not Found")
            self.send_response(404)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html.encode("utf-8"))

    def _serve_livereload(self) -> None:
        html = """<!DOCTYPE html>
<html>
<head>
    <title>LiveReload</title>
    <script>
    const evtSource = new EventSource('/livereload');
    evtSource.onmessage = (e) => {
        if (e.data === 'reload') location.reload();
    };
    </script>
</head>
<body>LiveReload connected</body>
</html>"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

    def _serve_static(self, path: str) -> bool:
        static_folder = os.path.join(self.docs.folder, "..", "static")

        for static_base in [static_folder, "static", "assets"]:
            if os.path.isdir(static_base):
                file_path = os.path.join(static_base, path.lstrip("/"))
                if os.path.isfile(file_path):
                    self._serve_file(file_path)
                    return True

        return False

    def _serve_file(self, file_path: str) -> None:
        mime_type, _ = mimetypes.guess_type(file_path)
        content_type = mime_type or "application/octet-stream"

        with open(file_path, "rb") as f:
            content = f.read()

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def log_message(self, format: str, *args) -> None:
        path = self.path.split("?")[0]
        code = str(self.response_code) if hasattr(self, "response_code") else "200"

        try:
            from rich.console import Console

            console = Console()
            if code.startswith("2"):
                console.print(f"[green]{code}[/green] [dim]{path}[/dim]")
            elif code.startswith("4") or code.startswith("5"):
                console.print(f"[red]{code}[/red] [dim]{path}[/dim]")
            else:
                console.print(f"[yellow]{code}[/yellow] [dim]{path}[/dim]")
        except Exception:
            print(f"{code} {path}")


class LiveReloadHandler(BaseHTTPRequestHandler):
    docs: Docs = None
    clients: list = []

    def do_GET(self) -> None:
        if self.path == "/livereload":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            self.clients.append(self.wfile)
        else:
            self.send_error(404)

    def send_reload(self) -> None:
        for client in self.clients:
            try:
                client.write(b"data: reload\n\n")
                client.flush()
            except Exception:
                pass
        self.clients = []

    def log_message(self, format: str, *args) -> None:
        pass


def run_server(docs: Docs, live_reload: bool = False) -> None:
    try:
        from rich.console import Console

        console = Console()
        use_rich = True
    except ImportError:
        use_rich = False

    DocsHandler.docs = docs

    static_folder = os.path.join(docs.folder, "..", "static")
    if not os.path.exists(static_folder):
        os.makedirs(static_folder, exist_ok=True)

    url = f"http://{docs.host}:{docs.port}"

    if use_rich:
        console.print("[bold green]⚡[/bold green] [bold]mkpy[/bold] started")
        console.print(f"📂 Docs: [cyan]{docs.folder}[/cyan]")
        console.print(f"🎨 Theme: [cyan]{docs.theme}[/cyan]")
        console.print(f"[success]➜[/success] [bold]{url}[/bold]")
        if live_reload:
            console.print("[bold yellow]🔥 LiveReload enabled[/bold yellow]")
        console.print("[dim]Press Ctrl+C to stop[/dim]")
    else:
        print("⚡ mkpy started")
        print(f"📂 Docs: {docs.folder}")
        print(f"🎨 Theme: {docs.theme}")
        print(f"➜ {url}")
        if live_reload:
            print("🔥 LiveReload enabled")
        print("Press Ctrl+C to stop")

    server = HTTPServer((docs.host, docs.port), DocsHandler)

    if live_reload:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler

        class ReloadHandler(FileSystemEventHandler):
            def __init__(self, server_ref):
                self.server_ref = server_ref

            def on_modified(self, event):
                if event.is_directory or event.src_path.endswith(".md"):
                    self._trigger_reload()

            def on_created(self, event):
                if not event.is_directory or event.src_path.endswith(".md"):
                    self._trigger_reload()

            def on_deleted(self, event):
                if not event.is_directory or event.src_path.endswith(".md"):
                    self._trigger_reload()

            def _trigger_reload(self):
                try:
                    from rich.console import Console
                    console = Console()
                    console.print("[yellow]📄 File changed, reloading...[/yellow]")
                except Exception:
                    pass
                for client in LiveReloadHandler.clients:
                    try:
                        client.write(b"data: reload\n\n")
                        client.flush()
                    except Exception:
                        pass

        reload_observer = Observer()
        reload_handler = ReloadHandler(server)
        reload_observer.schedule(reload_handler, docs.folder, recursive=True)
        reload_observer.start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        if use_rich:
            console.print("[warning]👋[/warning] Shutting down...")
        else:
            print("👋 Shutting down...")
        if live_reload:
            reload_observer.stop()
            reload_observer.join()
