from __future__ import annotations

import importlib.util
import os
import sys
from typing import Annotated

import typer

from .docs import Docs

app = typer.Typer(help="Minimalistic documentation generator and server")


def load_docs_from_file(file_path: str) -> Docs:
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File '{file_path}' not found")

    spec = importlib.util.spec_from_file_location("docs_config", file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load '{file_path}'")

    module = importlib.util.module_from_spec(spec)
    sys.modules["docs_config"] = module
    spec.loader.exec_module(module)

    docs = None
    for name in dir(module):
        obj = getattr(module, name)
        if isinstance(obj, Docs):
            docs = obj
            break

    if docs is None:
        raise ValueError(f"No Docs instance found in '{file_path}'")

    return docs


@app.command()
def serve(
    file: Annotated[
        str | None,
        typer.Argument(help="Python file with Docs configuration"),
    ] = None,
    folder: Annotated[
        str,
        typer.Option("--folder", "-f", help="Path to folder containing markdown files"),
    ] = "docs",
    title: Annotated[
        str,
        typer.Option("--title", "-t", help="Documentation title"),
    ] = "MKPY",
    theme: Annotated[
        str,
        typer.Option("--theme", help="Theme: light or dark"),
    ] = "light",
    host: Annotated[
        str,
        typer.Option("--host", help="Host address"),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        typer.Option("--port", "-p", help="Port number"),
    ] = 8000,
    no_nav: Annotated[
        bool,
        typer.Option("--no-nav", help="Disable navigation menu"),
    ] = False,
    live_reload: Annotated[
        bool,
        typer.Option("--live-reload", "-r", help="Enable live reload on file changes"),
    ] = False,
) -> None:
    """Serve documentation."""
    if file:
        docs = load_docs_from_file(file)
    else:
        docs = Docs(
            folder=folder,
            title=title,
            theme=theme,
            host=host,
            port=port,
            show_nav=not no_nav,
        )
    docs.run(live_reload=live_reload)


@app.command()
def build(
    folder: Annotated[
        str,
        typer.Option("--folder", "-f", help="Path to folder containing markdown files"),
    ] = "docs",
    output: Annotated[
        str,
        typer.Option("--output", "-o", help="Output directory for static files"),
    ] = "",
    directory: Annotated[
        str,
        typer.Option("--directory", "-d", help="Output directory (alternative to -o, reads READTHEDOCS_OUTPUT if set)"),
    ] = "",
    title: Annotated[
        str,
        typer.Option("--title", "-t", help="Documentation title"),
    ] = "MKPY",
    theme: Annotated[
        str,
        typer.Option("--theme", help="Theme: light or dark"),
    ] = "light",
    no_nav: Annotated[
        bool,
        typer.Option("--no-nav", help="Disable navigation menu"),
    ] = False,
) -> None:
    import os
    output_dir = directory or output
    if not output_dir:
        output_dir = os.environ.get("READTHEDOCS_OUTPUT", "project")
    from rich import box
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
    from rich.table import Table

    console = Console()

    os.makedirs(output_dir, exist_ok=True)
    docs = Docs(
        folder=folder,
        title=title,
        theme=theme,
        show_nav=not no_nav,
    )

    routes = list(docs.routes.items())
    total = len(routes)

    console.print(Panel.fit(
        f"[bold cyan]MKPY Build[/bold cyan]\n"
        f"Converting [yellow]{total}[/yellow] markdown files to HTML",
        border_style="cyan",
    ))

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold magenta")
    table.add_column("Status", style="green", width=8)
    table.add_column("Source", style="cyan")
    table.add_column("Output", style="yellow")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Building...", total=total)

        for route, md_path in routes:
            html_content = docs.render(md_path)

            if route == "/":
                html_filename = "index.html"
            else:
                html_filename = f"{route.lstrip('/')}.html"

            output_path = os.path.join(output_dir, html_filename)

            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            relative_md = os.path.relpath(md_path, folder)
            table.add_row("✓", relative_md, html_filename)

            progress.advance(task)

    console.print()
    console.print(table)

    console.print()
    console.print(Panel.fit(
        f"[bold green]✓ Build complete![/bold green]\n"
        f"Output directory: [yellow]{os.path.abspath(output_dir)}[/yellow]\n"
        f"Files created: [cyan]{total}[/cyan]",
        border_style="green",
    ))


@app.command()
def deploy(
    folder: Annotated[
        str,
        typer.Option("--folder", "-f", help="Path to folder containing markdown files"),
    ] = "docs",
    output: Annotated[
        str,
        typer.Option("--output", "-o", help="Output directory for static files"),
    ] = "project",
    title: Annotated[
        str,
        typer.Option("--title", "-t", help="Documentation title"),
    ] = "MKPY",
    theme: Annotated[
        str,
        typer.Option("--theme", help="Theme: light or dark"),
    ] = "light",
    no_nav: Annotated[
        bool,
        typer.Option("--no-nav", help="Disable navigation menu"),
    ] = False,
    github: Annotated[
        bool,
        typer.Option("--github", "-g", help="Create GitHub Actions workflow for deployment"),
    ] = True,
    repo: Annotated[
        str | None,
        typer.Option("--repo", "-r", help="GitHub repository (owner/repo)"),
    ] = None,
) -> None:
    """Build and deploy documentation to GitHub Pages."""
    from rich import box
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
    from rich.table import Table

    console = Console()

    # Build first
    console.print(Panel.fit(
        "[bold cyan]MKPY Deploy[/bold cyan]\n"
        "Building and deploying to GitHub Pages",
        border_style="cyan",
    ))

    os.makedirs(output, exist_ok=True)
    docs = Docs(
        folder=folder,
        title=title,
        theme=theme,
        show_nav=not no_nav,
    )

    routes = list(docs.routes.items())
    total = len(routes)

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold magenta")
    table.add_column("Status", style="green", width=8)
    table.add_column("Source", style="cyan")
    table.add_column("Output", style="yellow")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Building...", total=total)

        for route, md_path in routes:
            html_content = docs.render(md_path)

            if route == "/":
                html_filename = "index.html"
            else:
                html_filename = f"{route.lstrip('/')}.html"

            output_path = os.path.join(output, html_filename)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(html_content)

            relative_md = os.path.relpath(md_path, folder)
            table.add_row("✓", relative_md, html_filename)
            progress.advance(task)

    console.print()
    console.print(table)

    if github:
        console.print()
        console.print("[cyan]Creating GitHub Actions workflow...[/cyan]")

        workflow_dir = os.path.join(output, ".github", "workflows")
        os.makedirs(workflow_dir, exist_ok=True)

        workflow_content = """name: Deploy to GitHub Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Pages
        uses: actions/configure-pages@v4

      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: '.'

      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
"""
        workflow_path = os.path.join(workflow_dir, "deploy.yml")
        with open(workflow_path, "w", encoding="utf-8") as f:
            f.write(workflow_content)

        console.print(f"[green]✓[/green] Created {workflow_path}")

    # Summary
    console.print()
    console.print(Panel.fit(
        f"[bold green]✓ Deploy ready![/bold green]\n"
        f"Output: [yellow]{os.path.abspath(output)}[/yellow]\n"
        f"Files: [cyan]{total}[/cyan]\n"
        f"GitHub Actions: [green]{'✓ Created' if github else '✗ Skipped'}[/green]",
        border_style="green",
    ))

    if github:
        console.print()
        console.print("[bold yellow]Next steps:[/bold yellow]")
        console.print("  1. Push to GitHub:")
        console.print("     [cyan]git add .[/cyan]")
        console.print("     [cyan]git commit -m 'Add mkpy docs'[/cyan]")
        console.print("     [cyan]git push origin main[/cyan]")
        console.print()
        console.print("  2. Enable GitHub Pages:")
        console.print("     → Repository Settings → Pages")
        console.print("     → Source: [yellow]GitHub Actions[/yellow]")
        console.print()
        console.print("  3. Your docs will be live at:")
        console.print("     [cyan]https://<owner>.github.io/<repo>/[/cyan]")


@app.command()
def init(
    folder: Annotated[
        str,
        typer.Option("--folder", "-f", help="Folder for documentation files"),
    ] = "docs",
    title: Annotated[
        str,
        typer.Option("--title", "-t", help="Documentation title"),
    ] = "My Documentation",
) -> None:
    """Initialize Read the Docs configuration."""
    from rich import box
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    readthedocs_config = """version: 2

build:
  os: ubuntu-latest
  tools:
    python: "3.11"

commands:
- python -m pip install --upgrade pip
- python -m pip install mkpy-client
- python -m pip install -e .
- python -m mkpy build --theme dark -d $READTHEDOCS_OUTPUT/html
"""

    readthedocs_path = ".readthedocs.yaml"
    if os.path.exists(readthedocs_path):
        console.print(f"[yellow]Warning: {readthedocs_path} already exists, skipping[/yellow]")
    else:
        with open(readthedocs_path, "w", encoding="utf-8") as f:
            f.write(readthedocs_config)
        console.print(f"[green]✓[/green] Created {readthedocs_path}")

    os.makedirs(folder, exist_ok=True)

    index_content = f"""# {title}

Welcome to your documentation! This file was generated by **mkpy init**.

## Getting Started

This is the main page of your documentation. Edit `{folder}/index.md` to customize it.

## Next Steps

- Add more markdown files to the `{folder}/` folder
- Run `mkpy serve` to preview locally
- Run `mkpy build` to generate static HTML
- Deploy to GitHub Pages with `mkpy deploy`

## Configuration

You can customize your documentation in `.readthedocs.yaml`.
"""

    index_path = os.path.join(folder, "index.md")
    if os.path.exists(index_path):
        console.print(f"[yellow]Warning: {index_path} already exists, skipping[/yellow]")
    else:
        with open(index_path, "w", encoding="utf-8") as f:
            f.write(index_content)
        console.print(f"[green]✓[/green] Created {index_path}")

    console.print()
    console.print(Panel.fit(
        "[bold green]✓ Initialization complete![/bold green]\n"
        f"Run [cyan]mkpy serve[/cyan] to preview your documentation",
        border_style="green",
    ))


@app.command()
def version() -> None:
    from . import __version__

    typer.echo(f"mkpy {__version__}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
