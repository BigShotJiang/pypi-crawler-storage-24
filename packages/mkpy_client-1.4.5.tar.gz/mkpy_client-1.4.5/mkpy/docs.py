from __future__ import annotations

import json
import os
from typing import Annotated, Literal

from annotated_doc import Doc

from .markdown import extract_title, render as render_markdown
from .themes import THEMES, ThemeName
from .server import run_server


class NavItem:
    def __init__(self, title: str, path: str, children: list["NavItem"] | None = None):
        self.title = title
        self.path = path
        self.children = children or []

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "path": self.path,
            "children": [c.to_dict() for c in self.children]
        }


class Docs:
    """
    A minimalistic documentation generator and server.

    Automatically reads markdown files from a folder, converts them to HTML,
    and serves them via built-in HTTP server with automatic routing.

    Example:
        >>> from mkpy import Docs
        >>> docs = Docs(
        ...     title="My Project",
        ...     theme="dark",
        ...     port=3000,
        ... )
        >>> docs.run()
    """

    def __init__(
        self,
        folder: Annotated[
            str,
            Doc(
                """
                Path to folder containing markdown files.
                Defaults to "docs" in current directory.
                """
            ),
        ] = "docs",
        title: Annotated[
            str,
            Doc(
                """
                Title displayed in browser tab and page header.
                """
            ),
        ] = "MKPY",
        theme: Annotated[
            str | Literal["light", "dark"],
            Doc(
                """
                Color theme. Available: "light", "dark".
                """
            ),
        ] = "light",
        host: Annotated[
            str,
            Doc(
                """
                Host address to bind server to.
                """
            ),
        ] = "127.0.0.1",
        port: Annotated[
            int,
            Doc(
                """
                Port number for HTTP server.
                """
            ),
        ] = 8000,
        show_nav: Annotated[
            bool,
            Doc(
                """
                Whether to show automatic navigation menu.
                """
            ),
        ] = True,
        custom_css: Annotated[
            str | None,
            Doc(
                """
                Custom CSS to inject into every page.
                Can be inline CSS or path to .css file (e.g., "styles/custom.css").
                """
            ),
        ] = None,
        custom_js: Annotated[
            str | None,
            Doc(
                """
                Custom JavaScript to inject into every page.
                Can be inline JS or path to .js file (e.g., "scripts/main.js").
                """
            ),
        ] = None,
    ) -> None:
        """
        Initialize Docs instance.

        Args:
            folder: Path to markdown files folder.
            title: Documentation title.
            theme: Theme name ("light" or "dark").
            host: Server host address.
            port: Server port number.
            show_nav: Show navigation menu.
            custom_css: Custom CSS content or path to CSS file.
            custom_js: Custom JavaScript content or path to JS file.
        """
        self.folder = folder
        self.title = title
        self.theme = theme
        self.host = host
        self.port = port
        self.show_nav = show_nav
        self.custom_css = custom_css
        self.custom_js = custom_js

        if theme not in THEMES:
            raise ValueError(f"Theme '{theme}' not found. Available: {list(THEMES.keys())}")

        self.routes: dict[str, str] = {}
        self._auto_discover_assets()
        self._build_routes()

    def _auto_discover_assets(self) -> None:
        css_folder = os.path.join(self.folder, "css")
        if os.path.isdir(css_folder):
            css_files = []
            for f in sorted(os.listdir(css_folder)):
                if f.endswith(".css"):
                    with open(os.path.join(css_folder, f), encoding="utf-8") as file:
                        css_files.append(file.read())
            if css_files:
                auto_css = "\n".join(css_files)
                if self.custom_css:
                    self.custom_css = auto_css + "\n" + self.custom_css
                else:
                    self.custom_css = auto_css

        js_folder = os.path.join(self.folder, "js")
        if os.path.isdir(js_folder):
            js_files = []
            for f in sorted(os.listdir(js_folder)):
                if f.endswith(".js"):
                    with open(os.path.join(js_folder, f), encoding="utf-8") as file:
                        js_files.append(file.read())
            if js_files:
                auto_js = "\n".join(js_files)
                if self.custom_js:
                    self.custom_js = auto_js + "\n" + self.custom_js
                else:
                    self.custom_js = auto_js

    def _build_routes(self) -> None:
        if not os.path.exists(self.folder):
            raise FileNotFoundError(f"Folder '{self.folder}' not found")

        for root, _, files in os.walk(self.folder):
            for file in files:
                if file.endswith(".md"):
                    full_path = os.path.join(root, file)

                    route = os.path.relpath(full_path, self.folder)
                    route = route.replace("\\", "/")
                    route = route.replace(".md", "")

                    if route.endswith("index"):
                        route = route[:-6] if route.endswith("/index") else route[:-5]

                    route = "/" + route.strip("/") if route != "/" else "/"

                    self.routes[route] = full_path

    @property
    def navigation(self) -> list[tuple[str, str]]:
        nav = []
        for route in sorted(self.routes.keys()):
            file_path = self.routes[route]
            with open(file_path, "r", encoding="utf-8") as f:
                md = f.read()
            filename = os.path.basename(file_path)
            title = extract_title(md, filename)
            nav.append((route, title))
        return nav

    @property
    def navigation_tree(self) -> list[NavItem]:
        tree: dict[str, NavItem] = {}
        for route in sorted(self.routes.keys()):
            file_path = self.routes[route]
            with open(file_path, "r", encoding="utf-8") as f:
                md = f.read()
            filename = os.path.basename(file_path)
            title = extract_title(md, filename)

            parts = route.strip("/").split("/")
            current = tree
            for i, part in enumerate(parts):
                if part not in current:
                    is_leaf = i == len(parts) - 1
                    current[part] = NavItem(
                        title=title if is_leaf else part.replace("-", " ").replace("_", " ").title(),
                        path=route if is_leaf else "/" + "/".join(parts[:i+1])
                    )
                current = current[part].children
                if isinstance(current, dict):
                    current = current

        result = []
        for key in sorted(tree.keys()):
            result.append(tree[key])
        return self._build_tree_list(tree)

    def _build_tree_list(self, tree: dict) -> list[NavItem]:
        result = []
        for key in sorted(tree.keys()):
            item = tree[key]
            if item.children and isinstance(item.children, dict):
                item.children = self._build_tree_list(item.children)
            result.append(item)
        return result

    def generate_search_index(self) -> str:
        index = []
        for route in sorted(self.routes.keys()):
            file_path = self.routes[route]
            with open(file_path, "r", encoding="utf-8") as f:
                md = f.read()
            filename = os.path.basename(file_path)
            title = extract_title(md, filename)
            index.append({
                "title": title,
                "path": route,
                "content": md.replace("#", "").replace("*", "").replace("`", "")[:500]
            })
        return json.dumps(index, ensure_ascii=False)

    def _load_custom_asset(self, value: str | None, asset_type: str) -> str:
        if value is None:
            return ""

        if asset_type == "css" and value.endswith(".css") or asset_type == "js" and value.endswith(".js"):
            if os.path.isfile(value):
                with open(value, encoding="utf-8") as f:
                    return f.read()
            relative_path = os.path.join(self.folder, "..", value)
            if os.path.isfile(relative_path):
                with open(relative_path, encoding="utf-8") as f:
                    return f.read()

        return value

    def _render_nav_tree(self, items: list[NavItem], current_path: str) -> str:
        if not items:
            return ""
        html = "<ul>"
        for item in items:
            is_active = item.path == current_path
            html += f'<li><a href="{item.path}" class="{"active" if is_active else ""}">{item.title}</a>'
            if item.children:
                html += self._render_nav_tree(item.children, current_path)
            html += "</li>"
        html += "</ul>"
        return html

    def render(self, file_path: str, search_index: bool = False) -> str:
        with open(file_path, encoding="utf-8") as f:
            md = f.read()

        content = render_markdown(md)
        base_css = THEMES[self.theme]
        custom_css = self._load_custom_asset(self.custom_css, "css")

        nav_html = ""
        if self.show_nav:
            current_path = "/" + os.path.relpath(file_path, self.folder).replace("\\", "/").replace(".md", "")
            if current_path.endswith("/index"):
                current_path = current_path[:-6] or "/"
            nav_tree = self._render_nav_tree(self.navigation_tree, current_path)
            nav_html = f'<nav class="mkpy-nav"><details><summary>Navigation</summary>{nav_tree}</details></nav>'

        search_html = ""
        if search_index:
            search_index_data = self.generate_search_index()
            search_html = f'''<div class="mkpy-search">
                <input type="text" id="mkpy-search-input" placeholder="Search docs...">
                <div id="mkpy-search-results"></div>
            </div>
            <script>
            const searchIndex = {search_index_data};
            const searchInput = document.getElementById('mkpy-search-input');
            const searchResults = document.getElementById('mkpy-search-results');
            
            searchInput.addEventListener('input', (e) => {{
                const query = e.target.value.toLowerCase();
                if (query.length < 2) {{
                    searchResults.innerHTML = '';
                    return;
                }}
                const results = searchIndex.filter(item => 
                    item.title.toLowerCase().includes(query) || 
                    item.content.toLowerCase().includes(query)
                ).slice(0, 10);
                
                if (results.length === 0) {{
                    searchResults.innerHTML = '<div class="no-results">No results found</div>';
                    return;
                }}
                
                searchResults.innerHTML = results.map(r => 
                    `<a href="${{r.path}}" class="search-result"><strong>${{r.title}}</strong></a>`
                ).join('');
            }});
            
            document.addEventListener('click', (e) => {{
                if (!e.target.closest('.mkpy-search')) {{
                    searchResults.innerHTML = '';
                }}
            }});
            </script>'''

        custom_css_block = f"<style>\n{custom_css}\n</style>" if custom_css else ""

        return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.title}</title>
    <style>
    {base_css}
    .mkpy-nav {{
        margin-bottom: 2em;
        padding-bottom: 1em;
        border-bottom: 1px solid {'#30363d' if self.theme == 'dark' else '#eee'};
    }}
    .mkpy-nav summary {{
        cursor: pointer;
        font-weight: 600;
        padding: 0.5em;
        background: {'#21262d' if self.theme == 'dark' else '#f5f5f5'};
        border-radius: 4px;
    }}
    .mkpy-nav ul {{
        list-style: none;
        padding-left: 1em;
        margin: 0.5em 0;
    }}
    .mkpy-nav li {{
        margin: 0.3em 0;
    }}
    .mkpy-nav a {{
        color: {'#58a6ff' if self.theme == 'dark' else '#0066cc'};
    }}
    .mkpy-nav a.active {{
        font-weight: 600;
        text-decoration: underline;
    }}
    .mkpy-nav ul ul {{
        padding-left: 1.5em;
    }}
    .mkpy-search {{
        position: relative;
        margin-bottom: 2em;
    }}
    .mkpy-search input {{
        width: 100%;
        padding: 0.75em 1em;
        font-size: 1em;
        border: 1px solid {'#30363d' if self.theme == 'dark' else '#ddd'};
        border-radius: 8px;
        background: {'#0d1117' if self.theme == 'dark' else '#fff'};
        color: {'#c9d1d9' if self.theme == 'dark' else '#1a1a1a'};
    }}
    .mkpy-search input:focus {{
        outline: none;
        border-color: {'#58a6ff' if self.theme == 'dark' else '#0066cc'};
    }}
    #mkpy-search-results {{
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: {'#161b22' if self.theme == 'dark' else '#fff'};
        border: 1px solid {'#30363d' if self.theme == 'dark' else '#ddd'};
        border-radius: 8px;
        margin-top: 4px;
        max-height: 300px;
        overflow-y: auto;
        z-index: 100;
    }}
    .search-result {{
        display: block;
        padding: 0.75em 1em;
        color: {'#c9d1d9' if self.theme == 'dark' else '#1a1a1a'};
        text-decoration: none;
    }}
    .search-result:hover {{
        background: {'#21262d' if self.theme == 'dark' else '#f5f5f5'};
    }}
    .no-results {{
        padding: 1em;
        color: {'#8b949e' if self.theme == 'dark' else '#666'};
        text-align: center;
    }}
    </style>
    {custom_css_block}
</head>
<body>
    {search_html}
    {nav_html}
    <main>
    {content}
    </main>
    <footer style="margin-top: 3em; padding-top: 1em; border-top: 1px solid {'#30363d' if self.theme == 'dark' else '#eee'}; font-size: 0.85em; opacity: 0.7;">
        Generated by <a href="https://github.com/ndugram/mkpy">mkpy</a>
    </footer>
    <script>
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {{
        anchor.addEventListener('click', function (e) {{
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) target.scrollIntoView({{ behavior: 'smooth' }});
        }});
    }});
    </script>
    {self._load_custom_asset(self.custom_js, 'js')}
</body>
</html>
"""

    def render_error(self, code: int, message: str) -> str:
        """
        Render error page.

        Args:
            code: HTTP status code.
            message: Error message.

        Returns:
            HTML error page string.
        """
        css = THEMES[self.theme]
        return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{code} - {message}</title>
    <style>
    {css}
    .error-container {{
        text-align: center;
        padding: 4em 0;
    }}
    .error-code {{
        font-size: 6em;
        font-weight: bold;
        opacity: 0.3;
    }}
    .error-message {{
        font-size: 1.5em;
        margin-top: 1em;
    }}
    a {{
        color: {'#58a6ff' if self.theme == 'dark' else '#0066cc'};
    }}
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-code">{code}</div>
        <div class="error-message">{message}</div>
        <p><a href="/">← Back to home</a></p>
    </div>
</body>
</html>
"""

    def generate_sitemap(self, host: Annotated[
        str,
        Doc(
            """
            Base URL for sitemap generation.
            """
        ),
    ] = "http://localhost") -> str:
        """
        Generate sitemap.xml for SEO.

        Args:
            host: Base URL of the documentation site.

        Returns:
            XML sitemap string.
        """
        urls = []
        for route in sorted(self.routes.keys()):
            url = f"{host}{route}"
            urls.append(f"  <url>\n    <loc>{url}</loc>\n  </url>")
        return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + "\n".join(urls) + "\n</urlset>"

    def run(self, live_reload: bool = False) -> None:
        run_server(self, live_reload=live_reload)

    def build_static(
        self,
        output: Annotated[
            str,
            Doc(
                """
                Output directory for static files.
                """
            ),
        ] = "build",
    ) -> None:
        """
        Build static HTML files for deployment.

        Generates a complete static website that can be deployed
        to any static hosting service (GitHub Pages, Read the Docs, etc.).

        Args:
            output: Output directory path.
        """
        import shutil

        # Create output directory
        os.makedirs(output, exist_ok=True)

        # Copy assets if they exist
        css_src = os.path.join(self.folder, "css")
        if os.path.isdir(css_src):
            css_dest = os.path.join(output, "css")
            if os.path.exists(css_dest):
                shutil.rmtree(css_dest)
            shutil.copytree(css_src, css_dest)

        js_src = os.path.join(self.folder, "js")
        if os.path.isdir(js_src):
            js_dest = os.path.join(output, "js")
            if os.path.exists(js_dest):
                shutil.rmtree(js_dest)
            shutil.copytree(js_src, js_dest)

        # Generate HTML files
        for route, file_path in self.routes.items():
            html_content = self.render(file_path)

            # Determine output file path
            if route == "/":
                out_file = os.path.join(output, "index.html")
            else:
                # Remove leading slash and add .html
                clean_route = route.lstrip("/")
                if not clean_route:
                    out_file = os.path.join(output, "index.html")
                else:
                    out_file = os.path.join(output, clean_route + ".html")

            # Create directories if needed
            os.makedirs(os.path.dirname(out_file), exist_ok=True)

            # Write HTML file
            with open(out_file, "w", encoding="utf-8") as f:
                f.write(html_content)

        # Generate sitemap
        sitemap = self.generate_sitemap()
        with open(os.path.join(output, "sitemap.xml"), "w", encoding="utf-8") as f:
            f.write(sitemap)

