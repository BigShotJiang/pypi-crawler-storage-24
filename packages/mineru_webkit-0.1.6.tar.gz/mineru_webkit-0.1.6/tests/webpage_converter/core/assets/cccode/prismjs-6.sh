$ npm install prismjs
