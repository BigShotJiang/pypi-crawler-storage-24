print("oooo")
