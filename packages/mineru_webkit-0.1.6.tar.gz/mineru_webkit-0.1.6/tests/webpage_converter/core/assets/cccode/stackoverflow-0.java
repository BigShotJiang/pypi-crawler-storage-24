proximitySensor.getCurrentDistance();
