pip install https://github.com/WhiteWolf45380/PyVerse2D/archive/refs/heads/main.zip

