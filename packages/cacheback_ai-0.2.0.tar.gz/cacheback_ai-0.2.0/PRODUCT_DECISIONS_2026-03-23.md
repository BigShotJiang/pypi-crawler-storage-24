# Product Decisions — 2026-03-23 Brand Architecture Pivot

## Decision: Three-Product Stack

cacheback is the **engine**, not the product. Nobody cares how we make AI cheaper — they care that it IS cheaper.

## Architecture

```
bgml.ai (parent / R&D / EIC Pathfinder)
├── euor.ai      — B2B: EU compliant in-house AI for companies
├── iors.ai      — B2C: consumer AI franchise (free with compute sharing)
├── cacheback    — open source engine (PyPI, Apache 2.0)
└── distribute.re — marketing campaign for the compute network
```

---

## Product 1: euor.ai — B2B

**Tagline:** "EU compliant in-house AI. Your data never leaves your building."

**Target:** European SMEs and enterprises that need AI but can't send data to US clouds (GDPR, EU AI Act, regulated industries: legal, healthcare, finance, government).

**Value proposition:**
- AI runs on your existing office PCs (no GPU needed)
- Data stays on-premise — GDPR compliant by architecture
- 10-30x cheaper than cloud AI (no per-token costs after setup)
- EU AI Act compliance dashboard included
- Works offline — no internet dependency for inference

**Tiers:**

| Tier | Price | Nodes | Features |
|------|-------|-------|----------|
| Starter | €99/mo | Up to 5 PCs | Basic dashboard, text inference, semantic cache |
| Business | €499/mo | Unlimited | Compliance dashboard, SLA, image+voice, CAS synthesis, priority support |
| Enterprise | Custom | Unlimited | Dedicated support, custom models, audit trail, SSO, on-site setup |

**Technical:** Uses cacheback engine + BGML orchestrator + fleet worker stack. Customer installs worker on office PCs, connects to euor.ai management plane (hosted on EU infrastructure, Hetzner Finland).

**Competitive landscape:**
- Credo AI ($130K+/yr) — compliance only, no inference
- OneTrust ($130K+/yr) — compliance only
- Venvera (€299/mo) — closest, but no on-premise inference
- Nobody bundles cache + compliance + on-premise inference

---

## Product 2: iors.ai — B2C (First AI Franchise)

**Tagline:** "Free AI. Just share your computer."

**Target:** Consumers who want free AI and are willing to contribute compute. Students, hobbyists, developing-world users, privacy-conscious users.

**Value proposition:**
- FREE AI assistant with basic capabilities
- Works offline (basic knowledge + local inference)
- You contribute compute to the network when online
- The more you contribute, the more you unlock
- First AI franchise — users ARE the infrastructure

**Model:**

```
FREE tier (must run node + share compute):
  - Basic text AI (Phi-4-mini local)
  - Offline knowledge base
  - Semantic cache for faster responses
  - Must be online and sharing compute to use cloud features

PAID tiers:
  - Pro (€9/mo): In-house mesh (link your own devices), priority routing
  - Full Exo (€29/mo): All capabilities, ensemble quality, image+voice, zero ads
```

**Franchise mechanics:**
- Each user runs a worker node (PC, old laptop, phone)
- Network routes inference to nearest available nodes
- Users earn credits by contributing compute
- Credits can be spent on premium features or withdrawn
- Revenue split: 70% contributor, 20% platform, 10% foundation (BLOOM)

**Why "franchise":**
- Traditional franchise: you buy equipment, follow brand rules, serve customers, earn money
- iors.ai franchise: you contribute your existing equipment, join the network, serve inference, earn credits
- No upfront cost (unlike McDonald's $1M+)
- Passive income from idle compute

---

## Engine: cacheback (Open Source)

**Not a product. Not marketed separately.** It's the engine that powers both euor.ai and iors.ai.

- `pip install cacheback-ai` (Apache 2.0)
- Universal semantic cache (text, image, voice)
- Cache-Augmented Synthesis (CAS) — three-tier response
- Pluggable embedders (MiniLM, CLIP, CLAP, Whisper)
- Proxy mode for zero-code-change integration
- Used by euor.ai and iors.ai under the hood

Developer documentation and PyPI presence maintained for ecosystem growth, but no separate landing page or marketing budget.

---

## Marketing: distribute.re

**Not a product.** A campaign that promotes the iors.ai compute network.

- Landing page explaining the vision: "Redistribute compute. Democratize AI."
- Links to iors.ai for sign-up
- Links to euor.ai for businesses
- Social media, blog posts, press coverage
- Think: "Ice Bucket Challenge for AI compute" — viral mechanics

---

## Parked: bizzon.ai

- Domain and branding owned
- CEO considers it "too frivolous" for B2B
- May be used for a specific sub-brand later
- No action needed now

---

## Key Principles

1. **Nobody cares about the cache** — don't market it. Market cheaper AI.
2. **Two products, one engine** — euor.ai (pay with money) and iors.ai (pay with compute)
3. **EU compliance is the wedge** — for B2B, this is the #1 selling point
4. **Franchise model is the moat** — for B2C, nobody else offers "free AI for compute"
5. **cacheback stays open source** — it's the engine, not the product

---

## Status

- [x] cacheback engine v0.2.0 (text + image + voice embedders, CAS, proxy)
- [ ] euor.ai offering details finalized
- [ ] iors.ai franchise mechanics defined
- [ ] distribute.re campaign planned
- [ ] Landing pages for euor.ai and iors.ai
