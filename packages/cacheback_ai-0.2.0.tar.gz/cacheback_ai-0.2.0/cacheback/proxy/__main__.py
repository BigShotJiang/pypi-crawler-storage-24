"""Entry point for: python -m cacheback.proxy"""

import uvicorn

from cacheback.proxy.config import ProxyConfig


def main():
    config = ProxyConfig.from_env()
    uvicorn.run(
        "cacheback.proxy.app:app",
        host=config.host,
        port=config.port,
        log_level=config.log_level,
    )


if __name__ == "__main__":
    main()
