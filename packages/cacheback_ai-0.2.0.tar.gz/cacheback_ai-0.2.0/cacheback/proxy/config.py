"""Proxy configuration via environment variables."""

import os
from dataclasses import dataclass, field


@dataclass
class ProxyConfig:
    """Proxy server configuration. All values from env vars with sensible defaults."""

    # Upstream provider
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"

    # Cache settings
    cache_dir: str = ""
    similarity_threshold: float = 0.92
    negative_threshold: float = 0.85
    cache_max_entries: int = 100_000
    cache_ttl: int = 24 * 3600
    on_negative_hit: str = "skip"  # proxy default: skip (don't block requests)

    # Synthesis (CAS)
    synthesis_mode: str = "off"
    synthesis_model: str = "google/gemini-2.0-flash-lite-001"
    synthesis_model_base_url: str = ""
    synthesis_model_api_key: str = ""
    synthesis_threshold: float = 0.80
    synthesis_top_k: int = 5

    # Server
    host: str = "0.0.0.0"
    port: int = 8080
    log_level: str = "info"

    @classmethod
    def from_env(cls) -> "ProxyConfig":
        """Load config from environment variables (CACHEBACK_ prefix)."""
        return cls(
            openai_api_key=os.environ.get("OPENAI_API_KEY", ""),
            openai_base_url=os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1"),
            cache_dir=os.environ.get("CACHEBACK_CACHE_DIR", ""),
            similarity_threshold=float(os.environ.get("CACHEBACK_SIMILARITY_THRESHOLD", "0.92")),
            negative_threshold=float(os.environ.get("CACHEBACK_NEGATIVE_THRESHOLD", "0.85")),
            cache_max_entries=int(os.environ.get("CACHEBACK_MAX_ENTRIES", "100000")),
            cache_ttl=int(os.environ.get("CACHEBACK_TTL", str(24 * 3600))),
            on_negative_hit=os.environ.get("CACHEBACK_ON_NEGATIVE_HIT", "skip"),
            synthesis_mode=os.environ.get("CACHEBACK_SYNTHESIS_MODE", "off"),
            synthesis_model=os.environ.get("CACHEBACK_SYNTHESIS_MODEL", "google/gemini-2.0-flash-lite-001"),
            synthesis_model_base_url=os.environ.get("CACHEBACK_SYNTHESIS_BASE_URL", ""),
            synthesis_model_api_key=os.environ.get("CACHEBACK_SYNTHESIS_API_KEY", ""),
            synthesis_threshold=float(os.environ.get("CACHEBACK_SYNTHESIS_THRESHOLD", "0.80")),
            synthesis_top_k=int(os.environ.get("CACHEBACK_SYNTHESIS_TOP_K", "5")),
            host=os.environ.get("CACHEBACK_HOST", "0.0.0.0"),
            port=int(os.environ.get("CACHEBACK_PORT", "8080")),
            log_level=os.environ.get("CACHEBACK_LOG_LEVEL", "info"),
        )
