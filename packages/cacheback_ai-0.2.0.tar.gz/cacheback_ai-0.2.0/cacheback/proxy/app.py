"""cacheback-proxy — OpenAI-compatible caching proxy server.

Receives standard OpenAI API requests, routes through SemanticCache,
forwards misses to the upstream provider. Zero code change for users.

Usage:
    uvicorn cacheback.proxy.app:app --host 0.0.0.0 --port 8080

Or via Docker:
    docker run -e OPENAI_API_KEY=sk-... -p 8080:8080 cacheback/proxy
"""

import json
import logging
import time
from contextlib import asynccontextmanager
from typing import Optional

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

from cacheback.cache import SemanticCache, DEFAULT_CACHE_DIR
from cacheback.proxy.config import ProxyConfig
from cacheback.proxy.models import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionChoice,
    ChatCompletionMessage,
    CompletionUsage,
    ChatCompletionChunk,
    StreamChoice,
    DeltaContent,
)

logger = logging.getLogger("cacheback.proxy")


def _extract_query(messages: list) -> str:
    """Extract last user message as cache key."""
    for msg in reversed(messages):
        role = msg.role if hasattr(msg, "role") else msg.get("role", "")
        content = msg.content if hasattr(msg, "content") else msg.get("content", "")
        if role == "user":
            if isinstance(content, str):
                return content.strip()
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        return block.get("text", "").strip()
            break
    return ""


def create_app(config: Optional[ProxyConfig] = None) -> FastAPI:
    """Create the cacheback proxy FastAPI app."""

    if config is None:
        config = ProxyConfig.from_env()

    cache: Optional[SemanticCache] = None
    synthesis_engine = None
    http_client: Optional[httpx.AsyncClient] = None

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        nonlocal cache, synthesis_engine, http_client

        # Initialize cache
        cache = SemanticCache(
            cache_dir=config.cache_dir or DEFAULT_CACHE_DIR,
            similarity_threshold=config.similarity_threshold,
            negative_threshold=config.negative_threshold,
            max_entries=config.cache_max_entries,
            ttl_seconds=config.cache_ttl,
            on_negative_hit=config.on_negative_hit,
        )

        # Initialize CAS synthesis engine
        if config.synthesis_mode in ("auto", "always"):
            try:
                from cacheback.synthesis import SynthesisEngine
                synthesis_engine = SynthesisEngine(
                    model=config.synthesis_model,
                    base_url=config.synthesis_model_base_url or None,
                    api_key=config.synthesis_model_api_key or None,
                )
                synthesis_engine._threshold = config.synthesis_threshold
                synthesis_engine._top_k = config.synthesis_top_k
                logger.info("CAS synthesis enabled: model=%s", config.synthesis_model)
            except Exception as e:
                logger.warning("CAS synthesis init failed: %s", e)

        # HTTP client for upstream API calls
        http_client = httpx.AsyncClient(timeout=120.0)

        logger.info(
            "cacheback-proxy started: threshold=%.2f, synthesis=%s",
            config.similarity_threshold,
            config.synthesis_mode,
        )

        yield

        # Cleanup
        if cache:
            cache.close()
        if http_client:
            await http_client.aclose()

    app = FastAPI(
        title="cacheback-proxy",
        description="OpenAI-compatible caching proxy with semantic similarity",
        version="0.2.0",
        lifespan=lifespan,
    )

    # --- Health endpoint ---

    @app.get("/health")
    async def health():
        stats = cache.stats if cache else {}
        return {
            "status": "ok",
            "cache": stats,
            "synthesis": config.synthesis_mode,
        }

    # --- Cache stats ---

    @app.get("/v1/cache/stats")
    async def cache_stats():
        if not cache:
            return {"error": "cache not initialized"}
        return cache.stats

    # --- Main chat completions endpoint ---

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request):
        body = await request.json()
        req = ChatCompletionRequest(**body)

        messages = req.messages
        model = req.model
        stream = req.stream or False
        query = _extract_query(messages)

        # Passthrough: tool calls or empty queries bypass cache
        if req.tools or not query:
            return await _forward_upstream(body, stream, request)

        # --- Tier 1: Verbatim cache lookup ---
        cached_text = cache.lookup(query) if cache else None

        if stream:
            return await _handle_stream(
                body, request, query, model, cached_text
            )

        # Non-streaming path
        if cached_text is not None:
            logger.debug("[proxy] HIT: %s", query[:80])
            return _build_response(cached_text, model, cache_hit=True)

        # --- Tier 2: CAS synthesis ---
        synth_text = _try_synthesis(query, model)
        if synth_text is not None:
            logger.debug("[proxy] SYNTHESIS: %s", query[:80])
            return _build_response(synth_text, model, synthesized=True)

        # --- Tier 3: Upstream API call ---
        upstream_resp = await _forward_upstream(body, False, request)

        # Cache the response
        if isinstance(upstream_resp, JSONResponse):
            try:
                resp_data = json.loads(upstream_resp.body.decode())
                text = _extract_response_text(resp_data)
                if text and cache:
                    tokens = resp_data.get("usage", {}).get("completion_tokens", 0)
                    cache.populate(query, text, model=model, tokens=tokens)
            except Exception:
                pass

        return upstream_resp

    # --- Internal helpers ---

    def _try_synthesis(query: str, model: str) -> Optional[str]:
        """Attempt CAS synthesis. Returns text or None."""
        if not synthesis_engine or not cache:
            return None
        try:
            from cacheback.synthesis import SynthesisCandidate
            candidates_raw = cache.lookup_for_synthesis(
                query,
                threshold=synthesis_engine._threshold,
                top_k=synthesis_engine._top_k,
            )
            if not candidates_raw:
                return None
            candidates = []
            for cache_id, similarity in candidates_raw:
                entry = cache.get_entry(cache_id)
                if entry:
                    candidates.append(SynthesisCandidate(
                        query=entry.query_text,
                        response=entry.response_text,
                        similarity=similarity,
                        cache_id=cache_id,
                    ))
            if not candidates:
                return None
            result = synthesis_engine.synthesize(query, candidates)
            return result.text if result.text else None
        except Exception as e:
            logger.warning("[proxy] synthesis error: %s", e)
            return None

    def _build_response(
        text: str,
        model: str,
        cache_hit: bool = False,
        synthesized: bool = False,
    ) -> JSONResponse:
        """Build an OpenAI-format JSON response."""
        resp = ChatCompletionResponse(
            model=model,
            choices=[ChatCompletionChoice(
                message=ChatCompletionMessage(content=text),
            )],
            cacheback_hit=cache_hit,
            cacheback_synthesized=synthesized,
        )
        headers = {
            "X-Cacheback-Hit": str(cache_hit).lower(),
            "X-Cacheback-Synthesized": str(synthesized).lower(),
        }
        return JSONResponse(content=resp.model_dump(), headers=headers)

    async def _handle_stream(
        body: dict,
        request: Request,
        query: str,
        model: str,
        cached_text: Optional[str],
    ) -> StreamingResponse:
        """Handle streaming requests with cache support."""

        if cached_text is not None:
            logger.debug("[proxy] STREAM HIT: %s", query[:80])
            return StreamingResponse(
                _replay_stream(cached_text, model),
                media_type="text/event-stream",
                headers={
                    "X-Cacheback-Hit": "true",
                    "X-Cacheback-Synthesized": "false",
                },
            )

        # Tier 2: Synthesis → replay as stream
        synth_text = _try_synthesis(query, model)
        if synth_text is not None:
            logger.debug("[proxy] STREAM SYNTHESIS: %s", query[:80])
            return StreamingResponse(
                _replay_stream(synth_text, model),
                media_type="text/event-stream",
                headers={
                    "X-Cacheback-Hit": "false",
                    "X-Cacheback-Synthesized": "true",
                },
            )

        # Tier 3: Forward upstream, buffer and cache
        return StreamingResponse(
            _proxy_stream(body, request, query, model),
            media_type="text/event-stream",
            headers={
                "X-Cacheback-Hit": "false",
                "X-Cacheback-Synthesized": "false",
            },
        )

    async def _replay_stream(text: str, model: str):
        """Replay cached text as SSE stream."""
        chunk_id = f"chatcmpl-cache-{int(time.time())}"
        created = int(time.time())

        # Content chunk
        data = {
            "id": chunk_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {"role": "assistant", "content": text}, "finish_reason": None}],
        }
        yield f"data: {json.dumps(data)}\n\n"

        # Stop chunk
        data = {
            "id": chunk_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        }
        yield f"data: {json.dumps(data)}\n\n"
        yield "data: [DONE]\n\n"

    async def _proxy_stream(
        body: dict,
        request: Request,
        query: str,
        model: str,
    ):
        """Forward streaming request upstream, buffer chunks, cache on completion."""
        body["stream"] = True
        headers = _upstream_headers(request)
        url = f"{config.openai_base_url}/chat/completions"
        buffer = []

        if http_client is None:
            error_data = {"error": {"message": "http_client not initialized", "type": "proxy_error"}}
            yield f"data: {json.dumps(error_data)}\n\n"
            yield "data: [DONE]\n\n"
            return

        try:
            async with http_client.stream(
                "POST", url, json=body, headers=headers
            ) as resp:
                async for line in resp.aiter_lines():
                    yield f"{line}\n"

                    # Parse SSE for buffering
                    if line.startswith("data: ") and line != "data: [DONE]":
                        try:
                            chunk_data = json.loads(line[6:])
                            choices = chunk_data.get("choices", [])
                            if choices:
                                delta = choices[0].get("delta", {})
                                content = delta.get("content")
                                if content:
                                    buffer.append(content)
                        except json.JSONDecodeError:
                            pass

                # After stream completes, cache the full response
                if buffer and cache:
                    full_text = "".join(buffer)
                    cache.populate(query, full_text, model=model)

        except httpx.HTTPError as e:
            logger.error("[proxy] upstream stream error: %s", e)
            error_data = {
                "error": {"message": f"Upstream error: {e}", "type": "proxy_error"}
            }
            yield f"data: {json.dumps(error_data)}\n\n"
            yield "data: [DONE]\n\n"

    async def _forward_upstream(
        body: dict,
        stream: bool,
        request: Request,
    ) -> JSONResponse:
        """Forward request to upstream OpenAI API."""
        headers = _upstream_headers(request)
        url = f"{config.openai_base_url}/chat/completions"

        try:
            if http_client is None:
                raise httpx.HTTPError("http_client not initialized")
            resp = await http_client.post(url, json=body, headers=headers)
            return JSONResponse(
                content=resp.json(),
                status_code=resp.status_code,
            )
        except (httpx.HTTPError, AttributeError) as e:
            logger.error("[proxy] upstream error: %s", e)
            return JSONResponse(
                content={"error": {"message": str(e), "type": "proxy_error"}},
                status_code=502,
            )

    def _upstream_headers(request: Request) -> dict:
        """Build headers for upstream API call."""
        # Use API key from config, or passthrough from client
        api_key = config.openai_api_key
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer ") and not api_key:
            api_key = auth_header[7:]

        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    def _extract_response_text(resp_data: dict) -> Optional[str]:
        """Extract text from OpenAI response dict."""
        choices = resp_data.get("choices", [])
        if choices:
            msg = choices[0].get("message", {})
            return msg.get("content")
        return None

    return app


# Default app instance (for `uvicorn cacheback.proxy.app:app`)
app = create_app()
