"""cacheback CLI — manage the semantic cache.

Usage:
    cacheback stats          # Show cache statistics
    cacheback entries        # List cached entries
    cacheback evict          # Remove expired entries
    cacheback clear          # Clear all entries
    cacheback lookup "query" # Test a cache lookup
"""

import argparse
import time

from cacheback.cache import SemanticCache, DEFAULT_CACHE_DIR


def cmd_stats(cache: SemanticCache, args):
    s = cache.stats
    print(f"Cache directory: {cache._cache_dir}")
    print(f"Embedder:        {s['embedder']} ({s['modality']})")
    print(f"Entries:         {s['entries']}")
    print(f"Hits:            {s['hits']}")
    print(f"Misses:          {s['misses']}")
    print(f"Hit rate:        {s['hit_rate']:.1%}")
    print(f"Populations:     {s['populations']}")


def cmd_entries(cache: SemanticCache, args):
    cache._lazy_init()
    store = cache._store
    store._ensure_db()

    rows = store._conn.execute(
        """SELECT id, query_text, model, tokens, hit_count, modality, created_at, expires_at
           FROM cache_entries WHERE expires_at > ?
           ORDER BY created_at DESC LIMIT ?""",
        (time.time(), args.limit),
    ).fetchall()

    if not rows:
        print("No cache entries.")
        return

    for r in rows:
        age_h = (time.time() - r[6]) / 3600
        ttl_h = (r[7] - time.time()) / 3600
        print(
            f"[{r[0]:>4}] {r[1][:55]:<55} "
            f"hits={r[4]} model={r[2][:15]} "
            f"mod={r[5]} age={age_h:.1f}h ttl={ttl_h:.0f}h"
        )


def cmd_evict(cache: SemanticCache, args):
    evicted = cache.evict_expired()
    print(f"Evicted {evicted} expired entries.")
    print(f"Remaining: {cache.stats['entries']}")


def cmd_clear(cache: SemanticCache, args):
    cache._lazy_init()
    cache._store._ensure_db()
    cursor = cache._store._conn.execute("DELETE FROM cache_entries")
    cache._store._conn.commit()
    print(f"Cleared {cursor.rowcount} entries.")


def cmd_lookup(cache: SemanticCache, args):
    query = " ".join(args.query)
    if not query:
        print("Usage: cacheback lookup 'your query here'")
        return

    start = time.time()
    result = cache.lookup(query)
    latency = (time.time() - start) * 1000

    if result:
        print(f"HIT ({latency:.1f}ms)")
        print(f"Response: {result[:500]}")
    else:
        print(f"MISS ({latency:.1f}ms)")


def main():
    parser = argparse.ArgumentParser(
        prog="cacheback",
        description="Universal semantic cache for AI APIs",
    )
    parser.add_argument("--cache-dir", default=DEFAULT_CACHE_DIR, help="Cache directory")
    parser.add_argument("--threshold", type=float, default=0.92, help="Similarity threshold")
    parser.add_argument("--embedder", default="minilm", help="Embedder name (minilm, clip, clap, whisper)")

    sub = parser.add_subparsers(dest="command")

    sub.add_parser("stats", help="Show cache statistics")

    entries_p = sub.add_parser("entries", help="List cached entries")
    entries_p.add_argument("--limit", type=int, default=20, help="Max entries to show")

    sub.add_parser("evict", help="Remove expired entries")
    sub.add_parser("clear", help="Clear all entries")

    lookup_p = sub.add_parser("lookup", help="Test a cache lookup")
    lookup_p.add_argument("query", nargs="*", help="Query text")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    cache = SemanticCache(
        cache_dir=args.cache_dir,
        similarity_threshold=args.threshold,
        embedder=args.embedder,
    )

    try:
        {
            "stats": cmd_stats,
            "entries": cmd_entries,
            "evict": cmd_evict,
            "clear": cmd_clear,
            "lookup": cmd_lookup,
        }[args.command](cache, args)
    finally:
        cache.close()


if __name__ == "__main__":
    main()
