# cacheback TODOS

## Deferred from CEO Review (2026-03-23)

### TODO-1: Evaluate Gemini Embedding 2 for multimodal unification
- **What:** Google's Gemini Embedding 2 (March 2026) handles text+image+audio+video+PDF in a single vector space. Evaluate whether it can replace the planned 4-model architecture (MiniLM + CLIP + CLAP + Whisper).
- **Why:** A single natively multimodal embedder would eliminate the `EmbedderRegistry` complexity, reduce download size (~90MB vs ~530MB for 4 models), and unify the vector index (one dim, one index file per cache namespace).
- **Pros:** Massive simplification. One model, one dimension, one index. API-based (no ONNX downloads). Google offers free tier.
- **Cons:** API dependency (network latency vs local ONNX). Rate limits. Privacy (queries sent to Google). No offline mode. Lock-in risk.
- **Context:** EUREKA finding from CEO review. The current `BaseEmbedder` ABC + registry is already built (Phase 1). Gemini Embedding 2 could be added as just another embedder plugin (e.g., `GeminiEmbedder`), preserving the local-first MiniLM default while offering a cloud-powered multimodal option. Best of both worlds.
- **Effort:** M (human) / S (CC+gstack) — implement `embedders/gemini.py`, add tests, update docs
- **Priority:** P2 (Phase 1.5, after image cache lands)
- **Depends on:** Embedder registry (done), CLIP embedder (Phase 1.5)
