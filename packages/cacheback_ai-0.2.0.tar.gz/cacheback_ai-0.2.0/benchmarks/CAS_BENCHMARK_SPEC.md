# Cache-Augmented Synthesis (CAS) Benchmark Specification

> **Version:** 1.0 (2026-03-23)
> **Author:** BGML.ai Research
> **Status:** Ready for implementation

## 1. Problem Statement

Current semantic caches return **verbatim** cached responses when a query is
semantically similar to a previously seen one. This works for exact paraphrases
but fails when the new query has different intent nuances, needs context from the
conversation, or requires synthesizing knowledge from multiple cached entries.

**Cache-Augmented Synthesis (CAS)** uses a small local model (Phi-4-mini, 3.8B)
to **synthesize** a new response from K cached GPT-4 responses + conversation
context, rather than returning a verbatim cache hit. This benchmark measures
whether CAS produces responses competitive with fresh GPT-4 calls at a fraction
of the cost and latency.

## 2. Research Questions

| ID | Question | Metric |
|----|----------|--------|
| RQ1 | Does CAS match fresh GPT-4 quality? | LLM-judge win rate, BERTScore |
| RQ2 | Does CAS beat verbatim cache returns? | LLM-judge pairwise, factual accuracy |
| RQ3 | Does ensemble (3 models + MoA) beat single-model CAS? | Quality delta, latency tradeoff |
| RQ4 | What is the cost/latency break-even? | $/query, ms/query, quality threshold |
| RQ5 | How does K (number of cached refs) affect quality? | Quality vs K curve |
| RQ6 | How sensitive is CAS to cache-query semantic distance? | Quality vs similarity score |

## 3. Baselines (5 conditions)

| ID | Condition | Description | Cost Profile |
|----|-----------|-------------|--------------|
| B0 | **Fresh GPT-4** | Direct GPT-4o API call, no cache | $$$ (ceiling) |
| B1 | **Verbatim Cache** | Return highest-similarity cached response as-is | $0 (floor) |
| B2 | **CAS-Single** | Phi-4-mini synthesizes from top-K cached responses | $ (local compute) |
| B3 | **CAS-Ensemble** | 3x Phi-4-mini (temp 0.3/0.7/1.0) + Self-MoA aggregation | $$  (3x local) |
| B4 | **CAS-Debate** | 2x Phi-4-mini generate, 1x Phi-4-mini critiques + refines (RPI pattern) | $$ (3x local) |

### Why Self-MoA over Mixed-MoA

Per "Rethinking Mixture-of-Agents" (Li et al., 2025): Self-MoA (same model,
multiple samples) outperforms Mixed-MoA by 6.6% on AlpacaEval 2.0 and 3.8%
average across MMLU/CRUX/MATH. Since our fleet runs Phi-4-mini exclusively,
Self-MoA is the correct ensemble strategy. Mixed-MoA requires high-quality
diverse models; mixing weaker models drags down quality.

## 4. Datasets (3 domains, 200 test cases each = 600 total)

### 4.1 Knowledge QA (factoid + explanatory)

**Source:** Natural Questions (NQ) open subset + TriviaQA
**Setup:** Pre-populate cache with 5 GPT-4 responses per cluster (1000 cache entries for 200 test queries). Each test query is a **paraphrase** of a cached query but with added specificity or different angle.

```
Cache entry:  "What causes earthquakes?" -> GPT-4 response about tectonic plates
Test query:   "Why do earthquakes happen more often near the Pacific Ring of Fire?"
```

**Construction method:**
1. Sample 200 questions from NQ where GPT-4 gives correct answers
2. For each, generate 5 paraphrased variants via GPT-4 (different angles, specificity levels)
3. Get GPT-4 responses for all 5 paraphrases -> these become cache entries
4. Generate a 6th variant (the test query) that requires synthesizing info from multiple cached answers
5. Get GPT-4 gold response for the test query

### 4.2 Customer Support FAQ

**Source:** Synthetic, modeled on SaaS support (billing, features, troubleshooting)
**Setup:** 50 product topics x 4 question variants each = 200 test cases

```
Cache entries: [
  "How do I cancel my subscription?" -> detailed cancellation steps,
  "What happens to my data after cancellation?" -> data retention policy,
  "Can I get a refund after cancelling?" -> refund policy,
  "How do I downgrade instead of cancelling?" -> downgrade steps,
  "Is there a cancellation fee?" -> fee policy
]
Test query: "I want to stop paying but keep my data — what are my options?"
```

**Construction method:**
1. Define 50 product topics with realistic FAQ clusters
2. GPT-4 generates 5 Q&A pairs per topic (cache entries)
3. GPT-4 generates 4 composite test queries per topic that require multi-entry synthesis
4. GPT-4 generates gold responses for test queries

### 4.3 Code Assistance

**Source:** Subset of HumanEval + MBPP problems, rephrased
**Setup:** Cache contains GPT-4 solutions to related coding problems; test queries are variations.

```
Cache entries: [
  "Write a function to reverse a string" -> GPT-4 solution,
  "Write a function to check if a string is a palindrome" -> GPT-4 solution,
  "Write a function to remove duplicates from a string" -> GPT-4 solution,
  ...
]
Test query: "Write a function that returns the longest palindromic substring"
```

**Construction method:**
1. Sample 40 HumanEval problems + 160 MBPP problems
2. For each, identify 5 related problems from the same dataset or generate via GPT-4
3. Cache GPT-4 solutions for the 5 related problems
4. Test query = original problem; GPT-4 gold = original GPT-4 solution
5. Verify solutions execute correctly (automated test harness)

### Dataset Statistics Target

| Domain | Test Queries | Cache Entries | Avg Cached Refs/Query |
|--------|-------------|---------------|----------------------|
| Knowledge QA | 200 | 1,000 | 5 |
| Customer Support | 200 | 1,000 | 5 |
| Code Assist | 200 | 1,000 | 5 |
| **Total** | **600** | **3,000** | **5** |

## 5. Evaluation Metrics

### 5.1 Quality Metrics (Primary)

#### LLM-as-Judge (Primary metric)

**Model:** GPT-4o (or GPT-4o-mini as budget proxy, with calibration subset)
**Method:** Pairwise comparison + absolute scoring

**Pairwise prompt (for RQ1, RQ2, RQ3):**

```
You are an expert evaluator comparing two AI responses to a user query.

## User Query
{query}

## Conversation Context (if any)
{context}

## Response A
{response_a}

## Response B
{response_b}

## Evaluation Criteria
1. **Factual Accuracy**: Are the facts correct and verifiable?
2. **Relevance**: Does the response address the specific query (not just the general topic)?
3. **Completeness**: Does it cover all aspects the user asked about?
4. **Coherence**: Is it well-structured and easy to follow?
5. **Specificity**: Does it provide specific, actionable information vs vague generalities?

## Instructions
- Compare Response A and Response B on each criterion (1-5 scale each)
- Declare a winner: A, B, or TIE
- Output JSON only:

{
  "scores_a": {"accuracy": N, "relevance": N, "completeness": N, "coherence": N, "specificity": N},
  "scores_b": {"accuracy": N, "relevance": N, "completeness": N, "coherence": N, "specificity": N},
  "winner": "A" | "B" | "TIE",
  "reasoning": "brief explanation"
}
```

**Position bias mitigation:** Run each pair twice (A/B swapped). If judgments disagree, count as TIE.

**Absolute scoring prompt (for overall quality distribution):**

```
You are an expert evaluator. Rate this AI response on a 1-10 scale.

## User Query
{query}

## AI Response
{response}

## Rating Criteria
- 1-2: Incorrect, irrelevant, or harmful
- 3-4: Partially correct but missing key information
- 5-6: Correct but generic, could be more helpful
- 7-8: Good, accurate, relevant, well-structured
- 9-10: Excellent, comprehensive, insightful, perfectly tailored

Output JSON: {"score": N, "reasoning": "brief explanation"}
```

#### BERTScore (Secondary, automated)

Compare each response against GPT-4 gold reference using `bert-score` library
with `microsoft/deberta-xlarge-mnli` model. Report F1 score.

**Rationale:** BERTScore correlates weakly with human judgment for open-ended
generation (recent 2024 findings), but provides a useful automated sanity check
and catches catastrophic failures. It should NOT be the primary metric.

#### Factual Accuracy (Domain-specific)

- **Knowledge QA:** Extract factual claims, verify against gold. Binary per-claim,
  report claim-level accuracy.
- **Customer Support:** Check for policy contradictions, hallucinated features.
  LLM-judge with domain rubric.
- **Code Assist:** Execute generated code against test cases. Report pass@1.

### 5.2 Efficiency Metrics

| Metric | How Measured | Unit |
|--------|-------------|------|
| **Latency (e2e)** | Wall clock from query receipt to response complete | ms |
| **Latency (synthesis)** | Time for Phi-4-mini to generate synthesis | ms |
| **Latency (cache lookup)** | Embedding + vector search time | ms |
| **Cost per query** | API costs + compute cost (amortized fleet) | $/query |
| **Tokens generated** | Output tokens from synthesizer | count |
| **Tokens in context** | Total prompt tokens (cached refs + query + system) | count |

#### Cost Model

```python
COST_MODEL = {
    "gpt-4o": {"input": 2.50 / 1e6, "output": 10.00 / 1e6},        # $/token
    "gpt-4o-mini": {"input": 0.15 / 1e6, "output": 0.60 / 1e6},
    "phi-4-mini-local": {"input": 0.0, "output": 0.0,                # local compute
                          "compute_cost_per_hour": 0.05},             # electricity ~23 PCs
    "judge-gpt-4o": {"input": 2.50 / 1e6, "output": 10.00 / 1e6},   # eval cost
}

def compute_cost(condition, input_tokens, output_tokens, latency_s):
    """Compute cost per query including amortized fleet compute."""
    if condition == "B0":  # Fresh GPT-4
        return input_tokens * COST_MODEL["gpt-4o"]["input"] + \
               output_tokens * COST_MODEL["gpt-4o"]["output"]
    elif condition == "B1":  # Verbatim cache
        return 0.0001  # ~electricity for lookup
    elif condition in ("B2", "B3", "B4"):  # CAS variants
        fleet_cost = latency_s * COST_MODEL["phi-4-mini-local"]["compute_cost_per_hour"] / 3600
        return fleet_cost
```

### 5.3 Composite Score

```
CAS_Score = Quality_Normalized * (1 / (1 + log10(Cost_Ratio))) * (1 / (1 + log10(Latency_Ratio)))
```

Where:
- `Quality_Normalized` = LLM-judge score / GPT-4 baseline score
- `Cost_Ratio` = cost of condition / cost of GPT-4 baseline
- `Latency_Ratio` = latency of condition / latency of verbatim cache

## 6. Synthesis Prompts

### 6.1 CAS-Single System Prompt

```
You are a precise AI assistant. You have access to cached expert responses to
similar questions. Your job is to synthesize a NEW, tailored response to the
user's specific query by drawing on these cached references.

RULES:
1. Use the cached responses as your knowledge base — they were generated by a
   more capable model
2. DO NOT copy any single cached response verbatim
3. SYNTHESIZE: combine relevant information from multiple cached responses
4. ADAPT: tailor your response to the specific nuances of the user's query
5. If cached responses conflict, prefer the majority consensus
6. If the user's query asks for something not covered by any cached response,
   say "I don't have enough information to answer this specific aspect"
7. Maintain factual accuracy — do not add information not present in the
   cached responses
```

### 6.2 CAS-Single User Prompt Template

```
## User Query
{user_query}

## Conversation Context
{conversation_context}

## Cached Expert Responses (from similar queries)
{for i, (cached_query, cached_response, similarity) in enumerate(cached_refs)}
### Reference {i+1} (similarity: {similarity:.2f})
**Original question:** {cached_query}
**Expert response:** {cached_response}
{endfor}

## Your Task
Synthesize a response to the User Query above, drawing on the Cached Expert
Responses. Adapt the information to precisely match what the user is asking for.
```

### 6.3 CAS-Ensemble (Self-MoA) Aggregation Prompt

```
You are an expert aggregator. Below are three candidate responses to the same
user query. Synthesize the BEST possible response by:
1. Identifying the strongest elements from each candidate
2. Resolving any contradictions (majority wins, or flag uncertainty)
3. Producing a single, coherent, comprehensive response

## User Query
{user_query}

## Candidate 1 (temperature=0.3, conservative)
{response_1}

## Candidate 2 (temperature=0.7, balanced)
{response_2}

## Candidate 3 (temperature=1.0, creative)
{response_3}

## Your Aggregated Response
```

### 6.4 CAS-Debate (RPI) Prompts

**Generator prompt:** Same as CAS-Single (section 6.2)

**Critic prompt:**
```
You are a critical reviewer. Evaluate this AI response for:
1. Factual errors (compared to the cached references)
2. Missing information that the cached references contain
3. Information NOT supported by any cached reference (hallucination)
4. Relevance to the specific user query

## User Query
{user_query}

## Cached References (ground truth)
{cached_refs_formatted}

## Response Under Review
{response_to_critique}

## Your Critique
List specific issues. For each issue, cite which cached reference contradicts
or supports the claim. End with: "VERDICT: PASS" or "VERDICT: REVISE [list of issues]"
```

**Refiner prompt:**
```
Revise your response based on this critique. Fix ONLY the issues raised.
Do not change parts that were not criticized.

## Original Response
{original_response}

## Critique
{critique}

## Revised Response
```

## 7. Experimental Protocol

### 7.1 Cache Population Phase (offline, one-time)

1. For each of 600 test queries, retrieve the 5 pre-generated cache entries
2. Populate a cacheback SemanticCache instance with all 3,000 entries
3. Verify cache hit rate: each test query should retrieve its corresponding
   cluster (similarity > 0.80 for at least 3 of 5 entries)
4. Record actual similarity scores for analysis (RQ6)

### 7.2 Evaluation Phase

For each of 600 test queries, run all 5 conditions:

```python
for query in test_queries:  # 600
    results = {}

    # B0: Fresh GPT-4
    t0 = time.time()
    results["B0"] = call_gpt4(query)
    results["B0_latency"] = time.time() - t0

    # B1: Verbatim cache (top-1 hit)
    t0 = time.time()
    cached_refs = cache.lookup_topk(query, k=5)
    results["B1"] = cached_refs[0].response  # best match
    results["B1_latency"] = time.time() - t0

    # B2: CAS-Single
    t0 = time.time()
    results["B2"] = phi4_synthesize(query, cached_refs, temperature=0.7)
    results["B2_latency"] = time.time() - t0

    # B3: CAS-Ensemble (Self-MoA)
    t0 = time.time()
    r1 = phi4_synthesize(query, cached_refs, temperature=0.3)
    r2 = phi4_synthesize(query, cached_refs, temperature=0.7)
    r3 = phi4_synthesize(query, cached_refs, temperature=1.0)
    results["B3"] = phi4_aggregate([r1, r2, r3], query)
    results["B3_latency"] = time.time() - t0

    # B4: CAS-Debate (RPI)
    t0 = time.time()
    draft1 = phi4_synthesize(query, cached_refs, temperature=0.7)
    draft2 = phi4_synthesize(query, cached_refs, temperature=0.9)
    critique = phi4_critique(query, cached_refs, draft1)
    results["B4"] = phi4_refine(draft1, critique)
    results["B4_latency"] = time.time() - t0

    store_results(query, results)
```

### 7.3 Judging Phase

For each query, run pairwise comparisons:
- B0 vs B1 (GPT-4 vs verbatim — is synthesis even needed?)
- B0 vs B2 (GPT-4 vs CAS-Single — main research question)
- B1 vs B2 (verbatim vs CAS-Single — does synthesis help?)
- B2 vs B3 (single vs ensemble — is ensemble worth 3x cost?)
- B2 vs B4 (single vs debate — is debate worth 3x cost?)

Total judge calls: 600 queries x 5 pairs x 2 (position swap) = **6,000 judge calls**

Judge cost estimate (GPT-4o): ~800 input tokens/call x 200 output tokens/call
= 6000 * (800 * 2.50/1e6 + 200 * 10.00/1e6) = **$24.00**

Judge cost estimate (GPT-4o-mini): ~$2.16

### 7.4 Fleet Distribution (23 PCs)

```
Phase 1 — Cache Population:
  PC-1:  Run GPT-4 API calls to generate 3,000 cache entries (serial, ~2h)

Phase 2 — Evaluation:
  PC-1..10:  B2 (CAS-Single) — 60 queries each, parallel
  PC-11..17: B3 (CAS-Ensemble) — ~86 queries each, 3 sequential inferences per query
  PC-18..23: B4 (CAS-Debate) — ~100 queries each, 3 sequential inferences per query
  (B0 and B1 run on PC-1 only — API calls and cache lookups, no local compute)

Estimated wall-clock time:
  B0: 600 queries * ~2s/query = 20 min
  B1: 600 queries * ~0.05s/query = 30 sec
  B2: 60 queries/PC * ~5s/query = 5 min (10 PCs parallel)
  B3: 86 queries/PC * ~15s/query = 21 min (7 PCs parallel)
  B4: 100 queries/PC * ~15s/query = 25 min (6 PCs parallel)

  Total: ~30 min wall-clock with full fleet
```

## 8. Statistical Methodology

### 8.1 Sample Size Justification

**Target:** Detect a 5-percentage-point difference in win rate with 80% power at alpha=0.05.

Using the formula for comparing two proportions (two-sided):
- H0: p1 = p2 = 0.50 (tied win rate)
- H1: p1 = 0.55, p2 = 0.45 (5pp difference)
- n = (Z_alpha/2 + Z_beta)^2 * (p1(1-p1) + p2(1-p2)) / (p1-p2)^2
- n = (1.96 + 0.84)^2 * (0.55*0.45 + 0.45*0.55) / (0.10)^2
- n = 7.84 * 0.495 / 0.01 = **388 per condition**

With 600 test cases (200 per domain), we have sufficient power for:
- Overall comparisons (600 pairs per comparison)
- Per-domain analysis (200 pairs — sufficient for 10pp effect size)

### 8.2 Statistical Tests

| Comparison | Test | Why |
|------------|------|-----|
| Win rate (pairwise) | Paired bootstrap (10,000 resamples) | Accounts for per-query correlation |
| Absolute scores | Wilcoxon signed-rank test | Non-parametric, paired, ordinal data |
| BERTScore | Paired t-test with bootstrap CI | Continuous metric, paired |
| Latency | Mann-Whitney U | Non-normal distribution expected |
| Per-domain differences | Stratified bootstrap | Control for domain effects |

### 8.3 Multiple Comparison Correction

With 5 pairwise comparisons, apply Holm-Bonferroni correction (step-down):
1. Sort p-values ascending
2. Compare p_i against alpha / (5 - i + 1)
3. Reject until first non-rejection

### 8.4 Confidence Intervals

Report 95% bootstrap CIs for all metrics (10,000 resamples). Use BCa
(bias-corrected and accelerated) intervals for better small-sample coverage.

### 8.5 Effect Size

Report Cohen's d for continuous metrics and odds ratios for win rates.
Interpret:
- Small: d = 0.2 (or OR < 1.5)
- Medium: d = 0.5 (or OR 1.5-3.0)
- Large: d = 0.8 (or OR > 3.0)

## 9. Ablation Studies

### 9.1 K-variation (RQ5)

Test CAS-Single with K = {1, 2, 3, 5, 7, 10} cached references.
Hypothesis: diminishing returns after K=5, context window pollution after K=7.

### 9.2 Similarity threshold (RQ6)

Bucket test queries by cache-query similarity:
- High: 0.90-1.00 (near paraphrase)
- Medium: 0.80-0.90 (same topic, different angle)
- Low: 0.70-0.80 (related but distinct)

Hypothesis: CAS advantage over verbatim increases as similarity decreases.

### 9.3 Temperature sweep

Test CAS-Single at temperatures {0.0, 0.1, 0.3, 0.5, 0.7, 1.0}.
Find quality-diversity Pareto front.

### 9.4 Context window budget

Test with max context budgets of {2048, 4096, 8192, 16384} tokens.
Measure quality degradation as budget shrinks (relevant for constrained devices).

## 10. Implementation Skeleton

```python
#!/usr/bin/env python3
"""CAS Benchmark Runner — Cache-Augmented Synthesis evaluation suite.

Usage:
    python cas_benchmark.py --phase populate    # Generate cache entries
    python cas_benchmark.py --phase evaluate    # Run all conditions
    python cas_benchmark.py --phase judge       # LLM-as-judge evaluation
    python cas_benchmark.py --phase analyze     # Statistical analysis + report

Requires:
    pip install cacheback-ai openai numpy scipy bert-score tqdm
    Local: llama-cpp-python with Phi-4-mini-instruct GGUF
"""

import argparse
import json
import os
import time
import hashlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

import numpy as np

# ── Configuration ──────────────────────────────────────────────────────────

BENCHMARK_DIR = Path(__file__).parent / "cas_data"
CACHE_DIR = BENCHMARK_DIR / "cache"
RESULTS_DIR = BENCHMARK_DIR / "results"
DATASETS_DIR = BENCHMARK_DIR / "datasets"

PHI4_MODEL_PATH = os.environ.get(
    "PHI4_GGUF_PATH",
    os.path.expanduser("~/.cache/huggingface/hub/Phi-4-mini-instruct-Q4_K_M.gguf"),
)
PHI4_CONTEXT_SIZE = 16384  # 16K tokens, conservative for 128K model
PHI4_GPU_LAYERS = 0        # CPU-only for fleet compatibility

OPENAI_MODEL = "gpt-4o"
JUDGE_MODEL = "gpt-4o"     # or "gpt-4o-mini" for budget runs

K_CACHED_REFS = 5          # Number of cached references per query
NUM_BOOTSTRAP = 10_000     # Bootstrap resamples for CIs

# Temperature configs for ensemble
ENSEMBLE_TEMPS = [0.3, 0.7, 1.0]

# ── Data Structures ────────────────────────────────────────────────────────

@dataclass
class CacheEntry:
    query: str
    response: str
    domain: str
    cluster_id: str
    model: str = "gpt-4o"

@dataclass
class TestCase:
    query_id: str
    query: str
    domain: str           # "knowledge_qa" | "customer_support" | "code_assist"
    cluster_id: str
    gold_response: str    # GPT-4 response to this exact query
    context: str = ""     # Conversation context (if any)

@dataclass
class EvalResult:
    query_id: str
    condition: str        # "B0".."B4"
    response: str
    latency_ms: float
    input_tokens: int
    output_tokens: int
    cost_usd: float
    cached_refs_used: int
    avg_similarity: float

@dataclass
class JudgeVerdict:
    query_id: str
    pair: str             # e.g., "B0_vs_B2"
    scores_a: dict
    scores_b: dict
    winner: str           # "A" | "B" | "TIE"
    reasoning: str

# ── Phase 1: Dataset Generation ───────────────────────────────────────────

def generate_knowledge_qa_dataset(n: int = 200) -> tuple[list[CacheEntry], list[TestCase]]:
    """Generate Knowledge QA dataset from Natural Questions / TriviaQA.

    Strategy:
    1. Sample N seed questions with known correct GPT-4 answers
    2. For each, generate 5 paraphrases (cache entries) + 1 synthesis query (test case)
    3. The synthesis query requires combining info from multiple cache entries
    """
    from openai import OpenAI
    client = OpenAI()

    # Seed questions — curated for factual, multi-faceted answers
    SEED_GENERATION_PROMPT = """Generate {n} diverse factual questions that:
1. Have multi-paragraph answers (not single-fact)
2. Cover science, history, geography, technology, health
3. Are specific enough to have definitive answers
4. Each question should be answerable in 2-4 paragraphs

Output as JSON array of strings. No numbering, no categories."""

    seeds = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[{"role": "user", "content": SEED_GENERATION_PROMPT.format(n=n)}],
        response_format={"type": "json_object"},
        temperature=0.8,
    )

    seed_questions = json.loads(seeds.choices[0].message.content)["questions"]
    cache_entries = []
    test_cases = []

    for i, seed_q in enumerate(seed_questions[:n]):
        cluster_id = f"kqa_{i:03d}"

        # Generate 5 paraphrase variants + responses (cache entries)
        PARAPHRASE_PROMPT = f"""Given this question: "{seed_q}"

Generate 5 different questions that ask about the same topic but from
different angles or with different specificity. Each should require a
slightly different response.

Then generate a 6th question that would require COMBINING information
from multiple of the first 5 answers to fully respond.

Output JSON:
{{
  "paraphrases": ["q1", "q2", "q3", "q4", "q5"],
  "synthesis_query": "q6"
}}"""

        variants = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": PARAPHRASE_PROMPT}],
            response_format={"type": "json_object"},
            temperature=0.7,
        )
        vdata = json.loads(variants.choices[0].message.content)

        # Get GPT-4 responses for cache entries
        for j, pq in enumerate(vdata["paraphrases"]):
            resp = client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[{"role": "user", "content": pq}],
                temperature=0.3,
            )
            cache_entries.append(CacheEntry(
                query=pq,
                response=resp.choices[0].message.content,
                domain="knowledge_qa",
                cluster_id=cluster_id,
            ))

        # Gold response for synthesis query
        gold = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": vdata["synthesis_query"]}],
            temperature=0.3,
        )
        test_cases.append(TestCase(
            query_id=f"kqa_{i:03d}",
            query=vdata["synthesis_query"],
            domain="knowledge_qa",
            cluster_id=cluster_id,
            gold_response=gold.choices[0].message.content,
        ))

    return cache_entries, test_cases


def generate_customer_support_dataset(n: int = 200) -> tuple[list[CacheEntry], list[TestCase]]:
    """Generate Customer Support FAQ dataset.

    Strategy: 50 topics x 4 test queries each = 200 test cases.
    Each topic has 5 cache entries (different FAQ questions).
    """
    from openai import OpenAI
    client = OpenAI()

    TOPIC_PROMPT = """Generate 50 realistic SaaS product support topics. For each topic,
generate:
1. Five FAQ questions with detailed answers (these become cache entries)
2. Four "synthesis" questions that require combining information from
   multiple FAQ answers (these become test queries)

The product is a project management SaaS tool (like Asana/Notion).

Output JSON:
{{
  "topics": [
    {{
      "topic": "billing and payments",
      "faqs": [
        {{"question": "...", "answer": "..."}},
        ...5 total
      ],
      "synthesis_queries": ["q1", "q2", "q3", "q4"]
    }},
    ...50 total
  ]
}}"""

    # This would be chunked in practice due to output length
    # Implementation would batch 10 topics at a time
    # Simplified here for spec clarity

    # ... (same pattern as knowledge_qa)
    pass  # Full implementation in cas_benchmark.py


def generate_code_assist_dataset(n: int = 200) -> tuple[list[CacheEntry], list[TestCase]]:
    """Generate Code Assistance dataset from HumanEval/MBPP variants."""
    # ... (same pattern, with executable test verification)
    pass


# ── Phase 2: Cache Population ─────────────────────────────────────────────

def populate_cache(cache_entries: list[CacheEntry]):
    """Populate a cacheback SemanticCache with all cache entries."""
    from cacheback import SemanticCache

    cache = SemanticCache(
        cache_dir=str(CACHE_DIR),
        similarity_threshold=0.75,  # Lower threshold for benchmark — want to retrieve related, not just paraphrases
        embedder="minilm",
    )

    for entry in cache_entries:
        cache.populate(
            query=entry.query,
            response=entry.response,
            model=entry.model,
        )

    cache.save()
    cache.close()
    print(f"Populated cache with {len(cache_entries)} entries")


# ── Phase 3: Evaluation ───────────────────────────────────────────────────

class Phi4Synthesizer:
    """Phi-4-mini inference via llama-cpp-python."""

    def __init__(self, model_path: str = PHI4_MODEL_PATH):
        from llama_cpp import Llama
        self.llm = Llama(
            model_path=model_path,
            n_ctx=PHI4_CONTEXT_SIZE,
            n_gpu_layers=PHI4_GPU_LAYERS,
            verbose=False,
        )

    def generate(self, system: str, user: str, temperature: float = 0.7,
                 max_tokens: int = 1024) -> tuple[str, dict]:
        """Generate response, return (text, usage_dict)."""
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        t0 = time.time()
        resp = self.llm.create_chat_completion(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        latency = (time.time() - t0) * 1000
        text = resp["choices"][0]["message"]["content"]
        usage = resp.get("usage", {})
        return text, {"latency_ms": latency, **usage}


# CAS synthesis prompt templates (from Section 6)
CAS_SYSTEM_PROMPT = """You are a precise AI assistant. You have access to cached expert responses to
similar questions. Your job is to synthesize a NEW, tailored response to the
user's specific query by drawing on these cached references.

RULES:
1. Use the cached responses as your knowledge base -- they were generated by a
   more capable model
2. DO NOT copy any single cached response verbatim
3. SYNTHESIZE: combine relevant information from multiple cached responses
4. ADAPT: tailor your response to the specific nuances of the user's query
5. If cached responses conflict, prefer the majority consensus
6. If the user's query asks for something not covered by any cached response,
   say "I don't have enough information to answer this specific aspect"
7. Maintain factual accuracy -- do not add information not present in the
   cached responses"""


def format_cas_user_prompt(query: str, cached_refs: list[tuple[str, str, float]],
                           context: str = "") -> str:
    """Format user prompt with cached references."""
    refs_text = ""
    for i, (cq, cr, sim) in enumerate(cached_refs):
        refs_text += f"\n### Reference {i+1} (similarity: {sim:.2f})\n"
        refs_text += f"**Original question:** {cq}\n"
        refs_text += f"**Expert response:** {cr}\n"

    return f"""## User Query
{query}

## Conversation Context
{context or "(none)"}

## Cached Expert Responses (from similar queries)
{refs_text}

## Your Task
Synthesize a response to the User Query above, drawing on the Cached Expert
Responses. Adapt the information to precisely match what the user is asking for."""


def run_evaluation(test_cases: list[TestCase], cache_entries: list[CacheEntry]):
    """Run all 5 conditions on all test cases."""
    from openai import OpenAI
    from cacheback import SemanticCache

    oai = OpenAI()
    phi4 = Phi4Synthesizer()
    cache = SemanticCache(cache_dir=str(CACHE_DIR), similarity_threshold=0.75)

    results = []

    for tc in test_cases:
        # Retrieve cached references for this query
        # (We need a topk lookup — extend cacheback or use raw index)
        cached_refs = retrieve_topk(cache, tc.query, k=K_CACHED_REFS)

        # B0: Fresh GPT-4
        t0 = time.time()
        b0_resp = oai.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": tc.query}],
            temperature=0.3,
        )
        b0_latency = (time.time() - t0) * 1000
        results.append(EvalResult(
            query_id=tc.query_id, condition="B0",
            response=b0_resp.choices[0].message.content,
            latency_ms=b0_latency,
            input_tokens=b0_resp.usage.prompt_tokens,
            output_tokens=b0_resp.usage.completion_tokens,
            cost_usd=compute_api_cost("gpt-4o", b0_resp.usage.prompt_tokens,
                                       b0_resp.usage.completion_tokens),
            cached_refs_used=0,
            avg_similarity=0.0,
        ))

        # B1: Verbatim cache (top-1)
        t0 = time.time()
        b1_response = cached_refs[0][1] if cached_refs else ""
        b1_latency = (time.time() - t0) * 1000
        results.append(EvalResult(
            query_id=tc.query_id, condition="B1",
            response=b1_response,
            latency_ms=b1_latency,
            input_tokens=0, output_tokens=0, cost_usd=0.0001,
            cached_refs_used=1,
            avg_similarity=cached_refs[0][2] if cached_refs else 0.0,
        ))

        # B2: CAS-Single
        user_prompt = format_cas_user_prompt(tc.query, cached_refs, tc.context)
        b2_text, b2_usage = phi4.generate(CAS_SYSTEM_PROMPT, user_prompt, temperature=0.7)
        avg_sim = np.mean([r[2] for r in cached_refs]) if cached_refs else 0.0
        results.append(EvalResult(
            query_id=tc.query_id, condition="B2",
            response=b2_text,
            latency_ms=b2_usage["latency_ms"],
            input_tokens=b2_usage.get("prompt_tokens", 0),
            output_tokens=b2_usage.get("completion_tokens", 0),
            cost_usd=b2_usage["latency_ms"] / 1000 * 0.05 / 3600,
            cached_refs_used=len(cached_refs),
            avg_similarity=avg_sim,
        ))

        # B3: CAS-Ensemble (Self-MoA)
        t0 = time.time()
        ensemble_responses = []
        for temp in ENSEMBLE_TEMPS:
            r_text, _ = phi4.generate(CAS_SYSTEM_PROMPT, user_prompt, temperature=temp)
            ensemble_responses.append(r_text)

        # Aggregate
        agg_prompt = format_aggregation_prompt(tc.query, ensemble_responses)
        b3_text, b3_usage = phi4.generate(
            "You are an expert aggregator. Combine the best elements of "
            "the candidate responses into one optimal response.",
            agg_prompt,
            temperature=0.3,
        )
        b3_latency = (time.time() - t0) * 1000
        results.append(EvalResult(
            query_id=tc.query_id, condition="B3",
            response=b3_text,
            latency_ms=b3_latency,
            input_tokens=b3_usage.get("prompt_tokens", 0) * 4,  # approx
            output_tokens=b3_usage.get("completion_tokens", 0) * 4,
            cost_usd=b3_latency / 1000 * 0.05 / 3600,
            cached_refs_used=len(cached_refs),
            avg_similarity=avg_sim,
        ))

        # B4: CAS-Debate (RPI)
        t0 = time.time()
        draft, _ = phi4.generate(CAS_SYSTEM_PROMPT, user_prompt, temperature=0.7)
        critique_prompt = format_critique_prompt(tc.query, cached_refs, draft)
        critique, _ = phi4.generate(
            "You are a critical reviewer of AI responses.",
            critique_prompt,
            temperature=0.3,
        )
        refine_prompt = format_refine_prompt(draft, critique)
        b4_text, b4_usage = phi4.generate(
            CAS_SYSTEM_PROMPT,
            refine_prompt,
            temperature=0.5,
        )
        b4_latency = (time.time() - t0) * 1000
        results.append(EvalResult(
            query_id=tc.query_id, condition="B4",
            response=b4_text,
            latency_ms=b4_latency,
            input_tokens=b4_usage.get("prompt_tokens", 0) * 3,
            output_tokens=b4_usage.get("completion_tokens", 0) * 3,
            cost_usd=b4_latency / 1000 * 0.05 / 3600,
            cached_refs_used=len(cached_refs),
            avg_similarity=avg_sim,
        ))

    return results


# ── Phase 4: LLM-as-Judge ─────────────────────────────────────────────────

JUDGE_PAIRWISE_PROMPT = """You are an expert evaluator comparing two AI responses to a user query.

## User Query
{query}

## Conversation Context
{context}

## Response A
{response_a}

## Response B
{response_b}

## Evaluation Criteria
1. **Factual Accuracy**: Are the facts correct and verifiable?
2. **Relevance**: Does the response address the specific query (not just the general topic)?
3. **Completeness**: Does it cover all aspects the user asked about?
4. **Coherence**: Is it well-structured and easy to follow?
5. **Specificity**: Does it provide specific, actionable information vs vague generalities?

## Instructions
- Compare Response A and Response B on each criterion (1-5 scale each)
- Declare a winner: A, B, or TIE
- Output ONLY valid JSON:

{{"scores_a": {{"accuracy": N, "relevance": N, "completeness": N, "coherence": N, "specificity": N}}, "scores_b": {{"accuracy": N, "relevance": N, "completeness": N, "coherence": N, "specificity": N}}, "winner": "A" or "B" or "TIE", "reasoning": "brief explanation"}}"""

JUDGE_ABSOLUTE_PROMPT = """You are an expert evaluator. Rate this AI response on a 1-10 scale.

## User Query
{query}

## AI Response
{response}

## Rating Criteria
- 1-2: Incorrect, irrelevant, or harmful
- 3-4: Partially correct but missing key information
- 5-6: Correct but generic, could be more helpful
- 7-8: Good, accurate, relevant, well-structured
- 9-10: Excellent, comprehensive, insightful, perfectly tailored

Output ONLY valid JSON: {{"score": N, "reasoning": "brief explanation"}}"""

COMPARISON_PAIRS = [
    ("B0", "B1"),  # GPT-4 vs verbatim cache
    ("B0", "B2"),  # GPT-4 vs CAS-Single
    ("B1", "B2"),  # verbatim vs CAS-Single
    ("B2", "B3"),  # CAS-Single vs CAS-Ensemble
    ("B2", "B4"),  # CAS-Single vs CAS-Debate
]


def run_judge(results: list[EvalResult], test_cases: list[TestCase]):
    """Run LLM-as-judge pairwise comparisons with position bias mitigation."""
    from openai import OpenAI
    oai = OpenAI()

    verdicts = []
    results_by_query = {}
    for r in results:
        results_by_query.setdefault(r.query_id, {})[r.condition] = r

    tc_map = {tc.query_id: tc for tc in test_cases}

    for qid, cond_results in results_by_query.items():
        tc = tc_map[qid]

        for cond_a, cond_b in COMPARISON_PAIRS:
            if cond_a not in cond_results or cond_b not in cond_results:
                continue

            resp_a = cond_results[cond_a].response
            resp_b = cond_results[cond_b].response

            # Run twice with swapped positions
            for swap in [False, True]:
                ra, rb = (resp_b, resp_a) if swap else (resp_a, resp_b)
                prompt = JUDGE_PAIRWISE_PROMPT.format(
                    query=tc.query,
                    context=tc.context or "(none)",
                    response_a=ra,
                    response_b=rb,
                )

                judge_resp = oai.chat.completions.create(
                    model=JUDGE_MODEL,
                    messages=[{"role": "user", "content": prompt}],
                    response_format={"type": "json_object"},
                    temperature=0.0,
                )

                verdict_raw = json.loads(judge_resp.choices[0].message.content)

                # Un-swap the winner
                winner = verdict_raw["winner"]
                if swap:
                    if winner == "A":
                        winner = "B"
                    elif winner == "B":
                        winner = "A"
                    # TIE stays TIE

                verdicts.append(JudgeVerdict(
                    query_id=qid,
                    pair=f"{cond_a}_vs_{cond_b}",
                    scores_a=verdict_raw["scores_a"] if not swap else verdict_raw["scores_b"],
                    scores_b=verdict_raw["scores_b"] if not swap else verdict_raw["scores_a"],
                    winner=winner,
                    reasoning=verdict_raw["reasoning"],
                ))

    return verdicts


# ── Phase 5: Statistical Analysis ─────────────────────────────────────────

def analyze_results(results: list[EvalResult], verdicts: list[JudgeVerdict]):
    """Comprehensive statistical analysis."""
    from scipy import stats

    analysis = {}

    # 1. Win rates per comparison pair
    for pair_name in [f"{a}_vs_{b}" for a, b in COMPARISON_PAIRS]:
        pair_verdicts = [v for v in verdicts if v.pair == pair_name]

        # Consolidate position-swapped pairs
        consolidated = {}
        for v in pair_verdicts:
            key = v.query_id
            consolidated.setdefault(key, []).append(v.winner)

        wins_a, wins_b, ties = 0, 0, 0
        for qid, winners in consolidated.items():
            if len(winners) == 2:
                if winners[0] == winners[1]:  # Both agree
                    if winners[0] == "A":
                        wins_a += 1
                    elif winners[0] == "B":
                        wins_b += 1
                    else:
                        ties += 1
                else:  # Disagree -> TIE (position bias detected)
                    ties += 1
            elif len(winners) == 1:
                if winners[0] == "A":
                    wins_a += 1
                elif winners[0] == "B":
                    wins_b += 1
                else:
                    ties += 1

        total = wins_a + wins_b + ties
        cond_a, cond_b = pair_name.split("_vs_")

        # Bootstrap CI for win rate
        win_rate_a = wins_a / total if total > 0 else 0
        boot_wins = bootstrap_win_rate(consolidated, NUM_BOOTSTRAP)

        # Paired permutation test
        p_value = permutation_test_win_rate(consolidated, n_permutations=NUM_BOOTSTRAP)

        analysis[pair_name] = {
            f"wins_{cond_a}": wins_a,
            f"wins_{cond_b}": wins_b,
            "ties": ties,
            "total": total,
            f"win_rate_{cond_a}": win_rate_a,
            "bootstrap_ci_95": boot_wins,
            "p_value": p_value,
            "significant": p_value < 0.05,
        }

    # 2. Latency analysis
    for condition in ["B0", "B1", "B2", "B3", "B4"]:
        latencies = [r.latency_ms for r in results if r.condition == condition]
        if latencies:
            analysis[f"latency_{condition}"] = {
                "mean_ms": np.mean(latencies),
                "median_ms": np.median(latencies),
                "p95_ms": np.percentile(latencies, 95),
                "std_ms": np.std(latencies),
            }

    # 3. Cost analysis
    for condition in ["B0", "B1", "B2", "B3", "B4"]:
        costs = [r.cost_usd for r in results if r.condition == condition]
        if costs:
            analysis[f"cost_{condition}"] = {
                "mean_usd": np.mean(costs),
                "total_usd": np.sum(costs),
                "per_1000_queries_usd": np.mean(costs) * 1000,
            }

    # 4. Per-domain breakdown
    for domain in ["knowledge_qa", "customer_support", "code_assist"]:
        domain_results = [r for r in results if r.query_id.startswith(domain[:3])]
        # ... (same analysis structure per domain)

    # 5. BERTScore computation
    try:
        from bert_score import score as bert_score_fn
        for condition in ["B0", "B1", "B2", "B3", "B4"]:
            cond_results = [r for r in results if r.condition == condition]
            # Compare against gold responses (from test cases)
            # ... bert_score computation
    except ImportError:
        print("bert-score not installed, skipping BERTScore analysis")

    # 6. Holm-Bonferroni correction
    p_values = [(pair, analysis[pair]["p_value"])
                for pair in analysis if "p_value" in analysis.get(pair, {})]
    p_values.sort(key=lambda x: x[1])
    for rank, (pair, pval) in enumerate(p_values):
        corrected_alpha = 0.05 / (len(p_values) - rank)
        analysis[pair]["holm_bonferroni_significant"] = pval < corrected_alpha
        analysis[pair]["corrected_alpha"] = corrected_alpha

    return analysis


def bootstrap_win_rate(consolidated: dict, n_boot: int) -> tuple[float, float]:
    """Bootstrap 95% CI for win rate of condition A."""
    query_ids = list(consolidated.keys())
    n = len(query_ids)
    boot_rates = []

    for _ in range(n_boot):
        sample = np.random.choice(query_ids, size=n, replace=True)
        wins_a = sum(
            1 for qid in sample
            if consolidated[qid][0] == "A" and
               (len(consolidated[qid]) < 2 or consolidated[qid][1] == "A")
        )
        boot_rates.append(wins_a / n)

    return (np.percentile(boot_rates, 2.5), np.percentile(boot_rates, 97.5))


def permutation_test_win_rate(consolidated: dict, n_permutations: int) -> float:
    """Permutation test: is the win rate significantly different from 0.5?"""
    query_ids = list(consolidated.keys())
    n = len(query_ids)

    # Observed win count for A
    observed_wins_a = sum(
        1 for qid in query_ids
        if consolidated[qid][0] == "A" and
           (len(consolidated[qid]) < 2 or consolidated[qid][1] == "A")
    )
    observed_stat = abs(observed_wins_a / n - 0.5)

    # Permutation distribution
    count_extreme = 0
    for _ in range(n_permutations):
        # Randomly flip A/B for each query
        perm_wins_a = sum(
            1 for qid in query_ids
            if np.random.random() < 0.5
        )
        perm_stat = abs(perm_wins_a / n - 0.5)
        if perm_stat >= observed_stat:
            count_extreme += 1

    return count_extreme / n_permutations


# ── Utility Functions ──────────────────────────────────────────────────────

def retrieve_topk(cache, query: str, k: int) -> list[tuple[str, str, float]]:
    """Retrieve top-K cached entries for a query.

    Returns: [(cached_query, cached_response, similarity), ...]

    NOTE: This requires extending cacheback's lookup to return top-K results
    instead of just the best match. Implementation options:
    1. Access cache._index.search(embedding, k=K) directly
    2. Add a lookup_topk() method to SemanticCache
    """
    embedding = cache._embed(query)
    cache._lazy_init()
    results = cache._index.search(embedding, k=k, threshold=0.70)

    topk = []
    for cache_id, similarity in results:
        entry = cache._store.get(cache_id)
        if entry:
            topk.append((entry.query_text, entry.response_text, similarity))

    return topk


def compute_api_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Compute API cost in USD."""
    rates = {
        "gpt-4o": (2.50e-6, 10.00e-6),
        "gpt-4o-mini": (0.15e-6, 0.60e-6),
    }
    input_rate, output_rate = rates.get(model, (0, 0))
    return input_tokens * input_rate + output_tokens * output_rate


def format_aggregation_prompt(query: str, responses: list[str]) -> str:
    """Format Self-MoA aggregation prompt."""
    parts = [f"## User Query\n{query}\n"]
    labels = ["conservative (temp=0.3)", "balanced (temp=0.7)", "creative (temp=1.0)"]
    for i, (r, label) in enumerate(zip(responses, labels)):
        parts.append(f"## Candidate {i+1} ({label})\n{r}\n")
    parts.append("## Your Aggregated Response")
    return "\n".join(parts)


def format_critique_prompt(query: str, cached_refs: list, response: str) -> str:
    """Format RPI critique prompt."""
    refs_text = "\n".join(
        f"- [{sim:.2f}] Q: {cq}\n  A: {cr[:200]}..."
        for cq, cr, sim in cached_refs
    )
    return f"""## User Query
{query}

## Cached References (ground truth)
{refs_text}

## Response Under Review
{response}

## Your Critique
List specific issues. For each, cite which cached reference contradicts
or supports the claim. End with: "VERDICT: PASS" or "VERDICT: REVISE [list of issues]"
"""


def format_refine_prompt(original: str, critique: str) -> str:
    """Format RPI refinement prompt."""
    return f"""Revise your response based on this critique. Fix ONLY the issues raised.
Do not change parts that were not criticized.

## Original Response
{original}

## Critique
{critique}

## Revised Response"""


# ── Main Entry Point ──────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="CAS Benchmark Runner")
    parser.add_argument("--phase", choices=["populate", "evaluate", "judge", "analyze", "all"],
                        required=True)
    parser.add_argument("--domain", choices=["knowledge_qa", "customer_support", "code_assist", "all"],
                        default="all")
    parser.add_argument("--n", type=int, default=200, help="Test cases per domain")
    parser.add_argument("--judge-model", default=JUDGE_MODEL)
    parser.add_argument("--k", type=int, default=K_CACHED_REFS, help="Cached refs per query")
    parser.add_argument("--output", default=str(RESULTS_DIR))
    parser.add_argument("--dry-run", action="store_true", help="Print plan without executing")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    if args.phase in ("populate", "all"):
        print("=== Phase 1: Dataset Generation & Cache Population ===")
        all_cache = []
        all_tests = []

        if args.domain in ("knowledge_qa", "all"):
            ce, tc = generate_knowledge_qa_dataset(args.n)
            all_cache.extend(ce)
            all_tests.extend(tc)

        if args.domain in ("customer_support", "all"):
            ce, tc = generate_customer_support_dataset(args.n)
            all_cache.extend(ce)
            all_tests.extend(tc)

        if args.domain in ("code_assist", "all"):
            ce, tc = generate_code_assist_dataset(args.n)
            all_cache.extend(ce)
            all_tests.extend(tc)

        # Save datasets
        with open(os.path.join(args.output, "cache_entries.jsonl"), "w") as f:
            for e in all_cache:
                f.write(json.dumps(asdict(e)) + "\n")

        with open(os.path.join(args.output, "test_cases.jsonl"), "w") as f:
            for t in all_tests:
                f.write(json.dumps(asdict(t)) + "\n")

        populate_cache(all_cache)

    if args.phase in ("evaluate", "all"):
        print("=== Phase 2: Evaluation (all conditions) ===")
        # Load datasets
        test_cases = load_jsonl(os.path.join(args.output, "test_cases.jsonl"), TestCase)
        cache_entries = load_jsonl(os.path.join(args.output, "cache_entries.jsonl"), CacheEntry)

        results = run_evaluation(test_cases, cache_entries)

        with open(os.path.join(args.output, "eval_results.jsonl"), "w") as f:
            for r in results:
                f.write(json.dumps(asdict(r)) + "\n")

    if args.phase in ("judge", "all"):
        print("=== Phase 3: LLM-as-Judge ===")
        results = load_jsonl(os.path.join(args.output, "eval_results.jsonl"), EvalResult)
        test_cases = load_jsonl(os.path.join(args.output, "test_cases.jsonl"), TestCase)

        verdicts = run_judge(results, test_cases)

        with open(os.path.join(args.output, "verdicts.jsonl"), "w") as f:
            for v in verdicts:
                f.write(json.dumps(asdict(v)) + "\n")

    if args.phase in ("analyze", "all"):
        print("=== Phase 4: Statistical Analysis ===")
        results = load_jsonl(os.path.join(args.output, "eval_results.jsonl"), EvalResult)
        verdicts = load_jsonl(os.path.join(args.output, "verdicts.jsonl"), JudgeVerdict)

        analysis = analyze_results(results, verdicts)

        with open(os.path.join(args.output, "analysis.json"), "w") as f:
            json.dump(analysis, f, indent=2, default=str)

        print_report(analysis)


def load_jsonl(path: str, cls):
    """Load JSONL file into dataclass instances."""
    items = []
    with open(path) as f:
        for line in f:
            items.append(cls(**json.loads(line)))
    return items


def print_report(analysis: dict):
    """Print human-readable summary report."""
    print("\n" + "=" * 70)
    print("CAS BENCHMARK RESULTS")
    print("=" * 70)

    for pair in [f"{a}_vs_{b}" for a, b in COMPARISON_PAIRS]:
        if pair in analysis:
            d = analysis[pair]
            cond_a, cond_b = pair.split("_vs_")
            print(f"\n--- {cond_a} vs {cond_b} ---")
            print(f"  Wins {cond_a}: {d.get(f'wins_{cond_a}', 'N/A')}")
            print(f"  Wins {cond_b}: {d.get(f'wins_{cond_b}', 'N/A')}")
            print(f"  Ties: {d.get('ties', 'N/A')}")
            print(f"  Win rate {cond_a}: {d.get(f'win_rate_{cond_a}', 'N/A'):.3f}")
            ci = d.get("bootstrap_ci_95", ("N/A", "N/A"))
            print(f"  95% CI: [{ci[0]:.3f}, {ci[1]:.3f}]")
            print(f"  p-value: {d.get('p_value', 'N/A'):.4f}")
            sig = d.get("holm_bonferroni_significant", "N/A")
            print(f"  Significant (Holm-Bonferroni): {sig}")

    print("\n--- Latency Summary ---")
    for cond in ["B0", "B1", "B2", "B3", "B4"]:
        key = f"latency_{cond}"
        if key in analysis:
            d = analysis[key]
            print(f"  {cond}: {d['mean_ms']:.0f}ms mean, {d['median_ms']:.0f}ms median, "
                  f"{d['p95_ms']:.0f}ms p95")

    print("\n--- Cost Summary (per 1000 queries) ---")
    for cond in ["B0", "B1", "B2", "B3", "B4"]:
        key = f"cost_{cond}"
        if key in analysis:
            d = analysis[key]
            print(f"  {cond}: ${d['per_1000_queries_usd']:.4f}")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
```

## 11. Expected Outcomes & Hypotheses

| Hypothesis | Expected Result | Why |
|------------|-----------------|-----|
| H1: CAS-Single > Verbatim | CAS wins 60-70% pairwise | Synthesis adapts to specific query nuances |
| H2: GPT-4 > CAS-Single | GPT-4 wins 55-65% | GPT-4 is far more capable, but gap should be manageable |
| H3: CAS-Ensemble > CAS-Single | Ensemble wins 52-58% | Self-MoA paper shows 3-7% improvement, but with larger models |
| H4: CAS-Debate ~ CAS-Ensemble | No significant difference | RPI and Self-MoA converge for small models |
| H5: CAS advantage increases as similarity decreases | Correlation r > 0.3 | Verbatim fails when query diverges; synthesis adapts |
| H6: K=5 is near-optimal | Diminishing returns after K=5 | Context pollution outweighs marginal info after K=5-7 |
| H7: CAS cost < 5% of GPT-4 | 20-50x cost reduction | Local compute vs API pricing |
| H8: CAS latency < GPT-4 | 2-5x faster for CAS-Single | Phi-4-mini generates faster than API round-trip |

## 12. Budget Estimate

| Item | Count | Unit Cost | Total |
|------|-------|-----------|-------|
| Cache population (GPT-4o) | 3,000 entries x ~500 tokens out | $0.005/entry | $15.00 |
| Gold responses (GPT-4o) | 600 queries x ~400 tokens out | $0.004/query | $2.40 |
| Dataset generation prompts | ~800 GPT-4o calls | $0.005/call | $4.00 |
| B0 evaluation (GPT-4o) | 600 queries | $0.004/query | $2.40 |
| Judge calls (GPT-4o) | 6,000 calls | $0.004/call | $24.00 |
| Judge calls (GPT-4o-mini alt) | 6,000 calls | $0.00036/call | $2.16 |
| BERTScore compute | local | $0 | $0 |
| Phi-4-mini compute (23 PCs) | ~30 min fleet time | electricity | ~$0.05 |
| **Total (GPT-4o judge)** | | | **~$48** |
| **Total (GPT-4o-mini judge)** | | | **~$26** |

## 13. Deliverables

1. **`cas_benchmark.py`** — Main runner script (this spec's Section 10)
2. **`cas_data/datasets/`** — Generated test datasets (JSONL)
3. **`cas_data/results/`** — Raw evaluation results (JSONL)
4. **`cas_data/results/analysis.json`** — Statistical analysis output
5. **`CAS_BENCHMARK_REPORT.md`** — Human-readable report with tables and conclusions
6. **Extension to cacheback:** `SemanticCache.lookup_topk(query, k)` method

## 14. Key Findings from Literature Review

### GenerativeCache (arxiv 2503.17603)
- Uses SQuAD (130K Q&A pairs) for evaluation
- Achieves 9x speedup over GPTcache
- **Critical gap:** No quality evaluation of synthesized responses. Only measures throughput/latency
- Their "generative caching" is more about combining cached fragments than LLM synthesis
- Our CAS approach is fundamentally different and more ambitious

### GenCache (Microsoft, NeurIPS 2025, arxiv 2511.17565)
- Stores programs (not responses) that generate responses from prompt parameters
- Evaluates on WebShop (12K e-commerce queries) and incident diagnosis (298 incidents)
- Metrics: cache hit rate, positive/negative hits, token savings, latency
- Uses GPT-4.1 semantic verification for quality + 5% human spot-check
- **Key insight:** Separates cache hit rate (efficiency) from positive hit rate (correctness)
- Relevant metric: cost-to-savings ratio over time

### IC-Cache (arxiv 2501.12689)
- Caches intermediate computations (KV pairs), not final responses
- 1.4-5.9x throughput improvement, 28-71% latency reduction
- Claims "without hurting response quality" but limited quality evaluation
- 70%+ of requests have semantically similar counterparts

### Mixture-of-Agents (Wang et al., ICLR 2025)
- 3 layers, 6 proposers, 1 aggregator achieves 65.1% on AlpacaEval 2.0
- **Self-MoA beats Mixed-MoA** by 6.6% on AlpacaEval (Li et al., 2025)
- Self-MoA with 7 forward passes matches 13-pass 3-layer MoA
- Implication for CAS: use same model (Phi-4-mini) for all ensemble members

### Phi-4-mini (3.8B) Capabilities
- MMLU: 67.3% (5-shot), context window: 128K tokens
- GSM8K: 88.6%, MATH: 64.0%, ARC: 83.7%
- Known limitation: prone to hallucination with limited factual storage
- **Key risk for CAS:** Phi-4-mini may hallucinate beyond cached references
- Mitigation: synthesis prompt explicitly constrains to cached content

### Statistical Methodology
- Paired bootstrap is preferred over parametric tests for LLM comparisons
- Position bias in LLM-as-judge: run each pair twice with swapped positions
- Holm-Bonferroni correction for multiple comparisons
- 600 test cases provides 80% power to detect 5pp win rate differences

## 15. Open Questions for Future Work

1. **Fine-tuning Phi-4-mini for synthesis** — Would a LoRA fine-tuned on (cache_refs, query) -> synthesized_response improve quality significantly?
2. **Dynamic K selection** — Can we predict optimal K per query based on similarity distribution?
3. **Cache quality scoring** — Should CAS score and filter cached references before synthesis?
4. **Streaming synthesis** — Can we stream Phi-4-mini output while still doing cache lookup?
5. **Cross-modal CAS** — Synthesize from mixed text/code/image cached references?
6. **Phi-4-mini-reasoning variant** — Would the reasoning-trained variant (50% AIME) improve synthesis quality on complex queries?
