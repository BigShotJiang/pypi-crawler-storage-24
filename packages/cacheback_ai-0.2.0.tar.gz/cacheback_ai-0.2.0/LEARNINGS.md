# Learnings

Patterns, gotchas, and hard-won knowledge from cacheback development.

## API & Infrastructure

### OpenRouter is the default backend
- User has `OPENROUTER_API_KEY` — use OpenRouter for all LLM calls, not direct OpenAI
- OpenRouter is OpenAI-compatible: `base_url="https://openrouter.ai/api/v1"`
- Model IDs use provider prefix: `google/gemini-2.5-flash`, `openai/gpt-4o`

### BGML Fleet API endpoints
- API proxy: `https://lab.bgml.ai` (nginx -> port 8000)
- Downloads/fix: `https://app.bgml.ai` (different nginx config, NOT the API)
- Direct: `http://204.168.129.200:8000` (no HTTPS)
- Use `force_device_id` to route to specific fleet device
- Use `skip_cache: true` to bypass orchestrator's semantic cache

### Fleet device throughput
- POS-B2 (dev-e0d55ee6dd4c): 4.4 tok/s, Phi-4-mini Q4, 8GB RAM
- Short prompts (~100 tokens): ~14s response time
- Long prompts (~3000+ tokens): times out even at 300s
- Synthesis prompts with 5 full cached answers (~12K chars) exceed timeout
- Even truncated prompts (3.5K chars, 500 char/answer) still time out
- **Root cause:** Orchestrator retries flood the device (attempt #49-50 visible in logs)
- **Workaround:** Use cloud model (Gemini Flash Lite) for synthesis during benchmarking
- Fleet synthesis needs investigation: check retry backoff, request queuing, concurrent dispatch

## Benchmark Design

### Variant generation prefix ordering
- Must try longer prefixes FIRST when stripping question prefixes
- "How do I " before "How do " — otherwise "How do I reset" becomes "I reset"
- Already fixed in `generate_variants()` function

### Dataset generation costs (OpenRouter, March 2026)
- Gemini 2.5 Flash: ~$0.15/1M input, ~$0.60/1M output -> ~$0.50 for 600 calls
- Gemini 3.1 Flash Lite: ~$0.25/1M input, ~$1.50/1M output -> ~$0.37 for 600 calls
- GPT-4o via OR: ~$2.50 for 600 calls
- Claude Sonnet: ~$3.70 for 600 calls

### CAS quality gates (from CEO plan, adjusted)
- Mean judge ratio >= 0.80 (synthesis vs reference) -- PRIMARY metric
- Domain thresholds: customer_support >= 0.85, programming >= 0.80, science >= 0.75, general >= 0.75, creative >= 0.60
- BERTScore F1 >= 0.70 (only checked when installed)
- ROUGE-L: hard floor 0.10, soft warning 0.30
  - **Key learning:** ROUGE-L is naturally low for synthesis because CAS paraphrases from multiple cached answers, not copies them. A ROUGE-L of ~0.19 is normal and expected.
- Latency < 2000ms
- Any non-creative domain < 0.50 = total failure

### CAS benchmark FINAL results (100 questions, 2026-03-23)
- **Mean judge ratio: 0.892** -- GO decision confirmed
- All 5 domains pass individual thresholds (best: general_knowledge 0.94, worst: programming 0.86)
- customer_support: 0.89 (was 0.80 borderline with 2 samples -- 20 samples resolved it)
- creative: 0.88 (surprisingly strong -- synthesis compiles well from subjective responses)
- general_knowledge: 0.94 (factual Q&A with many cached variants = CAS sweet spot)
- Cloud synthesis latency ~2.7s (local would be ~300ms)
- ROUGE-L 0.167 (expected -- synthesis paraphrases, not copies)
- BERTScore: first computation was 0.87 (promising), but segfaults on Windows after first call
- Quick benchmark (10q) vs full (100q): 0.850 vs 0.892 -- larger sample increased accuracy

## Audio Embedder Patterns

### Shared audio utilities (`_audio.py`)
- Pure numpy mel spectrogram — no librosa/torchaudio dependency
- `load_audio()` type-checks BEFORE importing soundfile — ensures TypeError for invalid types even without soundfile installed
- soundfile imported lazily inside `load_audio()` — keeps top-level imports clean

### CLAP vs Whisper mel spectrogram differences
- CLAP: `log(mel)` (natural log), 48kHz, 64 mel bins, 1024 FFT, 480 hop, 10s duration
- Whisper: `log10(mel)`, clamp to max-8, normalize to [-1,1], 16kHz, 80 mel bins, 400 FFT, 160 hop, 30s
- These are NOT interchangeable — each model expects its specific preprocessing

### Mel filterbank edge case
- With high mel count + low FFT resolution (80 mels, 201 bins), some low-frequency filters are empty
- This is physically correct (mel spacing < FFT bin spacing) — not a bug
- Tests should account for this: ≥70/80 active filters is normal for Whisper config

### Whisper ONNX decoder inputs
- Merged decoder model has variable inputs including KV-cache tensors
- First pass: provide zero-sized tensors for `past_key_values.*` and `False` for `use_cache_branch`
- Dynamically inspect model inputs at runtime — don't hardcode input names

## Code Patterns

### Windows/Python gotchas
- Unicode chars (arrows, etc.) cause `UnicodeEncodeError` on Windows cp1252
- Use ASCII alternatives: `->` instead of `->`, `>=` instead of `>=`
- f-strings with backslashes -> unicode escape errors, use `chr(92)`
- BERTScore (roberta-large) segfaults on second call on Windows -- use --no-bert flag
- C: drive full -> redirect HF cache: `HF_HOME=F:/hf_cache`
- OPENROUTER_API_KEY not in env by default -- source from .env.local
