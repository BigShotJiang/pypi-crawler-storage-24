# cacheback — Universal Semantic Cache Engine

Apache 2.0 SDK. Engine powering euor.ai (B2B) and iors.ai (B2C). NOT a product — see `PRODUCT_DECISIONS_2026-03-23.md`.

## Workflow

Każde zadanie:
1. **RESEARCH** — deep research tematu (Explore, WebSearch, context7, czytaj kod). Nie pytaj — szukaj sam
2. **PLAN** — przedstaw plan realizacji (kroki, pliki, weryfikacja). Jedno pytanie: "Akceptujesz plan?"
3. **EXECUTE** — po akceptacji: `/ralph-loop` → realizuj do końca. ZERO pytań. Nie przerywaj. Nie pytaj o zgodę na kolejne kroki. Rób aż DONE

**NIE PYTAJ O NIC** poza: brak hasła/tokena, wydawanie pieniędzy, usuwanie danych.

## Commands

```bash
pip install -e ".[dev]"           # dev install
pip install -e ".[voice]"         # voice embedders (soundfile)
pip install -e ".[proxy]"         # proxy mode (fastapi, uvicorn)
pytest tests/                     # run all tests (164 passing)
pytest tests/ --basetemp=F:/tmp   # Windows (C: drive full)
cacheback stats                   # CLI: cache stats
cacheback-proxy                   # start proxy server
```

## Architecture

```
cacheback/
├── cache.py          # SemanticCache kernel (lookup, populate, stats, lookup_for_synthesis)
├── synthesis.py      # CAS engine (SynthesisEngine, three-tier: verbatim/synthesis/upstream)
├── openai.py         # CachedOpenAI + AsyncCachedOpenAI (drop-in wrapper)
├── anthropic.py      # CachedAnthropic + AsyncCachedAnthropic
├── _async_cache.py   # AsyncSemanticCache (executor-wrapped)
├── _streaming.py     # StreamBuffer, replay_cached_sync/async
├── exceptions.py     # CachebackBlocked
├── cli.py            # `cacheback stats/clear/lookup` CLI
├── proxy/            # FastAPI proxy server (OpenAI-compatible)
│   ├── app.py        # Routes, SSE streaming, cache headers
│   ├── config.py     # CACHEBACK_* env vars
│   └── models.py     # Request/response Pydantic models
├── embedders/
│   ├── __init__.py   # BaseEmbedder ABC, EmbedderRegistry, auto-registration
│   ├── minilm.py     # Text: MiniLM-L6-v2, 384-dim, ONNX (~90MB)
│   ├── clip.py       # Image: CLIP ViT-B/32, 512-dim, ONNX (~150MB)
│   ├── clap.py       # Audio: CLAP HTSAT, 512-dim, ONNX (~300MB)
│   ├── whisper.py    # Voice: Whisper tiny → MiniLM, 384-dim, ONNX (~165MB)
│   └── _audio.py     # Shared: mel filterbank, STFT, resample, load_audio (pure numpy)
├── index.py          # VectorIndex (hnswlib HNSW, dim-aware)
├── store.py          # CacheStore (SQLite WAL, schema migrations)
└── negative.py       # NegativeCacheAPI
```

## Key Patterns

- **Embedder registry**: `get_embedder("minilm")` returns singleton. New embedders: subclass `BaseEmbedder`, register in `__init__.py`
- **Lazy model loading**: ONNX models download from HuggingFace on first use, thread-safe (double-check lock)
- **soundfile is optional**: `_audio.py:load_audio()` type-checks BEFORE importing soundfile — TypeError raised even without it installed
- **Audio preprocessing differs per model**: CLAP (log, 48kHz, 64 mels) ≠ Whisper (log10, 16kHz, 80 mels). Not interchangeable
- **Whisper decoder**: merged ONNX model needs zero-sized KV-cache tensors on first pass. Inspect model inputs dynamically
- **CAS defaults off**: `synthesis_mode="off"` — zero behavior change for existing users
- **Response flags**: `response.cacheback_hit` (verbatim) and `response.cacheback_synthesized` (CAS) — both False = upstream miss

## Optional Dependencies

| Extra | What | When |
|-------|------|------|
| `openai` | openai SDK | CachedOpenAI wrapper |
| `anthropic` | anthropic SDK | CachedAnthropic wrapper |
| `image` | Pillow | CLIP preprocessing |
| `voice` | soundfile | CLAP/Whisper audio I/O |
| `proxy` | fastapi, uvicorn, httpx | Proxy server |
| `dev` | pytest, pytest-asyncio, httpx | Testing |

## Testing

- `asyncio_mode = "auto"` — no `@pytest.mark.asyncio` needed
- `pytest tests/test_embedders.py -k "CLAP"` — run specific class
- `conftest.py` sets dummy env vars — tests never hit real APIs

## CAS Benchmark (PASSED)

Mean judge ratio: 0.892 (threshold 0.80). All 5 domains pass. Script: `scripts/benchmark_cas.py`. Results: `benchmarks/`.

## Gotchas

- `HF_HOME=F:/hf_cache` on Windows (C: drive full)
- BERTScore segfaults on Windows after first call — use `--no-bert`
- Mel filterbank: 80 mels + 201 FFT bins → some low-freq filters empty (normal, not a bug)
- OPENROUTER_API_KEY not in env by default — source from `.env.local`
- `pip install cacheback-ai[voice]` required for CLAP/Whisper (soundfile dependency)
