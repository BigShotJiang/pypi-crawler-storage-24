/// mfa_attention.cpp — MFAttention Primitive implementation.
///
/// eval_gpu() routing:
///   STEEL path (f16/bf16):  generate_steel_forward_source() → ShaderCache
///   ccv path (f32 / legacy): generate_attention_source() → ShaderCache
///
/// The device architecture generation is read via mlx::core::metal and
/// compared against gen >= 15 (M3+) to select block parameters.
///
/// Buffer layout (all kernels):
///   buffer(0) = Q  [B × H × N × D], row-major, contiguous
///   buffer(1) = K  [B × H × S × D], row-major, contiguous
///   buffer(2) = V  [B × H × S × D], row-major, contiguous
///   buffer(3) = O  [B × H × N × D], row-major, output
///   buffer(4) = L  [B × H × N],     logsumexp (STEEL only, used for bwd)
///   buffer(5) = params  (struct MFAttention::Params packed into bytes)

#include "mfa_attention.hpp"
#include "mfa_shader_gen.hpp"
#include "mfa_steel_fwd.hpp"
#include "mfa_steel_fwd_v2.hpp"
#include "mfa_steel_fwd_v3.hpp"
#include "mfa_steel_fwd_v4.hpp"
#include "mfa_steel_fwd_v5.hpp"
#include "mfa_steel_bwd.hpp"
#include "mfa_sage_fwd.hpp"
#include "shader_cache.hpp"

#include <mlx/utils.h>
#include <mlx/allocator.h>
#include <mlx/backend/metal/device.h>
#include <Metal/Metal.hpp>

#include <cassert>
#include <cmath>
#include <cstdlib>
#include <stdexcept>

namespace mlx_mfa {

namespace {

inline bool is_v2_small_d_family(int head_dim) {
  return head_dim == 64 || head_dim == 128;
}

inline bool is_v2_d256_family(int head_dim) {
  return head_dim == 256;
}

inline bool is_v2_d512_family(int head_dim) {
  return head_dim == 512;
}

inline bool is_v2_dsplit_family(int head_dim) {
  // Large-D families are explicit:
  //   - D=256: narrow benchmark-backed MFA promotion in Python policy.
  //   - D=512: conservative SDPA-default in Python policy.
  // Both share the same C++ D-split kernel family; auto-route policy lives in
  // mlx_mfa/dispatch_policy.py.
  return is_v2_d256_family(head_dim) || is_v2_d512_family(head_dim);
}

}  // namespace

// =========================================================================
// Constructor
// =========================================================================

MFAttention::MFAttention(mlx::core::Stream stream, Params params)
    : mlx::core::Primitive(stream), params_(params) {}

// =========================================================================
// Forward pass (eval_gpu)
// =========================================================================

void MFAttention::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {
  // 3 = dense (Q, K, V)
  // 4 = sparse (Q, K, V, block_mask) or rope (Q, K, V, cos, sin) — 5 for rope
  // 5 = rope (Q, K, V, rotary_cos, rotary_sin)
  assert(inputs.size() >= 3 && inputs.size() <= 5);

  const auto& q = inputs[0]; // [B, H, N, D]
  const auto& k = inputs[1]; // [B, H, S, D]
  const auto& v = inputs[2]; // [B, H, S, D]
  // inputs[3] = block_mask [NQ_tiles, NK_tiles] uint8, only when has_block_mask

  int B = q.shape(0);
  int H = q.shape(1);
  int N = q.shape(2);
  int D = q.shape(3);
  int S = k.shape(2);
  int Hk = k.shape(1); // KV heads (for GQA)

  auto& out       = outputs[0]; // [B, H, N, D]
  auto& logsumexp = outputs[1]; // [B, H, N], float32

  out.set_data(mlx::core::allocator::malloc(out.nbytes()));
  logsumexp.set_data(mlx::core::allocator::malloc(logsumexp.nbytes()));

  // ── Device & dtype ──────────────────────────────────────────────────────
  auto& d = mlx::core::metal::device(stream().device);

  uint8_t dtype_code;
  if (q.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (q.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else                                        dtype_code = 2;

  // ── Route to ccv kernel when Steel register pressure is too high.
  //  • f32 (dtype==2): simdgroup_matrix spills exceed 32 KB threadgroup limit.
  //  Note: D=256 (f16/bf16) stays on STEEL despite register pressure because ccv
  //  3D-blocking + async_copy fallback is slower than STEEL register spill on macOS 26.
  if (dtype_code == 2) {
    bool is_m3_plus = (d.get_architecture_gen() >= 15);
    const bool low_prec_inter  = false;
    const bool low_prec_inputs = false;
    auto ccv_cfg = resolve_block_config(D, is_m3_plus, low_prec_inter, low_prec_inputs);
    unsigned short bq = ccv_cfg.block_q, bk = ccv_cfg.block_k, bd = ccv_cfg.block_d;
    unsigned short nw = bq / 8;

    MFAParams fwd_p{};
    fwd_p.R                = static_cast<uint32_t>(N);
    fwd_p.C                = static_cast<uint32_t>(S);
    fwd_p.Hq               = static_cast<uint32_t>(H);
    fwd_p.H_Hk_ratio       = static_cast<uint32_t>(H / Hk);
    fwd_p.dot_product_scale = params_.scale * static_cast<float>(M_LOG2E);
    fwd_p.causal           = params_.causal ? 1u : 0u;
    fwd_p.Q_batch_stride   = static_cast<uint32_t>(H  * N * D);
    fwd_p.K_batch_stride   = static_cast<uint32_t>(Hk * S * D);
    fwd_p.V_batch_stride   = static_cast<uint32_t>(Hk * S * D);
    fwd_p.O_batch_stride   = static_cast<uint32_t>(H  * N * D);

    using KK = ShaderCache::KernelKey;
    KK ccv_key{ KK::KernelType::AttentionForward,
                D, (int)bq, (int)bk, (int)bd, (int)nw,
                params_.causal, /*sparse=*/false, is_m3_plus,
                /*has_rope=*/false, /*rope_interleaved=*/false,
                /*has_softcap=*/false, /*has_alibi=*/false,
                /*has_window=*/false, dtype_code };
    void* raw = ShaderCache::get().get_or_compile(ccv_key, d.mtl_device());
    auto* pl  = reinterpret_cast<MTL::ComputePipelineState*>(raw);

    auto& enc = d.get_command_encoder(stream().index);
    enc.set_compute_pipeline_state(pl);
    enc.set_input_array(q,          0);
    enc.set_input_array(k,          1);
    enc.set_input_array(v,          2);
    enc.set_output_array(out,       3);
    enc.set_output_array(logsumexp, 4);
    enc.set_bytes(fwd_p,           10);

    uint32_t tiles = ((uint32_t)N + bq - 1u) / bq * (uint32_t)H * (uint32_t)B;
    enc.dispatch_threadgroups(
        MTL::Size::Make(tiles, 1, 1),
        MTL::Size::Make(nw * 32u, 1, 1));
    return;
  }

  // ── Architecture gen (STEEL f16/bf16 path) ──────────────────────────────
  // MFA_FORCE_GEN overrides hardware detection for correctness testing:
  //   MFA_FORCE_GEN=15  → treat as M3 (gen=15) even on M1 (gen=13)
  //   MFA_FORCE_GEN=13  → treat as M1 even on M3 hardware
  int arch_gen_steel = static_cast<int>(d.get_architecture_gen());
  const char* force_gen_env = std::getenv("MFA_FORCE_GEN");
  if (force_gen_env) arch_gen_steel = std::atoi(force_gen_env);
  bool is_m3_plus_steel = (arch_gen_steel >= 15);
  // M5+ (gen >= 17, A19/Apple Silicon 5th gen) exposes Metal 4 tensor API
  // (MTLTensor, cooperative tensor ops). Stub only — no kernel implemented yet.
  // When M5+ hardware is available, dispatch Metal4TensorOps kernel here.
  bool is_m5_plus = (arch_gen_steel >= 17);
  (void)is_m5_plus;  // unused until Metal4TensorOps kernel is implemented

  // ── GPU core count (for split-K occupancy heuristics) ────────────────────
  // estimate_gpu_cores() parses MTLDevice::name() for the actual chip variant
  // (M1 Max=32, M1 base=8, etc.) rather than using arch_gen alone (which maps
  // all M1 variants to gen=13). Falls back to gen-based estimate if unavailable.
  auto* mtl_dev_ptr = d.mtl_device();
  const std::string mtl_dev_name = mtl_dev_ptr
      ? std::string(mtl_dev_ptr->name()->utf8String()) : "";
  const int gpu_cores = estimate_gpu_cores(mtl_dev_name, arch_gen_steel);

  // ── Flash Decoding (Split-KV) path ──────────────────────────────────────
  //
  // At decode time (N_q ≤ 4) the standard grid (NQ, H, B) = (1, H, B) leaves
  // most SMs idle.  Flash Decoding splits the KV sequence into num_splits
  // chunks dispatched in parallel, then a tiny reduce kernel combines them.
  //
  // Activation: N ≤ 4 AND S ≥ 256 AND f16/bf16 (dtype_code != 2)
  //             AND no block mask (sparse path keeps its own dispatch)
  // CP2: D=64/128 use V2 tile sizes (larger BK) to reduce K-tile iterations per split.
  //      D=256/512 keep V1 tiles (V2 BQ=16/WM=2 for D=256 halves occupancy in V1 kernel).
  int BK_fd;
  if (D <= 128) {
    auto cfgv2 = select_steel_v2_block_config(D, is_m3_plus_steel);
    BK_fd = cfgv2.BK;
  } else {
    auto cfgv1 = select_steel_block_config(D, /*is_low_prec=*/true, is_m3_plus_steel);
    BK_fd = cfgv1.BK;
  }
  const bool use_flash_decode = (N <= 4 && S >= 256 && dtype_code != 2
                                 && !params_.has_block_mask);
  if (use_flash_decode) {
    int num_splits = compute_num_splits(S, BK_fd);
    // Use same config as shader generator (consistent BQ/BK/WM).
    int BQ_s, BK_s, WM_s, WN_s;
    if (D <= 128) {
      auto cfgv2 = select_steel_v2_block_config(D, is_m3_plus_steel);
      BQ_s = cfgv2.BQ; BK_s = cfgv2.BK; WM_s = cfgv2.WM; WN_s = cfgv2.WN;
    } else {
      auto cfgv1 = select_steel_block_config(D, /*is_low_prec=*/true, is_m3_plus_steel);
      BQ_s = cfgv1.BQ; BK_s = cfgv1.BK; WM_s = cfgv1.WM; WN_s = cfgv1.WN;
    }
    int TGP_s = WM_s * WN_s * 32;

    // ── Allocate scratch buffers pO and pL ─────────────────────────────────
    size_t pO_size = (size_t)num_splits * B * H * N * D * (dtype_code == 2 ? 4 : 2);
    size_t pL_size = (size_t)num_splits * B * H * N * sizeof(float);
    auto pO_buf = mlx::core::allocator::malloc(pO_size);
    auto pL_buf = mlx::core::allocator::malloc(pL_size);

    // ── Build FlashDecodePartialParams ─────────────────────────────────────
    int NQ_s = (N + BQ_s - 1) / BQ_s;
    int NK_total = (S + BK_s - 1) / BK_s;
    int NK_per_split = (NK_total + num_splits - 1) / num_splits;

    FlashDecodePartialParams pp{};
    pp.B = B; pp.H = H; pp.D = D;
    pp.qL = N; pp.kL = S;
    pp.gqa_factor = H / Hk;
    pp.scale = params_.scale;
    pp.NQ = NQ_s;
    pp.NQ_aligned = (N % BQ_s == 0) ? NQ_s : NQ_s - 1;
    pp.qL_rem     = (N % BQ_s == 0) ? BQ_s : (N % BQ_s);
    pp.qL_off     = (params_.causal && N < S) ? (S - N) : 0;
    pp.NK_total    = NK_total;
    pp.NK_aligned  = (S % BK_s == 0) ? NK_total : NK_total - 1;
    pp.kL_rem      = (S % BK_s == 0) ? BK_s : (S % BK_s);
    pp.num_splits  = num_splits;
    pp.NK_per_split = NK_per_split;
    // Input strides
    pp.Q_strides[0] = (int64_t)H  * N * D;
    pp.Q_strides[1] = (int64_t)N  * D;
    pp.Q_strides[2] = (int64_t)D;
    pp.K_strides[0] = (int64_t)Hk * S * D;
    pp.K_strides[1] = (int64_t)S  * D;
    pp.K_strides[2] = (int64_t)D;
    pp.V_strides[0] = (int64_t)Hk * S * D;
    pp.V_strides[1] = (int64_t)S  * D;
    pp.V_strides[2] = (int64_t)D;
    // pO strides (split outermost): [num_splits, B, H, qL, D]
    int64_t pO_head_stride  = (int64_t)N * D;
    int64_t pO_batch_stride = (int64_t)H * N * D;
    pp.pO_split_stride = (int64_t)B * H * N * D;
    pp.pO_batch_stride = pO_batch_stride;
    pp.pO_head_stride  = pO_head_stride;
    // pL strides: [num_splits, B, H, qL]
    pp.pL_split_stride = (int64_t)B * H * N;
    pp.pL_batch_stride = (int64_t)H * N;
    pp.pL_head_stride  = (int64_t)N;

    // Optional features
    pp.softcap       = params_.softcap;    // 0.0 when disabled
    pp.window_left   = params_.window_left;  // -1 when disabled
    pp.window_right  = params_.window_right; // -1 when disabled

    // ── Build FlashDecodeReduceParams ──────────────────────────────────────
    int reduce_tgp = std::min(D, 128);
    FlashDecodeReduceParams rp{};
    rp.B = B; rp.H = H; rp.D = D;
    rp.qL = N;
    rp.num_splits = num_splits;
    rp.pO_split_stride = pp.pO_split_stride;
    rp.pO_batch_stride = pp.pO_batch_stride;
    rp.pO_head_stride  = pp.pO_head_stride;
    rp.pL_split_stride = pp.pL_split_stride;
    rp.pL_batch_stride = pp.pL_batch_stride;
    rp.pL_head_stride  = pp.pL_head_stride;
    rp.O_batch_stride  = (int64_t)H * N * D;
    rp.O_head_stride   = (int64_t)N * D;
    rp.L_batch_stride  = (int64_t)H * N;
    rp.L_head_stride   = (int64_t)N;
    rp.reduce_tgp_size = reduce_tgp;

    // ── Compile Phase 1 and Phase 2 pipelines ─────────────────────────────
    using KK = ShaderCache::KernelKey;
    KK key_p1{
      KK::KernelType::FlashDecodePartial,
      D, BQ_s, BK_s, D, WM_s,
      params_.causal, /*sparse=*/false, is_m3_plus_steel,
      /*has_rope=*/false, /*rope_interleaved=*/true,
      params_.softcap > 0.0f,   // softcap variant
      params_.has_alibi,        // ALiBi position biases
      params_.window_left >= 0 || params_.window_right >= 0, // sliding window variant
      dtype_code
    };
    KK key_p2{
      KK::KernelType::FlashDecodeReduce,
      D, 0, 0, 0, 0,
      false, false, false, /*has_rope=*/false, /*rope_interleaved=*/true,
      /*has_softcap=*/false, /*has_alibi=*/false, /*has_window=*/false,
      dtype_code
    };
    auto* pl_p1 = reinterpret_cast<MTL::ComputePipelineState*>(
        ShaderCache::get().get_or_compile(key_p1, d.mtl_device()));
    auto* pl_p2 = reinterpret_cast<MTL::ComputePipelineState*>(
        ShaderCache::get().get_or_compile(key_p2, d.mtl_device()));

    auto& enc = d.get_command_encoder(stream().index);

    // ── Phase 1 dispatch ──────────────────────────────────────────────────
    enc.set_compute_pipeline_state(pl_p1);
    enc.set_input_array(q, 0);
    enc.set_input_array(k, 1);
    enc.set_input_array(v, 2);
    enc.set_buffer(reinterpret_cast<MTL::Buffer*>(pO_buf.ptr()), 3, 0);
    enc.set_buffer(reinterpret_cast<MTL::Buffer*>(pL_buf.ptr()), 4, 0);
    enc.set_bytes(pp, 5);
    if (params_.has_alibi) {
      // Flash Decode partial has no rope/block_mask: alibi_slopes is inputs[3]
      enc.set_input_array(inputs[3], 6);
    }
    enc.dispatch_threadgroups(
        MTL::Size::Make((size_t)(NQ_s * num_splits), (size_t)H, (size_t)B),
        MTL::Size::Make((size_t)TGP_s, 1, 1));

    // ── Phase 2 dispatch ──────────────────────────────────────────────────
    // Use barrier() (unconditional) — maybeInsertBarrier() is a no-op for
    // raw MTL::Buffer* bindings since needs_barrier_ is only set by
    // set_output_array(); Phase 1 writes pO/pL as set_buffer() buffers.
    enc.barrier();
    enc.set_compute_pipeline_state(pl_p2);
    enc.set_buffer(reinterpret_cast<MTL::Buffer*>(pO_buf.ptr()), 0, 0);
    enc.set_buffer(reinterpret_cast<MTL::Buffer*>(pL_buf.ptr()), 1, 0);
    enc.set_output_array(out,       2);
    enc.set_output_array(logsumexp, 3);
    enc.set_bytes(rp, 4);
    enc.dispatch_threadgroups(
        MTL::Size::Make((size_t)N, (size_t)H, (size_t)B),
        MTL::Size::Make((size_t)reduce_tgp, 1, 1));

    // Release scratch buffers (Metal retains them until command buffer completes)
    mlx::core::allocator::free(pO_buf);
    mlx::core::allocator::free(pL_buf);
    return;
  }

  // ── STEEL V2 split-K dispatch (Phase 3) ─────────────────────────────────
  // For under-occupied grids (total_tgs < 0.8 * gpu_cores) that are V2-eligible
  // but NOT handled by flash decode (N > 4), use V2 split-K to fill the GPU.
  // Phase 1: SteelV2SplitKPartial  (grid: NQ * num_splits, H, B)
  // Phase 2: FlashDecodeReduce     (reused, grid: N, H, B)
  // Set MFA_DISABLE_V2=1 to force V1 path (for benchmarking/debugging only).
  if (!std::getenv("MFA_DISABLE_V2")) {
    // MFA_FORCE_SPLITK override:
    //   1 -> force split-K attempt (bypass occupancy short-circuit)
    //   0 -> disable split-K entirely
    // unset/other -> normal heuristic + optional calibrated thresholds
    int force_splitk = -1;
    if (const char* fs_env = std::getenv("MFA_FORCE_SPLITK")) {
      if (fs_env[0] == '0' && fs_env[1] == '\0') force_splitk = 0;
      if (fs_env[0] == '1' && fs_env[1] == '\0') force_splitk = 1;
    }
    const bool has_window = (params_.window_left >= 0 || params_.window_right >= 0);
    const auto splitk_calibrated_max_n = [&]() -> int {
      // Key format (set by dispatch_policy._load_calibrated_kernel_config):
      // MFA_SPLITK_MAX_N_D{D}_C{0|1}_A{0|1}_W{0|1}
      const std::string env_key =
          "MFA_SPLITK_MAX_N_D" + std::to_string(D) +
          "_C" + std::to_string(params_.causal ? 1 : 0) +
          "_A" + std::to_string(params_.has_alibi ? 1 : 0) +
          "_W" + std::to_string(has_window ? 1 : 0);
      const char* v = std::getenv(env_key.c_str());
      if (!v || v[0] == '\0') return -1;
      return std::atoi(v);
    };
    const int calibrated_max_n = splitk_calibrated_max_n();

    const bool v2sk_eligible =
        (dtype_code != 2) &&
        is_v2_small_d_family(D) &&
        // Sparse remains excluded from V2 split-K (block-mask uses V1 BK indexing).
        // RoPE/ALiBi/window are supported in V2 split-K (Phase 3 composability).
        !params_.has_block_mask;

    const bool splitk_disabled_by_override = (force_splitk == 0);
    const bool splitk_disabled_by_calibration =
        (force_splitk < 0 && calibrated_max_n >= 0 && N > calibrated_max_n);

    if (v2sk_eligible && !splitk_disabled_by_override && !splitk_disabled_by_calibration) {
      auto cfg2 = select_steel_v2_block_config(D, is_m3_plus_steel);
      const int BQ2  = cfg2.BQ;
      const int BK2  = cfg2.BK;
      const int WM2  = cfg2.WM;
      const int TGP2 = WM2 * cfg2.WN * 32;
      const int NQ2  = (N + BQ2 - 1) / BQ2;
      const int total_tgs = NQ2 * H * B;
      const int num_splits = compute_v2_num_splits(
          total_tgs, S, BK2, gpu_cores, force_splitk == 1);

      if (num_splits >= 2) {
        const int NK2_total = (S + BK2 - 1) / BK2;
        const int NK2_per_split = (NK2_total + num_splits - 1) / num_splits;
        const int NQ2_aln = (N % BQ2 == 0) ? NQ2 : NQ2 - 1;
        const int NK2_aln = (S % BK2 == 0) ? NK2_total : NK2_total - 1;

        // ── Scratch buffers pO[num_splits, B, H, N, D] and pL[num_splits, B, H, N] ─
        size_t pO_size = (size_t)num_splits * B * H * N * D * 2;  // f16/bf16 = 2 bytes
        size_t pL_size = (size_t)num_splits * B * H * N * sizeof(float);
        auto pO_buf = mlx::core::allocator::malloc(pO_size);
        auto pL_buf = mlx::core::allocator::malloc(pL_size);

        // ── Build FlashDecodePartialParams for Phase 1 ─────────────────────
        FlashDecodePartialParams sk_pp{};
        sk_pp.B = B; sk_pp.H = H; sk_pp.D = D;
        sk_pp.qL = N; sk_pp.kL = S;
        sk_pp.gqa_factor  = H / Hk;
        sk_pp.scale       = params_.scale;
        sk_pp.NQ          = NQ2;
        sk_pp.NQ_aligned  = NQ2_aln;
        sk_pp.qL_rem      = (N % BQ2 == 0) ? BQ2 : (N % BQ2);
        sk_pp.qL_off      = (params_.causal && N < S) ? (S - N) : 0;
        sk_pp.NK_total    = NK2_total;
        sk_pp.NK_aligned  = NK2_aln;
        sk_pp.kL_rem      = (S % BK2 == 0) ? BK2 : (S % BK2);
        sk_pp.num_splits  = num_splits;
        sk_pp.NK_per_split = NK2_per_split;
        sk_pp.Q_strides[0] = (int64_t)H  * N * D;
        sk_pp.Q_strides[1] = (int64_t)N  * D;
        sk_pp.Q_strides[2] = (int64_t)D;
        sk_pp.K_strides[0] = (int64_t)Hk * S * D;
        sk_pp.K_strides[1] = (int64_t)S  * D;
        sk_pp.K_strides[2] = (int64_t)D;
        sk_pp.V_strides[0] = (int64_t)Hk * S * D;
        sk_pp.V_strides[1] = (int64_t)S  * D;
        sk_pp.V_strides[2] = (int64_t)D;
        sk_pp.pO_split_stride = (int64_t)B * H * N * D;
        sk_pp.pO_batch_stride = (int64_t)H * N * D;
        sk_pp.pO_head_stride  = (int64_t)N * D;
        sk_pp.pL_split_stride = (int64_t)B * H * N;
        sk_pp.pL_batch_stride = (int64_t)H * N;
        sk_pp.pL_head_stride  = (int64_t)N;
        sk_pp.softcap     = params_.softcap;
        sk_pp.window_left = params_.window_left;
        sk_pp.window_right = params_.window_right;
        sk_pp.rope_q_base    = params_.cache_seqlens;
        sk_pp.rope_cos_stride = D / 2;

        // ── Build FlashDecodeReduceParams for Phase 2 ─────────────────────
        int reduce_tgp = std::min(D, 128);
        FlashDecodeReduceParams sk_rp{};
        sk_rp.B = B; sk_rp.H = H; sk_rp.D = D;
        sk_rp.qL = N;
        sk_rp.num_splits      = num_splits;
        sk_rp.pO_split_stride = sk_pp.pO_split_stride;
        sk_rp.pO_batch_stride = sk_pp.pO_batch_stride;
        sk_rp.pO_head_stride  = sk_pp.pO_head_stride;
        sk_rp.pL_split_stride = sk_pp.pL_split_stride;
        sk_rp.pL_batch_stride = sk_pp.pL_batch_stride;
        sk_rp.pL_head_stride  = sk_pp.pL_head_stride;
        sk_rp.O_batch_stride  = (int64_t)H * N * D;
        sk_rp.O_head_stride   = (int64_t)N * D;
        sk_rp.L_batch_stride  = (int64_t)H * N;
        sk_rp.L_head_stride   = (int64_t)N;
        sk_rp.reduce_tgp_size = reduce_tgp;

        // ── Compile Phase 1 (V2 split-K partial) ──────────────────────────
        using KK2 = ShaderCache::KernelKey;
        KK2 key_sk{
          KK2::KernelType::SteelV2SplitKPartial,
          D, BQ2, BK2, D, WM2,
          params_.causal, /*sparse=*/false, is_m3_plus_steel,
          params_.has_rope, params_.rope_interleaved,
          params_.softcap > 0.0f,   // has_softcap
          params_.has_alibi,
          params_.window_left >= 0 || params_.window_right >= 0,  // has_window
          dtype_code, H / Hk
        };
        // Phase 2 reuses FlashDecodeReduce (key identical to flash_decode reduce).
        KK2 key_sk_reduce{
          KK2::KernelType::FlashDecodeReduce,
          D, 0, 0, 0, 0,
          false, false, false, false, true,
          false, false, false,
          dtype_code
        };

        auto* pl_sk1 = reinterpret_cast<MTL::ComputePipelineState*>(
            ShaderCache::get().get_or_compile(key_sk, d.mtl_device()));
        auto* pl_sk2 = reinterpret_cast<MTL::ComputePipelineState*>(
            ShaderCache::get().get_or_compile(key_sk_reduce, d.mtl_device()));

        auto& enc_sk = d.get_command_encoder(stream().index);

        // ── Phase 1: V2 split-K partial ────────────────────────────────────
        enc_sk.set_compute_pipeline_state(pl_sk1);
        enc_sk.set_input_array(q, 0);
        enc_sk.set_input_array(k, 1);
        enc_sk.set_input_array(v, 2);
        enc_sk.set_buffer(reinterpret_cast<MTL::Buffer*>(pO_buf.ptr()), 3, 0);
        enc_sk.set_buffer(reinterpret_cast<MTL::Buffer*>(pL_buf.ptr()), 4, 0);
        enc_sk.set_bytes(sk_pp, 5);
        if (params_.has_rope) {
          // inputs[3]=rotary_cos, inputs[4]=rotary_sin (no block_mask in split-K path)
          enc_sk.set_input_array(inputs[3], 6);
          enc_sk.set_input_array(inputs[4], 7);
        }
        if (params_.has_alibi) {
          // Dense split-K input order: [Q, K, V, alibi] or [Q, K, V, cos, sin, alibi]
          const int alibi_idx = 3 + (params_.has_rope ? 2 : 0);
          enc_sk.set_input_array(inputs[alibi_idx], 9);
        }
        enc_sk.dispatch_threadgroups(
            MTL::Size::Make((size_t)(NQ2 * num_splits), (size_t)H, (size_t)B),
            MTL::Size::Make((size_t)TGP2, 1, 1));

        // ── Phase 2: reduce ────────────────────────────────────────────────
        enc_sk.barrier();
        enc_sk.set_compute_pipeline_state(pl_sk2);
        enc_sk.set_buffer(reinterpret_cast<MTL::Buffer*>(pO_buf.ptr()), 0, 0);
        enc_sk.set_buffer(reinterpret_cast<MTL::Buffer*>(pL_buf.ptr()), 1, 0);
        enc_sk.set_output_array(out,       2);
        enc_sk.set_output_array(logsumexp, 3);
        enc_sk.set_bytes(sk_rp, 4);
        enc_sk.dispatch_threadgroups(
            MTL::Size::Make((size_t)N, (size_t)H, (size_t)B),
            MTL::Size::Make((size_t)reduce_tgp, 1, 1));

        mlx::core::allocator::free(pO_buf);
        mlx::core::allocator::free(pL_buf);
        return;
      }
    }
  }  // end if (!MFA_DISABLE_V2) — split-K block

  // ── STEEL V4 dispatch (f16/bf16, D=64/128, M3+ only) ────────────────────
  // Direct device K reads: eliminates K_smem + 2 barriers/tile (X + C).
  // Barrier schedule: B0 + (NK-1)×(A+B) ≈ 2×NK vs V2's 4×NK.
  // TGP: Q_smem + V_smem only (no K_smem). RoPE-K not supported (no TGP K).
  // Set MFA_ENABLE_V4=1 to opt in (disabled by default pending benchmarks).
  if (is_m3_plus_steel && std::getenv("MFA_ENABLE_V4")) {
    const bool v4_eligible =
        (dtype_code != 2) &&
        v4_tgp_eligible(D, is_m3_plus_steel) &&
        !params_.has_rope;    // V4 reads K raw from device; no TGP for RoPE-K

    if (v4_eligible) {
      auto cfg4 = select_steel_v4_block_config(D, is_m3_plus_steel);
      const int BQ4      = cfg4.BQ;   // 32
      const int BK4      = cfg4.BK;   // same as V2 (64 D=64, 64 M3+ D=128, 32 M1 D=128)
      const int WM4      = cfg4.WM;   // 4
      const int TGP4     = WM4 * cfg4.WN * 32;  // 128
      const int NQ4      = (N + BQ4 - 1) / BQ4;
      const int NK4      = (S + BK4 - 1) / BK4;
      const int NQ4_aln  = (N % BQ4 == 0) ? NQ4 : NQ4 - 1;
      const int NK4_aln  = (S % BK4 == 0) ? NK4 : NK4 - 1;

      using KK4 = ShaderCache::KernelKey;
      KK4 key4{
        KK4::KernelType::SteelForwardV4,
        D, BQ4, BK4, D, WM4,
        params_.causal,
        /*sparse=*/params_.has_block_mask,
        is_m3_plus_steel,
        /*has_rope=*/false,   // V4 never uses RoPE-K (gated above)
        /*rope_interleaved=*/false,
        params_.softcap > 0.0f,
        params_.has_alibi,
        params_.window_left >= 0 || params_.window_right >= 0,
        dtype_code,
        H / Hk
      };

      void* raw4     = ShaderCache::get().get_or_compile(key4, d.mtl_device());
      auto* pipeline4 = reinterpret_cast<MTL::ComputePipelineState*>(raw4);

      MFASteelParams sp4{};
      sp4.B          = B;
      sp4.H          = H;
      sp4.D          = D;
      sp4.qL         = N;
      sp4.kL         = S;
      sp4.gqa_factor = H / Hk;
      sp4.scale      = params_.scale;
      sp4.NQ         = NQ4;
      sp4.NK         = NK4;
      sp4.NQ_aligned = NQ4_aln;
      sp4.NK_aligned = NK4_aln;
      sp4.qL_rem     = (N % BQ4 == 0) ? BQ4 : (N % BQ4);
      sp4.kL_rem     = (S % BK4 == 0) ? BK4 : (S % BK4);
      sp4.qL_off     = (N < S && params_.causal) ? (S - N) : 0;
      sp4.rope_q_base     = params_.cache_seqlens;
      sp4.rope_cos_stride = D / 2;
      sp4.Q_strides[0] = (int64_t)H  * N * D;
      sp4.Q_strides[1] = (int64_t)N  * D;
      sp4.Q_strides[2] = (int64_t)D;
      sp4.K_strides[0] = (int64_t)Hk * S * D;
      sp4.K_strides[1] = (int64_t)S  * D;
      sp4.K_strides[2] = (int64_t)D;
      sp4.V_strides[0] = (int64_t)Hk * S * D;
      sp4.V_strides[1] = (int64_t)S  * D;
      sp4.V_strides[2] = (int64_t)D;
      sp4.O_strides[0] = (int64_t)H  * N * D;
      sp4.O_strides[1] = (int64_t)N  * D;
      sp4.O_strides[2] = (int64_t)D;
      sp4.L_strides[0] = (int64_t)H  * N;
      sp4.L_strides[1] = (int64_t)N;
      sp4.softcap      = params_.softcap;
      sp4.has_alibi    = params_.has_alibi ? 1 : 0;
      sp4.window_left  = params_.window_left;
      sp4.window_right = params_.window_right;
      sp4.mask_batch_stride = params_.has_block_mask ? (int64_t)(NQ4 * NK4) : 0;
      sp4.mask_head_stride  = params_.has_block_mask ? (int64_t)(NQ4 * NK4) : 0;

      auto& enc4 = d.get_command_encoder(stream().index);
      enc4.set_compute_pipeline_state(pipeline4);
      enc4.set_input_array(q,          0);
      enc4.set_input_array(k,          1);
      enc4.set_input_array(v,          2);
      enc4.set_output_array(out,       3);
      enc4.set_output_array(logsumexp, 4);
      enc4.set_bytes(sp4,              5);
      if (params_.has_block_mask) {
        enc4.set_input_array(inputs[3], 6);
      }
      if (params_.has_alibi) {
        int alibi_idx = 3 + (params_.has_block_mask ? 1 : 0);
        enc4.set_input_array(inputs[alibi_idx], 9);
      }

      enc4.dispatch_threadgroups(
          MTL::Size::Make((size_t)NQ4, (size_t)H, (size_t)B),
          MTL::Size::Make((size_t)TGP4, 1, 1));
      return;
    }
  }  // end if (is_m3_plus_steel && MFA_ENABLE_V4)

  // ── STEEL V5 dispatch (f16/bf16, D=64/128, all gens) ────────────────────
  // D-blocked: BD_tile=32, BK=128.  Q loaded from device into registers;
  // no Q_smem.  KV_smem = max(K^T=8704, V=10240) = 10,240 B → 3 TG/CU.
  // BK=128 → 4× fewer K-tile iterations vs V2 M1/M2 (BK=32).
  // Set MFA_ENABLE_V5=1 to opt in (disabled by default pending benchmarks).
  if (std::getenv("MFA_ENABLE_V5")) {
    const bool v5_elig =
        (dtype_code != 2) &&
        v5_eligible(D) &&
        !params_.has_rope &&         // RoPE: incompatible with register Q
        !params_.has_block_mask;     // sparse: block mask sized for V2's BK, not V5's BK=128

    if (v5_elig) {
      auto cfg5 = select_steel_v5_block_config(D, is_m3_plus_steel);
      const int BQ5     = cfg5.BQ;      // 32 (M1/M2) or 16 (M3+)
      const int BK5     = cfg5.BK;      // 128
      const int BD5     = cfg5.BD_tile; // 32
      const int WM5     = cfg5.WM;      // 4 (M1/M2) or 2 (M3+)
      const int TGP5    = WM5 * 32;     // 128 or 64
      const int NQ5     = (N + BQ5 - 1) / BQ5;
      const int NK5     = (S + BK5 - 1) / BK5;
      const int NQ5_aln = (N % BQ5 == 0) ? NQ5 : NQ5 - 1;
      const int NK5_aln = (S % BK5 == 0) ? NK5 : NK5 - 1;

      using KK5 = ShaderCache::KernelKey;
      KK5 key5{
        KK5::KernelType::SteelForwardV5,
        D, BQ5, BK5, BD5, WM5,
        params_.causal,
        /*sparse=*/params_.has_block_mask,
        is_m3_plus_steel,
        /*has_rope=*/false,
        /*rope_interleaved=*/false,
        params_.softcap > 0.0f,
        params_.has_alibi,
        params_.window_left >= 0 || params_.window_right >= 0,
        dtype_code,
        H / Hk
      };

      void* raw5      = ShaderCache::get().get_or_compile(key5, d.mtl_device());
      auto* pipeline5 = reinterpret_cast<MTL::ComputePipelineState*>(raw5);

      MFASteelParams sp5{};
      sp5.B          = B;
      sp5.H          = H;
      sp5.D          = D;
      sp5.qL         = N;
      sp5.kL         = S;
      sp5.gqa_factor = H / Hk;
      sp5.scale      = params_.scale;
      sp5.NQ         = NQ5;
      sp5.NK         = NK5;
      sp5.NQ_aligned = NQ5_aln;
      sp5.NK_aligned = NK5_aln;
      sp5.qL_rem     = (N % BQ5 == 0) ? BQ5 : (N % BQ5);
      sp5.kL_rem     = (S % BK5 == 0) ? BK5 : (S % BK5);
      sp5.qL_off     = (N < S && params_.causal) ? (S - N) : 0;
      sp5.rope_q_base     = params_.cache_seqlens;
      sp5.rope_cos_stride = D / 2;
      sp5.Q_strides[0] = (int64_t)H  * N * D;
      sp5.Q_strides[1] = (int64_t)N  * D;
      sp5.Q_strides[2] = (int64_t)D;
      sp5.K_strides[0] = (int64_t)Hk * S * D;
      sp5.K_strides[1] = (int64_t)S  * D;
      sp5.K_strides[2] = (int64_t)D;
      sp5.V_strides[0] = (int64_t)Hk * S * D;
      sp5.V_strides[1] = (int64_t)S  * D;
      sp5.V_strides[2] = (int64_t)D;
      sp5.O_strides[0] = (int64_t)H  * N * D;
      sp5.O_strides[1] = (int64_t)N  * D;
      sp5.O_strides[2] = (int64_t)D;
      sp5.L_strides[0] = (int64_t)H  * N;
      sp5.L_strides[1] = (int64_t)N;
      sp5.softcap      = params_.softcap;
      sp5.has_alibi    = params_.has_alibi ? 1 : 0;
      sp5.window_left  = params_.window_left;
      sp5.window_right = params_.window_right;
      sp5.mask_batch_stride = params_.has_block_mask ? (int64_t)(NQ5 * NK5) : 0;
      sp5.mask_head_stride  = params_.has_block_mask ? (int64_t)(NQ5 * NK5) : 0;

      auto& enc5 = d.get_command_encoder(stream().index);
      enc5.set_compute_pipeline_state(pipeline5);
      enc5.set_input_array(q,          0);
      enc5.set_input_array(k,          1);
      enc5.set_input_array(v,          2);
      enc5.set_output_array(out,       3);
      enc5.set_output_array(logsumexp, 4);
      enc5.set_bytes(sp5,              5);
      if (params_.has_block_mask) {
        enc5.set_input_array(inputs[3], 6);
      }
      if (params_.has_alibi) {
        int alibi_idx = 3 + (params_.has_block_mask ? 1 : 0);
        enc5.set_input_array(inputs[alibi_idx], 9);
      }

      enc5.dispatch_threadgroups(
          MTL::Size::Make((size_t)NQ5, (size_t)H, (size_t)B),
          MTL::Size::Make((size_t)TGP5, 1, 1));
      return;
    }
  }  // end if (MFA_ENABLE_V5)

  // ── STEEL V3 dispatch (f16/bf16, D=64 all gens, D=128 M1/M2 only) ───────
  // Separate K_smem + V_smem → 2 barriers/iter instead of V2's 4.
  // Benchmarked result: V3 regresses vs V2 (0.77–0.88×) because doubling TGP
  // (separate K+V instead of max(K,V)) halves occupancy (2 TGs/CU → 1 TG/CU).
  // Disabled by default; set MFA_ENABLE_V3=1 to opt in (research/benchmarking).
  if (std::getenv("MFA_ENABLE_V3")) {
    const bool v3_eligible =
        (dtype_code != 2) &&
        v3_tgp_eligible(D, is_m3_plus_steel) &&
        !params_.has_block_mask;

    if (v3_eligible) {
      auto cfg3 = select_steel_v3_block_config(D, is_m3_plus_steel);
      const int BQ3      = cfg3.BQ;   // 32
      const int BK3      = cfg3.BK;   // 64 (D=64) | 32 (D=128, all gens)
      const int WM3      = cfg3.WM;   // 4
      const int TGP3     = WM3 * cfg3.WN * 32;  // 128
      const int NQ3      = (N + BQ3 - 1) / BQ3;
      const int NK3      = (S + BK3 - 1) / BK3;
      const int NQ3_aln  = (N % BQ3 == 0) ? NQ3 : NQ3 - 1;
      const int NK3_aln  = (S % BK3 == 0) ? NK3 : NK3 - 1;

      using KK3 = ShaderCache::KernelKey;
      KK3 key3{
        KK3::KernelType::SteelForwardV3,
        D, BQ3, BK3, D, WM3,
        params_.causal,
        /*sparse=*/false,
        is_m3_plus_steel,
        params_.has_rope, params_.rope_interleaved,
        params_.softcap > 0.0f,
        params_.has_alibi,
        params_.window_left >= 0 || params_.window_right >= 0,
        dtype_code,
        H / Hk
      };

      void* raw3     = ShaderCache::get().get_or_compile(key3, d.mtl_device());
      auto* pipeline3 = reinterpret_cast<MTL::ComputePipelineState*>(raw3);

      MFASteelParams sp3{};
      sp3.B          = B;
      sp3.H          = H;
      sp3.D          = D;
      sp3.qL         = N;
      sp3.kL         = S;
      sp3.gqa_factor = H / Hk;
      sp3.scale      = params_.scale;
      sp3.NQ         = NQ3;
      sp3.NK         = NK3;
      sp3.NQ_aligned = NQ3_aln;
      sp3.NK_aligned = NK3_aln;
      sp3.qL_rem     = (N % BQ3 == 0) ? BQ3 : (N % BQ3);
      sp3.kL_rem     = (S % BK3 == 0) ? BK3 : (S % BK3);
      sp3.qL_off     = (N < S && params_.causal) ? (S - N) : 0;
      sp3.rope_q_base     = params_.cache_seqlens;
      sp3.rope_cos_stride = D / 2;
      sp3.Q_strides[0] = (int64_t)H  * N * D;
      sp3.Q_strides[1] = (int64_t)N  * D;
      sp3.Q_strides[2] = (int64_t)D;
      sp3.K_strides[0] = (int64_t)Hk * S * D;
      sp3.K_strides[1] = (int64_t)S  * D;
      sp3.K_strides[2] = (int64_t)D;
      sp3.V_strides[0] = (int64_t)Hk * S * D;
      sp3.V_strides[1] = (int64_t)S  * D;
      sp3.V_strides[2] = (int64_t)D;
      sp3.O_strides[0] = (int64_t)H  * N * D;
      sp3.O_strides[1] = (int64_t)N  * D;
      sp3.O_strides[2] = (int64_t)D;
      sp3.L_strides[0] = (int64_t)H  * N;
      sp3.L_strides[1] = (int64_t)N;
      sp3.softcap      = params_.softcap;
      sp3.has_alibi    = params_.has_alibi ? 1 : 0;
      sp3.window_left  = params_.window_left;
      sp3.window_right = params_.window_right;
      sp3.mask_batch_stride = 0;
      sp3.mask_head_stride  = 0;

      auto& enc3 = d.get_command_encoder(stream().index);
      enc3.set_compute_pipeline_state(pipeline3);
      enc3.set_input_array(q,          0);
      enc3.set_input_array(k,          1);
      enc3.set_input_array(v,          2);
      enc3.set_output_array(out,       3);
      enc3.set_output_array(logsumexp, 4);
      enc3.set_bytes(sp3,              5);
      if (params_.has_rope) {
        enc3.set_input_array(inputs[3], 7);
        enc3.set_input_array(inputs[4], 8);
      }
      if (params_.has_alibi) {
        int alibi_idx = 3 + (params_.has_rope ? 2 : 0);
        enc3.set_input_array(inputs[alibi_idx], 9);
      }

      enc3.dispatch_threadgroups(
          MTL::Size::Make((size_t)NQ3, (size_t)H, (size_t)B),
          MTL::Size::Make((size_t)TGP3, 1, 1));
      return;
    }
  }  // end if (MFA_ENABLE_V3)

  // ── STEEL V2 dispatch (f16/bf16, D=64/128 only) ──────────────────────────
  // BQ=32 (TQ=1), BK=64 (D=64) / BK=32 (D=128): sequential KV_smem, 2× BK vs V1.
  // D=256 excluded: routes to V1 (BQ=32, BK=16, WM=4, TGP=128).
  // Sparse (block_mask) excluded: mask is sized for V1 BK (BK_v1 != BK_v2).
  // Set MFA_DISABLE_V2=1 to bypass (forces V1 path, useful for benchmarking).
  if (!std::getenv("MFA_DISABLE_V2")) {
    const bool v2_eligible =
        (dtype_code != 2) &&
        is_v2_small_d_family(D) &&
        // block_mask is sized for V1 tile BK (BK_v1 ≠ BK_v2) — route to V1.
        !params_.has_block_mask;

    if (v2_eligible) {
      auto cfg2 = select_steel_v2_block_config(D, is_m3_plus_steel);
      const int BQ2      = cfg2.BQ;   // 32
      const int BK2      = cfg2.BK;   // 64 (D=64) | M1/M2 D=128:32, M3+ D=128:64
      const int WM2      = cfg2.WM;   // 4
      const int TGP2     = WM2 * cfg2.WN * 32;  // 128
      const int NQ2      = (N + BQ2 - 1) / BQ2;
      const int NK2      = (S + BK2 - 1) / BK2;
      const int NQ2_aln  = (N % BQ2 == 0) ? NQ2 : NQ2 - 1;
      const int NK2_aln  = (S % BK2 == 0) ? NK2 : NK2 - 1;

      using KK2 = ShaderCache::KernelKey;
      KK2 key2{
        KK2::KernelType::SteelForwardV2,
        D, BQ2, BK2, D, WM2,
        params_.causal,
        /*sparse=*/false,        // sparse routes to V1 (mask sized for V1 BK)
        is_m3_plus_steel,
        params_.has_rope, params_.rope_interleaved,
        params_.softcap > 0.0f,
        params_.has_alibi,
        params_.window_left >= 0 || params_.window_right >= 0,
        dtype_code,
        H / Hk
      };

      void* raw2     = ShaderCache::get().get_or_compile(key2, d.mtl_device());
      auto* pipeline2 = reinterpret_cast<MTL::ComputePipelineState*>(raw2);

      MFASteelParams sp2{};
      sp2.B          = B;
      sp2.H          = H;
      sp2.D          = D;
      sp2.qL         = N;
      sp2.kL         = S;
      sp2.gqa_factor = H / Hk;
      sp2.scale      = params_.scale;
      sp2.NQ         = NQ2;
      sp2.NK         = NK2;
      sp2.NQ_aligned = NQ2_aln;
      sp2.NK_aligned = NK2_aln;
      sp2.qL_rem     = (N % BQ2 == 0) ? BQ2 : (N % BQ2);
      sp2.kL_rem     = (S % BK2 == 0) ? BK2 : (S % BK2);
      sp2.qL_off     = (N < S && params_.causal) ? (S - N) : 0;
      sp2.rope_q_base     = params_.cache_seqlens;
      sp2.rope_cos_stride = D / 2;
      sp2.Q_strides[0] = (int64_t)H  * N * D;
      sp2.Q_strides[1] = (int64_t)N  * D;
      sp2.Q_strides[2] = (int64_t)D;
      sp2.K_strides[0] = (int64_t)Hk * S * D;
      sp2.K_strides[1] = (int64_t)S  * D;
      sp2.K_strides[2] = (int64_t)D;
      sp2.V_strides[0] = (int64_t)Hk * S * D;
      sp2.V_strides[1] = (int64_t)S  * D;
      sp2.V_strides[2] = (int64_t)D;
      sp2.O_strides[0] = (int64_t)H  * N * D;
      sp2.O_strides[1] = (int64_t)N  * D;
      sp2.O_strides[2] = (int64_t)D;
      sp2.L_strides[0] = (int64_t)H  * N;
      sp2.L_strides[1] = (int64_t)N;
      sp2.softcap      = params_.softcap;
      sp2.has_alibi    = params_.has_alibi ? 1 : 0;
      sp2.window_left  = params_.window_left;
      sp2.window_right = params_.window_right;
      // V2 is never sparse (block_mask sized for V1 BK ≠ V2 BK).
      sp2.mask_batch_stride = 0;
      sp2.mask_head_stride  = 0;

      auto& enc2 = d.get_command_encoder(stream().index);
      enc2.set_compute_pipeline_state(pipeline2);
      enc2.set_input_array(q,          0);
      enc2.set_input_array(k,          1);
      enc2.set_input_array(v,          2);
      enc2.set_output_array(out,       3);
      enc2.set_output_array(logsumexp, 4);
      enc2.set_bytes(sp2,              5);
      // buffer(6) = block_mask: unused in V2 (sparse routes to V1)
      if (params_.has_rope) {
        // Dense + RoPE: inputs[3]=cos, inputs[4]=sin (no block_mask in V2 path)
        enc2.set_input_array(inputs[3], 7);
        enc2.set_input_array(inputs[4], 8);
      }
      if (params_.has_alibi) {
        // Dense + ALiBi: inputs[3]=alibi_slopes (no block_mask, rope may or may not be set)
        int alibi_idx = 3 + (params_.has_rope ? 2 : 0);
        enc2.set_input_array(inputs[alibi_idx], 9);
      }

      // One threadgroup per Q-block: grid x = NQ2.
      enc2.dispatch_threadgroups(
          MTL::Size::Make((size_t)NQ2, (size_t)H, (size_t)B),
          MTL::Size::Make((size_t)TGP2, 1, 1));
      return;
    }
  }  // end if (!MFA_DISABLE_V2) — single-pass block

  // ── STEEL V2 D-split dispatch (f16/bf16, D=256/512) ─────────────────────
  // BD_HALF=128; D_SPLITS=D/128 (2 for D=256, 4 for D=512).
  // Uses dedicated large-D config selector (BK=32/64, WM=4, TGP=128).
  // D=128 BK calibration override (MFA_V2_FORCE_BK) does not affect D-split.
  // No RoPE (GPT-NeoX pairs cross BD_HALF boundary).
  // Sparse excluded (block_mask sized for V1 BK).
  // Set MFA_DISABLE_V2=1 to bypass.
  if (!std::getenv("MFA_DISABLE_V2")) {
    const bool v2_dsplit_eligible =
        (dtype_code != 2) &&
        is_v2_dsplit_family(D) &&
        !params_.has_block_mask &&
        !params_.has_rope;

    if (v2_dsplit_eligible) {
      const bool is_d256_path = is_v2_d256_family(D);
      const bool is_d512_path = is_v2_d512_family(D);
      const int BD_HALF = 128;
      auto cfg_ds       = select_steel_v2_dsplit_block_config(is_m3_plus_steel);
      const int BQ_ds   = cfg_ds.BQ;   // 32
      const int BK_ds   = cfg_ds.BK;   // 32 (M1/M2) or 64 (M3+)
      const int WM_ds   = cfg_ds.WM;   // 4
      const int TGP_ds  = WM_ds * cfg_ds.WN * 32;  // 128
      const int NQ_ds  = (N + BQ_ds - 1) / BQ_ds;
      const int NK_ds  = (S + BK_ds - 1) / BK_ds;
      const int NQ_ds_aln = (N % BQ_ds == 0) ? NQ_ds : NQ_ds - 1;
      const int NK_ds_aln = (S % BK_ds == 0) ? NK_ds : NK_ds - 1;

      using KKds = ShaderCache::KernelKey;
      // Keep the kernel-type branch explicit so D=512 decisions remain visible.
      auto kt_ds = KKds::KernelType::SteelV2DSplit512;
      if (is_d256_path) {
        kt_ds = KKds::KernelType::SteelV2DSplit256;
      } else if (is_d512_path) {
        kt_ds = KKds::KernelType::SteelV2DSplit512;
      }
      KKds key_ds{
        kt_ds,
        D, BQ_ds, BK_ds, BD_HALF, WM_ds,
        params_.causal,
        /*sparse=*/false,
        is_m3_plus_steel,
        /*has_rope=*/false, /*rope_interleaved=*/false,
        params_.softcap > 0.0f,
        params_.has_alibi,
        params_.window_left >= 0 || params_.window_right >= 0,
        dtype_code,
        H / Hk
      };

      void* raw_ds      = ShaderCache::get().get_or_compile(key_ds, d.mtl_device());
      auto* pipeline_ds = reinterpret_cast<MTL::ComputePipelineState*>(raw_ds);

      MFASteelParams sp_ds{};
      sp_ds.B          = B;
      sp_ds.H          = H;
      sp_ds.D          = D;
      sp_ds.qL         = N;
      sp_ds.kL         = S;
      sp_ds.gqa_factor = H / Hk;
      sp_ds.scale      = params_.scale;
      sp_ds.NQ         = NQ_ds;
      sp_ds.NK         = NK_ds;
      sp_ds.NQ_aligned = NQ_ds_aln;
      sp_ds.NK_aligned = NK_ds_aln;
      sp_ds.qL_rem     = (N % BQ_ds == 0) ? BQ_ds : (N % BQ_ds);
      sp_ds.kL_rem     = (S % BK_ds == 0) ? BK_ds : (S % BK_ds);
      sp_ds.qL_off     = (N < S && params_.causal) ? (S - N) : 0;
      sp_ds.rope_q_base     = params_.cache_seqlens;
      sp_ds.rope_cos_stride = D / 2;
      sp_ds.Q_strides[0] = (int64_t)H  * N * D;
      sp_ds.Q_strides[1] = (int64_t)N  * D;
      sp_ds.Q_strides[2] = (int64_t)D;
      sp_ds.K_strides[0] = (int64_t)Hk * S * D;
      sp_ds.K_strides[1] = (int64_t)S  * D;
      sp_ds.K_strides[2] = (int64_t)D;
      sp_ds.V_strides[0] = (int64_t)Hk * S * D;
      sp_ds.V_strides[1] = (int64_t)S  * D;
      sp_ds.V_strides[2] = (int64_t)D;
      sp_ds.O_strides[0] = (int64_t)H  * N * D;
      sp_ds.O_strides[1] = (int64_t)N  * D;
      sp_ds.O_strides[2] = (int64_t)D;
      sp_ds.L_strides[0] = (int64_t)H  * N;
      sp_ds.L_strides[1] = (int64_t)N;
      sp_ds.softcap      = params_.softcap;
      sp_ds.has_alibi    = params_.has_alibi ? 1 : 0;
      sp_ds.window_left  = params_.window_left;
      sp_ds.window_right = params_.window_right;
      sp_ds.mask_batch_stride = 0;
      sp_ds.mask_head_stride  = 0;

      auto& enc_ds = d.get_command_encoder(stream().index);
      enc_ds.set_compute_pipeline_state(pipeline_ds);
      enc_ds.set_input_array(q,          0);
      enc_ds.set_input_array(k,          1);
      enc_ds.set_input_array(v,          2);
      enc_ds.set_output_array(out,       3);
      enc_ds.set_output_array(logsumexp, 4);
      enc_ds.set_bytes(sp_ds,            5);
      if (params_.has_alibi) {
        // No rope, no block_mask in D-split path: ALiBi slopes at inputs[3].
        enc_ds.set_input_array(inputs[3], 9);
      }

      enc_ds.dispatch_threadgroups(
          MTL::Size::Make((size_t)NQ_ds, (size_t)H, (size_t)B),
          MTL::Size::Make((size_t)TGP_ds, 1, 1));
      return;
    }
  }  // end if (!MFA_DISABLE_V2) — D-split block

  // ── STEEL V1 tile config (f16 / bf16, or V2-disabled fallback) ───────────
  auto cfg = select_steel_block_config(D, /*is_low_prec=*/true, is_m3_plus_steel);
  int BQ = cfg.BQ;
  int BK = cfg.BK;
  int WM = cfg.WM;  // n_warps
  int WN = cfg.WN;
  int TGP_SIZE = WM * WN * 32;

  // ── Kernel cache key ─────────────────────────────────────────────────────
  using KK = ShaderCache::KernelKey;
  KK key{
    KK::KernelType::SteelForward,
    D,
    BQ, BK, D,   // block_d = full D (no sub-tiling in Steel)
    WM,
    params_.causal,
    params_.has_block_mask,  // sparse variant when block_mask present
    is_m3_plus_steel,        // separate compiled pipeline for M3+ configs
    params_.has_rope,           // in-kernel RoPE fusion variant
    params_.rope_interleaved,   // true=LLaMA, false=GPT-NeoX
    params_.softcap > 0.0f,    // tanh softcapping variant
    params_.has_alibi,          // ALiBi per-head position biases
    params_.window_left >= 0 || params_.window_right >= 0, // sliding window variant
    dtype_code
  };

  void* raw_pipeline = ShaderCache::get().get_or_compile(key, d.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw_pipeline);

  // ── Build MFASteelParams ─────────────────────────────────────────────────
  int NQ = (N + BQ - 1) / BQ;
  int NK = (S + BK - 1) / BK;
  int NQ_aligned = (N % BQ == 0) ? NQ : NQ - 1;
  int NK_aligned = (S % BK == 0) ? NK : NK - 1;

  MFASteelParams sp{};
  sp.B          = B;
  sp.H          = H;
  sp.D          = D;
  sp.qL         = N;
  sp.kL         = S;
  sp.gqa_factor = H / Hk;
  sp.scale      = params_.scale;
  sp.NQ         = NQ;
  sp.NK         = NK;
  sp.NQ_aligned = NQ_aligned;
  sp.NK_aligned = NK_aligned;
  sp.qL_rem     = (N % BQ == 0) ? BQ : (N % BQ);
  sp.kL_rem     = (S % BK == 0) ? BK : (S % BK);
  // For decode (N < S, causal), the first query row is at position S-N in the KV
  // sequence.  qL_off shifts the causal window so key position k is visible
  // to query row q when k <= q + qL_off.  For self-attention N==S → qL_off=0.
  sp.qL_off     = (N < S && params_.causal) ? (S - N) : 0;

  // RoPE fusion: absolute position of Q token 0 and stride of cos/sin table.
  // Both are zero when has_rope=false; the Metal kernel ignores them.
  sp.rope_q_base     = params_.cache_seqlens;
  sp.rope_cos_stride = D / 2;

  // Strides: [B, H, S] in elements (D=1 implicit)
  sp.Q_strides[0] = (int64_t)H * N * D;
  sp.Q_strides[1] = (int64_t)N * D;
  sp.Q_strides[2] = (int64_t)D;
  sp.K_strides[0] = (int64_t)Hk * S * D;
  sp.K_strides[1] = (int64_t)S * D;
  sp.K_strides[2] = (int64_t)D;
  sp.V_strides[0] = (int64_t)Hk * S * D;
  sp.V_strides[1] = (int64_t)S * D;
  sp.V_strides[2] = (int64_t)D;
  sp.O_strides[0] = (int64_t)H * N * D;
  sp.O_strides[1] = (int64_t)N * D;
  sp.O_strides[2] = (int64_t)D;
  // L strides: [B, H] with per-head stride = N
  sp.L_strides[0] = (int64_t)H * N;
  sp.L_strides[1] = (int64_t)N;

  // Optional features — must be set even when disabled (struct is zero-init'd
  // above but explicit assignment is clearer and guards against future refactors).
  sp.softcap     = params_.softcap;           // 0.0 when disabled
  sp.has_alibi   = params_.has_alibi ? 1 : 0;
  sp.window_left  = params_.window_left;     // -1 when disabled
  sp.window_right = params_.window_right;    // -1 when disabled

  // Block-sparse mask strides — 0 = broadcast this dimension.
  // 2D [NQ, NK]:       both = 0  (one mask shared by all B, H)
  // 3D [H, NQ, NK]:    batch=0, head=NQ*NK
  // 4D [B, H, NQ, NK]: batch=H*NQ*NK, head=NQ*NK
  sp.mask_batch_stride = 0;
  sp.mask_head_stride  = 0;
  if (params_.has_block_mask) {
    const auto& bm = inputs[3];
    if (bm.ndim() == 3) {
      sp.mask_head_stride  = (int64_t)bm.shape(1) * bm.shape(2);
    } else if (bm.ndim() == 4) {
      sp.mask_head_stride  = (int64_t)bm.shape(2) * bm.shape(3);
      sp.mask_batch_stride = (int64_t)bm.shape(1) * sp.mask_head_stride;
    }
    // 2D: both remain 0 (initialized above)
  }

  // ── Dispatch ─────────────────────────────────────────────────────────────
  auto& enc = d.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);

  // Buffers: Q=0, K=1, V=2, O=3, L=4, params=5, (block_mask=6 if sparse)
  enc.set_input_array(q,          0);
  enc.set_input_array(k,          1);
  enc.set_input_array(v,          2);
  enc.set_output_array(out,       3);
  enc.set_output_array(logsumexp, 4);
  enc.set_bytes(sp,               5);
  if (params_.has_block_mask) {
    enc.set_input_array(inputs[3], 6);
  }
  if (params_.has_rope) {
    // rotary_cos and rotary_sin follow block_mask (if present) in the input list.
    // Dense + RoPE: inputs[3]=cos, inputs[4]=sin
    // Sparse + RoPE (not currently exposed): inputs[4]=cos, inputs[5]=sin
    int cos_idx = params_.has_block_mask ? 4 : 3;
    enc.set_input_array(inputs[cos_idx],     7);
    enc.set_input_array(inputs[cos_idx + 1], 8);
  }
  if (params_.has_alibi) {
    // alibi_slopes [H] follows block_mask/rope in the input list.
    // Dense + ALiBi (no block_mask, no rope): inputs[3]=alibi_slopes
    int alibi_idx = 3
        + (params_.has_block_mask ? 1 : 0)
        + (params_.has_rope       ? 2 : 0);
    enc.set_input_array(inputs[alibi_idx], 9);
  }

  // 3D grid: persistent kernel — each TG handles 4 Q-tiles, so grid shrinks to ceil(NQ/4)
  static constexpr int kTilesPerTG = 4;
  const int NQ_tgs = (NQ + kTilesPerTG - 1) / kTilesPerTG;
  enc.dispatch_threadgroups(
      MTL::Size::Make(NQ_tgs, H, B),
      MTL::Size::Make(TGP_SIZE, 1, 1));
}

// =========================================================================
// Backward pass (Phase 3) — MFAttention::vjp
// =========================================================================
//
// MFA 7-GEMM backward pass split into two primitives:
//
//   Step 1: MFABackwardQuery [Q,K,V,O,L,dO] → [dQ, D_computed]
//     • Metal kernel computes D = scale * rowsum(O⊙dO) from O and dO,
//       writes D to the D output buffer, and accumulates dQ.
//
//   Step 2: MFABackwardKeyValue [Q,K,V,O,L,D_computed,dO] → [dK, dV]
//     • Metal kernel reads D_computed (now correctly scaled), computes
//       softmax derivatives, and accumulates dK and dV.
//
// Using two primitives lets MLX's graph execution guarantee that
// D_computed is fully written before backwardKeyValue reads it —
// no manual Metal memory barrier required.

std::vector<mlx::core::array> MFAttention::vjp(
    const std::vector<mlx::core::array>& primals,
    const std::vector<mlx::core::array>& cotangents,
    const std::vector<int>& argnums,
    const std::vector<mlx::core::array>& outputs) {

  const auto& q = primals[0];  // [B, H, N, D]
  const auto& k = primals[1];  // [B, H, S, D]
  const auto& v = primals[2];  // [B, H, S, D]

  // outputs[0] = O  (attention output, [B,H,N,D])
  // outputs[1] = L  (logsumexp,        [B,H,N], f32)
  const auto& O = outputs[0];
  const auto& L = outputs[1];

  // cotangents[0] = dO (gradient of O, same shape and dtype as O)
  const auto& dO = cotangents[0];

  mlx::core::Shape d_shape = {q.shape(0), q.shape(1), q.shape(2)};
  const int D_val = static_cast<int>(q.shape(3));

  // Route f16/bf16 D≤128 to the STEEL backward kernels.
  // GQA (H_q != H_kv) is supported: gqa_factor is set in BwdDQ/BwdDKV.
  const bool use_steel_bwd =
      (q.dtype() != mlx::core::float32) &&
      (D_val <= 128);

  std::vector<mlx::core::array> all_grads;

  if (use_steel_bwd) {
    // ---- STEEL backward path -----------------------------------------------
    //
    // delta = rowsum(dO * O)  [B, H, N], float32.
    // NOTE: do NOT pre-multiply by scale here.  The Metal kernel computes
    // dS = scale * P * (dP - delta), so delta must be the raw row-dot-product;
    // adding scale here would double-scale the subtracted term.
    // Computing this as a lazy MLX op lets the graph scheduler guarantee it
    // is ready before both bwd kernels execute; no explicit buffer chain needed.
    auto dO_f32    = mlx::core::astype(dO, mlx::core::float32, stream());
    auto O_f32     = mlx::core::astype(O,  mlx::core::float32, stream());
    auto dot_prod  = mlx::core::multiply(dO_f32, O_f32, stream());
    auto delta     = mlx::core::sum(dot_prod, std::vector<int>{3}, false, stream());

    // Step 1: STEEL dQ — grid (NQ, H, B), TGP = WM*32.
    // Buffer layout: Q(0),K(1),V(2),O(3-unused),L(4),dO(5),delta(6),dQ(7),p(8)
    auto bwd_q = mlx::core::array::make_arrays(
        {q.shape()},
        {q.dtype()},
        std::make_shared<MFASteelBwdDQ>(stream(), params_),
        {q, k, v, O, L, dO, delta});

    // Step 2: STEEL dKV — grid (NK, H, B), TGP = 32.
    // Buffer layout: Q(0),K(1),V(2),O(3-unused),L(4),delta(5),dO(6),dK(7),dV(8),p(9)
    auto bwd_kv = mlx::core::array::make_arrays(
        {k.shape(), v.shape()},
        {k.dtype(), v.dtype()},
        std::make_shared<MFASteelBwdDKV>(stream(), params_),
        {q, k, v, O, L, delta, dO});

    all_grads = {bwd_q[0], bwd_kv[0], bwd_kv[1]};

  } else {
    // ---- Legacy ccv backward path ------------------------------------------
    // Step 1: MFABackwardQuery → [dQ, D_computed]
    auto bwd_q = mlx::core::array::make_arrays(
        {q.shape(),         d_shape},
        {q.dtype(),  mlx::core::float32},
        std::make_shared<MFABackwardQuery>(stream(), params_),
        {q, k, v, O, L, dO});

    const auto& D_kernel = bwd_q[1];  // [B,H,N] f32, written by kernel

    // Step 2: MFABackwardKeyValue → [dK, dV]
    auto bwd_kv = mlx::core::array::make_arrays(
        {k.shape(),  v.shape()},
        {k.dtype(), v.dtype()},
        std::make_shared<MFABackwardKeyValue>(stream(), params_),
        {q, k, v, O, L, D_kernel, dO});

    all_grads = {bwd_q[0], bwd_kv[0], bwd_kv[1]};
  }

  // Return only the gradients for the requested argnums (0→dQ, 1→dK, 2→dV).
  std::vector<mlx::core::array> result;
  result.reserve(argnums.size());
  for (int i : argnums) {
    result.push_back(all_grads[i]);
  }
  return result;
}

// =========================================================================
// MFABackwardQuery::eval_gpu
// =========================================================================
//
// Dispatches the backwardQuery Metal kernel.
// The kernel computes D = scale*rowsum(O⊙dO) from O and dO and writes it
// to outputs[1] (D_computed); it also writes dQ to outputs[0].
//
// Buffer assignments (AttentionOperand::bufferIndex()):
//   Q=0, K=1, V=2, O=3, L=4, D=5(output), dO=6, dQ=9(output), params=10

void MFABackwardQuery::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {

  assert(inputs.size()  == 6);  // Q, K, V, O, L, dO
  assert(outputs.size() == 2);  // dQ, D_computed

  const auto& q  = inputs[0];  // [B, H, N, D]
  const auto& k  = inputs[1];  // [B, H, S, D]
  const auto& v  = inputs[2];  // [B, H, S, D]
  const auto& o  = inputs[3];  // [B, H, N, D]
  const auto& l  = inputs[4];  // [B, H, N], float32
  const auto& dO = inputs[5];  // [B, H, N, D]

  int B = q.shape(0), H = q.shape(1), N = q.shape(2), D = q.shape(3);
  int S = k.shape(2);

  auto& dQ         = outputs[0];  // [B, H, N, D], input dtype
  auto& D_computed = outputs[1];  // [B, H, N],    float32

  dQ.set_data(mlx::core::allocator::malloc(dQ.nbytes()));
  D_computed.set_data(mlx::core::allocator::malloc(D_computed.nbytes()));

  // ── Device & dtype ─────────────────────────────────────────────────────
  auto& dev = mlx::core::metal::device(stream().device);
  bool is_m3_plus = (dev.get_architecture_gen() >= 15); // 13=M1 14=M2 15=M3 16=M4

  uint8_t dtype_code;
  if (q.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (q.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else                                        dtype_code = 2;
  bool low_prec_inputs = (dtype_code != 2);
  const bool low_prec_inter = false; // forward blocks; see eval_gpu comment

  auto cfg = resolve_block_config(D, is_m3_plus, low_prec_inter,
                                  low_prec_inputs);
  unsigned short block_q = cfg.block_q;
  unsigned short block_k = cfg.block_k;
  unsigned short block_d = cfg.block_d;
  unsigned short n_warps = block_q / 8;

  MFAParams bw_params{};
  bw_params.R               = static_cast<uint32_t>(N);
  bw_params.C               = static_cast<uint32_t>(S);
  bw_params.Hq              = static_cast<uint32_t>(H);
  bw_params.H_Hk_ratio      = 1u;
  bw_params.dot_product_scale = params_.scale * static_cast<float>(M_LOG2E);
  bw_params.causal          = params_.causal ? 1u : 0u;
  bw_params.Q_batch_stride  = static_cast<uint32_t>(H * N * D);
  bw_params.K_batch_stride  = static_cast<uint32_t>(H * S * D);
  bw_params.V_batch_stride  = static_cast<uint32_t>(H * S * D);
  bw_params.O_batch_stride  = static_cast<uint32_t>(H * N * D);
  bw_params.dO_batch_stride = static_cast<uint32_t>(H * N * D);
  bw_params.dQ_batch_stride = static_cast<uint32_t>(H * N * D);
  bw_params.dK_batch_stride = static_cast<uint32_t>(H * S * D);
  bw_params.dV_batch_stride = static_cast<uint32_t>(H * S * D);

  using KK = ShaderCache::KernelKey;
  KK key{
    KK::KernelType::AttentionBackwardDQ,
    D, (int)block_q, (int)block_k, (int)block_d, (int)n_warps,
    params_.causal, /*sparse=*/false, is_m3_plus, /*has_rope=*/false,
    /*rope_interleaved=*/false,
    /*has_softcap=*/false, /*has_alibi=*/false, /*has_window=*/false, dtype_code
  };
  void* raw = ShaderCache::get().get_or_compile(key, dev.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw);

  auto& enc = dev.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);
  enc.set_input_array(q,            0);
  enc.set_input_array(k,            1);
  enc.set_input_array(v,            2);
  enc.set_input_array(o,            3);
  enc.set_input_array(l,            4);
  enc.set_output_array(D_computed,  5);  // kernel WRITES D here (buffer 5)
  enc.set_input_array(dO,           6);
  enc.set_output_array(dQ,          9);
  enc.set_bytes(bw_params,         10);

  uint32_t num_q_tiles = (static_cast<uint32_t>(N) + block_q - 1u) / block_q;
  uint32_t grid_dq     = num_q_tiles
                         * static_cast<uint32_t>(H)
                         * static_cast<uint32_t>(B);
  enc.dispatch_threadgroups(
      MTL::Size::Make(grid_dq,       1, 1),
      MTL::Size::Make(n_warps * 32u, 1, 1));
}

// =========================================================================
// MFABackwardKeyValue::eval_gpu
// =========================================================================
//
// Dispatches the backwardKeyValue Metal kernel.
// Reads D_computed (inputs[5]) written by MFABackwardQuery and accumulates
// dK (outputs[0]) and dV (outputs[1]).
//
// Buffer assignments:
//   Q=0, K=1, V=2, O=3, L=4, D=5(input), dO=6, dV=7(output), dK=8(output),
//   params=10

void MFABackwardKeyValue::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {

  assert(inputs.size()  == 7);  // Q, K, V, O, L, D_computed, dO
  assert(outputs.size() == 2);  // dK, dV

  const auto& q          = inputs[0];
  const auto& k          = inputs[1];
  const auto& v          = inputs[2];
  const auto& o          = inputs[3];
  const auto& l          = inputs[4];
  const auto& D_computed = inputs[5];  // float32 [B,H,N], from MFABackwardQuery
  const auto& dO         = inputs[6];

  int B = q.shape(0), H = q.shape(1), N = q.shape(2), D = q.shape(3);
  int S = k.shape(2);

  auto& dK = outputs[0];  // [B, H, S, D]
  auto& dV = outputs[1];  // [B, H, S, D]

  dK.set_data(mlx::core::allocator::malloc(dK.nbytes()));
  dV.set_data(mlx::core::allocator::malloc(dV.nbytes()));

  auto& dev = mlx::core::metal::device(stream().device);
  bool is_m3_plus = (dev.get_architecture_gen() >= 15); // 13=M1 14=M2 15=M3 16=M4

  uint8_t dtype_code;
  if (q.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (q.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else                                        dtype_code = 2;
  bool low_prec_inputs = (dtype_code != 2);
  const bool low_prec_inter = false; // forward blocks; see eval_gpu comment

  auto cfg = resolve_block_config(D, is_m3_plus, low_prec_inter,
                                  low_prec_inputs);
  unsigned short block_q = cfg.block_q;
  unsigned short block_k = cfg.block_k;
  unsigned short block_d = cfg.block_d;
  unsigned short n_warps = block_q / 8;

  MFAParams bw_params{};
  bw_params.R               = static_cast<uint32_t>(N);
  bw_params.C               = static_cast<uint32_t>(S);
  bw_params.Hq              = static_cast<uint32_t>(H);
  bw_params.H_Hk_ratio      = 1u;
  bw_params.dot_product_scale = params_.scale * static_cast<float>(M_LOG2E);
  bw_params.causal          = params_.causal ? 1u : 0u;
  bw_params.Q_batch_stride  = static_cast<uint32_t>(H * N * D);
  bw_params.K_batch_stride  = static_cast<uint32_t>(H * S * D);
  bw_params.V_batch_stride  = static_cast<uint32_t>(H * S * D);
  bw_params.O_batch_stride  = static_cast<uint32_t>(H * N * D);
  bw_params.dO_batch_stride = static_cast<uint32_t>(H * N * D);
  bw_params.dQ_batch_stride = static_cast<uint32_t>(H * N * D);
  bw_params.dK_batch_stride = static_cast<uint32_t>(H * S * D);
  bw_params.dV_batch_stride = static_cast<uint32_t>(H * S * D);

  using KK = ShaderCache::KernelKey;
  KK key{
    KK::KernelType::AttentionBackwardDKV,
    D, (int)block_q, (int)block_k, (int)block_d, (int)n_warps,
    params_.causal, /*sparse=*/false, is_m3_plus, /*has_rope=*/false,
    /*rope_interleaved=*/false,
    /*has_softcap=*/false, /*has_alibi=*/false, /*has_window=*/false, dtype_code
  };
  void* raw = ShaderCache::get().get_or_compile(key, dev.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw);

  auto& enc = dev.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);
  enc.set_input_array(q,          0);
  enc.set_input_array(k,          1);
  enc.set_input_array(v,          2);
  enc.set_input_array(o,          3);
  enc.set_input_array(l,          4);
  enc.set_input_array(D_computed, 5);  // kernel READS D from here (buffer 5)
  enc.set_input_array(dO,         6);
  enc.set_output_array(dV,        7);
  enc.set_output_array(dK,        8);
  enc.set_bytes(bw_params,       10);

  uint32_t num_k_tiles = (static_cast<uint32_t>(S) + block_q - 1u) / block_q;
  uint32_t grid_dkv    = num_k_tiles
                         * static_cast<uint32_t>(H)
                         * static_cast<uint32_t>(B);
  enc.dispatch_threadgroups(
      MTL::Size::Make(grid_dkv,      1, 1),
      MTL::Size::Make(n_warps * 32u, 1, 1));
}

// =========================================================================
// MFASteelBwdDQ::eval_gpu
// =========================================================================
//
// Dispatches the STEEL dQ backward kernel.
// Grid: (NQ, H, B) — one threadgroup per Q-tile.
//
// Buffer assignments (match generated Metal source):
//   Q(0), K(1), V(2), O(3-unused), L(4), dO(5), delta(6), dQ(7), params(8)

void MFASteelBwdDQ::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {

  // inputs: Q, K, V, O, L, dO, delta, [block_mask if sparse]
  assert(inputs.size()  == 7u + (params_.has_block_mask ? 1u : 0u));
  assert(outputs.size() == 1);  // dQ

  const auto& q     = inputs[0];  // [B, H, N, D]
  const auto& k     = inputs[1];  // [B, H, S, D]
  const auto& v     = inputs[2];  // [B, H, S, D]
  const auto& o     = inputs[3];  // [B, H, N, D]  (bound but not read)
  const auto& l     = inputs[4];  // [B, H, N], float32
  const auto& dO    = inputs[5];  // [B, H, N, D]
  const auto& delta = inputs[6];  // [B, H, N], float32

  const int B = q.shape(0), H = q.shape(1), N = q.shape(2), D = q.shape(3);
  const int S = k.shape(2), Hk = k.shape(1);  // Hk = H_kv for GQA

  auto& dQ = outputs[0];
  dQ.set_data(mlx::core::allocator::malloc(dQ.nbytes()));

  auto& dev = mlx::core::metal::device(stream().device);
  int arch_gen = static_cast<int>(dev.get_architecture_gen());
  if (const char* fg = std::getenv("MFA_FORCE_GEN")) arch_gen = std::atoi(fg);
  const bool is_m3_plus = (arch_gen >= 15);

  uint8_t dtype_code;
  if (q.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (q.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else                                        dtype_code = 2;

  const auto cfg = select_steel_block_config(D, /*is_low_prec=*/dtype_code != 2,
                                             is_m3_plus);
  const int BQ = cfg.BQ, BK = cfg.BK, BD = cfg.BD, WM = cfg.WM;
  const int NQ = (N + BQ - 1) / BQ;
  const int NK = (S + BK - 1) / BK;

  MFASteelBackwardParams sp{};
  sp.B            = B;   sp.H = H;   sp.D = D;
  sp.qL           = N;   sp.kL = S;
  sp.gqa_factor   = H / Hk;  // 1 for standard MHA; >1 for GQA
  sp.scale        = params_.scale;
  sp.scale_log2   = params_.scale * static_cast<float>(M_LOG2E);
  sp.NQ           = NQ;  sp.NK = NK;
  sp.NQ_aligned   = N / BQ;
  sp.NK_aligned   = S / BK;
  sp.qL_rem       = N % BQ;
  sp.kL_rem       = S % BK;
  sp.qL_off       = 0;
  // Strides: [B_stride, H_stride, seq_stride] for each operand.
  // K/V batch stride uses Hk (= H_kv), not H_q, since K/V are [B, H_kv, S, D].
  sp.Q_strides[0]  = (int64_t)H  * N * D;  sp.Q_strides[1]  = (int64_t)N * D;  sp.Q_strides[2]  = D;
  sp.K_strides[0]  = (int64_t)Hk * S * D;  sp.K_strides[1]  = (int64_t)S * D;  sp.K_strides[2]  = D;
  sp.V_strides[0]  = (int64_t)Hk * S * D;  sp.V_strides[1]  = (int64_t)S * D;  sp.V_strides[2]  = D;
  sp.O_strides[0]  = (int64_t)H  * N * D;  sp.O_strides[1]  = (int64_t)N * D;  sp.O_strides[2]  = D;
  sp.dO_strides[0] = (int64_t)H  * N * D;  sp.dO_strides[1] = (int64_t)N * D;  sp.dO_strides[2] = D;
  sp.dQ_strides[0] = (int64_t)H  * N * D;  sp.dQ_strides[1] = (int64_t)N * D;  sp.dQ_strides[2] = D;
  sp.dK_strides[0] = (int64_t)Hk * S * D;  sp.dK_strides[1] = (int64_t)S * D;  sp.dK_strides[2] = D;
  sp.dV_strides[0] = (int64_t)Hk * S * D;  sp.dV_strides[1] = (int64_t)S * D;  sp.dV_strides[2] = D;
  sp.L_strides[0]  = (int64_t)H  * N;      sp.L_strides[1]  = N;

  using KK = ShaderCache::KernelKey;
  KK key{KK::KernelType::SteelBackwardDQ,
         D, BQ, BK, BD, WM,
         params_.causal, /*sparse=*/params_.has_block_mask, is_m3_plus,
         /*has_rope=*/false, /*rope_interleaved=*/false,
         /*has_softcap=*/false, /*has_alibi=*/false, /*has_window=*/false, dtype_code,
         /*gqa_factor=*/H / Hk};
  void* raw = ShaderCache::get().get_or_compile(key, dev.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw);

  auto& enc = dev.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);
  enc.set_input_array(q,     0);
  enc.set_input_array(k,     1);
  enc.set_input_array(v,     2);
  enc.set_input_array(o,     3);  // declared in kernel; not read
  enc.set_input_array(l,     4);
  enc.set_input_array(dO,    5);
  enc.set_input_array(delta, 6);
  enc.set_output_array(dQ,   7);
  enc.set_bytes(sp,          8);
  if (params_.has_block_mask) {
    enc.set_input_array(inputs[7], 9);  // block_mask [NQ_tiles, NK_tiles] uchar
  }

  enc.dispatch_threadgroups(
      MTL::Size::Make(NQ, H, B),
      MTL::Size::Make(WM * 32, 1, 1));
}

// =========================================================================
// MFASteelBwdDKV::eval_gpu
// =========================================================================
//
// Dispatches the STEEL dK/dV backward kernel.
// Grid: (NK, H, B) — one threadgroup per K/V-tile (WM=1, TGP=32).
//
// Buffer assignments (match generated Metal source):
//   Q(0), K(1), V(2), O(3-unused), L(4), delta(5), dO(6),
//   dK(7), dV(8), params(9)

void MFASteelBwdDKV::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {

  // inputs: Q, K, V, O, L, delta, dO, [block_mask if sparse]
  assert(inputs.size()  == 7u + (params_.has_block_mask ? 1u : 0u));
  assert(outputs.size() == 2);  // dK, dV

  const auto& q     = inputs[0];
  const auto& k     = inputs[1];
  const auto& v     = inputs[2];
  const auto& o     = inputs[3];  // declared in kernel; not read
  const auto& l     = inputs[4];
  const auto& delta = inputs[5];  // [B, H, N], float32
  const auto& dO    = inputs[6];

  const int B = q.shape(0), H = q.shape(1), N = q.shape(2), D = q.shape(3);
  const int S = k.shape(2), Hk = k.shape(1);  // Hk = H_kv for GQA

  auto& dK = outputs[0];
  auto& dV = outputs[1];
  dK.set_data(mlx::core::allocator::malloc(dK.nbytes()));
  dV.set_data(mlx::core::allocator::malloc(dV.nbytes()));

  auto& dev = mlx::core::metal::device(stream().device);
  int arch_gen = static_cast<int>(dev.get_architecture_gen());
  if (const char* fg = std::getenv("MFA_FORCE_GEN")) arch_gen = std::atoi(fg);
  const bool is_m3_plus = (arch_gen >= 15);

  uint8_t dtype_code;
  if (q.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (q.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else                                        dtype_code = 2;

  const auto cfg = select_steel_block_config(D, /*is_low_prec=*/dtype_code != 2,
                                             is_m3_plus);
  const int BQ = cfg.BQ, BK = cfg.BK, BD = cfg.BD;
  const int NK = (S + BK - 1) / BK;
  const int NQ = (N + BQ - 1) / BQ;
  // dKV kernel hardcodes WM=1 (single simdgroup, no inter-warp race).
  constexpr int WM_DKV = 1;

  MFASteelBackwardParams sp{};
  sp.B            = B;   sp.H = H;   sp.D = D;
  sp.qL           = N;   sp.kL = S;
  sp.gqa_factor   = H / Hk;  // 1 for standard MHA; >1 for GQA
  sp.scale        = params_.scale;
  sp.scale_log2   = params_.scale * static_cast<float>(M_LOG2E);
  sp.NQ           = NQ;  sp.NK = NK;
  sp.NQ_aligned   = N / BQ;
  sp.NK_aligned   = S / BK;
  sp.qL_rem       = N % BQ;
  sp.kL_rem       = S % BK;
  sp.qL_off       = 0;
  // K/V/dK/dV batch strides use Hk (H_kv) — those tensors are [B, H_kv, S, D].
  sp.Q_strides[0]  = (int64_t)H  * N * D;  sp.Q_strides[1]  = (int64_t)N * D;  sp.Q_strides[2]  = D;
  sp.K_strides[0]  = (int64_t)Hk * S * D;  sp.K_strides[1]  = (int64_t)S * D;  sp.K_strides[2]  = D;
  sp.V_strides[0]  = (int64_t)Hk * S * D;  sp.V_strides[1]  = (int64_t)S * D;  sp.V_strides[2]  = D;
  sp.O_strides[0]  = (int64_t)H  * N * D;  sp.O_strides[1]  = (int64_t)N * D;  sp.O_strides[2]  = D;
  sp.dO_strides[0] = (int64_t)H  * N * D;  sp.dO_strides[1] = (int64_t)N * D;  sp.dO_strides[2] = D;
  sp.dQ_strides[0] = (int64_t)H  * N * D;  sp.dQ_strides[1] = (int64_t)N * D;  sp.dQ_strides[2] = D;
  sp.dK_strides[0] = (int64_t)Hk * S * D;  sp.dK_strides[1] = (int64_t)S * D;  sp.dK_strides[2] = D;
  sp.dV_strides[0] = (int64_t)Hk * S * D;  sp.dV_strides[1] = (int64_t)S * D;  sp.dV_strides[2] = D;
  sp.L_strides[0]  = (int64_t)H  * N;      sp.L_strides[1]  = N;

  using KK = ShaderCache::KernelKey;
  KK key{KK::KernelType::SteelBackwardDKV,
         D, BQ, BK, BD, WM_DKV,
         params_.causal, /*sparse=*/params_.has_block_mask, is_m3_plus,
         /*has_rope=*/false, /*rope_interleaved=*/false,
         /*has_softcap=*/false, /*has_alibi=*/false, /*has_window=*/false, dtype_code,
         /*gqa_factor=*/H / Hk};
  void* raw = ShaderCache::get().get_or_compile(key, dev.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw);

  auto& enc = dev.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);
  enc.set_input_array(q,     0);
  enc.set_input_array(k,     1);
  enc.set_input_array(v,     2);
  enc.set_input_array(o,     3);  // declared in kernel; not read
  enc.set_input_array(l,     4);
  enc.set_input_array(delta, 5);
  enc.set_input_array(dO,    6);
  enc.set_output_array(dK,   7);
  enc.set_output_array(dV,   8);
  enc.set_bytes(sp,          9);
  if (params_.has_block_mask) {
    enc.set_input_array(inputs[7], 10);  // block_mask [NQ_tiles, NK_tiles] uchar
  }

  // dKV grid Y = Hk (H_kv) — each TG handles one KV-head, iterating Q-heads
  enc.dispatch_threadgroups(
      MTL::Size::Make(NK, Hk, B),
      MTL::Size::Make(WM_DKV * 32, 1, 1));
}

// =========================================================================
// Equivalence
// =========================================================================

bool MFAttention::is_equivalent(const mlx::core::Primitive& other) const {
  auto* o = dynamic_cast<const MFAttention*>(&other);
  if (!o) return false;
  return params_.head_dim       == o->params_.head_dim       &&
         params_.scale          == o->params_.scale          &&
         params_.causal         == o->params_.causal         &&
         params_.has_block_mask == o->params_.has_block_mask &&
         params_.has_rope          == o->params_.has_rope          &&
         params_.rope_interleaved  == o->params_.rope_interleaved  &&
         params_.cache_seqlens     == o->params_.cache_seqlens     &&
         params_.softcap        == o->params_.softcap        &&
         params_.has_alibi      == o->params_.has_alibi      &&
         params_.window_left    == o->params_.window_left    &&
         params_.window_right   == o->params_.window_right;
}

// =========================================================================
// Free function: mfa_attention_forward
// =========================================================================

mlx::core::array mfa_attention_forward(
    const mlx::core::array& q,
    const mlx::core::array& k,
    const mlx::core::array& v,
    float scale,
    bool causal,
    float softcap,
    int  window_left,
    int  window_right,
    std::optional<mlx::core::StreamOrDevice> stream) {
  auto s = stream.has_value()
      ? mlx::core::to_stream(stream.value())
      : mlx::core::default_stream(mlx::core::Device::gpu);

  if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4) {
    throw std::invalid_argument("MFA: expected 4D inputs [B, H, N, D]");
  }

  // D.5: Enforce row-major BHND layout inside the C++ binding entry point.
  // mlx::core::contiguous() is a no-op (zero allocation) when the array is
  // already contiguous — it returns the same buffer with no copy.  Moving
  // this here eliminates 3 Python->C++ round-trips per forward dispatch.
  auto qc = mlx::core::contiguous(q, false, s);
  auto kc = mlx::core::contiguous(k, false, s);
  auto vc = mlx::core::contiguous(v, false, s);

  int D = qc.shape(3);
  if (D != 64 && D != 128 && D != 256) {
    throw std::invalid_argument(
        "MFA: head_dim must be 64, 128, or 256, got " + std::to_string(D));
  }

  MFAttention::Params params{D, scale, causal,
      /*has_block_mask=*/false, /*has_rope=*/false,
      /*rope_interleaved=*/false, /*cache_seqlens=*/0, /*softcap=*/softcap,
      /*has_alibi=*/false, /*window_left=*/window_left,
      /*window_right=*/window_right};

  auto out_shape  = qc.shape();                     // Shape [B, H, N, D]
  mlx::core::Shape lse_shape = {
      qc.shape(0), qc.shape(1), qc.shape(2)};       // Shape [B, H, N]

  // O dtype matches input dtype (kernel accumulates FP32 then writes input prec).
  // L (logsumexp for backward) is always FP32.
  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {qc.dtype(), mlx::core::float32},
      std::make_shared<MFAttention>(s, params),
      {qc, kc, vc});

  return outputs[0];
}

// =========================================================================
// Free function: mfa_attention_sparse_forward
// =========================================================================

mlx::core::array mfa_attention_sparse_forward(
    const mlx::core::array& q,
    const mlx::core::array& k,
    const mlx::core::array& v,
    const mlx::core::array& block_mask,
    float scale,
    bool causal,
    std::optional<mlx::core::StreamOrDevice> stream) {
  auto s = stream.has_value()
      ? mlx::core::to_stream(stream.value())
      : mlx::core::default_stream(mlx::core::Device::gpu);

  if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4) {
    throw std::invalid_argument("MFA sparse: expected 4D inputs [B, H, N, D]");
  }
  if (block_mask.ndim() < 2 || block_mask.ndim() > 4) {
    throw std::invalid_argument(
        "MFA sparse: block_mask must be 2D [NQ,NK], 3D [H,NQ,NK], "
        "or 4D [B,H,NQ,NK]");
  }

  int D = q.shape(3);
  if (D != 64 && D != 128 && D != 256) {
    throw std::invalid_argument(
        "MFA sparse: head_dim must be 64, 128, or 256, got " +
        std::to_string(D));
  }

  // Require f16/bf16 (sparse path is STEEL-only; f32 would need ccv update)
  if (q.dtype() == mlx::core::float32) {
    throw std::invalid_argument(
        "MFA sparse: float32 is not supported; use float16 or bfloat16");
  }

  MFAttention::Params params{D, scale, causal, /*has_block_mask=*/true,
      /*has_rope=*/false, /*rope_interleaved=*/false, /*cache_seqlens=*/0,
      /*softcap=*/0.0f, /*has_alibi=*/false, /*window_left=*/-1,
      /*window_right=*/-1};

  auto out_shape  = q.shape();
  mlx::core::Shape lse_shape = {q.shape(0), q.shape(1), q.shape(2)};

  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {q.dtype(), mlx::core::float32},
      std::make_shared<MFAttention>(s, params),
      {q, k, v, block_mask});

  return outputs[0];
}

std::vector<mlx::core::array> mfa_attention_sparse_forward_with_lse(
    const mlx::core::array& q,
    const mlx::core::array& k,
    const mlx::core::array& v,
    const mlx::core::array& block_mask,
    float scale,
    bool causal,
    std::optional<mlx::core::StreamOrDevice> stream) {
  auto s = stream.has_value()
      ? mlx::core::to_stream(stream.value())
      : mlx::core::default_stream(mlx::core::Device::gpu);

  if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4)
    throw std::invalid_argument("MFA sparse: expected 4D inputs [B, H, N, D]");
  if (block_mask.ndim() < 2 || block_mask.ndim() > 4)
    throw std::invalid_argument(
        "MFA sparse: block_mask must be 2D [NQ,NK], 3D [H,NQ,NK], "
        "or 4D [B,H,NQ,NK]");

  int D = q.shape(3);
  if (D != 64 && D != 128 && D != 256)
    throw std::invalid_argument(
        "MFA sparse: head_dim must be 64, 128, or 256, got " +
        std::to_string(D));

  if (q.dtype() == mlx::core::float32)
    throw std::invalid_argument(
        "MFA sparse: float32 is not supported; use float16 or bfloat16");

  MFAttention::Params params{D, scale, causal, /*has_block_mask=*/true,
      /*has_rope=*/false, /*rope_interleaved=*/false, /*cache_seqlens=*/0,
      /*softcap=*/0.0f, /*has_alibi=*/false, /*window_left=*/-1,
      /*window_right=*/-1};
  auto out_shape = q.shape();
  mlx::core::Shape lse_shape = {q.shape(0), q.shape(1), q.shape(2)};

  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {q.dtype(), mlx::core::float32},
      std::make_shared<MFAttention>(s, params),
      {q, k, v, block_mask});

  return {outputs[0], outputs[1]};  // O, L
}

// =========================================================================
// Free function: mfa_attention_rope_forward
// =========================================================================
//
// Forward pass with in-kernel RoPE fusion.
//   rotary_cos / rotary_sin: float32 [max_seq_len, D/2].
//   cache_seqlens: position of Q token 0 in the full sequence (KV cache length
//                  for autoregressive decode; 0 for prefill).
//
// The RoPE rotation is applied in threadgroup SRAM immediately after loading
// Q and K tiles — before the GEMM accumulation.  This fuses the rotary step
// into the attention kernel and eliminates a separate elementwise pass.
//
// Only f16/bf16 is supported (STEEL path).  float32 raises an error.

mlx::core::array mfa_attention_rope_forward(
    const mlx::core::array& q,
    const mlx::core::array& k,
    const mlx::core::array& v,
    const mlx::core::array& rotary_cos,
    const mlx::core::array& rotary_sin,
    float scale,
    bool causal,
    int cache_seqlens,
    bool interleaved,
    std::optional<mlx::core::StreamOrDevice> stream) {
  auto s = stream.has_value()
      ? mlx::core::to_stream(stream.value())
      : mlx::core::default_stream(mlx::core::Device::gpu);

  if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4) {
    throw std::invalid_argument(
        "MFA rope: expected 4D inputs [B, H, N, D]");
  }

  int D = q.shape(3);
  if (D != 64 && D != 128 && D != 256) {
    throw std::invalid_argument(
        "MFA rope: head_dim must be 64, 128, or 256, got " +
        std::to_string(D));
  }

  // RoPE fusion only on the STEEL path (f16/bf16).
  if (q.dtype() == mlx::core::float32) {
    throw std::invalid_argument(
        "MFA rope: float32 is not supported; use float16 or bfloat16");
  }

  MFAttention::Params params{
    D, scale, causal,
    /*has_block_mask=*/false,
    /*has_rope=*/true,
    /*rope_interleaved=*/interleaved,
    /*cache_seqlens=*/cache_seqlens,
    /*softcap=*/0.0f,
    /*has_alibi=*/false,
    /*window_left=*/-1,
    /*window_right=*/-1
  };

  auto out_shape  = q.shape();
  mlx::core::Shape lse_shape = {q.shape(0), q.shape(1), q.shape(2)};

  // inputs: [Q, K, V, rotary_cos, rotary_sin]
  // buffers in Metal: Q=0, K=1, V=2, O=3, L=4, params=5, cos=7, sin=8
  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {q.dtype(), mlx::core::float32},
      std::make_shared<MFAttention>(s, params),
      {q, k, v, rotary_cos, rotary_sin});

  return outputs[0];
}

// =========================================================================
// Free function: mfa_attention_alibi_forward
// =========================================================================

mlx::core::array mfa_attention_alibi_forward(
    const mlx::core::array& q,
    const mlx::core::array& k,
    const mlx::core::array& v,
    const mlx::core::array& alibi_slopes,
    float scale,
    bool causal,
    std::optional<mlx::core::StreamOrDevice> stream) {
  auto s = stream.has_value()
      ? mlx::core::to_stream(stream.value())
      : mlx::core::default_stream(mlx::core::Device::gpu);

  if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4)
    throw std::invalid_argument("MFA alibi: expected 4D inputs [B, H, N, D]");

  if (alibi_slopes.ndim() != 1)
    throw std::invalid_argument(
        "MFA alibi: alibi_slopes must be 1D [H]");

  // D.5: enforce row-major layout at the C++ binding entry point.
  auto qc = mlx::core::contiguous(q, false, s);
  auto kc = mlx::core::contiguous(k, false, s);
  auto vc = mlx::core::contiguous(v, false, s);

  int D = qc.shape(3);
  if (D != 64 && D != 128 && D != 256)
    throw std::invalid_argument(
        "MFA alibi: head_dim must be 64, 128, or 256, got " +
        std::to_string(D));

  MFAttention::Params params{
    D, scale, causal,
    /*has_block_mask=*/false,
    /*has_rope=*/false,
    /*rope_interleaved=*/false,
    /*cache_seqlens=*/0,
    /*softcap=*/0.0f,
    /*has_alibi=*/true,
    /*window_left=*/-1,
    /*window_right=*/-1
  };

  auto out_shape  = qc.shape();
  mlx::core::Shape lse_shape = {qc.shape(0), qc.shape(1), qc.shape(2)};

  // inputs: [Q, K, V, alibi_slopes]
  // Metal buffers: Q=0, K=1, V=2, O=3, L=4, params=5, alibi_slopes=9
  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {qc.dtype(), mlx::core::float32},
      std::make_shared<MFAttention>(s, params),
      {qc, kc, vc, alibi_slopes});

  return outputs[0];
}

// =========================================================================
// MFAVarlenAttention::eval_gpu
// =========================================================================
//
// Inputs:  Q(0), K(1), V(2), cu_seqlens_q(3), cu_seqlens_k(4), tile_offsets(5)
// Outputs: O(0), L(1)
// Metal:   Q=buf0, K=buf1, V=buf2, O=buf3, L=buf4, params=buf5, cu_q=buf6, cu_k=buf7, tiles=buf8

void MFAVarlenAttention::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {

  assert(inputs.size()  == 6);
  assert(outputs.size() == 2);

  const auto& q              = inputs[0];
  const auto& k              = inputs[1];
  const auto& v              = inputs[2];
  const auto& cu_seqlens_q   = inputs[3];
  const auto& cu_seqlens_k   = inputs[4];
  const auto& tile_offsets   = inputs[5];

  const int H  = q.shape(1);
  const int Hk = k.shape(1);
  const int total_q  = q.shape(2);
  const int total_kv = k.shape(2);
  const int D  = q.shape(3);
  const int num_seqs = (int)cu_seqlens_q.size() - 1;
  // tile_offsets is evaluated when eval_gpu() is called — last element = total tiles.
  const int total_q_tiles = tile_offsets.data<int>()[num_seqs];

  auto& O = outputs[0];
  auto& L = outputs[1];
  O.set_data(mlx::core::allocator::malloc(O.nbytes()));
  L.set_data(mlx::core::allocator::malloc(L.nbytes()));

  auto& dev = mlx::core::metal::device(stream().device);
  int arch_gen = static_cast<int>(dev.get_architecture_gen());
  if (const char* fg = std::getenv("MFA_FORCE_GEN")) arch_gen = std::atoi(fg);
  const bool is_m3_plus = (arch_gen >= 15);

  uint8_t dtype_code;
  if (q.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (q.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else                                        dtype_code = 2;

  const auto cfg = select_steel_block_config(D, dtype_code != 2, is_m3_plus);
  const int BQ = cfg.BQ, BK = cfg.BK, BD = cfg.BD, WM = cfg.WM;

  MFASteelVarlenParams vp{};
  vp.H             = H;
  vp.D             = D;
  vp.gqa_factor    = H / Hk;
  vp.num_seqs      = num_seqs;
  vp.total_q       = total_q;
  vp.total_kv      = total_kv;
  vp.total_q_tiles = total_q_tiles;
  vp.scale         = params_.scale;
  vp.softcap       = 0.0f;
  vp.Q_head_stride = (long)total_q  * D;
  vp.K_head_stride = (long)total_kv * D;

  using KK = ShaderCache::KernelKey;
  KK key{KK::KernelType::SteelVarlenForward,
         D, BQ, BK, BD, WM,
         params_.causal, /*sparse=*/false, is_m3_plus,
         false, false, false, false, /*has_window=*/false, dtype_code};
  void* raw = ShaderCache::get().get_or_compile(key, dev.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw);

  auto& enc = dev.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);
  enc.set_input_array(q,            0);
  enc.set_input_array(k,            1);
  enc.set_input_array(v,            2);
  enc.set_output_array(O,           3);
  enc.set_output_array(L,           4);
  enc.set_bytes(vp,                 5);
  enc.set_input_array(cu_seqlens_q, 6);
  enc.set_input_array(cu_seqlens_k, 7);
  enc.set_input_array(tile_offsets, 8);

  enc.dispatch_threadgroups(
      MTL::Size::Make(total_q_tiles, H, 1),
      MTL::Size::Make(WM * 32, 1, 1));
}

// =========================================================================
// mfa_attention_varlen_forward (free function)
// =========================================================================
// tile_offsets pre-computed in Python from cu_seqlens_q to avoid C++ eval().
std::pair<mlx::core::array, mlx::core::array> mfa_attention_varlen_forward(
    const mlx::core::array& q,
    const mlx::core::array& k,
    const mlx::core::array& v,
    const mlx::core::array& cu_q,
    const mlx::core::array& cu_k,
    const mlx::core::array& tile_offsets,
    float scale,
    bool  causal,
    mlx::core::Stream s) {

  const int H  = q.shape(1);

  mlx::core::Shape out_shape = q.shape();
  mlx::core::Shape lse_shape = {1, H, q.shape(2)};

  MFAVarlenAttention::Params params{scale, causal, q.shape(3)};

  // cu_seqlens cast to int32 if not already (Metal requires int32)
  auto cu_q_i32 = mlx::core::astype(cu_q, mlx::core::int32, s);
  auto cu_k_i32 = mlx::core::astype(cu_k, mlx::core::int32, s);
  auto tile_i32 = mlx::core::astype(tile_offsets, mlx::core::int32, s);

  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {q.dtype(), mlx::core::float32},
      std::make_shared<MFAVarlenAttention>(s, params),
      {q, k, v, cu_q_i32, cu_k_i32, tile_i32});

  return {outputs[0], outputs[1]};
}

// =========================================================================
// MFAPagedSteelForward::eval_gpu  (Track FD)
// =========================================================================
//
// Inputs:  Q(0)[B,H,N,D], k_pool(1)[num_blocks,BS,H_kv,D],
//          v_pool(2)[num_blocks,BS,H_kv,D], block_table(3)[B,max_blocks] int32,
//          seq_lens(4)[B] int32
// Outputs: O(0)[B,H,N,D], L(1)[B,H,N] float32
//
// Metal buffer layout:
//   Q=0, k_pool=1, v_pool=2, block_table=3, seq_lens=4, O=5, L=6, params=7

void MFAPagedSteelForward::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {

  assert(inputs.size()  == 5);
  assert(outputs.size() == 2);

  const auto& q           = inputs[0];  // [B, H, N, D]
  const auto& k_pool      = inputs[1];  // [num_blocks, block_size, H_kv, D]
  const auto& v_pool      = inputs[2];  // [num_blocks, block_size, H_kv, D]
  const auto& block_table = inputs[3];  // [B, max_blocks] int32
  const auto& seq_lens    = inputs[4];  // [B] int32

  const int B          = q.shape(0);
  const int H          = q.shape(1);
  const int N          = q.shape(2);   // query length
  const int D          = q.shape(3);
  const int block_size = k_pool.shape(1);
  const int H_kv       = k_pool.shape(2);
  const int num_blocks = k_pool.shape(0);
  const int max_blocks = block_table.shape(1);

  // kL = max(seq_lens) — used only for grid sizing, not per-batch masking.
  // seq_lens must already be evaluated by the free function (mx.eval'd).
  const int kL = [&]() -> int {
    int mx_len = 0;
    const int* sl = seq_lens.data<int>();
    for (int b = 0; b < B; ++b) mx_len = std::max(mx_len, sl[b]);
    return std::max(mx_len, 1);
  }();

  auto& O = outputs[0];
  auto& L = outputs[1];
  O.set_data(mlx::core::allocator::malloc(O.nbytes()));
  L.set_data(mlx::core::allocator::malloc(L.nbytes()));

  auto& dev = mlx::core::metal::device(stream().device);
  int arch_gen = static_cast<int>(dev.get_architecture_gen());
  if (const char* fg = std::getenv("MFA_FORCE_GEN")) arch_gen = std::atoi(fg);
  const bool is_m3_plus = (arch_gen >= 15);

  uint8_t dtype_code;
  if (q.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (q.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else dtype_code = 2;  // f32 not currently routed here but keep safe

  const auto cfg   = select_steel_block_config(D, dtype_code != 2, is_m3_plus);
  const int BQ     = cfg.BQ;
  const int BK     = cfg.BK;
  const int WM     = cfg.WM;
  const int TGP_SIZE = WM * 32;

  // ── Kernel cache key ────────────────────────────────────────────────────
  using KK = ShaderCache::KernelKey;
  KK key{
    KK::KernelType::PagedSteelForward,
    D,
    BQ, BK, D,          // block_d = full D (no sub-tiling)
    WM,
    params_.causal,
    /*sparse=*/false,
    is_m3_plus,
    /*has_rope=*/false,
    /*rope_interleaved=*/false,
    /*has_softcap=*/false,
    /*has_alibi=*/false,
    params_.window_left >= 0 || params_.window_right >= 0,  // has_window
    dtype_code,
    /*gqa_factor=*/H / H_kv
  };

  void* raw = ShaderCache::get().get_or_compile(key, dev.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw);

  // ── Build MFAPagedSteelParams ────────────────────────────────────────────
  const int NQ         = (N   + BQ - 1) / BQ;
  const int NK         = (kL  + BK - 1) / BK;
  const int NQ_aligned = (N   % BQ == 0) ? NQ : NQ - 1;
  const int NK_aligned = (kL  % BK == 0) ? NK : NK - 1;

  MFAPagedSteelParams pp{};
  pp.B          = B;
  pp.H          = H;
  pp.D          = D;
  pp.qL         = N;
  pp.kL         = kL;
  pp.gqa_factor = H / H_kv;
  pp.scale      = params_.scale;
  pp.NQ         = NQ;
  pp.NK         = NK;
  pp.NQ_aligned = NQ_aligned;
  pp.NK_aligned = NK_aligned;
  pp.qL_rem     = (N   % BQ == 0) ? BQ : (N   % BQ);
  pp.kL_rem     = (kL  % BK == 0) ? BK : (kL  % BK);
  // Decode: causal + N < kL → queries start at position kL-N in the KV seq.
  pp.qL_off     = (params_.causal && N < kL) ? (kL - N) : 0;
  pp.rope_q_base     = 0;   // RoPE not fused in paged path
  pp.rope_cos_stride = D / 2;
  // Q strides [B, H, N] (D=1 implicit)
  pp.Q_strides[0] = (int64_t)H  * N * D;
  pp.Q_strides[1] = (int64_t)N  * D;
  pp.Q_strides[2] = (int64_t)D;
  // O strides [B, H, N]
  pp.O_strides[0] = (int64_t)H  * N * D;
  pp.O_strides[1] = (int64_t)N  * D;
  pp.O_strides[2] = (int64_t)D;
  // L strides [B, H]
  pp.L_strides[0] = (int64_t)H  * N;
  pp.L_strides[1] = (int64_t)N;
  // Optional features
  pp.softcap      = 0.0f;
  pp.has_alibi    = 0;
  pp.window_left  = params_.window_left;
  pp.window_right = params_.window_right;
  // Paged-specific
  pp.block_size        = block_size;
  pp.max_blocks        = max_blocks;
  pp.pool_block_stride = block_size * H_kv * D;   // tokens/block * heads * D
  pp.pool_tok_stride   = H_kv * D;                // per-token stride (heads * D)
  pp.H_kv              = H_kv;

  // ── Dispatch ─────────────────────────────────────────────────────────────
  auto& enc = dev.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);

  // Buffer layout: Q=0, k_pool=1, v_pool=2, block_table=3, seq_lens=4,
  //                O=5, L=6, params=7
  enc.set_input_array (q,           0);
  enc.set_input_array (k_pool,      1);
  enc.set_input_array (v_pool,      2);
  enc.set_input_array (block_table, 3);
  enc.set_input_array (seq_lens,    4);
  enc.set_output_array(O,           5);
  enc.set_output_array(L,           6);
  enc.set_bytes       (pp,          7);

  // Persistent kernel: each TG handles 4 consecutive Q-tiles.
  static constexpr int kTilesPerTG = 4;
  const int NQ_tgs = (NQ + kTilesPerTG - 1) / kTilesPerTG;
  enc.dispatch_threadgroups(
      MTL::Size::Make(NQ_tgs, H, B),
      MTL::Size::Make(TGP_SIZE, 1, 1));
}

// =========================================================================
// mfa_paged_steel_forward (free function)
// =========================================================================

std::pair<mlx::core::array, mlx::core::array> mfa_paged_steel_forward(
    const mlx::core::array& q,
    const mlx::core::array& k_pool,
    const mlx::core::array& v_pool,
    const mlx::core::array& block_table,
    const mlx::core::array& seq_lens,
    float scale,
    bool  causal,
    int   window_left,
    int   window_right,
    int   block_size,
    mlx::core::Stream s) {

  // Validate shapes
  if (q.ndim() != 4)
    throw std::invalid_argument("mfa_paged_steel_forward: q must be 4-D [B,H,N,D]");
  if (k_pool.ndim() != 4)
    throw std::invalid_argument("mfa_paged_steel_forward: k_pool must be 4-D [num_blocks,BS,H_kv,D]");
  if (v_pool.ndim() != 4)
    throw std::invalid_argument("mfa_paged_steel_forward: v_pool must be 4-D [num_blocks,BS,H_kv,D]");
  if (block_table.ndim() != 2)
    throw std::invalid_argument("mfa_paged_steel_forward: block_table must be 2-D [B,max_blocks]");
  if (seq_lens.ndim() != 1)
    throw std::invalid_argument("mfa_paged_steel_forward: seq_lens must be 1-D [B]");

  const int B = q.shape(0);
  const int H = q.shape(1);
  const int N = q.shape(2);
  const int D = q.shape(3);

  // seq_lens must be evaluated before eval_gpu() so we can compute kL for grid.
  // The free function forces evaluation here.
  mlx::core::eval(seq_lens);

  // Cast block_table and seq_lens to int32 if not already.
  auto bt_i32 = mlx::core::astype(block_table, mlx::core::int32, s);
  auto sl_i32 = mlx::core::astype(seq_lens,    mlx::core::int32, s);
  mlx::core::eval(sl_i32);

  mlx::core::Shape out_shape = q.shape();          // [B, H, N, D]
  mlx::core::Shape lse_shape = {B, H, N};          // logsumexp

  MFAPagedSteelForward::Params params{D, scale, causal, window_left, window_right, block_size};

  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {q.dtype(), mlx::core::float32},
      std::make_shared<MFAPagedSteelForward>(s, params),
      {q, k_pool, v_pool, bt_i32, sl_i32});

  return {outputs[0], outputs[1]};
}

// =========================================================================
// MFASageForward::eval_gpu  (Track KB, CP2)
// =========================================================================
//
// Inputs:  q(0)[B,H,N,D] fp16/bf16, k_int8(1)[B,H_kv,S,D] int8,
//          v(2)[B,H_kv,S,D], k_scale(3)[B,H_kv,NK_blocks]
// Outputs: O(0)[B,H,N,D], L(1)[B,H,N] float32
//
// Metal buffer layout (CP2): Q=0, K_int8=1, V=2, O=3, L=4, params=5, K_scale=6

void MFASageForward::eval_gpu(
    const std::vector<mlx::core::array>& inputs,
    std::vector<mlx::core::array>& outputs) {

  assert(inputs.size()  == 4);
  assert(outputs.size() == 2);

  const auto& q       = inputs[0];  // [B, H,    N, D] fp16/bf16
  const auto& k_int8  = inputs[1];  // [B, H_kv, S, D] int8
  const auto& v       = inputs[2];  // [B, H_kv, S, D] fp16/bf16
  const auto& k_scale = inputs[3];  // [B, H_kv, NK_blocks]  float32

  const int B    = q.shape(0);
  const int H    = q.shape(1);
  const int N    = q.shape(2);   // query length
  const int D    = q.shape(3);
  const int H_kv = k_int8.shape(1);
  const int S    = k_int8.shape(2);   // KV length

  auto& O = outputs[0];
  auto& L = outputs[1];
  O.set_data(mlx::core::allocator::malloc(O.nbytes()));
  L.set_data(mlx::core::allocator::malloc(L.nbytes()));

  auto& dev = mlx::core::metal::device(stream().device);
  int arch_gen = static_cast<int>(dev.get_architecture_gen());
  if (const char* fg = std::getenv("MFA_FORCE_GEN")) arch_gen = std::atoi(fg);
  const bool is_m3_plus = (arch_gen >= 15);

  // V dtype code (O has same dtype as V)
  uint8_t dtype_code;
  if (v.dtype() == mlx::core::float16)       dtype_code = 0;
  else if (v.dtype() == mlx::core::bfloat16) dtype_code = 1;
  else dtype_code = 2;

  // CP3: Sage uses V2 tile sizes for D<=128. The Sage kernel already uses
  // sequential K/V sharing (Ks = KV_smem; Vs = KV_smem) — same as V2 STEEL.
  // V2 BK doubles K-tile coverage, halving K-tile iterations and barriers.
  // TGP: D=64 BK=64→13,824B; D=128 BK=32→18,944B — all <32KB.
  // Note: D=128 uses BK=32 on ALL gens (not M3+-adaptive BK=64) so that
  // sage_block_sizes() can return a gen-independent value for Python-side
  // quantization (K_scale.shape[-1] = S/BK must match kernel BK exactly).
  const bool is_low_prec = (dtype_code != 2);
  int BQ, BK, WM;
  if (D <= 128) {
    // Use V2 config but cap D=128 at BK=32 for Sage (Python API compatibility).
    const auto cfgv2_64 = select_steel_v2_block_config(64,  /*is_m3_plus=*/false);
    const auto cfgv2_128 = select_steel_v2_block_config(128, /*is_m3_plus=*/false);
    const auto& cfgv2 = (D <= 64) ? cfgv2_64 : cfgv2_128;
    BQ = cfgv2.BQ; BK = cfgv2.BK; WM = cfgv2.WM;
  } else {
    const auto cfgv1 = select_steel_block_config(D, is_low_prec, is_m3_plus);
    BQ = cfgv1.BQ; BK = cfgv1.BK; WM = cfgv1.WM;
  }
  const int TGP_SIZE = WM * 32;

  // ── Kernel cache key ────────────────────────────────────────────────────
  using KK = ShaderCache::KernelKey;
  KK key{
    KK::KernelType::SageForward,
    D,
    BQ, BK, D,
    WM,
    params_.causal,
    /*sparse=*/false,
    is_m3_plus,
    /*has_rope=*/false,
    /*rope_interleaved=*/false,
    /*has_softcap=*/false,
    /*has_alibi=*/false,
    /*has_window=*/params_.window_left >= 0 || params_.window_right >= 0,
    dtype_code,
    /*gqa_factor=*/params_.gqa_factor
  };

  void* raw = ShaderCache::get().get_or_compile(key, dev.mtl_device());
  auto* pipeline = reinterpret_cast<MTL::ComputePipelineState*>(raw);

  // ── Build MFASageParams ──────────────────────────────────────────────────
  const int NQ         = (N + BQ - 1) / BQ;
  const int NK         = (S + BK - 1) / BK;
  const int NQ_aligned = (N % BQ == 0) ? NQ : NQ - 1;
  const int NK_aligned = (S % BK == 0) ? NK : NK - 1;

  // NQ_blocks and NK_blocks are the same as NQ and NK (one scale per tile)
  // since quantization block_size was set to BQ and BK respectively.
  const int NQ_blocks = NQ;
  const int NK_blocks = NK;

  MFASageParams sp{};
  sp.B          = B;
  sp.H          = H;
  sp.D          = D;
  sp.qL         = N;
  sp.kL         = S;
  sp.gqa_factor = params_.gqa_factor;
  sp.scale      = params_.scale;
  sp.NQ         = NQ;
  sp.NK         = NK;
  sp.NQ_aligned = NQ_aligned;
  sp.NK_aligned = NK_aligned;
  sp.qL_rem     = (N % BQ == 0) ? BQ : (N % BQ);
  sp.kL_rem     = (S % BK == 0) ? BK : (S % BK);
  // For self-attention qL_off = 0; for decode with causal + N < S, offset the
  // causal mask so query at position i sees keys 0..(S-N+i).
  sp.qL_off     = (params_.causal && N < S) ? (S - N) : 0;
  // RoPE fields unused (kept for struct layout compatibility)
  sp.rope_q_base     = 0;
  sp.rope_cos_stride = D / 2;
  // Q strides [B, H, N] for fp16 (element units; CP2: Q is no longer int8)
  sp.Q_strides[0] = (int64_t)H  * N * D;
  sp.Q_strides[1] = (int64_t)N  * D;
  sp.Q_strides[2] = (int64_t)D;
  // K strides [B, H_kv, S] for int8
  sp.K_strides[0] = (int64_t)H_kv * S * D;
  sp.K_strides[1] = (int64_t)S  * D;
  sp.K_strides[2] = (int64_t)D;
  // V strides [B, H_kv, S] for fp16
  sp.V_strides[0] = (int64_t)H_kv * S * D;
  sp.V_strides[1] = (int64_t)S  * D;
  sp.V_strides[2] = (int64_t)D;
  // O strides [B, H, N] for fp16
  sp.O_strides[0] = (int64_t)H  * N * D;
  sp.O_strides[1] = (int64_t)N  * D;
  sp.O_strides[2] = (int64_t)D;
  // L strides [B, H] for float32
  sp.L_strides[0] = (int64_t)H  * N;
  sp.L_strides[1] = (int64_t)N;
  sp.softcap      = 0.0f;
  sp.has_alibi    = 0;
  sp.window_left  = params_.window_left;
  sp.window_right = params_.window_right;
  // Scale strides: K_scale [B, H_kv, NK_blocks]. Q_scale eliminated (CP2).
  sp.NQ_blocks         = NQ_blocks;
  sp.NK_blocks         = NK_blocks;
  sp.k_scale_stride_b  = H_kv * NK_blocks;
  sp.k_scale_stride_h  = NK_blocks;

  // ── Dispatch ─────────────────────────────────────────────────────────────
  auto& enc = dev.get_command_encoder(stream().index);
  enc.set_compute_pipeline_state(pipeline);

  // Buffer layout (CP2): Q=0, K_int8=1, V=2, O=3, L=4, params=5, K_scale=6
  enc.set_input_array (q,       0);
  enc.set_input_array (k_int8,  1);
  enc.set_input_array (v,       2);
  enc.set_output_array(O,       3);
  enc.set_output_array(L,       4);
  enc.set_bytes       (sp,      5);
  enc.set_input_array (k_scale, 6);

  // Non-persistent grid: one TG per Q-tile
  enc.dispatch_threadgroups(
      MTL::Size::Make(NQ, H, B),
      MTL::Size::Make(TGP_SIZE, 1, 1));
}

// =========================================================================
// mfa_sage_forward (free function)
// =========================================================================

std::pair<mlx::core::array, mlx::core::array> mfa_sage_forward(
    const mlx::core::array& q,
    const mlx::core::array& k_int8,
    const mlx::core::array& v,
    const mlx::core::array& k_scale,
    float scale,
    bool  causal,
    int   window_left,
    int   window_right,
    mlx::core::Stream s) {

  // Shape validation
  if (q.ndim() != 4)
    throw std::invalid_argument("mfa_sage_forward: q must be 4-D [B,H,N,D]");
  if (k_int8.ndim() != 4)
    throw std::invalid_argument("mfa_sage_forward: k_int8 must be 4-D [B,H_kv,S,D]");
  if (v.ndim() != 4)
    throw std::invalid_argument("mfa_sage_forward: v must be 4-D [B,H_kv,S,D]");
  if (k_scale.ndim() != 3)
    throw std::invalid_argument("mfa_sage_forward: k_scale must be 3-D [B,H_kv,NK_blocks]");

  const int B    = q.shape(0);
  const int H    = q.shape(1);
  const int N    = q.shape(2);
  const int D    = q.shape(3);
  const int H_kv = k_int8.shape(1);

  if (H % H_kv != 0)
    throw std::invalid_argument(
        "mfa_sage_forward: H must be divisible by H_kv (GQA).");

  const int gqa_factor = H / H_kv;

  mlx::core::Shape out_shape = {B, H, N, D};
  mlx::core::Shape lse_shape = {B, H, N};

  MFASageForward::Params params{D, scale, causal, gqa_factor, window_left, window_right};

  auto outputs = mlx::core::array::make_arrays(
      {out_shape, lse_shape},
      {v.dtype(), mlx::core::float32},
      std::make_shared<MFASageForward>(s, params),
      {q, k_int8, v, k_scale});

  return {outputs[0], outputs[1]};
}

}  // namespace mlx_mfa
