# Smart Organizer

A command-line tool to organize files in directories by type, find duplicates, clean up empty folders, and undo operations.

## Features

- **Organize Files**: Automatically move files into categorized folders based on file extensions (e.g., Images, Videos, Documents).
- **Find Duplicates**: Scan directories for duplicate files using SHA256 hashing.
- **Clean Up**: Remove empty folders recursively.
- **Undo Operations**: Reverse the last organize or clean operation.
- **Flexible Options**: Recursive scanning, dry-run mode, include/exclude hidden files, logging.
- **Safe Operations**: Dry-run mode to preview changes, conflict resolution for file moves.

## Installation

1. Ensure you have Python 3.8+ installed.
2. Clone or download the repository.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Install the package in editable mode:
   ```bash
   pip install -e .
   ```

## Usage

The tool provides several commands. Run `smart-organizer --help` for a list of commands.

### Organize Files

Moves files from the specified directory into subfolders based on their file type.

**Command:**
```bash
smart-organizer organize <directory_path> [options]
```

**Options:**
- `--recursive / --no-recursive`: Scan and organize files in subdirectories (default: recursive).
- `--dry-run`: Preview what would be moved without making changes.
- `--include-hidden`: Include hidden files (starting with `.`) and system files.
- `--overwrite`: Overwrite existing files if there are naming conflicts.
- `--log-file LOG_FILE`: Save operation logs to the specified file.

**Example:**
```bash
smart-organizer organize /path/to/messy/folder --dry-run
```
This shows what files would be moved, e.g., "Would move: photo.jpg -> Images/"

```bash
smart-organizer organize /path/to/messy/folder --recursive --include-hidden --log-file organize.log
```
Organizes all files recursively, includes hidden files, and logs to `organize.log`.

**Categories:**
- Images: .png, .jpg, .jpeg, .gif, .bmp, .tiff, .webp, .svg
- Videos: .mp4, .mkv, .mov, .avi, .wmv, .flv, .webm
- Documents: .pdf, .doc, .docx, .ppt, .pptx, .xls, .xlsx, .txt, .rtf
- Audio: .mp3, .wav, .flac, .aac, .ogg, .wma
- Archives: .zip, .rar, .tar, .gz, .7z, .bz2
- Code: .py, .js, .java, .cpp, .c, .h, .html, .css, .php, .rb, .go
- Executables: .exe, .msi, .dmg, .app, .deb, .rpm
- Fonts: .ttf, .otf, .woff, .woff2
- Others: Any other extensions

### Find Duplicates

Scans for duplicate files based on content hash and displays them grouped.

**Command:**
```bash
smart-organizer duplicates <directory_path> [options]
```

**Options:**
- `--recursive / --no-recursive`: Scan subdirectories (default: recursive).
- `--include-hidden`: Include hidden files.
- `--log-file LOG_FILE`: Save logs to file.

**Example:**
```bash
smart-organizer duplicates /path/to/folder --recursive
```
Outputs groups of duplicate files, e.g.:
```
Found 2 duplicate groups with 3 duplicate files:
Group 1 (Hash: abc123...):
  /path/file1.txt
  /path/file2.txt
Group 2 (Hash: def456...):
  /path/file3.jpg
  /path/file4.jpg
  /path/file5.jpg
```

### Clean Empty Folders

Removes all empty folders recursively.

**Command:**
```bash
smart-organizer clean <directory_path> [options]
```

**Options:**
- `--dry-run`: Preview folders that would be removed.
- `--log-file LOG_FILE`: Save logs to file.

**Example:**
```bash
smart-organizer clean /path/to/folder --dry-run
```
Shows "Would remove empty folder: /path/empty/"

```bash
smart-organizer clean /path/to/folder
```
Removes all empty folders and reports the count.

### Undo Operations

Reverses the last organize or clean operation in the directory.

**Command:**
```bash
smart-organizer undo <directory_path> --operation <operation> [options]
```

**Options:**
- `--operation`: 'organize' or 'clean' (default: organize).
- `--log-file LOG_FILE`: Save logs to file.

**Example:**
```bash
smart-organizer undo /path/to/folder --operation organize
```
Moves files back to their original locations.

```bash
smart-organizer undo /path/to/folder --operation clean
```
Recreates the previously removed empty folders.

**Note:** Undo only works for the most recent operation and requires the undo files (`.smart_organizer_undo_*.json`) to be present in the directory.

### Show File Categories

Displays all supported file categories and their extensions.

**Command:**
```bash
smart-organizer info
```

**Example Output:**
```
File Categories:
  Images: .png, .jpg, .jpeg, .gif, .bmp, .tiff, .webp, .svg
  Videos: .mp4, .mkv, .mov, .avi, .wmv, .flv, .webm
  ...
```

## Tips

- Always use `--dry-run` first to see what will happen.
- Use `--log-file` to keep a record of operations.
- For large directories, consider running without `--recursive` first.
- Undo is only available immediately after an operation; the undo files are deleted after undoing.

## Requirements

- Python 3.8+
- Dependencies: typer, pathlib (standard library)

## License

[Add license if applicable]

### Show File Categories
```bash
smart-organizer info
```

## File Categories

- **Images**: .png, .jpg, .jpeg, .gif, .bmp, .tiff, .webp, .svg
- **Videos**: .mp4, .mkv, .mov, .avi, .wmv, .flv, .webm
- **Documents**: .pdf, .doc, .docx, .ppt, .pptx, .xls, .xlsx, .txt, .rtf
- **Audio**: .mp3, .wav, .flac, .aac, .ogg, .wma
- **Archives**: .zip, .rar, .tar, .gz, .7z, .bz2
- **Code**: .py, .js, .java, .cpp, .c, .h, .html, .css, .php, .rb, .go
- **Executables**: .exe, .msi, .dmg, .app, .deb, .rpm
- **Fonts**: .ttf, .otf, .woff, .woff2
- **Others**: All other file types

## Examples

Organize files with dry run:
```bash
smart-organizer organize ~/Downloads --dry-run
```

Find duplicates in current directory:
```bash
smart-organizer duplicates . --include-hidden
```

Clean empty folders:
```bash
smart-organizer clean ~/Documents
```

## License

MIT License