from pathlib import Path
import os


def create_folder(path: Path) -> None:
    """Create directory if it doesn't exist."""
    path.mkdir(parents=True, exist_ok=True)


def get_extension(file_path: Path) -> str:
    """Get file extension in lowercase."""
    return file_path.suffix.lower()


def is_hidden(file_path: Path) -> bool:
    """Check if file is hidden (starts with dot)."""
    return file_path.name.startswith(".")


def is_system_file(file_path: Path) -> bool:
    """Check if file is a system file (e.g., desktop.ini, Thumbs.db)."""
    system_files = {"desktop.ini", "thumbs.db", ".ds_store"}
    return file_path.name.lower() in system_files


def safe_move(src: Path, dst: Path, overwrite: bool = False) -> bool:
    """Safely move file, handling overwrites."""
    if dst.exists() and not overwrite:
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    os.rename(src, dst)
    return True