# smart_organizer/rules.py

from typing import Dict, List


FILE_CATEGORIES: Dict[str, List[str]] = {
    "Images": [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".webp", ".svg"],
    "Videos": [".mp4", ".mkv", ".mov", ".avi", ".wmv", ".flv", ".webm"],
    "Documents": [".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt", ".rtf"],
    "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma"],
    "Archives": [".zip", ".rar", ".tar", ".gz", ".7z", ".bz2"],
    "Code": [".py", ".js", ".java", ".cpp", ".c", ".h", ".html", ".css", ".php", ".rb", ".go"],
    "Executables": [".exe", ".msi", ".dmg", ".app", ".deb", ".rpm"],
    "Fonts": [".ttf", ".otf", ".woff", ".woff2"],
}


def get_category(extension: str) -> str:
    """Get category for file extension."""
    for category, extensions in FILE_CATEGORIES.items():
        if extension in extensions:
            return category
    return "Others"


def add_custom_rule(category: str, extensions: List[str]) -> None:
    """Add custom category with extensions."""
    FILE_CATEGORIES[category] = extensions


def get_all_categories() -> Dict[str, List[str]]:
    """Get all file categories."""
    return FILE_CATEGORIES.copy()