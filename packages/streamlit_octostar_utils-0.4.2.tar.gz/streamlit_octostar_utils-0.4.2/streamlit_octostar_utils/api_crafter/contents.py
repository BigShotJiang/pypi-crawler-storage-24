"""
Contents abstraction for NiFi entities.

Provides a FileIO-like interface for handling entity contents with support for:
- Full io.BufferedIOBase compatibility (read, write, seek, tell, etc.)
- Seeking and streaming with HTTP Range requests
- Multiple storage backends (memory, workspace attachments, temporary blobs)
- Serialization/deserialization via from_locator()/to_locator() methods
- Lazy loading and efficient partial reads for large files

Storage Backends:
- MemoryContents: In-memory buffer (like BytesIO)
- WorkspaceAttachmentContents: Octostar workspace attachments via v2 entities API
- TemporaryAttachmentContents: Octostar temporary blob storage (user temp bucket, presigned URLs)
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List
from enum import Enum
import base64
import logging
from io import BytesIO, SEEK_SET, SEEK_CUR, SEEK_END

_logger = logging.getLogger(__name__)


class ContentsLocation(Enum):
    """Enumeration of supported content storage locations."""
    MEMORY = "memory"
    WORKSPACE_ATTACHMENT = "workspace_attachment"
    TEMPORARY_ATTACHMENT = "temporary_attachment"
    REFERENCE = "reference"


class Contents(ABC):
    """
    Abstract base class for entity contents.
    
    Provides a FileIO-like interface with support for seeking, streaming,
    and multiple storage backends. Each implementation manages its own
    locator dictionary for serialization/deserialization.
    """
    
    def __init__(
        self,
        entity_type: Optional[str] = None,
        filetype: Optional[str] = None,
        **kwargs
    ):
        self._entity_type = entity_type
        self._filetype = filetype
        self._closed = False
    
    # ==================== FileIO Interface ====================
    
    @abstractmethod
    def read(self, size: int = -1) -> bytes:
        """
        Read and return up to size bytes, or all bytes if size is -1.
        
        Args:
            size: Number of bytes to read. -1 means read all.
            
        Returns:
            Bytes read from the stream.
        """
        pass
    
    @abstractmethod
    def write(self, b: bytes) -> int:
        """
        Write bytes to the stream.
        
        Args:
            b: Bytes to write.
            
        Returns:
            Number of bytes written.
        """
        pass
    
    @abstractmethod
    def seek(self, offset: int, whence: int = SEEK_SET) -> int:
        """
        Change stream position.
        
        Args:
            offset: Offset relative to whence.
            whence: SEEK_SET (0) = from start, SEEK_CUR (1) = from current, SEEK_END (2) = from end.
            
        Returns:
            New absolute position.
        """
        pass
    
    @abstractmethod
    def tell(self) -> int:
        """
        Return current stream position.
        
        Returns:
            Current position in bytes.
        """
        pass
    
    def readable(self) -> bool:
        return True
    
    def writable(self) -> bool:
        return True
    
    def seekable(self) -> bool:
        return True
    
    @abstractmethod
    def flush(self):
        """Flush write buffers."""
        pass
    
    @abstractmethod
    def close(self):
        """Close the stream and release resources."""
        self._closed = True
    
    @abstractmethod
    def delete(self):
        """Delete the contents from their storage backend."""
        pass
    
    @property
    def closed(self) -> bool:
        """Check if stream is closed."""
        return self._closed
    
    @abstractmethod
    def truncate(self, size: Optional[int] = None) -> int:
        """
        Resize the stream to the given size.
        
        Args:
            size: New size in bytes. If None, use current position.
            
        Returns:
            New size.
        """
        pass
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False
    
    def readline(self, size: int = -1) -> bytes:
        """
        Read and return one line from the stream.
        
        Args:
            size: Maximum number of bytes to read. -1 means no limit.
            
        Returns:
            Bytes up to and including the newline character, or until EOF.
        """
        result = bytearray()
        while True:
            if size >= 0 and len(result) >= size:
                break
            byte = self.read(1)
            if not byte:
                break
            result.extend(byte)
            if byte == b'\n':
                break
        return bytes(result)
    
    def readlines(self, hint: int = -1) -> List[bytes]:
        """
        Read and return a list of lines from the stream.
        
        Args:
            hint: Optional size hint. If total size of lines exceeds hint, no more lines are read.
            
        Returns:
            List of lines.
        """
        lines = []
        total_size = 0
        while True:
            line = self.readline()
            if not line:
                break
            lines.append(line)
            total_size += len(line)
            if hint >= 0 and total_size >= hint:
                break
        return lines
    
    def writelines(self, lines: List[bytes]):
        """
        Write a list of lines to the stream.
        
        Args:
            lines: List of byte strings to write.
        """
        for line in lines:
            self.write(line)
    
    def readinto(self, b: bytearray) -> int:
        """
        Read bytes into a pre-allocated buffer.
        
        Args:
            b: Pre-allocated bytearray to read into.
            
        Returns:
            Number of bytes read.
        """
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n
    
    def read1(self, size: int = -1) -> bytes:
        """
        Read up to size bytes with at most one read() call to the underlying stream.
        
        For most implementations, this is the same as read(). Subclasses may override
        for optimization.
        
        Args:
            size: Number of bytes to read. -1 means read all available.
            
        Returns:
            Bytes read from the stream.
        """
        return self.read(size)
    
    # ==================== Locator Interface ====================
    
    @abstractmethod
    def to_locator(self) -> Dict[str, Any]:
        """
        Serialize contents to a locator dictionary.
        
        The locator contains:
        - location: The storage backend type
        - Additional backend-specific parameters
        
        Returns:
            Dictionary describing how to locate/access this content.
        """
        pass
    
    @staticmethod
    def from_locator(locator: Optional[Dict[str, Any]], client=None) -> Optional['Contents']:
        """
        Deserialize contents from a locator dictionary.
        
        Factory method that creates the appropriate Contents subclass based on the
        locator's "location" field. This replaces the old base64.b64decode logic in NiFi.
        
        Args:
            locator: Locator dictionary (e.g., from request.contents_pointer)
            client: Optional Octostar client for remote operations
            
        Returns:
            Contents instance or None if locator is None/empty.
            
        Raises:
            ValueError: If the location type is unknown
        """
        if not locator:
            return None
        
        location = locator.get("location")
        
        match location:
            case ContentsLocation.MEMORY.value:
                return MemoryContents._from_locator(locator)
            case ContentsLocation.WORKSPACE_ATTACHMENT.value:
                return WorkspaceAttachmentContents._from_locator(locator, client)
            case ContentsLocation.TEMPORARY_ATTACHMENT.value:
                return TemporaryAttachmentContents._from_locator(locator, client)
            case ContentsLocation.REFERENCE.value:
                return ReferenceContents._from_locator(locator, client)
            case _:
                raise ValueError(f"Unknown contents location type: {location}")
    
    # ==================== Utility Methods ====================
    
    def read_all(self) -> bytes:
        """Read all contents and return as bytes."""
        current_pos = self.tell()
        self.seek(0, SEEK_SET)
        data = self.read()
        self.seek(current_pos, SEEK_SET)
        return data
    
    def getvalue(self) -> bytes:
        """
        Return the entire contents without moving the position.
        
        This matches BytesIO.getvalue() behavior.
        
        Returns:
            Entire contents as bytes.
        """
        return self.read_all()
    
    def write_all(self, data: bytes):
        """Write all data, replacing existing contents."""
        self.seek(0, SEEK_SET)
        self.truncate(0)
        self.write(data)
        self.flush()
    
    def __bool__(self) -> bool:
        return True

    def __len__(self) -> int:
        """
        Return the length of the contents.
        
        Returns:
            Total size in bytes.
        """
        current_pos = self.tell()
        self.seek(0, SEEK_END)
        length = self.tell()
        self.seek(current_pos, SEEK_SET)
        return length


class MemoryContents(Contents):
    """In-memory contents implementation using BytesIO."""
    
    def __init__(
        self,
        entity_type: Optional[str] = None,
        filetype: Optional[str] = None,
        *,
        initial_data: Optional[bytes] = None,
        **kwargs
    ):
        super().__init__(entity_type, filetype, **kwargs)
        self._buffer = BytesIO(initial_data or b"")
    
    def read(self, size: int = -1) -> bytes:
        return self._buffer.read(size)
    
    def write(self, b: bytes) -> int:
        return self._buffer.write(b)
    
    def seek(self, offset: int, whence: int = SEEK_SET) -> int:
        return self._buffer.seek(offset, whence)
    
    def tell(self) -> int:
        return self._buffer.tell()
    
    def flush(self):
        self._buffer.flush()
    
    def close(self):
        if not self._closed:
            self._buffer.close()
            super().close()
    
    def delete(self):
        """Clear the in-memory buffer."""
        self._buffer = BytesIO(b"")
    
    def truncate(self, size: Optional[int] = None) -> int:
        return self._buffer.truncate(size)
    
    def getvalue(self) -> bytes:
        return self._buffer.getvalue()
    
    def to_locator(self) -> Dict[str, Any]:
        """
        Serialize to locator with base64-encoded data.
        
        Returns:
            {"location": "memory", "data": "<base64>", "entity_type": "...", "filetype": "..."}
        """
        data = self._buffer.getvalue()
        locator = {
            "location": ContentsLocation.MEMORY.value,
            "data": base64.b64encode(data).decode('utf-8') if data else None
        }
        if self._entity_type:
            locator["entity_type"] = self._entity_type
        if self._filetype:
            locator["filetype"] = self._filetype
        return locator
    
    @staticmethod
    def _from_locator(locator: Dict[str, Any]) -> 'MemoryContents':
        """
        Create MemoryContents from a locator dictionary.
        
        Args:
            locator: Locator dictionary with base64-encoded data
            
        Returns:
            New MemoryContents instance
        """
        data = locator.get("data")
        initial_data = base64.b64decode(data) if data else None
        return MemoryContents(
            entity_type=locator.get("entity_type"),
            filetype=locator.get("filetype"),
            initial_data=initial_data
        )


class WorkspaceAttachmentContents(Contents):
    """
    Contents implementation for Octostar workspace attachments.
    
    Uses the SDK's ``read_attachment`` / ``write_attachment`` functions which
    go through the v2 entities API.  No presigned URLs are needed.
    
    - Reads use ``read_attachment.sync()`` with ``byte_range`` for efficient
      partial reads and ``headers_only=True`` for HEAD metadata.
    - Writes are buffered locally and uploaded on ``flush()`` via
      ``write_attachment.sync()``, which does a single multipart POST that
      creates/upserts the entity record *and* stores the attachment.
    - After ``flush()``, the server response (full entity record) is
      available via :attr:`last_flush_result`.
    """
    
    def __init__(
        self,
        entity_type: Optional[str] = None,
        filetype: Optional[str] = None,
        *,
        workspace_id: str,
        entity_id: str,
        client,
        fields: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        super().__init__(entity_type, filetype, **kwargs)
        self._workspace_id = workspace_id
        self._entity_id = entity_id
        self._client = client
        self._fields = fields
        self._buffer: Optional[BytesIO] = None
        self._fully_loaded = False
        self._modified = False
        self._position = 0
        self._size: Optional[int] = None
        self._last_flush_result: Optional[Dict[str, Any]] = None
    
    @property
    def last_flush_result(self) -> Optional[Dict[str, Any]]:
        """Entity record returned by the last flush/write operation."""
        return self._last_flush_result
    
    # ==================== Remote operations via SDK ====================
    
    def _fetch_size(self) -> int:
        """Fetch the remote content size via a HEAD request."""
        if self._size is not None:
            return self._size
        
        try:
            from octostar.utils.workspace import read_attachment
            
            headers = read_attachment.sync(
                os_workspace=self._workspace_id,
                os_entity_uid=self._entity_id,
                headers_only=True,
                client=self._client,
            )
            self._size = int(headers.get('content-length', 0))
        except Exception:
            self._size = 0
        return self._size
    
    def _read_range(self, start: int, end: int) -> bytes:
        """Read a specific byte range from the remote attachment."""
        from octostar.utils.workspace import read_attachment
        
        data = read_attachment.sync(
            os_workspace=self._workspace_id,
            os_entity_uid=self._entity_id,
            decode=False,
            byte_range=(start, end),
            client=self._client,
        )
        return data if isinstance(data, bytes) else data.encode()
    
    def _load_full(self):
        """Load the entire remote attachment into the in-memory buffer."""
        if self._fully_loaded:
            return
        
        try:
            from octostar.utils.workspace import read_attachment
            
            data = read_attachment.sync(
                os_workspace=self._workspace_id,
                os_entity_uid=self._entity_id,
                decode=False,
                client=self._client,
            )
        except Exception:
            # Entity may not have an attachment yet — start with empty buffer
            data = b""
        
        self._buffer = BytesIO(data)
        self._fully_loaded = True
        self._size = len(data)
        self._buffer.seek(self._position, SEEK_SET)
    
    def _upload_data(self, data: bytes):
        """Upload data via the SDK write_attachment (v2 multipart POST)."""
        from octostar.utils.workspace import write_attachment
        
        result = write_attachment.sync(
            os_workspace=self._workspace_id,
            os_entity_uid=self._entity_id,
            entity_type=self._entity_type or "os_file",
            filetype=self._filetype or "application/octet-stream",
            file=data,
            fields=self._fields,
            client=self._client,
        )
        self._last_flush_result = result
    
    # ==================== FileIO Interface ====================
    
    def _ensure_buffer(self) -> BytesIO:
        """Guarantee ``_buffer`` is materialised (lazy-load if needed)."""
        if not self._buffer:
            self._load_full()
        assert self._buffer is not None
        return self._buffer
    
    def read(self, size: int = -1) -> bytes:
        if self._fully_loaded:
            return self._ensure_buffer().read(size)
        
        if size == -1:
            total = self._fetch_size()
            if self._position >= total:
                return b""
            size = total - self._position
        
        if size <= 0:
            return b""
        
        total = self._fetch_size()
        if self._position + size > total:
            size = total - self._position
        if size <= 0:
            return b""
        
        end_byte = self._position + size - 1
        data = self._read_range(self._position, end_byte)
        self._position += len(data)
        return data
    
    def write(self, b: bytes) -> int:
        n = self._ensure_buffer().write(b)
        self._modified = True
        return n
    
    def seek(self, offset: int, whence: int = SEEK_SET) -> int:
        if whence == SEEK_SET:
            new_pos = offset
        elif whence == SEEK_CUR:
            if self._buffer and self._fully_loaded:
                new_pos = self._buffer.tell() + offset
            else:
                new_pos = self._position + offset
        elif whence == SEEK_END:
            new_pos = self._fetch_size() + offset
        else:
            raise ValueError(f"Invalid whence value: {whence}")
        
        if new_pos < 0:
            raise ValueError("Negative seek position")
        
        if self._buffer and self._fully_loaded:
            return self._buffer.seek(new_pos, SEEK_SET)
        
        self._position = new_pos
        return self._position
    
    def tell(self) -> int:
        if self._buffer and self._fully_loaded:
            return self._buffer.tell()
        return self._position
    
    def flush(self):
        """Upload buffer contents to workspace via write_attachment, then invalidate cache."""
        if self._buffer:
            self._buffer.flush()
        
        if not self._modified or not self._buffer:
            return
        
        current_pos = self._buffer.tell()
        self._buffer.seek(0, SEEK_SET)
        data = self._buffer.read()
        self._buffer.seek(current_pos, SEEK_SET)
        
        self._upload_data(data)
        
        self._modified = False
        self._buffer.close()
        self._buffer = None
        self._fully_loaded = False
        self._position = 0
        self._size = None
    
    def close(self):
        if not self._closed:
            if self._modified:
                self.flush()
            if self._buffer:
                self._buffer.close()
            super().close()
    
    def truncate(self, size: Optional[int] = None) -> int:
        if not self._buffer and (size == 0 or (size is None and self._position == 0)):
            self._buffer = BytesIO()
            self._fully_loaded = True
            self._size = 0
            self._position = 0
            self._modified = True
            return 0
        self._modified = True
        return self._ensure_buffer().truncate(size)
    
    def getvalue(self) -> bytes:
        if not self._fully_loaded:
            self._load_full()
        assert self._buffer is not None
        return self._buffer.getvalue()
    
    def delete(self):
        """Delete the entity from the workspace."""
        from octostar.utils.workspace import delete_entity
        
        delete_entity.sync(
            os_entity_uid=self._entity_id,
            client=self._client
        )
    
    # ==================== Locator Interface ====================
    
    def to_locator(self) -> Dict[str, Any]:
        """
        Serialize to locator with workspace and entity ID.
        
        Returns:
            {"location": "workspace_attachment", "pointer": "workspace_id/entity_id", 
             "entity_type": "...", "filetype": "...", "fields": {...}}
        """
        if self._workspace_id and self._entity_id:
            pointer = f"{self._workspace_id}/{self._entity_id}"
        else:
            pointer = None
        
        locator = {
            "location": ContentsLocation.WORKSPACE_ATTACHMENT.value,
            "pointer": pointer
        }
        if self._entity_type:
            locator["entity_type"] = self._entity_type
        if self._filetype:
            locator["filetype"] = self._filetype
        if self._fields:
            locator["fields"] = self._fields
        return locator
    
    @staticmethod
    def _from_locator(locator: Dict[str, Any], client=None) -> 'WorkspaceAttachmentContents':
        """
        Create WorkspaceAttachmentContents from a locator dictionary.
        
        Args:
            locator: Locator dictionary with pointer "workspace_id/entity_id"
            client: Octostar client for remote operations
            
        Returns:
            New WorkspaceAttachmentContents instance
            
        Raises:
            ValueError: If the pointer is missing or malformed
        """
        pointer = locator.get("pointer")
        if not pointer or "/" not in pointer:
            raise ValueError(
                f"WorkspaceAttachmentContents locator requires a 'pointer' in 'workspace_id/entity_id' format, got: {pointer!r}"
            )
        
        parts = pointer.split("/")
        workspace_id = parts[0]
        entity_id = parts[-1]
        
        return WorkspaceAttachmentContents(
            entity_type=locator.get("entity_type"),
            filetype=locator.get("filetype"),
            workspace_id=workspace_id,
            entity_id=entity_id,
            client=client,
            fields=locator.get("fields"),
        )


class TemporaryAttachmentContents(Contents):
    """
    Contents implementation for Octostar temporary blob storage.
    
    Uses the SDK's ``read_temporary_blob`` / ``write_temporary_blob`` /
    ``delete_temporary_blob`` functions which handle presigned URLs internally.
    
    - Reads use ``read_temporary_blob.sync()`` with ``byte_range`` for efficient
      partial reads and ``headers_only=True`` for HEAD metadata.
    - Writes are buffered locally and uploaded on ``flush()`` via
      ``write_temporary_blob.sync()``.
    
    Temporary blobs are keyed by filename (not workspace/entity), and are not
    associated with any workspace entity. Use WorkspaceAttachmentContents for that.
    """
    
    def __init__(
        self,
        entity_type: Optional[str] = None,
        filetype: Optional[str] = None,
        *,
        filename: str,
        client,
        **kwargs
    ):
        super().__init__(entity_type, filetype, **kwargs)
        self._filename = filename
        self._client = client
        self._buffer: Optional[BytesIO] = None
        self._fully_loaded = False
        self._modified = False
        self._position = 0
        self._size: Optional[int] = None
    
    # ==================== Remote operations via SDK ====================
    
    def _fetch_size(self) -> int:
        """Fetch the remote content size via a HEAD request."""
        if self._size is not None:
            return self._size
        
        try:
            from octostar.utils.workspace import read_temporary_blob
            
            headers = read_temporary_blob.sync(
                filename=self._filename,
                headers_only=True,
                client=self._client,
            )
            self._size = int(headers.get('content-length', 0))
        except Exception:
            self._size = 0
        return self._size
    
    def _read_range(self, start: int, end: int) -> bytes:
        """Read a specific byte range from the remote blob."""
        from octostar.utils.workspace import read_temporary_blob
        
        data = read_temporary_blob.sync(
            filename=self._filename,
            decode=False,
            byte_range=(start, end),
            client=self._client,
        )
        return data if isinstance(data, bytes) else data.encode()
    
    def _load_full(self):
        """Load the entire remote blob into the in-memory buffer."""
        if self._fully_loaded:
            return
        
        try:
            from octostar.utils.workspace import read_temporary_blob
            
            data = read_temporary_blob.sync(
                filename=self._filename,
                decode=False,
                client=self._client,
            )
        except Exception:
            # Blob may not exist yet — start with empty buffer
            data = b""
        
        self._buffer = BytesIO(data)
        self._fully_loaded = True
        self._size = len(data)
        self._buffer.seek(self._position, SEEK_SET)
    
    def _upload_data(self, data: bytes):
        """Upload data via the SDK write_temporary_blob."""
        from octostar.utils.workspace import write_temporary_blob
        
        write_temporary_blob.sync(
            filename=self._filename,
            file=data,
            client=self._client,
        )
    
    # ==================== FileIO Interface ====================
    
    def _ensure_buffer(self) -> BytesIO:
        """Guarantee ``_buffer`` is materialised (lazy-load if needed)."""
        if not self._buffer:
            self._load_full()
        assert self._buffer is not None
        return self._buffer
    
    def read(self, size: int = -1) -> bytes:
        if self._fully_loaded:
            return self._ensure_buffer().read(size)
        
        if size == -1:
            total = self._fetch_size()
            if self._position >= total:
                return b""
            size = total - self._position
        
        if size <= 0:
            return b""
        
        total = self._fetch_size()
        if self._position + size > total:
            size = total - self._position
        if size <= 0:
            return b""
        
        end_byte = self._position + size - 1
        data = self._read_range(self._position, end_byte)
        self._position += len(data)
        return data
    
    def write(self, b: bytes) -> int:
        n = self._ensure_buffer().write(b)
        self._modified = True
        return n
    
    def seek(self, offset: int, whence: int = SEEK_SET) -> int:
        if whence == SEEK_SET:
            new_pos = offset
        elif whence == SEEK_CUR:
            if self._buffer and self._fully_loaded:
                new_pos = self._buffer.tell() + offset
            else:
                new_pos = self._position + offset
        elif whence == SEEK_END:
            new_pos = self._fetch_size() + offset
        else:
            raise ValueError(f"Invalid whence value: {whence}")
        
        if new_pos < 0:
            raise ValueError("Negative seek position")
        
        if self._buffer and self._fully_loaded:
            return self._buffer.seek(new_pos, SEEK_SET)
        
        self._position = new_pos
        return self._position
    
    def tell(self) -> int:
        if self._buffer and self._fully_loaded:
            return self._buffer.tell()
        return self._position
    
    def flush(self):
        """Upload buffer to temporary storage, then invalidate cache."""
        if self._buffer:
            self._buffer.flush()
        
        if not self._modified or not self._buffer:
            return
        
        current_pos = self._buffer.tell()
        self._buffer.seek(0, SEEK_SET)
        data = self._buffer.read()
        self._buffer.seek(current_pos, SEEK_SET)
        
        self._upload_data(data)
        
        self._modified = False
        self._buffer.close()
        self._buffer = None
        self._fully_loaded = False
        self._position = 0
        self._size = None
    
    def close(self):
        if not self._closed:
            if self._modified:
                self.flush()
            if self._buffer:
                self._buffer.close()
            super().close()
    
    def truncate(self, size: Optional[int] = None) -> int:
        if not self._buffer and (size == 0 or (size is None and self._position == 0)):
            self._buffer = BytesIO()
            self._fully_loaded = True
            self._size = 0
            self._position = 0
            self._modified = True
            return 0
        self._modified = True
        return self._ensure_buffer().truncate(size)
    
    def getvalue(self) -> bytes:
        if not self._fully_loaded:
            self._load_full()
        assert self._buffer is not None
        return self._buffer.getvalue()
    
    def delete(self):
        """Delete the blob from the temporary bucket."""
        from octostar.utils.workspace import delete_temporary_blob
        
        delete_temporary_blob.sync(
            filename=self._filename,
            client=self._client
        )
    
    # ==================== Locator Interface ====================
    
    def to_locator(self) -> Dict[str, Any]:
        """
        Serialize to locator with filename.
        
        Returns:
            {"location": "temporary_attachment", "filename": "..."}
        """
        locator = {
            "location": ContentsLocation.TEMPORARY_ATTACHMENT.value,
            "filename": self._filename
        }
        if self._entity_type:
            locator["entity_type"] = self._entity_type
        if self._filetype:
            locator["filetype"] = self._filetype
        return locator
    
    @staticmethod
    def _from_locator(locator: Dict[str, Any], client=None) -> 'TemporaryAttachmentContents':
        """
        Create TemporaryAttachmentContents from a locator dictionary.
        
        Args:
            locator: Locator dictionary with filename
            client: Octostar client
            
        Returns:
            New TemporaryAttachmentContents instance
        """
        return TemporaryAttachmentContents(
            entity_type=locator.get("entity_type"),
            filetype=locator.get("filetype"),
            filename=locator["filename"],
            client=client
        )


class ReferenceContents(Contents):
    """
    Contents that delegates reads to one source and writes to another.

    Useful for fragments that share their parent's attachment but need their
    own write target for content syncing.  When the sync system calls
    ``read()``, the data is read from ``read_source``. On ``write()``, the data is written to ``write_target``.

    ``read_source`` is **not owned** by this instance — it will not be closed
    or deleted, since it may be shared across multiple fragments.
    """

    def __init__(
        self,
        entity_type: Optional[str] = None,
        filetype: Optional[str] = None,
        *,
        read_source: Optional[Contents] = None,
        write_target: Optional[Contents] = None,
        **kwargs
    ):
        super().__init__(entity_type, filetype, **kwargs)
        self._read_source = read_source
        self._write_target = write_target

    # ==================== FileIO Interface ====================

    def __len__(self):
        if self._read_source:
            return len(self._read_source)
        return 0

    def read(self, size: int = -1) -> bytes:
        if self._read_source:
            return self._read_source.read(size)
        return b""

    def write(self, b: bytes) -> int:
        if self._write_target:
            return self._write_target.write(b)
        raise IOError("ReferenceContents has no write_target configured")

    def seek(self, offset: int, whence: int = SEEK_SET) -> int:
        if self._read_source:
            return self._read_source.seek(offset, whence)
        return 0

    def tell(self) -> int:
        if self._read_source:
            return self._read_source.tell()
        return 0

    def flush(self):
        if self._write_target:
            self._write_target.flush()

    def close(self):
        if not self._closed:
            if self._write_target:
                self._write_target.close()
            super().close()

    def delete(self):
        if self._write_target:
            self._write_target.delete()

    def truncate(self, size: Optional[int] = None) -> int:
        if self._write_target:
            return self._write_target.truncate(size)
        return 0

    def getvalue(self) -> bytes:
        if self._read_source:
            return self._read_source.getvalue()
        return b""

    # ==================== Locator Interface ====================

    def to_locator(self) -> Dict[str, Any]:
        locator: Dict[str, Any] = {
            "location": ContentsLocation.REFERENCE.value,
            "read_source": self._read_source.to_locator() if self._read_source else None,
            "write_target": self._write_target.to_locator() if self._write_target else None,
        }
        if self._entity_type:
            locator["entity_type"] = self._entity_type
        if self._filetype:
            locator["filetype"] = self._filetype
        return locator

    @staticmethod
    def _from_locator(locator: Dict[str, Any], client=None) -> 'ReferenceContents':
        read_source = Contents.from_locator(locator.get("read_source"), client)
        write_target = Contents.from_locator(locator.get("write_target"), client)
        return ReferenceContents(
            entity_type=locator.get("entity_type"),
            filetype=locator.get("filetype"),
            read_source=read_source,
            write_target=write_target,
        )
