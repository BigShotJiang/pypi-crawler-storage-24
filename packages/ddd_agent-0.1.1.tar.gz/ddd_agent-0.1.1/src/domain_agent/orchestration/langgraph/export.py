"""Workflow graph export helpers."""

from __future__ import annotations

from pathlib import Path
from typing import cast

from domain_agent.adapters.outbound.in_memory import (
    RecordingActionExecutor,
    StaticAgentEngine,
    StaticContextProvider,
)
from domain_agent.application.ports import WorkflowDependencies
from domain_agent.orchestration.langgraph.graph import build_workflow


def build_default_workflow_dependencies() -> WorkflowDependencies:
    """Create generic in-memory dependencies for graph export."""
    return WorkflowDependencies(
        context_provider=StaticContextProvider(),
        agent_engine=StaticAgentEngine(),
        action_executor=RecordingActionExecutor(),
    )


def export_workflow_mermaid(
    dependencies: WorkflowDependencies | None = None,
) -> str:
    """Return the workflow graph as Mermaid text."""
    workflow = build_workflow(dependencies or build_default_workflow_dependencies())
    return cast(str, workflow.get_graph().draw_mermaid())


def write_workflow_mermaid(output_path: str | Path) -> Path:
    """Write Mermaid text for the generic workflow graph to a file."""
    path = Path(output_path)
    path.write_text(export_workflow_mermaid(), encoding="utf-8")
    return path
