"""LangGraph orchestration assembly for the generic agent template."""

from __future__ import annotations

from typing import Any

from langgraph.graph import END, START, StateGraph

from domain_agent.application.ports import WorkflowDependencies
from domain_agent.orchestration.langgraph.nodes import (
    DeterministicNodes,
    LLMNodes,
    route_after_review,
)
from domain_agent.orchestration.langgraph.state import WorkflowState


def build_workflow(
    dependencies: WorkflowDependencies,
    *,
    checkpointer: Any | None = None,
) -> Any:
    """Build the default agent workflow graph."""
    deterministic_nodes = DeterministicNodes(dependencies)
    llm_nodes = LLMNodes(dependencies)

    graph = StateGraph(WorkflowState)
    graph.add_node("validate_request", deterministic_nodes.validate_request)
    graph.add_node("collect_context", deterministic_nodes.collect_context)
    graph.add_node("prepare_agent_work", llm_nodes.prepare_agent_work)
    graph.add_node("resolve_review", deterministic_nodes.resolve_review)
    graph.add_node("execute_action", deterministic_nodes.execute_action)
    graph.add_node("close_request", deterministic_nodes.close_request)

    graph.add_edge(START, "validate_request")
    graph.add_edge("validate_request", "collect_context")
    graph.add_edge("collect_context", "prepare_agent_work")
    graph.add_edge("prepare_agent_work", "resolve_review")
    graph.add_conditional_edges(
        "resolve_review",
        route_after_review,
        {
            "execute_action": "execute_action",
            "close_request": "close_request",
        },
    )
    graph.add_edge("execute_action", "close_request")
    graph.add_edge("close_request", END)

    return graph.compile(checkpointer=checkpointer)
