from __future__ import annotations

from datetime import datetime
from typing import Annotated, Literal

from model_lib import Entity
from pydantic import Field
from zero_3rdparty.enum_utils import StrEnum

from pkg_ext._internal.models.py_symbols import SymbolType


class ParamKind(StrEnum):
    POSITIONAL_ONLY = "positional_only"
    POSITIONAL_OR_KEYWORD = "positional_or_keyword"
    VAR_POSITIONAL = "var_positional"
    KEYWORD_ONLY = "keyword_only"
    VAR_KEYWORD = "var_keyword"


class ParamDefault(Entity):
    value_repr: str
    is_factory: bool = False


class FuncParamInfo(Entity):
    name: str
    kind: ParamKind
    type_annotation: str | None = None
    type_imports: list[str] = Field(default_factory=list)  # Full import paths, e.g., ["pathlib.Path"]
    default: ParamDefault | None = None


class CallableSignature(Entity):
    parameters: list[FuncParamInfo] = Field(default_factory=list)
    return_annotation: str | None = None
    return_type_imports: list[str] = Field(default_factory=list)


class ClassFieldInfo(Entity):
    name: str
    type_annotation: str | None = None
    type_imports: list[str] = Field(default_factory=list)  # Full import paths, e.g., ["pathlib.Path"]
    default: ParamDefault | None = None
    is_class_var: bool = False
    is_computed: bool = False
    description: str | None = None
    deprecated: str | None = None
    env_vars: list[str] | None = None


class SymbolDumpBase(Entity):
    name: str
    module_path: str
    docstring: str = ""
    line_number: int | None = None


class FunctionDump(SymbolDumpBase):
    type: Literal[SymbolType.FUNCTION] = SymbolType.FUNCTION
    signature: CallableSignature


class CLIParamInfo(Entity):
    """CLI parameter metadata from typer OptionInfo/ArgumentInfo."""

    param_name: str
    type_annotation: str | None = None
    flags: list[str] = Field(default_factory=list)
    help: str | None = None
    default_repr: str | None = None
    required: bool = False
    envvar: str | None = None
    is_argument: bool = False
    hidden: bool = False
    choices: list[str] | None = None


class CLICommandDump(SymbolDumpBase):
    """A typer CLI command with rich parameter metadata."""

    type: Literal[SymbolType.CLI_COMMAND] = SymbolType.CLI_COMMAND
    signature: CallableSignature
    cli_params: list[CLIParamInfo] = Field(default_factory=list)


class ClassDump(SymbolDumpBase):
    type: Literal[SymbolType.CLASS] = SymbolType.CLASS
    mro_bases: list[str] = Field(default_factory=list)
    num_direct_bases: int = 0
    init_signature: CallableSignature | None = None
    fields: list[ClassFieldInfo] | None = None

    @property
    def direct_bases(self) -> list[str]:
        return self.mro_bases[: self.num_direct_bases]


class ExceptionDump(SymbolDumpBase):
    type: Literal[SymbolType.EXCEPTION] = SymbolType.EXCEPTION
    mro_bases: list[str] = Field(default_factory=list)
    num_direct_bases: int = 0
    init_signature: CallableSignature | None = None

    @property
    def direct_bases(self) -> list[str]:
        return self.mro_bases[: self.num_direct_bases]


class TypeAliasDump(SymbolDumpBase):
    type: Literal[SymbolType.TYPE_ALIAS] = SymbolType.TYPE_ALIAS
    alias_target: str


class GlobalVarDump(SymbolDumpBase):
    type: Literal[SymbolType.GLOBAL_VAR] = SymbolType.GLOBAL_VAR
    annotation: str | None = None
    value_repr: str | None = None


SymbolDump = Annotated[
    FunctionDump | CLICommandDump | ClassDump | ExceptionDump | TypeAliasDump | GlobalVarDump,
    Field(discriminator="type"),
]


class GroupDump(Entity):
    name: str
    symbols: list[SymbolDump] = Field(default_factory=list)

    def filter_symbols(self, include_names: set[str]) -> GroupDump | None:
        filtered = [s for s in self.symbols if s.name in include_names]
        if not filtered:
            return None
        return GroupDump(name=self.name, symbols=filtered)


class PublicApiDump(Entity):
    pkg_import_name: str
    version: str
    groups: list[GroupDump] = Field(default_factory=list)
    dumped_at: datetime

    def get_group(self, name: str) -> GroupDump:
        for g in self.groups:
            if g.name == name:
                return g
        raise ValueError(f"Group not found: {name}")
