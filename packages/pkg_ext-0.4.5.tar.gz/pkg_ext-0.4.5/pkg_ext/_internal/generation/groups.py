from pathlib import Path

from pkg_ext._internal.config import Stability
from pkg_ext._internal.context import pkg_ctx
from pkg_ext._internal.models import (
    PkgCodeState,
    PublicGroup,
    SymbolRefId,
    ref_id_module,
    ref_id_name,
)
from pkg_ext._internal.pkg_state import PkgExtState
from pkg_ext._internal.settings import PkgSettings


def as_import_line(pkg_name: str, ref: SymbolRefId, *, skip_as_alias_underscore: bool = False) -> str:
    if skip_as_alias_underscore:
        return f"from {pkg_name}.{ref_id_module(ref)} import {ref_id_name(ref)}"

    return f"from {pkg_name}.{ref_id_module(ref)} import {ref_id_name(ref)} as _{ref_id_name(ref)}"


def write_imports(code: PkgCodeState, refs: list[SymbolRefId]) -> list[str]:
    return [as_import_line(code.pkg_import_name, ref) for ref in code.sort_refs(refs)]


def _stability_decorator_info(group: PublicGroup, pkg_name: str, tool_state: PkgExtState) -> tuple[str, str]:
    """Returns (import_line, decorator_call) for stability wrapping."""
    stability = tool_state.get_group_stability(group.name)
    match stability:
        case Stability.experimental:
            return f"from {pkg_name}._warnings import _experimental", "_experimental"
        case Stability.deprecated:
            replacement = tool_state.get_deprecation_replacement(group.name)
            reason = replacement.replace('"', '\\"') if replacement else "deprecated"
            return "from warnings import deprecated", f'deprecated("{reason}")'
    return "", ""


def write_group(
    group: PublicGroup,
    settings: PkgSettings,
    code: PkgCodeState,
    tool_state: PkgExtState,
) -> Path:
    path = settings.pkg_directory / f"{group.name}.py"
    pkg_name = code.pkg_import_name
    imports = [as_import_line(pkg_name, ref) for ref in group.sorted_refs]
    decorator_import, decorator_call = _stability_decorator_info(group, pkg_name, tool_state)

    if decorator_call:
        exposed_vars = [f"{ref_id_name(ref)} = {decorator_call}(_{ref_id_name(ref)})" for ref in group.sorted_refs]
    else:
        exposed_vars = [f"{ref_id_name(ref)} = _{ref_id_name(ref)}" for ref in group.sorted_refs]

    lines = [settings.file_header, *imports]
    if decorator_import:
        lines.append(decorator_import)
    lines.extend(["", *exposed_vars, ""])

    path.write_text("\n".join(lines))
    return path


def write_groups(ctx: pkg_ctx) -> list[Path]:
    return [
        write_group(group, ctx.settings, ctx.code_state, ctx.tool_state)
        for group in ctx.tool_state.groups.groups_no_root
    ]
