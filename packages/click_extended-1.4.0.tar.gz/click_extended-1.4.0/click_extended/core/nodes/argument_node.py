"""ArgumentNode abstract base class for CLI argument nodes."""

# pylint: disable=too-many-arguments
# pylint: disable=too-many-positional-arguments
# pylint: disable=redefined-builtin
# pylint: disable=arguments-differ
# pylint: disable=line-too-long

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Callable, ParamSpec, Sequence, Type, TypeVar

from click_extended.core.nodes.parent_node import ParentNode

if TYPE_CHECKING:
    from click_extended.core.other.context import Context

P = ParamSpec("P")
T = TypeVar("T")


class ArgumentNode(ParentNode, ABC):
    """
    Abstract base class for nodes that receive CLI argument values.

    ArgumentNode extends ParentNode to handle command-line arguments.
    The key difference is that the `load()` method receives a `value`
    parameter containing the parsed CLI argument value.
    """

    def __init__(
        self,
        name: str,
        param: str | None = None,
        nargs: int = 1,
        type: Type[Any] | None = None,
        help: str | None = None,
        required: bool = True,
        default: Any = None,
        tags: str | list[str] | None = None,
        choices: Sequence[str | int | float] | None = None,
        case_sensitive: bool = True,
        **kwargs: Any,
    ):
        r"""
        Initialize a new ``ArgumentNode`` instance.

        :param name: The argument name (parameter name for injection).
        :param param: Custom parameter name for the function.
            If not provided, uses ``name``.
        :param nargs: Number of arguments to accept. Use ``-1`` for unlimited.
            Defaults to ``1``.
        :param type: The type to convert the value to (``int``, ``str``, ``float``, ``bool``).
        :param help: Help text for this argument.
        :param required: Whether this argument is required. Defaults to ``True``.
        :param default: Default value if not provided. Defaults to ``None``.
        :param tags: Tag(s) to associate with this argument for grouping.
        :param \*\*kwargs: Additional keyword arguments passed to parent class.
        """
        super().__init__(
            name=param if param is not None else name,
            param=param,
            help=help,
            required=required,
            default=default,
            tags=tags,
            **kwargs,
        )
        self.nargs = nargs
        self.type = type
        self.choices = tuple(choices) if choices is not None else None
        self.case_sensitive = case_sensitive

    @abstractmethod
    def load(
        self,
        value: str | int | float | bool | None,
        context: "Context",
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        r"""
        Load and process the CLI argument value.

        This method is called with the parsed CLI argument value and should
        return the processed value to be injected into the function.

        :param value: The parsed CLI argument value from Click.
        :param context: The current context instance.
        :param \*args: Optional positional arguments.
        :param \*\*kwargs: Optional keyword arguments.

        :returns: The processed value to inject into the function.
        """
        raise NotImplementedError

    @classmethod
    def as_decorator(
        cls,
        *,
        name: str,
        param: str | None = None,
        nargs: int = 1,
        type: Type[Any] | None = None,
        help: str | None = None,
        required: bool = True,
        default: Any = None,
        tags: str | list[str] | None = None,
        choices: Sequence[str | int | float] | None = None,
        case_sensitive: bool = True,
        **kwargs: Any,
    ) -> Callable[[Callable[P, T]], Callable[P, T]]:
        r"""
        Return a decorator representation of the argument node.

        :param name: The argument name (parameter name for injection).
        :param param: Custom parameter name for the function.
            If not provided, uses ``name``.
        :param nargs: Number of arguments to accept. Use ``-1`` for unlimited.
            Defaults to ``1``.
        :param type: The type to convert the value to (``int``, ``str``, ``float``, ``bool``).
        :param help: Help text for this argument.
        :param required: Whether this argument is required. Defaults to ``True``.
        :param default: Default value if not provided. Defaults to ``None``.
        :param tags: Tag(s) to associate with this argument for grouping.
        :param \*\*kwargs: Additional keyword arguments passed to __init__ and load().

        :returns: A decorator function that registers the argument node.
        :rtype: Callable
        """
        return super().as_decorator(
            name=name,
            param=param,
            nargs=nargs,
            type=type,
            help=help,
            required=required,
            default=default,
            tags=tags,
            choices=choices,
            case_sensitive=case_sensitive,
            **kwargs,
        )


__all__ = ["ArgumentNode"]
