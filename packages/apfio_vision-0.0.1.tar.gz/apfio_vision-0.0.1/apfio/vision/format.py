# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


from enum import Enum


class ImageFormat(Enum):
    """
    Enumerates image file formats supported by :py:mod:`apfio.vision`.
    """
    AVIF = 0 # Best AVIF implementation available.
    JPEG = 1 # Best JPEG implementation available.
    PNG = 2 # Best PNG implementation available.
    _ignore_ = ('__ext', '__identifier')
    __ext = [".avif", ".jpg", ".png"]
    __identifier = ['AVIF', 'JPEG', 'PNG']

    @property
    def extension(self):
        """
        The file name extension used for this format.

        :return: A string starting with a dot.
        """
        return ImageFormat.__ext[self.value]

    @property
    def identifier(self):
        """
        The identifier string for serializing this format.

        :return: A str.
        """
        return ImageFormat.__identifier[self.value]

    @staticmethod
    def from_ext(ext):
        """
        Turns a file name extension into an :py:class:`~apfio.vision.format.ImageFormat` object.

        :param ext: The filename extension to find the :py:class:`~apfio.vision.format.ImageFormat` for. Should include a leading dot.

        :raises ValueError: If the given filename extension was not assigned a definitive :py:class:`~apfio.vision.format.ImageFormat`.

        :return: An :py:class:`~apfio.vision.format.ImageFormat` object.
        """
        try:
            return ImageFormat(ImageFormat.__ext.index(ext))
        except IndexError:
            raise ValueError(f"apfio.vision does not support any image format for the filename extension '{ext}'!")