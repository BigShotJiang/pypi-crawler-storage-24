"""Official Python SDK for RendShot — HTML-to-image rendering and URL screenshots."""

from rendshot.client import RendshotClient, AsyncRendshotClient
from rendshot.errors import RendshotError
from rendshot.types import (
    RenderImageOptions,
    ScreenshotUrlOptions,
    ImageResult,
    ImageMetadata,
    UsageResult,
)
from rendshot._version import __version__

__all__ = [
    "RendshotClient",
    "AsyncRendshotClient",
    "RendshotError",
    "RenderImageOptions",
    "ScreenshotUrlOptions",
    "ImageResult",
    "ImageMetadata",
    "UsageResult",
    "__version__",
]
