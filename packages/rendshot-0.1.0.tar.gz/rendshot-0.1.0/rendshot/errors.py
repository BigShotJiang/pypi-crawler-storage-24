"""Error types for the RendShot SDK."""

from __future__ import annotations


class RendshotError(Exception):
    """Error returned by the RendShot API."""

    def __init__(self, code: str, message: str, status: int) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status

    def __repr__(self) -> str:
        return f"RendshotError(code={self.code!r}, status={self.status}, message={self.message!r})"
