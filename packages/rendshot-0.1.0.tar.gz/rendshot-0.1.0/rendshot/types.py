"""Type definitions for the RendShot SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass
class RenderImageOptions:
    """Options for rendering HTML to an image."""

    html: str
    css: str | None = None
    width: int | None = None
    height: int | None = None
    format: Literal["png", "jpg"] | None = None
    quality: int | None = None
    device_scale: Literal[1, 2, 3] | None = None
    fonts: list[str] | None = None
    timeout: int | None = None

    def to_dict(self) -> dict:
        d: dict = {"html": self.html}
        if self.css is not None:
            d["css"] = self.css
        if self.width is not None:
            d["width"] = self.width
        if self.height is not None:
            d["height"] = self.height
        if self.format is not None:
            d["format"] = self.format
        if self.quality is not None:
            d["quality"] = self.quality
        if self.device_scale is not None:
            d["deviceScale"] = self.device_scale
        if self.fonts is not None:
            d["fonts"] = self.fonts
        if self.timeout is not None:
            d["timeout"] = self.timeout
        return d


@dataclass
class ScreenshotUrlOptions:
    """Options for taking a URL screenshot."""

    url: str
    width: int | None = None
    height: int | None = None
    format: Literal["png", "jpg"] | None = None
    quality: int | None = None
    full_page: bool | None = None
    device_scale: Literal[1, 2, 3] | None = None
    timeout: int | None = None

    def to_dict(self) -> dict:
        d: dict = {"url": self.url}
        if self.width is not None:
            d["width"] = self.width
        if self.height is not None:
            d["height"] = self.height
        if self.format is not None:
            d["format"] = self.format
        if self.quality is not None:
            d["quality"] = self.quality
        if self.full_page is not None:
            d["fullPage"] = self.full_page
        if self.device_scale is not None:
            d["deviceScale"] = self.device_scale
        if self.timeout is not None:
            d["timeout"] = self.timeout
        return d


@dataclass
class ImageResult:
    """Result from a render or screenshot operation."""

    image_id: str
    url: str
    width: int
    height: int
    format: str
    size: int
    created_at: str

    @classmethod
    def from_dict(cls, data: dict) -> "ImageResult":
        return cls(
            image_id=data["imageId"],
            url=data["url"],
            width=data["width"],
            height=data["height"],
            format=data["format"],
            size=data["size"],
            created_at=data["createdAt"],
        )


@dataclass
class ImageMetadata(ImageResult):
    """Image metadata including expiration."""

    expires_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "ImageMetadata":
        return cls(
            image_id=data["imageId"],
            url=data["url"],
            width=data["width"],
            height=data["height"],
            format=data["format"],
            size=data["size"],
            created_at=data["createdAt"],
            expires_at=data.get("expiresAt"),
        )


@dataclass
class UsageResult:
    """Current usage information."""

    month: str
    count: int
    limit: int
    plan: str

    @classmethod
    def from_dict(cls, data: dict) -> "UsageResult":
        return cls(
            month=data["month"],
            count=data["count"],
            limit=data["limit"],
            plan=data["plan"],
        )
