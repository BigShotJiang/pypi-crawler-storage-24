# Development Guide

This document covers how to set up a local development environment, build, and publish the `fusion-ai-sdk` package to PyPI.

## Setup

Install all dependencies (including dev tools) using `uv`:

```bash
uv sync --dev
```

---

## Running Examples

The `examples/` directory contains runnable scripts that demonstrate how to use the SDK. These are intended for local development and testing — they make real API calls.

### Available examples

| Script | What it demonstrates |
|--------|---------------------|
| `examples/basic_chat.py` | Simple LLM call across providers |
| `examples/structured_output.py` | Pydantic structured response schema |
| `examples/tool_calling.py` | Tool / function calling with `ToolExecutor` |
| `examples/reasoning.py` | Reasoning/thinking models |
| `examples/multimodal.py` | Vision / image inputs |

### Setup

Copy `.env.example` to `.env` and fill in your actual API keys if .env is not already created in the project root:

```bash
cp .env.example .env
```

Then open `.env` and replace the placeholder values with your real keys. For Ollama, no API key is needed — just make sure your local server is running (`ollama serve`) and update `host_url` in the env file.

### Run an example

```bash
uv run python examples/basic_chat.py
uv run python examples/structured_output.py
uv run python examples/tool_calling.py
uv run python examples/reasoning.py
uv run python examples/multimodal.py
```

Each script has commented-out blocks at the top for switching between providers — just uncomment the block you want to test.


## Releasing to PyPI

Follow these steps in order every time you want to publish a new version.

### Step 1 — Bump the version

Update the `version` field in `pyproject.toml`:

```toml
[project]
version = "1.0.2"  # follow semver: patch for fixes/docs, minor for features, major for breaking changes
```

### Step 2 — Sync dependencies

```bash
uv sync --dev
```

### Step 3 — Commit and push to Git

```bash
git add .
git commit -m "chore: bump version to 1.0.2"
git push origin main
```

### Step 4 — Tag the release

```bash
git tag -a v1.0.2 -m "Release v1.0.2"
git push origin v1.0.2
```

### Step 5 — Build the package

Clean any old build artifacts first, then build fresh:

```bash
rm -rf dist/
uv build
```

### Step 5 — (Optional) Validate on TestPyPI first

Before publishing to the real index you can do a dry-run on TestPyPI:

```bash
uv publish --publish-url https://test.pypi.org/legacy/
```

### Step 6 — Publish to PyPI

```bash
uv publish
```

You will be prompted for your **PyPI API token**. Generate one at [pypi.org/manage/account/token](https://pypi.org/manage/account/token/).
