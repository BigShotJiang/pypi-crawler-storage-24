"""
Reasoning & Thinking Example
=============================
Demonstrates how to enable reasoning/thinking across different providers.
Each provider maps `reasoning_effort` to its own native API internally.

Supported models:
  - OpenAI:  o1, o3, o4-mini, gpt-5
  - Gemini:  gemini-2.5-flash, gemini-2.5-pro
  - Ollama:  deepseek-r1, qwen2.5, qwq, llama3.1 (70B+)

Usage:
    python examples/reasoning.py
"""

from fusion_ai_sdk.llm_sdk import LLMInvoker
from dotenv import load_dotenv

load_dotenv()

QUESTION = "Prove that there are infinitely many prime numbers."


def main():
    invoker = LLMInvoker()

    # --- OpenAI reasoning model ---
    # Note: temperature is NOT supported for o-series models
    llm_input = LLMInvoker.ChatCompletionInput(
        provider="openai",
        model_name="o4-mini",
        messages=[{"role": "user", "content": QUESTION}],
        reasoning_effort="medium",  # "low" | "medium" | "high"
    )

    # --- Gemini thinking model ---
    # reasoning_summary returns the thinking trace in response.reasoning_summary
    # llm_input = LLMInvoker.ChatCompletionInput(
    #     provider="gemini",
    #     model_name="gemini-2.5-flash",
    #     messages=[{"role": "user", "content": QUESTION}],
    #     reasoning_effort="high",
    #     reasoning_summary="concise",    # "concise" | "detailed" | "auto"
    #     # gemini_thinking_budget=8192,  # Optional: explicit token budget (0-24576)
    # )

    # --- Ollama thinking model ---
    # llm_input = LLMInvoker.ChatCompletionInput(
    #     provider="ollama",
    #     host_url="http://localhost:11434",
    #     model_name="deepseek-r1:7b",
    #     messages=[{"role": "user", "content": QUESTION}],
    #     reasoning_effort="high",
    # )

    print(f"Calling {llm_input.provider} / {llm_input.model_name} with reasoning...")
    response = invoker.chat_completion(llm_input)

    if response.success:
        if response.reasoning_summary:
            print(f"\n--- Thinking ---\n{response.reasoning_summary}")
        print(f"\n--- Answer ---\n{response.response}")
        print(f"\nTokens — input: {response.usage.input_tokens}, "
              f"output: {response.usage.output_tokens}, "
              f"reasoning: {response.usage.reasoning_tokens}")
    else:
        print(f"Error: {response.error_message}")


if __name__ == "__main__":
    main()
