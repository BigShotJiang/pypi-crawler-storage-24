"""
Basic Chat Example
==================
Demonstrates a simple LLM call using the Fusion AI SDK.
Swap `provider` and `model_name` to test any of the three providers.

Usage:
    python examples/basic_chat.py
"""

import os
from fusion_ai_sdk.llm_sdk import LLMInvoker
from dotenv import load_dotenv

load_dotenv()


def main():
    invoker = LLMInvoker()

    # --- OpenAI ---
    llm_input = LLMInvoker.ChatCompletionInput(
        provider="openai",
        model_name="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a concise assistant."},
            {"role": "user", "content": "What is the capital of France?"},
        ],
        temperature=0.5,
    )

    # Swap to Gemini:
    # llm_input = LLMInvoker.ChatCompletionInput(
    #     provider="gemini",
    #     model_name="gemini-2.0-flash",
    #     messages=[{"role": "user", "content": "What is the capital of France?"}],
    # )

    # Swap to Ollama:
    # llm_input = LLMInvoker.ChatCompletionInput(
    #     provider="ollama",
    #     host_url="http://localhost:11434",
    #     model_name="llama3.2",
    #     messages=[{"role": "user", "content": "What is the capital of France?"}],
    # )

    print(f"Calling {llm_input.provider} / {llm_input.model_name}...")
    response = invoker.chat_completion(llm_input)

    if response.success:
        print(f"\nResponse: {response.response}")
        print(f"Tokens used: {response.usage.total_tokens}")
        print(f"Latency: {response.timing.latency_ms:.0f}ms")
    else:
        print(f"Error: {response.error_message}")


if __name__ == "__main__":
    main()
