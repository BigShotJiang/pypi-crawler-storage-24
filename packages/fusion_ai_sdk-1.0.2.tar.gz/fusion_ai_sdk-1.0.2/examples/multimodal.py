"""
Multimodal (Vision) Example
============================
Demonstrates passing an image alongside text to a vision-capable model.
Images can be supplied as a local file path, a public URL, or a base64 data URI.

Supported providers:
  - OpenAI: gpt-4o, gpt-4o-mini (vision built-in)
  - Gemini: gemini-2.0-flash, gemini-2.5-flash (vision built-in)
  - Ollama: llama3.2-vision, llava (must use a vision-capable model)

Note for Ollama: remote URLs are not supported — use a local path or base64.

Usage:
    python examples/multimodal.py
"""

from fusion_ai_sdk.llm_sdk import LLMInvoker
from dotenv import load_dotenv

load_dotenv()

# Replace with a real image path or URL
IMAGE_URL = "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/PNG_transparency_demonstration_1.png/280px-PNG_transparency_demonstration_1.png"


def main():
    invoker = LLMInvoker()

    llm_input = LLMInvoker.ChatCompletionInput(
        provider="openai",          # Works with "gemini" too
        model_name="gpt-4o-mini",   # For Ollama, use "llama3.2-vision" or "llava"
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Describe what you see in this image."},
                    {
                        "type": "image_url",
                        "image_url": {
                            # Option 1: Public URL
                            "url": IMAGE_URL,

                            # Option 2: Local file path
                            # "url": "/path/to/your/image.png",

                            # Option 3: Base64 data URI
                            # "url": "data:image/png;base64,iVBORw0KGgo...",
                        },
                    },
                ],
            }
        ],
    )

    print(f"Calling {llm_input.provider} / {llm_input.model_name} with image...")
    response = invoker.chat_completion(llm_input)

    if response.success:
        print(f"\nResponse: {response.response}")
        print(f"Latency: {response.timing.latency_ms:.0f}ms")
    else:
        print(f"Error: {response.error_message}")


if __name__ == "__main__":
    main()
