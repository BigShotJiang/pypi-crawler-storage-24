"""
Tool / Function Calling Example
================================
Demonstrates tool calling using the automatic ToolExecutor loop.
The SDK calls the model, executes the tool, feeds the result back,
and repeats until the model produces a final text answer.

Usage:
    python examples/tool_calling.py
"""

from fusion_ai_sdk.llm_sdk import LLMInvoker
from dotenv import load_dotenv

load_dotenv()


# --- Define your actual Python functions ---

def get_weather(location: str, unit: str = "celsius") -> dict:
    """Simulated weather API. Replace with a real implementation."""
    return {
        "location": location,
        "temperature": 22,
        "unit": unit,
        "condition": "Sunny",
    }


def get_population(city: str) -> dict:
    """Simulated population lookup. Replace with a real implementation."""
    populations = {"paris": 2_161_000, "tokyo": 13_960_000, "new york": 8_336_000}
    return {"city": city, "population": populations.get(city.lower(), "unknown")}


# --- Tool definitions in OpenAI format (compatible with all providers) ---

tools = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get the current weather for a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "City name, e.g. 'Paris'",
                    },
                    "unit": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "description": "Temperature unit. Defaults to celsius.",
                    },
                },
                "required": ["location"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_population",
            "description": "Get the population of a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "City name"},
                },
                "required": ["city"],
            },
        },
    },
]

tools_map = {
    "get_weather": get_weather,
    "get_population": get_population,
}


def main():
    invoker = LLMInvoker()
    executor = LLMInvoker.ToolExecutor(tools_map)

    llm_input = LLMInvoker.ChatCompletionInput(
        provider="openai",          # Works with "gemini" too
        model_name="gpt-4o-mini",   # Use a tool-capable model for Ollama (e.g. llama3.2)
        messages=[
            {
                "role": "user",
                "content": "What's the weather in Paris and what is its population?",
            }
        ],
        tools=tools,
        tool_choice="auto",
    )

    print(f"Calling {llm_input.provider} / {llm_input.model_name}...")
    response = invoker.chat_completion_with_tools(
        input_data=llm_input,
        tool_executor=executor,
        max_iterations=5,
    )

    if response.success:
        print(f"\nResponse: {response.response}")
        print(f"Tokens used: {response.usage.total_tokens}")
        print(f"Latency: {response.timing.latency_ms:.0f}ms")
    else:
        print(f"Error: {response.error_message}")


if __name__ == "__main__":
    main()
