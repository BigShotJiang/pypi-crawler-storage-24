"""
Structured Output Example
=========================
Demonstrates using a Pydantic model as `response_schema` to get
a validated Python object back instead of raw text.

Usage:
    python examples/structured_output.py
"""

from pydantic import BaseModel
from fusion_ai_sdk.llm_sdk import LLMInvoker
from dotenv import load_dotenv

load_dotenv()


class MovieReview(BaseModel):
    movie_name: str
    rating_out_of_10: int
    pros: list[str]
    cons: list[str]
    one_sentence_summary: str


def main():
    invoker = LLMInvoker()

    llm_input = LLMInvoker.ChatCompletionInput(
        provider="openai",          # Works with "gemini" or "ollama" too
        model_name="gpt-4o-mini",
        messages=[{"role": "user", "content": "Write a review for the movie Inception"}],
        response_schema=MovieReview,
    )

    print(f"Calling {llm_input.provider} / {llm_input.model_name}...")
    response = invoker.chat_completion(llm_input)

    if response.success:
        review: MovieReview = response.response
        print(f"\nMovie:   {review.movie_name}")
        print(f"Rating:  {review.rating_out_of_10}/10")
        print(f"Summary: {review.one_sentence_summary}")
        print(f"Pros:    {review.pros}")
        print(f"Cons:    {review.cons}")
    else:
        print(f"Error: {response.error_message}")


if __name__ == "__main__":
    main()
