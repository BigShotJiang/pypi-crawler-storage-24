"""GAM MCP Tools."""
