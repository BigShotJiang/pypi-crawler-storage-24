"""Test suite for CasConf."""
