SPLUNK PACKAGING TOOLKIT v1.2.7

March 2026

The Splunk Packaging Toolkit offers a tool for authoring, packaging and validating a Splunk app in a way that eases up app installation, configuration, and update.

Requires: future 1.0.0, wheel 0.46.3, setuptools 80.9.0, semantic_version 2.10.0


# Getting started

Install the package from [PyPI](https://pypi.org/), using pip:
```
pip install splunk-packaging-toolkit
```

# Usage
```
slim --help
```


# Splunk Packaging Toolkit online documentation is located at:
* http://dev.splunk.com/goto/packaging-toolkit

For installation instructions, see:
* http://dev.splunk.com/goto/packaging-toolkit-install

For release notes, see:
* http://dev.splunk.com/goto/packaging-toolkit-rn

Send your feedback to: appmgmt-feedback@splunk.com or via answers.splunk.com
