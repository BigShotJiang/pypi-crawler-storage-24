class JustSomeClass(object):
    pass
