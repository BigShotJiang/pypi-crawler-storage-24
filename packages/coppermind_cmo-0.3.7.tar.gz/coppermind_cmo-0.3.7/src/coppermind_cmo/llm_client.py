"""LLM client for classification and summarization.

Supports two providers:
  - Gateway (hosted): routes through Coppermind gateway → Claude API
  - Ollama (self-hosted): direct Ollama HTTP API, 30s timeout, temperature=0

The dispatcher function call_llm() routes to the correct provider based on config.
"""

import json
from typing import Optional

import httpx

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("llm_client")

VALID_MEMORY_TYPES = {
    "decision", "preference", "campaign_outcome",
    "commitment", "stakeholder", "fact",
}

CLASSIFY_PROMPT = (
    "Classify this client memory into exactly one type.\n\n"
    "Types:\n"
    '- decision: A choice that was made ("We\'re pausing LinkedIn ads")\n'
    '- preference: A stated or implied preference ("Prefers casual brand voice")\n'
    '- campaign_outcome: Results or metrics from a campaign ("Email open rate was 34%")\n'
    '- commitment: An action item someone committed to ("Ben will send messaging by Friday")\n'
    '- stakeholder: Information about a key person ("Sarah Chen is VP Marketing")\n'
    "- fact: Any other noteworthy fact about the client\n\n"
    "Examples:\n"
    'Memory: "Pausing LinkedIn ads through Q2, reallocating to content marketing." \u2192 decision\n'
    'Memory: "Sarah prefers async updates via Slack." \u2192 preference\n'
    'Memory: "Q1 email: 34% open rate, curiosity gap won." \u2192 campaign_outcome\n'
    'Memory: "Ben will send revised messaging by Friday." \u2192 commitment\n'
    'Memory: "James Park is the new CEO, started January 2026." \u2192 stakeholder\n'
    'Memory: "Series B, 45 employees, developer-first API platform." \u2192 fact\n\n'
    "Return ONLY the type name, nothing else.\n\n"
)

SUMMARIZE_PROMPT = (
    "Summarize this client memory in one sentence (max 100 chars). "
    "Preserve all proper nouns (people, company names), dollar amounts, "
    "dates, and specific identifiers exactly — never replace them with "
    "generic descriptions. "
    "Return ONLY the summary.\n\n"
)


# ---------------------------------------------------------------------------
# Ollama provider (self-hosted)
# ---------------------------------------------------------------------------

def call_ollama(
    prompt: str,
    base_url: str,
    model: str,
    timeout: int = 30,
) -> Optional[str]:
    """Call Ollama API. Returns response text or None on failure."""
    url = f"{base_url.rstrip('/')}/api/generate"
    try:
        resp = httpx.post(
            url,
            json={"model": model, "prompt": prompt, "stream": False, "options": {"temperature": 0}},
            timeout=timeout,
        )
        data = resp.json()
        return data.get("response", "")
    except Exception as e:
        logger.warn(f"Ollama call failed: {e}")
        return None


# ---------------------------------------------------------------------------
# Gateway provider (hosted)
# ---------------------------------------------------------------------------

def _gateway_headers(config: Config) -> dict:
    """Build headers for gateway requests including session tracking."""
    from coppermind_cmo.server import get_session_id
    return {
        "Authorization": f"Bearer {config.api_key}",
        "X-Session-Id": get_session_id(),
    }


def call_gateway_llm(
    endpoint: str,
    body: dict,
    config: Config,
    timeout: float = 30,
) -> Optional[dict]:
    """Call a gateway LLM endpoint. Returns parsed JSON response or None on failure."""
    url = f"{config.gateway_url.rstrip('/')}/v1/{endpoint}"
    try:
        resp = httpx.post(
            url,
            json=body,
            headers=_gateway_headers(config),
            timeout=timeout,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.warn(f"Gateway LLM call failed ({endpoint}): {e}")
        return None


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

def call_llm(
    prompt: str,
    config: Config,
    use_synthesis_model: bool = False,
) -> Optional[str]:
    """Route LLM call to gateway or Ollama based on config.

    Returns response text or None on failure.
    """
    if config.llm_provider == "gateway":
        if use_synthesis_model:
            result = call_gateway_llm("synthesize", {"prompt": prompt}, config)
            if result is not None:
                return result.get("text")
        else:
            # For classify/summarize, we send the raw prompt and let the gateway handle it
            result = call_gateway_llm("synthesize", {"prompt": prompt}, config)
            if result is not None:
                return result.get("text")
        return None
    elif config.llm_provider == "ollama":
        return call_ollama(prompt, config.ollama_url, config.ollama_model)
    else:
        return None


# ---------------------------------------------------------------------------
# High-level functions
# ---------------------------------------------------------------------------

def classify_memory_type(content: str, config: Config) -> tuple[str, str]:
    """Classify content into a memory type.

    Returns (memory_type, classified_by) where classified_by is
    'llm' or 'fallback'.
    """
    if config.llm_provider == "gateway":
        result = call_gateway_llm("classify", {"content": content}, config)
        if result is None:
            return ("fact", "fallback")
        memory_type = result.get("memory_type", "fact")
        cleaned = memory_type.strip().lower().rstrip(".,;:!?").replace(" ", "_")
        if cleaned in VALID_MEMORY_TYPES:
            return (cleaned, "llm")
        return ("fact", "llm")

    # Ollama or no provider
    prompt = CLASSIFY_PROMPT + f'Memory: "{content}"\nType:'

    if config.llm_provider == "ollama":
        response = call_ollama(prompt, config.ollama_url, config.ollama_model)
    else:
        response = None

    if response is None:
        return ("fact", "fallback")

    cleaned = response.strip().lower().rstrip(".,;:!?").replace(" ", "_")
    if cleaned in VALID_MEMORY_TYPES:
        return (cleaned, "llm")
    return ("fact", "llm")


def summarize(content: str, config: Config) -> str:
    """Generate a one-line summary. Falls back to truncation if LLM is down."""
    if config.llm_provider == "gateway":
        result = call_gateway_llm("summarize", {"content": content}, config)
        if result is not None:
            summary = result.get("summary", "")
            return summary.strip()[:200]
        return content[:100]

    # Ollama or no provider
    prompt = SUMMARIZE_PROMPT + f'Memory: "{content}"\nSummary:'

    if config.llm_provider == "ollama":
        response = call_ollama(prompt, config.ollama_url, config.ollama_model)
    else:
        response = None

    if response is not None:
        return response.strip()[:200]
    return content[:100]
