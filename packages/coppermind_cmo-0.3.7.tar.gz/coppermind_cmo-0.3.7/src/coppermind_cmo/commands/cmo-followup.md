# /cmo-followup — Post-Meeting Follow-Up Email

Draft a follow-up email after a client meeting.

## Steps

1. Confirm the active client. If none, ask which client the meeting was with.
2. Pull the most recent memories (last 24 hours) and the last meeting brief if saved.
3. Check if a CMO voice profile exists (search for an internal mind called "CMO Profile" or check for a `cmo_voice` memory). If found, use it for tone and style. If not, use a neutral professional tone — warm, concise, and direct.
4. Do NOT use the client's brand voice for emails. Brand voice is how the client talks to their customers. This email is from the CMO to the client.
5. Draft a follow-up email that includes:
   - Brief thank-you / recap of what was discussed
   - Key decisions made (bulleted)
   - Action items with owners and deadlines (bulleted)
   - Next steps or next meeting date if known
6. Match formality to the relationship — use stakeholder profile to gauge. If the stakeholder profile says "direct communicator" or the transcript shows casual language, be casual. Otherwise default to professional.
7. Present the draft and ask: "Want me to adjust anything, or copy this to your clipboard?"

## Rules
- Keep it short — 3-4 paragraphs max. CMOs send dozens of these.
- Never include internal notes or agency-specific details. This goes TO the client.
- Action items should clearly state who owns each one (including items the CMO owns).
- If the user just pasted a transcript, extract from that. Don't make them re-explain.
- Offer to copy to clipboard when done.
- If this is the first follow-up email and no CMO voice exists, mention it once: "Tip: paste 2-3 emails you've sent to clients and I'll learn your writing style for future emails."
