# /cmo-help — Coppermind Help

Provide help, troubleshooting, and how-to guidance for Coppermind CMO.
Answer conversationally and keep responses short — CMOs don't want tutorials.

## If no specific question

Show this quick reference:

```
COPPERMIND CMO — Quick Reference

GETTING STARTED
  "Set up [client name]"          Create a new client
  "Switch to [client]"            Change active client
  "List my clients"               Show all client minds

MEETINGS
  "Prep my meeting with [client]" Build a meeting brief
  "Save the brief"                Persist for later retrieval
  "Show my last brief"            Pull up saved brief

MEMORY
  "Remember: [anything]"          Store a structured memory
  "Quick note: [anything]"        Fast capture, no classification
  "What did we decide about X?"   Search decisions
  "Who is [person]?"              Search stakeholders

CONTENT
  "Write a blog post for [client]"    Uses client's brand voice
  "Draft a social post about X"       On-brand content
  "Write a follow-up email"           Post-meeting email draft

POWER FEATURES
  /cmo-morning                    Daily briefing across all clients
  /cmo-followup                   Draft post-meeting follow-up email
  /cmo-handoff                    Generate client handoff document
  /cmo-actions                    Overdue items across all clients
  /cmo-batch                      Write content for multiple clients
  /cmo-review                     Quarterly review for a client
  /cmo-connect                    Pull data from Granola/Gmail/Slack
```

## Rules
- Always check the knowledge base and quickstart before saying "I don't know."
- For setup issues, walk them through step by step — don't just link to the doc.
- Only suggest emailing coppermind@volacci.com for issues you genuinely cannot resolve.
- Keep answers short and actionable. CMOs don't want tutorials.
