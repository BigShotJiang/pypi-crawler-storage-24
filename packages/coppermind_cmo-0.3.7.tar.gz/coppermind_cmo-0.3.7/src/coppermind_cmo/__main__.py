"""Entry point: python -m coppermind_cmo runs the MCP server."""

from coppermind_cmo.server import main

if __name__ == "__main__":
    main()
