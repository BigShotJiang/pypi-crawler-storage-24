"""Error response helpers per SERVER_SPEC.md error format."""

from typing import Any


def tool_error(code: str, message: str) -> dict[str, Any]:
    return {"error": True, "code": code, "message": message}


def NO_ACTIVE_MIND() -> dict[str, Any]:
    return tool_error("NO_ACTIVE_MIND", "No active client. Call switch_client first. Need help? Contact coppermind@volacci.com.")


def MIND_NOT_FOUND() -> dict[str, Any]:
    return tool_error("MIND_NOT_FOUND", "Mind not found. Use list_minds to see available clients, or contact coppermind@volacci.com for help.")


def MIND_ARCHIVED(name: str) -> dict[str, Any]:
    return tool_error("MIND_ARCHIVED", f"Mind '{name}' is archived. Contact coppermind@volacci.com to unarchive.")


def INVALID_INPUT(message: str) -> dict[str, Any]:
    return tool_error("INVALID_INPUT", message)


def INVALID_MEMORY_TYPE(value: str) -> dict[str, Any]:
    valid = "decision, preference, campaign_outcome, commitment, stakeholder, fact"
    return tool_error("INVALID_MEMORY_TYPE", f"Invalid memory_type '{value}'. Valid types: {valid}")


def INVALID_BRAND_DNA(message: str) -> dict[str, Any]:
    return tool_error("INVALID_BRAND_DNA", message)


def SERVICE_UNAVAILABLE(service: str) -> dict[str, Any]:
    return tool_error("SERVICE_UNAVAILABLE", f"{service} is unreachable. If this persists, contact coppermind@volacci.com.")


def MEMORY_NOT_FOUND(memory_id: str) -> dict[str, Any]:
    return tool_error("MEMORY_NOT_FOUND", f"Memory '{memory_id}' not found or belongs to a different mind.")


def INVALID_QUERY() -> dict[str, Any]:
    return tool_error("INVALID_QUERY", "Query cannot be empty.")


def ACCESS_DENIED(detail: str = "You do not have access to this client mind. Contact coppermind@volacci.com if this is unexpected.") -> dict[str, Any]:
    return tool_error("ACCESS_DENIED", detail)
