"""Database connection pool and query helpers.

Adapted from old Coppermind lib/database.py. Simplified for CMO use case:
- Single config source (COPPERMIND_PG_* env vars via Config)
- psycopg2 ThreadedConnectionPool
"""

from __future__ import annotations

import os
import threading
from contextlib import contextmanager
from typing import Any

import psycopg2
from psycopg2.pool import PoolError, ThreadedConnectionPool

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("db")

POOL_MIN = 1
POOL_MAX = 3


class Database:
    """PostgreSQL connection pool wrapper."""

    def __init__(self, config: Config):
        self._config = config
        self._pool: ThreadedConnectionPool | None = None
        self._pool_lock = threading.Lock()

    def _ensure_pool(self):
        if self._pool is not None:
            return
        with self._pool_lock:
            if self._pool is None:
                ssl_kwargs = {}
                if self._config.api_key:
                    ca_path = os.path.join(
                        os.path.dirname(__file__), "supabase-ca.pem"
                    )
                    ssl_kwargs = {
                        "sslmode": "verify-ca",
                        "sslrootcert": ca_path,
                    }
                self._pool = ThreadedConnectionPool(
                    POOL_MIN, POOL_MAX,
                    host=self._config.pg_host,
                    port=self._config.pg_port,
                    dbname=self._config.pg_db,
                    user=self._config.pg_user,
                    password=self._config.pg_password,
                    connect_timeout=5,
                    keepalives=1,
                    keepalives_idle=30,
                    keepalives_interval=10,
                    keepalives_count=5,
                    **ssl_kwargs,
                )

    @contextmanager
    def connection(self):
        """Borrow a connection from the pool. Auto-returned on exit."""
        self._ensure_pool()
        try:
            conn = self._pool.getconn()
        except PoolError:
            logger.warn("Connection pool exhausted")
            raise
        _force_close = False
        try:
            yield conn
        except Exception:
            try:
                conn.rollback()
            except Exception:
                _force_close = True  # rollback failed — connection is dead
            raise
        finally:
            if conn.closed or _force_close:
                self._pool.putconn(conn, close=True)
            else:
                self._pool.putconn(conn)

    def fetch_all(self, sql: str, params: list[Any] | None = None) -> list[tuple]:
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                result = cur.fetchall()
            conn.commit()
            return result

    def fetch_one(self, sql: str, params: list[Any] | None = None) -> tuple | None:
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                result = cur.fetchone()
            conn.commit()
            return result

    def execute(self, sql: str, params: list[Any] | None = None):
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
            conn.commit()

    def execute_returning(self, sql: str, params: list[Any] | None = None) -> tuple | None:
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                row = cur.fetchone()
            conn.commit()
            return row

    def close(self):
        if self._pool is not None:
            self._pool.closeall()
            self._pool = None
