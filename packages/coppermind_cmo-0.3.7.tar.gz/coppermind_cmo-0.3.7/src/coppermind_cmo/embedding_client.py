"""HTTP client for embedding services.

Supports two providers:
  - Gateway (hosted): routes through Coppermind gateway → Voyage AI (512 dims)
  - Local (self-hosted): sentence-transformers service on localhost:8400 (384 dims)

Returns None on any failure — callers handle degraded mode.
"""

from typing import Optional

import httpx

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("embedding")

# Legacy constant for backward compatibility in tests
EXPECTED_DIMS = 384


def _get_embedding_local(text: str, base_url: str, expected_dims: int, timeout: float = 10) -> Optional[list[float]]:
    """Get embedding from the local sentence-transformers service."""
    try:
        resp = httpx.post(
            f"{base_url.rstrip('/')}/embed",
            json={"text": text},
            timeout=timeout,
        )
        resp.raise_for_status()
        embedding = resp.json()["embedding"]

        if not isinstance(embedding, list) or len(embedding) == 0:
            logger.warn("Invalid embedding shape: expected non-empty list")
            return None
        if not all(isinstance(x, (int, float)) for x in embedding):
            logger.warn("Invalid embedding: contains non-numeric elements")
            return None
        if len(embedding) != expected_dims:
            logger.warn(f"Embedding dimension mismatch: got {len(embedding)}, expected {expected_dims}")
            return None

        return embedding
    except Exception as e:
        logger.warn(f"Embedding request failed: {e}")
        return None


def _gateway_headers(config: Config) -> dict:
    """Build headers for gateway requests including session tracking."""
    from coppermind_cmo.server import get_session_id
    return {
        "Authorization": f"Bearer {config.api_key}",
        "X-Session-Id": get_session_id(),
    }


def _get_embedding_gateway(text: str, config: Config, timeout: float = 10) -> Optional[list[float]]:
    """Get embedding from the Coppermind gateway → Voyage AI."""
    try:
        resp = httpx.post(
            f"{config.gateway_url.rstrip('/')}/v1/embed",
            json={"text": text},
            headers=_gateway_headers(config),
            timeout=timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        embedding = data["embedding"]

        if not isinstance(embedding, list) or len(embedding) == 0:
            logger.warn("Invalid gateway embedding shape: expected non-empty list")
            return None
        if not all(isinstance(x, (int, float)) for x in embedding):
            logger.warn("Invalid gateway embedding: contains non-numeric elements")
            return None
        expected = data.get("dimensions", config.embedding_dims)
        if len(embedding) != expected:
            logger.warn(f"Gateway embedding dimension mismatch: got {len(embedding)}, expected {expected}")
            return None

        return embedding
    except Exception as e:
        logger.warn(f"Gateway embedding request failed: {e}")
        return None


def get_embedding(text: str, config: Config, timeout: float = 10) -> Optional[list[float]]:
    """Get embedding vector for text. Routes to gateway or local based on config."""
    if config.embedding_provider == "gateway":
        return _get_embedding_gateway(text, config, timeout)
    elif config.embedding_provider == "local":
        return _get_embedding_local(text, config.embedding_url, config.embedding_dims, timeout)
    else:
        return None


def check_health(config: Config, timeout: float = 5) -> bool:
    """Check if the embedding service is healthy."""
    if config.embedding_provider == "gateway":
        try:
            resp = httpx.get(
                f"{config.gateway_url.rstrip('/')}/v1/health",
                headers=_gateway_headers(config),
                timeout=timeout,
            )
            if resp.status_code != 200:
                return False
            return True
        except Exception:
            return False
    elif config.embedding_provider == "local":
        try:
            resp = httpx.get(f"{config.embedding_url.rstrip('/')}/health", timeout=timeout)
            if resp.status_code != 200:
                return False
            data = resp.json()
            reported_dims = data.get("dimensions")
            if reported_dims is not None and reported_dims != config.embedding_dims:
                logger.warn(
                    f"Embedding service dimension mismatch: reports {reported_dims}, expected {config.embedding_dims}"
                )
                return False
            return True
        except Exception:
            return False
    else:
        return False
