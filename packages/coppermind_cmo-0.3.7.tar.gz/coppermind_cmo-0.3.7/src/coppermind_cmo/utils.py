"""Shared utility functions."""

import json
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from coppermind_cmo.db import Database


def parse_jsonb(val) -> Any:
    """Parse jsonb value from DB — may be str, dict, or list."""
    if val is None:
        return {}
    if isinstance(val, str):
        return json.loads(val)
    return val


def get_mind_cadence(mind_id: str, db: "Database") -> dict:
    """Fetch a mind's cadence JSONB. Returns {} if not set."""
    row = db.fetch_one(
        "SELECT cadence FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if row and row[0]:
        return row[0] if isinstance(row[0], dict) else {}
    return {}


def touch_memories(db: "Database", ids: list[str]) -> None:
    """Update last_accessed_at for a list of memory UUIDs."""
    if not ids:
        return
    placeholders = ",".join(["%s::uuid"] * len(ids))
    db.execute(
        f"UPDATE memories SET last_accessed_at = now() WHERE id IN ({placeholders})",
        ids,
    )
