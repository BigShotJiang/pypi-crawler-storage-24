"""Configuration from COPPERMIND_* environment variables.

All numeric env vars are validated as integers at parse time (not on first use)
per SERVER_SPEC.md startup requirements.

Provider detection:
  COPPERMIND_API_KEY set → hosted mode (gateway for LLM+embedding)
  COPPERMIND_OLLAMA_HOST set → self-hosted LLM (Ollama)
  COPPERMIND_EMBEDDING_HOST set → self-hosted embeddings (local server)
  Neither → degraded mode (same as Sprint 1 when services are down)
"""

import os


def _int_env(name: str, default: int) -> int:
    val = os.environ.get(name)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        raise ValueError(f"{name} must be an integer, got: {val!r}")


class Config:
    """Parsed configuration from environment variables."""

    def __init__(self):
        # --- Customer identity (set during provisioning) ---
        self.customer_id: str = ""

        # --- Hosted mode ---
        self.api_key: str = os.environ.get("COPPERMIND_API_KEY", "")
        self.gateway_url: str = os.environ.get(
            "COPPERMIND_GATEWAY_URL",
            "https://api.coppermind.app",
        )

        # --- Self-hosted PostgreSQL ---
        self.pg_host: str = os.environ.get("COPPERMIND_PG_HOST", "localhost")
        self.pg_port: int = _int_env("COPPERMIND_PG_PORT", 5432)
        self.pg_db: str = os.environ.get("COPPERMIND_PG_DB", "coppermind_cmo")
        self.pg_user: str = os.environ.get("COPPERMIND_PG_USER", "coppermind")
        self.pg_password: str = os.environ.get("COPPERMIND_PG_PASSWORD", "")

        # --- Self-hosted embedding service ---
        self.embedding_host: str = os.environ.get("COPPERMIND_EMBEDDING_HOST", "localhost")
        self.embedding_port: int = _int_env("COPPERMIND_EMBEDDING_PORT", 8400)

        # --- Self-hosted Ollama ---
        self.ollama_host: str = os.environ.get("COPPERMIND_OLLAMA_HOST", "localhost")
        self.ollama_port: int = _int_env("COPPERMIND_OLLAMA_PORT", 11434)
        self.ollama_model: str = os.environ.get("COPPERMIND_OLLAMA_MODEL", "gemma3:12b")

        # --- Claude model configuration (hosted mode) ---
        self.claude_fast_model: str = os.environ.get(
            "COPPERMIND_CLAUDE_FAST_MODEL", "claude-haiku-4-5-20251001"
        )
        self.claude_synthesis_model: str = os.environ.get(
            "COPPERMIND_CLAUDE_SYNTHESIS_MODEL", "claude-sonnet-4-20250514"
        )

        # --- Provider detection ---
        if self.api_key:
            self.llm_provider: str | None = "gateway"
            self.embedding_provider: str | None = "gateway"
            self.embedding_dims: int = 512
            self.max_prompt_chars: int = 40000
        else:
            # Self-hosted: detect individually
            has_ollama = bool(os.environ.get("COPPERMIND_OLLAMA_HOST"))
            has_embedding = bool(os.environ.get("COPPERMIND_EMBEDDING_HOST"))
            self.llm_provider = "ollama" if has_ollama else None
            self.embedding_provider = "local" if has_embedding else None
            self.embedding_dims = 384
            self.max_prompt_chars = 13000

    @property
    def embedding_url(self) -> str:
        return f"http://{self.embedding_host}:{self.embedding_port}"

    @property
    def ollama_url(self) -> str:
        return f"http://{self.ollama_host}:{self.ollama_port}"


from dataclasses import dataclass, field


@dataclass
class ServerConfig:
    """Config fetched from the gateway on startup."""
    min_client_version: str = ""
    upgrade_message: str = ""
    prompts: dict = field(default_factory=dict)
    fetched: bool = False

_server_config: ServerConfig | None = None


def get_server_config() -> ServerConfig:
    """Return cached server config. Call fetch_server_config() first."""
    global _server_config
    if _server_config is None:
        _server_config = ServerConfig()
    return _server_config


def fetch_server_config(config: 'Config') -> ServerConfig:
    """Fetch config from gateway. Cache result. Returns defaults on failure."""
    global _server_config
    if config.llm_provider != "gateway":
        _server_config = ServerConfig()
        return _server_config

    import httpx
    try:
        resp = httpx.get(
            f"{config.gateway_url.rstrip('/')}/v1/config",
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=5.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            _server_config = ServerConfig(
                min_client_version=data.get("min_client_version", ""),
                upgrade_message=data.get("upgrade_message", ""),
                prompts=data.get("prompts", {}) if isinstance(data.get("prompts"), dict) else {},
                fetched=True,
            )
        else:
            _server_config = ServerConfig()
    except Exception:
        _server_config = ServerConfig()

    return _server_config
