"""Standalone embedding HTTP server using sentence-transformers.

Run: python -m coppermind_cmo.embedding_server
Serves on port 8400 by default.
"""

import os
import logging
import threading

from flask import Flask, request, jsonify

logger = logging.getLogger(__name__)
app = Flask(__name__)

_model = None
_model_lock = threading.Lock()
MODEL_NAME = "all-MiniLM-L6-v2"
DIMENSIONS = 384


def _get_model():
    global _model
    if _model is not None:
        return _model
    with _model_lock:
        if _model is None:
            from sentence_transformers import SentenceTransformer
            _model = SentenceTransformer(MODEL_NAME)
            logger.info("Loaded embedding model: %s", MODEL_NAME)
    return _model


@app.route("/health")
def health():
    try:
        _get_model()
        return jsonify({"status": "ok", "model": MODEL_NAME, "dimensions": DIMENSIONS})
    except Exception as e:
        logger.error("Model load failed: %s", e)
        return jsonify({"status": "error", "message": "Embedding model unavailable"}), 503


@app.route("/embed", methods=["POST"])
def embed():
    data = request.get_json()
    if not data or "text" not in data:
        return jsonify({"error": "Missing 'text' field"}), 400

    text = data["text"]
    if not isinstance(text, str) or not text.strip():
        return jsonify({"error": "'text' must be a non-empty string"}), 400
    if len(text) > 50000:
        return jsonify({"error": "Text exceeds 50,000 character limit"}), 400

    model = _get_model()
    embedding = model.encode(text, convert_to_numpy=True).tolist()
    return jsonify({"embedding": embedding})


def main():
    port = int(os.environ.get("COPPERMIND_EMBEDDING_PORT", "8400"))
    logger.info("Starting embedding server on port %d", port)
    _get_model()  # Pre-load model
    from waitress import serve
    serve(app, host="127.0.0.1", port=port, threads=4)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
