"""Coppermind CMO — AI memory for fractional CMOs."""

__version__ = "0.1.3"
