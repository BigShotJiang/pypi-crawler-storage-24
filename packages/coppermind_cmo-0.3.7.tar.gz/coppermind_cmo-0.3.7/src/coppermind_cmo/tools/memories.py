"""Memory tools: store_memory, search_memory, quick_note, hide_memory.

Reference: docs/MCP_TOOLS.md — store_memory, search_memory, quick_note, hide_memory.
"""

import json
import os
import uuid as _uuid
from typing import Any

from coppermind_cmo.config import Config, get_server_config
from coppermind_cmo.db import Database
from coppermind_cmo.embedding_client import get_embedding
from coppermind_cmo.llm_client import classify_memory_type, summarize, call_llm, VALID_MEMORY_TYPES
from coppermind_cmo.errors import (
    NO_ACTIVE_MIND, INVALID_INPUT, INVALID_MEMORY_TYPE,
    INVALID_QUERY, MEMORY_NOT_FOUND, tool_error,
)
from coppermind_cmo.utils import get_mind_cadence, touch_memories
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("memories")

MAX_CONTENT_CHARS = 10000
FALLBACK_CONFIDENCE = 0.8
MAX_LIMIT = 200
QUICK_NOTE_SUMMARY_LEN = 100
SIMILARITY_THRESHOLD = 0.3
BRAND_DNA_THRESHOLD = 0.45
try:
    RECONSOLIDATION_THRESHOLD = float(os.environ.get("COPPERMIND_RECONSOLIDATION_THRESHOLD", "0.70"))
except ValueError:
    RECONSOLIDATION_THRESHOLD = 0.70


def _find_similar_memory(
    embedding: list[float] | None,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict | None:
    """Search for an existing memory similar to the given embedding.

    Returns the best match above RECONSOLIDATION_THRESHOLD or None.
    """
    if embedding is None or active_mind is None:
        return None

    mind_id = active_mind[0]

    # Known limitation: concurrent reconsolidation is not protected by row
    # locking. Database.fetch_one() auto-commits, so FOR UPDATE would release
    # immediately. Acceptable for Sprint 1 — single-user MCP server and
    # single-threaded watcher make races practically impossible.
    row = db.fetch_one(
        "WITH q AS (SELECT %s::vector AS qv) "
        "SELECT id, content, summary, memory_type, "
        "1 - (embedding <=> q.qv) AS similarity "
        "FROM memories, q "
        "WHERE mind_id = %s AND is_current = true AND embedding IS NOT NULL "
        "AND 1 - (embedding <=> q.qv) >= %s "
        "ORDER BY embedding <=> q.qv ASC "
        "LIMIT 1",
        [json.dumps(embedding), mind_id, RECONSOLIDATION_THRESHOLD],
    )

    if row is None:
        return None

    return {
        "memory_id": str(row[0]),
        "content": row[1],
        "summary": row[2],
        "memory_type": row[3],
        "similarity": float(row[4]),
    }


_LOCAL_MERGE_PROMPT = (
    "You have two versions of the same client memory. "
    "Merge them into a single, concise memory that preserves all facts from both. "
    "Keep the result under 500 characters. Do not add information not present in either memory. "
    "Return ONLY the merged text, nothing else.\n\n"
    "Existing memory:\n<existing_memory>\n{old}\n</existing_memory>\n\n"
    "New information:\n<new_information>\n{new}\n</new_information>\n\n"
    "Merged memory:"
)

MERGE_PROMPT = _LOCAL_MERGE_PROMPT  # backward compat


def _build_merge_prompt(old_content: str, new_content: str) -> str:
    """Build merge prompt, preferring server-side template if available."""
    server_cfg = get_server_config()
    if server_cfg.fetched and server_cfg.prompts.get("merge"):
        template = server_cfg.prompts["merge"]
        import re
        subs = {"$existing$": old_content, "$new$": new_content}
        pattern = "|".join(re.escape(k) for k in subs)
        return re.sub(pattern, lambda m: subs[m.group()], template)
    return _LOCAL_MERGE_PROMPT.format(old=old_content, new=new_content)


def _merge_memory_content(
    old_content: str,
    new_content: str,
    config: Config,
) -> str:
    """Merge old and new memory content via LLM. Falls back to new content."""
    prompt = _build_merge_prompt(old_content, new_content)
    # Use Haiku (fast model) — merge is simple text combination, not synthesis
    result = call_llm(prompt, config, use_synthesis_model=False)
    if result and result.strip():
        return result.strip()[:MAX_CONTENT_CHARS]
    return new_content


DEDUP_CONFIRM_PROMPT = (
    "Are these two client memories describing the same fact or event? "
    "Consider them the same if they contain the same core information, even if worded differently. "
    "Reply ONLY with YES or NO.\n\n"
    "Memory A:\n{a}\n\n"
    "Memory B:\n{b}\n\n"
    "Same fact?"
)


def _confirm_duplicate(old_content: str, new_content: str, config: Config) -> bool:
    """Ask LLM whether two memories describe the same fact. Falls back to False if LLM unavailable."""
    prompt = DEDUP_CONFIRM_PROMPT.format(a=old_content, b=new_content)
    result = call_llm(prompt, config, use_synthesis_model=False)
    if result is None:
        # LLM unavailable — don't merge (the 0.70-0.85 zone needs LLM judgment)
        return False
    cleaned = result.strip().upper()
    return cleaned.startswith("YES")


def _update_memory(
    memory_id: str,
    content: str,
    summary: str,
    embedding: list[float] | None,
    db: Database,
    active_mind: tuple[str, str] | None,
    quarter_year: int | None = None,
    quarter: int | None = None,
    sprint: int | None = None,
) -> None:
    """Update an existing memory's content, summary, and embedding.

    Includes mind_id in WHERE clause to enforce client isolation.
    Sets follows_tool_call to track which tool triggered the merge.
    """
    from coppermind_cmo.server import get_last_tool_call
    mind_id = active_mind[0] if active_mind else None
    follows_tool = get_last_tool_call()
    if embedding is not None:
        db.execute(
            "UPDATE memories SET content = %s, summary = %s, "
            "embedding = %s::vector, last_accessed_at = now(), "
            "quarter_year = %s, quarter = %s, sprint = %s, "
            "follows_tool_call = %s "
            "WHERE id = %s AND mind_id = %s",
            [content, summary, json.dumps(embedding), quarter_year, quarter, sprint,
             follows_tool, memory_id, mind_id],
        )
    else:
        db.execute(
            "UPDATE memories SET content = %s, summary = %s, "
            "last_accessed_at = now(), "
            "quarter_year = %s, quarter = %s, sprint = %s, "
            "follows_tool_call = %s "
            "WHERE id = %s AND mind_id = %s",
            [content, summary, quarter_year, quarter, sprint,
             follows_tool, memory_id, mind_id],
        )


def _store_memory(
    content: str,
    memory_type: str | None,
    tags: list[str],
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
    skip_reconsolidation: bool = False,
    source_type: str = "manual",
    source_tool: str | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    if not content or not content.strip():
        return INVALID_INPUT("content cannot be empty")
    if len(content) > MAX_CONTENT_CHARS:
        return INVALID_INPUT(f"content exceeds {MAX_CONTENT_CHARS:,} character limit")

    if len(tags) > 20:
        return INVALID_INPUT("Maximum 20 tags allowed")
    if any(len(t) > 100 for t in tags):
        return INVALID_INPUT("Each tag must be 100 characters or fewer")

    # Preserve full document for long content (future re-extraction)
    if len(content) > 4000:
        from coppermind_cmo.ingest import _store_raw_document
        _store_raw_document(content, mind_id, db, source_type=source_type)

    # Normalize user-provided memory_type (invalid types fall through to auto-classification)
    classified_by = "user"
    confidence = 1.0
    if memory_type is not None:
        cleaned = memory_type.strip().lower().replace(" ", "_")
        if cleaned not in VALID_MEMORY_TYPES:
            logger.warn(
                f"Invalid memory_type '{memory_type}', falling back to auto-classification",
                mind_id=mind_id,
            )
            memory_type = None  # fall through to auto-classification below
        else:
            memory_type = cleaned

    if memory_type is None:
        # Auto-classify via LLM (gateway or Ollama)
        memory_type, classified_by = classify_memory_type(content, config)
        if classified_by == "fallback":
            confidence = FALLBACK_CONFIDENCE

    # Generate embedding
    embedding = get_embedding(content, config)
    has_embedding = embedding is not None

    # Fetch cadence for quarter tagging
    cadence = get_mind_cadence(mind_id, db)
    quarter_year = cadence.get("year")
    quarter = cadence.get("quarter")
    sprint = cadence.get("sprint")

    # --- Reconsolidation: check for similar existing memory ---
    if has_embedding and not skip_reconsolidation:
        similar = _find_similar_memory(embedding, db, active_mind)
        if similar is not None:
            # Tier 2: LLM confirmation (skip merge if LLM says they're different)
            if not _confirm_duplicate(similar["content"], content, config):
                logger.info(
                    f"Reconsolidation candidate rejected by LLM (similarity: {similar['similarity']:.0%})",
                    mind_id=mind_id,
                    candidate_id=similar["memory_id"],
                )
                similar = None  # fall through to normal insert

        if similar is not None:
            merged_content = _merge_memory_content(
                similar["content"], content, config,
            )
            merged_summary = summarize(merged_content, config)
            merged_embedding = get_embedding(merged_content, config)
            if merged_embedding is None:
                logger.warn(
                    "Re-embedding failed after merge — keeping original embedding",
                    mind_id=mind_id,
                    original_id=similar["memory_id"],
                )
            _update_memory(
                similar["memory_id"],
                merged_content,
                merged_summary,
                merged_embedding,
                db,
                active_mind,
                quarter_year=quarter_year,
                quarter=quarter,
                sprint=sprint,
            )
            logger.info(
                f"Reconsolidated memory: {merged_summary}",
                mind_id=mind_id,
                original_id=similar["memory_id"],
                similarity=similar["similarity"],
            )
            return {
                "memory_id": similar["memory_id"],
                "summary": merged_summary,
                "memory_type": similar["memory_type"],
                "classified_by": classified_by,
                "has_embedding": merged_embedding is not None,
                "mind_id": mind_id,
                "reconsolidated": True,
                "message": (
                    f"Merged with existing memory (similarity: "
                    f"{similar['similarity']:.0%}). Updated summary: {merged_summary}"
                ),
            }

    # Generate summary
    summary = summarize(content, config)

    # Resolve follows_tool_call from server tracking
    from coppermind_cmo.server import get_last_tool_call
    follows_tool = get_last_tool_call()

    # Insert new memory
    if has_embedding:
        row = db.execute_returning(
            "INSERT INTO memories "
            "(mind_id, content, summary, memory_type, embedding, confidence, "
            "source_type, tags, last_accessed_at, quarter_year, quarter, sprint, "
            "source_tool, follows_tool_call) "
            "VALUES (%s, %s, %s, %s, %s::vector, %s, %s, %s, now(), %s, %s, %s, %s, %s) "
            "RETURNING id",
            [mind_id, content, summary, memory_type, json.dumps(embedding), confidence,
             source_type, tags, quarter_year, quarter, sprint,
             source_tool, follows_tool],
        )
        if row is None:
            return tool_error("INTERNAL_ERROR", "Failed to store memory")
    else:
        row = db.execute_returning(
            "INSERT INTO memories "
            "(mind_id, content, summary, memory_type, confidence, "
            "source_type, tags, last_accessed_at, quarter_year, quarter, sprint, "
            "source_tool, follows_tool_call) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, now(), %s, %s, %s, %s, %s) "
            "RETURNING id",
            [mind_id, content, summary, memory_type, confidence, source_type, tags,
             quarter_year, quarter, sprint,
             source_tool, follows_tool],
        )
        if row is None:
            return tool_error("INTERNAL_ERROR", "Failed to store memory")

    memory_id = str(row[0])
    logger.info(f"Stored memory: {summary}", mind_id=mind_id)

    return {
        "memory_id": memory_id,
        "summary": summary,
        "memory_type": memory_type,
        "classified_by": classified_by,
        "has_embedding": has_embedding,
        "mind_id": mind_id,
    }


def _match_stakeholders(query: str, stakeholders: list[dict], existing_content: list[str]) -> list[dict]:
    """Match query against stakeholder name/title/role via case-insensitive substring.

    Returns synthetic search results for matching stakeholders, excluding any
    whose name already appears in existing_content (dedup with vector results).
    """
    query_lower = query.lower()
    matches = []
    for s in stakeholders:
        name = s.get("name", "")
        title = s.get("title", "")
        role = s.get("role", "")
        searchable = f"{name} {title} {role}".lower()

        if not any(term in searchable for term in query_lower.split()):
            continue

        # Dedup: skip if this stakeholder's name already appears in vector results
        if any(name.lower() in c.lower() for c in existing_content if c):
            continue

        # Build content string from all stakeholder fields
        parts = [f"{name}"]
        if title:
            parts.append(f"Title: {title}")
        if role:
            parts.append(f"Role: {role}")
        for k, v in s.items():
            if k not in ("name", "title", "role") and v:
                parts.append(f"{k}: {v}")
        content = " | ".join(parts)

        matches.append({
            "memory_id": None,
            "content": content,
            "summary": f"{name} — {title}" if title else name,
            "memory_type": "stakeholder",
            "confidence": 1.0,
            "similarity": 1.0,
            "tags": [],
            "source_type": "brand_dna",
            "created_at": None,
        })
    return matches


def _search_memory(
    query: str,
    memory_type: str | None,
    limit: int,
    offset: int,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
) -> dict | list:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    if not query or not query.strip():
        return INVALID_QUERY()

    limit = min(max(1, limit), MAX_LIMIT)
    offset = max(0, offset)

    if memory_type is not None:
        cleaned = memory_type.strip().lower().replace(" ", "_")
        if cleaned not in VALID_MEMORY_TYPES:
            logger.warn(
                f"Invalid memory_type filter '{memory_type}', ignoring filter",
                mind_id=mind_id,
            )
            memory_type = None  # search without type filter
        else:
            memory_type = cleaned

    embedding = get_embedding(query, config)
    if embedding is None:
        logger.warn("Embedding service unreachable for search_memory", mind_id=mind_id)
        from coppermind_cmo.errors import SERVICE_UNAVAILABLE
        return SERVICE_UNAVAILABLE("Embedding service")

    # Build query with CTE for single embedding computation
    sql = (
        "WITH q AS (SELECT %s::vector AS qv) "
        "SELECT id, content, summary, memory_type, confidence, "
        "1 - (embedding <=> q.qv) AS similarity, "
        "tags, source_type, created_at "
        "FROM memories, q "
        "WHERE mind_id = %s AND is_current = true AND embedding IS NOT NULL "
        "AND 1 - (embedding <=> q.qv) >= %s "
    )
    params: list[Any] = [json.dumps(embedding), mind_id, SIMILARITY_THRESHOLD]

    if memory_type:
        sql += "AND memory_type = %s "
        params.append(memory_type)

    sql += "ORDER BY embedding <=> q.qv ASC LIMIT %s OFFSET %s"
    params.extend([limit, offset])

    rows = db.fetch_all(sql, params)

    # Update last_accessed_at for returned memories
    if rows:
        touch_memories(db, [str(r[0]) for r in rows])

    results = [
        {
            "memory_id": str(r[0]),
            "content": r[1],
            "summary": r[2],
            "memory_type": r[3],
            "confidence": float(r[4]),
            "similarity": round(float(r[5]), 4),
            "tags": r[6] if r[6] else [],
            "source_type": r[7],
            "created_at": r[8].isoformat() if r[8] else None,
        }
        for r in rows
    ]

    # Cross-reference brand DNA stakeholders when results are sparse or low quality
    should_check_brand_dna = (
        memory_type is None or memory_type == "stakeholder"
    ) and offset == 0
    if should_check_brand_dna:
        best_similarity = max((r["similarity"] for r in results), default=0.0)
        if len(results) < limit or best_similarity < BRAND_DNA_THRESHOLD:
            stakeholder_row = db.fetch_one(
                "SELECT stakeholders FROM client_minds WHERE id = %s",
                [mind_id],
            )
            raw = stakeholder_row[0] if stakeholder_row and stakeholder_row[0] else []
            stakeholders = raw if isinstance(raw, list) else []
            if stakeholders:
                existing_content = [r["content"] for r in results]
                brand_matches = _match_stakeholders(query, stakeholders, existing_content)
                results.extend(brand_matches)

    return results[:limit]


def _quick_note(
    content: str,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    if not content or not content.strip():
        return INVALID_INPUT("content cannot be empty")
    if len(content) > MAX_CONTENT_CHARS:
        return INVALID_INPUT(f"content exceeds {MAX_CONTENT_CHARS:,} character limit")

    summary = content[:QUICK_NOTE_SUMMARY_LEN]
    embedding = get_embedding(content, config)

    # Fetch cadence for quarter tagging
    cadence = get_mind_cadence(mind_id, db)
    quarter_year = cadence.get("year")
    quarter = cadence.get("quarter")
    sprint = cadence.get("sprint")

    from coppermind_cmo.server import get_last_tool_call
    follows_tool = get_last_tool_call()

    if embedding is not None:
        row = db.execute_returning(
            "INSERT INTO memories "
            "(mind_id, content, summary, memory_type, embedding, confidence, "
            "source_type, last_accessed_at, quarter_year, quarter, sprint, "
            "source_tool, follows_tool_call) "
            "VALUES (%s, %s, %s, 'fact', %s::vector, %s, 'quick_note', now(), %s, %s, %s, %s, %s) "
            "RETURNING id",
            [mind_id, content, summary, json.dumps(embedding), FALLBACK_CONFIDENCE,
             quarter_year, quarter, sprint, "quick_note", follows_tool],
        )
        if row is None:
            return tool_error("INTERNAL_ERROR", "Failed to store memory")
    else:
        row = db.execute_returning(
            "INSERT INTO memories "
            "(mind_id, content, summary, memory_type, confidence, "
            "source_type, last_accessed_at, quarter_year, quarter, sprint, "
            "source_tool, follows_tool_call) "
            "VALUES (%s, %s, %s, 'fact', %s, 'quick_note', now(), %s, %s, %s, %s, %s) "
            "RETURNING id",
            [mind_id, content, summary, FALLBACK_CONFIDENCE,
             quarter_year, quarter, sprint, "quick_note", follows_tool],
        )
        if row is None:
            return tool_error("INTERNAL_ERROR", "Failed to store memory")

    return {"memory_id": str(row[0]), "mind_id": mind_id}


def _hide_memory(
    memory_id: str,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    try:
        _uuid.UUID(memory_id)
    except ValueError:
        return INVALID_INPUT("Invalid memory_id format")

    # Verify memory exists and belongs to active mind
    row = db.fetch_one(
        "SELECT id, summary FROM memories WHERE id = %s AND mind_id = %s",
        [memory_id, mind_id],
    )
    if not row:
        return MEMORY_NOT_FOUND(memory_id)

    summary = row[1]

    # Set is_current = false (trigger handles updated_at)
    db.execute(
        "UPDATE memories SET is_current = false WHERE id = %s AND mind_id = %s",
        [memory_id, mind_id],
    )

    logger.info(f"Hidden memory: {summary}", mind_id=mind_id)

    return {
        "memory_id": memory_id,
        "hidden": True,
        "summary": summary,
    }


def register(mcp_server):
    """Register memory tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED

    @mcp_server.tool()
    def store_memory(
        content: str,
        memory_type: str | None = None,
        tags: list[str] | None = None,
        background: bool = False,
    ) -> dict:
        """Store a piece of client knowledge as a memory.

        For long content like meeting transcripts (over ~1000 words), use background=true
        so the user can keep working while extraction happens. They'll be notified when it's done.

        ## Transcript Ingestion

        When a user pastes a meeting transcript or long-form notes:

        1. Acknowledge immediately: "Got it — extracting key information in the background."
        2. Call store_memory with background=true. The server processes the transcript
           in a background thread and returns immediately with an estimate.
        3. Continue the conversation with the user — don't wait for extraction to finish.
           Move on to the next onboarding step (cadence, brand voice, etc.) or whatever they want to discuss.
        4. The next tool call you make will include a notification when processing is done.
           Share it with the user: "Done — extracted [N] memories from your transcript."

        Never show individual store_memory calls to the user. They don't need to see the sausage being made.

        If the response includes `notifications`, share each one with the user before proceeding.
        """
        set_last_tool_call("store_memory")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()

        # Background mode for long content
        if background and active_mind and len(content) > 4000:
            from coppermind_cmo.background import start_background_ingestion
            from coppermind_cmo.db import Database
            mind_id, mind_name = active_mind
            config = get_config()
            return start_background_ingestion(
                text=content,
                mind_id=mind_id,
                mind_name=mind_name,
                db_factory=lambda: Database(config),
                config=config,
                source_type="meeting",
            )

        result = _store_memory(
            content, memory_type, tags or [], get_db(), get_config(), active_mind,
            source_tool="store_memory",
        )
        return attach_notifications(result)

    @mcp_server.tool()
    def search_memory(
        query: str,
        memory_type: str | None = None,
        limit: int = 10,
        offset: int = 0,
    ) -> list | dict:
        """Semantic search across the active client's memories."""
        set_last_tool_call("search_memory")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        return _search_memory(
            query, memory_type, limit, offset, get_db(), get_config(), active_mind
        )

    @mcp_server.tool()
    def quick_note(content: str) -> dict:
        """Fast capture — no LLM call. For jotting down a thought during a session.

        If the response includes `notifications`, share each one with the user before proceeding.
        """
        set_last_tool_call("quick_note")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _quick_note(content, get_db(), get_config(), active_mind)
        return attach_notifications(result)

    @mcp_server.tool()
    def hide_memory(memory_id: str) -> dict:
        """Hide a memory so it no longer appears in search, meeting prep, or campaign history.

        If the response includes `notifications`, share each one with the user before proceeding.
        """
        set_last_tool_call("hide_memory")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _hide_memory(memory_id, get_db(), active_mind)
        return attach_notifications(result)
