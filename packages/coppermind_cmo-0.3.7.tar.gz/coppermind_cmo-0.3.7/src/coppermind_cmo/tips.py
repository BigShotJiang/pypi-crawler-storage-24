"""Daily tips for Coppermind CMO beta testers.

Shows one personalized tip per session via switch_client response.
Tip progress tracked per customer in Supabase customer_tips table.
"""

from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("tips")

TIP_TEMPLATES = [
    {
        "title": "Meeting prep",
        "body": "Before any client meeting, ask Coppermind for a focused brief with your topics.",
        "try_it": "Prep my meeting with [client] — we need to discuss [topic]",
    },
    {
        "title": "Transcript magic",
        "body": "Paste a meeting transcript and watch Coppermind extract decisions, action items, and preferences automatically.",
        "try_it": "Just paste any transcript right here. Or better yet, ask Coppermind to connect your note taking app.",
    },
    {
        "title": "Instant recall",
        "body": "Ask about anything from past meetings — Coppermind searches across all your stored knowledge.",
        "try_it": "What did we decide about [topic]?",
    },
    {
        "title": "Quick capture",
        "body": "After a call, capture key takeaways in seconds. No need to organize — Coppermind handles that.",
        "try_it": "Quick note: [contact] wants the media plan by Thursday",
    },
    {
        "title": "Build your agenda",
        "body": "Between meetings, add items to the agenda. They'll appear automatically in your next meeting prep.",
        "try_it": "Add [topic] to my next meeting agenda with [client]",
    },
    {
        "title": "Write in their voice",
        "body": "Need to draft something for a client? Coppermind knows their brand voice and recent context.",
        "try_it": "Write a follow-up email to [contact] about [topic] in [client]'s brand voice",
    },
    {
        "title": "Know your people",
        "body": "Ask about any stakeholder and get personality, role, relationship dynamics — not just their title.",
        "try_it": "Who is [contact] at [client]?",
    },
    {
        "title": "Switch instantly",
        "body": "Jump between clients without losing context. Each client has their own memory.",
        "try_it": "Switch to [client]. What's top of mind right now?",
    },
    {
        "title": "Save your briefs",
        "body": "Save a meeting brief and pull it up later — even on your phone before walking in.",
        "try_it": "Prep my meeting with [client] and save it",
    },
    {
        "title": "Quarter check",
        "body": "Ask what's on track and what's at risk for any client's current quarter.",
        "try_it": "What are our current quarter goals for [client]?",
    },
    {
        "title": "Brand voice check",
        "body": "Quick reference before writing content or reviewing creative.",
        "try_it": "What's [client]'s brand voice?",
    },
    {
        "title": "Campaign history",
        "body": "See how campaigns performed — metrics, outcomes, and learnings.",
        "try_it": "How did our campaigns perform this quarter for [client]?",
    },
    {
        "title": "Teach Coppermind",
        "body": "Explicitly tell Coppermind things it should remember. Preferences, constraints, relationship notes.",
        "try_it": "Remember: [contact] prefers data-driven presentations, max 10 slides",
    },
    {
        "title": "Deep search",
        "body": "Search across all memories semantically — Coppermind finds related context even with different wording.",
        "try_it": "Search for anything related to [topic] for [client]",
    },
    {
        "title": "Add another client",
        "body": "Ready to bring on your next client? The more clients you set up, the more powerful the context switching becomes.",
        "try_it": "Let's set up a new client called [name]",
    },
]

# Track whether we've shown a tip this session
_tip_shown_this_session = False


def reset_session_tip():
    """Reset the session tip flag. Called at module level for testing."""
    global _tip_shown_this_session
    _tip_shown_this_session = False


def _personalize_tip(tip: dict, mind_name: str, company_info: dict, recent_topic: str | None) -> dict:
    """Replace placeholders with real client data."""
    contact_name = None
    if company_info and isinstance(company_info, dict):
        pc = company_info.get("primary_contact")
        if isinstance(pc, dict):
            contact_name = pc.get("name")

    try_it = tip["try_it"]
    try_it = try_it.replace("[client]", mind_name)
    try_it = try_it.replace("[contact]", contact_name or "your main contact")
    try_it = try_it.replace("[topic]", recent_topic or "a recent discussion topic")

    return {
        "title": tip["title"],
        "body": tip["body"],
        "try_it": try_it,
    }


def _get_recent_topic(mind_id: str, db: Database) -> str | None:
    """Get a recent memory's summary to use as a topic reference."""
    row = db.fetch_one(
        "SELECT summary FROM memories "
        "WHERE mind_id = %s AND is_current = true AND summary IS NOT NULL "
        "ORDER BY created_at DESC LIMIT 1",
        [mind_id],
    )
    if row and row[0]:
        topic = row[0]
        # Trim to something conversational
        if len(topic) > 60:
            topic = topic[:57] + "..."
        return topic
    return None


def get_next_tip(
    customer_id: str | None,
    mind_id: str,
    mind_name: str,
    company_info: dict,
    db: Database,
) -> dict | None:
    """Get the next unseen tip for this customer, personalized for the active mind.

    Returns None if:
    - customer_id is unknown (self-hosted mode)
    - all tips have been shown
    - a tip was already shown this session
    - any error occurs (never break switch_client for tips)
    """
    global _tip_shown_this_session

    if _tip_shown_this_session:
        return None

    if not customer_id:
        return None

    try:
        # Check if customer_tips table exists
        table_check = db.fetch_one(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_name = 'customer_tips'"
        )
        if not table_check:
            return None

        # Get current tip index
        row = db.fetch_one(
            "SELECT tip_index FROM customer_tips WHERE customer_id = %s",
            [customer_id],
        )

        if row:
            tip_index = row[0]
        else:
            tip_index = 0
            db.execute(
                "INSERT INTO customer_tips (customer_id, tip_index) VALUES (%s, 0)",
                [customer_id],
            )

        # All tips shown
        if tip_index >= len(TIP_TEMPLATES):
            return None

        tip_template = TIP_TEMPLATES[tip_index]

        # Personalize
        recent_topic = _get_recent_topic(mind_id, db)
        tip = _personalize_tip(tip_template, mind_name, company_info, recent_topic)

        # Increment
        db.execute(
            "UPDATE customer_tips SET tip_index = %s, last_shown_at = now() "
            "WHERE customer_id = %s",
            [tip_index + 1, customer_id],
        )

        _tip_shown_this_session = True

        return {
            "number": tip_index + 1,
            "total": len(TIP_TEMPLATES),
            **tip,
        }

    except Exception as e:
        logger.warn(f"Failed to get tip: {e}")
        return None
