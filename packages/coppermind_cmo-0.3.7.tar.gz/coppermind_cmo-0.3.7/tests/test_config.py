"""Tests for config.py — COPPERMIND_* env var parsing and provider detection."""

import os
import pytest
from unittest.mock import patch
from coppermind_cmo.config import Config


class TestConfigDefaults:
    def test_pg_host_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_host == "localhost"

    def test_pg_port_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_port == 5432

    def test_pg_db_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_db == "coppermind_cmo"

    def test_pg_user_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_user == "coppermind"

    def test_embedding_host_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.embedding_host == "localhost"

    def test_embedding_port_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.embedding_port == 8400

    def test_ollama_host_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.ollama_host == "localhost"

    def test_ollama_port_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.ollama_port == 11434

    def test_ollama_model_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.ollama_model == "gemma3:12b"


class TestConfigFromEnv:
    def test_reads_pg_host(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_HOST": "db.example.com"}):
            c = Config()
            assert c.pg_host == "db.example.com"

    def test_reads_pg_port(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_PORT": "5433"}):
            c = Config()
            assert c.pg_port == 5433

    def test_reads_pg_password(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_PASSWORD": "secret"}):
            c = Config()
            assert c.pg_password == "secret"

    def test_invalid_port_raises(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_PORT": "not_a_number"}):
            with pytest.raises(ValueError):
                Config()

    def test_invalid_embedding_port_raises(self):
        with patch.dict(os.environ, {"COPPERMIND_EMBEDDING_PORT": "abc"}):
            with pytest.raises(ValueError):
                Config()

    def test_invalid_ollama_port_raises(self):
        with patch.dict(os.environ, {"COPPERMIND_OLLAMA_PORT": "xyz"}):
            with pytest.raises(ValueError):
                Config()


class TestPgDsnRemoved:
    def test_config_has_no_pg_dsn_property(self):
        """Fix 1.1: pg_dsn property was removed to prevent password leaks."""
        from coppermind_cmo.config import Config
        assert not hasattr(Config, 'pg_dsn')


class TestConfigProperties:
    def test_embedding_url(self):
        with patch.dict(os.environ, {"COPPERMIND_EMBEDDING_HOST": "gpu", "COPPERMIND_EMBEDDING_PORT": "9000"}):
            c = Config()
            assert c.embedding_url == "http://gpu:9000"

    def test_ollama_url(self):
        with patch.dict(os.environ, {"COPPERMIND_OLLAMA_HOST": "llm", "COPPERMIND_OLLAMA_PORT": "11435"}):
            c = Config()
            assert c.ollama_url == "http://llm:11435"


class TestProviderDetection:
    def test_api_key_sets_gateway_providers(self):
        with patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True):
            c = Config()
            assert c.llm_provider == "gateway"
            assert c.embedding_provider == "gateway"
            assert c.embedding_dims == 512
            assert c.max_prompt_chars == 40000

    def test_ollama_host_sets_ollama_provider(self):
        with patch.dict(os.environ, {"COPPERMIND_OLLAMA_HOST": "llm-server"}, clear=True):
            c = Config()
            assert c.llm_provider == "ollama"
            assert c.embedding_dims == 384
            assert c.max_prompt_chars == 13000

    def test_embedding_host_sets_local_provider(self):
        with patch.dict(os.environ, {"COPPERMIND_EMBEDDING_HOST": "gpu-server"}, clear=True):
            c = Config()
            assert c.embedding_provider == "local"
            assert c.embedding_dims == 384

    def test_no_env_vars_gives_none_providers(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.llm_provider is None
            assert c.embedding_provider is None
            assert c.embedding_dims == 384
            assert c.max_prompt_chars == 13000

    def test_api_key_overrides_ollama_host(self):
        """API key takes precedence over self-hosted env vars."""
        with patch.dict(os.environ, {
            "COPPERMIND_API_KEY": "key",
            "COPPERMIND_OLLAMA_HOST": "llm-server",
        }, clear=True):
            c = Config()
            assert c.llm_provider == "gateway"
            assert c.embedding_provider == "gateway"

    def test_gateway_url_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.gateway_url == "https://api.coppermind.app"

    def test_gateway_url_configurable(self):
        with patch.dict(os.environ, {"COPPERMIND_GATEWAY_URL": "http://localhost:8787"}, clear=True):
            c = Config()
            assert c.gateway_url == "http://localhost:8787"


class TestDatabaseUrlParsing:
    def test_parse_database_url(self):
        """Verify _parse_database_url correctly populates config fields."""
        from coppermind_cmo.server import _parse_database_url
        from unittest.mock import MagicMock
        config = MagicMock()
        _parse_database_url(config, "postgres://myuser:mypass@db.supabase.co:6543/postgres")
        assert config.pg_host == "db.supabase.co"
        assert config.pg_port == 6543
        assert config.pg_db == "postgres"
        assert config.pg_user == "myuser"
        assert config.pg_password == "mypass"
