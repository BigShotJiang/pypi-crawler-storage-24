"""Tests for prep_meeting and get_campaign_history tools."""

import json
import pytest
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch
from coppermind_cmo.tools.intelligence import (
    _prep_meeting, _get_campaign_history, _get_last_brief,
    _rerank_by_topic,
    _enforce_token_budget, _collect_type_balanced,
    _quarter_weight, _collect_meeting_memories, _build_brief_prompt,
    _build_fallback_brief,
    PERMANENT_TYPES, TEMPORAL_TYPES,
)


def _dt(day: int) -> datetime:
    """Helper to create a timezone-aware datetime for March 2026."""
    return datetime(2026, 3, day, 10, 0, 0, tzinfo=timezone.utc)


def _make_config():
    config = MagicMock()
    config.llm_provider = "ollama"
    config.ollama_url = "http://localhost:11434"
    config.ollama_model = "gemma3:12b"
    config.embedding_provider = "local"
    config.embedding_url = "http://localhost:8400"
    config.embedding_dims = 384
    config.max_prompt_chars = 13000
    return config


class TestConstantValues:
    def test_max_prompt_chars_is_13000(self):
        """Fix 4.4: Must be 13000 for SentencePiece tokenizer, not 16000."""
        from coppermind_cmo.tools.intelligence import MAX_PROMPT_CHARS
        assert MAX_PROMPT_CHARS == 13000

    def test_recency_and_similarity_weights_sum_to_one(self):
        from coppermind_cmo.tools.intelligence import RECENCY_WEIGHT, SIMILARITY_WEIGHT
        assert RECENCY_WEIGHT + SIMILARITY_WEIGHT == 1.0


class TestGetCampaignHistory:
    def test_requires_active_mind(self):
        db = MagicMock()
        result = _get_campaign_history(10, 0, db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_returns_campaign_outcomes(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "Q1 email: 34% open rate", "Q1 email results",
             ["email"], _dt(5)),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert len(result) == 1
        assert result[0]["memory_id"] == "mem-1"
        assert result[0]["content"] == "Q1 email: 34% open rate"
        assert "2026-03-05" in result[0]["created_at"]

    def test_empty_result(self):
        db = MagicMock()
        db.fetch_all.return_value = []
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result == []
        db.execute.assert_not_called()

    def test_updates_last_accessed(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "content", "summary", [], _dt(5)),
        ]
        mind = ("mind-1", "Acme")
        _get_campaign_history(10, 0, db, mind)
        # Should have called execute for last_accessed_at update
        db.execute.assert_called_once()

    def test_none_tags_returns_empty_list(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "content", "summary", None, _dt(5)),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result[0]["tags"] == []

    def test_none_created_at_returns_none(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "content", "summary", ["tag"], None),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result[0]["created_at"] is None


def _context_row(cadence=None, company_info=None, stakeholders=None):
    """Helper to build a context_row tuple for prep_meeting mocks.

    Format: (name, brand_voice, brand_positioning, approved_messaging,
             stakeholders, content_themes, cadence, company_info)
    """
    return (
        "Acme",
        json.dumps({}),
        json.dumps({}),
        json.dumps({}),
        json.dumps(stakeholders or []),
        [],
        cadence or {},
        company_info or {},
    )


def _mem_row(mid, content, summary, mem_type, day, embedding=None, qy=None, q=None, s=None):
    """Helper to build a memory row from _collect_meeting_memories DB queries.

    Format: (id, content, summary, memory_type, created_at, embedding,
             quarter_year, quarter, sprint)
    """
    return (mid, content, summary, mem_type, _dt(day), embedding, qy, q, s)


class TestPrepMeeting:
    def test_requires_active_mind(self):
        db = MagicMock()
        config = _make_config()
        result = _prep_meeting(None, None, 20, db, config, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_insufficient_data_returns_raw(self):
        db = MagicMock()
        config = _make_config()

        # _collect_meeting_memories: cadence lookup, agenda, commitments, permanent, backfill
        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments (no cadence fallback)
            [_mem_row("m1", "c1", "s1", "fact", 1)],  # permanent
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 20, db, config, mind)
        assert result["mode"] == "raw"
        assert result["reason"] == "insufficient_data"
        assert result["brief_markdown"] is None
        assert result["memory_count"] == 1

    def test_no_memories_returns_raw(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # permanent
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 20, db, config, mind)
        assert result["mode"] == "raw"
        assert result["reason"] == "insufficient_data"
        assert result["memory_count"] == 0

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nContent here")
    def test_synthesized_brief(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [  # commitments
                _mem_row("m3", "c3", "s3", "commitment", 3),
                _mem_row("m4", "c4", "s4", "commitment", 4),
            ],
            [  # permanent
                _mem_row("m5", "c5", "s5", "fact", 5),
            ],
            [  # backfill
                _mem_row("m1", "c1", "s1", "decision", 1),
                _mem_row("m2", "c2", "s2", "decision", 2),
            ],
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "synthesized"
        assert result["brief_markdown"] == "## Brief\nContent here"
        assert result["client_name"] == "Acme"
        assert result["memory_count"] == 5
        mock_llm.assert_called_once()

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value=None)
    def test_llm_unavailable_returns_raw(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "fact", 2),
                _mem_row("m3", "c3", "s3", "stakeholder", 3),
            ],
            [_mem_row("m4", "c4", "s4", "decision", 4)],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "fallback"
        assert result["reason"] == "llm_unavailable"
        assert result["brief_markdown"] is not None
        assert result["memory_count"] == 4

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nDone")
    def test_memories_by_type_structure(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(stakeholders=[{"name": "Sarah", "title": "VP"}]),
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m3", "c3", "s3", "stakeholder", 3),
            ],
            [  # backfill
                _mem_row("m1", "c1", "s1", "decision", 1),
                _mem_row("m2", "c2", "s2", "decision", 2),
            ],
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert "decision" in result["memories_by_type"]
        assert "stakeholder" in result["memories_by_type"]
        assert len(result["memories_by_type"]["decision"]) == 2
        assert len(result["memories_by_type"]["stakeholder"]) == 1
        assert result["stakeholders"] == [{"name": "Sarah", "title": "VP"}]


class TestTopicReranking:
    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=None)
    def test_skips_reranking_when_embedding_unavailable(self, mock_emb):
        config = _make_config()
        memories = [
            ("m1", "c1", "s1", "decision", _dt(1), "type_balanced", None),
            ("m2", "c2", "s2", "fact", _dt(2), "fill", None),
        ]
        result = _rerank_by_topic(memories, "Q2 planning", config)
        assert len(result) == 2
        assert result[0][0] == "m1"

    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=[0.5, 0.5])
    def test_preserves_type_balanced_order(self, mock_emb):
        config = _make_config()
        memories = [
            ("m1", "c1", "s1", "decision", _dt(1), "type_balanced", None),
            ("m2", "c2", "s2", "decision", _dt(2), "type_balanced", None),
            ("m3", "c3", "s3", "fact", _dt(3), "fill", None),
        ]
        result = _rerank_by_topic(memories, "ads", config)
        assert result[0][0] == "m1"
        assert result[1][0] == "m2"
        assert result[0][5] == "type_balanced"


class TestTokenBudget:
    def test_no_truncation_when_under_budget(self):
        memories = [
            ("m1", "short", "sum1", "decision", _dt(1), "type_balanced", None),
            ("m2", "short", "sum2", "fact", _dt(2), "fill", None),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        result = _enforce_token_budget(memories, brand_dna, "Acme")
        assert len(result) == 2

    def test_drops_fill_memories_when_over_budget(self):
        type_balanced = [
            ("m1", "x" * 100, "s1", "decision", _dt(1), "type_balanced", None),
        ]
        fill = [
            (f"f{i}", "x" * 2000, f"long summary {i} " * 50, "fact", _dt(i + 1), "fill", None)
            for i in range(20)
        ]
        memories = type_balanced + fill
        brand_dna = {"brand_voice": {}}
        result = _enforce_token_budget(memories, brand_dna, "Acme")
        assert len(result) < len(memories)
        assert any(m[0] == "m1" for m in result)

    def test_type_balanced_exceeds_budget_truncates(self):
        type_balanced = [
            (f"tb{i}", "x" * 2000, f"long summary {i} " * 50, "decision", _dt(i + 1), "type_balanced", None)
            for i in range(20)
        ]
        brand_dna = {"brand_voice": {}}
        result = _enforce_token_budget(type_balanced, brand_dna, "Acme")
        # New priority-based enforcement drops lowest-priority memories
        assert len(result) < len(type_balanced)
        for m in result:
            assert m[5] == "type_balanced"

    def test_respects_custom_max_chars(self):
        """When max_chars is larger, more memories fit."""
        type_balanced = [
            ("m1", "x" * 100, "s1", "decision", _dt(1), "type_balanced", None),
        ]
        fill = [
            (f"f{i}", "x" * 2000, f"long summary {i} " * 50, "fact", _dt(i + 1), "fill", None)
            for i in range(20)
        ]
        memories = type_balanced + fill
        brand_dna = {"brand_voice": {}}
        result_small = _enforce_token_budget(memories, brand_dna, "Acme", max_chars=13000)
        result_large = _enforce_token_budget(memories, brand_dna, "Acme", max_chars=40000)
        assert len(result_large) >= len(result_small)


class TestCollectTypeBalanced:
    def test_no_populated_types_returns_empty(self):
        db = MagicMock()
        db.fetch_all.return_value = []
        result = _collect_type_balanced("mind-1", 20, db)
        assert result == []

    def test_single_type_gets_full_allocation(self):
        db = MagicMock()
        db.fetch_all.side_effect = [
            [("decision",)],
            [
                ("m1", "c1", "s1", "decision", _dt(1), None),
                ("m2", "c2", "s2", "decision", _dt(2), None),
            ],
            [],
        ]
        result = _collect_type_balanced("mind-1", 20, db)
        assert len(result) == 2
        for m in result:
            assert m[5] == "type_balanced"

    def test_deduplication_across_fill(self):
        db = MagicMock()
        db.fetch_all.side_effect = [
            [("decision",)],
            [("m1", "c1", "s1", "decision", _dt(1), None)],
            [("m2", "c2", "s2", "fact", _dt(2), None)],
        ]
        result = _collect_type_balanced("mind-1", 20, db)
        ids = [m[0] for m in result]
        assert ids.count("m1") == 1
        assert ids.count("m2") == 1
        assert len(result) == 2
        fill_call = db.fetch_all.call_args_list[2]
        assert "m1" in fill_call[0][1][1]

    def test_limit_less_than_populated_types_uses_fill_only(self):
        db = MagicMock()
        db.fetch_all.side_effect = [
            [("decision",), ("commitment",), ("fact",), ("preference",)],
            [],
            [],
            [],
            [],
            [
                ("m1", "c1", "s1", "decision", _dt(1), None),
                ("m2", "c2", "s2", "fact", _dt(2), None),
            ],
        ]
        result = _collect_type_balanced("mind-1", 2, db)
        assert len(result) == 2
        assert all(m[5] == "fill" for m in result)


class TestRerankAdditions:
    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=[0.5, 0.5])
    def test_no_fill_memories_returns_unchanged(self, mock_emb):
        config = _make_config()
        memories = [
            ("m1", "c1", "s1", "decision", _dt(1), "type_balanced", None),
            ("m2", "c2", "s2", "fact", _dt(2), "type_balanced", None),
        ]
        result = _rerank_by_topic(memories, "Q2 planning", config)
        assert len(result) == 2
        assert result[0][0] == "m1"
        assert result[1][0] == "m2"

    @patch("coppermind_cmo.tools.intelligence.get_embedding")
    def test_identical_timestamps_handled(self, mock_emb):
        mock_emb.return_value = [0.5, 0.5]
        config = _make_config()
        same_time = _dt(5)
        memories = [
            ("m1", "c1", "s1", "fact", same_time, "fill", None),
            ("m2", "c2", "s2", "fact", same_time, "fill", None),
            ("m3", "c3", "s3", "fact", same_time, "fill", None),
        ]
        result = _rerank_by_topic(memories, "ads", config)
        assert len(result) == 3

    @patch("coppermind_cmo.tools.intelligence.get_embedding")
    def test_mixed_embedding_availability(self, mock_emb):
        import json
        mock_emb.return_value = [1.0, 0.0]
        config = _make_config()
        stored_emb = json.dumps([0.8, 0.2])
        memories = [
            ("m1", "c1", "s1", "fact", _dt(1), "fill", stored_emb),
            ("m2", "c2", "s2", "fact", _dt(2), "fill", None),
        ]
        result = _rerank_by_topic(memories, "ads", config)
        assert len(result) == 2
        mock_emb.assert_called_once()


class TestPrepMeetingAdditions:
    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nContent here")
    def test_boundary_exactly_3_memories_attempts_synthesis(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "fact", 2),
                _mem_row("m3", "c3", "s3", "fact", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "synthesized"
        assert result["memory_count"] == 3
        mock_llm.assert_called_once()

    def test_brand_row_none_returns_error(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            None,  # context_row (not found — error path)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "fact", 2),
                _mem_row("m3", "c3", "s3", "fact", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"


class TestStoredEmbeddingReranking:
    def test_rerank_uses_stored_embeddings_not_http_calls(self, mock_config):
        from coppermind_cmo.tools.intelligence import _rerank_by_topic
        from unittest.mock import patch
        import json

        topic_embedding = [0.1] * 384
        stored_embedding = json.dumps([0.2] * 384)

        memories = [
            ("id1", "content1", "summary1", "fact", _dt(1), "fill", stored_embedding),
            ("id2", "content2", "summary2", "fact", _dt(2), "fill", stored_embedding),
        ]

        with patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=topic_embedding) as mock_get_emb:
            result = _rerank_by_topic(memories, "test topic", mock_config)

        mock_get_emb.assert_called_once_with("test topic", mock_config)
        assert len(result) == 2


class TestQuarterWeight:
    def test_quarter_weight_current(self):
        assert _quarter_weight(2026, 1, 2026, 1) == 1.0

    def test_quarter_weight_previous(self):
        assert _quarter_weight(2025, 4, 2026, 1) == 0.7

    def test_quarter_weight_old(self):
        assert _quarter_weight(2024, 4, 2026, 1) == 0.1

    def test_quarter_weight_untagged(self):
        assert _quarter_weight(None, None, 2026, 1) == 0.5

    def test_quarter_weight_future(self):
        assert _quarter_weight(2026, 2, 2026, 1) == 1.0


class TestCollectMeetingMemories:
    @patch("coppermind_cmo.tools.intelligence.get_embedding")
    def test_collect_meeting_memories_with_topics(self, mock_emb):
        mock_emb.return_value = [0.5, 0.5]
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence (no cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            # topic search returns 2 results
            [
                _mem_row("t1", "topic content 1", "topic summary 1", "decision", 1, None, 2026, 1, 1),
                _mem_row("t2", "topic content 2", "topic summary 2", "fact", 2, None, 2026, 1, 2),
            ],
            [],  # commitments (no cadence fallback)
            [],  # permanent
            [],  # backfill
        ]

        result = _collect_meeting_memories("mind-1", ["Q1 results"], 50, db, config)
        ids = [m[0] for m in result]
        assert "t1" in ids
        assert "t2" in ids

    def test_collect_meeting_memories_agenda_items(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [  # agenda returns 2 items
                _mem_row("a1", "agenda item 1", "agenda summary 1", "commitment", 5),
                _mem_row("a2", "agenda item 2", "agenda summary 2", "decision", 6),
            ],
            [],  # commitments (no cadence fallback)
            [],  # permanent
            [],  # backfill
        ]

        result = _collect_meeting_memories("mind-1", None, 50, db, config)
        assert len(result) >= 2
        # Agenda items should be first
        assert result[0][5] == "agenda"
        assert result[1][5] == "agenda"
        assert result[0][0] == "a1"

    def test_collect_meeting_memories_commitments(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            ({"type": "eos", "year": 2026, "quarter": 1},),  # cadence with year/quarter
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [  # commitments
                _mem_row("c1", "commitment 1", "commit summary 1", "commitment", 3, None, 2026, 1, 2),
            ],
            [],  # permanent
            [],  # backfill
        ]

        result = _collect_meeting_memories("mind-1", None, 50, db, config)
        commitment_mems = [m for m in result if m[5] == "commitment"]
        assert len(commitment_mems) == 1
        assert commitment_mems[0][0] == "c1"

    def test_collect_meeting_memories_permanent(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # no cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments (no cadence fallback)
            [  # permanent
                _mem_row("p1", "stakeholder info", "stakeholder summary", "stakeholder", 1),
                _mem_row("p2", "some fact", "fact summary", "fact", 2),
            ],
            [],  # backfill
        ]

        result = _collect_meeting_memories("mind-1", None, 50, db, config)
        permanent_mems = [m for m in result if m[5] == "permanent"]
        assert len(permanent_mems) == 2
        perm_ids = [m[0] for m in permanent_mems]
        assert "p1" in perm_ids
        assert "p2" in perm_ids

    def test_collect_meeting_memories_no_cadence(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence empty
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [  # commitments (recency fallback since no cadence)
                _mem_row("c1", "commitment 1", "commit summary", "commitment", 4),
            ],
            [],  # permanent
            [],  # backfill
        ]

        result = _collect_meeting_memories("mind-1", None, 50, db, config)
        # Function should work without cadence (no quarter weighting applied)
        assert len(result) >= 1
        commitment_mems = [m for m in result if m[5] == "commitment"]
        assert len(commitment_mems) == 1


class TestPrepMeetingEnhanced:
    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nTopic results")
    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=[0.5, 0.5])
    def test_prep_meeting_with_topics(self, mock_emb, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence via _get_mind_cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            # topic search for "Q1 results"
            [
                _mem_row("t1", "Q1 revenue up", "Q1 summary", "decision", 1, None, 2026, 1, 1),
                _mem_row("t2", "Q1 costs down", "costs summary", "fact", 2, None, 2026, 1, 2),
            ],
            # topic search for "ad budget"
            [
                _mem_row("t3", "ad spend info", "ad summary", "decision", 3, None, 2026, 1, 3),
            ],
            [],  # commitments (no cadence fallback)
            [],  # permanent
            [],  # backfill
        ]

        mind = ("mind-1", "Acme")
        result = _prep_meeting(["Q1 results", "ad budget"], None, 50, db, config, mind)
        assert result["mode"] == "synthesized"

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nReview brief")
    def test_prep_meeting_with_meeting_type(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "fact", 3),
            ],
            [],  # backfill
        ]

        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, "review", 50, db, config, mind)
        # Verify call_llm was called with a prompt containing "review"
        prompt_arg = mock_llm.call_args[0][0]
        assert "review" in prompt_arg

    def test_prep_meeting_invalid_meeting_type(self):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, "invalid", 50, db, config, mind)
        assert result["code"] == "INVALID_INPUT"

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nBackward compat")
    def test_prep_meeting_backward_compatible(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]

        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "synthesized"
        assert result["client_name"] == "Acme"


class TestBuildBriefPromptEnhanced:
    def test_build_brief_prompt_with_cadence(self):
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        memories = [
            ("m1", "content1", "summary1", "decision", _dt(1), "permanent", None, 2026, 1, 4),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme", cadence=cadence)
        assert "EOS Position" in prompt

    def test_build_brief_prompt_with_topics(self):
        memories = [
            ("m1", "content1", "summary1", "decision", _dt(1), "topic", None, 2026, 1, 1),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme", topics=["ads", "SEO"])
        assert "Discussion Topics" in prompt
        assert "ads" in prompt
        assert "SEO" in prompt


class TestBriefSprintNone:
    """Fix #4: Sprint None of None should not appear in brief header."""

    def test_no_sprint_data_omits_sprint_line(self):
        """When sprint/sprints_per_quarter are None, omit sprint from header."""
        cadence = {"type": "eos", "year": 2026, "quarter": 1}
        memories = [
            ("m1", "content1", "summary1", "decision", _dt(1), "permanent", None, 2026, 1, None),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme", cadence=cadence)
        assert "Sprint None" not in prompt
        assert "None of None" not in prompt
        assert "EOS Position" in prompt
        assert "2026 Q1" in prompt

    def test_with_sprint_data_shows_sprint(self):
        """When sprint and sprints_per_quarter are set, show them."""
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        memories = [
            ("m1", "content1", "summary1", "decision", _dt(1), "permanent", None, 2026, 1, 4),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme", cadence=cadence)
        assert "Sprint 4 of 6" in prompt
        assert "Sprint None" not in prompt

    def test_sprint_only_no_sprints_per_quarter(self):
        """When sprint is set but sprints_per_quarter is not, omit sprint info."""
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4}
        memories = [
            ("m1", "content1", "summary1", "decision", _dt(1), "permanent", None, 2026, 1, 4),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme", cadence=cadence)
        assert "None" not in prompt

    def test_no_cadence_at_all(self):
        """When cadence is empty, no position line at all."""
        memories = [
            ("m1", "content1", "summary1", "decision", _dt(1), "permanent", None, None, None, None),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme", cadence={})
        assert "EOS Position" not in prompt
        assert "Sprint" not in prompt


class TestBriefActionItems:
    """Fix #2: Brief prompt should include an Action Items section with checkboxes."""

    def test_action_items_section_in_prompt(self):
        """The brief prompt must include an Action Items section."""
        memories = [
            ("m1", "content1", "summary1", "commitment", _dt(1), "commitment", None, 2026, 1, 1),
            ("m2", "content2", "summary2", "fact", _dt(2), "permanent", None, 2026, 1, 1),
            ("m3", "content3", "summary3", "stakeholder", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme")
        assert "Action Items" in prompt

    def test_action_items_checkbox_format_in_prompt(self):
        """The brief prompt must instruct checkbox format for action items."""
        memories = [
            ("m1", "content1", "summary1", "commitment", _dt(1), "commitment", None, 2026, 1, 1),
            ("m2", "content2", "summary2", "fact", _dt(2), "permanent", None, 2026, 1, 1),
            ("m3", "content3", "summary3", "stakeholder", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme")
        assert "- [ ]" in prompt or "checkbox" in prompt.lower()

    def test_action_items_before_current_quarter_focus(self):
        """Action Items should appear after Key Stakeholders and before Current Quarter Focus."""
        memories = [
            ("m1", "content1", "summary1", "commitment", _dt(1), "commitment", None, 2026, 1, 1),
            ("m2", "content2", "summary2", "fact", _dt(2), "permanent", None, 2026, 1, 1),
            ("m3", "content3", "summary3", "stakeholder", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brand_dna = {"brand_voice": {}, "brand_positioning": {}}
        prompt = _build_brief_prompt(memories, brand_dna, "Acme")
        stakeholders_pos = prompt.index("Key Stakeholders")
        action_items_pos = prompt.index("Action Items")
        quarter_focus_pos = prompt.index("Current Quarter Focus")
        assert stakeholders_pos < action_items_pos < quarter_focus_pos


class TestEnforceTokenBudgetPriority:
    def test_enforce_token_budget_priority(self):
        """Verify backfill dropped before permanent, permanent before topic, topic before agenda."""
        memories = [
            ("a1", "agenda content", "agenda summary", "commitment", _dt(1), "agenda", None, 2026, 1, 1),
            ("t1", "topic content", "topic summary", "decision", _dt(2), "topic", None, 2026, 1, 2),
            ("c1", "commit content", "commit summary", "commitment", _dt(3), "commitment", None, 2026, 1, 3),
            ("p1", "permanent content", "permanent summary", "fact", _dt(4), "permanent", None, 2026, 1, 4),
            ("b1", "x" * 3000, "backfill summary " * 50, "decision", _dt(5), "backfill", None, 2026, 1, 5),
        ]
        brand_dna = {"brand_voice": {}}

        # Use a very low max_chars to force dropping
        result = _enforce_token_budget(memories, brand_dna, "Acme", max_chars=800)

        result_ids = [m[0] for m in result]
        result_tags = [m[5] for m in result]

        # backfill should be dropped before permanent
        if "b1" not in result_ids and "p1" in result_ids:
            pass  # correct: backfill dropped first
        elif "b1" in result_ids and "p1" in result_ids:
            pass  # both fit, that's fine
        else:
            # If permanent is dropped, backfill must also be dropped
            assert "b1" not in result_ids

        # If topic is dropped, backfill and permanent must also be dropped
        if "t1" not in result_ids:
            assert "b1" not in result_ids
            assert "p1" not in result_ids

        # agenda should be last to be dropped
        if len(result) > 0:
            # If anything survived, agenda should be among survivors
            if "a1" not in result_ids:
                # agenda was dropped — everything else must be too
                assert len(result_ids) == 0 or all(
                    tag in ("agenda",) for tag in result_tags
                )


class TestPrepMeetingSave:
    """Fix #5: prep_meeting with save=True persists the brief."""

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nSaved content")
    def test_save_true_stores_brief(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence via _get_mind_cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        db.execute_returning.return_value = ("brief-uuid",)
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind, save=True)
        assert result["mode"] == "synthesized"
        assert result.get("brief_id") == "brief-uuid"
        assert result["saved"] is True
        # Verify INSERT was called
        db.execute_returning.assert_called_once()
        insert_sql = db.execute_returning.call_args[0][0]
        assert "meeting_briefs" in insert_sql

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value="## Brief\nNot saved")
    def test_save_false_does_not_store(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind, save=False)
        assert result["mode"] == "synthesized"
        assert "brief_id" not in result
        db.execute_returning.assert_not_called()

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value=None)
    def test_save_true_raw_mode_does_not_store(self, mock_llm):
        """When LLM is unavailable and mode is raw, don't save even if save=True."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind, save=True)
        assert result["mode"] == "fallback"
        assert "brief_id" not in result
        assert result["saved"] is False
        db.execute_returning.assert_not_called()


class TestGetLastBrief:
    """Fix #5: get_last_brief retrieves the most recent saved brief."""

    def test_requires_active_mind(self):
        db = MagicMock()
        result = _get_last_brief(db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_returns_last_brief(self):
        db = MagicMock()
        created = _dt(5)
        db.fetch_one.return_value = (
            "brief-uuid", "## Brief\nContent", "review", ["topic1"], 10, created
        )
        mind = ("mind-1", "Acme")
        result = _get_last_brief(db, mind)
        assert result["brief_id"] == "brief-uuid"
        assert result["brief_markdown"] == "## Brief\nContent"
        assert result["meeting_type"] == "review"
        assert result["topics"] == ["topic1"]

    def test_no_brief_found(self):
        db = MagicMock()
        db.fetch_one.return_value = None
        mind = ("mind-1", "Acme")
        result = _get_last_brief(db, mind)
        assert result["brief_markdown"] is None
        assert result["message"] is not None


class TestFallbackBrief:
    """Fix #2: template-based brief when LLM is unavailable."""

    def test_basic_fallback_structure(self):
        """Fallback brief has headers and content."""
        memories = [
            ("m1", "Ben will send proposal by Friday", "Ben sends proposal", "commitment", _dt(1), "commitment", None, 2026, 1, 1),
            ("m2", "Pausing LinkedIn ads", "Pause LinkedIn", "decision", _dt(2), "permanent", None, 2026, 1, 1),
            ("m3", "Sarah Chen is VP Marketing", "Sarah is VP", "stakeholder", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brand_dna = {
            "brand_voice": {},
            "stakeholders": [{"name": "Sarah Chen", "title": "VP Marketing", "role": "primary contact"}],
        }
        brief = _build_fallback_brief(memories, brand_dna, "Acme")
        assert "# Meeting Brief: Acme" in brief
        assert "## Key Stakeholders" in brief
        assert "Sarah Chen" in brief
        assert "## Action Items" in brief
        assert "- [ ]" in brief
        assert "## Recent Decisions" in brief
        assert "Template-generated" in brief

    def test_fallback_with_no_memories(self):
        """Fallback brief with zero memories shows message."""
        brief = _build_fallback_brief([], {"stakeholders": []}, "Empty Client")
        assert "No memories available" in brief

    def test_fallback_with_cadence(self):
        """Fallback includes EOS position when cadence is set."""
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        brief = _build_fallback_brief([], {"stakeholders": []}, "Acme", cadence=cadence)
        assert "Sprint 4 of 6" in brief


class TestPrepMeetingFallback:
    """prep_meeting returns fallback brief instead of null when LLM is down."""

    @patch("coppermind_cmo.tools.intelligence.call_llm", return_value=None)
    def test_llm_unavailable_returns_fallback_brief(self, mock_llm):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(stakeholders=[{"name": "Sarah", "title": "VP"}]),
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "fallback"
        assert result["brief_markdown"] is not None
        assert "# Meeting Brief: Acme" in result["brief_markdown"]
        assert result["message"] is not None
        assert "LLM" in result["message"]

    def test_insufficient_data_has_message(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [_mem_row("m1", "c1", "s1", "fact", 1)],  # permanent (only 1)
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "raw"
        assert result["message"] is not None
        assert "memories" in result["message"].lower()
