"""Tests for error response formatting per SERVER_SPEC.md."""

import pytest
from coppermind_cmo.errors import (
    tool_error, NO_ACTIVE_MIND, MIND_NOT_FOUND,
    MIND_ARCHIVED, INVALID_INPUT, INVALID_MEMORY_TYPE,
    INVALID_BRAND_DNA, SERVICE_UNAVAILABLE, MEMORY_NOT_FOUND,
    INVALID_QUERY,
)


class TestToolError:
    def test_returns_dict_with_error_true(self):
        result = tool_error("TEST_CODE", "test message")
        assert result["error"] is True
        assert result["code"] == "TEST_CODE"
        assert result["message"] == "test message"

    def test_no_active_mind(self):
        result = NO_ACTIVE_MIND()
        assert result["code"] == "NO_ACTIVE_MIND"
        assert "switch_client" in result["message"]

    def test_mind_not_found_message(self):
        result = MIND_NOT_FOUND()
        assert result["code"] == "MIND_NOT_FOUND"
        assert "list_minds" in result["message"]

    def test_mind_archived(self):
        result = MIND_ARCHIVED("Acme")
        assert result["error"] is True
        assert result["code"] == "MIND_ARCHIVED"
        assert "Acme" in result["message"]

    def test_invalid_input(self):
        result = INVALID_INPUT("bad stuff")
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert result["message"] == "bad stuff"

    def test_invalid_memory_type(self):
        result = INVALID_MEMORY_TYPE("bogus")
        assert result["error"] is True
        assert result["code"] == "INVALID_MEMORY_TYPE"
        assert "bogus" in result["message"]
        # All valid types should be listed
        for valid_type in ["decision", "preference", "campaign_outcome",
                           "commitment", "stakeholder", "fact"]:
            assert valid_type in result["message"]

    def test_invalid_brand_dna(self):
        result = INVALID_BRAND_DNA("missing tone")
        assert result["error"] is True
        assert result["code"] == "INVALID_BRAND_DNA"
        assert result["message"] == "missing tone"

    def test_service_unavailable(self):
        result = SERVICE_UNAVAILABLE("Ollama")
        assert result["error"] is True
        assert result["code"] == "SERVICE_UNAVAILABLE"
        assert "Ollama" in result["message"]

    def test_memory_not_found(self):
        result = MEMORY_NOT_FOUND("uuid-123")
        assert result["error"] is True
        assert result["code"] == "MEMORY_NOT_FOUND"
        assert "uuid-123" in result["message"]

    def test_invalid_query(self):
        result = INVALID_QUERY()
        assert result["error"] is True
        assert result["code"] == "INVALID_QUERY"

    def test_mind_not_found_directs_to_list_minds(self):
        result = MIND_NOT_FOUND()
        assert result["error"] is True
        assert result["code"] == "MIND_NOT_FOUND"
        assert "list_minds" in result["message"]

    def test_all_errors_have_error_true(self):
        """Verify every error helper sets error: True."""
        results = [
            NO_ACTIVE_MIND(),
            MIND_NOT_FOUND(),
            MIND_ARCHIVED("X"),
            INVALID_INPUT("x"),
            INVALID_MEMORY_TYPE("x"),
            INVALID_BRAND_DNA("x"),
            SERVICE_UNAVAILABLE("x"),
            MEMORY_NOT_FOUND("x"),
            INVALID_QUERY(),
        ]
        for r in results:
            assert r["error"] is True, f"{r['code']} missing error: True"


class TestMindNotFoundSignature:
    def test_mind_not_found_rejects_arguments(self):
        """Fix 3.3: MIND_NOT_FOUND() takes no arguments — prevents roster leak."""
        with pytest.raises(TypeError):
            MIND_NOT_FOUND(["Acme", "Widget"])

    def test_mind_not_found_has_no_existing_key(self):
        """Fix 3.3: Response should not contain an 'existing' field."""
        result = MIND_NOT_FOUND()
        assert "existing" not in result
