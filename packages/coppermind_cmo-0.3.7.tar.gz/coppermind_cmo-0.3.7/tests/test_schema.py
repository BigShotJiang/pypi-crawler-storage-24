"""Tests for schema migration files."""

import os
import glob


def test_meeting_briefs_migration_has_grant():
    """Migration 006 should include GRANT for coppermind user."""
    schema_dir = os.path.join(os.path.dirname(__file__), "..", "schema")
    migration_006 = os.path.join(schema_dir, "006_meeting_briefs.sql")
    with open(migration_006) as f:
        content = f.read().lower()
    assert "grant" in content
    assert "meeting_briefs" in content
    assert "coppermind" in content


def test_all_create_table_migrations_have_grants():
    """Every migration that creates a table should include a GRANT statement."""
    schema_dir = os.path.join(os.path.dirname(__file__), "..", "schema")
    for path in sorted(glob.glob(os.path.join(schema_dir, "*.sql"))):
        with open(path) as f:
            content = f.read().lower()
        if "create table" in content:
            basename = os.path.basename(path)
            # 001_initial.sql may not have GRANTs (uses owner role)
            if basename == "001_initial.sql":
                continue
            assert "grant" in content, f"{basename} creates a table but has no GRANT statement"
