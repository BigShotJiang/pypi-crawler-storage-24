"""Tests for customer data isolation (migration 012).

Ensures that in hosted mode, customers can only see/modify minds they own
or have explicit access to. Self-hosted mode (no customer_id) is unaffected.
"""

from unittest.mock import MagicMock, patch

import pytest

import coppermind_cmo.tools.minds as minds_mod
from coppermind_cmo.tools.minds import (
    _switch_client, _list_minds, _verify_mind_access,
    _has_customer_id_col, _has_access_table,
)


@pytest.fixture
def enable_customer_isolation(monkeypatch):
    """Enable customer isolation features (migration 012 applied)."""
    monkeypatch.setattr("coppermind_cmo.tools.minds._has_customer_id_col", lambda db: True)
    monkeypatch.setattr("coppermind_cmo.tools.minds._has_access_table", lambda db: True)


@pytest.fixture
def db_with_isolation():
    """Mock DB that supports customer isolation queries."""
    return MagicMock()


class TestSwitchClientCustomerFiltering:
    def test_filters_by_customer(self, enable_customer_isolation, db_with_isolation):
        """Customer A creates a mind, customer B cannot see it via switch_client."""
        db = db_with_isolation
        # Customer B searches — mind exists but belongs to customer A
        db.fetch_one.return_value = None  # filtered query returns nothing
        set_mind = MagicMock()

        result = _switch_client("Acme Corp", False, db, set_mind, customer_id="customer_b")

        assert result["code"] == "MIND_NOT_FOUND"
        set_mind.assert_not_called()

        # Verify the SQL included customer_id filtering
        call_sql = db.fetch_one.call_args[0][0]
        assert "customer_id" in call_sql or "customer_mind_access" in call_sql

    def test_creates_with_customer_id(self, enable_customer_isolation, db_with_isolation):
        """New mind has customer_id set."""
        db = db_with_isolation
        db.fetch_one.side_effect = [
            None,  # lookup: not found
            None,  # slug check: not taken
        ]
        db.execute_returning.return_value = ("uuid-new", "Acme Corp", "acme-corp")
        set_mind = MagicMock()

        result = _switch_client("Acme Corp", True, db, set_mind, customer_id="customer_a")

        assert result["is_new"] is True
        # Verify INSERT included customer_id
        insert_sql = db.execute_returning.call_args[0][0]
        assert "customer_id" in insert_sql
        insert_params = db.execute_returning.call_args[0][1]
        assert "customer_a" in insert_params

    def test_creates_access_mapping(self, enable_customer_isolation, db_with_isolation):
        """New mind has customer_mind_access row created."""
        db = db_with_isolation
        db.fetch_one.side_effect = [
            None,  # lookup: not found
            None,  # slug check: not taken
        ]
        db.execute_returning.return_value = ("uuid-new", "Acme Corp", "acme-corp")
        set_mind = MagicMock()

        _switch_client("Acme Corp", True, db, set_mind, customer_id="customer_a")

        # Verify access mapping INSERT was called
        access_calls = [c for c in db.execute.call_args_list
                        if "customer_mind_access" in str(c)]
        assert len(access_calls) >= 1
        access_sql = access_calls[0][0][0]
        assert "INSERT INTO customer_mind_access" in access_sql
        access_params = access_calls[0][0][1]
        assert access_params[0] == "customer_a"
        assert access_params[1] == "uuid-new"


class TestListMindsCustomerFiltering:
    def test_filters_by_customer(self, enable_customer_isolation, db_with_isolation):
        """Customer A's minds not visible to customer B."""
        db = db_with_isolation
        db.fetch_all.return_value = []  # customer B sees nothing

        result = _list_minds(50, 0, db, customer_id="customer_b")

        assert result == []
        call_sql = db.fetch_all.call_args[0][0]
        assert "customer_id" in call_sql

    def test_shows_shared_minds(self, enable_customer_isolation, db_with_isolation):
        """Mind with access mapping visible to granted customer."""
        db = db_with_isolation
        from datetime import datetime
        db.fetch_all.return_value = [
            ("uuid-shared", "Shared Client", "shared-client", None, 5,
             datetime(2026, 1, 1), datetime(2026, 3, 1)),
        ]

        result = _list_minds(50, 0, db, customer_id="customer_b")

        assert len(result) == 1
        assert result[0]["name"] == "Shared Client"
        # Verify SQL checks both ownership AND access mapping
        call_sql = db.fetch_all.call_args[0][0]
        assert "customer_mind_access" in call_sql


class TestConfigureMindAccessDenied:
    def test_access_denied(self, enable_customer_isolation, db_with_isolation):
        """Customer B cannot configure customer A's mind."""
        db = db_with_isolation
        # _verify_mind_access: ownership check fails, access table check fails
        db.fetch_one.side_effect = [
            None,  # ownership check: not owner
            None,  # access table check: no mapping
        ]

        result = _verify_mind_access("mind-uuid", "customer_b", db)
        assert result is False


class TestStoreMemoryAccessDenied:
    def test_access_denied(self, enable_customer_isolation):
        """Customer B cannot store memories on customer A's mind."""
        # This tests that _verify_mind_access returns False for non-owners
        db = MagicMock()
        db.fetch_one.side_effect = [
            None,  # ownership: not owner
            None,  # access mapping: no entry
        ]

        assert _verify_mind_access("mind-uuid", "customer_b", db) is False


class TestSelfHostedNoFiltering:
    def test_no_customer_id_all_visible(self, db_with_isolation):
        """customer_id=None: all minds visible (backward compatible)."""
        db = db_with_isolation
        from datetime import datetime
        db.fetch_all.return_value = [
            ("uuid-1", "Client A", "client-a", None, 3,
             datetime(2026, 1, 1), datetime(2026, 3, 1)),
            ("uuid-2", "Client B", "client-b", None, 7,
             datetime(2026, 2, 1), datetime(2026, 3, 2)),
        ]

        result = _list_minds(50, 0, db, customer_id=None)

        assert len(result) == 2
        # SQL should NOT contain customer_id filtering
        call_sql = db.fetch_all.call_args[0][0]
        assert "customer_id" not in call_sql

    def test_switch_no_customer_id(self, db_with_isolation):
        """Self-hosted switch_client works without customer filtering."""
        db = db_with_isolation
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme", "acme", None, False, {}),  # found
            (5,),  # memory count
            None,  # tip: company_info lookup
        ]
        set_mind = MagicMock()

        result = _switch_client("Acme", False, db, set_mind, customer_id=None)

        assert result["name"] == "Acme"
        assert result["is_new"] is False


class TestBackfillNullCustomerId:
    def test_null_customer_id_visible_self_hosted(self, db_with_isolation):
        """Minds with NULL customer_id visible to self-hosted users."""
        db = db_with_isolation
        assert _verify_mind_access("any-mind", None, db) is True


class TestVerifyMindAccess:
    def test_owner_passes(self, enable_customer_isolation):
        """Owner passes verification."""
        db = MagicMock()
        db.fetch_one.return_value = (1,)  # ownership check: found

        assert _verify_mind_access("mind-uuid", "customer_a", db) is True

    def test_access_mapping_passes(self, enable_customer_isolation):
        """Customer with access mapping passes."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            None,  # ownership: not owner
            (1,),  # access mapping: found
        ]

        assert _verify_mind_access("mind-uuid", "customer_b", db) is True

    def test_no_access_denied(self, enable_customer_isolation):
        """Customer without ownership or mapping fails."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            None,  # ownership: not owner
            None,  # access mapping: not found
        ]

        assert _verify_mind_access("mind-uuid", "customer_c", db) is False

    def test_self_hosted_always_passes(self):
        """Self-hosted (no customer_id) always passes."""
        db = MagicMock()
        assert _verify_mind_access("any-mind", None, db) is True
        db.fetch_one.assert_not_called()


class TestPartialMigration:
    """Test partial migration state: customer_id column exists but access table doesn't."""

    @pytest.fixture(autouse=True)
    def enable_partial_migration(self, monkeypatch):
        """customer_id column exists, but customer_mind_access table does NOT."""
        monkeypatch.setattr("coppermind_cmo.tools.minds._has_customer_col", True)
        monkeypatch.setattr("coppermind_cmo.tools.minds._has_access_tbl", False)

    def test_verify_access_owner_passes(self):
        """Owner passes even without access table."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            True,   # _has_customer_id_col schema check (cached, but mock)
            (1,),   # ownership check: found
        ]
        # Re-mock to bypass cache
        with patch("coppermind_cmo.tools.minds._has_customer_id_col", return_value=True), \
             patch("coppermind_cmo.tools.minds._has_access_table", return_value=False):
            db2 = MagicMock()
            db2.fetch_one.return_value = (1,)  # ownership: found
            assert _verify_mind_access("mind-uuid", "customer_a", db2) is True

    def test_verify_access_non_owner_denied(self):
        """Non-owner denied when access table doesn't exist."""
        with patch("coppermind_cmo.tools.minds._has_customer_id_col", return_value=True), \
             patch("coppermind_cmo.tools.minds._has_access_table", return_value=False):
            db = MagicMock()
            db.fetch_one.return_value = None  # ownership: not found
            assert _verify_mind_access("mind-uuid", "customer_b", db) is False

    def test_switch_client_no_access_table_sql(self):
        """switch_client SQL doesn't reference customer_mind_access when table missing."""
        with patch("coppermind_cmo.tools.minds._has_customer_id_col", return_value=True), \
             patch("coppermind_cmo.tools.minds._has_access_table", return_value=False), \
             patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False):
            db = MagicMock()
            db.fetch_one.return_value = None  # lookup: not found
            set_mind = MagicMock()

            result = _switch_client("Acme", False, db, set_mind, customer_id="cust_a")

            assert result["code"] == "MIND_NOT_FOUND"
            call_sql = db.fetch_one.call_args[0][0]
            assert "customer_mind_access" not in call_sql
            assert "customer_id" in call_sql

    def test_list_minds_no_access_table_sql(self):
        """list_minds SQL doesn't reference customer_mind_access when table missing."""
        with patch("coppermind_cmo.tools.minds._has_customer_id_col", return_value=True), \
             patch("coppermind_cmo.tools.minds._has_access_table", return_value=False), \
             patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False):
            db = MagicMock()
            db.fetch_all.return_value = []

            _list_minds(50, 0, db, customer_id="cust_a")

            call_sql = db.fetch_all.call_args[0][0]
            assert "customer_mind_access" not in call_sql
            assert "customer_id" in call_sql
