"""Tests for IngestEngine — chunking, extraction, dedup."""

import hashlib
import pytest
from unittest.mock import patch, MagicMock
import json


class TestChunkText:
    def test_short_text_single_chunk(self):
        from coppermind_cmo.ingest import chunk_text
        result = chunk_text("Hello world")
        assert result == ["Hello world"]

    def test_empty_text_returns_empty(self):
        from coppermind_cmo.ingest import chunk_text
        result = chunk_text("")
        assert result == []

    def test_whitespace_only_returns_empty(self):
        from coppermind_cmo.ingest import chunk_text
        result = chunk_text("   \n\t  ")
        assert result == []

    def test_long_text_chunks_with_overlap(self):
        from coppermind_cmo.ingest import chunk_text
        text = "A" * 5000
        chunks = chunk_text(text, chunk_size=2000, overlap=200)
        assert len(chunks) == 3
        # First chunk: 0-2000
        assert len(chunks[0]) == 2000
        # Second chunk starts at 1800 (2000 - 200 overlap)
        assert len(chunks[1]) == 2000
        # Third chunk: remainder
        assert len(chunks[2]) > 0

    def test_chunks_skip_under_min_length(self):
        from coppermind_cmo.ingest import chunk_text
        # Text that produces a trailing chunk under 10 chars
        text = "A" * 2000 + "B" * 5
        chunks = chunk_text(text, chunk_size=2000, overlap=0)
        # The 5-char trailing chunk should be skipped
        assert len(chunks) == 1
        assert len(chunks[0]) == 2000

    def test_respects_custom_chunk_size(self):
        from coppermind_cmo.ingest import chunk_text
        text = "word " * 100  # 500 chars
        chunks = chunk_text(text, chunk_size=100, overlap=20)
        assert len(chunks) > 1
        assert all(len(c) <= 100 for c in chunks)

    def test_prefers_sentence_boundaries(self):
        from coppermind_cmo.ingest import chunk_text
        # Create text with clear sentence boundaries
        sentences = [f"Sentence number {i} is here. " for i in range(30)]
        text = "".join(sentences)  # ~30 * ~27 chars = ~810 chars
        chunks = chunk_text(text, chunk_size=200, overlap=30)
        # Each chunk should end at a sentence boundary (period + space)
        for chunk in chunks[:-1]:  # last chunk may not
            assert chunk.rstrip().endswith("."), f"Chunk doesn't end at sentence: '{chunk[-30:]}'"


class TestExtractMemoriesFromChunk:
    @patch("coppermind_cmo.ingest.call_llm")
    def test_extracts_valid_memories(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Acme paused LinkedIn ads through Q2", "memory_type": "decision", "confidence": 0.9},
            {"content": "Sarah is VP of Marketing", "memory_type": "stakeholder", "confidence": 0.85},
        ])
        result = extract_memories_from_chunk("Some meeting transcript chunk", mock_config)
        assert len(result) == 2
        assert result[0]["content"] == "Acme paused LinkedIn ads through Q2"
        assert result[0]["memory_type"] == "decision"

    @patch("coppermind_cmo.ingest.call_llm")
    def test_filters_low_confidence(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Maybe something happened", "memory_type": "fact", "confidence": 0.1},
        ])
        result = extract_memories_from_chunk("chunk", mock_config)
        assert len(result) == 0

    @patch("coppermind_cmo.ingest.call_llm")
    def test_filters_short_content(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Hi", "memory_type": "fact", "confidence": 0.9},
        ])
        result = extract_memories_from_chunk("chunk", mock_config)
        assert len(result) == 0

    @patch("coppermind_cmo.ingest.call_llm")
    def test_filters_invalid_memory_type(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Some valid content here", "memory_type": "invalid_type", "confidence": 0.9},
        ])
        result = extract_memories_from_chunk("chunk", mock_config)
        assert len(result) == 0

    @patch("coppermind_cmo.ingest.call_llm")
    def test_returns_empty_on_llm_failure(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = None
        result = extract_memories_from_chunk("chunk", mock_config)
        assert result == []

    @patch("coppermind_cmo.ingest.call_llm")
    def test_handles_malformed_json(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = "not valid json at all"
        result = extract_memories_from_chunk("chunk", mock_config)
        assert result == []


class TestIngestEngine:
    def _make_engine(self, mock_db, mock_config):
        from coppermind_cmo.ingest import IngestEngine
        active_mind = ("mind-uuid", "Acme Corp")
        return IngestEngine(mock_db, mock_config, active_mind)

    def test_init_sets_attributes(self, mock_db, mock_config):
        engine = self._make_engine(mock_db, mock_config)
        assert engine.mind_id == "mind-uuid"
        assert engine.mind_name == "Acme Corp"

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    @patch("coppermind_cmo.ingest._store_memory")
    def test_process_source_stores_extracted_memories(
        self, mock_store, mock_extract, mock_db, mock_config,
    ):
        mock_db.fetch_one.return_value = None  # no hash match
        mock_db.execute_returning.return_value = ("source-uuid",)
        mock_extract.return_value = [
            {"content": "A decision was made", "memory_type": "decision", "confidence": 0.9},
        ]
        mock_store.return_value = {"memory_id": "mem-uuid", "summary": "A decision"}

        engine = self._make_engine(mock_db, mock_config)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/path/to/session.jsonl",
            content="Short text under chunk size",
        )

        assert result["new"] + result["updated"] >= 1
        mock_store.assert_called_once()

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_skips_chunk_with_existing_hash(
        self, mock_extract, mock_db, mock_config,
    ):
        # fetch_one calls: schema check (None=no table), source lookup, hash check
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None  # force re-check
        mock_db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table → table doesn't exist
            ("source-uuid",),  # _get_or_create_source finds existing source
            ("log-uuid",),     # _check_hash finds existing hash for this mind
        ]

        engine = self._make_engine(mock_db, mock_config)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/path/to/session.jsonl",
            content="Already processed content",
        )

        assert result["skipped"] >= 1
        mock_extract.assert_not_called()

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_refresh_mode_reprocesses_existing_hash(
        self, mock_extract, mock_db, mock_config,
    ):
        # fetch_one calls: schema check (no table), source lookup
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None  # force re-check
        mock_db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table → table doesn't exist
            ("source-uuid",),  # _get_or_create_source finds existing source
        ]
        mock_extract.return_value = []

        engine = self._make_engine(mock_db, mock_config)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/path/to/session.jsonl",
            content="Previously processed content",
            refresh=True,
        )

        mock_extract.assert_called_once()
