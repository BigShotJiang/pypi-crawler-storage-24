"""Tests for daily tips system."""

import pytest
from unittest.mock import MagicMock, patch
from coppermind_cmo.tips import (
    TIP_TEMPLATES,
    get_next_tip,
    _personalize_tip,
    reset_session_tip,
)


@pytest.fixture(autouse=True)
def reset_tip_state():
    """Reset session tip flag before each test."""
    reset_session_tip()
    yield
    reset_session_tip()


@pytest.fixture
def mock_db():
    db = MagicMock()
    # customer_tips table exists
    db.fetch_one.return_value = (1,)
    return db


class TestTipTemplates:
    def test_has_15_tips(self):
        assert len(TIP_TEMPLATES) == 15

    def test_all_tips_have_required_fields(self):
        for i, tip in enumerate(TIP_TEMPLATES):
            assert "title" in tip, f"Tip {i} missing title"
            assert "body" in tip, f"Tip {i} missing body"
            assert "try_it" in tip, f"Tip {i} missing try_it"

    def test_first_tip_is_meeting_prep(self):
        assert TIP_TEMPLATES[0]["title"] == "Meeting prep"

    def test_last_tip_is_add_client(self):
        assert TIP_TEMPLATES[-1]["title"] == "Add another client"


class TestPersonalizeTip:
    def test_replaces_client_name(self):
        tip = {"title": "Test", "body": "Test", "try_it": "Prep for [client]"}
        result = _personalize_tip(tip, "Acme Corp", {}, None)
        assert result["try_it"] == "Prep for Acme Corp"

    def test_replaces_contact_name(self):
        tip = {"title": "Test", "body": "Test", "try_it": "[contact] wants something"}
        company_info = {"primary_contact": {"name": "Josh", "title": "CEO"}}
        result = _personalize_tip(tip, "Acme", company_info, None)
        assert result["try_it"] == "Josh wants something"

    def test_replaces_topic(self):
        tip = {"title": "Test", "body": "Test", "try_it": "What about [topic]?"}
        result = _personalize_tip(tip, "Acme", {}, "the rebrand")
        assert result["try_it"] == "What about the rebrand?"

    def test_all_placeholders_replaced(self):
        tip = {"title": "Test", "body": "Test", "try_it": "[contact] at [client] re: [topic]"}
        company_info = {"primary_contact": {"name": "Sarah"}}
        result = _personalize_tip(tip, "TechFlow", company_info, "Q3 budget")
        assert result["try_it"] == "Sarah at TechFlow re: Q3 budget"

    def test_no_company_info_uses_fallback(self):
        tip = {"title": "Test", "body": "Test", "try_it": "[contact] at [client]"}
        result = _personalize_tip(tip, "Acme", {}, None)
        assert result["try_it"] == "your main contact at Acme"

    def test_preserves_title_and_body(self):
        tip = {"title": "My Title", "body": "My Body", "try_it": "[client]"}
        result = _personalize_tip(tip, "Acme", {}, None)
        assert result["title"] == "My Title"
        assert result["body"] == "My Body"


class TestGetNextTip:
    def test_first_tip_is_tip_1(self, mock_db):
        # Table exists, no row yet for this customer
        mock_db.fetch_one.side_effect = [
            (1,),   # table exists
            None,   # no customer_tips row
            ("the rebrand",),  # recent topic
        ]
        result = get_next_tip("cust_1", "mind-1", "Acme", {}, mock_db)
        assert result is not None
        assert result["number"] == 1
        assert result["total"] == 15
        assert result["title"] == "Meeting prep"

    def test_tip_increments(self, mock_db):
        # Customer already at tip_index 3
        mock_db.fetch_one.side_effect = [
            (1,),   # table exists
            (3,),   # tip_index = 3
            ("social media",),  # recent topic
        ]
        result = get_next_tip("cust_1", "mind-1", "Acme", {}, mock_db)
        assert result is not None
        assert result["number"] == 4
        assert result["title"] == "Quick capture"

    def test_stops_after_15(self, mock_db):
        mock_db.fetch_one.side_effect = [
            (1,),    # table exists
            (15,),   # all tips shown
        ]
        result = get_next_tip("cust_1", "mind-1", "Acme", {}, mock_db)
        assert result is None

    def test_one_per_session(self, mock_db):
        mock_db.fetch_one.side_effect = [
            (1,),   # table exists
            (0,),   # tip_index = 0
            ("topic",),  # recent topic
        ]
        result1 = get_next_tip("cust_1", "mind-1", "Acme", {}, mock_db)
        assert result1 is not None

        # Second call same session — should return None
        result2 = get_next_tip("cust_1", "mind-1", "Acme", {}, mock_db)
        assert result2 is None

    def test_no_customer_id_returns_none(self, mock_db):
        result = get_next_tip(None, "mind-1", "Acme", {}, mock_db)
        assert result is None

    def test_no_table_returns_none(self, mock_db):
        mock_db.fetch_one.return_value = None  # table doesn't exist
        result = get_next_tip("cust_1", "mind-1", "Acme", {}, mock_db)
        assert result is None

    def test_personalized_with_real_data(self, mock_db):
        mock_db.fetch_one.side_effect = [
            (1,),   # table exists
            (0,),   # tip_index = 0
            ("the Q3 budget review",),  # recent topic
        ]
        company_info = {"primary_contact": {"name": "Josh", "title": "CEO"}}
        result = get_next_tip("cust_1", "mind-1", "TechFlow", company_info, mock_db)
        assert result is not None
        assert "TechFlow" in result["try_it"]
        assert "the Q3 budget review" in result["try_it"]

    def test_db_error_returns_none(self, mock_db):
        mock_db.fetch_one.side_effect = Exception("DB down")
        result = get_next_tip("cust_1", "mind-1", "Acme", {}, mock_db)
        assert result is None
