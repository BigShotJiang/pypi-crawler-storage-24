"""Lightweight performance regression tests for Coppermind CMO.

All DB/network calls are mocked.  These tests validate that Python logic
stays fast and does not regress.
"""

import importlib
import time
from datetime import datetime, timezone
from unittest.mock import MagicMock

from coppermind_cmo.errors import (
    NO_ACTIVE_MIND,
    MIND_NOT_FOUND,
    MIND_ARCHIVED,
    INVALID_INPUT,
    INVALID_MEMORY_TYPE,
    INVALID_BRAND_DNA,
    SERVICE_UNAVAILABLE,
    MEMORY_NOT_FOUND,
    INVALID_QUERY,
    tool_error,
)
from coppermind_cmo.tools.brand import _validate_stakeholders
from coppermind_cmo.tools.intelligence import _collect_type_balanced, _enforce_token_budget
from coppermind_cmo.tools.minds import _make_slug


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ALL_SOURCE_MODULES = [
    "coppermind_cmo",
    "coppermind_cmo.config",
    "coppermind_cmo.log",
    "coppermind_cmo.errors",
    "coppermind_cmo.db",
    "coppermind_cmo.embedding_client",
    "coppermind_cmo.embedding_server",
    "coppermind_cmo.llm_client",
    # server.py excluded: its import time is dominated by the third-party
    # mcp SDK, not our code.  We guard our own modules here.
    "coppermind_cmo.tools",
    "coppermind_cmo.tools.minds",
    "coppermind_cmo.tools.brand",
    "coppermind_cmo.tools.intelligence",
    "coppermind_cmo.tools.memories",
]

MEMORY_TYPES = [
    "decision",
    "preference",
    "campaign_outcome",
    "commitment",
    "stakeholder",
    "fact",
]


def _make_memory_tuple(
    mem_id: int,
    memory_type: str,
    day: int = 1,
    slot_tag: str = "type_balanced",
) -> tuple:
    """Build a mock memory tuple matching the shape returned by _collect_type_balanced."""
    return (
        mem_id,
        f"Content for memory {mem_id} of type {memory_type}",
        f"Summary of memory {mem_id}",
        memory_type,
        datetime(2026, 3, min(day, 28), tzinfo=timezone.utc),
        slot_tag,
        None,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestModuleImportPerformance:
    def test_all_modules_import_under_500ms(self):
        # Force-unload so re-import actually runs module init code
        # (in practice they are already cached, but importlib.reload works)
        start = time.perf_counter()
        for mod_name in ALL_SOURCE_MODULES:
            importlib.import_module(mod_name)
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert elapsed_ms < 500, (
            f"Importing all source modules took {elapsed_ms:.1f}ms (limit 500ms)"
        )


class TestSlugGenerationPerformance:
    def test_slug_generation_1000_names(self):
        names = [
            f"Acme Corp {i} -- Special! @Edition#{i}"
            for i in range(1000)
        ]

        start = time.perf_counter()
        for name in names:
            _make_slug(name)
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert elapsed_ms < 100, (
            f"Generating 1000 slugs took {elapsed_ms:.1f}ms (limit 100ms)"
        )


class TestTypeBalancedRetrievalPerformance:
    def test_collect_type_balanced_with_6_types(self):
        """Mock DB returns 6 types x 20 memories each; assert < 50ms."""
        db = MagicMock()

        # First call: DISTINCT memory_type
        type_rows = [(t,) for t in MEMORY_TYPES]
        # Per-type calls: 20 memories each
        per_type_rows = []
        for t in MEMORY_TYPES:
            rows = [
                (i + MEMORY_TYPES.index(t) * 20, f"content-{i}", f"summary-{i}",
                 t, datetime(2026, 3, (i % 28) + 1, tzinfo=timezone.utc), None)
                for i in range(20)
            ]
            per_type_rows.append(rows)
        # Fill call (remaining slots)
        fill_rows = [
            (200 + i, f"fill-content-{i}", f"fill-summary-{i}",
             "fact", datetime(2026, 3, 1, tzinfo=timezone.utc), None)
            for i in range(5)
        ]

        db.fetch_all.side_effect = [type_rows] + per_type_rows + [fill_rows]

        start = time.perf_counter()
        result = _collect_type_balanced("mind-uuid", limit=25, db=db)
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert elapsed_ms < 50, (
            f"_collect_type_balanced took {elapsed_ms:.1f}ms (limit 50ms)"
        )
        assert len(result) > 0


class TestTokenBudgetPerformance:
    def test_enforce_token_budget_100_memories(self):
        """Create 100 mock memories, run _enforce_token_budget, assert < 100ms."""
        memories = []
        for i in range(100):
            mem_type = MEMORY_TYPES[i % len(MEMORY_TYPES)]
            slot = "type_balanced" if i < 60 else "fill"
            memories.append(_make_memory_tuple(i, mem_type, day=(i % 28) + 1, slot_tag=slot))

        brand_dna = {
            "brand_voice": {"tone": ["professional", "warm"], "vocabulary": ["innovative"]},
            "brand_positioning": {"category": "SaaS", "differentiator": "AI-first"},
            "approved_messaging": {"tagline": "Think forward."},
            "stakeholders": [{"name": f"Person {j}", "title": "VP"} for j in range(5)],
            "content_themes": ["leadership", "innovation", "growth"],
        }

        start = time.perf_counter()
        result = _enforce_token_budget(memories, brand_dna, "Acme Corp")
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert elapsed_ms < 100, (
            f"_enforce_token_budget took {elapsed_ms:.1f}ms (limit 100ms)"
        )
        assert isinstance(result, list)


class TestBrandDNAValidationPerformance:
    def test_validate_50_stakeholders(self):
        """Validate 50 stakeholders (the max), assert < 10ms."""
        stakeholders = [
            {"name": f"Stakeholder {i}", "title": f"Title {i}", "role": f"Role {i}"}
            for i in range(50)
        ]

        start = time.perf_counter()
        err = _validate_stakeholders(stakeholders)
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert err is None, f"Unexpected validation error: {err}"
        assert elapsed_ms < 10, (
            f"Validating 50 stakeholders took {elapsed_ms:.1f}ms (limit 10ms)"
        )


class TestErrorHelperPerformance:
    def test_1000_error_constructions(self):
        """Call each error helper 1000 times, assert total < 50ms."""
        start = time.perf_counter()
        for _ in range(1000):
            tool_error("CODE", "msg")
            NO_ACTIVE_MIND()
            MIND_NOT_FOUND()
            MIND_ARCHIVED("X")
            INVALID_INPUT("x")
            INVALID_MEMORY_TYPE("x")
            INVALID_BRAND_DNA("x")
            SERVICE_UNAVAILABLE("x")
            MEMORY_NOT_FOUND("x")
            INVALID_QUERY()
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert elapsed_ms < 50, (
            f"1000 iterations of all error helpers took {elapsed_ms:.1f}ms (limit 50ms)"
        )
