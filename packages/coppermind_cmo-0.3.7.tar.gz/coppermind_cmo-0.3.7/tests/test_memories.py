"""Tests for memory tools: store_memory, search_memory, quick_note, hide_memory."""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch
from coppermind_cmo.tools.memories import (
    _store_memory, _search_memory, _quick_note, _hide_memory,
)


def _make_config():
    config = MagicMock()
    config.embedding_provider = "local"
    config.embedding_url = "http://localhost:8400"
    config.embedding_dims = 384
    config.llm_provider = "ollama"
    config.ollama_url = "http://localhost:11434"
    config.ollama_model = "gemma3:12b"
    return config


class TestStoreMemory:
    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = _make_config()
        return db, config, mind

    def test_requires_active_mind(self):
        db, config, _ = self._make_deps()
        result = _store_memory("content", None, [], db, config, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_empty_content_rejected(self):
        db, config, mind = self._make_deps()
        result = _store_memory("", None, [], db, config, mind)
        assert result["code"] == "INVALID_INPUT"

    def test_content_too_long_rejected(self):
        db, config, mind = self._make_deps()
        result = _store_memory("x" * 10001, None, [], db, config, mind)
        assert result["code"] == "INVALID_INPUT"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="Auto summary")
    def test_invalid_memory_type_auto_classifies(self, mock_sum, mock_cls, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-auto",)
        result = _store_memory("content", "invalid_type", [], db, config, mind)
        assert "error" not in result
        assert result["classified_by"] == "llm"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("decision", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="Short summary")
    def test_stores_with_auto_classification(self, mock_sum, mock_cls, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-uuid-1",)
        result = _store_memory("We decided to pause ads", None, ["q2"], db, config, mind)
        assert result["memory_id"] == "mem-uuid-1"
        assert result["memory_type"] == "decision"
        assert result["classified_by"] == "llm"
        assert result["has_embedding"] is True

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "fallback"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="truncated")
    def test_stores_without_embedding_degraded(self, mock_sum, mock_cls, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-uuid-2",)
        result = _store_memory("some content", None, [], db, config, mind)
        assert result["has_embedding"] is False
        assert result["classified_by"] == "fallback"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1])
    def test_stores_with_user_provided_type(self, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-uuid-3",)
        # When user provides type, no LLM classification needed
        with patch("coppermind_cmo.tools.memories.summarize", return_value="sum"):
            result = _store_memory("content", "commitment", [], db, config, mind)
        assert result["memory_type"] == "commitment"
        assert result["classified_by"] == "user"


class TestQuickNote:
    def test_requires_active_mind(self):
        db = MagicMock()
        config = _make_config()
        result = _quick_note("note", db, config, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_empty_content_rejected(self):
        db = MagicMock()
        config = _make_config()
        result = _quick_note("", db, config, ("mind-1", "Acme"))
        assert result["code"] == "INVALID_INPUT"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_stores_as_fact_with_truncated_summary(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        db.execute_returning.return_value = ("note-uuid",)
        mind = ("mind-1", "Acme")
        result = _quick_note("Quick thought here", db, config, mind)
        assert result["memory_id"] == "note-uuid"


class TestSearchMemory:
    def test_requires_active_mind(self):
        db = MagicMock()
        config = _make_config()
        result = _search_memory("query", None, 10, 0, db, config, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_empty_query_rejected(self):
        db = MagicMock()
        config = _make_config()
        result = _search_memory("", None, 10, 0, db, config, ("m", "n"))
        assert result["code"] == "INVALID_QUERY"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_returns_results(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        created_at = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("mem-1", "Pausing ads", "Pausing LinkedIn ads", "decision",
             1.0, 0.87, ["ads"], "manual", created_at),
        ]
        mind = ("mind-1", "Acme")
        result = _search_memory("ad budget", None, 10, 0, db, config, mind)
        assert len(result) == 1
        assert result[0]["memory_id"] == "mem-1"
        assert result[0]["similarity"] == 0.87


MEM_UUID_1 = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
MEM_UUID_2 = "b2c3d4e5-f6a7-8901-bcde-f12345678901"


class TestHideMemory:
    def test_requires_active_mind(self):
        db = MagicMock()
        result = _hide_memory(MEM_UUID_1, db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_memory_not_found(self):
        db = MagicMock()
        db.fetch_one.return_value = None
        result = _hide_memory(MEM_UUID_1, db, ("mind-1", "Acme"))
        assert result["code"] == "MEMORY_NOT_FOUND"

    def test_hides_memory(self):
        db = MagicMock()
        db.fetch_one.return_value = (MEM_UUID_1, "Summary text")
        result = _hide_memory(MEM_UUID_1, db, ("mind-1", "Acme"))
        assert result["hidden"] is True
        assert result["summary"] == "Summary text"
        db.execute.assert_called_once()

    def test_correct_memory_id_and_mind_id_in_update(self):
        """Assert db.execute includes both id and mind_id for defensive isolation."""
        db = MagicMock()
        db.fetch_one.return_value = (MEM_UUID_2, "Some summary")
        _hide_memory(MEM_UUID_2, db, ("mind-1", "Acme"))
        db.execute.assert_called_once()
        call_args = db.execute.call_args
        sql_arg = call_args[0][0]
        params_arg = call_args[0][1]
        assert "WHERE id = %s AND mind_id = %s" in sql_arg
        assert params_arg == [MEM_UUID_2, "mind-1"]


# ---------------------------------------------------------------------------
# Additional TestStoreMemory cases
# ---------------------------------------------------------------------------

class TestStoreMemoryExtended:
    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = _make_config()
        return db, config, mind

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="boundary summary")
    def test_content_at_boundary_10000_succeeds(self, mock_sum, mock_cls, mock_emb):
        """Content of exactly 10000 chars should store successfully (not error)."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-boundary",)
        content = "x" * 10000
        result = _store_memory(content, None, [], db, config, mind)
        assert result["memory_id"] == "mem-boundary"
        assert "error" not in result

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    @patch("coppermind_cmo.tools.memories.summarize", return_value="summary")
    def test_memory_type_normalization(self, mock_sum, mock_emb):
        """Pass 'Campaign Outcome' as memory_type. Should normalize to 'campaign_outcome'."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-norm",)
        result = _store_memory("content", "Campaign Outcome", [], db, config, mind)
        assert result["memory_type"] == "campaign_outcome"
        assert result["classified_by"] == "user"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "fallback"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="fallback summary")
    def test_fallback_confidence_is_lower(self, mock_sum, mock_cls, mock_emb):
        """When classified_by == 'fallback', confidence in execute_returning args should be 0.8."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-fb",)
        _store_memory("some content", None, [], db, config, mind)
        # No-embedding branch: params are [mind_id, content, summary, memory_type, confidence, tags]
        call_args = db.execute_returning.call_args[0][1]
        confidence_arg = call_args[4]  # 5th param is confidence in the no-embedding INSERT
        assert confidence_arg == 0.8

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("decision", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="tagged summary")
    def test_tags_passed_to_db(self, mock_sum, mock_cls, mock_emb):
        """Store with tags=['q2', 'ads'], verify the tags list appears in execute_returning call."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-tags",)
        _store_memory("content about ads", None, ["q2", "ads"], db, config, mind)
        call_args = db.execute_returning.call_args[0][1]
        # With embedding: params are [mind_id, content, summary, type, embedding_json, confidence, tags]
        assert ["q2", "ads"] in call_args


# ---------------------------------------------------------------------------
# Fix #3: Invalid memory_type auto-classification
# ---------------------------------------------------------------------------

class TestInvalidMemoryTypeAutoClassify:
    """Fix #3: invalid memory_type falls through to auto-classification instead of erroring."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="Auto-classified summary")
    def test_invalid_type_auto_classifies(self, mock_sum, mock_cls, mock_emb):
        """Invalid memory_type should auto-classify via LLM, not error."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-auto",)
        result = _store_memory("content", "event", [], db, config, mind)
        assert "error" not in result
        assert result["memory_type"] == "fact"
        assert result["classified_by"] == "llm"
        mock_cls.assert_called_once()

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("decision", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="Summary")
    def test_invalid_type_logs_warning(self, mock_sum, mock_cls, mock_emb):
        """Invalid memory_type should log a warning."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-warn",)
        with patch("coppermind_cmo.tools.memories.logger") as mock_logger:
            _store_memory("content", "event", [], db, config, mind)
            mock_logger.warn.assert_called()

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1])
    @patch("coppermind_cmo.tools.memories.summarize", return_value="sum")
    def test_valid_type_still_works(self, mock_sum, mock_emb):
        """Valid memory_type should still work as before."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-valid",)
        result = _store_memory("content", "commitment", [], db, config, mind)
        assert result["memory_type"] == "commitment"
        assert result["classified_by"] == "user"

    def _make_deps(self, mind=("mind-1", "Acme")):
        from unittest.mock import MagicMock
        db = MagicMock()
        config = MagicMock()
        config.embedding_provider = "local"
        config.embedding_url = "http://localhost:8400"
        config.embedding_dims = 384
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        return db, config, mind


# ---------------------------------------------------------------------------
# Additional TestSearchMemory cases
# ---------------------------------------------------------------------------

class TestSearchMemoryExtended:
    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = _make_config()
        return db, config, mind

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_invalid_type_filter_ignored(self, mock_emb):
        """Invalid memory_type filter should be ignored, not error."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        result = _search_memory("query", "event", 10, 0, db, config, mind)
        assert isinstance(result, list)
        # Should NOT have memory_type in params (filter dropped)
        call_params = db.fetch_all.call_args[0][1]
        assert "event" not in call_params

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_returns_service_unavailable_when_embedding_down(self, mock_emb):
        """When get_embedding returns None, search returns SERVICE_UNAVAILABLE error."""
        db, config, mind = self._make_deps()
        result = _search_memory("query", None, 10, 0, db, config, mind)
        assert isinstance(result, dict)
        assert result["error"] is True
        assert result["code"] == "SERVICE_UNAVAILABLE"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    @patch("coppermind_cmo.tools.memories.logger")
    def test_logs_warning_when_embedding_unavailable(self, mock_logger, mock_emb):
        """Per SERVER_SPEC.md: log a warning when embedding service unreachable."""
        db, config, mind = self._make_deps()
        _search_memory("query", None, 10, 0, db, config, mind)
        mock_logger.warn.assert_called_once()

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_type_filter_adds_sql_param(self, mock_emb):
        """Pass memory_type='decision'. Verify db.fetch_all is called with 'decision' in params."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        _search_memory("query", "decision", 10, 0, db, config, mind)
        call_args = db.fetch_all.call_args[0][1]
        assert "decision" in call_args

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_empty_results_no_last_accessed_update(self, mock_emb):
        """When db.fetch_all returns [], db.execute should NOT be called."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        _search_memory("query", None, 10, 0, db, config, mind)
        db.execute.assert_not_called()

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_none_tags_returns_empty_list(self, mock_emb):
        """Row has tags=None, result should show tags: []."""
        db, config, mind = self._make_deps()
        created_at = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("mem-1", "Content", "Summary", "fact", 0.9, 0.85, None, "manual", created_at),
        ]
        result = _search_memory("query", None, 10, 0, db, config, mind)
        assert result[0]["tags"] == []

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_none_created_at_returns_none(self, mock_emb):
        """Row has created_at=None, result should show created_at: None."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = [
            ("mem-1", "Content", "Summary", "fact", 0.9, 0.85, ["tag"], "manual", None),
        ]
        result = _search_memory("query", None, 10, 0, db, config, mind)
        assert result[0]["created_at"] is None


# ---------------------------------------------------------------------------
# Additional TestQuickNote cases
# ---------------------------------------------------------------------------

class TestQuickNoteExtended:
    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = _make_config()
        return db, config, mind

    def test_content_too_long_rejected(self):
        """Content > 10000 chars should be rejected."""
        db, config, mind = self._make_deps()
        result = _quick_note("x" * 10001, db, config, mind)
        assert result["code"] == "INVALID_INPUT"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_degraded_without_embedding(self, mock_emb):
        """When get_embedding returns None, quick_note should still store successfully."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("note-deg",)
        result = _quick_note("A quick note", db, config, mind)
        assert result["memory_id"] == "note-deg"
        assert "error" not in result

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_summary_is_first_100_chars(self, mock_emb):
        """Content of 200 chars. Verify the summary arg in execute_returning is content[:100]."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("note-sum",)
        content = "a" * 200
        _quick_note(content, db, config, mind)
        call_args = db.execute_returning.call_args[0][1]
        # With embedding: params are [mind_id, content, summary, embedding_json]
        summary_arg = call_args[2]
        assert summary_arg == "a" * 100
        assert len(summary_arg) == 100


# ---------------------------------------------------------------------------
# TestUUIDValidation
# ---------------------------------------------------------------------------

class TestUUIDValidation:
    def test_hide_memory_rejects_invalid_uuid(self, mock_db, active_mind):
        from coppermind_cmo.tools.memories import _hide_memory
        result = _hide_memory("not-a-uuid", mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "Invalid memory_id format" in result["message"]

    def test_hide_memory_accepts_valid_uuid(self, mock_db, active_mind):
        from coppermind_cmo.tools.memories import _hide_memory
        import uuid
        valid_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (valid_id, "test summary")
        result = _hide_memory(valid_id, mock_db, active_mind)
        assert result.get("error") is not True


# ---------------------------------------------------------------------------
# TestTagBounds
# ---------------------------------------------------------------------------

class TestTagBounds:
    def test_store_memory_rejects_too_many_tags(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _store_memory
        tags = [f"tag{i}" for i in range(21)]
        result = _store_memory("content", "fact", tags, mock_db, mock_config, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_store_memory_rejects_long_tag(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _store_memory
        tags = ["a" * 101]
        result = _store_memory("content", "fact", tags, mock_db, mock_config, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_store_memory_accepts_valid_tags(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _store_memory
        from unittest.mock import patch
        tags = ["tag1", "tag2"]
        with patch("coppermind_cmo.tools.memories.get_embedding", return_value=None), \
             patch("coppermind_cmo.tools.memories.summarize", return_value="summary"), \
             patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "llm")):
            mock_db.execute_returning.return_value = ("uuid-1",)
            result = _store_memory("content", "fact", tags, mock_db, mock_config, active_mind)
        assert result.get("error") is not True


# ---------------------------------------------------------------------------
# TestNullGuard
# ---------------------------------------------------------------------------

class TestNullGuard:
    def test_store_memory_null_row_returns_error(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _store_memory
        from unittest.mock import patch
        with patch("coppermind_cmo.tools.memories.get_embedding", return_value=None), \
             patch("coppermind_cmo.tools.memories.summarize", return_value="summary"), \
             patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "llm")):
            mock_db.execute_returning.return_value = None
            result = _store_memory("content", "fact", [], mock_db, mock_config, active_mind)
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"

    def test_quick_note_null_row_returns_error(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _quick_note
        from unittest.mock import patch
        with patch("coppermind_cmo.tools.memories.get_embedding", return_value=None):
            mock_db.execute_returning.return_value = None
            result = _quick_note("content", mock_db, mock_config, active_mind)
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"


class TestQuarterAutoTagging:
    """Tests for quarter/sprint auto-tagging on store_memory and quick_note."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("decision", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="Tagged summary")
    def test_store_memory_auto_tags_quarter(self, mock_sum, mock_cls, mock_emb):
        """store_memory with cadence set inserts quarter_year/quarter/sprint."""
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # _get_mind_cadence returns cadence with year/quarter/sprint
        db.fetch_one.return_value = ({"type": "eos", "year": 2026, "quarter": 1, "sprint": 4},)
        db.execute_returning.return_value = ("mem-qt",)

        result = _store_memory("We decided to pivot", None, [], db, config, mind)
        assert result["memory_id"] == "mem-qt"

        # Check the INSERT call includes quarter fields
        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        params = call_args[1]
        assert "quarter_year" in sql
        assert "quarter" in sql
        assert "sprint" in sql
        # params: mind_id, content, summary, type, embedding, confidence, source_type, tags, qy, q, s
        assert 2026 in params
        assert 1 in params
        assert 4 in params

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="No cadence summary")
    def test_store_memory_no_cadence(self, mock_sum, mock_cls, mock_emb):
        """store_memory with no cadence inserts NULL quarter fields."""
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # _get_mind_cadence returns empty cadence
        db.fetch_one.return_value = (None,)
        db.execute_returning.return_value = ("mem-nc",)

        result = _store_memory("Some fact", None, [], db, config, mind)
        assert result["memory_id"] == "mem-nc"

        # Check quarter fields are None
        call_args = db.execute_returning.call_args[0]
        params = call_args[1]
        # Last 3 params should be None (quarter_year, quarter, sprint)
        assert params[-3] is None
        assert params[-2] is None
        assert params[-1] is None

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_quick_note_auto_tags_quarter(self, mock_emb):
        """quick_note with cadence set inserts quarter fields."""
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # _get_mind_cadence returns cadence
        db.fetch_one.return_value = ({"type": "eos", "year": 2026, "quarter": 2, "sprint": 3},)
        db.execute_returning.return_value = ("note-qt",)

        result = _quick_note("Quick thought", db, config, mind)
        assert result["memory_id"] == "note-qt"

        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        params = call_args[1]
        assert "quarter_year" in sql
        # Params include quarter_year, quarter, sprint before source_tool, follows_tool_call
        assert 2026 in params
        assert 2 in params
        assert 3 in params

    @patch("coppermind_cmo.tools.memories._confirm_duplicate", return_value=True)
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("decision", "llm"))
    @patch("coppermind_cmo.tools.memories.summarize", return_value="Merged summary")
    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    @patch("coppermind_cmo.tools.memories._merge_memory_content", return_value="Merged content")
    def test_reconsolidation_updates_quarter(self, mock_merge, mock_find, mock_sum, mock_cls, mock_emb, mock_confirm):
        """Reconsolidated memory gets the new quarter tags."""
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # _get_mind_cadence returns cadence
        db.fetch_one.return_value = ({"type": "eos", "year": 2026, "quarter": 1, "sprint": 5},)

        # Simulate finding a similar memory for reconsolidation
        mock_find.return_value = {
            "memory_id": "existing-mem-id",
            "content": "Old content",
            "summary": "Old summary",
            "memory_type": "decision",
            "similarity": 0.90,
        }

        result = _store_memory("Updated decision", None, [], db, config, mind, skip_reconsolidation=False)
        assert result.get("reconsolidated") is True

        # The _update_memory call should include quarter fields
        update_call = db.execute.call_args[0]
        update_sql = update_call[0]
        update_params = update_call[1]
        assert "quarter_year" in update_sql
        assert "quarter" in update_sql
        assert "sprint" in update_sql
        assert 2026 in update_params
        assert 1 in update_params
        assert 5 in update_params


class TestSearchMemoryCTE:
    def test_search_uses_cte_with_single_embedding_param(self, mock_db, mock_config, active_mind):
        """Verify embedding is only passed once as a parameter (CTE pattern)."""
        from coppermind_cmo.tools.memories import _search_memory
        from unittest.mock import patch
        import json

        fake_embedding = [0.1] * 384
        with patch("coppermind_cmo.tools.memories.get_embedding", return_value=fake_embedding):
            mock_db.fetch_all.return_value = []
            _search_memory("test query", None, 10, 0, mock_db, mock_config, active_mind)

        args = mock_db.fetch_all.call_args
        sql = args[0][0]
        params = args[0][1]

        emb_json = json.dumps(fake_embedding)
        assert params.count(emb_json) == 1, "Embedding should appear only once in params (CTE)"
        assert "WITH q AS" in sql, "Query should use a CTE"


# ---------------------------------------------------------------------------
# Brand DNA stakeholder cross-reference in search_memory
# ---------------------------------------------------------------------------

BRAND_DNA_THRESHOLD = 0.45


class TestSearchBrandDnaCrossRef:
    """search_memory should cross-reference brand DNA stakeholders."""

    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = _make_config()
        return db, config, mind

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_appends_stakeholder_when_few_results(self, mock_emb):
        """When fewer than limit results, append matching stakeholders."""
        db, config, mind = self._make_deps()
        created_at = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
        # Vector search returns 1 result (below limit of 10)
        db.fetch_all.return_value = [
            ("mem-1", "Some content", "Some summary", "fact",
             1.0, 0.5, ["tag"], "manual", created_at),
        ]
        # Stakeholders query returns Brandon
        db.fetch_one.return_value = (
            [{"name": "Brandon Lee", "title": "VP Marketing", "role": "primary contact"}],
        )
        result = _search_memory("Brandon", None, 10, 0, db, config, mind)
        assert len(result) == 2
        brand_results = [r for r in result if r["source_type"] == "brand_dna"]
        assert len(brand_results) == 1
        assert "Brandon Lee" in brand_results[0]["content"]
        assert brand_results[0]["memory_type"] == "stakeholder"
        assert brand_results[0]["memory_id"] is None

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_appends_stakeholder_when_low_similarity(self, mock_emb):
        """When best similarity < 0.45, append matching stakeholders."""
        db, config, mind = self._make_deps()
        created_at = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
        # 9 results all with low similarity (below limit, low quality)
        db.fetch_all.return_value = [
            (f"mem-{i}", f"content {i}", f"summary {i}", "fact",
             1.0, 0.35, [], "manual", created_at)
            for i in range(9)
        ]
        db.fetch_one.return_value = (
            [{"name": "Brandon Lee", "title": "CEO"}],
        )
        result = _search_memory("Brandon", None, 10, 0, db, config, mind)
        brand_results = [r for r in result if r["source_type"] == "brand_dna"]
        assert len(brand_results) == 1

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_no_stakeholder_when_good_results_fill_limit(self, mock_emb):
        """When limit results with high similarity, don't query stakeholders."""
        db, config, mind = self._make_deps()
        created_at = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            (f"mem-{i}", f"content {i}", f"summary {i}", "fact",
             1.0, 0.8, [], "manual", created_at)
            for i in range(10)
        ]
        result = _search_memory("Brandon", None, 10, 0, db, config, mind)
        # Should NOT have queried stakeholders — only fetch_all for vector search
        # fetch_one not called for stakeholders (only for cadence etc if needed)
        brand_results = [r for r in result if r.get("source_type") == "brand_dna"]
        assert len(brand_results) == 0

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_no_match_when_query_doesnt_match_stakeholder(self, mock_emb):
        """Non-matching query returns no stakeholder results."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        db.fetch_one.return_value = (
            [{"name": "Brandon Lee", "title": "CEO"}],
        )
        result = _search_memory("budget planning", None, 10, 0, db, config, mind)
        brand_results = [r for r in result if r.get("source_type") == "brand_dna"]
        assert len(brand_results) == 0

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_matches_on_title_and_role(self, mock_emb):
        """Should match stakeholder title and role, not just name."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        db.fetch_one.return_value = (
            [{"name": "Sarah Chen", "title": "VP Marketing", "role": "executive sponsor"}],
        )
        result = _search_memory("VP Marketing", None, 10, 0, db, config, mind)
        brand_results = [r for r in result if r.get("source_type") == "brand_dna"]
        assert len(brand_results) == 1
        assert "Sarah Chen" in brand_results[0]["content"]

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_no_duplicates_with_existing_stakeholder_memory(self, mock_emb):
        """If vector search already returned a stakeholder memory about this person, don't duplicate."""
        db, config, mind = self._make_deps()
        created_at = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("mem-1", "Brandon Lee is VP Marketing at Acme", "Brandon is VP",
             "stakeholder", 1.0, 0.6, [], "manual", created_at),
        ]
        db.fetch_one.return_value = (
            [{"name": "Brandon Lee", "title": "VP Marketing"}],
        )
        result = _search_memory("Brandon", None, 10, 0, db, config, mind)
        brand_results = [r for r in result if r["source_type"] == "brand_dna"]
        assert len(brand_results) == 0

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_null_stakeholders_handled(self, mock_emb):
        """When stakeholders is NULL in DB, don't crash."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        db.fetch_one.return_value = (None,)
        result = _search_memory("Brandon", None, 10, 0, db, config, mind)
        assert result == []

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_skipped_when_type_filter_not_stakeholder(self, mock_emb):
        """When memory_type filter is set to non-stakeholder, skip brand DNA lookup."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        result = _search_memory("Brandon", "decision", 10, 0, db, config, mind)
        # Should not query stakeholders since user asked for decisions
        brand_results = [r for r in result if r.get("source_type") == "brand_dna"]
        assert len(brand_results) == 0

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_stakeholder_result_shape(self, mock_emb):
        """Synthetic stakeholder results have the correct shape."""
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        db.fetch_one.return_value = (
            [{"name": "Brandon Lee", "title": "CEO", "email": "brandon@acme.com"}],
        )
        result = _search_memory("Brandon", None, 10, 0, db, config, mind)
        assert len(result) == 1
        s = result[0]
        assert s["memory_id"] is None
        assert s["memory_type"] == "stakeholder"
        assert s["source_type"] == "brand_dna"
        assert s["confidence"] == 1.0
        assert s["similarity"] == 1.0
        assert s["tags"] == []
        assert s["created_at"] is None
        assert isinstance(s["content"], str)
        assert isinstance(s["summary"], str)


# ---------------------------------------------------------------------------
# Fix #4: Reconsolidation threshold and LLM confirmation
# ---------------------------------------------------------------------------

class TestReconsolidationThreshold:
    """Fix #4: Lower reconsolidation threshold with LLM confirmation."""

    def test_threshold_default_is_070(self):
        from coppermind_cmo.tools.memories import RECONSOLIDATION_THRESHOLD
        # Note: may be overridden by env var in test environment
        assert RECONSOLIDATION_THRESHOLD <= 0.85, "Default threshold should be lowered from 0.85"

    @patch("coppermind_cmo.tools.memories._confirm_duplicate", return_value=True)
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    @patch("coppermind_cmo.tools.memories._merge_memory_content", return_value="Merged")
    @patch("coppermind_cmo.tools.memories.summarize", return_value="Merged summary")
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("decision", "llm"))
    def test_merges_when_llm_confirms_duplicate(self, mock_cls, mock_sum, mock_merge, mock_find, mock_emb, mock_confirm):
        db = MagicMock()
        config = MagicMock()
        config.llm_provider = "ollama"
        mind = ("mind-1", "Acme")

        mock_find.return_value = {
            "memory_id": "existing-id",
            "content": "Old content about Yelp leads",
            "summary": "Yelp leads",
            "memory_type": "fact",
            "similarity": 0.72,
        }
        db.fetch_one.return_value = ({},)  # cadence

        result = _store_memory("New content about Yelp leads", None, [], db, config, mind, skip_reconsolidation=False)
        assert result.get("reconsolidated") is True
        mock_confirm.assert_called_once()

    @patch("coppermind_cmo.tools.memories._confirm_duplicate", return_value=False)
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    @patch("coppermind_cmo.tools.memories.summarize", return_value="New summary")
    @patch("coppermind_cmo.tools.memories.classify_memory_type", return_value=("fact", "llm"))
    def test_inserts_new_when_llm_rejects_duplicate(self, mock_cls, mock_sum, mock_find, mock_emb, mock_confirm):
        db = MagicMock()
        config = MagicMock()
        config.llm_provider = "ollama"
        mind = ("mind-1", "Acme")

        mock_find.return_value = {
            "memory_id": "existing-id",
            "content": "Different topic entirely",
            "summary": "Different",
            "memory_type": "fact",
            "similarity": 0.71,
        }
        db.fetch_one.return_value = ({},)  # cadence
        db.execute_returning.return_value = ("new-mem-id",)

        result = _store_memory("Content about something else", None, [], db, config, mind, skip_reconsolidation=False)
        assert result.get("reconsolidated") is not True
        assert result["memory_id"] == "new-mem-id"
        mock_confirm.assert_called_once()


class TestConfirmDuplicate:
    """Tests for _confirm_duplicate LLM check."""

    @patch("coppermind_cmo.tools.memories.call_llm", return_value="YES")
    def test_returns_true_on_yes(self, mock_llm):
        from coppermind_cmo.tools.memories import _confirm_duplicate
        config = MagicMock()
        assert _confirm_duplicate("old", "new", config) is True

    @patch("coppermind_cmo.tools.memories.call_llm", return_value="NO")
    def test_returns_false_on_no(self, mock_llm):
        from coppermind_cmo.tools.memories import _confirm_duplicate
        config = MagicMock()
        assert _confirm_duplicate("old", "new", config) is False

    @patch("coppermind_cmo.tools.memories.call_llm", return_value=None)
    def test_falls_back_to_false_when_llm_down(self, mock_llm):
        """LLM unavailable should NOT merge — the 0.70-0.85 zone needs LLM judgment."""
        from coppermind_cmo.tools.memories import _confirm_duplicate
        config = MagicMock()
        assert _confirm_duplicate("old", "new", config) is False

    @patch("coppermind_cmo.tools.memories.call_llm", return_value="  yes, they are the same  ")
    def test_handles_verbose_yes(self, mock_llm):
        from coppermind_cmo.tools.memories import _confirm_duplicate
        config = MagicMock()
        assert _confirm_duplicate("old", "new", config) is True
