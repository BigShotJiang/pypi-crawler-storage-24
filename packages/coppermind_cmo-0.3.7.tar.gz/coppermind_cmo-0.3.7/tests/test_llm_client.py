"""Tests for llm_client.py — LLM dispatcher, Ollama and gateway clients."""

import json
from unittest.mock import patch, MagicMock
from coppermind_cmo.llm_client import (
    call_ollama, classify_memory_type, summarize,
    call_llm, call_gateway_llm, SUMMARIZE_PROMPT,
)


class TestSummarizePrompt:
    """SUMMARIZE_PROMPT must instruct the LLM to preserve searchable specifics."""

    def test_prompt_mentions_proper_nouns(self):
        """SUMMARIZE_PROMPT must instruct LLM to preserve proper nouns."""
        prompt_lower = SUMMARIZE_PROMPT.lower()
        assert "proper noun" in prompt_lower or "names" in prompt_lower or "identifiers" in prompt_lower

    def test_prompt_mentions_dollar_amounts(self):
        """SUMMARIZE_PROMPT must instruct LLM to preserve dollar amounts."""
        prompt_lower = SUMMARIZE_PROMPT.lower()
        assert "dollar" in prompt_lower or "amount" in prompt_lower or "number" in prompt_lower

    def test_prompt_mentions_dates(self):
        """SUMMARIZE_PROMPT must instruct LLM to preserve dates."""
        prompt_lower = SUMMARIZE_PROMPT.lower()
        assert "date" in prompt_lower

    def test_prompt_max_length_still_specified(self):
        """Summary should still have a max length constraint."""
        assert "100" in SUMMARIZE_PROMPT or "max" in SUMMARIZE_PROMPT.lower()


class TestCallOllama:
    def test_returns_response_text(self):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"response": "decision"}

        with patch("coppermind_cmo.llm_client.httpx.post", return_value=mock_resp):
            result = call_ollama("classify this", "http://localhost:11434", "gemma3:12b")
            assert result == "decision"

    def test_returns_none_on_timeout(self):
        with patch("coppermind_cmo.llm_client.httpx.post", side_effect=TimeoutError("timeout")):
            result = call_ollama("classify", "http://localhost:11434", "gemma3:12b")
            assert result is None

    def test_returns_none_on_connection_error(self):
        with patch("coppermind_cmo.llm_client.httpx.post", side_effect=ConnectionError("refused")):
            result = call_ollama("classify", "http://localhost:11434", "gemma3:12b")
            assert result is None


class TestClassifyMemoryType:
    def _ollama_config(self):
        config = MagicMock()
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        return config

    def _gateway_config(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "test-key"
        config.gateway_url = "https://api.coppermind.dev"
        return config

    def test_valid_type_returned_ollama(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="decision"):
            result = classify_memory_type("We decided to pause ads", config)
            assert result == ("decision", "llm")

    def test_strips_whitespace_and_lowercases(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="  Campaign_Outcome  "):
            result = classify_memory_type("open rate 34%", config)
            assert result == ("campaign_outcome", "llm")

    def test_replaces_spaces_with_underscores(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="campaign outcome"):
            result = classify_memory_type("open rate 34%", config)
            assert result == ("campaign_outcome", "llm")

    def test_invalid_type_defaults_to_fact(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="garbage"):
            result = classify_memory_type("something", config)
            assert result == ("fact", "llm")

    def test_ollama_down_returns_fallback(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value=None):
            result = classify_memory_type("something", config)
            assert result == ("fact", "fallback")

    def test_gateway_classify_success(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"memory_type": "decision", "classified_by": "llm"}):
            result = classify_memory_type("We decided X", config)
            assert result == ("decision", "llm")

    def test_gateway_classify_failure_returns_fallback(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm", return_value=None):
            result = classify_memory_type("something", config)
            assert result == ("fact", "fallback")

    def test_no_provider_returns_fallback(self):
        config = MagicMock()
        config.llm_provider = None
        result = classify_memory_type("something", config)
        assert result == ("fact", "fallback")


class TestSummarize:
    def _ollama_config(self):
        config = MagicMock()
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        return config

    def _gateway_config(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "test-key"
        config.gateway_url = "https://api.coppermind.dev"
        return config

    def test_returns_summary(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="Short summary"):
            result = summarize("A very long content here...", config)
            assert result == "Short summary"

    def test_ollama_down_truncates_content(self):
        config = self._ollama_config()
        content = "x" * 200
        with patch("coppermind_cmo.llm_client.call_ollama", return_value=None):
            result = summarize(content, config)
            assert len(result) == 100

    def test_summarize_strips_whitespace(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="  summary with spaces  "):
            result = summarize("content", config)
            assert result == "summary with spaces"

    def test_summarize_truncation_at_100(self):
        config = self._ollama_config()
        content = "a" * 200
        with patch("coppermind_cmo.llm_client.call_ollama", return_value=None):
            result = summarize(content, config)
            assert len(result) == 100
            assert result == "a" * 100

    def test_gateway_summarize_success(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"summary": "Short gateway summary"}):
            result = summarize("Long content here", config)
            assert result == "Short gateway summary"

    def test_gateway_summarize_failure_truncates(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm", return_value=None):
            result = summarize("x" * 200, config)
            assert len(result) == 100

    def test_no_provider_truncates(self):
        config = MagicMock()
        config.llm_provider = None
        result = summarize("x" * 200, config)
        assert len(result) == 100


class TestCallOllamaAdditional:
    def test_call_ollama_http_error_returns_none(self):
        import httpx
        with patch("coppermind_cmo.llm_client.httpx.post", side_effect=httpx.HTTPStatusError("500", request=MagicMock(), response=MagicMock())):
            result = call_ollama("classify", "http://localhost:11434", "gemma3:12b")
            assert result is None

    def test_call_ollama_empty_response_key(self):
        """Response JSON has no 'response' key: data.get('response', '') returns ''."""
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"model": "gemma3:12b"}

        with patch("coppermind_cmo.llm_client.httpx.post", return_value=mock_resp):
            result = call_ollama("classify", "http://localhost:11434", "gemma3:12b")
            assert result == ""


class TestClassifyAdditional:
    def _ollama_config(self):
        config = MagicMock()
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        return config

    def test_classify_strips_trailing_punctuation(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="decision."):
            result = classify_memory_type("We decided X", config)
            assert result == ("decision", "llm")

    def test_classify_strips_exclamation(self):
        config = self._ollama_config()
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="commitment!"):
            result = classify_memory_type("Ben will do X", config)
            assert result == ("commitment", "llm")


class TestSummaryLengthEnforcement:
    @patch("coppermind_cmo.llm_client.call_ollama")
    def test_summarize_truncates_long_response(self, mock_call):
        config = MagicMock()
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost"
        config.ollama_model = "model"
        mock_call.return_value = "A" * 300  # 300 chars, should be truncated to 200
        result = summarize("content", config)
        assert len(result) <= 200

    @patch("coppermind_cmo.llm_client.call_ollama")
    def test_summarize_keeps_short_response(self, mock_call):
        config = MagicMock()
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost"
        config.ollama_model = "model"
        mock_call.return_value = "Short summary"
        result = summarize("content", config)
        assert result == "Short summary"


class TestCallLlmDispatcher:
    def test_routes_to_gateway(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "key"
        config.gateway_url = "https://api.coppermind.dev"
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"text": "response"}) as mock_gw:
            result = call_llm("prompt", config)
            assert result == "response"
            mock_gw.assert_called_once()

    def test_routes_to_ollama(self):
        config = MagicMock()
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        with patch("coppermind_cmo.llm_client.call_ollama", return_value="ollama result"):
            result = call_llm("prompt", config)
            assert result == "ollama result"

    def test_no_provider_returns_none(self):
        config = MagicMock()
        config.llm_provider = None
        result = call_llm("prompt", config)
        assert result is None

    def test_synthesis_model_flag(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "key"
        config.gateway_url = "https://api.coppermind.dev"
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"text": "synthesized"}) as mock_gw:
            result = call_llm("prompt", config, use_synthesis_model=True)
            assert result == "synthesized"
            mock_gw.assert_called_once_with("synthesize", {"prompt": "prompt"}, config)


class TestCallGatewayLlm:
    def test_success(self):
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.dev"
        config.api_key = "test-key"
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"text": "result"}
        mock_resp.raise_for_status = MagicMock()
        with patch("coppermind_cmo.llm_client.httpx") as mock_httpx:
            mock_httpx.post.return_value = mock_resp
            result = call_gateway_llm("synthesize", {"prompt": "test"}, config)
            assert result == {"text": "result"}

    def test_failure_returns_none(self):
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.dev"
        config.api_key = "test-key"
        with patch("coppermind_cmo.llm_client.httpx") as mock_httpx:
            mock_httpx.post.side_effect = Exception("timeout")
            result = call_gateway_llm("synthesize", {"prompt": "test"}, config)
            assert result is None
