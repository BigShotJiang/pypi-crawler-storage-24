# Coppermind CMO

AI-powered memory for fractional CMOs. Never forget a client detail, never leak data between clients, always prep well for meetings.

Coppermind CMO is an [MCP server](https://modelcontextprotocol.io/) that gives Claude persistent, client-scoped memory across conversations. Store meeting notes, brand voice, campaign outcomes, and decisions — then search, prep, and recall instantly.

## Installation

```bash
pip install coppermind-cmo
```

## Setup

Add to your Claude Code settings (`~/.claude/settings.json`):

```json
{
  "mcpServers": {
    "coppermind-cmo": {
      "command": "python",
      "args": ["-m", "coppermind_cmo"],
      "env": {
        "COPPERMIND_API_KEY": "your-key-here"
      }
    }
  }
}
```

> **Note:** Use `python3` instead of `python` on Mac/Linux if `python` is not aliased to Python 3.

That's it. The API key handles everything — database, embeddings, and AI classification are all managed for you.

## What it does

**10 tools for CMO workflows:**

| Tool | Purpose |
|------|---------|
| `switch_client` | Set the active client mind |
| `list_minds` | List all client minds |
| `store_memory` | Store a piece of client knowledge |
| `search_memory` | Semantic search across memories |
| `quick_note` | Fast capture, no AI classification |
| `hide_memory` | Soft-delete a memory |
| `get_brand_voice` | Read brand DNA |
| `set_brand_voice` | Update brand voice, positioning, stakeholders |
| `prep_meeting` | Generate a pre-meeting brief |
| `get_campaign_history` | Review campaign results |

**Key properties:**

- **Client isolation** — every query is scoped to the active client. Zero cross-client data leakage.
- **Brand DNA** — store and retrieve brand voice, positioning, stakeholders, and content themes per client.
- **Meeting prep** — type-balanced retrieval across all memory types, synthesized into a structured brief.
- **Graceful degradation** — if AI services are temporarily unavailable, storage still works. Nothing is lost.

## Daily workflow

```
# Before a call — get briefed
"Switch to Acme Corp and prep me for our meeting about Q2 planning"

# During/after a call — capture what happened
"Remember that Acme decided to pause LinkedIn ads through Q2"
"Quick note: Sarah mentioned the April budget review might affect Q3"

# Switching clients — change context
"Switch to Bluebell"
"What do we know about Bluebell's campaign performance?"
```

## Self-hosted mode

For users who want to run their own infrastructure:

```bash
pip install coppermind-cmo[self-hosted]
```

Requires PostgreSQL 14+ with pgvector, plus optionally Ollama and a local embedding server. See [full documentation](https://github.com/benfinklea/coppermind-cmo/blob/main/docs/QUICKSTART.md) for details.

## Support

Contact Ben directly at ben@volacci.com.
