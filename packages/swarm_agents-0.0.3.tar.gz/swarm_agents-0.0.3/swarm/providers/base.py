"""Base provider interface for multi-LLM support."""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, AsyncIterator

from openai.types.chat.chat_completion import ChatCompletion

from .types import CompletionRequest

if TYPE_CHECKING:
    pass


class ModelProvider(ABC):
    """Abstract base class for model providers."""

    @abstractmethod
    def create_completion(
        self, request: CompletionRequest, model: str
    ) -> ChatCompletion:
        """Create a non-streaming completion.

        Args:
            request: Completion request with messages, model, etc.

        Returns:
            ChatCompletion with the model's response
        """
        pass

    @abstractmethod
    async def create_completion_async(
        self, request: CompletionRequest, model: str
    ) -> ChatCompletion:
        """Create a non-streaming completion (async).

        Args:
            request: Completion request with messages, model, etc.

        Returns:
            ChatCompletion
        """
        pass

    @abstractmethod
    def stream_completion(
        self, request: CompletionRequest, model: str
    ) -> AsyncIterator[Any]:
        """Create a streaming completion.

        Args:
            request: Completion request with messages, etc.
            model: Model string to use (e.g., "openai/gpt-4o")

        Returns:
            AsyncIterator that yields streaming chunks from the model
        """
        raise NotImplementedError
