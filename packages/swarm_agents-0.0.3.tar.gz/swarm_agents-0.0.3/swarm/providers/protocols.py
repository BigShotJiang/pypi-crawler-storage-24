"""Protocols for provider routing abstractions."""

from typing import Any, AsyncIterator, Protocol

from openai.types.chat import ChatCompletion

from .types import CompletionRequest


class ModelRouterProtocol(Protocol):
    """Minimal router contract required by Swarm runners."""

    async def create_completion_async(
        self, request: CompletionRequest
    ) -> ChatCompletion: ...

    def stream_completion(self, request: CompletionRequest) -> AsyncIterator[Any]: ...
