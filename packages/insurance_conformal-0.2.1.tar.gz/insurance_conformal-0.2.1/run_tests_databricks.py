"""
Upload insurance-conformal source to Databricks workspace and run tests via Jobs API
using serverless compute.
"""
import os
import sys
import time
import base64

# Load credentials
env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            os.environ[k.strip()] = v.strip()

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs, compute
from databricks.sdk.service.workspace import ImportFormat

w = WorkspaceClient()

WORKSPACE_PATH = "/Workspace/Users/pricing.frontier@gmail.com/insurance_conformal_src"
LOCAL_SRC = "/home/ralph/repos/insurance-conformal"

print("Uploading source files to Databricks workspace...")


def upload_file(local_path: str, workspace_path: str):
    with open(local_path, "rb") as f:
        content = base64.b64encode(f.read()).decode()
    dir_path = "/".join(workspace_path.split("/")[:-1])
    try:
        w.workspace.mkdirs(path=dir_path)
    except Exception:
        pass
    w.workspace.import_(
        path=workspace_path,
        content=content,
        format=ImportFormat.AUTO,
        overwrite=True,
    )


files_to_upload = [
    ("src/insurance_conformal/__init__.py", f"{WORKSPACE_PATH}/src/insurance_conformal/__init__.py"),
    ("src/insurance_conformal/predictor.py", f"{WORKSPACE_PATH}/src/insurance_conformal/predictor.py"),
    ("src/insurance_conformal/scores.py", f"{WORKSPACE_PATH}/src/insurance_conformal/scores.py"),
    ("src/insurance_conformal/utils.py", f"{WORKSPACE_PATH}/src/insurance_conformal/utils.py"),
    ("src/insurance_conformal/diagnostics.py", f"{WORKSPACE_PATH}/src/insurance_conformal/diagnostics.py"),
    ("src/insurance_conformal/locally_weighted.py", f"{WORKSPACE_PATH}/src/insurance_conformal/locally_weighted.py"),
    ("src/insurance_conformal/hong.py", f"{WORKSPACE_PATH}/src/insurance_conformal/hong.py"),
    ("src/insurance_conformal/scr.py", f"{WORKSPACE_PATH}/src/insurance_conformal/scr.py"),
    ("src/insurance_conformal/diagnostics_ext.py", f"{WORKSPACE_PATH}/src/insurance_conformal/diagnostics_ext.py"),
    ("tests/__init__.py", f"{WORKSPACE_PATH}/tests/__init__.py"),
    ("tests/conftest.py", f"{WORKSPACE_PATH}/tests/conftest.py"),
    ("tests/test_predictor.py", f"{WORKSPACE_PATH}/tests/test_predictor.py"),
    ("tests/test_scores.py", f"{WORKSPACE_PATH}/tests/test_scores.py"),
    ("tests/test_utils.py", f"{WORKSPACE_PATH}/tests/test_utils.py"),
    ("tests/test_locally_weighted.py", f"{WORKSPACE_PATH}/tests/test_locally_weighted.py"),
    ("tests/test_hong.py", f"{WORKSPACE_PATH}/tests/test_hong.py"),
    ("tests/test_scr.py", f"{WORKSPACE_PATH}/tests/test_scr.py"),
    ("tests/test_diagnostics_ext.py", f"{WORKSPACE_PATH}/tests/test_diagnostics_ext.py"),
    ("pyproject.toml", f"{WORKSPACE_PATH}/pyproject.toml"),
]

for local_rel, ws_path in files_to_upload:
    local_full = f"{LOCAL_SRC}/{local_rel}"
    if not os.path.exists(local_full):
        print(f"  Skipping: {local_rel}")
        continue
    print(f"  {local_rel}")
    upload_file(local_full, ws_path)

print("Upload complete.")

# Upload runner notebook
notebook_task_content = """# Databricks notebook source
# COMMAND ----------
%python
import subprocess, sys

src_path = "/Workspace/Users/pricing.frontier@gmail.com/insurance_conformal_src"

# Install from source (deps will come from environment spec)
r2 = subprocess.run(
    [sys.executable, "-m", "pip", "install", "--quiet", "-e", src_path],
    capture_output=True, text=True
)
print(r2.stdout[-2000:])
if r2.stderr: print("install stderr:", r2.stderr[-1000:])

# Run tests
test_r = subprocess.run(
    [sys.executable, "-m", "pytest", f"{src_path}/tests/", "-v", "--tb=short", "--no-header"],
    capture_output=True, text=True, timeout=600
)
out = test_r.stdout + "\\n" + (test_r.stderr or "")
print(out[-15000:])

if test_r.returncode != 0:
    raise Exception(f"Tests FAILED (rc={test_r.returncode})")
print("\\n=== All tests PASSED ===")
"""

with open("/tmp/ic_nb_runner.py", "w") as f:
    f.write(notebook_task_content)

nb_runner_path = f"{WORKSPACE_PATH}/run_all_tests"
upload_file("/tmp/ic_nb_runner.py", nb_runner_path)
print(f"Uploaded runner to {nb_runner_path}")

print("\nSubmitting serverless test job...")

run_response = w.jobs.submit(
    run_name="insurance-conformal-v0.2-tests",
    tasks=[
        jobs.SubmitTask(
            task_key="run_tests",
            notebook_task=jobs.NotebookTask(
                notebook_path=nb_runner_path,
            ),
            environment_key="Default",
        )
    ],
    environments=[
        jobs.JobEnvironment(
            environment_key="Default",
            spec=compute.Environment(
                client="2",
                dependencies=[
                    "numpy>=1.24",
                    "polars>=0.20",
                    "pandas>=1.5",
                    "scipy>=1.10",
                    "pyarrow>=12.0",
                    "catboost>=1.2",
                    "scikit-learn>=1.3",
                    "pytest>=7.0",
                ],
            ),
        )
    ],
)

run_id = run_response.bind()["run_id"]
print(f"Job submitted: run_id={run_id}")

print("Polling for completion...")
for i in range(300):
    run_state = w.jobs.get_run(run_id=run_id)
    lc = run_state.state.life_cycle_state.value if run_state.state else "UNKNOWN"
    rs = run_state.state.result_state.value if (run_state.state and run_state.state.result_state) else ""
    if i % 6 == 0:
        print(f"  [{i*5}s] {lc} {rs}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(5)

print(f"  Final state: {lc} {rs}")

# Get output
try:
    run_detail = w.jobs.get_run(run_id=run_id)
    tasks = run_detail.tasks or []
    for task in tasks:
        task_run_id = getattr(task, "run_id", None)
        if task_run_id:
            try:
                out = w.jobs.get_run_output(run_id=task_run_id)
                if out.notebook_output and out.notebook_output.result:
                    print("\n--- Notebook output ---")
                    print(out.notebook_output.result[-15000:])
                if out.error:
                    print("\n--- Error ---")
                    print(out.error)
                if out.error_trace:
                    print("\n--- Trace ---")
                    print(out.error_trace[-5000:])
            except Exception as e:
                print(f"Could not get task output: {e}")
except Exception as e:
    print(f"Error fetching output: {e}")

final_state = w.jobs.get_run(run_id=run_id)
result_state = (
    final_state.state.result_state.value
    if (final_state.state and final_state.state.result_state)
    else "UNKNOWN"
)

print(f"\nFinal result: {result_state}")

if result_state != "SUCCESS":
    print("TESTS FAILED")
    sys.exit(1)
else:
    print("TESTS PASSED")
