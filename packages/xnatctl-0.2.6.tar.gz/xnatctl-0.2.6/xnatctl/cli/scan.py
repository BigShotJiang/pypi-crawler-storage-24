"""Scan commands for xnatctl."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import click

from xnatctl.cli.common import (
    Context,
    _make_alias_cb,
    confirm_destructive,
    global_options,
    handle_errors,
    parallel_options,
    require_auth,
)
from xnatctl.core.output import OutputFormat, print_error, print_json, print_output, print_success

if TYPE_CHECKING:
    from xnatctl.core.client import XNATClient


def _resolve_scan_params(client: XNATClient, base: str) -> dict[str, Any]:
    """Resolve the scan xsiType from the parent experiment.

    XNAT defaults to ``xnat:imageScanData`` subtypes when listing scans.
    Non-imaging sessions (e.g. EEG) need an explicit ``xsiType`` parameter
    so their scans are included in results.

    Args:
        client: Authenticated XNAT client.
        base: Experiment base path (e.g. ``/data/experiments/{id}``).

    Returns:
        Query params dict with ``xsiType`` set when derivable, empty otherwise.
    """
    params: dict[str, Any] = {}
    try:
        exp_resp = client.get_json(base)
    except Exception:
        return params
    exp_results = exp_resp.get("ResultSet", {}).get("Result", [])
    if exp_results:
        session_xsi = exp_results[0].get("xsiType", "")
        if session_xsi and "sessiondata" in session_xsi.lower():
            scan_xsi = session_xsi.replace("SessionData", "ScanData").replace(
                "sessionData", "scanData"
            )
            params["xsiType"] = scan_xsi
    return params


def _build_experiment_base(project: str | None, subject: str | None, session_id: str) -> str:
    """Build the XNAT experiment base path.

    Args:
        project: Project ID (optional).
        subject: Subject ID/label (optional, requires project).
        session_id: Experiment ID or label.

    Returns:
        Base path for the experiment resource.

    Raises:
        click.ClickException: If subject is given without a resolved project.
    """
    if subject and not project:
        raise click.ClickException(
            "-S/--subject requires -P/--project (or default_project in profile)"
        )
    if project and subject:
        return f"/data/projects/{project}/subjects/{subject}/experiments/{session_id}"
    if project:
        return f"/data/projects/{project}/experiments/{session_id}"
    return f"/data/experiments/{session_id}"


@click.group()
def scan() -> None:
    """Manage XNAT scans."""
    pass


@scan.command("list")
@click.option(
    "--experiment",
    "-E",
    "session_id",
    required=True,
    metavar="ID_OR_LABEL",
    help="Experiment ID (accession #), or label when -P is provided",
)
@click.option(
    "--project",
    "-P",
    help="Project ID (enables lookup by label; defaults to profile default_project)",
)
@click.option(
    "--subject",
    "-S",
    help="Subject ID/label (narrows experiment lookup, requires -P)",
)
@global_options
@require_auth
@handle_errors
def scan_list(ctx: Context, session_id: str, project: str | None, subject: str | None) -> None:
    """List scans in a session.

    Example:
        xnatctl scan list -E XNAT_E00001
        xnatctl scan list -E XNAT_E00001 -o json
        xnatctl scan list -E XNAT_E00001 -q  # IDs only
        xnatctl scan list -E SESSION_LABEL -P MYPROJ
        xnatctl scan list -P MYPROJ -S SUB001 -E SESSION_LABEL
    """
    from xnatctl.core.validation import validate_session_id

    session_id = validate_session_id(session_id)
    client = ctx.get_client()

    # Resolve project from profile default if not provided
    if not project:
        profile = ctx.config.get_profile(ctx.profile_name) if ctx.config else None
        project = profile.default_project if profile else None

    base = _build_experiment_base(project, subject, session_id)

    scan_params = _resolve_scan_params(client, base)
    resp = client.get_json(f"{base}/scans", params=scan_params)
    results = resp.get("ResultSet", {}).get("Result", [])

    # Transform for output
    scans = []
    for r in results:
        scans.append(
            {
                "id": r.get("ID", ""),
                "type": r.get("type", ""),
                "series_description": r.get("series_description", ""),
                "quality": r.get("quality", ""),
                "frames": r.get("frames", ""),
                "note": r.get("note", ""),
            }
        )

    print_output(
        scans,
        format=ctx.output_format,
        columns=["id", "type", "series_description", "quality", "frames"],
        column_labels={
            "id": "ID",
            "type": "Type",
            "series_description": "Series Description",
            "quality": "Quality",
            "frames": "Frames",
        },
        quiet=ctx.quiet,
        id_field="id",
    )


@scan.command("show")
@click.option(
    "--experiment",
    "-E",
    "session_id",
    required=True,
    metavar="ID_OR_LABEL",
    help="Experiment ID (accession #), or label when -P is provided",
)
@click.option(
    "--project",
    "-P",
    help="Project ID (enables lookup by label; defaults to profile default_project)",
)
@click.option(
    "--subject",
    "-S",
    help="Subject ID/label (narrows experiment lookup, requires -P)",
)
@click.argument("scan_id")
@global_options
@require_auth
@handle_errors
def scan_show(
    ctx: Context, session_id: str, project: str | None, subject: str | None, scan_id: str
) -> None:
    """Show scan details.

    Example:
        xnatctl scan show -E XNAT_E00001 1
        xnatctl scan show -E SESSION_LABEL 1 -P MYPROJ
        xnatctl scan show -P MYPROJ -S SUB001 -E SESSION_LABEL 1
    """
    from xnatctl.core.validation import validate_scan_id, validate_session_id

    session_id = validate_session_id(session_id)
    scan_id = validate_scan_id(scan_id)
    client = ctx.get_client()

    # Resolve project from profile default if not provided
    if not project:
        profile = ctx.config.get_profile(ctx.profile_name) if ctx.config else None
        project = profile.default_project if profile else None

    base = _build_experiment_base(project, subject, session_id)
    resp = client.get_json(f"{base}/scans/{scan_id}")
    results = resp.get("ResultSet", {}).get("Result", [])

    if not results:
        print_error(f"Scan not found: {scan_id}")
        raise SystemExit(1)

    scan_data = results[0]

    # Get resources
    try:
        res_resp = client.get_json(f"{base}/scans/{scan_id}/resources")
        resources = res_resp.get("ResultSet", {}).get("Result", [])
    except Exception:
        resources = []

    output = {
        "id": scan_data.get("ID", ""),
        "type": scan_data.get("type", ""),
        "series_description": scan_data.get("series_description", ""),
        "quality": scan_data.get("quality", ""),
        "frames": scan_data.get("frames", ""),
        "note": scan_data.get("note", ""),
        "resources": [r.get("label", "") for r in resources],
    }

    print_output(
        output,
        format=ctx.output_format,
        quiet=ctx.quiet,
        id_field="id",
    )


@scan.command("delete")
@click.option(
    "--experiment",
    "-E",
    "session_id",
    required=True,
    metavar="ID_OR_LABEL",
    help="Experiment ID (accession #), or label when -P is provided",
)
@click.option(
    "--project",
    "-P",
    help="Project ID (enables lookup by label; defaults to profile default_project)",
)
@click.option(
    "--subject",
    "-S",
    help="Subject ID/label (narrows experiment lookup, requires -P)",
)
@click.option("--scans", "-s", required=True, help="Scan IDs (comma-separated or '*' for all)")
@confirm_destructive("Delete these scans?")
@parallel_options
@global_options
@require_auth
@handle_errors
def scan_delete(
    ctx: Context,
    session_id: str,
    project: str | None,
    subject: str | None,
    scans: str,
    dry_run: bool,
    workers: int | None,
) -> None:
    """Delete scans from a session.

    Example:
        xnatctl scan delete -E XNAT_E00001 --scans 1,2,3
        xnatctl scan delete -E XNAT_E00001 --scans '*'  # Delete all
        xnatctl scan delete -E XNAT_E00001 --scans 1,2 --dry-run
        xnatctl scan delete -E SESSION_LABEL --scans 1,2,3 -P MYPROJ
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from xnatctl.core.validation import validate_scan_ids_input, validate_session_id

    session_id = validate_session_id(session_id)
    scan_ids = validate_scan_ids_input(scans)
    client = ctx.get_client()

    # Resolve project from profile default if not provided
    if not project:
        profile = ctx.config.get_profile(ctx.profile_name) if ctx.config else None
        project = profile.default_project if profile else None

    base = _build_experiment_base(project, subject, session_id)

    # If wildcard, get all scan IDs
    if scan_ids is None:
        scan_params = _resolve_scan_params(client, base)
        resp = client.get_json(f"{base}/scans", params=scan_params)
        results = resp.get("ResultSet", {}).get("Result", [])
        scan_ids = [r.get("ID", "") for r in results if r.get("ID")]

    if not scan_ids:
        print_error("No scans to delete")
        raise SystemExit(1)

    if dry_run:
        click.echo(f"[DRY-RUN] Would delete {len(scan_ids)} scans:")
        for sid in scan_ids:
            click.echo(f"  - {sid}")
        return

    # Resolve workers from profile
    if workers is None:
        profile = ctx.config.get_profile(ctx.profile_name) if ctx.config else None
        workers = profile.workers if (profile and profile.workers is not None) else 4

    deleted = []
    failed = []

    def delete_scan(scan_id: str) -> tuple[str, bool, str]:
        """Delete a scan and return status and error message."""
        try:
            resp = client.delete(f"{base}/scans/{scan_id}")
            return scan_id, resp.status_code in (200, 204), ""
        except Exception as e:
            return scan_id, False, str(e)

    if workers > 1 and len(scan_ids) > 1:
        with ThreadPoolExecutor(max_workers=min(workers, len(scan_ids))) as executor:
            futures = {executor.submit(delete_scan, sid): sid for sid in scan_ids}
            for future in as_completed(futures):
                scan_id, success, error = future.result()
                if success:
                    deleted.append(scan_id)
                else:
                    failed.append((scan_id, error))
    else:
        for scan_id in scan_ids:
            scan_id, success, error = delete_scan(scan_id)
            if success:
                deleted.append(scan_id)
            else:
                failed.append((scan_id, error))

    if deleted:
        print_success(f"Deleted {len(deleted)} scans")

    if failed:
        print_error(f"Failed to delete {len(failed)} scans:")
        for scan_id, error in failed:
            click.echo(f"  - {scan_id}: {error}")
        raise SystemExit(1)


@scan.command("download")
@click.option(
    "--experiment",
    "-E",
    "session_id",
    required=True,
    metavar="ID_OR_LABEL",
    help="Experiment ID (accession #), or label when -P is provided",
)
@click.option(
    "--project",
    "-P",
    help="Project ID (enables lookup by label; defaults to profile default_project)",
)
@click.option(
    "--subject",
    "-S",
    help="Subject ID/label (narrows experiment lookup, requires -P)",
)
@click.option("--scans", "-s", required=True, help="Scan IDs (comma-separated or '*' for all)")
@click.option("--out", type=click.Path(), default=".", show_default=True, help="Output directory")
@click.option("--name", hidden=True, help="Output directory name (defaults to experiment value)")
@click.option(
    "--resource",
    "-r",
    multiple=True,
    help="Resource type to download (e.g., DICOM). Omit for all resources.",
)
@click.option(
    "--extract/--no-extract", default=False, help="Extract ZIPs and remove archives after download"
)
@click.option(
    "--keep-zips", is_flag=True, hidden=True, help="With --extract, keep ZIP files after extraction"
)
@click.option(
    "--unzip",
    is_flag=True,
    hidden=True,
    expose_value=False,
    callback=_make_alias_cb("--unzip", "--extract", "extract", True),
)
@click.option(
    "--no-unzip",
    is_flag=True,
    hidden=True,
    expose_value=False,
    callback=_make_alias_cb("--no-unzip", "--no-extract", "extract", False),
)
@click.option("--cleanup", is_flag=True, hidden=True, expose_value=False, help="Deprecated: noop")
@click.option(
    "--no-cleanup",
    is_flag=True,
    hidden=True,
    expose_value=False,
    callback=_make_alias_cb("--no-cleanup", "--extract --keep-zips", "keep_zips", True),
)
@click.option("--dry-run", is_flag=True, help="Preview what would be downloaded")
@global_options
@require_auth
@handle_errors
def scan_download(
    ctx: Context,
    session_id: str,
    project: str | None,
    subject: str | None,
    scans: str,
    out: str,
    name: str | None,
    resource: tuple[str, ...],
    extract: bool,
    keep_zips: bool,
    dry_run: bool,
) -> None:
    """Download scans from an image session.

    Downloads all specified scans in a single request using XNAT's batch download
    feature. Output is saved to {out}/{experiment}/scans.zip.

    The output directory defaults to the value passed to -E/--experiment.
    Override it with --name.

    Use --resource to download a specific resource type (DICOM, NIFTI, etc).
    Only one --resource value is supported per invocation.
    Omit --resource to download all resources for the scans.

    Examples:
        xnatctl scan download -E XNAT_E00001 -s 1
        xnatctl scan download -E XNAT_E00001 -s 1 --out ./data
        xnatctl scan download -P PROJECT -E SESSION_LABEL -s 1,2,3 --out ./data
        xnatctl scan download -P PROJECT -E SESSION -s '*' --out ./data
    """
    from xnatctl.core.validation import validate_scan_ids_input, validate_session_id
    from xnatctl.models.progress import DownloadProgress, OperationPhase
    from xnatctl.services.downloads import DownloadService

    # Map extract/keep_zips to internal unzip/cleanup
    unzip = extract or keep_zips
    cleanup = extract and not keep_zips

    session_id = validate_session_id(session_id)
    scan_ids_input = validate_scan_ids_input(scans)
    output_dir = Path(out)
    client = ctx.get_client()

    if not project and not session_id.startswith("XNAT_E"):
        profile = ctx.config.get_profile(ctx.profile_name) if ctx.config else None
        project = profile.default_project if profile else None

    if name and ("/" in name or "\\" in name):
        raise click.ClickException("--name cannot contain path separators")

    use_all_keyword = scan_ids_input is None
    if scan_ids_input is None:
        scan_ids = ["ALL"]
    else:
        scan_ids = scan_ids_input

    # Validate resource option (only one value supported)
    if len(resource) > 1:
        raise click.ClickException(
            "Only one --resource value is supported per invocation. "
            "Use session download with -r for multi-resource filtering."
        )
    resource_filter: str | None = resource[0] if resource else None

    if dry_run:
        scan_desc = "all scans" if use_all_keyword else f"{len(scan_ids)} scans"
        resource_desc = resource[0] if resource else "all resources"
        click.echo(
            f"[DRY-RUN] Would download {scan_desc} ({resource_desc}) to {output_dir}/{name or session_id}/"
        )
        if not use_all_keyword:
            for sid in scan_ids:
                click.echo(f"  - Scan {sid}")
        return

    session_output = output_dir / (name or session_id)
    session_output.mkdir(parents=True, exist_ok=True)
    service = DownloadService(client)

    def progress_cb(progress: DownloadProgress) -> None:
        if progress.phase == OperationPhase.DOWNLOADING and not ctx.quiet:
            if progress.total_bytes:
                pct = progress.bytes_received * 100 // progress.total_bytes
                mb = progress.bytes_received / (1024 * 1024)
                click.echo(f"\r  Downloading: {pct}% ({mb:.1f} MB)", nl=False)

    try:
        summary = service.download_scans(
            session_id=session_id,
            scan_ids=scan_ids,
            output_dir=session_output,
            project=project,
            subject=subject,
            resource=resource_filter,
            zip_filename="scans.zip",
            extract=unzip,
            cleanup=cleanup,
            progress_callback=progress_cb if not ctx.quiet else None,
        )
    except ValueError as e:
        print_error(str(e))
        raise SystemExit(1) from None

    if not ctx.quiet:
        click.echo()

    if ctx.output_format == OutputFormat.JSON:
        print_json(
            {
                "session_id": session_id,
                "output_path": summary.output_path,
                "success": summary.success,
                "total_size_mb": round(summary.total_size_mb, 2),
                "errors": summary.errors,
            }
        )
    else:
        if summary.success:
            if unzip and not cleanup:
                if len(resource) > 1:
                    kept_zip_suffix = f" (kept {len(resource)} ZIP files)"
                else:
                    zip_name = f"scans_{resource[0]}.zip" if resource else "scans.zip"
                    kept_zip_suffix = f" (kept {session_output / zip_name})"
            else:
                kept_zip_suffix = ""
            print_success(
                f"Downloaded scans ({summary.total_size_mb:.1f} MB) to {summary.output_path}{kept_zip_suffix}"
            )
        else:
            print_error(
                f"Download failed: {summary.errors[0] if summary.errors else 'Unknown error'}"
            )
            raise SystemExit(1)
