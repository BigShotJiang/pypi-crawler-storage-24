"""The ``@trickle`` decorator — the main public API of the library."""

from __future__ import annotations

import datetime
import functools
import inspect
import logging
from typing import Any, Callable, Dict, Optional, Set, overload

from .attr_tracker import create_tracker
from .cache import TypeCache
from .env_detect import detect_environment
from .transport import enqueue
from .type_hash import hash_type
from .type_inference import infer_type

logger = logging.getLogger("trickle")

# Shared singleton cache
_cache = TypeCache()
_environment: Optional[str] = None


def _get_environment() -> str:
    global _environment
    if _environment is None:
        _environment = detect_environment()
    return _environment


# ---------------------------------------------------------------------------
# Decorator overloads
# ---------------------------------------------------------------------------

@overload
def trickle(fn: Callable) -> Callable: ...


@overload
def trickle(*, name: Optional[str] = None, module: Optional[str] = None) -> Callable: ...


def trickle(fn: Optional[Callable] = None, *, name: Optional[str] = None, module: Optional[str] = None) -> Callable:
    """Decorator that captures runtime type information for a function.

    Usage::

        @trickle
        def my_func(x, y):
            ...

        @trickle(name="custom", module="my.module")
        def my_func(x, y):
            ...
    """
    if fn is not None:
        # Called as @trickle (no parentheses)
        return _wrap(fn, name=None, module=None)
    # Called as @trickle(...) — return the actual decorator
    def decorator(f: Callable) -> Callable:
        return _wrap(f, name=name, module=module)
    return decorator


# ---------------------------------------------------------------------------
# Core wrapper logic
# ---------------------------------------------------------------------------

def _wrap(fn: Callable, *, name: Optional[str], module: Optional[str]) -> Callable:
    func_name = name or fn.__name__
    func_module = module or fn.__module__

    if inspect.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await _invoke_async(fn, func_name, func_module, args, kwargs)
        return async_wrapper
    else:
        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            return _invoke_sync(fn, func_name, func_module, args, kwargs)
        return sync_wrapper


def _invoke_sync(fn: Callable, func_name: str, func_module: str, args: tuple, kwargs: dict) -> Any:
    tracked_args, tracked_kwargs, all_paths_fns = _prepare_tracked(args, kwargs, fn)

    error_exc: Optional[Exception] = None
    result = None
    try:
        result = fn(*tracked_args, **tracked_kwargs)
    except Exception as exc:
        error_exc = exc
        _emit(fn, func_name, func_module, args, kwargs, result, all_paths_fns, error_exc, is_async=False)
        raise
    else:
        _emit(fn, func_name, func_module, args, kwargs, result, all_paths_fns, None, is_async=False)
    return result


async def _invoke_async(fn: Callable, func_name: str, func_module: str, args: tuple, kwargs: dict) -> Any:
    tracked_args, tracked_kwargs, all_paths_fns = _prepare_tracked(args, kwargs, fn)

    error_exc: Optional[Exception] = None
    result = None
    try:
        result = await fn(*tracked_args, **tracked_kwargs)
    except Exception as exc:
        error_exc = exc
        _emit(fn, func_name, func_module, args, kwargs, result, all_paths_fns, error_exc, is_async=True)
        raise
    else:
        _emit(fn, func_name, func_module, args, kwargs, result, all_paths_fns, None, is_async=True)
    return result


# ---------------------------------------------------------------------------
# Tracking helpers
# ---------------------------------------------------------------------------

def _prepare_tracked(args: tuple, kwargs: dict, fn: Callable):
    """Wrap mutable arguments in attribute trackers.

    Returns (tracked_args, tracked_kwargs, all_paths_fns) where
    *all_paths_fns* is a list of ``(param_name, get_paths_fn)`` tuples.
    """
    sig = None
    try:
        sig = inspect.signature(fn)
    except (ValueError, TypeError):
        pass

    param_names: list[str] = []
    if sig is not None:
        param_names = list(sig.parameters.keys())

    all_paths_fns: list[tuple[str, Callable[[], Set[str]]]] = []

    tracked_args = []
    for i, arg in enumerate(args):
        pname = param_names[i] if i < len(param_names) else f"arg{i}"
        tracked, get_paths = create_tracker(arg)
        all_paths_fns.append((pname, get_paths))
        tracked_args.append(tracked)

    tracked_kwargs: dict[str, Any] = {}
    for key, val in kwargs.items():
        tracked, get_paths = create_tracker(val)
        all_paths_fns.append((key, get_paths))
        tracked_kwargs[key] = tracked

    return tuple(tracked_args), tracked_kwargs, all_paths_fns


# ---------------------------------------------------------------------------
# Payload emission
# ---------------------------------------------------------------------------

def _sanitize_sample(value: Any, depth: int = 3) -> Any:
    """Truncate large values for safe serialization as sample data."""
    if depth <= 0:
        return "[truncated]"
    if value is None:
        return None
    if isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:200] + "..." if len(value) > 200 else value
    if isinstance(value, (list, tuple)):
        return [_sanitize_sample(v, depth - 1) for v in value[:5]]
    if isinstance(value, dict):
        return {k: _sanitize_sample(v, depth - 1) for k, v in list(value.items())[:20]}
    return str(value)


def _emit(
    fn: Callable,
    func_name: str,
    func_module: str,
    original_args: tuple,
    original_kwargs: dict,
    result: Any,
    all_paths_fns: list,
    error_exc: Optional[Exception],
    is_async: bool = False,
) -> None:
    """Build and enqueue an ingest payload.  Never raises."""
    try:
        import traceback

        # Infer argument types as a tuple (matching JS client format)
        elements = [infer_type(arg) for arg in original_args]
        # Include kwargs in the type
        if original_kwargs:
            kwargs_props: Dict[str, Any] = {}
            for key, val in original_kwargs.items():
                kwargs_props[key] = infer_type(val)
            elements.append({"kind": "object", "properties": kwargs_props})

        args_type: Dict[str, Any] = {"kind": "tuple", "elements": elements}
        return_type = infer_type(result)

        # Extract parameter names from the original function
        param_names: list[str] = []
        try:
            sig = inspect.signature(fn)
            param_names = [
                p.name for p in sig.parameters.values()
                if p.kind in (
                    inspect.Parameter.POSITIONAL_ONLY,
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                )
            ]
        except (ValueError, TypeError):
            pass

        type_hash_val = hash_type(args_type, return_type)
        function_key = f"{func_module}.{func_name}"

        # For errors, always send. For happy path, check cache.
        if error_exc is None and not _cache.should_send(function_key, type_hash_val):
            return

        # Build sample input
        sample_args = [_sanitize_sample(a) for a in original_args]
        if original_kwargs:
            sample_args.append(_sanitize_sample(original_kwargs))

        # camelCase payload to match backend's IngestPayload interface
        payload: Dict[str, Any] = {
            "functionName": func_name,
            "module": func_module,
            "language": "python",
            "environment": _get_environment(),
            "typeHash": type_hash_val,
            "argsType": args_type,
            "returnType": return_type,
            "sampleInput": sample_args,
            "sampleOutput": _sanitize_sample(result),
        }

        if is_async:
            payload["isAsync"] = True

        if param_names:
            payload["paramNames"] = param_names

        if error_exc is not None:
            payload["error"] = {
                "type": type(error_exc).__name__,
                "message": str(error_exc),
                "stackTrace": "".join(traceback.format_exception(type(error_exc), error_exc, error_exc.__traceback__)),
                "argsSnapshot": sample_args,
            }

        _cache.mark_sent(function_key, type_hash_val)
        enqueue(payload)

    except Exception:
        # NEVER crash the user's application
        logger.debug("trickle: failed to emit payload", exc_info=True)
