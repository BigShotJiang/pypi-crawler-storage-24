import asyncio
from datetime import datetime, UTC
from typing import List, Dict, Optional

from loguru import logger

from pjdev_sn_sdk import sn_api_service, control_parsing_service
from pjdev_sn_sdk.config_service import get_config
from pjdev_sn_sdk.models import snow_tables, SnowAuthPack


async def watch_for_queued_task_to_complete(auth_pack_sys_id: str) -> None:
    table_name = snow_tables.item_generation_action_event_queue_table
    fields = ["sys_id", "state", "source.name", "action", "table", "sys_created_on"]
    current_state = None
    max_retries = 1080  # 5400 total seconds (1.5 hours) in 5-second intervals
    retry_count = 0
    utc_timestamp = datetime.now(tz=UTC)
    while current_state != "processed":
        if retry_count >= max_retries:
            raise Exception(
                f"Timed out waiting for task to complete for {auth_pack_sys_id}"
            )
        retry_count += 1
        await asyncio.sleep(5)
        response, count = await sn_api_service.get_table_rows(
            table_name=table_name,
            query=f"source={auth_pack_sys_id}^ORDERBYDESCsys_created_on",
            fields=",".join(fields),
        )
        if len(response) == 0:
            continue
        data = response[0]
        created_on_str = data["sys_created_on"] + " +0000"
        created_on_dt = datetime.strptime(created_on_str, "%Y-%m-%d %H:%M:%S %z")
        current_state = data["state"]
        # ensure we are not looking at a job that was processed by a previous run
        if (
            abs((utc_timestamp - created_on_dt).total_seconds()) > 60 * 3
            and current_state == "processed"
        ):
            current_state = ""
            utc_timestamp = datetime.now(tz=UTC)
            continue
        auth_pack_name = data["source.name"]
        logger.info(f"State of task for {auth_pack_name}: {current_state}")


async def mark_control_ids_as_common(
    auth_pack_sys_id: str, control_ids: List[str]
) -> None:
    baseline_controls, baseline_count = await sn_api_service.get_table_rows(
        table_name=snow_tables.baseline_control_table_name,
        query=f"authorization_package.sys_id={auth_pack_sys_id}",
        fields="sys_id,control_objective.reference,common_control,implementation_status,inherited_from,justification",
    )

    for control_id in control_ids:
        b_control = next(
            (
                b
                for b in baseline_controls
                if control_parsing_service.extract_control(
                    b["control_objective.reference"]
                )
                == control_parsing_service.extract_control(control_id)
            ),
            None,
        )
        if not b_control:
            logger.warning(f"{control_id} not found in baseline")
            continue

        updated_sn_row = await sn_api_service.patch_table_row(
            table_name=snow_tables.baseline_control_table_name,
            payload={
                "implementation_status": "need_to_implement",
                "common_control": True,
            },
            fields=[
                "implementation_status",
                "sys_id",
                "common_control",
                "control_objective.reference",
            ],
            sys_id=b_control["sys_id"],
        )

        if (
            updated_sn_row["implementation_status"] != "need_to_implement"
            or updated_sn_row["common_control"] != "true"
        ):
            logger.error(f"{control_id} was not marked as n/a")


async def associate_controls_to_poam(
    auth_pack_sys_id: str,
    poam_sys_id: str,
    display_poam_id: str,
    control_ids: List[str],
) -> None:
    controls, count = await sn_api_service.get_table_rows(
        table_name=snow_tables.control_table_name,
        paginate=True,
        fields="sys_id,content.reference",
        query=f"authorization_package.sys_id={auth_pack_sys_id}",
    )

    for control_id in control_ids:
        sn_c = next(
            (
                c
                for c in controls
                if c["content.reference"].lower() == control_id.lower()
            ),
            None,
        )

        if not sn_c:
            logger.warning(
                f"Could not find control {control_id} in auth pack {auth_pack_sys_id}"
            )
            continue

        logger.info(
            f"Associating control {control_id} to poam {display_poam_id} ({poam_sys_id})"
        )
        payload = {"sn_grc_issue": poam_sys_id, "sn_grc_item": sn_c["sys_id"]}
        existing_link, link_count = await sn_api_service.get_table_rows(
            table_name=snow_tables.poam_control_m2m_table_name,
            query=f"sn_grc_issue.sys_id={poam_sys_id}^sn_grc_item.sys_id={sn_c['sys_id']}",
        )

        if link_count == 0:
            await sn_api_service.add_table_row(
                table_name=snow_tables.poam_control_m2m_table_name,
                payload=payload,
            )
        else:
            logger.info(
                f"Poam Control Link already exists for {display_poam_id} - {control_id}"
            )

    logger.info(f"Finished associating controls for {display_poam_id}")


def save_existing_auth_pack_data(sn_auth_pack: Dict) -> SnowAuthPack:
    auth_pack = SnowAuthPack.model_validate(sn_auth_pack)
    config = get_config()

    with open(
        config.output_path / f"existing_data_{auth_pack.number}.json",
        "w",
        encoding="utf-8",
    ) as f:
        f.write(auth_pack.model_dump_json(indent=2))

    return auth_pack


def read_existing_auth_pack_data(sn_auth_pack_number: str) -> Optional[SnowAuthPack]:
    config = get_config()
    filepath = config.output_path / f"existing_data_{sn_auth_pack_number}.json"
    if not filepath.exists():
        return None
    with open(filepath, "r", encoding="utf-8") as f:
        json_str = f.read()

        auth_pack = SnowAuthPack.model_validate_json(json_str)

    return auth_pack


if __name__ == "__main__":
    ap_number = "testing"
    test = {
        "sys_id": "test sys id",
        "name": "test",
        "number": ap_number,
        "step": 9,
        "authorization_comments": "auth_pack.authorization_comments",
        "next_authorization_date": "auth_pack.next_authorization_date",
        "authorization_date": "auth_pack.authorization_date",
        "authorization_decision": "auth_pack.authorization_decision",
        "ongoing_authorization": "auth_pack.ongoing_authorization",
    }
    save_existing_auth_pack_data(test)
    print(read_existing_auth_pack_data(ap_number))
