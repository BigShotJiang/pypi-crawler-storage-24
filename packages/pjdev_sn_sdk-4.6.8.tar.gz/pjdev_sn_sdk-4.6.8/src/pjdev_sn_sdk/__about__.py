# SPDX-FileCopyrightText: 2026-present Chris O'Neill <chris@purplejay.io>
#
# SPDX-License-Identifier: MIT
__version__ = "4.6.8"
