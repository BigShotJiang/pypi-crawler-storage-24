from typing import List, Tuple, Optional

import pytest

from pjdev_sn_sdk.control_parsing_service import extract_control, extract_control_requirement

control_test_data: List[Tuple[Optional[str], Optional[str]]] = [
    ("[r5] ca-09(01),ac-3", "CA-09(01)"),
    ("bl blah AC-02(3)(B)(005)(a) asdf j;lkj ;lkj asdg", "AC-02(03)"),
    ("ac-04(3) (asdfasdg ;alkjsdg ;j) ;lkj asdg", "AC-04(03)"),
    ("ac-04(3)(15)", "AC-04(03)(15)"),
    ("ac-4(3)", "AC-04(03)"),
    ("[r5] ac-4(3)", "AC-04(03)"),
    ("", None),
    (None, None),
    ("CA-05b", "CA-05"),
    ("SA-4(8)", "SA-04(08)"),
]


@pytest.mark.parametrize("raw_input, output", control_test_data)
def test_extract_control(raw_input: Optional[str], output: Optional[str]):
    result = extract_control(raw_input)

    assert result == output


control_list_test_data: List[Tuple[Optional[str], List[Optional[str]]]] = [
    ("[r5] IR-05, [r5] IR-07(01)", ["IR-05", "IR-07(01)"]),
    (
        "[r5] IR-05, [r5] IR-07(01), [r5] IR-04(03), [r5] IR-07, [r5] IR-04(01), [r5] IR-06, [r5] IR-06(01), [r5] IR-04, [r5] IR-08",
        [
            "IR-05",
            "IR-07(01)",
            "IR-04(03)",
            "IR-07",
            "IR-04(01)",
            "IR-06",
            "IR-06(01)",
            "IR-04",
            "IR-08",
        ],
    ),
]


@pytest.mark.parametrize("raw_input, output", control_list_test_data)
def test_extract_control_list(raw_input: Optional[str], output: Optional[str]):
    result = []

    if raw_input:
        split_controls = raw_input.split(",")
        for c in split_controls:
            extracted_control = extract_control(c)
            result.append(extracted_control)

    assert result == output


control_part_test_data: List[Tuple[Optional[str], Optional[str]]] = [
    ("ca-09(01)", None),
    ("ca-09a", "CA-9.a"),
    ("ca-09.a", "CA-9.a"),
    ("ca-9.a", "CA-9.a"),
    ("AC-01a", "AC-1.a"),
    ("AC-01a.01(a)", "AC-1.a"),
    ("AC-01a.01(b)", "AC-1.a"),
    ("AC-01a.02", "AC-1.a"),
    ("AC-1.a", "AC-1.a"),
]


@pytest.mark.parametrize("raw_input, output", control_part_test_data)
def test_extract_control_part(raw_input: Optional[str], output: Optional[str]):
    result = extract_control_requirement(raw_input)

    assert result == output
