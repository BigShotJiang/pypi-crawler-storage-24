__version__ = "0.2.0"
from decx.config import DEFAULT_CONFIG as DEFAULT_CONFIG
from decx.config import get_config as get_config
