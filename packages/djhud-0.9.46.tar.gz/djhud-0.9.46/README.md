# DJ HUD

Lightweight screen/webcam region capture and virtual camera tool for DJs.

Capture BPM, track info, waveforms, and deck status from your DJ software and stream it to remote DJs via VDO.Ninja, OBS, Discord, or Zoom.

## Install

```bash
pip install djhud
```

### Optional extras

```bash
# Virtual camera output (requires OBS Virtual Camera driver on Windows)
pip install djhud[virtualcam]

# macOS window listing support
pip install djhud[mac]

# Everything
pip install djhud[all]
```

## Run

```bash
djhud
```

Or as a Python module:

```bash
python -m djhud
```

## Features

- **Region capture** — select parts of any monitor, window, or webcam
- **Region editor** — drag, resize, crop, scale, lock aspect ratio, snap to grid, pixel nudge
- **Canvas compositor** — combine multiple regions into a single output
- **Webcam input** — device selection, resolution, FPS, flip, rotate, brightness, contrast, freeze/snapshot
- **Virtual camera output** — via pyvirtualcam → OBS Virtual Camera → VDO.Ninja / Discord / Zoom
- **Presets** — save/load JSON layouts per DJ app
- **System diagnostics** — dependency check, capability check, export report
- **Cross-platform** — Windows (full), macOS (screen + webcam), Linux (screen + webcam)

## Use case

Remote DJ back-to-back streaming. Capture BPM, track, key, waveform, and deck status from Traktor / Rekordbox / Serato / VirtualDJ / Djay and stream to your remote DJ partner.

## Supported DJ software

Works with any DJ software by capturing screen regions. Preset templates planned for:

- Traktor Pro
- Rekordbox
- Serato DJ
- VirtualDJ
- Djay Pro

## Requirements

- Python 3.9+
- Windows 10/11, macOS, or Linux
- For virtual camera: OBS Virtual Camera driver (Windows) or OBS (Mac/Linux)

## License

MIT
