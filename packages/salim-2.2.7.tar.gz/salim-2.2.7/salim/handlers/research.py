"""
Salim Deep Research — Multi-source web research + structured reports like Manus AI.

Manus's most praised feature is its ability to autonomously search multiple
sources, synthesize information, and produce polished research reports.
This handler replicates that: searches multiple sources, fetches full pages,
uses AI to synthesize, and produces a well-structured Markdown/DOCX report.

Commands:
  /research <topic>                   — deep research on any topic, send structured report
  /research <topic> --format=docx     — save as Word document
  /research <topic> --sources=5       — control how many sources to search (default: 6)
  /research <topic> --focus=<aspect>  — focus research on a specific angle
  /researchstop                       — stop active research task

Pipeline (real, not simulated):
  1. Query planning: AI breaks topic into 3-5 focused search queries
  2. Web fetching: Fetches top results from DuckDuckGo HTML (no API key needed)
  3. Content extraction: BeautifulSoup extracts article text from each source
  4. AI synthesis: Calls configured AI to synthesize + structure findings
  5. Report generation: Formats as Markdown with sources cited
  6. Delivery: Sends report + optionally a DOCX file

No API keys needed for search (uses DuckDuckGo HTML).
AI synthesis uses your configured Salim AI providers (NVIDIA/Groq/Z.AI).
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.research")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

RESEARCH_DIR = Path.home() / ".salim" / "research"
RESEARCH_DIR.mkdir(parents=True, exist_ok=True)

# Active research tasks per user
_active_research: dict[int, asyncio.Task] = {}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


def _ddg_search(query: str, max_results: int = 8) -> list[dict]:
    """
    Search DuckDuckGo HTML (no API key needed).
    Returns list of {title, url, snippet}.
    """
    try:
        encoded = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=10) as r:
            content = r.read().decode("utf-8", errors="replace")

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(content, "html.parser")

        results = []
        for result in soup.select(".result")[:max_results]:
            title_el = result.select_one(".result__title")
            link_el = result.select_one(".result__url")
            snippet_el = result.select_one(".result__snippet")

            title = title_el.get_text(strip=True) if title_el else ""
            raw_url = ""
            if link_el:
                raw_url = link_el.get_text(strip=True)
                if not raw_url.startswith("http"):
                    raw_url = "https://" + raw_url

            snippet = snippet_el.get_text(strip=True) if snippet_el else ""

            if title and raw_url:
                results.append({
                    "title": title,
                    "url": raw_url,
                    "snippet": snippet
                })

        return results
    except Exception as e:
        logger.warning(f"DDG search failed: {e}")
        return []


def _fetch_article_text(url: str, max_chars: int = 4000) -> str:
    """
    Fetch article text from URL using requests + BeautifulSoup.
    Extracts readable content, removes nav/footer/ads.
    """
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=10) as r:
            content = r.read()
            charset = r.headers.get_content_charset() or "utf-8"
            html_content = content.decode(charset, errors="replace")

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_content, "html.parser")

        # Remove noise elements
        for tag in soup(["script", "style", "nav", "footer", "header",
                         "aside", "advertisement", "form", "button",
                         ".ad", ".ads", ".advertisement", ".nav", ".sidebar"]):
            tag.decompose()

        # Try to find main content
        main_content = (
            soup.find("article")
            or soup.find("main")
            or soup.find(attrs={"role": "main"})
            or soup.find(id=re.compile(r"content|article|main", re.I))
            or soup.find(class_=re.compile(r"content|article|post|body", re.I))
            or soup.body
        )

        if main_content:
            text = main_content.get_text(separator="\n", strip=True)
        else:
            text = soup.get_text(separator="\n", strip=True)

        # Clean up excessive whitespace
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r' {3,}', ' ', text)

        return text[:max_chars]

    except Exception as e:
        logger.debug(f"Fetch failed for {url}: {e}")
        return ""


RESEARCH_SYSTEM_PROMPT = """You are a thorough research analyst. Your task is to synthesize information from multiple web sources into a well-structured research report.

Rules:
- Write in clear, informative prose
- Structure with clear sections using ## headers
- Cite sources inline using [Source: Title] format
- Include a summary at the top and key takeaways at the bottom
- Be factual; do not add speculation beyond what sources say
- Minimum 600 words, maximum 1200 words
- Format: Markdown

Report structure:
## Summary
(2-3 sentence executive summary)

## Background
(Context and background information)

## Key Findings
(Main findings from research, 3-5 points)

## Details
(Deeper dive into the most important aspects)

## Analysis
(Your synthesis and insights)

## Key Takeaways
(Bullet points of the most important points)

## Sources
(List all sources cited)"""


QUERY_PLANNING_PROMPT = """You are a research query planner. Given a research topic, generate {num_queries} focused search queries to comprehensively research it.

Topic: {topic}

Return ONLY a JSON array of strings, nothing else. Example:
["query 1", "query 2", "query 3"]

Make queries:
- Specific and targeted
- Cover different angles (definition, examples, recent developments, comparisons, criticisms)
- Varied in phrasing for diverse results
- In English regardless of input language"""


async def _plan_queries(topic: str, ai_instance, num_queries: int = 4) -> list[str]:
    """Use AI to generate research queries."""
    try:
        prompt = QUERY_PLANNING_PROMPT.replace("{topic}", topic).replace("{num_queries}", str(num_queries))
        raw, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system="You are a search query planner. Return only JSON.",
            max_tokens=300,
            temperature=0.3,
        )
        # Extract JSON
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        queries = json.loads(raw)
        if isinstance(queries, list):
            return [str(q) for q in queries[:num_queries]]
    except Exception as e:
        logger.warning(f"Query planning failed: {e}")

    # Fallback: generate basic queries
    return [
        topic,
        f"{topic} overview explanation",
        f"{topic} recent developments 2024 2025",
        f"{topic} examples use cases",
    ][:num_queries]


async def _synthesize_report(topic: str, sources: list[dict], ai_instance, focus: str = "") -> str:
    """Use AI to synthesize a research report from collected sources."""

    # Build context string
    context_parts = []
    for i, source in enumerate(sources[:8], 1):
        title = source.get("title", "Unknown")
        url = source.get("url", "")
        text = source.get("text", source.get("snippet", ""))
        if text:
            context_parts.append(
                f"[SOURCE {i}: {title}]\nURL: {url}\n{text[:600]}\n"
            )

    context = "\n---\n".join(context_parts)

    focus_line = f"\nFocus especially on: {focus}" if focus else ""

    user_prompt = (
        f"Research topic: {topic}{focus_line}\n\n"
        f"Sources collected:\n{context}\n\n"
        f"Write a comprehensive research report on this topic based on the sources above."
    )

    try:
        report, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": user_prompt}],
            system=RESEARCH_SYSTEM_PROMPT,
            max_tokens=1500,
            temperature=0.4,
        )
        return report
    except Exception as e:
        logger.error(f"AI synthesis failed: {e}")
        # Fallback: structured summary without AI
        lines = [f"# Research Report: {topic}\n"]
        lines.append(f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n")
        lines.append("## Sources Found\n")
        for source in sources[:8]:
            lines.append(f"- **{source.get('title', 'Unknown')}**")
            lines.append(f"  {source.get('url', '')}")
            snippet = source.get('snippet') or source.get('text', '')[:200]
            if snippet:
                lines.append(f"  {snippet}\n")
        return "\n".join(lines)


async def _run_research(
    topic: str,
    ai_instance,
    num_sources: int,
    focus: str,
    progress_callback,  # async(step, message)
    stop_event: asyncio.Event,
) -> tuple[str, list[dict]]:
    """
    Full research pipeline. Returns (report_markdown, sources_list).
    """

    # Step 1: Plan queries
    await progress_callback(1, f"🧠 Planning research queries for: <i>{esc(topic[:60])}</i>")

    if stop_event.is_set():
        return "", []

    queries = await _plan_queries(topic, ai_instance, num_queries=min(4, max(2, num_sources // 2)))
    await progress_callback(1, f"🔍 Generated {len(queries)} search queries")

    # Step 2: Search + fetch
    all_sources = []
    seen_urls = set()

    for i, query in enumerate(queries):
        if stop_event.is_set():
            break

        await progress_callback(2, f"🔍 Searching: <i>{esc(query[:60])}</i> ({i+1}/{len(queries)})")

        loop = asyncio.get_event_loop()
        results = await loop.run_in_executor(None, _ddg_search, query, 4)

        for result in results:
            url = result.get("url", "")
            if url in seen_urls:
                continue
            seen_urls.add(url)

            # Skip non-article URLs
            if any(skip in url.lower() for skip in
                   ("youtube.com", "twitter.com", "facebook.com", "instagram.com",
                    ".pdf", "maps.google", "play.google", "apps.apple")):
                continue

            all_sources.append(result)
            if len(all_sources) >= num_sources:
                break

        if len(all_sources) >= num_sources:
            break

        await asyncio.sleep(0.3)

    await progress_callback(2, f"📋 Found {len(all_sources)} sources")

    # Step 3: Fetch article text
    await progress_callback(3, f"📖 Fetching article content ({len(all_sources)} sources)…")

    loop = asyncio.get_event_loop()
    for i, source in enumerate(all_sources[:num_sources]):
        if stop_event.is_set():
            break
        url = source.get("url", "")
        if url:
            try:
                text = await loop.run_in_executor(None, _fetch_article_text, url, 3000)
                if text:
                    source["text"] = text
                await progress_callback(3, f"📖 Fetched {i+1}/{min(len(all_sources), num_sources)}: {esc(source.get('title', url)[:50])}")
            except Exception:
                pass
        await asyncio.sleep(0.2)

    if stop_event.is_set():
        return "", all_sources

    # Step 4: AI synthesis
    await progress_callback(4, "🤖 Synthesizing research with AI…")

    report = await _synthesize_report(topic, all_sources, ai_instance, focus)

    return report, all_sources


class DeepResearchHandlers:
    """Deep research handler — multi-source web research with AI synthesis."""

    @require_auth
    async def cmd_research(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /research <topic> [--format=docx] [--sources=N] [--focus=aspect]
        
        Researches a topic across multiple web sources and generates a
        comprehensive, AI-synthesized report.
        
        Options:
          --format=docx    Save as Word document (default: Markdown text)
          --sources=N      Number of sources (2-12, default: 6)
          --focus=X        Focus the research on a specific angle
        
        Examples:
          /research artificial intelligence in healthcare
          /research Python vs Rust --sources=8
          /research climate change --focus=economic impact --format=docx
          /research quantum computing 2025
        """
        msg = update.effective_message
        user_id = update.effective_user.id

        if not ctx.args:
            await msg.reply_text(
                "🔬 <b>Deep Research</b>\n\n"
                "Researches any topic across multiple web sources and creates\n"
                "a comprehensive AI-synthesized report.\n\n"
                "<b>Usage:</b> <code>/research &lt;topic&gt;</code>\n\n"
                "<b>Options:</b>\n"
                "• <code>--sources=N</code> — number of sources (default: 6)\n"
                "• <code>--format=docx</code> — save as Word document\n"
                "• <code>--focus=X</code> — focus on specific angle\n\n"
                "<b>Examples:</b>\n"
                "<code>/research artificial intelligence in healthcare</code>\n"
                "<code>/research Python vs Rust --sources=8</code>\n"
                "<code>/research quantum computing --format=docx</code>",
                parse_mode=H
            )
            return

        if not self._ai.is_configured():
            await msg.reply_text(
                "⚠️ AI not configured. Run <code>salim setup</code> to add an API key.\n"
                "<i>Research requires AI for synthesis.</i>",
                parse_mode=H
            )
            return

        # Parse args
        all_args = " ".join(ctx.args)

        # Extract options
        fmt = "markdown"
        if "--format=docx" in all_args:
            fmt = "docx"
            all_args = all_args.replace("--format=docx", "").strip()

        num_sources = 6
        src_match = re.search(r"--sources=(\d+)", all_args)
        if src_match:
            num_sources = min(12, max(2, int(src_match.group(1))))
            all_args = all_args.replace(src_match.group(0), "").strip()

        focus = ""
        focus_match = re.search(r"--focus=([^\s-][^-]*?)(?=--|$)", all_args)
        if focus_match:
            focus = focus_match.group(1).strip()
            all_args = all_args.replace(focus_match.group(0), "").strip()

        topic = all_args.strip()
        if not topic:
            await msg.reply_text("❌ Please provide a research topic.", parse_mode=H)
            return

        # Cancel any existing research
        if user_id in _active_research and not _active_research[user_id].done():
            _active_research[user_id].cancel()
            await asyncio.sleep(0.1)

        # Progress message
        progress_msg = await msg.reply_text(
            f"🔬 <b>Deep Research</b>\n"
            f"📌 Topic: <i>{esc(topic[:80])}</i>\n"
            f"{'🎯 Focus: ' + esc(focus[:50]) + chr(10) if focus else ''}"
            f"🔗 Sources: {num_sources}\n\n"
            f"<i>Step 1/4: Planning queries…</i>",
            parse_mode=H
        )

        stop_event = asyncio.Event()
        step_log = []

        async def progress_callback(step: int, message: str):
            step_log.append({"step": step, "msg": message, "time": time.time()})
            try:
                lines = [
                    f"🔬 <b>Researching:</b> <i>{esc(topic[:60])}</i>",
                    ""
                ]
                # Show last 5 steps
                icons = ["🧠", "🔍", "📖", "🤖", "✍️"]
                for entry in step_log[-5:]:
                    s = entry["step"]
                    icon = icons[s-1] if s <= len(icons) else "📌"
                    lines.append(f"{icon} Step {s}/4: {entry['msg']}")
                lines.append("")
                lines.append("<i>Please wait…</i>")
                await progress_msg.edit_text("\n".join(lines), parse_mode=H)
            except Exception:
                pass

        async def research_task():
            try:
                report_md, sources = await _run_research(
                    topic=topic,
                    ai_instance=self._ai,
                    num_sources=num_sources,
                    focus=focus,
                    progress_callback=progress_callback,
                    stop_event=stop_event,
                )

                if stop_event.is_set():
                    await progress_msg.edit_text("⏹️ Research stopped.", parse_mode=H)
                    return

                if not report_md:
                    await progress_msg.edit_text(
                        "❌ Research failed — could not find enough sources.",
                        parse_mode=H
                    )
                    return

                await progress_callback(5, "✅ Report ready!")

                # Save report
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                safe_topic = re.sub(r'[^\w\s-]', '', topic)[:40].strip().replace(' ', '_')
                report_path = RESEARCH_DIR / f"research_{safe_topic}_{timestamp}.md"
                report_path.write_text(report_md, encoding="utf-8")

                word_count = len(report_md.split())
                source_count = len(sources)

                if fmt == "docx":
                    # Try to generate DOCX
                    try:
                        docx_bytes = _report_to_docx(report_md, topic, sources)
                        docx_filename = f"research_{safe_topic}.docx"
                        buf = io.BytesIO(docx_bytes)
                        buf.name = docx_filename

                        await progress_msg.edit_text(
                            f"✅ <b>Research Complete</b>\n"
                            f"📌 <i>{esc(topic[:80])}</i>\n\n"
                            f"📊 {word_count:,} words · {source_count} sources",
                            parse_mode=H
                        )
                        await msg.reply_document(
                            document=buf,
                            filename=docx_filename,
                            caption=f"📄 <b>Research Report: {esc(topic[:60])}</b>",
                            parse_mode=H
                        )
                    except Exception as docx_err:
                        logger.warning(f"DOCX generation failed: {docx_err}, falling back to text")
                        fmt_actual = "markdown"  # fallback

                if fmt == "markdown":
                    # Split into chunks for Telegram (4096 char limit)
                    await progress_msg.edit_text(
                        f"✅ <b>Research Complete</b>\n"
                        f"📌 <i>{esc(topic[:80])}</i>\n\n"
                        f"📊 {word_count:,} words · {source_count} sources",
                        parse_mode=H
                    )

                    # Send as text file (Markdown)
                    md_bytes = report_md.encode("utf-8")
                    buf = io.BytesIO(md_bytes)
                    md_filename = f"research_{safe_topic}.md"
                    buf.name = md_filename

                    await msg.reply_document(
                        document=buf,
                        filename=md_filename,
                        caption=(
                            f"📋 <b>Research Report: {esc(topic[:60])}</b>\n"
                            f"📊 {word_count:,} words · {source_count} sources\n"
                            f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                        ),
                        parse_mode=H
                    )

                    # Also send a preview
                    preview = report_md[:2500]
                    if len(preview) >= 2495:
                        preview += "\n\n…<i>(see full report in file)</i>"
                    # Convert markdown to basic HTML for Telegram
                    tg_text = _md_to_tg_html(preview)
                    await msg.reply_text(tg_text, parse_mode=H, disable_web_page_preview=True)

            except asyncio.CancelledError:
                await progress_msg.edit_text("⏹️ Research cancelled.", parse_mode=H)
            except Exception as e:
                logger.error(f"Research task error: {e}", exc_info=True)
                await progress_msg.edit_text(
                    f"❌ <b>Research failed:</b> <code>{esc(str(e)[:300])}</code>",
                    parse_mode=H
                )
            finally:
                _active_research.pop(user_id, None)

        task = asyncio.create_task(research_task())
        _active_research[user_id] = task

    @require_auth
    async def cmd_researchstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop active research task."""
        user_id = update.effective_user.id
        if user_id in _active_research and not _active_research[user_id].done():
            _active_research[user_id].cancel()
            await update.effective_message.reply_text("⏹️ Research stopped.")
        else:
            await update.effective_message.reply_text("ℹ️ No active research task.")


def _md_to_tg_html(md: str) -> str:
    """Convert basic Markdown to Telegram HTML (best-effort)."""
    # Headers
    md = re.sub(r'^### (.+)$', r'<b>\1</b>', md, flags=re.MULTILINE)
    md = re.sub(r'^## (.+)$', r'\n<b>── \1 ──</b>', md, flags=re.MULTILINE)
    md = re.sub(r'^# (.+)$', r'\n<b>📌 \1</b>', md, flags=re.MULTILINE)
    # Bold
    md = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', md)
    # Italic
    md = re.sub(r'\*(.+?)\*', r'<i>\1</i>', md)
    # Bullet points (keep as-is, Telegram renders •)
    # Code
    md = re.sub(r'`(.+?)`', r'<code>\1</code>', md)
    # Escape HTML special chars that weren't intentional
    # (already partially done — leave existing tags intact)
    return md


def _report_to_docx(report_md: str, topic: str, sources: list[dict]) -> bytes:
    """Convert research report Markdown to DOCX bytes."""
    try:
        from docx import Document
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        doc = Document()

        # Title
        title_para = doc.add_heading(level=0)
        title_run = title_para.add_run(f"Research Report: {topic}")
        title_run.font.color.rgb = RGBColor(0x1a, 0x56, 0xdb)

        # Metadata
        meta = doc.add_paragraph()
        meta.add_run(f"Generated: {datetime.now().strftime('%B %d, %Y %H:%M')} | "
                     f"Sources: {len(sources)}").italic = True

        doc.add_paragraph()

        # Parse markdown sections
        current_section = None
        for line in report_md.split("\n"):
            if line.startswith("## "):
                heading = line[3:].strip()
                doc.add_heading(heading, level=2)
                current_section = heading
            elif line.startswith("### "):
                doc.add_heading(line[4:].strip(), level=3)
            elif line.startswith("# "):
                doc.add_heading(line[2:].strip(), level=1)
            elif line.startswith("- ") or line.startswith("• "):
                p = doc.add_paragraph(style="List Bullet")
                p.add_run(line.lstrip("- •").strip())
            elif line.strip():
                # Regular paragraph — handle bold/italic
                p = doc.add_paragraph()
                # Simple bold parsing
                parts = re.split(r'(\*\*[^*]+\*\*)', line)
                for part in parts:
                    if part.startswith("**") and part.endswith("**"):
                        run = p.add_run(part[2:-2])
                        run.bold = True
                    else:
                        p.add_run(part)

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()

    except ImportError:
        # python-docx not available — return plain text as .docx won't work
        raise ImportError("python-docx not installed. Install with: pip install python-docx")
