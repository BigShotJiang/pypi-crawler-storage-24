"""
Salim Web Scraper — Structured data extraction like Manus AI.

Manus can scrape any website and extract structured data (tables, lists,
contacts, prices, etc.) into CSV/JSON files. This handler does the same.

Commands:
  /scrape <url>                      — scrape page, auto-detect data type, send structured output
  /scrape <url> css:<selector>       — extract elements matching CSS selector
  /scrape <url> table                — extract all tables as CSV files
  /scrape <url> links                — extract all links with text
  /scrape <url> emails               — extract all email addresses
  /scrape <url> images               — extract all image URLs
  /scrape <url> json                 — extract JSON data from page (APIs, embedded data)
  /scrapebulk <url1> <url2> ...      — scrape multiple URLs, merge results
  /scrapewatch <url> <interval_min>  — watch URL for changes, alert on difference

Real implementation:
  - Uses requests + BeautifulSoup for parsing
  - Handles JavaScript-rendered pages via Playwright (if available)
  - Auto-detects content type: tables → CSV, lists → JSON, contacts → vCard
  - Respects robots.txt; sets real browser User-Agent
  - Handles pagination (detects "next page" links, follows up to 10 pages)
  - Results sent as files directly to Telegram
"""
from __future__ import annotations

import asyncio
import csv
import html
import io
import json
import logging
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.scraper")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

SCRAPER_DIR = Path.home() / ".salim" / "scraper"
SCRAPER_DIR.mkdir(parents=True, exist_ok=True)

# Active watches: url → {chat_id, interval, last_hash, task}
_watches: dict[str, dict] = {}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}


def _normalize_url(url: str) -> str:
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


def _fetch_page(url: str, timeout: int = 15) -> tuple[str, str]:
    """
    Fetch page HTML. Returns (html_content, final_url).
    Uses requests with retry, falls back to urllib.
    """
    try:
        import requests
        resp = requests.get(url, headers=HEADERS, timeout=timeout,
                            allow_redirects=True, verify=True)
        resp.raise_for_status()
        # Detect encoding
        resp.encoding = resp.apparent_encoding or "utf-8"
        return resp.text, resp.url
    except Exception as e:
        # Fallback: urllib
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            content = r.read()
            charset = "utf-8"
            ct = r.headers.get_content_charset()
            if ct:
                charset = ct
            return content.decode(charset, errors="replace"), r.url


def _parse_tables(soup, url: str) -> list[dict]:
    """Extract all HTML tables from page."""
    results = []
    for i, table in enumerate(soup.find_all("table")):
        rows = []
        headers = []

        # Try to get headers from <th> elements
        header_row = table.find("thead")
        if header_row:
            headers = [th.get_text(strip=True) for th in header_row.find_all(["th", "td"])]
        
        if not headers:
            first_row = table.find("tr")
            if first_row:
                ths = first_row.find_all("th")
                if ths:
                    headers = [th.get_text(strip=True) for th in ths]

        # Extract data rows
        for tr in table.find_all("tr"):
            cells = [td.get_text(strip=True) for td in tr.find_all(["td", "th"])]
            if cells:
                rows.append(cells)

        if rows:
            results.append({
                "table_index": i + 1,
                "headers": headers,
                "rows": rows,
            })
    return results


def _extract_emails(text: str) -> list[str]:
    """Extract all email addresses from text."""
    pattern = r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'
    return list(set(re.findall(pattern, text)))


def _extract_links(soup, base_url: str) -> list[dict]:
    """Extract all links with their text."""
    links = []
    seen = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if not href or href.startswith(("#", "javascript:", "mailto:", "tel:")):
            continue
        # Resolve relative URLs
        full_url = urllib.parse.urljoin(base_url, href)
        if full_url in seen:
            continue
        seen.add(full_url)
        text = a.get_text(strip=True)[:200]
        links.append({"text": text, "url": full_url})
    return links


def _extract_images(soup, base_url: str) -> list[dict]:
    """Extract all image URLs."""
    images = []
    seen = set()
    for img in soup.find_all("img"):
        src = img.get("src") or img.get("data-src") or ""
        if not src:
            continue
        full_url = urllib.parse.urljoin(base_url, src)
        if full_url in seen:
            continue
        seen.add(full_url)
        alt = img.get("alt", "")
        images.append({"url": full_url, "alt": alt})
    return images


def _extract_json_data(page_html: str) -> list[dict]:
    """
    Extract embedded JSON data from page (LD+JSON, inline JSON objects, API responses).
    """
    results = []
    
    # Look for <script type="application/ld+json"> (structured data)
    ld_json_pattern = re.compile(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        re.DOTALL | re.IGNORECASE
    )
    for match in ld_json_pattern.finditer(page_html):
        try:
            data = json.loads(match.group(1).strip())
            results.append({"source": "ld+json", "data": data})
        except Exception:
            pass

    # Look for window.__INITIAL_DATA__, window.__STATE__, etc.
    init_data_pattern = re.compile(
        r'window\.__(?:INITIAL_?DATA|STATE|PROPS|PRELOADED_STATE)[^=]*=\s*({.*?});',
        re.DOTALL
    )
    for match in init_data_pattern.finditer(page_html):
        try:
            data = json.loads(match.group(1))
            results.append({"source": "window_state", "data": data})
        except Exception:
            pass

    # Try to parse as pure JSON (API response)
    stripped = page_html.strip()
    if stripped.startswith(("{", "[")):
        try:
            data = json.loads(stripped)
            results.append({"source": "api_response", "data": data})
        except Exception:
            pass

    return results


def _extract_css_selector(soup, selector: str) -> list[str]:
    """Extract text from elements matching CSS selector."""
    try:
        elements = soup.select(selector)
        return [el.get_text(strip=True) for el in elements if el.get_text(strip=True)]
    except Exception as e:
        return [f"Selector error: {e}"]


def _auto_detect_and_extract(soup, html_text: str, url: str) -> dict:
    """
    Auto-detect the most valuable data on the page and extract it.
    Priority: JSON-LD → tables → lists → links → text.
    """
    result = {"method": "auto", "url": url}

    # 1. Try embedded JSON
    json_data = _extract_json_data(html_text)
    if json_data:
        result["type"] = "json"
        result["data"] = json_data
        return result

    # 2. Tables
    tables = _parse_tables(soup, url)
    if tables:
        result["type"] = "tables"
        result["data"] = tables
        return result

    # 3. Ordered/unordered lists with enough content
    lists = []
    for ul in soup.find_all(["ul", "ol"]):
        items = [li.get_text(strip=True) for li in ul.find_all("li") if li.get_text(strip=True)]
        if len(items) >= 3:
            lists.append(items)
    if lists:
        result["type"] = "lists"
        result["data"] = lists
        return result

    # 4. Links
    links = _extract_links(soup, url)
    if links:
        result["type"] = "links"
        result["data"] = links
        return result

    # 5. Plain text extraction
    text = soup.get_text(separator="\n", strip=True)
    lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
    result["type"] = "text"
    result["data"] = lines
    return result


def _dict_to_csv_bytes(data: list[dict]) -> bytes:
    """Convert list of dicts to CSV bytes."""
    if not data:
        return b""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(data[0].keys()), extrasaction="ignore")
    writer.writeheader()
    writer.writerows(data)
    return buf.getvalue().encode("utf-8-sig")  # BOM for Excel compatibility


def _tables_to_csv_bytes(table: dict) -> bytes:
    """Convert a parsed table to CSV."""
    buf = io.StringIO()
    headers = table.get("headers", [])
    rows = table.get("rows", [])

    if not rows:
        return b""

    max_cols = max(len(r) for r in rows)
    
    if headers and len(headers) == max_cols:
        # Use provided headers
        pass
    else:
        headers = [f"col_{i+1}" for i in range(max_cols)]

    writer = csv.writer(buf)
    writer.writerow(headers)
    for row in rows:
        # Pad short rows
        padded = row + [""] * (max_cols - len(row))
        writer.writerow(padded)

    return buf.getvalue().encode("utf-8-sig")


def _compute_content_hash(html_text: str) -> str:
    """Compute hash of page text content (ignoring dynamic timestamps etc)."""
    import hashlib
    # Strip scripts and style, keep body text
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_text, "html.parser")
        for tag in soup(["script", "style", "meta", "head"]):
            tag.decompose()
        text = soup.get_text(separator=" ", strip=True)
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text)
    except Exception:
        text = html_text
    return hashlib.sha256(text.encode()).hexdigest()


async def _do_scrape(url: str, mode: str, selector: str = "") -> dict:
    """
    Core scraping function. Returns result dict with:
      - type: str (tables/links/emails/images/json/text/css)
      - data: extracted content
      - url: final URL after redirects
      - title: page title
      - error: str (if failed)
    """
    url = _normalize_url(url)
    
    try:
        # Run blocking fetch in thread pool
        loop = asyncio.get_event_loop()
        html_text, final_url = await loop.run_in_executor(None, _fetch_page, url)
    except Exception as e:
        return {"error": str(e), "url": url}

    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_text, "html.parser")
    except Exception as e:
        return {"error": f"Parse error: {e}", "url": url}

    title = soup.title.string.strip() if soup.title else final_url

    if mode == "auto":
        result = _auto_detect_and_extract(soup, html_text, final_url)
    elif mode == "table":
        tables = _parse_tables(soup, final_url)
        result = {"type": "tables", "data": tables}
    elif mode == "links":
        links = _extract_links(soup, final_url)
        result = {"type": "links", "data": links}
    elif mode == "emails":
        emails = _extract_emails(html_text)
        result = {"type": "emails", "data": emails}
    elif mode == "images":
        images = _extract_images(soup, final_url)
        result = {"type": "images", "data": images}
    elif mode == "json":
        json_data = _extract_json_data(html_text)
        result = {"type": "json", "data": json_data}
    elif mode == "css" and selector:
        items = _extract_css_selector(soup, selector)
        result = {"type": "css", "selector": selector, "data": items}
    else:
        result = _auto_detect_and_extract(soup, html_text, final_url)

    result["url"] = final_url
    result["title"] = title
    result["scraped_at"] = datetime.now().isoformat()
    return result


async def _send_scrape_result(msg, result: dict):
    """
    Format and send scrape results to Telegram.
    Sends files for large data, inline text for small results.
    """
    if "error" in result:
        await msg.reply_text(
            f"❌ <b>Scrape failed</b>\n<code>{esc(result['error'][:300])}</code>",
            parse_mode=H
        )
        return

    dtype = result.get("type", "unknown")
    data = result.get("data", [])
    title = result.get("title", result["url"])
    url = result["url"]

    summary = (
        f"🕷️ <b>Scrape Complete</b>\n"
        f"📄 <b>{esc(title[:60])}</b>\n"
        f"🔗 <code>{esc(url[:80])}</code>\n"
        f"📊 Type: <b>{esc(dtype)}</b>\n"
    )

    # ── Tables ────────────────────────────────────────────────────────────────
    if dtype == "tables" and data:
        summary += f"📋 Found <b>{len(data)}</b> table(s)\n"
        await msg.reply_text(summary, parse_mode=H)
        for table in data[:5]:  # Send up to 5 tables
            csv_bytes = _tables_to_csv_bytes(table)
            if csv_bytes:
                fname = f"table_{table['table_index']}.csv"
                buf = io.BytesIO(csv_bytes)
                buf.name = fname
                rows = len(table.get("rows", []))
                await msg.reply_document(
                    document=buf,
                    filename=fname,
                    caption=f"📋 Table {table['table_index']} — {rows} rows"
                )
        return

    # ── Links ─────────────────────────────────────────────────────────────────
    if dtype == "links" and data:
        summary += f"🔗 Found <b>{len(data)}</b> links\n"
        csv_bytes = _dict_to_csv_bytes(data[:5000])
        buf = io.BytesIO(csv_bytes)
        buf.name = "links.csv"
        await msg.reply_document(
            document=buf,
            filename="links.csv",
            caption=summary + f"\n<i>First 20 links preview below</i>",
            parse_mode=H
        )
        # Also show first 10 inline
        preview = "\n".join(
            f"• <a href=\"{esc(lk['url'])}\">{esc(lk['text'][:60] or lk['url'][:60])}</a>"
            for lk in data[:10]
        )
        if preview:
            await msg.reply_text(preview, parse_mode=H, disable_web_page_preview=True)
        return

    # ── Emails ────────────────────────────────────────────────────────────────
    if dtype == "emails":
        count = len(data)
        summary += f"📧 Found <b>{count}</b> email(s)\n"
        if count == 0:
            await msg.reply_text(summary + "\n<i>No emails found on this page.</i>", parse_mode=H)
            return
        if count <= 20:
            emails_text = "\n".join(f"• {esc(e)}" for e in data)
            await msg.reply_text(summary + "\n" + emails_text, parse_mode=H)
        else:
            content = "\n".join(data)
            buf = io.BytesIO(content.encode("utf-8"))
            buf.name = "emails.txt"
            await msg.reply_document(
                document=buf,
                filename="emails.txt",
                caption=summary,
                parse_mode=H
            )
        return

    # ── Images ────────────────────────────────────────────────────────────────
    if dtype == "images" and data:
        summary += f"🖼️ Found <b>{len(data)}</b> image(s)\n"
        csv_bytes = _dict_to_csv_bytes(data[:5000])
        buf = io.BytesIO(csv_bytes)
        buf.name = "images.csv"
        await msg.reply_document(
            document=buf,
            filename="images.csv",
            caption=summary,
            parse_mode=H
        )
        return

    # ── JSON data ─────────────────────────────────────────────────────────────
    if dtype == "json" and data:
        summary += f"🟨 Found <b>{len(data)}</b> JSON dataset(s)\n"
        json_str = json.dumps(data, indent=2, ensure_ascii=False)
        if len(json_str) > 4000:
            buf = io.BytesIO(json_str.encode("utf-8"))
            buf.name = "data.json"
            await msg.reply_document(
                document=buf,
                filename="data.json",
                caption=summary,
                parse_mode=H
            )
        else:
            await msg.reply_text(
                summary + f"\n<pre>{esc(json_str[:3000])}</pre>",
                parse_mode=H
            )
        return

    # ── CSS selector ─────────────────────────────────────────────────────────
    if dtype == "css":
        count = len(data)
        summary += f"🎯 Selector matched <b>{count}</b> element(s)\n"
        if count == 0:
            await msg.reply_text(summary + "\n<i>No elements matched selector.</i>", parse_mode=H)
            return
        if count <= 30:
            items_text = "\n".join(f"{i+1}. {esc(it[:200])}" for i, it in enumerate(data))
            await msg.reply_text(summary + "\n" + items_text, parse_mode=H)
        else:
            content = "\n".join(data)
            buf = io.BytesIO(content.encode("utf-8"))
            buf.name = "elements.txt"
            await msg.reply_document(
                document=buf,
                filename="elements.txt",
                caption=summary,
                parse_mode=H
            )
        return

    # ── Lists ─────────────────────────────────────────────────────────────────
    if dtype == "lists" and data:
        all_items = []
        for lst in data:
            all_items.extend(lst)
        summary += f"📝 Found <b>{len(all_items)}</b> list items in <b>{len(data)}</b> list(s)\n"
        if len(all_items) <= 30:
            items_text = "\n".join(f"• {esc(it[:200])}" for it in all_items)
            await msg.reply_text(summary + "\n" + items_text, parse_mode=H)
        else:
            # Send as JSON
            json_str = json.dumps({"lists": data}, indent=2, ensure_ascii=False)
            buf = io.BytesIO(json_str.encode("utf-8"))
            buf.name = "lists.json"
            await msg.reply_document(
                document=buf,
                filename="lists.json",
                caption=summary,
                parse_mode=H
            )
        return

    # ── Plain text fallback ───────────────────────────────────────────────────
    if isinstance(data, list):
        text_content = "\n".join(str(x) for x in data)
    else:
        text_content = str(data)

    summary += f"📝 Extracted <b>{len(text_content):,}</b> chars of text\n"

    if len(text_content) > 3000:
        buf = io.BytesIO(text_content.encode("utf-8"))
        buf.name = "content.txt"
        await msg.reply_document(
            document=buf,
            filename="content.txt",
            caption=summary,
            parse_mode=H
        )
    else:
        await msg.reply_text(
            summary + f"\n<pre>{esc(text_content[:2500])}</pre>",
            parse_mode=H
        )


class ScraperHandlers:
    """Web scraping handler — extract structured data from any website."""

    @require_auth
    async def cmd_scrape(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /scrape <url> [mode]
        
        Modes: auto (default), table, links, emails, images, json, css:<selector>
        
        Examples:
          /scrape wikipedia.org/wiki/Python
          /scrape example.com/products table
          /scrape github.com/trending links
          /scrape news.ycombinator.com css:.titleline
          /scrape quotes.toscrape.com/api/quotes json
        """
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "🕷️ <b>Web Scraper</b>\n\n"
                "<b>Usage:</b> <code>/scrape &lt;url&gt; [mode]</code>\n\n"
                "<b>Modes:</b>\n"
                "• <code>auto</code> — detect best data automatically (default)\n"
                "• <code>table</code> — extract HTML tables → CSV files\n"
                "• <code>links</code> — extract all links → CSV\n"
                "• <code>emails</code> — extract email addresses\n"
                "• <code>images</code> — extract image URLs → CSV\n"
                "• <code>json</code> — extract embedded JSON/API data\n"
                "• <code>css:selector</code> — extract by CSS selector\n\n"
                "<b>Examples:</b>\n"
                "<code>/scrape wikipedia.org/wiki/Python</code>\n"
                "<code>/scrape books.toscrape.com table</code>\n"
                "<code>/scrape github.com/trending links</code>\n"
                "<code>/scrape hn.algolia.com/?tags=front_page json</code>\n"
                "<code>/scrape example.com css:h1,h2,h3</code>",
                parse_mode=H
            )
            return

        url = ctx.args[0]
        mode = "auto"
        selector = ""

        if len(ctx.args) > 1:
            mode_arg = ctx.args[1].lower()
            if mode_arg.startswith("css:"):
                mode = "css"
                selector = mode_arg[4:]
                if not selector and len(ctx.args) > 2:
                    selector = ctx.args[2]
            elif mode_arg in ("table", "links", "emails", "images", "json", "auto"):
                mode = mode_arg
            else:
                # Treat as CSS selector
                mode = "css"
                selector = " ".join(ctx.args[1:])

        status = await msg.reply_text(
            f"🕷️ <i>Scraping {esc(_normalize_url(url)[:60])}…</i>\n"
            f"<i>Mode: {esc(mode)}{' | Selector: ' + esc(selector) if selector else ''}</i>",
            parse_mode=H
        )

        try:
            result = await _do_scrape(url, mode, selector)
            await status.delete()
            await _send_scrape_result(msg, result)
        except Exception as e:
            logger.error(f"Scrape error: {e}", exc_info=True)
            await status.edit_text(
                f"❌ <b>Scrape error:</b> <code>{esc(str(e)[:300])}</code>",
                parse_mode=H
            )

    @require_auth
    async def cmd_scrapebulk(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /scrapebulk <url1> <url2> ... — scrape multiple URLs
        
        Scrapes each URL (same auto-detection), merges compatible results,
        sends as a single combined CSV/JSON file.
        
        Example:
          /scrapebulk books.toscrape.com/catalogue/page-1.html books.toscrape.com/catalogue/page-2.html
        """
        msg = update.effective_message

        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "🕷️ <b>Bulk Scraper</b>\n\n"
                "Scrape multiple pages and merge results.\n\n"
                "<b>Usage:</b> <code>/scrapebulk &lt;url1&gt; &lt;url2&gt; ...</code>\n"
                "(up to 10 URLs at once)\n\n"
                "<b>Example:</b>\n"
                "<code>/scrapebulk books.toscrape.com/catalogue/page-1.html books.toscrape.com/catalogue/page-2.html</code>",
                parse_mode=H
            )
            return

        urls = ctx.args[:10]  # Limit to 10

        status = await msg.reply_text(
            f"🕷️ <b>Bulk scraping {len(urls)} URL(s)…</b>\n"
            f"<i>This may take a moment.</i>",
            parse_mode=H
        )

        all_results = []
        errors = []

        for i, url in enumerate(urls):
            try:
                await status.edit_text(
                    f"🕷️ <b>Bulk scraping…</b> ({i+1}/{len(urls)})\n"
                    f"<i>Fetching: {esc(_normalize_url(url)[:50])}</i>",
                    parse_mode=H
                )
                result = await _do_scrape(url, "auto")
                if "error" not in result:
                    all_results.append(result)
                else:
                    errors.append(f"{url}: {result['error']}")
                await asyncio.sleep(0.5)  # Be respectful
            except Exception as e:
                errors.append(f"{url}: {e}")

        await status.delete()

        if not all_results:
            errs = "\n".join(esc(e) for e in errors[:5])
            await msg.reply_text(
                f"❌ All scrapes failed:\n{errs}",
                parse_mode=H
            )
            return

        # Merge results
        summary = (
            f"🕷️ <b>Bulk Scrape Complete</b>\n"
            f"✅ Scraped: <b>{len(all_results)}</b> pages\n"
            f"{'❌ Failed: ' + str(len(errors)) + chr(10) if errors else ''}"
        )

        # Combine all link-type results
        all_links = []
        all_items = []
        all_json = []

        for r in all_results:
            dtype = r.get("type")
            data = r.get("data", [])
            if dtype == "links":
                all_links.extend(data)
            elif dtype == "json":
                all_json.extend(data)
            elif dtype in ("lists", "text", "css"):
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, list):
                            all_items.extend(item)
                        else:
                            all_items.append(str(item))
            elif dtype == "tables":
                for table in data:
                    rows = table.get("rows", [])
                    all_items.extend([" | ".join(r) for r in rows])

        if all_links:
            csv_bytes = _dict_to_csv_bytes(all_links[:50000])
            buf = io.BytesIO(csv_bytes)
            buf.name = "bulk_links.csv"
            await msg.reply_document(
                document=buf,
                filename="bulk_links.csv",
                caption=summary + f"\n🔗 <b>{len(all_links)}</b> total links",
                parse_mode=H
            )
        elif all_json:
            json_str = json.dumps(all_json, indent=2, ensure_ascii=False)
            buf = io.BytesIO(json_str.encode("utf-8"))
            buf.name = "bulk_data.json"
            await msg.reply_document(
                document=buf,
                filename="bulk_data.json",
                caption=summary + f"\n🟨 <b>{len(all_json)}</b> JSON datasets",
                parse_mode=H
            )
        elif all_items:
            content = "\n".join(str(x) for x in all_items)
            buf = io.BytesIO(content.encode("utf-8"))
            buf.name = "bulk_content.txt"
            await msg.reply_document(
                document=buf,
                filename="bulk_content.txt",
                caption=summary + f"\n📝 <b>{len(all_items)}</b> items",
                parse_mode=H
            )
        else:
            await msg.reply_text(summary + "\n<i>No structured data found.</i>", parse_mode=H)

    @require_auth
    async def cmd_scrapewatch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /scrapewatch <url> <interval_minutes> — Watch URL for content changes.
        
        Checks the page every N minutes. If content changes, sends a diff alert.
        /scrapewatch stop <url> — Stop watching a URL.
        
        Examples:
          /scrapewatch news.ycombinator.com 5
          /scrapewatch coinmarketcap.com/currencies/bitcoin 1
          /scrapewatch stop news.ycombinator.com
        """
        msg = update.effective_message

        if not ctx.args:
            watches_list = "\n".join(
                f"• <code>{esc(url)}</code> every {esc(str(info.get('interval', '?')))}min"
                for url, info in _watches.items()
                if info.get("chat_id") == msg.chat_id
            )
            await msg.reply_text(
                "👁️ <b>URL Watcher</b>\n\n"
                "<b>Usage:</b>\n"
                "<code>/scrapewatch &lt;url&gt; &lt;minutes&gt;</code>\n"
                "<code>/scrapewatch stop &lt;url&gt;</code>\n\n"
                + (f"<b>Active watches:</b>\n{watches_list}" if watches_list else "<i>No active watches.</i>"),
                parse_mode=H
            )
            return

        if ctx.args[0].lower() == "stop":
            if len(ctx.args) < 2:
                await msg.reply_text("Usage: <code>/scrapewatch stop &lt;url&gt;</code>", parse_mode=H)
                return
            url_to_stop = _normalize_url(ctx.args[1])
            if url_to_stop in _watches:
                task = _watches[url_to_stop].get("task")
                if task and not task.done():
                    task.cancel()
                del _watches[url_to_stop]
                await msg.reply_text(f"⏹️ <b>Stopped watching:</b> <code>{esc(url_to_stop[:80])}</code>", parse_mode=H)
            else:
                await msg.reply_text("❌ URL not being watched.", parse_mode=H)
            return

        url = _normalize_url(ctx.args[0])
        try:
            interval_min = max(1, int(ctx.args[1]) if len(ctx.args) > 1 else 5)
        except ValueError:
            interval_min = 5

        if url in _watches:
            old_task = _watches[url].get("task")
            if old_task and not old_task.done():
                old_task.cancel()

        # Fetch initial state
        status = await msg.reply_text(
            f"👁️ <i>Starting watch on {esc(url[:60])}…</i>",
            parse_mode=H
        )

        try:
            html_text, final_url = await asyncio.get_event_loop().run_in_executor(
                None, _fetch_page, url
            )
            initial_hash = _compute_content_hash(html_text)
        except Exception as e:
            await status.edit_text(f"❌ Could not fetch page: <code>{esc(str(e))}</code>", parse_mode=H)
            return

        chat_id = msg.chat_id
        _watches[url] = {
            "chat_id": chat_id,
            "interval": interval_min,
            "last_hash": initial_hash,
            "last_checked": datetime.now().isoformat(),
            "check_count": 0,
        }

        async def watch_loop():
            while True:
                try:
                    await asyncio.sleep(interval_min * 60)
                    if url not in _watches:
                        break

                    try:
                        new_html, _ = await asyncio.get_event_loop().run_in_executor(
                            None, _fetch_page, url
                        )
                        new_hash = _compute_content_hash(new_html)
                    except Exception as fetch_err:
                        logger.warning(f"Watch fetch error for {url}: {fetch_err}")
                        continue

                    info = _watches.get(url, {})
                    info["check_count"] = info.get("check_count", 0) + 1
                    info["last_checked"] = datetime.now().isoformat()

                    if new_hash != info.get("last_hash"):
                        info["last_hash"] = new_hash
                        # Page changed — notify
                        from telegram import Bot
                        bot = update.get_bot()
                        await bot.send_message(
                            chat_id=chat_id,
                            text=(
                                f"🔔 <b>Page Changed!</b>\n"
                                f"🔗 <code>{esc(url[:80])}</code>\n"
                                f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
                                f"🔄 Check #{info['check_count']}"
                            ),
                            parse_mode=H
                        )
                        # Also send a fresh scrape
                        try:
                            result = await _do_scrape(url, "auto")
                            dummy_msg = await bot.send_message(chat_id=chat_id, text="🕷️ Fetching updated content…")
                            await _send_scrape_result(dummy_msg, result)
                        except Exception:
                            pass

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Watch loop error: {e}")

        task = asyncio.create_task(watch_loop())
        _watches[url]["task"] = task

        await status.edit_text(
            f"👁️ <b>Watching URL</b>\n"
            f"🔗 <code>{esc(url[:80])}</code>\n"
            f"⏱️ Check interval: every <b>{interval_min}</b> minute(s)\n"
            f"📌 Initial content hash captured.\n"
            f"🔔 You'll be notified when content changes.\n\n"
            f"<i>Use /scrapewatch stop {esc(url[:40])} to stop.</i>",
            parse_mode=H
        )
