"""
Salim — Control your laptop from Telegram.
"""

__version__ = "2.2.7"
__author__ = "Salim Contributors"
__license__ = "MIT"

from salim.config import Config
from salim.bot import SalimBot

__all__ = ["Config", "SalimBot", "__version__"]
