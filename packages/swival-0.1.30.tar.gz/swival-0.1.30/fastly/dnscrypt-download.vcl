# Fastly VCL Configuration for download.dnscrypt.info
# 
# This configuration caches content from https://dnscrypt.info while sending
# the Host header as download.dnscrypt.info to ensure correct origin routing.

vcl 4.0;

backend dnscrypt_origin {
    .host = "dnscrypt.info";
    .port = "443";
    .ssl = true;
    .ssl_sni_hostname = "dnscrypt.info";
    .ssl_cert_hostname = "dnscrypt.info";
    .connect_timeout = 10s;
    .first_byte_timeout = 30s;
    .between_bytes_timeout = 10s;
}

sub vcl_recv {
    # Override the Host header to download.dnscrypt.info for origin requests
    # This ensures the origin server routes correctly even though we connect to dnscrypt.info
    req.http.Host = "download.dnscrypt.info";

    # Pass through all request headers except Host (which we just set)
    
    # Standard cache bypass conditions
    # Bypass cache for non-GET/HEAD requests
    if (req.method != "GET" && req.method != "HEAD") {
        return (pass);
    }

    # Bypass cache for queries with no-cache or private directives
    if (req.http.Cache-Control) {
        if (req.http.Cache-Control ~ "(no-cache|private)") {
            return (pass);
        }
    }

    # Bypass cache for cookies (typically dynamic content)
    if (req.http.Cookie) {
        return (pass);
    }

    # Normalize URL - remove fragment identifiers
    if (req.url ~ "#") {
        set req.url = regsub(req.url, ".*#", "");
    }

    return (hash);
}

sub vcl_hash {
    # Standard hash based on request
    hash_data(req.http.host);
    hash_data(req.url);
    
    # Include Accept-Encoding in hash to handle different compressions correctly
    if (req.http.Accept-Encoding) {
        if (req.http.Accept-Encoding ~ "gzip") {
            hash_data("gzip");
        }
        if (req.http.Accept-Encoding ~ "br") {
            hash_data("br");
        }
    }
}

sub vcl_hit {
    # Check for stale content that can be served while revalidating
    if (obj.ttl + obj.grace > 0s) {
        return (deliver);
    }
    
    # For stale content, try to revalidate with origin
    return (pass);
}

sub vcl_miss {
    # Standard miss handling - fetch from origin
    return (fetch);
}

sub vcl_fetch {
    # Respect origin's Cache-Control headers
    # Fastly automatically respects: max-age, s-maxage, no-cache, no-store, private
    
    # Set a default TTL if origin doesn't provide caching headers
    # This ensures we cache something even without explicit headers
    if (!resp.http.Cache-Control && !resp.http.Expires) {
        # Default 1 hour for uncached responses
        set obj.ttl = 3600s;
    }

    # Set grace period to serve stale content during origin outages
    # Grace allows serving expired content for up to 24 hours if origin is down
    set obj.grace = 86400s;

    # Respect origin's Vary headers for proper cache key differentiation
    # Common values: Accept-Encoding, User-Agent, etc.
    
    # Add Fastly-specific headers for debugging (optional)
    # set resp.http.X-Cache-Key = req.url;
}

sub vcl_deliver {
    # Remove internal headers that shouldn't be exposed to clients
    
    # Add cache status header for debugging (Fastly standard practice)
    # set resp.http.X-Served-By = server.identity;
    
    return (deliver);
}

sub vcl_pass {
    # Pass requests through to origin without caching
    return (pass);
}
