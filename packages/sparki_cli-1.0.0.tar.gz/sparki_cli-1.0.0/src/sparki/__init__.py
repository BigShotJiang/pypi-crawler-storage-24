"""Sparki — video editor CLI."""

from importlib.metadata import version

__version__ = version("sparki-cli")
