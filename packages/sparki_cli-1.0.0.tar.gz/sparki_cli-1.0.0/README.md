# Sparki

AI-powered video editing from the command line.

## Installation

```
pip install sparki-cli
```

Or with [uv](https://docs.astral.sh/uv/):

```
uv tool install sparki-cli
```

## Quick Start

```bash
# Save your API key
sparki setup --api-key YOUR_KEY

# Upload, edit, and download in one step
sparki run --file video.mp4 --mode style-guided --style vlog/daily

# Or step by step
sparki upload --file video.mp4
sparki edit --object-key KEY --mode prompt-driven --prompt "Make a highlight reel"
sparki status --task-id TASK_ID
sparki download --task-id TASK_ID
```

## Commands

| Command | Description |
|---------|-------------|
| `setup` | Save and validate your API key |
| `upload` | Upload video files |
| `assets` | List uploaded assets |
| `edit` | Create an edit project |
| `status` | Check project status |
| `download` | Download completed result |
| `run` | End-to-end: upload → edit → download |
| `history` | List recent projects |

## Edit Modes

- **style-guided** — Choose from preset styles (e.g. `vlog/daily`, `montage/highlight-reel`)
- **prompt-driven** — Describe what you want in natural language
- **style-clone** — Clone the style of a reference video

## Links

- Website: https://sparki.io
- Telegram: https://t.me/Sparki_AI_bot
