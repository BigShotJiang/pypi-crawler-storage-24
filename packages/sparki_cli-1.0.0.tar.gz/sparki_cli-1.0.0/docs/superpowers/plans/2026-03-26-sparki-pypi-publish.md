# Sparki PyPI Publishing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extract the Sparki CLI from sparki-video-editor, set up the new repo with CI/CD, and prepare for PyPI publishing via Trusted Publisher.

**Architecture:** Copy source files from `sparki-video-editor/src/sparki_cli/` to `src/sparki/`, rename all internal imports, configure hatchling build, and set up two GitHub Actions workflows (test + publish with OIDC).

**Tech Stack:** Python 3.11+, Typer, httpx, Pydantic, hatchling, GitHub Actions, PyPI Trusted Publisher

**Spec:** `docs/superpowers/specs/2026-03-26-sparki-pypi-publish-design.md`

**Prerequisite:** Confirm `sparki` is available on PyPI (https://pypi.org/project/sparki/) before starting. If taken, the package name must be changed.

---

### Task 1: Fix .gitignore and create project skeleton

**Files:**
- Modify: `.gitignore`
- Create: `src/sparki/__init__.py`
- Create: `pyproject.toml`
- Create: `LICENSE`

- [ ] **Step 1: Fix .gitignore**

Remove `docs/`, `tests/`, and `uv.lock` from `.gitignore`. These need to be tracked.

Current `.gitignore` lines 27-31:
```
# Project-specific
docs/
tests/
uv.lock
.worktrees/
```

Replace with:
```
# Project-specific
.worktrees/
```

- [ ] **Step 2: Create pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "sparki"
version = "1.0.0"
description = "Sparki video editor CLI"
readme = "README.md"
requires-python = ">=3.11"
license = "MIT"
authors = [
    { name = "Sparki AI" }
]
classifiers = [
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Environment :: Console",
    "License :: OSI Approved :: MIT License",
]
dependencies = [
    "typer>=0.9.0",
    "httpx>=0.27.0",
    "pydantic>=2.0.0",
]

[project.scripts]
sparki = "sparki.cli:app"

[tool.hatch.build.targets.wheel]
packages = ["src/sparki"]

[tool.pytest.ini_options]
testpaths = ["tests"]
asyncio_mode = "auto"

[dependency-groups]
dev = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
    "respx>=0.21.0",
]
```

- [ ] **Step 3: Create src/sparki/__init__.py**

```python
"""Sparki — AI video editing CLI."""

from importlib.metadata import version

__version__ = version("sparki")
```

- [ ] **Step 4: Create LICENSE**

MIT license with copyright holder "Sparki AI".

- [ ] **Step 5: Commit**

```bash
git add .gitignore pyproject.toml src/sparki/__init__.py LICENSE docs/
git commit -m "chore: initialize project skeleton with pyproject.toml and MIT license"
```

---

### Task 2: Migrate source files with import rename

**Files:**
- Create: `src/sparki/constants.py` (from `sparki_cli/constants.py` — no internal imports to rename)
- Create: `src/sparki/output.py` (from `sparki_cli/output.py` — rename `sparki_cli` → `sparki`)
- Create: `src/sparki/models.py` (from `sparki_cli/models.py` — rename `sparki_cli` → `sparki`)
- Create: `src/sparki/config.py` (from `sparki_cli/config.py` — rename `sparki_cli` → `sparki`)
- Create: `src/sparki/client.py` (from `sparki_cli/client.py` — no internal imports to rename)
- Create: `src/sparki/cli.py` (from `sparki_cli/cli.py` — rename `sparki_cli` → `sparki`)

The files have these import dependencies:
```
constants.py  ← (no internal imports, leaf module)
output.py     ← imports from constants
models.py     ← imports from constants
config.py     ← imports from constants
client.py     ← (no internal imports, leaf module)
cli.py        ← imports from client, config, constants, output
```

- [ ] **Step 1: Copy constants.py (no changes needed)**

Copy `/Users/void/Documents/code/sparki-skills/sparki-video-editor/src/sparki_cli/constants.py` to `src/sparki/constants.py`. This file has no internal imports — copy as-is.

- [ ] **Step 2: Copy client.py (no changes needed)**

Copy `/Users/void/Documents/code/sparki-skills/sparki-video-editor/src/sparki_cli/client.py` to `src/sparki/client.py`. This file has no internal imports — copy as-is.

- [ ] **Step 3: Copy output.py with rename**

Copy to `src/sparki/output.py`. Change:
```python
from sparki_cli.constants import ERROR_CODES
```
to:
```python
from sparki.constants import ERROR_CODES
```

- [ ] **Step 4: Copy models.py with rename**

Copy to `src/sparki/models.py`. Change:
```python
from sparki_cli.constants import TELEGRAM_FILE_SIZE_LIMIT
```
to:
```python
from sparki.constants import TELEGRAM_FILE_SIZE_LIMIT
```

- [ ] **Step 5: Copy config.py with rename**

Copy to `src/sparki/config.py`. Change:
```python
from sparki_cli.constants import DEFAULT_BASE_URL, DEFAULT_UPLOAD_TG_LINK
```
to:
```python
from sparki.constants import DEFAULT_BASE_URL, DEFAULT_UPLOAD_TG_LINK
```

- [ ] **Step 6: Copy cli.py with rename**

Copy to `src/sparki/cli.py`. Replace only the module prefix `sparki_cli` with `sparki` in import lines; keep all imported names unchanged. The four import blocks to change:

```python
from sparki.client import SparkiClient
from sparki.config import Config, DEFAULT_CONFIG_DIR
from sparki.constants import (
    ALLOWED_EXTENSIONS,
    MAX_FILES_PER_UPLOAD,
    MAX_UPLOAD_SIZE,
    EditMode,
    VALID_DURATION_RANGES,
    TELEGRAM_FILE_SIZE_LIMIT,
    validate_style,
    style_to_payload,
    DEFAULT_ASSET_POLL_INTERVAL,
    DEFAULT_ASSET_POLL_TIMEOUT,
    DEFAULT_PROJECT_POLL_INTERVAL,
    DEFAULT_PROJECT_POLL_TIMEOUT,
)
from sparki.output import log, print_error, print_success
```

- [ ] **Step 7: Verify imports resolve**

Run: `cd /Users/void/Documents/code/sparki-cli && uv sync && uv run python -c "from sparki.cli import app; print('OK')"`

Expected: `OK`

- [ ] **Step 8: Commit**

```bash
git add src/sparki/
git commit -m "feat: migrate CLI source from sparki-video-editor with import rename"
```

---

### Task 3: Add smoke test

**Files:**
- Create: `tests/__init__.py`
- Create: `tests/test_smoke.py`

- [ ] **Step 1: Create tests/__init__.py**

Empty file.

- [ ] **Step 2: Write smoke test**

Create `tests/test_smoke.py`:

```python
"""Smoke tests — verify the package loads and CLI is importable."""

from sparki import __version__
from sparki.cli import app


def test_version_is_semver():
    assert isinstance(__version__, str)
    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)


def test_cli_app_has_commands():
    assert app is not None
    command_names = [cmd.name for cmd in app.registered_commands]
    assert "setup" in command_names
    assert "upload" in command_names
    assert "run" in command_names
```

- [ ] **Step 3: Run tests**

Run: `cd /Users/void/Documents/code/sparki-cli && uv run pytest tests/ -v`

Expected: 2 tests PASS

- [ ] **Step 4: Commit**

```bash
git add tests/
git commit -m "test: add smoke tests for package import and CLI app"
```

---

### Task 4: Create GitHub Actions — CI workflow

**Files:**
- Create: `.github/workflows/test.yml`

- [ ] **Step 1: Create .github/workflows/ directory**

```bash
mkdir -p /Users/void/Documents/code/sparki-cli/.github/workflows
```

- [ ] **Step 2: Create test.yml**

```yaml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.11", "3.12", "3.13"]
    steps:
      - uses: actions/checkout@v4

      - uses: astral-sh/setup-uv@v5

      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}

      - name: Install dependencies
        run: uv sync

      - name: Run tests
        run: uv run pytest tests/ -v
```

- [ ] **Step 3: Commit**

```bash
git add .github/workflows/test.yml
git commit -m "ci: add test workflow with Python 3.11-3.13 matrix"
```

---

### Task 5: Create GitHub Actions — Publish workflow

**Files:**
- Create: `.github/workflows/publish.yml`

- [ ] **Step 1: Create publish.yml**

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
      contents: read
    steps:
      - uses: actions/checkout@v4

      - uses: astral-sh/setup-uv@v5

      - uses: actions/setup-python@v5
        with:
          python-version: "3.13"

      - name: Verify version matches tag
        run: |
          PKG_VERSION=$(python -c "import tomllib; print(tomllib.load(open('pyproject.toml','rb'))['project']['version'])")
          TAG_VERSION="${GITHUB_REF_NAME#v}"
          if [ "$PKG_VERSION" != "$TAG_VERSION" ]; then
            echo "::error::Version mismatch: pyproject.toml=$PKG_VERSION tag=$TAG_VERSION"
            exit 1
          fi
          echo "Version $PKG_VERSION matches tag $TAG_VERSION"

      - name: Build package
        run: uv build

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
```

- [ ] **Step 2: Commit**

```bash
git add .github/workflows/publish.yml
git commit -m "ci: add PyPI publish workflow with Trusted Publisher OIDC"
```

---

### Task 6: Create README.md

**Files:**
- Create: `README.md`

- [ ] **Step 1: Create README.md**

```markdown
# Sparki

AI-powered video editing from the command line.

## Installation

```
pip install sparki
```

Or with [uv](https://docs.astral.sh/uv/):

```
uv tool install sparki
```

## Quick Start

```bash
# Save your API key
sparki setup --api-key YOUR_KEY

# Upload, edit, and download in one step
sparki run --file video.mp4 --mode style-guided --style vlog/daily

# Or step by step
sparki upload --file video.mp4
sparki edit --object-key KEY --mode prompt-driven --prompt "Make a highlight reel"
sparki status --task-id TASK_ID
sparki download --task-id TASK_ID
```

## Commands

| Command | Description |
|---------|-------------|
| `setup` | Save and validate your API key |
| `upload` | Upload video files |
| `assets` | List uploaded assets |
| `edit` | Create an edit project |
| `status` | Check project status |
| `download` | Download completed result |
| `run` | End-to-end: upload → edit → download |
| `history` | List recent projects |

## Edit Modes

- **style-guided** — Choose from preset styles (e.g. `vlog/daily`, `montage/highlight-reel`)
- **prompt-driven** — Describe what you want in natural language
- **style-clone** — Clone the style of a reference video

## Links

- Website: https://sparki.io
- Telegram: https://t.me/Sparki_AI_bot
```

- [ ] **Step 2: Commit**

```bash
git add README.md
git commit -m "docs: add README with installation and usage"
```

---

### Task 7: Generate lockfile and push

**Files:**
- Create: `uv.lock` (generated)

- [ ] **Step 1: Generate uv.lock**

Run: `cd /Users/void/Documents/code/sparki-cli && uv sync`

This generates `uv.lock` with pinned dependency versions.

- [ ] **Step 2: Commit lockfile**

```bash
git add uv.lock
git commit -m "chore: add uv.lock for reproducible builds"
```

- [ ] **Step 3: Push to GitHub**

```bash
git remote add origin git@github.com:sparki-ai/sparki-cli.git
git push -u origin main
```

---

### Task 8: Configure PyPI and GitHub (manual steps)

These steps must be done by the user in the browser.

- [ ] **Step 1: Create PyPI Trusted Publisher**

Go to https://pypi.org/manage/account/publishing/ and add a pending publisher:
- PyPI project name: `sparki`
- Owner: `sparki-ai`
- Repository: `sparki-cli`
- Workflow name: `publish.yml`
- Environment name: `pypi`

- [ ] **Step 2: Create GitHub environment**

Go to https://github.com/sparki-ai/sparki-cli/settings/environments and create an environment named `pypi`.

- [ ] **Step 3: Set up branch protection**

Go to https://github.com/sparki-ai/sparki-cli/settings/branches and add a rule for `main`:
- Require pull request reviews before merging
- Require status checks to pass (select the `test` workflow)
- Do not allow bypassing these settings

---

### Task 9: First release

- [ ] **Step 1: Create tag and release**

```bash
git tag v1.0.0
git push origin v1.0.0
```

Then create a GitHub Release from the `v1.0.0` tag via the GitHub UI or:

```bash
gh release create v1.0.0 --title "v1.0.0" --notes "Initial release of Sparki CLI"
```

- [ ] **Step 2: Verify publish**

Check the Actions tab on GitHub to confirm the publish workflow succeeds. Then verify:

```bash
pip install sparki
sparki --help
```
