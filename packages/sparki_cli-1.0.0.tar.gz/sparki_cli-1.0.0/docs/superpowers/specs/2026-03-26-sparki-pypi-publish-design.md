# Sparki CLI PyPI Publishing Design

## Overview

Extract the CLI from `sparki-skill/sparki-video-editor` into the standalone `sparki-cli` repo and publish it to PyPI as `sparki`, with automated CI/CD via GitHub Actions and PyPI Trusted Publisher.

**Repo:** `github.com/sparki-ai/sparki-cli`
**PyPI package name:** `sparki`
**CLI command:** `sparki`
**Initial version:** `1.0.0`

## 1. Code Migration & Rename

**Source:** `sparki-video-editor/src/sparki_cli/`
**Destination:** `sparki-cli/src/sparki/`

Files to copy and rename:
- `__init__.py` — remove hardcoded version, use `importlib.metadata` instead; rename all `sparki_cli` references to `sparki`
- `cli.py` — rename internal imports
- `client.py` — rename internal imports
- `config.py` — rename internal imports
- `constants.py` — rename internal imports
- `models.py` — rename internal imports
- `output.py` — rename internal imports

All `from sparki_cli` / `import sparki_cli` become `from sparki` / `import sparki`.

**Version single source of truth:** Version is defined only in `pyproject.toml`. `__init__.py` reads it at runtime via:
```python
from importlib.metadata import version
__version__ = version("sparki")
```
This eliminates version drift between files.

## 2. Project Configuration (pyproject.toml)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "sparki"
version = "1.0.0"
description = "Sparki video editor CLI"
readme = "README.md"
requires-python = ">=3.11"
license = "MIT"
authors = [
    { name = "Sparki AI" }
]
dependencies = [
    "typer>=0.9.0",
    "httpx>=0.27.0",
    "pydantic>=2.0.0",
]

[project.scripts]
sparki = "sparki.cli:app"

[tool.hatch.build.targets.wheel]
packages = ["src/sparki"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

## 3. GitHub Actions Workflows

### 3a. CI — test.yml

**Triggers:** push to `main`, pull requests to `main`

**Matrix:** Python 3.11, 3.12, 3.13

**Steps:**
1. Checkout code
2. Install uv
3. Set up Python (matrix version)
4. Install dependencies with `uv sync`
5. Run `pytest`

### 3b. Publish — publish.yml

**Trigger:** GitHub Release published (`types: [published]`, tag matching `v*`). Uses `published` rather than `created` to prevent accidental publishes from draft releases.

**Environment:** `pypi` (required for Trusted Publisher OIDC)

**Permissions:** Must explicitly declare:
```yaml
permissions:
  id-token: write   # Required for OIDC token exchange with PyPI
  contents: read     # Required for checkout (explicit permissions override all defaults)
```

**Steps:**
1. Checkout code
2. Install uv
3. Set up Python
4. **Version check** — extract version from `pyproject.toml`, compare with tag (strip `v` prefix). Fail if mismatch.
5. Build with `uv build`
6. Publish to PyPI using `pypa/gh-action-pypi-publish@release/v1` (uses OIDC, no token needed)

**Action pinning:** `pypa/gh-action-pypi-publish` is pinned to `release/v1` for reproducibility and supply-chain safety.

## 4. PyPI Trusted Publisher Setup

**Prerequisite:** Confirm `sparki` is available on PyPI before proceeding. The name must not be taken or reserved.

Manual steps on pypi.org (must be done by user):

1. Go to https://pypi.org/manage/account/publishing/
2. Add a new pending publisher:
   - **PyPI project name:** `sparki`
   - **Owner:** `sparki-ai`
   - **Repository:** `sparki-cli`
   - **Workflow name:** `publish.yml`
   - **Environment name:** `pypi`
3. On GitHub, create an environment named `pypi` in repo settings

## 5. GitHub Repo Configuration

### Branch protection on `main`:
- Require pull request reviews before merging
- Require status checks to pass (the CI test workflow)
- Do not allow bypassing these settings

### README.md:
- Package description
- Installation: `pip install sparki`
- Basic usage
- Link to docs/homepage

## 6. Version Check Logic

In the publish workflow, before building:

```bash
PKG_VERSION=$(python -c "import tomllib; print(tomllib.load(open('pyproject.toml','rb'))['project']['version'])")
TAG_VERSION="${GITHUB_REF_NAME#v}"
if [ "$PKG_VERSION" != "$TAG_VERSION" ]; then
  echo "Version mismatch: pyproject.toml=$PKG_VERSION tag=$TAG_VERSION"
  exit 1
fi
```

This prevents publishing when the developer forgets to update the version in `pyproject.toml`.

## 7. Release Workflow (Developer Process)

1. Update version in `pyproject.toml` (single source of truth)
2. Commit and push to `main` (via PR)
3. Create git tag: `git tag v1.0.0`
4. Push tag: `git push origin v1.0.0`
5. Create GitHub Release from the tag (publishing the release triggers CI)
6. CI automatically builds and publishes to PyPI

## 8. .gitignore Fix

The current `.gitignore` excludes `docs/` and `tests/`. These must be removed so the design docs and test files are tracked by git.

## 9. File Structure

```
sparki-cli/
  .github/
    workflows/
      test.yml
      publish.yml
  src/
    sparki/
      __init__.py
      cli.py
      client.py
      config.py
      constants.py
      models.py
      output.py
  tests/
  pyproject.toml
  README.md
  LICENSE
  .gitignore
```
