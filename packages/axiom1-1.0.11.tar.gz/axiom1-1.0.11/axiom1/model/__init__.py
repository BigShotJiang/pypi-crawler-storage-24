# ─────────────────────────────────────────────────────────
# EGen Labs | ErebusTN
# AXIOM-1 — EGen-Core/AXIOM-1
# File: axiom1/model/__init__.py
# ─────────────────────────────────────────────────────────

from axiom1.model.config import AXIOM1Config
from axiom1.model.model import AXIOM1

__all__ = ["AXIOM1Config", "AXIOM1"]
