# ─────────────────────────────────────────────────────────
# EGen Labs | ErebusTN
# AXIOM-1 — EGen-Core/AXIOM-1
# File: axiom1/tokenizer/__init__.py
# ─────────────────────────────────────────────────────────
from axiom1.tokenizer.tokenizer import AXIOM1Tokenizer
