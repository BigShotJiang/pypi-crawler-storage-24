"""Track processing widgets."""
