import os as _os
import subprocess as _subprocess
import pathlib as _pathlib

import addict as _adict
import click as _click

import coop.core as _coop_core
import coop.common.entity as _coop_common_entity
import coop.core.cli as _coop_core_cli

@_click.group(
    cls=_coop_core_cli.ClickGroupPlugin,
    entry_points_group="coop.openapi",
)
@_click.pass_context
def entrypoint(ctx: _coop_core_cli.click.Context) -> None: # noqa: D103
    ctx.obj = _adict.Dict()
    ctx.ensure_object(_adict.Dict)

@entrypoint.command(
    "generator",
    context_settings=dict(
        ignore_unknown_options=True, 
        allow_extra_args=True,
    )
)
@_coop_core_cli.click.pass_context
def generator(
    ctx: _coop_core_cli.click.Context,
) -> None:
    argv = ctx.args
    cmd = ["openapi-generator-cli"] + argv
    _subprocess.run(cmd, check=True)
