from typing import Any

from django.http import HttpRequest, HttpResponse
from wagtail.admin import messages as messages
from wagtail.admin.panels import (
    ObjectList as ObjectList,
)
from wagtail.admin.panels import (
    extract_panel_definitions_from_model_class as extract_panel_definitions_from_model_class,
)
from wagtail.admin.views import generic as generic
from wagtail.models.sites import Site as Site
from wagtail.permission_policies import ModelPermissionPolicy

from .forms import SiteSwitchForm as SiteSwitchForm
from .models import BaseGenericSetting as BaseGenericSetting
from .models import BaseSiteSetting as BaseSiteSetting
from .registry import registry as registry

def get_model_from_url_params(app_name: str, model_name: str) -> type: ...
def get_setting_edit_handler(model: type) -> ObjectList: ...
def redirect_to_relevant_instance(request: HttpRequest, app_name: str, model_name: str) -> HttpResponse: ...

class EditView(generic.EditView):
    template_name: str
    edit_url_name: str
    error_message: str
    permission_required: str
    app_name: str
    model_name: str
    model: type
    permission_policy: ModelPermissionPolicy
    pk: Any
    def setup(self, request: HttpRequest, app_name: str, model_name: str, *args: Any, **kwargs: Any) -> None: ...
    def get_header_icon(self) -> str | None: ...
    site: Site | None
    def get_object(self, queryset: Any = None) -> Any: ...
    def get_panel(self) -> ObjectList: ...
    def get_edit_url(self) -> str: ...
    def get_success_buttons(self) -> None: ...
    def get_page_subtitle(self) -> str: ...
    def get_context_data(self, **kwargs: Any) -> dict[str, Any]: ...
    def get_success_url(self) -> str: ...
    def get_success_message(self) -> str: ...
