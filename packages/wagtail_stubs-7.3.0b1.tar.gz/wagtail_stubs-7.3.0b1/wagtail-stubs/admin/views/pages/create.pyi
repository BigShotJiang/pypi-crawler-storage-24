from collections.abc import Callable
from typing import Any

from django.contrib.contenttypes.models import ContentType
from django.http import HttpRequest, HttpResponse, HttpResponseBase
from django.utils.functional import cached_property as cached_property
from django.views.generic.base import View
from wagtail.admin import messages as messages
from wagtail.admin.action_menu import PageActionMenu as PageActionMenu
from wagtail.admin.forms.pages import WagtailAdminPageForm
from wagtail.admin.panels.base import Panel
from wagtail.admin.ui.components import MediaContainer as MediaContainer
from wagtail.admin.ui.side_panels import (
    ChecksSidePanel as ChecksSidePanel,
)
from wagtail.admin.ui.side_panels import (
    CommentsSidePanel as CommentsSidePanel,
)
from wagtail.admin.ui.side_panels import (
    PageStatusSidePanel as PageStatusSidePanel,
)
from wagtail.admin.ui.side_panels import (
    PreviewSidePanel as PreviewSidePanel,
)
from wagtail.admin.utils import get_valid_next_url_from_request as get_valid_next_url_from_request
from wagtail.admin.views.generic import HookResponseMixin as HookResponseMixin
from wagtail.admin.views.generic.base import WagtailAdminTemplateMixin as WagtailAdminTemplateMixin
from wagtail.models.i18n import Locale as Locale
from wagtail.models.pages import Page as Page
from wagtail.models.pages import PagePermissionTester
from wagtail.models.pages import PageSubscription as PageSubscription
from wagtail.models.pages import PageViewRestriction as PageViewRestriction
from wagtail.models.view_restrictions import BaseViewRestriction as BaseViewRestriction
from wagtail.signals import init_new_page as init_new_page

def add_subpage(request: HttpRequest, parent_page_id: int) -> HttpResponseBase: ...

class CreateView(WagtailAdminTemplateMixin, HookResponseMixin, View):
    template_name: str
    page_title: str
    edit_url_name: str
    parent_page: Page
    parent_page_perms: PagePermissionTester
    page_content_type: ContentType
    page_class: type[Page]
    locale: Locale | None
    page: Page
    translations: list[dict[str, Any]]
    edit_handler: Panel
    form_class: type[WagtailAdminPageForm]
    subscription: PageSubscription
    next_url: str | None
    def dispatch(
        self, request: HttpRequest, content_type_app_name: str, content_type_model_name: str, parent_page_id: int
    ) -> HttpResponseBase: ...
    form: WagtailAdminPageForm
    def post(self, request: HttpRequest) -> HttpResponse: ...
    @cached_property
    def action_name_and_method(self) -> tuple[str, Callable[[], HttpResponseBase | None]]: ...
    @property
    def action_name(self) -> str: ...
    @property
    def action_method(self) -> Callable[[], HttpResponseBase | None]: ...
    def form_valid(self, form: WagtailAdminPageForm) -> HttpResponseBase | None: ...
    def get_page_subtitle(self) -> str: ...
    def get_edit_message_button(self) -> messages.button: ...
    def get_edit_url(self) -> str: ...
    def get_view_draft_message_button(self) -> messages.button: ...
    def get_view_live_message_button(self) -> messages.button: ...
    def set_default_privacy_setting(self) -> None: ...
    def save_action(self) -> HttpResponseBase | None: ...
    def publish_action(self) -> HttpResponseBase | None: ...
    def submit_action(self) -> HttpResponseBase | None: ...
    def redirect_away(self) -> HttpResponseBase: ...
    def redirect_and_remain(self) -> HttpResponseBase: ...
    has_unsaved_changes: bool
    def form_invalid(self, form: WagtailAdminPageForm) -> HttpResponse: ...
    def get(self, request: HttpRequest) -> HttpResponse: ...
    def get_preview_url(self) -> str: ...
    def get_side_panels(self) -> MediaContainer: ...
    def get_context_data(self, **kwargs: Any) -> dict[str, Any]: ...
    def get_translations(self) -> list[dict[str, Any]]: ...
