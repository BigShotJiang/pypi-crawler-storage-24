from __future__ import annotations

import argparse
from pathlib import Path

from llm_logparser.core.i18n import _


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="llm-logparser",
        description=_("cli.description"),
    )
    parser.add_argument(
        "--locale",
        "--lang",
        dest="locale",
        default=None,
        help=_("cli.option.lang.help"),
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        default=None,
        help=_("cli.option.log_level.help"),
    )
    parser.add_argument("--config", type=Path, help=_("cli.option.config.help"))
    parser.add_argument("--profile", help=_("cli.option.profile.help"))
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help=_("cli.option.non_interactive.help"),
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    parse_cmd = subparsers.add_parser(
        "parse",
        help=_("cli.parse.help"),
    )
    parse_cmd.add_argument(
        "--provider",
        required=False,
        help=_("cli.parse.opt.provider.help"),
    )
    parse_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.parse.opt.input.help"),
    )
    parse_cmd.add_argument(
        "--outdir",
        required=False,
        type=Path,
        default=Path("artifacts"),
        help=_("cli.parse.opt.outdir.help"),
    )
    parse_cmd.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        help=_("cli.parse.opt.dry_run.help"),
    )
    parse_cmd.add_argument(
        "--fail-fast",
        dest="fail_fast",
        action="store_true",
        help=_("cli.parse.opt.fail_fast.help"),
    )
    parse_cmd.add_argument(
        "--validate-schema",
        dest="validate_schema",
        action="store_true",
        help=_("cli.parse.opt.validate_schema.help"),
    )

    export_cmd = subparsers.add_parser(
        "export",
        help=_("cli.export.help"),
    )
    export_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.export.opt.input.help"),
    )
    export_cmd.add_argument(
        "--out",
        required=False,
        type=Path,
        help=_("cli.export.opt.out.help"),
    )
    export_cmd.add_argument(
        "--timezone",
        "--tz",
        dest="timezone",
        required=False,
        default="UTC",
        help=_("cli.option.timezone.help"),
    )
    export_cmd.add_argument(
        "--formatting",
        choices=["none", "light"],
        default="light",
        help=_("cli.option.formatting.help"),
    )
    export_cmd.add_argument("--split", dest="split", help=_("cli.option.split.help"))
    export_cmd.add_argument("--split-soft-overflow", dest="split_soft_overflow", type=float, default=0.20)
    export_cmd.add_argument("--split-hard", dest="split_hard", action="store_true")
    export_cmd.add_argument("--split-preview", dest="split_preview", action="store_true")
    export_cmd.add_argument(
        "--tiny-tail-threshold",
        dest="tiny_tail_threshold",
        type=int,
        default=20,
        help=_("cli.option.tiny_tail_threshold.help"),
    )

    extract_cmd = subparsers.add_parser(
        "extract",
        help=_("cli.extract.help"),
    )
    extract_cmd.add_argument(
        "--provider",
        required=False,
        help=_("cli.parse.opt.provider.help"),
    )
    extract_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.parse.opt.input.help"),
    )
    extract_cmd.add_argument(
        "--conversation-id",
        required=False,
        help=_("cli.extract.opt.conversation_id.help"),
    )
    extract_cmd.add_argument(
        "--outdir",
        required=False,
        type=Path,
        default=Path("artifacts"),
        help=_("cli.extract.opt.outdir.help"),
    )
    extract_cmd.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        help=_("cli.parse.opt.dry_run.help"),
    )

    analyze_cmd = subparsers.add_parser(
        "analyze",
        help=_("cli.analyze.help"),
    )
    analyze_subparsers = analyze_cmd.add_subparsers(
        dest="analyze_command",
        required=True,
    )
    analyze_stats_cmd = analyze_subparsers.add_parser(
        "stats",
        help=_("cli.analyze.stats.help"),
    )
    analyze_stats_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.analyze.opt.input.help"),
    )
    analyze_stats_cmd.add_argument(
        "--json",
        dest="json",
        action="store_true",
        help=_("cli.analyze.opt.json.help"),
    )
    analyze_stats_cmd.add_argument(
        "--out",
        required=False,
        type=Path,
        help=_("cli.analyze.opt.out.help"),
    )
    analyze_stats_cmd.add_argument(
        "--per-thread",
        dest="per_thread",
        action="store_true",
        help=_("cli.analyze.stats.opt.per_thread.help"),
    )
    analyze_stats_cmd.add_argument(
        "--top",
        required=False,
        type=int,
        help=_("cli.analyze.stats.opt.top.help"),
    )
    analyze_stats_cmd.add_argument(
        "--sort",
        choices=["messages", "chars", "span", "conversation_id"],
        default=None,
        help=_("cli.analyze.stats.opt.sort.help"),
    )
    analyze_stats_cmd.add_argument(
        "--include-role-breakdown",
        dest="include_role_breakdown",
        action="store_true",
        help=_("cli.analyze.stats.opt.include_role_breakdown.help"),
    )

    analyze_timeline_cmd = analyze_subparsers.add_parser(
        "timeline",
        help=_("cli.analyze.timeline.help"),
    )
    analyze_timeline_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.analyze.opt.input.help"),
    )
    analyze_timeline_cmd.add_argument(
        "--bucket",
        choices=["hour", "day", "week", "month"],
        default="day",
        help=_("cli.analyze.timeline.opt.bucket.help"),
    )
    analyze_timeline_cmd.add_argument(
        "--json",
        dest="json",
        action="store_true",
        help=_("cli.analyze.opt.json.help"),
    )
    analyze_timeline_cmd.add_argument(
        "--out",
        required=False,
        type=Path,
        help=_("cli.analyze.opt.out.help"),
    )

    analyze_tokens_cmd = analyze_subparsers.add_parser(
        "tokens",
        help=_("cli.analyze.tokens.help"),
        description=_("cli.analyze.tokens.help"),
    )
    analyze_tokens_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.analyze.opt.input.help"),
    )
    analyze_tokens_cmd.add_argument(
        "--model",
        required=False,
        help=_("cli.analyze.tokens.opt.model.help"),
    )
    analyze_tokens_cmd.add_argument(
        "--encoding",
        required=False,
        help=_("cli.analyze.tokens.opt.encoding.help"),
    )
    analyze_tokens_cmd.add_argument(
        "--skip-existing",
        dest="skip_existing",
        action="store_true",
        help=_("cli.analyze.opt.skip_existing.help"),
    )
    analyze_tokens_cmd.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        help=_("cli.analyze.opt.dry_run.help"),
    )

    analyze_metrics_cmd = analyze_subparsers.add_parser(
        "metrics",
        help=_("cli.analyze.metrics.help"),
        description=_("cli.analyze.metrics.help"),
    )
    analyze_metrics_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.analyze.opt.input.help"),
    )
    analyze_metrics_cmd.add_argument(
        "--skip-existing",
        dest="skip_existing",
        action="store_true",
        help=_("cli.analyze.opt.skip_existing.help"),
    )
    analyze_metrics_cmd.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        help=_("cli.analyze.opt.dry_run.help"),
    )

    analyze_sqlite_build_cmd = analyze_subparsers.add_parser(
        "sqlite-build",
        help=_("cli.analyze.sqlite_build.help"),
    )
    analyze_sqlite_build_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.analyze.sqlite_build.opt.input.help"),
    )
    analyze_sqlite_build_cmd.add_argument(
        "--provider",
        required=False,
        help=_("cli.analyze.sqlite_build.opt.provider.help"),
    )
    analyze_sqlite_build_cmd.add_argument(
        "--overwrite",
        dest="overwrite",
        action="store_true",
        help=_("cli.analyze.sqlite_build.opt.overwrite.help"),
    )

    chain_cmd = subparsers.add_parser(
        "chain",
        help=_("cli.chain.help"),
    )
    chain_cmd.add_argument(
        "--provider",
        required=False,
        help=_("cli.parse.opt.provider.help"),
    )
    chain_cmd.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        help=_("cli.parse.opt.dry_run.help"),
    )
    chain_cmd.add_argument(
        "--input",
        required=False,
        type=Path,
        help=_("cli.parse.opt.input.help"),
    )
    chain_cmd.add_argument(
        "--outdir",
        required=False,
        type=Path,
        default=Path("artifacts"),
        help=_("cli.chain.opt.outdir.help"),
    )
    chain_cmd.add_argument(
        "--timezone",
        "--tz",
        dest="timezone",
        required=False,
        default="UTC",
        help=_("cli.option.timezone.help"),
    )
    chain_cmd.add_argument(
        "--formatting",
        choices=["none", "light"],
        default="light",
        help=_("cli.option.formatting.help"),
    )
    chain_cmd.add_argument("--split", dest="split", help=_("cli.option.split.help"))
    chain_cmd.add_argument("--split-soft-overflow", dest="split_soft_overflow", type=float, default=0.20)
    chain_cmd.add_argument("--split-hard", dest="split_hard", action="store_true")
    chain_cmd.add_argument("--split-preview", dest="split_preview", action="store_true")
    chain_cmd.add_argument(
        "--tiny-tail-threshold",
        dest="tiny_tail_threshold",
        type=int,
        default=20,
        help=_("cli.option.tiny_tail_threshold.help"),
    )
    chain_cmd.add_argument(
        "--export-outdir",
        dest="export_outdir",
        type=Path,
        help=_("cli.chain.opt.export_outdir.help"),
    )
    chain_cmd.add_argument(
        "--parsed-root",
        dest="parsed_root",
        type=Path,
        help=_("cli.chain.opt.parsed_root.help"),
    )
    chain_cmd.add_argument(
        "--fail-fast",
        dest="fail_fast",
        action="store_true",
        help=_("cli.chain.opt.fail_fast.help"),
    )
    chain_cmd.add_argument(
        "--validate-schema",
        dest="validate_schema",
        action="store_true",
        help=_("cli.chain.opt.validate_schema.help"),
    )

    subparsers.add_parser("viewer", help=_("cli.viewer.help"))

    config_cmd = subparsers.add_parser(
        "config",
        help=_("cli.config.help"),
    )
    config_subparsers = config_cmd.add_subparsers(
        dest="config_command",
        required=True,
    )
    config_subparsers.add_parser("path", help=_("cli.config.path.help"))
    config_subparsers.add_parser("show", help=_("cli.config.show.help"))
    config_subparsers.add_parser("validate", help=_("cli.config.validate.help"))

    return parser
