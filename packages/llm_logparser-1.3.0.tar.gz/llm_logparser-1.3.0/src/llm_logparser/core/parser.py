# src/llm_logparser/core/parser.py
from __future__ import annotations
import json
import importlib
import logging
from pathlib import Path
from typing import Any, Dict, Generator, Optional
from datetime import datetime
from inspect import signature

try:
    import ijson  # type: ignore
except Exception:  # pragma: no cover
    ijson = None

from .l1_derivation import ThreadMetrics, build_thread_stats_artifact
from .i18n import _
from .message_windows import render_message_windows_jsonl

# ============================================================
# 1. Error Classes
# ============================================================

class LLPError(Exception):
    """Base class for parser-related errors."""
    code = "LP2000"
    def __init__(self, msg: str, *, code: str | None = None):
        super().__init__(msg)
        self.code = code or self.code

class LLPInputError(LLPError):
    code = "LP2100"

class LLPAdapterError(LLPError):
    code = "LP2200"

class LLPWriteError(LLPError):
    code = "LP2300"


# ============================================================
# 2. Provider Adapter Loader
# ============================================================

def load_adapter(provider: str):
    """動的に provider adapter をロードする。"""
    mod = importlib.import_module(f"llm_logparser.core.providers.{provider}.adapter")
    get_adapter = getattr(mod, "get_adapter", None)
    if not get_adapter:
        raise LLPAdapterError(f"adapter missing for provider={provider}")
    adapter = get_adapter()
    get_record_expander = getattr(mod, "get_record_expander", None)
    if callable(get_record_expander):
        try:
            setattr(adapter, "__llp_record_expander__", get_record_expander())
        except Exception:
            pass
    manifest = getattr(mod, "get_manifest", lambda: {})()
    policy = getattr(mod, "get_policy", lambda: {})()
    return adapter, manifest, policy


def load_extractor(provider: str):
    """動的に provider extractor をロードする。"""
    mod = importlib.import_module(f"llm_logparser.core.providers.{provider}.extractor")
    get_extractor = getattr(mod, "get_extractor", None)
    if not get_extractor:
        raise LLPAdapterError(f"extractor missing for provider={provider}")
    return get_extractor()


# ============================================================
# 3. JSON Stream Reader (Hybrid)
# ============================================================

def iter_json_records(path: Path, logger: logging.Logger) -> Generator[Dict[str, Any], None, None]:
    """
    巨大JSON/JSONLをストリーム的に読み込む。
    - JSON配列: ijson（あれば）で逐次読み取り
    - JSONオブジェクト: json.load で1件として読み取り
    - JSONL/NDJSON: 行単位で処理
    """
    try:
        with path.open("r", encoding="utf-8-sig") as f:
            first = ""
            while True:
                ch = f.read(1)
                if ch == "":
                    break
                if not ch.isspace():
                    first = ch
                    break
            f.seek(0)

            # JSONL / NDJSON
            if first not in ("[", "{"):
                for i, line in enumerate(f, start=1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        yield json.loads(line)
                    except json.JSONDecodeError as e:
                        logger.warning(
                            _("runtime.parser.skip_invalid_json_line", index=i, detail=e)
                        )
                        continue
                return

            # JSON array
            if first == "[":
                if ijson is not None:
                    for i, item in enumerate(ijson.items(f, "item"), start=1):
                        if not isinstance(item, dict):
                            logger.warning(_("runtime.parser.skip_invalid_element", index=i))
                            continue
                        yield item
                    return
                # fallback: load entire array (smaller files)
                data = json.load(f)
                if not isinstance(data, list):
                    raise LLPInputError("expected JSON array")
                for i, item in enumerate(data, start=1):
                    if not isinstance(item, dict):
                        logger.warning(_("runtime.parser.skip_invalid_element", index=i))
                        continue
                    yield item
                return

            # JSON object
            obj = json.load(f)
            if isinstance(obj, dict):
                yield obj
                return
            raise LLPInputError("expected JSON object at top-level")

    except FileNotFoundError:
        raise LLPInputError(f"input not found: {path}")
    except PermissionError:
        raise LLPInputError(f"permission denied: {path}")
    except Exception as e:
        raise LLPInputError(f"reader error: {e}")


# ============================================================
# 4. Validation / Cache Utilities
# ============================================================

def validate_message(msg: dict, *, fail_fast=False):
    """基本的なスキーマ検証。"""
    required_str = ["conversation_id", "message_id", "role"]
    for k in required_str:
        if not isinstance(msg.get(k), str) or not msg.get(k):
            if fail_fast:
                raise LLPAdapterError(f"missing required field: {k}")
            return False

    parent_id = msg.get("parent_id")
    if parent_id is not None and not isinstance(parent_id, str):
        if fail_fast:
            raise LLPAdapterError("invalid parent_id type")
        return False

    ts = msg.get("ts")
    if not isinstance(ts, int):
        if fail_fast:
            raise LLPAdapterError("missing/invalid ts (expected epoch ms int)")
        return False

    content = msg.get("content")
    if not isinstance(content, dict):
        if fail_fast:
            raise LLPAdapterError("missing/invalid content")
        return False
    if not isinstance(content.get("content_type"), str) or not content.get("content_type"):
        if fail_fast:
            raise LLPAdapterError("missing/invalid content.content_type")
        return False
    parts = content.get("parts")
    if not isinstance(parts, list) or not all(isinstance(p, str) for p in parts):
        if fail_fast:
            raise LLPAdapterError("missing/invalid content.parts (expected list[str])")
        return False

    if not isinstance(msg.get("text"), str):
        if fail_fast:
            raise LLPAdapterError("invalid text type")
        return False

    return True


def load_manifest_if_exists(provider_dir: Path) -> dict:
    """既存manifestをロードしてキャッシュに利用。"""
    man_path = provider_dir / "manifest.json"
    if not man_path.exists():
        return {}
    try:
        return json.loads(man_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def should_skip_thread(conv_id: str, msgs: list, manifest_old: dict) -> bool:
    """update_timeなどで差分スキップを判定。"""
    try:
        index = manifest_old.get("index", {}).get("threads", [])
        old = next((t for t in index if t["conversation_id"] == conv_id), None)
        if not old:
            return False
        old_count = old.get("count")
        new_count = len(msgs)
        if old_count == new_count:
            return True
    except Exception:
        pass
    return False


def write_thread_stats_artifact(
    outdir_thread: Path,
    *,
    provider: str,
    metrics: ThreadMetrics,
) -> None:
    """Persist cheap thread-local stats derived during the parse write loop."""
    artifact_path = outdir_thread / "thread_stats.json"
    tmp = artifact_path.with_suffix(".tmp")
    tmp.write_text(
        json.dumps(
            build_thread_stats_artifact(metrics, provider_id=provider),
            ensure_ascii=True,
            indent=2,
        ),
        encoding="utf-8",
    )
    tmp.replace(artifact_path)


def write_message_windows_artifact(
    outdir_thread: Path,
    *,
    canonical_rows: list[dict[str, Any]],
) -> None:
    """Persist deterministic message windows from canonical message rows."""
    artifact_path = outdir_thread / "message_windows.jsonl"
    tmp = artifact_path.with_suffix(".tmp")
    tmp.write_text(
        render_message_windows_jsonl(canonical_rows),
        encoding="utf-8",
    )
    tmp.replace(artifact_path)


def _invoke_adapter(adapter_func, raw: dict, *, source: str) -> list[dict]:
    """Call provider adapter with optional source context and TypeError fallback."""
    try:
        try:
            params = signature(adapter_func).parameters
        except Exception:
            params = {}
        if "source" in params:
            recs_iter = adapter_func(raw, source=source)
        else:
            recs_iter = adapter_func(raw)
    except TypeError:
        recs_iter = adapter_func(raw)
    return list(recs_iter)


# ============================================================
# 5. Main Parser
# ============================================================

def parse_to_jsonl(
    provider: str,
    input_path: Path,
    outdir: Path,
    *,
    dry_run: bool = False,
    fail_fast: bool = False,
    logger: Optional[logging.Logger] = None,
    progress_interval: int = 100,
    validate_schema: bool = False,
    schema_validator: "MessageSchemaValidator" | None = None,
) -> Dict[str, Any]:
    """
    各プロバイダのエクスポートJSONを解析し、スレッド単位のJSONLファイルを生成する。
    fail_fast=True の場合は一定数エラーで停止。
    """
    log = logger or logging.getLogger("llm_logparser.parser")
    log.info(
        _("runtime.parser.start_parse", provider=provider, dry_run=dry_run, fail_fast=fail_fast)
    )

    adapter_func, manifest, policy = load_adapter(provider)
    provider_dir = outdir / provider
    provider_dir.mkdir(parents=True, exist_ok=True)
    manifest_old = load_manifest_if_exists(provider_dir)

    if validate_schema and schema_validator is None:
        from .schema_validation import MessageSchemaValidator

        schema_validator = MessageSchemaValidator()
    message_validation_error_cls = None
    if schema_validator:
        from .schema_validation import MessageValidationError

        message_validation_error_cls = MessageValidationError

    errors, skipped, count = 0, 0, 0
    sample_errors: list[str] = []
    stats = {"threads": 0, "messages": 0}
    manifest_index = []
    record_expander = getattr(adapter_func, "__llp_record_expander__", None)
    if not callable(record_expander):
        record_expander = lambda raw: [raw]

    for raw in iter_json_records(input_path, log):
        try:
            expanded_records = list(record_expander(raw))
        except Exception as e:
            msg = _("runtime.parser.adapter_error", detail=e)
            log.warning(msg)
            errors += 1
            if len(sample_errors) < 5:
                sample_errors.append(msg)
            if fail_fast and errors > 3:
                raise LLPAdapterError(f"too many adapter errors ({errors})")
            continue

        for expanded_raw in expanded_records:
            try:
                recs = _invoke_adapter(
                    adapter_func,
                    expanded_raw,
                    source=str(input_path),
                )
                if not recs:
                    continue

                cid = recs[0].get("conversation_id")
                if not cid:
                    skipped += len(recs)
                    continue

                count += len(recs)
                if count % progress_interval == 0:
                    log.info(_("runtime.parser.processed_messages", count=count))

                recs.sort(key=lambda r: (r.get("ts") is None, r.get("ts"), r.get("message_id") or ""))

                if should_skip_thread(cid, recs, manifest_old):
                    skipped += 1
                    log.info(_("runtime.parser.skip_thread_unchanged", conversation_id=cid))
                    continue

                ts_values = [m.get("ts") for m in recs if isinstance(m.get("ts"), (int, float))]
                ts_min = min(ts_values) if ts_values else None
                ts_max = max(ts_values) if ts_values else None

                outdir_thread = provider_dir / f"thread-{cid}"
                outdir_thread.mkdir(parents=True, exist_ok=True)
                outpath = outdir_thread / "parsed.jsonl"

                if not dry_run:
                    tmp = outpath.with_suffix(".tmp")
                    thread_metrics = ThreadMetrics(conversation_id=cid)
                    canonical_rows: list[dict[str, Any]] = []
                    try:
                        with tmp.open("w", encoding="utf-8") as f:
                            thread_meta = {
                                "record_type": "thread",
                                "provider_id": provider,
                                "conversation_id": cid,
                                "message_count": len(recs),
                            }
                            f.write(json.dumps(thread_meta, ensure_ascii=True) + "\n")
                            for m in recs:
                                if schema_validator:
                                    try:
                                        schema_validator.validate_message(m)
                                    except message_validation_error_cls as verr:
                                        idx = m.get("message_id") or "<unknown>"
                                        log.warning(
                                            _(
                                                "runtime.parser.schema_validation_failed",
                                                conversation_id=cid,
                                                message_id=idx,
                                                detail=verr,
                                            )
                                        )
                                        skipped += 1
                                        if fail_fast:
                                            raise LLPAdapterError(
                                                "message schema validation failed"
                                            ) from verr
                                        continue

                                if not validate_message(m, fail_fast=fail_fast):
                                    skipped += 1
                                    continue
                                canonical_row = {
                                    "record_type": "message",
                                    "provider_id": provider,
                                    **m,
                                }
                                # Keep derived artifacts tied to the exact canonical rows we write.
                                canonical_rows.append(canonical_row)
                                thread_metrics.add_message(canonical_row)
                                f.write(
                                    json.dumps(
                                        canonical_row,
                                        ensure_ascii=True,
                                    )
                                    + "\n"
                                )
                        write_thread_stats_artifact(
                            outdir_thread,
                            provider=provider,
                            metrics=thread_metrics,
                        )
                        write_message_windows_artifact(
                            outdir_thread,
                            canonical_rows=canonical_rows,
                        )
                    except Exception as e:
                        raise LLPWriteError(f"write error: {e}")
                    tmp.replace(outpath)

                stats["threads"] += 1
                stats["messages"] += len(recs)

                manifest_index.append(
                    {
                        "conversation_id": cid,
                        "path": f"thread-{cid}/parsed.jsonl",
                        "count": len(recs),
                        "ts_min": ts_min,
                        "ts_max": ts_max,
                    }
                )
            except Exception as e:
                msg = _("runtime.parser.adapter_error", detail=e)
                log.warning(msg)
                errors += 1
                if len(sample_errors) < 5:
                    sample_errors.append(msg)
                if fail_fast and errors > 3:
                    raise LLPAdapterError(f"too many adapter errors ({errors})")

    # manifest出力
    if not dry_run:
        manifest_path = provider_dir / "manifest.json"
        manifest_obj = {
            "schema_version": "1.3",
            "provider": provider,
            "policy": policy,
            "exported_at": datetime.utcnow().isoformat(),
            "index": {"threads": manifest_index},
        }
        manifest_path.write_text(json.dumps(manifest_obj, ensure_ascii=True, indent=2), encoding="utf-8")
        log.info(_("runtime.parser.manifest_saved", path=manifest_path))

    log.info(
        _(
            "runtime.parser.summary",
            threads=stats["threads"],
            messages=stats["messages"],
            errors=errors,
            skipped=skipped,
        )
    )
    return {**stats, "errors": errors, "skipped": skipped, "samples": sample_errors}


def extract_to_json(
    provider: str,
    input_path: Path,
    outdir: Path,
    conversation_id: str,
    *,
    dry_run: bool = False,
    sanitize_policy: Any | None = None,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """指定 conversation_id の生会話を抽出し、Gemini-compat JSON を出力する。"""
    log = logger or logging.getLogger("llm_logparser.parser")
    log.info(
        _(
            "runtime.parser.start_extract",
            provider=provider,
            conversation_id=conversation_id,
            dry_run=dry_run,
        )
    )
    extractor = load_extractor(provider)
    extractor_kwargs: dict[str, Any] = {
        "input_path": input_path,
        "outdir": outdir,
        "provider": provider,
        "conversation_id": conversation_id,
        "dry_run": dry_run,
        "logger": log,
    }
    if "sanitize_policy" in signature(extractor).parameters:
        extractor_kwargs["sanitize_policy"] = sanitize_policy
    elif sanitize_policy is not None:
        log.debug(
            "Extractor for provider=%s does not accept sanitize_policy; using extractor defaults",
            provider,
        )
    result = extractor(**extractor_kwargs)
    if not isinstance(result, dict):
        raise LLPAdapterError("extractor returned invalid result")
    return result


# ============================================================
# 6. CLI Entry (Debug Only)
# ============================================================

if __name__ == "__main__":
    import argparse
    from ..cli.cli import setup_logger

    setup_logger()

    parser = argparse.ArgumentParser(description="Parse LLM export logs to JSONL (final robust version)")
    parser.add_argument("--provider", required=True)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--outdir", type=Path, default=Path("artifacts/output"))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--fail-fast", action="store_true")
    parser.add_argument("--progress-interval", type=int, default=100)

    args = parser.parse_args()

    parse_to_jsonl(
        args.provider,
        args.input,
        args.outdir,
        dry_run=args.dry_run,
        fail_fast=args.fail_fast,
        progress_interval=args.progress_interval,
    )
