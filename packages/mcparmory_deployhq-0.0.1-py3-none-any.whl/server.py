"""MCP server for DeployHQ — placeholder, full version coming soon."""

def main() -> None:
    print("mcparmory-deployhq: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
