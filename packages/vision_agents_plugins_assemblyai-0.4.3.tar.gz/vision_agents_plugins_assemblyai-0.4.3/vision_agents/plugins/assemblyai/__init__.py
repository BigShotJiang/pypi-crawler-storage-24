from .stt import STT

__path__ = __import__("pkgutil").extend_path(__path__, __name__)

__all__ = ["STT"]
