"""Data hive storage client package."""

from importlib import metadata
from pathlib import Path

from .client import DataHiveClient, RunHandle, StorageModePolicy
from .manifest import ArtifactEntry, RunManifest, RunSummary, TableEntry
from .policy import Policy

_PACKAGE_ROOT = Path(__file__).resolve().parent
__version__ = "0.1.7"


def _locate_distribution_file(*relative_candidates: str) -> Path:
    distribution = metadata.distribution("cf-datahive")
    files = distribution.files or []
    for candidate in relative_candidates:
        for entry in files:
            if entry.as_posix() == candidate:
                return Path(distribution.locate_file(entry)).resolve()
    raise FileNotFoundError(
        f"Could not locate any of {relative_candidates!r} in cf-datahive distribution files."
    )


def _native_root() -> Path:
    try:
        return _locate_distribution_file("cf_datahive/native/cmake/cf_datahive_consumer.cmake").parents[1]
    except Exception:
        return _PACKAGE_ROOT / "native"


def cf_datahive_cpp_source_path() -> str:
    """Return the package-owned native cf_datahive_cpp source root."""
    return str(_PACKAGE_ROOT / "cpp")


def cf_datahive_cpp_include_path() -> str:
    """Return the packaged native cf_datahive_cpp include root."""
    return str(_native_root() / "include")


def cf_datahive_cpp_library_path() -> str:
    """Return the packaged cf_datahive_cpp runtime library path."""
    native_root = _native_root()
    candidates = [
        native_root / "bin" / "cf_datahive_cpp.dll",
        native_root / "lib" / "libcf_datahive_cpp.so",
        native_root / "lib" / "libcf_datahive_cpp.dylib",
        native_root / "lib" / "cf_datahive_cpp.dll",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    raise FileNotFoundError("Packaged cf_datahive_cpp runtime library not found.")


def cf_datahive_cpp_import_library_path() -> str:
    """Return the packaged cf_datahive_cpp import/static library path for native consumers."""
    native_root = _native_root()
    candidates = [
        native_root / "lib" / "cf_datahive_cpp.lib",
        native_root / "lib" / "libcf_datahive_cpp.dll.a",
        native_root / "lib" / "libcf_datahive_cpp.a",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    runtime_library = Path(cf_datahive_cpp_library_path())
    if runtime_library.suffix not in {".dll"}:
        return str(runtime_library)
    raise FileNotFoundError("Packaged cf_datahive_cpp import library not found.")


def cf_datahive_cpp_runtime_dir() -> str:
    """Return the packaged runtime directory for cf_datahive native binaries."""
    native_root = _native_root()
    for candidate in (native_root / "bin", native_root / "lib"):
        if candidate.is_dir():
            return str(candidate)
    return str(native_root)


def cf_datahive_cpp_consumer_cmake_path() -> str:
    """Return the owner-provided CMake helper used by first-party native consumers."""
    return str(_native_root() / "cmake" / "cf_datahive_consumer.cmake")

__all__ = [
    "__version__",
    "ArtifactEntry",
    "DataHiveClient",
    "Policy",
    "RunHandle",
    "StorageModePolicy",
    "RunManifest",
    "RunSummary",
    "TableEntry",
    "cf_datahive_cpp_consumer_cmake_path",
    "cf_datahive_cpp_include_path",
    "cf_datahive_cpp_import_library_path",
    "cf_datahive_cpp_library_path",
    "cf_datahive_cpp_runtime_dir",
    "cf_datahive_cpp_source_path",
]
