#ifndef CF_DATAHIVE_CPP_CF_DATAHIVE_CPP_H
#define CF_DATAHIVE_CPP_CF_DATAHIVE_CPP_H

#include <string>

#if defined(_WIN32)
#  if defined(CF_DATAHIVE_CPP_EXPORTS)
#    define CF_DATAHIVE_CPP_API __declspec(dllexport)
#  elif defined(CF_DATAHIVE_CPP_STATIC)
#    define CF_DATAHIVE_CPP_API
#  else
#    define CF_DATAHIVE_CPP_API __declspec(dllimport)
#  endif
#else
#  define CF_DATAHIVE_CPP_API
#endif

namespace cf_datahive_cpp {

struct SinkConfig {
  std::string workspace_root;
  std::string pipeline_id;
  std::string pipeline_label;
  int cycle_count = 20;
};

struct SinkResult {
  bool ok = false;
  std::string run_id;
  std::string session_id;
  int session_run_index = 0;
  std::string status;
  std::string error;
};

CF_DATAHIVE_CPP_API SinkResult write_demo_measurements_run(const SinkConfig& config, const std::string& payload);

}  // namespace cf_datahive_cpp

#endif  // CF_DATAHIVE_CPP_CF_DATAHIVE_CPP_H
