include_guard(GLOBAL)

include(CMakeParseArguments)

function(cf_datahive_import_cpp_target)
  set(options)
  set(oneValueArgs TARGET INCLUDE_DIR LIBRARY_PATH IMPORT_LIBRARY_PATH)
  cmake_parse_arguments(CFDH "${options}" "${oneValueArgs}" "" ${ARGN})

  if (CFDH_UNPARSED_ARGUMENTS)
    message(FATAL_ERROR "cf_datahive_import_cpp_target received unexpected arguments: ${CFDH_UNPARSED_ARGUMENTS}")
  endif()
  if (NOT CFDH_TARGET)
    message(FATAL_ERROR "cf_datahive_import_cpp_target requires TARGET <target>.")
  endif()
  if (TARGET ${CFDH_TARGET})
    return()
  endif()
  if (NOT CFDH_INCLUDE_DIR OR NOT EXISTS "${CFDH_INCLUDE_DIR}/cf_datahive_cpp/cf_datahive_cpp.h")
    message(FATAL_ERROR "cf_datahive_import_cpp_target requires a valid INCLUDE_DIR containing cf_datahive_cpp headers.")
  endif()

  set(_import_library_path "${CFDH_IMPORT_LIBRARY_PATH}")
  set(_runtime_library_path "${CFDH_LIBRARY_PATH}")

  if (WIN32 AND NOT _import_library_path STREQUAL "")
    add_library(${CFDH_TARGET} SHARED IMPORTED GLOBAL)
    set_target_properties(${CFDH_TARGET} PROPERTIES
      IMPORTED_IMPLIB "${_import_library_path}"
      IMPORTED_LOCATION "${_runtime_library_path}"
      INTERFACE_INCLUDE_DIRECTORIES "${CFDH_INCLUDE_DIR}"
    )
  else()
    if (_import_library_path STREQUAL "")
      set(_import_library_path "${_runtime_library_path}")
    endif()
    add_library(${CFDH_TARGET} UNKNOWN IMPORTED GLOBAL)
    set_target_properties(${CFDH_TARGET} PROPERTIES
      IMPORTED_LOCATION "${_import_library_path}"
      INTERFACE_INCLUDE_DIRECTORIES "${CFDH_INCLUDE_DIR}"
    )
  endif()
endfunction()

function(cf_datahive_stage_consumer_runtime)
  set(options)
  set(oneValueArgs TARGET RUNTIME_DIR)
  set(multiValueArgs DESTINATIONS)
  cmake_parse_arguments(CFDH "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

  if (CFDH_UNPARSED_ARGUMENTS)
    message(FATAL_ERROR "cf_datahive_stage_consumer_runtime received unexpected arguments: ${CFDH_UNPARSED_ARGUMENTS}")
  endif()
  if (NOT CFDH_TARGET)
    message(FATAL_ERROR "cf_datahive_stage_consumer_runtime requires TARGET <target>.")
  endif()
  if (NOT TARGET ${CFDH_TARGET})
    message(FATAL_ERROR "cf_datahive_stage_consumer_runtime target '${CFDH_TARGET}' is not defined.")
  endif()

  set(_cfdh_destinations)
  foreach(_destination IN LISTS CFDH_DESTINATIONS)
    if (NOT _destination STREQUAL "")
      list(APPEND _cfdh_destinations "${_destination}")
    endif()
  endforeach()
  if (NOT _cfdh_destinations)
    return()
  endif()

  if (NOT CFDH_RUNTIME_DIR STREQUAL "" AND EXISTS "${CFDH_RUNTIME_DIR}")
    file(GLOB _cfdh_runtime_files "${CFDH_RUNTIME_DIR}/*.dll" "${CFDH_RUNTIME_DIR}/*.so" "${CFDH_RUNTIME_DIR}/*.dylib")
    foreach(_runtime_file IN LISTS _cfdh_runtime_files)
      foreach(_destination IN LISTS _cfdh_destinations)
        add_custom_command(TARGET ${CFDH_TARGET} POST_BUILD
          COMMAND ${CMAKE_COMMAND} -E make_directory "${_destination}"
          COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_runtime_file}" "${_destination}"
          VERBATIM
        )
      endforeach()
    endforeach()
  endif()

  if (WIN32 AND CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
    get_filename_component(_gnu_runtime_dir "${CMAKE_CXX_COMPILER}" DIRECTORY)
    set(_gnu_runtime_dlls
      "${_gnu_runtime_dir}/libgcc_s_seh-1.dll"
      "${_gnu_runtime_dir}/libstdc++-6.dll"
      "${_gnu_runtime_dir}/libwinpthread-1.dll"
    )

    foreach(_gnu_runtime_dll IN LISTS _gnu_runtime_dlls)
      if (EXISTS "${_gnu_runtime_dll}")
        foreach(_destination IN LISTS _cfdh_destinations)
          add_custom_command(TARGET ${CFDH_TARGET} POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E make_directory "${_destination}"
            COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_gnu_runtime_dll}" "${_destination}"
            VERBATIM
          )
        endforeach()
      endif()
    endforeach()
  endif()
endfunction()
