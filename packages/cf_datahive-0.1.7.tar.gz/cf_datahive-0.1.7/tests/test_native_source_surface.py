from __future__ import annotations

from pathlib import Path

from cf_datahive import (
    cf_datahive_cpp_consumer_cmake_path,
    cf_datahive_cpp_include_path,
    cf_datahive_cpp_import_library_path,
    cf_datahive_cpp_library_path,
    cf_datahive_cpp_runtime_dir,
)


def test_native_consumer_surface_is_packaged_under_owner_package() -> None:
    include_root = Path(cf_datahive_cpp_include_path())
    runtime_library = Path(cf_datahive_cpp_library_path())
    import_library = Path(cf_datahive_cpp_import_library_path())
    runtime_dir = Path(cf_datahive_cpp_runtime_dir())
    consumer_cmake = Path(cf_datahive_cpp_consumer_cmake_path())

    assert include_root.is_dir()
    assert (include_root / "cf_datahive_cpp" / "cf_datahive_cpp.h").is_file()
    assert runtime_library.is_file()
    assert import_library.is_file()
    assert runtime_dir.is_dir()
    assert consumer_cmake.is_file()
    assert consumer_cmake.parent.name == "cmake"
