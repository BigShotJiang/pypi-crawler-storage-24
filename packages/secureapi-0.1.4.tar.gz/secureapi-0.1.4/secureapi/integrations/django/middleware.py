"""Django middleware integration."""
