"""General helper utilities."""
