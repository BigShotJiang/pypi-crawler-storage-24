# SecureAPI

SecureAPI is a framework-agnostic authorization layer for Python APIs.
It helps developers prevent common API vulnerabilities like ID tampering, broken access control, and role misuse without writing repetitive security logic.

---

# Features

* Role-Based Access Control (RBAC)
* Multi-Tenant Support
* ID Tampering Protection (BOLA prevention)
* Centralized Authorization Logic
* Works with:

  * Django / DRF
  * FastAPI
  * Flask
* Config-driven security (YAML / DB-ready)
* Plug-and-play integration

---

# Installation

```bash
pip install secureapi
```

---

# Quick Start (Concept)

Instead of writing this everywhere:

```python
if request.user.id != form.created_by_id:
    return Response("Unauthorized", status=403)
```

Use SecureAPI:

```python
@secure_endpoint(resource="form", action="read")
def get_form(request, form_id):
    ...
```

---

# Configuration

Create a file:

## secureapi.yaml

```yaml
form:
  read: ["owner", "collaborator"]
  update: ["owner"]
  delete: ["owner"]

project:
  read: ["member", "admin"]
  update: ["admin"]
```

---

# Core Concepts

## 1. Resource

A model/entity like:

* form
* project
* user

## 2. Action

| HTTP Method | Action |
| ----------- | ------ |
| GET         | read   |
| POST        | create |
| PUT/PATCH   | update |
| DELETE      | delete |

---

## 3. Role

Defined by your system:

* owner
* admin
* member
* collaborator

---

# Integration Guide

---

# Django (DRF)

## Step 1: Add Permission

```python
from secureapi.integrations.django.permission import SecurePermission

class FormViewSet(ModelViewSet):
    queryset = Form.objects.all()
    permission_classes = [SecurePermission]
```

---

## Step 2: Ensure Model Fields

Your model should have:

```python
class Form(models.Model):
    created_by = models.ForeignKey(User, ...)
    tenant_id = models.IntegerField()
```

---

## Step 3: Provide Custom Resolvers

```python
# secureapi_config.py

def role_resolver(user, tenant_id):
    return user.role  # or DB lookup


def resource_resolver(resource, resource_id):
    from myapp.models import Form

    if resource == "form":
        return Form.objects.get(id=resource_id)
```

---

# FastAPI

## Step 1: Add Dependency

```python
from fastapi import Depends
from secureapi.integrations.fastapi.dependency import secure_dependency

@app.get("/forms/{form_id}")
def get_form(
    form_id: int,
    dep=Depends(secure_dependency("form", "read"))
):
    return {"message": "Authorized"}
```

---

# Flask

## Step 1: Use Decorator

```python
from secureapi.integrations.flask.decorator import secure_endpoint

@app.route("/forms/<int:form_id>")
@secure_endpoint(resource="form", action="read")
def get_form(form_id):
    return {"message": "Authorized"}
```

---

# Multi-Tenant Support

SecureAPI supports tenant-based isolation.

Pass tenant via header:

```http
X-Tenant-ID: 10
```

---

Example Logic:

* User belongs to tenant 10
* Form belongs to tenant 20

Access is denied.

---

# Security Features

## ID Tampering Protection

Prevents:

```http
GET /api/forms/1 → change to /api/forms/2
```

Automatically validates:

* Ownership
* Tenant isolation
* Role permissions

---

## Ownership Validation

* Ensures resource belongs to user
* Prevents unauthorized access

---

## Role Enforcement

* Only allowed roles can perform actions

---

# Advanced Configuration

## Custom Role Resolver

```python
def role_resolver(user, tenant_id):
    return TenantUser.objects.get(
        user=user,
        tenant_id=tenant_id
    ).role
```

---

## Custom Resource Mapping

```python
RESOURCE_MAP = {
    "form": Form,
    "project": Project
}
```

---

# Example Flow

Request:

```http
GET /forms/45
Authorization: Bearer token
X-Tenant-ID: 10
```

SecureAPI will:

1. Extract user
2. Resolve role
3. Load policy
4. Fetch object
5. Validate:

   * tenant match
   * ownership
   * role

Allow or deny access accordingly.

---

# Best Practices

* Always define tenant_id in models
* Use consistent role naming
* Keep policy config simple
* Avoid exposing raw IDs publicly (optional enhancement)

---

# Roadmap

* Admin UI for policy management
* Audit logs dashboard
* AI-based attack detection
* Token binding and replay protection

---

# Contributing

Contributions are welcome.

```bash
git clone https://github.com/yourusername/secureapi
cd secureapi
pip install -e .
```

---

# License

MIT License © 2026 Vaibhav Patil

---

# Support

If you find this useful:

* Star the repository
* Report issues
* Suggest features

---

# Final Note

SecureAPI is designed to solve one of the most critical problems in modern APIs:

Broken Authorization Logic

Build secure APIs without repeating security code.
