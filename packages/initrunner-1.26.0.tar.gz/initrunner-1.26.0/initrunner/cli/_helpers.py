"""Shared CLI helpers: error handling, role loading, and context management."""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

import typer
from rich.console import Console
from rich.markup import escape

if TYPE_CHECKING:
    from pydantic_ai import Agent

    from initrunner.agent.schema.role import RoleDefinition
    from initrunner.audit.logger import AuditLogger
    from initrunner.services.role_selector import SelectionResult

console = Console()


def display_sense_result(result: SelectionResult) -> None:
    """Render the intent-sensed role in a Rich panel."""
    from rich.panel import Panel
    from rich.table import Table

    c = result.candidate

    # Relative path if possible
    try:
        display_path = str(c.path.relative_to(Path.cwd()))
    except ValueError:
        display_path = str(c.path)

    # Method label
    method = result.method
    if method == "only_one":
        method_str = "[dim]only role available[/dim]"
    elif method == "keyword":
        method_str = (
            f"[green]keyword match[/green] (score: {result.top_score:.2f}, gap: {result.gap:.2f})"
        )
    elif method == "llm":
        method_str = "[yellow]LLM selection[/yellow]"
    else:
        method_str = "[yellow]fallback — no strong match[/yellow]"

    tags_str = ", ".join(c.tags) if c.tags else "[dim]none[/dim]"

    table = Table.grid(padding=(0, 1))
    table.add_column(style="dim", no_wrap=True)
    table.add_column()
    table.add_row("Name", f"[cyan]{escape(c.name)}[/cyan]")
    table.add_row("File", escape(display_path))
    table.add_row("Tags", tags_str)
    table.add_row("Method", method_str)
    if c.reason:
        table.add_row("Reason", escape(c.reason))

    console.print(Panel(table, title="[bold]Intent Sensing[/bold]", border_style="dim"))


def install_extra(extra: str) -> bool:
    """Best-effort install of an initrunner extra. Returns True on success."""
    import shutil
    import subprocess
    import sys

    pkg = f"initrunner[{extra}]"
    pkg_display = escape(pkg)

    exe = sys.executable.replace("\\", "/")
    if "/uv/tools/" in exe and shutil.which("uv"):
        cmd = ["uv", "tool", "install", "--force", pkg]
    elif "/pipx/venvs/" in exe:
        if shutil.which("pipx"):
            cmd = ["pipx", "install", "--force", pkg]
        else:
            cmd = [sys.executable, "-m", "pip", "install", pkg]
    elif shutil.which("uv"):
        cmd = ["uv", "pip", "install", pkg]
    else:
        cmd = [sys.executable, "-m", "pip", "install", pkg]

    try:
        with console.status(f"Installing {pkg_display}..."):
            subprocess.run(cmd, check=True, capture_output=True, text=True)
        console.print(f"[green]Installed {pkg_display}[/green]")
        return True
    except (subprocess.CalledProcessError, OSError) as exc:
        console.print(
            f"[yellow]Warning:[/yellow] Could not install {pkg_display}: {escape(str(exc))}\n"
            f"Install manually: [bold]{escape(' '.join(cmd))}[/bold]"
        )
        return False


def prompt_model_selection(
    provider: str,
    ollama_models: list[str] | None = None,
) -> str:
    """Show model choices for a provider and return selected model name."""
    from rich.prompt import Prompt

    from initrunner.templates import PROVIDER_MODELS, _default_model_name

    if provider == "ollama" and ollama_models:
        choices = [(m, "(local)") for m in ollama_models]
    else:
        choices = PROVIDER_MODELS.get(provider, [])

    default = choices[0][0] if choices else _default_model_name(provider)

    console.print()
    console.print("[bold]Select a model:[/bold]")
    for i, (model_id, desc) in enumerate(choices, 1):
        default_tag = " (default)" if model_id == default else ""
        desc_part = f" — {desc}" if desc else ""
        console.print(f"  {i}. {model_id}{desc_part}{default_tag}")
    console.print("  Or type a custom model name (press Enter for default)")

    raw = Prompt.ask("Model", default=default)

    if raw.strip().isdigit():
        idx = int(raw.strip()) - 1
        if 0 <= idx < len(choices):
            return choices[idx][0]

    return raw.strip() or default


def check_ollama_running() -> None:
    """Ping local Ollama and warn if it's not reachable."""
    from initrunner.services.providers import is_ollama_running

    if not is_ollama_running():
        console.print(
            "[yellow]Warning:[/yellow] Ollama does not appear to be running. "
            "Make sure to run: [bold]ollama serve[/bold]"
        )


def detect_yaml_kind(path: Path) -> str:
    """Peek at a YAML file's ``kind`` field without full validation.

    Returns the kind string (e.g. ``"Agent"``, ``"Team"``, ``"Compose"``).
    Defaults to ``"Agent"`` on any failure.
    """
    import yaml

    try:
        with open(path) as f:
            data = yaml.safe_load(f)
        if isinstance(data, dict):
            return data.get("kind", "Agent")
    except Exception:
        pass
    return "Agent"


def load_role_or_exit(role_file: Path) -> RoleDefinition:
    from initrunner.agent.loader import RoleLoadError
    from initrunner.services.discovery import load_role_sync

    try:
        return load_role_sync(role_file)
    except RoleLoadError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


def resolve_skill_dirs(skill_dir: Path | None) -> list[Path] | None:
    dirs: list[Path] = []
    if skill_dir is not None:
        dirs.append(skill_dir)
    env_val = os.environ.get("INITRUNNER_SKILL_DIR")
    if env_val:
        dirs.append(Path(env_val))
    return dirs if dirs else None


def load_and_build_or_exit(
    role_file: Path,
    extra_skill_dirs: list[Path] | None = None,
    model_override: str | None = None,
) -> tuple[RoleDefinition, Agent]:
    from initrunner.agent.loader import RoleLoadError, load_and_build

    try:
        role, agent = load_and_build(
            role_file,
            extra_skill_dirs=extra_skill_dirs,
            model_override=model_override,
        )
        return role, agent
    except RoleLoadError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


def resolve_model_override(model_flag: str | None) -> str | None:
    """Resolve a ``--model`` CLI flag value to ``provider:model``.

    Returns ``None`` when *model_flag* is ``None``.  Resolves aliases and
    validates the result contains a colon.  Exits with error on failure.
    """
    if model_flag is None:
        return None

    from initrunner.model_aliases import parse_model_string, resolve_model_alias

    resolved = resolve_model_alias(model_flag)
    try:
        parse_model_string(resolved)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None
    return resolved


def _apply_model_override(role: RoleDefinition, model_string: str) -> RoleDefinition:
    """Return a copy of *role* with its model config replaced by *model_string*.

    Preserves temperature and max_tokens.  Clears ``base_url`` and
    ``api_key_env`` only when the provider changes.
    """
    from initrunner.model_aliases import parse_model_string

    new_provider, new_name = parse_model_string(model_string)
    old_model = role.spec.model

    update: dict = {"provider": new_provider, "name": new_name}
    if new_provider != old_model.provider:
        update["base_url"] = None
        update["api_key_env"] = None

    new_model = old_model.model_copy(update=update)
    new_spec = role.spec.model_copy(update={"model": new_model})
    return role.model_copy(update={"spec": new_spec})


def create_audit_logger(audit_db: Path | None, no_audit: bool) -> AuditLogger | None:
    if no_audit:
        return None
    from initrunner.audit.logger import DEFAULT_DB_PATH
    from initrunner.audit.logger import AuditLogger as _AuditLogger

    return _AuditLogger(audit_db or DEFAULT_DB_PATH)


def _no_memory_role(role: RoleDefinition) -> RoleDefinition:
    """Return a shallow copy of *role* with memory disabled.

    Used to skip memory store creation when ``with_memory=False``.
    """
    return role.model_copy(update={"spec": role.spec.model_copy(update={"memory": None})})


def resolve_memory_path(role: RoleDefinition) -> Path:
    from initrunner.stores.base import resolve_memory_path as _resolve

    mem = role.spec.memory
    return _resolve(mem.store_path if mem else None, role.metadata.name)


@contextmanager
def ephemeral_context(
    role: RoleDefinition,
    agent: Agent,
    *,
    audit_db: Path | None = None,
    no_audit: bool = False,
    with_memory: bool = False,
):
    """Context manager for ephemeral (in-memory) roles.

    Like command_context() but accepts pre-built RoleDefinition + Agent.
    Skips sinks and observability.
    """
    from initrunner.stores.factory import managed_memory_store

    audit_logger = create_audit_logger(audit_db, no_audit)

    mem_role = role if with_memory else _no_memory_role(role)
    with managed_memory_store(mem_role, agent) as memory_store:
        try:
            yield role, agent, audit_logger, memory_store
        finally:
            if audit_logger is not None:
                audit_logger.close()


@contextmanager
def command_context(
    role_file: Path,
    *,
    audit_db: Path | None,
    no_audit: bool,
    with_memory: bool = False,
    with_sinks: bool = False,
    extra_skill_dirs: list[Path] | None = None,
    model_override: str | None = None,
):
    """Context manager for agent setup and resource cleanup.

    Yields (role, agent, audit_logger, memory_store, sink_dispatcher).
    """
    from initrunner.stores.factory import managed_memory_store

    role, agent = load_and_build_or_exit(
        role_file, extra_skill_dirs=extra_skill_dirs, model_override=model_override
    )

    # Setup observability after load so TracerProvider is active before
    # the first agent.run_sync() call (PydanticAI resolves it lazily).
    _otel_provider = None
    if role.spec.observability is not None:
        from initrunner.observability import setup_tracing

        _otel_provider = setup_tracing(role.spec.observability, role.metadata.name)
    audit_logger = create_audit_logger(audit_db, no_audit)

    mem_role = role if with_memory else _no_memory_role(role)
    with managed_memory_store(mem_role, agent) as memory_store:
        sink_dispatcher = None
        if with_sinks and role.spec.sinks:
            from initrunner.sinks.dispatcher import SinkDispatcher

            sink_dispatcher = SinkDispatcher(role.spec.sinks, role, role_dir=role_file.parent)

        try:
            yield role, agent, audit_logger, memory_store, sink_dispatcher
        finally:
            if audit_logger is not None:
                audit_logger.close()
            if _otel_provider is not None:
                from initrunner.observability import shutdown_tracing

                shutdown_tracing()
