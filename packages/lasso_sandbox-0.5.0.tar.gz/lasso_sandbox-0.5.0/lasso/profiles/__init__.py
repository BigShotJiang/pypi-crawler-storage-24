"""Bundled community profiles for LASSO.

These TOML files are installed via 'lasso profile install <name>'.
"""
