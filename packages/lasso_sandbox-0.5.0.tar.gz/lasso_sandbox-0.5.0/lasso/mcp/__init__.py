"""LASSO MCP (Model Context Protocol) server.

Exposes LASSO sandbox operations as MCP tools over stdin/stdout JSON-RPC
transport. Agents connect via MCP and all tool calls are routed through
LASSO's sandboxed execution environment with command gating and audit
logging.

Protocol: JSON-RPC 2.0 over stdin/stdout (newline-delimited JSON).
"""

from lasso.mcp.server import MCPServer

__all__ = ["MCPServer"]
