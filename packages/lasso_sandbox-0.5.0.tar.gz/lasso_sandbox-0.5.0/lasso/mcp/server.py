"""MCP server — JSON-RPC 2.0 over stdin/stdout.

Implements the Model Context Protocol lifecycle:
  initialize -> notifications/initialized -> tools/list -> tools/call

All tool executions are routed through LASSO sandboxes with command gating,
filesystem isolation, and audit logging.  Security policy (MCPSecurityConfig)
is enforced before every tool call: server allow/block lists, shell execution
gating, rate limiting, and audit logging.
"""

from __future__ import annotations

import json
import logging
import shlex
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional, TextIO

from lasso.config.defaults import BUILTIN_PROFILES
from lasso.config.schema import MCPSecurityConfig, ProfileMode, SandboxProfile
from lasso.core.audit import AuditLogger
from lasso.core.sandbox import SandboxExecResult, Sandbox, SandboxRegistry

logger = logging.getLogger("lasso.mcp")

# ---------------------------------------------------------------------------
# MCP protocol constants
# ---------------------------------------------------------------------------

MCP_PROTOCOL_VERSION = "2024-11-05"

SERVER_INFO = {
    "name": "lasso",
    "version": "0.1.0",
}

SERVER_CAPABILITIES = {
    "tools": {"listChanged": False},
}

# ---------------------------------------------------------------------------
# Tool definitions (MCP schema)
# ---------------------------------------------------------------------------

TOOLS = [
    {
        "name": "sandbox_exec",
        "description": (
            "Execute a command inside a LASSO sandbox. The command is validated "
            "against the sandbox's command gate (whitelist/blacklist) before "
            "execution. Returns stdout, stderr, and exit code."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The command to execute (e.g. 'ls -la', 'python3 script.py').",
                },
                "profile": {
                    "type": "string",
                    "description": "Profile name to use. Defaults to session profile.",
                },
                "sandbox_id": {
                    "type": "string",
                    "description": "Target sandbox ID. If omitted, uses the default session sandbox.",
                },
            },
            "required": ["command"],
        },
    },
    {
        "name": "sandbox_create",
        "description": (
            "Create a new sandboxed execution environment from a named profile. "
            "The sandbox is started immediately and ready for command execution."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "profile": {
                    "type": "string",
                    "description": "Profile name: minimal, development, or data-analysis.",
                },
                "working_dir": {
                    "type": "string",
                    "description": "Absolute path to the working directory to mount.",
                },
            },
            "required": ["profile", "working_dir"],
        },
    },
    {
        "name": "sandbox_stop",
        "description": "Stop a running sandbox and release its resources.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "sandbox_id": {
                    "type": "string",
                    "description": "ID of the sandbox to stop.",
                },
            },
            "required": ["sandbox_id"],
        },
    },
    {
        "name": "sandbox_status",
        "description": (
            "Get detailed status of a sandbox including state, exec counts, "
            "backend info, and audit log path."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "sandbox_id": {
                    "type": "string",
                    "description": "ID of the sandbox to inspect.",
                },
            },
            "required": ["sandbox_id"],
        },
    },
    {
        "name": "sandbox_list",
        "description": "List all sandboxes managed by this LASSO session with their status.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "sandbox_set_mode",
        "description": (
            "Change the profile mode of a sandbox. Controls the level of "
            "command access: observe (read-only), assist (curated dev tools), "
            "or autonomous (full whitelist)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "sandbox_id": {
                    "type": "string",
                    "description": "ID of the sandbox to change mode for.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["observe", "assist", "autonomous"],
                    "description": "New profile mode.",
                },
            },
            "required": ["sandbox_id", "mode"],
        },
    },
    {
        "name": "file_read",
        "description": (
            "Read the contents of a file through the sandbox. The file path is "
            "validated against the sandbox's filesystem policy."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to read (relative to sandbox working dir).",
                },
                "sandbox_id": {
                    "type": "string",
                    "description": "Sandbox to read through. Uses default if omitted.",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "file_write",
        "description": (
            "Write content to a file through the sandbox. The file path is "
            "validated against the sandbox's filesystem policy and the operation "
            "is logged to the audit trail."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to write (relative to sandbox working dir).",
                },
                "content": {
                    "type": "string",
                    "description": "Content to write to the file.",
                },
                "sandbox_id": {
                    "type": "string",
                    "description": "Sandbox to write through. Uses default if omitted.",
                },
            },
            "required": ["path", "content"],
        },
    },
]


# ---------------------------------------------------------------------------
# JSON-RPC helpers
# ---------------------------------------------------------------------------

def _jsonrpc_response(id: Any, result: Any) -> dict:
    """Build a JSON-RPC 2.0 success response."""
    return {"jsonrpc": "2.0", "id": id, "result": result}


def _jsonrpc_error(id: Any, code: int, message: str, data: Any = None) -> dict:
    """Build a JSON-RPC 2.0 error response."""
    err: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": "2.0", "id": id, "error": err}


# Standard JSON-RPC error codes
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603


def parse_jsonrpc_message(line: str) -> dict | None:
    """Parse a single JSON-RPC message from a line of text.

    Returns the parsed dict, or None if the line is empty/whitespace.
    Raises ValueError on malformed JSON.
    """
    line = line.strip()
    if not line:
        return None
    return json.loads(line)


# ---------------------------------------------------------------------------
# MCP tool call rate limiter (sliding window, follows api/auth.py pattern)
# ---------------------------------------------------------------------------

class MCPToolRateLimiter:
    """In-memory sliding window rate limiter for MCP tool calls."""

    def __init__(self, max_calls: int = 60, window_seconds: int = 60):
        self.max_calls = max_calls
        self.window_seconds = window_seconds
        self._timestamps: list[float] = []

    def is_allowed(self) -> tuple[bool, int]:
        """Check if a tool call is allowed.

        Returns (allowed, remaining) where remaining is the number of
        calls left in the current window.
        """
        now = time.monotonic()
        window_start = now - self.window_seconds

        # Prune old entries
        self._timestamps = [t for t in self._timestamps if t > window_start]

        remaining = max(0, self.max_calls - len(self._timestamps))

        if len(self._timestamps) >= self.max_calls:
            return False, 0

        self._timestamps.append(now)
        remaining = max(0, self.max_calls - len(self._timestamps))
        return True, remaining

    def reset(self) -> None:
        """Reset the rate limiter."""
        self._timestamps.clear()


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

class MCPServer:
    """LASSO MCP server — routes MCP tool calls through sandboxed execution.

    The server reads newline-delimited JSON-RPC messages from ``input_stream``
    and writes responses to ``output_stream``.  By default these are stdin and
    stdout, matching the standard MCP stdio transport.

    Parameters
    ----------
    default_profile : str
        Name of the default sandbox profile (must be a builtin or loadable).
    working_dir : str
        Default working directory for sandboxes.
    registry : SandboxRegistry | None
        Pre-existing registry.  Created automatically if not supplied.
    input_stream / output_stream : TextIO
        Override stdin/stdout for testing.
    """

    def __init__(
        self,
        default_profile: str = "development",
        working_dir: str = ".",
        registry: Optional[SandboxRegistry] = None,
        input_stream: Optional[TextIO] = None,
        output_stream: Optional[TextIO] = None,
        mcp_security: Optional[MCPSecurityConfig] = None,
    ):
        self.default_profile_name = default_profile
        self.working_dir = str(Path(working_dir).resolve())
        self.registry = registry or SandboxRegistry()
        self._input = input_stream or sys.stdin
        self._output = output_stream or sys.stdout
        self._initialized = False
        self._default_sandbox_id: Optional[str] = None
        self._running = False

        # MCP security policy
        self._mcp_security = mcp_security or MCPSecurityConfig()
        self._rate_limiter = MCPToolRateLimiter(
            max_calls=self._mcp_security.max_tool_calls_per_minute,
            window_seconds=60,
        )
        self._client_name: Optional[str] = None

        # Audit logger for MCP-level events (sandbox-independent)
        from lasso.config.schema import AuditConfig
        self._audit = AuditLogger(
            sandbox_id="mcp-server",
            config=AuditConfig(enabled=self._mcp_security.audit_tool_calls),
        )

        # Method dispatch table
        self._methods: dict[str, Any] = {
            "initialize": self._handle_initialize,
            "notifications/initialized": self._handle_initialized_notification,
            "tools/list": self._handle_tools_list,
            "tools/call": self._handle_tools_call,
            "ping": self._handle_ping,
        }

    # ------------------------------------------------------------------
    # Transport
    # ------------------------------------------------------------------

    def _send(self, msg: dict) -> None:
        """Write a JSON-RPC message to the output stream."""
        line = json.dumps(msg, separators=(",", ":"))
        self._output.write(line + "\n")
        self._output.flush()

    def _read_message(self) -> dict | None:
        """Read one JSON-RPC message from the input stream.

        Returns None on EOF.
        """
        try:
            line = self._input.readline()
        except (EOFError, OSError):
            return None
        if not line:
            return None
        return parse_jsonrpc_message(line)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Run the MCP server, reading from input until EOF or shutdown."""
        self._running = True
        logger.info("LASSO MCP server starting (profile=%s)", self.default_profile_name)

        while self._running:
            try:
                msg = self._read_message()
            except ValueError as exc:
                self._send(_jsonrpc_error(None, PARSE_ERROR, f"Parse error: {exc}"))
                continue

            if msg is None:
                # EOF — clean shutdown
                break

            self._dispatch(msg)

        # Cleanup
        self._shutdown()

    def stop(self) -> None:
        """Signal the server to stop after current message."""
        self._running = False

    def _shutdown(self) -> None:
        """Stop all sandboxes on server shutdown."""
        logger.info("LASSO MCP server shutting down")
        self.registry.stop_all()

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def _dispatch(self, msg: dict) -> None:
        """Route a JSON-RPC message to the appropriate handler."""
        method = msg.get("method")
        msg_id = msg.get("id")  # None for notifications
        params = msg.get("params", {})

        if not method:
            if msg_id is not None:
                self._send(_jsonrpc_error(msg_id, INVALID_REQUEST, "Missing 'method' field."))
            return

        handler = self._methods.get(method)
        if handler is None:
            if msg_id is not None:
                self._send(_jsonrpc_error(msg_id, METHOD_NOT_FOUND, f"Unknown method: {method}"))
            return

        try:
            result = handler(params)
            # Only send response for requests (those with an id), not notifications
            if msg_id is not None:
                self._send(_jsonrpc_response(msg_id, result))
        except Exception as exc:
            logger.exception("Error handling %s", method)
            if msg_id is not None:
                self._send(_jsonrpc_error(msg_id, INTERNAL_ERROR, str(exc)))

    # ------------------------------------------------------------------
    # Dispatch a single message (for testing without running the loop)
    # ------------------------------------------------------------------

    def handle_message(self, msg: dict) -> None:
        """Process a single JSON-RPC message and write the response.

        Convenience method for testing — equivalent to what ``run()`` does
        for each message but without the read loop.
        """
        self._dispatch(msg)

    # ------------------------------------------------------------------
    # MCP lifecycle handlers
    # ------------------------------------------------------------------

    def _handle_initialize(self, params: dict) -> dict:
        """Handle MCP 'initialize' request.

        Captures the client name from ``params.clientInfo.name`` for use
        in server allow/block list checks.
        """
        client_info = params.get("clientInfo", {})
        self._client_name = client_info.get("name")
        if self._client_name:
            logger.info("MCP client identified: %s", self._client_name)

        return {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": SERVER_CAPABILITIES,
            "serverInfo": SERVER_INFO,
        }

    def _handle_initialized_notification(self, params: dict) -> dict:
        """Handle 'notifications/initialized' — client is ready."""
        self._initialized = True
        logger.info("MCP client initialized")
        return {}

    def _handle_ping(self, params: dict) -> dict:
        """Handle ping for health checks."""
        return {}

    # ------------------------------------------------------------------
    # Tool handlers
    # ------------------------------------------------------------------

    def _handle_tools_list(self, params: dict) -> dict:
        """Return the list of available tools.

        When MCP security is enabled, the client must have completed the
        initialization handshake before discovering tools.  This is a
        lighter gate than the full policy check used for tools/call.
        """
        if self._mcp_security.enabled and not self._initialized:
            raise ValueError(
                "MCP client has not completed initialization handshake."
            )
        return {"tools": TOOLS}

    # ------------------------------------------------------------------
    # MCP security policy enforcement
    # ------------------------------------------------------------------

    def _check_mcp_policy(self, tool_name: str, arguments: dict) -> Optional[str]:
        """Check MCP security policy before dispatching a tool call.

        Returns a block reason string if the call should be denied,
        or None if it is allowed.
        """
        sec = self._mcp_security

        # 0. Initialization handshake required when security is enabled
        if not self._initialized and sec.enabled:
            return "MCP client has not completed initialization handshake."

        # 1. MCP must be enabled
        if not sec.enabled:
            return "MCP is disabled in this sandbox profile."

        # 2. Check client name against blocked list
        if self._client_name and sec.blocked_servers:
            if self._client_name in sec.blocked_servers:
                return f"MCP server '{self._client_name}' is blocked."

        # 3. Check client name against allowed list (if non-empty, acts as whitelist)
        if sec.allowed_servers:
            if self._client_name is None:
                return "Client must identify itself when server allowlist is configured."
            if self._client_name not in sec.allowed_servers:
                return (
                    f"MCP server '{self._client_name}' is not in the allowed list."
                )

        # 4. Shell execution check for sandbox_exec
        if tool_name == "sandbox_exec" and not sec.allow_shell_execution:
            return "Shell execution via MCP is disabled (allow_shell_execution=False)."

        # 5. Rate limiting
        allowed, remaining = self._rate_limiter.is_allowed()
        if not allowed:
            return (
                f"MCP tool call rate limit exceeded "
                f"({sec.max_tool_calls_per_minute}/min)."
            )

        return None

    def _log_mcp_tool_call(
        self,
        tool_name: str,
        arguments: dict,
        outcome: str,
        detail: Optional[dict[str, Any]] = None,
    ) -> None:
        """Log an MCP tool call to the audit trail (if audit_tool_calls is enabled)."""
        if not self._mcp_security.audit_tool_calls:
            return
        merged: dict[str, Any] = {}
        if self._client_name:
            merged["client_name"] = self._client_name
        if detail:
            merged.update(detail)
        self._audit.log_mcp_tool_call(
            tool_name=tool_name,
            arguments=arguments,
            outcome=outcome,
            detail=merged,
        )

    # ------------------------------------------------------------------
    # Tool dispatch (with security interception)
    # ------------------------------------------------------------------

    def _handle_tools_call(self, params: dict) -> dict:
        """Dispatch a tool call to the appropriate handler.

        Security policy is enforced BEFORE dispatching: enabled check,
        server allow/block lists, shell execution gating, and rate
        limiting.  All calls (allowed and blocked) are audit-logged.
        """
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        # --- Security interception ---
        block_reason = self._check_mcp_policy(tool_name, arguments)
        if block_reason:
            self._log_mcp_tool_call(tool_name, arguments, "blocked", {"reason": block_reason})
            return {
                "content": [{"type": "text", "text": f"BLOCKED: {block_reason}"}],
                "isError": True,
            }

        tool_handlers = {
            "sandbox_exec": self._tool_sandbox_exec,
            "sandbox_create": self._tool_sandbox_create,
            "sandbox_stop": self._tool_sandbox_stop,
            "sandbox_status": self._tool_sandbox_status,
            "sandbox_list": self._tool_sandbox_list,
            "sandbox_set_mode": self._tool_sandbox_set_mode,
            "file_read": self._tool_file_read,
            "file_write": self._tool_file_write,
        }

        handler = tool_handlers.get(tool_name)
        if handler is None:
            self._log_mcp_tool_call(tool_name, arguments, "error", {"reason": "unknown_tool"})
            return {
                "content": [{"type": "text", "text": f"Unknown tool: {tool_name}"}],
                "isError": True,
            }

        try:
            result = handler(arguments)
            outcome = "error" if result.get("isError") else "success"
            self._log_mcp_tool_call(tool_name, arguments, outcome)
            return result
        except Exception as exc:
            logger.exception("Tool %s failed", tool_name)
            self._log_mcp_tool_call(tool_name, arguments, "error", {"exception": str(exc)})
            return {
                "content": [{"type": "text", "text": f"Tool error: {exc}"}],
                "isError": True,
            }

    # ------------------------------------------------------------------
    # Sandbox resolution helpers
    # ------------------------------------------------------------------

    def _resolve_sandbox(self, sandbox_id: Optional[str] = None) -> Sandbox | None:
        """Get a sandbox by ID, falling back to the default session sandbox."""
        target_id = sandbox_id or self._default_sandbox_id
        if target_id is None:
            return None
        return self.registry.get(target_id)

    def _get_or_create_default_sandbox(self, profile_name: Optional[str] = None) -> Sandbox:
        """Return the default sandbox, creating it if necessary."""
        if self._default_sandbox_id:
            sb = self.registry.get(self._default_sandbox_id)
            if sb is not None:
                return sb

        # Create a new default sandbox
        name = profile_name or self.default_profile_name
        profile = self._resolve_profile(name, self.working_dir)
        sb = self.registry.create(profile)
        sb.start()
        self._default_sandbox_id = sb.id
        return sb

    @staticmethod
    def _resolve_profile(profile_name: str, working_dir: str) -> SandboxProfile:
        """Resolve a profile name to a SandboxProfile instance."""
        if profile_name in BUILTIN_PROFILES:
            return BUILTIN_PROFILES[profile_name](working_dir)

        from lasso.config.profile import load_profile
        return load_profile(profile_name)

    # ------------------------------------------------------------------
    # Tool implementations
    # ------------------------------------------------------------------

    def _tool_sandbox_exec(self, args: dict) -> dict:
        """Execute a command in a sandbox."""
        command = args.get("command")
        if not command:
            return {
                "content": [{"type": "text", "text": "Missing required parameter: command"}],
                "isError": True,
            }

        sandbox_id = args.get("sandbox_id")
        profile = args.get("profile")

        if sandbox_id:
            sb = self.registry.get(sandbox_id)
            if sb is None:
                return {
                    "content": [{"type": "text", "text": f"Sandbox not found: {sandbox_id}"}],
                    "isError": True,
                }
        else:
            sb = self._get_or_create_default_sandbox(profile)

        result: SandboxExecResult = sb.exec(command)

        if result.blocked:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"BLOCKED: {result.block_reason}",
                    }
                ],
                "isError": True,
            }

        output_parts = []
        if result.stdout:
            output_parts.append(result.stdout)
        if result.stderr:
            output_parts.append(f"[stderr] {result.stderr}")

        text = "\n".join(output_parts) if output_parts else "(no output)"

        return {
            "content": [{"type": "text", "text": text}],
            "isError": result.exit_code != 0,
        }

    def _tool_sandbox_create(self, args: dict) -> dict:
        """Create a new sandbox."""
        profile_name = args.get("profile")
        working_dir = args.get("working_dir")

        if not profile_name or not working_dir:
            return {
                "content": [{"type": "text", "text": "Missing required parameters: profile, working_dir"}],
                "isError": True,
            }

        working_dir = str(Path(working_dir).resolve())

        # Validate working directory (same rules as REST API)
        wd_path = Path(working_dir)
        if not wd_path.exists():
            return {
                "content": [{"type": "text", "text": f"Working directory does not exist: {working_dir}"}],
                "isError": True,
            }
        if not wd_path.is_dir():
            return {
                "content": [{"type": "text", "text": f"Working directory is not a directory: {working_dir}"}],
                "isError": True,
            }
        # Block system directories
        _BLOCKED_DIRS = ("/etc", "/usr", "/bin", "/sbin", "/boot", "/proc", "/sys", "/dev", "/root", "/var/run")
        for blocked in _BLOCKED_DIRS:
            if working_dir == blocked or working_dir.startswith(blocked + "/"):
                return {
                    "content": [{"type": "text", "text": f"Cannot create sandbox in system directory: {working_dir}"}],
                    "isError": True,
                }

        try:
            profile = self._resolve_profile(profile_name, working_dir)
        except (FileNotFoundError, KeyError):
            available = ", ".join(BUILTIN_PROFILES.keys())
            return {
                "content": [{"type": "text", "text": f"Unknown profile: {profile_name}. Available: {available}"}],
                "isError": True,
            }

        sb = self.registry.create(profile)
        sb.start()

        # Set as default if this is the first sandbox
        if self._default_sandbox_id is None:
            self._default_sandbox_id = sb.id

        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({
                        "sandbox_id": sb.id,
                        "profile": profile_name,
                        "state": sb.state.value,
                        "working_dir": working_dir,
                    }, indent=2),
                }
            ],
            "isError": False,
        }

    def _tool_sandbox_stop(self, args: dict) -> dict:
        """Stop a sandbox."""
        sandbox_id = args.get("sandbox_id")
        if not sandbox_id:
            return {
                "content": [{"type": "text", "text": "Missing required parameter: sandbox_id"}],
                "isError": True,
            }

        if self.registry.stop(sandbox_id):
            if self._default_sandbox_id == sandbox_id:
                self._default_sandbox_id = None
            return {
                "content": [{"type": "text", "text": f"Sandbox {sandbox_id} stopped."}],
                "isError": False,
            }

        return {
            "content": [{"type": "text", "text": f"Sandbox not found: {sandbox_id}"}],
            "isError": True,
        }

    def _tool_sandbox_status(self, args: dict) -> dict:
        """Get sandbox status."""
        sandbox_id = args.get("sandbox_id")
        if not sandbox_id:
            return {
                "content": [{"type": "text", "text": "Missing required parameter: sandbox_id"}],
                "isError": True,
            }

        sb = self.registry.get(sandbox_id)
        if sb is None:
            return {
                "content": [{"type": "text", "text": f"Sandbox not found: {sandbox_id}"}],
                "isError": True,
            }

        return {
            "content": [{"type": "text", "text": json.dumps(sb.status(), indent=2)}],
            "isError": False,
        }

    def _tool_sandbox_list(self, args: dict) -> dict:
        """List all sandboxes."""
        sandboxes = self.registry.list_all()
        return {
            "content": [{"type": "text", "text": json.dumps(sandboxes, indent=2)}],
            "isError": False,
        }

    def _tool_sandbox_set_mode(self, args: dict) -> dict:
        """Change the profile mode of a sandbox."""
        sandbox_id = args.get("sandbox_id")
        mode_str = args.get("mode")

        if not sandbox_id or not mode_str:
            return {
                "content": [{"type": "text", "text": "Missing required parameters: sandbox_id, mode"}],
                "isError": True,
            }

        try:
            target_mode = ProfileMode(mode_str)
        except ValueError:
            return {
                "content": [{"type": "text", "text": f"Invalid mode: {mode_str}. Valid: observe, assist, autonomous"}],
                "isError": True,
            }

        if self.registry.set_mode(sandbox_id, target_mode):
            sb = self.registry.get(sandbox_id)
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"Sandbox {sandbox_id} mode set to {target_mode.value}.",
                    }
                ],
                "isError": False,
            }

        return {
            "content": [{"type": "text", "text": f"Sandbox not found: {sandbox_id}"}],
            "isError": True,
        }

    def _tool_file_read(self, args: dict) -> dict:
        """Read a file through the sandbox."""
        path = args.get("path")
        if not path:
            return {
                "content": [{"type": "text", "text": "Missing required parameter: path"}],
                "isError": True,
            }

        sandbox_id = args.get("sandbox_id")
        sb = self._resolve_sandbox(sandbox_id)
        if sb is None:
            sb = self._get_or_create_default_sandbox()

        # Execute cat through the sandbox's command gate
        result = sb.exec(f"cat {shlex.quote(path)}")

        if result.blocked:
            return {
                "content": [{"type": "text", "text": f"BLOCKED: {result.block_reason}"}],
                "isError": True,
            }

        if result.exit_code != 0:
            error_msg = result.stderr or f"Failed to read file: {path}"
            return {
                "content": [{"type": "text", "text": error_msg}],
                "isError": True,
            }

        sb.audit.log_file_access(path, "read")

        return {
            "content": [{"type": "text", "text": result.stdout}],
            "isError": False,
        }

    def _tool_file_write(self, args: dict) -> dict:
        """Write a file through the sandbox."""
        path = args.get("path")
        content = args.get("content")

        if not path or content is None:
            return {
                "content": [{"type": "text", "text": "Missing required parameters: path, content"}],
                "isError": True,
            }

        sandbox_id = args.get("sandbox_id")
        sb = self._resolve_sandbox(sandbox_id)
        if sb is None:
            sb = self._get_or_create_default_sandbox()

        # Use printf to write through the sandbox command gate.
        # Escape single quotes in content for shell safety.
        escaped = content.replace("'", "'\\''")
        write_cmd = f"printf '%s' '{escaped}'"

        # First validate the write command is allowed, then the redirect target.
        # We construct as: printf '%s' '<content>' > <path>
        # But shell operators may be blocked, so use tee as fallback concept.
        # Actually, use the sandbox exec which goes through the command gate.
        # Since shell operators may be blocked, we write via python3 -c.
        import base64
        b64 = base64.b64encode(content.encode()).decode()
        write_cmd = (
            f"python3 -c \"import base64; "
            f"open({shlex.quote(path)},'w').write(base64.b64decode({shlex.quote(b64)}).decode())\""
        )

        result = sb.exec(write_cmd)

        if result.blocked:
            return {
                "content": [{"type": "text", "text": f"BLOCKED: {result.block_reason}"}],
                "isError": True,
            }

        if result.exit_code != 0:
            error_msg = result.stderr or f"Failed to write file: {path}"
            return {
                "content": [{"type": "text", "text": error_msg}],
                "isError": True,
            }

        sb.audit.log_file_access(path, "write")

        return {
            "content": [{"type": "text", "text": f"Written {len(content)} bytes to {path}"}],
            "isError": False,
        }


# ---------------------------------------------------------------------------
# MCP config generation
# ---------------------------------------------------------------------------

def generate_mcp_config(
    profile: str = "development",
    extra_args: Optional[list[str]] = None,
) -> dict:
    """Generate an MCP server configuration JSON for client setup.

    This produces the JSON that MCP clients (Claude Desktop, VS Code, etc.)
    need in their configuration to connect to LASSO.
    """
    args = ["mcp", "--profile", profile]
    if extra_args:
        args.extend(extra_args)

    return {
        "mcpServers": {
            "lasso": {
                "command": "lasso",
                "args": args,
            }
        }
    }
