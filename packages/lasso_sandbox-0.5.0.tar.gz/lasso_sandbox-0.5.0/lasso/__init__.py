"""LASSO - Layered Agent Sandbox Security Orchestrator."""

__version__ = "0.5.0"

__all__ = ["__version__"]
