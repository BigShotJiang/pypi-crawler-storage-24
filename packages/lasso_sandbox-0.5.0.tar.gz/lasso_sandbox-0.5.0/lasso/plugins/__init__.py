"""LASSO plugin system — discover and load plugins via entry_points."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from importlib.metadata import entry_points
from typing import Any, Optional

logger = logging.getLogger("lasso.plugins")


class AuditSink(ABC):
    """Plugin interface for custom audit event destinations."""

    @abstractmethod
    def send(self, event: dict) -> None:
        """Send an audit event to the sink."""
        ...

    def close(self) -> None:
        """Clean up resources."""
        pass


class CommandGatePlugin(ABC):
    """Plugin interface for custom command validation rules."""

    @abstractmethod
    def before_exec(self, command: str, args: list[str], profile_name: str) -> tuple[bool, str]:
        """Called before command execution. Return (allowed, reason)."""
        ...

    def after_exec(self, command: str, args: list[str], result: dict) -> None:
        """Called after command execution."""
        pass


# Plugin groups
PLUGIN_GROUPS = {
    "lasso.plugins.audit": AuditSink,
    "lasso.plugins.commands": CommandGatePlugin,
    "lasso.plugins.agents": None,  # Uses existing AgentProvider ABC
}


def discover_plugins(group: str) -> list[Any]:
    """Discover and load all plugins for a given group."""
    plugins = []
    try:
        eps = entry_points()
        # Python 3.12+ returns a SelectableGroups, earlier returns dict
        if hasattr(eps, "select"):
            group_eps = eps.select(group=group)
        else:
            group_eps = eps.get(group, [])

        for ep in group_eps:
            try:
                plugin_cls = ep.load()
                plugins.append(plugin_cls)
                logger.info("Loaded plugin: %s from %s", ep.name, ep.value)
            except Exception as e:
                logger.warning("Failed to load plugin %s: %s", ep.name, e)
    except Exception as e:
        logger.warning("Plugin discovery failed for group %s: %s", group, e)

    return plugins


def get_audit_sinks() -> list[AuditSink]:
    """Discover and instantiate all audit sink plugins."""
    sinks = []
    for cls in discover_plugins("lasso.plugins.audit"):
        try:
            sink = cls()
            if isinstance(sink, AuditSink):
                sinks.append(sink)
        except Exception as e:
            logger.warning("Failed to instantiate audit sink %s: %s", cls, e)
    return sinks


def get_command_gate_plugins() -> list[CommandGatePlugin]:
    """Discover and instantiate all command gate plugins."""
    plugins = []
    for cls in discover_plugins("lasso.plugins.commands"):
        try:
            plugin = cls()
            if isinstance(plugin, CommandGatePlugin):
                plugins.append(plugin)
        except Exception as e:
            logger.warning("Failed to instantiate command gate plugin %s: %s", cls, e)
    return plugins
