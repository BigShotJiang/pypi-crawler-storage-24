"""LASSO REST API v1 -- Flask Blueprint with all endpoints.

All responses use a consistent JSON envelope:
    {
        "success": true/false,
        "data": <payload or null>,
        "error": <error message or null>
    }

List endpoints support pagination via ``?limit=50&offset=0`` query parameters
and return a ``pagination`` object alongside the data.

Endpoints:
    Sandboxes:
        POST   /api/v1/sandboxes              Create sandbox
        GET    /api/v1/sandboxes              List all sandboxes
        GET    /api/v1/sandboxes/<id>         Get sandbox detail
        POST   /api/v1/sandboxes/<id>/exec    Execute command
        POST   /api/v1/sandboxes/<id>/stop    Stop sandbox
        DELETE /api/v1/sandboxes/<id>         Remove sandbox

    Profiles:
        GET    /api/v1/profiles               List all profiles
        GET    /api/v1/profiles/<name>        Get profile detail
        POST   /api/v1/profiles               Create/save profile
        DELETE /api/v1/profiles/<name>        Delete saved profile

    Audit:
        GET    /api/v1/sandboxes/<id>/audit   Get audit entries
        POST   /api/v1/audit/verify           Verify audit log integrity

    System:
        GET    /api/v1/health                 Health check
        GET    /api/v1/system/check           System capabilities
        GET    /api/v1/agents                 List supported agents
"""

from __future__ import annotations

import ipaddress
import json
import platform
import shutil
import socket
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

try:
    from flask import Blueprint, current_app, jsonify, request
except ImportError:
    raise ImportError(
        "Flask is required for the REST API. "
        "Install it with: pip install lasso-sandbox[dashboard]"
    )

from lasso import __version__
from lasso.api.auth import require_api_key, require_scope
from lasso.api.openapi import SWAGGER_UI_HTML, generate_openapi_spec
from lasso.config.defaults import BUILTIN_PROFILES
from lasso.config.profile import (
    delete_profile,
    list_profiles,
    load_profile,
    save_profile,
)
from lasso.config.schema import SandboxProfile, SandboxState
from lasso.core.audit_verify import verify_audit_log
from lasso.core.sandbox import SandboxRegistry
from lasso.dashboard.app import read_audit_log

# ---------------------------------------------------------------------------
# Blueprint
# ---------------------------------------------------------------------------

api_v1_bp = Blueprint("api_v1", __name__, url_prefix="/api/v1")

# Track startup time for uptime calculation in the health endpoint.
_startup_time = time.monotonic()
_startup_wall = datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _default_sandbox_dir() -> str:
    """Return a platform-appropriate default sandbox directory."""
    return str(Path(tempfile.gettempdir()) / "lasso-sandbox")


def _ok(data: Any, status: int = 200):
    """Return a success JSON envelope."""
    resp = jsonify({"success": True, "data": data, "error": None})
    resp.status_code = status
    return resp


def _ok_paginated(items: list, total: int, limit: int, offset: int, status: int = 200):
    """Return a success JSON envelope with pagination metadata.

    Args:
        items: The page of items to return.
        total: Total number of items before pagination.
        limit: Maximum items per page.
        offset: Number of items skipped.
        status: HTTP status code.
    """
    resp = jsonify({
        "success": True,
        "data": items,
        "pagination": {
            "total": total,
            "limit": limit,
            "offset": offset,
            "has_more": (offset + limit) < total,
        },
        "error": None,
    })
    resp.status_code = status
    return resp


def _parse_pagination() -> tuple[int, int]:
    """Parse limit and offset from query parameters with validation.

    Returns:
        A (limit, offset) tuple with sane defaults and bounds.
    """
    try:
        limit = int(request.args.get("limit", 50))
    except (ValueError, TypeError):
        limit = 50
    try:
        offset = int(request.args.get("offset", 0))
    except (ValueError, TypeError):
        offset = 0

    # Clamp to sensible bounds
    limit = max(1, min(limit, 200))
    offset = max(0, offset)
    return limit, offset


def _err(message: str, status: int = 400):
    """Return an error JSON envelope."""
    resp = jsonify({"success": False, "data": None, "error": message})
    resp.status_code = status
    return resp


def _get_registry() -> SandboxRegistry:
    reg = current_app.config.get("REGISTRY")
    if reg is None:
        reg = SandboxRegistry()
        current_app.config["REGISTRY"] = reg
    return reg


def _validate_working_dir(working_dir: str) -> str | None:
    """Validate working_dir input. Returns error message or None if valid."""
    if not working_dir:
        return "working_dir is required."
    if ".." in working_dir:
        return "Path traversal (..) is not allowed."
    if len(working_dir) > 4096:
        return "Path too long (max 4096 characters)."
    resolved = Path(working_dir).resolve()
    home = Path.home().resolve()
    tmp = Path(tempfile.gettempdir()).resolve()
    if not (str(resolved).startswith(str(home)) or str(resolved).startswith(str(tmp))):
        return "Working directory must be under home or temp directory."
    return None


def _profile_to_dict(profile: SandboxProfile, source: str = "unknown") -> dict:
    """Serialize a SandboxProfile to a JSON-friendly dict."""
    data = profile.model_dump(mode="json")
    data["source"] = source
    data["config_hash"] = profile.config_hash()
    return data


# ---------------------------------------------------------------------------
# Sandbox endpoints
# ---------------------------------------------------------------------------

@api_v1_bp.route("/sandboxes", methods=["POST"])
@require_api_key
@require_scope("write")
def create_sandbox():
    """Create a new sandbox from a profile.

    Body (JSON):
        {
            "profile": "minimal",
            "working_dir": "/tmp/my-sandbox"
        }
    """
    body = request.get_json(silent=True)
    if not body:
        return _err("Request body must be JSON.", 400)

    profile_name = body.get("profile", "").strip()
    working_dir = body.get("working_dir", "").strip()

    if not profile_name:
        return _err("'profile' is required.", 400)
    if not working_dir:
        return _err("'working_dir' is required.", 400)

    dir_error = _validate_working_dir(working_dir)
    if dir_error:
        return _err(dir_error, 400)

    # Resolve profile
    if profile_name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[profile_name](working_dir)
    else:
        try:
            profile = load_profile(profile_name)
            # Override working_dir from request
            profile.filesystem.working_dir = working_dir
        except FileNotFoundError:
            return _err(f"Profile '{profile_name}' not found.", 404)
        except ValueError as exc:
            return _err(str(exc), 400)

    registry = _get_registry()
    sb = registry.create(profile)

    try:
        sb.start()
    except RuntimeError as exc:
        # Sandbox created but failed to start -- return it with error state
        return _ok(sb.status(), 201)

    return _ok(sb.status(), 201)


@api_v1_bp.route("/sandboxes", methods=["GET"])
@require_api_key
def list_sandboxes():
    """List all sandboxes with optional pagination.

    Query params:
        limit: Max items per page (default 50, max 200).
        offset: Number of items to skip (default 0).
    """
    registry = _get_registry()
    all_sandboxes = registry.list_all()
    total = len(all_sandboxes)

    limit, offset = _parse_pagination()
    page = all_sandboxes[offset:offset + limit]
    return _ok_paginated(page, total, limit, offset)


@api_v1_bp.route("/sandboxes/<sandbox_id>", methods=["GET"])
@require_api_key
def get_sandbox(sandbox_id: str):
    """Get sandbox detail by ID."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return _err(f"Sandbox '{sandbox_id}' not found.", 404)
    return _ok(sb.status())


@api_v1_bp.route("/sandboxes/<sandbox_id>/exec", methods=["POST"])
@require_api_key
@require_scope("write")
def exec_in_sandbox(sandbox_id: str):
    """Execute a command inside a sandbox.

    Body (JSON):
        {
            "command": "ls -la"
        }
    """
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return _err(f"Sandbox '{sandbox_id}' not found.", 404)

    body = request.get_json(silent=True)
    if not body:
        return _err("Request body must be JSON.", 400)

    command = body.get("command", "").strip()
    if not command:
        return _err("'command' is required.", 400)
    if len(command) > 4096:
        return _err("Command too long (max 4096 characters).", 400)

    if sb.state != SandboxState.RUNNING:
        return _err(f"Sandbox is not running (state: {sb.state.value}).", 409)

    result = sb.exec(command)

    return _ok({
        "command": result.command,
        "exit_code": result.exit_code,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "duration_ms": result.duration_ms,
        "blocked": result.blocked,
        "block_reason": result.block_reason if result.blocked else None,
    })


@api_v1_bp.route("/sandboxes/<sandbox_id>/stop", methods=["POST"])
@require_api_key
@require_scope("write")
def stop_sandbox(sandbox_id: str):
    """Stop a running sandbox."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return _err(f"Sandbox '{sandbox_id}' not found.", 404)

    if sb.state == SandboxState.STOPPED:
        return _ok(sb.status())  # Already stopped, idempotent

    sb.stop()
    return _ok(sb.status())


@api_v1_bp.route("/sandboxes/<sandbox_id>", methods=["DELETE"])
@require_api_key
@require_scope("write")
def remove_sandbox(sandbox_id: str):
    """Remove a sandbox entirely (stops it first if running)."""
    registry = _get_registry()
    if not registry.get(sandbox_id):
        return _err(f"Sandbox '{sandbox_id}' not found.", 404)

    registry.remove(sandbox_id)
    return _ok({"removed": sandbox_id})


# ---------------------------------------------------------------------------
# Profile endpoints
# ---------------------------------------------------------------------------

@api_v1_bp.route("/profiles", methods=["GET"])
@require_api_key
def list_all_profiles():
    """List all profiles (builtin + saved) with optional pagination.

    Query params:
        limit: Max items per page (default 50, max 200).
        offset: Number of items to skip (default 0).
    """
    profiles = []

    for name, factory in BUILTIN_PROFILES.items():
        p = factory(_default_sandbox_dir())
        profiles.append({
            "name": name,
            "description": p.description,
            "source": "builtin",
            "cmd_mode": p.commands.mode.value,
            "net_mode": p.network.mode.value,
            "mem_limit": f"{p.resources.max_memory_mb}MB",
            "tags": p.tags,
        })

    for saved in list_profiles():
        if "error" not in saved:
            saved["source"] = "saved"
            saved.setdefault("description", "")
            profiles.append(saved)
        else:
            profiles.append({
                "name": saved.get("name", "unknown"),
                "source": "saved",
                "error": saved["error"],
            })

    total = len(profiles)
    limit, offset = _parse_pagination()
    page = profiles[offset:offset + limit]
    return _ok_paginated(page, total, limit, offset)


@api_v1_bp.route("/profiles/<name>", methods=["GET"])
@require_api_key
def get_profile(name: str):
    """Get profile detail by name."""
    if name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[name](_default_sandbox_dir())
        return _ok(_profile_to_dict(profile, source="builtin"))

    try:
        profile = load_profile(name)
        return _ok(_profile_to_dict(profile, source="saved"))
    except FileNotFoundError:
        return _err(f"Profile '{name}' not found.", 404)
    except ValueError as exc:
        return _err(str(exc), 400)


@api_v1_bp.route("/profiles", methods=["POST"])
@require_api_key
@require_scope("write")
def create_profile():
    """Create or update a saved profile.

    Body (JSON): a full SandboxProfile object, e.g.:
        {
            "name": "my-profile",
            "filesystem": {"working_dir": "/tmp/sandbox"},
            ...
        }
    """
    body = request.get_json(silent=True)
    if not body:
        return _err("Request body must be JSON.", 400)

    # Validate by constructing a SandboxProfile
    try:
        profile = SandboxProfile(**body)
    except Exception as exc:
        return _err(f"Invalid profile data: {exc}", 400)

    # Reject overwriting builtin profile names
    if profile.name in BUILTIN_PROFILES:
        return _err(
            f"Cannot overwrite builtin profile '{profile.name}'. Choose a different name.",
            409,
        )

    path = save_profile(profile)
    return _ok({
        "name": profile.name,
        "path": str(path),
        "config_hash": profile.config_hash(),
    }, 201)


@api_v1_bp.route("/profiles/<name>", methods=["DELETE"])
@require_api_key
@require_scope("write")
def delete_profile_endpoint(name: str):
    """Delete a saved profile."""
    if name in BUILTIN_PROFILES:
        return _err(f"Cannot delete builtin profile '{name}'.", 409)

    if not delete_profile(name):
        return _err(f"Profile '{name}' not found.", 404)

    return _ok({"deleted": name})


# ---------------------------------------------------------------------------
# Audit endpoints
# ---------------------------------------------------------------------------

@api_v1_bp.route("/sandboxes/<sandbox_id>/audit", methods=["GET"])
@require_api_key
def get_audit_entries(sandbox_id: str):
    """Get audit log entries for a sandbox with optional pagination.

    Query params:
        tail: number of entries to return (default 50) -- legacy parameter.
        type: filter by event type (command, lifecycle, violation, etc.)
        limit: max entries per page (default 50, max 200).
        offset: number of entries to skip (default 0).
    """
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return _err(f"Sandbox '{sandbox_id}' not found.", 404)

    # Support both legacy "tail" and new "limit" params
    try:
        tail = int(request.args.get("tail", 0))
    except ValueError:
        return _err("'tail' must be an integer.", 400)
    if tail < 0:
        return _err("'tail' must be non-negative.", 400)

    limit, offset = _parse_pagination()
    event_type = request.args.get("type", "").strip() or None

    entries: list[dict] = []
    if sb.audit.log_file and sb.audit.log_file.exists():
        # If tail is specified, use it as the primary limit (legacy behavior)
        read_tail = tail if tail > 0 else 0
        entries = read_audit_log(sb.audit.log_file, tail=read_tail, event_type=event_type)

    total = len(entries)
    page = entries[offset:offset + limit]

    return _ok_paginated(
        {
            "sandbox_id": sandbox_id,
            "entries": page,
            "count": len(page),
            "log_file": str(sb.audit.log_file) if sb.audit.log_file else None,
        },
        total,
        limit,
        offset,
    )


@api_v1_bp.route("/audit/verify", methods=["POST"])
@require_api_key
def verify_audit():
    """Verify the integrity of an audit log file.

    Body (JSON):
        {
            "log_file": "/path/to/audit.jsonl",
            "key_file": "/path/to/key"  (optional)
        }
    """
    body = request.get_json(silent=True)
    if not body:
        return _err("Request body must be JSON.", 400)

    log_file = body.get("log_file", "").strip()
    if not log_file:
        return _err("'log_file' is required.", 400)

    # Path traversal protection: restrict to LASSO audit directories only
    log_path = Path(log_file).resolve()
    allowed_dirs = [
        Path.home() / ".lasso" / "audit",
        Path.home() / ".lasso",
        Path(tempfile.gettempdir()),
    ]
    if not any(
        log_path == d.resolve() or d.resolve() in log_path.parents
        for d in allowed_dirs
    ):
        return _err("log_file must be in a LASSO audit directory", 403)
    # Reject non-audit file extensions
    if log_path.suffix not in (".jsonl", ".json"):
        return _err("log_file must be a .jsonl or .json audit log", 400)

    if not log_path.exists():
        return _err(f"Log file not found: {log_file}", 404)

    key_file = body.get("key_file")
    if key_file:
        key_path = Path(key_file).resolve()
        key_allowed_dirs = [
            Path.home() / ".lasso",
            Path(tempfile.gettempdir()),
        ]
        if not any(
            key_path == d.resolve() or d.resolve() in key_path.parents
            for d in key_allowed_dirs
        ):
            return _err("key_file must be in a LASSO directory", 403)

    result = verify_audit_log(log_path, key_path=key_file)

    return _ok({
        "valid": result.valid,
        "total_entries": result.total_entries,
        "verified_entries": result.verified_entries,
        "first_break_at": result.first_break_at,
        "errors": result.errors,
    })


# ---------------------------------------------------------------------------
# Webhook endpoints
# ---------------------------------------------------------------------------

@api_v1_bp.route("/webhooks/test", methods=["POST"])
@require_api_key
@require_scope("write")
def test_webhook():
    """Send a test event to a webhook URL.

    Body (JSON):
        {
            "url": "https://example.com/webhook",
            "secret": "optional-hmac-secret"
        }
    """
    body = request.get_json(silent=True)
    if not body:
        return _err("Request body must be JSON.", 400)

    url = (body.get("url") or "").strip()
    if not url:
        return _err("'url' is required.", 400)

    if not url.startswith(("http://", "https://")):
        return _err("'url' must start with http:// or https://.", 400)

    # SSRF protection: use the shared webhook URL validator
    from lasso.core.webhooks import _is_safe_webhook_url

    is_safe, reason = _is_safe_webhook_url(url)
    if not is_safe:
        return _err(f"Webhook URL blocked: {reason}", 400)

    secret = body.get("secret")

    from lasso.config.schema import WebhookConfig
    from lasso.core.audit import AuditEvent
    from lasso.core.webhooks import WebhookDispatcher

    wh_config = WebhookConfig(
        enabled=True,
        url=url,
        events=["lifecycle"],
        secret=secret,
        timeout_seconds=10,
        retry_count=0,
    )
    dispatcher = WebhookDispatcher([wh_config])

    test_event = AuditEvent(
        sandbox_id="test-000000",
        event_type="lifecycle",
        action="webhook_test",
        actor="system",
        detail={"message": "This is a test event from LASSO webhook configuration."},
    )

    # Dispatch synchronously for the test endpoint so we can report success/failure
    import hashlib
    import hmac as hmac_mod
    import urllib.error
    import urllib.request

    payload = json.dumps(test_event.to_dict(), separators=(",", ":"), sort_keys=True)
    headers = {
        "Content-Type": "application/json",
        "X-Lasso-Event": "lifecycle",
        "X-Lasso-Delivery": test_event.event_id,
        "X-Lasso-Timestamp": test_event.timestamp,
        "User-Agent": "LASSO-Webhook/1.0",
    }
    if secret:
        timestamp = test_event.timestamp
        sig_payload = timestamp + "." + payload
        sig = hmac_mod.new(secret.encode(), sig_payload.encode(), hashlib.sha256).hexdigest()
        headers["X-Lasso-Signature"] = f"t={timestamp},sha256={sig}"

    try:
        req = urllib.request.Request(url, data=payload.encode(), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            status = resp.status
            return _ok({
                "delivered": True,
                "status_code": status,
                "event_id": test_event.event_id,
            })
    except (urllib.error.URLError, OSError) as exc:
        return _ok({
            "delivered": False,
            "error": str(exc),
            "event_id": test_event.event_id,
        })


@api_v1_bp.route("/webhooks/events", methods=["GET"])
@require_api_key
def list_webhook_events():
    """List available webhook event types."""
    from lasso.core.webhooks import WEBHOOK_EVENT_TYPES

    return _ok({
        "event_types": WEBHOOK_EVENT_TYPES,
        "descriptions": {
            "command": "Command execution events (allowed and blocked).",
            "lifecycle": "Sandbox lifecycle events (start, stop, error).",
            "violation": "Security policy violation events.",
            "file": "File access and modification events.",
            "network": "Network connection events.",
        },
    })


# ---------------------------------------------------------------------------
# System endpoints
# ---------------------------------------------------------------------------

@api_v1_bp.route("/health", methods=["GET"])
@require_api_key
def health_check():
    """Health check endpoint with backend status and uptime.

    Returns system health including container backend availability,
    number of running sandboxes, and process uptime.
    """
    uptime_seconds = int(time.monotonic() - _startup_time)

    # Determine backend type and availability
    backend_name = "native"
    backend_available = True
    try:
        registry = _get_registry()
        backend = registry._backend
        if backend is not None:
            backend_name = getattr(backend, "name", type(backend).__name__.lower())
            if hasattr(backend, "is_available"):
                backend_available = backend.is_available()
        # Count running sandboxes
        all_sandboxes = registry.list_all()
        running_count = sum(
            1 for s in all_sandboxes if s.get("state") == "running"
        )
    except Exception:
        running_count = 0
        backend_available = False

    return _ok({
        "status": "healthy",
        "version": __version__,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "backend": backend_name,
        "backend_available": backend_available,
        "sandboxes_running": running_count,
        "uptime_seconds": uptime_seconds,
    })


@api_v1_bp.route("/system/check", methods=["GET"])
@require_api_key
def system_check():
    """System capabilities check."""
    caps: dict[str, Any] = {}

    caps["docker"] = shutil.which("docker") is not None
    caps["podman"] = shutil.which("podman") is not None

    caps["user_ns"] = Path("/proc/self/ns/user").exists()
    caps["mount_ns"] = Path("/proc/self/ns/mnt").exists()
    caps["pid_ns"] = Path("/proc/self/ns/pid").exists()
    caps["net_ns"] = Path("/proc/self/ns/net").exists()

    caps["cgroups_v2"] = Path("/sys/fs/cgroup/cgroup.controllers").exists()

    caps["platform"] = platform.platform()
    caps["python"] = platform.python_version()
    caps["lasso_version"] = __version__

    return _ok(caps)


@api_v1_bp.route("/agents", methods=["GET"])
@require_api_key
def list_agents():
    """List supported AI agent providers and their availability."""
    try:
        from lasso.agents.registry import list_agents as _list_agents
        agents = _list_agents()
    except Exception as exc:
        agents = [{"error": str(exc)}]

    return _ok(agents)


# ---------------------------------------------------------------------------
# OpenAPI / Swagger endpoints
# ---------------------------------------------------------------------------

@api_v1_bp.route("/openapi.json", methods=["GET"])
def openapi_spec():
    """Return the OpenAPI 3.0 specification as JSON."""
    spec = generate_openapi_spec()
    return jsonify(spec)


@api_v1_bp.route("/docs", methods=["GET"])
def swagger_docs():
    """Serve a Swagger UI page pointing at the OpenAPI spec."""
    from flask import Response

    return Response(SWAGGER_UI_HTML, mimetype="text/html")
