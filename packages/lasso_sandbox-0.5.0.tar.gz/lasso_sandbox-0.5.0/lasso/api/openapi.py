"""OpenAPI 3.0 specification generator for the LASSO REST API.

Generates a complete OpenAPI spec as a Python dict and serves it as JSON.
Also provides a Swagger UI HTML page loaded from CDN.

No external dependencies — pure Python dict construction.
"""

from __future__ import annotations

from lasso import __version__


def _error_schema() -> dict:
    """Standard error response schema."""
    return {
        "type": "object",
        "properties": {
            "success": {"type": "boolean", "example": False},
            "data": {"type": "null", "nullable": True},
            "error": {"type": "string", "example": "Something went wrong."},
        },
        "required": ["success", "data", "error"],
    }


def _ok_schema(data_schema: dict) -> dict:
    """Standard success response schema wrapping a data payload."""
    return {
        "type": "object",
        "properties": {
            "success": {"type": "boolean", "example": True},
            "data": data_schema,
            "error": {"type": "null", "nullable": True},
        },
        "required": ["success", "data", "error"],
    }


def _rate_limit_headers() -> dict:
    """Rate limiting response headers."""
    return {
        "X-RateLimit-Limit": {
            "description": "Maximum requests per window",
            "schema": {"type": "integer", "example": 100},
        },
        "X-RateLimit-Remaining": {
            "description": "Remaining requests in current window",
            "schema": {"type": "integer", "example": 97},
        },
        "X-RateLimit-Window": {
            "description": "Window size in seconds",
            "schema": {"type": "integer", "example": 60},
        },
    }


def _sandbox_status_schema() -> dict:
    """Schema for a sandbox status object."""
    return {
        "type": "object",
        "properties": {
            "id": {"type": "string", "example": "a1b2c3d4e5f6"},
            "name": {"type": "string", "example": "minimal"},
            "state": {
                "type": "string",
                "enum": ["created", "configuring", "running", "stopped", "paused", "error"],
                "example": "running",
            },
            "created_at": {"type": "string", "format": "date-time", "example": "2025-06-01T12:00:00+00:00"},
            "working_dir": {"type": "string", "example": "/tmp/lasso-sandbox"},
            "exec_count": {"type": "integer", "example": 5},
            "blocked_count": {"type": "integer", "example": 1},
            "config_hash": {"type": "string", "example": "a1b2c3d4e5f6"},
            "audit_log": {"type": "string", "nullable": True, "example": "/tmp/audit/log.jsonl"},
            "network_mode": {"type": "string", "example": "none"},
            "command_mode": {"type": "string", "example": "whitelist"},
            "backend": {"type": "string", "example": "native"},
            "container_id": {"type": "string", "nullable": True},
        },
    }


def _exec_result_schema() -> dict:
    """Schema for a command execution result."""
    return {
        "type": "object",
        "properties": {
            "command": {"type": "string", "example": "echo hello"},
            "exit_code": {"type": "integer", "example": 0},
            "stdout": {"type": "string", "example": "hello\n"},
            "stderr": {"type": "string", "example": ""},
            "duration_ms": {"type": "integer", "example": 42},
            "blocked": {"type": "boolean", "example": False},
            "block_reason": {"type": "string", "nullable": True},
        },
    }


def _profile_summary_schema() -> dict:
    """Schema for a profile list item."""
    return {
        "type": "object",
        "properties": {
            "name": {"type": "string", "example": "minimal"},
            "description": {"type": "string", "example": "Minimal sandbox with basic commands"},
            "source": {"type": "string", "enum": ["builtin", "saved"], "example": "builtin"},
            "cmd_mode": {"type": "string", "example": "whitelist"},
            "net_mode": {"type": "string", "example": "none"},
            "mem_limit": {"type": "string", "example": "256MB"},
            "tags": {"type": "array", "items": {"type": "string"}, "example": ["minimal"]},
        },
    }


def _audit_entry_schema() -> dict:
    """Schema for an audit log entry."""
    return {
        "type": "object",
        "properties": {
            "type": {"type": "string", "example": "command"},
            "timestamp": {"type": "string", "format": "date-time"},
            "sandbox_id": {"type": "string"},
            "detail": {"type": "object"},
        },
    }


def generate_openapi_spec() -> dict:
    """Generate the complete OpenAPI 3.0 specification as a dict."""

    rl_headers = _rate_limit_headers()

    paths = {
        # --- Health ---
        "/api/v1/health": {
            "get": {
                "operationId": "healthCheck",
                "summary": "Health check",
                "description": "Returns service health status, version, and current timestamp.",
                "tags": ["System"],
                "security": [{"ApiKeyHeader": []}],
                "responses": {
                    "200": {
                        "description": "Service is healthy",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "properties": {
                                        "status": {"type": "string", "example": "healthy"},
                                        "version": {"type": "string", "example": __version__},
                                        "timestamp": {"type": "string", "format": "date-time"},
                                    },
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "429": {
                        "description": "Rate limit exceeded",
                        "headers": rl_headers,
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- System check ---
        "/api/v1/system/check": {
            "get": {
                "operationId": "systemCheck",
                "summary": "System capabilities check",
                "description": "Reports available container runtimes, Linux namespaces, cgroups, and platform info.",
                "tags": ["System"],
                "security": [{"ApiKeyHeader": []}],
                "responses": {
                    "200": {
                        "description": "System capabilities",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "properties": {
                                        "docker": {"type": "boolean", "example": True},
                                        "podman": {"type": "boolean", "example": False},
                                        "user_ns": {"type": "boolean"},
                                        "mount_ns": {"type": "boolean"},
                                        "pid_ns": {"type": "boolean"},
                                        "net_ns": {"type": "boolean"},
                                        "cgroups_v2": {"type": "boolean"},
                                        "platform": {"type": "string", "example": "Linux-6.4.6-x86_64"},
                                        "python": {"type": "string", "example": "3.12.0"},
                                        "lasso_version": {"type": "string", "example": __version__},
                                    },
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Agents ---
        "/api/v1/agents": {
            "get": {
                "operationId": "listAgents",
                "summary": "List supported AI agent providers",
                "description": "Returns all supported agent providers and whether they are available on this system.",
                "tags": ["System"],
                "security": [{"ApiKeyHeader": []}],
                "responses": {
                    "200": {
                        "description": "List of agent providers",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "name": {"type": "string", "example": "claude-code"},
                                            "available": {"type": "boolean", "example": True},
                                        },
                                    },
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Sandboxes: list ---
        "/api/v1/sandboxes": {
            "get": {
                "operationId": "listSandboxes",
                "summary": "List all sandboxes",
                "description": "Returns status objects for every registered sandbox.",
                "tags": ["Sandboxes"],
                "security": [{"ApiKeyHeader": []}],
                "responses": {
                    "200": {
                        "description": "Array of sandbox status objects",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "array",
                                    "items": _sandbox_status_schema(),
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
            "post": {
                "operationId": "createSandbox",
                "summary": "Create a new sandbox",
                "description": "Create and start a sandbox from a named profile and working directory.",
                "tags": ["Sandboxes"],
                "security": [{"ApiKeyHeader": []}],
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "required": ["profile", "working_dir"],
                                "properties": {
                                    "profile": {"type": "string", "example": "minimal"},
                                    "working_dir": {"type": "string", "example": "/tmp/my-sandbox"},
                                },
                            },
                        },
                    },
                },
                "responses": {
                    "201": {
                        "description": "Sandbox created",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema(_sandbox_status_schema()),
                            },
                        },
                    },
                    "400": {
                        "description": "Invalid request (missing fields, path traversal, etc.)",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Profile not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Sandboxes: detail ---
        "/api/v1/sandboxes/{sandbox_id}": {
            "get": {
                "operationId": "getSandbox",
                "summary": "Get sandbox detail",
                "description": "Returns the full status of a specific sandbox by ID.",
                "tags": ["Sandboxes"],
                "security": [{"ApiKeyHeader": []}],
                "parameters": [
                    {
                        "name": "sandbox_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "example": "a1b2c3d4e5f6",
                    },
                ],
                "responses": {
                    "200": {
                        "description": "Sandbox status",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema(_sandbox_status_schema()),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Sandbox not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
            "delete": {
                "operationId": "removeSandbox",
                "summary": "Remove a sandbox",
                "description": "Stop (if running) and remove a sandbox entirely.",
                "tags": ["Sandboxes"],
                "security": [{"ApiKeyHeader": []}],
                "parameters": [
                    {
                        "name": "sandbox_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "example": "a1b2c3d4e5f6",
                    },
                ],
                "responses": {
                    "200": {
                        "description": "Sandbox removed",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "properties": {
                                        "removed": {"type": "string", "example": "a1b2c3d4e5f6"},
                                    },
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Sandbox not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Sandboxes: exec ---
        "/api/v1/sandboxes/{sandbox_id}/exec": {
            "post": {
                "operationId": "execInSandbox",
                "summary": "Execute a command in a sandbox",
                "description": "Run a shell command inside the specified sandbox. The command is validated against the sandbox's command gate policy before execution.",
                "tags": ["Sandboxes"],
                "security": [{"ApiKeyHeader": []}],
                "parameters": [
                    {
                        "name": "sandbox_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "example": "a1b2c3d4e5f6",
                    },
                ],
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "required": ["command"],
                                "properties": {
                                    "command": {
                                        "type": "string",
                                        "example": "echo hello",
                                        "maxLength": 4096,
                                    },
                                },
                            },
                        },
                    },
                },
                "responses": {
                    "200": {
                        "description": "Command executed (check 'blocked' field)",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema(_exec_result_schema()),
                            },
                        },
                    },
                    "400": {
                        "description": "Missing or invalid command",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Sandbox not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "409": {
                        "description": "Sandbox is not in running state",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Sandboxes: stop ---
        "/api/v1/sandboxes/{sandbox_id}/stop": {
            "post": {
                "operationId": "stopSandbox",
                "summary": "Stop a running sandbox",
                "description": "Stop a sandbox. Idempotent - stopping an already-stopped sandbox returns success.",
                "tags": ["Sandboxes"],
                "security": [{"ApiKeyHeader": []}],
                "parameters": [
                    {
                        "name": "sandbox_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "example": "a1b2c3d4e5f6",
                    },
                ],
                "responses": {
                    "200": {
                        "description": "Sandbox stopped",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema(_sandbox_status_schema()),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Sandbox not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Sandboxes: audit ---
        "/api/v1/sandboxes/{sandbox_id}/audit": {
            "get": {
                "operationId": "getAuditEntries",
                "summary": "Get audit log entries for a sandbox",
                "description": "Retrieve audit log entries, optionally filtered by event type and limited by tail count.",
                "tags": ["Audit"],
                "security": [{"ApiKeyHeader": []}],
                "parameters": [
                    {
                        "name": "sandbox_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "example": "a1b2c3d4e5f6",
                    },
                    {
                        "name": "tail",
                        "in": "query",
                        "required": False,
                        "schema": {"type": "integer", "default": 50, "minimum": 0},
                        "description": "Number of entries to return (most recent)",
                    },
                    {
                        "name": "type",
                        "in": "query",
                        "required": False,
                        "schema": {"type": "string", "enum": ["command", "lifecycle", "violation"]},
                        "description": "Filter by event type",
                    },
                ],
                "responses": {
                    "200": {
                        "description": "Audit entries",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "properties": {
                                        "sandbox_id": {"type": "string"},
                                        "entries": {
                                            "type": "array",
                                            "items": _audit_entry_schema(),
                                        },
                                        "count": {"type": "integer", "example": 12},
                                        "log_file": {"type": "string", "nullable": True},
                                    },
                                }),
                            },
                        },
                    },
                    "400": {
                        "description": "Invalid tail parameter",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Sandbox not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Audit: verify ---
        "/api/v1/audit/verify": {
            "post": {
                "operationId": "verifyAuditLog",
                "summary": "Verify audit log integrity",
                "description": "Verify the HMAC chain and hash integrity of an audit log file.",
                "tags": ["Audit"],
                "security": [{"ApiKeyHeader": []}],
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "required": ["log_file"],
                                "properties": {
                                    "log_file": {"type": "string", "example": "/tmp/audit/log.jsonl"},
                                    "key_file": {
                                        "type": "string",
                                        "nullable": True,
                                        "description": "Optional path to HMAC key file",
                                    },
                                },
                            },
                        },
                    },
                },
                "responses": {
                    "200": {
                        "description": "Verification result",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "properties": {
                                        "valid": {"type": "boolean", "example": True},
                                        "total_entries": {"type": "integer", "example": 42},
                                        "verified_entries": {"type": "integer", "example": 42},
                                        "first_break_at": {"type": "integer", "nullable": True},
                                        "errors": {
                                            "type": "array",
                                            "items": {"type": "string"},
                                        },
                                    },
                                }),
                            },
                        },
                    },
                    "400": {
                        "description": "Missing log_file field",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Log file not found on disk",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Profiles: list ---
        "/api/v1/profiles": {
            "get": {
                "operationId": "listProfiles",
                "summary": "List all profiles",
                "description": "Returns all available profiles (builtin + saved).",
                "tags": ["Profiles"],
                "security": [{"ApiKeyHeader": []}],
                "responses": {
                    "200": {
                        "description": "Array of profile summaries",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "array",
                                    "items": _profile_summary_schema(),
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
            "post": {
                "operationId": "createProfile",
                "summary": "Create or update a saved profile",
                "description": "Save a new profile to disk. Cannot overwrite builtin profile names.",
                "tags": ["Profiles"],
                "security": [{"ApiKeyHeader": []}],
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "required": ["name", "filesystem"],
                                "properties": {
                                    "name": {"type": "string", "example": "my-profile"},
                                    "description": {"type": "string", "example": "Custom sandbox profile"},
                                    "filesystem": {
                                        "type": "object",
                                        "properties": {
                                            "working_dir": {"type": "string", "example": "/tmp/sandbox"},
                                        },
                                    },
                                },
                                "additionalProperties": True,
                            },
                        },
                    },
                },
                "responses": {
                    "201": {
                        "description": "Profile created",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "properties": {
                                        "name": {"type": "string", "example": "my-profile"},
                                        "path": {"type": "string"},
                                        "config_hash": {"type": "string"},
                                    },
                                }),
                            },
                        },
                    },
                    "400": {
                        "description": "Invalid profile data",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "409": {
                        "description": "Cannot overwrite builtin profile",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- Profiles: detail ---
        "/api/v1/profiles/{name}": {
            "get": {
                "operationId": "getProfile",
                "summary": "Get profile detail",
                "description": "Returns the full configuration of a profile by name.",
                "tags": ["Profiles"],
                "security": [{"ApiKeyHeader": []}],
                "parameters": [
                    {
                        "name": "name",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "example": "minimal",
                    },
                ],
                "responses": {
                    "200": {
                        "description": "Profile detail",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "description": "Full SandboxProfile object",
                                    "additionalProperties": True,
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Profile not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
            "delete": {
                "operationId": "deleteProfile",
                "summary": "Delete a saved profile",
                "description": "Delete a saved profile from disk. Cannot delete builtin profiles.",
                "tags": ["Profiles"],
                "security": [{"ApiKeyHeader": []}],
                "parameters": [
                    {
                        "name": "name",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "example": "my-profile",
                    },
                ],
                "responses": {
                    "200": {
                        "description": "Profile deleted",
                        "headers": rl_headers,
                        "content": {
                            "application/json": {
                                "schema": _ok_schema({
                                    "type": "object",
                                    "properties": {
                                        "deleted": {"type": "string", "example": "my-profile"},
                                    },
                                }),
                            },
                        },
                    },
                    "401": {
                        "description": "Missing or invalid API key",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "404": {
                        "description": "Profile not found",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                    "409": {
                        "description": "Cannot delete builtin profile",
                        "content": {"application/json": {"schema": _error_schema()}},
                    },
                },
            },
        },
        # --- OpenAPI spec + docs (self-referential) ---
        "/api/v1/openapi.json": {
            "get": {
                "operationId": "getOpenApiSpec",
                "summary": "OpenAPI 3.0 specification",
                "description": "Returns this OpenAPI specification as JSON.",
                "tags": ["Documentation"],
                "responses": {
                    "200": {
                        "description": "OpenAPI 3.0 JSON specification",
                        "content": {"application/json": {"schema": {"type": "object"}}},
                    },
                },
            },
        },
        "/api/v1/docs": {
            "get": {
                "operationId": "swaggerUi",
                "summary": "Swagger UI documentation",
                "description": "Interactive API documentation powered by Swagger UI.",
                "tags": ["Documentation"],
                "responses": {
                    "200": {
                        "description": "HTML page with Swagger UI",
                        "content": {"text/html": {"schema": {"type": "string"}}},
                    },
                },
            },
        },
    }

    spec = {
        "openapi": "3.0.3",
        "info": {
            "title": "LASSO API",
            "description": (
                "Layered Agent Sandbox Security Orchestrator -- "
                "REST API for managing sandboxed AI agent execution environments "
                "with command whitelisting, network isolation, and tamper-evident audit logging."
            ),
            "version": __version__,
            "contact": {"name": "LASSO Project"},
            "license": {"name": "MIT"},
        },
        "servers": [
            {"url": "/", "description": "Current server"},
        ],
        "security": [{"ApiKeyHeader": []}],
        "paths": paths,
        "components": {
            "securitySchemes": {
                "ApiKeyHeader": {
                    "type": "apiKey",
                    "in": "header",
                    "name": "X-API-Key",
                    "description": "API key passed via the X-API-Key request header.",
                },
            },
            "schemas": {
                "ErrorResponse": _error_schema(),
                "SandboxStatus": _sandbox_status_schema(),
                "ExecResult": _exec_result_schema(),
                "ProfileSummary": _profile_summary_schema(),
                "AuditEntry": _audit_entry_schema(),
            },
        },
        "tags": [
            {"name": "Sandboxes", "description": "Create, manage, and execute commands in sandboxes"},
            {"name": "Profiles", "description": "Manage sandbox configuration profiles"},
            {"name": "Audit", "description": "View and verify tamper-evident audit logs"},
            {"name": "System", "description": "Health checks and system capabilities"},
            {"name": "Documentation", "description": "API documentation endpoints"},
        ],
    }

    return spec


SWAGGER_UI_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LASSO API Documentation</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css">
    <style>
        body { margin: 0; padding: 0; background: #1a1a2e; }
        #swagger-ui .topbar { display: none; }
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
    <script>
        SwaggerUIBundle({
            url: "/api/v1/openapi.json",
            dom_id: "#swagger-ui",
            deepLinking: true,
            presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIBundle.SwaggerUIStandalonePreset
            ],
            layout: "BaseLayout"
        });
    </script>
</body>
</html>
"""
