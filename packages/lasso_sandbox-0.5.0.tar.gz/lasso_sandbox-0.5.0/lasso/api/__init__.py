"""LASSO REST API — comprehensive JSON API for sandbox management.

Provides versioned endpoints under /api/v1/ for managing sandboxes,
profiles, audit logs, and system status. All endpoints require API key
authentication and are rate-limited.

Usage:
    from lasso.api import api_v1_bp
    app.register_blueprint(api_v1_bp)
"""

from lasso.api.routes import api_v1_bp

__all__ = ["api_v1_bp"]
