"""Goose agent provider — generates .goosehints and config from LASSO profiles.

Goose (by Block) uses:
  - .goosehints: project-level instruction file (Markdown)
  - goose config files for provider/model settings

LASSO generates the hints file, translating its universal policy into Goose's
native format for defense-in-depth constraint enforcement.
"""

from __future__ import annotations

import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType, generate_guardrails_markdown
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class GooseProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.GOOSE

    @property
    def display_name(self) -> str:
        return "Goose"

    def is_installed(self) -> bool:
        return shutil.which("goose") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["goose", "version"],
                capture_output=True, timeout=5,
            )
            output = result.stdout.decode().strip() or result.stderr.decode().strip()
            return output or None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        hints = self.generate_rules(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files={},
            rules_files={
                ".goosehints": hints,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        return generate_guardrails_markdown(profile, agent_name=self.display_name)

    def get_start_command(self) -> list[str]:
        return ["goose", "session"]

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
