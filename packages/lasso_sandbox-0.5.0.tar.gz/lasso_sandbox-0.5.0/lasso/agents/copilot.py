"""GitHub Copilot agent provider — generates copilot-instructions.md and settings from LASSO profiles.

GitHub Copilot Enterprise runs as an AI coding agent in enterprise environments.
LASSO translates its universal sandbox policy into Copilot's native format:
  - .github/copilot-instructions.md: behavioral guardrail rules
  - .github/copilot-settings.json: allowed/blocked commands and settings

Authentication uses GitHub tokens (GITHUB_TOKEN) and optionally a Copilot
Enterprise organization for license scoping.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType, generate_guardrails_markdown
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class CopilotProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.COPILOT

    @property
    def display_name(self) -> str:
        return "GitHub Copilot"

    def is_installed(self) -> bool:
        """Check if gh CLI is available and the copilot extension is present."""
        if shutil.which("gh") is None:
            return False
        try:
            result = subprocess.run(
                ["gh", "copilot", "--version"],
                capture_output=True, timeout=10,
            )
            return result.returncode == 0
        except Exception:
            return False

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["gh", "copilot", "--version"],
                capture_output=True, timeout=10,
            )
            if result.returncode == 0:
                output = result.stdout.decode().strip()
                return output if output else result.stderr.decode().strip()
            return None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        settings = self._build_settings(profile)
        instructions = self.generate_rules(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files={
                ".github/copilot-settings.json": json.dumps(settings, indent=2),
            },
            rules_files={
                ".github/copilot-instructions.md": instructions,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        """Generate .github/copilot-instructions.md with LASSO guardrails."""
        return generate_guardrails_markdown(profile, agent_name=self.display_name)

    def get_start_command(self) -> list[str]:
        return ["gh", "copilot"]

    def _build_settings(self, profile: SandboxProfile) -> dict:
        """Build .github/copilot-settings.json from a LASSO profile."""
        settings: dict = {
            "lasso": {
                "profile": profile.name,
                "sandbox": True,
            },
            "commands": self._build_command_policy(profile),
            "network": {
                "mode": profile.network.mode.value,
            },
        }

        # Add allowed domains for restricted mode
        if profile.network.mode == NetworkMode.RESTRICTED:
            settings["network"]["allowed_domains"] = profile.network.allowed_domains

        # Add org settings if agent_auth is configured
        if profile.agent_auth and profile.agent_auth.copilot_org:
            settings["github"] = {
                "organization": profile.agent_auth.copilot_org,
                "token_env": profile.agent_auth.github_token_env,
            }

        return settings

    def _build_command_policy(self, profile: SandboxProfile) -> dict:
        """Translate LASSO command policy to Copilot's command format."""
        policy: dict = {
            "mode": profile.commands.mode.value,
        }

        if profile.commands.mode == CommandMode.WHITELIST:
            policy["allowed"] = sorted(profile.commands.whitelist)
        else:
            policy["blocked"] = sorted(profile.commands.blacklist)

        # Blocked argument patterns
        if profile.commands.blocked_args:
            blocked_patterns = []
            for cmd, patterns in profile.commands.blocked_args.items():
                for p in patterns:
                    blocked_patterns.append(f"{cmd} {p}")
            policy["blocked_patterns"] = blocked_patterns

        return policy

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        env = {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }

        # Pass through GitHub token env var name
        if profile.agent_auth:
            env["GITHUB_TOKEN_ENV"] = profile.agent_auth.github_token_env
            if profile.agent_auth.copilot_org:
                env["COPILOT_ORG"] = profile.agent_auth.copilot_org

        return env
