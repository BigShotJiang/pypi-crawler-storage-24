"""OpenAI Codex CLI agent provider — generates AGENTS.md and config from LASSO profiles.

OpenAI Codex CLI uses:
  - AGENTS.md: project-level instruction file (standard across many agents)
  - codex.json or CLI flags for configuration
  - Sandbox modes: full-auto, suggest, ask

LASSO generates the instruction file, translating its universal policy into
Codex's native format for defense-in-depth constraint enforcement.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType, generate_guardrails_markdown
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class CodexProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.CODEX

    @property
    def display_name(self) -> str:
        return "OpenAI Codex CLI"

    def is_installed(self) -> bool:
        return shutil.which("codex") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["codex", "--version"],
                capture_output=True, timeout=5,
            )
            return result.stdout.decode().strip() or result.stderr.decode().strip() or None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        agents_md = self.generate_rules(profile)
        config = self._build_codex_config(profile)

        config_files = {}
        if config:
            config_files["codex.json"] = json.dumps(config, indent=2)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files=config_files,
            rules_files={
                "AGENTS.md": agents_md,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        return generate_guardrails_markdown(profile, agent_name=self.display_name)

    def get_start_command(self) -> list[str]:
        return ["codex"]

    def _build_codex_config(self, profile: SandboxProfile) -> dict:
        """Build codex.json config from a LASSO profile."""
        config: dict = {
            "lasso": {
                "profile": profile.name,
                "sandbox": True,
            },
            "instructions": ["AGENTS.md"],
        }

        if profile.network.mode == NetworkMode.NONE:
            config["sandbox_mode"] = "full-auto"
            config["network"] = False

        return config

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
