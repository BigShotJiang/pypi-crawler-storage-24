"""Aider agent provider — generates .aider.conf.yml and convention files from LASSO profiles.

Aider uses:
  - .aider.conf.yml: YAML config with model, edit format, and settings
  - CONVENTIONS.md: project-level instructions the agent follows
  - CLI flags for runtime behavior

LASSO generates both files, translating its universal policy into Aider's
native format. This is defense-in-depth — even if Aider allows a command,
the container's command gate still blocks it.
"""

from __future__ import annotations

import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType, generate_guardrails_markdown
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class AiderProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.AIDER

    @property
    def display_name(self) -> str:
        return "Aider"

    def is_installed(self) -> bool:
        return shutil.which("aider") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["aider", "--version"],
                capture_output=True, timeout=5,
            )
            return result.stdout.decode().strip() or result.stderr.decode().strip() or None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        conventions = self.generate_rules(profile)
        aider_conf = self._build_aider_conf(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files={
                ".aider.conf.yml": aider_conf,
            },
            rules_files={
                "CONVENTIONS.md": conventions,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        return generate_guardrails_markdown(profile, agent_name=self.display_name)

    def get_start_command(self) -> list[str]:
        return ["aider"]

    def _build_aider_conf(self, profile: SandboxProfile) -> str:
        """Build .aider.conf.yml content."""
        lines = [
            "# LASSO-generated Aider configuration",
            f"# Profile: {profile.name}",
            "",
            "# Read CONVENTIONS.md for sandbox rules",
            "read: [CONVENTIONS.md]",
            "",
            "# Disable auto-commits in sandbox (audit trail handles tracking)",
            "auto-commits: false",
            "",
            "# Disable linting in sandbox (may invoke disallowed commands)",
            "lint: false",
            "auto-lint: false",
            "",
            "# Disable auto-test (may invoke disallowed commands)",
            "auto-test: false",
            "",
            "# No browser opening in sandbox",
            "no-show-model-warnings: true",
            "",
        ]

        if profile.network.mode == NetworkMode.NONE:
            lines.append("# No network — use local model or pre-configured API")
            lines.append("no-auto-update: true")
            lines.append("")

        return "\n".join(lines)

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
