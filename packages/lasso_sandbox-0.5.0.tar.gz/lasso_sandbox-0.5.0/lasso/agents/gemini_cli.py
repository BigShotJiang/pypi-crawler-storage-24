"""Gemini CLI agent provider — generates GEMINI.md and settings from LASSO profiles.

Google's Gemini CLI uses:
  - GEMINI.md: project-level instruction file (like CLAUDE.md)
  - .gemini/settings.json: tool permissions and configuration

LASSO generates the instruction file and settings, translating its universal
policy into Gemini CLI's native format for defense-in-depth.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType, generate_guardrails_markdown
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class GeminiCLIProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.GEMINI_CLI

    @property
    def display_name(self) -> str:
        return "Gemini CLI"

    def is_installed(self) -> bool:
        return shutil.which("gemini") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["gemini", "--version"],
                capture_output=True, timeout=5,
            )
            return result.stdout.decode().strip() or result.stderr.decode().strip() or None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        gemini_md = self.generate_rules(profile)
        settings = self._build_settings(profile)

        config_files = {}
        if settings:
            config_files[".gemini/settings.json"] = json.dumps(settings, indent=2)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files=config_files,
            rules_files={
                "GEMINI.md": gemini_md,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        return generate_guardrails_markdown(profile, agent_name=self.display_name)

    def get_start_command(self) -> list[str]:
        return ["gemini"]

    def _build_settings(self, profile: SandboxProfile) -> dict:
        """Build .gemini/settings.json from a LASSO profile."""
        settings: dict = {
            "lasso": {
                "profile": profile.name,
                "sandbox": True,
            },
        }

        if profile.network.mode == NetworkMode.NONE:
            settings["sandboxed"] = True

        return settings

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
