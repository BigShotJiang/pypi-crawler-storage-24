"""Cursor agent provider — generates .cursor/rules and settings from LASSO profiles.

Cursor uses:
  - .cursor/rules/: directory of rule files (or legacy .cursorrules)
  - .cursor/settings.json: workspace-level settings
  - Instruction files are plain text/markdown

LASSO generates a rules file that enforces sandbox constraints within Cursor's
native permission model. This is defense-in-depth — even if Cursor allows a
command, the container's command gate still blocks it.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType, generate_guardrails_markdown
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class CursorProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.CURSOR

    @property
    def display_name(self) -> str:
        return "Cursor"

    def is_installed(self) -> bool:
        return shutil.which("cursor") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["cursor", "--version"],
                capture_output=True, timeout=5,
            )
            if result.returncode == 0:
                lines = result.stdout.decode().strip().splitlines()
                return lines[0] if lines else None
            return None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        rules_content = self.generate_rules(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files={},
            rules_files={
                ".cursor/rules/lasso-sandbox.mdc": self._build_mdc_rule(rules_content),
                ".cursorrules": rules_content,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        return generate_guardrails_markdown(profile, agent_name=self.display_name)

    def get_start_command(self) -> list[str]:
        return ["cursor", "."]

    def _build_mdc_rule(self, rules_content: str) -> str:
        """Build a Cursor .mdc rule file with frontmatter."""
        return (
            "---\n"
            "description: LASSO sandbox security constraints\n"
            "globs: **/*\n"
            "alwaysApply: true\n"
            "---\n\n"
            + rules_content
        )

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
