"""Built-in default profiles for common use cases.

Profiles are general-purpose but designed to meet the strictness
requirements of regulated environments (banking, healthcare, government).
"""

from lasso.config.schema import (
    AuditConfig,
    CommandConfig,
    CommandMode,
    FilesystemConfig,
    GitRepoAccessConfig,
    GuardrailsConfig,
    MCPSecurityConfig,
    NetworkConfig,
    NetworkMode,
    ProfileMode,
    ResourceConfig,
    SandboxProfile,
)


def minimal_profile(working_dir: str, name: str = "minimal") -> SandboxProfile:
    """Minimal sandbox — tight restrictions, no network, small resource limits.

    Use for: pure computation, offline scripting, untrusted agent evaluation.
    """
    return SandboxProfile(
        name=name,
        description="Minimal sandbox: no network, strict whitelist, low resources. "
        "Suitable for pure computation and untrusted agent evaluation.",
        tags=["secure", "offline"],
        mode=ProfileMode.OBSERVE,
        filesystem=FilesystemConfig(working_dir=working_dir),
        commands=CommandConfig(
            mode=CommandMode.WHITELIST,
            whitelist=["ls", "cat", "head", "tail", "grep", "wc", "echo", "test"],
            allow_shell_operators=False,
        ),
        network=NetworkConfig(mode=NetworkMode.NONE),
        resources=ResourceConfig(max_memory_mb=512, max_cpu_percent=25, max_pids=50),
        mcp_security=MCPSecurityConfig(enabled=False),
    )


def development_profile(working_dir: str, name: str = "development") -> SandboxProfile:
    """Developer sandbox — broader commands, restricted network, moderate resources.

    Use for: general coding tasks, building projects, running tests.
    Network is restricted to package registries and source hosting.
    """
    return SandboxProfile(
        name=name,
        description="Developer sandbox: common dev tools, restricted network "
        "for package managers and source hosting.",
        tags=["development", "coding"],
        mode=ProfileMode.ASSIST,
        filesystem=FilesystemConfig(working_dir=working_dir),
        commands=CommandConfig(
            mode=CommandMode.WHITELIST,
            whitelist=[
                "python3", "python", "pip", "pip3", "git", "node", "npm", "npx",
                "ls", "cat", "head", "tail", "grep", "find", "wc", "sort", "uniq",
                "diff", "mkdir", "cp", "mv", "touch", "echo", "printf", "test",
                "curl", "wget", "tar", "gzip", "gunzip", "zip", "unzip",
                "make", "cmake", "gcc", "g++", "rustc", "cargo",
            ],
            allow_shell_operators=True,
        ),
        network=NetworkConfig(
            mode=NetworkMode.RESTRICTED,
            allowed_domains=[
                "pypi.org", "files.pythonhosted.org",
                "registry.npmjs.org",
                "github.com", "api.github.com",
                "crates.io",
            ],
            allowed_ports=[80, 443],
        ),
        resources=ResourceConfig(max_memory_mb=4096, max_cpu_percent=75, max_pids=200),
        mcp_security=MCPSecurityConfig(enabled=True, allow_shell_execution=False),
    )


def offline_profile(working_dir: str, name: str = "offline") -> SandboxProfile:
    """Offline sandbox — Python/R data tools, no network, full audit trail.

    Use for: data science, analytics, report generation, model evaluation.
    No network access prevents data exfiltration. Full audit trail for
    compliance with DORA, ISO 27001, EU AI Act, HIPAA, SOC 2.
    """
    return SandboxProfile(
        name=name,
        description="Offline sandbox: Python, R, and data tools with no network "
        "access and full audit trail. Meets compliance requirements for "
        "regulated environments.",
        tags=["offline", "isolated", "compliance"],
        mode=ProfileMode.OBSERVE,
        filesystem=FilesystemConfig(
            working_dir=working_dir,
            hidden_paths=[
                "/etc/shadow", "/etc/gshadow", "/root",
                "/etc/ssh", "/etc/ssl/private",
            ],
            max_disk_mb=20480,
        ),
        commands=CommandConfig(
            mode=CommandMode.WHITELIST,
            whitelist=[
                "python3", "python", "pip", "pip3",
                "Rscript", "R",
                "jupyter", "jupyter-lab",
                "ls", "cat", "head", "tail", "grep", "find", "wc",
                "sort", "uniq", "diff", "mkdir", "cp", "mv", "touch",
            ],
            blocked_args={
                "pip": ["install --user", "install -e"],
                "git": ["push", "remote add"],
            },
            allow_shell_operators=False,
            max_execution_seconds=600,
        ),
        network=NetworkConfig(mode=NetworkMode.NONE),
        resources=ResourceConfig(
            max_memory_mb=8192,
            max_cpu_percent=50,
            max_pids=150,
        ),
        guardrails=GuardrailsConfig(enforce=True),
        audit=AuditConfig(
            enabled=True,
            include_command_output=True,
            include_file_diffs=True,
            sign_entries=True,
        ),
        mcp_security=MCPSecurityConfig(enabled=False),
    )


def strict_profile(working_dir: str, name: str = "strict") -> SandboxProfile:
    """Risk analysis team sandbox — Python, R, Git (restricted), no network, full audit.

    Use for: bank risk/analytics teams using OpenCode with GitHub Copilot Enterprise.
    Git history content (log --patch, diff, show) is blocked to prevent PII exposure
    from commit diffs. Database access is blocked at command and network levels.
    Full audit trail with HMAC signing for DORA/ISO 27001 compliance.
    """
    return SandboxProfile(
        name=name,
        description=(
            "Strict isolation profile: Python, R, and Git with no network access. "
            "Database access blocked at command and network levels. "
            "Git log/diff content restricted to prevent PII exposure. "
            "Full audit trail."
        ),
        tags=["strict", "pii-protection", "compliance"],
        mode=ProfileMode.OBSERVE,
        filesystem=FilesystemConfig(
            working_dir=working_dir,
            hidden_paths=[
                "/etc/shadow", "/etc/gshadow", "/root",
                "/etc/ssh", "/etc/ssl/private",
            ],
            max_disk_mb=20480,
        ),
        commands=CommandConfig(
            mode=CommandMode.WHITELIST,
            whitelist=[
                "python3", "pip", "git",
                "ls", "cat", "head", "tail", "grep", "find",
                "wc", "sort", "uniq", "diff",
                "mkdir", "cp", "mv", "touch", "echo", "test",
                "Rscript", "R", "jupyter",
            ],
            blocked_args={
                "git": [
                    "push", "push --force",
                    "remote add", "remote set-url",
                    "log -p", "log --patch",
                    "diff", "show",
                ],
                "pip": ["install --user", "install -e"],
            },
            allow_shell_operators=False,
            max_execution_seconds=600,
        ),
        network=NetworkConfig(mode=NetworkMode.NONE),
        resources=ResourceConfig(
            max_memory_mb=8192,
            max_cpu_percent=50,
            max_pids=150,
        ),
        guardrails=GuardrailsConfig(enforce=True),
        audit=AuditConfig(
            enabled=True,
            include_command_output=True,
            include_file_diffs=True,
            sign_entries=True,
        ),
        git_access=GitRepoAccessConfig(
            access_mode="read",
            block_git_history_content=True,
        ),
    )


# Backward compatibility alias
def banking_analysis_profile(working_dir: str, name: str = "bank-analysis") -> SandboxProfile:
    """Alias for offline_profile — backward compatibility."""
    return offline_profile(working_dir, name=name)


BUILTIN_PROFILES = {
    "minimal": minimal_profile,
    "development": development_profile,
    "offline": offline_profile,
    "strict": strict_profile,
    "bank-analysis": banking_analysis_profile,
}
