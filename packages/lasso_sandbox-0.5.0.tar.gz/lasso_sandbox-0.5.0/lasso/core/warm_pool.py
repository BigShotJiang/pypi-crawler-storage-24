"""Warm pool — pre-created containers for sub-500ms sandbox creation.

Instead of the full create cycle (resolve profile -> build image -> create
container -> start container -> apply network rules), the warm pool keeps
N standby containers per profile that are already created and started.

When a sandbox is requested, the pool returns a ready container instantly.
Replenishment happens on background daemon threads so the pool stays warm.
"""

from __future__ import annotations

import logging
import threading
import uuid
from dataclasses import dataclass, field
from typing import Optional

from lasso.backends.base import ContainerBackend, ContainerState
from lasso.backends.converter import profile_to_container_config
from lasso.config.schema import SandboxProfile

logger = logging.getLogger("lasso.warm_pool")


@dataclass
class _WarmContainer:
    """Metadata for a pre-warmed container sitting in the pool."""
    container_id: str
    profile_name: str
    image_tag: str


class WarmPool:
    """Pre-creates standby containers for common profiles.

    Keeps ``pool_size`` containers per profile in a "warm" state (created
    and started, running ``sleep infinity``).  When ``claim()`` is called,
    a warm container is popped from the pool and returned immediately,
    bypassing the expensive image-build and container-create steps.

    Thread-safe: all pool mutations are protected by a lock.
    """

    def __init__(
        self,
        backend: ContainerBackend,
        pool_size: int = 2,
        profiles: Optional[list[str]] = None,
    ):
        """
        Args:
            backend: The container backend to create warm containers on.
            pool_size: Number of warm containers to maintain per profile.
            profiles: Profile names to pre-warm.  ``None`` means all builtins.
        """
        self._backend = backend
        self._pool_size = max(0, min(pool_size, 10))
        self._profile_names = profiles

        # pool_name -> list of warm containers (LIFO for cache locality)
        self._pool: dict[str, list[_WarmContainer]] = {}
        # Tracks total containers created per profile (for stats)
        self._total_created: dict[str, int] = {}
        self._total_claimed: dict[str, int] = {}

        self._lock = threading.Lock()
        self._shutdown_event = threading.Event()

        # Resolved profiles cache: profile_name -> SandboxProfile
        self._resolved_profiles: dict[str, SandboxProfile] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def warmup(self, resolved_profiles: Optional[dict[str, SandboxProfile]] = None) -> None:
        """Pre-warm all configured profiles.

        Args:
            resolved_profiles: Mapping of profile_name -> SandboxProfile.
                If not provided, uses builtin profiles with a temp working dir.
        """
        if not self._backend or not self._backend.is_available():
            logger.debug("Backend not available; warm pool disabled.")
            return

        if self._pool_size == 0:
            return

        profiles = self._resolve_profiles(resolved_profiles)

        for name, profile in profiles.items():
            self._resolved_profiles[name] = profile
            with self._lock:
                if name not in self._pool:
                    self._pool[name] = []
                    self._total_created[name] = 0
                    self._total_claimed[name] = 0

            current = self._pool_count(name)
            needed = self._pool_size - current
            for _ in range(needed):
                if self._shutdown_event.is_set():
                    return
                self._create_warm_container(name, profile)

        logger.info(
            "Warm pool ready: %s",
            {name: self._pool_count(name) for name in profiles},
        )

    def claim(self, profile_name: str) -> Optional[str]:
        """Claim a warm container for this profile.

        Returns the container_id if a warm container was available,
        or ``None`` if the pool is empty for this profile (caller
        should fall back to the normal creation path).
        """
        with self._lock:
            containers = self._pool.get(profile_name, [])
            if not containers:
                return None

            warm = containers.pop()
            self._total_claimed.setdefault(profile_name, 0)
            self._total_claimed[profile_name] += 1

        logger.info(
            "Claimed warm container %s for profile '%s' (%d remaining)",
            warm.container_id[:12],
            profile_name,
            self._pool_count(profile_name),
        )

        return warm.container_id

    def replenish(self, profile_name: str) -> None:
        """Replenish the pool for a profile on a background daemon thread.

        Safe to call multiple times; extra calls are idempotent if the
        pool is already at capacity.
        """
        if self._shutdown_event.is_set():
            return

        profile = self._resolved_profiles.get(profile_name)
        if profile is None:
            logger.debug("No resolved profile for '%s'; cannot replenish.", profile_name)
            return

        thread = threading.Thread(
            target=self._replenish_sync,
            args=(profile_name, profile),
            daemon=True,
            name=f"lasso-warmpool-replenish-{profile_name}",
        )
        thread.start()

    def shutdown(self) -> None:
        """Stop and remove all warm containers.

        Signals background threads to stop, then cleans up every container
        still in the pool.
        """
        self._shutdown_event.set()

        with self._lock:
            all_containers: list[_WarmContainer] = []
            for containers in self._pool.values():
                all_containers.extend(containers)
                containers.clear()

        for warm in all_containers:
            try:
                self._backend.stop(warm.container_id)
                self._backend.remove(warm.container_id)
                logger.debug("Removed warm container %s", warm.container_id[:12])
            except Exception as e:
                logger.warning(
                    "Failed to clean up warm container %s: %s",
                    warm.container_id[:12], e,
                )

        logger.info("Warm pool shut down; removed %d containers.", len(all_containers))

    @property
    def stats(self) -> dict[str, dict[str, int]]:
        """Return pool statistics per profile.

        Returns::

            {
                "minimal": {"available": 2, "total_created": 4, "total_claimed": 2},
                ...
            }
        """
        with self._lock:
            result = {}
            for name in set(list(self._pool.keys()) + list(self._total_created.keys())):
                result[name] = {
                    "available": len(self._pool.get(name, [])),
                    "total_created": self._total_created.get(name, 0),
                    "total_claimed": self._total_claimed.get(name, 0),
                }
            return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _pool_count(self, profile_name: str) -> int:
        """Return number of available warm containers for a profile (lock-free read)."""
        with self._lock:
            return len(self._pool.get(profile_name, []))

    def _create_warm_container(self, profile_name: str, profile: SandboxProfile) -> Optional[str]:
        """Create and start a single warm container.

        Returns the container_id on success, None on failure.
        """
        try:
            # Ensure image exists
            from lasso.backends.image_builder import ensure_image
            image_tag = ensure_image(self._backend, profile)

            # Build container config
            config = profile_to_container_config(profile)
            warm_id = uuid.uuid4().hex[:12]
            config.name = f"lasso-warm-{profile_name}-{warm_id}"
            config.image = image_tag

            # Create and start
            container_id = self._backend.create(config)
            self._backend.start(container_id)

            warm = _WarmContainer(
                container_id=container_id,
                profile_name=profile_name,
                image_tag=image_tag,
            )

            with self._lock:
                self._pool.setdefault(profile_name, []).append(warm)
                self._total_created.setdefault(profile_name, 0)
                self._total_created[profile_name] += 1

            logger.debug(
                "Created warm container %s for profile '%s'",
                container_id[:12], profile_name,
            )
            return container_id

        except Exception as e:
            logger.warning(
                "Failed to create warm container for profile '%s': %s",
                profile_name, e,
            )
            return None

    def _replenish_sync(self, profile_name: str, profile: SandboxProfile) -> None:
        """Synchronous replenishment (runs on background thread)."""
        current = self._pool_count(profile_name)
        needed = self._pool_size - current

        for _ in range(needed):
            if self._shutdown_event.is_set():
                return
            self._create_warm_container(profile_name, profile)

    def _resolve_profiles(
        self, resolved_profiles: Optional[dict[str, SandboxProfile]] = None,
    ) -> dict[str, SandboxProfile]:
        """Resolve which profiles to warm.

        If ``resolved_profiles`` is provided, filter to configured names.
        Otherwise, load builtins.
        """
        if resolved_profiles:
            if self._profile_names:
                return {k: v for k, v in resolved_profiles.items() if k in self._profile_names}
            return resolved_profiles

        # Fall back to builtins
        import tempfile
        from lasso.config.defaults import BUILTIN_PROFILES

        names = self._profile_names or list(BUILTIN_PROFILES.keys())
        result = {}
        for name in names:
            factory = BUILTIN_PROFILES.get(name)
            if factory:
                tmp = tempfile.mkdtemp(prefix=f"lasso-warm-{name}-")
                result[name] = factory(tmp)
        return result
