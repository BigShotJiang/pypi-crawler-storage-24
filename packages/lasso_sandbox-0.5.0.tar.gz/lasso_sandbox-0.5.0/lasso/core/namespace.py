"""Linux namespace management — the foundation of sandbox isolation.

Uses unshare(1) to create isolated mount, PID, network, and user
namespaces. Manages bind mounts for filesystem views and tmpfs
for ephemeral storage.
"""

from __future__ import annotations

import logging
import os
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

from lasso.config.schema import FilesystemConfig

logger = logging.getLogger("lasso.namespace")

_IS_LINUX = platform.system() == "Linux"


class NamespaceError(Exception):
    """Raised when namespace operations fail."""


class SandboxFilesystem:
    """Manages the filesystem view for a sandbox.

    Creates an overlay/bind-mount based rootfs that provides:
    - Read-only system paths
    - Read-write working directory
    - Hidden sensitive paths
    - Isolated /tmp
    """

    def __init__(self, sandbox_id: str, fs_config: FilesystemConfig):
        self.sandbox_id = sandbox_id
        self.config = fs_config
        self.rootfs: Optional[Path] = None
        self._temp_dir: Optional[Path] = None

    def prepare(self) -> Path:
        """Create the sandbox rootfs directory structure.

        Returns the path to the rootfs that will be used as the new root.
        """
        self._temp_dir = Path(tempfile.mkdtemp(prefix=f"lasso-{self.sandbox_id}-"))
        self.rootfs = self._temp_dir / "rootfs"
        self.rootfs.mkdir()

        # Create essential directories
        for d in ["proc", "sys", "dev", "tmp", "etc", "usr", "bin", "sbin",
                   "lib", "lib64", "home", "var", "run"]:
            (self.rootfs / d).mkdir(exist_ok=True)

        return self.rootfs

    def get_mount_commands(self) -> list[list[str]]:
        """Generate the sequence of mount commands needed inside the namespace.

        These are executed after unshare --mount to build the filesystem view.
        """
        if not self.rootfs:
            raise NamespaceError("Call prepare() first")

        commands: list[list[str]] = []

        # Bind-mount read-only system paths
        for ro_path in self.config.read_only_paths:
            if Path(ro_path).exists():
                target = self.rootfs / ro_path.lstrip("/")
                target.mkdir(parents=True, exist_ok=True)
                commands.append([
                    "mount", "--bind", "-o", "ro", ro_path, str(target),
                ])

        # Bind-mount writable paths
        for rw_path in [self.config.working_dir] + self.config.writable_paths:
            source = Path(rw_path)
            if source.exists():
                target = self.rootfs / rw_path.lstrip("/")
                target.mkdir(parents=True, exist_ok=True)
                commands.append([
                    "mount", "--bind", rw_path, str(target),
                ])

        # Mount tmpfs for /tmp
        tmp_target = self.rootfs / "tmp"
        tmp_target.mkdir(exist_ok=True)
        commands.append([
            "mount", "-t", "tmpfs",
            "-o", f"size={self.config.temp_dir_mb}m,mode=1777",
            "tmpfs", str(tmp_target),
        ])

        # Mount proc
        proc_target = self.rootfs / "proc"
        proc_target.mkdir(exist_ok=True)
        commands.append([
            "mount", "-t", "proc", "proc", str(proc_target),
        ])

        return commands

    def get_unshare_command(self, inner_command: list[str]) -> list[str]:
        """Build the full unshare command that creates the sandbox.

        This creates mount + PID + user namespaces and executes inner_command
        inside the isolated environment.
        """
        working_dir = self.config.working_dir

        # Base unshare flags:
        # --mount    : new mount namespace
        # --pid      : new PID namespace (agent can't see host processes)
        # --fork     : fork before exec (required for PID namespace)
        # --map-root-user : map current user to root inside namespace
        cmd = [
            "unshare",
            "--mount",
            "--pid",
            "--fork",
            "--map-root-user",
        ]

        cmd.append("--")
        cmd.extend(inner_command)
        return cmd

    def cleanup(self) -> None:
        """Remove the temporary rootfs.

        On Windows, read-only files prevent rmtree from deleting. We use
        an onerror handler that clears the read-only attribute and retries.
        """
        if self._temp_dir and self._temp_dir.exists():
            # Best-effort cleanup — mounts may prevent immediate removal
            try:
                shutil.rmtree(self._temp_dir, onerror=_rmtree_onerror)
            except Exception:
                pass


def _rmtree_onerror(func, path, exc_info):
    """Handle permission errors during shutil.rmtree on Windows.

    Windows marks some files as read-only which prevents deletion.
    This handler clears the read-only flag and retries the removal.
    """
    try:
        os.chmod(path, 0o777)
        func(path)
    except OSError:
        pass


class NamespaceManager:
    """Creates and manages Linux namespaces for sandbox isolation."""

    @staticmethod
    def check_capabilities() -> dict[str, bool]:
        """Check what namespace capabilities are available."""
        if not _IS_LINUX:
            logger.debug("Namespace capabilities not available on %s", platform.system())
            return {
                "user_ns": False,
                "mount_ns": False,
                "pid_ns": False,
                "net_ns": False,
                "cgroups_v2": False,
            }

        caps = {}

        # Check unprivileged user namespaces
        try:
            result = subprocess.run(
                ["unshare", "--user", "--", "id"],
                capture_output=True, timeout=5,
            )
            caps["user_ns"] = result.returncode == 0
        except Exception as e:
            logger.debug("user_ns check failed: %s", e)
            caps["user_ns"] = False

        # Check mount namespace (needs user ns or root)
        try:
            result = subprocess.run(
                ["unshare", "--user", "--mount", "--", "ls", "/"],
                capture_output=True, timeout=5,
            )
            caps["mount_ns"] = result.returncode == 0
        except Exception as e:
            logger.debug("mount_ns check failed: %s", e)
            caps["mount_ns"] = False

        # Check PID namespace
        try:
            result = subprocess.run(
                ["unshare", "--user", "--pid", "--fork", "--", "echo", "ok"],
                capture_output=True, timeout=5,
            )
            caps["pid_ns"] = result.returncode == 0
        except Exception as e:
            logger.debug("pid_ns check failed: %s", e)
            caps["pid_ns"] = False

        # Check network namespace
        try:
            result = subprocess.run(
                ["unshare", "--user", "--net", "--", "ip", "link"],
                capture_output=True, timeout=5,
            )
            caps["net_ns"] = result.returncode == 0
        except Exception as e:
            logger.debug("net_ns check failed: %s", e)
            caps["net_ns"] = False

        # Check cgroups v2
        caps["cgroups_v2"] = Path("/sys/fs/cgroup/cgroup.controllers").exists()

        return caps

    @staticmethod
    def create_network_namespace(sandbox_id: str) -> str:
        """Create a named network namespace. Returns the netns name."""
        if not _IS_LINUX:
            raise NamespaceError("Network namespaces are only available on Linux")
        ns_name = f"lasso-{sandbox_id[:8]}"
        subprocess.run(
            ["ip", "netns", "add", ns_name],
            check=True, capture_output=True,
        )
        return ns_name

    @staticmethod
    def delete_network_namespace(ns_name: str) -> None:
        """Remove a named network namespace."""
        if not _IS_LINUX:
            return
        subprocess.run(
            ["ip", "netns", "delete", ns_name],
            capture_output=True,
        )
