"""Compliance reporting -- generate framework-mapped evidence reports from audit logs.

Produces structured compliance reports that map LASSO audit evidence to
regulatory requirements (DORA, EU AI Act). Reports are designed for bank
auditors and compliance officers -- each article is mapped to specific
LASSO controls with evidence counts from the audit trail.

Supported frameworks:
    - dora: Regulation (EU) 2022/2554 (Digital Operational Resilience Act)
    - eu-ai-act: Regulation (EU) 2024/1689 (Artificial Intelligence Act)
"""

from __future__ import annotations

import json
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from lasso import __version__
from lasso.config.defaults import BUILTIN_PROFILES
from lasso.config.profile import load_profile
from lasso.config.schema import SandboxProfile
from lasso.core.audit_verify import read_audit_entries, verify_audit_log


# ---------------------------------------------------------------------------
# Framework article definitions
# ---------------------------------------------------------------------------

@dataclass
class FrameworkArticle:
    """A single article/requirement in a regulatory framework."""
    number: str
    title: str
    requirement: str
    lasso_control: str
    relevant_event_types: list[str] = field(default_factory=list)
    relevant_outcomes: list[str] = field(default_factory=list)
    relevant_actions: list[str] = field(default_factory=list)


# DORA articles -- from docs/compliance/DORA-mapping.md
DORA_ARTICLES = [
    FrameworkArticle(
        number="Art. 5-6",
        title="ICT Risk Management Framework",
        requirement=(
            "Financial entities shall have in place an internal governance and "
            "control framework that ensures effective and prudent management of "
            "all ICT risks, including identification, protection, detection, "
            "response, and recovery."
        ),
        lasso_control=(
            "Profile-based policy enforcement: command whitelisting, network "
            "isolation, resource limits, and versioned configuration with "
            "deterministic config_hash for policy integrity verification."
        ),
        relevant_event_types=["lifecycle", "command"],
        relevant_outcomes=["success", "blocked"],
        relevant_actions=["start", "stop", "running"],
    ),
    FrameworkArticle(
        number="Art. 9",
        title="Protection and Prevention",
        requirement=(
            "Financial entities shall use and maintain updated ICT systems, "
            "protocols, and tools that are appropriate to the scale and "
            "complexity of their operations and that implement adequate "
            "measures to protect ICT assets."
        ),
        lasso_control=(
            "Defense-in-depth: command gate with whitelist/blacklist, blocked "
            "argument patterns, dangerous argument detection, shell operator "
            "restrictions, path traversal detection, container isolation with "
            "filesystem restrictions, and network policy enforcement."
        ),
        relevant_event_types=["command", "violation"],
        relevant_outcomes=["blocked"],
    ),
    FrameworkArticle(
        number="Art. 10",
        title="Detection",
        requirement=(
            "Financial entities shall have in place mechanisms to promptly "
            "detect anomalous activities, including ICT network performance "
            "issues and ICT-related incidents."
        ),
        lasso_control=(
            "Audit logging of every sandbox action: command executions, blocked "
            "commands, file access, network connections, and guardrail violations. "
            "Tamper-evident HMAC-SHA256 hash chain with independent verification."
        ),
        relevant_event_types=["command", "violation", "file", "network"],
        relevant_outcomes=["blocked", "error"],
    ),
    FrameworkArticle(
        number="Art. 11",
        title="Response and Recovery",
        requirement=(
            "Financial entities shall put in place a comprehensive ICT "
            "business continuity policy, including response and recovery plans."
        ),
        lasso_control=(
            "Controlled sandbox lifecycle: clean shutdown with audit logging, "
            "state persistence via StateStore, reconciliation on restart, "
            "context manager support for exception-safe cleanup."
        ),
        relevant_event_types=["lifecycle"],
        relevant_actions=["start", "stop", "running", "stopped", "error"],
    ),
    FrameworkArticle(
        number="Art. 17",
        title="ICT-Related Incident Reporting",
        requirement=(
            "Financial entities shall report major ICT-related incidents to "
            "competent authorities. Reports must include the nature of the "
            "incident, its impact, and the measures taken."
        ),
        lasso_control=(
            "Complete action history with UTC timestamps, unique event IDs, "
            "event categorization, and HMAC signatures. Supports incident "
            "reconstruction via lasso audit view/verify/export commands."
        ),
        relevant_event_types=["violation", "command"],
        relevant_outcomes=["blocked", "error"],
        relevant_actions=[],
    ),
]


# EU AI Act articles -- from docs/compliance/EU-AI-Act-mapping.md
EU_AI_ACT_ARTICLES = [
    FrameworkArticle(
        number="Art. 9",
        title="Risk Management System",
        requirement=(
            "Providers of high-risk AI systems shall establish, implement, "
            "document, and maintain a risk management system. This system "
            "shall be a continuous iterative process planned and run "
            "throughout the entire lifecycle of the high-risk AI system."
        ),
        lasso_control=(
            "Profile-based risk tiers (minimal, development, offline, strict, "
            "bank-analysis) with configurable risk controls: command whitelist, "
            "network isolation mode, guardrail enforcement, and defense-in-depth "
            "across four independent layers."
        ),
        relevant_event_types=["lifecycle", "command", "violation"],
        relevant_outcomes=["success", "blocked"],
    ),
    FrameworkArticle(
        number="Art. 12",
        title="Record-Keeping",
        requirement=(
            "High-risk AI systems shall technically allow for the automatic "
            "recording of events (logs) over the lifetime of the system. The "
            "logging capabilities shall ensure a level of traceability of the "
            "AI system's functioning throughout its lifecycle that is "
            "appropriate to the intended purpose of the system."
        ),
        lasso_control=(
            "Automatic, tamper-evident JSONL audit logging: every command "
            "execution, blocked attempt, lifecycle event, file access, network "
            "connection, and guardrail violation is recorded with timestamps, "
            "unique event IDs, and HMAC-SHA256 hash-chain signatures."
        ),
        relevant_event_types=["command", "lifecycle", "violation", "file", "network"],
    ),
    FrameworkArticle(
        number="Art. 14",
        title="Human Oversight",
        requirement=(
            "High-risk AI systems shall be designed and developed in such a "
            "way as to be effectively overseen by natural persons during the "
            "period in which they are used. Human oversight shall aim to "
            "prevent or minimize risks to health, safety, or fundamental rights."
        ),
        lasso_control=(
            "Command gating as pre-approved human policy, interactive REPL "
            "mode for supervised execution, sandbox lifecycle control (start, "
            "stop, mode changes), and post-hoc audit review with tamper-evident "
            "logs."
        ),
        relevant_event_types=["command", "lifecycle"],
        relevant_outcomes=["blocked", "success"],
        relevant_actions=["start", "stop"],
    ),
    FrameworkArticle(
        number="Art. 15",
        title="Accuracy, Robustness, and Cybersecurity",
        requirement=(
            "High-risk AI systems shall be designed and developed in such a "
            "way that they achieve an appropriate level of accuracy, robustness, "
            "and cybersecurity, and that they perform consistently throughout "
            "their lifecycle."
        ),
        lasso_control=(
            "Container isolation (process, filesystem, user namespace), "
            "cgroups v2 resource limits (memory, CPU, PIDs, file size), "
            "hardened input validation (null byte stripping, control character "
            "rejection, URL-encoded path traversal detection, symlink resolution), "
            "and network security (metadata endpoint blocking, private range "
            "blocking)."
        ),
        relevant_event_types=["command", "violation", "network"],
        relevant_outcomes=["blocked"],
    ),
]


FRAMEWORKS: dict[str, list[FrameworkArticle]] = {
    "dora": DORA_ARTICLES,
    "eu-ai-act": EU_AI_ACT_ARTICLES,
}

FRAMEWORK_FULL_NAMES: dict[str, str] = {
    "dora": "Digital Operational Resilience Act (EU) 2022/2554",
    "eu-ai-act": "EU Artificial Intelligence Act (EU) 2024/1689",
}


# ---------------------------------------------------------------------------
# Article evidence collection
# ---------------------------------------------------------------------------

@dataclass
class ArticleEvidence:
    """Evidence collected for a single framework article."""
    article: FrameworkArticle
    matching_event_count: int = 0
    sample_entries: list[dict[str, Any]] = field(default_factory=list)
    status: str = "Not Applicable"  # Implemented / Partially Implemented / Not Applicable

    @property
    def status_symbol(self) -> str:
        symbols = {
            "Implemented": "[PASS]",
            "Partially Implemented": "[PARTIAL]",
            "Not Applicable": "[N/A]",
        }
        return symbols.get(self.status, "[?]")


@dataclass
class AuditStatistics:
    """Aggregate statistics from an audit log."""
    total_events: int = 0
    total_commands: int = 0
    blocked_commands: int = 0
    successful_commands: int = 0
    violations: int = 0
    lifecycle_events: int = 0
    file_events: int = 0
    network_events: int = 0
    mcp_tool_calls: int = 0
    unique_sandbox_ids: int = 0
    earliest_timestamp: str = ""
    latest_timestamp: str = ""
    event_type_breakdown: dict[str, int] = field(default_factory=dict)
    outcome_breakdown: dict[str, int] = field(default_factory=dict)


@dataclass
class ComplianceReport:
    """A complete compliance evidence report."""
    framework: str
    framework_full_name: str
    report_date: str
    profile_name: str
    profile_hash: str
    audit_period_start: str
    audit_period_end: str
    lasso_version: str
    statistics: AuditStatistics
    article_evidence: list[ArticleEvidence]
    signing_verified: bool
    signing_details: str
    profile_summary: dict[str, Any]
    recommendations: list[str]
    total_events_analyzed: int


# ---------------------------------------------------------------------------
# Compliance reporter
# ---------------------------------------------------------------------------

class ComplianceReporter:
    """Generate compliance evidence reports from audit logs and profiles.

    Takes a regulatory framework name, an audit log path, and a profile,
    then produces a structured report mapping audit evidence to the
    framework's articles.

    Usage::

        reporter = ComplianceReporter("dora", "./audit/log.jsonl", "bank-analysis")
        report = reporter.generate()
        print(reporter.render_markdown(report))
    """

    MAX_SAMPLE_ENTRIES = 3  # sample entries per article

    def __init__(
        self,
        framework: str,
        audit_log_path: str,
        profile_name: str = "development",
    ):
        framework_lower = framework.lower()
        if framework_lower not in FRAMEWORKS:
            raise ValueError(
                f"Unknown framework: {framework!r}. "
                f"Supported: {', '.join(FRAMEWORKS.keys())}"
            )
        self.framework = framework_lower
        self.audit_log_path = Path(audit_log_path)
        self.profile_name = profile_name
        self.articles = FRAMEWORKS[self.framework]
        self.profile = self._load_profile()

    def _load_profile(self) -> SandboxProfile:
        """Load the named profile from builtins or saved profiles."""
        if self.profile_name in BUILTIN_PROFILES:
            dummy_dir = str(Path(tempfile.gettempdir()) / "lasso-compliance")
            return BUILTIN_PROFILES[self.profile_name](dummy_dir)
        try:
            return load_profile(self.profile_name)
        except FileNotFoundError:
            # Fall back to development profile with a note
            dummy_dir = str(Path(tempfile.gettempdir()) / "lasso-compliance")
            return BUILTIN_PROFILES["development"](dummy_dir)

    def generate(self) -> ComplianceReport:
        """Generate a complete compliance evidence report."""
        entries = self._read_entries()
        statistics = self._compute_statistics(entries)
        article_evidence = self._collect_evidence(entries)
        signing_verified, signing_details = self._verify_signing()
        profile_summary = self._summarize_profile()
        recommendations = self._generate_recommendations(
            article_evidence, statistics, signing_verified,
        )

        return ComplianceReport(
            framework=self.framework,
            framework_full_name=FRAMEWORK_FULL_NAMES[self.framework],
            report_date=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            profile_name=self.profile_name,
            profile_hash=self.profile.config_hash()[:12],
            audit_period_start=statistics.earliest_timestamp,
            audit_period_end=statistics.latest_timestamp,
            lasso_version=__version__,
            statistics=statistics,
            article_evidence=article_evidence,
            signing_verified=signing_verified,
            signing_details=signing_details,
            profile_summary=profile_summary,
            recommendations=recommendations,
            total_events_analyzed=statistics.total_events,
        )

    def _read_entries(self) -> list[dict[str, Any]]:
        """Read all audit entries from the log file."""
        if not self.audit_log_path.exists():
            return []
        return read_audit_entries(self.audit_log_path)

    def _compute_statistics(self, entries: list[dict]) -> AuditStatistics:
        """Compute aggregate statistics from audit entries."""
        stats = AuditStatistics()
        stats.total_events = len(entries)

        sandbox_ids: set[str] = set()
        event_types: dict[str, int] = {}
        outcomes: dict[str, int] = {}

        for entry in entries:
            etype = entry.get("type", "")
            outcome = entry.get("outcome", "")
            sandbox_id = entry.get("sandbox_id", "")

            if sandbox_id:
                sandbox_ids.add(sandbox_id)

            event_types[etype] = event_types.get(etype, 0) + 1
            if outcome:
                outcomes[outcome] = outcomes.get(outcome, 0) + 1

            if etype == "command":
                stats.total_commands += 1
                if outcome == "blocked":
                    stats.blocked_commands += 1
                elif outcome == "success":
                    stats.successful_commands += 1
            elif etype == "violation":
                stats.violations += 1
            elif etype == "lifecycle":
                stats.lifecycle_events += 1
            elif etype == "file":
                stats.file_events += 1
            elif etype == "network":
                stats.network_events += 1
            elif etype == "mcp_tool_call":
                stats.mcp_tool_calls += 1

            ts = entry.get("ts", "")
            if ts:
                if not stats.earliest_timestamp or ts < stats.earliest_timestamp:
                    stats.earliest_timestamp = ts
                if not stats.latest_timestamp or ts > stats.latest_timestamp:
                    stats.latest_timestamp = ts

        stats.unique_sandbox_ids = len(sandbox_ids)
        stats.event_type_breakdown = event_types
        stats.outcome_breakdown = outcomes

        return stats

    def _collect_evidence(self, entries: list[dict]) -> list[ArticleEvidence]:
        """Match audit entries to framework articles and collect evidence."""
        evidence_list: list[ArticleEvidence] = []

        for article in self.articles:
            matching: list[dict] = []

            for entry in entries:
                etype = entry.get("type", "")
                outcome = entry.get("outcome", "")
                action = entry.get("action", "")

                type_match = (
                    not article.relevant_event_types
                    or etype in article.relevant_event_types
                )
                outcome_match = (
                    not article.relevant_outcomes
                    or outcome in article.relevant_outcomes
                )
                action_match = (
                    not article.relevant_actions
                    or action in article.relevant_actions
                )

                if type_match and (outcome_match or action_match):
                    matching.append(entry)

            # Determine status based on evidence
            if len(matching) > 0:
                # Check if we have both enforcement evidence (blocked) and
                # operational evidence (success/lifecycle)
                has_blocked = any(
                    e.get("outcome") == "blocked" for e in matching
                )
                has_operational = any(
                    e.get("outcome") in ("success", "") or
                    e.get("type") == "lifecycle"
                    for e in matching
                )
                if has_blocked and has_operational:
                    status = "Implemented"
                elif has_blocked or has_operational:
                    status = "Implemented"
                else:
                    status = "Partially Implemented"
            else:
                status = "Not Applicable"

            # Take a sample of entries for the report
            samples = matching[:self.MAX_SAMPLE_ENTRIES]

            evidence_list.append(ArticleEvidence(
                article=article,
                matching_event_count=len(matching),
                sample_entries=samples,
                status=status,
            ))

        return evidence_list

    def _verify_signing(self) -> tuple[bool, str]:
        """Verify the audit log HMAC chain and return status details."""
        if not self.audit_log_path.exists():
            return False, "Audit log file not found."

        result = verify_audit_log(self.audit_log_path)

        if result.valid:
            return True, (
                f"HMAC chain verified: {result.verified_entries} of "
                f"{result.total_entries} entries verified. "
                f"No tampering detected."
            )
        else:
            error_summary = "; ".join(result.errors[:3])
            if len(result.errors) > 3:
                error_summary += f" (and {len(result.errors) - 3} more)"
            return False, (
                f"Verification failed: {result.verified_entries} of "
                f"{result.total_entries} entries verified. "
                f"First break at line {result.first_break_at}. "
                f"Errors: {error_summary}"
            )

    def _summarize_profile(self) -> dict[str, Any]:
        """Produce a human-readable summary of the profile configuration."""
        p = self.profile
        return {
            "name": p.name,
            "description": p.description,
            "version": p.version,
            "profile_version": p.profile_version,
            "config_hash": p.config_hash()[:12],
            "mode": p.mode.value,
            "commands": {
                "mode": p.commands.mode.value,
                "whitelist_count": len(p.commands.whitelist),
                "blocked_args_count": sum(
                    len(v) for v in p.commands.blocked_args.values()
                ),
                "shell_operators": p.commands.allow_shell_operators,
                "max_execution_seconds": p.commands.max_execution_seconds,
            },
            "network": {
                "mode": p.network.mode.value,
                "allowed_domains": p.network.allowed_domains,
                "blocked_ports_count": len(p.network.blocked_ports),
            },
            "resources": {
                "max_memory_mb": p.resources.max_memory_mb,
                "max_cpu_percent": p.resources.max_cpu_percent,
                "max_pids": p.resources.max_pids,
                "max_file_size_mb": p.resources.max_file_size_mb,
            },
            "audit": {
                "enabled": p.audit.enabled,
                "sign_entries": p.audit.sign_entries,
                "include_command_output": p.audit.include_command_output,
                "max_log_size_mb": p.audit.max_log_size_mb,
                "rotation_count": p.audit.rotation_count,
            },
            "guardrails": {
                "enforce": p.guardrails.enforce,
                "rules_count": len(p.guardrails.rules),
                "rules": [
                    {"id": r.id, "severity": r.severity, "enabled": r.enabled}
                    for r in p.guardrails.rules
                ],
            },
            "filesystem": {
                "hidden_paths_count": len(p.filesystem.hidden_paths),
                "read_only_paths_count": len(p.filesystem.read_only_paths),
            },
        }

    def _generate_recommendations(
        self,
        evidence: list[ArticleEvidence],
        stats: AuditStatistics,
        signing_verified: bool,
    ) -> list[str]:
        """Identify compliance gaps and produce actionable recommendations."""
        recs: list[str] = []

        # Check for articles with no evidence
        no_evidence = [e for e in evidence if e.status == "Not Applicable"]
        if no_evidence:
            articles_str = ", ".join(e.article.number for e in no_evidence)
            recs.append(
                f"No audit evidence found for: {articles_str}. "
                f"This may indicate the audit log does not cover the full "
                f"operational period, or these controls have not been exercised."
            )

        # Signing verification
        if not signing_verified:
            recs.append(
                "Audit log HMAC verification failed. Investigate potential "
                "tampering or ensure the correct signing key is available. "
                "For production use, store the signing key separately from "
                "the audit logs (audit.signing_key_path)."
            )

        # Profile configuration gaps
        p = self.profile
        if not p.audit.sign_entries:
            recs.append(
                "Audit entry HMAC signing is disabled. Enable "
                "audit.sign_entries for tamper-evident logging required "
                "by DORA Art. 17 and EU AI Act Art. 12."
            )

        if not p.audit.enabled:
            recs.append(
                "Audit logging is disabled. Enable audit.enabled to "
                "satisfy record-keeping requirements."
            )

        if p.commands.allow_shell_operators:
            recs.append(
                "Shell operators (pipes, redirects, subshells) are enabled. "
                "Consider disabling allow_shell_operators to prevent "
                "command chaining exploits."
            )

        if p.network.mode.value == "full":
            recs.append(
                "Network mode is 'full' (unrestricted). Consider using "
                "'restricted' or 'none' mode for regulated workloads to "
                "satisfy DORA Art. 9 protection requirements."
            )

        if not p.guardrails.enforce:
            recs.append(
                "Guardrail enforcement is disabled (violations are logged "
                "but not blocked). Enable guardrails.enforce for regulated "
                "environments."
            )

        if stats.total_events == 0:
            recs.append(
                "Audit log is empty. Ensure that sandboxes are configured "
                "with audit logging enabled and that the correct log file "
                "path is specified."
            )

        # Check for high violation rate
        if stats.total_commands > 0:
            violation_rate = stats.blocked_commands / stats.total_commands
            if violation_rate > 0.20:
                recs.append(
                    f"High command block rate: {stats.blocked_commands} of "
                    f"{stats.total_commands} commands were blocked "
                    f"({violation_rate:.0%}). Review the command whitelist "
                    f"to ensure it matches operational requirements."
                )

        if not recs:
            recs.append(
                "No compliance gaps identified. Continue monitoring audit "
                "logs and reviewing profile configuration periodically."
            )

        return recs

    # -------------------------------------------------------------------
    # Rendering
    # -------------------------------------------------------------------

    def render_markdown(self, report: ComplianceReport) -> str:
        """Render a compliance report as a Markdown document."""
        lines: list[str] = []

        # Title
        lines.append(f"# LASSO Compliance Evidence Report")
        lines.append(f"## {report.framework_full_name}")
        lines.append("")

        # Executive summary
        lines.append("---")
        lines.append("")
        lines.append("## Executive Summary")
        lines.append("")
        lines.append(f"| Property | Value |")
        lines.append(f"|----------|-------|")
        lines.append(f"| Framework | {report.framework_full_name} |")
        lines.append(f"| Report date | {report.report_date} |")
        lines.append(f"| LASSO version | {report.lasso_version} |")
        lines.append(f"| Profile | {report.profile_name} (hash: {report.profile_hash}) |")
        lines.append(f"| Audit period | {report.audit_period_start or 'N/A'} to {report.audit_period_end or 'N/A'} |")
        lines.append(f"| Total events analyzed | {report.total_events_analyzed:,} |")
        lines.append(f"| Audit log integrity | {'VERIFIED' if report.signing_verified else 'FAILED'} |")
        lines.append("")

        # Compliance status overview
        implemented = sum(
            1 for e in report.article_evidence if e.status == "Implemented"
        )
        partial = sum(
            1 for e in report.article_evidence if e.status == "Partially Implemented"
        )
        na = sum(
            1 for e in report.article_evidence if e.status == "Not Applicable"
        )
        total = len(report.article_evidence)

        lines.append(f"**Compliance coverage:** {implemented} of {total} articles fully evidenced, "
                      f"{partial} partially evidenced, {na} not applicable.")
        lines.append("")

        # Framework mapping
        lines.append("---")
        lines.append("")
        lines.append("## Framework Mapping")
        lines.append("")

        for ev in report.article_evidence:
            art = ev.article
            lines.append(f"### {art.number}: {art.title}")
            lines.append("")
            lines.append(f"**Regulatory requirement:**")
            lines.append(f"> {art.requirement}")
            lines.append("")
            lines.append(f"**LASSO control:**")
            lines.append(f"> {art.lasso_control}")
            lines.append("")
            lines.append(f"**Status:** {ev.status_symbol} {ev.status}")
            lines.append("")
            lines.append(f"**Evidence:** {ev.matching_event_count:,} matching audit events")
            lines.append("")

            if ev.sample_entries:
                lines.append("**Sample entries:**")
                lines.append("")
                lines.append("```")
                for sample in ev.sample_entries:
                    ts = sample.get("ts", "")[:19]
                    etype = sample.get("type", "")
                    action = sample.get("action", "")
                    outcome = sample.get("outcome", "")
                    sid = sample.get("sandbox_id", "")[:8]
                    detail_str = ""
                    detail = sample.get("detail", {})
                    if isinstance(detail, dict) and detail.get("reason"):
                        detail_str = f" -- {detail['reason'][:60]}"
                    lines.append(
                        f"  {ts}  {etype:<12} {action:<20} "
                        f"{outcome:<8} sandbox={sid}{detail_str}"
                    )
                lines.append("```")
                lines.append("")

            lines.append("---")
            lines.append("")

        # Audit statistics
        lines.append("## Audit Statistics")
        lines.append("")
        stats = report.statistics
        lines.append("| Metric | Count |")
        lines.append("|--------|-------|")
        lines.append(f"| Total events | {stats.total_events:,} |")
        lines.append(f"| Commands executed | {stats.successful_commands:,} |")
        lines.append(f"| Commands blocked | {stats.blocked_commands:,} |")
        lines.append(f"| Violations | {stats.violations:,} |")
        lines.append(f"| Lifecycle events | {stats.lifecycle_events:,} |")
        lines.append(f"| File access events | {stats.file_events:,} |")
        lines.append(f"| Network events | {stats.network_events:,} |")
        lines.append(f"| MCP tool calls | {stats.mcp_tool_calls:,} |")
        lines.append(f"| Unique sandbox sessions | {stats.unique_sandbox_ids:,} |")
        lines.append("")

        if stats.event_type_breakdown:
            lines.append("**Event type breakdown:**")
            lines.append("")
            for etype, count in sorted(
                stats.event_type_breakdown.items(), key=lambda x: -x[1]
            ):
                lines.append(f"- `{etype}`: {count:,}")
            lines.append("")

        if stats.outcome_breakdown:
            lines.append("**Outcome breakdown:**")
            lines.append("")
            for outcome, count in sorted(
                stats.outcome_breakdown.items(), key=lambda x: -x[1]
            ):
                lines.append(f"- `{outcome}`: {count:,}")
            lines.append("")

        # Signing verification
        lines.append("---")
        lines.append("")
        lines.append("## Audit Log Integrity")
        lines.append("")
        if report.signing_verified:
            lines.append("**Result: VERIFIED**")
        else:
            lines.append("**Result: FAILED**")
        lines.append("")
        lines.append(report.signing_details)
        lines.append("")

        # Profile configuration
        lines.append("---")
        lines.append("")
        lines.append("## Profile Configuration")
        lines.append("")
        ps = report.profile_summary
        lines.append(f"**Profile:** {ps['name']} (v{ps['profile_version']}, hash: {ps['config_hash']})")
        lines.append("")
        if ps.get("description"):
            lines.append(f"*{ps['description']}*")
            lines.append("")

        cmd = ps["commands"]
        lines.append("**Command policy:**")
        lines.append(f"- Mode: `{cmd['mode']}`")
        lines.append(f"- Whitelisted commands: {cmd['whitelist_count']}")
        lines.append(f"- Blocked argument patterns: {cmd['blocked_args_count']}")
        lines.append(f"- Shell operators: {'enabled' if cmd['shell_operators'] else 'disabled'}")
        lines.append(f"- Max execution time: {cmd['max_execution_seconds']}s")
        lines.append("")

        net = ps["network"]
        lines.append("**Network policy:**")
        lines.append(f"- Mode: `{net['mode']}`")
        if net["allowed_domains"]:
            lines.append(f"- Allowed domains: {', '.join(net['allowed_domains'])}")
        lines.append(f"- Blocked ports: {net['blocked_ports_count']}")
        lines.append("")

        res = ps["resources"]
        lines.append("**Resource limits:**")
        lines.append(f"- Memory: {res['max_memory_mb']} MB")
        lines.append(f"- CPU: {res['max_cpu_percent']}%")
        lines.append(f"- Max PIDs: {res['max_pids']}")
        lines.append(f"- Max file size: {res['max_file_size_mb']} MB")
        lines.append("")

        aud = ps["audit"]
        lines.append("**Audit configuration:**")
        lines.append(f"- Enabled: {'yes' if aud['enabled'] else 'no'}")
        lines.append(f"- HMAC signing: {'yes' if aud['sign_entries'] else 'no'}")
        lines.append(f"- Command output logging: {'yes' if aud['include_command_output'] else 'no'}")
        lines.append(f"- Max log size: {aud['max_log_size_mb']} MB")
        lines.append(f"- Rotation count: {aud['rotation_count']}")
        lines.append("")

        gr = ps["guardrails"]
        lines.append("**Guardrails:**")
        lines.append(f"- Enforcement: {'enabled' if gr['enforce'] else 'disabled (log-only)'}")
        lines.append(f"- Rules configured: {gr['rules_count']}")
        for rule in gr.get("rules", []):
            enabled = "enabled" if rule["enabled"] else "disabled"
            lines.append(f"  - `{rule['id']}` ({rule['severity']}) -- {enabled}")
        lines.append("")

        # Recommendations
        lines.append("---")
        lines.append("")
        lines.append("## Recommendations")
        lines.append("")
        for i, rec in enumerate(report.recommendations, 1):
            lines.append(f"{i}. {rec}")
            lines.append("")

        # Footer
        lines.append("---")
        lines.append("")
        lines.append(
            f"*Report generated by LASSO v{report.lasso_version} on "
            f"{report.report_date}. This report is for informational purposes "
            f"and does not constitute legal advice. Consult your compliance "
            f"team for a complete regulatory assessment.*"
        )
        lines.append("")

        return "\n".join(lines)

    def render_json(self, report: ComplianceReport) -> str:
        """Render a compliance report as JSON."""
        data = {
            "framework": report.framework,
            "framework_full_name": report.framework_full_name,
            "report_date": report.report_date,
            "lasso_version": report.lasso_version,
            "profile": {
                "name": report.profile_name,
                "hash": report.profile_hash,
            },
            "audit_period": {
                "start": report.audit_period_start,
                "end": report.audit_period_end,
            },
            "total_events_analyzed": report.total_events_analyzed,
            "signing": {
                "verified": report.signing_verified,
                "details": report.signing_details,
            },
            "statistics": {
                "total_events": report.statistics.total_events,
                "commands_executed": report.statistics.successful_commands,
                "commands_blocked": report.statistics.blocked_commands,
                "violations": report.statistics.violations,
                "lifecycle_events": report.statistics.lifecycle_events,
                "file_events": report.statistics.file_events,
                "network_events": report.statistics.network_events,
                "mcp_tool_calls": report.statistics.mcp_tool_calls,
                "unique_sandbox_sessions": report.statistics.unique_sandbox_ids,
                "event_type_breakdown": report.statistics.event_type_breakdown,
                "outcome_breakdown": report.statistics.outcome_breakdown,
            },
            "article_evidence": [
                {
                    "article_number": ev.article.number,
                    "article_title": ev.article.title,
                    "requirement": ev.article.requirement,
                    "lasso_control": ev.article.lasso_control,
                    "status": ev.status,
                    "matching_events": ev.matching_event_count,
                    "sample_entries": ev.sample_entries,
                }
                for ev in report.article_evidence
            ],
            "profile_configuration": report.profile_summary,
            "recommendations": report.recommendations,
        }
        return json.dumps(data, indent=2)
