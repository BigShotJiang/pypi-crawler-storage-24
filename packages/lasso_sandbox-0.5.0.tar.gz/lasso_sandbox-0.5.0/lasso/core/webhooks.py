"""Webhook dispatcher — async delivery of audit events to external systems.

Sends sandbox audit events (violations, lifecycle changes, commands, etc.) to
configured webhook endpoints for SIEM/SOAR, Slack, and monitoring integration.

Design decisions:
- Uses stdlib ``urllib.request`` only (no external HTTP dependencies).
- Dispatches asynchronously via ``threading.Thread`` so webhook latency
  never blocks command execution inside the sandbox.
- Signs payloads with HMAC-SHA256 when a secret is configured, following
  the same pattern as GitHub webhook signatures (X-Hub-Signature-256).
- Retries with exponential backoff on transient failures.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import logging
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lasso.config.schema import WebhookConfig
    from lasso.core.audit import AuditEvent

logger = logging.getLogger("lasso.webhooks")

# All event types that LASSO emits.
WEBHOOK_EVENT_TYPES: list[str] = [
    "command",
    "lifecycle",
    "violation",
    "file",
    "network",
]


def _is_safe_webhook_url(url: str) -> tuple[bool, str]:
    """Validate that a webhook URL does not target internal/private networks.

    Resolves the hostname to IP addresses and checks each against known
    private, loopback, link-local, reserved, and cloud metadata ranges.

    Returns:
        (is_safe, reason) — *is_safe* is True when the URL is safe to call.
        When False, *reason* describes why it was blocked.
    """
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return False, "Malformed URL"

    hostname = parsed.hostname
    if not hostname:
        return False, "No hostname in URL"

    scheme = (parsed.scheme or "").lower()
    if scheme not in ("http", "https"):
        return False, f"Disallowed URL scheme: {scheme!r}"

    # Resolve hostname to IPs (both IPv4 and IPv6)
    try:
        addrinfos = socket.getaddrinfo(hostname, parsed.port or 443, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        return False, f"DNS resolution failed for {hostname!r}: {exc}"

    if not addrinfos:
        return False, f"No DNS results for {hostname!r}"

    # Cloud metadata endpoints to block explicitly
    _METADATA_ADDRS = {
        ipaddress.ip_address("169.254.169.254"),
        ipaddress.ip_address("fd00:ec2::254"),
    }

    for family, _type, _proto, _canonname, sockaddr in addrinfos:
        ip_str = sockaddr[0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            return False, f"Unparseable resolved IP: {ip_str}"

        if ip in _METADATA_ADDRS:
            return False, f"Cloud metadata endpoint blocked: {ip}"
        if ip.is_private:
            return False, f"Private IP blocked: {ip}"
        if ip.is_loopback:
            return False, f"Loopback IP blocked: {ip}"
        if ip.is_link_local:
            return False, f"Link-local IP blocked: {ip}"
        if ip.is_reserved:
            return False, f"Reserved IP blocked: {ip}"
        if ip.is_multicast:
            return False, f"Multicast IP blocked: {ip}"
        if ip.is_unspecified:
            return False, f"Unspecified IP blocked: {ip}"

    return True, ""


class WebhookDispatcher:
    """Delivers audit events to one or more webhook endpoints.

    Each webhook is filtered by its ``events`` list — only matching event
    types are dispatched.  Delivery happens on a bounded thread pool so the
    caller is never blocked.
    """

    def __init__(
        self,
        webhooks: list[WebhookConfig],
        _allow_private: bool = False,
    ):
        self._webhooks = [wh for wh in webhooks if wh.enabled and wh.url]
        self._executor = ThreadPoolExecutor(max_workers=10)
        self._allow_private = _allow_private

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def dispatch(self, event: AuditEvent) -> None:
        """Send *event* to all matching webhooks (non-blocking)."""
        if not self._webhooks:
            return

        payload = json.dumps(event.to_dict(), separators=(",", ":"), sort_keys=True)

        for wh in self._webhooks:
            if event.event_type not in wh.events:
                continue
            self._executor.submit(self._deliver, wh, payload, event.event_type)

    def close(self) -> None:
        """Shut down the thread pool, waiting for pending deliveries."""
        self._executor.shutdown(wait=True)

    @property
    def active_webhooks(self) -> int:
        """Number of enabled+configured webhooks."""
        return len(self._webhooks)

    # ------------------------------------------------------------------
    # Internal delivery
    # ------------------------------------------------------------------

    def _deliver(
        self,
        wh: WebhookConfig,
        payload: str,
        event_type: str,
    ) -> None:
        """Deliver *payload* to a single webhook with retries."""
        # SSRF protection: validate the URL does not target internal networks
        if not self._allow_private:
            is_safe, reason = _is_safe_webhook_url(wh.url)
        else:
            is_safe, reason = True, ""
        if not is_safe:
            logger.warning(
                "Webhook delivery blocked (SSRF protection): %s -> %s — %s",
                event_type, wh.url, reason,
            )
            return

        delivery_id = uuid.uuid4().hex[:16]
        timestamp = str(int(time.time()))

        headers = {
            "Content-Type": "application/json",
            "X-Lasso-Event": event_type,
            "X-Lasso-Delivery": delivery_id,
            "X-Lasso-Timestamp": timestamp,
            "User-Agent": "LASSO-Webhook/1.0",
        }

        if wh.secret:
            sig_payload = timestamp + "." + payload
            sig = hmac.new(
                wh.secret.encode(),
                sig_payload.encode(),
                hashlib.sha256,
            ).hexdigest()
            headers["X-Lasso-Signature"] = f"t={timestamp},sha256={sig}"

        last_error: Exception | None = None
        attempts = 1 + wh.retry_count  # first attempt + retries

        for attempt in range(attempts):
            try:
                req = urllib.request.Request(
                    wh.url,
                    data=payload.encode(),
                    headers=headers,
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=wh.timeout_seconds) as resp:
                    status = resp.status
                    if 200 <= status < 300:
                        logger.debug(
                            "Webhook delivered: %s -> %s (status %d, delivery %s)",
                            event_type, wh.url, status, delivery_id,
                        )
                        return
                    else:
                        last_error = RuntimeError(f"HTTP {status}")
            except (urllib.error.URLError, OSError, RuntimeError) as exc:
                last_error = exc

            # Exponential backoff before retry
            if attempt < attempts - 1:
                backoff = 0.5 * (2 ** attempt)
                time.sleep(backoff)

        logger.warning(
            "Webhook delivery failed after %d attempts: %s -> %s — %s",
            attempts, event_type, wh.url, last_error,
        )
