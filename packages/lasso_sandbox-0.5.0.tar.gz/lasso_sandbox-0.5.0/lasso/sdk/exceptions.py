"""Custom exception types for the LASSO SDK.

Provides a hierarchy of specific exceptions so callers can handle
different failure modes precisely rather than catching generic
RuntimeError or KeyError.

Exception hierarchy::

    LassoError
    +-- SandboxNotFoundError
    +-- SandboxNotRunningError
    +-- ProfileNotFoundError
    +-- AuthenticationError
    +-- RateLimitError
    +-- CommandBlockedError
"""

from __future__ import annotations


class LassoError(Exception):
    """Base exception for all LASSO SDK errors.

    All SDK-specific exceptions inherit from this class, making it
    possible to catch any LASSO error with a single ``except LassoError``.
    """


class SandboxNotFoundError(LassoError):
    """Raised when a sandbox with the given ID does not exist.

    Attributes:
        sandbox_id: The ID that was looked up.
    """

    def __init__(self, sandbox_id: str, message: str | None = None):
        self.sandbox_id = sandbox_id
        super().__init__(message or f"Sandbox '{sandbox_id}' not found.")


class SandboxNotRunningError(LassoError):
    """Raised when an operation requires a running sandbox but it is not running.

    Attributes:
        sandbox_id: The sandbox ID.
        state: The current state of the sandbox.
    """

    def __init__(self, sandbox_id: str, state: str = "unknown"):
        self.sandbox_id = sandbox_id
        self.state = state
        super().__init__(
            f"Sandbox '{sandbox_id}' is not running (state: {state})."
        )


class ProfileNotFoundError(LassoError):
    """Raised when a profile name cannot be resolved.

    Attributes:
        profile_name: The profile name that was not found.
    """

    def __init__(self, profile_name: str, available: list[str] | None = None):
        self.profile_name = profile_name
        self.available = available or []
        msg = f"Profile '{profile_name}' not found."
        if self.available:
            msg += f" Available: {', '.join(self.available)}"
        super().__init__(msg)


class AuthenticationError(LassoError):
    """Raised when the API key is missing or invalid.

    Attributes:
        status_code: The HTTP status code returned by the API.
    """

    def __init__(self, message: str = "API key invalid or missing.", status_code: int = 401):
        self.status_code = status_code
        super().__init__(message)


class RateLimitError(LassoError):
    """Raised when the API rate limit has been exceeded.

    Attributes:
        retry_after: Suggested number of seconds to wait before retrying.
    """

    def __init__(self, message: str = "Rate limit exceeded.", retry_after: int | None = None):
        self.retry_after = retry_after
        super().__init__(message)


class CommandBlockedError(LassoError):
    """Raised when a command was blocked by the sandbox security policy.

    Attributes:
        command: The command that was blocked.
        reason: The reason the command was blocked.
    """

    def __init__(self, command: str, reason: str = ""):
        self.command = command
        self.reason = reason
        msg = f"Command blocked: '{command}'"
        if reason:
            msg += f" ({reason})"
        super().__init__(msg)
