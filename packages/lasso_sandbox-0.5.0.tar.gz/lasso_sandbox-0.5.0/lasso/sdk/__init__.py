"""LASSO Python SDK -- programmatic sandbox management.

Provides a high-level client for creating, managing, and interacting with
LASSO sandboxes, either locally (direct Sandbox objects) or remotely
(via the LASSO REST API).

Usage::

    from lasso.sdk import LassoClient, sandbox

    # Quick one-off sandbox
    with sandbox("development", "/my/project") as sb:
        result = sb.exec("python3 script.py")
        print(result.stdout)

    # Full client usage
    client = LassoClient()
    sb = client.create("development", working_dir="/my/project")
    result = sb.exec("ls -la")
    sb.stop()

    # Remote mode
    client = LassoClient(api_url="http://localhost:8080", api_key="lasso_xxx")

    # Exception handling
    from lasso.sdk import SandboxNotFoundError, ProfileNotFoundError
    try:
        sb = client.get("nonexistent-id")
    except SandboxNotFoundError:
        print("Sandbox not found")
"""

from lasso.sdk.client import LassoClient, SandboxHandle
from lasso.sdk.exceptions import (
    AuthenticationError,
    CommandBlockedError,
    LassoError,
    ProfileNotFoundError,
    RateLimitError,
    SandboxNotFoundError,
    SandboxNotRunningError,
)


def sandbox(profile="development", working_dir=".", **kwargs):
    """Quick context manager for one-off sandbox usage.

    Creates a :class:`LassoClient`, then yields a :class:`SandboxHandle`
    that is automatically stopped on exit.

    Args:
        profile: Name of the sandbox profile (default ``"development"``).
        working_dir: Working directory to mount inside the sandbox.
        **kwargs: Passed to :class:`LassoClient` constructor (e.g.
            ``api_url``, ``api_key``).

    Returns:
        A context manager yielding a :class:`SandboxHandle`.
    """
    client = LassoClient(**kwargs)
    return client.sandbox(profile, working_dir)


__all__ = [
    "LassoClient",
    "SandboxHandle",
    "sandbox",
    # Exceptions
    "LassoError",
    "SandboxNotFoundError",
    "SandboxNotRunningError",
    "ProfileNotFoundError",
    "AuthenticationError",
    "RateLimitError",
    "CommandBlockedError",
]
