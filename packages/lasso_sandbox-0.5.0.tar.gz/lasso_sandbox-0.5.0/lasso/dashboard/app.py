"""LASSO Dashboard — Flask application factory.

Usage:
    from lasso.dashboard.app import create_app
    app = create_app(registry=my_registry, backend=my_backend)
    app.run(debug=True)

Requires: pip install flask
"""

from __future__ import annotations

import atexit
import json
import os
import platform
import secrets
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

try:
    from flask import (
        Flask,
        Blueprint,
        abort,
        jsonify,
        redirect,
        render_template,
        request,
        url_for,
    )
except ImportError:
    raise ImportError(
        "Flask is required for the dashboard. "
        "Install it with: pip install lasso-sandbox[dashboard]"
    )

from lasso.dashboard.auth import init_dashboard_auth, require_login

from lasso import __version__
from lasso.config.defaults import BUILTIN_PROFILES
from lasso.config.profile import list_profiles, load_profile
from lasso.config.schema import SandboxState
from lasso.core.sandbox import Sandbox, SandboxRegistry

# ---------------------------------------------------------------------------
# Audit log reader utility
# ---------------------------------------------------------------------------

def read_audit_log(
    path: str | Path,
    tail: int = 50,
    event_type: str | None = None,
    offset: int = 0,
) -> list[dict]:
    """Read a JSONL audit log, optionally filtered and paginated."""
    entries: list[dict] = []
    path = Path(path)
    if not path.exists():
        return entries
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if event_type and entry.get("type") != event_type:
                    continue
                entries.append(entry)
    except (OSError, PermissionError):
        return entries
    # Apply offset + tail for pagination
    if offset:
        entries = entries[offset:]
    return entries[-tail:] if tail else entries


def _system_capabilities() -> dict[str, Any]:
    """Gather system info for the check page."""
    caps: dict[str, Any] = {}

    # Docker / Podman
    caps["docker"] = shutil.which("docker") is not None
    caps["podman"] = shutil.which("podman") is not None

    # Linux namespaces
    caps["user_ns"] = Path("/proc/self/ns/user").exists()
    caps["mount_ns"] = Path("/proc/self/ns/mnt").exists()
    caps["pid_ns"] = Path("/proc/self/ns/pid").exists()
    caps["net_ns"] = Path("/proc/self/ns/net").exists()

    # Cgroups v2
    caps["cgroups_v2"] = Path("/sys/fs/cgroup/cgroup.controllers").exists()

    # Platform
    caps["platform"] = platform.platform()
    caps["python"] = platform.python_version()

    return caps


# ---------------------------------------------------------------------------
# Blueprint
# ---------------------------------------------------------------------------

dashboard_bp = Blueprint(
    "dashboard",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/dashboard/static",
)


def _get_registry() -> SandboxRegistry:
    from flask import current_app
    reg = current_app.config.get("REGISTRY")
    if reg is None:
        reg = SandboxRegistry()
        current_app.config["REGISTRY"] = reg
    return reg


def _get_backend():
    from flask import current_app
    return current_app.config.get("BACKEND")


def _default_sandbox_dir() -> str:
    """Return a platform-appropriate default sandbox directory."""
    import tempfile
    return str(Path(tempfile.gettempdir()) / "lasso-sandbox")


def _get_all_profiles() -> list[dict]:
    """Return combined list of builtin + saved profiles."""
    profiles = []
    for name, factory in BUILTIN_PROFILES.items():
        p = factory(_default_sandbox_dir())
        profiles.append({
            "name": name,
            "description": p.description,
            "source": "builtin",
            "cmd_mode": p.commands.mode.value,
            "net_mode": p.network.mode.value,
            "mem_limit": f"{p.resources.max_memory_mb}MB",
            "tags": p.tags,
        })
    for saved in list_profiles():
        if "error" not in saved:
            saved["source"] = "saved"
            saved["description"] = saved.get("description", "")
            profiles.append(saved)
    return profiles


def _state_color(state: str) -> str:
    """Map sandbox state to a CSS color class."""
    return {
        "running": "state-running",
        "created": "state-created",
        "configuring": "state-configuring",
        "stopped": "state-stopped",
        "paused": "state-paused",
        "error": "state-error",
    }.get(state, "")


# ---------------------------------------------------------------------------
# Routes — HTML pages
# ---------------------------------------------------------------------------

@dashboard_bp.route("/")
@require_login
def index():
    """Dashboard home: sandbox list + system stats."""
    registry = _get_registry()
    sandboxes = registry.list_all()
    profiles = _get_all_profiles()

    stats = {
        "total": len(sandboxes),
        "running": sum(1 for s in sandboxes if s["state"] == "running"),
        "stopped": sum(1 for s in sandboxes if s["state"] == "stopped"),
        "errors": sum(1 for s in sandboxes if s["state"] == "error"),
        "total_execs": sum(s.get("exec_count", 0) for s in sandboxes),
        "total_blocked": sum(s.get("blocked_count", 0) for s in sandboxes),
    }

    return render_template(
        "index.html",
        sandboxes=sandboxes,
        profiles=profiles,
        stats=stats,
        state_color=_state_color,
        version=__version__,
    )


@dashboard_bp.route("/sandbox/<sandbox_id>")
@require_login
def sandbox_detail(sandbox_id: str):
    """Sandbox detail page."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        abort(404, description=f"Sandbox '{sandbox_id}' not found.")

    status = sb.status()
    policy = sb.command_gate.explain_policy()

    # Read recent audit entries
    audit_entries = []
    if sb.audit.log_file and sb.audit.log_file.exists():
        audit_entries = read_audit_log(sb.audit.log_file, tail=25)

    return render_template(
        "sandbox.html",
        sandbox=status,
        policy=policy,
        audit_entries=audit_entries,
        state_color=_state_color,
        version=__version__,
    )


@dashboard_bp.route("/sandbox/<sandbox_id>/exec", methods=["POST"])
@require_login
def sandbox_exec(sandbox_id: str):
    """Execute a command inside a sandbox. Returns HTMX partial."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        abort(404)

    command = request.form.get("command", "").strip()
    if not command:
        return render_template("partials/exec_result.html", error="No command provided.")
    if len(command) > 4096:
        return render_template("partials/exec_result.html", error="Command too long (max 4096 chars).")

    result = sb.exec(command)

    return render_template(
        "partials/exec_result.html",
        result={
            "command": result.command,
            "exit_code": result.exit_code,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "duration_ms": result.duration_ms,
            "blocked": result.blocked,
            "block_reason": result.block_reason if result.blocked else "",
        },
    )


def _validate_working_dir(working_dir: str) -> str | None:
    """Validate working_dir input. Returns error message or None if valid."""
    import tempfile

    if ".." in working_dir:
        return "Path traversal (..) is not allowed."
    if len(working_dir) > 4096:
        return "Path too long."
    resolved = Path(working_dir).resolve()
    home = Path.home().resolve()
    tmp = Path(tempfile.gettempdir()).resolve()
    if not (str(resolved).startswith(str(home)) or str(resolved).startswith(str(tmp))):
        return "Working directory must be under home or temp directory."
    return None


@dashboard_bp.route("/sandbox/create", methods=["POST"])
@require_login
def sandbox_create():
    """Create a new sandbox from a profile."""
    registry = _get_registry()
    backend = _get_backend()

    profile_name = request.form.get("profile", "").strip()
    working_dir = request.form.get("working_dir", _default_sandbox_dir()).strip()

    if not profile_name:
        return redirect(url_for("dashboard.index"))

    dir_error = _validate_working_dir(working_dir)
    if dir_error:
        abort(400, description=dir_error)

    # Resolve profile
    if profile_name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[profile_name](working_dir)
    else:
        try:
            profile = load_profile(profile_name)
        except FileNotFoundError:
            abort(400, description=f"Profile '{profile_name}' not found.")

    sb = registry.create(profile)
    try:
        sb.start()
    except RuntimeError:
        pass  # Started in error state, visible in dashboard

    return redirect(url_for("dashboard.index"))


@dashboard_bp.route("/sandbox/<sandbox_id>/stop", methods=["POST"])
@require_login
def sandbox_stop(sandbox_id: str):
    """Stop a running sandbox."""
    registry = _get_registry()
    if not registry.stop(sandbox_id):
        abort(404)
    return redirect(url_for("dashboard.index"))


@dashboard_bp.route("/profiles")
@require_login
def profiles_list():
    """Profile listing page."""
    profiles = _get_all_profiles()
    return render_template(
        "profiles.html",
        profiles=profiles,
        version=__version__,
    )


@dashboard_bp.route("/profiles/<name>")
@require_login
def profile_detail(name: str):
    """Profile detail/editor page."""
    profile = None
    source = "unknown"

    if name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[name](_default_sandbox_dir())
        source = "builtin"
    else:
        try:
            profile = load_profile(name)
            source = "saved"
        except FileNotFoundError:
            abort(404, description=f"Profile '{name}' not found.")

    profile_data = profile.model_dump(mode="json")
    profile_json = json.dumps(profile_data, indent=2)

    return render_template(
        "profile_detail.html",
        profile=profile,
        profile_data=profile_data,
        profile_json=profile_json,
        source=source,
        version=__version__,
    )


@dashboard_bp.route("/audit/<sandbox_id>")
@require_login
def audit_log(sandbox_id: str):
    """Audit log viewer with filters."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        abort(404, description=f"Sandbox '{sandbox_id}' not found.")

    status = sb.status()
    event_type = request.args.get("type", "")
    page = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 50))

    all_entries: list[dict] = []
    if sb.audit.log_file and sb.audit.log_file.exists():
        all_entries = read_audit_log(
            sb.audit.log_file,
            tail=0,  # get all
            event_type=event_type or None,
        )

    # Pagination
    total = len(all_entries)
    total_pages = max(1, (total + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    entries = all_entries[start : start + per_page]

    # Collect unique event types for filter dropdown
    event_types = sorted(set(e.get("type", "") for e in all_entries if e.get("type")))

    return render_template(
        "audit.html",
        sandbox=status,
        entries=entries,
        event_types=event_types,
        current_type=event_type,
        page=page,
        total_pages=total_pages,
        total=total,
        per_page=per_page,
        version=__version__,
    )


@dashboard_bp.route("/check")
@require_login
def system_check():
    """System capability check page."""
    caps = _system_capabilities()
    return render_template(
        "check.html",
        capabilities=caps,
        version=__version__,
    )


# ---------------------------------------------------------------------------
# Routes — HTMX partials
# ---------------------------------------------------------------------------

@dashboard_bp.route("/partials/sandbox-table")
@require_login
def partial_sandbox_table():
    """HTMX partial: refreshable sandbox table body."""
    registry = _get_registry()
    sandboxes = registry.list_all()
    stats = {
        "total": len(sandboxes),
        "running": sum(1 for s in sandboxes if s["state"] == "running"),
        "stopped": sum(1 for s in sandboxes if s["state"] == "stopped"),
        "errors": sum(1 for s in sandboxes if s["state"] == "error"),
        "total_execs": sum(s.get("exec_count", 0) for s in sandboxes),
        "total_blocked": sum(s.get("blocked_count", 0) for s in sandboxes),
    }
    return render_template(
        "partials/sandbox_table.html",
        sandboxes=sandboxes,
        stats=stats,
        state_color=_state_color,
    )


@dashboard_bp.route("/partials/audit-feed/<sandbox_id>")
@require_login
def partial_audit_feed(sandbox_id: str):
    """HTMX partial: live audit feed for a sandbox."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return "<tr><td colspan='5'>Sandbox not found.</td></tr>"

    entries = []
    if sb.audit.log_file and sb.audit.log_file.exists():
        entries = read_audit_log(sb.audit.log_file, tail=15)

    return render_template("partials/audit_feed.html", entries=entries)


@dashboard_bp.route("/partials/sandbox-status/<sandbox_id>")
@require_login
def partial_sandbox_status(sandbox_id: str):
    """HTMX partial: sandbox status badge and counters."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return "<span>Not found</span>"
    status = sb.status()
    return render_template(
        "partials/sandbox_status.html",
        sandbox=status,
        state_color=_state_color,
    )


# ---------------------------------------------------------------------------
# Routes — JSON API
# ---------------------------------------------------------------------------

@dashboard_bp.route("/api/sandboxes")
@require_login
def api_sandboxes():
    """JSON API: list all sandboxes."""
    registry = _get_registry()
    return jsonify(registry.list_all())


@dashboard_bp.route("/api/sandbox/<sandbox_id>/status")
@require_login
def api_sandbox_status(sandbox_id: str):
    """JSON API: sandbox status."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return jsonify({"error": "not found"}), 404
    return jsonify(sb.status())


# ---------------------------------------------------------------------------
# Template filters
# ---------------------------------------------------------------------------

def _register_filters(app: Flask) -> None:
    """Register custom Jinja2 template filters."""

    @app.template_filter("timeago")
    def timeago_filter(iso_str: str) -> str:
        """Format an ISO timestamp as a relative time string."""
        try:
            dt = datetime.fromisoformat(iso_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            now = datetime.now(timezone.utc)
            delta = now - dt
            seconds = int(delta.total_seconds())
            if seconds < 60:
                return f"{seconds}s ago"
            if seconds < 3600:
                return f"{seconds // 60}m ago"
            if seconds < 86400:
                return f"{seconds // 3600}h ago"
            return f"{seconds // 86400}d ago"
        except (ValueError, TypeError):
            return str(iso_str)

    @app.template_filter("truncate_id")
    def truncate_id_filter(value: str, length: int = 8) -> str:
        return value[:length] if value else ""

    @app.template_filter("tojson_pretty")
    def tojson_pretty_filter(value: Any) -> str:
        return json.dumps(value, indent=2, default=str)


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app(
    registry: SandboxRegistry | None = None,
    backend: Any | None = None,
) -> Flask:
    """Create and configure the LASSO dashboard Flask application.

    Args:
        registry: A SandboxRegistry instance for managing sandboxes.
                  A new empty registry is created if None.
        backend:  A ContainerBackend instance (Docker, Podman, etc.).
                  Native subprocess mode is used if None.

    Returns:
        A configured Flask application.

    Example:
        app = create_app()
        app.run(host="127.0.0.1", port=5000, debug=True)
    """
    app = Flask(
        __name__,
        template_folder=str(Path(__file__).parent / "templates"),
    )

    app.config["REGISTRY"] = registry or SandboxRegistry(backend=backend)
    app.config["BACKEND"] = backend
    app.config["SECRET_KEY"] = os.environ.get("LASSO_SECRET_KEY", secrets.token_hex(32))

    app.register_blueprint(dashboard_bp)

    # REST API v1
    from lasso.api import api_v1_bp
    app.register_blueprint(api_v1_bp)

    # Dashboard authentication + CSRF
    init_dashboard_auth(app)

    # Prometheus metrics
    from lasso.api.metrics import init_metrics
    init_metrics(app)

    _register_filters(app)

    # Session cookie hardening
    app.config["SESSION_COOKIE_SECURE"] = not app.debug
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["PERMANENT_SESSION_LIFETIME"] = 3600

    @app.after_request
    def set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"

        # CORS — restrictive by default (no cross-origin access)
        response.headers["Access-Control-Allow-Origin"] = "null"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, X-API-Key, X-CSRF-Token"

        # Content Security Policy
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "img-src 'self' data:; "
            "connect-src 'self'; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self'"
        )

        return response

    # Register atexit handler to gracefully shut down registry when Flask stops
    reg = app.config["REGISTRY"]
    atexit.register(reg.shutdown)

    return app


# ---------------------------------------------------------------------------
# Standalone runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app = create_app()
    print("LASSO Dashboard starting on http://127.0.0.1:5000")
    print("Note: pip install flask  (if not already installed)")
    app.run(host="127.0.0.1", port=5000, debug=os.environ.get("FLASK_DEBUG", "0") == "1")
