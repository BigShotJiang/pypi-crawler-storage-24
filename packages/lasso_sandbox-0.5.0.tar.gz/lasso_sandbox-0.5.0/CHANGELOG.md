# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.1] - 2026-03-22

### Fixed
- Project URLs updated from Tailscale IPs to GitHub (ClawWorksCo/lasso-sandbox)
- PyPI package metadata now points to correct public repository

## [0.4.0] - 2026-03-22

### Added
- `lasso compliance report dora` command to generate DORA and EU AI Act compliance evidence reports with article-level mapping from audit logs
- `lasso doctor` command with 10 comprehensive system diagnostic checks and `--fix` flag for auto-remediation
- `lasso quickstart` command for one-command setup (auto-detects agent, initializes config, creates sandbox)
- `lasso profile install` command to install community profiles from bundled profile pack
- 5 community profiles: `frontend-dev`, `data-science`, `ci-runner`, `banking-norway`, `healthcare`
- gVisor and Kata Containers isolation levels for stronger sandbox containment
- Syslog log forwarding (UDP/TCP/Unix socket) for SIEM integration
- 30 real Docker integration tests covering container escape, network isolation, E2E attack scenarios, filesystem isolation, and audit verification
- PyPI publishing setup with `lasso-sandbox` package name and Makefile
- CVE-2025-59536 case study documentation
- External signing key documentation with practical examples

### Changed
- Standardized CLI error and success message formatting
- First-run experience now auto-creates `~/.lasso/` directory
- Total test count: 1714 unit tests, 44 integration tests

## [0.3.1] - 2026-03-22

### Security
- Install iptables in container image so network firewall rules actually apply (was silently missing)
- Fail sandbox startup when iptables rules fail instead of silent continue
- Remove unauthenticated API bypass when no API keys are configured (now returns 401)
- Add `@require_login` to dashboard `/api/sandboxes` routes
- Fix audit log rotation chain breakage (reset hash chain per rotated file)
- Add SSRF blocking in webhook test endpoint (reject private/loopback IPs)
- Restrict `audit verify` to home/tmp paths to prevent file oracle attacks
- Fix MCP `file_read`/`file_write` command injection via `shlex.quote()`
- Add MCP `sandbox_create` working directory validation
- Fix command gate `blocked_args` short flag bypass (`-f` vs `--force`)
- Fix sed `DANGEROUS_ARGS` pattern that incorrectly blocked all sed usage
- Add interpreter commands to `DANGEROUS_ARGS` (`python3 -c`, `node -e`, etc.)
- Add `no-new-privileges` to container `security_opt`
- Include timestamp in webhook HMAC signature to prevent replay attacks
- Add signing key co-location warning when key is stored next to audit logs
- Profile name path traversal prevention
- API key file permissions set to `chmod 0o600`
- Remove API key query parameter support (header-only authentication)

### Fixed
- Remove false seccomp claim from README
- Fix documentation inconsistencies (step count, provider count)
- Add honest command gate limitations documentation

### Added
- `bank-analysis` as a real builtin profile
- 74 new security regression tests (1714 total)

## [0.3.0] - 2026-03-19

### Added
- 5 new agent providers: Cursor, Aider, Goose, Gemini CLI, and Codex (9 total supported agents)
- Zero-config `lasso run <agent>` command that auto-selects profile and generates agent-specific configuration
- Agent alias resolution (e.g., `claude` resolves to `claude-code`)
- Git config auto-injection (`user.name`/`user.email` detected and passed into sandbox)
- Credential passthrough via `--env KEY=VALUE` and `--pass-env` CLI flags
- `extra_env` field on `SandboxProfile` for programmatic environment variable injection
- Profile Modes for gradual authorization (audit, standard, privileged)
- MCP server security policy enforcement with sandbox-level access control
- Security review framework for pre-deployment profile auditing
- Checkpoint versioning for tracking verified LASSO releases
- VS Code IDE support as fourth agent provider (shell wrapper, settings.json generation)
- `writable_paths` validation in `FilesystemConfig` to block system-critical mounts
- Database access blocking (SSMS/MSSQL, PostgreSQL, MySQL, MongoDB, Redis)
- GitHub OAuth device flow authentication
- Air-gapped deployment guide
- CI/CD pipeline examples for GitHub Actions, GitLab CI, and Azure DevOps
- Architecture documentation
- HTML presentation materials (English and Norwegian) with interactive demo
- Lasso rope SVG logo and branding
- 201 new tests (1640 total)

### Changed
- Renamed to "Layered Agent Sandbox Security Orchestrator"
- Profiles renamed: `data-analysis` to `offline`, `risk-analysis` to `strict`
- MCP server test coverage expanded from 40 to 73 tests
- Dashboard now surfaces all security controls on sandbox detail page
- Podman-first container strategy with Docker fallback

### Fixed
- Critical: profile mode was ignored in BLACKLIST command mode
- VS Code shell wrapper and Windows support issues
- 6 security issues in `writable_paths` validation and security audit
- Critical checkpoint versioning issues (file lock, HMAC signing, TOCTOU)
- 4 MCP server security bypass vulnerabilities (handshake requirement, null client enforcement)

## [0.2.0] - 2026-03-16

### Added
- REST API with 15+ endpoints: full CRUD for sandboxes, profile management, audit log access, system health
- API key authentication with `X-API-Key` header and rate limiting (100 req/min)
- MCP server with JSON-RPC 2.0 transport (7 tools: `sandbox_exec`, `sandbox_create/stop/status/list`, `file_read/write`)
- Enterprise dashboard with dark theme (1,700+ lines custom CSS, zero external dependencies)
  - Real-time HTMX live updates (5s refresh)
  - Terminal-style command executor
  - Tabbed profile editor (7 tabs, keyboard navigation)
  - Audit log viewer with filtering and pagination
  - Token authentication and CSRF protection
  - Mobile responsive with ARIA accessibility labels
- Python SDK for programmatic LASSO control (local + remote modes, context managers)
- Webhook support for sandbox events with HMAC signing, async dispatch, event filtering, and retry
- GitHub Copilot Enterprise provider with `copilot-instructions.md` and org auth system
- Warm pool for pre-provisioned sandbox containers
- Profile sharing: export/import with integrity hashes, versioning, team directories (`LASSO_PROFILE_DIR`), diff/compare tool
- State persistence across restarts via `~/.lasso/state.json`
- OpenAPI 3.0 spec (`GET /api/v1/openapi.json`) with Swagger UI at `/api/v1/docs`
- Prometheus metrics endpoint (`GET /metrics` with 5 metric families)
- Graceful shutdown handlers (SIGINT/SIGTERM/SIGBREAK, atexit)
- Audit log rotation (`max_log_size_mb` + `rotation_count`)
- Unicode lookalike path traversal attack blocking
- Compliance documentation: DORA mapping (Article 5-30), EU AI Act mapping (Article 9-15)
- Security threat model with CVE case studies
- Windows compatibility: platform-aware defaults, Docker Desktop path conversion, `ntpath.basename`, read-only file cleanup

### Changed
- Dashboard auth upgraded with CSRF protection on all POST forms
- Command gate expanded to 6-layer validation (null bytes, control chars, URL-encoded traversal, symlinks, dangerous args for 25+ commands, whitelist/blacklist)
- Network enforcement: iptables rules applied to containers on start
- Test suite: 576 unit + 96 security regression + 68 API + 40 MCP + 40 Copilot + 28 dashboard auth tests

## [0.1.0] - 2026-03-16

### Added
- Core sandbox orchestrator with Docker backend
- Command gate with whitelist/blacklist modes for controlling agent tool access
- Tamper-evident audit logging with SHA-256 hash chain verification
- Security profiles (`default`, `strict`, `permissive`) with TOML configuration
- Network policy enforcement (allow/deny rules per sandbox)
- Filesystem isolation with configurable read-only and writable mount paths
- Resource limits (CPU, memory, PIDs) per sandbox
- Agent providers: OpenCode, Claude Code, GitHub Copilot
- CLI: `lasso create`, `lasso exec`, `lasso stop`, `lasso audit`, `lasso profile`
- `lasso setup` for guided first-time configuration
- Dashboard web UI for sandbox monitoring and management

[0.4.1]: https://github.com/ClawWorksCo/lasso-sandbox/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/ClawWorksCo/lasso-sandbox/compare/v0.3.1...v0.4.0
[0.3.1]: https://github.com/ClawWorksCo/lasso-sandbox/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/ClawWorksCo/lasso-sandbox/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/ClawWorksCo/lasso-sandbox/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/ClawWorksCo/lasso-sandbox/releases/tag/v0.1.0
