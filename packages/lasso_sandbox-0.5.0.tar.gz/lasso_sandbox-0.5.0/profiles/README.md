# LASSO Community Profiles

Pre-built sandbox profiles for common environments. Each profile is a
self-contained TOML file that can be installed with a single command.

## Quick Start

```bash
# Install a profile to ~/.lasso/profiles/
lasso profile install frontend-dev

# Use it immediately
lasso create frontend-dev --dir .

# Or in interactive mode
lasso interactive frontend-dev --dir .
```

## Available Profiles

| Profile | Network | Memory | Use Case |
|---------|---------|--------|----------|
| `frontend-dev` | restricted (npm, GitHub, jsDelivr) | 4 GB | Node.js, npm, web tooling |
| `data-science` | none | 16 GB | Python, Jupyter, R -- offline for data protection |
| `ci-runner` | restricted (package registries) | 8 GB | CI/CD pipelines with broad tool access |
| `banking-norway` | none | 8 GB | Norwegian banking compliance (DORA, EU AI Act) |
| `healthcare` | none | 4 GB | HIPAA environments -- no command output logging |

## Profile Details

### frontend-dev

Frontend development sandbox with Node.js, npm, npx, git, and common
Unix tools. Network is restricted to npm registry, GitHub, and jsDelivr CDN.

### data-science

Data science and machine learning sandbox with Python, Jupyter, and R.
Network is completely disabled to prevent data exfiltration. High memory
limit (16 GB) for large datasets and model training.

### ci-runner

CI/CD pipeline runner with broad language support: Python, Node.js, Go,
Rust, C/C++. Network restricted to package registries. 10-minute execution
timeout per command. Runs in autonomous mode for unattended operation.

### banking-norway

Strict isolation profile for Norwegian banking compliance. No network
access. Git is read-only with history content blocked to prevent PII
exposure from commit diffs. Full audit trail with HMAC signing. Meets
DORA, EU AI Act, and ISO 27001 requirements.

### healthcare

HIPAA-compliant sandbox with no network and no command output logging.
Command output is excluded from audit logs to prevent Protected Health
Information (PHI) from appearing in the audit trail. Full audit with
HMAC signing for tamper detection.

## Customizing

Profiles are standard TOML files. After installing, edit the copy at
`~/.lasso/profiles/<name>.toml` to adjust settings for your environment.
The original bundled profile is not modified.

## Contributing

To add a new community profile, create a TOML file in this directory
following the existing format. The file must parse successfully through
`SandboxProfile` validation. Test with:

```bash
python3 -c "from lasso.config.profile import load_profile_from_path; load_profile_from_path('profiles/your-profile.toml')"
```
