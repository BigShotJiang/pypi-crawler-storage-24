"""Load role.yaml and construct PydanticAI agents."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from pydantic_ai import Agent
from pydantic_ai.settings import ModelSettings

from initrunner._compat import require_provider
from initrunner._yaml import load_raw_yaml
from initrunner.agent.schema.base import ModelConfig
from initrunner.agent.schema.role import RoleDefinition

logger = logging.getLogger(__name__)

_PROVIDER_API_KEY_ENVS: dict[str, str] = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "google": "GOOGLE_API_KEY",
    "groq": "GROQ_API_KEY",
    "mistral": "MISTRAL_API_KEY",
    "cohere": "CO_API_KEY",
    "xai": "XAI_API_KEY",
}


class RoleLoadError(Exception):
    """Raised when a role definition cannot be loaded or validated."""


def load_role(path: Path) -> RoleDefinition:
    """Read a YAML file and validate it as a RoleDefinition."""
    from initrunner.deprecations import validate_role_dict

    raw = load_raw_yaml(path, RoleLoadError)
    try:
        role, _hits = validate_role_dict(raw)
    except (ValueError, Exception) as e:
        raise RoleLoadError(f"Validation failed for {path}:\n{e}") from e
    return role


def _build_model(model_config: ModelConfig):
    """Build a PydanticAI model — string for standard providers, OpenAIChatModel for custom."""
    if not model_config.needs_custom_provider():
        env_var = model_config.api_key_env or _PROVIDER_API_KEY_ENVS.get(model_config.provider)
        if env_var and not os.environ.get(env_var):
            raise RoleLoadError(
                f"API key not found. Set the {env_var} environment variable:\n"
                f"  export {env_var}=your-key-here\n"
                f"Or add it to a .env file in your role directory or ~/.initrunner/.env"
            )
        return model_config.to_model_string()

    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    base_url = model_config.base_url
    if model_config.provider == "ollama":
        from initrunner.services.providers import OLLAMA_DEFAULT_BASE_URL

        base_url = base_url or OLLAMA_DEFAULT_BASE_URL
        api_key = "ollama"
    elif model_config.api_key_env:
        api_key = os.environ.get(model_config.api_key_env)
        if not api_key:
            raise RoleLoadError(
                f"Environment variable '{model_config.api_key_env}' is not set "
                f"(required by model config)"
            )
    else:
        api_key = None

    if base_url and ("localhost" in base_url or "127.0.0.1" in base_url):
        if Path("/.dockerenv").exists():
            logger.warning(
                "Detected Docker environment with localhost base_url '%s'. "
                "Consider using 'http://host.docker.internal:11434/v1' instead.",
                base_url,
            )

    provider = OpenAIProvider(base_url=base_url, api_key=api_key)
    return OpenAIChatModel(model_config.name, provider=provider)


def _validate_provider(role: RoleDefinition) -> None:
    """Check the provider SDK is installed, raising RoleLoadError if not."""
    try:
        require_provider(role.spec.model.provider)
    except RuntimeError as e:
        raise RoleLoadError(str(e)) from None


def _validate_reasoning(role: RoleDefinition) -> None:
    """Validate reasoning config against tool declarations."""
    config = role.spec.reasoning
    if config is None:
        return

    from initrunner.agent.schema.tools import TodoToolConfig

    has_todo = any(isinstance(t, TodoToolConfig) for t in role.spec.tools)

    if config.pattern in ("todo_driven", "plan_execute") and not has_todo:
        raise RoleLoadError(
            f"reasoning.pattern '{config.pattern}' requires a 'todo' tool in spec.tools"
        )
    if config.pattern == "reflexion" and config.reflection_rounds == 0:
        raise RoleLoadError("reasoning.pattern 'reflexion' requires reflection_rounds > 0")


def _resolve_skills_and_merge(
    role: RoleDefinition,
    role_dir: Path | None,
    extra_skill_dirs: list[Path] | None,
) -> tuple[str, list, set[Path]]:
    """Resolve skills, log warnings, merge tools, and compose the system prompt.

    Returns ``(system_prompt, all_tools, explicit_skill_paths)``.
    """
    system_prompt = role.spec.role
    all_tools = list(role.spec.tools)
    explicit_paths: set[Path] = set()

    if not role.spec.skills:
        return system_prompt, all_tools, explicit_paths

    from initrunner.agent.skills import (
        build_skill_system_prompt,
        merge_skill_tools,
        resolve_skills,
    )

    resolved_skills = resolve_skills(role.spec.skills, role_dir, extra_skill_dirs)
    explicit_paths = {rs.source_path for rs in resolved_skills}

    for rs in resolved_skills:
        for req in rs.requirement_statuses:
            if not req.met:
                logger.warning(
                    "Skill '%s': unmet %s -- %s",
                    rs.definition.frontmatter.name,
                    req.kind,
                    req.detail,
                )

    all_tools = merge_skill_tools(resolved_skills, role.spec.tools)
    skill_prompt = build_skill_system_prompt(resolved_skills)
    if skill_prompt:
        system_prompt = f"{role.spec.role}\n\n{skill_prompt}"

    return system_prompt, all_tools, explicit_paths


def _create_agent(
    role: RoleDefinition,
    system_prompt: str,
    toolsets: list,
    output_type: type,
    instrument: Any = None,
    prepare_tools: Any = None,
) -> Agent:
    """Build the model and construct the PydanticAI Agent."""
    model_settings_kwargs: dict[str, Any] = {"max_tokens": role.spec.model.max_tokens}
    if not role.spec.model.is_reasoning_model():
        model_settings_kwargs["temperature"] = role.spec.model.temperature
    kwargs: dict[str, Any] = {
        "output_type": output_type,
        "system_prompt": system_prompt,
        "model_settings": ModelSettings(**model_settings_kwargs),
        "toolsets": toolsets if toolsets else None,
    }
    if instrument is not None:
        kwargs["instrument"] = instrument
    if prepare_tools is not None:
        kwargs["prepare_tools"] = prepare_tools
    return Agent(_build_model(role.spec.model), **kwargs)


def build_agent(
    role: RoleDefinition,
    role_dir: Path | None = None,
    output_type: type | None = None,
    extra_skill_dirs: list[Path] | None = None,
    *,
    prefer_async: bool = False,
) -> Agent:
    """Construct a PydanticAI Agent from a validated RoleDefinition."""
    _validate_provider(role)
    _validate_reasoning(role)
    system_prompt, all_tools, explicit_paths = _resolve_skills_and_merge(
        role, role_dir, extra_skill_dirs
    )

    # Resolve output type: explicit param wins, then role config, then str default
    if output_type is None:
        from initrunner.agent.output import resolve_output_type

        output_type = resolve_output_type(role.spec.output, role_dir)

    from initrunner.agent.tools import build_toolsets

    toolsets = build_toolsets(all_tools, role, role_dir=role_dir, prefer_async=prefer_async)

    # Auto-discovered skills — progressive disclosure via activate_skill tool
    auto_skill_activated: set[str] = set()
    if role.spec.auto_skills.enabled:
        from initrunner.agent.auto_skills import (
            build_activate_skill_toolset,
            build_catalog_prompt,
            discover_skills,
        )

        discovered = discover_skills(
            role_dir=role_dir,
            extra_dirs=extra_skill_dirs,
            max_skills=role.spec.auto_skills.max_skills,
            exclude_paths=explicit_paths,
        )
        if discovered:
            from initrunner.agent.tool_events import wrap_observable

            system_prompt = f"{system_prompt}\n\n{build_catalog_prompt(discovered)}"
            ts = build_activate_skill_toolset(discovered, auto_skill_activated)
            toolsets.append(wrap_observable(ts))

    # Tool search meta-tool — hides tools behind BM25 search to reduce context
    prepare_tools = None
    if role.spec.tool_search.enabled:
        from initrunner.agent.tools.tool_search import (
            ToolSearchManager,
            build_tool_search_toolset,
        )

        ts_config = role.spec.tool_search
        manager = ToolSearchManager(
            always_available=ts_config.always_available,
            max_results=ts_config.max_results,
            threshold=ts_config.threshold,
        )
        from initrunner.agent.tool_events import wrap_observable

        toolsets.append(wrap_observable(build_tool_search_toolset(manager)))
        prepare_tools = manager.prepare_tools_callback
        system_prompt += (
            "\n\nIMPORTANT: You have many tools available beyond what you currently see. "
            "Most are hidden to save context. When no visible tool obviously fits the "
            "user's request, ALWAYS call `search_tools` before saying you cannot do "
            "something (e.g. search_tools('send slack message'), search_tools('read csv')). "
            "Matching tools will then become available for you to call."
        )

    instrument = None
    if role.spec.observability is not None:
        from initrunner.observability import get_instrumentation_settings

        instrument = get_instrumentation_settings(role.spec.observability)

    agent = _create_agent(
        role,
        system_prompt,
        toolsets,
        output_type,
        instrument=instrument,
        prepare_tools=prepare_tools,
    )

    # Register dynamic system prompt for procedural memory injection.
    # The closure reads ``_memory_store`` from the agent so the already-open
    # store is reused instead of opening a second handle (which would hit
    # LanceDB table locks).
    if role.spec.memory is not None and role.spec.memory.procedural.enabled:
        from initrunner.agent.memory_ops import build_memory_system_prompt

        @agent.system_prompt
        def _procedural_context() -> str:
            store = getattr(agent, "_memory_store", None)
            return build_memory_system_prompt(role, store=store)

    # Register dynamic system prompt for resume context injection.
    # The ``_resume_context`` attribute is set by interactive.py when
    # resuming a session with memory available.
    if role.spec.memory is not None:

        @agent.system_prompt
        def _resume_context() -> str:
            return getattr(agent, "_resume_context", "")

    return agent


def _load_dotenv(role_dir: Path | None) -> None:
    """Load .env files — local first, then global as fallback.

    Uses ``override=False`` so existing env vars always win.
    Local is loaded before global so project-local values take precedence.
    """
    from dotenv import load_dotenv

    if role_dir is not None:
        local_env = role_dir / ".env"
        if local_env.is_file():
            load_dotenv(local_env, override=False)
    from initrunner.config import get_global_env_path

    global_env = get_global_env_path()
    if global_env.is_file():
        load_dotenv(global_env, override=False)


def _apply_model_override(role: RoleDefinition, provider: str, name: str) -> RoleDefinition:
    """Return a copy of *role* with its model config replaced."""
    old_model = role.spec.model
    update: dict[str, Any] = {"provider": provider, "name": name}
    if provider != old_model.provider:
        update["base_url"] = None
        update["api_key_env"] = None
    new_model = old_model.model_copy(update=update)
    new_spec = role.spec.model_copy(update={"model": new_model})
    return role.model_copy(update={"spec": new_spec})


def load_and_build(
    path: Path,
    extra_skill_dirs: list[Path] | None = None,
    model_override: str | None = None,
) -> tuple[RoleDefinition, Agent]:
    """Load a role YAML and build the corresponding agent.

    When *model_override* is a ``provider:model`` string the role's model
    config is replaced before the agent is built.  Otherwise, if the role
    was installed via the registry and the user set a provider override,
    that override is applied automatically.
    """
    _load_dotenv(path.parent)
    role = load_role(path)
    if model_override:
        from initrunner.model_aliases import parse_model_string

        new_provider, new_name = parse_model_string(model_override)
        role = _apply_model_override(role, new_provider, new_name)
    else:
        # Apply registry overrides for installed roles (if any)
        role = _apply_registry_overrides(role, path)
    agent = build_agent(role, role_dir=path.parent, extra_skill_dirs=extra_skill_dirs)
    return role, agent


def _apply_registry_overrides(role: RoleDefinition, path: Path) -> RoleDefinition:
    """Apply provider/model overrides from the registry manifest, if present."""
    try:
        from initrunner.registry import get_overrides_for_path

        overrides = get_overrides_for_path(path)
    except Exception:
        return role

    if not overrides:
        return role

    provider = overrides.get("provider", "")
    model = overrides.get("model", "")
    if not provider or not model:
        return role

    logger.info(
        "Applying registry override: %s/%s (original: %s/%s)",
        provider,
        model,
        role.spec.model.provider,
        role.spec.model.name,
    )
    return _apply_model_override(role, provider, model)
