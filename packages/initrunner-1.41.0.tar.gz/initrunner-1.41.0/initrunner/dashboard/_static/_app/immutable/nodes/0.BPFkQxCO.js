import{c as E,a as f,d as Te,b as Q,f as $,s as V,e as H}from"../chunks/BDGTMFSm.js";import{f as S,p as ze,o as Ne,G as De,g as e,e as u,t as C,a as Ce,s as _,c as d,r as l,u as A,b as L,d as $e,$ as Le,n as We,C as Ge}from"../chunks/BWzthV5F.js";import{s as Oe}from"../chunks/BI66VKG7.js";import{l as X,s as Y,p as Re,i as O,b as Je}from"../chunks/PnyBwwNh.js";import{I as Z,s as ee,e as re,d as F,b as J,i as oe,c as Qe,a as Xe}from"../chunks/BZHPAbyX.js";import{c as fe}from"../chunks/BDKFmoTa.js";import{p as he}from"../chunks/CPU3SeP9.js";import{a as Ee,s as Ke}from"../chunks/DHLcPB6i.js";import"../chunks/D7pp4EeN.js";import{C as Ye}from"../chunks/BzYvNwrB.js";import{W as we}from"../chunks/BFelDNjG.js";import{U as Me}from"../chunks/CGS9PC2Q.js";import{b as Ze}from"../chunks/YkFwJzVB.js";import{g as et}from"../chunks/Y_xSd7fF.js";import{l as tt}from"../chunks/CtmwM1gD.js";import{f as at}from"../chunks/Mag4q-3G.js";import{f as rt}from"../chunks/DODYeANV.js";import{P as ke}from"../chunks/DPH8D0PK.js";import{S as ot}from"../chunks/D5JiSx3U.js";const nt=!1,Jt=Object.freeze(Object.defineProperty({__proto__:null,ssr:nt},Symbol.toStringTag,{value:"Module"}));function Pe(x,i){const t=X(i,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1"}],["path",{d:"M10 21V8a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H3"}]];Z(x,Y({name:"blocks"},()=>t,{get iconNode(){return c},children:(v,k)=>{var p=E(),a=S(p);ee(a,i,"default",{}),f(v,p)},$$slots:{default:!0}}))}function je(x,i){const t=X(i,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z"}],["circle",{cx:"12",cy:"12",r:"10"}]];Z(x,Y({name:"compass"},()=>t,{get iconNode(){return c},children:(v,k)=>{var p=E(),a=S(p);ee(a,i,"default",{}),f(v,p)},$$slots:{default:!0}}))}function qe(x,i){const t=X(i,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["path",{d:"M12 20v2"}],["path",{d:"M12 2v2"}],["path",{d:"M17 20v2"}],["path",{d:"M17 2v2"}],["path",{d:"M2 12h2"}],["path",{d:"M2 17h2"}],["path",{d:"M2 7h2"}],["path",{d:"M20 12h2"}],["path",{d:"M20 17h2"}],["path",{d:"M20 7h2"}],["path",{d:"M7 20v2"}],["path",{d:"M7 2v2"}],["rect",{x:"4",y:"4",width:"16",height:"16",rx:"2"}],["rect",{x:"8",y:"8",width:"8",height:"8",rx:"1"}]];Z(x,Y({name:"cpu"},()=>t,{get iconNode(){return c},children:(v,k)=>{var p=E(),a=S(p);ee(a,i,"default",{}),f(v,p)},$$slots:{default:!0}}))}function Ie(x,i){const t=X(i,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["rect",{x:"16",y:"16",width:"6",height:"6",rx:"1"}],["rect",{x:"2",y:"16",width:"6",height:"6",rx:"1"}],["rect",{x:"9",y:"2",width:"6",height:"6",rx:"1"}],["path",{d:"M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"}],["path",{d:"M12 12V8"}]];Z(x,Y({name:"network"},()=>t,{get iconNode(){return c},children:(v,k)=>{var p=E(),a=S(p);ee(a,i,"default",{}),f(v,p)},$$slots:{default:!0}}))}function st(x,i){const t=X(i,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}],["path",{d:"M9 3v18"}],["path",{d:"m16 15-3-3 3-3"}]];Z(x,Y({name:"panel-left-close"},()=>t,{get iconNode(){return c},children:(v,k)=>{var p=E(),a=S(p);ee(a,i,"default",{}),f(v,p)},$$slots:{default:!0}}))}function it(x,i){const t=X(i,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}],["path",{d:"M9 3v18"}],["path",{d:"m14 9 3 3-3 3"}]];Z(x,Y({name:"panel-left-open"},()=>t,{get iconNode(){return c},children:(v,k)=>{var p=E(),a=S(p);ee(a,i,"default",{}),f(v,p)},$$slots:{default:!0}}))}function Fe(x,i){const t=X(i,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["path",{d:"M3 7V5a2 2 0 0 1 2-2h2"}],["path",{d:"M17 3h2a2 2 0 0 1 2 2v2"}],["path",{d:"M21 17v2a2 2 0 0 1-2 2h-2"}],["path",{d:"M7 21H5a2 2 0 0 1-2-2v-2"}],["circle",{cx:"12",cy:"12",r:"1"}],["path",{d:"M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0"}]];Z(x,Y({name:"scan-eye"},()=>t,{get iconNode(){return c},children:(v,k)=>{var p=E(),a=S(p);ee(a,i,"default",{}),f(v,p)},$$slots:{default:!0}}))}var lt=$('<span class="w-full text-center font-mono text-sm font-medium text-accent-primary">></span>'),ct=$('<span class="font-mono text-sm font-medium uppercase tracking-[0.08em] text-fg-faint"><span class="text-accent-primary">></span> InitRunner</span>'),dt=$('<span class="font-mono"> </span>'),pt=$("<a><!> <!></a>"),ft=$('<a><!> <span class="font-mono"> </span></a>'),ut=$('<div class="absolute left-full top-0 z-10 ml-1 min-w-[160px] border border-edge bg-surface-1 py-1 shadow-lg"><div class="px-3 py-1.5 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-fg-faint">Orchestration</div> <!></div>'),vt=$('<div class="relative" role="group"><button aria-label="Orchestration"><!></button> <!></div>'),mt=$('<a><!> <span class="font-mono"> </span></a>'),gt=$('<div class="ml-3"></div>'),ht=$('<button><!> <span class="font-mono">Orchestration</span> <!></button> <!>',1),xt=$('<span class="font-mono"> </span>'),bt=$("<a><!> <!></a>"),_t=$('<nav class="relative flex h-full flex-col border-r border-edge bg-[#111113] transition-[width] duration-150"><div class="pointer-events-none absolute right-0 top-0 h-24 w-px bg-gradient-to-b from-accent-primary/15 via-transparent to-transparent"></div> <div class="flex h-12 items-center border-b border-edge px-3"><!></div> <div class="flex flex-1 flex-col gap-1 p-2"><!> <!> <!></div> <div class="border-t border-edge p-2"><button class="flex w-full items-center justify-center py-1.5 text-fg-faint transition-[color,background-color] duration-150 hover:bg-surface-2 hover:text-fg-muted"><!></button></div></nav>');function yt(x,i){ze(i,!0);let t=Re(i,"collapsed",3,!1);function c(n){return n==="/"?he.url.pathname==="/":he.url.pathname.startsWith(n)}const v=[{href:"/",label:"Launchpad",icon:je},{href:"/agents",label:"Agents",icon:Pe}],k=[{href:"/compose",label:"Compose",icon:we},{href:"/teams",label:"Teams",icon:Me}],p=[{href:"/audit",label:"Audit",icon:Fe},{href:"/system",label:"System",icon:qe}];let a=L(!1),P=L(!1);Ne(()=>{Ee("sidebar-orch-open")==="true"&&u(a,!0)});const K=A(()=>he.url.pathname.startsWith("/compose")||he.url.pathname.startsWith("/teams"));De(()=>{e(K)&&u(a,!0)});function B(){e(K)||(u(a,!e(a)),Ke("sidebar-orch-open",String(e(a))))}function G(n){const s=n.currentTarget.closest('[role="group"]');s!=null&&s.contains(n.relatedTarget)||u(P,!1)}var U=_t(),N=_(d(U),2),xe=d(N);{var ue=n=>{var s=lt();f(n,s)},be=n=>{var s=ct();f(n,s)};O(xe,n=>{t()?n(ue):n(be,-1)})}l(N);var te=_(N,2),ne=d(te);re(ne,17,()=>v,oe,(n,s)=>{const b=A(()=>c(e(s).href));var r=pt(),M=d(r);fe(M,()=>e(s).icon,(g,y)=>{y(g,{size:15,strokeWidth:1.5})});var W=_(M,2);{var I=g=>{var y=dt(),D=d(y,!0);l(y),C(()=>V(D,e(s).label)),f(g,y)};O(W,g=>{t()||g(I)})}l(r),C(()=>{F(r,"href",e(s).href),J(r,1,`group flex items-center gap-2.5 px-2.5 py-2 text-[13px] transition-[color,background-color] duration-150 ${e(b)?"bg-accent-primary/10 text-accent-primary":"text-fg-faint hover:bg-surface-2 hover:text-fg-muted"}`),F(r,"title",t()?e(s).label:void 0)}),f(n,r)});var ve=_(ne,2);{var _e=n=>{var s=vt(),b=d(s),r=d(b);Ie(r,{size:15,strokeWidth:1.5}),l(b);var M=_(b,2);{var W=I=>{var g=ut(),y=_(d(g),2);re(y,17,()=>k,oe,(D,T)=>{const ie=A(()=>c(e(T).href));var w=ft(),j=d(w);fe(j,()=>e(T).icon,(ce,q)=>{q(ce,{size:15,strokeWidth:1.5})});var R=_(j,2),le=d(R,!0);l(R),l(w),C(()=>{F(w,"href",e(T).href),J(w,1,`flex items-center gap-2.5 px-3 py-2 text-[13px] transition-[color,background-color] duration-150 ${e(ie)?"bg-accent-primary/10 text-accent-primary":"text-fg-muted hover:bg-surface-2 hover:text-fg"}`),V(le,e(T).label)}),H("focus",w,()=>u(P,!0)),H("blur",w,G),f(D,w)}),l(g),f(I,g)};O(M,I=>{e(P)&&I(W)})}l(s),C(()=>{J(b,1,`group flex w-full items-center justify-center px-2.5 py-2 text-[13px] transition-[color,background-color] duration-150 ${e(K)?"bg-accent-primary/10 text-accent-primary":"text-fg-faint hover:bg-surface-2 hover:text-fg-muted"}`),F(b,"aria-expanded",e(P))}),H("mouseenter",s,()=>u(P,!0)),H("mouseleave",s,()=>u(P,!1)),H("focus",b,()=>u(P,!0)),H("blur",b,G),f(n,s)},o=n=>{var s=ht(),b=S(s),r=d(b);Ie(r,{size:15,strokeWidth:1.5});var M=_(r,4);{let g=A(()=>e(a)?"rotate-90":"");Ye(M,{size:12,strokeWidth:1.5,get class(){return`ml-auto transition-transform duration-150 ${e(g)??""}`}})}l(b);var W=_(b,2);{var I=g=>{var y=gt();re(y,21,()=>k,oe,(D,T)=>{const ie=A(()=>c(e(T).href));var w=mt(),j=d(w);fe(j,()=>e(T).icon,(ce,q)=>{q(ce,{size:15,strokeWidth:1.5})});var R=_(j,2),le=d(R,!0);l(R),l(w),C(()=>{F(w,"href",e(T).href),J(w,1,`group flex items-center gap-2.5 px-2.5 py-2 text-[13px] transition-[color,background-color] duration-150 ${e(ie)?"bg-accent-primary/10 text-accent-primary":"text-fg-faint hover:bg-surface-2 hover:text-fg-muted"}`),V(le,e(T).label)}),f(D,w)}),l(y),f(g,y)};O(W,g=>{e(a)&&g(I)})}C(()=>{J(b,1,`group flex w-full items-center gap-2.5 px-2.5 py-2 text-[13px] transition-[color,background-color] duration-150 ${e(K)?"text-accent-primary":"text-fg-faint hover:bg-surface-2 hover:text-fg-muted"}`),F(b,"aria-expanded",e(a))}),Q("click",b,B),f(n,s)};O(ve,n=>{t()?n(_e):n(o,-1)})}var h=_(ve,2);re(h,17,()=>p,oe,(n,s)=>{const b=A(()=>c(e(s).href));var r=bt(),M=d(r);fe(M,()=>e(s).icon,(g,y)=>{y(g,{size:15,strokeWidth:1.5})});var W=_(M,2);{var I=g=>{var y=xt(),D=d(y,!0);l(y),C(()=>V(D,e(s).label)),f(g,y)};O(W,g=>{t()||g(I)})}l(r),C(()=>{F(r,"href",e(s).href),J(r,1,`group flex items-center gap-2.5 px-2.5 py-2 text-[13px] transition-[color,background-color] duration-150 ${e(b)?"bg-accent-primary/10 text-accent-primary":"text-fg-faint hover:bg-surface-2 hover:text-fg-muted"}`),F(r,"title",t()?e(s).label:void 0)}),f(n,r)}),l(te);var z=_(te,2),m=d(z),me=d(m);{var se=n=>{it(n,{size:14})},ge=n=>{st(n,{size:14})};O(me,n=>{t()?n(se):n(ge,-1)})}l(m),l(z),l(U),C(()=>{Qe(U,`width: ${t()?"48px":"200px"}`),F(m,"aria-label",t()?"Expand sidebar":"Collapse sidebar")}),Q("click",m,function(...n){var s;(s=i.onToggle)==null||s.apply(this,n)}),f(x,U),Ce()}Te(["click"]);var $t=$('<div class="px-4 py-8 text-center text-[13px] text-fg-faint"> </div>'),kt=$('<span class="ml-auto truncate text-[13px] text-fg-faint"> </span>'),wt=$('<button><!> <span class="truncate"> </span> <!></button>'),Mt=$('<div class="px-3 pb-1 pt-2 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-fg-faint"> </div> <!>',1),Pt=$('<div class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"><div class="mx-auto mt-[15vh] w-full max-w-lg border border-accent-primary/10 bg-surface-1 shadow-2xl"><div class="flex items-center gap-3 border-b border-edge px-4 py-3"><!> <input placeholder="Search agents, compositions, teams..." class="w-full bg-transparent text-[14px] text-fg outline-none placeholder:text-fg-faint"/> <kbd class="shrink-0 rounded-full border border-edge bg-surface-2 px-2 py-0.5 font-mono text-[12px] text-fg-faint">ESC</kbd></div> <div class="max-h-[50vh] overflow-y-auto py-2"><!></div> <div class="flex items-center gap-4 border-t border-edge px-4 py-2 font-mono text-[12px] text-fg-faint"><span><kbd class="rounded-full border border-edge px-1.5">&#8593;&#8595;</kbd> navigate</span> <span><kbd class="rounded-full border border-edge px-1.5">&#8629;</kbd> select</span> <span><kbd class="rounded-full border border-edge px-1.5">esc</kbd> close</span></div></div></div>');function zt(x,i){ze(i,!0);let t=L(!1),c=L(""),v=L($e([])),k=L($e([])),p=L($e([])),a=L(0),P=L(void 0);const K=[{id:"nav-launchpad",label:"Launchpad",href:"/",icon:je,group:"Pages"},{id:"nav-agents",label:"Agents",href:"/agents",icon:Pe,group:"Pages"},{id:"nav-compose",label:"Compose",href:"/compose",icon:we,group:"Pages"},{id:"nav-audit",label:"Audit",href:"/audit",icon:Fe,group:"Pages"},{id:"nav-teams",label:"Teams",href:"/teams",icon:Me,group:"Pages"},{id:"nav-system",label:"System",href:"/system",icon:qe,group:"Pages"},{id:"action-new",label:"New Agent",href:"/agents/new",icon:ke,group:"Actions"},{id:"action-new-compose",label:"New Compose",href:"/compose/new",icon:ke,group:"Actions"},{id:"action-new-team",label:"New Team",href:"/teams/new",icon:ke,group:"Actions"}],B=A(()=>{const o=e(v).map(m=>({id:`agent-${m.id}`,label:m.name,sublabel:m.description,href:`/agents/${m.id}`,icon:Pe,group:"Agents"})),h=e(k).map(m=>({id:`compose-${m.id}`,label:m.name,sublabel:m.description,href:`/compose/${m.id}`,icon:we,group:"Compositions"})),z=e(p).map(m=>({id:`team-${m.id}`,label:m.name,sublabel:m.description,href:`/teams/${m.id}`,icon:Me,group:"Teams"}));return[...K,...o,...h,...z]}),G=A(()=>{if(!e(c).trim())return e(B);const o=e(c).toLowerCase();return e(B).filter(h=>h.label.toLowerCase().includes(o)||h.sublabel&&h.sublabel.toLowerCase().includes(o))}),U=A(()=>{const o=new Map;for(const h of e(G)){const z=o.get(h.group)||[];z.push(h),o.set(h.group,z)}return o}),N=A(()=>e(G));De(()=>{e(c),u(a,0)});function xe(){u(t,!e(t)),e(t)&&(u(c,""),u(a,0),te(),requestAnimationFrame(()=>{var o;return(o=e(P))==null?void 0:o.focus()}))}function ue(o){u(t,!1),et(o)}function be(o){if((o.metaKey||o.ctrlKey)&&o.key==="k"){o.preventDefault(),xe();return}if(e(t)){if(o.key==="Escape")o.preventDefault(),u(t,!1);else if(o.key==="ArrowDown")o.preventDefault(),u(a,Math.min(e(a)+1,e(N).length-1),!0);else if(o.key==="ArrowUp")o.preventDefault(),u(a,Math.max(e(a)-1,0),!0);else if(o.key==="Enter"){o.preventDefault();const h=e(N)[e(a)];h&&ue(h.href)}}}async function te(){try{const[o,h,z]=await Promise.all([tt().catch(()=>[]),at().catch(()=>[]),rt().catch(()=>[])]);u(v,o,!0),u(k,h,!0),u(p,z,!0)}catch{}}Ne(te);var ne=E();H("keydown",Le,be);var ve=S(ne);{var _e=o=>{var h=Pt(),z=d(h),m=d(z),me=d(m);ot(me,{size:16,class:"shrink-0 text-accent-primary/50"});var se=_(me,2);Xe(se),Je(se,r=>u(P,r),()=>e(P)),We(2),l(m);var ge=_(m,2),n=d(ge);{var s=r=>{var M=$t(),W=d(M);l(M),C(()=>V(W,`No results for "${e(c)??""}"`)),f(r,M)},b=r=>{const M=A(()=>({value:0}));var W=E(),I=S(W);re(I,17,()=>e(U),oe,(g,y)=>{var D=A(()=>Ge(e(y),2));let T=()=>e(D)[0],ie=()=>e(D)[1];var w=Mt(),j=S(w),R=d(j,!0);l(j);var le=_(j,2);re(le,17,ie,oe,(ce,q)=>{const Ae=A(()=>e(M).value++);var ae=wt(),Se=d(ae);fe(Se,()=>e(q).icon,(de,pe)=>{pe(de,{size:14,strokeWidth:1.75,class:"shrink-0 text-fg-faint"})});var ye=_(Se,2),He=d(ye,!0);l(ye);var Ue=_(ye,2);{var Ve=de=>{var pe=kt(),Be=d(pe,!0);l(pe),C(()=>V(Be,e(q).sublabel)),f(de,pe)};O(Ue,de=>{e(q).sublabel&&de(Ve)})}l(ae),C(()=>{J(ae,1,`flex w-full items-center gap-3 px-4 py-2 text-left text-[13px] transition-[background-color] duration-100 ${e(Ae)===e(a)?"bg-accent-primary/[0.08] text-fg":"text-fg-muted"}`),V(He,e(q).label)}),H("mouseenter",ae,()=>u(a,e(Ae),!0)),Q("click",ae,()=>ue(e(q).href)),f(ce,ae)}),C(()=>V(R,T())),f(g,w)}),f(r,W)};O(n,r=>{e(N).length===0?r(s):r(b,-1)})}l(ge),We(2),l(z),l(h),Q("click",h,()=>u(t,!1)),Q("keydown",h,r=>r.key==="Escape"&&u(t,!1)),Q("click",z,r=>r.stopPropagation()),Q("keydown",z,r=>r.stopPropagation()),Ze(se,()=>e(c),r=>u(c,r)),f(o,h)};O(ve,o=>{e(t)&&o(_e)})}f(x,ne),Ce()}Te(["click","keydown"]);var Nt=$('<div class="flex h-dvh flex-col overflow-hidden bg-background"><div class="flex flex-1 overflow-hidden"><!> <main class="min-w-0 flex-1 overflow-auto p-6 lg:p-8"><div class="mx-auto max-w-[1400px]"><!></div></main></div></div> <!>',1);function Ct(x,i){ze(i,!0);let t=L(!1);Ne(()=>{Ee("sidebar-collapsed")==="true"&&u(t,!0)});function c(){u(t,!e(t)),Ke("sidebar-collapsed",String(e(t)))}function v(N){(N.metaKey||N.ctrlKey)&&N.key==="b"&&(N.preventDefault(),c())}var k=Nt();H("keydown",Le,v);var p=S(k),a=d(p),P=d(a);yt(P,{get collapsed(){return e(t)},onToggle:c});var K=_(P,2),B=d(K),G=d(B);Oe(G,()=>i.children),l(B),l(K),l(a),l(p);var U=_(p,2);zt(U,{}),f(x,k),Ce()}function Qt(x,i){Ct(x,{children:(t,c)=>{var v=E(),k=S(v);Oe(k,()=>i.children),f(t,v)},$$slots:{default:!0}})}export{Qt as component,Jt as universal};
