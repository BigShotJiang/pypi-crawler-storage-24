import{c as Y,a as c,s as $,f as x,d as Va,b as da}from"./BDGTMFSm.js";import"./D7pp4EeN.js";import{f as P,p as Sa,G as La,g as a,c as l,r,e as f,a as Ca,b as R,s as d,t as S,n as ea,u as Q,d as Aa,o as Ea,B as Ra}from"./BWzthV5F.js";import{I as F,s as O,e as Ta,b as Pa,i as Ma,k as Ya}from"./BZHPAbyX.js";import{l as W,s as B,p as wa,i as b,b as Ha}from"./PnyBwwNh.js";import{s as Ia}from"./BI66VKG7.js";import{b as ja}from"./YkFwJzVB.js";import{R as qa}from"./DoqfnwNy.js";import{C as ka}from"./CNL0S2qR.js";import{C as Fa}from"./Dgi3wJCg.js";import{T as za}from"./B66iqv_S.js";function Na(h,e){const n=W(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const p=[["circle",{cx:"12",cy:"12",r:"10"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16"}]];F(h,B({name:"circle-alert"},()=>n,{get iconNode(){return p},children:(m,y)=>{var o=Y(),u=P(o);O(u,e,"default",{}),c(m,o)},$$slots:{default:!0}}))}function Oa(h,e){const n=W(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const p=[["circle",{cx:"12",cy:"12",r:"10"}],["rect",{x:"9",y:"9",width:"6",height:"6",rx:"1"}]];F(h,B({name:"circle-stop"},()=>n,{get iconNode(){return p},children:(m,y)=>{var o=Y(),u=P(o);O(u,e,"default",{}),c(m,o)},$$slots:{default:!0}}))}function Wa(h,e){const n=W(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const p=[["path",{d:"m15 9-6 6"}],["path",{d:"M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z"}],["path",{d:"m9 9 6 6"}]];F(h,B({name:"octagon-x"},()=>n,{get iconNode(){return p},children:(m,y)=>{var o=Y(),u=P(o);O(u,e,"default",{}),c(m,o)},$$slots:{default:!0}}))}function Ba(h,e){const n=W(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const p=[["polygon",{points:"6 3 20 12 6 21 6 3"}]];F(h,B({name:"play"},()=>n,{get iconNode(){return p},children:(m,y)=>{var o=Y(),u=P(o);O(u,e,"default",{}),c(m,o)},$$slots:{default:!0}}))}function Ga(h,e){const n=W(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const p=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7"}]];F(h,B({name:"save"},()=>n,{get iconNode(){return p},children:(m,y)=>{var o=Y(),u=P(o);O(u,e,"default",{}),c(m,o)},$$slots:{default:!0}}))}function Ne(h,e){const n=W(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const p=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"}],["circle",{cx:"12",cy:"12",r:"3"}]];F(h,B({name:"settings"},()=>n,{get iconNode(){return p},children:(m,y)=>{var o=Y(),u=P(o);O(u,e,"default",{}),c(m,o)},$$slots:{default:!0}}))}function Se(h,e){const n=W(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.511.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const p=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}]];F(h,B({name:"square"},()=>n,{get iconNode(){return p},children:(m,y)=>{var o=Y(),u=P(o);O(u,e,"default",{}),c(m,o)},$$slots:{default:!0}}))}var Da=x('<div class="flex h-full min-h-[200px] flex-col items-center justify-center gap-2"><!> <span class="text-[13px] text-fg-faint"> </span></div>'),Ja=x('<div class="flex flex-col gap-1.5"><span class="font-mono text-[11px] font-medium uppercase tracking-[0.1em] text-fg-faint">You</span> <div class="border-l-2 border-accent-primary/30 bg-accent-primary/[0.03] px-4 py-2.5"><pre class="whitespace-pre-wrap break-words font-mono text-[13px] leading-relaxed text-fg"> </pre></div></div>'),Ka=x('<div class="whitespace-pre-wrap break-words text-[14px] leading-[1.7] text-fg"> </div>'),Qa=x('<span class="text-[13px] text-fg-faint">Thinking...</span>'),Ua=x('<span class="ml-0.5 inline-block h-[18px] w-[2px] animate-pulse bg-accent-primary align-text-bottom"></span>'),Xa=x('<div class="mt-2 flex items-center gap-1.5 text-[12px] text-fg-faint"><!> Stopped</div>'),Za=x('<div class="mt-2 flex items-center gap-1.5 text-[12px] text-fail"><!> </div>'),ae=x('<span class="text-fg-muted"> </span>'),ee=x('<span class="text-fail"> </span>'),te=x('<div class="mt-3 flex flex-wrap items-center gap-3 border-t border-edge-subtle pt-2.5 font-mono text-[11px] text-fg-faint" style="font-variant-numeric: tabular-nums"><span> </span> <span> <!></span> <span> </span> <!></div>'),re=x('<div class="flex flex-col gap-1.5"><span class="font-mono text-[11px] font-medium uppercase tracking-[0.1em] text-fg-faint"> </span> <div><!> <!> <!> <!> <!> <!></div></div>'),se=x('<div class="flex flex-col gap-5 py-2"></div>'),ne=x('<div class="min-h-[200px] max-h-[calc(100dvh-32rem)] overflow-auto px-1"><!></div>');function Ce(h,e){Sa(e,!0);let n=wa(e,"messages",19,()=>[]),p=wa(e,"emptyText",3,"Run an agent to see output here"),m=wa(e,"assistantLabel",3,"Agent"),y=R(void 0);La(()=>{n().length,n().length>0&&n()[n().length-1].content,a(y)&&(a(y).scrollTop=a(y).scrollHeight)});var o=ne(),u=l(o);{var U=N=>{var M=Da(),D=l(M);Ba(D,{size:20,class:"text-fg-faint"});var _=d(D,2),X=l(_,!0);r(_),r(M),S(()=>$(X,p())),c(N,M)},G=N=>{var M=se();Ta(M,21,n,Ma,(D,_,X)=>{var ta=Y(),fa=P(ta);{var pa=H=>{var C=Ja(),V=d(l(C),2),L=l(V),I=l(L,!0);r(L),r(V),r(C),S(()=>$(I,a(_).content)),c(H,C)},ua=H=>{var C=re(),V=l(C),L=l(V,!0);r(V);var I=d(V,2);let ra;var j=l(I);{var xa=v=>{var s=Ka(),z=l(s,!0);r(s),S(()=>$(z,a(_).content)),c(v,s)},J=v=>{var s=Qa();c(v,s)};b(j,v=>{a(_).content?v(xa):a(_).status==="streaming"&&v(J,1)})}var sa=d(j,2);{var _a=v=>{var s=Ua();c(v,s)};b(sa,v=>{a(_).status==="streaming"&&v(_a)})}var na=d(sa,2);{var Z=v=>{var s=Xa(),z=l(s);Oa(z,{size:12}),ea(),r(s),c(v,s)};b(na,v=>{a(_).status==="interrupted"&&v(Z)})}var oa=d(na,2);{var ma=v=>{var s=Za(),z=l(s);Wa(z,{size:12});var A=d(z);r(s),S(()=>$(A,` ${a(_).error??""}`)),c(v,s)};b(oa,v=>{a(_).status==="error"&&a(_).error&&v(ma)})}var ia=d(oa,2);{var la=v=>{const s=Q(()=>a(_).result),z=Q(()=>a(s).tool_calls||a(s).tool_call_names.length);var A=te(),aa=l(A),ha=l(aa);r(aa);var t=d(aa,2),i=l(t),g=d(i);{var w=k=>{var T=ae(),q=l(T);r(T),S($a=>$(q,`(${$a??""})`),[()=>a(s).tool_call_names.join(", ")]),c(k,T)};b(g,k=>{a(s).tool_call_names.length>0&&k(w)})}r(t);var E=d(t,2),va=l(E);r(E);var ya=d(E,2);{var ba=k=>{var T=ee(),q=l(T,!0);r(T),S(()=>$(q,a(s).error)),c(k,T)};b(ya,k=>{!a(s).success&&a(s).error&&k(ba)})}r(A),S((k,T,q)=>{$(ha,`${k??""} in / ${T??""} out`),$(i,`${a(z)??""} tool${a(z)!==1?"s":""} `),$(va,`${q??""}ms`)},[()=>a(s).tokens_in.toLocaleString(),()=>a(s).tokens_out.toLocaleString(),()=>a(s).duration_ms.toLocaleString()]),c(v,A)};b(ia,v=>{a(_).result&&v(la)})}var ga=d(ia,2);{var ca=v=>{var s=Y(),z=P(s);Ia(z,()=>e.messageFooter,()=>({msg:a(_),index:X})),c(v,s)};b(ga,v=>{e.messageFooter&&v(ca)})}r(I),r(C),S(()=>{$(L,m()),ra=Pa(I,1,"bg-surface-1 px-4 py-3 transition-[border-color,box-shadow] duration-200",null,ra,{"border-l-2":a(_).status==="streaming","border-accent-primary":a(_).status==="streaming","glow-lime":a(_).status==="streaming"})}),c(H,C)};b(fa,H=>{a(_).role==="user"?H(pa):H(ua,-1)})}c(D,ta)}),r(M),c(N,M)};b(u,N=>{n().length===0?N(U):N(G,-1)})}r(o),Ha(o,N=>f(y,N),()=>a(y)),c(h,o),Ca()}var oe=x('<!> <span class="text-ok">Copied</span>',1),ie=x("<!> <span>Copy</span>",1),le=x('<span class="text-[12px] text-fg-faint">Validating...</span>'),ce=x('<div class="flex items-center gap-1.5 text-[13px] text-ok"><!> Saved successfully</div>'),ve=x('<div class="flex items-center gap-1.5 text-[13px] text-fail"><!> </div>'),de=x('<div class="flex items-start gap-2 border-l-2 border-l-warn bg-warn/5 px-3 py-2"><!> <p class="text-[13px] text-fg-muted"> </p></div>'),fe=x('<div class="flex items-start gap-2 font-mono text-[13px]"><!> <span> </span> <span class="text-fg-muted"> </span></div>'),pe=x('<div class="space-y-1"></div>'),ue=x('<div class="space-y-3"><div class="flex items-center gap-2"><button class="inline-flex items-center gap-1.5 rounded-full bg-accent-primary px-4 py-1.5 text-[13px] font-medium text-surface-0 transition-[background-color,box-shadow] duration-150 hover:bg-accent-primary-hover hover:shadow-[0_0_16px_oklch(0.91_0.20_128/0.25)] disabled:opacity-40"><!> </button> <button class="inline-flex items-center gap-1.5 rounded-full border border-edge px-4 py-1.5 text-[13px] text-fg-faint transition-[color,background-color,border-color] duration-150 hover:border-accent-primary/20 hover:bg-surface-2 hover:text-fg-muted disabled:opacity-40"><!> Reset</button> <button class="inline-flex items-center gap-1.5 text-[13px] text-fg-faint transition-[color] duration-150 hover:text-fg-muted" aria-label="Copy YAML"><!></button> <span class="ml-auto font-mono text-[12px] text-fg-faint"> </span> <!></div> <!> <!> <!> <textarea class="min-h-[500px] w-full resize-y border border-edge bg-surface-0 p-4 font-mono text-[13px] leading-relaxed text-fg-muted outline-none transition-[border-color,box-shadow] duration-150 focus:border-accent-primary/40 focus:shadow-[0_0_0_3px_oklch(0.91_0.20_128/0.08)]" spellcheck="false"></textarea> <!></div>');function Te(h,e){Sa(e,!0);let n=R(""),p=R(Aa([])),m=R(!1),y=R(!1),o=R(!1),u=R(null),U=R(!1),G=R(!1),N=null;const M=Q(()=>a(n)!==e.yaml),D=Q(()=>a(p).some(t=>t.severity==="error")),_=Q(()=>a(M)&&!a(D)&&!a(y)&&!a(m)),X=Q(()=>e.path.substring(e.path.lastIndexOf("/")+1));Ea(()=>{f(n,e.yaml,!0)});function ta(){f(o,!1),f(u,null),N&&clearTimeout(N),N=setTimeout(fa,800)}async function fa(){var t;if(!a(n).trim()){f(p,[],!0),f(G,!1);return}f(m,!0);try{const i=await e.validate(a(n));f(p,i.issues,!0);const g=a(n).match(/^\s*name:\s*(.+)$/m),w=(t=g==null?void 0:g[1])==null?void 0:t.trim();f(G,!!w&&w!==e.entityName,!0)}catch{}finally{f(m,!1)}}async function pa(){var t;f(y,!0),f(u,null),f(o,!1);try{await e.save(a(n)),f(o,!0),(t=e.onSaved)==null||t.call(e)}catch(i){f(u,i instanceof Error?i.message:"Save failed",!0)}finally{f(y,!1)}}function ua(){f(n,e.yaml,!0),f(p,[],!0),f(G,!1),f(o,!1),f(u,null)}async function H(){await navigator.clipboard.writeText(a(n)),f(U,!0),setTimeout(()=>f(U,!1),2e3)}var C=ue(),V=l(C),L=l(V),I=l(L);Ga(I,{size:13});var ra=d(I);r(L);var j=d(L,2),xa=l(j);qa(xa,{size:12}),ea(),r(j);var J=d(j,2),sa=l(J);{var _a=t=>{var i=oe(),g=P(i);ka(g,{size:14,class:"text-ok"}),ea(2),c(t,i)},na=t=>{var i=ie(),g=P(i);Fa(g,{size:14}),ea(2),c(t,i)};b(sa,t=>{a(U)?t(_a):t(na,-1)})}r(J);var Z=d(J,2),oa=l(Z,!0);r(Z);var ma=d(Z,2);{var ia=t=>{var i=le();c(t,i)};b(ma,t=>{a(m)&&t(ia)})}r(V);var la=d(V,2);{var ga=t=>{var i=ce(),g=l(i);ka(g,{size:14}),ea(),r(i),c(t,i)};b(la,t=>{a(o)&&t(ga)})}var ca=d(la,2);{var v=t=>{var i=ve(),g=l(i);Na(g,{size:14});var w=d(g);r(i),S(()=>$(w,` ${a(u)??""}`)),c(t,i)};b(ca,t=>{a(u)&&t(v)})}var s=d(ca,2);{var z=t=>{var i=de(),g=l(i);za(g,{size:14,class:"mt-0.5 shrink-0 text-warn"});var w=d(g,2),E=l(w,!0);r(w),r(i),S(()=>$(E,e.nameChangeWarning)),c(t,i)};b(s,t=>{a(G)&&t(z)})}var A=d(s,2);Ra(A);var aa=d(A,2);{var ha=t=>{var i=pe();Ta(i,21,()=>a(p),Ma,(g,w)=>{var E=fe(),va=l(E);{var ya=K=>{Na(K,{size:14,class:"mt-0.5 shrink-0 text-fail"})},ba=K=>{za(K,{size:14,class:"mt-0.5 shrink-0 text-warn"})};b(va,K=>{a(w).severity==="error"?K(ya):K(ba,-1)})}var k=d(va,2),T=l(k);r(k);var q=d(k,2),$a=l(q,!0);r(q),r(E),S(()=>{Pa(k,1,Ya(a(w).severity==="error"?"text-fail":"text-warn")),$(T,`${a(w).field??""}:`),$($a,a(w).message)}),c(g,E)}),r(i),c(t,i)};b(aa,t=>{a(p).length>0&&t(ha)})}r(C),S(()=>{L.disabled=!a(_),$(ra,` ${a(y)?"Saving...":"Save"}`),j.disabled=!a(M),$(oa,a(X))}),da("click",L,pa),da("click",j,ua),da("click",J,H),da("input",A,ta),ja(A,()=>a(n),t=>f(n,t)),c(h,C),Ca()}Va(["click","input"]);export{Ce as C,Ba as P,Se as S,Te as Y,Ne as a};
