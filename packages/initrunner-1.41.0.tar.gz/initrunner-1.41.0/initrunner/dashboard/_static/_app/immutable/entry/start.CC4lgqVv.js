import{l as o,a as r}from"../chunks/Y_xSd7fF.js";export{o as load_css,r as start};
