function a(t){try{return localStorage.getItem(t)}catch{return null}}function r(t,e){try{localStorage.setItem(t,e)}catch{}}export{a,r as s};
