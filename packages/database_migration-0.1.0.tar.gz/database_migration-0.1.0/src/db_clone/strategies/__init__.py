"""Conflict resolution strategies."""
