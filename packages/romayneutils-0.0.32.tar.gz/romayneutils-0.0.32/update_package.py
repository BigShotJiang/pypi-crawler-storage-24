
import os, time
import pyperclip as pc

dist = "C:\\Users\\Romayne\\Coding\\utilities\\dist"
filelist = [f for f in os.listdir(dist)]
for f in filelist:
    os.remove(os.path.join(dist, f))

os.chdir("C:/Users/Romayne/Coding/utilities")
os.system("py -m build")
local_api_key = open("A:/backups/pypi_api_key.txt", "r").read()
previous_clipboard_contents = pc.paste()
# its a pain to paste the api key into the actual field automatically so yeah thisll do for a script
pc.copy(local_api_key)
os.system("py -m twine upload dist/* --verbose")
pc.copy(previous_clipboard_contents)
time.sleep(60)
os.system("py -m pip install romayneutils --upgrade")