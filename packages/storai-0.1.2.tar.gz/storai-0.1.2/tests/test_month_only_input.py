import sqlite3

import pandas as pd

from storai.core.pipeline import run_pipeline


def test_month_only_summary_still_generates_date_and_reason():
    summary_df = pd.DataFrame(
        {
            "year": [2025, 2025, 2025, 2025],
            "month": [8, 7, 9, 10],
            "encounter_count": [1256.0, 1419.0, 1398.0, 1415.0],
            "visit_count": [1309.0, 1474.0, 1428.0, 1433.0],
            "charges": [956132.50, 1118011.72, 1143010.77, 1201737.75],
            "payment": [342235.81, 391585.01, 402424.61, 434446.20],
        }
    )

    conn = sqlite3.connect(":memory:")
    summary_df.to_sql("source_table", conn, index=False, if_exists="replace")

    result = run_pipeline(
        summary_df,
        source_sql="select * from source_table",
        db_engine=conn,
    )

    assert "report_date" in result["display_df"].columns
    assert result["insights"]
    assert "ml_findings" in result
    first = result["insights"][0]
    assert first["reason"]
    assert "month 10" not in first["insight"].lower()
