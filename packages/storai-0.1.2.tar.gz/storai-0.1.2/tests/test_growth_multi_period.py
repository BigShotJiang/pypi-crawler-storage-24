import pandas as pd

from storai.metrics.growth import compute_growth


def test_growth_returns_all_adjacent_periods():
    df = pd.DataFrame(
        {
            "report_date": pd.to_datetime(
                ["2025-07-01", "2025-08-01", "2025-09-01", "2025-10-01"]
            ),
            "payment": [100.0, 80.0, 100.0, 105.0],
        }
    )

    metrics = compute_growth(df, "report_date", "payment")

    assert len(metrics) == 3
    assert metrics[0].context["period"].startswith("2025-08-01")
    assert metrics[1].context["period"].startswith("2025-09-01")
    assert metrics[2].context["period"].startswith("2025-10-01")
