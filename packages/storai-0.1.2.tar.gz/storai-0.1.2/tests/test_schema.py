import pandas as pd

from storai.schema.infer import infer_schema

df = pd.DataFrame(
    {
        "date": pd.date_range("2024-01-01", periods=10),
        "payer": ["Aetna", "BCBS"] * 5,
        "revenue": [100, 120, 130, 140, 110, 150, 160, 170, 180, 190],
        "denied": [0, 1] * 5,
        "claim_id": range(10),
    }
)

schema = infer_schema(df)
print(schema.summary())
