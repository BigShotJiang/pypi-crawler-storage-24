import pandas as pd

from storai.metrics.engine import compute_metrics
from storai.schema.infer import infer_schema

# Sample data
df = pd.DataFrame(
    {
        "date": ["Q3", "Q4"],
        "payer": ["Aetna", "Aetna"],
        "revenue": [100, 118],
        "denied": [12, 7],
        "claim_id": [1, 2],
    }
)
schema = infer_schema(df)
metrics = compute_metrics(df, schema)

print(metrics)
for m in metrics:
    print("Metrics:")
    print(m.as_dict())
