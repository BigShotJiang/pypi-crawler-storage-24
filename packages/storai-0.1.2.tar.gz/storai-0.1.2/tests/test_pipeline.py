import pandas as pd

from storai.insights.detector import detect_insights
from storai.metrics.engine import compute_metrics
from storai.narrative.generator import generate_story
from storai.schema.infer import infer_schema

df = pd.DataFrame(
    {
        "date": ["Q3", "Q4", "Q3", "Q4"],
        "payer": ["Aetna", "Aetna", "BCBS", "BCBS"],
        "revenue": [100, 118, 90, 120],
        "denial_rate": [1, 0, 1, 0],
        "claim_id": [1, 2, 3, 4],
    }
)

schema = infer_schema(df)
metrics = compute_metrics(df, schema)
insights = detect_insights(metrics)
story = generate_story(insights)

print("\nSchema:", schema.summary())

print("\nMetrics:")
for m in metrics:
    print(m.as_dict())

print("\nInsights:")
for i in insights:
    print(i.as_dict())

print("\nFinal Story:\n")
print(story)
