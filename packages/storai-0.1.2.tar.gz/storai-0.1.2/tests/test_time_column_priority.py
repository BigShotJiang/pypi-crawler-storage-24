import sqlite3

import pandas as pd

from storai.core.pipeline import run_pipeline


def test_report_date_is_used_over_year_for_growth():
    summary_df = pd.DataFrame(
        {
            "year": [2025, 2025, 2025, 2025],
            "month": [8, 7, 9, 10],
            "encounter_count": [1256.0, 1419.0, 1398.0, 1415.0],
            "visit_count": [1309.0, 1474.0, 1428.0, 1433.0],
            "charges": [956132.50, 1118011.72, 1143010.77, 1201737.75],
            "payment": [342235.81, 391585.01, 402424.61, 434446.20],
        }
    )
    summary_df["report_date"] = pd.to_datetime(
        summary_df["year"].astype(str) + "-" + summary_df["month"].astype(str) + "-01"
    )

    source_df = summary_df.drop(columns=["report_date"]).copy()
    conn = sqlite3.connect(":memory:")
    source_df.to_sql("source_table", conn, index=False, if_exists="replace")

    result = run_pipeline(
        summary_df,
        source_sql="select * from source_table",
        db_engine=conn,
    )

    growth_insights = [
        item
        for item in result["insights"]
        if "increased" in item["insight"] or "decreased" in item["insight"]
    ]
    assert growth_insights, "Expected growth insights when report_date is present."
