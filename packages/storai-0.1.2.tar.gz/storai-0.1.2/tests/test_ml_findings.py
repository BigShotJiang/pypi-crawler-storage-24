import pandas as pd

from storai.core.pipeline import run_pipeline


def test_pipeline_returns_ml_outliers_and_patterns():
    df = pd.DataFrame(
        {
            "year": [2025, 2025, 2025, 2025, 2025],
            "month": [6, 7, 8, 9, 10],
            "payment": [100.0, 105.0, 102.0, 410.0, 103.0],  # outlier in Sep
            "charges": [500.0, 540.0, 580.0, 620.0, 660.0],  # upward pattern
            "visit_count": [50.0, 52.0, 51.0, 53.0, 52.0],
        }
    )

    result = run_pipeline(df)

    assert "ml_findings" in result
    assert "outliers" in result["ml_findings"]
    assert "patterns" in result["ml_findings"]

    outlier_metrics = {item["metric"] for item in result["ml_findings"]["outliers"]}
    assert "payment" in outlier_metrics

    pattern_names = {
        item["pattern"]
        for item in result["ml_findings"]["patterns"]
        if item["metric"] == "charges"
    }
    assert "upward_trend" in pattern_names
