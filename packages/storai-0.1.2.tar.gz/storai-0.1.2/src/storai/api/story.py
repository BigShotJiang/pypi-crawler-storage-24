from __future__ import annotations

from storai.application.service import run_analysis
from storai.data.loaders import resolve_source_df, resolve_summary_df


def analyze(
    summary_df=None,
    *,
    summary_sql=None,
    source_df=None,
    source_sql=None,
    db_engine=None,
):
    """
    Public library entrypoint for generating insights + reasons + ML findings.
    """
    resolved_summary_df = resolve_summary_df(
        summary_df=summary_df,
        summary_sql=summary_sql,
        db_engine=db_engine,
    )
    resolved_source_df = resolve_source_df(
        source_df=source_df,
        source_sql=source_sql,
        db_engine=db_engine,
    )

    return run_analysis(
        summary_df=resolved_summary_df,
        source_df=resolved_source_df,
        source_sql=source_sql,
        db_engine=db_engine,
    )


def story(
    summary_df=None,
    source_sql=None,
    db_engine=None,
    *,
    summary_sql=None,
    source_df=None,
):
    """
    Backward-compatible alias for `analyze`.
    """
    return analyze(
        summary_df=summary_df,
        summary_sql=summary_sql,
        source_df=source_df,
        source_sql=source_sql,
        db_engine=db_engine,
    )
