from dataclasses import dataclass, field
from typing import List


@dataclass
class Schema:
    time: List[str] = field(default_factory=list)
    metrics: List[str] = field(default_factory=list)
    dimensions: List[str] = field(default_factory=list)
    flags: List[str] = field(default_factory=list)
    identifiers: List[str] = field(default_factory=list)

    def summary(self) -> dict:
        return {
            "time": self.time,
            "metrics": self.metrics,
            "dimensions": self.dimensions,
            "flags": self.flags,
            "identifiers": self.identifiers,
        }


@dataclass
class Metric:
    type: str
    name: str
    value: float
    context: dict

    def as_dict(self):
        return {
            "type": self.type,
            "name": self.name,
            "value": self.value,
            "context": self.context,
        }


@dataclass
class Insight:
    type: str
    name: str
    score: float
    message_data: dict
    root_causes: List[str] = field(default_factory=list)

    def as_dict(self):
        return {
            "type": self.type,
            "name": self.name,
            "score": self.score,
            "data": self.message_data,
            "root_causes": self.root_causes,
        }
