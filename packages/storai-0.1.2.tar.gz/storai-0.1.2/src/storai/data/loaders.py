from __future__ import annotations

import pandas as pd


def resolve_summary_df(summary_df=None, summary_sql=None, db_engine=None):
    has_df = summary_df is not None
    has_sql = bool(summary_sql)

    if has_df and has_sql:
        raise ValueError("Provide either `summary_df` or `summary_sql`, not both.")

    if has_df:
        return summary_df

    if not has_sql:
        raise ValueError("`summary_df` or `summary_sql` is required.")

    if db_engine is None:
        raise ValueError("`db_engine` is required when using `summary_sql`.")

    return pd.read_sql(summary_sql, db_engine)


def resolve_source_df(source_df=None, source_sql=None, db_engine=None):
    if source_df is not None and source_sql:
        raise ValueError("Provide either `source_df` or `source_sql`, not both.")

    if source_df is not None:
        return source_df

    if source_sql and db_engine is None:
        raise ValueError("`db_engine` is required when using `source_sql`.")

    if source_sql and db_engine is not None:
        return pd.read_sql(source_sql, db_engine)

    return None
