from .api.story import analyze, story
from .insights.detector import detect_insights
from .metrics.engine import compute_metrics
from .ml.engine import detect_ml_findings
from .schema.infer import infer_schema

__all__ = [
    "story",
    "analyze",
    "detect_insights",
    "compute_metrics",
    "detect_ml_findings",
    "infer_schema",
]
__version__ = "0.1.0"
