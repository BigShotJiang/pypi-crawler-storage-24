TEMPLATES = {
    "growth_positive": "{metric} increased {percent}% in {period} vs {previous_period} ({previous_value} to {current_value}){reason_suffix}.",
    "growth_negative": "{metric} decreased {percent}% in {period} vs {previous_period} ({previous_value} to {current_value}){reason_suffix}.",
    "dominance": "{entity} contributes {percent}% of total {metric}{reason_suffix}.",
    "rate": "{metric} is {percent}%{reason_suffix}.",
    "rate_drop": "{metric} dropped from {prev}% to {curr}% in {period}{reason_suffix}.",
    "rate_rise": "{metric} increased from {prev}% to {curr}% in {period}{reason_suffix}.",
    "trend_up": "{metric} is trending upwards{reason_suffix}.",
    "trend_down": "{metric} is trending downwards{reason_suffix}.",
    "growth_summary_up": (
        "On {period}, we observed a broad surge. Key metrics including {metrics} "
        "rose significantly, averaging a {avg_percent}% increase{reason_suffix}."
    ),
    "growth_summary_down": (
        "On {period}, there was a significant downturn. {metrics} and others "
        "declined, averaging a {avg_percent}% drop{reason_suffix}."
    ),
    "root_cause": " This was primarily {cause}.",
    # Enhanced templates with context awareness
    "growth_positive_high": "{metric} increased {percent}% in {period} vs {previous_period} ({previous_value} to {current_value}){reason_suffix}.",
    "growth_negative_severe": "{metric} decreased {percent}% in {period} vs {previous_period} ({previous_value} to {current_value}){reason_suffix}.",
    "growth_moderate": "{metric} changed by {percent}% in {period} vs {previous_period} ({previous_value} to {current_value}){reason_suffix}.",
    "dominance_strong": "{entity} dominates with {percent}% share of {metric}, indicating {market_position}.",
    "dominance_moderate": "{entity} holds a significant {percent}% of {metric} market share, suggesting {market_position}.",
    "trend_consistent": "{metric} maintains a consistent upward trajectory, showing {strength} momentum.",
    "trend_volatile": "{metric} exhibits volatile behavior with {volatility_desc} fluctuations.",
    "seasonal_pattern": "{metric} follows a predictable {pattern_type} pattern, with {period} typically showing {typical_behavior}.",
    "anomaly_detected": "{metric} shows unusual {behavior_type} in {period}, deviating significantly from historical norms.",
    # Context-specific templates
    "volume_driven": "Volume increases in {key_drivers} contributed to this {metric_direction}.",
    "price_impact": "Price changes of {affected_items} had a measurable impact on {metric_performance}.",
    "operational_efficiency": "Operational improvements in {efficiency_areas} drove {performance_improvement}.",
    "market_conditions": "External market factors including {market_factors} influenced {metric_outcome}.",
    # Comparative templates
    "benchmark_beat": "{metric} outperformed industry benchmarks by {outperformance_margin}% in {period}.",
    "peer_comparison": "{metric} ranks {rank_position} among peers, demonstrating {competitive_advantage}.",
    "historical_trend": "{metric} continues a {trend_duration}-month trend, now {trend_status} compared to historical averages.",
}
