from .vocab import label


def percent(value):
    return round(value * 100, 1)


def metric_label(name):
    return label(name)


def title(name):
    return name.replace("_", " ").title()
