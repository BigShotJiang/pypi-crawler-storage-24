PRIORITY = {
    "growth": 1,
    "dominance": 2,
    "trend": 3,
    "rate_change": 4,
}


def sort_for_story(insights):
    return sorted(insights, key=lambda i: PRIORITY.get(i.type, 99))


def stitch_sentences(sentences):
    if not sentences:
        return ""

    if len(sentences) == 1:
        return sentences[0]

    story = sentences[0]

    for s in sentences[1:]:
        story += " " + s

    return story
