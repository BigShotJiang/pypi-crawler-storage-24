VOCAB = {
    "denial_rate": "Denial Rate",
    "revenue": "Revenue",
    "payer": "Payer",
    "insurance_ar": "Insurance AR",
    "patient_ar": "Patient AR",
}


def label(name: str) -> str:
    return VOCAB.get(name, name.replace("_", " ").title())
