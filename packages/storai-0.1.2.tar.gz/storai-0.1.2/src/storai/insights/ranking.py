def rank_insights(insights):
    return sorted(insights, key=lambda x: abs(x.score), reverse=True)
