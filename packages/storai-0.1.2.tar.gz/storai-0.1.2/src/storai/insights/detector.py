from .ranking import rank_insights
from .rules import RULES


def detect_insights(metrics):
    insights = []

    for metric in metrics:
        rule = RULES.get(metric.type)

        if not rule:
            continue

        result = rule(metric)

        if result:
            insights.append(result)

    return rank_insights(insights)
