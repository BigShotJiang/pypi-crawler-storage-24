from storai.application.service import run_analysis


def run_pipeline(summary_df, source_df=None, source_sql=None, db_engine=None):
    """
    Backward-compatible pipeline entrypoint.
    """
    return run_analysis(
        summary_df=summary_df,
        source_df=source_df,
        source_sql=source_sql,
        db_engine=db_engine,
    )
