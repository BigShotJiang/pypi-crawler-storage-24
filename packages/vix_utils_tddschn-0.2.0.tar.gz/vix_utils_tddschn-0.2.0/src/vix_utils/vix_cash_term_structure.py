import pandas as pd

import logging as logging
from urllib.parse import urlparse
import aiofiles
import aiohttp
import asyncio
import io
from itertools import chain
from appdirs import user_log_dir
from .location import data_dir, make_dir
from pathlib import Path


# use this URL to browse and find the index data
_cboe_indexes = "https://www.cboe.com/index/indexes"

_default_index_history_symbols = [
    "VIX",
    "VIX9D",
    "VIX3M",
    "VIX6M",
    "VIX1D",
    "VIX1Y",
    "VVIX",
    "GVZ",
    "OVX",
    "SHORTVOL",
    "LONGVOL",
    "VXTLT",
    "VIXMO",
    "VIXTLT",
    "COR1M",
    "COR3M",
    "COR6M",
    "DSPX",
    "JCJ",
]


def _normalize_symbols(symbols):
    if symbols is None:
        symbols = _default_index_history_symbols
    elif isinstance(symbols, str):
        symbols = [symbols]

    out = []
    for symbol in symbols:
        symbol_str = str(symbol).upper().strip()
        if not symbol_str:
            continue
        if symbol_str in out:
            continue
        out.append(symbol_str)
    return out


def _read_index_csv(fname, symbol):
    df = pd.read_csv(fname, header=0)
    if df.empty:
        return pd.DataFrame(columns=["Trade Date", "Close", "Symbol"])

    df.columns = [str(col).strip() for col in df.columns]
    lower_to_original = {str(col).strip().lower(): col for col in df.columns}

    def find_column(*names):
        for name in names:
            if name in lower_to_original:
                return lower_to_original[name]
        return None

    def find_column_containing(token):
        token = token.lower()
        for lower_name, original_name in lower_to_original.items():
            if token in lower_name:
                return original_name
        return None

    date_col = find_column("trade date", "date")
    close_col = (
        find_column("close")
        or find_column_containing("close")
        or find_column(symbol.lower())
    )

    if date_col is None or close_col is None:
        logging.warning(f"Skipping symbol {symbol}: unsupported columns in {fname}")
        return pd.DataFrame(columns=["Trade Date", "Close", "Symbol"])

    out = pd.DataFrame(
        {
            "Trade Date": pd.to_datetime(df[date_col], errors="coerce"),
            "Close": pd.to_numeric(df[close_col], errors="coerce"),
            "Symbol": symbol,
        }
    )

    open_col = find_column("open") or find_column_containing("open")
    high_col = find_column("high") or find_column_containing("high")
    low_col = find_column("low") or find_column_containing("low")

    if open_col is not None:
        out["Open"] = pd.to_numeric(df[open_col], errors="coerce")
    if high_col is not None:
        out["High"] = pd.to_numeric(df[high_col], errors="coerce")
    if low_col is not None:
        out["Low"] = pd.to_numeric(df[low_col], errors="coerce")

    ordered_cols = ["Trade Date"]
    for col in ["Open", "High", "Low", "Close", "Symbol"]:
        if col in out.columns:
            ordered_cols.append(col)
    out = out[ordered_cols]
    out = out.dropna(subset=["Trade Date", "Close"])
    return out


def get_vix_index_histories(symbols=None):
    """
    Return the history of some volatility indexes.
    """

    #    with asyncio.Runner() as runner:
    #        return runner.run(async_get_vix_index_histories())
    return asyncio.run(async_get_vix_index_histories(symbols=symbols))


async def async_get_vix_index_histories(symbols=None):
    """
    Return the history of some volatility indexes.
    """

    symbols = _normalize_symbols(symbols)

    data_directory = Path(data_dir())

    cash_data_directory = data_directory / "cash"
    download_data_directory = cash_data_directory / "download"
    del data_directory
    make_dir(download_data_directory)

    async with aiohttp.ClientSession() as session:

        async def download_csv_from_web(symbol):
            """


            :return: returns nothin when the data have been downloaded into local storage.

            """
            url = f"https://cdn.cboe.com/api/global/us_indices/daily_prices/{symbol}_History.csv"
            logging.debug(f"\nReading URL {url}")
            # save the csv files for inspection.
            cache_file_name = f"{symbol}_History.csv"

            async with session.get(url) as resp:
                if resp.status != 200:
                    logging.warning(
                        f"Skipping symbol {symbol}: {url} returned HTTP {resp.status}"
                    )
                    return None
                text = await resp.text()
            cache_file_path = download_data_directory / cache_file_name

            logging.debug(f"\nWriting file   {cache_file_path} ")

            async with aiofiles.open(cache_file_path, mode="w", newline="") as f:
                await f.write(text)
            logging.debug(f"Wrote {cache_file_path}")

            return symbol, cache_file_path

        # download all of them

        download_coro = (download_csv_from_web(symbol) for symbol in symbols)
        downloaded = await asyncio.gather(*download_coro)

    downloaded = [entry for entry in downloaded if entry is not None]
    if len(downloaded) == 0:
        return pd.DataFrame(columns=["Trade Date", "Close", "Symbol"])

    frames = (_read_index_csv(path, symbol) for symbol, path in downloaded)
    frames = [frame for frame in frames if not frame.empty]
    if len(frames) == 0:
        return pd.DataFrame(columns=["Trade Date", "Close", "Symbol"])

    all_vix_spot = pd.concat(frames)
    all_vix_spot["Trade Date"] = pd.to_datetime(all_vix_spot["Trade Date"])
    all_vix_spot = all_vix_spot.sort_values(["Trade Date", "Symbol"]).reset_index(
        drop=True
    )
    logging.debug(f"\nAll Vix spot \n{all_vix_spot}")

    return all_vix_spot


def pivot_spot_term_structure_on_symbol(all_vix_cash):
    try:
        m1 = f"all_vix_cash columns index:\n{all_vix_cash.columns}"
        all_spot_frame = all_vix_cash.set_index(["Trade Date", "Symbol"]).unstack()
    except Exception as e:
        logging.error("{e} in pivot_spot_term_structure_on_trade_date\n{m1}\n{m1}")
        raise e

    return all_spot_frame
