import json
import logging
from pathlib import Path

import aiofiles
import aiohttp
import asyncio
import pandas as pd

from .location import data_dir, make_dir

# Browse equities at https://www.cboe.com/us/equities/
_cboe_equity_history_url = (
    "https://cdn.cboe.com/api/global/delayed_quotes/charts/historical/{symbol}.json"
)


def _normalize_equity_symbols(symbols):
    if isinstance(symbols, str):
        symbols = [symbols]
    out = []
    for symbol in symbols:
        symbol_str = str(symbol).upper().strip()
        if not symbol_str:
            continue
        if symbol_str in out:
            continue
        out.append(symbol_str)
    return out


def _read_equity_json(fname, symbol):
    try:
        with open(fname) as f:
            data = json.load(f)
    except Exception as e:
        logging.warning(f"Skipping symbol {symbol}: failed to read {fname}: {e}")
        return pd.DataFrame(
            columns=["Trade Date", "Open", "High", "Low", "Close", "Volume", "Symbol"]
        )

    records = data.get("data", [])
    if not records:
        return pd.DataFrame(
            columns=["Trade Date", "Open", "High", "Low", "Close", "Volume", "Symbol"]
        )

    df = pd.DataFrame(records)

    col_map = {
        "date": "Trade Date",
        "open": "Open",
        "high": "High",
        "low": "Low",
        "close": "Close",
        "volume": "Volume",
    }
    df = df.rename(columns={k: v for k, v in col_map.items() if k in df.columns})
    df["Symbol"] = symbol

    for col in ["Open", "High", "Low", "Close"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    if "Volume" in df.columns:
        df["Volume"] = pd.to_numeric(df["Volume"], errors="coerce")

    df["Trade Date"] = pd.to_datetime(df["Trade Date"], errors="coerce")
    df = df.dropna(subset=["Trade Date", "Close"])

    ordered_cols = ["Trade Date"]
    for col in ["Open", "High", "Low", "Close", "Volume", "Symbol"]:
        if col in df.columns:
            ordered_cols.append(col)
    df = df[ordered_cols]
    return df


async def async_get_cboe_equity_histories(symbols):
    """
    Download historical daily OHLCV data for equities/ETFs from CBOE.

    Uses the endpoint:
        https://cdn.cboe.com/api/global/delayed_quotes/charts/historical/{symbol}.json

    Parameters
    ----------
    symbols : str or list of str
        Ticker symbol(s) to download (e.g. ``"SPY"`` or ``["SPY", "NVDA"]``).

    Returns
    -------
    pd.DataFrame
        Records-format DataFrame with columns:
        Trade Date, Open, High, Low, Close, Volume, Symbol.
    """
    symbols = _normalize_equity_symbols(symbols)

    equity_download_dir = Path(data_dir()) / "equity" / "download"
    make_dir(equity_download_dir)

    async with aiohttp.ClientSession() as session:

        async def download_one(symbol):
            url = _cboe_equity_history_url.format(symbol=symbol)
            logging.debug(f"Reading URL {url}")
            cache_path = equity_download_dir / f"{symbol}_History.json"

            async with session.get(url) as resp:
                if resp.status != 200:
                    logging.warning(
                        f"Skipping symbol {symbol}: {url} returned HTTP {resp.status}"
                    )
                    return None
                text = await resp.text()

            async with aiofiles.open(cache_path, mode="w") as f:
                await f.write(text)
            logging.debug(f"Wrote {cache_path}")

            return symbol, cache_path

        downloaded = await asyncio.gather(*(download_one(s) for s in symbols))

    downloaded = [entry for entry in downloaded if entry is not None]
    if not downloaded:
        return pd.DataFrame(
            columns=["Trade Date", "Open", "High", "Low", "Close", "Volume", "Symbol"]
        )

    frames = [
        frame
        for frame in (_read_equity_json(path, symbol) for symbol, path in downloaded)
        if not frame.empty
    ]
    if not frames:
        return pd.DataFrame(
            columns=["Trade Date", "Open", "High", "Low", "Close", "Volume", "Symbol"]
        )

    result = pd.concat(frames)
    result["Trade Date"] = pd.to_datetime(result["Trade Date"])
    result = result.sort_values(["Trade Date", "Symbol"]).reset_index(drop=True)
    logging.debug(f"Equity histories shape: {result.shape}")
    return result


def get_cboe_equity_histories(symbols):
    """
    Download historical daily OHLCV data for equities/ETFs from CBOE.

    Synchronous wrapper around :func:`async_get_cboe_equity_histories`.

    Parameters
    ----------
    symbols : str or list of str
        Ticker symbol(s) to download (e.g. ``"SPY"`` or ``["SPY", "NVDA"]``).

    Returns
    -------
    pd.DataFrame
        Records-format DataFrame with columns:
        Trade Date, Open, High, Low, Close, Volume, Symbol.
    """
    return asyncio.run(async_get_cboe_equity_histories(symbols=symbols))


def pivot_equity_histories_on_symbol(equity_histories):
    """
    Pivot equity histories from record format to wide format.

    Parameters
    ----------
    equity_histories : pd.DataFrame
        Records-format DataFrame as returned by :func:`get_cboe_equity_histories`.

    Returns
    -------
    pd.DataFrame
        Wide-format DataFrame with Trade Date as index and a MultiIndex of
        (price column, Symbol) as columns.
    """
    try:
        wide = equity_histories.set_index(["Trade Date", "Symbol"]).unstack()
    except Exception as e:
        logging.error(f"{e} in pivot_equity_histories_on_symbol")
        raise
    return wide
