import os
from typing import Any, Dict, List, Optional, Tuple

import hydra
import lightning as L
import torch
from lightning import Callback, LightningDataModule, LightningModule, Trainer
from lightning.pytorch.loggers import Logger
from omegaconf import DictConfig, open_dict

from profam import constants as _profam_constants
from profam.utils import (
    RankedLogger,
    check_config,
    extras,
    get_metric_value,
    instantiate_callbacks,
    instantiate_loggers,
    log_hyperparameters,
    save_profiler,
    setup_profiler,
    task_wrapper,
)

log = RankedLogger(__name__, rank_zero_only=True)
ckpt_dir_for_saving_test_results: Optional[str] = None


@task_wrapper
def train(cfg: DictConfig) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Trains the model. Can additionally evaluate on a testset, using best weights obtained during
    training.

    This method is wrapped in optional @task_wrapper decorator, that controls the behavior during
    failure. Useful for multiruns, saving info about the crash, etc.

    :param cfg: A DictConfig configuration composed by Hydra.
    :return: A tuple with metrics and dict with all instantiated objects.
    """
    log.info(f"Output dir: {cfg.paths.output_dir}")  # base for checkpoint, wandb

    if cfg.get("float32_matmul_precision", None) is not None:
        log.info(f"Setting float32_matmul_precision to {cfg.float32_matmul_precision}")
        torch.set_float32_matmul_precision(cfg.float32_matmul_precision)

    # set seed for random number generators in pytorch, numpy and python.random
    if cfg.get("seed"):
        L.seed_everything(cfg.seed, workers=True)

    os.environ["TOKENIZERS_PARALLELISM"] = "false"

    tokenizer = hydra.utils.instantiate(cfg.tokenizer)
    log.info(f"Instantiating datamodule <{cfg.data._target_}>")
    datamodule: LightningDataModule = hydra.utils.instantiate(
        cfg.data,
        tokenizer=tokenizer,
        _convert_="partial",
    )
    log.info(f"Instantiating model <{cfg.model._target_}>")
    model: LightningModule = hydra.utils.instantiate(cfg.model, tokenizer=tokenizer)

    log.info("Instantiating callbacks...")
    callbacks: List[Callback] = instantiate_callbacks(
        cfg.get("callbacks"), extra_callbacks_cfg=cfg.get("extra_callbacks")
    )

    if cfg.get("logger") and "wandb" in cfg.get("logger"):
        with open_dict(cfg):
            if cfg.logger.wandb.get("name") is None:
                num_params = sum(p.numel() for p in model.parameters())
                if num_params >= 1_000_000_000:
                    params_str = f"{num_params / 1_000_000_000:.3g}B"
                else:
                    params_str = f"{num_params / 1_000_000:.3g}M"
                tags_str = ""
                if cfg.get("tags"):
                    tags_str = "||".join(cfg.tags)

                if tags_str:
                    cfg.logger.wandb.name = f"{tags_str}-{params_str}"
                else:
                    cfg.logger.wandb.name = params_str

    log.info("Instantiating loggers...")
    logger: List[Logger] = instantiate_loggers(cfg.get("logger"))

    # setup profiler
    profiler_name = cfg.trainer.profiler.name
    log.info(f"Instantiating profiler <{profiler_name}>")
    profiler = setup_profiler(cfg=cfg.trainer.profiler, log=log)

    log.info(f"Instantiating trainer <{cfg.trainer._target_}>")
    trainer: Trainer = hydra.utils.instantiate(
        cfg.trainer,
        callbacks=callbacks,
        logger=logger,
        profiler=profiler,
    )
    # print(trainer.strategy._get_process_group_backend())
    # print(
    #     trainer.strategy.cluster_environment,
    #     trainer.strategy.cluster_environment.__dict__,
    # )

    object_dict = {
        "cfg": cfg,
        "datamodule": datamodule,
        "model": model,
        "callbacks": callbacks,
        "logger": logger,
        "trainer": trainer,
    }

    if logger:
        log.info("Logging hyperparameters!")
        log_hyperparameters(object_dict)

    if cfg.get("train"):
        if cfg.get("ckpt_path"):
            log.info(f"Resuming training from checkpoint: {cfg.get('ckpt_path')}")
            if cfg.get("override_optimizer_on_load"):
                log.info(
                    "Will override optimizer and scheduler states from checkpoint with current config values"
                )
        log.info("Starting training!")
        try:
            trainer.fit(
                model=model, datamodule=datamodule, ckpt_path=cfg.get("ckpt_path")
            )
        except Exception as e:
            raise e
        finally:
            save_profiler(profiler=profiler, stage="train", log=log)

    train_metrics = trainer.callback_metrics

    if cfg.get("test"):
        log.info("Starting testing!")
        ckpt_path = trainer.checkpoint_callback.best_model_path
        if ckpt_path == "":
            log.warning("Best ckpt not found! Using config ckpt path...")
            ckpt_path = cfg.get("ckpt_path")
        print("CHECKPOINT PATH", ckpt_path)
        trainer.test(model=model, datamodule=datamodule, ckpt_path=ckpt_path)
        log.info(f"Best ckpt path: {ckpt_path}")

    test_metrics = trainer.callback_metrics

    # merge train and test metrics
    metric_dict = {**train_metrics, **test_metrics}

    return metric_dict, object_dict


@hydra.main(version_base="1.3", config_path="configs", config_name="train.yaml")
def main(cfg: DictConfig) -> Optional[float]:
    """Main entry point for training.

    :param cfg: DictConfig configuration composed by Hydra.
    :return: Optional[float] with optimized metric value.
    """
    # apply extra utilities
    # (e.g. ask for tags if none are provided in cfg, print cfg tree, etc.)
    extras(cfg)
    check_config(cfg)
    # train the model
    metric_dict, _ = train(cfg)

    # safely retrieve metric value for hydra-based hyperparameter optimization
    metric_value = get_metric_value(
        metric_dict=metric_dict, metric_name=cfg.get("optimized_metric")
    )

    # return optimized metric
    return metric_value


if __name__ == "__main__":
    main()
