from __future__ import annotations

from cadis._api import SUPPORTED_ISO2
from scripts.update_stable_release_manifest import build_stable_manifest


def test_build_stable_manifest_uses_supported_iso2_in_order():
    dataset_manifest = {
        "generated_at": "2026-03-12T04:51:21Z",
        "countries": {
            "TW": {"tw.admin": {"latest": "v1.0.3"}},
            "JP": {"jp.admin": {"latest": "v1.0.1"}},
            "GB": {"gb.admin": {"latest": "v1.0.0"}},
            "IT": {"it.admin": {"latest": "v1.0.1"}},
            "KR": {"kr.admin": {"latest": "v1.0.0"}},
        },
    }

    payload = build_stable_manifest(
        dataset_manifest=dataset_manifest,
        dataset_manifest_url="https://example.invalid/releases/dataset_manifest.json",
        cadis_version="0.3.6",
        updated_at="2026-03-20T00:00:00Z",
    )

    assert payload["profile"] == "cadis.deployment.release"
    assert payload["source_dataset_manifest_generated_at"] == "2026-03-12T04:51:21Z"
    assert list(payload["datasets"].keys()) == SUPPORTED_ISO2
    assert payload["datasets"] == {
        "JP": "v1.0.1",
        "TW": "v1.0.3",
        "GB": "v1.0.0",
        "IT": "v1.0.1",
        "KR": "v1.0.0",
    }
