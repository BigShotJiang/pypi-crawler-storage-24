"""Canonical Cadis package version."""

__version__ = "0.4.0"
