"""Keyring backend for Azure DevOps Artifacts feeds."""

from __future__ import annotations

import base64
import configparser
import json
import logging
import time
import urllib.parse
from pathlib import Path

import keyring.backend
import keyring.credentials
import requests

from . import _constants as C
from . import _provider, _session_token
from ._azure_cli import AzureCliProvider
from ._managed_identity import ManagedIdentityProvider

log = logging.getLogger(__name__)

# Cached credentials expire after 50 minutes (tokens typically live 60-75 min)
_CACHE_TTL_SECONDS = 50 * 60

PROVIDERS: dict[str, type[_provider.TokenProvider]] = {
    "azure_cli": AzureCliProvider,
    "managed_identity": ManagedIdentityProvider,
}

DEFAULT_CHAIN = ["azure_cli", "managed_identity"]


def _account_from_token(bearer: str) -> str | None:
    """Extract the user principal name from a JWT bearer token (no validation)."""
    try:
        payload = bearer.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        claims: dict[str, str] = json.loads(base64.urlsafe_b64decode(payload))
        return claims.get("upn") or claims.get("unique_name") or claims.get("oid")
    except Exception:
        return None


def _is_supported(service: str) -> bool:
    """Return True if *service* looks like an Azure DevOps Artifacts feed URL."""
    try:
        netloc = urllib.parse.urlparse(service).hostname or ""
    except ValueError:
        return False
    return netloc in C.SUPPORTED_NETLOCS


def _is_safe_origin(
    parsed: urllib.parse.ParseResult, allowed_hosts: frozenset[str]
) -> bool:
    """Return True if *parsed* is a clean HTTPS origin on an allowed host.

    Rejects HTTP, explicit non-default ports, userinfo, and non-root paths.
    """
    if parsed.scheme != "https":
        return False
    if (parsed.hostname or "") not in allowed_hosts:
        return False
    if parsed.port is not None and parsed.port != 443:
        return False
    return not (parsed.username or parsed.password)


def _validate_auth_uri(uri: str) -> bool:
    """Return True if *uri* points to a known Azure AD login endpoint over HTTPS."""
    try:
        parsed = urllib.parse.urlparse(uri)
    except Exception:
        return False
    return _is_safe_origin(parsed, C.ALLOWED_AUTH_HOSTS)


def _validate_vsts_authority(url: str) -> bool:
    """Return True if *url* is a clean HTTPS origin on a known Azure DevOps host."""
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return False
    if not _is_safe_origin(parsed, C.ALLOWED_VSTS_AUTHORITY_HOSTS):
        return False
    # Authority should be an origin, not a deep path
    return parsed.path in ("", "/")


def _discover(service: str) -> tuple[str, str] | None:
    """GET the feed URL unauthenticated to discover tenant and authority.

    Returns ``(tenant_id, vsts_authority)`` or ``None``.
    """
    try:
        resp = requests.get(service, allow_redirects=False, timeout=10)
    except requests.RequestException:
        log.debug("discovery request failed for %s", service, exc_info=True)
        return None

    www_auth = resp.headers.get("WWW-Authenticate", "")
    vsts_authority = resp.headers.get("X-VSS-AuthorizationEndpoint", "")

    # Parse tenant from: Bearer authorization_uri=https://login.microsoftonline.com/{tenant}
    tenant_id = ""
    for raw_part in www_auth.split(","):
        part = raw_part.strip()
        if "authorization_uri=" in part:
            uri = part.split("authorization_uri=", 1)[1].strip().strip('"')
            if not _validate_auth_uri(uri):
                log.warning("discovery returned untrusted authorization_uri: %s", uri)
                return None
            # URI is like https://login.microsoftonline.com/{tenant_id}
            tenant_id = uri.rstrip("/").rsplit("/", 1)[-1]
            break

    if not tenant_id or not vsts_authority:
        log.debug(
            "discovery incomplete: tenant=%r authority=%r",
            tenant_id,
            vsts_authority,
        )
        return None

    if not _validate_vsts_authority(vsts_authority):
        log.warning(
            "discovery returned untrusted authority endpoint: %s", vsts_authority
        )
        return None

    return tenant_id, vsts_authority


def _configured_provider() -> str | None:
    """Read provider override from env var or keyring config."""
    import os  # noqa: PLC0415

    env = os.environ.get("ARTIFACTS_KEYRING_NOFUSS_PROVIDER", "").strip()
    if env:
        return env

    # Try keyring config file (user home only — CWD is not trusted)
    path = Path("~/.config/python_keyring/keyringrc.cfg").expanduser()
    if path.is_file():
        cfg = configparser.ConfigParser()
        cfg.read(path)
        val = cfg.get("artifacts_keyring_nofuss", "provider", fallback="").strip()
        if val:
            return val

    return None


class ArtifactsKeyringBackend(keyring.backend.KeyringBackend):
    priority = 9.9  # keyring expects numeric

    def __init__(self) -> None:
        super().__init__()  # type: ignore[no-untyped-call]
        self._cache: dict[str, tuple[keyring.credentials.SimpleCredential, float]] = {}

    def get_credential(  # noqa: PLR0911, C901
        self,
        service: str,
        username: str | None,  # noqa: ARG002
    ) -> keyring.credentials.SimpleCredential | None:
        if not _is_supported(service):
            return None

        # Validate provider config early so typos are surfaced before
        # any network calls.
        chosen = _configured_provider()
        if chosen and chosen not in PROVIDERS:
            log.warning("unknown provider %r, valid: %s", chosen, ", ".join(PROVIDERS))
            return None

        cached = self._cache.get(service)
        if cached is not None:
            cred, ts = cached
            if time.monotonic() - ts < _CACHE_TTL_SECONDS:
                return cred
            del self._cache[service]

        # Discover tenant + authority
        info = _discover(service)
        if info is None:
            log.warning("could not discover tenant for %s", service)
            return None
        tenant_id, vsts_authority = info

        # Build provider list
        if chosen:
            chain: list[_provider.TokenProvider] = [PROVIDERS[chosen]()]
        else:
            chain = [PROVIDERS[name]() for name in DEFAULT_CHAIN]

        # Get bearer token
        bearer = _provider.run_chain(chain, tenant_id)
        if bearer is None:
            log.warning(
                "all auth providers failed for %s — are you logged in? "
                "Try: az login --tenant %s",
                service,
                tenant_id,
            )
            return None

        account = _account_from_token(bearer)

        # Exchange for session token
        session_tok = _session_token.exchange(bearer, vsts_authority)
        if session_tok is None:
            if account:
                log.warning(
                    "session token exchange failed for %s (authenticated as %s)",
                    service,
                    account,
                )
            else:
                log.warning("session token exchange failed for %s", service)
            return None

        if account:
            log.debug("authenticated to %s as %s", service, account)
        cred = keyring.credentials.SimpleCredential("VssSessionToken", session_tok)
        self._cache[service] = (cred, time.monotonic())
        return cred

    def get_password(self, service: str, username: str | None) -> str | None:
        cred = self.get_credential(service, username)
        return cred.password if cred else None

    def set_password(self, service: str, username: str, password: str) -> None:
        msg = "read-only backend"
        raise NotImplementedError(msg)

    def delete_password(self, service: str, username: str) -> None:
        msg = "read-only backend"
        raise NotImplementedError(msg)
