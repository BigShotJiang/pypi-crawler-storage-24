# Tests the convolution matrix function in utils
# Covered functions:
# - build_convolution_matrix

import openirf
import numpy as np
import pytest

# Test Variables
f_vec_test = np.array([1, 2, 3])
f_vec_test2 = np.array([[1, 2, 3]])
f_vec_test3 = np.array([[1, 2, 3], [2, 4, 6]])


def test_correct_shape_convolution_matrix():
    A = openirf.utils.build_convolution_matrix(f_vec_test)  # Input: 1d array
    assert np.array_equal(A, np.array([[1, 0, 0], [2, 1, 0], [3, 2, 1]])), "Convolution matrix: Shape does not match expected output."
    A = openirf.utils.build_convolution_matrix(f_vec_test2)  # Input: pseudo-2d array
    assert np.array_equal(A, np.array([[1, 0, 0], [2, 1, 0], [3, 2, 1]])), "Convolution matrix: Shape does not match expected output."


def test_rejection_of_non_1d_array():
    with pytest.raises(Exception) as exc_info:
        A = openirf.utils.build_convolution_matrix(f_vec_test3)  # Input: 2d array
    assert exc_info.value.args[0] == "Expected 1D array. Got 2D."
    assert exc_info.type.__name__ == "ValueError"
