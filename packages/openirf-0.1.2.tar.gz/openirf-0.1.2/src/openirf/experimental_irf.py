import numpy as np
import scipy as sp
from .utils import *


class ExperimentalIRF:
    """
    OpenIRF Experimental IRF Class
    ------------------------------

    Stores time series (t_vec,y_vec_,f_vec) for IRF calculation.

    Shape of time series arrays
    ---------------------------
    - 3D: Multiple dofs, multiple measurements (dof,number_of_measurements,points)
    - 2D: Single dof, multiple measurements (number_of_measurements,points)
    - 1D: Single dof, one measurement (points)

    Constraints
    -----------
    - t_vec must matched stored t_vec (if already stored)
    - All data must share the same t_vec
    - Data cannot be added without a specified or already stored t_vec

    Attributes
    ----------
    :param t_vec: Time vector of time series y_vec and f_vec.
    :type t_vec: ndarray
    :param y_vec: Time series of system responses.
    :type y_vec: ndarray
    :param f_vec: Time series of applied forces.
    :type f_vec: ndarray

    """

    # Declare parameters as attributes
    t_vec = np.empty((0))
    y_vec = np.empty((0, 0, 0))
    f_vec = np.empty((0, 0, 0))

    def __init__(self, t_vec=np.empty((0)), y_vec=np.empty((0, 0, 0)), f_vec=np.empty((0, 0, 0))):
        # Initialize ExperimentalIRF class with provided data
        if t_vec.size != 0:
            self.t_vec = convert_to_1d_array(t_vec)

        if y_vec.size != 0 or f_vec.size != 0:
            self.add_time_series(y_vec, f_vec, t_vec=self.t_vec)

    # Convert any array passed to ExperimentalIRF into a 3D array for concise internal storage.
    def _convert_to_3d_array(self, array):
        # Input convention:
        # 3D: Multiple dofs, multiple measurements (dof,number_of_measurements,points)
        # 2D: Single dof, multiple measurements (number_of_measurements,points)
        # 1D: Single dof, one measurement (points)

        if array.ndim == 1:
            array = array[np.newaxis, np.newaxis, :]
        elif array.ndim == 2:
            array = array[np.newaxis, :, :]
        elif array.ndim == 3:
            pass
        else:
            raise ValueError(f"Expected 1D, 2D, or 3D array. Got {array.ndim}D.")

        return array

    def __str__(self):
        # Prints a formatted object summary of the ExperimentalIRF object
        def print_array(arr):
            if arr is None or arr.size == 0:
                return "None"
            else:
                return str(arr.shape)

        return (
            "==== OpenIRF Experimental IRF Object Summary ====\n"
            f"t_vec: {print_array(self.t_vec)}\n"
            f"y_vec: {print_array(self.y_vec)}\n"
            f"f_vec: {print_array(self.f_vec)}"
        )

    def __repr__(self):
        # Return the same output as __str__ for IPython outputs
        return self.__str__()

    def add_time_series(self, y_vec, f_vec, t_vec=None):
        """
        Add Time Series
        ---------------

        This method allows to add time series to the class istance.

        Shape of time series arrays
        ---------------------------
        - 3D: Multiple dofs, multiple measurements (dof,number_of_measurements,points)
        - 2D: Single dof, multiple measurements (number_of_measurements,points)
        - 1D: Single dof, one measurement (points)

        Constraints
        -----------
        - t_vec must matched stored t_vec (if already stored)
        - All data must share the same t_vec
        - Data cannot be added without a specified or already stored t_vec

        Parameters
        ----------
        :param t_vec: Time vector of time series y_vec and f_vec.
        :type t_vec: ndarray
        :param y_vec: Time series of system responses.
        :type y_vec: ndarray
        :param f_vec: Time series of applied forces.
        :type f_vec: ndarray, optional

        """
        # Shape input data
        if t_vec is not None:
            t_vec = convert_to_1d_array(t_vec)
        y_vec = self._convert_to_3d_array(y_vec)
        f_vec = self._convert_to_3d_array(f_vec)

        # Input check - Time Vector
        if self.t_vec.size != 0 and t_vec is not None:
            if not np.array_equal(self.t_vec, t_vec):
                raise Exception("Provided t_vec does not match stored t_vec.")
        if self.t_vec.size == 0:  # Assign provided time vector if previously self.t_vec was empty
            if t_vec is None or t_vec.size == 0:  # No t_vec provided for data
                raise Exception("No t_vec provided for data.")
            self.t_vec = t_vec

        # Input check - Data
        if y_vec.shape[-1] != len(self.t_vec):
            raise Exception("Provided y_vec does not match length of stored t_vec.")
        if f_vec.shape[-1] != len(self.t_vec):
            raise Exception("Provided f_vec does not match length of stored t_vec.")

        if self.y_vec.size != 0:  # Only y_vec or f_vec must be checked here, since they can only be initialized in pairs.
            y_vec_new = np.append(self.y_vec, y_vec, axis=0)
            f_vec_new = np.append(self.f_vec, f_vec, axis=0)
        else:
            y_vec_new = y_vec
            f_vec_new = f_vec

        self.y_vec = y_vec_new
        self.f_vec = f_vec_new
