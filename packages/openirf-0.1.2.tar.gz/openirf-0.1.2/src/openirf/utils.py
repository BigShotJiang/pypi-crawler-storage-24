import numpy as np
import scipy as sp
from tqdm import tqdm


def convert_to_1d_array(array):
    """
    Returns a 1d array from provided input and raises an error for higher dimensional input.

    Parameters
    ----------
    :param array: Force vector from which the convolution matrix F is built.
    :type array: ndarray

    Returns
    -------
    :param array: A 1d array without unnecessary dimensions.
    :type array: ndarray

    """
    array = np.squeeze(array)

    if array.ndim != 1:
        raise ValueError(f"Expected 1D array. Got {array.ndim}D.")

    return array


def build_convolution_matrix(array):
    """
    Returns a square convolution matrix A built from the provided time series array.

    Parameters
    ----------
    :param array: Time series array from which a convolution matrix is built.
    :type array: ndarray

    Returns
    -------
    :param A: A square convolution matrix A.
    :type A: ndarray (len(array), len(array))

    """
    # Check array dimensions and strip unnecessary dimensions.
    array = convert_to_1d_array(array)
    return sp.linalg.toeplitz(array, np.zeros_like(array))


def newmark_integration(M, C, K, f_vec, t_vec, q0, dq0, beta=0.25, gamma=0.5):
    """
    Performs a Newmark time integration for the given system matrices (MCK) with applied forces (f_vec) at time steps specified in time vector (t_vec). The initial conditions on displacements are set by q0, initial velocities are set by dq0. Optionally, the Newmark parameters can be overriden from their default values (Average Constant Acceleration with beta=1/4, gamma=1/2).

    Parameters
    ----------
    :param M: Mass matrix of numerical model.
    :type M: ndarray (n,n)
    :param C: Damping matrix of numerical model.
    :type C: ndarray (n,n)
    :param K: Stiffness matrix of numerical model.
    :type K: ndarray (n,n)
    :param f_vec: Vector of applied forces.
    :type f_vec: ndarray (m,n)
    :param t_vec: Time vector
    :type t_vec: ndarray (m)
    :param q0: Initial displacements vector.
    :type q0: ndarray (n)
    :param dq0: Initial velocities vector.
    :type dq0: ndarray (n)
    :param beta: Newmark parameter beta; default: 0.25
    :type beta: ndarray, optional
    :param gamma: Newmark parameter gamma; default: 0.5
    :type gamma: ndarray, optional

    Returns
    -------
    :param q: Displacements of the system w.r.t. t_vec.
    :type q: ndarray (m,n)
    :param dq: Velocities of the system w.r.t. t_vec.
    :type dq: ndarray (m,n)
    :param ddq: Accelerations of the system w.r.t. t_vec.
    :type ddq: ndarray (m,n)

    """
    # Preallocation
    q = np.zeros([len(t_vec), len(M)])
    dq = np.zeros([len(t_vec), len(M)])
    ddq = np.zeros([len(t_vec), len(M)])

    # Set initial conditions
    q[0] = q0
    dq[0] = dq0

    # Get step size from time vector
    t_step = t_vec[1]

    # Invert stepping matrix
    S_inv = np.linalg.inv(M + gamma * t_step * C + beta * t_step**2 * K)

    # Initial accelerations
    if (f_vec[0] == 0).all() and (q == 0).all() and (dq == 0).all():  # Skip inverting mass matrix when unnecessary
        ddq[0] = 0
    else:
        M_inv = np.linalg.inv(M)
        ddq[0] = np.matmul(M_inv, (f_vec[0] - np.matmul(C, dq[0]) - np.matmul(K, q[0])))

    # Integration loop
    for n in tqdm(range(0, len(t_vec) - 1), leave=False):
        # Predictor step
        dq[n + 1] = dq[n] + (1 - gamma) * t_step * ddq[n]
        q[n + 1] = q[n] + t_step * dq[n] + (0.5 - beta) * t_step**2 * ddq[n]

        # Calculate new accelerations
        ddq[n + 1] = np.matmul(S_inv, (f_vec[n + 1] - np.matmul(C, dq[n + 1]) - np.matmul(K, q[n + 1])))

        # Corrector step
        dq[n + 1] += gamma * t_step * ddq[n + 1]
        q[n + 1] += beta * t_step**2 * ddq[n + 1]

    return q, dq, ddq
