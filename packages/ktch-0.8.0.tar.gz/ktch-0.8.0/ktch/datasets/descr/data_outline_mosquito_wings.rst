Mosquito Wing Outline Dataset
======================================