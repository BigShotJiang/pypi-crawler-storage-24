#!/usr/bin/env python
# coding: utf-8

"""
High-level inference API for PRISM models.

Quick start::

    import prism

    model = prism.pretrained("checkpoint.ckpt")       # auto-detects GPU
    emb   = model.extract_embedding("EVQLVESGGGLVQ...")  # [H] numpy array
    gl    = model.extract_GL_logit("EVQLVESGGGLVQ...")    # [L, 20] GL log-probs
    ngl   = model.extract_NGL_logit("EVQLVESGGGLVQ...")   # [L, 20] NGL log-probs
    ppl   = model.perplexity("EVQLVESGGGLVQ...")          # scalar perplexity

All methods accept a single string or a list of strings.
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Literal, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from tqdm.auto import tqdm

import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint

try:
    from huggingface_hub import hf_hub_download
except ImportError:
    hf_hub_download = None


# =============================================================================
# Module-level helpers
# =============================================================================

def _resolve_device(device: str) -> str:
    """Resolve ``"auto"`` to ``"cuda"`` or ``"cpu"``; pass others through."""
    if device == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    return device


def _resolve_checkpoint(checkpoint_path: str) -> str:
    """If *checkpoint_path* is a HF Hub model ID, download and return local path.

    Detection logic:
    - If the path exists on disk, return it as-is.
    - If it contains ``/`` but does **not** start with ``/``, ``.``, or ``~``,
      treat it as a HF Hub ``repo_id`` and download ``checkpoint.ckpt``.
    - Otherwise raise :class:`FileNotFoundError`.
    """
    path = Path(checkpoint_path)
    if path.exists():
        return str(path)

    # Looks like a HF Hub ID: "org/model-name"
    if "/" in checkpoint_path and not checkpoint_path.startswith(("/", ".", "~")):
        if hf_hub_download is None:
            raise ImportError(
                "Install huggingface-hub to download models: "
                "pip install huggingface-hub"
            )
        return hf_hub_download(
            repo_id=checkpoint_path,
            filename="checkpoint.ckpt",
        )

    raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")


def _get_bundled_gene_vocab() -> str:
    """Return path to the ``gene_vocabulary.json`` bundled with the package."""
    return str(Path(__file__).parent / "data" / "gene_vocabulary.json")


def _ensure_list(x):
    """Wrap a single string in a list; return ``(list, was_single)``."""
    if isinstance(x, str):
        return [x], True
    return x, False


def _unwrap_single(result, was_single):
    """If the caller passed a single string, unwrap the batch dimension."""
    if not was_single:
        return result
    if isinstance(result, list) and len(result) == 1:
        return result[0]
    if isinstance(result, np.ndarray) and result.ndim >= 1 and result.shape[0] == 1:
        return result[0]
    return result


# =============================================================================
# Factory
# =============================================================================

def pretrained(
    checkpoint_path: str,
    device: str = "auto",
    gene_vocab_path: Optional[str] = None,
) -> "PrismModel":
    """Load a pretrained PRISM model from checkpoint.

    Extracts hyperparameters from the checkpoint automatically — no YAML config needed.

    *checkpoint_path* can be:

    - A local ``.ckpt`` file path (``"/path/to/model.ckpt"``)
    - A Hugging Face Hub model ID (``"RomeroLab-Duke/prism-antibody"``).
      The checkpoint will be downloaded and cached automatically.

    Args:
        checkpoint_path: Path to a ``.ckpt`` file **or** a HF Hub ``repo_id``.
        device: Device to load model on (``"auto"``, ``"cuda"``, ``"cpu"``, ``"cuda:0"``, etc.).
            Defaults to ``"auto"`` which picks CUDA when available, else CPU.
        gene_vocab_path: Optional path to gene_vocabulary.json. If ``None``,
            looks in checkpoint hparams, then falls back to the bundled copy.

    Returns:
        PrismModel wrapper ready for inference.
    """
    from .model import SFT_ESM2
    from .multimodal_io import GeneVocabulary

    device = _resolve_device(device)

    ckpt_path = _resolve_checkpoint(checkpoint_path)
    checkpoint = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    hparams = checkpoint.get("hyper_parameters", {})

    # Resolve gene vocab: explicit arg > checkpoint hparam > bundled fallback
    gene_vocab = None
    num_genes = 0
    if hparams.get("use_germline_genes", False):
        vocab_path = gene_vocab_path or hparams.get("gene_vocab_path")
        if not vocab_path or not Path(vocab_path).exists():
            vocab_path = _get_bundled_gene_vocab()
        if vocab_path and Path(vocab_path).exists():
            gene_vocab = GeneVocabulary.from_json(vocab_path)
            num_genes = len(gene_vocab)
        else:
            # Last resort: use num_genes from hparams
            num_genes = hparams.get("num_genes", 0)

    # Build model kwargs from checkpoint hparams
    model_kwargs = dict(
        seed=hparams.get("seed", 42),
        model_identifier=hparams.get("model_identifier", "esm2_t12_35M_UR50D"),
        num_unfrozen_transformer_blocks=hparams.get("num_unfrozen_transformer_blocks", 12),
        random_weights=True,  # Will be overwritten by checkpoint weights
        add_custom_tokens=hparams.get("add_custom_tokens", True),
        custom_token_strategy=hparams.get("custom_token_strategy", "lowercase_ngl"),
        activation_function=hparams.get("activation_function", "gelu"),
        fix_swiglu_double_activation=hparams.get("fix_swiglu_double_activation", False),
        # Gene conditioning
        use_germline_genes=hparams.get("use_germline_genes", False),
        num_genes=num_genes,
        gene_embedding_dim=hparams.get("gene_embedding_dim", 64),
        gene_embedding_dropout=hparams.get("gene_embedding_dropout", 0.1),
        # Region embedding
        use_region_embedding=hparams.get("use_region_embedding", False),
        num_regions=hparams.get("num_regions", 8),
        region_embedding_dim=hparams.get("region_embedding_dim", 32),
        # Multihead architecture
        tie_word_embeddings=hparams.get("tie_word_embeddings", False),
        use_multihead_architecture=hparams.get("use_multihead_architecture", True),
        aa_loss_weight=hparams.get("aa_loss_weight", 1.0),
        mut_loss_weight=hparams.get("mut_loss_weight", 1.5),
        mut_focal_gamma=hparams.get("mut_focal_gamma", 2.0),
        use_alpha_gating=hparams.get("use_alpha_gating", True),
        final_loss_weight=hparams.get("final_loss_weight", 2.0),
        aa_focal_gamma=hparams.get("aa_focal_gamma", 2.0),
        origin_focal_gamma=hparams.get("origin_focal_gamma", 2.0),
        ngl_loss_alpha=hparams.get("ngl_loss_alpha", 3.0),
        use_multiplicative_gating=hparams.get("use_multiplicative_gating", True),
        gating_temperature=hparams.get("gating_temperature", 0.5),
        gating_temperature_warmup_steps=hparams.get("gating_temperature_warmup_steps", 500),
        detach_origin_gradient=hparams.get("detach_origin_gradient", True),
        origin_head_dropout=hparams.get("origin_head_dropout", 0.1),
        aa_loss_ngl_weight=hparams.get("aa_loss_ngl_weight", 0.5),
        use_region_balanced_loss=hparams.get("use_region_balanced_loss", True),
        use_cdr_loss_boosting=hparams.get("use_cdr_loss_boosting", False),
        cdr_loss_multiplier=hparams.get("cdr_loss_multiplier", 2.0),
        # Dual AA Heads (v35/v36)
        use_dual_aa_heads=hparams.get("use_dual_aa_heads", False),
        dual_aa_heads_conditioned=hparams.get("dual_aa_heads_conditioned", True),
        # Dummy training args (required by __init__ but unused at inference)
        peak_learning_rate=1e-4,
        adam_beta1=0.9,
        adam_beta2=0.999,
        adam_epsilon=1e-8,
        WD=0.01,
        warmup_steps=100,
        max_steps=1000,
        logging_steps=10,
        eval_steps=50,
        loss_type="focal_loss",
        batch_size=1,
        mask_prob=0.15,
    )

    model = SFT_ESM2(**model_kwargs)

    # Load state dict
    state_dict = checkpoint["state_dict"]
    # Remove non-persistent buffers that may be in old checkpoints
    keys_to_remove = [k for k in state_dict if "aa_indices" in k]
    for k in keys_to_remove:
        del state_dict[k]
    # Filter out keys with shape mismatches (e.g. old 1-output mut_head vs new 2/3-output)
    model_state = model.state_dict()
    keys_to_skip = []
    for k, v in state_dict.items():
        if k in model_state and v.shape != model_state[k].shape:
            keys_to_skip.append(k)
    for k in keys_to_skip:
        del state_dict[k]
    model.load_state_dict(state_dict, strict=False)
    model.to(device)
    model.eval()

    return PrismModel(model, gene_vocab=gene_vocab, device=device)


# =============================================================================
# Main inference wrapper
# =============================================================================

class PrismModel:
    """High-level wrapper for PRISM inference.

    Provides clean methods for common tasks: pseudo-log-likelihood,
    embedding extraction, origin prediction, mutation scoring, and raw logits.

    All public methods accept either a single sequence string or a list of
    strings.  When a single string is passed the batch dimension is removed
    from the return value for convenience.

    Attributes:
        AA_ORDER: The 20 standard amino acids in alphabetical order.
            Column *i* of ``extract_GL_logit`` / ``extract_NGL_logit`` /
            ``extract_marginalized_logit`` corresponds to ``AA_ORDER[i]``.
    """

    AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"

    def __init__(self, model, gene_vocab=None, device="cpu"):
        self.model = model
        self.tokenizer = model.tokenizer
        self.gene_vocab = gene_vocab
        self.device = device

        # Build AA token mappings
        self.uppercase_aa_to_idx: Dict[str, int] = {}
        self.lowercase_aa_to_idx: Dict[str, int] = {}
        for aa in self.AA_ORDER:
            self.uppercase_aa_to_idx[aa] = self.tokenizer.convert_tokens_to_ids(aa)
            lower_id = self.tokenizer.convert_tokens_to_ids(aa.lower())
            if lower_id != self.tokenizer.unk_token_id:
                self.lowercase_aa_to_idx[aa.lower()] = lower_id

        # Collect all standard AA token IDs (for marginalization)
        self._aa_upper_ids = torch.tensor(
            [self.uppercase_aa_to_idx[aa] for aa in self.AA_ORDER],
            device=device,
        )
        self._aa_lower_ids = torch.tensor(
            [self.lowercase_aa_to_idx.get(aa.lower(), -1) for aa in self.AA_ORDER],
            device=device,
        )

        # Precompute GL/NGL index arrays for slicing 53-vocab log-probs → [*, 20]
        self._gl_indices = np.array(
            [self.uppercase_aa_to_idx[aa] for aa in self.AA_ORDER]
        )
        self._ngl_indices = np.array(
            [self.lowercase_aa_to_idx.get(aa.lower(), -1) for aa in self.AA_ORDER]
        )

    # =========================================================================
    # Core Inference Methods
    # =========================================================================

    @torch.no_grad()
    def logits(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        head: Literal["final", "aa", "origin", "alpha"] = "final",
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[torch.Tensor, List[torch.Tensor]]:
        """Extract raw logits from the model.

        Args:
            sequences: Amino acid sequence(s) (uppercase).
            batch_size: Batch size for inference.
            head: Which head's output to return:
                - ``"final"``: 53-vocab combined logits (alpha-gated)
                - ``"aa"``: 33-vocab AA head logits
                - ``"origin"``: 2-class origin head logits
                - ``"alpha"``: Per-position alpha values
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            Single tensor when input is a string; list of tensors for list input.
        """
        sequences, was_single = _ensure_list(sequences)
        all_outputs = []
        n = len(sequences)

        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)
            batch_seqs = sequences[start:end]

            input_ids, attn_mask = self._tokenize(batch_seqs)
            v_ids, j_ids = self._encode_genes(v_genes, start, end)
            r_ids = self._encode_regions(region_masks, batch_seqs, start, end)

            logits_aa, _, logits_mut, alpha, logits_final, hidden = self.model._forward_multihead(
                input_ids=input_ids,
                attention_mask=attn_mask,
                v_gene_ids=v_ids,
                j_gene_ids=j_ids,
                region_ids=r_ids,
            )

            for i in range(len(batch_seqs)):
                seq_len = attn_mask[i].sum().item()
                if head == "final":
                    all_outputs.append(logits_final[i, :seq_len].cpu())
                elif head == "aa":
                    all_outputs.append(logits_aa[i, :seq_len].cpu())
                elif head == "origin":
                    all_outputs.append(logits_mut[i, :seq_len].cpu())
                elif head == "alpha":
                    all_outputs.append(alpha[i, :seq_len].cpu() if alpha is not None else None)

        return _unwrap_single(all_outputs, was_single)

    @torch.no_grad()
    def pseudo_log_likelihood(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        mode: Literal["marginalized", "gl", "ngl", "full_53"] = "marginalized",
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
        return_per_position: bool = False,
    ) -> Union[float, np.ndarray, List[np.ndarray]]:
        """Compute pseudo-log-likelihood (PLL) for each sequence.

        Uses masked marginal scoring: for each position, mask it, predict, and
        accumulate log P(true token | context).

        Args:
            sequences: Amino acid sequence(s) (uppercase).
            batch_size: Number of positions to mask simultaneously per sequence.
            mode: How to compute log probabilities:
                - ``"marginalized"``: logsumexp(upper, lower) for 20 effective AAs (default)
                - ``"gl"``: Uppercase (germline) logprobs only
                - ``"ngl"``: Lowercase (non-germline) logprobs only
                - ``"full_53"``: Full 53-vocab logprobs
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.
            return_per_position: If True, return per-position log-probs instead
                of summed PLL. Each element is an array of shape ``[L_i]``
                where ``L_i`` is the number of AA positions in sequence i.

        Returns:
            When ``return_per_position=False`` (default):
                Scalar float (single string) or array ``[N]`` (list input).
            When ``return_per_position=True``:
                List of 1-D arrays, each ``[L_i]`` with per-position log-probs.
        """
        sequences, was_single = _ensure_list(sequences)
        pll_values = []
        per_pos_values = [] if return_per_position else None

        for seq_idx, seq in enumerate(tqdm(sequences, desc="Computing PLL")):
            input_ids, attn_mask = self._tokenize([seq])
            v_ids, j_ids = self._encode_genes(
                v_genes, seq_idx, seq_idx + 1 if v_genes else None
            )
            r_ids = self._encode_regions(
                region_masks, [seq], seq_idx, seq_idx + 1 if region_masks else None
            )

            seq_len = attn_mask[0].sum().item()
            # Identify maskable positions (skip special tokens)
            mask_token_id = self.tokenizer.mask_token_id
            maskable = []
            for pos in range(seq_len):
                tid = input_ids[0, pos].item()
                if tid not in (
                    self.tokenizer.cls_token_id,
                    self.tokenizer.eos_token_id,
                    self.tokenizer.pad_token_id,
                ):
                    maskable.append(pos)

            original_ids = [input_ids[0, pos].item() for pos in maskable]

            # Per-position log-prob storage
            if return_per_position:
                pos_logps = np.zeros(len(maskable), dtype=np.float64)

            # Batch masked positions: create batch_size copies with different positions masked
            total_logp = 0.0
            for chunk_start in range(0, len(maskable), batch_size):
                chunk_positions = maskable[chunk_start : chunk_start + batch_size]
                chunk_original_ids = original_ids[chunk_start : chunk_start + batch_size]
                bs = len(chunk_positions)

                # Create batch: repeat input_ids for each masked position
                batch_input = input_ids.expand(bs, -1).clone()
                batch_attn = attn_mask.expand(bs, -1)
                for i, pos in enumerate(chunk_positions):
                    batch_input[i, pos] = mask_token_id

                # Expand gene/region IDs to match batch
                batch_v = v_ids.expand(bs, -1) if v_ids is not None else None
                batch_j = j_ids.expand(bs, -1) if j_ids is not None else None
                batch_r = r_ids.expand(bs, -1) if r_ids is not None else None

                logits_aa, _, logits_mut, alpha, logits_final, _ = self.model._forward_multihead(
                    input_ids=batch_input,
                    attention_mask=batch_attn,
                    v_gene_ids=batch_v,
                    j_gene_ids=batch_j,
                    region_ids=batch_r,
                )

                # Extract log-probs at each masked position
                for i, (pos, orig_id) in enumerate(zip(chunk_positions, chunk_original_ids)):
                    if mode == "full_53":
                        log_probs = F.log_softmax(logits_final[i, pos], dim=-1)
                        lp = log_probs[orig_id].item()
                    elif mode == "gl":
                        log_probs = F.log_softmax(logits_final[i, pos], dim=-1)
                        lp = log_probs[orig_id].item()
                    elif mode == "ngl":
                        log_probs = F.log_softmax(logits_final[i, pos], dim=-1)
                        lower_id = self.model.lowercase_aa_token_ids.get(orig_id)
                        if lower_id is not None:
                            lp = log_probs[lower_id].item()
                        else:
                            lp = log_probs[orig_id].item()
                    else:  # marginalized
                        log_probs = F.log_softmax(logits_final[i, pos], dim=-1)
                        lp = self._marginalized_logp(log_probs, orig_id)

                    total_logp += lp
                    if return_per_position:
                        pos_logps[chunk_start + i] = lp

            pll_values.append(total_logp)
            if return_per_position:
                per_pos_values.append(pos_logps)

        if return_per_position:
            if was_single:
                return per_pos_values[0]
            return per_pos_values

        result = np.array(pll_values)
        return _unwrap_single(result, was_single)

    @torch.no_grad()
    def embed(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        mode: Literal["mean", "per_residue", "cls"] = "mean",
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Extract embeddings from the ESM2 backbone.

        Args:
            sequences: Amino acid sequence(s) (uppercase).
            batch_size: Batch size for inference.
            mode: Embedding type:
                - ``"mean"``: Mean-pooled over non-padding positions
                - ``"per_residue"``: Per-residue embeddings
                - ``"cls"``: CLS token embedding
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            For single string with ``"mean"``/``"cls"``: 1-D array ``[H]``.
            For list with ``"mean"``/``"cls"``: 2-D array ``[N, H]``.
            For ``"per_residue"``: single array ``[L, H]`` or list of arrays.
        """
        sequences, was_single = _ensure_list(sequences)
        all_embeddings = []
        n = len(sequences)

        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)
            batch_seqs = sequences[start:end]

            input_ids, attn_mask = self._tokenize(batch_seqs)
            v_ids, j_ids = self._encode_genes(v_genes, start, end)
            r_ids = self._encode_regions(region_masks, batch_seqs, start, end)

            # Forward through backbone to get hidden states
            outputs = self.model._forward_with_gene_conditioning(
                input_ids=input_ids,
                attention_mask=attn_mask,
                v_gene_ids=v_ids,
                j_gene_ids=j_ids,
                region_ids=r_ids,
                output_hidden_states=True,
            )
            hidden_states = outputs.hidden_states[-1]  # [B, L, H]

            for i in range(len(batch_seqs)):
                seq_len = attn_mask[i].sum().item()
                h = hidden_states[i].cpu().numpy()

                if mode == "mean":
                    all_embeddings.append(h[:seq_len].mean(axis=0))
                elif mode == "cls":
                    all_embeddings.append(h[0])
                elif mode == "per_residue":
                    all_embeddings.append(h[:seq_len])

        if mode in ("mean", "cls"):
            result = np.stack(all_embeddings)
            return _unwrap_single(result, was_single)
        # per_residue
        return _unwrap_single(all_embeddings, was_single)

    def extract_embedding(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        mode: Literal["mean", "per_residue", "cls"] = "mean",
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Alias for :meth:`embed`."""
        return self.embed(
            sequences, batch_size=batch_size, mode=mode,
            v_genes=v_genes, j_genes=j_genes, region_masks=region_masks,
        )

    @torch.no_grad()
    def predict_origin(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[Dict[str, np.ndarray], List[Dict[str, np.ndarray]]]:
        """Predict GL/NGL origin per residue.

        Args:
            sequences: Amino acid sequence(s) (uppercase).
            batch_size: Batch size for inference.
            v_genes: Optional V gene names.
            j_genes: Optional J gene names.
            region_masks: Optional region mask strings.

        Returns:
            Dict (single string) or list of dicts, each with:
                - ``"origin_logits"``: ``[L]`` raw origin logits
                - ``"origin_probs"``: ``[L]`` sigmoid probabilities (>0.5 = NGL)
                - ``"alpha"``: ``[L]`` alpha gating values (if available)
        """
        sequences, was_single = _ensure_list(sequences)
        all_results = []
        n = len(sequences)

        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)
            batch_seqs = sequences[start:end]

            input_ids, attn_mask = self._tokenize(batch_seqs)
            v_ids, j_ids = self._encode_genes(v_genes, start, end)
            r_ids = self._encode_regions(region_masks, batch_seqs, start, end)

            logits_aa, _, logits_mut, alpha, logits_final, _ = self.model._forward_multihead(
                input_ids=input_ids,
                attention_mask=attn_mask,
                v_gene_ids=v_ids,
                j_gene_ids=j_ids,
                region_ids=r_ids,
            )

            for i in range(len(batch_seqs)):
                seq_len = attn_mask[i].sum().item()
                result = {
                    "origin_logits": logits_mut[i, :seq_len].cpu().numpy(),
                    "origin_probs": torch.sigmoid(logits_mut[i, :seq_len]).cpu().numpy(),
                }
                if alpha is not None:
                    result["alpha"] = alpha[i, :seq_len].cpu().numpy()
                all_results.append(result)

        return _unwrap_single(all_results, was_single)

    @torch.no_grad()
    def score_mutations(
        self,
        wt_sequences: Union[str, List[str]],
        mut_sequences: Union[str, List[str]],
        batch_size: int = 32,
        mode: Literal["marginalized", "gl", "ngl"] = "marginalized",
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[float, np.ndarray]:
        """Score mutations by log-likelihood ratio at mutated positions.

        Score = sum_i [ logP(mut_i | context) - logP(wt_i | context) ]

        Args:
            wt_sequences: Wild-type sequence(s).
            mut_sequences: Mutant sequence(s) (same length as wt).
            batch_size: Batch size for inference.
            mode: Log probability mode (``"marginalized"``, ``"gl"``, ``"ngl"``).
            v_genes: Optional V gene names.
            j_genes: Optional J gene names.
            region_masks: Optional region mask strings.

        Returns:
            Scalar float for single-string input; array ``[N]`` for list input.
        """
        wt_sequences, was_single_wt = _ensure_list(wt_sequences)
        mut_sequences, _ = _ensure_list(mut_sequences)
        assert len(wt_sequences) == len(mut_sequences)
        scores = []

        for idx in range(len(wt_sequences)):
            wt_seq = wt_sequences[idx]
            mut_seq = mut_sequences[idx]

            # Find mutation positions
            mut_positions = [i for i, (w, m) in enumerate(zip(wt_seq, mut_seq)) if w != m]
            if not mut_positions:
                scores.append(0.0)
                continue

            # Get logits for both sequences (always pass lists internally)
            wt_logits = self.logits(
                [wt_seq], batch_size=1, head="final",
                v_genes=[v_genes[idx]] if v_genes else None,
                j_genes=[j_genes[idx]] if j_genes else None,
                region_masks=[region_masks[idx]] if region_masks else None,
            )
            # logits() with a list returns a list
            if isinstance(wt_logits, list):
                wt_logits = wt_logits[0]
            mut_logits = self.logits(
                [mut_seq], batch_size=1, head="final",
                v_genes=[v_genes[idx]] if v_genes else None,
                j_genes=[j_genes[idx]] if j_genes else None,
                region_masks=[region_masks[idx]] if region_masks else None,
            )
            if isinstance(mut_logits, list):
                mut_logits = mut_logits[0]

            score = 0.0
            for pos in mut_positions:
                # +1 for CLS token offset in tokenized sequence
                tok_pos = pos + 1
                if tok_pos >= mut_logits.size(0):
                    continue

                mut_aa = mut_seq[pos]
                wt_aa = wt_seq[pos]
                mut_token_id = self.uppercase_aa_to_idx.get(mut_aa)
                wt_token_id = self.uppercase_aa_to_idx.get(wt_aa)

                if mut_token_id is None or wt_token_id is None:
                    continue

                log_probs_mut = F.log_softmax(mut_logits[tok_pos].to(self.device), dim=-1)
                log_probs_wt = F.log_softmax(wt_logits[tok_pos].to(self.device), dim=-1)

                if mode == "marginalized":
                    logp_mut = self._marginalized_logp(log_probs_mut, mut_token_id)
                    logp_wt = self._marginalized_logp(log_probs_wt, wt_token_id)
                elif mode == "gl":
                    logp_mut = log_probs_mut[mut_token_id].item()
                    logp_wt = log_probs_wt[wt_token_id].item()
                elif mode == "ngl":
                    mut_lower = self.model.lowercase_aa_token_ids.get(mut_token_id, mut_token_id)
                    wt_lower = self.model.lowercase_aa_token_ids.get(wt_token_id, wt_token_id)
                    logp_mut = log_probs_mut[mut_lower].item()
                    logp_wt = log_probs_wt[wt_lower].item()
                else:
                    logp_mut = log_probs_mut[mut_token_id].item()
                    logp_wt = log_probs_wt[wt_token_id].item()

                score += logp_mut - logp_wt

            scores.append(score)

        result = np.array(scores)
        return _unwrap_single(result, was_single_wt)

    # =========================================================================
    # New extract_* Methods (v1.1.0)
    # =========================================================================

    @torch.no_grad()
    def _forward_batch(
        self,
        sequences: List[str],
        batch_size: int,
        v_genes: Optional[List[str]],
        j_genes: Optional[List[str]],
        region_masks: Optional[List[str]],
    ) -> List[Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]]:
        """Run forward pass and collect per-sequence unpadded outputs.

        Returns:
            List of ``(logits_final, logits_mut, alpha, attn_len)`` tuples,
            one per sequence.  All tensors are on CPU.
        """
        results = []
        n = len(sequences)

        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)
            batch_seqs = sequences[start:end]

            input_ids, attn_mask = self._tokenize(batch_seqs)
            v_ids, j_ids = self._encode_genes(v_genes, start, end)
            r_ids = self._encode_regions(region_masks, batch_seqs, start, end)

            logits_aa, _, logits_mut, alpha, logits_final, _ = self.model._forward_multihead(
                input_ids=input_ids,
                attention_mask=attn_mask,
                v_gene_ids=v_ids,
                j_gene_ids=j_ids,
                region_ids=r_ids,
            )

            for i in range(len(batch_seqs)):
                seq_len = attn_mask[i].sum().item()
                results.append((
                    logits_final[i, :seq_len].cpu(),
                    logits_mut[i, :seq_len].cpu(),
                    alpha[i, :seq_len].cpu() if alpha is not None else None,
                    seq_len,
                ))

        return results

    @torch.no_grad()
    def extract_full_logit(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Extract full 53-vocab log-probabilities per position.

        Args:
            sequences: Amino acid sequence(s).
            batch_size: Batch size for inference.
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            ``[L, 53]`` numpy array (single string) or list of such arrays.
        """
        sequences, was_single = _ensure_list(sequences)
        outputs = self._forward_batch(sequences, batch_size, v_genes, j_genes, region_masks)

        result = []
        for logits_final, _, _, _ in outputs:
            log_probs = F.log_softmax(logits_final, dim=-1).numpy()
            result.append(log_probs)

        return _unwrap_single(result, was_single)

    @torch.no_grad()
    def extract_GL_logit(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Extract germline (uppercase) log-probabilities for 20 amino acids.

        Columns are in alphabetical AA order (``PrismModel.AA_ORDER``):
        A, C, D, E, F, G, H, I, K, L, M, N, P, Q, R, S, T, V, W, Y.

        Args:
            sequences: Amino acid sequence(s).
            batch_size: Batch size for inference.
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            ``[L, 20]`` numpy array (single string) or list of such arrays.
        """
        sequences, was_single = _ensure_list(sequences)
        outputs = self._forward_batch(sequences, batch_size, v_genes, j_genes, region_masks)

        result = []
        for logits_final, _, _, _ in outputs:
            log_probs = F.log_softmax(logits_final, dim=-1).numpy()
            result.append(log_probs[:, self._gl_indices])

        return _unwrap_single(result, was_single)

    @torch.no_grad()
    def extract_NGL_logit(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Extract non-germline (lowercase) log-probabilities for 20 amino acids.

        Columns are in alphabetical AA order (``PrismModel.AA_ORDER``):
        A, C, D, E, F, G, H, I, K, L, M, N, P, Q, R, S, T, V, W, Y.

        Args:
            sequences: Amino acid sequence(s).
            batch_size: Batch size for inference.
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            ``[L, 20]`` numpy array (single string) or list of such arrays.
        """
        sequences, was_single = _ensure_list(sequences)
        outputs = self._forward_batch(sequences, batch_size, v_genes, j_genes, region_masks)

        result = []
        for logits_final, _, _, _ in outputs:
            log_probs = F.log_softmax(logits_final, dim=-1).numpy()
            result.append(log_probs[:, self._ngl_indices])

        return _unwrap_single(result, was_single)

    @torch.no_grad()
    def extract_marginalized_logit(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Extract marginalized log-probabilities: logsumexp(GL, NGL) per AA.

        For each of the 20 amino acids::

            log P(AA) = logsumexp(log P(AA_upper), log P(AA_lower))

        Columns are in alphabetical AA order (``PrismModel.AA_ORDER``).

        Args:
            sequences: Amino acid sequence(s).
            batch_size: Batch size for inference.
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            ``[L, 20]`` numpy array (single string) or list of such arrays.
        """
        sequences, was_single = _ensure_list(sequences)
        outputs = self._forward_batch(sequences, batch_size, v_genes, j_genes, region_masks)

        result = []
        for logits_final, _, _, _ in outputs:
            log_probs = F.log_softmax(logits_final, dim=-1)  # [L, 53]
            gl = log_probs[:, torch.tensor(self._gl_indices, dtype=torch.long)]    # [L, 20]
            ngl = log_probs[:, torch.tensor(self._ngl_indices, dtype=torch.long)]  # [L, 20]
            marg = torch.logsumexp(torch.stack([gl, ngl], dim=-1), dim=-1)  # [L, 20]
            result.append(marg.numpy())

        return _unwrap_single(result, was_single)

    @torch.no_grad()
    def extract_alpha(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Extract per-position alpha gating values.

        Alpha controls the GL/NGL mixture: higher alpha means more weight
        on the NGL (somatic) prediction.

        Args:
            sequences: Amino acid sequence(s).
            batch_size: Batch size for inference.
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            ``[L]`` numpy array (single string) or list of such arrays.
        """
        sequences, was_single = _ensure_list(sequences)
        outputs = self._forward_batch(sequences, batch_size, v_genes, j_genes, region_masks)

        result = []
        for _, _, alpha, _ in outputs:
            if alpha is not None:
                result.append(alpha.numpy())
            else:
                result.append(None)

        return _unwrap_single(result, was_single)

    @torch.no_grad()
    def perplexity(
        self,
        sequences: Union[str, List[str]],
        batch_size: int = 32,
        mode: Literal["marginalized", "gl", "ngl", "full_53"] = "marginalized",
        v_genes: Optional[List[str]] = None,
        j_genes: Optional[List[str]] = None,
        region_masks: Optional[List[str]] = None,
    ) -> Union[float, np.ndarray]:
        """Compute perplexity: ``exp(-PLL / seq_length)``.

        A convenience wrapper around :meth:`pseudo_log_likelihood`.

        Args:
            sequences: Amino acid sequence(s).
            batch_size: Batch size for PLL computation.
            mode: Log-probability mode (see :meth:`pseudo_log_likelihood`).
            v_genes: Optional V gene names per sequence.
            j_genes: Optional J gene names per sequence.
            region_masks: Optional region mask strings per sequence.

        Returns:
            Scalar float (single string) or array ``[N]`` (list input).
        """
        sequences, was_single = _ensure_list(sequences)

        # PLL returns array [N] when given a list
        pll = self.pseudo_log_likelihood(
            sequences, batch_size=batch_size, mode=mode,
            v_genes=v_genes, j_genes=j_genes, region_masks=region_masks,
        )
        # pll could be scalar (if pseudo_log_likelihood unwrapped) or array
        if isinstance(pll, (float, np.floating)):
            pll = np.array([pll])

        seq_lengths = np.array([len(s) for s in sequences], dtype=np.float64)
        ppl = np.exp(-pll / seq_lengths)

        return _unwrap_single(ppl, was_single)

    # =========================================================================
    # Binding Affinity Scoring (v0.4.0)
    # =========================================================================

    # Valid signals and properties for validation
    _BINDING_SIGNALS = {"origin_logit", "origin_prob", "ngl_logprob", "alpha"}
    _BINDING_AGGREGATIONS = {"sum", "mean"}
    _DEVELOPABILITY_PROPERTIES = {
        "self_interaction", "hydrophobicity", "thermal_stability",
        "immunogenicity", "polyreactivity", "expression",
    }

    @torch.no_grad()
    def score_binding(
        self,
        wt_sequence: str,
        mutant_sequences: Union[str, List[str]],
        signal: str = "origin_logit",
        aggregation: str = "sum",
        batch_size: int = 64,
    ) -> Union[float, np.ndarray]:
        """Score binding affinity change for mutants relative to wild-type.

        Uses the masked-individual + WT-centered scoring approach validated
        on FLAb2 binding datasets, where ``origin_logit_sum`` was the top
        performing signal across all baselines (ESM2-650M, AbLang2, AntiBERTy,
        Sapiens).

        For each mutation position, the position is masked in the mutant
        sequence and the model predicts signals at that position.  The WT
        signal at the same position (from an unmasked forward pass) is
        subtracted to produce a WT-centered score.  Scores are aggregated
        across mutation positions.

        Args:
            wt_sequence: Wild-type amino acid sequence (uppercase).
            mutant_sequences: One or more mutant sequences (same length as WT).
            signal: Which model signal to use at mutation positions.
                ``"origin_logit"`` (default, best overall),
                ``"origin_prob"``, ``"ngl_logprob"``, or ``"alpha"``.
            aggregation: How to aggregate across mutation positions.
                ``"sum"`` (default) or ``"mean"``.
            batch_size: Batch size for masked forward passes.

        Returns:
            Scalar float for single mutant; ``[N]`` array for list of mutants.
            Higher score indicates better predicted binding affinity.

        Raises:
            ValueError: If signal/aggregation is invalid or lengths mismatch.
        """
        if signal not in self._BINDING_SIGNALS:
            raise ValueError(
                f"Signal must be one of {sorted(self._BINDING_SIGNALS)}, got '{signal}'"
            )
        if aggregation not in self._BINDING_AGGREGATIONS:
            raise ValueError(
                f"Aggregation must be one of {sorted(self._BINDING_AGGREGATIONS)}, "
                f"got '{aggregation}'"
            )

        mutant_sequences, was_single = _ensure_list(mutant_sequences)

        # Validate lengths
        for i, mut in enumerate(mutant_sequences):
            if len(mut) != len(wt_sequence):
                raise ValueError(
                    f"Length mismatch: WT has {len(wt_sequence)} residues but "
                    f"mutant {i} has {len(mut)} residues"
                )

        # 1. Unmasked forward pass on WT to get baseline signals
        wt_signals = self._extract_unmasked_signals(wt_sequence)

        # 2. Score each mutant
        scores = []
        for mut_seq in mutant_sequences:
            # Find mutation positions
            mut_positions = [
                i for i, (w, m) in enumerate(zip(wt_sequence, mut_seq)) if w != m
            ]
            if not mut_positions:
                scores.append(0.0)
                continue

            # Masked forward at each mutation position
            mut_signals = self._extract_masked_signals_at_positions(
                mut_seq, mut_positions, batch_size=batch_size,
            )

            # WT-centered scoring
            deltas = []
            for idx, seq_pos in enumerate(mut_positions):
                wt_val = wt_signals[signal][seq_pos]
                mut_val = mut_signals[signal][idx]
                deltas.append(mut_val - wt_val)

            if aggregation == "sum":
                scores.append(float(np.sum(deltas)))
            else:
                scores.append(float(np.mean(deltas)))

        result = np.array(scores)
        return _unwrap_single(result, was_single)

    # =========================================================================
    # Developability Scoring (v0.4.0)
    # =========================================================================

    @torch.no_grad()
    def score_developability(
        self,
        sequences: Union[str, List[str]],
        properties: Optional[List[str]] = None,
        batch_size: int = 64,
    ) -> Union[Dict[str, float], List[Dict[str, float]]]:
        """Score antibody developability across 6 biophysical properties.

        Uses per-property optimal scoring methods identified by exhaustive
        evaluation of 432 zero-shot methods (see REPORT.md).  Each property
        uses the best method from v34.1b analysis:

        - **self_interaction**: fraction of positions with NGL logprob < log(0.01)
        - **hydrophobicity**: minimum alpha gating value
        - **thermal_stability**: std of GL log-probabilities
        - **immunogenicity**: mean GL log-probability
        - **polyreactivity**: std of alpha gating values
        - **expression**: mean NGL log-probability

        All computations are done in a single masked pseudo-log-likelihood
        pass that collects GL/NGL logprobs, alpha, and origin signals.

        Args:
            sequences: Amino acid sequence(s) (uppercase).
            properties: Subset of properties to compute.  ``None`` = all 6.
            batch_size: Batch size for the masked PLL loop.

        Returns:
            Dict of ``{property: score}`` for single string;
            list of dicts for list input.
            **Higher** score = more favorable for all properties.

        Raises:
            ValueError: If an invalid property name is specified.
        """
        # Validate properties
        if properties is not None:
            invalid = set(properties) - self._DEVELOPABILITY_PROPERTIES
            if invalid:
                raise ValueError(
                    f"Invalid property name(s): {sorted(invalid)}. "
                    f"Valid: {sorted(self._DEVELOPABILITY_PROPERTIES)}"
                )
            requested = set(properties)
        else:
            requested = self._DEVELOPABILITY_PROPERTIES

        sequences, was_single = _ensure_list(sequences)

        all_results = []
        for seq in sequences:
            # Run masked PLL loop collecting all signals
            signals = self._masked_forward_full(seq, batch_size=batch_size)

            result = {}

            # 1. Self-Interaction: fraction of positions with NGL logprob < log(0.01)
            #    Higher fraction = more "clean" positions = lower self-interaction = better
            if "self_interaction" in requested:
                ngl_lps = signals["ngl_logprob"]
                result["self_interaction"] = float(np.mean(ngl_lps < np.log(0.01)))

            # 2. Hydrophobicity: min alpha across all positions
            #    Low min alpha = strong GL preference at bottleneck position = better
            if "hydrophobicity" in requested:
                result["hydrophobicity"] = float(np.min(signals["alpha"]))

            # 3. Thermal Stability: std of GL log-probs
            #    Higher heterogeneity in GL confidence = more structurally diverse = better
            if "thermal_stability" in requested:
                result["thermal_stability"] = float(np.std(signals["gl_logprob"]))

            # 4. Immunogenicity: mean GL log-prob
            #    Higher GL probability = more germline-like = less immunogenic = better
            if "immunogenicity" in requested:
                result["immunogenicity"] = float(np.mean(signals["gl_logprob"]))

            # 5. Polyreactivity: std of alpha gating values
            #    Higher alpha variability = more diverse gating = more polyreactive
            #    Sign flip: lower std = less polyreactive = better
            #    We return the raw std; user interprets direction from docstring
            if "polyreactivity" in requested:
                result["polyreactivity"] = float(np.std(signals["alpha"]))

            # 6. Expression: mean NGL log-prob
            #    Higher NGL probability = more natural mutations = better expression
            if "expression" in requested:
                result["expression"] = float(np.mean(signals["ngl_logprob"]))

            all_results.append(result)

        return _unwrap_single(all_results, was_single)

    # =========================================================================
    # Internal: Masked Forward Full (v0.4.0)
    # =========================================================================

    @torch.no_grad()
    def _masked_forward_full(
        self,
        sequence: str,
        batch_size: int = 64,
    ) -> Dict[str, np.ndarray]:
        """Run masked PLL loop collecting ALL signals per position.

        For each amino acid position in the sequence:
        1. Mask that position
        2. Forward pass through the model
        3. Collect GL logprob, NGL logprob, marginalized logprob, alpha,
           and origin logit at that position

        Args:
            sequence: Single amino acid sequence (uppercase).
            batch_size: Number of masked positions per forward pass.

        Returns:
            Dict with keys ``"gl_logprob"``, ``"ngl_logprob"``,
            ``"marg_logprob"``, ``"alpha"``, ``"origin_logit"``; each a
            1-D numpy array of length ``len(sequence)``.
        """
        input_ids, attn_mask = self._tokenize([sequence])
        seq_len = attn_mask[0].sum().item()
        mask_token_id = self.tokenizer.mask_token_id
        special_ids = {
            self.tokenizer.cls_token_id,
            self.tokenizer.eos_token_id,
            self.tokenizer.pad_token_id,
        }
        special_ids.discard(None)

        # Identify maskable (AA) positions
        maskable = []
        for pos in range(seq_len):
            tid = input_ids[0, pos].item()
            if tid not in special_ids:
                maskable.append(pos)

        n_aa = len(maskable)
        original_ids = [input_ids[0, pos].item() for pos in maskable]

        # Pre-allocate output arrays
        gl_logprob = np.zeros(n_aa, dtype=np.float64)
        ngl_logprob = np.zeros(n_aa, dtype=np.float64)
        marg_logprob = np.zeros(n_aa, dtype=np.float64)
        alpha_arr = np.zeros(n_aa, dtype=np.float64)
        origin_logit = np.zeros(n_aa, dtype=np.float64)

        # Process in batches
        for chunk_start in range(0, n_aa, batch_size):
            chunk_positions = maskable[chunk_start : chunk_start + batch_size]
            chunk_orig_ids = original_ids[chunk_start : chunk_start + batch_size]
            bs = len(chunk_positions)

            # Create batch: repeat input_ids with one position masked per copy
            batch_input = input_ids.expand(bs, -1).clone()
            batch_attn = attn_mask.expand(bs, -1)
            for i, pos in enumerate(chunk_positions):
                batch_input[i, pos] = mask_token_id

            logits_aa, _, logits_mut, alpha, logits_final, _ = (
                self.model._forward_multihead(
                    input_ids=batch_input,
                    attention_mask=batch_attn,
                    v_gene_ids=None,
                    j_gene_ids=None,
                    region_ids=None,
                )
            )

            # Extract signals at each masked position
            for i, (pos, orig_id) in enumerate(
                zip(chunk_positions, chunk_orig_ids)
            ):
                idx = chunk_start + i

                # GL log-prob: log P(uppercase AA)
                lp = F.log_softmax(logits_final[i, pos], dim=-1)
                gl_logprob[idx] = lp[orig_id].item()

                # NGL log-prob: log P(lowercase AA)
                lower_id = self.model.lowercase_aa_token_ids.get(orig_id)
                if lower_id is not None:
                    ngl_logprob[idx] = lp[lower_id].item()
                else:
                    ngl_logprob[idx] = lp[orig_id].item()

                # Marginalized: logsumexp(GL, NGL)
                marg_logprob[idx] = self._marginalized_logp(lp, orig_id)

                # Alpha gating
                if alpha is not None:
                    alpha_arr[idx] = alpha[i, pos].item()

                # Origin logit (2-class: scalar per position)
                if logits_mut.dim() == 2:
                    origin_logit[idx] = logits_mut[i, pos].item()
                else:
                    # 3-class: take NGL logit (index 1)
                    origin_logit[idx] = logits_mut[i, pos, 1].item()

        return {
            "gl_logprob": gl_logprob,
            "ngl_logprob": ngl_logprob,
            "marg_logprob": marg_logprob,
            "alpha": alpha_arr,
            "origin_logit": origin_logit,
        }

    @torch.no_grad()
    def _extract_unmasked_signals(
        self,
        sequence: str,
    ) -> Dict[str, np.ndarray]:
        """Extract origin_logit, origin_prob, alpha, ngl_logprob from unmasked forward pass.

        Returns dict with each signal as a 1-D array of length ``len(sequence)``.
        """
        input_ids, attn_mask = self._tokenize([sequence])
        seq_len = attn_mask[0].sum().item()
        special_ids = {
            self.tokenizer.cls_token_id,
            self.tokenizer.eos_token_id,
            self.tokenizer.pad_token_id,
        }
        special_ids.discard(None)

        logits_aa, _, logits_mut, alpha, logits_final, _ = (
            self.model._forward_multihead(
                input_ids=input_ids,
                attention_mask=attn_mask,
                v_gene_ids=None,
                j_gene_ids=None,
                region_ids=None,
            )
        )

        # Identify AA positions
        aa_positions = []
        for pos in range(seq_len):
            tid = input_ids[0, pos].item()
            if tid not in special_ids:
                aa_positions.append(pos)

        n_aa = len(aa_positions)
        aa_idx = torch.tensor(aa_positions, dtype=torch.long)

        # Origin logit
        if logits_mut.dim() == 2:
            ol = logits_mut[0, aa_idx].cpu().numpy()
        else:
            ol = logits_mut[0, aa_idx, 1].cpu().numpy()

        # Origin prob
        op = 1.0 / (1.0 + np.exp(-ol))  # sigmoid

        # Alpha
        if alpha is not None:
            al = alpha[0, aa_idx].cpu().numpy()
        else:
            al = np.zeros(n_aa)

        # NGL logprob
        lp_final = F.log_softmax(logits_final[0], dim=-1)
        nl = np.zeros(n_aa, dtype=np.float64)
        for i, tok_pos in enumerate(aa_positions):
            orig_id = input_ids[0, tok_pos].item()
            lower_id = self.model.lowercase_aa_token_ids.get(orig_id)
            if lower_id is not None:
                nl[i] = lp_final[tok_pos, lower_id].item()
            else:
                nl[i] = lp_final[tok_pos, orig_id].item()

        return {
            "origin_logit": ol,
            "origin_prob": op,
            "alpha": al,
            "ngl_logprob": nl,
        }

    @torch.no_grad()
    def _extract_masked_signals_at_positions(
        self,
        sequence: str,
        seq_positions: List[int],
        batch_size: int = 64,
    ) -> Dict[str, np.ndarray]:
        """Extract signals at specific masked positions (for binding scoring).

        Each position in ``seq_positions`` is masked individually and the
        model's origin_logit, origin_prob, alpha, and ngl_logprob are
        collected at that position.

        Args:
            sequence: Amino acid sequence (uppercase).
            seq_positions: List of 0-indexed AA positions to mask.
            batch_size: Number of positions per forward pass.

        Returns:
            Dict with each signal as a 1-D array aligned to ``seq_positions``.
        """
        input_ids, attn_mask = self._tokenize([sequence])
        seq_len = attn_mask[0].sum().item()
        mask_token_id = self.tokenizer.mask_token_id
        special_ids = {
            self.tokenizer.cls_token_id,
            self.tokenizer.eos_token_id,
            self.tokenizer.pad_token_id,
        }
        special_ids.discard(None)

        # Map AA sequence positions to token positions
        aa_to_tok = []
        for pos in range(seq_len):
            tid = input_ids[0, pos].item()
            if tid not in special_ids:
                aa_to_tok.append(pos)

        n_positions = len(seq_positions)
        origin_logit = np.zeros(n_positions, dtype=np.float64)
        origin_prob = np.zeros(n_positions, dtype=np.float64)
        alpha_arr = np.zeros(n_positions, dtype=np.float64)
        ngl_logprob = np.zeros(n_positions, dtype=np.float64)

        for chunk_start in range(0, n_positions, batch_size):
            chunk = seq_positions[chunk_start : chunk_start + batch_size]
            bs = len(chunk)

            batch_input = input_ids.expand(bs, -1).clone()
            batch_attn = attn_mask.expand(bs, -1)
            tok_positions = []
            for i, seq_pos in enumerate(chunk):
                tok_pos = aa_to_tok[seq_pos] if seq_pos < len(aa_to_tok) else 0
                batch_input[i, tok_pos] = mask_token_id
                tok_positions.append(tok_pos)

            logits_aa, _, logits_mut, alpha, logits_final, _ = (
                self.model._forward_multihead(
                    input_ids=batch_input,
                    attention_mask=batch_attn,
                    v_gene_ids=None,
                    j_gene_ids=None,
                    region_ids=None,
                )
            )

            for i, tok_pos in enumerate(tok_positions):
                idx = chunk_start + i

                # Origin logit
                if logits_mut.dim() == 2:
                    origin_logit[idx] = logits_mut[i, tok_pos].item()
                else:
                    origin_logit[idx] = logits_mut[i, tok_pos, 1].item()

                # Origin prob (sigmoid)
                origin_prob[idx] = 1.0 / (1.0 + np.exp(-origin_logit[idx]))

                # Alpha
                if alpha is not None:
                    alpha_arr[idx] = alpha[i, tok_pos].item()

                # NGL logprob
                lp = F.log_softmax(logits_final[i, tok_pos], dim=-1)
                orig_id = input_ids[0, tok_pos].item()
                lower_id = self.model.lowercase_aa_token_ids.get(orig_id)
                if lower_id is not None:
                    ngl_logprob[idx] = lp[lower_id].item()
                else:
                    ngl_logprob[idx] = lp[orig_id].item()

        return {
            "origin_logit": origin_logit,
            "origin_prob": origin_prob,
            "alpha": alpha_arr,
            "ngl_logprob": ngl_logprob,
        }

    # =========================================================================
    # Public Utilities
    # =========================================================================

    @staticmethod
    def marginalize_logits(logits_53: torch.Tensor, model) -> torch.Tensor:
        """Marginalize 53-vocab logits to 20 effective AA log-probabilities.

        For each of the 20 amino acids, computes:
            log P(AA) = logsumexp(log P(AA_upper), log P(AA_lower))

        Args:
            logits_53: [..., 53] raw logits from the final head.
            model: The SFT_ESM2 model (for token ID mappings).

        Returns:
            [..., 20] marginalized log-probabilities.
        """
        log_probs = F.log_softmax(logits_53, dim=-1)
        shape = log_probs.shape[:-1]
        result = torch.zeros(*shape, 20, device=logits_53.device)

        for i, aa in enumerate("ACDEFGHIKLMNPQRSTVWY"):
            upper_id = model.tokenizer.convert_tokens_to_ids(aa)
            lower_id = model.lowercase_aa_token_ids.get(upper_id)
            if lower_id is not None:
                result[..., i] = torch.logsumexp(
                    torch.stack([log_probs[..., upper_id], log_probs[..., lower_id]], dim=-1),
                    dim=-1,
                )
            else:
                result[..., i] = log_probs[..., upper_id]

        return result

    # =========================================================================
    # Internal Helpers
    # =========================================================================

    def _tokenize(self, sequences: List[str]) -> Tuple[torch.Tensor, torch.Tensor]:
        """Tokenize sequences with uppercase forcing, padding, and device placement."""
        # Force uppercase for input
        upper_seqs = [s.upper() for s in sequences]
        encoded = self.tokenizer(
            upper_seqs,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=512,
        )
        input_ids = encoded["input_ids"].to(self.device)
        attn_mask = encoded["attention_mask"].to(self.device)
        return input_ids, attn_mask

    def _encode_genes(
        self,
        genes: Optional[List[str]],
        start: int,
        end: Optional[int],
    ) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
        """Encode V/J gene strings to tensor IDs."""
        if genes is None or self.gene_vocab is None:
            return None, None
        if end is None:
            end = start + 1

        batch_genes = genes[start:end]
        gene_ids = torch.tensor(
            [self.gene_vocab.encode(g) for g in batch_genes],
            device=self.device,
        )
        # Return same IDs for both v and j (caller should pass separate lists)
        return gene_ids, gene_ids

    def _encode_regions(
        self,
        region_masks: Optional[List[str]],
        sequences: List[str],
        start: int,
        end: Optional[int],
    ) -> Optional[torch.Tensor]:
        """Encode region mask strings to tensor.

        Region mask format: digit string like "0011122233344456666"
        Values: 0=FR1, 1=CDR1, 2=FR2, 3=CDR2, 4=FR3, 5=CDR3, 6=FR4
        Model expects +1 offset (0=padding).
        """
        if region_masks is None:
            return None
        if end is None:
            end = start + 1

        batch_masks = region_masks[start:end]
        max_len = max(len(s) for s in sequences) + 2  # +2 for special tokens

        region_ids = torch.zeros(len(batch_masks), max_len, dtype=torch.long, device=self.device)
        for i, mask_str in enumerate(batch_masks):
            if mask_str:
                for j, ch in enumerate(mask_str):
                    if j + 1 < max_len:  # +1 for CLS token
                        region_ids[i, j + 1] = int(ch) + 1  # +1 offset

        return region_ids

    def _marginalized_logp(self, log_probs: torch.Tensor, upper_token_id: int) -> float:
        """Compute marginalized log probability: logsumexp(upper, lower)."""
        lower_id = self.model.lowercase_aa_token_ids.get(upper_token_id)
        if lower_id is not None:
            return torch.logsumexp(
                torch.tensor([log_probs[upper_token_id], log_probs[lower_id]]),
                dim=0,
            ).item()
        return log_probs[upper_token_id].item()

    # =========================================================================
    # Data Loading
    # =========================================================================

    @staticmethod
    def _load_data(data_path: str) -> pd.DataFrame:
        """Load antibody data from parquet, pickle, or CSV.

        If the DataFrame lacks a ``split`` column, a random 90/5/5
        train/valid/test split is added (deterministic, seed=42).

        Args:
            data_path: Path to ``.parquet``, ``.pkl``/``.pickle``, or ``.csv`` file.

        Returns:
            DataFrame with at least a ``split`` column.

        Raises:
            ValueError: For unsupported file extensions.
        """
        path = Path(data_path)
        if path.suffix == ".parquet":
            df = pd.read_parquet(data_path)
        elif path.suffix in (".pkl", ".pickle"):
            df = pd.read_pickle(data_path)
        elif path.suffix == ".csv":
            df = pd.read_csv(data_path)
        else:
            raise ValueError(f"Unsupported file format: {path.suffix}")

        # Auto-split if no 'split' column
        if "split" not in df.columns:
            n = len(df)
            indices = np.random.RandomState(42).permutation(n)
            n_val = max(1, int(n * 0.05))
            n_test = max(1, int(n * 0.05))
            split = np.array(["train"] * n)
            split[indices[:n_val]] = "valid"
            split[indices[n_val:n_val + n_test]] = "test"
            df["split"] = split

        return df

    # =========================================================================
    # Finetuning
    # =========================================================================

    def finetune(
        self,
        data_path: str,
        output_dir: str = "prism_finetune_output",
        # Training hyperparameters
        max_steps: int = 5000,
        learning_rate: float = 1e-4,
        batch_size: int = 32,
        warmup_steps: int = 500,
        weight_decay: float = 0.01,
        mask_prob: float = 0.15,
        gradient_accumulation_steps: int = 1,
        # Trainer settings
        devices: int = 1,
        precision: str = "bf16-mixed",
        val_check_interval: Optional[Union[int, float]] = 500,
        # Data settings
        num_workers: int = 4,
        seed: int = 42,
    ) -> str:
        """Finetune the model on additional antibody data.

        All transformer layers are unfrozen.  A fresh optimizer (AdamW +
        cosine schedule) is created.  After training the best checkpoint
        is loaded back so the model is ready for inference.

        Args:
            data_path: Path to ``.parquet``, ``.pkl``, or ``.csv`` file with
                at least ``HEAVY_CHAIN_AA_SEQUENCE`` and/or
                ``LIGHT_CHAIN_AA_SEQUENCE`` columns.
            output_dir: Directory for checkpoints and logs.
            max_steps: Total training steps.
            learning_rate: Peak learning rate for AdamW.
            batch_size: Per-device batch size.
            warmup_steps: Linear warmup steps.
            weight_decay: AdamW weight decay.
            mask_prob: Masking probability for MLM training.
            gradient_accumulation_steps: Gradient accumulation steps.
            devices: Number of GPUs (or ``1`` for CPU/single-GPU).
            precision: Training precision (``"bf16-mixed"``, ``"32"``, etc.).
            val_check_interval: Validate every N steps (int) or fraction of epoch (float).
            num_workers: DataLoader workers.
            seed: Random seed.

        Returns:
            Path to the best checkpoint file.
        """
        from .io_utils import SFTDataModule

        logger = logging.getLogger(__name__)

        # 1. Load data
        df = self._load_data(data_path)
        logger.info(
            "Loaded %d sequences (%d train, %d valid, %d test)",
            len(df),
            (df["split"] == "train").sum(),
            (df["split"] == "valid").sum(),
            (df["split"] == "test").sum(),
        )

        # 2. Update model training hparams (used by configure_optimizers)
        self.model.peak_learning_rate = learning_rate
        self.model.warmup_steps = warmup_steps
        self.model.max_steps = max_steps
        self.model.WD = weight_decay
        self.model.mask_prob = mask_prob
        self.model.batch_size = batch_size

        # 3. Unfreeze all parameters
        for p in self.model.parameters():
            p.requires_grad = True

        # 4. Build DataModule
        dm = SFTDataModule(
            data_frame=df,
            batch_size=batch_size,
            mask_prob=mask_prob,
            tokenizer=self.tokenizer,
            seed=seed,
            num_workers=num_workers,
            gene_vocab=self.gene_vocab,
            use_germline_genes=self.model.use_germline_genes,
            use_region_embedding=self.model.use_region_embedding,
        )

        # 5. Checkpoint callback
        ckpt_callback = ModelCheckpoint(
            dirpath=str(Path(output_dir) / "checkpoints"),
            filename="best-{step}-{val/Final_PPL_All:.4f}",
            monitor="val/Final_PPL_All",
            mode="min",
            save_top_k=1,
            every_n_train_steps=val_check_interval if isinstance(val_check_interval, int) else None,
        )

        # 6. Build Trainer
        trainer = pl.Trainer(
            max_steps=max_steps,
            devices=devices,
            precision=precision,
            accumulate_grad_batches=gradient_accumulation_steps,
            val_check_interval=val_check_interval,
            default_root_dir=output_dir,
            callbacks=[ckpt_callback],
            enable_progress_bar=True,
            logger=pl.loggers.TensorBoardLogger(output_dir, name="finetune"),
        )

        # 7. Train
        self.model.train()
        trainer.fit(self.model, datamodule=dm)

        # 8. Load best checkpoint back
        best_path = trainer.checkpoint_callback.best_model_path
        if best_path:
            self._reload_best_checkpoint(best_path)

        # 9. Eval mode
        self.model.eval()

        return best_path

    def _reload_best_checkpoint(self, checkpoint_path: str) -> None:
        """Load weights from a checkpoint back into ``self.model``."""
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        state_dict = checkpoint.get("state_dict", checkpoint)
        # Remove non-persistent buffers
        keys_to_remove = [k for k in state_dict if "aa_indices" in k]
        for k in keys_to_remove:
            del state_dict[k]
        self.model.load_state_dict(state_dict, strict=False)
        self.model.to(self.device)
