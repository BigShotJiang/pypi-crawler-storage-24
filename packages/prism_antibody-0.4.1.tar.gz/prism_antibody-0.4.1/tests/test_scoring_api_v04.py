"""Tests for PRISM v0.4.0 scoring API: score_binding + score_developability.

Uses mocking to avoid needing a real checkpoint. Tests cover:
- score_binding: single mutant, multiple mutants, no-mutation case, length mismatch
- score_developability: single sequence, multiple sequences, specific properties
- _masked_forward_full: signal collection and shape validation
"""

import numpy as np
import pytest
import torch
import torch.nn.functional as F
from unittest.mock import MagicMock

from prism.api import PrismModel


# ---------------------------------------------------------------------------
# Fixtures: build a mock PrismModel with proper 2-class origin head
# ---------------------------------------------------------------------------

_AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"
_UPPER_IDS = [5, 23, 13, 9, 18, 6, 21, 12, 15, 4, 20, 17, 14, 16, 10, 8, 11, 7, 22, 19]
_LOWER_IDS = list(range(33, 53))
VOCAB_SIZE = 53


def _make_mock_tokenizer():
    """Create a mock tokenizer that behaves like ESM2 + lowercase tokens."""
    tok = MagicMock()
    tok.cls_token_id = 0
    tok.pad_token_id = 1
    tok.eos_token_id = 2
    tok.unk_token_id = 3
    tok.mask_token_id = 32

    _token_to_id = {}
    for i, aa in enumerate(_AA_ORDER):
        _token_to_id[aa] = _UPPER_IDS[i]
        _token_to_id[aa.lower()] = _LOWER_IDS[i]

    tok.convert_tokens_to_ids = lambda t: _token_to_id.get(t, tok.unk_token_id)

    def tokenize_call(seqs, return_tensors="pt", padding=True, truncation=True,
                      max_length=512, add_special_tokens=True):
        if isinstance(seqs, str):
            seqs = [seqs]
        batch_ids = []
        for s in seqs:
            ids = [tok.cls_token_id] + [_token_to_id.get(c, tok.unk_token_id) for c in s.upper()] + [tok.eos_token_id]
            batch_ids.append(ids)
        max_len = max(len(ids) for ids in batch_ids)
        padded = [ids + [tok.pad_token_id] * (max_len - len(ids)) for ids in batch_ids]
        input_ids = torch.tensor(padded)
        attention_mask = (input_ids != tok.pad_token_id).long()
        return {"input_ids": input_ids, "attention_mask": attention_mask}

    tok.side_effect = tokenize_call
    tok.__call__ = tokenize_call
    return tok


def _make_mock_model():
    """Create a mock SFT_ESM2 model with 2-class origin head (logits_mut is [B, L])."""
    model = MagicMock()
    model.tokenizer = _make_mock_tokenizer()
    model.eval = MagicMock(return_value=model)
    model.to = MagicMock(return_value=model)
    model.use_germline_genes = False

    # lowercase_aa_token_ids: {upper_id: lower_id}
    model.lowercase_aa_token_ids = {
        _UPPER_IDS[i]: _LOWER_IDS[i] for i in range(20)
    }

    # Deterministic output for reproducibility
    torch.manual_seed(42)

    def forward_multihead(input_ids, attention_mask, v_gene_ids=None, j_gene_ids=None, region_ids=None):
        B, L = input_ids.shape
        logits_aa = torch.randn(B, L, 33)
        logits_aa_ngl = None
        # 2-class origin: [B, L] (squeezed from [B, L, 1])
        logits_mut = torch.randn(B, L)
        alpha = torch.sigmoid(torch.randn(B, L))
        logits_final = torch.randn(B, L, VOCAB_SIZE)
        hidden = torch.randn(B, L, 480)
        return logits_aa, logits_aa_ngl, logits_mut, alpha, logits_final, hidden

    model._forward_multihead = MagicMock(side_effect=forward_multihead)

    return model


@pytest.fixture
def prism_model():
    """Build a PrismModel backed by mocks."""
    mock_model = _make_mock_model()
    return PrismModel(mock_model, gene_vocab=None, device="cpu")


# ---------------------------------------------------------------------------
# Tests: score_binding
# ---------------------------------------------------------------------------

class TestScoreBinding:
    """Tests for the score_binding method."""

    def test_single_mutant_returns_float(self, prism_model):
        """Single mutant should return a scalar float."""
        score = prism_model.score_binding("ACDEF", "ACGEF")
        assert isinstance(score, (float, np.floating))

    def test_multiple_mutants_returns_array(self, prism_model):
        """Multiple mutants should return an array of shape [N]."""
        scores = prism_model.score_binding("ACDEF", ["ACGEF", "AGDEF", "ACDEY"])
        assert isinstance(scores, np.ndarray)
        assert scores.shape == (3,)

    def test_no_mutation_returns_zero(self, prism_model):
        """When mutant == WT, the score should be 0."""
        score = prism_model.score_binding("ACDEF", "ACDEF")
        assert score == 0.0

    def test_length_mismatch_raises(self, prism_model):
        """When WT and mutant have different lengths, should raise ValueError."""
        with pytest.raises(ValueError, match="[Ll]ength"):
            prism_model.score_binding("ACDEF", "ACDE")

    def test_signal_origin_prob(self, prism_model):
        """Scoring with signal='origin_prob' should also work."""
        score = prism_model.score_binding("ACDEF", "ACGEF", signal="origin_prob")
        assert isinstance(score, (float, np.floating))

    def test_signal_ngl_logprob(self, prism_model):
        """Scoring with signal='ngl_logprob' should also work."""
        score = prism_model.score_binding("ACDEF", "ACGEF", signal="ngl_logprob")
        assert isinstance(score, (float, np.floating))

    def test_signal_alpha(self, prism_model):
        """Scoring with signal='alpha' should also work."""
        score = prism_model.score_binding("ACDEF", "ACGEF", signal="alpha")
        assert isinstance(score, (float, np.floating))

    def test_aggregation_mean(self, prism_model):
        """Scoring with aggregation='mean' should also work."""
        score = prism_model.score_binding("ACDEF", "AGDEF", aggregation="mean")
        assert isinstance(score, (float, np.floating))

    def test_multi_site_mutation(self, prism_model):
        """Multiple mutations in a single sequence should return valid scores."""
        score_sum = prism_model.score_binding("ACDEF", "GCGEY", aggregation="sum")
        score_mean = prism_model.score_binding("ACDEF", "GCGEY", aggregation="mean")
        assert isinstance(score_sum, (float, np.floating))
        assert isinstance(score_mean, (float, np.floating))
        assert np.isfinite(score_sum)
        assert np.isfinite(score_mean)

    def test_invalid_signal_raises(self, prism_model):
        """Invalid signal parameter should raise ValueError."""
        with pytest.raises(ValueError, match="[Ss]ignal"):
            prism_model.score_binding("ACDEF", "ACGEF", signal="invalid")

    def test_invalid_aggregation_raises(self, prism_model):
        """Invalid aggregation parameter should raise ValueError."""
        with pytest.raises(ValueError, match="[Aa]ggregation"):
            prism_model.score_binding("ACDEF", "ACGEF", aggregation="invalid")


# ---------------------------------------------------------------------------
# Tests: score_developability
# ---------------------------------------------------------------------------

class TestScoreDevelopability:
    """Tests for the score_developability method."""

    def test_single_sequence_returns_dict(self, prism_model):
        """Single sequence should return a dict with all 6 properties."""
        result = prism_model.score_developability("ACDEFGHIKL")
        assert isinstance(result, dict)
        expected_keys = {
            "self_interaction", "hydrophobicity", "thermal_stability",
            "immunogenicity", "polyreactivity", "expression",
        }
        assert set(result.keys()) == expected_keys

    def test_all_values_are_finite(self, prism_model):
        """All property scores should be finite floats."""
        result = prism_model.score_developability("ACDEFGHIKL")
        for key, val in result.items():
            assert np.isfinite(val), f"{key} is not finite: {val}"

    def test_multiple_sequences_returns_list(self, prism_model):
        """Multiple sequences should return a list of dicts."""
        results = prism_model.score_developability(["ACDEFGHIKL", "MNPQRSTVWY"])
        assert isinstance(results, list)
        assert len(results) == 2
        for r in results:
            assert isinstance(r, dict)
            assert len(r) == 6

    def test_specific_properties_filter(self, prism_model):
        """Requesting specific properties should only return those."""
        result = prism_model.score_developability(
            "ACDEFGHIKL",
            properties=["immunogenicity", "expression"]
        )
        assert isinstance(result, dict)
        assert set(result.keys()) == {"immunogenicity", "expression"}

    def test_invalid_property_raises(self, prism_model):
        """Invalid property name should raise ValueError."""
        with pytest.raises(ValueError, match="[Pp]roperty"):
            prism_model.score_developability(
                "ACDEFGHIKL",
                properties=["invalid_property"]
            )

    def test_self_interaction_is_fraction(self, prism_model):
        """Self-interaction score (fraction below threshold) should be in [0, 1]."""
        result = prism_model.score_developability("ACDEFGHIKL")
        assert 0.0 <= result["self_interaction"] <= 1.0

    def test_immunogenicity_is_negative(self, prism_model):
        """Immunogenicity (mean GL log-prob) should typically be negative."""
        result = prism_model.score_developability("ACDEFGHIKL")
        # Mean log-prob of random logits is overwhelmingly negative
        assert result["immunogenicity"] < 0.0

    def test_expression_is_negative(self, prism_model):
        """Expression (mean NGL log-prob) should typically be negative."""
        result = prism_model.score_developability("ACDEFGHIKL")
        assert result["expression"] < 0.0


# ---------------------------------------------------------------------------
# Tests: _masked_forward_full (internal helper)
# ---------------------------------------------------------------------------

class TestMaskedForwardFull:
    """Tests for the internal _masked_forward_full method."""

    def test_returns_all_signals(self, prism_model):
        """Should return dict with all 5 signal types."""
        result = prism_model._masked_forward_full("ACDEF", batch_size=64)
        expected_keys = {"gl_logprob", "ngl_logprob", "marg_logprob", "alpha", "origin_logit"}
        assert set(result.keys()) == expected_keys

    def test_signal_shapes_match(self, prism_model):
        """All signals should have length == number of AA positions in the sequence."""
        seq = "ACDEF"
        result = prism_model._masked_forward_full(seq, batch_size=64)
        n_aa = len(seq)
        for key, val in result.items():
            assert len(val) == n_aa, f"{key} has length {len(val)}, expected {n_aa}"

    def test_logprobs_are_negative(self, prism_model):
        """Log probabilities should be <= 0."""
        result = prism_model._masked_forward_full("ACDEF", batch_size=64)
        for key in ["gl_logprob", "ngl_logprob", "marg_logprob"]:
            assert np.all(result[key] <= 0.0 + 1e-6), f"{key} has positive values"
