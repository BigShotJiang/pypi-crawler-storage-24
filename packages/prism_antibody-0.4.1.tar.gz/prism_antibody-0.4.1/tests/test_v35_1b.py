"""Tests for v35.1b features: ngl_label_smoothing for NGL AA head loss."""

import inspect

import pytest
import torch
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Test 1: ngl_label_smoothing parameter in SFT_ESM2
# ---------------------------------------------------------------------------

class TestNglLabelSmoothing:
    """Test that ngl_label_smoothing parameter is accepted and stored."""

    def test_parameter_exists_in_init(self):
        """SFT_ESM2 should accept ngl_label_smoothing parameter."""
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'ngl_label_smoothing' in sig.parameters, \
            "SFT_ESM2.__init__ should accept ngl_label_smoothing"

    def test_default_is_zero(self):
        """Default ngl_label_smoothing should be 0.0 (no smoothing)."""
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert sig.parameters['ngl_label_smoothing'].default == 0.0

    def test_used_in_training_step(self):
        """_training_step_multihead should reference ngl_label_smoothing."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        assert 'ngl_label_smoothing' in source or 'label_smoothing' in source, \
            "_training_step_multihead should use ngl_label_smoothing"

    def test_passed_from_train_esm_config(self):
        """train_esm.py should pass ngl_label_smoothing from config to model."""
        with open('/home/jk661/projects/Devant/prism/script/train_esm.py') as f:
            source = f.read()
        assert 'ngl_label_smoothing' in source, \
            "train_esm.py should pass ngl_label_smoothing from config"


# ---------------------------------------------------------------------------
# Test 2: _focal_loss with label_smoothing behavior
# ---------------------------------------------------------------------------

class TestFocalLossLabelSmoothing:
    """Test that _focal_loss supports label_smoothing parameter."""

    def test_focal_loss_accepts_label_smoothing(self):
        """_focal_loss should accept label_smoothing keyword argument."""
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2._focal_loss)
        assert 'label_smoothing' in sig.parameters, \
            "_focal_loss should accept label_smoothing parameter"

    def test_label_smoothing_zero_matches_original(self):
        """With label_smoothing=0.0, output should match original focal loss."""
        from prism.model import SFT_ESM2

        # Create a minimal model just to call _focal_loss
        # We'll use a mock approach: call the method as an unbound function
        # by creating the necessary attributes
        model = _make_minimal_model()

        logits = torch.randn(4, 10, 33)
        targets = torch.randint(0, 33, (4, 10))
        targets[0, :3] = -100  # some ignored positions

        loss_no_smooth = model._focal_loss(logits, targets, gamma=2.0, label_smoothing=0.0)
        loss_default = model._focal_loss(logits, targets, gamma=2.0)

        assert torch.allclose(loss_no_smooth, loss_default, atol=1e-6), \
            "label_smoothing=0.0 should match default behavior"

    def test_label_smoothing_reduces_overconfidence_penalty(self):
        """With label_smoothing > 0, loss for confident-but-wrong predictions should be lower
        because some probability mass is spread to other classes."""
        model = _make_minimal_model()

        # Create a confident prediction: logits strongly predict class 0
        B, L, V = 2, 5, 33
        logits = torch.zeros(B, L, V)
        logits[:, :, 0] = 10.0  # very confident on class 0

        # But the target is class 1 (model is confidently WRONG)
        targets = torch.ones(B, L, dtype=torch.long)

        loss_no_smooth = model._focal_loss(logits, targets, gamma=2.0, label_smoothing=0.0)
        loss_smooth = model._focal_loss(logits, targets, gamma=2.0, label_smoothing=0.1)

        # With smoothing, the "correct" target has some mass on class 0 too,
        # so the loss for being wrong is slightly lower
        assert loss_smooth < loss_no_smooth, \
            f"Smoothed loss ({loss_smooth:.4f}) should be < unsmoothed ({loss_no_smooth:.4f}) for wrong predictions"

    def test_label_smoothing_increases_loss_for_correct_predictions(self):
        """With label_smoothing > 0, loss for confident-and-correct predictions
        should be slightly higher because target is softened."""
        model = _make_minimal_model()

        B, L, V = 2, 5, 33
        logits = torch.zeros(B, L, V)
        logits[:, :, 0] = 10.0  # very confident on class 0

        targets = torch.zeros(B, L, dtype=torch.long)  # correct!

        loss_no_smooth = model._focal_loss(logits, targets, gamma=2.0, label_smoothing=0.0)
        loss_smooth = model._focal_loss(logits, targets, gamma=2.0, label_smoothing=0.1)

        # With smoothing, the target is softened so even correct predictions get more loss
        assert loss_smooth > loss_no_smooth, \
            f"Smoothed loss ({loss_smooth:.4f}) should be > unsmoothed ({loss_no_smooth:.4f}) for correct predictions"

    def test_label_smoothing_only_on_ngl_head(self):
        """GL AA head and Final head should NOT receive label smoothing.
        Only the NGL AA head loss should use ngl_label_smoothing."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)

        # Count how many times label_smoothing appears in the training step
        # It should only appear in the NGL AA head loss section
        lines = source.split('\n')
        smoothing_lines = [l for l in lines if 'label_smoothing' in l and 'self.ngl_label_smoothing' in l]
        assert len(smoothing_lines) >= 1, \
            "ngl_label_smoothing should be used at least once in training step"

        # Verify it's NOT used for the GL AA head loss (the first _focal_loss call)
        # Look at the GL AA head loss calls - they should NOT pass label_smoothing
        # We check by looking at the NGL AA head section specifically
        ngl_section_found = False
        for i, line in enumerate(lines):
            if 'NGL AA Head Loss' in line:
                ngl_section_found = True
            if ngl_section_found and 'label_smoothing' in line:
                break
        assert ngl_section_found, "Should find NGL AA Head Loss section with label_smoothing"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _MinimalModel:
    """Minimal stand-in for SFT_ESM2 to test _focal_loss without full init."""
    def __init__(self):
        self.ngl_loss_alpha = 1.0
        self.ngl_label_smoothing = 0.0


def _make_minimal_model():
    """Create a minimal model that can call _focal_loss."""
    from prism.model import SFT_ESM2
    model = _MinimalModel()
    # Bind the _focal_loss method
    model._focal_loss = SFT_ESM2._focal_loss.__get__(model, type(model))
    return model
