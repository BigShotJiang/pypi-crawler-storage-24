"""Tests for v37 GL-NGL Divergence Loss.

Tests that:
1. New params (divergence_loss_weight, etc.) are accepted by SFT_ESM2
2. _compute_divergence_loss computes KL/JS divergence correctly
3. Clamping to max_kl_divergence works
4. Warmup gating prevents divergence loss before warmup_steps
5. Divergence loss is integrated into _training_step_multihead
6. Validation metrics (val/GL_NGL_KL) are logged
"""

import inspect
import numpy as np
import pytest
import torch
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Test 1: Parameter acceptance
# ---------------------------------------------------------------------------

class TestDivergenceParams:
    """Test that SFT_ESM2 accepts all v37 divergence params."""

    def test_divergence_loss_weight_param(self):
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'divergence_loss_weight' in sig.parameters
        assert sig.parameters['divergence_loss_weight'].default == 0.0

    def test_divergence_warmup_steps_param(self):
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'divergence_warmup_steps' in sig.parameters
        assert sig.parameters['divergence_warmup_steps'].default == 2000

    def test_max_kl_divergence_param(self):
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'max_kl_divergence' in sig.parameters
        assert sig.parameters['max_kl_divergence'].default == 10.0

    def test_divergence_type_param(self):
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'divergence_type' in sig.parameters
        assert sig.parameters['divergence_type'].default == "kl"


# ---------------------------------------------------------------------------
# Test 2: _compute_divergence_loss method
# ---------------------------------------------------------------------------

class TestComputeDivergenceLoss:
    """Test the _compute_divergence_loss method."""

    def test_method_exists(self):
        from prism.model import SFT_ESM2
        assert hasattr(SFT_ESM2, '_compute_divergence_loss'), \
            "SFT_ESM2 should have _compute_divergence_loss method"

    def test_kl_divergence_basic(self):
        """KL divergence between different distributions should be positive."""
        from prism.model import SFT_ESM2

        # Simulate: GL head predicts uniform, NGL head predicts peaked
        B, L, V = 2, 10, 20
        logits_gl = torch.zeros(B, L, V)  # uniform
        logits_ngl = torch.randn(B, L, V) * 3  # peaked

        # NGL mask: positions 2-5 are NGL
        ngl_masks = torch.zeros(B, L)
        ngl_masks[:, 2:6] = 1

        # labels_aa: mark positions 2-5 as masked (not -100)
        labels_aa = torch.full((B, L), -100)
        labels_aa[:, 2:6] = 5  # some valid token id

        result = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            max_kl_divergence=10.0, divergence_type="kl"
        )
        # Result should be negative (we negate to maximize divergence)
        assert result.item() < 0, "Divergence loss should be negative (maximizing KL)"

    def test_kl_divergence_identical_distributions(self):
        """KL divergence between identical distributions should be ~0."""
        from prism.model import SFT_ESM2

        B, L, V = 2, 10, 20
        logits = torch.randn(B, L, V)

        ngl_masks = torch.zeros(B, L)
        ngl_masks[:, 2:6] = 1
        labels_aa = torch.full((B, L), -100)
        labels_aa[:, 2:6] = 5

        result = SFT_ESM2._compute_divergence_loss(
            logits, logits, ngl_masks, labels_aa,
            max_kl_divergence=10.0, divergence_type="kl"
        )
        # Should be near zero (identical distributions)
        assert abs(result.item()) < 0.01, \
            f"KL divergence of identical dists should be ~0, got {result.item()}"

    def test_clamping_works(self):
        """Per-position KL should be clamped to max_kl_divergence."""
        from prism.model import SFT_ESM2

        B, L, V = 1, 5, 20
        # Very different distributions → large KL
        logits_gl = torch.zeros(B, L, V)
        logits_ngl = torch.zeros(B, L, V)
        logits_ngl[:, :, 0] = 100.0  # extremely peaked

        ngl_masks = torch.ones(B, L)
        labels_aa = torch.full((B, L), 5)

        max_kl = 2.0
        result = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            max_kl_divergence=max_kl, divergence_type="kl"
        )
        # Result magnitude should not exceed max_kl (negative of clamped mean)
        assert abs(result.item()) <= max_kl + 0.01, \
            f"Clamped divergence should be <= {max_kl}, got {abs(result.item())}"

    def test_js_divergence(self):
        """JS divergence should also work and be bounded."""
        from prism.model import SFT_ESM2

        B, L, V = 2, 10, 20
        logits_gl = torch.zeros(B, L, V)
        logits_ngl = torch.randn(B, L, V) * 3

        ngl_masks = torch.zeros(B, L)
        ngl_masks[:, 2:6] = 1
        labels_aa = torch.full((B, L), -100)
        labels_aa[:, 2:6] = 5

        result = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            max_kl_divergence=10.0, divergence_type="js"
        )
        assert result.item() < 0, "JS divergence loss should be negative"
        # JS is bounded by ln(2) ≈ 0.693
        assert abs(result.item()) <= 0.7, \
            f"JS divergence should be <= ln(2), got {abs(result.item())}"

    def test_no_ngl_positions_returns_zero(self):
        """If no NGL positions are masked, loss should be 0."""
        from prism.model import SFT_ESM2

        B, L, V = 2, 10, 20
        logits_gl = torch.randn(B, L, V)
        logits_ngl = torch.randn(B, L, V)

        ngl_masks = torch.zeros(B, L)  # No NGL positions
        labels_aa = torch.full((B, L), -100)

        result = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            max_kl_divergence=10.0, divergence_type="kl"
        )
        assert result.item() == 0.0, "No NGL positions → loss should be 0"


# ---------------------------------------------------------------------------
# Test 3: Integration with training step
# ---------------------------------------------------------------------------

class TestDivergenceInTrainingStep:
    """Test divergence loss integration in _training_step_multihead."""

    def test_training_step_references_divergence(self):
        """_training_step_multihead should reference divergence_loss_weight."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        assert 'divergence_loss_weight' in source, \
            "_training_step_multihead should use divergence_loss_weight"

    def test_training_step_logs_divergence(self):
        """_training_step_multihead should log train/Divergence_Loss."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        assert 'Divergence_Loss' in source, \
            "_training_step_multihead should log Divergence_Loss"


# ---------------------------------------------------------------------------
# Test 4: Validation metrics
# ---------------------------------------------------------------------------

class TestDivergenceValidationMetrics:
    """Test that validation step logs divergence metrics."""

    def test_validation_logs_gl_ngl_kl(self):
        """_validation_step_multihead should log val/GL_NGL_KL."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._validation_step_multihead)
        assert 'GL_NGL_KL' in source, \
            "_validation_step_multihead should log GL_NGL_KL"

    def test_validation_logs_divergence_at_cdr(self):
        """_validation_step_multihead should log val/Divergence_At_CDR."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._validation_step_multihead)
        assert 'Divergence_At_CDR' in source, \
            "_validation_step_multihead should log Divergence_At_CDR"

    def test_validation_logs_divergence_at_fr(self):
        """_validation_step_multihead should log val/Divergence_At_FR."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._validation_step_multihead)
        assert 'Divergence_At_FR' in source, \
            "_validation_step_multihead should log Divergence_At_FR"
