#!/usr/bin/env python
# coding: utf-8
"""
Tests for v38 3-class origin head (GL / SynNGL / NGL).

Tests are grouped into:
  - Multiclass focal loss (5 tests)
  - 3-class gating (4 tests)
  - Dataset 3-class labels (4 tests)
  - Collate dtype (2 tests)
  - Backward compatibility (2 tests)
"""

import numpy as np
import pandas as pd
import pytest
import torch
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_model(num_origin_classes=2, synth_weight=0.5, origin_class_weights=None, **kwargs):
    """Instantiate a minimal SFT_ESM2 model for testing."""
    from prism.model import SFT_ESM2

    defaults = dict(
        seed=42,
        model_identifier="esm2_t6_8M_UR50D",
        peak_learning_rate=1e-4,
        adam_beta1=0.9,
        adam_beta2=0.999,
        adam_epsilon=1e-8,
        WD=0.01,
        warmup_steps=10,
        max_steps=100,
        logging_steps=10,
        eval_steps=10,
        batch_size=2,
        mask_prob=0.15,
        num_unfrozen_transformer_blocks=2,
        loss_type="focal_loss",
        random_weights=True,
        add_custom_tokens=True,
        custom_token_strategy="lowercase_ngl",
        activation_function="gelu",
        use_multihead_architecture=True,
        use_alpha_gating=True,
        detach_origin_gradient=True,
        tie_word_embeddings=False,
        num_origin_classes=num_origin_classes,
        synth_weight=synth_weight,
        origin_class_weights=origin_class_weights,
    )
    defaults.update(kwargs)
    return SFT_ESM2(**defaults)


# ===========================================================================
# GROUP 1: Multiclass Focal Loss
# ===========================================================================


class TestMulticlassFocalLoss:
    """Tests for the new _multiclass_focal_loss method."""

    def test_focal_loss_uniform_logits_positive(self):
        """Uniform logits should produce a positive loss."""
        model = _make_model(num_origin_classes=3)

        B, L, C = 2, 10, 3
        logits = torch.zeros(B, L, C)
        targets = torch.randint(0, C, (B, L))

        loss = model._multiclass_focal_loss(logits, targets, gamma=2.0)
        assert loss.item() > 0, f"Expected positive loss, got {loss.item()}"

    def test_focal_loss_ignore_index_excludes(self):
        """Positions with ignore_index=-1 should be excluded from loss."""
        model = _make_model(num_origin_classes=3)

        B, L, C = 2, 10, 3
        logits = torch.randn(B, L, C)
        # All targets are -1 except first position
        targets = torch.full((B, L), -1, dtype=torch.long)
        targets[:, 0] = 1

        loss_with_ignore = model._multiclass_focal_loss(logits, targets, gamma=2.0, ignore_index=-1)
        # Loss should be computed only from the first position
        assert loss_with_ignore.item() > 0

    def test_focal_loss_class_weights(self):
        """Rare classes (higher weight) should produce higher loss when wrong."""
        model = _make_model(num_origin_classes=3)

        B, L, C = 4, 20, 3
        # Logits that are "wrong" for class 2 (predict class 0)
        logits = torch.zeros(B, L, C)
        logits[:, :, 0] = 5.0  # Strong prediction for class 0
        targets = torch.full((B, L), 2, dtype=torch.long)  # True class is 2

        loss_unweighted = model._multiclass_focal_loss(logits, targets, gamma=2.0)
        loss_weighted = model._multiclass_focal_loss(
            logits, targets, gamma=2.0,
            class_weights=torch.tensor([1.0, 1.0, 8.0])  # Class 2 upweighted
        )
        assert loss_weighted.item() > loss_unweighted.item(), (
            f"Weighted loss ({loss_weighted.item():.4f}) should exceed "
            f"unweighted ({loss_unweighted.item():.4f})"
        )

    def test_focal_loss_all_ignored_returns_zero(self):
        """If all targets are ignore_index, loss should be 0."""
        model = _make_model(num_origin_classes=3)

        B, L, C = 2, 10, 3
        logits = torch.randn(B, L, C)
        targets = torch.full((B, L), -1, dtype=torch.long)

        loss = model._multiclass_focal_loss(logits, targets, gamma=2.0, ignore_index=-1)
        assert loss.item() == 0.0, f"Expected 0 loss for all-ignored, got {loss.item()}"

    def test_focal_loss_correct_prediction_low_loss(self):
        """When model is confident and correct, focal weight should suppress loss."""
        model = _make_model(num_origin_classes=3)

        B, L, C = 2, 10, 3
        # Very confident correct predictions
        logits_confident = torch.zeros(B, L, C)
        logits_confident[:, :, 1] = 20.0  # Very confident class 1
        targets = torch.ones(B, L, dtype=torch.long)

        loss_confident = model._multiclass_focal_loss(logits_confident, targets, gamma=2.0)

        # Less confident
        logits_uncertain = torch.zeros(B, L, C)
        logits_uncertain[:, :, 1] = 1.0  # Slightly confident class 1
        loss_uncertain = model._multiclass_focal_loss(logits_uncertain, targets, gamma=2.0)

        assert loss_confident.item() < loss_uncertain.item(), (
            f"Confident loss ({loss_confident.item():.6f}) should be less than "
            f"uncertain loss ({loss_uncertain.item():.6f})"
        )


# ===========================================================================
# GROUP 2: 3-Class Gating
# ===========================================================================


class TestThreeClassGating:
    """Tests for 3-class gating in the 53-vocab construction."""

    def test_effective_probs_sum_to_one(self):
        """P_eff_GL + P_eff_NGL should approximately sum to 1."""
        model = _make_model(num_origin_classes=3, synth_weight=0.5)

        B, L = 2, 10
        # Simulate 3-class origin logits
        logits_mut = torch.randn(B, L, 3)
        log_p = F.log_softmax(logits_mut, dim=-1)

        sw = model.synth_weight
        log_sw = torch.log(torch.tensor(sw))
        log_1_minus_sw = torch.log(torch.tensor(1.0 - sw))

        log_p_gl_raw = log_p[:, :, 0]
        log_p_syn = log_p[:, :, 1]
        log_p_ngl_raw = log_p[:, :, 2]

        log_p_ngl_eff = torch.logaddexp(log_p_ngl_raw, log_sw + log_p_syn)
        log_p_gl_eff = torch.logaddexp(log_p_gl_raw, log_1_minus_sw + log_p_syn)

        # exp(log_p_ngl_eff) + exp(log_p_gl_eff) should ≈ 1
        sum_probs = torch.exp(log_p_ngl_eff) + torch.exp(log_p_gl_eff)
        assert torch.allclose(sum_probs, torch.ones_like(sum_probs), atol=1e-5), (
            f"Effective probs don't sum to 1: max deviation {(sum_probs - 1.0).abs().max().item():.6f}"
        )

    def test_synth_weight_0_gives_binary(self):
        """sw=0 → SynNGL merges entirely into GL, recovering 2-class behavior."""
        model = _make_model(num_origin_classes=3, synth_weight=1e-7)  # Near-zero

        B, L = 2, 10
        logits_mut = torch.randn(B, L, 3)
        log_p = F.log_softmax(logits_mut, dim=-1)

        # With sw≈0: P_eff_GL = P(GL) + P(SynNGL), P_eff_NGL = P(NGL)
        p_gl = torch.exp(log_p[:, :, 0])
        p_syn = torch.exp(log_p[:, :, 1])
        p_ngl = torch.exp(log_p[:, :, 2])

        p_eff_gl = p_gl + p_syn  # All SynNGL flows to GL
        p_eff_ngl = p_ngl

        assert torch.allclose(p_eff_gl + p_eff_ngl, torch.ones_like(p_eff_gl), atol=1e-5)
        # P_eff_NGL should equal P(NGL) exactly
        assert torch.allclose(p_eff_ngl, p_ngl, atol=1e-5)

    def test_synth_weight_1_merges_synth_into_ngl(self):
        """sw=1 → SynNGL merges entirely into NGL."""
        B, L = 2, 10
        logits_mut = torch.randn(B, L, 3)
        log_p = F.log_softmax(logits_mut, dim=-1)

        sw = 1.0 - 1e-7  # Near 1

        p_gl = torch.exp(log_p[:, :, 0])
        p_syn = torch.exp(log_p[:, :, 1])
        p_ngl = torch.exp(log_p[:, :, 2])

        p_eff_ngl = p_ngl + sw * p_syn  # All SynNGL flows to NGL
        p_eff_gl = p_gl + (1 - sw) * p_syn  # ≈ P(GL)

        assert torch.allclose(p_eff_gl + p_eff_ngl, torch.ones_like(p_eff_gl), atol=1e-4)
        # P_eff_GL should be approximately P(GL)
        assert torch.allclose(p_eff_gl, p_gl, atol=1e-4)

    def test_gating_output_shape_53_vocab(self):
        """3-class gating should produce [B, L, 53] output."""
        model = _make_model(num_origin_classes=3, synth_weight=0.5)
        model.eval()

        B, L = 2, 20
        V = len(model.tokenizer)

        # Create dummy inputs
        input_ids = torch.randint(4, 24, (B, L))
        input_ids[:, 0] = model.tokenizer.cls_token_id
        attention_mask = torch.ones(B, L, dtype=torch.long)

        with torch.no_grad():
            logits_aa, logits_aa_ngl, logits_mut, alpha, logits_final, hidden = model._forward_multihead(
                input_ids, attention_mask
            )

        assert logits_final is not None, "logits_final should not be None with alpha gating"
        assert logits_final.shape == (B, L, 53), f"Expected (B, L, 53), got {logits_final.shape}"


# ===========================================================================
# GROUP 3: Dataset 3-Class Labels
# ===========================================================================


class TestDataset3ClassLabels:
    """Tests for 3-class label assignment in SeqSeqDataset."""

    def _make_dataset_row(self, hc_mut_codes="", synthetic_ngl_heavy=""):
        """Create a minimal DataFrame row for testing."""
        from transformers import AutoTokenizer
        from prism.io_utils import SeqSeqDataset

        seq = "EVQLVESGGGLVQPGG"  # 16 AA heavy chain
        data = {
            "HEAVY_CHAIN_AA_SEQUENCE": [seq],
            "chain_type": ["heavy"],
            "hc_mut_codes": [hc_mut_codes],
        }
        if synthetic_ngl_heavy:
            data["synthetic_ngl_heavy"] = [synthetic_ngl_heavy]

        df = pd.DataFrame(data)
        tokenizer = AutoTokenizer.from_pretrained("facebook/esm2_t6_8M_UR50D")
        tokenizer.add_tokens(['a', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l',
                              'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'y'])
        return df, tokenizer

    def test_gl_position_class_0(self):
        """No mutation + synth=0 → class 0 (GL)."""
        from prism.io_utils import SeqSeqDataset

        # All zeros in synthetic_ngl, no mutations
        df, tokenizer = self._make_dataset_row(
            hc_mut_codes="",
            synthetic_ngl_heavy="0000000000000000"
        )
        ds = SeqSeqDataset(df, tokenizer, mask_prob=0.15, use_3class_origin=True)
        _, ngl_mask = ds[0]
        # All positions should be class 0 (GL)
        # ngl_mask has padding, check the first 16 AA positions
        assert np.all(ngl_mask[1:17] == 0), f"GL positions should be class 0, got {ngl_mask[1:17]}"

    def test_synngl_position_class_1(self):
        """No mutation + synth=1 → class 1 (SynNGL)."""
        from prism.io_utils import SeqSeqDataset

        # Position 5 has synth=1, no mutations
        synth = "0000010000000000"
        df, tokenizer = self._make_dataset_row(
            hc_mut_codes="",
            synthetic_ngl_heavy=synth
        )
        ds = SeqSeqDataset(df, tokenizer, mask_prob=0.15, use_3class_origin=True)
        _, ngl_mask = ds[0]
        # ngl_mask_heavy[5] = 1 (synth position 5), mapped directly to ngl_mask[5]
        # (existing convention: ngl_mask is NOT offset for CLS token;
        #  CLS position is handled via ignore_index in collate)
        assert ngl_mask[5] == 1, f"SynNGL position should be class 1, got {ngl_mask[5]}"
        # Position 0 should still be class 0
        assert ngl_mask[0] == 0, f"GL position should be class 0, got {ngl_mask[0]}"

    def test_ngl_position_class_2(self):
        """Has SHM mutation → class 2 (NGL), regardless of synth label."""
        from prism.io_utils import SeqSeqDataset

        # Position 5 has mutation AND synth=1 → should be class 2 (NGL wins)
        synth = "0000010000000000"
        df, tokenizer = self._make_dataset_row(
            hc_mut_codes="E6K",  # Position 6 (1-indexed) = position 5 (0-indexed)
            synthetic_ngl_heavy=synth
        )
        ds = SeqSeqDataset(df, tokenizer, mask_prob=0.15, use_3class_origin=True)
        _, ngl_mask = ds[0]
        # E6K → pos 5 (0-indexed) → ngl_mask_heavy[5] = 2 → ngl_mask[5] = 2
        assert ngl_mask[5] == 2, f"NGL position should be class 2, got {ngl_mask[5]}"

    def test_missing_synth_col_fallback_no_synngl(self):
        """No synthetic_ngl column → only GL (0) and NGL (2), no SynNGL (1)."""
        from prism.io_utils import SeqSeqDataset

        df, tokenizer = self._make_dataset_row(
            hc_mut_codes="E6K",
            synthetic_ngl_heavy=""  # Empty string (no synth data)
        )
        # Remove the column entirely
        if "synthetic_ngl_heavy" in df.columns:
            df = df.drop(columns=["synthetic_ngl_heavy"])
        ds = SeqSeqDataset(df, tokenizer, mask_prob=0.15, use_3class_origin=True)
        _, ngl_mask = ds[0]
        # Without synth data: mutations → class 2 (NGL), rest → class 0 (GL)
        # No class 1 (SynNGL) since we have no synth labels
        unique_vals = set(np.unique(ngl_mask))
        assert unique_vals.issubset({0, 2}), f"Without synth data, should be {{0, 2}}, got {unique_vals}"
        assert ngl_mask[5] == 2, f"Mutation position should be class 2, got {ngl_mask[5]}"


# ===========================================================================
# GROUP 4: Collate dtype
# ===========================================================================


class TestCollateDtype:
    """Tests for labels_mut dtype in collate function."""

    def _make_collate_fn(self, use_3class_origin=False):
        from transformers import AutoTokenizer
        from prism.io_utils import make_collate_fn_multihead

        tokenizer = AutoTokenizer.from_pretrained("facebook/esm2_t6_8M_UR50D")
        tokenizer.add_tokens(['a', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l',
                              'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'y'])
        return make_collate_fn_multihead(
            tokenizer, 0.15, silent=True,
            use_3class_origin=use_3class_origin
        ), tokenizer

    def _make_batch(self, tokenizer, use_3class_origin=False):
        """Create a minimal batch of (input_ids, ngl_mask) tuples."""
        seq = "EVQLVESGGGLVQPGG"
        encoding = tokenizer(seq, padding="max_length", truncation=True, max_length=320, add_special_tokens=True)
        input_ids = torch.tensor(encoding["input_ids"], dtype=torch.long)
        L = len(encoding["input_ids"])

        if use_3class_origin:
            ngl_mask = np.zeros(L, dtype=np.int32)
            ngl_mask[3] = 1  # SynNGL
            ngl_mask[5] = 2  # NGL
        else:
            ngl_mask = np.zeros(L, dtype=np.int32)
            ngl_mask[5] = 1  # NGL

        return [(input_ids, ngl_mask), (input_ids.clone(), ngl_mask.copy())]

    def test_labels_mut_dtype_long_3class(self):
        """3-class collate should produce long (int64) labels_mut."""
        collate_fn, tokenizer = self._make_collate_fn(use_3class_origin=True)
        batch = self._make_batch(tokenizer, use_3class_origin=True)
        result = collate_fn(batch)
        # result is (input_ids, labels_aa, labels_mut, attention_mask, ngl_masks)
        labels_mut = result[2]
        assert labels_mut.dtype == torch.long, f"Expected long dtype, got {labels_mut.dtype}"

    def test_labels_mut_dtype_float_2class(self):
        """2-class collate should produce float labels_mut (backward compat)."""
        collate_fn, tokenizer = self._make_collate_fn(use_3class_origin=False)
        batch = self._make_batch(tokenizer, use_3class_origin=False)
        result = collate_fn(batch)
        labels_mut = result[2]
        assert labels_mut.dtype == torch.float32, f"Expected float32 dtype, got {labels_mut.dtype}"


# ===========================================================================
# GROUP 5: Backward Compatibility
# ===========================================================================


class TestBackwardCompat:
    """Tests for backward compatibility with 2-class models."""

    def test_default_params_binary(self):
        """Default num_origin_classes should be 2 (binary)."""
        from prism.model import SFT_ESM2

        model = _make_model()  # No explicit num_origin_classes
        assert model.num_origin_classes == 2, (
            f"Default should be 2, got {model.num_origin_classes}"
        )

    def test_checkpoint_shape_upgrade(self):
        """Loading a 2-class checkpoint into 3-class model should auto-migrate mut_head."""
        model_3class = _make_model(num_origin_classes=3)
        H = model_3class.mut_head.in_features

        # Verify 3-class model has correct shapes
        assert model_3class.mut_head.weight.shape == (3, H), (
            f"3-class mut_head should be (3, {H}), got {model_3class.mut_head.weight.shape}"
        )
        assert model_3class.origin_projection.weight.shape[1] == 3, (
            f"3-class origin_projection input should be 3, got {model_3class.origin_projection.weight.shape}"
        )

        # Simulate loading a 2-class checkpoint
        checkpoint = {"state_dict": {}}
        for name, param in model_3class.named_parameters():
            checkpoint["state_dict"][name] = param.data.clone()

        # Replace mut_head with 2-class shapes
        checkpoint["state_dict"]["mut_head.weight"] = torch.randn(1, H)
        checkpoint["state_dict"]["mut_head.bias"] = torch.randn(1)
        checkpoint["state_dict"]["origin_projection.weight"] = torch.randn(H, 1)
        checkpoint["state_dict"]["origin_projection.bias"] = torch.randn(H)

        # on_load_checkpoint should auto-reshape
        model_3class.on_load_checkpoint(checkpoint)

        # After reshape, shapes should match 3-class
        assert checkpoint["state_dict"]["mut_head.weight"].shape == (3, H)
        assert checkpoint["state_dict"]["mut_head.bias"].shape == (3,)
        assert checkpoint["state_dict"]["origin_projection.weight"].shape == (H, 3)
        assert checkpoint["state_dict"]["origin_projection.bias"].shape == (H,)
