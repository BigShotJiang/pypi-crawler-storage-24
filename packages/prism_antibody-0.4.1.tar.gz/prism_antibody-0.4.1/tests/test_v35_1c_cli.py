"""Tests for v35.1c perplexity and GL/NGL embedding extraction CLI scripts."""

import subprocess
import shutil
import sys
from pathlib import Path

import pytest

SCRIPT_DIR = Path(__file__).parent.parent / "script" / "analyze"
PPL_SCRIPT = SCRIPT_DIR / "1.pppl_calculation" / "inference_prism_ppl.py"
EMBED_SCRIPT = SCRIPT_DIR / "2.gl-ngl_calculation" / "extract_evo_ab_embeddings.py"

V35_1C_CHECKPOINT = (
    "/home/jk661/projects/Devant/prism/outputs/"
    "ESM2_v35.1c_paired_ngl_tuned_esm2_t12_35M_UR50D_custom_unfrozen12_lr1e-4_bs256/"
    "checkpoints/val_Final_PPL_NGL-23-2.3327.ckpt"
)
TEST_DATA = "/home/jk661/projects/Devant/prism/data/unpaired_OAS/linear_probe_data/test_linear.pkl"
DEV_DATA = "/home/jk661/projects/Devant/prism/data/ginkgo/developability_data.csv"

# Use conda run -n prism to avoid MKL library issues with system python
CONDA_RUN = shutil.which("conda")
USE_CONDA = CONDA_RUN is not None


def _run_script(script_path, args, timeout=300):
    """Run a Python script, using conda env if available."""
    if USE_CONDA:
        cmd = ["conda", "run", "-n", "prism", "python", str(script_path)] + args
    else:
        cmd = [sys.executable, str(script_path)] + args
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


class TestScriptsExist:
    """Verify that CLI scripts exist."""

    def test_ppl_script_exists(self):
        assert PPL_SCRIPT.exists(), f"PPL script not found: {PPL_SCRIPT}"

    def test_embed_script_exists(self):
        assert EMBED_SCRIPT.exists(), f"Embedding script not found: {EMBED_SCRIPT}"


class TestPPLScriptHelp:
    """Verify PPL script can be invoked with --help."""

    def test_help_flag(self):
        result = _run_script(PPL_SCRIPT, ["--help"], timeout=30)
        assert result.returncode == 0, f"STDERR:\n{result.stderr}"
        assert "checkpoint" in result.stdout.lower()
        assert "data" in result.stdout.lower()


class TestEmbedScriptHelp:
    """Verify embedding extraction script can be invoked with --help."""

    def test_help_flag(self):
        result = _run_script(EMBED_SCRIPT, ["--help"], timeout=30)
        assert result.returncode == 0, f"STDERR:\n{result.stderr}"
        assert "checkpoint" in result.stdout.lower()


@pytest.mark.skipif(
    not Path(V35_1C_CHECKPOINT).exists(), reason="v35.1c checkpoint not available"
)
@pytest.mark.skipif(
    not Path(DEV_DATA).exists(), reason="developability data not available"
)
class TestPPLScriptRun:
    """Integration test: run PPL script on a small subset."""

    def test_run_with_max_sequences(self, tmp_path):
        output_path = tmp_path / "ppl_output.csv"
        result = _run_script(
            PPL_SCRIPT,
            [
                "--checkpoint", V35_1C_CHECKPOINT,
                "--data_path", DEV_DATA,
                "--output_path", str(output_path),
                "--max_sequences", "3",
                "--device", "cpu",
            ],
            timeout=600,
        )
        assert result.returncode == 0, f"STDERR:\n{result.stderr}"
        assert output_path.exists(), "Output file not created"

        import pandas as pd
        df = pd.read_csv(output_path)
        assert any(
            "ppl" in c.lower() for c in df.columns
        ), f"No PPL column found. Columns: {list(df.columns)}"
        assert len(df) == 3


@pytest.mark.skipif(
    not Path(V35_1C_CHECKPOINT).exists(), reason="v35.1c checkpoint not available"
)
@pytest.mark.skipif(
    not Path(TEST_DATA).exists(), reason="test data not available"
)
class TestEmbedScriptRun:
    """Integration test: run embedding extraction on a small subset."""

    def test_extract_embeddings(self, tmp_path):
        # Create a small test PKL from the first 3 rows
        import pandas as pd
        df = pd.read_pickle(TEST_DATA).head(3)
        small_input = tmp_path / "small_test.pkl"
        df.to_pickle(small_input)

        output_path = tmp_path / "small_test_embed.pkl"
        result = _run_script(
            EMBED_SCRIPT,
            [
                "--checkpoint", V35_1C_CHECKPOINT,
                "--input_file", str(small_input),
                "--output_file", str(output_path),
                "--embed_name", "evo_ab_v35_1c",
                "--batch_size", "4",
                "--device", "cpu",
            ],
            timeout=600,
        )
        assert result.returncode == 0, f"STDERR:\n{result.stderr}"
        assert output_path.exists(), "Output file not created"

        out_df = pd.read_pickle(output_path)
        assert "embed_evo_ab_v35_1c_h" in out_df.columns
        assert "embed_evo_ab_v35_1c_l" in out_df.columns
        assert out_df["embed_evo_ab_v35_1c_h"].iloc[0].shape[1] == 480
