"""Tests for per-position pseudo-log-likelihood in api.py and stratified PPL in inference script."""

import importlib
import numpy as np
import pandas as pd
import pytest
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch


def _import_inference_module():
    """Import inference_prism_ppl without triggering torch import at module level."""
    spec = importlib.util.spec_from_file_location(
        "inference_prism_ppl",
        str(Path(__file__).parent.parent / "script" / "analyze" / "1.pppl_calculation" / "inference_prism_ppl.py"),
        submodule_search_locations=[],
    )
    # Mock torch and prism before importing
    mock_torch = MagicMock()
    mock_prism = MagicMock()
    saved_modules = {}
    for mod_name in ["torch", "prism"]:
        if mod_name in sys.modules:
            saved_modules[mod_name] = sys.modules[mod_name]
    sys.modules["torch"] = mock_torch
    sys.modules["prism"] = mock_prism
    try:
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    finally:
        # Restore
        for mod_name, mod in saved_modules.items():
            sys.modules[mod_name] = mod
        for mod_name in ["torch", "prism"]:
            if mod_name not in saved_modules and mod_name in sys.modules:
                del sys.modules[mod_name]
    return module


_mod = _import_inference_module()
build_position_annotations = _mod.build_position_annotations
compute_stratified_ppl = _mod.compute_stratified_ppl
FR_REGIONS = _mod.FR_REGIONS
CDR12_REGIONS = _mod.CDR12_REGIONS
CDR3_REGIONS = _mod.CDR3_REGIONS


# =============================================================================
# Tests for build_position_annotations
# =============================================================================

class TestBuildPositionAnnotations:
    def test_basic_heavy_light(self):
        """Heavy + light chain positions annotated correctly."""
        heavy = ["EVQLV"]  # 5 AA
        light = ["DIQMT"]  # 5 AA
        ngl = ["EVqLVDIQmT"]  # q (pos 2), m (pos 8) are NGL
        rmh = ["00145"]  # FR1, FR1, CDR1, FR3, CDR3
        rml = ["02345"]  # FR1, FR2, CDR2, FR3, CDR3

        anns = build_position_annotations(heavy, light, ngl, rmh, rml)
        assert len(anns) == 1
        ann = anns[0]

        # Chain
        np.testing.assert_array_equal(ann["chain"], ["H", "H", "H", "H", "H", "L", "L", "L", "L", "L"])
        # GL/NGL
        np.testing.assert_array_equal(ann["gl_ngl"], ["GL", "GL", "NGL", "GL", "GL", "GL", "GL", "GL", "NGL", "GL"])
        # Region
        np.testing.assert_array_equal(ann["region"], [0, 0, 1, 4, 5, 0, 2, 3, 4, 5])

    def test_all_gl(self):
        """Sequence with no NGL positions."""
        heavy = ["EVQLV"]
        light = ["DIQMT"]
        ngl = ["EVQLVDIQMT"]  # all uppercase = all GL
        rmh = ["00000"]
        rml = ["00000"]

        anns = build_position_annotations(heavy, light, ngl, rmh, rml)
        assert all(g == "GL" for g in anns[0]["gl_ngl"])

    def test_none_ngl_seq(self):
        """NGL_lowercase_seq is None — all positions treated as GL."""
        heavy = ["EVQLV"]
        light = ["DIQMT"]

        anns = build_position_annotations(heavy, light, None, ["00000"], ["00000"])
        assert all(g == "GL" for g in anns[0]["gl_ngl"])

    def test_none_region_mask(self):
        """No region mask — all region values should be -1."""
        heavy = ["EV"]
        light = ["DI"]
        ngl = ["EVDI"]

        anns = build_position_annotations(heavy, light, ngl, None, None)
        np.testing.assert_array_equal(anns[0]["region"], [-1, -1, -1, -1])

    def test_heavy_only(self):
        """Light chain is None."""
        heavy = ["EVQLV"]
        ngl = ["EVqLV"]
        rmh = ["01234"]

        anns = build_position_annotations(heavy, None, ngl, rmh, None)
        assert len(anns[0]["chain"]) == 5
        assert all(c == "H" for c in anns[0]["chain"])

    def test_empty_sequence(self):
        """Empty heavy and light sequences."""
        heavy = [""]
        light = [""]
        ngl = [""]

        anns = build_position_annotations(heavy, light, ngl, [""], [""])
        assert len(anns[0]["chain"]) == 0


# =============================================================================
# Tests for compute_stratified_ppl
# =============================================================================

class TestComputeStratifiedPPL:
    def _make_annotations(self, n_pos, chains, gl_ngls, regions):
        """Helper to build annotation dicts."""
        return {
            "chain": np.array(chains),
            "gl_ngl": np.array(gl_ngls),
            "region": np.array(regions, dtype=np.int8),
        }

    def test_single_category(self):
        """All positions are Heavy GL FR — only those categories have data."""
        logps = [np.array([-1.0, -2.0, -3.0])]
        anns = [self._make_annotations(3, ["H", "H", "H"], ["GL", "GL", "GL"], [0, 0, 0])]

        results = compute_stratified_ppl(logps, anns)

        # Total PPL = exp(-(-1-2-3)/3) = exp(2) ≈ 7.389
        assert results["Total"]["n_seqs"] == 1
        assert abs(results["Total"]["mean_ppl"] - np.exp(2.0)) < 0.01

        # NGL should have no data
        assert results["NGL"]["n_seqs"] == 0

        # Heavy_FR_GL should match Total
        assert abs(results["Heavy_FR_GL"]["mean_ppl"] - np.exp(2.0)) < 0.01

    def test_gl_vs_ngl_split(self):
        """GL and NGL positions give different PPLs."""
        # 4 positions: 2 GL (logp=-1), 2 NGL (logp=-3)
        logps = [np.array([-1.0, -1.0, -3.0, -3.0])]
        anns = [self._make_annotations(
            4,
            ["H", "H", "H", "H"],
            ["GL", "GL", "NGL", "NGL"],
            [0, 0, 0, 0],
        )]

        results = compute_stratified_ppl(logps, anns)
        # GL PPL = exp(1) ≈ 2.718
        assert abs(results["GL"]["mean_ppl"] - np.exp(1.0)) < 0.01
        # NGL PPL = exp(3) ≈ 20.086
        assert abs(results["NGL"]["mean_ppl"] - np.exp(3.0)) < 0.01

    def test_multiple_sequences(self):
        """Mean PPL is averaged across sequences."""
        logps = [
            np.array([-1.0, -1.0]),  # PPL = exp(1)
            np.array([-2.0, -2.0]),  # PPL = exp(2)
        ]
        anns = [
            self._make_annotations(2, ["H", "H"], ["GL", "GL"], [0, 0]),
            self._make_annotations(2, ["H", "H"], ["GL", "GL"], [0, 0]),
        ]

        results = compute_stratified_ppl(logps, anns)
        expected_mean = (np.exp(1.0) + np.exp(2.0)) / 2
        assert abs(results["Total"]["mean_ppl"] - expected_mean) < 0.01
        assert results["Total"]["n_seqs"] == 2
        assert results["Total"]["n_tokens"] == 4

    def test_region_stratification(self):
        """CDR3 NGL positions isolated from FR GL positions."""
        logps = [np.array([-1.0, -4.0])]
        anns = [self._make_annotations(
            2,
            ["H", "H"],
            ["GL", "NGL"],
            [0, 5],  # FR1 GL, CDR3 NGL
        )]

        results = compute_stratified_ppl(logps, anns)
        # FR_GL: exp(1)
        assert abs(results["FR_GL"]["mean_ppl"] - np.exp(1.0)) < 0.01
        assert results["FR_GL"]["n_tokens"] == 1
        # CDR3_NGL: exp(4)
        assert abs(results["CDR3_NGL"]["mean_ppl"] - np.exp(4.0)) < 0.01
        assert results["CDR3_NGL"]["n_tokens"] == 1
        # CDR12_GL should be empty
        assert results["CDR12_GL"]["n_seqs"] == 0

    def test_heavy_vs_light(self):
        """Heavy and light chain PPL computed separately."""
        logps = [np.array([-1.0, -1.0, -3.0, -3.0])]
        anns = [self._make_annotations(
            4,
            ["H", "H", "L", "L"],
            ["GL", "GL", "GL", "GL"],
            [0, 0, 0, 0],
        )]

        results = compute_stratified_ppl(logps, anns)
        assert abs(results["Heavy"]["mean_ppl"] - np.exp(1.0)) < 0.01
        assert abs(results["Light"]["mean_ppl"] - np.exp(3.0)) < 0.01

    def test_sequence_with_no_ngl_excluded_from_ngl_stats(self):
        """Sequences without NGL positions don't contribute to NGL stats."""
        logps = [
            np.array([-1.0, -1.0]),  # all GL
            np.array([-2.0, -3.0]),  # one NGL
        ]
        anns = [
            self._make_annotations(2, ["H", "H"], ["GL", "GL"], [0, 0]),
            self._make_annotations(2, ["H", "H"], ["GL", "NGL"], [0, 0]),
        ]

        results = compute_stratified_ppl(logps, anns)
        # NGL: only seq 1 contributes, PPL = exp(3)
        assert results["NGL"]["n_seqs"] == 1
        assert abs(results["NGL"]["mean_ppl"] - np.exp(3.0)) < 0.01

    def test_zero_positions_returns_nan(self):
        """Category with no positions returns NaN."""
        logps = [np.array([-1.0])]
        anns = [self._make_annotations(1, ["H"], ["GL"], [0])]

        results = compute_stratified_ppl(logps, anns)
        assert results["Light_CDR3_NGL"]["n_seqs"] == 0
        assert np.isnan(results["Light_CDR3_NGL"]["mean_ppl"])


# =============================================================================
# Tests for api.py pseudo_log_likelihood return_per_position
# =============================================================================

class TestPLLPerPosition:
    @pytest.fixture
    def mock_model(self):
        """Create a minimal mock of the PRISM model for per-position PLL testing."""
        # We test the logic flow, not the actual model computation
        # This test ensures return_per_position properly accumulates values
        pass

    def test_per_position_output_is_list_of_arrays(self):
        """return_per_position=True should return list of 1-D arrays."""
        # This is a structural contract test
        # Per-position logps for 2 sequences of lengths 3 and 2
        per_pos = [
            np.array([-1.0, -2.0, -3.0]),
            np.array([-1.5, -2.5]),
        ]
        # Verify the sum matches PLL
        pll = [lp.sum() for lp in per_pos]
        assert abs(pll[0] - (-6.0)) < 1e-10
        assert abs(pll[1] - (-4.0)) < 1e-10

    def test_per_position_ppl_from_logps(self):
        """PPL computed from per-position logps matches exp(-mean(logps))."""
        logps = np.array([-1.0, -2.0, -3.0])
        ppl = np.exp(-logps.mean())
        assert abs(ppl - np.exp(2.0)) < 0.01


# =============================================================================
# Tests for save_stratified_ppl
# =============================================================================

save_stratified_ppl = _mod.save_stratified_ppl


class TestSaveStratifiedPPL:
    def test_saves_csv_with_all_categories(self, tmp_path):
        """Summary CSV contains all 27 categories and correct columns."""
        stratified = {
            "Total": {"mean_ppl": 5.0, "median_ppl": 4.5, "std_ppl": 1.0, "n_seqs": 100, "n_tokens": 5000},
            "GL": {"mean_ppl": 3.0, "median_ppl": 2.8, "std_ppl": 0.5, "n_seqs": 100, "n_tokens": 4500},
            "NGL": {"mean_ppl": 10.0, "median_ppl": 9.0, "std_ppl": 2.0, "n_seqs": 50, "n_tokens": 500},
        }

        out_path = tmp_path / "summary.csv"
        save_stratified_ppl({"marginalized": stratified}, out_path)

        df = pd.read_csv(out_path)
        assert "group" in df.columns
        assert "category" in df.columns
        assert "marginalized_mean_ppl" in df.columns
        assert "marginalized_n_tokens" in df.columns
        # Should have all 27 categories
        assert len(df) == 27
        # Check a specific row
        total_row = df[df["category"] == "Total"].iloc[0]
        assert abs(total_row["marginalized_mean_ppl"] - 5.0) < 0.01

    def test_multiple_modes_columns(self, tmp_path):
        """Multiple modes create separate column sets."""
        strat_marg = {"Total": {"mean_ppl": 5.0, "median_ppl": 4.5, "std_ppl": 1.0, "n_seqs": 10, "n_tokens": 100}}
        strat_gl = {"Total": {"mean_ppl": 3.0, "median_ppl": 2.5, "std_ppl": 0.8, "n_seqs": 10, "n_tokens": 100}}

        out_path = tmp_path / "multi.csv"
        save_stratified_ppl({"marginalized": strat_marg, "gl": strat_gl}, out_path)

        df = pd.read_csv(out_path)
        assert "marginalized_mean_ppl" in df.columns
        assert "gl_mean_ppl" in df.columns
        total_row = df[df["category"] == "Total"].iloc[0]
        assert abs(total_row["marginalized_mean_ppl"] - 5.0) < 0.01
        assert abs(total_row["gl_mean_ppl"] - 3.0) < 0.01
