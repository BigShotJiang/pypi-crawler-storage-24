"""Tests for the unified benchmark runner script."""

import os
import sys
import subprocess
import tempfile

import pytest

SCRIPT_PATH = os.path.join(
    os.path.dirname(__file__), "..", "script", "run_all_benchmarks.py"
)

# ── helper ──────────────────────────────────────────────────────────────────
def run_script(*args):
    """Run run_all_benchmarks.py with args, return CompletedProcess."""
    return subprocess.run(
        [sys.executable, SCRIPT_PATH, *args],
        capture_output=True,
        text=True,
        timeout=30,
    )


def _import(name):
    """Import a name from run_all_benchmarks."""
    sys.path.insert(0, os.path.dirname(SCRIPT_PATH))
    mod = __import__("run_all_benchmarks")
    return getattr(mod, name)


# ── CLI validation tests ───────────────────────────────────────────────────
class TestCLIValidation:
    def test_script_exists(self):
        assert os.path.isfile(SCRIPT_PATH), f"Script not found at {SCRIPT_PATH}"

    def test_missing_checkpoint_shows_error(self):
        result = run_script()
        assert result.returncode != 0
        assert "checkpoint" in result.stderr.lower()

    def test_help_flag(self):
        result = run_script("--help")
        assert result.returncode == 0
        assert "--checkpoint" in result.stdout
        assert "--skip" in result.stdout
        assert "--output_dir" in result.stdout
        assert "--device" in result.stdout

    def test_invalid_skip_value_rejected(self):
        result = run_script("--checkpoint", "dummy.ckpt", "--skip", "invalid_bench")
        assert result.returncode != 0

    def test_skip_accepts_valid_values(self):
        result = run_script("--help")
        assert "binding" in result.stdout
        assert "developability" in result.stdout
        assert "recovery" in result.stdout

    def test_skip_no_therasabdab(self):
        """therasabdab should NOT be a valid --skip choice anymore."""
        result = run_script("--help")
        assert "therasabdab" not in result.stdout


# ── Post-processing logic tests ────────────────────────────────────────────
class TestRecoveryPostProcessing:
    """Test the inline recovery post-processing from random masking output."""

    def test_summarize_recovery_all_correct(self):
        """All predictions correct should give 100% accuracy."""
        import pandas as pd
        summarize = _import("summarize_recovery")

        df = pd.DataFrame({
            "position_type": ["GL", "GL", "NGL", "NGL"],
            "region_type": ["FR", "CDR", "FR", "CDR"],
            "is_correct_natural": [True, True, True, True],
            "is_correct_forced_gl": [True, True, True, True],
            "is_correct_forced_ngl": [True, True, True, True],
        })
        summary = summarize(df)
        assert isinstance(summary, pd.DataFrame)
        assert len(summary) > 0
        # All accuracies should be 1.0
        assert (summary["accuracy"] == 1.0).all()

    def test_summarize_recovery_none_correct(self):
        """All predictions wrong should give 0% accuracy."""
        import pandas as pd
        summarize = _import("summarize_recovery")

        df = pd.DataFrame({
            "position_type": ["GL", "NGL"],
            "region_type": ["FR", "CDR"],
            "is_correct_natural": [False, False],
            "is_correct_forced_gl": [False, False],
            "is_correct_forced_ngl": [False, False],
        })
        summary = summarize(df)
        assert (summary["accuracy"] == 0.0).all()

    def test_summarize_recovery_mixed(self):
        """50% correct should give 0.5 accuracy."""
        import pandas as pd
        summarize = _import("summarize_recovery")

        df = pd.DataFrame({
            "position_type": ["GL", "GL", "GL", "GL"],
            "region_type": ["FR", "FR", "FR", "FR"],
            "is_correct_natural": [True, True, False, False],
            "is_correct_forced_gl": [True, False, True, False],
            "is_correct_forced_ngl": [True, False, False, True],
        })
        summary = summarize(df)
        gl_natural = summary[
            (summary["position_type"] == "GL")
            & (summary["region"] == "All")
            & (summary["mode"] == "natural")
        ]
        assert len(gl_natural) == 1
        assert gl_natural.iloc[0]["accuracy"] == 0.5

    def test_summarize_recovery_has_expected_columns(self):
        """Summary should have position_type, region, mode, accuracy, n_positions."""
        import pandas as pd
        summarize = _import("summarize_recovery")

        df = pd.DataFrame({
            "position_type": ["GL"],
            "region_type": ["FR"],
            "is_correct_natural": [True],
            "is_correct_forced_gl": [True],
            "is_correct_forced_ngl": [False],
        })
        summary = summarize(df)
        for col in ["position_type", "region", "mode", "accuracy", "n_positions"]:
            assert col in summary.columns, f"Missing column: {col}"

    def test_summarize_recovery_region_breakdown(self):
        """Should produce All, FR, CDR breakdowns."""
        import pandas as pd
        summarize = _import("summarize_recovery")

        df = pd.DataFrame({
            "position_type": ["GL", "GL", "GL"],
            "region_type": ["FR", "CDR", "FR"],
            "is_correct_natural": [True, False, True],
            "is_correct_forced_gl": [True, False, True],
            "is_correct_forced_ngl": [False, False, False],
        })
        summary = summarize(df)
        regions = set(summary["region"].unique())
        assert "All" in regions
        assert "FR" in regions
        assert "CDR" in regions


class TestOutputDirectory:
    """Test output directory logic."""

    def test_default_output_dir_from_experiment_name(self):
        get_default_output_dir = _import("get_default_output_dir")
        result = get_default_output_dir("my_experiment_v34")
        assert "my_experiment_v34" in result
        assert "benchmarks" in result

    def test_default_output_dir_fallback(self):
        get_default_output_dir = _import("get_default_output_dir")
        result = get_default_output_dir(None)
        assert "benchmarks" in result
        assert "unknown" in result


class TestParseBindingResults:
    """Test binding result parsing handles actual CSV format."""

    def test_parse_without_logit_type_column(self):
        """Sweep CSV has no logit_type column — should still parse spearman."""
        import pandas as pd
        parse = _import("_parse_binding_results")

        # Create a CSV matching the actual benchmark output format
        df = pd.DataFrame({
            "lambda": [0.0, 1.0, 5.0, 10.0],
            "T": [1.0, 1.0, 1.0, 1.0],
            "spearman_rho": [-0.20, -0.10, 0.31, 0.33],
            "spearman_p": [0.0, 0.0, 0.0, 0.0],
            "pearson_r": [-0.15, -0.08, 0.23, 0.24],
            "pearson_p": [0.0, 0.0, 0.0, 0.0],
            "n_valid": [65093, 65093, 65093, 65093],
        })
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as f:
            df.to_csv(f, index=False)
            csv_path = f.name

        try:
            result = parse(csv_path, "")
            # Should find best |spearman_rho| = 0.33 at lambda=10
            assert "best_r_default" in result, f"Missing best_r_default, got {result}"
            assert abs(result["best_r_default"] - 0.33) < 0.01
            assert abs(result["best_lambda_default"] - 10.0) < 0.01
        finally:
            os.unlink(csv_path)

    def test_parse_with_logit_type_column(self):
        """Sweep CSV with logit_type column should parse per-type results."""
        import pandas as pd
        parse = _import("_parse_binding_results")

        df = pd.DataFrame({
            "logit_type": ["gl", "gl", "ngl", "ngl"],
            "lambda": [0.0, 1.0, 0.0, 1.0],
            "T": [1.0, 1.0, 1.0, 1.0],
            "spearman_rho": [0.10, 0.30, 0.15, 0.25],
            "spearman_p": [0.01, 0.01, 0.01, 0.01],
            "pearson_r": [0.1, 0.3, 0.15, 0.25],
            "pearson_p": [0.01, 0.01, 0.01, 0.01],
            "n_valid": [100, 100, 100, 100],
        })
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as f:
            df.to_csv(f, index=False)
            csv_path = f.name

        try:
            result = parse(csv_path, "")
            assert "best_r_gl" in result
            assert "best_r_ngl" in result
            assert abs(result["best_r_gl"] - 0.30) < 0.01
            assert abs(result["best_r_ngl"] - 0.25) < 0.01
        finally:
            os.unlink(csv_path)

    def test_parse_nonexistent_csv(self):
        """Missing CSV file should return empty dict, not crash."""
        parse = _import("_parse_binding_results")
        result = parse("/nonexistent/path.csv", "")
        assert isinstance(result, dict)

    def test_parse_selects_highest_positive_spearman(self):
        """Best spearman should be the highest (most positive) value."""
        import pandas as pd
        parse = _import("_parse_binding_results")

        df = pd.DataFrame({
            "lambda": [0.0, 1.0],
            "T": [1.0, 1.0],
            "spearman_rho": [-0.50, 0.30],
            "spearman_p": [0.0, 0.0],
            "pearson_r": [-0.4, 0.25],
            "pearson_p": [0.0, 0.0],
            "n_valid": [100, 100],
        })
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as f:
            df.to_csv(f, index=False)
            csv_path = f.name

        try:
            result = parse(csv_path, "")
            # Highest positive r = 0.30 at lambda=1.0
            assert abs(result["best_r_default"] - 0.30) < 0.01
            assert abs(result["best_lambda_default"] - 1.0) < 0.01
        finally:
            os.unlink(csv_path)


class TestRecoverySummarizeGermlineRecovery:
    """Test that summarize_recovery handles germline_recovery columns."""

    def test_summarize_includes_germline_recovery(self):
        """When germline_recovery columns exist, summary should include them."""
        import pandas as pd
        summarize = _import("summarize_recovery")

        df = pd.DataFrame({
            "position_type": ["NGL", "NGL", "NGL", "NGL"],
            "region_type": ["FR", "FR", "CDR", "CDR"],
            "is_correct_natural": [False, True, False, False],
            "is_correct_forced_gl": [False, True, False, False],
            "is_correct_forced_ngl": [False, True, False, False],
            "germline_recovery_natural": [True, False, True, True],
            "germline_recovery_forced_gl": [True, False, True, True],
            "germline_recovery_forced_ngl": [True, False, True, True],
        })
        summary = summarize(df)

        # Should have germline_recovery rows
        gl_recovery_rows = summary[summary["mode"].str.startswith("germline_recovery_")]
        assert len(gl_recovery_rows) > 0, "Should have germline_recovery rows"

        # Check NGL All germline_recovery_natural = 0.75 (3/4)
        row = summary[
            (summary["position_type"] == "NGL")
            & (summary["region"] == "All")
            & (summary["mode"] == "germline_recovery_natural")
        ]
        assert len(row) == 1
        assert abs(row.iloc[0]["accuracy"] - 0.75) < 0.01

    def test_summarize_without_germline_recovery_columns(self):
        """Backward compatible: works without germline_recovery columns."""
        import pandas as pd
        summarize = _import("summarize_recovery")

        df = pd.DataFrame({
            "position_type": ["GL", "NGL"],
            "region_type": ["FR", "CDR"],
            "is_correct_natural": [True, False],
            "is_correct_forced_gl": [True, False],
            "is_correct_forced_ngl": [True, False],
        })
        summary = summarize(df)
        assert len(summary) > 0
        # No germline_recovery rows
        gl_recovery_rows = summary[summary["mode"].str.startswith("germline_recovery_")]
        assert len(gl_recovery_rows) == 0


class TestFilterByRegion:
    """Test region filtering helpers."""

    def test_filter_cdr_positions(self):
        get_region_type = _import("get_region_type")
        assert get_region_type("1") == "CDR"
        assert get_region_type("3") == "CDR"
        assert get_region_type("5") == "CDR"

    def test_filter_fr_positions(self):
        get_region_type = _import("get_region_type")
        assert get_region_type("0") == "FR"
        assert get_region_type("2") == "FR"
        assert get_region_type("4") == "FR"
        assert get_region_type("6") == "FR"

    def test_filter_unknown_region(self):
        get_region_type = _import("get_region_type")
        assert get_region_type(None) is None
        assert get_region_type("") is None
