"""Tests for v37 SHM-Based Sample Weighting.

Tests that:
1. New params (use_shm_weighting, shm_beta, shm_mean_ngl) are accepted
2. SHM weight calculation is correct
3. Training step logs SHM_Weight and Mean_NGL_Count
4. Edge cases: zero NGL, all NGL positions
"""

import inspect
import numpy as np
import pytest
import torch


# ---------------------------------------------------------------------------
# Test 1: Parameter acceptance
# ---------------------------------------------------------------------------

class TestSHMParams:
    """Test that SFT_ESM2 accepts all v37 SHM weighting params."""

    def test_use_shm_weighting_param(self):
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'use_shm_weighting' in sig.parameters
        assert sig.parameters['use_shm_weighting'].default == False

    def test_shm_beta_param(self):
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'shm_beta' in sig.parameters
        assert sig.parameters['shm_beta'].default == 1.0

    def test_shm_mean_ngl_param(self):
        from prism.model import SFT_ESM2
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'shm_mean_ngl' in sig.parameters
        assert sig.parameters['shm_mean_ngl'].default == 15.0


# ---------------------------------------------------------------------------
# Test 2: Weight calculation
# ---------------------------------------------------------------------------

class TestSHMWeightCalculation:
    """Test the SHM weight formula: 1.0 + shm_beta * (mean_ngl / shm_mean_ngl)."""

    def test_zero_ngl_gives_weight_one(self):
        """If mean_ngl=0, weight should be 1.0 (baseline)."""
        shm_beta = 1.0
        shm_mean_ngl = 15.0
        mean_ngl = 0.0
        weight = 1.0 + shm_beta * (mean_ngl / shm_mean_ngl)
        assert weight == 1.0

    def test_average_ngl_gives_weight_two(self):
        """If mean_ngl equals shm_mean_ngl, weight should be 2.0."""
        shm_beta = 1.0
        shm_mean_ngl = 15.0
        mean_ngl = 15.0
        weight = 1.0 + shm_beta * (mean_ngl / shm_mean_ngl)
        assert weight == 2.0

    def test_double_ngl_gives_weight_three(self):
        """If mean_ngl is 2x shm_mean_ngl, weight should be 3.0."""
        shm_beta = 1.0
        shm_mean_ngl = 15.0
        mean_ngl = 30.0
        weight = 1.0 + shm_beta * (mean_ngl / shm_mean_ngl)
        assert weight == 3.0

    def test_beta_scaling(self):
        """shm_beta controls the strength of the upweighting."""
        shm_mean_ngl = 15.0
        mean_ngl = 15.0

        weight_beta0 = 1.0 + 0.0 * (mean_ngl / shm_mean_ngl)
        weight_beta05 = 1.0 + 0.5 * (mean_ngl / shm_mean_ngl)
        weight_beta1 = 1.0 + 1.0 * (mean_ngl / shm_mean_ngl)

        assert weight_beta0 == 1.0
        assert weight_beta05 == 1.5
        assert weight_beta1 == 2.0


# ---------------------------------------------------------------------------
# Test 3: Training step integration
# ---------------------------------------------------------------------------

class TestSHMInTrainingStep:
    """Test SHM weighting integration in _training_step_multihead."""

    def test_training_step_references_shm_weighting(self):
        """_training_step_multihead should reference use_shm_weighting."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        assert 'shm_weighting' in source or 'shm_weight' in source, \
            "_training_step_multihead should use SHM weighting"

    def test_training_step_logs_shm_weight(self):
        """_training_step_multihead should log train/SHM_Weight."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        assert 'SHM_Weight' in source, \
            "_training_step_multihead should log SHM_Weight"

    def test_training_step_logs_mean_ngl_count(self):
        """_training_step_multihead should log train/Mean_NGL_Count."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        assert 'Mean_NGL_Count' in source, \
            "_training_step_multihead should log Mean_NGL_Count"


# ---------------------------------------------------------------------------
# Test 4: Validation metrics
# ---------------------------------------------------------------------------

class TestSHMValidationMetrics:
    """Test validation step logs mean NGL count."""

    def test_validation_logs_mean_ngl_count(self):
        """_validation_step_multihead should log val/Mean_NGL_Count."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._validation_step_multihead)
        assert 'Mean_NGL_Count' in source, \
            "_validation_step_multihead should log Mean_NGL_Count"
