#!/usr/bin/env python
# coding: utf-8
"""
Tests for v40: 2-class origin + SynNGL auxiliary signals.

Tests are grouped into:
  - 6-rate masking (Approach A) — collate function produces correct probabilities
  - Origin label smoothing with MPNN prob (Approach B) — soft labels in collate
  - SynNGL-aware divergence loss (Approach C) — model._compute_divergence_loss with synth
  - MPNN-weighted GL head loss (Approach D) — position_weights in _focal_loss
  - Backward compatibility — all new params default to off
"""

import numpy as np
import pandas as pd
import pytest
import torch
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_model(use_dual_aa_heads=True, **kwargs):
    """Instantiate a minimal SFT_ESM2 model for testing."""
    from prism.model import SFT_ESM2

    defaults = dict(
        seed=42,
        model_identifier="esm2_t6_8M_UR50D",
        peak_learning_rate=1e-4,
        adam_beta1=0.9,
        adam_beta2=0.999,
        adam_epsilon=1e-8,
        WD=0.01,
        warmup_steps=10,
        max_steps=100,
        logging_steps=10,
        eval_steps=10,
        batch_size=2,
        mask_prob=0.15,
        num_unfrozen_transformer_blocks=2,
        loss_type="focal_loss",
        random_weights=True,
        add_custom_tokens=True,
        custom_token_strategy="lowercase_ngl",
        activation_function="gelu",
        use_multihead_architecture=True,
        use_alpha_gating=True,
        detach_origin_gradient=True,
        tie_word_embeddings=False,
        use_dual_aa_heads=use_dual_aa_heads,
        num_origin_classes=2,  # v40: back to 2-class
    )
    defaults.update(kwargs)
    return SFT_ESM2(**defaults)


def _make_tokenizer():
    """Create a tokenizer with custom lowercase tokens added."""
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained("facebook/esm2_t6_8M_UR50D")
    lowercase_aa = list("acdefghiklmnpqrstvwy")
    tokenizer.add_tokens(lowercase_aa)
    return tokenizer


def _make_test_df(n=4, include_synth=True, include_mpnn_prob=False):
    """Create a test DataFrame with optional synth and MPNN prob columns."""
    heavy_seqs = ["EVQLVESGGGLVQPGG"] * n
    light_seqs = ["DIQMTQSPSSLSA"] * n
    hc_muts = ["A5G;T10S"] * n  # positions 5 and 10 are NGL
    lc_muts = ["S3T"] * n

    df = pd.DataFrame({
        "HEAVY_CHAIN_AA_SEQUENCE": heavy_seqs,
        "LIGHT_CHAIN_AA_SEQUENCE": light_seqs,
        "hc_mut_codes": hc_muts,
        "lc_mut_codes": lc_muts,
        "region_mask_heavy": ["0000011111222220"] * n,  # FR1(0-4), CDR1(5-9), FR2(10-14), CDR3(15)
        "region_mask_light": ["0000011112222"] * n,
    })

    if include_synth:
        # SynNGL at positions 2, 7, 12 for heavy; 1, 6 for light
        df["synthetic_ngl_heavy"] = ["0010000100010000"] * n
        df["synthetic_ngl_light"] = ["0100001000000"] * n

    if include_mpnn_prob:
        # MPNN germline probabilities (high=GL-confident, low=GL-unlikely)
        # Positions matching synth_ngl should have low values
        import pickle
        heavy_probs = np.array([0.95, 0.90, 0.05, 0.85, 0.80,   # pos 2 = low (SynNGL)
                                0.70, 0.60, 0.10, 0.55, 0.50,   # pos 7 = low (SynNGL)
                                0.45, 0.40, 0.08, 0.35, 0.30,   # pos 12 = low (SynNGL)
                                0.25], dtype=np.float32)
        light_probs = np.array([0.90, 0.05, 0.85, 0.80, 0.75,   # pos 1 = low (SynNGL)
                                0.70, 0.10, 0.60, 0.55, 0.50,   # pos 6 = low (SynNGL)
                                0.45, 0.40, 0.35], dtype=np.float32)
        df["mpnn_gl_prob_heavy"] = [pickle.dumps(heavy_probs)] * n
        df["mpnn_gl_prob_light"] = [pickle.dumps(light_probs)] * n

    return df


# ===========================================================================
# GROUP 1: 6-Rate Masking (Approach A)
# ===========================================================================

class TestSixRateMasking:
    """Tests for 6-rate masking that differentiates GL/SynNGL/NGL × CDR/FR."""

    def test_six_rate_masking_produces_correct_rates(self):
        """With synth masking, 6 different masking probabilities should be used."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=200, include_synth=True)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_region_masking=True,
            ngl_targeted_masking=True,
            cdr_mask_prob=0.35,
            fr_mask_prob=0.15,
            cdr_ngl_mask_prob=0.50,
            fr_ngl_mask_prob=0.40,
            use_synth_masking=True,
            cdr_synth_mask_prob=0.45,
            fr_synth_mask_prob=0.30,
            silent=True,
        )

        batch = [dataset[i] for i in range(200)]
        result = collate_fn(batch)
        # result should contain synth_masks in batch dict
        # At minimum: input_ids, labels_aa, labels_mut, attn_mask, ngl_masks, region_ids
        assert len(result) >= 6, f"Expected at least 6 items in batch, got {len(result)}"

    def test_synth_mask_returned_in_batch(self):
        """When use_synth_masking=True, synth_masks should be in the batch output."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=True)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        # The batch should include synth_masks tensor
        # We expect it appended after the standard outputs
        # Standard: input_ids, labels_aa, labels_mut, attn_mask, ngl_masks, region_ids
        # New: synth_masks
        assert len(result) >= 7, f"Expected synth_masks in output, got {len(result)} items"
        synth_masks = result[6]  # After region_ids
        assert synth_masks.shape[0] == 4, "Batch dimension mismatch"
        assert synth_masks.dtype == torch.bool or synth_masks.dtype == torch.int64

    def test_synth_only_positions_identified_correctly(self):
        """SynNGL-only positions = synth_mask & ~ngl_mask."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=True)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        ngl_masks = result[4]
        synth_masks = result[6]

        # SynNGL positions should NOT overlap with NGL positions
        # (NGL = actual mutations, SynNGL = structural without mutation)
        synth_only = synth_masks.bool() & ~ngl_masks.bool()
        # There should be some synth-only positions
        assert synth_only.any(), "Expected some SynNGL-only positions"

    def test_backward_compat_no_synth_masking(self):
        """Without use_synth_masking, output format should be unchanged."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=False)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        # Standard format: input_ids, labels_aa, labels_mut, attn_mask, ngl_masks, region_ids
        assert len(result) == 6, f"Expected 6 items without synth masking, got {len(result)}"


# ===========================================================================
# GROUP 2: Origin Label Smoothing with MPNN Prob (Approach B)
# ===========================================================================

class TestOriginLabelSmoothing:
    """Tests for MPNN-based soft origin labels."""

    def test_mpnn_smoothed_labels_range(self):
        """SynNGL positions should have origin labels between 0 and 1 (not hard 0 or 1)."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=True, include_mpnn_prob=True)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=1.0,  # Mask everything so all labels are active
            use_region_embedding=True,
            use_synth_masking=True,
            use_mpnn_origin_smoothing=True,
            origin_label_smooth_factor=0.2,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        labels_mut = result[2]  # labels_mut
        synth_masks = result[6]  # synth_masks

        # At masked SynNGL positions (synth_mask=True, ngl_mask=False),
        # labels_mut should be between 0 and 1 (soft label)
        ngl_masks = result[4]
        synth_only = synth_masks.bool() & ~ngl_masks.bool()
        active = (labels_mut != -1.0) & synth_only

        if active.any():
            smooth_values = labels_mut[active]
            assert (smooth_values > 0.0).any(), "Expected some smooth labels > 0"
            assert (smooth_values < 1.0).all(), "SynNGL smooth labels should be < 1.0"

    def test_ngl_positions_stay_hard_1(self):
        """Real NGL positions should remain 1.0 (not smoothed)."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=True, include_mpnn_prob=True)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=1.0,
            use_region_embedding=True,
            use_synth_masking=True,
            use_mpnn_origin_smoothing=True,
            origin_label_smooth_factor=0.2,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        labels_mut = result[2]
        ngl_masks = result[4]

        # At masked NGL positions, labels_mut should be 1.0
        active_ngl = (labels_mut != -1.0) & ngl_masks.bool()
        if active_ngl.any():
            assert (labels_mut[active_ngl] == 1.0).all(), "NGL positions should stay at 1.0"

    def test_gl_positions_stay_hard_0(self):
        """Pure GL positions (not SynNGL) should remain 0.0."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=True, include_mpnn_prob=True)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=1.0,
            use_region_embedding=True,
            use_synth_masking=True,
            use_mpnn_origin_smoothing=True,
            origin_label_smooth_factor=0.2,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        labels_mut = result[2]
        ngl_masks = result[4]
        synth_masks = result[6]

        # Pure GL = not NGL and not SynNGL
        pure_gl = ~ngl_masks.bool() & ~synth_masks.bool()
        active_gl = (labels_mut != -1.0) & pure_gl
        if active_gl.any():
            assert (labels_mut[active_gl] == 0.0).all(), "Pure GL positions should stay at 0.0"

    def test_no_smoothing_by_default(self):
        """Without use_mpnn_origin_smoothing, labels_mut should be 0.0 or 1.0."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=True, include_mpnn_prob=True)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=1.0,
            use_region_embedding=True,
            use_synth_masking=True,
            # use_mpnn_origin_smoothing defaults to False
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        labels_mut = result[2]
        active = (labels_mut != -1.0)
        if active.any():
            unique_vals = labels_mut[active].unique()
            for v in unique_vals:
                assert v.item() in (0.0, 1.0), f"Unexpected label value {v.item()} without smoothing"


# ===========================================================================
# GROUP 3: SynNGL-Aware Divergence Loss (Approach C)
# ===========================================================================

class TestSynthDivergenceLoss:
    """Tests for SynNGL-aware divergence that adds divergence signal at SynNGL positions."""

    def test_synth_divergence_basic(self):
        """With synth_masks, divergence should also be computed at SynNGL positions."""
        from prism.model import SFT_ESM2

        B, L, V = 2, 20, 33
        logits_gl = torch.randn(B, L, V)
        logits_ngl = torch.randn(B, L, V) + 2.0  # Different distribution

        ngl_masks = torch.zeros(B, L, dtype=torch.long)
        ngl_masks[:, 5:8] = 1  # Some NGL positions

        synth_masks = torch.zeros(B, L, dtype=torch.long)
        synth_masks[:, 10:13] = 1  # Some SynNGL positions (no overlap with NGL)

        labels_aa = torch.full((B, L), -100)
        labels_aa[:, 3:15] = torch.randint(4, 24, (B, 12))  # Some masked positions

        loss = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            synth_masks=synth_masks,
            synth_div_weight=0.3,
            divergence_type="js",
        )

        assert loss.item() < 0, "Divergence loss should be negative (maximizing divergence)"

    def test_synth_divergence_increases_loss_magnitude(self):
        """Adding SynNGL positions should increase the total divergence signal."""
        from prism.model import SFT_ESM2

        B, L, V = 2, 20, 33
        logits_gl = torch.randn(B, L, V)
        logits_ngl = torch.randn(B, L, V) + 2.0

        ngl_masks = torch.zeros(B, L, dtype=torch.long)
        ngl_masks[:, 5:8] = 1

        labels_aa = torch.full((B, L), -100)
        labels_aa[:, 3:15] = torch.randint(4, 24, (B, 12))

        # Without synth
        loss_no_synth = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            divergence_type="js",
        )

        # With synth (additional positions contribute to divergence)
        synth_masks = torch.zeros(B, L, dtype=torch.long)
        synth_masks[:, 10:13] = 1

        loss_with_synth = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            synth_masks=synth_masks,
            synth_div_weight=0.3,
            divergence_type="js",
        )

        # Both should be negative, and with synth should have non-zero contribution
        assert loss_no_synth.item() < 0
        assert loss_with_synth.item() < 0

    def test_synth_divergence_zero_weight_equals_no_synth(self):
        """With synth_div_weight=0, result should equal no synth."""
        from prism.model import SFT_ESM2

        B, L, V = 2, 20, 33
        torch.manual_seed(42)
        logits_gl = torch.randn(B, L, V)
        logits_ngl = torch.randn(B, L, V) + 2.0

        ngl_masks = torch.zeros(B, L, dtype=torch.long)
        ngl_masks[:, 5:8] = 1

        labels_aa = torch.full((B, L), -100)
        labels_aa[:, 3:15] = torch.randint(4, 24, (B, 12))

        synth_masks = torch.zeros(B, L, dtype=torch.long)
        synth_masks[:, 10:13] = 1

        loss_no_synth = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            divergence_type="js",
        )

        loss_zero_weight = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            synth_masks=synth_masks,
            synth_div_weight=0.0,
            divergence_type="js",
        )

        assert abs(loss_no_synth.item() - loss_zero_weight.item()) < 1e-5

    def test_synth_divergence_backward_compat(self):
        """Without synth_masks arg, should work exactly as before."""
        from prism.model import SFT_ESM2

        B, L, V = 2, 20, 33
        logits_gl = torch.randn(B, L, V)
        logits_ngl = torch.randn(B, L, V) + 2.0

        ngl_masks = torch.zeros(B, L, dtype=torch.long)
        ngl_masks[:, 5:8] = 1

        labels_aa = torch.full((B, L), -100)
        labels_aa[:, 3:15] = torch.randint(4, 24, (B, 12))

        # Should not raise any error
        loss = SFT_ESM2._compute_divergence_loss(
            logits_gl, logits_ngl, ngl_masks, labels_aa,
            divergence_type="js",
        )
        assert isinstance(loss, torch.Tensor)


# ===========================================================================
# GROUP 4: MPNN-Weighted GL Head Loss (Approach D)
# ===========================================================================

class TestMPNNWeightedLoss:
    """Tests for position-weighted focal loss on GL head."""

    def test_position_weights_reduce_total_loss_contribution(self):
        """Low-weight positions should contribute less to the total weighted loss sum."""
        model = _make_model()

        B, L, V = 2, 20, 33
        torch.manual_seed(42)
        logits = torch.randn(B, L, V)
        targets = torch.randint(4, 24, (B, L))

        # All weight=1.0 except position 0 which has weight=0
        position_weights_zero = torch.ones(B, L)
        position_weights_zero[:, 0] = 0.0

        position_weights_full = torch.ones(B, L)

        loss_zero_at_0 = model._focal_loss(
            logits, targets, gamma=2.0, ignore_index=-100,
            position_weights=position_weights_zero,
        )
        loss_full = model._focal_loss(
            logits, targets, gamma=2.0, ignore_index=-100,
            position_weights=position_weights_full,
        )

        # Zeroing out one position's weight should change the loss
        assert abs(loss_zero_at_0.item() - loss_full.item()) > 1e-6, \
            "Position weights should affect loss computation"

    def test_position_weights_ones_equals_no_weights(self):
        """Position weights of all 1.0 should equal no weights."""
        model = _make_model()

        B, L, V = 2, 20, 33
        torch.manual_seed(42)
        logits = torch.randn(B, L, V)
        targets = torch.randint(4, 24, (B, L))

        loss_no_weights = model._focal_loss(
            logits, targets, gamma=2.0, ignore_index=-100
        )

        position_weights = torch.ones(B, L)
        loss_with_ones = model._focal_loss(
            logits, targets, gamma=2.0, ignore_index=-100,
            position_weights=position_weights,
        )

        assert abs(loss_no_weights.item() - loss_with_ones.item()) < 1e-5

    def test_position_weights_zero_eliminates_loss(self):
        """Position weights of all 0.0 should give zero loss."""
        model = _make_model()

        B, L, V = 2, 20, 33
        logits = torch.randn(B, L, V)
        targets = torch.randint(4, 24, (B, L))

        position_weights = torch.zeros(B, L)
        loss = model._focal_loss(
            logits, targets, gamma=2.0, ignore_index=-100,
            position_weights=position_weights,
        )

        assert loss.item() < 1e-7, f"Expected near-zero loss, got {loss.item()}"


# ===========================================================================
# GROUP 5: Backward Compatibility
# ===========================================================================

class TestBackwardCompatibility:
    """Verify all new features default to off and don't break existing behavior."""

    def test_model_init_defaults(self):
        """Model should initialize with all v40 params at their defaults."""
        model = _make_model()

        # New v40 params should have safe defaults
        assert model.use_synth_divergence is False or not hasattr(model, 'use_synth_divergence') or model.synth_div_weight == 0.0
        assert model.use_mpnn_gl_weighting is False or not hasattr(model, 'use_mpnn_gl_weighting')

    def test_dataset_without_synth_masking(self):
        """SeqSeqDataset with use_synth_masking=False should work as before."""
        from prism.io_utils import SeqSeqDataset

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=False)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
        )

        item = dataset[0]
        # Standard format: (token_ids, ngl_mask, region_ids)
        assert len(item) == 3

    def test_collate_without_synth_masking(self):
        """Collate function without synth masking should return standard format."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=False)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        # Standard: input_ids, labels_aa, labels_mut, attn_mask, ngl_masks, region_ids
        assert len(result) == 6

    def test_mpnn_gl_prob_missing_column_uses_default(self):
        """When mpnn_gl_prob columns are missing, should default to 1.0 (full GL confidence)."""
        from prism.io_utils import SeqSeqDataset, make_collate_fn_multihead

        tokenizer = _make_tokenizer()
        df = _make_test_df(n=4, include_synth=True, include_mpnn_prob=False)

        dataset = SeqSeqDataset(
            df, tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
        )

        collate_fn = make_collate_fn_multihead(
            tokenizer, mask_prob=0.15,
            use_region_embedding=True,
            use_synth_masking=True,
            use_mpnn_origin_smoothing=True,
            origin_label_smooth_factor=0.2,
            silent=True,
        )

        batch = [dataset[i] for i in range(4)]
        result = collate_fn(batch)

        # Should not crash, labels_mut should still be valid
        labels_mut = result[2]
        assert not torch.isnan(labels_mut).any()


# ===========================================================================
# GROUP 6: Model Integration (Approach C+D combined)
# ===========================================================================

class TestModelIntegration:
    """Tests verifying model accepts new params and processes them correctly."""

    def test_model_accepts_synth_divergence_params(self):
        """Model should accept use_synth_divergence and synth_div_weight params."""
        model = _make_model(
            use_synth_divergence=True,
            synth_div_weight=0.3,
            divergence_loss_weight=0.03,
        )
        assert model.use_synth_divergence is True
        assert model.synth_div_weight == 0.3

    def test_model_accepts_mpnn_gl_weighting_params(self):
        """Model should accept use_mpnn_gl_weighting and mpnn_min_weight params."""
        model = _make_model(
            use_mpnn_gl_weighting=True,
            mpnn_min_weight=0.3,
        )
        assert model.use_mpnn_gl_weighting is True
        assert model.mpnn_min_weight == 0.3
