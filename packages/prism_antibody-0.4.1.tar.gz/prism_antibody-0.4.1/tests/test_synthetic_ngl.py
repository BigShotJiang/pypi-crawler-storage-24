"""Tests for the ProteinMPNN synthetic NGL label generation pipeline (scripts 9-12)."""

import importlib.util
import numpy as np
import pandas as pd
import pytest
import os

SCRIPT_DIR = os.path.join(os.path.dirname(__file__), "..", "script", "data")


def _import_script(filename, module_name):
    """Import a script with dots in its filename as a Python module."""
    spec = importlib.util.spec_from_file_location(module_name, os.path.join(SCRIPT_DIR, filename))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


stage1 = _import_script("9.select_vgene_pair_representatives.py", "stage1")
stage3 = _import_script("11.score_structures_proteinmpnn.py", "stage3")
stage4 = _import_script("12.generate_synthetic_ngl_labels.py", "stage4")


# ═══════════════════════════════════════════════════════════════════════════════
# Stage 1: Representative Selection
# ═══════════════════════════════════════════════════════════════════════════════


def _make_paired_df(rows):
    """Helper: build a minimal paired DataFrame for testing Stage 1."""
    return pd.DataFrame(rows)


class TestRepresentativeSelection:
    def test_picks_highest_ngl(self):
        """Representative should be the sequence with the most NGL mutations."""
        df = _make_paired_df(
            [
                {
                    "v_gene_heavy": "IGHV1-2",
                    "v_gene_light": "IGKV1-5",
                    "total_num_ngl_muts": 3,
                    "HEAVY_CHAIN_AA_SEQUENCE": "EVQLV",
                    "LIGHT_CHAIN_AA_SEQUENCE": "DIQMT",
                    "HEAVY_CHAIN_AA_GERMLINE_ALIGNMENT": "EVQLV",
                    "LIGHT_CHAIN_AA_GERMLINE_ALIGNMENT": "DIQMT",
                    "hc_mut_codes": "E1A;V2L;Q3R",
                    "lc_mut_codes": "",
                    "region_mask_heavy": "00000",
                    "region_mask_light": "00000",
                },
                {
                    "v_gene_heavy": "IGHV1-2",
                    "v_gene_light": "IGKV1-5",
                    "total_num_ngl_muts": 7,
                    "HEAVY_CHAIN_AA_SEQUENCE": "QVQLQ",
                    "LIGHT_CHAIN_AA_SEQUENCE": "EIVLT",
                    "HEAVY_CHAIN_AA_GERMLINE_ALIGNMENT": "QVQLQ",
                    "LIGHT_CHAIN_AA_GERMLINE_ALIGNMENT": "EIVLT",
                    "hc_mut_codes": "Q1E;V2A;Q3L;L4V;Q5E",
                    "lc_mut_codes": "E1D;I2V",
                    "region_mask_heavy": "00000",
                    "region_mask_light": "00000",
                },
            ]
        )
        reps = stage1.select_representatives(df, min_group_size=1)
        assert len(reps) == 1
        assert reps.iloc[0]["heavy_seq"] == "QVQLQ"

    def test_single_sequence_group(self):
        """A group with exactly 1 sequence should still produce a representative."""
        df = _make_paired_df(
            [
                {
                    "v_gene_heavy": "IGHV3-30",
                    "v_gene_light": "IGLV1-44",
                    "total_num_ngl_muts": 1,
                    "HEAVY_CHAIN_AA_SEQUENCE": "EVQLV",
                    "LIGHT_CHAIN_AA_SEQUENCE": "SYELT",
                    "HEAVY_CHAIN_AA_GERMLINE_ALIGNMENT": "EVQLV",
                    "LIGHT_CHAIN_AA_GERMLINE_ALIGNMENT": "SYELT",
                    "hc_mut_codes": "E1D",
                    "lc_mut_codes": "",
                    "region_mask_heavy": "00000",
                    "region_mask_light": "00000",
                },
            ]
        )
        reps = stage1.select_representatives(df, min_group_size=1)
        assert len(reps) == 1
        assert reps.iloc[0]["num_seqs_in_group"] == 1

    def test_min_group_size_filter(self):
        """Groups below min_group_size should be excluded."""
        df = _make_paired_df(
            [
                {
                    "v_gene_heavy": "IGHV1-2",
                    "v_gene_light": "IGKV1-5",
                    "total_num_ngl_muts": 3,
                    "HEAVY_CHAIN_AA_SEQUENCE": "EVQLV",
                    "LIGHT_CHAIN_AA_SEQUENCE": "DIQMT",
                    "HEAVY_CHAIN_AA_GERMLINE_ALIGNMENT": "EVQLV",
                    "LIGHT_CHAIN_AA_GERMLINE_ALIGNMENT": "DIQMT",
                    "hc_mut_codes": "E1A;V2L;Q3R",
                    "lc_mut_codes": "",
                    "region_mask_heavy": "00000",
                    "region_mask_light": "00000",
                },
            ]
        )
        reps = stage1.select_representatives(df, min_group_size=5)
        assert len(reps) == 0


# ═══════════════════════════════════════════════════════════════════════════════
# Germline Reconstruction
# ═══════════════════════════════════════════════════════════════════════════════


class TestGermlineReconstruction:
    def test_x_positions_use_actual_aa(self):
        """X in germline alignment should be replaced by the actual AA from the sequence."""
        seq = "EVQLV"
        gl_aln = "XVQXV"
        result = stage1.reconstruct_germline(seq, gl_aln)
        assert result == "EVQLV"

    def test_normal_positions_use_germline(self):
        """Non-X positions should keep the germline AA even if the mature AA differs."""
        seq = "AVQLV"  # A at pos 0 differs from germline E
        gl_aln = "EVQLV"
        result = stage1.reconstruct_germline(seq, gl_aln)
        assert result == "EVQLV"

    def test_mixed_x_and_mutations(self):
        """Combined X replacements and germline retention."""
        seq = "ARQLV"
        gl_aln = "XVXLV"  # X at pos 0 and 2
        result = stage1.reconstruct_germline(seq, gl_aln)
        # pos 0: X → A (from seq), pos 1: V (GL), pos 2: X → Q (from seq),
        # pos 3: L (GL), pos 4: V (GL)
        assert result == "AVQLV"


# ═══════════════════════════════════════════════════════════════════════════════
# Stage 3: MPNN Alphabet Mapping
# ═══════════════════════════════════════════════════════════════════════════════


class TestMPNNAlphabet:
    def test_mpnn_to_prism_alphabet_mapping(self):
        """MPNN 21-char alphabet (with X) → PRISM 20-char alphabet (drop X)."""
        # MPNN: ACDEFGHIKLMNPQRSTVWYX (21 AAs)
        # PRISM: ACDEFGHIKLMNPQRSTVWY (20 AAs) — just drop index 20
        mpnn_log_probs = np.zeros((5, 21))
        # Set distinct values to track columns
        for i in range(21):
            mpnn_log_probs[:, i] = -(i + 1)

        prism_log_probs = stage3.mpnn_to_prism_alphabet(mpnn_log_probs)
        assert prism_log_probs.shape == (5, 20)
        # X column (index 20) should be gone
        # The first 20 columns should be preserved
        np.testing.assert_array_equal(prism_log_probs, mpnn_log_probs[:, :20])


# ═══════════════════════════════════════════════════════════════════════════════
# Stage 4: Synthetic NGL Labels
# ═══════════════════════════════════════════════════════════════════════════════


class TestSyntheticNGLLabels:
    def test_threshold_zero_no_synthetic_ngl(self):
        """With threshold=0, no position should be marked as synthetic NGL
        (prob_of_gl can't be < 0)."""
        log_probs = np.log(np.full((5, 20), 0.05))  # uniform
        gl_seq = "ACDEF"
        aa_order = "ACDEFGHIKLMNPQRSTVWY"
        mask = stage4.compute_synthetic_ngl_mask(log_probs, gl_seq, aa_order, threshold=0.0)
        assert mask == "00000"

    def test_threshold_one_all_synthetic_ngl(self):
        """With threshold=1.0, every position should be marked as synthetic NGL
        (prob < 1.0 for any non-degenerate distribution)."""
        log_probs = np.log(np.full((5, 20), 0.05))  # uniform → each p=0.05 < 1.0
        gl_seq = "ACDEF"
        aa_order = "ACDEFGHIKLMNPQRSTVWY"
        mask = stage4.compute_synthetic_ngl_mask(log_probs, gl_seq, aa_order, threshold=1.0)
        assert mask == "11111"

    def test_specific_threshold(self):
        """Positions with GL AA prob below threshold → synthetic NGL."""
        aa_order = "ACDEFGHIKLMNPQRSTVWY"
        log_probs = np.log(np.full((3, 20), 0.05))  # uniform → p=0.05 each
        # Make position 1 strongly favor its GL AA (D at index 2 in ACDEFG...)
        log_probs[1, :] = np.log(0.001)
        log_probs[1, 2] = np.log(0.98)  # D has high prob → NOT synthetic NGL
        gl_seq = "ADK"
        mask = stage4.compute_synthetic_ngl_mask(log_probs, gl_seq, aa_order, threshold=0.1)
        # pos 0: A (idx 0), prob=0.05 < 0.1 → "1"
        # pos 1: D (idx 2), prob=0.98 >= 0.1 → "0"
        # pos 2: K (idx 8), prob=0.05 < 0.1 → "1"
        assert mask == "101"

    def test_alignment_same_length(self):
        """When representative and target have same region lengths, direct position mapping."""
        rep_probs = np.random.randn(10, 20)
        rep_regions = "0000111222"  # FR1(4), CDR1(3), FR2(3)
        tgt_regions = "0000111222"  # same lengths
        aligned = stage4.align_mpnn_profile(rep_probs, rep_regions, tgt_regions)
        np.testing.assert_array_equal(aligned, rep_probs)

    def test_alignment_different_cdr3_length(self):
        """CDR3 length mismatch should use nearest-neighbor interpolation."""
        # Representative: 4 FR1 + 3 CDR3(5) + 2 FR4(6)
        rep_probs = np.arange(9 * 20, dtype=np.float32).reshape(9, 20)
        rep_regions = "000055566"
        # Target: 4 FR1 + 5 CDR3(5) + 2 FR4(6)
        tgt_regions = "00005555566"
        aligned = stage4.align_mpnn_profile(rep_probs, rep_regions, tgt_regions)
        assert aligned.shape == (11, 20)
        # FR1 and FR4 regions should be directly mapped
        np.testing.assert_array_equal(aligned[:4], rep_probs[:4])  # FR1
        np.testing.assert_array_equal(aligned[-2:], rep_probs[-2:])  # FR4

    def test_missing_vgene_pair_returns_none(self):
        """When no MPNN profile exists for a V-gene pair, return None."""
        profiles = {}  # empty profile dict
        result = stage4.lookup_profile(profiles, "IGHV1-2_IGKV1-5")
        assert result is None
