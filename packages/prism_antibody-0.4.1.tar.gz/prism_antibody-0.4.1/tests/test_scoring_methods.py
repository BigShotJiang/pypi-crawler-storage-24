#!/usr/bin/env python
"""Tests for comprehensive scoring methods benchmark.

Tests cover:
1. PositionScoreData dataclass stores all required fields
2. All 18 scoring method formulas produce correct results on known values
3. Logsumexp marginalization matches torch.logsumexp
4. Origin-adaptive correctly switches heads based on p_ngl > 0.5
5. Alpha-weighting correctly interpolates
6. Lambda sweep correctly scales reference terms
7. Edge cases: single mutation, zero alpha, extreme logprobs
"""

import math
import sys
from pathlib import Path

import numpy as np
import pytest
import torch

# Add the script directory to path so we can import the benchmark module
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "script" / "analyze" / "3.zero-shot"))

from benchmark_scoring_methods import (
    PositionScoreData,
    compute_all_method_scores,
    compute_logsumexp,
)


# =============================================================================
# Test fixtures
# =============================================================================


@pytest.fixture
def single_position_data():
    """A single mutation position with known values for manual verification.

    Setup: WT amino acid X at position i, mutant amino acid Y.
    Two contexts: WT-masked and Mut-masked.
    """
    return PositionScoreData(
        # WT-context masked (position masked in WT sequence)
        logp_gl_wt_wtctx=-2.0,     # logP_GL(X | WT_masked)
        logp_ngl_wt_wtctx=-3.0,    # logP_NGL(X | WT_masked)
        logp_gl_mut_wtctx=-4.0,    # logP_GL(Y | WT_masked)
        logp_ngl_mut_wtctx=-1.5,   # logP_NGL(Y | WT_masked)
        logp_aa_wt_wtctx=-2.5,     # logP_AA(X | WT_masked)
        logp_aa_mut_wtctx=-3.5,    # logP_AA(Y | WT_masked)
        # Mut-context masked (position masked in Mut sequence)
        logp_gl_wt_mutctx=-2.2,    # logP_GL(X | Mut_masked)
        logp_ngl_wt_mutctx=-3.2,   # logP_NGL(X | Mut_masked)
        logp_gl_mut_mutctx=-3.8,   # logP_GL(Y | Mut_masked)
        logp_ngl_mut_mutctx=-1.2,  # logP_NGL(Y | Mut_masked)
        logp_aa_wt_mutctx=-2.3,    # logP_AA(X | Mut_masked)
        logp_aa_mut_mutctx=-3.3,   # logP_AA(Y | Mut_masked)
        # Unmasked WT pass values
        alpha=0.7,                  # learned gating value at this position
        p_ngl=0.8,                  # sigmoid(origin_logit) at this position
        # Unmasked WT pass logprobs (from full 53-vocab output)
        logp_gl_wt_unmasked=-1.8,   # logP_GL(X | WT_unmasked)
        logp_ngl_wt_unmasked=-2.8,  # logP_NGL(X | WT_unmasked)
        logp_gl_mut_unmasked=-3.5,  # logP_GL(Y | WT_unmasked)
        logp_ngl_mut_unmasked=-1.0, # logP_NGL(Y | WT_unmasked)
    )


@pytest.fixture
def multi_position_data():
    """Two mutation positions to test summing across positions."""
    pos1 = PositionScoreData(
        logp_gl_wt_wtctx=-2.0,
        logp_ngl_wt_wtctx=-3.0,
        logp_gl_mut_wtctx=-4.0,
        logp_ngl_mut_wtctx=-1.5,
        logp_aa_wt_wtctx=-2.5,
        logp_aa_mut_wtctx=-3.5,
        logp_gl_wt_mutctx=-2.2,
        logp_ngl_wt_mutctx=-3.2,
        logp_gl_mut_mutctx=-3.8,
        logp_ngl_mut_mutctx=-1.2,
        logp_aa_wt_mutctx=-2.3,
        logp_aa_mut_mutctx=-3.3,
        alpha=0.7,
        p_ngl=0.8,
        logp_gl_wt_unmasked=-1.8,
        logp_ngl_wt_unmasked=-2.8,
        logp_gl_mut_unmasked=-3.5,
        logp_ngl_mut_unmasked=-1.0,
    )
    pos2 = PositionScoreData(
        logp_gl_wt_wtctx=-1.5,
        logp_ngl_wt_wtctx=-2.5,
        logp_gl_mut_wtctx=-3.0,
        logp_ngl_mut_wtctx=-2.0,
        logp_aa_wt_wtctx=-1.8,
        logp_aa_mut_wtctx=-2.8,
        logp_gl_wt_mutctx=-1.7,
        logp_ngl_wt_mutctx=-2.7,
        logp_gl_mut_mutctx=-2.8,
        logp_ngl_mut_mutctx=-1.8,
        logp_aa_wt_mutctx=-1.9,
        logp_aa_mut_mutctx=-2.9,
        alpha=0.3,
        p_ngl=0.4,
        logp_gl_wt_unmasked=-1.3,
        logp_ngl_wt_unmasked=-2.3,
        logp_gl_mut_unmasked=-2.8,
        logp_ngl_mut_unmasked=-1.5,
    )
    return [pos1, pos2]


# =============================================================================
# Test PositionScoreData dataclass
# =============================================================================


class TestPositionScoreData:
    def test_has_all_required_fields(self, single_position_data):
        """PositionScoreData must store all 18 required fields."""
        d = single_position_data
        # WT-context masked fields
        assert hasattr(d, 'logp_gl_wt_wtctx')
        assert hasattr(d, 'logp_ngl_wt_wtctx')
        assert hasattr(d, 'logp_gl_mut_wtctx')
        assert hasattr(d, 'logp_ngl_mut_wtctx')
        assert hasattr(d, 'logp_aa_wt_wtctx')
        assert hasattr(d, 'logp_aa_mut_wtctx')
        # Mut-context masked fields
        assert hasattr(d, 'logp_gl_wt_mutctx')
        assert hasattr(d, 'logp_ngl_wt_mutctx')
        assert hasattr(d, 'logp_gl_mut_mutctx')
        assert hasattr(d, 'logp_ngl_mut_mutctx')
        assert hasattr(d, 'logp_aa_wt_mutctx')
        assert hasattr(d, 'logp_aa_mut_mutctx')
        # Unmasked WT pass
        assert hasattr(d, 'alpha')
        assert hasattr(d, 'p_ngl')
        # Unmasked logprobs
        assert hasattr(d, 'logp_gl_wt_unmasked')
        assert hasattr(d, 'logp_ngl_wt_unmasked')
        assert hasattr(d, 'logp_gl_mut_unmasked')
        assert hasattr(d, 'logp_ngl_mut_unmasked')

    def test_values_stored_correctly(self, single_position_data):
        """Values should be stored as-is."""
        d = single_position_data
        assert d.logp_gl_wt_wtctx == -2.0
        assert d.logp_ngl_mut_wtctx == -1.5
        assert d.alpha == 0.7
        assert d.p_ngl == 0.8


# =============================================================================
# Test logsumexp marginalization
# =============================================================================


class TestLogsumexp:
    def test_matches_torch_logsumexp(self):
        """Our logsumexp should match torch.logsumexp exactly."""
        a, b = -2.0, -3.0
        expected = torch.logsumexp(torch.tensor([a, b]), dim=0).item()
        result = compute_logsumexp(a, b)
        assert abs(result - expected) < 1e-6

    def test_logsumexp_dominance(self):
        """When one value is much larger, logsumexp ≈ that value."""
        result = compute_logsumexp(-1.0, -100.0)
        assert abs(result - (-1.0)) < 1e-3

    def test_logsumexp_equal_values(self):
        """logsumexp(a, a) = a + ln(2)."""
        a = -2.0
        result = compute_logsumexp(a, a)
        expected = a + math.log(2)
        assert abs(result - expected) < 1e-6

    def test_logsumexp_zero_logprobs(self):
        """logsumexp(0, 0) = ln(2)."""
        result = compute_logsumexp(0.0, 0.0)
        assert abs(result - math.log(2)) < 1e-6


# =============================================================================
# Test Category A: Unmasked WT context scoring
# =============================================================================


class TestCategoryA:
    """Category A: Unmasked WT context (fastest, 1 pass total)."""

    def test_A1_ngl_minus_gl(self, single_position_data):
        """A1: logP_NGL(Y|WT) - logP_GL(X|WT)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_ngl_mut_unmasked - d.logp_gl_wt_unmasked
        assert abs(scores['A1_ngl_minus_gl'] - expected) < 1e-6

    def test_A2_ngl_only(self, single_position_data):
        """A2: logP_NGL(Y|WT)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_ngl_mut_unmasked
        assert abs(scores['A2_ngl_only'] - expected) < 1e-6

    def test_A3_gl_llr(self, single_position_data):
        """A3: logP_GL(Y|WT) - logP_GL(X|WT)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_gl_mut_unmasked - d.logp_gl_wt_unmasked
        assert abs(scores['A3_gl_llr'] - expected) < 1e-6

    def test_A4_marg_llr(self, single_position_data):
        """A4: logP_marg(Y|WT) - logP_marg(X|WT)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        marg_mut = compute_logsumexp(d.logp_gl_mut_unmasked, d.logp_ngl_mut_unmasked)
        marg_wt = compute_logsumexp(d.logp_gl_wt_unmasked, d.logp_ngl_wt_unmasked)
        expected = marg_mut - marg_wt
        assert abs(scores['A4_marg_llr'] - expected) < 1e-6


# =============================================================================
# Test Category B: Masked WT context scoring
# =============================================================================


class TestCategoryB:
    """Category B: Masked WT context (per-position masking)."""

    def test_B1_masked_ngl_gl(self, single_position_data):
        """B1: logP_NGL(Y|WT_m) - logP_GL(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_ngl_mut_wtctx - d.logp_gl_wt_wtctx
        assert abs(scores['B1_masked_ngl_gl'] - expected) < 1e-6

    def test_B2_masked_marg_llr(self, single_position_data):
        """B2: logP_marg(Y|WT_m) - logP_marg(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        marg_mut = compute_logsumexp(d.logp_gl_mut_wtctx, d.logp_ngl_mut_wtctx)
        marg_wt = compute_logsumexp(d.logp_gl_wt_wtctx, d.logp_ngl_wt_wtctx)
        expected = marg_mut - marg_wt
        assert abs(scores['B2_masked_marg_llr'] - expected) < 1e-6

    def test_B3_masked_ngl_only(self, single_position_data):
        """B3: logP_NGL(Y|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_ngl_mut_wtctx
        assert abs(scores['B3_masked_ngl_only'] - expected) < 1e-6

    def test_B4_masked_gl_llr(self, single_position_data):
        """B4: logP_GL(Y|WT_m) - logP_GL(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_gl_mut_wtctx - d.logp_gl_wt_wtctx
        assert abs(scores['B4_masked_gl_llr'] - expected) < 1e-6

    def test_B5_masked_ngl_ngl(self, single_position_data):
        """B5: logP_NGL(Y|WT_m) - logP_NGL(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_ngl_mut_wtctx - d.logp_ngl_wt_wtctx
        assert abs(scores['B5_masked_ngl_ngl'] - expected) < 1e-6


# =============================================================================
# Test Category C: Dual context scoring
# =============================================================================


class TestCategoryC:
    """Category C: Dual context (WT masked for ref, Mut masked for target)."""

    def test_C1_dual_ngl_gl(self, single_position_data):
        """C1: logP_NGL(Y|Mut_m) - logP_GL(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_ngl_mut_mutctx - d.logp_gl_wt_wtctx
        assert abs(scores['C1_dual_ngl_gl'] - expected) < 1e-6

    def test_C2_dual_marg(self, single_position_data):
        """C2: logP_marg(Y|Mut_m) - logP_marg(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        marg_mut = compute_logsumexp(d.logp_gl_mut_mutctx, d.logp_ngl_mut_mutctx)
        marg_wt = compute_logsumexp(d.logp_gl_wt_wtctx, d.logp_ngl_wt_wtctx)
        expected = marg_mut - marg_wt
        assert abs(scores['C2_dual_marg'] - expected) < 1e-6

    def test_C3_dual_ngl_ngl(self, single_position_data):
        """C3: logP_NGL(Y|Mut_m) - logP_NGL(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_ngl_mut_mutctx - d.logp_ngl_wt_wtctx
        assert abs(scores['C3_dual_ngl_ngl'] - expected) < 1e-6

    def test_C4_dual_gl_gl(self, single_position_data):
        """C4: logP_GL(Y|Mut_m) - logP_GL(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_gl_mut_mutctx - d.logp_gl_wt_wtctx
        assert abs(scores['C4_dual_gl_gl'] - expected) < 1e-6


# =============================================================================
# Test Category D: AA head only
# =============================================================================


class TestCategoryD:
    """Category D: AA head only (before alpha gating)."""

    def test_D1_aa_head_wt(self, single_position_data):
        """D1: logP_AA(Y|WT_m) - logP_AA(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_aa_mut_wtctx - d.logp_aa_wt_wtctx
        assert abs(scores['D1_aa_head_wt'] - expected) < 1e-6

    def test_D2_aa_head_dual(self, single_position_data):
        """D2: logP_AA(Y|Mut_m) - logP_AA(X|WT_m)."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        expected = d.logp_aa_mut_mutctx - d.logp_aa_wt_wtctx
        assert abs(scores['D2_aa_head_dual'] - expected) < 1e-6


# =============================================================================
# Test Category E: Origin-aware / Alpha-weighted
# =============================================================================


class TestCategoryE:
    """Category E: Origin-aware / Alpha-weighted methods."""

    def test_E1_origin_adaptive_ngl_position(self, single_position_data):
        """E1 at NGL position (p_ngl=0.8 > 0.5): uses NGL LLR."""
        d = single_position_data
        assert d.p_ngl > 0.5  # sanity check
        scores = compute_all_method_scores([d])
        # At NGL position: NGL LLR
        expected = d.logp_ngl_mut_wtctx - d.logp_ngl_wt_wtctx
        assert abs(scores['E1_origin_adaptive'] - expected) < 1e-6

    def test_E1_origin_adaptive_gl_position(self):
        """E1 at GL position (p_ngl=0.2 < 0.5): uses GL LLR."""
        d = PositionScoreData(
            logp_gl_wt_wtctx=-2.0, logp_ngl_wt_wtctx=-3.0,
            logp_gl_mut_wtctx=-4.0, logp_ngl_mut_wtctx=-1.5,
            logp_aa_wt_wtctx=-2.5, logp_aa_mut_wtctx=-3.5,
            logp_gl_wt_mutctx=-2.2, logp_ngl_wt_mutctx=-3.2,
            logp_gl_mut_mutctx=-3.8, logp_ngl_mut_mutctx=-1.2,
            logp_aa_wt_mutctx=-2.3, logp_aa_mut_mutctx=-3.3,
            alpha=0.3, p_ngl=0.2,  # GL position
            logp_gl_wt_unmasked=-1.8, logp_ngl_wt_unmasked=-2.8,
            logp_gl_mut_unmasked=-3.5, logp_ngl_mut_unmasked=-1.0,
        )
        scores = compute_all_method_scores([d])
        # At GL position: GL LLR
        expected = d.logp_gl_mut_wtctx - d.logp_gl_wt_wtctx
        assert abs(scores['E1_origin_adaptive'] - expected) < 1e-6

    def test_E2_alpha_weighted(self, single_position_data):
        """E2: alpha*NGL_LLR + (1-alpha)*GL_LLR using masked WT context."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        ngl_llr = d.logp_ngl_mut_wtctx - d.logp_ngl_wt_wtctx
        gl_llr = d.logp_gl_mut_wtctx - d.logp_gl_wt_wtctx
        expected = d.alpha * ngl_llr + (1 - d.alpha) * gl_llr
        assert abs(scores['E2_alpha_weighted'] - expected) < 1e-6

    def test_E2_alpha_zero(self):
        """E2 with alpha=0: should equal pure GL LLR."""
        d = PositionScoreData(
            logp_gl_wt_wtctx=-2.0, logp_ngl_wt_wtctx=-3.0,
            logp_gl_mut_wtctx=-4.0, logp_ngl_mut_wtctx=-1.5,
            logp_aa_wt_wtctx=-2.5, logp_aa_mut_wtctx=-3.5,
            logp_gl_wt_mutctx=-2.2, logp_ngl_wt_mutctx=-3.2,
            logp_gl_mut_mutctx=-3.8, logp_ngl_mut_mutctx=-1.2,
            logp_aa_wt_mutctx=-2.3, logp_aa_mut_mutctx=-3.3,
            alpha=0.0, p_ngl=0.5,
            logp_gl_wt_unmasked=-1.8, logp_ngl_wt_unmasked=-2.8,
            logp_gl_mut_unmasked=-3.5, logp_ngl_mut_unmasked=-1.0,
        )
        scores = compute_all_method_scores([d])
        gl_llr = d.logp_gl_mut_wtctx - d.logp_gl_wt_wtctx
        assert abs(scores['E2_alpha_weighted'] - gl_llr) < 1e-6

    def test_E2_alpha_one(self):
        """E2 with alpha=1: should equal pure NGL LLR."""
        d = PositionScoreData(
            logp_gl_wt_wtctx=-2.0, logp_ngl_wt_wtctx=-3.0,
            logp_gl_mut_wtctx=-4.0, logp_ngl_mut_wtctx=-1.5,
            logp_aa_wt_wtctx=-2.5, logp_aa_mut_wtctx=-3.5,
            logp_gl_wt_mutctx=-2.2, logp_ngl_wt_mutctx=-3.2,
            logp_gl_mut_mutctx=-3.8, logp_ngl_mut_mutctx=-1.2,
            logp_aa_wt_mutctx=-2.3, logp_aa_mut_mutctx=-3.3,
            alpha=1.0, p_ngl=0.5,
            logp_gl_wt_unmasked=-1.8, logp_ngl_wt_unmasked=-2.8,
            logp_gl_mut_unmasked=-3.5, logp_ngl_mut_unmasked=-1.0,
        )
        scores = compute_all_method_scores([d])
        ngl_llr = d.logp_ngl_mut_wtctx - d.logp_ngl_wt_wtctx
        assert abs(scores['E2_alpha_weighted'] - ngl_llr) < 1e-6

    def test_E3_alpha_boosted(self, single_position_data):
        """E3: alpha * [logP_NGL(Y|WT_m) - logP_GL(X|WT_m)]."""
        d = single_position_data
        scores = compute_all_method_scores([d])
        method_b = d.logp_ngl_mut_wtctx - d.logp_gl_wt_wtctx
        expected = d.alpha * method_b
        assert abs(scores['E3_alpha_boosted'] - expected) < 1e-6


# =============================================================================
# Test multi-position summing
# =============================================================================


class TestMultiPosition:
    def test_scores_sum_across_positions(self, multi_position_data):
        """Scores should sum across multiple mutation positions."""
        scores = compute_all_method_scores(multi_position_data)

        # B1 should sum: (ngl_mut_wtctx - gl_wt_wtctx) for each position
        pos1, pos2 = multi_position_data
        expected_b1 = (
            (pos1.logp_ngl_mut_wtctx - pos1.logp_gl_wt_wtctx) +
            (pos2.logp_ngl_mut_wtctx - pos2.logp_gl_wt_wtctx)
        )
        assert abs(scores['B1_masked_ngl_gl'] - expected_b1) < 1e-6

    def test_e2_sums_alpha_weighted_across_positions(self, multi_position_data):
        """E2 alpha-weighted should use per-position alpha values."""
        scores = compute_all_method_scores(multi_position_data)

        pos1, pos2 = multi_position_data
        ngl_llr1 = pos1.logp_ngl_mut_wtctx - pos1.logp_ngl_wt_wtctx
        gl_llr1 = pos1.logp_gl_mut_wtctx - pos1.logp_gl_wt_wtctx
        e2_pos1 = pos1.alpha * ngl_llr1 + (1 - pos1.alpha) * gl_llr1

        ngl_llr2 = pos2.logp_ngl_mut_wtctx - pos2.logp_ngl_wt_wtctx
        gl_llr2 = pos2.logp_gl_mut_wtctx - pos2.logp_gl_wt_wtctx
        e2_pos2 = pos2.alpha * ngl_llr2 + (1 - pos2.alpha) * gl_llr2

        expected = e2_pos1 + e2_pos2
        assert abs(scores['E2_alpha_weighted'] - expected) < 1e-6

    def test_e1_mixed_origin_positions(self, multi_position_data):
        """E1 should use NGL LLR for pos1 (p_ngl=0.8) and GL LLR for pos2 (p_ngl=0.4)."""
        scores = compute_all_method_scores(multi_position_data)

        pos1, pos2 = multi_position_data
        # pos1: p_ngl=0.8 > 0.5 → NGL LLR
        e1_pos1 = pos1.logp_ngl_mut_wtctx - pos1.logp_ngl_wt_wtctx
        # pos2: p_ngl=0.4 < 0.5 → GL LLR
        e1_pos2 = pos2.logp_gl_mut_wtctx - pos2.logp_gl_wt_wtctx

        expected = e1_pos1 + e1_pos2
        assert abs(scores['E1_origin_adaptive'] - expected) < 1e-6


# =============================================================================
# Test lambda sweep
# =============================================================================


class TestLambdaSweep:
    def test_lambda_zero_no_reference(self, single_position_data):
        """Lambda=0: score = mut_term only (no reference subtraction)."""
        d = single_position_data
        scores = compute_all_method_scores([d], lambda_value=0.0)
        # B1 with lambda=0: just logP_NGL(Y|WT_m), no subtraction of ref
        expected = d.logp_ngl_mut_wtctx
        assert abs(scores['B1_masked_ngl_gl'] - expected) < 1e-6

    def test_lambda_one_standard(self, single_position_data):
        """Lambda=1.0: score = mut_term - 1.0 * ref_term (standard)."""
        d = single_position_data
        scores = compute_all_method_scores([d], lambda_value=1.0)
        expected = d.logp_ngl_mut_wtctx - 1.0 * d.logp_gl_wt_wtctx
        assert abs(scores['B1_masked_ngl_gl'] - expected) < 1e-6

    def test_lambda_two_doubles_reference(self, single_position_data):
        """Lambda=2.0: score = mut_term - 2.0 * ref_term."""
        d = single_position_data
        scores = compute_all_method_scores([d], lambda_value=2.0)
        expected = d.logp_ngl_mut_wtctx - 2.0 * d.logp_gl_wt_wtctx
        assert abs(scores['B1_masked_ngl_gl'] - expected) < 1e-6

    def test_lambda_affects_all_methods_with_ref(self, single_position_data):
        """Lambda should affect all methods that have a reference term."""
        d = single_position_data
        scores_0 = compute_all_method_scores([d], lambda_value=0.0)
        scores_1 = compute_all_method_scores([d], lambda_value=1.0)

        # Methods with a reference term should differ
        methods_with_ref = [
            'A1_ngl_minus_gl', 'A3_gl_llr', 'A4_marg_llr',
            'B1_masked_ngl_gl', 'B2_masked_marg_llr', 'B4_masked_gl_llr',
            'B5_masked_ngl_ngl',
            'C1_dual_ngl_gl', 'C2_dual_marg', 'C3_dual_ngl_ngl', 'C4_dual_gl_gl',
            'D1_aa_head_wt', 'D2_aa_head_dual',
        ]
        for m in methods_with_ref:
            assert scores_0[m] != scores_1[m], f"{m} should change with lambda"

    def test_lambda_does_not_affect_score_only_methods(self, single_position_data):
        """Methods that are only a score (no reference subtraction) are unaffected by lambda."""
        d = single_position_data
        scores_0 = compute_all_method_scores([d], lambda_value=0.0)
        scores_2 = compute_all_method_scores([d], lambda_value=2.0)

        # A2 and B3 are "score only" (no subtraction)
        assert scores_0['A2_ngl_only'] == scores_2['A2_ngl_only']
        assert scores_0['B3_masked_ngl_only'] == scores_2['B3_masked_ngl_only']


# =============================================================================
# Test all 18 methods are returned
# =============================================================================


class TestMethodCompleteness:
    def test_all_18_methods_present(self, single_position_data):
        """compute_all_method_scores should return all 18 methods."""
        scores = compute_all_method_scores([single_position_data])
        expected_methods = [
            'A1_ngl_minus_gl', 'A2_ngl_only', 'A3_gl_llr', 'A4_marg_llr',
            'B1_masked_ngl_gl', 'B2_masked_marg_llr', 'B3_masked_ngl_only',
            'B4_masked_gl_llr', 'B5_masked_ngl_ngl',
            'C1_dual_ngl_gl', 'C2_dual_marg', 'C3_dual_ngl_ngl', 'C4_dual_gl_gl',
            'D1_aa_head_wt', 'D2_aa_head_dual',
            'E1_origin_adaptive', 'E2_alpha_weighted', 'E3_alpha_boosted',
        ]
        for method in expected_methods:
            assert method in scores, f"Missing method: {method}"
        assert len(scores) == 18


# =============================================================================
# Edge cases
# =============================================================================


class TestEdgeCases:
    def test_empty_position_list(self):
        """Empty position list should return zeros for all methods."""
        scores = compute_all_method_scores([])
        for method, value in scores.items():
            assert value == 0.0, f"{method} should be 0.0 for empty positions"

    def test_very_negative_logprobs(self):
        """Extremely negative logprobs should not cause NaN or overflow."""
        d = PositionScoreData(
            logp_gl_wt_wtctx=-100.0, logp_ngl_wt_wtctx=-100.0,
            logp_gl_mut_wtctx=-100.0, logp_ngl_mut_wtctx=-100.0,
            logp_aa_wt_wtctx=-100.0, logp_aa_mut_wtctx=-100.0,
            logp_gl_wt_mutctx=-100.0, logp_ngl_wt_mutctx=-100.0,
            logp_gl_mut_mutctx=-100.0, logp_ngl_mut_mutctx=-100.0,
            logp_aa_wt_mutctx=-100.0, logp_aa_mut_mutctx=-100.0,
            alpha=0.5, p_ngl=0.5,
            logp_gl_wt_unmasked=-100.0, logp_ngl_wt_unmasked=-100.0,
            logp_gl_mut_unmasked=-100.0, logp_ngl_mut_unmasked=-100.0,
        )
        scores = compute_all_method_scores([d])
        for method, value in scores.items():
            assert not math.isnan(value), f"{method} is NaN"
            assert not math.isinf(value), f"{method} is inf"
