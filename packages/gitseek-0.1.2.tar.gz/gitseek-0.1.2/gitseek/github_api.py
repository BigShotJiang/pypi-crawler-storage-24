import requests

GITHUB_API = "https://api.github.com/search/repositories"

def search_repositories(query, stars=None, limit=5):
    q = query

    if stars:
        q += f" stars:>{stars}"

    params = {
        "q": q,
        "sort": "stars",
        "order": "desc",
        "per_page": limit
    }

    response = requests.get(GITHUB_API, params=params)
    data = response.json()

    return data.get("items", [])