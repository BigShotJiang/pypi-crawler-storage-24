"""
This module is an abstraction layer of the “Schizophrenic Artificial Intelligence” algorithm created by Sapiens Technology®️.
It acts as an intermediary between user inputs and model outputs, requesting from “Frankenstein” through the “Entity” the submodels most suitable for each type of situation.
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_schizophrenic_ai'
version = '1.0.7'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=['schizophrenic-artificial-intelligence'],
    url='https://github.com/sapiens-technology/sapiens_schizophrenic_ai',
    license='Proprietary Software'
)
"""
This module is an abstraction layer of the “Schizophrenic Artificial Intelligence” algorithm created by Sapiens Technology®️.
It acts as an intermediary between user inputs and model outputs, requesting from “Frankenstein” through the “Entity” the submodels most suitable for each type of situation.
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
