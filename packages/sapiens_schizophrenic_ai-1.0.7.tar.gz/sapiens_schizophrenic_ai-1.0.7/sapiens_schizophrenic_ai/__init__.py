"""
This module is an abstraction layer of the “Schizophrenic Artificial Intelligence” algorithm created by Sapiens Technology®️.
It acts as an intermediary between user inputs and model outputs, requesting from “Frankenstein” through the “Entity” the submodels most suitable for each type of situation.
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .sapiens_schizophrenic_ai import *
"""
This module is an abstraction layer of the “Schizophrenic Artificial Intelligence” algorithm created by Sapiens Technology®️.
It acts as an intermediary between user inputs and model outputs, requesting from “Frankenstein” through the “Entity” the submodels most suitable for each type of situation.
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
