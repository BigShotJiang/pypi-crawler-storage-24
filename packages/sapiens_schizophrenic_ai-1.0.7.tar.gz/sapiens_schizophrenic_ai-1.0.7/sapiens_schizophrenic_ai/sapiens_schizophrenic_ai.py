"""
This module is an abstraction layer of the “Schizophrenic Artificial Intelligence” algorithm created by Sapiens Technology®️.
It acts as an intermediary between user inputs and model outputs, requesting from “Frankenstein” through the “Entity” the submodels most suitable for each type of situation.
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
class SapiensSchizophrenicAI:
	def __init__(self, show_errors=True, display_error_point=False):
		try:
			self.__show_errors = bool(show_errors) if type(show_errors) in (bool, int, float) else True
			self.__display_error_point = bool(display_error_point) if type(display_error_point) in (bool, int, float) else False
			try:
				from warnings import simplefilter, filterwarnings
				from logging import getLogger, ERROR, disable, CRITICAL
				from os import environ
				from dotenv import load_dotenv
				simplefilter('ignore')
				filterwarnings('ignore')
				filterwarnings('ignore', category=UserWarning, module='torch.distributed')
				getLogger('torch.distributed.elastic.multiprocessing.redirects').setLevel(ERROR)
				environ['DISABLE_MODEL_SOURCE_CHECK'] = 'True'
				load_dotenv()
				disable(CRITICAL)
			except: pass
			from traceback import print_exc
			self.__print_exc = print_exc
			from schizophrenic_artificial_intelligence import SchizophrenicArtificialIntelligence
			self.__schizophrenic_artificial_intelligence = SchizophrenicArtificialIntelligence(show_errors=self.__show_errors, display_error_point=self.__display_error_point)
			self.__OUTPUT = {'answer': '', 'answer_for_files': '', 'files': [], 'sources': [], 'javascript_charts': [], 'artifacts': [], 'next_token': '', 'str_cost': '0.0000000000', 'tool_call': []}
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSchizophrenicAI.__init__: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def loadModel(self, model_path='', progress=True):
		try: return self.__schizophrenic_artificial_intelligence.loadModel(model_path=model_path, progress=progress)
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSchizophrenicAI.loadModel: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
	def inference(self, messages=[], max_tokens=None, stream=True, task_names=[], language='', temperature=0.5, creativity=0.5, humor=0.5, formality=0.5, political_spectrum=0.5, reasoning=0.0, reflection=False, tools=[]):
		try:
			inference_dictionary = self.__OUTPUT
			messages = list(messages) if type(messages) in (tuple, list) else []
			if max_tokens is not None: max_tokens = int(max_tokens) if type(max_tokens) in (bool, int, float) else None
			stream = bool(stream) if type(stream) in (bool, int, float) else True
			task_names = list(task_names) if type(task_names) in (tuple, list) else []
			language = str(language).strip()
			temperature = float(temperature) if type(temperature) in (bool, int, float) else 0.5
			creativity = float(creativity) if type(creativity) in (bool, int, float) else 0.5
			humor = float(humor) if type(humor) in (bool, int, float) else 0.5
			formality = float(formality) if type(formality) in (bool, int, float) else 0.5
			political_spectrum = float(political_spectrum) if type(political_spectrum) in (bool, int, float) else 0.5
			reasoning = float(reasoning) if type(reasoning) in (bool, int, float) else 0.5
			reflection = bool(reflection) if type(reflection) in (bool, int, float) else False
			tools = list(tools) if type(tools) in (tuple, list) else []
			self.__schizophrenic_artificial_intelligence.max_tokens = max_tokens
			self.__schizophrenic_artificial_intelligence.task_names = task_names
			self.__schizophrenic_artificial_intelligence.language = language
			self.__schizophrenic_artificial_intelligence.temperature = temperature
			self.__schizophrenic_artificial_intelligence.creativity = creativity
			self.__schizophrenic_artificial_intelligence.humor = humor
			self.__schizophrenic_artificial_intelligence.formality = formality
			self.__schizophrenic_artificial_intelligence.political_spectrum = political_spectrum
			self.__schizophrenic_artificial_intelligence.reasoning = reasoning
			self.__schizophrenic_artificial_intelligence.reflection = reflection
			self.__schizophrenic_artificial_intelligence.tools = tools
			self.__schizophrenic_artificial_intelligence.delay = 0.0
			inference_dictionary = self.__schizophrenic_artificial_intelligence.completeMessages(messages=messages, stream=stream)
			if max_tokens and type(max_tokens) == int:
				if stream:
					tokens_count = 0
					def _limit_tokens(inference_dictionary=[]):
						nonlocal tokens_count
						for dictionary in inference_dictionary:
							if tokens_count > max_tokens:
								dictionary['next_token'] = ''
								yield dictionary
							else:
								tokens_count += 1
								yield dictionary
					return _limit_tokens(inference_dictionary=inference_dictionary)
				else:
					def _limit_answer_words(answer='', max_tokens=None):
						truncated_text = answer
						if not max_tokens: return truncated_text
						words = answer.split()
						if len(words) <= max_tokens: return answer
						truncated_text = ' '.join(words[:max_tokens])
						punctuation_priority = ('.', '?', '!', ';', ',')
						for punctuation in punctuation_priority:
							index = truncated_text.rfind(punctuation)
							if index != -1: return truncated_text[:index+1]
						return truncated_text
					answer = inference_dictionary['answer']
					inference_dictionary['answer'] = _limit_answer_words(answer=answer, max_tokens=max_tokens)
			return inference_dictionary
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSchizophrenicAI.inference: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return self.__OUTPUT
	def printInference(self, messages=[], max_tokens=None, stream=True, task_names=[], language='', temperature=0.5, creativity=0.5, humor=0.5, formality=0.5, political_spectrum=0.5, reasoning=0.0, reflection=False, tools=[]):
		try:
			inference = self.inference(messages=messages, max_tokens=max_tokens, stream=stream, task_names=task_names, language=language, temperature=temperature, creativity=creativity, humor=humor, formality=formality, political_spectrum=political_spectrum, reasoning=reasoning, reflection=reflection, tools=tools)
			if stream:
				first_token = True
				for dictionary in inference:
					token = dictionary.get('next_token', '')
					if not token: continue
					if first_token:
						print(token.lstrip(), end='', flush=True)
						first_token = False
					else: print(token, end='', flush=True)
				print()
			else: print(inference['answer'])
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSchizophrenicAI.printInference: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def close(self):
		try: return self.__schizophrenic_artificial_intelligence.close()
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSchizophrenicAI.close: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
"""
This module is an abstraction layer of the “Schizophrenic Artificial Intelligence” algorithm created by Sapiens Technology®️.
It acts as an intermediary between user inputs and model outputs, requesting from “Frankenstein” through the “Entity” the submodels most suitable for each type of situation.
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
