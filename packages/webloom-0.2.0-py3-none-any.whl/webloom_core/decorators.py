from __future__ import annotations

from functools import lru_cache, wraps
from typing import Any, Callable, ParamSpec, TypeVar

from .element import Element
from .page import Page
from .style import ResponsiveStyle, Style, StyleSheet, Theme

P = ParamSpec("P")
R = TypeVar("R")


def component(func: Callable[P, R]) -> Callable[P, R]:
    """Marks a function as a Webloom component and validates non-None output."""

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        result = func(*args, **kwargs)
        if result is None:
            raise ValueError(f"Component {func.__name__} returned None")
        return result

    return wrapper


def memo_component(maxsize: int = 128) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Caches pure component output."""

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        cached = lru_cache(maxsize=maxsize)(func)

        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            return cached(*args, **kwargs)

        setattr(wrapper, "cache_clear", cached.cache_clear)
        setattr(wrapper, "cache_info", cached.cache_info)
        return wrapper

    return decorator


def page_component(title: str, **page_kwargs: Any) -> Callable[[Callable[P, Any]], Callable[P, Page]]:
    """Wraps component output into a Page object."""

    def decorator(func: Callable[P, Any]) -> Callable[P, Page]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> Page:
            result = func(*args, **kwargs)

            if isinstance(result, Page):
                return result
            if result is None:
                return Page(title, **page_kwargs)
            if isinstance(result, (list, tuple)):
                return Page(title, *result, **page_kwargs)
            return Page(title, result, **page_kwargs)

        return wrapper

    return decorator


def styled(
    style: Style | dict[str, object] | None = None,
    responsive: ResponsiveStyle | dict[str, object] | None = None,
    **attrs: Any,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Decorator to attach style/responsive/attrs to returned Element."""

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            result = func(*args, **kwargs)
            if isinstance(result, Element):
                if style is not None:
                    result.merge_style(style)
                if responsive is not None:
                    result.merge_responsive(responsive)
                if attrs:
                    result.set_attrs(**attrs)
            return result

        return wrapper

    return decorator


def with_stylesheets(*stylesheets: StyleSheet | str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Adds one or more stylesheets to returned Page."""

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            result = func(*args, **kwargs)
            if isinstance(result, Page):
                result.stylesheets.extend(stylesheets)
            return result

        return wrapper

    return decorator


def with_themes(*themes: Theme | dict[str, object]) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Adds one or more themes to returned Page."""

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            result = func(*args, **kwargs)
            if isinstance(result, Page):
                for theme in themes:
                    if isinstance(theme, Theme):
                        result.themes.append(theme)
                    else:
                        result.themes.append(Theme(tokens=theme))
            return result

        return wrapper

    return decorator