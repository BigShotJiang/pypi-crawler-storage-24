from __future__ import annotations

import re

from .element import Element

_HTML_TAGS = [
    "a",
    "abbr",
    "address",
    "area",
    "article",
    "aside",
    "audio",
    "b",
    "base",
    "bdi",
    "bdo",
    "blockquote",
    "body",
    "br",
    "button",
    "canvas",
    "caption",
    "cite",
    "code",
    "col",
    "colgroup",
    "data",
    "datalist",
    "dd",
    "del",
    "details",
    "dfn",
    "dialog",
    "div",
    "dl",
    "dt",
    "em",
    "embed",
    "fieldset",
    "figcaption",
    "figure",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "hgroup",
    "hr",
    "html",
    "i",
    "iframe",
    "img",
    "input",
    "ins",
    "kbd",
    "label",
    "legend",
    "li",
    "link",
    "main",
    "map",
    "mark",
    "menu",
    "meta",
    "meter",
    "nav",
    "noscript",
    "object",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "param",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "script",
    "search",
    "section",
    "select",
    "slot",
    "small",
    "source",
    "span",
    "strong",
    "style",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "template",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "title",
    "tr",
    "track",
    "u",
    "ul",
    "var",
    "video",
    "wbr",
]

_SPECIAL_CLASS_NAMES = {
    "del": "DelTag",
    "map": "MapTag",
    "object": "ObjectTag",
    "style": "StyleTag",
    "var": "VarTag",
}


def _to_class_name(tag: str) -> str:
    if tag in _SPECIAL_CLASS_NAMES:
        return _SPECIAL_CLASS_NAMES[tag]
    return "".join(part.capitalize() for part in tag.split("-"))


def _class_to_tag_name(class_name: str) -> str:
    value = class_name.strip().replace("_", "-")
    if not value:
        raise ValueError("Class name cannot be empty")

    step1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1-\2", value)
    step2 = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", step1)
    cleaned = step2.lower().strip("-")
    if not cleaned:
        raise ValueError(f"Invalid class name: {class_name!r}")
    return cleaned


def _normalize_tag_name(name: str) -> str:
    cleaned = name.strip().lower().replace("_", "-")
    cleaned = re.sub(r"[^a-z0-9\-]", "-", cleaned)
    cleaned = re.sub(r"-+", "-", cleaned).strip("-")
    if not cleaned:
        raise ValueError("Tag name cannot be empty")
    return cleaned


def tag_class(name: str) -> type[Element]:
    tag_name = _normalize_tag_name(name)
    class_name = _to_class_name(tag_name)
    cls = globals().get(class_name)
    if isinstance(cls, type) and issubclass(cls, Element) and getattr(cls, "tag", None) == tag_name:
        return cls

    cls = type(class_name, (Element,), {"tag": tag_name})
    globals()[class_name] = cls
    if class_name not in __all__:
        __all__.append(class_name)
    return cls


def custom_tag(name: str, *children: object, **attrs: object) -> Element:
    return tag_class(name)(*children, **attrs)


def tag(name: str, *children: object, **attrs: object) -> Element:
    return custom_tag(name, *children, **attrs)


__all__: list[str] = []

for _tag in _HTML_TAGS:
    _class_name = _to_class_name(_tag)
    globals()[_class_name] = type(_class_name, (Element,), {"tag": _tag})
    __all__.append(_class_name)


for _helper in ("custom_tag", "tag", "tag_class"):
    if _helper not in __all__:
        __all__.append(_helper)


def __getattr__(name: str) -> object:
    if name.startswith("_"):
        raise AttributeError(name)

    try:
        tag_name = _class_to_tag_name(name)
    except ValueError as exc:
        raise AttributeError(name) from exc

    cls = type(name, (Element,), {"tag": tag_name})
    globals()[name] = cls
    if name not in __all__:
        __all__.append(name)
    return cls