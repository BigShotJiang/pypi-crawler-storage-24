from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Iterable, Mapping

DEFAULT_BREAKPOINTS: dict[str, str] = {
    "sm": "640px",
    "md": "768px",
    "lg": "1024px",
    "xl": "1280px",
    "2xl": "1536px",
}

_PSEUDO_ELEMENTS = {
    "after",
    "before",
    "first-letter",
    "first-line",
    "marker",
    "placeholder",
    "selection",
    "backdrop",
}

_SIZE_TOKEN_RE = re.compile(r"^\d+(\.\d+)?(px|em|rem|vh|vw|vmin|vmax|%)$")


def _to_css_name(name: str) -> str:
    if name.startswith("--"):
        return name
    if name.startswith("_"):
        return "-" + name.lstrip("_").replace("_", "-")
    return name.strip("_").replace("_", "-")


def _to_css_var_name(name: str) -> str:
    normalized = _to_css_name(name)
    if not normalized.startswith("--"):
        return f"--{normalized}"
    return normalized


def _normalize_pseudo(name: str) -> str:
    cleaned = name.strip().replace("_", "-")
    if not cleaned:
        raise ValueError("Pseudo selector cannot be empty")

    raw = cleaned.lstrip(":")
    prefix = "::" if raw in _PSEUDO_ELEMENTS else ":"
    return f"{prefix}{raw}"


def _normalize_support_condition(condition: str) -> str:
    value = condition.strip()
    if not value:
        raise ValueError("Supports condition cannot be empty")
    if value.startswith("("):
        return value
    return f"({value})"


def _selector_text(selector: object) -> str:
    text = str(selector).strip()
    if not text:
        raise ValueError("Selector cannot be empty")
    return text


def _indent_block(block: str, spaces: int = 2) -> str:
    prefix = " " * spaces
    return "\n".join(prefix + line if line else line for line in block.splitlines())


def _render_rule(selector: object, style: "Style", indent: str = "") -> str:
    selector_text = _selector_text(selector)
    lines = [f"{indent}{selector_text} {{"]
    for key, value in style.as_dict().items():
        lines.append(f"{indent}  {key}: {value};")
    lines.append(f"{indent}}}")
    return "\n".join(lines)


class Style:
    """Simple style container that renders as inline CSS."""

    def __init__(self, **properties: object) -> None:
        self._values: dict[str, str] = {}
        for key, value in properties.items():
            self.set(key, value)

    def set(self, key: str, value: object) -> "Style":
        if value is None:
            return self
        self._values[_to_css_name(key)] = str(value)
        return self

    def update(self, values: Mapping[str, object]) -> "Style":
        for key, value in values.items():
            self.set(key, value)
        return self

    @classmethod
    def combine(cls, *items: "Style | Mapping[str, object] | None") -> "Style":
        merged = cls()
        for item in items:
            if item is None:
                continue
            if isinstance(item, Style):
                merged._values.update(item._values)
                continue
            for key, value in item.items():
                if value is None:
                    continue
                merged._values[_to_css_name(key)] = str(value)
        return merged

    def as_dict(self) -> dict[str, str]:
        return dict(self._values)

    def to_inline(self) -> str:
        return "; ".join(f"{key}: {value}" for key, value in self._values.items())

    def __bool__(self) -> bool:
        return bool(self._values)

    def __repr__(self) -> str:
        return f"Style({self._values!r})"


@dataclass
class MediaQuery:
    min_width: str | None = None
    max_width: str | None = None
    min_height: str | None = None
    max_height: str | None = None
    orientation: str | None = None
    prefers_color_scheme: str | None = None
    prefers_reduced_motion: str | None = None
    prefers_contrast: str | None = None
    hover: str | None = None
    pointer: str | None = None
    media_type: str | None = None
    custom: str | None = None

    @classmethod
    def from_value(cls, value: "MediaQuery | str | None" = None, **kwargs: object) -> "MediaQuery":
        updates = {key: val for key, val in kwargs.items() if val is not None}

        if isinstance(value, MediaQuery):
            data = value.__dict__.copy()
            data.update(updates)
            return cls(**data)

        if isinstance(value, str):
            data = dict(updates)
            stripped = value.strip()
            if _SIZE_TOKEN_RE.match(stripped):
                data.setdefault("min_width", stripped)
            else:
                data.setdefault("custom", stripped)
            return cls(**data)

        return cls(**updates)

    def to_condition(self) -> str:
        parts: list[str] = []
        if self.media_type:
            parts.append(self.media_type.strip())
        if self.custom:
            parts.append(self.custom.strip())
        if self.min_width:
            parts.append(f"(min-width: {self.min_width})")
        if self.max_width:
            parts.append(f"(max-width: {self.max_width})")
        if self.min_height:
            parts.append(f"(min-height: {self.min_height})")
        if self.max_height:
            parts.append(f"(max-height: {self.max_height})")
        if self.orientation:
            parts.append(f"(orientation: {self.orientation})")
        if self.prefers_color_scheme:
            parts.append(f"(prefers-color-scheme: {self.prefers_color_scheme})")
        if self.prefers_reduced_motion:
            parts.append(f"(prefers-reduced-motion: {self.prefers_reduced_motion})")
        if self.prefers_contrast:
            parts.append(f"(prefers-contrast: {self.prefers_contrast})")
        if self.hover:
            parts.append(f"(hover: {self.hover})")
        if self.pointer:
            parts.append(f"(pointer: {self.pointer})")

        return " and ".join(part for part in parts if part) or "all"

    def __str__(self) -> str:
        return self.to_condition()


@dataclass
class ContainerQuery:
    name: str | None = None
    min_width: str | None = None
    max_width: str | None = None
    min_height: str | None = None
    max_height: str | None = None
    orientation: str | None = None
    custom: str | None = None

    @classmethod
    def from_value(cls, value: "ContainerQuery | str | None" = None, **kwargs: object) -> "ContainerQuery":
        updates = {key: val for key, val in kwargs.items() if val is not None}

        if isinstance(value, ContainerQuery):
            data = value.__dict__.copy()
            data.update(updates)
            return cls(**data)

        if isinstance(value, str):
            data = dict(updates)
            if "name" in data or "custom" in data:
                return cls(**data)
            stripped = value.strip()
            if _SIZE_TOKEN_RE.match(stripped):
                data["min_width"] = stripped
            elif "(" in stripped or ":" in stripped or stripped.startswith("style"):
                data["custom"] = stripped
            else:
                data["name"] = stripped
            return cls(**data)

        return cls(**updates)

    def to_header(self) -> str:
        parts: list[str] = []
        if self.name:
            parts.append(self.name.strip())
        if self.custom:
            parts.append(self.custom.strip())
        if self.min_width:
            parts.append(f"(min-width: {self.min_width})")
        if self.max_width:
            parts.append(f"(max-width: {self.max_width})")
        if self.min_height:
            parts.append(f"(min-height: {self.min_height})")
        if self.max_height:
            parts.append(f"(max-height: {self.max_height})")
        if self.orientation:
            parts.append(f"(orientation: {self.orientation})")

        return " ".join(part for part in parts if part) or "(min-width: 0px)"

    def __str__(self) -> str:
        return self.to_header()


class Theme:
    """CSS variable token manager."""

    def __init__(self, tokens: Mapping[str, object] | None = None, **named_tokens: object) -> None:
        self._tokens: dict[str, str] = {}

        if tokens:
            for name, value in tokens.items():
                self.set(str(name), value)

        for name, value in named_tokens.items():
            self.set(name, value)

    def set(self, name: str, value: object) -> "Theme":
        if value is None:
            return self
        self._tokens[_to_css_var_name(name)] = str(value)
        return self

    def get(self, name: str, default: str | None = None) -> str | None:
        return self._tokens.get(_to_css_var_name(name), default)

    def var(self, name: str, fallback: object | None = None) -> str:
        token = _to_css_var_name(name)
        if fallback is None:
            return f"var({token})"
        return f"var({token}, {fallback})"

    def as_style(self) -> Style:
        return Style.combine(self._tokens)

    def to_css(self, selector: object = ":root") -> str:
        style = self.as_style()
        if not style:
            return ""
        return _render_rule(selector, style)

    def as_dict(self) -> dict[str, str]:
        return dict(self._tokens)

    def __bool__(self) -> bool:
        return bool(self._tokens)


class ResponsiveStyle:
    """Responsive style with pseudo and conditional rule support."""

    def __init__(
        self,
        base: Style | Mapping[str, object] | None = None,
        breakpoints: Mapping[str, Style | Mapping[str, object]] | None = None,
        pseudos: Mapping[str, Style | Mapping[str, object]] | None = None,
        breakpoint_pseudos: Mapping[str, Mapping[str, Style | Mapping[str, object]]] | None = None,
        media: Mapping[str, Style | Mapping[str, object]] | None = None,
        media_pseudos: Mapping[str, Mapping[str, Style | Mapping[str, object]]] | None = None,
        supports: Mapping[str, Style | Mapping[str, object]] | None = None,
        support_pseudos: Mapping[str, Mapping[str, Style | Mapping[str, object]]] | None = None,
        **responsive: Style | Mapping[str, object],
    ) -> None:
        self.base = Style.combine(base)
        self.breakpoints: dict[str, Style] = {}
        self.pseudos: dict[str, Style] = {}
        self.breakpoint_pseudos: dict[str, dict[str, Style]] = {}
        self.media: dict[str, Style] = {}
        self.media_pseudos: dict[str, dict[str, Style]] = {}
        self.supports: dict[str, Style] = {}
        self.support_pseudos: dict[str, dict[str, Style]] = {}

        merged_breakpoints: dict[str, Style | Mapping[str, object]] = {}
        if breakpoints:
            merged_breakpoints.update(breakpoints)
        merged_breakpoints.update(responsive)

        for name, style in merged_breakpoints.items():
            self.set_breakpoint(str(name), style)

        if pseudos:
            for pseudo_name, style in pseudos.items():
                self.set_pseudo(str(pseudo_name), style)

        if breakpoint_pseudos:
            for bp_name, pseudo_map in breakpoint_pseudos.items():
                for pseudo_name, style in pseudo_map.items():
                    self.set_breakpoint_pseudo(str(bp_name), str(pseudo_name), style)

        if media:
            for query, style in media.items():
                self.set_media(str(query), style)

        if media_pseudos:
            for query, pseudo_map in media_pseudos.items():
                for pseudo_name, style in pseudo_map.items():
                    self.set_media_pseudo(str(query), str(pseudo_name), style)

        if supports:
            for condition, style in supports.items():
                self.set_support(str(condition), style)

        if support_pseudos:
            for condition, pseudo_map in support_pseudos.items():
                for pseudo_name, style in pseudo_map.items():
                    self.set_support_pseudo(str(condition), str(pseudo_name), style)

        self.class_name = self._build_class_name()

    def set_breakpoint(self, name: str, style: Style | Mapping[str, object] | None) -> "ResponsiveStyle":
        if style is None:
            return self
        self.breakpoints[str(name)] = Style.combine(style)
        return self

    def set_pseudo(self, pseudo_name: str, style: Style | Mapping[str, object] | None) -> "ResponsiveStyle":
        if style is None:
            return self
        self.pseudos[_normalize_pseudo(pseudo_name)] = Style.combine(style)
        return self

    def set_breakpoint_pseudo(
        self,
        breakpoint_name: str,
        pseudo_name: str,
        style: Style | Mapping[str, object] | None,
    ) -> "ResponsiveStyle":
        if style is None:
            return self
        bp = str(breakpoint_name)
        pseudo = _normalize_pseudo(pseudo_name)
        self.breakpoint_pseudos.setdefault(bp, {})[pseudo] = Style.combine(style)
        return self

    def set_media(self, query: str | MediaQuery, style: Style | Mapping[str, object] | None) -> "ResponsiveStyle":
        if style is None:
            return self
        media_query = str(query) if isinstance(query, MediaQuery) else str(MediaQuery.from_value(query))
        self.media[media_query] = Style.combine(style)
        return self

    def set_media_pseudo(
        self,
        query: str | MediaQuery,
        pseudo_name: str,
        style: Style | Mapping[str, object] | None,
    ) -> "ResponsiveStyle":
        if style is None:
            return self
        media_query = str(query) if isinstance(query, MediaQuery) else str(MediaQuery.from_value(query))
        pseudo = _normalize_pseudo(pseudo_name)
        self.media_pseudos.setdefault(media_query, {})[pseudo] = Style.combine(style)
        return self

    def set_support(self, condition: str, style: Style | Mapping[str, object] | None) -> "ResponsiveStyle":
        if style is None:
            return self
        support_condition = _normalize_support_condition(condition)
        self.supports[support_condition] = Style.combine(style)
        return self

    def set_support_pseudo(
        self,
        condition: str,
        pseudo_name: str,
        style: Style | Mapping[str, object] | None,
    ) -> "ResponsiveStyle":
        if style is None:
            return self
        support_condition = _normalize_support_condition(condition)
        pseudo = _normalize_pseudo(pseudo_name)
        self.support_pseudos.setdefault(support_condition, {})[pseudo] = Style.combine(style)
        return self

    def _build_class_name(self) -> str:
        payload = {
            "base": self.base.as_dict(),
            "breakpoints": {name: style.as_dict() for name, style in sorted(self.breakpoints.items())},
            "pseudos": {name: style.as_dict() for name, style in sorted(self.pseudos.items())},
            "breakpoint_pseudos": {
                bp: {name: style.as_dict() for name, style in sorted(pseudo_map.items())}
                for bp, pseudo_map in sorted(self.breakpoint_pseudos.items())
            },
            "media": {q: style.as_dict() for q, style in sorted(self.media.items())},
            "media_pseudos": {
                q: {name: style.as_dict() for name, style in sorted(pseudo_map.items())}
                for q, pseudo_map in sorted(self.media_pseudos.items())
            },
            "supports": {c: style.as_dict() for c, style in sorted(self.supports.items())},
            "support_pseudos": {
                c: {name: style.as_dict() for name, style in sorted(pseudo_map.items())}
                for c, pseudo_map in sorted(self.support_pseudos.items())
            },
        }

        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:10]
        return f"wb-{digest}"

    def to_css(self, breakpoints: Mapping[str, str] | None = None) -> str:
        bp_map = dict(DEFAULT_BREAKPOINTS)
        if breakpoints:
            bp_map.update({str(k): str(v) for k, v in breakpoints.items()})

        blocks: list[str] = []

        if self.base:
            blocks.append(_render_rule(f".{self.class_name}", self.base))

        for pseudo_name, style in self.pseudos.items():
            if style:
                blocks.append(_render_rule(f".{self.class_name}{pseudo_name}", style))

        all_breakpoints = set(self.breakpoints.keys()) | set(self.breakpoint_pseudos.keys())
        for bp_name in sorted(all_breakpoints):
            width = bp_map.get(bp_name, bp_name)
            media_lines = [f"@media (min-width: {width}) {{"]

            bp_style = self.breakpoints.get(bp_name)
            if bp_style:
                media_lines.append(_render_rule(f".{self.class_name}", bp_style, indent="  "))

            for pseudo_name, pseudo_style in self.breakpoint_pseudos.get(bp_name, {}).items():
                if pseudo_style:
                    media_lines.append(_render_rule(f".{self.class_name}{pseudo_name}", pseudo_style, indent="  "))

            media_lines.append("}")
            blocks.append("\n".join(media_lines))

        all_media = set(self.media.keys()) | set(self.media_pseudos.keys())
        for query in sorted(all_media):
            media_lines = [f"@media {query} {{"]

            media_style = self.media.get(query)
            if media_style:
                media_lines.append(_render_rule(f".{self.class_name}", media_style, indent="  "))

            for pseudo_name, pseudo_style in self.media_pseudos.get(query, {}).items():
                if pseudo_style:
                    media_lines.append(_render_rule(f".{self.class_name}{pseudo_name}", pseudo_style, indent="  "))

            media_lines.append("}")
            blocks.append("\n".join(media_lines))

        all_supports = set(self.supports.keys()) | set(self.support_pseudos.keys())
        for condition in sorted(all_supports):
            support_lines = [f"@supports {condition} {{"]

            support_style = self.supports.get(condition)
            if support_style:
                support_lines.append(_render_rule(f".{self.class_name}", support_style, indent="  "))

            for pseudo_name, pseudo_style in self.support_pseudos.get(condition, {}).items():
                if pseudo_style:
                    support_lines.append(_render_rule(f".{self.class_name}{pseudo_name}", pseudo_style, indent="  "))

            support_lines.append("}")
            blocks.append("\n".join(support_lines))

        return "\n\n".join(block for block in blocks if block.strip())

    def __repr__(self) -> str:
        return f"ResponsiveStyle(class_name={self.class_name!r})"


class StyleSheet:
    """Programmatic stylesheet builder for global and advanced CSS at-rules."""

    def __init__(self, *raw_rules: str) -> None:
        self._rules: list[str] = [rule.strip() for rule in raw_rules if rule and rule.strip()]

    def add_raw(self, css: str) -> "StyleSheet":
        if css and css.strip():
            self._rules.append(css.strip())
        return self

    def add_rule(self, selector: object, style: Style | Mapping[str, object]) -> "StyleSheet":
        self._rules.append(_render_rule(selector, Style.combine(style)))
        return self

    def add_pseudo(self, selector: object, pseudo: str, style: Style | Mapping[str, object]) -> "StyleSheet":
        self._rules.append(_render_rule(f"{_selector_text(selector)}{_normalize_pseudo(pseudo)}", Style.combine(style)))
        return self

    def add_media(
        self,
        query: MediaQuery | str | None = None,
        selector: object | None = None,
        style: Style | Mapping[str, object] | None = None,
        *,
        rules: Iterable[str] | None = None,
        min_width: str | None = None,
        max_width: str | None = None,
        min_height: str | None = None,
        max_height: str | None = None,
        orientation: str | None = None,
        prefers_color_scheme: str | None = None,
        prefers_reduced_motion: str | None = None,
        prefers_contrast: str | None = None,
        hover: str | None = None,
        pointer: str | None = None,
        media_type: str | None = None,
        custom: str | None = None,
    ) -> "StyleSheet":
        media_query = MediaQuery.from_value(
            query,
            min_width=min_width,
            max_width=max_width,
            min_height=min_height,
            max_height=max_height,
            orientation=orientation,
            prefers_color_scheme=prefers_color_scheme,
            prefers_reduced_motion=prefers_reduced_motion,
            prefers_contrast=prefers_contrast,
            hover=hover,
            pointer=pointer,
            media_type=media_type,
            custom=custom,
        )

        inner_rules: list[str] = []
        if selector is not None and style is not None:
            inner_rules.append(_render_rule(selector, Style.combine(style), indent="  "))

        if rules:
            inner_rules.extend(_indent_block(rule.strip()) for rule in rules if rule and rule.strip())

        if not inner_rules:
            return self

        block = "\n".join([f"@media {media_query} {{", *inner_rules, "}"])
        self._rules.append(block)
        return self

    def add_container(
        self,
        query: ContainerQuery | str | None = None,
        selector: object | None = None,
        style: Style | Mapping[str, object] | None = None,
        *,
        rules: Iterable[str] | None = None,
        name: str | None = None,
        min_width: str | None = None,
        max_width: str | None = None,
        min_height: str | None = None,
        max_height: str | None = None,
        orientation: str | None = None,
        custom: str | None = None,
    ) -> "StyleSheet":
        container_query = ContainerQuery.from_value(
            query,
            name=name,
            min_width=min_width,
            max_width=max_width,
            min_height=min_height,
            max_height=max_height,
            orientation=orientation,
            custom=custom,
        )

        inner_rules: list[str] = []
        if selector is not None and style is not None:
            inner_rules.append(_render_rule(selector, Style.combine(style), indent="  "))

        if rules:
            inner_rules.extend(_indent_block(rule.strip()) for rule in rules if rule and rule.strip())

        if not inner_rules:
            return self

        block = "\n".join([f"@container {container_query} {{", *inner_rules, "}"])
        self._rules.append(block)
        return self

    def add_supports(
        self,
        condition: str,
        selector: object | None = None,
        style: Style | Mapping[str, object] | None = None,
        *,
        rules: Iterable[str] | None = None,
    ) -> "StyleSheet":
        support_condition = _normalize_support_condition(condition)

        inner_rules: list[str] = []
        if selector is not None and style is not None:
            inner_rules.append(_render_rule(selector, Style.combine(style), indent="  "))

        if rules:
            inner_rules.extend(_indent_block(rule.strip()) for rule in rules if rule and rule.strip())

        if not inner_rules:
            return self

        block = "\n".join([f"@supports {support_condition} {{", *inner_rules, "}"])
        self._rules.append(block)
        return self

    def add_keyframes(self, name: str, frames: Mapping[str, Style | Mapping[str, object]]) -> "StyleSheet":
        lines = [f"@keyframes {name} {{"]
        for step, step_style in frames.items():
            style = Style.combine(step_style)
            lines.append(f"  {step} {{")
            for key, value in style.as_dict().items():
                lines.append(f"    {key}: {value};")
            lines.append("  }")
        lines.append("}")
        self._rules.append("\n".join(lines))
        return self

    def add_font_face(
        self,
        family: str,
        src: str,
        **properties: object,
    ) -> "StyleSheet":
        style = Style(font_family=f'"{family}"', src=src)
        style.update(properties)

        lines = ["@font-face {"]
        for key, value in style.as_dict().items():
            lines.append(f"  {key}: {value};")
        lines.append("}")

        self._rules.append("\n".join(lines))
        return self

    def add_layer(self, name: str | None = None, *rules: str) -> "StyleSheet":
        if not rules:
            if name:
                self._rules.append(f"@layer {name};")
            else:
                self._rules.append("@layer;")
            return self

        header = f"@layer {name}" if name else "@layer"
        inner = [_indent_block(rule.strip()) for rule in rules if rule and rule.strip()]
        block = "\n".join([f"{header} {{", *inner, "}"])
        self._rules.append(block)
        return self

    def add_layer_rule(self, layer_name: str, selector: object, style: Style | Mapping[str, object]) -> "StyleSheet":
        rule = _render_rule(selector, Style.combine(style))
        return self.add_layer(layer_name, rule)

    def add_property(
        self,
        name: str,
        *,
        syntax: str,
        inherits: bool,
        initial_value: object,
    ) -> "StyleSheet":
        property_name = _to_css_var_name(name)
        inherits_value = "true" if inherits else "false"

        lines = [
            f"@property {property_name} {{",
            f"  syntax: {syntax};",
            f"  inherits: {inherits_value};",
            f"  initial-value: {initial_value};",
            "}",
        ]
        self._rules.append("\n".join(lines))
        return self

    def add_page(self, style: Style | Mapping[str, object], selector: str | None = None) -> "StyleSheet":
        header = "@page" + (f" {selector.strip()}" if selector and selector.strip() else "")
        lines = [f"{header} {{"]
        normalized = Style.combine(style)
        for key, value in normalized.as_dict().items():
            lines.append(f"  {key}: {value};")
        lines.append("}")

        self._rules.append("\n".join(lines))
        return self

    def add_scope(
        self,
        root: object,
        selector: object | None = None,
        style: Style | Mapping[str, object] | None = None,
        *,
        rules: Iterable[str] | None = None,
        to: object | None = None,
    ) -> "StyleSheet":
        root_selector = _selector_text(root)
        to_part = f" to ({_selector_text(to)})" if to is not None else ""
        header = f"@scope ({root_selector}){to_part}"

        inner_rules: list[str] = []
        if selector is not None and style is not None:
            inner_rules.append(_render_rule(selector, Style.combine(style), indent="  "))

        if rules:
            inner_rules.extend(_indent_block(rule.strip()) for rule in rules if rule and rule.strip())

        if not inner_rules:
            return self

        block = "\n".join([f"{header} {{", *inner_rules, "}"])
        self._rules.append(block)
        return self

    def add_theme(self, theme: Theme, selector: object = ":root") -> "StyleSheet":
        css = theme.to_css(selector)
        if css:
            self._rules.append(css)
        return self

    def extend(self, other: "StyleSheet | str") -> "StyleSheet":
        if isinstance(other, StyleSheet):
            self._rules.extend(other._rules)
            return self
        return self.add_raw(str(other))

    def render(self) -> str:
        return "\n\n".join(rule for rule in self._rules if rule.strip())

    def __bool__(self) -> bool:
        return bool(self._rules)
