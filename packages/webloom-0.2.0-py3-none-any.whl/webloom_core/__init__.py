from .decorators import (
    component,
    memo_component,
    page_component,
    styled,
    with_stylesheets,
    with_themes,
)
from .element import Comment, Element, RawHTML, comment, raw_html
from .page import Page
from .selectors import Selector, sel
from .style import (
    DEFAULT_BREAKPOINTS,
    ContainerQuery,
    MediaQuery,
    ResponsiveStyle,
    Style,
    StyleSheet,
    Theme,
)
from . import tags as _tags
from .tags import *  # noqa: F401,F403
from .tags import __all__ as _tag_exports
from .version import __version__

__all__ = [
    "DEFAULT_BREAKPOINTS",
    "Comment",
    "ContainerQuery",
    "Element",
    "MediaQuery",
    "Page",
    "RawHTML",
    "ResponsiveStyle",
    "Selector",
    "Style",
    "StyleSheet",
    "Theme",
    "__version__",
    "comment",
    "component",
    "memo_component",
    "page_component",
    "raw_html",
    "sel",
    "styled",
    "with_stylesheets",
    "with_themes",
    *_tag_exports,
]


def __getattr__(name: str) -> object:
    value = getattr(_tags, name)
    globals()[name] = value
    if name not in __all__:
        __all__.append(name)
    return value
