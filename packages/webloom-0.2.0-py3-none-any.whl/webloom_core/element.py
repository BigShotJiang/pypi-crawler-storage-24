from __future__ import annotations

from html import escape
from typing import Any, Mapping

from .style import ResponsiveStyle, Style

_VOID_TAGS = {
    "area",
    "base",
    "br",
    "col",
    "embed",
    "hr",
    "img",
    "input",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr",
}

_RAW_TEXT_TAGS = {"script", "style"}


def _normalize_attr_name(key: str) -> str:
    if key == "class_":
        return "class"
    if key == "for_":
        return "for"
    return key.rstrip("_").replace("_", "-")


def _normalize_class_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple, set)):
        return " ".join(str(item).strip() for item in value if str(item).strip())
    return str(value).strip()


def _merge_class_value(existing: Any, appended: str) -> str:
    existing_value = _normalize_class_value(existing)
    appended_value = appended.strip()

    if not existing_value:
        return appended_value
    if not appended_value:
        return existing_value

    deduplicated: list[str] = []
    seen: set[str] = set()
    for token in (existing_value + " " + appended_value).split():
        if token not in seen:
            seen.add(token)
            deduplicated.append(token)
    return " ".join(deduplicated)


def _normalize_responsive(value: Any) -> ResponsiveStyle | None:
    if value is None:
        return None
    if isinstance(value, ResponsiveStyle):
        return value
    if isinstance(value, Mapping):
        keys = set(value.keys())
        advanced_keys = {"base", "breakpoints", "pseudos", "breakpoint_pseudos", "media", "media_pseudos"}
        if keys & advanced_keys:
            return ResponsiveStyle(
                base=value.get("base"),
                breakpoints=value.get("breakpoints"),
                pseudos=value.get("pseudos"),
                breakpoint_pseudos=value.get("breakpoint_pseudos"),
                media=value.get("media"),
                media_pseudos=value.get("media_pseudos"),
                supports=value.get("supports"),
                support_pseudos=value.get("support_pseudos"),
            )

        base = value.get("base")
        breakpoints = {k: v for k, v in value.items() if k != "base"}
        return ResponsiveStyle(base=base, breakpoints=breakpoints)

    raise TypeError("responsive must be ResponsiveStyle or mapping")


def _is_renderable_node(value: Any) -> bool:
    return hasattr(value, "render") and callable(getattr(value, "render"))


def _render_external_node(value: Any, pretty: bool, level: int) -> str:
    if not _is_renderable_node(value):
        return ""

    try:
        return value.render(pretty=pretty, level=level)
    except TypeError:
        rendered = value.render()
        if pretty:
            indent = "  " * level
            return "\n".join(indent + line if line else line for line in str(rendered).splitlines())
        return str(rendered)


class RawHTML:
    """Represents trusted raw HTML that should not be escaped."""

    def __init__(self, html: str) -> None:
        self.html = html

    def render(self, pretty: bool = True, level: int = 0) -> str:
        if not pretty:
            return self.html
        indent = "  " * level
        return "\n".join(indent + line if line else line for line in self.html.splitlines())

    def __str__(self) -> str:
        return self.html


class Comment:
    """HTML comment node."""

    def __init__(self, text: str) -> None:
        sanitized = str(text).replace("--", "- -")
        if sanitized.endswith("-"):
            sanitized += " "
        self.text = sanitized

    def render(self, pretty: bool = True, level: int = 0) -> str:
        indent = "  " * level if pretty else ""
        return f"{indent}<!-- {self.text} -->"

    def __str__(self) -> str:
        return self.render(pretty=False)


def raw_html(html: str) -> RawHTML:
    return RawHTML(html)


def comment(text: str) -> Comment:
    return Comment(text)


class Element:
    """Base HTML element class for Python-first page composition."""

    tag = "div"

    def __init__(
        self,
        *children: Any,
        style: Style | Mapping[str, object] | None = None,
        responsive: ResponsiveStyle | Mapping[str, object] | None = None,
        **attrs: Any,
    ) -> None:
        style_from_attrs = attrs.pop("style", None)
        responsive_from_attrs = attrs.pop("responsive", None)
        aria_attrs = attrs.pop("aria", None)
        data_attrs = attrs.pop("data", None)

        self.style = Style.combine(style_from_attrs, style)
        self.responsive = _normalize_responsive(responsive_from_attrs if responsive_from_attrs is not None else responsive)

        self.attrs: dict[str, Any] = {}
        for key, value in attrs.items():
            if value is None or value is False:
                continue
            self.attrs[_normalize_attr_name(key)] = value

        if self.responsive:
            self.attrs["class"] = _merge_class_value(self.attrs.get("class"), self.responsive.class_name)

        self.set_aria(aria_attrs)
        self.set_data(data_attrs)

        self.children: list[Any] = []
        for child in children:
            self._append_child(child)

    def merge_style(self, style: Style | Mapping[str, object] | None) -> "Element":
        if style is None:
            return self
        self.style = Style.combine(self.style, style)
        return self

    def merge_responsive(self, responsive: ResponsiveStyle | Mapping[str, object] | None) -> "Element":
        normalized = _normalize_responsive(responsive)
        if normalized is None:
            return self
        self.responsive = normalized
        self.attrs["class"] = _merge_class_value(self.attrs.get("class"), normalized.class_name)
        return self

    def set_aria(self, aria: Mapping[str, object] | None) -> "Element":
        if not aria:
            return self
        for key, value in aria.items():
            if value is None:
                continue
            self.attrs[f"aria-{_normalize_attr_name(str(key))}"] = value
        return self

    def set_data(self, data: Mapping[str, object] | None) -> "Element":
        if not data:
            return self
        for key, value in data.items():
            if value is None:
                continue
            self.attrs[f"data-{_normalize_attr_name(str(key))}"] = value
        return self

    def set_attrs(self, **attrs: Any) -> "Element":
        aria_attrs = attrs.pop("aria", None)
        data_attrs = attrs.pop("data", None)

        for key, value in attrs.items():
            normalized_name = _normalize_attr_name(key)
            if normalized_name == "class":
                self.attrs["class"] = _merge_class_value(self.attrs.get("class"), _normalize_class_value(value))
                continue
            if value is None or value is False:
                self.attrs.pop(normalized_name, None)
                continue
            self.attrs[normalized_name] = value

        self.set_aria(aria_attrs)
        self.set_data(data_attrs)
        return self

    def _append_child(self, child: Any) -> None:
        if child is None:
            return
        if isinstance(child, (list, tuple)):
            for nested in child:
                self._append_child(nested)
            return
        self.children.append(child)

    def collect_responsive_styles(self) -> list[ResponsiveStyle]:
        styles: list[ResponsiveStyle] = []
        if self.responsive:
            styles.append(self.responsive)

        for child in self.children:
            if isinstance(child, Element):
                styles.extend(child.collect_responsive_styles())

        return styles

    def _render_attrs(self) -> str:
        attrs = dict(self.attrs)
        if self.style:
            inline_style = self.style.to_inline()
            if inline_style:
                attrs["style"] = inline_style

        if not attrs:
            return ""

        rendered: list[str] = []
        for name, value in attrs.items():
            if value is True:
                rendered.append(name)
                continue
            rendered.append(f'{name}="{escape(str(value), quote=True)}"')
        return " " + " ".join(rendered)

    def _render_child(self, child: Any, pretty: bool, level: int) -> str:
        if isinstance(child, Element):
            return child.render(pretty=pretty, level=level)

        if _is_renderable_node(child):
            return _render_external_node(child, pretty=pretty, level=level)

        return ("  " * level if pretty else "") + escape(str(child))

    def render(self, pretty: bool = True, level: int = 0) -> str:
        indent = "  " * level if pretty else ""
        attrs = self._render_attrs()

        if self.tag in _VOID_TAGS:
            return f"{indent}<{self.tag}{attrs}>"

        if not self.children:
            return f"{indent}<{self.tag}{attrs}></{self.tag}>"

        text_only = all(not isinstance(child, Element) and not _is_renderable_node(child) for child in self.children)

        if text_only:
            if self.tag in _RAW_TEXT_TAGS:
                text = "".join(str(child) for child in self.children)
            else:
                text = "".join(escape(str(child)) for child in self.children)
            return f"{indent}<{self.tag}{attrs}>{text}</{self.tag}>"

        if pretty:
            lines = [f"{indent}<{self.tag}{attrs}>"]
            for child in self.children:
                lines.append(self._render_child(child, pretty=True, level=level + 1))
            lines.append(f"{indent}</{self.tag}>")
            return "\n".join(lines)

        compact_children = "".join(self._render_child(child, pretty=False, level=0) for child in self.children)
        return f"<{self.tag}{attrs}>{compact_children}</{self.tag}>"

    def __str__(self) -> str:
        return self.render(pretty=False)