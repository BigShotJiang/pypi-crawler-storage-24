from __future__ import annotations

import re

_PSEUDO_ELEMENTS = {
    "after",
    "before",
    "first-letter",
    "first-line",
    "marker",
    "placeholder",
    "selection",
    "backdrop",
}


def _normalize_pseudo(name: str) -> str:
    cleaned = name.strip().replace("_", "-")
    if not cleaned:
        raise ValueError("Pseudo selector cannot be empty")

    raw = cleaned.lstrip(":")
    prefix = "::" if raw in _PSEUDO_ELEMENTS else ":"
    return f"{prefix}{raw}"


def _selector_text(value: object) -> str:
    text = str(value).strip()
    if not text:
        raise ValueError("Selector value cannot be empty")
    return text


def _class_name(name: str) -> str:
    return re.sub(r"\s+", "-", name.strip())


class Selector:
    """Composable CSS selector builder."""

    def __init__(self, value: object) -> None:
        self._value = _selector_text(value)

    @classmethod
    def tag(cls, name: str) -> "Selector":
        return cls(name)

    @classmethod
    def cls(cls, name: str) -> "Selector":
        return cls(f".{_class_name(name)}")

    @classmethod
    def id(cls, name: str) -> "Selector":
        return cls(f"#{_class_name(name)}")

    def descendant(self, selector: object) -> "Selector":
        return Selector(f"{self._value} {_selector_text(selector)}")

    def child(self, selector: object) -> "Selector":
        return Selector(f"{self._value} > {_selector_text(selector)}")

    def adjacent(self, selector: object) -> "Selector":
        return Selector(f"{self._value} + {_selector_text(selector)}")

    def sibling(self, selector: object) -> "Selector":
        return Selector(f"{self._value} ~ {_selector_text(selector)}")

    def class_(self, name: str) -> "Selector":
        return Selector(f"{self._value}.{_class_name(name)}")

    def id_(self, name: str) -> "Selector":
        return Selector(f"{self._value}#{_class_name(name)}")

    def attr(self, name: str, value: object | None = None, operator: str = "=") -> "Selector":
        attr_name = name.strip().replace("_", "-")
        if value is None:
            return Selector(f"{self._value}[{attr_name}]")
        return Selector(f"{self._value}[{attr_name}{operator}\"{value}\"]")

    def pseudo(self, name: str) -> "Selector":
        return Selector(f"{self._value}{_normalize_pseudo(name)}")

    def pseudo_element(self, name: str) -> "Selector":
        cleaned = name.strip().replace("_", "-").lstrip(":")
        if not cleaned:
            raise ValueError("Pseudo-element name cannot be empty")
        return Selector(f"{self._value}::{cleaned}")

    def where(self, selector: object) -> "Selector":
        return Selector(f"{self._value}:where({_selector_text(selector)})")

    def is_(self, selector: object) -> "Selector":
        return Selector(f"{self._value}:is({_selector_text(selector)})")

    def not_(self, selector: object) -> "Selector":
        return Selector(f"{self._value}:not({_selector_text(selector)})")

    def has(self, selector: object) -> "Selector":
        return Selector(f"{self._value}:has({_selector_text(selector)})")

    def hover(self) -> "Selector":
        return self.pseudo("hover")

    def focus(self) -> "Selector":
        return self.pseudo("focus")

    def focus_visible(self) -> "Selector":
        return self.pseudo("focus-visible")

    def active(self) -> "Selector":
        return self.pseudo("active")

    def visited(self) -> "Selector":
        return self.pseudo("visited")

    def before(self) -> "Selector":
        return self.pseudo_element("before")

    def after(self) -> "Selector":
        return self.pseudo_element("after")

    def __str__(self) -> str:
        return self._value

    def __repr__(self) -> str:
        return f"Selector({self._value!r})"


def sel(value: object) -> Selector:
    return Selector(value)


__all__ = ["Selector", "sel"]