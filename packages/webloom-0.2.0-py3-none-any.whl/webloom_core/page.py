from __future__ import annotations

from pathlib import Path
from typing import Iterable, Mapping

from .element import Element
from .style import DEFAULT_BREAKPOINTS, ResponsiveStyle, Style, StyleSheet, Theme
from .tags import Body, Head, Html, Link, Meta, StyleTag, Title


class Page:
    """HTML document wrapper with runtime CSS composition controls."""

    def __init__(
        self,
        title: str,
        *body_children: object,
        lang: str = "en",
        body_style: Style | Mapping[str, object] | None = None,
        head_elements: Iterable[Element] | None = None,
        breakpoints: Mapping[str, str] | None = None,
        stylesheets: Iterable[StyleSheet | str] | None = None,
        themes: Theme | Mapping[str, object] | Iterable[Theme | Mapping[str, object]] | None = None,
        inline_css: bool = True,
        css_output_path: str | Path | None = None,
        css_href: str | None = None,
    ) -> None:
        self.title = title
        self.lang = lang
        self.body_children = body_children
        self.body_style = body_style
        self.head_elements = list(head_elements or [])
        self.stylesheets = list(stylesheets or [])
        self.inline_css = inline_css
        self.css_output_path = Path(css_output_path) if css_output_path else None
        self.css_href = css_href

        self.breakpoints = dict(DEFAULT_BREAKPOINTS)
        if breakpoints:
            self.breakpoints.update({str(k): str(v) for k, v in breakpoints.items()})

        self.themes: list[Theme] = self._normalize_themes(themes)

    def _normalize_themes(
        self,
        themes: Theme | Mapping[str, object] | Iterable[Theme | Mapping[str, object]] | None,
    ) -> list[Theme]:
        if themes is None:
            return []

        if isinstance(themes, Theme):
            return [themes]

        if isinstance(themes, Mapping):
            return [Theme(tokens=themes)]

        normalized: list[Theme] = []
        for item in themes:
            if isinstance(item, Theme):
                normalized.append(item)
            elif isinstance(item, Mapping):
                normalized.append(Theme(tokens=item))
            else:
                raise TypeError("themes items must be Theme or mapping")

        return normalized

    def _collect_responsive_styles(self) -> list[ResponsiveStyle]:
        deduplicated: dict[str, ResponsiveStyle] = {}
        for node in self.body_children:
            if not isinstance(node, Element):
                continue
            for style in node.collect_responsive_styles():
                deduplicated[style.class_name] = style
        return list(deduplicated.values())

    def _build_responsive_css(self, styles: list[ResponsiveStyle]) -> str:
        blocks: list[str] = []
        for style in styles:
            css = style.to_css(self.breakpoints)
            if css:
                blocks.append(css)
        return "\n\n".join(blocks)

    def _build_stylesheet_css(self) -> str:
        blocks: list[str] = []
        for stylesheet in self.stylesheets:
            if isinstance(stylesheet, StyleSheet):
                css = stylesheet.render()
            else:
                css = str(stylesheet).strip()
            if css:
                blocks.append(css)
        return "\n\n".join(blocks)

    def _build_theme_css(self) -> str:
        blocks = [theme.to_css() for theme in self.themes if theme]
        return "\n\n".join(block for block in blocks if block.strip())

    def _build_css(self) -> str:
        responsive_styles = self._collect_responsive_styles()
        responsive_css = self._build_responsive_css(responsive_styles)
        stylesheet_css = self._build_stylesheet_css()
        theme_css = self._build_theme_css()

        return "\n\n".join(block for block in (theme_css, responsive_css, stylesheet_css) if block.strip())

    def _write_css_file(self, css: str) -> None:
        if not self.css_output_path:
            return
        self.css_output_path.parent.mkdir(parents=True, exist_ok=True)
        self.css_output_path.write_text(css, encoding="utf-8")

    def render(self, pretty: bool = True) -> str:
        css = self._build_css()

        if css and self.css_output_path:
            self._write_css_file(css)

        head_nodes: list[Element] = [
            Meta(charset="utf-8"),
            Meta(name="viewport", content="width=device-width, initial-scale=1"),
            Title(self.title),
        ]

        if css and self.css_href:
            head_nodes.append(Link(rel="stylesheet", href=self.css_href))

        if css and self.inline_css:
            head_nodes.append(StyleTag(css))

        head_nodes.extend(self.head_elements)

        head = Head(*head_nodes)
        body = Body(*self.body_children, style=self.body_style)
        html = Html(head, body, lang=self.lang)

        doctype = "<!doctype html>"
        document = html.render(pretty=pretty)
        return f"{doctype}\n{document}" if pretty else doctype + document