from __future__ import annotations

from typing import Any

from django.http import HttpRequest, HttpResponse
from django.views import View


def render_to_html(node: Any, pretty: bool = True) -> str:
    if hasattr(node, "render") and callable(node.render):
        try:
            return node.render(pretty=pretty)
        except TypeError:
            return node.render()
    return str(node)


class WebloomPageView(View):
    """Base class for rendering Webloom pages in Django."""

    pretty = True

    def get_page(self, request: HttpRequest, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError("Implement get_page() in subclasses.")

    def get(self, request: HttpRequest, *args: Any, **kwargs: Any) -> HttpResponse:
        page = self.get_page(request, *args, **kwargs)
        html = render_to_html(page, pretty=self.pretty)
        return HttpResponse(html, content_type="text/html; charset=utf-8")