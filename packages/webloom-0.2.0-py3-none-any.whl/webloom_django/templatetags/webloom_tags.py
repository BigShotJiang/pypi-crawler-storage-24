from __future__ import annotations

from typing import Any

from django import template
from django.utils.safestring import mark_safe

from webloom_django.views import render_to_html

register = template.Library()


@register.simple_tag(takes_context=True)
def render_webloom(context: template.Context, component: Any, pretty: bool = False) -> str:
    if callable(component):
        request = context.get("request")
        try:
            component = component(request)
        except TypeError:
            component = component()
    return mark_safe(render_to_html(component, pretty=pretty))