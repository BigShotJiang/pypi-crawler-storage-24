from django.apps import AppConfig


class WebloomDjangoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "webloom_django"
    verbose_name = "Webloom Django Integration"