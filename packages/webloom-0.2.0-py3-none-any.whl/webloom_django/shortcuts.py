﻿from __future__ import annotations

from typing import Any

from django.http import HttpResponse

from .views import render_to_html


def render_page_response(page: Any, *, pretty: bool = True, status: int = 200) -> HttpResponse:
    html = render_to_html(page, pretty=pretty)
    return HttpResponse(html, content_type="text/html; charset=utf-8", status=status)
