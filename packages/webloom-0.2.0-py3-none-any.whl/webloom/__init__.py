from webloom_core import *  # noqa: F401,F403
import webloom_core as _core
from webloom_core import __version__


def __getattr__(name: str) -> object:
    value = getattr(_core, name)
    globals()[name] = value
    return value
