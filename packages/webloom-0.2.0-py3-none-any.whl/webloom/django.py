try:
    from webloom_django.shortcuts import render_page_response
    from webloom_django.views import WebloomPageView, render_to_html
except ModuleNotFoundError as exc:
    if exc.name and exc.name.startswith("django"):
        raise ImportError(
            "Django integration is optional. Install it with: pip install \"webloom[django]\""
        ) from exc
    raise

__all__ = ["WebloomPageView", "render_page_response", "render_to_html"]
