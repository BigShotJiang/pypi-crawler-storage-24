# Pydantic ACP

silence is golden.