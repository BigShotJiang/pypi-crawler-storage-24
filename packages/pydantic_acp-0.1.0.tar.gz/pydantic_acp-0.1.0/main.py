def main():
    print("Hello from pydantic-acp!")


if __name__ == "__main__":
    main()
