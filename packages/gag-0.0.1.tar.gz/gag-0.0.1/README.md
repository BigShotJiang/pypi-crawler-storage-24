# gag

This is a **namespace package** repository for the GAG (Git/Github Agentic) tool suite.

## Purpose
This package serves as the top-level namespace for various tools, such as:
- `gag-repo-viewer` (installed as `gag.repo_viewer`)

## Installation
Currently, this package is a placeholder. Please install specific tools from the GAG suite directly.

```bash
pip install gag-repo-viewer
```
