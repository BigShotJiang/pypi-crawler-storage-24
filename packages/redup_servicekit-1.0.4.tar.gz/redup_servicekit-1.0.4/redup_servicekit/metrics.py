"""Prometheus metrics registry and bucket/aggregation constants.

The :mod:`redup_servicekit.metrics` module contains:

- :data:`redup_servicekit.metrics.PROMETHEUS_METRICS_REGISTRY` — singleton registry for metrics
- :data:`redup_servicekit.metrics.OPERATION_EXPAND_METRICS` — aggregation name to function
- :data:`redup_servicekit.metrics.BUCKETS_HIST` — histogram bucket boundaries for time/size
"""


class _MetricsRegistry(dict):
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance


PROMETHEUS_METRICS_REGISTRY = _MetricsRegistry()

OPERATION_EXPAND_METRICS = {
    "sum": sum,
    "max": lambda x: max(x) if x else 0.0,
    "len": len,
    "mean": lambda x: sum(x) / len(x),
}

BUCKETS_HIST = {
    "time": [
        0.01,
        0.02,
        0.03,
        0.05,
        0.1,
        0.5,
        1.0,
        1.5,
        2.0,
        2.5,
        3.0,
        3.5,
        4.0,
        4.5,
        5.0,
        6.0,
        7.0,
        8.0,
        9.0,
        10.0,
        15.0,
        20.0,
        25.0,
        30.0,
        35.0,
        40.0,
        45.0,
        50.0,
        55.0,
        60.0,
        90.0,
        120.0,
        180.0,
        240.0,
        270.0,
        300.0,
        360.0,
        420.0,
        480.0,
        540.0,
        600.0,
        900.0,
        1200.0,
        1500.0,
        1800.0,
        3600.0,
        "INF",
    ],
    "size": [
        1.0,
        5.0,
        10.0,
        20.0,
        50.0,
        100.0,
        500.0,
        1000.0,
        5000.0,
        10000.0,
        15000.0,
        30000.0,
        150000.0,
        300000.0,
        450000.0,
        600000.0,
        750000.0,
        900000.0,
        1050000.0,
        1200000.0,
        1350000.0,
        1500000.0,
        1800000.0,
        2100000.0,
        2400000.0,
        2700000.0,
        3000000.0,
        3750000.0,
        4500000.0,
        6000000.0,
        7500000.0,
        9000000.0,
        10500000.0,
        12000000.0,
        13500000.0,
        15000000.0,
        17500000.0,
        20000000.0,
        25000000.0,
        35000000.0,
        50000000.0,
        65000000.0,
        80000000.0,
        100000000.0,
        120000000.0,
        140000000.0,
        160000000.0,
        200000000.0,
        260000000.0,
        360000000.0,
        500000000.0,
        750000000.0,
        1000000000.0,
        2000000000.0,
        "INF",
    ],
}
