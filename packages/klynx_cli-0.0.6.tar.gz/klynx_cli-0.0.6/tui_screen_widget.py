"""Readonly TextArea used to render live TUI session screen content."""

from textual.widgets import TextArea


class TUIScreenWidget(TextArea):
    """Render a textual snapshot from a TUI session."""

    DEFAULT_CSS = """
    TUIScreenWidget {
        border: solid $secondary;
        height: 100%;
    }
    """

    def __init__(self, **kwargs):
        kwargs["read_only"] = True
        kwargs["show_line_numbers"] = False
        super().__init__(**kwargs)
        self.session_name = ""
        self.can_focus = True

    def update_screen(self, name: str, lines: list, cursor_row: int, cursor_col: int):
        """Update the screen content if it has changed."""
        if not self.selection.is_empty:
            return

        current_state = (name, lines, cursor_row, cursor_col)
        if getattr(self, "_last_state", None) == current_state:
            return
        self._last_state = current_state
        self.session_name = name

        line_width = 68
        title = f" {self.session_name} "
        header = f"{'=' * line_width}\n{title}\n{'=' * line_width}"
        body = "\n".join(lines)
        footer = f"{'=' * line_width}\nCursor: ({cursor_row}, {cursor_col})"
        full_text = f"{header}\n{body}\n{footer}"

        self.replace(
            full_text,
            start=(0, 0),
            end=self.document.end,
            maintain_selection_offset=False,
        )

        target_row = cursor_row + 3  # Header consumes 3 lines.
        try:
            if self.selection.is_empty:
                self.cursor_location = (target_row, cursor_col)
                self.scroll_cursor_visible()
        except Exception:
            pass
