"""Context-aware suggester for command, file, and skill completion."""

from __future__ import annotations

import os
from typing import Optional

from textual.suggester import Suggester

from .command_specs import slash_suggestions


class ContextAwareSuggester(Suggester):
    """Provide slash-command, file, and skill suggestions."""

    def __init__(self, app_instance):
        super().__init__(use_cache=False)
        self.app_instance = app_instance
        self.default_commands = slash_suggestions()

    def _get_commands(self):
        if hasattr(self.app_instance, 'get_command_suggestions'):
            try:
                dynamic = self.app_instance.get_command_suggestions()
                if dynamic:
                    return dynamic
            except Exception:
                pass
        if hasattr(self.app_instance, 'command_registry'):
            try:
                dynamic = self.app_instance.command_registry.command_suggestions()
                if dynamic:
                    return dynamic
            except Exception:
                pass
        return self.default_commands

    async def get_suggestion(self, value: str) -> Optional[str]:
        if not value:
            return None

        tokens = value.split(' ')
        last_token = tokens[-1]

        if len(tokens) == 1 and last_token.startswith('/'):
            commands = self._get_commands()
            matches = [cmd for cmd in commands if cmd.startswith(last_token) and cmd != last_token]
            if matches:
                return min(matches, key=len)

        if last_token.startswith('@'):
            prefix = last_token[1:]
            try:
                folder = os.path.dirname(prefix)
                base = os.path.basename(prefix)
                search_dir = os.path.join(os.getcwd(), folder)
                if os.path.isdir(search_dir):
                    for name in os.listdir(search_dir):
                        if name.startswith(base):
                            suggestion = '@' + os.path.join(folder, name).replace('\\', '/')
                            if os.path.isdir(os.path.join(search_dir, name)):
                                suggestion += '/'
                            return ' '.join(tokens[:-1] + [suggestion])
            except Exception:
                pass

        if last_token.startswith('$'):
            prefix = last_token[1:].strip().lower()
            try:
                skill_names = self.app_instance.get_skill_names()
            except Exception:
                skill_names = []

            if skill_names:
                matches = [name for name in skill_names if name.lower().startswith(prefix)]
                if matches:
                    suggestion = '$' + sorted(matches)[0]
                    return ' '.join(tokens[:-1] + [suggestion])

        return None

