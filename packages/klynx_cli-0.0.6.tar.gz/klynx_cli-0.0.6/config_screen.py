"""Model and API key configuration screen for the TUI app."""

import os

from dotenv import set_key
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Log as RichLog, Select

from .env import resolve_env_file


class ConfigScreen(Screen):
    """Interactive configuration form for model and API keys."""

    def compose(self) -> ComposeResult:
        with Vertical(id="config-dialog"):
            yield Label("Model & API Key Configuration", id="config-title")

            from klynx.model.registry import MODEL_REGISTRY

            options = [(config["description"], alias) for alias, config in MODEL_REGISTRY.items()]
            options.append(("Other (Custom)", "__other__"))

            yield Label("Provider / Preset Model:")
            yield Select(options, id="model-provider", prompt="Select a model...")

            with Vertical(id="custom-model-container"):
                yield Label("Custom provider (for example: openai):")
                yield Input(placeholder="Model Provider", id="custom-provider")
                yield Label("Custom model name (for example: gpt-4o):")
                yield Input(placeholder="Model Name", id="custom-model")

            yield Label("API Key:")
            yield Input(placeholder="API Key", password=True, id="api-key")
            yield Label("Tavily API Key (optional, for web search):")
            yield Input(placeholder="Tavily API Key", password=True, id="tavily-api-key")

            with Horizontal(id="config-buttons"):
                yield Button("Save and Reload", id="btn-save", variant="primary")
                yield Button("Cancel", id="btn-cancel")

    def on_mount(self) -> None:
        select = self.query_one("#model-provider", Select)
        container = self.query_one("#custom-model-container")
        container.display = False

        found = False
        if self.app.model_provider:
            for _, value in select._options:
                if value == self.app.model_provider:
                    select.value = value
                    found = True
                    break

        if not found and self.app.model_provider:
            select.value = "__other__"
            self.query_one("#custom-provider").value = self.app.model_provider
            self.query_one("#custom-model").value = self.app.model_name or ""
            self.query_one("#api-key").value = self.app.api_key or ""
            container.display = True

        tavily_key = self.app.tavily_api_key or os.environ.get("TAVILY_API_KEY", "")
        self.query_one("#tavily-api-key").value = tavily_key

        self.set_timer(0.1, self._fill_api_key_for_current_selection)

    def _fill_api_key_for_current_selection(self) -> None:
        select = self.query_one("#model-provider", Select)
        if select.value and select.value != Select.BLANK:
            self._update_api_key_input(select.value)
        self.query_one("#api-key").focus()

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select.id != "model-provider":
            return

        container = self.query_one("#custom-model-container")
        if event.value == "__other__":
            container.display = True
            # Keep current key in custom mode to avoid accidental clearing.
            self.query_one("#api-key").value = self.app.api_key or ""
            return

        if event.value and event.value != Select.BLANK:
            container.display = False
            self._update_api_key_input(event.value)
            return

        container.display = False
        self.query_one("#api-key").value = ""

    def _update_api_key_input(self, alias: str) -> None:
        from klynx.model.registry import MODEL_REGISTRY

        config = MODEL_REGISTRY.get(alias)
        if not config:
            return

        env_keys = config.get("env_key")
        api_key = ""
        if isinstance(env_keys, list):
            for key in env_keys:
                api_key = os.environ.get(key)
                if api_key:
                    break
        elif env_keys:
            api_key = os.environ.get(env_keys, "")
        self.query_one("#api-key").value = api_key or ""

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-cancel":
            self.app.pop_screen()
            return

        if event.button.id != "btn-save":
            return

        provider_select = self.query_one("#model-provider", Select).value

        if provider_select == "__other__":
            provider = self.query_one("#custom-provider").value.strip()
            name = self.query_one("#custom-model").value.strip()
            if not provider or not name:
                self.app.query_one("#agent-log", RichLog).write(
                    "[error] Custom model requires both provider and model name."
                )
                return
        else:
            provider = str(provider_select) if provider_select and provider_select != Select.BLANK else ""
            name = ""

        api_key = self.query_one("#api-key").value.strip()
        tavily_key = self.query_one("#tavily-api-key").value.strip()

        if not provider:
            return

        env_file = resolve_env_file()
        if not os.path.exists(env_file):
            with open(env_file, "a", encoding="utf-8"):
                pass

        from klynx.model.registry import MODEL_REGISTRY

        env_key = None
        if name in MODEL_REGISTRY:
            env_keys = MODEL_REGISTRY[name].get("env_key")
            if isinstance(env_keys, list):
                env_key = env_keys[0]
            elif env_keys:
                env_key = env_keys
        elif provider in MODEL_REGISTRY:
            env_keys = MODEL_REGISTRY[provider].get("env_key")
            if isinstance(env_keys, list):
                env_key = env_keys[0]
            elif env_keys:
                env_key = env_keys
        if not env_key:
            env_key = f"{provider.upper().replace('/', '_')}_API_KEY"

        # Empty API key is allowed; setup_model will fallback to environment variables.
        if api_key:
            set_key(env_file, env_key, api_key, quote_mode="never")
            os.environ[env_key] = api_key

        set_key(env_file, "KLYNX_DEFAULT_PROVIDER", provider, quote_mode="never")
        os.environ["KLYNX_DEFAULT_PROVIDER"] = provider

        if name:
            set_key(env_file, "KLYNX_DEFAULT_MODEL", name, quote_mode="never")
            os.environ["KLYNX_DEFAULT_MODEL"] = name
        else:
            set_key(env_file, "KLYNX_DEFAULT_MODEL", "", quote_mode="never")
            os.environ["KLYNX_DEFAULT_MODEL"] = ""

        if tavily_key:
            set_key(env_file, "TAVILY_API_KEY", tavily_key, quote_mode="never")
            os.environ["TAVILY_API_KEY"] = tavily_key
            self.app.tavily_api_key = tavily_key

        self.app.model_provider = provider
        self.app.model_name = name if name else None
        self.app.api_key = api_key if api_key else None

        self.app.pop_screen()
        self.app._init_agent()
