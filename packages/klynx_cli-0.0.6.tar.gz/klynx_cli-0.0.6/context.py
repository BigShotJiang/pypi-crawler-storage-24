from __future__ import annotations

import logging
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

from .config import ConfigSourceStatus, ResolvedConfig, inspect_config_sources, load_resolved_config
from .session import SessionManager

LOG_LEVEL_NAMES = ('CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG')


@dataclass
class CliLoggingState:
    level_name: str
    print_logs: bool
    log_path: Path


@dataclass
class CliContext:
    resolved: ResolvedConfig
    session_manager: SessionManager
    config_sources: List[ConfigSourceStatus]
    logging: CliLoggingState
    logger: logging.Logger


def _coerce_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value or '').strip().lower()
    return text in {'1', 'true', 'yes', 'on'}


def _resolve_logging_state(
    resolved: ResolvedConfig,
    *,
    log_level: Optional[str] = None,
    print_logs: Optional[bool] = None,
) -> CliLoggingState:
    configured_level = str(resolved.cli_log_level or 'INFO').strip().upper() or 'INFO'
    if configured_level not in LOG_LEVEL_NAMES:
        configured_level = 'INFO'
    effective_level = str(log_level or configured_level).strip().upper() or configured_level
    if effective_level not in LOG_LEVEL_NAMES:
        effective_level = configured_level

    effective_print = resolved.cli_print_logs
    if print_logs is not None:
        effective_print = bool(print_logs)
    log_path = resolved.paths.home_dir / 'logs' / 'klynx-cli.log'
    return CliLoggingState(level_name=effective_level, print_logs=_coerce_bool(effective_print), log_path=log_path)


def configure_cli_logging(
    resolved: ResolvedConfig,
    *,
    log_level: Optional[str] = None,
    print_logs: Optional[bool] = None,
) -> CliLoggingState:
    state = _resolve_logging_state(resolved, log_level=log_level, print_logs=print_logs)
    state.log_path.parent.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    for handler in list(root_logger.handlers):
        if getattr(handler, '_klynx_cli_managed', False):
            root_logger.removeHandler(handler)
            try:
                handler.close()
            except Exception:
                pass

    formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    handlers = []

    file_handler = logging.FileHandler(state.log_path, encoding='utf-8')
    file_handler.setFormatter(formatter)
    file_handler._klynx_cli_managed = True  # type: ignore[attr-defined]
    handlers.append(file_handler)

    if state.print_logs:
        stream_handler = logging.StreamHandler(sys.stderr)
        stream_handler.setFormatter(formatter)
        stream_handler._klynx_cli_managed = True  # type: ignore[attr-defined]
        handlers.append(stream_handler)

    root_logger.setLevel(getattr(logging, state.level_name, logging.INFO))
    for handler in handlers:
        root_logger.addHandler(handler)
    return state


def build_cli_context(
    *,
    cwd: Optional[str] = None,
    overrides: Optional[Iterable[str]] = None,
    log_level: Optional[str] = None,
    print_logs: Optional[bool] = None,
) -> CliContext:
    resolved = load_resolved_config(cwd, overrides=overrides)
    logging_state = configure_cli_logging(resolved, log_level=log_level, print_logs=print_logs)
    logger = logging.getLogger('klynx_cli')
    sources = inspect_config_sources(str(resolved.cwd))
    session_manager = SessionManager(str(resolved.cwd))

    logger.info(
        'Resolved CLI context cwd=%s model=%s/%s session_root=%s log_path=%s',
        resolved.cwd,
        resolved.model_provider,
        resolved.model_name,
        resolved.paths.session_root,
        logging_state.log_path,
    )
    for source in sources:
        if source.exists and not source.valid:
            logger.warning('Invalid config source %s at %s: %s', source.name, source.path, source.error)

    return CliContext(
        resolved=resolved,
        session_manager=session_manager,
        config_sources=sources,
        logging=logging_state,
        logger=logger,
    )

