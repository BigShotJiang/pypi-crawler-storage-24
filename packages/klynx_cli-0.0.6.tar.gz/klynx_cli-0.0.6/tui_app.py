"""Compatibility entrypoint that delegates to the unified Klynx CLI."""

from pathlib import Path
import sys


def _bootstrap_import_paths() -> None:
    root_dir = Path(__file__).resolve().parent.parent
    source_lib_dir = root_dir / "libs" / "klynx"
    for path in (root_dir, source_lib_dir):
        text = str(path)
        if path.exists() and text not in sys.path:
            sys.path.insert(0, text)


if __package__ in (None, ""):
    _bootstrap_import_paths()


def main() -> None:
    from klynx_cli.main import main as cli_main

    cli_main(sys.argv[1:])


if __name__ == "__main__":
    main()
