"""Stdout redirector for optionally forwarding raw prints into the TUI log."""

from __future__ import annotations

import io
from typing import Optional

from textual.widgets import Log as RichLog


class StdoutRedirector(io.TextIOBase):
    def __init__(self, app: "KlynxTUIApp", original_stdout, *, enabled: Optional[bool] = None):
        self.app = app
        self.original = original_stdout
        if enabled is None:
            output_config = getattr(getattr(app, "tui_config", None), "output", None)
            enabled = bool(getattr(output_config, "show_raw_stdout", False))
        self.enabled = bool(enabled)
        self._buffer = ""

    def write(self, text: str) -> int:
        if not text:
            return 0
        if not self.enabled:
            return len(text)

        self._buffer += text
        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            if not line.strip():
                continue
            try:
                self.app.call_from_thread(self._write_to_log, line)
            except Exception:
                pass
        return len(text)

    def _write_to_log(self, line: str) -> None:
        try:
            log_widget = self.app.query_one("#agent-log", RichLog)
            log_widget.write(line)
        except Exception:
            pass

    def flush(self) -> None:
        if not self.enabled:
            self._buffer = ""
            return
        if self._buffer.strip():
            try:
                self.app.call_from_thread(self._write_to_log, self._buffer.strip())
            except Exception:
                pass
        self._buffer = ""
