"""Environment helpers for Klynx TUI app."""

from __future__ import annotations

import os
from typing import Optional

from .config import load_env_files, resolve_paths


def resolve_env_file(cwd: Optional[str] = None) -> str:
    """Return the workspace-local env file path used for project overrides."""
    paths = resolve_paths(cwd or os.getcwd())
    paths.project_env.parent.mkdir(parents=True, exist_ok=True)
    return str(paths.project_env)


def load_workspace_env(cwd: Optional[str] = None) -> str:
    """Load global then project env files, returning the project env path."""
    env_file = resolve_env_file(cwd)
    load_env_files(cwd or os.getcwd())
    return env_file
