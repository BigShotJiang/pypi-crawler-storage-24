"""Configurable agent provider for TUI app."""

from __future__ import annotations

from dataclasses import dataclass, field
import importlib
from typing import Any, Callable, Dict, List, Mapping, Optional

from klynx.agent.graph import create_agent
from klynx.agent.tools.web_search import set_tavily_api
from klynx.model import setup as setup_model

from .adapters import CliAgentAdapter, CliAgentCapabilities, wrap_backend
from .config import TUIConfig


@dataclass
class CliRuntimeContext:
    working_dir: str
    model_provider: str
    model_name: Optional[str]
    api_key: Optional[str]
    tavily_api_key: Optional[str]
    model_kwargs: Dict[str, Any] = field(default_factory=dict)
    max_iterations: Optional[int] = None
    memory_dir: str = ""
    load_project_docs: bool = False
    checkpointer: Optional[Any] = None
    store: Optional[Any] = None
    allow_shell_commands: Optional[bool] = None
    tool_virtual_root: str = ""
    additional_dirs: List[str] = field(default_factory=list)
    set_layout_mode: Optional[Callable[[str], str]] = None
    tui_screen_update_callback: Optional[Callable[..., None]] = None


RuntimeContext = CliRuntimeContext


@dataclass
class AgentBuildResult:
    agent: CliAgentAdapter
    selected_model: str
    warnings: List[str] = field(default_factory=list)


_CAPABILITY_DEFAULTS = CliAgentCapabilities()


def validate_agent_contract(agent: Any) -> None:
    required = ("invoke", "get_context", "compact_context", "add_tools")
    for name in required:
        if not callable(getattr(agent, name, None)):
            raise ValueError(f"agent missing required method: {name}")


def _normalize_layout_mode_alias(value: str) -> str:
    text = str(value or "").strip().lower()
    if text == "full":
        return "chat"
    if text == "focus":
        return "focus_tui"
    return text


def _add_layout_tool(agent: CliAgentAdapter, runtime: CliRuntimeContext) -> Optional[str]:
    if runtime.set_layout_mode is None:
        return None
    capabilities = getattr(agent, "capabilities", _CAPABILITY_DEFAULTS)
    if not getattr(capabilities, "supports_tools_mutation", False):
        return "Selected backend does not support dynamic tool injection, so set_tui_layout was skipped."

    def set_tui_layout(mode: str = None, layout: str = None, input: str = None, **kwargs) -> str:
        target_mode = mode
        if not target_mode:
            content = input or layout or kwargs.get("value") or ""
            lowered = str(content).lower()
            if "focus_tui" in lowered or "focus tui" in lowered:
                target_mode = "focus_tui"
            elif "inspect" in lowered:
                target_mode = "inspect"
            elif "split" in lowered:
                target_mode = "split"
            elif "chat" in lowered or "full" in lowered:
                target_mode = "chat"
        target_mode = _normalize_layout_mode_alias(str(target_mode or ""))
        if not target_mode:
            return "Error: please provide a layout mode such as chat, split, focus_tui, or inspect."
        return runtime.set_layout_mode(target_mode)

    agent.add_tools(
        {
            "name": "set_tui_layout",
            "func": set_tui_layout,
            "description": "Switch the TUI layout preset. Valid modes: chat, split, focus_tui, inspect.",
        }
    )
    return None


def _apply_tool_strategy(agent: CliAgentAdapter, config: TUIConfig) -> List[str]:
    warnings: List[str] = []
    include = config.agent.tools_include
    exclude = {name.strip() for name in config.agent.tools_exclude if name.strip()}
    capabilities = getattr(agent, "capabilities", _CAPABILITY_DEFAULTS)

    if include:
        if getattr(capabilities, "supports_tools_mutation", False):
            agent.add_tools(*include)
        else:
            warnings.append(
                "Selected backend does not support tool mutation, so tools_include was ignored."
            )

    if not exclude:
        return warnings

    backend = getattr(agent, "backend", None)
    if not getattr(capabilities, "supports_tools_mutation", False) or backend is None or not hasattr(backend, "tools"):
        warnings.append(
            "Selected backend does not expose removable tool state, so tools_exclude was ignored."
        )
        return warnings

    for tool_name in list(getattr(backend, "tools", {}).keys()):
        if tool_name in exclude:
            backend.tools.pop(tool_name, None)
            if hasattr(backend, "external_tool_funcs"):
                backend.external_tool_funcs.pop(tool_name, None)
    if hasattr(backend, "_refresh_tool_prompts"):
        backend._refresh_tool_prompts()
    return warnings


def _coerce_capabilities(payload: Any) -> Optional[CliAgentCapabilities]:
    if isinstance(payload, CliAgentCapabilities):
        return payload
    if not isinstance(payload, Mapping):
        return None
    values = {field: payload.get(field, getattr(_CAPABILITY_DEFAULTS, field)) for field in _CAPABILITY_DEFAULTS.__dataclass_fields__}
    return CliAgentCapabilities(**{key: bool(value) for key, value in values.items()})


def normalize_build_result(
    created: Any,
    *,
    fallback_selected: str,
    adapter_hint: str = "auto",
) -> AgentBuildResult:
    warnings: List[str] = []
    selected = str(fallback_selected or "").strip() or fallback_selected
    capabilities: Optional[CliAgentCapabilities] = None

    if isinstance(created, AgentBuildResult):
        agent = wrap_backend(created.agent, adapter=adapter_hint)
        result = AgentBuildResult(agent=agent, selected_model=created.selected_model or selected, warnings=list(created.warnings or []))
        validate_agent_contract(result.agent)
        return result

    if isinstance(created, Mapping):
        backend = created.get("agent", created.get("backend"))
        if backend is None:
            raise ValueError("provider mapping result must include agent or backend")
        selected = str(created.get("selected_model") or created.get("selected") or selected)
        adapter_hint = str(created.get("adapter") or adapter_hint or "auto")
        capabilities = _coerce_capabilities(created.get("capabilities"))
        warnings.extend(str(item) for item in list(created.get("warnings") or []) if str(item).strip())
        agent = wrap_backend(backend, adapter=adapter_hint, capabilities=capabilities)
        result = AgentBuildResult(agent=agent, selected_model=selected, warnings=warnings)
        validate_agent_contract(result.agent)
        return result

    if isinstance(created, tuple) and len(created) >= 1:
        backend = created[0]
        if len(created) >= 2 and created[1]:
            selected = str(created[1])
        if len(created) >= 3:
            third = created[2]
            if isinstance(third, str):
                adapter_hint = third
            else:
                capabilities = _coerce_capabilities(third)
        agent = wrap_backend(backend, adapter=adapter_hint, capabilities=capabilities)
        result = AgentBuildResult(agent=agent, selected_model=selected, warnings=warnings)
        validate_agent_contract(result.agent)
        return result

    agent = wrap_backend(created, adapter=adapter_hint, capabilities=capabilities)
    result = AgentBuildResult(agent=agent, selected_model=selected, warnings=warnings)
    validate_agent_contract(result.agent)
    return result


def _build_default_agent(runtime: CliRuntimeContext, config: TUIConfig) -> AgentBuildResult:
    selected = runtime.model_provider
    if runtime.model_name:
        selected = f"{runtime.model_provider}/{runtime.model_name}"

    if runtime.tavily_api_key:
        set_tavily_api(runtime.tavily_api_key)

    model = setup_model(
        runtime.model_provider,
        runtime.model_name,
        api_key=runtime.api_key,
        **runtime.model_kwargs,
    )
    backend = create_agent(
        working_dir=runtime.working_dir,
        model=model,
        max_iterations=runtime.max_iterations,
        memory_dir=runtime.memory_dir,
        load_project_docs=runtime.load_project_docs,
        checkpointer=runtime.checkpointer,
        store=runtime.store,
        allow_shell_commands=runtime.allow_shell_commands,
        tool_virtual_root=(runtime.tool_virtual_root or runtime.working_dir),
    )
    result = AgentBuildResult(agent=wrap_backend(backend, adapter="klynx"), selected_model=selected, warnings=[])
    result.warnings.extend(_apply_tool_strategy(result.agent, config))
    layout_warning = _add_layout_tool(result.agent, runtime)
    if layout_warning:
        result.warnings.append(layout_warning)
    result.agent.set_callbacks(tui_screen_update_callback=runtime.tui_screen_update_callback)
    validate_agent_contract(result.agent)
    return result


def _load_callable(spec: str):
    entry = str(spec).strip()
    if ":" not in entry:
        raise ValueError("provider entry must use module:function format")
    module_name, func_name = entry.split(":", 1)
    module = importlib.import_module(module_name)
    fn = getattr(module, func_name)
    if not callable(fn):
        raise ValueError(f"provider is not callable: {entry}")
    return fn


def build_agent(config: TUIConfig, runtime: CliRuntimeContext) -> AgentBuildResult:
    warnings: List[str] = []
    provider_spec = (config.agent.provider or "").strip()
    adapter_hint = str(config.agent.adapter or config.agent.backend or "auto").strip().lower() or "auto"
    if provider_spec:
        try:
            provider = _load_callable(provider_spec)
            created = provider(runtime=runtime, config=config)
            result = normalize_build_result(created, fallback_selected=provider_spec, adapter_hint=adapter_hint)
            result.agent.set_callbacks(tui_screen_update_callback=runtime.tui_screen_update_callback)
            result.warnings.extend(warnings)
            return result
        except Exception as exc:
            warnings.append(f"External agent provider failed, falling back to default provider: {exc}")

    default_result = _build_default_agent(runtime, config)
    default_result.warnings.extend(warnings)
    return default_result
