"""Slash command registry for the Klynx TUI app."""

from __future__ import annotations

from dataclasses import dataclass
import importlib
from typing import Callable, Dict, List, Optional

from textual.widgets import Log as RichLog

from ..command_specs import SLASH_COMMANDS, get_slash_command_spec

from .config import TUIConfig


CommandHandler = Callable[[List[str], str], None]


@dataclass
class RegisteredCommand:
    name: str
    handler: CommandHandler
    help_text: str
    enabled: bool = True


class CommandRegistry:
    """Command dispatch and metadata container."""

    def __init__(self, app) -> None:
        self.app = app
        self._commands: Dict[str, RegisteredCommand] = {}

    def register(
        self,
        name: str,
        handler: CommandHandler,
        help_text: str,
        enabled: bool = True,
    ) -> None:
        cmd = str(name).strip().lower().lstrip('/')
        if not cmd:
            return
        self._commands[cmd] = RegisteredCommand(
            name=cmd,
            handler=handler,
            help_text=help_text,
            enabled=enabled,
        )

    def dispatch(self, raw_input: str) -> bool:
        raw = (raw_input or '').strip()
        if not raw.startswith('/'):
            return False
        parts = raw.split()
        cmd = parts[0].lstrip('/').lower()
        args = parts[1:]

        command = self._commands.get(cmd)
        if not command or not command.enabled:
            return False
        try:
            command.handler(args, raw)
        except Exception as exc:
            _write_log(self.app, f'[error] command failed /{cmd}: {exc}', style='bold red')
        return True

    def command_suggestions(self) -> List[str]:
        return sorted(f'/{name}' for name, cmd in self._commands.items() if cmd.enabled)

    def render_help(self) -> str:
        lines = ['Klynx TUI Help', '-----------------']
        for name in sorted(self._commands.keys()):
            cmd = self._commands[name]
            if not cmd.enabled:
                continue
            lines.append(f'/{name}  {cmd.help_text}')
            spec = get_slash_command_spec(name)
            if spec and spec.shell_equivalents:
                lines.append(f"    shell: {' | '.join(spec.shell_equivalents)}")
        return '\n'.join(lines)


def _write_log(app, message: str, style: Optional[str] = None) -> None:
    _ = style
    try:
        log = app.query_one('#agent-log', RichLog)
        log.write(str(message) + "\n")
    except Exception:
        pass


def _make_app_handler(app, method_name: str) -> CommandHandler:
    def _handler(args: List[str], raw: str) -> None:
        handler = getattr(app, method_name, None)
        if not callable(handler):
            raise RuntimeError(f'Missing command handler: {method_name}')
        handler(args=args, raw=raw)

    return _handler


def _load_external_command_hooks(registry: CommandRegistry, app, handler_specs: List[str]) -> None:
    for spec in handler_specs:
        entry = str(spec).strip()
        if not entry or ':' not in entry:
            _write_log(app, f'[warning] invalid external command handler: {spec}', style='yellow')
            continue
        module_name, func_name = entry.split(':', 1)
        try:
            module = importlib.import_module(module_name)
            hook = getattr(module, func_name)
        except Exception as exc:
            _write_log(app, f'[warning] failed to load external command handler {entry}: {exc}', style='yellow')
            continue
        if not callable(hook):
            _write_log(app, f'[warning] external command handler is not callable: {entry}', style='yellow')
            continue
        try:
            hook(registry=registry, app=app)
        except TypeError:
            hook(registry, app)
        except Exception as exc:
            _write_log(app, f'[warning] external command handler failed {entry}: {exc}', style='yellow')


def create_command_registry(app, config: TUIConfig) -> CommandRegistry:
    registry = CommandRegistry(app)
    builtin_enabled = config.commands.builtin
    help_overrides = config.commands.help_overrides

    for spec in SLASH_COMMANDS:
        enabled = bool(builtin_enabled.get(spec.name, True))
        if not enabled:
            continue
        help_text = help_overrides.get(spec.name, spec.default_help)
        registry.register(
            name=spec.name,
            handler=_make_app_handler(app, spec.handler_name),
            help_text=help_text,
            enabled=True,
        )

    if config.commands.external_handlers:
        _load_external_command_hooks(registry, app, config.commands.external_handlers)

    return registry

