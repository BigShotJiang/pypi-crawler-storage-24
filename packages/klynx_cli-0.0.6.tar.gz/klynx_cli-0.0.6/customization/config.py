"""TUI customization config model and loader."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Dict, List, Optional


LAYOUT_MODE_ALIASES = {
    "full": "chat",
    "focus": "focus_tui",
    "focus-tui": "focus_tui",
    "focus_tui": "focus_tui",
}
LAYOUT_PRESETS = {"chat", "split", "focus_tui", "inspect"}


def normalize_layout_mode(value: Any, default: str = "chat") -> str:
    text = str(value or "").strip().lower()
    if not text:
        return default
    normalized = LAYOUT_MODE_ALIASES.get(text, text)
    return normalized if normalized in LAYOUT_PRESETS else default


def _as_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
    return default


def _as_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _ensure_str_list(value: Any) -> List[str]:
    if isinstance(value, str):
        return [value]
    if not isinstance(value, list):
        return []
    result: List[str] = []
    for item in value:
        if item is None:
            continue
        text = str(item).strip()
        if text:
            result.append(text)
    return result


def _load_mapping_from_file(config_path: Path) -> Dict[str, Any]:
    if not config_path.exists():
        return {}

    suffix = config_path.suffix.lower()
    text = config_path.read_text(encoding="utf-8")
    if not text.strip():
        return {}

    if suffix in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore
        except Exception:
            return {}
        loaded = yaml.safe_load(text) or {}
        return loaded if isinstance(loaded, dict) else {}

    if suffix == ".json":
        try:
            loaded = json.loads(text)
        except Exception:
            return {}
        return loaded if isinstance(loaded, dict) else {}

    return {}


@dataclass
class OutputConfig:
    visible_events: List[str] = field(
        default_factory=lambda: [
            "warning",
            "error",
            "answer",
            "tool_exec",
        ]
    )
    show_reasoning_tokens: bool = False
    show_reasoning_indicator: bool = True
    allow_text_metrics_fallback: bool = False
    show_raw_stdout: bool = False
    tool_result_max_lines: int = 8
    status_fields: List[str] = field(
        default_factory=lambda: ["round", "total_tokens", "context_usage"]
    )


@dataclass
class KeybindingsConfig:
    disable_defaults: List[str] = field(default_factory=list)
    overrides: Dict[str, Dict[str, Any]] = field(default_factory=dict)


@dataclass
class CommandsConfig:
    builtin: Dict[str, bool] = field(
        default_factory=lambda: {
            "quit": True,
            "clear": True,
            "copy": True,
            "context": True,
            "help": True,
            "mode": True,
            "model": True,
            "compact": True,
        }
    )
    external_handlers: List[str] = field(default_factory=list)
    help_overrides: Dict[str, str] = field(default_factory=dict)


@dataclass
class InputConfig:
    enable_skill_ref: bool = True
    enable_file_ref: bool = True
    preprocessors: List[str] = field(default_factory=list)


@dataclass
class AgentConfig:
    backend: str = "klynx"
    provider: str = ""
    adapter: str = "auto"
    invoke: Dict[str, Any] = field(default_factory=lambda: {"thinking_context": False})
    tools_include: List[str] = field(default_factory=list)
    tools_exclude: List[str] = field(default_factory=list)
    backend_options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UIConfig:
    css_path: str = ""
    layout_mode: str = "chat"
    panels: Dict[str, Any] = field(
        default_factory=lambda: {
            "transcript": True,
            "activity": True,
            "workspace": True,
            "status": "compact",
        }
    )
    workspace_default: str = "tui"
    responsive_stack_breakpoint: int = 120


@dataclass
class TUIConfig:
    output: OutputConfig = field(default_factory=OutputConfig)
    keybindings: KeybindingsConfig = field(default_factory=KeybindingsConfig)
    commands: CommandsConfig = field(default_factory=CommandsConfig)
    input: InputConfig = field(default_factory=InputConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    source_path: str = ""


def default_config_path(base_dir: Optional[str] = None) -> Path:
    root = Path(base_dir or ".").resolve()
    return root / ".klynx" / "tui" / "config.yaml"


def _load_user_config(base_dir: Optional[str] = None) -> Dict[str, Any]:
    primary = default_config_path(base_dir)
    if primary.exists():
        return _load_mapping_from_file(primary)

    json_fallback = primary.with_suffix(".json")
    if json_fallback.exists():
        return _load_mapping_from_file(json_fallback)
    return {}


def load_tui_config(base_dir: Optional[str] = None) -> TUIConfig:
    payload = _load_user_config(base_dir)
    output_raw = payload.get("output", {}) if isinstance(payload.get("output"), dict) else {}
    keybindings_raw = payload.get("keybindings", {}) if isinstance(payload.get("keybindings"), dict) else {}
    commands_raw = payload.get("commands", {}) if isinstance(payload.get("commands"), dict) else {}
    input_raw = payload.get("input", {}) if isinstance(payload.get("input"), dict) else {}
    agent_raw = payload.get("agent", {}) if isinstance(payload.get("agent"), dict) else {}
    ui_raw = payload.get("ui", {}) if isinstance(payload.get("ui"), dict) else {}

    output = OutputConfig(
        visible_events=_ensure_str_list(output_raw.get("visible_events")) or OutputConfig().visible_events,
        show_reasoning_tokens=_as_bool(
            output_raw.get("show_reasoning_tokens"),
            OutputConfig().show_reasoning_tokens,
        ),
        show_reasoning_indicator=_as_bool(
            output_raw.get("show_reasoning_indicator"),
            _as_bool(output_raw.get("show_reasoning_tokens"), OutputConfig().show_reasoning_indicator),
        ),
        allow_text_metrics_fallback=_as_bool(
            output_raw.get("allow_text_metrics_fallback"),
            OutputConfig().allow_text_metrics_fallback,
        ),
        show_raw_stdout=_as_bool(
            output_raw.get("show_raw_stdout"),
            OutputConfig().show_raw_stdout,
        ),
        tool_result_max_lines=max(
            1,
            _as_int(output_raw.get("tool_result_max_lines"), OutputConfig().tool_result_max_lines),
        ),
        status_fields=_ensure_str_list(output_raw.get("status_fields")) or OutputConfig().status_fields,
    )

    keybindings = KeybindingsConfig(
        disable_defaults=_ensure_str_list(keybindings_raw.get("disable_defaults")),
        overrides=keybindings_raw.get("overrides", {})
        if isinstance(keybindings_raw.get("overrides", {}), dict)
        else {},
    )

    builtin_raw = commands_raw.get("builtin", {})
    if not isinstance(builtin_raw, dict):
        builtin_raw = {}
    builtin = CommandsConfig().builtin.copy()
    for name, enabled in builtin_raw.items():
        builtin[str(name).strip().lower()] = _as_bool(enabled, True)

    help_overrides_raw = commands_raw.get("help_overrides", {})
    if not isinstance(help_overrides_raw, dict):
        help_overrides_raw = {}
    help_overrides = {
        str(k).strip().lower(): str(v)
        for k, v in help_overrides_raw.items()
        if str(k).strip()
    }

    commands = CommandsConfig(
        builtin=builtin,
        external_handlers=_ensure_str_list(commands_raw.get("external_handlers")),
        help_overrides=help_overrides,
    )

    input_cfg = InputConfig(
        enable_skill_ref=_as_bool(input_raw.get("enable_skill_ref"), True),
        enable_file_ref=_as_bool(input_raw.get("enable_file_ref"), True),
        preprocessors=_ensure_str_list(input_raw.get("preprocessors")),
    )

    invoke_raw = agent_raw.get("invoke", {})
    if not isinstance(invoke_raw, dict):
        invoke_raw = {}
    backend_options_raw = agent_raw.get("backend_options", {})
    if not isinstance(backend_options_raw, dict):
        backend_options_raw = {}
    agent = AgentConfig(
        backend=str(agent_raw.get("backend", AgentConfig().backend) or AgentConfig().backend).strip().lower(),
        provider=str(agent_raw.get("provider", "") or "").strip(),
        adapter=str(agent_raw.get("adapter", AgentConfig().adapter) or AgentConfig().adapter).strip().lower(),
        invoke=invoke_raw or AgentConfig().invoke,
        tools_include=_ensure_str_list(agent_raw.get("tools_include")),
        tools_exclude=_ensure_str_list(agent_raw.get("tools_exclude")),
        backend_options=backend_options_raw,
    )

    panels_raw = ui_raw.get("panels", {})
    if not isinstance(panels_raw, dict):
        panels_raw = {}
    panels = dict(UIConfig().panels)
    panels.update(panels_raw)

    ui = UIConfig(
        css_path=str(ui_raw.get("css_path", "") or "").strip(),
        layout_mode=normalize_layout_mode(ui_raw.get("layout_mode", UIConfig().layout_mode), default=UIConfig().layout_mode),
        panels=panels,
        workspace_default=str(ui_raw.get("workspace_default", UIConfig().workspace_default) or UIConfig().workspace_default).strip().lower(),
        responsive_stack_breakpoint=max(
            60,
            _as_int(ui_raw.get("responsive_stack_breakpoint"), UIConfig().responsive_stack_breakpoint),
        ),
    )

    config = TUIConfig(
        output=output,
        keybindings=keybindings,
        commands=commands,
        input=input_cfg,
        agent=agent,
        ui=ui,
        source_path=str(default_config_path(base_dir)),
    )
    return config
