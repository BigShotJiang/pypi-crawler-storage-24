"""Event rendering strategy for the TUI app."""

from __future__ import annotations

import re

from textual.widgets import Log

from ..output import (
    extract_tool_name,
    format_thinking_label,
    is_internal_status_text,
    sanitize_visible_text,
)
from .config import OutputConfig

_TOOL_PARAM_PATTERN = re.compile(r"^\s*([A-Za-z0-9_\-\u4e00-\u9fff]+)\s*[::]\s*(.+?)\s*$")
_TOOL_PARAM_DROP_KEYS = {"output", "result", "stdout", "stderr", "content"}
_STREAM_SANITIZE_CARRY_CHARS = 256


class EventRenderer:
    """Render agent events with minimal single-stream output."""

    def __init__(self, app, output_config: OutputConfig) -> None:
        self.app = app
        self.output_config = output_config
        self.visible_events = set(output_config.visible_events or [])
        self.show_reasoning_indicator = bool(getattr(output_config, "show_reasoning_indicator", True))

    def _log_widget(self) -> Log:
        return self.app.query_one("#agent-log", Log)

    def _ensure_state(self) -> None:
        if not hasattr(self.app, "_token_buffer"):
            self.app._token_buffer = ""
        if not hasattr(self.app, "_reasoning_buffer"):
            self.app._reasoning_buffer = ""
        if not hasattr(self.app, "_last_response"):
            self.app._last_response = ""
        if not hasattr(self.app, "_thinking_indicator_logged"):
            self.app._thinking_indicator_logged = False
        if not hasattr(self.app, "_current_tool_name"):
            self.app._current_tool_name = ""
        if not hasattr(self.app, "_current_tool_params"):
            self.app._current_tool_params = {}
        if not hasattr(self.app, "_last_tool_marker"):
            self.app._last_tool_marker = ""
        if not hasattr(self.app, "_stream_visible_prefix"):
            self.app._stream_visible_prefix = ""
        if not hasattr(self.app, "_stream_line_open"):
            self.app._stream_line_open = False
        if not hasattr(self.app, "_stream_sanitize_carry"):
            self.app._stream_sanitize_carry = ""
        if not hasattr(self.app, "_stream_fast_path"):
            self.app._stream_fast_path = True

    def _close_stream_line_if_needed(self) -> None:
        if getattr(self.app, "_stream_line_open", False):
            self._log_widget().write("\n")
            self.app._stream_line_open = False

    def _write_line(self, content: str) -> None:
        text = str(content or "").strip("\n")
        if not text:
            return
        self._close_stream_line_if_needed()
        self._log_widget().write(text + "\n")

    def _append_stream(self, content: str) -> None:
        text = str(content or "")
        if not text:
            return
        self._log_widget().write(text)
        self.app._stream_line_open = True

    @staticmethod
    def _compact_param_value(raw: str) -> str:
        text = sanitize_visible_text(raw)
        if not text:
            text = str(raw or "").strip()
        text = " ".join(text.split())
        if len(text) > 120:
            text = text[:117] + "..."
        return text

    def _emit_thinking_indicator(self) -> None:
        if not self.show_reasoning_indicator:
            return
        if getattr(self.app, "_thinking_indicator_logged", False):
            return
        self.app._thinking_indicator_logged = True
        self._write_line(format_thinking_label())

    def _emit_tool_marker(self) -> None:
        tool_name = str(getattr(self.app, "_current_tool_name", "") or "").strip()
        if not tool_name:
            return

        params = getattr(self.app, "_current_tool_params", {}) or {}
        ordered_pairs = []
        for key in sorted(params.keys()):
            value = str(params.get(key, "") or "").strip()
            if not value:
                continue
            ordered_pairs.append(f"{key}={value}")
        payload = " ".join([f"tool={tool_name}", *ordered_pairs]).strip()
        marker = f"[{payload}]"
        if marker == getattr(self.app, "_last_tool_marker", ""):
            return
        self.app._last_tool_marker = marker
        self._write_line(marker)

    def _try_start_tool(self, content: str) -> bool:
        tool_name = extract_tool_name(content)
        if not tool_name:
            return False
        self.app._current_tool_name = tool_name
        self.app._current_tool_params = {}
        self.app._last_tool_marker = ""
        self._emit_tool_marker()
        return True

    def _try_append_tool_param(self, content: str) -> bool:
        if not getattr(self.app, "_current_tool_name", ""):
            return False
        match = _TOOL_PARAM_PATTERN.match(str(content or ""))
        if not match:
            return False
        key = str(match.group(1) or "").strip().lower()
        value = self._compact_param_value(match.group(2) or "")
        if not key or not value or key in _TOOL_PARAM_DROP_KEYS:
            return False
        params = dict(getattr(self.app, "_current_tool_params", {}) or {})
        params[key] = value
        self.app._current_tool_params = params
        self._emit_tool_marker()
        return True

    def _clear_tool_state(self) -> None:
        self.app._current_tool_name = ""
        self.app._current_tool_params = {}
        self.app._last_tool_marker = ""

    def _stream_token_content(self, content: str) -> None:
        raw = str(content or "")
        if not raw:
            return

        self.app._has_streamed_tokens = True
        self.app._token_buffer += raw

        # Fast path: plain token text can be streamed directly without full
        # protocol sanitization on every chunk.
        if bool(getattr(self.app, "_stream_fast_path", True)):
            if "<" not in raw:
                if "answer" in self.visible_events:
                    self._append_stream(raw)
                self.app._stream_visible_prefix = str(
                    getattr(self.app, "_stream_visible_prefix", "") or ""
                ) + raw
                self.app._stream_sanitize_carry = (str(getattr(self.app, "_stream_sanitize_carry", "") or "") + raw)[
                    -_STREAM_SANITIZE_CARRY_CHARS:
                ]
                return
            self.app._stream_fast_path = False

        carry = str(getattr(self.app, "_stream_sanitize_carry", "") or "")
        window = carry + raw
        previous_visible = sanitize_visible_text(carry)
        visible_full = sanitize_visible_text(window)

        if visible_full.startswith(previous_visible):
            delta = visible_full[len(previous_visible):]
        else:
            common = 0
            limit = min(len(visible_full), len(previous_visible))
            while common < limit and visible_full[common] == previous_visible[common]:
                common += 1
            delta = visible_full[common:]

        self.app._stream_visible_prefix = visible_full
        self.app._stream_sanitize_carry = window[-_STREAM_SANITIZE_CARRY_CHARS:]
        if "answer" in self.visible_events and delta:
            self._append_stream(delta)

    def _flush_final_answer(self, event: dict | None = None) -> None:
        had_streamed_tokens = bool(getattr(self.app, "_has_streamed_tokens", False))
        raw_answer = str(getattr(self.app, "_token_buffer", "") or "")
        if not raw_answer and event is not None:
            raw_answer = str(event.get("answer", "") or event.get("content", "") or "")
        answer = sanitize_visible_text(raw_answer)

        self._close_stream_line_if_needed()

        self.app._stream_visible_prefix = ""
        self.app._token_buffer = ""
        self.app._reasoning_buffer = ""
        self.app._has_streamed_tokens = False
        self.app._has_streamed_reasoning = False
        self.app._thinking_indicator_logged = False
        self.app._stream_sanitize_carry = ""
        self.app._stream_fast_path = True
        self._clear_tool_state()
        if answer:
            self.app._last_response = answer
            if "answer" in self.visible_events and not had_streamed_tokens:
                self._write_line(answer)

    def handle(self, event: dict) -> None:
        self._ensure_state()
        typ = str(event.get("type", "") or "")
        content = str(event.get("content", "") or "")

        if typ == "token":
            self._stream_token_content(content)
            return

        if typ == "reasoning_token":
            self.app._has_streamed_reasoning = True
            self._emit_thinking_indicator()
            return

        if typ == "done":
            self._flush_final_answer(event)
            return

        if typ == "answer":
            if not getattr(self.app, "_has_streamed_tokens", False):
                answer = sanitize_visible_text(content)
                if answer:
                    self.app._last_response = answer
                    if "answer" in self.visible_events:
                        self._write_line(answer)
            return

        if typ == "reasoning":
            if content:
                self._emit_thinking_indicator()
            return

        if typ == "summary":
            # Keep summary internal to reduce transcript noise.
            self.app._summary_emitted = True
            return

        if typ == "tool_exec":
            if self._try_start_tool(content):
                return
            self._try_append_tool_param(content)
            return

        if typ == "tool_result":
            # Never print concrete tool output in the transcript.
            self._clear_tool_state()
            return

        if typ == "token_usage":
            self.app._accumulate_token_usage_event(event)
            return

        if typ == "context_stats":
            self.app._accumulate_context_stats_event(event)
            self.app._update_status()
            return

        if typ in {"info", "routing", "tool_calls"}:
            return

        if typ in {"warning", "error"}:
            text = sanitize_visible_text(content) or content.strip()
            if text and not is_internal_status_text(text):
                self._write_line(text)
            return

        if typ in self.visible_events:
            text = sanitize_visible_text(content)
            if text:
                self._write_line(f"[{typ}] {text}")
