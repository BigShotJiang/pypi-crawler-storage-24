"""Customization layer for klynx_cli."""

from .adapters import (
    CliAgentAdapter,
    CliAgentCapabilities,
    CliEvent,
    DeepAgentsCliAdapter,
    GenericCliAgentAdapter,
    KlynxCliAdapter,
    LangGraphCliAdapter,
    wrap_backend,
)
from .agent_provider import (
    AgentBuildResult,
    CliRuntimeContext,
    RuntimeContext,
    build_agent,
    normalize_build_result,
    validate_agent_contract,
)
from .commands import CommandRegistry, create_command_registry
from .config import TUIConfig, load_tui_config, normalize_layout_mode
from .keymap import apply_bindings, resolve_bindings
from .preprocessors import apply_preprocessors, build_preprocessor_chain
from .renderers import EventRenderer

__all__ = [
    "AgentBuildResult",
    "CliAgentAdapter",
    "CliAgentCapabilities",
    "CliEvent",
    "CliRuntimeContext",
    "CommandRegistry",
    "DeepAgentsCliAdapter",
    "EventRenderer",
    "GenericCliAgentAdapter",
    "KlynxCliAdapter",
    "LangGraphCliAdapter",
    "RuntimeContext",
    "TUIConfig",
    "apply_bindings",
    "apply_preprocessors",
    "build_agent",
    "build_preprocessor_chain",
    "create_command_registry",
    "load_tui_config",
    "normalize_build_result",
    "normalize_layout_mode",
    "resolve_bindings",
    "validate_agent_contract",
    "wrap_backend",
]
