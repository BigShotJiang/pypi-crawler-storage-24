"""CLI agent adapter primitives for klynx_cli."""

from __future__ import annotations

from dataclasses import dataclass, field
import inspect
from typing import Any, Callable, Dict, Iterable, Iterator, Optional, Protocol, runtime_checkable


EventDict = Dict[str, Any]


@dataclass(frozen=True)
class CliAgentCapabilities:
    supports_resume: bool = True
    supports_compact: bool = False
    supports_tools_mutation: bool = False
    supports_layout_tool: bool = False
    supports_tui_screen_callback: bool = False
    supports_direct_ask: bool = False
    supports_headless_run: bool = True

    def merged(self, **overrides: Any) -> "CliAgentCapabilities":
        values = {
            "supports_resume": self.supports_resume,
            "supports_compact": self.supports_compact,
            "supports_tools_mutation": self.supports_tools_mutation,
            "supports_layout_tool": self.supports_layout_tool,
            "supports_tui_screen_callback": self.supports_tui_screen_callback,
            "supports_direct_ask": self.supports_direct_ask,
            "supports_headless_run": self.supports_headless_run,
        }
        for key, value in overrides.items():
            if key in values and value is not None:
                values[key] = bool(value)
        return CliAgentCapabilities(**values)


@dataclass
class CliEvent:
    type: str
    content: Any = ""
    payload: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> EventDict:
        event: EventDict = {"type": str(self.type or "")}
        if self.content not in (None, ""):
            event["content"] = self.content
        event.update(dict(self.payload or {}))
        return event


@runtime_checkable
class CliAgentAdapter(Protocol):
    backend: Any
    capabilities: CliAgentCapabilities

    def invoke(self, task: str, thread_id: str, **kwargs: Any) -> Iterable[EventDict]:
        ...

    def ask(self, message: str, thread_id: str = "default", **kwargs: Any) -> Iterable[EventDict]:
        ...

    def get_context(self, thread_id: str = "default") -> Dict[str, Any]:
        ...

    def compact_context(self, thread_id: str) -> tuple[str, str]:
        ...

    def add_tools(self, *tools: Any) -> Any:
        ...

    def set_callbacks(self, **callbacks: Any) -> None:
        ...


class BaseCliAgentAdapter:
    def __init__(self, backend: Any, *, capabilities: Optional[CliAgentCapabilities] = None) -> None:
        self.backend = backend
        self.capabilities = capabilities or infer_backend_capabilities(backend)

    def __getattr__(self, name: str) -> Any:
        return getattr(self.backend, name)

    def _call_backend(self, method_name: str, *args: Any, **kwargs: Any) -> Any:
        method = getattr(self.backend, method_name, None)
        if not callable(method):
            raise AttributeError(f"backend missing method: {method_name}")
        try:
            return method(*args, **kwargs)
        except TypeError:
            filtered = _filter_supported_kwargs(method, kwargs)
            if args:
                return method(*args, **filtered)
            return method(**filtered)

    def _iter_events(self, source: Any) -> Iterator[EventDict]:
        if source is None:
            return
        if isinstance(source, dict):
            yield dict(source)
            return
        if isinstance(source, CliEvent):
            yield source.to_dict()
            return
        if isinstance(source, str):
            yield {"type": "answer", "content": source}
            return
        if isinstance(source, Iterable):
            for item in source:
                if isinstance(item, dict):
                    yield dict(item)
                elif isinstance(item, CliEvent):
                    yield item.to_dict()
                elif item is not None:
                    yield {"type": "answer", "content": str(item)}
            return
        yield {"type": "answer", "content": str(source)}

    def invoke(self, task: str, thread_id: str, **kwargs: Any) -> Iterable[EventDict]:
        source = self._call_backend("invoke", task=task, thread_id=thread_id, **kwargs)
        return self._iter_events(source)

    def ask(self, message: str, thread_id: str = "default", **kwargs: Any) -> Iterable[EventDict]:
        ask_method = getattr(self.backend, "ask", None)
        if callable(ask_method):
            source = self._call_backend("ask", message=message, thread_id=thread_id, **kwargs)
        else:
            invoke_kwargs = dict(kwargs)
            invoke_kwargs.setdefault("direct_answer", True)
            source = self._call_backend("invoke", task=message, thread_id=thread_id, **invoke_kwargs)
        return self._iter_events(source)

    def get_context(self, thread_id: str = "default") -> Dict[str, Any]:
        getter = getattr(self.backend, "get_context", None)
        if not callable(getter):
            return {}
        try:
            payload = getter(thread_id=thread_id)
        except TypeError:
            payload = getter(thread_id)
        return dict(payload or {}) if isinstance(payload, dict) else {}

    def compact_context(self, thread_id: str) -> tuple[str, str]:
        compact = getattr(self.backend, "compact_context", None)
        if not callable(compact):
            return ("Context compaction is not supported by this backend.", "")
        try:
            result = compact(thread_id)
        except TypeError:
            result = compact(thread_id=thread_id)
        if isinstance(result, tuple) and len(result) >= 2:
            return str(result[0]), str(result[1] or "")
        return str(result or "ok"), ""

    def add_tools(self, *tools: Any) -> Any:
        adder = getattr(self.backend, "add_tools", None)
        if not callable(adder):
            raise AttributeError("backend does not support tool mutation")
        return adder(*tools)

    def set_callbacks(self, **callbacks: Any) -> None:
        tui_callback = callbacks.get("tui_screen_update_callback")
        if tui_callback is not None:
            manager = getattr(self.backend, "tui_manager", None)
            if manager is not None and hasattr(manager, "screen_update_callback"):
                manager.screen_update_callback = tui_callback


class GenericCliAgentAdapter(BaseCliAgentAdapter):
    pass


class KlynxCliAdapter(BaseCliAgentAdapter):
    def __init__(self, backend: Any, *, capabilities: Optional[CliAgentCapabilities] = None) -> None:
        inferred = infer_backend_capabilities(backend).merged(
            supports_compact=True,
            supports_tools_mutation=True,
            supports_layout_tool=True,
            supports_tui_screen_callback=hasattr(getattr(backend, "tui_manager", None), "screen_update_callback"),
            supports_direct_ask=callable(getattr(backend, "ask", None)),
        )
        super().__init__(backend, capabilities=capabilities or inferred)


class LangGraphCliAdapter(BaseCliAgentAdapter):
    def __init__(self, backend: Any, *, capabilities: Optional[CliAgentCapabilities] = None) -> None:
        inferred = infer_backend_capabilities(backend).merged(
            supports_tools_mutation=callable(getattr(backend, "add_tools", None)),
            supports_compact=callable(getattr(backend, "compact_context", None)),
        )
        super().__init__(backend, capabilities=capabilities or inferred)


class DeepAgentsCliAdapter(BaseCliAgentAdapter):
    def __init__(self, backend: Any, *, capabilities: Optional[CliAgentCapabilities] = None) -> None:
        inferred = infer_backend_capabilities(backend).merged(
            supports_tools_mutation=callable(getattr(backend, "add_tools", None)),
            supports_compact=callable(getattr(backend, "compact_context", None)),
        )
        super().__init__(backend, capabilities=capabilities or inferred)


def _filter_supported_kwargs(func: Callable[..., Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        signature = inspect.signature(func)
    except (TypeError, ValueError):
        return dict(kwargs)
    params = signature.parameters
    if any(param.kind == param.VAR_KEYWORD for param in params.values()):
        return dict(kwargs)
    return {name: value for name, value in kwargs.items() if name in params}


def infer_backend_capabilities(backend: Any) -> CliAgentCapabilities:
    manager = getattr(backend, "tui_manager", None)
    return CliAgentCapabilities(
        supports_resume=True,
        supports_compact=callable(getattr(backend, "compact_context", None)),
        supports_tools_mutation=callable(getattr(backend, "add_tools", None)),
        supports_layout_tool=callable(getattr(backend, "add_tools", None)),
        supports_tui_screen_callback=hasattr(manager, "screen_update_callback"),
        supports_direct_ask=callable(getattr(backend, "ask", None)),
        supports_headless_run=callable(getattr(backend, "invoke", None)),
    )


def looks_like_cli_agent_adapter(value: Any) -> bool:
    return isinstance(value, BaseCliAgentAdapter) or (
        hasattr(value, "capabilities")
        and callable(getattr(value, "set_callbacks", None))
        and callable(getattr(value, "invoke", None))
        and callable(getattr(value, "get_context", None))
        and callable(getattr(value, "compact_context", None))
        and callable(getattr(value, "add_tools", None))
    )


def wrap_backend(
    backend: Any,
    *,
    adapter: str = "auto",
    capabilities: Optional[CliAgentCapabilities] = None,
) -> CliAgentAdapter:
    if looks_like_cli_agent_adapter(backend):
        if capabilities is not None and hasattr(backend, "capabilities"):
            backend.capabilities = capabilities  # type: ignore[attr-defined]
        return backend

    hint = str(adapter or "auto").strip().lower() or "auto"
    if hint == "klynx":
        return KlynxCliAdapter(backend, capabilities=capabilities)
    if hint == "langgraph":
        return LangGraphCliAdapter(backend, capabilities=capabilities)
    if hint == "deepagents":
        return DeepAgentsCliAdapter(backend, capabilities=capabilities)

    has_klynx_shape = callable(getattr(backend, "compact_context", None)) and callable(
        getattr(backend, "add_tools", None)
    )
    if has_klynx_shape:
        return KlynxCliAdapter(backend, capabilities=capabilities)
    return GenericCliAgentAdapter(backend, capabilities=capabilities)
