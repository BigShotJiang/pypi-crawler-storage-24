"""Key binding resolution and runtime registration."""

from __future__ import annotations

from typing import Dict, List, Tuple

from .config import TUIConfig


DEFAULT_BINDINGS = [
    {"key": "ctrl+q", "action": "quit", "description": "quit", "show": True},
    {"key": "escape", "action": "interrupt_agent", "description": "interrupt", "show": True},
    {"key": "ctrl+l", "action": "clear_log", "description": "clear log", "show": True},
    {"key": "ctrl+shift+c", "action": "copy_last", "description": "copy", "show": True},
]


def resolve_bindings(config: TUIConfig) -> Tuple[List[Dict], List[str]]:
    """Apply disable/override rules and return final bindings + warnings."""
    disabled = {key.lower() for key in config.keybindings.disable_defaults}
    result: List[Dict] = []
    warnings: List[str] = []

    for binding in DEFAULT_BINDINGS:
        if binding["key"].lower() in disabled:
            continue
        result.append(binding.copy())

    by_key = {item["key"].lower(): item for item in result}
    for key, spec in config.keybindings.overrides.items():
        key_text = str(key).strip()
        if not key_text:
            continue
        if not isinstance(spec, dict):
            warnings.append(f"ignore invalid keybinding override: {key}")
            continue
        action = str(spec.get("action", "") or "").strip()
        if not action:
            warnings.append(f"ignore keybinding without action: {key}")
            continue
        description = str(spec.get("description", action) or action)
        show = bool(spec.get("show", True))
        resolved = {
            "key": key_text,
            "action": action,
            "description": description,
            "show": show,
        }
        lowered = key_text.lower()
        if lowered in by_key and by_key[lowered]["action"] != action:
            warnings.append(f"key override: {key_text} {by_key[lowered]['action']} -> {action}")
        by_key[lowered] = resolved

    return list(by_key.values()), warnings


def apply_bindings(app, bindings: List[Dict]) -> None:
    """Register bindings at runtime to support user customization."""
    for binding in bindings:
        key = str(binding.get("key", "") or "").strip()
        action = str(binding.get("action", "") or "").strip()
        if not key or not action:
            continue
        description = str(binding.get("description", action) or action)
        show = bool(binding.get("show", True))
        try:
            app.bind(key, action, description=description, show=show)
        except TypeError:
            app.bind(key, action, description, show=show)
