"""Input preprocessing pipeline for TUI."""

from __future__ import annotations

from dataclasses import dataclass, field
import importlib
import os
import re
from typing import Callable, List, Tuple

from .config import TUIConfig


@dataclass
class PreprocessResult:
    text: str
    notes: List[str] = field(default_factory=list)


class SkillReferencePreprocessor:
    """Parse `$skill-name` refs and append a system note for load_skill usage."""

    pattern = re.compile(r"(?<!\S)\$([a-zA-Z0-9_.-]+)")

    def __call__(self, text: str, app) -> PreprocessResult:
        skill_refs: List[str] = []

        def _replace(match) -> str:
            skill_name = match.group(1).strip()
            if skill_name:
                skill_refs.append(skill_name)
            return skill_name

        transformed = self.pattern.sub(_replace, text)
        if not skill_refs:
            return PreprocessResult(text=transformed)

        unique: List[str] = []
        seen = set()
        for name in skill_refs:
            lowered = name.lower()
            if lowered in seen:
                continue
            seen.add(lowered)
            unique.append(name)

        installed = set()
        try:
            installed = set(app.get_skill_names())
        except Exception:
            installed = set()
        installed_lower = {name.lower() for name in installed}
        missing = [name for name in unique if name.lower() not in installed_lower]

        note_lines = [
            "[System Note: User referenced skills]",
            f"Referenced skills: {', '.join(unique)}",
            "Before completing the task, call load_skill(name) for referenced skills when details are needed.",
        ]
        if missing:
            note_lines.append(
                f"Some referenced skills are not currently installed: {', '.join(missing)}"
            )

        transformed = f"{transformed}\n\n" + "\n".join(note_lines)
        notes = [f"[] : {', '.join(unique)}"]
        return PreprocessResult(text=transformed, notes=notes)


class FileReferencePreprocessor:
    """Resolve `@path` file refs and append absolute location notes."""

    pattern = re.compile(r"@([a-zA-Z0-9_./\\:\-]+)")

    def __call__(self, text: str, app) -> PreprocessResult:
        file_refs: List[str] = []

        def _replace(match) -> str:
            ref = match.group(1)
            if os.path.exists(ref):
                abs_path = os.path.abspath(ref)
                file_refs.append(f"File '{ref}' is located at: {abs_path}")
                return ref

            if ref and ref[-1] in ",.?!;:'\"":
                clean_ref = ref[:-1]
                punctuation = ref[-1]
                if clean_ref and os.path.exists(clean_ref):
                    abs_path = os.path.abspath(clean_ref)
                    file_refs.append(f"File '{clean_ref}' is located at: {abs_path}")
                    return clean_ref + punctuation
            return match.group(0)

        transformed = self.pattern.sub(_replace, text)
        if not file_refs:
            return PreprocessResult(text=transformed)

        transformed += "\n\n[System Note: User mentioned files]\n" + "\n".join(file_refs)
        notes = [f"[] : {', '.join(file_refs)}"]
        return PreprocessResult(text=transformed, notes=notes)


def _load_external_preprocessor(spec: str) -> Callable[[str, object], Tuple[str, List[str]]]:
    entry = str(spec).strip()
    if ":" not in entry:
        raise ValueError(f" preprocessor : {spec}")
    module_name, func_name = entry.split(":", 1)
    module = importlib.import_module(module_name)
    func = getattr(module, func_name)
    if not callable(func):
        raise ValueError(f"preprocessor : {spec}")

    def _wrapped(text: str, app) -> Tuple[str, List[str]]:
        output = func(text=text, app=app)
        if isinstance(output, tuple) and len(output) == 2:
            new_text, notes = output
            if not isinstance(notes, list):
                notes = [str(notes)]
            return str(new_text), [str(note) for note in notes]
        if isinstance(output, str):
            return output, []
        return text, []

    return _wrapped


def build_preprocessor_chain(app, config: TUIConfig) -> List[Callable[[str, object], Tuple[str, List[str]]]]:
    chain: List[Callable[[str, object], Tuple[str, List[str]]]] = []

    def _wrap(preprocessor):
        def _runner(text: str, _app):
            result = preprocessor(text, _app)
            return result.text, result.notes

        return _runner

    if config.input.enable_skill_ref:
        skill = SkillReferencePreprocessor()
        chain.append(_wrap(skill))
    if config.input.enable_file_ref:
        file_ref = FileReferencePreprocessor()
        chain.append(_wrap(file_ref))

    for entry in config.input.preprocessors:
        try:
            chain.append(_load_external_preprocessor(entry))
        except Exception:
            continue
    return chain


def apply_preprocessors(
    text: str,
    app,
    chain: List[Callable[[str, object], Tuple[str, List[str]]]],
) -> Tuple[str, List[str]]:
    current = text
    all_notes: List[str] = []
    for processor in chain:
        try:
            current, notes = processor(current, app)
        except Exception:
            continue
        for note in notes:
            if note and note not in all_notes:
                all_notes.append(note)
    return current, all_notes
