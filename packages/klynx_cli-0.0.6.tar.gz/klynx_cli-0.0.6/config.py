from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from dotenv import load_dotenv

try:
    import tomllib  # type: ignore[attr-defined]
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore[no-redef]

DEFAULT_CONFIG: Dict[str, Any] = {
    'model': {
        'provider': 'deepseek',
        'name': 'deepseek-reasoner',
    },
    'cli': {
        'log_level': 'INFO',
        'print_logs': False,
    },
    'session': {},
    'tui': {},
}


@dataclass
class ConfigPaths:
    cwd: Path
    home_dir: Path
    global_config: Path
    project_dir: Path
    project_config: Path
    global_env: Path
    project_env: Path
    legacy_tui_config: Path
    session_root: Path


@dataclass
class ConfigSourceStatus:
    name: str
    path: str
    exists: bool
    valid: bool
    source_type: str
    error: str = ''

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'path': self.path,
            'exists': self.exists,
            'valid': self.valid,
            'source_type': self.source_type,
            'error': self.error,
        }


@dataclass
class ResolvedConfig:
    cwd: Path
    data: Dict[str, Any]
    paths: ConfigPaths

    @property
    def model_provider(self) -> str:
        model = self.data.get('model', {}) if isinstance(self.data, dict) else {}
        default_provider = str(DEFAULT_CONFIG['model']['provider'])
        return str(model.get('provider', default_provider) or default_provider).strip()

    @property
    def model_name(self) -> str:
        model = self.data.get('model', {}) if isinstance(self.data, dict) else {}
        default_name = str(DEFAULT_CONFIG['model']['name'])
        if not isinstance(model, dict):
            return default_name
        if 'name' not in model:
            return default_name
        value = model.get('name')
        if value is None:
            return ''
        return str(value).strip()

    @property
    def cli_log_level(self) -> str:
        cli = self.data.get('cli', {}) if isinstance(self.data, dict) else {}
        default_level = str(DEFAULT_CONFIG['cli']['log_level'])
        return str(cli.get('log_level', default_level) or default_level).strip().upper()

    @property
    def cli_print_logs(self) -> bool:
        cli = self.data.get('cli', {}) if isinstance(self.data, dict) else {}
        value = cli.get('print_logs', DEFAULT_CONFIG['cli']['print_logs'])
        if isinstance(value, bool):
            return value
        return str(value or '').strip().lower() in {'1', 'true', 'yes', 'on'}

    def to_dict(self) -> Dict[str, Any]:
        payload = dict(self.data)
        payload['paths'] = config_paths_payload(self)
        payload['config_sources'] = [item.to_dict() for item in inspect_config_sources(str(self.cwd))]
        return payload


def get_klynx_home() -> Path:
    raw = str(os.environ.get('KLYNX_HOME', '') or '').strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.home().expanduser().resolve() / '.klynx'


def resolve_paths(cwd: Optional[str] = None) -> ConfigPaths:
    cwd_path = Path(cwd or os.getcwd()).expanduser().resolve()
    home_dir = get_klynx_home()
    project_dir = cwd_path / '.klynx'
    return ConfigPaths(
        cwd=cwd_path,
        home_dir=home_dir,
        global_config=home_dir / 'config.toml',
        project_dir=project_dir,
        project_config=project_dir / 'config.toml',
        global_env=home_dir / '.env',
        project_env=project_dir / '.env',
        legacy_tui_config=project_dir / 'tui' / 'config.yaml',
        session_root=home_dir / 'sessions',
    )


def ensure_parent_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def load_env_files(cwd: Optional[str] = None) -> ConfigPaths:
    paths = resolve_paths(cwd)
    if paths.global_env.exists():
        load_dotenv(paths.global_env, override=False)
    if paths.project_env.exists():
        load_dotenv(paths.project_env, override=True)
    return paths


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _load_toml_file(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        payload = tomllib.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _legacy_tui_payload(paths: ConfigPaths) -> Dict[str, Any]:
    if not paths.legacy_tui_config.exists():
        return {}
    try:
        from klynx_cli.customization.config import load_tui_config
    except Exception:
        return {}
    try:
        config = load_tui_config(str(paths.cwd))
    except Exception:
        return {}
    return {'tui': asdict(config)}


def _parse_override_value(raw: str) -> Any:
    text = str(raw or '').strip()
    lowered = text.lower()
    if lowered in {'true', 'false'}:
        return lowered == 'true'
    if lowered in {'null', 'none'}:
        return None
    try:
        return int(text)
    except Exception:
        pass
    try:
        return float(text)
    except Exception:
        pass
    if text.startswith(('[', '{')) or (text.startswith('"') and text.endswith('"')):
        try:
            return json.loads(text)
        except Exception:
            pass
    return text


def _apply_override(target: Dict[str, Any], key_path: str, value: Any) -> None:
    parts = [segment.strip() for segment in str(key_path or '').split('.') if segment.strip()]
    if not parts:
        raise ValueError('Override path cannot be empty')
    current = target
    for part in parts[:-1]:
        next_value = current.get(part)
        if not isinstance(next_value, dict):
            next_value = {}
            current[part] = next_value
        current = next_value
    current[parts[-1]] = value


def parse_inline_overrides(items: Optional[Iterable[str]]) -> List[Tuple[str, Any]]:
    parsed: List[Tuple[str, Any]] = []
    for item in items or []:
        text = str(item or '').strip()
        if not text:
            continue
        if '=' not in text:
            raise ValueError(f'Invalid override, expected key=value: {text}')
        key, raw_value = text.split('=', 1)
        parsed.append((key.strip(), _parse_override_value(raw_value)))
    return parsed


def _apply_env_defaults(data: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(data)
    model_cfg = dict(merged.get('model', {}) or {})
    env_provider = str(os.environ.get('KLYNX_DEFAULT_PROVIDER', '') or '').strip()
    env_model = str(os.environ.get('KLYNX_DEFAULT_MODEL', '') or '').strip()
    has_env_provider = 'KLYNX_DEFAULT_PROVIDER' in os.environ
    has_env_model = 'KLYNX_DEFAULT_MODEL' in os.environ
    if has_env_provider and env_provider:
        model_cfg['provider'] = env_provider
    # Respect explicit empty model values from env so alias providers
    # (e.g. "gpt-4o") can work without inheriting stale defaults.
    if has_env_model:
        model_cfg['name'] = env_model
    merged['model'] = model_cfg
    return merged


def load_resolved_config(
    cwd: Optional[str] = None,
    overrides: Optional[Iterable[str]] = None,
) -> ResolvedConfig:
    paths = load_env_files(cwd)
    data = _deep_merge({}, DEFAULT_CONFIG)
    data = _deep_merge(data, _load_toml_file(paths.global_config))
    data = _deep_merge(data, _load_toml_file(paths.project_config))
    data = _deep_merge(data, _legacy_tui_payload(paths))
    data = _apply_env_defaults(data)
    for key, value in parse_inline_overrides(overrides):
        _apply_override(data, key, value)
    return ResolvedConfig(cwd=paths.cwd, data=data, paths=paths)


def _toml_key(name: str) -> str:
    key = str(name or '').strip()
    if not key:
        raise ValueError('TOML key cannot be empty')
    if all(ch.isalnum() or ch in {'_', '-'} for ch in key):
        return key
    return json.dumps(key, ensure_ascii=False)


def _toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return str(value)
    if value is None:
        return '""'
    if isinstance(value, list):
        return '[' + ', '.join(_toml_value(item) for item in value) + ']'
    return json.dumps(str(value), ensure_ascii=False)


def dump_toml(data: Dict[str, Any]) -> str:
    lines: List[str] = []

    def emit_table(prefix: str, mapping: Dict[str, Any]) -> None:
        scalars: List[Tuple[str, Any]] = []
        tables: List[Tuple[str, Dict[str, Any]]] = []
        for key, value in mapping.items():
            if isinstance(value, dict):
                tables.append((key, value))
            else:
                scalars.append((key, value))
        if prefix:
            lines.append(f'[{prefix}]')
        for key, value in scalars:
            lines.append(f'{_toml_key(key)} = {_toml_value(value)}')
        if scalars and tables:
            lines.append('')
        for index, (key, value) in enumerate(tables):
            child_prefix = f'{prefix}.{_toml_key(key)}' if prefix else _toml_key(key)
            emit_table(child_prefix, value)
            if index != len(tables) - 1:
                lines.append('')

    emit_table('', data)
    rendered = '\n'.join(lines).strip()
    return rendered + ('\n' if rendered else '')


def save_config_patch(scope: str, patch: Dict[str, Any], cwd: Optional[str] = None) -> Path:
    resolved = load_resolved_config(cwd)
    scope_name = str(scope or 'global').strip().lower()
    if scope_name not in {'global', 'project'}:
        raise ValueError('scope must be global or project')
    path = resolved.paths.global_config if scope_name == 'global' else resolved.paths.project_config
    existing = _load_toml_file(path)
    merged = _deep_merge(existing, patch)
    ensure_parent_dir(path)
    path.write_text(dump_toml(merged), encoding='utf-8')
    return path


def config_paths_payload(resolved: ResolvedConfig) -> Dict[str, str]:
    return {
        'cwd': str(resolved.paths.cwd),
        'home_dir': str(resolved.paths.home_dir),
        'global_config': str(resolved.paths.global_config),
        'project_config': str(resolved.paths.project_config),
        'global_env': str(resolved.paths.global_env),
        'project_env': str(resolved.paths.project_env),
        'legacy_tui_config': str(resolved.paths.legacy_tui_config),
        'session_root': str(resolved.paths.session_root),
    }


def _toml_status(name: str, path: Path) -> ConfigSourceStatus:
    if not path.exists():
        return ConfigSourceStatus(name=name, path=str(path), exists=False, valid=True, source_type='toml')
    try:
        payload = tomllib.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        return ConfigSourceStatus(name=name, path=str(path), exists=True, valid=False, source_type='toml', error=str(exc))
    if not isinstance(payload, dict):
        return ConfigSourceStatus(name=name, path=str(path), exists=True, valid=False, source_type='toml', error='Top-level TOML value must be a table')
    return ConfigSourceStatus(name=name, path=str(path), exists=True, valid=True, source_type='toml')


def _env_status(name: str, path: Path) -> ConfigSourceStatus:
    if not path.exists():
        return ConfigSourceStatus(name=name, path=str(path), exists=False, valid=True, source_type='env')
    try:
        path.read_text(encoding='utf-8')
    except Exception as exc:
        return ConfigSourceStatus(name=name, path=str(path), exists=True, valid=False, source_type='env', error=str(exc))
    return ConfigSourceStatus(name=name, path=str(path), exists=True, valid=True, source_type='env')


def _legacy_tui_status(paths: ConfigPaths) -> ConfigSourceStatus:
    path = paths.legacy_tui_config
    if not path.exists():
        return ConfigSourceStatus(name='legacy_tui_config', path=str(path), exists=False, valid=True, source_type='yaml')
    try:
        from klynx_cli.customization.config import load_tui_config
        load_tui_config(str(paths.cwd))
    except Exception as exc:
        return ConfigSourceStatus(name='legacy_tui_config', path=str(path), exists=True, valid=False, source_type='yaml', error=str(exc))
    return ConfigSourceStatus(name='legacy_tui_config', path=str(path), exists=True, valid=True, source_type='yaml')


def inspect_config_sources(cwd: Optional[str] = None) -> List[ConfigSourceStatus]:
    paths = resolve_paths(cwd)
    return [
        _toml_status('global_config', paths.global_config),
        _toml_status('project_config', paths.project_config),
        _legacy_tui_status(paths),
        _env_status('global_env', paths.global_env),
        _env_status('project_env', paths.project_env),
    ]


def validate_config_sources(cwd: Optional[str] = None) -> Tuple[bool, List[ConfigSourceStatus]]:
    sources = inspect_config_sources(cwd)
    valid = all((not item.exists) or item.valid for item in sources)
    return valid, sources
