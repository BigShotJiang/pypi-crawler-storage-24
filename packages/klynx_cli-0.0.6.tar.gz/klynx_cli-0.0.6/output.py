from __future__ import annotations

import json
import re
from typing import Any, Dict, Iterable, Mapping, Sequence, TextIO

from .config import ConfigSourceStatus

EXIT_OK = 0
EXIT_FAILURE = 1
EXIT_USAGE = 2
EXIT_CONFIG = 3
EXIT_NOT_FOUND = 4

_INTERNAL_STATUS_PREFIXES = (
    "[feedback]",
    "[routing]",
    "[context",
    "[context_stats]",
    "[Token]",
    "[tool_parse]",
    "[no_tool_call]",
    "[Native Tool Calling]",
    "[XML Fallback]",
    "[done]",
    "[task_goal",
    "[task_plan]",
    "[step_progress]",
    "[Checkpoint]",
)

_PROTOCOL_TAGS = (
    "act",
    "thinking",
    "reflection",
    "tool_result",
    "task_goal",
    "execute_command",
    "read_file",
    "apply_patch",
    "write_to_file",
    "replace_in_file",
    "list_directory",
    "create_directory",
    "preview_file",
    "search_in_files",
    "load_skill",
    "read_tool_artifact",
    "run_subtask",
    "wait_terminal_until",
    "read_terminal_since_last",
    "attempt_completion",
    "update_task_state",
    "workdir",
    "command",
)

_TOOL_NAME_PATTERN = re.compile(r"^\[[^\]]*\d+/\d+\]\s+(.+)$", re.IGNORECASE)
_PROTOCOL_BLOCK_PATTERN = re.compile(
    r"(?is)<(?P<tag>" + "|".join(re.escape(tag) for tag in _PROTOCOL_TAGS) + r")\b[^>]*>.*?</(?P=tag)>"
)
_PROTOCOL_SINGLETON_PATTERN = re.compile(
    r"(?is)<(?:" + "|".join(re.escape(tag) for tag in _PROTOCOL_TAGS) + r")\b[^>]*/>"
)
_PROTOCOL_LINE_PATTERN = re.compile(
    r"^\s*</?(?:" + "|".join(re.escape(tag) for tag in _PROTOCOL_TAGS) + r")\b[^>]*>\s*$",
    re.IGNORECASE,
)


def format_thinking_label() -> str:
    return "[thinking]"


def format_tool_label(tool_name: str) -> str:
    normalized = re.sub(r"\s+", " ", str(tool_name or "")).strip() or "tool"
    return f"[tool:{normalized}]"


def extract_tool_name(content: str) -> str:
    stripped = str(content or "").strip()
    if not stripped:
        return ""
    match = _TOOL_NAME_PATTERN.match(stripped)
    if match:
        return match.group(1).strip()
    return ""


def is_internal_status_text(content: str) -> bool:
    stripped = str(content or "").strip()
    if not stripped:
        return False
    if any(stripped.startswith(prefix) for prefix in _INTERNAL_STATUS_PREFIXES):
        return True
    return bool(_PROTOCOL_LINE_PATTERN.match(stripped))


def sanitize_visible_text(content: str) -> str:
    text = str(content or "")
    if not text.strip():
        return ""

    previous = None
    while text != previous:
        previous = text
        text = _PROTOCOL_BLOCK_PATTERN.sub(" ", text)
        text = _PROTOCOL_SINGLETON_PATTERN.sub(" ", text)

    kept_lines = []
    blank_streak = 0
    for raw_line in text.splitlines():
        stripped = raw_line.strip()
        if not stripped:
            blank_streak += 1
            if blank_streak <= 1:
                kept_lines.append("")
            continue
        blank_streak = 0
        if is_internal_status_text(stripped):
            continue
        kept_lines.append(raw_line)

    cleaned = "\n".join(kept_lines)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def json_dump(stream: TextIO, payload: Dict[str, Any]) -> None:
    stream.write(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    stream.flush()


def print_kv(stream: TextIO, rows: Iterable[tuple[str, Any]]) -> None:
    for key, value in rows:
        stream.write(f"{key}: {value}\n")
    stream.flush()


def _write_value(stream: TextIO, value: Any, *, indent: int = 0) -> None:
    prefix = " " * indent
    if isinstance(value, Mapping):
        for key, item in value.items():
            if isinstance(item, (Mapping, list)):
                stream.write(f"{prefix}{key}:\n")
                _write_value(stream, item, indent=indent + 2)
            else:
                stream.write(f"{prefix}{key}: {item}\n")
        return
    if isinstance(value, list):
        if not value:
            stream.write(f"{prefix}[]\n")
            return
        for item in value:
            if isinstance(item, (Mapping, list)):
                stream.write(f"{prefix}-\n")
                _write_value(stream, item, indent=indent + 2)
            else:
                stream.write(f"{prefix}- {item}\n")
        return
    stream.write(f"{prefix}{value}\n")


def print_nested_mapping(stream: TextIO, payload: Mapping[str, Any]) -> None:
    _write_value(stream, payload)
    stream.flush()


def print_session_table(stream: TextIO, sessions: Sequence[Mapping[str, Any]]) -> None:
    if not sessions:
        stream.write("No saved sessions\n")
        stream.flush()
        return
    for record in sessions:
        provider = str(record.get("provider", "") or "").strip()
        model_name = str(record.get("model_name", "") or "").strip()
        model_ref = provider if not model_name else f"{provider}/{model_name}"
        stream.write(
            f"{record.get('session_id')}  {record.get('updated_at')}  {model_ref}  {record.get('title')}\n"
        )
    stream.flush()


def print_transcript(stream: TextIO, transcript: Sequence[Mapping[str, Any]]) -> None:
    if not transcript:
        stream.write("Transcript: (empty)\n")
        stream.flush()
        return
    stream.write("Transcript:\n")
    for item in transcript:
        stream.write(f"- {item.get('timestamp')} [{item.get('role')}] {item.get('content')}\n")
    stream.flush()


def print_config_sources(stream: TextIO, sources: Sequence[ConfigSourceStatus]) -> None:
    if not sources:
        stream.write("config_sources: []\n")
        stream.flush()
        return
    stream.write("config_sources:\n")
    for source in sources:
        state = "valid" if source.valid else "invalid"
        exists = "present" if source.exists else "missing"
        suffix = f" ({source.error})" if source.error else ""
        stream.write(f"- {source.name}: {exists}, {state}, {source.path}{suffix}\n")
    stream.flush()


def print_doctor_report(stream: TextIO, payload: Mapping[str, Any]) -> None:
    stream.write(f"ok: {payload.get('ok')}\n")
    stream.write("critical_checks:\n")
    for item in payload.get("critical_checks", []) or []:
        suffix = f" ({item.get('detail')})" if item.get("detail") else ""
        stream.write(f"- {item.get('name')}: {item.get('ok')}{suffix}\n")
    stream.write("optional_checks:\n")
    for item in payload.get("optional_checks", []) or []:
        suffix = f" ({item.get('detail')})" if item.get("detail") else ""
        stream.write(f"- {item.get('name')}: {item.get('ok')}{suffix}\n")
    stream.write("model:\n")
    _write_value(stream, payload.get("model", {}) or {}, indent=2)
    stream.write("logging:\n")
    _write_value(stream, payload.get("logging", {}) or {}, indent=2)
    stream.write("paths:\n")
    _write_value(stream, payload.get("paths", {}) or {}, indent=2)
    print_config_sources(stream, [ConfigSourceStatus(**item) for item in payload.get("config_sources", []) or []])
    stream.flush()
