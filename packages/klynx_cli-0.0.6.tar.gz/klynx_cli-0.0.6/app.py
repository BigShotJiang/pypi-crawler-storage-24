"""Main Klynx Textual app."""

import os
import re
import sys
import threading
from queue import Empty, SimpleQueue
from typing import Any, Dict, List, Optional, Tuple

from dotenv import load_dotenv
from textual import work
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Input, Static

from klynx.agent.context_manager import TokenCounter
from klynx.model import MODEL_REGISTRY

from .config_screen import ConfigScreen
from .context_aware_suggester import ContextAwareSuggester
from .customization import (
    EventRenderer,
    RuntimeContext,
    TUIConfig,
    apply_bindings,
    apply_preprocessors,
    build_agent,
    build_preprocessor_chain,
    create_command_registry,
    load_tui_config,
    resolve_bindings,
)
from .env import resolve_env_file
from .stdout_redirector import StdoutRedirector
from .suggestion_input import SuggestionInput
from .wrapping_log import AutoWrapLog as RichLog

load_dotenv(resolve_env_file())
class KlynxTUIApp(App):
    """
    Single-pane Klynx Textual TUI.

    The transcript, progress markers, and final answers are rendered in one
    unified log view to keep output compact and readable.
    """
    
    CSS = """
    Screen {
        layout: vertical;
    }

    ConfigScreen {
        align: center middle;
    }

    #config-dialog {
        background: $surface;
        padding: 1 2;
        width: 60%;
        height: auto;
        border: thick $primary;
    }

    #config-title {
        text-style: bold;
        padding-bottom: 1;
        content-align: center middle;
        width: 100%;
    }

    #config-buttons {
        height: 3;
        margin-top: 1;
        align: center middle;
    }

    #config-buttons Button {
        margin: 0 1;
    }

    #main-area {
        height: 1fr;
    }

    #log-container,
    #activity-panel,
    #workspace-panel {
        height: 1fr;
        min-width: 24;
    }

    #log-container {
        width: 1fr;
        border: solid $accent;
        border-title-color: $text;
    }

    #agent-log {
        width: 100%;
        height: 1fr;
        overflow-y: auto;
    }

    #activity-panel {
        width: 36;
        border: solid $warning;
        border-title-color: $text;
        display: none;
        padding: 0 1;
    }

    #active-stream-container {
        width: 100%;
        height: 1fr;
        overflow-y: auto;
        display: none;
        margin: 0;
        padding: 0;
    }

    #stream-reasoning {
        color: $text-muted;
        text-style: italic;
    }

    #stream-answer {
        color: $text;
    }

    #workspace-panel {
        width: 1fr;
        border: solid $secondary;
        border-title-color: $text;
        display: none;
    }

    #tui-screen {
        width: 100%;
        height: 1fr;
        overflow-y: auto;
    }

    #main-area.layout-chat #activity-panel,
    #main-area.layout-chat #workspace-panel {
        display: none;
    }

    #main-area.layout-split #activity-panel,
    #main-area.layout-split #workspace-panel,
    #main-area.layout-inspect #activity-panel,
    #main-area.layout-inspect #workspace-panel {
        display: block;
    }

    #main-area.layout-focus-tui #workspace-panel {
        display: block;
        width: 2fr;
    }

    #main-area.layout-focus-tui #activity-panel {
        display: none;
    }

    #main-area.layout-focus-tui #log-container {
        width: 1fr;
    }

    #main-area.layout-inspect #log-container {
        width: 35%;
    }

    #main-area.layout-inspect #activity-panel {
        width: 28%;
    }

    #main-area.layout-inspect #workspace-panel {
        width: 37%;
    }

    #main-area.stacked-mode {
        layout: vertical;
    }

    #main-area.stacked-mode #log-container,
    #main-area.stacked-mode #activity-panel,
    #main-area.stacked-mode #workspace-panel {
        width: 100%;
        height: 1fr;
    }

    #input-area {
        height: 3;
        margin: 0;
        padding: 0;
    }

    #task-input {
        width: 1fr;
    }

    #status-bar {
        dock: bottom;
        height: 2;
        background: $surface;
        color: $text-muted;
        padding: 0 2;
    }
    """
    
    BINDINGS = []
    
    def __init__(
        self,
        model_provider: str = None,
        model_name: str = None,
        api_key: str = None,
        tavily_api_key: str = None,
        use_config: bool = True,
        **model_kwargs,
    ):
        super().__init__()
        
        # Load .env when present.
        env_file = resolve_env_file()
        if os.path.exists(env_file):
            load_dotenv(env_file)
            
        env_provider = os.environ.get("KLYNX_DEFAULT_PROVIDER")
        env_name = os.environ.get("KLYNX_DEFAULT_MODEL")
        normalized_provider = str(model_provider or "").strip() or None
        normalized_model_name = None
        if model_name is not None:
            normalized_model_name = str(model_name).strip() or None
        
        if env_provider:
            self.model_provider = normalized_provider or env_provider
            self.model_name = (
                normalized_model_name
                if model_name is not None
                else (str(env_name).strip() or None)
            )
        else:
            self.model_provider = normalized_provider or "deepseek"
            if model_name is not None:
                self.model_name = normalized_model_name
            elif normalized_provider:
                self.model_name = None
            else:
                self.model_name = "deepseek-reasoner"
        
        # If api_key is not provided, _init_agent -> setup_model will try os.environ.
        self.api_key = api_key
        self.tavily_api_key = tavily_api_key
        self.model_kwargs = model_kwargs
        self.use_config = bool(use_config)
        if self.use_config:
            self.tui_config = load_tui_config(os.getcwd())
        else:
            self.tui_config = TUIConfig()
        self._invoke_defaults = dict(self.tui_config.agent.invoke or {})

        import uuid
        self.thread_id = str(uuid.uuid4())[:8]
        self.agent = None
        self.accumulated_context = ""
        self.round_count = 0
        self.total_tokens = 0
        self._original_stdout = sys.stdout
        self._redirector = None
        self._last_screen_hash = {}  # {session_name: hash} for incremental UI update detection.
        self._last_response = ""  # Cache last assistant response for clipboard copy.
        self._token_buffer = ""
        self._reasoning_buffer = ""
        self.show_reasoning_tokens = bool(self.tui_config.output.show_reasoning_tokens)
        self.allow_text_metrics_fallback = bool(
            self.tui_config.output.allow_text_metrics_fallback
            or str(os.environ.get("KLYNX_TUI_TEXT_METRICS_FALLBACK", "")).strip().lower() in {"1", "true", "yes", "on"}
        )
        self._summary_emitted = False
        self._round_prompt_tokens = 0
        self._round_completion_tokens = 0
        self._round_usage_total_tokens = 0
        self._round_usage_event_count = 0
        self._latest_context_tokens = 0
        self._configured_context_max_tokens = 128000
        self._latest_context_max_tokens = self._configured_context_max_tokens
        self._latest_context_usage_pct = 0.0
        self._latest_context_breakdown = {}
        self._latest_tool_dedupe_hits = 0
        self._latest_repeated_read_hits = 0
        self._latest_stall_rounds = 0
        self._latest_read_coverage_files = 0
        self.is_processing = False  # Prevent duplicate submit while running.
        self.command_registry = self.create_command_registry()
        self._preprocessor_chain = self.create_preprocessor_chain()
        self._current_layout_mode = "chat"
        self.event_renderer = None
        self._ui_event_queue: SimpleQueue[dict] = SimpleQueue()
        self._ui_queue_timer = None
        self._draining_ui_queue = False
        self._ui_queue_max_events_per_tick = 512
        self._ui_stream_fps = self._resolve_stream_fps()
        self._ui_stream_interval = 1.0 / float(self._ui_stream_fps)
        self._ui_drain_signal_lock = threading.Lock()
        self._ui_drain_signal_pending = False
        self._ui_queue_size_lock = threading.Lock()
        self._ui_queue_size = 0

    @staticmethod
    def _resolve_stream_fps() -> int:
        raw = str(os.environ.get("KLYNX_TUI_STREAM_FPS", "60") or "").strip()
        try:
            fps = int(raw)
        except Exception:
            fps = 60
        return max(20, min(fps, 120))

    def _enqueue_ui_event(self, event: dict, *, urgent: bool = False) -> None:
        self._ui_event_queue.put(dict(event or {}))
        should_signal = False
        with self._ui_queue_size_lock:
            was_empty = self._ui_queue_size <= 0
            self._ui_queue_size += 1
            if urgent or was_empty:
                should_signal = True
        if should_signal:
            self._request_ui_drain()

    def _request_ui_drain(self) -> None:
        with self._ui_drain_signal_lock:
            if self._ui_drain_signal_pending:
                return
            self._ui_drain_signal_pending = True
        try:
            self.call_from_thread(self._drain_ui_event_queue)
        except Exception:
            with self._ui_drain_signal_lock:
                self._ui_drain_signal_pending = False

    def _clear_ui_event_queue(self) -> None:
        while True:
            try:
                self._ui_event_queue.get_nowait()
            except Empty:
                break
        with self._ui_queue_size_lock:
            self._ui_queue_size = 0
        with self._ui_drain_signal_lock:
            self._ui_drain_signal_pending = False

    @staticmethod
    def _coalesce_ui_events(events: List[dict]) -> List[dict]:
        if not events:
            return []

        merged: List[dict] = []
        token_chunks: List[str] = []
        token_chars = 0
        max_token_chars_per_chunk = 1024

        def flush_tokens() -> None:
            nonlocal token_chars
            if token_chunks:
                merged.append({"type": "token", "content": "".join(token_chunks)})
                token_chunks.clear()
                token_chars = 0

        for event in events:
            typ = str(event.get("type", "") or "")
            if typ == "token":
                chunk = str(event.get("content", "") or "")
                if chunk:
                    token_chunks.append(chunk)
                    token_chars += len(chunk)
                    if token_chars >= max_token_chars_per_chunk:
                        flush_tokens()
                continue

            flush_tokens()
            merged.append(event)

        flush_tokens()
        return merged

    def _drain_ui_event_queue(self) -> None:
        if self._draining_ui_queue:
            return

        self._draining_ui_queue = True
        try:
            pending: List[dict] = []
            for _ in range(self._ui_queue_max_events_per_tick):
                try:
                    pending.append(self._ui_event_queue.get_nowait())
                except Empty:
                    break

            if pending:
                with self._ui_queue_size_lock:
                    self._ui_queue_size = max(0, self._ui_queue_size - len(pending))

            if not pending:
                return

            for event in self._coalesce_ui_events(pending):
                typ = str(event.get("type", "") or "")
                if typ == "__round_done__":
                    self._on_agent_done(
                        dict(event.get("result", {}) or {}),
                        dict(event.get("state_values", {}) or {}),
                        int(event.get("round_tokens", 0) or 0),
                    )
                    continue
                if typ == "__agent_error__":
                    self._on_agent_error(str(event.get("error", "") or "Unknown error"))
                    continue
                self._handle_event(event)
        finally:
            self._draining_ui_queue = False
            with self._ui_drain_signal_lock:
                self._ui_drain_signal_pending = False
        with self._ui_queue_size_lock:
            queue_left = self._ui_queue_size > 0
        if queue_left:
            self._request_ui_drain()

    @staticmethod
    def _iter_env_keys(value) -> List[str]:
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item or "").strip()]
        text = str(value or "").strip()
        return [text] if text else []

    def _resolve_model_api_key(self) -> Optional[str]:
        if self.api_key:
            return str(self.api_key).strip() or None

        provider = str(self.model_provider or "").strip()
        model_name = str(self.model_name or "").strip()
        env_keys: List[str] = []

        if model_name and model_name in MODEL_REGISTRY:
            env_keys = self._iter_env_keys(MODEL_REGISTRY[model_name].get("env_key"))
        elif provider and provider in MODEL_REGISTRY:
            env_keys = self._iter_env_keys(MODEL_REGISTRY[provider].get("env_key"))
        else:
            route = f"{provider}/{model_name}" if provider and model_name else provider
            route = route.strip()
            if route:
                for config in MODEL_REGISTRY.values():
                    if str(config.get("model", "") or "").strip() == route:
                        env_keys = self._iter_env_keys(config.get("env_key"))
                        break

        for key in env_keys:
            value = str(os.environ.get(key, "") or "").strip()
            if value:
                return value
        return None

    def _resolve_model_auth_hint(self) -> tuple[str, List[str]]:
        """Return human-readable model label and candidate API key env vars."""
        provider = str(self.model_provider or "").strip()
        model_name = str(self.model_name or "").strip()
        route = f"{provider}/{model_name}" if provider and model_name else provider
        route = route.strip()

        config = None
        if model_name and model_name in MODEL_REGISTRY:
            config = MODEL_REGISTRY.get(model_name)
        elif provider and provider in MODEL_REGISTRY:
            config = MODEL_REGISTRY.get(provider)
        elif route:
            for item in MODEL_REGISTRY.values():
                if str(item.get("model", "") or "").strip() == route:
                    config = item
                    break

        env_keys: List[str] = []
        label = route or "selected model"
        if isinstance(config, dict):
            label = str(config.get("description") or config.get("model") or label)
            env_keys = self._iter_env_keys(config.get("env_key"))
        elif provider:
            # Fallback for custom providers not present in MODEL_REGISTRY.
            env_keys = [f"{provider.upper().replace('/', '_')}_API_KEY"]
        return label, env_keys

    def create_command_registry(self):
        return create_command_registry(self, self.tui_config)

    def create_preprocessor_chain(self):
        return build_preprocessor_chain(self, self.tui_config)

    def resolve_keybindings(self) -> Tuple[List[Dict[str, Any]], List[str]]:
        return resolve_bindings(self.tui_config)

    def create_event_renderer(self):
        return EventRenderer(self, self.tui_config.output)

    def create_agent_build_result(self, runtime: RuntimeContext):
        return build_agent(self.tui_config, runtime)

    def format_status(self, metrics: Dict[str, Any]) -> Optional[str]:
        _ = metrics
        return None

    @staticmethod
    def _to_int(value, default: int = 0) -> int:
        try:
            return int(value)
        except Exception:
            return default

    @staticmethod
    def _extract_usage_from_text(content: str) -> tuple[int, int, int]:
        prompt = 0
        completion = 0
        total = 0
        if not content:
            return prompt, completion, total

        prompt_match = re.search(r"Prompt\s*:\s*([\d,]+)", content, re.IGNORECASE)
        completion_match = re.search(r"Completion\s*:\s*([\d,]+)", content, re.IGNORECASE)
        total_match = re.search(r"Total\s*:\s*([\d,]+)", content, re.IGNORECASE)

        if prompt_match:
            prompt = int(prompt_match.group(1).replace(",", ""))
        if completion_match:
            completion = int(completion_match.group(1).replace(",", ""))
        if total_match:
            total = int(total_match.group(1).replace(",", ""))
        return prompt, completion, total

    def _accumulate_token_usage_event(self, event: dict) -> bool:
        """
        Accumulate per-iteration token usage from structured `token_usage` events.
        Only `usage_scope=inference` contributes to per-round prompt/completion totals.
        """
        scope = str(event.get("usage_scope", "") or "").strip().lower()
        if scope and scope not in {"inference", "model_inference", "iteration"}:
            return False

        prompt = self._to_int(event.get("prompt_tokens", 0), 0)
        completion = self._to_int(event.get("completion_tokens", 0), 0)
        total = self._to_int(event.get("total_tokens", 0), 0)

        if self.allow_text_metrics_fallback and prompt <= 0 and completion <= 0 and total <= 0:
            prompt, completion, total = self._extract_usage_from_text(str(event.get("content", "")))

        if prompt <= 0 and completion <= 0 and total <= 0:
            return False

        if total <= 0:
            total = max(prompt, 0) + max(completion, 0)
        if prompt <= 0 and total > 0:
            prompt = max(total - max(completion, 0), 0)
        if completion <= 0 and total > 0:
            completion = max(total - max(prompt, 0), 0)

        self._round_prompt_tokens += max(prompt, 0)
        self._round_completion_tokens += max(completion, 0)
        self._round_usage_total_tokens += max(total, 0)
        self._round_usage_event_count += 1
        return True

    @staticmethod
    def _extract_context_overview_from_text(content: str) -> tuple[int, int, float]:
        if not content:
            return 0, 0, 0.0

        patterns = [
            r"Token\s*:\s*([\d,]+)\s*/\s*([\d,]+)\s*\(([\d.]+)%\)",
            r"Token\s*usage\s*:\s*([\d,]+)\s*/\s*([\d,]+)\s*\(([\d.]+)%\)",
        ]
        for pattern in patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if not match:
                continue
            total = int(match.group(1).replace(",", ""))
            max_tokens = int(match.group(2).replace(",", ""))
            usage_pct = float(match.group(3))
            return total, max_tokens, usage_pct
        return 0, 0, 0.0

    @staticmethod
    def _extract_context_breakdown_from_text(content: str) -> dict:
        if not content:
            return {}
        if "breakdown" not in content.lower():
            return {}

        breakdown = {}
        for key, value in re.findall(r"([a-zA-Z0-9_]+)\s*:\s*([\d,]+)", content):
            try:
                breakdown[key] = int(value.replace(",", ""))
            except Exception:
                continue
        return breakdown

    @staticmethod
    def _extract_usage_from_text(content: str) -> tuple[int, int, int]:
        """Parse prompt/completion/total token usage from plain text metrics."""
        prompt = 0
        completion = 0
        total = 0
        if not content:
            return prompt, completion, total

        prompt_match = re.search(r"Prompt\s*:\s*([\d,]+)", content, re.IGNORECASE)
        completion_match = re.search(r"Completion\s*:\s*([\d,]+)", content, re.IGNORECASE)
        total_match = re.search(r"Total\s*:\s*([\d,]+)", content, re.IGNORECASE)

        if prompt_match:
            prompt = int(prompt_match.group(1).replace(",", ""))
        if completion_match:
            completion = int(completion_match.group(1).replace(",", ""))
        if total_match:
            total = int(total_match.group(1).replace(",", ""))
        return prompt, completion, total

    @staticmethod
    def _extract_context_overview_from_text(content: str) -> tuple[int, int, float]:
        """Parse context usage summary from text-only context stats."""
        if not content:
            return 0, 0, 0.0

        patterns = [
            r"Token\s*:\s*([\d,]+)\s*/\s*([\d,]+)\s*\(([\d.]+)%\)",
            r"Token\s*usage\s*:\s*([\d,]+)\s*/\s*([\d,]+)\s*\(([\d.]+)%\)",
        ]
        for pattern in patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if not match:
                continue
            total = int(match.group(1).replace(",", ""))
            max_tokens = int(match.group(2).replace(",", ""))
            usage_pct = float(match.group(3))
            return total, max_tokens, usage_pct
        return 0, 0, 0.0

    @staticmethod
    def _extract_context_breakdown_from_text(content: str) -> dict:
        """Parse context breakdown map from text-only context stats."""
        if not content:
            return {}
        if "breakdown" not in content.lower():
            return {}

        breakdown = {}
        for key, value in re.findall(r"([a-zA-Z0-9_]+)\s*:\s*([\d,]+)", content):
            try:
                breakdown[key] = int(value.replace(",", ""))
            except Exception:
                continue
        return breakdown

    def _accumulate_context_stats_event(self, event: dict) -> bool:
        content = str(event.get("content", "") or "")
        updated = False

        total = self._to_int(event.get("context_total_tokens", 0), 0)
        max_tokens = self._to_int(event.get("context_max_tokens", 0), 0)
        usage_pct_raw = event.get("context_usage_pct", None)
        usage_pct = None
        if usage_pct_raw is not None:
            try:
                usage_pct = float(usage_pct_raw)
            except Exception:
                usage_pct = None

        if self.allow_text_metrics_fallback and (total <= 0 or max_tokens <= 0):
            parsed_total, parsed_max, parsed_pct = self._extract_context_overview_from_text(content)
            if parsed_total > 0:
                total = parsed_total
            if parsed_max > 0:
                max_tokens = parsed_max
            if usage_pct is None and parsed_pct > 0:
                usage_pct = parsed_pct

        breakdown_raw = event.get("context_breakdown", {})
        breakdown = {}
        if isinstance(breakdown_raw, dict):
            for key, value in breakdown_raw.items():
                try:
                    breakdown[str(key)] = int(value)
                except Exception:
                    continue
        if self.allow_text_metrics_fallback and not breakdown:
            breakdown = self._extract_context_breakdown_from_text(content)

        usage_source = str(event.get("usage_source", "") or "").strip().lower()
        if usage_source == "estimate" and not self.allow_text_metrics_fallback:
            return False

        if total > 0:
            self._latest_context_tokens = total
            updated = True
        if max_tokens > 0:
            self._latest_context_max_tokens = max_tokens
            updated = True
        if breakdown:
            self._latest_context_breakdown = breakdown
            updated = True

        if usage_pct is not None:
            self._latest_context_usage_pct = max(0.0, usage_pct)
            updated = True
        elif self._latest_context_tokens > 0 and self._latest_context_max_tokens > 0:
            self._latest_context_usage_pct = (
                self._latest_context_tokens / self._latest_context_max_tokens * 100
            )

        return updated

    def _resolve_context_usage(self, state_values: Optional[dict] = None) -> tuple[int, int, float]:
        state_values = state_values or {}
        default_max_tokens = int(getattr(self, "_configured_context_max_tokens", 128000) or 128000)
        max_tokens = self._to_int(
            state_values.get("max_context_tokens", self._latest_context_max_tokens or default_max_tokens),
            default_max_tokens,
        )
        if max_tokens <= 0:
            max_tokens = default_max_tokens

        context_tokens = int(self._latest_context_tokens or 0)

        if context_tokens > 0:
            self._latest_context_tokens = context_tokens
            self._latest_context_max_tokens = max_tokens
            usage_pct = context_tokens / max_tokens * 100
            self._latest_context_usage_pct = usage_pct
            return context_tokens, max_tokens, usage_pct

        return 0, max_tokens, 0.0

    def _detect_agent_context_window(self) -> int:
        default_max_tokens = int(getattr(self, "_configured_context_max_tokens", 128000) or 128000)
        agent = getattr(self, "agent", None)
        if agent is None:
            return default_max_tokens

        candidates: List[Any] = [agent]
        backend = getattr(agent, "backend", None)
        if backend is not None:
            candidates.append(backend)
            backend_model = getattr(backend, "model", None)
            if backend_model is not None:
                candidates.append(backend_model)
        agent_model = getattr(agent, "model", None)
        if agent_model is not None:
            candidates.append(agent_model)

        for target in candidates:
            for attr_name in ("max_context_tokens", "context_window", "max_tokens"):
                raw_value = getattr(target, attr_name, None)
                parsed = self._to_int(raw_value, 0)
                if parsed > 0:
                    return parsed

        return default_max_tokens

    def _format_messages(self, messages: list) -> str:
        """Build compact plain-text context from message history."""
        context = ""
        for msg in messages:
            role = "User"
            if hasattr(msg, "type"):
                if msg.type == "human":
                    role = "User"
                elif msg.type == "ai":
                    role = "Assistant"
                elif msg.type == "system":
                    role = "System"
                elif msg.type == "tool":  # LangChain tool message
                    role = "Tool"
            
            content = getattr(msg, "content", str(msg))
            context += f"\n[{role}]: {content}\n"
        return context.strip()

    def get_skill_names(self) -> list:
        """Return the current skill names exposed by the active agent."""
        if not self.agent or not hasattr(self.agent, "skill_registry"):
            return []
        return sorted(self.agent.skill_registry.keys())

    def get_command_suggestions(self) -> list:
        """Return slash command suggestions for input completion."""
        if self.command_registry:
            suggestions = self.command_registry.command_suggestions()
            if "/context" in suggestions and "/context full" not in suggestions:
                suggestions.append("/context full")
            return sorted(suggestions)
        return []
    
    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="main-area"):
            with Vertical(id="log-container"):
                yield RichLog(id="agent-log", highlight=False)
        yield Static(
            f"Round: 0 | Token: 0 | Context: 0/{int(self._latest_context_max_tokens or 128000)} (0.0%)",
            id="status-bar",
        )

        with Horizontal(id="input-area"):
            yield SuggestionInput(
                placeholder="Enter task /slash command or @file or $skill ...",
                id="task-input",
                suggester=ContextAwareSuggester(self)
            )
        yield Footer()
    
    
    def on_mount(self) -> None:
        """Initialize app state after mount."""
        self.title = "Klynx Agent TUI"
        
        log_container = self.query_one("#log-container", Vertical)
        log_container.border_title = "Transcript"
        
        log = self.query_one("#agent-log", RichLog)
        self.event_renderer = self.create_event_renderer()

        bindings, binding_warnings = self.resolve_keybindings()
        apply_bindings(self, bindings)
        for warning in binding_warnings:
            log.write(f"[config] {warning}\n")
        
        self._redirector = StdoutRedirector(self, self._original_stdout)
        sys.stdout = self._redirector
        
        self._init_agent()

        self.set_layout_mode(self.tui_config.ui.layout_mode)

        self._ui_queue_timer = self.set_interval(
            self._ui_stream_interval,
            self._drain_ui_event_queue,
            pause=False,
        )
        
        self.query_one("#task-input", Input).focus()
        
    def action_toggle_split(self):
        """Action for F2 binding"""
        log = self.query_one("#agent-log", RichLog)
        log.write("[system] Single-pane transcript view is enabled.")

    def on_resize(self, event) -> None:
        _ = event
        if getattr(self, "_current_layout_mode", None):
            self.set_layout_mode(self._current_layout_mode)

    def action_copy_last(self):
        """Action for Ctrl+Shift+C binding"""
        log = self.query_one("#agent-log", RichLog)
        if self._last_response:
            self.copy_to_clipboard(self._last_response)
            log.write("[system] Copied the latest response to the clipboard.")
        else:
            log.write("[system] No response is available to copy yet.")
            
    def action_interrupt_agent(self):
        """Action for Ctrl+C binding"""
        if self.is_processing and self.agent:
            log = self.query_one("#agent-log", RichLog)
            log.write("[system] Interrupting current task...")
            if hasattr(self.agent, "_cancel_event"):
                self.agent._cancel_event.set()
        else:
            self.query_one("#agent-log", RichLog).write("[system] No task is running. Use /quit to exit.")
            
    def set_layout_mode(self, mode: str) -> str:
        """Set the active layout preset for the main workspace."""
        _ = mode
        self._current_layout_mode = "chat"
        return "Single-pane transcript view is enabled."

    def _init_agent(self):
        """Initialize the agent and bind the current runtime state."""
        log = self.query_one("#agent-log", RichLog)

        
        working_dir = os.getcwd()
        
        try:
            # Clean previous TUI sessions before rebuilding agent.
            if self.agent and hasattr(self.agent, "tui_manager"):
                try:
                    for session in list(getattr(self.agent.tui_manager, "sessions", {}).values()):
                        try:
                            session.close()
                        except Exception:
                            pass
                    if hasattr(self.agent.tui_manager, "sessions"):
                        self.agent.tui_manager.sessions.clear()
                except Exception:
                    pass
            self._last_screen_hash = {}
            runtime_api_key = self._resolve_model_api_key()
            runtime = RuntimeContext(
                working_dir=working_dir,
                model_provider=self.model_provider,
                model_name=self.model_name,
                api_key=runtime_api_key,
                tavily_api_key=self.tavily_api_key,
                model_kwargs=dict(self.model_kwargs),
                max_iterations=None,
                memory_dir=working_dir,
                load_project_docs=False,
                set_layout_mode=None,
                tui_screen_update_callback=None,
            )
            build_result = self.create_agent_build_result(runtime)
            self.agent = build_result.agent
            detected_context_max = self._detect_agent_context_window()
            if detected_context_max > 0:
                self._configured_context_max_tokens = detected_context_max
                if int(self._latest_context_tokens or 0) <= 0:
                    self._latest_context_max_tokens = detected_context_max
            for warning in build_result.warnings:
                log.write(f"[config] {warning}\n")
            self._update_status()
        except ValueError as e:
            if "API Key" in str(e):
                model_label, env_keys = self._resolve_model_auth_hint()
                env_text = " / ".join(env_keys) if env_keys else "(provider specific key)"
                log.write(f"[system] Missing API key for current model: {model_label}")
                log.write(f"[system] Please set environment variable: {env_text}")
                log.write("[system] Opening the API key configuration screen...")
                self.push_screen(ConfigScreen())
            else:
                log.write(f"[error] Agent initialization failed: {e}")
        except Exception as e:
            log.write(f"[error] Agent initialization failed: {e}")
    
    def _on_tui_screen_update(self, name: str, lines: list, cursor_row: int, cursor_col: int):
        """Single-pane mode ignores workspace screen updates."""
        _ = name, lines, cursor_row, cursor_col
    
    def _update_tui_widget(self, name: str, lines: list, cursor_row: int, cursor_col: int):
        """Single-pane mode ignores workspace screen updates."""
        _ = name, lines, cursor_row, cursor_col
    
    def _refresh_tui_screen(self):
        """Single-pane mode does not render workspace screen data."""
        return
    
    def _update_status(self):
        """Refresh bottom status bar."""
        ctx_tokens, max_tokens, usage_pct = self._resolve_context_usage()
        status = self.query_one("#status-bar", Static)
        metrics = {
            "round": self.round_count,
            "total_tokens": self.total_tokens,
            "context_tokens": ctx_tokens,
            "context_max_tokens": max_tokens,
            "context_usage_pct": usage_pct,
            "tool_dedupe_hits": self._latest_tool_dedupe_hits,
            "repeated_read_hits": self._latest_repeated_read_hits,
            "stall_rounds": self._latest_stall_rounds,
            "read_coverage_files": self._latest_read_coverage_files,
            "model_provider": self.model_provider,
            "model_name": self.model_name,
            "thread_id": self.thread_id,
        }
        custom_status = self.format_status(metrics)
        if custom_status:
            status.update(custom_status)
            return

        field_map = {
            "round": f"Round: {self.round_count}",
            "total_tokens": f"Token: {self.total_tokens}",
            "context_usage": (
                f"Context: {ctx_tokens}/{max_tokens} ({usage_pct:.1f}%)"
                if ctx_tokens > 0
                else f"Context: unknown/{max_tokens}"
            ),
            "model": (
                f"Model: {self.model_provider}/{self.model_name}"
                if self.model_name
                else f"Model: {self.model_provider}"
            ),
            "convergence": (
                f"Convergence: dedupe={self._latest_tool_dedupe_hits}, repeat_read={self._latest_repeated_read_hits}, stall={self._latest_stall_rounds}"
            ),
            "coverage": f"Coverage: files={self._latest_read_coverage_files}",
            "thread_id": f"Thread: {self.thread_id}",
        }
        fields = self.tui_config.output.status_fields or ["round", "total_tokens", "context_usage"]
        parts = [field_map[field] for field in fields if field in field_map]
        status.update(" | ".join(parts))

    def _cmd_quit(self, args: list, raw: str) -> None:
        self.exit()

    def _cmd_clear(self, args: list, raw: str) -> None:
        log = self.query_one("#agent-log", RichLog)
        log.clear()
        import uuid

        self.thread_id = str(uuid.uuid4())[:8]
        self.accumulated_context = ""
        self.total_tokens = 0
        self._latest_context_tokens = 0
        self._latest_context_max_tokens = int(getattr(self, "_configured_context_max_tokens", 128000) or 128000)
        self._latest_context_usage_pct = 0.0
        self._latest_context_breakdown = {}
        self._latest_tool_dedupe_hits = 0
        self._latest_repeated_read_hits = 0
        self._latest_stall_rounds = 0
        self._latest_read_coverage_files = 0
        self.round_count = 0
        log.write(f"[system] Log and context cleared, new session started (thread: {self.thread_id})")
        self._update_status()

    def _cmd_model(self, args: list, raw: str) -> None:
        log = self.query_one("#agent-log", RichLog)
        if getattr(self, "is_processing", False):
            log.write("[system] A task is running, so the model cannot be changed right now.")
            return
        self.push_screen(ConfigScreen())

    def _cmd_context(self, args: list, raw: str) -> None:
        log = self.query_one("#agent-log", RichLog)
        is_full = any(str(arg).lower() == "full" for arg in args)
        state_values = self.agent.get_context(thread_id=self.thread_id) if self.agent else {}

        if not state_values:
            log.write("[Current Context]\n(empty, no history yet)\n")
            return

        msgs = state_values.get("messages", [])
        context_tokens, max_tokens, usage_pct = self._resolve_context_usage(state_values)
        goal = state_values.get("overall_goal", "")

        info = f"Thread ID: {self.thread_id}\n"
        info += f"History messages: {len(msgs)}\n"
        if context_tokens > 0:
            info += f"Context usage: {context_tokens:,}/{max_tokens:,} tokens ({usage_pct:.1f}%)\n"
        else:
            info += f"Context usage: unknown/{max_tokens:,}\n"
        if self._latest_context_breakdown:
            stats_str = " | ".join(
                f"{k}: {v:,}" for k, v in self._latest_context_breakdown.items()
            )
            info += f"Breakdown: {stats_str}\n"
        info += f"Current goal: {goal if goal else '(none)'}\n"
        log.write(f"[Current Context]\n{info}\n")

        if is_full and msgs:
            full_content = ""
            show_thinking = state_values.get("thinking_context", True)
            for i, record in enumerate(msgs):
                role = record.__class__.__name__.replace("Message", "")
                reasoning = ""
                if show_thinking and hasattr(record, "additional_kwargs") and record.additional_kwargs:
                    reasoning = record.additional_kwargs.get("reasoning_content", "")
                content_str = str(record.content)
                if reasoning:
                    content_str = f"<think>\n{reasoning}\n</think>\n{content_str}"
                if len(content_str) > 5000:
                    content_str = content_str[:5000] + "\n... (truncated)"
                full_content += f"[{i+1}] [{role}]:\n{content_str}\n{'-'*40}\n"
            log.write(f"[Full Conversation]\n{full_content}\n")
            return

        if msgs:
            recent = msgs[-2:]
            preview = ""
            show_thinking = state_values.get("thinking_context", True)
            for record in recent:
                role = record.__class__.__name__.replace("Message", "")
                reasoning = ""
                if show_thinking and hasattr(record, "additional_kwargs") and record.additional_kwargs:
                    reasoning = record.additional_kwargs.get("reasoning_content", "")
                content_str = str(record.content)
                if reasoning:
                    content_str = f"<think>...</think> {content_str}"
                content_preview = str(content_str)[:100].replace("\n", " ") + "..."
                preview += f"[{role}]: {content_preview}\n"
            preview += "\n(Hint: use '/context full' to inspect the full conversation history.)"
            log.write(f"[Recent Messages]\n{preview}\n")

    def _cmd_copy(self, args: list, raw: str) -> None:
        log = self.query_one("#agent-log", RichLog)
        if self._last_response:
            self.copy_to_clipboard(self._last_response)
            log.write("[system] Copied the latest response to the clipboard.")
        else:
            log.write("[system] No response is available to copy yet.")

    def _cmd_help(self, args: list, raw: str) -> None:
        log = self.query_one("#agent-log", RichLog)
        if self.command_registry:
            log.write(self.command_registry.render_help())
            return
        log.write("[system] No help is currently available.")

    def _cmd_mode(self, args: list, raw: str) -> None:
        log = self.query_one("#agent-log", RichLog)
        _ = args, raw
        msg = self.set_layout_mode("chat")
        log.write(f"[system] {msg}")

    def _cmd_compact(self, args: list, raw: str) -> None:
        log = self.query_one("#agent-log", RichLog)
        if getattr(self, "is_processing", False):
            log.write("[system] A task is running, so context compaction is unavailable.")
            return
        self.is_processing = True
        self._run_compact()
    
    def on_input_submitted(self, event: Input.Submitted):
        """Handle user input."""
        task = event.value.strip()
        if not task:
            return
            
        event.input.value = ""
        
        if task.startswith("/"):
            if self.command_registry and self.command_registry.dispatch(task):
                return
            self.query_one("#agent-log", RichLog).write(
                f"[error] Unknown command: {task.split(' ')[0].lower()}, use /help for available commands."
            )
            return

        if getattr(self, "is_processing", False):
            log = self.query_one("#agent-log", RichLog)
            log.write("[system] A task is still running. Please wait...\n")
            return

        self.is_processing = True
        self._clear_ui_event_queue()

        self.round_count += 1
        self.query_one("#status-bar").update(f"Round: {self.round_count} | Running...")
        
        # Show user input in transcript.
        log = self.query_one("#agent-log", RichLog)
        log.write(f"\nUSER (Round {self.round_count})> {task}\n")
        
        task, preprocess_notes = apply_preprocessors(task, self, self._preprocessor_chain)
        for note in preprocess_notes:
            log.write(f"{note}\n")

        self._run_agent(task)
    
    @work(thread=True, exclusive=True)
    def _run_agent(self, task: str) -> None:
        """Run the active agent in a worker thread so the UI stays responsive."""
        try:
            # Reset streaming flags/buffers for this round.
            self._has_streamed_tokens = False
            self._has_streamed_reasoning = False
            self._summary_emitted = False
            self._round_prompt_tokens = 0
            self._round_completion_tokens = 0
            self._round_usage_total_tokens = 0
            self._round_usage_event_count = 0
            self._token_buffer = ""
            self._reasoning_buffer = ""
            self._last_response = ""  # Clear last response before receiving new output.
            
            # Clear possible leftover cancel flag.
            if hasattr(self.agent, "_cancel_event"):
                self.agent._cancel_event.clear()
            
            # Stream agent events.
            invoke_kwargs = dict(self._invoke_defaults)
            invoke_kwargs.setdefault("thinking_context", False)
            reasoning_indicator_emitted = False

            for event in self.agent.invoke(
                task=task,
                thread_id=self.thread_id, 
                **invoke_kwargs
            ):
                event_type = str(event.get("type", "") or "")
                if event_type == "token":
                    self._enqueue_ui_event(event)
                    continue

                if event_type == "reasoning_token":
                    if not reasoning_indicator_emitted and str(event.get("content", "") or ""):
                        self._enqueue_ui_event({"type": "reasoning_token", "content": "."}, urgent=True)
                        reasoning_indicator_emitted = True
                    continue

                self._enqueue_ui_event(event, urgent=True)
                
                if event_type == "done":
                    # Final event carries completion payload.
                    result = event
                    
                    # Pull latest state snapshot.
                    state_values = self.agent.get_context(thread_id=self.thread_id)
                    
                    # Update plain-text context cache for legacy helpers.
                    messages = state_values.get("messages", [])
                    if messages:
                        self.accumulated_context = self._format_messages(messages)
                    else:
                        self.accumulated_context = ""

                    round_tokens = int(result.get("total_tokens", 0) or 0)

                    # Defer finalization to the UI queue so it runs after `done` rendering.
                    self._enqueue_ui_event(
                        {
                            "type": "__round_done__",
                            "result": result,
                            "state_values": state_values,
                            "round_tokens": round_tokens,
                        },
                        urgent=True,
                    )
                    break  # Stop after done event to avoid duplicate handling.
            
        except Exception as e:
            self._enqueue_ui_event({"type": "__agent_error__", "error": str(e)}, urgent=True)
            import traceback
            traceback.print_exc()

    def _handle_event(self, event: dict):
        """Route one agent event through the configured renderer."""
        if self.event_renderer is None:
            self.event_renderer = EventRenderer(self, self.tui_config.output)
        self.event_renderer.handle(event)

    def _on_agent_done(self, result: dict, state_values: dict, round_tokens: int):
        """Handle completion of one agent run."""
        self._token_buffer = ""
        self._reasoning_buffer = ""

        last_prompt_tokens = int(result.get("prompt_tokens", 0) or 0)
        round_tokens = int(round_tokens or 0)
        round_prompt_sum = int(getattr(self, "_round_prompt_tokens", 0) or 0)
        round_completion_sum = int(getattr(self, "_round_completion_tokens", 0) or 0)
        round_usage_total_sum = int(getattr(self, "_round_usage_total_tokens", 0) or 0)
        usage_events = int(getattr(self, "_round_usage_event_count", 0) or 0)
        resolved_round_tokens = round_tokens
        if round_usage_total_sum > 0:
            resolved_round_tokens = round_usage_total_sum
        elif round_prompt_sum > 0 or round_completion_sum > 0:
            resolved_round_tokens = round_prompt_sum + round_completion_sum

        context_tokens, max_tokens, usage_pct = self._resolve_context_usage(state_values)
        _ = last_prompt_tokens, context_tokens, max_tokens, usage_pct, usage_events
        read_coverage = state_values.get("read_coverage", {}) or {}
        if isinstance(read_coverage, dict):
            self._latest_read_coverage_files = len(read_coverage)
        else:
            self._latest_read_coverage_files = 0
        self._latest_tool_dedupe_hits = int(state_values.get("tool_dedupe_hits", 0) or 0)
        self._latest_repeated_read_hits = int(state_values.get("repeated_read_hits", 0) or 0)
        self._latest_stall_rounds = int(state_values.get("stall_rounds", 0) or 0)

        self.total_tokens += resolved_round_tokens
        self.is_processing = False
        log = self.query_one("#agent-log", RichLog)
        log.write(
            f"\n[system] ===== Round {self.round_count} completed "
            f"(this round tokens: {resolved_round_tokens}, total: {self.total_tokens}) =====\n"
        )
        self._update_status()

    def _on_agent_error(self, error_msg: str):
        """Handle agent runtime error."""
        self.is_processing = False
        log = self.query_one("#agent-log", RichLog)
        log.write(f"[error] {error_msg}")
    
    def action_clear_log(self):
        """Ctrl+L clear log."""
        log = self.query_one("#agent-log", RichLog)
        log.clear()
    
    def on_unmount(self) -> None:
        """Restore stdout when app exits."""
        if self._ui_queue_timer is not None:
            try:
                self._ui_queue_timer.stop()
            except Exception:
                pass
        self._clear_ui_event_queue()
        sys.stdout = self._original_stdout



    @work(thread=True)
    def _run_compact(self) -> None:
        """Run context compaction in a worker thread."""
        log = self.query_one("#agent-log", RichLog)
        
        try:
            log.write("[system] Compacting context, please wait...\n")
            status_msg, summary = self.agent.compact_context(self.thread_id)
            
            # Drain buffered events produced during compaction.
            while self.agent._event_buffer:
                event = self.agent._event_buffer.pop(0)
                self.call_from_thread(self._handle_event, event)
                
            log.write(f"[system] {status_msg}\n")
            
            # Keep TUI context cache aligned with compaction summary.
            if summary:
                old_tokens = TokenCounter.estimate_tokens(self.accumulated_context) if self.accumulated_context else 0
                self.accumulated_context = f"<context_summary>\n{summary}\n</context_summary>"
                new_tokens = TokenCounter.estimate_tokens(self.accumulated_context)
                log.write(f"[system] Context updated: {old_tokens} -> {new_tokens} tokens\n")
        except Exception as e:
            log.write(f"[error] Context compaction failed: {e}")
        finally:
            self.is_processing = False
            self._update_status()


