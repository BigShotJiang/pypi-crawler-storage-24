from __future__ import annotations

import argparse
import inspect
import getpass
import os
import shutil
import sys
from typing import Any, Dict, Iterable, Optional, Sequence, TextIO

from dotenv import set_key, unset_key

from klynx.model import MODEL_REGISTRY

from .command_specs import root_command_words, root_help_epilog
from .config import config_paths_payload, save_config_patch, validate_config_sources
from .context import LOG_LEVEL_NAMES, CliContext, build_cli_context
from .output import (
    EXIT_CONFIG,
    EXIT_FAILURE,
    EXIT_NOT_FOUND,
    EXIT_OK,
    EXIT_USAGE,
    json_dump,
    print_doctor_report,
    print_kv,
    print_nested_mapping,
    print_session_table,
    print_transcript,
)
from .runtime import (
    HumanRunPrinter,
    RunDisplayOptions,
    _parse_model_reference,
    build_agent_runtime,
    build_system_prompt_append,
)

SUBCOMMANDS = set(root_command_words())
_OPTIONS_WITH_VALUE = {
    "-C",
    "--cd",
    "-c",
    "--log-level",
    "-m",
    "--model",
    "--provider",
    "--session",
    "--env-key",
    "--api-key",
    "--scope",
}


def _join_message(parts: Sequence[str], stdin: TextIO) -> str:
    text = " ".join(str(item or "") for item in parts).strip()
    if text:
        return text
    if not stdin.isatty():
        return stdin.read().strip()
    return ""


def _common_parent() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-C", "--cd", dest="cwd", default=argparse.SUPPRESS, help="Working directory")
    parser.add_argument("-c", dest="config_overrides", action="append", default=argparse.SUPPRESS, help="Inline config override key=value")
    parser.add_argument("--log-level", choices=LOG_LEVEL_NAMES, default=argparse.SUPPRESS, help="CLI logging verbosity")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--print-logs", dest="print_logs", action="store_true", default=argparse.SUPPRESS, help="Echo CLI logs to stderr")
    group.add_argument("--no-print-logs", dest="print_logs", action="store_false", default=argparse.SUPPRESS, help="Do not echo CLI logs to stderr")
    return parser


def _build_default_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="klynx",
        description="Klynx unified CLI (default behavior launches the TUI).",
        formatter_class=argparse.RawTextHelpFormatter,
        parents=[_common_parent()],
        epilog=root_help_epilog(),
    )
    parser.add_argument("-m", "--model", dest="model", default=None, help="Model alias or provider/model")
    parser.add_argument("--provider", default=None, help="Model provider override")
    parser.add_argument("--session", default=None, help="Use an existing session id")
    parser.add_argument("--last", action="store_true", help="Reuse the most recent session")
    parser.add_argument("prompt", nargs="*", help="Optional initial prompt to submit after the TUI launches")
    return parser


def _build_command_parser() -> argparse.ArgumentParser:
    common_parent = _common_parent()
    parser = argparse.ArgumentParser(
        prog="klynx",
        formatter_class=argparse.RawTextHelpFormatter,
        parents=[common_parent],
        epilog=root_help_epilog(),
    )
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    run_parser = subparsers.add_parser("run", parents=[common_parent], help="Run non-interactively")
    run_parser.add_argument("-m", "--model", default=None, help="Model alias or provider/model")
    run_parser.add_argument("--provider", default=None, help="Model provider override")
    run_parser.add_argument("--session", default=None, help="Existing session id")
    run_parser.add_argument("--resume", nargs="?", const="__last__", default=None, help="Resume a prior session id, or the most recent if omitted")
    run_parser.add_argument("--last", action="store_true", help="Use the most recent session")
    run_parser.add_argument("--json", action="store_true", help="Emit JSON output")
    run_parser.add_argument("--show-reasoning", action="store_true", help="Show reasoning events in terminal output")
    run_parser.add_argument("--show-tools", action="store_true", help="Show concise tool execution progress")
    run_parser.add_argument("--show-tool-output", action="store_true", help="Show truncated tool result previews")
    run_parser.add_argument("--tool-output-lines", type=int, default=8, help="Max lines to print for each tool result preview")
    run_parser.add_argument("--search", action="store_true", help="Enable web_search tool")
    run_parser.add_argument("--mode", choices=["build", "plan", "ask"], default="build", help="Execution mode")
    run_parser.add_argument("--approval", choices=["manual", "on-request", "auto"], default="auto", help="Approval preset")
    run_parser.add_argument("--add-dir", dest="additional_dirs", action="append", default=[], help="Allow access to an additional directory")
    run_parser.add_argument("message", nargs="*", help="Task or message to run")

    resume_parser = subparsers.add_parser("resume", parents=[common_parent], help="Resume a session in the TUI")
    resume_parser.add_argument("session_id", nargs="?", default=None)
    resume_parser.add_argument("--last", action="store_true", help="Resume the most recent session")
    resume_parser.add_argument("-m", "--model", default=None)
    resume_parser.add_argument("--provider", default=None)

    session_parser = subparsers.add_parser("session", parents=[common_parent], help="Manage saved sessions")
    session_sub = session_parser.add_subparsers(dest="session_cmd", required=True)
    session_list = session_sub.add_parser("list", help="List sessions")
    session_list.add_argument("--json", action="store_true")
    session_show = session_sub.add_parser("show", help="Show session metadata and transcript")
    session_show.add_argument("session_id", nargs="?", default=None)
    session_show.add_argument("--last", action="store_true")
    session_show.add_argument("--json", action="store_true")
    session_show.add_argument("--limit", type=int, default=20)
    session_delete = session_sub.add_parser("delete", help="Delete a session")
    session_delete.add_argument("session_id")
    session_delete.add_argument("--json", action="store_true")
    session_compact = session_sub.add_parser("compact", help="Compact context for a saved session")
    session_compact.add_argument("session_id", nargs="?", default=None)
    session_compact.add_argument("--last", action="store_true")
    session_compact.add_argument("-m", "--model", default=None)
    session_compact.add_argument("--provider", default=None)
    session_compact.add_argument("--json", action="store_true")

    auth_parser = subparsers.add_parser("auth", parents=[common_parent], help="Manage API keys")
    auth_sub = auth_parser.add_subparsers(dest="auth_cmd", required=True)
    auth_status = auth_sub.add_parser("status", help="Show configured API keys")
    auth_status.add_argument("--json", action="store_true")
    auth_login = auth_sub.add_parser("login", help="Write an API key to a .env file")
    auth_login.add_argument("--model", default=None, help="Model alias to infer env key from")
    auth_login.add_argument("--env-key", default=None, help="Explicit env var to write")
    auth_login.add_argument("--api-key", default=None, help="API key value (prompt if omitted)")
    auth_login.add_argument("--scope", choices=["global", "project"], default="global")
    auth_logout = auth_sub.add_parser("logout", help="Remove an API key from a .env file")
    auth_logout.add_argument("--model", default=None)
    auth_logout.add_argument("--env-key", default=None)
    auth_logout.add_argument("--scope", choices=["global", "project"], default="global")

    models_parser = subparsers.add_parser("models", parents=[common_parent], help="Inspect model registry and defaults")
    models_sub = models_parser.add_subparsers(dest="models_cmd", required=True)
    models_list = models_sub.add_parser("list", help="List known model aliases")
    models_list.add_argument("--json", action="store_true")
    models_show = models_sub.add_parser("show", help="Show current default model")
    models_show.add_argument("--json", action="store_true")
    models_set = models_sub.add_parser("set", help="Persist a default model")
    models_set.add_argument("model")
    models_set.add_argument("--provider", default=None)
    models_set.add_argument("--scope", choices=["global", "project"], default="global")

    config_parser = subparsers.add_parser("config", parents=[common_parent], help="Inspect effective config")
    config_sub = config_parser.add_subparsers(dest="config_cmd", required=True)
    config_show = config_sub.add_parser("show", help="Show effective config")
    config_show.add_argument("--json", action="store_true")
    config_path = config_sub.add_parser("path", help="Show config/env/session paths")
    config_path.add_argument("--json", action="store_true")
    config_validate = config_sub.add_parser("validate", help="Validate config loading")
    config_validate.add_argument("--json", action="store_true")

    doctor_parser = subparsers.add_parser("doctor", parents=[common_parent], help="Run environment diagnostics")
    doctor_parser.add_argument("--json", action="store_true")

    completion_parser = subparsers.add_parser("completion", parents=[common_parent], help="Generate shell completion")
    completion_parser.add_argument("shell", choices=["bash", "powershell"])

    tui_parser = subparsers.add_parser("tui", parents=[common_parent], help="Launch the TUI explicitly")
    tui_parser.add_argument("-m", "--model", dest="model", default=None)
    tui_parser.add_argument("--provider", default=None)
    tui_parser.add_argument("--session", default=None)
    tui_parser.add_argument("--last", action="store_true")
    tui_parser.add_argument("prompt", nargs="*", help="Optional initial prompt")

    return parser


def _first_positional_token(args_list: Sequence[str]) -> Optional[str]:
    skip_next = False
    force_default = False
    for token in args_list:
        if force_default:
            return None
        if skip_next:
            skip_next = False
            continue
        if token == "--":
            force_default = True
            continue
        if token in _OPTIONS_WITH_VALUE:
            skip_next = True
            continue
        if any(token.startswith(option + "=") for option in _OPTIONS_WITH_VALUE if option.startswith("--")):
            continue
        if token.startswith("-"):
            continue
        return token
    return None


def _looks_like_subcommand(args_list: Sequence[str]) -> bool:
    token = _first_positional_token(args_list)
    return token in SUBCOMMANDS if token else False


def _resolve_session_id(context: CliContext, session_id: Optional[str], use_last: bool) -> Optional[str]:
    if session_id:
        return str(session_id).strip()
    if use_last:
        record = context.session_manager.latest_session(cwd=str(context.resolved.cwd)) or context.session_manager.latest_session()
        if record:
            return str(record.get("session_id", "") or "").strip() or None
    return None


def _infer_env_key(model_alias: Optional[str], explicit_env_key: Optional[str]) -> str:
    if explicit_env_key:
        return str(explicit_env_key).strip()
    alias = str(model_alias or "").strip()
    if alias and alias in MODEL_REGISTRY:
        env_key = MODEL_REGISTRY[alias].get("env_key")
        if isinstance(env_key, list) and env_key:
            return str(env_key[0]).strip()
        if isinstance(env_key, str) and env_key.strip():
            return env_key.strip()
    raise ValueError("Please pass --env-key or --model to resolve the target API key")


def _completion_script(shell: str) -> str:
    words = " ".join(root_command_words())
    if shell == "bash":
        return (
            "_klynx_complete() {\n"
            "  local cur=\"${COMP_WORDS[COMP_CWORD]}\"\n"
            f"  COMPREPLY=( $(compgen -W \"{words}\" -- \"$cur\") )\n"
            "}\n"
            "complete -F _klynx_complete klynx\n"
            "complete -F _klynx_complete klynx-cli\n"
        )
    quoted_words = ",".join(repr(item) for item in root_command_words())
    return (
        f"$klynxCommands = {quoted_words}\n"
        "Register-ArgumentCompleter -CommandName klynx,klynx-cli -ScriptBlock {\n"
        "  param($wordToComplete)\n"
        "  $klynxCommands | Where-Object { $_ -like \"$wordToComplete*\" } | ForEach-Object {\n"
        "    [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)\n"
        "  }\n"
        "}\n"
    )


def launch_tui_app(*, resolved, session_manager, session_id: Optional[str], provider: Optional[str], model_name: Optional[str], prompt: str) -> int:
    target_session_id = session_id or session_manager.new_session_id()
    record = session_manager.load_session(target_session_id) or {}
    selection = _parse_model_reference(model_name, provider, resolved, record)
    provider_name = str(selection.provider or "").strip() or resolved.model_provider
    model_name_value = selection.model_name
    session_model_name = model_name_value
    if session_model_name is None and provider_name in MODEL_REGISTRY:
        session_model_name = ""

    session_manager.ensure_session(
        target_session_id,
        cwd=str(resolved.cwd),
        provider=provider_name,
        model_name=session_model_name,
        mode="tui",
        title=prompt or None,
    )
    os.chdir(str(resolved.cwd))
    from klynx_cli.app import KlynxTUIApp

    tui_kwargs = {
        "model_provider": provider_name,
        "model_name": model_name_value,
        "initial_prompt": prompt,
        "thread_id": target_session_id,
        "checkpointer": session_manager.checkpointer,
        "store": session_manager.store,
        "session_manager": session_manager,
    }
    signature = inspect.signature(KlynxTUIApp)
    filtered_kwargs = {key: value for key, value in tui_kwargs.items() if key in signature.parameters}
    app = KlynxTUIApp(**filtered_kwargs)
    app.run()
    return EXIT_OK

def _handle_run(args, *, context: CliContext, stdout: TextIO, stderr: TextIO, stdin: TextIO) -> int:
    message = _join_message(args.message, stdin)
    if not message:
        stderr.write("run requires a message or stdin input\n")
        stderr.flush()
        return EXIT_USAGE
    resume_value = getattr(args, "resume", None)
    resume_session = None if resume_value in (None, "__last__") else str(resume_value).strip() or None
    use_last = bool(args.last) or resume_value == "__last__"
    session_id = _resolve_session_id(context, args.session or resume_session, use_last)
    try:
        runtime = build_agent_runtime(
            resolved=context.resolved,
            session_manager=context.session_manager,
            session_id=session_id,
            provider=args.provider,
            model_name=args.model,
            mode=args.mode,
            approval=args.approval,
            enable_search=bool(args.search),
            additional_dirs=args.additional_dirs,
        )
    except ValueError as exc:
        stderr.write(f"run configuration error: {exc}\n")
        stderr.flush()
        return EXIT_USAGE

    context.logger.info(
        "Starting headless run session=%s model=%s mode=%s approval=%s cwd=%s additional_dirs=%s",
        runtime.session_id,
        runtime.selection.selected_model,
        args.mode,
        args.approval,
        context.resolved.cwd,
        runtime.additional_dirs,
    )
    context.session_manager.append_transcript_entry(runtime.session_id, "user", message)
    system_prompt_append = build_system_prompt_append(args.mode, args.approval, runtime.additional_dirs)
    result: Dict[str, Any] = {}
    had_error = False
    error_text = ""
    display_options = RunDisplayOptions(
        show_reasoning=bool(args.show_reasoning),
        show_tools=bool(args.show_tools) or bool(args.show_tool_output),
        show_tool_output=bool(args.show_tool_output),
        tool_output_max_lines=max(1, int(args.tool_output_lines or 1)),
    )
    printer = None if args.json else HumanRunPrinter(stdout, options=display_options)
    try:
        if args.mode == "ask":
            iterator = runtime.agent.ask(message=message, thread_id=runtime.session_id)
        else:
            iterator = runtime.agent.invoke(
                task=message,
                thread_id=runtime.session_id,
                thinking_context=(args.mode == "plan"),
                system_prompt_append=system_prompt_append,
            )
        for event in iterator:
            if printer is not None:
                printer.handle(event)
            if str(event.get("type", "") or "") == "error":
                had_error = True
                error_text = str(event.get("content", "") or error_text)
            if str(event.get("type", "") or "") == "done":
                result = dict(event)
    except Exception as exc:
        had_error = True
        error_text = str(exc)
        context.logger.exception("Headless run failed")
        stderr.write(f"run failed: {exc}\n")
        stderr.flush()
    state = runtime.agent.get_context(thread_id=runtime.session_id) if hasattr(runtime.agent, "get_context") else {}
    answer = str(result.get("answer", "") or result.get("content", "") or "")
    if answer:
        context.session_manager.append_transcript_entry(runtime.session_id, "assistant", answer)
    context.session_manager.sync_session(
        runtime.session_id,
        cwd=str(context.resolved.cwd),
        provider=runtime.selection.provider,
        model_name=runtime.selection.model_name,
        mode=args.mode,
        prompt=message,
        answer=answer,
        state=state,
    )
    payload = {
        "session_id": runtime.session_id,
        "selected_model": runtime.selection.selected_model,
        "mode": args.mode,
        "approval": args.approval,
        "cwd": str(context.resolved.cwd),
        "additional_dirs": runtime.additional_dirs,
        "tool_virtual_root": runtime.tool_virtual_root,
        "task_completed": bool(result.get("task_completed", state.get("task_completed", False) if isinstance(state, dict) else False)),
        "iteration_count": int(result.get("iteration_count", state.get("iteration_count", 0) if isinstance(state, dict) else 0) or 0),
        "total_tokens": int(result.get("total_tokens", state.get("total_tokens", 0) if isinstance(state, dict) else 0) or 0),
        "answer": answer,
        "reasoning": str(result.get("reasoning", "") or ""),
        "error": error_text,
        "log_level": context.logging.level_name,
        "log_path": str(context.logging.log_path),
    }
    if args.json:
        json_dump(stdout, payload)
    return EXIT_FAILURE if had_error else EXIT_OK


def _handle_resume(args, *, context: CliContext, stderr: TextIO, tui_runner) -> int:
    session_id = _resolve_session_id(context, args.session_id, args.last or not args.session_id)
    if not session_id:
        stderr.write("No saved session found to resume\n")
        stderr.flush()
        return EXIT_NOT_FOUND
    context.logger.info("Resuming TUI session=%s cwd=%s", session_id, context.resolved.cwd)
    return tui_runner(
        resolved=context.resolved,
        session_manager=context.session_manager,
        session_id=session_id,
        provider=args.provider,
        model_name=args.model,
        prompt="",
    )


def _handle_session(args, *, context: CliContext, stdout: TextIO, stderr: TextIO) -> int:
    manager = context.session_manager
    if args.session_cmd == "list":
        sessions = manager.list_sessions(cwd=str(context.resolved.cwd)) or manager.list_sessions()
        if args.json:
            json_dump(stdout, {"sessions": sessions})
            return EXIT_OK
        print_session_table(stdout, sessions)
        return EXIT_OK
    if args.session_cmd == "show":
        session_id = _resolve_session_id(context, args.session_id, args.last or not args.session_id)
        if not session_id:
            stderr.write("No session selected\n")
            stderr.flush()
            return EXIT_NOT_FOUND
        record = manager.load_session(session_id)
        if not record:
            stderr.write(f"Session not found: {session_id}\n")
            stderr.flush()
            return EXIT_NOT_FOUND
        transcript = manager.read_transcript(session_id, limit=args.limit)
        if args.json:
            json_dump(stdout, {"session": record, "transcript": transcript})
            return EXIT_OK
        print_nested_mapping(stdout, record)
        stdout.write("\n")
        print_transcript(stdout, transcript)
        return EXIT_OK
    if args.session_cmd == "delete":
        ok = manager.delete_session(args.session_id)
        if args.json:
            json_dump(stdout, {"session_id": args.session_id, "deleted": ok})
        else:
            stdout.write(("Deleted" if ok else "Nothing to delete") + f" session {args.session_id}\n")
            stdout.flush()
        return EXIT_OK
    if args.session_cmd == "compact":
        session_id = _resolve_session_id(context, args.session_id, args.last or not args.session_id)
        if not session_id:
            stderr.write("No session selected\n")
            stderr.flush()
            return EXIT_NOT_FOUND
        runtime = build_agent_runtime(
            resolved=context.resolved,
            session_manager=manager,
            session_id=session_id,
            provider=args.provider,
            model_name=args.model,
            mode="build",
            approval="auto",
            enable_search=False,
        )
        status, summary = runtime.agent.compact_context(session_id)
        manager.sync_session(
            session_id,
            cwd=str(context.resolved.cwd),
            provider=runtime.selection.provider,
            model_name=runtime.selection.model_name,
            mode="build",
            answer=summary or "",
            state=runtime.agent.get_context(thread_id=session_id),
        )
        if args.json:
            json_dump(stdout, {"session_id": session_id, "status": status, "summary": summary})
        else:
            stdout.write(status + "\n")
            if summary:
                stdout.write(summary + "\n")
            stdout.flush()
        return EXIT_OK
    stderr.write(f"Unknown session command: {args.session_cmd}\n")
    stderr.flush()
    return EXIT_USAGE


def _handle_auth(args, *, context: CliContext, stdout: TextIO, stderr: TextIO) -> int:
    if args.auth_cmd == "status":
        rows = []
        for alias, config in MODEL_REGISTRY.items():
            env_keys = config.get("env_key")
            keys = env_keys if isinstance(env_keys, list) else [env_keys]
            keys = [str(item).strip() for item in keys if str(item or "").strip()]
            if not keys:
                continue
            rows.append({"alias": alias, "env_keys": keys, "configured": any(bool(os.environ.get(key)) for key in keys)})
        if args.json:
            json_dump(stdout, {"auth": rows})
        else:
            for row in rows:
                stdout.write(f"{row['alias']}: {'configured' if row['configured'] else 'missing'} ({', '.join(row['env_keys'])})\n")
            stdout.flush()
        return EXIT_OK
    try:
        env_key = _infer_env_key(args.model, args.env_key)
    except ValueError as exc:
        stderr.write(str(exc) + "\n")
        stderr.flush()
        return EXIT_USAGE
    env_path = context.resolved.paths.global_env if args.scope == "global" else context.resolved.paths.project_env
    env_path.parent.mkdir(parents=True, exist_ok=True)
    if args.auth_cmd == "login":
        api_key = str(args.api_key or "").strip() or getpass.getpass(f"{env_key}: ").strip()
        if not api_key:
            stderr.write("API key cannot be empty\n")
            stderr.flush()
            return EXIT_USAGE
        if not env_path.exists():
            env_path.write_text("", encoding="utf-8")
        set_key(str(env_path), env_key, api_key, quote_mode="never")
        os.environ[env_key] = api_key
        stdout.write(f"Saved {env_key} to {env_path}\n")
        stdout.flush()
        return EXIT_OK
    if args.auth_cmd == "logout":
        if env_path.exists():
            unset_key(str(env_path), env_key)
        os.environ.pop(env_key, None)
        stdout.write(f"Removed {env_key} from {env_path}\n")
        stdout.flush()
        return EXIT_OK
    stderr.write(f"Unknown auth command: {args.auth_cmd}\n")
    stderr.flush()
    return EXIT_USAGE

def _handle_models(args, *, context: CliContext, stdout: TextIO, stderr: TextIO) -> int:
    if args.models_cmd == "list":
        rows = []
        for alias, config in MODEL_REGISTRY.items():
            env_key = config.get("env_key")
            env_keys = env_key if isinstance(env_key, list) else [env_key]
            env_keys = [str(item).strip() for item in env_keys if str(item or "").strip()]
            rows.append(
                {
                    "alias": alias,
                    "route": str(config.get("model", "") or ""),
                    "description": str(config.get("description", "") or ""),
                    "configured": any(bool(os.environ.get(key)) for key in env_keys),
                    "env_keys": env_keys,
                }
            )
        if args.json:
            json_dump(stdout, {"models": rows})
        else:
            for row in rows:
                status = "configured" if row["configured"] else "missing"
                stdout.write(f"{row['alias']}: {row['route']} [{status}]\n")
            stdout.flush()
        return EXIT_OK
    if args.models_cmd == "show":
        payload = {
            "provider": context.resolved.model_provider,
            "model": context.resolved.model_name,
            "selected_model": f"{context.resolved.model_provider}/{context.resolved.model_name}",
        }
        if args.json:
            json_dump(stdout, payload)
        else:
            print_kv(stdout, payload.items())
        return EXIT_OK
    if args.models_cmd == "set":
        model_ref = str(args.model or "").strip()
        provider = str(args.provider or "").strip()
        name = model_ref
        if model_ref in MODEL_REGISTRY:
            route = str(MODEL_REGISTRY[model_ref].get("model", "") or "")
            if route and "/" in route and not provider:
                provider = route.split("/", 1)[0].strip()
        elif "/" in model_ref and not provider:
            provider, name = model_ref.split("/", 1)
            provider = provider.strip()
            name = name.strip()
        if not provider:
            provider = context.resolved.model_provider
        path = save_config_patch(args.scope, {"model": {"provider": provider, "name": name}}, cwd=getattr(args, "cwd", None))
        stdout.write(f"Saved default model to {path}\n")
        stdout.flush()
        return EXIT_OK
    stderr.write(f"Unknown models command: {args.models_cmd}\n")
    stderr.flush()
    return EXIT_USAGE


def _handle_config(args, *, context: CliContext, stdout: TextIO) -> int:
    if args.config_cmd == "show":
        payload = context.resolved.to_dict()
        if args.json:
            json_dump(stdout, payload)
        else:
            print_nested_mapping(stdout, payload)
        return EXIT_OK
    if args.config_cmd == "path":
        payload = config_paths_payload(context.resolved)
        if args.json:
            json_dump(stdout, payload)
        else:
            print_kv(stdout, payload.items())
        return EXIT_OK
    if args.config_cmd == "validate":
        valid, sources = validate_config_sources(str(context.resolved.cwd))
        payload = {
            "valid": valid,
            "paths": config_paths_payload(context.resolved),
            "sources": [item.to_dict() for item in sources],
        }
        if args.json:
            json_dump(stdout, payload)
        else:
            print_kv(stdout, [("valid", valid)])
            stdout.write("\n")
            for item in sources:
                state = "valid" if item.valid else "invalid"
                exists = "present" if item.exists else "missing"
                suffix = f" ({item.error})" if item.error else ""
                stdout.write(f"- {item.name}: {exists}, {state}, {item.path}{suffix}\n")
            stdout.flush()
        return EXIT_OK if valid else EXIT_CONFIG
    return EXIT_USAGE


def _current_model_env_keys(provider: str, model_name: str) -> Iterable[str]:
    if model_name in MODEL_REGISTRY:
        env_key = MODEL_REGISTRY[model_name].get("env_key")
        if isinstance(env_key, list):
            return [str(item).strip() for item in env_key if str(item or "").strip()]
        if isinstance(env_key, str) and env_key.strip():
            return [env_key.strip()]
    route = f"{provider}/{model_name}" if model_name else provider
    for config in MODEL_REGISTRY.values():
        if str(config.get("model", "") or "") == route:
            env_key = config.get("env_key")
            if isinstance(env_key, list):
                return [str(item).strip() for item in env_key if str(item or "").strip()]
            if isinstance(env_key, str) and env_key.strip():
                return [env_key.strip()]
    return []


def _build_doctor_payload(context: CliContext) -> Dict[str, Any]:
    auth_keys = list(_current_model_env_keys(context.resolved.model_provider, context.resolved.model_name))
    current_model_ready = any(bool(os.environ.get(key)) for key in auth_keys) if auth_keys else False
    critical_checks = [
        {"name": "cwd_exists", "ok": context.resolved.cwd.exists(), "detail": str(context.resolved.cwd)},
        {"name": "session_root_parent_writable", "ok": os.access(str(context.resolved.paths.home_dir), os.W_OK), "detail": str(context.resolved.paths.home_dir)},
        {"name": "agent_import", "ok": True, "detail": "klynx.agent"},
        {"name": "tui_import", "ok": True, "detail": "klynx_cli.app"},
    ]
    try:
        import klynx.agent  # noqa: F401
    except Exception as exc:
        critical_checks[2]["ok"] = False
        critical_checks[2]["detail"] = str(exc)
    try:
        import klynx_cli.app  # noqa: F401
    except Exception as exc:
        critical_checks[3]["ok"] = False
        critical_checks[3]["detail"] = str(exc)

    optional_checks = [
        {"name": "git", "ok": shutil.which("git") is not None, "detail": shutil.which("git") or "not found"},
        {"name": "ripgrep", "ok": shutil.which("rg") is not None, "detail": shutil.which("rg") or "not found"},
        {"name": "playwright", "ok": shutil.which("playwright") is not None, "detail": shutil.which("playwright") or "not found"},
        {"name": "current_model_auth", "ok": current_model_ready, "detail": ", ".join(auth_keys) if auth_keys else "no env key metadata"},
    ]
    ok = all(bool(item["ok"]) for item in critical_checks)
    return {
        "ok": ok,
        "critical_checks": critical_checks,
        "optional_checks": optional_checks,
        "model": {
            "provider": context.resolved.model_provider,
            "model": context.resolved.model_name,
            "auth_env_keys": auth_keys,
            "auth_configured": current_model_ready,
        },
        "logging": {
            "level": context.logging.level_name,
            "print_logs": context.logging.print_logs,
            "path": str(context.logging.log_path),
        },
        "paths": config_paths_payload(context.resolved),
        "config_sources": [item.to_dict() for item in context.config_sources],
        "python": sys.executable,
    }


def _handle_doctor(args, *, context: CliContext, stdout: TextIO) -> int:
    payload = _build_doctor_payload(context)
    if args.json:
        json_dump(stdout, payload)
    else:
        print_doctor_report(stdout, payload)
    return EXIT_OK if payload["ok"] else EXIT_FAILURE


def _handle_completion(args, *, stdout: TextIO) -> int:
    stdout.write(_completion_script(args.shell))
    stdout.flush()
    return EXIT_OK


def dispatch(
    argv: Optional[Sequence[str]] = None,
    *,
    stdout: Optional[TextIO] = None,
    stderr: Optional[TextIO] = None,
    stdin: Optional[TextIO] = None,
    tui_runner=launch_tui_app,
) -> int:
    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    stdin = stdin or sys.stdin
    args_list = list(argv if argv is not None else sys.argv[1:])

    if not args_list or not _looks_like_subcommand(args_list):
        parser = _build_default_parser()
        parsed = parser.parse_args(args_list)
        context = build_cli_context(
            cwd=getattr(parsed, "cwd", None),
            overrides=getattr(parsed, "config_overrides", None),
            log_level=getattr(parsed, "log_level", None),
            print_logs=getattr(parsed, "print_logs", None),
        )
        session_id = _resolve_session_id(context, parsed.session, parsed.last)
        prompt = _join_message(parsed.prompt, stdin)
        context.logger.info("Launching default TUI session=%s cwd=%s", session_id or "<new>", context.resolved.cwd)
        return tui_runner(
            resolved=context.resolved,
            session_manager=context.session_manager,
            session_id=session_id,
            provider=parsed.provider,
            model_name=parsed.model,
            prompt=prompt,
        )

    parser = _build_command_parser()
    parsed = parser.parse_args(args_list)
    context = build_cli_context(
        cwd=getattr(parsed, "cwd", None),
        overrides=getattr(parsed, "config_overrides", None),
        log_level=getattr(parsed, "log_level", None),
        print_logs=getattr(parsed, "print_logs", None),
    )
    if parsed.subcommand == "run":
        return _handle_run(parsed, context=context, stdout=stdout, stderr=stderr, stdin=stdin)
    if parsed.subcommand == "resume":
        return _handle_resume(parsed, context=context, stderr=stderr, tui_runner=tui_runner)
    if parsed.subcommand == "session":
        return _handle_session(parsed, context=context, stdout=stdout, stderr=stderr)
    if parsed.subcommand == "auth":
        return _handle_auth(parsed, context=context, stdout=stdout, stderr=stderr)
    if parsed.subcommand == "models":
        return _handle_models(parsed, context=context, stdout=stdout, stderr=stderr)
    if parsed.subcommand == "config":
        return _handle_config(parsed, context=context, stdout=stdout)
    if parsed.subcommand == "doctor":
        return _handle_doctor(parsed, context=context, stdout=stdout)
    if parsed.subcommand == "completion":
        return _handle_completion(parsed, stdout=stdout)
    if parsed.subcommand == "tui":
        session_id = _resolve_session_id(context, parsed.session, parsed.last)
        prompt = _join_message(parsed.prompt, stdin)
        return tui_runner(
            resolved=context.resolved,
            session_manager=context.session_manager,
            session_id=session_id,
            provider=parsed.provider,
            model_name=parsed.model,
            prompt=prompt,
        )
    stderr.write(f"Unknown command: {parsed.subcommand}\n")
    stderr.flush()
    return EXIT_USAGE


def main(argv: Optional[Sequence[str]] = None) -> int:
    code = dispatch(argv)
    if argv is None:
        raise SystemExit(code)
    return code






