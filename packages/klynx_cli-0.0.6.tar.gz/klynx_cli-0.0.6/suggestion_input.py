"""Input widget with explicit Tab-completion behavior."""

from textual.widgets import Input


class SuggestionInput(Input):
    """Input box that accepts inline suggestions on Tab."""

    BINDINGS = [
        ("tab", "complete_suggestion", "Complete"),
    ]

    def action_complete_suggestion(self) -> None:
        """Accept the current suggestion when available."""
        # Textual does not expose this publicly yet.
        suggestion = getattr(self, "_suggestion", "")
        if suggestion and self.cursor_at_end:
            self.value = suggestion
            self.cursor_position = len(self.value)
            return
        self.screen.focus_next()
