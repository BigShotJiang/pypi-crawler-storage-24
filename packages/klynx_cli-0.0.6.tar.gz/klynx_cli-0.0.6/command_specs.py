from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


@dataclass(frozen=True)
class RootCommandSpec:
    name: str
    summary: str


@dataclass(frozen=True)
class SlashCommandSpec:
    name: str
    handler_name: str
    default_help: str
    shell_equivalents: Tuple[str, ...] = ()
    suggestions: Tuple[str, ...] = ()


ROOT_COMMANDS: Tuple[RootCommandSpec, ...] = (
    RootCommandSpec('run', 'Execute a task without launching the TUI.'),
    RootCommandSpec('resume', 'Resume a saved session in the TUI.'),
    RootCommandSpec('session', 'Inspect or manage saved sessions.'),
    RootCommandSpec('auth', 'Manage API keys and auth env files.'),
    RootCommandSpec('models', 'List models and persist default model selection.'),
    RootCommandSpec('config', 'Inspect effective config, paths, and validation.'),
    RootCommandSpec('doctor', 'Run environment and dependency diagnostics.'),
    RootCommandSpec('completion', 'Generate shell completion scripts.'),
    RootCommandSpec('tui', 'Launch the TUI explicitly.'),
)


SLASH_COMMANDS: Tuple[SlashCommandSpec, ...] = (
    SlashCommandSpec(
        'quit',
        '_cmd_quit',
        'Exit the current TUI session.',
        suggestions=('/quit',),
    ),
    SlashCommandSpec(
        'clear',
        '_cmd_clear',
        'Start a fresh in-app thread and clear the visible transcript.',
        suggestions=('/clear',),
    ),
    SlashCommandSpec(
        'copy',
        '_cmd_copy',
        'Copy the latest assistant response to the clipboard.',
        suggestions=('/copy',),
    ),
    SlashCommandSpec(
        'context',
        '_cmd_context',
        'Show session context. Use /context full for the full transcript.',
        shell_equivalents=('klynx session show --last', 'klynx session show <session_id>'),
        suggestions=('/context', '/context full'),
    ),
    SlashCommandSpec(
        'help',
        '_cmd_help',
        'Show available slash commands and their shell equivalents.',
        shell_equivalents=('klynx --help',),
        suggestions=('/help',),
    ),
    SlashCommandSpec(
        'mode',
        '_cmd_mode',
        'Single-pane mode is always enabled; this command only prints current mode.',
        shell_equivalents=('klynx tui',),
        suggestions=('/mode',),
    ),
    SlashCommandSpec(
        'model',
        '_cmd_model',
        'Open model settings inside the TUI.',
        shell_equivalents=('klynx models show', 'klynx models set <model>'),
        suggestions=('/model',),
    ),
    SlashCommandSpec(
        'compact',
        '_cmd_compact',
        'Compact the current session context.',
        shell_equivalents=('klynx session compact --last', 'klynx session compact <session_id>'),
        suggestions=('/compact', '/compat'),
    ),
    SlashCommandSpec(
        'compat',
        '_cmd_compact',
        'Alias for /compact.',
        shell_equivalents=('klynx session compact --last',),
        suggestions=('/compat',),
    ),
)


_SLASH_BY_NAME: Dict[str, SlashCommandSpec] = {spec.name: spec for spec in SLASH_COMMANDS}


def root_command_words() -> List[str]:
    return [spec.name for spec in ROOT_COMMANDS]


def root_help_epilog() -> str:
    lines = ['Subcommands:']
    width = max(len(spec.name) for spec in ROOT_COMMANDS)
    for spec in ROOT_COMMANDS:
        lines.append(f'  {spec.name.ljust(width)}  {spec.summary}')
    return '\n'.join(lines)


def get_slash_command_spec(name: str) -> Optional[SlashCommandSpec]:
    key = str(name or '').strip().lower().lstrip('/')
    return _SLASH_BY_NAME.get(key)


def slash_suggestions() -> List[str]:
    items = []
    seen = set()
    for spec in SLASH_COMMANDS:
        values = spec.suggestions or (f'/{spec.name}',)
        for value in values:
            if value not in seen:
                items.append(value)
                seen.add(value)
    return items
