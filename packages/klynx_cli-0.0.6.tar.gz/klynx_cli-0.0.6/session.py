from __future__ import annotations

import json
import os
import pickle
import threading
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from langgraph.checkpoint.memory import InMemorySaver

from .config import ensure_parent_dir, resolve_paths


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class PersistentMemorySaver(InMemorySaver):
    """File-backed LangGraph checkpoint saver built on top of InMemorySaver."""

    def __init__(self, file_path: Path):
        self.file_path = Path(file_path)
        self._lock = threading.RLock()
        super().__init__()
        ensure_parent_dir(self.file_path)
        self._load()

    def _load(self) -> None:
        if not self.file_path.exists():
            return
        with self._lock:
            try:
                payload = pickle.loads(self.file_path.read_bytes())
            except Exception:
                return
            storage = defaultdict(lambda: defaultdict(dict))
            for thread_id, ns_map in dict(payload.get("storage", {}) or {}).items():
                nested = defaultdict(dict)
                for checkpoint_ns, entries in dict(ns_map or {}).items():
                    nested[checkpoint_ns] = dict(entries or {})
                storage[thread_id] = nested
            writes = defaultdict(dict)
            for key, value in dict(payload.get("writes", {}) or {}).items():
                writes[key] = dict(value or {})
            self.storage = storage
            self.writes = writes
            self.blobs = dict(payload.get("blobs", {}) or {})

    def _persist(self) -> None:
        payload = {
            "storage": {
                thread_id: {
                    checkpoint_ns: dict(entries)
                    for checkpoint_ns, entries in dict(ns_map).items()
                }
                for thread_id, ns_map in dict(self.storage).items()
            },
            "writes": {key: dict(value) for key, value in dict(self.writes).items()},
            "blobs": dict(self.blobs),
        }
        temp_path = self.file_path.with_suffix(self.file_path.suffix + ".tmp")
        temp_path.write_bytes(pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL))
        os.replace(temp_path, self.file_path)

    def put(self, config, checkpoint, metadata, new_versions):  # type: ignore[override]
        with self._lock:
            result = super().put(config, checkpoint, metadata, new_versions)
            self._persist()
            return result

    def put_writes(self, config, writes, task_id, task_path=""):  # type: ignore[override]
        with self._lock:
            super().put_writes(config, writes, task_id, task_path)
            self._persist()

    def delete_thread(self, thread_id: str) -> None:  # type: ignore[override]
        with self._lock:
            super().delete_thread(thread_id)
            self._persist()


class FileAgentStore:
    """Small pickle-backed key-value store for summary/tool artifact content."""

    def __init__(self, file_path: Path):
        self.file_path = Path(file_path)
        self._lock = threading.RLock()
        self._data: Dict[str, Any] = {}
        ensure_parent_dir(self.file_path)
        self._load()

    def _load(self) -> None:
        if not self.file_path.exists():
            return
        with self._lock:
            try:
                self._data = pickle.loads(self.file_path.read_bytes())
            except Exception:
                self._data = {}

    def _persist(self) -> None:
        temp_path = self.file_path.with_suffix(self.file_path.suffix + ".tmp")
        temp_path.write_bytes(pickle.dumps(self._data, protocol=pickle.HIGHEST_PROTOCOL))
        os.replace(temp_path, self.file_path)

    def get(self, key: str) -> Any:
        return self._data.get(key)

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            self._data[key] = value
            self._persist()

    def delete(self, key: str) -> None:
        with self._lock:
            self._data.pop(key, None)
            self._persist()

    def keys(self) -> List[str]:
        return list(self._data.keys())


class SessionManager:
    def __init__(self, cwd: Optional[str] = None):
        paths = resolve_paths(cwd)
        self.root = paths.session_root
        self.records_dir = self.root / "records"
        self.transcripts_dir = self.root / "transcripts"
        self.root.mkdir(parents=True, exist_ok=True)
        self.records_dir.mkdir(parents=True, exist_ok=True)
        self.transcripts_dir.mkdir(parents=True, exist_ok=True)
        self.checkpointer = PersistentMemorySaver(self.root / "checkpoints.pkl")
        self.store = FileAgentStore(self.root / "store.pkl")

    def new_session_id(self) -> str:
        return f"sess_{uuid.uuid4().hex[:10]}"

    def _record_path(self, session_id: str) -> Path:
        return self.records_dir / f"{session_id}.json"

    def _transcript_path(self, session_id: str) -> Path:
        return self.transcripts_dir / f"{session_id}.jsonl"

    def _title_from_text(self, text: Optional[str]) -> str:
        content = " ".join(str(text or "").split()).strip()
        if not content:
            return "Klynx session"
        if len(content) <= 80:
            return content
        return content[:77] + "..."

    def load_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        path = self._record_path(session_id)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None
        return payload if isinstance(payload, dict) else None

    def ensure_session(
        self,
        session_id: Optional[str] = None,
        *,
        cwd: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        mode: Optional[str] = None,
        title: Optional[str] = None,
    ) -> Dict[str, Any]:
        current_id = str(session_id or self.new_session_id()).strip()
        existing = self.load_session(current_id) or {}
        now = _now_iso()
        record = {
            "session_id": current_id,
            "cwd": str(Path(cwd or existing.get("cwd") or os.getcwd()).resolve()),
            "provider": str(provider if provider is not None else existing.get("provider", "") or "").strip(),
            "model_name": str(model_name if model_name is not None else existing.get("model_name", "") or "").strip(),
            "mode": str(mode if mode is not None else existing.get("mode", "") or "run").strip() or "run",
            "title": str(title if title is not None else existing.get("title", "") or self._title_from_text(existing.get("latest_prompt"))).strip() or "Klynx session",
            "created_at": str(existing.get("created_at", now) or now),
            "updated_at": now,
            "latest_prompt": str(existing.get("latest_prompt", "") or ""),
            "latest_answer": str(existing.get("latest_answer", "") or ""),
            "task_completed": bool(existing.get("task_completed", False)),
            "iteration_count": int(existing.get("iteration_count", 0) or 0),
            "total_tokens": int(existing.get("total_tokens", 0) or 0),
            "message_count": int(existing.get("message_count", 0) or 0),
            "context_summary": str(existing.get("context_summary", "") or ""),
        }
        self._record_path(current_id).write_text(
            json.dumps(record, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return record

    def sync_session(
        self,
        session_id: str,
        *,
        cwd: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        mode: Optional[str] = None,
        prompt: Optional[str] = None,
        answer: Optional[str] = None,
        state: Optional[Dict[str, Any]] = None,
        title: Optional[str] = None,
    ) -> Dict[str, Any]:
        record = self.ensure_session(
            session_id,
            cwd=cwd,
            provider=provider,
            model_name=model_name,
            mode=mode,
            title=title or self._title_from_text(prompt),
        )
        if prompt is not None:
            record["latest_prompt"] = str(prompt)
        if answer is not None:
            preview = str(answer)
            if len(preview) > 400:
                preview = preview[:397] + "..."
            record["latest_answer"] = preview
        if state:
            messages = state.get("messages", []) or []
            record["task_completed"] = bool(state.get("task_completed", record.get("task_completed", False)))
            record["iteration_count"] = int(state.get("iteration_count", record.get("iteration_count", 0)) or 0)
            record["total_tokens"] = int(state.get("total_tokens", record.get("total_tokens", 0)) or 0)
            record["message_count"] = len(messages)
            record["context_summary"] = str(state.get("context_summary", record.get("context_summary", "")) or "")
        record["updated_at"] = _now_iso()
        self._record_path(session_id).write_text(
            json.dumps(record, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return record

    def append_transcript_entry(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        kind: str = "message",
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        entry = {
            "timestamp": _now_iso(),
            "role": str(role or "").strip() or "system",
            "kind": str(kind or "message").strip() or "message",
            "content": str(content or ""),
        }
        if extra:
            entry.update(extra)
        path = self._transcript_path(session_id)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def read_transcript(self, session_id: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        path = self._transcript_path(session_id)
        if not path.exists():
            return []
        items: List[Dict[str, Any]] = []
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                text = line.strip()
                if not text:
                    continue
                try:
                    payload = json.loads(text)
                except Exception:
                    continue
                if isinstance(payload, dict):
                    items.append(payload)
        if limit is not None and limit > 0:
            return items[-limit:]
        return items

    def list_sessions(self, *, cwd: Optional[str] = None, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        records: List[Dict[str, Any]] = []
        filter_cwd = str(Path(cwd).resolve()) if cwd else ""
        for path in self.records_dir.glob("*.json"):
            record = self.load_session(path.stem)
            if not record:
                continue
            if filter_cwd and str(record.get("cwd", "") or "") != filter_cwd:
                continue
            records.append(record)
        records.sort(key=lambda item: str(item.get("updated_at", "") or ""), reverse=True)
        if limit is not None and limit > 0:
            return records[:limit]
        return records

    def latest_session(self, *, cwd: Optional[str] = None) -> Optional[Dict[str, Any]]:
        sessions = self.list_sessions(cwd=cwd, limit=1)
        return sessions[0] if sessions else None

    def delete_session(self, session_id: str) -> bool:
        removed = False
        record_path = self._record_path(session_id)
        transcript_path = self._transcript_path(session_id)
        if record_path.exists():
            record_path.unlink()
            removed = True
        if transcript_path.exists():
            transcript_path.unlink()
            removed = True
        self.checkpointer.delete_thread(session_id)
        for key in list(self.store.keys()):
            if key.startswith(f"summary_event:{session_id}:") or key.startswith(f"tool_artifact:{session_id}:"):
                self.store.delete(key)
        return removed