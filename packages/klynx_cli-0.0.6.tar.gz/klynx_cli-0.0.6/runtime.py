from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, TextIO

from klynx.agent import create_agent as create_agent  # compatibility export
from klynx.agent import create_agent as create_agent  # compatibility export
from klynx.agent.tools.web_search import set_tavily_api
from klynx.model import MODEL_REGISTRY, setup as setup_model  # compatibility export

from .config import ResolvedConfig
from .output import extract_tool_name, format_thinking_label, format_tool_label, sanitize_visible_text
from .session import SessionManager
from .customization import RuntimeContext, TUIConfig, build_agent, wrap_backend


@dataclass
class RuntimeSelection:
    provider: str
    model_name: Optional[str]
    selected_model: str
    approval: str
    mode: str


@dataclass
class AgentRuntime:
    agent: Any
    session_id: str
    selection: RuntimeSelection
    additional_dirs: List[str] = field(default_factory=list)
    tool_virtual_root: str = ''


@dataclass(frozen=True)
class RunDisplayOptions:
    show_reasoning: bool = False
    show_tools: bool = False
    show_tool_output: bool = False
    tool_output_max_lines: int = 8


class HumanRunPrinter:
    def __init__(self, stream: TextIO, options: Optional[RunDisplayOptions] = None):
        self.stream = stream
        self.options = options or RunDisplayOptions()
        self._printed_reasoning_label = False
        self._buffered_answer_parts: List[str] = []
        self._streamed_answer = False
        self._streamed_reasoning = False
        self._last_tool_message = ''

    def _write(self, text: str, *, end: str = '\n') -> None:
        self.stream.write(str(text) + end)
        self.stream.flush()

    def _emit_reasoning_label(self) -> None:
        if not self.options.show_reasoning or self._printed_reasoning_label:
            return
        self._write(format_thinking_label())
        self._printed_reasoning_label = True
        self._streamed_reasoning = True

    def _buffer_answer_text(self, content: str) -> None:
        if not content:
            return
        self._buffered_answer_parts.append(str(content))
        self._streamed_answer = True

    def _flush_answer(self, fallback: str = '') -> None:
        raw_answer = ''.join(self._buffered_answer_parts).strip() or str(fallback or '').strip()
        answer = sanitize_visible_text(raw_answer)
        self._buffered_answer_parts.clear()
        if answer:
            self._write(answer)

    def _emit_tool_message(self, content: str) -> None:
        if not self.options.show_tools:
            return
        tool_name = extract_tool_name(content)
        if not tool_name:
            return
        message = format_tool_label(tool_name)
        if message == self._last_tool_message:
            return
        self._last_tool_message = message
        self._write(message)

    def _emit_tool_output(self, content: str) -> None:
        if not self.options.show_tool_output:
            return
        text = sanitize_visible_text(content)
        if not text:
            return
        lines = text.splitlines()
        if not lines:
            return
        max_lines = max(1, int(self.options.tool_output_max_lines or 1))
        preview = '\n'.join(lines[:max_lines])
        if len(lines) > max_lines:
            preview += f'\n... ({len(lines) - max_lines} more lines)'
        self._write(preview)

    def handle(self, event: Dict[str, Any]) -> None:
        etype = str(event.get('type', '') or '')
        content = str(event.get('content', '') or '')
        if etype == 'reasoning_token':
            if content:
                self._emit_reasoning_label()
            return
        if etype == 'token':
            self._buffer_answer_text(content)
            return
        if etype == 'reasoning' and content:
            self._emit_reasoning_label()
            return
        if etype == 'answer' and not self._streamed_answer and content:
            self._buffer_answer_text(content)
            return
        if etype == 'tool_exec' and content:
            self._emit_tool_message(content)
            return
        if etype == 'tool_result' and content:
            self._emit_tool_output(content)
            return
        if etype in {'warning', 'error'} and content:
            text = sanitize_visible_text(content) or content.strip()
            if text:
                self._write(text)
            return
        if etype == 'done':
            answer = str(event.get('answer', '') or event.get('content', '') or '')
            self._flush_answer(answer)
            return


APPROVAL_PROMPTS = {
    'manual': 'Do not run shell commands or modify files until the user explicitly approves the plan.',
    'on-request': 'Ask for approval before high-impact shell commands, file mutations, or external actions.',
    'auto': 'Follow the default execution policy and proceed autonomously when the work is verifiable.',
}

MODE_PROMPTS = {
    'plan': 'Start by producing a concise actionable plan before continuing execution.',
    'build': 'Prioritize directly completing the task and validating the result.',
    'ask': 'Answer directly when tools are unnecessary and keep the response concise.',
}


def _parse_model_reference(
    model_arg: Optional[str],
    provider_arg: Optional[str],
    resolved: ResolvedConfig,
    session_record: Optional[Dict[str, Any]],
) -> RuntimeSelection:
    session_record = session_record or {}
    if isinstance(session_record, dict) and 'provider' in session_record:
        default_provider = str(session_record.get('provider') or '').strip()
    else:
        default_provider = str(resolved.model_provider or '').strip()
    if not default_provider:
        default_provider = str(resolved.model_provider or '').strip()

    if isinstance(session_record, dict) and 'model_name' in session_record:
        default_model = str(session_record.get('model_name') or '').strip()
    else:
        default_model = str(resolved.model_name or '').strip()

    provider = str(provider_arg or '').strip()
    model_name = str(model_arg or '').strip()
    model_explicit = bool(model_name)
    provider_explicit = bool(provider)

    # When provider itself is a model alias (e.g. "gpt-4o"), it fully identifies
    # the model and should not be combined with an inherited model_name.
    if provider and provider in MODEL_REGISTRY and not model_explicit:
        default_model = ""

    if model_name and '/' in model_name and not provider:
        head, tail = model_name.split('/', 1)
        provider = head.strip()
        model_name = tail.strip()
    elif model_name and model_name in MODEL_REGISTRY:
        route = str(MODEL_REGISTRY[model_name].get('model', '') or '')
        if route and '/' in route and not provider:
            provider = route.split('/', 1)[0].strip()
    if not provider:
        provider = default_provider
    if not model_name:
        model_name = default_model

    if provider in MODEL_REGISTRY and not model_explicit:
        model_name = ""

    if model_name and model_name in MODEL_REGISTRY and not provider_explicit:
        route = str(MODEL_REGISTRY[model_name].get('model', '') or '')
        if route and '/' in route:
            provider = route.split('/', 1)[0].strip() or provider

    selected = provider if not model_name else f'{provider}/{model_name}'
    return RuntimeSelection(
        provider=provider,
        model_name=model_name or None,
        selected_model=selected,
        approval='auto',
        mode='build',
    )


def normalize_additional_dirs(cwd: str, additional_dirs: Optional[Sequence[str]]) -> List[str]:
    cwd_path = Path(cwd).expanduser().resolve()
    resolved_dirs: List[str] = []
    seen = {str(cwd_path).lower()}
    for item in additional_dirs or []:
        raw = str(item or '').strip()
        if not raw:
            continue
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = (cwd_path / candidate).resolve()
        else:
            candidate = candidate.resolve()
        if not candidate.exists():
            raise ValueError(f'Additional directory does not exist: {candidate}')
        if not candidate.is_dir():
            raise ValueError(f'Additional path is not a directory: {candidate}')
        normalized = str(candidate)
        key = normalized.lower()
        if key in seen:
            continue
        seen.add(key)
        resolved_dirs.append(normalized)
    return resolved_dirs


def _compute_tool_virtual_root(cwd: str, additional_dirs: Sequence[str]) -> str:
    paths = [str(Path(cwd).expanduser().resolve())]
    paths.extend(str(Path(item).expanduser().resolve()) for item in additional_dirs)
    if len(paths) == 1:
        return paths[0]
    try:
        return os.path.commonpath(paths)
    except ValueError as exc:
        raise ValueError('--add-dir entries must be on the same drive as --cwd') from exc


def build_system_prompt_append(mode: str, approval: str, additional_dirs: Optional[Sequence[str]] = None) -> str:
    chunks = []
    mode_key = str(mode or 'build').strip().lower()
    approval_key = str(approval or 'auto').strip().lower()
    if mode_key in MODE_PROMPTS:
        chunks.append(MODE_PROMPTS[mode_key])
    if approval_key in APPROVAL_PROMPTS:
        chunks.append(APPROVAL_PROMPTS[approval_key])
    extra_dirs = [str(item).strip() for item in additional_dirs or [] if str(item).strip()]
    if extra_dirs:
        formatted = '\n'.join(f'- {item}' for item in extra_dirs)
        chunks.append(
            'You may also inspect these additional directories outside the working directory. '
            'Use absolute paths when operating in them:\n' + formatted
        )
    return '\n\n'.join(chunk for chunk in chunks if chunk).strip()


def build_agent_runtime(
    *,
    resolved: ResolvedConfig,
    session_manager: SessionManager,
    session_id: Optional[str] = None,
    provider: Optional[str] = None,
    model_name: Optional[str] = None,
    mode: str = 'build',
    approval: str = 'auto',
    enable_search: bool = False,
    max_iterations: Optional[int] = None,
    additional_dirs: Optional[Sequence[str]] = None,
) -> AgentRuntime:
    record = session_manager.load_session(session_id) if session_id else None
    selection = _parse_model_reference(model_name, provider, resolved, record)
    selection.mode = str(mode or 'build').strip().lower() or 'build'
    selection.approval = str(approval or 'auto').strip().lower() or 'auto'

    normalized_additional_dirs = normalize_additional_dirs(str(resolved.cwd), additional_dirs)
    tool_virtual_root = _compute_tool_virtual_root(str(resolved.cwd), normalized_additional_dirs)
    allow_shell_commands = selection.approval != 'manual'

    runtime_ctx = RuntimeContext(
        working_dir=str(resolved.cwd),
        model_provider=selection.provider,
        model_name=selection.model_name,
        api_key=None,
        tavily_api_key=str(os.environ.get('TAVILY_API_KEY', '') or '').strip() or None,
        model_kwargs={},
        max_iterations=max_iterations,
        memory_dir=str(resolved.cwd),
        load_project_docs=False,
        checkpointer=session_manager.checkpointer,
        store=session_manager.store,
        allow_shell_commands=allow_shell_commands,
        tool_virtual_root=tool_virtual_root,
        additional_dirs=normalized_additional_dirs,
        set_layout_mode=None,
        tui_screen_update_callback=None,
    )

    tui_payload = resolved.data.get('tui', {}) if isinstance(resolved.data, dict) else {}
    tui_agent_payload = tui_payload.get('agent', {}) if isinstance(tui_payload, dict) else {}
    use_custom_backend = bool(
        str(tui_agent_payload.get('provider', '') or '').strip()
        or str(tui_agent_payload.get('backend', '') or '').strip().lower() not in {'', 'klynx'}
        or str(tui_agent_payload.get('adapter', '') or '').strip().lower() not in {'', 'auto', 'klynx'}
        or list(tui_agent_payload.get('tools_include') or [])
        or list(tui_agent_payload.get('tools_exclude') or [])
    )

    if use_custom_backend:
        from .customization import load_tui_config

        build_result = build_agent(load_tui_config(str(resolved.cwd)), runtime_ctx)
        agent = build_result.agent
        selection.selected_model = str(build_result.selected_model or selection.selected_model)
    else:
        if runtime_ctx.tavily_api_key:
            set_tavily_api(runtime_ctx.tavily_api_key)
        model = setup_model(selection.provider, selection.model_name, api_key=None)
        backend = create_agent(
            working_dir=str(resolved.cwd),
            model=model,
            max_iterations=max_iterations,
            memory_dir=str(resolved.cwd),
            load_project_docs=False,
            checkpointer=session_manager.checkpointer,
            store=session_manager.store,
            allow_shell_commands=allow_shell_commands,
            tool_virtual_root=tool_virtual_root,
        )
        agent = wrap_backend(backend, adapter='klynx')
        if enable_search:
            agent.add_tools('web_search')

    actual_session_id = str(session_id or session_manager.new_session_id()).strip()
    session_model_name = selection.model_name
    if session_model_name is None and selection.provider in MODEL_REGISTRY:
        session_model_name = ""
    session_manager.ensure_session(
        actual_session_id,
        cwd=str(resolved.cwd),
        provider=selection.provider,
        model_name=session_model_name,
        mode=selection.mode,
    )
    return AgentRuntime(
        agent=agent,
        session_id=actual_session_id,
        selection=selection,
        additional_dirs=normalized_additional_dirs,
        tool_virtual_root=tool_virtual_root,
    )
