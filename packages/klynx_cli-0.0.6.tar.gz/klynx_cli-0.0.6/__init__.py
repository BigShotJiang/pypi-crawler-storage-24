"""Klynx TUI app package."""

from .app import KlynxTUIApp

__all__ = [
    "KlynxTUIApp",
]
