from __future__ import annotations

import os
from typing import Any

import requests

from .config import load_config
from .errors import EXIT_AUTH_ERROR, EXIT_REMOTE_ERROR, CLIError


class ZeroEvalAPI:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 20.0,
    ) -> None:
        cfg = load_config()
        self._api_key = api_key or os.getenv("ZEROEVAL_API_KEY") or cfg.get("api_key")
        if not self._api_key:
            raise CLIError(
                "ZEROEVAL_API_KEY not set. Run `zeroeval setup` or export the variable.",
                exit_code=EXIT_AUTH_ERROR,
            )
        self._base_url = (
            base_url
            or os.getenv("ZEROEVAL_BASE_URL")
            or os.getenv("ZEROEVAL_API_URL")
            or cfg.get("api_base_url")
            or "https://api.zeroeval.com"
        ).rstrip("/")
        self._timeout = timeout

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        try:
            resp = requests.request(
                method,
                url,
                headers=self._headers(),
                params=params,
                timeout=self._timeout,
            )
        except requests.RequestException as exc:
            raise CLIError(
                f"Network error calling ZeroEval API: {exc}",
                exit_code=EXIT_REMOTE_ERROR,
            ) from exc

        if resp.status_code in (401, 403):
            raise CLIError(
                f"Authentication/authorization failed ({resp.status_code}).",
                exit_code=EXIT_AUTH_ERROR,
                details=_safe_json(resp),
            )
        if resp.status_code >= 400:
            raise CLIError(
                f"API request failed ({resp.status_code}) for {path}.",
                exit_code=EXIT_REMOTE_ERROR,
                details=_safe_json(resp),
            )

        return _safe_json(resp)

    # Datasets
    def list_datasets(self, *, limit: int, offset: int) -> Any:
        return self._request(
            "GET",
            "/v1/datasets",
            params={"limit": limit, "offset": offset},
        )

    def get_dataset(self, dataset: str) -> Any:
        return self._request("GET", f"/v1/datasets/{dataset}")

    def list_dataset_versions(self, dataset: str) -> Any:
        return self._request("GET", f"/v1/datasets/{dataset}/versions")

    def get_dataset_rows(
        self,
        dataset: str,
        *,
        version: int | None,
        subset: str | None,
        limit: int,
        offset: int,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if version is not None:
            params["version_number"] = version
        if subset:
            params["subset"] = subset
        return self._request("GET", f"/v1/datasets/{dataset}/data", params=params)

    # Evals
    def list_evals(
        self,
        *,
        dataset_id: str | None,
        status: str | None,
        limit: int,
        offset: int,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if dataset_id:
            params["dataset_id"] = dataset_id
        if status:
            params["status"] = status
        return self._request("GET", "/v1/evals", params=params)

    def get_eval(self, eval_id: str) -> Any:
        return self._request("GET", f"/v1/evals/{eval_id}")

    def get_eval_summary(self, eval_id: str) -> Any:
        return self._request("GET", f"/v1/evals/{eval_id}/summary")

    def get_eval_results(
        self,
        eval_id: str,
        *,
        repetition: int | None,
        limit: int,
        offset: int,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if repetition is not None:
            params["repetition"] = repetition
        return self._request("GET", f"/v1/evals/{eval_id}/results", params=params)

    def list_eval_scorers(self, eval_id: str) -> Any:
        return self._request("GET", f"/v1/evals/{eval_id}/scorers")

    def get_eval_scores(
        self,
        eval_id: str,
        scorer_id: str,
        *,
        limit: int,
        offset: int,
    ) -> Any:
        return self._request(
            "GET",
            f"/v1/evals/{eval_id}/scorers/{scorer_id}/scores",
            params={"limit": limit, "offset": offset},
        )

    def get_trace(self, trace_id: str) -> Any:
        return self._request("GET", "/traces", params={"id": trace_id, "limit": 1})

    def get_spans_for_trace(self, trace_id: str, *, limit: int, offset: int) -> Any:
        return self._request(
            "GET",
            "/spans",
            params={"trace_id": trace_id, "limit": limit, "offset": offset},
        )


def _safe_json(response: requests.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return {"raw": response.text}

