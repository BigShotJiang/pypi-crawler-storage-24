from .auth import register_auth_commands
from .datasets import register_datasets_commands
from .evals import register_evals_commands
from .spec import register_spec_commands

__all__ = [
    "register_auth_commands",
    "register_datasets_commands",
    "register_evals_commands",
    "register_spec_commands",
]

