from __future__ import annotations

import argparse
import json

from ..context import CLIContext
from ..errors import EXIT_USER_ERROR, CLIError
from ..specs import CLI_SPEC, get_command_spec


def cmd_spec_cli(args: argparse.Namespace, ctx: CLIContext):
    if args.format == "json":
        return CLI_SPEC
    return _to_markdown(CLI_SPEC)


def cmd_spec_command(args: argparse.Namespace, ctx: CLIContext):
    command = get_command_spec(args.path)
    if not command:
        raise CLIError(
            f"Unknown command path '{args.path}'.",
            exit_code=EXIT_USER_ERROR,
        )

    if args.format == "json":
        return command
    return _command_to_markdown(command)


def register_spec_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]):
    spec = subparsers.add_parser("spec", help="CLI specification and manual dumps")
    spec_sub = spec.add_subparsers(dest="spec_command", required=True)

    p_cli = spec_sub.add_parser("cli", help="Dump full CLI spec")
    p_cli.add_argument("--format", choices=["json", "markdown"], default="json")
    p_cli.set_defaults(handler=cmd_spec_cli)

    p_command = spec_sub.add_parser("command", help="Dump single command spec")
    p_command.add_argument("path", help='Command path, e.g. "evals results"')
    p_command.add_argument("--format", choices=["json", "markdown"], default="json")
    p_command.set_defaults(handler=cmd_spec_command)


def _to_markdown(spec: dict) -> str:
    lines: list[str] = []
    lines.append("# ZeroEval CLI Manual")
    lines.append("")
    lines.append(f"- Spec version: `{spec['spec_version']}`")
    lines.append(f"- Mode: `{spec['mode']}`")
    lines.append(f"- Non-interactive: `{spec['non_interactive']}`")
    lines.append("")
    lines.append("## Global options")
    for opt in spec.get("global_options", []):
        default = json.dumps(opt.get("default"))
        lines.append(f"- `{opt['name']}` ({opt['type']}), default `{default}`: {opt['description']}")
    lines.append("")
    lines.append("## Exit codes")
    for code, desc in spec.get("exit_codes", {}).items():
        lines.append(f"- `{code}`: {desc}")
    lines.append("")
    lines.append("## Commands")
    for command in spec.get("commands", []):
        lines.append(_command_to_markdown(command))
        lines.append("")
    return "\n".join(lines).strip()


def _command_to_markdown(command: dict) -> str:
    lines: list[str] = []
    lines.append(f"### `{command['path']}`")
    lines.append(f"- Description: {command.get('description', '')}")
    lines.append(f"- Auth required: `{command.get('auth_required', True)}`")

    args = command.get("arguments", [])
    if args:
        lines.append("- Arguments:")
        for arg in args:
            lines.append(f"  - `{arg['name']}` ({arg['type']}), required `{arg.get('required', False)}`")

    options = command.get("options", [])
    if options:
        lines.append("- Options:")
        for opt in options:
            default = json.dumps(opt.get("default"))
            bounds: list[str] = []
            if "min" in opt:
                bounds.append(f"min={opt['min']}")
            if "max" in opt:
                bounds.append(f"max={opt['max']}")
            if "enum" in opt:
                bounds.append(f"enum={opt['enum']}")
            extra = f" ({', '.join(bounds)})" if bounds else ""
            lines.append(f"  - `{opt['name']}` ({opt['type']}), default `{default}`{extra}")
    return "\n".join(lines)

