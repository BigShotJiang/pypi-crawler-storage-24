from __future__ import annotations

import argparse
from typing import Any

from ..context import CLIContext
from ..http import ZeroEvalAPI
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def cmd_evals_list(args: argparse.Namespace, ctx: CLIContext):
    rows = _api(args, ctx).list_evals(
        dataset_id=args.dataset_id,
        status=args.status,
        limit=args.limit,
        offset=args.offset,
    )
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_evals_get(args: argparse.Namespace, ctx: CLIContext):
    row = _api(args, ctx).get_eval(eval_id=args.eval_id)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_evals_summary(args: argparse.Namespace, ctx: CLIContext):
    return _api(args, ctx).get_eval_summary(eval_id=args.eval_id)


def cmd_evals_results(args: argparse.Namespace, ctx: CLIContext):
    rows = _api(args, ctx).get_eval_results(
        eval_id=args.eval_id,
        repetition=args.repetition,
        limit=args.limit,
        offset=args.offset,
    )
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_evals_scorers(args: argparse.Namespace, ctx: CLIContext):
    rows = _api(args, ctx).list_eval_scorers(eval_id=args.eval_id)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_evals_scores(args: argparse.Namespace, ctx: CLIContext):
    api = _api(args, ctx)
    rows = api.get_eval_scores(
        eval_id=args.eval_id,
        scorer_id=args.scorer_id,
        limit=args.limit,
        offset=args.offset,
    )
    rows = apply_query(rows, where=args.where, select=None, order=args.order)

    if args.include_eval_result or args.include_dataset_row:
        eval_results = api.get_eval_results(
            eval_id=args.eval_id,
            repetition=None,
            limit=10000,
            offset=0,
        )
        result_by_id = {r.get("id"): r for r in eval_results}
        dataset_rows_by_id: dict[str, dict[str, Any]] = {}
        if args.include_dataset_row:
            dataset_rows: list[dict[str, Any]] = []
            try:
                dataset_payload = api.get_dataset_rows(
                    dataset=args.include_dataset_row_dataset,
                    version=None,
                    subset=args.include_dataset_row_subset,
                    limit=args.include_dataset_row_limit,
                    offset=0,
                )
                dataset_rows = (
                    dataset_payload.get("rows")
                    if isinstance(dataset_payload, dict)
                    else dataset_payload
                ) or []
            except Exception:
                # Fallback for environments where /v1/datasets/{name}/data is unavailable.
                dataset_rows = _sdk_pull_dataset_rows(
                    dataset=args.include_dataset_row_dataset,
                    subset=args.include_dataset_row_subset,
                    limit=args.include_dataset_row_limit,
                    api=api,
                )
            if isinstance(dataset_rows, list):
                for row in dataset_rows:
                    key = row.get("row_id") if isinstance(row, dict) else None
                    if key is not None:
                        dataset_rows_by_id[str(key)] = row

        enriched: list[dict[str, Any]] = []
        for score in rows:
            score_obj = dict(score)
            eval_result_id = score_obj.get("eval_result_id")
            eval_result = result_by_id.get(eval_result_id)
            if args.include_eval_result:
                score_obj["eval_result"] = eval_result
            if args.include_dataset_row and isinstance(eval_result, dict):
                row_id = eval_result.get("row_id")
                if row_id is not None:
                    score_obj["dataset_row"] = dataset_rows_by_id.get(str(row_id))
            enriched.append(score_obj)
        rows = enriched
    if args.select:
        rows = apply_query(rows, where=None, select=args.select, order=None)
    return rows


def _sdk_pull_dataset_rows(
    *,
    dataset: str | None,
    subset: str | None,
    limit: int,
    api: ZeroEvalAPI,
) -> list[dict[str, Any]]:
    if not dataset:
        return []
    # Import local SDK from same package.
    import zeroeval as ze

    api_key = api._api_key  # noqa: SLF001
    api_url = api._base_url  # noqa: SLF001
    ze.init(api_key=api_key, api_url=api_url)
    ds = ze.Dataset.pull(dataset, subset=subset)
    rows: list[dict[str, Any]] = []
    for idx, row in enumerate(ds):
        if idx >= limit:
            break
        row_obj = row if isinstance(row, dict) else dict(row)
        if "row_id" not in row_obj:
            row_obj["row_id"] = str(idx + 1)
        rows.append(row_obj)
    return rows


def cmd_evals_traces(args: argparse.Namespace, ctx: CLIContext):
    api = _api(args, ctx)
    results = api.get_eval_results(
        eval_id=args.eval_id, repetition=args.repetition, limit=args.limit, offset=args.offset
    )
    trace_ids = sorted({row.get("trace_id") for row in results if row.get("trace_id")})
    traces: list[dict] = []
    for trace_id in trace_ids:
        trace = api.get_trace(trace_id)
        spans = api.get_spans_for_trace(trace_id, limit=args.spans_limit, offset=0)
        traces.append(
            {
                "trace_id": trace_id,
                "trace": trace,
                "spans": spans,
            }
        )
    return {
        "eval_id": args.eval_id,
        "trace_count": len(traces),
        "traces": traces,
    }


def register_evals_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]):
    evals = subparsers.add_parser("evals", help="Evaluation/run inspection commands")
    evals_sub = evals.add_subparsers(dest="evals_command", required=True)

    p_list = evals_sub.add_parser("list", help="List evals")
    p_list.add_argument("--dataset-id", default=None)
    p_list.add_argument("--status", default=None)
    p_list.add_argument("--limit", type=int, default=50)
    p_list.add_argument("--offset", type=int, default=0)
    p_list.add_argument("--where", action="append", default=[])
    p_list.add_argument("--select", default=None)
    p_list.add_argument("--order", default=None)
    p_list.set_defaults(handler=cmd_evals_list)

    p_get = evals_sub.add_parser("get", help="Get eval metadata")
    p_get.add_argument("eval_id")
    p_get.add_argument("--where", action="append", default=[])
    p_get.add_argument("--select", default=None)
    p_get.add_argument("--order", default=None)
    p_get.set_defaults(handler=cmd_evals_get)

    p_summary = evals_sub.add_parser("summary", help="Get eval summary")
    p_summary.add_argument("eval_id")
    p_summary.set_defaults(handler=cmd_evals_summary)

    p_results = evals_sub.add_parser("results", help="Get eval results")
    p_results.add_argument("eval_id")
    p_results.add_argument("--repetition", type=int, default=None)
    p_results.add_argument("--limit", type=int, default=100)
    p_results.add_argument("--offset", type=int, default=0)
    p_results.add_argument("--where", action="append", default=[])
    p_results.add_argument("--select", default=None)
    p_results.add_argument("--order", default=None)
    p_results.set_defaults(handler=cmd_evals_results)

    p_scorers = evals_sub.add_parser("scorers", help="List eval scorers")
    p_scorers.add_argument("eval_id")
    p_scorers.add_argument("--where", action="append", default=[])
    p_scorers.add_argument("--select", default=None)
    p_scorers.add_argument("--order", default=None)
    p_scorers.set_defaults(handler=cmd_evals_scorers)

    p_scores = evals_sub.add_parser("scores", help="Get scorer scores for an eval")
    p_scores.add_argument("eval_id")
    p_scores.add_argument("scorer_id")
    p_scores.add_argument("--limit", type=int, default=100)
    p_scores.add_argument("--offset", type=int, default=0)
    p_scores.add_argument("--where", action="append", default=[])
    p_scores.add_argument("--select", default=None)
    p_scores.add_argument("--order", default=None)
    p_scores.add_argument("--include-eval-result", action="store_true")
    p_scores.add_argument("--include-dataset-row", action="store_true")
    p_scores.add_argument("--include-dataset-row-dataset", default=None)
    p_scores.add_argument("--include-dataset-row-subset", default=None)
    p_scores.add_argument("--include-dataset-row-limit", type=int, default=10000)
    p_scores.set_defaults(handler=cmd_evals_scores)

    p_traces = evals_sub.add_parser(
        "traces",
        help="Resolve traces from eval results and fetch trace + spans",
    )
    p_traces.add_argument("eval_id")
    p_traces.add_argument("--repetition", type=int, default=None)
    p_traces.add_argument("--limit", type=int, default=100)
    p_traces.add_argument("--offset", type=int, default=0)
    p_traces.add_argument("--spans-limit", type=int, default=500)
    p_traces.set_defaults(handler=cmd_evals_traces)

