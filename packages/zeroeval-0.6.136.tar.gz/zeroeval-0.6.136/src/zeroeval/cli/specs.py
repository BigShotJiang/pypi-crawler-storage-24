from __future__ import annotations

from typing import Any

SPEC_VERSION = "1.0.0"


CLI_SPEC: dict[str, Any] = {
    "spec_version": SPEC_VERSION,
    "name": "zeroeval-cli",
    "mode": "agent-first",
    "non_interactive": True,
    "auth_precedence": [
        "Explicit CLI options",
        "Environment variables",
        "Global CLI config (~/.config/zeroeval/config.json or platform equivalent)",
    ],
    "output_contract": {
        "text": "Human-readable deterministic text (JSON pretty-print for objects).",
        "json": "Stable JSON payload suitable for automation.",
        "stderr_policy": "Errors only",
        "stdout_policy": "Payload only",
    },
    "global_options": [
        {
            "name": "--output",
            "type": "string",
            "required": False,
            "default": "text",
            "enum": ["text", "json"],
            "description": "Output format.",
        },
        {
            "name": "--api-base-url",
            "type": "string",
            "required": False,
            "default": "ZEROEVAL_BASE_URL|ZEROEVAL_API_URL|https://api.zeroeval.com",
            "description": "Override API base URL.",
        },
        {
            "name": "--project-id",
            "type": "string",
            "required": False,
            "default": None,
            "description": "Project context override (reserved for future server-side support).",
        },
        {
            "name": "--quiet",
            "type": "boolean",
            "required": False,
            "default": False,
            "description": "Suppress non-essential logs.",
        },
        {
            "name": "--timeout",
            "type": "number",
            "required": False,
            "default": 20.0,
            "description": "Request timeout in seconds.",
        },
    ],
    "exit_codes": {
        "0": "success",
        "2": "user_validation_error",
        "3": "auth_or_permission_error",
        "4": "remote_api_or_network_error",
    },
    "commands": [
        {
            "path": "setup",
            "description": "Interactive API-key onboarding flow.",
            "auth_required": False,
            "interactive": True,
            "output_schema": {"type": "object", "properties": {"ok": {"type": "boolean"}}},
            "options": [],
        },
        {
            "path": "auth set",
            "description": "Set global non-interactive auth config.",
            "auth_required": False,
            "interactive": False,
            "output_schema": {"type": "object"},
            "options": [
                {"name": "--api-key", "type": "string", "default": None},
                {"name": "--api-key-env", "type": "string", "default": None},
                {"name": "--api-base-url", "type": "string", "default": None},
            ],
        },
        {
            "path": "auth show",
            "description": "Show current global auth config.",
            "auth_required": False,
            "interactive": False,
            "output_schema": {"type": "object"},
            "options": [{"name": "--redact", "type": "boolean", "default": False}],
        },
        {
            "path": "auth clear",
            "description": "Clear global auth config.",
            "auth_required": False,
            "interactive": False,
            "output_schema": {"type": "object"},
            "options": [{"name": "--api-key-only", "type": "boolean", "default": False}],
        },
        {
            "path": "datasets list",
            "description": "List datasets.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "array"},
            "options": [
                {"name": "--limit", "type": "integer", "default": 100, "min": 1, "max": 1000},
                {"name": "--offset", "type": "integer", "default": 0, "min": 0},
            ],
        },
        {
            "path": "datasets get",
            "description": "Get dataset metadata by dataset name.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "object"},
            "arguments": [{"name": "dataset", "type": "string", "required": True}],
            "options": [],
        },
        {
            "path": "datasets versions",
            "description": "List versions for a dataset.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "array"},
            "arguments": [{"name": "dataset", "type": "string", "required": True}],
            "options": [],
        },
        {
            "path": "datasets rows",
            "description": "Fetch rows for a dataset.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "object", "properties": {"rows": {"type": "array"}}},
            "arguments": [{"name": "dataset", "type": "string", "required": True}],
            "options": [
                {"name": "--version", "type": "integer", "default": None},
                {"name": "--subset", "type": "string", "default": None},
                {"name": "--limit", "type": "integer", "default": 100, "min": 1, "max": 10000},
                {"name": "--offset", "type": "integer", "default": 0, "min": 0},
            ],
        },
        {
            "path": "evals list",
            "description": "List evals/runs.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "array"},
            "options": [
                {"name": "--dataset-id", "type": "string", "default": None},
                {"name": "--status", "type": "string", "default": None},
                {"name": "--limit", "type": "integer", "default": 50, "min": 1, "max": 200},
                {"name": "--offset", "type": "integer", "default": 0, "min": 0},
            ],
        },
        {
            "path": "evals get",
            "description": "Get eval metadata by eval ID.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "object"},
            "arguments": [{"name": "eval_id", "type": "string", "required": True}],
            "options": [],
        },
        {
            "path": "evals summary",
            "description": "Get eval summary.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "object"},
            "arguments": [{"name": "eval_id", "type": "string", "required": True}],
            "options": [],
        },
        {
            "path": "evals results",
            "description": "Get eval row results.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "array"},
            "arguments": [{"name": "eval_id", "type": "string", "required": True}],
            "options": [
                {"name": "--repetition", "type": "integer", "default": None},
                {"name": "--limit", "type": "integer", "default": 100, "min": 1, "max": 10000},
                {"name": "--offset", "type": "integer", "default": 0, "min": 0},
            ],
        },
        {
            "path": "evals scorers",
            "description": "List scorers for an eval.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "array"},
            "arguments": [{"name": "eval_id", "type": "string", "required": True}],
            "options": [],
        },
        {
            "path": "evals scores",
            "description": "Get scores for a scorer in an eval.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {"type": "array"},
            "arguments": [
                {"name": "eval_id", "type": "string", "required": True},
                {"name": "scorer_id", "type": "string", "required": True},
            ],
            "options": [
                {"name": "--limit", "type": "integer", "default": 100, "min": 1, "max": 10000},
                {"name": "--offset", "type": "integer", "default": 0, "min": 0},
            ],
        },
        {
            "path": "evals traces",
            "description": "Resolve traces from eval results and fetch traces + spans.",
            "auth_required": True,
            "interactive": False,
            "output_schema": {
                "type": "object",
                "properties": {
                    "eval_id": {"type": "string"},
                    "trace_count": {"type": "integer"},
                    "traces": {"type": "array"},
                },
            },
            "arguments": [{"name": "eval_id", "type": "string", "required": True}],
            "options": [
                {"name": "--repetition", "type": "integer", "default": None},
                {"name": "--limit", "type": "integer", "default": 100, "min": 1, "max": 10000},
                {"name": "--offset", "type": "integer", "default": 0, "min": 0},
                {"name": "--spans-limit", "type": "integer", "default": 500, "min": 1, "max": 10000},
            ],
        },
        {
            "path": "spec cli",
            "description": "Dump full CLI command/parameter specification.",
            "auth_required": False,
            "interactive": False,
            "output_schema": {"type": "object"},
            "options": [{"name": "--format", "type": "string", "default": "json", "enum": ["json", "markdown"]}],
        },
        {
            "path": "spec command",
            "description": "Dump spec for a single command path.",
            "auth_required": False,
            "interactive": False,
            "output_schema": {"type": "object"},
            "arguments": [{"name": "path", "type": "string", "required": True}],
            "options": [{"name": "--format", "type": "string", "default": "json", "enum": ["json", "markdown"]}],
        },
    ],
}


def get_command_spec(path: str) -> dict[str, Any] | None:
    normalized = " ".join(path.strip().split())
    for command in CLI_SPEC["commands"]:
        if command["path"] == normalized:
            return command
    return None

