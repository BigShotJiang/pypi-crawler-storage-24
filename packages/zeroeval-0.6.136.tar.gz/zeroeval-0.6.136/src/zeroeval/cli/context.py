from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CLIContext:
    output: str
    api_base_url: str | None
    project_id: str | None
    quiet: bool
    timeout: float

