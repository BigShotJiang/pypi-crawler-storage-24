from __future__ import annotations

from dataclasses import dataclass
from typing import Any

EXIT_SUCCESS = 0
EXIT_USER_ERROR = 2
EXIT_AUTH_ERROR = 3
EXIT_REMOTE_ERROR = 4


@dataclass
class CLIError(Exception):
    message: str
    exit_code: int = EXIT_USER_ERROR
    details: Any = None

    def __str__(self) -> str:
        return self.message

