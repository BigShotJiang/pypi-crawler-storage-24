from __future__ import annotations

import json
import os
from contextlib import suppress
from pathlib import Path
from typing import Any

from .errors import EXIT_REMOTE_ERROR, CLIError


def get_config_path() -> Path:
    if os.name == "nt":
        appdata = os.getenv("APPDATA")
        if appdata:
            return Path(appdata) / "zeroeval" / "config.json"
        return Path.home() / "AppData" / "Roaming" / "zeroeval" / "config.json"
    xdg = os.getenv("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "zeroeval" / "config.json"
    return Path.home() / ".config" / "zeroeval" / "config.json"


def load_config() -> dict[str, Any]:
    path = get_config_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        raise CLIError(
            f"Failed to read CLI config at {path}: {exc}",
            exit_code=EXIT_REMOTE_ERROR,
        ) from exc


def save_config(config: dict[str, Any]) -> Path:
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.write_text(json.dumps(config, indent=2, sort_keys=True))
        # Best effort on unix; Windows ignores this.
        with suppress(OSError):
            os.chmod(path, 0o600)
        return path
    except OSError as exc:
        raise CLIError(
            f"Failed to write CLI config at {path}: {exc}",
            exit_code=EXIT_REMOTE_ERROR,
        ) from exc

