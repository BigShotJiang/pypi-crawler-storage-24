import base64
import io
import json
import logging
import os
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional, Union

import requests

if TYPE_CHECKING:
    from .dataset_class import Dataset
    from .scorer_class import ScoreRecord, Scorer

logger = logging.getLogger("zeroeval")


# ---------------------------------------------------------------------------
# Abstract interfaces
# ---------------------------------------------------------------------------


class DatasetWriter(ABC):
    @abstractmethod
    def write(self, dataset: "Dataset", create_new_version: bool = False) -> None:
        pass


class ExperimentResultWriter(ABC):
    @abstractmethod
    def _write(self, payload: object) -> Union[str, None]:
        pass


class ScorerWriter(ABC):
    @abstractmethod
    def _write(
        self, scorer_or_score: Union["Scorer", "ScoreRecord"]
    ) -> Union[str, None]:
        pass


# ---------------------------------------------------------------------------
# Shared backend base with auth + org/project resolution
# ---------------------------------------------------------------------------


class _BackendWriter:
    """Handles authentication and lazy org/project resolution."""

    def __init__(self):
        self._api_key: Optional[str] = None
        self._headers: Optional[dict[str, str]] = None
        self._org_id: Optional[str] = None
        self._project_id: Optional[str] = None

    @property
    def api_url(self) -> str:
        return os.environ.get(
            "ZEROEVAL_API_URL", "https://api.zeroeval.com"
        ).rstrip("/")

    def _ensure_auth_setup(self):
        if self._api_key is None:
            self._api_key = os.environ.get("ZEROEVAL_API_KEY")
            if not self._api_key:
                raise ValueError("ZEROEVAL_API_KEY environment variable not set")
        if self._headers is None:
            self._headers = {"Authorization": f"Bearer {self._api_key}"}

    def _resolve_org_id(self) -> str:
        if self._org_id:
            return self._org_id
        self._ensure_auth_setup()
        resp = requests.get(
            f"{self.api_url}/organizations/my", headers=self._headers
        )
        resp.raise_for_status()
        orgs = resp.json()
        if not orgs:
            raise ValueError("No organizations found for this API key")
        self._org_id = orgs[0]["id"]
        return self._org_id

    def _resolve_project_id(self) -> str:
        if self._project_id:
            return self._project_id
        org_id = self._resolve_org_id()
        resp = requests.get(
            f"{self.api_url}/organizations/{org_id}/projects",
            headers=self._headers,
        )
        resp.raise_for_status()
        projects = resp.json()
        if not projects:
            raise ValueError(
                "No projects found — create one at app.zeroeval.com first"
            )
        self._project_id = projects[0]["id"]
        return self._project_id

    @staticmethod
    def _raise_for_response(resp: requests.Response) -> None:
        if resp.status_code in (401, 403):
            raise ValueError("Authentication error: check your API key")
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise ValueError(f"API error ({resp.status_code}): {detail}")


# ---------------------------------------------------------------------------
# Dataset writer — uploads Parquet via the Hub API
# ---------------------------------------------------------------------------


class DatasetBackendWriter(_BackendWriter, DatasetWriter):
    """Writes datasets to ZeroEval using the Hub API (Parquet + S3)."""

    def write(self, dataset: "Dataset", create_new_version: bool = False) -> None:
        self._ensure_auth_setup()
        org_id = self._resolve_org_id()
        slug = dataset.name

        # Create dataset (idempotent — 409 means already exists)
        resp = requests.post(
            f"{self.api_url}/v1/datasets",
            params={"organization_id": org_id},
            json={
                "slug": slug,
                "display_name": slug,
                "description": dataset.description or "",
                "visibility": "private",
            },
            headers=self._headers,
        )
        if resp.status_code == 409:
            logger.debug("Dataset '%s' exists, creating new version", slug)
        elif resp.ok:
            dataset._backend_id = resp.json()["id"]
        else:
            self._raise_for_response(resp)

        # Also fetch the dataset ID if we don't have it yet (409 case)
        if not dataset._backend_id:
            info = requests.get(
                f"{self.api_url}/v1/datasets/{org_id}/{slug}",
                headers=self._headers,
            )
            if info.ok:
                dataset._backend_id = info.json()["id"]

        self._upload_version(org_id, slug, dataset)

    def _upload_version(
        self, org_id: str, slug: str, dataset: "Dataset"
    ) -> None:
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError:
            raise ImportError(
                "pyarrow is required for dataset operations. "
                "Install with: pip install 'zeroeval[datasets]'"
            ) from None

        rows = dataset.data
        if not rows:
            table = pa.table({"id": pa.array([], type=pa.string())})
        else:
            all_keys = list(dict.fromkeys(k for row in rows for k in row))
            columns = {key: [row.get(key) for row in rows] for key in all_keys}
            table = pa.table(columns)

        buf = io.BytesIO()
        pq.write_table(table, buf)
        parquet_bytes = buf.getvalue()

        resp = requests.post(
            f"{self.api_url}/v1/datasets/{org_id}/{slug}/versions",
            json={
                "message": "Upload data via SDK",
                "files": [
                    {
                        "path": "data/default.parquet",
                        "content_base64": base64.b64encode(parquet_bytes).decode(),
                        "size_bytes": len(parquet_bytes),
                    }
                ],
            },
            headers=self._headers,
        )
        resp.raise_for_status()
        version = resp.json()
        dataset._version_id = version["id"]
        dataset._version_number = version["version_number"]
        logger.info(
            "Created version %s for dataset '%s'",
            version["version_number"],
            slug,
        )


# ---------------------------------------------------------------------------
# Eval/result writer — uses the /v1/evals API
# ---------------------------------------------------------------------------


class ExperimentResultBackendWriter(_BackendWriter, ExperimentResultWriter):
    """Backend helper for run/result authentication and project resolution."""

    def _write(self, payload: object) -> Union[str, None]:
        raise NotImplementedError(
            "Legacy Experiment writer path was removed. "
            "Use Dataset.eval(...) and Eval APIs."
        )


# ---------------------------------------------------------------------------
# Scorer/score writer — uses /v1/evals/{id}/scorers
# ---------------------------------------------------------------------------


class ScorerBackendWriter(_BackendWriter, ScorerWriter):
    """Writes scorers and scores to the ZeroEval backend."""

    def _write(
        self, scorer_or_score: Union["Scorer", "ScoreRecord"]
    ) -> Union[str, None]:
        from .scorer_class import ScoreRecord, Scorer
        
        self._ensure_auth_setup()

        if isinstance(scorer_or_score, Scorer):
            return self._create_scorer(scorer_or_score)
        elif isinstance(scorer_or_score, ScoreRecord):
            return self._create_score(scorer_or_score)
        return None

    def _create_scorer(self, scorer: "Scorer") -> Optional[str]:
        eval_id = scorer.eval_id
        try:
            resp = requests.post(
                f"{self.api_url}/v1/evals/{eval_id}/scorers",
                json={
                    "name": scorer.name,
                    "code": scorer.code,
                    "description": scorer.description,
                    "scoring_mode": scorer.scoring_mode,
                },
                headers=self._headers,
            )
            resp.raise_for_status()
            return resp.json()["id"]
        except requests.RequestException as e:
            logger.error("Failed to create scorer: %s", e)
            return None

    def _create_score(
        self, score_record: "ScoreRecord"
    ) -> Optional[str]:
        eval_id = score_record.scorer.eval_id
        scorer_id = score_record.scorer._backend_id
        if not scorer_id:
            logger.error("Cannot create score: scorer not synced")
            return None
        
        try:
            resp = requests.post(
                f"{self.api_url}/v1/evals/{eval_id}/scorers/{scorer_id}/scores",
                json=[
                    {
                        "eval_result_id": score_record.run_result_id,
                        "score_value": json.dumps(score_record.score_value)
                        if isinstance(score_record.score_value, (dict, list))
                        else str(score_record.score_value),
                        "score_type": "json"
                        if isinstance(score_record.score_value, (dict, list))
                        else "text",
                    }
                ],
                headers=self._headers,
            )
            resp.raise_for_status()
            items = resp.json()
            return items[0]["id"] if items else None
        except requests.RequestException as e:
            logger.error("Failed to create score: %s", e)
            return None
