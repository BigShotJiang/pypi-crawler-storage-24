from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Protocol

from ..execution import CheckpointConfig, ExecutionConfig


@dataclass(slots=True)
class ExecutionRequest:
    """Immutable execution input for the backend-agnostic kernel."""

    task_name: str
    task_func: Callable[[dict[str, Any]], dict[str, Any]]
    rows: list[dict[str, Any]]
    execution: ExecutionConfig
    checkpoint: CheckpointConfig
    completed_row_ids: set[str]


@dataclass(slots=True)
class ExecutionSummary:
    """Execution output from the kernel."""

    rows: list[dict[str, Any]]
    retry_attempts_total: int


class ResultFlusher(Protocol):
    def __call__(self, rows: list[dict[str, Any]]) -> None: ...


class TraceFlusher(Protocol):
    def __call__(self) -> None: ...

