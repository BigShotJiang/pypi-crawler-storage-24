from __future__ import annotations

import json
import logging
from typing import Any

import requests

from ..writer import ExperimentResultBackendWriter
from .schema import RunArtifactEvent

logger = logging.getLogger("zeroeval")


class BackendArtifactSink:
    """
    Adapter sink that projects artifact events to existing /v1/evals contracts.

    This preserves current backend behavior while moving SDK execution to event-first
    semantics.
    """

    def __init__(self, writer: ExperimentResultBackendWriter | None = None):
        self._writer = writer or ExperimentResultBackendWriter()
        self._result_ids: dict[str, str] = {}

    def write_event(self, event: RunArtifactEvent) -> None:
        eval_id = event.eval_id
        if not eval_id:
            return
        if event.event_type in ("sample_completed", "sample_failed"):
            self._write_sample_result(eval_id, event.payload)
        elif event.event_type == "metrics_computed":
            self._write_metrics(eval_id, event.payload)

    def _write_sample_result(self, eval_id: str, payload: dict[str, Any]) -> None:
        row = payload.get("row") or {}
        row_id = str(payload.get("row_id") or row.get("row_id") or row.get("id") or "")
        if not row_id:
            return
        outputs = payload.get("outputs") or []
        run_number = int(payload.get("run_number") or 1)
        result_data = {k: row.get(k) for k in outputs if k in row}
        runtime_meta = {
            "attempt": row.get("_attempt"),
            "skipped": row.get("_skipped"),
            "error": row.get("_error"),
            "error_code": row.get("_error_code"),
        }
        runtime_meta = {k: v for k, v in runtime_meta.items() if v not in (None, "")}
        if runtime_meta:
            result_data["_runtime"] = runtime_meta

        self._writer._ensure_auth_setup()
        resp = requests.post(
            f"{self._writer.api_url}/v1/evals/{eval_id}/results",
            json={
                "results": [
                    {
                        "row_id": row_id,
                        "result": result_data or None,
                        "trace_id": row.get("_trace_id"),
                        "repetition_number": run_number,
                    }
                ]
            },
            headers=self._writer._headers,
        )
        resp.raise_for_status()
        items = resp.json() or []
        if items:
            self._result_ids[row_id] = items[0]["id"]

    def _write_metrics(self, eval_id: str, payload: dict[str, Any]) -> None:
        self._writer._ensure_auth_setup()
        mode = payload.get("mode")
        if mode == "column":
            requests.post(
                f"{self._writer.api_url}/v1/evals/{eval_id}/column-metrics",
                json={
                    "metric_name": payload.get("name"),
                    "repetition_number": payload.get("run_number", 1),
                    "results": payload.get("results", {}),
                },
                headers=self._writer._headers,
            ).raise_for_status()
        elif mode == "run":
            requests.post(
                f"{self._writer.api_url}/v1/evals/{eval_id}/eval-metrics",
                json={
                    "metric_name": payload.get("name"),
                    "total_repetitions": payload.get("total_runs", 1),
                    "results": payload.get("results", {}),
                },
                headers=self._writer._headers,
            ).raise_for_status()
        elif mode == "row":
            # Row scores still flow through Eval's existing scorer path.
            logger.debug("Row metric projection is handled in scorer pipeline: %s", json.dumps(payload))

