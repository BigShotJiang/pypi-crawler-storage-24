from __future__ import annotations

import json
from pathlib import Path
from typing import Protocol

from .schema import RunArtifactEvent


class ArtifactSink(Protocol):
    def write_event(self, event: RunArtifactEvent) -> None: ...


class InMemoryArtifactSink:
    def __init__(self):
        self.events: list[RunArtifactEvent] = []

    def write_event(self, event: RunArtifactEvent) -> None:
        self.events.append(event)


class FileArtifactSink:
    """Append-only JSONL sink."""

    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write_event(self, event: RunArtifactEvent) -> None:
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event.to_dict(), ensure_ascii=True) + "\n")

