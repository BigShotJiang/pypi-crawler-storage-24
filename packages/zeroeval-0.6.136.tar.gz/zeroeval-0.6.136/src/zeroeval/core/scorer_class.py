import logging
from typing import Any, Optional

from .writer import ScorerBackendWriter, ScorerWriter

logger = logging.getLogger("zeroeval")


class Scorer:
    """Defines a scorer for a run."""

    def __init__(
        self,
        name: str,
        code: str,
        description: str,
        eval_id: str,
        scoring_mode: str = "row",
    ):
        self.name = name
        self.code = code
        self.description = description
        self.eval_id = eval_id
        self.scoring_mode = scoring_mode
        self._backend_id: Optional[str] = None
        self._writer: ScorerWriter = ScorerBackendWriter()

    def _write(self) -> Optional[str]:
        if not self._backend_id:
            assigned_id = self._writer._write(self)
            if assigned_id:
                self._backend_id = assigned_id
        return self._backend_id


class ScoreRecord:
    """Persisted scorer output for a single run result."""

    def __init__(
        self,
        scorer: Scorer,
        score_value: Any,
        run_result_id: str,
        row_id: str,
    ):
        self.scorer = scorer
        self.score_value = score_value
        self.run_result_id = run_result_id
        self.row_id = row_id
        self._writer = scorer._writer

    def _write(self) -> Optional[str]:
        return self._writer._write(self)

