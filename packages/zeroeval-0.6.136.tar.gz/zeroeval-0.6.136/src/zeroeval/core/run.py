import logging
import inspect
import os
from typing import Any, Callable, Dict, List, Optional, Union

import requests

from .artifacts import (
    BackendArtifactSink,
    FileArtifactSink,
    InMemoryArtifactSink,
    RunArtifactRecorder,
)
from .dataset_class import DotDict
from .execution import EvalHealth, ResumeConfig
from .evaluation import Evaluation, EvaluationMode, get_evaluation
from .scorer_class import Scorer, ScoreRecord
from .metrics import get_column_metric, get_run_metric
from .eval_collection import EvalCollection
from .writer import ExperimentResultBackendWriter

logger = logging.getLogger("zeroeval")


class Eval:
    """
    Represents the result of running a task on a dataset.
    Contains the results and can be scored with scorers.
    """

    def __init__(
        self,
        dataset_name: str,
        dataset_id: str,
        dataset_version_id: str,
        task_name: str,
        task_code: str,
        rows: list[dict[str, Any]],
        outputs: list[str],
        subset_name: Optional[str] = None,
        repetition_number: int = 1,
        total_runs: int = 1,
        task_func: Optional[Callable] = None,
        dataset_ref: Optional[Any] = None,
        experiment_id: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        execution_config: Optional[Any] = None,
        checkpoint_config: Optional[Any] = None,
        resume_config: Optional[Any] = None,
        workers: Optional[int] = None,
    ):
        self.dataset_name = dataset_name
        self.dataset_id = dataset_id
        self.dataset_version_id = dataset_version_id
        self.subset_name = subset_name
        self.task_name = task_name
        self.task_code = task_code
        self.rows = rows
        self.outputs = outputs
        self.repetition_number = repetition_number
        self.total_runs = total_runs
        self._task_func = task_func
        self._dataset_ref = dataset_ref
        self._experiment_id = experiment_id
        self.parameters = parameters or {}
        self.execution_config = execution_config
        self.checkpoint_config = checkpoint_config
        self.resume_config = resume_config
        self.workers = workers
        self._writer = ExperimentResultBackendWriter()
        self._scorers: list[Scorer] = []
        self._scores: list[ScoreRecord] = []
        self._scorer_funcs: list = []
        self._scoring_plans: list[
            dict[str, Any]
        ] = []
        self._experiment_created = False
        self._result_ids: dict[str, str] = {}  # row_id → run_result_id
        self.metrics: dict[str, Any] = {}
        self._all_evals: Optional[list["Eval"]] = None
        self._results_written = False
        self._retry_attempts_total = 0
        self.health: dict[str, Any] = {}
        self._artifact_memory_sink: InMemoryArtifactSink | None = None
        self._artifact_recorder: RunArtifactRecorder | None = None
        self._artifact_consistency_errors: list[str] = []
        self._display: Any = None

    @property
    def id(self) -> Optional[str]:
        """Public eval identifier used by backend APIs."""
        return self._experiment_id

    def _ensure_experiment_exists(self):
        """Create an eval on the backend if one doesn't exist yet."""
        if self._experiment_created or self._experiment_id:
            return

        if not self.dataset_id:
            raise ValueError("Cannot create eval without dataset ID")

        try:
            self._writer._ensure_auth_setup()
            project_id = self._writer._resolve_project_id()
            payload = {
                "project_id": project_id,
                "dataset_id": self.dataset_id,
                "name": self.task_name,
                "description": (
                    f"Eval with {self.total_runs} repetitions"
                    if self.total_runs > 1
                    else ""
                ),
                "config": self.parameters,
                "total_repetitions": self.total_runs,
            }
            if self.subset_name:
                payload["subset_name"] = self.subset_name
            resp = requests.post(
                f"{self._writer.api_url}/v1/evals",
                json=payload,
                headers=self._writer._headers,
            )
            if not resp.ok:
                detail = resp.text
                try:
                    detail_json = resp.json()
                    detail = detail_json.get("detail", detail)
                except Exception:
                    pass
                raise RuntimeError(
                    f"Could not create eval (status={resp.status_code}): {detail}"
                )
            self._experiment_id = resp.json()["id"]
            self._experiment_created = True
            logger.info("Created eval: %s", self._experiment_id)
        except Exception as e:
            logger.error("Could not create eval: %s", e)
            raise RuntimeError(f"Eval creation failed: {e}") from e

    def _update_backend_status(self, status: str) -> None:
        """Best-effort eval status update for frontend/backend lifecycle."""
        if not self._experiment_id:
            return
        try:
            self._writer._ensure_auth_setup()
            resp = requests.patch(
                f"{self._writer.api_url}/v1/evals/{self._experiment_id}",
                json={"status": status},
                headers=self._writer._headers,
            )
            resp.raise_for_status()
        except Exception as e:
            logger.warning(
                "Failed to update eval status (%s) for %s: %s",
                status,
                self._experiment_id,
                e,
            )

    def _sync_total_repetitions(self) -> None:
        """Best-effort sync of total repetition count to backend eval metadata."""
        if not self._experiment_id:
            return
        try:
            self._writer._ensure_auth_setup()
            description = (
                f"Eval with {self.total_runs} repetitions"
                if self.total_runs > 1
                else ""
            )
            resp = requests.patch(
                f"{self._writer.api_url}/v1/evals/{self._experiment_id}",
                json={
                    "total_repetitions": self.total_runs,
                    "description": description,
                },
                headers=self._writer._headers,
            )
            resp.raise_for_status()
        except Exception as e:
            logger.warning(
                "Failed to sync total repetitions (%s) for %s: %s",
                self.total_runs,
                self._experiment_id,
                e,
            )

    def _write_results(self):
        """Submit results for this eval to the backend (batch)."""
        if not self._experiment_id or self._results_written:
            return

        self._submit_result_batch(self.rows)
        self._results_written = True

    def _env_flag_enabled(self, name: str, default: bool = False) -> bool:
        raw = os.getenv(name)
        if raw is None:
            return default
        return raw.strip().lower() in {"1", "true", "yes", "on"}

    def _artifact_enabled(self) -> bool:
        return self._env_flag_enabled("ZEROEVAL_ARTIFACT_V1", default=False) or self._env_flag_enabled(
            "ZEROEVAL_DUAL_WRITE_COMPARE", default=False
        )

    def _ensure_artifact_recorder(self) -> None:
        if self._artifact_recorder is not None or not self._artifact_enabled():
            return
        eval_id = self._experiment_id or self.task_name
        sinks = []
        self._artifact_memory_sink = InMemoryArtifactSink()
        sinks.append(self._artifact_memory_sink)

        path = os.getenv("ZEROEVAL_ARTIFACT_JSONL_PATH")
        if path:
            sinks.append(FileArtifactSink(path))

        if self._env_flag_enabled("ZEROEVAL_ARTIFACT_BACKEND_SINK", default=False):
            sinks.append(BackendArtifactSink(self._writer))

        self._artifact_recorder = RunArtifactRecorder(eval_id=eval_id, sinks=sinks)

    def get_artifact_events(self) -> list[dict[str, Any]]:
        if not self._artifact_memory_sink:
            return []
        return [event.to_dict() for event in self._artifact_memory_sink.events]

    def validate_artifact_consistency(self) -> list[str]:
        self._artifact_consistency_errors = []
        if not self._artifact_recorder:
            return self._artifact_consistency_errors
        events = self.get_artifact_events()
        sample_done = [
            e
            for e in events
            if e.get("event_type") in ("sample_completed", "sample_failed")
        ]
        if len(sample_done) != len(self.rows):
            self._artifact_consistency_errors.append(
                f"sample_event_count_mismatch: events={len(sample_done)} rows={len(self.rows)}"
            )
        if events:
            seqs = [int(e.get("seq", 0)) for e in events]
            if seqs != list(range(1, len(seqs) + 1)):
                self._artifact_consistency_errors.append("non_monotonic_event_sequence")
        return self._artifact_consistency_errors

    def _submit_result_batch(self, rows: List[dict[str, Any]]):
        """Submit a batch of rows to backend and update row->result mapping."""
        if not self._experiment_id:
            return

        self._writer._ensure_auth_setup()

        # Build batch payload.
        batch = []
        for i, row in enumerate(rows):
            row_id = row.get("row_id") or row.get("id") or str(i)
            result_data = {k: row.get(k) for k in self.outputs if k in row}
            runtime_meta = {
                "attempt": row.get("_attempt"),
                "skipped": row.get("_skipped"),
                "error": row.get("_error"),
                "error_code": row.get("_error_code"),
            }
            runtime_meta = {
                k: v for k, v in runtime_meta.items() if v not in (None, "")
            }
            if runtime_meta:
                result_data["_runtime"] = runtime_meta
            trace_id = row.get("_trace_id")

            batch.append(
                {
                    "row_id": str(row_id),
                    "result": result_data or None,
                    "trace_id": trace_id,
                    "repetition_number": self.repetition_number,
                }
            )

        if not batch:
            return

        try:
            resp = requests.post(
                f"{self._writer.api_url}/v1/evals/{self._experiment_id}/results",
                json={"results": batch},
                headers=self._writer._headers,
            )
            if not resp.ok:
                detail = resp.text
                try:
                    detail_json = resp.json()
                    detail = detail_json.get("detail", detail)
                except Exception:
                    pass
                raise RuntimeError(
                    f"Failed to submit eval results (status={resp.status_code}): {detail}"
                )

            # Build row_id → result_id mapping for evaluations
            result_items = resp.json()
            for item in result_items:
                self._result_ids[item["row_id"]] = item["id"]
            logger.info(
                "Submitted %d results to eval %s",
                len(result_items),
                self._experiment_id,
            )
        except Exception as e:
            logger.error("Failed to submit results: %s", e)
            raise RuntimeError(f"Eval result submission failed: {e}") from e

    def load_existing_result_row_ids(self, repetition: Optional[int] = None) -> set[str]:
        """Fetch already persisted row_ids for this eval/repetition."""
        if not self._experiment_id:
            return set()

        self._writer._ensure_auth_setup()
        offset = 0
        limit = 1000
        found_ids: set[str] = set()

        while True:
            params: dict[str, Any] = {"limit": limit, "offset": offset}
            if repetition is not None:
                params["repetition"] = repetition
            try:
                resp = requests.get(
                    f"{self._writer.api_url}/v1/evals/{self._experiment_id}/results",
                    params=params,
                    headers=self._writer._headers,
                )
                resp.raise_for_status()
                items = resp.json() or []
            except Exception as e:
                logger.warning("Could not fetch existing eval results: %s", e)
                break

            if not items:
                break

            for item in items:
                row_id = str(item.get("row_id"))
                result_id = item.get("id")
                if row_id and result_id:
                    found_ids.add(row_id)
                    self._result_ids[row_id] = result_id

            if len(items) < limit:
                break
            offset += len(items)

        return found_ids

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def eval(
        self,
        scorers: List[Union[Callable, Evaluation, str]],
        column_map: Optional[dict[str, Union[str, dict[str, str]]]] = None,
        **kwargs,
    ) -> "Eval":
        """Apply scorers to the eval results.

        Args:
            scorers: Scorers to execute.
            column_map: Explicit scorer input mapping. Supports:
                - Global mapping: {"arg_name": "column_name"}
                - Per-scorer mapping:
                  {"eval_name": {"arg_name": "column_name"}}
            **kwargs: Deprecated global mapping form.
        """
        if column_map is not None and kwargs:
            raise ValueError(
                "Use either 'column_map' or legacy kwargs mapping, not both."
            )

        # Backward compatibility: kwargs still act as a global column map.
        if column_map is None and kwargs:
            logger.warning(
                "Passing scorer column mapping as kwargs is deprecated. "
                "Use column_map={...} instead."
            )
            column_map = kwargs

        column_map = column_map or {}
        stored_column_map: dict[str, Union[str, dict[str, str]]] = {}
        for key, value in column_map.items():
            if isinstance(value, dict):
                stored_column_map[key] = dict(value)
            else:
                stored_column_map[key] = value
        self._scorer_funcs.extend(scorers)
        self._scoring_plans.append(
            {
                "scorers": list(scorers),
                "column_map": stored_column_map,
            }
        )

        eval_objects: list[Evaluation] = []
        for scorer in scorers:
            if isinstance(scorer, str):
                eval_obj = get_evaluation(scorer)
                if not eval_obj:
                    raise ValueError(
                        f"Scorer '{scorer}' not found in registry"
                    )
                eval_objects.append(eval_obj)
            elif isinstance(scorer, Evaluation):
                eval_objects.append(scorer)
            elif callable(scorer):
                if hasattr(scorer, "_is_evaluation"):
                    eval_obj = (
                        scorer
                        if isinstance(scorer, Evaluation)
                        else get_evaluation(scorer.__name__)
                    )
                    eval_objects.append(eval_obj)
                else:
                    from .evaluation import evaluation

                    eval_decorator = evaluation(
                        mode="row", outputs=[scorer.__name__]
                    )
                    eval_obj = eval_decorator(scorer)
                    eval_objects.append(eval_obj)
            else:
                raise TypeError(f"Invalid scorer type: {type(scorer)}")

        self._validate_eval_column_map(eval_objects, column_map)

        row_evals = [e for e in eval_objects if e.mode == EvaluationMode.ROW]
        column_evals = [
            e for e in eval_objects if e.mode == EvaluationMode.COLUMN
        ]
        run_evals = [e for e in eval_objects if e.mode == EvaluationMode.RUN]

        if self.dataset_id:
            self._ensure_experiment_exists()
            self._write_results()

        all_scorer_names = [e.name for e in eval_objects]
        if self._display and all_scorer_names:
            self._display.start_scoring(all_scorer_names)

        if row_evals:
            self._process_row_scores(row_evals, column_map=column_map)
            if self._display:
                for e in row_evals:
                    self._display.scorer_done(e.name)
        if column_evals:
            self._process_column_scores(column_evals, column_map=column_map)
            if self._display:
                for e in column_evals:
                    self._display.scorer_done(e.name)
        if run_evals and self._all_evals:
            self._process_run_scores(
                run_evals, self._all_evals, column_map=column_map
            )
            if self._display:
                for e in run_evals:
                    self._display.scorer_done(e.name)
        elif run_evals:
            logger.warning(
                "Eval-level evaluations require multiple repetitions. Use .repeat() first."
            )

        if self._display and all_scorer_names:
            self._display.finish_scoring()
            self._display.show_summary(
                metrics=self.metrics,
                health=self.health,
                eval_id=self.id,
            )

        return self

    def _available_row_columns(self) -> set[str]:
        cols: set[str] = set()
        for row in self.rows:
            cols.update(row.keys())
        return cols

    def _required_eval_kwargs(self, eval_obj: Evaluation) -> list[str]:
        signature = inspect.signature(eval_obj.func)
        params = list(signature.parameters.values())
        # row/column/run scorers may accept first positional input
        if eval_obj.mode in (
            EvaluationMode.ROW,
            EvaluationMode.COLUMN,
            EvaluationMode.RUN,
        ):
            if params:
                params = params[1:]

        required: list[str] = []
        for param in params:
            if param.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            ):
                continue
            if param.default is inspect.Parameter.empty:
                required.append(param.name)
        return required

    def _validate_eval_column_map(
        self,
        eval_objects: list[Evaluation],
        column_map: dict[str, Union[str, dict[str, str]]],
    ) -> None:
        if not eval_objects:
            return

        available_cols = self._available_row_columns()
        for eval_obj in eval_objects:
            if eval_obj.mode == EvaluationMode.ROW:
                available_cols.update(eval_obj.outputs)
        nested = any(isinstance(v, dict) for v in column_map.values())

        for eval_obj in eval_objects:
            required_kwargs = self._required_eval_kwargs(eval_obj)
            resolved_map = self._resolve_eval_column_map(eval_obj, column_map)

            if eval_obj.mode == EvaluationMode.ROW:
                missing_kwargs = [
                    arg_name for arg_name in required_kwargs if arg_name not in resolved_map
                ]
                if missing_kwargs:
                    raise ValueError(
                        f"Evaluation '{eval_obj.name}' requires mapped arguments "
                        f"{missing_kwargs}. Provide column_map for these arguments."
                    )

            if eval_obj.mode in (EvaluationMode.ROW, EvaluationMode.COLUMN):
                for arg_name, column_name in resolved_map.items():
                    if column_name not in available_cols:
                        raise ValueError(
                            f"Evaluation '{eval_obj.name}' maps argument '{arg_name}' "
                            f"to unknown column '{column_name}'."
                        )

            if nested and not isinstance(column_map.get(eval_obj.name), dict) and required_kwargs:
                # In nested mode, scorers with required mapped args must declare explicit map.
                # This prevents accidental silent fallbacks.
                missing_kwargs = [
                    arg_name for arg_name in required_kwargs if arg_name not in resolved_map
                ]
                if missing_kwargs and eval_obj.mode == EvaluationMode.ROW:
                    raise ValueError(
                        f"Nested column_map is missing mapping for evaluation "
                        f"'{eval_obj.name}' required args {missing_kwargs}."
                    )

    def _resolve_eval_column_map(
        self,
        eval_obj: Evaluation,
        column_map: dict[str, Union[str, dict[str, str]]],
    ) -> dict[str, str]:
        if not column_map:
            return {}

        nested = any(isinstance(v, dict) for v in column_map.values())
        if not nested:
            return {k: v for k, v in column_map.items() if isinstance(v, str)}

        per_eval = column_map.get(eval_obj.name)
        if isinstance(per_eval, dict):
            return {
                arg_name: col_name
                for arg_name, col_name in per_eval.items()
                if isinstance(col_name, str)
            }
        return {}

    def _ensure_backend_row_scorers(
        self, scorers: List[Evaluation]
    ) -> dict[str, Scorer]:
        """Ensure row scorers exist in backend and return by-name mapping."""
        if not self._experiment_id:
            return {}

        by_name: dict[str, Scorer] = {}
        try:
            self._writer._ensure_auth_setup()
            resp = requests.get(
                f"{self._writer.api_url}/v1/evals/{self._experiment_id}/scorers",
                headers=self._writer._headers,
            )
            if resp.ok:
                for item in resp.json() or []:
                    name = item.get("name")
                    if not name:
                        continue
                    scorer = Scorer(
                        name=str(name),
                        code=str(item.get("code") or ""),
                        description=str(item.get("description") or ""),
                        eval_id=self._experiment_id,
                        scoring_mode=str(item.get("scoring_mode") or "row"),
                    )
                    scorer._backend_id = str(item.get("id") or "")
                    by_name[scorer.name] = scorer
        except Exception as e:
            logger.warning(
                "Failed to load backend scorers for eval %s: %s",
                self._experiment_id,
                e,
            )

        for eval_obj in scorers:
            if eval_obj.name in by_name:
                continue
            try:
                scorer_db = Scorer(
                    name=eval_obj.name,
                    code=eval_obj._code,
                    description=eval_obj.description,
                    eval_id=self._experiment_id,
                    scoring_mode=eval_obj.mode.value,
                )
                scorer_db._write()
                by_name[eval_obj.name] = scorer_db
            except Exception as e:
                logger.warning(
                    "Failed to create scorer '%s' for eval %s: %s",
                    eval_obj.name,
                    self._experiment_id,
                    e,
                )

        self._scorers = list(by_name.values())
        return by_name

    def _process_row_scores(
        self,
        scorers: List[Evaluation],
        column_map: dict[str, Union[str, dict[str, str]]],
    ):
        scorer_by_name = self._ensure_backend_row_scorers(scorers)

        for i, row in enumerate(self.rows):
            for eval_obj in scorers:
                try:
                    resolved_map = self._resolve_eval_column_map(
                        eval_obj, column_map
                    )
                    eval_kwargs = {
                        arg_name: row.get(column_name)
                        for arg_name, column_name in resolved_map.items()
                    }
                    eval_result = eval_obj(DotDict(row), **eval_kwargs)
                    row.update(eval_result)
                    scorer_db = scorer_by_name.get(eval_obj.name)
                    if self._experiment_id and scorer_db:
                        self._save_score_result(
                            scorer_db, eval_result, row, i
                        )
                except Exception as e:
                    logger.error(
                        "Scorer %s failed on row %d: %s",
                        eval_obj.name,
                        i,
                        e,
                    )

    def _process_column_scores(
        self,
        scorers: List[Evaluation],
        column_map: dict[str, Union[str, dict[str, str]]],
    ):
        for eval_obj in scorers:
            try:
                resolved_map = self._resolve_eval_column_map(eval_obj, column_map)
                if resolved_map:
                    eval_kwargs = {
                        arg_name: [row.get(column_name) for row in self.rows]
                        for arg_name, column_name in resolved_map.items()
                    }
                    eval_result = eval_obj(**eval_kwargs)
                else:
                    eval_result = eval_obj(self.rows)
                self.metrics.update(eval_result)
                self._persist_column_metric(eval_obj.name, eval_result)
            except Exception as e:
                logger.error(
                    "Column scorer %s failed: %s", eval_obj.name, e
                )

    def _process_run_scores(
        self,
        scorers: List[Evaluation],
        all_runs: List["Eval"],
        column_map: dict[str, Union[str, dict[str, str]]],
    ):
        for eval_obj in scorers:
            try:
                resolved_map = self._resolve_eval_column_map(eval_obj, column_map)
                eval_result = eval_obj(all_runs, **resolved_map)
                self.metrics.update(eval_result)
                self._persist_run_metric(eval_obj.name, eval_result, len(all_runs))
            except Exception as e:
                logger.error(
                    "Eval scorer %s failed: %s", eval_obj.name, e
                )

    def _persist_column_metric(self, metric_name: str, results: dict[str, Any]) -> None:
        if self._artifact_recorder:
            self._artifact_recorder.record(
                "metrics_computed",
                {
                    "mode": "column",
                    "name": metric_name,
                    "run_number": self.repetition_number,
                    "results": results,
                },
            )
        if not self._experiment_id:
            return
        try:
            self._writer._ensure_auth_setup()
            resp = requests.post(
                f"{self._writer.api_url}/v1/evals/{self._experiment_id}/column-metrics",
                json={
                    "metric_name": metric_name,
                    "run_number": self.repetition_number,
                    "results": results,
                },
                headers=self._writer._headers,
            )
            resp.raise_for_status()
        except Exception as e:
            logger.warning("Could not persist column metric '%s': %s", metric_name, e)

    def _persist_run_metric(
        self, metric_name: str, results: dict[str, Any], total_runs: int
    ) -> None:
        if self._artifact_recorder:
            self._artifact_recorder.record(
                "metrics_computed",
                {
                    "mode": "run",
                    "name": metric_name,
                    "total_runs": total_runs,
                    "results": results,
                },
            )
        if not self._experiment_id:
            return
        try:
            self._writer._ensure_auth_setup()
            resp = requests.post(
                f"{self._writer.api_url}/v1/evals/{self._experiment_id}/eval-metrics",
                json={
                    "metric_name": metric_name,
                    "total_runs": total_runs,
                    "results": results,
                },
                headers=self._writer._headers,
            )
            resp.raise_for_status()
        except Exception as e:
            logger.warning("Could not persist run metric '%s': %s", metric_name, e)

    def _save_score_result(
        self,
        scorer_db: Scorer,
        eval_result: dict,
        row: dict,
        row_idx: int,
    ):
        row_id = row.get("row_id") or row.get("id") or str(row_idx)
        result_id = self._result_ids.get(str(row_id))
        if not result_id:
            return

        score = ScoreRecord(
            scorer=scorer_db,
            score_value=eval_result,
            run_result_id=result_id,
            row_id=str(row_id),
        )
        score._write()
        self._scores.append(score)

    # ------------------------------------------------------------------
    # Repeat
    # ------------------------------------------------------------------

    def repeat(self, n: int) -> EvalCollection:
        """Repeat the eval n times total (including this eval)."""
        if not self._task_func or not self._dataset_ref:
            raise ValueError(
                "Cannot repeat without task function and dataset reference. "
                "Use dataset.eval() instead."
            )
        if n < 1:
            raise ValueError("Number of repeats must be at least 1")

        self.total_runs = n
        self._sync_total_repetitions()
        all_runs = [self]

        for run_num in range(2, n + 1):
            logger.info("Running eval (repetition %d/%d)...", run_num, n)
            dataset_eval = getattr(self._dataset_ref, "eval", None)
            if dataset_eval is None:
                raise ValueError("Dataset reference does not support eval().")
            new_run = dataset_eval(
                self._task_func,
                repetition_number=run_num,
                total_runs=n,
                experiment_id=self._experiment_id,
                parameters=self.parameters,
                workers=self.workers,
                execution=self.execution_config,
                checkpoint=self.checkpoint_config,
                resume=self.resume_config,
            )
            new_run._scorers = self._scorers
            if self._scoring_plans:
                for plan in self._scoring_plans:
                    plan_scorers = plan.get("scorers") or []
                    plan_column_map = plan.get("column_map") or {}
                    new_run.eval(
                        plan_scorers,
                        column_map=plan_column_map,
                    )
            elif self._scorer_funcs:
                # Backward compatibility for runs created before plan tracking.
                new_run.eval(self._scorer_funcs)
            all_runs.append(new_run)

        self._all_evals = all_runs
        return EvalCollection(all_runs)

    def score(
        self,
        scorers: list[Callable],
        column_map: Optional[dict[str, Union[str, dict[str, str]]]] = None,
        **kwargs,
    ) -> "Eval":
        """Alias for eval()."""
        return self.eval(scorers, column_map=column_map, **kwargs)

    def resume(
        self,
        task_func: Optional[Callable] = None,
        *,
        execution: Optional[Any] = None,
        checkpoint: Optional[Any] = None,
        resume: Optional[ResumeConfig] = None,
        workers: Optional[int] = None,
    ) -> "Eval":
        """Resume this eval with skip-completed semantics by default."""
        if not self._dataset_ref:
            raise ValueError("Cannot resume without dataset reference.")

        selected_task = task_func or self._task_func
        if not selected_task:
            raise ValueError(
                "Cannot resume without a task function. Pass task_func explicitly."
            )

        dataset_eval = getattr(self._dataset_ref, "eval", None)
        if dataset_eval is None:
            raise ValueError("Dataset reference does not support eval().")

        return dataset_eval(
            selected_task,
            repetition_number=self.repetition_number,
            total_runs=self.total_runs,
            eval_id=self.id,
            parameters=self.parameters,
            workers=workers if workers is not None else self.workers,
            execution=execution if execution is not None else self.execution_config,
            checkpoint=checkpoint if checkpoint is not None else self.checkpoint_config,
            resume=resume
            if resume is not None
            else (
                self.resume_config
                if self.resume_config is not None
                else ResumeConfig(mode="force", skip_completed=True)
            ),
        )

    def set_retry_attempts(self, attempts: int) -> None:
        self._retry_attempts_total = max(0, attempts)

    def finalize_health(self) -> dict[str, Any]:
        total = len(self.rows)
        success_count = 0
        error_count = 0
        skipped_count = 0
        retry_success_count = 0

        for row in self.rows:
            if row.get("_skipped"):
                skipped_count += 1
                continue
            if row.get("_error"):
                error_count += 1
                continue
            success_count += 1
            if int(row.get("_attempt", 1)) > 1:
                retry_success_count += 1

        success_rate = (success_count / total) if total else 0.0
        error_rate = (error_count / total) if total else 0.0
        retry_success_rate = (
            (retry_success_count / success_count) if success_count else 0.0
        )
        if total > 0 and skipped_count == total and error_count == 0:
            status = "resumed"
        else:
            status = (
                "healthy"
                if error_rate <= 0.10 and success_rate >= 0.90
                else "degraded"
            )

        run_health = EvalHealth(
            success_count=success_count,
            error_count=error_count,
            skipped_count=skipped_count,
            total_count=total,
            success_rate=success_rate,
            error_rate=error_rate,
            retry_success_rate=retry_success_rate,
            status=status,
            extra={"retry_attempts_total": self._retry_attempts_total},
        )
        self.health = {
            "success_count": run_health.success_count,
            "error_count": run_health.error_count,
            "skipped_count": run_health.skipped_count,
            "total_count": run_health.total_count,
            "success_rate": run_health.success_rate,
            "error_rate": run_health.error_rate,
            "retry_success_rate": run_health.retry_success_rate,
            "status": run_health.status,
            **run_health.extra,
        }
        return self.health

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def column_metrics(
        self, metrics: List[Union[Callable, Evaluation, str]]
    ) -> "Eval":
        eval_objects: list[Evaluation] = []
        for metric in metrics:
            if isinstance(metric, str):
                metric_obj = get_column_metric(metric)
                if not metric_obj:
                    logger.warning("Column metric '%s' not found", metric)
                    continue
                eval_objects.append(metric_obj)
                continue
            elif isinstance(metric, Evaluation):
                if metric.mode != EvaluationMode.COLUMN:
                    logger.warning(
                        "Skipping non-column metric '%s' in column_metrics",
                        metric.name,
                    )
                    continue
                eval_objects.append(metric)
                continue
            elif callable(metric):
                from .evaluation import evaluation as evaluation_decorator

                eval_objects.append(
                    evaluation_decorator(
                        mode="column", outputs=[metric.__name__]
                    )(metric)
                )
                continue
            else:
                continue

        if not eval_objects:
            return self
        return self.eval(eval_objects)

    def run_metrics(
        self,
        metrics: List[Union[Callable, Evaluation, str]],
        all_runs: List["Eval"],
    ) -> "Eval":
        eval_objects: list[Evaluation] = []
        for metric in metrics:
            if isinstance(metric, str):
                metric_obj = get_run_metric(metric)
                if not metric_obj:
                    logger.warning("Eval metric '%s' not found", metric)
                    continue
                eval_objects.append(metric_obj)
                continue
            elif isinstance(metric, Evaluation):
                if metric.mode != EvaluationMode.RUN:
                    logger.warning(
                        "Skipping non-run metric '%s' in run_metrics",
                        metric.name,
                    )
                    continue
                eval_objects.append(metric)
                continue
            elif callable(metric):
                from .evaluation import evaluation as evaluation_decorator

                eval_objects.append(
                    evaluation_decorator(
                        mode="run", outputs=[metric.__name__]
                    )(metric)
                )
                continue
            else:
                continue

        if not eval_objects:
            return self
        self._all_evals = all_runs
        return self.eval(eval_objects)

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------

    def __repr__(self):
        run_info = (
            f"repetition {self.repetition_number}/{self.total_runs}"
            if self.total_runs > 1
            else "single eval"
        )
        return (
            f"Eval(dataset='{self.dataset_name}', task='{self.task_name}', "
            f"rows={len(self.rows)}, scorers={len(self._scorers)}, "
            f"{run_info})"
        )

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        return self.rows[idx]
