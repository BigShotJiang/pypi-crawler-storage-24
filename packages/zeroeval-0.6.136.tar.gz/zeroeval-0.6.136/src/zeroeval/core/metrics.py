"""
Aggregate metric decorators built on top of the Evaluation primitive.
"""

from typing import Callable, List, Optional

from .evaluation import Evaluation, EvaluationMode, evaluation, get_evaluation

def column_metric(
    outputs: List[str], name: Optional[str] = None
) -> Callable[[Callable], Evaluation]:
    """Decorator alias for Evaluation(mode='column')."""
    return evaluation(mode="column", outputs=outputs, name=name)


def run_metric(
    outputs: List[str], name: Optional[str] = None
) -> Callable[[Callable], Evaluation]:
    """Decorator alias for Evaluation(mode='run')."""
    return evaluation(mode="run", outputs=outputs, name=name)


def get_column_metric(name: str) -> Optional[Evaluation]:
    """Fetch a registered column metric (Evaluation in column mode)."""
    eval_obj = get_evaluation(name)
    if eval_obj and eval_obj.mode == EvaluationMode.COLUMN:
        return eval_obj
    return None


def get_run_metric(name: str) -> Optional[Evaluation]:
    """Fetch a registered run metric (Evaluation in run mode)."""
    eval_obj = get_evaluation(name)
    if eval_obj and eval_obj.mode == EvaluationMode.RUN:
        return eval_obj
    return None