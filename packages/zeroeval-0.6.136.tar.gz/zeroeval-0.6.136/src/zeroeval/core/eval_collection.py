"""EvalCollection class for elegant multi-eval operations."""
from typing import Any, Callable, List, Optional, Union


class EvalCollection:
    """A collection of evals that provides a fluent interface for batch operations."""

    def __init__(self, runs: List["Eval"]):
        """Initialize with a list of Eval objects."""
        if not runs:
            raise ValueError("EvalCollection requires at least one eval")
        self.runs = runs

    def eval(
        self,
        scorers: List[Union[Callable, Any]],
        column_map: Optional[dict[str, Union[str, dict[str, str]]]] = None,
        **kwargs,
    ) -> "EvalCollection":
        for run in self.runs:
            run.eval(scorers, column_map=column_map, **kwargs)
        return self

    def column_metrics(
        self,
        metrics: List[Union[Callable, Any]],
        column_map: Optional[dict[str, Union[str, dict[str, str]]]] = None,
        **kwargs,
    ) -> "EvalCollection":
        for run in self.runs:
            run.column_metrics(metrics, column_map=column_map, **kwargs)
        return self

    def run_metrics(self, metrics: List[Union[Callable, Any]]) -> "EvalCollection":
        if self.runs:
            self.runs[0].run_metrics(metrics, self.runs)
        return self

    def __len__(self) -> int:
        return len(self.runs)

    def __getitem__(self, index: int) -> "Eval":
        return self.runs[index]

    def __iter__(self):
        return iter(self.runs)

    def __repr__(self) -> str:
        return f"EvalCollection({len(self.runs)} evals)"

    @property
    def first(self) -> "Eval":
        return self.runs[0] if self.runs else None

    @property
    def last(self) -> "Eval":
        return self.runs[-1] if self.runs else None

    def to_list(self) -> List["Eval"]:
        return self.runs

