import pytest
from contextlib import contextmanager

from zeroeval.core.dataset_class import Dataset
from zeroeval.core.evaluation import clear_evaluations, evaluation
from zeroeval.core.execution import (
    CheckpointConfig,
    ExecutionConfig,
    FailurePolicy,
    RetryPolicy,
    ResumeConfig,
)
from zeroeval.core.eval import Eval
from zeroeval.core.task import task


@pytest.mark.core
def test_eval_public_id():
    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="t",
        task_code="",
        rows=[],
        outputs=[],
        experiment_id="eval_123",
    )
    assert run.id == "eval_123"


@pytest.mark.core
def test_eval_column_map_per_scorer_and_score_alias():
    clear_evaluations()

    @evaluation(mode="row", outputs=["match"])
    def exact_match(row, answer_col):
        return {"match": int(row["prediction"] == answer_col)}

    @evaluation(mode="column", outputs=["accuracy"])
    def accuracy(match_col):
        return {"accuracy": sum(match_col) / len(match_col)}

    rows = [
        {"row_id": "1", "prediction": "A", "answer": "A"},
        {"row_id": "2", "prediction": "B", "answer": "C"},
    ]
    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="t",
        task_code="",
        rows=rows,
        outputs=["prediction"],
    )

    # score() should behave exactly like eval(), including column_map.
    run.score(
        [exact_match, accuracy],
        column_map={
            "exact_match": {"answer_col": "answer"},
            "accuracy": {"match_col": "match"},
        },
    )

    assert rows[0]["match"] == 1
    assert rows[1]["match"] == 0
    assert run.metrics["accuracy"] == 0.5


@pytest.mark.core
def test_eval_legacy_kwargs_mapping_still_works():
    clear_evaluations()

    @evaluation(mode="row", outputs=["match"])
    def exact_match(row, answer_col):
        return {"match": int(row["prediction"] == answer_col)}

    rows = [{"row_id": "1", "prediction": "A", "answer": "A"}]
    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="t",
        task_code="",
        rows=rows,
        outputs=["prediction"],
    )
    run.eval([exact_match], answer_col="answer")
    assert rows[0]["match"] == 1


@pytest.mark.core
def test_finalize_health_marks_fully_skipped_as_resumed():
    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="t",
        task_code="",
        rows=[{"_skipped": True}, {"_skipped": True}],
        outputs=[],
    )

    health = run.finalize_health()
    assert health["status"] == "resumed"
    assert health["skipped_count"] == 2
    assert health["error_count"] == 0


@pytest.mark.core
def test_eval_resume_calls_dataset_eval_with_expected_defaults():
    class DatasetSpy:
        def __init__(self):
            self.calls = []

        def eval(self, task_func, **kwargs):
            self.calls.append((task_func, kwargs))
            return "resumed_eval"

    ds = DatasetSpy()

    @task(outputs=["prediction"])
    def solve(row):
        return {"prediction": row["x"]}

    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="solve",
        task_code="",
        rows=[],
        outputs=["prediction"],
        repetition_number=2,
        total_runs=5,
        task_func=solve,
        dataset_ref=ds,
        experiment_id="eval_abc",
        parameters={"k": 1},
        execution_config=ExecutionConfig(workers=3),
        checkpoint_config=CheckpointConfig(flush_every_rows=10),
        resume_config=ResumeConfig(mode="force", skip_completed=True),
        workers=3,
    )

    resumed = run.resume()
    assert resumed == "resumed_eval"
    _, kwargs = ds.calls[0]
    assert kwargs["eval_id"] == "eval_abc"
    assert kwargs["repetition_number"] == 2
    assert kwargs["total_runs"] == 5
    assert kwargs["workers"] == 3
    assert kwargs["parameters"] == {"k": 1}


@pytest.mark.core
def test_repeat_propagates_runtime_configs():
    class DatasetSpy:
        def __init__(self):
            self.calls = []

        def eval(self, task_func, **kwargs):
            self.calls.append(kwargs)
            return Eval(
                dataset_name="d",
                dataset_id="",
                dataset_version_id="",
                task_name="t",
                task_code="",
                rows=[],
                outputs=["prediction"],
                repetition_number=kwargs["repetition_number"],
                total_runs=kwargs["total_runs"],
                task_func=task_func,
                dataset_ref=self,
                experiment_id=kwargs.get("experiment_id"),
                execution_config=kwargs.get("execution"),
                checkpoint_config=kwargs.get("checkpoint"),
                resume_config=kwargs.get("resume"),
                workers=kwargs.get("workers"),
            )

    @task(outputs=["prediction"])
    def solve(row):
        return {"prediction": row["x"]}

    ds = DatasetSpy()
    execution = ExecutionConfig(workers=4)
    checkpoint = CheckpointConfig(flush_every_rows=7)
    resume = ResumeConfig(mode="force", skip_completed=True)

    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="solve",
        task_code="",
        rows=[],
        outputs=["prediction"],
        repetition_number=1,
        total_runs=1,
        task_func=solve,
        dataset_ref=ds,
        experiment_id="eval_main",
        execution_config=execution,
        checkpoint_config=checkpoint,
        resume_config=resume,
        workers=4,
    )

    rc = run.repeat(3)
    assert len(rc.runs) == 3
    assert len(ds.calls) == 2
    for call in ds.calls:
        assert call["experiment_id"] == "eval_main"
        assert call["workers"] == 4
        assert call["execution"] is execution
        assert call["checkpoint"] is checkpoint
        assert call["resume"] is resume


@pytest.mark.core
def test_dataset_eval_supports_eval_id(monkeypatch):
    @task(outputs=["prediction"])
    def solve(row):
        return {"prediction": row["x"]}

    ds = Dataset("local_ds", data=[{"row_id": "1", "x": "ok"}])

    # Keep this test fully local (no backend calls).
    monkeypatch.setattr(
        "zeroeval.core.eval.Eval._ensure_experiment_exists",
        lambda self: None,
    )
    monkeypatch.setattr(
        "zeroeval.core.eval.Eval._submit_result_batch",
        lambda self, rows: None,
    )
    monkeypatch.setattr(
        "zeroeval.core.eval.Eval.load_existing_result_row_ids",
        lambda self, repetition=None: set(),
    )
    @contextmanager
    def _noop_span(name=None):
        class _Span:
            trace_id = None

            def set_error(self, **kwargs):
                return None

        yield _Span()

    monkeypatch.setattr(
        "zeroeval.observability.decorators.span",
        _noop_span,
    )

    run = ds.eval(
        solve,
        eval_id="eval_local_1",
        resume=ResumeConfig(mode="fresh"),
        checkpoint=CheckpointConfig(enabled=False),
        execution=ExecutionConfig(workers=1, max_in_flight=1),
    )
    assert run.id == "eval_local_1"


@pytest.mark.core
def test_execution_config_validation():
    with pytest.raises(ValueError, match="FailurePolicy.on_row_error"):
        FailurePolicy(on_row_error="halt")

    with pytest.raises(ValueError, match="ResumeConfig.mode"):
        ResumeConfig(mode="resume")

    with pytest.raises(ValueError, match="RetryPolicy.retry_on"):
        RetryPolicy(retry_on=("TimeoutError", "", 123))  # type: ignore[arg-type]


@pytest.mark.core
def test_eval_requires_column_map_for_required_row_kwargs():
    clear_evaluations()

    @evaluation(mode="row", outputs=["score"])
    def exact_match(row, answer_col):
        return {"score": int(row["prediction"] == answer_col)}

    rows = [{"row_id": "1", "prediction": "A", "answer": "A"}]
    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="t",
        task_code="",
        rows=rows,
        outputs=["prediction"],
    )

    with pytest.raises(ValueError, match="requires mapped arguments"):
        run.eval([exact_match])

    with pytest.raises(ValueError, match="unknown column"):
        run.eval([exact_match], column_map={"exact_match": {"answer_col": "missing"}})


@pytest.mark.core
def test_explicit_resume_requires_backend_eval_and_stable_row_ids(monkeypatch):
    @task(outputs=["prediction"])
    def solve(row):
        return {"prediction": row.get("x", "ok")}

    # No stable row id present.
    ds = Dataset("local_ds", data=[{"x": "ok"}])

    monkeypatch.setattr(
        "zeroeval.core.eval.Eval._ensure_experiment_exists",
        lambda self: None,
    )
    monkeypatch.setattr(
        "zeroeval.core.eval.Eval._submit_result_batch",
        lambda self, rows: None,
    )
    @contextmanager
    def _noop_span(name=None):
        class _Span:
            trace_id = None

            def set_error(self, **kwargs):
                return None

        yield _Span()

    monkeypatch.setattr(
        "zeroeval.observability.decorators.span",
        _noop_span,
    )

    with pytest.raises(ValueError, match="requires a backend eval id"):
        ds.eval(
            solve,
            resume=ResumeConfig(mode="force", skip_completed=True),
            checkpoint=CheckpointConfig(enabled=False),
            execution=ExecutionConfig(workers=1, max_in_flight=1),
        )

    with pytest.raises(ValueError, match="stable row identities"):
        ds.eval(
            solve,
            eval_id="eval_local",
            resume=ResumeConfig(mode="force", skip_completed=True),
            checkpoint=CheckpointConfig(enabled=False),
            execution=ExecutionConfig(workers=1, max_in_flight=1),
        )

