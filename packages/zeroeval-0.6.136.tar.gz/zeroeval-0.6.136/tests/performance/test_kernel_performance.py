import time

import pytest

from zeroeval.core.execution import CheckpointConfig, ExecutionConfig
from zeroeval.core.kernel import ExecutionEngine, ExecutionRequest


@pytest.mark.performance
def test_execution_engine_row_throughput_smoke():
    rows = [{"row_id": str(i), "x": i} for i in range(500)]
    engine = ExecutionEngine(result_flusher=lambda out: None)
    request = ExecutionRequest(
        task_name="perf_smoke",
        task_func=lambda row: {"prediction": row["x"] * 2},
        rows=rows,
        execution=ExecutionConfig(workers=8, max_in_flight=32, timeout_s=30.0),
        checkpoint=CheckpointConfig(enabled=False),
        completed_row_ids=set(),
    )

    started = time.perf_counter()
    summary = engine.execute(request)
    elapsed = time.perf_counter() - started

    # Regression gate: this workload should remain comfortably sub-second on CI/local dev.
    assert len(summary.rows) == 500
    assert elapsed < 2.0

