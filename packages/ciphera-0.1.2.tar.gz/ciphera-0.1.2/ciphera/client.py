"""
client.py — CipheraClient for Python

Connect to Algorand and query the Ciphera KYC contracts.

Usage:
    from ciphera import CipheraClient

    client = CipheraClient()                     # Testnet (default)
    client = CipheraClient(network="mainnet")    # Mainnet
    client = CipheraClient(algod_url="http://localhost:4001", algod_token="aaaa...")  # LocalNet

    # Check KYC status
    status = client.verify_kyc("WALLET_ADDRESS")
    print(status.is_verified)

    # Check a specific nullifier
    registered = client.is_nullifier_registered("deadbeef...")
"""

from __future__ import annotations

import base64
from typing import Optional, Dict, Any

try:
    import algosdk
    from algosdk.v2client import algod as algod_client
    _ALGOSDK_AVAILABLE = True
except ImportError:
    _ALGOSDK_AVAILABLE = False

from .models import KYCStatus
from .exceptions import NetworkError, ContractError


# ── Default Algorand Testnet endpoints ───────────────────────────────────────
_TESTNET_ALGOD = "https://testnet-api.algonode.cloud"
_MAINNET_ALGOD = "https://mainnet-api.algonode.cloud"
_LOCALNET_ALGOD = "http://localhost:4001"
_LOCALNET_TOKEN = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"


# ── Deployed contract IDs on Algorand Testnet ─────────────────────────────────
DEFAULT_CONTRACT_IDS = {
    "nullifier_registry": 756272073,
    "smt_registry":       756272075,
    "kyc_box_storage":    756272299,
    "credential_manager": 756281076,
    "credential_asa_id":  756281102,
}


class CipheraClient:
    """
    Python client for the Ciphera ZK-KYC system on Algorand.

    Args:
        network:      "testnet" (default) | "mainnet" | "localnet"
        algod_url:    Custom Algod endpoint URL (overrides network preset)
        algod_token:  Custom Algod API token (default: empty for AlgoNode)
        contract_ids: Override deployed contract IDs (dict)

    Example:
        client = CipheraClient()
        status = client.verify_kyc("AAAA...")
        print(status.is_verified)
    """

    def __init__(
        self,
        network: str = "testnet",
        algod_url: Optional[str] = None,
        algod_token: str = "",
        contract_ids: Optional[Dict[str, int]] = None,
    ) -> None:
        if not _ALGOSDK_AVAILABLE:
            raise ImportError(
                "py-algorand-sdk is required: pip install ciphera[algorand]"
            )

        # Resolve endpoint
        if algod_url:
            url, token = algod_url, algod_token
        elif network == "mainnet":
            url, token = _MAINNET_ALGOD, ""
        elif network == "localnet":
            url, token = _LOCALNET_ALGOD, _LOCALNET_TOKEN
        else:  # testnet (default)
            url, token = _TESTNET_ALGOD, ""

        self._algod = algod_client.AlgodClient(token, url)

        # Merge contract IDs
        self._contracts = {**DEFAULT_CONTRACT_IDS, **(contract_ids or {})}

    # ── Public Methods ─────────────────────────────────────────────────────

    def verify_kyc(self, wallet_address: Optional[str] = None) -> KYCStatus:
        """
        Check KYC status via the on-chain NullifierRegistry.

        Reads the `total_registered` global state variable.
        A non-zero value means at least one credential has been registered.

        For wallet-specific KYC, use is_nullifier_registered() with
        the wallet's nullifier hex.

        Args:
            wallet_address: Not currently used (reserved for future wallet-level checks).

        Returns:
            KYCStatus with is_verified, total_registered, app_id

        Example:
            status = client.verify_kyc()
            print(f"Registry has {status.total_registered} verified users")
        """
        app_id = self._contracts["nullifier_registry"]
        try:
            app_info = self._algod.application_info(app_id)
            global_state = app_info.get("params", {}).get("global-state", [])

            total_registered = 0
            for kv in global_state:
                key = base64.b64decode(kv["key"]).decode("utf-8", errors="ignore")
                if key == "total_registered":
                    total_registered = kv["value"].get("uint", 0)

            return KYCStatus(
                is_verified=total_registered > 0,
                app_id=app_id,
                total_registered=total_registered,
            )
        except Exception as e:
            raise NetworkError(f"Failed to query NullifierRegistry (app {app_id}): {e}") from e

    def is_nullifier_registered(self, nullifier_hex: str) -> bool:
        """
        Check if a specific nullifier is registered in box storage.

        More precise than verify_kyc() — directly confirms a specific
        credential nullifier exists on-chain.

        Args:
            nullifier_hex: 32-byte nullifier as hex string (64 chars, no 0x prefix)

        Returns:
            True if the nullifier is registered, False otherwise

        Example:
            registered = client.is_nullifier_registered("deadbeef" * 8)
        """
        app_id = self._contracts["nullifier_registry"]
        try:
            # Box name = b"nul_" + 32-byte nullifier
            prefix = b"nul_"
            nullifier_bytes = bytes.fromhex(nullifier_hex.lstrip("0x").zfill(64))
            box_name = base64.b64encode(prefix + nullifier_bytes).decode()

            result = self._algod.application_box_by_name(app_id, box_name)
            return bool(result.get("value"))
        except algosdk.error.AlgodHTTPError as e:
            if "box not found" in str(e).lower() or e.code == 404:
                return False
            raise NetworkError(f"Box lookup failed: {e}") from e
        except Exception as e:
            return False

    def get_credential_asa_id(self) -> int:
        """Return the KYCRED ASA (Algorand Standard Asset) ID."""
        return self._contracts["credential_asa_id"]

    @staticmethod
    def explorer_tx_url(txid: str) -> str:
        """Return Allo.info explorer URL for a transaction."""
        return f"https://allo.info/tx/{txid}"

    @staticmethod
    def explorer_app_url(app_id: int) -> str:
        """Return Allo.info explorer URL for an application."""
        return f"https://allo.info/application/{app_id}"
