"""
ciphera — Zero-Knowledge KYC SDK for Algorand (Python)

Install:
    pip install ciphera

Usage:
    from ciphera import CipheraClient

    client = CipheraClient()
    status = client.verify_kyc("WALLET_ADDRESS")
    print(status.is_verified)
"""

from .client import CipheraClient
from .models import KYCStatus, ProofResult, PublicSignals
from .verifier import verify_proof
from .exceptions import CipheraError, ProofVerificationError, NetworkError

__version__ = "0.1.2"
__author__ = "Aditya Pandey"
__license__ = "MIT"

__all__ = [
    "CipheraClient",
    "KYCStatus",
    "ProofResult",
    "PublicSignals",
    "verify_proof",
    "CipheraError",
    "ProofVerificationError",
    "NetworkError",
    "__version__",
]
