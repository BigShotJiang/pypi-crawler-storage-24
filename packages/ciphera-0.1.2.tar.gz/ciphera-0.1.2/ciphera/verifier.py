"""
verifier.py — ZK proof verification for the Ciphera Python SDK.

Verifies Groth16 proofs using snarkjs via Node.js subprocess.
The issuer backend calls verify_proof() before registering
a nullifier on-chain.
"""

from __future__ import annotations

import json
import subprocess
import shutil
import tempfile
from pathlib import Path
from typing import Union, List, Dict, Any

from .models import ProofResult, PublicSignals
from .exceptions import ProofVerificationError


def verify_proof(
    verification_key: Union[Dict[str, Any], str, Path],
    proof: Dict[str, Any],
    public_signals: List[str],
    expected_app_id: Optional[Union[int, str]] = None,
) -> ProofResult:
    """
    Verify a Groth16 ZK proof using snarkjs (via Node.js subprocess).

    Args:
        verification_key: The Groth16 verification key (dict, JSON string, or file path).
        proof:            The Groth16 proof object from snarkjs.
        public_signals:   List of public signal strings from the circuit.
        expected_app_id:  Optional NullifierRegistry app ID to guard cross-app attacks.

    Returns:
        ProofResult with .valid, .nullifier_hex, .public_signals, .error

    Example:
        import json
        vk = json.load(open("verification_key.json"))
        result = verify_proof(vk, proof_dict, signal_list, expected_app_id=756272073)
        if result.valid:
            print(result.nullifier_hex)
    """
    # Normalise verification_key to dict
    if isinstance(verification_key, (str, Path)):
        p = Path(verification_key)
        if p.exists():
            with open(p) as f:
                vk_dict = json.load(f)
        else:
            vk_dict = json.loads(str(verification_key))
    else:
        vk_dict = verification_key

    # Validate public signals length
    if len(public_signals) < 6:
        return ProofResult(
            valid=False,
            error=f"Expected >= 6 public signals, got {len(public_signals)}"
        )

    # Quick sanity checks before expensive snarkjs call
    is_indian, is_adult, is_kyc = public_signals[3], public_signals[4], public_signals[5]
    if is_indian != "1":
        return ProofResult(valid=False, error="isIndian must be 1")
    if is_adult != "1":
        return ProofResult(valid=False, error="isAdult must be 1")
    if is_kyc != "1":
        return ProofResult(valid=False, error="isKYCVerified must be 1")

    app_id_signal = public_signals[2]
    if expected_app_id is not None and app_id_signal != str(expected_app_id):
        return ProofResult(
            valid=False,
            error=f"appId mismatch: expected {expected_app_id}, got {app_id_signal}"
        )

    # Run snarkjs verification via Node.js
    if not shutil.which("node"):
        raise ProofVerificationError(
            "Node.js is required for ZK proof verification. "
            "Install from https://nodejs.org"
        )

    js_script = """
const snarkjs = require('snarkjs');
const input = JSON.parse(process.argv[2]);
snarkjs.groth16.verify(input.vk, input.publicSignals, input.proof)
  .then(valid => { process.stdout.write(JSON.stringify({valid})); })
  .catch(e => { process.stdout.write(JSON.stringify({valid: false, error: e.message})); });
"""
    payload = json.dumps({
        "vk": vk_dict,
        "proof": proof,
        "publicSignals": public_signals,
    })

    with tempfile.NamedTemporaryFile(suffix=".js", mode="w", delete=False) as f:
        f.write(js_script)
        script_path = f.name

    try:
        result = subprocess.run(
            ["node", script_path, payload],
            capture_output=True, text=True, timeout=60
        )
        output = json.loads(result.stdout)
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError) as e:
        return ProofResult(valid=False, error=f"Verification failed: {e}")
    finally:
        Path(script_path).unlink(missing_ok=True)

    if not output.get("valid"):
        return ProofResult(valid=False, error=output.get("error", "Proof is invalid"))

    signals = PublicSignals.from_list(public_signals)
    return ProofResult(
        valid=True,
        nullifier_hex=signals.nullifier_hex,
        public_signals=signals,
    )


# Optional type hint (Python 3.9 compat)
from typing import Optional
