"""
models.py — Ciphera SDK Pydantic models
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class PublicSignals:
    """Public signals output from the ZK circuit."""
    nullifier: str          # BN254 field element as decimal string
    merkle_root: str        # SMT root
    app_id: str             # Algorand NullifierRegistry app ID
    is_indian: str          # "1"
    is_adult: str           # "1"
    is_kyc_verified: str    # "1"

    @classmethod
    def from_list(cls, signals: List[str]) -> "PublicSignals":
        """Parse from snarkjs publicSignals array."""
        if len(signals) < 6:
            raise ValueError(f"Expected >= 6 public signals, got {len(signals)}")
        return cls(
            nullifier=signals[0],
            merkle_root=signals[1],
            app_id=signals[2],
            is_indian=signals[3],
            is_adult=signals[4],
            is_kyc_verified=signals[5],
        )

    @property
    def nullifier_hex(self) -> str:
        """Nullifier as 32-byte hex string (suitable for Algorand box keys)."""
        return format(int(self.nullifier), '064x')


@dataclass
class ProofResult:
    """Result of ZK proof verification."""
    valid: bool
    nullifier_hex: Optional[str] = None
    public_signals: Optional[PublicSignals] = None
    error: Optional[str] = None


@dataclass
class KYCStatus:
    """KYC verification status for a wallet address."""
    is_verified: bool
    app_id: int
    total_registered: Optional[int] = None
    nullifier: Optional[str] = None
    error: Optional[str] = None
