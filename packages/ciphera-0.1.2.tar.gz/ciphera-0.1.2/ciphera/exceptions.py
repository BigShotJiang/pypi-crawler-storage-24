"""
exceptions.py — Ciphera SDK custom exceptions
"""


class CipheraError(Exception):
    """Base exception for all Ciphera SDK errors."""
    pass


class ProofVerificationError(CipheraError):
    """Raised when a ZK proof fails verification."""
    pass


class NetworkError(CipheraError):
    """Raised when Algorand network requests fail."""
    pass


class ContractError(CipheraError):
    """Raised when smart contract interactions fail."""
    pass
