from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict

from .ui_controller_migman import MigManUIController, MigManUIRuntime


@dataclass
class UIRenderContext:
    ui_app: Any
    runtime: MigManUIRuntime
    controller: MigManUIController
    content_container: Any | None
    transform_tab_state: Dict[str, Any]
    convenience_hooks: Dict[str, Callable[..., Any]]
    migmanprojects: list[str]
    get_tip: Callable[[str, str], str]
    renderers: Dict[str, Callable[[], None]]
    mark_changed: Callable[[], None]
    mark_saved: Callable[[], None]
    set_active: Callable[[str], None]
    save_config: Callable[[], None]
    reset_config: Callable[[], None]
