from enum import Enum


class MigManExtractAdapter(Enum):
    GENERICODBC = "genericodbc"
    INFORCOM = "inforcom"
    INFORIGF = "inforigf"
    INFORAS = "inforas"
    SAPECC = "sapecc"
    SAPTENANT = "saptenant"
    SAPSYSTEMDB = "sapsystemdb"
    PROALPHA = "proalpha"
    SAGEKHK = "sagekhk"

class MigManLoadAdapter(Enum):
    PROALPHA_MIGMAN = "proalpha_migman"
    NEMO_BUSINESS_PROCESSES = "nemo_business_process"

class MigManTransformStep(Enum):
    JOINS = "10_joins"
    MAPPINGS = "20_mappings"
    DUPLICATES = "30_duplicates"
    NONEMPTY = "40_nonempty"
