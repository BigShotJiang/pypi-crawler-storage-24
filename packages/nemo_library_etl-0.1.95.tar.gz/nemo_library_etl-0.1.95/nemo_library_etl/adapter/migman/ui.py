from .UI.app import MigManUI

__all__ = ["MigManUI"]
