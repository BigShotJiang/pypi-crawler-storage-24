from pathlib import Path

from nemo_library_etl.adapter.migman.load import (
    _parse_report_count,
    _quote_sql_identifier,
    _relative_report_path,
)


def test_quote_sql_identifier_escapes_double_quotes() -> None:
    assert _quote_sql_identifier('My "Column"') == '"My ""Column"""'
    assert _quote_sql_identifier("simple_name") == '"simple_name"'


def test_parse_report_count_handles_empty_numeric_and_invalid_values() -> None:
    assert _parse_report_count(None) == 0
    assert _parse_report_count("") == 0
    assert _parse_report_count("   ") == 0
    assert _parse_report_count("2") == 2
    assert _parse_report_count("2.0") == 2
    assert _parse_report_count("2.9") == 2
    assert _parse_report_count("abc") == 0


def test_relative_report_path_returns_relative_for_absolute_paths_in_cwd(monkeypatch, tmp_path) -> None:
    monkeypatch.chdir(tmp_path)

    report_file = tmp_path / "reports" / "to_customer" / "kunden.html"
    report_file.parent.mkdir(parents=True, exist_ok=True)
    report_file.write_text("ok", encoding="utf-8")

    result = _relative_report_path(report_file)

    assert result == Path("reports/to_customer/kunden.html")
    assert not result.is_absolute()