"""Clavis Python SDK client."""
from typing import Any

import httpx

from clavis.exceptions import ClavisError, AuthenticationError, RateLimitError, TokenError
from clavis.models import ProxyResponse, ServiceToken


class ClavisClient:
    """Clavis SDK client.

    Usage::

        client = ClavisClient(api_key="your-jwt-token", base_url="https://your-agentauth.com")

        # Get a token for a service
        token = await client.get_token("kalshi")
        print(token.access_token)  # ready to use

        # Or proxy the whole request
        response = await client.proxy("kalshi", "GET", "/trade-api/v2/markets")
    """

    def __init__(self, api_key: str, base_url: str = "http://localhost:8000") -> None:
        self._base_url = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {api_key}"}

    async def get_token(self, service_name: str) -> ServiceToken:
        """Get a valid token for a registered service (auto-refreshes if expired).

        Args:
            service_name: The service name you used when registering (e.g., 'kalshi').

        Returns:
            ServiceToken with a ready-to-use access_token.

        Raises:
            TokenError: If no token can be obtained.
        """
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                f"{self._base_url}/v1/tokens/{service_name}",
                headers=self._headers,
                timeout=30,
            )
            self._raise_for_status(resp)
            return ServiceToken(**resp.json())

    async def proxy(
        self,
        service_name: str,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> ProxyResponse:
        """Proxy a request through Clavis (adds auth, handles rate limits).

        Args:
            service_name: The service to call (e.g., 'kalshi').
            method: HTTP method (GET, POST, etc.).
            path: API path on the target service (e.g., '/trade-api/v2/markets').
            params: Optional query parameters.
            body: Optional JSON request body.
            headers: Optional extra headers.

        Returns:
            ProxyResponse with status_code, headers, and body.

        Raises:
            RateLimitError: If the service rate limit is exceeded.
            ClavisError: For other errors.
        """
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"{self._base_url}/v1/proxy/{service_name}",
                headers=self._headers,
                json={"method": method, "path": path, "params": params, "body": body, "headers": headers},
                timeout=60,
            )
            self._raise_for_status(resp)
            data = resp.json()
            return ProxyResponse(
                **data,
                rate_limit_remaining=int(resp.headers.get("X-RateLimit-Remaining", 0)),
            )


    async def check_credentials(self, service_name: str) -> dict:
        """Check credential status without making external API calls.

        Queries only the Clavis database and Redis — never contacts the upstream
        service. Safe to call frequently as a health check.

        Args:
            service_name: Name of the service to check (e.g., 'kalshi').

        Returns:
            dict with keys: service, valid, expires_in, rate_limit_remaining,
            last_used, status. May also include 'error' if valid is False.

        Raises:
            ClavisError: If the request fails (e.g., network error).
            AuthenticationError: If the API key is invalid (401).
        """
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                f"{self._base_url}/v1/credentials/{service_name}/check",
                headers=self._headers,
                timeout=30,
            )
            self._raise_for_status(resp)
            return resp.json()


    async def call(
        self,
        service_name: str,
        method: str,
        url: str,
        params: dict | None = None,
        json: dict | None = None,
        data: dict | str | None = None,
        headers: dict | None = None,
    ) -> dict:
        """Call an external API with server-side credential injection.

        Credentials are fetched from the Clavis vault and injected server-side.
        The agent never sees raw credential values, eliminating prompt-injection
        exfiltration as an attack vector.

        The url must target the connector's configured base domain — cross-domain
        calls are rejected (SSRF prevention).

        Args:
            service_name: The service whose credentials to inject (e.g., 'kalshi').
            method: HTTP method (GET, POST, PUT, DELETE, PATCH).
            url: Full URL to call. Must be on the connector's allowed domain.
            params: Optional query parameters.
            json: Optional JSON body (mutually exclusive with data).
            data: Optional form-encoded body (mutually exclusive with json).
            headers: Optional extra headers (auth headers added server-side).

        Returns:
            dict with keys: status_code (int), headers (dict), body (dict | str).

        Raises:
            ClavisError: If the URL is rejected (SSRF), service not found, etc.
            AuthenticationError: If the API key is invalid (401).
            RateLimitError: If the service rate limit is exceeded.
        """
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"{self._base_url}/v1/call/{service_name}",
                headers=self._headers,
                json={"method": method, "url": url, "params": params, "json": json, "data": data, "headers": headers},
                timeout=60,
            )
            self._raise_for_status(resp)
            return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        """Convert HTTP errors to Clavis exceptions with helpful messages."""
        if resp.status_code == 401:
            raise AuthenticationError("Invalid API key. Get a new token at POST /v1/auth/login.", status_code=401)
        if resp.status_code == 429:
            retry_after = int(resp.headers.get("Retry-After", 1))
            raise RateLimitError(
                resp.json().get("detail", "Rate limit exceeded."),
                retry_after=retry_after,
            )
        if resp.status_code == 503:
            raise TokenError(resp.json().get("detail", "Token unavailable."), status_code=503)
        if resp.status_code >= 400:
            detail = resp.json().get("detail", resp.text) if resp.content else resp.text
            raise ClavisError(detail, status_code=resp.status_code)
