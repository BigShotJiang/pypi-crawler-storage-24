"""Pydantic models for SDK responses."""
from datetime import datetime

from pydantic import BaseModel


class ServiceToken(BaseModel):
    """A valid access token for a third-party service."""

    service_name: str
    token_type: str
    access_token: str
    expires_at: datetime | None = None
    rate_limit_remaining: int | None = None


class ProxyResponse(BaseModel):
    """Response from a proxied request."""

    status_code: int
    headers: dict
    body: str | dict | list | None
    rate_limit_remaining: int | None = None
