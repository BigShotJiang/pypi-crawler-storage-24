"""Clavis SDK exceptions."""


class ClavisError(Exception):
    """Base exception for all Clavis errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class TokenError(ClavisError):
    """Raised when a token cannot be obtained or refreshed."""


class RateLimitError(ClavisError):
    """Raised when the service rate limit is exceeded."""

    def __init__(self, message: str, retry_after: int = 0) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class AuthenticationError(ClavisError):
    """Raised when developer authentication fails."""
