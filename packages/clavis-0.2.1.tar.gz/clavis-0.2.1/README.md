# Clavis

**Self-Hosted Credential Infrastructure for Autonomous Agents**

Your AI agents need API keys, OAuth tokens, and wallet keys.  
Hardcoding them = one prompt injection away from disaster.

Clavis stores credentials server-side and injects them at runtime.  
**Your agents never see the secrets.**

## Installation

```bash
pip install clavis
```

## Quick Start

```python
from clavis import ClavisClient

client = ClavisClient(
    api_key="your-jwt-token",       # from POST /v1/auth/login
    base_url="https://your-clavis-instance.com"
)

# Secure call — credential injected server-side, never touches agent memory
response = await client.call(
    "stripe",
    "GET",
    "https://api.stripe.com/v1/balance"
)
print(response["body"])  # {"object": "balance", ...}

# Check credential health without making external calls
status = await client.check_credentials("stripe")
# {"valid": True, "status": "healthy", "expires_in": 3542}

# Proxy a request (path-based, credential injected server-side)
response = await client.proxy(
    "openai",
    "POST",
    "/v1/chat/completions",
    body={"model": "gpt-4o", "messages": messages}
)
```

## Why Clavis

| | Hardcoded secrets | Clavis |
|---|---|---|
| Agent sees raw key | Yes | **No** |
| Prompt injection risk | High | **Eliminated** |
| Token auto-refresh | Manual | **Automatic** |
| Audit log | None | **Every request** |
| Rate limiting | Manual | **Built-in** |
| Self-hostable | — | **Yes** |

## Security Model

`clavis.call()` is the core primitive. When your agent calls it:

1. Clavis fetches the credential from its encrypted vault
2. Injects it into the upstream HTTP request server-side
3. Returns only the API response — **no credential ever leaves the server**

Even a fully compromised agent cannot exfiltrate credentials it never received.

## Features

- **`call()`** — Server-side credential injection; agent never sees raw secrets
- **`proxy()`** — Path-based proxying with automatic auth
- **`check_credentials()`** — Dry-run health check; no external calls made
- **`get_token()`** — Retrieve a valid token for custom auth flows
- Encrypted credentials at rest (Fernet)
- Automatic OAuth token refresh
- Redis-backed rate limiting (cross-agent)
- Full audit log on every auth event
- MCP server for Claude Desktop integration

## Self-Hosting

Clavis is fully self-hostable. See [clavisagent.com/docs/mcp.html](https://clavisagent.com/docs/mcp.html) for setup.

## License

MIT
