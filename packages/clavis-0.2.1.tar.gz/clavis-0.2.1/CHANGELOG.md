## v0.2.1 — 2026-03-27

### Bug Fix
- Fixed import statements: removed stale  references, now correctly imports from 
- No functional changes from v0.2.0

---

# Changelog

## v0.2.0 — 2026-03-27

### Security
- Added `clavis.call()` for server-side credential injection — agents never receive raw credentials
- SSRF protection validates target domain against connector's allowed base URL
- Credentials fetched from encrypted vault and injected at request time; never returned to caller

### Features
- `ClavisClient.call(service, method, url, *, params, json, data, headers)` — full-URL call with auth injection
- `ClavisClient.check_credentials(service)` — dry-run health check (valid, expires_in, rate_limit_remaining, last_used)

### Infrastructure
- 165 passing tests (up from 41 in v0.1.1)
- Monthly usage tracking added to UsageTracker
- Billing test coverage fixed

### Migration

No breaking changes. `get_token()` and `proxy()` continue to work unchanged.

```python
# v0.1.x — credential touches agent memory (still works, but vulnerable)
creds = await client.get_token("stripe")
# v0.2.0 — credential never leaves Clavis server
response = await client.call("stripe", "GET", "https://api.stripe.com/v1/balance")
```

---

## v0.1.1 — 2026-03-20

- Initial PyPI release
- `get_token()`, `proxy()` methods
- Encrypted credential storage, automatic token refresh, rate limiting
