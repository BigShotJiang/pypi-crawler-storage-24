# SPDX-License-Identifier: Apache-2.0
"""
Lightr vLLM Core - Device-agnostic encryption and license components.

This package provides core functionality that can be shared across
different hardware platforms (GPU, NPU, etc.).

Usage:
    # Encrypt a model
    vllm-encrypt-model --input ./model --output ./encrypted_model

    # Generate license
    vllm-gen-license --model-dir ./encrypted_model --vendor-key key.pem

    # Get fingerprint
    vllm-get-fingerprint
"""

from lightr_vllm_core.crypto import (
    ModelEncryptor,
    ModelDecryptor,
    generate_dek,
    is_encrypted_file,
    MAGIC_BYTES,
    HEADER_SIZE,
    CHUNK_SIZE,
)
from lightr_vllm_core.license import (
    LicenseInfo,
    LicenseManager,
    LicenseValidator,
    OfflineLicenseManager,
)
from lightr_vllm_core.base import (
    FingerprintPolicy,
    BaseFingerprint,
    BaseEncryptedLoader,
    ENC_SUFFIX,
    SAFETENSORS_ENC,
    GGUF_ENC,
)

__all__ = [
    # Crypto
    "ModelEncryptor",
    "ModelDecryptor",
    "generate_dek",
    "is_encrypted_file",
    "MAGIC_BYTES",
    "HEADER_SIZE",
    "CHUNK_SIZE",
    # License
    "LicenseInfo",
    "LicenseManager",
    "LicenseValidator",
    "OfflineLicenseManager",
    # Base
    "FingerprintPolicy",
    "BaseFingerprint",
    "BaseEncryptedLoader",
    # Constants
    "ENC_SUFFIX",
    "SAFETENSORS_ENC",
    "GGUF_ENC",
]

__version__ = "0.1.0"