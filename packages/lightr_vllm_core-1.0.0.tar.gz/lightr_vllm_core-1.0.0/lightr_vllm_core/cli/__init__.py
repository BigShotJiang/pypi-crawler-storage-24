# SPDX-License-Identifier: Apache-2.0
"""CLI tools for lightr-vllm-core."""

from lightr_vllm_core.cli.encrypt_model import main as encrypt_main
from lightr_vllm_core.cli.gen_license import main as license_main
from lightr_vllm_core.cli.get_fingerprint import main as fingerprint_main

__all__ = ["encrypt_main", "license_main", "fingerprint_main"]