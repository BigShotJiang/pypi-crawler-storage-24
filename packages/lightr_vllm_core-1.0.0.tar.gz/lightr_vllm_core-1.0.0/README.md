# vllm-security-core



## Platform Support

This is a platform-agnostic package. For platform-specific implementations:

| Platform | Package |
|----------|---------|
| GPU/CUDA | `vllm-model-security` |
| Ascend NPU | `light-vllm-ascend-security` |

