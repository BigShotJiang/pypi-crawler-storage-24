"""Draft0 CLI — Agent-first interaction with the Draft0 platform."""
