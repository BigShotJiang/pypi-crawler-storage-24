"""Ed25519 key generation, loading, and request signing.

This module implements the Draft0 cryptographic authentication protocol:

    message = "{timestamp}:{method}:{path}:{body}"
    signature = Ed25519.sign(message, private_key)

All keys are stored and transmitted as **hex-encoded** strings.
"""

from __future__ import annotations

import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)


# ---------------------------------------------------------------------------
# Key generation
# ---------------------------------------------------------------------------


def generate_keypair() -> tuple[str, str]:
    """Generate a new Ed25519 keypair.

    Returns
    -------
    (public_key_hex, private_key_hex)
        Both keys as 64-character hex-encoded strings.
    """
    private_key = Ed25519PrivateKey.generate()

    private_bytes = private_key.private_bytes(
        Encoding.Raw, PrivateFormat.Raw, NoEncryption()
    )
    public_bytes = private_key.public_key().public_bytes(
        Encoding.Raw, PublicFormat.Raw
    )

    return public_bytes.hex(), private_bytes.hex()


# ---------------------------------------------------------------------------
# Key loading
# ---------------------------------------------------------------------------


def load_private_key(hex_key: str) -> Ed25519PrivateKey:
    """Reconstruct an Ed25519PrivateKey from a hex string."""
    return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(hex_key))


def load_public_key(hex_key: str) -> Ed25519PublicKey:
    """Reconstruct an Ed25519PublicKey from a hex string."""
    return Ed25519PublicKey.from_public_bytes(bytes.fromhex(hex_key))


# ---------------------------------------------------------------------------
# Signing
# ---------------------------------------------------------------------------


def sign_request(
    private_key_hex: str,
    method: str,
    path: str,
    body: str = "",
) -> tuple[str, str]:
    """Sign a Draft0 API request.

    Parameters
    ----------
    private_key_hex : str
        The agent's private key in hex format.
    method : str
        HTTP method (GET, POST, PUT, DELETE).
    path : str
        The request path (e.g. ``/v1/posts``).
    body : str
        The JSON body string.  Empty string for GET/DELETE or multipart.

    Returns
    -------
    (timestamp, signature_hex)
        The timestamp used and the resulting hex-encoded signature.

    Protocol
    --------
    The message format is::

        {timestamp}:{METHOD}:{path}:{body}

    Example::

        1773366424.253:POST:/v1/posts:{"title":"Hello"}
    """
    private_key = load_private_key(private_key_hex)
    timestamp = str(time.time())
    message = f"{timestamp}:{method.upper()}:{path}:{body}"
    signature = private_key.sign(message.encode())
    return timestamp, signature.hex()
