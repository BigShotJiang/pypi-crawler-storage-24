"""Feed, trending, tags, and personal digest commands.

Commands
--------
d0 feed [--sort recent|top] [--tag TAG]   Global feed
d0 feed trending [--limit N]              Trending posts (last 24h)
d0 feed tags                              List all tags with counts
d0 feed digest [--period 24h|7d|30d]      Personalized digest
"""

from __future__ import annotations

from typing import Optional

import typer

from d0.client import api, handle_response

app = typer.Typer(help="Discover content: feed, trending, tags, and personal digest.")


@app.callback(invoke_without_command=True)
def feed(
    ctx: typer.Context,
    sort: str = typer.Option(
        "recent",
        "--sort",
        help="Sort order: 'recent' or 'top' (reputation-weighted).",
    ),
    tag: Optional[str] = typer.Option(None, "--tag", help="Filter by a specific tag."),
    limit: int = typer.Option(20, "--limit", "-n", min=1, max=100, help="Max posts to return."),
    offset: int = typer.Option(0, "--offset", min=0, help="Number of posts to skip."),
) -> None:
    """Browse the global content feed.

    By default shows the most recent posts. Use ``--sort top`` for
    reputation-weighted ranking.

    Example::

        d0 feed
        d0 feed --sort top --tag architecture
    """
    if ctx.invoked_subcommand is not None:
        return

    if sort not in ("recent", "top"):
        raise SystemExit("Sort must be 'recent' or 'top'.")

    params: dict = {"sort": sort, "limit": limit, "offset": offset}
    if tag:
        params["tag"] = tag

    response = api.get("/v1/feed", params=params)
    handle_response(response)


@app.command()
def trending(
    limit: int = typer.Option(20, "--limit", "-n", min=1, max=50, help="Max posts to return."),
) -> None:
    """Show trending posts — most vote activity in the last 24 hours.

    Example::

        d0 feed trending
        d0 feed trending --limit 5
    """
    response = api.get("/v1/feed/trending", params={"limit": limit})
    handle_response(response)


@app.command()
def tags() -> None:
    """List all tags used across posts, sorted by count.

    Example::

        d0 feed tags
    """
    response = api.get("/v1/tags")
    handle_response(response)


@app.command()
def digest(
    period: str = typer.Option(
        "7d",
        "--period", "-p",
        help="Time window: '24h', '7d', or '30d'.",
    ),
) -> None:
    """Get your personalized content digest.

    Auto-infers your domains of interest from your published post tags,
    then returns top posts and rising authors grouped by each tag.

    Requires authentication (you must have published at least one post).

    Example::

        d0 feed digest
        d0 feed digest --period 24h
    """
    if period not in ("24h", "7d", "30d"):
        raise SystemExit("Period must be '24h', '7d', or '30d'.")

    response = api.get("/v1/digest/personal", params={"period": period}, auth=True)
    handle_response(response)
