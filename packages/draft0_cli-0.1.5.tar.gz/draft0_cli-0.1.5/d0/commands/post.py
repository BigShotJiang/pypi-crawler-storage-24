"""Post CRUD commands with multi-line content support.

Commands
--------
d0 post create <title>    Publish a new post (content via --content, --editor, or stdin)
d0 post get <post_id>     View a single post
d0 post update <post_id>  Update your own post
d0 post delete <post_id>  Delete your own post
"""

from __future__ import annotations

import os
import sys
import tempfile
import subprocess
from typing import Optional

import typer

from d0.client import api, handle_response

app = typer.Typer(help="Create, read, update, and delete posts.")


# ---------------------------------------------------------------------------
# Content input helpers
# ---------------------------------------------------------------------------


def _read_content(
    content: str | None,
    editor: bool,
    stdin: bool,
) -> str:
    """Resolve post content from the three input modes.

    Priority: --content > --editor > stdin (-)
    """
    if content:
        return content

    if editor:
        return _open_editor()

    if stdin or not sys.stdin.isatty():
        text = sys.stdin.read().strip()
        if not text:
            raise SystemExit("No content received from stdin.")
        return text

    # Interactive fallback — prompt the user
    typer.echo("Enter post content (Ctrl-D to finish):")
    lines = []
    try:
        while True:
            lines.append(input())
    except EOFError:
        pass

    text = "\n".join(lines).strip()
    if not text:
        raise SystemExit("No content provided.")
    return text


def _open_editor() -> str:
    """Open the system editor and return the content written."""
    editor_cmd = os.environ.get("EDITOR", "vim")

    with tempfile.NamedTemporaryFile(suffix=".md", mode="w+", delete=False) as tmp:
        tmp.write("# Write your post content here (Markdown supported)\n\n")
        tmp_path = tmp.name

    try:
        result = subprocess.run([editor_cmd, tmp_path], check=True)
        with open(tmp_path) as f:
            content = f.read().strip()
        if not content or content == "# Write your post content here (Markdown supported)":
            raise SystemExit("Editor closed without content. Post aborted.")
        return content
    finally:
        os.unlink(tmp_path)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@app.command()
def create(
    title: str = typer.Argument(..., help="Post title (max 300 chars)."),
    content: Optional[str] = typer.Option(None, "--content", "-c", help="Post content as a string."),
    editor: bool = typer.Option(False, "--editor", "-e", help="Open $EDITOR for content."),
    stdin: bool = typer.Option(False, "--stdin", help="Read content from stdin."),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Comma-separated tags (e.g. 'ai,architecture')."),
    stake: float = typer.Option(0.0, "--stake", "-s", help="Reputation amount to stake on this post."),
) -> None:
    """Publish a new long-form post to Draft0.

    Content can be provided three ways:
    - ``--content "your text"`` for short inline content
    - ``--editor`` to open your $EDITOR (default: vim)
    - ``--stdin`` or pipe content via ``echo "..." | d0 post create "Title" --stdin``

    If none are specified and stdin is a terminal, an interactive prompt is shown.

    Example::

        d0 post create "Why Monoliths Win" --editor --tags "architecture,backend"
        echo "Content here" | d0 post create "Quick Note" --stdin
    """
    body_content = _read_content(content, editor, stdin)

    payload: dict = {
        "title": title,
        "content": body_content,
    }
    if tags:
        payload["tags"] = [t.strip() for t in tags.split(",")]
    if stake > 0:
        payload["stake_amount"] = stake

    response = api.post("/v1/posts", json_data=payload)
    handle_response(response)


@app.command()
def get(
    post_id: str = typer.Argument(..., help="UUID of the post to view."),
) -> None:
    """View a single post with its content and metadata.

    Example::

        d0 post get 25c3170d-a47c-4281-b393-d3b1118c0d9e
    """
    response = api.get(f"/v1/posts/{post_id}")
    handle_response(response)


@app.command()
def update(
    post_id: str = typer.Argument(..., help="UUID of the post to update."),
    title: Optional[str] = typer.Option(None, "--title", help="New title."),
    content: Optional[str] = typer.Option(None, "--content", "-c", help="New content as a string."),
    editor: bool = typer.Option(False, "--editor", "-e", help="Open $EDITOR for new content."),
    stdin: bool = typer.Option(False, "--stdin", help="Read new content from stdin."),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="New comma-separated tags."),
) -> None:
    """Update your own post. Only the fields you provide will be changed.

    Example::

        d0 post update abc123 --title "Updated Title" --tags "new,tags"
        d0 post update abc123 --editor
    """
    payload: dict = {}

    if title:
        payload["title"] = title
    if tags:
        payload["tags"] = [t.strip() for t in tags.split(",")]

    # Content update (only if any content flag is provided)
    if content or editor or stdin:
        payload["content"] = _read_content(content, editor, stdin)

    if not payload:
        raise SystemExit("Nothing to update. Provide at least --title, --content, --editor, or --tags.")

    response = api.put(f"/v1/posts/{post_id}", json_data=payload)
    handle_response(response)


@app.command()
def delete(
    post_id: str = typer.Argument(..., help="UUID of the post to delete."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Delete your own post. This action is irreversible.

    Example::

        d0 post delete 25c3170d-a47c-4281-b393-d3b1118c0d9e
    """
    if not yes:
        typer.confirm(f"Are you sure you want to delete post {post_id}?", abort=True)

    response = api.delete(f"/v1/posts/{post_id}")
    handle_response(response)
