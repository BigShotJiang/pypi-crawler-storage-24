"""Signed HTTP client for the Draft0 API.

Wraps ``httpx`` and automatically injects the three required auth headers
(``X-Public-Key``, ``X-Timestamp``, ``X-Signature``) for every
authenticated request.

Usage::

    from d0.client import api

    # Authenticated POST
    response = api.post("/v1/posts", json={"title": "Hi"})

    # Public GET (no signing needed)
    response = api.get("/v1/feed")
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import httpx

from d0.config import get_base_url, load_identity
from d0.security import sign_request


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def print_json(data: Any) -> None:
    """Pretty-print a JSON-serializable object to stdout."""
    print(json.dumps(data, indent=2, default=str))


def print_error(message: str) -> None:
    """Print an error message to stderr."""
    print(f"✗ Error: {message}", file=sys.stderr)


def handle_response(response: httpx.Response) -> dict | list | None:
    """Process an httpx response: print result or error, return parsed data.

    Returns the parsed JSON on success, or None on failure.
    """
    if response.status_code in (200, 201):
        data = response.json()
        print_json(data)
        return data
    elif response.status_code == 204:
        print("✓ Done.")
        return None
    else:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        print_error(f"[{response.status_code}] {detail}")
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Signed client
# ---------------------------------------------------------------------------


class Draft0Client:
    """HTTP client that auto-signs requests using the local identity."""

    def __init__(self) -> None:
        self._base_url: str | None = None
        self._identity: dict | None = None

    # -- lazy loading so import doesn't fail when no identity exists --

    @property
    def base_url(self) -> str:
        if self._base_url is None:
            self._base_url = get_base_url()
        return self._base_url

    def _load_identity(self) -> dict:
        if self._identity is None:
            self._identity = load_identity()
        return self._identity

    def _auth_headers(self, method: str, path: str, body: str = "") -> dict[str, str]:
        """Build the three auth headers for a signed request."""
        identity = self._load_identity()
        public_key = identity["public_key"]
        private_key = identity["private_key"]

        timestamp, signature = sign_request(private_key, method, path, body)
        return {
            "X-Public-Key": public_key,
            "X-Timestamp": timestamp,
            "X-Signature": signature,
        }

    # -- Public convenience methods --

    def get(self, path: str, *, params: dict | None = None, auth: bool = False) -> httpx.Response:
        """Send a GET request.  Set ``auth=True`` for signed endpoints."""
        headers = {}
        if auth:
            headers = self._auth_headers("GET", path)
        return httpx.get(f"{self.base_url}{path}", headers=headers, params=params)

    def post(self, path: str, *, json_data: dict | None = None, auth: bool = True) -> httpx.Response:
        """Send a signed POST request with JSON body."""
        body_str = json.dumps(json_data) if json_data else ""
        headers = self._auth_headers("POST", path, body_str)
        headers["Content-Type"] = "application/json"
        return httpx.post(f"{self.base_url}{path}", headers=headers, content=body_str)

    def put(self, path: str, *, json_data: dict | None = None, auth: bool = True) -> httpx.Response:
        """Send a signed PUT request with JSON body."""
        body_str = json.dumps(json_data) if json_data else ""
        headers = self._auth_headers("PUT", path, body_str)
        headers["Content-Type"] = "application/json"
        return httpx.put(f"{self.base_url}{path}", headers=headers, content=body_str)

    def delete(self, path: str, *, auth: bool = True) -> httpx.Response:
        """Send a signed DELETE request."""
        headers = self._auth_headers("DELETE", path)
        return httpx.delete(f"{self.base_url}{path}", headers=headers)

    def upload(self, path: str, *, file_path: Path) -> httpx.Response:
        """Send a signed multipart file upload.

        Per the Draft0 protocol, the body portion of the signature is
        left empty for multipart requests.
        """
        headers = self._auth_headers("POST", path, "")
        with open(file_path, "rb") as f:
            files = {"file": (file_path.name, f)}
            return httpx.post(f"{self.base_url}{path}", headers=headers, files=files)


# Singleton instance — import and use directly
api = Draft0Client()
