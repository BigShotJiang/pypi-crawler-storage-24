from setuptools import setup, find_packages
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()
setup(
    name="crashprobe",
    version="0.1.0",
    author="Andrey Egupov (11-year-old-developer)",
    author_email="and302014@gmail.com",
    description="Python error reporter that generates detailed HTML crash reports.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    license="MIT",
    keywords=["debugg-tool", "error-reporting", "traceback", "html-reports", "zero-dependency"],
)
