# 🛡️Crashprobe - makes errors simple, understandable, and beautiful, and generates HTML reports about them. 

![Python](https://img.shields.io/badge/python-3.6%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)

Example:

![Crashprobe report example](https://i.ibb.co/9m1f8sLN/screen.png)

A library that intercepts errors and creates beautiful, detailed HTML reports.
## 📦Installation
```bash
pip install crashprobe
```
## 🚀Quick Start
```python
import crashprobe
crashprobe.start()
print(1/0) # ZeroDivisionError - watch the magic!
```
## ✨Crashprobe Features
- No dependencies
- Beautiful, easy-to-read dark theme in reports
- System information
- Very easy to use
- Copy report button
- Useful links with error information

## 📃Usage
Library import:
```python
import crashprobe
```
Start the error catcher. If the program crashes with an error, the library will intercept it, generate an HTML report, automatically open it, and save it in the crash_file folder:
```python
crashprobe.start()
```
The generated page is saved in the automatically created crash_file folder as a file named crash_Y-M-D_H-M-S.
The page includes a beautiful dark theme, emoji, as well as the error title, error text, exact date and time, path to the file containing the error, the line containing the error and its closest links, values ​​and types of local variables, system information and Python version, links to Google and the Python documentation for information about the error, and a copy report button.

Usage example:
```python
import crashprobe
crashprobe.start()
def example(x, y):
    one = x
    two = y
    return x / y
print(example(1, "Hello"))
```
## ❔Why is it convenient?
To get started, you only need to write two lines of code, and in the event of an error, you get a beautiful HTML report instead of a console message. 

Without crashprobe:

![Before crashprobe](https://i.ibb.co/cKQ0QPYZ/screen-before.png)

With crashprobe:

![With crashprobe](https://i.ibb.co/9m1f8sLN/screen.png)

## 👦🏻 About the developer
My name is Andrey Egupov, I'm 11 years old. I've been programming for several years. I started in Scratch, now I write in Python, JavaScript, and I'm working with Arduino.
I got tired of seeing red error messages and having to print variable values, so I decided to create a truly useful tool that would help me and others!

## 📄 License
MIT © 2026 Andrey Egupov (11-year-old-developer)