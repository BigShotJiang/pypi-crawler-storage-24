"""
Distance Metrics

Distance measures for signal comparison: Euclidean, cosine, Manhattan, DTW.
"""

import numpy as np
from typing import Optional

import pmtvs_distance._rust as _rust


def euclidean_distance(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute Euclidean (L2) distance between two signals.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Euclidean distance (L2 norm of difference)
    """
    return _rust.euclidean_distance(x, y)


def cosine_distance(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute cosine distance between two signals.

    Cosine distance = 1 - cosine similarity

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Cosine distance in [0, 2]
    """
    return _rust.cosine_distance(x, y)


def manhattan_distance(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute Manhattan (L1) distance between two signals.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Manhattan distance (L1 norm of difference)
    """
    return _rust.manhattan_distance(x, y)


def earth_movers_distance(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute Earth Mover's Distance (Wasserstein distance) between distributions.

    Parameters
    ----------
    x : np.ndarray
        First distribution (as samples)
    y : np.ndarray
        Second distribution (as samples)

    Returns
    -------
    float
        EMD (>= 0)
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    x = x[~np.isnan(x)]
    y = y[~np.isnan(y)]
    if len(x) == 0 or len(y) == 0:
        return np.nan
    return float(_rust.earth_movers_distance(x, y))


def cosine_similarity(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute cosine similarity between two vectors.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Cosine similarity in [-1, 1]
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    if len(x) != len(y):
        return np.nan
    mask = ~(np.isnan(x) | np.isnan(y))
    x = x[mask]
    y = y[mask]
    if len(x) == 0:
        return np.nan
    return float(_rust.cosine_similarity(x, y))


def dtw_distance(
    x: np.ndarray,
    y: np.ndarray,
    window: Optional[int] = None
) -> float:
    """
    Compute Dynamic Time Warping distance between two signals.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    window : int, optional
        Sakoe-Chiba band width for constraint (default: no constraint)

    Returns
    -------
    float
        DTW distance
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    x = x[~np.isnan(x)]
    y = y[~np.isnan(y)]
    if len(x) == 0 or len(y) == 0:
        return np.nan
    w = window if window is not None else -1
    return float(_rust.dtw_distance(x, y, w))
