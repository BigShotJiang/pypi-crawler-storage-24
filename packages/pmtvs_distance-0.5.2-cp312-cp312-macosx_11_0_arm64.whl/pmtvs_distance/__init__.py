"""
pmtvs-distance — Distance metrics for signal comparison.

numpy in, number out.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_distance._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-distance && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

# --- Public API ---
from pmtvs_distance.distance import (
    euclidean_distance,
    cosine_distance,
    manhattan_distance,
    dtw_distance,
    earth_movers_distance,
    cosine_similarity,
)

__all__ = [
    "__version__",
    "BACKEND",
    "euclidean_distance",
    "cosine_distance",
    "manhattan_distance",
    "dtw_distance",
    "earth_movers_distance",
    "cosine_similarity",
]
