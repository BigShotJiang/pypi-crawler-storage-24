import time
from c4rlib import (
    Logger, ColorUtils, Gradient, GradientPresets,
    Box, Banner, TextStyle, Utils,
    Spinner, ProgressBar, Table, Console
)

Console.clear()

# ─── TITULO ────────────────────────────────────────────────────────────────────
print(Banner.title("  c4rlib DEMO  ", color="#9b5de5"))
print()

# ─── COLORES ───────────────────────────────────────────────────────────────────
print(Banner.arrow_line("COLORS & GRADIENTS", color="#00ccff"))
print()

print(ColorUtils.paint("  Texto en rojo hex",    "#FF4444"))
print(ColorUtils.paint("  Texto en verde hex",   "#29bf12"))
print(ColorUtils.paint("  Texto en cyan hex",    "#00ccff"))
print(ColorUtils.paint("  Texto en purpura hex", "#9b5de5"))
print(ColorUtils.paint("  Texto en gold hex",    "#ffd60a"))
print()

print("  " + Gradient.preset("Gradiente cyan → gold",    GradientPresets.cyan_to_gold))
print("  " + Gradient.preset("Gradiente purple → pink",  GradientPresets.purple_to_pink))
print("  " + Gradient.preset("Gradiente red → blue",     GradientPresets.red_to_blue))
print("  " + Gradient.random_gradient("Gradiente random cada vez!"))
print("  " + ColorUtils.rainbow("Texto arcoiris caracter por caracter"))
print()

multi = Gradient.multicolor("Multi-stop gradient: rojo → amarillo → verde → azul!", [
    (255, 0, 0), (255, 255, 0), (0, 255, 0), (0, 100, 255)
])
print("  " + multi)
print()

input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── LOGGER ────────────────────────────────────────────────────────────────────
print(Banner.arrow_line("LOGGER", color="#00ccff"))
print()

Logger.success("Login",    "usuario conectado",      "200 OK")
Logger.error  ("Request",  "timeout de conexion",    "408")
Logger.warning ("RateLimit","demasiadas peticiones",  "429")
Logger.info   ("Server",   "escuchando en puerto",   "8080")
Logger.debug  ("Memory",   "uso actual de RAM",      "312 MB")
Logger.critical("Crash",   "error fatal en modulo",  "SIGKILL")
Logger.network ("HTTP",    "GET /api/users",         "200 OK")
Logger.captcha ("Solver",  "resolviendo captcha",    "hcaptcha")
Logger.input  ("User",     "nuevo input recibido",   "stdin")
Logger.output ("Result",   "respuesta generada",     "stdout")
print()
Logger.gradient_log("Este mensaje tiene gradiente automatico aplicado")
print()
Logger.banner_log("ESTO ES UN BANNER LOG — DESTACADO", hex_color="#ffd60a")
print()
Logger.custom("#FF69B4", "♥", "LVL", "mensaje custom", "cualquier texto", "extra info")
print()

input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── BOXES & BANNERS ───────────────────────────────────────────────────────────
print(Banner.arrow_line("BOXES & BANNERS", color="#00ccff"))
print()

print(Box.rounded  ("Box Rounded",   color="#00ccff"))
print(Box.double   ("Box Double",    color="#9b5de5"))
print(Box.heavy    ("Box Heavy",     color="#29bf12"))
print(Box.simple   ("Box Simple",    color="#ffd60a"))
print(Box.dots     ("Box Dots",      color="#ff7b00"))
print(Box.gradient_box("Box Gradient", start=(0,200,255), end=(200,0,255)))
print()

print(Box.multiline(
    ["Linea uno del box", "Linea dos del box", "Linea tres del box"],
    style="rounded", color="#00ccff"
))
print()

print(Banner.line       ("Banner Line",        color="#00ccff"))
print(Banner.arrow_line ("Banner Arrow",       color="#9b5de5"))
print(Banner.heart_line ("Banner Heart",       color="#FF69B4"))
print(Banner.wave_line  ("Banner Wave",        color="#29bf12"))
print(Banner.gradient_banner("Banner Gradient", start=(0,200,255), end=(200,0,255)))
print()

input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── TEXT STYLES ───────────────────────────────────────────────────────────────
print(Banner.arrow_line("TEXT STYLES", color="#00ccff"))
print()

base = "c4rlib text styles"
print(f"  Original:     {base}")
print(f"  Fancy:        {TextStyle.fancy(base)}")
print(f"  Double Struck:{TextStyle.double_struck(base)}")
print(f"  Cursive:      {TextStyle.cursive(base)}")
print(f"  Fraktur:      {TextStyle.fraktur(base)}")
print(f"  Syllabic:     {TextStyle.syllabic(base)}")
print(f"  Small Caps:   {TextStyle.small_caps(base)}")
print(f"  Wide:         {TextStyle.wide('c4rlib')}")
print(f"  Leet:         {TextStyle.leet(base)}")
print(f"  Alternate:    {TextStyle.alternate_case(base)}")
print(f"  Reverse:      {TextStyle.reverse(base)}")
print(f"  Strikethrough:{TextStyle.strikethrough(base)}")
print(f"  Zalgo:        {TextStyle.zalgo('zalgo text', intensity=2)}")
print()

input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── UTILS ─────────────────────────────────────────────────────────────────────
print(Banner.arrow_line("UTILITIES", color="#00ccff"))
print()

print(ColorUtils.paint("  ── Identity ──", "#6c757d"))
print(f"  UUID v4:       {Utils.generate_uuid()}")
print(f"  UUID hex:      {Utils.generate_uuid_hex()}")
print(f"  Token 32:      {Utils.generate_token(32)}")
print(f"  Hex token:     {Utils.generate_hex_token(16)}")
print(f"  PIN 6 digits:  {Utils.generate_pin(6)}")
print(f"  Password:      {Utils.generate_password(20, symbols=True)}")
print()

print(ColorUtils.paint("  ── Hashes ──", "#6c757d"))
print(f"  MD5:           {Utils.hash_md5('c4rlib')}")
print(f"  SHA256:        {Utils.hash_sha256('c4rlib')}")
print()

print(ColorUtils.paint("  ── Fake Data ──", "#6c757d"))
print(f"  Name:          {Utils.random_name()}")
print(f"  Email:         {Utils.random_email()}")
print(f"  Username:      {Utils.random_username()}")
print(f"  Birthdate:     {Utils.random_birthdate()}")
print()

print(ColorUtils.paint("  ── Network ──", "#6c757d"))
print(f"  IPv4:          {Utils.generate_ipv4()}")
print(f"  IPv6:          {Utils.generate_ipv6()}")
print(f"  MAC:           {Utils.generate_mac()}")
print()

print(ColorUtils.paint("  ── Time ──", "#6c757d"))
print(f"  Time:          {Utils.log_time()}")
print(f"  Date:          {Utils.log_date()}")
print(f"  Datetime:      {Utils.log_datetime()}")
print(f"  Timestamp ms:  {Utils.timestamp()}")
print()

print(ColorUtils.paint("  ── System ──", "#6c757d"))
info = Utils.os_info()
for k, v in info.items():
    print(f"  {k:<10}     {v}")
print()

input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── SPINNER ───────────────────────────────────────────────────────────────────
print(Banner.arrow_line("SPINNERS", color="#00ccff"))
print()

estilos = ["dots", "line", "arrows", "bounce", "circle", "square", "star", "grow"]
for estilo in estilos:
    sp = Spinner(f"Spinner style: {estilo}", style=estilo, color="#00ccff")
    sp.start()
    time.sleep(1.2)
    sp.stop(f"Listo con estilo: {estilo}")

print()
input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── PROGRESS BAR ──────────────────────────────────────────────────────────────
print(Banner.arrow_line("PROGRESS BARS", color="#00ccff"))
print()

estilos_bar = ["block", "shade", "smooth", "classic", "dot"]
for estilo in estilos_bar:
    bar = ProgressBar(total=40, label=f"  [{estilo}]", style=estilo, color="#00ccff")
    for _ in range(40):
        time.sleep(0.02)
        bar.update(1)
    bar.finish(f"Completado estilo {estilo}")
    time.sleep(0.3)

print()
input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── TABLE ─────────────────────────────────────────────────────────────────────
print(Banner.arrow_line("TABLES", color="#00ccff"))
print()

t1 = Table(
    headers=["Nombre", "Score", "Nivel", "Status"],
    title="🏆 LEADERBOARD",
    header_color="#ffd60a",
    border_color="#6c757d"
)
t1.add_rows([
    ["c4r",     "9999", "MAX",  "✔ Winner"],
    ["Alice",   "8420", "S",    "✔ Pass"],
    ["Bob",     "7310", "A",    "✔ Pass"],
    ["Charlie", "4120", "B",    "✔ Pass"],
    ["Dave",    "1050", "D",    "✘ Fail"],
])
t1.print()
print()

t2 = Table(
    headers=["Modulo", "Descripcion", "Status"],
    title="c4rlib MODULES",
    header_color="#9b5de5",
    border_color="#00ccff"
)
t2.add_rows([
    ["colors",  "RGB, HEX, HSL, gradientes",          "✔ OK"],
    ["logger",  "10 niveles de log con colores",       "✔ OK"],
    ["banners", "Boxes y banners decorativos",         "✔ OK"],
    ["text",    "Fancy, zalgo, leet, small caps...",   "✔ OK"],
    ["utils",   "UUID, hashes, fake data, network",    "✔ OK"],
    ["console", "Spinner, ProgressBar, Table",         "✔ OK"],
])
t2.print()
print()

input(ColorUtils.paint("  [ Presiona ENTER para continuar ]", "#6c757d"))
Console.clear()

# ─── CONSOLE EXTRAS ────────────────────────────────────────────────────────────
print(Banner.arrow_line("CONSOLE EXTRAS", color="#00ccff"))
print()

w, h = Console.size()
print(f"  Terminal size: {ColorUtils.paint(str(w), '#00ccff')} x {ColorUtils.paint(str(h), '#00ccff')} caracteres")
print()

Console.rule(char="─", color="#6c757d")
Console.rule(char="═", color="#9b5de5")
Console.rule(char="━", color="#00ccff")
print()

print(ColorUtils.paint("  Typewriter effect:", "#ffd60a"))
Console.typewriter("  Esto se escribe letra por letra como una maquina de escribir...", delay=0.03, color="#00ccff")
print()

print(ColorUtils.paint("  Countdown:", "#ffd60a"))
Console.countdown(3, text="  Demo terminando en", color="#FF4444")
print()

# ─── FIN ───────────────────────────────────────────────────────────────────────
Console.rule(char="═", color="#9b5de5")
print()
print(Banner.title("  GRACIAS POR USAR c4rlib  ", color="#9b5de5"))
print()
print("  " + Gradient.preset("pip install c4rlib", GradientPresets.cyan_to_gold))
print()
Console.rule(char="═", color="#9b5de5")