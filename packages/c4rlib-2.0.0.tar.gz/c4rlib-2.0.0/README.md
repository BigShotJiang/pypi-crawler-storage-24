# c4rlib

> A powerful Python utility library for terminal tools — way more than Raducord.

```
pip install c4rlib
```

---

## ✨ Features

| Module       | What it does                                              |
|--------------|-----------------------------------------------------------|
| `ColorUtils` | RGB, HEX, HSL colors, background colors, rainbow, random |
| `Gradient`   | Smooth gradients, multi-stop gradients, presets           |
| `Logger`     | 10+ log levels with colored output and timestamps        |
| `Box`        | 7 box styles + gradient + multiline boxes                |
| `Banner`     | Divider lines, title blocks, heart/wave/arrow banners    |
| `TextStyle`  | Fancy, fraktur, cursive, zalgo, leet, small caps & more  |
| `Utils`      | UUID, tokens, hashes, fake names/emails, IP, MAC, time   |
| `Spinner`    | 10 animated spinner styles (context manager support)     |
| `ProgressBar`| Animated bar with ETA, speed, customizable style         |
| `Table`      | Full bordered tables with colors, titles, alignment      |
| `Console`    | Typewriter, countdown, cursor control, terminal size     |

---

## 🚀 Quick Start

```python
from c4rlib import Logger, Gradient, GradientPresets, Box, Spinner, ProgressBar, Table
import time

# Logging
Logger.success("Login", "token_abc123", "200 OK")
Logger.error("Request", "timeout", "408")
Logger.warning("RateLimit", "429 Too Many Requests", "retry in 5s")
Logger.gradient_log("Custom gradient message")

# Colors & Gradients
from c4rlib import ColorUtils, Gradient, GradientPresets

text = Gradient.preset("Hello, c4rlib!", GradientPresets.cyan_to_gold)
print(text)

text2 = Gradient.multicolor("Rainbow text!", [
    (255, 0, 0), (255, 165, 0), (255, 255, 0), (0, 255, 0), (0, 0, 255)
])
print(text2)

# Boxes & Banners
from c4rlib import Box, Banner

print(Box.rounded("c4rlib", color="#00ccff"))
print(Box.gradient_box("Gradient Box"))
print(Box.multiline(["Line one", "Line two", "Line three"], style="double"))
print(Banner.title("MY TOOL", color="#9b5de5"))
print(Banner.arrow_line("Section Name", color="#ffd60a"))

# Text styles
from c4rlib import TextStyle

print(TextStyle.fancy("Hello World"))
print(TextStyle.zalgo("corrupted text", intensity=2))
print(TextStyle.leet("leet speak"))
print(TextStyle.small_caps("small caps"))
print(TextStyle.wide("wide text"))

# Spinner (context manager)
with Spinner("Fetching data...", style="dots", color="#00ccff"):
    time.sleep(2)

# Progress bar
bar = ProgressBar(total=50, label="Downloading", style="block")
for _ in range(50):
    time.sleep(0.05)
    bar.update(1)
bar.finish("Download complete")

# Table
table = Table(headers=["Name", "Score", "Status"], title="Leaderboard")
table.add_rows([
    ["Alice",   "98",  "✔ Pass"],
    ["Bob",     "74",  "✔ Pass"],
    ["Charlie", "41",  "✘ Fail"],
])
table.print()

# Utils
from c4rlib import Utils

print(Utils.generate_uuid())
print(Utils.generate_password(20, symbols=True))
print(Utils.hash_sha256("secret"))
print(Utils.random_name())
print(Utils.random_email())
print(Utils.generate_ipv4())
```

---

## 📦 Installation

```bash
pip install c4rlib
```

No extra dependencies required — pure Python standard library only.

---

## 📝 License

MIT © c4r
