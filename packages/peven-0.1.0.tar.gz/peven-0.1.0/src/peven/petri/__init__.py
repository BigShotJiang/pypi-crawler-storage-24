"""Petri net engine core."""
