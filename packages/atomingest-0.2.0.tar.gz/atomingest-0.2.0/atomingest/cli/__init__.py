"""CLI module for AtomIngest."""

from atomingest.cli.main import main

__all__ = ["main"]
