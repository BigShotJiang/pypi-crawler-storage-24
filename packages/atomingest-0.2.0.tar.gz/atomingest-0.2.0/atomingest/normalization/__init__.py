"""
Normalization module for AtomIngest.

Provides normalization pipeline components and integration hooks.
"""

from atomingest.normalization.integration import (
    normalize_then_validate,
    normalize_csv_file,
    normalize_csv_string,
)
from atomingest.normalization.core import (
    NormalizationConfig,
    NormalizationStepConfig,
    NormalizationReport,
)
from atomingest.normalization.pipeline import NormalizationPipeline

__all__ = [
    # Integration hooks
    "normalize_then_validate",
    "normalize_csv_file",
    "normalize_csv_string",
    # Core classes
    "NormalizationConfig",
    "NormalizationStepConfig",
    "NormalizationReport",
    "NormalizationPipeline",
]
