from abc import ABC, abstractmethod
from typing import Iterator, Dict, Any, Union, List, TextIO, Iterable
from pathlib import Path

from atomingest.normalization.steps import BaseNormalizerStep


class DataSource(ABC):
    """
    Abstract Strategy for Data Sources
    """

    @abstractmethod
    def read(
        self,
        source: Union[str, Path, TextIO, Iterable[str]],
        line_steps: List[BaseNormalizerStep] = None,
        report=None,
    ) -> Iterator[Dict[str, Any]]:
        """
        Read from the source and yields normalised rows (dicts)
        Args:
            source: The input source(path or file-like object or iterable of strings)
            line_steps: A list of normalizer steps that apply to raw text lines
            (only relevant for text-based sources like CSV)
            report: Optional NormalizationReport for tracking metrics
        """
        pass
