import logging
from typing import Iterator, Dict, Any, Union, List, TextIO, Iterable
from pathlib import Path

try:
    import pandas as pd
except ImportError:
    pd = None

from atomingest.normalization.steps import BaseNormalizerStep
from atomingest.normalization.sources.base import DataSource

logger = logging.getLogger(__name__)


class ParquetDataSource(DataSource):
    """
    Concrete Strategy for Parquet files (PARQUET)
    """

    def __init__(self, **kwargs):
        self.read_parquet_kwargs = kwargs

    def read(
        self,
        source: Union[str, Path, TextIO, Iterable[str]],
        line_steps: List[BaseNormalizerStep] = None,
        report=None,
    ) -> Iterator[Dict[str, Any]]:
        if pd is None:
            raise ImportError("pandas is required to read ParquetDataSource.")

        if line_steps:
            logger.info("Line steps are ignored for Parquet data sources.")

        df = pd.read_parquet(source, **self.read_parquet_kwargs)
        df = df.where(pd.notnull(df), None)

        # Count header row
        if report:
            report.increment_total_lines()

        for row in df.to_dict(orient="records"):
            if report:
                report.increment_total_lines()
            yield row
