"""
Pipeline module for AtomIngest.

Provides hooks, runners, and dead letter queue functionality.
"""

from atomingest.pipeline.hooks import (
    Hook,
    HookConfig,
    HookContext,
    HookExecutionError,
    HookRegistry,
    HookType,
    FunctionHook,
    OnCompleteHook,
    OnErrorHook,
    PostSaveHook,
    PreSaveHook,
    TransformHook,
    DeadLetterQueueHook,
    DLQFailureModel,
    create_registry_from_config,
    parse_hooks_config,
)
from atomingest.pipeline.dlq import (
    DLQStatus,
    DLQRecord,
    DLQStore,
    DLQRetryRunner,
    DLQExporter,
    DLQManager,
)

__all__ = [
    # Hook base classes
    "Hook",
    "HookContext",
    "HookConfig",
    "HookType",
    "HookExecutionError",
    "HookRegistry",
    # Hook implementations
    "FunctionHook",
    "OnCompleteHook",
    "OnErrorHook",
    "PostSaveHook",
    "PreSaveHook",
    "TransformHook",
    "DeadLetterQueueHook",
    "DLQFailureModel",
    # Utility functions
    "create_registry_from_config",
    "parse_hooks_config",
    # Dead Letter Queue
    "DLQStatus",
    "DLQRecord",
    "DLQStore",
    "DLQRetryRunner",
    "DLQExporter",
    "DLQManager",
]
