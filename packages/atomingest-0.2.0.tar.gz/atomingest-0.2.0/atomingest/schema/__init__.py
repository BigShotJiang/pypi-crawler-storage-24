"""
Schema module for AtomIngest.

Provides validators and decorators for YAML-defined field validation.
"""

from atomingest.schema.validators import (
    ChoiceValidator,
    CustomValidator,
    FieldValidationConfig,
    LengthValidator,
    NotEmptyValidator,
    RangeValidator,
    RegexValidator,
    ValidationError,
    Validator,
    VALIDATOR_REGISTRY,
    create_validator_from_dict,
    parse_field_validators,
)

from atomingest.schema.decorators import (
    ValidatedFieldDescriptor,
    apply_validation_to_schema,
    create_validated_model,
    field_validator,
    inject_validators,
    validate_row,
    validate_row_strict,
)

__all__ = [
    # Validators
    "ChoiceValidator",
    "CustomValidator",
    "FieldValidationConfig",
    "LengthValidator",
    "NotEmptyValidator",
    "RangeValidator",
    "RegexValidator",
    "ValidationError",
    "Validator",
    "VALIDATOR_REGISTRY",
    "create_validator_from_dict",
    "parse_field_validators",
    # Decorators
    "ValidatedFieldDescriptor",
    "apply_validation_to_schema",
    "create_validated_model",
    "field_validator",
    "inject_validators",
    "validate_row",
    "validate_row_strict",
]
