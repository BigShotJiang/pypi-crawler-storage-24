"""AtomIngest - A Metadata-Driven Data Ingestion Framework

AtomIngest is a configurable, zero-boilerplate data ingestion framework designed for
fintech environments where data reliability, compliance, and scalability are paramount.

Built on the metaprogramming foundations of AtomSQL, it dynamically generates ORM models,
validators, and transformation logic entirely from YAML configurations.
"""

__version__ = "0.2.0"
__author__ = "Prashant Singh"
__email__ = "box_prashant@outlook.com"

# Core functionality exports
from atomingest.core.ingester import Ingester
from atomingest.core.loader import SchemaLoader

# Normalization pipeline exports
from atomingest.normalization import (
    normalize_then_validate,
    normalize_csv_file,
    normalize_csv_string,
    NormalizationConfig,
    NormalizationStepConfig,
    NormalizationReport,
    NormalizationPipeline,
)

# Schema and validation exports
from atomingest.schema.drift_detector import SchemaDriftDetector
from atomingest.schema.validators import Validator

# Pipeline components
from atomingest.core.dependency_resolver import DependencyResolver

# Security features
from atomingest.security.kms import KeyManager

# Observability
from atomingest.pipeline.audit_metadata import MetadataInjectionHook
from atomingest.pipeline.hooks import HookRegistry, HookType, HookContext
from atomingest.observability.metrics import MetricsCollector

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__email__",
    # Core functionality
    "Ingester",
    "SchemaLoader",
    # Normalization pipeline
    "normalize_then_validate",
    "normalize_csv_file",
    "normalize_csv_string",
    "NormalizationConfig",
    "NormalizationStepConfig",
    "NormalizationReport",
    "NormalizationPipeline",
    # Schema and validation
    "SchemaDriftDetector",
    "Validator",
    # Pipeline components
    "DependencyResolver",
    # Security
    "KeyManager",
    # Observability
    "MetadataInjectionHook",
    "HookRegistry",
    "HookType",
    "HookContext",
    "MetricsCollector",
]
