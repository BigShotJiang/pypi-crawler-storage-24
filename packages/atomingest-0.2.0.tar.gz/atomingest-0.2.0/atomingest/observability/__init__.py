"""
Observability module for atomingest.

Provides:
- Prometheus metrics for monitoring
- Structured JSON logging
"""

from .metrics import (
    MetricsCollector,
    track_normalization,
    track_hook_execution,
    record_dlq_entry,
    set_pipeline_info,
    get_metrics,
    is_prometheus_available,
)

from .json_logging import (
    JSONFormatter,
    StructuredLogger,
    configure_structured_logging,
    get_logger,
)

__all__ = [
    "MetricsCollector",
    "track_normalization",
    "track_hook_execution",
    "record_dlq_entry",
    "set_pipeline_info",
    "get_metrics",
    "is_prometheus_available",
    "JSONFormatter",
    "StructuredLogger",
    "configure_structured_logging",
    "get_logger",
]
