# Pre-commit Hooks

This repository uses pre-commit hooks to ensure code quality and consistency.

## Setup

Install the hooks:
```bash
uv sync --dev
uv run pre-commit install
```

## Hooks Configured

### Code Quality & Style
- **trailing-whitespace**: Removes trailing whitespace
- **end-of-file-fixer**: Ensures files end with a newline
- **mixed-line-ending**: Fixes mixed line endings (converts to LF)
- **ruff**: Python linter with auto-fix
- **ruff-format**: Python code formatter

### Security & Type Checking
- **mypy**: Static type checker for Python
- **bandit**: Security linter for Python code

### File Validation
- **check-yaml**: Validates YAML files
- **check-json**: Validates JSON files
- **check-toml**: Validates TOML files
- **check-merge-conflict**: Prevents committing merge conflict markers
- **debug-statements**: Checks for debugger imports and breakpoints
- **check-added-large-files**: Prevents large files (>1MB) from being committed

### Testing
- **pytest-check**: Runs all tests before commit

## Usage

The hooks run automatically on `git commit`. To run manually:

```bash
# Run on all files
uv run pre-commit run --all-files

# Run on staged files only
uv run pre-commit run

# Run specific hook
uv run pre-commit run ruff --all-files

# Skip hooks (not recommended)
git commit --no-verify
```

## Updating Hooks

```bash
uv run pre-commit autoupdate
```
