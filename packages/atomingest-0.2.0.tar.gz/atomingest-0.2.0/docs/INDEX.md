# AtomIngest Documentation Index

Welcome to the AtomIngest documentation! This index will help you find the information you need.

---

## 📚 Getting Started

- **[Installation Guide](installation.md)** - How to install AtomIngest
- **[Quick Start](quickstart.md)** - Get up and running in 5 minutes
- **[Getting Started](getting_started.md)** - Comprehensive introduction

---

## 📖 Core Documentation

### User Guides
- **[Comprehensive User Guide](comprehensive_user_guide.md)** - Complete guide to using AtomIngest
- **[Fintech User Guide](fintech_user_guide.md)** - Fintech-specific patterns and compliance

### Concepts
- **[Architecture](ARCHITECTURE.md)** - Visual architecture diagrams (Mermaid)
- **[Core Concepts](concepts.md)** - Understanding AtomIngest architecture
- **[Schema Definition](schema_definition.md)** - Defining table schemas in YAML
- **[Field Types](field_types.md)** - Available field types and their usage
- **[Validation](validation.md)** - Data validation and constraints

### Configuration
- **[Pipeline Configuration](pipeline_configuration.md)** - Configuring ingestion pipelines
- **[Normalization](normalization.md)** - Data normalization and cleaning
- **[Normalization Pipeline](normalization_pipeline_readme.md)** - Normalization pipeline details

### Advanced Features
- **[Hooks](hooks.md)** - Pipeline hooks and callbacks
- **[Security](security.md)** - Encryption, PII protection, and compliance
- **[Patterns](patterns.md)** - Common patterns and best practices
- **[Performance](performance.md)** - Performance tuning and optimization

### Error Handling
- **[Error Handling](error_handling.md)** - Error handling strategies
- **[FAQ](faq.md)** - Frequently asked questions

---

## 🔧 Reference

- **[API Reference](api_reference.md)** - Complete API documentation
- **[CLI Reference](cli_reference.md)** - Command-line interface guide

---

## 🚀 Release & Development

### Release Documentation
- **[PyPI Release Guide](PYPI_RELEASE_GUIDE.md)** - How to release to PyPI
- **[Release Process](RELEASE.md)** - GitFlow release process
- **[Release Summary](RELEASE_SUMMARY.md)** - Latest release information
- **[Branch Sync Summary](BRANCH_SYNC_SUMMARY.md)** - Branch synchronization guide

### Development
- **[Pre-commit Hooks](pre-commit.md)** - Pre-commit configuration and usage

---

## 📝 Documentation Structure

```
docs/
├── INDEX.md                          # This file
├── README.md                         # Documentation overview
│
├── Getting Started/
│   ├── installation.md
│   ├── quickstart.md
│   └── getting_started.md
│
├── User Guides/
│   ├── comprehensive_user_guide.md
│   └── fintech_user_guide.md
│
├── Core Concepts/
│   ├── concepts.md
│   ├── schema_definition.md
│   ├── field_types.md
│   └── validation.md
│
├── Configuration/
│   ├── pipeline_configuration.md
│   ├── normalization.md
│   └── normalization_pipeline_readme.md
│
├── Advanced/
│   ├── hooks.md
│   ├── security.md
│   ├── patterns.md
│   └── performance.md
│
├── Reference/
│   ├── api_reference.md
│   └── cli_reference.md
│
├── Help/
│   ├── error_handling.md
│   └── faq.md
│
└── Release/
    ├── PYPI_RELEASE_GUIDE.md
    ├── RELEASE.md
    ├── RELEASE_SUMMARY.md
    ├── BRANCH_SYNC_SUMMARY.md
    └── pre-commit.md
```

---

## 🔍 Quick Links

### Common Tasks
- [Install AtomIngest](installation.md#installation)
- [Run your first pipeline](quickstart.md#quick-start)
- [Define a schema](schema_definition.md#defining-schemas)
- [Add validation rules](validation.md#validation-rules)
- [Configure normalization](normalization.md#configuration)
- [Use hooks](hooks.md#hook-types)
- [Encrypt sensitive data](security.md#pii-encryption)

### Troubleshooting
- [Common errors](error_handling.md#common-errors)
- [FAQ](faq.md)
- [Performance issues](performance.md#troubleshooting)

### Development
- [Release to PyPI](PYPI_RELEASE_GUIDE.md)
- [Set up pre-commit hooks](pre-commit.md)

---

## 📦 External Resources

- **GitHub Repository**: https://github.com/prashant-fintech/atomingest
- **PyPI Package**: https://pypi.org/project/atomingest/
- **Issue Tracker**: https://github.com/prashant-fintech/atomingest/issues

---

## 💡 Need Help?

- Check the [FAQ](faq.md) for common questions
- Review [Error Handling](error_handling.md) for troubleshooting
- Open an issue on [GitHub](https://github.com/prashant-fintech/atomingest/issues)
- Email: box_prashant@outlook.com

---

**Last Updated**: February 10, 2026
