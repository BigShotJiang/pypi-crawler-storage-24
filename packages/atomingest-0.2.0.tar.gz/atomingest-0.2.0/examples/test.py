import os
import sqlite3

db_file = "C:\\projects\\atomsql-workspace\\atomingest\\nse_data.db"
abs_path = os.path.abspath(db_file)

print(f"Checking Database File: {abs_path}")

if not os.path.exists(db_file):
    print("❌ Error: File does not exist at this path!")
else:
    print(f"✅ File found. Size: {os.path.getsize(db_file)} bytes")

    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute("SELECT count(*) FROM nse_bhavcopy")
        count = cursor.fetchone()[0]
        print(f"📊 Total Rows in Table: {count}")
        conn.close()
    except Exception as e:
        print(f"❌ Could not read database: {e}")
