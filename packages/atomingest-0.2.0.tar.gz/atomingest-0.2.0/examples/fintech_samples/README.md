# Fintech Sample Projects

This directory contains complete, runnable examples of fintech data ingestion pipelines using AtomIngest.

## Available Samples

### 1. Payment Processing System
- **Directory**: `payment_processing/`
- **Use Case**: Real-time credit card transaction processing
- **Features**: Fraud detection, PCI compliance, real-time validation
- **Data Volume**: High-frequency (10,000+ TPS)

### 2. Market Data Ingestion
- **Directory**: `market_data/`
- **Use Case**: Stock price and trading data ingestion
- **Features**: Market hours validation, price anomaly detection, technical indicators
- **Data Volume**: Ultra-high frequency (100,000+ messages/second)

### 3. Customer KYC & Onboarding
- **Directory**: `customer_kyc/`
- **Use Case**: Customer data ingestion with regulatory compliance
- **Features**: PII encryption, identity verification, AML screening
- **Data Volume**: Medium (1,000s of customers/day)

### 4. Risk & Regulatory Reporting
- **Directory**: `risk_reporting/`
- **Use Case**: Daily risk calculations and regulatory report generation
- **Features**: VaR calculations, stress testing, automated submissions
- **Data Volume**: Batch processing (EOD)

### 5. Trade Settlement System
- **Directory**: `trade_settlement/`
- **Use Case**: Post-trade processing and settlement
- **Features**: T+2 settlement, corporate actions, dividend processing
- **Data Volume**: Medium-high (10,000s of trades/day)

### 6. Loan Origination System
- **Directory**: `loan_origination/`
- **Use Case**: Loan application data processing
- **Features**: Credit scoring, document validation, compliance checks
- **Data Volume**: Low-medium (100s of applications/day)

## Quick Start

Each sample includes:
- `README.md` - Detailed setup and usage instructions
- `pipeline.yaml` - Main pipeline configuration
- `schema.yaml` - Data schema definition
- `sample_data/` - Test data files
- `tests/` - Unit and integration tests
- `requirements.txt` - Python dependencies

### Running a Sample

```bash
# Navigate to sample directory
cd fintech_samples/payment_processing

# Install dependencies
pip install -r requirements.txt

# Run the pipeline with sample data
atomingest run pipeline.yaml --input sample_data/transactions.csv

# Run tests
pytest tests/
```

## Sample Data

All samples include realistic but anonymized test data that demonstrates:
- Various data formats (CSV, JSON, XML, Parquet)
- Edge cases and error conditions
- Performance testing datasets
- Compliance testing scenarios

## Architecture Overview

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Data Sources  │────│   AtomIngest     │────│   Target DB     │
│                 │    │   Pipeline       │    │                 │
│ • Market Feeds  │    │ • Validation     │    │ • PostgreSQL    │
│ • Trading Sys   │    │ • Normalization  │    │ • SQLite        │
│ • Customer Apps │    │ • Security       │    │ • TimescaleDB*  │
│ • Risk Systems  │    │ • Compliance     │    │ • ClickHouse*   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │                     * Planned for
                                ▼                       future versions
                       ┌──────────────────┐
                       │  Audit & Monitor │
                       │ • Logs           │
                       │ • Metrics        │
                       │ • Alerts         │
                       └──────────────────┘
```

## Best Practices Demonstrated

- **Security**: PII encryption, field-level access control
- **Compliance**: SOX, GDPR, PCI-DSS, Basel III patterns
- **Performance**: Batch processing, streaming, parallel execution
- **Reliability**: Error handling, retry logic, dead letter queues
- **Testing**: Unit tests, integration tests, compliance validation
- **Monitoring**: Metrics collection, alerting, audit trails

## Contributing

To add a new sample:

1. Create directory under `fintech_samples/`
2. Include all required files (see template)
3. Add comprehensive README
4. Include realistic test data
5. Add entry to this index

## Support

For questions about these samples:
- Check individual sample READMEs
- Review [Fintech User Guide](../docs/fintech_user_guide.md)
- Open an issue on GitHub
