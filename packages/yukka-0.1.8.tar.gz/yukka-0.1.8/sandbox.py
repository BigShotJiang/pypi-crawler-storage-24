"""Sandbox for testing the yukka package during development.

Usage:
    1. Copy .env.example to .env and set YUKKA_TOKEN
    2. Run: python sandbox.py

    Or use interactively:
    python -i sandbox.py
"""

from dotenv import load_dotenv

from yukka import Asset, Session

# Load environment variables from .env file
load_dotenv()

# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    # Initialize session (auto-loads token from YUKKA_TOKEN environment variable)
    with Session() as session:
        # You can also pass the token explicitly:
        # with Session(token="eyJ...") as session:

        # =========================================================================
        # 2. CREATE ASSETS
        # =========================================================================

        # Option A: From YUKKA ID (if you already know it)
        # Format is "type:alpha_id", e.g., "company:bmw"
        bmw = Asset.from_yukka_id("company:bmw")
        print(f"Asset from YUKKA ID: {bmw}")

        # You can create multiple assets at once
        assets = Asset.from_yukka_id(["company:bmw", "company:apple", "company:tesla"])
        print(f"Multiple assets: {assets}")

        # Option B: From ISIN (resolves via Metadata API)
        # This calls the YUKKA Metadata API to find the corresponding yukka_id
        philips = Asset.from_isin("NL0000009538", session.resolver)
        print(f"Asset from ISIN: {philips}")

        # You can resolve multiple ISINs at once
        assets_from_isins = Asset.from_isin(
            ["DE0005190003", "NL0000009538", "GB00BD6K4575"],  # BMW, Philips, Compass Group
            session.resolver,
        )
        print(f"Assets from ISINs: {assets_from_isins}")

        # =========================================================================
        # 3. FETCH SENTIMENT
        # =========================================================================

        # Fetch sentiment for a single asset
        df = session.sentiment(bmw, date_from="2026-01-01", date_to="2026-01-31")
        print("\nSentiment for BMW:")
        print(df)

        # Fetch sentiment for multiple assets
        df = session.sentiment(assets_from_isins, date_from="2026-01-01", date_to="2026-01-31")
        print("\nSentiment for multiple companies:")
        print(df)

        # date_to defaults to today if not specified
        df = session.sentiment(philips, date_from="2026-01-01")
        print(f"\nSentiment for Philips (until {session.today}):")
        print(df)
