"""Response models (dataclasses or Pydantic) for YUKKA APIs.

This module will contain structured models for API responses.
Currently, responses are parsed directly in the backend layer.
"""
