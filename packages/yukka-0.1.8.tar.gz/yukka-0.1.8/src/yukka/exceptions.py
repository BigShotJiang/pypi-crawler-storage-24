"""YUKKA API exceptions."""


class ExpiredToken(ValueError):
    """Raised when JWT token has expired and cannot be renewed."""

    pass


class TokenTooOld(ValueError):
    """Raised when JWT token was issued more than 8 months ago."""

    pass
