"""YUKKA Package - Getting Started Examples.

This file demonstrates 3 ways to create Assets from the STOXX 600 universe and fetch sentiment:
1. Using YUKKA ID
2. Using ISIN
3. Using RIC code
"""

import polars as pl
from dotenv import load_dotenv

from yukka import Asset, Session
from yukka.data import stoxx600

load_dotenv()


def example_1_yukka_id():
    """Example 1: Look up asset by YUKKA ID from STOXX 600 and fetch sentiment."""
    print("\n" + "=" * 60)
    print("EXAMPLE 1: Using YUKKA ID")
    print("=" * 60)

    # Load STOXX 600 universe
    df = stoxx600()

    # Find BMW by yukka_id
    row = df.filter(pl.col("yukka_id") == "bmw").row(0, named=True)
    print(f"Found: {row['constituent_name']} (yukka_id: {row['yukka_id']})")

    # Create asset and fetch sentiment
    with Session() as session:
        bmw = Asset.from_yukka_id(f"company:{row['yukka_id']}")
        df = session.sentiment(bmw, date_from="2026-01-01", date_to="2026-01-31")
        print(f"\nSentiment data:\n{df}")


def example_2_isin():
    """Example 2: Look up asset by ISIN from STOXX 600 and fetch sentiment."""
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Using ISIN")
    print("=" * 60)

    # Load STOXX 600 universe
    df = stoxx600()

    # Find Siemens by ISIN
    isin = "DE0007236101"  # Siemens
    row = df.filter(pl.col("isin") == isin).row(0, named=True)
    print(f"Found: {row['constituent_name']} (ISIN: {row['isin']})")

    # Create asset and fetch sentiment
    with Session() as session:
        siemens = Asset.from_isin(isin, session.resolver)
        df = session.sentiment(siemens, date_from="2026-01-01", date_to="2026-01-31")
        print(f"\nSentiment data:\n{df}")


def example_3_ric():
    """Example 3: Look up asset by RIC code from STOXX 600 and fetch sentiment."""
    print("\n" + "=" * 60)
    print("EXAMPLE 3: Using RIC Code")
    print("=" * 60)

    # Load STOXX 600 universe
    df = stoxx600()

    # Find SAP by RIC code
    ric = "SAPG.DE"
    row = df.filter(pl.col("constituent_ric") == ric).row(0, named=True)
    print(f"Found: {row['constituent_name']} (RIC: {row['constituent_ric']})")

    # Create asset and fetch sentiment
    with Session() as session:
        sap = Asset.from_ric(ric)
        df = session.sentiment(sap, date_from="2026-01-01", date_to="2026-01-31")
        print(f"\nSentiment data:\n{df}")


if __name__ == "__main__":
    example_1_yukka_id()
    example_2_isin()
    example_3_ric()
