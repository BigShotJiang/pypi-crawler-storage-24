"""Example: Fetching sentiment data from YUKKA APIs.

This example demonstrates how to:
1. Create a session with authentication
2. Create Asset objects from YUKKA IDs
3. Fetch sentiment scores for assets
"""

from dotenv import load_dotenv

from yukka import Asset, Session

load_dotenv()


def main():
    """Fetch sentiment data for BMW."""
    with Session() as session:
        # Create an asset from a YUKKA ID
        bmw = Asset.from_yukka_id(["company:bmw", "company:apple"])

        # Fetch sentiment data (date_to defaults to today)
        df = session.sentiment(bmw, date_from="2026-01-01")

        print(df)


if __name__ == "__main__":
    main()
