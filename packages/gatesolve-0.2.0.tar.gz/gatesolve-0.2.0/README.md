# gatesolve

> Solve CAPTCHAs with x402 micropayments. Built for AI agents.

[![PyPI](https://img.shields.io/pypi/v/gatesolve)](https://pypi.org/project/gatesolve/)
[![Python](https://img.shields.io/pypi/pyversions/gatesolve)](https://pypi.org/project/gatesolve/)

## Install

```bash
pip install gatesolve
```

## Quick Start

```python
from gatesolve import GateSolve

gs = GateSolve()

# Solve a Cloudflare Turnstile CAPTCHA
solution = gs.solve(
    captcha_type="turnstile",
    sitekey="0x4AAAAAAAB...",
    pageurl="https://example.com",
)

print(solution.token)  # Use this to bypass the CAPTCHA
print(solution.solve_time)  # e.g. "1.8s"
print(solution.payment.amount)  # e.g. "0.02"
```

## Async

```python
import asyncio
from gatesolve import AsyncGateSolve

async def main():
    async with AsyncGateSolve() as gs:
        solution = await gs.solve(
            captcha_type="turnstile",
            sitekey="0x4AAAAAAAB...",
            pageurl="https://example.com",
        )
        print(solution.token)

asyncio.run(main())
```

## With Playwright

```python
from gatesolve import GateSolve
from playwright.sync_api import sync_playwright

gs = GateSolve()

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    page.goto("https://protected-site.com")
    
    sitekey = page.locator("[data-sitekey]").get_attribute("data-sitekey")
    
    solution = gs.solve(
        captcha_type="turnstile",
        sitekey=sitekey,
        pageurl=page.url,
    )
    
    page.evaluate(f"""
        document.querySelector('[name="cf-turnstile-response"]')
            .value = '{solution.token}';
    """)
    page.click("button[type=submit]")
```

## Configuration

```python
gs = GateSolve(
    base_url="https://api.gatesolve.dev",  # API endpoint
    wallet_address="0x...",                  # Your USDC wallet
    network="base",                          # Base L2 (default)
    max_price=0.05,                          # Max price per solve
    timeout=30,                              # Timeout in seconds
    max_retries=3,                           # Auto-retry on failure
)
```

## Supported CAPTCHAs

| Type | SDK Name | Price |
|------|----------|-------|
| Cloudflare Turnstile | `turnstile` | $0.02 |
| reCAPTCHA v2 | `recaptcha_v2` | $0.03 |
| reCAPTCHA v3 | `recaptcha_v3` | $0.02 |
| hCaptcha | `hcaptcha` | $0.03 |

## How x402 Works

1. You call `gs.solve()` 
2. SDK sends request to GateSolve API
3. API returns HTTP 402 with payment details
4. SDK pays via USDC on Base L2
5. API returns the CAPTCHA solution

No API keys. No accounts. The payment IS the authentication.

## Error Handling

```python
from gatesolve import GateSolve, SolveError, RateLimitError

gs = GateSolve()

try:
    solution = gs.solve(...)
except RateLimitError as e:
    print(f"Rate limited, retry in {e.retry_after}s")
except SolveError as e:
    print(f"Solve failed: {e.message} (status: {e.status_code})")
```

## Links

- **Website**: [gatesolve.dev](https://gatesolve.dev)
- **Docs**: [gatesolve.dev/docs](https://gatesolve.dev/docs)
- **Playground**: [gatesolve.dev/playground](https://gatesolve.dev/playground)
- **Twitter**: [@ArsonxDev](https://x.com/ArsonxDev)

## License

MIT
