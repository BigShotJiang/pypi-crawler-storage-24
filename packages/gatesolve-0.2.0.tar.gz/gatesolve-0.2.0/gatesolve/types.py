"""Type definitions for GateSolve SDK."""

from typing import Literal

CaptchaType = Literal[
    "turnstile",
    "recaptcha_v2",
    "recaptcha_v3",
    "hcaptcha",
]

# Maps SDK type names to API type names
TYPE_MAP: dict[str, str] = {
    "turnstile": "cloudflare-turnstile",
    "recaptcha_v2": "recaptcha-v2",
    "recaptcha_v3": "recaptcha-v3",
    "hcaptcha": "hcaptcha",
}
