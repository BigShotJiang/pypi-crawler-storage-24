"""GateSolve client — sync and async CAPTCHA solving."""

from __future__ import annotations

import time
from typing import Optional

import httpx

from .models import PaymentInfo, RateLimitError, Solution, SolveError
from .types import TYPE_MAP, CaptchaType

DEFAULT_BASE_URL = "https://gatesolve.dev"
DEFAULT_TIMEOUT = 60.0
DEFAULT_POLL_INTERVAL = 3.0
DEFAULT_MAX_RETRIES = 3
USER_AGENT = "gatesolve-python/0.2.0"


class GateSolve:
    """Synchronous GateSolve client.

    Usage::

        from gatesolve import GateSolve

        gs = GateSolve(api_key="gs_your_key")
        solution = gs.solve(
            captcha_type="turnstile",
            sitekey="0x4AAAAAAAB...",
            pageurl="https://example.com",
        )
        print(solution.token)
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.poll_interval = poll_interval
        self.max_retries = max_retries
        
        headers = {"User-Agent": USER_AGENT}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=headers,
        )

    def solve(
        self,
        captcha_type: CaptchaType,
        sitekey: str,
        pageurl: str,
        *,
        timeout: Optional[float] = None,
        callback_url: Optional[str] = None,
    ) -> Solution:
        """Solve a CAPTCHA using async submit-and-poll.

        Args:
            captcha_type: Type of CAPTCHA ("turnstile", "recaptcha_v2", etc.)
            sitekey: The site key from the CAPTCHA element.
            pageurl: URL of the page containing the CAPTCHA.
            timeout: Override default timeout for this solve.
            callback_url: Optional webhook URL for result delivery.

        Returns:
            Solution with the solve token.

        Raises:
            SolveError: If the solve fails.
            RateLimitError: If rate limited.
        """
        api_type = TYPE_MAP.get(captcha_type, captcha_type)
        payload: dict = {
            "type": api_type,
            "siteKey": sitekey,
            "pageUrl": pageurl,
        }
        if callback_url:
            payload["callbackUrl"] = callback_url

        effective_timeout = timeout or self.timeout

        # Step 1: Submit solve request
        for attempt in range(self.max_retries):
            try:
                resp = self._client.post("/api/solve", json=payload)

                if resp.status_code == 429:
                    retry_after = float(resp.headers.get("Retry-After", "5"))
                    if attempt < self.max_retries - 1:
                        time.sleep(retry_after)
                        continue
                    raise RateLimitError(retry_after)

                if resp.status_code == 401:
                    raise SolveError(
                        "Invalid or missing API key. Get one free at gatesolve.dev",
                        status_code=401,
                        error_type="auth_error",
                    )

                if resp.status_code != 200:
                    try:
                        msg = resp.json().get("message", resp.text)
                    except Exception:
                        msg = resp.text
                    raise SolveError(msg, status_code=resp.status_code)

                data = resp.json()
                job_id = data.get("id")
                if not job_id:
                    raise SolveError("No job ID returned", error_type="api_error")

                break

            except httpx.TimeoutException:
                if attempt < self.max_retries - 1:
                    continue
                raise SolveError("Submit timed out", error_type="timeout")
            except (httpx.ConnectError, httpx.ReadError) as e:
                if attempt < self.max_retries - 1:
                    time.sleep(1)
                    continue
                raise SolveError(str(e), error_type="connection_error")
        else:
            raise SolveError("Max retries exceeded on submit", error_type="max_retries")

        # Step 2: Poll for result
        start = time.monotonic()
        while True:
            elapsed = time.monotonic() - start
            if elapsed > effective_timeout:
                raise SolveError(
                    f"Solve timed out after {effective_timeout:.0f}s",
                    error_type="timeout",
                )

            time.sleep(self.poll_interval)

            try:
                poll_resp = self._client.get(f"/api/solve?id={job_id}")
                if poll_resp.status_code != 200:
                    continue

                result = poll_resp.json()
                status = result.get("status")

                if status == "solved":
                    return Solution(
                        token=result["token"],
                        captcha_type=captcha_type,
                        solve_time=result.get("solvedIn", "unknown"),
                        job_id=job_id,
                    )
                elif status == "failed":
                    raise SolveError(
                        result.get("error", "Solve failed"),
                        error_type="solve_failed",
                    )
                # status is "pending" or "solving" — keep polling

            except httpx.TimeoutException:
                continue
            except (httpx.ConnectError, httpx.ReadError):
                continue

    def submit(
        self,
        captcha_type: CaptchaType,
        sitekey: str,
        pageurl: str,
        *,
        callback_url: Optional[str] = None,
    ) -> str:
        """Submit a solve request without polling. Returns the job ID.
        
        Use this with callback_url for webhook-based workflows,
        or call poll() manually.
        """
        api_type = TYPE_MAP.get(captcha_type, captcha_type)
        payload: dict = {
            "type": api_type,
            "siteKey": sitekey,
            "pageUrl": pageurl,
        }
        if callback_url:
            payload["callbackUrl"] = callback_url

        resp = self._client.post("/api/solve", json=payload)
        
        if resp.status_code != 200:
            try:
                msg = resp.json().get("message", resp.text)
            except Exception:
                msg = resp.text
            raise SolveError(msg, status_code=resp.status_code)

        return resp.json()["id"]

    def poll(self, job_id: str) -> dict:
        """Poll for a solve result. Returns the raw response dict."""
        resp = self._client.get(f"/api/solve?id={job_id}")
        return resp.json()

    def health(self) -> dict:
        """Check API health status."""
        resp = self._client.get("/api/health")
        return resp.json()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> GateSolve:
        return self

    def __exit__(self, *args) -> None:
        self.close()


class AsyncGateSolve:
    """Async GateSolve client for use with asyncio.

    Usage::

        import asyncio
        from gatesolve import AsyncGateSolve

        async def main():
            async with AsyncGateSolve(api_key="gs_your_key") as gs:
                solution = await gs.solve(
                    captcha_type="turnstile",
                    sitekey="0x4AAAAAAAB...",
                    pageurl="https://example.com",
                )
                print(solution.token)

        asyncio.run(main())
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.poll_interval = poll_interval
        self.max_retries = max_retries

        headers = {"User-Agent": USER_AGENT}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers=headers,
        )

    async def solve(
        self,
        captcha_type: CaptchaType,
        sitekey: str,
        pageurl: str,
        *,
        timeout: Optional[float] = None,
        callback_url: Optional[str] = None,
    ) -> Solution:
        """Async solve — same interface as sync client."""
        import asyncio

        api_type = TYPE_MAP.get(captcha_type, captcha_type)
        payload: dict = {
            "type": api_type,
            "siteKey": sitekey,
            "pageUrl": pageurl,
        }
        if callback_url:
            payload["callbackUrl"] = callback_url

        effective_timeout = timeout or self.timeout

        # Submit
        for attempt in range(self.max_retries):
            try:
                resp = await self._client.post("/api/solve", json=payload)

                if resp.status_code == 429:
                    retry_after = float(resp.headers.get("Retry-After", "5"))
                    if attempt < self.max_retries - 1:
                        await asyncio.sleep(retry_after)
                        continue
                    raise RateLimitError(retry_after)

                if resp.status_code == 401:
                    raise SolveError(
                        "Invalid or missing API key",
                        status_code=401,
                        error_type="auth_error",
                    )

                if resp.status_code != 200:
                    try:
                        msg = resp.json().get("message", resp.text)
                    except Exception:
                        msg = resp.text
                    raise SolveError(msg, status_code=resp.status_code)

                job_id = resp.json().get("id")
                if not job_id:
                    raise SolveError("No job ID returned", error_type="api_error")
                break

            except httpx.TimeoutException:
                if attempt < self.max_retries - 1:
                    continue
                raise SolveError("Submit timed out", error_type="timeout")
        else:
            raise SolveError("Max retries exceeded", error_type="max_retries")

        # Poll
        start = time.monotonic()
        while True:
            elapsed = time.monotonic() - start
            if elapsed > effective_timeout:
                raise SolveError(
                    f"Solve timed out after {effective_timeout:.0f}s",
                    error_type="timeout",
                )

            await asyncio.sleep(self.poll_interval)

            try:
                poll_resp = await self._client.get(f"/api/solve?id={job_id}")
                if poll_resp.status_code != 200:
                    continue

                result = poll_resp.json()
                status = result.get("status")

                if status == "solved":
                    return Solution(
                        token=result["token"],
                        captcha_type=captcha_type,
                        solve_time=result.get("solvedIn", "unknown"),
                        job_id=job_id,
                    )
                elif status == "failed":
                    raise SolveError(
                        result.get("error", "Solve failed"),
                        error_type="solve_failed",
                    )

            except httpx.TimeoutException:
                continue

    async def submit(
        self,
        captcha_type: CaptchaType,
        sitekey: str,
        pageurl: str,
        *,
        callback_url: Optional[str] = None,
    ) -> str:
        """Submit without polling. Returns job ID."""
        api_type = TYPE_MAP.get(captcha_type, captcha_type)
        payload: dict = {
            "type": api_type,
            "siteKey": sitekey,
            "pageUrl": pageurl,
        }
        if callback_url:
            payload["callbackUrl"] = callback_url

        resp = await self._client.post("/api/solve", json=payload)
        if resp.status_code != 200:
            try:
                msg = resp.json().get("message", resp.text)
            except Exception:
                msg = resp.text
            raise SolveError(msg, status_code=resp.status_code)
        return resp.json()["id"]

    async def poll(self, job_id: str) -> dict:
        """Poll for result."""
        resp = await self._client.get(f"/api/solve?id={job_id}")
        return resp.json()

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncGateSolve:
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()
