"""Data models for GateSolve SDK."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PaymentInfo:
    """Details of the x402 micropayment."""
    amount: str
    currency: str = "USDC"
    network: str = "base"
    tx_hash: Optional[str] = None
    receiver: Optional[str] = None


@dataclass
class Solution:
    """A solved CAPTCHA result."""
    token: str
    captcha_type: str
    solve_time: str
    job_id: Optional[str] = None
    payment: Optional[PaymentInfo] = None
    
    def __str__(self) -> str:
        return self.token
    
    def __repr__(self) -> str:
        return f"Solution(type={self.captcha_type!r}, time={self.solve_time}, token={self.token[:20]}...)"


class SolveError(Exception):
    """Raised when a CAPTCHA solve fails."""
    
    def __init__(self, message: str, status_code: int = 0, error_type: str = "unknown"):
        self.message = message
        self.status_code = status_code
        self.error_type = error_type
        super().__init__(message)


class PaymentError(SolveError):
    """Raised when x402 payment fails."""
    
    def __init__(self, message: str, amount: str = "", currency: str = "USDC"):
        self.amount = amount
        self.currency = currency
        super().__init__(message, status_code=402, error_type="payment_failed")


class RateLimitError(SolveError):
    """Raised when rate limited."""
    
    def __init__(self, retry_after: float = 0):
        self.retry_after = retry_after
        super().__init__(
            f"Rate limited. Retry after {retry_after}s",
            status_code=429,
            error_type="rate_limited",
        )
