"""GateSolve — Solve CAPTCHAs with x402 micropayments."""

from .client import GateSolve, AsyncGateSolve
from .models import Solution, PaymentInfo, SolveError
from .types import CaptchaType

__version__ = "0.1.0"
__all__ = [
    "GateSolve",
    "AsyncGateSolve",
    "Solution",
    "PaymentInfo",
    "SolveError",
    "CaptchaType",
]
