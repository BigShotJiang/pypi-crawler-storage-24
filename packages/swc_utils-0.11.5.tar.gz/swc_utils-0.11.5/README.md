### SWC Utils
> This repository contains a collection of utilities for SWC projects.

`pip install swc_utils`

`pip install swc_utils[extras]` (for all extras)

#### Test with pytest
(you need to have a redis server running for the tests to work - it must be reachable from the hostname 'redis' and the default port 6379)
```bash
pytest -v
```

#### Email Login with united-domains
```python
from swc_utils.mail.smtp_client import SMTPClient

client = SMTPClient(
    "smtp.udag.de",
    465,
    "<default>@example.com",
    "<system name>",
    "<user>",
    "<password>"
)

client.send(
    ["<mail1>", "<mail2>"],
    "<content>",
    "<subject>",
    sender_email="sender@example.com"
)
```
