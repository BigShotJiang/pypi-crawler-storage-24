"""
Routing utilities for SWC.
Includes routes for /login and /logout, as well as any other authentication-related routes.
"""