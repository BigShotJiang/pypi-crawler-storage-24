"""
This module provides utilities for managing database connections and models.
It includes functionality for creating connection profiles, connecting to databases, and generating base models for database interactions.
"""
from .connection_profile import ConnectionProfile
from .database_connection import connect_to_database
from .base_model import make_base_model
