"""
Helper functions for exceptions.
"""