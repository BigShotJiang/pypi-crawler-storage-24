import pickle
import weakref
from collections.abc import MutableMapping
from typing import TypeVar

from redis import Redis

V = TypeVar("V")


class RedisSimpleMapping(MutableMapping[str, V]):
    def __init__(self, redis: Redis, redis_key: str = None, persist: bool = False, overwrite: bool = True,
                 default_item_ttl: int = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.redis = redis
        self.redis_key = \
            (redis_key if ":" in redis_key else f"redis_mapping:{redis_key}") \
                if redis_key is not None else f"redis_mapping:{id(self)}"
        self.default_item_ttl = default_item_ttl

        pattern = f"{self.redis_key}:*"
        if self.redis.keys(pattern):
            if overwrite:
                for k in self.redis.keys(pattern):
                    self.redis.delete(k)
            else:
                raise ValueError(f"Redis key '{self.redis_key}' already exists and overwrite is set to False.")
        if not persist:
            _redis = self.redis
            _pattern = f"{self.redis_key}:*"
            weakref.finalize(self, lambda: [_redis.delete(k) for k in _redis.keys(_pattern)])

    def key_for(self, item: str):
        return f"{self.redis_key}:{item}"

    def keys(self):
        prefix = f"{self.redis_key}:"
        return [key.decode().removeprefix(prefix) for key in self.redis.keys(f"{prefix}*")]

    def set(self, key: str, value: V, ex=None):
        self.redis.set(self.key_for(key), pickle.dumps(value), ex=ex or self.default_item_ttl)

    def get(self, key: str, default=None) -> V:
        item = self.redis.get(self.key_for(key))
        if item is None:
            if default is not None:
                return default
            raise KeyError(f"Key '{key}' not found in RedisSimpleMapping.")
        return pickle.loads(item)

    def delete(self, key: str):
        self.redis.delete(self.key_for(key))

    def __len__(self):
        return len(self.redis.keys(f"{self.redis_key}:*"))

    def __getitem__(self, item: str) -> V:
        return self.get(item)

    def __iter__(self):
        for key in self.keys():
            yield key

    def __setitem__(self, key: str, value: V):
        self.set(key, value)

    def __delitem__(self, key: str):
        self.delete(key)

    def __repr__(self):
        keys = self.keys()
        items = {key: pickle.loads(self.get(key)) for key in keys}
        return f"RedisBucket({items})"
