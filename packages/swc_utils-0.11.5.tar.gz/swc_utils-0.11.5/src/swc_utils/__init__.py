"""
.. include:: ../../README.md
    :end-before: Email Login with united-domains
"""