"""
This module provides utilities for sending emails using the SMTP protocol.
It includes the SMTPClient class, which allows you to connect to an SMTP server, authenticate, and send emails with various options such as attachments and HTML content.
"""

from .smtp_client import SMTPClient
