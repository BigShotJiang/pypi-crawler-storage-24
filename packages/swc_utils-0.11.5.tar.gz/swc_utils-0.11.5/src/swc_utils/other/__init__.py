"""
Other utilities for SWC processing.
"""

from .generator_utils import generator_from_callback_consumer
