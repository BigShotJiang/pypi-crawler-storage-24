"""
pyexample.

An example python library.
"""

__version__ = '0.1.0'
__author__ = 'Jandre Badenhorst'
__credits__ = 'https://developer.payspace.com'