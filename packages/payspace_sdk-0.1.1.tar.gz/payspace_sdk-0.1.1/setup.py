from setuptools import setup


with open("README.md", "r") as fh:
    long_description = fh.read()


setup(
    name='payspace_sdk',
    version='0.1.1',    
    description='A simple SDK for interacting with the Payspace API',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/jb-tech1999/payspace_sdk',
    author='Jandre Badenhorst',
    author_email='j.badenhorst@decisioninc.com',
    packages=['payspace_sdk'],
    install_requires=['requests'],

    classifiers=[
        'Intended Audience :: Developers', 
        'Operating System :: POSIX :: Linux',        

        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14',
    ],
)