"""Tests for BearerTokenMiddleware."""

import pytest

from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient

from affinity_mcp.bearer_token_middleware import BearerTokenMiddleware
from affinity_mcp.context import api_key_var


def _make_app() -> Starlette:
    """Create a minimal Starlette app that echoes the current api_key_var."""

    async def echo_key(request):
        return JSONResponse({"api_key": api_key_var.get("")})

    app = Starlette(routes=[Route("/echo", echo_key)])
    app.add_middleware(BearerTokenMiddleware)
    return app


@pytest.fixture
def client() -> TestClient:
    return TestClient(_make_app())


def test_sets_api_key_from_bearer_header(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Bearer test-key-123"})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": "test-key-123"}


def test_missing_header_leaves_key_empty(client: TestClient):
    resp = client.get("/echo")
    assert resp.status_code == 200
    assert resp.json() == {"api_key": ""}


def test_empty_bearer_leaves_key_empty(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Bearer "})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": ""}


def test_non_bearer_auth_leaves_key_empty(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Basic abc123"})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": ""}


def test_api_key_does_not_leak_between_requests(client: TestClient):
    resp1 = client.get("/echo", headers={"Authorization": "Bearer key-one"})
    assert resp1.json() == {"api_key": "key-one"}

    resp2 = client.get("/echo")
    assert resp2.json() == {"api_key": ""}


@pytest.mark.asyncio
async def test_non_http_scope_passes_through():
    observed_keys = []

    async def inner_app(scope, receive, send):
        observed_keys.append(api_key_var.get(""))

    middleware = BearerTokenMiddleware(inner_app)
    await middleware({"type": "websocket"}, None, None)
    assert observed_keys == [""]
