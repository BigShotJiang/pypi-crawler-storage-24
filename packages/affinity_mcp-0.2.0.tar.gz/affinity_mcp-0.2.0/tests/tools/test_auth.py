import pytest
from affinity_mcp.tools.auth import get_current_user


@pytest.mark.asyncio
async def test_get_current_user(mocker):
    mock_response = {
        "grant": {
            "createdAt": "2023-01-01T00:00:00Z",
            "scopes": ["api"],
            "type": "api-key",
        },
        "user": {
            "firstName": "John",
            "lastName": "Smith",
            "emailAddress": "john.smith@contoso.com",
            "id": 1,
        },
        "tenant": {"name": "Contoso Ltd.", "subdomain": "contoso", "id": 1},
    }

    mock_fetch_current_user = mocker.patch("affinity_mcp.tools.auth.fetch_current_user")
    mock_fetch_current_user.return_value = mock_response

    result = await get_current_user()

    assert result == mock_response

    mock_fetch_current_user.assert_called_once()
