import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.relationship_strengths import get_relationship_strengths


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_relationship_strengths_api = mocker.patch(
        "affinity_mcp.tools.relationship_strengths.AffinityAPI"
    )
    mock_relationship_strengths_api.return_value.__aenter__.return_value = (
        mock_api_instance
    )

    return mock_api_instance


@pytest.mark.asyncio
async def test_get_relationship_strengths_with_only_external_person_id(
    mock_affinity_api,
):
    mock_response = [
        {
            "external_id": 1234,
            "internal_id": 2345,
            "strength": 0.5,
        },
        {
            "external_id": 1234,
            "internal_id": 3456,
            "strength": 0.9,
        },
        {
            "external_id": 1234,
            "internal_id": 4567,
            "strength": 0.123,
        },
    ]

    mock_affinity_api.get.return_value = mock_response

    result = await get_relationship_strengths(external_person_id=1234)

    expected_response = {"data": mock_response}
    assert expected_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/relationships-strengths", params={"external_id": 1234}
    )


@pytest.mark.asyncio
async def test_get_relationship_strengths_with_internal_person_id(mock_affinity_api):
    mock_response = [
        {
            "external_id": 1234,
            "internal_id": 2345,
            "strength": 0.875,
        }
    ]

    mock_affinity_api.get.return_value = mock_response

    result = await get_relationship_strengths(
        external_person_id=1234, internal_person_id=2345
    )

    expected_response = {"data": mock_response}
    assert expected_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/relationships-strengths",
        params={"internal_id": 2345, "external_id": 1234},
    )
