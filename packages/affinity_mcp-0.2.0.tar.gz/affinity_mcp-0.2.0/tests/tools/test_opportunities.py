import pytest

from unittest.mock import AsyncMock
from affinity_mcp.tools import opportunities


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()
    mock_api_class = mocker.patch("affinity_mcp.tools.opportunities.AffinityAPI")
    mock_api_class.return_value.__aenter__.return_value = mock_api_instance
    return mock_api_instance


@pytest.mark.asyncio
async def test_search_opportunities_with_default_filters(mock_affinity_api):
    mock_response = {
        "opportunities": [
            {
                "id": 1,
                "name": "Opp 1",
                "person_ids": [1],
                "organization_ids": [1],
                "list_entries": [],
            },
            {
                "id": 2,
                "name": "Opp 2",
                "person_ids": [2],
                "organization_ids": [2],
                "list_entries": [],
            },
        ]
    }
    mock_affinity_api.get.return_value = mock_response

    result = await opportunities.search_opportunities()

    assert mock_response == result
    mock_affinity_api.get.assert_called_once_with(
        "/opportunities", params={"page_size": 100}
    )


@pytest.mark.asyncio
async def test_search_opportunities_with_term_no_page_size_reduce_page_size(
    mock_affinity_api,
):
    mock_response = {
        "opportunities": [
            {
                "id": 1,
                "name": "Test",
                "person_ids": [1],
                "organization_ids": [1],
                "list_entries": [],
            },
        ]
    }
    mock_affinity_api.get.return_value = mock_response

    result = await opportunities.search_opportunities(term="Test")

    assert mock_response == result
    mock_affinity_api.get.assert_called_once_with(
        "/opportunities",
        params={"term": "Test", "page_size": 10},
    )


@pytest.mark.asyncio
async def test_search_opportunities_with_term_and_provided_page_size(mock_affinity_api):
    mock_response = {
        "opportunities": [
            {
                "id": 1,
                "name": "Test",
                "person_ids": [1],
                "organization_ids": [1],
                "list_entries": [],
            },
        ]
    }
    mock_affinity_api.get.return_value = mock_response

    result = await opportunities.search_opportunities(
        term="Test", page_size=50, page_token="token"
    )

    assert mock_response == result
    mock_affinity_api.get.assert_called_once_with(
        "/opportunities",
        params={"term": "Test", "page_size": 50, "page_token": "token"},
    )
