import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.transcripts import get_transcript_fragments


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()
    mock_transcripts_api = mocker.patch("affinity_mcp.tools.transcripts.AffinityAPI")
    mock_transcripts_api.return_value.__aenter__.return_value = mock_api_instance
    return mock_api_instance


@pytest.fixture
def mock_fragments_response():
    return {
        "data": [
            {
                "content": "Hello, welcome to the meeting.",
                "speaker": "John Doe",
                "startTimestamp": "00:00:05",
                "endTimestamp": "00:00:08",
            },
            {
                "content": "Thanks for having me. Let's discuss the proposal.",
                "speaker": "Jane Smith",
                "startTimestamp": "00:00:09",
                "endTimestamp": "00:00:13",
            },
        ],
        "pagination": {
            "prevUrl": None,
            "nextUrl": "https://api.affinity.co/v2/transcripts/123/fragments?cursor=abc123",
        },
    }


@pytest.mark.asyncio
async def test_get_transcript_fragments_with_defaults(
    mock_affinity_api, mock_fragments_response
):
    mock_fragments_response["pagination"]["totalCount"] = 2
    mock_affinity_api.get.return_value = mock_fragments_response

    result = await get_transcript_fragments(transcript_id=123)

    assert result == mock_fragments_response
    assert result["pagination"]["totalCount"] == 2
    mock_affinity_api.get.assert_called_once_with(
        "/v2/transcripts/123/fragments", params={"limit": 20, "totalCount": True}
    )


@pytest.mark.asyncio
async def test_get_transcript_fragments_with_pagination(
    mock_affinity_api, mock_fragments_response
):
    mock_fragments_response["pagination"]["totalCount"] = 100
    mock_affinity_api.get.return_value = mock_fragments_response

    result = await get_transcript_fragments(
        transcript_id=456, cursor="abc123", limit=50
    )

    assert result == mock_fragments_response
    assert result["pagination"]["totalCount"] == 100
    mock_affinity_api.get.assert_called_once_with(
        "/v2/transcripts/456/fragments",
        params={"cursor": "abc123", "limit": 50, "totalCount": True},
    )
