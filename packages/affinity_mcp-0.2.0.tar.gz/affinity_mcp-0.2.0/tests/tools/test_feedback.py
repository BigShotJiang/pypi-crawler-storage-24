import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.feedback import send_feedback


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_feedback_api = mocker.patch("affinity_mcp.tools.feedback.AffinityAPI")
    mock_feedback_api.return_value.__aenter__.return_value = mock_api_instance

    return mock_api_instance


@pytest.mark.asyncio
async def test_send_feedback(mock_affinity_api):
    mock_affinity_api.post.return_value = None

    subject = "Feedback Request"
    body = "Feedback Body"
    result = await send_feedback(subject=subject, body=body)

    assert result is None

    mock_affinity_api.post.assert_called_once_with(
        "/v2/feedback", {"subject": subject, "body": body, "type": "mcp"}
    )
