import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.field_values import (
    get_entity_field_values,
    upsert_entity_field_value,
    upsert_list_entry_field_values,
    FieldValueUpsert,
    ValueToUpsert,
)
from affinity_mcp.types import EntityType, Location, FieldValueType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_field_values_api = mocker.patch("affinity_mcp.tools.field_values.AffinityAPI")
    mock_field_values_api.return_value.__aenter__.return_value = mock_api_instance

    return mock_api_instance


@pytest.mark.asyncio
async def test_get_entity_field_values(mock_affinity_api):
    mock_response = [
        {
            "id": 123,
            "field_id": 456,
            "list_entry_id": None,
            "entity_id": 789,
            "entity_type": 0,
            "value": {
                "city": "San Francisco",
                "state": "California",
                "country": "United States",
            },
            "value_type": 6,
        },
        {
            "id": 124,
            "field_id": 457,
            "list_entry_id": None,
            "entity_id": 789,
            "entity_type": 0,
            "value": "Some text value",
            "value_type": 1,
        },
    ]

    mock_affinity_api.get.return_value = mock_response

    result = await get_entity_field_values(entity_type=EntityType.PERSON, entity_id=789)

    assert result == {"data": mock_response}

    mock_affinity_api.get.assert_called_once_with(
        "/field-values", params={"person_id": 789}
    )


@pytest.mark.asyncio
async def test_upsert_entity_field_value_both_modes_raises_error(mock_affinity_api):
    with pytest.raises(ValueError) as exc_info:
        await upsert_entity_field_value(
            value="Some text value", field_value_id=123, field_id=456, entity_id=789
        )
    assert (
        str(exc_info.value)
        == "Cannot provide both field_value_id (UPDATE mode) and field_id/entity_id (CREATE mode)"
    )


@pytest.mark.asyncio
async def test_upsert_entity_field_value_no_mode_raises_error(mock_affinity_api):
    with pytest.raises(ValueError) as exc_info:
        await upsert_entity_field_value(value="Some text value")
    assert (
        str(exc_info.value)
        == "Must provide either field_value_id (UPDATE MODE) or field_id/entity_id (CREATE MODE)"
    )


@pytest.mark.asyncio
async def test_upsert_entity_field_value_create_with_empty_value_raises_error(
    mock_affinity_api,
):
    with pytest.raises(ValueError) as exc_info:
        await upsert_entity_field_value(field_id=1, entity_id=789, value=None)
    assert str(exc_info.value) == "Cannot create empty field value"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "value,expected_body,expected_value",
    [
        ("Healthcare", {"value": "Healthcare"}, "Healthcare"),
        (1000000, {"value": 1000000}, 1000000),
        (
            Location(street_address="123 Market St", city="San Francisco", state="CA"),
            {
                "value": {
                    "street_address": "123 Market St",
                    "city": "San Francisco",
                    "state": "CA",
                }
            },
            {"city": "San Francisco", "state": "CA"},
        ),
    ],
)
async def test_upsert_entity_field_value_update_mode(
    mock_affinity_api, value, expected_body, expected_value
):
    mock_response = {
        "id": 20406836,
        "field_id": 1284,
        "list_entry_id": None,
        "entity_id": 38706,
        "created_at": "2022-10-04T10:37:19.418-04:00",
        "updated_at": "2023-02-06T11:53:08.914-05:00",
        "value": expected_value,
    }
    mock_affinity_api.put.return_value = mock_response

    result = await upsert_entity_field_value(field_value_id=20406836, value=value)

    assert result == mock_response
    mock_affinity_api.put.assert_called_once_with(
        "/field-values/20406836", body=expected_body
    )


@pytest.mark.asyncio
async def test_upsert_entity_field_value_update_mode_empty_value_calls_delete(
    mock_affinity_api,
):
    mock_response = {"success": True}
    mock_affinity_api.delete.return_value = mock_response

    result = await upsert_entity_field_value(field_value_id=20406836, value=None)

    assert result == mock_response
    mock_affinity_api.delete.assert_called_once_with("/field-values/20406836")


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "value,expected_value",
    [
        ("Healthcare", "Healthcare"),
        (1000000, 1000000),
        (
            Location(street_address="123 Market St", city="San Francisco", state="CA"),
            {"street_address": "123 Market St", "city": "San Francisco", "state": "CA"},
        ),
    ],
)
async def test_upsert_entity_field_value_create_mode(
    mock_affinity_api, value, expected_value
):
    mock_response = {
        "id": 20406836,
        "field_id": 123,
        "list_entry_id": None,
        "entity_id": 789,
        "created_at": "2022-10-04T10:37:19.418-04:00",
        "updated_at": "2023-02-06T11:53:08.914-05:00",
        "value": expected_value,
    }
    mock_affinity_api.post.return_value = mock_response

    result = await upsert_entity_field_value(field_id=123, entity_id=789, value=value)

    expected_body = {
        "field_id": 123,
        "value": expected_value,
        "entity_id": 789,
    }
    assert result == mock_response
    mock_affinity_api.post.assert_called_once_with("/field-values", body=expected_body)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "field_upsert,expected_formatted_upsert",
    [
        (
            FieldValueUpsert(
                id="field-text",
                value=ValueToUpsert(type=FieldValueType.TEXT, data="Some new text"),
            ),
            {"id": "field-text", "value": {"type": "text", "data": "Some new text"}},
        ),
        (
            FieldValueUpsert(
                id="field-filterable-text",
                value=ValueToUpsert(
                    type=FieldValueType.FILTERABLE_TEXT, data="Some filterable text"
                ),
            ),
            {
                "id": "field-filterable-text",
                "value": {"type": "filterable-text", "data": "Some filterable text"},
            },
        ),
        (
            FieldValueUpsert(
                id="field-filterable-text-multi",
                value=ValueToUpsert(
                    type=FieldValueType.FILTERABLE_TEXT_MULTI, data=["Text 1", "Text 2"]
                ),
            ),
            {
                "id": "field-filterable-text-multi",
                "value": {
                    "type": "filterable-text-multi",
                    "data": ["Text 1", "Text 2"],
                },
            },
        ),
        (
            FieldValueUpsert(
                id="field-datetime",
                value=ValueToUpsert(
                    type=FieldValueType.DATETIME, data="2023-01-01T00:00:00Z"
                ),
            ),
            {
                "id": "field-datetime",
                "value": {"type": "datetime", "data": "2023-01-01T00:00:00Z"},
            },
        ),
        (
            FieldValueUpsert(
                id="field-company",
                value=ValueToUpsert(type=FieldValueType.COMPANY, data={"id": 1}),
            ),
            {"id": "field-company", "value": {"type": "company", "data": {"id": 1}}},
        ),
        (
            FieldValueUpsert(
                id="field-company-multi",
                value=ValueToUpsert(
                    type=FieldValueType.COMPANY_MULTI, data=[{"id": 1}, {"id": 2}]
                ),
            ),
            {
                "id": "field-company-multi",
                "value": {"type": "company-multi", "data": [{"id": 1}, {"id": 2}]},
            },
        ),
        (
            FieldValueUpsert(
                id="field-person",
                value=ValueToUpsert(type=FieldValueType.PERSON, data={"id": 1}),
            ),
            {"id": "field-person", "value": {"type": "person", "data": {"id": 1}}},
        ),
        (
            FieldValueUpsert(
                id="field-person-multi",
                value=ValueToUpsert(
                    type=FieldValueType.PERSON_MULTI, data=[{"id": 1}, {"id": 2}]
                ),
            ),
            {
                "id": "field-person-multi",
                "value": {"type": "person-multi", "data": [{"id": 1}, {"id": 2}]},
            },
        ),
        (
            FieldValueUpsert(
                id="field-number",
                value=ValueToUpsert(type=FieldValueType.NUMBER, data=100),
            ),
            {"id": "field-number", "value": {"type": "number", "data": 100}},
        ),
        (
            FieldValueUpsert(
                id="field-number-multi",
                value=ValueToUpsert(
                    type=FieldValueType.NUMBER_MULTI, data=[100, 200, 300]
                ),
            ),
            {
                "id": "field-number-multi",
                "value": {"type": "number-multi", "data": [100, 200, 300]},
            },
        ),
        (
            FieldValueUpsert(
                id="field-location",
                value=ValueToUpsert(
                    type=FieldValueType.LOCATION,
                    data=Location(city="San Francisco", state="CA"),
                ),
            ),
            {
                "id": "field-location",
                "value": {
                    "type": "location",
                    "data": {
                        "streetAddress": None,
                        "city": "San Francisco",
                        "state": "CA",
                        "country": None,
                        "continent": None,
                    },
                },
            },
        ),
        (
            FieldValueUpsert(
                id="field-location-dict",
                value=ValueToUpsert(
                    type=FieldValueType.LOCATION,
                    data={"city": "New York", "state": "NY"},
                ),
            ),
            {
                "id": "field-location-dict",
                "value": {
                    "type": "location",
                    "data": {
                        "streetAddress": None,
                        "city": "New York",
                        "state": "NY",
                        "country": None,
                        "continent": None,
                    },
                },
            },
        ),
        (
            FieldValueUpsert(
                id="field-location-multi",
                value=ValueToUpsert(
                    type=FieldValueType.LOCATION_MULTI,
                    data=[
                        Location(
                            street_address="1 Main Street",
                            city="San Francisco",
                            state="California",
                            country="United States",
                            continent="North America",
                        ),
                        Location(
                            street_address="1600 Pennsylvania Avenue NW",
                            city="Washington",
                            state="DC",
                            country="United States",
                            continent="North America",
                        ),
                    ],
                ),
            ),
            {
                "id": "field-location-multi",
                "value": {
                    "type": "location-multi",
                    "data": [
                        {
                            "streetAddress": "1 Main Street",
                            "city": "San Francisco",
                            "state": "California",
                            "country": "United States",
                            "continent": "North America",
                        },
                        {
                            "streetAddress": "1600 Pennsylvania Avenue NW",
                            "city": "Washington",
                            "state": "DC",
                            "country": "United States",
                            "continent": "North America",
                        },
                    ],
                },
            },
        ),
        (
            FieldValueUpsert(
                id="field-dropdown",
                value=ValueToUpsert(
                    type=FieldValueType.DROPDOWN, data={"dropdownOptionId": 1}
                ),
            ),
            {
                "id": "field-dropdown",
                "value": {"type": "dropdown", "data": {"dropdownOptionId": 1}},
            },
        ),
        (
            FieldValueUpsert(
                id="field-dropdown-multi",
                value=ValueToUpsert(
                    type=FieldValueType.DROPDOWN_MULTI,
                    data=[{"dropdownOptionId": 1}, {"dropdownOptionId": 2}],
                ),
            ),
            {
                "id": "field-dropdown-multi",
                "value": {
                    "type": "dropdown-multi",
                    "data": [{"dropdownOptionId": 1}, {"dropdownOptionId": 2}],
                },
            },
        ),
        (
            FieldValueUpsert(
                id="field-ranked-dropdown",
                value=ValueToUpsert(
                    type=FieldValueType.RANKED_DROPDOWN, data={"dropdownOptionId": 1}
                ),
            ),
            {
                "id": "field-ranked-dropdown",
                "value": {"type": "ranked-dropdown", "data": {"dropdownOptionId": 1}},
            },
        ),
    ],
)
async def test_upsert_list_entry_field_values(
    mock_affinity_api, field_upsert, expected_formatted_upsert
):
    mock_response = {"operation": "update-fields"}
    mock_affinity_api.patch.return_value = mock_response

    result = await upsert_list_entry_field_values(
        list_id=123, list_entry_id=456, upserts=[field_upsert]
    )

    assert result == mock_response
    mock_affinity_api.patch.assert_called_once_with(
        "/v2/lists/123/list-entries/456/fields",
        body={"operation": "update-fields", "updates": [expected_formatted_upsert]},
    )
