import pytest

from unittest.mock import AsyncMock
from datetime import datetime, timezone
from affinity_mcp.tools import notes
from affinity_mcp.tools.notes import EntityType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()
    mock_api_class = mocker.patch("affinity_mcp.tools.notes.AffinityAPI")
    mock_api_class.return_value.__aenter__.return_value = mock_api_instance
    return mock_api_instance


@pytest.fixture
def mock_construct_tenant_url(mocker):
    mock = mocker.patch("affinity_mcp.tools.notes.construct_tenant_url")
    mock.return_value = "https://contoso.affinity.co"
    return mock


@pytest.fixture
def mock_get_notes_response():
    return [
        {
            "id": 2,
            "content": {
                "html": "<p>A new note</p>",
            },
            "creator": {
                "id": 111,
                "firstName": "Doe",
                "lastName": "John",
                "primaryEmailAddress": "john.doe@affinity.co",
                "type": "internal",
            },
            "createdAt": "2026-01-14T16:22:56Z",
            "updatedAt": "2026-01-14T16:22:56Z",
            "mentions": [],
        }
    ]


@pytest.mark.asyncio
async def test_create_note_with_single_entity_id(
    mock_affinity_api, mock_construct_tenant_url
):
    person_ids = [123]
    content = "Test note"
    mock_response = {
        "id": 1,
        "creator_id": 2,
        "person_ids": person_ids,
        "associated_person_ids": [123],
        "interaction_person_ids": [],
        "interaction_id": None,
        "interaction_type": None,
        "is_meeting": False,
        "mentioned_person_ids": [],
        "organization_ids": [],
        "opportunity_ids": [],
        "parent_id": None,
        "content": content,
        "type": 2,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": None,
    }

    mock_affinity_api.post.return_value = mock_response

    result = await notes.create_note(person_ids=person_ids, content=content)
    expected_result = {
        **mock_response,
        "note_url": "https://contoso.affinity.co/notes/1",
    }
    assert expected_result == result
    mock_affinity_api.post.assert_called_once_with(
        "/notes", {"person_ids": person_ids, "content": content, "type": 2}
    )


@pytest.mark.asyncio
async def test_create_note_with_multiple_entity_ids(
    mock_affinity_api, mock_construct_tenant_url
):
    person_ids = [123]
    company_ids = [456]
    opportunity_ids = [789, 910]
    content = "Test note"
    mock_response = {
        "id": 1,
        "creator_id": 2,
        "person_ids": person_ids,
        "associated_person_ids": [123],
        "interaction_person_ids": [],
        "interaction_id": None,
        "interaction_type": None,
        "is_meeting": False,
        "mentioned_person_ids": [],
        "organization_ids": company_ids,
        "opportunity_ids": opportunity_ids,
        "parent_id": None,
        "content": content,
        "type": 2,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": None,
    }

    mock_affinity_api.post.return_value = mock_response

    result = await notes.create_note(
        person_ids=person_ids,
        company_ids=company_ids,
        opportunity_ids=opportunity_ids,
        content=content,
    )
    expected_result = {
        **mock_response,
        "note_url": "https://contoso.affinity.co/notes/1",
    }
    assert expected_result == result
    mock_affinity_api.post.assert_called_once_with(
        "/notes",
        {
            "person_ids": person_ids,
            "organization_ids": company_ids,
            "opportunity_ids": opportunity_ids,
            "content": content,
            "type": 2,
        },
    )


@pytest.mark.asyncio
async def test_get_notes_use_defaults(mock_affinity_api, mock_get_notes_response):
    mock_affinity_api.get.return_value = mock_get_notes_response

    result = await notes.get_notes()
    assert mock_get_notes_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/notes", params={"limit": 20})


@pytest.mark.asyncio
async def test_get_notes_with_filter_expr(mock_affinity_api, mock_get_notes_response):
    mock_affinity_api.get.return_value = mock_get_notes_response

    result = await notes.get_notes(filter_expr="createdAt<2026-01-01T00:00:00Z")
    assert mock_get_notes_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/notes", params={"filter": "createdAt<2026-01-01T00:00:00Z", "limit": 20}
    )


@pytest.mark.asyncio
async def test_get_notes_with_pagination(mock_affinity_api, mock_get_notes_response):
    mock_affinity_api.get.return_value = mock_get_notes_response

    result = await notes.get_notes(cursor="ICAgICAgIGFmdGVyOjo6NA", limit=50)
    assert mock_get_notes_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/notes", params={"cursor": "ICAgICAgIGFmdGVyOjo6NA", "limit": 50}
    )


@pytest.mark.asyncio
async def test_get_notes_with_all_parameters(
    mock_affinity_api, mock_get_notes_response
):
    mock_affinity_api.get.return_value = mock_get_notes_response

    result = await notes.get_notes(
        filter_expr="createdAt>2025-01-01T00:00:00Z",
        cursor="ICAgICAgIGFmdGVyOjo6NA",
        limit=100,
    )
    assert mock_get_notes_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/notes",
        params={
            "filter": "createdAt>2025-01-01T00:00:00Z",
            "cursor": "ICAgICAgIGFmdGVyOjo6NA",
            "limit": 100,
        },
    )


@pytest.mark.asyncio
async def test_companies_attached_to_note(mock_affinity_api):
    mock_response = [{"id": 2, "type": "company"}]

    mock_affinity_api.get.return_value = mock_response

    result = await notes.get_entities_attached_to_note(
        note_id=2, entity_type=EntityType.COMPANY
    )
    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/notes/2/attached-companies")


@pytest.mark.asyncio
async def test_persons_attached_to_note(mock_affinity_api):
    mock_response = [{"id": 2, "type": "person"}]

    mock_affinity_api.get.return_value = mock_response

    result = await notes.get_entities_attached_to_note(
        note_id=2, entity_type=EntityType.PERSON
    )
    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/notes/2/attached-persons")


@pytest.mark.asyncio
async def test_opportunities_attached_to_note(mock_affinity_api):
    mock_response = [{"id": 2, "type": "opportunity"}]

    mock_affinity_api.get.return_value = mock_response

    result = await notes.get_entities_attached_to_note(
        note_id=2, entity_type=EntityType.OPPORTUNITY
    )
    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/notes/2/attached-opportunities")


@pytest.mark.asyncio
async def test_get_notes_for_a_person(mock_affinity_api):
    mock_response = {"data": [{"id": 1, "content": "abcd"}]}

    mock_affinity_api.get.return_value = mock_response

    result = await notes.get_notes_for_entity(
        entity_id=2, entity_type=EntityType.PERSON
    )
    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/persons/2/notes")


@pytest.mark.asyncio
async def test_get_notes_for_a_company(mock_affinity_api):
    mock_response = {"data": [{"id": 1, "content": "abcd"}]}

    mock_affinity_api.get.return_value = mock_response

    result = await notes.get_notes_for_entity(
        entity_id=2, entity_type=EntityType.COMPANY
    )
    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/companies/2/notes")


@pytest.mark.asyncio
async def test_get_notes_for_an_opportunity(mock_affinity_api):
    mock_response = {"data": [{"id": 1, "content": "abcd"}]}

    mock_affinity_api.get.return_value = mock_response

    result = await notes.get_notes_for_entity(
        entity_id=2, entity_type=EntityType.OPPORTUNITY
    )
    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/opportunities/2/notes")
