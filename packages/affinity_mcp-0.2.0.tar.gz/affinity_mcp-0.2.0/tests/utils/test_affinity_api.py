"""Tests for Affinity API client."""

import json
from unittest.mock import AsyncMock, Mock

import httpx
import pytest
import importlib.metadata

from affinity_mcp.context import TransportMode, api_key_var, transport_mode
from affinity_mcp.utils.affinity_api import AffinityAPI, APP_NAME, AffinityAPIError


@pytest.fixture(autouse=True)
def _set_stdio_mode():
    """Set stdio transport mode for all tests by default."""
    token = transport_mode.set(TransportMode.STDIO)
    yield
    transport_mode.reset(token)


class TestAffinityAPI:
    def test_api_key_resolves_from_settings_in_stdio_mode(self):
        client = AffinityAPI()
        assert client._get_api_key() == "test_api_key"

    def test_api_key_resolves_from_contextvar_in_http_mode(self):
        mode_token = transport_mode.set(TransportMode.HTTP)
        key_token = api_key_var.set("request-level-key")
        try:
            client = AffinityAPI()
            assert client._get_api_key() == "request-level-key"
        finally:
            api_key_var.reset(key_token)
            transport_mode.reset(mode_token)

    def test_api_key_raises_in_stdio_mode_without_key(self, mocker):
        mocker.patch(
            "affinity_mcp.utils.affinity_api.settings",
            mocker.Mock(api_key=None, api_url="https://api.affinity.co"),
        )
        client = AffinityAPI()
        with pytest.raises(ValueError, match="AFFINITY_API_KEY is missing"):
            _ = client._get_api_key()

    def test_api_key_raises_in_http_mode_without_key(self):
        mode_token = transport_mode.set(TransportMode.HTTP)
        try:
            client = AffinityAPI()
            with pytest.raises(AffinityAPIError) as exc_info:
                _ = client._get_api_key()
            assert exc_info.value.status_code == 401
        finally:
            transport_mode.reset(mode_token)

    def test_api_key_raises_for_unsupported_transport_mode(self):
        mode_token = transport_mode.set("unsupported")
        try:
            client = AffinityAPI()
            with pytest.raises(ValueError, match="Unsupported transport mode"):
                _ = client._get_api_key()
        finally:
            transport_mode.reset(mode_token)

    def test_init_creates_http_client(self):
        api_client = AffinityAPI()
        assert isinstance(api_client._client, httpx.AsyncClient)
        assert api_client._client._base_url == httpx.URL("https://api.affinity.co/")
        assert api_client._client._timeout.read == 30.0

    def test_headers_property(self):
        api_client = AffinityAPI()
        headers = api_client._base_headers
        version = importlib.metadata.version(APP_NAME)

        expected_headers = {
            "Accept": "application/json",
            "User-Agent": f"{APP_NAME}/{version}",
            "X-Client-Id": APP_NAME,
            "X-Client-Version": version,
        }
        assert expected_headers == headers

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        api_client = AffinityAPI()
        async with api_client as client:
            assert client is api_client

    @pytest.mark.asyncio
    async def test_aclose_called_on_exit(self, mocker):
        api_client = AffinityAPI()
        mock_aclose = mocker.patch.object(api_client, "aclose", new_callable=AsyncMock)
        async with api_client:
            pass

        mock_aclose.assert_called_once()

    @pytest.mark.asyncio
    async def test_request_sends_auth_header(self, mocker):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = {}

        mock_request = mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        await api_client.get("/v2/persons")

        mock_request.assert_called_once_with(
            "GET",
            "/v2/persons",
            headers={"Authorization": "Bearer test_api_key"},
            params=None,
        )

    def test_handle_response_raises_affinity_api_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = True
        mock_response.status_code = 500
        mock_response.text = "Internal server error"
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "500 Internal Server Error", request=Mock(), response=mock_response
        )

        with pytest.raises(AffinityAPIError) as exc_info:
            api_client._handle_response("GET", "/v2/persons", mock_response)

        assert exc_info.value.status_code == 500
        assert str(exc_info.value) == "Internal server error"

    def test_handle_response_return_enhanced_403_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = True
        mock_response.status_code = 403
        mock_response.text = "User does not have access to this feature"
        mock_response.request = Mock()
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "403 Forbidden", request=Mock(), response=mock_response
        )

        with pytest.raises(AffinityAPIError) as exc_info:
            api_client._handle_response("GET", "/v2/persons/1", mock_response)

        error_message = "User does not have access to this feature. Please contact your Affinity Admin for help gaining access."
        assert exc_info.value.status_code == 403
        assert str(exc_info.value) == error_message

    def test_handle_response_returns_none_for_status_code_204(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 204
        mock_response.text = None

        result = api_client._handle_response("GET", "/get-endpoint", mock_response)

        assert result is None

    def test_handle_response_returns_json_on_success(self):
        api_client = AffinityAPI()
        expected_data = {"id": 123, "name": "Test"}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        result = api_client._handle_response("GET", "/v2/persons", mock_response)

        assert result == expected_data
        mock_response.json.assert_called_once()

    def test_handle_response_raises_json_decode_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.text = "Invalid JSON"
        mock_response.json = lambda: json.loads(mock_response.text)

        with pytest.raises(json.JSONDecodeError):
            api_client._handle_response("GET", "/v2/persons", mock_response)

    @pytest.mark.asyncio
    @pytest.mark.parametrize("method", ["get", "post"])
    async def test_network_timeout_raises_request_error(self, mocker, method):
        api_client = AffinityAPI()
        mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            side_effect=httpx.TimeoutException("Request timed out"),
        )
        with pytest.raises(httpx.TimeoutException):
            await getattr(api_client, method)("/v2/persons")

    @pytest.mark.asyncio
    @pytest.mark.parametrize("method", ["get", "post"])
    async def test_connection_error_raises_request_error(self, mocker, method):
        api_client = AffinityAPI()
        mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            side_effect=httpx.ConnectError("Connection failed"),
        )
        with pytest.raises(httpx.ConnectError):
            await getattr(api_client, method)("/v2/persons")

    @pytest.mark.asyncio
    @pytest.mark.parametrize("method", ["get", "post"])
    async def test_raises_json_decode_error(self, mocker, method):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.text = "Invalid JSON"
        mock_response.json = lambda: json.loads(mock_response.text)

        mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )

        with pytest.raises(json.JSONDecodeError):
            await getattr(api_client, method)("/v2/persons")

    @pytest.mark.asyncio
    async def test_successful_get_request_returns_data(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"id": 123, "name": "Test Person"}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.get("/v2/persons/123")

        assert result == expected_data
        mock_response.json.assert_called_once()

    @pytest.mark.asyncio
    async def test_successful_get_request_returns_none(self, mocker):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 204
        mock_response.json.return_value = None

        mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.get("/get-endpoint")

        assert result is None

    @pytest.mark.asyncio
    async def test_successful_get_request_with_query_params(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"results": []}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mock_request = mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.get(
            "/v2/persons", params={"page_size": 10, "cursor": "abc"}
        )

        assert result == expected_data
        mock_request.assert_called_once_with(
            "GET",
            "/v2/persons",
            headers={"Authorization": "Bearer test_api_key"},
            params={"page_size": 10, "cursor": "abc"},
        )

    @pytest.mark.asyncio
    async def test_successful_post_request_returns_data(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"id": 123}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.post("/post-endpoint")

        assert result == expected_data
        mock_response.json.assert_called_once()

    @pytest.mark.asyncio
    async def test_successful_post_request_returns_none(self, mocker):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 204

        mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.post("/post-endpoint")

        assert result is None

    @pytest.mark.asyncio
    async def test_successful_post_request_with_body(self, mocker):
        api_client = AffinityAPI()
        expected_data = {
            "id": 123,
            "creator_id": 1,
            "person_ids": [2],
            "content": "this is a note",
            "type": 2,
        }
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mock_request = mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        body = {
            "creator_id": 1,
            "person_ids": [2],
            "content": "this is a note",
            "type": 2,
        }
        result = await api_client.post("/notes", body=body)

        assert result == expected_data
        mock_request.assert_called_once_with(
            "POST",
            "/notes",
            headers={"Authorization": "Bearer test_api_key"},
            json=body,
        )

    @pytest.mark.asyncio
    async def test_successful_put_request_with_body(self, mocker):
        api_client = AffinityAPI()
        expected_data = {
            "id": 20406836,
            "field_id": 1284,
            "value": "Updated value",
        }
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mock_request = mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        body = {"value": "Updated value"}
        result = await api_client.put("/field-values/20406836", body=body)

        assert result == expected_data
        mock_request.assert_called_once_with(
            "PUT",
            "/field-values/20406836",
            headers={"Authorization": "Bearer test_api_key"},
            json=body,
        )

    @pytest.mark.asyncio
    async def test_successful_patch_request_with_body(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"operation": "update-fields"}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mock_request = mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        body = {
            "operation": "update-fields",
            "updates": [
                {
                    "id": "field-1",
                    "value": {"type": "text", "data": "New text"},
                }
            ],
        }
        result = await api_client.patch(
            "/v2/lists/123/list-entries/456/fields", body=body
        )

        assert result == expected_data
        mock_request.assert_called_once_with(
            "PATCH",
            "/v2/lists/123/list-entries/456/fields",
            headers={"Authorization": "Bearer test_api_key"},
            json=body,
        )

    @pytest.mark.asyncio
    async def test_successful_delete_request(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"success": "true"}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mock_request = mocker.patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock,
            return_value=mock_response,
        )

        result = await api_client.delete("/field-values/123")

        assert result == expected_data
        mock_request.assert_called_once_with(
            "DELETE",
            "/field-values/123",
            headers={"Authorization": "Bearer test_api_key"},
            params=None,
        )

    def test_parse_error_message_from_api_v2_format_single_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {
            "errors": [{"message": "Malformed field", "code": "VALIDATION_ERROR"}]
        }

        result = api_client._parse_error_message(mock_response)

        assert result == "Malformed field"

    def test_parse_error_message_from_api_v2_format_multiple_errors(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {
            "errors": [
                {"message": "Malformed field", "code": "VALIDATION_ERROR"},
                {"message": "Missing required field", "code": "VALIDATION_ERROR"},
            ]
        }

        result = api_client._parse_error_message(mock_response)

        assert result == "Malformed field; Missing required field"

    def test_parse_error_message_from_api_v2_format_error_without_message(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {"errors": [{"code": "UNKNOWN_ERROR"}]}

        result = api_client._parse_error_message(mock_response)

        assert result == "{'code': 'UNKNOWN_ERROR'}"

    def test_parse_error_message_from_api_v1_format_single_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = ["Invalid API key"]

        result = api_client._parse_error_message(mock_response)

        assert result == "Invalid API key"

    def test_parse_error_message_from_api_v1_format_multiple_errors(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = [
            "Invalid API key",
            "Missing required field",
        ]

        result = api_client._parse_error_message(mock_response)

        assert result == "Invalid API key; Missing required field"

    def test_parse_error_message_unknown_format(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {"error": "Something went wrong"}
        mock_response.text = "Something went wrong"

        result = api_client._parse_error_message(mock_response)

        assert result == "Something went wrong"

    def test_parse_error_message_json_decode_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.side_effect = json.JSONDecodeError("error", "doc", 0)
        mock_response.text = "Internal Server Error"

        result = api_client._parse_error_message(mock_response)

        assert result == "Internal Server Error"

    def test_parse_error_message_empty_v2_errors_list(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {"errors": []}

        result = api_client._parse_error_message(mock_response)

        assert result == ""

    def test_parse_error_message_empty_v1_errors_list(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = []

        result = api_client._parse_error_message(mock_response)

        assert result == ""
