"""Tests for settings module."""

import pytest
from pydantic import ValidationError

from affinity_mcp.settings import Settings


def test_missing_api_url_uses_default_value(monkeypatch, tmp_path):
    monkeypatch.delenv("AFFINITY_API_URL", raising=False)
    monkeypatch.setenv("AFFINITY_API_KEY", "test_key")
    monkeypatch.chdir(tmp_path)

    settings = Settings()

    assert str(settings.api_url) == "https://api.affinity.co/"


def test_api_key_empty_string_field(monkeypatch):
    monkeypatch.setenv("AFFINITY_API_KEY", "")

    settings = Settings()

    assert settings.api_key.get_secret_value() == ""


def test_load_from_env_file(tmp_path, monkeypatch):
    monkeypatch.delenv("AFFINITY_API_KEY", raising=False)
    monkeypatch.delenv("AFFINITY_API_URL", raising=False)

    settings = Settings()

    assert settings.api_key.get_secret_value() == "test_api_key"
    assert str(settings.api_url) == "https://api.affinity.co/"


def test_load_from_env_var(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AFFINITY_API_KEY", "env_api_key")
    monkeypatch.setenv("AFFINITY_API_URL", "https://test-url.com")

    settings = Settings()

    assert settings.api_key.get_secret_value() == "env_api_key"
    assert str(settings.api_url) == "https://test-url.com/"


def test_some_env_var_overrides_env_file(tmp_path, monkeypatch):
    monkeypatch.setenv("AFFINITY_API_KEY", "env_api_key")

    settings = Settings()

    assert settings.api_key.get_secret_value() == "env_api_key"
    assert str(settings.api_url) == "https://api.affinity.co/"


def test_all_env_vars_override_env_file(tmp_path, monkeypatch):
    monkeypatch.setenv("AFFINITY_API_KEY", "env_api_key")
    monkeypatch.setenv("AFFINITY_API_URL", "https://test-url.com")

    settings = Settings()

    assert settings.api_key.get_secret_value() == "env_api_key"
    assert str(settings.api_url) == "https://test-url.com/"


def test_extra_fields_ignored(monkeypatch):
    monkeypatch.setenv("AFFINITY_API_URL", "https://api.affinity.co")
    monkeypatch.setenv("AFFINITY_EXTRA_FIELD", "should_be_ignored")

    settings = Settings()

    assert hasattr(settings, "api_key")
    assert hasattr(settings, "api_url")
    assert not hasattr(settings, "extra_field")


def test_api_url_invalid_scheme_raises_validation_error(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AFFINITY_API_KEY", "test_key")
    monkeypatch.setenv("AFFINITY_API_URL", "http://api.affinity.co")

    with pytest.raises(ValidationError) as exc_info:
        Settings()

    error_message = str(exc_info.value)
    assert "AFFINITY_API_URL scheme must be https" in error_message


def test_api_url_missing_scheme_raises_validation_error(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AFFINITY_API_KEY", "test_key")
    monkeypatch.setenv("AFFINITY_API_URL", "api.affinity.co")

    with pytest.raises(ValidationError) as exc_info:
        Settings()

    error_message = str(exc_info.value)
    assert "Input should be a valid URL, relative URL without a base" in error_message


def test_api_url_with_path_raises_validation_error(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AFFINITY_API_KEY", "test_key")
    monkeypatch.setenv("AFFINITY_API_URL", "https://api.affinity.co/v2")

    with pytest.raises(ValidationError) as exc_info:
        Settings()

    error_message = str(exc_info.value)
    assert "AFFINITY_API_URL must not contain a path" in error_message


def test_api_url_valid_url_with_trailing_slash(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AFFINITY_API_KEY", "test_key")
    monkeypatch.setenv("AFFINITY_API_URL", "https://api.affinity.co/")

    settings = Settings()

    assert str(settings.api_url) == "https://api.affinity.co/"
