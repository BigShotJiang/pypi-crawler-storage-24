---
name: Bug report
about: Report a bug or unexpected behavior
title: ''
labels: bug
assignees: ''

---

**Description**
Provide a clear and concise description of the bug.

**If applicable, which MCP tool is affected?**
e.g., search_companies, get_notes, create_note, etc.

**To Reproduce**
Steps to reproduce the behavior:
1. Call tool '...'
2. Pass parameters '...'
3. See error

**Expected Behavior**
Describe what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain the problem.

**Environment:**
 - **Affinity MCP Server Version**: [e.g., 0.1.0]
 - **MCP Client**: [e.g., Claude Desktop, Claude CLI, VSCode Copilot]
 - **OS**: [e.g., macOS 15.1, Windows 11, Ubuntu 24.04]

**Additional Context**
Add any other context about the problem here.

**Confirmations**
- [ ] I have searched existing issues and did not find a duplicate
- [ ] I have tested this with the latest version of affinity-mcp
