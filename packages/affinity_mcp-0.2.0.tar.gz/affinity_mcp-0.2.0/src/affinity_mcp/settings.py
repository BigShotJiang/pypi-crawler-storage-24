"""Application settings and configuration management."""

import os

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, SecretStr, HttpUrl, field_validator


class Settings(BaseSettings):
    """Application settings from environment variables and env file.

    Settings are loaded from the env file specified by ENV_FILE (default: .env).
    Environment variables override env file values.

    Attributes:
        api_key: The Affinity API key, stored securely as a SecretStr.
            Optional — required for stdio transport, not needed for HTTP transport.
        api_url: The Affinity API URL (defaults to https://api.affinity.co)
    """

    model_config = SettingsConfigDict(
        env_prefix="affinity_",
        env_file=os.getenv("ENV_FILE", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )
    api_key: SecretStr | None = Field(default=None)
    api_url: HttpUrl = Field(default=HttpUrl("https://api.affinity.co"))

    @field_validator("api_url", mode="after")
    @classmethod
    def validate_api_url_field(cls, url: HttpUrl) -> HttpUrl:
        """Validates the provided Affinity API URL."""

        if str(url.scheme) != "https":
            raise ValueError("AFFINITY_API_URL scheme must be https")

        if url.path and url.path != "/":
            raise ValueError("AFFINITY_API_URL must not contain a path")

        return url


settings = Settings()
