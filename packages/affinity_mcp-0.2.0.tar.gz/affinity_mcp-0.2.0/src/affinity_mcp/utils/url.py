from ..settings import settings
from .auth import fetch_current_user


async def construct_tenant_url() -> str:
    """Construct the tenant-specific URL by replacing 'api.' with the user's subdomain.

    Returns:
        Tenant URL without trailing slash.
    """
    user_info = await fetch_current_user()
    subdomain = user_info["tenant"]["subdomain"]

    api_url = str(settings.api_url)
    tenant_url = api_url.replace("api.", f"{subdomain}.")
    return tenant_url.strip("/")
