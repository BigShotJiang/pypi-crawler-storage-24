from typing import Any

from .affinity_api import AffinityAPI


async def fetch_current_user() -> dict[str, Any]:
    """Fetch current user information.

    Returns:
        Current user information including tenant details and API permissions.
    """
    async with AffinityAPI() as client:
        return await client.get("/v2/auth/whoami")
