from typing import Any, TypedDict


class DateFiltersApiV1(TypedDict, total=False):
    """Filter parameters for date-based searches in External API V1."""

    min_first_email_date: str
    max_first_email_date: str
    min_last_email_date: str
    max_last_email_date: str
    min_last_interaction_date: str
    max_last_interaction_date: str
    min_last_event_date: str
    max_last_event_date: str
    min_first_event_date: str
    max_first_event_date: str
    min_next_event_date: str
    max_next_event_date: str


def clean_date_filters(
    date_filters: DateFiltersApiV1,
) -> dict[str, Any]:
    """Clean date filters by removing None values."""
    return {k: v for k, v in date_filters.items() if v is not None}
