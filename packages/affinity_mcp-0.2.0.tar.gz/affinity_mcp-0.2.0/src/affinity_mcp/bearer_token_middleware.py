from starlette.requests import Request
from starlette.types import ASGIApp, Receive, Scope, Send

from .context import api_key_var


class BearerTokenMiddleware:
    """Extracts an Affinity API key from the ``Authorization: Bearer <key>``
    header and stores it in ``api_key_var`` for the duration of the request."""

    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            request = Request(scope)
            key = ""
            auth = request.headers.get("authorization", "")
            if auth.lower().startswith("bearer "):
                key = auth[7:].strip()
            key_token = api_key_var.set(key) if key else None
            try:
                await self.app(scope, receive, send)
            finally:
                if key_token:
                    api_key_var.reset(key_token)
            return

        await self.app(scope, receive, send)
