from typing import Any

from ..utils.auth import fetch_current_user


async def get_current_user() -> dict[str, Any]:
    """Get information about the current user. Use this tool to
    verify authentication and understand available API access levels.

    Returns:
        Information about the user, their current organization, and
        API key permissions.
    """
    return await fetch_current_user()
