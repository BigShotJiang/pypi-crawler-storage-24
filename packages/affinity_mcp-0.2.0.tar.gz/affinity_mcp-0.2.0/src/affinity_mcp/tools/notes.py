from typing import Any
from ..utils.affinity_api import AffinityAPI
from ..utils.url import construct_tenant_url
from ..types import EntityType


async def create_note(
    content: str,
    person_ids: list[int] | None = None,
    company_ids: list[int] | None = None,
    opportunity_ids: list[int] | None = None,
) -> dict[str, Any]:
    """Creates a new HTML note with the supplied parameters.

    REQUIRED:
      - content: The note content (cannot be empty)
      - At least one of: person_ids, organization_ids, or opportunity_id

    Args:
        person_ids: List of person IDs
        company_ids: List of company IDs
        opportunity_ids: List of opportunity IDs
        content (str): HTML content of the note. Common formatting options:
          - <strong> for bold, <em> for italic, <u> for underline
          - <ul><li> for bullet lists, <ol><li> for numbered lists
          - <blockquote> for block quotes
          - <hr> for dividers

    Returns:
        dict[str, Any]: API response containing the created note information
    """
    body = {
        k: v
        for k, v in {
            "content": content,
            "person_ids": person_ids,
            "organization_ids": company_ids,
            "opportunity_ids": opportunity_ids,
            # Use HTML as it's the standard format for text notes going forward
            "type": 2,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        response = await client.post("/notes", body)

    tenant_url = await construct_tenant_url()
    response["note_url"] = f"{tenant_url}/notes/{response['id']}"
    return response


async def get_notes(
    filter_expr: str | None = None,
    cursor: str | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    """Find notes in Affinity. Filter by ID, creator, and/or creation date.

    Args:
        filter_expr: Filter expression using Affinity query language. Available fields:
            - id: unique identifier for the note (operators: =)
              Example: "id=123" or "(id=1 | id=2 | id=10)"
            - creator.id: Person ID that created the note (operators: =)
              Example: "creator.id=456"
            - createdAt: When the note was created in Affinity (operators: >, <, >=, <=)
              Format: ISO 8601 timestamp
              Example: "createdAt>=2026-01-01T00:00:00Z"

            Complex examples:
            - Date range: "createdAt>=2026-01-01T00:00:00Z & createdAt<2026-02-01T00:00:00Z"
            - By creator in date range: "creator.id=123 & createdAt>=2026-01-01T00:00:00Z"

            Boolean logic: & (AND), | (OR), () for grouping
            Full filtering spec: https://developer.affinity.co/pages/external-api-v2/filtering

        cursor: Cursor for the next or previous page.
        limit: Number of items to include in the page. Default is 20, max is 100.
            When you need more than 100 records, use the cursor to paginate over the results.

    Returns:
        Structured data containing the list of notes and pagination information.
    """
    params = {
        k: v
        for k, v in {
            "filter": filter_expr,
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        return await client.get("/v2/notes", params=params)


async def get_entities_attached_to_note(
    note_id: int,
    entity_type: EntityType,
) -> dict[str, Any]:
    """Find entities attached to a note. Allows to retrieve details of a note, or a list of
    entities that are directly attached to a note.

    Args:
        note_id: The note ID that will be used in the search
        entity_type: Type of entities to retrieve. Options: "company", "person", "opportunity".
    """
    async with AffinityAPI() as client:
        return await client.get(
            f"/v2/notes/{note_id}/attached-{entity_type.to_plural()}"
        )


async def get_notes_for_entity(
    entity_id: int,
    entity_type: EntityType,
) -> dict[str, Any]:
    """Get all notes attached to a specific company, person, or opportunity.
    For the reverse (finding entities attached to a note), use get_entities_attached_to_note.

    Args:
        entity_id: The ID of the company, person, or opportunity
        entity_type: What type of entity this ID refers to. Options: "company", "person", "opportunity"

    Example: To get notes for company ID 123, use entity_id=123, entity_type="company"
    """
    async with AffinityAPI() as client:
        return await client.get(f"/v2/{entity_type.to_plural()}/{entity_id}/notes")
