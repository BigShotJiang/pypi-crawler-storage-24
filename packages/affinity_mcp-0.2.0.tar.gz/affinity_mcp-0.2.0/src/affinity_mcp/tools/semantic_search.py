from typing import Any
from ..utils.affinity_api import AffinityAPI
from ..types import EntityType


async def semantic_search(
    prompt: str,
    limit: int = 10,
    entity_type: EntityType = EntityType.COMPANY,
) -> dict[str, Any]:
    """
    Finds companies matching a natural language description about business context, characteristics,
    or relationship data. If looking up a company by keyword or domain, use search_companies instead.

    SEARCHABLE ATTRIBUTES:
      - Industry/sector: "healthcare", "fintech", "climate tech", "enterprise SaaS", "biotech", "AI"
          Example: "climate tech companies in our pipeline"
      - Technology/business concepts: "solar energy", "battery storage", "payment processing", "gene therapy"
          Example: "biotech companies working on extracellular vesicles"
      - Funding information: stage, funding date, amount raised, year founded
          Example: "Series A companies that raised more than $10M"
      - Employee metrics: headcount, hiring/departure rates
          Example: "companies with more than 100 employees"
      - Interaction history: search by when your firm met with or emailed companies
          Example: "companies we emailed recently"
      - Relationship strength: firm-wide relationship scores
          Example: "companies where we have strong connections"
      - Time references: "last week", "recently", "this quarter", "in the past 6 months", "90 days"
          Example: "companies our firm met with in the past 90 days"
      - Headquarters location: cities, states, countries, regions
          Example: "fintech startups in San Francisco"
      - Investor information: VC/PE firm names
          Example: "companies backed by Sequoia Capital"

    SORTING:
      - Results can be ordered by a single sortable attribute. Cannot sort by multiple attributes.
      (ex. cannot sort by both total funding and last funding)
      - Sorting works with or without semantic descriptors:
          Without descriptors: "Find Series B companies with the most funding"
            → matches on investment stage and applies sorting for funding
          With descriptors: "Find Series B cancer diagnosis healthtech companies with the most funding"
            → optimizes for both semantic relevance and the desired sort order
      - Formulas and computed sorts are NOT supported (ex., "last funding / total funding")

    GOTCHAS:
      - "I", "we", and "our firm" all refer to FIRM-WIDE data. Semantic search does not support personal/individual
        interaction filtering. "Companies I met with last week" means "companies any member of my firm met with last week."
      - "In our pipeline" and "in our network" filter to org-relevant companies (companies your firm has interacted
        with or added to Affinity). They do NOT search for membership in a specific list named "Pipeline" or similar.
      - Interaction and relationship data is always firm-wide. You cannot search by a specific team member's
        individual relationship or interaction history.

    NOT SUPPORTED:
      - Third-party enrichment data such as Crunchbase, PitchBook, Dealroom
      - Company valuation and revenue metrics
      - Specific list membership: "companies in my Series A pipeline list"
      - Lookup by similarity to a named company: "companies like OpenAI"
      - Notes, email body content, or file attachments
      - Custom fields you've created

    Args:
        prompt: Natural language description of the companies to find. Must be between 1 and 500 characters.
        limit: Number of companies to return. Default is 10. Minimum is 1, maximum is 100.
        entity_type: The type of entity to search for. Currently only supports "company".

    Returns:
        A list of entities that match the prompt with an explanation of the search. Results prioritize
        org-relevant companies (companies your firm knows) but also search the universal database.
    """
    body = {
        "prompt": prompt,
        "limit": limit,
        "entityType": entity_type.to_plural(),
    }

    async with AffinityAPI() as client:
        return await client.post("/v2/semantic-search", body=body)
