from typing import Any

from ..utils.affinity_api import AffinityAPI


async def get_relationship_strengths(
    external_person_id: int, internal_person_id: int | None = None
) -> dict[str, Any]:
    """Gets relationship strengths between an external person and internal team members.
    Optionally filter to a specific internal person.

    IMPORTANT: When the user uses first-person language (ex. 'my relationship', 'how do I know', etc.),
    you MUST call get_current_user first to obtain the internal_person_id.

    Args:
        external_person_id: ID of the external person to get relationship strengths for
        internal_person_id: Optional ID to filter results to a specific internal person

    Returns:
        A list of relationship strength records, each containing external_id, internal_id,
        and strength represented as a float between 0-1. You MUST convert the strength to
        a percentage between 0 and 100, rounded to the nearest integer (values of .5 or
        greater round up, values less than .5 round down)
    """
    params = {
        k: v
        for k, v in {
            "internal_id": internal_person_id,
            "external_id": external_person_id,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        response = await client.get("/relationships-strengths", params=params)
        return {"data": response}
