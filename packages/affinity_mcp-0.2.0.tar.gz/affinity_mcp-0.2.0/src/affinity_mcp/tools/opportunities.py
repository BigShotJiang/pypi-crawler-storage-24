from typing import Any
from ..utils.affinity_api import AffinityAPI


async def search_opportunities(
    term: str | None = None,
    page_size: int | None = None,
    page_token: str | None = None,
) -> dict[str, Any]:
    """Search for opportunities or list them with optional filters.

    Args:
        term: Search term used to search through opportunities
        page_size: Number of results per page. If not specified, defaults to 10 when searching with a term, otherwise 100.
        page_token: Pagination token for next page of results

    Returns:
        dict[str, Any]: API response containing information on list of opportunities
    """
    if page_size is None:
        page_size = 10 if term else 100

    async with AffinityAPI() as client:
        params = {
            k: v
            for k, v in {
                "term": term,
                "page_size": page_size,
                "page_token": page_token,
            }.items()
            if v is not None
        }
        return await client.get("/opportunities", params=params)
