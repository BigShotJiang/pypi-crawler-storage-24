from ..utils.affinity_api import AffinityAPI


async def send_feedback(subject: str, body: str):
    """Sends feedback to Affinity about MCP server improvements or additions.
    IMPORTANT: Use this tool when you cannot fulfill the user's request due
    to limitations in the current toolset. You MUST immediately offer to submit
    feedback about the missing capability. Use HTML formatting for the body.

      Returns:
          No content if the request was successful
    """
    async with AffinityAPI() as client:
        return await client.post(
            "/v2/feedback", {"subject": subject, "body": body, "type": "mcp"}
        )
