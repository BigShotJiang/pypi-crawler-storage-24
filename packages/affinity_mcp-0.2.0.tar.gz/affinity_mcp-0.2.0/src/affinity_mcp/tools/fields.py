from typing import Any, Literal

from ..types import EntityType
from ..utils.affinity_api import AffinityAPI


async def get_entity_fields(
    entity_type: Literal[EntityType.COMPANY, EntityType.PERSON],
    cursor: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """Returns metadata on non-list specific company or person fields.

    Args:
        entity_type: Type of entity to return fields for. Options: "company", "person"
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 100.

    Returns:
        Field metadata
    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get(f"/v2/{entity_type.to_plural()}/fields", params=params)


async def get_list_fields(
    list_id: int, cursor: str | None = None, limit: int = 100
) -> dict[str, Any]:
    """Returns metadata on fields available for a given list.

    Args:
        list_id: ID of list to return fields for.
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 100.

    Returns:
        Field metadata
    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get(f"/v2/lists/{list_id}/fields", params=params)


async def get_list_field_dropdown_options(
    list_id: int, field_id: str, cursor: str | None = None, limit: int = 20
) -> dict[str, Any]:
    """Returns the dropdown options for a specific dropdown or ranked-dropdown field on a list.
    Use the returned dropdown option IDs when writing dropdown field values via upsert_list_entry_field_values
    and upsert_entity_field_value (ranked-dropdown only).

    Args:
        list_id: ID of list
        field_id: human-readable string ID of field to return options for (ex. "field-123")
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 20, maximum is 100.

    Returns:
        Metadata about each dropdown option
    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get(
            f"/v2/lists/{list_id}/fields/{field_id}/dropdown-options", params=params
        )
