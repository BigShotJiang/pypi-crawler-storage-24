"""
insurance-spatial: BYM2 spatial territory ratemaking and conformal prediction for UK personal lines.

Provides adjacency construction, BYM2 model fitting via PyMC, spatial diagnostics,
and territory relativity extraction - all in a pipeline designed to slot into an
existing GLM or GBM pricing workflow.

Also provides spatially weighted conformal prediction intervals via the
`insurance_spatial.conformal` sub-package:

    from insurance_spatial.conformal import SpatialConformalPredictor
"""

from insurance_spatial.adjacency import AdjacencyMatrix, build_grid_adjacency
from insurance_spatial.models import BYM2Model, BYM2Result
from insurance_spatial.diagnostics import MoranI, convergence_summary
from insurance_spatial.relativities import extract_relativities

__all__ = [
    "AdjacencyMatrix",
    "build_grid_adjacency",
    "BYM2Model",
    "BYM2Result",
    "MoranI",
    "convergence_summary",
    "extract_relativities",
    "conformal",
    "__version__",
]

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("insurance-spatial")
except PackageNotFoundError:
    __version__ = "0.0.0"  # not installed


def __getattr__(name: str):
    if name == "conformal":
        from insurance_spatial import conformal as _conformal
        return _conformal
    raise AttributeError(f"module 'insurance_spatial' has no attribute {name!r}")
