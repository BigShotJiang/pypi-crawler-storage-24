"""
AutoPromptLab SDK - Public API for prompt optimization.

This module provides a simplified interface for business users to run
prompt optimization workflows programmatically.

Two main use cases:
1. Start a new optimization experiment
2. Resume from a checkpoint
"""

from prompt_auto_lab.sdk.result import OptimizationResult
from prompt_auto_lab.sdk.config import AutoPromptLabConfig
from prompt_auto_lab.sdk.lab import AutoPromptLab, LabStatus, optimize_prompt

__all__ = [
    "AutoPromptLab",
    "AutoPromptLabConfig",
    "OptimizationResult",
    "LabStatus",
    "optimize_prompt",
]
