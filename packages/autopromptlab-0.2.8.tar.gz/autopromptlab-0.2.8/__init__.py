"""
AutoPromptLab - Multi-agent prompt optimization framework.

This package provides tools for automated prompt optimization using
multi-agent systems and evaluation feedback loops.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# SDK public API - always available
from prompt_auto_lab.sdk import (
    AutoPromptLab,
    AutoPromptLabConfig,
    OptimizationResult,
    LabStatus,
    optimize_prompt,
)

# Version
__version__ = "0.1.0"

# Lazy imports for core components (only loaded when accessed)
# This prevents import errors if internal dependencies are missing
def __getattr__(name: str):
    """Lazy import for advanced components."""
    if name == "Orchestrator":
        from prompt_auto_lab.orchestrator.orchestrator import Orchestrator
        return Orchestrator
    elif name == "SharedState":
        from prompt_auto_lab.orchestrator.state_store import SharedState
        return SharedState
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# Type hints for IDE support
if TYPE_CHECKING:
    from prompt_auto_lab.orchestrator.orchestrator import Orchestrator
    from prompt_auto_lab.orchestrator.state_store import SharedState

__all__ = [
    # SDK API
    "AutoPromptLab",
    "AutoPromptLabConfig", 
    "OptimizationResult",
    "LabStatus",
    "optimize_prompt",
    # Core components (lazy loaded)
    "Orchestrator",
    "SharedState",
    # Metadata
    "__version__",
]
