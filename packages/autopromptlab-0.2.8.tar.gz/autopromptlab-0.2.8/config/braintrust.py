from __future__ import annotations

# Braintrust org endpoint mappings.
BRAINTRUST_ORG_ENDPOINTS = {
    "bt-azure": "https://prod-msft-api-endpoint-eackahcmezgzaybz.a03.azurefd.net",
    "non-pme": "https://api.braintrust.dev",
}

