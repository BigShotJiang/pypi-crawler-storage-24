from prompt_auto_lab.api.main import app

__all__ = ["app"]
