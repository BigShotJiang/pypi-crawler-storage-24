from __future__ import annotations

from pathlib import Path
from typing import Awaitable, Callable

from prompt_auto_lab.core.picasso_workspace import (
    SPARSE_CHECKOUT_PATHS,
    copy_picasso_repo as core_copy_picasso_repo,
    delete_picasso_repo as core_delete_picasso_repo,
    resolve_working_picasso_path as core_resolve_working_picasso_path,
    get_session_picasso_path as core_get_session_picasso_path,
    get_session_picasso_root as core_get_session_picasso_root,
)

ProgressCallback = Callable[[int, int, str], Awaitable[None]]


def get_session_picasso_root() -> Path:
    """Get root directory used for per-session Picasso clones."""
    return core_get_session_picasso_root()


async def copy_picasso_repo(
    dest_path: Path,
    branch: str = "main",
    progress_callback: ProgressCallback | None = None,
) -> None:
    """Shallow clone Picasso repo to destination with sparse checkout."""
    await core_copy_picasso_repo(
        dest_path=dest_path,
        branch=branch,
        progress_callback=progress_callback,
    )


def delete_picasso_repo(repo_path: Path) -> None:
    """Delete a Picasso repo copy."""
    core_delete_picasso_repo(repo_path)


def get_session_picasso_path(user_id: str, session_id: str) -> Path:
    """Get the Picasso repo path for a session."""
    return core_get_session_picasso_path(user_id, session_id)


def resolve_working_picasso_path(
    *,
    user_id: str | None = None,
    session_id: str,
) -> Path:
    """Resolve the effective Picasso working repo path using shared core logic."""
    return core_resolve_working_picasso_path(
        user_id=user_id,
        session_id=session_id,
    )
