---
title: Format `pyproject.toml`
footer: false
---

### Description

Auto-formats `pyproject.toml` with [pyproject-fmt](https://github.com/tox-dev/pyproject-fmt). See the [`format-pyproject` job documentation](https://github.com/kdeldycke/repomatic?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.
