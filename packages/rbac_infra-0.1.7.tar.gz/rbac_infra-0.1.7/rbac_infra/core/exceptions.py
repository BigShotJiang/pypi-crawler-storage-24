class AccessDenied(Exception):
    pass