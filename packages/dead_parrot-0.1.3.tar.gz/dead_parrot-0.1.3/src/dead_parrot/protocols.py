"""Protocols."""

from typing import Literal, Protocol, TypedDict


class MetricResult(TypedDict):
    """TypedDict for the result of a metric's scoring."""

    score: float
    rationale: str | None


class Metric(Protocol):
    """Protocol for a metric."""

    def score(
        self,
        question: str,
        example_answer: str,
        prediction_answer: str,
    ) -> MetricResult:
        """Score the predicted answer given the question and example answer."""
        ...


class AiAssistant(Protocol):
    """Protocol for an AI assistant."""

    @property
    def name(self) -> str:
        """Return the name of the AI assistant."""
        ...

    def ask(self, question: str) -> str:
        """Answer the question using the RAG pipeline."""
        ...

    def evaluate(self, use_testset: bool = False) -> float:
        """Evaluate the RAG pipeline based on the devset or testset."""
        ...

    def optimize(self) -> None:
        """Optimize the RAG pipeline based on the trainset."""
        ...


class AiAssistantClass(Protocol):
    """Protocol for the instantiation of an AI assistant."""

    def __call__(
        self,
        name: str,
        task_model: str,
        teacher_model: str,
        embedding_model: str,
        corpus: list[str],
        examples: list[tuple[str, str]],
        metric: Metric,
        optimization_effort: Literal["light", "medium", "heavy"] = "light",
    ) -> AiAssistant:
        """Instantiate the AI assistant."""
        ...
