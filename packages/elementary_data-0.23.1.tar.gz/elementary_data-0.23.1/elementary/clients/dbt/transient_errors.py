"""Per-adapter transient error patterns for automatic retry.

Each adapter may produce transient errors that are safe to retry.  This
module centralises those patterns so that the runner can decide whether a
failed dbt command should be retried transparently.

To add patterns for a new adapter, append a new entry to
``_ADAPTER_PATTERNS`` with the **adapter type** as key (e.g.
``"bigquery"``, ``"snowflake"``) and a tuple of **plain, lowercase**
substrings that appear in the error output.  Matching is
case-insensitive substring search so regex is not needed.

The ``adapter_type`` argument accepted by :func:`is_transient_error`
should be the dbt **adapter type** (e.g. ``"bigquery"``, ``"snowflake"``),
as resolved from ``profiles.yml``.  When the value does not match any
known adapter key (or is ``None``), **all** adapter patterns are checked
defensively so that transient errors are never missed.
"""

from typing import Dict, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Per-adapter transient error substrings (all lowercase).
#
# A command failure is considered *transient* when the dbt output
# (stdout + stderr, lowercased) contains **any** of the substrings
# listed for the active adapter **or** in the ``_COMMON`` list.
# ---------------------------------------------------------------------------

_COMMON: Tuple[str, ...] = (
    # Generic connection / HTTP errors that any adapter can surface.
    "connection reset by peer",
    "connection was closed",
    "remotedisconnected",
    "connectionerror",
    "brokenpipeerror",
    "connection aborted",
    "read timed out",
)

_DATABRICKS_PATTERNS: Tuple[str, ...] = (
    "temporarily_unavailable",
    "504 gateway timeout",
    "502 bad gateway",
    "service unavailable",
)

_TSQL_TRANSIENT: Tuple[str, ...] = (
    "connection timed out",
    "could not connect to the server",
    "ssl syscall error",
    "communication link failure",
    "tcp provider: an existing connection was forcibly closed",
    "login timeout expired",
)

_ADAPTER_PATTERNS: Dict[str, Tuple[str, ...]] = {
    "bigquery": (
        # Streaming-buffer delay after a streaming insert.
        "streaming data from",
        "is temporarily unavailable",
        # Generic transient backend error (500).
        "retrying may solve the problem",
        "backenderror",
        # Rate-limit / quota errors.
        "exceeded rate limits",
        "rateLimitExceeded".lower(),
        "quota exceeded",
        # Duplicate job ID (409 conflict) — seen with dbt-fusion + xdist.
        "error 409",
        # Internal errors surfaced as 503 / "internal error".
        "internal error encountered",
        "503 service unavailable",
        "http 503",
    ),
    "snowflake": (
        "could not connect to snowflake backend",
        "authentication token has expired",
        "incident id:",
        "service is unavailable",
    ),
    "redshift": (
        "connection timed out",
        "could not connect to the server",
        "ssl syscall error",
    ),
    "databricks": _DATABRICKS_PATTERNS,
    "athena": (
        "throttlingexception",
        "toomanyrequestsexception",
        "service unavailable",
    ),
    "dremio": (
        # Common patterns (remotedisconnected, connection was closed) already
        # cover the most frequent Dremio transient errors.  Add Dremio-specific
        # patterns here as they are identified.
    ),
    "postgres": (
        "could not connect to server",
        "connection timed out",
        "server closed the connection unexpectedly",
        "ssl syscall error",
    ),
    "trino": (
        "service unavailable",
        "server returned http response code: 503",
    ),
    "clickhouse": (
        "connection timed out",
        "broken pipe",
    ),
    "spark": (
        "thrift transport is closed",
        "could not connect to any thrift server",
        "connection refused",
    ),
    "duckdb": (
        # DuckDB runs in-process; transient errors are rare.
        # Common patterns (connection reset, broken pipe) are in _COMMON.
    ),
    "fabricspark": (
        "502 bad gateway",
        "503 service unavailable",
        "connection timed out",
    ),
    "fabric": _TSQL_TRANSIENT,
    "sqlserver": _TSQL_TRANSIENT,
    "vertica": (
        "connection timed out",
        "could not connect to the server",
        "ssl syscall error",
    ),
}

# Pre-computed union of all adapter-specific patterns for the fallback path
# when adapter_type is unknown.  Built once at import time.
_ALL_ADAPTER_PATTERNS: Tuple[str, ...] = tuple(
    pattern for patterns in _ADAPTER_PATTERNS.values() for pattern in patterns
)


def is_transient_error(
    adapter_type: Optional[str],
    output: Optional[str] = None,
    stderr: Optional[str] = None,
) -> bool:
    """Return ``True`` if *output*/*stderr* contain a known transient error.

    Parameters
    ----------
    adapter_type:
        The dbt adapter type (e.g. ``"bigquery"``, ``"snowflake"``),
        typically resolved from ``profiles.yml`` by the runner.
        When the value matches a key in ``_ADAPTER_PATTERNS``, only that
        adapter's patterns (plus ``_COMMON``) are used.  When it does
        **not** match any known adapter (or is ``None``), **all** adapter
        patterns are checked defensively to avoid missing transient errors.
    output:
        The captured stdout of the dbt command (may be ``None``).
    stderr:
        The captured stderr of the dbt command (may be ``None``).
    """
    haystack = _build_haystack(output, stderr)
    if not haystack:
        return False

    if isinstance(adapter_type, str):
        adapter_patterns = _ADAPTER_PATTERNS.get(adapter_type.lower())
        if adapter_patterns is not None:
            # Known adapter — use common + adapter-specific patterns.
            patterns: Sequence[str] = (*_COMMON, *adapter_patterns)
        else:
            # Unknown adapter type. Check all adapters defensively.
            patterns = (*_COMMON, *_ALL_ADAPTER_PATTERNS)
    else:
        # No adapter type provided; check all adapters defensively.
        patterns = (*_COMMON, *_ALL_ADAPTER_PATTERNS)

    return any(pattern in haystack for pattern in patterns)


def _build_haystack(output: Optional[str] = None, stderr: Optional[str] = None) -> str:
    """Concatenate and lowercase *output* + *stderr* for matching."""
    parts = []
    if output and isinstance(output, str):
        parts.append(output)
    if stderr and isinstance(stderr, str):
        parts.append(stderr)
    return "\n".join(parts).lower()
