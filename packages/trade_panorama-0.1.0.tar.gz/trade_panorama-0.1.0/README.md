# trade-panorama

Unified PnL dashboard across multiple trading bots.

Different bots store trades in different JSON formats. trade-panorama scans your directory tree, auto-detects known bot data files, normalizes everything into a unified model, and shows a single summary table.

## Install

```bash
pip install trade-panorama
```

## Usage

```bash
# Scan current directory
trade-panorama

# Scan a specific directory
trade-panorama -d /path/to/trading/bots

# JSON output (for piping to other tools)
trade-panorama --json

# Filter by bot name
trade-panorama -b crypto -b stock
```

## Example Output

```
=== Trade Panorama ===

Bot                 Trades      WR       PnL%   Open      Capital
-----------------------------------------------------------------
Crypto (MEXC)            3     67%     +8.50%      0
Stock Bot                5     60%     +3.20%      2 $5200 (+$200)
Integrated Bot           2     50%     -1.00%      1 $950 (-$50)
HF Bot                 100     48%    -12.30%      0
-----------------------------------------------------------------
TOTAL                  110     51%     -1.60%      3
```

## Supported Bots

| Bot | Data File | Detected Fields |
|-----|-----------|-----------------|
| Crypto (MEXC) | `pnl.json` | BUY/SELL pairs → round-trip PnL |
| Stock Bot | `stock_paper_trades.json` | closed/open positions, capital |
| Integrated Bot | `paper_trades.json` | closed/open positions, capital |
| HF Bot | `hf_evolution_state.json` | Population variants, all trades |

## Adding a New Bot Parser

1. Create `src/trade_panorama/parsers/your_bot.py`
2. Implement a function that takes a `dict` (parsed JSON) and returns a `BotSummary`
3. Register it in `parsers/__init__.py` with the filename as key

## License

MIT
