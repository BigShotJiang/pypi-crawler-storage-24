"""Unified data model for cross-bot trade aggregation."""


class UnifiedTrade:
    """A single trade normalized from any bot's JSON format."""

    def __init__(self, bot, asset, direction, entry_price, exit_price,
                 pnl_pct, entry_time, exit_time, strategy=""):
        self.bot = bot
        self.asset = asset
        self.direction = direction
        self.entry_price = entry_price
        self.exit_price = exit_price
        self.pnl_pct = pnl_pct
        self.entry_time = entry_time
        self.exit_time = exit_time
        self.strategy = strategy

    def to_dict(self):
        return {
            "bot": self.bot,
            "asset": self.asset,
            "direction": self.direction,
            "entry_price": self.entry_price,
            "exit_price": self.exit_price,
            "pnl_pct": self.pnl_pct,
            "entry_time": self.entry_time,
            "exit_time": self.exit_time,
            "strategy": self.strategy,
        }


class OpenPosition:
    """An open (unclosed) position."""

    def __init__(self, bot, asset, direction, entry_price, entry_time,
                 size_usd=0, strategy=""):
        self.bot = bot
        self.asset = asset
        self.direction = direction
        self.entry_price = entry_price
        self.entry_time = entry_time
        self.size_usd = size_usd
        self.strategy = strategy

    def to_dict(self):
        return {
            "bot": self.bot,
            "asset": self.asset,
            "direction": self.direction,
            "entry_price": self.entry_price,
            "entry_time": self.entry_time,
            "size_usd": self.size_usd,
            "strategy": self.strategy,
        }


class BotSummary:
    """Aggregated stats for one bot."""

    def __init__(self, name, trades=None, open_positions=None,
                 capital=0, initial_capital=0):
        self.name = name
        self.trades = trades or []
        self.open_positions = open_positions or []
        self.capital = capital
        self.initial_capital = initial_capital

    @property
    def total_trades(self):
        return len(self.trades)

    @property
    def wins(self):
        return sum(1 for t in self.trades if t.pnl_pct > 0)

    @property
    def win_rate(self):
        if not self.trades:
            return 0.0
        return self.wins / len(self.trades)

    @property
    def total_pnl_pct(self):
        return sum(t.pnl_pct for t in self.trades)

    @property
    def capital_pnl(self):
        if self.initial_capital > 0:
            return self.capital - self.initial_capital
        return 0.0

    def to_dict(self):
        return {
            "name": self.name,
            "total_trades": self.total_trades,
            "wins": self.wins,
            "win_rate": self.win_rate,
            "total_pnl_pct": self.total_pnl_pct,
            "open_positions": len(self.open_positions),
            "capital": self.capital,
            "initial_capital": self.initial_capital,
            "capital_pnl": self.capital_pnl,
        }
