"""trade-panorama — Unified PnL dashboard across multiple trading bots."""
__version__ = "0.1.0"
