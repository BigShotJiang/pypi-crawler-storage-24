"""Parser for Integrated Bot (paper_trades.json)."""
from ..model import UnifiedTrade, OpenPosition, BotSummary


def parse_integrated_bot(data):
    """Parse integrated bot paper trades.

    Schema: {capital, initial_capital, open_positions: [{asset, direction,
             entry_price, entry_time, size_usd, ...}],
             closed_positions: [{asset, direction, entry_price, exit_price,
             pnl_pct, ...}]}
    """
    trades = []
    for t in data.get("closed_positions", []):
        trades.append(UnifiedTrade(
            bot="Integrated Bot",
            asset=t.get("asset", ""),
            direction=t.get("direction", ""),
            entry_price=t.get("entry_price", 0),
            exit_price=t.get("exit_price", 0),
            pnl_pct=t.get("pnl_pct", 0),
            entry_time=t.get("entry_time", ""),
            exit_time=t.get("exit_time", ""),
            strategy=t.get("strategy", ""),
        ))

    open_pos = []
    for p in data.get("open_positions", []):
        open_pos.append(OpenPosition(
            bot="Integrated Bot",
            asset=p.get("asset", ""),
            direction=p.get("direction", ""),
            entry_price=p.get("entry_price", 0),
            entry_time=p.get("entry_time", ""),
            size_usd=p.get("size_usd", 0),
            strategy=p.get("strategy", ""),
        ))

    return BotSummary(
        name="Integrated Bot",
        trades=trades,
        open_positions=open_pos,
        capital=data.get("capital", 0),
        initial_capital=data.get("initial_capital", 0),
    )
