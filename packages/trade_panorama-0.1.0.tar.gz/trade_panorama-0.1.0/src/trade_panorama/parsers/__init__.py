"""Bot-specific JSON parsers. Each parser normalizes data into UnifiedTrade format."""
from .hf_bot import parse_hf_bot
from .integrated_bot import parse_integrated_bot
from .stock_bot import parse_stock_bot
from .crypto import parse_crypto_pnl

PARSERS = {
    "hf_evolution_state.json": parse_hf_bot,
    "paper_trades.json": parse_integrated_bot,
    "stock_paper_trades.json": parse_stock_bot,
    "pnl.json": parse_crypto_pnl,
}
