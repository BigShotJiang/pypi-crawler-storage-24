"""Parser for HF Evolution Engine (hf_evolution_state.json)."""
from ..model import UnifiedTrade, OpenPosition, BotSummary


def parse_hf_bot(data):
    """Parse HF evolution state into BotSummary.

    Schema: {population: [{id, strategy_type, trades: [{asset, direction,
             entry_price, exit_price, pnl_pct, entry_time, exit_time}]}]}
    """
    trades = []
    for variant in data.get("population", []):
        strategy = variant.get("strategy_type", "") + ":" + variant.get("id", "")
        for t in variant.get("trades", []):
            trades.append(UnifiedTrade(
                bot="HF Bot",
                asset=t.get("asset", ""),
                direction=t.get("direction", ""),
                entry_price=t.get("entry_price", 0),
                exit_price=t.get("exit_price", 0),
                pnl_pct=t.get("pnl_pct", 0),
                entry_time=t.get("entry_time", ""),
                exit_time=t.get("exit_time", ""),
                strategy=strategy,
            ))

    return BotSummary(name="HF Bot", trades=trades)
