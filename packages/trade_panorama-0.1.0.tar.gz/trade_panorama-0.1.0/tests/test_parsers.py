"""Tests for trade_panorama.parsers."""
import unittest
from trade_panorama.parsers.crypto import parse_crypto_pnl
from trade_panorama.parsers.integrated_bot import parse_integrated_bot
from trade_panorama.parsers.stock_bot import parse_stock_bot
from trade_panorama.parsers.hf_bot import parse_hf_bot


class TestCryptoParser(unittest.TestCase):
    def test_basic_pair(self):
        data = {"trades": [
            {"side": "BUY", "price": "100", "qty": "1", "time": "2026-01-01"},
            {"side": "SELL", "price": "110", "qty": "1", "time": "2026-01-02"},
        ]}
        s = parse_crypto_pnl(data)
        self.assertEqual(s.name, "Crypto (MEXC)")
        self.assertEqual(s.total_trades, 1)
        self.assertAlmostEqual(s.trades[0].pnl_pct, 10.0)

    def test_empty(self):
        s = parse_crypto_pnl({"trades": []})
        self.assertEqual(s.total_trades, 0)

    def test_no_trades_key(self):
        s = parse_crypto_pnl({})
        self.assertEqual(s.total_trades, 0)

    def test_multiple_pairs(self):
        data = {"trades": [
            {"side": "BUY", "price": "200", "qty": "1", "time": ""},
            {"side": "BUY", "price": "300", "qty": "1", "time": ""},
            {"side": "SELL", "price": "220", "qty": "1", "time": ""},
            {"side": "SELL", "price": "280", "qty": "1", "time": ""},
        ]}
        s = parse_crypto_pnl(data)
        self.assertEqual(s.total_trades, 2)


class TestIntegratedBotParser(unittest.TestCase):
    def test_full(self):
        data = {
            "capital": 900,
            "initial_capital": 1000,
            "closed_positions": [
                {"asset": "BTC", "direction": "LONG", "entry_price": 100,
                 "exit_price": 95, "pnl_pct": -5, "entry_time": "",
                 "exit_time": "", "strategy": "mean_rev"},
            ],
            "open_positions": [
                {"asset": "ETH", "direction": "LONG", "entry_price": 50,
                 "entry_time": "2026-01-01", "size_usd": 200, "strategy": "trend"},
            ],
        }
        s = parse_integrated_bot(data)
        self.assertEqual(s.name, "Integrated Bot")
        self.assertEqual(s.total_trades, 1)
        self.assertEqual(len(s.open_positions), 1)
        self.assertEqual(s.capital, 900)
        self.assertAlmostEqual(s.capital_pnl, -100)

    def test_empty(self):
        s = parse_integrated_bot({})
        self.assertEqual(s.total_trades, 0)
        self.assertEqual(len(s.open_positions), 0)


class TestStockBotParser(unittest.TestCase):
    def test_uses_symbol(self):
        data = {
            "capital": 5000,
            "initial_capital": 5000,
            "closed_positions": [
                {"symbol": "AAPL", "direction": "LONG", "entry_price": 150,
                 "exit_price": 160, "pnl_pct": 6.67, "entry_time": "",
                 "exit_time": "", "strategy": "breakout"},
            ],
            "open_positions": [],
        }
        s = parse_stock_bot(data)
        self.assertEqual(s.name, "Stock Bot")
        self.assertEqual(s.trades[0].asset, "AAPL")


class TestHfBotParser(unittest.TestCase):
    def test_population(self):
        data = {"population": [
            {
                "id": "V001",
                "strategy_type": "momentum",
                "trades": [
                    {"asset": "BTC", "direction": "LONG", "entry_price": 100,
                     "exit_price": 105, "pnl_pct": 5, "entry_time": "",
                     "exit_time": ""},
                    {"asset": "ETH", "direction": "SHORT", "entry_price": 50,
                     "exit_price": 48, "pnl_pct": 4, "entry_time": "",
                     "exit_time": ""},
                ],
            },
            {
                "id": "V002",
                "strategy_type": "range",
                "trades": [
                    {"asset": "BTC", "direction": "SHORT", "entry_price": 100,
                     "exit_price": 102, "pnl_pct": -2, "entry_time": "",
                     "exit_time": ""},
                ],
            },
        ]}
        s = parse_hf_bot(data)
        self.assertEqual(s.name, "HF Bot")
        self.assertEqual(s.total_trades, 3)
        self.assertEqual(s.wins, 2)
        self.assertEqual(s.trades[0].strategy, "momentum:V001")

    def test_empty_population(self):
        s = parse_hf_bot({"population": []})
        self.assertEqual(s.total_trades, 0)


if __name__ == "__main__":
    unittest.main()
