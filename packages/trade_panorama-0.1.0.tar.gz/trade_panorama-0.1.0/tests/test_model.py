"""Tests for trade_panorama.model."""
import unittest
from trade_panorama.model import UnifiedTrade, OpenPosition, BotSummary


class TestUnifiedTrade(unittest.TestCase):
    def test_to_dict(self):
        t = UnifiedTrade("Bot", "BTC", "LONG", 100, 110, 10.0,
                         "2026-01-01", "2026-01-02", "momentum")
        d = t.to_dict()
        self.assertEqual(d["bot"], "Bot")
        self.assertEqual(d["asset"], "BTC")
        self.assertEqual(d["pnl_pct"], 10.0)
        self.assertEqual(d["strategy"], "momentum")

    def test_default_strategy(self):
        t = UnifiedTrade("Bot", "ETH", "SHORT", 50, 45, 10.0, "", "")
        self.assertEqual(t.strategy, "")


class TestOpenPosition(unittest.TestCase):
    def test_to_dict(self):
        p = OpenPosition("Bot", "AAPL", "LONG", 150.0, "2026-01-01",
                         size_usd=1000, strategy="breakout")
        d = p.to_dict()
        self.assertEqual(d["size_usd"], 1000)
        self.assertEqual(d["strategy"], "breakout")


class TestBotSummary(unittest.TestCase):
    def _make_trade(self, pnl):
        return UnifiedTrade("B", "X", "LONG", 100, 100 + pnl, pnl, "", "")

    def test_empty(self):
        s = BotSummary("Test")
        self.assertEqual(s.total_trades, 0)
        self.assertEqual(s.wins, 0)
        self.assertAlmostEqual(s.win_rate, 0.0)
        self.assertAlmostEqual(s.total_pnl_pct, 0.0)

    def test_win_rate(self):
        trades = [self._make_trade(5), self._make_trade(-2), self._make_trade(3)]
        s = BotSummary("Test", trades=trades)
        self.assertEqual(s.total_trades, 3)
        self.assertEqual(s.wins, 2)
        self.assertAlmostEqual(s.win_rate, 2 / 3)

    def test_total_pnl(self):
        trades = [self._make_trade(5), self._make_trade(-3)]
        s = BotSummary("Test", trades=trades)
        self.assertAlmostEqual(s.total_pnl_pct, 2.0)

    def test_capital_pnl(self):
        s = BotSummary("Test", capital=1200, initial_capital=1000)
        self.assertAlmostEqual(s.capital_pnl, 200)

    def test_capital_pnl_no_initial(self):
        s = BotSummary("Test", capital=500, initial_capital=0)
        self.assertAlmostEqual(s.capital_pnl, 0.0)

    def test_to_dict(self):
        trades = [self._make_trade(10)]
        pos = [OpenPosition("B", "Y", "SHORT", 50, "")]
        s = BotSummary("Test", trades=trades, open_positions=pos,
                       capital=1100, initial_capital=1000)
        d = s.to_dict()
        self.assertEqual(d["name"], "Test")
        self.assertEqual(d["total_trades"], 1)
        self.assertEqual(d["open_positions"], 1)
        self.assertEqual(d["capital_pnl"], 100)


if __name__ == "__main__":
    unittest.main()
