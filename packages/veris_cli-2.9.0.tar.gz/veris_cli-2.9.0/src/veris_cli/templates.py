"""Static file templates for veris init."""

DOCKERFILE_SANDBOX = """# Extends veris-gvisor base with your agent code
FROM us-central1-docker.pkg.dev/veris-ai-prod/veris-sandbox/veris-gvisor:latest

# ============================================================
# 1. AGENT CODE — Update paths to match your project structure
# ============================================================
# NOTE: Build context is project root, so paths are relative
# to project root (even though this Dockerfile is in .veris/)

COPY app /agent/app

# ============================================================
# 2. DEPENDENCIES — Uncomment ONE section below
# ============================================================
WORKDIR /agent

# ── uv (default) ──────────────────────────────────────────
COPY pyproject.toml /agent/
COPY README.md /agent/
# COPY uv.lock /agent/
RUN uv sync --no-dev

# ── pip ────────────────────────────────────────────────────
# COPY requirements.txt /agent/
# RUN pip install --no-cache-dir -r requirements.txt

# ── poetry ─────────────────────────────────────────────────
# COPY pyproject.toml poetry.lock /agent/
# RUN pip install poetry && poetry install --no-dev

# ============================================================
# 3. VERIS CONFIG
# ============================================================

COPY .veris/veris.yaml /config/veris.yaml

WORKDIR /app
"""

VERIS_YAML = """# Veris simulation configuration
version: "1.0"

# Uncomment the services your agent calls. dns_aliases should match the
# domains your agent makes requests to — they'll be routed to the mock automatically.
services:

  # - name: calendar
  #   dns_aliases:
  #     - www.googleapis.com
  #     - calendar.google.com
  #     - calendar-json.googleapis.com
  #     - googleapis.com
  #     - oauth2.googleapis.com

  # - name: crm
  #   dns_aliases:
  #     - login.salesforce.com
  #     - test.salesforce.com
  #     - your-domain.salesforce.com

  # - name: postgres
  #   config:
  #     SCHEMA_PATH: /agent/schemas/schema.sql

  # - name: mcp/stripe
  #   dns_aliases:
  #     - mcp.stripe.com

  # - name: mcp/shopify-storefront
  #   dns_aliases:
  #     - veris-ai.myshopify.com

  # - name: mcp/shopify-customer
  #   dns_aliases:
  #     - veris-ai.account.myshopify.com

  # - name: oracle

  # - name: atlassian/jira
  #   dns_aliases:
  #     - api.atlassian.com
  #     - your-instance.atlassian.net

  # - name: atlassian/confluence
  #   dns_aliases:
  #     - api.atlassian.com
  #     - your-instance.atlassian.net

  # - name: slack
  #   dns_aliases:
  #     - slack.com
  #     - api.slack.com

  # - name: zendesk-support
  #   dns_aliases:
  #     - your-subdomain.zendesk.com

  # - name: twilio
  #   dns_aliases:
  #     - api.twilio.com

  # - name: hogan
  #   dns_aliases:
  #     - api-gateway.wellsfargo.net

  # - name: microsoft/graph
  #   dns_aliases:
  #     - graph.microsoft.com

  # - name: microsoft/devops
  #   dns_aliases:
  #     - dev.azure.com
  #     - almsearch.dev.azure.com

  # - name: llm-proxy
  #   dns_aliases:
  #     - my-deployment.openai.azure.com

persona:
  modality:
    type: http                         # http | ws | email
    url: http://localhost:8008/chat
    # method: POST
    # headers:
    #   Content-Type: application/json
    # request:
    #   message_field: message
    #   session_field: session_id
    #   static_fields:
    #     prompt_type: default
    # response:
    #   type: json                     # json | sse
    #   message_field: response
    #   session_field: session_id
    #
    # SSE response parsing:
    # response:
    #   type: sse
    #   chunk_event: chunk
    #   chunk_field: chunk
    #   session_event: id
    #   session_field: conversation_id
    #   done_event: end_turn
    #
    # WebSocket:
    # type: ws
    # url: ws://localhost:8008/ws/chat
    #
    # Email:
    # type: email
    # email_address: agent@ea.veris.ai

  # config:
  #   RESPONSE_INTERVAL: "2"
  #   POLL_INTERVAL: "3"
  #   REFLECTION_INTERVAL: "5"

agent:
  code_path: /agent
  entry_point: uv run --no-sync uvicorn app.main:app --host 0.0.0.0 --port 8008
  port: 8008
  # environment:
    # DATABASE_URL: postgresql://postgres:postgres@localhost:5432/SIMULATION_ID
    # ORACLE_BASE_URL: http://localhost:6203
"""


DOCKERIGNORE = """\
# Veris build context — excluded from `veris env push` uploads
.git
.venv
__pycache__
node_modules
.env
.env.*
*.egg-info
dist
build
.mypy_cache
.pytest_cache
.ruff_cache
"""


def get_dockerignore() -> str:
    """Get .dockerignore template for .veris/ directory."""
    return DOCKERIGNORE.strip()


def get_dockerfile_sandbox() -> str:
    """Get Dockerfile.sandbox template."""
    return DOCKERFILE_SANDBOX.strip()


def get_veris_yaml() -> str:
    """Get veris.yaml template."""
    return VERIS_YAML.strip()
