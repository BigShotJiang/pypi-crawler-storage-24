# SentryML

**The security layer every LLM-powered app is missing.**  
Real-time prompt injection firewall — scan user input before it reaches your LLM.

## Install

```bash
pip install sentryml
```

## Quickstart (3 lines)

```python
import sentryml
sentryml.configure(api_key="your-key", api_url="https://sentryml-api-jihxilyyya-nw.a.run.app")
safe_prompt = sentryml.guard(user_message)  # raises ThreatBlockedError if attack detected
```

## Get an API key

Sign up free at https://nastwest-u26wck-618.web.app  
10,000 scans/month. No credit card.

## How it works

```text
User Input → sentryml.guard() → SentryML API → BLOCK/ALLOW → Your LLM
```

Detects 8 attack types using semantic similarity (`all-MiniLM-L6-v2`) with token-level explainability.

## Attack types detected

- prompt_injection, jailbreak, role_hijacking, data_exfiltration  
- indirect_injection, goal_hijacking, context_manipulation

## Full scan response

```python
result = sentryml.scan('your prompt', app_id='my-chatbot')
print(result.severity)            # critical / high / medium / low / safe
print(result.threat_score)        # 0.0 – 1.0
print(result.attack_type)         # prompt_injection / jailbreak / etc
print(result.recommended_action)  # block / flag / allow
print(result.latency_ms)          # scan latency
print(result.carbon_g_co2e)       # CO2e grams per scan
print(result.token_explanations)  # SHAP token attribution
print(result.threat_summary)      # Gemini-generated narrative
```

## Guard pattern (recommended)

```python
from sentryml.exceptions import ThreatBlockedError

def chat(user_message: str) -> str:
    try:
        safe_prompt = sentryml.guard(user_message)
    except ThreatBlockedError as e:
        return f'Blocked: {e.result.attack_type} ({e.result.threat_score:.0%})'
    return llm.complete(safe_prompt)
```

## Async support

```python
result = await sentryml.scan_async(user_message, app_id='my-app')
```

## Carbon tracking

Every scan returns `carbon_g_co2e`. Blocked attacks save CO2 by preventing unnecessary LLM calls.  
Track your AI security carbon footprint in the live dashboard.

## Live dashboard

https://nastwest-u26wck-618.web.app
