"""SentryML HTTP client with retries and error mapping."""

from typing import Optional
import httpx

from .models import ScanResult, TokenExplanation, Severity, RecommendedAction


class SentryMLError(Exception):
    """Raised when the SentryML API returns an error or is unreachable."""


class SentryMLClient:
    """Synchronous and asynchronous SentryML API client."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: str = "http://localhost:8000",
        retries: int = 3,
        timeout: float = 30.0,
    ):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.retries = retries
        self.timeout = timeout
        self._headers = {"Content-Type": "application/json"}
        if api_key:
            self._headers["X-API-Key"] = api_key

    def _parse_result(self, data: dict) -> ScanResult:
        token_explanations = [
            TokenExplanation(
                token=t["token"],
                shap_value=t["shap_value"],
                position=t["position"],
            )
            for t in data.get("token_explanations", [])
        ]
        return ScanResult(
            scan_id=data["scan_id"],
            timestamp=data["timestamp"],
            is_threat=data["is_threat"],
            threat_score=data["threat_score"],
            severity=Severity(data["severity"]),
            attack_type=data["attack_type"],
            attack_type_scores=data.get("attack_type_scores", {}),
            token_explanations=token_explanations,
            threat_summary=data.get("threat_summary"),
            recommended_action=RecommendedAction(data["recommended_action"]),
            latency_ms=data["latency_ms"],
            model_version=data["model_version"],
            carbon_g_co2e=data.get("carbon_g_co2e", 0.0),
            app_id=data.get("app_id"),
            prompt=data.get("prompt"),
        )

    def scan(self, prompt: str, app_id: Optional[str] = None) -> ScanResult:
        """Scan a prompt synchronously. Retries on 5xx errors."""
        payload: dict = {"prompt": prompt}
        if app_id:
            payload["app_id"] = app_id

        last_error: Optional[Exception] = None
        with httpx.Client(timeout=self.timeout) as client:
            for attempt in range(self.retries):
                try:
                    res = client.post(
                        f"{self.api_url}/v1/scan",
                        json=payload,
                        headers=self._headers,
                    )
                    res.raise_for_status()
                    return self._parse_result(res.json())
                except httpx.HTTPStatusError as e:
                    last_error = e
                    if e.response.status_code < 500:
                        raise SentryMLError(
                            f"API error {e.response.status_code}: {e.response.text}"
                        ) from e
                except httpx.RequestError as e:
                    last_error = e

        raise SentryMLError(f"Request failed after {self.retries} attempts: {last_error}") from last_error

    async def scan_async(self, prompt: str, app_id: Optional[str] = None) -> ScanResult:
        """Scan a prompt asynchronously. Retries on 5xx errors."""
        payload: dict = {"prompt": prompt}
        if app_id:
            payload["app_id"] = app_id

        last_error: Optional[Exception] = None
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            for attempt in range(self.retries):
                try:
                    res = await client.post(
                        f"{self.api_url}/v1/scan",
                        json=payload,
                        headers=self._headers,
                    )
                    res.raise_for_status()
                    return self._parse_result(res.json())
                except httpx.HTTPStatusError as e:
                    last_error = e
                    if e.response.status_code < 500:
                        raise SentryMLError(
                            f"API error {e.response.status_code}: {e.response.text}"
                        ) from e
                except httpx.RequestError as e:
                    last_error = e

        raise SentryMLError(f"Request failed after {self.retries} attempts: {last_error}") from last_error

    def guard(
        self,
        prompt: str,
        app_id: Optional[str] = None,
        raise_on_threat: bool = True,
    ) -> ScanResult:
        """Scan and raise SentryMLError if the prompt is blocked."""
        result = self.scan(prompt, app_id)
        if raise_on_threat and result.recommended_action == RecommendedAction.BLOCK:
            raise SentryMLError(
                f"Prompt blocked: {result.attack_type} (score: {result.threat_score:.0%})"
            )
        return result
