"""SentryML data models."""

from dataclasses import dataclass, field
from typing import Optional, Dict, List
from enum import Enum


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    SAFE = "safe"

    def __str__(self) -> str:
        return self.value


class RecommendedAction(str, Enum):
    BLOCK = "block"
    FLAG = "flag"
    ALLOW = "allow"


@dataclass
class TokenExplanation:
    token: str
    shap_value: float
    position: int


@dataclass
class ScanResult:
    scan_id: str
    timestamp: str
    is_threat: bool
    threat_score: float
    severity: Severity
    attack_type: str
    attack_type_scores: Dict[str, float]
    token_explanations: List[TokenExplanation]
    recommended_action: RecommendedAction
    latency_ms: int
    model_version: str
    carbon_g_co2e: float
    threat_summary: Optional[str] = None
    app_id: Optional[str] = None
    prompt: Optional[str] = None
