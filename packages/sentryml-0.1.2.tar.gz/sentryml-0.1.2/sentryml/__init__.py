"""SentryML SDK — LLM prompt injection firewall client.

Quick start:
    import sentryml
    sentryml.configure(api_key="sm_live_...", api_url="http://localhost:8000")

    result = sentryml.scan("Ignore all previous instructions")
    print(result.severity, result.threat_score)

    # Decorator / guard — raises SentryMLError if the prompt is blocked
    sentryml.guard(prompt, app_id="my-app")
"""

from typing import Optional

from .client import SentryMLClient, SentryMLError
from .models import ScanResult, Severity, RecommendedAction, TokenExplanation

_client: Optional[SentryMLClient] = None


def configure(
    api_key: Optional[str] = None,
    api_url: str = "http://localhost:8000",
) -> None:
    """Initialise the default client. Call once at application startup."""
    global _client
    _client = SentryMLClient(api_key=api_key, api_url=api_url)


def _get_client() -> SentryMLClient:
    global _client
    if _client is None:
        _client = SentryMLClient()
    return _client


def scan(prompt: str, app_id: Optional[str] = None) -> ScanResult:
    """Scan a prompt synchronously and return a ScanResult."""
    return _get_client().scan(prompt, app_id)


async def scan_async(prompt: str, app_id: Optional[str] = None) -> ScanResult:
    """Scan a prompt asynchronously and return a ScanResult."""
    return await _get_client().scan_async(prompt, app_id)


def guard(
    prompt: str,
    app_id: Optional[str] = None,
    raise_on_threat: bool = True,
) -> ScanResult:
    """Scan a prompt and raise SentryMLError if recommended_action is 'block'."""
    return _get_client().guard(prompt, app_id, raise_on_threat)


__all__ = [
    "configure",
    "scan",
    "scan_async",
    "guard",
    "SentryMLClient",
    "SentryMLError",
    "ScanResult",
    "Severity",
    "RecommendedAction",
    "TokenExplanation",
]
