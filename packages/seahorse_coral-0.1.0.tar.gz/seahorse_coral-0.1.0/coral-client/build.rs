use std::io::Result;

fn main() -> Result<()> {
    println!("cargo:rerun-if-changed=../coral/proto");

    tonic_prost_build::configure()
        .build_client(true)
        .build_server(false)
        .bytes(".")
        // Older protoc releases require this flag to accept proto3 optional fields.
        .protoc_arg("--experimental_allow_proto3_optional")
        .compile_protos(
            &[
                "../coral/proto/coral/common/v1/common.proto",
                "../coral/proto/coral/catalog/v1/catalog.proto",
                "../coral/proto/coral/storage/v1/storage.proto",
                "../coral/proto/coral/health/v1/health.proto",
                "../coral/proto/coral/node/v1/node.proto",
                "../coral/proto/coral/sql/v1/sql.proto",
                "../coral/proto/coral/ingest/v1/ingest.proto",
                "../coral/proto/coral/query/v1/query.proto",
                "../coral/proto/coral/export/v1/export.proto",
                "../coral/proto/coral/segment/v1/segment.proto",
                "../coral/proto/coral/table/v1/table.proto",
                "../coral/proto/coral/log/v1/log.proto",
                "../coral/proto/coral/utility/v1/utility.proto",
            ],
            &["../coral/proto"],
        )?;

    Ok(())
}
