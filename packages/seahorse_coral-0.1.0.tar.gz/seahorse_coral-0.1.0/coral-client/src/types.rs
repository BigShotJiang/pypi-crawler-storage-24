use std::time::{Duration, SystemTime};

use arrow_schema::SchemaRef;
use coral_models::api::schema::{Column, ExternalIndex, ExternalSegmentation, TableConfigurations};
use coral_models::catalog::{
    CacheEntryType, CacheEntryValue, IndexInfoElement, NodeInfo, SegmentationInfo,
};
use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
pub struct NodeRecord {
    pub node_id: String,
    pub node_info: NodeInfo,
}

#[derive(Debug, Clone, Serialize)]
pub struct TableView {
    pub table_name: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub configurations: Option<TableConfigurations>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub external: Option<ExternalTableView>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub internal: Option<InternalTableView>,
}

#[derive(Debug, Clone, Serialize)]
pub struct ExternalTableView {
    pub columns: Vec<Column>,
    pub primary_key: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation: Option<ExternalSegmentation>,
    pub indexes: Vec<ExternalIndex>,
}

#[derive(Debug, Clone, Serialize)]
pub struct InternalTableView {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub schema: Option<SchemaRef>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation_info: Option<SegmentationInfo>,
    pub index_info: Vec<IndexInfoElement>,
}

#[derive(Debug, Clone, Serialize)]
pub struct ParquetSchemaInfo {
    pub columns: Vec<Column>,
    pub primary_key: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation: Option<ExternalSegmentation>,
    pub indexes: Vec<ExternalIndex>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub schema: Option<SchemaRef>,
}

#[derive(Debug, Clone, Serialize)]
pub struct CatalogCacheEntry {
    pub key: String,
    pub cache_type: CacheEntryType,
    pub created_at: SystemTime,
    pub ttl: Duration,
    pub invalidated: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub value: Option<CacheEntryValue>,
}

#[derive(Debug, Clone, Serialize)]
pub struct CatalogCacheDump {
    pub cache_entries: Vec<CatalogCacheEntry>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub next_cursor: Option<String>,
}
