use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use bytes::Bytes;
use coral_models::api::CreateStatusResponse;
use coral_models::api::cluster::{
    CacheConfigResponse, CacheDumpRequest, CacheInvalidateRequest, CacheInvalidateResponse,
    CacheRefreshResponse, CacheStatsResponse, CatalogStorageDumpResponse, RebalanceCommitRequest,
    RebalanceCommitResponse, RebalancePlanRequest, RebalancePlanResponse, RebalanceStatusResponse,
    SegmentsRetryRequest, SegmentsRetryResponse, SegmentsStatusResponse, StorageDumpQueryParams,
};
use coral_models::api::data::{
    DataDeleteRequest, DataExportDownloadQueryParams, DataExportRequest, DataExportResponse,
    DataInsertResult, DataScanRequest, DataUpdateRequest, InsertQueryParams, ScanQueryParams,
    SearchQueryParams,
};
use coral_models::api::diagnostics::{DataPlanRequest, DataPlanResponse};
use coral_models::api::node::{
    AllSyncErrorsResponse, NodePingResponse, NodeSyncErrorsResponse, VdbResourceUsageResponse,
};
use coral_models::api::schema::CreateTableRequest;
use coral_models::api::storage::{BatchInsertQueryParams, Paths};
use coral_models::api::table::{
    ActiveSetFlushRequest, ActiveSetFlushResponse, CreateTableResponse, DeleteTableResponse,
    TableIndexedCountResponse,
};
use coral_models::api::vector::{
    HybridVectorSearchRequest, VectorSearchExactKnnRequest, VectorSearchRequest,
};
use coral_models::{LogConfig, LogConfigUpdate, LogLevel, MultipleResults, SingleResult};
use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;
use tokio::io::{AsyncWrite, AsyncWriteExt};
use tokio::sync::mpsc;
use tonic::Request;
use tonic::codegen::tokio_stream;
use tonic::codegen::tokio_stream::StreamExt;
use tonic::transport::{Channel, Endpoint};

use crate::error::CoralClientError;
use crate::mapping;
use crate::proto::{
    catalog, common, export, health, ingest, log, node, query, segment, table, utility,
};
use crate::result_stream::QueryResultStream;
use crate::types::{CatalogCacheDump, NodeRecord, ParquetSchemaInfo, TableView};

const DEFAULT_ARROW_IPC_UPLOAD_CHUNK_SIZE_BYTES: usize = 256 * 1024;
const DEFAULT_ARROW_IPC_UPLOAD_BUFFERED_CHUNKS: usize = 8;

#[derive(Debug, Clone)]
pub struct CoralClient {
    base_url: String,
    grpc_channel: Arc<Mutex<Option<Channel>>>,
}

#[derive(Debug)]
pub struct ExportDownloadStream {
    filename: String,
    inner: tonic::Streaming<export::ExportDownloadEvent>,
}

impl ExportDownloadStream {
    pub fn filename(&self) -> &str {
        &self.filename
    }

    pub async fn next_chunk(&mut self) -> Result<Option<Bytes>, CoralClientError> {
        match self.inner.message().await? {
            Some(event) => match event.event.ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(
                    "export download stream event did not contain a payload".to_string(),
                )
            })? {
                export::export_download_event::Event::Chunk(chunk) => Ok(Some(chunk.chunk)),
                export::export_download_event::Event::Header(_) => {
                    Err(CoralClientError::InvalidGrpcResponse(
                        "export download stream contained multiple headers".to_string(),
                    ))
                }
            },
            None => Ok(None),
        }
    }

    /// Explicit full-materialization helper for callers that intentionally want
    /// the complete download buffered in memory.
    ///
    /// The canonical export download path is [`Self::write_all_to`] or
    /// repeated [`Self::next_chunk`] consumption.
    pub async fn collect(mut self) -> Result<Vec<u8>, CoralClientError> {
        let mut body = Vec::new();
        while let Some(chunk) = self.next_chunk().await? {
            body.extend_from_slice(&chunk);
        }
        Ok(body)
    }

    pub async fn write_all_to<W>(&mut self, writer: &mut W) -> Result<u64, CoralClientError>
    where
        W: AsyncWrite + Unpin,
    {
        let mut written = 0_u64;
        while let Some(chunk) = self.next_chunk().await? {
            writer.write_all(&chunk).await?;
            written = written.saturating_add(chunk.len() as u64);
        }
        writer.flush().await?;
        Ok(written)
    }
}

impl CoralClient {
    pub fn new(base_url: String) -> Self {
        Self {
            base_url,
            grpc_channel: Arc::new(Mutex::new(None)),
        }
    }

    fn grpc_channel(&self) -> Result<Channel, CoralClientError> {
        let mut cached_channel = self.grpc_channel.lock().map_err(|_| {
            CoralClientError::InvalidGrpcResponse("gRPC channel mutex poisoned".to_string())
        })?;

        if let Some(channel) = cached_channel.as_ref() {
            return Ok(channel.clone());
        }

        let endpoint = Endpoint::from_shared(self.grpc_base_url())?;
        let channel = endpoint.connect_lazy();
        *cached_channel = Some(channel.clone());

        Ok(channel)
    }

    fn grpc_base_url(&self) -> String {
        self.base_url.trim_end_matches('/').to_string()
    }

    fn catalog_admin_client(
        &self,
    ) -> Result<
        catalog::catalog_admin_service_client::CatalogAdminServiceClient<Channel>,
        CoralClientError,
    > {
        Ok(
            catalog::catalog_admin_service_client::CatalogAdminServiceClient::new(
                self.grpc_channel()?,
            ),
        )
    }

    fn health_client(
        &self,
    ) -> Result<health::health_service_client::HealthServiceClient<Channel>, CoralClientError> {
        Ok(health::health_service_client::HealthServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn ingest_client(
        &self,
    ) -> Result<ingest::ingest_service_client::IngestServiceClient<Channel>, CoralClientError> {
        Ok(ingest::ingest_service_client::IngestServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn log_client(
        &self,
    ) -> Result<log::log_service_client::LogServiceClient<Channel>, CoralClientError> {
        Ok(log::log_service_client::LogServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn node_client(
        &self,
    ) -> Result<node::node_service_client::NodeServiceClient<Channel>, CoralClientError> {
        Ok(node::node_service_client::NodeServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn query_client(
        &self,
    ) -> Result<query::query_service_client::QueryServiceClient<Channel>, CoralClientError> {
        Ok(query::query_service_client::QueryServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn segment_client(
        &self,
    ) -> Result<segment::segment_service_client::SegmentServiceClient<Channel>, CoralClientError>
    {
        Ok(segment::segment_service_client::SegmentServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn table_client(
        &self,
    ) -> Result<table::table_service_client::TableServiceClient<Channel>, CoralClientError> {
        Ok(table::table_service_client::TableServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn export_client(
        &self,
    ) -> Result<export::export_service_client::ExportServiceClient<Channel>, CoralClientError> {
        Ok(export::export_service_client::ExportServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    fn utility_client(
        &self,
    ) -> Result<utility::utility_service_client::UtilityServiceClient<Channel>, CoralClientError>
    {
        Ok(utility::utility_service_client::UtilityServiceClient::new(
            self.grpc_channel()?,
        ))
    }

    async fn get_tables_impl(&self, internal: bool) -> Result<Vec<TableView>, CoralClientError> {
        let request = table::ListTablesRequest {
            options: Some(mapping::default_table_query_options(internal)),
        };
        let response = self
            .table_client()?
            .list_tables(request)
            .await?
            .into_inner();
        mapping::map_list_tables_response(response)
    }

    async fn get_table_impl(
        &self,
        table_name: &str,
        internal: bool,
    ) -> Result<TableView, CoralClientError> {
        let request = table::GetTableRequest {
            table_name: table_name.to_string(),
            options: Some(mapping::default_table_query_options(internal)),
        };
        let response = self.table_client()?.get_table(request).await?.into_inner();
        mapping::map_get_table_response(response)
    }

    pub async fn health_check(&self) -> Result<String, CoralClientError> {
        let response = self
            .health_client()?
            .check(health::HealthCheckRequest {})
            .await?
            .into_inner();
        Ok(response.message)
    }

    pub async fn get_nodes(&self) -> Result<Vec<NodeRecord>, CoralClientError> {
        let response = self
            .node_client()?
            .list_nodes(node::ListNodesRequest {})
            .await?
            .into_inner();
        mapping::map_list_nodes_response(response)
    }

    pub async fn get_node(
        &self,
        node_name: &str,
    ) -> Result<coral_models::catalog::NodeInfo, CoralClientError> {
        let response = self
            .node_client()?
            .get_node(node::GetNodeRequest {
                node_name: node_name.to_string(),
            })
            .await?
            .into_inner();
        mapping::map_get_node_response(response)
    }

    pub async fn ping_node(&self, node_name: &str) -> Result<NodePingResponse, CoralClientError> {
        let response = self
            .node_client()?
            .ping_node(node::PingNodeRequest {
                node_name: node_name.to_string(),
            })
            .await?
            .into_inner();
        Ok(mapping::map_ping_node_response(response))
    }

    pub async fn get_vdb_resource_usage(
        &self,
    ) -> Result<VdbResourceUsageResponse, CoralClientError> {
        let response = self
            .node_client()?
            .get_vdb_resource_usage(node::GetVdbResourceUsageRequest {})
            .await?
            .into_inner();
        mapping::map_vdb_resource_usage_response(response)
    }

    pub async fn get_node_sync_errors(
        &self,
        node_id: &str,
    ) -> Result<NodeSyncErrorsResponse, CoralClientError> {
        let response = self
            .node_client()?
            .get_node_sync_errors(node::GetNodeSyncErrorsRequest {
                node_id: node_id.to_string(),
            })
            .await?
            .into_inner();
        mapping::map_node_sync_errors_response(response)
    }

    pub async fn get_all_sync_errors(&self) -> Result<AllSyncErrorsResponse, CoralClientError> {
        let response = self
            .node_client()?
            .get_all_sync_errors(common::Empty {})
            .await?
            .into_inner();
        mapping::map_all_sync_errors_response(response)
    }

    pub async fn get_catalog_storage_dump(
        &self,
        request: &StorageDumpQueryParams,
    ) -> Result<CatalogStorageDumpResponse, CoralClientError> {
        let response = self
            .catalog_admin_client()?
            .get_catalog_storage_dump(mapping::map_catalog_storage_dump_request(request))
            .await?
            .into_inner();
        Ok(mapping::map_catalog_storage_dump_response(response))
    }

    pub async fn get_catalog_cache_dump(
        &self,
        request: &CacheDumpRequest,
    ) -> Result<CatalogCacheDump, CoralClientError> {
        let response = self
            .catalog_admin_client()?
            .get_catalog_cache_dump(mapping::map_catalog_cache_dump_request(request))
            .await?
            .into_inner();
        mapping::map_catalog_cache_dump_response(response)
    }

    pub async fn get_catalog_cache_stats(&self) -> Result<CacheStatsResponse, CoralClientError> {
        let response = self
            .catalog_admin_client()?
            .get_catalog_cache_stats(common::Empty {})
            .await?
            .into_inner();
        Ok(mapping::map_catalog_cache_stats_response(response))
    }

    pub async fn get_catalog_cache_config(&self) -> Result<CacheConfigResponse, CoralClientError> {
        let response = self
            .catalog_admin_client()?
            .get_catalog_cache_config(common::Empty {})
            .await?
            .into_inner();
        Ok(mapping::map_catalog_cache_config_response(response))
    }

    pub async fn refresh_catalog_cache(&self) -> Result<CacheRefreshResponse, CoralClientError> {
        let response = self
            .catalog_admin_client()?
            .refresh_catalog_cache(common::Empty {})
            .await?
            .into_inner();
        Ok(mapping::map_refresh_catalog_cache_response(response))
    }

    pub async fn invalidate_catalog_cache(
        &self,
        request: &CacheInvalidateRequest,
    ) -> Result<CacheInvalidateResponse, CoralClientError> {
        let response = self
            .catalog_admin_client()?
            .invalidate_catalog_cache(mapping::map_invalidate_catalog_cache_request(request))
            .await?
            .into_inner();
        Ok(mapping::map_invalidate_catalog_cache_response(response))
    }

    pub async fn get_log_level(&self) -> Result<LogLevel, CoralClientError> {
        let response = self
            .log_client()?
            .get_log_level(common::Empty {})
            .await?
            .into_inner();
        Ok(mapping::map_log_level_from_proto(response))
    }

    pub async fn set_log_level(&self, level: &LogLevel) -> Result<LogLevel, CoralClientError> {
        let response = self
            .log_client()?
            .set_log_level(mapping::map_log_level_to_proto(level))
            .await?
            .into_inner();
        Ok(mapping::map_log_level_from_proto(response))
    }

    pub async fn get_log_config(&self) -> Result<LogConfig, CoralClientError> {
        let response = self
            .log_client()?
            .get_log_config(common::Empty {})
            .await?
            .into_inner();
        mapping::map_log_config_from_proto(response)
    }

    pub async fn update_log_config(
        &self,
        update: &LogConfigUpdate,
    ) -> Result<LogConfig, CoralClientError> {
        let response = self
            .log_client()?
            .update_log_config(mapping::map_log_config_update_to_proto(update))
            .await?
            .into_inner();
        mapping::map_log_config_from_proto(response)
    }

    pub async fn rotate_logs(&self) -> Result<(), CoralClientError> {
        self.log_client()?.rotate_logs(common::Empty {}).await?;
        Ok(())
    }

    pub async fn get_tables(&self) -> Result<Vec<TableView>, CoralClientError> {
        self.get_tables_impl(false).await
    }

    pub async fn get_tables_with_internal(
        &self,
        internal: bool,
    ) -> Result<Vec<TableView>, CoralClientError> {
        self.get_tables_impl(internal).await
    }

    pub async fn create_table(
        &self,
        request: &CreateTableRequest,
    ) -> Result<CreateTableResponse, CoralClientError> {
        let response = self
            .table_client()?
            .create_table(mapping::map_create_table_request(request)?)
            .await?
            .into_inner();
        mapping::map_create_table_response(response)
    }

    pub async fn delete_table(
        &self,
        table_name: &str,
    ) -> Result<DeleteTableResponse, CoralClientError> {
        let response = self
            .table_client()?
            .delete_table(table::DeleteTableRequest {
                table_name: table_name.to_string(),
            })
            .await?
            .into_inner();
        mapping::map_delete_table_response(response)
    }

    pub async fn get_table_create_status(
        &self,
        table_name: &str,
    ) -> Result<CreateStatusResponse, CoralClientError> {
        let response = self
            .table_client()?
            .get_create_status(table::GetCreateStatusRequest {
                table_name: table_name.to_string(),
            })
            .await?
            .into_inner();
        mapping::map_create_status_response(response)
    }

    pub async fn active_set_flush(
        &self,
        table_name: &str,
        request: &ActiveSetFlushRequest,
    ) -> Result<ActiveSetFlushResponse, CoralClientError> {
        let response = self
            .table_client()?
            .active_set_flush(mapping::map_active_set_flush_request(table_name, request))
            .await?
            .into_inner();
        Ok(mapping::map_active_set_flush_response(response))
    }

    pub async fn segments_retry(
        &self,
        table_name: &str,
        request: &SegmentsRetryRequest,
    ) -> Result<SegmentsRetryResponse, CoralClientError> {
        let response = self
            .segment_client()?
            .retry_segments(mapping::map_segments_retry_request(table_name, request))
            .await?
            .into_inner();
        mapping::map_segments_retry_response(response)
    }

    pub async fn get_segments_status(
        &self,
        table_name: &str,
    ) -> Result<SegmentsStatusResponse, CoralClientError> {
        let response = self
            .segment_client()?
            .get_segments_status(segment::GetSegmentsStatusRequest {
                table_name: table_name.to_string(),
            })
            .await?
            .into_inner();
        mapping::map_segments_status_response(response)
    }

    pub async fn rebalance_plan(
        &self,
        table_name: &str,
        request: &RebalancePlanRequest,
    ) -> Result<RebalancePlanResponse, CoralClientError> {
        let response = self
            .segment_client()?
            .rebalance_plan(mapping::map_rebalance_plan_request(table_name, request))
            .await?
            .into_inner();
        mapping::map_rebalance_plan_response(response)
    }

    pub async fn rebalance_commit(
        &self,
        table_name: &str,
        request: &RebalanceCommitRequest,
    ) -> Result<RebalanceCommitResponse, CoralClientError> {
        let response = self
            .segment_client()?
            .rebalance_commit(mapping::map_rebalance_commit_request(table_name, request))
            .await?
            .into_inner();
        mapping::map_rebalance_commit_response(response)
    }

    pub async fn get_rebalance_status(
        &self,
        table_name: &str,
    ) -> Result<RebalanceStatusResponse, CoralClientError> {
        let response = self
            .segment_client()?
            .get_rebalance_status(segment::GetRebalanceStatusRequest {
                table_name: table_name.to_string(),
            })
            .await?
            .into_inner();
        Ok(mapping::map_rebalance_status_response(response))
    }

    pub async fn get_table_schema(&self, table_name: &str) -> Result<TableView, CoralClientError> {
        self.get_table_impl(table_name, false).await
    }

    pub async fn get_table_schema_with_internal(
        &self,
        table_name: &str,
        internal: bool,
    ) -> Result<TableView, CoralClientError> {
        self.get_table_impl(table_name, internal).await
    }

    pub async fn insert_data(
        &self,
        table_name: &str,
        data: &str,
        params: &InsertQueryParams,
    ) -> Result<DataInsertResult, CoralClientError> {
        let response = self
            .ingest_client()?
            .insert_jsonl(ingest::InsertJsonlRequest {
                table_name: table_name.to_string(),
                options: Some(mapping::map_insert_options(params)),
                jsonl: Bytes::copy_from_slice(data.as_bytes()),
            })
            .await?
            .into_inner();
        Ok(mapping::map_insert_response(response))
    }

    /// Convenience helper that uploads a fully materialized Arrow IPC stream.
    ///
    /// This remains available for callers that already have the entire Arrow
    /// IPC payload in memory, but the canonical low-level ingest surface is
    /// [`Self::insert_arrow_ipc_chunk_stream`].
    pub async fn insert_data_arrow_stream(
        &self,
        table_name: &str,
        arrow_ipc_stream: Vec<u8>,
    ) -> Result<DataInsertResult, CoralClientError> {
        self.insert_arrow_ipc_chunk_stream(
            table_name,
            &default_insert_options(),
            byte_chunks_from_buffer(
                Bytes::from(arrow_ipc_stream),
                DEFAULT_ARROW_IPC_UPLOAD_CHUNK_SIZE_BYTES,
            ),
        )
        .await
    }

    /// Canonical low-level Arrow IPC upload API.
    ///
    /// Callers provide a chunk stream directly, allowing Arrow IPC payloads to
    /// be produced and uploaded incrementally without first materializing a
    /// full `Vec<u8>`.
    pub async fn insert_arrow_ipc_chunk_stream<S>(
        &self,
        table_name: &str,
        options: &InsertQueryParams,
        chunks: S,
    ) -> Result<DataInsertResult, CoralClientError>
    where
        S: tokio_stream::Stream<Item = Result<Bytes, CoralClientError>> + Send + 'static,
    {
        let (sender, receiver) = mpsc::channel::<ingest::InsertArrowIpcStreamEvent>(
            DEFAULT_ARROW_IPC_UPLOAD_BUFFERED_CHUNKS,
        );
        let upload_handle = tokio::spawn(stream_arrow_ipc_chunks(
            table_name.to_string(),
            options.clone(),
            chunks,
            sender,
        ));

        let response = self
            .ingest_client()?
            .insert_arrow_ipc(Request::new(tokio_stream::wrappers::ReceiverStream::new(
                receiver,
            )))
            .await?
            .into_inner();

        upload_handle
            .await
            .map_err(|error| CoralClientError::TaskJoinError(error.to_string()))??;

        Ok(mapping::map_insert_response(response))
    }

    /// Convenience helper that reads a local parquet file and uploads it as a
    /// streamed Arrow IPC ingest request.
    ///
    /// This is built on top of [`Self::insert_arrow_ipc_chunk_stream`]. Callers
    /// that already own a chunk source should prefer the lower-level API.
    pub async fn insert_parquet_file_as_arrow_stream(
        &self,
        table_name: &str,
        parquet_path: impl AsRef<Path>,
        parquet_batch_size: Option<usize>,
    ) -> Result<DataInsertResult, CoralClientError> {
        let parquet_path: PathBuf = parquet_path.as_ref().to_path_buf();
        let batch_size = parquet_batch_size;
        self.insert_arrow_ipc_chunk_stream(
            table_name,
            &default_insert_options(),
            parquet_file_to_arrow_ipc_chunks(
                parquet_path,
                batch_size,
                DEFAULT_ARROW_IPC_UPLOAD_CHUNK_SIZE_BYTES,
                DEFAULT_ARROW_IPC_UPLOAD_BUFFERED_CHUNKS,
            ),
        )
        .await
    }

    pub async fn batch_insert_data(
        &self,
        table_name: &str,
        request: &Paths,
        params: &BatchInsertQueryParams,
    ) -> Result<coral_models::api::data::BatchDataInsertResult, CoralClientError> {
        let response = self
            .ingest_client()?
            .batch_insert_files(mapping::map_batch_insert_request(
                table_name, request, params,
            )?)
            .await?
            .into_inner();
        Ok(mapping::map_batch_insert_response(response))
    }

    /// Convenience helper that fully collects a vector search result.
    ///
    /// The canonical data-plane API is [`Self::vector_search_stream`].
    pub async fn vector_search(
        &self,
        table_name: &str,
        index_name: &str,
        request: &VectorSearchRequest,
    ) -> Result<MultipleResults, CoralClientError> {
        self.vector_search_stream(table_name, index_name, request)
            .await?
            .collect_multiple()
            .await
    }

    /// Canonical low-level vector search API.
    pub async fn vector_search_stream(
        &self,
        table_name: &str,
        index_name: &str,
        request: &VectorSearchRequest,
    ) -> Result<QueryResultStream, CoralClientError> {
        let response = self
            .query_client()?
            .vector_search(mapping::map_vector_search_request(
                table_name,
                index_name,
                request,
                &SearchQueryParams { allow_writer: None },
            )?)
            .await?
            .into_inner();
        Ok(QueryResultStream::new(response))
    }

    /// Convenience helper that fully collects an exact-kNN search result.
    ///
    /// The canonical data-plane API is [`Self::vector_search_exact_knn_stream`].
    pub async fn vector_search_exact_knn(
        &self,
        table_name: &str,
        index_name: &str,
        request: &VectorSearchExactKnnRequest,
    ) -> Result<MultipleResults, CoralClientError> {
        self.vector_search_exact_knn_stream(table_name, index_name, request)
            .await?
            .collect_multiple()
            .await
    }

    /// Canonical low-level exact-kNN search API.
    pub async fn vector_search_exact_knn_stream(
        &self,
        table_name: &str,
        index_name: &str,
        request: &VectorSearchExactKnnRequest,
    ) -> Result<QueryResultStream, CoralClientError> {
        let response = self
            .query_client()?
            .vector_search_exact_knn(mapping::map_vector_search_exact_knn_request(
                table_name,
                index_name,
                request,
                &SearchQueryParams { allow_writer: None },
            )?)
            .await?
            .into_inner();
        Ok(QueryResultStream::new(response))
    }

    /// Convenience helper that fully collects a hybrid search result.
    ///
    /// The canonical data-plane API is [`Self::hybrid_search_stream`].
    pub async fn hybrid_search(
        &self,
        table_name: &str,
        request: &HybridVectorSearchRequest,
    ) -> Result<MultipleResults, CoralClientError> {
        self.hybrid_search_stream(table_name, request)
            .await?
            .collect_multiple()
            .await
    }

    /// Canonical low-level hybrid search API.
    pub async fn hybrid_search_stream(
        &self,
        table_name: &str,
        request: &HybridVectorSearchRequest,
    ) -> Result<QueryResultStream, CoralClientError> {
        let response = self
            .query_client()?
            .hybrid_search(build_hybrid_search_request(table_name, request))
            .await?
            .into_inner();
        Ok(QueryResultStream::new(response))
    }

    pub async fn data_plan(
        &self,
        table_name: &str,
        request: &DataPlanRequest,
    ) -> Result<DataPlanResponse, CoralClientError> {
        let response = self
            .query_client()?
            .data_plan(build_data_plan_request(table_name, request))
            .await?
            .into_inner();
        mapping::map_data_plan_response(response)
    }

    pub async fn get_indexed_row_count(
        &self,
        table_name: &str,
    ) -> Result<TableIndexedCountResponse, CoralClientError> {
        let response = self
            .table_client()?
            .get_indexed_row_count(build_get_indexed_row_count_request(table_name, Some(true)))
            .await?
            .into_inner();
        mapping::map_get_indexed_row_count_response(response)
    }

    pub async fn get_indexed_row_count_with_readable(
        &self,
        table_name: &str,
        readable: Option<bool>,
    ) -> Result<TableIndexedCountResponse, CoralClientError> {
        let response = self
            .table_client()?
            .get_indexed_row_count(build_get_indexed_row_count_request(table_name, readable))
            .await?
            .into_inner();
        mapping::map_get_indexed_row_count_response(response)
    }

    /// Convenience helper that fully collects a scan result.
    ///
    /// The canonical data-plane API is [`Self::scan_data_stream`].
    pub async fn scan_data(
        &self,
        table_name: &str,
        request: &DataScanRequest,
        params: &ScanQueryParams,
    ) -> Result<SingleResult, CoralClientError> {
        self.scan_data_stream(table_name, request, params)
            .await?
            .collect_single()
            .await
    }

    /// Canonical low-level scan API.
    pub async fn scan_data_stream(
        &self,
        table_name: &str,
        request: &DataScanRequest,
        params: &ScanQueryParams,
    ) -> Result<QueryResultStream, CoralClientError> {
        let response = self
            .query_client()?
            .scan_table_data(build_scan_table_data_request(table_name, request, params))
            .await?
            .into_inner();
        Ok(QueryResultStream::new(response))
    }

    pub async fn update_table_data(
        &self,
        table_name: &str,
        request: &DataUpdateRequest,
    ) -> Result<(), CoralClientError> {
        self.ingest_client()?
            .update_table_data(mapping::map_update_table_data_request(table_name, request))
            .await?;
        Ok(())
    }

    pub async fn delete_table_data(
        &self,
        table_name: &str,
        request: &DataDeleteRequest,
    ) -> Result<(), CoralClientError> {
        self.ingest_client()?
            .delete_table_data(mapping::map_delete_table_data_request(table_name, request))
            .await?;
        Ok(())
    }

    pub async fn export_data(
        &self,
        table_name: &str,
        request: &DataExportRequest,
    ) -> Result<DataExportResponse, CoralClientError> {
        let response: export::ExportTableDataResponse = self
            .export_client()?
            .export_table_data(mapping::map_export_request(table_name, request)?)
            .await?
            .into_inner();
        mapping::map_export_response(response)
    }

    pub async fn get_table(&self, table_name: &str) -> Result<TableView, CoralClientError> {
        self.get_table_impl(table_name, false).await
    }

    pub async fn get_table_with_internal(
        &self,
        table_name: &str,
        internal: bool,
    ) -> Result<TableView, CoralClientError> {
        self.get_table_impl(table_name, internal).await
    }

    /// Canonical low-level export download API.
    ///
    /// The caller consumes chunks through [`ExportDownloadStream`] rather than
    /// receiving a fully buffered file by default.
    pub async fn export_data_download_stream(
        &self,
        table_name: &str,
        params: &DataExportDownloadQueryParams,
    ) -> Result<ExportDownloadStream, CoralClientError> {
        let mut stream: tonic::Streaming<export::ExportDownloadEvent> = self
            .export_client()?
            .export_table_data_download(mapping::map_export_download_request(table_name, params))
            .await?
            .into_inner();
        let filename = read_export_download_header(&mut stream).await?;
        Ok(ExportDownloadStream {
            filename,
            inner: stream,
        })
    }

    pub async fn get_columns_from_parquet(
        &self,
        request: &Paths,
        internal: bool,
    ) -> Result<ParquetSchemaInfo, CoralClientError> {
        let response = self
            .utility_client()?
            .get_schema_from_parquet(mapping::map_get_schema_from_parquet_request(
                request, internal,
            )?)
            .await?
            .into_inner();
        mapping::map_get_schema_from_parquet_response(response)
    }
}

fn build_hybrid_search_request(
    table_name: &str,
    request: &HybridVectorSearchRequest,
) -> Request<query::HybridSearchRequest> {
    Request::new(mapping::map_hybrid_search_request(
        table_name,
        request,
        &SearchQueryParams { allow_writer: None },
    ))
}

fn build_data_plan_request(
    table_name: &str,
    request: &DataPlanRequest,
) -> Request<query::DataPlanRequest> {
    Request::new(mapping::map_data_plan_request(table_name, request))
}

fn build_get_indexed_row_count_request(
    table_name: &str,
    readable: Option<bool>,
) -> Request<table::GetIndexedRowCountRequest> {
    Request::new(table::GetIndexedRowCountRequest {
        table_name: table_name.to_string(),
        readable,
    })
}

fn build_scan_table_data_request(
    table_name: &str,
    request: &DataScanRequest,
    params: &ScanQueryParams,
) -> Request<query::ScanTableDataRequest> {
    Request::new(mapping::map_scan_request(table_name, request, params))
}

async fn read_export_download_header(
    stream: &mut tonic::Streaming<export::ExportDownloadEvent>,
) -> Result<String, CoralClientError> {
    let header = stream.message().await?.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "export download stream ended before sending a header".to_string(),
        )
    })?;
    match header.event.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse("export download header payload missing".to_string())
    })? {
        export::export_download_event::Event::Header(header) => Ok(header.filename),
        other => Err(CoralClientError::InvalidGrpcResponse(format!(
            "expected export download header, got {other:?}"
        ))),
    }
}

fn default_insert_options() -> InsertQueryParams {
    InsertQueryParams {
        reader_batch_size: None,
        use_async_read: None,
    }
}

fn insert_arrow_ipc_header_event(
    table_name: String,
    options: InsertQueryParams,
) -> ingest::InsertArrowIpcStreamEvent {
    ingest::InsertArrowIpcStreamEvent {
        event: Some(ingest::insert_arrow_ipc_stream_event::Event::Header(
            ingest::InsertArrowIpcStreamHeader {
                table_name,
                options: Some(mapping::map_insert_options(&options)),
            },
        )),
    }
}

fn insert_arrow_ipc_chunk_event(chunk: Bytes) -> ingest::InsertArrowIpcStreamEvent {
    ingest::InsertArrowIpcStreamEvent {
        event: Some(ingest::insert_arrow_ipc_stream_event::Event::Chunk(
            ingest::InsertArrowIpcStreamChunk { chunk },
        )),
    }
}

fn byte_chunks_from_buffer(
    buffer: Bytes,
    chunk_size: usize,
) -> impl tokio_stream::Stream<Item = Result<Bytes, CoralClientError>> {
    let chunk_size = chunk_size.max(1);
    let mut chunks =
        Vec::with_capacity((buffer.len() + chunk_size.saturating_sub(1)) / chunk_size.max(1));
    let mut offset = 0;
    while offset < buffer.len() {
        let next_offset = (offset + chunk_size).min(buffer.len());
        chunks.push(Ok(buffer.slice(offset..next_offset)));
        offset = next_offset;
    }

    tokio_stream::iter(chunks)
}

async fn stream_arrow_ipc_chunks<S>(
    table_name: String,
    options: InsertQueryParams,
    chunks: S,
    sender: mpsc::Sender<ingest::InsertArrowIpcStreamEvent>,
) -> Result<(), CoralClientError>
where
    S: tokio_stream::Stream<Item = Result<Bytes, CoralClientError>> + Send + 'static,
{
    let mut chunks = Box::pin(chunks);
    sender
        .send(insert_arrow_ipc_header_event(table_name, options))
        .await
        .map_err(|_| {
            CoralClientError::InvalidGrpcResponse(
                "insert arrow stream receiver dropped before header was sent".to_string(),
            )
        })?;

    while let Some(chunk) = chunks.next().await {
        let chunk = chunk?;
        if chunk.is_empty() {
            continue;
        }

        sender
            .send(insert_arrow_ipc_chunk_event(chunk))
            .await
            .map_err(|_| {
                CoralClientError::InvalidGrpcResponse(
                    "insert arrow stream receiver dropped before upload completed".to_string(),
                )
            })?;
    }

    Ok(())
}

fn parquet_file_to_arrow_ipc_chunks(
    parquet_path: PathBuf,
    batch_size: Option<usize>,
    chunk_size_bytes: usize,
    buffered_chunks: usize,
) -> impl tokio_stream::Stream<Item = Result<Bytes, CoralClientError>> {
    let (sender, receiver) = mpsc::channel::<Result<Bytes, CoralClientError>>(buffered_chunks);
    tokio::task::spawn_blocking(move || {
        let result = stream_parquet_file_as_arrow_ipc(
            &parquet_path,
            batch_size,
            sender.clone(),
            chunk_size_bytes,
        );

        if let Err(error) = result {
            let _ = sender.blocking_send(Err(error));
        }
    });

    tokio_stream::wrappers::ReceiverStream::new(receiver)
}

fn stream_parquet_file_as_arrow_ipc(
    parquet_path: &Path,
    batch_size: Option<usize>,
    sender: mpsc::Sender<Result<Bytes, CoralClientError>>,
    chunk_size_bytes: usize,
) -> Result<(), CoralClientError> {
    use arrow_array::RecordBatchReader;
    use arrow_ipc::writer::StreamWriter;
    use std::fs::File;

    let file = File::open(parquet_path)?;
    let mut reader = ParquetRecordBatchReaderBuilder::try_new(file)?
        .with_batch_size(batch_size.unwrap_or(8192))
        .build()?;

    let schema = reader.schema().clone();
    let mut writer = StreamWriter::try_new(
        InsertArrowIpcChunkWriter::new(sender, chunk_size_bytes.max(1)),
        &schema,
    )?;
    for batch in reader.by_ref() {
        writer.write(&batch?)?;
    }
    writer.finish()?;
    let mut chunk_writer = writer.into_inner()?;
    chunk_writer.finish()?;
    Ok(())
}

struct InsertArrowIpcChunkWriter {
    sender: mpsc::Sender<Result<Bytes, CoralClientError>>,
    buffer: bytes::BytesMut,
    chunk_size_bytes: usize,
}

impl InsertArrowIpcChunkWriter {
    fn new(sender: mpsc::Sender<Result<Bytes, CoralClientError>>, chunk_size_bytes: usize) -> Self {
        Self {
            sender,
            buffer: bytes::BytesMut::with_capacity(chunk_size_bytes),
            chunk_size_bytes,
        }
    }

    fn finish(&mut self) -> Result<(), CoralClientError> {
        if self.buffer.is_empty() {
            return Ok(());
        }

        let chunk = self.buffer.split().freeze();
        self.send_chunk(chunk)
    }

    fn flush_full_chunks(&mut self) -> Result<(), CoralClientError> {
        while self.buffer.len() >= self.chunk_size_bytes {
            let chunk = self.buffer.split_to(self.chunk_size_bytes).freeze();
            self.send_chunk(chunk)?;
        }
        Ok(())
    }

    fn send_chunk(&self, chunk: Bytes) -> Result<(), CoralClientError> {
        self.sender.blocking_send(Ok(chunk)).map_err(|_| {
            CoralClientError::InvalidGrpcResponse(
                "insert arrow stream receiver dropped before upload completed".to_string(),
            )
        })
    }
}

impl std::io::Write for InsertArrowIpcChunkWriter {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.buffer.extend_from_slice(buf);
        self.flush_full_chunks()
            .map_err(|error| std::io::Error::other(error.to_string()))?;
        Ok(buf.len())
    }

    fn flush(&mut self) -> std::io::Result<()> {
        self.flush_full_chunks()
            .map_err(|error| std::io::Error::other(error.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use std::path::PathBuf;
    use std::sync::Arc;
    use std::time::{SystemTime, UNIX_EPOCH};

    use arrow_array::{Int32Array, RecordBatch};
    use arrow_schema::{DataType, Field, Schema};
    use coral_models::api::data::{DataScanRequest, ScanQueryParams};
    use coral_models::api::diagnostics::DataPlanRequest as ModelDataPlanRequest;
    use parquet::arrow::ArrowWriter;
    use std::collections::VecDeque;

    use super::*;

    #[test]
    fn grpc_base_url_trims_trailing_slash() {
        let client = CoralClient::new("http://127.0.0.1:8080/".to_string());

        assert_eq!(client.grpc_base_url(), "http://127.0.0.1:8080");
    }

    #[tokio::test]
    async fn grpc_channel_is_cached_and_shared_across_clones() {
        let client = CoralClient::new("http://127.0.0.1:8080/".to_string());
        assert!(client.grpc_channel.lock().expect("channel mutex").is_none());

        let cloned = client.clone();
        let _channel = client.grpc_channel().expect("grpc channel");

        assert!(client.grpc_channel.lock().expect("channel mutex").is_some());
        assert!(cloned.grpc_channel.lock().expect("channel mutex").is_some());
        assert!(Arc::ptr_eq(&client.grpc_channel, &cloned.grpc_channel));
    }

    async fn collect_export_download_stream_from_messages<F, Fut>(
        mut next_message: F,
    ) -> Result<(String, Vec<u8>), CoralClientError>
    where
        F: FnMut() -> Fut,
        Fut: std::future::Future<Output = Result<Option<export::ExportDownloadEvent>, tonic::Status>>,
    {
        let header = next_message().await?.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "export download stream ended before sending a header".to_string(),
            )
        })?;
        let filename = match header.event.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "export download header payload missing".to_string(),
            )
        })? {
            export::export_download_event::Event::Header(header) => header.filename,
            other => {
                return Err(CoralClientError::InvalidGrpcResponse(format!(
                    "expected export download header, got {other:?}"
                )));
            }
        };

        let mut body = Vec::new();
        while let Some(event) = next_message().await? {
            match event.event.ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(
                    "export download stream event did not contain a payload".to_string(),
                )
            })? {
                export::export_download_event::Event::Chunk(chunk) => {
                    body.extend_from_slice(&chunk.chunk);
                }
                export::export_download_event::Event::Header(_) => {
                    return Err(CoralClientError::InvalidGrpcResponse(
                        "export download stream contained multiple headers".to_string(),
                    ));
                }
            }
        }

        Ok((filename, body))
    }

    #[tokio::test]
    async fn collects_export_download_stream() {
        let queue = Arc::new(Mutex::new(VecDeque::from(vec![
            export::ExportDownloadEvent {
                event: Some(export::export_download_event::Event::Header(
                    export::ExportDownloadHeader {
                        filename: "part-00000.parquet".to_string(),
                    },
                )),
            },
            export::ExportDownloadEvent {
                event: Some(export::export_download_event::Event::Chunk(
                    export::ExportDownloadChunk {
                        chunk: Bytes::from_static(b"hello "),
                    },
                )),
            },
            export::ExportDownloadEvent {
                event: Some(export::export_download_event::Event::Chunk(
                    export::ExportDownloadChunk {
                        chunk: Bytes::from_static(b"world"),
                    },
                )),
            },
        ])));

        let (filename, body) = collect_export_download_stream_from_messages({
            let queue = queue.clone();
            move || {
                let queue = queue.clone();
                async move { Ok(queue.lock().expect("queue").pop_front()) }
            }
        })
        .await
        .expect("collected export stream");

        assert_eq!(filename, "part-00000.parquet");
        assert_eq!(body, b"hello world");
    }

    #[tokio::test]
    async fn stream_arrow_ipc_chunks_emits_header_and_chunks() {
        let (sender, mut receiver) = mpsc::channel::<ingest::InsertArrowIpcStreamEvent>(8);

        stream_arrow_ipc_chunks(
            "videos".to_string(),
            default_insert_options(),
            tokio_stream::iter(vec![
                Ok(Bytes::from_static(b"abc")),
                Ok(Bytes::new()),
                Ok(Bytes::from_static(b"def")),
            ]),
            sender,
        )
        .await
        .expect("stream chunks");

        let header = receiver.recv().await.expect("header");
        match header.event.expect("header event") {
            ingest::insert_arrow_ipc_stream_event::Event::Header(header) => {
                assert_eq!(header.table_name, "videos");
            }
            other => panic!("unexpected event: {other:?}"),
        }

        let first_chunk = receiver.recv().await.expect("first chunk");
        match first_chunk.event.expect("chunk event") {
            ingest::insert_arrow_ipc_stream_event::Event::Chunk(chunk) => {
                assert_eq!(chunk.chunk, Bytes::from_static(b"abc"));
            }
            other => panic!("unexpected event: {other:?}"),
        }

        let second_chunk = receiver.recv().await.expect("second chunk");
        match second_chunk.event.expect("chunk event") {
            ingest::insert_arrow_ipc_stream_event::Event::Chunk(chunk) => {
                assert_eq!(chunk.chunk, Bytes::from_static(b"def"));
            }
            other => panic!("unexpected event: {other:?}"),
        }

        assert!(receiver.recv().await.is_none());
    }

    #[tokio::test]
    async fn rejects_export_download_stream_without_header() {
        let queue = Arc::new(Mutex::new(VecDeque::from(vec![
            export::ExportDownloadEvent {
                event: Some(export::export_download_event::Event::Chunk(
                    export::ExportDownloadChunk {
                        chunk: Bytes::from_static(b"payload"),
                    },
                )),
            },
        ])));

        let error = collect_export_download_stream_from_messages({
            let queue = queue.clone();
            move || {
                let queue = queue.clone();
                async move { Ok(queue.lock().expect("queue").pop_front()) }
            }
        })
        .await
        .expect_err("missing header should fail");

        match error {
            CoralClientError::InvalidGrpcResponse(message) => {
                assert!(message.contains("expected export download header"));
            }
            other => panic!("unexpected error: {other}"),
        }
    }

    #[test]
    fn parquet_file_to_arrow_ipc_stream_roundtrip() {
        let schema = Arc::new(Schema::new(vec![Field::new("id", DataType::Int32, false)]));
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(Int32Array::from(vec![1, 2, 3]))],
        )
        .expect("record batch");

        let mut path = std::env::temp_dir();
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time")
            .as_nanos();
        path.push(format!("coral-client-{unique}.parquet"));

        write_parquet(&path, schema.as_ref(), batch).expect("write parquet");
        let (sender, mut receiver) = mpsc::channel::<Result<Bytes, CoralClientError>>(
            DEFAULT_ARROW_IPC_UPLOAD_BUFFERED_CHUNKS,
        );
        stream_parquet_file_as_arrow_ipc(
            &path,
            Some(1024),
            sender,
            DEFAULT_ARROW_IPC_UPLOAD_CHUNK_SIZE_BYTES,
        )
        .expect("stream parquet");
        let mut ipc = Vec::new();
        while let Some(chunk) = receiver.blocking_recv() {
            ipc.extend_from_slice(chunk.expect("chunk").as_ref());
        }
        let mut reader =
            arrow_ipc::reader::StreamReader::try_new(ipc.as_slice(), None).expect("ipc reader");
        let decoded = reader
            .next()
            .expect("batch present")
            .expect("decoded batch");

        assert_eq!(decoded.num_rows(), 3);
        std::fs::remove_file(path).expect("cleanup parquet file");
    }

    #[test]
    fn build_data_plan_request_wraps_proto_payload() {
        let request = ModelDataPlanRequest {
            projection: Some("id, name".to_string()),
            filter: Some("id > 10".to_string()),
            allow_writer: Some(true),
        };

        let payload = build_data_plan_request("videos", &request).into_inner();

        assert_eq!(payload.table_name, "videos");
        assert_eq!(payload.projection.as_deref(), Some("id, name"));
        assert_eq!(payload.filter.as_deref(), Some("id > 10"));
        assert_eq!(payload.allow_writer, Some(true));
    }

    #[test]
    fn build_get_indexed_row_count_request_uses_table_name() {
        let payload = build_get_indexed_row_count_request("videos", Some(true)).into_inner();

        assert_eq!(payload.table_name, "videos");
        assert_eq!(payload.readable, Some(true));
    }

    #[test]
    fn build_get_indexed_row_count_request_allows_disabling_readable() {
        let payload = build_get_indexed_row_count_request("videos", Some(false)).into_inner();

        assert_eq!(payload.table_name, "videos");
        assert_eq!(payload.readable, Some(false));
    }

    #[test]
    fn build_scan_table_data_request_wraps_scan_options() {
        let request = DataScanRequest {
            projection: Some("id".to_string()),
            filter: Some("id < 100".to_string()),
            limit: Some(25),
        };
        let params = ScanQueryParams {
            include_metrics: Some(true),
            allow_writer: Some(false),
            include_internal_columns: Some(true),
        };

        let payload = build_scan_table_data_request("videos", &request, &params).into_inner();
        let options = payload.options.expect("scan request options");

        assert_eq!(payload.table_name, "videos");
        assert_eq!(payload.projection.as_deref(), Some("id"));
        assert_eq!(payload.filter.as_deref(), Some("id < 100"));
        assert_eq!(payload.limit, Some(25));
        assert_eq!(options.include_metrics, Some(true));
        assert_eq!(options.allow_writer, Some(false));
        assert_eq!(options.include_internal_columns, Some(true));
    }

    fn write_parquet(
        path: &PathBuf,
        schema: &Schema,
        batch: RecordBatch,
    ) -> Result<(), CoralClientError> {
        let file = std::fs::File::create(path)?;
        let mut writer = ArrowWriter::try_new(file, Arc::new(schema.clone()), None)?;
        writer.write(&batch)?;
        writer.close()?;
        Ok(())
    }
}
