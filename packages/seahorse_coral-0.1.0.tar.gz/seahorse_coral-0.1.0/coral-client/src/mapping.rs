use std::collections::HashMap;
use std::time::{Duration, UNIX_EPOCH};

use coral_models::api::cluster::{
    CacheConfigResponse, CacheDumpRequest, CacheInvalidateRequest, CacheInvalidateResponse,
    CacheRefreshResponse, CacheStatsResponse, CatalogStorageDumpResponse, RebalanceCommitRequest,
    RebalanceCommitResponse, RebalanceNodeLoad, RebalancePlanRequest, RebalancePlanResponse,
    RebalancePlanSummary, RebalanceSegmentChangeFlag, RebalanceSegmentEntry, RebalanceSegmentSide,
    RebalanceStatusResponse, RebalanceStrategy,
    SegmentAssignmentSnapshot as RebalanceSegmentAssignmentSnapshot, SegmentRetryMode,
    SegmentStructureSnapshot, SegmentsRetryNodeObservations, SegmentsRetryNodeResult,
    SegmentsRetryRequest, SegmentsRetryResponse, SegmentsRetrySkipInfo, SegmentsRetrySummary,
    SegmentsStatusMode, SegmentsStatusResponse, SegmentsStatusSummary,
    StorageDumpQueryParams as ModelStorageDumpQueryParams, TableOperationNodeSegmentStatus,
    TableOperationObservedSegmentStatus, TableOperationPollingInfo,
    TableOperationSegmentExpectation, TableOperationSegmentStatus,
};
use coral_models::api::common::RequestMetrics;
use coral_models::api::data::{
    BatchDataInsertResult, DataDeleteRequest, DataExportDownloadQueryParams, DataExportRequest,
    DataExportResponse, DataInsertResult, DataScanRequest, DataUpdateRequest, ExportMode,
    FileFormat, FileInsertResult, InsertQueryParams, ScanQueryParams, SearchQueryParams,
};
use coral_models::api::diagnostics::{
    DataPlanRequest as ModelDataPlanRequest, DataPlanResponse as ModelDataPlanResponse,
    EmptyRangeDiagnostic, NodeSearchRanges, NodeSegmentRawSnapshot, NodeSetVersions,
    RawNodeAssignments, SegmentPlanDetail, SegmentPruningInfo, SetVersionEntry,
};
use coral_models::api::node::NodePingResponse;
use coral_models::api::node::{
    AllSyncErrorsResponse, NodeResourceUsage, NodeResourceUsageResult, NodeSyncErrorsResponse,
    SegmentResourceUsage, TableResourceUsage, VdbResourceUsageResponse,
};
use coral_models::api::schema::{
    Column, ColumnType, CreateTableRequest, ExternalIndex, ExternalSegmentation, IndexParams,
    ScalarType, SegmentationComposition, SegmentationStrategy, TableConfigurations, TablePlacement,
    VectorElement, VectorType,
};
use coral_models::api::storage::{
    BatchInsertQueryParams, CloudStorageCredentials, CloudStorageOptions, Paths, StorageConfig,
    StorageType,
};
use coral_models::api::table::{
    ActiveSetFlushRequest, ActiveSetFlushResponse, CreateTableResponse, DeleteTableResponse,
    SyncMode, TableIndexedCount, TableIndexedCountResponse,
};
use coral_models::api::vector::{
    DenseSearchParameters, DenseVectorSearchConfig, FusionConfig, FusionParameters,
    HybridVectorSearchRequest, QueryVectors, VectorSearchRequest,
};
use coral_models::api::{
    LogConfig, LogConfigUpdate, LogLevel, SparseMetadata, SparseSearchParameters,
    SparseVectorSearchConfig, VectorSearchExactKnnRequest,
};
use coral_models::catalog::{
    CacheEntryType, CacheEntryValue, ColumnMinMaxValue, IndexInfoElement, IndexParameters,
    NodeCheckpointInfo, NodeInfo, NodeStage, NodeState, NodeType, SegmentAssignment,
    SegmentAssignmentSnapshot as CatalogSegmentAssignmentSnapshot, SegmentAssignmentStatus,
    SegmentInfo, SegmentKeyCompositionType, SegmentType, SegmentationInfo, SyncErrorInfo,
    TableAssignment, TableInfo as CatalogTableInfo, TableOperationFailure,
    TableOperationNodeFailure, TableOperationSegmentFailure,
};

use crate::error::CoralClientError;
use crate::proto::{
    catalog, common, export as export_proto, ingest, log, node, query, segment, storage, table,
    utility,
};
use crate::result_stream::schema_from_ipc;
use crate::types::{
    CatalogCacheDump, CatalogCacheEntry, ExternalTableView, InternalTableView, NodeRecord,
    ParquetSchemaInfo, TableView,
};

pub(crate) fn default_table_query_options(internal: bool) -> table::TableQueryOptions {
    table::TableQueryOptions {
        view: if internal {
            table::TableView::Internal as i32
        } else {
            table::TableView::External as i32
        },
        include_internal_columns: None,
    }
}

pub(crate) fn map_request_metrics(
    metrics: Option<common::RequestMetrics>,
) -> Option<RequestMetrics> {
    metrics.map(|metrics| RequestMetrics {
        elapsed_time: metrics.elapsed_time.unwrap_or_default(),
        rss_peak_bytes: metrics.rss_peak_bytes,
    })
}

pub(crate) fn map_create_table_request(
    request: &CreateTableRequest,
) -> Result<table::CreateTableRequest, CoralClientError> {
    Ok(table::CreateTableRequest {
        table: Some(catalog::CreateTableSpec {
            table_name: request.table_name.clone(),
            columns: request
                .columns
                .iter()
                .cloned()
                .map(map_column_to_proto)
                .collect::<Result<Vec<_>, _>>()?,
            primary_key: request.primary_key.clone().unwrap_or_default(),
            segmentation: request
                .segmentation
                .clone()
                .map(map_external_segmentation_to_proto),
            indexes: request
                .indexes
                .clone()
                .unwrap_or_default()
                .into_iter()
                .map(map_external_index_to_proto)
                .collect(),
            configurations: request
                .configurations
                .clone()
                .map(map_table_configurations_to_proto),
            placement: request.placement.clone().map(map_table_placement_to_proto),
        }),
    })
}

pub(crate) fn map_create_table_response(
    response: table::CreateTableResponse,
) -> Result<CreateTableResponse, CoralClientError> {
    let identity = response.table.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "create table response is missing table identity".to_string(),
        )
    })?;

    Ok(CreateTableResponse {
        table_name: identity.table_name,
        oid: identity.oid,
    })
}

pub(crate) fn map_delete_table_response(
    response: table::DeleteTableResponse,
) -> Result<DeleteTableResponse, CoralClientError> {
    let identity = response.table.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "delete table response is missing table identity".to_string(),
        )
    })?;

    Ok(DeleteTableResponse {
        table_name: identity.table_name,
        oid: identity.oid,
    })
}

pub(crate) fn map_active_set_flush_request(
    table_name: &str,
    request: &ActiveSetFlushRequest,
) -> table::ActiveSetFlushRequest {
    table::ActiveSetFlushRequest {
        table_name: table_name.to_string(),
        segment_ids: request.segment_ids.clone().unwrap_or_default(),
        sync_mode: map_sync_mode_to_proto(request.sync_mode) as i32,
    }
}

pub(crate) fn map_active_set_flush_response(
    response: table::ActiveSetFlushResponse,
) -> ActiveSetFlushResponse {
    ActiveSetFlushResponse {
        flushed: response.flushed,
        failed: response.failed,
        skipped: response.skipped,
    }
}

pub(crate) fn map_segments_retry_request(
    table_name: &str,
    request: &SegmentsRetryRequest,
) -> segment::RetrySegmentsRequest {
    segment::RetrySegmentsRequest {
        table_name: table_name.to_string(),
        mode: map_segment_retry_mode_to_proto(&request.mode) as i32,
        only_failed: request.only_failed,
        skip_unsubscribed: request.skip_unsubscribed,
        dry_run: request.dry_run,
        max_targets: request.max_targets,
    }
}

pub(crate) fn map_segments_retry_response(
    response: segment::RetrySegmentsResponse,
) -> Result<SegmentsRetryResponse, CoralClientError> {
    let summary = response.summary.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "segments retry response is missing summary".to_string(),
        )
    })?;

    Ok(SegmentsRetryResponse {
        table_name: response.table_name,
        table_status: response.table_status,
        summary: SegmentsRetrySummary {
            mode: summary.mode,
            total_nodes: summary.total_nodes,
            published_segment_count: summary.published_segment_count,
            skipped_node_count: summary.skipped_node_count,
            truncated: summary.truncated,
        },
        nodes: response
            .nodes
            .into_iter()
            .map(map_segments_retry_node_result)
            .collect::<Result<Vec<_>, _>>()?,
    })
}

pub(crate) fn map_segments_status_response(
    response: segment::GetSegmentsStatusResponse,
) -> Result<SegmentsStatusResponse, CoralClientError> {
    Ok(SegmentsStatusResponse {
        table_name: response.table_name,
        table_status: response.table_status,
        mode: map_segments_status_mode_from_proto(response.mode)?,
        started_at: empty_option_to_none(response.started_at),
        ttl_seconds: response.ttl_seconds,
        failure: response.failure.map(map_table_operation_failure_from_proto),
        polling: response.polling.map(map_table_operation_polling_from_proto),
        summary: response.summary.map(map_segments_status_summary_from_proto),
    })
}

pub(crate) fn map_catalog_storage_dump_request(
    request: &ModelStorageDumpQueryParams,
) -> catalog::GetCatalogStorageDumpRequest {
    catalog::GetCatalogStorageDumpRequest {
        pattern: request.pattern.clone(),
        limit: request.limit.map(|value| value as u32),
    }
}

pub(crate) fn map_catalog_storage_dump_response(
    response: catalog::GetCatalogStorageDumpResponse,
) -> CatalogStorageDumpResponse {
    CatalogStorageDumpResponse {
        entries: response
            .entries
            .into_iter()
            .map(|entry| coral_models::api::CatalogStorageDumpEntry {
                key: entry.key,
                value: entry.value,
            })
            .collect(),
    }
}

pub(crate) fn map_catalog_cache_dump_request(
    request: &CacheDumpRequest,
) -> catalog::GetCatalogCacheDumpRequest {
    catalog::GetCatalogCacheDumpRequest {
        entry_type: request
            .entry_type
            .clone()
            .map(map_cache_entry_type_to_proto)
            .map(|value| value as i32),
        include_value: request.include_value,
        invalidated_only: request.invalidated_only,
        expired_only: request.expired_only,
        limit: request.limit.map(|value| value as u32),
        cursor: request.cursor.clone(),
    }
}

pub(crate) fn map_catalog_cache_dump_response(
    response: catalog::GetCatalogCacheDumpResponse,
) -> Result<CatalogCacheDump, CoralClientError> {
    Ok(CatalogCacheDump {
        cache_entries: response
            .cache_entries
            .into_iter()
            .map(map_cache_entry_dump_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        next_cursor: empty_option_to_none(response.next_cursor),
    })
}

pub(crate) fn map_catalog_cache_stats_response(
    response: catalog::GetCatalogCacheStatsResponse,
) -> CacheStatsResponse {
    CacheStatsResponse {
        nodes_count: u64_to_usize(response.nodes_count),
        tables_count: u64_to_usize(response.tables_count),
        segments_count: u64_to_usize(response.segments_count),
        total_count: u64_to_usize(response.total_count),
    }
}

pub(crate) fn map_catalog_cache_config_response(
    response: catalog::GetCatalogCacheConfigResponse,
) -> CacheConfigResponse {
    CacheConfigResponse {
        default_ttl_seconds: response.default_ttl_seconds,
        invalidation_subscriber_active: response.invalidation_subscriber_active,
        invalidation_channel: response.invalidation_channel,
        invalidation_reconnect_interval_seconds: response.invalidation_reconnect_interval_seconds,
        invalidation_heartbeat_interval_seconds: response.invalidation_heartbeat_interval_seconds,
    }
}

pub(crate) fn map_invalidate_catalog_cache_request(
    request: &CacheInvalidateRequest,
) -> catalog::InvalidateCatalogCacheRequest {
    catalog::InvalidateCatalogCacheRequest {
        key: request.key.clone(),
        publish: request.publish,
    }
}

pub(crate) fn map_invalidate_catalog_cache_response(
    response: catalog::InvalidateCatalogCacheResponse,
) -> CacheInvalidateResponse {
    CacheInvalidateResponse {
        invalidated: response.invalidated,
        published: response.published,
    }
}

pub(crate) fn map_refresh_catalog_cache_response(
    response: catalog::RefreshCatalogCacheResponse,
) -> CacheRefreshResponse {
    CacheRefreshResponse {
        refreshed: response.refreshed,
    }
}

pub(crate) fn map_log_level_to_proto(level: &LogLevel) -> log::LogLevel {
    log::LogLevel {
        level: level.level.clone(),
    }
}

pub(crate) fn map_log_level_from_proto(level: log::LogLevel) -> LogLevel {
    LogLevel { level: level.level }
}

pub(crate) fn map_log_config_from_proto(
    config: log::LogConfig,
) -> Result<LogConfig, CoralClientError> {
    Ok(LogConfig {
        output_mode: config.output_mode,
        stdio_target: config.stdio_target,
        file_path: config.file_path,
        file_instance_id: config.file_instance_id,
        max_size_mb: config.max_size_mb,
        max_files: config.max_files.try_into().map_err(|_| {
            CoralClientError::InvalidGrpcResponse("max_files exceeds usize".to_string())
        })?,
        suffix_mode: config.suffix_mode,
        timestamp_tz: config.timestamp_tz,
        timestamp_format: config.timestamp_format,
    })
}

pub(crate) fn map_log_config_update_to_proto(update: &LogConfigUpdate) -> log::LogConfigUpdate {
    log::LogConfigUpdate {
        output_mode: update.output_mode.clone(),
        stdio_target: update.stdio_target.clone(),
        file_path: update.file_path.clone(),
        file_instance_id: update.file_instance_id.clone(),
        max_size_mb: update.max_size_mb,
        max_files: update.max_files.map(|value| value as u64),
        suffix_mode: update.suffix_mode.clone(),
        timestamp_tz: update.timestamp_tz.clone(),
        timestamp_format: update.timestamp_format.clone(),
    }
}

pub(crate) fn map_rebalance_plan_request(
    table_name: &str,
    request: &RebalancePlanRequest,
) -> segment::RebalancePlanRequest {
    segment::RebalancePlanRequest {
        table_name: table_name.to_string(),
        reader_nodes: request.reader_nodes.clone().unwrap_or_default(),
        writer_nodes: request.writer_nodes.clone().unwrap_or_default(),
        strategy: request
            .strategy
            .map(map_rebalance_strategy_to_proto)
            .map(|value| value as i32),
    }
}

pub(crate) fn map_rebalance_plan_response(
    response: segment::RebalancePlanResponse,
) -> Result<RebalancePlanResponse, CoralClientError> {
    let expected_segment_structure = response.expected_segment_structure.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance plan response is missing expected_segment_structure".to_string(),
        )
    })?;
    let summary = response.summary.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance plan response is missing summary".to_string(),
        )
    })?;
    let commit_template = response.commit_template.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance plan response is missing commit_template".to_string(),
        )
    })?;

    Ok(RebalancePlanResponse {
        table_name: response.table_name,
        expected_table_version: response.expected_table_version,
        strategy: map_rebalance_strategy_from_proto(response.strategy)?,
        expected_segment_structure: map_segment_structure_snapshot_from_proto(
            expected_segment_structure,
        )?,
        effective_reader_nodes: response.effective_reader_nodes,
        effective_writer_nodes: response.effective_writer_nodes,
        summary: map_rebalance_plan_summary_from_proto(summary),
        segments: response
            .segments
            .into_iter()
            .map(map_rebalance_segment_entry_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        commit_template: map_rebalance_commit_request_from_proto(commit_template)?,
    })
}

pub(crate) fn map_rebalance_commit_request(
    table_name: &str,
    request: &RebalanceCommitRequest,
) -> segment::RebalanceCommitRequest {
    segment::RebalanceCommitRequest {
        table_name: table_name.to_string(),
        reader_nodes: request.reader_nodes.clone().unwrap_or_default(),
        writer_nodes: request.writer_nodes.clone().unwrap_or_default(),
        strategy: request
            .strategy
            .map(map_rebalance_strategy_to_proto)
            .map(|value| value as i32),
        expected_table_version: request.expected_table_version,
        expected_segment_structure: Some(map_segment_structure_snapshot_to_proto(
            request.expected_segment_structure.clone(),
        )),
    }
}

pub(crate) fn map_rebalance_commit_response(
    response: segment::RebalanceCommitResponse,
) -> Result<RebalanceCommitResponse, CoralClientError> {
    let summary = response.summary.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance commit response is missing summary".to_string(),
        )
    })?;

    Ok(RebalanceCommitResponse {
        table_name: response.table_name,
        new_table_version: response.new_table_version,
        status: response.status,
        summary: map_rebalance_plan_summary_from_proto(summary),
        segments: response
            .segments
            .into_iter()
            .map(map_rebalance_segment_entry_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        effective_reader_nodes: response.effective_reader_nodes,
        effective_writer_nodes: response.effective_writer_nodes,
    })
}

pub(crate) fn map_rebalance_status_response(
    response: segment::GetRebalanceStatusResponse,
) -> RebalanceStatusResponse {
    RebalanceStatusResponse {
        table_name: response.table_name,
        status: response.status,
        started_at: empty_option_to_none(response.started_at),
        ttl_seconds: response.ttl_seconds,
        failure: response.failure.map(map_table_operation_failure_from_proto),
        polling: response.polling.map(map_table_operation_polling_from_proto),
    }
}

pub(crate) fn map_batch_insert_request(
    table_name: &str,
    request: &Paths,
    params: &BatchInsertQueryParams,
) -> Result<ingest::BatchInsertFilesRequest, CoralClientError> {
    Ok(ingest::BatchInsertFilesRequest {
        table_name: table_name.to_string(),
        paths: Some(map_paths_to_proto(request.clone())?),
        options: Some(ingest::BatchInsertOptions {
            format: map_file_format_to_proto(params.format.clone()) as i32,
            reader_batch_size: params.reader_batch_size.map(|value| value as u32),
            max_concurrent_files: params.max_concurrent_files.map(|value| value as u32),
            include_metrics: params.include_metrics,
        }),
    })
}

pub(crate) fn map_batch_insert_response(
    response: ingest::BatchInsertFilesResponse,
) -> BatchDataInsertResult {
    BatchDataInsertResult {
        results: response
            .results
            .into_iter()
            .map(|result| FileInsertResult {
                path: result.path,
                success: result.success,
                result: result.result.map(map_insert_response),
                error: empty_option_to_none(result.error),
            })
            .collect(),
        metrics: map_request_metrics(response.metrics),
        total_inserted_row_count: response.total_inserted_row_count as usize,
        total_inserted_record_batches: response.total_inserted_record_batches as usize,
    }
}

pub(crate) fn map_get_indexed_row_count_response(
    response: table::GetIndexedRowCountResponse,
) -> Result<TableIndexedCountResponse, CoralClientError> {
    let primary = response.primary.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "indexed row count response is missing primary counts".to_string(),
        )
    })?;

    Ok(TableIndexedCountResponse {
        total_row_count: primary.total_row_count,
        indexed_counts: primary
            .indexed_counts
            .into_iter()
            .map(map_indexed_count_from_proto)
            .collect(),
        readable: response.readable.map(map_table_indexed_count_from_proto),
    })
}

pub(crate) fn map_create_status_response(
    response: table::GetCreateStatusResponse,
) -> Result<coral_models::api::CreateStatusResponse, CoralClientError> {
    Ok(coral_models::api::CreateStatusResponse {
        table_name: response.table_name,
        status: response.status,
        started_at: empty_option_to_none(response.started_at),
        failure: response.failure.map(map_table_operation_failure_from_proto),
        polling: response.polling.map(map_table_operation_polling_from_proto),
    })
}

pub(crate) fn map_get_schema_from_parquet_request(
    request: &Paths,
    internal: bool,
) -> Result<utility::GetSchemaFromParquetRequest, CoralClientError> {
    Ok(utility::GetSchemaFromParquetRequest {
        paths: Some(map_paths_to_proto(request.clone())?),
        internal_schema: internal.then_some(true),
    })
}

pub(crate) fn map_get_schema_from_parquet_response(
    response: utility::GetSchemaFromParquetResponse,
) -> Result<ParquetSchemaInfo, CoralClientError> {
    Ok(ParquetSchemaInfo {
        columns: response
            .columns
            .into_iter()
            .map(map_column_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        primary_key: response.primary_key,
        segmentation: response
            .segmentation
            .map(map_external_segmentation_from_proto)
            .transpose()?,
        indexes: response
            .indexes
            .into_iter()
            .map(map_external_index_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        schema: response
            .schema
            .map(|schema| schema_from_ipc(&schema.arrow_schema_ipc))
            .transpose()?,
    })
}

pub(crate) fn map_list_tables_response(
    response: table::ListTablesResponse,
) -> Result<Vec<TableView>, CoralClientError> {
    response
        .tables
        .into_iter()
        .map(map_table_from_proto)
        .collect()
}

pub(crate) fn map_get_table_response(
    response: table::GetTableResponse,
) -> Result<TableView, CoralClientError> {
    let table = response.table.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "get table response is missing table payload".to_string(),
        )
    })?;

    map_table_from_proto(table)
}

pub(crate) fn map_list_nodes_response(
    response: node::ListNodesResponse,
) -> Result<Vec<NodeRecord>, CoralClientError> {
    response
        .nodes
        .into_iter()
        .map(|record| {
            let node_info = record.node_info.ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(
                    "list nodes response contained a node without node_info".to_string(),
                )
            })?;
            Ok(NodeRecord {
                node_id: record.node_id,
                node_info: map_node_info_from_proto(node_info)?,
            })
        })
        .collect()
}

pub(crate) fn map_get_node_response(
    response: node::GetNodeResponse,
) -> Result<NodeInfo, CoralClientError> {
    let node_info = response.node.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "get node response is missing node payload".to_string(),
        )
    })?;

    map_node_info_from_proto(node_info)
}

pub(crate) fn map_ping_node_response(response: node::PingNodeResponse) -> NodePingResponse {
    NodePingResponse {
        node_name: response.node_name,
        result: response.result,
    }
}

pub(crate) fn map_vdb_resource_usage_response(
    response: node::GetVdbResourceUsageResponse,
) -> Result<VdbResourceUsageResponse, CoralClientError> {
    Ok(VdbResourceUsageResponse {
        nodes: response
            .nodes
            .into_iter()
            .map(map_node_resource_usage_result_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        total_memory_bytes: response.total_memory_bytes,
        total_disk_bytes: response.total_disk_bytes,
    })
}

pub(crate) fn map_node_sync_errors_response(
    response: node::GetNodeSyncErrorsResponse,
) -> Result<NodeSyncErrorsResponse, CoralClientError> {
    Ok(NodeSyncErrorsResponse {
        node_id: response.node_id,
        sync_error_info: response
            .sync_error_info
            .map(map_sync_error_info_from_proto)
            .transpose()?
            .unwrap_or_else(SyncErrorInfo::empty),
    })
}

pub(crate) fn map_all_sync_errors_response(
    response: node::GetAllSyncErrorsResponse,
) -> Result<AllSyncErrorsResponse, CoralClientError> {
    Ok(AllSyncErrorsResponse {
        nodes: response
            .nodes
            .into_iter()
            .map(map_node_sync_errors_response)
            .collect::<Result<Vec<_>, _>>()?,
    })
}

pub(crate) fn map_insert_options(params: &InsertQueryParams) -> ingest::InsertOptions {
    ingest::InsertOptions {
        use_async_read: params.use_async_read,
        reader_batch_size: params.reader_batch_size.map(|value| value as u32),
    }
}

pub(crate) fn map_insert_response(response: ingest::InsertResponse) -> DataInsertResult {
    DataInsertResult {
        inserted_record_batches: response.inserted_record_batches as usize,
        inserted_row_count: response.inserted_row_count as usize,
        elapsed_time: response.elapsed_time,
    }
}

pub(crate) fn map_scan_request(
    table_name: &str,
    request: &DataScanRequest,
    params: &ScanQueryParams,
) -> query::ScanTableDataRequest {
    query::ScanTableDataRequest {
        table_name: table_name.to_string(),
        options: Some(query::ScanRequestOptions {
            include_metrics: params.include_metrics,
            allow_writer: params.allow_writer,
            include_internal_columns: params.include_internal_columns,
        }),
        projection: request.projection.clone(),
        filter: request.filter.clone(),
        limit: request.limit,
    }
}

pub(crate) fn map_data_plan_request(
    table_name: &str,
    request: &ModelDataPlanRequest,
) -> query::DataPlanRequest {
    query::DataPlanRequest {
        table_name: table_name.to_string(),
        projection: request.projection.clone(),
        filter: request.filter.clone(),
        allow_writer: request.allow_writer,
    }
}

pub(crate) fn map_data_plan_response(
    response: query::DataPlanResponse,
) -> Result<ModelDataPlanResponse, CoralClientError> {
    Ok(ModelDataPlanResponse {
        table_name: response.table_name,
        filter: empty_option_to_none(response.filter),
        segment_pruning: response
            .segment_pruning
            .map(map_segment_pruning_info_from_proto)
            .transpose()?,
        segments: response
            .segments
            .into_iter()
            .map(map_segment_plan_detail_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        final_distribution: response
            .final_distribution
            .into_iter()
            .map(map_node_search_ranges_from_proto)
            .collect(),
        empty_range_diagnostics: response
            .empty_range_diagnostics
            .into_iter()
            .map(map_empty_range_diagnostic_from_proto)
            .collect(),
        raw_node_assignments: response
            .raw_node_assignments
            .into_iter()
            .map(map_raw_node_assignments_from_proto)
            .collect(),
    })
}

pub(crate) fn map_vector_search_request(
    table_name: &str,
    index_name: &str,
    request: &VectorSearchRequest,
    params: &SearchQueryParams,
) -> Result<query::VectorSearchRequest, CoralClientError> {
    Ok(query::VectorSearchRequest {
        table_name: table_name.to_string(),
        index_name: index_name.to_string(),
        options: Some(query::SearchRequestOptions {
            allow_writer: params.allow_writer,
        }),
        top_k: request.top_k,
        query: Some(map_query_vectors(&request.query)?),
        projection: request.projection.clone(),
        filter: request.filter.clone(),
    })
}

pub(crate) fn map_vector_search_exact_knn_request(
    table_name: &str,
    index_name: &str,
    request: &VectorSearchExactKnnRequest,
    params: &SearchQueryParams,
) -> Result<query::VectorSearchExactKnnRequest, CoralClientError> {
    Ok(query::VectorSearchExactKnnRequest {
        table_name: table_name.to_string(),
        index_name: index_name.to_string(),
        options: Some(query::SearchRequestOptions {
            allow_writer: params.allow_writer,
        }),
        top_k: request.top_k,
        query: Some(map_query_vectors(&request.query)?),
        projection: request.projection.clone(),
        filter: request.filter.clone(),
    })
}

pub(crate) fn map_hybrid_search_request(
    table_name: &str,
    request: &HybridVectorSearchRequest,
    params: &SearchQueryParams,
) -> query::HybridSearchRequest {
    query::HybridSearchRequest {
        table_name: table_name.to_string(),
        options: Some(query::SearchRequestOptions {
            allow_writer: params.allow_writer,
        }),
        top_k: request.top_k,
        dense: Some(map_dense_vector_search_config_to_proto(
            request.dense.clone(),
        )),
        sparse: Some(map_sparse_vector_search_config_to_proto(
            request.sparse.clone(),
        )),
        fusion: Some(map_fusion_config_to_proto(request.fusion.clone())),
        projection: request.projection.clone(),
        filter: request.filter.clone(),
    }
}

pub(crate) fn map_export_request(
    table_name: &str,
    request: &DataExportRequest,
) -> Result<export_proto::ExportTableDataRequest, CoralClientError> {
    Ok(export_proto::ExportTableDataRequest {
        table_name: table_name.to_string(),
        options: Some(export_proto::ExportQueryOptions {
            include_internal_columns: request.include_internal_columns,
        }),
        request: Some(export_proto::ExportTableDataBody {
            export_paths: Some(map_paths_to_proto(request.export_paths.clone())?),
            format: map_file_format_to_proto(request.format.clone()) as i32,
            projection: request.projection.clone(),
            filter: request.filter.clone(),
            limit: request.limit,
            mode: map_export_mode_to_proto(request.mode.clone()) as i32,
            row_group_size: request.row_group_size.map(|value| value as u64),
            target_file_size_bytes: request.target_file_size_bytes.map(|value| value as u64),
            max_row_groups_per_file: request.max_row_groups_per_file.map(|value| value as u64),
            include_metrics: request.include_metrics,
            allow_writer: request.allow_writer,
            include_internal_columns: request.include_internal_columns,
        }),
    })
}

pub(crate) fn map_export_response(
    response: export_proto::ExportTableDataResponse,
) -> Result<DataExportResponse, CoralClientError> {
    let export_result = response.export_result.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "export response is missing export_result".to_string(),
        )
    })?;

    Ok(DataExportResponse {
        export_result: coral_models::api::data::ExportResult {
            output_prefix: export_result.output_prefix,
            files: export_result.files,
            mode: map_export_mode_from_proto(export_result.mode)?,
            total_row_count: export_result.total_row_count as usize,
            total_uncompressed_byte_size: export_result.total_uncompressed_byte_size as usize,
            num_row_groups: export_result.num_row_groups as usize,
            average_uncompressed_row_group_size: export_result.average_uncompressed_row_group_size
                as usize,
        },
        metrics: map_request_metrics(response.metrics),
    })
}

pub(crate) fn map_export_download_request(
    table_name: &str,
    params: &DataExportDownloadQueryParams,
) -> export_proto::ExportTableDataDownloadRequest {
    export_proto::ExportTableDataDownloadRequest {
        table_name: table_name.to_string(),
        options: Some(export_proto::ExportTableDataDownloadOptions {
            format: map_file_format_to_proto(Some(params.format.clone())) as i32,
            row_group_size: params.row_group_size.map(|value| value as u64),
            allow_writer: params.allow_writer,
            projection: params.projection.clone(),
            filter: params.filter.clone(),
            limit: params.limit,
            include_internal_columns: params.include_internal_columns,
        }),
    }
}

pub(crate) fn map_update_table_data_request(
    table_name: &str,
    request: &DataUpdateRequest,
) -> ingest::UpdateTableDataRequest {
    ingest::UpdateTableDataRequest {
        table_name: table_name.to_string(),
        update_condition: request.update_condition.clone(),
        update_values: request.update_values.clone(),
    }
}

pub(crate) fn map_delete_table_data_request(
    table_name: &str,
    request: &DataDeleteRequest,
) -> ingest::DeleteTableDataRequest {
    ingest::DeleteTableDataRequest {
        table_name: table_name.to_string(),
        delete_condition: request.delete_condition.clone(),
    }
}

fn map_sync_mode_to_proto(sync_mode: SyncMode) -> table::SyncMode {
    match sync_mode {
        SyncMode::Async => table::SyncMode::Async,
        SyncMode::WriterSync => table::SyncMode::WriterSync,
        SyncMode::ReaderSync => table::SyncMode::ReaderSync,
    }
}

fn map_segment_retry_mode_to_proto(mode: &SegmentRetryMode) -> segment::SegmentRetryMode {
    match mode {
        SegmentRetryMode::Auto => segment::SegmentRetryMode::Auto,
        SegmentRetryMode::Create => segment::SegmentRetryMode::Create,
        SegmentRetryMode::Rebalance => segment::SegmentRetryMode::Rebalance,
    }
}

fn map_rebalance_strategy_to_proto(strategy: RebalanceStrategy) -> segment::RebalanceStrategy {
    match strategy {
        RebalanceStrategy::BalancedMinMoves => segment::RebalanceStrategy::BalancedMinMoves,
        RebalanceStrategy::StrictAlgorithmic => segment::RebalanceStrategy::StrictAlgorithmic,
    }
}

fn map_cache_entry_type_to_proto(value: CacheEntryType) -> catalog::CacheEntryType {
    match value {
        CacheEntryType::Node => catalog::CacheEntryType::Node,
        CacheEntryType::Table => catalog::CacheEntryType::Table,
        CacheEntryType::Segment => catalog::CacheEntryType::Segment,
    }
}

fn map_segments_retry_node_result(
    result: segment::SegmentsRetryNodeResult,
) -> Result<SegmentsRetryNodeResult, CoralClientError> {
    let observations = result.observations.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "segments retry node result is missing observations".to_string(),
        )
    })?;

    Ok(SegmentsRetryNodeResult {
        node_id: result.node_id,
        published_segments: result.published_segments,
        skipped: result.skipped.map(|skipped| SegmentsRetrySkipInfo {
            reason: skipped.reason,
        }),
        observations: map_segments_retry_node_observations(observations),
    })
}

fn map_segments_retry_node_observations(
    observations: segment::SegmentsRetryNodeObservations,
) -> SegmentsRetryNodeObservations {
    SegmentsRetryNodeObservations {
        missing_nodeinfo: observations.missing_nodeinfo,
        missing_table_assignment: observations.missing_table_assignment,
        missing_segment_count: observations.missing_segment_count,
        failed_segment_count: observations.failed_segment_count,
        synced_segment_count: observations.synced_segment_count,
        not_removed_segment_count: observations.not_removed_segment_count,
    }
}

fn map_segments_status_mode_from_proto(value: i32) -> Result<SegmentsStatusMode, CoralClientError> {
    match segment::SegmentsStatusMode::try_from(value)
        .unwrap_or(segment::SegmentsStatusMode::Unspecified)
    {
        segment::SegmentsStatusMode::Active => Ok(SegmentsStatusMode::Active),
        segment::SegmentsStatusMode::Create => Ok(SegmentsStatusMode::Create),
        segment::SegmentsStatusMode::Rebalance => Ok(SegmentsStatusMode::Rebalance),
        segment::SegmentsStatusMode::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "segments status mode is unspecified".to_string(),
        )),
    }
}

fn map_cache_entry_dump_from_proto(
    entry: catalog::CacheEntryDump,
) -> Result<CatalogCacheEntry, CoralClientError> {
    Ok(CatalogCacheEntry {
        key: entry.key,
        cache_type: map_cache_entry_type_from_proto(entry.cache_type)?,
        created_at: UNIX_EPOCH + Duration::from_millis(entry.created_at_epoch_millis),
        ttl: Duration::from_secs(entry.ttl_seconds),
        invalidated: entry.invalidated,
        value: entry
            .value
            .map(map_cache_entry_value_from_proto)
            .transpose()?,
    })
}

fn map_cache_entry_value_from_proto(
    value: catalog::CacheEntryValue,
) -> Result<CacheEntryValue, CoralClientError> {
    let kind = value.kind.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse("cache entry value is missing kind".to_string())
    })?;

    match kind {
        catalog::cache_entry_value::Kind::NodeInfo(value) => {
            Ok(CacheEntryValue::Node(map_node_info_from_proto(value)?))
        }
        catalog::cache_entry_value::Kind::TableInfo(value) => {
            Ok(CacheEntryValue::Table(map_table_info_from_proto(value)?))
        }
        catalog::cache_entry_value::Kind::SegmentInfo(value) => Ok(CacheEntryValue::Segment(
            map_segment_info_from_proto(value)?,
        )),
    }
}

fn map_table_info_from_proto(
    value: catalog::TableInfo,
) -> Result<CatalogTableInfo, CoralClientError> {
    Ok(CatalogTableInfo {
        table_name: value.table_name,
        version: value.version,
        format_version: value.format_version,
        oid: value.oid,
        schema: schema_from_ipc(
            &value
                .schema
                .ok_or_else(|| {
                    CoralClientError::InvalidGrpcResponse(
                        "cache table value is missing schema".to_string(),
                    )
                })?
                .arrow_schema_ipc,
        )?,
        segmentation_info: value
            .segmentation_info
            .map(map_segmentation_info_from_proto)
            .transpose()?,
        index_info: Some(
            value
                .index_info
                .into_iter()
                .map(map_index_info_from_proto)
                .collect::<Result<Vec<_>, _>>()?,
        ),
        active_set_size_limit: value.active_set_size_limit,
        max_threads: value.max_threads,
        segments: value
            .segments
            .into_iter()
            .map(|segment| coral_models::catalog::SegmentReference {
                segment_id: segment.segment_id,
                segment_oid: segment.segment_oid,
            })
            .collect(),
        status: value
            .status
            .map(map_table_operational_status_from_proto)
            .transpose()?,
        rebalancing_context: value
            .rebalancing_context
            .map(map_table_rebalancing_context_from_proto)
            .transpose()?,
        creation_context: value
            .creation_context
            .map(map_table_creation_context_from_proto)
            .transpose()?,
    })
}

fn map_segment_info_from_proto(
    value: catalog::SegmentInfo,
) -> Result<SegmentInfo, CoralClientError> {
    Ok(SegmentInfo {
        oid: value.oid,
        version: value.version,
        format_version: value.format_version,
        kafka_info: value
            .kafka_info
            .map(map_kafka_info_from_proto)
            .ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(
                    "cache segment value is missing kafka info".to_string(),
                )
            })?,
        column_min_max: value
            .column_min_max
            .into_iter()
            .map(|(column, value)| Ok((column, map_column_min_max_value_from_proto(value)?)))
            .collect::<Result<HashMap<_, _>, CoralClientError>>()?,
        reader: value.reader,
        writer: value.writer,
        migration_source: value
            .migration_source
            .map(|value| CatalogSegmentAssignmentSnapshot {
                readers: value.readers,
                writer: value.writer,
            }),
    })
}

fn map_column_min_max_value_from_proto(
    value: catalog::ColumnMinMaxValue,
) -> Result<ColumnMinMaxValue, CoralClientError> {
    Ok(ColumnMinMaxValue {
        min: map_scalar_value_from_proto(value.min.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "cache column min/max value is missing min".to_string(),
            )
        })?)?,
        max: map_scalar_value_from_proto(value.max.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "cache column min/max value is missing max".to_string(),
            )
        })?)?,
    })
}

fn map_scalar_value_from_proto(
    value: common::ScalarValue,
) -> Result<serde_json::Value, CoralClientError> {
    let kind = value.kind.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse("scalar value is missing kind".to_string())
    })?;

    match kind {
        common::scalar_value::Kind::BoolValue(value) => Ok(serde_json::Value::Bool(value)),
        common::scalar_value::Kind::Int64Value(value) => {
            Ok(serde_json::Value::Number(value.into()))
        }
        common::scalar_value::Kind::DoubleValue(value) => serde_json::Number::from_f64(value)
            .map(serde_json::Value::Number)
            .ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(
                    "scalar value contains non-finite f64".to_string(),
                )
            }),
        common::scalar_value::Kind::StringValue(value) => Ok(serde_json::Value::String(value)),
    }
}

fn map_kafka_info_from_proto(value: catalog::KafkaInfo) -> coral_models::catalog::KafkaInfo {
    coral_models::catalog::KafkaInfo {
        topic: value.topic,
        partition: value.partition,
    }
}

fn map_table_operational_status_from_proto(
    value: i32,
) -> Result<coral_models::catalog::TableOperationalStatus, CoralClientError> {
    match catalog::TableOperationalStatus::try_from(value)
        .unwrap_or(catalog::TableOperationalStatus::Unspecified)
    {
        catalog::TableOperationalStatus::Active => {
            Ok(coral_models::catalog::TableOperationalStatus::Active)
        }
        catalog::TableOperationalStatus::CreatingInProgress => {
            Ok(coral_models::catalog::TableOperationalStatus::CreatingInProgress)
        }
        catalog::TableOperationalStatus::CreatingFailed => {
            Ok(coral_models::catalog::TableOperationalStatus::CreatingFailed)
        }
        catalog::TableOperationalStatus::PreparingRebalance => {
            Ok(coral_models::catalog::TableOperationalStatus::PreparingRebalance)
        }
        catalog::TableOperationalStatus::RebalancingInProgress => {
            Ok(coral_models::catalog::TableOperationalStatus::RebalancingInProgress)
        }
        catalog::TableOperationalStatus::RebalancingFailed => {
            Ok(coral_models::catalog::TableOperationalStatus::RebalancingFailed)
        }
        catalog::TableOperationalStatus::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "cache table operational status is unspecified".to_string(),
        )),
    }
}

fn map_table_rebalancing_context_from_proto(
    value: catalog::TableRebalancingContext,
) -> Result<coral_models::catalog::RebalancingContext, CoralClientError> {
    Ok(coral_models::catalog::RebalancingContext {
        reader_nodes: some_if_not_empty(value.reader_nodes),
        writer_nodes: some_if_not_empty(value.writer_nodes),
        strategy: empty_option_to_none(value.strategy),
        started_at: empty_option_to_none(value.started_at),
        failure: value
            .failure
            .map(map_catalog_table_operation_failure_from_proto)
            .transpose()?,
    })
}

fn map_table_creation_context_from_proto(
    value: catalog::TableCreationContext,
) -> Result<coral_models::catalog::CreationContext, CoralClientError> {
    Ok(coral_models::catalog::CreationContext {
        started_at: empty_option_to_none(value.started_at),
        failure: value
            .failure
            .map(map_catalog_table_operation_failure_from_proto)
            .transpose()?,
    })
}

fn map_catalog_table_operation_failure_from_proto(
    value: catalog::TableOperationFailure,
) -> Result<TableOperationFailure, CoralClientError> {
    Ok(TableOperationFailure {
        summary: value.summary,
        detected_at: value.detected_at,
        node_failures: value
            .node_failures
            .into_iter()
            .map(|failure| {
                Ok(TableOperationNodeFailure {
                    node_id: failure.node_id,
                    segments: failure
                        .segments
                        .into_iter()
                        .map(|segment| {
                            Ok(TableOperationSegmentFailure {
                                segment_id: segment.segment_id,
                                status: map_segment_assignment_status_from_proto(segment.status)?,
                                failure_reason: segment.failure_reason,
                            })
                        })
                        .collect::<Result<Vec<_>, CoralClientError>>()?,
                })
            })
            .collect::<Result<Vec<_>, CoralClientError>>()?,
    })
}

fn map_cache_entry_type_from_proto(value: i32) -> Result<CacheEntryType, CoralClientError> {
    match catalog::CacheEntryType::try_from(value).unwrap_or(catalog::CacheEntryType::Unspecified) {
        catalog::CacheEntryType::Node => Ok(CacheEntryType::Node),
        catalog::CacheEntryType::Table => Ok(CacheEntryType::Table),
        catalog::CacheEntryType::Segment => Ok(CacheEntryType::Segment),
        catalog::CacheEntryType::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "cache entry type is unspecified".to_string(),
        )),
    }
}

fn map_rebalance_strategy_from_proto(value: i32) -> Result<RebalanceStrategy, CoralClientError> {
    match segment::RebalanceStrategy::try_from(value)
        .unwrap_or(segment::RebalanceStrategy::Unspecified)
    {
        segment::RebalanceStrategy::BalancedMinMoves => Ok(RebalanceStrategy::BalancedMinMoves),
        segment::RebalanceStrategy::StrictAlgorithmic => Ok(RebalanceStrategy::StrictAlgorithmic),
        segment::RebalanceStrategy::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "rebalance strategy is unspecified".to_string(),
        )),
    }
}

fn map_rebalance_plan_summary_from_proto(
    summary: segment::RebalancePlanSummary,
) -> RebalancePlanSummary {
    RebalancePlanSummary {
        total_segments: summary.total_segments,
        writer_moves: summary.writer_moves,
        reader_moves: summary.reader_moves,
        unchanged_count: summary.unchanged_count,
        writer_load_before: summary
            .writer_load_before
            .into_iter()
            .map(map_rebalance_node_load_from_proto)
            .collect(),
        writer_load_after: summary
            .writer_load_after
            .into_iter()
            .map(map_rebalance_node_load_from_proto)
            .collect(),
        reader_load_before: summary
            .reader_load_before
            .into_iter()
            .map(map_rebalance_node_load_from_proto)
            .collect(),
        reader_load_after: summary
            .reader_load_after
            .into_iter()
            .map(map_rebalance_node_load_from_proto)
            .collect(),
    }
}

fn map_rebalance_node_load_from_proto(load: segment::RebalanceNodeLoad) -> RebalanceNodeLoad {
    RebalanceNodeLoad {
        node_id: load.node_id,
        count: load.count,
    }
}

fn map_rebalance_segment_entry_from_proto(
    entry: segment::RebalanceSegmentEntry,
) -> Result<RebalanceSegmentEntry, CoralClientError> {
    let before = entry.before.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance segment entry is missing before".to_string(),
        )
    })?;
    let after = entry.after.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance segment entry is missing after".to_string(),
        )
    })?;
    let changed = entry.changed.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance segment entry is missing changed".to_string(),
        )
    })?;

    Ok(RebalanceSegmentEntry {
        segment_id: entry.segment_id,
        before: map_rebalance_segment_side_from_proto(before),
        after: map_rebalance_segment_side_from_proto(after),
        changed: RebalanceSegmentChangeFlag {
            writer: changed.writer,
            readers: changed.readers,
        },
    })
}

fn map_rebalance_segment_side_from_proto(
    side: segment::RebalanceSegmentSide,
) -> RebalanceSegmentSide {
    RebalanceSegmentSide {
        writer: side.writer,
        readers: side.readers,
    }
}

fn map_segment_structure_snapshot_to_proto(
    snapshot: SegmentStructureSnapshot,
) -> segment::SegmentStructureSnapshot {
    segment::SegmentStructureSnapshot {
        segmentation_info: snapshot
            .segmentation_info
            .map(map_segmentation_info_to_proto),
        segment_ids: snapshot.segment_ids,
        segment_assignments: snapshot
            .segment_assignments
            .into_iter()
            .map(|(segment_id, assignment)| {
                (
                    segment_id,
                    segment::SegmentAssignmentSnapshot {
                        segment_id: assignment.segment_id,
                        readers: assignment.readers,
                        writer: assignment.writer,
                    },
                )
            })
            .collect(),
    }
}

fn map_segment_structure_snapshot_from_proto(
    snapshot: segment::SegmentStructureSnapshot,
) -> Result<SegmentStructureSnapshot, CoralClientError> {
    Ok(SegmentStructureSnapshot {
        segmentation_info: snapshot
            .segmentation_info
            .map(map_segmentation_info_from_proto)
            .transpose()?,
        segment_ids: snapshot.segment_ids,
        segment_assignments: snapshot
            .segment_assignments
            .into_iter()
            .map(|(segment_id, assignment)| {
                Ok((
                    segment_id,
                    RebalanceSegmentAssignmentSnapshot {
                        segment_id: assignment.segment_id,
                        readers: assignment.readers,
                        writer: assignment.writer,
                    },
                ))
            })
            .collect::<Result<HashMap<_, _>, CoralClientError>>()?,
    })
}

fn map_rebalance_commit_request_from_proto(
    request: segment::RebalanceCommitRequest,
) -> Result<RebalanceCommitRequest, CoralClientError> {
    let expected_segment_structure = request.expected_segment_structure.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "rebalance commit request is missing expected_segment_structure".to_string(),
        )
    })?;

    Ok(RebalanceCommitRequest {
        reader_nodes: some_if_not_empty(request.reader_nodes),
        writer_nodes: some_if_not_empty(request.writer_nodes),
        strategy: request
            .strategy
            .map(map_rebalance_strategy_from_proto)
            .transpose()?,
        expected_table_version: request.expected_table_version,
        expected_segment_structure: map_segment_structure_snapshot_from_proto(
            expected_segment_structure,
        )?,
    })
}

fn map_segments_status_summary_from_proto(
    summary: segment::SegmentsStatusSummary,
) -> SegmentsStatusSummary {
    SegmentsStatusSummary {
        total: summary.total,
        synced: summary.synced,
        failed: summary.failed,
        pending: summary.pending,
    }
}

fn map_table_operation_failure_from_proto(
    failure: segment::TableOperationFailure,
) -> TableOperationFailure {
    TableOperationFailure {
        summary: failure.summary,
        detected_at: failure.detected_at,
        node_failures: failure
            .node_failures
            .into_iter()
            .map(map_table_operation_node_failure_from_proto)
            .collect(),
    }
}

fn map_table_operation_node_failure_from_proto(
    failure: segment::TableOperationNodeFailure,
) -> TableOperationNodeFailure {
    TableOperationNodeFailure {
        node_id: failure.node_id,
        segments: failure
            .segments
            .into_iter()
            .map(map_table_operation_segment_failure_from_proto)
            .collect(),
    }
}

fn map_table_operation_segment_failure_from_proto(
    failure: segment::TableOperationSegmentFailure,
) -> TableOperationSegmentFailure {
    TableOperationSegmentFailure {
        segment_id: failure.segment_id,
        status: map_segment_assignment_status_from_proto(failure.status as i32)
            .unwrap_or(SegmentAssignmentStatus::Unknown),
        failure_reason: failure.failure_reason,
    }
}

fn map_table_operation_polling_from_proto(
    polling: segment::TableOperationPollingInfo,
) -> TableOperationPollingInfo {
    TableOperationPollingInfo {
        evaluated_at: polling.evaluated_at,
        nodes: polling
            .nodes
            .into_iter()
            .map(map_table_operation_node_segment_status_from_proto)
            .collect(),
    }
}

fn map_table_operation_node_segment_status_from_proto(
    node_status: segment::TableOperationNodeSegmentStatus,
) -> TableOperationNodeSegmentStatus {
    TableOperationNodeSegmentStatus {
        node_id: node_status.node_id,
        segments: node_status
            .segments
            .into_iter()
            .map(map_table_operation_segment_status_from_proto)
            .collect(),
    }
}

fn map_table_operation_segment_status_from_proto(
    status: segment::TableOperationSegmentStatus,
) -> TableOperationSegmentStatus {
    TableOperationSegmentStatus {
        segment_id: status.segment_id,
        expected: map_table_operation_segment_expectation_from_proto(status.expected),
        observed: map_table_operation_observed_segment_status_from_proto(status.observed),
        failure_reason: empty_option_to_none(status.failure_reason),
    }
}

fn map_table_operation_segment_expectation_from_proto(
    value: i32,
) -> TableOperationSegmentExpectation {
    match segment::TableOperationSegmentExpectation::try_from(value)
        .unwrap_or(segment::TableOperationSegmentExpectation::Unspecified)
    {
        segment::TableOperationSegmentExpectation::Remove => {
            TableOperationSegmentExpectation::Remove
        }
        segment::TableOperationSegmentExpectation::Add
        | segment::TableOperationSegmentExpectation::Unspecified => {
            TableOperationSegmentExpectation::Add
        }
    }
}

fn map_table_operation_observed_segment_status_from_proto(
    value: i32,
) -> TableOperationObservedSegmentStatus {
    match segment::TableOperationObservedSegmentStatus::try_from(value)
        .unwrap_or(segment::TableOperationObservedSegmentStatus::Unspecified)
    {
        segment::TableOperationObservedSegmentStatus::Syncing => {
            TableOperationObservedSegmentStatus::Syncing
        }
        segment::TableOperationObservedSegmentStatus::Synced => {
            TableOperationObservedSegmentStatus::Synced
        }
        segment::TableOperationObservedSegmentStatus::Removing => {
            TableOperationObservedSegmentStatus::Removing
        }
        segment::TableOperationObservedSegmentStatus::Failed => {
            TableOperationObservedSegmentStatus::Failed
        }
        segment::TableOperationObservedSegmentStatus::Unknown
        | segment::TableOperationObservedSegmentStatus::Unspecified => {
            TableOperationObservedSegmentStatus::Unknown
        }
        segment::TableOperationObservedSegmentStatus::Deleted => {
            TableOperationObservedSegmentStatus::Deleted
        }
        segment::TableOperationObservedSegmentStatus::NotTracked => {
            TableOperationObservedSegmentStatus::NotTracked
        }
        segment::TableOperationObservedSegmentStatus::MissingNodeInfo => {
            TableOperationObservedSegmentStatus::MissingNodeInfo
        }
        segment::TableOperationObservedSegmentStatus::MissingTableAssignment => {
            TableOperationObservedSegmentStatus::MissingTableAssignment
        }
        segment::TableOperationObservedSegmentStatus::MissingSegmentAssignment => {
            TableOperationObservedSegmentStatus::MissingSegmentAssignment
        }
    }
}

fn map_segment_pruning_info_from_proto(
    info: query::SegmentPruningInfo,
) -> Result<SegmentPruningInfo, CoralClientError> {
    Ok(SegmentPruningInfo {
        enabled: info.enabled,
        total_segments_available: u64_to_usize(info.total_segments_available),
        segments_pruned: u64_to_usize(info.segments_pruned),
        pruning_filters: info
            .pruning_filters
            .into_iter()
            .map(|filter| coral_models::api::PruningFilter {
                filter_expression: filter.filter_expression,
            })
            .collect(),
    })
}

fn map_segment_plan_detail_from_proto(
    detail: query::SegmentPlanDetail,
) -> Result<SegmentPlanDetail, CoralClientError> {
    Ok(SegmentPlanDetail {
        segment_id: detail.segment_id,
        last_inactive_set: detail.last_inactive_set,
        latest_versions: detail
            .latest_versions
            .into_iter()
            .map(map_set_version_entry_from_proto)
            .collect(),
        readers: detail
            .readers
            .into_iter()
            .map(map_node_set_versions_from_proto)
            .collect(),
        writer: detail
            .writer
            .map(map_node_set_versions_from_proto)
            .ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(
                    "segment plan detail is missing writer".to_string(),
                )
            })?,
        segment_distribution: detail
            .segment_distribution
            .into_iter()
            .map(map_node_search_ranges_from_proto)
            .collect(),
    })
}

fn map_set_version_entry_from_proto(entry: query::SetVersionEntry) -> SetVersionEntry {
    SetVersionEntry {
        set: entry.set,
        version: entry.version,
    }
}

fn map_node_set_versions_from_proto(versions: query::NodeSetVersions) -> NodeSetVersions {
    NodeSetVersions {
        node_id: versions.node_id,
        node_type: versions.node_type,
        last_set_number: versions.last_set_number,
        versions: versions
            .versions
            .into_iter()
            .map(map_set_version_entry_from_proto)
            .collect(),
        num_latest_matches: versions.num_latest_matches,
        num_latest_mismatches: versions.num_latest_mismatches,
    }
}

fn map_node_search_ranges_from_proto(ranges: query::NodeSearchRanges) -> NodeSearchRanges {
    NodeSearchRanges {
        node_id: ranges.node_id,
        node_type: ranges.node_type,
        search_scopes: ranges.search_scopes,
    }
}

fn map_empty_range_diagnostic_from_proto(
    diagnostic: query::EmptyRangeDiagnostic,
) -> EmptyRangeDiagnostic {
    EmptyRangeDiagnostic {
        node_id: diagnostic.node_id,
        node_type: diagnostic.node_type,
        node_address: diagnostic.node_address,
        assigned_segments_for_table: diagnostic.assigned_segments_for_table,
        segment_last_sets: diagnostic
            .segment_last_sets
            .into_iter()
            .map(|entry| (entry.segment_id, entry.last_set_number))
            .collect(),
    }
}

fn map_raw_node_assignments_from_proto(
    assignment: query::RawNodeAssignments,
) -> RawNodeAssignments {
    RawNodeAssignments {
        node_id: assignment.node_id,
        node_type: assignment.node_type,
        node_address: assignment.node_address,
        assigned_segments: assignment
            .assigned_segments
            .into_iter()
            .map(map_node_segment_raw_snapshot_from_proto)
            .collect(),
    }
}

fn map_node_segment_raw_snapshot_from_proto(
    snapshot: query::NodeSegmentRawSnapshot,
) -> NodeSegmentRawSnapshot {
    NodeSegmentRawSnapshot {
        segment_id: snapshot.segment_id,
        last_set_number: snapshot.last_set_number,
        versions: snapshot
            .versions
            .into_iter()
            .map(map_set_version_entry_from_proto)
            .collect(),
    }
}

fn map_table_indexed_count_from_proto(value: table::TableIndexedCount) -> TableIndexedCount {
    TableIndexedCount {
        total_row_count: value.total_row_count,
        indexed_counts: value
            .indexed_counts
            .into_iter()
            .map(map_indexed_count_from_proto)
            .collect(),
    }
}

fn map_indexed_count_from_proto(
    value: table::IndexedCount,
) -> coral_models::api::table::IndexedCount {
    coral_models::api::table::IndexedCount {
        index_name: value.index_name,
        index_type: value.index_type,
        indexed_row_count: value.indexed_row_count,
    }
}

fn map_table_from_proto(table: catalog::Table) -> Result<TableView, CoralClientError> {
    let mut response = TableView {
        table_name: table.table_name,
        configurations: table
            .configurations
            .map(map_table_configurations_from_proto),
        external: None,
        internal: None,
    };

    match table.definition {
        Some(catalog::table::Definition::External(definition)) => {
            response.external = Some(ExternalTableView {
                columns: definition
                    .columns
                    .into_iter()
                    .map(map_column_from_proto)
                    .collect::<Result<Vec<_>, _>>()?,
                primary_key: definition.primary_key,
                segmentation: definition
                    .segmentation
                    .map(map_external_segmentation_from_proto)
                    .transpose()?,
                indexes: definition
                    .indexes
                    .into_iter()
                    .map(map_external_index_from_proto)
                    .collect::<Result<Vec<_>, _>>()?,
            });
        }
        Some(catalog::table::Definition::Internal(definition)) => {
            response.internal = Some(InternalTableView {
                schema: definition
                    .schema
                    .map(|schema| schema_from_ipc(&schema.arrow_schema_ipc))
                    .transpose()?,
                segmentation_info: definition
                    .segmentation_info
                    .map(map_segmentation_info_from_proto)
                    .transpose()?,
                index_info: definition
                    .index_info
                    .into_iter()
                    .map(map_index_info_from_proto)
                    .collect::<Result<Vec<_>, _>>()?,
            });
        }
        None => {}
    }

    Ok(response)
}

fn map_table_configurations_to_proto(
    configurations: TableConfigurations,
) -> catalog::TableConfigurations {
    catalog::TableConfigurations {
        active_set_size_limit: configurations.active_set_size_limit,
        max_threads: configurations.max_threads,
    }
}

fn map_table_configurations_from_proto(
    configurations: catalog::TableConfigurations,
) -> TableConfigurations {
    TableConfigurations {
        active_set_size_limit: configurations.active_set_size_limit,
        max_threads: configurations.max_threads,
    }
}

fn map_table_placement_to_proto(placement: TablePlacement) -> catalog::TablePlacement {
    catalog::TablePlacement {
        assigned_nodes: placement
            .assigned_nodes
            .map(|assigned_nodes| catalog::AssignedNodes {
                writer_nodes: assigned_nodes.writer_nodes,
                reader_nodes: assigned_nodes.reader_nodes,
            }),
    }
}

fn map_column_to_proto(column: Column) -> Result<catalog::Column, CoralClientError> {
    Ok(catalog::Column {
        name: column.name,
        column_type: Some(catalog::ColumnType {
            kind: Some(match column.r#type {
                ColumnType::Scalar(scalar_type) => {
                    catalog::column_type::Kind::Scalar(map_scalar_type_to_proto(scalar_type) as i32)
                }
                ColumnType::Vector(vector_type) => match vector_type {
                    VectorType::DenseVector { element, dim } => {
                        catalog::column_type::Kind::DenseVector(catalog::DenseVectorType {
                            element: map_vector_element_to_proto(element) as i32,
                            dim,
                        })
                    }
                    VectorType::SparseVector => {
                        catalog::column_type::Kind::SparseVector(catalog::SparseVectorType {})
                    }
                },
            }),
        }),
        nullable: column.nullable,
        max_length: column.max_length,
    })
}

fn map_column_from_proto(column: catalog::Column) -> Result<Column, CoralClientError> {
    let column_type = column
        .column_type
        .and_then(|column_type| column_type.kind)
        .ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(format!(
                "column '{}' is missing column_type",
                column.name
            ))
        })?;

    Ok(Column {
        name: column.name,
        r#type: match column_type {
            catalog::column_type::Kind::Scalar(value) => {
                ColumnType::Scalar(map_scalar_type_from_proto(value)?)
            }
            catalog::column_type::Kind::DenseVector(vector) => {
                ColumnType::Vector(VectorType::DenseVector {
                    element: map_vector_element_from_proto(vector.element)?,
                    dim: vector.dim,
                })
            }
            catalog::column_type::Kind::SparseVector(_) => {
                ColumnType::Vector(VectorType::SparseVector)
            }
        },
        nullable: column.nullable,
        max_length: column.max_length,
    })
}

fn map_scalar_type_to_proto(value: ScalarType) -> catalog::ScalarType {
    match value {
        ScalarType::Int64 => catalog::ScalarType::Int64,
        ScalarType::Float64 => catalog::ScalarType::Float64,
        ScalarType::Bool => catalog::ScalarType::Bool,
        ScalarType::String => catalog::ScalarType::String,
    }
}

fn map_scalar_type_from_proto(value: i32) -> Result<ScalarType, CoralClientError> {
    match catalog::ScalarType::try_from(value).unwrap_or(catalog::ScalarType::Unspecified) {
        catalog::ScalarType::Int64 => Ok(ScalarType::Int64),
        catalog::ScalarType::Float64 => Ok(ScalarType::Float64),
        catalog::ScalarType::Bool => Ok(ScalarType::Bool),
        catalog::ScalarType::String => Ok(ScalarType::String),
        catalog::ScalarType::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "scalar type is unspecified".to_string(),
        )),
    }
}

fn map_vector_element_to_proto(value: VectorElement) -> catalog::VectorElement {
    match value {
        VectorElement::Float32 => catalog::VectorElement::Float32,
    }
}

fn map_vector_element_from_proto(value: i32) -> Result<VectorElement, CoralClientError> {
    match catalog::VectorElement::try_from(value).unwrap_or(catalog::VectorElement::Unspecified) {
        catalog::VectorElement::Float32 => Ok(VectorElement::Float32),
        catalog::VectorElement::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "vector element is unspecified".to_string(),
        )),
    }
}

fn map_external_segmentation_to_proto(
    segmentation: ExternalSegmentation,
) -> catalog::ExternalSegmentation {
    catalog::ExternalSegmentation {
        strategy: map_segmentation_strategy_to_proto(segmentation.strategy) as i32,
        columns: segmentation.columns,
        buckets: segmentation.buckets,
        composition: segmentation
            .composition
            .map(|value| map_segmentation_composition_to_proto(value) as i32),
    }
}

fn map_external_segmentation_from_proto(
    segmentation: catalog::ExternalSegmentation,
) -> Result<ExternalSegmentation, CoralClientError> {
    Ok(ExternalSegmentation {
        strategy: map_segmentation_strategy_from_proto(segmentation.strategy)?,
        columns: segmentation.columns,
        buckets: segmentation.buckets,
        composition: segmentation
            .composition
            .map(map_segmentation_composition_from_proto)
            .transpose()?,
    })
}

fn map_segmentation_strategy_to_proto(
    strategy: SegmentationStrategy,
) -> catalog::SegmentationStrategy {
    match strategy {
        SegmentationStrategy::Value => catalog::SegmentationStrategy::Value,
        SegmentationStrategy::Hash => catalog::SegmentationStrategy::Hash,
    }
}

fn map_segmentation_strategy_from_proto(
    value: i32,
) -> Result<SegmentationStrategy, CoralClientError> {
    match catalog::SegmentationStrategy::try_from(value)
        .unwrap_or(catalog::SegmentationStrategy::Unspecified)
    {
        catalog::SegmentationStrategy::Value => Ok(SegmentationStrategy::Value),
        catalog::SegmentationStrategy::Hash => Ok(SegmentationStrategy::Hash),
        catalog::SegmentationStrategy::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "segmentation strategy is unspecified".to_string(),
        )),
    }
}

fn map_segmentation_composition_to_proto(
    value: SegmentationComposition,
) -> catalog::SegmentationComposition {
    match value {
        SegmentationComposition::Single => catalog::SegmentationComposition::Single,
        SegmentationComposition::Hierarchical => catalog::SegmentationComposition::Hierarchical,
        SegmentationComposition::Composite => catalog::SegmentationComposition::Composite,
    }
}

fn map_segmentation_composition_from_proto(
    value: i32,
) -> Result<SegmentationComposition, CoralClientError> {
    match catalog::SegmentationComposition::try_from(value)
        .unwrap_or(catalog::SegmentationComposition::Unspecified)
    {
        catalog::SegmentationComposition::Single => Ok(SegmentationComposition::Single),
        catalog::SegmentationComposition::Hierarchical => Ok(SegmentationComposition::Hierarchical),
        catalog::SegmentationComposition::Composite => Ok(SegmentationComposition::Composite),
        catalog::SegmentationComposition::Unspecified => {
            Err(CoralClientError::InvalidGrpcResponse(
                "segmentation composition is unspecified".to_string(),
            ))
        }
    }
}

fn map_external_index_to_proto(index: ExternalIndex) -> catalog::ExternalIndex {
    catalog::ExternalIndex {
        r#type: index.r#type,
        column: index.column,
        params: index.params.map(map_index_params_to_proto),
    }
}

fn map_external_index_from_proto(
    index: catalog::ExternalIndex,
) -> Result<ExternalIndex, CoralClientError> {
    Ok(ExternalIndex {
        r#type: index.r#type,
        column: index.column,
        params: index.params.map(map_index_params_from_proto).transpose()?,
    })
}

fn map_index_params_to_proto(params: IndexParams) -> catalog::IndexParams {
    catalog::IndexParams {
        space: params.space,
        ef_construction: params.ef_construction,
        m: params.M,
        sparse_model: params.sparse_model,
    }
}

fn map_index_params_from_proto(
    params: catalog::IndexParams,
) -> Result<IndexParams, CoralClientError> {
    Ok(IndexParams {
        space: empty_option_to_none(params.space),
        ef_construction: params.ef_construction,
        M: params.m,
        sparse_model: empty_option_to_none(params.sparse_model),
    })
}

fn map_segmentation_info_to_proto(
    segmentation_info: SegmentationInfo,
) -> catalog::SegmentationInfo {
    catalog::SegmentationInfo {
        segment_type: map_segment_type_to_proto(segmentation_info.segment_type) as i32,
        segment_keys: segmentation_info.segment_keys.unwrap_or_default(),
        num_buckets: segmentation_info.num_buckets,
        segment_key_composition_type: segmentation_info
            .segment_key_composition_type
            .map(|value| map_segment_key_composition_type_to_proto(value) as i32),
    }
}

fn map_segmentation_info_from_proto(
    segmentation_info: catalog::SegmentationInfo,
) -> Result<SegmentationInfo, CoralClientError> {
    Ok(SegmentationInfo {
        segment_type: map_segment_type_from_proto(segmentation_info.segment_type)?,
        segment_keys: some_if_not_empty(segmentation_info.segment_keys),
        num_buckets: segmentation_info.num_buckets,
        segment_key_composition_type: segmentation_info
            .segment_key_composition_type
            .map(map_segment_key_composition_type_from_proto)
            .transpose()?,
    })
}

fn map_segment_type_to_proto(value: SegmentType) -> catalog::SegmentType {
    match value {
        SegmentType::Undefined => catalog::SegmentType::Undefined,
        SegmentType::Value => catalog::SegmentType::Value,
        SegmentType::Hash => catalog::SegmentType::Hash,
    }
}

fn map_segment_type_from_proto(value: i32) -> Result<SegmentType, CoralClientError> {
    match catalog::SegmentType::try_from(value).unwrap_or(catalog::SegmentType::Unspecified) {
        catalog::SegmentType::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "segment type is unspecified".to_string(),
        )),
        catalog::SegmentType::Undefined => Ok(SegmentType::Undefined),
        catalog::SegmentType::Value => Ok(SegmentType::Value),
        catalog::SegmentType::Hash => Ok(SegmentType::Hash),
    }
}

fn map_segment_key_composition_type_to_proto(
    value: SegmentKeyCompositionType,
) -> catalog::SegmentKeyCompositionType {
    match value {
        SegmentKeyCompositionType::Single => catalog::SegmentKeyCompositionType::Single,
        SegmentKeyCompositionType::Hierarchical => catalog::SegmentKeyCompositionType::Hierarchical,
        SegmentKeyCompositionType::Composite => catalog::SegmentKeyCompositionType::Composite,
    }
}

fn map_segment_key_composition_type_from_proto(
    value: i32,
) -> Result<SegmentKeyCompositionType, CoralClientError> {
    match catalog::SegmentKeyCompositionType::try_from(value)
        .unwrap_or(catalog::SegmentKeyCompositionType::Unspecified)
    {
        catalog::SegmentKeyCompositionType::Single => Ok(SegmentKeyCompositionType::Single),
        catalog::SegmentKeyCompositionType::Hierarchical => {
            Ok(SegmentKeyCompositionType::Hierarchical)
        }
        catalog::SegmentKeyCompositionType::Composite => Ok(SegmentKeyCompositionType::Composite),
        catalog::SegmentKeyCompositionType::Unspecified => {
            Err(CoralClientError::InvalidGrpcResponse(
                "segment key composition type is unspecified".to_string(),
            ))
        }
    }
}

fn map_index_info_from_proto(
    index_info: catalog::InternalIndexInfo,
) -> Result<IndexInfoElement, CoralClientError> {
    Ok(IndexInfoElement {
        column_name: index_info.column_name,
        index_type: index_info.index_type,
        parameters: index_info
            .parameters
            .map(map_internal_index_parameters_from_proto)
            .transpose()?,
    })
}

fn map_internal_index_parameters_from_proto(
    params: catalog::IndexParams,
) -> Result<IndexParameters, CoralClientError> {
    Ok(IndexParameters {
        space: empty_option_to_none(params.space),
        ef_construction: params.ef_construction.map(|value| value.to_string()),
        M: params.m.map(|value| value.to_string()),
        sparse_model: empty_option_to_none(params.sparse_model),
    })
}

fn map_node_info_from_proto(node_info: catalog::NodeInfo) -> Result<NodeInfo, CoralClientError> {
    Ok(NodeInfo {
        version: node_info.version,
        format_version: node_info.format_version,
        node_type: map_node_type_from_proto(node_info.node_type)?,
        state: map_node_state_from_proto(node_info.state)?,
        node_stage: map_node_stage_from_proto(node_info.node_stage)?,
        last_updated: node_info.last_updated,
        node_address: node_info.node_address,
        assigned_tables: node_info
            .assigned_tables
            .into_iter()
            .map(|(table_id, assignment)| {
                Ok((
                    table_id,
                    TableAssignment {
                        table_oid: assignment.table_oid,
                        segments: assignment
                            .segments
                            .into_iter()
                            .map(|(segment_id, assignment)| {
                                Ok((
                                    segment_id,
                                    SegmentAssignment {
                                        segment_oid: assignment.segment_oid,
                                        status: map_segment_assignment_status_from_proto(
                                            assignment.status,
                                        )?,
                                        failure_reason: assignment.failure_reason,
                                        checkpoint: map_node_checkpoint_info_from_proto(
                                            assignment.checkpoint.ok_or_else(|| {
                                                CoralClientError::InvalidGrpcResponse(
                                                    "segment assignment is missing checkpoint"
                                                        .to_string(),
                                                )
                                            })?,
                                        ),
                                    },
                                ))
                            })
                            .collect::<Result<HashMap<_, _>, CoralClientError>>()?,
                    },
                ))
            })
            .collect::<Result<HashMap<_, _>, CoralClientError>>()?,
    })
}

fn map_node_type_from_proto(value: i32) -> Result<NodeType, CoralClientError> {
    match catalog::NodeType::try_from(value).unwrap_or(catalog::NodeType::Unspecified) {
        catalog::NodeType::Reader => Ok(NodeType::Reader),
        catalog::NodeType::Writer => Ok(NodeType::Writer),
        catalog::NodeType::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "node type is unspecified".to_string(),
        )),
    }
}

fn map_node_state_from_proto(value: i32) -> Result<NodeState, CoralClientError> {
    match catalog::NodeState::try_from(value).unwrap_or(catalog::NodeState::Unspecified) {
        catalog::NodeState::InRecovery => Ok(NodeState::InRecovery),
        catalog::NodeState::Active => Ok(NodeState::Active),
        catalog::NodeState::Inactive => Ok(NodeState::Inactive),
        catalog::NodeState::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "node state is unspecified".to_string(),
        )),
    }
}

fn map_node_stage_from_proto(value: i32) -> Result<NodeStage, CoralClientError> {
    match catalog::NodeStage::try_from(value).unwrap_or(catalog::NodeStage::Unspecified) {
        catalog::NodeStage::Init => Ok(NodeStage::Init),
        catalog::NodeStage::Loading => Ok(NodeStage::Loading),
        catalog::NodeStage::Subscribing => Ok(NodeStage::Subscribing),
        catalog::NodeStage::Running => Ok(NodeStage::Running),
        catalog::NodeStage::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "node stage is unspecified".to_string(),
        )),
    }
}

fn map_segment_assignment_status_from_proto(
    value: i32,
) -> Result<SegmentAssignmentStatus, CoralClientError> {
    match catalog::SegmentAssignmentStatus::try_from(value)
        .unwrap_or(catalog::SegmentAssignmentStatus::Unspecified)
    {
        catalog::SegmentAssignmentStatus::Syncing => Ok(SegmentAssignmentStatus::Syncing),
        catalog::SegmentAssignmentStatus::Synced => Ok(SegmentAssignmentStatus::Synced),
        catalog::SegmentAssignmentStatus::Removing => Ok(SegmentAssignmentStatus::Removing),
        catalog::SegmentAssignmentStatus::Failed => Ok(SegmentAssignmentStatus::Failed),
        catalog::SegmentAssignmentStatus::Unknown => Ok(SegmentAssignmentStatus::Unknown),
        catalog::SegmentAssignmentStatus::Unspecified => {
            Err(CoralClientError::InvalidGrpcResponse(
                "segment assignment status is unspecified".to_string(),
            ))
        }
    }
}

fn map_node_checkpoint_info_from_proto(
    checkpoint: catalog::NodeCheckpointInfo,
) -> NodeCheckpointInfo {
    NodeCheckpointInfo {
        last_set_number: checkpoint.last_set_number,
        set_versions: checkpoint.set_versions,
        set_index_counts: checkpoint
            .set_index_counts
            .into_iter()
            .map(|(index_name, values)| (index_name, values.values))
            .collect(),
    }
}

fn map_node_resource_usage_result_from_proto(
    result: node::NodeResourceUsageResult,
) -> Result<NodeResourceUsageResult, CoralClientError> {
    Ok(NodeResourceUsageResult {
        node_name: result.node_name,
        node_type: result.node_type,
        resource_usage: result
            .resource_usage
            .map(map_node_resource_usage_from_proto)
            .transpose()?,
        error: empty_option_to_none(result.error),
    })
}

fn map_node_resource_usage_from_proto(
    resource_usage: node::NodeResourceUsage,
) -> Result<NodeResourceUsage, CoralClientError> {
    Ok(NodeResourceUsage {
        tables: resource_usage
            .tables
            .into_iter()
            .map(map_table_resource_usage_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        total_memory_bytes: resource_usage.total_memory_bytes,
        total_disk_bytes: resource_usage.total_disk_bytes,
    })
}

fn map_table_resource_usage_from_proto(
    resource_usage: node::TableResourceUsage,
) -> Result<TableResourceUsage, CoralClientError> {
    Ok(TableResourceUsage {
        table_name: resource_usage.table_name,
        segments: resource_usage
            .segments
            .into_iter()
            .map(map_segment_resource_usage_from_proto)
            .collect::<Result<Vec<_>, _>>()?,
        total_memory_bytes: resource_usage.total_memory_bytes,
        total_disk_bytes: resource_usage.total_disk_bytes,
    })
}

fn map_segment_resource_usage_from_proto(
    resource_usage: node::SegmentResourceUsage,
) -> Result<SegmentResourceUsage, CoralClientError> {
    Ok(SegmentResourceUsage {
        segment_id: resource_usage.segment_id,
        memory_bytes: resource_usage.memory_bytes,
        disk_bytes: resource_usage.disk_bytes,
    })
}

fn map_sync_error_info_from_proto(
    sync_error_info: node::SyncErrorInfo,
) -> Result<SyncErrorInfo, CoralClientError> {
    Ok(SyncErrorInfo::new(
        sync_error_info
            .sync_errors
            .into_iter()
            .map(|(key, values)| (key, values.values))
            .collect::<HashMap<_, _>>(),
    ))
}

fn map_query_vectors(query_vectors: &QueryVectors) -> Result<query::VectorQuery, CoralClientError> {
    Ok(query::VectorQuery {
        query: Some(match query_vectors {
            QueryVectors::Dense {
                vectors,
                parameters,
            } => query::vector_query::Query::Dense(query::DenseQueryVectors {
                vectors: vectors
                    .iter()
                    .cloned()
                    .map(|values| query::FloatVector { values })
                    .collect(),
                parameters: parameters.clone().map(map_dense_search_parameters_to_proto),
            }),
            QueryVectors::Sparse {
                vectors,
                parameters,
                metadata,
            } => query::vector_query::Query::Sparse(query::SparseQueryVectors {
                vectors: vectors.clone(),
                parameters: parameters
                    .clone()
                    .map(map_sparse_search_parameters_to_proto),
                metadata: metadata.clone().map(map_sparse_metadata_to_proto),
            }),
        }),
    })
}

fn map_dense_vector_search_config_to_proto(
    config: DenseVectorSearchConfig,
) -> query::DenseVectorSearchConfig {
    query::DenseVectorSearchConfig {
        column: config.column,
        vectors: config
            .vectors
            .into_iter()
            .map(|values| query::FloatVector { values })
            .collect(),
        parameters: config.parameters.map(map_dense_search_parameters_to_proto),
    }
}

fn map_dense_search_parameters_to_proto(
    params: DenseSearchParameters,
) -> query::DenseSearchParameters {
    query::DenseSearchParameters {
        ef_search: params.ef_search,
    }
}

fn map_sparse_vector_search_config_to_proto(
    config: SparseVectorSearchConfig,
) -> query::SparseVectorSearchConfig {
    query::SparseVectorSearchConfig {
        column: config.column,
        vectors: config.vectors,
        parameters: config.parameters.map(map_sparse_search_parameters_to_proto),
        metadata: config.metadata.map(map_sparse_metadata_to_proto),
    }
}

fn map_sparse_search_parameters_to_proto(
    params: SparseSearchParameters,
) -> query::SparseSearchParameters {
    query::SparseSearchParameters {
        k: params.k,
        b: params.b,
    }
}

fn map_sparse_metadata_to_proto(metadata: SparseMetadata) -> query::SparseMetadata {
    query::SparseMetadata {
        n: metadata.n,
        avgdl: metadata.avgdl,
        df: metadata.df,
    }
}

fn map_fusion_config_to_proto(config: FusionConfig) -> query::FusionConfig {
    query::FusionConfig {
        r#type: config.r#type,
        parameters: config.parameters.map(map_fusion_parameters_to_proto),
    }
}

fn map_fusion_parameters_to_proto(parameters: FusionParameters) -> query::FusionParameters {
    query::FusionParameters {
        k: parameters.k,
        alpha: parameters.alpha,
    }
}

fn map_paths_to_proto(paths: Paths) -> Result<storage::Paths, CoralClientError> {
    Ok(storage::Paths {
        paths: paths.paths,
        storage_config: paths
            .storage_config
            .map(map_storage_config_to_proto)
            .transpose()?,
    })
}

fn map_storage_config_to_proto(
    config: StorageConfig,
) -> Result<storage::StorageConfig, CoralClientError> {
    Ok(storage::StorageConfig {
        storage_type: map_storage_type_to_proto(config.storage_type) as i32,
        bucket: config.bucket,
        credentials: config
            .credentials
            .map(map_cloud_storage_credentials_to_proto),
        options: config.options.map(map_cloud_storage_options_to_proto),
    })
}

fn map_cloud_storage_credentials_to_proto(
    credentials: CloudStorageCredentials,
) -> storage::CloudStorageCredentials {
    storage::CloudStorageCredentials {
        access_key: credentials.access_key,
        secret_key: credentials.secret_key,
    }
}

fn map_cloud_storage_options_to_proto(
    options: CloudStorageOptions,
) -> storage::CloudStorageOptions {
    storage::CloudStorageOptions {
        region: options.region,
        endpoint: options.endpoint,
        virtual_hosted_style: options.virtual_hosted_style,
        allow_http: options.allow_http,
    }
}

fn map_storage_type_to_proto(storage_type: Option<StorageType>) -> storage::StorageType {
    match storage_type.unwrap_or(StorageType::Local) {
        StorageType::Local => storage::StorageType::Local,
        StorageType::Aws => storage::StorageType::Aws,
        StorageType::S3 => storage::StorageType::S3,
        StorageType::Gcp => storage::StorageType::Gcp,
        StorageType::Azure => storage::StorageType::Azure,
        StorageType::Ceph => storage::StorageType::Ceph,
        StorageType::Minio => storage::StorageType::Minio,
        StorageType::S3Compatible => storage::StorageType::S3Compatible,
    }
}

fn map_file_format_to_proto(format: Option<FileFormat>) -> storage::FileFormat {
    match format.unwrap_or(FileFormat::Parquet) {
        FileFormat::Jsonl => storage::FileFormat::Jsonl,
        FileFormat::Parquet => storage::FileFormat::Parquet,
    }
}

fn map_export_mode_to_proto(mode: Option<ExportMode>) -> export_proto::ExportMode {
    match mode.unwrap_or(ExportMode::MultiFile) {
        ExportMode::SingleFile => export_proto::ExportMode::SingleFile,
        ExportMode::MultiFile => export_proto::ExportMode::MultiFile,
    }
}

fn map_export_mode_from_proto(value: i32) -> Result<ExportMode, CoralClientError> {
    match export_proto::ExportMode::try_from(value).unwrap_or(export_proto::ExportMode::Unspecified)
    {
        export_proto::ExportMode::SingleFile => Ok(ExportMode::SingleFile),
        export_proto::ExportMode::MultiFile => Ok(ExportMode::MultiFile),
        export_proto::ExportMode::Unspecified => Err(CoralClientError::InvalidGrpcResponse(
            "export mode is unspecified".to_string(),
        )),
    }
}

fn empty_to_none(value: String) -> Option<String> {
    if value.is_empty() { None } else { Some(value) }
}

fn empty_option_to_none(value: Option<String>) -> Option<String> {
    value.and_then(empty_to_none)
}

fn some_if_not_empty<T>(values: Vec<T>) -> Option<Vec<T>> {
    if values.is_empty() {
        None
    } else {
        Some(values)
    }
}

fn u64_to_usize(value: u64) -> usize {
    value.try_into().unwrap_or(usize::MAX)
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;
    use std::sync::Arc;

    use arrow_ipc::writer::StreamWriter;
    use arrow_schema::{DataType, Field, Schema};

    use super::*;

    fn schema_to_ipc(schema: &Schema) -> Vec<u8> {
        let mut writer =
            StreamWriter::try_new(Vec::new(), &Arc::new(schema.clone())).expect("writer");
        writer.finish().expect("finish");
        writer.into_inner().expect("into inner")
    }

    #[test]
    fn maps_external_table_proto_to_model() {
        let table = catalog::Table {
            table_name: "docs".to_string(),
            configurations: Some(catalog::TableConfigurations {
                active_set_size_limit: Some(1000),
                max_threads: Some(8),
            }),
            definition: Some(catalog::table::Definition::External(
                catalog::ExternalTableDefinition {
                    columns: vec![catalog::Column {
                        name: "id".to_string(),
                        column_type: Some(catalog::ColumnType {
                            kind: Some(catalog::column_type::Kind::Scalar(
                                catalog::ScalarType::Int64 as i32,
                            )),
                        }),
                        nullable: false,
                        max_length: None,
                    }],
                    primary_key: vec!["id".to_string()],
                    segmentation: Some(catalog::ExternalSegmentation {
                        strategy: catalog::SegmentationStrategy::Hash as i32,
                        columns: vec!["id".to_string()],
                        buckets: Some(4),
                        composition: Some(catalog::SegmentationComposition::Single as i32),
                    }),
                    indexes: vec![catalog::ExternalIndex {
                        r#type: "hnsw".to_string(),
                        column: "embedding".to_string(),
                        params: Some(catalog::IndexParams {
                            space: Some("cosinespace".to_string()),
                            ef_construction: Some(200),
                            m: Some(16),
                            sparse_model: None,
                        }),
                    }],
                },
            )),
        };

        let mapped = map_table_from_proto(table).expect("table mapping");
        let external = mapped.external.expect("external definition");

        assert_eq!(mapped.table_name, "docs");
        assert_eq!(external.primary_key, vec!["id".to_string()]);
        assert_eq!(external.columns.len(), 1);
        assert_eq!(
            external.indexes[0]
                .params
                .as_ref()
                .and_then(|params| params.M),
            Some(16)
        );
    }

    #[test]
    fn maps_internal_table_proto_to_model() {
        let schema = Schema::new(vec![Field::new("id", DataType::Int64, false)]);
        let table = catalog::Table {
            table_name: "docs".to_string(),
            configurations: None,
            definition: Some(catalog::table::Definition::Internal(
                catalog::InternalTableDefinition {
                    schema: Some(common::ArrowSchema {
                        arrow_schema_ipc: schema_to_ipc(&schema).into(),
                    }),
                    segmentation_info: Some(catalog::SegmentationInfo {
                        segment_type: catalog::SegmentType::Hash as i32,
                        segment_keys: vec!["id".to_string()],
                        num_buckets: Some(8),
                        segment_key_composition_type: Some(
                            catalog::SegmentKeyCompositionType::Single as i32,
                        ),
                    }),
                    index_info: vec![catalog::InternalIndexInfo {
                        column_name: "embedding".to_string(),
                        index_type: "hnsw".to_string(),
                        parameters: Some(catalog::IndexParams {
                            space: Some("l2space".to_string()),
                            ef_construction: Some(200),
                            m: Some(16),
                            sparse_model: None,
                        }),
                    }],
                },
            )),
        };

        let mapped = map_table_from_proto(table).expect("table mapping");
        let internal = mapped.internal.expect("internal definition");

        assert_eq!(internal.schema.expect("schema").fields().len(), 1);
        assert_eq!(
            internal
                .segmentation_info
                .expect("segmentation")
                .num_buckets,
            Some(8)
        );
        assert_eq!(
            internal.index_info[0]
                .parameters
                .as_ref()
                .and_then(|params| params.M.as_ref())
                .map(String::as_str),
            Some("16")
        );
    }

    #[test]
    fn maps_node_list_response_to_typed_records() {
        let value = map_list_nodes_response(node::ListNodesResponse {
            nodes: vec![catalog::NodeRecord {
                node_id: "reader-1".to_string(),
                node_info: Some(catalog::NodeInfo {
                    version: 1,
                    format_version: 1,
                    node_type: catalog::NodeType::Reader as i32,
                    state: catalog::NodeState::Active as i32,
                    node_stage: catalog::NodeStage::Running as i32,
                    last_updated: "20260310-12:00:00".to_string(),
                    node_address: "127.0.0.1:5001".to_string(),
                    assigned_tables: HashMap::from([(
                        "table-1".to_string(),
                        catalog::TableAssignment {
                            table_oid: "oid-1".to_string(),
                            segments: HashMap::from([(
                                "segment-1".to_string(),
                                catalog::SegmentAssignment {
                                    segment_oid: "segment-oid-1".to_string(),
                                    status: catalog::SegmentAssignmentStatus::Synced as i32,
                                    failure_reason: String::new(),
                                    checkpoint: Some(catalog::NodeCheckpointInfo {
                                        last_set_number: Some(1),
                                        set_versions: vec!["1:1:0:0".to_string()],
                                        set_index_counts: HashMap::from([(
                                            "embedding:hnsw".to_string(),
                                            common::StringValues {
                                                values: vec!["0:10".to_string()],
                                            },
                                        )]),
                                    }),
                                },
                            )]),
                        },
                    )]),
                }),
            }],
        })
        .expect("node mapping");

        assert_eq!(value.len(), 1);
        assert_eq!(value[0].node_id, "reader-1");
        assert_eq!(value[0].node_info.node_type, NodeType::Reader);
    }

    #[test]
    fn maps_active_set_flush_request_to_typed_proto() {
        let request = map_active_set_flush_request(
            "docs",
            &ActiveSetFlushRequest {
                segment_ids: Some(vec!["segment-1".to_string()]),
                sync_mode: SyncMode::ReaderSync,
            },
        );

        assert_eq!(request.table_name, "docs");
        assert_eq!(request.segment_ids, vec!["segment-1".to_string()]);
        assert_eq!(request.sync_mode, table::SyncMode::ReaderSync as i32);
    }

    #[test]
    fn maps_segments_status_response_to_model() {
        let mapped = map_segments_status_response(segment::GetSegmentsStatusResponse {
            table_name: "docs".to_string(),
            table_status: "REBALANCING_FAILED".to_string(),
            mode: segment::SegmentsStatusMode::Rebalance as i32,
            started_at: Some("2026-03-10T12:00:00Z".to_string()),
            ttl_seconds: Some(30),
            failure: Some(segment::TableOperationFailure {
                summary: "failed".to_string(),
                detected_at: "2026-03-10T12:01:00Z".to_string(),
                node_failures: vec![segment::TableOperationNodeFailure {
                    node_id: "reader-1".to_string(),
                    segments: vec![segment::TableOperationSegmentFailure {
                        segment_id: "segment-1".to_string(),
                        status: catalog::SegmentAssignmentStatus::Failed as i32,
                        failure_reason: "io".to_string(),
                    }],
                }],
            }),
            polling: None,
            summary: Some(segment::SegmentsStatusSummary {
                total: 3,
                synced: 1,
                failed: 1,
                pending: 1,
            }),
        })
        .expect("segments status mapping");

        assert_eq!(mapped.mode, SegmentsStatusMode::Rebalance);
        assert_eq!(mapped.summary.expect("summary").failed, 1);
        assert_eq!(
            mapped.failure.expect("failure").node_failures[0].segments[0].failure_reason,
            "io"
        );
    }

    #[test]
    fn maps_batch_insert_response_to_model() {
        let mapped = map_batch_insert_response(ingest::BatchInsertFilesResponse {
            results: vec![ingest::FileInsertResult {
                path: "/tmp/data.parquet".to_string(),
                success: true,
                result: Some(ingest::InsertResponse {
                    inserted_record_batches: 2,
                    inserted_row_count: 10,
                    elapsed_time: Some(0.25),
                }),
                error: None,
            }],
            metrics: Some(common::RequestMetrics {
                elapsed_time: Some(0.5),
                rss_peak_bytes: Some(1024),
            }),
            total_inserted_row_count: 10,
            total_inserted_record_batches: 2,
        });

        assert_eq!(mapped.results.len(), 1);
        assert_eq!(mapped.total_inserted_row_count, 10);
        assert_eq!(mapped.metrics.expect("metrics").rss_peak_bytes, Some(1024));
    }

    #[test]
    fn maps_schema_from_parquet_response_to_model() {
        let schema = Schema::new(vec![Field::new("id", DataType::Int64, false)]);
        let mapped = map_get_schema_from_parquet_response(utility::GetSchemaFromParquetResponse {
            columns: vec![catalog::Column {
                name: "id".to_string(),
                column_type: Some(catalog::ColumnType {
                    kind: Some(catalog::column_type::Kind::Scalar(
                        catalog::ScalarType::Int64 as i32,
                    )),
                }),
                nullable: false,
                max_length: None,
            }],
            primary_key: vec!["id".to_string()],
            segmentation: None,
            indexes: vec![],
            schema: Some(common::ArrowSchema {
                arrow_schema_ipc: schema_to_ipc(&schema).into(),
            }),
        })
        .expect("schema mapping");

        assert_eq!(mapped.columns.len(), 1);
        assert_eq!(mapped.primary_key, vec!["id".to_string()]);
        assert_eq!(mapped.schema.expect("schema").fields().len(), 1);
    }

    #[test]
    fn maps_create_status_response_to_model() {
        let mapped = map_create_status_response(table::GetCreateStatusResponse {
            table_name: "docs".to_string(),
            status: "CREATING_FAILED".to_string(),
            started_at: Some("2026-03-10T12:00:00Z".to_string()),
            failure: Some(segment::TableOperationFailure {
                summary: "timeout".to_string(),
                detected_at: "2026-03-10T12:01:00Z".to_string(),
                node_failures: vec![],
            }),
            polling: None,
        })
        .expect("create status mapping");

        assert_eq!(mapped.table_name, "docs");
        assert_eq!(mapped.status, "CREATING_FAILED");
        assert_eq!(mapped.failure.expect("failure").summary, "timeout");
    }

    #[test]
    fn maps_vdb_resource_usage_response_to_model() {
        let mapped = map_vdb_resource_usage_response(node::GetVdbResourceUsageResponse {
            nodes: vec![node::NodeResourceUsageResult {
                node_name: "reader-1".to_string(),
                node_type: "READER".to_string(),
                resource_usage: Some(node::NodeResourceUsage {
                    tables: vec![node::TableResourceUsage {
                        table_name: "docs".to_string(),
                        segments: vec![node::SegmentResourceUsage {
                            segment_id: "segment-1".to_string(),
                            memory_bytes: 10,
                            disk_bytes: 20,
                        }],
                        total_memory_bytes: 10,
                        total_disk_bytes: 20,
                    }],
                    total_memory_bytes: 10,
                    total_disk_bytes: 20,
                }),
                error: None,
            }],
            total_memory_bytes: 10,
            total_disk_bytes: 20,
        })
        .expect("resource usage mapping");

        assert_eq!(mapped.nodes[0].node_name, "reader-1");
        assert_eq!(
            mapped.nodes[0]
                .resource_usage
                .as_ref()
                .expect("usage")
                .tables[0]
                .segments[0]
                .segment_id,
            "segment-1"
        );
    }

    #[test]
    fn maps_data_plan_response_to_model() {
        let mapped = map_data_plan_response(query::DataPlanResponse {
            table_name: "docs".to_string(),
            filter: Some("id > 10".to_string()),
            segment_pruning: Some(query::SegmentPruningInfo {
                enabled: true,
                total_segments_available: 8,
                segments_pruned: 6,
                pruning_filters: vec![query::PruningFilter {
                    filter_expression: "id > 10".to_string(),
                }],
            }),
            segments: vec![query::SegmentPlanDetail {
                segment_id: "segment-1".to_string(),
                last_inactive_set: 2,
                latest_versions: vec![query::SetVersionEntry { set: 1, version: 3 }],
                readers: vec![query::NodeSetVersions {
                    node_id: "reader-1".to_string(),
                    node_type: "READER".to_string(),
                    last_set_number: Some(2),
                    versions: vec![query::SetVersionEntry { set: 1, version: 3 }],
                    num_latest_matches: Some(1),
                    num_latest_mismatches: Some(0),
                }],
                writer: Some(query::NodeSetVersions {
                    node_id: "writer-1".to_string(),
                    node_type: "WRITER".to_string(),
                    last_set_number: None,
                    versions: vec![],
                    num_latest_matches: None,
                    num_latest_mismatches: None,
                }),
                segment_distribution: vec![query::NodeSearchRanges {
                    node_id: "reader-1".to_string(),
                    node_type: "READER".to_string(),
                    search_scopes: vec!["seg:0-2".to_string()],
                }],
            }],
            final_distribution: vec![],
            empty_range_diagnostics: vec![],
            raw_node_assignments: vec![],
        })
        .expect("data plan mapping");

        assert_eq!(mapped.table_name, "docs");
        assert_eq!(
            mapped
                .segment_pruning
                .expect("segment pruning")
                .segments_pruned,
            6
        );
        assert_eq!(mapped.segments[0].writer.node_id, "writer-1");
    }

    #[test]
    fn maps_rebalance_plan_request_to_proto_with_table_name() {
        let request = map_rebalance_plan_request(
            "docs",
            &RebalancePlanRequest {
                reader_nodes: Some(vec!["reader-1".to_string()]),
                writer_nodes: Some(vec!["writer-1".to_string()]),
                strategy: Some(RebalanceStrategy::BalancedMinMoves),
            },
        );

        assert_eq!(request.table_name, "docs");
        assert_eq!(request.reader_nodes, vec!["reader-1".to_string()]);
        assert_eq!(
            request.strategy,
            Some(segment::RebalanceStrategy::BalancedMinMoves as i32)
        );
    }

    #[test]
    fn maps_rebalance_plan_response_to_model() {
        let mapped = map_rebalance_plan_response(segment::RebalancePlanResponse {
            table_name: "docs".to_string(),
            expected_table_version: 9,
            strategy: segment::RebalanceStrategy::StrictAlgorithmic as i32,
            expected_segment_structure: Some(segment::SegmentStructureSnapshot {
                segmentation_info: Some(catalog::SegmentationInfo {
                    segment_type: catalog::SegmentType::Hash as i32,
                    segment_keys: vec!["id".to_string()],
                    num_buckets: Some(4),
                    segment_key_composition_type: Some(
                        catalog::SegmentKeyCompositionType::Single as i32,
                    ),
                }),
                segment_ids: vec!["segment-1".to_string()],
                segment_assignments: HashMap::from([(
                    "segment-1".to_string(),
                    segment::SegmentAssignmentSnapshot {
                        segment_id: "segment-1".to_string(),
                        readers: vec!["reader-1".to_string()],
                        writer: "writer-1".to_string(),
                    },
                )]),
            }),
            effective_reader_nodes: vec!["reader-1".to_string()],
            effective_writer_nodes: vec!["writer-1".to_string()],
            summary: Some(segment::RebalancePlanSummary {
                total_segments: 1,
                writer_moves: 1,
                reader_moves: 0,
                unchanged_count: 0,
                writer_load_before: vec![],
                writer_load_after: vec![],
                reader_load_before: vec![],
                reader_load_after: vec![],
            }),
            segments: vec![segment::RebalanceSegmentEntry {
                segment_id: "segment-1".to_string(),
                before: Some(segment::RebalanceSegmentSide {
                    writer: "writer-1".to_string(),
                    readers: vec!["reader-1".to_string()],
                }),
                after: Some(segment::RebalanceSegmentSide {
                    writer: "writer-2".to_string(),
                    readers: vec!["reader-1".to_string()],
                }),
                changed: Some(segment::RebalanceSegmentChangeFlag {
                    writer: true,
                    readers: false,
                }),
            }],
            commit_template: Some(segment::RebalanceCommitRequest {
                table_name: "docs".to_string(),
                reader_nodes: vec!["reader-1".to_string()],
                writer_nodes: vec!["writer-2".to_string()],
                strategy: Some(segment::RebalanceStrategy::StrictAlgorithmic as i32),
                expected_table_version: 9,
                expected_segment_structure: Some(segment::SegmentStructureSnapshot {
                    segmentation_info: None,
                    segment_ids: vec!["segment-1".to_string()],
                    segment_assignments: HashMap::from([(
                        "segment-1".to_string(),
                        segment::SegmentAssignmentSnapshot {
                            segment_id: "segment-1".to_string(),
                            readers: vec!["reader-1".to_string()],
                            writer: "writer-2".to_string(),
                        },
                    )]),
                }),
            }),
        })
        .expect("rebalance plan mapping");

        assert_eq!(mapped.table_name, "docs");
        assert_eq!(mapped.expected_table_version, 9);
        assert_eq!(mapped.commit_template.expected_table_version, 9);
        assert!(mapped.segments[0].changed.writer);
    }

    #[test]
    fn maps_catalog_cache_dump_response_to_client_type() {
        let schema = Schema::empty();
        let mapped = map_catalog_cache_dump_response(catalog::GetCatalogCacheDumpResponse {
            cache_entries: vec![catalog::CacheEntryDump {
                key: "TABLE:docs".to_string(),
                cache_type: catalog::CacheEntryType::Table as i32,
                created_at_epoch_millis: 12_000,
                ttl_seconds: 30,
                invalidated: false,
                value: Some(catalog::CacheEntryValue {
                    kind: Some(catalog::cache_entry_value::Kind::TableInfo(
                        catalog::TableInfo {
                            table_name: "docs".to_string(),
                            version: 7,
                            format_version: 1,
                            oid: "1001".to_string(),
                            schema: Some(common::ArrowSchema {
                                arrow_schema_ipc: schema_to_ipc(&schema).into(),
                            }),
                            segmentation_info: None,
                            index_info: Vec::new(),
                            active_set_size_limit: Some(1000),
                            max_threads: Some(4),
                            segments: Vec::new(),
                            status: Some(catalog::TableOperationalStatus::Active as i32),
                            rebalancing_context: None,
                            creation_context: None,
                        },
                    )),
                }),
            }],
            next_cursor: Some("TABLE|TABLE:docs".to_string()),
        })
        .expect("catalog cache dump mapping");

        assert_eq!(mapped.cache_entries.len(), 1);
        assert_eq!(mapped.cache_entries[0].key, "TABLE:docs");
        assert_eq!(mapped.cache_entries[0].ttl, Duration::from_secs(30));
        assert!(matches!(
            mapped.cache_entries[0].value,
            Some(CacheEntryValue::Table(ref value))
                if value.table_name == "docs" && value.active_set_size_limit == Some(1000)
        ));
    }

    #[test]
    fn maps_log_config_response_to_model() {
        let mapped = map_log_config_from_proto(log::LogConfig {
            output_mode: "file".to_string(),
            stdio_target: "stderr".to_string(),
            file_path: "/tmp/coral.log".to_string(),
            file_instance_id: "node-1".to_string(),
            max_size_mb: 128,
            max_files: 10,
            suffix_mode: "number".to_string(),
            timestamp_tz: "utc".to_string(),
            timestamp_format: "%Y".to_string(),
        })
        .expect("log config mapping");

        assert_eq!(mapped.max_files, 10);
        assert_eq!(mapped.output_mode, "file");
    }
}
