use thiserror::Error;

use coral_models::ResultSetError;

#[derive(Error, Debug)]
pub enum CoralClientError {
    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),
    #[error("Arrow error: {0}")]
    ArrowError(#[from] arrow_schema::ArrowError),
    #[error("Parquet error: {0}")]
    ParquetError(#[from] parquet::errors::ParquetError),
    #[error("gRPC status: {0}")]
    GrpcStatus(#[from] tonic::Status),
    #[error("gRPC transport error: {0}")]
    GrpcTransport(#[from] tonic::transport::Error),
    #[error("Invalid gRPC response: {0}")]
    InvalidGrpcResponse(String),
    #[error("Task join error: {0}")]
    TaskJoinError(String),
}

impl From<ResultSetError> for CoralClientError {
    fn from(value: ResultSetError) -> Self {
        match value {
            ResultSetError::Arrow(error) => Self::ArrowError(error),
            other => Self::InvalidGrpcResponse(other.to_string()),
        }
    }
}
