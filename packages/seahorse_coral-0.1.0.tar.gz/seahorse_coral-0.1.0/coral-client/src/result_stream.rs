//! Stream-oriented result decoding for the Rust client.

use arrow_array::RecordBatch;
use arrow_ipc::reader::StreamReader;
use arrow_ipc::writer::StreamWriter;
use bytes::{Bytes, BytesMut};
use coral_models::api::common::RequestMetrics;
use coral_models::result_set::empty_schema;
use coral_models::{MultipleResults, ResultSet, ResultSets, SingleResult};
use tokio::sync::mpsc;

use crate::error::CoralClientError;
use crate::mapping;
use crate::proto::query;

#[derive(Debug, Clone)]
pub struct CollectedResultStream {
    arrow_ipc_stream: Bytes,
    num_resultsets: u32,
    resultset_batch_counts: Vec<u32>,
    metrics: Option<RequestMetrics>,
}

impl CollectedResultStream {
    pub fn arrow_ipc_stream(&self) -> &Bytes {
        &self.arrow_ipc_stream
    }

    pub fn into_arrow_ipc_stream(self) -> Bytes {
        self.arrow_ipc_stream
    }

    pub fn num_resultsets(&self) -> u32 {
        self.num_resultsets
    }

    pub fn resultset_batch_counts(&self) -> &[u32] {
        &self.resultset_batch_counts
    }

    pub fn metrics(&self) -> Option<&RequestMetrics> {
        self.metrics.as_ref()
    }
}

#[derive(Debug, Clone)]
pub struct PreviewedResultSet {
    result: ResultSet,
    truncated: bool,
}

impl PreviewedResultSet {
    pub fn result(&self) -> &ResultSet {
        &self.result
    }

    pub fn into_result(self) -> ResultSet {
        self.result
    }

    pub fn truncated(&self) -> bool {
        self.truncated
    }
}

#[derive(Debug, Clone)]
pub struct PreviewedResultSets {
    result: ResultSets,
    truncated: Vec<bool>,
}

impl PreviewedResultSets {
    pub fn result(&self) -> &ResultSets {
        &self.result
    }

    pub fn into_result(self) -> ResultSets {
        self.result
    }

    pub fn truncated(&self) -> &[bool] {
        &self.truncated
    }
}

#[derive(Debug)]
/// Low-level Arrow `RecordBatch` stream decoded from a gRPC query result
/// stream.
///
/// This is the canonical consumed form for Rust callers that want to process
/// batches incrementally without first collecting the entire Arrow IPC payload.
pub struct RecordBatchStream {
    num_resultsets: u32,
    resultset_batch_counts: Vec<u32>,
    receiver: mpsc::UnboundedReceiver<Result<RecordBatch, CoralClientError>>,
    completion: Option<tokio::task::JoinHandle<Result<Option<RequestMetrics>, CoralClientError>>>,
}

impl RecordBatchStream {
    pub fn num_resultsets(&self) -> u32 {
        self.num_resultsets
    }

    pub fn resultset_batch_counts(&self) -> &[u32] {
        &self.resultset_batch_counts
    }

    pub async fn next_record_batch(&mut self) -> Result<Option<RecordBatch>, CoralClientError> {
        match self.receiver.recv().await {
            Some(Ok(record_batch)) => Ok(Some(record_batch)),
            Some(Err(error)) => Err(error),
            None => Ok(None),
        }
    }

    pub async fn next_record_batch_arrow_ipc(&mut self) -> Result<Option<Bytes>, CoralClientError> {
        let Some(record_batch) = self.next_record_batch().await? else {
            return Ok(None);
        };

        encode_record_batches_to_ipc(std::slice::from_ref(&record_batch)).map(Some)
    }

    pub async fn finish(mut self) -> Result<Option<RequestMetrics>, CoralClientError> {
        let completion = self.completion.take().ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "record batch stream completion handle missing".to_string(),
            )
        })?;

        completion
            .await
            .map_err(|error| CoralClientError::TaskJoinError(error.to_string()))?
    }
}

impl Drop for RecordBatchStream {
    fn drop(&mut self) {
        if let Some(completion) = self.completion.take() {
            completion.abort();
        }
    }
}

#[derive(Debug)]
/// Low-level gRPC query result stream.
///
/// This type still represents the wire-level tonic stream of
/// `ResultStreamEvent`. Callers can:
///
/// - convert it to [`RecordBatchStream`] for incremental Arrow batch
///   consumption, or
/// - explicitly materialize it through `collect_*` helpers.
pub struct QueryResultStream {
    inner: tonic::Streaming<query::ResultStreamEvent>,
}

impl QueryResultStream {
    pub(crate) fn new(inner: tonic::Streaming<query::ResultStreamEvent>) -> Self {
        Self { inner }
    }

    pub async fn into_record_batch_stream(self) -> Result<RecordBatchStream, CoralClientError> {
        let mut inner = self.inner;
        let QueryStreamPreamble {
            num_resultsets,
            resultset_batch_counts,
            first_event,
        } = read_query_stream_preamble(&mut inner).await?;
        let (chunk_sender, chunk_receiver) = std::sync::mpsc::channel();
        let (batch_sender, batch_receiver) = mpsc::unbounded_channel();

        let decode_handle = tokio::task::spawn_blocking(move || {
            decode_record_batches_from_chunks(chunk_receiver, batch_sender)
        });

        let completion = tokio::spawn(async move {
            let metrics = pump_query_stream_chunks(inner, chunk_sender, first_event).await?;
            decode_handle
                .await
                .map_err(|error| CoralClientError::TaskJoinError(error.to_string()))??;
            Ok(metrics)
        });

        Ok(RecordBatchStream {
            num_resultsets,
            resultset_batch_counts,
            receiver: batch_receiver,
            completion: Some(completion),
        })
    }

    pub async fn into_resultset_stream(self) -> Result<ResultSetStream, CoralClientError> {
        let stream = self.into_record_batch_stream().await?;
        Ok(ResultSetStream::new(stream))
    }

    /// Explicit full-materialization helper that buffers the whole Arrow IPC
    /// stream in memory.
    pub async fn collect_arrow_ipc(self) -> Result<CollectedResultStream, CoralClientError> {
        collect_tonic_result_stream(self.inner).await
    }

    /// Explicit convenience helper that collects a single-result stream into a
    /// fully materialized [`SingleResult`].
    pub async fn collect_single(self) -> Result<SingleResult, CoralClientError> {
        let CollectedResultStream {
            arrow_ipc_stream,
            num_resultsets,
            resultset_batch_counts,
            metrics,
        } = self.collect_arrow_ipc().await?;
        if num_resultsets != 1 {
            return Err(CoralClientError::InvalidGrpcResponse(format!(
                "expected a single resultset stream, got {} resultsets",
                num_resultsets
            )));
        }
        if resultset_batch_counts.as_slice() != [count_batches_in_ipc(arrow_ipc_stream.as_ref())?] {
            return Err(CoralClientError::InvalidGrpcResponse(
                "single-result query stream boundary metadata did not match the Arrow IPC payload"
                    .to_string(),
            ));
        }

        single_result_from_arrow_ipc(arrow_ipc_stream.as_ref(), metrics)
    }

    /// Explicit convenience helper that collects a multi-result stream into a
    /// fully materialized [`MultipleResults`].
    pub async fn collect_multiple(self) -> Result<MultipleResults, CoralClientError> {
        let CollectedResultStream {
            arrow_ipc_stream,
            num_resultsets,
            resultset_batch_counts,
            metrics,
        } = self.collect_arrow_ipc().await?;
        multiple_result_from_arrow_ipc(
            arrow_ipc_stream.as_ref(),
            num_resultsets,
            &resultset_batch_counts,
            metrics,
        )
    }

    pub async fn collect_single_preview(
        self,
        row_limit: usize,
    ) -> Result<PreviewedResultSet, CoralClientError> {
        let stream = self.into_record_batch_stream().await?;
        if stream.num_resultsets() != 1 {
            return Err(CoralClientError::InvalidGrpcResponse(format!(
                "expected a single resultset stream, got {} resultsets",
                stream.num_resultsets()
            )));
        }

        collect_single_preview_from_record_batch_stream(stream, row_limit).await
    }

    pub async fn collect_multiple_preview(
        self,
        row_limit: usize,
    ) -> Result<PreviewedResultSets, CoralClientError> {
        let stream = self.into_record_batch_stream().await?;
        collect_multiple_preview_from_record_batch_stream(stream, row_limit).await
    }
}

#[derive(Debug)]
pub struct ResultSetStream {
    inner: RecordBatchStream,
    next_resultset_index: usize,
}

impl ResultSetStream {
    fn new(inner: RecordBatchStream) -> Self {
        Self {
            inner,
            next_resultset_index: 0,
        }
    }

    pub fn num_resultsets(&self) -> u32 {
        self.inner.num_resultsets()
    }

    pub fn resultset_batch_counts(&self) -> &[u32] {
        self.inner.resultset_batch_counts()
    }

    pub async fn next_resultset_arrow_ipc(&mut self) -> Result<Option<Bytes>, CoralClientError> {
        let Some(record_batch_count) = self
            .inner
            .resultset_batch_counts()
            .get(self.next_resultset_index)
            .copied()
        else {
            return Ok(None);
        };

        let mut result_batches = Vec::with_capacity(record_batch_count as usize);
        for _ in 0..record_batch_count {
            let batch = self.inner.next_record_batch().await?.ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(format!(
                    "expected resultset {} to contain {} record batches, but stream ended early",
                    self.next_resultset_index, record_batch_count
                ))
            })?;
            result_batches.push(batch);
        }

        self.next_resultset_index += 1;

        encode_record_batches_to_ipc(&result_batches).map(Some)
    }

    pub async fn finish(self) -> Result<Option<RequestMetrics>, CoralClientError> {
        self.inner.finish().await
    }
}

pub(crate) fn schema_from_ipc(bytes: &[u8]) -> Result<arrow_schema::SchemaRef, CoralClientError> {
    let reader = StreamReader::try_new(bytes, None)?;
    Ok(reader.schema().clone())
}

pub(crate) fn single_result_from_arrow_ipc(
    arrow_ipc_stream: &[u8],
    metrics: Option<RequestMetrics>,
) -> Result<SingleResult, CoralClientError> {
    let (schema, batches) = read_record_batches(arrow_ipc_stream)?;
    Ok(SingleResult::new(ResultSet::new(schema, batches), metrics))
}

pub(crate) fn multiple_result_from_arrow_ipc(
    arrow_ipc_stream: &[u8],
    num_resultsets: u32,
    resultset_batch_counts: &[u32],
    metrics: Option<RequestMetrics>,
) -> Result<MultipleResults, CoralClientError> {
    if arrow_ipc_stream.is_empty() && num_resultsets == 0 {
        return Ok(MultipleResults::new(ResultSets::empty(), metrics));
    }

    let (_schema, batches) = read_record_batches(arrow_ipc_stream)?;

    if resultset_batch_counts.len() != num_resultsets as usize {
        return Err(CoralClientError::InvalidGrpcResponse(format!(
            "expected {num_resultsets} resultset boundary descriptors, got {}",
            resultset_batch_counts.len()
        )));
    }

    let expected_record_batches: usize = resultset_batch_counts
        .iter()
        .map(|count| *count as usize)
        .sum();
    if batches.len() != expected_record_batches {
        return Err(CoralClientError::InvalidGrpcResponse(format!(
            "expected {expected_record_batches} record batches from query boundaries, but Arrow IPC stream contained {} record batches",
            batches.len(),
        )));
    }

    let mut remaining_batches = batches.into_iter();
    let mut result_sets = Vec::with_capacity(resultset_batch_counts.len());
    for (resultset_index, record_batch_count) in resultset_batch_counts.iter().enumerate() {
        let result_batches = remaining_batches
            .by_ref()
            .take(*record_batch_count as usize)
            .collect::<Vec<_>>();
        if result_batches.len() != *record_batch_count as usize {
            return Err(CoralClientError::InvalidGrpcResponse(format!(
                "query stream ended while reconstructing resultset {resultset_index}"
            )));
        }

        let result_set = ResultSet::try_new(result_batches)?;
        result_sets.push(result_set);
    }

    Ok(MultipleResults::new(ResultSets::new(result_sets), metrics))
}

#[cfg(test)]
async fn collect_result_stream_from_messages<F, Fut>(
    mut next_message: F,
) -> Result<CollectedResultStream, CoralClientError>
where
    F: FnMut() -> Fut,
    Fut: std::future::Future<Output = Result<Option<query::ResultStreamEvent>, tonic::Status>>,
{
    let mut messages = std::collections::VecDeque::new();
    while let Some(message) = next_message().await? {
        messages.push_back(message);
    }

    let header = messages.pop_front().ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "query stream ended before sending a header".to_string(),
        )
    })?;
    let header = match header.event.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse("query stream header payload missing".to_string())
    })? {
        query::result_stream_event::Event::Header(header) => header,
        other => {
            return Err(CoralClientError::InvalidGrpcResponse(format!(
                "expected query stream header, got {other:?}"
            )));
        }
    };

    let mut resultset_batch_counts = Vec::with_capacity(header.num_result_sets as usize);
    let mut arrow_ipc_stream = BytesMut::new();
    let mut metrics = None;
    let mut saw_footer = false;
    let mut saw_chunk_phase = false;

    while let Some(message) = messages.pop_front() {
        let event = message.event.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "query stream event did not contain a payload".to_string(),
            )
        })?;

        match event {
            query::result_stream_event::Event::ResultSetBoundary(boundary) => {
                if saw_chunk_phase || saw_footer {
                    return Err(CoralClientError::InvalidGrpcResponse(
                        "query stream resultset boundary arrived after chunk streaming began"
                            .to_string(),
                    ));
                }
                let expected_index = resultset_batch_counts.len() as u32;
                if boundary.result_set_index != expected_index {
                    return Err(CoralClientError::InvalidGrpcResponse(format!(
                        "expected query resultset boundary index {expected_index}, got {}",
                        boundary.result_set_index
                    )));
                }
                resultset_batch_counts.push(boundary.record_batch_count);
            }
            query::result_stream_event::Event::Chunk(chunk) => {
                saw_chunk_phase = true;
                if saw_footer {
                    return Err(CoralClientError::InvalidGrpcResponse(
                        "query stream chunk arrived after footer".to_string(),
                    ));
                }
                arrow_ipc_stream.extend_from_slice(&chunk.chunk);
            }
            query::result_stream_event::Event::Footer(footer) => {
                if saw_footer {
                    return Err(CoralClientError::InvalidGrpcResponse(
                        "query stream footer arrived more than once".to_string(),
                    ));
                }
                metrics = mapping::map_request_metrics(footer.metrics);
                saw_footer = true;
            }
            query::result_stream_event::Event::Header(_) => {
                return Err(CoralClientError::InvalidGrpcResponse(
                    "query stream contained multiple headers".to_string(),
                ));
            }
        }
    }

    if resultset_batch_counts.len() != header.num_result_sets as usize {
        return Err(CoralClientError::InvalidGrpcResponse(format!(
            "expected {} query resultset boundaries, got {}",
            header.num_result_sets,
            resultset_batch_counts.len()
        )));
    }

    if !saw_footer {
        return Err(CoralClientError::InvalidGrpcResponse(
            "query stream ended before sending a footer".to_string(),
        ));
    }

    Ok(CollectedResultStream {
        arrow_ipc_stream: arrow_ipc_stream.freeze(),
        num_resultsets: header.num_result_sets,
        resultset_batch_counts,
        metrics,
    })
}

async fn collect_tonic_result_stream(
    mut inner: tonic::Streaming<query::ResultStreamEvent>,
) -> Result<CollectedResultStream, CoralClientError> {
    let QueryStreamPreamble {
        num_resultsets,
        resultset_batch_counts,
        first_event,
    } = read_query_stream_preamble(&mut inner).await?;
    let mut arrow_ipc_stream = BytesMut::new();
    let mut metrics = None;
    let mut saw_footer = false;

    if let Some(first_event) = first_event {
        maybe_append_result_stream_chunk(
            &mut arrow_ipc_stream,
            &mut metrics,
            &mut saw_footer,
            first_event,
        )?;
    }

    while let Some(message) = inner.message().await? {
        let event = message.event.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "query stream event did not contain a payload".to_string(),
            )
        })?;
        maybe_append_result_stream_chunk(
            &mut arrow_ipc_stream,
            &mut metrics,
            &mut saw_footer,
            event,
        )?;
    }

    if !saw_footer {
        return Err(CoralClientError::InvalidGrpcResponse(
            "query stream ended before sending a footer".to_string(),
        ));
    }

    Ok(CollectedResultStream {
        arrow_ipc_stream: arrow_ipc_stream.freeze(),
        num_resultsets,
        resultset_batch_counts,
        metrics,
    })
}

fn count_batches_in_ipc(bytes: &[u8]) -> Result<u32, CoralClientError> {
    let reader = StreamReader::try_new(bytes, None)?;
    let count = reader.count();
    Ok(count as u32)
}

fn encode_record_batches_to_ipc(record_batches: &[RecordBatch]) -> Result<Bytes, CoralClientError> {
    let Some(first_batch) = record_batches.first() else {
        return Ok(Bytes::new());
    };

    let schema = first_batch.schema();
    let mut writer = StreamWriter::try_new(Vec::new(), schema.as_ref())?;
    for record_batch in record_batches {
        writer.write(record_batch)?;
    }
    writer.finish()?;
    Ok(Bytes::from(writer.into_inner()?))
}

async fn read_query_stream_preamble(
    inner: &mut tonic::Streaming<query::ResultStreamEvent>,
) -> Result<QueryStreamPreamble, CoralClientError> {
    let message = inner.message().await?.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse(
            "query stream ended before sending a header".to_string(),
        )
    })?;

    let header = match message.event.ok_or_else(|| {
        CoralClientError::InvalidGrpcResponse("query stream header payload missing".to_string())
    })? {
        query::result_stream_event::Event::Header(header) => header,
        other => {
            return Err(CoralClientError::InvalidGrpcResponse(format!(
                "expected query stream header, got {other:?}"
            )));
        }
    };

    let mut resultset_batch_counts = Vec::with_capacity(header.num_result_sets as usize);
    let first_event = loop {
        let message = match inner.message().await? {
            Some(message) => message,
            None => {
                return if header.num_result_sets == 0 {
                    Ok(QueryStreamPreamble {
                        num_resultsets: 0,
                        resultset_batch_counts,
                        first_event: None,
                    })
                } else {
                    Err(CoralClientError::InvalidGrpcResponse(
                        "query stream ended before sending any resultset boundary or footer"
                            .to_string(),
                    ))
                };
            }
        };

        let event = message.event.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "query stream event did not contain a payload".to_string(),
            )
        })?;

        match event {
            query::result_stream_event::Event::ResultSetBoundary(boundary) => {
                let expected_index = resultset_batch_counts.len() as u32;
                if boundary.result_set_index != expected_index {
                    return Err(CoralClientError::InvalidGrpcResponse(format!(
                        "expected query resultset boundary index {expected_index}, got {}",
                        boundary.result_set_index
                    )));
                }
                resultset_batch_counts.push(boundary.record_batch_count);
            }
            query::result_stream_event::Event::Chunk(_)
            | query::result_stream_event::Event::Footer(_) => {
                break Some(event);
            }
            query::result_stream_event::Event::Header(_) => {
                return Err(CoralClientError::InvalidGrpcResponse(
                    "query stream contained multiple headers".to_string(),
                ));
            }
        }
    };

    if resultset_batch_counts.len() != header.num_result_sets as usize {
        return Err(CoralClientError::InvalidGrpcResponse(format!(
            "expected {} query resultset boundaries, got {}",
            header.num_result_sets,
            resultset_batch_counts.len()
        )));
    }

    Ok(QueryStreamPreamble {
        num_resultsets: header.num_result_sets,
        resultset_batch_counts,
        first_event,
    })
}

async fn pump_query_stream_chunks(
    mut inner: tonic::Streaming<query::ResultStreamEvent>,
    sender: std::sync::mpsc::Sender<ChunkReaderEvent>,
    first_event: Option<query::result_stream_event::Event>,
) -> Result<Option<RequestMetrics>, CoralClientError> {
    if let Some(event) = first_event {
        if let ChunkPumpOutcome::Finished(metrics) =
            handle_query_stream_chunk_event(event, &sender)?
        {
            return Ok(metrics);
        }
    }

    while let Some(message) = inner.message().await? {
        let event = message.event.ok_or_else(|| {
            CoralClientError::InvalidGrpcResponse(
                "query stream event did not contain a payload".to_string(),
            )
        })?;

        if let ChunkPumpOutcome::Finished(metrics) =
            handle_query_stream_chunk_event(event, &sender)?
        {
            return Ok(metrics);
        }
    }

    let _ = sender.send(ChunkReaderEvent::End);
    Err(CoralClientError::InvalidGrpcResponse(
        "query stream ended before sending a footer".to_string(),
    ))
}

fn handle_query_stream_chunk_event(
    event: query::result_stream_event::Event,
    sender: &std::sync::mpsc::Sender<ChunkReaderEvent>,
) -> Result<ChunkPumpOutcome, CoralClientError> {
    match event {
        query::result_stream_event::Event::Chunk(chunk) => {
            if sender.send(ChunkReaderEvent::Chunk(chunk.chunk)).is_err() {
                return Ok(ChunkPumpOutcome::Finished(None));
            }
            Ok(ChunkPumpOutcome::Continue)
        }
        query::result_stream_event::Event::Footer(footer) => {
            let metrics = mapping::map_request_metrics(footer.metrics);
            let _ = sender.send(ChunkReaderEvent::End);
            Ok(ChunkPumpOutcome::Finished(metrics))
        }
        query::result_stream_event::Event::Header(_) => {
            let _ = sender.send(ChunkReaderEvent::End);
            Err(CoralClientError::InvalidGrpcResponse(
                "query stream contained multiple headers".to_string(),
            ))
        }
        query::result_stream_event::Event::ResultSetBoundary(_) => {
            let _ = sender.send(ChunkReaderEvent::End);
            Err(CoralClientError::InvalidGrpcResponse(
                "query stream resultset boundary arrived after chunk streaming began".to_string(),
            ))
        }
    }
}

enum ChunkPumpOutcome {
    Continue,
    Finished(Option<RequestMetrics>),
}

fn maybe_append_result_stream_chunk(
    arrow_ipc_stream: &mut BytesMut,
    metrics: &mut Option<RequestMetrics>,
    saw_footer: &mut bool,
    event: query::result_stream_event::Event,
) -> Result<(), CoralClientError> {
    match event {
        query::result_stream_event::Event::Chunk(chunk) => {
            if *saw_footer {
                return Err(CoralClientError::InvalidGrpcResponse(
                    "query stream chunk arrived after footer".to_string(),
                ));
            }
            arrow_ipc_stream.extend_from_slice(&chunk.chunk);
            Ok(())
        }
        query::result_stream_event::Event::Footer(footer) => {
            if *saw_footer {
                return Err(CoralClientError::InvalidGrpcResponse(
                    "query stream footer arrived more than once".to_string(),
                ));
            }
            *metrics = mapping::map_request_metrics(footer.metrics);
            *saw_footer = true;
            Ok(())
        }
        query::result_stream_event::Event::Header(_) => Err(CoralClientError::InvalidGrpcResponse(
            "query stream contained multiple headers".to_string(),
        )),
        query::result_stream_event::Event::ResultSetBoundary(_) => {
            Err(CoralClientError::InvalidGrpcResponse(
                "query stream resultset boundary arrived after chunk streaming began".to_string(),
            ))
        }
    }
}

#[derive(Debug)]
enum ChunkReaderEvent {
    Chunk(Bytes),
    End,
}

struct ChunkReader {
    receiver: std::sync::mpsc::Receiver<ChunkReaderEvent>,
    current_chunk: Bytes,
    offset: usize,
    finished: bool,
}

struct QueryStreamPreamble {
    num_resultsets: u32,
    resultset_batch_counts: Vec<u32>,
    first_event: Option<query::result_stream_event::Event>,
}

impl ChunkReader {
    fn new(receiver: std::sync::mpsc::Receiver<ChunkReaderEvent>) -> Self {
        Self {
            receiver,
            current_chunk: Bytes::new(),
            offset: 0,
            finished: false,
        }
    }

    fn fill_chunk(&mut self) -> Result<(), CoralClientError> {
        if self.finished {
            return Ok(());
        }

        match self.receiver.recv() {
            Ok(ChunkReaderEvent::Chunk(chunk)) => {
                self.current_chunk = chunk;
                self.offset = 0;
                Ok(())
            }
            Ok(ChunkReaderEvent::End) | Err(_) => {
                self.finished = true;
                Ok(())
            }
        }
    }
}

impl std::io::Read for ChunkReader {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        loop {
            if self.offset < self.current_chunk.len() {
                let remaining = self.current_chunk.len() - self.offset;
                let to_copy = remaining.min(buf.len());
                buf[..to_copy]
                    .copy_from_slice(&self.current_chunk[self.offset..self.offset + to_copy]);
                self.offset += to_copy;
                return Ok(to_copy);
            }

            if self.finished {
                return Ok(0);
            }

            self.fill_chunk()
                .map_err(|error| std::io::Error::other(error.to_string()))?;
        }
    }
}

#[cfg(test)]
fn decode_single_preview_from_chunks(
    receiver: std::sync::mpsc::Receiver<ChunkReaderEvent>,
    row_limit: usize,
) -> Result<PreviewedResultSet, CoralClientError> {
    let reader = ChunkReader::new(receiver);
    let mut stream_reader = StreamReader::try_new(reader, None)?;
    let schema = stream_reader.schema().clone();
    let mut preview_batches = Vec::new();
    let mut remaining = row_limit;
    let mut truncated = false;

    while let Some(batch) = stream_reader.next() {
        let batch = batch?;
        if remaining == 0 {
            truncated = true;
            break;
        }

        let rows_to_take = batch.num_rows().min(remaining);
        preview_batches.push(batch.slice(0, rows_to_take));
        if rows_to_take < batch.num_rows() {
            truncated = true;
            break;
        }
        remaining = remaining.saturating_sub(rows_to_take);
    }

    if preview_batches.is_empty() {
        return Err(CoralClientError::InvalidGrpcResponse(
            "query preview stream did not contain any record batches".to_string(),
        ));
    }

    Ok(PreviewedResultSet {
        result: ResultSet::new(schema, preview_batches),
        truncated,
    })
}

fn decode_record_batches_from_chunks(
    receiver: std::sync::mpsc::Receiver<ChunkReaderEvent>,
    sender: mpsc::UnboundedSender<Result<RecordBatch, CoralClientError>>,
) -> Result<(), CoralClientError> {
    let reader = ChunkReader::new(receiver);
    let mut stream_reader = StreamReader::try_new(reader, None)?;

    while let Some(batch) = stream_reader.next() {
        match batch {
            Ok(batch) => {
                if sender.send(Ok(batch)).is_err() {
                    return Ok(());
                }
            }
            Err(error) => {
                let error = CoralClientError::from(error);
                let _ = sender.send(Err(CoralClientError::InvalidGrpcResponse(
                    error.to_string(),
                )));
                return Err(error);
            }
        }
    }

    Ok(())
}

#[cfg(test)]
fn decode_multiple_preview_from_chunks(
    receiver: std::sync::mpsc::Receiver<ChunkReaderEvent>,
    resultset_batch_counts: &[u32],
    row_limit: usize,
) -> Result<PreviewedResultSets, CoralClientError> {
    if resultset_batch_counts.is_empty() {
        return Ok(PreviewedResultSets {
            result: ResultSets::empty(),
            truncated: Vec::new(),
        });
    }

    let reader = ChunkReader::new(receiver);
    let mut stream_reader = StreamReader::try_new(reader, None)?;
    let mut preview_result_sets = Vec::with_capacity(resultset_batch_counts.len());
    let mut truncated = Vec::with_capacity(resultset_batch_counts.len());

    for (resultset_index, record_batch_count) in resultset_batch_counts.iter().enumerate() {
        let mut result_batches = Vec::with_capacity(*record_batch_count as usize);
        for _ in 0..*record_batch_count {
            let batch = stream_reader.next().ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(format!(
                    "expected resultset {resultset_index} to contain {record_batch_count} record batches, but stream ended early"
                ))
            })??;
            result_batches.push(batch);
        }

        let (preview_batches, result_truncated) =
            preview_record_batches(&result_batches, row_limit);
        let schema = result_batches
            .first()
            .map(RecordBatch::schema)
            .unwrap_or_else(empty_schema);
        preview_result_sets.push(ResultSet::new(schema, preview_batches));
        truncated.push(result_truncated);
    }

    Ok(PreviewedResultSets {
        result: ResultSets::new(preview_result_sets),
        truncated,
    })
}

async fn collect_single_preview_from_record_batch_stream(
    mut stream: RecordBatchStream,
    row_limit: usize,
) -> Result<PreviewedResultSet, CoralClientError> {
    let mut preview_batches = Vec::new();
    let mut remaining = row_limit;
    let mut truncated = false;

    while let Some(batch) = stream.next_record_batch().await? {
        if remaining == 0 {
            truncated = true;
            break;
        }

        let rows_to_take = batch.num_rows().min(remaining);
        preview_batches.push(batch.slice(0, rows_to_take));
        if rows_to_take < batch.num_rows() {
            truncated = true;
            break;
        }
        remaining = remaining.saturating_sub(rows_to_take);
    }

    if preview_batches.is_empty() {
        let _ = stream.finish().await?;
        return Err(CoralClientError::InvalidGrpcResponse(
            "query preview stream did not contain any record batches".to_string(),
        ));
    }

    if !truncated {
        let _ = stream.finish().await?;
    }

    Ok(PreviewedResultSet {
        result: ResultSet::new(preview_batches[0].schema().clone(), preview_batches),
        truncated,
    })
}

async fn collect_multiple_preview_from_record_batch_stream(
    mut stream: RecordBatchStream,
    row_limit: usize,
) -> Result<PreviewedResultSets, CoralClientError> {
    let expected_resultsets = stream.num_resultsets() as usize;
    if expected_resultsets == 0 {
        let _ = stream.finish().await?;
        return Ok(PreviewedResultSets {
            result: ResultSets::empty(),
            truncated: Vec::new(),
        });
    }

    let resultset_batch_counts = stream.resultset_batch_counts().to_vec();
    let mut preview_result_sets = Vec::with_capacity(expected_resultsets);
    let mut truncated = Vec::with_capacity(expected_resultsets);

    for (resultset_index, record_batch_count) in resultset_batch_counts.iter().enumerate() {
        let mut result_batches = Vec::with_capacity(*record_batch_count as usize);
        for _ in 0..*record_batch_count {
            let batch = stream.next_record_batch().await?.ok_or_else(|| {
                CoralClientError::InvalidGrpcResponse(format!(
                    "expected resultset {resultset_index} to contain {record_batch_count} record batches, but stream ended early"
                ))
            })?;
            result_batches.push(batch);
        }

        let (preview_batches, result_truncated) =
            preview_record_batches(&result_batches, row_limit);
        let schema = result_batches
            .first()
            .map(RecordBatch::schema)
            .unwrap_or_else(empty_schema);
        preview_result_sets.push(ResultSet::new(schema, preview_batches));
        truncated.push(result_truncated);
    }

    let _ = stream.finish().await?;

    Ok(PreviewedResultSets {
        result: ResultSets::new(preview_result_sets),
        truncated,
    })
}

fn preview_record_batches(
    record_batches: &[RecordBatch],
    row_limit: usize,
) -> (Vec<RecordBatch>, bool) {
    let total_rows: usize = record_batches.iter().map(RecordBatch::num_rows).sum();
    let mut remaining = row_limit;
    let mut preview_batches = Vec::new();

    for batch in record_batches {
        if remaining == 0 {
            break;
        }

        let rows_to_take = batch.num_rows().min(remaining);
        preview_batches.push(batch.slice(0, rows_to_take));
        remaining = remaining.saturating_sub(rows_to_take);
    }

    if preview_batches.is_empty() && !record_batches.is_empty() {
        preview_batches.push(record_batches[0].slice(0, 0));
    }

    (preview_batches, total_rows > row_limit)
}

fn read_record_batches(
    bytes: &[u8],
) -> Result<(arrow_schema::SchemaRef, Vec<RecordBatch>), CoralClientError> {
    let reader = StreamReader::try_new(bytes, None)?;
    let schema = reader.schema().clone();
    let batches = reader.collect::<Result<Vec<_>, _>>()?;
    Ok((schema, batches))
}

#[cfg(test)]
mod tests {
    use std::collections::VecDeque;
    use std::sync::Arc;
    use std::sync::Mutex;

    use arrow_array::{Int32Array, StringArray};
    use arrow_ipc::writer::StreamWriter;
    use arrow_schema::{DataType, Field, Schema};

    use super::*;
    use crate::proto::common;

    fn sample_batches() -> Vec<RecordBatch> {
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, false),
        ]));

        vec![
            RecordBatch::try_new(
                schema.clone(),
                vec![
                    Arc::new(Int32Array::from(vec![1, 2])),
                    Arc::new(StringArray::from(vec!["a", "b"])),
                ],
            )
            .expect("first batch"),
            RecordBatch::try_new(
                schema,
                vec![
                    Arc::new(Int32Array::from(vec![3])),
                    Arc::new(StringArray::from(vec!["c"])),
                ],
            )
            .expect("second batch"),
        ]
    }

    fn sample_ipc() -> Vec<u8> {
        let batches = sample_batches();
        let schema = batches[0].schema();
        let mut writer = StreamWriter::try_new(Vec::new(), &schema).expect("writer");
        for batch in batches {
            writer.write(&batch).expect("write batch");
        }
        writer.finish().expect("finish writer");
        writer.into_inner().expect("into inner")
    }

    #[test]
    fn decodes_single_result_from_arrow_ipc() {
        let ipc = sample_ipc();
        let result = single_result_from_arrow_ipc(&ipc, None).expect("single result");

        assert_eq!(result.result().record_batches().len(), 2);
        assert_eq!(result.result().schema().fields().len(), 2);
    }

    #[test]
    fn decodes_multiple_results_from_arrow_ipc() {
        let ipc = sample_ipc();
        let result =
            multiple_result_from_arrow_ipc(&ipc, 2, &[1, 1], None).expect("multiple result");

        assert_eq!(result.result().result_sets().len(), 2);
        assert_eq!(result.result().num_resultsets(), 2);
        assert_eq!(result.result().result_sets()[0].record_batches().len(), 1);
        assert_eq!(result.result().result_sets()[1].record_batches().len(), 1);
    }

    #[test]
    fn decodes_multiple_results_with_multi_batch_resultset() {
        let ipc = sample_ipc();
        let result = multiple_result_from_arrow_ipc(&ipc, 1, &[2], None).expect("multiple result");

        assert_eq!(result.result().result_sets().len(), 1);
        assert_eq!(result.result().num_resultsets(), 1);
        assert_eq!(result.result().result_sets()[0].record_batches().len(), 2);
    }

    #[test]
    fn rejects_mismatched_resultset_count() {
        let ipc = sample_ipc();
        let error = multiple_result_from_arrow_ipc(&ipc, 3, &[1, 1, 1], None)
            .expect_err("should reject mismatch");

        match error {
            CoralClientError::InvalidGrpcResponse(message) => {
                assert!(message.contains("expected 3 record batches from query boundaries"));
            }
            other => panic!("unexpected error: {other}"),
        }
    }

    #[tokio::test]
    async fn collects_result_stream_events() {
        let ipc = sample_ipc();
        let queue = Arc::new(Mutex::new(VecDeque::from(vec![
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::Header(
                    query::ResultStreamHeader { num_result_sets: 2 },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::ResultSetBoundary(
                    query::ResultSetBoundary {
                        result_set_index: 0,
                        record_batch_count: 1,
                    },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::ResultSetBoundary(
                    query::ResultSetBoundary {
                        result_set_index: 1,
                        record_batch_count: 1,
                    },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::Chunk(
                    query::ResultStreamChunk {
                        chunk: Bytes::from(ipc),
                    },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::Footer(
                    query::ResultStreamFooter {
                        metrics: Some(common::RequestMetrics {
                            elapsed_time: Some(0.5),
                            rss_peak_bytes: Some(42),
                        }),
                    },
                )),
            },
        ])));

        let collected = collect_result_stream_from_messages({
            let queue = queue.clone();
            move || {
                let queue = queue.clone();
                async move { Ok(queue.lock().expect("queue").pop_front()) }
            }
        })
        .await
        .expect("collected stream");

        assert_eq!(collected.num_resultsets(), 2);
        assert_eq!(
            collected
                .metrics()
                .and_then(|metrics| metrics.rss_peak_bytes),
            Some(42)
        );
        assert!(!collected.arrow_ipc_stream().is_empty());
    }

    #[tokio::test]
    async fn rejects_stream_without_footer() {
        let queue = Arc::new(Mutex::new(VecDeque::from(vec![query::ResultStreamEvent {
            event: Some(query::result_stream_event::Event::Header(
                query::ResultStreamHeader { num_result_sets: 0 },
            )),
        }])));

        let error = collect_result_stream_from_messages({
            let queue = queue.clone();
            move || {
                let queue = queue.clone();
                async move { Ok(queue.lock().expect("queue").pop_front()) }
            }
        })
        .await
        .expect_err("missing footer should fail");

        match error {
            CoralClientError::InvalidGrpcResponse(message) => {
                assert!(message.contains("footer"));
            }
            other => panic!("unexpected error: {other}"),
        }
    }

    #[tokio::test]
    async fn decodes_record_batches_from_chunk_stream() {
        let ipc = sample_ipc();
        let (chunk_sender, chunk_receiver) = std::sync::mpsc::channel();
        let (batch_sender, mut batch_receiver) = tokio::sync::mpsc::unbounded_channel();

        let decode_handle = tokio::task::spawn_blocking(move || {
            decode_record_batches_from_chunks(chunk_receiver, batch_sender)
        });

        chunk_sender
            .send(ChunkReaderEvent::Chunk(Bytes::from(ipc)))
            .expect("chunk send");
        chunk_sender.send(ChunkReaderEvent::End).expect("end send");

        let first = batch_receiver
            .recv()
            .await
            .expect("first batch event")
            .expect("first batch");
        let second = batch_receiver
            .recv()
            .await
            .expect("second batch event")
            .expect("second batch");

        assert_eq!(first.num_rows(), 2);
        assert_eq!(second.num_rows(), 1);
        assert!(batch_receiver.recv().await.is_none());

        decode_handle
            .await
            .expect("decode join")
            .expect("decode result");
    }

    #[tokio::test]
    async fn next_record_batch_arrow_ipc_encodes_single_batch() {
        let ipc = sample_ipc();
        let (chunk_sender, chunk_receiver) = std::sync::mpsc::channel();
        let (batch_sender, batch_receiver) = tokio::sync::mpsc::unbounded_channel();

        let decode_handle = tokio::task::spawn_blocking(move || {
            decode_record_batches_from_chunks(chunk_receiver, batch_sender)
        });

        chunk_sender
            .send(ChunkReaderEvent::Chunk(Bytes::from(ipc)))
            .expect("chunk send");
        chunk_sender.send(ChunkReaderEvent::End).expect("end send");

        let completion = tokio::spawn(async move {
            decode_handle
                .await
                .expect("decode join")
                .expect("decode result");
            Ok(None)
        });

        let mut stream = RecordBatchStream {
            num_resultsets: 1,
            resultset_batch_counts: vec![2],
            receiver: batch_receiver,
            completion: Some(completion),
        };

        let first_batch_ipc = stream
            .next_record_batch_arrow_ipc()
            .await
            .expect("first batch ipc")
            .expect("batch bytes");
        let (schema, batches) =
            read_record_batches(first_batch_ipc.as_ref()).expect("decode bytes");

        assert_eq!(schema.fields().len(), 2);
        assert_eq!(batches.len(), 1);
        assert_eq!(batches[0].num_rows(), 2);

        let _ = stream.finish().await.expect("finish");
    }

    #[tokio::test]
    async fn resultset_stream_respects_boundaries() {
        let ipc = sample_ipc();
        let queue = Arc::new(Mutex::new(VecDeque::from(vec![
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::Header(
                    query::ResultStreamHeader { num_result_sets: 2 },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::ResultSetBoundary(
                    query::ResultSetBoundary {
                        result_set_index: 0,
                        record_batch_count: 1,
                    },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::ResultSetBoundary(
                    query::ResultSetBoundary {
                        result_set_index: 1,
                        record_batch_count: 1,
                    },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::Chunk(
                    query::ResultStreamChunk {
                        chunk: Bytes::from(ipc),
                    },
                )),
            },
            query::ResultStreamEvent {
                event: Some(query::result_stream_event::Event::Footer(
                    query::ResultStreamFooter { metrics: None },
                )),
            },
        ])));

        let collected = collect_result_stream_from_messages({
            let queue = queue.clone();
            move || {
                let queue = queue.clone();
                async move { Ok(queue.lock().expect("queue").pop_front()) }
            }
        })
        .await
        .expect("collected");

        let mut resultset_batches = VecDeque::from(
            collected
                .resultset_batch_counts()
                .iter()
                .copied()
                .collect::<Vec<_>>(),
        );
        let (_schema, batches) =
            read_record_batches(collected.arrow_ipc_stream().as_ref()).expect("decode");
        let batch_receiver = {
            let (batch_sender, batch_receiver) = tokio::sync::mpsc::unbounded_channel();
            for batch in batches {
                batch_sender.send(Ok(batch)).expect("send batch");
            }
            batch_receiver
        };
        let completion = tokio::spawn(async { Ok(None) });
        let record_batch_stream = RecordBatchStream {
            num_resultsets: collected.num_resultsets(),
            resultset_batch_counts: resultset_batches.drain(..).collect(),
            receiver: batch_receiver,
            completion: Some(completion),
        };

        let mut resultset_stream = ResultSetStream::new(record_batch_stream);
        let first = resultset_stream
            .next_resultset_arrow_ipc()
            .await
            .expect("first resultset")
            .expect("first bytes");
        let second = resultset_stream
            .next_resultset_arrow_ipc()
            .await
            .expect("second resultset")
            .expect("second bytes");
        assert!(
            resultset_stream
                .next_resultset_arrow_ipc()
                .await
                .expect("stream end")
                .is_none()
        );

        let (_, first_batches) = read_record_batches(first.as_ref()).expect("decode first");
        let (_, second_batches) = read_record_batches(second.as_ref()).expect("decode second");
        assert_eq!(first_batches.len(), 1);
        assert_eq!(second_batches.len(), 1);
        assert_eq!(first_batches[0].num_rows(), 2);
        assert_eq!(second_batches[0].num_rows(), 1);
    }

    #[test]
    fn decodes_single_preview_from_chunks() {
        let (sender, receiver) = std::sync::mpsc::channel();
        sender
            .send(ChunkReaderEvent::Chunk(Bytes::from(sample_ipc())))
            .expect("send chunk");
        sender.send(ChunkReaderEvent::End).expect("send end");

        let preview =
            decode_single_preview_from_chunks(receiver, 1).expect("single preview decode");

        assert_eq!(preview.result().record_batches().len(), 1);
        assert_eq!(preview.result().record_batches()[0].num_rows(), 1);
        assert!(preview.truncated());
    }

    #[test]
    fn decodes_multiple_preview_from_chunks() {
        let (sender, receiver) = std::sync::mpsc::channel();
        sender
            .send(ChunkReaderEvent::Chunk(Bytes::from(sample_ipc())))
            .expect("send chunk");
        sender.send(ChunkReaderEvent::End).expect("send end");

        let preview = decode_multiple_preview_from_chunks(receiver, &[1, 1], 1)
            .expect("multiple preview decode");

        assert_eq!(preview.result().result_sets().len(), 2);
        assert_eq!(
            preview.result().result_sets()[0].record_batches()[0].num_rows(),
            1
        );
        assert_eq!(
            preview.result().result_sets()[1].record_batches()[0].num_rows(),
            1
        );
        assert_eq!(preview.truncated(), &[true, false]);
    }

    #[test]
    fn decodes_multiple_preview_with_multi_batch_resultset() {
        let (sender, receiver) = std::sync::mpsc::channel();
        sender
            .send(ChunkReaderEvent::Chunk(Bytes::from(sample_ipc())))
            .expect("send chunk");
        sender.send(ChunkReaderEvent::End).expect("send end");

        let preview = decode_multiple_preview_from_chunks(receiver, &[2], 2)
            .expect("multiple preview decode");

        assert_eq!(preview.result().result_sets().len(), 1);
        assert_eq!(preview.result().result_sets()[0].record_batches().len(), 1);
        assert_eq!(
            preview.result().result_sets()[0].record_batches()[0].num_rows(),
            2
        );
        assert!(preview.truncated()[0]);
    }
}
