//! gRPC-first Rust client for Coral.
//!
//! # Surface model
//!
//! `coral-client` is the low-level Rust SDK for Coral.
//!
//! - Control-plane APIs are typed unary RPCs.
//! - Data-plane APIs are **stream-first** and Arrow-native.
//! - Full-materialization helpers remain available, but they are explicit
//!   convenience helpers rather than the canonical path.
//!
//! # Canonical data-plane APIs
//!
//! Query/scan/search:
//!
//! - [`CoralClient::scan_data_stream`]
//! - [`CoralClient::vector_search_stream`]
//! - [`CoralClient::vector_search_exact_knn_stream`]
//! - [`CoralClient::hybrid_search_stream`]
//! - [`ResultSetStream`]
//! - [`RecordBatchStream`]
//!
//! Export download:
//!
//! - [`CoralClient::export_data_download_stream`]
//! - [`ExportDownloadStream`]
//!
//! Ingest upload:
//!
//! - [`CoralClient::insert_arrow_ipc_chunk_stream`]
//!
//! # Convenience helpers
//!
//! Collect helpers are still available when the caller intentionally wants a
//! fully materialized result:
//!
//! - [`QueryResultStream::collect_single`]
//! - [`QueryResultStream::collect_multiple`]
//! - [`ExportDownloadStream::collect`]
//!
//! Higher-level clients such as `seahorse-coral` can build collect-first UX on
//! top of these low-level primitives, but `coral-client` itself keeps the
//! stream-oriented surface as the canonical one.

pub mod client;
pub mod error;
mod mapping;
mod proto;
mod result_stream;
pub mod types;

pub use client::{CoralClient, ExportDownloadStream};
pub use coral_models::*;
pub use coral_models::{
    MultipleResults, ResultSet, ResultSetError, ResultSets, ResultWithMetrics, SingleResult,
};
pub use error::CoralClientError;
pub use result_stream::{
    CollectedResultStream, PreviewedResultSet, PreviewedResultSets, QueryResultStream,
    RecordBatchStream, ResultSetStream,
};
pub use types::*;
