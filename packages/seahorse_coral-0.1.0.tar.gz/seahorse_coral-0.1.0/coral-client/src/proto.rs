pub mod coral {
    pub mod catalog {
        pub mod v1 {
            tonic::include_proto!("coral.catalog.v1");
        }
    }

    pub mod common {
        #[allow(dead_code)]
        pub mod v1 {
            tonic::include_proto!("coral.common.v1");
        }
    }

    pub mod export {
        pub mod v1 {
            tonic::include_proto!("coral.export.v1");
        }
    }

    pub mod health {
        pub mod v1 {
            tonic::include_proto!("coral.health.v1");
        }
    }

    pub mod ingest {
        pub mod v1 {
            tonic::include_proto!("coral.ingest.v1");
        }
    }

    pub mod log {
        pub mod v1 {
            tonic::include_proto!("coral.log.v1");
        }
    }

    pub mod node {
        pub mod v1 {
            tonic::include_proto!("coral.node.v1");
        }
    }

    pub mod query {
        pub mod v1 {
            tonic::include_proto!("coral.query.v1");
        }
    }

    pub mod segment {
        pub mod v1 {
            tonic::include_proto!("coral.segment.v1");
        }
    }

    pub mod sql {
        pub mod v1 {
            tonic::include_proto!("coral.sql.v1");
        }
    }

    pub mod storage {
        pub mod v1 {
            tonic::include_proto!("coral.storage.v1");
        }
    }

    pub mod table {
        pub mod v1 {
            tonic::include_proto!("coral.table.v1");
        }
    }

    pub mod utility {
        pub mod v1 {
            tonic::include_proto!("coral.utility.v1");
        }
    }
}

pub use coral::catalog::v1 as catalog;
pub use coral::common::v1 as common;
pub use coral::export::v1 as export;
pub use coral::health::v1 as health;
pub use coral::ingest::v1 as ingest;
pub use coral::log::v1 as log;
pub use coral::node::v1 as node;
pub use coral::query::v1 as query;
pub use coral::segment::v1 as segment;
pub use coral::storage::v1 as storage;
pub use coral::table::v1 as table;
pub use coral::utility::v1 as utility;
