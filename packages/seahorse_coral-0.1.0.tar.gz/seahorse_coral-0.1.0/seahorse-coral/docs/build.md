# Build the Python package (from source)

This repository uses **maturin** + **pyo3 (abi3)** to build a native extension.

## Prerequisites

- Rust toolchain (stable)
- Python **>= 3.9**

## (Optional) Create and activate a virtual environment with uv

If you prefer using **uv** to manage a local virtual environment:

```bash
cd seahorse-coral
uv venv .venv
source .venv/bin/activate
```

If `uv` is not installed:

```bash
python3 -m pip install -U uv
```

If you see `No module named pip` inside the venv, bootstrap pip:

```bash
python3 -m ensurepip --default-pip
python3 -m pip install -U pip
```

## Install maturin

```bash
python3 -m pip install -U pip
python3 -m pip install "maturin>=1,<2"
```

Or install maturin via cargo (requires Rust toolchain):

```bash
cargo install maturin --locked
```

## Development install (recommended for local development)

Build and install into the current Python environment:

```bash
cd seahorse-coral
maturin develop
```

For an optimized build:

```bash
maturin develop --release
```

## Run the Python surface tests

Install `pytest` and `pytest-asyncio` into the active environment if needed:

```bash
uv pip install --python .venv/bin/python pytest pytest-asyncio
```

Then run the package tests:

```bash
cd seahorse-coral
.venv/bin/python -m pytest tests
```

The tests cover the Arrow-first tabular surface and typed metadata/admin conversions.

## Build wheels (for distribution)

```bash
cd seahorse-coral
maturin build --release
```

Wheels will be created under `seahorse-coral/target/wheels/`.

## (Optional) Build source distribution (sdist)

```bash
cd seahorse-coral
maturin sdist
```

## Quick sanity check

```bash
python3 -c "import seahorse_coral as sc; print(sc.__version__)"
```
