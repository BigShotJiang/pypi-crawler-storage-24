# Advanced usage

This document complements the Quickstart in `README.md` and focuses on more advanced schema options.

## A) Segmentation

```python
import seahorse_coral as sc

coral = sc.Coral("http://localhost:8080")

schema = (
    sc.SchemaBuilder()
    .int64("id", nullable=False)
    .vector("vector", dim=384)
    .metadata()
    .with_primary_key("id")
    # Hash segmentation (single column + buckets)
    .with_segmentation(sc.hash_segmentation(["id"], buckets=32))
    .hnsw("vector")
)

table = coral.table("documents_segmented", schema)
```

## B) Configurations (tuning)

```python
import seahorse_coral as sc

schema = (
    sc.SchemaBuilder()
    .int64("id", nullable=False)
    .vector("vector", dim=384)
    .metadata()
    .with_primary_key("id")
    .with_configurations(
        sc.TableConfigurations(active_set_size_limit=200_000, max_threads=4)
    )
    .hnsw("vector")
)
```

## C) Placement (assigned nodes)

```python
import seahorse_coral as sc

placement = sc.TablePlacement(
    assigned_nodes=sc.AssignedNodes(writer_nodes=["node-1"], reader_nodes=["node-2"])
)

schema = (
    sc.SchemaBuilder()
    .int64("id", nullable=False)
    .vector("vector", dim=384)
    .metadata()
    .with_primary_key("id")
    .with_placement(placement)
    .hnsw("vector")
)
```

## D) Dense + sparse table (for sparse / hybrid search)

```python
import seahorse_coral as sc

schema = sc.SchemaBuilder(
    columns=[
        sc.int64_column("id", nullable=False),
        sc.vector_column("vector", dim=384),
        sc.sparse_vector_column("sparse_emb"),
        sc.metadata_column("metadata"),
    ],
    primary_key=["id"],
    indexes=[
        sc.hnsw_index("vector"),
        sc.inverted_index("sparse_emb"),
    ],
)
```

## E) Index definitions (schema-level)

Schema-level index objects are:
- `IndexDefinition` (preferred name)
- `IndexDef` (alias)

They represent CreateTableRequest “index specs” and are separate from runtime `Index`
(`table.index("vector")`) used for searching.


