# Compatibility policy

This document is the source of truth for `seahorse-coral` to Coral server compatibility.

## Versioning policy

- The workspace Rust crates (`coral`, `coral-cli`, `coral-client`, `coral-mcp-server`, `coral-models`) use lockstep versioning.
- `seahorse-coral` is versioned independently from those workspace crates.
- The first pip release of `seahorse-coral` starts at `0.1.0`.
- `seahorse-coral` version bumps are reserved for changes that affect the distributed Python package in a user-meaningful way.
- Server-only or workspace-only releases do not require a `seahorse-coral` version bump when Python package behavior and compatibility stay the same.

## Initial compatibility baseline

`seahorse-coral` support begins with Coral `2.5.0`.

| seahorse-coral | Compatible Coral server | Notes |
| --- | --- | --- |
| `0.1.x` | `2.5.x` | Initial pip release line. Compatibility starts from Coral `2.5.0` and includes readable indexed row count by default plus update/delete and rebalance plan/commit/status surfaces in the Python SDK. |

## When to update this document

Update this document when:

- the supported Coral server version range changes
- there is a significant protocol change
- a compatibility caveat needs to be called out for a release line
- a breaking client/server compatibility change is introduced

## Version bump guidance for seahorse-coral

Bump `seahorse-coral` when the shipped Python package changes in a way users can observe, such as:

- Python API additions, removals, or behavior changes
- packaging metadata or runtime dependency changes
- protocol handling changes that affect which Coral server versions are supported
- fixes that change client behavior, error handling, or serialization/deserialization

Do not bump `seahorse-coral` only because the workspace Rust crates were released, unless those changes also affect the shipped Python package or its compatibility contract.
