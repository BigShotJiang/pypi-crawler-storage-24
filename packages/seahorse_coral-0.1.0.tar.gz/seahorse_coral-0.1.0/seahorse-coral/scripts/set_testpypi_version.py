#!/usr/bin/env python3
"""Rewrite package version fields for unique TestPyPI uploads."""

from __future__ import annotations

import argparse
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Pattern


@dataclass(frozen=True)
class VersionTarget:
    path: Path
    pattern: Pattern[str]


VERSION_TARGETS = (
    VersionTarget(Path("pyproject.toml"), re.compile(r'(?m)^(version = ")([^"]+)(")$')),
    VersionTarget(
        Path("python/seahorse_coral/__init__.py"),
        re.compile(r'(?m)^(__version__ = ")([^"]+)(")$'),
    ),
)


def derive_testpypi_version(base_version: str, unique_id: str) -> str:
    """Convert a release version into a unique PEP 440 dev release."""
    if not unique_id.isdigit():
        raise ValueError("unique_id must contain digits only")

    normalized_version = base_version.split("+", maxsplit=1)[0]
    if re.search(r"\.dev\d+$", normalized_version):
        return re.sub(r"\.dev\d+$", f".dev{unique_id}", normalized_version)
    return f"{normalized_version}.dev{unique_id}"


def build_unique_id(run_number: str, run_attempt: str) -> str:
    if not run_number.isdigit():
        raise ValueError("run_number must contain digits only")
    if not run_attempt.isdigit():
        raise ValueError("run_attempt must contain digits only")

    return f"{run_number}{int(run_attempt):02d}"


def _replace_version(contents: str, pattern: Pattern[str], new_version: str) -> str:
    updated_contents, replacements = pattern.subn(
        lambda match: f"{match.group(1)}{new_version}{match.group(3)}",
        contents,
        count=1,
    )
    if replacements != 1:
        raise ValueError("expected to replace exactly one version string")
    return updated_contents


def read_base_version(root: Path) -> str:
    pyproject = (root / "pyproject.toml").read_text(encoding="utf-8")
    match = VERSION_TARGETS[0].pattern.search(pyproject)
    if match is None:
        raise ValueError("failed to read version from pyproject.toml")
    return match.group(2)


def sync_versions(root: Path, new_version: str) -> None:
    for target in VERSION_TARGETS:
        target_path = root / target.path
        contents = target_path.read_text(encoding="utf-8")
        target_path.write_text(
            _replace_version(contents, target.pattern, new_version),
            encoding="utf-8",
        )


def write_github_metadata(
    version: str,
    base_version: str,
    run_number: str,
    run_attempt: str,
    github_env_path: Path,
    github_step_summary_path: Path,
) -> None:
    with github_env_path.open("a", encoding="utf-8") as env_file:
        env_file.write(f"TESTPYPI_VERSION={version}\n")

    with github_step_summary_path.open("a", encoding="utf-8") as summary_file:
        summary_file.write(
            "\n".join(
                (
                    "### TestPyPI Version",
                    "",
                    f"- Version: `{version}`",
                    f"- Base version: `{base_version}`",
                    f"- Workflow run number: `{run_number}`",
                    f"- Run attempt: `{run_attempt}`",
                    "",
                )
            )
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="package root directory")
    parser.add_argument("--unique-id", help="numeric dev suffix")
    parser.add_argument("--run-number", help="GitHub workflow run number")
    parser.add_argument("--run-attempt", help="GitHub workflow run attempt")
    parser.add_argument(
        "--write-github-metadata",
        action="store_true",
        help="write TESTPYPI_VERSION and a summary for GitHub Actions",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(args.root).resolve()
    base_version = read_base_version(root)
    unique_id = args.unique_id
    if unique_id is None:
        run_number = args.run_number or os.environ["GITHUB_RUN_NUMBER"]
        run_attempt = args.run_attempt or os.environ["GITHUB_RUN_ATTEMPT"]
        unique_id = build_unique_id(run_number, run_attempt)
    else:
        run_number = args.run_number or os.environ.get("GITHUB_RUN_NUMBER", "")
        run_attempt = args.run_attempt or os.environ.get("GITHUB_RUN_ATTEMPT", "")

    new_version = derive_testpypi_version(base_version, unique_id)
    sync_versions(root, new_version)
    if args.write_github_metadata:
        github_env = os.environ["GITHUB_ENV"]
        github_step_summary = os.environ["GITHUB_STEP_SUMMARY"]
        write_github_metadata(
            version=new_version,
            base_version=base_version,
            run_number=run_number,
            run_attempt=run_attempt,
            github_env_path=Path(github_env),
            github_step_summary_path=Path(github_step_summary),
        )
        print(f"Prepared TestPyPI version: {new_version}")
        return

    print(new_version)


if __name__ == "__main__":
    main()
