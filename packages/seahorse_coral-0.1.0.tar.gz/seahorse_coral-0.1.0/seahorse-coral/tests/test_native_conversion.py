from types import SimpleNamespace

from seahorse_coral.coral import (
    _indexed_counts_from_native,
    _node_snapshot_from_native,
    _rebalance_commit_from_native,
    _rebalance_plan_from_native,
    _rebalance_status_from_native,
    _segments_retry_from_native,
    _segments_status_from_native,
)


def test_node_info_from_native_accepts_native_objects():
    native = SimpleNamespace(
        node_id="reader-1",
        node_info=SimpleNamespace(
            version=1,
            format_version=2,
            type="READER",
            state="ACTIVE",
            node_stage="RUNNING",
            last_updated="20260108-00:00:00",
            node_address="localhost:6000",
            assigned_tables={
                "docs": SimpleNamespace(
                    table_oid="table-oid",
                    segments={
                        "seg-1": SimpleNamespace(
                            segment_oid="segment-oid",
                            status="SYNCED",
                            failure_reason="",
                            checkpoint=SimpleNamespace(
                                last_set_number=7,
                                set_versions=["0:1:10:0"],
                                set_index_counts={"vector:hnsw": ["0:10"]},
                            ),
                        )
                    },
                )
            },
        ),
    )

    node = _node_snapshot_from_native(native)

    assert node.node_id == "reader-1"
    assert node.node_type == "READER"
    assert node.assigned_tables["docs"].table_oid == "table-oid"
    assert node.assigned_tables["docs"].segments["seg-1"].checkpoint.last_set_number == 7


def test_segments_status_from_native_accepts_native_objects():
    native = SimpleNamespace(
        table_name="docs",
        table_status="ACTIVE",
        mode="active",
        started_at="2026-03-11T00:00:00Z",
        ttl_seconds=30,
        summary=SimpleNamespace(total=5, synced=3, failed=1, pending=1),
        polling=SimpleNamespace(
            evaluated_at="2026-03-11T00:00:10Z",
            nodes=[
                SimpleNamespace(
                    node_id="reader-1",
                    segments=[
                        SimpleNamespace(
                            segment_id="seg-1",
                            expected="ADD",
                            observed="SYNCED",
                            failure_reason=None,
                        )
                    ],
                )
            ],
        ),
        failure=None,
    )

    result = _segments_status_from_native(native)

    assert result.table_name == "docs"
    assert result.mode == "active"
    assert result.summary is not None
    assert result.summary.synced == 3
    assert result.polling is not None
    assert result.polling.nodes[0].segments[0].observed == "SYNCED"


def test_segments_retry_from_native_accepts_native_objects():
    native = SimpleNamespace(
        table_name="docs",
        table_status="REBALANCING_IN_PROGRESS",
        summary=SimpleNamespace(
            mode="rebalance",
            total_nodes=2,
            published_segment_count=3,
            skipped_node_count=1,
            truncated=False,
        ),
        nodes=[
            SimpleNamespace(
                node_id="reader-1",
                published_segments=["seg-1", "seg-2"],
                skipped=None,
                observations=SimpleNamespace(
                    missing_nodeinfo=False,
                    missing_table_assignment=False,
                    missing_segment_count=0,
                    failed_segment_count=1,
                    synced_segment_count=2,
                    not_removed_segment_count=0,
                ),
            )
        ],
    )

    result = _segments_retry_from_native(native)

    assert result.table_name == "docs"
    assert result.summary.mode == "rebalance"
    assert result.nodes[0].node_id == "reader-1"
    assert result.nodes[0].observations.failed_segment_count == 1


def test_indexed_counts_from_native_preserves_readable_section():
    native = SimpleNamespace(
        total_row_count=10,
        indexed_counts=[
            SimpleNamespace(index_name="vector", index_type="HNSW", indexed_row_count=10)
        ],
        readable=SimpleNamespace(
            total_row_count=9,
            indexed_counts=[
                SimpleNamespace(index_name="vector", index_type="HNSW", indexed_row_count=9)
            ],
        ),
    )

    result = _indexed_counts_from_native(native)

    assert result.total_row_count == 10
    assert result.readable is not None
    assert result.readable.total_row_count == 9


def test_rebalance_plan_from_native_accepts_dict_payload():
    native = {
        "table_name": "docs",
        "expected_table_version": 9,
        "strategy": "balanced_min_moves",
        "expected_segment_structure": {
            "segmentation_info": None,
            "segment_ids": ["seg-1"],
            "segment_assignments": {
                "seg-1": {
                    "segment_id": "seg-1",
                    "readers": ["reader-1"],
                    "writer": "writer-1",
                }
            },
        },
        "effective_reader_nodes": ["reader-1"],
        "effective_writer_nodes": ["writer-1"],
        "summary": {
            "total_segments": 1,
            "writer_moves": 1,
            "reader_moves": 0,
            "unchanged_count": 0,
            "writer_load_before": [],
            "writer_load_after": [],
            "reader_load_before": [],
            "reader_load_after": [],
        },
        "segments": [
            {
                "segment_id": "seg-1",
                "before": {"writer": "writer-1", "readers": ["reader-1"]},
                "after": {"writer": "writer-2", "readers": ["reader-1"]},
                "changed": {"writer": True, "readers": False},
            }
        ],
        "commit_template": {
            "reader_nodes": ["reader-1"],
            "writer_nodes": ["writer-2"],
            "strategy": "balanced_min_moves",
            "expected_table_version": 9,
            "expected_segment_structure": {
                "segmentation_info": None,
                "segment_ids": ["seg-1"],
                "segment_assignments": {
                    "seg-1": {
                        "segment_id": "seg-1",
                        "readers": ["reader-1"],
                        "writer": "writer-2",
                    }
                },
            },
        },
    }

    result = _rebalance_plan_from_native(native)

    assert result.table_name == "docs"
    assert result.commit_template.expected_table_version == 9
    assert result.segments[0].changed.writer is True


def test_rebalance_commit_from_native_accepts_dict_payload():
    native = {
        "table_name": "docs",
        "new_table_version": 10,
        "status": "REBALANCING_IN_PROGRESS",
        "summary": {
            "total_segments": 1,
            "writer_moves": 1,
            "reader_moves": 0,
            "unchanged_count": 0,
            "writer_load_before": [],
            "writer_load_after": [],
            "reader_load_before": [],
            "reader_load_after": [],
        },
        "segments": [],
        "effective_reader_nodes": ["reader-1"],
        "effective_writer_nodes": ["writer-2"],
    }

    result = _rebalance_commit_from_native(native)

    assert result.new_table_version == 10
    assert result.status == "REBALANCING_IN_PROGRESS"


def test_rebalance_status_from_native_accepts_dict_payload():
    native = {
        "table_name": "docs",
        "status": "REBALANCING_IN_PROGRESS",
        "started_at": "2026-03-11T00:00:00Z",
        "ttl_seconds": 1800,
        "failure": None,
        "polling": {
            "evaluated_at": "2026-03-11T00:00:10Z",
            "nodes": [
                {
                    "node_id": "reader-1",
                    "segments": [
                        {
                            "segment_id": "seg-1",
                            "expected": "ADD",
                            "observed": "SYNCED",
                            "failure_reason": None,
                        }
                    ],
                }
            ],
        },
    }

    result = _rebalance_status_from_native(native)

    assert result.table_name == "docs"
    assert result.status == "REBALANCING_IN_PROGRESS"
    assert result.polling is not None
