import asyncio
import inspect
import sys
import types

import pytest

from seahorse_coral.types import (
    FileImportResult,
    ImportFilesResult,
    IndexedCountSummary,
    IndexedCounts,
    NodeInfo,
    RebalanceCommitRequest,
    RebalanceStatusResult,
    SegmentStructureSnapshot,
    RecordBatchStream,
    ResultSet,
    ResultSetStream,
    ResultSets,
)


def _run_sync(operation):
    result = operation() if callable(operation) else operation
    if inspect.isawaitable(result):
        return asyncio.run(result)
    return result


def test_node_info_from_dict_builds_typed_tree():
    node = NodeInfo.from_dict(
        {
            "node_id": "reader-1",
            "node_info": {
                "version": 1,
                "format_version": 2,
                "type": "READER",
                "state": "ACTIVE",
                "node_stage": "RUNNING",
                "last_updated": "20260108-00:00:00",
                "node_address": "localhost:6000",
                "assigned_tables": {
                    "docs": {
                        "table_oid": "table-oid",
                        "segments": {
                            "seg-1": {
                                "segment_oid": "segment-oid",
                                "status": "SYNCED",
                                "failure_reason": "",
                                "checkpoint": {
                                    "last_set_number": 7,
                                    "set_versions": ["0:1:10:0"],
                                    "set_index_counts": {"vector:hnsw": ["0:10"]},
                                },
                            }
                        },
                    }
                },
            },
        }
    )

    assert node.node_id == "reader-1"
    assert node.node_type == "READER"
    assert node.assigned_tables["docs"].table_oid == "table-oid"
    assert node.assigned_tables["docs"].segments["seg-1"].checkpoint.last_set_number == 7


def test_result_set_caches_pyarrow_parsing(monkeypatch):
    open_stream_calls = 0
    table_from_batches_calls = 0

    class FakeReader:
        def __iter__(self):
            return iter(["batch-1", "batch-2"])

    class FakeTable:
        def __init__(self, batches):
            self.batches = list(batches)

        def to_pandas(self):
            return {"batches": self.batches}

        def to_pylist(self):
            return [{"batches": self.batches}]

    def fake_open_stream(_payload):
        nonlocal open_stream_calls
        open_stream_calls += 1
        return FakeReader()

    def fake_from_batches(batches):
        nonlocal table_from_batches_calls
        table_from_batches_calls += 1
        return FakeTable(batches)

    fake_pyarrow = types.SimpleNamespace(
        ipc=types.SimpleNamespace(open_stream=fake_open_stream),
        Table=types.SimpleNamespace(from_batches=fake_from_batches),
    )
    monkeypatch.setitem(sys.modules, "pyarrow", fake_pyarrow)

    result = ResultSet(arrow_ipc=b"ipc", elapsed_time=0.25, rss_peak_bytes=1024)

    first_batches = result.to_record_batches()
    second_batches = result.to_record_batches()
    assert first_batches is second_batches
    assert open_stream_calls == 1

    first_table = result.to_pyarrow()
    second_table = result.to_pyarrow()
    assert first_table is second_table
    assert table_from_batches_calls == 1


def test_result_sets_split_batches_by_boundaries(monkeypatch):
    class FakeReader:
        def __iter__(self):
            return iter(["batch-1", "batch-2", "batch-3"])

    fake_pyarrow = types.SimpleNamespace(
        ipc=types.SimpleNamespace(open_stream=lambda _payload: FakeReader()),
        Table=types.SimpleNamespace(from_batches=lambda batches: list(batches)),
    )
    monkeypatch.setitem(sys.modules, "pyarrow", fake_pyarrow)

    result_sets = ResultSets(
        arrow_ipc=b"ipc",
        resultset_batch_counts=[2, 1],
        elapsed_time=0.5,
        rss_peak_bytes=2048,
    )

    materialized = list(result_sets)
    assert len(materialized) == 2
    assert materialized[0].to_record_batches() == ["batch-1", "batch-2"]
    assert materialized[1].to_record_batches() == ["batch-3"]


def test_import_files_result_summarizes_failures():
    result = ImportFilesResult(
        files=[
            FileImportResult(path="ok.parquet", success=True, inserted_row_count=10),
            FileImportResult(path="bad.parquet", success=False, error="decode failed"),
        ],
        total_inserted_record_batches=1,
        total_inserted_row_count=10,
    )

    assert result.succeeded_count == 1
    assert result.failed_count == 1
    assert result.all_succeeded is False
    assert result.failed_paths == ["bad.parquet"]


def test_indexed_counts_can_carry_readable_summary():
    result = IndexedCounts(
        total_row_count=10,
        indexed_counts=[],
        readable=IndexedCountSummary(total_row_count=9, indexed_counts=[]),
    )

    assert result.readable is not None
    assert result.readable.total_row_count == 9


def test_rebalance_commit_request_to_dict_round_trips():
    request = RebalanceCommitRequest(
        expected_table_version=9,
        expected_segment_structure=SegmentStructureSnapshot(
            segmentation_info=None,
            segment_ids=["seg-1"],
            segment_assignments={},
        ),
        writer_nodes=["writer-2"],
        strategy="balanced_min_moves",
    )

    round_tripped = RebalanceCommitRequest.from_dict(request.to_dict())

    assert round_tripped.expected_table_version == 9
    assert round_tripped.writer_nodes == ["writer-2"]
    assert round_tripped.strategy == "balanced_min_moves"


def test_rebalance_status_result_from_dict_builds_polling_tree():
    result = RebalanceStatusResult.from_dict(
        {
            "table_name": "docs",
            "status": "REBALANCING_IN_PROGRESS",
            "started_at": "2026-03-11T00:00:00Z",
            "ttl_seconds": 1800,
            "polling": {
                "evaluated_at": "2026-03-11T00:00:10Z",
                "nodes": [
                    {
                        "node_id": "reader-1",
                        "segments": [
                            {
                                "segment_id": "seg-1",
                                "expected": "ADD",
                                "observed": "SYNCED",
                            }
                        ],
                    }
                ],
            },
        }
    )

    assert result.status == "REBALANCING_IN_PROGRESS"
    assert result.polling is not None
    assert result.polling.nodes[0].segments[0].observed == "SYNCED"


def test_record_batch_stream_sync_iteration(monkeypatch):
    monkeypatch.setattr(
        "seahorse_coral.types._decode_single_record_batch",
        lambda payload: f"decoded:{payload.decode()}",
    )

    class NativeStream:
        def __init__(self):
            self._items = iter([b"a", b"b", None])
            self.elapsed_time = None
            self.rss_peak_bytes = None

        async def next_batch(self):
            return next(self._items)

        async def close(self):
            self.elapsed_time = 0.75
            self.rss_peak_bytes = 4096

    stream = RecordBatchStream(NativeStream(), run_async=_run_sync)

    assert list(stream) == ["decoded:a", "decoded:b"]
    stream.close()
    assert stream.elapsed_time == pytest.approx(0.75)
    assert stream.rss_peak_bytes == 4096


def test_result_set_stream_sync_iteration():
    class NativeStream:
        def __init__(self):
            self._items = iter([b"rs1", b"rs2", None])
            self.elapsed_time = None
            self.rss_peak_bytes = None

        async def next_resultset(self):
            return next(self._items)

        async def close(self):
            self.elapsed_time = 1.25
            self.rss_peak_bytes = 8192

    stream = ResultSetStream(NativeStream(), run_async=_run_sync)
    results = list(stream)

    assert [result.arrow_ipc for result in results] == [b"rs1", b"rs2"]
    stream.close()
    assert stream.elapsed_time == pytest.approx(1.25)
    assert stream.rss_peak_bytes == 8192
