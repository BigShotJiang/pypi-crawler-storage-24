import asyncio
import sys
import types
from types import SimpleNamespace

import pytest

from seahorse_coral.coral import (
    AsyncCoral,
    Coral,
    _arrow_ipc_from_value,
    _node_snapshot_from_native,
    _result_set_from_native,
    _result_sets_from_native,
)
from seahorse_coral.exceptions import ImportFilesError, PartialImportError, SeahorseError
from seahorse_coral.schema import (
    SchemaBuilder,
    hnsw_index,
    int64_column,
    metadata_column,
    vector_column,
)
from seahorse_coral.storage import ImportOptions, local_file, s3_file
from seahorse_coral.table import AsyncTable, Table
from seahorse_coral.types import (
    ActiveSetFlushResult,
    ImportFilesResult,
    IndexedCounts,
    InsertResult,
    NodeInfo,
    RebalanceCommitResult,
    RebalancePlanResult,
    RebalanceStatusResult,
    RecordBatchStream,
    ResultSet,
    ResultSetStream,
    ResultSets,
    SegmentsRetryResult,
    SegmentsStatusResult,
    TableSchema,
    TableInfo,
)


def _test_schema_dict(table_name: str = "docs"):
    return (
        SchemaBuilder()
        .int64("id", nullable=False)
        .vector("vector", dim=3)
        .metadata()
        .with_primary_key("id")
        .hnsw("vector")
        .to_dict(table_name=table_name)
    )


def _test_node_native():
    return SimpleNamespace(
        node_id="reader-1",
        node_info=SimpleNamespace(
            version=1,
            format_version=2,
            type="READER",
            state="ACTIVE",
            node_stage="RUNNING",
            last_updated="2026-03-11T00:00:00Z",
            node_address="localhost:6000",
            assigned_tables={
                "docs": SimpleNamespace(
                    table_oid="table-oid",
                    segments={
                        "seg-1": SimpleNamespace(
                            segment_oid="segment-oid",
                            status="SYNCED",
                            failure_reason="",
                            checkpoint=SimpleNamespace(
                                last_set_number=7,
                                set_versions=["0:1:10:0"],
                                set_index_counts={"vector:hnsw": ["0:10"]},
                            ),
                        )
                    },
                )
            },
        ),
    )


def _test_segments_status_native():
    return SimpleNamespace(
        table_name="docs",
        table_status="ACTIVE",
        mode="active",
        started_at="2026-03-11T00:00:00Z",
        ttl_seconds=30,
        summary=SimpleNamespace(total=5, synced=3, failed=1, pending=1),
        polling=SimpleNamespace(
            evaluated_at="2026-03-11T00:00:10Z",
            nodes=[
                SimpleNamespace(
                    node_id="reader-1",
                    segments=[
                        SimpleNamespace(
                            segment_id="seg-1",
                            expected="ADD",
                            observed="SYNCED",
                            failure_reason=None,
                        )
                    ],
                )
            ],
        ),
        failure=None,
    )


def _test_segments_retry_native():
    return SimpleNamespace(
        table_name="docs",
        table_status="REBALANCING_IN_PROGRESS",
        summary=SimpleNamespace(
            mode="rebalance",
            total_nodes=2,
            published_segment_count=3,
            skipped_node_count=1,
            truncated=False,
        ),
        nodes=[
            SimpleNamespace(
                node_id="reader-1",
                published_segments=["seg-1", "seg-2"],
                skipped=None,
                observations=SimpleNamespace(
                    missing_nodeinfo=False,
                    missing_table_assignment=False,
                    missing_segment_count=0,
                    failed_segment_count=1,
                    synced_segment_count=2,
                    not_removed_segment_count=0,
                ),
            )
        ],
    )


def _test_rebalance_plan_native():
    return {
        "table_name": "docs",
        "expected_table_version": 9,
        "strategy": "balanced_min_moves",
        "expected_segment_structure": {
            "segmentation_info": {
                "segment_type": "hash",
                "segment_keys": ["id"],
                "num_buckets": 4,
            },
            "segment_ids": ["seg-1"],
            "segment_assignments": {
                "seg-1": {
                    "segment_id": "seg-1",
                    "readers": ["reader-1"],
                    "writer": "writer-1",
                }
            },
        },
        "effective_reader_nodes": ["reader-1"],
        "effective_writer_nodes": ["writer-1"],
        "summary": {
            "total_segments": 1,
            "writer_moves": 1,
            "reader_moves": 0,
            "unchanged_count": 0,
            "writer_load_before": [{"node_id": "writer-1", "count": 1}],
            "writer_load_after": [{"node_id": "writer-2", "count": 1}],
            "reader_load_before": [{"node_id": "reader-1", "count": 1}],
            "reader_load_after": [{"node_id": "reader-1", "count": 1}],
        },
        "segments": [
            {
                "segment_id": "seg-1",
                "before": {"writer": "writer-1", "readers": ["reader-1"]},
                "after": {"writer": "writer-2", "readers": ["reader-1"]},
                "changed": {"writer": True, "readers": False},
            }
        ],
        "commit_template": {
            "reader_nodes": ["reader-1"],
            "writer_nodes": ["writer-2"],
            "strategy": "balanced_min_moves",
            "expected_table_version": 9,
            "expected_segment_structure": {
                "segmentation_info": {
                    "segment_type": "hash",
                    "segment_keys": ["id"],
                    "num_buckets": 4,
                },
                "segment_ids": ["seg-1"],
                "segment_assignments": {
                    "seg-1": {
                        "segment_id": "seg-1",
                        "readers": ["reader-1"],
                        "writer": "writer-2",
                    }
                },
            },
        },
    }


def _test_rebalance_commit_native():
    return {
        "table_name": "docs",
        "new_table_version": 10,
        "status": "REBALANCING_IN_PROGRESS",
        "summary": {
            "total_segments": 1,
            "writer_moves": 1,
            "reader_moves": 0,
            "unchanged_count": 0,
            "writer_load_before": [{"node_id": "writer-1", "count": 1}],
            "writer_load_after": [{"node_id": "writer-2", "count": 1}],
            "reader_load_before": [{"node_id": "reader-1", "count": 1}],
            "reader_load_after": [{"node_id": "reader-1", "count": 1}],
        },
        "segments": [
            {
                "segment_id": "seg-1",
                "before": {"writer": "writer-1", "readers": ["reader-1"]},
                "after": {"writer": "writer-2", "readers": ["reader-1"]},
                "changed": {"writer": True, "readers": False},
            }
        ],
        "effective_reader_nodes": ["reader-1"],
        "effective_writer_nodes": ["writer-2"],
    }


def _test_rebalance_status_native():
    return {
        "table_name": "docs",
        "status": "REBALANCING_IN_PROGRESS",
        "started_at": "2026-03-11T00:00:00Z",
        "ttl_seconds": 1800,
        "failure": None,
        "polling": {
            "evaluated_at": "2026-03-11T00:00:10Z",
            "nodes": [
                {
                    "node_id": "reader-1",
                    "segments": [
                        {
                            "segment_id": "seg-1",
                            "expected": "ADD",
                            "observed": "SYNCED",
                            "failure_reason": None,
                        }
                    ],
                }
            ],
        },
    }


def _test_import_files_native(paths, failures=None):
    failures = failures or {}
    results = []
    total_inserted_record_batches = 0
    total_inserted_row_count = 0

    for path in paths:
        error = failures.get(path)
        success = error is None
        inserted_record_batches = 1 if success else 0
        inserted_row_count = 10 if success else 0
        total_inserted_record_batches += inserted_record_batches
        total_inserted_row_count += inserted_row_count
        results.append(
            SimpleNamespace(
                path=path,
                success=success,
                inserted_record_batches=inserted_record_batches,
                inserted_row_count=inserted_row_count,
                error=error,
            )
        )

    return SimpleNamespace(
        results=results,
        total_inserted_record_batches=total_inserted_record_batches,
        total_inserted_row_count=total_inserted_row_count,
        elapsed_time=0.6,
        rss_peak_bytes=4096,
    )


class DummyRecordBatchStream:
    def __init__(self, values):
        self._values = iter(values)
        self.elapsed_time = None
        self.rss_peak_bytes = None

    async def next_batch(self):
        return next(self._values)

    async def close(self):
        self.elapsed_time = 0.4
        self.rss_peak_bytes = 2048


class DummyResultSetStream:
    def __init__(self, values):
        self._values = iter(values)
        self.elapsed_time = None
        self.rss_peak_bytes = None

    async def next_resultset(self):
        return next(self._values)

    async def close(self):
        self.elapsed_time = 0.9
        self.rss_peak_bytes = 4096


class DummyClient:
    def __init__(self):
        self.created_table = None
        self.deleted_table = None
        self.last_update = None
        self.last_delete = None
        self.last_rebalance_plan = None
        self.last_rebalance_commit = None
        self.last_insert_jsonl = None
        self.last_insert_arrow = None
        self.last_insert_parquet = None
        self.last_import = None
        self.import_failures = {}

    async def health_check(self):
        return "OK"

    async def get_nodes(self):
        return [_test_node_native()]

    async def list_tables(self, name_only=None, internal=None):
        if name_only:
            return ["docs", "images"]
        return [
            SimpleNamespace(table_name="docs", schema=_test_schema_dict()),
            SimpleNamespace(table_name="images", schema=None),
        ]

    async def get_table_schema(self, table_name, internal=None):
        return SimpleNamespace(table_name=table_name, schema=_test_schema_dict(table_name))

    async def create_table(self, table_name, schema):
        self.created_table = (table_name, schema)
        return True

    async def delete_table(self, table_name):
        self.deleted_table = table_name
        return True

    async def update_table_data(self, table_name, update_values, update_condition):
        self.last_update = (table_name, update_values, update_condition)

    async def delete_table_data(self, table_name, delete_condition):
        self.last_delete = (table_name, delete_condition)

    async def active_set_flush(self, table_name, segment_ids, sync_mode):
        return SimpleNamespace(flushed=["seg-1"], failed=[], skipped=["seg-2"])

    async def segments_status(self, table_name):
        return _test_segments_status_native()

    async def segments_retry(
        self,
        table_name,
        mode,
        only_failed,
        skip_unsubscribed,
        dry_run,
        max_targets,
    ):
        return _test_segments_retry_native()

    async def rebalance_plan(self, table_name, reader_nodes, writer_nodes, strategy):
        self.last_rebalance_plan = (table_name, reader_nodes, writer_nodes, strategy)
        return _test_rebalance_plan_native()

    async def rebalance_commit(self, table_name, request):
        self.last_rebalance_commit = (table_name, request)
        return _test_rebalance_commit_native()

    async def rebalance_status(self, table_name):
        return _test_rebalance_status_native()

    async def insert_data(self, table_name, jsonl, reader_batch_size, use_async_read):
        self.last_insert_jsonl = (table_name, jsonl, reader_batch_size, use_async_read)
        return SimpleNamespace(
            inserted_record_batches=1,
            inserted_row_count=2,
            total_inserted_record_batches=1,
            total_inserted_row_count=2,
        )

    async def insert_arrow_stream(self, table_name, arrow_ipc):
        self.last_insert_arrow = (table_name, arrow_ipc)
        return SimpleNamespace(
            inserted_record_batches=1,
            inserted_row_count=1,
            total_inserted_record_batches=1,
            total_inserted_row_count=1,
        )

    async def insert_parquet_as_arrow_stream(self, table_name, path, batch_size):
        self.last_insert_parquet = (table_name, path, batch_size)
        return SimpleNamespace(
            inserted_record_batches=4,
            inserted_row_count=100,
            total_inserted_record_batches=4,
            total_inserted_row_count=100,
        )

    async def insert_from_file(
        self,
        table_name,
        paths,
        storage_type,
        bucket,
        access_key,
        secret_key,
        region,
        endpoint,
        virtual_hosted_style,
        allow_http,
        format,
        reader_batch_size,
        max_concurrent_files,
    ):
        self.last_import = (
            table_name,
            paths,
            storage_type,
            bucket,
            format,
            reader_batch_size,
            max_concurrent_files,
        )
        return _test_import_files_native(paths, failures=self.import_failures)

    async def scan_data(self, table_name, projection, filter, limit, include_metrics, allow_writer):
        return SimpleNamespace(
            arrow_ipc=b"scan-arrow",
            elapsed_time=0.25,
            rss_peak_bytes=1024,
        )

    async def scan_data_stream(
        self,
        table_name,
        projection,
        filter,
        limit,
        include_metrics,
        allow_writer,
    ):
        return DummyRecordBatchStream([b"scan-batch-1", b"scan-batch-2", None])

    async def vector_search(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        ef_search,
        projection,
        filter,
    ):
        return SimpleNamespace(arrow_ipc=b"vector-single", elapsed_time=0.3, rss_peak_bytes=1200)

    async def vector_search_batch(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        ef_search,
        projection,
        filter,
    ):
        return SimpleNamespace(
            arrow_ipc=b"vector-batch",
            resultset_batch_counts=[1, 2],
            elapsed_time=0.5,
            rss_peak_bytes=1500,
        )

    async def vector_search_stream(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        ef_search,
        projection,
        filter,
    ):
        return DummyRecordBatchStream([b"vector-batch-1", None])

    async def vector_search_batch_stream(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        ef_search,
        projection,
        filter,
    ):
        return DummyResultSetStream([b"vector-rs-1", b"vector-rs-2", None])

    async def vector_search_sparse(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        bm25_k,
        bm25_b,
        metadata,
        projection,
        filter,
    ):
        return SimpleNamespace(arrow_ipc=b"sparse-single", elapsed_time=0.35, rss_peak_bytes=1300)

    async def vector_search_sparse_batch(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        bm25_k,
        bm25_b,
        metadata,
        projection,
        filter,
    ):
        return SimpleNamespace(
            arrow_ipc=b"sparse-batch",
            resultset_batch_counts=[1, 1],
            elapsed_time=0.55,
            rss_peak_bytes=1700,
        )

    async def vector_search_sparse_stream(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        bm25_k,
        bm25_b,
        metadata,
        projection,
        filter,
    ):
        return DummyRecordBatchStream([b"sparse-batch-1", None])

    async def vector_search_sparse_batch_stream(
        self,
        table_name,
        index_name,
        query_vectors,
        top_k,
        bm25_k,
        bm25_b,
        metadata,
        projection,
        filter,
    ):
        return DummyResultSetStream([b"sparse-rs-1", b"sparse-rs-2", None])

    async def hybrid_search(
        self,
        table_name,
        top_k,
        dense_column,
        dense_queries,
        sparse_column,
        sparse_queries,
        fusion_type,
        rrf_k,
        alpha,
        ef_search,
        bm25_k,
        bm25_b,
        sparse_metadata,
        projection,
        filter,
    ):
        return SimpleNamespace(arrow_ipc=b"hybrid-single", elapsed_time=0.45, rss_peak_bytes=1400)

    async def hybrid_search_batch(
        self,
        table_name,
        top_k,
        dense_column,
        dense_queries,
        sparse_column,
        sparse_queries,
        fusion_type,
        rrf_k,
        alpha,
        ef_search,
        bm25_k,
        bm25_b,
        sparse_metadata,
        projection,
        filter,
    ):
        return SimpleNamespace(
            arrow_ipc=b"hybrid-batch",
            resultset_batch_counts=[1],
            elapsed_time=0.65,
            rss_peak_bytes=1800,
        )

    async def hybrid_search_stream(
        self,
        table_name,
        top_k,
        dense_column,
        dense_queries,
        sparse_column,
        sparse_queries,
        fusion_type,
        rrf_k,
        alpha,
        ef_search,
        bm25_k,
        bm25_b,
        sparse_metadata,
        projection,
        filter,
    ):
        return DummyRecordBatchStream([b"hybrid-batch-1", None])

    async def hybrid_search_batch_stream(
        self,
        table_name,
        top_k,
        dense_column,
        dense_queries,
        sparse_column,
        sparse_queries,
        fusion_type,
        rrf_k,
        alpha,
        ef_search,
        bm25_k,
        bm25_b,
        sparse_metadata,
        projection,
        filter,
    ):
        return DummyResultSetStream([b"hybrid-rs-1", None])

    async def get_indexed_row_count(self, table_name, readable):
        return SimpleNamespace(
            total_row_count=10,
            indexed_counts=[
                SimpleNamespace(index_name="vector", index_type="HNSW", indexed_row_count=10)
            ],
            readable=SimpleNamespace(
                total_row_count=9,
                indexed_counts=[
                    SimpleNamespace(
                        index_name="vector", index_type="HNSW", indexed_row_count=9
                    )
                ],
            )
            if readable
            else None,
        )


class FutureReturningClient:
    def _ready(self, value):
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        future.set_result(value)
        return future

    def health_check(self):
        return self._ready("OK")

    def get_nodes(self):
        return self._ready([_test_node_native()])


def _make_sync_coral(client: DummyClient) -> Coral:
    coral = object.__new__(Coral)
    coral._client = client
    coral._timeout = None
    coral._url = "http://localhost:3000"
    return coral


def _make_async_coral(client: DummyClient) -> AsyncCoral:
    coral = object.__new__(AsyncCoral)
    coral._client = client
    coral._timeout = None
    coral._url = "http://localhost:3000"
    return coral


def test_native_result_converters():
    single = _result_set_from_native(
        SimpleNamespace(arrow_ipc=b"single", elapsed_time=0.2, rss_peak_bytes=100)
    )
    multiple = _result_sets_from_native(
        SimpleNamespace(
            arrow_ipc=b"multi",
            resultset_batch_counts=[1, 1],
            elapsed_time=0.4,
            rss_peak_bytes=200,
        )
    )
    node = _node_snapshot_from_native(_test_node_native())

    assert isinstance(single, ResultSet)
    assert isinstance(multiple, ResultSets)
    assert isinstance(node, NodeInfo)


def test_arrow_ipc_from_value_supports_record_batch_sequences(monkeypatch):
    class FakeBuffer:
        def __init__(self):
            self.payload = b""

        def write(self, data):
            self.payload += data

        def getvalue(self):
            return types.SimpleNamespace(to_pybytes=lambda: self.payload)

    class FakeRecordBatch:
        def __init__(self, schema, rows):
            self.schema = schema
            self.rows = rows

    class FakeWriter:
        def __init__(self, sink, schema):
            self._sink = sink
            self._schema = schema

        def write_batch(self, batch):
            self._sink.write(f"{self._schema}:{batch.rows}|".encode())

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

    fake_pyarrow = types.SimpleNamespace(
        RecordBatch=FakeRecordBatch,
        Table=type("FakeTable", (), {}),
        BufferOutputStream=lambda: FakeBuffer(),
        ipc=types.SimpleNamespace(new_stream=lambda sink, schema: FakeWriter(sink, schema)),
    )
    monkeypatch.setitem(sys.modules, "pyarrow", fake_pyarrow)

    payload = _arrow_ipc_from_value(
        [FakeRecordBatch("schema-1", 1), FakeRecordBatch("schema-1", 2)]
    )

    assert payload == b"schema-1:1|schema-1:2|"


def test_sync_coral_surface(monkeypatch, tmp_path):
    monkeypatch.setattr(
        "seahorse_coral.types._decode_single_record_batch",
        lambda payload: f"decoded:{payload.decode()}",
    )

    client = DummyClient()
    coral = _make_sync_coral(client)
    parquet_file = tmp_path / "data.parquet"
    parquet_file.write_bytes(b"PAR1")

    assert coral.health() == "OK"
    nodes = coral.nodes()
    assert isinstance(nodes[0], NodeInfo)

    tables = coral.list_tables()
    assert [table.table_name for table in tables] == ["docs", "images"]
    assert all(isinstance(table, TableInfo) for table in tables)
    assert coral.list_table_names() == ["docs", "images"]

    table = coral.get_table("docs")
    assert isinstance(table, Table)

    created = coral.create_table(
        "created_docs",
        columns=[
            int64_column("id", nullable=False),
            vector_column("vector", dim=3),
            metadata_column("metadata"),
        ],
        primary_key=["id"],
        indexes=[hnsw_index("vector")],
    )
    assert isinstance(created, Table)
    assert client.created_table[0] == "created_docs"

    schema = table.schema()
    assert isinstance(schema, TableSchema)

    rows_result = table.insert_rows([{"id": 1}, {"id": 2}], reader_batch_size=32)
    jsonl_result = table.insert_jsonl('{"id": 1}\n')
    arrow_result = table.insert_arrow(b"ARROW")
    parquet_result = table.insert_parquet(parquet_file, batch_size=128)
    local_source_result = table.insert_parquet(local_file(str(parquet_file)), batch_size=64)
    remote_source_result = table.insert_parquet(
        s3_file("data.parquet", bucket="bucket"),
        options=ImportOptions(),
    )
    remote_import = client.last_import
    import_result = table.import_files(
        local_file(["data-1.parquet", "data-2.parquet"]),
        options=ImportOptions(),
    )
    assert all(
        isinstance(result, InsertResult)
        for result in (
            rows_result,
            jsonl_result,
            arrow_result,
            parquet_result,
            local_source_result,
            remote_source_result,
        )
    )
    assert isinstance(import_result, ImportFilesResult)
    assert import_result.all_succeeded is True
    assert remote_source_result.inserted_record_batches == 1
    assert remote_source_result.inserted_row_count == 10
    assert import_result.total_inserted_row_count == 20
    assert import_result.elapsed_time == pytest.approx(0.6)
    assert import_result.rss_peak_bytes == 4096
    assert [item.path for item in import_result.files] == [
        "data-1.parquet",
        "data-2.parquet",
    ]
    assert import_result.files[0].inserted_record_batches == 1
    assert import_result.files[0].inserted_row_count == 10
    assert client.last_insert_parquet == ("docs", str(parquet_file), 64)
    assert remote_import[:5] == ("docs", ["data.parquet"], "S3", "bucket", "Parquet")
    assert client.last_import[:5] == ("docs", ["data-1.parquet", "data-2.parquet"], "LOCAL", None, "Parquet")

    scan_result = table.scan(select="id", include_metrics=True)
    assert isinstance(scan_result, ResultSet)
    assert scan_result.arrow_ipc == b"scan-arrow"

    scan_stream = table.scan_stream(limit=10)
    assert isinstance(scan_stream, RecordBatchStream)
    assert list(scan_stream) == ["decoded:scan-batch-1", "decoded:scan-batch-2"]

    index = table.index("vector")
    assert index.search([0.1, 0.2, 0.3], top_k=3).arrow_ipc == b"vector-single"
    assert isinstance(index.search_batch([[0.1], [0.2]], top_k=3), ResultSets)
    assert list(index.search_stream([0.1, 0.2], top_k=3)) == ["decoded:vector-batch-1"]
    resultset_stream = index.search_batch_stream([[0.1], [0.2]], top_k=3)
    assert isinstance(resultset_stream, ResultSetStream)
    assert [result.arrow_ipc for result in resultset_stream] == [b"vector-rs-1", b"vector-rs-2"]

    assert index.search_sparse("1:0.5 2:0.3").arrow_ipc == b"sparse-single"
    assert isinstance(index.search_sparse_batch(["1:0.5", "2:0.5"]), ResultSets)

    hybrid = table.hybrid_search(
        dense_column="vector",
        dense_query=[0.1, 0.2, 0.3],
        sparse_column="sparse_vector",
        sparse_query="1:0.5 2:0.3",
        top_k=3,
    )
    hybrid_batch = table.hybrid_search_batch(
        dense_column="vector",
        dense_queries=[[0.1]],
        sparse_column="sparse_vector",
        sparse_queries=["1:0.5"],
        top_k=3,
    )
    hybrid_stream = table.hybrid_search_stream(
        dense_column="vector",
        dense_query=[0.1, 0.2],
        sparse_column="sparse_vector",
        sparse_query="1:0.5",
    )
    hybrid_batch_stream = table.hybrid_search_batch_stream(
        dense_column="vector",
        dense_queries=[[0.1]],
        sparse_column="sparse_vector",
        sparse_queries=["1:0.5"],
    )
    assert isinstance(hybrid, ResultSet)
    assert isinstance(hybrid_batch, ResultSets)
    assert isinstance(hybrid_stream, RecordBatchStream)
    assert isinstance(hybrid_batch_stream, ResultSetStream)

    with pytest.raises(ValueError, match="exactly one dense and one sparse query"):
        table.hybrid_search_batch(
            dense_column="vector",
            dense_queries=[[0.1], [0.2]],
            sparse_column="sparse_vector",
            sparse_queries=["1:0.5", "2:0.5"],
            top_k=3,
        )

    with pytest.raises(ValueError, match="exactly one dense and one sparse query"):
        table.hybrid_search_batch_stream(
            dense_column="vector",
            dense_queries=[[0.1], [0.2]],
            sparse_column="sparse_vector",
            sparse_queries=["1:0.5", "2:0.5"],
        )

    flush_result = table.active_set_flush()
    status_result = table.segments_status()
    retry_result = table.segments_retry()
    plan_result = table.rebalance_plan(writer_nodes=["writer-2"])
    commit_result = table.rebalance_commit(plan_result.commit_template)
    rebalance_status = table.rebalance_status()
    table.update_rows("metadata = 'updated'", where="id = 1")
    table.delete_rows(where="id = 2")
    indexed_count = table.indexed_row_count()
    assert isinstance(flush_result, ActiveSetFlushResult)
    assert isinstance(status_result, SegmentsStatusResult)
    assert isinstance(retry_result, SegmentsRetryResult)
    assert isinstance(plan_result, RebalancePlanResult)
    assert isinstance(commit_result, RebalanceCommitResult)
    assert isinstance(rebalance_status, RebalanceStatusResult)
    assert isinstance(indexed_count, IndexedCounts)
    assert indexed_count.readable is not None
    assert indexed_count.readable.total_row_count == 9
    assert client.last_update == ("docs", "metadata = 'updated'", "id = 1")
    assert client.last_delete == ("docs", "id = 2")
    assert client.last_rebalance_plan == (
        "docs",
        None,
        ["writer-2"],
        None,
    )
    assert client.last_rebalance_commit[0] == "docs"
    assert client.last_rebalance_commit[1]["expected_table_version"] == 9

    assert table.drop() is True
    assert client.deleted_table == "docs"


def test_import_files_partial_failure_raises_partial_import_error():
    client = DummyClient()
    client.import_failures = {"data-2.parquet": "decode failed"}
    coral = _make_sync_coral(client)
    table = coral.get_table("docs")

    with pytest.raises(PartialImportError) as exc_info:
        table.import_files(
            local_file(["data-1.parquet", "data-2.parquet"]),
            options=ImportOptions(),
        )

    result = exc_info.value.result
    assert result.total_inserted_row_count == 10
    assert result.elapsed_time == pytest.approx(0.6)
    assert result.rss_peak_bytes == 4096
    assert result.failed_paths == ["data-2.parquet"]
    assert exc_info.value.details == "data-2.parquet: decode failed"


def test_import_files_can_return_partial_result_when_strict_false():
    client = DummyClient()
    client.import_failures = {"data-2.parquet": "decode failed"}
    coral = _make_sync_coral(client)
    table = coral.get_table("docs")

    result = table.import_files(
        local_file(["data-1.parquet", "data-2.parquet"]),
        options=ImportOptions(),
        strict=False,
    )

    assert isinstance(result, ImportFilesResult)
    assert result.succeeded_count == 1
    assert result.failed_count == 1
    assert result.failed_paths == ["data-2.parquet"]


def test_import_files_all_failure_raises_import_files_error():
    client = DummyClient()
    client.import_failures = {
        "data-1.parquet": "decode failed",
        "data-2.parquet": "permission denied",
    }
    coral = _make_sync_coral(client)
    table = coral.get_table("docs")

    with pytest.raises(ImportFilesError) as exc_info:
        table.import_files(
            local_file(["data-1.parquet", "data-2.parquet"]),
            options=ImportOptions(),
        )

    assert not isinstance(exc_info.value, PartialImportError)
    assert exc_info.value.result.failed_count == 2
    assert exc_info.value.result.total_inserted_row_count == 0


def test_sync_coral_supports_future_returning_client_without_running_loop():
    coral = _make_sync_coral(FutureReturningClient())

    assert coral.health() == "OK"
    nodes = coral.nodes()
    assert isinstance(nodes[0], NodeInfo)


def test_sync_coral_supports_future_returning_client_inside_running_loop():
    coral = _make_sync_coral(FutureReturningClient())

    async def run():
        assert coral.health() == "OK"
        nodes = coral.nodes()
        assert isinstance(nodes[0], NodeInfo)

    asyncio.run(run())


def test_insert_parquet_rejects_local_directories(tmp_path):
    client = DummyClient()
    coral = _make_sync_coral(client)
    table = coral.get_table("docs")
    directory = tmp_path / "dataset"
    directory.mkdir()

    with pytest.raises(ValueError, match="Use import_files\\(\\) for directories"):
        table.insert_parquet(directory)


def test_insert_parquet_rejects_missing_local_files(tmp_path):
    client = DummyClient()
    coral = _make_sync_coral(client)
    table = coral.get_table("docs")

    with pytest.raises(FileNotFoundError, match="local file not found"):
        table.insert_parquet(tmp_path / "missing.parquet")


def test_insert_parquet_remote_failure_raises_seahorse_error():
    client = DummyClient()
    client.import_failures = {"data.parquet": "decode failed"}
    coral = _make_sync_coral(client)
    table = coral.get_table("docs")

    with pytest.raises(SeahorseError, match="Insert parquet failed: Import files failed"):
        table.insert_parquet(
            s3_file("data.parquet", bucket="bucket"),
            options=ImportOptions(),
        )


def test_async_coral_surface(monkeypatch):
    monkeypatch.setattr(
        "seahorse_coral.types._decode_single_record_batch",
        lambda payload: f"decoded:{payload.decode()}",
    )

    async def run():
        client = DummyClient()
        coral = _make_async_coral(client)

        assert await coral.health() == "OK"
        assert isinstance((await coral.nodes())[0], NodeInfo)

        assert all(isinstance(item, TableInfo) for item in await coral.list_tables())
        assert await coral.list_table_names() == ["docs", "images"]

        table = await coral.get_table("docs")
        assert isinstance(table, AsyncTable)

        created = await coral.create_table(
            "async_docs",
            columns=[
                int64_column("id", nullable=False),
                vector_column("vector", dim=3),
                metadata_column("metadata"),
            ],
            primary_key=["id"],
            indexes=[hnsw_index("vector")],
        )
        assert isinstance(created, AsyncTable)

        assert isinstance(await table.schema(), TableSchema)
        assert isinstance(await table.insert_rows([{"id": 1}]), InsertResult)
        remote_insert = await table.insert_parquet(s3_file("data.parquet", bucket="bucket"))
        import_result = await table.import_files(
            local_file(["data-1.parquet", "data-2.parquet"]),
            options=ImportOptions(),
        )
        assert isinstance(remote_insert, InsertResult)
        assert remote_insert.inserted_record_batches == 1
        assert remote_insert.inserted_row_count == 10
        assert isinstance(import_result, ImportFilesResult)
        assert import_result.elapsed_time == pytest.approx(0.6)
        assert import_result.rss_peak_bytes == 4096
        assert isinstance(await table.scan(), ResultSet)
        scan_stream = await table.scan_stream(limit=10)
        assert [batch async for batch in scan_stream] == [
            "decoded:scan-batch-1",
            "decoded:scan-batch-2",
        ]

        index = table.index("vector")
        assert isinstance(await index.search([0.1, 0.2]), ResultSet)
        assert isinstance(await index.search_batch([[0.1], [0.2]]), ResultSets)
        vector_stream = await index.search_stream([0.1, 0.2])
        assert [batch async for batch in vector_stream] == ["decoded:vector-batch-1"]
        vector_batch_stream = await index.search_batch_stream([[0.1], [0.2]])
        assert [result.arrow_ipc async for result in vector_batch_stream] == [
            b"vector-rs-1",
            b"vector-rs-2",
        ]

        assert isinstance(
            await table.hybrid_search(
                dense_column="vector",
                dense_query=[0.1, 0.2],
                sparse_column="sparse_vector",
                sparse_query="1:0.5",
            ),
            ResultSet,
        )
        assert isinstance(
            await table.hybrid_search_batch(
                dense_column="vector",
                dense_queries=[[0.1, 0.2]],
                sparse_column="sparse_vector",
                sparse_queries=["1:0.5"],
            ),
            ResultSets,
        )
        hybrid_batch_stream = await table.hybrid_search_batch_stream(
            dense_column="vector",
            dense_queries=[[0.1, 0.2]],
            sparse_column="sparse_vector",
            sparse_queries=["1:0.5"],
        )
        assert [result.arrow_ipc async for result in hybrid_batch_stream] == [b"hybrid-rs-1"]

        with pytest.raises(ValueError, match="exactly one dense and one sparse query"):
            await table.hybrid_search_batch(
                dense_column="vector",
                dense_queries=[[0.1], [0.2]],
                sparse_column="sparse_vector",
                sparse_queries=["1:0.5", "2:0.5"],
            )

        with pytest.raises(ValueError, match="exactly one dense and one sparse query"):
            await table.hybrid_search_batch_stream(
                dense_column="vector",
                dense_queries=[[0.1], [0.2]],
                sparse_column="sparse_vector",
                sparse_queries=["1:0.5", "2:0.5"],
            )
        assert isinstance(await table.indexed_row_count(), IndexedCounts)
        await table.update_rows("metadata = 'updated'", where="id = 1")
        await table.delete_rows(where="id = 2")
        plan_result = await table.rebalance_plan(writer_nodes=["writer-2"])
        assert isinstance(plan_result, RebalancePlanResult)
        assert isinstance(
            await table.rebalance_commit(plan_result.commit_template),
            RebalanceCommitResult,
        )
        assert isinstance(await table.rebalance_status(), RebalanceStatusResult)
        assert await table.drop() is True

    asyncio.run(run())


def test_async_insert_parquet_remote_failure_raises_seahorse_error():
    async def run():
        client = DummyClient()
        client.import_failures = {"data.parquet": "decode failed"}
        coral = _make_async_coral(client)
        table = await coral.get_table("docs")

        with pytest.raises(SeahorseError, match="Insert parquet failed: Import files failed"):
            await table.insert_parquet(
                s3_file("data.parquet", bucket="bucket"),
                options=ImportOptions(),
            )

    asyncio.run(run())


def test_async_insert_parquet_rejects_missing_local_files(tmp_path):
    async def run():
        client = DummyClient()
        coral = _make_async_coral(client)
        table = await coral.get_table("docs")

        with pytest.raises(FileNotFoundError, match="local file not found"):
            await table.insert_parquet(tmp_path / "missing.parquet")

    asyncio.run(run())
