"""Import surface tests for seahorse-coral package."""


def test_import_package():
    import seahorse_coral

    assert seahorse_coral is not None
    assert isinstance(seahorse_coral.__version__, str)


def test_import_clients():
    from seahorse_coral import AsyncCoral, Coral

    assert callable(Coral)
    assert callable(AsyncCoral)


def test_import_objects():
    from seahorse_coral import AsyncCoral, AsyncIndex, AsyncTable, Coral, Index, Table

    assert Coral is not None
    assert AsyncCoral is not None
    assert Table is not None
    assert AsyncTable is not None
    assert Index is not None
    assert AsyncIndex is not None


def test_import_result_types():
    from seahorse_coral import RecordBatchStream, ResultSet, ResultSetStream, ResultSets

    assert ResultSet is not None
    assert ResultSets is not None
    assert RecordBatchStream is not None
    assert ResultSetStream is not None


def test_import_admin_types():
    from seahorse_coral import (
        ActiveSetFlushResult,
        FileImportResult,
        IndexedCountSummary,
        IndexedCounts,
        ImportFilesResult,
        IndexRowCount,
        InsertResult,
        NodeCheckpoint,
        NodeInfo,
        RebalanceCommitRequest,
        RebalanceCommitResult,
        RebalancePlanResult,
        RebalanceStatusResult,
        SegmentsRetryResult,
        SegmentsStatusResult,
        SegmentAssignment,
        TableAssignment,
        TableSchema,
        TableInfo,
    )

    assert TableInfo is not None
    assert TableSchema is not None
    assert InsertResult is not None
    assert FileImportResult is not None
    assert ImportFilesResult is not None
    assert ActiveSetFlushResult is not None
    assert NodeInfo is not None
    assert NodeCheckpoint is not None
    assert TableAssignment is not None
    assert SegmentAssignment is not None
    assert IndexedCounts is not None
    assert IndexedCountSummary is not None
    assert IndexRowCount is not None
    assert SegmentsStatusResult is not None
    assert SegmentsRetryResult is not None
    assert RebalancePlanResult is not None
    assert RebalanceCommitRequest is not None
    assert RebalanceCommitResult is not None
    assert RebalanceStatusResult is not None


def test_import_schema():
    from seahorse_coral import (
        Column,
        IndexDef,
        IndexDefinition,
        SchemaBuilder,
        Segmentation,
        TableConfigurations,
        TablePlacement,
    )

    assert Column is not None
    assert SchemaBuilder is not None
    assert Segmentation is not None
    assert IndexDefinition is not None
    assert IndexDef is IndexDefinition
    assert TableConfigurations is not None
    assert TablePlacement is not None


def test_import_storage_helpers():
    from seahorse_coral import (
        azure_file,
        gcs_file,
        local_directory,
        local_file,
        minio_file,
        s3_compatible_file,
        s3_directory,
        s3_file,
    )

    assert callable(local_file)
    assert callable(local_directory)
    assert callable(s3_file)
    assert callable(s3_directory)
    assert callable(gcs_file)
    assert callable(azure_file)
    assert callable(minio_file)
    assert callable(s3_compatible_file)


def test_import_exceptions():
    from seahorse_coral import (
        ConnectionError,
        ImportFilesError,
        PartialImportError,
        QueryError,
        SearchError,
        SeahorseError,
        TableError,
    )

    assert issubclass(SeahorseError, Exception)
    assert issubclass(ConnectionError, SeahorseError)
    assert issubclass(ImportFilesError, TableError)
    assert issubclass(PartialImportError, ImportFilesError)
    assert issubclass(QueryError, SeahorseError)
    assert issubclass(TableError, SeahorseError)
    assert issubclass(SearchError, SeahorseError)
