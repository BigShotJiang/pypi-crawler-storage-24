"""Tests for TestPyPI version rewriting."""

from __future__ import annotations

import sys
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import set_testpypi_version


def test_derive_testpypi_version_appends_dev_suffix() -> None:
    version = set_testpypi_version.derive_testpypi_version("2.2.1", "12345")

    assert version == "2.2.1.dev12345"


def test_derive_testpypi_version_replaces_existing_dev_suffix() -> None:
    version = set_testpypi_version.derive_testpypi_version("2.2.1.dev7", "12345")

    assert version == "2.2.1.dev12345"


def test_derive_testpypi_version_drops_local_segment() -> None:
    version = set_testpypi_version.derive_testpypi_version("2.2.1+local", "12345")

    assert version == "2.2.1.dev12345"


def test_build_unique_id_zero_pads_attempt() -> None:
    unique_id = set_testpypi_version.build_unique_id("42", "3")

    assert unique_id == "4203"


def test_sync_versions_updates_python_package_version_targets(tmp_path: Path) -> None:
    (tmp_path / "python/seahorse_coral").mkdir(parents=True)
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "seahorse-coral"\nversion = "2.2.1"\n',
        encoding="utf-8",
    )
    (tmp_path / "Cargo.toml").write_text(
        '[package]\nname = "seahorse-coral"\nversion = "2.2.1"\n'
        'pyo3 = { version = "0.20" }\n',
        encoding="utf-8",
    )
    (tmp_path / "python/seahorse_coral/__init__.py").write_text(
        '__version__ = "2.2.1"\n',
        encoding="utf-8",
    )

    set_testpypi_version.sync_versions(tmp_path, "2.2.1.dev12345")

    assert 'version = "2.2.1.dev12345"' in (tmp_path / "pyproject.toml").read_text(
        encoding="utf-8"
    )
    assert 'version = "2.2.1"' in (tmp_path / "Cargo.toml").read_text(encoding="utf-8")
    assert '__version__ = "2.2.1.dev12345"' in (
        tmp_path / "python/seahorse_coral/__init__.py"
    ).read_text(encoding="utf-8")


def test_read_base_version_uses_pyproject_version(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "seahorse-coral"\nversion = "2.2.1"\n',
        encoding="utf-8",
    )

    assert set_testpypi_version.read_base_version(tmp_path) == "2.2.1"


def test_write_github_metadata_writes_env_and_summary(tmp_path: Path) -> None:
    github_env = tmp_path / "github_env"
    github_step_summary = tmp_path / "github_step_summary"

    set_testpypi_version.write_github_metadata(
        version="2.2.1.dev4203",
        base_version="2.2.1",
        run_number="42",
        run_attempt="3",
        github_env_path=github_env,
        github_step_summary_path=github_step_summary,
    )

    assert github_env.read_text(encoding="utf-8") == "TESTPYPI_VERSION=2.2.1.dev4203\n"
    summary = github_step_summary.read_text(encoding="utf-8")
    assert "### TestPyPI Version" in summary
    assert "- Version: `2.2.1.dev4203`" in summary
    assert "- Base version: `2.2.1`" in summary
    assert "- Workflow run number: `42`" in summary
    assert "- Run attempt: `3`" in summary
