"""Unit tests for seahorse_coral.schema (CreateTableRequest helpers)."""

import pytest

from seahorse_coral.schema import (
    AssignedNodes,
    Column,
    IndexDef,
    IndexDefinition,
    IndexSpace,
    IndexType,
    ScalarType,
    SchemaBuilder,
    SegmentationComposition,
    SegmentationStrategy,
    TableConfigurations,
    TablePlacement,
    VectorElement,
    default_vector_table_schema,
    default_vector_table_schema_string_id,
    metadata_column,
    hash_segmentation,
    hnsw_index,
    int64_column,
    string_column,
    value_segmentation,
    vector_column,
)


def test_indexdef_is_alias_of_indexdefinition():
    assert IndexDef is IndexDefinition


def test_int64_column_to_dict():
    col = int64_column("id", nullable=False)
    assert col.to_dict() == {"name": "id", "nullable": False, "type": "INT64"}


def test_vector_column_to_dict():
    col = vector_column("embedding", dim=384)
    as_dict = col.to_dict()
    assert as_dict["name"] == "embedding"
    assert as_dict["type"] == {"name": "DENSE_VECTOR", "element": "FLOAT32", "dim": 384}


def test_string_column_to_dict_includes_max_length_when_set():
    col = string_column("title", nullable=True, max_length=256)
    assert col.to_dict() == {
        "name": "title",
        "nullable": True,
        "type": "STRING",
        "max_length": 256,
    }


def test_schema_builder_rejects_max_length_on_non_string_column():
    schema = SchemaBuilder(
        columns=[
            Column(
                name="id",
                type=ScalarType.INT64,
                nullable=False,
                max_length=10,
            )
        ],
        primary_key=["id"],
    )
    with pytest.raises(ValueError, match="max_length"):
        schema.validate()


def test_schema_builder_rejects_non_positive_max_length_for_string_column():
    schema = SchemaBuilder(columns=[string_column("title", max_length=0)])
    with pytest.raises(ValueError, match="must be > 0"):
        schema.validate()


def test_hnsw_index_to_dict():
    idx = hnsw_index("embedding", space=IndexSpace.COSINE, ef_construction=123, M=12)
    assert idx.to_dict() == {
        "type": "HNSW",
        "column": "embedding",
        "params": {"space": "cosine", "ef_construction": 123, "M": 12},
    }


@pytest.mark.parametrize(
    ("raw_space", "expected"),
    [
        ("l2", IndexSpace.L2),
        ("l2space", IndexSpace.L2),
        ("cosine", IndexSpace.COSINE),
        ("cosinespace", IndexSpace.COSINE),
        ("ip", IndexSpace.IP),
        ("ipspace", IndexSpace.IP),
        ("inner_product", IndexSpace.IP),
        ("dot", IndexSpace.IP),
    ],
)
def test_index_space_parse_accepts_client_and_server_aliases(raw_space, expected):
    assert IndexSpace.parse(raw_space) is expected


def test_schema_builder_from_dict_accepts_server_canonical_index_space():
    payload = {
        "table_name": "docs",
        "columns": [
            {"name": "id", "type": "INT64", "nullable": False},
            {
                "name": "embedding",
                "type": {"name": "DENSE_VECTOR", "element": "FLOAT32", "dim": 3},
                "nullable": False,
            },
        ],
        "primary_key": ["id"],
        "indexes": [
            {
                "type": "DISKBASED",
                "column": "embedding",
                "params": {"space": "ipspace", "ef_construction": 200, "M": 16},
            }
        ],
    }

    restored = SchemaBuilder.from_dict(payload)
    assert restored.indexes is not None
    assert restored.indexes[0].params is not None
    assert restored.indexes[0].params.space is IndexSpace.IP
    assert restored.to_dict(table_name="docs")["indexes"][0]["params"]["space"] == "ip"


def test_value_segmentation_defaults_by_column_count():
    seg_single = value_segmentation(["id"])
    assert seg_single.strategy == SegmentationStrategy.VALUE
    assert seg_single.composition == SegmentationComposition.SINGLE

    seg_multi = value_segmentation(["id", "category"])
    assert seg_multi.strategy == SegmentationStrategy.VALUE
    assert seg_multi.composition == SegmentationComposition.COMPOSITE


def test_hash_segmentation_requires_single_column():
    with pytest.raises(ValueError, match="single column"):
        hash_segmentation(["id", "category"])


def test_schema_builder_to_dict_minimal_and_named():
    schema = SchemaBuilder(columns=[int64_column("id", nullable=False)], primary_key=["id"])
    as_dict = schema.to_dict(table_name="docs")
    assert as_dict["table_name"] == "docs"
    assert as_dict["primary_key"] == ["id"]
    assert as_dict["columns"] == [{"name": "id", "nullable": False, "type": "INT64"}]


def test_schema_builder_fluent_happy_path():
    schema = (
        SchemaBuilder()
        .int64("id", nullable=False)
        .vector("vector", dim=3)
        .metadata()
        .with_primary_key("id")
        .hnsw("vector")
    )
    schema.validate()
    as_dict = schema.to_dict(table_name="docs")
    assert as_dict["table_name"] == "docs"
    assert as_dict["primary_key"] == ["id"]
    assert len(as_dict["columns"]) == 3
    assert as_dict["columns"][0]["name"] == "id"
    assert as_dict["columns"][1]["name"] == "vector"
    assert as_dict["columns"][2]["name"] == "metadata"


def test_default_vector_table_schema_has_id_vector_metadata():
    schema = default_vector_table_schema(384)
    as_dict = schema.to_dict(table_name="docs")
    assert [c["name"] for c in as_dict["columns"]] == ["id", "vector", "metadata"]
    assert as_dict["primary_key"] == ["id"]
    assert as_dict["indexes"][0]["column"] == "vector"


def test_default_vector_table_schema_string_id_uses_string_pk():
    schema = default_vector_table_schema_string_id(384)
    as_dict = schema.to_dict(table_name="docs")
    assert as_dict["columns"][0]["name"] == "id"
    assert as_dict["columns"][0]["type"] == "STRING"
    assert as_dict["primary_key"] == ["id"]


def test_schema_builder_full_shape_keys():
    schema = SchemaBuilder(
        columns=[
            int64_column("id", nullable=False),
            vector_column("embedding", dim=3, element=VectorElement.FLOAT32),
        ],
        primary_key=["id"],
        segmentation=value_segmentation(["id"]),
        indexes=[hnsw_index("embedding")],
        configurations=TableConfigurations(active_set_size_limit=100, max_threads=4),
        placement=TablePlacement(
            assigned_nodes=AssignedNodes(writer_nodes=["writer-1"], reader_nodes=["reader-1"])
        ),
    )
    as_dict = schema.to_dict(table_name="docs")

    assert set(as_dict.keys()) == {
        "table_name",
        "columns",
        "primary_key",
        "segmentation",
        "indexes",
        "configurations",
        "placement",
    }


def test_schema_builder_from_dict_roundtrip():
    original = SchemaBuilder(
        columns=[
            int64_column("id", nullable=False),
            string_column("title", max_length=256),
            vector_column("embedding", dim=3, element=VectorElement.FLOAT32),
        ],
        primary_key=["id"],
        segmentation=value_segmentation(["id"]),
        indexes=[hnsw_index("embedding", space=IndexSpace.COSINE, ef_construction=100, M=12)],
        configurations=TableConfigurations(active_set_size_limit=100, max_threads=2),
        placement=TablePlacement(
            assigned_nodes=AssignedNodes(writer_nodes=["writer-1"], reader_nodes=["reader-1"])
        ),
    )

    payload = original.to_dict(table_name="docs")
    restored = SchemaBuilder.from_dict(payload)

    assert restored.to_dict(table_name="docs") == payload
