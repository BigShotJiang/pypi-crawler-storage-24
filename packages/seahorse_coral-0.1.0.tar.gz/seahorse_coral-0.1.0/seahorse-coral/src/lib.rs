use std::collections::HashMap;
use std::sync::Arc;

use coral_client::CoralClient as RustCoralClient;
use coral_client::RecordBatchStream as ClientRecordBatchStream;
use coral_client::ResultSetStream as ClientResultSetStream;
use coral_client::TableView as ClientTableView;
use coral_models::api::data::{
    DataDeleteRequest, DataUpdateRequest, InsertQueryParams, ScanQueryParams,
};
use coral_models::api::schema;
use coral_models::api::storage::{
    BatchInsertQueryParams, CloudStorageCredentials, CloudStorageOptions, Paths, StorageConfig,
    StorageType,
};
use coral_models::api::vector::{
    DenseSearchParameters, DenseVectorSearchConfig, FusionConfig, FusionParameters,
    HybridVectorSearchRequest, QueryVectors, VectorSearchRequest,
};
use coral_models::api::{
    ActiveSetFlushRequest, RebalanceCommitRequest, RebalancePlanRequest, RebalanceStrategy,
    SegmentRetryMode, SegmentsRetryRequest, SparseMetadata, SparseSearchParameters,
    SparseVectorSearchConfig, SyncMode,
};
use coral_models::{DataScanRequest, FileFormat};
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyDict, PyList};
use pyo3_asyncio::tokio::future_into_py;
use serde::Serialize;
use serde_json::Value;
use tokio::sync::Mutex;

fn scalar_type_to_string(scalar_type: &schema::ScalarType) -> &'static str {
    match scalar_type {
        schema::ScalarType::Int64 => "INT64",
        schema::ScalarType::Float64 => "FLOAT64",
        schema::ScalarType::Bool => "BOOL",
        schema::ScalarType::String => "STRING",
    }
}

fn vector_element_to_string(element: &schema::VectorElement) -> &'static str {
    match element {
        schema::VectorElement::Float32 => "FLOAT32",
    }
}

fn segmentation_strategy_to_string(strategy: &schema::SegmentationStrategy) -> &'static str {
    match strategy {
        schema::SegmentationStrategy::Value => "value",
        schema::SegmentationStrategy::Hash => "hash",
    }
}

fn segmentation_composition_to_string(
    composition: &schema::SegmentationComposition,
) -> &'static str {
    match composition {
        schema::SegmentationComposition::Single => "single",
        schema::SegmentationComposition::Hierarchical => "hierarchical",
        schema::SegmentationComposition::Composite => "composite",
    }
}

fn node_type_to_string(node_type: &coral_models::catalog::NodeType) -> &'static str {
    match node_type {
        coral_models::catalog::NodeType::Reader => "READER",
        coral_models::catalog::NodeType::Writer => "WRITER",
    }
}

fn node_state_to_string(node_state: &coral_models::catalog::NodeState) -> &'static str {
    match node_state {
        coral_models::catalog::NodeState::InRecovery => "IN_RECOVERY",
        coral_models::catalog::NodeState::Active => "ACTIVE",
        coral_models::catalog::NodeState::Inactive => "INACTIVE",
    }
}

fn node_stage_to_string(node_stage: &coral_models::catalog::NodeStage) -> &'static str {
    match node_stage {
        coral_models::catalog::NodeStage::Init => "INIT",
        coral_models::catalog::NodeStage::Loading => "LOADING",
        coral_models::catalog::NodeStage::Subscribing => "SUBSCRIBING",
        coral_models::catalog::NodeStage::Running => "RUNNING",
    }
}

fn segment_assignment_status_to_string(
    status: &coral_models::catalog::SegmentAssignmentStatus,
) -> &'static str {
    match status {
        coral_models::catalog::SegmentAssignmentStatus::Syncing => "SYNCING",
        coral_models::catalog::SegmentAssignmentStatus::Synced => "SYNCED",
        coral_models::catalog::SegmentAssignmentStatus::Removing => "REMOVING",
        coral_models::catalog::SegmentAssignmentStatus::Failed => "FAILED",
        coral_models::catalog::SegmentAssignmentStatus::Unknown => "UNKNOWN",
    }
}

fn table_operation_segment_expectation_to_string(
    expectation: &coral_models::api::cluster::TableOperationSegmentExpectation,
) -> &'static str {
    match expectation {
        coral_models::api::cluster::TableOperationSegmentExpectation::Add => "ADD",
        coral_models::api::cluster::TableOperationSegmentExpectation::Remove => "REMOVE",
    }
}

fn table_operation_observed_segment_status_to_string(
    status: &coral_models::api::cluster::TableOperationObservedSegmentStatus,
) -> &'static str {
    match status {
        coral_models::api::cluster::TableOperationObservedSegmentStatus::Syncing => "SYNCING",
        coral_models::api::cluster::TableOperationObservedSegmentStatus::Synced => "SYNCED",
        coral_models::api::cluster::TableOperationObservedSegmentStatus::Removing => "REMOVING",
        coral_models::api::cluster::TableOperationObservedSegmentStatus::Failed => "FAILED",
        coral_models::api::cluster::TableOperationObservedSegmentStatus::Unknown => "UNKNOWN",
        coral_models::api::cluster::TableOperationObservedSegmentStatus::Deleted => "DELETED",
        coral_models::api::cluster::TableOperationObservedSegmentStatus::NotTracked => {
            "NOT_TRACKED"
        }
        coral_models::api::cluster::TableOperationObservedSegmentStatus::MissingNodeInfo => {
            "MISSING_NODE_INFO"
        }
        coral_models::api::cluster::TableOperationObservedSegmentStatus::MissingTableAssignment => {
            "MISSING_TABLE_ASSIGNMENT"
        }
        coral_models::api::cluster::TableOperationObservedSegmentStatus::MissingSegmentAssignment => {
            "MISSING_SEGMENT_ASSIGNMENT"
        }
    }
}

fn segments_status_mode_to_string(
    mode: &coral_models::api::cluster::SegmentsStatusMode,
) -> &'static str {
    match mode {
        coral_models::api::cluster::SegmentsStatusMode::Active => "active",
        coral_models::api::cluster::SegmentsStatusMode::Create => "create",
        coral_models::api::cluster::SegmentsStatusMode::Rebalance => "rebalance",
    }
}

fn parse_rebalance_strategy(strategy: Option<&str>) -> PyResult<Option<RebalanceStrategy>> {
    match strategy {
        None => Ok(None),
        Some("balanced_min_moves") => Ok(Some(RebalanceStrategy::BalancedMinMoves)),
        Some("strict_algorithmic") => Ok(Some(RebalanceStrategy::StrictAlgorithmic)),
        Some(other) => Err(pyo3::exceptions::PyValueError::new_err(format!(
            "Invalid strategy '{}': expected 'balanced_min_moves' | 'strict_algorithmic'",
            other
        ))),
    }
}

fn map_column_to_py(py: Python, column: &schema::Column) -> PyResult<PyObject> {
    let py_dict = PyDict::new(py);
    py_dict.set_item("name", &column.name)?;
    py_dict.set_item("nullable", column.nullable)?;

    match &column.r#type {
        schema::ColumnType::Scalar(scalar) => {
            py_dict.set_item("type", scalar_type_to_string(scalar))?;
        }
        schema::ColumnType::Vector(vector) => {
            let vector_dict = PyDict::new(py);
            match vector {
                schema::VectorType::DenseVector { element, dim } => {
                    vector_dict.set_item("name", "DENSE_VECTOR")?;
                    vector_dict.set_item("element", vector_element_to_string(element))?;
                    vector_dict.set_item("dim", dim)?;
                }
                schema::VectorType::SparseVector => {
                    vector_dict.set_item("name", "SPARSE_VECTOR")?;
                }
            }
            py_dict.set_item("type", vector_dict)?;
        }
    }

    if let Some(max_length) = column.max_length {
        py_dict.set_item("max_length", max_length)?;
    }

    Ok(py_dict.to_object(py))
}

fn map_external_segmentation_to_py(
    py: Python,
    segmentation: &schema::ExternalSegmentation,
) -> PyResult<PyObject> {
    let py_dict = PyDict::new(py);
    py_dict.set_item(
        "strategy",
        segmentation_strategy_to_string(&segmentation.strategy),
    )?;
    py_dict.set_item("columns", segmentation.columns.clone())?;
    if let Some(buckets) = segmentation.buckets {
        py_dict.set_item("buckets", buckets)?;
    }
    if let Some(composition) = &segmentation.composition {
        py_dict.set_item(
            "composition",
            segmentation_composition_to_string(composition),
        )?;
    }
    Ok(py_dict.to_object(py))
}

fn map_index_params_to_py(py: Python, params: &schema::IndexParams) -> PyResult<Option<PyObject>> {
    let py_dict = PyDict::new(py);

    if let Some(space) = &params.space {
        py_dict.set_item("space", space)?;
    }
    if let Some(ef_construction) = params.ef_construction {
        py_dict.set_item("ef_construction", ef_construction)?;
    }
    if let Some(m) = params.M {
        py_dict.set_item("M", m)?;
    }
    if let Some(sparse_model) = &params.sparse_model {
        py_dict.set_item("sparse_model", sparse_model)?;
    }

    if py_dict.len() == 0 {
        Ok(None)
    } else {
        Ok(Some(py_dict.to_object(py)))
    }
}

fn map_external_index_to_py(py: Python, index: &schema::ExternalIndex) -> PyResult<PyObject> {
    let py_dict = PyDict::new(py);
    py_dict.set_item("type", &index.r#type)?;
    py_dict.set_item("column", &index.column)?;
    if let Some(params) = &index.params {
        if let Some(params_dict) = map_index_params_to_py(py, params)? {
            py_dict.set_item("params", params_dict)?;
        }
    }
    Ok(py_dict.to_object(py))
}

fn map_table_configurations_to_py(
    py: Python,
    configurations: &schema::TableConfigurations,
) -> PyResult<Option<PyObject>> {
    let py_dict = PyDict::new(py);
    if let Some(active_set_size_limit) = configurations.active_set_size_limit {
        py_dict.set_item("active_set_size_limit", active_set_size_limit)?;
    }
    if let Some(max_threads) = configurations.max_threads {
        py_dict.set_item("max_threads", max_threads)?;
    }

    if py_dict.len() == 0 {
        Ok(None)
    } else {
        Ok(Some(py_dict.to_object(py)))
    }
}

fn table_schema_to_py(py: Python, table: &ClientTableView) -> PyResult<PyObject> {
    let Some(external) = &table.external else {
        return Ok(py.None());
    };

    let py_dict = PyDict::new(py);
    let columns = external
        .columns
        .iter()
        .map(|column| map_column_to_py(py, column))
        .collect::<PyResult<Vec<_>>>()?;
    py_dict.set_item("columns", columns)?;

    if !external.primary_key.is_empty() {
        py_dict.set_item("primary_key", external.primary_key.clone())?;
    }
    if let Some(segmentation) = &external.segmentation {
        py_dict.set_item(
            "segmentation",
            map_external_segmentation_to_py(py, segmentation)?,
        )?;
    }
    if !external.indexes.is_empty() {
        let indexes = external
            .indexes
            .iter()
            .map(|index| map_external_index_to_py(py, index))
            .collect::<PyResult<Vec<_>>>()?;
        py_dict.set_item("indexes", indexes)?;
    }
    if let Some(configurations) = &table.configurations {
        if let Some(config_dict) = map_table_configurations_to_py(py, configurations)? {
            py_dict.set_item("configurations", config_dict)?;
        }
    }

    Ok(py_dict.to_object(py))
}

fn py_to_json_value(value: &PyAny) -> PyResult<Value> {
    if value.is_none() {
        return Ok(Value::Null);
    }

    if let Ok(value) = value.extract::<bool>() {
        return Ok(Value::Bool(value));
    }

    if let Ok(value) = value.extract::<i64>() {
        return Ok(Value::Number(value.into()));
    }

    if let Ok(value) = value.extract::<u64>() {
        return Ok(Value::Number(value.into()));
    }

    if let Ok(value) = value.extract::<f64>() {
        let number = serde_json::Number::from_f64(value).ok_or_else(|| {
            pyo3::exceptions::PyValueError::new_err("non-finite float is not supported")
        })?;
        return Ok(Value::Number(number));
    }

    if let Ok(value) = value.extract::<String>() {
        return Ok(Value::String(value));
    }

    if let Ok(list) = value.downcast::<PyList>() {
        return Ok(Value::Array(
            list.iter()
                .map(py_to_json_value)
                .collect::<PyResult<Vec<_>>>()?,
        ));
    }

    if let Ok(dict) = value.downcast::<PyDict>() {
        let mut result = serde_json::Map::with_capacity(dict.len());
        for (key, value) in dict.iter() {
            let key = key.extract::<String>()?;
            result.insert(key, py_to_json_value(value)?);
        }
        return Ok(Value::Object(result));
    }

    Err(pyo3::exceptions::PyTypeError::new_err(
        "unsupported Python value for JSON-compatible conversion",
    ))
}

fn json_value_to_py(py: Python<'_>, value: &Value) -> PyResult<PyObject> {
    match value {
        Value::Null => Ok(py.None()),
        Value::Bool(v) => Ok(v.into_py(py)),
        Value::Number(v) => {
            if let Some(i) = v.as_i64() {
                Ok(i.into_py(py))
            } else if let Some(u) = v.as_u64() {
                Ok(u.into_py(py))
            } else if let Some(f) = v.as_f64() {
                Ok(f.into_py(py))
            } else {
                Err(pyo3::exceptions::PyValueError::new_err(
                    "unsupported JSON number value",
                ))
            }
        }
        Value::String(v) => Ok(v.into_py(py)),
        Value::Array(values) => {
            let items = values
                .iter()
                .map(|item| json_value_to_py(py, item))
                .collect::<PyResult<Vec<_>>>()?;
            Ok(PyList::new(py, items).into_py(py))
        }
        Value::Object(values) => {
            let dict = PyDict::new(py);
            for (key, item) in values {
                dict.set_item(key, json_value_to_py(py, item)?)?;
            }
            Ok(dict.to_object(py))
        }
    }
}

fn serialize_model_to_py<T>(py: Python<'_>, value: &T) -> PyResult<PyObject>
where
    T: Serialize,
{
    let json = serde_json::to_value(value).map_err(|error| {
        pyo3::exceptions::PyRuntimeError::new_err(format!("Serialize result failed: {}", error))
    })?;
    json_value_to_py(py, &json)
}

fn parse_sparse_metadata(
    py: Python,
    metadata: Option<PyObject>,
) -> PyResult<Option<SparseMetadata>> {
    let Some(metadata) = metadata else {
        return Ok(None);
    };

    let dict = metadata
        .as_ref(py)
        .downcast::<PyDict>()
        .map_err(|_| pyo3::exceptions::PyTypeError::new_err("sparse metadata must be a dict"))?;

    let n = if let Some(value) = dict.get_item("N")? {
        value.extract::<u64>()?
    } else if let Some(value) = dict.get_item("n")? {
        value.extract::<u64>()?
    } else {
        return Err(pyo3::exceptions::PyValueError::new_err(
            "sparse metadata missing 'N'",
        ));
    };

    let avgdl = dict
        .get_item("avgdl")?
        .ok_or_else(|| pyo3::exceptions::PyValueError::new_err("sparse metadata missing 'avgdl'"))?
        .extract::<f32>()?;
    let df = dict
        .get_item("df")?
        .ok_or_else(|| pyo3::exceptions::PyValueError::new_err("sparse metadata missing 'df'"))?
        .extract::<Vec<String>>()?;

    Ok(Some(SparseMetadata { n, avgdl, df }))
}

fn map_node_checkpoint_info_to_py(
    py: Python,
    checkpoint: &coral_models::catalog::NodeCheckpointInfo,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PyNodeCheckpointInfo {
            last_set_number: checkpoint.last_set_number,
            set_versions: checkpoint.set_versions.clone(),
            set_index_counts: checkpoint.set_index_counts.clone(),
        },
    )?
    .to_object(py))
}

fn map_segment_assignment_to_py(
    py: Python,
    assignment: &coral_models::catalog::SegmentAssignment,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PySegmentAssignment {
            segment_oid: assignment.segment_oid.clone(),
            status: segment_assignment_status_to_string(&assignment.status).to_string(),
            failure_reason: assignment.failure_reason.clone(),
            checkpoint: map_node_checkpoint_info_to_py(py, &assignment.checkpoint)?,
        },
    )?
    .to_object(py))
}

fn map_table_assignment_to_py(
    py: Python,
    assignment: &coral_models::catalog::TableAssignment,
) -> PyResult<PyObject> {
    let segments = PyDict::new(py);
    for (segment_id, segment_assignment) in &assignment.segments {
        segments.set_item(
            segment_id,
            map_segment_assignment_to_py(py, segment_assignment)?,
        )?;
    }

    Ok(Py::new(
        py,
        PyTableAssignment {
            table_oid: assignment.table_oid.clone(),
            segments: segments.to_object(py),
        },
    )?
    .to_object(py))
}

fn map_node_info_to_py(
    py: Python,
    node_info: &coral_models::catalog::NodeInfo,
) -> PyResult<PyObject> {
    let assigned_tables = PyDict::new(py);
    for (table_id, table_assignment) in &node_info.assigned_tables {
        assigned_tables.set_item(table_id, map_table_assignment_to_py(py, table_assignment)?)?;
    }

    Ok(Py::new(
        py,
        PyNodeInfo {
            version: node_info.version,
            format_version: node_info.format_version,
            r#type: node_type_to_string(&node_info.node_type).to_string(),
            state: node_state_to_string(&node_info.state).to_string(),
            node_stage: node_stage_to_string(&node_info.node_stage).to_string(),
            last_updated: node_info.last_updated.clone(),
            node_address: node_info.node_address.clone(),
            assigned_tables: assigned_tables.to_object(py),
        },
    )?
    .to_object(py))
}

fn map_node_record_to_py(py: Python, record: &coral_client::NodeRecord) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PyNodeRecord {
            node_id: record.node_id.clone(),
            node_info: map_node_info_to_py(py, &record.node_info)?,
        },
    )?
    .to_object(py))
}

fn map_table_operation_segment_failure_to_py(
    py: Python,
    failure: &coral_models::catalog::TableOperationSegmentFailure,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PyTableOperationSegmentFailure {
            segment_id: failure.segment_id.clone(),
            status: segment_assignment_status_to_string(&failure.status).to_string(),
            failure_reason: failure.failure_reason.clone(),
        },
    )?
    .to_object(py))
}

fn map_table_operation_node_failure_to_py(
    py: Python,
    failure: &coral_models::catalog::TableOperationNodeFailure,
) -> PyResult<PyObject> {
    let segments = failure
        .segments
        .iter()
        .map(|segment| map_table_operation_segment_failure_to_py(py, segment))
        .collect::<PyResult<Vec<_>>>()?;

    Ok(Py::new(
        py,
        PyTableOperationNodeFailure {
            node_id: failure.node_id.clone(),
            segments: segments.into_py(py),
        },
    )?
    .to_object(py))
}

fn map_table_operation_failure_to_py(
    py: Python,
    failure: &coral_models::catalog::TableOperationFailure,
) -> PyResult<PyObject> {
    let node_failures = failure
        .node_failures
        .iter()
        .map(|node_failure| map_table_operation_node_failure_to_py(py, node_failure))
        .collect::<PyResult<Vec<_>>>()?;

    Ok(Py::new(
        py,
        PyTableOperationFailure {
            summary: failure.summary.clone(),
            detected_at: failure.detected_at.clone(),
            node_failures: node_failures.into_py(py),
        },
    )?
    .to_object(py))
}

fn map_table_operation_segment_status_to_py(
    py: Python,
    status: &coral_models::api::cluster::TableOperationSegmentStatus,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PyTableOperationSegmentStatus {
            segment_id: status.segment_id.clone(),
            expected: table_operation_segment_expectation_to_string(&status.expected).to_string(),
            observed: table_operation_observed_segment_status_to_string(&status.observed)
                .to_string(),
            failure_reason: status.failure_reason.clone(),
        },
    )?
    .to_object(py))
}

fn map_table_operation_node_segment_status_to_py(
    py: Python,
    node_status: &coral_models::api::cluster::TableOperationNodeSegmentStatus,
) -> PyResult<PyObject> {
    let segments = node_status
        .segments
        .iter()
        .map(|segment_status| map_table_operation_segment_status_to_py(py, segment_status))
        .collect::<PyResult<Vec<_>>>()?;

    Ok(Py::new(
        py,
        PyTableOperationNodeSegmentStatus {
            node_id: node_status.node_id.clone(),
            segments: segments.into_py(py),
        },
    )?
    .to_object(py))
}

fn map_table_operation_polling_info_to_py(
    py: Python,
    polling: &coral_models::api::cluster::TableOperationPollingInfo,
) -> PyResult<PyObject> {
    let nodes = polling
        .nodes
        .iter()
        .map(|node_status| map_table_operation_node_segment_status_to_py(py, node_status))
        .collect::<PyResult<Vec<_>>>()?;

    Ok(Py::new(
        py,
        PyTableOperationPollingInfo {
            evaluated_at: polling.evaluated_at.clone(),
            nodes: nodes.into_py(py),
        },
    )?
    .to_object(py))
}

fn map_segments_status_summary_to_py(
    py: Python,
    summary: &coral_models::api::cluster::SegmentsStatusSummary,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PySegmentsStatusSummary {
            total: summary.total,
            synced: summary.synced,
            failed: summary.failed,
            pending: summary.pending,
        },
    )?
    .to_object(py))
}

fn map_segments_status_result_to_py(
    py: Python,
    result: &coral_models::api::cluster::SegmentsStatusResponse,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PySegmentsStatusResult {
            table_name: result.table_name.clone(),
            table_status: result.table_status.clone(),
            mode: segments_status_mode_to_string(&result.mode).to_string(),
            started_at: result.started_at.clone(),
            ttl_seconds: result.ttl_seconds,
            failure: result
                .failure
                .as_ref()
                .map(|failure| map_table_operation_failure_to_py(py, failure))
                .transpose()?,
            polling: result
                .polling
                .as_ref()
                .map(|polling| map_table_operation_polling_info_to_py(py, polling))
                .transpose()?,
            summary: result
                .summary
                .as_ref()
                .map(|summary| map_segments_status_summary_to_py(py, summary))
                .transpose()?,
        },
    )?
    .to_object(py))
}

fn map_segments_retry_skip_info_to_py(
    py: Python,
    skipped: &coral_models::api::cluster::SegmentsRetrySkipInfo,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PySegmentsRetrySkipInfo {
            reason: skipped.reason.clone(),
        },
    )?
    .to_object(py))
}

fn map_segments_retry_node_observations_to_py(
    py: Python,
    observations: &coral_models::api::cluster::SegmentsRetryNodeObservations,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PySegmentsRetryNodeObservations {
            missing_nodeinfo: observations.missing_nodeinfo,
            missing_table_assignment: observations.missing_table_assignment,
            missing_segment_count: observations.missing_segment_count,
            failed_segment_count: observations.failed_segment_count,
            synced_segment_count: observations.synced_segment_count,
            not_removed_segment_count: observations.not_removed_segment_count,
        },
    )?
    .to_object(py))
}

fn map_segments_retry_node_result_to_py(
    py: Python,
    result: &coral_models::api::cluster::SegmentsRetryNodeResult,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PySegmentsRetryNodeResult {
            node_id: result.node_id.clone(),
            published_segments: result.published_segments.clone(),
            skipped: result
                .skipped
                .as_ref()
                .map(|skipped| map_segments_retry_skip_info_to_py(py, skipped))
                .transpose()?,
            observations: map_segments_retry_node_observations_to_py(py, &result.observations)?,
        },
    )?
    .to_object(py))
}

fn map_segments_retry_summary_to_py(
    py: Python,
    summary: &coral_models::api::cluster::SegmentsRetrySummary,
) -> PyResult<PyObject> {
    Ok(Py::new(
        py,
        PySegmentsRetrySummary {
            mode: summary.mode.clone(),
            total_nodes: summary.total_nodes,
            published_segment_count: summary.published_segment_count,
            skipped_node_count: summary.skipped_node_count,
            truncated: summary.truncated,
        },
    )?
    .to_object(py))
}

fn map_segments_retry_result_to_py(
    py: Python,
    result: &coral_models::api::cluster::SegmentsRetryResponse,
) -> PyResult<PyObject> {
    let nodes = result
        .nodes
        .iter()
        .map(|node| map_segments_retry_node_result_to_py(py, node))
        .collect::<PyResult<Vec<_>>>()?;

    Ok(Py::new(
        py,
        PySegmentsRetryResult {
            table_name: result.table_name.clone(),
            table_status: result.table_status.clone(),
            summary: map_segments_retry_summary_to_py(py, &result.summary)?,
            nodes: nodes.into_py(py),
        },
    )?
    .to_object(py))
}

#[pyclass]
pub struct CoralClient {
    client: RustCoralClient,
}

#[pyclass]
#[derive(Clone)]
pub struct TableView {
    #[pyo3(get)]
    pub table_name: String,
    #[pyo3(get)]
    pub schema: Option<PyObject>,
}

#[pyclass]
#[derive(Clone)]
pub struct TableSchema {
    #[pyo3(get)]
    pub table_name: String,
    #[pyo3(get)]
    pub schema: PyObject,
}

#[pyclass(name = "NodeCheckpointInfo")]
#[derive(Clone)]
pub struct PyNodeCheckpointInfo {
    #[pyo3(get)]
    pub last_set_number: Option<i64>,
    #[pyo3(get)]
    pub set_versions: Vec<String>,
    #[pyo3(get)]
    pub set_index_counts: HashMap<String, Vec<String>>,
}

#[pyclass(name = "SegmentAssignment")]
#[derive(Clone)]
pub struct PySegmentAssignment {
    #[pyo3(get)]
    pub segment_oid: String,
    #[pyo3(get)]
    pub status: String,
    #[pyo3(get)]
    pub failure_reason: String,
    #[pyo3(get)]
    pub checkpoint: PyObject,
}

#[pyclass(name = "TableAssignment")]
#[derive(Clone)]
pub struct PyTableAssignment {
    #[pyo3(get)]
    pub table_oid: String,
    #[pyo3(get)]
    pub segments: PyObject,
}

#[pyclass(name = "NodeInfo")]
#[derive(Clone)]
pub struct PyNodeInfo {
    #[pyo3(get)]
    pub version: i32,
    #[pyo3(get)]
    pub format_version: i32,
    #[pyo3(get)]
    pub r#type: String,
    #[pyo3(get)]
    pub state: String,
    #[pyo3(get)]
    pub node_stage: String,
    #[pyo3(get)]
    pub last_updated: String,
    #[pyo3(get)]
    pub node_address: String,
    #[pyo3(get)]
    pub assigned_tables: PyObject,
}

#[pyclass(name = "NodeRecord")]
#[derive(Clone)]
pub struct PyNodeRecord {
    #[pyo3(get)]
    pub node_id: String,
    #[pyo3(get)]
    pub node_info: PyObject,
}

#[pyclass(name = "TableOperationSegmentFailure")]
#[derive(Clone)]
pub struct PyTableOperationSegmentFailure {
    #[pyo3(get)]
    pub segment_id: String,
    #[pyo3(get)]
    pub status: String,
    #[pyo3(get)]
    pub failure_reason: String,
}

#[pyclass(name = "TableOperationNodeFailure")]
#[derive(Clone)]
pub struct PyTableOperationNodeFailure {
    #[pyo3(get)]
    pub node_id: String,
    #[pyo3(get)]
    pub segments: PyObject,
}

#[pyclass(name = "TableOperationFailure")]
#[derive(Clone)]
pub struct PyTableOperationFailure {
    #[pyo3(get)]
    pub summary: String,
    #[pyo3(get)]
    pub detected_at: String,
    #[pyo3(get)]
    pub node_failures: PyObject,
}

#[pyclass(name = "TableOperationSegmentStatus")]
#[derive(Clone)]
pub struct PyTableOperationSegmentStatus {
    #[pyo3(get)]
    pub segment_id: String,
    #[pyo3(get)]
    pub expected: String,
    #[pyo3(get)]
    pub observed: String,
    #[pyo3(get)]
    pub failure_reason: Option<String>,
}

#[pyclass(name = "TableOperationNodeSegmentStatus")]
#[derive(Clone)]
pub struct PyTableOperationNodeSegmentStatus {
    #[pyo3(get)]
    pub node_id: String,
    #[pyo3(get)]
    pub segments: PyObject,
}

#[pyclass(name = "TableOperationPollingInfo")]
#[derive(Clone)]
pub struct PyTableOperationPollingInfo {
    #[pyo3(get)]
    pub evaluated_at: String,
    #[pyo3(get)]
    pub nodes: PyObject,
}

#[pyclass(name = "SegmentsStatusSummary")]
#[derive(Clone)]
pub struct PySegmentsStatusSummary {
    #[pyo3(get)]
    pub total: u32,
    #[pyo3(get)]
    pub synced: u32,
    #[pyo3(get)]
    pub failed: u32,
    #[pyo3(get)]
    pub pending: u32,
}

#[pyclass(name = "SegmentsStatusResult")]
#[derive(Clone)]
pub struct PySegmentsStatusResult {
    #[pyo3(get)]
    pub table_name: String,
    #[pyo3(get)]
    pub table_status: String,
    #[pyo3(get)]
    pub mode: String,
    #[pyo3(get)]
    pub started_at: Option<String>,
    #[pyo3(get)]
    pub ttl_seconds: Option<u64>,
    #[pyo3(get)]
    pub failure: Option<PyObject>,
    #[pyo3(get)]
    pub polling: Option<PyObject>,
    #[pyo3(get)]
    pub summary: Option<PyObject>,
}

#[pyclass(name = "SegmentsRetrySkipInfo")]
#[derive(Clone)]
pub struct PySegmentsRetrySkipInfo {
    #[pyo3(get)]
    pub reason: String,
}

#[pyclass(name = "SegmentsRetryNodeObservations")]
#[derive(Clone)]
pub struct PySegmentsRetryNodeObservations {
    #[pyo3(get)]
    pub missing_nodeinfo: bool,
    #[pyo3(get)]
    pub missing_table_assignment: bool,
    #[pyo3(get)]
    pub missing_segment_count: u32,
    #[pyo3(get)]
    pub failed_segment_count: u32,
    #[pyo3(get)]
    pub synced_segment_count: u32,
    #[pyo3(get)]
    pub not_removed_segment_count: u32,
}

#[pyclass(name = "SegmentsRetryNodeResult")]
#[derive(Clone)]
pub struct PySegmentsRetryNodeResult {
    #[pyo3(get)]
    pub node_id: String,
    #[pyo3(get)]
    pub published_segments: Vec<String>,
    #[pyo3(get)]
    pub skipped: Option<PyObject>,
    #[pyo3(get)]
    pub observations: PyObject,
}

#[pyclass(name = "SegmentsRetrySummary")]
#[derive(Clone)]
pub struct PySegmentsRetrySummary {
    #[pyo3(get)]
    pub mode: String,
    #[pyo3(get)]
    pub total_nodes: u32,
    #[pyo3(get)]
    pub published_segment_count: u32,
    #[pyo3(get)]
    pub skipped_node_count: u32,
    #[pyo3(get)]
    pub truncated: bool,
}

#[pyclass(name = "SegmentsRetryResult")]
#[derive(Clone)]
pub struct PySegmentsRetryResult {
    #[pyo3(get)]
    pub table_name: String,
    #[pyo3(get)]
    pub table_status: String,
    #[pyo3(get)]
    pub summary: PyObject,
    #[pyo3(get)]
    pub nodes: PyObject,
}

#[pyclass]
#[derive(Clone)]
pub struct InsertResult {
    #[pyo3(get)]
    pub inserted_record_batches: usize,
    #[pyo3(get)]
    pub inserted_row_count: usize,
    #[pyo3(get)]
    pub total_inserted_record_batches: usize,
    #[pyo3(get)]
    pub total_inserted_row_count: usize,
}

#[pyclass(name = "FileImportResult")]
#[derive(Clone)]
pub struct PyFileImportResult {
    #[pyo3(get)]
    pub path: String,
    #[pyo3(get)]
    pub success: bool,
    #[pyo3(get)]
    pub inserted_record_batches: usize,
    #[pyo3(get)]
    pub inserted_row_count: usize,
    #[pyo3(get)]
    pub error: Option<String>,
}

#[pyclass(name = "ImportFilesResult")]
#[derive(Clone)]
pub struct PyImportFilesResult {
    #[pyo3(get)]
    pub results: PyObject,
    #[pyo3(get)]
    pub total_inserted_record_batches: usize,
    #[pyo3(get)]
    pub total_inserted_row_count: usize,
    #[pyo3(get)]
    pub elapsed_time: Option<f64>,
    #[pyo3(get)]
    pub rss_peak_bytes: Option<u64>,
}

#[pyclass]
#[derive(Clone)]
pub struct ActiveSetFlushResult {
    #[pyo3(get)]
    pub flushed: Vec<String>,
    #[pyo3(get)]
    pub failed: Vec<String>,
    #[pyo3(get)]
    pub skipped: Vec<String>,
}

#[pyclass(name = "ResultSetPayload")]
#[derive(Clone)]
pub struct ResultSetPayload {
    arrow_ipc: Py<PyBytes>,
    num_resultsets: u32,
    elapsed_time: Option<f64>,
    rss_peak_bytes: Option<u64>,
}

#[pymethods]
impl ResultSetPayload {
    #[getter]
    fn arrow_ipc(&self, py: Python<'_>) -> Py<PyBytes> {
        self.arrow_ipc.clone_ref(py)
    }

    #[getter]
    fn num_resultsets(&self) -> u32 {
        self.num_resultsets
    }

    #[getter]
    fn elapsed_time(&self) -> Option<f64> {
        self.elapsed_time
    }

    #[getter]
    fn rss_peak_bytes(&self) -> Option<u64> {
        self.rss_peak_bytes
    }
}

#[pyclass(name = "ResultSetsPayload")]
#[derive(Clone)]
pub struct ResultSetsPayload {
    arrow_ipc: Py<PyBytes>,
    resultset_batch_counts: Vec<u32>,
    elapsed_time: Option<f64>,
    rss_peak_bytes: Option<u64>,
}

#[pymethods]
impl ResultSetsPayload {
    #[getter]
    fn arrow_ipc(&self, py: Python<'_>) -> Py<PyBytes> {
        self.arrow_ipc.clone_ref(py)
    }

    #[getter]
    fn resultset_batch_counts(&self) -> Vec<u32> {
        self.resultset_batch_counts.clone()
    }

    #[getter]
    fn elapsed_time(&self) -> Option<f64> {
        self.elapsed_time
    }

    #[getter]
    fn rss_peak_bytes(&self) -> Option<u64> {
        self.rss_peak_bytes
    }
}

fn build_result_set_payload<T>(
    arrow_ipc: T,
    num_resultsets: u32,
    elapsed_time: Option<f64>,
    rss_peak_bytes: Option<u64>,
) -> PyResult<ResultSetPayload>
where
    T: AsRef<[u8]>,
{
    Python::with_gil(|py| {
        Ok(ResultSetPayload {
            arrow_ipc: PyBytes::new(py, arrow_ipc.as_ref()).into_py(py),
            num_resultsets,
            elapsed_time,
            rss_peak_bytes,
        })
    })
}

fn build_result_sets_payload<T>(
    arrow_ipc: T,
    resultset_batch_counts: Vec<u32>,
    elapsed_time: Option<f64>,
    rss_peak_bytes: Option<u64>,
) -> PyResult<ResultSetsPayload>
where
    T: AsRef<[u8]>,
{
    Python::with_gil(|py| {
        Ok(ResultSetsPayload {
            arrow_ipc: PyBytes::new(py, arrow_ipc.as_ref()).into_py(py),
            resultset_batch_counts,
            elapsed_time,
            rss_peak_bytes,
        })
    })
}

fn metrics_to_elapsed_time(
    metrics: Option<&coral_models::api::common::RequestMetrics>,
) -> Option<f64> {
    metrics.map(|metrics| f64::from(metrics.elapsed_time))
}

fn metrics_to_rss_peak_bytes(
    metrics: Option<&coral_models::api::common::RequestMetrics>,
) -> Option<u64> {
    metrics.and_then(|metrics| metrics.rss_peak_bytes)
}

fn build_import_files_result(
    result: coral_models::api::data::BatchDataInsertResult,
) -> PyResult<PyImportFilesResult> {
    let elapsed_time = metrics_to_elapsed_time(result.metrics.as_ref());
    let rss_peak_bytes = metrics_to_rss_peak_bytes(result.metrics.as_ref());

    Python::with_gil(|py| {
        let results = result
            .results
            .into_iter()
            .map(|file_result| {
                let inserted_record_batches = file_result
                    .result
                    .as_ref()
                    .map(|result| result.inserted_record_batches)
                    .unwrap_or(0);
                let inserted_row_count = file_result
                    .result
                    .as_ref()
                    .map(|result| result.inserted_row_count)
                    .unwrap_or(0);

                Py::new(
                    py,
                    PyFileImportResult {
                        path: file_result.path,
                        success: file_result.success,
                        inserted_record_batches,
                        inserted_row_count,
                        error: file_result.error,
                    },
                )
            })
            .collect::<PyResult<Vec<_>>>()?;

        Ok(PyImportFilesResult {
            results: results.into_py(py),
            total_inserted_record_batches: result.total_inserted_record_batches,
            total_inserted_row_count: result.total_inserted_row_count,
            elapsed_time,
            rss_peak_bytes,
        })
    })
}

struct RecordBatchStreamBindingState {
    stream: Option<ClientRecordBatchStream>,
    elapsed_time: Option<f64>,
    rss_peak_bytes: Option<u64>,
}

#[pyclass(name = "RecordBatchStreamBinding")]
pub struct RecordBatchStreamBinding {
    state: Arc<Mutex<RecordBatchStreamBindingState>>,
}

#[pymethods]
impl RecordBatchStreamBinding {
    #[getter]
    fn elapsed_time(&self) -> Option<f64> {
        self.state.blocking_lock().elapsed_time
    }

    #[getter]
    fn rss_peak_bytes(&self) -> Option<u64> {
        self.state.blocking_lock().rss_peak_bytes
    }

    pub fn next_batch<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let state = self.state.clone();
        future_into_py(py, async move {
            let mut guard = state.lock().await;
            let Some(stream) = guard.stream.as_mut() else {
                return Ok(None::<Py<PyBytes>>);
            };

            match stream
                .next_record_batch_arrow_ipc()
                .await
                .map_err(|error| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Read record batch stream failed: {}",
                        error
                    ))
                })? {
                Some(batch_ipc) => Python::with_gil(|py| {
                    Ok(Some(PyBytes::new(py, batch_ipc.as_ref()).into_py(py)))
                }),
                None => {
                    let stream = guard.stream.take().expect("stream exists");
                    drop(guard);
                    let metrics = stream.finish().await.map_err(|error| {
                        pyo3::exceptions::PyRuntimeError::new_err(format!(
                            "Finish record batch stream failed: {}",
                            error
                        ))
                    })?;
                    let mut guard = state.lock().await;
                    guard.elapsed_time = metrics_to_elapsed_time(metrics.as_ref());
                    guard.rss_peak_bytes = metrics_to_rss_peak_bytes(metrics.as_ref());
                    Ok(None)
                }
            }
        })
    }

    pub fn close<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let state = self.state.clone();
        future_into_py(py, async move {
            let mut guard = state.lock().await;
            let Some(stream) = guard.stream.take() else {
                return Ok(());
            };
            drop(guard);
            let metrics = stream.finish().await.map_err(|error| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Close record batch stream failed: {}",
                    error
                ))
            })?;
            let mut guard = state.lock().await;
            guard.elapsed_time = metrics_to_elapsed_time(metrics.as_ref());
            guard.rss_peak_bytes = metrics_to_rss_peak_bytes(metrics.as_ref());
            Ok(())
        })
    }
}

struct ResultSetStreamBindingState {
    stream: Option<ClientResultSetStream>,
    elapsed_time: Option<f64>,
    rss_peak_bytes: Option<u64>,
}

#[pyclass(name = "ResultSetStreamBinding")]
pub struct ResultSetStreamBinding {
    state: Arc<Mutex<ResultSetStreamBindingState>>,
}

#[pymethods]
impl ResultSetStreamBinding {
    #[getter]
    fn elapsed_time(&self) -> Option<f64> {
        self.state.blocking_lock().elapsed_time
    }

    #[getter]
    fn rss_peak_bytes(&self) -> Option<u64> {
        self.state.blocking_lock().rss_peak_bytes
    }

    pub fn next_resultset<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let state = self.state.clone();
        future_into_py(py, async move {
            let mut guard = state.lock().await;
            let Some(stream) = guard.stream.as_mut() else {
                return Ok(None::<Py<PyBytes>>);
            };

            match stream.next_resultset_arrow_ipc().await.map_err(|error| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Read resultset stream failed: {}",
                    error
                ))
            })? {
                Some(resultset_ipc) => Python::with_gil(|py| {
                    Ok(Some(PyBytes::new(py, resultset_ipc.as_ref()).into_py(py)))
                }),
                None => {
                    let stream = guard.stream.take().expect("stream exists");
                    drop(guard);
                    let metrics = stream.finish().await.map_err(|error| {
                        pyo3::exceptions::PyRuntimeError::new_err(format!(
                            "Finish resultset stream failed: {}",
                            error
                        ))
                    })?;
                    let mut guard = state.lock().await;
                    guard.elapsed_time = metrics_to_elapsed_time(metrics.as_ref());
                    guard.rss_peak_bytes = metrics_to_rss_peak_bytes(metrics.as_ref());
                    Ok(None)
                }
            }
        })
    }

    pub fn close<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let state = self.state.clone();
        future_into_py(py, async move {
            let mut guard = state.lock().await;
            let Some(stream) = guard.stream.take() else {
                return Ok(());
            };
            drop(guard);
            let metrics = stream.finish().await.map_err(|error| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Close resultset stream failed: {}",
                    error
                ))
            })?;
            let mut guard = state.lock().await;
            guard.elapsed_time = metrics_to_elapsed_time(metrics.as_ref());
            guard.rss_peak_bytes = metrics_to_rss_peak_bytes(metrics.as_ref());
            Ok(())
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn result_set_payload_reuses_python_bytes_object_on_getter() {
        Python::with_gil(|py| {
            let result = build_result_set_payload([1, 2, 3], 1, Some(0.25), Some(128))
                .expect("result-set payload");

            let first = result.arrow_ipc(py);
            let second = result.arrow_ipc(py);

            assert_eq!(first.as_ref(py).as_ptr(), second.as_ref(py).as_ptr());
        });
    }

    #[test]
    fn build_import_files_result_preserves_per_file_outcomes() {
        let result = build_import_files_result(coral_models::api::data::BatchDataInsertResult {
            results: vec![
                coral_models::api::data::FileInsertResult {
                    path: "ok.parquet".to_string(),
                    success: true,
                    result: Some(coral_models::api::data::DataInsertResult {
                        inserted_record_batches: 2,
                        inserted_row_count: 10,
                        elapsed_time: Some(0.25),
                    }),
                    error: None,
                },
                coral_models::api::data::FileInsertResult {
                    path: "bad.parquet".to_string(),
                    success: false,
                    result: None,
                    error: Some("decode failed".to_string()),
                },
            ],
            metrics: Some(coral_models::api::common::RequestMetrics {
                elapsed_time: 1.5,
                rss_peak_bytes: Some(2048),
            }),
            total_inserted_row_count: 10,
            total_inserted_record_batches: 2,
        })
        .expect("import files result");

        assert_eq!(result.total_inserted_record_batches, 2);
        assert_eq!(result.total_inserted_row_count, 10);
        assert_eq!(result.elapsed_time, Some(1.5));
        assert_eq!(result.rss_peak_bytes, Some(2048));

        Python::with_gil(|py| {
            let results = result
                .results
                .as_ref(py)
                .downcast::<PyList>()
                .expect("result list");
            assert_eq!(results.len(), 2);

            let first = results.get_item(0).expect("first item");
            assert_eq!(
                first
                    .getattr("path")
                    .expect("path attr")
                    .extract::<String>()
                    .expect("path value"),
                "ok.parquet"
            );
            assert!(
                first
                    .getattr("success")
                    .expect("success attr")
                    .extract::<bool>()
                    .expect("success value")
            );

            let second = results.get_item(1).expect("second item");
            assert_eq!(
                second
                    .getattr("error")
                    .expect("error attr")
                    .extract::<Option<String>>()
                    .expect("error value"),
                Some("decode failed".to_string())
            );
        });
    }

    #[test]
    fn parse_rebalance_strategy_supports_known_values() {
        assert_eq!(
            parse_rebalance_strategy(Some("balanced_min_moves")).unwrap(),
            Some(RebalanceStrategy::BalancedMinMoves)
        );
        assert_eq!(
            parse_rebalance_strategy(Some("strict_algorithmic")).unwrap(),
            Some(RebalanceStrategy::StrictAlgorithmic)
        );
        assert!(parse_rebalance_strategy(Some("unknown")).is_err());
    }

    #[test]
    fn build_indexed_count_summary_maps_primary_counts() {
        let summary = build_indexed_count_summary(&coral_models::api::TableIndexedCount {
            total_row_count: 10,
            indexed_counts: vec![coral_models::api::IndexedCount {
                index_name: "vector".to_string(),
                index_type: "hnsw".to_string(),
                indexed_row_count: 9,
            }],
        });

        assert_eq!(summary.total_row_count, 10);
        assert_eq!(summary.indexed_counts.len(), 1);
        assert_eq!(summary.indexed_counts[0].index_name, "vector");
        assert_eq!(summary.indexed_counts[0].indexed_row_count, 9);
    }
}

#[pyclass]
#[derive(Clone)]
pub struct IndexedCountSummary {
    #[pyo3(get)]
    pub total_row_count: i32,
    #[pyo3(get)]
    pub indexed_counts: Vec<IndexedCount>,
}

fn build_indexed_count_summary(value: &coral_models::api::TableIndexedCount) -> IndexedCountSummary {
    IndexedCountSummary {
        total_row_count: value.total_row_count,
        indexed_counts: value
            .indexed_counts
            .iter()
            .map(|ic| IndexedCount {
                index_name: ic.index_name.clone(),
                index_type: ic.index_type.clone(),
                indexed_row_count: ic.indexed_row_count,
            })
            .collect(),
    }
}

#[pyclass]
#[derive(Clone)]
pub struct IndexedCountInfo {
    #[pyo3(get)]
    pub total_row_count: i32,
    #[pyo3(get)]
    pub indexed_counts: Vec<IndexedCount>,
    #[pyo3(get)]
    pub readable: Option<IndexedCountSummary>,
}

#[pyclass]
#[derive(Clone)]
pub struct IndexedCount {
    #[pyo3(get)]
    pub index_name: String,
    #[pyo3(get)]
    pub index_type: String,
    #[pyo3(get)]
    pub indexed_row_count: i32,
}

#[pymethods]
impl CoralClient {
    #[new]
    pub fn new(base_url: String) -> Self {
        Self {
            client: RustCoralClient::new(base_url),
        }
    }

    pub fn health_check<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client.health_check().await.map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Health check failed: {}", e))
            })?;
            Ok(result)
        })
    }

    pub fn get_nodes<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client.get_nodes().await.map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Get nodes failed: {}", e))
            })?;
            Python::with_gil(|py| {
                let py_list = result
                    .iter()
                    .map(|item| map_node_record_to_py(py, item))
                    .collect::<PyResult<Vec<_>>>()?;
                Ok(py_list.into_py(py))
            })
        })
    }

    pub fn create_table<'py>(
        &self,
        py: Python<'py>,
        name: String,
        schema: PyObject,
    ) -> PyResult<&'py PyAny> {
        let mut request: schema::CreateTableRequest =
            serde_json::from_value(py_to_json_value(schema.as_ref(py))?).map_err(|e| {
                pyo3::exceptions::PyValueError::new_err(format!("Invalid schema: {}", e))
            })?;
        request.table_name = name.clone();

        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client.create_table(&request).await.map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Create table failed: {}", e))
            })?;

            Ok(TableView {
                table_name: result.table_name,
                schema: None,
            })
        })
    }

    pub fn list_tables<'py>(
        &self,
        py: Python<'py>,
        name_only: Option<bool>,
        internal: Option<bool>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .get_tables_with_internal(internal.unwrap_or(false))
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!("List tables failed: {}", e))
                })?;

            if name_only.unwrap_or(false) {
                let names: Vec<String> = result.iter().map(|t| t.table_name.clone()).collect();
                Python::with_gil(|py| Ok(names.into_py(py)))
            } else {
                let tables: Vec<TableView> = result
                    .iter()
                    .map(|t| TableView {
                        table_name: t.table_name.clone(),
                        schema: Some(Python::with_gil(|py| {
                            table_schema_to_py(py, t).unwrap_or_else(|_| py.None())
                        })),
                    })
                    .collect();
                Python::with_gil(|py| Ok(tables.into_py(py)))
            }
        })
    }

    pub fn get_table_schema<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        internal: Option<bool>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .get_table_schema_with_internal(&table_name, internal.unwrap_or(false))
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Get table schema failed: {}",
                        e
                    ))
                })?;
            let schema = Python::with_gil(|py| {
                table_schema_to_py(py, &result).unwrap_or_else(|_| py.None())
            });

            Ok(TableSchema {
                table_name: result.table_name,
                schema,
            })
        })
    }

    pub fn delete_table<'py>(&self, py: Python<'py>, table_name: String) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client.delete_table(&table_name).await.map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Delete table failed: {}", e))
            })?;

            Ok(result.table_name == table_name)
        })
    }

    /// Update rows in a table using SQL WHERE / SET fragments.
    #[pyo3(signature = (table_name, update_values, update_condition=None))]
    pub fn update_table_data<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        update_values: String,
        update_condition: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            client
                .update_table_data(
                    &table_name,
                    &DataUpdateRequest {
                        update_condition,
                        update_values,
                    },
                )
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Update table data failed: {}",
                        e
                    ))
                })?;
            Ok(())
        })
    }

    /// Delete rows in a table using an optional SQL WHERE fragment.
    #[pyo3(signature = (table_name, delete_condition=None))]
    pub fn delete_table_data<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        delete_condition: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            client
                .delete_table_data(
                    &table_name,
                    &DataDeleteRequest { delete_condition },
                )
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Delete table data failed: {}",
                        e
                    ))
                })?;
            Ok(())
        })
    }

    /// Flush active set data for a table.
    ///
    /// Args:
    ///     table_name: Name of the table
    ///     segment_ids: Optional list of segment ids to flush (default: all)
    ///     sync_mode: "async" (default) | "writer-sync" | "reader-sync"
    #[pyo3(signature = (table_name, segment_ids=None, sync_mode=None))]
    pub fn active_set_flush<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        segment_ids: Option<Vec<String>>,
        sync_mode: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let mode_str = sync_mode.as_deref().unwrap_or("async");
            let mode = match mode_str {
                "async" => SyncMode::Async,
                "writer-sync" => SyncMode::WriterSync,
                "reader-sync" => SyncMode::ReaderSync,
                other => {
                    return Err(pyo3::exceptions::PyValueError::new_err(format!(
                        "Invalid sync_mode '{}': expected 'async' | 'writer-sync' | 'reader-sync'",
                        other
                    )))
                }
            };

            let request = ActiveSetFlushRequest {
                segment_ids,
                sync_mode: mode,
            };

            let result = client
                .active_set_flush(&table_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Active set flush failed: {}",
                        e
                    ))
                })?;

            Ok(ActiveSetFlushResult {
                flushed: result.flushed,
                failed: result.failed,
                skipped: result.skipped,
            })
        })
    }

    /// Get unified segments status for a table.
    #[pyo3(signature = (table_name))]
    pub fn segments_status<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client.get_segments_status(&table_name).await.map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Get segments status failed: {}",
                    e
                ))
            })?;

            Python::with_gil(|py| map_segments_status_result_to_py(py, &result))
        })
    }

    /// Publish SEGMENT-only retry triggers for a table.
    ///
    /// Args:
    ///     table_name: Name of the table
    ///     mode: "auto" (default) | "create" | "rebalance"
    ///     only_failed: Retry only FAILED/missing segments (default: true)
    ///     skip_unsubscribed: Skip nodes with no pubsub subscribers (default: true)
    ///     dry_run: Plan-only (do not publish) (default: false)
    ///     max_targets: Optional cap on number of segments to publish (default: None)
    #[pyo3(signature = (table_name, mode=None, only_failed=None, skip_unsubscribed=None, dry_run=None, max_targets=None))]
    pub fn segments_retry<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        mode: Option<String>,
        only_failed: Option<bool>,
        skip_unsubscribed: Option<bool>,
        dry_run: Option<bool>,
        max_targets: Option<u32>,
    ) -> PyResult<&'py PyAny> {
        let mode_str = mode.as_deref().unwrap_or("auto");
        let mode = match mode_str {
            "auto" => SegmentRetryMode::Auto,
            "create" => SegmentRetryMode::Create,
            "rebalance" => SegmentRetryMode::Rebalance,
            other => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "Invalid mode '{}': expected 'auto' | 'create' | 'rebalance'",
                    other
                )))
            }
        };

        let request = SegmentsRetryRequest {
            mode,
            only_failed: only_failed.unwrap_or(true),
            skip_unsubscribed: skip_unsubscribed.unwrap_or(true),
            dry_run: dry_run.unwrap_or(false),
            max_targets,
        };

        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .segments_retry(&table_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Segments retry failed: {}",
                        e
                    ))
                })?;

            Python::with_gil(|py| map_segments_retry_result_to_py(py, &result))
        })
    }

    /// Compute a rebalance plan for a table.
    #[pyo3(signature = (table_name, reader_nodes=None, writer_nodes=None, strategy=None))]
    pub fn rebalance_plan<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        reader_nodes: Option<Vec<String>>,
        writer_nodes: Option<Vec<String>>,
        strategy: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let strategy = parse_rebalance_strategy(strategy.as_deref())?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let request = RebalancePlanRequest {
                reader_nodes: reader_nodes.filter(|nodes| !nodes.is_empty()),
                writer_nodes: writer_nodes.filter(|nodes| !nodes.is_empty()),
                strategy,
            };

            let result = client.rebalance_plan(&table_name, &request).await.map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Rebalance plan failed: {}",
                    e
                ))
            })?;

            Python::with_gil(|py| serialize_model_to_py(py, &result))
        })
    }

    /// Commit a previously planned rebalance request.
    pub fn rebalance_commit<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        request: PyObject,
    ) -> PyResult<&'py PyAny> {
        let request: RebalanceCommitRequest =
            serde_json::from_value(py_to_json_value(request.as_ref(py))?).map_err(|e| {
                pyo3::exceptions::PyValueError::new_err(format!(
                    "Invalid rebalance commit request: {}",
                    e
                ))
            })?;

        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .rebalance_commit(&table_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Rebalance commit failed: {}",
                        e
                    ))
                })?;

            Python::with_gil(|py| serialize_model_to_py(py, &result))
        })
    }

    /// Get rebalance status for a table.
    #[pyo3(signature = (table_name))]
    pub fn rebalance_status<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .get_rebalance_status(&table_name)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Get rebalance status failed: {}",
                        e
                    ))
                })?;

            Python::with_gil(|py| serialize_model_to_py(py, &result))
        })
    }

    /// Insert data directly using JSON format.
    ///
    /// Args:
    ///     table_name: Name of the table to insert into
    ///     data: JSON string (JSONL format - one JSON object per line)
    ///     reader_batch_size: Optional record batch size for reader
    ///     use_async_read: Whether to use async reading (default: true)
    #[pyo3(signature = (table_name, data, reader_batch_size=None, use_async_read=None))]
    pub fn insert_data<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        data: String,
        reader_batch_size: Option<usize>,
        use_async_read: Option<bool>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let params = InsertQueryParams {
                reader_batch_size,
                use_async_read,
            };

            let result = client
                .insert_data(&table_name, &data, &params)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!("Insert data failed: {}", e))
                })?;

            Ok(InsertResult {
                inserted_record_batches: result.inserted_record_batches,
                inserted_row_count: result.inserted_row_count,
                total_inserted_record_batches: result.inserted_record_batches,
                total_inserted_row_count: result.inserted_row_count,
            })
        })
    }

    /// Insert data using Arrow IPC stream format.
    ///
    /// Args:
    ///     table_name: Name of the table to insert into
    ///     data: Arrow IPC stream bytes (schema + record batches)
    #[pyo3(signature = (table_name, data))]
    pub fn insert_arrow_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        data: Vec<u8>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .insert_data_arrow_stream(&table_name, data)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Insert arrow stream failed: {}",
                        e
                    ))
                })?;

            Ok(InsertResult {
                inserted_record_batches: result.inserted_record_batches,
                inserted_row_count: result.inserted_row_count,
                total_inserted_record_batches: result.inserted_record_batches,
                total_inserted_row_count: result.inserted_row_count,
            })
        })
    }

    /// Insert data from a local Parquet file by converting it to an Arrow IPC stream.
    ///
    /// Args:
    ///     table_name: Name of the table to insert into
    ///     parquet_path: Local parquet file path
    ///     parquet_batch_size: Optional parquet reader batch size (rows per record batch)
    #[pyo3(signature = (table_name, parquet_path, parquet_batch_size=None))]
    pub fn insert_parquet_as_arrow_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        parquet_path: String,
        parquet_batch_size: Option<usize>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .insert_parquet_file_as_arrow_stream(
                    &table_name,
                    std::path::Path::new(&parquet_path),
                    parquet_batch_size,
                )
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Insert parquet as arrow stream failed: {}",
                        e
                    ))
                })?;

            Ok(InsertResult {
                inserted_record_batches: result.inserted_record_batches,
                inserted_row_count: result.inserted_row_count,
                total_inserted_record_batches: result.inserted_record_batches,
                total_inserted_row_count: result.inserted_row_count,
            })
        })
    }

    #[pyo3(signature = (table_name, file_paths, storage_type=None, bucket=None, access_key=None, secret_key=None, region=None, endpoint=None, virtual_hosted_style=None, allow_http=None, format=None, batch_size=None, max_concurrent_files=None))]
    pub fn insert_from_file<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        file_paths: Vec<String>,
        storage_type: Option<String>,
        bucket: Option<String>,
        access_key: Option<String>,
        secret_key: Option<String>,
        region: Option<String>,
        endpoint: Option<String>,
        virtual_hosted_style: Option<bool>,
        allow_http: Option<bool>,
        format: Option<String>,
        batch_size: Option<usize>,
        max_concurrent_files: Option<usize>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let storage_type_enum =
                storage_type
                    .as_deref()
                    .map(|s| match s.to_uppercase().as_str() {
                        "AWS" => StorageType::Aws,
                        "S3" => StorageType::S3,
                        "CEPH" => StorageType::Ceph,
                        "MINIO" => StorageType::Minio,
                        "S3_COMPATIBLE" => StorageType::S3Compatible,
                        "GCP" => StorageType::Gcp,
                        "AZURE" => StorageType::Azure,
                        _ => StorageType::Local,
                    });

            let credentials = if access_key.is_some() || secret_key.is_some() {
                Some(CloudStorageCredentials {
                    access_key,
                    secret_key,
                })
            } else {
                None
            };

            let options = if region.is_some()
                || endpoint.is_some()
                || virtual_hosted_style.is_some()
                || allow_http.is_some()
            {
                Some(CloudStorageOptions {
                    region,
                    endpoint,
                    virtual_hosted_style,
                    allow_http,
                })
            } else {
                None
            };

            let storage_config = if storage_type_enum.is_some()
                || bucket.is_some()
                || credentials.is_some()
                || options.is_some()
            {
                Some(StorageConfig {
                    storage_type: storage_type_enum,
                    bucket,
                    credentials,
                    options,
                })
            } else {
                None
            };

            let file_format = format.as_deref().map(|f| match f.to_lowercase().as_str() {
                "jsonl" => FileFormat::Jsonl,
                "parquet" => FileFormat::Parquet,
                _ => FileFormat::Parquet,
            });

            let request = Paths {
                paths: file_paths,
                storage_config,
            };

            let params = BatchInsertQueryParams {
                format: file_format,
                reader_batch_size: batch_size,
                max_concurrent_files,
                include_metrics: None,
            };

            let result = client
                .batch_insert_data(&table_name, &request, &params)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Insert from file failed: {}",
                        e
                    ))
                })?;

            build_import_files_result(result)
        })
    }

    #[pyo3(signature = (table_name, projection=None, filter=None, limit=None, include_metrics=None, allow_writer=None))]
    pub fn scan_data<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        projection: Option<String>,
        filter: Option<String>,
        limit: Option<i32>,
        include_metrics: Option<bool>,
        allow_writer: Option<bool>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let request = DataScanRequest {
                projection,
                filter,
                limit,
            };

            let params = ScanQueryParams {
                include_metrics,
                allow_writer,
                include_internal_columns: None,
            };

            let result = client
                .scan_data_stream(&table_name, &request, &params)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!("Scan data failed: {}", e))
                })?
                .collect_arrow_ipc()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Scan data stream collection failed: {}",
                        e
                    ))
                })?;

            let elapsed_time = result
                .metrics()
                .map(|metrics| f64::from(metrics.elapsed_time));
            let rss_peak_bytes = result.metrics().and_then(|metrics| metrics.rss_peak_bytes);

            build_result_set_payload(
                result.into_arrow_ipc_stream(),
                1,
                elapsed_time,
                rss_peak_bytes,
            )
        })
    }

    #[pyo3(signature = (table_name, projection=None, filter=None, limit=None, include_metrics=None, allow_writer=None))]
    pub fn scan_data_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        projection: Option<String>,
        filter: Option<String>,
        limit: Option<i32>,
        include_metrics: Option<bool>,
        allow_writer: Option<bool>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let request = DataScanRequest {
                projection,
                filter,
                limit,
            };

            let params = ScanQueryParams {
                include_metrics,
                allow_writer,
                include_internal_columns: None,
            };

            let stream = client
                .scan_data_stream(&table_name, &request, &params)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Open scan data stream failed: {}",
                        e
                    ))
                })?
                .into_record_batch_stream()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Decode scan data stream failed: {}",
                        e
                    ))
                })?;

            Ok(RecordBatchStreamBinding {
                state: Arc::new(Mutex::new(RecordBatchStreamBindingState {
                    stream: Some(stream),
                    elapsed_time: None,
                    rss_peak_bytes: None,
                })),
            })
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, ef_search=None, projection=None, filter=None))]
    pub fn vector_search<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<Vec<f32>>,
        top_k: Option<i32>,
        ef_search: Option<u32>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Dense {
                    vectors: query_vectors,
                    parameters,
                },
                projection,
                filter,
            };

            let result = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Vector search failed: {}",
                        e
                    ))
                })?
                .collect_arrow_ipc()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Vector search stream collection failed: {}",
                        e
                    ))
                })?;

            let num_resultsets = result.num_resultsets();
            let elapsed_time = result
                .metrics()
                .map(|metrics| f64::from(metrics.elapsed_time));
            let rss_peak_bytes = result.metrics().and_then(|metrics| metrics.rss_peak_bytes);

            build_result_set_payload(
                result.into_arrow_ipc_stream(),
                num_resultsets,
                elapsed_time,
                rss_peak_bytes,
            )
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, ef_search=None, projection=None, filter=None))]
    pub fn vector_search_batch<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<Vec<f32>>,
        top_k: Option<i32>,
        ef_search: Option<u32>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Dense {
                    vectors: query_vectors,
                    parameters,
                },
                projection,
                filter,
            };

            let result = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Vector batch search failed: {}",
                        e
                    ))
                })?
                .collect_arrow_ipc()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Vector batch search stream collection failed: {}",
                        e
                    ))
                })?;

            let elapsed_time = metrics_to_elapsed_time(result.metrics());
            let rss_peak_bytes = metrics_to_rss_peak_bytes(result.metrics());

            let resultset_batch_counts = result.resultset_batch_counts().to_vec();
            let arrow_ipc = result.into_arrow_ipc_stream();

            build_result_sets_payload(
                arrow_ipc,
                resultset_batch_counts,
                elapsed_time,
                rss_peak_bytes,
            )
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, ef_search=None, projection=None, filter=None))]
    pub fn vector_search_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<Vec<f32>>,
        top_k: Option<i32>,
        ef_search: Option<u32>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Dense {
                    vectors: query_vectors,
                    parameters,
                },
                projection,
                filter,
            };

            let stream = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Open vector search stream failed: {}",
                        e
                    ))
                })?
                .into_record_batch_stream()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Decode vector search stream failed: {}",
                        e
                    ))
                })?;

            Ok(RecordBatchStreamBinding {
                state: Arc::new(Mutex::new(RecordBatchStreamBindingState {
                    stream: Some(stream),
                    elapsed_time: None,
                    rss_peak_bytes: None,
                })),
            })
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, ef_search=None, projection=None, filter=None))]
    pub fn vector_search_batch_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<Vec<f32>>,
        top_k: Option<i32>,
        ef_search: Option<u32>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Dense {
                    vectors: query_vectors,
                    parameters,
                },
                projection,
                filter,
            };

            let stream = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Open vector batch search stream failed: {}",
                        e
                    ))
                })?
                .into_resultset_stream()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Decode vector batch resultset stream failed: {}",
                        e
                    ))
                })?;

            Ok(ResultSetStreamBinding {
                state: Arc::new(Mutex::new(ResultSetStreamBindingState {
                    stream: Some(stream),
                    elapsed_time: None,
                    rss_peak_bytes: None,
                })),
            })
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, bm25_k=None, bm25_b=None, metadata=None, projection=None, filter=None))]
    pub fn vector_search_sparse<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<String>,
        top_k: Option<i32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let metadata = parse_sparse_metadata(py, metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Sparse {
                    vectors: query_vectors,
                    parameters,
                    metadata,
                },
                projection,
                filter,
            };

            let result = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Sparse vector search failed: {}",
                        e
                    ))
                })?
                .collect_arrow_ipc()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Sparse vector search stream collection failed: {}",
                        e
                    ))
                })?;

            let num_resultsets = result.num_resultsets();
            let elapsed_time = result
                .metrics()
                .map(|metrics| f64::from(metrics.elapsed_time));
            let rss_peak_bytes = result.metrics().and_then(|metrics| metrics.rss_peak_bytes);

            build_result_set_payload(
                result.into_arrow_ipc_stream(),
                num_resultsets,
                elapsed_time,
                rss_peak_bytes,
            )
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, bm25_k=None, bm25_b=None, metadata=None, projection=None, filter=None))]
    pub fn vector_search_sparse_batch<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<String>,
        top_k: Option<i32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let metadata = parse_sparse_metadata(py, metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Sparse {
                    vectors: query_vectors,
                    parameters,
                    metadata,
                },
                projection,
                filter,
            };

            let result = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Sparse vector batch search failed: {}",
                        e
                    ))
                })?
                .collect_arrow_ipc()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Sparse vector batch search stream collection failed: {}",
                        e
                    ))
                })?;

            let elapsed_time = metrics_to_elapsed_time(result.metrics());
            let rss_peak_bytes = metrics_to_rss_peak_bytes(result.metrics());

            let resultset_batch_counts = result.resultset_batch_counts().to_vec();
            let arrow_ipc = result.into_arrow_ipc_stream();

            build_result_sets_payload(
                arrow_ipc,
                resultset_batch_counts,
                elapsed_time,
                rss_peak_bytes,
            )
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, bm25_k=None, bm25_b=None, metadata=None, projection=None, filter=None))]
    pub fn vector_search_sparse_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<String>,
        top_k: Option<i32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let metadata = parse_sparse_metadata(py, metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Sparse {
                    vectors: query_vectors,
                    parameters,
                    metadata,
                },
                projection,
                filter,
            };

            let stream = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Open sparse vector search stream failed: {}",
                        e
                    ))
                })?
                .into_record_batch_stream()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Decode sparse vector search stream failed: {}",
                        e
                    ))
                })?;

            Ok(RecordBatchStreamBinding {
                state: Arc::new(Mutex::new(RecordBatchStreamBindingState {
                    stream: Some(stream),
                    elapsed_time: None,
                    rss_peak_bytes: None,
                })),
            })
        })
    }

    #[pyo3(signature = (table_name, index_name, query_vectors, top_k=None, bm25_k=None, bm25_b=None, metadata=None, projection=None, filter=None))]
    pub fn vector_search_sparse_batch_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        index_name: String,
        query_vectors: Vec<String>,
        top_k: Option<i32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let metadata = parse_sparse_metadata(py, metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let request = VectorSearchRequest {
                top_k: top_k.unwrap_or(10),
                query: QueryVectors::Sparse {
                    vectors: query_vectors,
                    parameters,
                    metadata,
                },
                projection,
                filter,
            };

            let stream = client
                .vector_search_stream(&table_name, &index_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Open sparse vector batch search stream failed: {}",
                        e
                    ))
                })?
                .into_resultset_stream()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Decode sparse vector batch resultset stream failed: {}",
                        e
                    ))
                })?;

            Ok(ResultSetStreamBinding {
                state: Arc::new(Mutex::new(ResultSetStreamBindingState {
                    stream: Some(stream),
                    elapsed_time: None,
                    rss_peak_bytes: None,
                })),
            })
        })
    }

    #[pyo3(signature = (table_name, top_k, dense_column, dense_vectors, sparse_column, sparse_vectors, fusion_type, rrf_k=None, alpha=None, ef_search=None, bm25_k=None, bm25_b=None, sparse_metadata=None, projection=None, filter=None))]
    pub fn hybrid_search<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        top_k: i32,
        dense_column: String,
        dense_vectors: Vec<Vec<f32>>,
        sparse_column: String,
        sparse_vectors: Vec<String>,
        fusion_type: String,
        rrf_k: Option<u32>,
        alpha: Option<f32>,
        ef_search: Option<u32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        sparse_metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let sparse_metadata = parse_sparse_metadata(py, sparse_metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let dense_parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let dense = DenseVectorSearchConfig {
                column: dense_column,
                vectors: dense_vectors,
                parameters: dense_parameters,
            };

            let sparse_parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let sparse = SparseVectorSearchConfig {
                column: sparse_column,
                vectors: sparse_vectors,
                parameters: sparse_parameters,
                metadata: sparse_metadata,
            };

            let fusion_parameters = if rrf_k.is_some() || alpha.is_some() {
                Some(FusionParameters { k: rrf_k, alpha })
            } else {
                None
            };

            let fusion = FusionConfig {
                r#type: fusion_type,
                parameters: fusion_parameters,
            };

            let request = HybridVectorSearchRequest {
                top_k,
                dense,
                sparse,
                fusion,
                projection,
                filter,
            };

            let result = client
                .hybrid_search_stream(&table_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Hybrid search failed: {}",
                        e
                    ))
                })?
                .collect_arrow_ipc()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Hybrid search stream collection failed: {}",
                        e
                    ))
                })?;

            let num_resultsets = result.num_resultsets();
            let elapsed_time = result
                .metrics()
                .map(|metrics| f64::from(metrics.elapsed_time));
            let rss_peak_bytes = result.metrics().and_then(|metrics| metrics.rss_peak_bytes);

            build_result_set_payload(
                result.into_arrow_ipc_stream(),
                num_resultsets,
                elapsed_time,
                rss_peak_bytes,
            )
        })
    }

    #[pyo3(signature = (table_name, top_k, dense_column, dense_vectors, sparse_column, sparse_vectors, fusion_type, rrf_k=None, alpha=None, ef_search=None, bm25_k=None, bm25_b=None, sparse_metadata=None, projection=None, filter=None))]
    pub fn hybrid_search_batch<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        top_k: i32,
        dense_column: String,
        dense_vectors: Vec<Vec<f32>>,
        sparse_column: String,
        sparse_vectors: Vec<String>,
        fusion_type: String,
        rrf_k: Option<u32>,
        alpha: Option<f32>,
        ef_search: Option<u32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        sparse_metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let sparse_metadata = parse_sparse_metadata(py, sparse_metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let dense_parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let dense = DenseVectorSearchConfig {
                column: dense_column,
                vectors: dense_vectors,
                parameters: dense_parameters,
            };

            let sparse_parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let sparse = SparseVectorSearchConfig {
                column: sparse_column,
                vectors: sparse_vectors,
                parameters: sparse_parameters,
                metadata: sparse_metadata,
            };

            let fusion_parameters = if rrf_k.is_some() || alpha.is_some() {
                Some(FusionParameters { k: rrf_k, alpha })
            } else {
                None
            };

            let fusion = FusionConfig {
                r#type: fusion_type,
                parameters: fusion_parameters,
            };

            let request = HybridVectorSearchRequest {
                top_k,
                dense,
                sparse,
                fusion,
                projection,
                filter,
            };

            let result = client
                .hybrid_search_stream(&table_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Hybrid batch search failed: {}",
                        e
                    ))
                })?
                .collect_arrow_ipc()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Hybrid batch search stream collection failed: {}",
                        e
                    ))
                })?;

            let elapsed_time = metrics_to_elapsed_time(result.metrics());
            let rss_peak_bytes = metrics_to_rss_peak_bytes(result.metrics());

            let resultset_batch_counts = result.resultset_batch_counts().to_vec();
            let arrow_ipc = result.into_arrow_ipc_stream();

            build_result_sets_payload(
                arrow_ipc,
                resultset_batch_counts,
                elapsed_time,
                rss_peak_bytes,
            )
        })
    }

    #[pyo3(signature = (table_name, top_k, dense_column, dense_vectors, sparse_column, sparse_vectors, fusion_type, rrf_k=None, alpha=None, ef_search=None, bm25_k=None, bm25_b=None, sparse_metadata=None, projection=None, filter=None))]
    pub fn hybrid_search_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        top_k: i32,
        dense_column: String,
        dense_vectors: Vec<Vec<f32>>,
        sparse_column: String,
        sparse_vectors: Vec<String>,
        fusion_type: String,
        rrf_k: Option<u32>,
        alpha: Option<f32>,
        ef_search: Option<u32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        sparse_metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let sparse_metadata = parse_sparse_metadata(py, sparse_metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let dense_parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let dense = DenseVectorSearchConfig {
                column: dense_column,
                vectors: dense_vectors,
                parameters: dense_parameters,
            };

            let sparse_parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let sparse = SparseVectorSearchConfig {
                column: sparse_column,
                vectors: sparse_vectors,
                parameters: sparse_parameters,
                metadata: sparse_metadata,
            };

            let fusion_parameters = if rrf_k.is_some() || alpha.is_some() {
                Some(FusionParameters { k: rrf_k, alpha })
            } else {
                None
            };

            let fusion = FusionConfig {
                r#type: fusion_type,
                parameters: fusion_parameters,
            };

            let request = HybridVectorSearchRequest {
                top_k,
                dense,
                sparse,
                fusion,
                projection,
                filter,
            };

            let stream = client
                .hybrid_search_stream(&table_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Open hybrid search stream failed: {}",
                        e
                    ))
                })?
                .into_record_batch_stream()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Decode hybrid search stream failed: {}",
                        e
                    ))
                })?;

            Ok(RecordBatchStreamBinding {
                state: Arc::new(Mutex::new(RecordBatchStreamBindingState {
                    stream: Some(stream),
                    elapsed_time: None,
                    rss_peak_bytes: None,
                })),
            })
        })
    }

    #[pyo3(signature = (table_name, top_k, dense_column, dense_vectors, sparse_column, sparse_vectors, fusion_type, rrf_k=None, alpha=None, ef_search=None, bm25_k=None, bm25_b=None, sparse_metadata=None, projection=None, filter=None))]
    pub fn hybrid_search_batch_stream<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        top_k: i32,
        dense_column: String,
        dense_vectors: Vec<Vec<f32>>,
        sparse_column: String,
        sparse_vectors: Vec<String>,
        fusion_type: String,
        rrf_k: Option<u32>,
        alpha: Option<f32>,
        ef_search: Option<u32>,
        bm25_k: Option<f32>,
        bm25_b: Option<f32>,
        sparse_metadata: Option<PyObject>,
        projection: Option<String>,
        filter: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let sparse_metadata = parse_sparse_metadata(py, sparse_metadata)?;
        let client = self.client.clone();
        future_into_py(py, async move {
            let dense_parameters = ef_search.map(|ef| DenseSearchParameters {
                ef_search: Some(ef),
            });

            let dense = DenseVectorSearchConfig {
                column: dense_column,
                vectors: dense_vectors,
                parameters: dense_parameters,
            };

            let sparse_parameters = if bm25_k.is_some() || bm25_b.is_some() {
                Some(SparseSearchParameters {
                    k: bm25_k,
                    b: bm25_b,
                })
            } else {
                None
            };

            let sparse = SparseVectorSearchConfig {
                column: sparse_column,
                vectors: sparse_vectors,
                parameters: sparse_parameters,
                metadata: sparse_metadata,
            };

            let fusion_parameters = if rrf_k.is_some() || alpha.is_some() {
                Some(FusionParameters { k: rrf_k, alpha })
            } else {
                None
            };

            let fusion = FusionConfig {
                r#type: fusion_type,
                parameters: fusion_parameters,
            };

            let request = HybridVectorSearchRequest {
                top_k,
                dense,
                sparse,
                fusion,
                projection,
                filter,
            };

            let stream = client
                .hybrid_search_stream(&table_name, &request)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Open hybrid batch search stream failed: {}",
                        e
                    ))
                })?
                .into_resultset_stream()
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Decode hybrid batch resultset stream failed: {}",
                        e
                    ))
                })?;

            Ok(ResultSetStreamBinding {
                state: Arc::new(Mutex::new(ResultSetStreamBindingState {
                    stream: Some(stream),
                    elapsed_time: None,
                    rss_peak_bytes: None,
                })),
            })
        })
    }

    #[pyo3(signature = (table_name, readable=None))]
    pub fn get_indexed_row_count<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        readable: Option<bool>,
    ) -> PyResult<&'py PyAny> {
        let client = self.client.clone();
        future_into_py(py, async move {
            let result = client
                .get_indexed_row_count_with_readable(&table_name, readable)
                .await
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Get indexed row count failed: {}",
                        e
                    ))
                })?;

            Ok(IndexedCountInfo {
                total_row_count: result.total_row_count,
                indexed_counts: result
                    .indexed_counts
                    .iter()
                    .map(|ic| IndexedCount {
                        index_name: ic.index_name.clone(),
                        index_type: ic.index_type.clone(),
                        indexed_row_count: ic.indexed_row_count,
                    })
                    .collect(),
                readable: result.readable.as_ref().map(build_indexed_count_summary),
            })
        })
    }
}

#[pymodule]
fn _seahorse_coral(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<CoralClient>()?;
    m.add_class::<TableView>()?;
    m.add_class::<TableSchema>()?;
    m.add_class::<PyNodeCheckpointInfo>()?;
    m.add_class::<PySegmentAssignment>()?;
    m.add_class::<PyTableAssignment>()?;
    m.add_class::<PyNodeInfo>()?;
    m.add_class::<PyNodeRecord>()?;
    m.add_class::<PyTableOperationSegmentFailure>()?;
    m.add_class::<PyTableOperationNodeFailure>()?;
    m.add_class::<PyTableOperationFailure>()?;
    m.add_class::<PyTableOperationSegmentStatus>()?;
    m.add_class::<PyTableOperationNodeSegmentStatus>()?;
    m.add_class::<PyTableOperationPollingInfo>()?;
    m.add_class::<PySegmentsStatusSummary>()?;
    m.add_class::<PySegmentsStatusResult>()?;
    m.add_class::<PySegmentsRetrySkipInfo>()?;
    m.add_class::<PySegmentsRetryNodeObservations>()?;
    m.add_class::<PySegmentsRetryNodeResult>()?;
    m.add_class::<PySegmentsRetrySummary>()?;
    m.add_class::<PySegmentsRetryResult>()?;
    m.add_class::<InsertResult>()?;
    m.add_class::<PyFileImportResult>()?;
    m.add_class::<PyImportFilesResult>()?;
    m.add_class::<ActiveSetFlushResult>()?;
    m.add_class::<ResultSetPayload>()?;
    m.add_class::<ResultSetsPayload>()?;
    m.add_class::<RecordBatchStreamBinding>()?;
    m.add_class::<ResultSetStreamBinding>()?;
    m.add_class::<IndexedCountSummary>()?;
    m.add_class::<IndexedCountInfo>()?;
    m.add_class::<IndexedCount>()?;
    Ok(())
}
