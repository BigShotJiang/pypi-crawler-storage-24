use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use utoipa::ToSchema;

/// Sync error information stored in Redis
/// Maps "table_id:segment_id" to array of set IDs with errors
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SyncErrorInfo {
    #[serde(flatten)]
    pub sync_errors: HashMap<String, Vec<i64>>,
}

impl SyncErrorInfo {
    pub fn new(sync_errors: HashMap<String, Vec<i64>>) -> Self {
        Self { sync_errors }
    }

    pub fn empty() -> Self {
        Self {
            sync_errors: HashMap::new(),
        }
    }
}
