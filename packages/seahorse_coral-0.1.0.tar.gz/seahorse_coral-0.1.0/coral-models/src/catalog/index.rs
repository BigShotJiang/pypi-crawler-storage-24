use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct IndexInfoElement {
    /// Column name targeted by the index (e.g. vector column).
    #[schema(example = "embedding")]
    pub column_name: String,
    /// Type of the index. "hnsw", "diskbased", "inverted".
    #[schema(example = "hnsw")]
    pub index_type: String,
    /// Additional parameters of the index.
    #[schema(example = json!({ "space": "l2space", "ef_construction": "200", "M": "16" }))]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub parameters: Option<IndexParameters>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
#[allow(non_snake_case)]
pub struct IndexParameters {
    /// Space of the index. "l2space", "ipspace".
    #[schema(example = "l2space")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub space: Option<String>,
    /// Ef construction of the index.
    #[schema(example = "200")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub ef_construction: Option<String>,
    /// M of the index.
    #[schema(example = "16")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub M: Option<String>,
    /// Sparse model of the index. "bm25".
    #[schema(example = "bm25")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sparse_model: Option<String>,
}
