use std::collections::HashMap;

use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

/// Full checkpoint information from `CHECKPOINT:{table_id}:{segment_id}` Redis key.
///
/// Writer nodes manage these keys and update them after flushing active sets to S3.
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CheckpointInfo {
    /// Checkpoint metadata version (incremented by writer on each update)
    pub version: i32,
    /// Redis key format version (currently 1)
    pub format_version: i32,
    /// Segment OID (same as SEGMENT's oid)
    pub oid: String,
    /// Kafka consumer committed offset (next read position)
    pub committed_offset: i64,
    /// Record batch index to skip during recovery (-1 if none)
    pub recovery_skip_index: i64,
    /// Primary key index version (monotonic, incremented on Update/Delete)
    pub pk_epoch: i64,
    /// Current active set number
    pub last_set_number: i64,
    /// Set version info: "set_number:version:row_count:deleted_count"
    pub set_versions: Vec<String>,
    /// Index-specific set counts: index_name -> ["set_number:indexed_count", ...]
    #[serde(default)]
    pub set_index_counts: HashMap<String, Vec<String>>,
}

#[deprecated(note = "Use CheckpointInfo")]
pub type SegmentCheckpoint = CheckpointInfo;
