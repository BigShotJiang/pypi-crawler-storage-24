use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Debug, thiserror::Error)]
pub enum CatalogKeyError {
    #[error("Invalid catalog key format: {0}")]
    InvalidFormat(String),
}

/// Redis key types
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
pub enum CatalogKey {
    Node {
        node_id: String,
    }, // NODE:{NODE_ID}
    Table {
        table_id: String,
    }, // TABLE:{TABLE_ID}
    Segment {
        table_id: String,
        segment_id: String,
    }, // SEGMENT:{TABLE_ID}:{SEGMENT_ID}
    SyncError {
        node_id: String,
    }, // SYNC_ERROR:{NODE_ID}
    Checkpoint {
        table_id: String,
        segment_id: String,
    }, // CHECKPOINT:{TABLE_ID}:{SEGMENT_ID}
}

impl CatalogKey {
    pub fn node(node_id: impl Into<String>) -> Self {
        CatalogKey::Node {
            node_id: node_id.into(),
        }
    }

    pub fn table(table_id: impl Into<String>) -> Self {
        CatalogKey::Table {
            table_id: table_id.into(),
        }
    }

    pub fn segment(table_id: impl Into<String>, segment_id: impl Into<String>) -> Self {
        CatalogKey::Segment {
            table_id: table_id.into(),
            segment_id: segment_id.into(),
        }
    }

    pub fn sync_error(node_id: impl Into<String>) -> Self {
        CatalogKey::SyncError {
            node_id: node_id.into(),
        }
    }

    pub fn checkpoint(table_id: impl Into<String>, segment_id: impl Into<String>) -> Self {
        CatalogKey::Checkpoint {
            table_id: table_id.into(),
            segment_id: segment_id.into(),
        }
    }
}

impl std::fmt::Display for CatalogKey {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CatalogKey::Node { node_id } => write!(f, "NODE:{}", node_id),
            CatalogKey::Table { table_id } => write!(f, "TABLE:{}", table_id),
            CatalogKey::Segment {
                table_id,
                segment_id,
            } => {
                write!(f, "SEGMENT:{}:{}", table_id, segment_id)
            }
            CatalogKey::SyncError { node_id } => write!(f, "SYNC_ERROR:{}", node_id),
            CatalogKey::Checkpoint {
                table_id,
                segment_id,
            } => {
                write!(f, "CHECKPOINT:{}:{}", table_id, segment_id)
            }
        }
    }
}

impl std::str::FromStr for CatalogKey {
    type Err = CatalogKeyError;

    fn from_str(key: &str) -> Result<Self, Self::Err> {
        if let Some(node_id) = key.strip_prefix("NODE:") {
            Ok(CatalogKey::Node {
                node_id: node_id.to_string(),
            })
        } else if let Some(table_id) = key.strip_prefix("TABLE:") {
            Ok(CatalogKey::Table {
                table_id: table_id.to_string(),
            })
        } else if let Some(segment_part) = key.strip_prefix("SEGMENT:") {
            if let Some((table_id, segment_id)) = segment_part.split_once(':') {
                Ok(CatalogKey::Segment {
                    table_id: table_id.to_string(),
                    segment_id: segment_id.to_string(),
                })
            } else {
                Err(CatalogKeyError::InvalidFormat(format!(
                    "Invalid catalog key format: {}",
                    key
                )))
            }
        } else if let Some(node_id) = key.strip_prefix("SYNC_ERROR:") {
            Ok(CatalogKey::SyncError {
                node_id: node_id.to_string(),
            })
        } else if let Some(checkpoint_part) = key.strip_prefix("CHECKPOINT:") {
            if let Some((table_id, segment_id)) = checkpoint_part.split_once(':') {
                Ok(CatalogKey::Checkpoint {
                    table_id: table_id.to_string(),
                    segment_id: segment_id.to_string(),
                })
            } else {
                Err(CatalogKeyError::InvalidFormat(format!(
                    "Invalid catalog key format: {}",
                    key
                )))
            }
        } else {
            Err(CatalogKeyError::InvalidFormat(format!(
                "Invalid catalog key format: {}",
                key
            )))
        }
    }
}

#[cfg(test)]
mod tests {
    use std::str::FromStr;

    use super::*;

    #[test]
    fn test_catalog_key() {
        let node_key = CatalogKey::node("R1");
        assert_eq!(node_key.to_string(), "NODE:R1");

        let table_key = CatalogKey::table("T1");
        assert_eq!(table_key.to_string(), "TABLE:T1");

        let segment_key = CatalogKey::segment("T1", "S1");
        assert_eq!(segment_key.to_string(), "SEGMENT:T1:S1");

        let sync_error_key = CatalogKey::sync_error("R1");
        assert_eq!(sync_error_key.to_string(), "SYNC_ERROR:R1");

        let checkpoint_key = CatalogKey::checkpoint("T1", "S1");
        assert_eq!(checkpoint_key.to_string(), "CHECKPOINT:T1:S1");

        assert_eq!(
            CatalogKey::from_str("NODE:R1").unwrap().to_string(),
            "NODE:R1"
        );
        assert_eq!(
            CatalogKey::from_str("TABLE:T1").unwrap().to_string(),
            "TABLE:T1"
        );
        assert_eq!(
            CatalogKey::from_str("SEGMENT:T1:S1").unwrap().to_string(),
            "SEGMENT:T1:S1"
        );
        assert_eq!(
            CatalogKey::from_str("SYNC_ERROR:R1").unwrap().to_string(),
            "SYNC_ERROR:R1"
        );
        assert_eq!(
            CatalogKey::from_str("CHECKPOINT:T1:S1")
                .unwrap()
                .to_string(),
            "CHECKPOINT:T1:S1"
        );
    }
}
