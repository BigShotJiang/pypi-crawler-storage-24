use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::catalog::SegmentAssignmentStatus;
use crate::catalog::index::IndexInfoElement;
use crate::catalog::segmentation::SegmentationInfo;
// Note: TableInfo is persisted in Redis and not exposed directly in OpenAPI.

fn default_format_version() -> i32 {
    1
}

/// Failure information for table create/rebalance operations.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
pub struct TableOperationFailure {
    /// Human-readable summary for operators/users.
    pub summary: String,
    /// When failure was detected (RFC3339 timestamp).
    #[schema(value_type = String, format = "date-time")]
    pub detected_at: String,
    /// Per-node list of failed segments (node-level grouping).
    pub node_failures: Vec<TableOperationNodeFailure>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
pub struct TableOperationNodeFailure {
    pub node_id: String,
    pub segments: Vec<TableOperationSegmentFailure>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
pub struct TableOperationSegmentFailure {
    pub segment_id: String,
    pub status: SegmentAssignmentStatus,
    pub failure_reason: String,
}

/// Segment information within a table (simplified for TABLE keys)
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct SegmentReference {
    pub segment_id: String,
    pub segment_oid: String,
}

/// Table information stored in Redis and used as the source-of-truth catalog value.
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TableInfo {
    pub table_name: String,
    pub version: i32,
    #[serde(default = "default_format_version")]
    pub format_version: i32,
    pub oid: String,
    #[schema(value_type = crate::docs::arrow_schema::ArrowSchema)]
    pub schema: arrow_schema::SchemaRef,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation_info: Option<SegmentationInfo>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub index_info: Option<Vec<IndexInfoElement>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub active_set_size_limit: Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_threads: Option<i32>,
    pub segments: Vec<SegmentReference>,
    /// Operational status of the table. If None, treated as ACTIVE for backward compatibility.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub status: Option<TableOperationalStatus>,
    /// Rebalancing context, present only while rebalancing is in progress.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rebalancing_context: Option<RebalancingContext>,
    /// Creation context, present only while creation is in progress.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub creation_context: Option<CreationContext>,
}

impl TableInfo {
    /// Create a dummy TableInfo for invalidation or placeholder purposes
    pub fn dummy() -> Self {
        Self {
            table_name: "dummy_table".to_string(),
            version: 1,
            format_version: default_format_version(),
            oid: "dummy_oid".to_string(),
            schema: std::sync::Arc::new(arrow_schema::Schema::new(vec![arrow_schema::Field::new(
                "dummy",
                arrow_schema::DataType::LargeUtf8,
                false,
            )])),
            segmentation_info: None,
            index_info: None,
            active_set_size_limit: None,
            max_threads: None,
            segments: Vec::new(),
            status: None,
            rebalancing_context: None,
            creation_context: None,
        }
    }

    /// Add a new segment to this table
    pub fn add_segment_reference(&mut self, segment_reference: SegmentReference) {
        self.segments.push(segment_reference);
    }

    /// Remove a segment from this table by segment_id
    pub fn remove_segment(&mut self, segment_id: &str) -> Option<SegmentReference> {
        if let Some(pos) = self
            .segments
            .iter()
            .position(|s| s.segment_id == segment_id)
        {
            Some(self.segments.remove(pos))
        } else {
            None
        }
    }

    /// Get segment information by segment_id
    pub fn get_segment(&self, segment_id: &str) -> Option<&SegmentReference> {
        self.segments.iter().find(|s| s.segment_id == segment_id)
    }

    /// Get mutable segment information by segment_id
    pub fn get_segment_mut(&mut self, segment_id: &str) -> Option<&mut SegmentReference> {
        self.segments
            .iter_mut()
            .find(|s| s.segment_id == segment_id)
    }

    /// Get all segments
    pub fn get_segments(&self) -> &Vec<SegmentReference> {
        &self.segments
    }

    /// Add index information
    pub fn add_index(&mut self, index_info: IndexInfoElement) {
        if self.index_info.is_none() {
            self.index_info = Some(Vec::new());
        }
        self.index_info.as_mut().unwrap().push(index_info);
    }

    /// Set active set size limit
    pub fn set_active_set_size_limit(&mut self, limit: i32) {
        self.active_set_size_limit = Some(limit);
    }

    /// Set max threads
    pub fn set_max_threads(&mut self, max_threads: i32) {
        self.max_threads = Some(max_threads);
    }
}

/// Operational status of a table
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum TableOperationalStatus {
    Active,
    CreatingInProgress,
    CreatingFailed,
    PreparingRebalance, // Table locked for rebalancing preparation (inserts blocked)
    RebalancingInProgress,
    RebalancingFailed,
}

/// Context information recorded while rebalancing is in progress
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct RebalancingContext {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub reader_nodes: Option<Vec<String>>, // requested reader nodes
    #[serde(skip_serializing_if = "Option::is_none")]
    pub writer_nodes: Option<Vec<String>>, // requested writer nodes
    #[serde(skip_serializing_if = "Option::is_none")]
    pub strategy: Option<String>, // e.g., "balanced_min_moves"
    #[serde(skip_serializing_if = "Option::is_none")]
    pub started_at: Option<String>, // RFC3339 timestamp
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure: Option<TableOperationFailure>,
}

/// Context information recorded while creation is in progress
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CreationContext {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub started_at: Option<String>, // RFC3339 timestamp
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure: Option<TableOperationFailure>,
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use super::*;
    use crate::catalog::index::IndexParameters;
    use crate::catalog::segmentation::{SegmentKeyCompositionType, SegmentType};

    #[test]
    fn test_table_info_serialization() {
        // Create table schema
        let schema = Arc::new(arrow_schema::Schema::new(vec![
            arrow_schema::Field::new("id", arrow_schema::DataType::Int64, false),
            arrow_schema::Field::new("name", arrow_schema::DataType::LargeUtf8, false),
        ]));

        // Create segmentation info
        let segmentation_info = SegmentationInfo {
            segment_type: SegmentType::Hash,
            segment_key_composition_type: Some(SegmentKeyCompositionType::Single),
            segment_keys: Some(vec!["id".to_string()]),
            num_buckets: Some(3),
        };

        let mut table_info = TableInfo {
            table_name: "test_sgmt".to_string(),
            version: 1,
            format_version: default_format_version(),
            oid: "1001".to_string(),
            schema,
            segmentation_info: Some(segmentation_info),
            index_info: None,
            active_set_size_limit: Some(1000),
            max_threads: Some(8),
            segments: Vec::new(),
            status: None,
            rebalancing_context: None,
            creation_context: None,
        };

        // Add index info
        let index_info = IndexInfoElement {
            column_name: "name".to_string(),
            index_type: "hnsw".to_string(),
            parameters: Some(IndexParameters {
                space: Some("ipspace".to_string()),
                M: Some("16".to_string()),
                ef_construction: Some("200".to_string()),
                sparse_model: None,
            }),
        };
        table_info.add_index(index_info);

        // Add segment info
        let segment_reference = SegmentReference {
            segment_id: "SEG001".to_string(),
            segment_oid: "1001".to_string(),
        };
        table_info.add_segment_reference(segment_reference);

        let json = serde_json::to_string_pretty(&table_info).unwrap();
        println!("TableInfo JSON:\n{}", json);

        let deserialized: TableInfo = serde_json::from_str(&json).unwrap();
        assert_eq!(table_info.version, deserialized.version);
        assert_eq!(table_info.oid, deserialized.oid);
        assert_eq!(table_info.table_name, deserialized.table_name);
        assert_eq!(table_info.segments.len(), deserialized.segments.len());
        assert_eq!(
            table_info.segments[0].segment_id,
            deserialized.segments[0].segment_id
        );
    }

    #[test]
    fn test_table_info_creation_context_serialization() {
        let mut table_info = TableInfo::dummy();
        table_info.status = Some(TableOperationalStatus::CreatingInProgress);
        table_info.creation_context = Some(CreationContext {
            started_at: Some("2025-01-01T00:00:00Z".to_string()),
            failure: None,
        });

        let json = serde_json::to_string_pretty(&table_info).unwrap();
        let deserialized: TableInfo = serde_json::from_str(&json).unwrap();
        assert!(matches!(
            deserialized.status,
            Some(TableOperationalStatus::CreatingInProgress)
        ));
        assert_eq!(
            deserialized
                .creation_context
                .and_then(|c| c.started_at)
                .unwrap(),
            "2025-01-01T00:00:00Z".to_string()
        );
    }

    #[test]
    fn test_table_operational_status_creating_failed_serialization() {
        let json = serde_json::to_string(&TableOperationalStatus::CreatingFailed).unwrap();
        assert_eq!(json, "\"CREATING_FAILED\"");

        let deserialized: TableOperationalStatus = serde_json::from_str(&json).unwrap();
        assert_eq!(deserialized, TableOperationalStatus::CreatingFailed);
    }
}
