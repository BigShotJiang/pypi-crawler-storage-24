use std::time::{Duration, SystemTime};

use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::catalog::{NodeInfo, SegmentInfo, TableInfo};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "UPPERCASE")]
pub enum CacheEntryType {
    Node,
    Table,
    Segment,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum CacheEntryValue {
    Node(NodeInfo),
    Table(TableInfo),
    Segment(SegmentInfo),
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheEntryDump {
    pub key: String,
    pub cache_type: CacheEntryType,
    #[schema(value_type = String, format = "date-time")]
    pub created_at: SystemTime,
    #[schema(value_type = u64, format = "seconds")]
    pub ttl: Duration,
    pub invalidated: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub value: Option<CacheEntryValue>,
}
