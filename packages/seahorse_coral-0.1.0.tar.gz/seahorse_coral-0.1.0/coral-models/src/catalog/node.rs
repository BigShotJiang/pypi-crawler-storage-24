use std::collections::HashMap;

use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

fn default_format_version() -> i32 {
    1
}

/// Node types
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
#[serde(rename_all = "UPPERCASE")]
pub enum NodeType {
    Reader,
    Writer,
}

/// Node states
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum NodeState {
    InRecovery,
    Active,
    Inactive,
}

/// Node stage (lifecycle)
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum NodeStage {
    Init,
    Loading,
    Subscribing,
    Running,
}

impl Default for NodeStage {
    fn default() -> Self {
        Self::Running
    }
}

/// Table assignment information for a node
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TableAssignment {
    pub table_oid: String,
    pub segments: HashMap<String, SegmentAssignment>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SegmentAssignmentStatus {
    Syncing,
    Synced,
    Removing,
    Failed,
    #[serde(other)]
    Unknown,
}

impl Default for SegmentAssignmentStatus {
    fn default() -> Self {
        // Backward compatibility: legacy assignments had no explicit status.
        // Treat them as "SYNCED" to preserve previous success semantics.
        Self::Synced
    }
}

/// Lightweight checkpoint info embedded in `SegmentAssignment` (NodeInfo).
///
/// This is a subset of `CheckpointInfo` used by reader nodes.
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct NodeCheckpointInfo {
    pub last_set_number: Option<i64>,
    pub set_versions: Vec<String>,
    #[serde(default)]
    pub set_index_counts: HashMap<String, Vec<String>>,
}

/// Assignment information for a segment on a node
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct SegmentAssignment {
    pub segment_oid: String,
    #[serde(default)]
    pub status: SegmentAssignmentStatus,
    #[serde(default)]
    pub failure_reason: String,
    pub checkpoint: NodeCheckpointInfo,
}

/// Node information stored in Redis
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct NodeInfo {
    pub version: i32,
    #[serde(default = "default_format_version")]
    pub format_version: i32,
    #[serde(rename = "type")]
    pub node_type: NodeType,
    pub state: NodeState,
    #[serde(default)]
    pub node_stage: NodeStage,
    /// Timestamp string for last update time.
    ///
    /// Format: "YYYYMMDD-HH24:MM:SS" (e.g. "20260108-00:00:00")
    #[serde(default)]
    #[schema(example = "20260108-00:00:00")]
    pub last_updated: String,
    pub node_address: String,
    pub assigned_tables: HashMap<String, TableAssignment>,
}

impl NodeInfo {
    pub fn dummy() -> Self {
        Self {
            version: 1,
            format_version: default_format_version(),
            node_type: NodeType::Reader,
            state: NodeState::Active,
            node_stage: NodeStage::default(),
            last_updated: String::new(),
            node_address: "dummy_address".to_string(),
            assigned_tables: HashMap::new(),
        }
    }

    /// Returns true iff this node can be used for placement/serving.
    pub fn is_active(&self) -> bool {
        matches!(self.state, NodeState::Active)
    }

    /// Check if a table segment is assigned to this node
    pub fn is_assigned(&self, table_id: &str, segment_id: &str) -> bool {
        let table_assignment = self.assigned_tables.get(table_id);
        if let Some(table_assignment) = table_assignment {
            table_assignment.segments.contains_key(segment_id)
        } else {
            false
        }
    }
}
mod tests {
    #[allow(unused_imports)]
    use std::collections::HashMap;

    #[allow(unused_imports)]
    use super::{
        NodeCheckpointInfo, NodeInfo, NodeStage, NodeState, NodeType, SegmentAssignment,
        SegmentAssignmentStatus, TableAssignment,
    };

    #[test]
    fn test_node_info_serialization() {
        let mut node_info = NodeInfo {
            version: 1,
            format_version: 1,
            node_type: NodeType::Writer,
            state: NodeState::Active,
            node_stage: NodeStage::Running,
            last_updated: "20260108-00:00:00".to_string(),
            node_address: "localhost:8080".to_string(),
            assigned_tables: HashMap::new(),
        };

        // Manually create table assignment with segment
        let mut segments = HashMap::new();
        segments.insert(
            "segment1".to_string(),
            SegmentAssignment {
                segment_oid: "3001".to_string(),
                status: SegmentAssignmentStatus::Synced,
                failure_reason: "".to_string(),
                checkpoint: NodeCheckpointInfo {
                    last_set_number: Some(0),
                    set_versions: vec![],
                    set_index_counts: HashMap::new(),
                },
            },
        );

        let table_assignment = TableAssignment {
            table_oid: "1001".to_string(),
            segments,
        };

        node_info
            .assigned_tables
            .insert("test_sgmt".to_string(), table_assignment);

        let json = serde_json::to_string_pretty(&node_info).unwrap();
        println!("NodeInfo JSON:\n{}", json);

        let deserialized: NodeInfo = serde_json::from_str(&json).unwrap();
        assert_eq!(node_info.node_type, deserialized.node_type);
        assert_eq!(node_info.node_address, deserialized.node_address);
        assert_eq!(node_info.last_updated, deserialized.last_updated);
        assert_eq!(
            node_info.assigned_tables.len(),
            deserialized.assigned_tables.len()
        );
        // Check that the segment assignment is preserved
        let table_key = "test_sgmt";
        let segment_key = "segment1";

        let original_segment = node_info
            .assigned_tables
            .get(table_key)
            .unwrap()
            .segments
            .get(segment_key)
            .unwrap();

        let deserialized_segment = deserialized
            .assigned_tables
            .get(table_key)
            .unwrap()
            .segments
            .get(segment_key)
            .unwrap();

        assert_eq!(
            original_segment.segment_oid,
            deserialized_segment.segment_oid
        );
        assert_eq!(original_segment.status, deserialized_segment.status);
        assert_eq!(
            original_segment.failure_reason,
            deserialized_segment.failure_reason
        );
        assert_eq!(
            original_segment.checkpoint.last_set_number,
            deserialized_segment.checkpoint.last_set_number
        );
    }

    #[test]
    fn test_node_state_serialization_in_recovery_is_screaming_snake_case() {
        let json = serde_json::to_string(&NodeState::InRecovery).unwrap();
        assert_eq!(json, "\"IN_RECOVERY\"");
        let back: NodeState = serde_json::from_str(&json).unwrap();
        assert_eq!(back, NodeState::InRecovery);
    }

    #[test]
    fn checkpoint_deserializes_with_unknown_fields() {
        let json = r#"{
  "version": 1,
  "format_version": 1,
  "oid": "019c1254-b056-7a26-b715-44eefef22702",
  "committed_offset": 16,
  "recovery_skip_index": -1,
  "pk_epoch": 4,
  "last_set_number": 1,
  "set_versions": ["0:2:1000:0", "1:2:518:508"],
  "set_index_counts": {
    "emb:diskbased": ["0:1000", "1:10"],
    "sparse_emb:inverted": ["0:1000", "1:10"]
  }
}"#;

        let checkpoint: NodeCheckpointInfo = serde_json::from_str(json).unwrap();
        assert_eq!(checkpoint.last_set_number, Some(1));
        assert_eq!(
            checkpoint.set_versions,
            vec!["0:2:1000:0".to_string(), "1:2:518:508".to_string()]
        );
        assert_eq!(
            checkpoint
                .set_index_counts
                .get("emb:diskbased")
                .cloned()
                .unwrap(),
            vec!["0:1000".to_string(), "1:10".to_string()]
        );
    }

    #[test]
    fn test_segment_assignment_status_default_is_synced() {
        // Backward compatibility: missing "status" should default to SYNCED.
        let json = r#"
        {
          "segment_oid": "3001",
          "checkpoint": { "last_set_number": 0, "set_versions": [], "set_index_counts": {} }
        }
        "#;
        let assignment: SegmentAssignment = serde_json::from_str(json).unwrap();
        assert_eq!(assignment.status, SegmentAssignmentStatus::Synced);
        assert_eq!(assignment.failure_reason, "");
    }

    #[test]
    fn test_segment_assignment_status_serialization_removing_is_screaming_snake_case() {
        let json = serde_json::to_string(&SegmentAssignmentStatus::Removing).unwrap();
        assert_eq!(json, "\"REMOVING\"");
        let back: SegmentAssignmentStatus = serde_json::from_str(&json).unwrap();
        assert_eq!(back, SegmentAssignmentStatus::Removing);
    }

    #[test]
    fn test_segment_assignment_status_unknown_deserializes_from_unrecognized() {
        let json = "\"SOME_FUTURE_STATUS\"";
        let st: SegmentAssignmentStatus = serde_json::from_str(json).unwrap();
        assert_eq!(st, SegmentAssignmentStatus::Unknown);
    }

    #[test]
    fn test_node_info_last_updated_defaults_to_empty_string() {
        // Backward compatibility: missing "last_updated" should default to empty string.
        let json = r#"
        {
          "version": 1,
          "type": "READER",
          "format_version": 1,
          "state": "ACTIVE",
          "node_stage": "RUNNING",
          "node_address": "localhost:8080",
          "assigned_tables": {}
        }
        "#;
        let info: NodeInfo = serde_json::from_str(json).unwrap();
        assert_eq!(info.last_updated, "");
    }
}
