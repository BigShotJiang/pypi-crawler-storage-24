use std::collections::HashMap;

use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

fn default_format_version() -> i32 {
    1
}

#[derive(Debug, Serialize, Deserialize, Clone, ToSchema)]
pub struct SegmentationInfo {
    /// Type of the segmentation. "hash", "value".
    #[schema(example = "hash")]
    pub segment_type: SegmentType,
    /// Keys of the segmentation. Can have multiple keys for composite segmentation.
    #[schema(example = json!(["id"]))]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segment_keys: Option<Vec<String>>,
    /// Number of buckets of the segmentation. Only required for hash segmentation.
    #[schema(example = 10)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub num_buckets: Option<u32>,
    /// Composition type of the segmentation. "single", "hierarchical", "composite".
    #[schema(example = "single")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segment_key_composition_type: Option<SegmentKeyCompositionType>,
}

impl SegmentationInfo {
    pub fn hash(segment_keys: &[String], num_buckets: u32) -> Self {
        Self {
            segment_type: SegmentType::Hash,
            segment_keys: Some(segment_keys.to_vec()),
            num_buckets: Some(num_buckets),
            segment_key_composition_type: Some(SegmentKeyCompositionType::Single),
        }
    }

    pub fn value(segment_keys: &[String]) -> Self {
        if segment_keys.is_empty() {
            return Self::default();
        }

        let composition_type = if segment_keys.len() > 1 {
            SegmentKeyCompositionType::Composite
        } else {
            SegmentKeyCompositionType::Single
        };

        Self {
            segment_type: SegmentType::Value,
            segment_keys: Some(segment_keys.to_vec()),
            num_buckets: None,
            segment_key_composition_type: Some(composition_type),
        }
    }
}

impl Default for SegmentationInfo {
    fn default() -> Self {
        Self {
            segment_type: SegmentType::Undefined,
            segment_keys: None,
            num_buckets: None,
            segment_key_composition_type: None,
        }
    }
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq, Clone, ToSchema)]
#[serde(rename_all = "lowercase")]
pub enum SegmentType {
    Undefined,
    Value,
    Hash,
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq, Clone, ToSchema)]
#[serde(rename_all = "lowercase")]
pub enum SegmentKeyCompositionType {
    Single,
    Hierarchical,
    Composite,
}

/// Column min/max value information (per column)
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ColumnMinMaxValue {
    pub min: serde_json::Value,
    pub max: serde_json::Value,
}

/// Kafka information for a segment
#[derive(Debug, Clone, Serialize, Deserialize, Hash, Eq, PartialEq, Ord, PartialOrd, ToSchema)]
pub struct KafkaInfo {
    pub topic: String,
    pub partition: i32,
}

/// Segment tag information (stored under SEGMENT:{TABLE_ID}:{SEGMENT_TAG})
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct SegmentInfo {
    pub oid: String,
    pub version: i32,
    #[serde(default = "default_format_version")]
    pub format_version: i32,
    pub kafka_info: KafkaInfo,
    pub column_min_max: HashMap<String, ColumnMinMaxValue>, // {column_name: {min, max}}
    pub reader: Vec<String>,
    pub writer: String,
    /// Previous assignment snapshot used by Seahorse to migrate data. Present only during rebalancing.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub migration_source: Option<SegmentAssignmentSnapshot>,
}

impl SegmentInfo {
    pub fn dummy() -> Self {
        Self {
            oid: "dummy_oid".to_string(),
            version: 1,
            format_version: default_format_version(),
            kafka_info: KafkaInfo {
                topic: "dummy_topic".to_string(),
                partition: 0,
            },
            column_min_max: HashMap::new(),
            reader: vec!["dummy_reader".to_string()],
            writer: "dummy_writer".to_string(),
            migration_source: None,
        }
    }
}

impl Default for SegmentInfo {
    fn default() -> Self {
        Self::dummy()
    }
}

/// Assignment snapshot for a segment (before rebalancing commit)
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct SegmentAssignmentSnapshot {
    pub readers: Vec<String>,
    pub writer: String,
}

//=============================================================================
// Segment ID
//=============================================================================

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Hash, Eq)]
pub enum ColumnDefinition {
    Single(String),
    Hierarchy(Vec<String>),
    Composite(Vec<String>),
}

impl ColumnDefinition {
    pub fn get_type_str(&self) -> &'static str {
        match self {
            ColumnDefinition::Single(_) => "single",
            ColumnDefinition::Hierarchy(_) => "hier",
            ColumnDefinition::Composite(_) => "comp",
        }
    }
}

impl std::fmt::Display for ColumnDefinition {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ColumnDefinition::Single(col) => write!(f, "{}", col),
            ColumnDefinition::Hierarchy(cols) => write!(f, "{}", cols.join(">")),
            ColumnDefinition::Composite(cols) => write!(f, "{}", cols.join("+")),
        }
    }
}

impl std::str::FromStr for ColumnDefinition {
    type Err = SegmentIdError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s.contains('>') {
            let cols: Vec<String> = s.split('>').map(|s| s.to_string()).collect();
            if cols.len() < 2 {
                return Err(SegmentIdError::InvalidColumnFormat(s.to_string()));
            }
            Ok(ColumnDefinition::Hierarchy(cols))
        } else if s.contains('+') {
            let cols: Vec<String> = s.split('+').map(|s| s.to_string()).collect();
            if cols.len() < 2 {
                return Err(SegmentIdError::InvalidColumnFormat(s.to_string()));
            }
            Ok(ColumnDefinition::Composite(cols))
        } else {
            Ok(ColumnDefinition::Single(s.to_string()))
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Hash, Eq)]
pub enum BucketInfo {
    Single(u32),
    Hierarchy(Vec<u32>),
}

impl std::fmt::Display for BucketInfo {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            BucketInfo::Single(bucket) => write!(f, "{}", bucket),
            BucketInfo::Hierarchy(buckets) => write!(
                f,
                "{}",
                buckets
                    .iter()
                    .map(|b| b.to_string())
                    .collect::<Vec<_>>()
                    .join(".")
            ),
        }
    }
}

impl std::str::FromStr for BucketInfo {
    type Err = SegmentIdError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s.contains('.') {
            let buckets: Result<Vec<u32>, _> = s.split('.').map(|b| b.parse::<u32>()).collect();
            match buckets {
                Ok(b) => Ok(BucketInfo::Hierarchy(b)),
                Err(_) => Err(SegmentIdError::InvalidBucketFormat(s.to_string())),
            }
        } else {
            match s.parse::<u32>() {
                Ok(bucket) => Ok(BucketInfo::Single(bucket)),
                Err(_) => Err(SegmentIdError::InvalidBucketFormat(s.to_string())),
            }
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Hash, Eq)]
pub enum NumBuckets {
    Single(u32),
    Hierarchy(Vec<u32>),
}

impl std::fmt::Display for NumBuckets {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            NumBuckets::Single(num) => write!(f, "{}", num),
            NumBuckets::Hierarchy(nums) => write!(
                f,
                "{}",
                nums.iter()
                    .map(|n| n.to_string())
                    .collect::<Vec<_>>()
                    .join(".")
            ),
        }
    }
}

impl std::str::FromStr for NumBuckets {
    type Err = SegmentIdError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s.contains('.') {
            let buckets: Result<Vec<u32>, _> = s.split('.').map(|b| b.parse::<u32>()).collect();
            match buckets {
                Ok(b) => Ok(NumBuckets::Hierarchy(b)),
                Err(_) => Err(SegmentIdError::InvalidNumBucketsFormat(s.to_string())),
            }
        } else {
            match s.parse::<u32>() {
                Ok(num) => Ok(NumBuckets::Single(num)),
                Err(_) => Err(SegmentIdError::InvalidNumBucketsFormat(s.to_string())),
            }
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Hash, Eq)]
pub enum SegmentTag {
    Default,
    Hash {
        columns: ColumnDefinition,
        bucket: BucketInfo,
        num_buckets: NumBuckets,
    },
    Value {
        columns: ColumnDefinition,
        values: Vec<String>,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Hash, Eq)]
pub struct SegmentId {
    pub version: String,
    pub segment_tag: SegmentTag,
    pub metadata: String,
}

impl SegmentId {
    const DELIMITER: &'static str = "|";
}

#[derive(Debug, thiserror::Error)]
pub enum SegmentIdError {
    #[error("Invalid segment ID format: {0}")]
    InvalidFormat(String),

    #[error("Invalid column format: {0}")]
    InvalidColumnFormat(String),

    #[error("Invalid bucket format: {0}")]
    InvalidBucketFormat(String),

    #[error("Invalid num_buckets format: {0}")]
    InvalidNumBucketsFormat(String),

    #[error("Invalid segment type: {0}")]
    InvalidSegmentType(String),

    #[error("JSON parsing error: {0}")]
    JsonError(String),
}

impl SegmentId {
    pub fn new_hash_single(
        version: String,
        column: String,
        bucket: u32,
        num_buckets: u32,
        metadata: String,
    ) -> Self {
        SegmentId {
            version,
            segment_tag: SegmentTag::Hash {
                columns: ColumnDefinition::Single(column),
                bucket: BucketInfo::Single(bucket),
                num_buckets: NumBuckets::Single(num_buckets),
            },
            metadata,
        }
    }

    pub fn new_hash_hierarchy(
        version: String,
        columns: Vec<String>,
        buckets: Vec<u32>,
        num_buckets: Vec<u32>,
        metadata: String,
    ) -> Self {
        SegmentId {
            version,
            segment_tag: SegmentTag::Hash {
                columns: ColumnDefinition::Hierarchy(columns),
                bucket: BucketInfo::Hierarchy(buckets),
                num_buckets: NumBuckets::Hierarchy(num_buckets),
            },
            metadata,
        }
    }

    pub fn new_hash_composite(
        version: String,
        columns: Vec<String>,
        bucket: u32,
        num_buckets: u32,
        metadata: String,
    ) -> Self {
        SegmentId {
            version,
            segment_tag: SegmentTag::Hash {
                columns: ColumnDefinition::Composite(columns),
                bucket: BucketInfo::Single(bucket),
                num_buckets: NumBuckets::Single(num_buckets),
            },
            metadata,
        }
    }

    pub fn new_value_single(
        version: String,
        column: String,
        value: String,
        metadata: String,
    ) -> Self {
        SegmentId {
            version,
            segment_tag: SegmentTag::Value {
                columns: ColumnDefinition::Single(column),
                values: vec![value],
            },
            metadata,
        }
    }

    pub fn new_value_composite(
        version: String,
        columns: Vec<String>,
        values: Vec<String>,
        metadata: String,
    ) -> Self {
        SegmentId {
            version,
            segment_tag: SegmentTag::Value {
                columns: ColumnDefinition::Composite(columns),
                values,
            },
            metadata,
        }
    }

    // Escape delimiter characters in a string
    fn escape_string(s: &str) -> String {
        s.replace(Self::DELIMITER, &format!("\\{}", Self::DELIMITER))
    }

    // Unescape delimiter characters in a string
    fn unescape_string(s: &str) -> String {
        s.replace(&format!("\\{}", Self::DELIMITER), Self::DELIMITER)
    }

    // Convert values Vec<String> to escaped JSON-like string
    fn values_to_string(values: &[String]) -> String {
        let escaped_values: Vec<String> = values
            .iter()
            .map(|v| format!("\"{}\"", Self::escape_string(v)))
            .collect();
        format!("[{}]", escaped_values.join(","))
    }

    // Parse escaped JSON-like string back to Vec<String>
    fn string_to_values(s: &str) -> Result<Vec<String>, SegmentIdError> {
        if !s.starts_with('[') || !s.ends_with(']') {
            return Err(SegmentIdError::JsonError(
                "Values must be in array format [...]".to_string(),
            ));
        }

        let inner = &s[1..s.len() - 1];
        if inner.is_empty() {
            return Ok(vec![]);
        }

        let mut values = Vec::new();
        let mut current = String::new();
        let mut in_string = false;
        let mut escape_next = false;
        let chars: Vec<char> = inner.chars().collect();

        let mut i = 0;
        while i < chars.len() {
            let ch = chars[i];

            if escape_next {
                current.push(ch);
                escape_next = false;
                i += 1;
                continue;
            }

            if ch == '\\' {
                escape_next = true;
                i += 1;
                continue;
            }

            if ch == '"' {
                if in_string {
                    // End of string value
                    values.push(Self::unescape_string(&current));
                    current.clear();
                    in_string = false;
                } else {
                    // Start of string value
                    in_string = true;
                }
                i += 1;
                continue;
            }

            if in_string {
                current.push(ch);
            } else if ch == ',' {
                // Skip comma outside of strings
            }

            i += 1;
        }

        Ok(values)
    }

    // Smart split that respects escaped delimiters
    fn smart_split(s: &str) -> Result<Vec<String>, SegmentIdError> {
        let mut parts = Vec::new();
        let mut current = String::new();
        let mut escape_next = false;
        let chars: Vec<char> = s.chars().collect();
        let delimiter_chars: Vec<char> = Self::DELIMITER.chars().collect();

        let mut i = 0;
        while i < chars.len() {
            if escape_next {
                current.push(chars[i]);
                escape_next = false;
                i += 1;
                continue;
            }

            if chars[i] == '\\' {
                escape_next = true;
                current.push(chars[i]);
                i += 1;
                continue;
            }

            // Check if we're at a delimiter position
            if i + delimiter_chars.len() <= chars.len() {
                let potential_delimiter: String =
                    chars[i..i + delimiter_chars.len()].iter().collect();
                if potential_delimiter == Self::DELIMITER {
                    // Found an unescaped delimiter
                    parts.push(current);
                    current = String::new();
                    i += delimiter_chars.len();
                    continue;
                }
            }

            current.push(chars[i]);
            i += 1;
        }

        // Add the last part
        parts.push(current);

        Ok(parts)
    }

    pub fn get_version(&self) -> &str {
        &self.version
    }

    pub fn get_metadata(&self) -> &str {
        &self.metadata
    }

    pub fn is_hash_segment(&self) -> bool {
        matches!(self.segment_tag, SegmentTag::Hash { .. })
    }

    pub fn is_value_segment(&self) -> bool {
        matches!(self.segment_tag, SegmentTag::Value { .. })
    }

    pub fn get_columns(&self) -> Option<&ColumnDefinition> {
        match &self.segment_tag {
            SegmentTag::Hash { columns, .. } => Some(columns),
            SegmentTag::Value { columns, .. } => Some(columns),
            SegmentTag::Default => None,
        }
    }

    pub fn get_values(&self) -> Option<&Vec<String>> {
        match &self.segment_tag {
            SegmentTag::Value { values, .. } => Some(values),
            _ => None,
        }
    }

    pub fn get_bucket(&self) -> Option<&BucketInfo> {
        match &self.segment_tag {
            SegmentTag::Hash { bucket, .. } => Some(bucket),
            _ => None,
        }
    }

    pub fn get_num_buckets(&self) -> Option<&NumBuckets> {
        match &self.segment_tag {
            SegmentTag::Hash { num_buckets, .. } => Some(num_buckets),
            _ => None,
        }
    }
}

// ID Format: {version}|{type}|{composition_type}|{columns}|{bucket_or_values_or_idx}|{num_buckets_or_empty}|{metadata}
impl std::fmt::Display for SegmentId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match &self.segment_tag {
            SegmentTag::Default => write!(f, "_default_"),
            SegmentTag::Hash {
                columns,
                bucket,
                num_buckets,
            } => {
                write!(
                    f,
                    "{}|hash|{}|{}|{}|{}|{}",
                    Self::escape_string(&self.version),
                    columns.get_type_str(),
                    columns,
                    bucket,
                    num_buckets,
                    Self::escape_string(&self.metadata)
                )
            }
            SegmentTag::Value { columns, values } => {
                write!(
                    f,
                    "{}|value|{}|{}|{}||{}",
                    Self::escape_string(&self.version),
                    columns.get_type_str(),
                    columns,
                    Self::values_to_string(values),
                    Self::escape_string(&self.metadata)
                )
            }
        }
    }
}

impl std::str::FromStr for SegmentId {
    type Err = SegmentIdError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s == "_default_" {
            return Ok(SegmentId {
                version: "".to_string(),
                segment_tag: SegmentTag::Default,
                metadata: "".to_string(),
            });
        }

        // Split while respecting escaped delimiters
        let parts = Self::smart_split(s)?;

        if parts.len() != 7 {
            return Err(SegmentIdError::InvalidFormat(format!(
                "Expected 7 parts separated by '{}', got {}",
                Self::DELIMITER,
                parts.len()
            )));
        }

        let version = Self::unescape_string(&parts[0]);
        let type_str = &parts[1];
        let composition_type_str = &parts[2];
        let columns_str = &parts[3];
        let bucket_or_values = &parts[4];
        let num_buckets_or_empty = &parts[5];
        let metadata = Self::unescape_string(&parts[6]);

        let segment_tag = match type_str.as_str() {
            "hash" => {
                let columns = ColumnDefinition::from_str(columns_str)?;
                let bucket = BucketInfo::from_str(bucket_or_values)?;
                let num_buckets = NumBuckets::from_str(num_buckets_or_empty)?;

                // Validate composition type matches the column definition
                let expected_type = columns.get_type_str();
                if composition_type_str != expected_type {
                    return Err(SegmentIdError::InvalidFormat(format!(
                        "Composition type mismatch: expected '{}', got '{}'",
                        expected_type, composition_type_str
                    )));
                }

                SegmentTag::Hash {
                    columns,
                    bucket,
                    num_buckets,
                }
            }
            "value" => {
                let columns = ColumnDefinition::from_str(columns_str)?;
                let values = Self::string_to_values(bucket_or_values)?;

                // Validate composition type matches the column definition
                let expected_type = columns.get_type_str();
                if composition_type_str != expected_type {
                    return Err(SegmentIdError::InvalidFormat(format!(
                        "Composition type mismatch: expected '{}', got '{}'",
                        expected_type, composition_type_str
                    )));
                }

                SegmentTag::Value { columns, values }
            }
            _ => return Err(SegmentIdError::InvalidSegmentType(type_str.to_string())),
        };

        Ok(SegmentId {
            version,
            segment_tag,
            metadata,
        })
    }
}

#[cfg(test)]
mod tests {
    use std::str::FromStr;

    use super::*;

    #[test]
    fn test_segment_key_serialization() {
        let mut column_min_max = HashMap::new();
        column_min_max.insert(
            "id".to_string(),
            ColumnMinMaxValue {
                min: serde_json::Value::Number(serde_json::Number::from(1)),
                max: serde_json::Value::Number(serde_json::Number::from(1000)),
            },
        );
        column_min_max.insert(
            "name".to_string(),
            ColumnMinMaxValue {
                min: serde_json::Value::String("A".to_string()),
                max: serde_json::Value::String("Z".to_string()),
            },
        );

        let segment_key = SegmentInfo {
            oid: "3001".to_string(),
            version: 1,
            format_version: default_format_version(),
            kafka_info: KafkaInfo {
                topic: "T1_S1".to_string(),
                partition: 5,
            },
            column_min_max,
            reader: vec![],
            writer: "w1".to_string(),
            migration_source: None,
        };

        let json = serde_json::to_string_pretty(&segment_key).unwrap();
        println!("SegmentKey JSON:\n{}", json);

        let deserialized: SegmentInfo = serde_json::from_str(&json).unwrap();
        assert_eq!(segment_key.version, deserialized.version);
        assert_eq!(segment_key.oid, deserialized.oid);
        assert_eq!(
            segment_key.column_min_max.len(),
            deserialized.column_min_max.len()
        );
    }

    #[test]
    fn test_hash_single_segment() {
        let segment = SegmentId::new_hash_single(
            "v3".to_string(),
            "region".to_string(),
            5,
            12,
            "{metadata}".to_string(),
        );

        let id_str = segment.to_string();
        let parsed = SegmentId::from_str(&id_str).unwrap();
        assert_eq!(parsed, segment);
    }

    #[test]
    fn test_value_with_delimiter_in_data() {
        let values = vec![
            "data|with|pipes".to_string(),
            "normal data".to_string(),
            "more|pipes|here".to_string(),
        ];

        let segment = SegmentId::new_value_composite(
            "v3".to_string(),
            vec!["col1".to_string(), "col2".to_string(), "col3".to_string()],
            values,
            "{meta|data}".to_string(),
        );

        let id_str = segment.to_string();
        let parsed = SegmentId::from_str(&id_str).unwrap();
        assert_eq!(parsed, segment);
    }

    #[test]
    fn test_value_single_segment() {
        let segment = SegmentId::new_value_single(
            "v3".to_string(),
            "region".to_string(),
            "seoul|korea".to_string(),
            "{metadata}".to_string(),
        );

        let id_str = segment.to_string();
        let parsed = SegmentId::from_str(&id_str).unwrap();
        assert_eq!(parsed, segment);
    }

    #[test]
    fn test_new_format_with_composition_type() {
        // Test hash single segment with new format
        let segment = SegmentId::new_hash_single(
            "v1".to_string(),
            "id".to_string(),
            3,
            10,
            "test_meta".to_string(),
        );

        let id_str = segment.to_string();
        println!("Hash single format: {}", id_str);

        // Should be: v1|hash|single|id|3|10|test_meta
        let expected_parts = vec!["v1", "hash", "single", "id", "3", "10", "test_meta"];
        let actual_parts: Vec<&str> = id_str.split('|').collect();
        assert_eq!(actual_parts, expected_parts);

        let parsed = SegmentId::from_str(&id_str).unwrap();
        assert_eq!(parsed, segment);

        // Test value composite segment with new format
        let segment2 = SegmentId::new_value_composite(
            "v2".to_string(),
            vec!["col1".to_string(), "col2".to_string()],
            vec!["val1".to_string(), "val2".to_string()],
            "meta2".to_string(),
        );

        let id_str2 = segment2.to_string();
        println!("Value composite format: {}", id_str2);

        // Should be: v2|value|comp|col1+col2|["val1","val2"]||meta2
        let actual_parts2: Vec<&str> = id_str2.split('|').collect();
        assert_eq!(actual_parts2.len(), 7);
        assert_eq!(actual_parts2[0], "v2");
        assert_eq!(actual_parts2[1], "value");
        assert_eq!(actual_parts2[2], "comp");
        assert_eq!(actual_parts2[3], "col1+col2");
        assert_eq!(actual_parts2[5], ""); // empty num_buckets for value segments
        assert_eq!(actual_parts2[6], "meta2");

        let parsed2 = SegmentId::from_str(&id_str2).unwrap();
        assert_eq!(parsed2, segment2);
    }

    #[test]
    fn test_delimiter_comparison() {
        // Test with single pipes in data
        let values_with_single_pipes = vec!["path|to|file".to_string(), "normal".to_string()];

        let segment = SegmentId::new_value_composite(
            "v3".to_string(),
            vec!["col1".to_string(), "col2".to_string()],
            values_with_single_pipes,
            "meta|info".to_string(),
        );

        let id_str = segment.to_string();
        println!("Single pipe in data: {}", id_str);

        let parsed = SegmentId::from_str(&id_str).unwrap();
        assert_eq!(parsed, segment);

        // Test with double pipes in data
        let values_with_double_pipes = vec!["data||with||double".to_string(), "normal".to_string()];

        let segment2 = SegmentId::new_value_composite(
            "v3".to_string(),
            vec!["col1".to_string(), "col2".to_string()],
            values_with_double_pipes,
            "meta".to_string(),
        );

        let id_str2 = segment2.to_string();
        println!("Double pipe in data: {}", id_str2);

        let parsed2 = SegmentId::from_str(&id_str2).unwrap();
        assert_eq!(parsed2, segment2);
    }

    #[test]
    fn segment_id_from_str_rejects_invalid_format() {
        assert!(SegmentId::from_str("").is_err());
        assert!(SegmentId::from_str("not-a-segment-id").is_err());
        assert!(SegmentId::from_str("v1|hash|single|id|3|10").is_err());
    }
}
