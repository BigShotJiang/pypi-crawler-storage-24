pub mod api;
pub mod catalog;
pub mod docs;
pub mod result_set;

// Re-export API types at crate root for ergonomic imports
pub use api::*;
pub use result_set::{
    MultipleResults, ResultSet, ResultSetError, ResultSets, ResultWithMetrics, SingleResult,
};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cloud_storage_credentials_debug() {
        let creds_some = api::storage::CloudStorageCredentials {
            access_key: Some("my_access_key".to_string()),
            secret_key: Some("my_secret_key".to_string()),
        };
        let debug_str_some = format!("{:?}", creds_some);
        assert!(debug_str_some.contains("access_key: Some(\"******\")"));
        assert!(debug_str_some.contains("secret_key: Some(\"******\")"));
        assert!(!debug_str_some.contains("my_access_key"));
        assert!(!debug_str_some.contains("my_secret_key"));

        let creds_none = api::storage::CloudStorageCredentials {
            access_key: None,
            secret_key: None,
        };
        let debug_str_none = format!("{:?}", creds_none);
        assert!(debug_str_none.contains("access_key: None"));
        assert!(debug_str_none.contains("secret_key: None"));
    }

    #[test]
    fn test_cloud_storage_credentials_display() {
        let creds = api::storage::CloudStorageCredentials {
            access_key: Some("my_access_key".to_string()),
            secret_key: Some("my_secret_key".to_string()),
        };
        let display_str = format!("{}", creds);
        assert_eq!(
            display_str,
            "CloudStorageCredentials(access_key=******, secret_key=******)"
        );
    }
}
