//! Canonical result-set domain model shared across transports.

use std::sync::Arc;

use arrow_array::RecordBatch;
use arrow_ipc::writer::StreamWriter;
use arrow_schema::{Schema, SchemaRef};

use crate::api::common::RequestMetrics;

#[derive(Debug, Clone)]
pub struct ResultSet {
    schema: SchemaRef,
    record_batches: Vec<RecordBatch>,
}

#[derive(Debug, Clone)]
pub struct ResultSets {
    result_sets: Vec<ResultSet>,
}

#[derive(Debug, Clone)]
pub struct ResultWithMetrics<T> {
    result: T,
    metrics: Option<RequestMetrics>,
}

pub type SingleResult = ResultWithMetrics<ResultSet>;
pub type MultipleResults = ResultWithMetrics<ResultSets>;

impl ResultSet {
    pub fn try_new(record_batches: Vec<RecordBatch>) -> Result<Self, ResultSetError> {
        let schema = record_batches
            .first()
            .map(RecordBatch::schema)
            .ok_or(ResultSetError::EmptySingleResultSet)?;

        Ok(Self {
            schema,
            record_batches,
        })
    }

    pub fn new(schema: SchemaRef, record_batches: Vec<RecordBatch>) -> Self {
        Self {
            schema,
            record_batches,
        }
    }

    pub fn schema(&self) -> &SchemaRef {
        &self.schema
    }

    pub fn record_batches(&self) -> &[RecordBatch] {
        &self.record_batches
    }

    pub fn record_batches_mut(&mut self) -> &mut [RecordBatch] {
        &mut self.record_batches
    }

    pub fn into_record_batches(self) -> Vec<RecordBatch> {
        self.record_batches
    }

    pub fn into_parts(self) -> (SchemaRef, Vec<RecordBatch>) {
        (self.schema, self.record_batches)
    }

    pub fn num_resultsets(&self) -> u32 {
        1
    }

    pub fn resultset_batch_count(&self) -> u32 {
        self.record_batches.len() as u32
    }

    pub fn num_rows(&self) -> usize {
        self.record_batches.iter().map(RecordBatch::num_rows).sum()
    }

    pub fn empty_with_schema(schema: SchemaRef) -> Self {
        Self::new(schema.clone(), vec![RecordBatch::new_empty(schema)])
    }

    pub fn to_arrow_ipc(&self) -> Result<Vec<u8>, ResultSetError> {
        encode_record_batches_to_ipc(self.schema.clone(), &self.record_batches)
    }
}

impl ResultSets {
    pub fn new(result_sets: Vec<ResultSet>) -> Self {
        Self { result_sets }
    }

    pub fn empty() -> Self {
        Self {
            result_sets: Vec::new(),
        }
    }

    pub fn schema(&self) -> SchemaRef {
        self.result_sets
            .first()
            .map(|result_set| result_set.schema().clone())
            .unwrap_or_else(empty_schema)
    }

    pub fn result_sets(&self) -> &[ResultSet] {
        &self.result_sets
    }

    pub fn into_result_sets(self) -> Vec<ResultSet> {
        self.result_sets
    }

    pub fn into_parts(self) -> Vec<ResultSet> {
        self.result_sets
    }

    pub fn num_resultsets(&self) -> u32 {
        self.result_sets.len() as u32
    }

    pub fn resultset_batch_counts(&self) -> Vec<u32> {
        self.result_sets
            .iter()
            .map(ResultSet::resultset_batch_count)
            .collect()
    }

    pub fn iter_record_batches(&self) -> impl Iterator<Item = &RecordBatch> {
        self.result_sets
            .iter()
            .flat_map(|result_set| result_set.record_batches().iter())
    }

    pub fn into_flat_record_batches(self) -> Vec<RecordBatch> {
        self.result_sets
            .into_iter()
            .flat_map(ResultSet::into_record_batches)
            .collect()
    }

    pub fn to_arrow_ipc(&self) -> Result<Vec<u8>, ResultSetError> {
        if self.result_sets.is_empty() {
            return Ok(Vec::new());
        }
        let schema = self.schema();
        let mut writer = StreamWriter::try_new(Vec::new(), &schema)?;
        for record_batch in self.iter_record_batches() {
            writer.write(record_batch)?;
        }
        writer.finish()?;
        Ok(writer.into_inner()?)
    }
}

impl<T> ResultWithMetrics<T> {
    pub fn new(result: T, metrics: Option<RequestMetrics>) -> Self {
        Self { result, metrics }
    }

    pub fn with_metrics(mut self, metrics: Option<RequestMetrics>) -> Self {
        self.metrics = metrics;
        self
    }

    pub fn result(&self) -> &T {
        &self.result
    }

    pub fn into_result(self) -> T {
        self.result
    }

    pub fn metrics(&self) -> Option<&RequestMetrics> {
        self.metrics.as_ref()
    }

    pub fn into_metrics(self) -> Option<RequestMetrics> {
        self.metrics
    }

    pub fn into_parts(self) -> (T, Option<RequestMetrics>) {
        (self.result, self.metrics)
    }
}

pub fn empty_schema() -> SchemaRef {
    Arc::new(Schema::empty())
}

fn encode_record_batches_to_ipc(
    schema: SchemaRef,
    record_batches: &[RecordBatch],
) -> Result<Vec<u8>, ResultSetError> {
    let mut writer = StreamWriter::try_new(Vec::new(), &schema)?;
    for record_batch in record_batches {
        writer.write(record_batch)?;
    }
    writer.finish()?;
    Ok(writer.into_inner()?)
}

#[derive(Debug, thiserror::Error)]
pub enum ResultSetError {
    #[error("single result set requires at least one record batch")]
    EmptySingleResultSet,
    #[error(transparent)]
    Arrow(#[from] arrow_schema::ArrowError),
}

#[cfg(test)]
mod tests {
    use super::*;

    use arrow_array::{Int32Array, StringArray};
    use arrow_schema::{DataType, Field, Schema};

    fn sample_batch(values: [i32; 2]) -> RecordBatch {
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, false),
        ]));

        RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int32Array::from(values.to_vec())),
                Arc::new(StringArray::from(vec!["a", "b"])),
            ],
        )
        .expect("sample batch must build")
    }

    #[test]
    fn single_result_requires_non_empty_batches() {
        let error = ResultSet::try_new(Vec::new()).expect_err("empty batches must fail");
        assert!(matches!(error, ResultSetError::EmptySingleResultSet));
    }

    #[test]
    fn multiple_result_sets_tracks_batch_boundaries() {
        let first = ResultSet::try_new(vec![sample_batch([1, 2]), sample_batch([3, 4])])
            .expect("first resultset must build");
        let second =
            ResultSet::try_new(vec![sample_batch([5, 6])]).expect("second resultset must build");

        let result_sets = ResultSets::new(vec![first, second]);

        assert_eq!(result_sets.num_resultsets(), 2);
        assert_eq!(result_sets.resultset_batch_counts(), vec![2, 1]);
    }

    #[test]
    fn multiple_result_sets_arrow_ipc_round_trip_contains_all_batches() {
        let first = ResultSet::try_new(vec![sample_batch([1, 2]), sample_batch([3, 4])])
            .expect("first resultset must build");
        let second =
            ResultSet::try_new(vec![sample_batch([5, 6])]).expect("second resultset must build");

        let ipc = ResultSets::new(vec![first, second])
            .to_arrow_ipc()
            .expect("ipc encoding must succeed");
        let reader = arrow_ipc::reader::StreamReader::try_new(ipc.as_slice(), None)
            .expect("ipc reader must open");
        let decoded = reader
            .collect::<Result<Vec<_>, _>>()
            .expect("all record batches must decode");

        assert_eq!(decoded.len(), 3);
    }

    #[test]
    fn envelope_keeps_metrics_at_root() {
        let result_set = ResultSet::try_new(vec![sample_batch([1, 2])]).expect("resultset");
        let envelope = SingleResult::new(
            result_set,
            Some(RequestMetrics {
                elapsed_time: 0.25,
                rss_peak_bytes: Some(1024),
            }),
        );

        assert_eq!(envelope.metrics().map(|m| m.elapsed_time), Some(0.25));
        assert_eq!(envelope.result().resultset_batch_count(), 1);
    }

    #[test]
    fn empty_with_schema_creates_single_empty_batch() {
        let schema = sample_batch([1, 2]).schema();

        let result_set = ResultSet::empty_with_schema(schema.clone());

        assert_eq!(result_set.schema(), &schema);
        assert_eq!(result_set.resultset_batch_count(), 1);
        assert_eq!(result_set.num_rows(), 0);
        assert_eq!(result_set.record_batches()[0].num_rows(), 0);
    }
}
