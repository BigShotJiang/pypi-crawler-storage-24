use serde::{Deserialize, Serialize};
use utoipa::{IntoParams, ToSchema};

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SqlQueryRequest {
    /// SQL query to execute.
    #[schema(
        example = "SELECT inner_product(feature, [-0.011122962,-0.00063176895,0.0020679801]) as distance, video_id, video_title, timestamp FROM my_table order by distance limit 3"
    )]
    pub sql: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct SqlParameters {
    /// Name of the vector index to use. If it is not provided, vector index is not used.
    /// Only 'default' index is supported currently.
    #[param(default = "default")]
    pub index_name: Option<String>,
    /// If true, vector index is not used.
    #[param(default = "false")]
    pub no_use_index: Option<bool>,
}
