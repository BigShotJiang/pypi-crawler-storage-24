use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::api::{SparseMetadata, SparseSearchParameters, SparseVectorSearchConfig};

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum QueryVectors {
    /// Dense vectors represented as fixed-size lists of floats
    Dense {
        /// Dense vectors represented as fixed-size lists of floats
        #[schema(example = "[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]")]
        vectors: Vec<Vec<f32>>,
        /// Optional parameters to fine-tune dense vector search
        #[schema(example = "{\"ef_search\": 256}")]
        parameters: Option<DenseSearchParameters>,
    },
    /// Sparse vectors represented as strings
    Sparse {
        /// Sparse vectors represented as strings (e.g. "1:0.5 2:0.3")
        #[schema(example = "[\"1:0.5 2:0.3\", \"1:0.2 3:0.4\"]")]
        vectors: Vec<String>,
        /// Parameters for sparse model (BM25): k (term frequency weight), b (length penalty)
        #[schema(example = "{\"k\": 1.2, \"b\": 0.75}")]
        parameters: Option<SparseSearchParameters>,
        /// Optional metadata for sparse vector search (ignored for dense)
        /// Example: {"N": 50001, "avgdl": 200.51, "df": ["205:30001 101:15000", "205:25000 101:12000"]}
        #[schema(
            example = "{\"N\": 50001, \"avgdl\": 200.51, \"df\": [\"205:30001 101:15000\", \"205:25000 101:12000\"]}"
        )]
        metadata: Option<SparseMetadata>,
    },
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct VectorSearchRequest {
    /// Number of top results to return from the vector search. Must be greater than 0.
    #[schema(example = "3")]
    pub top_k: i32,
    /// Query specification. Exactly one of "dense" or "sparse" must be provided at the top-level.
    /// Examples:
    /// {"dense": {"vectors": [[0.1, 0.2, 0.3]], "parameters": {"ef_search": 128}}}
    /// {"sparse": {"vectors": ["1:0.5 2:0.3"], "parameters": {"k": 1.2, "b": 0.75}, "metadata": {"N": 50001, "avgdl": 200.51, "df": ["205:30001 101:15000"]}}}
    #[serde(flatten)]
    pub query: QueryVectors,
    /// Columns to include in the result set. Uses SQL projection syntax (e.g. "col1, col2"). If not specified, all columns will be returned.
    #[schema(
        default = "*",
        example = "video_title , channel_name, video_id, timestamp, distance"
    )]
    pub projection: Option<String>,
    /// SQL WHERE clause to filter the results. If not specified, no filtering will be applied.
    /// The filter condition must be a valid SQL expression that evaluates to a boolean value.
    /// For example: "video_id < 3000" or "category = 'music' AND views > 1000"
    #[schema(default = "", example = "video_id < 3000")]
    pub filter: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct VectorSearchExactKnnRequest {
    /// Number of top results to return from the vector search. Must be greater than 0.
    #[schema(example = "3")]
    pub top_k: i32,
    /// Query specification. Exactly one of "dense" or "sparse" must be provided at the top-level.
    #[serde(flatten)]
    pub query: QueryVectors,
    /// Columns to include in the result set. Uses SQL projection syntax (e.g. "col1, col2"). If not specified, all columns will be returned.
    #[schema(
        default = "*",
        example = "video_title , channel_name, video_id, timestamp, distance"
    )]
    pub projection: Option<String>,
    /// SQL WHERE clause to filter the results. If not specified, no filtering will be applied.
    /// The filter condition must be a valid SQL expression that evaluates to a boolean value.
    /// For example: "video_id < 3000" or "category = 'music' AND views > 1000"
    #[schema(default = "", example = "video_id < 3000")]
    pub filter: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DenseSearchParameters {
    /// Size of the dynamic candidate list during search. A larger value will result in more accurate but slower searches.
    #[schema(default = "Same value as top_k", example = "1000")]
    pub ef_search: Option<u32>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DenseVectorSearchConfig {
    /// Column name containing dense vectors
    #[schema(example = "dense_vector")]
    pub column: String,
    /// Dense vector query
    #[schema(example = "[[0.1, 0.2, 0.3, 0.768], [0.5, 0.6, 0.7, 0.8]]")]
    pub vectors: Vec<Vec<f32>>,
    /// Search parameters for dense vector search
    pub parameters: Option<DenseSearchParameters>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct FusionConfig {
    /// Type of fusion algorithm to use
    #[schema(example = "rrf")]
    #[serde(rename = "type")]
    pub r#type: String,
    /// Fusion parameters
    pub parameters: Option<FusionParameters>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct FusionParameters {
    /// RRF parameter k value
    #[schema(example = "60")]
    pub k: Option<u32>,
    /// Weight parameter alpha for dense search (0.0 to 1.0). Sparse weight is automatically (1 - alpha). Default is 0.5
    #[schema(example = "0.7")]
    pub alpha: Option<f32>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct HybridVectorSearchRequest {
    /// Number of top results to return from the hybrid search. Must be greater than 0.
    #[schema(example = "100")]
    pub top_k: i32,
    /// Dense vector search configuration
    pub dense: DenseVectorSearchConfig,
    /// Sparse vector search configuration
    pub sparse: SparseVectorSearchConfig,
    /// Fusion configuration for combining results
    pub fusion: FusionConfig,
    /// Columns to include in the result set. Uses SQL projection syntax (e.g. "col1, col2"). If not specified, all columns will be returned.
    #[schema(default = "*", example = "id, name")]
    pub projection: Option<String>,
    /// SQL WHERE clause to filter the results. If not specified, no filtering will be applied.
    #[schema(default = "", example = "id < 1000")]
    pub filter: Option<String>,
}
