use serde::{Deserialize, Serialize};
use utoipa::{IntoParams, ToSchema};

use super::data::FileFormat;

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum StorageType {
    Local,
    Aws,
    S3,
    Gcp,
    Azure,
    Ceph,
    Minio,
    S3Compatible,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct StorageConfig {
    /// Storage type of the file to read. When it is not provided, it is treated as a local file. Currently, only 'AWS', 'S3', 'CEPH', 'MINIO', and 'S3_COMPATIBLE' are supported.
    #[schema(
        default = "LOCAL",
        examples("AWS", "S3", "CEPH", "MINIO", "S3_COMPATIBLE")
    )]
    pub storage_type: Option<StorageType>,
    /// Bucket name of cloud storage.
    pub bucket: Option<String>,
    /// Credentials to access cloud storage. When it is not provided, try to use the credentials in the configuration such as environment variables.
    pub credentials: Option<CloudStorageCredentials>,
    /// Options for Cloud Storage.
    pub options: Option<CloudStorageOptions>,
}

impl std::default::Default for StorageConfig {
    fn default() -> Self {
        Self {
            storage_type: Some(StorageType::Local),
            bucket: None,
            credentials: None,
            options: None,
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct Paths {
    /// Path to the file or directory to read or write.
    #[schema(example = json!(["/Path/to/data/file1.parquet", "/Path/to/data/file2.parquet"]))]
    pub paths: Vec<String>,
    /// Storage configuration.
    #[schema(example = json!({
        "storage_type": "AWS",
        "bucket": "my-bucket",
        "credentials": {
            "access_key": "my-access-key",
            "secret_key": "my-secret-key"
        },
        "options": {
            "region": "us-east-1",
            "endpoint": "https://s3.us-east-1.amazonaws.com"
        }
    }))]
    pub storage_config: Option<StorageConfig>,
}

#[derive(Serialize, Deserialize, Clone, ToSchema)]
pub struct CloudStorageCredentials {
    /// Access key of cloud storage.
    pub access_key: Option<String>,
    /// Secret key of cloud storage.
    pub secret_key: Option<String>,
}

impl std::fmt::Debug for CloudStorageCredentials {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("CloudStorageCredentials")
            .field("access_key", &self.access_key.as_ref().map(|_| "******"))
            .field("secret_key", &self.secret_key.as_ref().map(|_| "******"))
            .finish()
    }
}

impl std::fmt::Display for CloudStorageCredentials {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "CloudStorageCredentials(access_key=******, secret_key=******)"
        )
    }
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct CloudStorageOptions {
    /// Region of cloud storage.
    pub region: Option<String>,
    /// Endpoint of cloud storage.
    pub endpoint: Option<String>,
    /// Whether to use virtual hosted style request.
    /// Virtual hosted style request: https://<bucket>.s3.<region>.amazonaws.com/<key>
    /// Path style request: https://s3.<region>.amazonaws.com/<bucket>/<key>
    #[schema(default = "false")]
    pub virtual_hosted_style: Option<bool>,
    /// Whether to allow HTTP requests.
    #[schema(default = "false")]
    pub allow_http: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct BatchInsertQueryParams {
    /// Format of the file to insert. Parquet is the default format. "Parquet", "Jsonl" are supported.
    #[param(inline, default = "Parquet")]
    pub format: Option<FileFormat>,
    /// Maximum number of rows in each record batch produced by the reader.
    /// This controls the reader's record batch size, not the final insert batch or segment size.
    #[param(default = "64")]
    pub reader_batch_size: Option<usize>,
    /// Maximum number of files to process concurrently. Defaults to 2 files.
    #[param(default = "2")]
    pub max_concurrent_files: Option<usize>,
    /// Whether to include detailed performance metrics (such as peak memory usage) in the response.
    /// Defaults to false for better performance. Note that peak memory measurements may be influenced by concurrent API operations.
    #[param(default = "false")]
    pub include_metrics: Option<bool>,
}

#[derive(Debug, ToSchema)]
pub struct BatchInsertMultiPartForm {
    /// File to insert.
    #[schema(value_type = String, format = Binary, content_media_type = "application/octet-stream")]
    pub file: String,
}
