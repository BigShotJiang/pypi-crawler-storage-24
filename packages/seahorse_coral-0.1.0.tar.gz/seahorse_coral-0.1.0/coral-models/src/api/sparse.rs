use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

/// Errors that can occur during sparse parameter validation
#[derive(Debug, Clone)]
pub enum SparseParameterError {
    InvalidBParameter { value: f32 },
    InvalidKParameter { value: f32 },
}

impl std::fmt::Display for SparseParameterError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SparseParameterError::InvalidBParameter { value } => {
                write!(f, "BM25 parameter b must be in [0, 1], got {}", value)
            }
            SparseParameterError::InvalidKParameter { value } => {
                write!(f, "BM25 parameter k must be > 0, got {}", value)
            }
        }
    }
}

impl std::error::Error for SparseParameterError {}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SparseMetadata {
    /// Total number of documents (N)
    #[schema(example = "50001")]
    #[serde(rename = "N")]
    pub n: u64,
    /// Average document length (avgdl)
    #[schema(example = "200.51")]
    pub avgdl: f32,
    /// Term document frequencies in format "term_id:df term_id:df ..."
    #[schema(example = r#"["205:30001 101:15000", "205:25000 101:12000"]"#)]
    pub df: Vec<String>,
}

/// Default BM25 parameter values
pub const DEFAULT_BM25_K: f32 = 1.2;
pub const DEFAULT_BM25_B: f32 = 0.75;

/// Maximum supported dimension (inclusive) for sparse vectors.
///
/// This is interpreted as an inclusive upper bound on `term_id`:
/// `0 <= term_id <= MAX_SPARSE_VECTOR_DIM`.
pub const MAX_SPARSE_VECTOR_DIM: u64 = u64::MAX;

/// BM25 (Best Matching 25) sparse search parameters
///
/// BM25 is a ranking function used by search engines to estimate the relevance
/// of documents to a given search query. It is a probabilistic retrieval model
/// based on the Binary Independence Model.
///
/// # Algorithm Formula
///
/// The BM25 score for a document D given query Q is calculated as:
///
/// ```text
/// score(D,Q) = Σ IDF(qi) * (f(qi,D) * (k1 + 1)) / (f(qi,D) + k1 * (1 - b + b * |D|/avgdl))
/// ```
///
/// Where:
/// - `f(qi,D)` = frequency of term qi in document D
/// - `|D|` = length of document D in words
/// - `avgdl` = average document length in the collection
/// - `IDF(qi)` = inverse document frequency of term qi
/// - `k1` = controls term frequency saturation (typically 1.2-2.0)
/// - `b` = controls document length normalization (typically 0.75)
///
/// # Parameter Guidelines
///
/// ## k parameter (Term Frequency Saturation)
/// - **Range**: > 0.0 (typically 1.2-2.0)
/// - **Default**: 1.2
/// - **Effect**:
///   - Higher values (>1.2): More weight to term frequency
///   - Lower values (<1.2): Less impact of term frequency
///   - Very high values: Linear relationship with term frequency
///   - Very low values: Almost binary (term present/absent)
///
/// ## b parameter (Document Length Normalization)
/// - **Range**: 0.0-1.0
/// - **Default**: 0.75
/// - **Effect**:
///   - 0.0: No length normalization (favors longer documents)
///   - 1.0: Full length normalization (heavily penalizes longer documents)
///   - 0.75: Balanced approach (recommended for most use cases)
///
/// # Examples
///
/// ```rust
/// # use coral_models::api::sparse::SparseSearchParameters;
/// // Conservative settings (less term frequency impact)
/// let conservative = SparseSearchParameters { k: Some(0.8), b: Some(0.75) };
///
/// // Aggressive settings (more term frequency impact)
/// let aggressive = SparseSearchParameters { k: Some(2.0), b: Some(0.5) };
///
/// // Default BM25 settings
/// let default = SparseSearchParameters { k: Some(1.2), b: Some(0.75) };
/// ```
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SparseSearchParameters {
    /// BM25 k1 parameter: controls term frequency saturation
    /// Higher values (>1.2) give more weight to term frequency
    /// Lower values (<1.2) reduce the impact of term frequency
    /// Typical range: 1.2-2.0, Default: 1.2
    #[schema(example = "1.2")]
    pub k: Option<f32>,
    /// BM25 b parameter: controls document length normalization (0..1)
    /// 0 = no length normalization, 1 = full length normalization
    /// Typical value: 0.75 (balanced approach)
    #[schema(example = "0.75")]
    pub b: Option<f32>,
}

/// Validated sparse search parameters - guaranteed to be valid
#[derive(Debug, Clone)]
pub struct ValidatedSparseSearchParameters {
    pub k: Option<f32>,
    pub b: Option<f32>,
}

impl SparseSearchParameters {
    /// Validate BM25 parameters with structured error types
    /// Returns specific error type if validation fails, None if valid
    pub fn validate(&self) -> Result<(), SparseParameterError> {
        if let Some(b) = self.b {
            if !(0.0..=1.0).contains(&b) {
                return Err(SparseParameterError::InvalidBParameter { value: b });
            }
        }

        if let Some(k) = self.k {
            if k <= 0.0 {
                return Err(SparseParameterError::InvalidKParameter { value: k });
            }
        }

        Ok(())
    }

    /// Convert to validated parameters after checking validity
    /// This eliminates the need for repeated validation
    pub fn validated(self) -> Result<ValidatedSparseSearchParameters, SparseParameterError> {
        self.validate()?;
        Ok(ValidatedSparseSearchParameters {
            k: self.k,
            b: self.b,
        })
    }
}

impl ValidatedSparseSearchParameters {
    /// Get k parameter with default fallback
    pub fn k_or_default(&self) -> f32 {
        self.k.unwrap_or(DEFAULT_BM25_K)
    }

    /// Get b parameter with default fallback
    pub fn b_or_default(&self) -> f32 {
        self.b.unwrap_or(DEFAULT_BM25_B)
    }
}

impl std::convert::TryFrom<SparseSearchParameters> for ValidatedSparseSearchParameters {
    type Error = SparseParameterError;

    fn try_from(value: SparseSearchParameters) -> Result<Self, Self::Error> {
        value.validated()
    }
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SparseVectorSearchConfig {
    /// Column name containing sparse vectors
    #[schema(example = "sparse_vector")]
    pub column: String,
    /// Sparse vector query in format "index:value index:value"
    #[schema(example = "[\"0:21 2:20 5:13.5\", \"1:0.5 2:0.3 5:0.8\"]")]
    pub vectors: Vec<String>,
    // BM25 model is used when parameters or metadata are provided
    /// Parameters for sparse model (BM25): k and b
    pub parameters: Option<SparseSearchParameters>,
    /// Metadata used by sparse model (BM25)
    pub metadata: Option<SparseMetadata>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sparse_search_parameters_validation() {
        // Valid parameters
        let valid_params = SparseSearchParameters {
            k: Some(1.2),
            b: Some(0.75),
        };
        assert!(valid_params.validate().is_ok());

        // Valid boundary values
        let boundary_params = SparseSearchParameters {
            k: Some(0.1),
            b: Some(0.0),
        };
        assert!(boundary_params.validate().is_ok());

        let boundary_params2 = SparseSearchParameters {
            k: Some(10.0),
            b: Some(1.0),
        };
        assert!(boundary_params2.validate().is_ok());

        // Invalid b parameter (too high)
        let invalid_b_high = SparseSearchParameters {
            k: Some(1.2),
            b: Some(1.5),
        };
        assert!(invalid_b_high.validate().is_err());

        // Invalid b parameter (negative)
        let invalid_b_neg = SparseSearchParameters {
            k: Some(1.2),
            b: Some(-0.1),
        };
        assert!(invalid_b_neg.validate().is_err());

        // Invalid k parameter (zero)
        let invalid_k_zero = SparseSearchParameters {
            k: Some(0.0),
            b: Some(0.75),
        };
        assert!(invalid_k_zero.validate().is_err());

        // Invalid k parameter (negative)
        let invalid_k_neg = SparseSearchParameters {
            k: Some(-1.0),
            b: Some(0.75),
        };
        assert!(invalid_k_neg.validate().is_err());

        // None values should be valid
        let none_params = SparseSearchParameters { k: None, b: None };
        assert!(none_params.validate().is_ok());
    }

    #[test]
    fn test_validated_sparse_params_try_from() {
        let params = SparseSearchParameters {
            k: Some(1.2),
            b: Some(0.75),
        };
        let validated: Result<ValidatedSparseSearchParameters, _> = params.try_into();
        assert!(validated.is_ok());

        let invalid = SparseSearchParameters {
            k: Some(0.0),
            b: Some(0.75),
        };
        let validated_err: Result<ValidatedSparseSearchParameters, _> = invalid.try_into();
        assert!(validated_err.is_err());
    }
}
