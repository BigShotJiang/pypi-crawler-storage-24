use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SingleResultSetResponse {
    /// Schema of the resultset.
    pub schema: serde_json::Value,
    /// Data of the single resultset in JSON format. Each row is represented as a JSON object in an JSON array.
    pub data: serde_json::Value,
    /// Request metrics such as elapsed time and optional peak memory.
    pub metrics: Option<RequestMetrics>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct MultipleResultSetResponse {
    /// Schema of the resultset
    pub schema: serde_json::Value,
    /// Number of resultsets
    pub num_resultsets: u32,
    /// Data of multiple resultsets. Each element is a JSON array representing one resultset.
    pub data: Vec<serde_json::Value>,
    /// Request metrics such as elapsed time and optional peak memory.
    pub metrics: Option<RequestMetrics>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RequestMetrics {
    /// Elapsed time in seconds for handling the request.
    pub elapsed_time: f32,
    /// Peak resident memory observed during the request (bytes). Present when metrics are included.
    pub rss_peak_bytes: Option<u64>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct VoidResponse {}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct LogLevel {
    /// Log level. 'trace', 'debug', 'info', 'warning', 'error' are valid log levels.
    #[schema(examples("trace", "debug", "info", "warning", "error"))]
    pub level: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct LogConfig {
    /// Output sink combination for logs.
    /// - `stdout`: console only (default)
    /// - `file`: file only
    /// - `both`: console and file
    #[schema(examples("stdout", "file", "both"))]
    pub output_mode: String,
    /// Console (stdio) target for the console sink.
    /// - `stdout` (default)
    /// - `stderr`
    #[schema(examples("stdout", "stderr"))]
    pub stdio_target: String,
    /// Active file path used by the file sink when enabled.
    /// The parent directory will be created on demand.
    #[schema(example = "./logs/coral.log")]
    pub file_path: String,
    /// Instance identifier inserted into the filename (e.g., pod or host name).
    /// If empty, no identifier is inserted. Defaults to hostname in K8s (HOSTNAME env).
    #[schema(example = "myapp-6c9b9f7d8f-abcde")]
    pub file_instance_id: String,
    /// Maximum active file size in megabytes before rotation occurs.
    #[schema(example = 10)]
    pub max_size_mb: u64,
    /// Number of rotated files to retain. When exceeded, the oldest is removed.
    #[schema(example = 10)]
    pub max_files: usize,
    /// Rotation filename suffix policy for rotated files.
    /// - `number`: .001, .002, ... (zero-padded width 3; width grows when `max_files >= 1000`)
    /// - `timestamp`: .YYYY-mm-ddTHH-MM-SS
    /// - `number_timestamp`: .NNN_YYYY-mm-ddTHH-MM-SS
    #[schema(examples("number", "timestamp", "number_timestamp"))]
    pub suffix_mode: String,
    /// Timezone used when rendering timestamps in rotated filenames.
    /// - `utc` (default) | `local`
    #[schema(examples("utc", "local"))]
    pub timestamp_tz: String,
    /// Filename-safe timestamp format used for the suffix.
    /// Defaults to `%Y-%m-%dT%H-%M-%S%.3fZ`.
    #[schema(example = "%Y-%m-%dT%H-%M-%S%.3fZ")]
    pub timestamp_format: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct LogConfigUpdate {
    /// Optional new output sink combination. If omitted, remains unchanged.
    /// - `stdout` | `file` | `both`
    #[schema(examples("stdout", "file", "both"))]
    pub output_mode: Option<String>,
    /// Optional new stdio target for console sink.
    /// - `stdout` | `stderr`
    #[schema(examples("stdout", "stderr"))]
    pub stdio_target: Option<String>,
    /// Optional new file path for the file sink.
    /// Takes effect immediately for subsequent writes; directory is created if missing.
    #[schema(example = "/var/log/coral/app.log")]
    pub file_path: Option<String>,
    /// Optional instance identifier to insert into filenames (before extension).
    /// Use empty string to disable.
    #[schema(example = "myapp-6c9b9f7d8f-abcde")]
    pub file_instance_id: Option<String>,
    /// Optional new max size (MB) before rotation.
    #[schema(example = 10)]
    pub max_size_mb: Option<u64>,
    /// Optional new retention count for rotated files.
    #[schema(example = 10)]
    pub max_files: Option<usize>,
    /// Optional new suffix policy.
    /// - `number` | `timestamp` | `number_timestamp`
    #[schema(examples("number", "timestamp", "number_timestamp"))]
    pub suffix_mode: Option<String>,
    /// Optional new timestamp timezone for suffix.
    /// - `utc` | `local`
    #[schema(examples("utc", "local"))]
    pub timestamp_tz: Option<String>,
    /// Optional new timestamp format for suffix.
    #[schema(example = "%Y-%m-%dT%H-%M-%S%.3fZ")]
    pub timestamp_format: Option<String>,
}
