use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

// =============================================================================
// External Schema (Create Table)
// =============================================================================

/// Maximum supported dimension for a dense vector column.
pub const MAX_DENSE_VECTOR_DIM: u32 = 65_535;

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TableConfigurations {
    /// Active set size limit
    #[serde(skip_serializing_if = "Option::is_none")]
    pub active_set_size_limit: Option<i32>,
    /// Max threads for indexing/search
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_threads: Option<i32>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TablePlacement {
    /// Assigned nodes for table (optional)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub assigned_nodes: Option<crate::api::table::AssignedNodes>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CreateTableRequest {
    /// Table name
    pub table_name: String,
    /// Column definitions
    pub columns: Vec<Column>,
    /// Primary key columns (optional)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub primary_key: Option<Vec<String>>,
    /// Segmentation configuration (optional)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation: Option<ExternalSegmentation>,
    /// Index configurations (optional)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub indexes: Option<Vec<ExternalIndex>>,
    /// Performance and tuning configurations (optional)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub configurations: Option<TableConfigurations>,
    /// Data placement and node assignment (optional)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub placement: Option<TablePlacement>,
}

// ----------------------- Columns & Types -----------------------

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
#[serde(try_from = "ColumnSerde")]
pub struct Column {
    pub name: String,
    /// Data type of the column. In case of `VectorType`, `name` accepts both `DENSE_VECTOR` and alias `VECTOR` for dense vector.
    #[serde(rename = "type")]
    pub r#type: ColumnType,
    /// Whether the column is nullable.
    ///
    /// - If omitted (or provided as null), defaults to:
    ///   - Scalar type: true
    ///   - Vector type: false
    ///
    /// Note: even if this is set to true for Vector type, the server may reject it at validation time.
    #[schema(required = false, nullable = true)]
    pub nullable: bool,
    /// Optional maximum length constraint for STRING columns.
    ///
    /// The limit is interpreted as the number of UTF-8 bytes (i.e., `value.len()`).
    /// If omitted or null, no length constraint is applied.
    #[serde(skip_serializing_if = "Option::is_none")]
    #[schema(required = false, nullable = true, example = 256)]
    pub max_length: Option<u32>,
}

#[derive(Debug, Deserialize)]
struct ColumnSerde {
    name: String,
    #[serde(rename = "type")]
    r#type: ColumnType,
    #[serde(default)]
    nullable: Option<bool>,
    #[serde(default)]
    max_length: Option<u32>,
}

impl TryFrom<ColumnSerde> for Column {
    type Error = String;

    fn try_from(value: ColumnSerde) -> Result<Self, Self::Error> {
        let default_nullable = matches!(value.r#type, ColumnType::Scalar(_));
        Ok(Self {
            name: value.name,
            r#type: value.r#type,
            nullable: value.nullable.unwrap_or(default_nullable),
            max_length: value.max_length,
        })
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
#[serde(untagged)]
pub enum ColumnType {
    /// Scalar types (non-parameterized)
    Scalar(ScalarType),
    /// VECTOR type with parameters
    Vector(VectorType),
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ScalarType {
    Int64,
    Float64,
    Bool,
    String,
}

/// Vector type
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
#[serde(tag = "name", rename_all = "SCREAMING_SNAKE_CASE")]
pub enum VectorType {
    #[serde(alias = "VECTOR")]
    DenseVector {
        /// Element type of the dense vector
        element: VectorElement,
        /// Dimension of the dense vector (1..=65535)
        #[schema(minimum = 1, maximum = 65535, example = 768)]
        dim: u32,
    },
    SparseVector,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum VectorElement {
    Float32,
}

// ----------------------- Segmentation -----------------------

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ExternalSegmentation {
    /// Segmentation strategy: "value" | "hash"
    pub strategy: SegmentationStrategy,
    /// Column names for segmentation
    pub columns: Vec<String>,
    /// Number of buckets (required for hash)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub buckets: Option<u32>,
    /// Composition: "single" | "hierarchical" | "composite"
    #[serde(skip_serializing_if = "Option::is_none")]
    pub composition: Option<SegmentationComposition>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum SegmentationStrategy {
    Value,
    Hash,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum SegmentationComposition {
    Single,
    Hierarchical,
    Composite,
}

// ----------------------- Indexes -----------------------

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ExternalIndex {
    /// Index type: HNSW | INVERTED | DISKBASED (case-insensitive)
    pub r#type: String,
    /// Target column name (single column)
    pub column: String,
    /// Parameters depend on index type
    #[serde(skip_serializing_if = "Option::is_none")]
    pub params: Option<IndexParams>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema, Default)]
#[allow(non_snake_case)]
pub struct IndexParams {
    /// "l2" | "ip" | "cosine" (normalized to "l2space" | "ipspace" | "cosinespace")
    #[serde(skip_serializing_if = "Option::is_none")]
    pub space: Option<String>,
    /// HNSW only
    #[serde(skip_serializing_if = "Option::is_none")]
    pub ef_construction: Option<u32>,
    /// HNSW only
    #[serde(skip_serializing_if = "Option::is_none")]
    pub M: Option<u32>,
    /// INVERTED only
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sparse_model: Option<String>,
}

// ----------------------- Tests -----------------------
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_serde_column_nullable_defaults_by_type_when_missing_or_null() {
        // Scalar: missing -> true
        let col: Column = serde_json::from_str(r#"{"name":"id","type":"INT64"}"#).unwrap();
        assert!(col.nullable);

        // Scalar: null -> true (treated same as missing)
        let col: Column =
            serde_json::from_str(r#"{"name":"id","type":"INT64","nullable":null}"#).unwrap();
        assert!(col.nullable);

        // Vector: missing -> false
        let col: Column = serde_json::from_str(
            r#"{"name":"emb","type":{"name":"VECTOR","element":"FLOAT32","dim":3}}"#,
        )
        .unwrap();
        assert!(!col.nullable);

        // Vector: null -> false (treated same as missing)
        let col: Column = serde_json::from_str(
            r#"{"name":"emb","type":{"name":"VECTOR","element":"FLOAT32","dim":3},"nullable":null}"#,
        )
        .unwrap();
        assert!(!col.nullable);

        // Sparse vector: missing -> false
        let col: Column =
            serde_json::from_str(r#"{"name":"emb","type":{"name":"SPARSE_VECTOR"}}"#).unwrap();
        assert!(!col.nullable);

        // Sparse vector: null -> false (treated same as missing)
        let col: Column = serde_json::from_str(
            r#"{"name":"emb","type":{"name":"SPARSE_VECTOR"},"nullable":null}"#,
        )
        .unwrap();
        assert!(!col.nullable);
    }

    #[test]
    fn test_serde_create_table_request_with_configurations_and_placement() {
        let req = CreateTableRequest {
            table_name: "docs".to_string(),
            columns: vec![
                Column {
                    name: "id".to_string(),
                    r#type: ColumnType::Scalar(ScalarType::Int64),
                    nullable: false,
                    max_length: None,
                },
                Column {
                    name: "title".to_string(),
                    r#type: ColumnType::Scalar(ScalarType::String),
                    nullable: true,
                    max_length: None,
                },
            ],
            primary_key: Some(vec!["id".to_string()]),
            segmentation: None,
            indexes: None,
            configurations: Some(TableConfigurations {
                active_set_size_limit: Some(123),
                max_threads: Some(8),
            }),
            placement: Some(TablePlacement {
                assigned_nodes: Some(crate::api::table::AssignedNodes {
                    writer_nodes: vec!["node-1".to_string()],
                    reader_nodes: vec!["node-1".to_string(), "node-2".to_string()],
                }),
            }),
        };

        let json = serde_json::to_value(&req).expect("serialize");
        // top-level fields should not be present
        assert!(json.get("active_set_size_limit").is_none());
        assert!(json.get("max_threads").is_none());
        // configurations object present
        let cfg = json
            .get("configurations")
            .and_then(|v| v.as_object())
            .expect("configurations present");
        assert_eq!(
            cfg.get("active_set_size_limit").and_then(|v| v.as_i64()),
            Some(123)
        );
        assert_eq!(cfg.get("max_threads").and_then(|v| v.as_i64()), Some(8));
        // placement.assigned_nodes present
        let placement = json
            .get("placement")
            .and_then(|v| v.as_object())
            .expect("placement present");
        let assigned = placement
            .get("assigned_nodes")
            .and_then(|v| v.as_object())
            .expect("assigned_nodes present");
        assert_eq!(
            assigned
                .get("writer_nodes")
                .and_then(|v| v.as_array())
                .map(|a| a.len()),
            Some(1)
        );
        assert_eq!(
            assigned
                .get("reader_nodes")
                .and_then(|v| v.as_array())
                .map(|a| a.len()),
            Some(2)
        );
    }

    #[test]
    fn test_serde_create_table_request_omits_empty_optionals() {
        let req = CreateTableRequest {
            table_name: "docs".to_string(),
            columns: vec![],
            primary_key: None,
            segmentation: None,
            indexes: None,
            configurations: None,
            placement: None,
        };
        let json = serde_json::to_value(&req).expect("serialize");
        assert!(json.get("configurations").is_none());
        assert!(json.get("placement").is_none());
    }
}
