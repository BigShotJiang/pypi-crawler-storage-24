use serde::{Deserialize, Serialize};
use utoipa::{IntoParams, ToSchema};

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct AssignedNodes {
    /// Writer nodes for inserting data into the table.
    pub writer_nodes: Vec<String>,
    /// Reader nodes for querying data from the table.
    pub reader_nodes: Vec<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct CreateTableResponse {
    /// Name of the table created.
    pub table_name: String,
    /// Object ID of the table.
    pub oid: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DeleteTableResponse {
    /// Name of the table deleted.
    pub table_name: String,
    /// Object ID of the table.
    pub oid: String,
}

/// Flush status returned by Seahorse node
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "lowercase")]
pub enum FlushStatus {
    Success,
    Failed,
    Skipped,
    Partial,
}

/// Response from Seahorse TABLE FLUSH command (per writer node)
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TableFlushResponse {
    /// Overall flush status
    #[schema(example = "success")]
    pub status: FlushStatus,
    /// Successfully flushed segment IDs
    #[schema(example = json!(["v1|hash|single|pk|0|2|"]))]
    pub flushed: Vec<String>,
    /// Failed segment IDs
    #[schema(example = json!([]))]
    pub failed: Vec<String>,
    /// Skipped segment IDs
    #[schema(example = json!([]))]
    pub skipped: Vec<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct TableResponse {
    /// Name of the table.
    pub table_name: String,
    // ---------------- External (default) ----------------
    /// External columns (present when internal=false)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub columns: Option<Vec<crate::api::schema::Column>>,
    /// External primary key (present when internal=false)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub primary_key: Option<Vec<String>>,
    /// External segmentation (present when internal=false)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation: Option<crate::api::schema::ExternalSegmentation>,
    /// External indexes (present when internal=false)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub indexes: Option<Vec<crate::api::schema::ExternalIndex>>,
    /// Configurations (present for both modes when available)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub configurations: Option<crate::api::schema::TableConfigurations>,
    // ---------------- Internal schema (internal_schema=true) ----------------
    /// Internal Arrow schema of the table. When internal_schema=true: Arrow schema only.
    #[schema(value_type = crate::docs::arrow_schema::ArrowSchema, nullable)]
    pub schema: Option<arrow_schema::SchemaRef>,
    /// Segmentation info from catalog (internal_schema=true)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation_info: Option<crate::catalog::segmentation::SegmentationInfo>,
    /// Index info from catalog (internal_schema=true)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub index_info: Option<Vec<crate::catalog::index::IndexInfoElement>>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct CreateTableColumnsResponse {
    /// Columns inferred from a Parquet file for building CreateTableRequest
    pub columns: Vec<crate::api::schema::Column>,
    /// External primary key inferred from the schema (optional).
    ///
    /// Notes:
    /// - This is present only when the source schema includes field metadata `primary_key=true`.
    /// - Current SeahorseDB/Coral behavior supports a single primary key column.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub primary_key: Option<Vec<String>>,
    /// External segmentation configuration inferred from the schema (optional).
    ///
    /// Notes:
    /// - For general Parquet files, this is usually unknown and omitted.
    /// - When the Parquet file was exported by Coral, this may be restored from embedded
    ///   `seahorse:schema` metadata.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation: Option<crate::api::schema::ExternalSegmentation>,
    /// External index configurations inferred from the schema (optional).
    ///
    /// Notes:
    /// - For general Parquet files, index configuration is not derivable and omitted.
    /// - When the Parquet file was exported by Coral, this may be restored from embedded
    ///   `seahorse:schema` metadata.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub indexes: Option<Vec<crate::api::schema::ExternalIndex>>,
    /// Internal Arrow schema (present when internal=true)
    #[serde(skip_serializing_if = "Option::is_none")]
    #[schema(value_type = crate::docs::arrow_schema::ArrowSchema, nullable)]
    pub schema: Option<arrow_schema::SchemaRef>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct GetTablesParameters {
    /// If true, only table names are returned.
    #[param(default = "false")]
    pub table_name_only: Option<bool>,
    /// If true, return internal Arrow schema (instead of external schema); default false.
    #[param(required = false, value_type = bool, example = false)]
    pub internal_schema: Option<bool>,
    /// If true, include internal columns (e.g. "__deleted_flag").
    ///
    /// - When internal_schema=true: internal Arrow schema includes internal columns.
    /// - When internal_schema=false: external schema `columns` includes internal columns.
    /// Alias: is_internal
    #[param(required = false, value_type = bool, example = false)]
    #[serde(alias = "is_internal")]
    pub include_internal_columns: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct GetTableQueryParameters {
    /// If true, return internal Arrow schema (instead of external schema); default false.
    #[param(required = false, value_type = bool, example = false)]
    pub internal_schema: Option<bool>,
    /// If true, include internal columns (e.g. "__deleted_flag").
    ///
    /// - When internal_schema=true: internal Arrow schema includes internal columns.
    /// - When internal_schema=false: external schema `columns` includes internal columns.
    /// Alias: is_internal
    #[param(required = false, value_type = bool, example = false)]
    #[serde(alias = "is_internal")]
    pub include_internal_columns: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct IndexedRowCountQueryParams {
    /// If true, include readable indexed row count (based on reader nodes) in the response.
    ///
    /// - Uses reader nodes only (writer nodes are excluded).
    /// - Deduplicates by `segment_id` and selects the entry with the largest `row_count`
    ///   to avoid dummy segments.
    /// - Computes readable row count as `row_count - deleted_row_count` (saturating).
    ///
    /// Defaults to true (include readable counts in addition to primary writer-based counts).
    #[param(default = "true")]
    pub readable: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct TableIndexedCount {
    pub total_row_count: i32,
    pub indexed_counts: Vec<IndexedCount>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct TableIndexedCountResponse {
    pub total_row_count: i32,
    pub indexed_counts: Vec<IndexedCount>,
    /// Readable (reader-based) indexed row count.
    ///
    /// Present by default unless `readable=false` is explicitly requested.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub readable: Option<TableIndexedCount>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct IndexedCount {
    pub index_name: String,
    pub index_type: String,
    pub indexed_row_count: i32,
}

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "kebab-case")]
pub enum SyncMode {
    /// Enqueue flush requests and return immediately.
    Async,
    /// Ensure the writer has uploaded the active set data to S3.
    WriterSync,
    /// Ensure readers can query the flushed active set data.
    ReaderSync,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct ActiveSetFlushRequest {
    /// Segment IDs to flush (optional). If omitted, all segments are flushed.
    #[serde(skip_serializing_if = "Option::is_none")]
    #[schema(example = json!(["v1|hash|single|pk|0|2|"]))]
    pub segment_ids: Option<Vec<String>>,
    /// Synchronization mode.
    #[schema(example = "reader-sync")]
    pub sync_mode: SyncMode,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct ActiveSetFlushResponse {
    #[schema(example = json!(["v1|hash|single|pk|0|2|"]))]
    pub flushed: Vec<String>,
    #[schema(example = json!([]))]
    pub failed: Vec<String>,
    #[schema(example = json!([]))]
    pub skipped: Vec<String>,
}
