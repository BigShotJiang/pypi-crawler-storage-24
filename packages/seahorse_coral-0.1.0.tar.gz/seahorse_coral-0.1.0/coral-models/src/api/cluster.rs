use std::collections::HashMap;

use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

pub use crate::catalog::{CacheEntryDump, CacheEntryType, CacheEntryValue};

use crate::catalog::{SegmentationInfo, TableOperationFailure};

// =================== Cache Management ===================

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheEntryDumpResponse {
    pub cache_entries: Vec<CacheEntryDump>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub next_cursor: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheDumpRequest {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub entry_type: Option<CacheEntryType>,
    pub include_value: bool,
    pub invalidated_only: bool,
    pub expired_only: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub limit: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cursor: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheStatsResponse {
    pub nodes_count: usize,
    pub tables_count: usize,
    pub segments_count: usize,
    pub total_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheConfigResponse {
    #[schema(value_type = u64, format = "seconds")]
    pub default_ttl_seconds: u64,
    pub invalidation_subscriber_active: bool,
    pub invalidation_channel: String,
    #[schema(value_type = u64, format = "seconds")]
    pub invalidation_reconnect_interval_seconds: u64,
    #[schema(value_type = u64, format = "seconds")]
    pub invalidation_heartbeat_interval_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheRefreshResponse {
    pub refreshed: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheInvalidateRequest {
    /// Catalog key string form: NODE:{id} | TABLE:{id} | SEGMENT:{table}:{segment}
    pub key: String,
    /// Publish invalidation event to redis (optional, default false)
    #[serde(default)]
    pub publish: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CacheInvalidateResponse {
    pub invalidated: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub published: Option<bool>,
}

// =================== Catalog Storage Dump ===================

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct StorageDumpQueryParams {
    /// Redis glob-style pattern (e.g., "*", "TABLE:*", "SEGMENT:tbl1:*")
    pub pattern: Option<String>,
    /// Optional maximum number of entries to return (defaults to all)
    pub limit: Option<usize>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CatalogStorageDumpEntry {
    /// Raw key
    pub key: String,
    /// Raw value (as stored); typically JSON string
    pub value: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CatalogStorageDumpResponse {
    /// Key-value entries returned by the pattern filter
    pub entries: Vec<CatalogStorageDumpEntry>,
}

// =================== Rebalancing ===================

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum RebalanceStrategy {
    BalancedMinMoves,
    StrictAlgorithmic,
}

fn empty_vec_as_none<'de, D>(deserializer: D) -> Result<Option<Vec<String>>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let opt = Option::<Vec<String>>::deserialize(deserializer)?;
    Ok(opt.filter(|v| !v.is_empty()))
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalancePlanRequest {
    /// Optional list of reader node IDs. If omitted or empty, readers remain unchanged.
    #[serde(default, deserialize_with = "empty_vec_as_none")]
    pub reader_nodes: Option<Vec<String>>,
    /// Optional list of writer node IDs. If omitted or empty, writers remain unchanged.
    #[serde(default, deserialize_with = "empty_vec_as_none")]
    pub writer_nodes: Option<Vec<String>>,
    /// Strategy hint. Default: balanced_min_moves.
    pub strategy: Option<RebalanceStrategy>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalanceNodeLoad {
    pub node_id: String,
    pub count: u32,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalancePlanSummary {
    pub total_segments: u32,
    pub writer_moves: u32,
    pub reader_moves: u32,
    pub unchanged_count: u32,
    pub writer_load_before: Vec<RebalanceNodeLoad>,
    pub writer_load_after: Vec<RebalanceNodeLoad>,
    pub reader_load_before: Vec<RebalanceNodeLoad>,
    pub reader_load_after: Vec<RebalanceNodeLoad>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalanceSegmentSide {
    pub writer: String,
    pub readers: Vec<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalanceSegmentChangeFlag {
    pub writer: bool,
    pub readers: bool,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalanceSegmentEntry {
    pub segment_id: String,
    pub before: RebalanceSegmentSide,
    pub after: RebalanceSegmentSide,
    pub changed: RebalanceSegmentChangeFlag,
}

/// Snapshot of a single segment's reader/writer assignments at plan time
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentAssignmentSnapshot {
    pub segment_id: String,
    pub readers: Vec<String>,
    pub writer: String,
}

/// Structural snapshot of all segments at plan time
/// Used for structural validation during commit (not version-based)
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentStructureSnapshot {
    /// Table's segmentation_info at plan time
    #[serde(skip_serializing_if = "Option::is_none")]
    pub segmentation_info: Option<SegmentationInfo>,

    /// Sorted list of segment IDs at plan time
    pub segment_ids: Vec<String>,

    /// Reader/writer assignments for each segment at plan time
    pub segment_assignments: HashMap<String, SegmentAssignmentSnapshot>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalancePlanResponse {
    pub table_name: String,
    pub expected_table_version: i32,
    pub strategy: RebalanceStrategy,
    /// Structural snapshot of segments at plan time for validation during commit
    pub expected_segment_structure: SegmentStructureSnapshot,
    pub effective_reader_nodes: Vec<String>,
    pub effective_writer_nodes: Vec<String>,
    pub summary: RebalancePlanSummary,
    pub segments: Vec<RebalanceSegmentEntry>,
    pub commit_template: RebalanceCommitRequest,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalanceCommitRequest {
    /// Optional list of reader node IDs. If omitted or empty, readers remain unchanged.
    #[serde(default, deserialize_with = "empty_vec_as_none")]
    pub reader_nodes: Option<Vec<String>>,
    /// Optional list of writer node IDs. If omitted or empty, writers remain unchanged.
    #[serde(default, deserialize_with = "empty_vec_as_none")]
    pub writer_nodes: Option<Vec<String>>,
    /// Strategy hint. Default: balanced_min_moves.
    #[schema(default = "balanced_min_moves")]
    pub strategy: Option<RebalanceStrategy>,
    /// Required CAS guard. Must match Plan's table_version.
    pub expected_table_version: i32,
    /// Required structural snapshot from plan for validation
    pub expected_segment_structure: SegmentStructureSnapshot,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalanceCommitResponse {
    pub table_name: String,
    pub new_table_version: i32,
    pub status: String,
    pub summary: RebalancePlanSummary,
    pub segments: Vec<RebalanceSegmentEntry>,
    pub effective_reader_nodes: Vec<String>,
    pub effective_writer_nodes: Vec<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct TableOperationPollingInfo {
    #[schema(value_type = String, format = "date-time")]
    pub evaluated_at: String,
    pub nodes: Vec<TableOperationNodeSegmentStatus>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct TableOperationNodeSegmentStatus {
    pub node_id: String,
    pub segments: Vec<TableOperationSegmentStatus>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct TableOperationSegmentStatus {
    pub segment_id: String,
    pub expected: TableOperationSegmentExpectation,
    pub observed: TableOperationObservedSegmentStatus,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure_reason: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum TableOperationSegmentExpectation {
    Add,
    Remove,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum TableOperationObservedSegmentStatus {
    Syncing,
    Synced,
    Removing,
    Failed,
    Unknown,
    Deleted,
    NotTracked,
    MissingNodeInfo,
    MissingTableAssignment,
    MissingSegmentAssignment,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RebalanceStatusResponse {
    pub table_name: String,
    pub status: String,
    #[schema(value_type = String, format = "date-time", nullable)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub started_at: Option<String>,
    /// TTL seconds used for timeout judgment (derived from server configuration for this status).
    #[schema(value_type = u64, format = "seconds", nullable)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub ttl_seconds: Option<u64>,
    /// Failure information (present only when the operation has failed)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure: Option<TableOperationFailure>,
    /// Polling snapshot (per-node per-segment observed status)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub polling: Option<TableOperationPollingInfo>,
}

/// Create status response (mirror of RebalanceStatusResponse shape)
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct CreateStatusResponse {
    pub table_name: String,
    pub status: String,
    #[schema(value_type = String, format = "date-time", nullable)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub started_at: Option<String>,
    /// Failure information (present only when the operation has failed)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure: Option<TableOperationFailure>,
    /// Polling snapshot (per-node per-segment observed status)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub polling: Option<TableOperationPollingInfo>,
}

// =================== Segment Operations (Retry + Unified Status) ===================

#[derive(Default, Serialize, Deserialize, Debug, Clone, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum SegmentRetryMode {
    #[default]
    Auto,
    Create,
    Rebalance,
}

fn default_true() -> bool {
    true
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentsRetryRequest {
    #[serde(default)]
    pub mode: SegmentRetryMode,
    #[serde(default = "default_true")]
    pub only_failed: bool,
    #[serde(default = "default_true")]
    pub skip_unsubscribed: bool,
    #[serde(default)]
    pub dry_run: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_targets: Option<u32>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentsRetryNodeResult {
    pub node_id: String,
    pub published_segments: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub skipped: Option<SegmentsRetrySkipInfo>,
    pub observations: SegmentsRetryNodeObservations,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentsRetrySkipInfo {
    pub reason: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, Default, ToSchema)]
pub struct SegmentsRetryNodeObservations {
    pub missing_nodeinfo: bool,
    pub missing_table_assignment: bool,
    pub missing_segment_count: u32,
    pub failed_segment_count: u32,
    pub synced_segment_count: u32,
    pub not_removed_segment_count: u32,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentsRetrySummary {
    pub mode: String,
    pub total_nodes: u32,
    pub published_segment_count: u32,
    pub skipped_node_count: u32,
    pub truncated: bool,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentsRetryResponse {
    pub table_name: String,
    pub table_status: String,
    pub summary: SegmentsRetrySummary,
    pub nodes: Vec<SegmentsRetryNodeResult>,
}

// =================== Unified Segments Status ===================

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum SegmentsStatusMode {
    Active,
    Create,
    Rebalance,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentsStatusSummary {
    pub total: u32,
    pub synced: u32,
    pub failed: u32,
    pub pending: u32,
}

/// Unified segments status response (replaces deprecated create/status and rebalance/status).
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentsStatusResponse {
    pub table_name: String,
    pub table_status: String,
    pub mode: SegmentsStatusMode,
    #[schema(value_type = String, format = "date-time", nullable)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub started_at: Option<String>,
    #[schema(value_type = u64, format = "seconds", nullable)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub ttl_seconds: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure: Option<TableOperationFailure>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub polling: Option<TableOperationPollingInfo>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub summary: Option<SegmentsStatusSummary>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rebalance_plan_request_empty_nodes_deserialize_as_none() {
        let req: RebalancePlanRequest =
            serde_json::from_str(r#"{"reader_nodes":[],"writer_nodes":[]}"#).unwrap();
        assert_eq!(req.reader_nodes, None);
        assert_eq!(req.writer_nodes, None);
    }

    #[test]
    fn rebalance_plan_request_non_empty_nodes_preserved() {
        let req: RebalancePlanRequest = serde_json::from_str(
            r#"{"reader_nodes":["r1","r2"],"writer_nodes":["w1"],"strategy":"balanced_min_moves"}"#,
        )
        .unwrap();
        assert_eq!(
            req.reader_nodes,
            Some(vec!["r1".to_string(), "r2".to_string()])
        );
        assert_eq!(req.writer_nodes, Some(vec!["w1".to_string()]));
        assert_eq!(req.strategy, Some(RebalanceStrategy::BalancedMinMoves));
    }

    #[test]
    fn rebalance_commit_request_empty_nodes_deserialize_as_none() {
        let json = r#"
        {
          "reader_nodes": [],
          "writer_nodes": [],
          "expected_table_version": 1,
          "expected_segment_structure": {
            "segmentation_info": null,
            "segment_ids": [],
            "segment_assignments": {}
          }
        }
        "#;
        let req: RebalanceCommitRequest = serde_json::from_str(json).unwrap();
        assert_eq!(req.reader_nodes, None);
        assert_eq!(req.writer_nodes, None);
    }
}
