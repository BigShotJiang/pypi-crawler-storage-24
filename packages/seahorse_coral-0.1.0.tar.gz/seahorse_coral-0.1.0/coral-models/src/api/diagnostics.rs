use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataPlanRequest {
    /// Optional projection list (SQL projection syntax). If not specified, all columns will be returned.
    #[schema(default = "*", example = "id, name, distance")]
    pub projection: Option<String>,
    /// Optional filter does not execute any query.
    pub filter: Option<String>,
    /// Allow writer nodes to participate in serving. Defaults to false (reader-only).
    #[schema(default = "false")]
    pub allow_writer: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SetVersionEntry {
    pub set: i64,
    pub version: i64,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct NodeSetVersions {
    pub node_id: String,
    pub node_type: String,
    /// For readers: last set number they can serve; for writers: None
    pub last_set_number: Option<i64>,
    pub versions: Vec<SetVersionEntry>,
    /// For readers: counts within inactive sets (0..=last_inactive_set). Writers: None
    pub num_latest_matches: Option<i64>,
    pub num_latest_mismatches: Option<i64>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct NodeSearchRanges {
    pub node_id: String,
    pub node_type: String,
    /// Search scopes such as "seg:0-26" for readers or "seg:27" for writers
    pub search_scopes: Vec<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentPlanDetail {
    pub segment_id: String,
    pub last_inactive_set: i64,
    pub latest_versions: Vec<SetVersionEntry>,
    pub readers: Vec<NodeSetVersions>,
    pub writer: NodeSetVersions,
    /// Distribution for this segment (reader ranges per node and writer ranges)
    pub segment_distribution: Vec<NodeSearchRanges>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct EmptyRangeDiagnostic {
    pub node_id: String,
    pub node_type: String,
    pub node_address: String,
    pub assigned_segments_for_table: Vec<String>,
    /// last_set_number per segment if available
    pub segment_last_sets: Vec<(String, Option<i64>)>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataPlanResponse {
    pub table_name: String,
    pub filter: Option<String>,
    pub segment_pruning: Option<SegmentPruningInfo>,
    /// Per-segment diagnostics including versions and per-segment distribution
    pub segments: Vec<SegmentPlanDetail>,
    /// Final node to search scopes map aggregated across segments
    pub final_distribution: Vec<NodeSearchRanges>,
    /// Diagnostics for nodes that ended up with empty search scopes
    pub empty_range_diagnostics: Vec<EmptyRangeDiagnostic>,
    /// Raw per-node assignments and set versions before planning (for visibility)
    pub raw_node_assignments: Vec<RawNodeAssignments>,
}

/// Raw snapshot of a node's assignment state for the requested table
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct RawNodeAssignments {
    pub node_id: String,
    pub node_type: String,
    pub node_address: String,
    /// Segments assigned to this node for the table and their version info
    pub assigned_segments: Vec<NodeSegmentRawSnapshot>,
}

/// Raw snapshot of a single segment assignment on a node
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct NodeSegmentRawSnapshot {
    pub segment_id: String,
    /// For readers: last set number they can serve; for writers: None
    pub last_set_number: Option<i64>,
    /// Raw set->version entries parsed from checkpoint.set_versions
    pub versions: Vec<SetVersionEntry>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentPruningInfo {
    pub enabled: bool,
    pub total_segments_available: usize,
    pub segments_pruned: usize,
    pub pruning_filters: Vec<PruningFilter>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct PruningFilter {
    pub filter_expression: String,
}
