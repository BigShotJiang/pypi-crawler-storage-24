use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::catalog::SyncErrorInfo;

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct NodePingResponse {
    pub node_name: String,
    pub result: String,
}

/// Resource usage information for a single segment
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct SegmentResourceUsage {
    pub segment_id: String,
    pub memory_bytes: u64,
    pub disk_bytes: u64,
}

/// Resource usage information for a single table
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct TableResourceUsage {
    pub table_name: String,
    pub segments: Vec<SegmentResourceUsage>,
    pub total_memory_bytes: u64,
    pub total_disk_bytes: u64,
}

/// Resource usage response from a single SeahorseDB node
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct NodeResourceUsage {
    pub tables: Vec<TableResourceUsage>,
    pub total_memory_bytes: u64,
    pub total_disk_bytes: u64,
}

/// Resource usage response for a single node with node identification
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct NodeResourceUsageResult {
    pub node_name: String,
    pub node_type: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub resource_usage: Option<NodeResourceUsage>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

/// Aggregated resource usage response from all nodes
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct VdbResourceUsageResponse {
    pub nodes: Vec<NodeResourceUsageResult>,
    pub total_memory_bytes: u64,
    pub total_disk_bytes: u64,
}

/// Sync error information for a specific node
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct NodeSyncErrorsResponse {
    pub node_id: String,
    #[serde(flatten)]
    pub sync_error_info: SyncErrorInfo,
}

/// Aggregated sync errors from all nodes
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct AllSyncErrorsResponse {
    pub nodes: Vec<NodeSyncErrorsResponse>,
}
