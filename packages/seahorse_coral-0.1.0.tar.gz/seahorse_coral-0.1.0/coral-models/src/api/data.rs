use serde::{Deserialize, Serialize};
use utoipa::{IntoParams, ToSchema};

use super::common::RequestMetrics;
use super::storage::Paths;

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataScanRequest {
    /// Columns to include in the result set. Uses SQL projection syntax (e.g. "col1, col2"). If not specified, all columns will be returned.
    #[schema(default = "*", example = "video_id, video_title")]
    pub projection: Option<String>,
    /// SQL WHERE clause to filter the results. If not specified, no filtering will be applied.
    #[schema(default = "", example = "category < 40 and category > 10")]
    pub filter: Option<String>,
    /// Number of rows to return in the result set. If set to 0 or not specified, returns all matching rows.
    #[schema(default = "0", example = "100")]
    pub limit: Option<i32>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct ScanQueryParams {
    /// Include detailed metrics such as peak memory in the response. Defaults to off.
    #[param(default = "false")]
    pub include_metrics: Option<bool>,
    /// Allow writer nodes to participate in serving. Defaults to false (reader-only).
    #[param(default = "false")]
    pub allow_writer: Option<bool>,
    /// If true, include internal columns (e.g. "__deleted_flag") in scan results.
    /// Alias: is_internal
    #[param(default = "false")]
    #[serde(alias = "is_internal")]
    pub include_internal_columns: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct SearchQueryParams {
    /// Allow writer nodes to participate in serving. Defaults to false (reader-only).
    #[param(default = "false")]
    pub allow_writer: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct ExportQueryParams {
    /// If true, include internal columns (e.g. "__deleted_flag") in exported data.
    /// Alias: is_internal
    #[param(default = "false")]
    #[serde(alias = "is_internal")]
    pub include_internal_columns: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataUpdateRequest {
    /// SQL WHERE clause to filter which rows to update. If not provided, all rows will be updated.
    #[schema(default = "", example = "video_id = 1000")]
    pub update_condition: Option<String>,
    /// Values to update in SQL SET clause format (e.g. "column = value"). Multiple assignments can be separated by commas.
    /// - String values must be enclosed in single quotes: `title = 'hello'`
    /// - List/Vector values use bracket literals: `vec = [1.0, 2.0, 3.0]`
    #[schema(example = "video_title = 'changed_title', category = 100")]
    pub update_values: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataDeleteRequest {
    /// SQL WHERE clause to filter which rows to delete. If not provided, all rows will be deleted.
    #[schema(default = "", example = "video_id = 1000")]
    pub delete_condition: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataInsertResult {
    /// Number of total record batches inserted.
    pub inserted_record_batches: usize,
    /// Number of total rows inserted.
    pub inserted_row_count: usize,
    /// Elapsed time in seconds for reading the file and inserting the data into the table.
    /// This measures the time taken by the underlying data insertion process,
    /// but does not include the full duration of the API request.
    pub elapsed_time: Option<f32>,
}

/// Per-file batch insert outcome
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct FileInsertResult {
    /// Source file path
    pub path: String,
    /// Whether this file was inserted successfully
    pub success: bool,
    /// Result when success == true
    pub result: Option<DataInsertResult>,
    /// Error message when success == false
    pub error: Option<String>,
}

/// Batch insert result returning per-file outcomes
#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct BatchDataInsertResult {
    /// Outcomes for each input path
    pub results: Vec<FileInsertResult>,
    /// Request metrics such as elapsed time and optional peak memory.
    pub metrics: Option<RequestMetrics>,
    /// Sum of inserted_row_count across successful files
    pub total_inserted_row_count: usize,
    /// Sum of inserted_record_batches across successful files
    pub total_inserted_record_batches: usize,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct InsertQueryParams {
    /// Maximum number of rows in each record batch produced by the reader.
    /// This controls the reader's record batch size, not the final insert batch or segment size.
    /// Default depends on Apache Arrow configuration and it is 1024.
    pub reader_batch_size: Option<usize>,
    /// Synchronous read loads all data and converts it to record batches before starting table insertion.
    /// Asynchronous read streams data one record batch at a time, inserting each batch immediately.
    #[param(default = "true")]
    pub use_async_read: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct ExportResult {
    /// Output prefix (directory/prefix).
    ///
    /// - single_file: equals request export directory
    /// - multi_file: equals newly created folder under export directory
    pub output_prefix: String,

    /// Exported files (filenames only).
    ///
    /// - single_file: ["{table}-{export_id}.parquet"]
    /// - multi_file: ["part-00000.parquet", "part-00001.parquet", ...]
    pub files: Vec<String>,

    /// Resolved export mode after defaulting.
    pub mode: ExportMode,
    /// Total number of rows exported.
    pub total_row_count: usize,
    /// Total uncompressed byte size of the exported data.
    pub total_uncompressed_byte_size: usize,
    /// Number of row groups exported.
    pub num_row_groups: usize,
    /// Average row group size in bytes.
    pub average_uncompressed_row_group_size: usize,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataExportResponse {
    pub export_result: ExportResult,
    /// Request metrics such as elapsed time and optional peak memory.
    pub metrics: Option<RequestMetrics>,
}

#[derive(PartialEq, Eq, Serialize, Deserialize, Debug, Clone, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum ExportMode {
    /// Export as a single parquet file.
    SingleFile,
    /// Export as multiple parquet files under a folder.
    #[serde(alias = "dataset")]
    MultiFile,
}

#[derive(Serialize, Deserialize, Debug, Clone, ToSchema)]
pub struct DataExportRequest {
    /// Export destination directory in `paths` (must contain exactly one directory).
    /// Keep using existing storage semantics via storage_config.
    pub export_paths: Paths,

    /// File format to export. Currently only Parquet.
    #[schema(default = "Parquet")]
    pub format: Option<FileFormat>,

    /// Columns to include in the exported data. Uses SQL projection syntax (e.g. "col1, col2").
    /// If not specified, all columns will be returned.
    #[schema(default = "*", example = "video_id, video_title")]
    pub projection: Option<String>,
    /// SQL WHERE clause to filter the exported rows. If not specified, no filtering will be applied.
    #[schema(default = "", example = "category < 40 and category > 10")]
    pub filter: Option<String>,
    /// Number of rows to export. If set to 0 or not specified, exports all matching rows.
    #[schema(default = "0", example = "100")]
    pub limit: Option<i32>,

    /// Export mode. Defaults to multi_file.
    #[schema(default = "multi_file")]
    pub mode: Option<ExportMode>,

    /// Row group size in bytes. Default is 40MB.
    #[schema(default = "40000000")]
    pub row_group_size: Option<usize>,

    /// Target parquet file size in bytes for multi_file export.
    /// Server may translate this to a row-group rollover threshold.
    pub target_file_size_bytes: Option<usize>,

    /// Maximum number of row groups per part file for multi_file export.
    /// If set, this takes precedence over `target_file_size_bytes`.
    pub max_row_groups_per_file: Option<usize>,

    /// Include detailed metrics such as peak memory in the response. Defaults to off.
    #[schema(default = "false")]
    pub include_metrics: Option<bool>,

    /// Allow writer nodes to participate in serving. Defaults to false (reader-only).
    #[schema(default = "false")]
    pub allow_writer: Option<bool>,

    /// If true, include internal columns (e.g. "__deleted_flag") in exported data.
    /// Alias: is_internal
    #[schema(default = "false")]
    #[serde(alias = "is_internal")]
    pub include_internal_columns: Option<bool>,
}

#[derive(Serialize, Deserialize, Debug, Clone, IntoParams, ToSchema)]
pub struct DataExportDownloadQueryParams {
    /// File format to export. Currently, only "Parquet" is supported.
    #[param(default = "Parquet")]
    pub format: FileFormat,
    /// Row group size in bytes. Default is 40MB.
    #[param(default = "40000000")]
    pub row_group_size: Option<usize>,
    /// Allow writer nodes to participate in serving. Defaults to false (reader-only).
    #[param(default = "false")]
    pub allow_writer: Option<bool>,
    /// Columns to include in the exported data. Uses SQL projection syntax (e.g. "col1, col2").
    /// If not specified, all columns will be returned.
    #[param(required = false, value_type = String, example = "id, title")]
    pub projection: Option<String>,
    /// SQL WHERE clause to filter the exported rows. If not specified, no filtering will be applied.
    #[param(required = false, value_type = String, example = "category > 10 and category < 40")]
    pub filter: Option<String>,
    /// Number of rows to export. If set to 0 or not specified, exports all matching rows.
    #[param(required = false, value_type = i32, example = 1000)]
    pub limit: Option<i32>,
    /// If true, include internal columns (e.g. "__deleted_flag") in exported data.
    /// Alias: is_internal
    #[param(default = "false")]
    #[serde(alias = "is_internal")]
    pub include_internal_columns: Option<bool>,
}

#[derive(PartialEq, Eq, Serialize, Deserialize, Debug, Clone, ToSchema)]
pub enum FileFormat {
    /// Json Lines format.
    Jsonl,
    /// Parquet format.
    Parquet,
}

impl FileFormat {
    pub fn get_extension(&self) -> &str {
        match self {
            FileFormat::Jsonl => ".jsonl",
            FileFormat::Parquet => ".parquet",
        }
    }
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::{ScanQueryParams, SearchQueryParams};

    #[test]
    fn search_query_params_deserializes_allow_writer() {
        let params: SearchQueryParams =
            serde_json::from_value(json!({ "allow_writer": true })).expect("valid params");

        assert_eq!(params.allow_writer, Some(true));
    }

    #[test]
    fn search_query_params_ignores_scan_only_fields() {
        let params: SearchQueryParams = serde_json::from_value(json!({
            "allow_writer": false,
            "include_metrics": true,
            "include_internal_columns": true
        }))
        .expect("unknown fields should be ignored for compatibility");

        assert_eq!(params.allow_writer, Some(false));
    }

    #[test]
    fn scan_query_params_keeps_scan_specific_fields() {
        let params: ScanQueryParams = serde_json::from_value(json!({
            "allow_writer": true,
            "include_metrics": true,
            "include_internal_columns": true
        }))
        .expect("valid scan params");

        assert_eq!(params.allow_writer, Some(true));
        assert_eq!(params.include_metrics, Some(true));
        assert_eq!(params.include_internal_columns, Some(true));
    }
}
