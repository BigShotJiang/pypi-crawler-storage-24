use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use utoipa::ToSchema;

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ArrowField {
    pub name: String,
    pub data_type: String,
    pub nullable: bool,
    #[serde(default)]
    pub metadata: HashMap<String, String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ArrowSchema {
    pub fields: Vec<ArrowField>,
    #[serde(default)]
    pub metadata: HashMap<String, String>,
}
