"""
Seahorse Coral Client Exceptions

Custom exception classes for the Seahorse Coral client.
"""

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .types import ImportFilesResult


class SeahorseError(Exception):
    """Base exception class for Seahorse Coral client errors."""

    def __init__(self, message: str, details: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.details = details

    def __str__(self) -> str:
        if self.details:
            return f"{self.message}: {self.details}"
        return self.message


class ConnectionError(SeahorseError):
    """Exception raised when connection to server fails."""

    pass


class QueryError(SeahorseError):
    """Exception raised when a query execution fails."""

    pass


class TableError(SeahorseError):
    """Exception raised when table operations fail."""

    pass


class ImportFilesError(TableError):
    """Exception raised when a file import request fails."""

    def __init__(
        self,
        result: "ImportFilesResult",
        message: str = "Import files failed",
        details: Optional[str] = None,
    ):
        super().__init__(message, details)
        self.result = result


class PartialImportError(ImportFilesError):
    """Exception raised when a file import request partially succeeds."""

    pass


class SearchError(SeahorseError):
    """Exception raised when vector search operations fail."""

    pass

