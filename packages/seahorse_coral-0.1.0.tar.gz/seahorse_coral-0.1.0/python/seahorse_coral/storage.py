"""
Storage utilities for Seahorse Coral Client.

This module provides utilities for handling file-based data insertion
and cloud storage integration.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union


class StorageType(Enum):
    """Storage types for data insertion."""

    LOCAL = "LOCAL"
    AWS = "AWS"
    S3 = "S3"
    GCP = "GCP"
    AZURE = "AZURE"
    CEPH = "CEPH"
    MINIO = "MINIO"
    S3_COMPATIBLE = "S3_COMPATIBLE"


class FileFormat(Enum):
    """File formats for data insertion."""

    JSONL = "Jsonl"
    PARQUET = "Parquet"


@dataclass
class CloudStorageCredentials:
    """Cloud storage credentials."""

    access_key: Optional[str] = None
    secret_key: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        result = {}
        if self.access_key:
            result["access_key"] = self.access_key
        if self.secret_key:
            result["secret_key"] = self.secret_key
        return result


@dataclass
class CloudStorageOptions:
    """Cloud storage options."""

    region: Optional[str] = None
    endpoint: Optional[str] = None
    virtual_hosted_style: bool = False
    allow_http: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        result = {}
        if self.region:
            result["region"] = self.region
        if self.endpoint:
            result["endpoint"] = self.endpoint
        if self.virtual_hosted_style:
            result["virtual_hosted_style"] = self.virtual_hosted_style
        if self.allow_http:
            result["allow_http"] = self.allow_http
        return result


@dataclass
class StorageConfig:
    """Storage configuration for cloud storage access."""

    storage_type: Optional[StorageType] = None
    bucket: Optional[str] = None
    credentials: Optional[CloudStorageCredentials] = None
    options: Optional[CloudStorageOptions] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        result = {}
        if self.storage_type:
            result["storage_type"] = self.storage_type.value
        if self.bucket:
            result["bucket"] = self.bucket
        if self.credentials:
            result["credentials"] = self.credentials.to_dict()
        if self.options:
            result["options"] = self.options.to_dict()
        return result


@dataclass
class FileSource:
    """File source configuration for server-side imports."""

    paths: List[str] = field(default_factory=list)
    storage_config: Optional[StorageConfig] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format for API request."""
        result = {"paths": self.paths}
        if self.storage_config:
            result["storage_config"] = self.storage_config.to_dict()
        return result


@dataclass
class ImportOptions:
    """Options for file-based imports."""

    format: FileFormat = FileFormat.PARQUET
    # Controls the record batch size of the reader, not the final insert batch size.
    reader_batch_size: Optional[int] = None
    max_concurrent_files: Optional[int] = None
    include_metrics: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format for API request."""
        result = {"format": self.format.value}
        if self.reader_batch_size:
            result["reader_batch_size"] = self.reader_batch_size
        if self.max_concurrent_files:
            result["max_concurrent_files"] = self.max_concurrent_files
        if self.include_metrics:
            result["include_metrics"] = self.include_metrics
        return result


# =============================================================================
# Helper functions for creating storage configurations
# =============================================================================


def local_file(file_path: Union[str, List[str]]) -> FileSource:
    """Create a local file insertion request."""
    if isinstance(file_path, str):
        file_path = [file_path]

    return FileSource(
        paths=file_path,
        storage_config=StorageConfig(storage_type=StorageType.LOCAL),
    )


def local_directory(directory_path: str) -> FileSource:
    """Create a local directory insertion request."""
    return FileSource(
        paths=[directory_path],
        storage_config=StorageConfig(storage_type=StorageType.LOCAL),
    )


def s3_file(
    file_path: Union[str, List[str]],
    bucket: str,
    access_key: Optional[str] = None,
    secret_key: Optional[str] = None,
    region: Optional[str] = None,
    endpoint: Optional[str] = None,
) -> FileSource:
    """Create an S3 file insertion request."""
    if isinstance(file_path, str):
        file_path = [file_path]

    credentials = None
    if access_key and secret_key:
        credentials = CloudStorageCredentials(
            access_key=access_key, secret_key=secret_key
        )

    options = None
    if region or endpoint:
        options = CloudStorageOptions(region=region, endpoint=endpoint)

    return FileSource(
        paths=file_path,
        storage_config=StorageConfig(
            storage_type=StorageType.S3,
            bucket=bucket,
            credentials=credentials,
            options=options,
        ),
    )


def s3_directory(
    directory_path: str,
    bucket: str,
    access_key: Optional[str] = None,
    secret_key: Optional[str] = None,
    region: Optional[str] = None,
    endpoint: Optional[str] = None,
) -> FileSource:
    """Create an S3 directory insertion request."""
    credentials = None
    if access_key and secret_key:
        credentials = CloudStorageCredentials(
            access_key=access_key, secret_key=secret_key
        )

    options = None
    if region or endpoint:
        options = CloudStorageOptions(region=region, endpoint=endpoint)

    return FileSource(
        paths=[directory_path],
        storage_config=StorageConfig(
            storage_type=StorageType.S3,
            bucket=bucket,
            credentials=credentials,
            options=options,
        ),
    )


def gcs_file(
    file_path: Union[str, List[str]],
    bucket: str,
    credentials_path: Optional[str] = None,
) -> FileSource:
    """Create a Google Cloud Storage file insertion request."""
    if isinstance(file_path, str):
        file_path = [file_path]

    return FileSource(
        paths=file_path,
        storage_config=StorageConfig(
            storage_type=StorageType.GCP,
            bucket=bucket,
        ),
    )


def azure_file(
    file_path: Union[str, List[str]],
    bucket: str,  # Container name in Azure
    access_key: Optional[str] = None,
    secret_key: Optional[str] = None,
    endpoint: Optional[str] = None,
) -> FileSource:
    """Create an Azure Blob Storage file insertion request."""
    if isinstance(file_path, str):
        file_path = [file_path]

    credentials = None
    if access_key and secret_key:
        credentials = CloudStorageCredentials(
            access_key=access_key, secret_key=secret_key
        )

    options = None
    if endpoint:
        options = CloudStorageOptions(endpoint=endpoint)

    return FileSource(
        paths=file_path,
        storage_config=StorageConfig(
            storage_type=StorageType.AZURE,
            bucket=bucket,
            credentials=credentials,
            options=options,
        ),
    )


def minio_file(
    file_path: Union[str, List[str]],
    bucket: str,
    access_key: str,
    secret_key: str,
    endpoint: str,
    region: Optional[str] = None,
    use_ssl: bool = True,
) -> FileSource:
    """Create a MinIO file insertion request."""
    if isinstance(file_path, str):
        file_path = [file_path]

    return FileSource(
        paths=file_path,
        storage_config=StorageConfig(
            storage_type=StorageType.MINIO,
            bucket=bucket,
            credentials=CloudStorageCredentials(
                access_key=access_key, secret_key=secret_key
            ),
            options=CloudStorageOptions(
                region=region, endpoint=endpoint, allow_http=not use_ssl
            ),
        ),
    )


def s3_compatible_file(
    file_path: Union[str, List[str]],
    bucket: str,
    access_key: str,
    secret_key: str,
    endpoint: str,
    region: Optional[str] = None,
    virtual_hosted_style: bool = False,
    use_ssl: bool = True,
) -> FileSource:
    """Create an S3-compatible storage file insertion request."""
    if isinstance(file_path, str):
        file_path = [file_path]

    return FileSource(
        paths=file_path,
        storage_config=StorageConfig(
            storage_type=StorageType.S3_COMPATIBLE,
            bucket=bucket,
            credentials=CloudStorageCredentials(
                access_key=access_key, secret_key=secret_key
            ),
            options=CloudStorageOptions(
                region=region,
                endpoint=endpoint,
                virtual_hosted_style=virtual_hosted_style,
                allow_http=not use_ssl,
            ),
        ),
    )
