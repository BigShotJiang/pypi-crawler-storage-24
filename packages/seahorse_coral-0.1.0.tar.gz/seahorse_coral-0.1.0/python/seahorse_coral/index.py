"""
Index classes for Seahorse Coral Client.

This module defines dense/sparse vector search APIs for a table index.
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .types import (
    RecordBatchStream,
    ResultSet,
    ResultSetStream,
    ResultSets,
    SparseVector,
    SparseVectorList,
    Vector,
    VectorList,
)

if TYPE_CHECKING:
    from .table import AsyncTable, Table


def _ensure_dense_query(query: Vector) -> VectorList:
    if not isinstance(query, list) or not query:
        raise ValueError("query must be a non-empty list[float]")
    if not all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in query):
        raise TypeError("query must be a list[float]")
    return [float(value) for value in query]


def _ensure_dense_queries(queries: VectorList) -> VectorList:
    if not isinstance(queries, list) or not queries:
        raise ValueError("queries must be a non-empty list[list[float]]")
    normalized = []
    for query in queries:
        normalized.append(_ensure_dense_query(query))
    return normalized


def _ensure_sparse_query(query: SparseVector) -> SparseVectorList:
    if not isinstance(query, str) or not query:
        raise ValueError("query must be a non-empty sparse vector string")
    return [query]


def _ensure_sparse_queries(queries: SparseVectorList) -> SparseVectorList:
    if not isinstance(queries, list) or not queries:
        raise ValueError("queries must be a non-empty list[str]")
    if not all(isinstance(query, str) and query for query in queries):
        raise TypeError("queries must be a list[str]")
    return queries


class Index:
    """Sync vector index handle."""

    def __init__(self, table: "Table", index_name: str):
        self._table = table
        self._name = index_name

    @property
    def name(self) -> str:
        return self._name

    @property
    def table_name(self) -> str:
        return self._table.name

    def search(
        self,
        query: Vector,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        return self._table._db._vector_search(
            self._table.name,
            self._name,
            _ensure_dense_query(query),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    def search_batch(
        self,
        queries: VectorList,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        return self._table._db._vector_search_batch(
            self._table.name,
            self._name,
            _ensure_dense_queries(queries),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    def search_stream(
        self,
        query: Vector,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        return self._table._db._vector_search_stream(
            self._table.name,
            self._name,
            _ensure_dense_query(query),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    def search_batch_stream(
        self,
        queries: VectorList,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        return self._table._db._vector_search_batch_stream(
            self._table.name,
            self._name,
            _ensure_dense_queries(queries),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    def search_sparse(
        self,
        query: SparseVector,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        return self._table._db._sparse_search(
            self._table.name,
            self._name,
            _ensure_sparse_query(query),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    def search_sparse_batch(
        self,
        queries: SparseVectorList,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        return self._table._db._sparse_search_batch(
            self._table.name,
            self._name,
            _ensure_sparse_queries(queries),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    def search_sparse_stream(
        self,
        query: SparseVector,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        return self._table._db._sparse_search_stream(
            self._table.name,
            self._name,
            _ensure_sparse_query(query),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    def search_sparse_batch_stream(
        self,
        queries: SparseVectorList,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        return self._table._db._sparse_search_batch_stream(
            self._table.name,
            self._name,
            _ensure_sparse_queries(queries),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    def __repr__(self) -> str:
        return f"Index(table='{self._table.name}', name='{self._name}')"


class AsyncIndex:
    """Async vector index handle."""

    def __init__(self, table: "AsyncTable", index_name: str):
        self._table = table
        self._name = index_name

    @property
    def name(self) -> str:
        return self._name

    @property
    def table_name(self) -> str:
        return self._table.name

    async def search(
        self,
        query: Vector,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        return await self._table._db._vector_search(
            self._table.name,
            self._name,
            _ensure_dense_query(query),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    async def search_batch(
        self,
        queries: VectorList,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        return await self._table._db._vector_search_batch(
            self._table.name,
            self._name,
            _ensure_dense_queries(queries),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    async def search_stream(
        self,
        query: Vector,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        return await self._table._db._vector_search_stream(
            self._table.name,
            self._name,
            _ensure_dense_query(query),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    async def search_batch_stream(
        self,
        queries: VectorList,
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        return await self._table._db._vector_search_batch_stream(
            self._table.name,
            self._name,
            _ensure_dense_queries(queries),
            top_k=top_k,
            ef_search=ef_search,
            select=select,
            where=where,
        )

    async def search_sparse(
        self,
        query: SparseVector,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        return await self._table._db._sparse_search(
            self._table.name,
            self._name,
            _ensure_sparse_query(query),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    async def search_sparse_batch(
        self,
        queries: SparseVectorList,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        return await self._table._db._sparse_search_batch(
            self._table.name,
            self._name,
            _ensure_sparse_queries(queries),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    async def search_sparse_stream(
        self,
        query: SparseVector,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        return await self._table._db._sparse_search_stream(
            self._table.name,
            self._name,
            _ensure_sparse_query(query),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    async def search_sparse_batch_stream(
        self,
        queries: SparseVectorList,
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        return await self._table._db._sparse_search_batch_stream(
            self._table.name,
            self._name,
            _ensure_sparse_queries(queries),
            top_k=top_k,
            bm25_k=bm25_k,
            bm25_b=bm25_b,
            sparse_metadata=sparse_metadata,
            select=select,
            where=where,
        )

    def __repr__(self) -> str:
        return f"AsyncIndex(table='{self._table.name}', name='{self._name}')"
