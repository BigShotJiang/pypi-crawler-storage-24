"""
Table classes for Seahorse Coral Client.

This module defines collect-first and stream query APIs for a single table,
plus explicit insert/import methods.
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .index import AsyncIndex, Index
from .storage import FileSource, ImportOptions
from .types import (
    ActiveSetFlushResult,
    HybridSearchOptions,
    ImportFilesResult,
    IndexedCounts,
    InsertResult,
    RebalanceCommitRequest,
    RebalanceCommitResult,
    RebalancePlanResult,
    RebalanceStatusResult,
    RecordBatchStream,
    ResultSet,
    ResultSetStream,
    ResultSets,
    SegmentsRetryResult,
    SegmentsStatusResult,
    SparseVector,
    SparseVectorList,
    TableSchema,
    Vector,
    VectorList,
)

if TYPE_CHECKING:
    from .coral import AsyncCoral, Coral


def _ensure_dense_query(query: Vector) -> VectorList:
    if not isinstance(query, list) or not query:
        raise ValueError("query must be a non-empty list[float]")
    if not all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in query):
        raise TypeError("query must be a list[float]")
    return [float(value) for value in query]


def _ensure_dense_queries(queries: VectorList) -> VectorList:
    if not isinstance(queries, list) or not queries:
        raise ValueError("queries must be a non-empty list[list[float]]")
    dense_queries = []
    for query in queries:
        dense_queries.append(_ensure_dense_query(query))
    return dense_queries


def _ensure_sparse_query(query: SparseVector) -> SparseVectorList:
    if not isinstance(query, str) or not query:
        raise ValueError("query must be a non-empty sparse vector string")
    return [query]


def _ensure_sparse_queries(queries: SparseVectorList) -> SparseVectorList:
    if not isinstance(queries, list) or not queries:
        raise ValueError("queries must be a non-empty list[str]")
    if not all(isinstance(query, str) and query for query in queries):
        raise TypeError("queries must be a list[str]")
    return queries


def _validate_current_hybrid_batch_support(
    dense_queries: VectorList, sparse_queries: SparseVectorList
) -> None:
    if len(dense_queries) != len(sparse_queries):
        raise ValueError("dense_queries and sparse_queries must have the same length")
    if len(dense_queries) != 1:
        raise ValueError(
            "hybrid_search_batch currently supports exactly one dense and one sparse query"
        )


class Table:
    """Sync table handle."""

    def __init__(self, coral: "Coral", table_name: str):
        self._db = coral
        self._name = table_name

    @property
    def name(self) -> str:
        return self._name

    def schema(self) -> TableSchema:
        return self._db._get_table_schema(self._name)

    def index(self, name: str) -> Index:
        return Index(self, name)

    def insert_rows(
        self,
        rows: List[Dict[str, Any]],
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        return self._db._insert_rows(
            self._name,
            rows,
            reader_batch_size=reader_batch_size,
            use_async_read=use_async_read,
        )

    def insert_jsonl(
        self,
        jsonl: str,
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        return self._db._insert_jsonl(
            self._name,
            jsonl,
            reader_batch_size=reader_batch_size,
            use_async_read=use_async_read,
        )

    def insert_arrow(self, data: Any) -> InsertResult:
        return self._db._insert_arrow(self._name, data)

    def insert_parquet(
        self,
        source: Any,
        *,
        batch_size: Optional[int] = None,
        options: Optional[ImportOptions] = None,
    ) -> InsertResult:
        return self._db._insert_parquet(
            self._name,
            source,
            batch_size=batch_size,
            options=options,
        )

    def import_files(
        self,
        request: FileSource,
        *,
        options: Optional[ImportOptions] = None,
        strict: bool = True,
    ) -> ImportFilesResult:
        return self._db._import_files(self._name, request, options=options, strict=strict)

    def scan(
        self,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> ResultSet:
        return self._db._scan(
            self._name,
            select=select,
            where=where,
            limit=limit,
            include_metrics=include_metrics,
            allow_writer=allow_writer,
        )

    def scan_stream(
        self,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> RecordBatchStream:
        return self._db._scan_stream(
            self._name,
            select=select,
            where=where,
            limit=limit,
            include_metrics=include_metrics,
            allow_writer=allow_writer,
        )

    def hybrid_search(
        self,
        *,
        dense_column: str,
        dense_query: Vector,
        sparse_column: str,
        sparse_query: SparseVector,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSet:
        return self._db._hybrid_search(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=_ensure_dense_query(dense_query),
            sparse_column=sparse_column,
            sparse_queries=_ensure_sparse_query(sparse_query),
            options=options,
        )

    def hybrid_search_batch(
        self,
        *,
        dense_column: str,
        dense_queries: VectorList,
        sparse_column: str,
        sparse_queries: SparseVectorList,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSets:
        normalized_dense = _ensure_dense_queries(dense_queries)
        normalized_sparse = _ensure_sparse_queries(sparse_queries)
        _validate_current_hybrid_batch_support(normalized_dense, normalized_sparse)

        return self._db._hybrid_search_batch(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=normalized_dense,
            sparse_column=sparse_column,
            sparse_queries=normalized_sparse,
            options=options,
        )

    def hybrid_search_stream(
        self,
        *,
        dense_column: str,
        dense_query: Vector,
        sparse_column: str,
        sparse_query: SparseVector,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> RecordBatchStream:
        return self._db._hybrid_search_stream(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=_ensure_dense_query(dense_query),
            sparse_column=sparse_column,
            sparse_queries=_ensure_sparse_query(sparse_query),
            options=options,
        )

    def hybrid_search_batch_stream(
        self,
        *,
        dense_column: str,
        dense_queries: VectorList,
        sparse_column: str,
        sparse_queries: SparseVectorList,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSetStream:
        normalized_dense = _ensure_dense_queries(dense_queries)
        normalized_sparse = _ensure_sparse_queries(sparse_queries)
        _validate_current_hybrid_batch_support(normalized_dense, normalized_sparse)

        return self._db._hybrid_search_batch_stream(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=normalized_dense,
            sparse_column=sparse_column,
            sparse_queries=normalized_sparse,
            options=options,
        )

    def indexed_row_count(self, *, readable: bool = True) -> IndexedCounts:
        return self._db._get_indexed_row_count(self._name, readable=readable)

    def update_rows(self, values: str, *, where: Optional[str] = None) -> None:
        self._db._update_rows(self._name, values, where=where)

    def delete_rows(self, *, where: Optional[str] = None) -> None:
        self._db._delete_rows(self._name, where=where)

    def active_set_flush(
        self,
        segment_ids: Optional[List[str]] = None,
        sync_mode: str = "async",
    ) -> ActiveSetFlushResult:
        return self._db._active_set_flush(
            self._name,
            segment_ids=segment_ids,
            sync_mode=sync_mode,
        )

    def segments_status(self) -> SegmentsStatusResult:
        return self._db._segments_status(self._name)

    def segments_retry(
        self,
        *,
        mode: str = "auto",
        only_failed: bool = True,
        skip_unsubscribed: bool = True,
        dry_run: bool = False,
        max_targets: Optional[int] = None,
    ) -> SegmentsRetryResult:
        return self._db._segments_retry(
            self._name,
            mode=mode,
            only_failed=only_failed,
            skip_unsubscribed=skip_unsubscribed,
            dry_run=dry_run,
            max_targets=max_targets,
        )

    def rebalance_plan(
        self,
        *,
        reader_nodes: Optional[List[str]] = None,
        writer_nodes: Optional[List[str]] = None,
        strategy: Optional[str] = None,
    ) -> RebalancePlanResult:
        return self._db._rebalance_plan(
            self._name,
            reader_nodes=reader_nodes,
            writer_nodes=writer_nodes,
            strategy=strategy,
        )

    def rebalance_commit(
        self, request: RebalanceCommitRequest
    ) -> RebalanceCommitResult:
        return self._db._rebalance_commit(self._name, request)

    def rebalance_status(self) -> RebalanceStatusResult:
        return self._db._rebalance_status(self._name)

    def drop(self) -> bool:
        return self._db.drop_table(self._name)

    def __repr__(self) -> str:
        return f"Table(name='{self._name}')"


class AsyncTable:
    """Async table handle."""

    def __init__(self, coral: "AsyncCoral", table_name: str):
        self._db = coral
        self._name = table_name

    @property
    def name(self) -> str:
        return self._name

    async def schema(self) -> TableSchema:
        return await self._db._get_table_schema(self._name)

    def index(self, name: str) -> AsyncIndex:
        return AsyncIndex(self, name)

    async def insert_rows(
        self,
        rows: List[Dict[str, Any]],
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        return await self._db._insert_rows(
            self._name,
            rows,
            reader_batch_size=reader_batch_size,
            use_async_read=use_async_read,
        )

    async def insert_jsonl(
        self,
        jsonl: str,
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        return await self._db._insert_jsonl(
            self._name,
            jsonl,
            reader_batch_size=reader_batch_size,
            use_async_read=use_async_read,
        )

    async def insert_arrow(self, data: Any) -> InsertResult:
        return await self._db._insert_arrow(self._name, data)

    async def insert_parquet(
        self,
        source: Any,
        *,
        batch_size: Optional[int] = None,
        options: Optional[ImportOptions] = None,
    ) -> InsertResult:
        return await self._db._insert_parquet(
            self._name,
            source,
            batch_size=batch_size,
            options=options,
        )

    async def import_files(
        self,
        request: FileSource,
        *,
        options: Optional[ImportOptions] = None,
        strict: bool = True,
    ) -> ImportFilesResult:
        return await self._db._import_files(
            self._name,
            request,
            options=options,
            strict=strict,
        )

    async def scan(
        self,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> ResultSet:
        return await self._db._scan(
            self._name,
            select=select,
            where=where,
            limit=limit,
            include_metrics=include_metrics,
            allow_writer=allow_writer,
        )

    async def scan_stream(
        self,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> RecordBatchStream:
        return await self._db._scan_stream(
            self._name,
            select=select,
            where=where,
            limit=limit,
            include_metrics=include_metrics,
            allow_writer=allow_writer,
        )

    async def hybrid_search(
        self,
        *,
        dense_column: str,
        dense_query: Vector,
        sparse_column: str,
        sparse_query: SparseVector,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSet:
        return await self._db._hybrid_search(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=_ensure_dense_query(dense_query),
            sparse_column=sparse_column,
            sparse_queries=_ensure_sparse_query(sparse_query),
            options=options,
        )

    async def hybrid_search_batch(
        self,
        *,
        dense_column: str,
        dense_queries: VectorList,
        sparse_column: str,
        sparse_queries: SparseVectorList,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSets:
        normalized_dense = _ensure_dense_queries(dense_queries)
        normalized_sparse = _ensure_sparse_queries(sparse_queries)
        _validate_current_hybrid_batch_support(normalized_dense, normalized_sparse)

        return await self._db._hybrid_search_batch(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=normalized_dense,
            sparse_column=sparse_column,
            sparse_queries=normalized_sparse,
            options=options,
        )

    async def hybrid_search_stream(
        self,
        *,
        dense_column: str,
        dense_query: Vector,
        sparse_column: str,
        sparse_query: SparseVector,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> RecordBatchStream:
        return await self._db._hybrid_search_stream(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=_ensure_dense_query(dense_query),
            sparse_column=sparse_column,
            sparse_queries=_ensure_sparse_query(sparse_query),
            options=options,
        )

    async def hybrid_search_batch_stream(
        self,
        *,
        dense_column: str,
        dense_queries: VectorList,
        sparse_column: str,
        sparse_queries: SparseVectorList,
        top_k: int = 10,
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSetStream:
        normalized_dense = _ensure_dense_queries(dense_queries)
        normalized_sparse = _ensure_sparse_queries(sparse_queries)
        _validate_current_hybrid_batch_support(normalized_dense, normalized_sparse)

        return await self._db._hybrid_search_batch_stream(
            self._name,
            top_k=top_k,
            dense_column=dense_column,
            dense_queries=normalized_dense,
            sparse_column=sparse_column,
            sparse_queries=normalized_sparse,
            options=options,
        )

    async def indexed_row_count(self, *, readable: bool = True) -> IndexedCounts:
        return await self._db._get_indexed_row_count(self._name, readable=readable)

    async def update_rows(self, values: str, *, where: Optional[str] = None) -> None:
        await self._db._update_rows(self._name, values, where=where)

    async def delete_rows(self, *, where: Optional[str] = None) -> None:
        await self._db._delete_rows(self._name, where=where)

    async def active_set_flush(
        self,
        segment_ids: Optional[List[str]] = None,
        sync_mode: str = "async",
    ) -> ActiveSetFlushResult:
        return await self._db._active_set_flush(
            self._name,
            segment_ids=segment_ids,
            sync_mode=sync_mode,
        )

    async def segments_status(self) -> SegmentsStatusResult:
        return await self._db._segments_status(self._name)

    async def segments_retry(
        self,
        *,
        mode: str = "auto",
        only_failed: bool = True,
        skip_unsubscribed: bool = True,
        dry_run: bool = False,
        max_targets: Optional[int] = None,
    ) -> SegmentsRetryResult:
        return await self._db._segments_retry(
            self._name,
            mode=mode,
            only_failed=only_failed,
            skip_unsubscribed=skip_unsubscribed,
            dry_run=dry_run,
            max_targets=max_targets,
        )

    async def rebalance_plan(
        self,
        *,
        reader_nodes: Optional[List[str]] = None,
        writer_nodes: Optional[List[str]] = None,
        strategy: Optional[str] = None,
    ) -> RebalancePlanResult:
        return await self._db._rebalance_plan(
            self._name,
            reader_nodes=reader_nodes,
            writer_nodes=writer_nodes,
            strategy=strategy,
        )

    async def rebalance_commit(
        self, request: RebalanceCommitRequest
    ) -> RebalanceCommitResult:
        return await self._db._rebalance_commit(self._name, request)

    async def rebalance_status(self) -> RebalanceStatusResult:
        return await self._db._rebalance_status(self._name)

    async def drop(self) -> bool:
        return await self._db.drop_table(self._name)

    def __repr__(self) -> str:
        return f"AsyncTable(name='{self._name}')"
