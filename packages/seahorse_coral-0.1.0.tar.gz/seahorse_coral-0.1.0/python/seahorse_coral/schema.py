"""
Schema builder utilities for Seahorse Coral Client.

This module provides convenient ways to build table schemas for the
CreateTableRequest API format.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# =============================================================================
# Enums
# =============================================================================


class ScalarType(Enum):
    """Scalar data types for table columns."""

    INT64 = "INT64"
    FLOAT64 = "FLOAT64"
    BOOL = "BOOL"
    STRING = "STRING"


class VectorElement(Enum):
    """Element types for vector columns."""

    FLOAT32 = "FLOAT32"


class IndexType(Enum):
    """Index types."""

    HNSW = "HNSW"
    DISKBASED = "DISKBASED"
    INVERTED = "INVERTED"


class IndexSpace(Enum):
    """Vector index space/distance metrics."""

    L2 = "l2"
    COSINE = "cosine"
    IP = "ip"  # Inner product

    @classmethod
    def parse(cls, value: Any) -> "IndexSpace":
        if isinstance(value, cls):
            return value

        normalized = str(value).strip().lower()
        aliases = {
            "l2": cls.L2,
            "l2space": cls.L2,
            "cosine": cls.COSINE,
            "cosinespace": cls.COSINE,
            "ip": cls.IP,
            "ipspace": cls.IP,
            "inner_product": cls.IP,
            "dot": cls.IP,
        }
        try:
            return aliases[normalized]
        except KeyError as exc:
            raise ValueError(f"{value!r} is not a valid IndexSpace") from exc


class SegmentationStrategy(Enum):
    """Segmentation strategies."""

    VALUE = "value"
    HASH = "hash"


class SegmentationComposition(Enum):
    """Segmentation composition types."""

    SINGLE = "single"
    COMPOSITE = "composite"
    HIERARCHICAL = "hierarchical"


# =============================================================================
# Column Types
# =============================================================================


@dataclass
class Column:
    """Column definition for table schema."""

    name: str
    type: Any  # ScalarType or VectorType dict
    nullable: bool = True
    max_length: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format."""
        result: Dict[str, Any] = {"name": self.name, "nullable": self.nullable}

        if isinstance(self.type, ScalarType):
            result["type"] = self.type.value
        elif isinstance(self.type, dict):
            # Vector type
            result["type"] = self.type
        else:
            result["type"] = self.type

        if self.max_length is not None:
            result["max_length"] = self.max_length

        return result

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "Column":
        column_type = value.get("type")
        parsed_type: Any

        if isinstance(column_type, str):
            parsed_type = ScalarType(column_type)
        elif isinstance(column_type, dict):
            vector_name = str(column_type.get("name", "")).upper()
            if vector_name in {"DENSE_VECTOR", "VECTOR"}:
                parsed_type = {
                    "name": "DENSE_VECTOR",
                    "element": str(column_type.get("element", "FLOAT32")).upper(),
                    "dim": int(column_type.get("dim", 0)),
                }
            elif vector_name == "SPARSE_VECTOR":
                parsed_type = {"name": "SPARSE_VECTOR"}
            else:
                raise ValueError(f"Unsupported vector type: {column_type}")
        else:
            raise ValueError(f"Unsupported column type: {column_type}")

        return cls(
            name=str(value.get("name", "")),
            type=parsed_type,
            nullable=bool(value.get("nullable", True)),
            max_length=value.get("max_length"),
        )


# =============================================================================
# Index Definition
# =============================================================================


@dataclass
class IndexParams:
    """Parameters for index configuration."""

    space: Optional[IndexSpace] = None
    ef_construction: Optional[int] = None
    M: Optional[int] = None
    sparse_model: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format."""
        result: Dict[str, Any] = {}
        if self.space is not None:
            result["space"] = self.space.value
        if self.ef_construction is not None:
            result["ef_construction"] = self.ef_construction
        if self.M is not None:
            result["M"] = self.M
        if self.sparse_model is not None:
            result["sparse_model"] = self.sparse_model
        return result

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "IndexParams":
        space = value.get("space")
        return cls(
            space=IndexSpace.parse(space) if space is not None else None,
            ef_construction=value.get("ef_construction"),
            M=value.get("M"),
            sparse_model=value.get("sparse_model"),
        )


@dataclass
class IndexDefinition:
    """Index definition for table schema."""

    type: IndexType
    column: str
    params: Optional[IndexParams] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format."""
        result: Dict[str, Any] = {
            "type": self.type.value,
            "column": self.column,
        }
        if self.params is not None:
            params_dict = self.params.to_dict()
            if params_dict:
                result["params"] = params_dict
        return result

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "IndexDefinition":
        params = value.get("params")
        return cls(
            type=IndexType(str(value.get("type", "")).upper()),
            column=str(value.get("column", "")),
            params=IndexParams.from_dict(params) if isinstance(params, dict) else None,
        )


# Short alias for convenience
IndexDef = IndexDefinition


# =============================================================================
# Segmentation
# =============================================================================


@dataclass
class Segmentation:
    """Segmentation configuration for table schema."""

    strategy: SegmentationStrategy
    columns: List[str]
    buckets: Optional[int] = None
    composition: Optional[SegmentationComposition] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format."""
        result: Dict[str, Any] = {
            "strategy": self.strategy.value,
            "columns": self.columns,
        }
        if self.buckets is not None:
            result["buckets"] = self.buckets
        if self.composition is not None:
            result["composition"] = self.composition.value
        return result

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "Segmentation":
        composition = value.get("composition")
        return cls(
            strategy=SegmentationStrategy(str(value.get("strategy", "")).lower()),
            columns=[str(column) for column in value.get("columns", [])],
            buckets=value.get("buckets"),
            composition=SegmentationComposition(str(composition).lower())
            if composition is not None
            else None,
        )


# =============================================================================
# Configurations
# =============================================================================


@dataclass
class TableConfigurations:
    """Performance and tuning configurations."""

    active_set_size_limit: Optional[int] = None
    max_threads: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format."""
        result: Dict[str, Any] = {}
        if self.active_set_size_limit is not None:
            result["active_set_size_limit"] = self.active_set_size_limit
        if self.max_threads is not None:
            result["max_threads"] = self.max_threads
        return result

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableConfigurations":
        return cls(
            active_set_size_limit=value.get("active_set_size_limit"),
            max_threads=value.get("max_threads"),
        )


@dataclass
class AssignedNodes:
    """Node assignment for table placement."""

    writer_nodes: List[str]
    reader_nodes: List[str]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format."""
        return {
            "writer_nodes": self.writer_nodes,
            "reader_nodes": self.reader_nodes,
        }

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "AssignedNodes":
        return cls(
            writer_nodes=[str(node) for node in value.get("writer_nodes", [])],
            reader_nodes=[str(node) for node in value.get("reader_nodes", [])],
        )


@dataclass
class TablePlacement:
    """Data placement and node assignment."""

    assigned_nodes: Optional[AssignedNodes] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format."""
        result: Dict[str, Any] = {}
        if self.assigned_nodes is not None:
            result["assigned_nodes"] = self.assigned_nodes.to_dict()
        return result

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TablePlacement":
        assigned_nodes = value.get("assigned_nodes")
        return cls(
            assigned_nodes=AssignedNodes.from_dict(assigned_nodes)
            if isinstance(assigned_nodes, dict)
            else None
        )


# =============================================================================
# Schema Builder
# =============================================================================


class SchemaBuilder:
    """
    Builder class for creating table schemas.

    This provides a Pythonic way to define table schemas that match
    the CreateTableRequest API format.

    Example:
        >>> schema = SchemaBuilder(
        ...     columns=[
        ...         int64_column("id", nullable=False),
        ...         string_column("title"),
        ...         vector_column("embedding", dim=768)
        ...     ],
        ...     primary_key=["id"],
        ...     indexes=[
        ...         hnsw_index("embedding", space=IndexSpace.L2)
        ...     ],
        ...     segmentation=value_segmentation(["id"]),
        ...     configurations=TableConfigurations(active_set_size_limit=200000)
        ... )
    """

    def __init__(
        self,
        columns: Optional[List[Column]] = None,
        primary_key: Optional[List[str]] = None,
        segmentation: Optional[Segmentation] = None,
        indexes: Optional[List[IndexDefinition]] = None,
        configurations: Optional[TableConfigurations] = None,
        placement: Optional[TablePlacement] = None,
    ):
        self.columns = list(columns) if columns is not None else []
        self.primary_key = primary_key
        self.segmentation = segmentation
        self.indexes = indexes
        self.configurations = configurations
        self.placement = placement

    # -------------------------------------------------------------------------
    # Fluent / chainable builder helpers
    # -------------------------------------------------------------------------

    def add_column(self, column: Column) -> "SchemaBuilder":
        """Append a column definition."""
        self.columns.append(column)
        return self

    def add_columns(self, columns: List[Column]) -> "SchemaBuilder":
        """Append multiple column definitions."""
        self.columns.extend(columns)
        return self

    def int64(self, name: str, nullable: bool = True) -> "SchemaBuilder":
        return self.add_column(int64_column(name, nullable=nullable))

    def float64(self, name: str, nullable: bool = True) -> "SchemaBuilder":
        return self.add_column(float64_column(name, nullable=nullable))

    def bool(self, name: str, nullable: bool = True) -> "SchemaBuilder":
        return self.add_column(bool_column(name, nullable=nullable))

    def string(
        self, name: str, nullable: bool = True, max_length: Optional[int] = None
    ) -> "SchemaBuilder":
        return self.add_column(
            string_column(name, nullable=nullable, max_length=max_length)
        )

    def vector(
        self,
        name: str,
        dim: int,
        element: VectorElement = VectorElement.FLOAT32,
        nullable: bool = False,
    ) -> "SchemaBuilder":
        return self.add_column(
            vector_column(name, dim=dim, element=element, nullable=nullable)
        )

    def sparse_vector(self, name: str, nullable: bool = False) -> "SchemaBuilder":
        return self.add_column(sparse_vector_column(name, nullable=nullable))

    def metadata(
        self,
        name: str = "metadata",
        nullable: bool = True,
        max_length: Optional[int] = None,
    ) -> "SchemaBuilder":
        """Add a metadata column (stored as STRING, typically JSON-encoded)."""
        return self.add_column(metadata_column(name, nullable=nullable, max_length=max_length))

    def with_primary_key(self, *columns: str) -> "SchemaBuilder":
        self.primary_key = list(columns)
        return self

    def with_segmentation(self, segmentation: Segmentation) -> "SchemaBuilder":
        self.segmentation = segmentation
        return self

    def add_index(self, index: IndexDefinition) -> "SchemaBuilder":
        if self.indexes is None:
            self.indexes = []
        self.indexes.append(index)
        return self

    def hnsw(
        self,
        column: str,
        space: IndexSpace = IndexSpace.L2,
        ef_construction: int = 200,
        M: int = 16,
    ) -> "SchemaBuilder":
        return self.add_index(
            hnsw_index(column, space=space, ef_construction=ef_construction, M=M)
        )

    def diskbased(
        self,
        column: str,
        space: IndexSpace = IndexSpace.L2,
        ef_construction: int = 200,
        M: int = 16,
    ) -> "SchemaBuilder":
        return self.add_index(
            diskbased_index(column, space=space, ef_construction=ef_construction, M=M)
        )

    def inverted(self, column: str, sparse_model: Optional[str] = None) -> "SchemaBuilder":
        return self.add_index(inverted_index(column, sparse_model=sparse_model))

    def with_configurations(
        self, configurations: TableConfigurations
    ) -> "SchemaBuilder":
        self.configurations = configurations
        return self

    def with_placement(self, placement: TablePlacement) -> "SchemaBuilder":
        self.placement = placement
        return self

    def validate(self) -> None:
        """Validate schema consistency before sending it to the server."""
        if not self.columns:
            raise ValueError("SchemaBuilder.columns must not be empty")

        column_names = [c.name for c in self.columns]
        if len(set(column_names)) != len(column_names):
            raise ValueError(f"Duplicate column names found: {column_names}")

        for c in self.columns:
            if c.max_length is None:
                continue
            if not isinstance(c.max_length, int):
                raise ValueError(
                    f"max_length for column '{c.name}' must be an int, got {type(c.max_length)}"
                )
            if c.max_length <= 0:
                raise ValueError(
                    f"max_length for STRING column '{c.name}' must be > 0, got {c.max_length}"
                )
            if not (isinstance(c.type, ScalarType) and c.type == ScalarType.STRING):
                raise ValueError(
                    f"max_length is only supported for STRING columns (column '{c.name}')"
                )

        column_set = set(column_names)

        if self.primary_key is not None:
            missing = [c for c in self.primary_key if c not in column_set]
            if missing:
                raise ValueError(f"primary_key references unknown columns: {missing}")

        if self.segmentation is not None:
            missing = [c for c in self.segmentation.columns if c not in column_set]
            if missing:
                raise ValueError(f"segmentation references unknown columns: {missing}")
            if self.segmentation.strategy == SegmentationStrategy.HASH:
                if len(self.segmentation.columns) != 1:
                    raise ValueError("HASH segmentation requires exactly one column")
                if self.segmentation.buckets is None:
                    raise ValueError("HASH segmentation requires buckets")

        if self.indexes is not None:
            missing = [i.column for i in self.indexes if i.column not in column_set]
            if missing:
                raise ValueError(f"indexes reference unknown columns: {missing}")

    def to_dict(self, table_name: str = "") -> Dict[str, Any]:
        """
        Convert schema to CreateTableRequest format.

        Args:
            table_name: Optional table name (usually set by Coral.table(..., schema=...))

        Returns:
            Dictionary matching CreateTableRequest format
        """
        result: Dict[str, Any] = {
            "table_name": table_name,
            "columns": [col.to_dict() for col in self.columns],
        }

        if self.primary_key is not None:
            result["primary_key"] = self.primary_key

        if self.segmentation is not None:
            result["segmentation"] = self.segmentation.to_dict()

        if self.indexes is not None:
            result["indexes"] = [idx.to_dict() for idx in self.indexes]

        if self.configurations is not None:
            config_dict = self.configurations.to_dict()
            if config_dict:
                result["configurations"] = config_dict

        if self.placement is not None:
            placement_dict = self.placement.to_dict()
            if placement_dict:
                result["placement"] = placement_dict

        return result

    def to_json(self, table_name: str = "") -> str:
        """Convert schema to JSON string."""
        import json

        return json.dumps(self.to_dict(table_name), indent=2)

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SchemaBuilder":
        return cls(
            columns=[Column.from_dict(column) for column in value.get("columns", [])],
            primary_key=[str(column) for column in value.get("primary_key", [])]
            if value.get("primary_key") is not None
            else None,
            segmentation=Segmentation.from_dict(value["segmentation"])
            if isinstance(value.get("segmentation"), dict)
            else None,
            indexes=[IndexDefinition.from_dict(index) for index in value.get("indexes", [])]
            if value.get("indexes") is not None
            else None,
            configurations=TableConfigurations.from_dict(value["configurations"])
            if isinstance(value.get("configurations"), dict)
            else None,
            placement=TablePlacement.from_dict(value["placement"])
            if isinstance(value.get("placement"), dict)
            else None,
        )


# =============================================================================
# Column Helper Functions
# =============================================================================


def int64_column(name: str, nullable: bool = True) -> Column:
    """Create a 64-bit integer column."""
    return Column(name=name, type=ScalarType.INT64, nullable=nullable)


def float64_column(name: str, nullable: bool = True) -> Column:
    """Create a 64-bit float column."""
    return Column(name=name, type=ScalarType.FLOAT64, nullable=nullable)


def bool_column(name: str, nullable: bool = True) -> Column:
    """Create a boolean column."""
    return Column(name=name, type=ScalarType.BOOL, nullable=nullable)


def string_column(
    name: str, nullable: bool = True, max_length: Optional[int] = None
) -> Column:
    """Create a string column."""
    return Column(name=name, type=ScalarType.STRING, nullable=nullable, max_length=max_length)


def metadata_column(
    name: str = "metadata", nullable: bool = True, max_length: Optional[int] = None
) -> Column:
    """Create a metadata column (stored as STRING, typically JSON-encoded)."""
    return string_column(name, nullable=nullable, max_length=max_length)


def vector_column(
    name: str,
    dim: int,
    element: VectorElement = VectorElement.FLOAT32,
    nullable: bool = False,
) -> Column:
    """
    Create a dense vector column.

    Args:
        name: Column name
        dim: Vector dimension
        element: Element type (default: FLOAT32)
        nullable: Whether the column is nullable
    """
    return Column(
        name=name,
        type={"name": "DENSE_VECTOR", "element": element.value, "dim": dim},
        nullable=nullable,
    )


def sparse_vector_column(name: str, nullable: bool = True) -> Column:
    """Create a sparse vector column."""
    return Column(name=name, type={"name": "SPARSE_VECTOR"}, nullable=nullable)


# =============================================================================
# Index Helper Functions
# =============================================================================


def hnsw_index(
    column: str,
    space: IndexSpace = IndexSpace.L2,
    ef_construction: int = 200,
    M: int = 16,
) -> IndexDefinition:
    """
    Create an HNSW index.

    Args:
        column: Target column name
        space: Distance metric (L2, COSINE, IP)
        ef_construction: ef_construction parameter
        M: M parameter
    """
    return IndexDefinition(
        type=IndexType.HNSW,
        column=column,
        params=IndexParams(space=space, ef_construction=ef_construction, M=M),
    )


def diskbased_index(
    column: str,
    space: IndexSpace = IndexSpace.L2,
    ef_construction: int = 200,
    M: int = 16,
) -> IndexDefinition:
    """
    Create a disk-based index.

    Args:
        column: Target column name
        space: Distance metric
        ef_construction: ef_construction parameter
        M: M parameter
    """
    return IndexDefinition(
        type=IndexType.DISKBASED,
        column=column,
        params=IndexParams(space=space, ef_construction=ef_construction, M=M),
    )


def inverted_index(column: str, sparse_model: Optional[str] = None) -> IndexDefinition:
    """
    Create an inverted index (for sparse vectors).

    Args:
        column: Target column name
        sparse_model: Optional sparse model name (e.g., "BM25")
    """
    params = IndexParams(sparse_model=sparse_model) if sparse_model else None
    return IndexDefinition(type=IndexType.INVERTED, column=column, params=params)


# =============================================================================
# Segmentation Helper Functions
# =============================================================================


def value_segmentation(
    columns: List[str], composition: Optional[SegmentationComposition] = None
) -> Segmentation:
    """
    Create value-based segmentation.

    Args:
        columns: Column names for segmentation
        composition: Composition type (auto-detected if not specified)
    """
    if composition is None:
        if len(columns) == 1:
            composition = SegmentationComposition.SINGLE
        else:
            composition = SegmentationComposition.COMPOSITE

    return Segmentation(
        strategy=SegmentationStrategy.VALUE,
        columns=columns,
        composition=composition,
    )


def hash_segmentation(columns: List[str], buckets: int = 12) -> Segmentation:
    """
    Create hash-based segmentation.

    Args:
        columns: Column names for segmentation (single column only)
        buckets: Number of buckets
    """
    if len(columns) != 1:
        raise ValueError("Hash segmentation only supports single column")

    return Segmentation(
        strategy=SegmentationStrategy.HASH,
        columns=columns,
        buckets=buckets,
        composition=SegmentationComposition.SINGLE,
    )


# =============================================================================
# Preset schemas (for onboarding / happy path)
# =============================================================================


def default_vector_table_schema(
    dim: int,
    *,
    id_name: str = "id",
    id_type: ScalarType = ScalarType.INT64,
    vector_name: str = "vector",
    metadata_name: str = "metadata",
    space: IndexSpace = IndexSpace.L2,
    ef_construction: int = 200,
    M: int = 16,
) -> SchemaBuilder:
    """
    Create a default schema for a vector table with three columns:
    - id: INT64 (non-nullable)
    - vector: DENSE_VECTOR (non-nullable)
    - metadata: STRING (nullable, typically JSON-encoded)
    """
    if id_type not in (ScalarType.INT64, ScalarType.STRING):
        raise ValueError("id_type must be ScalarType.INT64 or ScalarType.STRING")

    id_column = (
        int64_column(id_name, nullable=False)
        if id_type == ScalarType.INT64
        else string_column(id_name, nullable=False)
    )

    schema = SchemaBuilder(
        columns=[
            id_column,
            vector_column(vector_name, dim=dim, nullable=False),
            metadata_column(metadata_name, nullable=True),
        ],
        primary_key=[id_name],
        indexes=[hnsw_index(vector_name, space=space, ef_construction=ef_construction, M=M)],
    )
    schema.validate()
    return schema


# Backward/shorter alias
DefaultVectorTableSchema = default_vector_table_schema


def default_vector_table_schema_string_id(
    dim: int,
    *,
    id_name: str = "id",
    vector_name: str = "vector",
    metadata_name: str = "metadata",
    space: IndexSpace = IndexSpace.L2,
    ef_construction: int = 200,
    M: int = 16,
) -> SchemaBuilder:
    """Same as default_vector_table_schema, but uses STRING primary key."""
    return default_vector_table_schema(
        dim,
        id_name=id_name,
        id_type=ScalarType.STRING,
        vector_name=vector_name,
        metadata_name=metadata_name,
        space=space,
        ef_construction=ef_construction,
        M=M,
    )
