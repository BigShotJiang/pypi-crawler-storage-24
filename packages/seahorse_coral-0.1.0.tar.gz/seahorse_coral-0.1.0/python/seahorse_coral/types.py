"""
Seahorse Coral Client Types

Type definitions and data classes for the Seahorse Coral client.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterator, List, Optional, Sequence

from .schema import SchemaBuilder

# Type aliases for better readability
Vector = List[float]
VectorList = List[Vector]
Metadata = Dict[str, Any]

# Sparse vector format used by SeahorseDB (e.g. "1:0.5 2:0.3")
SparseVector = str
SparseVectorList = List[SparseVector]


@dataclass
class TableInfo:
    """Summary information about a table."""

    table_name: str
    schema: Optional[SchemaBuilder] = None


@dataclass
class TableSchema:
    """Table schema information."""

    table_name: str
    schema: SchemaBuilder


@dataclass
class NodeCheckpoint:
    last_set_number: Optional[int]
    set_versions: List[str]
    set_index_counts: Dict[str, List[str]]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "NodeCheckpoint":
        return cls(
            last_set_number=value.get("last_set_number"),
            set_versions=[str(item) for item in value.get("set_versions", [])],
            set_index_counts={
                str(key): [str(entry) for entry in entries]
                for key, entries in value.get("set_index_counts", {}).items()
            },
        )


@dataclass
class SegmentAssignment:
    segment_oid: str
    status: str
    failure_reason: str
    checkpoint: NodeCheckpoint

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentAssignment":
        return cls(
            segment_oid=str(value.get("segment_oid", "")),
            status=str(value.get("status", "UNKNOWN")),
            failure_reason=str(value.get("failure_reason", "")),
            checkpoint=NodeCheckpoint.from_dict(value.get("checkpoint", {})),
        )


@dataclass
class TableAssignment:
    table_oid: str
    segments: Dict[str, SegmentAssignment]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableAssignment":
        return cls(
            table_oid=str(value.get("table_oid", "")),
            segments={
                str(segment_id): SegmentAssignment.from_dict(segment)
                for segment_id, segment in value.get("segments", {}).items()
            },
        )


@dataclass
class NodeInfo:
    node_id: str
    version: int
    format_version: int
    node_type: str
    state: str
    node_stage: str
    last_updated: str
    node_address: str
    assigned_tables: Dict[str, TableAssignment]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "NodeInfo":
        node_payload = value.get("node_info", value)
        return cls(
            node_id=str(value.get("node_id", node_payload.get("node_id", ""))),
            version=int(node_payload.get("version", 0)),
            format_version=int(node_payload.get("format_version", 0)),
            node_type=str(node_payload.get("type", node_payload.get("node_type", ""))),
            state=str(node_payload.get("state", "")),
            node_stage=str(node_payload.get("node_stage", "")),
            last_updated=str(node_payload.get("last_updated", "")),
            node_address=str(node_payload.get("node_address", "")),
            assigned_tables={
                str(table_id): TableAssignment.from_dict(assignment)
                for table_id, assignment in node_payload.get("assigned_tables", {}).items()
            },
        )


@dataclass
class InsertResult:
    """Result of data insertion operation."""

    inserted_record_batches: int
    inserted_row_count: int
    total_inserted_record_batches: int = 0
    total_inserted_row_count: int = 0


@dataclass
class FileImportResult:
    """Per-file result for batch file imports."""

    path: str
    success: bool
    inserted_record_batches: int = 0
    inserted_row_count: int = 0
    error: Optional[str] = None


@dataclass
class ImportFilesResult:
    """Result of a multi-file import request."""

    files: List[FileImportResult]
    total_inserted_record_batches: int
    total_inserted_row_count: int
    elapsed_time: Optional[float] = None
    rss_peak_bytes: Optional[int] = None

    @property
    def succeeded_count(self) -> int:
        return sum(1 for item in self.files if item.success)

    @property
    def failed_count(self) -> int:
        return sum(1 for item in self.files if not item.success)

    @property
    def all_succeeded(self) -> bool:
        return bool(self.files) and self.failed_count == 0

    @property
    def failed_paths(self) -> List[str]:
        return [item.path for item in self.files if not item.success]


@dataclass
class ActiveSetFlushResult:
    """Result of active set flush operation."""

    flushed: List[str]
    failed: List[str]
    skipped: List[str]


@dataclass
class TableOperationSegmentFailure:
    segment_id: str
    status: str
    failure_reason: str

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableOperationSegmentFailure":
        return cls(
            segment_id=str(value.get("segment_id", "")),
            status=str(value.get("status", "UNKNOWN")),
            failure_reason=str(value.get("failure_reason", "")),
        )


@dataclass
class TableOperationNodeFailure:
    node_id: str
    segments: List[TableOperationSegmentFailure]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableOperationNodeFailure":
        return cls(
            node_id=str(value.get("node_id", "")),
            segments=[
                TableOperationSegmentFailure.from_dict(segment)
                for segment in value.get("segments", [])
            ],
        )


@dataclass
class TableOperationFailure:
    summary: str
    detected_at: str
    node_failures: List[TableOperationNodeFailure]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableOperationFailure":
        return cls(
            summary=str(value.get("summary", "")),
            detected_at=str(value.get("detected_at", "")),
            node_failures=[
                TableOperationNodeFailure.from_dict(node)
                for node in value.get("node_failures", [])
            ],
        )


@dataclass
class TableOperationSegmentStatus:
    segment_id: str
    expected: str
    observed: str
    failure_reason: Optional[str] = None

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableOperationSegmentStatus":
        return cls(
            segment_id=str(value.get("segment_id", "")),
            expected=str(value.get("expected", "")),
            observed=str(value.get("observed", "")),
            failure_reason=value.get("failure_reason"),
        )


@dataclass
class TableOperationNodeSegmentStatus:
    node_id: str
    segments: List[TableOperationSegmentStatus]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableOperationNodeSegmentStatus":
        return cls(
            node_id=str(value.get("node_id", "")),
            segments=[
                TableOperationSegmentStatus.from_dict(segment)
                for segment in value.get("segments", [])
            ],
        )


@dataclass
class TableOperationPollingInfo:
    evaluated_at: str
    nodes: List[TableOperationNodeSegmentStatus]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TableOperationPollingInfo":
        return cls(
            evaluated_at=str(value.get("evaluated_at", "")),
            nodes=[
                TableOperationNodeSegmentStatus.from_dict(node)
                for node in value.get("nodes", [])
            ],
        )


@dataclass
class SegmentsStatusSummary:
    total: int
    synced: int
    failed: int
    pending: int

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentsStatusSummary":
        return cls(
            total=int(value.get("total", 0)),
            synced=int(value.get("synced", 0)),
            failed=int(value.get("failed", 0)),
            pending=int(value.get("pending", 0)),
        )


@dataclass
class SegmentsStatusResult:
    table_name: str
    table_status: str
    mode: str
    started_at: Optional[str] = None
    ttl_seconds: Optional[int] = None
    failure: Optional[TableOperationFailure] = None
    polling: Optional[TableOperationPollingInfo] = None
    summary: Optional[SegmentsStatusSummary] = None

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentsStatusResult":
        failure = value.get("failure")
        polling = value.get("polling")
        summary = value.get("summary")
        return cls(
            table_name=str(value.get("table_name", "")),
            table_status=str(value.get("table_status", "")),
            mode=str(value.get("mode", "")),
            started_at=value.get("started_at"),
            ttl_seconds=value.get("ttl_seconds"),
            failure=TableOperationFailure.from_dict(failure) if failure else None,
            polling=TableOperationPollingInfo.from_dict(polling) if polling else None,
            summary=SegmentsStatusSummary.from_dict(summary) if summary else None,
        )


@dataclass
class SegmentsRetrySkipInfo:
    reason: str

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentsRetrySkipInfo":
        return cls(reason=str(value.get("reason", "")))


@dataclass
class SegmentsRetryNodeObservations:
    missing_nodeinfo: bool
    missing_table_assignment: bool
    missing_segment_count: int
    failed_segment_count: int
    synced_segment_count: int
    not_removed_segment_count: int

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentsRetryNodeObservations":
        return cls(
            missing_nodeinfo=bool(value.get("missing_nodeinfo", False)),
            missing_table_assignment=bool(value.get("missing_table_assignment", False)),
            missing_segment_count=int(value.get("missing_segment_count", 0)),
            failed_segment_count=int(value.get("failed_segment_count", 0)),
            synced_segment_count=int(value.get("synced_segment_count", 0)),
            not_removed_segment_count=int(value.get("not_removed_segment_count", 0)),
        )


@dataclass
class SegmentsRetryNodeResult:
    node_id: str
    published_segments: List[str]
    observations: SegmentsRetryNodeObservations
    skipped: Optional[SegmentsRetrySkipInfo] = None

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentsRetryNodeResult":
        skipped = value.get("skipped")
        return cls(
            node_id=str(value.get("node_id", "")),
            published_segments=[str(item) for item in value.get("published_segments", [])],
            observations=SegmentsRetryNodeObservations.from_dict(
                value.get("observations", {})
            ),
            skipped=SegmentsRetrySkipInfo.from_dict(skipped) if skipped else None,
        )


@dataclass
class SegmentsRetrySummary:
    mode: str
    total_nodes: int
    published_segment_count: int
    skipped_node_count: int
    truncated: bool

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentsRetrySummary":
        return cls(
            mode=str(value.get("mode", "")),
            total_nodes=int(value.get("total_nodes", 0)),
            published_segment_count=int(value.get("published_segment_count", 0)),
            skipped_node_count=int(value.get("skipped_node_count", 0)),
            truncated=bool(value.get("truncated", False)),
        )


@dataclass
class SegmentsRetryResult:
    table_name: str
    table_status: str
    summary: SegmentsRetrySummary
    nodes: List[SegmentsRetryNodeResult]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentsRetryResult":
        return cls(
            table_name=str(value.get("table_name", "")),
            table_status=str(value.get("table_status", "")),
            summary=SegmentsRetrySummary.from_dict(value.get("summary", {})),
            nodes=[
                SegmentsRetryNodeResult.from_dict(node)
                for node in value.get("nodes", [])
            ],
        )


@dataclass
class ResultSet:
    """Collect-first Arrow-native representation of a single logical resultset."""

    arrow_ipc: Optional[bytes] = None
    elapsed_time: Optional[float] = None
    rss_peak_bytes: Optional[int] = None
    _record_batches_cache: Optional[List[Any]] = field(
        default=None, init=False, repr=False
    )
    _pyarrow_cache: Optional[Any] = field(default=None, init=False, repr=False)

    @classmethod
    def from_record_batches(
        cls,
        record_batches: List[Any],
        *,
        elapsed_time: Optional[float] = None,
        rss_peak_bytes: Optional[int] = None,
    ) -> "ResultSet":
        result = cls(
            arrow_ipc=None,
            elapsed_time=elapsed_time,
            rss_peak_bytes=rss_peak_bytes,
        )
        result._record_batches_cache = list(record_batches)
        return result

    def to_record_batches(self) -> List[Any]:
        """Return a list of `pyarrow.RecordBatch` objects for this resultset."""
        if self._record_batches_cache is None:
            import pyarrow as pa

            if self.arrow_ipc is None:
                raise ValueError("ResultSet has neither Arrow IPC payload nor cached record batches")

            reader = pa.ipc.open_stream(self.arrow_ipc)
            self._record_batches_cache = list(reader)
        return self._record_batches_cache

    def to_pyarrow(self) -> Any:
        """Return a `pyarrow.Table` for this resultset."""
        if self._pyarrow_cache is None:
            import pyarrow as pa

            self._pyarrow_cache = pa.Table.from_batches(self.to_record_batches())
        return self._pyarrow_cache

    def to_pandas(self) -> Any:
        """Return a `pandas.DataFrame`."""
        return self.to_pyarrow().to_pandas()

    def to_polars(self) -> Any:
        """Return a `polars.DataFrame`."""
        import polars as pl

        return pl.from_arrow(self.to_pyarrow())

    def to_json(self) -> Any:
        """Return a JSON-compatible list of row dictionaries."""
        return self.to_pyarrow().to_pylist()


@dataclass
class ResultSets(Sequence[ResultSet]):
    """Collect-first representation of multiple logical resultsets."""

    arrow_ipc: bytes
    resultset_batch_counts: List[int]
    elapsed_time: Optional[float] = None
    rss_peak_bytes: Optional[int] = None
    _result_sets_cache: Optional[List[ResultSet]] = field(
        default=None, init=False, repr=False
    )

    def _materialize(self) -> List[ResultSet]:
        if self._result_sets_cache is None:
            result_batches = ResultSet(arrow_ipc=self.arrow_ipc).to_record_batches()
            offset = 0
            result_sets: List[ResultSet] = []
            for batch_count in self.resultset_batch_counts:
                next_offset = offset + batch_count
                result_sets.append(
                    ResultSet.from_record_batches(result_batches[offset:next_offset])
                )
                offset = next_offset
            self._result_sets_cache = result_sets
        return self._result_sets_cache

    def __len__(self) -> int:
        return len(self.resultset_batch_counts)

    def __iter__(self) -> Iterator[ResultSet]:
        return iter(self._materialize())

    def __getitem__(self, index: int) -> ResultSet:
        return self._materialize()[index]

    def to_record_batches(self) -> List[List[Any]]:
        return [result_set.to_record_batches() for result_set in self]

    def to_pyarrow(self) -> List[Any]:
        return [result_set.to_pyarrow() for result_set in self]

    def to_pandas(self) -> List[Any]:
        return [result_set.to_pandas() for result_set in self]

    def to_polars(self) -> List[Any]:
        return [result_set.to_polars() for result_set in self]

    def to_json(self) -> List[Any]:
        return [result_set.to_json() for result_set in self]


class RecordBatchStream:
    """Single-resultset stream of `pyarrow.RecordBatch` values."""

    def __init__(
        self,
        native_stream: Any,
        *,
        run_async: Optional[Callable[[Any], Any]] = None,
    ) -> None:
        self._native = native_stream
        self._run_async = run_async
        self._exhausted = False

    @property
    def elapsed_time(self) -> Optional[float]:
        return getattr(self._native, "elapsed_time", None)

    @property
    def rss_peak_bytes(self) -> Optional[int]:
        return getattr(self._native, "rss_peak_bytes", None)

    def __iter__(self) -> "RecordBatchStream":
        return self

    def __next__(self) -> Any:
        if self._run_async is None:
            raise TypeError("RecordBatchStream requires 'async for' in async contexts")

        batch_ipc = self._run_async(lambda: self._native.next_batch())
        if batch_ipc is None:
            self._exhausted = True
            raise StopIteration
        return _decode_single_record_batch(batch_ipc)

    def __aiter__(self) -> "RecordBatchStream":
        return self

    async def __anext__(self) -> Any:
        batch_ipc = await self._native.next_batch()
        if batch_ipc is None:
            self._exhausted = True
            raise StopAsyncIteration
        return _decode_single_record_batch(batch_ipc)

    def close(self) -> None:
        if self._run_async is None:
            raise TypeError("RecordBatchStream.close() is only available in sync contexts")
        self._run_async(lambda: self._native.close())
        self._exhausted = True

    async def aclose(self) -> None:
        await self._native.close()
        self._exhausted = True


class ResultSetStream:
    """Multi-resultset stream that yields `ResultSet` objects."""

    def __init__(
        self,
        native_stream: Any,
        *,
        run_async: Optional[Callable[[Any], Any]] = None,
    ) -> None:
        self._native = native_stream
        self._run_async = run_async
        self._exhausted = False

    @property
    def elapsed_time(self) -> Optional[float]:
        return getattr(self._native, "elapsed_time", None)

    @property
    def rss_peak_bytes(self) -> Optional[int]:
        return getattr(self._native, "rss_peak_bytes", None)

    def __iter__(self) -> "ResultSetStream":
        return self

    def __next__(self) -> ResultSet:
        if self._run_async is None:
            raise TypeError("ResultSetStream requires 'async for' in async contexts")

        resultset_ipc = self._run_async(lambda: self._native.next_resultset())
        if resultset_ipc is None:
            self._exhausted = True
            raise StopIteration
        return ResultSet(arrow_ipc=resultset_ipc)

    def __aiter__(self) -> "ResultSetStream":
        return self

    async def __anext__(self) -> ResultSet:
        resultset_ipc = await self._native.next_resultset()
        if resultset_ipc is None:
            self._exhausted = True
            raise StopAsyncIteration
        return ResultSet(arrow_ipc=resultset_ipc)

    def close(self) -> None:
        if self._run_async is None:
            raise TypeError("ResultSetStream.close() is only available in sync contexts")
        self._run_async(lambda: self._native.close())
        self._exhausted = True

    async def aclose(self) -> None:
        await self._native.close()
        self._exhausted = True


def _decode_single_record_batch(arrow_ipc: bytes) -> Any:
    import pyarrow as pa

    reader = pa.ipc.open_stream(arrow_ipc)
    batches = list(reader)
    if len(batches) != 1:
        raise ValueError(
            f"expected a single record batch payload, got {len(batches)} record batches"
        )
    return batches[0]


@dataclass
class IndexRowCount:
    """Information about indexed row count for a specific index."""

    index_name: str
    index_type: str
    indexed_row_count: int


@dataclass
class IndexedCounts:
    """Information about indexed row counts."""

    total_row_count: int
    indexed_counts: List[IndexRowCount]
    readable: Optional["IndexedCountSummary"] = None


@dataclass
class IndexedCountSummary:
    """Nested indexed row count summary."""

    total_row_count: int
    indexed_counts: List[IndexRowCount]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "IndexedCountSummary":
        return cls(
            total_row_count=int(value.get("total_row_count", 0)),
            indexed_counts=[
                IndexRowCount(
                    index_name=str(item.get("index_name", "")),
                    index_type=str(item.get("index_type", "")),
                    indexed_row_count=int(item.get("indexed_row_count", 0)),
                )
                for item in value.get("indexed_counts", [])
            ],
        )


@dataclass
class RebalanceNodeLoad:
    node_id: str
    count: int

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalanceNodeLoad":
        return cls(
            node_id=str(value.get("node_id", "")),
            count=int(value.get("count", 0)),
        )


@dataclass
class RebalancePlanSummary:
    total_segments: int
    writer_moves: int
    reader_moves: int
    unchanged_count: int
    writer_load_before: List[RebalanceNodeLoad]
    writer_load_after: List[RebalanceNodeLoad]
    reader_load_before: List[RebalanceNodeLoad]
    reader_load_after: List[RebalanceNodeLoad]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalancePlanSummary":
        return cls(
            total_segments=int(value.get("total_segments", 0)),
            writer_moves=int(value.get("writer_moves", 0)),
            reader_moves=int(value.get("reader_moves", 0)),
            unchanged_count=int(value.get("unchanged_count", 0)),
            writer_load_before=[
                RebalanceNodeLoad.from_dict(item)
                for item in value.get("writer_load_before", [])
            ],
            writer_load_after=[
                RebalanceNodeLoad.from_dict(item)
                for item in value.get("writer_load_after", [])
            ],
            reader_load_before=[
                RebalanceNodeLoad.from_dict(item)
                for item in value.get("reader_load_before", [])
            ],
            reader_load_after=[
                RebalanceNodeLoad.from_dict(item)
                for item in value.get("reader_load_after", [])
            ],
        )


@dataclass
class RebalanceSegmentSide:
    writer: str
    readers: List[str]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalanceSegmentSide":
        return cls(
            writer=str(value.get("writer", "")),
            readers=[str(item) for item in value.get("readers", [])],
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "writer": self.writer,
            "readers": list(self.readers),
        }


@dataclass
class RebalanceSegmentChangeFlag:
    writer: bool
    readers: bool

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalanceSegmentChangeFlag":
        return cls(
            writer=bool(value.get("writer", False)),
            readers=bool(value.get("readers", False)),
        )


@dataclass
class RebalanceSegmentEntry:
    segment_id: str
    before: RebalanceSegmentSide
    after: RebalanceSegmentSide
    changed: RebalanceSegmentChangeFlag

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalanceSegmentEntry":
        return cls(
            segment_id=str(value.get("segment_id", "")),
            before=RebalanceSegmentSide.from_dict(value.get("before", {})),
            after=RebalanceSegmentSide.from_dict(value.get("after", {})),
            changed=RebalanceSegmentChangeFlag.from_dict(value.get("changed", {})),
        )


@dataclass
class SegmentAssignmentSnapshot:
    segment_id: str
    readers: List[str]
    writer: str

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentAssignmentSnapshot":
        return cls(
            segment_id=str(value.get("segment_id", "")),
            readers=[str(item) for item in value.get("readers", [])],
            writer=str(value.get("writer", "")),
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "segment_id": self.segment_id,
            "readers": list(self.readers),
            "writer": self.writer,
        }


@dataclass
class SegmentStructureSnapshot:
    segmentation_info: Optional[Dict[str, Any]]
    segment_ids: List[str]
    segment_assignments: Dict[str, SegmentAssignmentSnapshot]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SegmentStructureSnapshot":
        return cls(
            segmentation_info=value.get("segmentation_info"),
            segment_ids=[str(item) for item in value.get("segment_ids", [])],
            segment_assignments={
                str(key): SegmentAssignmentSnapshot.from_dict(item)
                for key, item in value.get("segment_assignments", {}).items()
            },
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "segmentation_info": self.segmentation_info,
            "segment_ids": list(self.segment_ids),
            "segment_assignments": {
                key: value.to_dict()
                for key, value in self.segment_assignments.items()
            },
        }


@dataclass
class RebalanceCommitRequest:
    expected_table_version: int
    expected_segment_structure: SegmentStructureSnapshot
    reader_nodes: Optional[List[str]] = None
    writer_nodes: Optional[List[str]] = None
    strategy: Optional[str] = None

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalanceCommitRequest":
        reader_nodes = value.get("reader_nodes") or []
        writer_nodes = value.get("writer_nodes") or []
        return cls(
            expected_table_version=int(value.get("expected_table_version", 0)),
            expected_segment_structure=SegmentStructureSnapshot.from_dict(
                value.get("expected_segment_structure", {})
            ),
            reader_nodes=[str(item) for item in reader_nodes] or None,
            writer_nodes=[str(item) for item in writer_nodes] or None,
            strategy=value.get("strategy"),
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reader_nodes": list(self.reader_nodes) if self.reader_nodes else None,
            "writer_nodes": list(self.writer_nodes) if self.writer_nodes else None,
            "strategy": self.strategy,
            "expected_table_version": self.expected_table_version,
            "expected_segment_structure": self.expected_segment_structure.to_dict(),
        }


@dataclass
class RebalancePlanResult:
    table_name: str
    expected_table_version: int
    strategy: str
    expected_segment_structure: SegmentStructureSnapshot
    effective_reader_nodes: List[str]
    effective_writer_nodes: List[str]
    summary: RebalancePlanSummary
    segments: List[RebalanceSegmentEntry]
    commit_template: RebalanceCommitRequest

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalancePlanResult":
        return cls(
            table_name=str(value.get("table_name", "")),
            expected_table_version=int(value.get("expected_table_version", 0)),
            strategy=str(value.get("strategy", "")),
            expected_segment_structure=SegmentStructureSnapshot.from_dict(
                value.get("expected_segment_structure", {})
            ),
            effective_reader_nodes=[
                str(item) for item in value.get("effective_reader_nodes", [])
            ],
            effective_writer_nodes=[
                str(item) for item in value.get("effective_writer_nodes", [])
            ],
            summary=RebalancePlanSummary.from_dict(value.get("summary", {})),
            segments=[
                RebalanceSegmentEntry.from_dict(item)
                for item in value.get("segments", [])
            ],
            commit_template=RebalanceCommitRequest.from_dict(
                value.get("commit_template", {})
            ),
        )


@dataclass
class RebalanceCommitResult:
    table_name: str
    new_table_version: int
    status: str
    summary: RebalancePlanSummary
    segments: List[RebalanceSegmentEntry]
    effective_reader_nodes: List[str]
    effective_writer_nodes: List[str]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalanceCommitResult":
        return cls(
            table_name=str(value.get("table_name", "")),
            new_table_version=int(value.get("new_table_version", 0)),
            status=str(value.get("status", "")),
            summary=RebalancePlanSummary.from_dict(value.get("summary", {})),
            segments=[
                RebalanceSegmentEntry.from_dict(item)
                for item in value.get("segments", [])
            ],
            effective_reader_nodes=[
                str(item) for item in value.get("effective_reader_nodes", [])
            ],
            effective_writer_nodes=[
                str(item) for item in value.get("effective_writer_nodes", [])
            ],
        )


@dataclass
class RebalanceStatusResult:
    table_name: str
    status: str
    started_at: Optional[str] = None
    ttl_seconds: Optional[int] = None
    failure: Optional[TableOperationFailure] = None
    polling: Optional[TableOperationPollingInfo] = None

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "RebalanceStatusResult":
        failure = value.get("failure")
        polling = value.get("polling")
        return cls(
            table_name=str(value.get("table_name", "")),
            status=str(value.get("status", "")),
            started_at=value.get("started_at"),
            ttl_seconds=value.get("ttl_seconds"),
            failure=TableOperationFailure.from_dict(failure) if failure else None,
            polling=TableOperationPollingInfo.from_dict(polling) if polling else None,
        )


@dataclass
class HybridSearchOptions:
    """Optional tuning parameters for hybrid search."""

    fusion: str = "rrf"
    rrf_k: Optional[int] = None
    alpha: Optional[float] = None
    ef_search: Optional[int] = None
    bm25_k: Optional[float] = None
    bm25_b: Optional[float] = None
    sparse_metadata: Optional[Dict[str, Any]] = None
    projection: Optional[str] = None
    filter: Optional[str] = None
