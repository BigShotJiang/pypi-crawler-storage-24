"""
Coral connection classes for Seahorse Coral Client.

This module defines the root sync/async client objects and the internal
conversion helpers used by the public Table/Index wrappers.
"""

import asyncio
import inspect
import json
import os
from collections.abc import Sequence
from typing import Any, Dict, List, Optional

from ._seahorse_coral import CoralClient as _RustClient
from .exceptions import (
    ConnectionError,
    ImportFilesError,
    PartialImportError,
    QueryError,
    SeahorseError,
)
from .schema import (
    Column,
    IndexDefinition,
    SchemaBuilder,
    Segmentation,
    TableConfigurations,
    TablePlacement,
)
from .storage import FileFormat, FileSource, ImportOptions, StorageType
from .table import AsyncTable, Table
from .types import (
    ActiveSetFlushResult,
    FileImportResult,
    HybridSearchOptions,
    IndexedCountSummary,
    ImportFilesResult,
    IndexedCounts,
    IndexRowCount,
    InsertResult,
    NodeInfo,
    RebalanceCommitRequest,
    RebalanceCommitResult,
    RebalancePlanResult,
    RebalanceStatusResult,
    RecordBatchStream,
    ResultSet,
    ResultSetStream,
    ResultSets,
    SegmentsRetryResult,
    SegmentsStatusResult,
    TableSchema,
    TableInfo,
)


def _build_create_table_schema(
    *,
    schema: Optional[SchemaBuilder],
    columns: Optional[List[Column]],
    primary_key: Optional[List[str]],
    segmentation: Optional[Segmentation],
    indexes: Optional[List[IndexDefinition]],
    configurations: Optional[TableConfigurations],
    placement: Optional[TablePlacement],
) -> SchemaBuilder:
    if schema is not None and not isinstance(schema, SchemaBuilder):
        raise TypeError(f"schema must be a SchemaBuilder instance, got {type(schema)}")

    if schema is not None:
        provided_components = any(
            value is not None
            for value in (
                columns,
                primary_key,
                segmentation,
                indexes,
                configurations,
                placement,
            )
        )
        if provided_components:
            raise TypeError("Pass either schema=... or schema components, not both.")
        schema.validate()
        return schema

    if columns is None:
        raise TypeError("columns must be provided when schema is not provided")

    schema_obj = SchemaBuilder(
        columns=columns,
        primary_key=primary_key,
        segmentation=segmentation,
        indexes=indexes,
        configurations=configurations,
        placement=placement,
    )
    schema_obj.validate()
    return schema_obj


def _attr_or_key(value: Any, name: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(name, default)
    return getattr(value, name, default)


def _plain_data(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _plain_data(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain_data(item) for item in value]
    if hasattr(value, "__dict__"):
        return {
            key: _plain_data(item)
            for key, item in vars(value).items()
            if not key.startswith("_")
        }
    return value


def _arrow_ipc_from_value(data: Any) -> bytes:
    if isinstance(data, (bytes, bytearray, memoryview)):
        return bytes(data)

    try:
        import pyarrow as pa
    except ImportError as error:
        raise TypeError(
            "insert_arrow() accepts bytes, pyarrow.Table, pyarrow.RecordBatch, "
            "or Sequence[pyarrow.RecordBatch]"
        ) from error

    if isinstance(data, pa.Table):
        schema = data.schema
        record_batches = data.to_batches()
    elif isinstance(data, pa.RecordBatch):
        schema = data.schema
        record_batches = [data]
    elif isinstance(data, Sequence) and not isinstance(data, (str, bytes, bytearray, memoryview)):
        record_batches = list(data)
        if not record_batches:
            raise ValueError("insert_arrow() requires at least one RecordBatch")
        if not all(isinstance(batch, pa.RecordBatch) for batch in record_batches):
            raise TypeError(
                "insert_arrow() Sequence input must contain only pyarrow.RecordBatch values"
            )
        schema = record_batches[0].schema
        for batch in record_batches[1:]:
            if batch.schema != schema:
                raise ValueError("all RecordBatch values must share the same schema")
    else:
        raise TypeError(
            "insert_arrow() accepts bytes, pyarrow.Table, pyarrow.RecordBatch, "
            "or Sequence[pyarrow.RecordBatch]"
        )

    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, schema) as writer:
        for batch in record_batches:
            writer.write_batch(batch)
    return sink.getvalue().to_pybytes()


def _ensure_import_options(
    *,
    batch_size: Optional[int] = None,
    options: Optional[ImportOptions] = None,
) -> ImportOptions:
    if options is not None and not isinstance(options, ImportOptions):
        raise TypeError(f"options must be an ImportOptions instance, got {type(options)}")

    resolved = options or ImportOptions()
    if resolved.format is not FileFormat.PARQUET:
        raise ValueError("insert_parquet() only supports FileFormat.PARQUET")

    if batch_size is not None:
        resolved = ImportOptions(
            format=FileFormat.PARQUET,
            reader_batch_size=batch_size,
            max_concurrent_files=resolved.max_concurrent_files,
            include_metrics=resolved.include_metrics,
        )

    return resolved


def _single_source_path(source: FileSource) -> str:
    if len(source.paths) != 1:
        raise ValueError("insert_parquet() requires exactly one parquet source")
    return source.paths[0]


def _single_local_parquet_path(path: Any) -> str:
    resolved_path = os.fspath(path)
    if not os.path.exists(resolved_path):
        raise FileNotFoundError(f"insert_parquet() local file not found: {resolved_path}")
    if os.path.isdir(resolved_path):
        raise ValueError(
            "insert_parquet() requires a single parquet file. "
            "Use import_files() for directories."
        )
    return resolved_path


def _parquet_source_kind(source: Any) -> str:
    if isinstance(source, (str, os.PathLike)):
        return "local_path"

    if isinstance(source, FileSource):
        storage_type = (
            source.storage_config.storage_type
            if source.storage_config and source.storage_config.storage_type
            else None
        )
        if storage_type in (None, StorageType.LOCAL):
            return "local_file_source"
        return "remote_file_source"

    raise TypeError(
        "insert_parquet() accepts a local path or FileSource. "
        "Use import_files() for multi-file or directory imports."
    )


def _result_set_from_native(result: Any) -> ResultSet:
    return ResultSet(
        arrow_ipc=result.arrow_ipc,
        elapsed_time=_attr_or_key(result, "elapsed_time"),
        rss_peak_bytes=_attr_or_key(result, "rss_peak_bytes"),
    )


def _result_sets_from_native(result: Any) -> ResultSets:
    return ResultSets(
        arrow_ipc=result.arrow_ipc,
        resultset_batch_counts=list(_attr_or_key(result, "resultset_batch_counts", [])),
        elapsed_time=_attr_or_key(result, "elapsed_time"),
        rss_peak_bytes=_attr_or_key(result, "rss_peak_bytes"),
    )


def _insert_result_from_native(result: Any) -> InsertResult:
    return InsertResult(
        inserted_record_batches=int(_attr_or_key(result, "inserted_record_batches", 0)),
        inserted_row_count=int(_attr_or_key(result, "inserted_row_count", 0)),
        total_inserted_record_batches=int(_attr_or_key(result, "total_inserted_record_batches", 0)),
        total_inserted_row_count=int(_attr_or_key(result, "total_inserted_row_count", 0)),
    )


def _file_import_result_from_native(result: Any) -> FileImportResult:
    inserted_record_batches = _attr_or_key(result, "inserted_record_batches")
    inserted_row_count = _attr_or_key(result, "inserted_row_count")
    if inserted_record_batches is None or inserted_row_count is None:
        native_result = _attr_or_key(result, "result")
        if inserted_record_batches is None:
            inserted_record_batches = _attr_or_key(
                native_result, "inserted_record_batches", 0
            )
        if inserted_row_count is None:
            inserted_row_count = _attr_or_key(native_result, "inserted_row_count", 0)

    return FileImportResult(
        path=str(_attr_or_key(result, "path", "")),
        success=bool(_attr_or_key(result, "success", False)),
        inserted_record_batches=int(inserted_record_batches or 0),
        inserted_row_count=int(inserted_row_count or 0),
        error=_attr_or_key(result, "error"),
    )


def _import_files_result_from_native(result: Any) -> ImportFilesResult:
    elapsed_time = _attr_or_key(result, "elapsed_time")
    rss_peak_bytes = _attr_or_key(result, "rss_peak_bytes")
    if elapsed_time is None or rss_peak_bytes is None:
        metrics = _attr_or_key(result, "metrics")
        if elapsed_time is None:
            elapsed_time = _attr_or_key(metrics, "elapsed_time")
        if rss_peak_bytes is None:
            rss_peak_bytes = _attr_or_key(metrics, "rss_peak_bytes")

    return ImportFilesResult(
        files=[
            _file_import_result_from_native(item)
            for item in list(_attr_or_key(result, "results", []))
        ],
        total_inserted_record_batches=int(
            _attr_or_key(result, "total_inserted_record_batches", 0)
        ),
        total_inserted_row_count=int(_attr_or_key(result, "total_inserted_row_count", 0)),
        elapsed_time=elapsed_time,
        rss_peak_bytes=rss_peak_bytes,
    )


def _format_import_files_failure_details(result: ImportFilesResult) -> Optional[str]:
    failed = [item for item in result.files if not item.success]
    if not failed:
        return None

    details = [
        f"{item.path}: {item.error or 'unknown error'}" for item in failed[:3]
    ]
    if len(failed) > 3:
        details.append(f"+{len(failed) - 3} more")
    return "; ".join(details)


def _finalize_import_files_result(
    result: ImportFilesResult,
    *,
    strict: bool,
) -> ImportFilesResult:
    if not result.files:
        raise ImportFilesError(result, "Import files returned no per-file results")

    if not strict or result.all_succeeded:
        return result

    details = _format_import_files_failure_details(result)
    if result.succeeded_count > 0:
        raise PartialImportError(result, "Import files partially failed", details)
    raise ImportFilesError(result, "Import files failed", details)


def _single_insert_result_from_import_files_result(
    result: ImportFilesResult,
) -> InsertResult:
    if len(result.files) != 1:
        raise RuntimeError(
            f"expected exactly one file import result, got {len(result.files)}"
        )

    file_result = result.files[0]
    if not file_result.success:
        raise RuntimeError(file_result.error or "File import failed")

    return InsertResult(
        inserted_record_batches=file_result.inserted_record_batches,
        inserted_row_count=file_result.inserted_row_count,
        total_inserted_record_batches=result.total_inserted_record_batches,
        total_inserted_row_count=result.total_inserted_row_count,
    )


def _record_batch_stream_from_native(
    native_stream: Any,
    *,
    run_async: Optional[Any],
) -> RecordBatchStream:
    return RecordBatchStream(native_stream, run_async=run_async)


def _result_set_stream_from_native(
    native_stream: Any,
    *,
    run_async: Optional[Any],
) -> ResultSetStream:
    return ResultSetStream(native_stream, run_async=run_async)


def _node_checkpoint_from_native(value: Any) -> Any:
    from .types import NodeCheckpoint

    return NodeCheckpoint(
        last_set_number=_attr_or_key(value, "last_set_number"),
        set_versions=[str(item) for item in _attr_or_key(value, "set_versions", [])],
        set_index_counts={
            str(key): [str(entry) for entry in entries]
            for key, entries in _attr_or_key(value, "set_index_counts", {}).items()
        },
    )


def _segment_assignment_from_native(value: Any) -> Any:
    from .types import SegmentAssignment

    return SegmentAssignment(
        segment_oid=str(_attr_or_key(value, "segment_oid", "")),
        status=str(_attr_or_key(value, "status", "UNKNOWN")),
        failure_reason=str(_attr_or_key(value, "failure_reason", "")),
        checkpoint=_node_checkpoint_from_native(_attr_or_key(value, "checkpoint")),
    )


def _table_assignment_from_native(value: Any) -> Any:
    from .types import TableAssignment

    return TableAssignment(
        table_oid=str(_attr_or_key(value, "table_oid", "")),
        segments={
            str(segment_id): _segment_assignment_from_native(segment_value)
            for segment_id, segment_value in _attr_or_key(value, "segments", {}).items()
        },
    )


def _node_info_from_native(value: Any) -> NodeInfo:
    return NodeInfo(
        node_id=str(_attr_or_key(value, "node_id", "")),
        version=int(_attr_or_key(value, "version", 0)),
        format_version=int(_attr_or_key(value, "format_version", 0)),
        node_type=str(_attr_or_key(value, "type", _attr_or_key(value, "node_type", ""))),
        state=str(_attr_or_key(value, "state", "")),
        node_stage=str(_attr_or_key(value, "node_stage", "")),
        last_updated=str(_attr_or_key(value, "last_updated", "")),
        node_address=str(_attr_or_key(value, "node_address", "")),
        assigned_tables={
            str(table_id): _table_assignment_from_native(table_value)
            for table_id, table_value in _attr_or_key(value, "assigned_tables", {}).items()
        },
    )


def _node_snapshot_from_native(value: Any) -> NodeInfo:
    node_payload = _attr_or_key(value, "node_info")
    if node_payload is None:
        return _node_info_from_native(value)

    node_payload = _plain_data(node_payload)
    node_payload["node_id"] = str(_attr_or_key(value, "node_id", node_payload.get("node_id", "")))
    return NodeInfo.from_dict(node_payload)


def _table_schema_from_native(result: Any) -> TableSchema:
    return TableSchema(
        table_name=result.table_name,
        schema=SchemaBuilder.from_dict(result.schema),
    )


def _table_info_from_native(result: Any) -> TableInfo:
    schema = None
    if getattr(result, "schema", None) is not None:
        schema = SchemaBuilder.from_dict(result.schema)
    return TableInfo(table_name=result.table_name, schema=schema)


def _segments_status_from_native(value: Any) -> SegmentsStatusResult:
    return SegmentsStatusResult.from_dict(
        {
            "table_name": _attr_or_key(value, "table_name", ""),
            "table_status": _attr_or_key(value, "table_status", ""),
            "mode": _attr_or_key(value, "mode", ""),
            "started_at": _attr_or_key(value, "started_at"),
            "ttl_seconds": _attr_or_key(value, "ttl_seconds"),
            "failure": _plain_data(_attr_or_key(value, "failure")),
            "polling": _plain_data(_attr_or_key(value, "polling")),
            "summary": _plain_data(_attr_or_key(value, "summary")),
        }
    )


def _segments_retry_from_native(value: Any) -> SegmentsRetryResult:
    return SegmentsRetryResult.from_dict(
        {
            "table_name": _attr_or_key(value, "table_name", ""),
            "table_status": _attr_or_key(value, "table_status", ""),
            "summary": _plain_data(_attr_or_key(value, "summary")),
            "nodes": _plain_data(_attr_or_key(value, "nodes", [])),
        }
    )


def _indexed_count_summary_from_native(value: Any) -> IndexedCountSummary:
    return IndexedCountSummary(
        total_row_count=int(_attr_or_key(value, "total_row_count", 0)),
        indexed_counts=[
            IndexRowCount(
                index_name=str(_attr_or_key(item, "index_name", "")),
                index_type=str(_attr_or_key(item, "index_type", "")),
                indexed_row_count=int(_attr_or_key(item, "indexed_row_count", 0)),
            )
            for item in list(_attr_or_key(value, "indexed_counts", []))
        ],
    )


def _indexed_counts_from_native(value: Any) -> IndexedCounts:
    readable = _attr_or_key(value, "readable")
    return IndexedCounts(
        total_row_count=int(_attr_or_key(value, "total_row_count", 0)),
        indexed_counts=[
            IndexRowCount(
                index_name=str(_attr_or_key(item, "index_name", "")),
                index_type=str(_attr_or_key(item, "index_type", "")),
                indexed_row_count=int(_attr_or_key(item, "indexed_row_count", 0)),
            )
            for item in list(_attr_or_key(value, "indexed_counts", []))
        ],
        readable=_indexed_count_summary_from_native(readable) if readable else None,
    )


def _rebalance_plan_from_native(value: Any) -> RebalancePlanResult:
    payload = _plain_data(value)
    if not isinstance(payload, dict):
        raise TypeError("rebalance plan payload must be dict-like")
    return RebalancePlanResult.from_dict(payload)


def _rebalance_commit_from_native(value: Any) -> RebalanceCommitResult:
    payload = _plain_data(value)
    if not isinstance(payload, dict):
        raise TypeError("rebalance commit payload must be dict-like")
    return RebalanceCommitResult.from_dict(payload)


def _rebalance_status_from_native(value: Any) -> RebalanceStatusResult:
    payload = _plain_data(value)
    if not isinstance(payload, dict):
        raise TypeError("rebalance status payload must be dict-like")
    return RebalanceStatusResult.from_dict(payload)


class Coral:
    """Sync root client for Seahorse Coral."""

    def __init__(self, url: str, timeout: Optional[float] = None):
        self._client = _RustClient(url)
        self._timeout = timeout
        self._url = url

    def _run_async(self, operation: Any) -> Any:
        async def runner() -> Any:
            result = operation() if callable(operation) else operation
            if inspect.isawaitable(result):
                return await result
            return result

        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(runner())

        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            return executor.submit(lambda: asyncio.run(runner())).result()

    def health(self) -> str:
        try:
            return self._run_async(lambda: self._client.health_check())
        except Exception as error:
            raise ConnectionError(f"Health check failed: {error}")

    def nodes(self) -> List[NodeInfo]:
        try:
            return [
                _node_snapshot_from_native(item)
                for item in self._run_async(lambda: self._client.get_nodes())
            ]
        except Exception as error:
            raise ConnectionError(f"Get nodes failed: {error}")

    def get_table(self, name: str) -> Table:
        try:
            self._run_async(lambda: self._client.get_table_schema(name))
            return Table(self, name)
        except Exception as error:
            raise SeahorseError(f"Get table failed: {error}")

    def create_table(
        self,
        name: str,
        schema: Optional[SchemaBuilder] = None,
        *,
        columns: Optional[List[Column]] = None,
        primary_key: Optional[List[str]] = None,
        segmentation: Optional[Segmentation] = None,
        indexes: Optional[List[IndexDefinition]] = None,
        configurations: Optional[TableConfigurations] = None,
        placement: Optional[TablePlacement] = None,
    ) -> Table:
        try:
            schema_obj = _build_create_table_schema(
                schema=schema,
                columns=columns,
                primary_key=primary_key,
                segmentation=segmentation,
                indexes=indexes,
                configurations=configurations,
                placement=placement,
            )
            self._run_async(
                lambda: self._client.create_table(
                    name, schema_obj.to_dict(table_name=name)
                )
            )
            return Table(self, name)
        except Exception as error:
            raise SeahorseError(f"Create table failed: {error}")

    def list_tables(self) -> List[TableInfo]:
        try:
            return [
                _table_info_from_native(item)
                for item in self._run_async(lambda: self._client.list_tables(False))
            ]
        except Exception as error:
            raise SeahorseError(f"List tables failed: {error}")

    def list_table_names(self) -> List[str]:
        try:
            return list(self._run_async(lambda: self._client.list_tables(True)))
        except Exception as error:
            raise SeahorseError(f"List table names failed: {error}")

    def drop_table(self, name: str) -> bool:
        try:
            return self._run_async(lambda: self._client.delete_table(name))
        except Exception as error:
            raise SeahorseError(f"Drop table failed: {error}")

    def _get_table_schema(self, table_name: str) -> TableSchema:
        try:
            return _table_schema_from_native(
                self._run_async(lambda: self._client.get_table_schema(table_name))
            )
        except Exception as error:
            raise SeahorseError(f"Get table schema failed: {error}")

    def _get_indexed_row_count(
        self, table_name: str, readable: bool = True
    ) -> IndexedCounts:
        try:
            result = self._run_async(
                lambda: self._client.get_indexed_row_count(table_name, readable)
            )
            return _indexed_counts_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Get indexed row count failed: {error}")

    def _update_rows(
        self,
        table_name: str,
        update_values: str,
        *,
        where: Optional[str] = None,
    ) -> None:
        try:
            self._run_async(
                lambda: self._client.update_table_data(table_name, update_values, where)
            )
        except Exception as error:
            raise SeahorseError(f"Update rows failed: {error}")

    def _delete_rows(
        self,
        table_name: str,
        *,
        where: Optional[str] = None,
    ) -> None:
        try:
            self._run_async(lambda: self._client.delete_table_data(table_name, where))
        except Exception as error:
            raise SeahorseError(f"Delete rows failed: {error}")

    def _active_set_flush(
        self,
        table_name: str,
        segment_ids: Optional[List[str]] = None,
        sync_mode: str = "async",
    ) -> ActiveSetFlushResult:
        try:
            result = self._run_async(
                lambda: self._client.active_set_flush(
                    table_name, segment_ids, sync_mode
                )
            )
            return ActiveSetFlushResult(
                flushed=list(result.flushed),
                failed=list(result.failed),
                skipped=list(result.skipped),
            )
        except Exception as error:
            raise SeahorseError(f"Active set flush failed: {error}")

    def _segments_status(self, table_name: str) -> SegmentsStatusResult:
        try:
            return _segments_status_from_native(
                self._run_async(lambda: self._client.segments_status(table_name))
            )
        except Exception as error:
            raise SeahorseError(f"Get segments status failed: {error}")

    def _segments_retry(
        self,
        table_name: str,
        *,
        mode: str = "auto",
        only_failed: bool = True,
        skip_unsubscribed: bool = True,
        dry_run: bool = False,
        max_targets: Optional[int] = None,
    ) -> SegmentsRetryResult:
        try:
            return _segments_retry_from_native(
                self._run_async(
                    lambda: self._client.segments_retry(
                        table_name,
                        mode,
                        only_failed,
                        skip_unsubscribed,
                        dry_run,
                        max_targets,
                    )
                )
            )
        except Exception as error:
            raise SeahorseError(f"Segments retry failed: {error}")

    def _rebalance_plan(
        self,
        table_name: str,
        *,
        reader_nodes: Optional[List[str]] = None,
        writer_nodes: Optional[List[str]] = None,
        strategy: Optional[str] = None,
    ) -> RebalancePlanResult:
        try:
            return _rebalance_plan_from_native(
                self._run_async(
                    lambda: self._client.rebalance_plan(
                        table_name, reader_nodes, writer_nodes, strategy
                    )
                )
            )
        except Exception as error:
            raise SeahorseError(f"Rebalance plan failed: {error}")

    def _rebalance_commit(
        self,
        table_name: str,
        request: RebalanceCommitRequest,
    ) -> RebalanceCommitResult:
        try:
            return _rebalance_commit_from_native(
                self._run_async(
                    lambda: self._client.rebalance_commit(
                        table_name, request.to_dict()
                    )
                )
            )
        except Exception as error:
            raise SeahorseError(f"Rebalance commit failed: {error}")

    def _rebalance_status(self, table_name: str) -> RebalanceStatusResult:
        try:
            return _rebalance_status_from_native(
                self._run_async(lambda: self._client.rebalance_status(table_name))
            )
        except Exception as error:
            raise SeahorseError(f"Get rebalance status failed: {error}")

    def _insert_rows(
        self,
        table_name: str,
        rows: List[Dict[str, Any]],
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        if not rows:
            raise ValueError("rows must not be empty")
        if not all(isinstance(row, dict) for row in rows):
            raise TypeError("rows must be a list[dict]")

        try:
            jsonl = "\n".join(json.dumps(row) for row in rows)
            result = self._run_async(
                lambda: self._client.insert_data(
                    table_name,
                    jsonl,
                    reader_batch_size,
                    use_async_read,
                )
            )
            return _insert_result_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Insert rows failed: {error}")

    def _insert_jsonl(
        self,
        table_name: str,
        jsonl: str,
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        try:
            result = self._run_async(
                lambda: self._client.insert_data(
                    table_name,
                    jsonl,
                    reader_batch_size,
                    use_async_read,
                )
            )
            return _insert_result_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Insert JSONL failed: {error}")

    def _insert_arrow(self, table_name: str, data: Any) -> InsertResult:
        try:
            result = self._run_async(
                lambda: self._client.insert_arrow_stream(
                    table_name, _arrow_ipc_from_value(data)
                )
            )
            return _insert_result_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Insert Arrow IPC failed: {error}")

    def _insert_parquet(
        self,
        table_name: str,
        source: Any,
        *,
        batch_size: Optional[int] = None,
        options: Optional[ImportOptions] = None,
    ) -> InsertResult:
        kind = _parquet_source_kind(source)
        if kind == "local_path":
            path = _single_local_parquet_path(source)
            try:
                result = self._run_async(
                    lambda: self._client.insert_parquet_as_arrow_stream(
                        table_name,
                        path,
                        batch_size,
                    )
                )
            except Exception as error:
                raise SeahorseError(f"Insert parquet failed: {error}")
            return _insert_result_from_native(result)

        if kind == "local_file_source":
            path = _single_local_parquet_path(_single_source_path(source))
            try:
                result = self._run_async(
                    lambda: self._client.insert_parquet_as_arrow_stream(
                        table_name,
                        path,
                        batch_size,
                    )
                )
            except Exception as error:
                raise SeahorseError(f"Insert parquet failed: {error}")
            return _insert_result_from_native(result)

        _single_source_path(source)
        import_options = _ensure_import_options(
            batch_size=batch_size,
            options=options,
        )
        try:
            import_result = _import_files_result_from_native(
                self._run_async(
                    lambda: self._insert_from_file_native(
                        table_name, source, import_options
                    )
                )
            )
            finalized_result = _finalize_import_files_result(import_result, strict=True)
            return _single_insert_result_from_import_files_result(finalized_result)
        except Exception as error:
            raise SeahorseError(f"Insert parquet failed: {error}")

    def _import_files(
        self,
        table_name: str,
        request: FileSource,
        *,
        options: Optional[ImportOptions] = None,
        strict: bool = True,
    ) -> ImportFilesResult:
        try:
            resolved_options = options or ImportOptions()
            result = _import_files_result_from_native(
                self._run_async(
                    lambda: self._insert_from_file_native(
                        table_name, request, resolved_options
                    )
                )
            )
            return _finalize_import_files_result(result, strict=strict)
        except ImportFilesError:
            raise
        except Exception as error:
            raise SeahorseError(f"Import files failed: {error}")

    async def _insert_from_file_native(
        self,
        table_name: str,
        request: FileSource,
        options: ImportOptions,
    ) -> Any:
        storage_config = request.storage_config
        credentials = storage_config.credentials if storage_config else None
        storage_options = storage_config.options if storage_config else None
        return await self._client.insert_from_file(
            table_name,
            list(request.paths),
            storage_config.storage_type.value
            if storage_config and storage_config.storage_type
            else None,
            storage_config.bucket if storage_config else None,
            credentials.access_key if credentials else None,
            credentials.secret_key if credentials else None,
            storage_options.region if storage_options else None,
            storage_options.endpoint if storage_options else None,
            storage_options.virtual_hosted_style if storage_options else None,
            storage_options.allow_http if storage_options else None,
            options.format.value if options.format else None,
            options.reader_batch_size,
            options.max_concurrent_files,
        )

    def _scan(
        self,
        table_name: str,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> ResultSet:
        try:
            return _result_set_from_native(
                self._run_async(
                    lambda: self._client.scan_data(
                        table_name,
                        select,
                        where,
                        limit,
                        include_metrics,
                        allow_writer,
                    )
                )
            )
        except Exception as error:
            raise QueryError(f"Scan failed: {error}")

    def _scan_stream(
        self,
        table_name: str,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> RecordBatchStream:
        try:
            native_stream = self._run_async(
                lambda: self._client.scan_data_stream(
                    table_name,
                    select,
                    where,
                    limit,
                    include_metrics,
                    allow_writer,
                )
            )
            return _record_batch_stream_from_native(native_stream, run_async=self._run_async)
        except Exception as error:
            raise QueryError(f"Open scan stream failed: {error}")

    def _vector_search(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        try:
            return _result_set_from_native(
                self._run_async(
                    lambda: self._client.vector_search(
                        table_name,
                        index_name,
                        queries,
                        top_k,
                        ef_search,
                        select,
                        where,
                    )
                )
            )
        except Exception as error:
            raise QueryError(f"Vector search failed: {error}")

    def _vector_search_batch(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        try:
            return _result_sets_from_native(
                self._run_async(
                    lambda: self._client.vector_search_batch(
                        table_name,
                        index_name,
                        queries,
                        top_k,
                        ef_search,
                        select,
                        where,
                    )
                )
            )
        except Exception as error:
            raise QueryError(f"Vector batch search failed: {error}")

    def _vector_search_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        try:
            native_stream = self._run_async(
                lambda: self._client.vector_search_stream(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    ef_search,
                    select,
                    where,
                )
            )
            return _record_batch_stream_from_native(native_stream, run_async=self._run_async)
        except Exception as error:
            raise QueryError(f"Open vector search stream failed: {error}")

    def _vector_search_batch_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        try:
            native_stream = self._run_async(
                lambda: self._client.vector_search_batch_stream(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    ef_search,
                    select,
                    where,
                )
            )
            return _result_set_stream_from_native(native_stream, run_async=self._run_async)
        except Exception as error:
            raise QueryError(f"Open vector batch stream failed: {error}")

    def _sparse_search(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        try:
            return _result_set_from_native(
                self._run_async(
                    lambda: self._client.vector_search_sparse(
                        table_name,
                        index_name,
                        queries,
                        top_k,
                        bm25_k,
                        bm25_b,
                        sparse_metadata,
                        select,
                        where,
                    )
                )
            )
        except Exception as error:
            raise QueryError(f"Sparse search failed: {error}")

    def _sparse_search_batch(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        try:
            return _result_sets_from_native(
                self._run_async(
                    lambda: self._client.vector_search_sparse_batch(
                        table_name,
                        index_name,
                        queries,
                        top_k,
                        bm25_k,
                        bm25_b,
                        sparse_metadata,
                        select,
                        where,
                    )
                )
            )
        except Exception as error:
            raise QueryError(f"Sparse batch search failed: {error}")

    def _sparse_search_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        try:
            native_stream = self._run_async(
                lambda: self._client.vector_search_sparse_stream(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    bm25_k,
                    bm25_b,
                    sparse_metadata,
                    select,
                    where,
                )
            )
            return _record_batch_stream_from_native(native_stream, run_async=self._run_async)
        except Exception as error:
            raise QueryError(f"Open sparse search stream failed: {error}")

    def _sparse_search_batch_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        try:
            native_stream = self._run_async(
                lambda: self._client.vector_search_sparse_batch_stream(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    bm25_k,
                    bm25_b,
                    sparse_metadata,
                    select,
                    where,
                )
            )
            return _result_set_stream_from_native(native_stream, run_async=self._run_async)
        except Exception as error:
            raise QueryError(f"Open sparse batch stream failed: {error}")

    def _hybrid_search(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSet:
        options = options or HybridSearchOptions()
        try:
            return _result_set_from_native(
                self._run_async(
                    lambda: self._client.hybrid_search(
                        table_name,
                        top_k,
                        dense_column,
                        dense_queries,
                        sparse_column,
                        sparse_queries,
                        options.fusion,
                        options.rrf_k,
                        options.alpha,
                        options.ef_search,
                        options.bm25_k,
                        options.bm25_b,
                        options.sparse_metadata,
                        options.projection,
                        options.filter,
                    )
                )
            )
        except Exception as error:
            raise QueryError(f"Hybrid search failed: {error}")

    def _hybrid_search_batch(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSets:
        options = options or HybridSearchOptions()
        try:
            return _result_sets_from_native(
                self._run_async(
                    lambda: self._client.hybrid_search_batch(
                        table_name,
                        top_k,
                        dense_column,
                        dense_queries,
                        sparse_column,
                        sparse_queries,
                        options.fusion,
                        options.rrf_k,
                        options.alpha,
                        options.ef_search,
                        options.bm25_k,
                        options.bm25_b,
                        options.sparse_metadata,
                        options.projection,
                        options.filter,
                    )
                )
            )
        except Exception as error:
            raise QueryError(f"Hybrid batch search failed: {error}")

    def _hybrid_search_stream(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> RecordBatchStream:
        options = options or HybridSearchOptions()
        try:
            native_stream = self._run_async(
                lambda: self._client.hybrid_search_stream(
                    table_name,
                    top_k,
                    dense_column,
                    dense_queries,
                    sparse_column,
                    sparse_queries,
                    options.fusion,
                    options.rrf_k,
                    options.alpha,
                    options.ef_search,
                    options.bm25_k,
                    options.bm25_b,
                    options.sparse_metadata,
                    options.projection,
                    options.filter,
                )
            )
            return _record_batch_stream_from_native(native_stream, run_async=self._run_async)
        except Exception as error:
            raise QueryError(f"Open hybrid search stream failed: {error}")

    def _hybrid_search_batch_stream(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSetStream:
        options = options or HybridSearchOptions()
        try:
            native_stream = self._run_async(
                lambda: self._client.hybrid_search_batch_stream(
                    table_name,
                    top_k,
                    dense_column,
                    dense_queries,
                    sparse_column,
                    sparse_queries,
                    options.fusion,
                    options.rrf_k,
                    options.alpha,
                    options.ef_search,
                    options.bm25_k,
                    options.bm25_b,
                    options.sparse_metadata,
                    options.projection,
                    options.filter,
                )
            )
            return _result_set_stream_from_native(native_stream, run_async=self._run_async)
        except Exception as error:
            raise QueryError(f"Open hybrid batch stream failed: {error}")


class AsyncCoral:
    """Async root client for Seahorse Coral."""

    def __init__(self, url: str, timeout: Optional[float] = None):
        self._client = _RustClient(url)
        self._timeout = timeout
        self._url = url

    async def health(self) -> str:
        try:
            return await self._client.health_check()
        except Exception as error:
            raise ConnectionError(f"Health check failed: {error}")

    async def nodes(self) -> List[NodeInfo]:
        try:
            return [_node_snapshot_from_native(item) for item in await self._client.get_nodes()]
        except Exception as error:
            raise ConnectionError(f"Get nodes failed: {error}")

    async def get_table(self, name: str) -> AsyncTable:
        try:
            await self._client.get_table_schema(name)
            return AsyncTable(self, name)
        except Exception as error:
            raise SeahorseError(f"Get table failed: {error}")

    async def create_table(
        self,
        name: str,
        schema: Optional[SchemaBuilder] = None,
        *,
        columns: Optional[List[Column]] = None,
        primary_key: Optional[List[str]] = None,
        segmentation: Optional[Segmentation] = None,
        indexes: Optional[List[IndexDefinition]] = None,
        configurations: Optional[TableConfigurations] = None,
        placement: Optional[TablePlacement] = None,
    ) -> AsyncTable:
        try:
            schema_obj = _build_create_table_schema(
                schema=schema,
                columns=columns,
                primary_key=primary_key,
                segmentation=segmentation,
                indexes=indexes,
                configurations=configurations,
                placement=placement,
            )
            await self._client.create_table(name, schema_obj.to_dict(table_name=name))
            return AsyncTable(self, name)
        except Exception as error:
            raise SeahorseError(f"Create table failed: {error}")

    async def list_tables(self) -> List[TableInfo]:
        try:
            return [_table_info_from_native(item) for item in await self._client.list_tables(False)]
        except Exception as error:
            raise SeahorseError(f"List tables failed: {error}")

    async def list_table_names(self) -> List[str]:
        try:
            return list(await self._client.list_tables(True))
        except Exception as error:
            raise SeahorseError(f"List table names failed: {error}")

    async def drop_table(self, name: str) -> bool:
        try:
            return await self._client.delete_table(name)
        except Exception as error:
            raise SeahorseError(f"Drop table failed: {error}")

    async def _get_table_schema(self, table_name: str) -> TableSchema:
        try:
            return _table_schema_from_native(await self._client.get_table_schema(table_name))
        except Exception as error:
            raise SeahorseError(f"Get table schema failed: {error}")

    async def _get_indexed_row_count(
        self, table_name: str, readable: bool = True
    ) -> IndexedCounts:
        try:
            result = await self._client.get_indexed_row_count(table_name, readable)
            return _indexed_counts_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Get indexed row count failed: {error}")

    async def _update_rows(
        self,
        table_name: str,
        update_values: str,
        *,
        where: Optional[str] = None,
    ) -> None:
        try:
            await self._client.update_table_data(table_name, update_values, where)
        except Exception as error:
            raise SeahorseError(f"Update rows failed: {error}")

    async def _delete_rows(
        self,
        table_name: str,
        *,
        where: Optional[str] = None,
    ) -> None:
        try:
            await self._client.delete_table_data(table_name, where)
        except Exception as error:
            raise SeahorseError(f"Delete rows failed: {error}")

    async def _active_set_flush(
        self,
        table_name: str,
        segment_ids: Optional[List[str]] = None,
        sync_mode: str = "async",
    ) -> ActiveSetFlushResult:
        try:
            result = await self._client.active_set_flush(table_name, segment_ids, sync_mode)
            return ActiveSetFlushResult(
                flushed=list(result.flushed),
                failed=list(result.failed),
                skipped=list(result.skipped),
            )
        except Exception as error:
            raise SeahorseError(f"Active set flush failed: {error}")

    async def _segments_status(self, table_name: str) -> SegmentsStatusResult:
        try:
            return _segments_status_from_native(await self._client.segments_status(table_name))
        except Exception as error:
            raise SeahorseError(f"Get segments status failed: {error}")

    async def _segments_retry(
        self,
        table_name: str,
        *,
        mode: str = "auto",
        only_failed: bool = True,
        skip_unsubscribed: bool = True,
        dry_run: bool = False,
        max_targets: Optional[int] = None,
    ) -> SegmentsRetryResult:
        try:
            return _segments_retry_from_native(
                await self._client.segments_retry(
                    table_name,
                    mode,
                    only_failed,
                    skip_unsubscribed,
                    dry_run,
                    max_targets,
                )
            )
        except Exception as error:
            raise SeahorseError(f"Segments retry failed: {error}")

    async def _rebalance_plan(
        self,
        table_name: str,
        *,
        reader_nodes: Optional[List[str]] = None,
        writer_nodes: Optional[List[str]] = None,
        strategy: Optional[str] = None,
    ) -> RebalancePlanResult:
        try:
            return _rebalance_plan_from_native(
                await self._client.rebalance_plan(
                    table_name, reader_nodes, writer_nodes, strategy
                )
            )
        except Exception as error:
            raise SeahorseError(f"Rebalance plan failed: {error}")

    async def _rebalance_commit(
        self,
        table_name: str,
        request: RebalanceCommitRequest,
    ) -> RebalanceCommitResult:
        try:
            return _rebalance_commit_from_native(
                await self._client.rebalance_commit(table_name, request.to_dict())
            )
        except Exception as error:
            raise SeahorseError(f"Rebalance commit failed: {error}")

    async def _rebalance_status(self, table_name: str) -> RebalanceStatusResult:
        try:
            return _rebalance_status_from_native(
                await self._client.rebalance_status(table_name)
            )
        except Exception as error:
            raise SeahorseError(f"Get rebalance status failed: {error}")

    async def _insert_rows(
        self,
        table_name: str,
        rows: List[Dict[str, Any]],
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        if not rows:
            raise ValueError("rows must not be empty")
        if not all(isinstance(row, dict) for row in rows):
            raise TypeError("rows must be a list[dict]")

        try:
            jsonl = "\n".join(json.dumps(row) for row in rows)
            result = await self._client.insert_data(
                table_name,
                jsonl,
                reader_batch_size,
                use_async_read,
            )
            return _insert_result_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Insert rows failed: {error}")

    async def _insert_jsonl(
        self,
        table_name: str,
        jsonl: str,
        *,
        reader_batch_size: Optional[int] = None,
        use_async_read: Optional[bool] = None,
    ) -> InsertResult:
        try:
            result = await self._client.insert_data(
                table_name,
                jsonl,
                reader_batch_size,
                use_async_read,
            )
            return _insert_result_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Insert JSONL failed: {error}")

    async def _insert_arrow(self, table_name: str, data: Any) -> InsertResult:
        try:
            result = await self._client.insert_arrow_stream(
                table_name,
                _arrow_ipc_from_value(data),
            )
            return _insert_result_from_native(result)
        except Exception as error:
            raise SeahorseError(f"Insert Arrow IPC failed: {error}")

    async def _insert_parquet(
        self,
        table_name: str,
        source: Any,
        *,
        batch_size: Optional[int] = None,
        options: Optional[ImportOptions] = None,
    ) -> InsertResult:
        kind = _parquet_source_kind(source)
        if kind == "local_path":
            path = _single_local_parquet_path(source)
            try:
                result = await self._client.insert_parquet_as_arrow_stream(
                    table_name,
                    path,
                    batch_size,
                )
            except Exception as error:
                raise SeahorseError(f"Insert parquet failed: {error}")
            return _insert_result_from_native(result)

        if kind == "local_file_source":
            path = _single_local_parquet_path(_single_source_path(source))
            try:
                result = await self._client.insert_parquet_as_arrow_stream(
                    table_name,
                    path,
                    batch_size,
                )
            except Exception as error:
                raise SeahorseError(f"Insert parquet failed: {error}")
            return _insert_result_from_native(result)

        _single_source_path(source)
        import_options = _ensure_import_options(
            batch_size=batch_size,
            options=options,
        )
        try:
            import_result = _import_files_result_from_native(
                await self._insert_from_file_native(
                    table_name,
                    source,
                    import_options,
                )
            )
            finalized_result = _finalize_import_files_result(import_result, strict=True)
            return _single_insert_result_from_import_files_result(finalized_result)
        except Exception as error:
            raise SeahorseError(f"Insert parquet failed: {error}")

    async def _import_files(
        self,
        table_name: str,
        request: FileSource,
        *,
        options: Optional[ImportOptions] = None,
        strict: bool = True,
    ) -> ImportFilesResult:
        try:
            resolved_options = options or ImportOptions()
            result = _import_files_result_from_native(
                await self._insert_from_file_native(
                    table_name,
                    request,
                    resolved_options,
                )
            )
            return _finalize_import_files_result(result, strict=strict)
        except ImportFilesError:
            raise
        except Exception as error:
            raise SeahorseError(f"Import files failed: {error}")

    async def _insert_from_file_native(
        self,
        table_name: str,
        request: FileSource,
        options: ImportOptions,
    ) -> Any:
        storage_config = request.storage_config
        credentials = storage_config.credentials if storage_config else None
        storage_options = storage_config.options if storage_config else None
        return await self._client.insert_from_file(
            table_name,
            list(request.paths),
            storage_config.storage_type.value
            if storage_config and storage_config.storage_type
            else None,
            storage_config.bucket if storage_config else None,
            credentials.access_key if credentials else None,
            credentials.secret_key if credentials else None,
            storage_options.region if storage_options else None,
            storage_options.endpoint if storage_options else None,
            storage_options.virtual_hosted_style if storage_options else None,
            storage_options.allow_http if storage_options else None,
            options.format.value if options.format else None,
            options.reader_batch_size,
            options.max_concurrent_files,
        )

    async def _scan(
        self,
        table_name: str,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> ResultSet:
        try:
            return _result_set_from_native(
                await self._client.scan_data(
                    table_name,
                    select,
                    where,
                    limit,
                    include_metrics,
                    allow_writer,
                )
            )
        except Exception as error:
            raise QueryError(f"Scan failed: {error}")

    async def _scan_stream(
        self,
        table_name: str,
        *,
        select: Optional[str] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
        include_metrics: Optional[bool] = None,
        allow_writer: Optional[bool] = None,
    ) -> RecordBatchStream:
        try:
            native_stream = await self._client.scan_data_stream(
                table_name,
                select,
                where,
                limit,
                include_metrics,
                allow_writer,
            )
            return _record_batch_stream_from_native(native_stream, run_async=None)
        except Exception as error:
            raise QueryError(f"Open scan stream failed: {error}")

    async def _vector_search(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        try:
            return _result_set_from_native(
                await self._client.vector_search(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    ef_search,
                    select,
                    where,
                )
            )
        except Exception as error:
            raise QueryError(f"Vector search failed: {error}")

    async def _vector_search_batch(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        try:
            return _result_sets_from_native(
                await self._client.vector_search_batch(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    ef_search,
                    select,
                    where,
                )
            )
        except Exception as error:
            raise QueryError(f"Vector batch search failed: {error}")

    async def _vector_search_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        try:
            native_stream = await self._client.vector_search_stream(
                table_name,
                index_name,
                queries,
                top_k,
                ef_search,
                select,
                where,
            )
            return _record_batch_stream_from_native(native_stream, run_async=None)
        except Exception as error:
            raise QueryError(f"Open vector search stream failed: {error}")

    async def _vector_search_batch_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[List[float]],
        *,
        top_k: int = 10,
        ef_search: Optional[int] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        try:
            native_stream = await self._client.vector_search_batch_stream(
                table_name,
                index_name,
                queries,
                top_k,
                ef_search,
                select,
                where,
            )
            return _result_set_stream_from_native(native_stream, run_async=None)
        except Exception as error:
            raise QueryError(f"Open vector batch stream failed: {error}")

    async def _sparse_search(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSet:
        try:
            return _result_set_from_native(
                await self._client.vector_search_sparse(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    bm25_k,
                    bm25_b,
                    sparse_metadata,
                    select,
                    where,
                )
            )
        except Exception as error:
            raise QueryError(f"Sparse search failed: {error}")

    async def _sparse_search_batch(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSets:
        try:
            return _result_sets_from_native(
                await self._client.vector_search_sparse_batch(
                    table_name,
                    index_name,
                    queries,
                    top_k,
                    bm25_k,
                    bm25_b,
                    sparse_metadata,
                    select,
                    where,
                )
            )
        except Exception as error:
            raise QueryError(f"Sparse batch search failed: {error}")

    async def _sparse_search_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> RecordBatchStream:
        try:
            native_stream = await self._client.vector_search_sparse_stream(
                table_name,
                index_name,
                queries,
                top_k,
                bm25_k,
                bm25_b,
                sparse_metadata,
                select,
                where,
            )
            return _record_batch_stream_from_native(native_stream, run_async=None)
        except Exception as error:
            raise QueryError(f"Open sparse search stream failed: {error}")

    async def _sparse_search_batch_stream(
        self,
        table_name: str,
        index_name: str,
        queries: List[str],
        *,
        top_k: int = 10,
        bm25_k: Optional[float] = None,
        bm25_b: Optional[float] = None,
        sparse_metadata: Optional[Dict[str, Any]] = None,
        select: Optional[str] = None,
        where: Optional[str] = None,
    ) -> ResultSetStream:
        try:
            native_stream = await self._client.vector_search_sparse_batch_stream(
                table_name,
                index_name,
                queries,
                top_k,
                bm25_k,
                bm25_b,
                sparse_metadata,
                select,
                where,
            )
            return _result_set_stream_from_native(native_stream, run_async=None)
        except Exception as error:
            raise QueryError(f"Open sparse batch stream failed: {error}")

    async def _hybrid_search(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSet:
        options = options or HybridSearchOptions()
        try:
            return _result_set_from_native(
                await self._client.hybrid_search(
                    table_name,
                    top_k,
                    dense_column,
                    dense_queries,
                    sparse_column,
                    sparse_queries,
                    options.fusion,
                    options.rrf_k,
                    options.alpha,
                    options.ef_search,
                    options.bm25_k,
                    options.bm25_b,
                    options.sparse_metadata,
                    options.projection,
                    options.filter,
                )
            )
        except Exception as error:
            raise QueryError(f"Hybrid search failed: {error}")

    async def _hybrid_search_batch(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSets:
        options = options or HybridSearchOptions()
        try:
            return _result_sets_from_native(
                await self._client.hybrid_search_batch(
                    table_name,
                    top_k,
                    dense_column,
                    dense_queries,
                    sparse_column,
                    sparse_queries,
                    options.fusion,
                    options.rrf_k,
                    options.alpha,
                    options.ef_search,
                    options.bm25_k,
                    options.bm25_b,
                    options.sparse_metadata,
                    options.projection,
                    options.filter,
                )
            )
        except Exception as error:
            raise QueryError(f"Hybrid batch search failed: {error}")

    async def _hybrid_search_stream(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> RecordBatchStream:
        options = options or HybridSearchOptions()
        try:
            native_stream = await self._client.hybrid_search_stream(
                table_name,
                top_k,
                dense_column,
                dense_queries,
                sparse_column,
                sparse_queries,
                options.fusion,
                options.rrf_k,
                options.alpha,
                options.ef_search,
                options.bm25_k,
                options.bm25_b,
                options.sparse_metadata,
                options.projection,
                options.filter,
            )
            return _record_batch_stream_from_native(native_stream, run_async=None)
        except Exception as error:
            raise QueryError(f"Open hybrid search stream failed: {error}")

    async def _hybrid_search_batch_stream(
        self,
        table_name: str,
        *,
        top_k: int,
        dense_column: str,
        dense_queries: List[List[float]],
        sparse_column: str,
        sparse_queries: List[str],
        options: Optional[HybridSearchOptions] = None,
    ) -> ResultSetStream:
        options = options or HybridSearchOptions()
        try:
            native_stream = await self._client.hybrid_search_batch_stream(
                table_name,
                top_k,
                dense_column,
                dense_queries,
                sparse_column,
                sparse_queries,
                options.fusion,
                options.rrf_k,
                options.alpha,
                options.ef_search,
                options.bm25_k,
                options.bm25_b,
                options.sparse_metadata,
                options.projection,
                options.filter,
            )
            return _result_set_stream_from_native(native_stream, run_async=None)
        except Exception as error:
            raise QueryError(f"Open hybrid batch stream failed: {error}")
