# PatchPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**owner_group_id** | **str** |  | [optional] 
**webhook_id** | **str** |  | [optional] 
**grace_period_days** | **int** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.patch_policy import PatchPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of PatchPolicy from a JSON string
patch_policy_instance = PatchPolicy.from_json(json)
# print the JSON string representation of the object
print(PatchPolicy.to_json())

# convert the object into a dict
patch_policy_dict = patch_policy_instance.to_dict()
# create an instance of PatchPolicy from a dict
patch_policy_from_dict = PatchPolicy.from_dict(patch_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


