# Policy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Time of record creation. | 
**updated_at** | **datetime** | Time of last record update. | 
**id** | **str** | The ID of the policy. | 
**organization_id** | **str** | The ID of the organization. | 
**name** | **str** | The name of the policy. | 
**description** | **str** |  | [optional] 
**owner_group_id** | **str** | The ID of the group that owns this policy. | 
**webhook_id** | **str** | The ID of the notification webhook. | 
**grace_period_days** | **int** | The number of days for the grace period. | 
**alert_rules** | [**List[PolicyAlertRule]**](PolicyAlertRule.md) | Alert rules attached to this policy. | 
**attestation_rules** | [**List[PolicyAttestationRule]**](PolicyAttestationRule.md) | Attestation rules attached to this policy. | 
**last_updated_by_user_id** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.policy import Policy

# TODO update the JSON string below
json = "{}"
# create an instance of Policy from a JSON string
policy_instance = Policy.from_json(json)
# print the JSON string representation of the object
print(Policy.to_json())

# convert the object into a dict
policy_dict = policy_instance.to_dict()
# create an instance of Policy from a dict
policy_from_dict = Policy.from_dict(policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


