# PostPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of the policy. | 
**description** | **str** |  | [optional] 
**owner_group_id** | **str** | The ID of the group that owns this policy. | 
**webhook_id** | **str** | The ID of the notification webhook. | 
**grace_period_days** | **int** | The number of days for the grace period. | 

## Example

```python
from arthur_client.api_bindings.models.post_policy import PostPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of PostPolicy from a JSON string
post_policy_instance = PostPolicy.from_json(json)
# print the JSON string representation of the object
print(PostPolicy.to_json())

# convert the object into a dict
post_policy_dict = post_policy_instance.to_dict()
# create an instance of PostPolicy from a dict
post_policy_from_dict = PostPolicy.from_dict(post_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


