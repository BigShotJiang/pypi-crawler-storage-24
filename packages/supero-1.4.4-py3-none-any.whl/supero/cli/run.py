"""
supero.cli.run — Main orchestrator for Supero App Runner

Entry point: python3 -m supero.cli

Lean orchestrator — 5 steps:
  1. Validate project files exist (schemas.py, config.py, setup.py)
  2. Interactive .env setup (if not configured)
  3. CDN downloads (supero-ui.js, index.html, server.py, config.js)
  4. Run setup.py (handles ALL platform interaction via AppSetup)
  5. Start server (or mobile, or docker)

The CLI does NOT duplicate platform logic — setup.py's AppSetup.run()
handles domain bootstrap, schema upload, services, workflows, policies,
and seed data. The CLI only ensures .env + infrastructure files exist.
"""

import os
import sys
import time
import socket
import subprocess
import argparse

from supero.cli.env_manager import EnvManager
from supero.cli.interactive import interactive_setup
from supero.cli.cdn_downloader import CdnDownloader

__version__ = "1.0.0"

# ── ANSI colors for terminal output ──
class _C:
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"

def _ok(msg):     print(f"  {_C.GREEN}✓{_C.RESET} {msg}")
def _warn(msg):   print(f"  {_C.YELLOW}⚠{_C.RESET} {msg}")
def _fail(msg):   print(f"  {_C.RED}✗{_C.RESET} {msg}")
def _info(msg):   print(f"  {_C.DIM}{msg}{_C.RESET}")
def _header(msg): print(f"\n{_C.BOLD}── {msg} ──{_C.RESET}\n")


def parse_args():
    parser = argparse.ArgumentParser(
        prog="supero-run",
        description="Supero App Runner — interactive setup + server launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ./run.sh                    Interactive setup + start server
  ./run.sh --setup-only       Run setup without starting server
  ./run.sh --server-only      Start server (skip setup)
  ./run.sh --mobile           Also set up mobile app
  ./run.sh --docker           Build and run with Docker Compose
  ./run.sh --no-interactive   Use .env values without prompting
  ./run.sh --reset            Re-upload schemas and re-run setup
        """
    )
    parser.add_argument("--setup-only", action="store_true",
                        help="Run setup without starting server")
    parser.add_argument("--server-only", action="store_true",
                        help="Start server without running setup")
    parser.add_argument("--mobile", action="store_true",
                        help="Also set up the mobile app (Expo)")
    parser.add_argument("--docker", action="store_true",
                        help="Build and run with Docker Compose")
    parser.add_argument("--port", type=int,
                        help="Override server port (default: from .env or 5648)")
    parser.add_argument("--no-interactive", action="store_true",
                        help="Use .env values without prompting")
    parser.add_argument("--reset", action="store_true",
                        help="Re-upload schemas and re-run setup")
    parser.add_argument("--verbose", action="store_true",
                        help="Show detailed logs from setup and server")
    parser.add_argument("--no-seed", action="store_true",
                        help="Skip seeding test data (seed runs by default)")
    parser.add_argument("--seed", action="store_true", default=True,
                        help=argparse.SUPPRESS)  # kept for backwards compat
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {__version__}")
    return parser.parse_args()


def validate_project(path: str) -> dict:
    """
    Validate that required project files exist.
    Returns dict with has_web and has_mobile flags.
    """
    required = [
        ("schemas.py", "Schema definitions"),
        ("config.py",  "App configuration"),
        ("setup.py",   "Setup script"),
    ]

    missing = []
    for filename, desc in required:
        filepath = os.path.join(path, filename)
        if os.path.exists(filepath):
            _ok(f"Found {filename}")
        else:
            _fail(f"Missing {filename} ({desc})")
            missing.append(filename)

    # Check for ui/app.js in both app_dir and project root (CWD)
    has_web = (
        os.path.exists(os.path.join(path, "ui", "app.js"))
        or os.path.exists(os.path.join(os.getcwd(), "ui", "app.js"))
    )

    # Mobile dir can be inside the app package OR at the project root
    has_mobile = (
        os.path.exists(os.path.join(path, "mobile", "src", "appConfig.ts"))
        or os.path.exists(os.path.join(os.getcwd(), "mobile", "src", "appConfig.ts"))
    )

    if has_web:
        _ok("Found ui/app.js (Web UI)")
    if has_mobile:
        _ok("Found mobile/src/appConfig.ts (Mobile)")

    if not has_web and not has_mobile:
        _warn("No ui/app.js or mobile/src/appConfig.ts found")

    if missing:
        print()
        _fail(f"Missing required files: {', '.join(missing)}")
        print(f"  {_C.DIM}Make sure you're in the app root directory.{_C.RESET}")
        sys.exit(1)

    return {"has_web": has_web, "has_mobile": has_mobile}


def _find_app_dir() -> str:
    """
    Find the app package directory (contains setup.py at top level
    and ui/ subdirectory).

    Generated apps have this layout:
      project_root/
      ├── run.sh
      ├── package_name/
      │   ├── setup.py
      │   ├── config.py
      │   ├── schemas.py
      │   └── ui/
      │       └── app.js
      └── ...

    OR flat layout (setup.py at CWD level):
      project_root/
      ├── run.sh
      ├── setup.py
      ├── config.py
      ├── schemas.py
      └── ui/
          └── app.js

    Returns the directory containing setup.py.
    """
    cwd = os.getcwd()

    # Flat layout: setup.py in CWD
    if os.path.exists(os.path.join(cwd, "setup.py")):
        return cwd

    # Package layout: look for a subdirectory with setup.py
    for entry in os.listdir(cwd):
        candidate = os.path.join(cwd, entry)
        if (os.path.isdir(candidate)
                and not entry.startswith(".")
                and entry not in ("mobile", "e2e-tests", ".venv", "__pycache__")
                and os.path.exists(os.path.join(candidate, "setup.py"))):
            return candidate

    # Fallback: CWD
    return cwd


def _get_lan_ip() -> str:
    """Get LAN IP address for the network URL display."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "0.0.0.0"


def _read_app_meta(app_dir: str) -> dict:
    """
    Extract app metadata from config.py.

    Looks for app_name, app_emoji, app_description attributes
    in the config class or as module-level variables.

    Returns dict with keys: name, emoji, description (all strings, may be empty).
    """
    config_path = os.path.join(app_dir, "config.py")
    result = {"name": "", "emoji": "", "description": ""}
    if not os.path.exists(config_path):
        return result

    # Map config.py attribute names to our result keys
    # Use specific prefixed names to avoid matching unrelated attributes
    # like workflow descriptions or policy descriptions
    attr_map = {
        "app_name": "name",
        "display_name": "name",
        "app_emoji": "emoji",
        "app_description": "description",
    }

    try:
        with open(config_path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                for attr, key in attr_map.items():
                    if line.startswith(f"{attr}") and "=" in line:
                        val = line.split("=", 1)[1].strip().strip("'\"")
                        if val and not result[key]:  # first match wins
                            result[key] = val
    except Exception:
        pass
    return result


def main():
    args = parse_args()

    # ── Banner ──
    print()
    print(f"{_C.BOLD}🚀 Supero App Runner v{__version__}{_C.RESET}")
    print("━" * 40)
    print()

    # ── Step 1: Find app directory and validate files ──
    _header("Step 1 · Checking project files")
    app_dir = _find_app_dir()

    if app_dir != os.getcwd():
        _info(f"App directory: {os.path.basename(app_dir)}/")

    project = validate_project(app_dir)

    # Resolve ui_dir — may be in app_dir or project root
    if os.path.exists(os.path.join(app_dir, "ui", "app.js")):
        ui_base = app_dir
    elif os.path.exists(os.path.join(os.getcwd(), "ui", "app.js")):
        ui_base = os.getcwd()
    else:
        ui_base = app_dir

    # ── Step 2: Environment setup ──
    env = EnvManager(env_path=os.path.join(os.getcwd(), ".env"))

    if not args.server_only:
        if args.reset:
            _header("Step 2 · Resetting configuration")
            env.clear()
            _ok("Configuration cleared")
            print()

        if not env.is_configured() or args.reset:
            _header("Step 2 · Domain configuration")
            if args.no_interactive:
                _fail(".env not configured. Run without --no-interactive first.")
                sys.exit(1)
            interactive_setup(env)
        else:
            _header("Step 2 · Using saved configuration")
            _ok(f"Domain:  {env.get('SUPERO_DOMAIN')}")
            _ok(f"Project: {env.get('SUPERO_PROJECT', 'default-project')}")
            _ok(f"Email:   {env.get('SUPERO_ADMIN_EMAIL')}")
    else:
        if not env.is_configured():
            _fail("No .env configuration found. Run without --server-only first.")
            sys.exit(1)
        _header("Step 2 · Skipped (--server-only)")
        _ok(f"Domain: {env.get('SUPERO_DOMAIN')}")

    # ── Derive SDK env vars from SUPERO_URL ──
    env.derive_sdk_vars()

    # ── Step 3: CDN downloads + generate infrastructure files ──
    if project["has_web"]:
        _header("Step 3 · Preparing web UI files")
        ui_dir = os.path.join(ui_base, "ui")

        # Read app metadata from config.py (name, emoji, description)
        meta = _read_app_meta(app_dir)
        app_name = env.get("APP_NAME") or meta["name"] or env.get(
            "SUPERO_DOMAIN", "Supero App"
        ).replace("-", " ").title()
        app_emoji = env.get("APP_EMOJI") or meta["emoji"]
        app_description = env.get("APP_DESCRIPTION") or meta["description"]

        cdn = CdnDownloader(verbose=args.verbose)
        cdn.ensure_files(ui_dir, app_name=app_name)
        env.generate_config_js(
            ui_dir,
            app_name=app_name,
            app_emoji=app_emoji,
            app_description=app_description,
        )
    else:
        _header("Step 3 · Skipped (no web UI)")
        _info("No ui/app.js found, skipping CDN downloads")

    # ── Step 4: Run setup.py ──
    if not args.server_only:
        _header("Step 4 · Running platform setup")
        _info("This registers the domain, uploads schemas, configures services...")
        print()

        setup_cmd = [sys.executable, "setup.py"]

        # Pass credentials
        domain = env.get("SUPERO_DOMAIN")
        email = env.get("SUPERO_ADMIN_EMAIL")
        password = env.get("SUPERO_PASSWORD")
        if domain:
            setup_cmd.extend(["--domain", domain])
        if email:
            setup_cmd.extend(["--admin-email", email])
        if password:
            setup_cmd.extend(["--password", password])

        # Only pass --no-seed if user explicitly opted out
        # (setup.py seeds by default when seed_fn is provided)
        if args.no_seed:
            setup_cmd.append("--no-seed")

        if args.verbose:
            result = subprocess.run(setup_cmd, cwd=app_dir)
        else:
            result = subprocess.run(
                setup_cmd, cwd=app_dir,
                capture_output=True, text=True
            )
            # Show summary lines from setup output
            if result.stdout:
                for line in result.stdout.splitlines():
                    # Surface meaningful status lines
                    if any(k in line for k in ("✅", "✓", "⚠", "❌", "Error",
                                                "created", "skipped", "failed",
                                                "uploaded", "registered", "logged")):
                        print(f"  {line.strip()}")

        if result.returncode != 0:
            print()
            _fail("Setup failed")
            if not args.verbose:
                if result.stderr:
                    print(f"\n{_C.DIM}Error output:{_C.RESET}")
                    # Show last 20 lines of stderr
                    for line in result.stderr.strip().splitlines()[-20:]:
                        print(f"  {line}")
                print()
                _info("Tip: run with --verbose for full output")
                _info("Tip: run with --reset to clear config and retry")
            sys.exit(1)

        print()
        _ok("Platform setup complete")
    else:
        _header("Step 4 · Skipped (--server-only)")

    # ── Reload .env after setup (bootstrap may have written api_key) ──
    env.reload()

    # ── Regenerate config.js after setup (may have new api_key/tenant) ──
    if project["has_web"]:
        ui_dir = os.path.join(ui_base, "ui")
        meta = _read_app_meta(app_dir)
        env.generate_config_js(
            ui_dir,
            app_name=meta["name"],
            app_emoji=meta["emoji"],
            app_description=meta["description"],
        )

    # ── Step 5: Start server / mobile / docker ──
    if not args.setup_only:
        port = args.port or int(env.get("PORT", env.get("UI_PORT", "5648")))

        if args.docker:
            _header("Step 5 · Starting with Docker Compose")
            subprocess.run(["docker", "compose", "up", "--build"])

        elif project["has_web"]:
            _header("Step 5 · Starting web server")

            ui_dir = os.path.join(ui_base, "ui")
            server_py = os.path.join(ui_dir, "server.py")

            if not os.path.exists(server_py):
                _fail(f"server.py not found in {ui_dir}")
                sys.exit(1)

            # Kill any existing process on this port
            try:
                result = subprocess.run(
                    ["lsof", "-ti", f"tcp:{port}"],
                    capture_output=True, text=True
                )
                if result.stdout.strip():
                    pids = result.stdout.strip()
                    _info(f"Stopping existing process on port {port}...")
                    subprocess.run(
                        ["kill", "-9"] + pids.split(),
                        capture_output=True
                    )
                    time.sleep(1)
            except FileNotFoundError:
                pass  # lsof not available on this platform

            lan_ip = _get_lan_ip()
            admin_email = env.get("SUPERO_ADMIN_EMAIL", "admin@example.com")

            print()
            print(f"  {_C.GREEN}{_C.BOLD}✅ READY{_C.RESET}")
            print()
            print(f"  {_C.CYAN}Local:{_C.RESET}    http://localhost:{port}")
            if lan_ip != "0.0.0.0":
                print(f"  {_C.CYAN}Network:{_C.RESET}  http://{lan_ip}:{port}")
            print()
            print(f"  {_C.CYAN}Login:{_C.RESET}    {admin_email}")
            print()
            print(f"  {_C.DIM}Press Ctrl+C to stop{_C.RESET}")
            print()

            # Set PORT env var for server.py
            os.environ["PORT"] = str(port)
            os.environ["UI_PORT"] = str(port)

            try:
                subprocess.run(
                    [sys.executable, "server.py"],
                    cwd=ui_dir
                )
            except KeyboardInterrupt:
                print(f"\n  {_C.DIM}Server stopped.{_C.RESET}")

        else:
            _ok("Setup complete (no web UI to start)")

    else:
        _header("Step 5 · Skipped (--setup-only)")
        _ok("Setup complete. Run without --setup-only to start the server.")

    # ── Mobile setup (optional, after web server) ──
    if args.mobile:
        if project["has_mobile"]:
            _header("Mobile · Setting up Expo app")
            mobile_dir = os.path.join(os.getcwd(), "mobile")
            expo_sh = os.path.join(mobile_dir, "expo.sh")

            if os.path.exists(expo_sh):
                subprocess.run(["bash", expo_sh, "setup"], cwd=mobile_dir)
                _ok("Mobile app ready")
                _info("Start with: cd mobile && ./expo.sh start")
            else:
                _warn("mobile/expo.sh not found — download it from CDN first")
                _info("curl -sL https://cdn.supero.dev/mobile/1.0.0/expo.sh -o mobile/expo.sh")
        else:
            _warn("No mobile/src/appConfig.ts found — skipping mobile setup")


if __name__ == "__main__":
    main()
