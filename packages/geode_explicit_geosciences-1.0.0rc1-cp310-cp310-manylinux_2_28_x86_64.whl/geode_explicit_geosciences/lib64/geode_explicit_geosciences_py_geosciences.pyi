"""
Geode-Explicit_Geosciences Python binding for geological models
"""
from __future__ import annotations
import collections.abc
import geode_explicit.lib64.geode_explicit_py_brep
import geode_explicit.lib64.geode_explicit_py_common
import opengeode.lib64.opengeode_py_basic
import opengeode.lib64.opengeode_py_mesh
import opengeode_geosciences.lib64.opengeode_geosciences_py_explicit
__all__: list[str] = ['ExplicitGeosciencesGeosciencesLibrary', 'StructuralModelExplicitModeler']
class ExplicitGeosciencesGeosciencesLibrary:
    @staticmethod
    def initialize() -> None:
        ...
class StructuralModelExplicitModeler(geode_explicit.lib64.geode_explicit_py_brep.BRepExplicitModeler):
    def __init__(self, arg0: opengeode_geosciences.lib64.opengeode_geosciences_py_explicit.StructuralModel, arg1: geode_explicit.lib64.geode_explicit_py_brep.BRepExplicitModelerParameters) -> None:
        ...
    def add_fault(self, arg0: collections.abc.Sequence[opengeode.lib64.opengeode_py_mesh.TriangulatedSurface3D]) -> opengeode.lib64.opengeode_py_basic.uuid:
        ...
    def add_horizon(self, arg0: collections.abc.Sequence[opengeode.lib64.opengeode_py_mesh.TriangulatedSurface3D]) -> opengeode.lib64.opengeode_py_basic.uuid:
        ...
    def process(self) -> geode_explicit.lib64.geode_explicit_py_common.MeshElements:
        ...
