#
# Copyright (c) 2019 - 2026 Geode-solutions. All rights reserved.
#

import opengeode
import opengeode_geosciences
import opengeode_inspector
import geode_common
import geode_conversion
import geode_background
import geode_explicit

from .lib64.geode_explicit_geosciences_py_geosciences import *
ExplicitGeosciencesGeosciencesLibrary.initialize()
