## Compatibility Matrix

The table below is generated from `scripts/compat_matrix.py`.

| Integration | Version set | Dependencies | Supported Python |
|---|---|---|---|
| `onnx` | `min` | `onnxruntime==1.18.1`, `numpy==1.26.4` | 3.10, 3.11, 3.12, 3.13, 3.14 |
| `onnx` | `min` (`py3.13` override) | `onnxruntime==1.20.1`, `numpy==2.1.3` | 3.13 |
| `onnx` | `current` | `onnxruntime==1.20.1`, `numpy==2.1.3` | 3.10, 3.11, 3.12, 3.13, 3.14 |
| `torch` | `min` | `torch==2.4.1`, `numpy==1.26.4` | 3.10, 3.11, 3.12, 3.13, 3.14 |
| `torch` | `min` (`py3.13` override) | `torch==2.6.0`, `numpy==2.1.3` | 3.13 |
| `torch` | `min` (`py3.14` override) | `torch==2.5.0`, `numpy==2.1.3` | 3.14 |
| `torch` | `current` | `torch==2.6.0`, `numpy==2.1.3` | 3.10, 3.11, 3.12, 3.13, 3.14 |
| `torch` | `current` (`py3.14` override) | `torch==2.10.0`, `numpy==2.1.3` | 3.14 |
| `timm` | `min` | `torch==2.4.1`, `torchvision==0.19.1`, `timm==1.0.11`, `numpy==1.26.4` | 3.10, 3.11, 3.12, 3.13, 3.14 |
| `timm` | `min` (`py3.13` override) | `torch==2.6.0`, `torchvision==0.21.0`, `timm==1.0.11`, `numpy==2.1.3` | 3.13 |
| `timm` | `min` (`py3.14` override) | `torch==2.5.0`, `torchvision==0.19.1`, `timm==1.0.11`, `numpy==2.1.3` | 3.14 |
| `timm` | `current` | `torch==2.6.0`, `torchvision==0.21.0`, `timm==1.0.15`, `numpy==2.1.3` | 3.10, 3.11, 3.12, 3.13, 3.14 |
| `timm` | `current` (`py3.14` override) | `torch==2.10.0`, `torchvision==0.25.0`, `timm==1.0.15`, `numpy==2.1.3` | 3.14 |
| `tensorflow` | `min` | `tensorflow==2.16.1`, `keras==3.3.3`, `numpy==1.26.4` | 3.10, 3.11, 3.12 |
| `tensorflow` | `current` | `tensorflow==2.18.0`, `keras==3.8.0`, `numpy==2.0.2` | 3.10, 3.11, 3.12 |
