def check_bro(name):
    if name == "vignesh" or name == "amal" or name == "sarath":
        print("bro is dump")
    elif name == "aswin":
        print("bro is god")
    elif name == "anandhu":
        print("bro is npc")
    else:
        print("bro is unknown")
