from setuptools import setup, find_packages

setup(
    name="is_dump",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        #add any dependencies here
        #be good as bp
    ]
)