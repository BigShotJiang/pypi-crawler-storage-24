import asyncio
import threading
from typing import Any, cast

import pytest

from bluesky_nats.nats_publisher import CoroutineExecutor


@pytest.mark.asyncio
async def test_submit_coroutine_function():
    """Test the submit method with a coroutine function."""

    async def coro_func(x, y):
        await asyncio.sleep(0.1)
        return x + y

    executor = CoroutineExecutor()
    future = executor.submit(coro_func, 1, 2)
    result = await asyncio.wrap_future(future)
    assert result == 3


@pytest.mark.asyncio
async def test_submit_non_coroutine_function():
    """Test the submit method with a regular function."""

    def regular_func(x, y):
        return x * y

    executor = CoroutineExecutor()
    future = executor.submit(regular_func, 2, 3)
    result = await asyncio.wrap_future(future)
    assert result == 6


@pytest.mark.asyncio
async def test_submit_non_callable():
    """Test the submit method with a non-callable object."""
    executor = CoroutineExecutor()
    with pytest.raises(TypeError, match="Expected callable"):
        executor.submit(123)  # pyright: ignore[reportArgumentType]


def test_shutdown_prevents_new_submissions() -> None:
    """Executor rejects new work after shutdown."""
    executor = CoroutineExecutor()
    executor.shutdown()

    with pytest.raises(RuntimeError, match="CoroutineExecutor is shut down"):
        executor.submit(lambda: 1)


def test_shutdown_called_from_io_loop_thread() -> None:
    """Shutdown from the IO loop thread should not close a running loop directly."""
    executor = CoroutineExecutor()
    finished = threading.Event()

    async def shutdown_on_loop() -> None:
        executor.shutdown(wait=True)
        finished.set()

    future = executor.submit_coroutine(shutdown_on_loop())
    did_finish = finished.wait(timeout=2)
    assert did_finish
    future.result(timeout=2)

    with pytest.raises(RuntimeError, match="CoroutineExecutor is shut down"):
        executor.submit(lambda: 1)


@pytest.mark.asyncio
async def test_constructor_rejects_removed_loop_argument() -> None:
    """The loop argument was removed to enforce isolated executor event-loop ownership."""
    running_loop = asyncio.get_running_loop()
    executor_ctor = cast("Any", CoroutineExecutor)

    with pytest.raises(TypeError):
        executor_ctor(running_loop)
