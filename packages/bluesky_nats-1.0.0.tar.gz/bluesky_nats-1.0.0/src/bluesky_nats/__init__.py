"""bluesky-nats module."""
