from __future__ import with_statement
import re
words = []
testword = []
ans = []
print("MENU")
print()
print(" 1 . Hash tag segmentation ")
print(" 2 . URL segmentation ")

choice = 0
while choice not in [1, 2]:
    try:
        print("enter the input choice for performing word segmentation")
        choice = int(input())
        if choice not in [1, 2]:
            print("Invalid choice. Please enter 1 or 2.")
    except ValueError:
        print("Invalid input. Please enter a number (1 or 2).")

if choice == 1:
    text = "#hello how are you"
    print("input with HashTag",text)
    pattern=re.compile(r"[^\w']")
    a = pattern.sub('', text)
elif choice == 2:
    text = "www.whatismyname.com"
    print("input with URL",text)
    a=re.split(r'\s|(?<!\d)[,.](?!\d)', text)
    splitwords = ["www","com","in"]
    a ="".join([each for each in a if each not in splitwords])
else:
    print("wrong choice try again")
    exit()

print("Processed input:", a)


try:
    with open('words.txt', 'r') as f:
        lines = f.readlines()
        words =[(e.strip()) for e in lines]
except FileNotFoundError:
    print("Error: 'words.txt' file not found. Please create this file with a list of words, each on a new line.")
    exit()

test_length = len(a)

def Seg(s_to_segment, s_len):
    found_segments = []
    for k in range(1, s_len + 1):
        prefix = s_to_segment[0:k]
        if prefix in words:
            print(f"'{prefix}' appears in the corpus")
            found_segments.append(prefix)
            break
    if found_segments:
        return found_segments[0]
    return ""

processed_chars_total = 0
segmented_words_list = []
current_text_to_segment = a

while processed_chars_total < test_length:
    ans_word = Seg(current_text_to_segment, len(current_text_to_segment))
    if ans_word:
        segment_length = len(ans_word)
        segmented_words_list.append(ans_word)
        current_text_to_segment = current_text_to_segment[segment_length:]
        processed_chars_total += segment_length
    else:
        if len(current_text_to_segment) > 0:
            segmented_words_list.append(current_text_to_segment[0])
            current_text_to_segment = current_text_to_segment[1:]
            processed_chars_total += 1
        else:
            break

answer = segmented_words_list
Aft_Seg = " ".join([each for each in answer])
print("\nOutput:")
print("--------")
print("Segmented text:", Aft_Seg)

C = len(answer)
score = C
print("Total segmented words (score):", score)

unique_words = set(answer)
print("Number of different words found:", len(unique_words))
print("Different words found:", list(unique_words))
