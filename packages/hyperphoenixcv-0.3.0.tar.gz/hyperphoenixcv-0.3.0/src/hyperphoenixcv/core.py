from __future__ import annotations

"""
HyperPhoenixCV - Resumable hyperparameter search with checkpoint support.

This module provides the HyperPhoenixCV class, which extends the functionality
of scikit-learn's GridSearchCV by adding checkpoint support, random search,
and Bayesian optimization to accelerate the search for optimal hyperparameters.
"""

import os
import numpy as np
import pandas as pd
from typing import Union
from sklearn.base import BaseEstimator
from sklearn.exceptions import NotFittedError
from sklearn.utils.validation import check_is_fitted

from .search_strategies import create_search_strategy
from .checkpoint import CheckpointManager
from .result_manager import ResultManager
from .cv_executor import CVExecutor


class HyperPhoenixCV(BaseEstimator):
    """
    Resumable hyperparameter search with checkpoint support and Bayesian optimization.
    Supports exhaustive grid search, random search, and Bayesian optimization.

    Example usage:
    # Create an instance
    hp = HyperPhoenixCV(
        estimator=combat_pipeline,
        param_grid={
            'tfidf__max_features': [8000, 12000, 15000],
            'tfidf__ngram_range': [(1,1), (1,2)],
            'clf__C': [0.001, 0.01, 0.1],
            'clf__penalty': ['l1','l2'],
            'clf__solver': ['liblinear', 'saga'],
            'clf__class_weight': [None, 'balanced']
        },
        scoring=['f1', 'accuracy'],
        cv=5,
        n_jobs=-2,
        checkpoint_path="experiment_checkpoint.pkl",
        results_csv="experiment_results.csv",
        verbose=True
    )

    # Start the search
    hp.fit(X, y)

    # If the process was interrupted, run again with the same checkpoint_path:
    hp.fit(X, y)  # Will continue from the last saved point!

    # Get results
    print("Best parameters:", hp.best_params_)
    print("Best score:", hp.best_score_)

    # Top-10 results
    top_10 = hp.get_top_results(10)
    print(top_10)

    # Manually delete checkpoint
    hp.clear_checkpoint()
    """

    def __init__(
        self,
        estimator,
        param_grid: dict,
        scoring: str | list[str] = 'f1',
        cv: int = 5,
        n_jobs: int = 1,
        checkpoint_path: str = "hyperphoenix_checkpoint.pkl",
        results_csv: str = "hyperphoenix_results.csv",
        verbose: bool = True,
        clear_checkpoint: bool = False,
        random_search: bool = False,
        n_iter: int = 10,
        random_state: int | None = None,
        use_bayesian_optimization: bool = False,
        bayesian_optimizer = None,
        refit: bool = True,
        pre_dispatch: str = '2*n_jobs',
        error_score: Union[str, float] = 'raise',
        early_stopping_patience: int | None = None,
    ):
        """
        Initializes HyperPhoenixCV.

        Parameters:
        -----------
        estimator : sklearn estimator
            Model/pipeline for hyperparameter tuning
        param_grid : dict
            Dictionary of parameters to search over
        scoring : str or list of str
            Metrics for evaluation (e.g., 'f1', 'accuracy' or ['f1', 'accuracy'])
        cv : int
            Number of folds for cross-validation
        n_jobs : int
            Number of processes for parallel computation
        checkpoint_path : str
            Path to checkpoint file
        results_csv : str
            Path to CSV file for results
        verbose : bool
            Whether to print progress
        clear_checkpoint : bool
            Whether to delete existing checkpoint on initialization
        random_search : bool
            Whether to use random search instead of exhaustive grid search
        n_iter : int
            Number of random combinations (if random_search=True)
        random_state : int, optional
            Random seed for reproducibility
        use_bayesian_optimization : bool
            Whether to use Bayesian optimization (predictive parameter selection)
        bayesian_optimizer : sklearn regressor, optional
            Model that predicts which parameters will perform better
            (defaults to RandomForestRegressor)
        refit : bool, default=True
            Whether to refit the best model on the entire dataset after search.
            If True, after hyperparameter search completes, `best_estimator_.fit(X, y)` will be called.
        pre_dispatch : str, default='2*n_jobs'
            Controls the number of jobs that get dispatched during parallel
            execution. See `sklearn.model_selection.cross_validate`.
        error_score : 'raise' or numeric, default='raise'
            Value to assign to the score if an error occurs in the estimator.
            If 'raise', the error is raised.
        early_stopping_patience : int, optional
            If set, stop the search after this many iterations without improvement
            in the primary metric (scoring[0]). Useful for random search and
            Bayesian optimization to avoid unnecessary evaluations.
        """
        self.estimator = estimator
        self.param_grid = param_grid
        self.scoring = scoring if isinstance(scoring, list) else [scoring]
        self.cv = cv
        self.n_jobs = n_jobs
        self.checkpoint_path = checkpoint_path
        self.results_csv = results_csv
        self.verbose = verbose
        self.random_search = random_search
        self.n_iter = n_iter
        self.random_state = random_state
        self.use_bayesian_optimization = use_bayesian_optimization
        self.bayesian_optimizer = bayesian_optimizer
        self.refit = refit
        self.pre_dispatch = pre_dispatch
        self.error_score = error_score
        self.early_stopping_patience = early_stopping_patience

        # Create components
        self.search_strategy = create_search_strategy(
            param_grid=param_grid,
            random_search=random_search,
            use_bayesian_optimization=use_bayesian_optimization,
            n_iter=n_iter,
            random_state=random_state,
            bayesian_optimizer=bayesian_optimizer,
            scoring=self.scoring[0] if self.scoring else 'f1',
        )
        self.checkpoint_manager = CheckpointManager(
            checkpoint_path=checkpoint_path,
            verbose=verbose,
        )
        self.result_manager = ResultManager(
            scoring=self.scoring,
            results_csv=results_csv,
        )
        self.cv_executor = CVExecutor(
            cv=cv,
            scoring=self.scoring,
            n_jobs=n_jobs,
            verbose=verbose,
            pre_dispatch=pre_dispatch,
            error_score=error_score,
        )

        # Delete checkpoint if specified
        if clear_checkpoint:
            self.checkpoint_manager.clear()

        # Attributes that will be set after fit
        self.best_params_ = {}
        self.best_score_ = 0.0
        self.best_estimator_ = None
        self.cv_results_ = {}
        self.best_index_ = None

    def _format_metric_string(self, result: dict) -> str:
        """
        Format metrics from a result dictionary into a readable string.

        Parameters:
        -----------
        result : dict
            Result dictionary containing mean_test_* and std_test_* keys.

        Returns:
        --------
        str
            Formatted string like "f1: 0.85 ± 0.02 | accuracy: 0.90 ± 0.01"
        """
        metrics = []
        for metric in self.scoring:
            mean_key = f'mean_test_{metric}'
            std_key = f'std_test_{metric}'
            if mean_key in result:
                metrics.append(
                    f"{metric}: {result[mean_key]:.4f} ± {result[std_key]:.4f}"
                )
        return " | ".join(metrics)

    def _compute_best_metrics(self) -> str:
        """
        Compute the best metric values across all valid results.

        Returns:
        --------
        str
            Formatted string like "f1: 0.92 | accuracy: 0.95"
        """
        valid_results = [r for r in self.result_manager.results if 'error' not in r]
        if not valid_results:
            return ""

        best_metrics = []
        for metric in self.scoring:
            metric_key = f'mean_test_{metric}'
            best_val = max(
                r[metric_key] for r in valid_results
                if metric_key in r
            )
            best_metrics.append(f"{metric}: {best_val:.4f}")
        return " | ".join(best_metrics)

    def fit(self, X, y, groups=None):
        """
        Performs hyperparameter tuning with intermediate result saving.

        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            Training data.
        y : array-like of shape (n_samples,)
            Target values.
        groups : array-like of shape (n_samples,), default=None
            Groups for group cross-validation (if used).

        Returns:
        --------
        self : object
            Returns the instance.
        """
        # Load progress from checkpoint
        checkpoint_results = self.checkpoint_manager.load()
        self.result_manager.add_results(checkpoint_results)

        # Generate all parameter combinations
        all_params = self.search_strategy.generate_parameters()
        if self.verbose:
            print(f"Total combinations: {len(all_params)}")

        # Exclude already processed
        completed_params = [r['params'] for r in checkpoint_results if 'params' in r]
        remaining_params = [p for p in all_params if p not in completed_params]
        if self.verbose:
            print(f"Remaining to process: {len(remaining_params)}")

        # If Bayesian optimization is used, sort remaining parameters by prediction
        if self.use_bayesian_optimization:
            remaining_params = self.search_strategy.suggest_next(checkpoint_results)
            if self.verbose:
                print("Remaining parameters sorted by predicted metric.")

        # Early stopping tracking
        primary_metric = self.scoring[0]
        best_score = -float('inf')
        no_improvement_count = 0

        # Determine current best score from checkpoint results
        valid_checkpoint = [r for r in checkpoint_results if 'error' not in r]
        if valid_checkpoint:
            best_score = max(
                r.get(f'mean_test_{primary_metric}', -float('inf'))
                for r in valid_checkpoint
            )

        # Iterate over remaining parameters
        for i, params in enumerate(remaining_params, start=1):
            if self.verbose:
                print(f"\n[{i}/{len(remaining_params)}] Testing: {params}")

            result = self.cv_executor.evaluate(
                estimator=self.estimator,
                X=X,
                y=y,
                params=params,
                groups=groups,
            )
            self.result_manager.add_result(result)
            self.checkpoint_manager.save(self.result_manager.results)

            if self.verbose and 'error' not in result:
                current_str = self._format_metric_string(result)
                best_str = self._compute_best_metrics()
                print(f"Saved. Current: {current_str} | Best: {best_str}")

            # Early stopping logic
            if self.early_stopping_patience is not None:
                if 'error' not in result:
                    current_score = result.get(f'mean_test_{primary_metric}', -float('inf'))
                    if current_score > best_score + 1e-9:  # improvement
                        best_score = current_score
                        no_improvement_count = 0
                        if self.verbose:
                            print(f"🎯 Improvement detected (new best: {best_score:.4f})")
                    else:
                        no_improvement_count += 1
                        if self.verbose:
                            print(f"⏳ No improvement ({no_improvement_count}/{self.early_stopping_patience})")
                else:
                    # Error counts as no improvement
                    no_improvement_count += 1

                if no_improvement_count >= self.early_stopping_patience:
                    if self.verbose:
                        print(f"🛑 Early stopping triggered after {i} iterations (no improvement for {self.early_stopping_patience} consecutive trials).")
                    break

        # Save results to CSV
        self.result_manager.save_to_csv()

        # Update attributes for compatibility with GridSearchCV
        self.cv_results_ = self.result_manager.format_cv_results()
        self._update_best_attributes()

        # Refit the best estimator on the whole dataset
        if self.refit and self.best_params_:
            self.best_estimator_ = self.estimator.set_params(**self.best_params_)
            self.best_estimator_.fit(X, y)

        if self.verbose:
            print(f"\nAll results saved to {self.results_csv}")
            print(f"Best result ({self.scoring[0]}): {self.best_score_:.4f}")
            if self.random_search:
                total_grid = len(all_params)
                print(
                    f"Random search used: {self.n_iter} out of {total_grid} "
                    f"possible combinations ({self.n_iter/total_grid*100:.2f}%)"
                )

        return self

    def _update_best_attributes(self):
        """Set best_params_, best_score_, and best_index_ from result_manager."""
        valid_results = [r for r in self.result_manager.results if 'error' not in r]
        if not valid_results:
            self.best_params_ = {}
            self.best_score_ = 0.0
            self.best_index_ = None
            return

        # Sort by the first metric
        scoring_key = f'mean_test_{self.scoring[0]}'
        best_result = max(valid_results, key=lambda x: x.get(scoring_key, float('-inf')))
        self.best_params_ = best_result['params']
        self.best_score_ = best_result.get(scoring_key, 0.0)

        # Find index in cv_results_['params']
        if self.cv_results_ and 'params' in self.cv_results_:
            params_list = self.cv_results_['params']
            for idx, param_dict in enumerate(params_list):
                if param_dict == self.best_params_:
                    self.best_index_ = idx
                    break
            else:
                self.best_index_ = None
        else:
            self.best_index_ = None

    def predict(self, X):
        """
        Predictions using the best model.

        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            Data for prediction.

        Returns:
        --------
        y_pred : array-like of shape (n_samples,)
            Predicted values.
        """
        check_is_fitted(self, 'best_estimator_')
        return self.best_estimator_.predict(X)

    def predict_proba(self, X):
        """
        Class probabilities (if the best model supports predict_proba).

        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            Data for prediction.

        Returns:
        --------
        y_proba : array-like of shape (n_samples, n_classes)
            Class probabilities.
        """
        check_is_fitted(self, 'best_estimator_')
        return self.best_estimator_.predict_proba(X)

    def score(self, X, y):
        """
        Evaluate the best model on data X, y.

        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            Data for evaluation.
        y : array-like of shape (n_samples,)
            True values.

        Returns:
        --------
        score : float
            Metric value (default uses scoring[0]).
        """
        check_is_fitted(self, 'best_estimator_')
        return self.best_estimator_.score(X, y)

    def get_top_results(self, n: int = 10) -> pd.DataFrame:
        """
        Returns top‑N results.

        Parameters:
        -----------
        n : int
            Number of top results to return.

        Returns:
        --------
        pd.DataFrame: Top‑N results.
        """
        return self.result_manager.get_top_results(n)

    def clear_checkpoint(self):
        """
        Deletes the checkpoint file.
        """
        self.checkpoint_manager.clear()

    def load_results_from_checkpoint(self, n: int = 10) -> pd.DataFrame:
        """
        Loads results from a checkpoint and returns top‑N.
        Useful when fit() was interrupted and CSV was not created.

        Parameters:
        -----------
        n : int
            Number of top results to return

        Returns:
        --------
        pd.DataFrame
            Top‑N results from the checkpoint
        """
        # Load checkpoint directly (bypassing result_manager)
        checkpoint_results = self.checkpoint_manager.load()
        # Create a temporary ResultManager to format results
        temp_manager = ResultManager(scoring=self.scoring)
        temp_manager.add_results(checkpoint_results)
        return temp_manager.get_top_results(n)
    def _load_checkpoint(self):
        """
        Private method for backward compatibility.
        Returns the list of results from the checkpoint.
        """
        return self.checkpoint_manager.load()

    def _save_checkpoint(self, results):
        """
        Private method for backward compatibility.
        Saves results to checkpoint.
        """
        self.checkpoint_manager.save(results)




