# SPDX-FileCopyrightText: 2026 Florent Rougon
# SPDX-License-Identifier: GPL-2.0-or-later
# SPDX-FileComment: Initialization of the 'flightgear.meta.scripts.catalog' package

"""Scripts for handling of aircraft catalogs."""
