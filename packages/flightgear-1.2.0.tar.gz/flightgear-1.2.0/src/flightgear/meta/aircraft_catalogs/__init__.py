# SPDX-FileCopyrightText: 2026 Florent Rougon
# SPDX-License-Identifier: GPL-2.0-or-later

"""Package for aircraft catalog handling."""
