# -*- coding: utf-8 -*-

aircraftTypeTags = [
    "aerobatic",
    "airship",
    "balloon",
    "bizjet",
    "bomber",
    "cargo",
    "carrier",
    "fighter",
    "ga",
    "glider",
    "groundvehicle",
    "helicopter",
    "interceptor",
    "passenger",
    "racer",
    "spaceship",
    "tanker",
    "trainer",
    "transport",
    "ultralight",
    "unpowered",
    "uav",
    "reconnaissance",
    "seacraft",
    "crop-duster",
    "bush-plane",
    "airliner",
]

manufacturerTags = [
    "airbus",
    "antonov",
    "arado",
    "atr",
    "avro",
    "bae",
    "bell",
    "bleriot",
    "boeing",
    "bombardier",
    "caudron",
    "cessna",
    "consolidated",
    "dassault",
    "de-havilland",
    "diamond",
    "dornier",
    "douglas",
    "embraer",
    "eurocopter",
    "fairchild",
    "fairey",
    "focke-wulf",
    "fokker",
    "general-dynamics",
    "gotha",
    "grumman",
    "handley-page",
    "hawker",
    "heinkel",
    "ilyushin",
    "junkers",
    "kawasaki",
    "lockheed",
    "mc-donnell-douglas",
    "messerschmitt",
    "mikoyan-gurevich",
    "mitsubishi",
    "north-american",
    "northrop",
    "pilatus",
    "piper",
    "republic",
    "robin",
    "rockwell",
    "saab",
    "short",
    "sikorsky",
    "sopwith",
    "spad",
    "sukhoi",
    "supermarine",
    "tupolev",
    "vickers",
    "vought",
    "wright",
    "yakovlev"
]

eraTags = [
    "1910s",
    "1920s",
    "1930s",
    "1940s",
    "1950s",
    "1960s",
    "1970s",
    "1980s",
    "1990s",
    "2000s",
    "2010s",
    "2020s",
    "coldwar",
    "early-pioneers",
    "golden-age",
    "gulfwar1",
    "gulfwar2",
    "vietnam",
    "ww1",
    "ww2"
]

featureTags = [
    "aerobatic",
    "airship",
    "amphibious",
    "biplane",
    "canard",
    "castering-wheel",
    "combat",
    "delta",
    "etops",
    "experimental",
    "fictional",
    "fixed-gear",
    "flying-wing",
    "floats",
    "glass-cockpit",
    "low-wing",
    "mid-wing",
    "high-wing",
    "h-tail",
    "hud",
    "ifr",
    "lifting-body",
    "pressurised",
    "prototype",
    "refuel",
    "retractable-gear",
    "seaplane",
    "skis",
    "stol",
    "supersonic",
    "supercharger",
    "turbocharger",
    "t-tail",
    "tail-dragger",
    "tricycle",
    "tail-hook",
    "triplane",
    "twin-boom",
    "v-tail",
    "variable-geometry",
    "vtol",
    "wing-fold"
    "water-drop"
]

propulsionTags = [
    "afterburner",
    "diesel",
    "electric",
    "jet",
    "propeller",
    "piston",
    "radial",
    "rocket",
    "single-engine",
    "supercharged",
    "turboprop",
    "twin-engine",
    "triple-engine",
    "four-engine",
    "variable-pitch",
    "fixed-pitch"
]

simFeatureTags = [
    "dual-controls",
    "rembrandt",
    "tow",
    "wildfire",
    "pushback",
]

tags = (aircraftTypeTags + manufacturerTags + eraTags + simFeatureTags +
        propulsionTags + featureTags)

def isValidTag(maybeTag):
    return maybeTag in tags

skippedTags = [
    "compositor",
    "hdr",
]

replacedTags = {
    "1-engine" :                "single-engine",
    "2-engine" :                "twin-engine",
    "2-engines" :               "twin-engine",
    "two-engine" :              "twin-engine",
    "3-engine" :                "triple-engine",
    "3-engines" :               "triple-engine",
    "4-engine" :                "four-engine",
    "turbocharged" :            "turbocharger",
    "aerial-reconnaissance":    "reconnaissance",
    "cropduster":               "crop-duster",
    "castering":                "castering-wheel",
    "pressurized":              "pressurised",
}

def fixupTag(invalidTag):
    t = invalidTag.lower()

    if t in skippedTags:
        return None
    elif t in tags:             # check for case error, tags are all lowercase
        return t
    elif t in replacedTags:
        return replacedTags[t]
    else:
        return None
