# SPDX-FileCopyrightText: 2025 Florent Rougon
# SPDX-License-Identifier: GPL-2.0-or-later

"""Helpers for use with the standard logging module."""

# This class, minus the docstring, is from the Python documentation
# (Logging Cookbook): https://docs.python.org/3/howto/logging-cookbook.html#using-custom-message-objects
class BraceMessage:
    """Defer log message formatting until __str__() is called.

    Message formatting won't be done if the log message is discarded due
    to the level set on loggers, handlers or due to log filters.
    """

    def __init__(self, fmt, /, *args, **kwargs):
        self.fmt = fmt
        self.args = args
        self.kwargs = kwargs

    def __str__(self):
        return self.fmt.format(*self.args, **self.kwargs)
