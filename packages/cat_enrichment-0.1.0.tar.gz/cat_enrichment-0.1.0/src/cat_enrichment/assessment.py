"""Home enrichment assessment tool for indoor cats.

Evaluates a home environment for indoor cat enrichment adequacy
based on research-backed criteria and provides a scored assessment
with actionable recommendations.
"""


class HomeAssessment:
    """Result of a home enrichment assessment.

    Attributes:
        score: Numeric score from 0 to 100.
        grade: Letter grade (A through F).
        level: Descriptive level name in English and Korean.
        recommendations: List of improvement recommendations.
        breakdown: Dict of category scores.
        cats: Number of cats in the household.
    """

    def __init__(self, score, grade, level, recommendations, breakdown, cats):
        self.score = score
        self.grade = grade
        self.level = level
        self.recommendations = recommendations
        self.breakdown = breakdown
        self.cats = cats

    def __repr__(self):
        return (
            f"HomeAssessment(score={self.score}, grade='{self.grade}', "
            f"level='{self.level}', recommendations={len(self.recommendations)})"
        )

    def __str__(self):
        lines = [
            f"Cat Home Enrichment Assessment (고양이 가정 풍부화 평가)",
            f"{'=' * 52}",
            f"Overall Score: {self.score}/100 (Grade: {self.grade})",
            f"Level: {self.level}",
            f"Cats in household: {self.cats}",
            f"",
            f"Category Breakdown:",
        ]
        for category, info in self.breakdown.items():
            bar = "#" * int(info["score"] / 5) + "." * (20 - int(info["score"] / 5))
            lines.append(f"  {category:22s} [{bar}] {info['score']:3d}/100")

        if self.recommendations:
            lines.append("")
            lines.append("Recommendations:")
            for i, rec in enumerate(self.recommendations, 1):
                lines.append(f"  {i}. {rec}")

        return "\n".join(lines)

    def to_dict(self):
        """Convert assessment to a dictionary."""
        return {
            "score": self.score,
            "grade": self.grade,
            "level": self.level,
            "cats": self.cats,
            "recommendations": self.recommendations,
            "breakdown": self.breakdown,
        }


def assess_home(
    vertical_spaces=0,
    scratchers=0,
    hiding_spots=0,
    play_minutes=0,
    window_access=False,
    cats=1,
    puzzle_feeders=0,
    litter_boxes=0,
    water_sources=0,
    toys=0,
    training_sessions=0,
    outdoor_access=False,
):
    """Assess your home's enrichment level for indoor cats.

    Evaluates the home environment based on research-backed criteria
    and returns a comprehensive assessment with scores and recommendations.

    Args:
        vertical_spaces: Number of cat trees, shelves, or elevated perches.
        scratchers: Number of scratching posts/surfaces.
        hiding_spots: Number of hiding spots (boxes, covered beds, etc.).
        play_minutes: Daily interactive play time in minutes.
        window_access: Whether cats have comfortable window viewing access.
        cats: Number of cats in the household.
        puzzle_feeders: Number of puzzle feeders or foraging stations.
        litter_boxes: Number of litter boxes (0 = not specified).
        water_sources: Number of water sources (bowls, fountains).
        toys: Number of available toys.
        training_sessions: Weekly training/trick sessions.
        outdoor_access: Whether cats have safe outdoor access (catio, etc.).

    Returns:
        HomeAssessment: Comprehensive assessment result.

    Example:
        >>> result = assess_home(
        ...     vertical_spaces=2, scratchers=3, hiding_spots=2,
        ...     play_minutes=20, window_access=True, cats=1,
        ...     puzzle_feeders=1, toys=10
        ... )
        >>> print(result.grade)
        'A'
    """
    if cats < 1:
        cats = 1

    recommendations = []
    breakdown = {}

    # --- Physical Environment (25 points) ---
    physical_score = 0

    # Vertical spaces: ideal is 1+ per cat
    vert_ratio = vertical_spaces / cats
    if vert_ratio >= 1.0:
        physical_score += 30
    elif vert_ratio >= 0.5:
        physical_score += 20
    elif vertical_spaces > 0:
        physical_score += 10
    else:
        recommendations.append(
            "Add vertical spaces (cat trees, wall shelves) - at least 1 per cat. "
            "캣타워나 벽선반을 고양이 수만큼 설치하세요."
        )

    # Scratchers: ideal is 2+ per cat
    scratch_ratio = scratchers / cats
    if scratch_ratio >= 2.0:
        physical_score += 25
    elif scratch_ratio >= 1.0:
        physical_score += 18
    elif scratchers > 0:
        physical_score += 10
    else:
        recommendations.append(
            "Add scratching posts (both vertical and horizontal). "
            "스크래치 포스트를 추가하세요 (수직, 수평 모두)."
        )

    # Hiding spots: ideal is cats + 1
    if hiding_spots >= cats + 1:
        physical_score += 25
    elif hiding_spots >= cats:
        physical_score += 18
    elif hiding_spots > 0:
        physical_score += 10
    else:
        recommendations.append(
            "Add hiding spots (boxes, covered beds, tunnels). "
            "숨을 수 있는 공간(상자, 덮인 침대, 터널)을 추가하세요."
        )

    # Window access
    if window_access:
        physical_score += 15
    else:
        recommendations.append(
            "Provide window perch access for outdoor viewing. "
            "외부를 볼 수 있는 창문 선반을 제공하세요."
        )

    # Outdoor access bonus
    if outdoor_access:
        physical_score += 5

    physical_score = min(100, physical_score)
    breakdown["Physical Environment"] = {
        "score": physical_score,
        "weight": 0.25,
    }

    # --- Play & Exercise (25 points) ---
    play_score = 0

    # Play minutes: ideal is 30+ minutes/day
    if play_minutes >= 30:
        play_score += 50
    elif play_minutes >= 20:
        play_score += 40
    elif play_minutes >= 15:
        play_score += 30
    elif play_minutes >= 10:
        play_score += 20
    elif play_minutes > 0:
        play_score += 10
    else:
        recommendations.append(
            "Start daily interactive play sessions - minimum 15-20 minutes/day. "
            "매일 최소 15-20분의 인터랙티브 놀이 시간을 시작하세요."
        )

    # Toys
    if toys >= 10:
        play_score += 30
    elif toys >= 5:
        play_score += 20
    elif toys > 0:
        play_score += 10
    else:
        recommendations.append(
            "Get a variety of toys (wand, balls, kickers) - rotate them weekly. "
            "다양한 장난감(낚싯대, 공, 킥커)을 구비하고 매주 로테이션하세요."
        )

    # Training sessions
    if training_sessions >= 3:
        play_score += 20
    elif training_sessions >= 1:
        play_score += 10

    play_score = min(100, play_score)
    breakdown["Play & Exercise"] = {
        "score": play_score,
        "weight": 0.25,
    }

    # --- Feeding Enrichment (25 points) ---
    feeding_score = 0

    # Puzzle feeders
    if puzzle_feeders >= 2:
        feeding_score += 40
    elif puzzle_feeders >= 1:
        feeding_score += 25
    else:
        recommendations.append(
            "Add puzzle feeders to make mealtimes more stimulating. "
            "퍼즐 급식기를 추가하여 식사 시간을 더 자극적으로 만드세요."
        )

    # Litter boxes: n+1 rule
    ideal_litter = cats + 1
    if litter_boxes == 0:
        # Not specified — give partial credit
        feeding_score += 15
    elif litter_boxes >= ideal_litter:
        feeding_score += 30
    elif litter_boxes >= cats:
        feeding_score += 20
    else:
        recommendations.append(
            f"Add more litter boxes - ideal is {ideal_litter} for {cats} cat(s) (n+1 rule). "
            f"화장실을 추가하세요 - {cats}마리 고양이에게 이상적인 수는 {ideal_litter}개입니다 (n+1 규칙)."
        )
        feeding_score += 10

    # Water sources
    if water_sources >= 2:
        feeding_score += 30
    elif water_sources >= 1:
        feeding_score += 20
    else:
        # Not specified — give partial credit
        feeding_score += 15

    feeding_score = min(100, feeding_score)
    breakdown["Feeding & Resources"] = {
        "score": feeding_score,
        "weight": 0.25,
    }

    # --- Social & Cognitive (25 points) ---
    social_score = 0

    # Play already counted, but interactive play is social too
    if play_minutes >= 15:
        social_score += 35
    elif play_minutes >= 5:
        social_score += 20
    elif play_minutes > 0:
        social_score += 10

    # Training is cognitive
    if training_sessions >= 3:
        social_score += 30
    elif training_sessions >= 1:
        social_score += 20
    else:
        recommendations.append(
            "Try clicker training for cognitive stimulation (even 5 min/day helps). "
            "인지 자극을 위해 클리커 트레이닝을 시도하세요 (하루 5분도 도움됩니다)."
        )

    # Novel objects / variety (approximated by toy count)
    if toys >= 10:
        social_score += 25
    elif toys >= 5:
        social_score += 15
    elif toys > 0:
        social_score += 8

    # Multi-cat bonus/consideration
    if cats > 1:
        social_score += 10

    social_score = min(100, social_score)
    breakdown["Social & Cognitive"] = {
        "score": social_score,
        "weight": 0.25,
    }

    # --- Calculate Overall Score ---
    total_score = 0
    for category_info in breakdown.values():
        total_score += category_info["score"] * category_info["weight"]

    total_score = round(min(100, total_score))

    # Grade assignment
    if total_score >= 90:
        grade = "A"
        level = "Excellent / 우수"
    elif total_score >= 80:
        grade = "B+"
        level = "Very Good / 매우 좋음"
    elif total_score >= 70:
        grade = "B"
        level = "Good / 좋음"
    elif total_score >= 60:
        grade = "C+"
        level = "Above Average / 보통 이상"
    elif total_score >= 50:
        grade = "C"
        level = "Average / 보통"
    elif total_score >= 40:
        grade = "D"
        level = "Below Average / 보통 이하"
    elif total_score >= 30:
        grade = "D-"
        level = "Needs Improvement / 개선 필요"
    else:
        grade = "F"
        level = "Critical / 심각한 개선 필요"

    # Ensure we always have at least one recommendation
    if not recommendations:
        recommendations.append(
            "Excellent setup! Consider rotating toys weekly and trying new enrichment methods. "
            "훌륭한 환경입니다! 장난감을 매주 로테이션하고 새로운 풍부화 방법을 시도해보세요."
        )

    return HomeAssessment(
        score=total_score,
        grade=grade,
        level=level,
        recommendations=recommendations,
        breakdown=breakdown,
        cats=cats,
    )
