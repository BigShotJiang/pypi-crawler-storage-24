"""Personalized enrichment recommendation engine.

Generates targeted enrichment recommendations based on home
assessment results, cat count, and specific needs.
"""

from .data import enrichment_methods, CATEGORIES
from .assessment import assess_home, HomeAssessment


def get_recommendations(
    assessment=None,
    budget="any",
    priority=None,
    max_recommendations=5,
    lang="en",
    **assess_kwargs,
):
    """Get personalized enrichment recommendations.

    Can accept either an existing HomeAssessment or keyword arguments
    to create one automatically.

    Args:
        assessment: An existing HomeAssessment object (optional).
            If not provided, keyword arguments are passed to assess_home().
        budget: Filter by cost - 'low', 'medium', 'high', or 'any'.
        priority: Focus on a specific category - 'physical', 'sensory',
            'social', 'feeding', 'cognitive', 'play', or None for auto-detect.
        max_recommendations: Maximum number of recommendations to return.
        lang: Language for descriptions - 'en' or 'ko'.
        **assess_kwargs: Arguments passed to assess_home() if no
            assessment is provided.

    Returns:
        list[dict]: List of recommendation dicts with keys:
            - method_key: Key in enrichment_methods
            - name: Method name
            - reason: Why this is recommended
            - priority: Priority level ('high', 'medium', 'low')
            - effectiveness: Effectiveness score
            - cost: Cost level
            - tips: Implementation tips

    Example:
        >>> recs = get_recommendations(
        ...     vertical_spaces=0, scratchers=1, play_minutes=5,
        ...     budget="low", max_recommendations=3
        ... )
        >>> for r in recs:
        ...     print(f"{r['name']}: {r['reason']}")
    """
    # Create assessment if not provided
    if assessment is None:
        if assess_kwargs:
            assessment = assess_home(**assess_kwargs)
        else:
            assessment = assess_home()

    recommendations = []

    # Determine weak categories from breakdown
    weak_categories = []
    for cat_name, info in assessment.breakdown.items():
        if info["score"] < 50:
            weak_categories.append((cat_name, info["score"]))
    weak_categories.sort(key=lambda x: x[1])

    # Map assessment category names to data categories
    category_mapping = {
        "Physical Environment": ["physical"],
        "Play & Exercise": ["play", "social"],
        "Feeding & Resources": ["feeding"],
        "Social & Cognitive": ["cognitive", "social", "sensory"],
    }

    # Determine priority categories
    if priority:
        target_categories = [priority]
    elif weak_categories:
        target_categories = []
        for cat_name, _ in weak_categories:
            target_categories.extend(category_mapping.get(cat_name, []))
    else:
        # All categories are good; suggest variety
        target_categories = list(CATEGORIES.keys())

    # Filter and score methods
    scored_methods = []
    for key, method in enrichment_methods.items():
        # Budget filter
        if budget != "any" and method.get("cost", "low") != budget:
            if budget == "low" and method.get("cost") in ("medium", "high"):
                continue
            elif budget == "medium" and method.get("cost") == "high":
                continue

        # Score based on category relevance and effectiveness
        score = method["effectiveness"]
        if method["category"] in target_categories:
            score += 0.3  # Boost relevant categories

        # Boost strongly-evidenced methods
        if method.get("evidence_level") == "strong":
            score += 0.1
        elif method.get("evidence_level") == "moderate":
            score += 0.05

        scored_methods.append((key, method, score))

    # Sort by score descending
    scored_methods.sort(key=lambda x: x[2], reverse=True)

    # Build recommendation list
    for key, method, score in scored_methods[:max_recommendations]:
        name = method.get("name_ko", method["name"]) if lang == "ko" else method["name"]
        desc = method.get("description_ko", method["description"]) if lang == "ko" else method["description"]

        # Determine priority level
        if method["category"] in target_categories and score > 1.0:
            rec_priority = "high"
        elif method["category"] in target_categories:
            rec_priority = "medium"
        else:
            rec_priority = "low"

        # Generate reason
        if method["category"] in target_categories and weak_categories:
            if lang == "ko":
                reason = f"평가에서 개선이 필요한 영역을 보완합니다. {desc}"
            else:
                reason = f"Addresses a weak area identified in your assessment. {desc}"
        else:
            if lang == "ko":
                reason = f"높은 효과성({method['effectiveness']:.0%})의 풍부화 방법입니다. {desc}"
            else:
                reason = f"High-effectiveness ({method['effectiveness']:.0%}) enrichment method. {desc}"

        recommendations.append(
            {
                "method_key": key,
                "name": name,
                "category": CATEGORIES.get(method["category"], method["category"]),
                "reason": reason,
                "priority": rec_priority,
                "effectiveness": method["effectiveness"],
                "cost": method.get("cost", "unknown"),
                "tips": method.get("implementation_tips", []),
            }
        )

    return recommendations


def quick_wins(cats=1, budget="low", lang="en"):
    """Get quick, low-cost enrichment wins.

    Returns the easiest and most impactful enrichment methods
    that can be implemented immediately with minimal cost.

    Args:
        cats: Number of cats in the household.
        budget: Maximum budget level - 'low' or 'medium'.
        lang: Language - 'en' or 'ko'.

    Returns:
        list[dict]: List of quick-win recommendations.
    """
    quick_methods = []
    for key, method in enrichment_methods.items():
        if (
            method.get("cost", "low") in ("low",)
            and method.get("maintenance", "low") in ("low",)
            and method["effectiveness"] >= 0.70
        ):
            name = method.get("name_ko", method["name"]) if lang == "ko" else method["name"]
            desc = method.get("description_ko", method["description"]) if lang == "ko" else method["description"]
            quick_methods.append(
                {
                    "method_key": key,
                    "name": name,
                    "description": desc,
                    "effectiveness": method["effectiveness"],
                    "tips": method.get("implementation_tips", [])[:2],
                }
            )

    quick_methods.sort(key=lambda x: x["effectiveness"], reverse=True)
    return quick_methods[:5]


def enrichment_plan(cats=1, experience="beginner", lang="en"):
    """Generate a structured enrichment plan.

    Creates a week-by-week enrichment introduction plan
    based on experience level.

    Args:
        cats: Number of cats.
        experience: 'beginner', 'intermediate', or 'advanced'.
        lang: Language - 'en' or 'ko'.

    Returns:
        dict: Structured enrichment plan with weekly goals.
    """
    if experience == "beginner":
        plan = {
            "duration": "4 weeks",
            "level": "Beginner" if lang == "en" else "초급",
            "weeks": {
                "week_1": {
                    "focus": "Basic Physical Environment" if lang == "en" else "기본 물리적 환경",
                    "tasks": [
                        "Set up a scratching post near main resting area",
                        "Create 2 hiding spots using cardboard boxes",
                        "Establish a window viewing station",
                    ] if lang == "en" else [
                        "주요 휴식 공간 근처에 스크래치 포스트 설치",
                        "골판지 상자로 2개의 숨기 공간 만들기",
                        "창문 관찰 스테이션 설정",
                    ],
                },
                "week_2": {
                    "focus": "Interactive Play" if lang == "en" else "인터랙티브 놀이",
                    "tasks": [
                        "Start daily 10-minute wand toy sessions",
                        "Introduce 2-3 different toy types",
                        "Set a consistent play schedule",
                    ] if lang == "en" else [
                        "매일 10분 낚싯대 장난감 놀이 시작",
                        "2-3가지 다른 종류의 장난감 도입",
                        "일관된 놀이 일정 설정",
                    ],
                },
                "week_3": {
                    "focus": "Feeding Enrichment" if lang == "en" else "급식 풍부화",
                    "tasks": [
                        "Introduce a simple puzzle feeder (egg carton)",
                        "Try scatter feeding for one meal",
                        "Add a second water source",
                    ] if lang == "en" else [
                        "간단한 퍼즐 급식기(달걀 상자) 도입",
                        "한 끼에 대해 산란 급식 시도",
                        "두 번째 물 소스 추가",
                    ],
                },
                "week_4": {
                    "focus": "Sensory Enrichment" if lang == "en" else "감각 풍부화",
                    "tasks": [
                        "Try catnip or silver vine",
                        "Set up a bird watching station",
                        "Increase play time to 15-20 minutes",
                    ] if lang == "en" else [
                        "캣닢 또는 개다래 시도",
                        "새 관찰 스테이션 설정",
                        "놀이 시간을 15-20분으로 증가",
                    ],
                },
            },
        }
    elif experience == "intermediate":
        plan = {
            "duration": "4 weeks",
            "level": "Intermediate" if lang == "en" else "중급",
            "weeks": {
                "week_1": {
                    "focus": "Advanced Physical Setup" if lang == "en" else "고급 물리적 설정",
                    "tasks": [
                        "Install wall-mounted shelves for cat highways",
                        "Add vertical variety at different heights",
                        "Create a dedicated 'cat room' or enriched zone",
                    ] if lang == "en" else [
                        "고양이 고속도로를 위한 벽걸이 선반 설치",
                        "다양한 높이의 수직 다양성 추가",
                        "전용 '고양이 방' 또는 풍부화 구역 만들기",
                    ],
                },
                "week_2": {
                    "focus": "Training & Cognitive" if lang == "en" else "훈련 및 인지",
                    "tasks": [
                        "Start clicker training (sit, touch)",
                        "Introduce medium-difficulty puzzle feeders",
                        "Create a simple obstacle course",
                    ] if lang == "en" else [
                        "클리커 트레이닝 시작 (앉아, 터치)",
                        "중간 난이도 퍼즐 급식기 도입",
                        "간단한 장애물 코스 만들기",
                    ],
                },
                "week_3": {
                    "focus": "Sensory Variety" if lang == "en" else "감각 다양성",
                    "tasks": [
                        "Try species-specific music",
                        "Introduce scent enrichment (valerian, honeysuckle)",
                        "Add texture variety to resting areas",
                    ] if lang == "en" else [
                        "종 특이적 음악 시도",
                        "향기 풍부화 도입 (쥐오줌풀, 인동덩굴)",
                        "휴식 공간에 질감 다양성 추가",
                    ],
                },
                "week_4": {
                    "focus": "Routine & Rotation" if lang == "en" else "루틴 및 로테이션",
                    "tasks": [
                        "Establish toy rotation system (3-4 groups)",
                        "Create a weekly enrichment schedule",
                        "Evaluate and adjust based on cat's preferences",
                    ] if lang == "en" else [
                        "장난감 로테이션 시스템 구축 (3-4 그룹)",
                        "주간 풍부화 일정 만들기",
                        "고양이의 선호도에 따라 평가 및 조정",
                    ],
                },
            },
        }
    else:  # advanced
        plan = {
            "duration": "4 weeks",
            "level": "Advanced" if lang == "en" else "고급",
            "weeks": {
                "week_1": {
                    "focus": "Environmental Design" if lang == "en" else "환경 디자인",
                    "tasks": [
                        "Design a full cat highway system",
                        "Consider a catio or outdoor enclosure",
                        "Optimize all resource stations (n+1 rule)",
                    ] if lang == "en" else [
                        "전체 고양이 고속도로 시스템 설계",
                        "캣티오 또는 실외 인클로저 고려",
                        "모든 자원 스테이션 최적화 (n+1 규칙)",
                    ],
                },
                "week_2": {
                    "focus": "Advanced Training" if lang == "en" else "고급 훈련",
                    "tasks": [
                        "Teach complex tricks (high-five, spin, fetch)",
                        "Introduce agility course elements",
                        "Practice cooperative care behaviors",
                    ] if lang == "en" else [
                        "복잡한 트릭 가르치기 (하이파이브, 회전, 가져오기)",
                        "어질리티 코스 요소 도입",
                        "협력적 케어 행동 연습",
                    ],
                },
                "week_3": {
                    "focus": "Multi-Sensory Programs" if lang == "en" else "다중 감각 프로그램",
                    "tasks": [
                        "Create multi-modal enrichment sessions",
                        "Combine feeding puzzles with scent trails",
                        "Design rotating enrichment calendar",
                    ] if lang == "en" else [
                        "다중 모드 풍부화 세션 만들기",
                        "퍼즐 급식과 향기 트레일 결합",
                        "로테이션 풍부화 캘린더 설계",
                    ],
                },
                "week_4": {
                    "focus": "Assessment & Innovation" if lang == "en" else "평가 및 혁신",
                    "tasks": [
                        "Conduct full home enrichment audit",
                        "Research and try novel enrichment methods",
                        "Document what works best for your cat",
                    ] if lang == "en" else [
                        "전체 가정 풍부화 감사 실시",
                        "새로운 풍부화 방법 연구 및 시도",
                        "고양이에게 가장 잘 맞는 것 기록",
                    ],
                },
            },
        }

    return plan
