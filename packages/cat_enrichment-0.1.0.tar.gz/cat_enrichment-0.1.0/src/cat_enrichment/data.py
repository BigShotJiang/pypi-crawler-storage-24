"""Enrichment methods database for indoor cats.

Contains 30+ research-backed enrichment methods organized by category,
with effectiveness ratings, evidence levels, and implementation tips.
Each method includes bilingual names (English/Korean).
"""

CATEGORIES = {
    "physical": "Physical Environment (물리적 환경)",
    "sensory": "Sensory Stimulation (감각 자극)",
    "social": "Social Interaction (사회적 상호작용)",
    "feeding": "Feeding Enrichment (급식 풍부화)",
    "cognitive": "Cognitive Stimulation (인지 자극)",
    "play": "Play & Exercise (놀이 및 운동)",
}

enrichment_methods = {
    # === Physical Environment ===
    "vertical_space": {
        "name": "Vertical Space",
        "name_ko": "수직 공간",
        "category": "physical",
        "effectiveness": 0.92,
        "evidence_level": "strong",
        "description": "Cat trees, shelves, and elevated perches that allow climbing and height access.",
        "description_ko": "캣타워, 선반, 높은 곳의 쉼터 등 고양이가 오르고 높이에 접근할 수 있는 공간.",
        "implementation_tips": [
            "Provide at least one vertical structure per cat",
            "Place near windows for combined environmental viewing",
            "Ensure stability — wobbly structures will be avoided",
            "Vary heights from 0.5m to ceiling height",
        ],
        "cost": "medium",
        "maintenance": "low",
    },
    "hiding_spots": {
        "name": "Hiding Spots",
        "name_ko": "숨기 공간",
        "category": "physical",
        "effectiveness": 0.88,
        "evidence_level": "strong",
        "description": "Enclosed spaces where cats can retreat and feel secure.",
        "description_ko": "고양이가 은신하고 안전감을 느낄 수 있는 밀폐된 공간.",
        "implementation_tips": [
            "Provide boxes, tunnels, or covered beds",
            "Place in quiet areas away from high traffic",
            "One hiding spot per cat plus one extra",
            "Include options at different heights",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "window_perch": {
        "name": "Window Perch",
        "name_ko": "창문 선반",
        "category": "physical",
        "effectiveness": 0.85,
        "evidence_level": "strong",
        "description": "Comfortable perch at window level for outdoor viewing.",
        "description_ko": "외부를 관찰할 수 있는 창문 높이의 편안한 선반.",
        "implementation_tips": [
            "Install at a window with outdoor activity (birds, movement)",
            "Ensure it can support the cat's weight",
            "Add a cushion for comfort during long viewing sessions",
            "Consider a bird feeder outside the window",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "scratching_surfaces": {
        "name": "Scratching Surfaces",
        "name_ko": "스크래치 표면",
        "category": "physical",
        "effectiveness": 0.90,
        "evidence_level": "strong",
        "description": "Appropriate surfaces for scratching behavior — essential for claw maintenance and territory marking.",
        "description_ko": "발톱 관리와 영역 표시에 필수적인 적절한 스크래치 표면.",
        "implementation_tips": [
            "Provide both vertical and horizontal scratchers",
            "Use sisal, cardboard, and carpet varieties",
            "Place near resting areas and room entrances",
            "Replace when worn — cats prefer fresh surfaces",
        ],
        "cost": "low",
        "maintenance": "medium",
    },
    "outdoor_enclosure": {
        "name": "Outdoor Enclosure (Catio)",
        "name_ko": "실외 인클로저 (캣티오)",
        "category": "physical",
        "effectiveness": 0.95,
        "evidence_level": "moderate",
        "description": "Enclosed outdoor space allowing safe access to fresh air, sun, and nature.",
        "description_ko": "신선한 공기, 햇볕, 자연에 안전하게 접근할 수 있는 밀폐된 실외 공간.",
        "implementation_tips": [
            "Ensure escape-proof construction",
            "Include shade and rain shelter",
            "Add climbing structures and perches",
            "Consider seasonal weather protection",
        ],
        "cost": "high",
        "maintenance": "medium",
    },
    "multiple_litter_boxes": {
        "name": "Multiple Litter Boxes",
        "name_ko": "다수 화장실",
        "category": "physical",
        "effectiveness": 0.82,
        "evidence_level": "strong",
        "description": "Adequate litter box provision following the n+1 rule (one per cat plus one extra).",
        "description_ko": "n+1 규칙(고양이 수 + 1)에 따른 적절한 화장실 배치.",
        "implementation_tips": [
            "Follow the n+1 rule: one per cat plus one extra",
            "Place in different locations throughout the home",
            "Avoid placing near food and water stations",
            "Scoop daily, full clean weekly",
        ],
        "cost": "low",
        "maintenance": "high",
    },
    # === Sensory Stimulation ===
    "catnip": {
        "name": "Catnip / Silver Vine",
        "name_ko": "캣닢 / 개다래",
        "category": "sensory",
        "effectiveness": 0.75,
        "evidence_level": "strong",
        "description": "Olfactory stimulation through catnip (Nepeta cataria) or silver vine (Actinidia polygama).",
        "description_ko": "캣닢 또는 개다래를 통한 후각 자극.",
        "implementation_tips": [
            "About 60-70% of cats respond to catnip",
            "Silver vine affects ~80% of cats including non-catnip responders",
            "Rotate usage to prevent habituation — 1-2 times per week",
            "Use fresh or high-quality dried products",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "bird_watching": {
        "name": "Bird Watching Setup",
        "name_ko": "새 관찰 환경",
        "category": "sensory",
        "effectiveness": 0.87,
        "evidence_level": "moderate",
        "description": "Window bird feeders and wildlife viewing opportunities for visual stimulation.",
        "description_ko": "시각 자극을 위한 창문 새 모이통 및 야생동물 관찰 기회.",
        "implementation_tips": [
            "Install bird feeder within 1-2 meters of a window",
            "Add a comfortable perch at the window",
            "Consider bird-watching TV/videos as a supplement",
            "Ensure the window is secure",
        ],
        "cost": "low",
        "maintenance": "medium",
    },
    "music_therapy": {
        "name": "Species-Specific Music",
        "name_ko": "종 특이적 음악",
        "category": "sensory",
        "effectiveness": 0.68,
        "evidence_level": "moderate",
        "description": "Music composed in frequency ranges and tempos appealing to cats.",
        "description_ko": "고양이에게 매력적인 주파수 범위와 템포로 작곡된 음악.",
        "implementation_tips": [
            "Use cat-specific music (e.g., 'Music for Cats' by David Teie)",
            "Play at low volume",
            "Observe the cat's reaction — stop if signs of stress",
            "Best used during alone time or stressful events",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "scent_enrichment": {
        "name": "Scent Enrichment",
        "name_ko": "향기 풍부화",
        "category": "sensory",
        "effectiveness": 0.72,
        "evidence_level": "moderate",
        "description": "Safe herbal scents and pheromone diffusers for olfactory stimulation.",
        "description_ko": "후각 자극을 위한 안전한 허브 향기 및 페로몬 디퓨저.",
        "implementation_tips": [
            "Try valerian root, honeysuckle, or olive leaves",
            "Avoid essential oils — many are toxic to cats",
            "Synthetic pheromone diffusers (Feliway) reduce stress",
            "Rotate scents to maintain novelty",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "texture_variety": {
        "name": "Texture Variety",
        "name_ko": "질감 다양성",
        "category": "sensory",
        "effectiveness": 0.65,
        "evidence_level": "low",
        "description": "Different surface textures for tactile stimulation and exploration.",
        "description_ko": "촉각 자극과 탐색을 위한 다양한 표면 질감.",
        "implementation_tips": [
            "Provide surfaces like fleece, sisal, corrugated cardboard, wood",
            "Rotate textures periodically",
            "Include crinkly materials in play areas",
            "Grass patches or wheat grass for tactile interest",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    # === Social Interaction ===
    "interactive_play": {
        "name": "Interactive Play Sessions",
        "name_ko": "인터랙티브 놀이 시간",
        "category": "social",
        "effectiveness": 0.95,
        "evidence_level": "strong",
        "description": "Dedicated play sessions with wand toys, laser pointers, or other interactive toys.",
        "description_ko": "낚싯대 장난감, 레이저 포인터 또는 기타 인터랙티브 장난감으로 하는 전용 놀이 시간.",
        "implementation_tips": [
            "Minimum 15-20 minutes twice daily",
            "Mimic prey movement — erratic, away from the cat",
            "End with a 'catch' to prevent frustration",
            "Vary toy types to maintain interest",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "clicker_training": {
        "name": "Clicker Training",
        "name_ko": "클리커 트레이닝",
        "category": "social",
        "effectiveness": 0.80,
        "evidence_level": "moderate",
        "description": "Positive reinforcement training for tricks and commands.",
        "description_ko": "트릭과 명령을 위한 긍정적 강화 훈련.",
        "implementation_tips": [
            "Keep sessions short — 3-5 minutes",
            "Use high-value treats as rewards",
            "Start with simple behaviors (sit, touch)",
            "Train before meal times when motivation is highest",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "gentle_handling": {
        "name": "Gentle Handling & Grooming",
        "name_ko": "부드러운 핸들링 및 그루밍",
        "category": "social",
        "effectiveness": 0.78,
        "evidence_level": "moderate",
        "description": "Regular gentle petting, brushing, and positive physical contact.",
        "description_ko": "정기적인 부드러운 쓰다듬기, 브러싱 및 긍정적 신체 접촉.",
        "implementation_tips": [
            "Follow the cat's cues — stop when they signal enough",
            "Focus on preferred areas (cheeks, chin, forehead)",
            "Avoid belly and tail base unless cat enjoys it",
            "Combine with slow blinks for bonding",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "companion_cat": {
        "name": "Feline Companion",
        "name_ko": "고양이 동반자",
        "category": "social",
        "effectiveness": 0.70,
        "evidence_level": "moderate",
        "description": "A compatible companion cat for social interaction and play.",
        "description_ko": "사회적 상호작용과 놀이를 위한 호환 가능한 동반 고양이.",
        "implementation_tips": [
            "Not all cats benefit — assess individual personality first",
            "Proper slow introduction is critical (2-4 weeks)",
            "Similar energy levels and temperaments work best",
            "Ensure adequate resources (litter boxes, food stations) for both",
        ],
        "cost": "high",
        "maintenance": "high",
    },
    # === Feeding Enrichment ===
    "puzzle_feeders": {
        "name": "Puzzle Feeders",
        "name_ko": "퍼즐 급식기",
        "category": "feeding",
        "effectiveness": 0.91,
        "evidence_level": "strong",
        "description": "Food-dispensing toys that require problem-solving to access food.",
        "description_ko": "먹이에 접근하기 위해 문제 해결이 필요한 급식 장난감.",
        "implementation_tips": [
            "Start with easy puzzles and increase difficulty gradually",
            "Use portion of daily food allowance in puzzles",
            "Rotate different puzzle types weekly",
            "DIY options: egg cartons, muffin tins, toilet paper rolls",
        ],
        "cost": "medium",
        "maintenance": "medium",
    },
    "foraging_stations": {
        "name": "Foraging Stations",
        "name_ko": "채집 스테이션",
        "category": "feeding",
        "effectiveness": 0.88,
        "evidence_level": "strong",
        "description": "Multiple feeding locations that encourage natural foraging behavior.",
        "description_ko": "자연스러운 채집 행동을 장려하는 다수의 급식 장소.",
        "implementation_tips": [
            "Scatter kibble in multiple locations around the home",
            "Hide food in different spots each day",
            "Use elevated and floor-level locations",
            "Start with obvious placements, then make harder to find",
        ],
        "cost": "low",
        "maintenance": "medium",
    },
    "lick_mats": {
        "name": "Lick Mats",
        "name_ko": "릭 매트",
        "category": "feeding",
        "effectiveness": 0.76,
        "evidence_level": "moderate",
        "description": "Textured mats for spreading wet food, promoting slow eating and mental stimulation.",
        "description_ko": "습식 사료를 펴 바르는 질감 매트로 느린 식사와 정신 자극을 촉진.",
        "implementation_tips": [
            "Spread wet food or paste thinly across the mat",
            "Freeze for longer-lasting enrichment",
            "Clean thoroughly after each use",
            "Great for reducing meal-time anxiety",
        ],
        "cost": "low",
        "maintenance": "medium",
    },
    "timed_feeders": {
        "name": "Timed / Automatic Feeders",
        "name_ko": "타이머 / 자동 급식기",
        "category": "feeding",
        "effectiveness": 0.70,
        "evidence_level": "moderate",
        "description": "Automatic feeders that dispense meals at set intervals.",
        "description_ko": "정해진 간격으로 식사를 제공하는 자동 급식기.",
        "implementation_tips": [
            "Set 4-5 small meals throughout the day to mimic natural pattern",
            "Combine with puzzle elements if possible",
            "Useful for overweight cats on portion control",
            "Include at least one interactive feeding session daily",
        ],
        "cost": "medium",
        "maintenance": "medium",
    },
    "food_variety": {
        "name": "Food Variety / Rotation",
        "name_ko": "사료 다양성 / 로테이션",
        "category": "feeding",
        "effectiveness": 0.65,
        "evidence_level": "low",
        "description": "Rotating different flavors and textures of food.",
        "description_ko": "다양한 맛과 질감의 사료를 로테이션.",
        "implementation_tips": [
            "Introduce new foods gradually over 7-10 days",
            "Rotate between 3-4 different protein sources",
            "Mix wet and dry food for texture variety",
            "Monitor for digestive issues during transitions",
        ],
        "cost": "medium",
        "maintenance": "low",
    },
    # === Cognitive Stimulation ===
    "novel_objects": {
        "name": "Novel Object Introduction",
        "name_ko": "새로운 물체 도입",
        "category": "cognitive",
        "effectiveness": 0.78,
        "evidence_level": "moderate",
        "description": "Regular introduction of new objects for investigation and exploration.",
        "description_ko": "조사와 탐색을 위한 정기적인 새 물체 도입.",
        "implementation_tips": [
            "Introduce one new item every few days",
            "Cardboard boxes, paper bags, and crinkle toys are free/cheap",
            "Rotate objects — remove after a week, reintroduce later",
            "Let the cat approach at their own pace",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "cat_tv": {
        "name": "Cat TV / Video Enrichment",
        "name_ko": "고양이 TV / 영상 풍부화",
        "category": "cognitive",
        "effectiveness": 0.62,
        "evidence_level": "low",
        "description": "Videos of birds, fish, or small animals for visual entertainment.",
        "description_ko": "시각적 즐거움을 위한 새, 물고기 또는 작은 동물 영상.",
        "implementation_tips": [
            "Use a tablet or TV at cat eye level",
            "Monitor for frustration (excessive pawing at screen)",
            "Best as supplement to real environmental enrichment",
            "Some cats respond more than others",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "trick_training": {
        "name": "Trick Training",
        "name_ko": "트릭 훈련",
        "category": "cognitive",
        "effectiveness": 0.82,
        "evidence_level": "moderate",
        "description": "Teaching cats tricks and tasks to provide cognitive challenges.",
        "description_ko": "인지적 도전을 제공하기 위해 고양이에게 트릭과 과제를 가르침.",
        "implementation_tips": [
            "Start with targeting (nose to hand/stick)",
            "Progress to sit, high-five, spin, come when called",
            "Use positive reinforcement only — never punishment",
            "3-5 minute sessions, 2-3 times per day",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "obstacle_course": {
        "name": "Agility / Obstacle Course",
        "name_ko": "어질리티 / 장애물 코스",
        "category": "cognitive",
        "effectiveness": 0.79,
        "evidence_level": "low",
        "description": "Home obstacle courses combining physical and cognitive challenges.",
        "description_ko": "신체적, 인지적 도전을 결합한 가정용 장애물 코스.",
        "implementation_tips": [
            "Use household items: chairs, boxes, tunnels",
            "Guide with treats or a wand toy",
            "Start simple and add complexity over time",
            "Keep it fun — cats should choose to participate",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    # === Play & Exercise ===
    "wand_toys": {
        "name": "Wand / Fishing Rod Toys",
        "name_ko": "낚싯대 장난감",
        "category": "play",
        "effectiveness": 0.93,
        "evidence_level": "strong",
        "description": "Interactive wand toys that simulate prey movement for predatory play.",
        "description_ko": "포식 놀이를 위해 먹잇감 움직임을 시뮬레이션하는 인터랙티브 낚싯대 장난감.",
        "implementation_tips": [
            "Move away from the cat, not toward them",
            "Use erratic, unpredictable movements",
            "Allow the 'catch' at the end of play",
            "Store safely away when not in use (string danger)",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "ball_toys": {
        "name": "Ball & Rolling Toys",
        "name_ko": "공 및 굴리는 장난감",
        "category": "play",
        "effectiveness": 0.74,
        "evidence_level": "moderate",
        "description": "Balls, rolling toys, and track toys for solo and interactive play.",
        "description_ko": "혼자 및 인터랙티브 놀이를 위한 공, 굴리는 장난감 및 트랙 장난감.",
        "implementation_tips": [
            "Ping pong balls are cheap and effective",
            "Crinkle balls add auditory stimulation",
            "Track toys provide long-lasting solo play",
            "Rotate toys every few days to maintain novelty",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "laser_pointer": {
        "name": "Laser Pointer Play",
        "name_ko": "레이저 포인터 놀이",
        "category": "play",
        "effectiveness": 0.80,
        "evidence_level": "moderate",
        "description": "Laser dot chasing for aerobic exercise and prey-drive stimulation.",
        "description_ko": "유산소 운동과 포식 본능 자극을 위한 레이저 점 추적.",
        "implementation_tips": [
            "ALWAYS end with a tangible treat or toy 'catch'",
            "Never shine in the cat's eyes",
            "Limit sessions to 5-10 minutes to prevent frustration",
            "Follow up with a physical toy they can catch",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "catnip_toys": {
        "name": "Catnip Kicker Toys",
        "name_ko": "캣닢 킥커 장난감",
        "category": "play",
        "effectiveness": 0.77,
        "evidence_level": "moderate",
        "description": "Large kick toys filled with catnip for bunny-kicking and solo play.",
        "description_ko": "버니킥과 혼자 놀이를 위한 캣닢이 채워진 큰 킥 장난감.",
        "implementation_tips": [
            "Size should match the cat — large enough to bunny kick",
            "Refresh catnip periodically or use refillable toys",
            "Combine with silver vine for broader appeal",
            "Provide 1-2 always-available plus rotated options",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "tunnel_play": {
        "name": "Tunnels & Tubes",
        "name_ko": "터널 및 튜브",
        "category": "play",
        "effectiveness": 0.81,
        "evidence_level": "moderate",
        "description": "Collapsible tunnels and tubes for running, hiding, and ambush play.",
        "description_ko": "달리기, 숨기, 매복 놀이를 위한 접이식 터널 및 튜브.",
        "implementation_tips": [
            "Crinkle tunnels add auditory enrichment",
            "Connect multiple tunnels for longer courses",
            "Roll a ball through to encourage play",
            "Can be collapsed and stored when not in use",
        ],
        "cost": "low",
        "maintenance": "low",
    },
    "automated_toys": {
        "name": "Automated / Electronic Toys",
        "name_ko": "자동 / 전자 장난감",
        "category": "play",
        "effectiveness": 0.71,
        "evidence_level": "low",
        "description": "Battery-operated or electronic toys that move independently.",
        "description_ko": "독립적으로 움직이는 배터리 작동 또는 전자 장난감.",
        "implementation_tips": [
            "Use as supplement, not replacement for interactive play",
            "Supervise initially to ensure safety",
            "Rotate to prevent boredom and habituation",
            "Best for cats who are home alone during the day",
        ],
        "cost": "medium",
        "maintenance": "medium",
    },
    # === Additional Methods ===
    "water_fountain": {
        "name": "Cat Water Fountain",
        "name_ko": "고양이 분수대",
        "category": "sensory",
        "effectiveness": 0.83,
        "evidence_level": "strong",
        "description": "Flowing water fountain to encourage hydration and provide sensory interest.",
        "description_ko": "수분 섭취를 촉진하고 감각적 흥미를 제공하는 흐르는 물 분수대.",
        "implementation_tips": [
            "Many cats prefer running water over still water",
            "Clean and replace filters regularly",
            "Place away from food bowls",
            "Stainless steel or ceramic preferred over plastic",
        ],
        "cost": "medium",
        "maintenance": "medium",
    },
    "cat_grass": {
        "name": "Cat Grass / Wheatgrass",
        "name_ko": "캣 그라스 / 밀싹",
        "category": "sensory",
        "effectiveness": 0.69,
        "evidence_level": "moderate",
        "description": "Safe grasses for chewing, providing fiber and sensory enrichment.",
        "description_ko": "씹기 위한 안전한 풀로 섬유질과 감각 풍부화 제공.",
        "implementation_tips": [
            "Grow wheat grass, oat grass, or barley grass",
            "Replace every 1-2 weeks when yellowing",
            "Ensure no pesticides or fertilizers used",
            "Provides safe alternative to houseplants",
        ],
        "cost": "low",
        "maintenance": "medium",
    },
    "rotation_system": {
        "name": "Toy Rotation System",
        "name_ko": "장난감 로테이션 시스템",
        "category": "cognitive",
        "effectiveness": 0.84,
        "evidence_level": "moderate",
        "description": "Systematic rotation of toys to maintain novelty and prevent habituation.",
        "description_ko": "신선함을 유지하고 습관화를 방지하기 위한 체계적인 장난감 로테이션.",
        "implementation_tips": [
            "Divide toys into 3-4 groups",
            "Rotate groups every 3-5 days",
            "Keep 2-3 favorites always available",
            "Add new toys periodically",
        ],
        "cost": "low",
        "maintenance": "low",
    },
}


def get_methods_by_category(category):
    """Get all enrichment methods in a specific category.

    Args:
        category: One of 'physical', 'sensory', 'social', 'feeding', 'cognitive', 'play'

    Returns:
        dict: Filtered enrichment methods in the given category.
    """
    if category not in CATEGORIES:
        raise ValueError(
            f"Unknown category '{category}'. Valid categories: {list(CATEGORIES.keys())}"
        )
    return {
        k: v for k, v in enrichment_methods.items() if v["category"] == category
    }


def get_top_methods(n=10):
    """Get the top N enrichment methods by effectiveness.

    Args:
        n: Number of top methods to return (default 10).

    Returns:
        list: List of (key, method_dict) tuples sorted by effectiveness.
    """
    sorted_methods = sorted(
        enrichment_methods.items(),
        key=lambda x: x[1]["effectiveness"],
        reverse=True,
    )
    return sorted_methods[:n]


def search_methods(query):
    """Search enrichment methods by keyword.

    Args:
        query: Search string to match against method names and descriptions.

    Returns:
        dict: Matching enrichment methods.
    """
    query_lower = query.lower()
    return {
        k: v
        for k, v in enrichment_methods.items()
        if query_lower in v["name"].lower()
        or query_lower in v.get("name_ko", "").lower()
        or query_lower in v["description"].lower()
        or query_lower in v.get("description_ko", "").lower()
    }
