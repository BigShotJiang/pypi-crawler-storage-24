"""Cat Behavioral Enrichment Library by PlayCat (플레이캣)

Research-backed tools for indoor cat environmental enrichment assessment.
Provides enrichment method databases, home assessment tools, research
statistics, and personalized recommendations.

Homepage: https://playcat.xyz
Dataset: https://huggingface.co/datasets/playcat/playcat-cat-behavior-new-data-set
"""

__version__ = "0.1.0"

from .data import enrichment_methods, CATEGORIES
from .assessment import assess_home, HomeAssessment
from .statistics import research_stats, get_stat
from .recommendations import get_recommendations

__all__ = [
    "__version__",
    "enrichment_methods",
    "CATEGORIES",
    "assess_home",
    "HomeAssessment",
    "research_stats",
    "get_stat",
    "get_recommendations",
]
