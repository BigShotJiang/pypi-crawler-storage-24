import requests
import json
from typing import Dict, List

__version__ = "1.0.0"
__author__ = "Paras Chourasiya (@Aotpy)"
__author_url__ = "https://Aotpy.vercel.app"

class TgUser:
    
    def __init__(self, base_url: str = "https://api-tobi-frag.vercel.app/check"):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def check(self, username: str) -> Dict:
        username = username.lstrip('@')
        
        try:
            response = self.session.get(
                self.base_url,
                params={"username": username},
                timeout=10
            )
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            return {
                "username": f"@{username}",
                "state": "error",
                "Price_TON": "N/A",
                "₹inr": "N/A",
                "$usd": "N/A",
                "fragment_status": "error",
                "message": f"Error: {str(e)}",
                "developer": "@Aotpy",
                "channel": "@obitoapi / @obitostuffs",
                "error": True
            }
    
    def check_many(self, usernames: List[str], max_workers: int = 5) -> Dict[str, Dict]:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        results = {}
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_username = {
                executor.submit(self.check, username): username 
                for username in usernames
            }
            
            for future in as_completed(future_to_username):
                username = future_to_username[future]
                try:
                    results[username] = future.result()
                except Exception as e:
                    results[username] = {
                        "username": f"@{username}",
                        "state": "error",
                        "message": str(e),
                        "developer": "@Aotpy"
                    }
        
        return results
    
    def to_json(self, username: str) -> str:
        return json.dumps(self.check(username), ensure_ascii=False, indent=2)