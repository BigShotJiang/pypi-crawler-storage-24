#!/usr/bin/env python3
import json
import sys
from typing import List
from telegram_checker import TgUser, __version__, __author__, __author_url__

def main():
    checker = TgUser()
    
    if len(sys.argv) == 1:
        print(f"""
╔══════════════════════════════════════════════════════╗
║  tguser - Telegram Username Checker                  ║
║  Version: {__version__}                                  
║  Author: {__author__}                                   
║  Web: {__author_url__}                                     
╚══════════════════════════════════════════════════════╝

Usage:
  tguser check <username>          Check single username
  tguser batch user1,user2,user3   Check multiple usernames
  tguser file <filename>           Check from file
  tguser -i                        Interactive mode

Examples:
  tguser check john
  tguser batch john,doe,telegram
  tguser file usernames.txt
""")
        return
    
    if sys.argv[1] == 'check' and len(sys.argv) > 2:
        username = sys.argv[2]
        result = checker.check(username)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
        if not result.get('error'):
            if result.get('state') == 'available':
                print(f"\n✅ @{username.lstrip('@')} is AVAILABLE!")
            elif result.get('state') == 'taken':
                print(f"\n❌ @{username.lstrip('@')} is TAKEN")
    
    elif sys.argv[1] == 'batch' and len(sys.argv) > 2:
        usernames = [u.strip() for u in sys.argv[2].split(',') if u.strip()]
        results = checker.check_many(usernames)
        print(json.dumps(results, ensure_ascii=False, indent=2))
        
        available = [u for u, d in results.items() if d.get('state') == 'available']
        taken = [u for u, d in results.items() if d.get('state') == 'taken']
        
        print(f"\n📊 Summary: {len(available)} available, {len(taken)} taken")
        if available:
            print(f"✅ Available: {', '.join(available)}")
    
    elif sys.argv[1] == 'file' and len(sys.argv) > 2:
        filename = sys.argv[2]
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                usernames = [line.strip() for line in f if line.strip()]
            results = checker.check_many(usernames)
            print(json.dumps(results, ensure_ascii=False, indent=2))
        except FileNotFoundError:
            print(f"❌ File '{filename}' not found")
        except Exception as e:
            print(f"❌ Error: {e}")
    
    elif sys.argv[1] == '-i':
        interactive_mode(checker)
    
    else:
        print("❌ Invalid command. Use: tguser check <username>")

def interactive_mode(checker):
    print(f"""
╔══════════════════════════════════════════════════════╗
║  tguser - Interactive Mode                           ║
║  Author: @Aotpy | https://Aotpy.vercel.app           ║
╚══════════════════════════════════════════════════════╝
Commands: username | batch: u1,u2,u3 | file: file.txt | exit
""")
    
    while True:
        try:
            cmd = input("\n🔍 > ").strip()
            
            if cmd.lower() == 'exit':
                print("👋 Goodbye!")
                break
            
            elif cmd.lower().startswith('batch:'):
                usernames = [u.strip() for u in cmd[6:].split(',') if u.strip()]
                if usernames:
                    results = checker.check_many(usernames)
                    print(json.dumps(results, ensure_ascii=False, indent=2))
                    
                    available = [u for u, d in results.items() if d.get('state') == 'available']
                    if available:
                        print(f"\n✅ Available: {', '.join(available)}")
            
            elif cmd.lower().startswith('file:'):
                filename = cmd[5:].strip()
                try:
                    with open(filename, 'r') as f:
                        usernames = [line.strip() for line in f if line.strip()]
                    results = checker.check_many(usernames)
                    print(json.dumps(results, ensure_ascii=False, indent=2))
                except Exception as e:
                    print(f"❌ Error: {e}")
            
            elif cmd:
                result = checker.check(cmd)
                print(json.dumps(result, ensure_ascii=False, indent=2))
                
                if result.get('state') == 'available':
                    print(f"\n✅ @{cmd.lstrip('@')} is AVAILABLE!")
                elif result.get('state') == 'taken':
                    price = result.get('Price_TON', '')
                    print(f"\n❌ @{cmd.lstrip('@')} is TAKEN{f' - {price} TON' if price and price != 'Unknown' else ''}")
        
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()