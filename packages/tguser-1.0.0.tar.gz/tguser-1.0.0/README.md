# Telegram Username Checker

A Python module to check Telegram username availability using the Tobi Frag API.

## Installation

```bash
pip install -e .