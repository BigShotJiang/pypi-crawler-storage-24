"""
Agentic todo list for tracking task progress.

Provides structured task tracking for complex multi-step operations.
The model manages todos through the entropic.todo_write internal tool.
"""

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class TodoStatus(Enum):
    """Status of a todo item."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


@dataclass
class TodoItem:
    """A single todo item."""

    content: str  # Task description (imperative: "Fix bug")
    active_form: str  # Present continuous ("Fixing bug")
    status: TodoStatus = TodoStatus.PENDING
    target_tier: str | None = None  # Which tier should execute (None = self)
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None

    def mark_in_progress(self) -> None:
        """Mark this item as in progress."""
        self.status = TodoStatus.IN_PROGRESS

    def mark_completed(self) -> None:
        """Mark this item as completed."""
        self.status = TodoStatus.COMPLETED
        self.completed_at = datetime.utcnow()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "id": self.id,
            "content": self.content,
            "active_form": self.active_form,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }
        if self.target_tier is not None:
            result["target_tier"] = self.target_tier
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TodoItem":
        """Create from dictionary."""
        return cls(
            content=data["content"],
            active_form=data["active_form"],
            status=TodoStatus(data["status"]),
            target_tier=data.get("target_tier"),
            id=data.get("id", str(uuid.uuid4())[:8]),
            created_at=(
                datetime.fromisoformat(data["created_at"])
                if data.get("created_at")
                else datetime.utcnow()
            ),
            completed_at=(
                datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") else None
            ),
        )


@dataclass
class TodoList:
    """Manages a list of todo items for a conversation."""

    conversation_id: str | None = None
    items: list[TodoItem] = field(default_factory=list)

    def add(self, content: str, active_form: str) -> TodoItem:
        """Add a new todo item."""
        item = TodoItem(content=content, active_form=active_form)
        self.items.append(item)
        return item

    def get_current(self) -> TodoItem | None:
        """Get the currently in-progress item."""
        for item in self.items:
            if item.status == TodoStatus.IN_PROGRESS:
                return item
        return None

    def get_pending(self) -> list[TodoItem]:
        """Get all pending items."""
        return [i for i in self.items if i.status == TodoStatus.PENDING]

    def get_completed(self) -> list[TodoItem]:
        """Get all completed items."""
        return [i for i in self.items if i.status == TodoStatus.COMPLETED]

    def get_todos_for_tier(self, tier: str) -> list[TodoItem]:
        """Get todos targeting a specific tier."""
        return [i for i in self.items if i.target_tier == tier]

    @property
    def progress(self) -> tuple[int, int]:
        """Return (completed, total) counts."""
        completed = len(self.get_completed())
        return completed, len(self.items)

    @property
    def is_empty(self) -> bool:
        """Check if todo list is empty."""
        return len(self.items) == 0

    def clear(self) -> None:
        """Clear all items."""
        self.items = []

    def clear_self_todos(self) -> int:
        """Remove all self-directed todos (target_tier is None).

        Returns:
            Number of items removed
        """
        before = len(self.items)
        self.items = [i for i in self.items if i.target_tier is not None]
        return before - len(self.items)

    def format_for_context(self) -> str:
        """Format todo list for injection into conversation context."""
        if self.is_empty:
            return "[CURRENT TODO STATE]\n" "No active todos.\n" "[END TODO STATE]"
        status_icons = {"pending": "[ ]", "in_progress": "[>]", "completed": "[x]"}
        lines = ["[CURRENT TODO STATE]"]

        # Check if items have mixed target tiers
        tiers = {item.target_tier for item in self.items}
        has_mixed_tiers = len(tiers) > 1 or (len(tiers) == 1 and None not in tiers)

        if has_mixed_tiers:
            self._format_grouped(lines, status_icons)
        else:
            self._format_flat(lines, status_icons)

        completed, total = self.progress
        lines.append(f"Progress: {completed}/{total} completed")
        lines.append("[END TODO STATE]")
        return "\n".join(lines)

    def _format_flat(self, lines: list[str], icons: dict[str, str]) -> None:
        """Format items as a flat list with indices."""
        for i, item in enumerate(self.items):
            icon = icons.get(item.status.value, "[ ]")
            lines.append(f"  [{i}] {icon} {item.content}")

    def _format_grouped(self, lines: list[str], icons: dict[str, str]) -> None:
        """Format items grouped by target tier with global indices."""
        # Build index -> item mapping first to preserve global indices
        groups: dict[str, list[tuple[int, TodoItem]]] = {}
        for i, item in enumerate(self.items):
            key = item.target_tier or "self"
            groups.setdefault(key, []).append((i, item))

        # Named tiers first, then self
        for tier_name in sorted(groups, key=lambda t: (t == "self", t)):
            label = "self" if tier_name == "self" else f"{tier_name} tier"
            lines.append(f"  For {label}:")
            for idx, item in groups[tier_name]:
                icon = icons.get(item.status.value, "[ ]")
                lines.append(f"    [{idx}] {icon} {item.content}")

    def handle_tool_call(self, arguments: dict[str, Any]) -> str:
        """
        Handle a todo_write tool call with action-based dispatch.

        Args:
            arguments: Tool call arguments with 'action' and action-specific fields

        Returns:
            Status message
        """
        arguments = self._normalize_arguments(arguments)
        action = arguments.get("action", "replace")
        handlers = {
            "add": self._handle_add,
            "update": self._handle_update,
            "bulk_update": self._handle_bulk_update,
            "remove": self._handle_remove,
            "replace": self._handle_replace,
        }
        handler = handlers.get(action)
        if not handler:
            return (
                f"Error: Unknown action '{action}'. "
                f"Valid actions: add, update, bulk_update, remove, replace. "
                f'Example: entropic.todo_write(action="add", todos=[{{"content": "...", '
                f'"active_form": "...", "status": "pending"}}])'
            )
        return handler(arguments)

    def handle_simple_call(self, arguments: dict[str, Any]) -> str:
        """Handle a simplified todo call (for entropic.todo tool).

        Supports add, update, remove only. No target_tier, no bulk_update,
        no replace, no active_form (computed from content).
        """
        action = arguments.get("action", "")
        handlers = {
            "add": self._simple_add,
            "update": self._simple_update,
            "remove": self._simple_remove,
        }
        handler = handlers.get(action)
        if not handler:
            return (
                f"Error: Unknown action '{action}'. Valid: add, update, remove. "
                'Example: entropic.todo(action="add", content="Write tests", status="pending")'
            )
        return handler(arguments)

    def _simple_add(self, args: dict[str, Any]) -> str:
        """Add a todo item via simplified interface."""
        content = args.get("content", "")
        status = args.get("status", "pending")

        error = self._validate_simple_add(content, status)
        if error:
            return error

        active_form = f"Working on: {content}" if " " in content else content
        self.items.append(
            TodoItem(content=content, active_form=active_form, status=TodoStatus(status))
        )
        return f"Added: {content}. Total: {len(self.items)}"

    def _validate_simple_add(self, content: str, status: str) -> str | None:
        """Validate simple add arguments. Returns error string or None."""
        if not content:
            return (
                "Error: 'add' requires 'content' (task description). "
                'Example: entropic.todo(action="add", content="Write tests", status="pending")'
            )
        valid_statuses = ("pending", "in_progress", "completed")
        if status not in valid_statuses:
            return f"Error: Invalid status '{status}'. Valid: pending, in_progress, completed."
        return (
            "Error: Only one task can be in_progress at a time."
            if status == "in_progress" and self.get_current() is not None
            else None
        )

    def _simple_update(self, args: dict[str, Any]) -> str:
        """Update a todo item by index via simplified interface."""
        index, error = self._resolve_index(args, "update")
        if error:
            return error
        item = self.items[index]
        if "status" in args:
            status_error = self._apply_status(item, args["status"])
            if status_error:
                return status_error
        if "content" in args:
            item.content = args["content"]
            item.active_form = f"Working on: {args['content']}"
        return f"Updated [{index}]: {item.content[:50]}"

    def _simple_remove(self, args: dict[str, Any]) -> str:
        """Remove a todo item by index via simplified interface."""
        index, error = self._resolve_index(args, "remove")
        if error:
            return error
        removed = self.items.pop(index)
        return f"Removed [{index}]: {removed.content[:50]}"

    @staticmethod
    def _normalize_arguments(args: dict[str, Any]) -> dict[str, Any]:
        """Parse stringified JSON values that models sometimes produce."""
        todos = args.get("todos")
        if isinstance(todos, str):
            try:
                parsed = json.loads(todos)
                if isinstance(parsed, list):
                    args = {**args, "todos": parsed}
            except (json.JSONDecodeError, TypeError):
                pass
        return args

    def update_from_tool_call(self, todos: list[dict[str, Any]]) -> str:
        """Legacy wrapper — delegates to handle_tool_call with replace action."""
        return self.handle_tool_call({"action": "replace", "todos": todos})

    def _handle_add(self, args: dict[str, Any]) -> str:
        """Append new items to the todo list."""
        todos = args.get("todos", [])
        if not todos:
            return (
                "Error: 'add' action requires a 'todos' array with at least one item. "
                "Each item needs: content (string), active_form (string), status (pending|in_progress|completed). "
                'Example: entropic.todo_write(action="add", todos=[{"content": "Implement login", '
                '"active_form": "Implementing login", "status": "pending", "target_tier": "eng"}])'
            )

        errors = self._validate_items(todos)
        if errors:
            return (
                "Error: Invalid todo format. Each item requires: content, active_form, status.\n"
                + "\n".join(errors)
                + '\nExample valid item: {"content": "Do X", "active_form": "Doing X", '
                '"status": "pending", "target_tier": "eng"}'
            )

        for t in todos:
            self.items.append(
                TodoItem(
                    content=t["content"],
                    active_form=t["active_form"],
                    status=TodoStatus(t["status"]),
                    target_tier=t.get("target_tier"),
                )
            )

        return f"Added {len(todos)} item(s). Total: {len(self.items)}"

    def _resolve_index(self, args: dict[str, Any], action: str) -> tuple[int, str | None]:
        """Validate and return index from args. Returns (index, error_or_None)."""
        if "index" not in args:
            return -1, (
                f"Error: '{action}' action requires an 'index' field (integer) "
                f"identifying which todo item to {action}. "
                f"Current items: {len(self.items)} (indices 0-{max(0, len(self.items) - 1)}). "
                f'Example: entropic.todo_write(action="{action}", index=0, status="completed")'
            )
        index = args["index"]
        if not 0 <= index < len(self.items):
            return -1, (
                f"Error: Index {index} out of range. "
                f"Valid indices: 0-{max(0, len(self.items) - 1)} ({len(self.items)} items exist). "
                f'Use entropic.todo_write(action="add", ...) to create items first.'
            )
        return index, None

    def _apply_status(self, item: TodoItem, status_str: str) -> str | None:
        """Apply status change to item. Returns error string or None on success."""
        if status_str not in ("pending", "in_progress", "completed"):
            return (
                f"Error: Invalid status '{status_str}'. "
                f"Valid values: 'pending', 'in_progress', 'completed'."
            )
        new_status = TodoStatus(status_str)
        if new_status == TodoStatus.IN_PROGRESS:
            current = self.get_current()
            if current and current is not item:
                return "Error: Only one task can be in_progress at a time"
        item.status = new_status
        if new_status == TodoStatus.COMPLETED:
            item.completed_at = datetime.utcnow()
        return None

    def _handle_update(self, args: dict[str, Any]) -> str:
        """Update a single item by index."""
        index, error = self._resolve_index(args, "update")
        if error:
            return error

        item = self.items[index]

        if "status" in args:
            status_error = self._apply_status(item, args["status"])
            if status_error:
                return status_error

        for attr in ("content", "active_form", "target_tier"):
            if attr in args:
                setattr(item, attr, args[attr])

        return f"Updated item {index}: {item.content[:50]}"

    def _handle_bulk_update(self, args: dict[str, Any]) -> str:
        """Update multiple items by index in a single call."""
        updates = args.get("updates", [])

        # Recover stringified JSON — model sometimes emits "[{...}]" as string
        if isinstance(updates, str):
            try:
                updates = json.loads(updates)
            except (json.JSONDecodeError, ValueError):
                pass

        if not updates or not isinstance(updates, list):
            got_type = type(updates).__name__
            return (
                f"Error: 'bulk_update' requires an 'updates' array of objects, got {got_type}. "
                f"Each object needs at minimum an 'index' field. "
                f'Example: entropic.todo_write(action="bulk_update", updates=['
                f'{{"index": 0, "status": "completed"}}, '
                f'{{"index": 1, "status": "in_progress"}}])'
            )

        results = []
        for entry in updates:
            if not isinstance(entry, dict) or "index" not in entry:
                results.append(
                    f"Error: each update must be an object with 'index' (integer). "
                    f"Got: {type(entry).__name__}. "
                    f'Example: {{"index": 0, "status": "completed"}}'
                )
                continue
            result = self._handle_update(entry)
            results.append(result)

        return " | ".join(results)

    def _handle_remove(self, args: dict[str, Any]) -> str:
        """Remove an item by index."""
        index, error = self._resolve_index(args, "remove")
        if error:
            return error

        removed = self.items.pop(index)
        return f"Removed item {index}: {removed.content[:50]}"

    def _handle_replace(self, args: dict[str, Any]) -> str:
        """Replace the entire todo list (legacy behavior)."""
        todos = args.get("todos", [])
        errors = self._validate_items(todos)
        if errors:
            return (
                "Error: Invalid todo format. Each item requires: content, active_form, status.\n"
                + "\n".join(errors)
                + '\nExample valid item: {"content": "Do X", "active_form": "Doing X", '
                '"status": "pending", "target_tier": "eng"}'
            )

        # Validate: only one in_progress
        in_progress = [t for t in todos if t["status"] == "in_progress"]
        if len(in_progress) > 1:
            return (
                f"Error: Only one task can be in_progress at a time. "
                f"Found {len(in_progress)} items with status 'in_progress'. "
                f"Set all but one to 'pending' or 'completed'."
            )

        self.items = [
            TodoItem(
                content=t["content"],
                active_form=t["active_form"],
                status=TodoStatus(t["status"]),
                target_tier=t.get("target_tier"),
            )
            for t in todos
        ]

        completed, total = self.progress
        return f"Todo list replaced: {completed}/{total} completed"

    def _validate_items(self, todos: list[dict[str, Any]]) -> list[str]:
        """Validate todo item dicts. Returns list of error strings (empty = valid)."""
        if not isinstance(todos, list):
            return [f"'todos' must be an array, got {type(todos).__name__}"]
        errors = []
        for i, t in enumerate(todos):
            if "content" not in t:
                errors.append(f"Item {i}: missing required field 'content'")
            if "active_form" not in t:
                errors.append(f"Item {i}: missing required field 'active_form'")
            if "status" not in t:
                errors.append(f"Item {i}: missing required field 'status'")
            elif t["status"] not in ("pending", "in_progress", "completed"):
                errors.append(
                    f"Item {i}: invalid status '{t['status']}' "
                    f"(must be: pending, in_progress, completed)"
                )
        return errors

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "conversation_id": self.conversation_id,
            "items": [item.to_dict() for item in self.items],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TodoList":
        """Create from dictionary."""
        todo_list = cls(conversation_id=data.get("conversation_id"))
        todo_list.items = [TodoItem.from_dict(item) for item in data.get("items", [])]
        return todo_list
