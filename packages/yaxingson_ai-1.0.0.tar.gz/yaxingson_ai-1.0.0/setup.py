from distutils.core import setup

setup(
    name='yaxingson-ai',
    version='1.0.0',
    author='Yaxing Son',
    author_email='3228891558@qq.com',
    url='https://github.com/yaxingson/ai',
    packages=['ai', 'ai.agent', 'ai.llm']
)
