from .handlers.image import (
    compress_image,
    compress_folder_parallel,
    convert_image,
    compress_to_target_size,
)

from .handlers.pdf import (
    compress_pdf,
    compress_pdf_to_target_size,
)

from .handlers.video import compress_video

__all__ = [
    "compress_image",
    "compress_folder_parallel",
    "convert_image",
    "compress_to_target_size",
    "compress_pdf",
    "compress_pdf_to_target_size",
    "compress_video",
]

__version__ = "1.0.0"