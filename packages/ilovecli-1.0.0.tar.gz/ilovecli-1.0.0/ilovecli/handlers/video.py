import subprocess
from rich.console import Console
from ..utils import print_size_report
import os

console = Console()

def compress_video(input_path: str, crf: int = 28):
    output = "compressed_" + os.path.basename(input_path)
    original_size = os.path.getsize(input_path)

    try:
        subprocess.run([
            "ffmpeg",
            "-i", input_path,
            "-vcodec", "libx265",       # HEVC is superior for compression
            "-crf", str(crf),
            "-preset", "medium",        # fast enough while maintaining quality
            "-threads", "0",            # utilize all CPU cores
            "-tag:v", "hvc1",           # ensures mac/iOS compatibility for HEVC
            "-movflags", "+faststart",  # better for web streaming
            "-y",
            output
        ], check=True, capture_output=True, text=True)

        print_size_report(original_size, os.path.getsize(output), filename=os.path.basename(input_path))

    except subprocess.CalledProcessError as e:
        console.print(f"❌ FFmpeg failed: {e.stderr.strip() if e.stderr else 'Unknown error'}", style="red")