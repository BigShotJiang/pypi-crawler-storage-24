# pdf_tools.py
import subprocess
import os
from rich.console import Console
from ..utils import print_size_report

console = Console()

def compress_pdf(input_path: str, quality: str = "ebook"):
    """
    Compress PDF using Ghostscript with standard PDFSETTINGS.
    quality: screen, ebook, printer, prepress
    """
    output = "compressed_" + os.path.basename(input_path)
    original_size = os.path.getsize(input_path)

    result = subprocess.run([
        "gs",
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        f"-dPDFSETTINGS=/{quality}",
        "-dNOPAUSE",
        "-dQUIET",
        "-dBATCH",
        f"-sOutputFile={output}",
        input_path
    ])

    if result.returncode != 0:
        console.print("❌ Ghostscript failed", style="red")
        return

    new_size = os.path.getsize(output)
    print_size_report(original_size, new_size, filename=os.path.basename(input_path))


def compress_pdf_to_target_size(input_path: str, target_kb: int, quality: str = "screen"):
    """
    Compress PDF to a target size in KB using a combination of:
    1. Ghostscript PDFSETTINGS
    2. Optional DPI downsampling for images
    """
    output = "target_" + os.path.basename(input_path)
    target_bytes = target_kb * 1024
    original_size = os.path.getsize(input_path)

    # If already below target
    if original_size <= target_bytes:
        console.print(f"✅ Already under target size ({target_kb} KB)")
        return input_path

    # Step 1: Apply Ghostscript PDFSETTINGS compression first
    subprocess.run([
        "gs",
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        f"-dPDFSETTINGS=/{quality}",
        "-dNOPAUSE",
        "-dQUIET",
        "-dBATCH",
        f"-sOutputFile={output}",
        input_path
    ], check=True)

    current_size = os.path.getsize(output)
    if current_size <= target_bytes:
        console.print(f"✅ Saved as {output} | Size: {round(current_size/1024,2)} KB")
        return output

    # Step 2: DPI downsampling (for image-heavy PDFs)
    low, high = 50, 300
    best_dpi = None
    
    max_iterations = 5
    iterations = 0

    import tempfile
    
    while low <= high and iterations < max_iterations:
        iterations += 1
        mid = (low + high) // 2
        
        # Use a temporary file to avoid slow disk I/O on the final location
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=True) as tmp_pdf:
            subprocess.run([
                "gs",
                "-sDEVICE=pdfwrite",
                "-dCompatibilityLevel=1.4",
                "-dDownsampleColorImages=true",
                "-dColorImageResolution=" + str(mid),
                "-dDownsampleGrayImages=true",
                "-dGrayImageResolution=" + str(mid),
                "-dDownsampleMonoImages=true",
                "-dMonoImageResolution=" + str(mid),
                "-dNOPAUSE",
                "-dQUIET",
                "-dBATCH",
                "-sOutputFile=" + tmp_pdf.name,
                input_path
            ], check=True)

            new_size = os.path.getsize(tmp_pdf.name)
        
        if target_bytes * 0.95 <= new_size <= target_bytes * 1.05:
            best_dpi = mid
            break
            
        if new_size > target_bytes:
            high = mid - 1
        else:
            best_dpi = mid
            low = mid + 1

    if best_dpi is None:
        console.print(f"❌ Could not reach target size ({target_kb} KB). Final size: {round(new_size/1024,2)} KB", style="red")
        return None

    # Final save using best DPI
    subprocess.run([
        "gs",
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        "-dDownsampleColorImages=true",
        "-dColorImageResolution=" + str(best_dpi),
        "-dDownsampleGrayImages=true",
        "-dGrayImageResolution=" + str(best_dpi),
        "-dDownsampleMonoImages=true",
        "-dMonoImageResolution=" + str(best_dpi),
        "-dNOPAUSE",
        "-dQUIET",
        "-dBATCH",
        "-sOutputFile=" + output,
        input_path
    ], check=True)

    final_size_kb = round(os.path.getsize(output) / 1024, 2)
    console.print(f"✅ Saved as {output}")
    console.print(f"📦 Final Size: {final_size_kb} KB")
    console.print(f"🎯 DPI Used: {best_dpi}")
    return output