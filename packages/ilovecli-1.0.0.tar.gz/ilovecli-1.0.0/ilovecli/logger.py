import logging
import os
from rich.logging import RichHandler

log_dir = os.path.expanduser("~/.ilovecli/logs")
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.WARNING, 
    format="%(message)s",
    handlers=[
        logging.FileHandler(os.path.join(log_dir, "ilovecli.log")),
        RichHandler(rich_tracebacks=True, show_time=False, show_path=False)
    ]
)

logger = logging.getLogger("ilovecli")

def set_log_level(verbose: bool, debug: bool):
    if debug:
        logger.setLevel(logging.DEBUG)
        for handler in logging.root.handlers:
            handler.setLevel(logging.DEBUG)
    elif verbose:
        logger.setLevel(logging.INFO)
        for handler in logging.root.handlers:
            handler.setLevel(logging.INFO)