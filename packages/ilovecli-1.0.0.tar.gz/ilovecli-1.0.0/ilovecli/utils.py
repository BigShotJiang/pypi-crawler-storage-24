from rich.console import Console

console = Console()

def format_size(size_bytes):
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.2f} MB"

def print_size_report(original, new, filename=""):
    reduction = ((original - new) / original) * 100 if original > 0 else 0
    orig_str = format_size(original)
    new_str = format_size(new)
    
    if new > original:
        console.print(f"⚠️  [yellow]{filename}[/yellow]: {orig_str} ➔ {new_str} (Increased {-reduction:.2f}%)")
    else:
        console.print(f"📉 [green]{filename}[/green]: {orig_str} ➔ {new_str} ({reduction:.2f}% reduced)")