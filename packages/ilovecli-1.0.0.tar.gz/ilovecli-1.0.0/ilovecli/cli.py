import typer
from pathlib import Path
from rich.console import Console
from rich.progress import Spinner
from rich.text import Text
import shutil
from rich.panel import Panel
from typing import List
import mimetypes
import requests

from ilovecli import (
    compress_image,
    compress_folder_parallel,
    compress_pdf,
    compress_video,
    convert_image,
    compress_to_target_size,
    compress_pdf_to_target_size,
    __version__,
)
from ilovecli.logger import logger

console = Console()

# 1. Added an epilogue for a polished footer in the main help menu
app = typer.Typer(
    help="🚀 [bold green]ilovecli[/bold green] - The Ultimate Image, PDF & Video Compressor",
    epilog="Made with ❤️  | Use [bold cyan]ilovecli <command> --help[/bold cyan] for detailed usage of a specific command.",
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]},
    rich_markup_mode="rich"
)

SUPPORTED_IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".webp"]
SUPPORTED_VIDEO_EXTS = [".mp4", ".mkv", ".mov"]
SUPPORTED_PDF_EXTS = [".pdf"]

def show_banner():
    banner = r"""
  _   _                 _ _  
 (_) | | _____   _____ | (_) 
 | | | |/ _ \ \ / / _ \| | | 
 | | | | (_) \ V /  __/| | | 
 |_| |_|\___/ \_/ \___||_|_| 
    """
    console.print(Panel(banner, title="🚀 The ultimate media compressor", border_style="cyan", subtitle=f"v{__version__}"))

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    verbose: bool = typer.Option(False, "--verbose", help="Enable verbose output"),
    debug: bool = typer.Option(False, "--debug", help="Enable debug output"),
    version: bool = typer.Option(False, "--version", "-v", help="Show version", is_eager=True),
    author: bool = typer.Option(False, "--author", "-a", help="Show author info", is_eager=True),
    info: bool = typer.Option(False, "--info", "-i", help="Show project info", is_eager=True),
):
    from ilovecli.logger import set_log_level
    set_log_level(verbose, debug)
    if version:
        console.print(f"[bold cyan]ilovecli[/bold cyan] v{__version__}")
        raise typer.Exit()
    if author:
        console.print("👨‍💻 Author: Deep Dhabal")
        console.print("🎓 Computer Science Student | Cloud & Dev Enthusiast")
        raise typer.Exit()
    if info:
        show_banner()
        console.print("[bold cyan]ilovecli[/bold cyan] - Compress images, PDFs, and videos")
        console.print(f"📦 Version: {__version__}")
        console.print("⚡ Built with Typer & Rich")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        show_banner()
        console.print("Use [bold cyan]ilovecli --help[/bold cyan] to see available commands.")

# 2. Grouped into Panels using rich_help_panel and added short_help
@app.command(
    rich_help_panel="[bold cyan]🚀 Core Compression[/bold cyan]",
    short_help="Auto-detect & compress a single file (Img/PDF/Vid)."
)
@app.command(name="c", hidden=True)
def compress(
    file: Path = typer.Argument(..., help="Path to the file to compress"),
    quality: int = typer.Option(60, "--quality", "-q", help="Image quality (10-95)"),
    pdf_quality: str = typer.Option("ebook", "--pdf-quality", "-p", help="PDF quality profile", case_sensitive=False, show_choices=True),
    crf: int = typer.Option(28, "--crf", "-c", help="Video CRF (18-35)")
):
    """
    [bold green]Auto-detect and compress a file.[/bold green]
    
    [blue]Alias:[/blue] [bold]c[/bold]
    
    Automatically detects the file type (image, video, or PDF) and applies the optimal compression. 
    You can tweak the specific quality flags (like `--pdf-quality` or `--quality`) to adjust the output.
    """
    if not file.exists():
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    mime_type, _ = mimetypes.guess_type(str(file))
    try:
        logger.info(f"Starting compression for {file.name}")
        with console.status(f"Compressing {file.name}...", spinner="dots"):
            if mime_type and mime_type.startswith("image/"):
                compress_image(str(file), quality)
            elif mime_type == "application/pdf" or file.suffix.lower() == ".pdf":
                compress_pdf(str(file), pdf_quality)
            elif mime_type and mime_type.startswith("video/"):
                compress_video(str(file), crf)
            else:
                console.print(f"❌ Unsupported file type: {mime_type or 'Unknown'}", style="red")
                raise typer.Exit()
        console.print(f"✅ Compression completed: {file.name}", style="green")
        logger.info("Compression completed successfully")
    except Exception as e:
        logger.error(f"Error during compression: {e}")
        logger.debug("Stack trace:", exc_info=True)
        console.print(f"❌ Error: {e}", style="red")
        raise typer.Exit(1)

@app.command(
    rich_help_panel="[bold cyan]🚀 Core Compression[/bold cyan]",
    short_help="Compress an entire folder of images concurrently."
)
@app.command(name="f", hidden=True)
def folder(
    path: Path = typer.Argument(..., help="Path to the folder"),
    quality: int = typer.Option(60, "--quality", "-q", help="Image quality (10-95)"),
    overwrite: bool = typer.Option(False, "--overwrite", "-o", help="Overwrite existing compressed files"),
    recursive: bool = typer.Option(False, "--recursive", "-r", help="Recursively compress images in subfolders"),
    exclude: List[str] = typer.Option([], "--exclude", "-e", help="Folders to exclude (e.g., node_modules)"),
    smart: bool = typer.Option(False, "--smart", "-s", help="Auto-adjust quality based on file size/resolution")
):
    """
    [bold green]Compress an entire folder of images concurrently.[/bold green]
    
    [blue]Alias:[/blue] [bold]f[/bold]
    
    Utilizes multi-core processing to rapidly compress all supported images inside a directory.
    Use `--recursive` to scan subfolders, or `--smart` to let the algorithm decide quality limits.
    """
    if not path.exists():
        console.print("❌ Folder not found", style="red")
        raise typer.Exit()

    logger.info(f"Starting folder compression: {path}")
    if overwrite:
        typer.confirm("You are about to overwrite existing compressed files. Continue?", abort=True)
    with console.status(f"Compressing folder {path}...", spinner="dots"):
        compress_folder_parallel(str(path), quality, overwrite, recursive, exclude, smart)
    console.print(f"✅ Folder compression completed: {path}", style="green")

@app.command(
    rich_help_panel="[bold cyan]🚀 Core Compression[/bold cyan]",
    short_help="Compress a file to a precise target size in KB."
)
@app.command(name="t", hidden=True)
def target(
    file: Path = typer.Argument(..., help="Path to the file"),
    size_kb: int = typer.Argument(..., help="Target size in KB"),
    pdf_quality: str = typer.Option(
        "screen", "--quality", "-q", 
        help="PDF profile: screen, ebook, printer, prepress",
        case_sensitive=False, show_choices=True
    )
):
    """
    [bold green]Compress a file to a precise target size in KB.[/bold green]
    
    [blue]Alias:[/blue] [bold]t[/bold]
    
    Works for both images and PDFs utilizing binary search algorithms.
    
    [bold yellow]PDF Quality Profiles:[/bold yellow]
    - [cyan]screen[/cyan]: Fast compression, extremely low quality (72 DPI). Best for email/web.
    - [cyan]ebook[/cyan]: Good balance of quality and size (150 DPI). Best for general reading.
    - [cyan]printer[/cyan]: High quality for physical printing (300 DPI).
    - [cyan]prepress[/cyan]: Lossless, extremely high quality (300 DPI+). Minimal size reduction.
    """
    if not file.exists():
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    mime_type, _ = mimetypes.guess_type(str(file))
    initial_sz_mb = file.stat().st_size / (1024 * 1024)
    logger.info(f"Starting target compression for {file.name} to {size_kb} KB")

    try:
        with console.status(f"Compressing {file.name} ({initial_sz_mb:.2f} MB) to {size_kb} KB...", spinner="dots"):
            if mime_type and mime_type.startswith("image/"):
                out_path = compress_to_target_size(str(file), size_kb)
            elif mime_type == "application/pdf" or file.suffix.lower() == ".pdf":
                out_path = compress_pdf_to_target_size(str(file), size_kb, quality=pdf_quality)
            else:
                console.print("❌ Target compression only supported for images and PDFs", style="red")
                raise typer.Exit(1)
            
            if not out_path:
                raise ValueError("Could not compress file to desired target size.")

        out_file = Path(out_path)
        final_size_kb = round(out_file.stat().st_size / 1024, 2)
        console.print(f"✅ Target compression completed: {out_file.name} ({final_size_kb} KB)", style="green")
        logger.info("Target compression completed successfully")
    except Exception as e:
        logger.error(f"Error during target compression: {e}")
        logger.debug("Stack trace:", exc_info=True)
        console.print(f"❌ Target compression failed: {e}", style="red")
        raise typer.Exit(1)

@app.command(
    rich_help_panel="[bold yellow]🧰 Utilities[/bold yellow]",
    short_help="Download and compress a file directly from a URL."
)
@app.command(name="u", hidden=True)
def url(
    link: str = typer.Argument(..., help="URL to the file"),
    output: Path = typer.Option(None, "--output", "-o", help="Specific output filename"),
    quality: int = typer.Option(60, "--quality", "-q", help="Image quality (10-95)")
):
    """
    [bold green]Download and compress a file directly from a URL.[/bold green]
    
    [blue]Alias:[/blue] [bold]u[/bold]
    
    Downloads a file into a local path and instantly triggers the compression flow on it.
    """
    try:
        logger.info(f"Fetching URL: {link}")
        console.print(f"📥 Downloading from {link}...")
        response = requests.get(link, stream=True)
        response.raise_for_status()
        
        fname = link.split("/")[-1] or "downloaded_file"
        save_path = output if output else Path(fname)
        
        with open(save_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
                
        console.print(f"✅ Downloaded successfully to {save_path.name}")
        compress(save_path, quality=quality, pdf_quality="ebook", crf=28)
    except Exception as e:
        logger.error(f"Failed URL operation: {e}")
        logger.debug("Stack trace:", exc_info=True)
        console.print(f"❌ Failed to process URL: {e}", style="red")
        raise typer.Exit(1)

@app.command(
    rich_help_panel="[bold yellow]🧰 Utilities[/bold yellow]",
    short_help="Convert an image from one format to another."
)
@app.command(name="cv", hidden=True)
def convert(
    input: Path = typer.Argument(..., help="Input file path"),
    output: Path = typer.Argument(..., help="Output file path (e.g., output.webp)")
):
    """
    [bold green]Convert an image from one format to another.[/bold green]
    
    [blue]Alias:[/blue] [bold]cv[/bold]
    
    Simple utility to convert images safely (e.g., png to jpg or webp).
    """
    logger.info(f"Converting {input.name} to {output.name}")
    with console.status(f"Converting {input.name}...", spinner="dots"):
        convert_image(str(input), str(output))
    console.print(f"✅ Conversion completed: {output.name}", style="green")

@app.command(
    rich_help_panel="[bold magenta]🛠️  Diagnostics[/bold magenta]",
    short_help="Check system dependencies (FFmpeg, Ghostscript)."
)
@app.command(name="d", hidden=True)
def doctor():
    """
    [bold green]System dependencies check for compression engines.[/bold green]
    
    [blue]Alias:[/blue] [bold]d[/bold]
    
    Verifies if your system has FFmpeg (for videos) and Ghostscript (for PDFs) installed securely.
    """
    console.print("[bold cyan]ilovecli[/bold cyan] System Doctor 🩺\n", style="bold")
    
    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path:
        console.print(f"✅ FFmpeg found: [green]{ffmpeg_path}[/green]")
    else:
        console.print("❌ FFmpeg NOT found (Video compression will not work)", style="red")

    gs_path = shutil.which("gs")
    if gs_path:
        console.print(f"✅ Ghostscript found: [green]{gs_path}[/green]")
    else:
        console.print("❌ Ghostscript NOT found (PDF compression will not work)", style="red")

if __name__ == "__main__":
    app()