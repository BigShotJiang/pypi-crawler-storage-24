
# 🚀 ilovecli (v1.0.0)

> Compress smarter. From your terminal.

`ilovecli` is a fast, cross-platform command-line tool to compress **Images, PDFs, and Videos** directly from your terminal. 

Built with an unapologetic focus on performance, the engine dynamically utilizes **multi-threading, hardware-accelerated HEVC encoding, and RAM-disk buffering** to guarantee blazing-fast execution times while maintaining beautiful, context-aware console output.

---

## ✨ Features

- 🖼 **Images (JPG, PNG, WEBP):** Multi-core parallel compression with `io.BytesIO()` RAM-buffering.
- 📄 **PDFs:** Ghostscript-powered size reduction utilizing `/tmp/` TMPFS RAM-disks to eliminate slow I/O.
- 🎬 **Videos:** Next-gen `libx265` HEVC FFmpeg conversion dynamically mapping to 100% of CPU threads.
- 🎯 **Target-size Compression:** Feed a precise KB target, and the binary-search algorithm guarantees a fit.
- ⚡ **Lightning Fast Aliases:** Trigger any command with single keystrokes (`c`, `f`, `t`, `cv`, `u`, `d`).
- 🎨 **Gorgeous UI:** Fully mapped `Rich` terminal integration with contextual progress spinners.
- 🐳 **Docker Support:** Run effortlessly inside lightweight, pre-configured containers.

---

## 📦 Installation

### Install from PyPI

```bash
pip install ilovecli
```

*(Note: ilovecli relies on system implementations of FFmpeg and Ghostscript)*

### Install from Source

```bash
git clone https://github.com/Dhabaldeep/ilovecli.git
cd ilovecli
pip install .
```

---

## 🔧 System Diagnostics

Make sure the following engines are installed on your OS:
* Python 3.8+
* **FFmpeg** (for video compression)
* **Ghostscript** (for PDF compression)

You can run our built-in doctor command to verify your secure toolchains:
```bash
ilovecli doctor   # or: ilovecli d
```

---

## 🚀 Usage Guide

All commands support **Short Aliases** for massive speed typing improvements. Run `ilovecli --help` anytime for a gorgeous, color-coded manual!

### 🔹 Compress Any Supported File (`compress` / `c`)

```bash
ilovecli c file.jpg          # Image
ilovecli c document.pdf      # PDF
ilovecli c video.mp4         # Video
```

The system automatically detects the file MIME-type and routes it to the correct multi-threaded compression engine.

### 🎯 Compress to a Precise Target Size (`target` / `t`)

Need a PDF below 2MB for an email attachment? Just specify the KB:

```bash
ilovecli t image.jpg 300
ilovecli t document.pdf 1500 --quality ebook
```

Our engine calculates the file differential on the fly, rendering beautiful context-aware spinners:
`⠼ Compressing document.pdf (14.20 MB) to 1500 KB...`

### 📁 Parallel Folder Compression (`folder` / `f`)

```bash
ilovecli f ./images --smart
```

Shrink thousands of images at once utilizing 100% of your CPU cores.

### 🌐 Direct URL Processing (`url` / `u`)

```bash
ilovecli u https://example.com/massive_image.png
```
Downloads the file to a standard path and instantly executes the compression flow.

### 🔄 Format Converter (`convert` / `cv`)

```bash
ilovecli cv raw_photo.png optimized.webp
```

---

## 📄 PDF Quality Profiles (`-p` / `-q`)

When compressing PDFs, you no longer have to guess what quality you are exporting. We map directly to structured DPI variants:

* `screen` : Fast compression, extremely low quality (**72 DPI**). Best for emails and web.
* `ebook` : Good balance of quality and size (**150 DPI**). General reading default.
* `printer` : High quality for physical printing (**300 DPI**).
* `prepress` : Lossless, exceptionally high quality (**300 DPI+**). Minimal size reduction.

Example:
```bash
ilovecli c report.pdf -p prepress
```

---

## 🎬 Video Compression Engine

By default, `ilovecli` runs all video compression using **libx265 (HEVC)**. This yields incredibly small file sizes with no perceptible loss compared to legacy h264.

Control the Constant Rate Factor (`--crf` / `-c`):
- **Lower CRF** → Better quality
- **Higher CRF** → Smaller file (Recommended range: `18–35`)

```bash
ilovecli c video.mp4 -c 24
```

---

## 🐳 Docker Deployment

Don't want to install FFmpeg or Ghostscript locally? No problem.

```bash
docker build -t ilovecli .
docker run --rm -v $(pwd):/data ilovecli c /data/huge_file.pdf
```

---

## 🛠 Advanced Tech Stack

* **Typer & Rich**: Next-generation CLI routing and gorgeous rendering frameworks.
* **io.BytesIO & tempfile.tmpfs**: Complete removal of disk I/O chokepoints during deep binary searches.
* **Pillow-SIMD & Multiprocessing**: Heavily optimized concurrent graphical transformations.
* **HEVC / FFmpeg**: Fully threaded video crunching.

---

## 📄 License & Contributing

Licensed under the MIT License. Contributions are absolutely welcome! Support the project by dropping a ⭐ on the repository if this tool saved your hard drive!

