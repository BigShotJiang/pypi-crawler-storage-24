from dataclasses import dataclass
from pathlib import Path
import shutil
import re

import mistune
import tomllib

from .template_renderer import render_template, TEMPLATES_DIR


@dataclass
class Post:
    title: str
    slug: str
    path: Path
    meta: dict[str, str]
    summary: str


def _slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def _read_config(root: Path) -> dict:
    config_path = root / "vye.toml"
    if not config_path.exists():
        return {}
    return tomllib.loads(config_path.read_text(encoding="utf-8"))


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    if not text.startswith("---\n"):
        return {}, text
    parts = text.split("---\n", 2)
    if len(parts) < 3:
        return {}, text
    raw_meta, body = parts[1], parts[2]
    meta: dict[str, str] = {}
    for line in raw_meta.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = value.strip().strip('"')
    return meta, body


def _collect_posts(content_dir: Path) -> list[Post]:
    posts: list[Post] = []
    for path in sorted(content_dir.rglob("*.md")):
        meta, body = _parse_frontmatter(path.read_text(encoding="utf-8"))
        title = meta.get("title") or path.stem.replace("-", " ").title()
        slug = _slugify(path.stem)
        summary = _make_summary(body)
        posts.append(
            Post(title=title, slug=slug, path=path, meta=meta, summary=summary)
        )
    return posts


def _make_summary(body: str, limit: int = 32) -> str:
    text = re.sub(r"\s+", " ", body.strip())
    if len(text) <= limit:
        return text
    return text[:limit].rstrip() + "..."


def _find_avatar(assets_dir: Path) -> Path | None:
    candidates = [
        "avatar.png",
        "avatar.jpg",
        "avatar.jpeg",
        "avatar.webp",
        "avatar.gif",
        "avatar.svg",
        "avatar.ppm",
    ]
    for name in candidates:
        path = assets_dir / name
        if path.exists():
            return path
    return None


def _copy_assets(root: Path, dist_dir: Path) -> None:
    assets_dir = root / "assets"
    if not assets_dir.exists():
        return

    dest_dir = dist_dir / "assets"
    if dest_dir.exists():
        shutil.rmtree(dest_dir)
    shutil.copytree(assets_dir, dest_dir)


def _load_css(theme: str) -> str:
    css_name = {
        "terminal": "terminal.css",
        "classic": "classic.css",
    }.get(theme, "classic.css")
    return (TEMPLATES_DIR / css_name).read_text(encoding="utf-8")


def execute():
    root = Path(".")
    config = _read_config(root)
    if config == {}:
        print(
            "A vye.toml file was not found. Please initialize a site with ´vye init´ first."
        )
        return
    meta = config.get("meta", {})
    site_title = meta.get("title", "Vye site")
    author = meta.get("author", "Anonymous")
    tagline = meta.get(
        "tagline", meta.get("tagline", "A tiny statically generated blog.")
    )
    theme = meta.get("theme", config.get("theme", "classic"))

    content_dir = root / "articles"
    dist_dir = root / "dist"
    dist_dir.mkdir(parents=True, exist_ok=True)
    _copy_assets(root, dist_dir)
    avatar_path = _find_avatar(root / "assets")

    posts = _collect_posts(content_dir) if content_dir.exists() else []
    markdown = mistune.create_markdown(escape=False, hard_wrap=True)
    css = _load_css(theme)

    rendered_posts: list[dict[str, str]] = []
    for post in posts:
        raw = post.path.read_text(encoding="utf-8")
        _, body = _parse_frontmatter(raw)
        html = markdown(body)
        out_dir = dist_dir / post.slug
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "index.html").write_text(
            render_template(
                "post.html.j2",
                title=post.title,
                site_title=site_title,
                date=post.meta.get("date", "Post"),
                content=html,
                css=css,
            ),
            encoding="utf-8",
        )
        rendered_posts.append(
            {
                "title": post.title,
                "summary": post.summary,
                "url": f"{post.slug}/index.html",
            }
        )

    (dist_dir / "index.html").write_text(
        render_template(
            "index.html.j2",
            title=site_title,
            site_title=site_title,
            author=author,
            tagline=tagline,
            posts=rendered_posts,
            avatar_name=avatar_path.name if avatar_path else None,
            css=css,
        ),
        encoding="utf-8",
    )

    print(f"Built {len(rendered_posts)} post(s) into {dist_dir.resolve()}")
