from sys import argv

from . import build_command
from . import new_command


def main():
    if len(argv) > 1 and argv[1] == "init":
        new_command.execute()
    elif len(argv) > 1 and argv[1] == "build":
        build_command.execute()
    else:
        print("Usage: vye [init|build]")
