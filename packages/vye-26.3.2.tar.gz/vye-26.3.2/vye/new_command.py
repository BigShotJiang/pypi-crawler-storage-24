from rich.prompt import Prompt
from rich.prompt import Confirm
from rich import print
from pathlib import Path
import re


def _slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def _toml_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def execute():
    root = Path(".")
    print("[bold]Create a new Vye site[/bold]")
    print("This will set up the basic project files in the current directory.\n")

    title = Prompt.ask("Site name").strip()
    while not title:
        print("[red]Site name is required.[/red]")
        title = Prompt.ask("Site name").strip()

    author = Prompt.ask("Author").strip()
    tagline = Prompt.ask("Site tagline", default="A tiny statically generated blog.").strip()
    theme = Prompt.ask("Theme", choices=["classic", "terminal"], default="classic")
    seo_tags = Prompt.ask("SEO tags (comma-separated)", default="").strip()
    slug = _slugify(title)
    if not slug:
        print("[red]Could not derive a valid project directory name.[/red]")
        return
    project_dir = root / slug

    print()
    print(f"[bold]Project[/bold]: {title}")
    print(f"[bold]Author[/bold]: {author or 'Not provided'}")
    print(f"[bold]Location[/bold]: {project_dir.resolve()}")

    if project_dir.exists():
        print(f"[red]'{project_dir}' already exists. Aborting.[/red]")
        return

    if not Confirm.ask("Create project here?", default=True):
        print("Aborted.")
        return

    project_dir.mkdir(parents=True)
    (project_dir / "articles").mkdir(parents=True, exist_ok=True)
    (project_dir / "assets").mkdir(parents=True, exist_ok=True)
    config = project_dir / "vye.toml"
    tags = [tag.strip() for tag in seo_tags.split(",") if tag.strip()]
    tags_toml = ", ".join(f'"{tag}"' for tag in tags)
    config.write_text(
        "\n".join(
            [
                f'[meta]\ntitle = "{_toml_string(title)}"',
                f'author = "{_toml_string(author)}"',
                f'tagline = "{_toml_string(tagline)}"',
                f'theme = "{_toml_string(theme)}"',
                f"tags = [{tags_toml}]" if tags else "tags = []",
                "",
            ]
        ),
        encoding="utf-8",
    )

    post_path = project_dir / "articles" / "welcome.md"
    post_path.write_text(
        "\n".join(
            [
                "---",
                f'title: "Welcome to {title}"',
                f'date: "{datetime_now()}"',
                "---",
                "",
                "# Hello",
                "",
                "This is a starter post. Replace it with your own content.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    print("[green]Project created.[/green]")
    print(f"Next: cd {project_dir} and add posts in articles/ and an avatar in assets/ if you want one.")


def datetime_now() -> str:
    from datetime import date

    return date.today().isoformat()
