# Vye

Vye is a markdown-first static site generator written in Python.
It is meant for simple blogs without a heavy stack.

## Features

- `vye init` creates a new site.
- `vye build` generates static HTML from Markdown in `articles/`.
- Supports frontmatter metadata.

## Requirements

- Python `3.14` or newer.
- `uv` is recommended.

## Install

```bash
uv tool install vye
```

Or:

```bash
pipx install vye
```

## Usage

```bash
vye init
vye build
```

`vye init` creates `vye.toml`, `articles/welcome.md`, and `assets/`.
`vye build` writes the site to `dist/`.

## Expected Structure

```text
.
├── assets/
├── articles/
│   └── welcome.md
├── dist/
└── vye.toml
```

## Post Format

Markdown files in `articles/` can include frontmatter at the top:

```md
---
title: "My first post"
date: "2026-03-26"
---

# Hello

This is the body of the post.
```

If `title` is missing, Vye infers one from the file name.

## Configuration

`vye.toml` stores the site configuration:

```toml
[meta]
title = "My blog"
author = "Isaac"
tagline = "A small blog with good vibes"
theme = "classic"
tags = ["markdown", "blog", "static-site"]
```

## Notes

- `build` expects `vye.toml` at the project root.
- If `articles/` does not exist, the site still builds, but without posts.
- `assets/avatar.*` is used as an optional homepage avatar.

## License

See [LICENSE.md](LICENSE.md).
