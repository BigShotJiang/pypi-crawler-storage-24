"""trajectories CLI entry point."""

from pathlib import Path

import click
from rich.console import Console

from trajectories.config import get_api_key, get_api_url, set_api_key, set_api_url

console = Console()


@click.group()
@click.version_option(package_name="trajectories-sh")
def main():
    """trajectories.sh — Upload and share Harbor trajectory jobs."""
    pass


@main.command()
@click.argument("job_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--slug", "-s", default=None, help="URL slug (default: directory name)")
@click.option("--name", "-n", default=None, help="Display name (default: slug)")
@click.option("--visibility", "-v", type=click.Choice(["public", "unlisted", "private"]), default="private")
@click.option("--api-url", default=None, help="API base URL (override config)")
@click.option("--api-key", default=None, help="API key (override config)")
@click.option("--concurrency", "-c", default=12, help="Parallel upload threads")
def push(job_dir, slug, name, visibility, api_url, api_key, concurrency):
    """Push a Harbor job directory to trajectories.sh."""
    from trajectories.push import push_job
    push_job(job_dir, slug=slug, name=name, visibility=visibility,
             api_url=api_url, api_key=api_key, concurrency=concurrency)


@main.command()
@click.option("--api-key", prompt="API key", help="Your trajectories.sh API key")
@click.option("--api-url", default=None, help="Custom API URL (default: trajectories.sh)")
def login(api_key, api_url):
    """Save your API key for future pushes."""
    set_api_key(api_key)
    if api_url:
        set_api_url(api_url)

    console.print(f"[green]API key saved to ~/.trajectories-sh/config.json[/green]")
    console.print(f"  Key: {api_key[:12]}...")
    console.print(f"  URL: {api_url or get_api_url()}")


@main.command()
def whoami():
    """Show current configuration."""
    key = get_api_key()
    url = get_api_url()

    if key:
        console.print(f"  API key: {key[:12]}...")
    else:
        console.print("  [dim]No API key configured[/dim]")
    console.print(f"  API URL: {url}")


@main.command(name="push-task")
@click.argument("task_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--name", "-n", default=None, help="Task name (default: directory name)")
@click.option("--visibility", "-v", type=click.Choice(["public", "unlisted", "private"]), default="public")
@click.option("--api-url", default=None, help="API base URL (override config)")
@click.option("--api-key", default=None, help="API key (override config)")
def push_task(task_dir, name, visibility, api_url, api_key):
    """Upload a Harbor task directory to trajectories.sh."""
    from trajectories.push_task import push_task as _push_task
    _push_task(task_dir, name=name, visibility=visibility,
               api_url=api_url, api_key=api_key)


@main.command(name="import-run")
@click.argument("run_id", type=str)
@click.option("--repo", "-r", required=True, help="GitHub repo (owner/name)")
@click.option("--slug", "-s", default=None, help="URL slug (default: run-{RUN_ID})")
@click.option("--name", "-n", default=None, help="Display name")
@click.option("--visibility", "-v", type=click.Choice(["public", "unlisted", "private"]), default="unlisted")
@click.option("--api-url", default=None, help="API base URL (override config)")
@click.option("--api-key", default=None, help="API key (override config)")
@click.option("--concurrency", "-c", default=12, help="Parallel upload threads")
@click.option("--pattern", default="harbor-output-*", help="Artifact name pattern")
@click.option("--keep", is_flag=True, help="Keep a local copy of the merged artifacts")
def import_run_cmd(run_id, repo, slug, name, visibility, api_url, api_key, concurrency, pattern, keep):
    """Import a GitHub Actions Harbor run into trajectories.sh.

    Downloads harbor-output artifacts, merges them, and pushes to trajectories.sh.
    Requires the GitHub CLI (gh) to be installed and authenticated.
    """
    from trajectories.import_run import import_run
    import_run(
        repo=repo, run_id=run_id, slug=slug, name=name,
        visibility=visibility, api_url=api_url, api_key=api_key,
        concurrency=concurrency, artifact_pattern=pattern, keep=keep,
    )


@main.command()
def logout():
    """Remove saved API key."""
    from trajectories.config import CONFIG_FILE
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
        console.print("[green]Logged out. Config removed.[/green]")
    else:
        console.print("[dim]No config to remove.[/dim]")


if __name__ == "__main__":
    main()
