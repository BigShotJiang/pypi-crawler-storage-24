"""Import a Harbor CI run from GitHub Actions artifacts into trajectories.sh."""

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from rich.console import Console

from trajectories.push import push_job

console = Console()


def import_run(
    repo: str,
    run_id: str,
    slug: str | None = None,
    name: str | None = None,
    visibility: str = "unlisted",
    api_url: str | None = None,
    api_key: str | None = None,
    concurrency: int = 12,
    artifact_pattern: str = "harbor-output-*",
    keep: bool = False,
):
    """Download Harbor CI artifacts from a GitHub Actions run and push to trajectories.sh."""

    if shutil.which("gh") is None:
        console.print("[red]GitHub CLI (gh) is required but not installed.[/red]")
        console.print("  Install: https://cli.github.com/")
        raise SystemExit(1)

    if not slug:
        slug = f"run-{run_id}"
    if not name:
        name = f"{repo.split('/')[-1]} run {run_id}"

    with tempfile.TemporaryDirectory() as tmpdir:
        download_dir = Path(tmpdir) / "artifacts"
        merged_dir = Path(tmpdir) / "merged"
        merged_dir.mkdir()

        console.print(f"[bold]Importing run[/bold] {repo} #{run_id}")
        console.print(f"  Downloading artifacts matching [cyan]{artifact_pattern}[/cyan]...")

        result = subprocess.run(
            [
                "gh", "run", "download", run_id,
                "--repo", repo,
                "--pattern", artifact_pattern,
                "--dir", str(download_dir),
            ],
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            console.print(f"[red]Download failed:[/red] {result.stderr.strip()}")
            raise SystemExit(1)

        artifact_dirs = sorted(download_dir.iterdir()) if download_dir.exists() else []
        if not artifact_dirs:
            console.print("[red]No artifacts found for this run.[/red]")
            raise SystemExit(1)

        console.print(f"  Downloaded {len(artifact_dirs)} artifact(s)")

        console.print("  Merging artifacts...")
        for artifact_dir in artifact_dirs:
            if not artifact_dir.is_dir():
                continue
            for item in artifact_dir.rglob("*"):
                if item.is_file():
                    rel = item.relative_to(artifact_dir)
                    dest = merged_dir / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(item, dest)

        file_count = sum(1 for _ in merged_dir.rglob("*") if _.is_file())
        console.print(f"  Merged into {file_count} files")

        if keep:
            keep_dir = Path(f"harbor-run-{run_id}")
            if keep_dir.exists():
                shutil.rmtree(keep_dir)
            shutil.copytree(merged_dir, keep_dir)
            console.print(f"  Kept local copy at [dim]{keep_dir}[/dim]")

        console.print()
        push_job(
            job_dir=merged_dir,
            slug=slug,
            name=name,
            visibility=visibility,
            api_url=api_url,
            api_key=api_key,
            concurrency=concurrency,
        )
