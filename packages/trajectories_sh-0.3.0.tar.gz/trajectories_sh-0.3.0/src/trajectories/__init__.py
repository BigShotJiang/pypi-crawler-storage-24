"""trajectories-sh: CLI for uploading Harbor trajectory jobs."""
__version__ = "0.3.0"
