"""Push a Harbor job directory to trajectories.sh."""

import os
import tarfile
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import (
    Progress,
    BarColumn,
    TextColumn,
    TimeElapsedColumn,
    MofNCompleteColumn,
    DownloadColumn,
    SpinnerColumn,
)

from trajectories.config import get_api_key, get_api_url

console = Console()

SKIP_PATTERNS = {"__pycache__", ".DS_Store", ".git"}
MAX_FILE_SIZE = 50 * 1024 * 1024
ARCHIVE_THRESHOLD = 50


def collect_files(job_dir: Path) -> list[tuple[Path, str]]:
    """Collect all files in the job directory with relative paths."""
    files = []
    for root, dirs, filenames in os.walk(job_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_PATTERNS]
        for name in filenames:
            if name in SKIP_PATTERNS:
                continue
            abs_path = Path(root) / name
            rel_path = abs_path.relative_to(job_dir)
            if abs_path.stat().st_size > MAX_FILE_SIZE:
                continue
            files.append((abs_path, str(rel_path)))
    return files


def push_job(
    job_dir: Path,
    slug: str | None = None,
    name: str | None = None,
    visibility: str = "private",
    api_url: str | None = None,
    api_key: str | None = None,
    concurrency: int = 12,
):
    """Push a Harbor job directory to trajectories.sh."""
    api_url = api_url or get_api_url()
    api_key = api_key or get_api_key()

    if not api_key:
        console.print("[red]No API key configured. Run: trajectories login[/red]")
        raise SystemExit(1)

    if not job_dir.exists() or not job_dir.is_dir():
        console.print(f"[red]Directory not found: {job_dir}[/red]")
        raise SystemExit(1)

    if not slug:
        slug = job_dir.name

    if not name:
        name = slug

    headers = {"Authorization": f"Bearer {api_key}"}
    client = httpx.Client(base_url=api_url, headers=headers, timeout=300.0)

    console.print(f"[bold]Pushing[/bold] {job_dir} → [cyan]{slug}[/cyan]")

    files = collect_files(job_dir)
    total_size = sum(f.stat().st_size for f, _ in files)
    console.print(f"  {len(files)} files, {total_size / 1024 / 1024:.1f} MB")

    resp = client.post("/api/cli/push/init", json={
        "slug": slug,
        "name": name,
        "visibility": visibility,
    })
    if resp.status_code != 200:
        console.print(f"[red]Init failed: {resp.text}[/red]")
        raise SystemExit(1)

    init_data = resp.json()
    job_id = init_data["job_id"]
    console.print(f"  Job ID: [dim]{job_id}[/dim]")

    if len(files) >= ARCHIVE_THRESHOLD:
        _push_archive(client, job_id, job_dir, files, total_size)
    else:
        _push_files(client, job_id, files, total_size, concurrency)

    console.print("  Finalizing...")
    resp = client.post(f"/api/cli/push/{job_id}/finalize")
    if resp.status_code != 200:
        console.print(f"[red]Finalize failed: {resp.text}[/red]")
        raise SystemExit(1)

    result = resp.json()
    console.print()
    console.print(f"[green bold]✓ Pushed successfully![/green bold]")
    console.print(f"  Trials: {result['n_trials']}")
    if result.get("mean_reward") is not None:
        console.print(f"  Pass rate: {result['mean_reward'] * 100:.0f}%")
    console.print(f"  Viewer: {api_url}{result['viewer_url']}")


CHUNK_MAX_MB = 15


def _push_archive(client: httpx.Client, job_id: str, job_dir: Path, files: list, total_size: int):
    """Compress and upload as tar.gz archive(s), splitting into chunks if needed."""
    with tempfile.TemporaryDirectory() as tmpdir:
        archive_path = os.path.join(tmpdir, "upload.tar.gz")

        console.print(f"  Compressing {len(files)} files...")
        with tarfile.open(archive_path, "w:gz") as tar:
            for abs_path, rel_path in files:
                tar.add(str(abs_path), arcname=rel_path)

        archive_size = os.path.getsize(archive_path)
        ratio = (1 - archive_size / total_size) * 100 if total_size > 0 else 0
        console.print(f"  Archive: {archive_size / 1024 / 1024:.1f} MB ({ratio:.0f}% compressed)")

        chunk_limit = CHUNK_MAX_MB * 1024 * 1024

        if archive_size <= chunk_limit:
            _upload_via_signed_url(client, job_id, archive_path, archive_size)
        else:
            _upload_chunked_signed(client, job_id, files, tmpdir, chunk_limit, total_size)


def _do_signed_upload_and_extract(client: httpx.Client, job_id: str, archive_path: str, archive_size: int, label: str = ""):
    """Upload a tar.gz to Supabase Storage via signed URL, then extract server-side."""
    resp = client.post(f"/api/cli/push/{job_id}/upload-url")
    if resp.status_code != 200:
        console.print(f"[red]Failed to get upload URL: {resp.text}[/red]")
        raise SystemExit(1)

    signed_url = resp.json()["signed_url"]

    import subprocess
    import shutil

    upload_ok = False
    for attempt in range(3):
        if shutil.which("curl"):
            result = subprocess.run(
            ["curl", "--http1.1", "-s",
             "-w", "%{response_code}",
             "-o", "/dev/null",
             "-X", "PUT", signed_url,
             "-H", "Content-Type: application/gzip",
             "-H", "Expect:",
             "--data-binary", f"@{archive_path}",
             "--max-time", "600",
             "--retry", "2", "--retry-delay", "5"],
                capture_output=True, text=True,
            )
            status = result.stdout.strip()
            if status in ("200", "201"):
                upload_ok = True
                break
            console.print(f"  [yellow]Upload attempt {attempt + 1} failed: HTTP {status}[/yellow]")
        else:
            try:
                with open(archive_path, "rb") as f:
                    upload_resp = httpx.put(
                        signed_url, content=f.read(),
                        headers={"Content-Type": "application/gzip"},
                        timeout=600.0,
                    )
                if upload_resp.status_code in (200, 201):
                    upload_ok = True
                    break
                console.print(f"  [yellow]Upload attempt {attempt + 1} failed: {upload_resp.status_code}[/yellow]")
            except Exception as e:
                console.print(f"  [yellow]Upload attempt {attempt + 1} error: {e}[/yellow]")
        if attempt < 2:
            time.sleep(5)

    if not upload_ok:
        console.print(f"[red]Storage upload failed after retries[/red]")
        raise SystemExit(1)

    console.print(f"  Extracting{label}...")
    extract_resp = client.post(f"/api/cli/push/{job_id}/extract", timeout=30.0)
    if extract_resp.status_code != 200:
        console.print(f"[red]Extract start failed: {extract_resp.text[:200]}[/red]")
        raise SystemExit(1)

    while True:
        time.sleep(3)
        try:
            status_resp = client.get(f"/api/cli/push/{job_id}/extract-status", timeout=10.0)
            if status_resp.status_code != 200:
                continue
            status = status_resp.json()
            st = status.get("status", "unknown")
            if st == "done":
                return status
            elif st == "error":
                console.print(f"[red]Extraction error: {status.get('detail')}[/red]")
                raise SystemExit(1)
            else:
                uploaded = status.get("uploaded", 0)
                if uploaded > 0:
                    console.print(f"    {st}... {uploaded} files stored", end="\r")
        except Exception:
            pass


def _upload_via_signed_url(client: httpx.Client, job_id: str, archive_path: str, archive_size: int):
    """Upload a single archive via signed URL and extract."""
    result = _do_signed_upload_and_extract(client, job_id, archive_path, archive_size)
    if result.get("errors", 0) > 0:
        console.print(f"  [yellow]Stored: {result['uploaded']}, Errors: {result['errors']}[/yellow]")
    else:
        console.print(f"  [green]All {result['uploaded']} files stored[/green]")


def _upload_chunked_signed(client: httpx.Client, job_id: str, files: list, tmpdir: str, chunk_limit: int, total_size: int):
    """Split files into multiple archives under the size limit, upload each via signed URL."""
    target_raw_per_chunk = chunk_limit * 4
    chunks: list[list] = [[]]
    current_size = 0

    for abs_path, rel_path in files:
        fsize = abs_path.stat().st_size
        if current_size + fsize > target_raw_per_chunk and chunks[-1]:
            chunks.append([])
            current_size = 0
        chunks[-1].append((abs_path, rel_path))
        current_size += fsize

    console.print(f"  Splitting into {len(chunks)} chunks (max {CHUNK_MAX_MB}MB each)")

    total_uploaded = 0
    total_errors = 0

    for i, chunk_files in enumerate(chunks):
        chunk_path = os.path.join(tmpdir, f"chunk-{i}.tar.gz")
        label = f" chunk {i + 1}/{len(chunks)}"

        console.print(f"  Compressing{label} ({len(chunk_files)} files)...")
        with tarfile.open(chunk_path, "w:gz") as tar:
            for abs_path, rel_path in chunk_files:
                tar.add(str(abs_path), arcname=rel_path)

        chunk_size = os.path.getsize(chunk_path)
        console.print(f"  {label}: {chunk_size / 1024 / 1024:.1f} MB")

        result = _do_signed_upload_and_extract(client, job_id, chunk_path, chunk_size, label)
        total_uploaded += result.get("uploaded", 0)
        total_errors += result.get("errors", 0)

        os.unlink(chunk_path)

    if total_errors > 0:
        console.print(f"  [yellow]Stored: {total_uploaded}, Errors: {total_errors}[/yellow]")
    else:
        console.print(f"  [green]All {total_uploaded} files stored across {len(chunks)} chunks[/green]")


def _push_files(client: httpx.Client, job_id: str, files: list, total_size: int, concurrency: int):
    """Upload files individually (used for small jobs)."""
    uploaded = 0
    errors = 0

    def upload_one(abs_path: Path, rel_path: str) -> int:
        file_size = abs_path.stat().st_size
        for attempt in range(3):
            try:
                with open(abs_path, "rb") as f:
                    upload_resp = client.post(
                        f"/api/cli/push/{job_id}/file",
                        files={"file": (rel_path, f, "application/octet-stream")},
                        data={"path": rel_path},
                    )
                if upload_resp.status_code == 200:
                    return file_size
            except Exception:
                pass
            if attempt < 2:
                time.sleep(1.0 * (attempt + 1))
        return -1

    with Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=30),
        MofNCompleteColumn(),
        TextColumn("·"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Uploading", total=len(files))

        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            futures = {executor.submit(upload_one, ap, rp): (ap, rp) for ap, rp in files}
            for future in as_completed(futures):
                _, rel_path = futures[future]
                result = future.result()
                if result >= 0:
                    uploaded += 1
                    progress.console.print(f"  [green]✓[/green] [dim]{rel_path}[/dim]")
                else:
                    errors += 1
                    progress.console.print(f"  [red]✗[/red] [dim]{rel_path}[/dim]")
                progress.advance(task)

    if errors > 0:
        console.print(f"  [yellow]Uploaded: {uploaded}, Errors: {errors}[/yellow]")
    else:
        console.print(f"  [green]All {uploaded} files uploaded[/green]")
