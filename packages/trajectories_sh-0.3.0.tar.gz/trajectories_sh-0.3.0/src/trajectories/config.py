"""Config file management for trajectory-sh CLI."""

import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".trajectories-sh"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_API_URL = "https://api.trajectories.sh"


def load_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def save_config(config: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_api_key() -> str | None:
    return load_config().get("api_key")


def get_api_url() -> str:
    return load_config().get("api_url", DEFAULT_API_URL)


def set_api_key(key: str):
    config = load_config()
    config["api_key"] = key
    save_config(config)


def set_api_url(url: str):
    config = load_config()
    config["api_url"] = url
    save_config(config)
