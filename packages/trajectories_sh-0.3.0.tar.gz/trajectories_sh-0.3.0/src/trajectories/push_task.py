"""Push a Harbor task directory to trajectories.sh."""

import hashlib
import os
from pathlib import Path

import httpx
from rich.console import Console

from trajectories.config import get_api_key, get_api_url

console = Console()


def compute_dirhash(task_dir: Path) -> str:
    """Compute SHA-256 dirhash matching Harbor's checksum algorithm."""
    try:
        from dirhash import dirhash
        return dirhash(str(task_dir), "sha256")
    except ImportError:
        pass

    h = hashlib.sha256()
    for root, dirs, files in sorted(os.walk(task_dir)):
        dirs.sort()
        for fname in sorted(files):
            fpath = Path(root) / fname
            rel = fpath.relative_to(task_dir)
            h.update(str(rel).encode())
            h.update(fpath.read_bytes())
    return h.hexdigest()


def read_file(task_dir: Path, *names: str) -> str:
    """Read the first matching file from the task directory."""
    for name in names:
        p = task_dir / name
        if p.exists():
            return p.read_text(errors="replace")
    return ""


def parse_toml_config(task_dir: Path) -> dict:
    """Parse task.toml if present."""
    p = task_dir / "task.toml"
    if not p.exists():
        return {}
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore
        except ImportError:
            return {}
    return tomllib.loads(p.read_text())


def push_task(
    task_dir: Path,
    name: str | None = None,
    visibility: str = "public",
    api_url: str | None = None,
    api_key: str | None = None,
):
    """Upload a task directory to trajectories.sh."""
    api_url = api_url or get_api_url()
    api_key = api_key or get_api_key()

    if not api_key:
        console.print("[red]No API key configured. Run: trajectories login[/red]")
        raise SystemExit(1)

    external_id = name or task_dir.name
    console.print(f"[bold]Pushing task[/bold] {task_dir} → [cyan]{external_id}[/cyan]")

    console.print("  Computing dirhash...")
    task_hash = compute_dirhash(task_dir)
    console.print(f"  Hash: [dim]{task_hash}[/dim]")

    instruction = read_file(task_dir, "instruction.md", "instruction.txt", "prompt.md", "prompt.txt")
    dockerfile = read_file(task_dir, "environment/Dockerfile", "Dockerfile")
    test_code = read_file(task_dir, "tests/tests.py", "tests/test.py", "test.py")
    solution = ""
    sol_dir = task_dir / "solution"
    if sol_dir.exists():
        parts = []
        for f in sorted(sol_dir.rglob("*")):
            if f.is_file():
                rel = f.relative_to(task_dir)
                parts.append(f"# {rel}\n{f.read_text(errors='replace')}")
        solution = "\n\n".join(parts)

    config = parse_toml_config(task_dir)
    metadata = config.get("metadata", {})
    category = metadata.get("category", "")
    difficulty = metadata.get("difficulty", "")
    tags = metadata.get("tags", [])

    console.print(f"  Instruction: {len(instruction)} chars")
    console.print(f"  Dockerfile: {len(dockerfile)} chars")
    console.print(f"  Tests: {len(test_code)} chars")
    if tags:
        console.print(f"  Tags: {', '.join(tags)}")

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    client = httpx.Client(base_url=api_url, headers=headers, timeout=30.0)

    console.print("  Uploading...")
    resp = client.post("/api/cli/push-task", json={
        "external_id": external_id,
        "task_hash": task_hash,
        "instruction": instruction,
        "dockerfile": dockerfile,
        "test_code": test_code,
        "solution": solution,
        "category": category,
        "difficulty": difficulty,
        "tags": tags,
        "source_path": external_id,
        "visibility": visibility,
    })

    if resp.status_code != 200:
        console.print(f"[red]Upload failed: {resp.text}[/red]")
        raise SystemExit(1)

    result = resp.json()
    console.print()
    if result["created"]:
        console.print(f"[green bold]✓ Task created![/green bold]")
    else:
        console.print(f"[green bold]✓ Task updated![/green bold]")
    console.print(f"  Task ID: {result['task_id']}")
    console.print(f"  Hash: {result['task_hash']}")
    console.print(f"  View: {api_url.replace('api.', '')}/visualizer?task={result['task_id']}")
