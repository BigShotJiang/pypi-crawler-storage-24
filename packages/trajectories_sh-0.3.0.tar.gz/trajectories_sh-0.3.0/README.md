# trajectories

CLI for uploading Harbor trajectory jobs to trajectories.sh.

## Install

```bash
pip install trajectories
```

## Usage

```bash
# Save your API key (get it from Settings in the web app)
trajectories login --api-key tsh_your_key_here

# Push a Harbor job directory
trajectories push ./jobs/my-run

# Push with options
trajectories push ./jobs/my-run --slug my-benchmark --visibility public --name "My Benchmark Run"

# Check config
trajectories whoami
```
