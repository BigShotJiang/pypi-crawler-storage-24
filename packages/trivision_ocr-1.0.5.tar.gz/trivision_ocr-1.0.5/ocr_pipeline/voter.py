"""
voter.py — Stage 2: Confidence-weighted spatial voter.

Merges detections from all three OCR engines into a single deduplicated list.
Algorithm:
  1. Flatten all results into one list.
  2. Group boxes that overlap spatially (IoU > IOU_THRESHOLD).
  3. Within each group, pick the text with the highest weighted score:
       score = confidence × ENGINE_WEIGHT + (agreeing_engines × AGREEMENT_BONUS)
  4. Return one canonical detection per spatial group.

The agreement bonus is the key differentiator vs. Google Vision API: when all 3
engines agree on the same text, confidence is boosted significantly — this
cross-validation removes random engine errors that a single model cannot detect.

Expert review fix applied:
  - area2 computation: was (box2[0]-box2[0]) * ... → fixed to (box2[2]-box2[0]) * ...
"""

from __future__ import annotations

from difflib import SequenceMatcher

# Config is optional at import time — voter.py is used in unit tests where the
# full dependency chain (pytesseract, paddleocr, …) is NOT installed.
# If config is unavailable, sensible defaults are used instead.
try:
    from . import config as _config
    _MIN_CONF: float = getattr(_config, "MIN_CONFIDENCE", 0.05)
    _IOU_THRESHOLD = _config.IOU_THRESHOLD
    _TEXT_SIM_THRESHOLD = _config.TEXT_SIMILARITY_THRESHOLD
    _AGREEMENT_BONUS = _config.AGREEMENT_BONUS
    _ENGINE_WEIGHTS = _config.ENGINE_WEIGHTS
except Exception:  # ModuleNotFoundError or ImportError for heavy deps
    _MIN_CONF: float = 0.05
    _IOU_THRESHOLD = 0.20
    _TEXT_SIM_THRESHOLD = 0.80
    _AGREEMENT_BONUS = 0.15
    _ENGINE_WEIGHTS = {"paddleocr": 0.45, "easyocr": 0.35, "tesseract": 0.20}


# ── Core geometry ────────────────────────────────────────────────────────────


def iou(box1: list, box2: list) -> float:
    """
    Intersection-over-Union for two axis-aligned bounding boxes [x1, y1, x2, y2].

    Returns 0.0 for non-overlapping or zero-area boxes (degenerate edge case
    from noisy crops — prevents ZeroDivisionError).
    """
    # Zero-area guard (expert review fix #4)
    area1 = max(0.0, box1[2] - box1[0]) * max(0.0, box1[3] - box1[1])
    area2 = max(0.0, box2[2] - box2[0]) * max(0.0, box2[3] - box2[1])   # FIXED typo
    if area1 == 0.0 or area2 == 0.0:
        return 0.0

    xi1 = max(box1[0], box2[0])
    yi1 = max(box1[1], box2[1])
    xi2 = min(box1[2], box2[2])
    yi2 = min(box1[3], box2[3])

    inter_area = max(0.0, xi2 - xi1) * max(0.0, yi2 - yi1)
    union_area = area1 + area2 - inter_area
    return inter_area / union_area if union_area > 0 else 0.0


def text_similarity(a: str, b: str) -> float:
    """SequenceMatcher ratio between two lowercased strings. Range [0, 1]."""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


# ── Main voter ───────────────────────────────────────────────────────────────


def vote(all_results: list[list[dict]]) -> list[dict]:
    """
    Merge results from multiple engines into a single deduplicated list.

    Parameters
    ----------
    all_results:
        One list of ``{text, confidence, bbox, engine}`` dicts per engine.

    Returns
    -------
    List of ``{text, confidence, bbox, engine_count}`` — one entry per
    distinct text region found in the image.
    """
    flat: list[dict] = [item for engine_list in all_results for item in engine_list]
    if not flat:
        return []

    used = [False] * len(flat)
    final: list[dict] = []

    for i, anchor in enumerate(flat):
        if used[i]:
            continue

        # Collect all detections that spatially overlap with this anchor
        group = [anchor]
        for j, candidate in enumerate(flat):
            if i == j or used[j]:
                continue
            if iou(anchor["bbox"], candidate["bbox"]) > _IOU_THRESHOLD:
                group.append(candidate)
                used[j] = True
        used[i] = True

        # ── Weighted vote within the group ───────────────────────────────────
        best_text: str | None = None
        best_bbox: list | None = None
        best_score: float = _MIN_CONF - 0.001  # Need to comfortably beat MIN_CONFIDENCE to be selected

        for det in group:
            engine_weight = _ENGINE_WEIGHTS.get(det["engine"], 0.20)
            base_score = det["confidence"] * engine_weight

            # Count how many OTHER detections in the group agree with this text
            agreements = sum(
                1
                for other in group
                if other is not det
                and text_similarity(det["text"], other["text"])
                > _TEXT_SIM_THRESHOLD
            )
            total_score = base_score + agreements * _AGREEMENT_BONUS

            if total_score > best_score:
                best_score = total_score
                best_text = det["text"]
                best_bbox = det["bbox"]

        if best_text is not None and best_bbox is not None:
            final.append(
                {
                    "text": best_text,
                    "confidence": min(1.0, best_score),
                    "bbox": best_bbox,
                    "engine_count": len(group),
                }
            )

    final = [t for t in final if not (t["engine_count"] == 1 and t["confidence"] < 0.10)]
    return final
