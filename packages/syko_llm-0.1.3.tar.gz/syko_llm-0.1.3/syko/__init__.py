
from .configuration_syko import SykoConfig
from .modeling_syko import SykoCausalLM, SykoBaseModel
from transformers import AutoConfig, AutoModelForCausalLM
AutoConfig.register("syko", SykoConfig)
AutoModelForCausalLM.register(SykoConfig, SykoCausalLM)
