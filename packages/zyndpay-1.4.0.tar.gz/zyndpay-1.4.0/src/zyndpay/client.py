from zyndpay.http_client import HttpClient
from zyndpay.resources.balances import Balances
from zyndpay.resources.bulk_payments import BulkPayments
from zyndpay.resources.payins import Payins
from zyndpay.resources.paylinks import Paylinks
from zyndpay.resources.payouts import Payouts
from zyndpay.resources.transactions import Transactions
from zyndpay.resources.withdrawals import Withdrawals
from zyndpay.webhooks import WebhookVerifier


class ZyndPay:
    """
    Official ZyndPay Python SDK.

    Example::

        from zyndpay import ZyndPay

        zyndpay = ZyndPay("zyp_live_sk_...")

        # Create a payin
        payin = zyndpay.payins.create(amount="100")
        print(payin["address"])  # Send USDT here

        # Create a payout
        payout = zyndpay.payouts.create(
            amount="50",
            destination_address="T...",
        )

        # Check balance
        balance = zyndpay.balances.get()
        print(balance["balance"])

        # Verify a webhook
        event = zyndpay.webhooks.verify(payload, signature)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = None,
        timeout: int = None,
        max_retries: int = None,
        webhook_secret: str = None,
    ):
        """
        Initialize the ZyndPay client.

        Args:
            api_key: Your API key (zyp_live_sk_... or zyp_test_sk_...)
            base_url: Base URL override (default: https://api.zyndpay.io/v1)
            timeout: Request timeout in seconds (default: 30)
            max_retries: Max retries on network errors (default: 2)
            webhook_secret: Webhook signing secret for signature verification
        """
        client = HttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        self.payins = Payins(client)
        self.payouts = Payouts(client)
        self.paylinks = Paylinks(client)
        self.bulk_payments = BulkPayments(client)
        self.withdrawals = Withdrawals(client)
        self.transactions = Transactions(client)
        self.balances = Balances(client)
        self.webhooks = WebhookVerifier(webhook_secret or "")
