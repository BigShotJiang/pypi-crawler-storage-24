class Balances:
    """Check your USDT balance."""

    def __init__(self, client):
        self._client = client

    def get(self) -> dict:
        """
        Get your USDT TRC20 balance.

        Returns:
            Dict with "currency" and "balance" fields.
        """
        res = self._client.get("/merchant/balances/USDT_TRC20")
        return res["data"]

    def get_all(self) -> dict:
        """
        Get all currency balances.

        Returns:
            Dict mapping currency names to balance strings.
        """
        res = self._client.get("/merchant/balances")
        return res["data"]

    def get_by_currency(self, currency) -> dict:
        """
        Get balance for a specific currency.

        Args:
            currency: Currency code (e.g. "USDT_TRC20")

        Returns:
            Dict with balance details for the specified currency.
        """
        res = self._client.request("GET", f"/merchant/balances/{currency}")
        return res["data"]
