"""Core streaming runner -- wraps soprano-sdk's LangGraph workflow and
yields high-level events instead of raw SDK types.

This is the only module in the streaming package that imports from
``soprano_sdk`` internals and ``langgraph``.  Consumer code should
depend only on :class:`WorkflowStreamer` and the event dataclasses.
"""

from __future__ import annotations

import os
import uuid
from typing import Any, Dict, Generator, Optional

from langfuse.langchain import CallbackHandler
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command

from soprano_sdk.core.engine import WorkflowEngine, load_workflow
from soprano_sdk.core.constants import MFAConfig, OutcomePrefix, WorkflowKeys
from soprano_sdk.utils.logger import logger
from soprano_sdk.utils.tracing import trace_workflow_execution

from .events import (
    AsyncInterruptEvent,
    CompleteEvent,
    CustomEvent,
    ErrorEvent,
    FollowUpEvent,
    FollowUpOutOfScopeEvent,
    InterruptEvent,
    NodeCompleteEvent,
    OutOfScopeEvent,
    RedirectEvent,
    WorkflowEvent,
)


class WorkflowStreamer:
    """Streaming wrapper around a soprano-sdk workflow.

    Replaces ``WorkflowTool.execute()`` with a generator-based API that
    yields typed events as each graph node runs, enabling real-time
    streaming to clients via SSE, WebSockets, or any transport.

    Parameters
    ----------
    yaml_path:
        Path to the soprano-sdk workflow YAML file.
    name:
        Identifier for this workflow (used in interrupt metadata).
    config:
        Optional runtime configuration dict passed to ``load_workflow``.
        All values take precedence over the YAML file configurations.
        
        **Full Schema Overrides (`_deep_merge_config`)**
        Any property defined in the JSON schema (`schema.py`) and 
        present in `_YAML_SCHEMA_KEYS` can be safely deep-merged at 
        runtime. This includes:
            - ``steps`` (list): Runtime topology configurations (e.g. 
              ``agent.model``, ``agent.instructions``, ``guardrails``).
            - ``outcomes`` (list): Runtime routing parameters (e.g. 
              ``humanize``, ``redirect_to``).
            - ``follow_up`` (dict): Follow-up configuration (e.g. 
              ``enabled``, ``on_unknown``, ``max_history_turns``).
            - ``humanization_agent`` (dict): Humanizer settings.
            - ``localization`` (dict): Locale prompts and language configurations.
            - ``data`` (list): Runtime dynamic fields.
            - ``agent_framework``, ``name``, ``failure_message``, etc.

        **Non-Schema Overrides** (Do not participate in schema validation):
            - ``model_config`` (dict): Primary LLM routing configuration.
              (keys: ``model_name``, ``provider``, ``api_key``, ``base_url``)
            - ``bedrock_config`` (dict): Underlying AWS Bedrock options.
            - ``rollback_strategy`` (str): Method of node resumptions.
            - ``template_loader``: Jinja2 custom renderer instance.
    checkpointer:
        Optional LangGraph checkpointer for state persistence.
        Defaults to ``InMemorySaver()``.
    mfa_config:
        Optional MFA configuration (passed through to soprano-sdk).

    Examples
    --------
    ::

        streamer = WorkflowStreamer.from_env("workflow.yaml", name="returns")

        for event in streamer.stream(thread_id="t1", user_message="hello"):
            match event:
                case InterruptEvent():
                    send_to_user(event.prompt)
                case CompleteEvent():
                    send_to_user(event.message)
    """

    def __init__(
        self,
        yaml_path: str,
        name: str = "workflow",
        description: str = "",
        config: Optional[Dict[str, Any]] = None,
        checkpointer: Any = None,
        mfa_config: Optional[MFAConfig] = None,
    ):
        if checkpointer is None:
            checkpointer = InMemorySaver()
        self._name = name
        self.description = description
        self._checkpointer = checkpointer
        self._graph: CompiledStateGraph
        self._engine: WorkflowEngine
        self._graph, self._engine = load_workflow(
            yaml_path,
            checkpointer=checkpointer,
            config=config,
            mfa_config=mfa_config,
        )

    @classmethod
    def from_env(
        cls,
        yaml_path: str = "workflow.yaml",
        name: str = "workflow",
        checkpointer: Any = None,
        mfa_config: Optional[MFAConfig] = None,
    ) -> WorkflowStreamer:
        """Build a streamer using environment variables.

        Required env vars:
            ``OPENAI_API_KEY``
        Optional env vars:
            ``MODEL_NAME``  (default: ``gpt-4o-mini``)

        Raises
        ------
        RuntimeError
            If ``OPENAI_API_KEY`` is not set.
        """
        api_key = os.environ.get("OPENAI_API_KEY", "")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY environment variable is not set")

        return cls(
            yaml_path=yaml_path,
            name=name,
            config={
                "model_config": {
                    "model_name": os.environ.get("MODEL_NAME", "gpt-4o-mini"),
                    "api_key": api_key,
                },
            },
            checkpointer=checkpointer,
            mfa_config=mfa_config,
        )

    @property
    def workflow_name(self) -> str:
        """Name of the loaded workflow (from the YAML ``name`` field)."""
        return self._engine.workflow_name

    @property
    def graph(self) -> CompiledStateGraph:
        """The underlying compiled LangGraph."""
        return self._graph

    @property
    def engine(self) -> WorkflowEngine:
        """The underlying workflow engine."""
        return self._engine

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def stream(
        self,
        thread_id: Optional[str] = None,
        user_message: Optional[str] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        target_language: Optional[str] = None,
        target_script: Optional[str] = None,
    ) -> Generator[WorkflowEvent, None, None]:
        """Execute one conversation turn and yield events as they occur.

        Handles both fresh starts and resumes automatically.  If the
        thread already has an interrupted workflow, sending a
        ``user_message`` resumes it.

        Parameters
        ----------
        thread_id:
            Unique conversation thread identifier.  If ``None``, a new
            UUID is generated automatically.
        user_message:
            The user's message.  ``None`` or ``""`` to start without
            user input.
        initial_context:
            Context to inject for fresh starts (e.g. ``{"order_id": "123"}``).
        target_language:
            Target language for this turn (e.g. ``"Tamil"``).
        target_script:
            Target script for this turn (e.g. ``"Devanagari"``).

        Yields
        ------
        WorkflowEvent
            One of the event types defined in ``soprano_sdk.streaming.events``.
        """
        thread_id = thread_id or str(uuid.uuid4())
        try:
            with trace_workflow_execution(
                workflow_name=self._name,
                thread_id=thread_id,
                has_initial_context=initial_context is not None,
            ) as span:
                yield from self._stream_graph(
                    thread_id, user_message, initial_context,
                    target_language, target_script,
                    span=span,
                )
                final_event = self._resolve_final_state(thread_id)

                if isinstance(final_event, (InterruptEvent, AsyncInterruptEvent, OutOfScopeEvent, FollowUpEvent, FollowUpOutOfScopeEvent)):
                    span.set_attribute("workflow.status", "interrupted")
                else:
                    span.set_attribute("workflow.status", "completed")

                yield final_event
        except Exception as exc:
            logger.error(f"[WorkflowStreamer] Error during streaming: {exc}")
            yield ErrorEvent(error=str(exc))

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _stream_graph(
        self,
        thread_id: str,
        user_message: Optional[str],
        initial_context: Optional[Dict[str, Any]],
        target_language: Optional[str],
        target_script: Optional[str],
        span: Any = None,
    ) -> Generator[NodeCompleteEvent | CustomEvent, None, None]:
        callback_handler = CallbackHandler()
        config = self._thread_config(thread_id)
        config["callbacks"] = [callback_handler]

        state = self._graph.get_state(config)

        localization_state: Dict[str, Any] = {}
        if target_language:
            localization_state[WorkflowKeys.TARGET_LANGUAGE] = target_language
        if target_script:
            localization_state[WorkflowKeys.TARGET_SCRIPT] = target_script

        if state.next:
            # Resuming an interrupted workflow
            if span:
                span.set_attribute("workflow.resumed", True)
            logger.info(f"[WorkflowStreamer] Resuming workflow {self._name} (thread: {thread_id})")
            filtered_context = self._filter_already_collected_fields(
                state.values, initial_context
            )
            self._engine.update_context(filtered_context)

            if span:
                span.add_event("context.updated", {
                    "fields": list(filtered_context.keys()),
                    "filtered_out": list(
                        set((initial_context or {}).keys()) - set(filtered_context.keys())
                    ),
                })

            update_state = {
                **filtered_context,
                **localization_state,
                WorkflowKeys.USER_MESSAGE: user_message or "",
                WorkflowKeys.THREAD_ID: thread_id,
                WorkflowKeys.WORKFLOW_NAME: self._name,
            }
            self._graph.update_state(config, update_state)
            input_val = Command(resume=user_message or "")
        else:
            # Fresh start
            if span:
                span.set_attribute("workflow.resumed", False)
            logger.info(f"[WorkflowStreamer] Starting workflow {self._name} (thread: {thread_id})")
            self._engine.update_context(initial_context)

            if span:
                span.add_event("context.updated", {
                    "fields": list((initial_context or {}).keys()),
                })

            input_val = {
                **(initial_context or {}),
                **localization_state,
                WorkflowKeys.USER_MESSAGE: user_message or "",
                WorkflowKeys.THREAD_ID: thread_id,
                WorkflowKeys.WORKFLOW_NAME: self._name,
            }

        for mode, chunk in self._graph.stream(
            input_val, config=config, stream_mode=["updates", "custom"]
        ):
            if mode == "updates":
                for node_name, update in chunk.items():
                    if node_name.startswith("__"):
                        continue
                    yield NodeCompleteEvent(
                        node=node_name,
                        state_update=_serialize(update),
                    )
            elif mode == "custom":
                yield CustomEvent(payload=_serialize(chunk))

    def _resolve_final_state(
        self, thread_id: str
    ) -> InterruptEvent | AsyncInterruptEvent | OutOfScopeEvent | FollowUpEvent | FollowUpOutOfScopeEvent | CompleteEvent | RedirectEvent:
        config = self._thread_config(thread_id)
        final_state = self._graph.get_state(config)

        # Per LangGraph docs, state.tasks[].interrupts is the authoritative
        # source for interrupt data after both stream() and invoke().
        # state.next contains pending node names (non-empty after interrupt).
        interrupt_val = None
        if final_state.tasks:
            for task in final_state.tasks:
                if task.interrupts:
                    interrupt_val = task.interrupts[0].value
                    break

        if interrupt_val is not None:
            return self._build_interrupt_from_value(interrupt_val, final_state, thread_id)

        # No interrupt — workflow completed. Clean up thread checkpoint.
        if not final_state.next and self._checkpointer:
            try:
                self._checkpointer.delete_thread(thread_id)
            except AttributeError:
                pass

        return self._build_complete(final_state, thread_id)

    def _build_interrupt_from_value(
        self, interrupt_val: Any, final_state: Any, thread_id: str
    ) -> InterruptEvent | AsyncInterruptEvent | OutOfScopeEvent | FollowUpEvent | FollowUpOutOfScopeEvent:
        interrupt_type = interrupt_val.get("type") if isinstance(interrupt_val, dict) else None

        # Async interrupt
        if interrupt_type == "async":
            return AsyncInterruptEvent(
                thread_id=thread_id,
                workflow_name=self._name,
                pending=interrupt_val.get("pending", {}),
                step_id=interrupt_val.get("step_id", ""),
            )

        # Collector out-of-scope interrupt
        if interrupt_type == "out_of_scope":
            return OutOfScopeEvent(
                thread_id=thread_id,
                workflow_name=self._name,
                reason=interrupt_val.get("reason", "User query is out of scope"),
                user_message=interrupt_val.get("user_message", ""),
            )

        # Follow-up Q&A interrupt
        if interrupt_type == "follow_up":
            return FollowUpEvent(
                prompt=interrupt_val.get("text", ""),
                options=interrupt_val.get("options") or [],
                is_selectable=interrupt_val.get("is_selectable") or False,
            )

        # Follow-up out-of-scope interrupt
        if interrupt_type == "follow_up_out_of_scope":
            return FollowUpOutOfScopeEvent(
                thread_id=thread_id,
                workflow_name=self._name,
                reason=interrupt_val.get("reason", ""),
                user_message=interrupt_val.get("user_message", ""),
            )

        # User input interrupt
        if isinstance(interrupt_val, dict) and "text" in interrupt_val:
            prompt = interrupt_val["text"]
            options = interrupt_val.get("options", [])
            is_selectable = interrupt_val.get("is_selectable", False)
        else:
            prompt = str(interrupt_val) if interrupt_val else ""
            options = []
            is_selectable = False

        node_id = final_state.next[0] if final_state.next else None
        field_details = self._engine.build_field_details(
            final_state.values, node_id=node_id
        )

        return InterruptEvent(
            prompt=prompt,
            options=options,
            is_selectable=is_selectable,
            field_details=field_details,
        )

    def _build_complete(
        self, final_state: Any, thread_id: str
    ) -> CompleteEvent | RedirectEvent:
        outcome = self._engine.get_outcome_message(final_state.values)

        if outcome.message.startswith(OutcomePrefix.REDIRECT):
            parts = outcome.message.split("|", 4)
            # Format: __REDIRECT__|thread_id|workflow_name|redirect_to|message
            return RedirectEvent(
                message=parts[4] if len(parts) > 4 else "",
                redirect_to=parts[3] if len(parts) > 3 else "",
                thread_id=parts[1] if len(parts) > 1 else thread_id,
                workflow_name=parts[2] if len(parts) > 2 else self._name,
                options=outcome.options or [],
                is_selectable=outcome.is_selectable,
            )

        return CompleteEvent(
            message=outcome.message,
            options=outcome.options or [],
            is_selectable=outcome.is_selectable,
        )

    def _filter_already_collected_fields(
        self,
        current_state: Dict[str, Any],
        initial_context: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        return self._engine.filter_initial_context(initial_context)

    @staticmethod
    def _thread_config(thread_id: str) -> dict:
        return {"configurable": {"thread_id": thread_id}}


def _serialize(obj: Any) -> Any:
    """Best-effort JSON-safe serialization of arbitrary state values."""
    if isinstance(obj, dict):
        return {k: _serialize(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_serialize(v) for v in obj]
    if isinstance(obj, (str, int, float, bool, type(None))):
        return obj
    return str(obj)
