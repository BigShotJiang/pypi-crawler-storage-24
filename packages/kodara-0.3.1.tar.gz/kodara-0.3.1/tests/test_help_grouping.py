"""Tests for kodara --help output section grouping (KodaraGroup)."""

from click.testing import CliRunner
from kodara.cli.main import main


def _help_output():
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    return result.output


def test_free_section_present():
    assert "FREE" in _help_output()


def test_pro_section_present():
    assert "PRO" in _help_output()


def test_free_section_label():
    assert "FREE — up to 200 files" in _help_output()


def test_pro_section_label():
    assert "PRO — $19/month" in _help_output()


def test_init_in_free_section():
    output = _help_output()
    free_start = output.index("FREE")
    pro_start = output.index("PRO")
    free_block = output[free_start:pro_start]
    assert "init" in free_block


def test_ask_in_free_section():
    output = _help_output()
    free_start = output.index("FREE")
    pro_start = output.index("PRO")
    free_block = output[free_start:pro_start]
    assert "ask" in free_block


def test_impact_in_pro_section():
    output = _help_output()
    pro_start = output.index("PRO")
    team_start = output.index("TEAM")
    pro_block = output[pro_start:team_start]
    assert "impact" in pro_block


def test_mcp_in_pro_section():
    output = _help_output()
    pro_start = output.index("PRO")
    team_start = output.index("TEAM")
    pro_block = output[pro_start:team_start]
    assert "mcp" in pro_block


def test_drift_in_pro_section():
    output = _help_output()
    pro_start = output.index("PRO")
    team_start = output.index("TEAM")
    pro_block = output[pro_start:team_start]
    assert "drift" in pro_block


def test_clone_pattern_in_pro_section():
    output = _help_output()
    pro_start = output.index("PRO")
    team_start = output.index("TEAM")
    pro_block = output[pro_start:team_start]
    assert "clone-pattern" in pro_block


def test_onboard_in_team_section():
    output = _help_output()
    team_start = output.index("TEAM")
    enterprise_start = output.index("ENTERPRISE")
    team_block = output[team_start:enterprise_start]
    assert "onboard" in team_block


def test_bus_factor_in_team_section():
    output = _help_output()
    team_start = output.index("TEAM")
    enterprise_start = output.index("ENTERPRISE")
    team_block = output[team_start:enterprise_start]
    assert "bus-factor" in team_block


def test_debt_in_team_section():
    output = _help_output()
    team_start = output.index("TEAM")
    enterprise_start = output.index("ENTERPRISE")
    team_block = output[team_start:enterprise_start]
    assert "debt" in team_block


def test_arch_init_in_team_section():
    output = _help_output()
    team_start = output.index("TEAM")
    enterprise_start = output.index("ENTERPRISE")
    team_block = output[team_start:enterprise_start]
    assert "arch-init" in team_block


def test_ci_check_in_enterprise_section():
    output = _help_output()
    enterprise_start = output.index("ENTERPRISE")
    enterprise_block = output[enterprise_start:]
    assert "ci-check" in enterprise_block


def test_init_ci_in_enterprise_section():
    output = _help_output()
    enterprise_start = output.index("ENTERPRISE")
    enterprise_block = output[enterprise_start:]
    assert "init-ci" in enterprise_block


def test_scan_in_pro_section():
    output = _help_output()
    pro_start = output.index("PRO")
    team_start = output.index("TEAM")
    pro_block = output[pro_start:team_start]
    assert "scan" in pro_block


def test_dna_in_pro_section():
    output = _help_output()
    pro_start = output.index("PRO")
    team_start = output.index("TEAM")
    pro_block = output[pro_start:team_start]
    assert "dna" in pro_block


def test_why_in_pro_section():
    output = _help_output()
    pro_start = output.index("PRO")
    team_start = output.index("TEAM")
    pro_block = output[pro_start:team_start]
    assert "why" in pro_block


def test_team_section_label():
    assert "TEAM — $25/user" in _help_output()


def test_enterprise_section_label():
    assert "ENTERPRISE" in _help_output()


def test_free_appears_before_pro():
    output = _help_output()
    assert output.index("FREE") < output.index("PRO")


def test_pro_appears_before_team():
    output = _help_output()
    assert output.index("PRO") < output.index("TEAM")


def test_team_appears_before_enterprise():
    output = _help_output()
    assert output.index("TEAM") < output.index("ENTERPRISE")


def test_version_is_0_2_5():
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert "0.2.5" in result.output
