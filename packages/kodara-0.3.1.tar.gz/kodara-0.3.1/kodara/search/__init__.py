"""Semantic search subsystem — enhanced query scoring with stemming and IDF."""
