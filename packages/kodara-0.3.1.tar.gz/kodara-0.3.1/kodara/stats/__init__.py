"""Token savings tracker — records usage and calculates money saved."""
