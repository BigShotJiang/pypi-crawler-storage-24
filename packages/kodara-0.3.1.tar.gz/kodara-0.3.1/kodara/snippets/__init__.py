"""Code snippet extractor — reads relevant parts of source files."""
