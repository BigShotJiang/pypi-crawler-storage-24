"""Diff analyzer — impact analysis across changed files (PR/branch/staged)."""
