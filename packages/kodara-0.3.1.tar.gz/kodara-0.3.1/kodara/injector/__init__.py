"""Auto-context injector — generates files that AI tools read automatically."""
