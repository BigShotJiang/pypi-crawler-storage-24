"""
CI Generator — creates GitHub Actions workflow for Kodara architecture checks.
"""
from __future__ import annotations

from pathlib import Path

WORKFLOW_CONTENT: str = """\
name: Kodara Architecture Check

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  architecture:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install Kodara
        run: pip install kodara

      - name: Index project
        run: kodara init --no-summaries

      - name: Architecture check
        run: kodara ci-check
"""


def generate_workflow(root: Path) -> Path:
    """Create .github/workflows/kodara.yml in the project root.

    Creates .github/workflows/ directory if it doesn't exist.
    Returns path to created file.
    Raises FileExistsError if file already exists (caller handles).
    """
    workflows_dir = root / ".github" / "workflows"
    target = workflows_dir / "kodara.yml"

    if target.exists():
        raise FileExistsError(str(target))

    workflows_dir.mkdir(parents=True, exist_ok=True)
    target.write_text(WORKFLOW_CONTENT, encoding="utf-8")
    return target


def workflow_exists(root: Path) -> bool:
    """Check if .github/workflows/kodara.yml already exists."""
    return (root / ".github" / "workflows" / "kodara.yml").exists()
