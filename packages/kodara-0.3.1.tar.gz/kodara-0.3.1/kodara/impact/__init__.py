"""Impact analysis — what breaks if you change a file."""
