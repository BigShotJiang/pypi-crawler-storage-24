"""Snapshots — periodic captures of project memory state."""
