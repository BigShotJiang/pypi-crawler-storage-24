"""Git memory subsystem — extracts history, blame, and evolution data."""
