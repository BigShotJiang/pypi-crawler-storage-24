"""Developer annotations — the human WHY layer on top of code structure."""
