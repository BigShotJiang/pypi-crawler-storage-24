"""Onboarding guide — where to start in an unfamiliar project."""
