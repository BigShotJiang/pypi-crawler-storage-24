"""File and content hashing utilities."""

import hashlib
from pathlib import Path


def hash_file(path: str | Path) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_content(content: str) -> str:
    """Compute SHA-256 hash of string content."""
    return hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()


def short_hash(value: str, length: int = 8) -> str:
    """Return a short hex hash of a string."""
    return hashlib.sha256(value.encode()).hexdigest()[:length]
