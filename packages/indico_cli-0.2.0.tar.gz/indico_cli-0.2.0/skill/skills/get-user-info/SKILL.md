---
name: get-user-info
description: Get the currently authenticated Indico user's information (name, email, ID, admin status). Use when the user wants to check their Indico identity, verify authentication is working, or see who they are logged in as. Triggers on keywords like "who am I", "user info", "check authentication", "my Indico account", "am I logged in".
allowed-tools: Bash
---

# Get Indico User Info

Retrieve information about the currently authenticated user (name, email, user ID, admin status).

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli user-info
```

## Parameters

None required. Uses the configured authentication token.

## Examples

```bash
uvx indico-cli user-info
```

With explicit credentials:
```bash
uvx indico-cli --base-url https://indico.cern.ch --token indp_xxx user-info
```
