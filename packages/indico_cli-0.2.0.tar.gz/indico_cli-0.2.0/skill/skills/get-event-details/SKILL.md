---
name: get-event-details
description: Get detailed information about a specific Indico event including title, dates, location, description, and optionally contributions and sessions. Use when the user wants details about a specific event, needs event metadata, wants to see what's in an event, or asks "tell me about event X". Triggers on keywords like "event details", "event info", "what is event", "describe event", "event summary".
allowed-tools: Bash
---

# Get Indico Event Details

Retrieve full details about a specific Indico event, optionally including its contributions and sessions.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli event-details --event-id <ID> [--contributions] [--sessions]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | The Indico event ID |
| `--contributions` | No | Flag to include contributions/talks |
| `--sessions` | No | Flag to include session details |

## Examples

Basic event info:
```bash
uvx indico-cli event-details --event-id 137346
```

Event with contributions and sessions:
```bash
uvx indico-cli event-details --event-id 137346 --contributions --sessions
```
