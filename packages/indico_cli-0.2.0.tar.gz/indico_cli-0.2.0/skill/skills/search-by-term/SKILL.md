---
name: search-by-term
description: Full-text search across all Indico content types (events, contributions, categories, attachments, notes) by keyword. Use when the user wants to find something in Indico by name or keyword, search for a topic across events and contributions, or find presentations/attachments matching a term. Triggers on keywords like "search Indico", "find in Indico", "search for", "look up", "find presentations about".
allowed-tools: Bash
---

# Search Indico by Keyword

Perform a comprehensive search across all Indico content types: categories, events, contributions, subcontributions, attachments, and event notes.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli search-by-term --term "<search query>" [--limit N]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--term` | Yes | The search keyword or phrase |
| `--limit` | No | Maximum results per content type (default: 50) |

## Examples

Search for "beam dynamics":
```bash
uvx indico-cli search-by-term --term "beam dynamics"
```

Quick search with limited results:
```bash
uvx indico-cli search-by-term --term "machine learning" --limit 5
```
