---
name: create-session
description: Create a session within an existing Indico event. Use when the user wants to add a session to an event, organize an event into sessions, or structure an agenda with session blocks. Requires event management permissions. Triggers on keywords like "create session", "add session", "new session in event".
allowed-tools: Bash
---

# Create Session in Indico Event

Create a session within an existing Indico event. Requires management permissions on the event.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli create-session --event-id <ID> --title "Session Title" [--description TEXT]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | The event ID to add the session to |
| `--title` | Yes | Session title |
| `--description` | No | Session description |

## Examples

```bash
uvx indico-cli create-session --event-id 137346 --title "Morning Session" --description "Talks on beam physics"
```
