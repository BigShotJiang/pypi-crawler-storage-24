---
name: add-timetable-entry
description: Schedule a session or contribution in the Indico event timetable at a specific time. Use when the user wants to schedule an item, add something to the timetable, or set the time for a session block or contribution. Requires event management permissions. Triggers on keywords like "schedule", "add to timetable", "set time for", "timetable entry".
allowed-tools: Bash
---

# Add Timetable Entry

Schedule a session block or contribution in the event timetable at a specific start time. Requires management permissions on the event.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli add-timetable-entry --event-id <ID> --type <session_block|contribution> --object-id <ID> --start <ISO datetime> [--duration N]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | The event ID |
| `--type` | Yes | Entry type: `session_block` or `contribution` |
| `--object-id` | Yes | ID of the session or contribution to schedule |
| `--start` | Yes | Start datetime (ISO format) |
| `--duration` | No | Duration in minutes |

## Examples

Schedule a session block:
```bash
uvx indico-cli add-timetable-entry --event-id 137346 --type session_block --object-id 5 --start 2025-06-15T09:00:00 --duration 120
```

Schedule a contribution:
```bash
uvx indico-cli add-timetable-entry --event-id 137346 --type contribution --object-id 12 --start 2025-06-15T14:00:00 --duration 30
```
