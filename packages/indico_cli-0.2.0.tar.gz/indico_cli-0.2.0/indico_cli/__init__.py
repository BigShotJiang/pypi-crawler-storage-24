"""Indico CLI - Command line interface for Indico event management systems."""

try:
    from indico_cli._version import __version__
except ImportError:
    __version__ = "0.0.0.dev0"
