"""
Utility functions for building Indico API request data.

These functions construct JSON-encoded form data fields used by Indico's
internal frontend endpoints for creating events, sessions, contributions,
and other entities.
"""

import json
from datetime import datetime
from typing import Dict, List, Tuple


def build_person_link_data(
    speakers: List[Dict[str, str]],
    is_speaker: bool = True,
    is_submitter: bool = False,
    author_type: int = 0,
) -> str:
    """Build JSON string for Indico's person_link_data field.

    Args:
        speakers: List of dicts with keys like first_name, last_name,
                  email, affiliation.
        is_speaker: Whether the person is a speaker (default: True).
        is_submitter: Whether the person is a submitter (default: False).
        author_type: Author type code (default: 0).

    Returns:
        JSON string array of person link objects formatted for Indico.
    """
    person_links = []
    for speaker in speakers:
        person_link = {
            "firstName": speaker.get("first_name", ""),
            "lastName": speaker.get("last_name", ""),
            "email": speaker.get("email", ""),
            "affiliation": speaker.get("affiliation", ""),
            "isSubmitter": is_submitter,
            "isSpeaker": is_speaker,
            "authorType": author_type,
        }
        person_links.append(person_link)
    return json.dumps(person_links)


def build_location_data(
    venue: str = "",
    room: str = "",
    address: str = "",
) -> str:
    """Build JSON string for Indico's location_data field.

    Args:
        venue: Venue name (e.g., "CERN").
        room: Room name (e.g., "513/1-024").
        address: Physical address.

    Returns:
        JSON string dict with venue_name, room_name, address.
    """
    location = {
        "venue_name": venue,
        "room_name": room,
        "address": address,
    }
    return json.dumps(location)


def build_occurrence_data(date: str, time: str, duration: int) -> str:
    """Build JSON string for event occurrence data.

    Args:
        date: Date string in "YYYY-MM-DD" format.
        time: Time string in "HH:MM" format.
        duration: Duration in minutes.

    Returns:
        JSON array with a single occurrence dict containing
        date, time, and duration fields.
    """
    occurrence = {
        "date": date,
        "time": time,
        "duration": duration,
    }
    return json.dumps([occurrence])


def build_category_data(category_id: str) -> str:
    """Build JSON string for Indico's category field.

    Args:
        category_id: Category ID as a string.

    Returns:
        JSON string of {"id": int(category_id)}.

    Raises:
        ValueError: If category_id is not a numeric string.
    """
    try:
        return json.dumps({"id": int(category_id)})
    except (ValueError, TypeError):
        raise ValueError(
            f"category_id must be a numeric string, got: {category_id!r}"
        )


def parse_datetime_to_date_time(iso_str: str) -> Tuple[str, str]:
    """Parse an ISO datetime string into separate date and time strings.

    Args:
        iso_str: ISO format datetime string (e.g., "2024-12-25T14:30:00").

    Returns:
        Tuple of (date, time) where date is "YYYY-MM-DD" and time is "HH:MM".
    """
    dt = datetime.fromisoformat(iso_str)
    date_str = dt.strftime("%Y-%m-%d")
    time_str = dt.strftime("%H:%M")
    return date_str, time_str


def compute_duration_minutes(start: str, end: str) -> int:
    """Compute duration in minutes between two ISO datetime strings.

    Args:
        start: Start datetime in ISO format (e.g., "2024-12-25T14:00:00").
        end: End datetime in ISO format (e.g., "2024-12-25T15:30:00").

    Returns:
        Integer number of minutes between start and end.

    Raises:
        ValueError: If end is before start.
    """
    start_dt = datetime.fromisoformat(start)
    end_dt = datetime.fromisoformat(end)
    if end_dt < start_dt:
        raise ValueError(
            f"End time ({end}) must not be before start time ({start})"
        )
    delta = end_dt - start_dt
    return int(delta.total_seconds() / 60)
