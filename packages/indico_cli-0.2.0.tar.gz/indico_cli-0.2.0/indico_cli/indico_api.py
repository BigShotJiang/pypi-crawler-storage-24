#!/usr/bin/env python3
"""
Indico API Client

This module provides a client for interacting with Indico (https://getindico.io/),
an event management system used at CERN and other organizations.

Features:
- Search for events and categories
- Get event details, contributions, and materials
- Download event files and attachments
- Export event data

Based on Indico HTTP API documentation:
https://docs.getindico.io/en/stable/http-api/

Uses modern Bearer token authentication (API tokens starting with 'indp_')
"""

import base64
import json
import logging
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import httpx

from indico_cli.utils import (
    build_person_link_data, build_location_data,
    build_occurrence_data, build_category_data,
    parse_datetime_to_date_time, compute_duration_minutes,
)


class IndicoAPI:
    """Helper class for making authenticated requests to Indico API

    Uses modern Bearer token authentication for all API operations.

    Parameters:
        base_url: Base URL of the Indico instance (e.g., "https://indico.cern.ch")
        bearer_token: Bearer token for API authentication (optional for public data)

    Usage:
        # For authenticated access
        api = IndicoAPI("https://indico.cern.ch", bearer_token="indp_...")

        # For public data only (no authentication)
        api = IndicoAPI("https://indico.cern.ch")
    """

    def __init__(
        self,
        base_url: str,
        bearer_token: Optional[str] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.bearer_token = bearer_token
        self.client = httpx.AsyncClient(timeout=30.0)

        # Set up Bearer token headers (no Content-Type for GET requests;
        # Indico returns 403 if Content-Type: application/json is sent on file downloads)
        if bearer_token:
            self.headers = {
                "Authorization": f"Bearer {bearer_token}",
                "User-Agent": "Indico-CLI/1.0",
            }
        else:
            # Fallback headers without authentication (for public data)
            self.headers = {
                "Content-Type": "application/json",
                "User-Agent": "Indico-CLI/1.0",
            }


    async def get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        only_public: bool = False,
    ) -> Dict[str, Any]:
        """Make GET request to Indico API"""
        url_params = params.copy() if params else {}

        if only_public:
            url_params["onlypublic"] = "yes"

        url = f"{self.base_url}{path}"
        if url_params:
            url += f"?{urlencode(url_params)}"

        try:
            response = await self.client.get(url, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            raise Exception(f"Indico API request failed: {e}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse Indico API response: {e}")

    async def get_binary(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        only_public: bool = False,
    ) -> httpx.Response:
        """Make GET request to Indico API for binary content (files, attachments)"""
        url_params = params.copy() if params else {}

        if only_public:
            url_params["onlypublic"] = "yes"

        url = f"{self.base_url}{path}"
        if url_params:
            url += f"?{urlencode(url_params)}"

        try:
            response = await self.client.get(url, headers=self.headers, follow_redirects=True)
            response.raise_for_status()
            return response
        except httpx.HTTPError as e:
            raise Exception(f"Indico API binary request failed: {e}")

    async def post(self, path: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Make POST request to Indico API"""
        try:
            url = f"{self.base_url}{path}"

            # Use JSON for API endpoints, form data otherwise
            if path.startswith("/api/"):
                response = await self.client.post(
                    url, json=data, headers=self.headers
                )
            else:
                response = await self.client.post(
                    url, data=data, headers=self.headers
                )

            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            raise Exception(f"Indico API POST request failed: {e}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse Indico API response: {e}")

    def _build_internal_headers(self, include_content_type: bool = True) -> Dict[str, str]:
        """Build headers for internal Indico endpoints."""
        headers = {
            **self.headers,
            "X-Requested-With": "XMLHttpRequest",
        }
        if not include_content_type:
            headers.pop("Content-Type", None)
        return headers

    def _check_indico_error(self, result: Any) -> None:
        """Raise if Indico returned an application-level error."""
        if isinstance(result, dict) and "error" in result:
            error_info = result["error"]
            if isinstance(error_info, dict) and "message" in error_info:
                raise Exception(f"Indico error: {error_info['message']}")
            raise Exception(f"Indico error: {error_info}")

    async def post_internal(
        self, path: str, data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """POST to Indico internal frontend endpoints.

        Uses form-encoded data with X-Requested-With header, which is
        required by Indico's internal endpoints that lack a public REST API
        for write operations.

        Args:
            path: Endpoint path (e.g., "/event/123/manage/contributions/create").
            data: Form data to send (will be form-encoded, not JSON).

        Returns:
            Parsed JSON response dict.
        """
        try:
            url = f"{self.base_url}{path}"
            response = await self.client.post(
                url, data=data,
                headers=self._build_internal_headers(include_content_type=False),
            )
            response.raise_for_status()
            result = response.json()
            self._check_indico_error(result)
            return result
        except httpx.HTTPError as e:
            raise Exception(
                f"Indico internal POST request failed: {e}"
            )
        except json.JSONDecodeError as e:
            raise Exception(
                f"Failed to parse Indico internal response: {e}"
            )

    async def delete_internal(self, path: str) -> Dict[str, Any]:
        """DELETE for Indico internal endpoints (e.g., timetable deletion).

        Uses X-Requested-With header with Bearer token authentication.

        Args:
            path: Endpoint path (e.g., "/event/123/manage/timetable/entry/5").

        Returns:
            Parsed JSON response dict.
        """
        try:
            url = f"{self.base_url}{path}"
            response = await self.client.delete(
                url, headers=self._build_internal_headers(),
            )
            response.raise_for_status()
            result = response.json()
            self._check_indico_error(result)
            return result
        except httpx.HTTPError as e:
            raise Exception(
                f"Indico internal DELETE request failed: {e}"
            )
        except json.JSONDecodeError as e:
            raise Exception(
                f"Failed to parse Indico internal response: {e}"
            )


class IndicoClient:
    """High-level client for Indico operations"""

    def __init__(self, api: IndicoAPI):
        self.api = api

    def _extract_file_content(
        self, content: bytes, content_type: str, filename: str
    ) -> Optional[str]:
        """Extract readable content from downloaded files"""
        try:
            # Determine file type from content type and filename
            filename_lower = filename.lower()

            # Text files
            if content_type.startswith("text/") or filename_lower.endswith(
                (
                    ".txt",
                    ".md",
                    ".rst",
                    ".py",
                    ".js",
                    ".html",
                    ".css",
                    ".json",
                    ".xml",
                    ".csv",
                )
            ):
                try:
                    return content.decode("utf-8")
                except UnicodeDecodeError:
                    try:
                        return content.decode("latin1")
                    except UnicodeDecodeError:
                        return "[Text file - encoding not supported]"

            # PDF files (basic extraction)
            elif content_type == "application/pdf" or filename_lower.endswith(
                ".pdf"
            ):
                # For now, just indicate it's a PDF - full PDF parsing would require additional libraries
                return f"[PDF file - {len(content)} bytes. Use a PDF reader to view content.]"

            # Images
            elif content_type.startswith("image/") or filename_lower.endswith(
                (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg")
            ):
                return f"[Image file - {content_type}, {len(content)} bytes]"

            # Office documents
            elif content_type in [
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ] or filename_lower.endswith(
                (".docx", ".xlsx", ".pptx", ".doc", ".xls", ".ppt")
            ):
                return (
                    f"[Office document - {content_type}, {len(content)} bytes]"
                )

            # Small binary files - provide base64 for very small files
            elif len(content) < 1024:  # Less than 1KB
                b64_content = base64.b64encode(content).decode("utf-8")
                return f"[Small binary file - base64 encoded]\n{b64_content}"

            else:
                return f"[Binary file - {content_type}, {len(content)} bytes]"

        except Exception as e:
            return f"[Error extracting content: {str(e)}]"

    async def get_user_info(self) -> str:
        """Get current user information"""
        result = await self.api.get("/api/user/")

        response = "Current User Information:\n\n"
        response += f"Name: {result.get('first_name', '')} {result.get('last_name', '')}\n"
        response += f"Email: {result.get('email', 'N/A')}\n"
        response += f"User ID: {result.get('id', 'N/A')}\n"
        response += f"Admin: {'Yes' if result.get('admin', False) else 'No'}\n"

        return response

    async def search_events(
        self,
        category_id: str,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        limit: Optional[int] = None,
        only_public: bool = False,
    ) -> str:
        """Search for events in Indico categories"""
        params = {"pretty": "yes"}

        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        if limit:
            params["limit"] = str(limit)

        result = await self.api.get(
            f"/export/categ/{category_id}.json", params, only_public
        )

        events = result.get("results", [])
        count = result.get("count", 0)

        response = f"Found {count} events in category {category_id}:\n\n"
        for event in events[:10]:  # Limit display to first 10
            event_id = event.get("id", "N/A")
            title = event.get("title", "No title")
            start_date = event.get("startDate", {}).get("date", "N/A")
            location = event.get("location", "No location")
            url = event.get("url", "")
            response += f"- {title} (ID: {event_id})\n"
            response += f"  Date: {start_date}, Location: {location}\n"
            if url:
                response += f"  URL: {url}\n"
            response += "\n"

        if count > 10:
            response += f"... and {count - 10} more events\n"

        return response

    async def search_events_by_term(
        self, search_term: str, limit: int = 50
    ) -> str:
        """Search for content by keyword/term using comprehensive Indico search API"""
        try:
            # URL-encode the search term to handle special characters
            # Define all search types to query
            search_types = [
                ("category", "Categories"),
                ("event", "Events"),
                ("contribution", "Contributions"),
                ("subcontribution", "Subcontributions"),
                ("attachment", "Attachments"),
                ("event_note", "Event Notes")
            ]

            all_results = {}
            total_found = 0

            # Search across all content types
            for search_type, display_name in search_types:
                try:
                    params = {"q": search_term, "type": search_type}
                    if limit:
                        params["limit"] = str(limit)

                    # Use the new search API endpoint
                    result = await self.api.get(f"/search/api/search", params)

                    # Handle both direct results and nested results format
                    if isinstance(result, dict):
                        results = result.get("results", result.get("hits", []))
                    else:
                        results = result if isinstance(result, list) else []

                    if results:
                        all_results[search_type] = {
                            "display_name": display_name,
                            "results": results[:limit] if limit else results,
                            "count": len(results)
                        }
                        total_found += len(results)

                except Exception as e:
                    # Continue with other search types if one fails
                    logging.warning(f"{search_type} search failed: {e}")
                    continue

            # Build comprehensive response
            response = f"Comprehensive search results for '{search_term}':\n"
            response += f"Total items found across all content types: {total_found}\n\n"

            if total_found == 0:
                response += "No results found. Try:\n"
                response += "- Using more general search terms\n"
                response += "- Checking spelling and trying synonyms\n"
                response += "- Searching in specific categories with search_events\n"
                response += "- Using broader keywords\n"
                return response

            # Display results by category
            for search_type, data in all_results.items():
                display_name = data["display_name"]
                results = data["results"]
                count = data["count"]

                response += f"{display_name} ({count} found):\n"

                # Display first few results of each type
                display_limit = min(5, len(results))
                for i, result in enumerate(results[:display_limit], 1):
                    response += self._format_search_result(result, search_type, i)

                if count > display_limit:
                    response += f"   ... and {count - display_limit} more {display_name.lower()}\n"
                response += "\n"

            # Add helpful suggestions for next steps
            response += "Next steps:\n"
            response += "- Use get_event_details(event_id) for detailed event information\n"
            response += "- Use get_event_contributions(event_id) to see event contributions\n"
            response += "- Use get_files(event_id) to download event materials\n"

            return response

        except Exception as e:
            return (
                f"Error searching content: {str(e)}\n\n"
                "Possible issues:\n"
                "- Search API endpoint may not be available on this Indico instance\n"
                "- Insufficient permissions to search content\n"
                "- Search term may contain invalid characters\n"
                "- Network connectivity issues\n"
                "- Try searching within specific categories using search_events\n"
                "- Consider using get_event_details if you know the event ID"
            )

    def _format_search_result(self, result: dict, search_type: str, index: int) -> str:
        """Format a single search result based on its type"""
        formatted = f"   {index}. "

        if search_type == "event":
            title = result.get("title", "No title")
            event_id = result.get("id", result.get("event_id", "N/A"))
            date = result.get("start_date", result.get("startDate", "N/A"))
            location = result.get("location", "N/A")

            formatted += f"{title} (ID: {event_id})\n"
            formatted += f"      Date: {date}, Location: {location}\n"
            if result.get("url"):
                formatted += f"      URL: {result['url']}\n"

        elif search_type == "category":
            title = result.get("title", result.get("name", "No title"))
            cat_id = result.get("id", result.get("category_id", "N/A"))

            formatted += f"{title} (ID: {cat_id})\n"
            if result.get("description"):
                desc = result["description"][:100] + "..." if len(result["description"]) > 100 else result["description"]
                formatted += f"      Description: {desc}\n"

        elif search_type in ["contribution", "subcontribution"]:
            title = result.get("title", "No title")
            contrib_id = result.get("id", "N/A")
            event_title = result.get("event_title", result.get("event", {}).get("title", ""))

            formatted += f"{title} (ID: {contrib_id})\n"
            if event_title:
                formatted += f"      Event: {event_title}\n"
            if result.get("speakers"):
                speakers = [s.get("name", f"{s.get('first_name', '')} {s.get('last_name', '')}").strip()
                          for s in result["speakers"][:2]]
                speakers_str = ", ".join(filter(None, speakers))
                if speakers_str:
                    formatted += f"      Speakers: {speakers_str}\n"

        elif search_type == "attachment":
            filename = result.get("filename", result.get("title", "No filename"))
            file_id = result.get("id", "N/A")
            event_title = result.get("event_title", "")

            formatted += f"{filename} (ID: {file_id})\n"
            if event_title:
                formatted += f"      Event: {event_title}\n"
            if result.get("content_type"):
                formatted += f"      Type: {result['content_type']}\n"

        elif search_type == "event_note":
            title = result.get("title", "Note")
            note_id = result.get("id", "N/A")
            event_title = result.get("event_title", "")

            formatted += f"{title} (ID: {note_id})\n"
            if event_title:
                formatted += f"      Event: {event_title}\n"
            if result.get("html"):
                content = result["html"][:100] + "..." if len(result["html"]) > 100 else result["html"]
                # Strip HTML tags for display
                clean_content = re.sub(r'<[^>]+>', '', content)
                formatted += f"      Content: {clean_content}\n"
        else:
            # Generic formatting for unknown types
            title = result.get("title", result.get("name", "Unknown"))
            item_id = result.get("id", "N/A")
            formatted += f"{title} (ID: {item_id})\n"

        return formatted


    async def get_event_details(
        self,
        event_id: str,
        include_contributions: bool = False,
        include_sessions: bool = False,
    ) -> str:
        """Get detailed information about a specific event"""
        params = {"pretty": "yes"}

        # Set detail level based on what user requested
        if include_contributions:
            params["detail"] = "contributions"
        elif include_sessions:
            params["detail"] = "sessions"
        # Default to basic event details if nothing specified

        result = await self.api.get(f"/export/event/{event_id}.json", params)

        event = result.get("results", [{}])[0] if result.get("results") else {}

        if not event:
            return (
                f"Event {event_id} not found or not accessible\n\n"
                "Possible issues:\n"
                "- Invalid event ID\n"
                "- Event is private and you don't have access\n"
                "- Event may be in a restricted category"
            )

        response = f"Event Details for ID {event_id}:\n\n"
        response += f"Title: {event.get('title', 'N/A')}\n"
        response += f"Type: {event.get('type', 'N/A')}\n"
        response += f"Category: {event.get('category', 'N/A')}\n"

        # Handle both dict and string date formats
        start_date = event.get("startDate", {})
        if isinstance(start_date, dict):
            start_str = f"{start_date.get('date', 'N/A')} {start_date.get('time', '')}".strip()
        else:
            start_str = str(start_date) if start_date else "N/A"

        end_date = event.get("endDate", {})
        if isinstance(end_date, dict):
            end_str = f"{end_date.get('date', 'N/A')} {end_date.get('time', '')}".strip()
        else:
            end_str = str(end_date) if end_date else "N/A"

        response += f"Start: {start_str}\n"
        response += f"End: {end_str}\n"
        response += f"Location: {event.get('location', 'N/A')}\n"
        response += f"Room: {event.get('room', 'N/A')}\n"
        response += f"Timezone: {event.get('timezone', 'N/A')}\n"

        description = event.get("description", "")
        if description:
            # Truncate very long descriptions
            desc_preview = (
                description[:300] + "..."
                if len(description) > 300
                else description
            )
            response += f"Description: {desc_preview}\n"
        else:
            response += "Description: N/A\n"

        response += f"URL: {event.get('url', 'N/A')}\n"

        # Add material information if available
        if "material" in event and event["material"]:
            response += f"\nMaterials ({len(event['material'])}):\n"
            for material in event["material"][:3]:  # Show first 3
                mat_title = material.get("title", "Unknown")
                mat_id = material.get("id", "N/A")
                resource_count = len(material.get("resources", []))
                response += (
                    f"- {mat_title} (ID: {mat_id}) - {resource_count} files\n"
                )
            if len(event["material"]) > 3:
                response += (
                    f"... and {len(event['material']) - 3} more materials\n"
                )

        # Enhanced contributions display
        if "contributions" in event and event["contributions"]:
            contribs = event["contributions"]
            response += f"\nContributions ({len(contribs)}):\n"
            for i, contrib in enumerate(contribs[:5], 1):  # Show first 5
                title = contrib.get("title", "No title")
                contrib_id = contrib.get("id", "N/A")
                speakers = contrib.get("speakers", [])
                duration = contrib.get("duration", "")

                response += f"{i}. {title} (ID: {contrib_id})\n"

                if speakers:
                    speaker_names = []
                    for speaker in speakers[:2]:  # Limit to first 2 speakers
                        if isinstance(speaker, dict):
                            name_parts = []
                            if speaker.get("first_name"):
                                name_parts.append(speaker["first_name"])
                            if speaker.get("last_name"):
                                name_parts.append(speaker["last_name"])
                            if name_parts:
                                speaker_names.append(" ".join(name_parts))
                    if speaker_names:
                        response += f"   Speakers: {', '.join(speaker_names)}"
                        if len(speakers) > 2:
                            response += f" (+{len(speakers) - 2} more)"
                        response += "\n"

                if duration:
                    response += f"   Duration: {duration}\n"

                response += "\n"

            if len(contribs) > 5:
                response += f"... and {len(contribs) - 5} more contributions\n"
            response += "\nUse get_event_contributions for detailed contribution information.\n"

        # Enhanced sessions display
        if "sessions" in event and event["sessions"]:
            sessions = event["sessions"]
            response += f"\nSessions ({len(sessions)}):\n"
            for i, session in enumerate(sessions[:5], 1):  # Show first 5
                title = session.get("title", "No title")
                session_id = session.get("id", "N/A")
                session_contribs = session.get("contributions", [])

                response += f"{i}. {title} (ID: {session_id})\n"
                if session_contribs:
                    response += (
                        f"   Contains {len(session_contribs)} contributions\n"
                    )
                response += "\n"

            if len(sessions) > 5:
                response += f"... and {len(sessions) - 5} more sessions\n"

        return response




    async def search_categories(
        self, category_id: str = "0", limit: Optional[int] = None
    ) -> str:
        """Search for event categories"""
        params = {"pretty": "yes"}

        if limit:
            params["limit"] = str(limit)

        result = await self.api.get(
            f"/export/categ/{category_id}.json", params
        )

        # This returns events in the category
        items = result.get("results", [])

        response = f"Category {category_id} contents:\n\n"
        response += f"Found {len(items)} items\n\n"

        for item in items[:10]:
            title = item.get("title", "No title")
            item_type = item.get("type", "event")
            item_id = item.get("id", "N/A")
            response += f"- {title} (ID: {item_id}, Type: {item_type})\n"

        if len(items) > 10:
            response += f"... and {len(items) - 10} more items\n"

        response += (
            "\nNote: This endpoint returns events within the category. "
        )
        response += "For subcategory browsing, use the web interface."

        return response

    async def get_event_contributions(
        self,
        event_id: str,
        include_subcontributions: bool = False,
        limit: Optional[int] = None,
    ) -> str:
        """Get contributions for a specific event"""
        params = {"pretty": "yes"}

        # Set detail level based on subcontributions preference
        # According to API docs: contributions, subcontributions, or sessions
        if include_subcontributions:
            params["detail"] = "subcontributions"
        else:
            params["detail"] = "contributions"

        try:
            result = await self.api.get(
                f"/export/event/{event_id}.json", params
            )

            event = (
                result.get("results", [{}])[0] if result.get("results") else {}
            )
            contributions = event.get("contributions", [])

            if not contributions:
                return f"No contributions found for event {event_id} ({event.get('title', 'Unknown Event')})"

            # Apply limit if specified
            display_contributions = (
                contributions[:limit] if limit else contributions
            )

            response = f"Contributions for event {event_id} ({event.get('title', 'Unknown Event')}):\n"
            response += f"Found {len(contributions)} contributions total\n\n"

            for i, contrib in enumerate(display_contributions, 1):
                contrib_id = contrib.get("id", "N/A")
                title = contrib.get("title", "No title")
                description = contrib.get("description", "")
                speakers = contrib.get("speakers", [])
                start_date = contrib.get("startDate", {})
                duration = contrib.get("duration", "")
                track = contrib.get("track", "")
                session = contrib.get("session", "")

                response += f"{i}. {title} (ID: {contrib_id})\n"

                # Show speakers
                if speakers:
                    speaker_names = []
                    for speaker in speakers[:3]:  # Limit to first 3 speakers
                        if isinstance(speaker, dict):
                            name_parts = []
                            if speaker.get("first_name"):
                                name_parts.append(speaker["first_name"])
                            if speaker.get("last_name"):
                                name_parts.append(speaker["last_name"])
                            if name_parts:
                                speaker_names.append(" ".join(name_parts))
                    if speaker_names:
                        response += f"   Speakers: {', '.join(speaker_names)}"
                        if len(speakers) > 3:
                            response += f" (+{len(speakers) - 3} more)"
                        response += "\n"

                # Show other details
                if isinstance(start_date, dict):
                    date_str = f"{start_date.get('date', 'N/A')} {start_date.get('time', '')}".strip()
                    if date_str != "N/A":
                        response += f"   Time: {date_str}\n"

                if duration:
                    response += f"   Duration: {duration}\n"

                if track:
                    response += f"   Track: {track}\n"

                if session:
                    response += f"   Session: {session}\n"

                if description:
                    # Truncate long descriptions
                    desc_preview = (
                        description[:150] + "..."
                        if len(description) > 150
                        else description
                    )
                    response += f"   Description: {desc_preview}\n"

                # Show subcontributions if available and requested
                if include_subcontributions and contrib.get(
                    "subcontributions"
                ):
                    subcontribs = contrib["subcontributions"]
                    response += f"   Subcontributions ({len(subcontribs)}):\n"
                    for j, subcontrib in enumerate(
                        subcontribs[:3], 1
                    ):  # Show first 3
                        sub_title = subcontrib.get("title", "No title")
                        response += f"     {j}. {sub_title}\n"
                    if len(subcontribs) > 3:
                        response += (
                            f"     ... and {len(subcontribs) - 3} more\n"
                        )

                response += "\n"

            if limit and len(contributions) > limit:
                response += f"... and {len(contributions) - limit} more contributions (use limit parameter to see more)\n"

            response += f"\nTotal contributions: {len(contributions)}\n"
            if include_subcontributions:
                response += (
                    "Note: Subcontributions are included where available.\n"
                )
            else:
                response += "Use include_subcontributions=true to see nested subcontributions.\n"

            return response

        except Exception as e:
            return (
                f"Error retrieving contributions: {str(e)}\n\n"
                "Possible issues:\n"
                "- Invalid event ID\n"
                "- Event is private and you don't have access\n"
                "- Event may not have contributions\n"
                "- API endpoint may not be available"
            )

    async def download_file_with_auth(self, file_info: Dict[str, Any], event_id: str) -> Optional[httpx.Response]:
        """Try multiple download paths to retrieve a file"""
        download_methods = []

        # Method 1: Use download_url if available
        if file_info.get("download_url"):
            url = file_info["download_url"]
            if url.startswith(self.api.base_url):
                path = url[len(self.api.base_url):]
            else:
                path = url
            download_methods.append(("download_url", path))

        # Method 2: API paths from file metadata
        download_methods.extend([
            ("modern_api", file_info.get("api_path", "")),
            ("legacy_export", file_info.get("legacy_path", "")),
        ])

        # Method 3: Alternative path constructions
        alt_paths = [
            f"/event/{event_id}/contributions/{file_info.get('contrib_id', '')}/attachments/{file_info.get('attachment_id', '')}/download",
            f"/api/events/{event_id}/contributions/{file_info.get('contrib_id', '')}/materials/{file_info.get('folder_id', '')}/{file_info.get('attachment_id', '')}",
            f"/event/{event_id}/material/{file_info.get('folder_id', '')}/{file_info.get('attachment_id', '')}",
            f"/event/{file_info.get('contrib_id', '')}/material/{file_info.get('folder_id', '')}/{file_info.get('attachment_id', '')}"
        ]
        download_methods.extend([(f"alternative_{i}", path) for i, path in enumerate(alt_paths)])

        for _method, path in download_methods:
            if not path:
                continue

            try:
                response = await self.api.get_binary(path)
                if response.status_code < 400:
                    return response
            except Exception:
                # Try next method
                continue

        return None

    async def get_files(
        self,
        event_id: str,
        download_files: bool = True,
        download_dir: Optional[str] = None,
        include_content: bool = True,
    ) -> str:
        """Get all files for an event and optionally download them

        Note: File downloads require both API token and API secret.
        Event listing works with just API token, but file export API requires both.

        Args:
            event_id: The ID of the event
            download_files: Whether to actually download the files (default: True)
            download_dir: Custom directory to save files (default: downloads/{event_id}/)
            include_content: Whether to include file content in the response (default: True)
        """
        try:
            # Get event details with materials/attachments
            params = {"pretty": "yes", "detail": "contributions"}
            result = await self.api.get(
                f"/export/event/{event_id}.json", params
            )

            event = (
                result.get("results", [{}])[0] if result.get("results") else {}
            )

            if not event:
                return f"Event {event_id} not found or not accessible"

            # Collect all files from different sources
            files_found = []

            event_title = event.get("title", "Unknown Event")
            response = f"Files for event {event_id} ({event_title}):\n\n"

            # 1. Check event-level materials
            if "material" in event and event["material"]:
                response += f"Event Materials ({len(event['material'])}):\n"
                for material in event["material"]:
                    mat_title = material.get("title", "Unknown")
                    mat_id = material.get("id", "N/A")
                    resources = material.get("resources", [])

                    response += f"- {mat_title} (ID: {mat_id}) - {len(resources)} files\n"

                    for resource in resources:
                        filename = resource.get("name", "unknown_file")
                        resource_id = resource.get("id", "")
                        file_size = resource.get("size", "unknown size")

                        files_found.append(
                            {
                                "filename": filename,
                                "resource_id": resource_id,
                                "material_id": mat_id,
                                "size": file_size,
                                "source": f"Event Material: {mat_title}",
                                "type": "event_material",
                                "api_path": f"/export/event/{event_id}/material/{mat_id}/{resource_id}.bin",
                            }
                        )

                        response += f"    - {filename} ({file_size})\n"
                response += "\n"

            # 2. Check contribution-level materials/attachments
            contributions = event.get("contributions", [])
            if contributions:
                contrib_files_count = 0
                for contrib in contributions:
                    contrib_title = contrib.get(
                        "title", "Unknown Contribution"
                    )
                    contrib_id = contrib.get("id", "")

                    # Check for folders/attachments in contributions
                    folders = contrib.get("folders", [])
                    if folders:
                        for folder in folders:
                            folder_title = folder.get(
                                "title", "Unknown Folder"
                            )
                            folder_id = folder.get("id", "")
                            attachments = folder.get("attachments", [])

                            for attachment in attachments:
                                filename = attachment.get(
                                    "filename",
                                    attachment.get("title", "unknown_file"),
                                )
                                attachment_id = attachment.get("id", "")
                                file_size = attachment.get(
                                    "size", "unknown size"
                                )
                                # Check if attachment has download_url
                                download_url = attachment.get("download_url") or attachment.get("url")

                                files_found.append(
                                    {
                                        "filename": filename,
                                        "attachment_id": attachment_id,
                                        "folder_id": folder_id,
                                        "contrib_id": contrib_id,
                                        "size": file_size,
                                        "source": f"Contribution: {contrib_title} / Folder: {folder_title}",
                                        "type": "contribution_attachment",
                                        "download_url": download_url,
                                        "api_path": f"/event/{event_id}/contributions/{contrib_id}/attachments/{attachment_id}/{filename}",
                                        "legacy_path": f"/export/event/{event_id}/contrib/{contrib_id}/material/{folder_id}/{attachment_id}.bin",
                                    }
                                )

                                contrib_files_count += 1

                if contrib_files_count > 0:
                    response += f"Contribution Attachments: {contrib_files_count} files found\n\n"

            # Summary of all files found
            if files_found:
                response += f"Total files found: {len(files_found)}\n\n"

                # Download files if requested
                if download_files:
                    response += "Downloading files...\n\n"

                    # Check if we have authentication for file downloads
                    if not self.api.bearer_token:
                        response += "File downloads require authentication (Bearer token).\n"
                        response += "Please configure a Bearer token.\n\n"
                        response += "Files found but not downloaded:\n"
                        for i, file_info in enumerate(files_found, 1):
                            response += f"{i}. {file_info['filename']}\n"
                            response += f"   Source: {file_info['source']}\n"
                            response += f"   Size: {file_info['size']}\n"
                            response += (
                                f"   API Path: {file_info['api_path']}\n\n"
                            )
                        return response

                    download_count = 0
                    max_downloads = (
                        10  # Limit downloads to prevent overwhelming
                    )

                    for file_info in files_found[:max_downloads]:
                        try:
                            # Use the new download method with better error handling
                            file_response = await self.download_file_with_auth(file_info, event_id)

                            if not file_response:
                                raise Exception(f"All download methods failed for {file_info['filename']}")

                            # Get file metadata
                            content_type = file_response.headers.get(
                                "content-type", "application/octet-stream"
                            )
                            content_length = file_response.headers.get(
                                "content-length",
                                str(len(file_response.content)),
                            )

                            # Save file to local filesystem
                            if download_dir:
                                save_dir = download_dir
                            else:
                                save_dir = f"downloads/{event_id}"
                            os.makedirs(save_dir, exist_ok=True)

                            # Sanitize filename to prevent path issues
                            safe_filename = "".join(
                                c
                                for c in file_info["filename"]
                                if c.isalnum() or c in (" ", ".", "-", "_")
                            ).rstrip()
                            if not safe_filename:
                                safe_filename = f"file_{file_info.get('resource_id', file_info.get('attachment_id', 'unknown'))}"

                            file_path = os.path.join(save_dir, safe_filename)

                            # Handle duplicate filenames
                            counter = 1
                            original_path = file_path
                            while os.path.exists(file_path):
                                name, ext = os.path.splitext(original_path)
                                file_path = f"{name}_{counter}{ext}"
                                counter += 1

                            # Write the binary content to file
                            with open(file_path, "wb") as f:
                                f.write(file_response.content)

                            response += (
                                f"Downloaded: {file_info['filename']}\n"
                            )
                            response += f"   Size: {content_length} bytes\n"
                            response += f"   Type: {content_type}\n"
                            response += f"   Source: {file_info['source']}\n"
                            response += f"   Saved to: {file_path}\n"

                            # Include file content if requested
                            if include_content:
                                file_content = self._extract_file_content(
                                    file_response.content,
                                    content_type,
                                    file_info["filename"],
                                )
                                if file_content:
                                    response += (
                                        f"   Content:\n{file_content}\n"
                                    )
                                else:
                                    response += "   Content: [Binary file - content not extracted]\n"

                            response += "\n"

                            download_count += 1

                        except Exception as e:
                            response += f"Failed to download {file_info['filename']}: {str(e)}\n"
                            if file_info.get("download_url"):
                                response += f"   Download URL: {file_info['download_url']}\n"
                            response += (
                                f"   API Path: {file_info['api_path']}\n\n"
                            )

                    if len(files_found) > max_downloads:
                        response += f"Limited downloads to first {max_downloads} files. {len(files_found) - max_downloads} files not downloaded.\n\n"

                    response += f"Download Summary: {download_count}/{min(len(files_found), max_downloads)} files downloaded successfully\n"
                    if download_count > 0:
                        final_dir = (
                            download_dir
                            if download_dir
                            else f"downloads/{event_id}"
                        )
                        response += f"All files saved to: {final_dir}/\n"
                else:
                    # Just list files without downloading
                    response += "File Details:\n"
                    for i, file_info in enumerate(files_found, 1):
                        response += f"{i}. {file_info['filename']}\n"
                        response += f"   Source: {file_info['source']}\n"
                        response += f"   Size: {file_info['size']}\n"
                        if file_info.get("download_url"):
                            response += f"   Download URL: {file_info['download_url']}\n"
                        response += f"   API Path: {file_info['api_path']}\n"

                        # If content is requested but download is disabled, try to fetch content without saving
                        if include_content and self.api.bearer_token:
                            try:
                                response += "   Fetching content...\n"
                                # Prefer download_url (correct path) over api_path (may have wrong contrib ID)
                                fetch_path = file_info.get("download_url", file_info["api_path"])
                                if fetch_path.startswith(self.api.base_url):
                                    fetch_path = fetch_path[len(self.api.base_url):]
                                file_response = await self.api.get_binary(fetch_path)
                                content_type = file_response.headers.get(
                                    "content-type", "application/octet-stream"
                                )
                                file_content = self._extract_file_content(
                                    file_response.content,
                                    content_type,
                                    file_info["filename"],
                                )
                                if file_content:
                                    response += (
                                        f"   Content:\n{file_content}\n"
                                    )
                                else:
                                    response += "   Content: [Binary file - content not extracted]\n"
                            except Exception as e:
                                response += f"   Content: [Error fetching content: {str(e)}]\n"
                        elif include_content and not self.api.bearer_token:
                            response += "   Content: [Bearer token required to fetch content]\n"

                        response += "\n"

                    if include_content and not self.api.bearer_token:
                        response += "\nSet download_files=True to download the files, or configure Bearer token to fetch content.\n"
                    else:
                        response += "\nSet download_files=True to download the files.\n"

            else:
                response += "No files found for this event.\n"
                response += "This could mean:\n"
                response += (
                    "- Event has no attached materials or contributions\n"
                )
                response += (
                    "- Files are in a different structure not yet supported\n"
                )
                response += (
                    "- You may not have permission to see the materials\n"
                )

            return response

        except Exception as e:
            return (
                f"Error retrieving files: {str(e)}\n\n"
                "Possible issues:\n"
                "- Invalid event ID\n"
                "- Event is private and you don't have access\n"
                "- Network connectivity issues\n"
                "- API endpoint may not be available"
            )

    async def download_single_attachment(
        self, download_url: str, filename: Optional[str] = None
    ) -> str:
        """Download a single file attachment using its download URL"""
        try:
            # Extract path from URL if it's a full URL
            if download_url.startswith(self.api.base_url):
                path = download_url[len(self.api.base_url):]
            elif download_url.startswith("http"):
                # External URL, can't download with our API
                return (
                    f"Cannot download external URL: {download_url}\n"
                    "Only URLs from the configured Indico instance can be downloaded."
                )
            else:
                path = download_url

            # Use our download method
            fake_file_info = {
                "filename": filename or "downloaded_file",
                "download_url": download_url,
                "api_path": path,
                "legacy_path": path,
            }

            file_response = await self.download_file_with_auth(fake_file_info, "unknown")

            if not file_response:
                return (
                    f"Failed to download file from {download_url}\n"
                    "All download methods failed. Check URL and authentication."
                )

            # Get file metadata
            content_type = file_response.headers.get(
                "content-type", "application/octet-stream"
            )
            content_length = file_response.headers.get(
                "content-length", str(len(file_response.content))
            )

            # Generate filename if not provided
            if not filename:
                # Try to extract from URL
                url_parts = download_url.split("/")
                filename = url_parts[-1] if url_parts else "downloaded_file"
                # Clean up filename
                filename = "".join(
                    c for c in filename if c.isalnum() or c in (" ", ".", "-", "_")
                ).rstrip()
                if not filename:
                    filename = "downloaded_file"

            # Save file to local filesystem
            save_dir = "downloads/single_attachments"
            os.makedirs(save_dir, exist_ok=True)

            # Sanitize filename to prevent path issues
            safe_filename = "".join(
                c for c in filename if c.isalnum() or c in (" ", ".", "-", "_")
            ).rstrip()
            if not safe_filename:
                safe_filename = "downloaded_file"

            file_path = os.path.join(save_dir, safe_filename)

            # Handle duplicate filenames
            counter = 1
            original_path = file_path
            while os.path.exists(file_path):
                name, ext = os.path.splitext(original_path)
                file_path = f"{name}_{counter}{ext}"
                counter += 1

            # Write the binary content to file
            with open(file_path, "wb") as f:
                f.write(file_response.content)

            response = f"Downloaded single attachment:\n\n"
            response += f"Filename: {filename}\n"
            response += f"Size: {content_length} bytes\n"
            response += f"Type: {content_type}\n"
            response += f"Downloaded from: {download_url}\n"
            response += f"Saved to: {file_path}\n\n"

            # Include file content preview
            file_content = self._extract_file_content(
                file_response.content, content_type, filename
            )
            if file_content:
                # Limit content preview to reasonable size
                content_preview = (
                    file_content[:1000] + "..." if len(file_content) > 1000 else file_content
                )
                response += f"Content preview:\n{content_preview}\n"
            else:
                response += "Content: [Binary file - content not extracted]\n"

            return response

        except Exception as e:
            return (
                f"Error downloading attachment: {str(e)}\n\n"
                "Possible issues:\n"
                "- Invalid download URL\n"
                "- File is private and you don't have access\n"
                "- Network connectivity issues\n"
                "- Authentication problems"
            )

    # ------------------------------------------------------------------ #
    #  Event / Session / Contribution / Timetable management methods      #
    # ------------------------------------------------------------------ #

    async def _create_event_raw(
        self,
        title: str,
        category_id: str,
        event_type: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        timezone: Optional[str] = None,
        description: Optional[str] = None,
        location: Optional[str] = None,
        room: Optional[str] = None,
        speakers: Optional[List[Dict[str, str]]] = None,
    ) -> Dict[str, Any]:
        """Create an event via Indico's internal frontend endpoint.

        Returns the raw JSON response from Indico.
        """
        effective_timezone = timezone or "Europe/Zurich"
        try:
            from zoneinfo import ZoneInfo
            today = datetime.now(ZoneInfo(effective_timezone)).strftime("%Y-%m-%d")
        except (ImportError, KeyError):
            today = datetime.now().strftime("%Y-%m-%d")

        if start_date:
            start_date_str, start_time_str = parse_datetime_to_date_time(start_date)
        else:
            start_date_str = today
            start_time_str = "09:00"

        if end_date:
            end_date_str, end_time_str = parse_datetime_to_date_time(end_date)
        else:
            end_date_str = today
            end_time_str = "18:00"

        # Compute duration from the effective start/end times
        effective_start = f"{start_date_str}T{start_time_str}:00"
        effective_end = f"{end_date_str}T{end_time_str}:00"
        duration = compute_duration_minutes(effective_start, effective_end)

        form_data = {
            "event-creation-title": title,
            "event-creation-category": build_category_data(category_id),
            "event-creation-occurrences": build_occurrence_data(
                start_date_str, start_time_str, duration
            ),
            "event-creation-timezone": effective_timezone,
            "event-creation-location_data": build_location_data(
                location or "", room or "", ""
            ),
            "event-creation-person_link_data": (
                build_person_link_data(speakers) if speakers else "[]"
            ),
            "event-creation-protection_mode": "0",
        }
        if description:
            form_data["event-creation-description"] = description

        return await self.api.post_internal(
            f"/event/create/{event_type}", form_data
        )

    async def create_event(
        self,
        title: str,
        category_id: str,
        event_type: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        timezone: Optional[str] = None,
        description: Optional[str] = None,
        location: Optional[str] = None,
        room: Optional[str] = None,
        speakers: Optional[List[Dict[str, str]]] = None,
    ) -> str:
        """Create an event and return a formatted response."""
        try:
            result = await self._create_event_raw(
                title=title,
                category_id=category_id,
                event_type=event_type,
                start_date=start_date,
                end_date=end_date,
                timezone=timezone,
                description=description,
                location=location,
                room=room,
                speakers=speakers,
            )

            event_id = result.get("id", "unknown")
            event_url = f"{self.api.base_url}/event/{event_id}/"

            response = "Event created successfully!\n\n"
            response += f"Title: {title}\n"
            response += f"Type: {event_type}\n"
            response += f"Event ID: {event_id}\n"
            response += f"URL: {event_url}\n"

            return response
        except Exception as e:
            return (
                f"Failed to create event: {e}\n\n"
                "Possible issues:\n"
                "- Check your token has write:legacy_api scope\n"
                f"- Verify you have create permissions in category {category_id}\n"
                "- Ensure date format is ISO (e.g., 2026-03-01T09:00:00)"
            )

    async def _create_session_raw(
        self,
        event_id: str,
        title: str,
        description: Optional[str] = None,
        colors: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a session in an event via the internal endpoint.

        Session timing is controlled by timetable entries, not at creation time.
        Returns the raw JSON response from Indico.
        """
        default_colors = {"text": "#ffffff", "background": "#1a1a5c"}
        effective_colors = colors or default_colors

        form_data = {
            "title": title,
            "description": description or "",
            "default_contribution_duration": "20",
            "colors": json.dumps(effective_colors),
        }

        return await self.api.post_internal(
            f"/event/{event_id}/manage/sessions/create", form_data
        )

    async def create_session(
        self,
        event_id: str,
        title: str,
        description: Optional[str] = None,
        colors: Optional[Dict[str, str]] = None,
    ) -> str:
        """Create a session and return a formatted response."""
        try:
            result = await self._create_session_raw(
                event_id=event_id,
                title=title,
                description=description,
                colors=colors,
            )

            session_id = result.get("id", "unknown")

            response = "Session created successfully!\n\n"
            response += f"Title: {title}\n"
            response += f"Session ID: {session_id}\n"
            response += f"Event ID: {event_id}\n"

            return response
        except Exception as e:
            return (
                f"Failed to create session: {e}\n\n"
                "Possible issues:\n"
                f"- Check you have manage permissions on event {event_id}\n"
                "- Verify the event exists and is accessible"
            )

    async def _create_contribution_raw(
        self,
        event_id: str,
        title: str,
        description: Optional[str] = None,
        duration_minutes: Optional[int] = None,
        speakers: Optional[List[Dict[str, str]]] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a contribution in an event via the internal endpoint.

        Returns the raw JSON response from Indico.
        """
        form_data = {
            "title": title,
            "description": description or "",
            "duration": str(duration_minutes if duration_minutes is not None else 20),
            "person_link_data": (
                build_person_link_data(speakers) if speakers else "[]"
            ),
            "session_id": session_id or "",
        }

        return await self.api.post_internal(
            f"/event/{event_id}/manage/contributions/create", form_data
        )

    async def create_contribution(
        self,
        event_id: str,
        title: str,
        description: Optional[str] = None,
        duration_minutes: Optional[int] = None,
        speakers: Optional[List[Dict[str, str]]] = None,
        session_id: Optional[str] = None,
    ) -> str:
        """Create a contribution and return a formatted response."""
        try:
            result = await self._create_contribution_raw(
                event_id=event_id,
                title=title,
                description=description,
                duration_minutes=duration_minutes,
                speakers=speakers,
                session_id=session_id,
            )

            contribution_id = result.get("id", "unknown")

            response = "Contribution created successfully!\n\n"
            response += f"Title: {title}\n"
            response += f"Contribution ID: {contribution_id}\n"
            response += f"Event ID: {event_id}\n"
            if session_id:
                response += f"Session ID: {session_id}\n"

            return response
        except Exception as e:
            return (
                f"Failed to create contribution: {e}\n\n"
                "Possible issues:\n"
                f"- Check you have manage permissions on event {event_id}\n"
                "- Verify the event exists and is accessible"
            )

    async def add_timetable_entry(
        self,
        event_id: str,
        entry_type: str,
        object_id: str,
        start_date: str,
        duration_minutes: Optional[int] = None,
    ) -> str:
        """Add an entry to the event timetable."""
        try:
            date_str, time_str = parse_datetime_to_date_time(start_date)

            form_data: Dict[str, Any] = {
                "type": entry_type,
                "objectId": object_id,
                "startDate": f"{date_str} {time_str}",
            }
            if duration_minutes is not None:
                form_data["duration"] = str(duration_minutes)

            result = await self.api.post_internal(
                f"/event/{event_id}/manage/timetable/", form_data
            )

            response = "Timetable entry added successfully!\n\n"
            response += f"Entry type: {entry_type}\n"
            response += f"Object ID: {object_id}\n"
            response += f"Start: {date_str} {time_str}\n"
            if duration_minutes is not None:
                response += f"Duration: {duration_minutes} minutes\n"
            response += f"Event ID: {event_id}\n"
            response += f"\nResponse: {json.dumps(result, indent=2)}\n"

            return response
        except Exception as e:
            return (
                f"Failed to add timetable entry: {e}\n\n"
                "Possible issues:\n"
                f"- Check you have manage permissions on event {event_id}\n"
                "- Verify the object_id and entry_type are valid\n"
                "- Ensure start_date is in ISO format"
            )

    async def delete_timetable_entry(
        self,
        event_id: str,
        entry_id: str,
    ) -> str:
        """Delete a timetable entry from an event."""
        try:
            await self.api.delete_internal(
                f"/event/{event_id}/manage/timetable/{entry_id}"
            )

            response = "Timetable entry deleted successfully!\n\n"
            response += f"Entry ID: {entry_id}\n"
            response += f"Event ID: {event_id}\n"

            return response
        except Exception as e:
            return (
                f"Failed to delete timetable entry: {e}\n\n"
                "Possible issues:\n"
                f"- Check you have manage permissions on event {event_id}\n"
                f"- Verify entry_id {entry_id} exists"
            )

    async def create_event_with_agenda(
        self,
        title: str,
        category_id: str,
        event_type: str,
        start_date: str,
        end_date: str,
        timezone: Optional[str] = None,
        description: Optional[str] = None,
        location: Optional[str] = None,
        room: Optional[str] = None,
        speakers: Optional[List[Dict[str, str]]] = None,
        agenda: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """Create an event with a full agenda (sessions and contributions).

        The *agenda* parameter is a list of items. Each item is a dict with:
        - ``title`` (str): session or contribution title.
        - ``description`` (str, optional): description text.
        - ``speakers`` (list[dict], optional): speaker dicts.
        - ``duration_minutes`` (int, optional): duration for standalone contributions.
        - ``contributions`` (list[dict], optional): if present the item is
          treated as a *session* and each entry in the list becomes a
          contribution inside that session.  Each contribution dict may have
          ``title``, ``description``, ``speakers``, ``duration_minutes``.
        """
        errors: List[str] = []
        created_sessions: List[Dict[str, Any]] = []
        created_contributions: List[Dict[str, Any]] = []

        # 1. Create the event
        result = await self._create_event_raw(
            title=title,
            category_id=category_id,
            event_type=event_type,
            start_date=start_date,
            end_date=end_date,
            timezone=timezone,
            description=description,
            location=location,
            room=room,
            speakers=speakers,
        )

        # Extract event_id from the response
        event_id = result.get("id")
        if event_id is None:
            # Try to parse from a redirect URL if present
            redirect_url = result.get("redirect", "") or result.get("url", "")
            if redirect_url:
                # URLs look like /event/1234/ or .../event/1234/manage/...
                parts = redirect_url.rstrip("/").split("/")
                for i, part in enumerate(parts):
                    if part == "event" and i + 1 < len(parts):
                        event_id = parts[i + 1]
                        break

        if event_id is None:
            return (
                "Event creation returned a response but the event ID "
                f"could not be determined.\n\nRaw response:\n"
                f"{json.dumps(result, indent=2)}"
            )

        event_id = str(event_id)
        event_url = f"{self.api.base_url}/event/{event_id}/"

        # 2. Process agenda items
        if agenda:
            for item in agenda:
                item_title = item.get("title", "Untitled")
                contributions_list = item.get("contributions")

                if contributions_list is not None:
                    # This item is a session containing contributions
                    try:
                        session_result = await self._create_session_raw(
                            event_id=event_id,
                            title=item_title,
                            description=item.get("description"),
                        )
                        session_id = str(session_result.get("id", "unknown"))
                        created_sessions.append({
                            "title": item_title,
                            "id": session_id,
                        })
                    except Exception as exc:
                        errors.append(
                            f"Failed to create session '{item_title}': {exc}"
                        )
                        continue

                    # Create each contribution inside the session
                    for contrib in contributions_list:
                        contrib_title = contrib.get("title", "Untitled")
                        try:
                            contrib_result = await self._create_contribution_raw(
                                event_id=event_id,
                                title=contrib_title,
                                description=contrib.get("description"),
                                duration_minutes=contrib.get("duration_minutes"),
                                speakers=contrib.get("speakers"),
                                session_id=session_id,
                            )
                            created_contributions.append({
                                "title": contrib_title,
                                "id": str(contrib_result.get("id", "unknown")),
                                "session_id": session_id,
                            })
                        except Exception as exc:
                            errors.append(
                                f"Failed to create contribution '{contrib_title}' "
                                f"in session '{item_title}': {exc}"
                            )
                else:
                    # Standalone contribution (no session)
                    try:
                        contrib_result = await self._create_contribution_raw(
                            event_id=event_id,
                            title=item_title,
                            description=item.get("description"),
                            duration_minutes=item.get("duration_minutes"),
                            speakers=item.get("speakers"),
                        )
                        created_contributions.append({
                            "title": item_title,
                            "id": str(contrib_result.get("id", "unknown")),
                        })
                    except Exception as exc:
                        errors.append(
                            f"Failed to create contribution '{item_title}': {exc}"
                        )

        # 3. Build comprehensive response
        response = "Event with agenda created successfully!\n\n"
        response += f"Event: {title}\n"
        response += f"Event ID: {event_id}\n"
        response += f"URL: {event_url}\n\n"

        if created_sessions:
            response += f"Sessions ({len(created_sessions)}):\n"
            for session in created_sessions:
                response += f"  - {session['title']} (ID: {session['id']})\n"
            response += "\n"

        if created_contributions:
            response += f"Contributions ({len(created_contributions)}):\n"
            for contrib in created_contributions:
                line = f"  - {contrib['title']} (ID: {contrib['id']})"
                if "session_id" in contrib:
                    line += f" [session {contrib['session_id']}]"
                response += line + "\n"
            response += "\n"

        if errors:
            response += f"Errors ({len(errors)}):\n"
            for error_msg in errors:
                response += f"  - {error_msg}\n"
            response += "\n"

        return response
