#!/usr/bin/env python3
"""CLI entry point for interacting with Indico event management systems."""

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Optional

import click

from indico_cli.indico_api import IndicoAPI, IndicoClient

CONFIG_DIR = Path.home() / ".config" / "indico-cli"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_config() -> dict:
    """Load saved configuration from disk, returning empty dict on failure."""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(base_url: str, token: str) -> None:
    """Persist configuration to ~/.config/indico-cli/config.json."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps({"base_url": base_url, "token": token}, indent=2))


def get_client(base_url: Optional[str], token: Optional[str]) -> IndicoClient:
    """Create an IndicoClient from CLI args, env vars, or saved config."""
    saved_config = load_config()
    resolved_url = base_url or os.getenv("INDICO_BASE_URL") or saved_config.get("base_url", "")
    resolved_token = token or os.getenv("INDICO_API_TOKEN") or saved_config.get("token", "")

    if not resolved_url:
        click.echo("Error: --base-url, INDICO_BASE_URL, or saved config required", err=True)
        sys.exit(1)

    api = IndicoAPI(resolved_url, bearer_token=resolved_token if resolved_token else None)
    return IndicoClient(api)


def run_async(coro):
    """Run an async coroutine and return its result."""
    return asyncio.run(coro)


def parse_speakers_json(speakers_string: Optional[str]):
    """Parse a JSON string of speakers into a list of dicts."""
    if not speakers_string:
        return None
    return json.loads(speakers_string)


@click.group()
@click.option("--base-url", envvar="INDICO_BASE_URL", help="Indico instance URL")
@click.option("--token", envvar="INDICO_API_TOKEN", help="API bearer token")
@click.pass_context
def cli(ctx, base_url, token):
    """CLI for interacting with Indico event management systems."""
    ctx.ensure_object(dict)
    ctx.obj["base_url"] = base_url
    ctx.obj["token"] = token


@cli.command()
@click.option("--base-url", required=True, help="Indico instance URL")
@click.option("--token", default="", help="API bearer token")
def configure(base_url, token):
    """Configure connection to an Indico instance and test it."""
    api = IndicoAPI(base_url, bearer_token=token if token else None)
    client = IndicoClient(api)
    try:
        result = run_async(client.get_user_info())
        click.echo("Connection successful!")
        click.echo(result)
        save_config(base_url, token)
        click.echo(f"Configuration saved to {CONFIG_FILE}")
    except Exception as error:
        click.echo(f"Connection test failed: {error}", err=True)
        sys.exit(1)


@cli.command("user-info")
@click.pass_context
def user_info(ctx):
    """Get current user information."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.get_user_info())
    click.echo(result)


@cli.command("search-events")
@click.option("--category-id", required=True, help="Category ID to search in")
@click.option("--from-date", default=None, help="Start date filter (e.g. 2024-01-01)")
@click.option("--to-date", default=None, help="End date filter (e.g. 2024-12-31)")
@click.option("--limit", type=int, default=None, help="Maximum number of results")
@click.option("--only-public", is_flag=True, default=False, help="Only show public events")
@click.pass_context
def search_events(ctx, category_id, from_date, to_date, limit, only_public):
    """Search for events in a category."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.search_events(category_id, from_date, to_date, limit, only_public))
    click.echo(result)


@cli.command("search-by-term")
@click.option("--term", required=True, help="Search term")
@click.option("--limit", type=int, default=50, help="Maximum number of results")
@click.pass_context
def search_by_term(ctx, term, limit):
    """Search for events by keyword/term."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.search_events_by_term(term, limit))
    click.echo(result)


@cli.command("search-categories")
@click.option("--category-id", default="0", help="Parent category ID (default: root)")
@click.option("--limit", type=int, default=None, help="Maximum number of results")
@click.pass_context
def search_categories(ctx, category_id, limit):
    """Search for event categories."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.search_categories(category_id, limit))
    click.echo(result)


@cli.command("event-details")
@click.option("--event-id", required=True, help="Event ID")
@click.option("--contributions", is_flag=True, default=False, help="Include contributions")
@click.option("--sessions", is_flag=True, default=False, help="Include sessions")
@click.pass_context
def event_details(ctx, event_id, contributions, sessions):
    """Get detailed information about a specific event."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.get_event_details(event_id, contributions, sessions))
    click.echo(result)


@cli.command()
@click.option("--event-id", required=True, help="Event ID")
@click.option("--subcontributions", is_flag=True, default=False, help="Include subcontributions")
@click.option("--limit", type=int, default=None, help="Maximum number of results")
@click.pass_context
def contributions(ctx, event_id, subcontributions, limit):
    """Get contributions for a specific event."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.get_event_contributions(event_id, subcontributions, limit))
    click.echo(result)


@cli.command()
@click.option("--event-id", required=True, help="Event ID")
@click.option("--download/--no-download", default=True, help="Download files (default: yes)")
@click.option("--download-dir", default=None, help="Directory to save downloaded files")
@click.pass_context
def files(ctx, event_id, download, download_dir):
    """Get and optionally download files for an event."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.get_files(event_id, download_files=download, download_dir=download_dir))
    click.echo(result)


@cli.command()
@click.option("--url", required=True, help="Download URL for the attachment")
@click.option("--filename", default=None, help="Save as this filename")
@click.pass_context
def download(ctx, url, filename):
    """Download a single file attachment."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.download_single_attachment(url, filename))
    click.echo(result)


@cli.command("create-event")
@click.option("--title", required=True, help="Event title")
@click.option("--category-id", required=True, help="Category ID")
@click.option("--type", "event_type", required=True, type=click.Choice(["lecture", "meeting", "conference"]), help="Event type")
@click.option("--start", default=None, help="Start date/time (ISO format)")
@click.option("--end", default=None, help="End date/time (ISO format)")
@click.option("--timezone", default=None, help="Timezone (e.g. Europe/Zurich)")
@click.option("--description", default=None, help="Event description")
@click.option("--location", default=None, help="Event location")
@click.option("--room", default=None, help="Room name")
@click.option("--speakers", default=None, help="Speakers as JSON string")
@click.pass_context
def create_event(ctx, title, category_id, event_type, start, end, timezone, description, location, room, speakers):
    """Create a new event."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    parsed_speakers = parse_speakers_json(speakers)
    result = run_async(client.create_event(
        title=title,
        category_id=category_id,
        event_type=event_type,
        start_date=start,
        end_date=end,
        timezone=timezone,
        description=description,
        location=location,
        room=room,
        speakers=parsed_speakers,
    ))
    click.echo(result)


@cli.command("create-session")
@click.option("--event-id", required=True, help="Event ID")
@click.option("--title", required=True, help="Session title")
@click.option("--description", default=None, help="Session description")
@click.pass_context
def create_session(ctx, event_id, title, description):
    """Create a session in an event."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.create_session(
        event_id=event_id,
        title=title,
        description=description,
    ))
    click.echo(result)


@cli.command("create-contribution")
@click.option("--event-id", required=True, help="Event ID")
@click.option("--title", required=True, help="Contribution title")
@click.option("--description", default=None, help="Contribution description")
@click.option("--duration", type=int, default=None, help="Duration in minutes")
@click.option("--speakers", default=None, help="Speakers as JSON string")
@click.option("--session-id", default=None, help="Session ID to add contribution to")
@click.pass_context
def create_contribution(ctx, event_id, title, description, duration, speakers, session_id):
    """Create a contribution in an event."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    parsed_speakers = parse_speakers_json(speakers)
    result = run_async(client.create_contribution(
        event_id=event_id,
        title=title,
        description=description,
        duration_minutes=duration,
        speakers=parsed_speakers,
        session_id=session_id,
    ))
    click.echo(result)


@cli.command("add-timetable-entry")
@click.option("--event-id", required=True, help="Event ID")
@click.option("--type", "entry_type", required=True, type=click.Choice(["session_block", "contribution"]), help="Entry type")
@click.option("--object-id", required=True, help="Object ID (session or contribution)")
@click.option("--start", required=True, help="Start date/time (ISO format)")
@click.option("--duration", type=int, default=None, help="Duration in minutes")
@click.pass_context
def add_timetable_entry(ctx, event_id, entry_type, object_id, start, duration):
    """Add an entry to the event timetable."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.add_timetable_entry(
        event_id=event_id,
        entry_type=entry_type,
        object_id=object_id,
        start_date=start,
        duration_minutes=duration,
    ))
    click.echo(result)


@cli.command("delete-timetable-entry")
@click.option("--event-id", required=True, help="Event ID")
@click.option("--entry-id", required=True, help="Timetable entry ID")
@click.pass_context
def delete_timetable_entry(ctx, event_id, entry_id):
    """Delete a timetable entry from an event."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    result = run_async(client.delete_timetable_entry(
        event_id=event_id,
        entry_id=entry_id,
    ))
    click.echo(result)


@cli.command("create-event-with-agenda")
@click.option("--title", required=True, help="Event title")
@click.option("--category-id", required=True, help="Category ID")
@click.option("--type", "event_type", required=True, type=click.Choice(["lecture", "meeting", "conference"]), help="Event type")
@click.option("--start", required=True, help="Start date/time (ISO format)")
@click.option("--end", required=True, help="End date/time (ISO format)")
@click.option("--timezone", default=None, help="Timezone (e.g. Europe/Zurich)")
@click.option("--description", default=None, help="Event description")
@click.option("--location", default=None, help="Event location")
@click.option("--room", default=None, help="Room name")
@click.option("--speakers", default=None, help="Speakers as JSON string")
@click.option("--agenda-file", type=click.Path(exists=True), default=None, help="Path to JSON file with agenda array")
@click.pass_context
def create_event_with_agenda(ctx, title, category_id, event_type, start, end, timezone, description, location, room, speakers, agenda_file):
    """Create an event with a full agenda from a JSON file."""
    client = get_client(ctx.obj["base_url"], ctx.obj["token"])
    parsed_speakers = parse_speakers_json(speakers)

    agenda_data = None
    if agenda_file:
        with open(agenda_file) as agenda_fh:
            agenda_data = json.load(agenda_fh)

    result = run_async(client.create_event_with_agenda(
        title=title,
        category_id=category_id,
        event_type=event_type,
        start_date=start,
        end_date=end,
        timezone=timezone,
        description=description,
        location=location,
        room=room,
        speakers=parsed_speakers,
        agenda=agenda_data,
    ))
    click.echo(result)


if __name__ == "__main__":
    cli()
