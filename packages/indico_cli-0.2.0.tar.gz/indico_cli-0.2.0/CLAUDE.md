# CLAUDE.md

## Project Overview

Python CLI tool for interacting with Indico event management systems. Extracted from the `indico-mcp` MCP server. Run via `uvx indico-cli` or install with `pip install indico-cli`.

## Architecture

- `indico_cli/cli.py`: Click CLI entry point with 15 subcommands
- `indico_cli/indico_api.py`: HTTP API client (`IndicoAPI` for low-level requests, `IndicoClient` for high-level operations)
- `indico_cli/utils.py`: Utility functions for building Indico API request data
- `skill/`: Claude Code skill package (14 skills mapping to CLI commands)

## Development

```bash
# Install in dev mode
uv pip install -e .

# Run CLI
indico-cli --help

# Run with uvx from source
uvx --from . indico-cli --help
```

## Configuration

Requires env vars `INDICO_BASE_URL` and `INDICO_API_TOKEN`, or use `indico-cli configure`. A `.env` file is supported but must never be committed.

## Key Technical Details

- All API calls are async (httpx). The CLI wraps them with `asyncio.run()`.
- Bearer token auth only (tokens starting with `indp_`). No `Content-Type` header on GET requests (Indico returns 403 for file downloads if `Content-Type: application/json` is set).
- The Indico export API returns local sequential contribution IDs (e.g., 1, 2, 3) not database IDs. Always use `download_url` from API responses for file downloads, not reconstructed paths.
- Room booking is excluded (needs separate fix).
