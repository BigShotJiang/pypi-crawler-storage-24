import os

# 屏蔽 MediaPipe 内部 C++ (abseil/glog) 产生的冗余日志
# 级别: 0=INFO, 1=WARNING, 2=ERROR, 3=FATAL —— 设为 2 仅保留 ERROR 及以上
os.environ.setdefault('GLOG_minloglevel', '2')
os.environ.setdefault('ABSL_MIN_LOG_LEVEL', '2')
