"""
Registry module to manage dynamic registration of Business Rules and Data Loaders.
"""

class RuleRegistry:
    """
    Singleton registry to store functions decorated with @register_rule or @register_loader.
    """
    _rules = {}
    _loaders = {}

    @classmethod
    def register_rule(cls, name=None):
        """
        Decorator to register a Business Rule function.
        
        Args:
            name (str, optional): The name to register the rule under. If not provided,
                                  the function's name will be used.
        
        Returns:
            function: The decorator function.
        """
        def decorator(func):
            rule_name = name if name else func.__name__
            if rule_name in cls._rules:
                print(f"[Warning] Overwriting existing rule: {rule_name}")
            cls._rules[rule_name] = func
            return func
        return decorator

    @classmethod
    def register_loader(cls, name=None):
        """
        Decorator to register a Data Loader function.
        
        Args:
            name (str, optional): The name to register the loader under. If not provided,
                                  the function's name will be used.
        
        Returns:
            function: The decorator function.
        """
        def decorator(func):
            loader_name = name if name else func.__name__
            cls._loaders[loader_name] = func
            return func
        return decorator

    @classmethod
    def get_rule(cls, name):
        """
        Retrieve a Business Rule by name.
        
        Args:
            name (str): The name of the registered business rule.
            
        Returns:
            function: The registered business rule function.
            
        Raises:
            ValueError: If the rule is not found in the registry.
        """
        if name not in cls._rules:
            raise ValueError(f"Business Rule '{name}' not found. Ensure the module containing it is imported.")
        return cls._rules[name]

    @classmethod
    def get_loader(cls, name):
        """
        Retrieve a Data Loader by name.
        
        Args:
            name (str): The name of the registered data loader.
            
        Returns:
            function: The registered data loader function.
            
        Raises:
            ValueError: If the loader is not found in the registry.
        """
        if name not in cls._loaders:
            raise ValueError(f"Data Loader '{name}' not found.")
        return cls._loaders[name]
    
    @classmethod
    def list_rules(cls):
        """
        List all registered rules.
        
        Returns:
            list[str]: A list of names of all currently registered business rules.
        """
        return list(cls._rules.keys())
