"""
Configuration module. Handles YAML loading and Environment detection.
Includes auto-discovery mechanism to find config.yaml at project root.
"""
import yaml
import os

class ConfigurationManager:
    """
    Manages the loading and retrieval of configuration from a YAML file.
    Automatically detects the current environment by testing catalog access.
    """
    def __init__(self, spark, config_path=None):
        """
        Initializes the ConfigurationManager.
        
        Args:
            spark (SparkSession): The active SparkSession used to verify catalog access.
            config_path (str, optional): Absolute path to the config.yaml file.
                                         If not provided, the framework will attempt
                                         to auto-discover it by searching parent directories.
                                         
        Raises:
            FileNotFoundError: If the configuration file cannot be found.
        """
        self.spark = spark
        self.config = {}
        self.current_env_name = None
        self.db_prefix = None
        
        # 1. Path Resolution logic
        final_path = config_path
        
        if not final_path:
            # Try to auto-discover at current location or parents
            print("[Config] No path provided. Searching for 'config.yaml' in parent directories...")
            final_path = self._find_config_upwards("config.yaml")
            
        if final_path:
            self._load_config_file(final_path)
            self.current_env_name = self._detect_environment()
            self.db_prefix = self.get_value("catalog")
        else:
            # Critical error: Framework cannot run without config
            raise FileNotFoundError(
                "[Config] CRITICAL: 'config.yaml' not found in current directory or any parent directory. "
                "Please verify your project structure."
            )

    def _find_config_upwards(self, filename):
        """
        Searches for a file starting from current working directory and moving up.
        
        Args:
            filename (str): The name of the file to search for.
            
        Returns:
            str: Absolute path to the file if found, else None.
        """
        current_dir = os.getcwd()
        
        # Loop until we hit the root of the filesystem
        while True:
            check_path = os.path.join(current_dir, filename)
            if os.path.exists(check_path):
                print(f"   [Config] Auto-discovered config file at: {check_path}")
                return check_path
            
            parent_dir = os.path.dirname(current_dir)
            if parent_dir == current_dir:
                # We hit the filesystem root (e.g. /) without finding the file
                return None
            current_dir = parent_dir

    def _load_config_file(self, path):
        """
        Loads the YAML configuration file into the object's state.
        
        Args:
            path (str): The absolute path to the YAML file.
            
        Raises:
            ValueError: If the YAML file contains syntax errors.
        """
        print(f"   [Config] Loading configuration from: {path}")
        try:
            with open(path, 'r') as f:
                self.config = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise ValueError(f"Error parsing YAML file: {exc}")

    def _detect_environment(self):
        """
        Auto-detects the active environment by iterating through the 'priority_check'
        list in the config and attempting to connect to the associated catalog.
        
        Returns:
            str: The name of the successfully detected environment.
            
        Raises:
            EnvironmentError: If no catalogs defined in the configuration are accessible.
        """
        envs = self.config.get("environments", {})
        priority = self.config.get("priority_check", envs.keys())

        print("   [Config] Auto-detecting environment...")

        for env_name in priority:
            if env_name not in envs:
                continue
            
            catalog = envs[env_name].get("catalog")
            try:
                # Use a read-only command which is more stable than USE CATALOG.
                # It checks for accessibility without changing the session's state.
                self.spark.sql(f"SHOW SCHEMAS IN `{catalog}`").limit(1).collect()
                print(f"   [Config] Success: Connected to catalog '{catalog}'. Environment is '{env_name.upper()}'.")
                return env_name
            except Exception:
                continue
        
        raise EnvironmentError("Could not connect to any catalog defined in the configuration file.")

    def get_value(self, key):
        """
        Retrieves a configuration value specific to the currently active environment.
        
        Args:
            key (str): The configuration key to retrieve.
            
        Returns:
            Any: The value associated with the key, or None if not found or no env is active.
        """
        if not self.current_env_name: return None
        return self.config["environments"][self.current_env_name].get(key)
    
    def get_db(self):
        """
        Retrieves the database (catalog) prefix for the current environment.
        
        Returns:
            str: The database/catalog prefix.
        """
        return self.db_prefix
