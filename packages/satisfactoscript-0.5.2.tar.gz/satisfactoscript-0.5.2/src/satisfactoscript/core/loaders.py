"""
Generic Data Loaders registered via the RuleRegistry.
"""
from functools import reduce
from pyspark.sql import functions as F
from .registry import RuleRegistry

@RuleRegistry.register_loader(name="load_and_union_tables")
def load_and_union_tables(spark, config, table_fqns):
    """
    Loads a list of tables using their Fully Qualified Names (FQN) and performs a
    unionByName. Missing columns across different tables are allowed and will be
    filled with nulls.
    
    Args:
        spark (SparkSession): The active SparkSession.
        config (dict): The configuration dictionary.
        table_fqns (list[str]): A list of string FQNs representing the tables to load.
        
    Returns:
        DataFrame: A PySpark DataFrame containing the union of all loaded tables.
        
    Raises:
        ValueError: If none of the provided tables could be loaded successfully.
    """
    print(f"   -> [Data Loader] Loading and Unioning {len(table_fqns)} tables...")
    list_of_dfs = []
    for table in table_fqns:
        try:
            # Use spark directly as injected by the engine
            df = spark.table(table)
            list_of_dfs.append(df)
        except Exception as e:
            print(f"      [WARNING] Could not load {table}. Skipping.")
    
    if not list_of_dfs:
        raise ValueError("No tables loaded successfully.")
        
    # Use unionByName with allowMissingColumns for robustness
    return reduce(lambda x, y: x.unionByName(y, allowMissingColumns=True), list_of_dfs)

@RuleRegistry.register_loader()
def load_generic_explode_union(spark, config, source_fqn, filter_expr=None, union_config=None):
    """
    Loads a source table, explodes multiple array columns (e.g., items, rewards, freeItems),
    and unifies the results into a single common schema using unionByName.
    
    Args:
        spark (SparkSession): The active SparkSession.
        config (dict): The configuration dictionary.
        source_fqn (str): The Fully Qualified Name of the source table (e.g., 'raw_ddp_orders').
        filter_expr (str, optional): An initial SQL filter expression to apply before exploding
                                     (e.g., "cart IS NOT NULL").
        union_config (dict): A configuration dictionary defining how to unify the branches.
                             It should contain:
                             - 'common_cols' (list): Columns to keep from the root level.
                             - 'branches' (list of dict): Configuration for each array to explode.
                               Each branch config requires:
                                 - 'explode_col': Path to the array column.
                                 - 'item_alias' (optional): Alias for the exploded item.
                                 - 'mappings' (optional): dict mapping target col names to source paths.
                                 - 'defaults' (optional): dict of default values for missing columns.
                                 
    Returns:
        DataFrame: A single unified PySpark DataFrame containing all exploded branches.
        
    Raises:
        ValueError: If 'union_config' is not provided.
    """
    print(f"      [Loader] Generic Explode & Union on {source_fqn}")
    
    # 1. Lecture Source
    df_source = spark.table(source_fqn)
    
    # 2. Filtre Global (Optimisation)
    if filter_expr:
        df_source = df_source.filter(F.expr(filter_expr))

    if not union_config:
        raise ValueError("[Loader] 'union_config' is required for load_generic_explode_union")

    common_cols = union_config.get("common_cols", [])
    branches = union_config.get("branches", [])
    
    dfs_to_union = []

    # 3. Boucle sur chaque branche (Items, Rewards, FOC...)
    for i, branch_conf in enumerate(branches):
        explode_col = branch_conf["explode_col"]   # ex: "cart.items"
        item_alias = branch_conf.get("item_alias", "item") # ex: "item"
        mappings = branch_conf.get("mappings", {}) # ex: {"sku": "item.sku"}
        defaults = branch_conf.get("defaults", {}) # ex: {"line_type": "Normal"}
        
        print(f"        -> Processing branch {i+1}: {explode_col} (alias: {item_alias})")

        # A. Explode
        # On ne garde que les lignes où l'array n'est pas vide pour éviter les nulls inutiles
        # (Sauf si on voulait du left join, mais ici on veut des lignes produits)
        df_branch = df_source.withColumn(item_alias, F.explode(F.col(explode_col)))
        
        # B. Sélection des Colonnes Communes
        # On commence par sélectionner les colonnes d'entête (OrderNumber, etc.)
        select_exprs = [F.col(c) for c in common_cols]
        
        # C. Mapping des Champs Spécifiques
        # On ajoute les colonnes mappées (ex: item.sku -> sku)
        mapped_col_names = []
        for target_col, source_path in mappings.items():
            select_exprs.append(F.col(source_path).alias(target_col))
            mapped_col_names.append(target_col)
            
        # D. Valeurs par Défaut
        # Pour les colonnes qui existent dans d'autres branches mais pas celle-ci
        for target_col, default_val in defaults.items():
            if target_col not in mapped_col_names:
                # Gestion des types basiques
                if isinstance(default_val, float):
                    select_exprs.append(F.lit(default_val).cast("double").alias(target_col))
                elif isinstance(default_val, int):
                    select_exprs.append(F.lit(default_val).cast("int").alias(target_col))
                else:
                    select_exprs.append(F.lit(default_val).alias(target_col))
        
        # Application de la sélection
        df_branch = df_branch.select(*select_exprs)
        dfs_to_union.append(df_branch)

    # 4. Union Finale
    if not dfs_to_union:
        print("      [Warning] No branches processed. Returning empty DF.")
        return spark.createDataFrame([], schema=df_source.schema) # Ou schema vide
        
    print(f"      [Union] Merging {len(dfs_to_union)} branches...")
    # unionByName avec allowMissingColumns=True est plus robuste si les defaults ne couvrent pas tout
    df_final = reduce(lambda x, y: x.unionByName(y, allowMissingColumns=True), dfs_to_union)
    
    return df_final
