import pytest
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DoubleType

# Functions to test from the core module
from satisfactoscript.core.core import _apply_operation, _build_filter_expression
from satisfactoscript.core.core import SatisfactoEngine

# Mock registry for testing purposes
from satisfactoscript.core.registry import RuleRegistry
from datetime import datetime

# ==============================================================================
# TESTS FOR HELPERS
# ==============================================================================

@pytest.mark.parametrize("op_str, expected_value", [
    ("upper", "HELLO-WORLD"),
    ("lit:world", "world"),
    ("cast:string", "123"),
    ("substring:1,3", "hel"),
    ("split:-,1", "world"),
    ("trim", "hello world"),
    ("coalesce:default", "default"),
    ("expr:concat(col1, '_test')", "hello-world_test")
])
def test_apply_operation_various(spark, op_str, expected_value):
    """Tests various single operations of _apply_operation."""
    # Default schema and data for most string operations
    schema = StructType([StructField("col1", StringType(), True)])
    df = spark.createDataFrame([("hello-world",), (" hello world ",)], schema)
    
    # Special case for 'cast:string' which needs a different input type to be meaningful
    if op_str == "cast:string":
        schema = StructType([StructField("col1", IntegerType(), True)])
        df = spark.createDataFrame([(123,)], schema)

    # Coalesce test needs a null value
    df_null = spark.createDataFrame([(None,)], schema)
    
    if "coalesce" in op_str:
        res_df = df_null
    elif "trim" in op_str:
        res_df = df.filter(F.col("col1").contains(" "))
    elif op_str == "cast:string":
        res_df = df
    else:
        res_df = df.filter(~F.col("col1").contains(" "))

    result = res_df.withColumn("res", _apply_operation(F.col("col1"), op_str)).collect()[0]
    assert result["res"] == expected_value


def test_apply_operation_conditional(spark):
    """Tests the when/then/else logic of _apply_operation."""
    df = spark.createDataFrame([("complete",), ("pending",)], ["status"])
    
    # Define a when/then/else chain
    operations = [
        "when:eq:complete",
        "then:lit:C",
        "else:lit:P"
    ]
    
    c = F.col("status")
    res_col = F.when(
        _apply_operation(c, operations[0]), 
        _apply_operation(c, operations[1])
    ).otherwise(_apply_operation(c, operations[2]))
    
    results = df.withColumn("res", res_col).collect()
    assert results[0]["res"] == "C"
    assert results[1]["res"] == "P"


@pytest.mark.parametrize("filters, expected_count", [
    ([{"column": "country", "operator": "eq", "value": "FR"}], 1),
    ([{"column": "country", "operator": "ne", "value": "FR"}], 2),
    ([{"column": "sales", "operator": "gt", "value": 150}], 1),
    ([{"column": "sales", "operator": "lte", "value": 150}], 2),
    ([{"column": "country", "operator": "in", "value": ["FR", "DE"]}], 2),
    ([{"column": "country", "operator": "not_in", "value": ["US", "DE"]}], 1),
    ([{"column": "product", "operator": "is_null"}], 1),
    ([{"column": "product", "operator": "is_not_null"}], 2),
    ([{"column": "product", "operator": "contains", "value": "phone"}], 1),
    ([{"column": "product", "operator": "notcontains", "value": "phone"}], 1),
    ([
        {"column": "country", "operator": "eq", "value": "DE"},
        {"column": "sales", "operator": "gt", "value": 100}
    ], 1)
])
def test_build_filter_expression_various(spark, filters, expected_count):
    """Tests various filter operators and combinations."""
    data = [
        ("FR", 100, "laptop"),
        ("DE", 200, "smartphone"),
        ("US", 150, None)
    ]
    df = spark.createDataFrame(data, ["country", "sales", "product"])
    
    filter_expr = _build_filter_expression(filters)
    result_count = df.filter(filter_expr).count()
    
    assert result_count == expected_count

# ==============================================================================
# TESTS FOR ENGINE METHODS (VIA A MOCKED ENGINE)
# ==============================================================================

@pytest.fixture
def mock_engine(spark, mocker):
    """Fixture to create a SatisfactoEngine instance with mocked dependencies."""
    
    # This mock replaces the original _load_config_from_yaml method.
    # Instead of just returning None, it actively sets the necessary config attributes
    # on the instance ('self') that is passed to it.
    def mock_load_config(instance, config_path):
        instance.config = {"environments": {"test": {"is_production": False}}}
        instance.env = "test"
        # Use the default spark_catalog which is known by the local Spark session
        instance.db = "spark_catalog"

    mocker.patch.object(SatisfactoEngine, "_load_config_from_yaml", side_effect=mock_load_config, autospec=True)
    mocker.patch.object(SatisfactoEngine, "_get_clean_username", return_value="test_user")
    
    # Mock DBUtils which is not available in local Spark
    mocker.patch('satisfactoscript.core.core.DBUtils', autospec=True)

    # We still pass a dummy config_path to ensure the 'if config_path:' branch is taken
    engine = SatisfactoEngine(spark=spark, config_path="dummy/path/to/config.yaml")
    
    return engine


def test_get_target_schema(mock_engine, mocker):
    """Tests the sandbox logic for schema names."""
    
    # 1. Interactive mode (default for mock) -> Suffix should be added
    mocker.patch.object(mock_engine, "_is_running_as_job", return_value=False)
    mock_engine.is_job_execution = False
    mock_engine.schema_suffix = "_test_user"
    assert mock_engine.get_target_schema("silver") == "silver_test_user"
    
    # 2. Job mode -> Suffix should NOT be added
    mocker.patch.object(mock_engine, "_is_running_as_job", return_value=True)
    mock_engine.is_job_execution = True
    mock_engine.schema_suffix = "" # Logic inside __init__ is mocked, so we set it
    assert mock_engine.get_target_schema("silver") == "silver"

    # 3. Prod environment -> Suffix should NOT be added
    mock_engine.config = {"environments": {"prod": {"is_production": True}}}
    mock_engine.env = "prod"
    mock_engine.is_job_execution = False
    mock_engine.schema_suffix = ""
    assert mock_engine.get_target_schema("gold") == "gold"


def test_get_select_expressions(mock_engine):
    """Tests the parsing of the 'select_final' block."""
    field_list = [
        ["source_id", "target_id", []],
        ["amount", "amount_eur", ["cast:double"]],
        ["status", "status_code", ["when:eq:Paid", "then:lit:1", "else:lit:0"]]
    ]
    
    expressions = mock_engine.get_select_expressions(field_list)
    
    assert len(expressions) == 3
    assert "target_id" in str(expressions[0])
    assert "CAST(amount AS DOUBLE)" in str(expressions[1])
    
    # For conditional logic, check for the essential parts rather than exact string representation
    # which can vary between PySpark versions.
    conditional_expr_str = str(expressions[2])
    assert "CASE" in conditional_expr_str
    assert "WHEN" in conditional_expr_str
    assert "status_code" in conditional_expr_str


def test_process_schema_with_preprocess(mock_engine, spark):
    """
    Integration test for process_schema, specifically testing the 'preprocess'
    (qualify/deduplication) logic.
    """
    # 1. Prepare data with duplicates
    sales_data = [
        (1, 10.0, datetime(2023, 1, 1, 10, 0, 0)), # Old version
        (1, 12.0, datetime(2023, 1, 1, 12, 0, 0)), # New version, should be kept
        (2, 20.0, datetime(2023, 1, 2, 10, 0, 0))  # Single entry
    ]
    sales_schema = StructType([
        StructField("sale_id", IntegerType()),
        StructField("amount", DoubleType()),
        StructField("updated_at", TimestampType())
    ])
    sales_df = spark.createDataFrame(sales_data, sales_schema)
    sales_df.createOrReplaceTempView("sales_with_duplicates")

    # 2. Define schema with preprocess qualify
    schema_dict = {
        "tables": [
            {
                "name": "sales_with_duplicates",
                "alias": "s",
                "preprocess": {
                    "qualify": {
                        "partition_by": ["sale_id"],
                        "order_by": [{"field": "updated_at", "order": "desc"}]
                    }
                }
            }
        ],
        "select_final": [
            ["sale_id", "sale_id", []],
            ["amount", "amount", []]
        ]
    }

    # 3. Execute the process
    result_df = mock_engine.process_schema(schema_dict)
    
    # 4. Assertions
    assert result_df.count() == 2 # Should have deduplicated from 3 to 2 rows
    
    result_data = result_df.sort("sale_id").collect()
    assert result_data[0]["sale_id"] == 1
    assert result_data[0]["amount"] == 12.0 # The latest amount
    assert result_data[1]["sale_id"] == 2
    assert result_data[1]["amount"] == 20.0

    spark.catalog.dropTempView("sales_with_duplicates")


def test_process_schema_raises_error_on_unknown_rule(mock_engine):
    """
    Tests that process_schema correctly raises a ValueError when a business
    rule specified in the schema is not found in the RuleRegistry.
    """
    schema_dict = {
        "tables": [{"name": "some_table", "alias": "t"}],
        "business_rules": ["this_rule_does_not_exist"]
    }
    
    # Mock a dummy table to avoid FileNotFoundError
    mock_engine.spark.createDataFrame([(1,)], ["id"]).createOrReplaceTempView("some_table")

    with pytest.raises(ValueError, match="Business Rule 'this_rule_does_not_exist' not found"):
        mock_engine.process_schema(schema_dict)

    mock_engine.spark.catalog.dropTempView("some_table")


def test_run_split_to_org(mock_engine, mocker, spark):
    """
    Tests the run_split_to_org runner. It spies on the _write_dataframe method
    to ensure it's called correctly without actually writing any data.
    """
    # 0. Create the schema required for the test before running the engine
    spark.sql("CREATE SCHEMA IF NOT EXISTS spark_catalog.gold_test_user")

    # 1. Spy on the _write_dataframe and _drop_table_if_exists methods
    spy_write = mocker.spy(mock_engine, "_write_dataframe")
    mocker.patch.object(mock_engine, "_drop_table_if_exists")

    # 2. Prepare mock data
    source_data = [
        (1, "FR"),
        (2, "DE"),
        (3, "FR")
    ]
    source_df = spark.createDataFrame(source_data, ["id", "sales_org_code"])
    source_df.createOrReplaceTempView("source_for_split")

    # 3. Define schema and org list
    schema_dict = {"tables": [{"name": "source_for_split", "alias": "t"}]}
    org_list = [
        {"label": "france", "org_code": "FR"},
        {"label": "germany", "org_code": "DE"}
    ]

    # 4. Execute the runner
    mock_engine.run_split_to_org(
        schema_dict=schema_dict,
        org_list=org_list,
        target_layer="gold",
        target_base_name="sales"
    )

    # 5. Assertions on the spy
    assert spy_write.call_count == 2

    # Check the call for France
    call_fr_args = spy_write.call_args_list[0].args
    df_fr = call_fr_args[0]
    fqn_fr = call_fr_args[1]
    assert "sales_france" in fqn_fr
    assert df_fr.count() == 2
    assert df_fr.filter("sales_org_code = 'FR'").count() == 2

    # Check the call for Germany
    call_de_args = spy_write.call_args_list[1].args
    df_de = call_de_args[0]
    fqn_de = call_de_args[1]
    assert "sales_germany" in fqn_de
    assert df_de.count() == 1
    assert df_de.filter("sales_org_code = 'DE'").count() == 1

    # 6. Cleanup
    spark.catalog.dropTempView("source_for_split")
    spark.sql("DROP SCHEMA IF EXISTS spark_catalog.gold_test_user CASCADE")
