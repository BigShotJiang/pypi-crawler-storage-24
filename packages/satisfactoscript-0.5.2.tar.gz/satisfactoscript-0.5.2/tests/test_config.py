import pytest
import os
import yaml
from satisfactoscript.core.config import ConfigurationManager

# ==============================================================================
# TESTS FOR ConfigurationManager
# ==============================================================================

def test_config_loads_and_detects_env(spark, tmp_path):
    """
    Tests that ConfigurationManager can correctly load a YAML file,
    and auto-detect the active environment by checking catalog access.
    This test relies on the default 'spark_catalog' which always exists.
    """
    # 1. Create a dummy config file pointing to the real, existing spark_catalog
    config_content = {
        "priority_check": ["non_existent_env", "test_env"],
        "environments": {
            "non_existent_env": {"catalog": "fake_catalog"},
            "test_env": {"catalog": "spark_catalog"} # This catalog is real
        }
    }
    config_file = tmp_path / "config.yaml"
    with open(config_file, 'w') as f:
        yaml.dump(config_content, f)

    # 2. Instantiate the manager, pointing to our temporary config file
    manager = ConfigurationManager(spark, config_path=str(config_file))

    # 3. Assertions
    assert manager.current_env_name == "test_env"
    assert manager.get_db() == "spark_catalog"
    assert manager.get_value("catalog") == "spark_catalog"


def test_config_raises_error_if_no_catalog_matches(spark, tmp_path):
    """
    Tests that ConfigurationManager raises an EnvironmentError if it cannot
    connect to any of the catalogs listed in the priority_check.
    """
    # 1. Create a config file where none of the catalogs will exist
    config_content = {
        "priority_check": ["non_existent_env_1", "non_existent_env_2"],
        "environments": {
            "non_existent_env_1": {"catalog": "cat_1"},
            "non_existent_env_2": {"catalog": "cat_2"}
        }
    }
    config_file = tmp_path / "config.yaml"
    with open(config_file, 'w') as f:
        yaml.dump(config_content, f)

    # 2. Assert that instantiating the manager raises the correct error
    with pytest.raises(EnvironmentError, match="Could not connect to any catalog"):
        ConfigurationManager(spark, config_path=str(config_file))


def test_config_raises_error_if_file_not_found():
    """
    Tests that a FileNotFoundError is raised if the config_path does not exist
    and auto-discovery fails (which it will in a controlled test).
    """
    # We pass a non-existent path and expect a FileNotFoundError
    # We don't need spark for this test as it should fail before using it.
    with pytest.raises(FileNotFoundError):
        ConfigurationManager(spark=None, config_path="/path/to/non/existent/config.yaml")
