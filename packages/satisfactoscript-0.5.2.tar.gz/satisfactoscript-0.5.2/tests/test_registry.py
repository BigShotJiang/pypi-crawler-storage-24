import pytest
from satisfactoscript.core.registry import RuleRegistry

def test_register_rule():
    @RuleRegistry.register_rule(name="my_rule")
    def my_rule(df):
        return df

    assert "my_rule" in RuleRegistry.list_rules()
    assert RuleRegistry.get_rule("my_rule") == my_rule

def test_register_loader():
    @RuleRegistry.register_loader(name="my_loader")
    def my_loader(spark, config, table_fqns):
        pass

    assert RuleRegistry.get_loader("my_loader") == my_loader
