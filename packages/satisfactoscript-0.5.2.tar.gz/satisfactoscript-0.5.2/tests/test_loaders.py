import pytest
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType, DoubleType

# Functions to test from the loaders module
from satisfactoscript.core.loaders import load_and_union_tables, load_generic_explode_union

# ==============================================================================
# TEST FOR load_and_union_tables
# ==============================================================================

def test_load_and_union_tables(spark):
    """
    Tests the load_and_union_tables loader to ensure it correctly loads and unions
    multiple tables, handling missing columns.
    """
    # 1. Prepare mock data and register as temporary views
    data1 = [("A", 100), ("B", 200)]
    df1 = spark.createDataFrame(data1, ["product_code", "sales"])
    df1.createOrReplaceTempView("sales_part1")

    data2 = [(300, "C"), (400, "D")]
    df2 = spark.createDataFrame(data2, ["sales", "product_code_new"])
    df2.createOrReplaceTempView("sales_part2")

    table_fqns = ["sales_part1", "sales_part2"]

    # 2. Execute the loader function
    # The loader doesn't use the 'config' argument, so we can pass None
    result_df = load_and_union_tables(spark, None, table_fqns)

    # 3. Assertions
    assert result_df.count() == 4
    
    # Check that all columns are present
    assert "product_code" in result_df.columns
    assert "sales" in result_df.columns
    assert "product_code_new" in result_df.columns
    
    # Check that nulls were filled in correctly
    assert result_df.filter("product_code IS NULL").count() == 2
    assert result_df.filter("product_code_new IS NULL").count() == 2
    
    # Clean up views
    spark.catalog.dropTempView("sales_part1")
    spark.catalog.dropTempView("sales_part2")


def test_load_and_union_tables_no_tables_found(spark):
    """
    Tests that the loader raises a ValueError if no tables can be loaded.
    """
    with pytest.raises(ValueError, match="No tables loaded successfully."):
        load_and_union_tables(spark, None, ["non_existent_table"])

# ==============================================================================
# TEST FOR load_generic_explode_union
# ==============================================================================

def test_load_generic_explode_union(spark):
    """
    Tests the complex loader that explodes and unions multiple nested arrays
    based on a configuration dictionary.
    """
    # 1. Prepare complex nested data
    source_schema = StructType([
        StructField("order_id", StringType()),
        StructField("cart", StructType([
            StructField("items", ArrayType(StructType([
                StructField("sku", StringType()),
                StructField("price", DoubleType())
            ]))),
            StructField("rewards", ArrayType(StructType([
                StructField("reward_sku", StringType()),
                StructField("discount", DoubleType())
            ])))
        ]))
    ])
    
    data = [
        ("ORDER1", (
            [{"sku": "SKU100", "price": 99.9}], 
            [{"reward_sku": "REWARD1", "discount": 5.0}]
        )),
        ("ORDER2", (
            [{"sku": "SKU200", "price": 10.0}, {"sku": "SKU300", "price": 20.0}], 
            [] # No rewards for this order
        ))
    ]
    
    df = spark.createDataFrame(data, schema=source_schema)
    df.createOrReplaceTempView("raw_orders")

    # 2. Define the union configuration
    union_config = {
        "common_cols": ["order_id"],
        "branches": [
            {
                "explode_col": "cart.items",
                "item_alias": "item",
                "mappings": {
                    "product_sku": "item.sku",
                    "line_amount": "item.price"
                },
                "defaults": {
                    "line_type": "SALE"
                }
            },
            {
                "explode_col": "cart.rewards",
                "item_alias": "reward",
                "mappings": {
                    "product_sku": "reward.reward_sku",
                    "line_amount": "reward.discount"
                },
                "defaults": {
                    "line_type": "REWARD"
                }
            }
        ]
    }

    # 3. Execute the loader
    result_df = load_generic_explode_union(
        spark, 
        None, 
        source_fqn="raw_orders", 
        union_config=union_config
    )
    
    # 4. Assertions
    assert result_df.count() == 4 # 1 item + 1 reward from ORDER1, 2 items from ORDER2
    
    # Check columns
    expected_cols = ["order_id", "product_sku", "line_amount", "line_type"]
    assert all(col in result_df.columns for col in expected_cols)
    
    # Check data integrity
    result_data = result_df.sort("order_id", "product_sku").collect()
    
    # ORDER1
    assert result_data[0]["order_id"] == "ORDER1"
    assert result_data[0]["product_sku"] == "REWARD1"
    assert result_data[0]["line_amount"] == 5.0
    assert result_data[0]["line_type"] == "REWARD"
    
    assert result_data[1]["order_id"] == "ORDER1"
    assert result_data[1]["product_sku"] == "SKU100"
    assert result_data[1]["line_amount"] == 99.9
    assert result_data[1]["line_type"] == "SALE"
    
    # ORDER2
    assert result_data[2]["order_id"] == "ORDER2"
    assert result_data[2]["product_sku"] == "SKU200"
    assert result_data[2]["line_type"] == "SALE"

    # Clean up
    spark.catalog.dropTempView("raw_orders")
