"""EWS Scoreboard Pipeline."""
__version__ = "0.15.9"


def init_workspace(target_dir=".", force=False):
    """Paketin içindeki güncel notebook'ları çalışma dizinine kopyalar.

    - Mevcut dosya varsa ve hash aynıysa atlar
    - Mevcut dosya varsa ve hash farklıysa eski dosyayı _arsiv/'e taşır, yenisini kopyalar
    - force=True ise her zaman üzerine yazar (arsivleme yok)

    Kullanım:
        python -m ews_scoreboard init
        veya
        from ews_scoreboard import init_workspace; init_workspace()
    """
    import hashlib
    import shutil
    from datetime import datetime
    from pathlib import Path

    from ews_scoreboard.paths import get_notebooks_dir

    target = Path(target_dir).resolve()
    nb_dir = get_notebooks_dir()
    arsiv_dir = target / "_arsiv"

    created, updated, skipped = [], [], 0

    for nb_file in sorted(nb_dir.glob("*.ipynb")):
        if nb_file.name == "nb_01_ingest.ipynb":
            continue
        dst = target / nb_file.name

        if force:
            shutil.copy2(nb_file, dst)
            updated.append(nb_file.name)
        elif not dst.exists():
            shutil.copy2(nb_file, dst)
            created.append(nb_file.name)
        else:
            src_hash = hashlib.sha256(nb_file.read_bytes()).hexdigest()[:16]
            dst_hash = hashlib.sha256(dst.read_bytes()).hexdigest()[:16]
            if src_hash != dst_hash:
                # Eski dosyayı arsivle
                arsiv_dir.mkdir(exist_ok=True)
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                arsiv_name = f"{dst.stem}_{ts}{dst.suffix}"
                shutil.move(str(dst), str(arsiv_dir / arsiv_name))
                shutil.copy2(nb_file, dst)
                updated.append(nb_file.name)
            else:
                skipped += 1

    # Version marker
    ver_file = target / "db" / ".nb_version"
    ver_file.parent.mkdir(parents=True, exist_ok=True)
    ver_file.write_text(__version__, encoding="utf-8")

    print(f"EWS Scoreboard v{__version__} — init_workspace")
    print(f"  Hedef: {target}")
    print(f"  Aynı: {skipped}, Yeni: {len(created)}, Güncellendi: {len(updated)}")
    if updated:
        print(f"  Eski versiyonlar: {arsiv_dir}/")
    for f in created:
        print(f"    + {f}")
    for f in updated:
        print(f"    ↻ {f}")
    return {"created": created, "updated": updated, "skipped": skipped}
