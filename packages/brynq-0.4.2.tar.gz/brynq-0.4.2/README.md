<p align="center">
  <h1 align="center">Brynq</h1>
  <p align="center"><strong>All your AI models. One app.</strong></p>
</p>

<p align="center">
  <a href="https://pypi.org/project/brynq/"><img src="https://img.shields.io/pypi/v/brynq.svg?style=flat-square" alt="PyPI version"></a>
  <a href="https://github.com/khadkutamaihaine/brynq/actions"><img src="https://img.shields.io/github/actions/workflow/status/khadkutamaihaine/brynq/ci.yml?style=flat-square" alt="CI status"></a>
  <a href="https://opensource.org/licenses/Apache-2.0"><img src="https://img.shields.io/badge/license-Apache_2.0-blue.svg?style=flat-square" alt="License"></a>
  <a href="https://www.python.org/downloads/"><img src="https://img.shields.io/badge/python-3.10+-blue.svg?style=flat-square" alt="Python 3.10+"></a>
</p>

---

Brynq connects the AI tools you already use — Gemini, Claude, ChatGPT, Llama, Mistral — and makes them work together. Log in with Google, and Brynq automatically finds every model on your machine.

No new subscriptions. No API keys to manage. Your AI, orchestrated.

```
You: "Research the latest on solid-state batteries and summarize the key breakthroughs"

  Gemini:  Searching recent papers and news... Found 12 key developments
           in 2025-2026 including Toyota's sulfide electrolyte breakthrough...

  Claude:  Analyzing Gemini's findings. The most significant trend is the
           shift from oxide to sulfide electrolytes, which reduces interface
           resistance by 10x...

  Llama:   Summary: Three breakthroughs matter most — (1) Toyota's sulfide
           cells hitting 500 Wh/kg, (2) QuantumScape's solid-state pouch
           cells passing automotive qualification, (3) Samsung SDI's...
```

---

## Get started

### Download the desktop app

<p>
  <a href="https://github.com/khadkutamaihaine/brynq/releases/latest/download/install-brynq.bat">
    <strong>Install for Windows</strong>
  </a>
  &nbsp;&nbsp;|&nbsp;&nbsp;
  <a href="https://github.com/khadkutamaihaine/brynq/releases/latest/download/install-brynq.sh">
    <strong>Install for macOS / Linux</strong>
  </a>
</p>

### Or install via terminal

```bash
pip install brynq

brynq-runtime start     # Opens the app
brynq-runtime chat      # Terminal chat
brynq-runtime models    # See all detected models
brynq-runtime status    # Check connections
```

---

## How it works

### 1. Log in with Google

One click. Uses your existing Google account to access Gemini. No API keys, no credit card, no extra charges.

### 2. Brynq detects your models

Have Claude installed? Ollama running? ChatGPT CLI? Brynq finds them automatically and adds them to your team. Nothing to configure.

| Model | How Brynq finds it | Cost to you |
|-------|-------------------|-------------|
| **Gemini** | Google OAuth (one-click login) | Your existing Google account |
| **Claude** | Auto-detected if installed on your machine | Your existing subscription |
| **Llama, Mistral, Phi** | Auto-detected via Ollama | Free (runs on your hardware) |
| **ChatGPT** | Auto-detected or paste API key | Your existing subscription or API key |
| **Any Ollama model** | Auto-detected | Free |

### 3. They work together

You ask once. Brynq figures out which model handles which part, then executes locally on your machine. Five strategies:

- **Sequential** — One model's output feeds the next
- **Fan-Out** — Multiple models answer in parallel, best response wins
- **Debate** — Models critique each other's answers
- **Refine** — One drafts, another improves, repeat
- **Single** — Route to the best model for this specific task

---

## Why Brynq

**No extra charges** — Uses the subscriptions and tools you already have. Google OAuth uses your Google account. Claude uses your existing installation. Ollama is free. No surprise bills.

**Private by default** — Local models run entirely on your computer. Your conversations never leave your machine. Cloud models are called directly from your machine to the provider.

**Smarter together** — Models fact-check each other and build on each other's strengths. Gemini is great at research, Claude at analysis, Llama at fast summaries. Together they produce better results than any single model.

**One conversation** — No more opening Claude in one tab, Gemini in another, and ChatGPT in a third. Ask once, get answers from your whole team, in one place.

---

## Security

- **Your keys stay local** — API keys and OAuth tokens are encrypted on your machine. Never sent to our servers.
- **Your data stays local** — Documents and conversations never leave your computer.
- **Encrypted storage** — All credentials stored with Fernet encryption in a machine-bound vault.
- **Tamper-proof** — Execution plans are cryptographically signed and time-limited.

---

## Development

```bash
# Install in dev mode
pip install -e ".[all]"

# Start the runtime
brynq-runtime start

# Run tests
python -m pytest tests/ -v

# Lint
ruff check src/brynq/ cloud/ runtime/
```

## Stack

- **Runtime**: Python, FastAPI
- **Desktop app**: React 19, Vite 8, Tailwind v4, TypeScript
- **Auth**: Google OAuth 2.0 + BYOK API keys
- **LLM support**: Ollama, Claude, Gemini, OpenAI, LM Studio
- **Tests**: 4,500+ passing
- **CI/CD**: GitHub Actions

---

## License

Apache 2.0

Built by [Gurjeet Grewal](https://github.com/khadkutamaihaine).
