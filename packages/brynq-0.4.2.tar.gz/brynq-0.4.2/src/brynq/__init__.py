# Terminal Broker — Standalone MCP server for cross-terminal messaging
