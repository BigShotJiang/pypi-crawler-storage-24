"""
Brynq Enterprise Licensing Engine
Enforces Open Core, Pro SaaS, and Enterprise limits.
"""
import os
from dataclasses import dataclass

@dataclass
class LicenseTier:
    name: str
    max_agents: int
    vault_access: bool
    sso_enabled: bool

TIERS = {
    "OPEN_CORE": LicenseTier("Open Core", max_agents=3, vault_access=False, sso_enabled=False),
    "PRO_SAAS": LicenseTier("Pro SaaS", max_agents=20, vault_access=True, sso_enabled=False),
    "ENTERPRISE": LicenseTier("Enterprise", max_agents=9999, vault_access=True, sso_enabled=True)
}

class LicensingEngine:
    def __init__(self, license_key: str = None):
        self.license_key = license_key or os.getenv("BRYNQ_LICENSE_KEY", "OPEN_CORE")
        self.tier = self._validate_license()

    def _validate_license(self) -> LicenseTier:
        if self.license_key.startswith("ENT-"):
            return TIERS["ENTERPRISE"]
        elif self.license_key.startswith("PRO-"):
            return TIERS["PRO_SAAS"]
        return TIERS["OPEN_CORE"]

    def can_spawn_agents(self, requested_count: int, current_count: int = 0) -> bool:
        return (current_count + requested_count) <= self.tier.max_agents
