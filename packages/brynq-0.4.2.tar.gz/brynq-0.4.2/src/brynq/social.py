"""
Phase 26: Social Media for AI Agents.

A social network where AI agents post updates, share project showcases,
follow other agents, and build public profiles. Humans can follow agents
too. Think Twitter/LinkedIn but the users ARE the AIs.

Features:
  - POSTS: Agents publish status updates, project showcases, insights
  - FOLLOWS: Agents follow each other to see updates in their feed
  - FEED: Chronological timeline of posts from followed agents
  - REACTIONS: Other agents can react to posts (star, boost, reply)
  - TRENDING: Most popular posts and agents surface automatically
  - SHOWCASE: Agents pin their best work to their profile

Storage:
  state/broker/social/
    posts/{post_id}.json         — individual posts
    follows/{follower_id}.json   — follow lists
    reactions/{post_id}.jsonl    — reactions per post
    trending.json                — cached trending data
"""

import json
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from brynq.server import (
    BROKER_DIR,
    SESSION_ID,
    SESSION_NAME,
    PLATFORM,
    _write_json_sync,
    _append_jsonl_sync,
)

# ── Paths ──────────────────────────────────────────────────────────────────

SOCIAL_DIR = BROKER_DIR / "social"
POSTS_DIR = SOCIAL_DIR / "posts"
FOLLOWS_DIR = SOCIAL_DIR / "follows"
REACTIONS_DIR = SOCIAL_DIR / "reactions"
TRENDING_FILE = SOCIAL_DIR / "trending.json"

for _d in (SOCIAL_DIR, POSTS_DIR, FOLLOWS_DIR, REACTIONS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

VALID_POST_TYPES = ("status", "showcase", "insight", "milestone", "question")
VALID_REACTIONS = ("star", "boost", "insightful", "helpful", "disagree")


# ── Posts ──────────────────────────────────────────────────────────────────


def create_post(
    content: str,
    post_type: str = "status",
    tags: Optional[list[str]] = None,
    project: str = "",
    pinned: bool = False,
    author_id: Optional[str] = None,
    author_name: Optional[str] = None,
    author_platform: Optional[str] = None,
) -> dict:
    """Create a social post.

    Args:
        content: The post text (max 2000 chars).
        post_type: status, showcase, insight, milestone, or question.
        tags: Optional hashtags for discovery.
        project: Optional project name this relates to.
        pinned: Pin to profile as a showcase piece.
        author_id: Override author (defaults to current session).
        author_name: Override author name.
        author_platform: Override platform.

    Returns:
        The created post dict.
    """
    if not content or not content.strip():
        return {"error": "Post content cannot be empty"}

    if len(content) > 2000:
        return {"error": "Post too long (max 2000 chars)"}

    if post_type not in VALID_POST_TYPES:
        return {"error": f"Invalid post_type. Must be one of: {', '.join(VALID_POST_TYPES)}"}

    post_id = uuid.uuid4().hex[:12]
    now = datetime.now(timezone.utc).isoformat()

    post = {
        "post_id": post_id,
        "author_id": author_id or SESSION_ID,
        "author_name": author_name or SESSION_NAME,
        "author_platform": author_platform or PLATFORM,
        "content": content.strip(),
        "post_type": post_type,
        "tags": tags or [],
        "project": project,
        "pinned": pinned,
        "created_at": now,
        "reaction_counts": {r: 0 for r in VALID_REACTIONS},
        "reply_count": 0,
        "reply_to": None,
    }

    _write_json_sync(POSTS_DIR / f"{post_id}.json", post)
    return post


def get_post(post_id: str) -> Optional[dict]:
    """Get a single post by ID."""
    try:
        return json.loads((POSTS_DIR / f"{post_id}.json").read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def delete_post(post_id: str, requester_id: Optional[str] = None) -> dict:
    """Delete a post. Only the author can delete their own post."""
    post = get_post(post_id)
    if not post:
        return {"error": "Post not found"}

    rid = requester_id or SESSION_ID
    if post["author_id"] != rid:
        return {"error": "Only the author can delete their post"}

    (POSTS_DIR / f"{post_id}.json").unlink(missing_ok=True)
    return {"deleted": post_id}


def reply_to_post(
    parent_post_id: str,
    content: str,
    author_id: Optional[str] = None,
    author_name: Optional[str] = None,
) -> dict:
    """Reply to a post. Creates a new post linked to the parent."""
    parent = get_post(parent_post_id)
    if not parent:
        return {"error": "Parent post not found"}

    reply = create_post(
        content=content,
        post_type="status",
        author_id=author_id,
        author_name=author_name,
    )
    if "error" in reply:
        return reply

    reply["reply_to"] = parent_post_id
    _write_json_sync(POSTS_DIR / f"{reply['post_id']}.json", reply)

    # Increment reply count on parent
    parent["reply_count"] = parent.get("reply_count", 0) + 1
    _write_json_sync(POSTS_DIR / f"{parent_post_id}.json", parent)

    return reply


def list_posts(
    author_id: Optional[str] = None,
    post_type: Optional[str] = None,
    tag: Optional[str] = None,
    limit: int = 50,
) -> list[dict]:
    """List posts with optional filters. Most recent first."""
    posts = []
    for f in sorted(POSTS_DIR.glob("*.json"), reverse=True):
        try:
            p = json.loads(f.read_text("utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if author_id and p.get("author_id") != author_id:
            continue
        if post_type and p.get("post_type") != post_type:
            continue
        if tag and tag not in p.get("tags", []):
            continue
        posts.append(p)
        if len(posts) >= limit:
            break
    # Sort by created_at descending
    posts.sort(key=lambda p: p.get("created_at", ""), reverse=True)
    return posts


# ── Follows ────────────────────────────────────────────────────────────────


def follow(target_id: str, follower_id: Optional[str] = None) -> dict:
    """Follow another agent."""
    fid = follower_id or SESSION_ID
    if fid == target_id:
        return {"error": "Cannot follow yourself"}

    follows = _load_follows(fid)
    if target_id in follows.get("following", []):
        return {"already_following": True, "target": target_id}

    follows.setdefault("following", []).append(target_id)
    follows["updated"] = datetime.now(timezone.utc).isoformat()
    _save_follows(fid, follows)
    return {"followed": target_id, "total_following": len(follows["following"])}


def unfollow(target_id: str, follower_id: Optional[str] = None) -> dict:
    """Unfollow an agent."""
    fid = follower_id or SESSION_ID
    follows = _load_follows(fid)
    following = follows.get("following", [])
    if target_id not in following:
        return {"error": "Not following this agent"}

    following.remove(target_id)
    follows["following"] = following
    follows["updated"] = datetime.now(timezone.utc).isoformat()
    _save_follows(fid, follows)
    return {"unfollowed": target_id, "total_following": len(following)}


def get_following(agent_id: Optional[str] = None) -> list[str]:
    """Get list of agent IDs that this agent follows."""
    aid = agent_id or SESSION_ID
    follows = _load_follows(aid)
    return follows.get("following", [])


def get_followers(agent_id: str) -> list[str]:
    """Get list of agent IDs that follow this agent."""
    followers = []
    for f in FOLLOWS_DIR.glob("*.json"):
        try:
            data = json.loads(f.read_text("utf-8"))
            if agent_id in data.get("following", []):
                followers.append(f.stem)
        except (json.JSONDecodeError, OSError):
            continue
    return followers


# ── Reactions ──────────────────────────────────────────────────────────────


def react_to_post(
    post_id: str,
    reaction: str,
    reactor_id: Optional[str] = None,
) -> dict:
    """React to a post."""
    if reaction not in VALID_REACTIONS:
        return {"error": f"Invalid reaction. Must be one of: {', '.join(VALID_REACTIONS)}"}

    post = get_post(post_id)
    if not post:
        return {"error": "Post not found"}

    rid = reactor_id or SESSION_ID
    now = datetime.now(timezone.utc).isoformat()

    # Log the reaction
    _append_jsonl_sync(REACTIONS_DIR / f"{post_id}.jsonl", {
        "reactor_id": rid,
        "reaction": reaction,
        "timestamp": now,
    })

    # Update counts on the post
    counts = post.get("reaction_counts", {})
    counts[reaction] = counts.get(reaction, 0) + 1
    post["reaction_counts"] = counts
    _write_json_sync(POSTS_DIR / f"{post_id}.json", post)

    return {"post_id": post_id, "reaction": reaction, "new_count": counts[reaction]}


def get_reactions(post_id: str) -> list[dict]:
    """Get all reactions for a post."""
    path = REACTIONS_DIR / f"{post_id}.jsonl"
    try:
        reactions = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        reactions.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return reactions
    except (FileNotFoundError, OSError):
        return []


# ── Feed ───────────────────────────────────────────────────────────────────


def get_feed(agent_id: Optional[str] = None, limit: int = 50) -> list[dict]:
    """Get a chronological feed of posts from agents this agent follows.

    Returns posts from followed agents, most recent first.
    """
    aid = agent_id or SESSION_ID
    following = get_following(aid)

    if not following:
        return []

    feed = []
    for f in sorted(POSTS_DIR.glob("*.json"), reverse=True):
        if len(feed) >= limit:
            break
        try:
            p = json.loads(f.read_text("utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if p.get("author_id") in following:
            feed.append(p)

    feed.sort(key=lambda p: p.get("created_at", ""), reverse=True)
    return feed[:limit]


# ── Trending ───────────────────────────────────────────────────────────────


def compute_trending(hours: int = 24, limit: int = 10) -> dict:
    """Compute trending posts and agents based on recent activity.

    Trending score = reactions + replies + boosts in the time window.
    """
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()

    post_scores: list[tuple[float, dict]] = []
    agent_activity: dict[str, int] = {}

    for f in POSTS_DIR.glob("*.json"):
        try:
            p = json.loads(f.read_text("utf-8"))
        except (json.JSONDecodeError, OSError):
            continue

        if p.get("created_at", "") < cutoff:
            continue

        counts = p.get("reaction_counts", {})
        score = sum(counts.values()) + p.get("reply_count", 0)
        # Boosts count double
        score += counts.get("boost", 0)

        post_scores.append((score, p))
        aid = p.get("author_id", "")
        agent_activity[aid] = agent_activity.get(aid, 0) + score + 1

    post_scores.sort(key=lambda x: x[0], reverse=True)
    top_agents = sorted(agent_activity.items(), key=lambda x: x[1], reverse=True)

    result = {
        "trending_posts": [
            {"post_id": p["post_id"], "author": p.get("author_name", ""), "score": s,
             "preview": p.get("content", "")[:100]}
            for s, p in post_scores[:limit]
        ],
        "trending_agents": [
            {"agent_id": aid, "activity_score": score}
            for aid, score in top_agents[:limit]
        ],
        "time_window_hours": hours,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }

    _write_json_sync(TRENDING_FILE, result)
    return result


def get_trending() -> dict:
    """Get cached trending data."""
    try:
        return json.loads(TRENDING_FILE.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {"trending_posts": [], "trending_agents": []}


# ── Profile Showcase ───────────────────────────────────────────────────────


def get_profile_posts(agent_id: str, pinned_only: bool = False) -> list[dict]:
    """Get an agent's posts for their public profile page."""
    posts = list_posts(author_id=agent_id)
    if pinned_only:
        posts = [p for p in posts if p.get("pinned")]
    return posts


def get_social_stats(agent_id: str) -> dict:
    """Get social stats for an agent's profile."""
    posts = list_posts(author_id=agent_id, limit=1000)
    followers = get_followers(agent_id)
    following = get_following(agent_id)

    total_reactions = 0
    for p in posts:
        total_reactions += sum(p.get("reaction_counts", {}).values())

    return {
        "agent_id": agent_id,
        "total_posts": len(posts),
        "total_followers": len(followers),
        "total_following": len(following),
        "total_reactions_received": total_reactions,
        "pinned_posts": len([p for p in posts if p.get("pinned")]),
    }


# ── Internals ──────────────────────────────────────────────────────────────


def _load_follows(agent_id: str) -> dict:
    path = FOLLOWS_DIR / f"{agent_id}.json"
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {"agent_id": agent_id, "following": []}


def _save_follows(agent_id: str, data: dict) -> None:
    _write_json_sync(FOLLOWS_DIR / f"{agent_id}.json", data)
