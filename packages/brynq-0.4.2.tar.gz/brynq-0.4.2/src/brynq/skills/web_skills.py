import requests
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS
import logging

logger = logging.getLogger(__name__)

def search_web(query: str, max_results: int = 5) -> str:
    """
    Searches the web using DuckDuckGo to find current information.
    Use this when the user asks for recent news, events, or facts not in your local memory.
    """
    logger.info(f"[WEB_SKILL] Searching web for: {query}")
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
        if not results: return "No results found for your query."
        
        formatted_results = "\n\n".join([f"Title: {r['title']}\nURL: {r['href']}\nSnippet: {r['body']}" for r in results])
        return f"Web Search Results for '{query}':\n\n{formatted_results}"
    except Exception as e:
        logger.error(f"[WEB_SKILL] Web search failed: {e}")
        return f"Error performing web search: {str(e)}"

def scrape_url(url: str) -> str:
    """
    Scrapes the main text content from a specific URL. 
    Use this to read the full content of an article or webpage found via search_web.
    """
    logger.info(f"[WEB_SKILL] Scraping URL: {url}")
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        for script in soup(["script", "style", "nav", "footer", "header"]): 
            script.extract()
            
        text = soup.get_text(separator=' ', strip=True)
        
        # Enforce Context Window Safety limits (approx 3000 words)
        words = text.split()
        if len(words) > 3000: 
            text = " ".join(words[:3000]) + "\n\n[SYSTEM NOTICE: CONTENT TRUNCATED FOR LENGTH]"
            
        return text
    except Exception as e:
        logger.error(f"[WEB_SKILL] Scraping failed: {e}")
        return f"Error scraping URL: {str(e)}"
