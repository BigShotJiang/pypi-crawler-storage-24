"""
Runtime Auth — OAuth 2.0 login for AI provider subscriptions.

Users log in with their existing Claude/Gemini/ChatGPT subscriptions.
Tokens are encrypted locally (Fernet, machine-bound) and NEVER sent
to Brynq cloud.

Submodules:
    oauth_manager    — Core OAuth flow orchestrator
    token_store      — Encrypted local token storage
    callback_server  — Temporary localhost server for OAuth redirects
    providers        — Provider-specific OAuth configuration
"""

from .callback_server import (
    CallbackResult,
    OAuthCallbackError,
    OAuthCallbackServer,
    OAuthCallbackTimeout,
)
from .oauth_manager import (
    Connection,
    OAuthManager,
    OAuthTokenError,
    generate_pkce_pair,
    generate_state,
)
from .providers import ProviderConfig, get_provider, list_provider_names
from .token_store import TokenSet, TokenStore

__all__ = [
    # Core manager
    "OAuthManager",
    "Connection",
    "OAuthTokenError",
    # Token storage
    "TokenStore",
    "TokenSet",
    # Callback server
    "OAuthCallbackServer",
    "CallbackResult",
    "OAuthCallbackError",
    "OAuthCallbackTimeout",
    # Providers
    "ProviderConfig",
    "get_provider",
    "list_provider_names",
    # Helpers
    "generate_pkce_pair",
    "generate_state",
]
