"""
Runtime Key Vault — Secure local storage for user API keys.

Keys are encrypted with Fernet (AES-128-CBC + HMAC-SHA256) using
machine-specific key derivation. Keys NEVER leave the user's machine.
"""

from .key_vault import KeyVault, KeyInfo

__all__ = ["KeyVault", "KeyInfo"]
