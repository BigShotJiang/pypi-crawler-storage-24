"""
Brynq Desktop Launcher — Entry point for PyInstaller.

When the user double-clicks Brynq.exe, this starts the chat.
"""
import sys
import os

# Ensure the bundled runtime package is importable
if getattr(sys, 'frozen', False):
    # Running as PyInstaller bundle
    os.chdir(os.path.dirname(sys.executable))

from runtime.cli import main

if __name__ == "__main__":
    sys.argv = [sys.argv[0], "chat"]
    sys.exit(main())
