```
- name: Pull environments
  env:
    ENV_SECURE_KEY: ${{ secrets.ENV_SECURE_KEY }}
  run: softdoes-env pull --project Test2 --stage PRODUCTION
```

pypi-AgEIcHlwaS5vcmcCJDc3NDY3MTdhLTRiNDUtNGI0My05MWNiLWZmNDk0Njk1ZDllOAACKlszLCJjMjkyMjBiMi1mNzgxLTQ5MzctOTA2My1lNDEwZTFkZWI0ZTciXQAABiBOYhwNGOAyWX838bpFduvM-EHEAt1G7RzfFUGJN4hcMw