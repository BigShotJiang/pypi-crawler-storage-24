import argparse
import os
import sys
import requests

API_URL = 'https://api.softdoes-env-app.softwaredoes.com/api/v1/env/pull'

def pull_env(project: str, stage: str, department: str, api_url: str):
    secure_key = os.getenv('ENV_SECURE_KEY')
    if not secure_key:
        print("Error: ENV_SECURE_KEY environment variable is not set.")
        sys.exit(1)

    headers = {
        'accept': 'application/json',
        'X-ENV-SECURE-KEY': secure_key,
        'Content-Type': 'application/json'
    }

    payload = {
        "project": project,
        "department": department,
        "stage": stage
    }

    print(f"Downloading configuration for {project} [{stage}]...")

    try:
        response = requests.post(api_url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        
        env_vars = response.json().get('env', {})
        
        if not env_vars:
            print("Error: API returned an empty env object.")
            sys.exit(1)

        with open('.env', 'w', encoding='utf-8') as f:
            for key, value in env_vars.items():
                f.write(f'{key}="{value}"\n')
                
        print(f"Success! Saved {len(env_vars)} variables to local .env file")

    except requests.exceptions.RequestException as e:
        print(f"API request error: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Softdoes Environment CLI Manager")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Configure the "pull" command
    pull_parser = subparsers.add_parser("pull", help="Download .env file from API")
    pull_parser.add_argument("--project", required=True, help="Project name")
    pull_parser.add_argument("--stage", required=True, help="Environment (e.g., LOCAL, DEV, PRODUCTION)")
    pull_parser.add_argument("--department", default="Python", help="Department (default: Python)")
    pull_parser.add_argument("--api-url", default=API_URL, help="API URL for pulling environment variables")

    args = parser.parse_args()

    if args.command == "pull":
        pull_env(project=args.project, stage=args.stage, department=args.department, api_url=args.api_url)
    else:
        print(f"Unknown command: {args.command}")
        sys.exit(1)


if __name__ == "__main__":
    main()