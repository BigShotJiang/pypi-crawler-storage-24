# AltSportsLeagues MCP Server

FastMCP server that wraps the public AltSportsLeagues API (`api.altsportsleagues.ai`) as MCP tools for AI agents. Enables Claude, GPT, and other LLM-based agents to discover, evaluate, and reason about alternative sports leagues.

## Quick Start

```bash
# Install dependencies
uv sync

# Run the MCP server (stdio transport)
uv run python server.py
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `API_BASE_URL` | `https://api.altsportsleagues.ai` | Public API base URL |
| `ALTSPORTSLEAGUES_API_KEY` | (empty) | API key for authenticated endpoints |
| `SUPABASE_URL` | `https://gfzefuwlegzywletgood.supabase.co` | Supabase project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | (empty) | Supabase service role key (for context/assessment tools) |

Set these in the monorepo root `.env` file or export them directly.

## Architecture

```
server.py              FastMCP app -- registers all 35 tools
config.py              Environment config, Supabase client singleton
api_client.py          Async httpx wrapper for the public API

tools/
  discovery.py         6 tools -- find and research leagues (API proxy)
  valuation.py         4 tools -- score, tier, partnership eval (API proxy)
  fingerprinting.py    4 tools -- league DNA profiling (API proxy)
  onboarding.py        4 tools -- pipeline visibility, read-only (API proxy)
  assessment.py        7 tools -- readiness, archetype, edge cases (API proxy + Supabase)
  context.py           5 tools -- full intelligence assembly (Supabase direct)
  timeseries.py        5 tools -- valuation history, market index (API proxy)
```

### Data Sources

- **API proxy tools** call `api.altsportsleagues.ai` via `api_client.py`
- **Supabase direct tools** (context, assessment) query the `leagues` and `league_valuation_snapshots` tables directly for maximum data freshness
- **Market data tools** call `/v1/market-data/*` endpoints (being added to the public API)

## Tools Reference (35 total)

### Discovery (6 tools)
| Tool | Description |
|------|-------------|
| `discover_leagues` | AI-powered search for leagues by natural language query |
| `research_league` | Deep research a specific league (web scraping, social analysis) |
| `list_discovered_leagues` | Browse all previously discovered leagues |
| `get_market_opportunities` | Identify underserved sport verticals and regions |
| `get_discovery_stats` | Aggregate pipeline statistics |
| `get_trending_discoveries` | Trending sports and geographic hotspots |

### Valuation (4 tools)
| Tool | Description |
|------|-------------|
| `evaluate_league` | Full multi-dimensional valuation (0-1000 score, Tier 1.1-4.9) |
| `get_tier_definitions` | Tier system definitions and criteria |
| `score_partnership` | Multi-factor partnership opportunity scoring |
| `get_qualification_matrix` | Decision matrix for fast-track / invest / pass |

### Fingerprinting (4 tools)
| Tool | Description |
|------|-------------|
| `generate_fingerprint` | Create a league DNA profile |
| `get_fingerprint` | Retrieve existing fingerprint |
| `search_similar_leagues` | Find leagues with similar profiles |
| `check_fingerprint_quality` | Assess fingerprint completeness |

### Onboarding (4 tools)
| Tool | Description |
|------|-------------|
| `get_questionnaire_status` | Questionnaire processing status |
| `get_onboarding_progress` | Per-league pipeline progress and blockers |
| `get_pipeline_overview` | All leagues in pipeline, stage breakdown |
| `get_onboarding_stats` | Aggregate onboarding metrics and trends |

### Assessment (7 tools)
| Tool | Description |
|------|-------------|
| `generate_readiness_report` | Full 6-dimension readiness report (0-1000) |
| `classify_sport_archetype` | Classify into 5 archetypes (Combat/Racing/Action/Precision/Team) |
| `identify_edge_cases` | Sport-specific betting edge cases and mitigations |
| `detect_trading_anomalies` | Anomaly patterns and integrity risk scoring |
| `rank_league_maturity` | Maturity grade (A-F) and production readiness |
| `get_kb_catalog_alignment` | Schema coverage vs ASD canonical data model |
| `assess_league_readiness` | 5-dimension readiness with certification eligibility |

### Context (5 tools)
| Tool | Description |
|------|-------------|
| `get_league_context` | Complete intelligence context (the "tell me everything" tool) |
| `compare_leagues` | Side-by-side multi-league comparison |
| `query_leagues` | Filter/search leagues by archetype, tier, status, text |
| `get_league_documents` | All uploaded documents for a league |
| `get_data_coverage` | Scraped-vs-verified field-level coverage map |

### Market Data / Time Series (5 tools)
| Tool | Description |
|------|-------------|
| `get_league_snapshots` | Historical valuation time series (stock chart style) |
| `get_league_quarterly_report` | SEC 10-Q style quarterly report |
| `get_league_momentum` | Top movers and decliners market-wide |
| `get_league_index` | Aggregate market index by archetype |
| `compare_league_trajectories` | Head-to-head trajectory comparison |

## Typical Agent Workflows

**"What leagues are out there?"**
`discover_leagues` -> `research_league` -> `classify_sport_archetype`

**"Is this league worth pursuing?"**
`get_league_context` -> `evaluate_league` -> `score_partnership` -> `generate_readiness_report`

**"Compare these two candidates"**
`compare_leagues` -> `compare_league_trajectories` -> `get_data_coverage` (per league)

**"What's trending in the market?"**
`get_league_index` -> `get_league_momentum` -> `get_trending_discoveries`

## API Endpoints Mapped

| MCP Tool Module | Backend Endpoints |
|----------------|-------------------|
| discovery | `/v1/discovery/*` |
| valuation | `/v1/valuation/*`, `/v1/partnership-scorer/*`, `/v1/qualification/*` |
| fingerprinting | `/v1/fingerprint/*` |
| onboarding | `/v1/onboarding/*` |
| assessment | `/mcp/valuation/*` (internal MCP endpoints) |
| context | Supabase direct (leagues, league_valuation_snapshots, league_documents) |
| timeseries | `/v1/market-data/*` |
