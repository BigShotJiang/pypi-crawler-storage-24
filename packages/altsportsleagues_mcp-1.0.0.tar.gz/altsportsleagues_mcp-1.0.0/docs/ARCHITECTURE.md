# AltSportsLeagues MCP — Architecture & Vision

## Purpose

The league intelligence layer for AltSportsLeagues. Enables AI agents (Claude, Avery) and eventually external developers (SDK) to deeply query, assess, and reason about alternative sports leagues — their data, readiness, and partnership potential.

## Business Context

ASD = intelligent data glue between alt sports leagues (supply) and sportsbooks (demand).

**Core loop:** Find leagues → Assess them → Certify data quality → Connect to sportsbooks → Revenue share

**The product is the intelligence**, not the API endpoints. The MCP/SDK surfaces that intelligence to different consumers.

## Data Duality: Scraped vs Verified

Every league in the system has up to two data layers:

### Layer 1: Scraped / Discovered
- **Source:** ASD research, web scraping, AI discovery
- **Confidence:** Low-to-medium (best guess)
- **Flags:** `source_type=scraped`, `discovery_classification=scraped`, `verification_status=unverified`
- **Contains:** Estimated fan counts, guessed sport archetype, web-scraped social numbers, no API credentials

### Layer 2: League-Submitted / Verified
- **Source:** League owner via questionnaire, uploaded docs, API credentials
- **Confidence:** High (authoritative, first-party)
- **Flags:** `source_type=questionnaire/manual`, `discovery_classification=league_partner`, `verification_status=verified`
- **Contains:** Real contacts, real rosters, API keys, season schedules, compliance docs, financial data

### The Assessment Gap
The readiness workflow measures **how much of Layer 1 has been replaced/confirmed by Layer 2**. Each scoring dimension improves as scraped data gets replaced by verified data. The tier moves from estimated to certified.

## Readiness Report (0-1000 score)

Three inputs combine into the readiness score:

1. **API Valuation** — discover API → validate → test endpoints → schema alignment vs kb_catalog → edge cases → trading anomalies
2. **Sportsbook Preference Score** — archetype fit (which sportsbooks want this sport type?) + market coverage potential
3. **Questionnaire Completeness** — 7 sections scored, confidence tiers per field (🟢manual 🔵RAG 🟡AI)

### 6 Scoring Dimensions
| Dimension | Weight | Max Points |
|-----------|--------|------------|
| Market Potential | 25% | 250 |
| Data Quality | 20% | 200 |
| Betting Readiness | 20% | 200 |
| Fan Engagement | 15% | 150 |
| Operational Maturity | 10% | 100 |
| Risk Deductions | 10% | 100 |

### Output
- ASD Certificate Tier 1.1-4.9
- Value vs Friction matrix (fast-track / invest / pass)
- Per-dimension breakdown with recommendations

## 5 Assessment Panels (Internal UI Workflow)

The League Notebook's right panel dropdown:

1. ⚡ **API Assessment** — schema/column mappings (their fields → our fields)
2. ✨ **League Assets** — generate + curate actual data records
3. 🖥 **DTO Mapping** — data → canonical transfer objects (WHO × WHEN × WHAT × HISTORY)
4. 📊 **Bettable Markets** — H2H / Brackets / Score-based / Props / Futures, per-market qualification
5. 📄 **Required Documents** — 21 doc types, quality scoring (great/good/minimal/insufficient)

## 5 Sport Archetypes

| Archetype | Examples | Key Edge Cases |
|-----------|----------|----------------|
| Combat | MMA, Boxing, Kickboxing | No contest, DQ, doctor stoppage |
| Racing | F1, NASCAR, MotoGP | Safety car, red flags, race delays |
| Action/Heat | Surfing, Skateboarding, BMX | Weather, heat elimination, judging |
| Precision | Golf, Darts, Pickleball | Weather delays, playoff holes, withdrawals |
| Team | Lacrosse, Rugby, Handball | Overtime, shootouts, weather delays |

## Tier System

| Tier | Contract Value | Description |
|------|---------------|-------------|
| T0 Elite | $500K+ | Premier leagues |
| T1 Premium | $25K-$125K | High-value, clean data |
| T2 Professional | $0-$65K | Good data, some work needed |
| T3 Standard | $0-$28K | Basic integration |
| T4 Enterprise CV | $50K-$400K | Requires video/CV pipeline |

4 pricing flavors per tier: FRIENDLY / DEAL / STICK / RETAIL

## Architecture: MCP → SDK → Shared Data Layer

```
┌─────────────────────────────────────────┐
│          Consumer Surfaces              │
│                                         │
│  Claude (MCP)    SDK (REST)    UI       │
│  "ask anything"  programmatic  panels   │
└────────────┬─────────┬──────────┬───────┘
             │         │          │
        ┌────▼─────────▼──────────▼────┐
        │     Shared Data Layer        │
        │                              │
        │  context.get_league()        │
        │  context.compare_leagues()   │
        │  context.query_leagues()     │
        │  assessment.readiness()      │
        │  assessment.maturity()       │
        │                              │
        └──────────────┬───────────────┘
                       │
        ┌──────────────▼───────────────┐
        │        Data Sources          │
        │                              │
        │  Supabase  (leagues, scores, │
        │   questionnaires, docs)      │
        │  Neo4j     (graph, relations)│
        │  pg_vector (fingerprints)    │
        │  Backend API (valuation,     │
        │   discovery, assessment)     │
        │  Storage   (PDFs, specs)     │
        └─────────────────────────────┘
```

The MCP is the prototype of the shared data layer. When the SDK ships, the MCP becomes a thin wrapper around it.

## MCP Tool Modules

### Current (✅ done)
| Module | Tools | Source | Purpose |
|--------|-------|--------|---------|
| discovery.py | 6 | API proxy | Find and research leagues |
| valuation.py | 4 | API proxy | Score and classify |
| fingerprinting.py | 4 | API proxy | Profile and compare |
| onboarding.py | 4 | API proxy | Pipeline visibility (read-only) |

### Planned
| Module | Tools | Source | Purpose |
|--------|-------|--------|---------|
| assessment.py | ~7 | API proxy + Supabase | Readiness reports, archetype, edge cases, maturity |
| context.py | ~5 | Supabase direct + API | Full league context assembly, comparison, data coverage |
| data/supabase.py | — | Supabase direct | Shared query layer for context + assessment |
| data/documents.py | — | Supabase storage | Fetch/search uploaded docs + extracted text |

## League Valuation Time Series (Stock Market of Leagues)

### Existing Infrastructure
- **`league_valuation_snapshots`** table in Supabase — stores weekly/monthly/quarterly/annual snapshots
- **`frontend-discovery-leagues-experimental-leagues-as-a-stock-market`** — full Bloomberg-style UI already built
- **Snapshot engine** computes 6 weighted dimensions per snapshot
- **Filing labels** (Q1 2026, etc.) — SEC-style quarterly reports

### 6 Valuation Dimensions (per snapshot)
| Dimension | Weight | What it Measures |
|-----------|--------|-----------------|
| Social Growth & Sentiment | 25% | Mentions, followers, engagement, viral moments |
| Player Contract Values | 20% | Total contract value, player earnings, tier distribution |
| Sponsorship Revenue | 20% | Active sponsors, deal values, renewals |
| Events Impact | 15% | Upcoming events, championship cycles, viewership |
| Seasonality | 10% | Season phase, partnership windows, off-season value |
| Demographics | 10% | Age range, income, geographic reach, betting propensity |

### Per-League Data
- `valuation_score` (0-100), `previous_score`, `score_change`
- `growth_trajectory`: rapid_expansion / strong_growth / steady / declining
- `momentum_score` (0-100), `volatility_index` (0-100)
- `investment_grade`: AAA through C
- `recommended_action`: invest-now / evaluate / monitor / pass
- `data_confidence` (0-1), `data_kind` (observed/estimated/extrapolated)
- `executive_summary`, `key_highlights`, `risk_factors`, `forward_guidance`
- `social_signals` JSONB, `demographics` JSONB, `upcoming_events` JSONB

### Sportsbook Product Vision
Two views for sportsbook customers:

**View 1: Certified Network** — leagues that have completed onboarding
- Verified data (Layer 2), certified readiness, known tier + pricing
- Ready to integrate — sign the deal

**View 2: Opportunities** — discovered leagues not yet onboarded
- Estimated readiness from scraped data
- `request_onboarding()` — sportsbook says "I want this league"
- Creates qualified lead with buyer already attached
- Demand signal drives ASD's league acquisition priority

### Tokenization Roadmap
```
Phase 1 (NOW):     Score leagues → store snapshots → show trends via MCP
Phase 2 (NEXT):    Sportsbooks request leagues → demand signals → priority queue
Phase 3 (FUTURE):  Tokenize league data rights → buy early, benefit from appreciation
                   → Secondary market for league data futures
```

## Auth Model

Same backend API (`api.altsportsleagues.ai`), different auth scopes:

| Role | Access | Used By |
|------|--------|---------|
| public | Discovery, valuation, fingerprinting | altsportsleagues-mcp, future SDK |
| league-owner | Onboarding, questionnaire, own data | League portal |
| sportsbook | League data feeds, coverage, events | Sportsbook SDK |
| admin | Everything | backend-internal MCP, admin UI |

Auth middleware on the backend enforces role → endpoint scoping.

## Internal MCP (`backend-internal`)

Same API, admin-scoped key. Exposes internal ops:
- Email processing (Gmail fetch, audit)
- Confluence/Trello
- Contract generation
- League CRUD
- n8n automation triggers
- Admin ops

NOT a separate API — just an MCP server with an admin API key pointing at the same backend.

## User Journeys

### Journey 1: Discovery — "What's out there?"
```
search/research → classify archetype → fingerprint → compare → rank opportunities
```

### Journey 2: Valuation — "How good is it?"
```
3 inputs (API valuation + sportsbook preference + questionnaire)
→ 6 dimensions scored → 0-1000 readiness → Tier 1.1-4.9
→ value/friction matrix → fast-track / invest / pass
```

### Journey 3: Deep Intelligence — "Tell me everything"
```
get_league_context() → assembled from all data sources
→ scraped vs verified coverage map
→ documents + extracted text
→ similar leagues + benchmarks
→ blocking items + recommendations
→ Claude reasons over the full picture
```

### Journey 4: Onboarding Monitoring — "Where are they in the pipeline?"
```
pipeline overview → per-league stage → blockers → time-in-stage
```

## Supabase Tables (Key)

- `leagues` — core table, scraped + verified data, scores JSONB
- `user_leagues` — league-owner submitted data
- `questionnaire_submissions` — structured questionnaire responses
- `league_documents` — uploaded file metadata
- `league_assessments` — readiness score history

## Key Endpoints (Backend API)

### Discovery
- `POST /v1/discovery/search` — AI-powered league search
- `POST /v1/discovery/research` — deep research on a league
- `GET /v1/discovery/leagues` — list discovered
- `GET /v1/discovery/opportunities` — market opportunities
- `GET /v1/discovery/stats/trending` — trending sports/regions

### Valuation
- `POST /v1/valuation/evaluate` — multi-dimensional scoring
- `GET /v1/valuation/tiers` — tier definitions
- `POST /v1/partnership-scorer/evaluate` — partnership fit
- `GET /v1/qualification/decision-matrix` — qualification criteria

### Fingerprinting
- `POST /v1/fingerprint/generate` — create profile
- `GET /v1/fingerprint/{league_id}` — get profile
- `POST /v1/fingerprint/search` — similarity search
- `POST /v1/fingerprint/quality` — completeness check

### Assessment (MCP Valuation Tools)
- `POST /mcp/valuation/readiness_report` — full readiness report
- `POST /mcp/valuation/classify_sport` — archetype classification
- `POST /mcp/valuation/edge_cases` — sport-specific edge cases
- `POST /mcp/valuation/trading_anomalies` — anomaly detection
- `POST /mcp/valuation/league_maturity` — maturity ranking
- `POST /mcp/valuation/kb_catalog_alignment` — schema coverage

### Onboarding (read-only)
- `GET /v1/onboarding/questionnaires/{id}` — questionnaire status
- `GET /v1/onboarding/pipeline/{league_id}` — pipeline progress
- `GET /v1/onboarding/pipeline/overview` — all leagues in pipeline
- `GET /v1/onboarding/stats` — aggregate metrics
