# AltSportsLeagues MCP Server

MCP-compatible server for the AltSportsLeagues platform — league discovery, valuation, market intelligence, fingerprinting, onboarding pipeline visibility, and time-series market data for AI agents and sportsbooks.

## Quick Start

```bash
# Install
pip install altsportsleagues-mcp

# Run (stdio)
ALTSPORTSLEAGUES_API_KEY=your_key altsportsleagues-mcp

# Run (HTTP/SSE)
ALTSPORTSLEAGUES_API_KEY=your_key altsportsleagues-mcp --sse --port 8080
```

## Connect to Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "altsportsleagues": {
      "command": "altsportsleagues-mcp",
      "env": {
        "ALTSPORTSLEAGUES_API_KEY": "your_api_key",
        "SUPABASE_SERVICE_ROLE_KEY": "your_supabase_key"
      }
    }
  }
}
```

## Connect to Cursor

Create `.cursor/mcp.json` in your project root:

```json
{
  "mcpServers": {
    "altsportsleagues": {
      "command": "altsportsleagues-mcp",
      "env": {
        "ALTSPORTSLEAGUES_API_KEY": "your_api_key",
        "SUPABASE_SERVICE_ROLE_KEY": "your_supabase_key"
      }
    }
  }
}
```

## Connect to OpenClaw

```yaml
mcp:
  servers:
    altsportsleagues:
      command: altsportsleagues-mcp
      env:
        ALTSPORTSLEAGUES_API_KEY: your_api_key
        SUPABASE_SERVICE_ROLE_KEY: your_supabase_key
```

## Installation via npm

```bash
npx altsportsleagues-mcp
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ALTSPORTSLEAGUES_API_KEY` | Yes | Your AltSportsLeagues API key |
| `API_BASE_URL` | No | Override API base URL (default: https://api.altsportsleagues.ai) |
| `SUPABASE_URL` | No | Supabase project URL (for context tools) |
| `SUPABASE_SERVICE_ROLE_KEY` | No | Supabase service role key (for context tools) |

## Tools (36)

### Discovery (6)
| Tool | Description |
|------|-------------|
| `discover_leagues` | AI-powered search for alternative sports leagues |
| `research_league` | Deep-research a specific league |
| `list_discovered_leagues` | List all previously discovered leagues |
| `get_market_opportunities` | Identify underserved market opportunities |
| `get_discovery_stats` | Aggregate discovery pipeline statistics |
| `get_trending_discoveries` | Trending sports and regions |

### Valuation (4)
| Tool | Description |
|------|-------------|
| `evaluate_league` | Multi-dimensional league evaluation and tier assignment |
| `get_tier_definitions` | Tier classification system definitions |
| `score_partnership` | Score a potential partnership opportunity |
| `get_qualification_matrix` | Qualification decision matrix |

### Fingerprinting (4)
| Tool | Description |
|------|-------------|
| `generate_fingerprint` | Generate a unique DNA profile for a league |
| `get_fingerprint` | Retrieve an existing fingerprint profile |
| `search_similar_leagues` | Find leagues with similar profiles |
| `check_fingerprint_quality` | Check fingerprint quality and completeness |

### Onboarding Pipeline (4)
| Tool | Description |
|------|-------------|
| `get_questionnaire_status` | Questionnaire processing status |
| `get_onboarding_progress` | League onboarding pipeline progress |
| `get_pipeline_overview` | Full pipeline stage-by-stage breakdown |
| `get_onboarding_stats` | Aggregate onboarding statistics |

### Assessment (7)
| Tool | Description |
|------|-------------|
| `generate_readiness_report` | Full readiness report with composite score |
| `classify_sport_archetype` | Classify into 5 canonical archetypes |
| `identify_edge_cases` | Sport-specific edge cases for betting markets |
| `detect_trading_anomalies` | Trading anomaly and integrity risk detection |
| `rank_league_maturity` | Maturity and production readiness ranking |
| `get_kb_catalog_alignment` | Schema alignment check against ASD canonical schema |
| `assess_league_readiness` | 5-dimension readiness assessment via Supabase |

### Context (5)
| Tool | Description |
|------|-------------|
| `get_league_context` | Complete intelligence context assembly |
| `compare_leagues` | Side-by-side multi-league comparison |
| `query_leagues` | Flexible league search with filters |
| `get_league_documents` | All uploaded documents for a league |
| `get_data_coverage` | Scraped-vs-verified field coverage analysis |

### Market Data / Time-Series (5)
| Tool | Description |
|------|-------------|
| `get_league_snapshots` | Historical valuation snapshots |
| `get_league_quarterly_report` | SEC 10-Q style quarterly report |
| `get_league_momentum` | Top movers and decliners |
| `get_league_index` | Aggregate market index |
| `compare_league_trajectories` | Head-to-head trajectory comparison |

## License

MIT
