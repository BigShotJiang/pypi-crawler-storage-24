"""Configuration for AltSportsLeagues MCP Server"""

import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# --- Supabase (used by context + assessment tools that query directly) ---
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://gfzefuwlegzywletgood.supabase.co")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_SERVICE_ROLE") or os.getenv("SUPABASE_API_KEY", "")

# --- Public API (api.altsportsleagues.ai) ---
API_BASE_URL = os.getenv("API_BASE_URL", "https://api.altsportsleagues.ai")
API_KEY = os.getenv("ALTSPORTSLEAGUES_API_KEY", "")

_supabase_client = None


def get_supabase_client():
    global _supabase_client
    if _supabase_client is None:
        from supabase import create_client
        _supabase_client = create_client(SUPABASE_URL, SUPABASE_KEY)
    return _supabase_client
