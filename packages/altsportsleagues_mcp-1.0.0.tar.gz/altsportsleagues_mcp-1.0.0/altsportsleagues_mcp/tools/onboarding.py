"""Onboarding tools -- read-only visibility into questionnaire status and onboarding pipeline progress."""

from ..api_client import api_request


async def get_questionnaire_status(questionnaire_id: str) -> dict:
    """Get the processing status of a submitted league questionnaire.

    Returns the current state of a questionnaire submission: received,
    processing, completed, or error. Includes section-level completion
    percentages and confidence tiers per field (manual / RAG / AI).

    Args:
        questionnaire_id: UUID of the questionnaire submission.
    """
    return await api_request("GET", f"/v1/onboarding/questionnaires/{questionnaire_id}")


async def get_onboarding_progress(league_id: str) -> dict:
    """Get onboarding pipeline progress for a specific league.

    Returns the league's current onboarding stage (discovered, contacted,
    questionnaire_sent, questionnaire_received, under_review, certified,
    live), time-in-stage, completed steps, blocking items, and next
    actions required.

    Args:
        league_id: UUID of the league.
    """
    return await api_request("GET", f"/v1/onboarding/pipeline/{league_id}")


async def get_pipeline_overview() -> dict:
    """Get an overview of all leagues currently in the onboarding pipeline.

    Returns a stage-by-stage breakdown showing how many leagues are at
    each onboarding stage, average time-in-stage, bottlenecks, and
    recently progressed leagues. No parameters needed.
    """
    return await api_request("GET", "/v1/onboarding/pipeline/overview")


async def get_onboarding_stats() -> dict:
    """Get aggregate statistics about the onboarding pipeline.

    Returns total leagues onboarded, conversion rates by stage,
    average time-to-certification, success rates by sport archetype,
    and month-over-month trends. No parameters needed.
    """
    return await api_request("GET", "/v1/onboarding/stats")
