"""Assessment tools -- readiness reports, sport archetype classification, edge-case detection, and maturity ranking.

Most tools proxy to /mcp/valuation/* backend endpoints. assess_league_readiness
queries Supabase directly for maximum data freshness.
"""

from ..api_client import api_request
from ..config import get_supabase_client


async def generate_readiness_report(league_id: str) -> dict:
    """Generate a full readiness report for a league.

    Combines API valuation results, sportsbook preference scoring, and
    questionnaire completeness into a single 0-1000 composite score across
    6 weighted dimensions: Market Potential (25%, max 250), Data Quality
    (20%, max 200), Betting Readiness (20%, max 200), Fan Engagement
    (15%, max 150), Operational Maturity (10%, max 100), Risk Deductions
    (10%, max 100).

    Returns the composite score, per-dimension breakdown, ASD Certificate
    Tier (1.1-4.9), value-vs-friction classification (fast-track / invest /
    pass), and actionable recommendations.

    Args:
        league_id: UUID of the league.
    """
    try:
        return await api_request("POST", "/mcp/valuation/readiness_report", json={
            "questionnaire_data": {"league_id": league_id}
        })
    except Exception as e:
        return {"error": f"Failed to generate readiness report: {str(e)}"}


async def classify_sport_archetype(sport_type: str, league_name: str = None) -> dict:
    """Classify a sport into one of 5 canonical archetypes.

    The 5 archetypes are: Combat (MMA, boxing), Racing (F1, NASCAR),
    Action/Heat (surfing, skateboarding), Precision (golf, darts),
    and Team (lacrosse, rugby). Each archetype has distinct edge cases,
    betting market structures, and data requirements.

    Returns the archetype classification, confidence level, key
    characteristics, and sport-specific edge cases to watch for.

    Args:
        sport_type: Sport type string (e.g. "kickboxing", "drone racing").
        league_name: Optional league name for context-aware classification.
    """
    try:
        payload = {"sport_type": sport_type}
        if league_name:
            payload["league_name"] = league_name
        return await api_request("POST", "/mcp/valuation/classify_sport", json=payload)
    except Exception as e:
        return {"error": f"Failed to classify sport archetype: {str(e)}"}


async def identify_edge_cases(sport_type: str, market_preferences: list[str] = None) -> dict:
    """Identify sport-specific edge cases that affect betting market integrity.

    Analyzes a sport type for known edge cases: race delays, no contests,
    weather disruptions, disqualifications, judging controversies, injury
    stoppages, etc. Each edge case includes severity, frequency, affected
    betting markets, and mitigation strategies.

    Optionally filter by specific market types (H2H, props, futures, etc.).

    Args:
        sport_type: Sport type string.
        market_preferences: Optional list of betting market types to focus on.
    """
    try:
        payload = {"sport_type": sport_type}
        if market_preferences:
            payload["market_preferences"] = market_preferences
        return await api_request("POST", "/mcp/valuation/edge_cases", json=payload)
    except Exception as e:
        return {"error": f"Failed to identify edge cases: {str(e)}"}


async def detect_trading_anomalies(sport_type: str, api_url: str = None) -> dict:
    """Detect potential trading anomalies and integrity risks for a sport.

    Analyzes a sport type for known anomaly patterns: suspicious odds
    movements, market suspension triggers, data feed gaps, timing
    irregularities, and result manipulation indicators.

    Returns anomaly patterns, suggested alert rules, and an overall risk score.

    Args:
        sport_type: Sport type string.
        api_url: Optional URL of the league's data API for live analysis.
    """
    try:
        payload = {"sport_type": sport_type}
        if api_url:
            payload["api_url"] = api_url
        return await api_request("POST", "/mcp/valuation/trading_anomalies", json=payload)
    except Exception as e:
        return {"error": f"Failed to detect trading anomalies: {str(e)}"}


async def rank_league_maturity(league_name: str, api_score: float, schema_alignment: float, sport_type: str) -> dict:
    """Rank a league's maturity and production readiness.

    Takes key league metrics and produces a maturity assessment: overall
    maturity score, letter grade (A-F), production readiness level, and
    market position tier (Tier 1-4). Useful for prioritizing which leagues
    to onboard first.

    Args:
        league_name: Name of the league.
        api_score: API quality/availability score (0.0-1.0).
        schema_alignment: How well the league's data maps to ASD canonical schema (0.0-1.0).
        sport_type: Sport type string.
    """
    try:
        return await api_request("POST", "/mcp/valuation/league_maturity", json={
            "league_name": league_name,
            "api_score": api_score,
            "schema_alignment": schema_alignment,
            "sport_type": sport_type,
        })
    except Exception as e:
        return {"error": f"Failed to rank league maturity: {str(e)}"}


async def get_kb_catalog_alignment(api_url: str, league_name: str = None) -> dict:
    """Check how well a league's API aligns with ASD's canonical kb_catalog schema.

    Probes the league's API and maps its data structures against the ASD
    canonical schema (WHO x WHEN x WHAT x HISTORY). Returns coverage score,
    matched schemas, missing schemas, data gaps, and an integration
    complexity estimate (simple / moderate / complex / custom).

    Args:
        api_url: URL of the league's data API to analyze.
        league_name: Optional league name for context.
    """
    try:
        payload = {"api_url": api_url}
        if league_name:
            payload["league_name"] = league_name
        return await api_request("POST", "/mcp/valuation/kb_catalog_alignment", json=payload)
    except Exception as e:
        return {"error": f"Failed to check kb_catalog alignment: {str(e)}"}


async def assess_league_readiness(league_id: str, assessment_type: str = "full") -> dict:
    """Assess a league's readiness across 5 dimensions using live Supabase data.

    Queries the league record directly and computes scores for:
    Data Readiness (25%) -- profile field completeness, API availability, social presence.
    Technical Readiness (20%) -- API quality, schema alignment.
    Business Readiness (20%) -- reach, broadcast partners, social following.
    Operational Readiness (20%) -- event cadence, roster depth.
    Market Readiness (15%) -- opportunity score, priority score.

    Returns an overall score, certification eligibility (premium / standard /
    provisional / not_eligible), per-dimension breakdowns, and specific
    recommendations for improvement.

    Args:
        league_id: UUID of the league.
        assessment_type: Assessment scope -- "full" (default) for all dimensions.
    """
    try:
        client = get_supabase_client()
        result = client.table("leagues").select("*").eq("id", league_id).execute()

        if not result.data:
            return {"error": f"League {league_id} not found"}

        league = result.data[0]
        scores = league.get("scores") or {}
        enrichment = league.get("enrichment_data") or {}

        # --- Data Readiness (weight: 25%) ---
        data_fields = ["league_name", "sport_type", "website", "country", "founded_year",
                       "participant_count", "social_media", "contact_email"]
        populated = sum(1 for f in data_fields if league.get(f))
        data_completeness = populated / len(data_fields)

        has_api = bool(enrichment.get("api_url") or league.get("api_url"))
        has_social = bool(league.get("social_media"))
        data_readiness = round((data_completeness * 60 + (20 if has_api else 0) + (20 if has_social else 0)), 1)

        # --- Technical Readiness (weight: 20%) ---
        api_score = scores.get("openness", 0) or 0
        schema_score = enrichment.get("schema_alignment", 0) or 0
        tech_readiness = round(min(100, api_score * 50 + schema_score * 50), 1)

        # --- Business Readiness (weight: 20%) ---
        reach = scores.get("reach", 0) or 0
        broadcast = scores.get("broadcast", 0) or 0
        social = scores.get("social", 0) or 0
        business_readiness = round(min(100, (reach + broadcast + social) / 3 * 100), 1)

        # --- Operational Readiness (weight: 20%) ---
        cadence = scores.get("cadence", 0) or 0
        roster = scores.get("roster", 0) or 0
        operational_readiness = round(min(100, (cadence + roster) / 2 * 100), 1)

        # --- Market Readiness (weight: 15%) ---
        opportunity = scores.get("opportunity_score", 0) or 0
        priority = scores.get("priority_score", 0) or 0
        market_readiness = round(min(100, (opportunity + priority) / 2 * 100), 1)

        # --- Overall ---
        overall = round(
            data_readiness * 0.25 +
            tech_readiness * 0.20 +
            business_readiness * 0.20 +
            operational_readiness * 0.20 +
            market_readiness * 0.15,
            1
        )

        # --- Certification ---
        dims = [data_readiness, tech_readiness, business_readiness, operational_readiness, market_readiness]
        min_dim = min(dims)

        if overall >= 80 and min_dim >= 70:
            certification = "premium"
        elif overall >= 65 and min_dim >= 60:
            certification = "standard"
        elif overall >= 50 and min_dim >= 50:
            certification = "provisional"
        else:
            certification = "not_eligible"

        # --- Recommendations ---
        recommendations = []
        if data_readiness < 60:
            recommendations.append("Improve data completeness -- fill missing league profile fields")
        if tech_readiness < 60:
            recommendations.append("Improve API coverage or schema alignment for technical readiness")
        if business_readiness < 60:
            recommendations.append("Grow reach, broadcast, or social presence for business readiness")
        if operational_readiness < 60:
            recommendations.append("Increase event cadence and roster depth for operational readiness")
        if market_readiness < 60:
            recommendations.append("Improve opportunity and priority scores for market readiness")

        return {
            "league_id": league_id,
            "league_name": league.get("league_name"),
            "assessment_type": assessment_type,
            "overall_score": overall,
            "certification": certification,
            "dimensions": {
                "data_readiness": data_readiness,
                "technical_readiness": tech_readiness,
                "business_readiness": business_readiness,
                "operational_readiness": operational_readiness,
                "market_readiness": market_readiness,
            },
            "recommendations": recommendations,
        }
    except Exception as e:
        return {"error": f"Failed to assess league readiness: {str(e)}"}
