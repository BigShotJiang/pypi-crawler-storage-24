"""Context tools -- full league intelligence assembly from Supabase.

These tools query Supabase directly (not via the public API) to assemble
comprehensive league context, run comparisons, and analyze data coverage.
They form the primary "tell me everything about this league" capability.
"""

from ..config import get_supabase_client


# Fields expected on a league record for coverage analysis
_LEAGUE_FIELDS = [
    "league_name", "sport_type", "sport_archetype", "website", "country",
    "region", "founded_year", "participant_count", "event_count",
    "social_media", "contact_email", "contact_name", "phone",
    "broadcast_partners", "sponsors", "api_url", "description",
    "logo_url", "tier", "readiness_score",
]

_SCRAPED_INDICATORS = {"scraped", "discovered", "auto"}
_VERIFIED_INDICATORS = {"verified", "confirmed", "manual", "submitted"}


def _compute_data_coverage(league: dict) -> dict:
    """Analyze which fields are populated and classify as scraped vs verified."""
    populated = []
    missing = []
    for f in _LEAGUE_FIELDS:
        val = league.get(f)
        if val is not None and val != "" and val != [] and val != {}:
            populated.append(f)
        else:
            missing.append(f)

    source_type = (league.get("source_type") or "").lower()
    verification = (league.get("verification_status") or "").lower()

    is_verified = verification in _VERIFIED_INDICATORS
    is_scraped = source_type in _SCRAPED_INDICATORS and not is_verified

    return {
        "total_fields": len(_LEAGUE_FIELDS),
        "populated_fields": len(populated),
        "missing_fields": missing,
        "coverage_pct": round(len(populated) / len(_LEAGUE_FIELDS) * 100, 1) if _LEAGUE_FIELDS else 0,
        "data_origin": "verified" if is_verified else ("scraped" if is_scraped else "unknown"),
        "source_type": league.get("source_type"),
        "verification_status": league.get("verification_status"),
    }


async def get_league_context(league_id: str) -> dict:
    """Assemble the complete intelligence context for a league.

    This is the primary "tell me everything" tool. Pulls the full league
    record, scores, recent valuation snapshots, and computes a scraped-vs-
    verified data coverage analysis. Returns all data needed for deep
    reasoning about a league's current state, readiness, and potential.

    Includes: core profile, all scores, enrichment data, sport archetype,
    tier, onboarding stage, discovery classification, verification status,
    and the last 4 valuation snapshots.

    Args:
        league_id: UUID of the league.
    """
    try:
        client = get_supabase_client()

        # 1. Core league record
        league_result = client.table("leagues").select("*").eq("id", league_id).execute()
        if not league_result.data:
            return {"error": f"League {league_id} not found"}
        league = league_result.data[0]

        # 2. Scores from JSONB column
        scores = league.get("scores")

        # 3. Latest valuation snapshots
        snapshots_result = client.table("league_valuation_snapshots").select("*").eq("league_id", league_id).order("snapshot_date", desc=True).limit(4).execute()

        # 4. Data coverage analysis
        data_coverage = _compute_data_coverage(league)

        return {
            "league": league,
            "scores": scores,
            "data_coverage": data_coverage,
            "recent_snapshots": snapshots_result.data if snapshots_result.data else [],
            "source_type": league.get("source_type"),
            "verification_status": league.get("verification_status"),
            "discovery_classification": league.get("discovery_classification"),
            "sport_archetype": league.get("sport_archetype"),
            "tier": league.get("tier"),
            "onboarding_stage": league.get("onboarding_stage"),
            "enrichment_data": league.get("enrichment_data"),
        }
    except Exception as e:
        return {"error": f"Failed to get league context: {str(e)}"}


async def compare_leagues(league_ids: list[str]) -> dict:
    """Side-by-side comparison of multiple leagues.

    Takes a list of league UUIDs and returns a comparison table with each
    league's name, sport type, archetype, tier, readiness score, onboarding
    stage, scores, data coverage percentage, data origin (scraped/verified),
    latest valuation score, score change, growth trajectory, and latest quarter.

    Use this when evaluating multiple partnership candidates or benchmarking
    leagues within a sport vertical.

    Args:
        league_ids: List of league UUIDs to compare (2-10 recommended).
    """
    try:
        client = get_supabase_client()

        # Fetch all leagues
        leagues_result = client.table("leagues").select("*").in_("id", league_ids).execute()
        if not leagues_result.data:
            return {"error": "No leagues found for the given IDs"}

        # Fetch latest snapshot per league
        comparisons = []
        for league in leagues_result.data:
            lid = league["id"]
            snap_result = client.table("league_valuation_snapshots").select("valuation_score, score_change, filing_label, snapshot_date, growth_trajectory").eq("league_id", lid).order("snapshot_date", desc=True).limit(1).execute()

            latest_snap = snap_result.data[0] if snap_result.data else {}
            scores = league.get("scores") or {}
            coverage = _compute_data_coverage(league)

            comparisons.append({
                "league_id": lid,
                "league_name": league.get("league_name"),
                "sport_type": league.get("sport_type"),
                "sport_archetype": league.get("sport_archetype"),
                "tier": league.get("tier"),
                "readiness_score": league.get("readiness_score"),
                "onboarding_stage": league.get("onboarding_stage"),
                "scores": scores,
                "data_coverage_pct": coverage["coverage_pct"],
                "data_origin": coverage["data_origin"],
                "latest_valuation": latest_snap.get("valuation_score"),
                "score_change": latest_snap.get("score_change"),
                "growth_trajectory": latest_snap.get("growth_trajectory"),
                "latest_quarter": latest_snap.get("filing_label"),
            })

        return {"leagues": comparisons, "count": len(comparisons)}
    except Exception as e:
        return {"error": f"Failed to compare leagues: {str(e)}"}


async def query_leagues(
    sport_archetype: str = None,
    tier_range: str = None,
    verification_status: str = None,
    search: str = None,
    limit: int = 20,
) -> dict:
    """Query and filter leagues from the database.

    Flexible search across all leagues with smart filters. Combine any
    filters to narrow results. Returns league summaries sorted by most
    recently updated.

    Filter options:
    - sport_archetype: combat, racing, action_heat, precision, team
    - tier_range: e.g. "1.0-2.9" for Tier 1-2 leagues
    - verification_status: "verified" or "unverified"
    - search: free-text search across league name and sport type

    Args:
        sport_archetype: Filter by archetype (combat/racing/action_heat/precision/team).
        tier_range: Tier range string like "1.0-2.9".
        verification_status: Filter by verification status.
        search: Free-text search string.
        limit: Maximum results (default 20).
    """
    try:
        client = get_supabase_client()
        query = client.table("leagues").select(
            "id, league_name, sport_type, sport_archetype, tier, source_type, "
            "discovery_classification, verification_status, scores, readiness_score, "
            "onboarding_stage, created_at, updated_at"
        )

        if sport_archetype:
            query = query.ilike("sport_archetype", f"%{sport_archetype}%")

        if tier_range:
            parts = tier_range.split("-")
            if len(parts) == 2:
                try:
                    low, high = float(parts[0]), float(parts[1])
                    query = query.gte("tier", low).lte("tier", high)
                except ValueError:
                    pass

        if verification_status:
            query = query.eq("verification_status", verification_status)

        if search:
            query = query.or_(f"league_name.ilike.%{search}%,sport_type.ilike.%{search}%")

        query = query.limit(limit).order("updated_at", desc=True)
        result = query.execute()

        return {"leagues": result.data if result.data else [], "count": len(result.data) if result.data else 0}
    except Exception as e:
        return {"error": f"Failed to query leagues: {str(e)}"}


async def get_league_documents(league_id: str) -> dict:
    """Get all uploaded documents for a league.

    Returns metadata for all documents associated with the league: PDFs,
    compliance documents, API specification files, questionnaire responses,
    financial statements, etc. Includes document type, upload date, file
    size, and processing status.

    Args:
        league_id: UUID of the league.
    """
    try:
        client = get_supabase_client()
        result = client.table("league_documents").select("*").eq("league_id", league_id).order("created_at", desc=True).execute()
        return {
            "league_id": league_id,
            "documents": result.data if result.data else [],
            "count": len(result.data) if result.data else 0,
        }
    except Exception as e:
        return {"error": f"Failed to get league documents: {str(e)}"}


async def get_data_coverage(league_id: str) -> dict:
    """Get a detailed scraped-vs-verified field map for a league.

    Analyzes every profile field to show which are populated vs empty,
    and classifies the data origin (scraped / verified / unknown). Returns
    a per-field breakdown with value previews and an aggregate coverage
    percentage. Useful for understanding data confidence and identifying
    what still needs verification.

    Args:
        league_id: UUID of the league.
    """
    try:
        client = get_supabase_client()
        result = client.table("leagues").select("*").eq("id", league_id).execute()
        if not result.data:
            return {"error": f"League {league_id} not found"}

        league = result.data[0]
        coverage = _compute_data_coverage(league)

        # Build per-field detail
        field_details = {}
        for f in _LEAGUE_FIELDS:
            val = league.get(f)
            has_value = val is not None and val != "" and val != [] and val != {}
            field_details[f] = {
                "populated": has_value,
                "value_preview": str(val)[:100] if has_value else None,
                "origin": coverage["data_origin"],
            }

        return {
            "league_id": league_id,
            "league_name": league.get("league_name"),
            "summary": coverage,
            "fields": field_details,
        }
    except Exception as e:
        return {"error": f"Failed to get data coverage: {str(e)}"}
