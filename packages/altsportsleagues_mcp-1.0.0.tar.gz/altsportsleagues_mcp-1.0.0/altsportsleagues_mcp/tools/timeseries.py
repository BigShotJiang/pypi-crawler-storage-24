"""Time-series tools -- valuation history, momentum, market index, and trajectory comparisons.

These tools call the /v1/market-data/* endpoints on the public AltSportsLeagues API.
They expose the "leagues as a stock market" view: historical snapshots, quarterly
reports (SEC 10-Q style), momentum/movers, aggregate index, and head-to-head
trajectory comparisons.
"""

from ..api_client import api_request


async def get_league_snapshots(league_id: str, limit: int = 8) -> dict:
    """Retrieve historical valuation snapshots for a league -- like a stock price chart.

    Returns a time series of valuation scores across 6 weighted dimensions
    (Social Growth 25%, Contract Values 20%, Sponsorship Revenue 20%,
    Events Impact 15%, Seasonality 10%, Demographics 10%).

    Each snapshot includes the composite score, per-dimension breakdowns,
    score change from previous period, growth trajectory classification,
    and data confidence level.

    Use this to understand how a league's value has changed over time.

    Args:
        league_id: UUID of the league.
        limit: Maximum number of snapshots to return (default 8, most recent first).
    """
    return await api_request(
        "GET",
        f"/v1/market-data/{league_id}/history",
        params={"limit": limit},
    )


async def get_league_quarterly_report(league_id: str, quarter: str | None = None) -> dict:
    """Retrieve an SEC 10-Q style quarterly report for a league.

    Returns the full valuation breakdown for a specific quarter:
    composite score (0-100), 6 dimension scores, financials (sponsorship
    totals, contract totals, projected revenue), quarter-over-quarter
    growth rates, social signals, demographics, upcoming events,
    seasonality phase, executive summary, key highlights, risk factors,
    forward guidance, recommended action, and data confidence.

    If no quarter is specified, returns the latest available report.

    Args:
        league_id: UUID of the league.
        quarter: Filing label such as "Q1 2026". Omit for latest.
    """
    params = {}
    if quarter:
        params["quarter"] = quarter
    return await api_request(
        "GET",
        f"/v1/market-data/{league_id}/snapshot",
        params=params,
    )


async def get_league_momentum() -> dict:
    """Retrieve the top movers and decliners across all leagues.

    Returns leagues ranked by recent score change -- the biggest
    gainers and biggest losers. Each entry includes the league name,
    sport archetype, current valuation score, score change, growth
    trajectory, and momentum classification (rapid_expansion,
    strong_growth, steady, declining).

    Use this to find which leagues are trending up or down right now.
    No parameters required -- returns the current market-wide movers.
    """
    return await api_request("GET", "/v1/market-data/movers")


async def get_league_index(archetype: str | None = None) -> dict:
    """Retrieve the aggregate league market index -- a stock-market-style summary.

    Returns total league count, per-archetype averages (avg valuation,
    avg score change), top movers, and top decliners. Optionally filter
    by sport archetype (combat, racing, action_heat, precision, team).

    Use this to get a birds-eye view of the entire league marketplace,
    or drill into a specific sport archetype vertical.

    Args:
        archetype: Optional sport archetype filter (e.g. "combat", "racing").
    """
    params = {}
    if archetype:
        params["archetype"] = archetype
    return await api_request("GET", "/v1/market-data/summary", params=params)


async def compare_league_trajectories(league_id_1: str, league_id_2: str) -> dict:
    """Head-to-head valuation trajectory comparison between two leagues.

    Returns side-by-side score histories showing how both leagues'
    valuations have evolved over recent quarters. Highlights diverging
    or converging trends, total change over the period, and current
    growth trajectories.

    Use this when a user asks "how does League A compare to League B
    over time?" or wants to evaluate two partnership candidates.

    Args:
        league_id_1: UUID of the first league.
        league_id_2: UUID of the second league.
    """
    return await api_request(
        "GET",
        f"/v1/market-data/compare/{league_id_1}/{league_id_2}",
    )
