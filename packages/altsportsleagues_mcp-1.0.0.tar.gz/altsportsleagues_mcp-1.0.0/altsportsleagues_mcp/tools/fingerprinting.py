"""Fingerprinting tools -- comprehensive league profiling, similarity search, and quality checks."""

from ..api_client import api_request


async def generate_fingerprint(league_id: str, force: bool = False) -> dict:
    """Generate a unique fingerprint profile for a league.

    Creates a multi-dimensional DNA profile capturing the league's sport
    archetype characteristics, data coverage, market positioning, fan
    demographics, operational maturity, and competitive landscape.
    The fingerprint enables similarity search and clustering.

    Set force=True to regenerate even if a fingerprint already exists.

    Args:
        league_id: UUID of the league to fingerprint.
        force: If True, regenerate the fingerprint from scratch.
    """
    return await api_request("POST", "/v1/fingerprint/generate", json={"league_id": league_id, "force": force})


async def get_fingerprint(league_id: str) -> dict:
    """Retrieve the existing fingerprint profile for a league.

    Returns the full fingerprint with archetype classification, dimensional
    scores, characteristic tags, and metadata. Returns an error if no
    fingerprint has been generated yet (use generate_fingerprint first).

    Args:
        league_id: UUID of the league.
    """
    return await api_request("GET", f"/v1/fingerprint/{league_id}")


async def search_similar_leagues(league_id: str, limit: int = 10) -> dict:
    """Find leagues with similar fingerprint profiles.

    Uses the league's fingerprint to search for the most similar leagues
    by archetype, operational maturity, market positioning, and data
    characteristics. Useful for benchmarking, competitive analysis,
    and finding comparable partnership candidates.

    Args:
        league_id: UUID of the reference league.
        limit: Maximum number of similar leagues to return (default 10).
    """
    return await api_request("POST", "/v1/fingerprint/search", json={"league_id": league_id, "limit": limit})


async def check_fingerprint_quality(league_id: str) -> dict:
    """Check the quality and completeness of a league's fingerprint.

    Analyzes which fingerprint dimensions are well-populated vs sparse,
    identifies data gaps that could improve the profile, and returns an
    overall quality score with recommendations for enrichment.

    Args:
        league_id: UUID of the league.
    """
    return await api_request("POST", "/v1/fingerprint/quality", json={"league_id": league_id})
