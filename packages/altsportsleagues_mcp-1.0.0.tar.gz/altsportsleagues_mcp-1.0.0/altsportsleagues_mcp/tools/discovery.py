"""Discovery tools -- find, research, and explore alternative sports leagues worldwide."""

from ..api_client import api_request


async def discover_leagues(query: str, filters: dict | None = None) -> dict:
    """Search for alternative sports leagues using AI-powered discovery.

    Accepts natural language queries like "combat sports in Southeast Asia"
    or "emerging racing leagues." Optionally pass structured filters for
    sport type, region, minimum fan count, etc.

    Returns a ranked list of matching leagues with summary profiles.

    Args:
        query: Natural language search query describing the leagues you want.
        filters: Optional dict of structured filters (sport, region, min_fans, etc.).
    """
    payload = {"query": query}
    if filters:
        payload["filters"] = filters
    return await api_request("POST", "/v1/discovery/search", json=payload)


async def research_league(league_name: str, sport: str | None = None, website: str | None = None) -> dict:
    """Deep-research a specific league to gather comprehensive intelligence.

    Takes a league name (and optionally its sport and website) and runs
    an AI research pipeline: web scraping, social media analysis, news
    coverage, competitive landscape, and data availability assessment.

    Returns a detailed intelligence dossier suitable for evaluation.

    Args:
        league_name: Full name of the league to research.
        sport: Sport type hint (e.g. "kickboxing", "drone racing").
        website: League website URL if known.
    """
    payload = {"league_name": league_name}
    if sport:
        payload["sport"] = sport
    if website:
        payload["website"] = website
    return await api_request("POST", "/v1/discovery/research", json=payload)


async def list_discovered_leagues(limit: int = 50, offset: int = 0) -> dict:
    """List all previously discovered leagues in the AltSportsLeagues database.

    Returns paginated league summaries ordered by discovery date.
    Use this to browse what has already been found before running new searches.

    Args:
        limit: Maximum number of results (default 50).
        offset: Pagination offset.
    """
    return await api_request("GET", "/v1/discovery/leagues", params={"limit": limit, "offset": offset})


async def get_market_opportunities() -> dict:
    """Identify current market opportunities across sports verticals.

    Returns a breakdown of underserved sport types, high-demand regions,
    and gaps where sportsbook demand exceeds available league supply.
    No parameters needed.
    """
    return await api_request("GET", "/v1/discovery/opportunities")


async def get_discovery_stats() -> dict:
    """Get aggregate statistics about the discovery pipeline.

    Returns total leagues discovered, breakdown by sport type and region,
    discovery velocity, and coverage metrics. No parameters needed.
    """
    return await api_request("GET", "/v1/discovery/stats")


async def get_trending_discoveries() -> dict:
    """Get trending sports and regions where new leagues are being discovered.

    Returns emerging sport types gaining traction, geographic hotspots
    with accelerating league creation, and recent discovery highlights.
    No parameters needed.
    """
    return await api_request("GET", "/v1/discovery/stats/trending")
