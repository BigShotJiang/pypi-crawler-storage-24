"""Valuation tools -- multi-dimensional league scoring, tier classification, and partnership evaluation."""

from ..api_client import api_request


async def evaluate_league(league_id: str, criteria: dict | None = None) -> dict:
    """Evaluate a league's value across multiple dimensions and assign a tier.

    Runs the full valuation model: Market Potential (25%), Data Quality (20%),
    Betting Readiness (20%), Fan Engagement (15%), Operational Maturity (10%),
    and Risk Deductions (10%). Produces a 0-1000 composite score and an
    ASD Certificate Tier (1.1 through 4.9).

    Optionally pass custom criteria weights or overrides.

    Args:
        league_id: UUID of the league to evaluate.
        criteria: Optional dict of custom evaluation criteria or weight overrides.
    """
    payload = {"league_id": league_id}
    if criteria:
        payload["criteria"] = criteria
    return await api_request("POST", "/v1/valuation/evaluate", json=payload)


async def get_tier_definitions() -> dict:
    """Get the tier classification system definitions and criteria.

    Returns all tier levels (T0 Elite through T4 Enterprise CV) with their
    score thresholds, contract value ranges, pricing flavors
    (FRIENDLY/DEAL/STICK/RETAIL), and qualifying criteria.
    No parameters needed.
    """
    return await api_request("GET", "/v1/valuation/tiers")


async def score_partnership(league_id: str, parameters: dict | None = None) -> dict:
    """Score a potential partnership opportunity with a league.

    Evaluates how well a league fits as a partnership candidate based on
    data quality, market demand, sportsbook interest, integration
    complexity, and revenue potential. Returns a multi-factor partnership
    score with recommendations.

    Args:
        league_id: UUID of the league to score.
        parameters: Optional dict of partnership-specific parameters or weights.
    """
    payload = {"league_id": league_id}
    if parameters:
        payload["parameters"] = parameters
    return await api_request("POST", "/v1/partnership-scorer/evaluate", json=payload)


async def get_qualification_matrix() -> dict:
    """Get the qualification decision matrix for league assessment.

    Returns the full decision matrix that maps league attributes to
    qualification outcomes: fast-track, invest, monitor, or pass.
    Includes dimension thresholds, weighting logic, and tier boundaries.
    No parameters needed.
    """
    return await api_request("GET", "/v1/qualification/decision-matrix")
