import httpx
from .config import API_BASE_URL, API_KEY

# Default timeout: 30s connect, 120s read (some endpoints do heavy AI work)
_TIMEOUT = httpx.Timeout(connect=30.0, read=120.0, write=30.0, pool=30.0)


async def api_request(method: str, path: str, **kwargs) -> dict:
    """Make an authenticated request to the AltSportsLeagues API.

    Automatically injects the API key header when configured and applies
    sensible timeouts for long-running intelligence endpoints.
    """
    headers = kwargs.pop("headers", {})
    if API_KEY:
        headers["Authorization"] = f"Bearer {API_KEY}"

    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        try:
            response = await client.request(
                method,
                f"{API_BASE_URL}{path}",
                headers=headers,
                **kwargs,
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            return {"error": f"API returned {e.response.status_code}", "detail": e.response.text}
        except httpx.RequestError as e:
            return {"error": f"Request failed: {str(e)}"}
