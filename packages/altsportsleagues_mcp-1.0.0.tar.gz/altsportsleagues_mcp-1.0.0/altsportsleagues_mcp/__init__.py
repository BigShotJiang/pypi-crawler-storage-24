"""AltSportsLeagues MCP Server"""
