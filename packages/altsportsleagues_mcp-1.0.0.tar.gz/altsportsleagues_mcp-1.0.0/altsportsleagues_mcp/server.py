from fastmcp import FastMCP
from .tools import discovery, valuation, fingerprinting, onboarding, assessment, context, timeseries

mcp = FastMCP(
    "AltSportsLeagues",
    instructions=(
        "AltSportsLeagues league intelligence platform. "
        "Use these tools to discover alternative sports leagues worldwide, "
        "evaluate their partnership and data-quality potential, generate "
        "comprehensive fingerprint profiles, track onboarding pipelines, "
        "run readiness assessments, assemble full league context from all "
        "data sources, and monitor valuation time-series like a stock market. "
        "Start with discovery or context tools, then drill deeper with "
        "valuation, fingerprinting, or assessment tools as needed."
    ),
)

# --- Discovery: Find and research leagues ---
mcp.tool()(discovery.discover_leagues)
mcp.tool()(discovery.research_league)
mcp.tool()(discovery.list_discovered_leagues)
mcp.tool()(discovery.get_market_opportunities)
mcp.tool()(discovery.get_discovery_stats)
mcp.tool()(discovery.get_trending_discoveries)

# --- Valuation: Score and classify leagues ---
mcp.tool()(valuation.evaluate_league)
mcp.tool()(valuation.get_tier_definitions)
mcp.tool()(valuation.score_partnership)
mcp.tool()(valuation.get_qualification_matrix)

# --- Fingerprinting: Profile and compare league DNA ---
mcp.tool()(fingerprinting.generate_fingerprint)
mcp.tool()(fingerprinting.get_fingerprint)
mcp.tool()(fingerprinting.search_similar_leagues)
mcp.tool()(fingerprinting.check_fingerprint_quality)

# --- Onboarding: Pipeline visibility (read-only) ---
mcp.tool()(onboarding.get_questionnaire_status)
mcp.tool()(onboarding.get_onboarding_progress)
mcp.tool()(onboarding.get_pipeline_overview)
mcp.tool()(onboarding.get_onboarding_stats)

# --- Assessment: Readiness reports, archetype, edge cases, maturity ---
mcp.tool()(assessment.generate_readiness_report)
mcp.tool()(assessment.classify_sport_archetype)
mcp.tool()(assessment.identify_edge_cases)
mcp.tool()(assessment.detect_trading_anomalies)
mcp.tool()(assessment.rank_league_maturity)
mcp.tool()(assessment.get_kb_catalog_alignment)
mcp.tool()(assessment.assess_league_readiness)

# --- Context: Full league intelligence assembly (Supabase direct) ---
mcp.tool()(context.get_league_context)
mcp.tool()(context.compare_leagues)
mcp.tool()(context.query_leagues)
mcp.tool()(context.get_league_documents)
mcp.tool()(context.get_data_coverage)

# --- Market Data: Valuation time-series, momentum, index (via /v1/market-data/*) ---
mcp.tool()(timeseries.get_league_snapshots)
mcp.tool()(timeseries.get_league_quarterly_report)
mcp.tool()(timeseries.get_league_momentum)
mcp.tool()(timeseries.get_league_index)
mcp.tool()(timeseries.compare_league_trajectories)

if __name__ == "__main__":
    mcp.run()


def main():
    """Run the MCP server."""
    import argparse
    parser = argparse.ArgumentParser(description="AltSportsLeagues MCP Server")
    parser.add_argument("--sse", action="store_true", help="Run as SSE server")
    parser.add_argument("--port", type=int, default=8080, help="SSE port")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="SSE host")
    args = parser.parse_args()

    if args.sse:
        mcp.run(transport="streamable-http", host=args.host, port=args.port)
    else:
        mcp.run(transport="stdio")
