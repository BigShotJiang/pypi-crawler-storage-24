from __future__ import annotations
from typing import TYPE_CHECKING, Any, Callable, Generic, Iterable, Iterator, TypeVar, overload

T = TypeVar('T')
from .Device import Device

if TYPE_CHECKING:
    from Live.Base import Vector
    from Live.DeviceParameter import DeviceParameter



class ATimeableValueVector(Vector[DeviceParameter]):

    def append(self, value: DeviceParameter | None, /) -> None:
        ...

    def extend(self, values: Iterable[DeviceParameter] | None, /) -> None:
        ...

class DeviceType(int):
    """The type of the device."""
    undefined: int = 0
    instrument: int = 1
    audio_effect: int = 2
    midi_effect: int = 4

__all__ = ['Device', 'ATimeableValueVector', 'DeviceType']
