from __future__ import annotations

import bisect
import heapq
import logging
import math
import statistics
from dataclasses import dataclass, field
from pathlib import Path

from .config.limits import UTILITY
from .types import Fragment, FragmentId
from .utility import InformationNeed, UtilityState, apply_fragment, compute_density, marginal_gain, utility_value

logger = logging.getLogger(__name__)

_BASELINE_K_MAX = 5
_CORE_BUDGET_FRACTION = 0.70


def _adaptive_baseline_k(n_candidates: int) -> int:
    return min(_BASELINE_K_MAX, math.ceil(0.1 * n_candidates))


@dataclass
class SelectionResult:
    selected: list[Fragment]
    reason: str
    used_tokens: int
    utility: float


class _IntervalIndex:
    def __init__(self) -> None:
        self._by_path: dict[Path, list[tuple[int, int]]] = {}
        self._ids: set[FragmentId] = set()

    def add(self, frag_id: FragmentId) -> None:
        self._ids.add(frag_id)
        intervals = self._by_path.get(frag_id.path)
        if intervals is None:
            intervals = []
            self._by_path[frag_id.path] = intervals
        bisect.insort(intervals, (frag_id.start_line, frag_id.end_line))

    def __contains__(self, frag_id: FragmentId) -> bool:
        return frag_id in self._ids

    def overlaps(self, frag: Fragment) -> bool:
        intervals = self._by_path.get(frag.path)
        if not intervals:
            return False
        upper = bisect.bisect_right(intervals, (frag.end_line, float("inf")))
        for i in range(upper):
            start, end = intervals[i]
            if start == frag.start_line and end == frag.end_line:
                continue
            if end >= frag.start_line:
                return True
        return False

    def is_superset_of(self, frag: Fragment) -> bool:
        intervals = self._by_path.get(frag.path)
        if not intervals:
            return False
        upper = bisect.bisect_right(intervals, (frag.start_line, float("inf")))
        for i in range(upper):
            start, end = intervals[i]
            if start == frag.start_line and end == frag.end_line:
                continue
            if start <= frag.start_line and frag.end_line <= end:
                return True
        return False


@dataclass
class _SelectionState:
    selected: list[Fragment] = field(default_factory=list)
    selected_ids: _IntervalIndex = field(default_factory=_IntervalIndex)
    remaining_budget: int = 0
    utility_state: UtilityState = field(default_factory=UtilityState)


def _log_and_return(result: SelectionResult, core_ids: set[FragmentId]) -> SelectionResult:
    core_count = sum(1 for f in result.selected if f.id in core_ids)
    logger.debug(  # nosemgrep: python-logger-credential-disclosure
        "Selection: frags=%d core=%d tokens=%d reason=%s utility=%.4f",
        len(result.selected),
        core_count,
        result.used_tokens,
        result.reason,
        result.utility,
    )
    return result


def _select_core_fragments(
    core_fragments: list[Fragment],
    rel: dict[FragmentId, float],
    needs: tuple[InformationNeed, ...],
    state: _SelectionState,
    budget_tokens: int,
    sig_lookup: dict[FragmentId, Fragment] | None = None,
) -> None:
    core_budget = int(budget_tokens * _CORE_BUDGET_FRACTION)
    core_used = 0
    sorted_core = sorted(core_fragments, key=lambda f: rel.get(f.id, 0.0), reverse=True)

    for frag in sorted_core:
        if state.selected_ids.is_superset_of(frag):
            continue
        if core_used + frag.token_count > core_budget:
            sig = sig_lookup.get(frag.id) if sig_lookup else None
            if sig and sig.id not in state.selected_ids and core_used + sig.token_count <= core_budget:
                state.selected.append(sig)
                state.selected_ids.add(sig.id)
                state.remaining_budget -= sig.token_count
                core_used += sig.token_count
                apply_fragment(sig, rel.get(frag.id, 0.0), needs, state.utility_state)
            continue

        state.selected.append(frag)
        state.selected_ids.add(frag.id)
        state.remaining_budget -= frag.token_count
        core_used += frag.token_count
        apply_fragment(frag, rel.get(frag.id, 0.0), needs, state.utility_state)


@dataclass
class _HeapEntry:
    neg_density: float
    frag_id: FragmentId
    version: int

    def __lt__(self, other: _HeapEntry) -> bool:
        return self.neg_density < other.neg_density


def _build_initial_heap(
    candidates: list[Fragment],
    rel: dict[FragmentId, float],
    needs: tuple[InformationNeed, ...],
    state: UtilityState,
    id_to_frag: dict[FragmentId, Fragment],
) -> list[_HeapEntry]:
    heap: list[_HeapEntry] = []
    for frag in candidates:
        if frag.token_count > 0:
            density = compute_density(frag, rel.get(frag.id, 0.0), needs, state)
            heapq.heappush(heap, _HeapEntry(-density, frag.id, 0))
            id_to_frag[frag.id] = frag
    return heap


def _find_best_candidate_heap(
    heap: list[_HeapEntry],
    current_version: int,
    id_to_frag: dict[FragmentId, Fragment],
    selected_ids: _IntervalIndex,
    remaining_budget: int,
    rel: dict[FragmentId, float],
    needs: tuple[InformationNeed, ...],
    state: UtilityState,
) -> tuple[Fragment | None, float, int]:
    while heap:
        entry = heapq.heappop(heap)
        frag = id_to_frag.get(entry.frag_id)

        if frag is None:
            continue
        if frag.token_count > remaining_budget:
            continue
        if selected_ids.overlaps(frag):
            continue

        if entry.version < current_version:
            new_density = compute_density(frag, rel.get(frag.id, 0.0), needs, state)
            heapq.heappush(heap, _HeapEntry(-new_density, frag.id, current_version))
            continue

        actual_density = -entry.neg_density
        if actual_density <= 0:
            return None, 0.0, current_version

        return frag, actual_density, current_version + 1

    return None, 0.0, current_version


def _find_best_singleton(
    non_core: list[Fragment],
    base_selected_ids: _IntervalIndex,
    base_budget: int,
    rel: dict[FragmentId, float],
    needs: tuple[InformationNeed, ...],
    base_state: UtilityState,
) -> tuple[Fragment | None, float]:
    best_singleton = None
    best_gain = 0.0
    for f in non_core:
        if f.token_count > base_budget:
            continue
        if base_selected_ids.overlaps(f):
            continue
        gain = marginal_gain(f, rel.get(f.id, 0.0), needs, base_state)
        if gain > best_gain:
            best_gain = gain
            best_singleton = f
    return best_singleton, best_gain


def _compute_r_cap(rel: dict[FragmentId, float]) -> float:
    values = [v for v in rel.values() if v > 0]
    if len(values) < 2:
        return max(values[0], 1e-9) if values else 1.0
    med = statistics.median(values)
    std = statistics.stdev(values)
    return max(med + UTILITY.r_cap_sigma * std, 1e-9)


def lazy_greedy_select(
    fragments: list[Fragment],
    core_ids: set[FragmentId],
    rel: dict[FragmentId, float],
    needs: tuple[InformationNeed, ...],
    budget_tokens: int,
    tau: float = 0.08,
    file_importance: dict[Path, float] | None = None,
) -> SelectionResult:
    if not fragments:
        return _log_and_return(
            SelectionResult(selected=[], reason="no_candidates", used_tokens=0, utility=0.0),
            core_ids,
        )

    core_fragments = [f for f in fragments if f.id in core_ids]
    core_fragments.sort(key=lambda f: (f.token_count if f.token_count > 0 else 10**9, f.line_count, f.start_line))
    non_core_fragments = [f for f in fragments if f.id not in core_ids]

    sig_by_loc: dict[tuple[Path, int], Fragment] = {}
    for f in fragments:
        if "_signature" in f.kind:
            sig_by_loc[(f.path, f.start_line)] = f
    sig_lookup: dict[FragmentId, Fragment] = {}
    for cf in core_fragments:
        key = (cf.path, cf.start_line)
        if key in sig_by_loc:
            sig_lookup[cf.id] = sig_by_loc[key]

    state = _SelectionState(remaining_budget=budget_tokens)
    state.utility_state.r_cap = _compute_r_cap(rel)
    state.utility_state.changed_dirs = frozenset(cid.path.parent for cid in core_ids)
    if file_importance is not None:
        state.utility_state.file_importance = file_importance
    _select_core_fragments(core_fragments, rel, needs, state, budget_tokens, sig_lookup)

    if state.remaining_budget <= 0:
        used = budget_tokens - state.remaining_budget
        return _log_and_return(
            SelectionResult(
                selected=state.selected,
                reason="budget_exhausted",
                used_tokens=used,
                utility=utility_value(state.utility_state),
            ),
            core_ids,
        )

    base_state = state.utility_state.copy()
    base_selected = list(state.selected)
    base_budget = state.remaining_budget

    candidates = [f for f in non_core_fragments if not state.selected_ids.overlaps(f)]
    baseline_k = _adaptive_baseline_k(len(candidates))
    id_to_frag: dict[FragmentId, Fragment] = {}
    heap = _build_initial_heap(candidates, rel, needs, state.utility_state, id_to_frag)

    selections_for_baseline, threshold = _run_greedy_loop_heap(heap, id_to_frag, state, rel, needs, tau, baseline_k)

    greedy_utility = utility_value(state.utility_state)
    base_selected_ids = _IntervalIndex()
    for f in base_selected:
        base_selected_ids.add(f.id)

    singleton_result = _try_singleton_improvement(
        non_core_fragments,
        base_selected_ids,
        base_budget,
        base_selected,
        rel,
        needs,
        base_state,
        greedy_utility,
        budget_tokens,
        core_ids,
    )
    if singleton_result is not None:
        return singleton_result

    return _determine_final_result(
        state,
        base_selected,
        budget_tokens,
        greedy_utility,
        selections_for_baseline,
        threshold,
        bool(heap),
        core_ids,
        baseline_k,
    )


def _run_greedy_loop_heap(
    heap: list[_HeapEntry],
    id_to_frag: dict[FragmentId, Fragment],
    state: _SelectionState,
    rel: dict[FragmentId, float],
    needs: tuple[InformationNeed, ...],
    tau: float,
    baseline_k: int = _BASELINE_K_MAX,
) -> tuple[int, float]:
    baseline_densities: list[float] = []
    threshold = 0.0
    selections_for_baseline = 0
    current_version = 0

    while heap and state.remaining_budget > 0:
        best_frag, best_density, current_version = _find_best_candidate_heap(
            heap,
            current_version,
            id_to_frag,
            state.selected_ids,
            state.remaining_budget,
            rel,
            needs,
            state.utility_state,
        )

        if best_frag is None or best_density <= 0:
            break

        if selections_for_baseline < baseline_k:
            baseline_densities.append(best_density)
            selections_for_baseline += 1
            if selections_for_baseline == baseline_k and baseline_densities:
                threshold = tau * statistics.median(baseline_densities)
        elif best_density < threshold:
            break

        state.selected.append(best_frag)
        state.selected_ids.add(best_frag.id)
        state.remaining_budget -= best_frag.token_count
        apply_fragment(best_frag, rel.get(best_frag.id, 0.0), needs, state.utility_state)

    return selections_for_baseline, threshold


def _try_singleton_improvement(
    non_core: list[Fragment],
    base_selected_ids: _IntervalIndex,
    base_budget: int,
    base_selected: list[Fragment],
    rel: dict[FragmentId, float],
    needs: tuple[InformationNeed, ...],
    base_state: UtilityState,
    greedy_utility: float,
    budget_tokens: int,
    core_ids: set[FragmentId],
) -> SelectionResult | None:
    best_singleton, best_gain = _find_best_singleton(non_core, base_selected_ids, base_budget, rel, needs, base_state)

    if best_singleton is None:
        return None

    singleton_utility = utility_value(base_state) + best_gain
    if singleton_utility <= greedy_utility:
        return None

    used = budget_tokens - (base_budget - best_singleton.token_count)
    return _log_and_return(
        SelectionResult(
            selected=[*base_selected, best_singleton],
            reason="best_singleton",
            used_tokens=used,
            utility=singleton_utility,
        ),
        core_ids,
    )


def _determine_final_result(
    state: _SelectionState,
    base_selected: list[Fragment],
    budget_tokens: int,
    greedy_utility: float,
    selections_for_baseline: int,
    threshold: float,
    has_remaining_candidates: bool,
    core_ids: set[FragmentId],
    baseline_k: int = _BASELINE_K_MAX,
) -> SelectionResult:
    used = budget_tokens - state.remaining_budget

    if state.remaining_budget <= 0:
        reason = "budget_exhausted"
    elif greedy_utility <= 0:
        reason = "no_utility"
    elif not state.selected or len(state.selected) == len(base_selected):
        reason = "no_candidates"
    elif selections_for_baseline >= baseline_k and threshold > 0 and has_remaining_candidates:
        reason = "stopped_by_tau"
    else:
        reason = "no_candidates"

    return _log_and_return(
        SelectionResult(selected=state.selected, reason=reason, used_tokens=used, utility=greedy_utility),
        core_ids,
    )
