from __future__ import annotations

import logging
from collections import deque

from .graph import Graph
from .types import FragmentId

logger = logging.getLogger(__name__)


class _ReverseView:
    __slots__ = ("adjacency", "nodes")

    def __init__(self, graph: Graph) -> None:
        self.nodes = graph.nodes
        self.adjacency = graph.reverse_adjacency

    def neighbors(self, node: FragmentId) -> dict[FragmentId, float]:
        return self.adjacency.get(node, {})


def _init_seed_residuals(
    seeds: set[FragmentId],
    graph_nodes: set[FragmentId],
    seed_weights: dict[FragmentId, float] | None,
) -> dict[FragmentId, float]:
    valid_seeds = seeds & graph_nodes
    if not valid_seeds:
        return {}

    if seed_weights:
        epsilon = 0.1
        total_sw = sum(seed_weights.get(s, epsilon) for s in valid_seeds)
        if total_sw <= 0:
            return dict.fromkeys(valid_seeds, 0.0)
        return {s: seed_weights.get(s, epsilon) / total_sw for s in valid_seeds}

    weight = 1.0 / len(valid_seeds)
    return dict.fromkeys(valid_seeds, weight)


def _propagate_residual(
    u: FragmentId,
    residual: dict[FragmentId, float],
    estimate: dict[FragmentId, float],
    graph: Graph | _ReverseView,
    alpha: float,
    restart: float,
    push_threshold: float,
    queue: deque[FragmentId],
    visited: set[FragmentId],
) -> None:
    r_u = residual.get(u, 0.0)
    if r_u < push_threshold:
        return

    estimate[u] = estimate.get(u, 0.0) + restart * r_u
    residual[u] = 0.0

    nbrs = graph.neighbors(u)
    total_weight = sum(nbrs.values()) if nbrs else 0.0
    if total_weight <= 0:
        return

    push_mass = alpha * r_u
    for v, w in nbrs.items():
        delta = push_mass * (w / total_weight)
        old_r = residual.get(v, 0.0)
        residual[v] = old_r + delta
        if v not in visited and old_r + delta >= push_threshold:
            queue.append(v)
            visited.add(v)


def _personalized_pagerank_sparse(
    graph: Graph | _ReverseView,
    seeds: set[FragmentId],
    alpha: float = 0.60,
    tol: float = 1e-4,
    seed_weights: dict[FragmentId, float] | None = None,
) -> dict[FragmentId, float]:
    n = len(graph.nodes)
    if n == 0:
        return {}

    restart = 1.0 - alpha
    push_threshold = tol

    residual = _init_seed_residuals(seeds, graph.nodes, seed_weights)
    estimate: dict[FragmentId, float] = {}

    queue: deque[FragmentId] = deque(residual.keys())
    visited: set[FragmentId] = set(queue)

    pushes = 0
    max_pushes = min(n * 50, 500_000)
    while queue and pushes < max_pushes:
        u = queue.popleft()
        visited.discard(u)
        _propagate_residual(u, residual, estimate, graph, alpha, restart, push_threshold, queue, visited)
        pushes += 1

    return estimate


def personalized_pagerank(
    graph: Graph,
    seeds: set[FragmentId],
    alpha: float = 0.60,
    tol: float = 1e-4,
    lam: float = 0.4,
    seed_weights: dict[FragmentId, float] | None = None,
) -> dict[FragmentId, float]:
    if not graph.nodes:
        return {}

    valid_seeds = seeds & graph.nodes
    if not valid_seeds:
        return {n: 1.0 / len(graph.nodes) for n in graph.nodes}

    forward_scores = _personalized_pagerank_sparse(graph, valid_seeds, alpha, tol, seed_weights)

    reverse_view = _ReverseView(graph)
    backward_scores = _personalized_pagerank_sparse(reverse_view, valid_seeds, alpha, tol, seed_weights)

    combined: dict[FragmentId, float] = {}
    all_nodes = set(forward_scores) | set(backward_scores)
    for node in all_nodes:
        fwd = forward_scores.get(node, 0.0)
        bwd = backward_scores.get(node, 0.0)
        combined[node] = lam * fwd + (1 - lam) * bwd

    total = sum(combined.values())
    if total > 0:
        return {n: s / total for n, s in combined.items()}

    logger.debug(
        "PPR sparse bidirectional: forward=%d backward=%d combined=%d nodes",
        len(forward_scores),
        len(backward_scores),
        len(combined),
    )
    return combined
