from __future__ import annotations

import time
from typing import Any, BinaryIO
from urllib.parse import quote

import httpx

from ._http import HttpClient
from ._retry import with_retry
from ._types import BucketQueryResult, FileRecord, FoldersResult, PutOptions, RetryOptions

UPLOAD_POLL_INTERVAL = 0.5
UPLOAD_POLL_MAX_ATTEMPTS = 10


def _parse_file(raw: dict[str, Any]) -> FileRecord:
	return FileRecord(
		filename=raw["filename"],
		s3_key=raw["s3Key"],
		visibility=raw["visibility"],
		content_type=raw["contentType"],
		ext=raw["ext"],
		status=raw["status"],
		created_at=raw["createdAt"],
		updated_at=raw["updatedAt"],
		size=raw.get("size"),
		metadata=raw.get("metadata"),
		url=raw.get("url"),
	)


class Bucket:
	def __init__(self, name: str, http: HttpClient, retry_options: RetryOptions) -> None:
		self.name = name
		self._http = http
		self._retry = retry_options

	def _path(self, suffix: str = "") -> str:
		return f"/api/buckets/{quote(self.name, safe='')}{suffix}"

	def put(
		self,
		filename: str,
		file: bytes | BinaryIO,
		options: PutOptions | None = None,
	) -> FileRecord:
		"""Upload a file to the bucket.

		The file content is read entirely into memory for the presigned S3
		upload. For very large files this may cause high memory usage —
		consider chunked upload strategies for files exceeding available RAM.

		Args:
			filename: The name to store the file under.
			file: Raw bytes or a file-like object (will be read via .read()).
			options: Optional PutOptions with visibility, metadata, content_type.
		"""
		opts = options or PutOptions()
		visibility = opts.visibility
		metadata = opts.metadata
		content_type = opts.content_type or "application/octet-stream"

		file_bytes: bytes
		if isinstance(file, bytes):
			file_bytes = file
		else:
			file_bytes = file.read()

		# Step 1: Initiate upload
		init_result = with_retry(
			lambda: self._http.post(self._path("/upload"), {
				"filename": filename,
				"contentType": content_type,
				"size": len(file_bytes),
				"visibility": visibility,
				"metadata": metadata,
			}),
			self._retry,
		)

		upload_url: str = init_result["uploadUrl"]

		# Step 2: Upload to S3 directly
		response = httpx.put(
			upload_url,
			content=file_bytes,
			headers={"Content-Type": content_type},
		)
		if response.status_code >= 400:
			raise RuntimeError(f"S3 upload failed: {response.status_code} {response.reason_phrase}")

		# Step 3: Poll for ready status
		for _ in range(UPLOAD_POLL_MAX_ATTEMPTS):
			time.sleep(UPLOAD_POLL_INTERVAL)
			meta = self.get_meta(filename)
			if meta.status == "ready":
				return meta

		return self.get_meta(filename)

	def get_url(self, filename: str, *, expires_in: int | None = None) -> str:
		suffix = f"/files/{quote(filename, safe='')}"
		params: dict[str, str] | None = None
		if expires_in is not None:
			params = {"expiresIn": str(expires_in)}
		result = with_retry(
			lambda: self._http.get(self._path(suffix), params),
			self._retry,
		)
		url: str = result["url"]
		return url

	def get_meta(self, filename: str) -> FileRecord:
		result = with_retry(
			lambda: self._http.get(self._path(f"/files/{quote(filename, safe='')}/meta")),
			self._retry,
		)
		return _parse_file(result["file"])

	def query(
		self,
		*,
		ext: str | None = None,
		prefix: str | None = None,
		limit: int | None = None,
		cursor: str | None = None,
	) -> BucketQueryResult:
		body: dict[str, Any] = {}
		if ext is not None:
			body["ext"] = ext
		if prefix is not None:
			body["prefix"] = prefix
		if limit is not None:
			body["limit"] = limit
		if cursor is not None:
			body["cursor"] = cursor

		result = with_retry(
			lambda: self._http.post(self._path("/query"), body),
			self._retry,
		)
		return BucketQueryResult(
			items=[_parse_file(f) for f in result["files"]],
			cursor=result.get("cursor"),
		)

	def list_folders(self, prefix: str | None = None) -> FoldersResult:
		params: dict[str, str] | None = None
		if prefix is not None:
			params = {"prefix": prefix}
		result = with_retry(
			lambda: self._http.get(self._path("/folders"), params),
			self._retry,
		)
		return FoldersResult(folders=result["folders"], files=result["files"])

	def set_visibility(self, filename: str, visibility: str) -> FileRecord:
		result = with_retry(
			lambda: self._http.patch(
				self._path(f"/files/{quote(filename, safe='')}/visibility"),
				{"visibility": visibility},
			),
			self._retry,
		)
		return _parse_file(result["file"])

	def remove(self, filename: str) -> None:
		with_retry(
			lambda: self._http.delete(self._path(f"/files/{quote(filename, safe='')}")),
			self._retry,
		)
