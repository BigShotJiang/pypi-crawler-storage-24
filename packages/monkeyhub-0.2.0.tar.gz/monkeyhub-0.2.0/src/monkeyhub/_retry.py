from __future__ import annotations

import time
from typing import Callable, TypeVar

from ._errors import NetworkError, RateLimitError, ServiceError
from ._types import RetryOptions

T = TypeVar("T")


def with_retry(fn: Callable[[], T], options: RetryOptions) -> T:
	retries_429 = 0
	retries_503 = 0
	retries_network = 0

	while True:
		try:
			return fn()
		except RateLimitError as err:
			if retries_429 >= options.max_retries_429:
				raise
			delay = (
				err.retry_after
				if err.retry_after
				else options.base_delay_429 * (2 ** retries_429)
			)
			retries_429 += 1
			time.sleep(delay)
		except NetworkError:
			if retries_network >= options.max_retries_network:
				raise
			retries_network += 1
			time.sleep(options.network_delay)
		except ServiceError as err:
			if err.status != 503 or retries_503 >= options.max_retries_503:
				raise
			delay = options.base_delay_503 * (2 ** retries_503)
			retries_503 += 1
			time.sleep(delay)
