from __future__ import annotations

import threading
from urllib.parse import quote

from ._collection import Collection
from ._http import HttpClient
from ._types import CollectionOptions, CollectionStats, CollectionSummary, RetryOptions


class Database:
	def __init__(self, name: str, http: HttpClient, retry_options: RetryOptions) -> None:
		self.name = name
		self._http = http
		self._retry = retry_options
		self._lock = threading.Lock()
		self._collections: dict[str, Collection] = {}

	def collection(self, name: str, options: CollectionOptions | None = None) -> Collection:
		cache_key = f"{self.name}:{name}"
		with self._lock:
			existing = self._collections.get(cache_key)
			if existing is not None:
				return existing
			col = Collection(name, self._http, self._retry, options or {}, db=self.name)
			self._collections[cache_key] = col
			return col

	def list_collections(self) -> list[CollectionSummary]:
		result = self._http.get(f"/api/db/{quote(self.name, safe='')}/collections")
		return [
			CollectionSummary(
				name=c["name"],
				key=c["key"],
				indices=c.get("indices", []),
				stats=CollectionStats(
					item_count=c["stats"]["itemCount"],
					item_count_is_estimate=c["stats"]["itemCountIsEstimate"],
					average_item_size_bytes=c["stats"]["averageItemSizeBytes"],
					indexes_declared=c["stats"]["indexesDeclared"],
					indexes_max=c["stats"]["indexesMax"],
				),
				created_at=c["createdAt"],
				updated_at=c["updatedAt"],
			)
			for c in result["collections"]
		]
