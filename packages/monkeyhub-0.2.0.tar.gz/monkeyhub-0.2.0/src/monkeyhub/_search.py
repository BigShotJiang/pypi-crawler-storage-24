from __future__ import annotations

import threading
from typing import Any
from urllib.parse import quote

from ._http import HttpClient
from ._retry import with_retry
from ._types import RetryOptions, SearchMatch, SearchResult


class Search:
	def __init__(
		self,
		name: str,
		http: HttpClient,
		retry_options: RetryOptions,
		fields: list[str],
	) -> None:
		self.name = name
		self._http = http
		self._retry = retry_options
		self._fields = fields
		self._registered = False
		self._lock = threading.Lock()

	def _ensure_registered(self) -> None:
		if self._registered:
			return
		with self._lock:
			if self._registered:
				return
			with_retry(
				lambda: self._http.post("/api/search", {
					"name": self.name,
					"fields": self._fields,
				}),
				self._retry,
			)
			self._registered = True

	def _path(self, suffix: str = "") -> str:
		return f"/api/search/{quote(self.name, safe='')}{suffix}"

	def upsert(self, item: dict[str, Any] | list[dict[str, Any]]) -> None:
		self._ensure_registered()
		items = item if isinstance(item, list) else [item]
		if not items:
			return

		body: dict[str, Any] = {"item": items[0]} if len(items) == 1 else {"items": items}
		with_retry(
			lambda: self._http.post(self._path("/vectors"), body),
			self._retry,
		)

	def query(
		self,
		text: str,
		*,
		top_k: int | None = None,
		filter: dict[str, Any] | None = None,
	) -> SearchResult:
		self._ensure_registered()
		if not text or not text.strip():
			raise ValueError("query() requires text.")

		body: dict[str, Any] = {"text": text}
		if top_k is not None:
			body["topK"] = top_k
		if filter is not None:
			body["filter"] = filter

		result = with_retry(
			lambda: self._http.post(self._path("/query"), body),
			self._retry,
		)
		matches = [
			SearchMatch(key=m["key"], score=m["score"], distance=m["distance"])
			for m in result.get("matches", [])
		]
		return SearchResult(matches=matches)

	def remove(self, key: str | int) -> None:
		self._ensure_registered()
		with_retry(
			lambda: self._http.delete(self._path(f"/vectors/{quote(str(key), safe='')}")),
			self._retry,
		)

	def count(self) -> int:
		self._ensure_registered()
		result = with_retry(
			lambda: self._http.get(self._path()),
			self._retry,
		)
		count: int = result["index"]["vectorCount"]
		return count
