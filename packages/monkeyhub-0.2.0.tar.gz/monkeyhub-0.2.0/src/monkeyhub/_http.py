from __future__ import annotations

from typing import Any

import httpx

from ._errors import NetworkError, ServiceError, error_from_response


class HttpClient:
	def __init__(self, base_url: str, api_key: str, timeout: float = 30.0) -> None:
		self._base_url = base_url.rstrip("/")
		self._api_key = api_key
		self._timeout = timeout
		self._client = httpx.Client(
			base_url=self._base_url,
			headers={
				"Authorization": f"Bearer {api_key}",
			},
			timeout=timeout,
		)

	def request(
		self,
		method: str,
		path: str,
		*,
		body: Any | None = None,
		params: dict[str, str] | None = None,
	) -> Any:
		headers: dict[str, str] = {}
		content: bytes | None = None

		if body is not None:
			import json
			headers["Content-Type"] = "application/json"
			content = json.dumps(body).encode()

		# Filter out None params
		filtered_params: dict[str, str] | None = None
		if params:
			filtered_params = {k: v for k, v in params.items() if v is not None}
			if not filtered_params:
				filtered_params = None

		try:
			response = self._client.request(
				method,
				path,
				content=content,
				headers=headers,
				params=filtered_params,
			)
		except httpx.TimeoutException:
			raise ServiceError("Request timed out")
		except (httpx.ConnectError, httpx.ReadError) as e:
			raise NetworkError(f"A network error occurred: {e}") from e

		if response.status_code >= 400:
			try:
				data = response.json()
			except Exception:
				raise ServiceError(f"HTTP {response.status_code}")
			resp_headers = dict(response.headers)
			raise error_from_response(response.status_code, data, resp_headers)

		if response.status_code == 204 or not response.content:
			return {}

		try:
			return response.json()
		except Exception as e:
			raise ServiceError(f"Failed to decode JSON response from server: {e}") from e

	def get(self, path: str, params: dict[str, str] | None = None) -> Any:
		return self.request("GET", path, params=params)

	def post(self, path: str, body: Any) -> Any:
		return self.request("POST", path, body=body)

	def put(self, path: str, body: Any) -> Any:
		return self.request("PUT", path, body=body)

	def patch(self, path: str, body: Any) -> Any:
		return self.request("PATCH", path, body=body)

	def delete(self, path: str, params: dict[str, str] | None = None, *, body: Any | None = None) -> Any:
		return self.request("DELETE", path, params=params, body=body)

	def close(self) -> None:
		self._client.close()
