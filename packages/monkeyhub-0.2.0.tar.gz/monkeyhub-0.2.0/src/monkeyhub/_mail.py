from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ._errors import NotFoundError
from ._http import HttpClient
from ._retry import with_retry
from ._types import (
	DnsRecord,
	DomainInfo,
	DomainVerification,
	MailQueryResult,
	Message,
	RetryOptions,
	SendReceipt,
)


def _parse_message(raw: dict[str, Any]) -> Message:
	return Message(
		id=raw["id"],
		from_addr=raw["from"],
		to=raw["to"],
		subject=raw["subject"],
		status=raw["status"],
		created_at=raw["createdAt"],
		updated_at=raw["updatedAt"],
		html=raw.get("html"),
		text=raw.get("text"),
		reply_to=raw.get("replyTo"),
	)


class Mail:
	def __init__(self, http: HttpClient, retry_options: RetryOptions) -> None:
		self._http = http
		self._retry = retry_options

	def send(
		self,
		*,
		from_addr: str,
		to: str,
		subject: str,
		html: str | None = None,
		text: str | None = None,
		reply_to: str | None = None,
	) -> SendReceipt:
		body: dict[str, Any] = {
			"from": from_addr,
			"to": to,
			"subject": subject,
		}
		if html is not None:
			body["html"] = html
		if text is not None:
			body["text"] = text
		if reply_to is not None:
			body["replyTo"] = reply_to

		result = with_retry(
			lambda: self._http.post("/api/mail/send", body),
			self._retry,
		)
		return SendReceipt(id=result["id"], status=result["status"])

	def get_message(self, id: str) -> Message | None:
		try:
			result = with_retry(
				lambda: self._http.get(f"/api/mail/messages/{quote(id, safe='')}"),
				self._retry,
			)
			return _parse_message(result["message"])
		except NotFoundError:
			return None

	def query(
		self,
		*,
		status: str | None = None,
		limit: int | None = None,
		cursor: str | None = None,
	) -> MailQueryResult:
		params: dict[str, str] = {}
		if status is not None:
			params["status"] = status
		if limit is not None:
			params["limit"] = str(limit)
		if cursor is not None:
			params["cursor"] = cursor

		result = with_retry(
			lambda: self._http.get("/api/mail/messages", params if params else None),
			self._retry,
		)
		return MailQueryResult(
			items=[_parse_message(m) for m in result["items"]],
			cursor=result.get("cursor"),
		)

	def verify_domain(self, domain: str) -> DomainVerification:
		result = with_retry(
			lambda: self._http.post("/api/mail/domains", {"domain": domain}),
			self._retry,
		)
		dns = result["dnsRecords"]
		return DomainVerification(
			domain=result["domain"],
			status=result["status"],
			dns_records={
				k: [DnsRecord(type=r["type"], name=r["name"], value=r["value"], purpose=r["purpose"]) for r in v]
				for k, v in dns.items()
			},
		)

	def get_domain(self, domain: str) -> DomainInfo | None:
		try:
			result = with_retry(
				lambda: self._http.get(f"/api/mail/domains/{quote(domain, safe='')}"),
				self._retry,
			)
			d = result["domain"] if isinstance(result.get("domain"), dict) else result
			return DomainInfo(
				domain=d["domain"],
				status=d["status"],
				created_at=d["createdAt"],
				updated_at=d["updatedAt"],
				dkim_tokens=d.get("dkimTokens"),
			)
		except NotFoundError:
			return None

	def list_domains(self) -> list[DomainInfo]:
		result = with_retry(
			lambda: self._http.get("/api/mail/domains"),
			self._retry,
		)
		return [
			DomainInfo(
				domain=d["domain"],
				status=d["status"],
				created_at=d["createdAt"],
				updated_at=d["updatedAt"],
				dkim_tokens=d.get("dkimTokens"),
			)
			for d in result["domains"]
		]

	def remove_domain(self, domain: str) -> None:
		with_retry(
			lambda: self._http.delete(f"/api/mail/domains/{quote(domain, safe='')}"),
			self._retry,
		)
