from __future__ import annotations

from typing import Any


class MonkeyError(Exception):
	"""Base error for all MonkeyHub API errors."""

	status: int
	code: str
	request_id: str
	message: str
	reason: str | None
	dimension: str | None
	used: int | None
	limit: int | None
	suggested_plan: str | None
	upgrade_url: str | None

	def __init__(
		self,
		status: int,
		code: str,
		message: str,
		request_id: str = "",
		*,
		reason: str | None = None,
		dimension: str | None = None,
		used: int | None = None,
		limit: int | None = None,
		suggested_plan: str | None = None,
		upgrade_url: str | None = None,
	) -> None:
		super().__init__(message)
		self.status = status
		self.code = code
		self.message = message
		self.request_id = request_id
		self.reason = reason
		self.dimension = dimension
		self.used = used
		self.limit = limit
		self.suggested_plan = suggested_plan
		self.upgrade_url = upgrade_url


class NotFoundError(MonkeyError):
	def __init__(self, message: str = "Not found", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(404, "NOT_FOUND", message, request_id, **kwargs)


class UnauthorizedError(MonkeyError):
	def __init__(self, message: str = "Unauthorized", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(401, "UNAUTHORIZED", message, request_id, **kwargs)


class ForbiddenError(MonkeyError):
	def __init__(self, message: str = "Forbidden", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(403, "FORBIDDEN", message, request_id, **kwargs)


class ValidationError(MonkeyError):
	def __init__(self, message: str = "Validation error", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(400, "VALIDATION_ERROR", message, request_id, **kwargs)


class ConflictError(MonkeyError):
	def __init__(self, message: str = "Conflict", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(409, "CONFLICT", message, request_id, **kwargs)


class PayloadTooLargeError(MonkeyError):
	def __init__(self, message: str = "Payload too large", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(413, "PAYLOAD_TOO_LARGE", message, request_id, **kwargs)


class QuotaExceededError(MonkeyError):
	def __init__(self, message: str = "Quota exceeded", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(402, "QUOTA_EXCEEDED", message, request_id, **kwargs)


class RateLimitError(MonkeyError):
	retry_after: float

	def __init__(
		self,
		message: str = "Too many requests",
		request_id: str = "",
		retry_after: float = 1.0,
		**kwargs: Any,
	) -> None:
		super().__init__(429, "RATE_LIMITED", message, request_id, **kwargs)
		self.retry_after = retry_after


class ServiceError(MonkeyError):
	def __init__(self, message: str = "Service error", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(500, "SERVICE_ERROR", message, request_id, **kwargs)


class NetworkError(ServiceError):
	"""Raised when a network-level error occurs (connection refused, read error, etc.)."""

	def __init__(self, message: str = "A network error occurred", request_id: str = "", **kwargs: Any) -> None:
		super().__init__(message, request_id, **kwargs)


_ERROR_MAP: dict[int, type[MonkeyError]] = {
	400: ValidationError,
	401: UnauthorizedError,
	402: QuotaExceededError,
	403: ForbiddenError,
	404: NotFoundError,
	409: ConflictError,
	413: PayloadTooLargeError,
	500: ServiceError,
}


def error_from_response(
	status: int,
	body: dict[str, Any],
	headers: dict[str, str] | None = None,
) -> MonkeyError:
	message = body.get("message") or f"HTTP {status}"
	request_id = body.get("requestId", "")
	details: dict[str, Any] = {}
	for key in ("reason", "dimension", "used", "limit", "suggestedPlan", "upgradeUrl"):
		if key in body and body[key] is not None:
			# Convert camelCase to snake_case for Python kwargs
			py_key = {
				"suggestedPlan": "suggested_plan",
				"upgradeUrl": "upgrade_url",
			}.get(key, key)
			details[py_key] = body[key]

	if status == 429:
		retry_after = 1.0
		if headers and "retry-after" in headers:
			try:
				retry_after = float(headers["retry-after"])
			except (ValueError, TypeError):
				pass
		return RateLimitError(message, request_id, retry_after, **details)

	if status == 503:
		return ServiceError(message, request_id, **details)

	cls = _ERROR_MAP.get(status)
	if cls:
		return cls(message, request_id, **details)  # type: ignore[arg-type]

	return MonkeyError(status, body.get("code", "UNKNOWN"), message, request_id, **details)
