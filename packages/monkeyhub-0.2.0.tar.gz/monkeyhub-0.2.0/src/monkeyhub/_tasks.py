from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ._errors import NotFoundError
from ._http import HttpClient
from ._retry import with_retry
from ._types import (
	CreateTaskInput,
	RetryOptions,
	RunListResult,
	RunTaskInput,
	TaskDefinition,
	TaskListResult,
	TaskRun,
	TaskSchedule,
	UpdateTaskInput,
)

MAX_BATCH_SIZE = 10


def _parse_schedule(raw: dict[str, Any]) -> TaskSchedule:
	return TaskSchedule(
		cron=raw["cron"],
		title=raw.get("title"),
		timezone=raw.get("timezone"),
	)


def _parse_task_def(raw: dict[str, Any]) -> TaskDefinition:
	schedules = None
	if "schedules" in raw and raw["schedules"] is not None:
		schedules = [_parse_schedule(s) for s in raw["schedules"]]
	return TaskDefinition(
		id=raw["id"],
		org=raw["org"],
		name=raw["name"],
		status=raw["status"],
		execution=raw.get("execution", {}),
		created_at=raw["createdAt"],
		updated_at=raw["updatedAt"],
		description=raw.get("description"),
		tags=raw.get("tags"),
		group=raw.get("group"),
		schedules=schedules,
	)


def _parse_task_run(raw: dict[str, Any]) -> TaskRun:
	return TaskRun(
		id=raw["id"],
		task_id=raw["taskId"],
		task_name=raw["taskName"],
		org=raw["org"],
		trigger=raw["trigger"],
		status=raw["status"],
		retries=raw["retries"],
		created_at=raw["createdAt"],
		updated_at=raw["updatedAt"],
		schedule_title=raw.get("scheduleTitle"),
		payload=raw.get("payload"),
		result=raw.get("result"),
		run_at=raw.get("runAt"),
		started_at=raw.get("startedAt"),
		completed_at=raw.get("completedAt"),
	)


class TaskHandle:
	"""A handle to a single task definition with methods to manage runs."""

	def __init__(self, data: TaskDefinition, http: HttpClient, retry_options: RetryOptions) -> None:
		self.id = data.id
		self.name = data.name
		self.description = data.description
		self.tags = data.tags
		self.group = data.group
		self.status = data.status
		self.schedules = data.schedules
		self.execution = data.execution
		self.created_at = data.created_at
		self.updated_at = data.updated_at
		self._http = http
		self._retry = retry_options

	def _path(self, suffix: str = "") -> str:
		return f"/api/tasks/{quote(self.id, safe='')}{suffix}"

	def pause(self) -> TaskHandle:
		result = with_retry(
			lambda: self._http.post(self._path("/pause"), {}),
			self._retry,
		)
		return TaskHandle(_parse_task_def(result["task"]), self._http, self._retry)

	def resume(self) -> TaskHandle:
		result = with_retry(
			lambda: self._http.post(self._path("/resume"), {}),
			self._retry,
		)
		return TaskHandle(_parse_task_def(result["task"]), self._http, self._retry)

	def run_now(self, input: RunTaskInput | None = None) -> TaskRun:
		result = with_retry(
			lambda: self._http.post(self._path("/run"), dict(input) if input else {}),
			self._retry,
		)
		return _parse_task_run(result["run"])

	def run_batch(self, inputs: list[RunTaskInput]) -> list[TaskRun]:
		if len(inputs) > MAX_BATCH_SIZE:
			raise ValueError(f"Maximum {MAX_BATCH_SIZE} runs per batch")
		result = with_retry(
			lambda: self._http.post(self._path("/run/batch"), [dict(i) for i in inputs]),
			self._retry,
		)
		return [_parse_task_run(r) for r in result["runs"]]

	def list_history(
		self,
		limit: int | None = None,
		*,
		status: str | None = None,
		cursor: str | None = None,
	) -> RunListResult:
		params: dict[str, str] = {}
		if limit is not None:
			params["limit"] = str(limit)
		if status is not None:
			params["status"] = status
		if cursor is not None:
			params["cursor"] = cursor

		path = self._path("/runs")
		result = with_retry(
			lambda: self._http.get(path, params or None),
			self._retry,
		)
		return RunListResult(
			items=[_parse_task_run(r) for r in result["runs"]],
			cursor=result.get("cursor"),
		)

	def get_run(self, run_id: str) -> TaskRun | None:
		try:
			result = with_retry(
				lambda: self._http.get(self._path(f"/runs/{quote(run_id, safe='')}")),
				self._retry,
			)
			return _parse_task_run(result["run"])
		except NotFoundError:
			return None

	def cancel(self, run_id: str) -> None:
		with_retry(
			lambda: self._http.post(self._path(f"/runs/{quote(run_id, safe='')}/cancel"), {}),
			self._retry,
		)

	def retry(self, run_id: str) -> TaskRun:
		result = with_retry(
			lambda: self._http.post(self._path(f"/runs/{quote(run_id, safe='')}/retry"), {}),
			self._retry,
		)
		return _parse_task_run(result["run"])


class TasksClient:
	"""Top-level tasks client: create, list, lookup, update, remove."""

	def __init__(self, http: HttpClient, retry_options: RetryOptions) -> None:
		self._http = http
		self._retry = retry_options

	def create(self, input: CreateTaskInput) -> TaskHandle:
		result = with_retry(
			lambda: self._http.post("/api/tasks", dict(input)),
			self._retry,
		)
		return TaskHandle(_parse_task_def(result["task"]), self._http, self._retry)

	def list(
		self,
		*,
		group: str | None = None,
		status: str | None = None,
		tag: str | None = None,
		limit: int | None = None,
		cursor: str | None = None,
	) -> TaskListResult:
		params: dict[str, str] = {}
		if group is not None:
			params["group"] = group
		if status is not None:
			params["status"] = status
		if tag is not None:
			params["tag"] = tag
		if limit is not None:
			params["limit"] = str(limit)
		if cursor is not None:
			params["cursor"] = cursor

		result = with_retry(
			lambda: self._http.get("/api/tasks", params or None),
			self._retry,
		)
		return TaskListResult(
			items=[_parse_task_def(t) for t in result["tasks"]],
			cursor=result.get("cursor"),
		)

	def lookup(self, id_or_name: str) -> TaskHandle | None:
		try:
			result = with_retry(
				lambda: self._http.get(f"/api/tasks/{quote(id_or_name, safe='')}"),
				self._retry,
			)
			return TaskHandle(_parse_task_def(result["task"]), self._http, self._retry)
		except NotFoundError:
			return None

	def update(self, id_or_name: str, input: UpdateTaskInput) -> TaskHandle:
		result = with_retry(
			lambda: self._http.put(f"/api/tasks/{quote(id_or_name, safe='')}", dict(input)),
			self._retry,
		)
		return TaskHandle(_parse_task_def(result["task"]), self._http, self._retry)

	def remove(self, id_or_name: str) -> None:
		with_retry(
			lambda: self._http.delete(f"/api/tasks/{quote(id_or_name, safe='')}"),
			self._retry,
		)
