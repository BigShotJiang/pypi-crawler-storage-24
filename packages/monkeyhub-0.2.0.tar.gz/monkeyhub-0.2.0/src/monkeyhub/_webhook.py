from __future__ import annotations

import hashlib
import hmac
import time


def verify_webhook(
	*,
	signature: str,
	timestamp: int | str,
	body: str,
	secret: str,
) -> bool:
	"""Verify a MonkeyHub webhook signature.

	Returns True if the signature is valid and the timestamp is within 5 minutes.
	"""
	ts = int(timestamp)

	# Reject if older than 5 minutes
	now = int(time.time())
	if abs(now - ts) > 300:
		return False

	expected = hmac.new(
		secret.encode(),
		f"{ts}.{body}".encode(),
		hashlib.sha256,
	).hexdigest()

	expected_sig = f"sha256={expected}"
	return hmac.compare_digest(signature, expected_sig)
