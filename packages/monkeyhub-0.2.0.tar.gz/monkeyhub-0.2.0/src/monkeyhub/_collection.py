from __future__ import annotations

import threading
from typing import Any
from urllib.parse import quote

from ._errors import NotFoundError
from ._http import HttpClient
from ._retry import with_retry
from ._types import BackupInfo, CollectionOptions, KeyType, QueryResult, RetryOptions

MAX_BATCH_SAVE = 25
MAX_BATCH_FIND = 100


def _parse_backup(raw: dict[str, Any]) -> BackupInfo:
	return BackupInfo(
		id=raw["id"],
		org_id=raw["orgId"],
		db=raw["db"],
		collection_name=raw["collectionName"],
		status=raw["status"],
		created_at=raw["createdAt"],
		item_count=raw.get("itemCount"),
		file_size=raw.get("fileSize"),
		file_id=raw.get("fileId"),
		error=raw.get("error"),
		completed_at=raw.get("completedAt"),
	)


class Collection:
	def __init__(
		self,
		name: str,
		http: HttpClient,
		retry_options: RetryOptions,
		options: CollectionOptions,
		db: str = "default",
	) -> None:
		self.name = name
		self.db = db
		self._http = http
		self._retry = retry_options
		self._options = options
		self._registered = False
		self._lock = threading.Lock()

	def _ensure_registered(self) -> None:
		if self._registered:
			return
		with self._lock:
			if self._registered:
				return
			with_retry(
				lambda: self._http.post(f"/api/db/{quote(self.db, safe='')}/collections", {
					"name": self.name,
					"indexes": self._options.get("indexes", []),
					"key": self._options.get("key"),
				}),
				self._retry,
			)
			self._registered = True

	def _path(self, suffix: str = "") -> str:
		return f"/api/db/{quote(self.db, safe='')}/collections/{quote(self.name, safe='')}{suffix}"

	def find_one(self, key: KeyType, sort_key: KeyType | None = None) -> dict[str, Any] | None:
		self._ensure_registered()
		params: dict[str, str] | None = None
		if sort_key is not None:
			params = {"sortKey": str(sort_key)}
		try:
			result = with_retry(
				lambda: self._http.get(
					self._path(f"/items/{quote(str(key), safe='')}"),
					params,
				),
				self._retry,
			)
			item: dict[str, Any] = result["item"]
			return item
		except NotFoundError:
			return None

	def find(self, keys: list[KeyType], sort_keys: list[KeyType] | None = None) -> list[dict[str, Any]]:
		if not keys:
			return []
		if sort_keys is not None and len(sort_keys) != len(keys):
			raise ValueError("find() requires sort_keys to have the same length as keys.")
		self._ensure_registered()

		all_items: list[dict[str, Any]] = []
		for i in range(0, len(keys), MAX_BATCH_FIND):
			chunk_keys = keys[i:i + MAX_BATCH_FIND]
			keys_param = ",".join(quote(str(k), safe="") for k in chunk_keys)
			params: dict[str, str] = {"keys": keys_param}
			if sort_keys is not None:
				chunk_sort = sort_keys[i:i + MAX_BATCH_FIND]
				params["sortKeys"] = ",".join(quote(str(k), safe="") for k in chunk_sort)
			result = with_retry(
				lambda p=params: self._http.get(self._path("/items"), p),  # type: ignore[misc]
				self._retry,
			)
			all_items.extend(result["items"])
		return all_items

	def query(
		self,
		*,
		hash_key: KeyType,
		index: str | None = None,
		range_key: KeyType | None = None,
		range_key_op: str | None = None,
		filter: dict[str, Any] | None = None,
		limit: int | None = None,
		reverse: bool | None = None,
		cursor: str | None = None,
	) -> QueryResult:
		self._ensure_registered()

		body: dict[str, Any] = {"hashKey": hash_key}
		if index is not None:
			body["index"] = index
		if range_key is not None:
			body["rangeKey"] = range_key
		if range_key_op is not None:
			body["rangeKeyOp"] = range_key_op
		if filter is not None:
			body["filter"] = filter
		if limit is not None:
			body["limit"] = limit
		if reverse is not None:
			body["scanForward"] = not reverse
		if cursor is not None:
			body["cursor"] = cursor

		result = with_retry(
			lambda: self._http.post(self._path("/query"), body),
			self._retry,
		)
		return QueryResult(items=result["items"], cursor=result.get("cursor"))

	def save(self, item: dict[str, Any] | list[dict[str, Any]]) -> None:
		self._ensure_registered()
		items = item if isinstance(item, list) else [item]
		if not items:
			return

		for i in range(0, len(items), MAX_BATCH_SAVE):
			chunk = items[i:i + MAX_BATCH_SAVE]
			body: dict[str, Any] = {"item": chunk[0]} if len(chunk) == 1 else {"items": chunk}
			with_retry(
				lambda b=body: self._http.post(self._path("/items"), b),  # type: ignore[misc]
				self._retry,
			)

	def remove(self, key: KeyType, sort_key: KeyType | None = None) -> None:
		self._ensure_registered()
		params: dict[str, str] | None = None
		if sort_key is not None:
			params = {"sortKey": str(sort_key)}
		with_retry(
			lambda: self._http.delete(
				self._path(f"/items/{quote(str(key), safe='')}"),
				params,
			),
			self._retry,
		)

	def drop(self, confirm_name: str) -> None:
		if confirm_name != self.name:
			raise ValueError(f'Confirmation name "{confirm_name}" does not match collection name "{self.name}"')
		self._ensure_registered()
		with_retry(
			lambda: self._http.post(self._path("/drop"), {"confirm": True}),
			self._retry,
		)

	def backup(self) -> BackupInfo:
		self._ensure_registered()
		result = with_retry(
			lambda: self._http.post(self._path("/backup"), {}),
			self._retry,
		)
		return _parse_backup(result["backup"])

	def list_backups(self) -> list[BackupInfo]:
		self._ensure_registered()
		result = with_retry(
			lambda: self._http.get(self._path("/backups")),
			self._retry,
		)
		return [_parse_backup(b) for b in result["backups"]]

	def get_backup(self, backup_id: str) -> BackupInfo:
		self._ensure_registered()
		result = with_retry(
			lambda: self._http.get(self._path(f"/backups/{quote(backup_id, safe='')}")),
			self._retry,
		)
		return _parse_backup(result["backup"])
