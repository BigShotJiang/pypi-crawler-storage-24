from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, TypedDict


KeyType = str | int | float


# --- Retry ---

@dataclass
class RetryOptions:
	max_retries_429: int = 3
	max_retries_503: int = 3
	max_retries_network: int = 1
	base_delay_429: float = 1.0
	base_delay_503: float = 1.0
	network_delay: float = 1.0


@dataclass
class MonkeyOptions:
	base_url: str = "https://api.monkeyhub.ai"
	timeout: float = 30.0
	retry: RetryOptions = field(default_factory=RetryOptions)


# --- Collection ---

class IndexDefinition(TypedDict, total=False):
	name: str  # required but TypedDict total=False for optional fields
	hashKey: str
	hashKeyType: Literal["string", "number"]
	rangeKey: str
	rangeKeyType: Literal["string", "number"]


IndexSpec = str | IndexDefinition


class KeySchema(TypedDict, total=False):
	hashKey: str
	rangeKey: str


class CollectionOptions(TypedDict, total=False):
	indexes: list[IndexSpec]
	key: KeySchema


@dataclass
class CollectionStats:
	item_count: int
	item_count_is_estimate: bool
	average_item_size_bytes: int
	indexes_declared: int
	indexes_max: int


@dataclass
class CollectionSummary:
	name: str
	key: dict[str, Any]
	indices: list[IndexSpec]
	stats: CollectionStats
	created_at: int
	updated_at: int


@dataclass
class QueryOptions:
	hash_key: KeyType | None = None
	index: str | None = None
	range_key: KeyType | None = None
	range_key_op: Literal["=", "begins_with", "<", "<=", ">", ">="] | None = None
	filter: dict[str, Any] | None = None
	limit: int | None = None
	reverse: bool | None = None
	cursor: str | None = None


@dataclass
class QueryResult:
	items: list[dict[str, Any]]
	cursor: str | None = None


@dataclass
class BackupInfo:
	id: str
	org_id: str
	db: str
	collection_name: str
	status: str
	created_at: int
	item_count: int | None = None
	file_size: int | None = None
	file_id: str | None = None
	error: str | None = None
	completed_at: int | None = None


# --- Search ---

@dataclass
class SearchQueryOptions:
	top_k: int | None = None
	filter: dict[str, Any] | None = None


@dataclass
class SearchMatch:
	key: str
	score: float
	distance: float


@dataclass
class SearchResult:
	matches: list[SearchMatch]


# --- Tasks ---

TaskStatus = Literal[
	"scheduled", "queued", "processing", "completed",
	"failed", "dead_letter", "cancelled",
]


class WebhookAuthHmac(TypedDict):
	type: Literal["hmac"]
	secret: str


class WebhookAuthBearer(TypedDict):
	type: Literal["bearer"]
	token: str


class WebhookAuthHeader(TypedDict):
	type: Literal["header"]
	name: str
	value: str


WebhookAuth = WebhookAuthHmac | WebhookAuthBearer | WebhookAuthHeader


@dataclass
class TaskSchedule:
	cron: str
	title: str | None = None
	timezone: str | None = None


class ExecutionConfig(TypedDict, total=False):
	url: str
	method: Literal["GET", "POST", "PUT", "DELETE"]
	auth: WebhookAuth
	headers: dict[str, str]
	payload: dict[str, Any]
	timeout: int
	maxRetries: int
	allowOverlap: bool


class CreateTaskInput(TypedDict, total=False):
	name: str  # required
	description: str
	tags: list[str]
	group: str
	schedules: list[dict[str, Any]]
	execution: ExecutionConfig


class UpdateTaskInput(TypedDict, total=False):
	name: str
	description: str
	tags: list[str]
	group: str
	schedules: list[dict[str, Any]]
	execution: ExecutionConfig


class RunTaskInput(TypedDict, total=False):
	payload: dict[str, Any]
	delay: int | str


@dataclass
class TaskDefinition:
	id: str
	org: str
	name: str
	status: Literal["enabled", "paused"]
	execution: dict[str, Any]
	created_at: int
	updated_at: int
	description: str | None = None
	tags: list[str] | None = None
	group: str | None = None
	schedules: list[TaskSchedule] | None = None


@dataclass
class TaskRun:
	id: str
	task_id: str
	task_name: str
	org: str
	trigger: Literal["schedule", "manual", "retry"]
	status: str
	retries: int
	created_at: int
	updated_at: int
	schedule_title: str | None = None
	payload: dict[str, Any] | None = None
	result: dict[str, Any] | None = None
	run_at: int | None = None
	started_at: int | None = None
	completed_at: int | None = None


@dataclass
class TaskListResult:
	items: list[TaskDefinition]
	cursor: str | None = None


@dataclass
class RunListResult:
	items: list[TaskRun]
	cursor: str | None = None


# --- Bucket ---

@dataclass
class PutOptions:
	visibility: Literal["public", "private"] = "private"
	metadata: dict[str, str] | None = None
	content_type: str | None = None


@dataclass
class GetUrlOptions:
	expires_in: int | None = None


@dataclass
class FileRecord:
	filename: str
	s3_key: str
	visibility: str
	content_type: str
	ext: str
	status: str
	created_at: int
	updated_at: int
	size: int | None = None
	metadata: dict[str, str] | None = None
	url: str | None = None


@dataclass
class BucketQueryOptions:
	ext: str | None = None
	prefix: str | None = None
	limit: int | None = None
	cursor: str | None = None


@dataclass
class BucketQueryResult:
	items: list[FileRecord]
	cursor: str | None = None


@dataclass
class FoldersResult:
	folders: list[str]
	files: list[str]


# --- Mail ---

class SendInput(TypedDict, total=False):
	from_addr: str  # required — maps to "from" in JSON
	to: str  # required
	subject: str  # required
	html: str
	text: str
	reply_to: str


@dataclass
class SendReceipt:
	id: str
	status: str


@dataclass
class Message:
	id: str
	from_addr: str
	to: str
	subject: str
	status: str
	created_at: int
	updated_at: int
	html: str | None = None
	text: str | None = None
	reply_to: str | None = None


@dataclass
class MailQueryOptions:
	status: str | None = None
	limit: int | None = None
	cursor: str | None = None


@dataclass
class MailQueryResult:
	items: list[Message]
	cursor: str | None = None


@dataclass
class DnsRecord:
	type: str
	name: str
	value: str
	purpose: str


@dataclass
class DomainVerification:
	domain: str
	status: str
	dns_records: dict[str, list[DnsRecord]]


@dataclass
class DomainInfo:
	domain: str
	status: str
	created_at: int
	updated_at: int
	dkim_tokens: list[str] | None = None


# --- Box ---

BoxStatus = Literal["starting", "running", "paused", "destroyed"]
BoxSize = Literal["nano", "small", "medium", "large", "xlarge"]
TerminalClientType = Literal["console", "cli", "agent"]


@dataclass
class BoxMount:
	source: str
	target: str
	readonly: bool = False


@dataclass
class BoxInfo:
	id: str
	name: str
	org_id: str
	status: str
	created_at: int
	updated_at: int
	image: str | None = None
	snapshot_id: str | None = None
	idle_timeout: int | None = None
	http_port: int | None = None
	public_http: bool = False
	size: str | None = None
	resources: dict[str, Any] | None = None
	mounts: list[BoxMount] | None = None
	pause_reason: str | None = None
	host_id: str | None = None
	url: str | None = None


class CreateBoxOptions(TypedDict, total=False):
	name: str  # required
	image: str
	snapshotId: str
	env: dict[str, str]
	mounts: list[dict[str, Any]]
	idleTimeout: int
	httpPort: int
	publicHttp: bool
	size: str


@dataclass
class ListBoxesOptions:
	status: str | None = None


@dataclass
class ExecOptions:
	timeout: int | None = None
	cwd: str | None = None
	env: dict[str, str] | None = None


@dataclass
class ExecResult:
	exit_code: int
	stdout: str
	stderr: str


@dataclass
class BoxSnapshotInfo:
	id: str
	name: str
	org_id: str
	box_id: str
	status: str
	created_at: int
	size_bytes: int | None = None


@dataclass
class BoxTemplateBuildInfo:
	id: str
	name: str
	org_id: str
	status: str
	created_at: int
	template_id: str | None = None
	error: str | None = None


class CreateTemplateBuildOptions(TypedDict, total=False):
	name: str  # required
	description: str
	from_image: str  # maps to "from" in JSON
	dockerfile: str  # required — inline Dockerfile contents
	files: dict[str, str]


@dataclass
class TemplateListEntry:
	id: str
	name: str
	type: str
	created_at: int
	description: str | None = None


@dataclass
class BoxTerminalSessionInfo:
	id: str
	box_id: str
	client_type: str
	status: str
	created_at: int
	cwd: str | None = None
	cols: int | None = None
	rows: int | None = None


class CreateTerminalOptions(TypedDict, total=False):
	clientType: str  # required
	cwd: str
	cols: int
	rows: int
