from __future__ import annotations

import threading
from typing import Any
from urllib.parse import quote

from ._box import BoxNamespace
from ._bucket import Bucket
from ._collection import Collection
from ._database import Database
from ._http import HttpClient
from ._mail import Mail
from ._search import Search
from ._tasks import TasksClient
from ._types import (
	CollectionOptions,
	CollectionStats,
	CollectionSummary,
	MonkeyOptions,
	RetryOptions,
)


class Monkey:
	"""MonkeyHub Python SDK client."""

	def __init__(self, api_key: str, options: MonkeyOptions | None = None) -> None:
		if not api_key or (not api_key.startswith("mk_live_") and not api_key.startswith("mk_pub_")):
			raise ValueError('Invalid API key. Must start with "mk_live_" or "mk_pub_".')

		opts = options or MonkeyOptions()
		self._http = HttpClient(opts.base_url, api_key, opts.timeout)
		self._retry = opts.retry
		self._lock = threading.Lock()
		self._databases: dict[str, Database] = {}
		self._collections: dict[str, Collection] = {}
		self._searches: dict[str, Search] = {}
		self._buckets: dict[str, Bucket] = {}
		self._mail: Mail | None = None
		self._tasks_client: TasksClient | None = None
		self._box = BoxNamespace(self._http, self._retry)

	def db(self, name: str) -> Database:
		with self._lock:
			existing = self._databases.get(name)
			if existing is not None:
				return existing
			database = Database(name, self._http, self._retry)
			self._databases[name] = database
			return database

	def collection(self, name: str, options: CollectionOptions | None = None) -> Collection:
		cache_key = f"default:{name}"
		with self._lock:
			existing = self._collections.get(cache_key)
			if existing is not None:
				return existing
			col = Collection(name, self._http, self._retry, options or {}, db="default")
			self._collections[cache_key] = col
			return col

	def search(self, name: str, *, fields: list[str]) -> Search:
		with self._lock:
			existing = self._searches.get(name)
			if existing is not None:
				return existing
			s = Search(name, self._http, self._retry, fields)
			self._searches[name] = s
			return s

	def list_collections(self, db: str | None = None) -> list[CollectionSummary]:
		db_name = db or "default"
		result = self._http.get(f"/api/db/{quote(db_name, safe='')}/collections")
		return [
			CollectionSummary(
				name=c["name"],
				key=c["key"],
				indices=c.get("indices", []),
				stats=CollectionStats(
					item_count=c["stats"]["itemCount"],
					item_count_is_estimate=c["stats"]["itemCountIsEstimate"],
					average_item_size_bytes=c["stats"]["averageItemSizeBytes"],
					indexes_declared=c["stats"]["indexesDeclared"],
					indexes_max=c["stats"]["indexesMax"],
				),
				created_at=c["createdAt"],
				updated_at=c["updatedAt"],
			)
			for c in result["collections"]
		]

	@property
	def tasks(self) -> TasksClient:
		if self._tasks_client is None:
			self._tasks_client = TasksClient(self._http, self._retry)
		return self._tasks_client

	def bucket(self, name: str) -> Bucket:
		with self._lock:
			existing = self._buckets.get(name)
			if existing is not None:
				return existing
			b = Bucket(name, self._http, self._retry)
			self._buckets[name] = b
			return b

	def mail(self) -> Mail:
		with self._lock:
			if self._mail is None:
				self._mail = Mail(self._http, self._retry)
			return self._mail

	@property
	def box(self) -> BoxNamespace:
		return self._box

	def close(self) -> None:
		self._http.close()

	def __enter__(self) -> Monkey:
		return self

	def __exit__(self, *args: Any) -> None:
		self.close()
