from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ._errors import NotFoundError
from ._http import HttpClient
from ._retry import with_retry
from ._types import (
	BoxInfo,
	BoxMount,
	BoxSnapshotInfo,
	BoxTemplateBuildInfo,
	BoxTerminalSessionInfo,
	CreateBoxOptions,
	CreateTemplateBuildOptions,
	ExecResult,
	RetryOptions,
	TemplateListEntry,
)


def _snake_to_camel(name: str) -> str:
	parts = name.split("_")
	if len(parts) == 1:
		return name
	return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _parse_box_info(raw: dict[str, Any]) -> BoxInfo:
	mounts = None
	if "mounts" in raw and raw["mounts"] is not None:
		mounts = [BoxMount(source=m["source"], target=m["target"], readonly=m.get("readonly", False)) for m in raw["mounts"]]
	return BoxInfo(
		id=raw["id"],
		name=raw["name"],
		org_id=raw["orgId"],
		status=raw["status"],
		created_at=raw["createdAt"],
		updated_at=raw["updatedAt"],
		image=raw.get("image"),
		snapshot_id=raw.get("snapshotId"),
		idle_timeout=raw.get("idleTimeout"),
		http_port=raw.get("httpPort"),
		public_http=raw.get("publicHttp", False),
		size=raw.get("size"),
		resources=raw.get("resources"),
		mounts=mounts,
		pause_reason=raw.get("pauseReason"),
		host_id=raw.get("hostId"),
		url=raw.get("url"),
	)


def _parse_snapshot(raw: dict[str, Any]) -> BoxSnapshotInfo:
	return BoxSnapshotInfo(
		id=raw["id"],
		name=raw["name"],
		org_id=raw["orgId"],
		box_id=raw["boxId"],
		status=raw["status"],
		created_at=raw["createdAt"],
		size_bytes=raw.get("sizeBytes"),
	)


def _parse_terminal(raw: dict[str, Any]) -> BoxTerminalSessionInfo:
	return BoxTerminalSessionInfo(
		id=raw["id"],
		box_id=raw["boxId"],
		client_type=raw["clientType"],
		status=raw["status"],
		created_at=raw["createdAt"],
		cwd=raw.get("cwd"),
		cols=raw.get("cols"),
		rows=raw.get("rows"),
	)


def _parse_build(raw: dict[str, Any]) -> BoxTemplateBuildInfo:
	return BoxTemplateBuildInfo(
		id=raw["id"],
		name=raw["name"],
		org_id=raw["orgId"],
		status=raw["status"],
		created_at=raw["createdAt"],
		template_id=raw.get("templateId"),
		error=raw.get("error"),
	)


class Box:
	"""A live box instance with methods to manage its lifecycle."""

	def __init__(self, box_id: str, http: HttpClient, retry_options: RetryOptions, snapshot_client: SnapshotNamespace | None = None) -> None:
		self.id = box_id
		self._http = http
		self._retry = retry_options
		self._snapshot_client = snapshot_client

	def _path(self, suffix: str = "") -> str:
		return f"/api/boxes/{quote(self.id, safe='')}{suffix}"

	def info(self) -> BoxInfo:
		result = with_retry(lambda: self._http.get(self._path()), self._retry)
		return _parse_box_info(result["box"])

	def pause(self) -> BoxInfo:
		result = with_retry(lambda: self._http.post(self._path("/pause"), {}), self._retry)
		return _parse_box_info(result["box"])

	def resume(self) -> BoxInfo:
		result = with_retry(lambda: self._http.post(self._path("/resume"), {}), self._retry)
		return _parse_box_info(result["box"])

	def set_idle_timeout(self, idle_timeout: int) -> BoxInfo:
		result = with_retry(
			lambda: self._http.patch(self._path(), {"idleTimeout": idle_timeout}),
			self._retry,
		)
		return _parse_box_info(result["box"])

	def destroy(self) -> None:
		with_retry(lambda: self._http.delete(self._path()), self._retry)

	def snapshot(self, *, name: str | None = None) -> BoxSnapshot:
		body: dict[str, Any] = {}
		if name is not None:
			body["name"] = name
		result = with_retry(lambda: self._http.post(self._path("/snapshot"), body), self._retry)
		snap_info = _parse_snapshot(result["snapshot"])
		return BoxSnapshot(snap_info.id, self._http, self._retry, self._snapshot_client)

	def exec(self, command: str, *, timeout: int | None = None, cwd: str | None = None, env: dict[str, str] | None = None) -> ExecResult:
		body: dict[str, Any] = {"command": command}
		if timeout is not None:
			body["timeout"] = timeout
		if cwd is not None:
			body["cwd"] = cwd
		if env is not None:
			body["env"] = env
		result = with_retry(lambda: self._http.post(self._path("/exec"), body), self._retry)
		return ExecResult(
			exit_code=result["exitCode"],
			stdout=result["stdout"],
			stderr=result["stderr"],
		)

	def upload(self, remote_path: str, content: bytes) -> None:
		import base64
		with_retry(
			lambda: self._http.put(self._path("/files"), {
				"path": remote_path,
				"content": base64.b64encode(content).decode(),
			}),
			self._retry,
		)

	def download(self, remote_path: str) -> bytes:
		import base64
		result = with_retry(
			lambda: self._http.get(self._path("/files"), {"path": remote_path}),
			self._retry,
		)
		return base64.b64decode(result["content"])

	def get_url(self) -> str:
		result = with_retry(lambda: self._http.get(self._path("/url")), self._retry)
		url: str = result["url"]
		return url

	def add_mount(self, *, source: str, target: str, readonly: bool = False) -> BoxMount:
		body: dict[str, Any] = {"source": source, "target": target}
		if readonly:
			body["readonly"] = True
		result = with_retry(lambda: self._http.post(self._path("/mounts"), body), self._retry)
		m = result["mount"]
		return BoxMount(source=m["source"], target=m["target"], readonly=m.get("readonly", False))

	def remove_mount(self, target: str) -> None:
		with_retry(
			lambda: self._http.delete(self._path("/mounts"), body={"target": target}),
			self._retry,
		)

	def list_mounts(self) -> list[BoxMount]:
		result = with_retry(lambda: self._http.get(self._path("/mounts")), self._retry)
		return [BoxMount(source=m["source"], target=m["target"], readonly=m.get("readonly", False)) for m in result["mounts"]]

	def create_terminal(self, *, client_type: str, cwd: str | None = None, cols: int | None = None, rows: int | None = None) -> BoxTerminalSessionInfo:
		body: dict[str, Any] = {"clientType": client_type}
		if cwd is not None:
			body["cwd"] = cwd
		if cols is not None:
			body["cols"] = cols
		if rows is not None:
			body["rows"] = rows
		result = with_retry(lambda: self._http.post(self._path("/terminals"), body), self._retry)
		return _parse_terminal(result["terminal"])

	def list_terminals(self) -> list[BoxTerminalSessionInfo]:
		result = with_retry(lambda: self._http.get(self._path("/terminals")), self._retry)
		return [_parse_terminal(t) for t in result["terminals"]]

	def close_terminal(self, terminal_session_id: str) -> None:
		with_retry(
			lambda: self._http.delete(self._path(f"/terminals/{quote(terminal_session_id, safe='')}")),
			self._retry,
		)


class BoxSnapshot:
	"""A snapshot reference with methods to create boxes from it."""

	def __init__(self, snapshot_id: str, http: HttpClient, retry_options: RetryOptions, snapshot_client: SnapshotNamespace | None = None) -> None:
		self.id = snapshot_id
		self._http = http
		self._retry = retry_options
		self._snapshot_client = snapshot_client

	def info(self) -> BoxSnapshotInfo:
		result = with_retry(
			lambda: self._http.get(f"/api/boxes/snapshots/{quote(self.id, safe='')}"),
			self._retry,
		)
		return _parse_snapshot(result["snapshot"])

	def create_box(self, *, name: str, **kwargs: Any) -> Box:
		body: dict[str, Any] = {"name": name, "snapshotId": self.id}
		for k, v in kwargs.items():
			if v is not None:
				body[_snake_to_camel(k)] = v
		result = with_retry(
			lambda: self._http.post("/api/boxes", body),
			self._retry,
		)
		return Box(result["box"]["id"], self._http, self._retry, self._snapshot_client)

	def delete(self) -> None:
		with_retry(
			lambda: self._http.delete(f"/api/boxes/snapshots/{quote(self.id, safe='')}"),
			self._retry,
		)


class BoxTemplate:
	"""A template reference with methods to create boxes from it."""

	def __init__(self, template_id: str, http: HttpClient, retry_options: RetryOptions, box_namespace: BoxNamespace | None = None) -> None:
		self.id = template_id
		self._http = http
		self._retry = retry_options
		self._box_namespace = box_namespace

	def info(self) -> TemplateListEntry:
		result = with_retry(
			lambda: self._http.get(f"/api/boxes/templates/{quote(self.id, safe='')}"),
			self._retry,
		)
		t = result["template"]
		return TemplateListEntry(
			id=t["id"],
			name=t["name"],
			type=t["type"],
			created_at=t["createdAt"],
			description=t.get("description"),
		)

	def create_box(self, *, name: str, **kwargs: Any) -> Box:
		body: dict[str, Any] = {"name": name, "image": self.id}
		for k, v in kwargs.items():
			if v is not None:
				body[_snake_to_camel(k)] = v
		result = with_retry(
			lambda: self._http.post("/api/boxes", body),
			self._retry,
		)
		snapshot_client = self._box_namespace.snapshots if self._box_namespace else None
		return Box(result["box"]["id"], self._http, self._retry, snapshot_client)

	def delete(self) -> None:
		with_retry(
			lambda: self._http.delete(f"/api/boxes/templates/{quote(self.id, safe='')}"),
			self._retry,
		)


class BoxNamespace:
	"""Top-level box operations: create, get, list."""

	def __init__(self, http: HttpClient, retry_options: RetryOptions) -> None:
		self._http = http
		self._retry = retry_options
		self.snapshots = SnapshotNamespace(http, retry_options, self)
		self.templates = TemplateNamespace(http, retry_options, self)
		self.template_builds = TemplateBuildNamespace(http, retry_options)

	def create(self, options: CreateBoxOptions) -> Box:
		result = with_retry(
			lambda: self._http.post("/api/boxes", dict(options)),
			self._retry,
		)
		return Box(result["box"]["id"], self._http, self._retry, self.snapshots)

	def get(self, box_id: str) -> Box | None:
		try:
			result = with_retry(
				lambda: self._http.get(f"/api/boxes/{quote(box_id, safe='')}"),
				self._retry,
			)
			return Box(result["box"]["id"], self._http, self._retry, self.snapshots)
		except NotFoundError:
			return None

	def list(self, *, status: str | None = None) -> list[BoxInfo]:
		params: dict[str, str] | None = None
		if status is not None:
			params = {"status": status}
		result = with_retry(
			lambda: self._http.get("/api/boxes", params),
			self._retry,
		)
		return [_parse_box_info(b) for b in result["boxes"]]


class SnapshotNamespace:
	"""Snapshot operations: list, get, delete."""

	def __init__(self, http: HttpClient, retry_options: RetryOptions, box_namespace: BoxNamespace | None = None) -> None:
		self._http = http
		self._retry = retry_options
		self._box_namespace = box_namespace

	def list(self) -> list[BoxSnapshotInfo]:
		result = with_retry(
			lambda: self._http.get("/api/boxes/snapshots"),
			self._retry,
		)
		return [_parse_snapshot(s) for s in result["snapshots"]]

	def get(self, snapshot_id: str) -> BoxSnapshot | None:
		try:
			with_retry(
				lambda: self._http.get(f"/api/boxes/snapshots/{quote(snapshot_id, safe='')}"),
				self._retry,
			)
			return BoxSnapshot(snapshot_id, self._http, self._retry, self)
		except NotFoundError:
			return None

	def delete(self, snapshot_id: str) -> None:
		with_retry(
			lambda: self._http.delete(f"/api/boxes/snapshots/{quote(snapshot_id, safe='')}"),
			self._retry,
		)


class TemplateNamespace:
	"""Template operations: build, list, get, delete."""

	def __init__(self, http: HttpClient, retry_options: RetryOptions, box_namespace: BoxNamespace | None = None) -> None:
		self._http = http
		self._retry = retry_options
		self._box_namespace = box_namespace

	def build(self, options: CreateTemplateBuildOptions) -> BoxTemplateBuildInfo:
		body = dict(options)
		# Remap from_image → "from" for the API
		if "from_image" in body:
			body["from"] = body.pop("from_image")
		result = with_retry(
			lambda: self._http.post("/api/boxes/templates/builds", body),
			self._retry,
		)
		return _parse_build(result["build"])

	def list(self) -> list[TemplateListEntry]:
		result = with_retry(
			lambda: self._http.get("/api/boxes/templates"),
			self._retry,
		)
		return [
			TemplateListEntry(
				id=t["id"],
				name=t["name"],
				type=t["type"],
				created_at=t["createdAt"],
				description=t.get("description"),
			)
			for t in result["templates"]
		]

	def get(self, template_id: str) -> BoxTemplate | None:
		try:
			with_retry(
				lambda: self._http.get(f"/api/boxes/templates/{quote(template_id, safe='')}"),
				self._retry,
			)
			return BoxTemplate(template_id, self._http, self._retry, self._box_namespace)
		except NotFoundError:
			return None

	def delete(self, template_id: str) -> None:
		with_retry(
			lambda: self._http.delete(f"/api/boxes/templates/{quote(template_id, safe='')}"),
			self._retry,
		)


class TemplateBuildNamespace:
	"""Template build operations: get."""

	def __init__(self, http: HttpClient, retry_options: RetryOptions) -> None:
		self._http = http
		self._retry = retry_options

	def get(self, build_id: str) -> BoxTemplateBuildInfo | None:
		try:
			result = with_retry(
				lambda: self._http.get(f"/api/boxes/templates/builds/{quote(build_id, safe='')}"),
				self._retry,
			)
			return _parse_build(result["build"])
		except NotFoundError:
			return None
