# MonkeyHub Python SDK

Python SDK for [MonkeyHub](https://monkeyhub.ai) — Backend as a Service for AI teams.

## Install

```bash
pip install monkeyhub
```

## Quickstart

```python
from monkeyhub import Monkey, PutOptions

m = Monkey("mk_live_your_key_here")

# Collections (MonkeyDB)
users = m.collection("users")
users.save({"id": "1", "name": "Alice", "role": "admin"})
user = users.find_one("1")

# Vector search (MonkeySearch)
docs = m.search("docs", fields=["title", "body"])
docs.upsert({"id": "1", "title": "Getting Started", "body": "Welcome to MonkeyHub"})
results = docs.query("getting started")

# Tasks (MonkeyTasks)
tasks = m.tasks("emails")
tasks.run({"payload": {"to": "alice@example.com", "template": "welcome"}})

# File storage (MonkeyBuckets)
bucket = m.bucket("uploads")
with open("photo.jpg", "rb") as f:
    bucket.put("photo.jpg", f.read(), PutOptions(content_type="image/jpeg"))
url = bucket.get_url("photo.jpg")

# Email (MonkeyMail)
mail = m.mail()
mail.send(from_addr="hello@example.com", to="alice@example.com", subject="Hi", text="Hello!")

# Compute boxes (MonkeyBox)
box = m.boxes.create({"name": "dev-box", "image": "default"})
result = box.exec("echo hello")
print(result.stdout)
```

## Context Manager

```python
with Monkey("mk_live_your_key_here") as m:
    col = m.collection("test")
    col.save({"id": "1", "value": "hello"})
```

## Documentation

Full documentation at [monkeyhub.ai/docs/sdk/python](https://monkeyhub.ai/docs/sdk/python).
