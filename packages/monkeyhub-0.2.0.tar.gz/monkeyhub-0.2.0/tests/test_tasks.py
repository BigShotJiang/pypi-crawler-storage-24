import pytest

from monkeyhub._tasks import TasksClient, TaskHandle
from conftest import FAST_RETRY, MockTransport, make_http_client, make_response


TASK_DEF_RAW = {
	"id": "task-1",
	"org": "org-1",
	"name": "send-emails",
	"status": "enabled",
	"execution": {"url": "https://example.com/webhook", "method": "POST"},
	"createdAt": 1000,
	"updatedAt": 1000,
	"description": "Send email notifications",
	"tags": ["email"],
	"group": "notifications",
}

RUN_RAW = {
	"id": "run-1",
	"taskId": "task-1",
	"taskName": "send-emails",
	"org": "org-1",
	"trigger": "manual",
	"status": "completed",
	"retries": 0,
	"createdAt": 1000,
	"updatedAt": 2000,
	"payload": {"to": "alice@test.com"},
}


def make_tasks_client(transport: MockTransport) -> TasksClient:
	http = make_http_client(transport)
	return TasksClient(http, FAST_RETRY)


def make_task_handle(transport: MockTransport) -> TaskHandle:
	from monkeyhub._tasks import _parse_task_def
	http = make_http_client(transport)
	return TaskHandle(_parse_task_def(TASK_DEF_RAW), http, FAST_RETRY)


class TestTasksClientCreate:
	def test_create_returns_handle(self) -> None:
		transport = MockTransport([
			make_response(200, {"task": TASK_DEF_RAW}),
		])
		client = make_tasks_client(transport)
		handle = client.create({"name": "send-emails"})
		assert handle.id == "task-1"
		assert handle.name == "send-emails"
		assert handle.status == "enabled"

		body = transport.get_request_body(0)
		assert body["name"] == "send-emails"


class TestTasksClientList:
	def test_list_tasks(self) -> None:
		transport = MockTransport([
			make_response(200, {"tasks": [TASK_DEF_RAW], "cursor": "next"}),
		])
		client = make_tasks_client(transport)
		result = client.list(group="notifications", limit=10)
		assert len(result.items) == 1
		assert result.items[0].name == "send-emails"
		assert result.cursor == "next"

		url = str(transport.requests[0].url)
		assert "group=notifications" in url
		assert "limit=10" in url

	def test_list_no_options(self) -> None:
		transport = MockTransport([
			make_response(200, {"tasks": []}),
		])
		client = make_tasks_client(transport)
		result = client.list()
		assert result.items == []


class TestTasksClientLookup:
	def test_lookup_returns_handle(self) -> None:
		transport = MockTransport([
			make_response(200, {"task": TASK_DEF_RAW}),
		])
		client = make_tasks_client(transport)
		handle = client.lookup("send-emails")
		assert handle is not None
		assert handle.id == "task-1"

	def test_lookup_returns_none_on_404(self) -> None:
		transport = MockTransport([
			make_response(404, {"message": "Not found", "code": "NOT_FOUND"}),
		])
		client = make_tasks_client(transport)
		assert client.lookup("missing") is None


class TestTasksClientUpdate:
	def test_update_returns_handle(self) -> None:
		updated = {**TASK_DEF_RAW, "description": "Updated desc"}
		transport = MockTransport([
			make_response(200, {"task": updated}),
		])
		client = make_tasks_client(transport)
		handle = client.update("task-1", {"description": "Updated desc"})
		assert handle.description == "Updated desc"

		assert transport.requests[0].method == "PUT"


class TestTasksClientRemove:
	def test_remove_task(self) -> None:
		transport = MockTransport([make_response(200, {})])
		client = make_tasks_client(transport)
		client.remove("task-1")
		assert transport.requests[0].method == "DELETE"
		assert "/api/tasks/task-1" in str(transport.requests[0].url)


class TestTaskHandlePauseResume:
	def test_pause(self) -> None:
		paused = {**TASK_DEF_RAW, "status": "paused"}
		transport = MockTransport([
			make_response(200, {"task": paused}),
		])
		handle = make_task_handle(transport)
		result = handle.pause()
		assert result.status == "paused"
		assert "/pause" in str(transport.requests[0].url)

	def test_resume(self) -> None:
		transport = MockTransport([
			make_response(200, {"task": TASK_DEF_RAW}),
		])
		handle = make_task_handle(transport)
		result = handle.resume()
		assert result.status == "enabled"
		assert "/resume" in str(transport.requests[0].url)


class TestTaskHandleRunNow:
	def test_run_now(self) -> None:
		transport = MockTransport([
			make_response(200, {"run": RUN_RAW}),
		])
		handle = make_task_handle(transport)
		run = handle.run_now({"payload": {"to": "alice@test.com"}})
		assert run.id == "run-1"
		assert run.status == "completed"
		assert "/run" in str(transport.requests[0].url)

	def test_run_now_no_input(self) -> None:
		transport = MockTransport([
			make_response(200, {"run": RUN_RAW}),
		])
		handle = make_task_handle(transport)
		run = handle.run_now()
		assert run.id == "run-1"


class TestTaskHandleRunBatch:
	def test_run_batch(self) -> None:
		transport = MockTransport([
			make_response(200, {"runs": [RUN_RAW, {**RUN_RAW, "id": "run-2"}]}),
		])
		handle = make_task_handle(transport)
		runs = handle.run_batch([{"payload": {"a": 1}}, {"payload": {"b": 2}}])
		assert len(runs) == 2
		assert "/run/batch" in str(transport.requests[0].url)

	def test_run_batch_over_limit_raises(self) -> None:
		transport = MockTransport()
		handle = make_task_handle(transport)
		with pytest.raises(ValueError, match="Maximum 10"):
			handle.run_batch([{"payload": {}} for _ in range(11)])


class TestTaskHandleHistory:
	def test_list_history(self) -> None:
		transport = MockTransport([
			make_response(200, {"runs": [RUN_RAW], "cursor": "next"}),
		])
		handle = make_task_handle(transport)
		result = handle.list_history(limit=5, status="completed")
		assert len(result.items) == 1
		assert result.cursor == "next"

		url = str(transport.requests[0].url)
		assert "limit=5" in url
		assert "status=completed" in url

	def test_get_run(self) -> None:
		transport = MockTransport([
			make_response(200, {"run": RUN_RAW}),
		])
		handle = make_task_handle(transport)
		run = handle.get_run("run-1")
		assert run is not None
		assert run.id == "run-1"

	def test_get_run_returns_none_on_404(self) -> None:
		transport = MockTransport([
			make_response(404, {"message": "Not found", "code": "NOT_FOUND"}),
		])
		handle = make_task_handle(transport)
		assert handle.get_run("missing") is None


class TestTaskHandleCancelRetry:
	def test_cancel_run(self) -> None:
		transport = MockTransport([make_response(200, {})])
		handle = make_task_handle(transport)
		handle.cancel("run-1")
		assert transport.requests[0].method == "POST"
		assert "/cancel" in str(transport.requests[0].url)

	def test_retry_run(self) -> None:
		transport = MockTransport([
			make_response(200, {"run": {**RUN_RAW, "trigger": "retry"}}),
		])
		handle = make_task_handle(transport)
		run = handle.retry("run-1")
		assert run.trigger == "retry"
		assert "/retry" in str(transport.requests[0].url)
