import pytest

from monkeyhub import Monkey, MonkeyOptions


class TestMonkeyClient:
	def test_rejects_empty_key(self) -> None:
		with pytest.raises(ValueError, match="Invalid API key"):
			Monkey("")

	def test_rejects_invalid_prefix(self) -> None:
		with pytest.raises(ValueError, match="Invalid API key"):
			Monkey("sk_live_abc123")

	def test_accepts_live_key(self) -> None:
		m = Monkey("mk_live_test_key")
		assert m is not None
		m.close()

	def test_accepts_pub_key(self) -> None:
		m = Monkey("mk_pub_test_key")
		assert m is not None
		m.close()

	def test_collection_caching(self) -> None:
		m = Monkey("mk_live_test_key")
		c1 = m.collection("users")
		c2 = m.collection("users")
		c3 = m.collection("posts")
		assert c1 is c2
		assert c1 is not c3
		m.close()

	def test_search_caching(self) -> None:
		m = Monkey("mk_live_test_key")
		s1 = m.search("docs", fields=["title"])
		s2 = m.search("docs", fields=["title"])
		s3 = m.search("other", fields=["name"])
		assert s1 is s2
		assert s1 is not s3
		m.close()

	def test_tasks_singleton(self) -> None:
		m = Monkey("mk_live_test_key")
		t1 = m.tasks
		t2 = m.tasks
		assert t1 is t2
		m.close()

	def test_db_caching(self) -> None:
		m = Monkey("mk_live_test_key")
		d1 = m.db("analytics")
		d2 = m.db("analytics")
		d3 = m.db("logs")
		assert d1 is d2
		assert d1 is not d3
		m.close()

	def test_bucket_caching(self) -> None:
		m = Monkey("mk_live_test_key")
		b1 = m.bucket("uploads")
		b2 = m.bucket("uploads")
		b3 = m.bucket("images")
		assert b1 is b2
		assert b1 is not b3
		m.close()

	def test_mail_singleton(self) -> None:
		m = Monkey("mk_live_test_key")
		m1 = m.mail()
		m2 = m.mail()
		assert m1 is m2
		m.close()

	def test_context_manager(self) -> None:
		with Monkey("mk_live_test_key") as m:
			assert m is not None

	def test_custom_options(self) -> None:
		opts = MonkeyOptions(base_url="http://localhost:3000", timeout=10.0)
		m = Monkey("mk_live_test_key", options=opts)
		assert m is not None
		m.close()
