import json

import pytest

from monkeyhub._collection import Collection
from conftest import FAST_RETRY, MockTransport, make_http_client, make_response


def make_collection(transport: MockTransport, name: str = "users", db: str = "default") -> Collection:
	http = make_http_client(transport)
	return Collection(name, http, FAST_RETRY, {}, db=db)


BACKUP_RAW = {
	"id": "bak-1",
	"orgId": "org-1",
	"db": "default",
	"collectionName": "users",
	"status": "complete",
	"createdAt": 1000,
	"itemCount": 42,
	"fileSize": 8192,
}


class TestCollectionRegistration:
	def test_first_op_registers(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"item": {"id": "1", "name": "Alice"}}),
		])
		col = make_collection(transport)
		col.find_one("1")

		assert len(transport.requests) == 2
		reg_body = transport.get_request_body(0)
		assert reg_body["name"] == "users"
		# Registration goes to /api/db/default/collections
		assert "/api/db/default/collections" in str(transport.requests[0].url)

	def test_registers_only_once(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"item": {"id": "1"}}),
			make_response(200, {"item": {"id": "2"}}),
		])
		col = make_collection(transport)
		col.find_one("1")
		col.find_one("2")

		# 1 registration + 2 find_one
		assert len(transport.requests) == 3
		# Only first request is POST /api/db/default/collections
		assert transport.requests[0].method == "POST"
		assert "/api/db/default/collections" in str(transport.requests[0].url)

	def test_custom_db(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"item": {"id": "1"}}),
		])
		col = make_collection(transport, db="analytics")
		col.find_one("1")

		assert "/api/db/analytics/collections" in str(transport.requests[0].url)
		assert "/api/db/analytics/collections/users/items/" in str(transport.requests[1].url)


class TestFindOne:
	def test_returns_item(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"item": {"id": "1", "name": "Alice"}}),
		])
		col = make_collection(transport)
		result = col.find_one("1")
		assert result == {"id": "1", "name": "Alice"}

	def test_returns_none_on_404(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(404, {"message": "Not found", "code": "NOT_FOUND"}),
		])
		col = make_collection(transport)
		result = col.find_one("missing")
		assert result is None

	def test_includes_sort_key(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"item": {"id": "1", "sk": "a"}}),
		])
		col = make_collection(transport)
		col.find_one("1", sort_key="a")
		url = str(transport.requests[1].url)
		assert "sortKey=a" in url


class TestFind:
	def test_returns_items(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"items": [{"id": "1"}, {"id": "2"}]}),
		])
		col = make_collection(transport)
		result = col.find(["1", "2"])
		assert len(result) == 2

	def test_empty_keys_returns_empty(self) -> None:
		transport = MockTransport()
		col = make_collection(transport)
		result = col.find([])
		assert result == []
		assert len(transport.requests) == 0

	def test_auto_chunks_over_100(self) -> None:
		keys = [str(i) for i in range(150)]
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"items": [{"id": str(i)} for i in range(100)]}),
			make_response(200, {"items": [{"id": str(i)} for i in range(100, 150)]}),
		])
		col = make_collection(transport)
		result = col.find(keys)
		assert len(result) == 150
		# 1 registration + 2 chunks
		assert len(transport.requests) == 3

	def test_sort_keys_length_mismatch_raises(self) -> None:
		transport = MockTransport([make_response(201, {"collection": {}})])
		col = make_collection(transport)
		with pytest.raises(ValueError, match="same length"):
			col.find(["1", "2"], sort_keys=["a"])


class TestQuery:
	def test_basic_query(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"items": [{"id": "1"}], "cursor": "abc"}),
		])
		col = make_collection(transport)
		result = col.query(hash_key="user-1")
		assert result.items == [{"id": "1"}]
		assert result.cursor == "abc"

	def test_reverse_sets_scan_forward(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"items": []}),
		])
		col = make_collection(transport)
		col.query(hash_key="user-1", reverse=True)
		body = transport.get_request_body(1)
		assert body["scanForward"] is False

	def test_path_uses_db(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"items": []}),
		])
		col = make_collection(transport, db="analytics")
		col.query(hash_key="user-1")
		assert "/api/db/analytics/collections/users/query" in str(transport.requests[1].url)


class TestSave:
	def test_single_item(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {}),
		])
		col = make_collection(transport)
		col.save({"id": "1", "name": "Alice"})
		body = transport.get_request_body(1)
		assert "item" in body
		assert body["item"]["id"] == "1"

	def test_batch_items(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {}),
		])
		col = make_collection(transport)
		col.save([{"id": "1"}, {"id": "2"}])
		body = transport.get_request_body(1)
		assert "items" in body
		assert len(body["items"]) == 2

	def test_auto_chunks_over_25(self) -> None:
		items = [{"id": str(i)} for i in range(60)]
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {}),
			make_response(200, {}),
			make_response(200, {}),
		])
		col = make_collection(transport)
		col.save(items)
		# 1 registration + 3 chunks (25 + 25 + 10)
		assert len(transport.requests) == 4

	def test_empty_list_is_noop(self) -> None:
		transport = MockTransport([make_response(201, {"collection": {}})])
		col = make_collection(transport)
		col.save([])
		# Only registration, no save
		assert len(transport.requests) == 1


class TestRemove:
	def test_delete_item(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {}),
		])
		col = make_collection(transport)
		col.remove("1")
		assert transport.requests[1].method == "DELETE"

	def test_delete_with_sort_key(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {}),
		])
		col = make_collection(transport)
		col.remove("1", sort_key="a")
		url = str(transport.requests[1].url)
		assert "sortKey=a" in url


class TestDrop:
	def test_drop_collection(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {}),
		])
		col = make_collection(transport)
		col.drop("users")
		assert transport.requests[1].method == "POST"
		assert "/drop" in str(transport.requests[1].url)
		body = transport.get_request_body(1)
		assert body["confirm"] is True

	def test_drop_wrong_name_raises(self) -> None:
		transport = MockTransport([make_response(201, {"collection": {}})])
		col = make_collection(transport)
		with pytest.raises(ValueError, match="does not match"):
			col.drop("wrong-name")


class TestBackup:
	def test_backup(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"backup": BACKUP_RAW}),
		])
		col = make_collection(transport)
		backup = col.backup()
		assert backup.id == "bak-1"
		assert backup.status == "complete"
		assert backup.item_count == 42
		assert "/backup" in str(transport.requests[1].url)

	def test_list_backups(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"backups": [BACKUP_RAW]}),
		])
		col = make_collection(transport)
		backups = col.list_backups()
		assert len(backups) == 1
		assert backups[0].id == "bak-1"
		assert "/backups" in str(transport.requests[1].url)

	def test_get_backup(self) -> None:
		transport = MockTransport([
			make_response(201, {"collection": {}}),
			make_response(200, {"backup": BACKUP_RAW}),
		])
		col = make_collection(transport)
		backup = col.get_backup("bak-1")
		assert backup.id == "bak-1"
		assert "/backups/bak-1" in str(transport.requests[1].url)
