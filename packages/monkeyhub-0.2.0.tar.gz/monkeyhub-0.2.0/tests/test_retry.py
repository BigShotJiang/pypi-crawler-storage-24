from unittest.mock import patch

import pytest

from monkeyhub._errors import NetworkError, NotFoundError, RateLimitError, ServiceError
from monkeyhub._retry import with_retry
from monkeyhub._types import RetryOptions


def fast_options(**overrides: int | float) -> RetryOptions:
	return RetryOptions(
		max_retries_429=overrides.get("max_retries_429", 2),
		max_retries_503=overrides.get("max_retries_503", 2),
		max_retries_network=overrides.get("max_retries_network", 1),
		base_delay_429=0.0,
		base_delay_503=0.0,
		network_delay=0.0,
	)


class TestWithRetry:
	def test_success_no_retry(self) -> None:
		result = with_retry(lambda: 42, fast_options())
		assert result == 42

	@patch("monkeyhub._retry.time.sleep")
	def test_429_retries_then_succeeds(self, mock_sleep) -> None:  # type: ignore[no-untyped-def]
		calls = 0

		def fn() -> str:
			nonlocal calls
			calls += 1
			if calls < 3:
				raise RateLimitError("rate limited", retry_after=0.5)
			return "ok"

		result = with_retry(fn, fast_options())
		assert result == "ok"
		assert calls == 3
		assert mock_sleep.call_count == 2

	@patch("monkeyhub._retry.time.sleep")
	def test_429_exhausts_retries(self, mock_sleep) -> None:  # type: ignore[no-untyped-def]
		def fn() -> None:
			raise RateLimitError("rate limited")

		with pytest.raises(RateLimitError):
			with_retry(fn, fast_options(max_retries_429=1))

	@patch("monkeyhub._retry.time.sleep")
	def test_503_retries(self, mock_sleep) -> None:  # type: ignore[no-untyped-def]
		calls = 0

		def fn() -> str:
			nonlocal calls
			calls += 1
			if calls < 2:
				raise ServiceError("unavailable")
				# Manually set to 503
			return "ok"

		# ServiceError has status 500, need a 503 one
		calls_503 = 0

		def fn_503() -> str:
			nonlocal calls_503
			calls_503 += 1
			if calls_503 < 2:
				err = ServiceError("unavailable")
				err.status = 503
				raise err
			return "ok"

		result = with_retry(fn_503, fast_options())
		assert result == "ok"

	@patch("monkeyhub._retry.time.sleep")
	def test_network_error_retries(self, mock_sleep) -> None:  # type: ignore[no-untyped-def]
		calls = 0

		def fn() -> str:
			nonlocal calls
			calls += 1
			if calls < 2:
				raise NetworkError("connection refused")
			return "ok"

		result = with_retry(fn, fast_options())
		assert result == "ok"
		assert calls == 2

	def test_non_retryable_error_raises_immediately(self) -> None:
		def fn() -> None:
			raise NotFoundError("not found")

		with pytest.raises(NotFoundError):
			with_retry(fn, fast_options())

	@patch("monkeyhub._retry.time.sleep")
	def test_uses_retry_after_from_rate_limit(self, mock_sleep) -> None:  # type: ignore[no-untyped-def]
		calls = 0

		def fn() -> str:
			nonlocal calls
			calls += 1
			if calls == 1:
				raise RateLimitError("slow", retry_after=2.5)
			return "ok"

		with_retry(fn, fast_options())
		mock_sleep.assert_called_once_with(2.5)
