from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from monkeyhub._http import HttpClient
from monkeyhub._types import RetryOptions


FAST_RETRY = RetryOptions(
	max_retries_429=0,
	max_retries_503=0,
	max_retries_network=0,
	base_delay_429=0.0,
	base_delay_503=0.0,
	network_delay=0.0,
)


def make_response(status: int = 200, body: Any = None, headers: dict[str, str] | None = None) -> httpx.Response:
	"""Build a mock httpx.Response."""
	content = json.dumps(body or {}).encode()
	return httpx.Response(
		status_code=status,
		content=content,
		headers={
			"content-type": "application/json",
			**(headers or {}),
		},
	)


class MockTransport(httpx.BaseTransport):
	"""Records requests and returns pre-configured responses in sequence."""

	def __init__(self, responses: list[httpx.Response] | None = None) -> None:
		self.responses = list(responses or [])
		self.requests: list[httpx.Request] = []
		self._index = 0

	def handle_request(self, request: httpx.Request) -> httpx.Response:
		self.requests.append(request)
		if self._index < len(self.responses):
			resp = self.responses[self._index]
			self._index += 1
			return resp
		# Default: return last response or 200
		if self.responses:
			return self.responses[-1]
		return make_response(200, {})

	@property
	def last_request(self) -> httpx.Request:
		return self.requests[-1]

	def get_request_body(self, index: int = -1) -> Any:
		req = self.requests[index]
		return json.loads(req.content.decode()) if req.content else None


def make_http_client(transport: MockTransport) -> HttpClient:
	"""Create an HttpClient wired to a MockTransport."""
	client = HttpClient("https://api.monkeyhub.ai", "mk_live_test_key")
	client._client = httpx.Client(transport=transport, base_url="https://api.monkeyhub.ai")
	return client


@pytest.fixture
def transport() -> MockTransport:
	return MockTransport()


@pytest.fixture
def http(transport: MockTransport) -> HttpClient:
	return make_http_client(transport)
