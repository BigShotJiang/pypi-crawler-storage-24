from unittest.mock import patch

from monkeyhub._bucket import Bucket
from monkeyhub._types import PutOptions
from conftest import FAST_RETRY, MockTransport, make_http_client, make_response


FILE_RAW = {
	"filename": "photo.jpg",
	"s3Key": "org-1/uploads/photo.jpg",
	"visibility": "private",
	"contentType": "image/jpeg",
	"ext": "jpg",
	"status": "ready",
	"createdAt": 1000,
	"updatedAt": 1000,
	"size": 1024,
}


def make_bucket(transport: MockTransport, name: str = "uploads") -> Bucket:
	http = make_http_client(transport)
	return Bucket(name, http, FAST_RETRY)


class TestPut:
	@patch("monkeyhub._bucket.time.sleep")
	@patch("monkeyhub._bucket.httpx.put")
	def test_three_step_upload(self, mock_httpx_put, mock_sleep) -> None:  # type: ignore[no-untyped-def]
		import httpx as _httpx

		mock_httpx_put.return_value = _httpx.Response(200)

		transport = MockTransport([
			# Step 1: initiate upload
			make_response(200, {
				"uploadUrl": "https://s3.example.com/presigned",
				"file": {**FILE_RAW, "status": "uploading"},
			}),
			# Step 3: poll for ready
			make_response(200, {"file": FILE_RAW}),
		])
		bucket = make_bucket(transport)
		result = bucket.put("photo.jpg", b"fake-image-data", PutOptions(content_type="image/jpeg"))

		assert result.filename == "photo.jpg"
		assert result.status == "ready"

		# Verify S3 upload was called
		mock_httpx_put.assert_called_once()
		call_args = mock_httpx_put.call_args
		assert call_args[0][0] == "https://s3.example.com/presigned"

		# Verify initiate request
		init_body = transport.get_request_body(0)
		assert init_body["filename"] == "photo.jpg"
		assert init_body["contentType"] == "image/jpeg"
		assert init_body["visibility"] == "private"


class TestGetUrl:
	def test_returns_url(self) -> None:
		transport = MockTransport([
			make_response(200, {"url": "https://cdn.example.com/photo.jpg"}),
		])
		bucket = make_bucket(transport)
		url = bucket.get_url("photo.jpg")
		assert url == "https://cdn.example.com/photo.jpg"

	def test_with_expires_in(self) -> None:
		transport = MockTransport([
			make_response(200, {"url": "https://s3.example.com/signed"}),
		])
		bucket = make_bucket(transport)
		bucket.get_url("photo.jpg", expires_in=3600)
		url = str(transport.requests[0].url)
		assert "expiresIn=3600" in url


class TestGetMeta:
	def test_returns_file_record(self) -> None:
		transport = MockTransport([
			make_response(200, {"file": FILE_RAW}),
		])
		bucket = make_bucket(transport)
		meta = bucket.get_meta("photo.jpg")
		assert meta.filename == "photo.jpg"
		assert meta.content_type == "image/jpeg"
		assert meta.size == 1024


class TestQuery:
	def test_basic_query(self) -> None:
		transport = MockTransport([
			make_response(200, {"files": [FILE_RAW], "cursor": "next"}),
		])
		bucket = make_bucket(transport)
		result = bucket.query(ext="jpg", limit=10)
		assert len(result.items) == 1
		assert result.cursor == "next"

	def test_query_with_prefix(self) -> None:
		transport = MockTransport([
			make_response(200, {"files": [FILE_RAW]}),
		])
		bucket = make_bucket(transport)
		result = bucket.query(prefix="photos/")
		assert len(result.items) == 1
		body = transport.get_request_body(0)
		assert body["prefix"] == "photos/"


class TestListFolders:
	def test_list_folders(self) -> None:
		transport = MockTransport([
			make_response(200, {"folders": ["photos/", "docs/"], "files": ["readme.txt"]}),
		])
		bucket = make_bucket(transport)
		result = bucket.list_folders()
		assert result.folders == ["photos/", "docs/"]
		assert result.files == ["readme.txt"]
		assert "/folders" in str(transport.requests[0].url)

	def test_list_folders_with_prefix(self) -> None:
		transport = MockTransport([
			make_response(200, {"folders": ["photos/2024/"], "files": []}),
		])
		bucket = make_bucket(transport)
		bucket.list_folders(prefix="photos/")
		url = str(transport.requests[0].url)
		assert "prefix=photos" in url


class TestSetVisibility:
	def test_set_visibility(self) -> None:
		transport = MockTransport([
			make_response(200, {"file": {**FILE_RAW, "visibility": "public"}}),
		])
		bucket = make_bucket(transport)
		result = bucket.set_visibility("photo.jpg", "public")
		assert result.visibility == "public"
		assert transport.requests[0].method == "PATCH"
		assert "/visibility" in str(transport.requests[0].url)
		body = transport.get_request_body(0)
		assert body["visibility"] == "public"


class TestRemove:
	def test_delete_file(self) -> None:
		transport = MockTransport([make_response(200, {})])
		bucket = make_bucket(transport)
		bucket.remove("photo.jpg")
		assert transport.requests[0].method == "DELETE"
