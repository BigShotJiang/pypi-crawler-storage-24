from monkeyhub._mail import Mail
from conftest import FAST_RETRY, MockTransport, make_http_client, make_response


MESSAGE_RAW = {
	"id": "msg-1",
	"from": "hello@example.com",
	"to": "alice@example.com",
	"subject": "Hi",
	"status": "queued",
	"createdAt": 1000,
	"updatedAt": 1000,
}


def make_mail(transport: MockTransport) -> Mail:
	http = make_http_client(transport)
	return Mail(http, FAST_RETRY)


class TestSend:
	def test_send_email(self) -> None:
		transport = MockTransport([
			make_response(200, {"id": "msg-1", "status": "queued"}),
		])
		mail = make_mail(transport)
		receipt = mail.send(
			from_addr="hello@example.com",
			to="alice@example.com",
			subject="Hi",
			text="Hello!",
		)
		assert receipt.id == "msg-1"
		assert receipt.status == "queued"

		body = transport.get_request_body(0)
		assert body["from"] == "hello@example.com"
		assert body["to"] == "alice@example.com"
		assert body["text"] == "Hello!"


class TestGetMessage:
	def test_returns_message(self) -> None:
		transport = MockTransport([
			make_response(200, {"message": MESSAGE_RAW}),
		])
		mail = make_mail(transport)
		msg = mail.get_message("msg-1")
		assert msg is not None
		assert msg.id == "msg-1"
		assert msg.from_addr == "hello@example.com"

	def test_returns_none_on_404(self) -> None:
		transport = MockTransport([
			make_response(404, {"message": "Not found", "code": "NOT_FOUND"}),
		])
		mail = make_mail(transport)
		assert mail.get_message("missing") is None


class TestQuery:
	def test_basic_query(self) -> None:
		transport = MockTransport([
			make_response(200, {"items": [MESSAGE_RAW], "cursor": "next"}),
		])
		mail = make_mail(transport)
		result = mail.query(status="queued")
		assert len(result.items) == 1
		assert result.cursor == "next"


class TestDomains:
	def test_verify_domain(self) -> None:
		transport = MockTransport([
			make_response(200, {
				"domain": "example.com",
				"status": "pending",
				"dnsRecords": {
					"required": [{"type": "TXT", "name": "_dmarc", "value": "v=DMARC1", "purpose": "dmarc"}],
					"recommended": [],
				},
			}),
		])
		mail = make_mail(transport)
		verification = mail.verify_domain("example.com")
		assert verification.domain == "example.com"
		assert verification.status == "pending"
		assert len(verification.dns_records["required"]) == 1

	def test_list_domains(self) -> None:
		transport = MockTransport([
			make_response(200, {"domains": [{
				"domain": "example.com",
				"status": "verified",
				"createdAt": 1000,
				"updatedAt": 1000,
			}]}),
		])
		mail = make_mail(transport)
		domains = mail.list_domains()
		assert len(domains) == 1
		assert domains[0].domain == "example.com"

	def test_remove_domain(self) -> None:
		transport = MockTransport([make_response(200, {})])
		mail = make_mail(transport)
		mail.remove_domain("example.com")
		assert transport.requests[0].method == "DELETE"
