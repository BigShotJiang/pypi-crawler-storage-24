from monkeyhub._box import Box, BoxNamespace, BoxSnapshot
from conftest import FAST_RETRY, MockTransport, make_http_client, make_response


BOX_RAW = {
	"id": "box-1",
	"name": "dev-box",
	"orgId": "org-1",
	"status": "running",
	"image": "default",
	"createdAt": 1000,
	"updatedAt": 1000,
}

SNAPSHOT_RAW = {
	"id": "snap_abc",
	"name": "my-snap",
	"orgId": "org-1",
	"boxId": "box-1",
	"status": "ready",
	"createdAt": 1000,
}


def make_box(transport: MockTransport, box_id: str = "box-1") -> Box:
	http = make_http_client(transport)
	return Box(box_id, http, FAST_RETRY)


def make_box_namespace(transport: MockTransport) -> BoxNamespace:
	http = make_http_client(transport)
	return BoxNamespace(http, FAST_RETRY)


class TestBoxCreate:
	def test_create_from_image(self) -> None:
		transport = MockTransport([
			make_response(200, {"box": BOX_RAW}),
		])
		ns = make_box_namespace(transport)
		box = ns.create({"name": "dev-box", "image": "default"})
		assert box.id == "box-1"

		body = transport.get_request_body(0)
		assert body["name"] == "dev-box"
		assert body["image"] == "default"


class TestBoxGet:
	def test_returns_box(self) -> None:
		transport = MockTransport([
			make_response(200, {"box": BOX_RAW}),
		])
		ns = make_box_namespace(transport)
		box = ns.get("box-1")
		assert box is not None
		assert box.id == "box-1"

	def test_returns_none_on_404(self) -> None:
		transport = MockTransport([
			make_response(404, {"message": "Not found", "code": "NOT_FOUND"}),
		])
		ns = make_box_namespace(transport)
		assert ns.get("missing") is None


class TestBoxList:
	def test_list_boxes(self) -> None:
		transport = MockTransport([
			make_response(200, {"boxes": [BOX_RAW]}),
		])
		ns = make_box_namespace(transport)
		boxes = ns.list()
		assert len(boxes) == 1
		assert boxes[0].id == "box-1"

	def test_list_with_status_filter(self) -> None:
		transport = MockTransport([
			make_response(200, {"boxes": []}),
		])
		ns = make_box_namespace(transport)
		ns.list(status="running")
		url = str(transport.requests[0].url)
		assert "status=running" in url


class TestBoxLifecycle:
	def test_info(self) -> None:
		transport = MockTransport([
			make_response(200, {"box": BOX_RAW}),
		])
		box = make_box(transport)
		info = box.info()
		assert info.id == "box-1"
		assert info.status == "running"

	def test_pause(self) -> None:
		transport = MockTransport([
			make_response(200, {"box": {**BOX_RAW, "status": "paused"}}),
		])
		box = make_box(transport)
		info = box.pause()
		assert info.status == "paused"

	def test_resume(self) -> None:
		transport = MockTransport([
			make_response(200, {"box": BOX_RAW}),
		])
		box = make_box(transport)
		info = box.resume()
		assert info.status == "running"

	def test_set_idle_timeout(self) -> None:
		transport = MockTransport([
			make_response(200, {"box": {**BOX_RAW, "idleTimeout": 600}}),
		])
		box = make_box(transport)
		box.set_idle_timeout(600)
		body = transport.get_request_body(0)
		assert body["idleTimeout"] == 600

	def test_destroy(self) -> None:
		transport = MockTransport([make_response(200, {})])
		box = make_box(transport)
		box.destroy()
		assert transport.requests[0].method == "DELETE"


class TestBoxExec:
	def test_exec_command(self) -> None:
		transport = MockTransport([
			make_response(200, {"exitCode": 0, "stdout": "hello\n", "stderr": ""}),
		])
		box = make_box(transport)
		result = box.exec("echo hello")
		assert result.exit_code == 0
		assert result.stdout == "hello\n"

	def test_exec_with_options(self) -> None:
		transport = MockTransport([
			make_response(200, {"exitCode": 0, "stdout": "", "stderr": ""}),
		])
		box = make_box(transport)
		box.exec("ls", cwd="/tmp", timeout=5000)
		body = transport.get_request_body(0)
		assert body["cwd"] == "/tmp"
		assert body["timeout"] == 5000


class TestBoxSnapshot:
	def test_create_snapshot(self) -> None:
		transport = MockTransport([
			make_response(200, {"snapshot": SNAPSHOT_RAW}),
		])
		box = make_box(transport)
		snap = box.snapshot(name="my-snap")
		assert snap.id == "snap_abc"

	def test_snapshot_info(self) -> None:
		transport = MockTransport([
			make_response(200, {"snapshot": SNAPSHOT_RAW}),
		])
		http = make_http_client(transport)
		snap = BoxSnapshot("snap_abc", http, FAST_RETRY)
		info = snap.info()
		assert info.name == "my-snap"

	def test_snapshot_delete(self) -> None:
		transport = MockTransport([make_response(200, {})])
		http = make_http_client(transport)
		snap = BoxSnapshot("snap_abc", http, FAST_RETRY)
		snap.delete()
		assert transport.requests[0].method == "DELETE"


class TestBoxMounts:
	def test_add_mount(self) -> None:
		transport = MockTransport([
			make_response(200, {"mount": {"source": "/data", "target": "/mnt/data", "readonly": False}}),
		])
		box = make_box(transport)
		mount = box.add_mount(source="/data", target="/mnt/data")
		assert mount.source == "/data"
		assert mount.target == "/mnt/data"

	def test_list_mounts(self) -> None:
		transport = MockTransport([
			make_response(200, {"mounts": [{"source": "/data", "target": "/mnt/data", "readonly": True}]}),
		])
		box = make_box(transport)
		mounts = box.list_mounts()
		assert len(mounts) == 1
		assert mounts[0].readonly is True

	def test_remove_mount(self) -> None:
		transport = MockTransport([make_response(200, {})])
		box = make_box(transport)
		box.remove_mount("/mnt/data")
		assert transport.requests[0].method == "DELETE"


class TestBoxTerminals:
	def test_create_terminal(self) -> None:
		transport = MockTransport([
			make_response(200, {"terminal": {
				"id": "term_abc",
				"boxId": "box-1",
				"clientType": "console",
				"status": "active",
				"createdAt": 1000,
			}}),
		])
		box = make_box(transport)
		term = box.create_terminal(client_type="console", cols=80, rows=24)
		assert term.id == "term_abc"
		assert term.client_type == "console"

	def test_list_terminals(self) -> None:
		transport = MockTransport([
			make_response(200, {"terminals": [{
				"id": "term_abc",
				"boxId": "box-1",
				"clientType": "console",
				"status": "active",
				"createdAt": 1000,
			}]}),
		])
		box = make_box(transport)
		terminals = box.list_terminals()
		assert len(terminals) == 1

	def test_close_terminal(self) -> None:
		transport = MockTransport([make_response(200, {})])
		box = make_box(transport)
		box.close_terminal("term_abc")
		assert transport.requests[0].method == "DELETE"


class TestSnapshots:
	def test_list_snapshots(self) -> None:
		transport = MockTransport([
			make_response(200, {"snapshots": [SNAPSHOT_RAW]}),
		])
		ns = make_box_namespace(transport)
		snapshots = ns.snapshots.list()
		assert len(snapshots) == 1
		assert snapshots[0].id == "snap_abc"

	def test_delete_snapshot(self) -> None:
		transport = MockTransport([make_response(200, {})])
		ns = make_box_namespace(transport)
		ns.snapshots.delete("snap_abc")
		assert transport.requests[0].method == "DELETE"


class TestTemplates:
	def test_build_template(self) -> None:
		transport = MockTransport([
			make_response(200, {"build": {
				"id": "tplb_abc",
				"name": "my-template",
				"orgId": "org-1",
				"status": "queued",
				"createdAt": 1000,
			}}),
		])
		ns = make_box_namespace(transport)
		build = ns.templates.build({"name": "my-template", "dockerfile": "FROM ubuntu"})
		assert build.id == "tplb_abc"
		assert build.status == "queued"

	def test_list_templates(self) -> None:
		transport = MockTransport([
			make_response(200, {"templates": [{
				"id": "tpl_abc",
				"name": "my-template",
				"type": "custom",
				"createdAt": 1000,
			}]}),
		])
		ns = make_box_namespace(transport)
		templates = ns.templates.list()
		assert len(templates) == 1
		assert templates[0].id == "tpl_abc"

	def test_delete_template(self) -> None:
		transport = MockTransport([make_response(200, {})])
		ns = make_box_namespace(transport)
		ns.templates.delete("tpl_abc")
		assert transport.requests[0].method == "DELETE"
