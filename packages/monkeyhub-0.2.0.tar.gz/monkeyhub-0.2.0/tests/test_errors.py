from monkeyhub._errors import (
	ConflictError,
	ForbiddenError,
	MonkeyError,
	NotFoundError,
	PayloadTooLargeError,
	QuotaExceededError,
	RateLimitError,
	ServiceError,
	UnauthorizedError,
	ValidationError,
	error_from_response,
)


class TestErrorHierarchy:
	def test_base_error_fields(self) -> None:
		err = MonkeyError(500, "TEST", "test message", "req-1")
		assert err.status == 500
		assert err.code == "TEST"
		assert err.message == "test message"
		assert err.request_id == "req-1"
		assert str(err) == "test message"

	def test_subclass_default_status(self) -> None:
		cases: list[tuple[type[MonkeyError], int]] = [
			(NotFoundError, 404),
			(UnauthorizedError, 401),
			(ForbiddenError, 403),
			(ValidationError, 400),
			(ConflictError, 409),
			(PayloadTooLargeError, 413),
			(QuotaExceededError, 402),
			(RateLimitError, 429),
			(ServiceError, 500),
		]
		for cls, expected_status in cases:
			err = cls()
			assert err.status == expected_status
			assert isinstance(err, MonkeyError)

	def test_rate_limit_retry_after(self) -> None:
		err = RateLimitError(retry_after=5.0)
		assert err.retry_after == 5.0

	def test_quota_details(self) -> None:
		err = QuotaExceededError(
			"Over limit",
			"req-1",
			reason="storage",
			dimension="bytes",
			used=100,
			limit=50,
			suggested_plan="pro",
			upgrade_url="https://example.com/upgrade",
		)
		assert err.reason == "storage"
		assert err.dimension == "bytes"
		assert err.used == 100
		assert err.limit == 50
		assert err.suggested_plan == "pro"
		assert err.upgrade_url == "https://example.com/upgrade"


class TestErrorFromResponse:
	def test_maps_status_codes(self) -> None:
		cases: list[tuple[int, type[MonkeyError]]] = [
			(400, ValidationError),
			(401, UnauthorizedError),
			(402, QuotaExceededError),
			(403, ForbiddenError),
			(404, NotFoundError),
			(409, ConflictError),
			(413, PayloadTooLargeError),
			(500, ServiceError),
		]
		for status, expected_cls in cases:
			err = error_from_response(status, {"message": "test", "requestId": "r1"})
			assert isinstance(err, expected_cls)
			assert err.message == "test"
			assert err.request_id == "r1"

	def test_429_with_retry_after_header(self) -> None:
		err = error_from_response(
			429,
			{"message": "slow down"},
			{"retry-after": "3"},
		)
		assert isinstance(err, RateLimitError)
		assert err.retry_after == 3.0

	def test_429_default_retry_after(self) -> None:
		err = error_from_response(429, {"message": "slow down"})
		assert isinstance(err, RateLimitError)
		assert err.retry_after == 1.0

	def test_503_maps_to_service_error(self) -> None:
		err = error_from_response(503, {"message": "unavailable"})
		assert isinstance(err, ServiceError)

	def test_unknown_status(self) -> None:
		err = error_from_response(418, {"message": "teapot", "code": "TEAPOT"})
		assert isinstance(err, MonkeyError)
		assert err.status == 418
		assert err.code == "TEAPOT"

	def test_missing_message_fallback(self) -> None:
		err = error_from_response(500, {})
		assert err.message == "HTTP 500"

	def test_quota_details_from_body(self) -> None:
		err = error_from_response(402, {
			"message": "limit reached",
			"suggestedPlan": "pro",
			"upgradeUrl": "https://example.com",
			"used": 10,
			"limit": 5,
		})
		assert isinstance(err, QuotaExceededError)
		assert err.suggested_plan == "pro"
		assert err.upgrade_url == "https://example.com"
