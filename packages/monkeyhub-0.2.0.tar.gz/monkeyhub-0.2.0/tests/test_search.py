import pytest

from monkeyhub._search import Search
from conftest import FAST_RETRY, MockTransport, make_http_client, make_response


def make_search(transport: MockTransport, name: str = "docs") -> Search:
	http = make_http_client(transport)
	return Search(name, http, FAST_RETRY, fields=["title", "body"])


class TestSearchRegistration:
	def test_first_op_registers(self) -> None:
		transport = MockTransport([
			make_response(201, {}),
			make_response(200, {}),
		])
		s = make_search(transport)
		s.upsert({"id": "1", "title": "Hello"})

		reg_body = transport.get_request_body(0)
		assert reg_body["name"] == "docs"
		assert reg_body["fields"] == ["title", "body"]


class TestUpsert:
	def test_single_item(self) -> None:
		transport = MockTransport([
			make_response(201, {}),
			make_response(200, {}),
		])
		s = make_search(transport)
		s.upsert({"id": "1", "title": "Hello"})
		body = transport.get_request_body(1)
		assert "item" in body

	def test_multiple_items(self) -> None:
		transport = MockTransport([
			make_response(201, {}),
			make_response(200, {}),
		])
		s = make_search(transport)
		s.upsert([{"id": "1"}, {"id": "2"}])
		body = transport.get_request_body(1)
		assert "items" in body
		assert len(body["items"]) == 2

	def test_empty_is_noop(self) -> None:
		transport = MockTransport([make_response(201, {})])
		s = make_search(transport)
		s.upsert([])
		assert len(transport.requests) == 1


class TestQuery:
	def test_basic_query(self) -> None:
		transport = MockTransport([
			make_response(201, {}),
			make_response(200, {
				"matches": [{"key": "1", "score": 0.95, "distance": 0.05}],
			}),
		])
		s = make_search(transport)
		result = s.query("hello world")
		assert len(result.matches) == 1
		assert result.matches[0].key == "1"
		assert result.matches[0].score == 0.95

	def test_empty_text_raises(self) -> None:
		transport = MockTransport([make_response(201, {})])
		s = make_search(transport)
		with pytest.raises(ValueError, match="requires text"):
			s.query("")

	def test_with_options(self) -> None:
		transport = MockTransport([
			make_response(201, {}),
			make_response(200, {"matches": []}),
		])
		s = make_search(transport)
		s.query("test", top_k=5, filter={"status": "active"})
		body = transport.get_request_body(1)
		assert body["topK"] == 5
		assert body["filter"] == {"status": "active"}


class TestRemove:
	def test_remove_by_key(self) -> None:
		transport = MockTransport([
			make_response(201, {}),
			make_response(200, {}),
		])
		s = make_search(transport)
		s.remove("1")
		assert transport.requests[1].method == "DELETE"


class TestCount:
	def test_returns_vector_count(self) -> None:
		transport = MockTransport([
			make_response(201, {}),
			make_response(200, {"index": {"vectorCount": 42}}),
		])
		s = make_search(transport)
		assert s.count() == 42
