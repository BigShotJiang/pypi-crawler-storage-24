import hashlib
import hmac
import time
from unittest.mock import patch

from monkeyhub._webhook import verify_webhook


def make_signature(body: str, secret: str, timestamp: int) -> str:
	digest = hmac.new(
		secret.encode(),
		f"{timestamp}.{body}".encode(),
		hashlib.sha256,
	).hexdigest()
	return f"sha256={digest}"


class TestVerifyWebhook:
	def test_valid_signature(self) -> None:
		ts = int(time.time())
		body = '{"event":"task.completed"}'
		secret = "whsec_test123"
		sig = make_signature(body, secret, ts)

		assert verify_webhook(
			signature=sig,
			timestamp=ts,
			body=body,
			secret=secret,
		) is True

	def test_invalid_signature(self) -> None:
		ts = int(time.time())
		assert verify_webhook(
			signature="sha256=invalid",
			timestamp=ts,
			body="{}",
			secret="whsec_test123",
		) is False

	def test_expired_timestamp(self) -> None:
		old_ts = int(time.time()) - 400  # > 5 minutes ago
		body = "{}"
		secret = "whsec_test123"
		sig = make_signature(body, secret, old_ts)

		assert verify_webhook(
			signature=sig,
			timestamp=old_ts,
			body=body,
			secret=secret,
		) is False

	def test_string_timestamp(self) -> None:
		ts = int(time.time())
		body = '{"event":"test"}'
		secret = "whsec_test123"
		sig = make_signature(body, secret, ts)

		assert verify_webhook(
			signature=sig,
			timestamp=str(ts),
			body=body,
			secret=secret,
		) is True

	@patch("monkeyhub._webhook.time.time")
	def test_future_timestamp_within_5_min(self, mock_time) -> None:  # type: ignore[no-untyped-def]
		mock_time.return_value = 1000000.0
		ts = 1000200  # 200 seconds in the future
		body = "{}"
		secret = "secret"
		sig = make_signature(body, secret, ts)

		assert verify_webhook(
			signature=sig,
			timestamp=ts,
			body=body,
			secret=secret,
		) is True
