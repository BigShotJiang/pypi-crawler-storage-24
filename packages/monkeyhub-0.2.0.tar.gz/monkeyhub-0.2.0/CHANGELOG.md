# Changelog

## 0.2.0

Bring Python SDK up to date with TypeScript SDK.

- Align API surface with TypeScript SDK v0.2.0
- Updated collection, search, task, bucket, box, and mail interfaces

## 0.1.0

Initial release of the MonkeyHub Python SDK.

- MonkeyDB collections: CRUD, batch operations, querying with indexes
- MonkeySearch: vector upsert, similarity queries, count
- MonkeyTasks: task submission, scheduling, configuration
- MonkeyBuckets: file upload (presigned S3), download URLs, metadata
- MonkeyMail: send email, domain verification, message queries
- MonkeyBox: compute boxes, snapshots, templates, terminals, exec
- Webhook signature verification
- Automatic retry with exponential backoff (429, 503, network errors)
- Context manager support
- PEP 561 typed package
