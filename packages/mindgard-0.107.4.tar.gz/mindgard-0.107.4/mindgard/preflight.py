# Standard library imports
import logging
from typing import Tuple

# Third party imports
from rich.console import Console

from .exceptions import HTTPBaseError, MGException, Uncontactable
from .wrappers.llm import LLMModelWrapper


def preflight_llm(
    model_wrapper: LLMModelWrapper,
    console: Console,
    json_out: bool,
) -> bool:
    """
    Makes requests to the LLM to validate basic connectivity before submitting
    test.

    Returns True on success, False on failure
    """
    try:
        if not json_out:
            console.print("[white]Contacting target...")
        model_wrapper.__call__("Hello llm, are you there?")
        return True
    except Uncontactable as cerr:
        logging.debug(cerr)
        model_api = model_wrapper.api_url if hasattr(model_wrapper, "api_url") else "<unknown>"
        if not json_out:
            console.print(
                f"[red]Could not connect to the target! [white](URL: {model_api}, are you sure it's correct?)"
            )
    except HTTPBaseError as httpbe:
        logging.debug(httpbe)
        message: str = f"[red]Target pre-flight check returned {httpbe.status_code} ({httpbe.status_message})"
        if httpbe.status_code == 401:
            message += " Is your API token correct/valid/permissive?"
        if not json_out:
            console.print(message)
        raise MGException(f"{httpbe}")
    except Exception as e:
        # something we've not really accounted for caught
        logging.error(e)
        raise e

    return False
