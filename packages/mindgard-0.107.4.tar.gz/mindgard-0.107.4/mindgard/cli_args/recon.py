from ..constants import ENABLE_DEV_FEATURES
from .shared import add_shared_arguments
from .types import _SubparserType


def add_recon_command(subparsers: _SubparserType):
    recon_parser = subparsers.add_parser(
        "recon", help="Run various reconnaissance techniques against your target system"
    )
    recon_subparsers = recon_parser.add_subparsers(title="Recon subcommands", dest="recon_subcommand", required=True)

    # Define prod recon subcommands
    subcommands = {
        "guardrail": "Run guardrail reconnaissance against your target system",
        "input-encoding": "Run input encoding reconnaissance against your target system",
        "output-encoding": "Run output encoding reconnaissance against your target system",
        "system-prompt-extraction": "Run system prompt extraction against your target system",
        "tool-discovery": "Run tool discovery reconnaissance against your target system",
        "output-formatting": "Run output formatting reconnaissance against your target system",
        "output-rendering": "Run output rendering reconnaissance against your target system",
    }
    # Add dev recon subcommands
    if ENABLE_DEV_FEATURES:
        subcommands["non-contextual"] = "Run non-contextual reconnaissance against your target system"
        subcommands["code-generation"] = "Run code generation reconnaissance against your target system"

    for cmd, help_text in subcommands.items():
        subparser = recon_subparsers.add_parser(cmd, help=help_text)
        add_shared_arguments(subparser)

        if ENABLE_DEV_FEATURES and cmd == "guardrail":
            subparser.add_argument(
                "--accept-fingerprinting",
                action="store_true",
                help="Automatically perform guardrail fingerprinting if prompted. WARNING: fingerprinting will fire ~120 prompts at your target system.",
                required=False,
            )

    return recon_parser
