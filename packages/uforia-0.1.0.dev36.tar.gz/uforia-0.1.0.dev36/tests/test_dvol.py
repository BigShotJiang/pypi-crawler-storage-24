from __future__ import annotations

from datetime import datetime, timezone

from uforia.ingest.deribit.dvol import fetch_dvol


class StubDeribitClient:
    def get_volatility_index_data(
        self,
        currency: str,
        start: datetime,
        end: datetime,
        resolution: str = "3600",
    ) -> dict[str, object]:
        assert currency == "BTC"
        assert resolution == "3600"
        return {
            "data": [
                [1773039600000, 60.89, 61.16, 60.67, 60.67],
                [1773043200000, 60.67, 60.79, 59.65, 59.68],
            ],
            "continuation": None,
        }


def test_fetch_dvol_preserves_deribit_index_units() -> None:
    start = datetime(2026, 3, 8, 9, tzinfo=timezone.utc)
    end = datetime(2026, 3, 8, 10, tzinfo=timezone.utc)

    frame = fetch_dvol(start=start, end=end, client=StubDeribitClient())

    assert frame.height == 2
    assert frame.item(0, "dvol_open") == 60.89
    assert frame.item(0, "dvol_close") == 60.67
    assert frame.item(1, "dvol_low") == 59.65
    assert frame.item(1, "dvol_close") == 59.68
