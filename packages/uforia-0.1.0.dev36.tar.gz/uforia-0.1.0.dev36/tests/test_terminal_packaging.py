from __future__ import annotations

from importlib.metadata import entry_points


def test_terminal_console_script_is_registered() -> None:
    scripts = [entry for entry in entry_points(group="console_scripts") if entry.name == "uforia"]

    assert len(scripts) == 1
    assert scripts[0].value == "uforia.terminal.app:app"


def test_admin_console_script_is_registered() -> None:
    scripts = [entry for entry in entry_points(group="console_scripts") if entry.name == "uforia-admin"]

    assert len(scripts) == 1
    assert scripts[0].value == "uforia.cli:app"
