from __future__ import annotations

from datetime import datetime, timedelta, timezone

import polars as pl

from uforia.signals import compute_rvvix


def test_compute_rvvix_generates_window_columns() -> None:
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    rows = []
    for hour in range(24 * 20):
        ts = start + timedelta(hours=hour)
        rows.append(
            {
                "ts": ts,
                "date": ts.date(),
                "source": "dvol",
                "value": 50.0 + (hour % 12),
                "quality_flag": "ok",
            }
        )
    frame = pl.DataFrame(rows)
    result = compute_rvvix(frame, windows=(7, 14))
    assert "rvvix_7d" in result.columns
    assert "rvvix_14d" in result.columns
    assert result["rvvix_7d"].drop_nulls().len() > 0
