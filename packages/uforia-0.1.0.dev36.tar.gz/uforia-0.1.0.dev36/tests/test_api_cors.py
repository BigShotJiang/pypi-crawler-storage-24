from __future__ import annotations

from fastapi.testclient import TestClient

from uforia.api.app import create_app


def test_api_allows_private_lan_origin_for_browser_refresh() -> None:
    client = TestClient(create_app())

    response = client.options(
        "/api/v1/system/health",
        headers={
            "Origin": "http://192.168.1.69:3000",
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "http://192.168.1.69:3000"
