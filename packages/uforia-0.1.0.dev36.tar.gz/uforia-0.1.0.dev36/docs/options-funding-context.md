# Options Funding Context

## What it measures
Funding Context places perpetual funding alongside the vol regime so crowded basis positioning can be read next to options stress.

Exact inputs:
- `funding_rate_snapshot`
- `funding_context_series`
- `vvix_series`

Derived fields:
- `funding_rate`
- `funding_rate_zscore`
- `funding_change_24h`
- `funding_regime`
- joined `rvvix_14d` and `qvvix_30d`

## How to interpret it
- Very positive funding means crowded longs; very negative funding means crowded shorts.
- Funding extremes are more dangerous when `VVIX` is also elevated.

## Trade use
- Use stretched funding plus rising vol-of-vol as a warning against carry harvesting.
- Use normalizing funding after an extreme as confirmation that crowding is unwinding.

## Failure modes
- Funding can remain extreme in trend regimes.
- Funding alone is not a volatility signal.

## Pair with
- [Options Carry / VRP](options-carry-vrp.md)
- [Options Vol Regime Transitions](options-vol-regime-transitions.md)
