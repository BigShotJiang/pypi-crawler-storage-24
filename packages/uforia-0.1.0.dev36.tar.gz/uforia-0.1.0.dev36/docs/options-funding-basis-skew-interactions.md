# Options Funding-Basis Skew Interactions

## Inputs
- `surface_features`
- `funding_context_series`
- `perps_signal_series`

## Core Fields
- `basis_bps`
- `funding_rate`
- `funding_rate_zscore`
- `skew_richness`
- `basis_pressure`
- `funding_basis_skew_score`
- `regime`

## Interpretation
- positive score: crowded basis pressure reinforcing downside-rich skew
- negative score: upside-rich or squeeze-prone skew setup

## Failure Modes
- venue-specific basis distortions can dominate the read
- funding extremes can persist through trends

## Quality Flags
- `ok`: funding and skew inputs available
