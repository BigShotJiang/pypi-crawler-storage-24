# Composite Index

The `Composite` family produces three separate hourly indices for `BTC`, `ETH`, and the weighted market aggregate:

- `sentiment_index` on `0-100`
- `directional_tilt` on `-100 to +100`
- `fragility_index` on `0-100`

Why three indices instead of one:
- sentiment measures crowding, fear, greed, and complacency
- directional tilt measures where the market is leaning next
- fragility measures squeeze, cascade, and overshoot risk

These are intentionally not collapsed into one number because the same market can be:
- fearful and bullish
- greedy and bearish
- neutral but structurally fragile

Publication behavior:
- when upstream history is thin, the composite prefers publishing a low-confidence, degraded-quality reading over returning `null`
- this is most relevant for new signal families or recently initialized assets
- treat `partial_context` and `insufficient_data` readings as context, not firm decision signals

Primary datasets:
- `composite_signal_series`
- `composite_component_series`
- `composite_transition_series`

Primary UI surfaces:
- `/composite`
- `/composite/composite_overview`
- `/composite/composite_btc`
- `/composite/composite_eth`
- `/composite/composite_market`
- `/composite/composite_decomposition`

Primary API surfaces:
- `/api/v1/composite/signals`
- `/api/v1/composite/signals/{signal_id}/latest`
- `/api/v1/composite/signals/{signal_id}/series`
- `/api/v1/composite/decomposition/{signal_id}`
- `/api/v1/composite/transitions/{signal_id}`
