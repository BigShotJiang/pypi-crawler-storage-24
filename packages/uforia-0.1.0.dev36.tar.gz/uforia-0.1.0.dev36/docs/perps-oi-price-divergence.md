# Perps OI-Price Divergence

## What it measures
Whether leverage is building or unwinding independently of price.

## Inputs
- `microstructure_raw_event.open_interest`
- `microstructure_bar.close`
- carry and crowding fields from `perps_signal_series`

## Derived fields
- `oi_change_1h`
- `oi_change_4h`
- `oi_change_24h`
- `price_change_1h`
- `oi_price_divergence`
- `oi_acceleration`
- `leverage_regime`

## How to interpret it
- Rising OI with little price movement means leverage is being added quietly.
- Negative divergence means positioning and price are moving out of sync.
- `oi_acceleration` helps separate slow accumulation from increasingly urgent leverage build.

## Trade use cases
- Use divergence to find crowded setups before the unwind starts.
- Use the regime label to separate leverage build from orderly deleveraging.
- Combine with funding-basis carry to tell whether the leverage is expensive or still cheap.

## Caveats
- OI can move for mechanical reasons around contract rolls or venue-specific changes.
- Divergence alone does not tell you direction; it tells you fragility and positioning stress.

## Companion dashboards
- `funding_basis_carry`
- `liquidation_cascade`
- `cum_delta_momentum`
