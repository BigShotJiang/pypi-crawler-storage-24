# Perps Depth Resilience

## What it measures
How quickly the order book refills after aggressive flow and whether spread conditions are normal or stressed.

## Inputs
- `microstructure_book_state.depth_notional_bid_5`
- `microstructure_book_state.depth_notional_ask_5`
- `microstructure_book_state.spread`
- aggressive trade notional from `microstructure_raw_event`

## Derived fields
- `depth_recovery_speed`
- `spread_bps`
- `spread_zscore_4h`
- `spread_zscore_24h`
- `depth_imbalance_momentum`
- `spread_regime`

## How to interpret it
- Fast `depth_recovery_speed` means the market is resilient and can absorb aggressive flow.
- High spread z-scores mean makers are widening and market quality is deteriorating.
- Rising `depth_imbalance_momentum` shows the book is leaning harder in one direction.

## Trade use cases
- Use resilience as a filter for whether momentum can keep running.
- Avoid fading flow when spread and resilience are both deteriorating.
- Use tight spreads with high carry as a sign that crowding is present but not yet stressed.

## Caveats
- Book metrics can shift sharply during exchange incidents or data gaps.
- Depth resilience is a structural condition, not a direct entry signal.

## Companion dashboards
- `order_flow_toxicity`
- `liquidation_cascade`
- `funding_basis_carry`
