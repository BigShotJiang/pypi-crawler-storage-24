# Perps Volatility Microstructure

## What it measures
How realized volatility behaves across short sampling frequencies and whether the market is noisy or trending.

## Inputs
- `microstructure_bar.close` at `5s` and `60s`

## Derived fields
- `rv_5s`
- `rv_1m`
- `rv_5m`
- `vol_signature_ratio`
- `vol_clustering`
- `rv_regime`

## How to interpret it
- `vol_signature_ratio > 1` means the market is dominated by microstructure noise.
- Lower signature ratios indicate cleaner directional movement.
- High `vol_clustering` means recent volatility is self-reinforcing rather than episodic.

## Trade use cases
- Use the signature ratio to decide whether momentum or mean-reversion logic should dominate.
- Combine elevated RV with high toxicity to identify genuine stress, not just noise.
- Use RV regime shifts as context for changing confidence thresholds.

## Caveats
- Sparse 5-second history can produce `insufficient_history`.
- Short-term RV jumps are sensitive to exchange-specific pauses and gaps.

## Companion dashboards
- `order_flow_toxicity`
- `cross_venue_price_discovery`
- `cum_delta_momentum`
