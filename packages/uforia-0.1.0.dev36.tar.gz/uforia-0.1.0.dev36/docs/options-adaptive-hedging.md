# Options Adaptive Hedging

## Inputs
- ATM option rows from `option_chain_snapshot`
- `surface_features`
- realized vol from spot history
- `funding_context_series`
- `perps_signal_series`

## Core Fields
- `smile_aware_delta`: ATM delta adjusted by short-dated skew
- `min_var_delta`: realized-to-implied variance scaled delta
- `hedge_band_width`: no-trade region width
- `expected_hedge_bleed_bps`: estimated cost of over-hedging
- `basis_mismatch_bps`: perp-versus-option mismatch proxy
- `route_score`: hedge route quality score
- `route_preference`: `perp` or `nearby_future`

## Interpretation
- wider bands mean hedge less frequently
- worse route score means edge can be destroyed by implementation

## Scope
- research overlay only
- no live orders or live hedge scheduler

## Quality Flags
- `ok`: ATM greeks available
- `insufficient_data`: no usable ATM hedge snapshot
