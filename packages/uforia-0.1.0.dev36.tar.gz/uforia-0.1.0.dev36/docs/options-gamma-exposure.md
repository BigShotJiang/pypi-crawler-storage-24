# Options Gamma Exposure

## What it measures
Gamma Exposure aggregates persisted option gamma into expiry and strike buckets to show where hedging pressure is concentrated.

Exact inputs:
- `option_chain_snapshot` with persisted `gamma`
- `gamma_exposure_series`

Derived fields:
- `gamma_exposure`
- `gamma_share`
- `pinning_concentration`

## How to interpret it
- High ATM pinning concentration suggests sticky behavior near central strikes.
- Large wing exposure suggests more hedging sensitivity if the market reaches those zones.

## Trade use
- Reduce breakout conviction near strong ATM pinning.
- Use wing gamma pockets to understand where tail hedging demand is most likely to distort price action or quotes.

## Failure modes
- This is still an exposure map, not a full dealer positioning model.
- Exposure can be large without becoming active if spot never approaches the relevant strikes.

## Pair with
- [Options Positioning / Flow](options-positioning.md)
- [Options Dislocations](options-dislocations.md)
