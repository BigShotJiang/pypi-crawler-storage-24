# Options Cross-Asset Relative Value

## What it measures
The Cross-Asset Relative Value dashboard compares BTC and ETH across shared options dimensions. It uses:
- `surface_features`
- `vvix_series`
- `razor_series`
- `options_carry_series`
- `options_relative_value_series`

## Derived fields
- `atm_iv_spread_7d`, `atm_iv_spread_30d`
- `skew_spread_30d`
- `vvix_spread`
- `razor_spread`
- `spread_zscore`
- `relative_regime`

## How to interpret it
- Positive spreads mean BTC is richer than ETH on that dimension.
- Negative spreads mean ETH is richer.
- Relative-value signals are cleaner when both assets share the same broad risk regime.

## Trade use
- Use this page for pair-style vol trades when outright exposure feels too regime-sensitive.
- Confirm whether the spread is ATM-led, skew-led, or VVIX-led before structuring the trade.
- Use the z-score to screen setups, not to size them blindly.

## Caveats
- Asset-specific catalysts can break the spread relationship.
- Relative cheapness is not the same as absolute cheapness.

## Pair with
- `docs/options-surface.md`
- `docs/options-carry-vrp.md`
- `docs/options-signals.md`
