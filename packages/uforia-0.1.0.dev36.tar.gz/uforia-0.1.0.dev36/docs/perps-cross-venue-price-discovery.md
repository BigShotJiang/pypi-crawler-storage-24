# Perps Cross-Venue Price Discovery

## What it measures
Which venue is leading the perp complex and how quickly dislocations close.

## Inputs
- `microstructure_bar.close`
- `microstructure_bar.venue_group`
- derivative venue pairs from Binance and Bybit

## Derived fields
- `lead_lag_score`
- `venue_dislocation_bps`
- `convergence_half_life_secs`
- `price_discovery_leader`

## How to interpret it
- Positive `lead_lag_score` means Binance is leading Bybit; negative means the reverse.
- High `venue_dislocation_bps` indicates local stress or informed flow on one venue.
- Longer `convergence_half_life_secs` means dislocations are not arbitraging away quickly.

## Trade use cases
- Use the leader venue as the primary confirmation source during fast moves.
- Treat slow convergence as a warning that cross-venue hedges may not neutralize risk quickly.
- Pair with toxicity and spread stress to confirm if the leader is seeing informed flow.

## Caveats
- The v1 implementation uses lead-lag/dislocation rather than full information-share estimation.
- Sparse cross-venue coverage produces `partial_context`.

## Companion dashboards
- `order_flow_toxicity`
- `depth_resilience`
- `vol_microstructure`
