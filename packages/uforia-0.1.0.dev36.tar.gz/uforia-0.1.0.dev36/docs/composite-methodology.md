# Composite Methodology

## Inputs

The composite only consumes already-built upstream datasets:

- `VVIX`
  - `rvvix_14d`
  - `qvvix_30d`
- `Razor`
  - `razor_pnl_zscore`
  - `razor_vrp_zscore`
- `Options`
  - `vol_carry_score`
  - `skew_stress_score`
  - `ml_carry_toxicity_score`
  - `funding_skew_score`
  - `sessionality_score`
  - `dispersion_score`
  - `expiry_pin_score`
  - `gamma_flip_score`
- `Perps`
  - `carry_score`
  - `positioning_score`
  - `cascade_risk_score`
  - `fragility_score`
  - `toxicity_score`
  - directional/context fields from `perps_signal_series`
- `Microstructure`
  - active horizon outputs from `microstructure_model_output`

## Normalization

Each usable component is transformed with:

1. rolling z-score
2. winsorization/clipping
3. sign alignment so contribution direction is consistent within each pillar

Primary path:
- a standard rolling z-score with a fuller history requirement

Sparse-history fallback:
- if the full rolling window is not yet available, the composite falls back to a lower-sample rolling normalization on the same lookback window
- fallback-normalized components are intentionally attenuated, so the index can publish a weak reading instead of `null`
- fallback publication should usually show up with lower confidence and a degraded `quality_flag`

Missing data is never zero-filled. Instead:
- that component weight is dropped
- coverage falls
- confidence falls
- `quality_flag` can degrade to `partial_context` or `insufficient_data`

## Pillars

### Sentiment

Built from:
- options sentiment subindex
- perps sentiment subindex
- microstructure context subindex

Default weights:
- options `0.40`
- perps `0.40`
- microstructure `0.20`

### Directional

Built from:
- microstructure directional subindex
- perps directional subindex
- options directional subindex

Default weights:
- microstructure `0.60`
- perps `0.30`
- options `0.10`

### Fragility

Built from:
- perps fragility subindex
- options fragility subindex
- microstructure fragility subindex

Default weights:
- perps `0.40`
- options `0.40`
- microstructure `0.20`

## Hybrid calibration

V1 uses fixed pillar weights first, then a small calibrator:

- sentiment and fragility use percentile/isotonic-style calibration when enough history exists
- directional uses a shallow ridge-style calibration on next-return behavior

If the calibrator is data-poor or unstable:
- the system falls back to fixed-weight outputs
- publication continues
- confidence reflects the fallback state

## Market aggregate

The market composite is built after the asset-level composites:

- BTC weight `0.65`
- ETH weight `0.35`

This keeps the asset-level structure interpretable and avoids mixing raw BTC/ETH signals before normalization.
