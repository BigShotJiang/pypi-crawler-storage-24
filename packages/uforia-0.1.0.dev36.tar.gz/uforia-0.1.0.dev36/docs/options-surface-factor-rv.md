# Options Surface Factor RV

## Inputs
- `options_surface_snapshot`
- liquidity from `open_interest`, `volume`, and `mean_spread`

## Core Fields
- `factor_return_1h`: liquidity-weighted average node return
- `factor_momentum_24h`: rolling 24h factor momentum
- `node_residual`: node return minus common factor return
- `node_residual_zscore`: rolling residual z-score by tenor and moneyness bucket
- `residual_value_score`: residual z-score scaled by liquidity weight

## Interpretation
- positive `factor_momentum_24h`: common surface repricing is persistent
- positive `residual_value_score`: locally cheap node after removing factor move
- negative `residual_value_score`: locally rich node

## Failure Modes
- sparse strikes distort local node returns
- poor liquidity can make residuals look larger than they are

## Quality Flags
- `ok`: node return available
- `insufficient_data`: no valid previous node observation
