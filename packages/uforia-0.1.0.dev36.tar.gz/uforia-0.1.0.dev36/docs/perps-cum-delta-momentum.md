# Perps Cumulative Delta Momentum

## What it measures
Whether trade imbalance is accelerating, exhausting, or being absorbed without much price movement.

## Inputs
- `microstructure_bar.buy_volume`
- `microstructure_bar.sell_volume`
- `microstructure_raw_event.trade_notional`
- `microstructure_bar.close`

## Derived fields
- `cum_delta_acceleration`
- `delta_divergence`
- `absorption_ratio`
- `delta_regime`

## How to interpret it
- Positive acceleration means buy-side pressure is intensifying; negative means sell pressure is intensifying.
- High `delta_divergence` means pressure and price are moving out of sync.
- High `absorption_ratio` means the market is absorbing flow without letting price travel much.

## Trade use cases
- Use aggressive delta regimes to confirm breakout attempts.
- Use divergence plus high absorption to identify exhaustion rather than confirmation.
- Pair with OI divergence to separate real leverage build from transient aggressive flow.

## Caveats
- Delta signals can whipsaw in noisy conditions.
- Absorption is sensitive to how trade notional and price movement are sampled.

## Companion dashboards
- `oi_price_divergence`
- `order_flow_toxicity`
- `vol_microstructure`
