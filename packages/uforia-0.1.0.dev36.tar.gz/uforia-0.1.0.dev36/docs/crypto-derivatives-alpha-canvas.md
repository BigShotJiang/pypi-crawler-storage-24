# Crypto Derivatives Alpha Canvas

## Goal
Implement the PDF's P1 and P2 research stack as read-only analytics inside the existing options and perps platform.

## Coverage Map
- `surface factor momentum` -> `options_surface_factor_series` -> `surface_factor_rv` -> `surface_factor_score`
- `residual surface mean reversion` -> `options_surface_factor_series` -> `surface_factor_rv` -> `residual_surface_rv_score`
- `ML carry with toxicity veto` -> `options_ml_carry_series` -> `ml_carry_toxicity` -> `ml_carry_toxicity_score` using ATM IV minus forecast RV, then implementation-cost vetoes
- `expiry pinning / gamma flip` -> `options_expiry_flow_series` -> `expiry_flow_map` -> `expiry_pin_score`, `gamma_flip_score`
- `smile-aware / adaptive hedging` -> `options_adaptive_hedge_series` -> `adaptive_hedging` -> `adaptive_hedge_score`
- `sessionality and funding clocks` -> `options_sessionality_series` -> `sessionality_clocks` -> `sessionality_score`
- `BTC-ETH dispersion` -> `options_dispersion_series` -> `btc_eth_dispersion` -> `dispersion_score` using a surface-implied correlation proxy, not a listed basket implied correlation
- `funding-basis x skew` -> `options_funding_skew_series` -> `funding_basis_skew` -> `funding_skew_score`

## Build Order
Per asset (`BTC`, `ETH`):
- `uv run uforia-admin build options-surface`
- `uv run uforia-admin build options-carry`
- `uv run uforia-admin build options-skew`
- `uv run uforia-admin build options-dislocations`
- `uv run uforia-admin build options-positioning`
- `uv run uforia-admin build vol-cone`
- `uv run uforia-admin build term-structure-momentum`
- `uv run uforia-admin build gamma-exposure`
- `uv run uforia-admin build funding-context`
- `uv run uforia-admin build straddle-breakeven`
- `uv run uforia-admin build surface-factor-rv`
- `uv run uforia-admin build ml-carry-toxicity`
- `uv run uforia-admin build expiry-flow-map`
- `uv run uforia-admin build adaptive-hedging`
- `uv run uforia-admin build sessionality-clocks`
- `uv run uforia-admin build funding-basis-skew`

Cross-asset:
- `uv run uforia-admin build options-rv`
- `uv run uforia-admin build btc-eth-dispersion`

Composite:
- `uv run uforia-admin build options-signals`
- `uv run uforia-admin build vol-regime-transitions`

Umbrella:
- `uv run uforia-admin build alpha-canvas --start ... --end ... --underlyings BTC,ETH`

The Mac Mini hourly refresh now builds these alpha-canvas datasets directly; they are not one-off research-only artifacts anymore. If these dashboards ever show `unknown`, the first thing to check is whether the latest refresh run completed successfully for the affected time window.

## Scope Boundary
- Research-only analytics and dashboards
- No live hedging engine
- No maker quoting engine
- No RL hedge scheduler
- Dealer-flow is inferred from OI, strike concentration, greeks, and perp context because historical option trade sign is not available
