# Options Surface Dislocations

## What it measures
The Surface Dislocation dashboard compares market quotes against the fitted SSVI surface. It uses:
- `option_chain_snapshot`
- fitted surface parameters from `surface_features`
- `options_dislocation_series`

## Derived fields
- `atm_residual`: average residual near the center of the smile
- `wing_residual`: average residual in the tails
- `max_residual`: largest absolute local mismatch
- `mean_abs_residual`: broad dislocation level
- `dislocation_zscore`: normalized residual stress

## How to interpret it
- Broad residual expansion often means the whole surface is moving quickly or fit quality is weak.
- Localized residuals are more actionable than broad parallel repricing.
- Persistent local distortions matter more than one-off prints.

## Trade use
- Use isolated rich wings for relative-value sales.
- Use cheap local points to source convexity without paying for the whole surface.
- Prefer RV structures over outright vol trades when dislocations are high but the macro regime is mixed.

## Caveats
- Poor fit quality can create false residuals.
- Sparse tenors can exaggerate residuals.

## Pair with
- `docs/options-surface.md`
- `docs/options-positioning.md`
- `docs/options-signals.md`
