# Options Surface

## What it measures
The Vol Surface dashboard summarizes the smile and term structure from archived Deribit option snapshots. It uses:
- `option_chain_snapshot`
- `surface_features`
- `options_surface_snapshot`

The dashboard focuses on:
- mean IV by tenor and moneyness bucket
- IV change over `1h`, `24h`, and `7d`
- term structure context from `surface_features`

## Derived fields
- `mean_mark_iv`: average bucket IV
- `iv_change_1h`, `iv_change_24h`, `iv_change_7d`: bucket repricing
- `option_count`, `open_interest`, `volume`: liquidity and coverage context

## How to interpret it
- ATM-led repricing usually means the market is moving its base volatility estimate.
- Wing-led repricing usually means crash insurance or squeeze protection is repricing faster than the center.
- Front-end only repricing points to event risk or a short-lived stress window.
- Parallel shifts across tenors are broader regime changes.

## Trade use
- Prefer straddles when ATM is moving harder than wings.
- Prefer strangles or wing expressions when tails are repricing independently.
- Use calendars when front-end vol is repricing much faster than back-end vol.

## Caveats
- Low coverage can make wings look unstable.
- A single local distortion should be checked against Surface Dislocation before treating it as a regime shift.

## Pair with
- `options-skew.md`
- `options-dislocations.md`
- `docs/btc-vvix-pipeline.md`
