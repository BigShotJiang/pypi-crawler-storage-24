# Options BTC-ETH Dispersion

## Inputs
- BTC and ETH `surface_features`
- BTC and ETH spot history derived from `option_chain_snapshot`

## Core Fields
- `implied_correlation`: matched-tenor surface-implied correlation proxy from rolling BTC/ETH ATM IV co-moves
- `realized_correlation`
- `realized_corr_forecast`
- `corr_gap`: implied-correlation proxy minus forecast realized correlation
- `rr_richness_spread`
- `bf_richness_spread`
- `cross_smile_consistency`
- `dispersion_score`
- `dispersion_regime`

## Interpretation
- positive `corr_gap`: the surface-implied correlation proxy is richer than forecast realized correlation
- low `cross_smile_consistency`: do not trust dispersion without checking skew contamination

## Quality Flags
- `ok`: aligned BTC/ETH tenor observations, IV co-move history, and realized-correlation forecast available
- `insufficient_data`: missing aligned surface or correlation history
