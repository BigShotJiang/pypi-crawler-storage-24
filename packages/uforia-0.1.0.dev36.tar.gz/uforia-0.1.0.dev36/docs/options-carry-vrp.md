# Options Carry / VRP

## What it measures
Carry / VRP compares short-dated implied vol against realized vol and now pairs that with vol-cone and funding context.

Exact inputs:
- `surface_features`
- `options_carry_series`
- `vol_cone_series`
- `funding_context_series`
- `vvix_series`
- `razor_series`

Derived fields used on the dashboard:
- `carry_spread_7d`, `carry_spread_30d`
- `term_carry_7_30`
- `roll_down_carry`
- `carry_zscore`
- `carry_regime`

## How to interpret it
- Rich carry means the market is charging more short-dated premium than recent movement has delivered.
- Cheap carry means the gamma you are selling is no longer obviously well paid.
- Rich carry is safer when `qVVIX` and funding are calm; it is more dangerous when vol-of-vol and directional crowding are rising together.

## Trade use
- Short premium when carry is rich, roll-down is positive, funding is not stretched, and `VVIX` is not expanding.
- Prefer long gamma when carry has compressed, the breakeven gap is improving, and front-end term momentum is steepening.
- Use the cone percentiles to decide whether “rich” is merely above normal or historically extreme.

## Failure modes
- Carry can stay rich in calm regimes and become richer before it mean reverts.
- Short realized-vol windows can understate latent event risk.
- Funding extremes can dominate options carry if perp positioning is very crowded.

## Pair with
- [Options Vol Cone](options-vol-cone.md)
- [Options Funding Context](options-funding-context.md)
- [Options Signals](options-signals.md)
