# Perps Order Flow Toxicity

## What it measures
Whether aggressive flow looks informed enough to force makers to widen and reduce liquidity.

## Inputs
- `microstructure_raw_event.trade_notional`
- `microstructure_raw_event.side`
- `microstructure_bar.buy_volume`
- `microstructure_bar.sell_volume`

## Derived fields
- `vpin_50`
- `toxic_flow_zscore_4h`
- `toxic_flow_zscore_24h`
- `ofi_persistence`
- `large_trade_ratio`
- `toxicity_regime`

## How to interpret it
- High `vpin_50` means flow is imbalanced enough to look informed rather than noisy.
- Persistent `ofi_persistence` means the imbalance is not washing out quickly.
- High `large_trade_ratio` suggests the move is being driven by concentrated aggressive size.

## Trade use cases
- Use toxicity as a filter for momentum strategies and a blocker for passive mean-reversion.
- Pair with depth resilience to distinguish informed flow from thin-market noise.
- Watch for toxicity rising before spread stress shows up in the book.

## Caveats
- VPIN-style proxies are sensitive to bucket construction and volume mix.
- Low liquidity windows can look toxic even when the move is not durable.

## Companion dashboards
- `depth_resilience`
- `vol_microstructure`
- `cross_venue_price_discovery`


## Quality semantics
- The perps workbench quality badge is dashboard-specific. A row can still be usable for order-flow toxicity even if unrelated cross-venue or basis fields are sparse.
- `partial_context` should mainly indicate that fields required for this dashboard are missing, not that some other perps family field on the same timestamp is null.
