# Perps Liquidation Cascade

## What it measures
How vulnerable the perp market is to a liquidation-driven move.

## Inputs
- `microstructure_raw_event.trade_notional`
- `microstructure_raw_event.liquidation_side`
- `microstructure_raw_event.open_interest`
- `microstructure_book_state.depth_notional_bid_5`
- `microstructure_book_state.depth_notional_ask_5`
- carry context from `perps_signal_series`

## Derived fields
- `long_liq_notional`
- `short_liq_notional`
- `liq_intensity_zscore`
- `liq_asymmetry`
- `oi_concentration`
- `crowding_score`
- `cascade_risk_score`
- `cascade_regime`

## How to interpret it
- Rising `oi_concentration` means more leverage is sitting on less depth.
- High `liq_intensity_zscore` with one-sided `liq_asymmetry` signals an ongoing stress unwind.
- High `cascade_risk_score` means the market is structurally fragile even before price breaks.

## Trade use cases
- Use as a filter against carry trades when the market is already fragile.
- Combine with spread/depth stress to identify likely continuation conditions.
- Track asymmetry to tell whether the stress is long-side or short-side.

## Caveats
- Liquidation feeds can be venue-specific and incomplete.
- A high risk score is a setup condition, not a timing trigger by itself.

## Companion dashboards
- `funding_basis_carry`
- `depth_resilience`
- `order_flow_toxicity`
