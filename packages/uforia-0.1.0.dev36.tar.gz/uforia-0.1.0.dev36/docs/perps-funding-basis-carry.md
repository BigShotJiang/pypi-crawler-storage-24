# Perps Funding-Basis Carry

## What it measures
The total cost or income of holding perp exposure, combining spot-vs-perp basis and hourly funding into a single carry view.

## Inputs
- `microstructure_bar.close`
- `microstructure_bar.market_type`
- `funding_rate_snapshot.interest_1h`

## Derived fields
- `basis_bps = ((perp_mid - spot_mid) / spot_mid) * 10000`
- `carry_annualized_pct = basis_pct + funding_rate_1h * 24 * 365 * 100`
- `carry_zscore_7d`
- `carry_zscore_30d`
- `carry_momentum_1h`
- `carry_momentum_24h`
- `cross_venue_funding_spread`

## How to interpret it
- High positive carry means long perp exposure is expensive and positioning is crowded.
- Sharp carry compression often precedes squeeze-style moves or forced deleveraging.
- Negative carry with weak basis suggests shorts are paying to stay in the trade.

## Trade use cases
- Fade crowded carry when `carry_zscore_7d` and `carry_zscore_30d` are both extended.
- Pair with liquidation and OI dashboards to see whether expensive carry is fragile or stable.
- Use `cross_venue_funding_spread` to spot venue-specific crowding before it spreads.

## Caveats
- Requires both spot and perp context for a full row.
- Funding can stay extreme during stress; do not short carry blindly without fragility context.

## Companion dashboards
- `liquidation_cascade`
- `oi_price_divergence`
- `depth_resilience`
