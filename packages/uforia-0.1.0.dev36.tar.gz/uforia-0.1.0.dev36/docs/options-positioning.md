# Options Positioning / Flow

## What it measures
Positioning / Flow tracks where open interest and volume are concentrated across expiry and moneyness buckets.

Exact inputs:
- `option_chain_snapshot`
- `options_positioning_series`
- companion gamma view: `gamma_exposure_series`

For historical snapshots captured before `gamma` was persisted in the normalized option-chain dataset, use the archive rebuild command to re-normalize from stored raw Deribit payloads:

```bash
uv run uforia-admin maintenance rebuild-options-from-archive \
  --underlying BTC \
  --start 2026-03-09T00:00:00Z \
  --end 2026-03-09T23:00:00Z
```

Derived fields:
- `open_interest`, `open_interest_change`
- `open_interest_share`
- `volume_share`
- `atm_pinning_concentration`
- `wing_concentration`

## How to interpret it
- High ATM pinning concentration means the market is crowded near central strikes and expiry behavior can become sticky.
- High wing concentration means the market is warehousing more tail risk away from spot.
- Rising OI with rising volume is stronger than volume alone; pure volume can be churn.

## Trade use
- Use pinning concentration to lower breakout conviction into expiry.
- Use wing concentration to judge whether skew moves are being confirmed by positioning or are just quote noise.
- Use the page together with Gamma Exposure to separate “crowded” from “crowded and hedging-relevant.”

## Failure modes
- OI is not directional by itself.
- Bucketed aggregates lose single-strike detail.
- Positioning can stay crowded for a long time before it matters.
- Gamma Exposure only lights up once the canonical option snapshot rows actually contain `gamma`; old raw archives need one rebuild pass to populate that history.

## Pair with
- [Options Gamma Exposure](options-gamma-exposure.md)
- [Options Skew](options-skew.md)
- [Options Dislocations](options-dislocations.md)
