# Research UI Platform

## Goal
Provide a reusable internal research and operator UI that can serve current Python analytics and future Rust engines through one API contract.

## Backend API
The first backend host is Python.

Main modules:
- `src/uforia/api/app.py`
- `src/uforia/api/providers/default.py`
- `src/uforia/api/models.py`
- `src/uforia/contracts.py`

Implemented API resources:
- `GET /api/v1/system/health`
- `GET /api/v1/signals`
- `GET /api/v1/signals/{signal_id}/latest`
- `GET /api/v1/signals/{signal_id}/series`
- `GET /api/v1/datasets`
- `GET /api/v1/datasets/{dataset_id}`
- `GET /api/v1/datasets/{dataset_id}/rows`
- `GET /api/v1/runs`
- `GET /api/v1/runs/summary`
- `GET /api/v1/engines`
- `WS /api/v1/stream`

The API is read-only in v1 and uses provider interfaces so future producers can be swapped behind the same contract.

## Frontend
The UI lives in `apps/web` and is built with Next.js App Router and TypeScript.

Current sections:
- `Overview`
- `Signals`
- `Datasets`
- `Runs`
- `Engines`

Current signal UI features implemented:
- BTC VVIX workspace
- ETH VVIX workspace
- BTC Razor workspace
- ETH Razor workspace
- latest tiles for either VVIX metrics or Razor metrics depending on signal family
- live status badge backed by WebSocket updates
- synchronized signal chart
- range and quality controls
- recent run context
- dataset browser and runs inspection

Important files:
- `apps/web/app/layout.tsx`
- `apps/web/features/overview/overview-dashboard.tsx`
- `apps/web/features/signals/signal-workspace.tsx`
- `apps/web/features/datasets/dataset-browser.tsx`
- `apps/web/features/runs/runs-board.tsx`
- `apps/web/lib/api/client.ts`
- `apps/web/lib/ws/use-stream.ts`
