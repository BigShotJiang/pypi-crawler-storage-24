# Options Vol Cone

## What it measures
The Vol Cone dashboard ranks current implied and realized vol against their own trailing history by tenor.

Exact inputs:
- `surface_features`
- `vol_cone_series`

Derived fields:
- `implied_vol`
- `realized_vol`
- `iv_rv_spread`
- `implied_percentile`
- `realized_percentile`
- `iv_rv_spread_percentile`

## How to interpret it
- High implied percentile with low realized percentile means the market is charging rich premium.
- High implied and high realized percentiles together usually mean a genuinely stressed regime.
- High spread percentile is the cleanest historical signal that carry is rich.

## Trade use
- Use the cone to decide whether a rich carry reading is merely above average or historically stretched.
- Use depressed cone readings after compression to screen for long-gamma entries.

## Failure modes
- Rolling percentiles are unstable early in the sample.
- Structural regime changes can make trailing percentiles misleading.

## Pair with
- [Options Carry / VRP](options-carry-vrp.md)
- [Options Straddle Breakeven](options-straddle-breakeven.md)
