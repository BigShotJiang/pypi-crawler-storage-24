# Options Skew / Crash Premium

## What it measures
The Skew / Crash Premium dashboard shows how expensive downside insurance is relative to upside. It uses:
- `surface_features`
- `options_skew_series`

## Derived fields
- `rr_25_7d`, `rr_25_30d`: short and medium-dated risk reversals
- `skew_slope`: front-end skew minus 30-day skew
- `skew_zscore`: normalized crash-premium pressure
- `spot_move_24h`: recent underlying move
- `crash_premium_regime`: `panic`, `unwind`, or `neutral`

## How to interpret it
- More negative short-dated skew means downside protection is getting more expensive.
- A sharp front-end steepening often signals immediate stress rather than a durable long-horizon regime.
- A skew unwind after a panic can precede broader vol normalization.

## Trade use
- Use skew stress to decide whether to sell symmetric premium or avoid the downside wing.
- Use skew unwinds as a filter for re-entering short-vol after a panic.
- Use calm skew with rising ATM vol to prefer neutral long-vol structures over crash hedges.

## Caveats
- Skew can remain steep through clustered downside moves.
- Spot direction alone does not explain skew.

## Pair with
- `docs/options-positioning.md`
- `docs/options-carry-vrp.md`
- `docs/options-surface.md`
