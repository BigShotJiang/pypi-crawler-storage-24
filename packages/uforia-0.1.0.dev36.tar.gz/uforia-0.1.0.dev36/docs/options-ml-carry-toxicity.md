# Options ML Carry Toxicity

## Inputs
- `options_carry_series`
- `surface_features`
- `funding_context_series`
- `perps_composite_series`
- `options_surface_snapshot`
- realized vol from spot history

## Core Fields
- `forecast_rv_7d`: HAR-style realized vol blend
- `jump_risk_score`: recent spot move plus skew and butterfly stress proxy
- `toxicity_score`: perps composite toxicity or funding fallback
- `expected_hedge_cost`: spread plus implied-vol-based bleed proxy
- `funding_drag`: perpetual funding cost proxy
- `gross_carry_spread`: ATM IV minus forecast RV
- `gross_carry_score`: z-score of the IV-minus-forecast-RV spread
- `net_carry_score`: gross carry minus toxicity, jump, hedge, spread, and funding penalties
- `carry_veto`: hard stop when implementation risk dominates

## Interpretation
- positive `net_carry_score`: carry survives implementation costs
- `carry_veto = true`: do not trust raw carry

## Quality Flags
- `ok`: forecast and penalties available
- `insufficient_data`: missing realized-vol forecast
