# Options Composite Signals

## Signals
The options composite layer now includes:
- `vol_carry_score`
- `skew_stress_score`
- `surface_dislocation_score`
- `cross_asset_vol_score`
- `vol_regime_score`
- `funding_vol_context_score`
- `breakeven_gap_score`
- `term_structure_momentum_score`

## Exact inputs
- `options_carry_series`
- `options_skew_series`
- `options_dislocation_series`
- `options_relative_value_series`
- `funding_context_series`
- `straddle_breakeven_series`
- `term_structure_momentum_series`
- `vvix_series`
- `razor_series`

## How to interpret them
- `vol_carry_score`: higher means richer short-dated carry and better short-vol carry conditions.
- `skew_stress_score`: higher means crash-premium pressure is elevated.
- `surface_dislocation_score`: higher means local quote-versus-fit distortions are larger.
- `cross_asset_vol_score`: positive means BTC is richer than ETH on the spread basket.
- `funding_vol_context_score`: higher means funding is stretched in the same direction as an unstable vol regime.
- `breakeven_gap_score`: higher means realized movement is outrunning short-dated breakevens.
- `term_structure_momentum_score`: higher means front-end pressure is accelerating.
- `vol_regime_score`: higher means a more defensive long-vol regime; lower means a calmer short-vol regime.

Thresholds are no longer fixed at a hardcoded `±1` band. The platform now calibrates rolling long/short thresholds from recent score history, so regime classification becomes more stable as live data accumulates.

## How to use them
- Use scores as ranking and filtering tools, not standalone execution triggers.
- Start from the score, then open the matching dashboard for the raw drivers.
- Treat disagreement across carry, funding, and `VVIX` as a reason to reduce conviction.
- Treat `quality_flag=insufficient_data` as a real state, not a missing UI bug. The adaptive thresholds need a minimum amount of recent hourly history before the regime labels become trustworthy.

## Example trade usage
- Rich carry but high `funding_vol_context_score`: avoid blindly selling premium into crowded stress.
- Positive `breakeven_gap_score` with rising term momentum: favor long gamma over short carry.
- High `surface_dislocation_score` with neutral regime: prefer relative-value trades over outright vol direction.

## Failure modes
- Scores are only as good as the datasets beneath them.
- Short live-forward histories can make normalization unstable.
- Regime scores can lag abrupt structural breaks.
- Adaptive thresholds can also lag a true structural regime shift. If market structure changes abruptly, the rolling quantiles may remain anchored to the old regime for a while.

## Pair with
- [Options Carry / VRP](options-carry-vrp.md)
- [Options Funding Context](options-funding-context.md)
- [Options Straddle Breakeven](options-straddle-breakeven.md)
