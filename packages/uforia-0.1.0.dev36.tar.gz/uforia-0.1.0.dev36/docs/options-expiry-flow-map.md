# Options Expiry Flow Map

## Inputs
- `option_chain_snapshot`
- strike, expiry, gamma, vega, delta, open interest

## Core Fields
- `pain_strike`: OI-weighted strike centroid
- `dominant_strike`: highest-OI strike in the local expiry and strike bucket
- `distance_to_pain_pct`: spot distance from pain strike
- `gamma_exposure`, `vanna_exposure`, `charm_exposure`
- `pinning_score`: positive-gamma concentration proxy
- `breakout_score`: vanna/charm plus distance-from-pain breakout proxy
- `flow_regime`: `positive_gamma_pin`, `negative_gamma_breakout`, or `neutral`

## Interpretation
- high `pinning_score`: expiry magnet conditions
- high `breakout_score`: dealer hedging may amplify rather than damp

## Failure Modes
- no option trade sign, so flow remains inferred
- sparse expiry buckets can overstate dominant strike effects
- missing greeks downgrade the row to partial context instead of silently zeroing pin or breakout exposures

## Quality Flags
- `ok`: enough option rows and greek coverage to form expiry buckets
- `partial_context`: expiry bucket exists but one or more greek exposures are only partially observed
- `insufficient_data`: expiry bucket exists but greek context is effectively unavailable
