# Options Straddle Breakeven

## What it measures
The Straddle Breakeven dashboard measures how far spot needs to move for a fresh `7D` ATM straddle to break even, then compares that implied move to what the underlying has actually been delivering.

It answers a simple question:
- is short-dated gamma currently priced too rich or too cheap relative to recent realized movement?

The dashboard is built from `straddle_breakeven_series`.

## Inputs
- `surface_features`
  - `atm_iv_7d`
- spot/index levels from `option_chain_snapshot`
- related context from:
  - `vvix_series`
  - `razor_series`
  - `options_signal_series`

## Derived fields
- `breakeven_move`
  - estimated move required for a fresh `7D` ATM straddle to break even
- `trailing_realized_move`
  - realized move over the matching recent horizon
- `breakeven_gap`
  - realized move minus implied breakeven move
- `quality_flag`
  - marks whether the estimate is based on a valid short-end surface state

The default approximation is:

`breakeven_move = atm_iv_7d * sqrt(7 / 365)`

## How to interpret it
High positive `breakeven_gap`:
- realized movement has been exceeding the move implied by the short-end straddle
- gamma has likely been underpriced
- this supports long-gamma or long-vol expressions, especially if carry is not extremely punitive

Deeply negative `breakeven_gap`:
- short-dated vol has been charging for more movement than spot has been delivering
- short-gamma carry is likely rich
- this supports short-vol structures, but only if `VVIX` and skew are not warning about a stressed regime

Fast change in `breakeven_gap`:
- often matters more than the level alone
- a rapid move from negative to positive usually means spot has started outrunning the carry assumptions embedded in short-dated options

## Trade usage
Useful expressions:
- long ATM straddle when:
  - `breakeven_gap` is positive
  - `vol_carry_score` is not strongly short-vol
  - `VVIX` is rising or at least not collapsing
- short ATM straddle or wider short strangle when:
  - `breakeven_gap` is persistently negative
  - carry is rich
  - `VVIX` and skew stress are contained
- prefer calendars when:
  - the breakeven gap is tightening but not clearly positive yet
  - short-end repricing is leading long-end repricing

This dashboard pairs especially well with:
- [Options Carry / VRP](docs/options-carry-vrp.md)
- [Options Signals](docs/options-signals.md)
- [Options Vol Cone](docs/options-vol-cone.md)

## Failure modes and false positives
- A single outsized move can temporarily make gamma look cheap even if the move was one-off and already exhausted.
- Short-end IV can lag an event repricing by one snapshot if coverage is thin.
- Breakeven is a first-order approximation, not a full realized P&L model.
- Use the Razor dashboard to confirm whether a long-gamma strategy is actually accruing edge, not just looking attractive on a single-hour comparison.

## Companion dashboards
- Check [Options Carry / VRP](docs/options-carry-vrp.md) next to see whether the carry regime agrees.
- Check [Options Skew](docs/options-skew.md) next to see whether the move is being repriced through crash premium instead of broad gamma.
- Check [Options Vol Regime Transitions](docs/options-vol-regime-transitions.md) next to see whether the current long-vol regime tends to persist.
