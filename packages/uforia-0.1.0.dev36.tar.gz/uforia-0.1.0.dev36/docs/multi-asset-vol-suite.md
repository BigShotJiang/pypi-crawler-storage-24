# Multi-Asset Vol Suite

## Scope
The current signal stack is a multi-asset volatility suite covering BTC and ETH.

Implemented signal families:
- `btc_vvix`
- `eth_vvix`
- `btc_razor`
- `eth_razor`

Implemented alpha-canvas options families:
- surface factor momentum and residual value
- ML carry with toxicity veto
- expiry pinning and gamma flip map
- adaptive hedging overlay
- sessionality and funding clocks
- BTC-ETH dispersion
- funding-basis x skew interactions

## VVIX
Implemented VVIX path:
- Deribit DVOL ingestion for BTC and ETH
- BTC/ETH vol-index series using `dvol` and `bvix` sources
- BTC/ETH `rVVIX` at `7d`, `14d`, and `30d`
- BTC/ETH `qVVIX` with explicit quality flags when surface history is insufficient

Main commands:
- `uv run uforia-admin ingest deribit-dvol --underlying BTC|ETH --start ... --end ...`
- `uv run uforia-admin build vol-index --underlying BTC|ETH --source dvol|bvix --start ... --end ...`
- `uv run uforia-admin build rvvix --underlying BTC|ETH --source dvol|bvix --start ... --end ...`
- `uv run uforia-admin build surface-features --underlying BTC|ETH --start ... --end ...`
- `uv run uforia-admin build qvvix --underlying BTC|ETH --source dvol|bvix --ts ...`

## Razor
Implemented Razor path:
- `razor_pnl` from a rolling hourly delta-hedged 7D ATM straddle reference program
- `razor_vrp` from cumulative implied-vs-realized variance premium
- rolling z-score normalization
- regime labels:
  - `double_buy`
  - `double_sell`
  - `neutral`

Main command:
- `uv run uforia-admin build razor --underlying BTC|ETH --start ... --end ...`

Current v1 constraint:
- `razor_pnl` is only as good as the archived hourly option snapshots available locally
- it is designed for live-forward research first, not full historical reconstruction from the public Deribit API

Alpha canvas scope boundary:
- research-only analytics and dashboard overlays
- no live hedge engine
- no maker quoting engine
- no RL hedging scheduler

## Datasets
Derived dataset contracts now include `underlying` on the main analytics paths:
- `vol_index_series`
- `surface_features`
- `vvix_series`
- `razor_series`

This lets BTC and ETH coexist in one storage root without overwriting or cross-reading one another.
