# Composite Regimes

## Sentiment

- `0-20`: `panic`
- `20-40`: `fear`
- `40-60`: `neutral`
- `60-80`: `greed`
- `80-100`: `euphoria`

Interpretation:
- fear is not automatically bearish
- greed is not automatically bullish
- extreme sentiment should be read with fragility and direction, not alone

## Directional Tilt

- `[-100,-40]`: `bearish`
- `(-40,-15]`: `mild_bearish`
- `(-15,15)`: `neutral`
- `[15,40)`: `mild_bullish`
- `[40,100]`: `bullish`

Interpretation:
- directional tilt is primarily microstructure-led
- when confidence is low, treat strong tilt as a watch state, not a hard signal

## Fragility

- `0-25`: `stable`
- `25-50`: `watch`
- `50-75`: `fragile`
- `75-100`: `squeeze_risk`

Interpretation:
- high fragility means tail risk and overshoot risk are elevated
- high fragility can invalidate smooth mean-reversion assumptions even when sentiment looks calm

## Common misreads

- `panic + bullish direction` can happen after forced selling
- `greed + bearish direction` can happen when longs are too crowded
- `neutral sentiment + high fragility` is often a warning that the next move matters more than the current mood

## How to use

1. Start with `sentiment_index` for crowding and fear/greed context.
2. Check `directional_tilt` for the current lean.
3. Check `fragility_index` before sizing or assuming a clean follow-through.
4. Use decomposition to see which family is driving the reading.
