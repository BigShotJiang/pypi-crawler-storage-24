# Options Sessionality Clocks

## Inputs
- spot history from `option_chain_snapshot`
- `surface_features`
- `options_carry_series`

## Session Labels
- `asia`: 00:00-07:59 UTC
- `europe`: 08:00-15:59 UTC
- `us`: 16:00-23:59 UTC

## Event Flags
- `is_weekend`: Saturday/Sunday UTC
- `is_funding_window`: 00:00, 08:00, 16:00 UTC
- `is_expiry_window`: Friday 06:00-10:00 UTC

## Core Fields
- `session_realized_vol`
- `session_implied_vol`
- `session_carry`
- `sessionality_score`
- `carry_switch`

## Interpretation
- high score means the current clock supports the active vol regime
- funding and expiry windows should be treated as timing filters, not standalone trades

## Quality Flags
- `ok`: implied vol present
- `insufficient_data`: missing surface snapshot for the hour
