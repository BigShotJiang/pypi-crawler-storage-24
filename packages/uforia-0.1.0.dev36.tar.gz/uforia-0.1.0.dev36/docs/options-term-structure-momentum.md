# Options Term Structure Momentum

## What it measures
This dashboard tracks whether front-end term structure pressure is accelerating or fading.

Exact inputs:
- `surface_features`
- `term_structure_momentum_series`

Derived fields:
- `term_slope_7_30`
- `term_slope_30_60`
- `term_slope_change_24h`
- `term_slope_change_72h`
- `momentum_regime`

## How to interpret it
- Positive slope change means front-end vol is rising faster than the back end.
- Negative slope change means near-term stress is decaying or getting pushed further out.

## Trade use
- Use steepening to time long front-vs-back gamma or defensive calendars.
- Use flattening after a spike to look for normalization rather than immediate outright short vol.

## Failure modes
- Event-driven term moves can reverse abruptly once the catalyst passes.
- A single strong day is weaker evidence than multi-day acceleration.

## Pair with
- [Options Vol Surface](options-surface.md)
- [Options Vol Regime Transitions](options-vol-regime-transitions.md)
