#!/bin/zsh
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LAUNCHD_ROOT="$REPO_ROOT/launchd"
TARGET_DIR="${HOME}/Library/LaunchAgents"

mkdir -p "$TARGET_DIR"
mkdir -p "${HOME}/Library/Logs/uforia"

cp "$LAUNCHD_ROOT"/com.uforia.*.plist "$TARGET_DIR"/

echo "Installed launchd plists into $TARGET_DIR"
echo "Bootstrap with:"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.api.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.web.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.archiver.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.refresh.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.refresh-hot.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.microstructure-live.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.microstructure-inference.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.microstructure-train.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.execution-engine.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.execution-state-sync.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.db-sync-hot.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.db-sync-raw-recent.plist"
echo "  launchctl bootstrap gui/\$(id -u) $TARGET_DIR/com.uforia.db-backfill-maintenance.plist"
