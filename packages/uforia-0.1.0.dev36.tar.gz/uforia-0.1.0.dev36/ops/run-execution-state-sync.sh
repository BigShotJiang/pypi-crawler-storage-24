#!/bin/zsh
set -euo pipefail

cd /Users/mubaris/dev/uforia

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
export UFORIA_EXECUTION_ENABLED=true
export UFORIA_DB_ENABLED="${UFORIA_DB_ENABLED:-true}"
export UFORIA_DB_READ_MODE="${UFORIA_DB_READ_MODE:-auto}"
export UFORIA_DB_WRITE_MODE="${UFORIA_DB_WRITE_MODE:-dual}"

while true; do
  /opt/homebrew/bin/uv run uforia-admin execution sync-state --health-path /Users/mubaris/dev/uforia/data/execution_live/health/latest.json || true
  /opt/homebrew/bin/uv run uforia-admin execution sync-live-state || true
  sleep 10
done
