#!/bin/zsh
set -euo pipefail

cd /Users/mubaris/dev/uforia

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
export UFORIA_EXECUTION_ENABLED=true
export UFORIA_EXECUTION_DEFAULT_MODE="${UFORIA_EXECUTION_DEFAULT_MODE:-dry_run}"
export UFORIA_EXECUTION_ACCOUNTS_PATH="${UFORIA_EXECUTION_ACCOUNTS_PATH:-/Users/mubaris/dev/uforia/config/execution_accounts.json}"

exec cargo run -p uforia-execution-app -- run --health-path /Users/mubaris/dev/uforia/data/execution_live/health/latest.json
