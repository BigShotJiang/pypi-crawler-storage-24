#!/bin/zsh
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
export UFORIA_DATA_ROOT="${UFORIA_DATA_ROOT:-$REPO_ROOT/data}"
export UFORIA_MICROSTRUCTURE_IMPORT_ROOT="${UFORIA_MICROSTRUCTURE_IMPORT_ROOT:-/Users/mubaris/dev/crypto-microstructure}"
export UFORIA_MICROSTRUCTURE_START="${UFORIA_MICROSTRUCTURE_START:-2026-01-01T00:00:00Z}"
export UFORIA_MICROSTRUCTURE_END="${UFORIA_MICROSTRUCTURE_END:-$(date -u +%Y-%m-%dT%H:00:00Z)}"
export UFORIA_DB_ENABLED="${UFORIA_DB_ENABLED:-true}"
export UFORIA_DB_DSN="${UFORIA_DB_DSN:-postgresql:///uforia?user=$USER}"
export UFORIA_DB_READ_MODE="${UFORIA_DB_READ_MODE:-auto}"
export UFORIA_DB_WRITE_MODE="${UFORIA_DB_WRITE_MODE:-dual}"

uv run uforia-admin microstructure import-history --root "$UFORIA_MICROSTRUCTURE_IMPORT_ROOT"

for ASSET in BTC ETH; do
  uv run uforia-admin microstructure build-features --asset "$ASSET" --start "$UFORIA_MICROSTRUCTURE_START" --end "$UFORIA_MICROSTRUCTURE_END"
  uv run uforia-admin microstructure build-labels --asset "$ASSET" --start "$UFORIA_MICROSTRUCTURE_START" --end "$UFORIA_MICROSTRUCTURE_END" --horizons 30s,1m,2m,5m
  uv run uforia-admin microstructure build-regime --asset "$ASSET" --start "$UFORIA_MICROSTRUCTURE_START" --end "$UFORIA_MICROSTRUCTURE_END"
done
