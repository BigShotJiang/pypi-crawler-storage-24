#!/bin/zsh
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
DATA_ROOT="${UFORIA_DATA_ROOT:-$REPO_ROOT/data}"

for DATASET in vol_index_series surface_features vvix_series; do
  DATASET_ROOT="$DATA_ROOT/$DATASET"
  if [ -d "$DATASET_ROOT" ]; then
    find "$DATASET_ROOT" -mindepth 1 -maxdepth 1 -type d -name 'source=*' -print -exec rm -rf {} +
  fi
done

for DATASET in dvol_snapshot vol_index_series vvix_series surface_features razor_series; do
  if [ -d "$DATA_ROOT/$DATASET" ]; then
    uv run uforia-admin maintenance compact --dataset "$DATASET" --start-date 2000-01-01 --end-date 2100-01-01 || true
  fi
done
