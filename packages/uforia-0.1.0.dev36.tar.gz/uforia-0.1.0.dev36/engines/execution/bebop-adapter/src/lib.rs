use serde_json::json;
use uforia_execution_core::{
    dry_run_payload, ExecutionVenue, InstrumentType, OrderType, QuoteRequest, VenueCapabilities,
};

pub fn capabilities() -> VenueCapabilities {
    VenueCapabilities {
        venue: ExecutionVenue::Bebop,
        instrument_types: vec![InstrumentType::Spot],
        order_types: vec![OrderType::Market],
        supports_post_only: false,
        supports_reduce_only: false,
        supports_amend: false,
        supports_mass_cancel: false,
        supports_private_ws: false,
        supports_quote_routing: true,
    }
}

pub fn build_quote_payload(request: &QuoteRequest) -> serde_json::Value {
    dry_run_payload(
        "bebop_quote",
        &[
            ("asset", json!(request.asset)),
            ("symbol", json!(request.symbol)),
            ("side", json!(request.side)),
            ("size", json!(request.size)),
            ("notional_usd", json!(request.notional_usd)),
        ],
    )
}

pub fn build_execute_payload(quote_id: &str) -> serde_json::Value {
    dry_run_payload("bebop_execute", &[("quote_id", json!(quote_id))])
}

#[cfg(test)]
mod tests {
    use super::*;
    use uforia_execution_core::{ExecutionVenue, OrderSide, QuoteRequest};

    #[test]
    fn builds_bebop_quote_payload() {
        let request = QuoteRequest::new(
            "acct",
            ExecutionVenue::Bebop,
            "BTC",
            "BTC-USD",
            OrderSide::Buy,
            2.0,
        );
        let payload = build_quote_payload(&request);
        assert_eq!(payload["symbol"], "BTC-USD");
        assert_eq!(payload["size"], 2.0);
    }
}
