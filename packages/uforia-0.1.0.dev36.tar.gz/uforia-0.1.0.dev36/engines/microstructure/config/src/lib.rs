use std::path::Path;

mod config;

pub use config::*;

pub fn load_config(path: &Path) -> Result<AppConfig, uforia_ms_types::CmError> {
    let contents = std::fs::read_to_string(path)
        .map_err(|e| uforia_ms_types::CmError::Config(e.to_string()))?;
    let mut config: AppConfig =
        toml::from_str(&contents).map_err(|e| uforia_ms_types::CmError::Config(e.to_string()))?;
    config.apply_env_overrides();
    config.validate()?;
    Ok(config)
}
