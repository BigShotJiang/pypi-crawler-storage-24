use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::{fs, path::Path};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogisticModelArtifact {
    pub asset: String,
    pub horizon: String,
    pub model_type: String,
    pub feature_columns: Vec<String>,
    pub means: Vec<f64>,
    pub stds: Vec<f64>,
    pub coef: Vec<Vec<f64>>,
    pub intercepts: Vec<f64>,
    pub classes: Vec<i64>,
    pub profitable: bool,
    pub cv_accuracy_mean: f64,
    pub cv_accuracy_std: f64,
    pub brier_score: f64,
}

pub fn load_artifact(path: &Path) -> Result<LogisticModelArtifact> {
    let text = fs::read_to_string(path)?;
    Ok(serde_json::from_str(&text)?)
}
