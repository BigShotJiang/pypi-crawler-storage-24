use thiserror::Error;

#[derive(Error, Debug)]
pub enum CmError {
    #[error("Feed error: {venue} - {msg}")]
    Feed { venue: String, msg: String },

    #[error("WebSocket error: {0}")]
    WebSocket(String),

    #[error("Reconnect exhausted after {attempts} attempts for {venue}")]
    ReconnectExhausted { venue: String, attempts: u32 },

    #[error("Parse error: {context} - {msg}")]
    Parse { context: String, msg: String },

    #[error("Config error: {0}")]
    Config(String),

    #[error("Storage error: {0}")]
    Storage(String),

    #[error("Parquet error: {0}")]
    Parquet(String),

    #[error("ClickHouse error: {0}")]
    ClickHouse(String),

    #[error("Model error: {0}")]
    Model(String),

    #[error("Feature error: {0}")]
    Feature(String),

    #[error("Risk limit breached: {0}")]
    RiskLimit(String),

    #[error("Kill switch activated: {reason}")]
    KillSwitch { reason: String },

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
}

pub type CmResult<T> = Result<T, CmError>;
