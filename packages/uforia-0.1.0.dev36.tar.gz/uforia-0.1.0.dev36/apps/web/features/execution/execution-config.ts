export type ExecutionSectionConfig = {
  id: string;
  title: string;
  description: string;
  playbook: {
    whatItMeasures: string[];
    interpretation: string[];
    workflow: string[];
    caveats: string[];
  };
};

export const EXECUTION_SECTIONS: ExecutionSectionConfig[] = [
  {
    id: "overview",
    title: "Overview",
    description: "Venue capability, account readiness, and latest execution-state summary.",
    playbook: {
      whatItMeasures: ["Shows which venues/accounts are available and whether private connectivity and state sync are healthy."],
      interpretation: ["Use this page before submitting orders. If health is degraded or accounts are disabled, stop here."],
      workflow: ["Confirm venue/account status, then jump to Markets or Order Entry."],
      caveats: ["Health is only as fresh as the execution engine/state sync updates."],
    },
  },
  {
    id: "markets",
    title: "Markets",
    description: "Latest venue market metadata, top-of-book context, and instrument support.",
    playbook: {
      whatItMeasures: ["Shows the instrument catalog and the latest market snapshot for each venue."],
      interpretation: ["Use this page to verify symbol naming, instrument type, and whether live top-of-book context is seeded."],
      workflow: ["Filter to the venue and asset you want, confirm the instrument, then use Order Entry."],
      caveats: ["Missing tick/min-size fields mean the venue adapter has not synced that market yet."],
    },
  },
  {
    id: "order-entry",
    title: "Order Entry",
    description: "Thin venue-aware operator ticket for quote, dry-run, paper, and future live placement.",
    playbook: {
      whatItMeasures: ["Shows the exact request the backend will validate and record."],
      interpretation: ["Dry-run validates risk and venue capability. Paper records the lifecycle without touching the venue."],
      workflow: ["Pick venue/account, validate with Dry Run, then use Paper or future Live mode once credentials are enabled."],
      caveats: ["Live placement is intentionally blocked in this build unless a venue-specific path is later enabled."],
    },
  },
  {
    id: "orders",
    title: "Orders",
    description: "Normalized order lifecycle across all execution venues.",
    playbook: {
      whatItMeasures: ["Shows submit, cancel, and cancel-all events in one normalized order stream."],
      interpretation: ["Use status and event type to verify whether an intent was accepted, rejected, or canceled."],
      workflow: ["Inspect the latest request_ids after every operator action."],
      caveats: ["This is an audit/event stream, not a broker blotter with implicit lifecycle reconstruction."],
    },
  },
  {
    id: "fills",
    title: "Fills",
    description: "Normalized fill history with fee and liquidity context.",
    playbook: {
      whatItMeasures: ["Shows immutable fill events written by the execution control plane."],
      interpretation: ["Use this page to confirm realized execution and fee load per venue."],
      workflow: ["After a live venue path is enabled, compare fills against order events and balances."],
      caveats: ["Paper fills are not generated in this build; this page may stay empty until live venues are enabled."],
    },
  },
  {
    id: "positions",
    title: "Positions",
    description: "Latest position snapshots by venue/account/symbol.",
    playbook: {
      whatItMeasures: ["Shows latest known exposure per venue and account."],
      interpretation: ["Use this to confirm reduce-only behavior, gross exposure, and symbol drift."],
      workflow: ["Refresh after any live order placement or external venue activity."],
      caveats: ["If state sync is not configured for a venue, rows will be missing rather than guessed."],
    },
  },
  {
    id: "balances",
    title: "Balances",
    description: "Latest balance snapshots by venue/account/asset.",
    playbook: {
      whatItMeasures: ["Shows total, available, and locked balances by venue."],
      interpretation: ["Use available balance to determine whether a live order can be supported before submission."],
      workflow: ["Confirm balance sufficiency before leaving dry-run mode."],
      caveats: ["Balance snapshots depend on private account sync and will be stale if the execution engine is disconnected."],
    },
  },
  {
    id: "venue-health",
    title: "Venue Health",
    description: "Private/public connectivity, latency, and reconnect state per venue/account.",
    playbook: {
      whatItMeasures: ["Shows connectivity, heartbeat age, latency, and last error for execution adapters."],
      interpretation: ["Treat non-online state as a trading block. Reconnect churn means venue state is not reliable."],
      workflow: ["Do not place live orders unless the relevant venue/account is online and heartbeat is fresh."],
      caveats: ["Health is adapter-reported. It does not prove that private account state has fully reconciled."],
    },
  },
];
