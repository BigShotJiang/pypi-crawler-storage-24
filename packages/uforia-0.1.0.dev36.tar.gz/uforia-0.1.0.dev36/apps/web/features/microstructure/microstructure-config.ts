export type MicrostructureSectionConfig = {
  id: string;
  title: string;
  description: string;
  lines: { key: string; label: string; color: string; yAxisId?: "left" | "right" }[];
  tableColumns: string[];
  playbook: {
    whatItMeasures: string;
    interpretation: string[];
    tradeExpressions: string[];
    caveats: string[];
    companionChecks: string[];
  };
};

export const MICROSTRUCTURE_SECTIONS: MicrostructureSectionConfig[] = [
  {
    id: "overview",
    title: "Overview",
    description: "Engine health, latest predictions, regime state, and training freshness.",
    lines: [
      { key: "confidence", label: "Confidence", color: "#6ac2ff" },
      { key: "tradability_score", label: "Tradability", color: "#ffd166" },
      { key: "expected_move_bps", label: "Expected Move", color: "#f58549", yAxisId: "right" },
    ],
    tableColumns: ["ts", "asset", "horizon", "signal_state", "confidence", "tradability_score", "expected_move_bps", "quality_flag"],
    playbook: {
      whatItMeasures: "The overview is the control screen for the medium-horizon engine: whether it is healthy, whether recent predictions are usable, and whether regime context supports acting on them.",
      interpretation: [
        "High confidence with low tradability often means the model sees a directional lean but not enough expected edge after costs.",
        "Rising expected move with a stable regime is a better setup than rising expected move during a deteriorating data-quality window.",
        "Training and backtest timestamps matter operationally: old models can still be live, but you should know when they were last refreshed.",
      ],
      tradeExpressions: [
        "Use this page as a gate before looking at detailed predictions. If health or quality is degraded, the right trade is often no trade.",
        "When the engine is healthy and recent 1m/5m signals align, use that as the first pass screening layer for paper deployment.",
      ],
      caveats: [
        "This page summarizes; it does not replace the deeper features and regime pages.",
        "A healthy engine does not imply profitable predictions. It only means the data path and model outputs are operational.",
      ],
      companionChecks: ["Predictions", "Regime", "Engine Health"],
    },
  },
  {
    id: "predictions",
    title: "Predictions",
    description: "Per-horizon probabilities, expected move, and paper signal state.",
    lines: [
      { key: "prob_spread", label: "P(Spread)", color: "#6ac2ff" },
      { key: "expected_move_bps", label: "Expected Move", color: "#ffd166", yAxisId: "right" },
    ],
    tableColumns: ["ts", "signal_state", "paper_position", "prob_up", "prob_down", "tradability_score", "expected_move_bps", "quality_flag"],
    playbook: {
      whatItMeasures: "This is the actionable layer: class probabilities, expected move, and the translated paper signal for each horizon.",
      interpretation: [
        "Probability spread matters more than the raw top class. A weak 0.38 vs 0.34 split is not the same as a decisive 0.62 vs 0.18 split.",
        "Tradability should be read with expected move. A high-confidence signal on a tiny expected move is often not worth costs.",
        "Alignment between 1m and 5m is stronger than a single isolated horizon print.",
      ],
      tradeExpressions: [
        "Favor paper longs when P(Up) leads materially, expected move is positive, and tradability is high.",
        "Favor paper shorts when P(Down) leads materially under the same conditions.",
        "Use flat or blocked states as an explicit instruction not to chase weak edges.",
      ],
      caveats: [
        "Do not treat raw probabilities as execution instructions without cost and regime context.",
        "The 30s horizon will remain sparse until sub-minute live data accumulates.",
      ],
      companionChecks: ["Features", "Regime", "Calibration"],
    },
  },
  {
    id: "regime",
    title: "Regime",
    description: "Rule-based vol/flow/basis state with persistence and hysteresis.",
    lines: [
      { key: "vol_percentile", label: "Vol %ile", color: "#6ac2ff" },
      { key: "flow_percentile", label: "Flow %ile", color: "#ffd166" },
      { key: "basis_percentile", label: "Basis %ile", color: "#f58549" },
      { key: "persistence_hours", label: "Persistence", color: "#8dd3c7", yAxisId: "right" },
    ],
    tableColumns: ["ts", "regime_state", "vol_percentile", "flow_percentile", "basis_percentile", "persistence_hours", "quality_flag"],
    playbook: {
      whatItMeasures: "Regime is the state filter around the prediction model: whether the market is calm, flow-stressed, or high-vol enough to change the expected reliability of short-horizon forecasts.",
      interpretation: [
        "Calm regimes tend to favor mean-reversion and lower realized follow-through.",
        "High-vol and flow-stress regimes often increase opportunity but also increase false positives and slippage risk.",
        "Persistence matters: a fresh regime flip is different from a regime that has already persisted for hours.",
      ],
      tradeExpressions: [
        "Use regime as a filter, not a signal by itself.",
        "Scale down paper aggressiveness when regime deteriorates faster than prediction confidence improves.",
      ],
      caveats: [
        "This is rule-based and intentionally simple. It is a guardrail, not a learned latent-state model.",
      ],
      companionChecks: ["Predictions", "Features", "Backtests"],
    },
  },
  {
    id: "features",
    title: "Features",
    description: "Core feature state from order flow, microprice, vol, funding, and options context.",
    lines: [
      { key: "book_imbalance", label: "Book Imbalance", color: "#6ac2ff" },
      { key: "order_flow_imbalance", label: "OFI", color: "#ffd166" },
      { key: "realized_vol", label: "Realized Vol", color: "#f58549" },
      { key: "funding_rate", label: "Funding", color: "#8dd3c7", yAxisId: "right" },
    ],
    tableColumns: ["ts", "book_imbalance", "order_flow_imbalance", "realized_vol", "microprice_tilt", "funding_rate", "quality_flag"],
    playbook: {
      whatItMeasures: "This page exposes the model inputs that matter most: who is leaning on the book, how microprice is skewed, whether realized vol is rising, and whether cross-market context is supportive.",
      interpretation: [
        "Book imbalance and microprice tilt show near-touch pressure.",
        "Order-flow imbalance and cumulative delta show whether aggressive flow is reinforcing or fading that pressure.",
        "Funding and options context help separate one-venue noise from broader positioning pressure.",
      ],
      tradeExpressions: [
        "Look for alignment across book, flow, and regime before trusting a directional model spike.",
        "Use features to explain why a signal exists; if the model fires without feature confirmation, size smaller or ignore it.",
      ],
      caveats: [
        "Feature sparsity or bad joins can create deceptively clean but uninformative rows.",
      ],
      companionChecks: ["Predictions", "Overview"],
    },
  },
  {
    id: "calibration",
    title: "Calibration",
    description: "Model freshness, CV accuracy, Brier score, and calibration context.",
    lines: [
      { key: "cv_accuracy_mean", label: "CV Accuracy", color: "#6ac2ff" },
      { key: "brier_score", label: "Brier", color: "#f58549" },
      { key: "calibration_error", label: "Calibration Error", color: "#ffd166" },
    ],
    tableColumns: ["ts", "asset", "horizon", "cv_accuracy_mean", "brier_score", "calibration_error", "profitable", "artifact_uri"],
    playbook: {
      whatItMeasures: "Training-run quality and freshness for the active TCN-Boost model family.",
      interpretation: [
        "Lower Brier is better; calibration error tells you whether confidence is being overstated.",
        "A profitable flag is only a screening hint, not proof of a tradable model.",
      ],
      tradeExpressions: [
        "Use this page to decide whether a trained tabular, TCN, or fusion model should remain active.",
      ],
      caveats: [
        "Short backtest windows can flatter unstable models.",
      ],
      companionChecks: ["Backtests", "Predictions"],
    },
  },
  {
    id: "backtests",
    title: "Backtests",
    description: "Walk-forward accuracy, Brier score, and paper edge by model/horizon.",
    lines: [
      { key: "mean_accuracy", label: "Accuracy", color: "#6ac2ff" },
      { key: "mean_brier_score", label: "Brier", color: "#f58549" },
      { key: "paper_net_edge_bps", label: "Net Edge", color: "#ffd166", yAxisId: "right" },
    ],
    tableColumns: ["ts", "asset", "horizon", "mean_accuracy", "mean_brier_score", "paper_net_edge_bps", "paper_sharpe", "quality_flag"],
    playbook: {
      whatItMeasures: "Backtests show whether the TCN-Boost stack survives purged, cost-aware evaluation rather than just fitting the training window.",
      interpretation: [
        "Accuracy alone is weak. Net edge and Brier are more useful together.",
        "Sharpe-like metrics on paper signals are only meaningful if turnover and blocking logic are realistic.",
      ],
      tradeExpressions: [
        "Promote models with stable backtests, not only the highest single-window score.",
      ],
      caveats: [
        "Backtests are only as honest as the label, cost, and purge assumptions.",
      ],
      companionChecks: ["Calibration", "Engine Health"],
    },
  },
  {
    id: "engine-health",
    title: "Engine Health",
    description: "Feature, prediction, training, and backtest freshness for the microstructure stack.",
    lines: [
      { key: "signals_available", label: "Signals", color: "#6ac2ff" },
    ],
    tableColumns: ["status", "engine_status", "last_feature_ts", "last_prediction_ts", "last_training_ts", "last_backtest_ts", "signals_available"],
    playbook: {
      whatItMeasures: "Operational health of the microstructure family inside `uforia`.",
      interpretation: [
        "This page tells you whether the engine is cold, stale, or producing current outputs.",
      ],
      tradeExpressions: [
        "If engine health is degraded, treat all related predictions as observational only.",
      ],
      caveats: [
        "Operational health does not imply alpha quality.",
      ],
      companionChecks: ["Overview"],
    },
  },
];
