export type CompositeDashboardLine = {
  key: string;
  label: string;
  color: string;
  yAxisId?: "left" | "right";
};

export type CompositePlaybook = {
  whatItMeasures: string;
  interpretation: string[];
  tradeExpressions: string[];
  caveats: string[];
  companionChecks: string[];
};

export type CompositeDashboardConfig = {
  id: string;
  signalId: string;
  title: string;
  description: string;
  scopeLabel: string;
  lines: CompositeDashboardLine[];
  tableColumns: string[];
  playbook: CompositePlaybook;
};

const DEFAULT_LINES: CompositeDashboardLine[] = [
  { key: "sentiment_index", label: "Sentiment", color: "#6ac2ff", yAxisId: "left" },
  { key: "fragility_index", label: "Fragility", color: "#f58549", yAxisId: "left" },
  { key: "directional_tilt", label: "Directional Tilt", color: "#8dd3c7", yAxisId: "right" },
];

export const COMPOSITE_DASHBOARDS: CompositeDashboardConfig[] = [
  {
    id: "composite_overview",
    signalId: "market_composite",
    title: "Composite Overview",
    description: "Market-wide composite state blending BTC and ETH into one interpretable market pulse.",
    scopeLabel: "Market",
    lines: DEFAULT_LINES,
    tableColumns: [
      "ts",
      "sentiment_index",
      "directional_tilt",
      "fragility_index",
      "confidence_score",
      "quality_flag",
    ],
    playbook: {
      whatItMeasures:
        "This is the top-level market state view. Sentiment tracks crowding and fear/greed, directional tilt tracks where the market is leaning, and fragility tracks squeeze or cascade risk.",
      interpretation: [
        "High sentiment with low fragility usually means complacent or crowded positioning rather than immediate danger.",
        "High fragility with neutral direction means the next move may be large but not yet clearly signed.",
        "Directional tilt should be read together with confidence. A strong tilt on weak confidence is a watch signal, not an execution signal.",
      ],
      tradeExpressions: [
        "Use the overview to choose whether the environment favors risk-on, defensive positioning, or patience.",
        "Treat high sentiment plus high fragility as unstable euphoria rather than clean bullishness.",
      ],
      caveats: [
        "Fear is not automatically bearish and greed is not automatically bullish.",
        "The market aggregate can mask BTC/ETH divergence. Check asset pages when the aggregate looks indecisive.",
      ],
      companionChecks: [
        "Check BTC and ETH composite pages for asset-level divergence.",
        "Check decomposition to see which family is driving the regime.",
      ],
    },
  },
  {
    id: "composite_btc",
    signalId: "btc_composite",
    title: "BTC Composite",
    description: "BTC-specific market state from options, perps, VVIX, Razor, and microstructure.",
    scopeLabel: "BTC",
    lines: DEFAULT_LINES,
    tableColumns: [
      "ts",
      "sentiment_index",
      "directional_tilt",
      "fragility_index",
      "confidence_score",
      "quality_flag",
    ],
    playbook: {
      whatItMeasures:
        "This isolates BTC market state so the signal is not diluted by ETH or cross-asset aggregation.",
      interpretation: [
        "Sentiment tells you whether BTC is crowded, fearful, or complacent.",
        "Directional tilt is microstructure-led and should dominate short-horizon direction reads.",
        "Fragility tells you whether BTC can overshoot clean mean-reversion assumptions.",
      ],
      tradeExpressions: [
        "Use BTC composite when BTC-specific structure is more informative than the market aggregate.",
        "Lean more on directional tilt when confidence is high and fragility is not extreme.",
      ],
      caveats: [
        "Short-term directional tilt can flip faster than sentiment or fragility.",
        "A neutral headline can still hide strong opposing sub-pillars.",
      ],
      companionChecks: [
        "Check decomposition for pillar dominance.",
        "Check Perps and Options family pages when fragility and sentiment disagree.",
      ],
    },
  },
  {
    id: "composite_eth",
    signalId: "eth_composite",
    title: "ETH Composite",
    description: "ETH-specific market state from options, perps, VVIX, Razor, and microstructure.",
    scopeLabel: "ETH",
    lines: DEFAULT_LINES,
    tableColumns: [
      "ts",
      "sentiment_index",
      "directional_tilt",
      "fragility_index",
      "confidence_score",
      "quality_flag",
    ],
    playbook: {
      whatItMeasures:
        "This isolates ETH state and keeps cross-asset BTC effects from overwhelming ETH-specific structure.",
      interpretation: [
        "ETH sentiment often moves faster than BTC during cross-asset dispersion episodes.",
        "ETH fragility can remain elevated even when the market-wide aggregate looks calm.",
        "Directional tilt is still microstructure-led, but confidence should be discounted when ETH live coverage is thin.",
      ],
      tradeExpressions: [
        "Use ETH composite when ETH options or perp crowding diverges from BTC.",
        "Treat high ETH fragility with neutral market composite as a dispersion warning.",
      ],
      caveats: [
        "ETH can inherit risk-on/risk-off flows from BTC without matching its structure exactly.",
        "Coverage quality matters more on ETH if fewer upstream signals are active.",
      ],
      companionChecks: [
        "Check BTC composite for market-vs-asset divergence.",
        "Check BTC-ETH dispersion and perps RV when ETH behaves idiosyncratically.",
      ],
    },
  },
  {
    id: "composite_market",
    signalId: "market_composite",
    title: "Market Composite",
    description: "BTC/ETH weighted market-wide state using fixed 0.65 / 0.35 weighting.",
    scopeLabel: "Market",
    lines: DEFAULT_LINES,
    tableColumns: [
      "ts",
      "sentiment_index",
      "directional_tilt",
      "fragility_index",
      "confidence_score",
      "quality_flag",
    ],
    playbook: {
      whatItMeasures:
        "This is the weighted BTC/ETH market aggregate intended for top-down state classification.",
      interpretation: [
        "Use this for broad market regime first, then drill into BTC/ETH for divergence.",
        "Because BTC has the heavier weight, market readings can stay stable while ETH swings harder.",
      ],
      tradeExpressions: [
        "Use market composite to decide whether to trade more aggressively across the board or stay selective.",
        "When market sentiment is extreme and fragility is rising, cut size even if directional tilt still agrees.",
      ],
      caveats: [
        "This is not a cross-sectional selector. It is an aggregate regime tool.",
        "A smooth aggregate can hide sharp single-asset stress.",
      ],
      companionChecks: [
        "Check BTC and ETH pages before acting on a strong aggregate reading.",
        "Check decomposition to see whether options/perps or microstructure are dominant.",
      ],
    },
  },
  {
    id: "composite_decomposition",
    signalId: "market_composite",
    title: "Composite Decomposition",
    description: "Contribution and regime-breakdown view for the market composite and its asset-level peers.",
    scopeLabel: "Decomposition",
    lines: DEFAULT_LINES,
    tableColumns: [
      "ts",
      "component",
      "pillar",
      "family",
      "normalized_value",
      "signed_contribution",
      "quality_flag",
    ],
    playbook: {
      whatItMeasures:
        "This shows what is driving the headline composite instead of only showing the headline score.",
      interpretation: [
        "Top contributors tell you whether a reading is options-led, perps-led, or microstructure-led.",
        "If positive and negative contributors offset heavily, a neutral headline may hide unstable structure.",
        "Transitions tell you whether the current regime usually persists or tends to flip quickly.",
      ],
      tradeExpressions: [
        "Use decomposition before trusting any extreme headline. You want to know which family is actually moving the index.",
        "Use transition persistence to decide whether a regime is worth leaning into or merely monitoring.",
      ],
      caveats: [
        "Contributions are normalized and weighted, not raw PnL or expectancy.",
        "Sparse components reduce confidence even when the headline value looks stable.",
      ],
      companionChecks: [
        "Check the corresponding asset page after identifying a dominant component.",
        "Check the original family dashboard to validate whether the contributor is clean or noisy.",
      ],
    },
  },
];

export const COMPOSITE_SIGNAL_LABELS: Record<string, string> = {
  sentiment_index: "Sentiment",
  directional_tilt: "Directional Tilt",
  fragility_index: "Fragility",
  confidence_score: "Confidence",
};
