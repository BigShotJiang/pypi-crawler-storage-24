import clsx from "clsx";

type StatusTone = "ok" | "warn" | "error" | "neutral" | "live";

const TONE_CLASS: Record<StatusTone, string> = {
  ok: "statusBadge statusOk",
  warn: "statusBadge statusWarn",
  error: "statusBadge statusError",
  neutral: "statusBadge statusNeutral",
  live: "statusBadge statusLive",
};

export function StatusBadge({
  label,
  tone = "neutral",
  pulse,
}: {
  label: string;
  tone?: StatusTone;
  pulse?: boolean;
}) {
  return <span className={clsx(TONE_CLASS[tone], pulse && "statusPulse")}>{label}</span>;
}
