import clsx from "clsx";

export function LiveDot({
  connected,
  ready,
}: {
  connected: boolean;
  ready: boolean;
}) {
  return (
    <span
      className={clsx(
        "liveDot",
        connected ? "liveDotConnected" : ready ? "liveDotDisconnected" : "liveDotConnecting",
      )}
    />
  );
}
