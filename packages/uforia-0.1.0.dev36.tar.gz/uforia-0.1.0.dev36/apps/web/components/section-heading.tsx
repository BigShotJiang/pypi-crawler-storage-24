export function SectionHeading({
  kicker,
  title,
  description,
}: {
  kicker: string;
  title: string;
  description: string;
}) {
  return (
    <div className="sectionHeading" title={description}>
      <p className="eyebrow">{kicker}</p>
      <h2>{title}</h2>
    </div>
  );
}
