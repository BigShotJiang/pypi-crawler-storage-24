export const dynamic = "force-dynamic";

import { PerpsList } from "@/features/perps/perps-list";
import { getPerpsDashboards } from "@/lib/api/client";

export default async function PerpsPage() {
  const dashboards = await getPerpsDashboards();
  return <PerpsList dashboards={dashboards} />;
}
