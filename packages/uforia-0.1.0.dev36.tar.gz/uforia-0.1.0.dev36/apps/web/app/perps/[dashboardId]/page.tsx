export const dynamic = "force-dynamic";

import { notFound } from "next/navigation";

import { PERPS_DASHBOARDS } from "@/features/perps/perps-config";
import { PerpsWorkspace } from "@/features/perps/perps-workspace";

export default async function PerpsDashboardPage({
  params,
}: {
  params: Promise<{ dashboardId: string }>;
}) {
  const { dashboardId } = await params;
  const dashboard = PERPS_DASHBOARDS.find((item) => item.id === dashboardId);
  if (!dashboard) notFound();

  return (
    <PerpsWorkspace
      dashboardId={dashboardId}
      initialLatest={null}
      initialSeries={null}
      initialSignalSummaries={[]}
    />
  );
}
