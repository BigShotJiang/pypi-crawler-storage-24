import type { Metadata } from "next";
import "./globals.css";

import { RailNav } from "@/components/rail-nav";
import { StatusBar } from "@/components/status-bar";
import { CommandPalette } from "@/components/command-palette";
import { isMicrostructureEnabled } from "@/lib/features";

export const metadata: Metadata = {
  title: "uforia research platform",
  description: "Operator-grade analytics UI for BTC VVIX and future research engines.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const microstructureEnabled = isMicrostructureEnabled();

  return (
    <html lang="en">
      <body>
        <div className="terminalLayout">
          <RailNav microstructureEnabled={microstructureEnabled} />
          <main className="terminalMain">{children}</main>
          <StatusBar />
        </div>
        <CommandPalette microstructureEnabled={microstructureEnabled} />
      </body>
    </html>
  );
}
