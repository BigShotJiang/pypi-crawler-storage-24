export default function MicrostructureSectionLoading() {
  return (
    <div className="pageStack">
      <div style={{ marginBottom: 16 }}>
        <div style={{ width: 140, height: 10, background: "rgba(159, 176, 204, 0.08)", borderRadius: 3, marginBottom: 6 }} />
        <div style={{ width: 200, height: 16, background: "rgba(159, 176, 204, 0.12)", borderRadius: 3 }} />
      </div>
      <div className="twoCol">
        <div className="twoColNarrow">
          <div className="panel" style={{ padding: 16 }}>
            {[1, 2, 3, 4].map((i) => (
              <div key={i} style={{ height: 32, background: "rgba(159, 176, 204, 0.06)", borderRadius: 3, marginBottom: 8 }} />
            ))}
          </div>
        </div>
        <div className="twoColWide">
          <div style={{ height: 440, background: "rgba(159, 176, 204, 0.04)", borderRadius: 4 }} />
        </div>
      </div>
    </div>
  );
}
