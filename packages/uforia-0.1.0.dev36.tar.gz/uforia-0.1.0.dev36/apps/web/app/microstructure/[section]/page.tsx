import { notFound } from "next/navigation";

import { MicrostructureWorkspace } from "@/features/microstructure/microstructure-workspace";
import { isMicrostructureEnabled } from "@/lib/features";
import { MICROSTRUCTURE_SECTIONS } from "@/features/microstructure/microstructure-config";

export default async function MicrostructureSectionPage({
  params,
  searchParams,
}: {
  params: Promise<{ section: string }>;
  searchParams: Promise<{ asset?: string; horizon?: string }>;
}) {
  if (!isMicrostructureEnabled()) {
    notFound();
  }
  const { section } = await params;
  const { asset, horizon } = await searchParams;
  if (!MICROSTRUCTURE_SECTIONS.some((item) => item.id === section)) {
    notFound();
  }
  return <MicrostructureWorkspace section={section} initialAsset={asset} initialHorizon={horizon} />;
}
