import { notFound } from "next/navigation";

import { getMicrostructureHealth, getMicrostructureSignals } from "@/lib/api/client";
import { MicrostructureList } from "@/features/microstructure/microstructure-list";
import { isMicrostructureEnabled } from "@/lib/features";

export default async function MicrostructurePage() {
  if (!isMicrostructureEnabled()) {
    notFound();
  }
  const [signals, health] = await Promise.all([
    getMicrostructureSignals(),
    getMicrostructureHealth(),
  ]);
  return <MicrostructureList signals={signals} health={health} />;
}
