export default function Loading() {
  return (
    <div className="pageStack">
      <div className="sectionHeading">
        <div className="sectionKicker">Loading</div>
        <h1 className="sectionTitle">Preparing page shell</h1>
        <p className="sectionDescription">
          The interface will render first and data will continue loading in the background.
        </p>
      </div>
      <div className="panel">
        <div className="chartEmpty">
          <p className="eyebrow" style={{ animation: "fetchPulse 1.2s ease-in-out infinite" }}>
            Loading<span style={{ animation: "fetchPulse 0.6s ease-in-out infinite" }}>_</span>
          </p>
        </div>
      </div>
    </div>
  );
}
