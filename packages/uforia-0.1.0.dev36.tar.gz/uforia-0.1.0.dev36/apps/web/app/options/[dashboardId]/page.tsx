export const dynamic = "force-dynamic";

import { notFound } from "next/navigation";

import { OptionsWorkspace } from "@/features/options/options-workspace";
import {
  OPTIONS_DASHBOARDS,
  OPTIONS_SIGNAL_DESCRIPTIONS,
} from "@/features/options/options-config";

export default async function OptionsDashboardPage({
  params,
}: {
  params: Promise<{ dashboardId: string }>;
}) {
  const { dashboardId } = await params;
  const dashboard = OPTIONS_DASHBOARDS.find((item) => item.id === dashboardId);
  if (!dashboard) {
    notFound();
  }
  return (
    <OptionsWorkspace
      dashboardId={dashboardId}
      initialLatest={null}
      initialSeries={null}
      initialSignalSummaries={Object.keys(OPTIONS_SIGNAL_DESCRIPTIONS).map((id) => ({
        id,
        name: id,
        description: OPTIONS_SIGNAL_DESCRIPTIONS[id] ?? "",
        supported_underlyings: ["BTC", "ETH"],
        latest_updated_at: null,
        latest_quality: null,
        latest_values: {},
      }))}
    />
  );
}
