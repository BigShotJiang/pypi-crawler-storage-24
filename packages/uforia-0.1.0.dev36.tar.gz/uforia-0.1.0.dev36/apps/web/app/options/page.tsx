export const dynamic = "force-dynamic";

import { OptionsList } from "@/features/options/options-list";
import { getOptionsDashboards } from "@/lib/api/client";

export default async function OptionsPage() {
  try {
    const dashboards = await getOptionsDashboards({ strict: true, timeoutMs: 20000 });
    if (dashboards.length === 0) {
      return (
        <OptionsList
          dashboards={[]}
          loadError="No options dashboards were returned. Individual dashboards may still be available via search."
        />
      );
    }
    return <OptionsList dashboards={dashboards} />;
  } catch {
    return (
      <OptionsList
        dashboards={[]}
        loadError="Unable to load options dashboards right now. Individual dashboards may still be available via search."
      />
    );
  }
}
