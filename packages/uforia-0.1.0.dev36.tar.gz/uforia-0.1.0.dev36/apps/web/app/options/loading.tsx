export default function OptionsLoading() {
  return (
    <div className="pageStack">
      <div className="sectionHeading">
        <span className="sectionKicker">Options</span>
        <h1>Options analytics workbench</h1>
        <p>Loading the options dashboards and latest derived rows.</p>
      </div>
      <div className="panel">
        <div className="emptyState" style={{ minHeight: 220 }}>
          <strong style={{ display: "block", marginBottom: 6 }}>Loading options dashboards</strong>
          <span>Fetching the latest dashboard summaries from the API.</span>
        </div>
      </div>
    </div>
  );
}
