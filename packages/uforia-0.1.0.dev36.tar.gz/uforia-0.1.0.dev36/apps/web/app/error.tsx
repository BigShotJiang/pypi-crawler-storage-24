"use client";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="pageStack" style={{ padding: "40px 0" }}>
      <p className="eyebrow" style={{ color: "var(--danger)" }}>ERROR</p>
      <p style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--danger)" }}>
        {error.message}
      </p>
      <button
        onClick={reset}
        style={{
          background: "transparent",
          border: "1px solid var(--border)",
          borderRadius: 3,
          padding: "6px 14px",
          color: "var(--accent)",
          fontFamily: "var(--font-mono)",
          fontSize: 12,
          cursor: "pointer",
        }}
      >
        Retry
      </button>
    </div>
  );
}
