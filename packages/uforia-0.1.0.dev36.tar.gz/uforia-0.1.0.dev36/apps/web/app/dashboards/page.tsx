import { DashboardWorkspace } from "@/features/dashboards/dashboard-workspace";
import {
  getCompositeSignals,
  getOptionsDashboards,
  getPerpsDashboards,
  getSignals,
} from "@/lib/api/client";

export default async function DashboardsPage() {
  const [signals, compositeSignals, optionsDashboards, perpsDashboards] = await Promise.all([
    getSignals(),
    getCompositeSignals(),
    getOptionsDashboards({ strict: true, timeoutMs: 20000 }),
    getPerpsDashboards(),
  ]);
  return (
    <DashboardWorkspace
      signalSources={signals}
      compositeSources={compositeSignals}
      optionsSources={optionsDashboards}
      perpsSources={perpsDashboards}
    />
  );
}
