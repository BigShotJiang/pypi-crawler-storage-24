export const dynamic = "force-dynamic";

import { EnginesBoard } from "@/features/engines/engines-board";
import { getEngines } from "@/lib/api/client";

export default async function EnginesPage() {
  const engines = await getEngines();
  return <EnginesBoard engines={engines} />;
}

