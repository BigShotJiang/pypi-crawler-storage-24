export const dynamic = "force-dynamic";

import { RunsBoard } from "@/features/runs/runs-board";
import { getRuns, getRunsSummary } from "@/lib/api/client";

export default async function RunsPage() {
  const [runs, summary] = await Promise.all([getRuns({ limit: 50 }), getRunsSummary()]);
  return <RunsBoard initialRuns={runs} initialSummary={summary} />;
}

