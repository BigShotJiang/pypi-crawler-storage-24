import { ExecutionList } from "@/features/execution/execution-list";

export default function ExecutionPage() {
  return <ExecutionList venues={[]} accounts={[]} health={[]} />;
}
