import { notFound } from "next/navigation";

import { ExecutionWorkspace } from "@/features/execution/execution-workspace";
import { EXECUTION_SECTIONS } from "@/features/execution/execution-config";

export default async function ExecutionSectionPage({
  params,
  searchParams,
}: {
  params: Promise<{ section: string }>;
  searchParams: Promise<{ venue?: string; account?: string; asset?: string }>;
}) {
  const { section } = await params;
  const { venue, account, asset } = await searchParams;
  if (!EXECUTION_SECTIONS.some((item) => item.id === section)) {
    notFound();
  }

  return (
    <ExecutionWorkspace
      section={section}
      initial={{
        venues: [],
        accounts: [],
        markets: [],
        orders: [],
        fills: [],
        positions: [],
        balances: [],
        health: [],
      }}
      initialFilters={{
        venue: venue ?? "hyperliquid",
        account: account ?? "",
        asset: asset ?? "BTC",
      }}
    />
  );
}
