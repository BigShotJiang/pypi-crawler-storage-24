export const dynamic = "force-dynamic";

import { SignalList } from "@/features/signals/signal-list";
import { isMicrostructureEnabled } from "@/lib/features";
import { getMicrostructureSignals, getSignals } from "@/lib/api/client";

export default async function SignalsPage() {
  const microstructureEnabled = isMicrostructureEnabled();
  const signals = await getSignals();
  const microstructureSignals = microstructureEnabled ? await getMicrostructureSignals() : [];
  return (
    <SignalList
      signals={signals}
      microstructureSignals={microstructureSignals}
      microstructureEnabled={microstructureEnabled}
    />
  );
}
