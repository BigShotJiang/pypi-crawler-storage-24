export const dynamic = "force-dynamic";

import { SignalWorkspace } from "@/features/signals/signal-workspace";
import type { RunsSummary } from "@/lib/api/types";

const EMPTY_RUN_SUMMARY: RunsSummary = {
  total_runs: 0,
  success_count: 0,
  failed_count: 0,
  gap_count: 0,
  skipped_count: 0,
  latest_logical_ts: null,
  latest_run_lag_hours: null,
};

export default async function SignalPage({
  params,
  searchParams,
}: {
  params: Promise<{ signalId: string }>;
  searchParams: Promise<{ source?: string }>;
}) {
  const { signalId } = await params;
  const { source = "dvol" } = await searchParams;

  return (
    <SignalWorkspace
      signalId={signalId}
      initialLatest={null}
      initialSeries={null}
      initialRuns={[]}
      initialRunSummary={EMPTY_RUN_SUMMARY}
      initialSource={source}
    />
  );
}
