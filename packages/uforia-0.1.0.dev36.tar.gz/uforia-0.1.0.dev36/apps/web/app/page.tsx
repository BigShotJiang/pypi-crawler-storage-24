import { MarketOverviewShell } from "@/features/overview/market-overview-shell";

export default function Page() {
  return <MarketOverviewShell />;
}
