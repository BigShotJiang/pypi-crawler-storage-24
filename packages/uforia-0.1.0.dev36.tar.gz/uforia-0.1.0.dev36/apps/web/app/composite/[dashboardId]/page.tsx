export const dynamic = "force-dynamic";

import { notFound } from "next/navigation";

import { COMPOSITE_DASHBOARDS } from "@/features/composite/composite-config";
import { CompositeWorkspace } from "@/features/composite/composite-workspace";

export default async function CompositeDashboardPage({
  params,
}: {
  params: Promise<{ dashboardId: string }>;
}) {
  const { dashboardId } = await params;
  const dashboard = COMPOSITE_DASHBOARDS.find((item) => item.id === dashboardId);
  if (!dashboard) {
    notFound();
  }

  return (
    <CompositeWorkspace
      dashboardId={dashboardId}
      initialLatest={null}
      initialSeries={null}
      initialDecomposition={null}
      initialTransitions={null}
    />
  );
}
