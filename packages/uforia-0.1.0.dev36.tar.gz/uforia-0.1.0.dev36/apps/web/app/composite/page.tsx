export const dynamic = "force-dynamic";

import { CompositeList } from "@/features/composite/composite-list";
import { getCompositeSignals } from "@/lib/api/client";

export default async function CompositePage() {
  const signals = await getCompositeSignals();
  return <CompositeList signals={signals} />;
}
