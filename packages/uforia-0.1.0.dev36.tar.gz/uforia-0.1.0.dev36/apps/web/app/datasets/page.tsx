export const dynamic = "force-dynamic";

import { DatasetBrowser } from "@/features/datasets/dataset-browser";
import { getDataset, getDatasetRows, getDatasets } from "@/lib/api/client";

export default async function DatasetsPage({
  searchParams,
}: {
  searchParams: Promise<{ dataset?: string; source?: string }>;
}) {
  const { dataset = "vvix_series", source = "dvol" } = await searchParams;
  const [datasets, selectedDataset, rows] = await Promise.all([
    getDatasets(),
    getDataset(dataset),
    getDatasetRows(dataset, { source, limit: 25 }),
  ]);
  return <DatasetBrowser datasets={datasets} selectedDataset={selectedDataset} rows={rows} />;
}

