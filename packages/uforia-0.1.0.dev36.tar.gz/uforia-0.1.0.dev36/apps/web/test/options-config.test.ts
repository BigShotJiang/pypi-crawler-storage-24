import { describe, expect, it } from "vitest";

import {
  OPTIONS_DASHBOARDS,
  OPTIONS_SIGNAL_DESCRIPTIONS,
} from "@/features/options/options-config";

describe("options alpha canvas config", () => {
  it("registers the new dashboard ids", () => {
    const ids = new Set(OPTIONS_DASHBOARDS.map((dashboard) => dashboard.id));

    expect(Array.from(ids)).toEqual(
      expect.arrayContaining([
        "surface_factor_rv",
        "ml_carry_toxicity",
        "expiry_flow_map",
        "adaptive_hedging",
        "sessionality_clocks",
        "btc_eth_dispersion",
        "funding_basis_skew",
      ]),
    );
  });

  it("registers the new options signal descriptions", () => {
    expect(Object.keys(OPTIONS_SIGNAL_DESCRIPTIONS)).toEqual(
      expect.arrayContaining([
        "surface_factor_score",
        "residual_surface_rv_score",
        "ml_carry_toxicity_score",
        "expiry_pin_score",
        "gamma_flip_score",
        "adaptive_hedge_score",
        "sessionality_score",
        "dispersion_score",
        "funding_skew_score",
      ]),
    );
  });
});
