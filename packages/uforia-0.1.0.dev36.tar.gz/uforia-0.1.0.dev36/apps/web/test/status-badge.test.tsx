// @vitest-environment jsdom

import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";

import { StatusBadge } from "@/components/status-badge";

describe("StatusBadge", () => {
  it("renders the provided label", () => {
    render(<StatusBadge label="STREAM LIVE" tone="live" />);
    expect(screen.getByText("STREAM LIVE")).toBeInTheDocument();
  });
});
