export const DEFAULT_INITIAL_RANGE_DAYS = 1;

export const RANGE_OPTIONS = [1, 7, 30, 90] as const;

export function rangeStartIso(rangeDays: number) {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() - rangeDays);
  return date.toISOString();
}

export function rangeWindowIso(rangeDays: number, endIso?: string | null) {
  const end = endIso ? new Date(endIso) : new Date();
  if (Number.isNaN(end.getTime())) {
    return {
      start: rangeStartIso(rangeDays),
      end: undefined,
    };
  }
  const start = new Date(end);
  start.setUTCDate(start.getUTCDate() - rangeDays);
  return {
    start: start.toISOString(),
    end: end.toISOString(),
  };
}

export function seriesMaxPoints(rangeDays: number) {
  if (rangeDays <= 1) return 240;
  if (rangeDays <= 7) return 336;
  if (rangeDays <= 30) return 720;
  return 1200;
}
