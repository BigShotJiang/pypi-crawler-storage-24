export function isMicrostructureEnabled(): boolean {
  const value =
    process.env.UFORIA_ENABLE_MICROSTRUCTURE ??
    process.env.NEXT_PUBLIC_ENABLE_MICROSTRUCTURE ??
    "true";
  return value !== "false" && value !== "0";
}
