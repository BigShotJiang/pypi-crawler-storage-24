"use client";

import { useEffect, useState } from "react";

export function useUtcClock() {
  const [time, setTime] = useState<string | null>(null);

  useEffect(() => {
    setTime(formatUtc(new Date()));
    const id = setInterval(() => setTime(formatUtc(new Date())), 1000);
    return () => clearInterval(id);
  }, []);

  return time ?? "--:--:-- UTC";
}

function formatUtc(date: Date) {
  const h = String(date.getUTCHours()).padStart(2, "0");
  const m = String(date.getUTCMinutes()).padStart(2, "0");
  const s = String(date.getUTCSeconds()).padStart(2, "0");
  return `${h}:${m}:${s} UTC`;
}
