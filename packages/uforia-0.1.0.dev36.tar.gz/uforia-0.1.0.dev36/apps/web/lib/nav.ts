export type NavItem = {
  href: string;
  label: string;
  shortcut: string;
  exact: boolean;
};

const ALL_NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Overview", shortcut: "1", exact: true },
  { href: "/dashboards", label: "Dashboards", shortcut: "2", exact: false },
  { href: "/signals", label: "Signals", shortcut: "3", exact: false },
  { href: "/composite", label: "Composite", shortcut: "4", exact: false },
  { href: "/options", label: "Options", shortcut: "5", exact: false },
  { href: "/perps", label: "Perps", shortcut: "6", exact: false },
  { href: "/microstructure", label: "Microstructure", shortcut: "7", exact: false },
  { href: "/execution", label: "Execution", shortcut: "8", exact: false },
  { href: "/datasets", label: "Datasets", shortcut: "9", exact: false },
  { href: "/runs", label: "Runs", shortcut: "0", exact: false },
  { href: "/engines", label: "Engines", shortcut: "-", exact: false },
];

export function getNavItems(microstructureEnabled: boolean): NavItem[] {
  if (microstructureEnabled) {
    return ALL_NAV_ITEMS;
  }
  return ALL_NAV_ITEMS.filter((item) => item.href !== "/microstructure");
}

export function isActive(pathname: string, href: string, exact: boolean) {
  if (exact) return pathname === href;
  return pathname === href || pathname.startsWith(href + "/");
}
