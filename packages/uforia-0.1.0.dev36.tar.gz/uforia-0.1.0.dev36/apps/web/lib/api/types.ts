export type ApiEnvelope<T> = {
  data: T;
  meta: {
    generated_at: string;
    query: Record<string, unknown>;
  };
  warnings: string[];
};

export type SignalSummary = {
  id: string;
  name: string;
  symbol: string;
  family: string | null;
  description: string;
  available_sources: string[];
  latest_source: string | null;
  latest_updated_at: string | null;
  latest_quality: string | null;
  latest_values: Record<string, number | null>;
};

export type SignalSeriesPoint = {
  ts: string;
  source: string;
  underlying: string | null;
  dvol: number | null;
  vol_index_value: number | null;
  rvvix_14d: number | null;
  rvvix_30d: number | null;
  qvvix_30d: number | null;
  razor_pnl: number | null;
  razor_vrp: number | null;
  razor_pnl_zscore: number | null;
  razor_vrp_zscore: number | null;
  trade_band: string | null;
  long_vol_signal: boolean | null;
  short_vol_signal: boolean | null;
  fit_quality: number | null;
  gap: boolean;
  quality_flag: string | null;
};

export type SignalSeriesResponse = {
  signal_id: string;
  symbol: string;
  source: string;
  points: SignalSeriesPoint[];
  latest_values: Record<string, number | null>;
  context: Record<string, unknown>;
};

export type DatasetSummary = {
  id: string;
  name: string;
  rows: number;
  latest_ts: string | null;
  latest_logical_ts: string | null;
  partition_columns: string[];
  primary_key: string[];
  schema_columns: string[];
};

export type DatasetDetail = DatasetSummary & {
  sample_partitions: Record<string, unknown>[];
};

export type DatasetRowsResponse = {
  dataset_id: string;
  rows: Record<string, unknown>[];
  limit: number;
};

export type RunRecord = {
  run_id: string;
  logical_ts: string;
  run_ts: string;
  dataset: string;
  venue: string;
  underlying: string;
  status: string;
  rows_written_raw: number;
  rows_written_normalized: number;
  error_message: string | null;
  duration_ms: number;
};

export type RunsSummary = {
  total_runs: number;
  success_count: number;
  failed_count: number;
  gap_count: number;
  skipped_count: number;
  latest_logical_ts: string | null;
  latest_run_lag_hours: number | null;
};

export type SystemHealth = {
  status: string;
  api_version: string;
  data_root: string;
  websocket_enabled: boolean;
  dataset_count: number;
  signal_count: number;
  latest_signal_update: string | null;
  latest_run_update: string | null;
};

export type EngineSummary = {
  id: string;
  name: string;
  status: string;
  detail: string;
};

export type StreamEvent = {
  event: string;
  producer: string;
  emitted_at: string;
  data: Record<string, unknown>;
};

export type OptionsDashboardSummary = {
  id: string;
  name: string;
  family: string;
  description: string;
  supported_underlyings: string[];
  latest_updated_at: string | null;
  latest_quality: string | null;
  latest_values: Record<string, unknown>;
};

export type OptionsSeriesPoint = {
  ts: string;
  underlying: string | null;
  pair_id: string | null;
  tenor: string | null;
  tenor_bucket: string | null;
  moneyness_bucket: string | null;
  expiry_bucket: string | null;
  strike_bucket: string | null;
  values: Record<string, unknown>;
  quality_flag: string | null;
};

export type OptionsDashboardResponse = {
  dashboard_id: string;
  underlying: string | null;
  points: OptionsSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type OptionsSignalSummary = {
  id: string;
  name: string;
  description: string;
  supported_underlyings: string[];
  latest_updated_at: string | null;
  latest_quality: string | null;
  latest_values: Record<string, unknown>;
};

export type OptionsSignalSeriesResponse = {
  signal_id: string;
  underlying: string;
  points: OptionsSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type PerpsDashboardSummary = {
  id: string;
  name: string;
  family: string;
  description: string;
  supported_assets: string[];
  supported_venue_scopes: string[];
  latest_updated_at: string | null;
  latest_quality: string | null;
  latest_values: Record<string, unknown>;
};

export type PerpsSeriesPoint = {
  ts: string;
  asset: string | null;
  venue_scope: string | null;
  values: Record<string, unknown>;
  quality_flag: string | null;
};

export type PerpsDashboardResponse = {
  dashboard_id: string;
  asset: string;
  venue_scope: string;
  points: PerpsSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type PerpsSignalSummary = {
  id: string;
  name: string;
  description: string;
  supported_assets: string[];
  supported_venue_scopes: string[];
  latest_updated_at: string | null;
  latest_quality: string | null;
  latest_values: Record<string, unknown>;
};

export type PerpsSignalSeriesResponse = {
  signal_id: string;
  asset: string;
  venue_scope: string;
  points: PerpsSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type CompositeSignalSummary = {
  id: string;
  name: string;
  description: string;
  scope: string;
  asset: string;
  latest_updated_at: string | null;
  latest_quality: string | null;
  latest_values: Record<string, unknown>;
};

export type CompositeSeriesPoint = {
  ts: string;
  scope: string;
  asset: string;
  values: Record<string, unknown>;
  quality_flag: string | null;
};

export type CompositeSignalSeriesResponse = {
  signal_id: string;
  scope: string;
  asset: string;
  points: CompositeSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type CompositeComponentRecord = {
  ts: string;
  scope: string;
  asset: string;
  pillar: string;
  family: string;
  component: string;
  raw_value: number | null;
  normalized_value: number | null;
  component_weight: number | null;
  pillar_score: number | null;
  pillar_weight: number | null;
  signed_contribution: number | null;
  quality_flag: string | null;
};

export type CompositeDecompositionResponse = {
  signal_id: string;
  scope: string;
  asset: string;
  records: CompositeComponentRecord[];
  latest_contributors: CompositeComponentRecord[];
  context: Record<string, unknown>;
};

export type CompositeTransitionRecord = {
  ts: string;
  scope: string;
  asset: string;
  index_type: string;
  current_regime: string | null;
  prior_regime: string | null;
  stay_probability: number | null;
  upshift_probability: number | null;
  downshift_probability: number | null;
  median_regime_duration_hours: number | null;
  quality_flag: string | null;
};

export type CompositeTransitionResponse = {
  signal_id: string;
  scope: string;
  asset: string;
  records: CompositeTransitionRecord[];
  context: Record<string, unknown>;
};

export type MicrostructureSignalSummary = {
  id: string;
  name: string;
  asset: string;
  horizon: string;
  description: string;
  latest_updated_at: string | null;
  latest_quality: string | null;
  latest_values: Record<string, unknown>;
};

export type MicrostructureSeriesPoint = {
  ts: string;
  asset: string;
  horizon: string;
  signal_state: string | null;
  paper_position: string | null;
  regime_state: string | null;
  prob_down: number | null;
  prob_flat: number | null;
  prob_up: number | null;
  expected_move_bps: number | null;
  expected_edge_bps: number | null;
  tradability_score: number | null;
  confidence: number | null;
  confidence_bucket: string | null;
  blocked_reason: string | null;
  model_family: string | null;
  quality_flag: string | null;
  values: Record<string, unknown>;
};

export type MicrostructureSignalSeriesResponse = {
  signal_id: string;
  asset: string;
  horizon: string;
  points: MicrostructureSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type MicrostructureFeatureResponse = {
  asset: string;
  horizon: string;
  points: MicrostructureSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type MicrostructureRegimeResponse = {
  asset: string;
  points: MicrostructureSeriesPoint[];
  latest_values: Record<string, unknown>;
  context: Record<string, unknown>;
};

export type MicrostructureHealth = {
  status: string;
  engine_status: string;
  last_feature_ts: string | null;
  last_prediction_ts: string | null;
  last_training_ts: string | null;
  last_backtest_ts: string | null;
  signals_available: number;
};

export type PriceSummary = {
  asset: string;
  mid_price: number | null;
  best_bid: number | null;
  best_ask: number | null;
  spread_bps: number | null;
  venue: string | null;
  ts: string | null;
};

export type PriceCandlePoint = {
  ts: string;
  asset: string;
  venue_scope: string;
  timeframe: string;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  volume: number | null;
  trade_count: number | null;
};

export type PriceSeriesResponse = {
  asset: string;
  venue_scope: string;
  timeframe: string;
  points: PriceCandlePoint[];
  latest_values: Record<string, number | null>;
  context: Record<string, unknown>;
};

export type ExecutionVenueSummary = {
  venue: string;
  supported_instrument_types: string[];
  supported_order_types: string[];
  supports_post_only: boolean;
  supports_reduce_only: boolean;
  supports_amend: boolean;
  supports_mass_cancel: boolean;
  supports_private_ws: boolean;
  supports_quote_routing: boolean;
};

export type ExecutionAccountSummary = {
  label: string;
  venue: string;
  environment: string;
  wallet_address: string | null;
  enabled_assets: string[];
  enabled_symbols: string[];
  max_order_notional_usd: number;
  max_position_notional_usd: number;
  enabled: boolean;
  kill_switch: boolean;
};

export type ExecutionMarketSummary = {
  ts: string;
  venue: string;
  asset: string;
  symbol: string;
  instrument_type: string;
  status: string;
  tick_size: number | null;
  step_size: number | null;
  min_size: number | null;
  min_notional: number | null;
  best_bid: number | null;
  best_ask: number | null;
  mark_price: number | null;
  index_price: number | null;
  quality_flag: string | null;
};

export type ExecutionOrderRecord = {
  ts: string;
  request_id: string;
  venue_order_id: string | null;
  client_order_id: string | null;
  venue: string;
  account: string;
  asset: string | null;
  symbol: string | null;
  event_type: string;
  status: string;
  side: string | null;
  order_type: string | null;
  time_in_force: string | null;
  price: number | null;
  size: number | null;
  remaining_size: number | null;
  filled_size: number | null;
  avg_fill_price: number | null;
  reason: string | null;
  quality_flag: string | null;
};

export type ExecutionFillRecord = {
  ts: string;
  fill_id: string;
  request_id: string | null;
  venue_order_id: string | null;
  venue: string;
  account: string;
  asset: string;
  symbol: string;
  side: string;
  price: number | null;
  size: number | null;
  fee: number | null;
  fee_asset: string | null;
  liquidity: string | null;
  quality_flag: string | null;
};

export type ExecutionPositionRecord = {
  ts: string;
  venue: string;
  account: string;
  asset: string;
  symbol: string;
  instrument_type: string;
  position_side: string | null;
  quantity: number | null;
  entry_price: number | null;
  mark_price: number | null;
  unrealized_pnl: number | null;
  realized_pnl: number | null;
  notional_usd: number | null;
  leverage: number | null;
  margin_mode: string | null;
  quality_flag: string | null;
};

export type ExecutionBalanceRecord = {
  ts: string;
  venue: string;
  account: string;
  asset: string;
  balance_type: string;
  total: number | null;
  available: number | null;
  locked: number | null;
  quality_flag: string | null;
};

export type ExecutionHealthRecord = {
  ts: string | null;
  venue: string;
  account: string;
  status: string;
  ws_connected: boolean;
  private_ws_connected: boolean;
  last_heartbeat_ms: number | null;
  latency_ms: number | null;
  last_error: string | null;
  reconnect_count: number;
  quality_flag: string | null;
};

export type ExecutionActionResponse = {
  request_id: string;
  venue: string;
  account: string;
  status: string;
  mode: string;
  message: string;
  venue_order_id: string | null;
  quote_id: string | null;
  failure_code: string | null;
  payload: Record<string, unknown>;
  emitted_at: string;
};
