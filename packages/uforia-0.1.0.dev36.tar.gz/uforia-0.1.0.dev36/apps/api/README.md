# API App

Thin app host for the Python FastAPI service.

Run locally with:

```bash
uv run uforia-api
```

