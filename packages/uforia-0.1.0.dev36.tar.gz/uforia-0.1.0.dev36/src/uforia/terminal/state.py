from __future__ import annotations

from dataclasses import dataclass

from rich.console import Console

from .client import UforiaApiClient
from .config import TerminalConfig


@dataclass
class TerminalState:
    config: TerminalConfig
    client: UforiaApiClient
    console: Console
