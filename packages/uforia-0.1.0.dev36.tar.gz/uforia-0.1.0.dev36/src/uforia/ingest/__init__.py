"""Market data ingestion."""
