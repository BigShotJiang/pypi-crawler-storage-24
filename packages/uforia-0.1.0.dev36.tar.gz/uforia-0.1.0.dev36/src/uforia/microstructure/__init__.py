from __future__ import annotations

from importlib import import_module
from typing import Any

_EXPORTS: dict[str, tuple[str, str]] = {
    "build_microstructure_feature_series": (".builders", "build_microstructure_feature_series"),
    "build_microstructure_label_series": (".builders", "build_microstructure_label_series"),
    "build_microstructure_regime_series": (".builders", "build_microstructure_regime_series"),
    "build_microstructure_signal_series": (".builders", "build_microstructure_signal_series"),
    "import_crypto_microstructure_history": (".historical", "import_crypto_microstructure_history"),
    "build_live_microstructure_bars": (".live", "build_live_microstructure_bars"),
    "ingest_live_engine_state": (".live", "ingest_live_engine_state"),
    "run_live_microstructure_inference_daemon": (
        ".live",
        "run_live_microstructure_inference_daemon",
    ),
    "run_live_microstructure_inference_once": (".live", "run_live_microstructure_inference_once"),
    "evaluate_microstructure_model": (".training", "evaluate_microstructure_model"),
    "export_microstructure_model": (".training", "export_microstructure_model"),
    "generate_microstructure_model_output": (".training", "generate_microstructure_model_output"),
    "train_microstructure_model": (".training", "train_microstructure_model"),
}

__all__ = list(_EXPORTS)


def __getattr__(name: str) -> Any:
    target = _EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attr_name = target
    module = import_module(module_name, __name__)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
