from __future__ import annotations

TABULAR_SOURCE = "tcn_boost_tabular"
TCN_SOURCE = "tcn_boost_tcn"
FUSION_SOURCE = "tcn_boost_fusion"
PAPER_SOURCE = "tcn_boost_paper_signal"
MODEL_VERSION = "tcn_boost_fusion_v2"
