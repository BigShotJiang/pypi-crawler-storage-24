from __future__ import annotations

from pathlib import Path

from uforia.storage import DatasetStore


def import_crypto_microstructure_history(
    store: DatasetStore,
    root: Path,
    *,
    assets: tuple[str, ...] = ("BTC", "ETH"),
) -> dict[str, object]:
    del store, root, assets
    raise RuntimeError(
        "Historical parquet import has been removed. Load microstructure history into Postgres before training."
    )
