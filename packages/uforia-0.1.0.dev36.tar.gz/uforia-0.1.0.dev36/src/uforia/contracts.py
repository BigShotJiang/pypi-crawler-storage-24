from __future__ import annotations

from enum import Enum

from uforia.storage import DatasetName


class SignalId(str, Enum):
    BTC_VVIX = "btc_vvix"
    ETH_VVIX = "eth_vvix"
    BTC_RAZOR = "btc_razor"
    ETH_RAZOR = "eth_razor"
    BTC_COMPOSITE = "btc_composite"
    ETH_COMPOSITE = "eth_composite"
    MARKET_COMPOSITE = "market_composite"
    BTC_MICROSTRUCTURE_30S = "btc_microstructure_30s"
    BTC_MICROSTRUCTURE_1M = "btc_microstructure_1m"
    BTC_MICROSTRUCTURE_2M = "btc_microstructure_2m"
    BTC_MICROSTRUCTURE_5M = "btc_microstructure_5m"
    ETH_MICROSTRUCTURE_30S = "eth_microstructure_30s"
    ETH_MICROSTRUCTURE_1M = "eth_microstructure_1m"
    ETH_MICROSTRUCTURE_2M = "eth_microstructure_2m"
    ETH_MICROSTRUCTURE_5M = "eth_microstructure_5m"


class ProducerId(str, Enum):
    DERIBIT_OPTIONS_ARCHIVER = "deribit_options_archiver"
    UFORIA_PIPELINE = "uforia_pipeline"
    MICROSTRUCTURE_IMPORTER = "microstructure_importer"
    MICROSTRUCTURE_LIVE_ENGINE = "microstructure_live_engine"
    EXECUTION_ENGINE = "execution_engine"
    EXECUTION_STATE_SYNC = "execution_state_sync"


class EngineId(str, Enum):
    CORE_ANALYTICS = "core_analytics"
    MICROSTRUCTURE_LIVE_ENGINE = "microstructure_live_engine"
    MICROSTRUCTURE_TRAINING_PIPELINE = "microstructure_training_pipeline"
    EXECUTION_ENGINE = "execution_engine"
    EXECUTION_STATE_SYNC = "execution_state_sync"


SUPPORTED_MARKET_SYMBOLS = ("BTC", "ETH")
VVIX_SOURCES = ("dvol", "bvix")
RAZOR_SOURCES = ("synthetic_7d_atm",)
MICROSTRUCTURE_HORIZONS = ("30s", "1m", "2m", "5m")
MICROSTRUCTURE_SOURCES = (
    "tcn_boost_tabular",
    "tcn_boost_tcn",
    "tcn_boost_fusion",
    "tcn_boost_paper_signal",
)
OPTIONS_DASHBOARD_IDS = (
    "vol_surface",
    "carry_vrp",
    "skew_crash_premium",
    "surface_dislocation",
    "cross_asset_rv",
    "positioning_flow",
    "vol_cone",
    "term_structure_momentum",
    "gamma_exposure",
    "funding_context",
    "straddle_breakeven",
    "vol_regime_transitions",
    "surface_factor_rv",
    "ml_carry_toxicity",
    "expiry_flow_map",
    "adaptive_hedging",
    "sessionality_clocks",
    "btc_eth_dispersion",
    "funding_basis_skew",
)
OPTIONS_SIGNAL_IDS = (
    "vol_carry_score",
    "skew_stress_score",
    "surface_dislocation_score",
    "cross_asset_vol_score",
    "vol_regime_score",
    "funding_vol_context_score",
    "breakeven_gap_score",
    "term_structure_momentum_score",
    "surface_factor_score",
    "residual_surface_rv_score",
    "ml_carry_toxicity_score",
    "expiry_pin_score",
    "gamma_flip_score",
    "adaptive_hedge_score",
    "sessionality_score",
    "dispersion_score",
    "funding_skew_score",
)
PERPS_DASHBOARD_IDS = (
    "funding_basis_carry",
    "liquidation_cascade",
    "order_flow_toxicity",
    "oi_price_divergence",
    "cross_venue_price_discovery",
    "depth_resilience",
    "vol_microstructure",
    "cum_delta_momentum",
)
PERPS_SIGNAL_IDS = (
    "carry_score",
    "cascade_risk_score",
    "toxicity_score",
    "positioning_score",
    "fragility_score",
)
COMPOSITE_DASHBOARD_IDS = (
    "composite_overview",
    "composite_btc",
    "composite_eth",
    "composite_market",
    "composite_decomposition",
)
COMPOSITE_SIGNAL_IDS = (
    SignalId.BTC_COMPOSITE.value,
    SignalId.ETH_COMPOSITE.value,
    SignalId.MARKET_COMPOSITE.value,
)
EXECUTION_VENUES = ("derive", "hyperliquid", "lighter", "bebop")
EXECUTION_PAGES = (
    "overview",
    "markets",
    "order-entry",
    "orders",
    "fills",
    "positions",
    "balances",
    "venue-health",
)
SUPPORTED_SOURCES = (*VVIX_SOURCES, *RAZOR_SOURCES)
UI_EXPOSED_DATASETS = (
    DatasetName.MICROSTRUCTURE_RAW_EVENT,
    DatasetName.MICROSTRUCTURE_BOOK_STATE,
    DatasetName.MICROSTRUCTURE_BAR,
    DatasetName.MICROSTRUCTURE_FEATURE_SERIES,
    DatasetName.MICROSTRUCTURE_LABEL_SERIES,
    DatasetName.MICROSTRUCTURE_MODEL_OUTPUT,
    DatasetName.MICROSTRUCTURE_REGIME_SERIES,
    DatasetName.MICROSTRUCTURE_SIGNAL_SERIES,
    DatasetName.MICROSTRUCTURE_TRAINING_RUN,
    DatasetName.MICROSTRUCTURE_BACKTEST_RUN,
    DatasetName.VVIX_SERIES,
    DatasetName.RAZOR_SERIES,
    DatasetName.OPTIONS_SURFACE_SNAPSHOT,
    DatasetName.OPTIONS_CARRY_SERIES,
    DatasetName.OPTIONS_SKEW_SERIES,
    DatasetName.OPTIONS_DISLOCATION_SERIES,
    DatasetName.OPTIONS_RELATIVE_VALUE_SERIES,
    DatasetName.OPTIONS_POSITIONING_SERIES,
    DatasetName.OPTIONS_SURFACE_FACTOR_SERIES,
    DatasetName.OPTIONS_ML_CARRY_SERIES,
    DatasetName.OPTIONS_EXPIRY_FLOW_SERIES,
    DatasetName.OPTIONS_ADAPTIVE_HEDGE_SERIES,
    DatasetName.OPTIONS_SESSIONALITY_SERIES,
    DatasetName.OPTIONS_DISPERSION_SERIES,
    DatasetName.OPTIONS_FUNDING_SKEW_SERIES,
    DatasetName.OPTIONS_SIGNAL_SERIES,
    DatasetName.FUNDING_RATE_SNAPSHOT,
    DatasetName.VOL_CONE_SERIES,
    DatasetName.TERM_STRUCTURE_MOMENTUM_SERIES,
    DatasetName.GAMMA_EXPOSURE_SERIES,
    DatasetName.FUNDING_CONTEXT_SERIES,
    DatasetName.STRADDLE_BREAKEVEN_SERIES,
    DatasetName.VOL_REGIME_TRANSITION_SERIES,
    DatasetName.PERPS_SIGNAL_SERIES,
    DatasetName.PERPS_COMPOSITE_SERIES,
    DatasetName.PERPS_TRANSITION_SERIES,
    DatasetName.COMPOSITE_SIGNAL_SERIES,
    DatasetName.COMPOSITE_COMPONENT_SERIES,
    DatasetName.COMPOSITE_TRANSITION_SERIES,
    DatasetName.EXECUTION_ORDER_INTENT,
    DatasetName.EXECUTION_ORDER_EVENT,
    DatasetName.EXECUTION_FILL_EVENT,
    DatasetName.EXECUTION_POSITION_SNAPSHOT,
    DatasetName.EXECUTION_BALANCE_SNAPSHOT,
    DatasetName.EXECUTION_QUOTE_SNAPSHOT,
    DatasetName.EXECUTION_MARKET_SNAPSHOT,
    DatasetName.EXECUTION_HEALTH_SNAPSHOT,
    DatasetName.VOL_INDEX_SERIES,
    DatasetName.SURFACE_FEATURES,
    DatasetName.INGESTION_RUNS,
    DatasetName.OPTION_CHAIN_SNAPSHOT,
    DatasetName.DVOL_SNAPSHOT,
)

# Keep API/UI on DB-backed reads for the hot serving datasets, but do not make
# the heaviest raw/training tables DB-strict while long-running raw migrations
# are still in progress on the Mac Mini.
API_DB_STRICT_DATASETS = (
    DatasetName.VVIX_SERIES,
    DatasetName.RAZOR_SERIES,
    DatasetName.OPTIONS_SURFACE_SNAPSHOT,
    DatasetName.OPTIONS_CARRY_SERIES,
    DatasetName.OPTIONS_SKEW_SERIES,
    DatasetName.OPTIONS_DISLOCATION_SERIES,
    DatasetName.OPTIONS_RELATIVE_VALUE_SERIES,
    DatasetName.OPTIONS_POSITIONING_SERIES,
    DatasetName.OPTIONS_SURFACE_FACTOR_SERIES,
    DatasetName.OPTIONS_ML_CARRY_SERIES,
    DatasetName.OPTIONS_EXPIRY_FLOW_SERIES,
    DatasetName.OPTIONS_ADAPTIVE_HEDGE_SERIES,
    DatasetName.OPTIONS_SESSIONALITY_SERIES,
    DatasetName.OPTIONS_DISPERSION_SERIES,
    DatasetName.OPTIONS_FUNDING_SKEW_SERIES,
    DatasetName.OPTIONS_SIGNAL_SERIES,
    DatasetName.FUNDING_RATE_SNAPSHOT,
    DatasetName.VOL_CONE_SERIES,
    DatasetName.TERM_STRUCTURE_MOMENTUM_SERIES,
    DatasetName.GAMMA_EXPOSURE_SERIES,
    DatasetName.FUNDING_CONTEXT_SERIES,
    DatasetName.STRADDLE_BREAKEVEN_SERIES,
    DatasetName.VOL_REGIME_TRANSITION_SERIES,
    DatasetName.PERPS_SIGNAL_SERIES,
    DatasetName.PERPS_COMPOSITE_SERIES,
    DatasetName.PERPS_TRANSITION_SERIES,
    DatasetName.COMPOSITE_SIGNAL_SERIES,
    DatasetName.COMPOSITE_COMPONENT_SERIES,
    DatasetName.COMPOSITE_TRANSITION_SERIES,
    DatasetName.EXECUTION_ORDER_INTENT,
    DatasetName.EXECUTION_ORDER_EVENT,
    DatasetName.EXECUTION_FILL_EVENT,
    DatasetName.EXECUTION_POSITION_SNAPSHOT,
    DatasetName.EXECUTION_BALANCE_SNAPSHOT,
    DatasetName.EXECUTION_QUOTE_SNAPSHOT,
    DatasetName.EXECUTION_MARKET_SNAPSHOT,
    DatasetName.EXECUTION_HEALTH_SNAPSHOT,
    DatasetName.MICROSTRUCTURE_MODEL_OUTPUT,
    DatasetName.MICROSTRUCTURE_REGIME_SERIES,
    DatasetName.MICROSTRUCTURE_SIGNAL_SERIES,
    DatasetName.MICROSTRUCTURE_TRAINING_RUN,
    DatasetName.MICROSTRUCTURE_BACKTEST_RUN,
    DatasetName.MICROSTRUCTURE_BAR,
    DatasetName.VOL_INDEX_SERIES,
    DatasetName.SURFACE_FEATURES,
    DatasetName.INGESTION_RUNS,
    DatasetName.OPTION_CHAIN_SNAPSHOT,
    DatasetName.DVOL_SNAPSHOT,
)
