from __future__ import annotations

import uvicorn

from uforia.api.app import create_app
from uforia.api.settings import get_api_settings


def main() -> None:
    settings = get_api_settings()
    uvicorn.run(
        "uforia.api.app:create_app",
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
        factory=True,
    )


app = create_app()
