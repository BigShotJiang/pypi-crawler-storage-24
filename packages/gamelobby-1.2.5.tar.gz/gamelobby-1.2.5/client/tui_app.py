"""
Textual TUI 主应用 — 极简终端风格
"""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Input, RichLog
from textual.containers import Vertical, Horizontal, Center, Middle
from textual.binding import Binding
from textual.message import Message
from textual import work

from .config import PORT, DEFAULT_HOST
from .network import NetworkManager
from .vim_mode import VimMode, Mode
from .message_handler import (
    parse_server_message,
    LoginPrompt, RequestAvatar, LoginSuccess,
    SystemMessage, GameMessage, ChatMessage, ChatHistory,
    StatusUpdate, OnlineUsers, GameInvite,
    RoomUpdate, RoomLeave, GameQuit, LocationUpdate,
    HandUpdate, ActionPrompt, SelfActionPrompt,
    WinAnimation, ActionCommand,
)
from .tui_widgets import ChatPanel, CommandPanel, InfoPanel

try:
    from .config import VERSION
except ImportError:
    VERSION = None


# ═══════════════════════════════════════════════════════
#  自定义消息
# ═══════════════════════════════════════════════════════

class ServerMsg(Message):
    def __init__(self, data: dict) -> None:
        super().__init__()
        self.data = data


class Disconnected(Message):
    pass


# ═══════════════════════════════════════════════════════
#  LoginScreen
# ═══════════════════════════════════════════════════════

class LoginScreen(Screen):
    BINDINGS = [Binding("escape", "quit", "退出", show=True)]

    def compose(self) -> ComposeResult:
        with Center():
            with Middle():
                with Vertical(id="login-container"):
                    yield Static("游戏大厅", id="login-title")
                    yield Input(placeholder=f"服务器地址 ({DEFAULT_HOST})", id="login-input")
                    yield Static("按 Enter 连接", id="login-status")

    def on_mount(self) -> None:
        self._check_update()

    @work(thread=True)
    def _check_update(self):
        import json
        import urllib.request
        try:
            req = urllib.request.Request(
                "https://pypi.org/pypi/gamelobby/json",
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                latest = json.loads(resp.read().decode())["info"]["version"]
            current = VERSION or "0.0.0"
            cur = tuple(int(x) for x in current.split("."))
            lat = tuple(int(x) for x in latest.split("."))
            if lat > cur:
                self.app.call_from_thread(
                    self.set_status,
                    f"发现新版本 v{latest}（当前 v{current}）\n"
                    f"请运行 pip install --upgrade gamelobby 更新\n\n"
                    f"按 Enter 连接",
                )
        except Exception:
            pass

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "login-input":
            return
        ip = event.value.strip() or DEFAULT_HOST
        self.query_one("#login-status", Static).update(f"正在连接 {ip}…")
        self.app.connect_to_server(ip)

    def set_status(self, text: str):
        try:
            self.query_one("#login-status", Static).update(text)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════
#  GameScreen — 三栏终端界面
# ═══════════════════════════════════════════════════════

class GameScreen(Screen):
    BINDINGS = [Binding("escape", "enter_normal", "", show=False)]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.logged_in = False
        self.in_mahjong_game = False
        self.current_location = "lobby"
        self.current_room_id = None
        self.need_discard = False
        self._input_buffer = ""       # INSERT 模式输入缓冲
        self._input_target = "cmd"    # 当前输入目标: "cmd" 或 "chat"

    def compose(self) -> ComposeResult:
        yield Static("", id="command-line")
        with Horizontal(id="main-container"):
            yield ChatPanel(id="chat-panel", classes="panel")
            yield CommandPanel(id="cmd-panel", classes="panel")
            yield InfoPanel(id="info-panel", classes="panel")
        with Horizontal(id="footer-bar"):
            yield Static(" NORMAL ", id="mode-indicator")
            yield Static("大厅", id="location-indicator")
            yield Static("已连接", id="connection-status")

    def on_mount(self) -> None:
        self.chat_panel.border_title = "[b]世界[/b] │ [dim]房间[/]"
        self.cmd_panel.border_title = "指令"
        self.info_panel.border_title = "信息"
        # 登录阶段自动进入输入模式
        self._enter_insert("cmd")

    # ── 属性快捷访问 ──

    @property
    def chat_panel(self) -> ChatPanel:
        return self.query_one("#chat-panel", ChatPanel)

    @property
    def cmd_panel(self) -> CommandPanel:
        return self.query_one("#cmd-panel", CommandPanel)

    @property
    def info_panel(self) -> InfoPanel:
        return self.query_one("#info-panel", InfoPanel)

    @property
    def vim(self) -> VimMode:
        return self.app.vim

    _PANELS = ["chat-panel", "cmd-panel", "info-panel"]

    # ── 模式切换 ──

    def action_enter_normal(self):
        if self.vim.mode == Mode.INSERT and self._input_buffer:
            # 丢弃未提交的输入
            self._input_buffer = ""
            self._update_prompt_line("")
        self.vim.enter_normal()
        self._update_mode_indicator()
        cmd_line = self.query_one("#command-line", Static)
        cmd_line.remove_class("visible")
        self.set_focus(None)

    def _enter_insert(self, target: str):
        """进入 INSERT 模式，target 为 'cmd' 或 'chat'"""
        self._input_target = target
        self._input_buffer = ""
        self.vim.enter_insert()
        self._update_mode_indicator()
        self._update_prompt_line("")

    def _enter_command_mode(self):
        self.vim.enter_command()
        self._update_mode_indicator()
        cmd_line = self.query_one("#command-line", Static)
        cmd_line.add_class("visible")
        cmd_line.update(":")

    def _update_mode_indicator(self):
        indicator = self.query_one("#mode-indicator", Static)
        mode = self.vim.mode
        if mode == Mode.NORMAL:
            indicator.update(" NORMAL ")
        elif mode == Mode.INSERT:
            label = "聊天" if self._input_target == "chat" else "指令"
            indicator.update(f" {label} ")
        elif mode == Mode.COMMAND:
            indicator.update(f" :{self.vim.command_buffer} ")

    def _update_prompt_line(self, text: str):
        """在当前焦点面板的 RichLog 底部显示输入提示行"""
        if self._input_target == "chat":
            prompt = f"> {text}█"
        elif not self.logged_in:
            prompt = f"  {text}█"
        else:
            prompt = f"/ {text}█"
        cmd_line = self.query_one("#command-line", Static)
        cmd_line.add_class("visible")
        cmd_line.update(prompt)

    def _update_location(self, location: str):
        self.current_location = location
        indicator = self.query_one("#location-indicator", Static)
        self.info_panel.set_location(location)
        loc_names = {
            "lobby": "大厅", "mahjong": "麻将",
            "mahjong_room": "麻将房间", "mahjong_playing": "麻将对局",
            "chess": "象棋", "chess_room": "象棋房间",
            "chess_playing": "象棋对局", "jrpg": "JRPG",
        }
        indicator.update(loc_names.get(location, location))

    # ── 键位处理 ──

    def on_key(self, event) -> None:
        vim = self.vim

        # ── INSERT 模式 ──
        if vim.mode == Mode.INSERT:
            event.prevent_default()
            event.stop()

            if event.key == "escape":
                self.action_enter_normal()
            elif event.key == "enter":
                self._submit_input()
            elif event.key == "backspace":
                self._input_buffer = self._input_buffer[:-1]
                self._update_prompt_line(self._input_buffer)
            else:
                ch = event.character
                if ch and ch.isprintable():
                    self._input_buffer += ch
                    self._update_prompt_line(self._input_buffer)
            return

        # ── COMMAND 模式 ──
        if vim.mode == Mode.COMMAND:
            event.prevent_default()
            event.stop()
            if event.key == "escape":
                self.action_enter_normal()
            elif event.key == "enter":
                cmd = vim.command_submit()
                self._execute_command(cmd)
                self._update_mode_indicator()
            elif event.key == "backspace":
                vim.command_backspace()
                cmd_line = self.query_one("#command-line", Static)
                cmd_line.update(f":{vim.command_buffer}")
                self._update_mode_indicator()
            else:
                ch = event.character
                if ch and ch.isprintable():
                    vim.command_append(ch)
                    cmd_line = self.query_one("#command-line", Static)
                    cmd_line.update(f":{vim.command_buffer}")
                    self._update_mode_indicator()
            return

        # ── NORMAL 模式 ──
        event.prevent_default()
        event.stop()
        key = event.key

        # 前缀键
        if vim.pending_key == "g":
            vim.pending_key = ""
            if key == "g":
                self._scroll_cmd_top()
            return

        if vim.pending_key == "d":
            vim.pending_key = ""
            ch = event.character
            if ch and ch.isprintable():
                self._discard_tile(ch)
            return

        # 单键
        if key == "colon":
            self._enter_command_mode()
        elif key == "i":
            self._enter_insert("chat")
        elif key == "slash":
            self._enter_insert("cmd")
        elif key == "j":
            self._scroll_cmd_down()
        elif key == "k":
            self._scroll_cmd_up()
        elif key == "G":
            self._scroll_cmd_bottom()
        elif key == "g":
            vim.pending_key = "g"
        elif key == "h" or key == "l":
            pass  # 保留但不做操作
        elif key == "d":
            if self.need_discard:
                vim.pending_key = "d"
        elif key == "q":
            self._send_command("/back")
        elif key == "tab":
            self._cycle_channel()
        elif event.character and event.character.isdigit() and event.character != "0":
            self._send_command(f"/{event.character}")

    # ── 输入提交 ──

    def _submit_input(self):
        text = self._input_buffer.strip()
        self._input_buffer = ""
        cmd_line = self.query_one("#command-line", Static)
        cmd_line.remove_class("visible")
        self.vim.enter_normal()
        self._update_mode_indicator()

        if not text:
            return

        if self._input_target == "chat":
            self._send_chat(text, self.chat_panel.current_channel)
        else:
            # 登录阶段直接发送文本，不加 /
            if not self.logged_in:
                self._send_command(text)
            else:
                if not text.startswith("/"):
                    text = "/" + text
                self._send_command(text)
        # 登录阶段提交后保持 INSERT 模式
        if not self.logged_in:
            self._enter_insert("cmd")

    # ── 滚动 ──

    def _get_cmd_log(self) -> RichLog | None:
        try:
            return self.query_one("#cmd-log", RichLog)
        except Exception:
            return None

    def _scroll_cmd_down(self):
        log = self._get_cmd_log()
        if log:
            log.scroll_down(animate=False)

    def _scroll_cmd_up(self):
        log = self._get_cmd_log()
        if log:
            log.scroll_up(animate=False)

    def _scroll_cmd_bottom(self):
        log = self._get_cmd_log()
        if log:
            log.scroll_end(animate=False)

    def _scroll_cmd_top(self):
        log = self._get_cmd_log()
        if log:
            log.scroll_home(animate=False)

    # ── 指令发送 ──

    def _send_command(self, text: str):
        self.app.send_command(text)

    def _send_chat(self, text: str, channel: int):
        self.app.send_chat(text, channel)

    def _execute_command(self, cmd: str):
        cmd_line = self.query_one("#command-line", Static)
        cmd_line.remove_class("visible")
        if not cmd:
            return
        if cmd in ("q", "quit"):
            self.app.exit()
            return
        self._send_command(f"/{cmd}")

    def _discard_tile(self, tile_name: str):
        self._send_command(f"/d {tile_name}")

    def _cycle_channel(self):
        ch = self.chat_panel.current_channel
        new_ch = 2 if ch == 1 else 1
        self.chat_panel.switch_channel(new_ch)
        self.app.switch_channel(new_ch)

    # ── 操作提示 ──

    def show_action_prompt(self, actions: dict, tile: str, from_player: str):
        parts = []
        idx = 1
        for action_name, label in [("ron", "荣和"), ("pon", "碰"), ("kan", "杠")]:
            if action_name in actions:
                parts.append(f"[{idx}]{label}")
                idx += 1
        if "chi" in actions:
            chi_opts = actions["chi"]
            if isinstance(chi_opts, list):
                for c in chi_opts:
                    parts.append(f"[{idx}]吃{c}")
                    idx += 1
            else:
                parts.append(f"[{idx}]吃")
                idx += 1
        parts.append(f"[{idx}]跳过")
        self.cmd_panel.set_action_bar(f"{from_player}打出 {tile}: {' '.join(parts)}")

    def show_self_action_prompt(self, actions: dict):
        parts = []
        idx = 1
        if "tsumo" in actions:
            parts.append(f"[{idx}]自摸"); idx += 1
        if "riichi" in actions:
            parts.append(f"[{idx}]立直"); idx += 1
        if "ankan" in actions:
            for tiles in actions["ankan"]:
                parts.append(f"[{idx}]暗杠{tiles}"); idx += 1
        if "kakan" in actions:
            for tile in actions["kakan"]:
                parts.append(f"[{idx}]加杠{tile}"); idx += 1
        parts.append(f"[{idx}]跳过")
        self.cmd_panel.set_action_bar(" ".join(parts))


# ═══════════════════════════════════════════════════════
#  GameLobbyApp — 主应用
# ═══════════════════════════════════════════════════════


class GameLobbyApp(App):
    """游戏大厅 TUI 客户端"""

    TITLE = "游戏大厅"
    CSS_PATH = "theme.tcss"

    BINDINGS = [
        Binding("ctrl+c", "quit", "退出", show=True, priority=True),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.network = NetworkManager(PORT)
        self.vim = VimMode()
        self.player_data: dict = {}
        self._pending_messages: list[dict] = []
        self._current_channel = 1

    def on_mount(self) -> None:
        self.push_screen(LoginScreen())

    # ── 网络 ──

    def connect_to_server(self, ip: str):
        """从 LoginScreen 调用，建立连接"""
        try:
            self.network.connect(ip)
        except Exception as e:
            screen = self.screen
            if isinstance(screen, LoginScreen):
                screen.set_status(f"连接失败: {e}")
            return

        self.network.disconnect_callback = self._on_disconnect
        self._start_receive_worker()

        # 切换到游戏界面
        self.switch_screen(GameScreen())

        # 处理缓冲消息
        for msg in self._pending_messages:
            self.post_message(ServerMsg(msg))
        self._pending_messages.clear()

    @work(thread=True)
    def _start_receive_worker(self):
        """后台线程：接收服务器消息并投递到事件循环"""
        buffer = ""
        import json
        while self.network.connected:
            try:
                data = self.network.socket.recv(4096)
                if not data:
                    break
                buffer += data.decode("utf-8")
                while "\n" in buffer:
                    msg_str, buffer = buffer.split("\n", 1)
                    if msg_str:
                        try:
                            msg = json.loads(msg_str)
                            self.post_message(ServerMsg(msg))
                        except Exception:
                            pass
            except Exception:
                break

        self.network.connected = False
        self.post_message(Disconnected())

    def _on_disconnect(self):
        self.post_message(Disconnected())

    def on_disconnected(self, _msg: Disconnected) -> None:
        """处理连接断开"""
        screen = self.screen
        if isinstance(screen, GameScreen):
            screen.cmd_panel.add_message("[dim]连接已断开[/]")
            conn = screen.query_one("#connection-status", Static)
            conn.update("已断开")

    # ── 消息处理 ──

    def on_server_msg(self, event: ServerMsg) -> None:
        """统一处理服务器消息"""
        screen = self.screen
        if not isinstance(screen, GameScreen):
            self._pending_messages.append(event.data)
            return

        parsed = parse_server_message(event.data)
        gs = screen

        if isinstance(parsed, LoginPrompt):
            gs.cmd_panel.add_message(parsed.text)

        elif isinstance(parsed, RequestAvatar):
            gs.cmd_panel.add_message(parsed.text)
            gs.cmd_panel.add_message("[dim]（TUI 模式下暂不支持编辑头像，跳过）[/]")

        elif isinstance(parsed, LoginSuccess):
            gs.logged_in = True
            gs.cmd_panel.add_message(parsed.text)
            gs.action_enter_normal()

        elif isinstance(parsed, SystemMessage):
            gs.chat_panel.add_system_message(parsed.text)

        elif isinstance(parsed, GameMessage):
            gs.cmd_panel.add_message(parsed.text, update_last=parsed.update_last)
            if parsed.clear_discard:
                gs.need_discard = False

        elif isinstance(parsed, ChatMessage):
            gs.chat_panel.add_message(parsed.name, parsed.text, parsed.channel, parsed.time)

        elif isinstance(parsed, ChatHistory):
            gs.chat_panel.show_history(parsed.messages, parsed.channel)

        elif isinstance(parsed, StatusUpdate):
            self.player_data = parsed.data
            gs.info_panel.update_status(parsed.data)
            if parsed.map_data:
                gs.info_panel.update_map(parsed.map_data)

        elif isinstance(parsed, OnlineUsers):
            gs.chat_panel.update_online_users(parsed.users)

        elif isinstance(parsed, GameInvite):
            inv = parsed.raw
            gs.cmd_panel.add_message(
                f"[b]游戏邀请[/b]: {inv.get('from', '?')} 邀请你加入 {inv.get('game', '?')}"
            )

        elif isinstance(parsed, RoomUpdate):
            if parsed.room_data:
                gs.info_panel.update_table(parsed.room_data)
                room_id = parsed.room_data.get("room_id")
                if room_id:
                    gs.current_room_id = room_id
                game_type = parsed.room_data.get("game_type", "mahjong")
                state = parsed.room_data.get("state", "waiting")
                if game_type == "mahjong":
                    gs.in_mahjong_game = state == "playing"
            if parsed.message:
                gs.cmd_panel.add_message(parsed.message)

        elif isinstance(parsed, (RoomLeave, GameQuit)):
            gs.info_panel.update_table(None)
            gs.info_panel.clear_hand()
            gs.in_mahjong_game = False
            gs.current_room_id = None
            if parsed.location:
                gs._update_location(parsed.location)

        elif isinstance(parsed, LocationUpdate):
            gs._update_location(parsed.location)

        elif isinstance(parsed, HandUpdate):
            gs.info_panel.update_hand(
                parsed.hand, parsed.drawn, parsed.tenpai_analysis, parsed.need_discard
            )
            gs.need_discard = parsed.need_discard

        elif isinstance(parsed, ActionPrompt):
            gs.show_action_prompt(parsed.actions, parsed.tile, parsed.from_player)

        elif isinstance(parsed, SelfActionPrompt):
            gs.show_self_action_prompt(parsed.actions)

        elif isinstance(parsed, WinAnimation):
            self._show_win_animation(gs, parsed)

        elif isinstance(parsed, ActionCommand):
            action = parsed.action
            if action == "clear":
                gs.cmd_panel.clear()
            elif action == "version":
                sv = parsed.raw.get("server_version", "未知")
                cv = VERSION or "开发版"
                gs.cmd_panel.add_message(f"版本信息\n客户端: v{cv}\n服务器: v{sv}")
            elif action == "exit":
                self.network.disconnect()
                self.exit()
            elif action == "maintenance":
                gs.cmd_panel.add_message("[b]系统维护[/b]: 服务器正在维护，请稍后重连。")
                self.network.disconnect()

    def _show_win_animation(self, gs: GameScreen, w: WinAnimation):
        if w.win_type == "tsumo":
            header = f"[b]【{w.winner} 自摸】[/b] [{w.tile}]"
        else:
            header = f"[b]【{w.winner} 荣和】[/b] [{w.tile}]"
            if w.loser:
                header += f" (放铳: {w.loser})"
        gs.cmd_panel.add_message(header)

        delay = 0.8
        for i, yaku in enumerate(w.yakus):
            yaku_name = yaku[0]
            yaku_han = yaku[1]
            is_yakuman = yaku[2] if len(yaku) > 2 else False
            if is_yakuman:
                text = f"  ★ {yaku_name} (役满)"
            else:
                text = f"  · {yaku_name} ({yaku_han}番)"
            self.set_timer(delay * (i + 1), lambda t=text: gs.cmd_panel.add_message(t))

        final_delay = delay * (len(w.yakus) + 1)
        if w.is_yakuman:
            score_text = f"\n[b]【点数】役满 {w.score}点[/b]"
        else:
            score_text = f"\n[b]【点数】{w.han}番{w.fu}符 = {w.score}点[/b]"

        self.set_timer(final_delay, lambda: gs.cmd_panel.add_message(score_text))
        self.set_timer(
            final_delay + 0.4,
            lambda: gs.cmd_panel.add_message("\n输入 /next 开始下一局"),
        )

    # ── 发送 ──

    def send_command(self, text: str):
        self.network.send({"type": "command", "text": text})

    def send_chat(self, text: str, channel: int):
        self.network.send({"type": "chat", "text": text, "channel": channel})

    def switch_channel(self, channel_id: int):
        self._current_channel = channel_id
        self.network.send({"type": "switch_channel", "channel": channel_id})

    # ── 退出 ──

    def action_quit(self) -> None:
        self.network.disconnect()
        self.exit()


def main():
    """CLI 入口点"""
    app = GameLobbyApp()
    app.run()
