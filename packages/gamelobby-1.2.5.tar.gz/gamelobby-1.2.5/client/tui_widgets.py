"""
TUI 面板组件 — ChatPanel / CommandPanel / InfoPanel
纯终端风格：所有面板只有 RichLog，无独立输入框
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import Static, RichLog
from textual.containers import Vertical
from textual.widget import Widget


# ═══════════════════════════════════════════════════════
#  ChatPanel — 聊天面板（左栏）
# ═══════════════════════════════════════════════════════

class ChatPanel(Widget):
    """聊天面板：频道标签 + 消息日志"""

    CHANNEL_NAMES = {1: "世界", 2: "房间"}

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_channel = 1

    def compose(self) -> ComposeResult:
        yield RichLog(id="chat-log", wrap=True, highlight=True, markup=True, max_lines=500)

    def add_message(self, name: str, text: str, channel: int = 1, time_str: str = ""):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.write(f"{name}> {text}")

    def add_system_message(self, text: str):
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.write(f"[dim]>>> {text}[/]")

    def show_history(self, messages: list, channel: int):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.clear()
        for m in messages:
            name = m.get("name", "???")
            text = m.get("text", "")
            log.write(f"{name}> {text}")

    def switch_channel(self, channel_id: int):
        self.current_channel = channel_id
        labels = []
        for cid, cname in self.CHANNEL_NAMES.items():
            if cid == channel_id:
                labels.append(f"[b]{cname}[/b]")
            else:
                labels.append(f"[dim]{cname}[/]")
        self.border_title = " │ ".join(labels)

    def update_online_users(self, users: list):
        if not users:
            self.border_subtitle = ""
            return
        names = ", ".join(u if isinstance(u, str) else u.get("name", "?") for u in users)
        self.border_subtitle = f"在线({len(users)})"


# ═══════════════════════════════════════════════════════
#  CommandPanel — 指令面板（中栏）
# ═══════════════════════════════════════════════════════

class CommandPanel(Widget):
    """指令面板：纯终端输出"""

    def compose(self) -> ComposeResult:
        yield RichLog(id="cmd-log", wrap=True, highlight=True, markup=True, max_lines=1000)

    def add_message(self, text: str, update_last: bool = False):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        log.write(text)

    def clear(self):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        log.clear()

    def set_action_bar(self, text: str):
        self.border_subtitle = text

    def clear_action_bar(self):
        self.border_subtitle = ""


# ═══════════════════════════════════════════════════════
#  InfoPanel — 信息面板（右栏）
# ═══════════════════════════════════════════════════════

class InfoPanel(Widget):
    """信息面板：地图/状态/牌桌"""

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_location = "lobby"

    def compose(self) -> ComposeResult:
        yield RichLog(id="info-content", wrap=True, highlight=True, markup=True, max_lines=500)

    def set_location(self, location: str):
        self.current_location = location
        loc_display = {
            "lobby": "大厅",
            "mahjong": "麻将",
            "mahjong_room": "麻将房间",
            "mahjong_playing": "麻将对局",
            "chess": "象棋",
            "chess_room": "象棋房间",
            "chess_playing": "象棋对局",
            "jrpg": "JRPG",
        }
        self.border_title = loc_display.get(location, location)

    def update_map(self, map_data):
        content: RichLog = self.query_one("#info-content", RichLog)
        content.clear()
        lines = map_data if isinstance(map_data, list) else map_data.split("\n")
        for line in lines:
            content.write(line)

    def update_status(self, player_data: dict):
        name = player_data.get("name", "?")
        level = player_data.get("level", 1)
        gold = player_data.get("gold", 0)
        self.border_subtitle = f"{name} Lv.{level} {gold}G"

    def update_table(self, room_data: dict | None):
        content: RichLog = self.query_one("#info-content", RichLog)
        if room_data is None:
            content.clear()
            return

        # 判断游戏类型：chess 有 board/time_control 字段；mahjong game_type 为 east/south
        game_type = room_data.get("game_type", "")
        if game_type == "chess" or "board" in room_data or "time_control" in room_data:
            self._render_chess(room_data)
        else:
            self._render_mahjong_table(room_data)

    def _render_mahjong_table(self, room_data: dict):
        content: RichLog = self.query_one("#info-content", RichLog)
        content.clear()

        state = room_data.get("state", "waiting")
        positions = room_data.get("positions", room_data.get("players", []))
        room_id = room_data.get("room_id", "?")

        content.write(f"房间: {room_id}  状态: {state}")
        content.write("─" * 30)

        wind_names = ["东", "南", "西", "北"]
        for i, p in enumerate(positions):
            name = p.get("name", f"空位{i}")
            score = p.get("score", 25000)
            is_riichi = p.get("riichi", False)
            wind = wind_names[i] if i < 4 else "?"
            riichi_mark = " [立直]" if is_riichi else ""
            content.write(f"{wind} {name} {score}点{riichi_mark}")

            discards = p.get("discards", [])
            if discards:
                discard_str = " ".join(discards[-12:])
                content.write(f"  弃: {discard_str}")

            melds = p.get("melds", [])
            if melds:
                meld_strs = []
                for m in melds:
                    mtype = m.get("type", "?")
                    tiles = " ".join(m.get("tiles", []))
                    meld_strs.append(f"[{mtype} {tiles}]")
                content.write(f"  副: {' '.join(meld_strs)}")

        dora = room_data.get("dora_indicators", [])
        remaining = room_data.get("deck_remaining", room_data.get("remaining_tiles", "?"))
        content.write("─" * 30)
        if dora:
            content.write(f"宝牌指示: {' '.join(dora)}")
        content.write(f"剩余: {remaining}张")

    def _render_chess(self, room_data: dict):
        content: RichLog = self.query_one("#info-content", RichLog)
        content.clear()

        board = room_data.get("board")
        if not board:
            players = room_data.get("players", {})
            if isinstance(players, dict):
                for key, name in players.items():
                    colors = ["白", "黑"]
                    label = colors[int(key)] if str(key).isdigit() and int(key) < 2 else f"#{key}"
                    content.write(f"{label}: {name}")
            elif isinstance(players, list):
                for p in players:
                    name = p.get("name", "空位") if isinstance(p, dict) else str(p)
                    content.write(name)
            return

        pieces = {
            "K": "♔", "Q": "♕", "R": "♖", "B": "♗", "N": "♘", "P": "♙",
            "k": "♚", "q": "♛", "r": "♜", "b": "♝", "n": "♞", "p": "♟",
        }
        # board 可为 2D list（8×8）或 1D list（64）
        is_2d = isinstance(board[0], list)
        content.write("  a b c d e f g h")
        for rank in range(8, 0, -1):
            row = f"{rank} "
            for file in range(8):
                if is_2d:
                    cell = board[8 - rank][file]
                else:
                    cell = board[(8 - rank) * 8 + file]
                piece = cell if cell else "."
                row += pieces.get(piece, piece) + " "
            content.write(row)
        content.write("  a b c d e f g h")

    def update_hand(self, hand: list, drawn: str | None = None,
                    tenpai: object = None, need_discard: bool = False):
        content: RichLog = self.query_one("#info-content", RichLog)
        if not hand:
            return

        tiles = " ".join(hand)
        drawn_str = f" | [b]{drawn}[/b] ←摸" if drawn else ""
        content.write(f"手牌: {tiles}{drawn_str}")

        if tenpai:
            if isinstance(tenpai, list):
                waits = ", ".join(str(t) for t in tenpai)
                content.write(f"听: {waits}")
            elif isinstance(tenpai, dict):
                parts = []
                for tile, info in tenpai.items():
                    pts = info if isinstance(info, (int, str)) else ""
                    parts.append(f"{tile}({pts})")
                content.write(f"听: {', '.join(parts)}")

        if need_discard:
            content.write("[b]请出牌[/b] (d + 牌名)")

    def clear_hand(self):
        pass  # hand now renders inline in RichLog
