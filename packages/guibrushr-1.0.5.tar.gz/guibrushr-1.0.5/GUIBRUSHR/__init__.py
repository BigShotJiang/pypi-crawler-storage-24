"""
GUIBRUSHR - GUI for Bayesian Retrieval Using Spectroscopy at High Resolution.

A comprehensive Python package for atmospheric retrieval analysis
using spectroscopic data at both high and low resolution.
"""

__version__ = "1.0.5"
__author__ = "GUIBRUSHR Team"
__description__ = "GUI for Bayesian Retrieval Using Spectroscopy at High Resolution"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """Lazy import submodules when accessed (prevents circular imports)."""
    if name in {"GUI", "Retrieval", "General_Constants", "GUIBRUSHR"}:
        module = importlib.import_module(f"{__name__}.{name}")
        sys.modules[f"{__name__}.{name}"] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "GUI",
    "Retrieval",
    "General_Constants",
    "GUIBRUSHR",
]
