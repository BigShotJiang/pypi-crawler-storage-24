"""
Tab Analysis Module

Contains analysis tab components for data analysis and visualization.
"""

__version__ = "1.0.5"
__author__ = "GUIBRUSHR Team"
__description__ = "Tab Analysis Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import analysis components when accessed (prevents circular imports).
    """
    if name in {"Frame_Delete_Retrieval", "FrameCrossCorrelationRetrieval", "FrameCornerPlot", "Frame_Model_Plot"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "Frame_Delete_Retrieval",
    "FrameCrossCorrelationRetrieval",
    "FrameCornerPlot",
    "Frame_Model_Plot"
]
