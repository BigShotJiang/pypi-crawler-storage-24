"""
Tab Panels Module

Contains all tab panel components for organized data input and analysis.
"""

__version__ = "1.0.5"
__author__ = "GUIBRUSHR Team"
__description__ = "Tab Panels Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import tab panel components when accessed (prevents circular imports).
    """
    if name in {
        'Frame_Retrieval_Analysis',
        'FrameCCNIght',
        'FrameTellRem',
        'Frame_Parameters',
        'FramePath',
        'FrameManualModel',
        'FrameGenerationHRData',
        'FrameDBInteractions'
    }:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'Frame_Retrieval_Analysis',
    'FrameCCNIght',
    'FrameTellRem',
    'Frame_Parameters',
    'FramePath',
    'FrameManualModel',
    'FrameGenerationHRData',
    'FrameDBInteractions'
]