"""
Retrieval Module for GUIBRUSHR

Contains all retrieval algorithms and model calculation components.
"""

__version__ = "1.0.5"
__author__ = "GUIBRUSHR Team"
__description__ = "Retrieval Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import retrieval submodules when accessed (prevents circular imports).
    """
    if name in {"ExofastMCMC", "ModelCalculation"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "ExofastMCMC",
    "ModelCalculation"
]
