"""
Retrieval class for astronomical data processing and model calculations.

This module contains the Retrieval class which handles the initialization
and configuration of retrieval parameters for astronomical observations.
"""


class Retrieval:
    """
    A class to handle retrieval parameters and configuration for astronomical data processing.
    
    This class manages various parameters related to atmospheric retrieval models,
    including chemistry settings, temperature formatting, telluric removal methods,
    and output configurations.
    """
    
    def __init__(
        self,
        scale,
        chemistry=None,
        ecc_opi=None,
        tell_rm_method=None,
        model_reprocessing=None,
        format_temperature=None,
        table_output_file=None,
        maxsteps=None,
        order_sel=None,
        id_process=None,
        path_results=None,
        retrieval_model=None,
        manual_model_obj=None,
        total_nights=0,
        total_hr_instruments=0,
        standardize_PCA="From pkl",
        mask_phase_enabled=False,
        mask_night_index=None,
        min_phase=None,
        max_phase=None,
        mask_inside_range=False
    ):
        """
        Initialize the Retrieval object with configuration parameters.
        
        Args:
            scale: Scale vector parameters for the retrieval process
            chemistry: Chemistry configuration for atmospheric modeling
            ecc_opi: Eccentricity and orbital parameters information
            tell_rm_method: Method for telluric removal
            model_reprocessing: Model reprocessing configuration
            format_temperature: Temperature formatting settings
            table_output_file: Output file path for tabulated results
            maxsteps: Maximum number of steps for the retrieval algorithm
            order_sel: Order selection parameters
            id_process: Process identifier
            path_results: Path where results will be stored
            retrieval_model: The retrieval model to be used
            manual_model_obj: Manual model object containing pre-configured parameters
            standardize_PCA: PCA standardization mode (default: "From pkl")
            total_nights: Total number of observation nights (default: 0)
            total_hr_instruments: Total number of HR instruments used (default: 0)
            mask_phase_enabled: Flag indicating whether to apply a mask to the phase data (default: False)
            mask_night_index: Index of the night to be masked (default: None)
            min_phase: Minimum phase value to be masked (default: None)
            max_phase: Maximum phase value to be masked (default: None)
            mask_inside_range: Flag indicating whether to mask data inside the specified phase range (default: False)
        """
        # If a manual model object is provided, extract all parameters from it
        # This allows for easy parameter transfer from existing model configurations
        if manual_model_obj is not None:
            model_reprocessing = manual_model_obj.model_reprocessing
            standardize_PCA = manual_model_obj.standardize_PCA
            format_temperature = manual_model_obj.format_temperature
            chemistry = manual_model_obj.chemistry
            ecc_opi = manual_model_obj.ecc_opi
            tell_rm_method = manual_model_obj.tell_rm_method
            table_output_file = manual_model_obj.table_output_file
            order_sel = manual_model_obj.order_sel
            maxsteps = manual_model_obj.maxsteps
            id_process = manual_model_obj.id_process
            path_results = manual_model_obj.path_results
            retrieval_model = manual_model_obj.retrieval_model
        
        # Assign all parameters to instance variables
        # Model processing and formatting settings
        self.model_reprocessing = model_reprocessing
        self.standardize_PCA = standardize_PCA
        self.format_temperature = format_temperature
        
        # Atmospheric and orbital parameters
        self.chemistry = chemistry
        self.eccentricity = ecc_opi  # Note: renamed from ecc_opi for clarity
        
        # Processing methods and configurations
        self.tell_rm_method = tell_rm_method
        self.table_output_file = table_output_file
        self.scale_vector_params = scale
        self.order_sel = order_sel
        
        # Algorithm and process control parameters
        self.maxsteps = maxsteps
        self.id_process = id_process
        
        # Output and model settings
        self.path_results = path_results
        self.retrieval_model = retrieval_model
        
        # Observation statistics
        self.total_nights = total_nights
        self.total_hr_instruments = total_hr_instruments

        self.mask_phase_enabled = mask_phase_enabled
        self.mask_night_index = mask_night_index
        self.min_phase = min_phase
        self.max_phase = max_phase
        self.mask_inside_range = mask_inside_range
