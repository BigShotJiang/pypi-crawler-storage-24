# -*- coding: utf-8 -*-
"""
@author:XuMing(xuming624@qq.com)
@description: CLI entry point for TreeSearch.

Default usage (lazy index + search):
    treesearch "How does auth work?" src/ docs/*.md
    treesearch "FTS5 search" treesearch/

Advanced subcommands:
    treesearch index --paths src/ docs/ --force
    treesearch search --db ./indexes/index.db --query "auth"
"""
import argparse
import asyncio
import logging
import os
import sys
import time

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Default command: lazy search (the simplest way to use TreeSearch)
# ---------------------------------------------------------------------------

def _run_default(args) -> None:
    """Lazy index + search: the simplest workflow."""
    from treesearch.treesearch import TreeSearch

    paths = args.paths
    query = args.query
    db_path = args.db or "./index.db"
    max_nodes = args.max_nodes

    if not paths:
        print("Error: no paths specified. Usage: treesearch \"query\" path1 [path2 ...]",
              file=sys.stderr)
        sys.exit(1)

    start_time = time.time()

    # TreeSearch handles everything: directory discovery, lazy indexing, search
    ts = TreeSearch(*paths, db_path=db_path)
    result = ts.search(query, max_nodes_per_doc=max_nodes)
    elapsed = time.time() - start_time

    if not result["documents"] or not result["flat_nodes"]:
        print(f"No results found for: {query}")
        return

    total_nodes = sum(len(d["nodes"]) for d in result["documents"])
    print(f"Found {total_nodes} result(s) in {len(result['documents'])} doc(s) ({elapsed:.1f}s)\n")

    for doc_result in result["documents"]:
        doc_name = doc_result["doc_name"]
        for node in doc_result["nodes"]:
            score = node.get("score", 0)
            title = node.get("title", "")
            line_start = node.get("line_start")
            line_end = node.get("line_end")
            text = node.get("text", "")

            # Header: [score] doc_name > title  (lines X-Y)
            loc = f"  (lines {line_start}-{line_end})" if line_start and line_end else ""
            print(f"[{score:.2f}] {doc_name} > {title}{loc}")

            # Text content
            if text:
                # Show up to 500 chars, preserve first few lines for readability
                preview = text[:500]
                if len(text) > 500:
                    preview += "..."
                for line in preview.split("\n"):
                    print(f"  {line}")
            print()


# ---------------------------------------------------------------------------
# Subcommand: index
# ---------------------------------------------------------------------------

def _add_index_args(sub: argparse.ArgumentParser) -> None:
    sub.add_argument("--paths", nargs="+", required=True,
                     help="File paths, glob patterns, or directories (e.g. src/ 'docs/*.md')")
    sub.add_argument("-o", "--output_dir", type=str, default="./indexes",
                     help="Output directory for database file (default: ./indexes)")
    sub.add_argument("--db", type=str, default="",
                     help="Path to SQLite database file (default: {output_dir}/index.db)")
    sub.add_argument("--no-summary", action="store_true", help="Skip node summary generation")
    sub.add_argument("--add-description", action="store_true", help="Generate doc description")
    sub.add_argument("--add-text", action="store_true", help="Include node text in output")
    sub.add_argument("--no-node-id", action="store_true", help="Skip node ID assignment")
    sub.add_argument("--thinning", action="store_true", help="Apply tree thinning")
    sub.add_argument("--thinning-threshold", type=int, default=5000,
                     help="Min token threshold for thinning (default: 5000)")
    sub.add_argument("--summary-threshold", type=int, default=200,
                     help="Token threshold for summary generation (default: 200)")
    sub.add_argument("--max-concurrency", type=int, default=5,
                     help="Max concurrent indexing tasks (default: 5)")
    sub.add_argument("--force", action="store_true",
                     help="Force re-index even if files unchanged")


async def _run_index(args) -> None:
    from treesearch.indexer import build_index
    from treesearch.tree import print_toc

    start_time = time.time()
    print(f"Indexing {len(args.paths)} path(s)...")

    results = await build_index(
        paths=args.paths,
        output_dir=args.output_dir,
        db_path=args.db,
        if_add_node_summary=not args.no_summary,
        if_add_doc_description=args.add_description,
        if_add_node_text=args.add_text,
        if_add_node_id=not args.no_node_id,
        if_thinning=args.thinning,
        min_token_threshold=args.thinning_threshold,
        summary_token_threshold=args.summary_threshold,
        max_concurrency=args.max_concurrency,
        force=args.force,
    )

    db_path = args.db or os.path.join(args.output_dir, "index.db")
    elapsed = time.time() - start_time
    print(f"\nIndexed {len(results)} file(s) to {db_path} ({elapsed:.1f}s)")
    for doc in results:
        print(f"  - {doc.doc_name}")
        print(f"    TOC:")
        print_toc(doc.structure)


# ---------------------------------------------------------------------------
# Subcommand: search (over pre-built index)
# ---------------------------------------------------------------------------

def _add_search_args(sub: argparse.ArgumentParser) -> None:
    sub.add_argument("--index_dir", type=str, default="./indexes",
                     help="Directory containing the database file (default: ./indexes)")
    sub.add_argument("--db", type=str, default="",
                     help="Path to SQLite database file (default: {index_dir}/index.db)")
    sub.add_argument("--query", type=str, required=True,
                     help="Search query")
    sub.add_argument("--top-k-docs", type=int, default=3,
                     help="Max documents to search (default: 3)")
    sub.add_argument("--max-nodes", type=int, default=5,
                     help="Max result nodes per document (default: 5)")


def _load_documents_from_dir(index_dir: str, db: str = ""):
    """Load all documents from a database file."""
    from treesearch.tree import Document, load_documents

    db_path = db or os.path.join(index_dir, "index.db")
    if not os.path.isfile(db_path):
        print(f"Database file not found: {db_path}", file=sys.stderr)
        sys.exit(1)
    documents = load_documents(db_path)
    if not documents:
        print(f"No documents found in database: {db_path}", file=sys.stderr)
        sys.exit(1)
    return documents


async def _run_search(args) -> None:
    from treesearch.search import search

    documents = _load_documents_from_dir(args.index_dir, db=args.db)
    print(f"Loaded {len(documents)} document(s)\n")

    print(f"Query: {args.query}")
    print("---")

    start_time = time.time()
    result = await search(
        query=args.query,
        documents=documents,
        top_k_docs=args.top_k_docs,
        max_nodes_per_doc=args.max_nodes,
    )
    elapsed = time.time() - start_time

    if not result["documents"]:
        print("\nNo relevant results found.")
        return

    total_nodes = sum(len(d["nodes"]) for d in result["documents"])
    print(f"\nFound {total_nodes} result(s) in {len(result['documents'])} doc(s) ({elapsed:.1f}s)\n")

    for doc_result in result["documents"]:
        doc_name = doc_result["doc_name"]
        for node in doc_result["nodes"]:
            score = node.get("score", 0)
            title = node.get("title", "")
            line_start = node.get("line_start")
            line_end = node.get("line_end")
            text = node.get("text", "")

            loc = f"  (lines {line_start}-{line_end})" if line_start and line_end else ""
            print(f"[{score:.2f}] {doc_name} > {title}{loc}")

            if text:
                preview = text[:500]
                if len(text) > 500:
                    preview += "..."
                for line in preview.split("\n"):
                    print(f"  {line}")
            print()


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

_SUBCOMMANDS = {"index", "search"}


def _build_default_parser() -> argparse.ArgumentParser:
    """Parser for default mode: treesearch "query" path1 path2 ..."""
    p = argparse.ArgumentParser(
        prog="treesearch",
        description=(
            "TreeSearch: Structure-aware document retrieval.\n\n"
            "Quick usage:\n"
            '  treesearch "search query" src/ docs/\n'
            '  treesearch "How does auth work?" project/\n\n'
            "Advanced:\n"
            "  treesearch index --paths src/ docs/ --force\n"
            "  treesearch search --db ./index.db --query \"auth\"\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")
    p.add_argument("query", nargs="?", default=None,
                   help="Search query")
    p.add_argument("paths", nargs="*", default=[],
                   help="Files, directories, or glob patterns to search")
    p.add_argument("--db", type=str, default="",
                   help="Path to SQLite database file (default: ./index.db)")
    p.add_argument("--max-nodes", type=int, default=5,
                   help="Max result nodes per document (default: 5)")
    return p


def _build_index_parser() -> argparse.ArgumentParser:
    """Parser for: treesearch index --paths ..."""
    p = argparse.ArgumentParser(prog="treesearch index")
    p.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")
    _add_index_args(p)
    return p


def _build_search_parser() -> argparse.ArgumentParser:
    """Parser for: treesearch search --query ..."""
    p = argparse.ArgumentParser(prog="treesearch search")
    p.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")
    _add_search_args(p)
    return p


def _detect_subcommand(argv: list[str]) -> str | None:
    """Detect if argv contains a subcommand (index/search) as the first non-flag arg."""
    for arg in argv:
        if arg.startswith("-"):
            continue
        if arg in _SUBCOMMANDS:
            return arg
        break  # first positional arg is not a subcommand
    return None


def main(argv: list[str] | None = None):
    if argv is None:
        argv = sys.argv[1:]

    subcmd = _detect_subcommand(argv)

    if subcmd == "index":
        # Strip the subcommand word from argv
        idx_argv = []
        found = False
        for a in argv:
            if not found and a == "index":
                found = True
                continue
            idx_argv.append(a)
        parser = _build_index_parser()
        args = parser.parse_args(idx_argv)
        level = logging.DEBUG if args.verbose else logging.WARNING
        logging.basicConfig(level=level, format="%(levelname)s - %(name)s - %(message)s")
        asyncio.run(_run_index(args))

    elif subcmd == "search":
        sch_argv = []
        found = False
        for a in argv:
            if not found and a == "search":
                found = True
                continue
            sch_argv.append(a)
        parser = _build_search_parser()
        args = parser.parse_args(sch_argv)
        level = logging.DEBUG if args.verbose else logging.WARNING
        logging.basicConfig(level=level, format="%(levelname)s - %(name)s - %(message)s")
        asyncio.run(_run_search(args))

    else:
        parser = _build_default_parser()
        args = parser.parse_args(argv)
        level = logging.DEBUG if args.verbose else logging.WARNING
        logging.basicConfig(level=level, format="%(levelname)s - %(name)s - %(message)s")
        if args.query:
            _run_default(args)
        else:
            parser.print_help()
            sys.exit(0)


if __name__ == "__main__":
    main()
