import secrets
import string
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("password")


@mcp.tool()
def gen_password(length: int = 16, use_upper: bool = True, use_lower: bool = True, use_digits: bool = True, use_symbols: bool = True) -> str:
    """生成安全的随机密码。"""
    if length < 4 or length > 128:
        return "密码长度应在 4 到 128 之间"
        
    chars = ""
    req_chars = []
    
    if use_upper:
        chars += string.ascii_uppercase
        req_chars.append(secrets.choice(string.ascii_uppercase))
    if use_lower:
        chars += string.ascii_lowercase
        req_chars.append(secrets.choice(string.ascii_lowercase))
    if use_digits:
        chars += string.digits
        req_chars.append(secrets.choice(string.digits))
    if use_symbols:
        symbols = "!@#$%^&*()_+-=[]{}|;:,.<>?"
        chars += symbols
        req_chars.append(secrets.choice(symbols))
        
    if not chars:
        return "错误: 至少需要选择一种字符类型"
        
    # 填充剩余长度
    rem_length = length - len(req_chars)
    for _ in range(rem_length):
        req_chars.append(secrets.choice(chars))
        
    # 打乱顺序
    secrets.SystemRandom().shuffle(req_chars)
    return "".join(req_chars)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
