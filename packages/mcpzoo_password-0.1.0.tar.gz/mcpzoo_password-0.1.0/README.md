# mcpzoo-password

> 密码生成 — 生成安全的随机密码

## Installation

```bash
uvx mcpzoo-password
```

## uvx JSON

```json
{
  "mcpServers": {
    "password": {
      "args": ["mcpzoo-password"],
      "command": "uvx"
    }
  }
}
```
