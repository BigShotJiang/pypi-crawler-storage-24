# luckyget
The all-in-one dev CLI tool for Termux.
```bash
pip install luckyget
```
