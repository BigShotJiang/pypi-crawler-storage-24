from __future__ import annotations

import re
from datetime import datetime

from ..models import (
    Hand, Card, PlayerSeat, Action, ActionType,
    Street, ShowdownEntry, Platform,
)
from .parser import Parser


class WinamaxParser(Parser):

    _RE_HEADER = re.compile(
        r"^Winamax Poker - .+? - HandId: #([\d-]+) - Holdem no limit "
        r"\((\d+\.?\d*)€/(\d+\.?\d*)€\) - (\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}) UTC",
        re.MULTILINE,
    )
    _RE_TABLE = re.compile(
        r"^Table: '(.+?)' (\d+)-max .+? Seat #(\d+) is the button",
        re.MULTILINE,
    )
    _RE_SEAT = re.compile(
        r"^Seat (\d+): (.+?) \((\d+\.?\d*)€\)", re.MULTILINE
    )
    _RE_POST_SB = re.compile(
        r"^(.+?) posts small blind (\d+\.?\d*)€", re.MULTILINE
    )
    _RE_POST_BB = re.compile(
        r"^(.+?) posts big blind (\d+\.?\d*)€", re.MULTILINE
    )
    _RE_DEALT_TO = re.compile(r"^Dealt to (.+?) \[(.+?)\]", re.MULTILINE)

    _RE_FOLD = re.compile(r"^(.+?) folds\s*$", re.MULTILINE)
    _RE_CHECK = re.compile(r"^(.+?) checks\s*$", re.MULTILINE)
    _RE_CALL = re.compile(
        r"^(.+?) calls (\d+\.?\d*)€(?: and is all-in)?", re.MULTILINE
    )
    _RE_BET = re.compile(
        r"^(.+?) bets (\d+\.?\d*)€(?: and is all-in)?", re.MULTILINE
    )
    _RE_RAISE = re.compile(
        r"^(.+?) raises (\d+\.?\d*)€ to (\d+\.?\d*)€(?: and is all-in)?",
        re.MULTILINE,
    )
    _RE_COLLECTED = re.compile(
        r"^(.+?) collected (\d+\.?\d*)€ from (?:main |side )?pot",
        re.MULTILINE,
    )
    _RE_SHOWS = re.compile(
        r"^(.+?) shows \[(.+?)\] \((.+?)\)", re.MULTILINE
    )

    _RE_FLOP = re.compile(r"^\*\*\* FLOP \*\*\* \[(.+?)\]", re.MULTILINE)
    _RE_TURN = re.compile(
        r"^\*\*\* TURN \*\*\* \[.+?\]\[(.+?)\]", re.MULTILINE
    )
    _RE_RIVER = re.compile(
        r"^\*\*\* RIVER \*\*\* \[.+?\]\[(.+?)\]", re.MULTILINE
    )
    _RE_POT_RAKE = re.compile(
        r"^Total pot (\d+\.?\d*)€ \| (?:Rake (\d+\.?\d*)€|No rake)",
        re.MULTILINE,
    )
    _RE_BOARD = re.compile(r"^Board: \[(.+?)\]", re.MULTILINE)

    _SECTION_MARKERS = [
        "*** ANTE/BLINDS ***",
        "*** PRE-FLOP ***",
        "*** FLOP ***",
        "*** TURN ***",
        "*** RIVER ***",
        "*** SHOW DOWN ***",
        "*** SUMMARY ***",
    ]

    # ────────────────────────────────────────────────────────────────

    def split_hands(self, content: str) -> list[str]:
        parts = re.split(r"\n\n(?=Winamax Poker)", content)
        return [p.strip() for p in parts if p.strip()]

    def parse_hand(self, text: str) -> Hand:
        # ── 1. Header ───────────────────────────────────────────────
        m = self._RE_HEADER.search(text)
        if not m:
            raise ValueError("No Winamax header found")
        hand_id = m.group(1)
        sb = float(m.group(2))
        bb = float(m.group(3))
        dt = datetime.strptime(m.group(4), "%Y/%m/%d %H:%M:%S")

        # ── 2. Table ────────────────────────────────────────────────
        m_table = self._RE_TABLE.search(text)
        table_name = m_table.group(1) if m_table else ""
        max_players = int(m_table.group(2)) if m_table else 6
        button_seat = int(m_table.group(3)) if m_table else 1

        # ── 3. Seats ────────────────────────────────────────────────
        players: list[PlayerSeat] = []
        for sm in self._RE_SEAT.finditer(text):
            players.append(
                PlayerSeat(
                    seat=int(sm.group(1)),
                    name=sm.group(2).strip(),
                    stack=float(sm.group(3)),
                )
            )

        # ── 4. Section boundaries ──────────────────────────────────
        sections = self._split_sections(text)

        # ── 5. Blinds (in ANTE/BLINDS section) ────────────────────
        actions: list[Action] = []
        ante_section = sections.get("ante_blinds", "")
        for sm_b in self._RE_POST_SB.finditer(ante_section):
            actions.append(Action(sm_b.group(1).strip(), ActionType.POST_SB,
                                  float(sm_b.group(2)), Street.PREFLOP))
        for bm in self._RE_POST_BB.finditer(ante_section):
            actions.append(Action(bm.group(1).strip(), ActionType.POST_BB,
                                  float(bm.group(2)), Street.PREFLOP))

        # ── 6. Hero (Dealt to is in the ante/blinds section) ──────
        hero = None
        hero_cards = None
        m_dealt = self._RE_DEALT_TO.search(text)
        if m_dealt:
            hero = m_dealt.group(1).strip()
            hero_cards = self._parse_cards(m_dealt.group(2))
            for p in players:
                if p.name == hero:
                    p.hole_cards = hero_cards

        # ── 7. Actions per street ──────────────────────────────────
        street_map = {
            "preflop": Street.PREFLOP,
            "flop": Street.FLOP,
            "turn": Street.TURN,
            "river": Street.RIVER,
        }
        for street_name, street_enum in street_map.items():
            section_text = sections.get(street_name, "")
            if not section_text:
                continue
            for line in section_text.split("\n"):
                action = self._parse_action_line(line, street_enum)
                if action:
                    actions.append(action)

        # Showdown section may have collected lines
        sd_text = sections.get("showdown", "")
        for line in sd_text.split("\n"):
            action = self._parse_action_line(line, Street.RIVER)
            if action:
                actions.append(action)

        # ── 8. Board ───────────────────────────────────────────────
        board: list[Card] = []
        # Prefer authoritative board from summary
        m_board = self._RE_BOARD.search(text)
        if m_board:
            board = self._parse_cards(m_board.group(1))
        else:
            m_flop = self._RE_FLOP.search(text)
            if m_flop:
                board = self._parse_cards(m_flop.group(1))
            m_turn = self._RE_TURN.search(text)
            if m_turn:
                board.append(self._parse_card(m_turn.group(1)))
            m_river = self._RE_RIVER.search(text)
            if m_river:
                board.append(self._parse_card(m_river.group(1)))

        # ── 9. Showdown & Winners ─────────────────────────────────
        showdown: list[ShowdownEntry] = []
        winners: dict[str, float] = {}

        for cm in self._RE_COLLECTED.finditer(text):
            name = cm.group(1).strip()
            amt = float(cm.group(2))
            winners[name] = winners.get(name, 0.0) + amt

        for sm_show in self._RE_SHOWS.finditer(text):
            name = sm_show.group(1).strip()
            cards = self._parse_cards(sm_show.group(2))
            desc = sm_show.group(3).strip()
            won = name in winners
            amt = winners.get(name, 0.0)
            showdown.append(ShowdownEntry(name, cards, desc, won, amt))
            for p in players:
                if p.name == name:
                    p.hole_cards = cards

        # ── 10. Summary ───────────────────────────────────────────
        pot = 0.0
        rake = 0.0
        m_pot = self._RE_POT_RAKE.search(text)
        if m_pot:
            pot = float(m_pot.group(1))
            rake = float(m_pot.group(2)) if m_pot.group(2) else 0.0

        return Hand(
            hand_id=hand_id,
            platform=Platform.WINAMAX,
            game_type="No Limit Hold'em",
            is_zoom=False,
            is_tournament=False,
            tournament_id=None,
            stakes=(sb, bb),
            datetime=dt,
            table_name=table_name,
            max_players=max_players,
            button_seat=button_seat,
            players=players,
            hero=hero,
            hero_cards=hero_cards,
            actions=actions,
            board=board,
            pot=pot,
            rake=rake,
            showdown=showdown,
            winners=winners,
            currency="EUR",
        )

    # ── Helpers ─────────────────────────────────────────────────────

    def _split_sections(self, text: str) -> dict[str, str]:
        positions: list[tuple[str, int]] = []
        for marker in self._SECTION_MARKERS:
            idx = text.find(marker)
            if idx != -1:
                positions.append((marker, idx))
        positions.sort(key=lambda x: x[1])

        sections: dict[str, str] = {}
        if positions:
            sections["header"] = text[: positions[0][1]]

        for i, (marker, start) in enumerate(positions):
            end = positions[i + 1][1] if i + 1 < len(positions) else len(text)
            content = text[start + len(marker) : end]
            if "ANTE/BLINDS" in marker:
                sections["ante_blinds"] = content
            elif "PRE-FLOP" in marker:
                sections["preflop"] = content
            elif "FLOP" in marker:
                sections["flop"] = content
            elif "TURN" in marker:
                sections["turn"] = content
            elif "RIVER" in marker:
                sections["river"] = content
            elif "SHOW DOWN" in marker:
                sections["showdown"] = content
            elif "SUMMARY" in marker:
                sections["summary"] = content
        return sections

    def _parse_action_line(self, line: str, street: Street) -> Action | None:
        line = line.strip()
        if not line or line.startswith("***") or line.startswith("Dealt to"):
            return None

        is_allin = "and is all-in" in line

        m = self._RE_FOLD.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.FOLD, 0.0, street)

        m = self._RE_CHECK.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.CHECK, 0.0, street)

        m = self._RE_RAISE.match(line)
        if m:
            atype = ActionType.ALL_IN if is_allin else ActionType.RAISE
            return Action(m.group(1).strip(), atype,
                          float(m.group(3)), street)  # total amount

        m = self._RE_CALL.match(line)
        if m:
            atype = ActionType.ALL_IN if is_allin else ActionType.CALL
            return Action(m.group(1).strip(), atype,
                          float(m.group(2)), street)

        m = self._RE_BET.match(line)
        if m:
            atype = ActionType.ALL_IN if is_allin else ActionType.BET
            return Action(m.group(1).strip(), atype,
                          float(m.group(2)), street)

        m = self._RE_COLLECTED.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.COLLECT,
                          float(m.group(2)), street)

        return None
