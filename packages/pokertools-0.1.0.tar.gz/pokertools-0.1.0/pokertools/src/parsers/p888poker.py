from __future__ import annotations

import re
from datetime import datetime

from ..models import (
    Hand, Card, PlayerSeat, Action, ActionType,
    Street, ShowdownEntry, Platform,
)
from .parser import Parser


# 888poker Spain uses Spanish card notation in some files:
#   Ranks:  D = 10 (Diez)          — all others same as English
#   Suits:  p = spades (picas), t = clubs (tréboles),
#           d = diamonds (diamantes), c = hearts (corazones)
_SPANISH_RANK_MAP = {"D": "T"}
_SPANISH_SUIT_MAP = {"p": "s", "t": "c", "c": "h"}  # 'd' stays 'd'


def _convert_888_card(s: str) -> Card:
    """Parse a card string that might use Spanish or standard notation."""
    s = s.strip()
    if len(s) < 2:
        raise ValueError(f"Invalid card string: {s!r}")
    rank = s[0].upper()
    suit = s[1].lower()
    rank = _SPANISH_RANK_MAP.get(rank, rank)
    suit = _SPANISH_SUIT_MAP.get(suit, suit)
    return Card(rank=rank, suit=suit)


def _parse_888_cards(s: str) -> list[Card]:
    """Parse cards from 888poker format like '[ Ah, 7d ]' (comma-separated)."""
    s = s.strip().strip("[]").strip()
    if not s:
        return []
    tokens = [t.strip() for t in s.split(",")]
    return [_convert_888_card(t) for t in tokens if t]


class Poker888Parser(Parser):

    _RE_GAME_NO = re.compile(r"^#Game No : (\d+)", re.MULTILINE)
    _RE_STAKES = re.compile(
        r"^([\d.]+)/([\d.]+) Blinds No Limit Holdem - \*\*\* (\d+) (\d+) (\d{4}) (\d{2}:\d{2}:\d{2})",
        re.MULTILINE,
    )
    _RE_TOURNAMENT = re.compile(
        r"^Tournament #(\d+) .+? - Table #(\d+) (\d+) Max", re.MULTILINE
    )
    _RE_BUTTON = re.compile(r"^Seat (\d+) is the button", re.MULTILINE)
    _RE_SEAT = re.compile(
        r"^Seat (\d+): (.*?) \( ([\d,.]+) \)", re.MULTILINE
    )
    _RE_ANTE = re.compile(r"^(.+?) posts ante \[([\d,.]+)\]", re.MULTILINE)
    _RE_POST_SB = re.compile(
        r"^(.+?) posts small blind \[([\d,.]+)\]", re.MULTILINE
    )
    _RE_POST_BB = re.compile(
        r"^(.+?) posts big blind \[([\d,.]+)\]", re.MULTILINE
    )
    _RE_DEALT_TO = re.compile(r"^Dealt to (.+?) \[ (.+?) \]", re.MULTILINE)

    # Actions — no colon before verb in 888
    _RE_FOLD = re.compile(r"^(.+?) folds\s*$", re.MULTILINE)
    _RE_CHECK = re.compile(r"^(.+?) checks\s*$", re.MULTILINE)
    _RE_CALL = re.compile(r"^(.+?) calls \[([\d,.]+)\]", re.MULTILINE)
    _RE_BET = re.compile(r"^(.+?) bets \[([\d,.]+)\]", re.MULTILINE)
    _RE_RAISE = re.compile(r"^(.+?) raises \[([\d,.]+)\]", re.MULTILINE)
    _RE_ALLIN = re.compile(r"^(.+?) all-?[Ii]n \[([\d,.]+)\]", re.MULTILINE)
    _RE_COLLECTED = re.compile(
        r"^(?:Primero runout |Segundo runout )?(.*?) ?collected \[ ([\d,.]+) \]",
        re.MULTILINE,
    )

    _RE_FLOP = re.compile(r"^\*\* Dealing flop \*\* \[ (.+?) \]", re.MULTILINE)
    _RE_TURN = re.compile(r"^\*\* Dealing turn \*\* \[ (.+?) \]", re.MULTILINE)
    _RE_RIVER = re.compile(r"^\*\* Dealing river \*\* \[ (.+?) \]", re.MULTILINE)

    _RE_SHOWS = re.compile(r"^(.+?) shows \[ (.+?) \]", re.MULTILINE)
    _RE_MUCKS = re.compile(r"^(.+?) mucks \[ (.+?) \]", re.MULTILINE)

    # ────────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_chip_amount(s: str) -> float:
        """Parse 888poker chip amounts where '.' can be a thousands separator.

        888poker uses European notation: 5.863 = 5863, 1.089.050 = 1089050.
        If the dot-separated groups each have exactly 3 digits, dots are thousands seps.
        """
        s = s.strip()
        if not s:
            return 0.0
        # Multiple dots → always thousands separators
        if s.count(".") > 1:
            return float(s.replace(".", ""))
        # Single dot with exactly 3 trailing digits → thousands separator
        if re.match(r"^\d+\.\d{3}$", s):
            return float(s.replace(".", ""))
        return float(s)

    def split_hands(self, content: str) -> list[str]:
        parts = re.split(r"\n{3,}", content)
        return [p.strip() for p in parts if p.strip() and "#Game No :" in p]

    def parse_hand(self, text: str) -> Hand:
        # ── 1. Game number ─────────────────────────────────────────
        m = self._RE_GAME_NO.search(text)
        if not m:
            raise ValueError("No 888poker game number found")
        hand_id = m.group(1)

        # ── 2. Stakes & datetime ───────────────────────────────────
        m_stakes = self._RE_STAKES.search(text)
        if not m_stakes:
            raise ValueError("No stakes/date line found")
        sb = float(m_stakes.group(1))
        bb = float(m_stakes.group(2))
        dt = datetime.strptime(
            f"{m_stakes.group(3)} {m_stakes.group(4)} {m_stakes.group(5)} {m_stakes.group(6)}",
            "%d %m %Y %H:%M:%S",
        )

        # ── 3. Tournament ─────────────────────────────────────────
        m_tourn = self._RE_TOURNAMENT.search(text)
        is_tournament = m_tourn is not None
        tournament_id = m_tourn.group(1) if m_tourn else None
        table_number = m_tourn.group(2) if m_tourn else "1"
        max_players = int(m_tourn.group(3)) if m_tourn else 6
        table_name = (
            f"Tournament #{tournament_id} Table #{table_number}"
            if is_tournament
            else f"Table #{table_number}"
        )

        # ── 4. Button ──────────────────────────────────────────────
        m_btn = self._RE_BUTTON.search(text)
        button_seat = int(m_btn.group(1)) if m_btn else 1

        # ── 5. Seats ───────────────────────────────────────────────
        players: list[PlayerSeat] = []
        for sm in self._RE_SEAT.finditer(text):
            players.append(
                PlayerSeat(
                    seat=int(sm.group(1)),
                    name=sm.group(2).strip(),
                    stack=self._parse_chip_amount(sm.group(3)),
                )
            )

        # ── 6. Section boundaries ──────────────────────────────────
        sections = self._split_sections(text)

        # ── 7. Antes and blinds ────────────────────────────────────
        actions: list[Action] = []
        pre = sections.get("pre", "")
        for am in self._RE_ANTE.finditer(pre):
            actions.append(Action(am.group(1).strip(), ActionType.POST_ANTE,
                                  self._parse_chip_amount(am.group(2)), Street.PREFLOP))
        for sm_b in self._RE_POST_SB.finditer(pre):
            actions.append(Action(sm_b.group(1).strip(), ActionType.POST_SB,
                                  self._parse_chip_amount(sm_b.group(2)), Street.PREFLOP))
        for bm in self._RE_POST_BB.finditer(pre):
            actions.append(Action(bm.group(1).strip(), ActionType.POST_BB,
                                  self._parse_chip_amount(bm.group(2)), Street.PREFLOP))

        # ── 8. Actions per street ──────────────────────────────────
        street_map = {
            "preflop": Street.PREFLOP,
            "flop": Street.FLOP,
            "turn": Street.TURN,
            "river": Street.RIVER,
        }
        for street_name, street_enum in street_map.items():
            section_text = sections.get(street_name, "")
            if not section_text:
                continue
            for line in section_text.split("\n"):
                action = self._parse_action_line(line, street_enum)
                if action:
                    actions.append(action)

        # ── 9. Hero ────────────────────────────────────────────────
        hero = None
        hero_cards = None
        m_dealt = self._RE_DEALT_TO.search(text)
        if m_dealt:
            hero = m_dealt.group(1).strip()
            hero_cards = _parse_888_cards(m_dealt.group(2))
            for p in players:
                if p.name == hero:
                    p.hole_cards = hero_cards

        # ── 10. Board ──────────────────────────────────────────────
        board: list[Card] = []
        m_flop = self._RE_FLOP.search(text)
        if m_flop:
            board = _parse_888_cards(m_flop.group(1))
        m_turn = self._RE_TURN.search(text)
        if m_turn:
            board.append(_convert_888_card(m_turn.group(1).strip()))
        m_river = self._RE_RIVER.search(text)
        if m_river:
            board.append(_convert_888_card(m_river.group(1).strip()))

        # ── 11. Showdown / Winners ─────────────────────────────────
        showdown: list[ShowdownEntry] = []
        winners: dict[str, float] = {}

        for cm in self._RE_COLLECTED.finditer(text):
            name = cm.group(1).strip()
            amt = self._parse_chip_amount(cm.group(2))
            winners[name] = winners.get(name, 0.0) + amt

        for sm_show in self._RE_SHOWS.finditer(text):
            name = sm_show.group(1).strip()
            cards = _parse_888_cards(sm_show.group(2))
            won = name in winners
            amt = winners.get(name, 0.0)
            showdown.append(ShowdownEntry(name, cards, "", won, amt))
            for p in players:
                if p.name == name:
                    p.hole_cards = cards

        for mm in self._RE_MUCKS.finditer(text):
            name = mm.group(1).strip()
            cards = _parse_888_cards(mm.group(2))
            showdown.append(ShowdownEntry(name, cards, "", False, 0.0))
            for p in players:
                if p.name == name:
                    p.hole_cards = cards

        # 888poker doesn't provide pot/rake in hand text (tournament)
        pot = sum(winners.values())

        return Hand(
            hand_id=hand_id,
            platform=Platform.POKER888,
            game_type="No Limit Hold'em",
            is_zoom=False,
            is_tournament=is_tournament,
            tournament_id=tournament_id,
            stakes=(sb, bb),
            datetime=dt,
            table_name=table_name,
            max_players=max_players,
            button_seat=button_seat,
            players=players,
            hero=hero,
            hero_cards=hero_cards,
            actions=actions,
            board=board,
            pot=pot,
            rake=0.0,
            showdown=showdown,
            winners=winners,
            currency="CHIPS",
        )

    # ── Helpers ─────────────────────────────────────────────────────

    _SECTION_MARKERS_888 = [
        "** Dealing down cards **",
        "** Dealing flop **",
        "** Dealing turn **",
        "** Dealing river **",
        "** Summary **",
    ]

    def _split_sections(self, text: str) -> dict[str, str]:
        positions: list[tuple[str, int]] = []
        for marker in self._SECTION_MARKERS_888:
            idx = text.find(marker)
            if idx != -1:
                positions.append((marker, idx))
        # Also handle "** Primero runout **" if present (appears before streets)
        for m in re.finditer(r"\*\* Primero runout \*\*", text):
            pass  # ignore — streets follow separately
        positions.sort(key=lambda x: x[1])

        sections: dict[str, str] = {}
        if positions:
            sections["pre"] = text[: positions[0][1]]
        else:
            sections["pre"] = text

        for i, (marker, start) in enumerate(positions):
            # Find end of the marker line
            line_end = text.find("\n", start)
            if line_end == -1:
                line_end = start + len(marker)
            content_start = line_end + 1
            end = positions[i + 1][1] if i + 1 < len(positions) else len(text)
            content = text[content_start:end]

            if "Dealing down cards" in marker:
                sections["preflop"] = content
            elif "Dealing flop" in marker:
                sections["flop"] = content
            elif "Dealing turn" in marker:
                sections["turn"] = content
            elif "Dealing river" in marker:
                sections["river"] = content
            elif "Summary" in marker:
                sections["summary"] = content
        return sections

    def _parse_action_line(self, line: str, street: Street) -> Action | None:
        line = line.strip()
        if not line or line.startswith("**") or line.startswith("Dealt to"):
            return None

        m = self._RE_ALLIN.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.ALL_IN,
                          self._parse_chip_amount(m.group(2)), street)

        m = self._RE_RAISE.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.RAISE,
                          self._parse_chip_amount(m.group(2)), street)

        m = self._RE_CALL.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.CALL,
                          self._parse_chip_amount(m.group(2)), street)

        m = self._RE_BET.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.BET,
                          self._parse_chip_amount(m.group(2)), street)

        m = self._RE_CHECK.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.CHECK, 0.0, street)

        m = self._RE_FOLD.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.FOLD, 0.0, street)

        m = self._RE_COLLECTED.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.COLLECT,
                          self._parse_chip_amount(m.group(2)), street)

        return None
