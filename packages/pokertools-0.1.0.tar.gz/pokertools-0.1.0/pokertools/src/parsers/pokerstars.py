from __future__ import annotations

import re
from datetime import datetime

from ..models import (
    Hand, Card, PlayerSeat, Action, ActionType,
    Street, ShowdownEntry, Platform,
)
from .parser import Parser


class PokerStarsParser(Parser):

    # ── Header ──────────────────────────────────────────────────────
    _RE_HEADER = re.compile(
        r"^PokerStars (Zoom )?Hand #(\d+):\s+.+?"
        r"\(([€$£]?[\d,.]+)/([€$£]?[\d,.]+)\)"
        r"\s*-\s*(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2})",
        re.MULTILINE,
    )
    _RE_TABLE = re.compile(
        r"^Table '(.+?)' (\d+)-max Seat #(\d+) is the button",
        re.MULTILINE,
    )

    # ── Seats / Blinds ──────────────────────────────────────────────
    _RE_SEAT = re.compile(
        r"^Seat (\d+): (.+?) \(([€$£]?[\d,.]+) in chips\)",
        re.MULTILINE,
    )
    _RE_POST_SB = re.compile(
        r"^(.+?): posts small blind ([€$£]?[\d,.]+)", re.MULTILINE
    )
    _RE_POST_BB = re.compile(
        r"^(.+?): posts big blind ([€$£]?[\d,.]+)", re.MULTILINE
    )
    _RE_POST_ANTE = re.compile(
        r"^(.+?): posts the ante ([€$£]?[\d,.]+)", re.MULTILINE
    )

    # ── Hole cards ──────────────────────────────────────────────────
    _RE_DEALT_TO = re.compile(r"^Dealt to (.+?) \[(.+?)\]", re.MULTILINE)

    # ── Actions ─────────────────────────────────────────────────────
    _RE_FOLD = re.compile(r"^(.+?): folds", re.MULTILINE)
    _RE_CHECK = re.compile(r"^(.+?): checks", re.MULTILINE)
    _RE_CALL = re.compile(
        r"^(.+?): calls ([€$£]?[\d,.]+)", re.MULTILINE
    )
    _RE_BET = re.compile(
        r"^(.+?): bets ([€$£]?[\d,.]+)", re.MULTILINE
    )
    _RE_RAISE = re.compile(
        r"^(.+?): raises [€$£]?[\d,.]+ to ([€$£]?[\d,.]+)", re.MULTILINE
    )
    _RE_UNCALLED = re.compile(
        r"^Uncalled bet \(([€$£]?[\d,.]+)\) returned to (.+)", re.MULTILINE
    )
    _RE_COLLECTED = re.compile(
        r"^(.+?) collected ([€$£]?[\d,.]+) from (?:main |side )?pot",
        re.MULTILINE,
    )

    # ── Showdown ────────────────────────────────────────────────────
    _RE_SHOWS = re.compile(
        r"^(.+?): shows \[(.+?)\] \((.+?)\)", re.MULTILINE
    )
    _RE_MUCKS = re.compile(r"^(.+?): mucks hand", re.MULTILINE)

    # ── Streets ─────────────────────────────────────────────────────
    _RE_FLOP = re.compile(r"^\*\*\* FLOP \*\*\* \[(.+?)\]", re.MULTILINE)
    _RE_TURN = re.compile(
        r"^\*\*\* TURN \*\*\* \[.+?\] \[(.+?)\]", re.MULTILINE
    )
    _RE_RIVER = re.compile(
        r"^\*\*\* RIVER \*\*\* \[.+?\] \[(.+?)\]", re.MULTILINE
    )

    # ── Summary ─────────────────────────────────────────────────────
    _RE_POT_RAKE = re.compile(
        r"^Total pot ([€$£]?[\d,.]+) \| Rake ([€$£]?[\d,.]+)",
        re.MULTILINE,
    )
    _RE_BOARD_SUMMARY = re.compile(r"^Board \[(.+?)\]", re.MULTILINE)

    # Section markers
    _SECTION_MARKERS = [
        "*** HOLE CARDS ***",
        "*** FLOP ***",
        "*** TURN ***",
        "*** RIVER ***",
        "*** SHOW DOWN ***",
        "*** SUMMARY ***",
    ]

    # ────────────────────────────────────────────────────────────────

    def split_hands(self, content: str) -> list[str]:
        parts = re.split(r"\n{3,}", content)
        return [p.strip() for p in parts if p.strip()]

    def parse_hand(self, text: str) -> Hand:
        # ── 1. Header ───────────────────────────────────────────────
        m = self._RE_HEADER.search(text)
        if not m:
            raise ValueError("No PokerStars header found")
        is_zoom = bool(m.group(1))
        hand_id = m.group(2)
        sb = self._parse_amount(m.group(3))
        bb = self._parse_amount(m.group(4))
        dt = datetime.strptime(m.group(5), "%Y/%m/%d %H:%M:%S")
        currency = "EUR" if "€" in m.group(3) else "USD" if "$" in m.group(3) else "EUR"

        # ── 2. Table ────────────────────────────────────────────────
        m_table = self._RE_TABLE.search(text)
        table_name = m_table.group(1) if m_table else ""
        max_players = int(m_table.group(2)) if m_table else 6
        button_seat = int(m_table.group(3)) if m_table else 1

        # ── 3. Seats ────────────────────────────────────────────────
        players: list[PlayerSeat] = []
        for sm in self._RE_SEAT.finditer(text):
            players.append(
                PlayerSeat(
                    seat=int(sm.group(1)),
                    name=sm.group(2).strip(),
                    stack=self._parse_amount(sm.group(3)),
                )
            )

        # ── 4. Section boundaries ──────────────────────────────────
        sections = self._split_sections(text)

        # ── 5. Blinds & Antes (before HOLE CARDS) ──────────────────
        actions: list[Action] = []
        pre_section = sections.get("pre", "")
        for am in self._RE_POST_ANTE.finditer(pre_section):
            actions.append(Action(am.group(1).strip(), ActionType.POST_ANTE,
                                  self._parse_amount(am.group(2)), Street.PREFLOP))
        for sm_blind in self._RE_POST_SB.finditer(pre_section):
            actions.append(Action(sm_blind.group(1).strip(), ActionType.POST_SB,
                                  self._parse_amount(sm_blind.group(2)), Street.PREFLOP))
        for bm in self._RE_POST_BB.finditer(pre_section):
            actions.append(Action(bm.group(1).strip(), ActionType.POST_BB,
                                  self._parse_amount(bm.group(2)), Street.PREFLOP))

        # ── 6. Actions per street ──────────────────────────────────
        street_map = {
            "preflop": Street.PREFLOP,
            "flop": Street.FLOP,
            "turn": Street.TURN,
            "river": Street.RIVER,
        }
        for street_name, street_enum in street_map.items():
            section_text = sections.get(street_name, "")
            if not section_text:
                continue
            for line in section_text.split("\n"):
                action = self._parse_action_line(line, street_enum)
                if action:
                    actions.append(action)

        # ── 7. Showdown actions ────────────────────────────────────
        sd_text = sections.get("showdown", "")
        for line in sd_text.split("\n"):
            action = self._parse_action_line(line, Street.RIVER)
            if action:
                actions.append(action)

        # ── 8. Hero ────────────────────────────────────────────────
        hero = None
        hero_cards = None
        m_dealt = self._RE_DEALT_TO.search(text)
        if m_dealt:
            hero = m_dealt.group(1).strip()
            hero_cards = self._parse_cards(m_dealt.group(2))
            for p in players:
                if p.name == hero:
                    p.hole_cards = hero_cards

        # ── 9. Board ───────────────────────────────────────────────
        board: list[Card] = []
        m_flop = self._RE_FLOP.search(text)
        if m_flop:
            board = self._parse_cards(m_flop.group(1))
        m_turn = self._RE_TURN.search(text)
        if m_turn:
            board.append(self._parse_card(m_turn.group(1)))
        m_river = self._RE_RIVER.search(text)
        if m_river:
            board.append(self._parse_card(m_river.group(1)))

        # ── 10. Showdown entries ───────────────────────────────────
        showdown: list[ShowdownEntry] = []
        winners: dict[str, float] = {}
        for cm in self._RE_COLLECTED.finditer(text):
            name = cm.group(1).strip()
            amt = self._parse_amount(cm.group(2))
            winners[name] = winners.get(name, 0.0) + amt

        for sm_show in self._RE_SHOWS.finditer(text):
            name = sm_show.group(1).strip()
            cards = self._parse_cards(sm_show.group(2))
            desc = sm_show.group(3).strip()
            won = name in winners
            amt = winners.get(name, 0.0)
            showdown.append(ShowdownEntry(name, cards, desc, won, amt))
            for p in players:
                if p.name == name:
                    p.hole_cards = cards

        # ── 11. Summary ───────────────────────────────────────────
        pot = 0.0
        rake = 0.0
        m_pot = self._RE_POT_RAKE.search(text)
        if m_pot:
            pot = self._parse_amount(m_pot.group(1))
            rake = self._parse_amount(m_pot.group(2))

        is_tournament = "Tournament" in text.split("\n")[0]
        tournament_id = None
        if is_tournament:
            tm = re.search(r"Tournament #(\d+)", text)
            if tm:
                tournament_id = tm.group(1)

        return Hand(
            hand_id=hand_id,
            platform=Platform.POKERSTARS,
            game_type="No Limit Hold'em",
            is_zoom=is_zoom,
            is_tournament=is_tournament,
            tournament_id=tournament_id,
            stakes=(sb, bb),
            datetime=dt,
            table_name=table_name,
            max_players=max_players,
            button_seat=button_seat,
            players=players,
            hero=hero,
            hero_cards=hero_cards,
            actions=actions,
            board=board,
            pot=pot,
            rake=rake,
            showdown=showdown,
            winners=winners,
            currency="CHIPS" if is_tournament else currency,
        )

    # ── Helpers ─────────────────────────────────────────────────────

    def _split_sections(self, text: str) -> dict[str, str]:
        """Split hand text into named sections based on *** markers."""
        positions: list[tuple[str, int]] = []
        for marker in self._SECTION_MARKERS:
            idx = text.find(marker)
            if idx != -1:
                positions.append((marker, idx))
        positions.sort(key=lambda x: x[1])

        sections: dict[str, str] = {}
        # Everything before first marker
        if positions:
            sections["pre"] = text[: positions[0][1]]
        else:
            sections["pre"] = text

        for i, (marker, start) in enumerate(positions):
            end = positions[i + 1][1] if i + 1 < len(positions) else len(text)
            content = text[start + len(marker) : end]
            if "HOLE CARDS" in marker:
                sections["preflop"] = content
            elif "FLOP" in marker:
                sections["flop"] = content
            elif "TURN" in marker:
                sections["turn"] = content
            elif "RIVER" in marker:
                sections["river"] = content
            elif "SHOW DOWN" in marker:
                sections["showdown"] = content
            elif "SUMMARY" in marker:
                sections["summary"] = content
        return sections

    def _parse_action_line(self, line: str, street: Street) -> Action | None:
        """Try to parse a single line as a player action. Returns None if not an action."""
        line = line.strip()
        if not line:
            return None

        m = self._RE_FOLD.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.FOLD, 0.0, street)

        m = self._RE_CHECK.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.CHECK, 0.0, street)

        m = self._RE_RAISE.match(line)
        if m:
            atype = ActionType.ALL_IN if "all-in" in line else ActionType.RAISE
            return Action(m.group(1).strip(), atype,
                          self._parse_amount(m.group(2)), street)

        m = self._RE_CALL.match(line)
        if m:
            atype = ActionType.ALL_IN if "all-in" in line else ActionType.CALL
            return Action(m.group(1).strip(), atype,
                          self._parse_amount(m.group(2)), street)

        m = self._RE_BET.match(line)
        if m:
            atype = ActionType.ALL_IN if "all-in" in line else ActionType.BET
            return Action(m.group(1).strip(), atype,
                          self._parse_amount(m.group(2)), street)

        m = self._RE_UNCALLED.match(line)
        if m:
            return Action(m.group(2).strip(), ActionType.RETURN_UNCALLED,
                          self._parse_amount(m.group(1)), street)

        m = self._RE_COLLECTED.match(line)
        if m:
            return Action(m.group(1).strip(), ActionType.COLLECT,
                          self._parse_amount(m.group(2)), street)

        return None
