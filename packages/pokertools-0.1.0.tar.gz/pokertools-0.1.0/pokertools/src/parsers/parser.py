from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path

from ..models import Hand, Card

logger = logging.getLogger(__name__)


class Parser(ABC):

    @abstractmethod
    def split_hands(self, content: str) -> list[str]:
        """Split file content into individual hand text blocks."""
        ...

    @abstractmethod
    def parse_hand(self, text: str) -> Hand:
        """Parse a single hand text block into a Hand object."""
        ...

    def parse_file(self, path: str | Path) -> list[Hand]:
        """Read a hand history file and parse all hands from it."""
        path = Path(path)
        content = None
        for enc in ("utf-8-sig", "utf-8", "latin-1"):
            try:
                content = path.read_text(encoding=enc)
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        if content is None:
            logger.error("Could not decode file %s", path)
            return []

        chunks = self.split_hands(content)
        hands: list[Hand] = []
        for chunk in chunks:
            chunk = chunk.strip()
            if not chunk or len(chunk) < 20:
                continue
            try:
                hands.append(self.parse_hand(chunk))
            except Exception:
                first_line = chunk.split("\n", 1)[0][:80]
                logger.warning("Failed to parse hand starting with: %s", first_line, exc_info=True)
        return hands

    def parse_directory(self, path: str | Path) -> list[Hand]:
        """Parse all .txt hand history files in a directory tree."""
        path = Path(path)
        hands: list[Hand] = []
        for txt_file in sorted(path.rglob("*.txt")):
            hands.extend(self.parse_file(txt_file))
        return hands

    @staticmethod
    def _parse_card(s: str) -> Card:
        return Card.from_str(s.strip())

    @staticmethod
    def _parse_cards(s: str) -> list[Card]:
        """Parse cards from a string like '[Jh 5h]' or '[ Ah, 7d ]'."""
        s = s.strip().strip("[]").strip()
        if not s:
            return []
        if "," in s:
            tokens = [t.strip() for t in s.split(",")]
        else:
            tokens = s.split()
        return [Card.from_str(t) for t in tokens if t]

    @staticmethod
    def _parse_amount(s: str) -> float:
        """Parse a monetary/chip amount string, stripping currency symbols."""
        s = s.strip().replace("\xa0", "").replace(" ", "")
        s = s.replace("€", "").replace("$", "").replace("£", "")
        if not s:
            return 0.0
        try:
            return float(s)
        except ValueError:
            return 0.0
