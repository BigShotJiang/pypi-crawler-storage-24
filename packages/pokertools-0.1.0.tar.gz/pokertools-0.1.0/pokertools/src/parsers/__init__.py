from .parser import Parser
from .pokerstars import PokerStarsParser
from .p888poker import Poker888Parser
from .winamax import WinamaxParser

__all__ = ["Parser", "PokerStarsParser", "Poker888Parser", "WinamaxParser"]
