from dataclasses import dataclass
from pokertools.src.models import Hand
from pokerlib import (
    HandParser,
    HandParserGroup,
    Player,
    PlayerGroup,
    Round,
    Table,
    PlayerSeats
)
import typing as t

RANGE_MATRIX = []

class RangeCombo:
    hand: Hand

class PokerRange:
    def __init__(self, name: str, player_name: t.Optional[str] = None, hand_history: t.Optional[t.Iterable[Hand]] = None):
        self.name = name
        self.hands = None
        if hand_history is not None and player_name is not None:
            self.fetch_from_history(hand_history, player_name)

    def fetch_from_history(self, hand_history: t.Iterable[Hand] , player_name: str):
        """Fetch the range of hands for a player from a hand history."""
        self.hands = []
        for hand in hand_history:
            for player in hand.players:
                if player.name == player_name:
                    self.hands.append(hand)
                    break
    
        self.range = [hand.hero_cards for hand in self.hands if hand.hero_cards is not None]
        print(self.range)
        self.range = {hand: self.range.count(hand) / len(self.hands) for hand in self.range}
            
    def get_grid(self, position, player) -> t.Dict[str, float]:
        """Get the range grid for a given position and player."""
        # This is a placeholder implementation. You would need to implement the logic to convert hand combinations into a grid format.
        return {str(hand): freq for hand, freq in self.range.items()}
