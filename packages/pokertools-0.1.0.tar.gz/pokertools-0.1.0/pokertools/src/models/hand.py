from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

SUIT_ICONS = {
    "h": "♥",
    "d": "♦",
    "c": "♣",
    "s": "♠",
}


class Platform(Enum):
    POKERSTARS = "pokerstars"
    POKER888 = "888poker"
    WINAMAX = "winamax"


class Street(Enum):
    PREFLOP = "preflop"
    FLOP = "flop"
    TURN = "turn"
    RIVER = "river"


class ActionType(Enum):
    POST_SB = "post_sb"
    POST_BB = "post_bb"
    POST_ANTE = "post_ante"
    FOLD = "fold"
    CHECK = "check"
    CALL = "call"
    BET = "bet"
    RAISE = "raise"
    ALL_IN = "all_in"
    COLLECT = "collect"
    RETURN_UNCALLED = "return_uncalled"
    SHOW = "show"
    MUCK = "muck"


@dataclass(frozen=True)
class Card:
    rank: str  # '2','3','4','5','6','7','8','9','T','J','Q','K','A'
    suit: str  # 'h','d','c','s'

    @classmethod
    def from_str(cls, s: str) -> Card:
        s = s.strip()
        if len(s) < 2:
            raise ValueError(f"Invalid card string: {s!r}")
        return cls(rank=s[0].upper(), suit=s[1].lower())

    def __str__(self) -> str:
        return f"{self.rank}{self.suit}"

    def __repr__(self) -> str:
        return f"{self.rank}{SUIT_ICONS.get(self.suit, self.suit)}"


@dataclass
class PlayerSeat:
    seat: int
    name: str
    stack: float
    hole_cards: Optional[list[Card]] = None


@dataclass
class Action:
    player: str
    action_type: ActionType
    amount: float = 0.0
    street: Street = Street.PREFLOP


@dataclass
class ShowdownEntry:
    player: str
    cards: list[Card]
    hand_description: str
    won: bool
    amount: float


@dataclass
class Hand:
    hand_id: str
    platform: Platform
    game_type: str
    is_zoom: bool
    is_tournament: bool
    tournament_id: Optional[str]
    stakes: tuple[float, float]
    datetime: datetime
    table_name: str
    max_players: int
    button_seat: int
    players: list[PlayerSeat] = field(default_factory=list)
    hero: Optional[str] = None
    hero_cards: Optional[list[Card]] = None
    actions: list[Action] = field(default_factory=list)
    board: list[Card] = field(default_factory=list)
    pot: float = 0.0
    rake: float = 0.0
    showdown: list[ShowdownEntry] = field(default_factory=list)
    winners: dict[str, float] = field(default_factory=dict)
    currency: str = "EUR"

    def to_dict(self) -> dict:
        return {
            "hand_id": self.hand_id,
            "platform": self.platform.value,
            "game_type": self.game_type,
            "is_zoom": self.is_zoom,
            "is_tournament": self.is_tournament,
            "tournament_id": self.tournament_id,
            "stakes": list(self.stakes),
            "datetime": self.datetime.isoformat(),
            "table_name": self.table_name,
            "max_players": self.max_players,
            "button_seat": self.button_seat,
            "players": [
                {
                    "seat": p.seat,
                    "name": p.name,
                    "stack": p.stack,
                    "hole_cards": [str(c) for c in p.hole_cards]
                    if p.hole_cards
                    else None,
                }
                for p in self.players
            ],
            "hero": self.hero,
            "hero_cards": [str(c) for c in self.hero_cards]
            if self.hero_cards
            else None,
            "actions": [
                {
                    "player": a.player,
                    "action_type": a.action_type.value,
                    "amount": a.amount,
                    "street": a.street.value,
                }
                for a in self.actions
            ],
            "board": [str(c) for c in self.board],
            "pot": self.pot,
            "rake": self.rake,
            "showdown": [
                {
                    "player": s.player,
                    "cards": [str(c) for c in s.cards],
                    "hand_description": s.hand_description,
                    "won": s.won,
                    "amount": s.amount,
                }
                for s in self.showdown
            ],
            "winners": self.winners,
            "currency": self.currency,
        }

    @classmethod
    def from_dict(cls, d: dict) -> Hand:
        return cls(
            hand_id=d["hand_id"],
            platform=Platform(d["platform"]),
            game_type=d["game_type"],
            is_zoom=d["is_zoom"],
            is_tournament=d["is_tournament"],
            tournament_id=d.get("tournament_id"),
            stakes=tuple(d["stakes"]),
            datetime=datetime.fromisoformat(d["datetime"]),
            table_name=d["table_name"],
            max_players=d["max_players"],
            button_seat=d["button_seat"],
            players=[
                PlayerSeat(
                    seat=p["seat"],
                    name=p["name"],
                    stack=p["stack"],
                    hole_cards=[Card.from_str(c) for c in p["hole_cards"]]
                    if p.get("hole_cards")
                    else None,
                )
                for p in d.get("players", [])
            ],
            hero=d.get("hero"),
            hero_cards=[Card.from_str(c) for c in d["hero_cards"]]
            if d.get("hero_cards")
            else None,
            actions=[
                Action(
                    player=a["player"],
                    action_type=ActionType(a["action_type"]),
                    amount=a["amount"],
                    street=Street(a["street"]),
                )
                for a in d.get("actions", [])
            ],
            board=[Card.from_str(c) for c in d.get("board", [])],
            pot=d.get("pot", 0.0),
            rake=d.get("rake", 0.0),
            showdown=[
                ShowdownEntry(
                    player=s["player"],
                    cards=[Card.from_str(c) for c in s["cards"]],
                    hand_description=s["hand_description"],
                    won=s["won"],
                    amount=s["amount"],
                )
                for s in d.get("showdown", [])
            ],
            winners=d.get("winners", {}),
            currency=d.get("currency", "EUR"),
        )


    def __str__(self) -> str:
        cards = [f"{c.rank}{SUIT_ICONS.get(c.suit, c.suit)}" for c in self.board]
        return f"[{cards}] Hand({self.hand_id} on {self.platform.value} at {self.datetime.isoformat()})"
    
    def __repr__(self) -> str:
        cards = [f"{c.rank}{SUIT_ICONS.get(c.suit, c.suit)}" for c in self.board]
        return f"{cards} | Hand({self.hand_id} on {self.platform.value} at {self.datetime.isoformat()})"