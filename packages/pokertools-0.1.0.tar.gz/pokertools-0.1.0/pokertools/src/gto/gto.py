from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Optional, Union

from ..models import Card, Street
from .game_tree import GameState, GameTreeBuilder
from .cfr import CFRSolver
from .hand_evaluator import HandEvaluator
from .abstractions import CardAbstraction, ActionAbstraction


@dataclass
class GTOScenario:
    """Input specification for a GTO solve."""

    street: Street
    board: list[Card]
    pot: float
    oop_stack: float
    ip_stack: float
    oop_range: list[str]   # hand combo strings: ["AhKh", "AsKs", ...]
    ip_range: list[str]
    oop_player: str = "OOP"
    ip_player: str = "IP"
    iterations: int = 1000
    n_buckets: int = 8
    bet_sizes: list[float] = field(default_factory=lambda: [0.33, 0.5, 0.75, 1.0])

    @staticmethod
    def _parse_hand_string(hs: str) -> list[Card]:
        hs = hs.strip()
        if len(hs) == 4:
            return [Card.from_str(hs[0:2]), Card.from_str(hs[2:4])]
        raise ValueError(f"Invalid hand string: {hs!r}")

    def _parse_range(self, hand_strings: list[str]) -> list[list[Card]]:
        result: list[list[Card]] = []
        for hs in hand_strings:
            try:
                result.append(self._parse_hand_string(hs))
            except ValueError:
                continue
        return result

    def to_game_state(self) -> GameState:
        oop_range = self._parse_range(self.oop_range)
        ip_range = self._parse_range(self.ip_range)
        return GameState(
            street=self.street,
            board=list(self.board),
            pot=self.pot,
            stacks={self.oop_player: self.oop_stack, self.ip_player: self.ip_stack},
            current_player=self.oop_player,
            player_names=[self.oop_player, self.ip_player],
            oop_range=oop_range,
            ip_range=ip_range,
            to_call=0.0,
            betting_history="",
            initial_investment={
                self.oop_player: self.oop_stack,
                self.ip_player: self.ip_stack,
            },
        )


@dataclass
class GTOSolution:
    """Output of a GTO solve."""

    scenario: GTOScenario
    oop_strategy: dict[str, dict[str, float]]
    ip_strategy: dict[str, dict[str, float]]
    oop_ev: float
    ip_ev: float
    exploitability: float
    iterations_run: int
    converged: bool
    solve_time_seconds: float

    def to_dict(self) -> dict:
        return {
            "scenario": {
                "street": self.scenario.street.value,
                "board": [str(c) for c in self.scenario.board],
                "pot": self.scenario.pot,
                "oop_stack": self.scenario.oop_stack,
                "ip_stack": self.scenario.ip_stack,
                "oop_range": self.scenario.oop_range,
                "ip_range": self.scenario.ip_range,
                "oop_player": self.scenario.oop_player,
                "ip_player": self.scenario.ip_player,
                "iterations": self.scenario.iterations,
                "n_buckets": self.scenario.n_buckets,
                "bet_sizes": self.scenario.bet_sizes,
            },
            "oop_strategy": self.oop_strategy,
            "ip_strategy": self.ip_strategy,
            "oop_ev": self.oop_ev,
            "ip_ev": self.ip_ev,
            "exploitability": self.exploitability,
            "iterations_run": self.iterations_run,
            "converged": self.converged,
            "solve_time_seconds": self.solve_time_seconds,
        }

    @classmethod
    def from_dict(cls, d: dict) -> GTOSolution:
        s = d["scenario"]
        scenario = GTOScenario(
            street=Street(s["street"]),
            board=[Card.from_str(c) for c in s["board"]],
            pot=s["pot"],
            oop_stack=s["oop_stack"],
            ip_stack=s["ip_stack"],
            oop_range=s["oop_range"],
            ip_range=s["ip_range"],
            oop_player=s.get("oop_player", "OOP"),
            ip_player=s.get("ip_player", "IP"),
            iterations=s.get("iterations", 1000),
            n_buckets=s.get("n_buckets", 8),
            bet_sizes=s.get("bet_sizes", [0.33, 0.5, 0.75, 1.0]),
        )
        return cls(
            scenario=scenario,
            oop_strategy=d["oop_strategy"],
            ip_strategy=d["ip_strategy"],
            oop_ev=d["oop_ev"],
            ip_ev=d["ip_ev"],
            exploitability=d["exploitability"],
            iterations_run=d["iterations_run"],
            converged=d["converged"],
            solve_time_seconds=d["solve_time_seconds"],
        )


def _solve_single(scenario: GTOScenario) -> GTOSolution:
    """Solve a single scenario. Module-level for ProcessPoolExecutor pickling."""
    start = time.time()

    evaluator = HandEvaluator()
    card_abs = CardAbstraction(n_buckets=scenario.n_buckets)
    action_abs = ActionAbstraction(bet_sizes=scenario.bet_sizes)
    game_tree = GameTreeBuilder(action_abs)
    solver = CFRSolver(game_tree, card_abs, action_abs, evaluator)

    initial_state = scenario.to_game_state()
    convergence = solver.train(initial_state, iterations=scenario.iterations)

    exploitability = solver.get_exploitability_estimate()

    # Extract average strategies split by position
    oop_strategy: dict[str, dict[str, float]] = {}
    ip_strategy: dict[str, dict[str, float]] = {}

    for key, action_sums in solver.strategy_sum.items():
        actions = list(action_sums.keys())
        avg = solver.get_average_strategy(key, actions)
        if key.endswith("|oop"):
            oop_strategy[key] = avg
        else:
            ip_strategy[key] = avg

    elapsed = time.time() - start

    return GTOSolution(
        scenario=scenario,
        oop_strategy=oop_strategy,
        ip_strategy=ip_strategy,
        oop_ev=0.0,   # full EV calc requires extra pass — deferred
        ip_ev=0.0,
        exploitability=exploitability,
        iterations_run=convergence["effective_iterations"],
        converged=exploitability < 1.0,
        solve_time_seconds=elapsed,
    )


def calculate_gto_solution(
    scenarios: Union[GTOScenario, list[GTOScenario]],
    max_workers: Optional[int] = None,
) -> Union[GTOSolution, list[GTOSolution]]:
    """Calculate GTO solution(s). Parallelises across multiple scenarios."""
    if isinstance(scenarios, GTOScenario):
        return _solve_single(scenarios)

    workers = max_workers or min(len(scenarios), os.cpu_count() or 1)
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(_solve_single, s) for s in scenarios]
        return [f.result() for f in futures]
