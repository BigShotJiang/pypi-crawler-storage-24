from __future__ import annotations

import random
import time
from collections import defaultdict
from typing import Optional, Callable

from ..models import Card, Street
from .game_tree import GameState, GameTreeBuilder
from .hand_evaluator import HandEvaluator
from .abstractions import CardAbstraction, ActionAbstraction


class CFRSolver:
    """CFR+ solver for heads-up NLHE.

    Uses outcome-sampling Monte Carlo CFR with regret floors at 0 (CFR+).
    """

    def __init__(
        self,
        game_tree: GameTreeBuilder,
        card_abstraction: CardAbstraction,
        action_abstraction: ActionAbstraction,
        evaluator: HandEvaluator,
    ):
        self.game_tree = game_tree
        self.card_abstraction = card_abstraction
        self.action_abstraction = action_abstraction
        self.evaluator = evaluator

        self.regret_sum: dict[str, dict[str, float]] = defaultdict(
            lambda: defaultdict(float)
        )
        self.strategy_sum: dict[str, dict[str, float]] = defaultdict(
            lambda: defaultdict(float)
        )
        self._iteration: int = 0

    def _info_set_key(
        self,
        state: GameState,
        player: str,
        hole_cards: tuple[Card, ...],
    ) -> str:
        bucket = self.card_abstraction.get_bucket(
            list(hole_cards), state.board, self.evaluator
        )
        position = "oop" if player == state.oop_player() else "ip"
        return f"{bucket}|{state.betting_history}|{position}"

    def get_strategy(self, info_set_key: str, actions: list[str]) -> dict[str, float]:
        """Current strategy via regret matching."""
        regrets = self.regret_sum[info_set_key]
        positive = {a: max(regrets.get(a, 0.0), 0.0) for a in actions}
        total = sum(positive.values())
        if total > 0:
            return {a: positive[a] / total for a in actions}
        uniform = 1.0 / len(actions)
        return {a: uniform for a in actions}

    def get_average_strategy(
        self, info_set_key: str, actions: list[str]
    ) -> dict[str, float]:
        """Average strategy (Nash equilibrium approximation)."""
        sums = self.strategy_sum[info_set_key]
        total = sum(sums.get(a, 0.0) for a in actions)
        if total > 0:
            return {a: sums.get(a, 0.0) / total for a in actions}
        uniform = 1.0 / len(actions)
        return {a: uniform for a in actions}

    def cfr(
        self,
        state: GameState,
        hole_cards_oop: tuple[Card, ...],
        hole_cards_ip: tuple[Card, ...],
        reach_oop: float,
        reach_ip: float,
    ) -> float:
        """Recursive CFR. Returns counterfactual value for OOP."""
        if state.is_terminal:
            return self.game_tree.get_payoff(
                state,
                state.oop_player(),
                list(hole_cards_oop),
                list(hole_cards_ip),
                self.evaluator,
            )

        player = state.current_player
        is_oop = player == state.oop_player()
        hole_cards = hole_cards_oop if is_oop else hole_cards_ip
        key = self._info_set_key(state, player, hole_cards)
        actions = self.game_tree.get_actions(state)

        if not actions:
            return 0.0

        strategy = self.get_strategy(key, actions)
        action_values: dict[str, float] = {}
        node_value = 0.0

        for action in actions:
            new_state = self.game_tree.apply_action(state, action)
            if is_oop:
                ev = self.cfr(
                    new_state, hole_cards_oop, hole_cards_ip,
                    reach_oop * strategy[action], reach_ip,
                )
            else:
                ev = self.cfr(
                    new_state, hole_cards_oop, hole_cards_ip,
                    reach_oop, reach_ip * strategy[action],
                )
            action_values[action] = ev
            node_value += strategy[action] * ev

        # Update regrets and strategy sums
        counterfactual_reach = reach_ip if is_oop else reach_oop
        player_reach = reach_oop if is_oop else reach_ip

        for action in actions:
            if is_oop:
                regret = action_values[action] - node_value
            else:
                regret = node_value - action_values[action]

            # CFR+: floor regrets at 0
            self.regret_sum[key][action] = max(
                0.0, self.regret_sum[key][action] + counterfactual_reach * regret
            )
            self.strategy_sum[key][action] += player_reach * strategy[action]

        return node_value

    def train(
        self,
        initial_state: GameState,
        iterations: int = 1000,
        progress_callback: Optional[Callable[[int, float], None]] = None,
    ) -> dict:
        """Run CFR for N iterations using outcome sampling."""
        oop_range = initial_state.oop_range
        ip_range = initial_state.ip_range
        board_set = set(str(c) for c in initial_state.board)

        for t in range(iterations):
            oop_hand = random.choice(oop_range)
            ip_hand = random.choice(ip_range)

            # Skip card conflicts
            all_strs = board_set | {str(c) for c in oop_hand} | {str(c) for c in ip_hand}
            if len(all_strs) != len(initial_state.board) + len(oop_hand) + len(ip_hand):
                continue

            self.cfr(
                initial_state,
                tuple(oop_hand),
                tuple(ip_hand),
                1.0,
                1.0,
            )
            self._iteration += 1

            if progress_callback and t % 100 == 0:
                progress_callback(t, self.get_exploitability_estimate())

        return {
            "iterations": iterations,
            "effective_iterations": self._iteration,
            "n_info_sets": len(self.regret_sum),
        }

    def get_exploitability_estimate(self) -> float:
        """Rough exploitability estimate based on remaining regret."""
        total_regret = sum(
            max(0.0, r)
            for regrets in self.regret_sum.values()
            for r in regrets.values()
        )
        return total_regret / max(1, self._iteration)
