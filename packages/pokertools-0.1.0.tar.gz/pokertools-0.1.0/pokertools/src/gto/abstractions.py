from __future__ import annotations

from ..models import Card
from .hand_evaluator import HandEvaluator


class CardAbstraction:
    """Groups hands into equity buckets to reduce the game tree size."""

    def __init__(self, n_buckets: int = 8, n_samples: int = 200):
        self.n_buckets = n_buckets
        self.n_samples = n_samples

    def get_bucket(
        self,
        hole_cards: list[Card],
        board: list[Card],
        evaluator: HandEvaluator,
    ) -> int:
        equity = evaluator.equity_vs_random(hole_cards, board, self.n_samples)
        bucket = int(equity * self.n_buckets)
        return min(bucket, self.n_buckets - 1)


class ActionAbstraction:
    """Limits available actions to discrete bet sizes (fractions of pot)."""

    DEFAULT_BET_SIZES: list[float] = [0.33, 0.5, 0.75, 1.0]

    def __init__(self, bet_sizes: list[float] | None = None):
        self.bet_sizes = bet_sizes or self.DEFAULT_BET_SIZES

    def get_actions(
        self,
        pot: float,
        stack: float,
        is_facing_bet: bool,
        facing_amount: float = 0.0,
    ) -> list[str]:
        actions: list[str] = []

        if is_facing_bet:
            actions.append("fold")
            if facing_amount <= stack:
                actions.append("call")
            for size in self.bet_sizes:
                raise_total = size * pot + facing_amount
                if facing_amount < raise_total <= stack:
                    actions.append(f"raise_{int(size * 100)}")
        else:
            actions.append("check")
            for size in self.bet_sizes:
                bet_amount = size * pot
                if 0 < bet_amount <= stack:
                    actions.append(f"bet_{int(size * 100)}")

        if stack > 0:
            actions.append("all_in")

        return actions

    def amount_for_action(
        self,
        action: str,
        pot: float,
        stack: float,
        facing_amount: float = 0.0,
    ) -> float:
        if action in ("fold", "check"):
            return 0.0
        if action == "call":
            return min(facing_amount, stack)
        if action == "all_in":
            return stack

        # bet_33, raise_50, etc.
        parts = action.split("_")
        if len(parts) == 2:
            fraction = int(parts[1]) / 100.0
            amount = fraction * pot
            if "raise" in parts[0]:
                amount += facing_amount
            return min(amount, stack)

        return 0.0
