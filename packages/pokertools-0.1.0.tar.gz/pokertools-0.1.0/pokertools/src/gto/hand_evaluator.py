from __future__ import annotations

import itertools
import random
from typing import Optional

from pokerlib import HandParser
from pokerlib.enums import Rank, Suit

from ..models import Card

_RANK_MAP: dict[str, Rank] = {
    "2": Rank.TWO, "3": Rank.THREE, "4": Rank.FOUR,
    "5": Rank.FIVE, "6": Rank.SIX, "7": Rank.SEVEN,
    "8": Rank.EIGHT, "9": Rank.NINE, "T": Rank.TEN,
    "J": Rank.JACK, "Q": Rank.QUEEN, "K": Rank.KING, "A": Rank.ACE,
}

_SUIT_MAP: dict[str, Suit] = {
    "s": Suit.SPADE, "c": Suit.CLUB, "d": Suit.DIAMOND, "h": Suit.HEART,
}

ALL_CARDS: list[Card] = [
    Card(rank=r, suit=s)
    for r in ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"]
    for s in ["h", "d", "c", "s"]
]


def card_to_tuple(card: Card) -> tuple[Rank, Suit]:
    return (_RANK_MAP[card.rank], _SUIT_MAP[card.suit])


def cards_to_tuples(cards: list[Card]) -> list[tuple[Rank, Suit]]:
    return [card_to_tuple(c) for c in cards]


class HandEvaluator:
    """Wraps pokerlib HandParser for hand evaluation."""

    def evaluate(self, hole_cards: list[Card], board: list[Card]) -> HandParser:
        """Return a HandParser for the combined hole + board cards."""
        return HandParser(cards_to_tuples(hole_cards + board))

    def compare(self, hand1: list[Card], hand2: list[Card], board: list[Card]) -> int:
        """Compare two hands on a board. Returns 1 if hand1 wins, -1 if hand2, 0 tie."""
        hp1 = self.evaluate(hand1, board)
        hp2 = self.evaluate(hand2, board)
        if hp1 > hp2:
            return 1
        elif hp2 > hp1:
            return -1
        return 0

    def equity_vs_random(
        self,
        hole_cards: list[Card],
        board: list[Card],
        n_samples: int = 500,
    ) -> float:
        """Estimate equity of hole_cards vs a random hand via Monte Carlo."""
        known = set(str(c) for c in hole_cards + board)
        deck = [c for c in ALL_CARDS if str(c) not in known]
        cards_needed = 5 - len(board)

        wins = 0.0
        total = 0

        for _ in range(n_samples):
            sampled = random.sample(deck, 2 + cards_needed)
            opp_cards = sampled[:2]
            remaining_board = sampled[2:]
            full_board = board + remaining_board

            result = self.compare(hole_cards, opp_cards, full_board)
            if result == 1:
                wins += 1.0
            elif result == 0:
                wins += 0.5
            total += 1

        return wins / total if total > 0 else 0.5
