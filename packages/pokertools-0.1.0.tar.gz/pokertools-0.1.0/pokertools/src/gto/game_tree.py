from __future__ import annotations

import copy
from dataclasses import dataclass, field

from ..models import Card, Street
from .abstractions import ActionAbstraction
from .hand_evaluator import HandEvaluator

_NEXT_STREET: dict[Street, Street | None] = {
    Street.PREFLOP: Street.FLOP,
    Street.FLOP: Street.TURN,
    Street.TURN: Street.RIVER,
    Street.RIVER: None,
}


@dataclass
class GameState:
    """State of a heads-up poker game at a decision point."""

    street: Street
    board: list[Card]
    pot: float
    stacks: dict[str, float]
    current_player: str
    player_names: list[str]        # [oop, ip]
    oop_range: list[list[Card]]
    ip_range: list[list[Card]]
    to_call: float = 0.0
    last_aggressor: str = ""
    betting_history: str = ""
    is_terminal: bool = False
    initial_investment: dict[str, float] = field(default_factory=dict)

    def oop_player(self) -> str:
        return self.player_names[0]

    def ip_player(self) -> str:
        return self.player_names[1]

    def other_player(self) -> str:
        return [p for p in self.player_names if p != self.current_player][0]


class GameTreeBuilder:
    """Manages game state transitions for the CFR solver (heads-up NLHE)."""

    def __init__(self, action_abstraction: ActionAbstraction):
        self.action_abstraction = action_abstraction

    def get_actions(self, state: GameState) -> list[str]:
        stack = state.stacks.get(state.current_player, 0.0)
        is_facing = state.to_call > 0
        return self.action_abstraction.get_actions(
            pot=state.pot,
            stack=stack,
            is_facing_bet=is_facing,
            facing_amount=state.to_call,
        )

    def apply_action(self, state: GameState, action: str) -> GameState:
        """Return a new GameState after the current player takes action."""
        new = GameState(
            street=state.street,
            board=list(state.board),
            pot=state.pot,
            stacks=dict(state.stacks),
            current_player=state.current_player,
            player_names=list(state.player_names),
            oop_range=state.oop_range,
            ip_range=state.ip_range,
            to_call=state.to_call,
            last_aggressor=state.last_aggressor,
            betting_history=state.betting_history,
            is_terminal=False,
            initial_investment=dict(state.initial_investment),
        )

        player = new.current_player
        other = new.other_player()
        stack = new.stacks[player]

        if action == "fold":
            new.is_terminal = True
            new.betting_history += "f"
            return new

        if action == "check":
            new.betting_history += "x"
            # If IP checks (both checked), advance street
            if player == new.ip_player() and not new.last_aggressor:
                return self._advance_street(new)
            # If OOP checks after IP bet... shouldn't happen. If OOP checks first, IP acts.
            new.current_player = other
            return new

        if action == "call":
            amount = min(new.to_call, stack)
            new.stacks[player] -= amount
            new.pot += amount
            new.to_call = 0.0
            new.betting_history += "c"
            return self._advance_street(new)

        if action == "all_in":
            amount = stack
            new.stacks[player] = 0.0
            new.pot += amount
            new.betting_history += "A"
            # Opponent needs to act if they can
            if amount > new.to_call:
                new.to_call = amount - new.to_call
                new.last_aggressor = player
                new.current_player = other
            else:
                # Calling all-in for less or equal
                new.to_call = 0.0
                return self._advance_street(new)
            return new

        # bet_X or raise_X
        amount = self.action_abstraction.amount_for_action(
            action, new.pot, stack, new.to_call
        )
        new.stacks[player] -= amount
        new.pot += amount
        new.to_call = amount - state.to_call  # new call amount for opponent
        new.last_aggressor = player
        new.current_player = other
        new.betting_history += f"b{action.split('_')[-1]}"
        return new

    def _advance_street(self, state: GameState) -> GameState:
        """Move to the next street or make terminal if past river."""
        next_street = _NEXT_STREET.get(state.street)
        if next_street is None:
            state.is_terminal = True
            return state
        state.street = next_street
        state.to_call = 0.0
        state.last_aggressor = ""
        state.current_player = state.oop_player()
        state.betting_history += "|"
        return state

    def get_payoff(
        self,
        state: GameState,
        player: str,
        hole_cards_oop: list[Card],
        hole_cards_ip: list[Card],
        evaluator: HandEvaluator,
    ) -> float:
        """Return net payoff for `player` in a terminal state.

        Positive = won chips, negative = lost chips.
        """
        oop = state.oop_player()
        ip = state.ip_player()
        oop_invested = state.initial_investment.get(oop, 0.0) - state.stacks.get(oop, 0.0)
        ip_invested = state.initial_investment.get(ip, 0.0) - state.stacks.get(ip, 0.0)

        # Fold: last char of history is 'f'
        if state.betting_history.endswith("f"):
            # Whoever folded loses their investment
            if state.current_player == oop:
                # OOP folded
                winner = ip
            else:
                winner = oop
        else:
            # Showdown
            result = evaluator.compare(hole_cards_oop, hole_cards_ip, state.board)
            if result == 1:
                winner = oop
            elif result == -1:
                winner = ip
            else:
                # Tie — split pot, return net 0 for both
                if player == oop:
                    return -oop_invested + state.pot / 2
                return -ip_invested + state.pot / 2

        if player == winner:
            invested = oop_invested if player == oop else ip_invested
            return state.pot - invested
        else:
            invested = oop_invested if player == oop else ip_invested
            return -invested
