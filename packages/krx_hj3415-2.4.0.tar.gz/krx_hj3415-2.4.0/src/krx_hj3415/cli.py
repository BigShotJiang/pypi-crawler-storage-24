# krx_hj3415/cli.py
from __future__ import annotations

import asyncio
from typing import Annotated

import typer
from krx_hj3415.app.composition import build_components
from krx_hj3415.app.domain.types import UniverseEnum
from krx_hj3415.app.settings import get_settings
from krx_hj3415.app.usecases.sync_universe import apply_removed, run_sync

app = typer.Typer(no_args_is_help=True)


@app.callback()
def main() -> None:
    """KRX universe tools."""
    pass


def _validate_max_days(v: int) -> int:
    s = get_settings()
    if not (s.max_days_min <= v <= s.max_days_max):
        raise typer.BadParameter(
            f"max-days는 {s.max_days_min}~{s.max_days_max} 범위여야 합니다."
        )
    return v


@app.command()
def sync(
    apply: Annotated[
        bool,
        typer.Option("--apply", help="removed를 nfs에서 실제 삭제까지 적용"),
    ] = False,
    snapshot: Annotated[
        bool,
        typer.Option("--snapshot/--no-snapshot", help="universe snapshot 저장 여부"),
    ] = True,
    max_days: Annotated[
        int,
        typer.Option(
            "--max-days",
            callback=_validate_max_days,
            help="최대 며칠 전까지 유효 엑셀 URL 탐색",
        ),
    ] = 15,
) -> None:
    """
    1) 외부에서 유니버스 수집
    2) DB latest와 diff
    3) universe latest(+snapshot) 저장
    4) (옵션) removed codes를 nfs에서 삭제 적용
    """

    async def _run() -> None:
        settings = get_settings()
        resolved_universe = UniverseEnum(settings.default_universe)
        components = build_components(settings)

        try:
            await components.resources.bootstrap()

            d = await run_sync(
                components.universe_store,
                universe=resolved_universe,
                max_days=max_days,
                snapshot=snapshot,
            )

            typer.echo(f"\n=== UNIVERSE SYNC: {d.universe} ===")
            typer.echo(f"asof: {d.asof.isoformat()}")
            typer.echo(
                f"added: {len(d.added)}, removed: {len(d.removed)}, kept: {d.kept_count}"
            )

            if d.added:
                typer.echo("\n[ADDED]")
                for it in d.added[: settings.print_limit]:
                    typer.echo(f"- {it.code} {it.name}")
                if len(d.added) > settings.print_limit:
                    typer.echo(f"... ({len(d.added) - settings.print_limit} more)")

            if d.removed:
                typer.echo("\n[REMOVED]")
                for it in d.removed[: settings.print_limit]:
                    typer.echo(f"- {it.code} {it.name}")
                if len(d.removed) > settings.print_limit:
                    typer.echo(f"... ({len(d.removed) - settings.print_limit} more)")

            if apply and d.removed:
                typer.echo("\n=== APPLY REMOVED TO NFS ===")
                r = await apply_removed(
                    components.nfs_cleaner,
                    removed_codes=d.removed_codes,
                )
                typer.echo(
                    f"latest_deleted={r.get('latest_deleted', 0)}, snapshots_deleted={r.get('snapshots_deleted', 0)}"
                )
            elif apply:
                typer.echo("\n(no removed codes) apply skipped")

        finally:
            await components.resources.aclose()

    asyncio.run(_run())


if __name__ == "__main__":
    app()
