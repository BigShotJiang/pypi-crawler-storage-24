# krx_hj3415/app/ports/universe_store.py
from __future__ import annotations

from typing import Protocol

from contracts_hj3415.common.envelope import UniverseEnvelopeDTO


class UniverseStorePort(Protocol):
    async def get_latest(self, *, universe: str) -> UniverseEnvelopeDTO | None: ...

    async def upsert_latest(self, *, dto: UniverseEnvelopeDTO) -> None: ...

    async def insert_snapshot(self, *, dto: UniverseEnvelopeDTO) -> None: ...
