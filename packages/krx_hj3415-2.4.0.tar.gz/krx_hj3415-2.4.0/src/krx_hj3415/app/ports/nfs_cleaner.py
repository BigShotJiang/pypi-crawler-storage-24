# krx_hj3415/app/ports/nfs_cleaner.py
from __future__ import annotations

from typing import Protocol, Sequence


class NfsCleanerPort(Protocol):
    async def delete_codes(self, *, codes: Sequence[str]) -> dict[str, int]: ...
