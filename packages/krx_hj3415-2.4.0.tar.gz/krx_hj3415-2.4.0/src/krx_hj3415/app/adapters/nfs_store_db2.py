# krx_hj3415/app/adapters/nfs_store_db2.py
from __future__ import annotations

from collections.abc import Sequence

from db2_hj3415.common.types import MongoDoc
from db2_hj3415.nfs.repo import delete_codes_from_all_endpoints
from krx_hj3415.app.ports.nfs_cleaner import NfsCleanerPort
from pymongo.asynchronous.database import AsyncDatabase


class NfsCleanerDb2(NfsCleanerPort):
    _db: AsyncDatabase[MongoDoc]

    def __init__(self, db: AsyncDatabase[MongoDoc]):
        self._db = db

    async def delete_codes(self, *, codes: Sequence[str]) -> dict[str, int]:
        return await delete_codes_from_all_endpoints(self._db, codes=codes)
