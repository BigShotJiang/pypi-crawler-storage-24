# krx_hj3415/app/adapters/universe_store_db2.py
from __future__ import annotations

from contracts_hj3415.common.envelope import UniverseEnvelopeDTO
from db2_hj3415.common.types import MongoDoc
from db2_hj3415.universe import mappers, repo
from krx_hj3415.app.ports.universe_store import UniverseStorePort
from pymongo.asynchronous.database import AsyncDatabase


class UniverseStoreDb2(UniverseStorePort):
    _db: AsyncDatabase[MongoDoc]

    def __init__(self, db: AsyncDatabase[MongoDoc]):
        self._db = db

    async def get_latest(self, *, universe: str) -> UniverseEnvelopeDTO | None:
        doc = await repo.get_latest(self._db, universe=universe)
        if not doc:
            return None
        return mappers.latest_doc_to_envelope(doc)

    async def upsert_latest(self, *, dto: UniverseEnvelopeDTO) -> None:
        doc = mappers.envelope_to_latest_doc(dto)
        _ = await repo.upsert_latest_doc(self._db, doc=doc)

    async def insert_snapshot(self, *, dto: UniverseEnvelopeDTO) -> None:
        doc = mappers.envelope_to_snapshot_doc(dto)
        _ = await repo.insert_snapshot_doc(self._db, doc=doc)
