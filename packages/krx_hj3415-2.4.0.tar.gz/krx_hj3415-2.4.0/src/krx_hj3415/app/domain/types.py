# krx_hj3415/app/domain/types.py
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum


class UniverseEnum(StrEnum):
    KRX300 = "krx300"


class MarketEnum(StrEnum):
    KRX = "krx"


@dataclass(frozen=True)
class CodeItem:
    code: str
    name: str
    asof: datetime
    market: MarketEnum


@dataclass(frozen=True)
class UniverseDiff:
    universe: UniverseEnum
    asof: datetime
    added: list[CodeItem]
    removed: list[CodeItem]
    kept_count: int

    @property
    def added_codes(self) -> list[str]:
        return [x.code for x in self.added]

    @property
    def removed_codes(self) -> list[str]:
        return [x.code for x in self.removed]
