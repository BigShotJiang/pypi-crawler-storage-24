# krx_hj3415/app/usecases/sync_universe.py
from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime

from contracts_hj3415.common import make_universe_envelope
from contracts_hj3415.common.envelope import UniverseEnvelopeDTO
from contracts_hj3415.universe.krx300 import UniverseItem
from krx_hj3415.app.domain.diff import diff_universe
from krx_hj3415.app.domain.types import CodeItem, MarketEnum, UniverseDiff, UniverseEnum
from krx_hj3415.app.ports.nfs_cleaner import NfsCleanerPort
from krx_hj3415.app.ports.universe_store import UniverseStorePort
from krx_hj3415.app.provider.krx300_samsungfund_excel import fetch_krx300_items


async def refresh_krx300(*, max_days: int = 15) -> tuple[datetime, list[CodeItem]]:
    return fetch_krx300_items(max_days=max_days)


def _envelope_to_code_items(env: UniverseEnvelopeDTO | None) -> list[CodeItem]:
    if not env:
        return []

    out: list[CodeItem] = []
    items = env["payload"]["contents"].get("items", [])
    for item in items:
        code = item.get("code", "")
        name = item.get("name", "")
        asof = env.get("asof", "")
        out.append(CodeItem(code=code, name=name, asof=asof, market=MarketEnum.KRX))
    return out


def _code_items_to_payload_items(
    items: Iterable[CodeItem],
    *,
    market: MarketEnum = MarketEnum.KRX,
) -> list[UniverseItem]:
    """
    krx 도메인 CodeItem 목록을 contracts UniverseItemDTO 목록으로 변환한다.

    - CodeItem.code 는 필수
    - CodeItem.name 은 비어있지 않을 때만 포함
    - market 은 krx 정책(default: "KRX")에 따라 주입
    """
    out: list[UniverseItem] = []

    for it in items:
        dto: UniverseItem = {
            "code": it.code,
            "name": it.name,
            "market": market.value,
        }
        out.append(dto)

    return out


async def apply_removed(
    cleaner: NfsCleanerPort,
    *,
    removed_codes: Iterable[str],
) -> dict[str, int]:
    codes = [str(c).strip() for c in removed_codes if c and str(c).strip()]
    if not codes:
        return {"latest_deleted": 0, "snapshots_deleted": 0}
    return await cleaner.delete_codes(codes=codes)


async def run_sync(
    universe_store: UniverseStorePort,
    *,
    universe: UniverseEnum = UniverseEnum.KRX300,
    max_days: int = 15,
    snapshot: bool = True,
) -> UniverseDiff:
    # 1) fetch
    asof, new_items = await refresh_krx300(max_days=max_days)

    # 2) load old (DTO)
    old_dto = await universe_store.get_latest(universe=universe.value)
    old_items = _envelope_to_code_items(old_dto)

    # 3) diff
    d = diff_universe(
        universe=universe, asof=asof, new_items=new_items, old_items=old_items
    )

    # 4) save
    dto = make_universe_envelope(
        universe=universe.value,
        asof=asof,
        source="samsungfund",
        contents={
            "items": _code_items_to_payload_items(new_items, market=MarketEnum.KRX)
        },
    )

    await universe_store.upsert_latest(dto=dto)
    if snapshot:
        await universe_store.insert_snapshot(dto=dto)

    return d
