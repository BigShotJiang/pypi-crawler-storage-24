# krx_hj3415/app/composition.py
from __future__ import annotations

from dataclasses import dataclass

from db2_hj3415.common.types import MongoDoc
from db2_hj3415.mongo import Mongo
from db2_hj3415.nfs.repo import ensure_indexes as ensure_indexes_nfs
from db2_hj3415.settings import Settings as Db2Settings
from db2_hj3415.universe.repo import ensure_indexes as ensure_indexes_universe
from krx_hj3415.app.adapters.nfs_store_db2 import NfsCleanerDb2
from krx_hj3415.app.adapters.universe_store_db2 import UniverseStoreDb2
from krx_hj3415.app.ports.nfs_cleaner import NfsCleanerPort
from krx_hj3415.app.ports.universe_store import UniverseStorePort
from krx_hj3415.app.settings import Settings
from pymongo.asynchronous.database import AsyncDatabase


def build_db2_settings(settings: Settings) -> Db2Settings:
    """
    krx settings -> db2 settings 변환.
    환경 소유권은 krx가 가지고, db2는 주입받아 사용한다.
    """
    return Db2Settings(
        MONGO_URI=settings.mongo_uri,
        DB_NAME=settings.mongo_db_name,
        MONGO_CONNECT_TIMEOUT_MS=settings.mongo_connect_timeout_ms,
        MONGO_SERVER_SELECTION_TIMEOUT_MS=settings.mongo_server_selection_timeout_ms,
        SNAPSHOT_TTL_DAYS=settings.snapshot_ttl_days,
    )


@dataclass(frozen=True)
class AppResources:
    mongo: Mongo
    db: AsyncDatabase[MongoDoc]
    db_settings: Db2Settings

    async def bootstrap(self) -> None:
        await ensure_indexes_universe(
            self.db,
            snapshot_ttl_days=self.db_settings.SNAPSHOT_TTL_DAYS,
        )
        await ensure_indexes_nfs(
            self.db,
            snapshot_ttl_days=self.db_settings.SNAPSHOT_TTL_DAYS,
        )

    async def aclose(self) -> None:
        await self.mongo.close()


@dataclass(frozen=True)
class Components:
    resources: AppResources
    universe_store: UniverseStorePort
    nfs_cleaner: NfsCleanerPort


def build_components(settings: Settings) -> Components:
    db2_settings = build_db2_settings(settings)
    mongo = Mongo(db2_settings)
    db = mongo.get_db()

    resources = AppResources(
        mongo=mongo,
        db=db,
        db_settings=db2_settings,
    )

    return Components(
        resources=resources,
        universe_store=UniverseStoreDb2(db),
        nfs_cleaner=NfsCleanerDb2(db),
    )
