# krx_hj3415/app/settings.py
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = PROJECT_ROOT / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(ENV_FILE),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # app
    app_name: str = "krx"
    app_env: str = "prod"
    log_level: str = "INFO"

    # db
    mongo_uri: str = "mongodb://localhost:27017"
    mongo_db_name: str = "hj3415"
    mongo_connect_timeout_ms: int = 5_000
    mongo_server_selection_timeout_ms: int = 5_000
    snapshot_ttl_days: int | None = 730

    # krx
    default_universe: str = ""

    default_max_days: int = 15
    max_days_min: int = 1
    max_days_max: int = 60

    source_name: str = "samsungfund"

    print_limit: int = 50


@lru_cache
def get_settings() -> Settings:
    return Settings()
