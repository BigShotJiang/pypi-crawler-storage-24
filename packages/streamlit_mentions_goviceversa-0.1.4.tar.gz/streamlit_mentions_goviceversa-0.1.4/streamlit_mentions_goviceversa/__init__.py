"""
streamlit-mentions-goviceversa

A Streamlit custom component for @mention autocomplete in text areas.
Users type @ to get an inline dropdown of taggable users, with filtering as they type.
"""

import os
import re
from typing import Any, Dict, List, Optional

import streamlit.components.v1 as components

_RELEASE = True

if _RELEASE:
    _build_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "frontend", "build"
    )
    _component_func = components.declare_component(
        "streamlit_mentions_goviceversa", path=_build_dir
    )
else:
    _component_func = components.declare_component(
        "streamlit_mentions_goviceversa", url="http://localhost:3001"
    )


def mention_textarea(
    users: List[Dict[str, str]],
    placeholder: str = "",
    height: int = 80,
    key: Optional[str] = None,
    default: str = "",
    mention_style: Optional[Dict[str, str]] = None,
    style_config: Optional[Dict[str, Any]] = None,
) -> str:
    """
    A text area with @mention autocomplete support.

    When the user types '@', a dropdown appears showing matching users.
    Selecting a user inserts a mention in the format @[Display Name](username).

    Args:
        users: List of dicts with keys:
            - id: unique identifier (username)
            - display: display name shown in dropdown and text
            - slack_id: (optional) Slack user ID for notification integration
        placeholder: Placeholder text shown when the textarea is empty.
        height: Height of the textarea in pixels.
        key: Streamlit widget key for state management.
        default: Default text value.
        mention_style: Dict to customise mention highlight appearance.
            Only backgroundColor is safe (other properties cause text
            misalignment between highlighter and textarea layers).
            Keys:
            - background_color_light: mention bg in light mode (default "#bbdefb")
            - background_color_dark: mention bg in dark mode (default "#2a4a6c")
        style_config: Dict to customise the general textarea appearance.
            Keys (all optional):
            - border_color_light / border_color_dark: border colour
            - focus_border_color: border colour on focus (default "#ff4b4b")
            - background_color_light / background_color_dark: textarea bg
            - text_color_light / text_color_dark: text colour
            - font_size: in pixels (default 14)
            - font_family: CSS font-family string
            - border_radius: in pixels (default 8)
            - dropdown_max_height: max height for suggestions dropdown (default 200)

    Returns:
        The text content as a string. Mentions are encoded as @[Display Name](username).

    Example:
        >>> users = [
        ...     {"id": "sajjad", "display": "Sajjad Goudarzi", "slack_id": "U07HW1Y0TC2"},
        ...     {"id": "john", "display": "John Smith", "slack_id": "U08AB2Z1XY3"},
        ... ]
        >>> value = mention_textarea(users=users, placeholder="Type @ to mention someone...")
        >>> # value might be: "Hey @[Sajjad Goudarzi](sajjad), please check this"
        >>>
        >>> # Customise mention highlight colour:
        >>> value = mention_textarea(
        ...     users=users,
        ...     mention_style={"background_color_light": "#c8e6c9"},
        ... )
    """
    component_value = _component_func(
        users=users,
        placeholder=placeholder,
        height=height,
        default=default,
        mention_style=mention_style or {},
        style_config=style_config or {},
        key=key,
    )
    return component_value if component_value is not None else default


# --- Utility functions for processing mentions ---

_MENTION_PATTERN = re.compile(r"@\[([^\]]+)\]\(([^)]+)\)")


def parse_mentions(text: str) -> List[Dict[str, str]]:
    """
    Parse @[Display Name](username) patterns from text.

    Args:
        text: Text containing mention markup.

    Returns:
        List of dicts with 'display' and 'username' keys.

    Example:
        >>> parse_mentions("Hey @[Sajjad Goudarzi](sajjad), check this")
        [{"display": "Sajjad Goudarzi", "username": "sajjad"}]
    """
    return [
        {"display": match[0], "username": match[1]}
        for match in _MENTION_PATTERN.findall(text)
    ]


def render_display_text(text: str) -> str:
    """
    Convert mention markup to readable @DisplayName format.

    @[Sajjad Goudarzi](sajjad) -> @Sajjad Goudarzi

    Args:
        text: Text containing mention markup.

    Returns:
        Text with mentions rendered as @DisplayName.
    """
    return _MENTION_PATTERN.sub(r"@\1", text)


def render_html_text(text: str) -> str:
    """
    Convert mention markup to styled HTML badges.

    @[Sajjad Goudarzi](sajjad) -> <span class="mention-badge">@Sajjad Goudarzi</span>

    Args:
        text: Text containing mention markup.

    Returns:
        HTML string with mentions rendered as styled inline badges.
    """

    def _replace_with_badge(match: re.Match) -> str:
        display_name = match.group(1)
        return (
            f'<span style="background:#e3f2fd;color:#1565c0;padding:1px 6px;'
            f"border-radius:10px;font-weight:500;font-size:13px;"
            f'white-space:nowrap;">@{display_name}</span>'
        )

    return _MENTION_PATTERN.sub(_replace_with_badge, text)


def render_slack_text(text: str, users_lookup: Dict[str, str]) -> str:
    """
    Convert mention markup to Slack <@SLACK_ID> format.

    @[Sajjad Goudarzi](sajjad) -> <@U07HW1Y0TC2>

    Args:
        text: Text containing mention markup.
        users_lookup: Dict mapping username -> slack_id.
            Example: {"sajjad": "U07HW1Y0TC2", "john": "U08AB2Z1XY3"}

    Returns:
        Text with mentions converted to Slack format.
        If a user has no slack_id in the lookup, falls back to @DisplayName.
    """

    def _replace_with_slack(match: re.Match) -> str:
        display_name = match.group(1)
        username = match.group(2)
        slack_id = users_lookup.get(username)
        if slack_id:
            return f"<@{slack_id}>"
        return f"@{display_name}"

    return _MENTION_PATTERN.sub(_replace_with_slack, text)


def build_slack_lookup(users_df: Any) -> Dict[str, str]:
    """
    Build a username -> slack_id lookup dict from a pandas DataFrame.

    This is a convenience function for use with render_slack_text().

    Args:
        users_df: pandas DataFrame with 'username' and 'slackId' columns.

    Returns:
        Dict mapping username to slack_id (only for users that have a slack_id).
    """
    lookup = {}
    for _, row in users_df.iterrows():
        username = row.get("username")
        slack_id = row.get("slackId")
        if username and slack_id:
            lookup[username] = slack_id
    return lookup
