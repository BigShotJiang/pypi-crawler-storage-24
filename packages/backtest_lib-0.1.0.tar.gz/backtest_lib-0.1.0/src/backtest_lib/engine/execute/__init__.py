from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass, replace
from functools import cached_property
from typing import Protocol, Self, TypeVar

from backtest_lib.engine.plan import Plan, PlanOp, TradeOrder
from backtest_lib.market import MarketView
from backtest_lib.market._backends import _get_mapping_type_from_backend
from backtest_lib.portfolio import Portfolio
from backtest_lib.universe.universe_mapping import UniverseMapping

TPlanOp_contra = TypeVar("TPlanOp_contra", bound=PlanOp, infer_variance=True)


class PlanExecutor[TPlanOp_contra](Protocol):
    def execute_plan(
        self,
        plan: Plan[TPlanOp_contra],
        portfolio: Portfolio,
        prices: UniverseMapping,
        market: MarketView,
    ) -> ExecutionResult: ...


@dataclass(frozen=True, slots=True)
class CostBreakdown:
    fees: float
    slippage: float

    def __post_init__(self) -> None:
        if self.fees < 0 or self.slippage < 0:
            raise ValueError("Costs must be non-negative.")


#: Zero-cost breakdown for fee- and slippage-free fills.
NO_COST = CostBreakdown(fees=0, slippage=0)


@dataclass(frozen=True)
class Trades:
    trades: tuple[TradeOrder, ...]
    security_alignment: tuple[str, ...]
    backend_mapping_type: type[UniverseMapping]

    @classmethod
    def from_inputs(
        cls,
        trades: Iterable[TradeOrder],
        *,
        security_alignment: Iterable[str],
        backend: str,
    ) -> Self:
        return cls(
            trades=tuple(trades),
            security_alignment=tuple(security_alignment),
            backend_mapping_type=_get_mapping_type_from_backend(backend),
        )

    @cached_property
    def position_delta(self) -> UniverseMapping[int]:
        batched_trades: dict[str, int] = defaultdict(int)
        for t in self.trades:
            batched_trades[t.security] += t.signed_qty

        return self.backend_mapping_type.from_vectors(
            self.security_alignment,
            (batched_trades.get(security, 0) for security in self.security_alignment),
        ).floor()

    def total_cost(self) -> float:
        return sum(trade.cost() for trade in self.trades)

    def with_universe(self, universe: tuple[str, ...]) -> Self:
        return replace(self, security_alignment=universe)


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    before: Portfolio
    after: Portfolio
    costs: CostBreakdown
    fills: Trades | None
    warnings: tuple[str, ...] = ()
