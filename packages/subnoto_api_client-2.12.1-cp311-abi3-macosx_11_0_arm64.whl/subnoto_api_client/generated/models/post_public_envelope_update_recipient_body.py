from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_update_recipient_body_role import PostPublicEnvelopeUpdateRecipientBodyRole
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_envelope_update_recipient_body_updates import PostPublicEnvelopeUpdateRecipientBodyUpdates





T = TypeVar("T", bound="PostPublicEnvelopeUpdateRecipientBody")



@_attrs_define
class PostPublicEnvelopeUpdateRecipientBody:
    """ 
        Attributes:
            envelope_uuid (str): The UUID of the envelope.
            email (str): The email address of the recipient to update.
            role (PostPublicEnvelopeUpdateRecipientBodyRole): The recipient role (used to identify the recipient).
            updates (PostPublicEnvelopeUpdateRecipientBodyUpdates):
            workspace_uuid (str | Unset): Optional. When omitted, the team's default workspace is used.
     """

    envelope_uuid: str
    email: str
    role: PostPublicEnvelopeUpdateRecipientBodyRole
    updates: PostPublicEnvelopeUpdateRecipientBodyUpdates
    workspace_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_envelope_update_recipient_body_updates import PostPublicEnvelopeUpdateRecipientBodyUpdates
        envelope_uuid = self.envelope_uuid

        email = self.email

        role = self.role.value

        updates = self.updates.to_dict()

        workspace_uuid = self.workspace_uuid


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "envelopeUuid": envelope_uuid,
            "email": email,
            "role": role,
            "updates": updates,
        })
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_envelope_update_recipient_body_updates import PostPublicEnvelopeUpdateRecipientBodyUpdates
        d = dict(src_dict)
        envelope_uuid = d.pop("envelopeUuid")

        email = d.pop("email")

        role = PostPublicEnvelopeUpdateRecipientBodyRole(d.pop("role"))




        updates = PostPublicEnvelopeUpdateRecipientBodyUpdates.from_dict(d.pop("updates"))




        workspace_uuid = d.pop("workspaceUuid", UNSET)

        post_public_envelope_update_recipient_body = cls(
            envelope_uuid=envelope_uuid,
            email=email,
            role=role,
            updates=updates,
            workspace_uuid=workspace_uuid,
        )


        post_public_envelope_update_recipient_body.additional_properties = d
        return post_public_envelope_update_recipient_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
