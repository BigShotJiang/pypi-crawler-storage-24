"""Public airfoil API for the Phase 1 refactor."""

__all__ = [
    "Airfoil",
    "AirfoilDefinitionSpec",
    "AirfoilFactory",
    "CstAirfoilSpec",
    "CstSurfaceSpec",
    "Curve",
    "Cylinder",
    "DatAirfoilSpec",
    "Naca4AirfoilClassic",
    "Naca4AirfoilParams",
    "Naca4AirfoilParamsSpec",
    "Naca4AirfoilSpec",
    "Naca4DigitCamber",
    "Naca4ModifiedAirfoilClassic",
    "Naca4ModifiedAirfoilParams",
    "Naca4ModifiedAirfoilParamsSpec",
    "Naca4ModifiedAirfoilSpec",
    "Naca5AirfoilClassic",
    "Naca5AirfoilParams",
    "Naca5AirfoilParamsSpec",
    "Naca5AirfoilSpec",
    "Naca5DigitCamberClassic",
    "Naca5DigitCamberParams",
    "Naca5DigitCamberReflexedClassic",
    "Naca5DigitCamberReflexedParams",
    "Naca5ModifiedAirfoilClassic",
    "Naca5ModifiedAirfoilParams",
    "Naca5ModifiedAirfoilParamsSpec",
    "Naca5ModifiedAirfoilSpec",
    "Naca45DigitModifiedThicknessClassic",
    "Naca45DigitModifiedThicknessParams",
    "Naca45DigitThicknessClassic",
    "Naca45DigitThicknessParams",
    "OrthogonalAirfoil",
]

from .internal.airfoil import Airfoil, OrthogonalAirfoil
from .internal.airfoil_schema import (
    AirfoilDefinitionSpec,
    CstAirfoilSpec,
    CstSurfaceSpec,
    DatAirfoilSpec,
    Naca4AirfoilParamsSpec,
    Naca4AirfoilSpec,
    Naca4ModifiedAirfoilParamsSpec,
    Naca4ModifiedAirfoilSpec,
    Naca5AirfoilParamsSpec,
    Naca5AirfoilSpec,
    Naca5ModifiedAirfoilParamsSpec,
    Naca5ModifiedAirfoilSpec,
)
from .internal.curve import Curve
from .internal.cylinder import Cylinder
from .internal.factory import AirfoilFactory
from .internal.naca4_airfoil import Naca4AirfoilClassic, Naca4AirfoilParams
from .internal.naca4_camber import Naca4DigitCamber
from .internal.naca4_modified_airfoil import (
    Naca4ModifiedAirfoilClassic,
    Naca4ModifiedAirfoilParams,
)
from .internal.naca5_airfoil import Naca5AirfoilClassic, Naca5AirfoilParams
from .internal.naca5_camber import (
    Naca5DigitCamberClassic,
    Naca5DigitCamberParams,
    Naca5DigitCamberReflexedClassic,
    Naca5DigitCamberReflexedParams,
)
from .internal.naca5_modified_airfoil import (
    Naca5ModifiedAirfoilClassic,
    Naca5ModifiedAirfoilParams,
)
from .internal.naca45_modified_thickness import (
    Naca45DigitModifiedThicknessClassic,
    Naca45DigitModifiedThicknessParams,
)
from .internal.naca45_thickness import (
    Naca45DigitThicknessClassic,
    Naca45DigitThicknessParams,
)
