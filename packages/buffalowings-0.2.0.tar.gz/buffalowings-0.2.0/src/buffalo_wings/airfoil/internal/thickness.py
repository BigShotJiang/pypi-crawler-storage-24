"""Compatibility exports for airfoil thickness relations."""

__all__ = [
    "CLASSIC_LEADING_EDGE_INDEX_THRESHOLD",
    "LEADING_EDGE_INDEX_MAX",
    "LEADING_EDGE_INDEX_MIN",
    "LEADING_EDGE_RADIUS_SCALE",
    "MAX_THICKNESS_INDEX_LIMIT",
    "MAX_THICKNESS_LOCATION_MAX",
    "MAX_THICKNESS_LOCATION_MIN",
    "OPEN_MODIFIED_TRAILING_EDGE_THICKNESS",
    "OPEN_TRAILING_EDGE_THICKNESS",
    "Naca45DigitModifiedThicknessClassic",
    "Naca45DigitModifiedThicknessParams",
    "Naca45DigitThicknessClassic",
    "Naca45DigitThicknessParams",
    "NoThickness",
    "Thickness",
]

from .naca45_modified_thickness import (
    Naca45DigitModifiedThicknessClassic,
    Naca45DigitModifiedThicknessParams,
)
from .naca45_thickness import (
    Naca45DigitThicknessClassic,
    Naca45DigitThicknessParams,
)
from .thickness_base import (
    CLASSIC_LEADING_EDGE_INDEX_THRESHOLD,
    LEADING_EDGE_INDEX_MAX,
    LEADING_EDGE_INDEX_MIN,
    LEADING_EDGE_RADIUS_SCALE,
    MAX_THICKNESS_INDEX_LIMIT,
    MAX_THICKNESS_LOCATION_MAX,
    MAX_THICKNESS_LOCATION_MIN,
    OPEN_MODIFIED_TRAILING_EDGE_THICKNESS,
    OPEN_TRAILING_EDGE_THICKNESS,
    NoThickness,
    Thickness,
)
