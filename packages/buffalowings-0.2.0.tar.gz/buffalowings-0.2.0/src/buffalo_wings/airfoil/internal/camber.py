"""Compatibility exports for airfoil camber relations."""

__all__ = [
    "CLASSIC_NACA_5DIGIT_IDEAL_LIFT_INDEX",
    "CLASSIC_NACA_5DIGIT_LIFT_MAX",
    "CLASSIC_NACA_5DIGIT_LIFT_MIN",
    "CLASSIC_NACA_5DIGIT_LOCATION_MAX",
    "CLASSIC_NACA_5DIGIT_LOCATION_MIN",
    "CLASSIC_NACA_5DIGIT_PARAMETERS",
    "CLASSIC_NACA_DIGIT_MAX",
    "REFLEXED_NACA_5DIGIT_PARAMETERS",
    "Camber",
    "Naca4DigitCamber",
    "Naca5DigitCamberClassic",
    "Naca5DigitCamberParams",
    "Naca5DigitCamberReflexedClassic",
    "Naca5DigitCamberReflexedParams",
    "NoCamber",
]

from .camber_base import (
    CLASSIC_NACA_5DIGIT_IDEAL_LIFT_INDEX,
    CLASSIC_NACA_5DIGIT_LIFT_MAX,
    CLASSIC_NACA_5DIGIT_LIFT_MIN,
    CLASSIC_NACA_5DIGIT_LOCATION_MAX,
    CLASSIC_NACA_5DIGIT_LOCATION_MIN,
    CLASSIC_NACA_5DIGIT_PARAMETERS,
    CLASSIC_NACA_DIGIT_MAX,
    REFLEXED_NACA_5DIGIT_PARAMETERS,
    Camber,
    NoCamber,
)
from .naca4_camber import Naca4DigitCamber
from .naca5_camber import (
    Naca5DigitCamberClassic,
    Naca5DigitCamberParams,
    Naca5DigitCamberReflexedClassic,
    Naca5DigitCamberReflexedParams,
)
