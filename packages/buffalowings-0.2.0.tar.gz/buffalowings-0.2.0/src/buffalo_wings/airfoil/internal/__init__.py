"""Internal airfoil implementation modules."""
