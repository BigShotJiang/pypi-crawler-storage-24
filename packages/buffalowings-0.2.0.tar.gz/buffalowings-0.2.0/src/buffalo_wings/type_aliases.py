"""Typing information needed for use with this library."""

import collections.abc
import typing

import numpy as np
from numpy.typing import NDArray

FloatScalar = float | np.floating[typing.Any]
"""
Scalar floating-point input accepted by public APIs.
"""

FloatArray = NDArray[np.float64]
"""
NumPy array with ``float64`` dtype used for array-only APIs.
"""

FloatInput = (
    FloatScalar
    | collections.abc.Sequence[FloatScalar]
    | NDArray[np.floating[typing.Any]]
)
"""
Input alias for scalar, sequence, or NumPy floating array parameters.
"""

__all__ = ["FloatArray", "FloatInput", "FloatScalar"]
