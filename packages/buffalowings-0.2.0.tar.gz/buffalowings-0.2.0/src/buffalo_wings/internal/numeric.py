"""Shared internal numeric normalization helpers."""

from __future__ import annotations

import numpy as np

from buffalo_wings.type_aliases import FloatArray, FloatInput


def as_float_array(value: FloatInput) -> FloatArray:
    """Normalize numeric input to a float64 NumPy array."""
    return np.asarray(value, dtype=np.float64)


def as_float_scalar(value: FloatInput) -> float:
    """Normalize a scalar-like numeric value to a Python float."""
    return float(as_float_array(value).item())
