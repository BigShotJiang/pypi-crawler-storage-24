"""Internal helper functions for module."""
