"""
Tools and libraries for constructing airfoils, wings, and other related shapes.

This is a Python based project that provides tools and libraries that can be
used to construct airfoils, wings, and other related geometries.
It is not intended to be a general CAD tool/library, but it is focused on
creating general shapes such as NURBS or point distributions from aerodynamic
specific inputs.

The main geometry APIs live in the :mod:`buffalo_wings.airfoil` and
:mod:`buffalo_wings.wing` subpackages.
Shared numeric aliases live in :mod:`buffalo_wings.type_aliases`.
"""

from . import airfoil, type_aliases, wing

__version__ = "0.2.0"

__all__ = ["__version__", "airfoil", "type_aliases", "wing"]
