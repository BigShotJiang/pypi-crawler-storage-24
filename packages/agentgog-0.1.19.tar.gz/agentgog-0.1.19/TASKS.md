# agentgog tasks/status

This file tracks what’s implemented and working.

## Project goal

Turn short messages into actions by:
- Classifying them into **CALENDAR**, **TASK**, **MEMO**
- Extracting structured details
- Sending them to external systems (Calendar / Tasks / notes)

## Current functionality (working)

### CLI commands

- `agentgog classify "..."`
  - Runs the classifier and triggers the relevant action:
    - `CALENDAR` → Google Calendar insert
    - `TASK` → Google Tasks insert (tries list name `My Tasks`, otherwise falls back to `@default`)
    - `MEMO` → Simplenote note creation
  - Supports provider switch: `-p openrouter|ollama`

- `agentgog chat "..."`
  - General chat.
  - Supports provider switch: `-p openrouter|ollama`
  - `-i` starts interactive mode with:
    - Conversation memory (in-memory)
    - Line editing + persistent command history via `prompt_toolkit` (`~/.agentgog_history`)
    - Commands: `/q` quit, `/c` clear history, `/mf` free models, `/mp` paid models, `/mx` preferred models

- `agentgog translator -s file.srt -m <model>`
  - SRT → Czech translation using `smolagents` (OpenRouter only).

- `agentgog qrpayment "..." -m <model>`
  - Generates a QR payment code (OpenRouter only).

- `agentgog codeagent "..."`
   - Runs a CodeAgent flow with code execution and tool use.
   - `-m <model>` optional: uses provider default if not specified (openrouter: `x-ai/grok-4.1-fast`, ollama: `llama3.2`)
   - Supports provider switch: `-p openrouter|ollama`
   - `--max-steps` configurable (default: 10)

- `agentgog compare -f <file> -e <expected.yaml>`
   - Semantically compares a result file with expected result from YAML.
   - Returns: `same` | `similar` | `differ`
   - Supports provider switch: `-p openrouter|ollama`
   - `-o <file>` to save output to file

### Providers

- **OpenRouter** (default)
  - Uses `OPENROUTER_API_KEY` (or `~/.openai_openrouter.key`).

- **Ollama** (local)
  - `-p ollama`
  - Enhanced error handling suggests installed models when the requested model is missing.

### Integrations

- **Google Calendar**
  - OAuth credentials file: `~/.config/google/credentials.json`
  - Token cache: `~/.config/google/token.json`
  - Inserts event into `primary` calendar.

- **Google Tasks**
  - Uses the same token file (`~/.config/google/token.json`).
  - Important: token must include Tasks scope.

- **Simplenote (MEMO)**
  - Requires environment variables:
    - `SIMPLENOTE_LOCAL_USER`
    - `SIMPLENOTE_LOCAL_PASSWORD`

## Known constraints / notes

- If you change Google OAuth scopes (e.g. add Tasks), delete token and re-auth:
   - `rm -f ~/.config/google/token.json`

- Some utilities (translator/qrpayment) are OpenRouter-only today.

- **CodeAgent limitations:**
  - Google Gemini models (google/gemini-2.5-flash, google/gemini-2.5-pro, etc.) may fail with 401 "cookie auth" errors
    - These models require direct Google authentication which is incompatible with OpenRouter's OpenAI-compatible API
    - Recommended alternatives: `google/gemma-3-27b-it:free`, `xiaomi/mimo-v2-flash:free`, `nex-agi/deepseek-v3.1-nex-n1:free`
  - Requires `OPENROUTER_API_KEY` environment variable to be set when using OpenRouter provider

## Recently added

- **compare command** - Semantic comparison of results against expected values
- **Interactive chat improvements** - `/mf` and `/mp` commands to list free/paid models, `/mx` to list preferred models
- **CodeAgent** - Full tool use and code execution capabilities
- **File I/O support** - `-f` and `-o` options for reading prompts from files and saving outputs

## Not yet implemented / planned

- No persistent conversation storage (chat history is in-memory only)
- No batch processing mode for classify command
- No configuration file support (all config via env vars or CLI args)
- No built-in scheduling/reminders (relies on external calendar)

## Useful one-liners

```bash
# Calendar
uv run agentgog classify "Meeting tomorrow at 10am"

# Task
uv run agentgog classify "Buy groceries tomorrow"

# Memo
uv run agentgog classify "Remember that my passport number is 123456789"

# Chat interactive
uv run agentgog chat -i

# CodeAgent with default model
uv run agentgog codeagent "Write a function to calculate fibonacci"

# CodeAgent with custom model
uv run agentgog codeagent "Solve a math problem" -m google/gemma-3-27b-it:free

# CodeAgent with Ollama
uv run agentgog codeagent "Create a web scraper" -p ollama -m llama3.2

# Compare result with expected
uv run agentgog compare -f result.txt -e expected.yaml
```
