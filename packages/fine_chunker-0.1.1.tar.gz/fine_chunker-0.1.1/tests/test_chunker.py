import pytest

from fine_chunker import Chunker, ChunkerType


def test_single_word_chunking_all_backends(available_backends, model_path, sample_text):
    """
    Smoke test to verify that backends initialize correctly
    and handle minimum input length (single word).
    """
    if not available_backends:
        pytest.skip("No backends installed (torch or onnx). Skipping integration test.")

    for backend in available_backends:
        print(f"\n[INFO] Testing backend: {backend}")

        try:
            chunker = Chunker.from_pretrained(
                type=ChunkerType.RECURSIVE,
                model_path=model_path,
                use_onnx=(backend == "onnx"),
                device="cpu",
            )

            chunks = chunker.chunk(sample_text)

            assert len(chunks) == 1, (
                f"Backend '{backend}' failed: expected exactly 1 chunk for a single word, got {len(chunks)}"
            )
            assert chunks[0].content.strip() == sample_text, (
                f"Backend '{backend}' failed: chunk content mismatch"
            )
            assert chunks[0].index == 0, (
                f"Backend '{backend}' failed: incorrect chunk index"
            )

            print(f"[SUCCESS] Backend {backend} passed.")

        except Exception as e:
            if backend == "onnx" and "Could not find" in str(e):
                print(
                    f"[SKIP] ONNX runtime assets (model.onnx/tokenizer.json) not found on HF Hub at {model_path}."
                )
                continue

            print(f"[ERROR] Backend {backend} failed with exception: {str(e)}")
            raise e
