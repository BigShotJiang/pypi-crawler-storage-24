from pathlib import Path

import pytest

TEST_DIR = Path(__file__).parent.absolute()
ROOT_DIR = TEST_DIR.parent
FIX_DIR = TEST_DIR / "fixtures"

HF_REPO = "jboksa/modbert-chunker-base"


@pytest.fixture(scope="session")
def model_path():
    return HF_REPO


@pytest.fixture(scope="session")
def fixture_path():
    if not FIX_DIR.exists():
        FIX_DIR.mkdir(parents=True, exist_ok=True)
    return FIX_DIR


@pytest.fixture(scope="session")
def sample_text():
    return "ModernBERT"


@pytest.fixture(scope="session")
def available_backends():
    backends = []
    try:
        import torch

        backends.append("torch")
    except ImportError:
        pass
    try:
        import onnxruntime

        backends.append("onnx")
    except ImportError:
        pass
    return backends


def pytest_configure(config):
    config.addinivalue_line("markers", "torch: marks tests that require torch")
    config.addinivalue_line("markers", "onnx: marks tests that require onnx")
