from abc import ABC, abstractmethod
from typing import List

from fine_chunker.types import Chunk


class BaseEngine(ABC):
    """Abstract base class for all chunking engine implementations."""

    def __init__(self, device: str):
        self.device = device

    @abstractmethod
    def chunk(self, text: str) -> List[Chunk]:
        """Split text into semantic chunks."""
        pass
