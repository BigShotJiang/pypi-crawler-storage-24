from abc import ABC, abstractmethod
from typing import Any, Dict, List


class BaseChunkingModel(ABC):
    @abstractmethod
    def predict(self, input_ids: List[int], threshold: float) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def tokenize_and_predict(self, text: str, threshold: float = 0.5) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def decode(self, token_ids: List[int]) -> str:
        raise NotImplementedError

    @abstractmethod
    def max_length(self) -> int:
        raise NotImplementedError

    @abstractmethod
    def tokenize(self, text: str, **kwargs) -> Any:
        raise NotImplementedError
