from dataclasses import dataclass


@dataclass
class Chunk:
    """Represents a single segment of text with its metadata."""

    index: int
    content: str
