"""Utility modules for FlaschenTaschen."""
