"""
AAP SDK Test Suite — 100% coverage of the 4 primitives.
Run: pytest tests/ -v
"""
import json
import pytest
from datetime import datetime, timezone, timedelta
from aap import (
    AAPIdentity, AAPKeyPair, AAPAuthorization, AuthorizationLevel,
    AAPProvenance, AAPAuditChain,
    AAPPhysicalWorldViolation, AAPValidationError, AAPSignatureError, AAPRevocationError
)


# ─── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def supervisor_keypair():
    return AAPKeyPair.generate()

@pytest.fixture
def agent_keypair():
    return AAPKeyPair.generate()

@pytest.fixture
def identity(supervisor_keypair, agent_keypair):
    return AAPIdentity.create(
        id="aap://acme/worker/test-bot@0.0.1",
        scope=["read:files", "write:files", "exec:deploy"],
        agent_keypair=agent_keypair,
        parent_keypair=supervisor_keypair,
        parent_did="did:key:z6Mktest",
    )

@pytest.fixture
def authorization(supervisor_keypair, identity):
    return AAPAuthorization.create(
        agent_id=identity.id,
        level=AuthorizationLevel.SUPERVISED,
        scope=["write:files"],
        supervisor_keypair=supervisor_keypair,
        supervisor_did="did:key:z6MkTest",
        physical=False,
    )


# ─── IDENTITY ────────────────────────────────────────────────────────────────

class TestIdentity:

    def test_create_valid_identity(self, identity):
        assert identity.id == "aap://acme/worker/test-bot@0.0.1"
        assert identity.public_key.startswith("ed25519:")
        assert identity.signature.startswith("ed25519:")
        assert "read:files" in identity.scope

    def test_invalid_id_format_raises(self, supervisor_keypair, agent_keypair):
        with pytest.raises(AAPValidationError, match="Invalid identity id format"):
            AAPIdentity.create(
                id="not-valid",
                scope=["read:files"],
                agent_keypair=agent_keypair,
                parent_keypair=supervisor_keypair,
                parent_did="did:key:z6MkTest",
            )

    def test_empty_scope_raises(self):
        with pytest.raises(AAPValidationError):
            AAPIdentity(
                id="aap://acme/worker/bot@1.0.0",
                public_key="ed25519:test",
                parent="did:key:z6MkTest",
                scope=[],
                issued_at=datetime.now(timezone.utc),
                signature="ed25519:test",
            )

    def test_allows_action(self, identity):
        assert identity.allows_action("read:files") is True
        assert identity.allows_action("delete:files") is False

    def test_allows_wildcard_scope(self, supervisor_keypair, agent_keypair):
        ident = AAPIdentity.create(
            id="aap://acme/worker/wild@1.0.0",
            scope=["read:*"],
            agent_keypair=agent_keypair,
            parent_keypair=supervisor_keypair,
            parent_did="did:key:z6MkTest",
        )
        assert ident.allows_action("read:anything") is True
        assert ident.allows_action("write:anything") is False

    def test_serialization_roundtrip(self, identity):
        restored = AAPIdentity.from_dict(identity.to_dict())
        assert restored.id == identity.id
        assert restored.scope == identity.scope
        assert restored.signature == identity.signature

    def test_revoked_identity_raises_on_verify(self, identity, supervisor_keypair):
        identity.revoked = True
        with pytest.raises(AAPRevocationError):
            identity.verify_signature(supervisor_keypair.public_key_b64)

    def test_wrong_key_raises_signature_error(self, identity):
        wrong_key = AAPKeyPair.generate()
        with pytest.raises(AAPSignatureError):
            identity.verify_signature(wrong_key.public_key_b64)

    def test_correct_key_verifies(self, identity, supervisor_keypair):
        identity.verify_signature(supervisor_keypair.public_key_b64)


# ─── AUTHORIZATION ────────────────────────────────────────────────────────────

class TestAuthorization:

    def test_create_valid_authorization(self, authorization):
        assert authorization.level == AuthorizationLevel.SUPERVISED
        assert authorization.is_valid() is True

    def test_physical_world_rule_autonomous_forbidden(self, supervisor_keypair):
        """CRITICAL: Level 4 on physical node MUST be rejected."""
        with pytest.raises(AAPPhysicalWorldViolation) as exc_info:
            AAPAuthorization.create(
                agent_id="aap://factory/robot/arm@1.0.0",
                level=AuthorizationLevel.AUTONOMOUS,
                scope=["move:arm"],
                supervisor_keypair=supervisor_keypair,
                supervisor_did="did:key:z6MkTest",
                physical=True,
            )
        assert "AAP-003" in exc_info.value.code

    def test_physical_supervised_is_allowed(self, supervisor_keypair):
        auth = AAPAuthorization.create(
            agent_id="aap://factory/robot/arm@1.0.0",
            level=AuthorizationLevel.SUPERVISED,
            scope=["move:arm"],
            supervisor_keypair=supervisor_keypair,
            supervisor_did="did:key:z6MkTest",
            physical=True,
        )
        assert auth.level == AuthorizationLevel.SUPERVISED

    def test_digital_autonomous_is_allowed(self, supervisor_keypair):
        auth = AAPAuthorization.create(
            agent_id="aap://acme/worker/bot@1.0.0",
            level=AuthorizationLevel.AUTONOMOUS,
            scope=["read:files"],
            supervisor_keypair=supervisor_keypair,
            supervisor_did="did:key:z6MkTest",
            physical=False,
        )
        assert auth.level == AuthorizationLevel.AUTONOMOUS

    def test_revoke_invalidates(self, authorization):
        authorization.revoke()
        assert authorization.is_valid() is False
        with pytest.raises(AAPRevocationError):
            authorization.check()

    def test_expired_is_invalid(self, supervisor_keypair):
        past = datetime.now(timezone.utc) - timedelta(seconds=1)
        auth = AAPAuthorization.create(
            agent_id="aap://acme/worker/bot@1.0.0",
            level=AuthorizationLevel.OBSERVE,
            scope=["read:files"],
            supervisor_keypair=supervisor_keypair,
            supervisor_did="did:key:z6MkTest",
            expires_at=past,
        )
        assert auth.is_expired() is True

    def test_serialization_roundtrip(self, authorization):
        restored = AAPAuthorization.from_dict(authorization.to_dict())
        assert restored.agent_id == authorization.agent_id
        assert restored.level == authorization.level


# ─── PROVENANCE ───────────────────────────────────────────────────────────────

class TestProvenance:

    def test_create_provenance(self, agent_keypair, identity, authorization):
        prov = AAPProvenance.create(
            agent_id=identity.id,
            action="write:file",
            input_data=b"deploy instruction",
            output_data=b"deployment result",
            authorization_id=authorization.session_id,
            agent_keypair=agent_keypair,
            target="/app/deploy.sh",
        )
        assert prov.input_hash.startswith("sha256:")
        assert prov.output_hash.startswith("sha256:")
        assert prov.action == "write:file"

    def test_same_input_same_hash(self, agent_keypair, identity, authorization):
        kwargs = dict(
            agent_id=identity.id, action="read:file",
            input_data=b"same", output_data=b"same",
            authorization_id=authorization.session_id,
            agent_keypair=agent_keypair,
        )
        p1 = AAPProvenance.create(**kwargs)
        p2 = AAPProvenance.create(**kwargs)
        assert p1.input_hash == p2.input_hash

    def test_verify_signature(self, agent_keypair, identity, authorization):
        prov = AAPProvenance.create(
            agent_id=identity.id, action="read:file",
            input_data=b"x", output_data=b"y",
            authorization_id=authorization.session_id,
            agent_keypair=agent_keypair,
        )
        prov.verify_signature(agent_keypair.public_key_b64)

    def test_serialization_roundtrip(self, agent_keypair, identity, authorization):
        prov = AAPProvenance.create(
            agent_id=identity.id, action="exec:deploy",
            input_data=b"cmd", output_data=b"ok",
            authorization_id=authorization.session_id,
            agent_keypair=agent_keypair,
            target="/bin/deploy",
        )
        restored = AAPProvenance.from_dict(prov.to_dict())
        assert restored.artifact_id == prov.artifact_id
        assert restored.input_hash == prov.input_hash


# ─── AUDIT CHAIN ──────────────────────────────────────────────────────────────

class TestAuditChain:

    def test_empty_chain_is_valid(self):
        valid, count, broken = AAPAuditChain().verify()
        assert valid is True
        assert count == 0

    def test_append_and_verify(self, agent_keypair):
        chain = AAPAuditChain()
        chain.append(
            agent_id="aap://acme/worker/bot@1.0.0",
            action="write:file", result="success",
            provenance_id="00000000-0000-0000-0000-000000000001",
            agent_keypair=agent_keypair,
        )
        valid, count, _ = chain.verify()
        assert valid is True
        assert count == 1

    def test_chain_grows_correctly(self, agent_keypair):
        chain = AAPAuditChain()
        for i in range(5):
            chain.append(
                agent_id="aap://acme/worker/bot@1.0.0",
                action=f"read:file{i}", result="success",
                provenance_id=f"00000000-0000-0000-0000-00000000000{i}",
                agent_keypair=agent_keypair,
            )
        valid, count, _ = chain.verify()
        assert valid is True
        assert count == 5

    def test_tampered_chain_is_invalid(self, agent_keypair, tmp_path):
        path = tmp_path / "audit.jsonl"
        chain = AAPAuditChain(storage_path=path)
        for i in range(2):
            chain.append(
                agent_id="aap://acme/worker/bot@1.0.0",
                action=f"write:file{i}", result="success",
                provenance_id=f"00000000-0000-0000-0000-00000000000{i}",
                agent_keypair=agent_keypair,
            )
        # Falsify first entry in JSONL file
        lines = [l for l in path.read_text().splitlines() if l.strip()]
        entry = json.loads(lines[0])
        entry["action"] = "delete:everything"
        lines[0] = json.dumps(entry)
        path.write_text("\n".join(lines) + "\n")
        # Reload — chain must be broken
        chain2 = AAPAuditChain(storage_path=path)
        valid, count, broken = chain2.verify()
        assert valid is False
        assert broken is not None

    def test_genesis_entry_prev_hash(self, agent_keypair):
        chain = AAPAuditChain()
        entry = chain.append(
            agent_id="aap://acme/worker/bot@1.0.0",
            action="read:file", result="success",
            provenance_id="00000000-0000-0000-0000-000000000001",
            agent_keypair=agent_keypair,
        )
        assert entry.prev_hash == "genesis"

    def test_blocked_result(self, agent_keypair):
        chain = AAPAuditChain()
        entry = chain.append(
            agent_id="aap://factory/robot/arm@1.0.0",
            action="move:arm", result="blocked",
            provenance_id="00000000-0000-0000-0000-000000000001",
            agent_keypair=agent_keypair,
            physical=True,
            result_detail="Shield rule: force > 50N",
        )
        assert entry.result == "blocked"
        assert entry.physical is True

    def test_persistence_and_reload(self, agent_keypair, tmp_path):
        path = tmp_path / "audit.jsonl"
        chain = AAPAuditChain(storage_path=path)
        chain.append(
            agent_id="aap://acme/worker/bot@1.0.0",
            action="write:file", result="success",
            provenance_id="00000000-0000-0000-0000-000000000001",
            agent_keypair=agent_keypair,
        )
        chain2 = AAPAuditChain(storage_path=path)
        assert len(chain2) == 1
        valid, count, _ = chain2.verify()
        assert valid is True
