"""Command result models for structured output.

Provides dataclasses for capturing and serializing command execution
results in JSON/CSV formats. These models ensure consistent output
across all commands that support structured output.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from confiture.core.migration_verifier import VerifyResult
    from confiture.models.schema import SchemaChange, SchemaDiff


class MigrationStatus:
    """Constants for migration status values.

    Use these instead of raw strings for reliable comparisons::

        if info.status == MigrationStatus.APPLIED:
            ...
    """

    APPLIED = "applied"
    PENDING = "pending"
    UNKNOWN = "unknown"


@dataclass
class MigrationInfo:
    """Status of a single migration file.

    Used in StatusResult to represent each migration and whether it
    has been applied, is pending, or has unknown status (no DB connection).
    """

    version: str
    name: str
    status: str  # "applied" | "pending" | "unknown"
    applied_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "version": self.version,
            "name": self.name,
            "status": self.status,
            "applied_at": self.applied_at.isoformat() if self.applied_at is not None else None,
        }


@dataclass
class StatusResult:
    """Result of migrate status operation."""

    migrations: list[MigrationInfo]
    tracking_table_exists: bool
    tracking_table: str
    summary: dict[str, int]  # {"applied": N, "pending": N, "total": N}
    rebuild_recommended: bool = False
    rebuild_reasons: list[str] = field(default_factory=list)

    @property
    def pending(self) -> list[str]:
        """Versions of pending migrations."""
        return [m.version for m in self.migrations if m.status == "pending"]

    @property
    def applied(self) -> list[str]:
        """Versions of applied migrations."""
        return [m.version for m in self.migrations if m.status == "applied"]

    @property
    def has_pending(self) -> bool:
        """True if any migrations are pending."""
        return any(m.status == "pending" for m in self.migrations)

    def get_migration(self, version: str) -> MigrationInfo | None:
        """Get migration info by version, or None if not found."""
        for m in self.migrations:
            if m.version == version:
                return m
        return None

    def get_status(self, version: str) -> str | None:
        """Get status of a migration ("applied", "pending", "unknown"), or None."""
        m = self.get_migration(version)
        return m.status if m else None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "tracking_table": self.tracking_table,
            "tracking_table_exists": self.tracking_table_exists,
            "migrations": [m.to_dict() for m in self.migrations],
            "summary": self.summary,
            "rebuild_recommended": self.rebuild_recommended,
            "rebuild_reasons": self.rebuild_reasons,
        }


@dataclass
class BuildResult:
    """Result of schema build operation.

    Tracks success/failure, files processed, size, timing, and any
    warnings or errors that occurred during build.
    """

    success: bool
    files_processed: int
    schema_size_bytes: int
    output_path: str
    hash: str | None = None
    execution_time_ms: int = 0
    seed_files_applied: int = 0
    warnings: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "success": self.success,
            "files_processed": self.files_processed,
            "schema_size_bytes": self.schema_size_bytes,
            "output_path": self.output_path,
            "hash": self.hash,
            "execution_time_ms": self.execution_time_ms,
            "seed_files_applied": self.seed_files_applied,
            "warnings": self.warnings,
            "error": self.error,
        }


@dataclass
class MigrationApplied:
    """Single migration that was applied.

    Tracks version, name, execution time, and rows affected.
    """

    version: str
    name: str
    execution_time_ms: int
    rows_affected: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "version": self.version,
            "name": self.name,
            "duration_ms": self.execution_time_ms,
            "rows_affected": self.rows_affected,
        }


@dataclass
class MigrateUpResult:
    """Result of migrate up operation.

    Attributes:
        success: True if all migrations applied successfully, False if any failed.

        migrations_applied: List of migrations that were successfully applied.
                           Each includes version, name, execution_time_ms, rows_affected.
                           (Serialized as "applied" in to_dict() output.)

        total_execution_time_ms: Total time in milliseconds.
                                (Serialized as "total_duration_ms" in to_dict() output.)

        checksums_verified: True if all applied migrations passed checksum verification.

        dry_run: True if this was a dry-run analysis (no SQL executed).

        warnings: List of non-fatal warning messages. Empty if no warnings.

        skipped: List of migration versions that were already applied.
                Empty if no previously-applied migrations were encountered.

        errors: List of error messages if success=False. Each string is a human-readable
               error description. Empty list if success=True.
    """

    success: bool
    migrations_applied: list[MigrationApplied]
    total_execution_time_ms: int
    checksums_verified: bool = True
    dry_run: bool = False
    warnings: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        """True if operation had errors (success=False and errors non-empty)."""
        return not self.success and len(self.errors) > 0

    @property
    def error_summary(self) -> str | None:
        """First error message, or None if no errors. Convenience for logging."""
        return self.errors[0] if self.errors else None

    def by_version(self, version: str) -> MigrationApplied | None:
        """Get applied migration by version, or None if not in this operation."""
        for m in self.migrations_applied:
            if m.version == version:
                return m
        return None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "success": self.success,
            "applied": [m.to_dict() for m in self.migrations_applied],
            "skipped": self.skipped,
            "errors": self.errors,
            "total_duration_ms": self.total_execution_time_ms,
            "checksums_verified": self.checksums_verified,
            "dry_run": self.dry_run,
            "warnings": self.warnings,
        }


@dataclass
class MigrateReinitResult:
    """Result of migrate reinit operation.

    Tracks how many tracking entries were deleted, which migrations
    were re-marked as applied, and any warnings or errors.
    """

    success: bool
    deleted_count: int
    migrations_marked: list[MigrationApplied]
    total_execution_time_ms: int
    dry_run: bool = False
    warnings: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "success": self.success,
            "deleted_count": self.deleted_count,
            "marked": [m.to_dict() for m in self.migrations_marked],
            "total_duration_ms": self.total_execution_time_ms,
            "dry_run": self.dry_run,
            "warnings": self.warnings,
            "error": self.error,
        }


@dataclass
class MigrateDownResult:
    """Result of migrate down operation.

    Tracks which migrations were rolled back, total execution time,
    and any warnings or errors that occurred.
    """

    success: bool
    migrations_rolled_back: list[MigrationApplied]
    total_execution_time_ms: int
    checksums_verified: bool = True
    warnings: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "success": self.success,
            "rolled_back": [m.to_dict() for m in self.migrations_rolled_back],
            "total_duration_ms": self.total_execution_time_ms,
            "checksums_verified": self.checksums_verified,
            "warnings": self.warnings,
            "error": self.error,
        }


@dataclass
class MigrateRebuildResult:
    """Result of migrate rebuild operation.

    Tracks schema cleanup, DDL application, tracking bootstrap,
    optional seed application, and post-rebuild verification.
    """

    success: bool
    schemas_dropped: list[str]
    ddl_statements_executed: int
    migrations_marked: list[MigrationApplied]
    total_execution_time_ms: int
    dry_run: bool = False
    warnings: list[str] = field(default_factory=list)
    error: str | None = None
    seeds_applied: int | None = None
    verified: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "success": self.success,
            "schemas_dropped": self.schemas_dropped,
            "ddl_statements_executed": self.ddl_statements_executed,
            "marked": [m.to_dict() for m in self.migrations_marked],
            "total_duration_ms": self.total_execution_time_ms,
            "dry_run": self.dry_run,
            "warnings": self.warnings,
            "error": self.error,
            "seeds_applied": self.seeds_applied,
            "verified": self.verified,
        }


@dataclass
class MigrateDiffChange:
    """A single schema change detected in diff.

    Tracks the type of change and details about what changed.
    """

    change_type: str
    details: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "type": self.change_type,
            "details": self.details,
        }


@dataclass
class MigrateDiffResult:
    """Result of schema diff operation.

    Tracks differences between two schemas and whether a migration
    was generated from the diff.
    """

    success: bool
    has_changes: bool
    changes: list[MigrateDiffChange] = field(default_factory=list)
    migration_generated: bool = False
    migration_file: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "success": self.success,
            "has_changes": self.has_changes,
            "changes": [c.to_dict() for c in self.changes],
            "change_count": len(self.changes),
            "migration_generated": self.migration_generated,
            "migration_file": self.migration_file,
            "error": self.error,
        }


@dataclass
class MigrateValidateResult:
    """Result of migration validation operation.

    Tracks validation checks performed and any issues found.
    """

    success: bool
    orphaned_files: list[str] = field(default_factory=list)
    duplicate_versions: dict[str, list[str]] = field(default_factory=dict)
    fixed_files: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "success": self.success,
            "orphaned_files": self.orphaned_files,
            "orphaned_files_count": len(self.orphaned_files),
            "duplicate_versions": self.duplicate_versions,
            "duplicate_versions_count": len(self.duplicate_versions),
            "fixed_files": self.fixed_files,
            "fixed_files_count": len(self.fixed_files),
            "warnings": self.warnings,
            "error": self.error,
        }


@dataclass
class ConversionResult:
    """Result of converting a single INSERT statement to COPY format.

    Tracks whether conversion was successful, the converted output,
    number of rows converted, or failure reason if conversion failed.
    """

    file_path: str
    success: bool
    copy_format: str | None = None
    rows_converted: int | None = None
    reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "file_path": self.file_path,
            "success": self.success,
            "copy_format": self.copy_format,
            "rows_converted": self.rows_converted,
            "reason": self.reason,
        }


@dataclass
class ConversionReport:
    """Report of batch INSERT to COPY conversion.

    Aggregates results from converting multiple seed files,
    tracking success/failure counts and providing overall metrics.
    """

    total_files: int
    successful: int
    failed: int
    results: list[ConversionResult] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Calculate success rate as percentage.

        Returns:
            Percentage of successful conversions (0-100).
        """
        if self.total_files == 0:
            return 0.0
        return (self.successful / self.total_files) * 100

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with all fields suitable for JSON output.
        """
        return {
            "total_files": self.total_files,
            "successful": self.successful,
            "failed": self.failed,
            "success_rate": self.success_rate,
            "results": [r.to_dict() for r in self.results],
        }


@dataclass
class VerifyAllResult:
    """Result of verifying all applied migrations.

    Attributes:
        results: Individual VerifyResult for each migration
        verified_count: Number of migrations that passed verification
        failed_count: Number of migrations that failed verification
        skipped_count: Number of applied migrations with no verify file
        total_applied: Total number of applied migrations checked
    """

    results: list[VerifyResult]
    verified_count: int
    failed_count: int
    skipped_count: int
    total_applied: int

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "verified_count": self.verified_count,
            "failed_count": self.failed_count,
            "skipped_count": self.skipped_count,
            "total_applied": self.total_applied,
            "results": [
                {
                    "version": r.version,
                    "name": r.name,
                    "status": r.status,
                    "actual_value": r.actual_value,
                    "verify_file": str(r.verify_file) if r.verify_file else None,
                    "error": r.error,
                }
                for r in self.results
            ],
        }


@dataclass
class DiffResult:
    """Result of a schema diff operation."""

    has_changes: bool
    changes: list[SchemaChange]

    @classmethod
    def from_schema_diff(cls, diff: SchemaDiff) -> DiffResult:
        """Construct from a SchemaDiff object."""
        return cls(has_changes=diff.has_changes(), changes=diff.changes)

    def _build_summary(self) -> dict[str, int]:
        changes = self.changes
        return {
            "tables_added": sum(1 for c in changes if c.type == "ADD_TABLE"),
            "tables_dropped": sum(1 for c in changes if c.type == "DROP_TABLE"),
            "tables_renamed": sum(1 for c in changes if c.type == "RENAME_TABLE"),
            "columns_added": sum(1 for c in changes if c.type == "ADD_COLUMN"),
            "columns_dropped": sum(1 for c in changes if c.type == "DROP_COLUMN"),
            "indexes_added": sum(1 for c in changes if c.type == "ADD_INDEX"),
            "indexes_dropped": sum(1 for c in changes if c.type == "DROP_INDEX"),
            "foreign_keys_added": sum(1 for c in changes if c.type == "ADD_FOREIGN_KEY"),
            "foreign_keys_dropped": sum(1 for c in changes if c.type == "DROP_FOREIGN_KEY"),
            "constraints_added": sum(
                1 for c in changes if c.type in ("ADD_CHECK_CONSTRAINT", "ADD_UNIQUE_CONSTRAINT")
            ),
            "constraints_dropped": sum(
                1 for c in changes if c.type in ("DROP_CHECK_CONSTRAINT", "DROP_UNIQUE_CONSTRAINT")
            ),
            "enum_types_added": sum(1 for c in changes if c.type == "ADD_ENUM_TYPE"),
            "enum_types_dropped": sum(1 for c in changes if c.type == "DROP_ENUM_TYPE"),
            "sequences_added": sum(1 for c in changes if c.type == "ADD_SEQUENCE"),
            "sequences_dropped": sum(1 for c in changes if c.type == "DROP_SEQUENCE"),
        }

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for JSON output."""
        return {
            "has_changes": self.has_changes,
            "summary": self._build_summary(),
            "changes": [
                {
                    "type": c.type,
                    "table": c.table,
                    "column": c.column,
                    "old_value": c.old_value,
                    "new_value": c.new_value,
                    "details": c.details,
                }
                for c in self.changes
            ],
        }
