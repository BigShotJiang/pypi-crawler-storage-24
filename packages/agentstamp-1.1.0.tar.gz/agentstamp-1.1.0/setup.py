from setuptools import setup

setup(
    name="agentstamp",
    version="1.1.0",
    description="AgentStamp identity lifecycle for Python AI agents (CrewAI, AutoGen, etc.)",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Vinay Bhosle",
    author_email="vinay@agentstamp.org",
    url="https://agentstamp.org",
    py_modules=["agentstamp_crewai"],
    install_requires=["requests>=2.20.0"],
    python_requires=">=3.8",
    license="MIT",
    keywords=["agentstamp", "ai-agents", "crewai", "identity", "trust", "verification"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
