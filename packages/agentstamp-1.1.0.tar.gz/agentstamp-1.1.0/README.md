# agentstamp

Identity lifecycle SDK for Python AI agents. Works with CrewAI, AutoGen, LangGraph, and any Python agent framework.

Register your agent, mint trust stamps, send heartbeats, and auto-renew — in 3 lines.

## Install

```bash
pip install agentstamp
```

## Quick Start

```python
from agentstamp_crewai import AgentStampLifecycle

lifecycle = AgentStampLifecycle(
    wallet_address="0xYourWalletAddress",
    name="MyAgent",
    description="What your agent does",
    category="research",
)
lifecycle.start()  # stamps + registers + heartbeats + auto-renew
```

That's it. Your agent now has:
- A cryptographic identity stamp (Ed25519)
- A public registry listing
- Heartbeat-based uptime reputation
- Auto-renewal before expiry

## Verify Other Agents

```python
trust = lifecycle.check_trust("0xOtherAgentWallet")
if trust.get("trusted"):
    print(f"Verified: {trust['agent']['name']} (score: {trust['reputation']['score']})")
else:
    print("Unverified agent — proceed with caution")
```

## Gate Functions Behind Verification

```python
from agentstamp_crewai import stamp_verified

@stamp_verified(lifecycle)
def sensitive_operation(data: str) -> str:
    """Only runs if the agent is AgentStamp verified."""
    return process(data)
```

## CrewAI Integration

```python
from crewai import Agent, Task, Crew
from agentstamp_crewai import AgentStampLifecycle

# Start lifecycle
lifecycle = AgentStampLifecycle(
    wallet_address="0x...",
    name="ResearchBot",
    description="Finds and summarizes papers",
    category="research",
)
lifecycle.start()

# Create CrewAI agent as normal
agent = Agent(
    role="Researcher",
    goal="Find relevant papers",
    backstory="Expert research assistant",
)

# Check trust before collaborating with other agents
trust = lifecycle.check_trust("0xCollaboratorWallet")
```

## Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `wallet_address` | required | Your agent's wallet address (EVM or Solana) |
| `name` | required | Agent display name |
| `description` | required | What your agent does |
| `category` | `"other"` | `research`, `trading`, `social`, `infrastructure`, etc. |
| `heartbeat_interval` | `300` | Seconds between heartbeats |
| `renew_before_days` | `2` | Days before expiry to auto-renew |
| `verbose` | `True` | Print lifecycle logs |

## Badge

Add a trust badge to your README:

```markdown
![AgentStamp](https://agentstamp.org/api/v1/badge/0xYourWallet)
```

## Links

- [AgentStamp](https://agentstamp.org) — Platform
- [npm SDK](https://www.npmjs.com/package/agentstamp-verify) — TypeScript/Node.js SDK
- [API Docs](https://agentstamp.org/api/v1/trust/check/0x...) — Trust check endpoint
