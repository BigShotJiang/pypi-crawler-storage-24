"""
AgentStamp + CrewAI Integration

Drop-in identity lifecycle for CrewAI agents.
Auto-registers your agent on first run, sends heartbeats, and auto-renews.

Install:
    pip install requests

Usage:
    from agentstamp_crewai import AgentStampLifecycle, stamp_verified_tool

    # Auto-register on startup
    lifecycle = AgentStampLifecycle(
        wallet_address="0x...",
        name="MyResearchAgent",
        description="Finds and summarizes research papers",
        category="research",
    )
    lifecycle.start()  # stamps + registers + heartbeats + auto-renew

    # Use as a CrewAI tool
    @stamp_verified_tool
    def my_api_call(query: str) -> str:
        '''Makes an API call only if the caller is AgentStamp verified.'''
        return do_the_thing(query)

    # Or check trust manually
    trust = lifecycle.check_trust("0x_other_agent_wallet")
    if trust["trusted"]:
        proceed()
"""

import json
import time
import threading
from typing import Optional, Callable, Any
import requests


AGENTSTAMP_API = "https://agentstamp.org"


class AgentStampLifecycle:
    """
    Manages the full AgentStamp identity lifecycle for a CrewAI agent.

    - Auto-registers (free stamp + free directory listing) on first run
    - Sends periodic heartbeats for uptime reputation
    - Auto-renews stamps and registrations before they expire
    """

    def __init__(
        self,
        wallet_address: str,
        name: str,
        description: str,
        category: str = "other",
        capabilities: Optional[list] = None,
        endpoint_url: Optional[str] = None,
        base_url: str = AGENTSTAMP_API,
        heartbeat_interval: int = 300,  # seconds
        renew_before_days: int = 2,
        renew_check_interval: int = 3600,  # seconds
        verbose: bool = True,
        on_registered: Optional[Callable] = None,
        on_renewed: Optional[Callable] = None,
        on_error: Optional[Callable] = None,
    ):
        self.wallet_address = wallet_address
        self.name = name
        self.description = description
        self.category = category
        self.capabilities = capabilities or []
        self.endpoint_url = endpoint_url
        self.base_url = base_url.rstrip("/")
        self.heartbeat_interval = heartbeat_interval
        self.renew_before_days = renew_before_days
        self.renew_check_interval = renew_check_interval
        self.verbose = verbose
        self.on_registered = on_registered
        self.on_renewed = on_renewed
        self.on_error = on_error

        # State
        self.agent_id: Optional[str] = None
        self.stamp_id: Optional[str] = None
        self.stamp_expires_at: Optional[str] = None
        self.registration_expires_at: Optional[str] = None
        self.heartbeat_count: int = 0
        self.initialized: bool = False

        # Timers
        self._heartbeat_timer: Optional[threading.Timer] = None
        self._renew_timer: Optional[threading.Timer] = None
        self._shutdown = False

    def start(self) -> dict:
        """Initialize + heartbeat + auto-renew in one call."""
        state = self.initialize()
        self.enable_heartbeat()
        self.enable_auto_renew()
        return state

    def initialize(self) -> dict:
        """Mint a free stamp and register if not already done."""
        self._log("Initializing agent lifecycle...")

        # Check if already registered
        if self._check_existing():
            self._log(f"Agent already registered: {self.agent_id}")
            self.initialized = True
            return self.get_state()

        # Step 1: Mint free stamp
        try:
            self._log("Minting free stamp...")
            resp = requests.post(
                f"{self.base_url}/api/v1/stamp/mint/free",
                json={"wallet_address": self.wallet_address},
                headers={
                    "x-wallet-address": self.wallet_address,
                    "User-Agent": "agentstamp-crewai/1.0.0",
                },
                timeout=10,
            )
            data = resp.json()
            if data.get("success") and data.get("stamp"):
                self.stamp_id = data["stamp"]["id"]
                self.stamp_expires_at = data["stamp"]["expires_at"]
                self._log(f"Stamp minted: {self.stamp_id}")
            elif "cooldown" in str(data.get("error", "")):
                self._log("Free stamp cooldown active — already stamped")
        except Exception as e:
            self._handle_error(e, "mint_stamp")

        # Step 2: Register in directory
        try:
            self._log("Registering agent in directory...")
            resp = requests.post(
                f"{self.base_url}/api/v1/registry/register/free",
                json={
                    "wallet_address": self.wallet_address,
                    "name": self.name,
                    "description": self.description,
                    "category": self.category,
                    "capabilities": self.capabilities,
                    "endpoint_url": self.endpoint_url,
                },
                headers={
                    "x-wallet-address": self.wallet_address,
                    "User-Agent": "agentstamp-crewai/1.0.0",
                },
                timeout=10,
            )
            data = resp.json()
            if data.get("success") and data.get("agent"):
                self.agent_id = data["agent"]["id"]
                self.registration_expires_at = data["agent"]["expires_at"]
                self._log(f"Agent registered: {self.agent_id}")
                if self.on_registered:
                    self.on_registered({"agent_id": self.agent_id, "stamp_id": self.stamp_id})
            elif "cooldown" in str(data.get("error", "")):
                self._log("Free registration cooldown active — already registered")
                self._check_existing()
        except Exception as e:
            self._handle_error(e, "register")

        self.initialized = True
        return self.get_state()

    def enable_heartbeat(self, interval: Optional[int] = None) -> None:
        """Send periodic heartbeats to maintain uptime score."""
        if self._heartbeat_timer is not None:
            return
        interval = interval or self.heartbeat_interval
        self._log(f"Heartbeat enabled (every {interval}s)")
        self._send_heartbeat()
        self._schedule_heartbeat(interval)

    def enable_auto_renew(self, check_interval: Optional[int] = None) -> None:
        """Periodically check and renew stamps/registrations before expiry."""
        if self._renew_timer is not None:
            return
        interval = check_interval or self.renew_check_interval
        self._log(f"Auto-renewal enabled (check every {interval}s)")
        self._check_and_renew()
        self._schedule_renew(interval)

    def check_trust(self, wallet_address: str) -> dict:
        """Check the trust status of another agent."""
        try:
            resp = requests.get(
                f"{self.base_url}/api/v1/trust/check/{wallet_address}",
                headers={"User-Agent": "agentstamp-crewai/1.0.0"},
                timeout=5,
            )
            return resp.json()
        except Exception as e:
            return {"trusted": False, "error": str(e)}

    def shutdown(self) -> None:
        """Stop all background timers."""
        self._shutdown = True
        if self._heartbeat_timer:
            self._heartbeat_timer.cancel()
            self._heartbeat_timer = None
        if self._renew_timer:
            self._renew_timer.cancel()
            self._renew_timer = None
        self._log("Lifecycle shut down")

    def get_state(self) -> dict:
        return {
            "initialized": self.initialized,
            "agent_id": self.agent_id,
            "stamp_id": self.stamp_id,
            "stamp_expires_at": self.stamp_expires_at,
            "registration_expires_at": self.registration_expires_at,
            "heartbeat_count": self.heartbeat_count,
        }

    # --- Private ---

    def _check_existing(self) -> bool:
        try:
            resp = requests.get(
                f"{self.base_url}/api/v1/trust/check/{self.wallet_address}",
                headers={"User-Agent": "agentstamp-crewai/1.0.0"},
                timeout=5,
            )
            data = resp.json()
            if data.get("agent"):
                self.agent_id = data["agent"].get("id")
            if data.get("stamp"):
                self.stamp_id = data["stamp"].get("id")
                self.stamp_expires_at = data["stamp"].get("expires_at")
            return data.get("trusted", False) or data.get("agent") is not None
        except Exception:
            return False

    def _send_heartbeat(self) -> None:
        if not self.agent_id or self._shutdown:
            return
        try:
            requests.post(
                f"{self.base_url}/api/v1/registry/heartbeat/{self.agent_id}",
                headers={"User-Agent": "agentstamp-crewai/1.0.0"},
                timeout=5,
            )
            self.heartbeat_count += 1
            self._log(f"Heartbeat #{self.heartbeat_count} sent")
        except Exception as e:
            self._handle_error(e, "heartbeat")

    def _schedule_heartbeat(self, interval: int) -> None:
        if self._shutdown:
            return
        self._heartbeat_timer = threading.Timer(interval, self._heartbeat_tick, [interval])
        self._heartbeat_timer.daemon = True
        self._heartbeat_timer.start()

    def _heartbeat_tick(self, interval: int) -> None:
        if self._shutdown:
            return
        self._send_heartbeat()
        self._schedule_heartbeat(interval)

    def _check_and_renew(self) -> None:
        if self._shutdown:
            return
        now = time.time()
        threshold = self.renew_before_days * 86400

        # Check stamp
        if self.stamp_expires_at:
            try:
                from datetime import datetime
                expiry = datetime.fromisoformat(self.stamp_expires_at.replace("Z", "+00:00")).timestamp()
                if expiry - now < threshold:
                    self._log("Stamp expiring soon — renewing...")
                    resp = requests.post(
                        f"{self.base_url}/api/v1/stamp/mint/free",
                        json={"wallet_address": self.wallet_address},
                        headers={"x-wallet-address": self.wallet_address, "User-Agent": "agentstamp-crewai/1.0.0"},
                        timeout=10,
                    )
                    data = resp.json()
                    if data.get("success") and data.get("stamp"):
                        self.stamp_id = data["stamp"]["id"]
                        self.stamp_expires_at = data["stamp"]["expires_at"]
                        self._log(f"Stamp renewed: {self.stamp_id}")
                        if self.on_renewed:
                            self.on_renewed({"type": "stamp", "expires_at": self.stamp_expires_at})
            except Exception as e:
                self._handle_error(e, "renew_stamp")

        # Check registration
        if self.registration_expires_at:
            try:
                from datetime import datetime
                expiry = datetime.fromisoformat(self.registration_expires_at.replace("Z", "+00:00")).timestamp()
                if expiry - now < threshold:
                    self._log("Registration expiring soon — renewing...")
                    resp = requests.post(
                        f"{self.base_url}/api/v1/registry/register/free",
                        json={
                            "wallet_address": self.wallet_address,
                            "name": self.name,
                            "description": self.description,
                            "category": self.category,
                            "capabilities": self.capabilities,
                        },
                        headers={"x-wallet-address": self.wallet_address, "User-Agent": "agentstamp-crewai/1.0.0"},
                        timeout=10,
                    )
                    data = resp.json()
                    if data.get("success") and data.get("agent"):
                        self.agent_id = data["agent"]["id"]
                        self.registration_expires_at = data["agent"]["expires_at"]
                        self._log(f"Registration renewed: {self.agent_id}")
                        if self.on_renewed:
                            self.on_renewed({"type": "registration", "expires_at": self.registration_expires_at})
            except Exception as e:
                self._handle_error(e, "renew_registration")

    def _schedule_renew(self, interval: int) -> None:
        if self._shutdown:
            return
        self._renew_timer = threading.Timer(interval, self._renew_tick, [interval])
        self._renew_timer.daemon = True
        self._renew_timer.start()

    def _renew_tick(self, interval: int) -> None:
        if self._shutdown:
            return
        self._check_and_renew()
        self._schedule_renew(interval)

    def _handle_error(self, err: Exception, context: str) -> None:
        self._log(f"Error [{context}]: {err}", is_error=True)
        if self.on_error:
            self.on_error(err, context)

    def _log(self, message: str, is_error: bool = False) -> None:
        if self.verbose:
            prefix = f"[AgentStamp:{self.name}]"
            if is_error:
                print(f"\033[91m{prefix} {message}\033[0m")
            else:
                print(f"\033[96m{prefix} {message}\033[0m")


def stamp_verified(lifecycle: AgentStampLifecycle):
    """
    Decorator: only execute a function if the agent is AgentStamp verified.

    Usage:
        lifecycle = AgentStampLifecycle(...)
        lifecycle.start()

        @stamp_verified(lifecycle)
        def my_tool(query: str) -> str:
            return "result"
    """
    def decorator(func: Callable) -> Callable:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if not lifecycle.initialized or not lifecycle.agent_id:
                return "Error: Agent not registered with AgentStamp. Call lifecycle.start() first."
            return func(*args, **kwargs)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    return decorator
