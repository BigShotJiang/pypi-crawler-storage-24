# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
"""This examples script demonstrates how to render documents from a source."""

from __future__ import annotations

import airbyte as ab
import rich


def main() -> None:
    read_result = ab.get_source(
        "source-github",
        config={
            "repositories": ["airbytehq/quickstarts"],
            "credentials": {
                "personal_access_token": ab.get_secret("GITHUB_PERSONAL_ACCESS_TOKEN")
            },
        },
        streams=["issues"],
    ).read()

    for doc in read_result["issues"].to_documents(
        title_property="title",
        content_properties=["body"],
        metadata_properties=["state", "url", "number"],
        # primary_key_properties=["id"],
        # cursor_property="updated_at",
        render_metadata=True,
    ):
        rich.print(rich.markdown.Markdown(str(doc) + "\n\n" + str("-" * 40)))


if __name__ == "__main__":
    main()
