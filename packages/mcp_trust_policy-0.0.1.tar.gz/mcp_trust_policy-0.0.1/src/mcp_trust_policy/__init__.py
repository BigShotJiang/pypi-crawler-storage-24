"""mcp-trust-policy — Policy-as-code engine for MCP trust — YAML and OPA/Rego policy definitions for agent-tool permissions."""
__version__ = "0.0.1"
