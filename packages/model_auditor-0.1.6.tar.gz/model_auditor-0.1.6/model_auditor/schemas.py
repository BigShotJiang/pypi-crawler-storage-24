"""Data schemas for model auditor evaluation results.

This module defines the data structures used to store and organize
evaluation results, including features, scores, outcomes, and their
associated metrics at various levels of aggregation.
"""

from __future__ import annotations

from typing import Any, Optional, Union, Callable
from dataclasses import dataclass, field

import pandas as pd
import numpy as np


# Helper functions for styling DataFrames


def _is_count_metric(metric_name: str) -> bool:
    """Check if a metric is a count metric (excluded from performance styling by default).

    Count metrics are identified by exact matching against known names,
    not prefix matching. This prevents misclassifying performance
    metrics like tpr/tnr/fpr/fnr as count metrics.

    Args:
        metric_name: Name of the metric to check.

    Returns:
        True if the metric is a count metric, False otherwise.
    """
    metric_name_upper = metric_name.upper()
    # Count metrics: exact matches only (case-insensitive)
    # Names with underscore prefix: n, n_tp, n_tn, n_fp, n_fn, n_pos, n_neg
    # Labels without prefix: N, TP, TN, FP, FN, Pos, Neg (with or without dots)
    count_metrics = {
        "N",
        "TP",
        "TN",
        "FP",
        "FN",
        "POS",
        "NEG",
        "POS.",
        "NEG.",  # labels (with and without dots)
        "N_TP",
        "N_TN",
        "N_FP",
        "N_FN",
        "N_POS",
        "N_NEG",  # with underscore
    }
    return metric_name_upper in count_metrics


def _is_lower_better_metric(metric_name: str) -> bool:
    """Check if a metric is lower-is-better (e.g., FPR, FNR).

    Args:
        metric_name: Name of the metric to check.

    Returns:
        True if the metric is lower-is-better, False otherwise.
    """
    metric_name_upper = metric_name.upper()
    lower_better_metrics = ["FPR", "FNR", "FALSE_POSITIVE_RATE", "FALSE_NEGATIVE_RATE"]
    return metric_name_upper in lower_better_metrics


def _get_metric_tier(
    value: float, values: pd.Series, lower_better: bool = False
) -> str:
    """Get the performance tier for a metric value relative to other values.

    Uses percentile-based tiering with thresholds at 0.33 and 0.66 for robustness
    across small samples and ties. Handles NaN values gracefully.

    Args:
        value: The value to classify.
        values: Series of all values for the metric (including the value).
        lower_better: If True, lower values are considered better performance.

    Returns:
        One of 'high', 'medium', 'low', or 'none' (for NaN).
    """
    if pd.isna(value):
        return "none"

    # Guard against empty series
    if values.count() == 0:
        return "none"

    # Calculate percentile rank (0-1) using strict less-than comparison
    # This handles ties by using consistent ranking across all values
    percentile = (values < value).sum() / values.count()

    # Define tier thresholds for 3-way split
    # Low: < 1/3, Medium: 1/3 to 2/3, High: >= 2/3
    if not lower_better:
        # Higher values are better: high tier has highest percentile
        if percentile >= 2 / 3:
            return "high"
        elif percentile >= 1 / 3:
            return "medium"
        else:
            return "low"
    else:
        # Lower values are better: invert the logic.
        # Use strict < boundaries so they mirror the higher_better >= boundaries.
        # higher_better: [0,1/3)→low, [1/3,2/3)→medium, [2/3,1]→high
        # lower_better:  [0,1/3)→high, [1/3,2/3)→medium, [2/3,1]→low
        if percentile < 1 / 3:
            return "high"
        elif percentile < 2 / 3:
            return "medium"
        else:
            return "low"


def _apply_tier_styling(
    display_df: pd.DataFrame,
    numeric_df: pd.DataFrame,
    metric_names: list[str],
    include_count_metrics: bool = False,
    low_color: str = "#f8d7da",
    medium_color: str = "#fff3cd",
    high_color: str = "#d4edda",
) -> pd.io.formats.style.Styler:
    """Apply tier-based coloring to a DataFrame.

    Args:
        display_df: DataFrame with formatted display values (strings).
        numeric_df: DataFrame with raw numeric values for tier classification.
        metric_names: List of metric names to apply styling to.
        include_count_metrics: If True, include count metrics in styling.
        low_color: Background color for low performance tier.
        medium_color: Background color for medium performance tier.
        high_color: Background color for high performance tier.

    Returns:
        A pandas Styler object with tier-based coloring applied.
    """
    # Initialize style matrix with all empty strings
    style_df = pd.DataFrame("", index=display_df.index, columns=display_df.columns)

    for metric_name in metric_names:
        if metric_name not in display_df.columns:
            continue

        # Skip count metrics unless explicitly included
        if not include_count_metrics and _is_count_metric(metric_name):
            continue

        # Get the numeric values for this metric
        numeric_values = numeric_df[metric_name]

        # Determine if this is a lower-is-better metric
        lower_better = _is_lower_better_metric(metric_name)

        # Apply tier coloring for each row
        for idx in display_df.index:
            value = numeric_values.loc[idx]
            tier = _get_metric_tier(value, numeric_values, lower_better=lower_better)

            if tier == "low":
                style_df.loc[idx, metric_name] = f"background-color: {low_color}"
            elif tier == "medium":
                style_df.loc[idx, metric_name] = f"background-color: {medium_color}"
            elif tier == "high":
                style_df.loc[idx, metric_name] = f"background-color: {high_color}"

    # Create and return the Styler
    return display_df.style.apply(lambda x: style_df, axis=None)


@dataclass
class LevelMetric:
    """
    Object to store the evaluation results for one metric of one level of a feature.
    (for example, AUC for one category of finding)

    Args:
        name (str): Name of the current feature level metric
        score (Union[float, int]): Score for the current feature level metric
        interval (tuple[float, float], optional): Optional lower and upper confidence
        bounds for the current feature level metric (defaults to None)
    """

    name: str
    label: str
    score: Union[float, int]
    interval: Optional[tuple[float, float]] = None


@dataclass
class LevelEvaluation:
    """
    Object to store the evaluation results for one level of a feature
    (for example, all metrics for one category of finding).

    Args:
        name (str): Name of the current feature level
        metrics (dict[str, LevelMetric]): Metrics for the current feature level
        (defaults to an empty dict)
    """

    name: str
    metrics: dict[str, LevelMetric] = field(default_factory=dict)

    def update(self, metric_name: str, metric_label: str, metric_score: float) -> None:
        """Add or update a metric for this level.

        Args:
            metric_name: Unique identifier for the metric.
            metric_label: Display label for the metric.
            metric_score: Computed metric value.
        """
        self.metrics[metric_name] = LevelMetric(
            name=metric_name, label=metric_label, score=metric_score
        )

    def update_intervals(
        self, metric_intervals: dict[str, tuple[float, float]]
    ) -> None:
        """Update confidence intervals for existing metrics.

        Args:
            metric_intervals: Dictionary mapping metric names to (lower, upper) bounds.
        """
        for metric_name, confidence_interval in metric_intervals.items():
            self.metrics[metric_name].interval = confidence_interval

    def to_dataframe(
        self, n_decimals: int = 3, add_index: bool = False, metric_labels: bool = False
    ) -> pd.DataFrame:
        """Convert level evaluation to a pandas DataFrame.

        Args:
            n_decimals: Number of decimal places for formatting scores.
            add_index: Unused parameter (kept for API consistency).
            metric_labels: If True, use metric labels as column names; else use names.

        Returns:
            Single-row DataFrame with metrics as columns.
        """
        metric_data: dict[str, str] = dict()
        for metric in self.metrics.values():
            # get the key name for the current metric (label if metric_labels is True)
            metric_key: str = metric.label if metric_labels else metric.name

            if metric.interval is not None:
                metric_data[metric_key] = (
                    f"{metric.score:.{n_decimals}f} ({metric.interval[0]:.{n_decimals}f}, {metric.interval[1]:.{n_decimals}f})"
                )
            elif isinstance(metric.score, float):
                metric_data[metric_key] = f"{metric.score:.{n_decimals}f}"
            else:
                # integer scores (default to comma delimited for now)
                metric_data[metric_key] = f"{metric.score:,}"

        return pd.DataFrame(metric_data, index=[self.name])

    def style_dataframe(
        self,
        n_decimals: int = 3,
        metric_labels: bool = False,
        include_count_metrics: bool = False,
        low_color: str = "#f8d7da",
        medium_color: str = "#fff3cd",
        high_color: str = "#d4edda",
    ) -> pd.io.formats.style.Styler:
        """Convert level evaluation to a styled pandas DataFrame for Jupyter display.

        Styles cells based on relative performance tiers within each metric column.

        Args:
            n_decimals: Number of decimal places for formatting scores.
            metric_labels: If True, use metric labels as column names; else use names.
            include_count_metrics: If True, include count metrics in tier styling.
            low_color: Background color for low performance tier.
            medium_color: Background color for medium performance tier.
            high_color: Background color for high performance tier.

        Returns:
            A pandas Styler object with tier-based coloring applied.
        """
        # Build the display DataFrame (same as to_dataframe)
        display_df = self.to_dataframe(
            n_decimals=n_decimals, metric_labels=metric_labels
        )

        # Build parallel numeric DataFrame for styling decisions
        numeric_data = {}
        metric_names = []
        for metric in self.metrics.values():
            metric_key = metric.label if metric_labels else metric.name
            numeric_data[metric_key] = metric.score
            metric_names.append(metric_key)
        numeric_df = pd.DataFrame(numeric_data, index=[self.name])

        # Apply tier styling
        return _apply_tier_styling(
            display_df=display_df,
            numeric_df=numeric_df,
            metric_names=metric_names,
            include_count_metrics=include_count_metrics,
            low_color=low_color,
            medium_color=medium_color,
            high_color=high_color,
        )


@dataclass
class FeatureEvaluation:
    """
    Object to store the evaluation results for one feature type
    (for example, metrics associated with different types of findings)

    Args:
        name (str): Name of the current feature
        name (str): Label for the current feature
        levels (dict[str, LevelEvaluation]): Levels of the current feature
        (defaults to an empty dict)
    """

    name: str
    label: str
    levels: dict[str, LevelEvaluation] = field(default_factory=dict)

    def update(
        self, metric_name: str, metric_label: str, data: dict[str, float]
    ) -> None:
        """Update metrics for all levels from a metric-level dictionary.

        Args:
            metric_name: Unique identifier for the metric.
            metric_label: Display label for the metric.
            data: Dictionary mapping level names to metric scores,
                e.g., {'levelA': 0.5, 'levelB': 0.5}.
        """
        # expects a dict for one metric type: {'levelA': 0.5, 'levelB': 0.5}
        # and maps them to child level metric dicts
        for level_name, level_metric in data.items():
            # try to get the level item and instantiate a new one if it doesn't exist yet
            level_eval: LevelEvaluation = self.levels.get(
                level_name, LevelEvaluation(name=level_name)
            )
            # update the metrics for that level eval object and save it back to the dict
            level_eval.update(
                metric_name=metric_name,
                metric_label=metric_label,
                metric_score=level_metric,
            )
            self.levels[level_name] = level_eval

    def update_intervals(
        self, level_name: str, metric_intervals: dict[str, tuple[float, float]]
    ) -> None:
        """Update confidence intervals for metrics at a specific level.

        Args:
            level_name: Name of the level to update.
            metric_intervals: Dictionary mapping metric names to (lower, upper) bounds.
        """
        self.levels[level_name].update_intervals(metric_intervals=metric_intervals)

    def to_dataframe(
        self, n_decimals: int = 3, add_index: bool = False, metric_labels: bool = False
    ) -> pd.DataFrame:
        """Convert feature evaluation to a pandas DataFrame.

        Args:
            n_decimals: Number of decimal places for formatting scores.
            add_index: If True, add feature label as a hierarchical index level.
            metric_labels: If True, use metric labels as column names; else use names.

        Returns:
            DataFrame with levels as rows and metrics as columns.
        """
        data: list[pd.DataFrame] = []
        for level_data in self.levels.values():
            data.append(
                level_data.to_dataframe(
                    n_decimals=n_decimals, metric_labels=metric_labels
                )
            )

        if add_index:
            return pd.concat({self.label: pd.concat(data, axis=0)})
        else:
            return pd.concat(data, axis=0)

    def style_dataframe(
        self,
        n_decimals: int = 3,
        metric_labels: bool = False,
        include_count_metrics: bool = False,
        low_color: str = "#f8d7da",
        medium_color: str = "#fff3cd",
        high_color: str = "#d4edda",
    ) -> pd.io.formats.style.Styler:
        """Convert feature evaluation to a styled pandas DataFrame for Jupyter display.

        Styles cells based on relative performance tiers within each metric column.

        Args:
            n_decimals: Number of decimal places for formatting scores.
            metric_labels: If True, use metric labels as column names; else use names.
            include_count_metrics: If True, include count metrics in tier styling.
            low_color: Background color for low performance tier.
            medium_color: Background color for medium performance tier.
            high_color: Background color for high performance tier.

        Returns:
            A pandas Styler object with tier-based coloring applied.
        """
        # Build the display DataFrame (same as to_dataframe)
        display_df = self.to_dataframe(
            n_decimals=n_decimals, metric_labels=metric_labels
        )

        # Build parallel numeric DataFrame for styling decisions
        numeric_data_list = []
        metric_names = set()

        for level_eval in self.levels.values():
            level_numeric = {}
            for metric in level_eval.metrics.values():
                metric_key = metric.label if metric_labels else metric.name
                level_numeric[metric_key] = metric.score
                metric_names.add(metric_key)
            numeric_data_list.append(level_numeric)

        numeric_df = pd.DataFrame(numeric_data_list, index=display_df.index)

        # Apply tier styling
        return _apply_tier_styling(
            display_df=display_df,
            numeric_df=numeric_df,
            metric_names=list(metric_names),
            include_count_metrics=include_count_metrics,
            low_color=low_color,
            medium_color=medium_color,
            high_color=high_color,
        )


@dataclass
class ScoreEvaluation:
    """Container for all evaluation results for a single score.

    Organizes evaluation results hierarchically by feature, then by level
    within each feature.

    Attributes:
        name: Name of the score being evaluated.
        label: Display label for the score.
        features: Dictionary mapping feature names to FeatureEvaluation objects.
    """

    name: str
    label: str
    features: dict[str, FeatureEvaluation] = field(default_factory=dict)

    def to_dataframe(
        self, n_decimals: int = 3, add_index: bool = False, metric_labels: bool = False
    ) -> pd.DataFrame:
        """Convert score evaluation to a pandas DataFrame.

        Args:
            n_decimals: Number of decimal places for formatting scores.
            add_index: If True, add score label as a hierarchical index level.
            metric_labels: If True, use metric labels as column names; else use names.

        Returns:
            DataFrame with hierarchical index (feature, level) and metrics as columns.
        """
        data: list[pd.DataFrame] = []
        for feature_data in self.features.values():
            data.append(
                feature_data.to_dataframe(
                    n_decimals=n_decimals, add_index=True, metric_labels=metric_labels
                )
            )

        if add_index:
            return pd.concat({self.label: pd.concat(data, axis=0)})
        else:
            return pd.concat(data, axis=0)

    def style_dataframe(
        self,
        n_decimals: int = 3,
        metric_labels: bool = False,
        include_count_metrics: bool = False,
        low_color: str = "#f8d7da",
        medium_color: str = "#fff3cd",
        high_color: str = "#d4edda",
    ) -> pd.io.formats.style.Styler:
        """Convert score evaluation to a styled pandas DataFrame for Jupyter display.

        Styles cells based on relative performance tiers within each metric column.

        Args:
            n_decimals: Number of decimal places for formatting scores.
            metric_labels: If True, use metric labels as column names; else use names.
            include_count_metrics: If True, include count metrics in tier styling.
            low_color: Background color for low performance tier.
            medium_color: Background color for medium performance tier.
            high_color: Background color for high performance tier.

        Returns:
            A pandas Styler object with tier-based coloring applied.
        """
        # Build the display DataFrame (same as to_dataframe)
        display_df = self.to_dataframe(
            n_decimals=n_decimals, metric_labels=metric_labels
        )

        # Build parallel numeric DataFrame for styling decisions
        numeric_data_list = []
        metric_names = set()

        for feature_eval in self.features.values():
            for level_eval in feature_eval.levels.values():
                level_numeric = {}
                for metric in level_eval.metrics.values():
                    metric_key = metric.label if metric_labels else metric.name
                    level_numeric[metric_key] = metric.score
                    metric_names.add(metric_key)
                numeric_data_list.append(level_numeric)

        numeric_df = pd.DataFrame(numeric_data_list, index=display_df.index)

        # Apply tier styling
        return _apply_tier_styling(
            display_df=display_df,
            numeric_df=numeric_df,
            metric_names=list(metric_names),
            include_count_metrics=include_count_metrics,
            low_color=low_color,
            medium_color=medium_color,
            high_color=high_color,
        )


@dataclass
class AuditorFeature:
    """Configuration for a stratification feature.

    Defines a column in the data that will be used to stratify metric
    evaluation into subgroups.

    Attributes:
        name: Column name in the DataFrame.
        label: Display label for the feature (defaults to name if None).
    """

    name: str
    label: Optional[str] = None


@dataclass
class AuditorScore:
    """Configuration for a prediction score column.

    Defines a continuous score column that will be evaluated against
    the ground truth outcome.

    Attributes:
        name: Column name in the DataFrame containing prediction scores.
        label: Display label for the score (defaults to name if None).
        threshold: Optional threshold for binarizing continuous scores.
    """

    name: str
    label: Optional[str] = None
    threshold: Optional[float] = None


@dataclass
class AuditorOutcome:
    """Configuration for the ground truth outcome column.

    Defines the outcome (label) column that predictions are compared against.

    Attributes:
        name: Column name in the DataFrame containing ground truth labels.
        mapping: Optional dictionary to convert outcome values to binary (0/1),
            e.g., {"positive": 1, "negative": 0}.
    """

    name: str
    mapping: Optional[dict[Any, int]] = None
