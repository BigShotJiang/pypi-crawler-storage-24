"""
Axonn MCP Server

Exposes US energy regulatory filings, real-time ISO prices, and market data
as MCP tools for use in Claude Code, Cursor, and other MCP-compatible clients.

Configuration:
  AXONN_API_KEY  — Your Axonn API key (default: axn_demo_key_001 for free tier)
  AXONN_API_URL  — API base URL (default: https://axonn-power.fly.dev)
"""

import json
import os
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "Axonn",
    instructions=(
        "US energy market intelligence. Use these tools to search regulatory filings "
        "(PUC rate cases, battery storage, interconnection), get real-time ISO prices "
        "(CAISO, ERCOT, PJM, MISO, SPP, NYISO, ISONE), track BESS projects, "
        "interconnection queues, commodity prices, and ask AI questions about energy markets."
    ),
)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

AXONN_API_URL = os.getenv("AXONN_API_URL", "https://axonn-power.fly.dev")

VALID_ISOS = ("CAISO", "ERCOT", "PJM", "MISO", "SPP", "NYISO", "ISONE")

VALID_CATEGORIES = (
    "rate_case",
    "battery_storage",
    "interconnection",
    "large_load",
    "demand_response",
    "renewable",
    "distributed_energy",
)

VALID_DATA_TYPES = ("bess", "queue", "commodities", "grid_monitor")


def _api_key() -> str:
    """Get the Axonn API key from env var, falling back to demo key."""
    return os.getenv("AXONN_API_KEY", "axn_demo_key_001")


def _headers() -> dict[str, str]:
    return {
        "X-API-Key": _api_key(),
        "Content-Type": "application/json",
        "User-Agent": "axonn-mcp/0.1.0",
    }


async def _get(path: str, params: dict | None = None) -> Any:
    """Make an authenticated GET request to the Axonn API."""
    url = f"{AXONN_API_URL}{path}"
    async with httpx.AsyncClient(timeout=60.0) as client:
        r = await client.get(url, headers=_headers(), params=params)
        r.raise_for_status()
        return r.json()


async def _post(path: str, body: dict | None = None) -> Any:
    """Make an authenticated POST request to the Axonn API."""
    url = f"{AXONN_API_URL}{path}"
    async with httpx.AsyncClient(timeout=60.0) as client:
        r = await client.post(url, headers=_headers(), json=body or {})
        r.raise_for_status()
        return r.json()


# ===================================================================
# TOOL 1: search_filings
# ===================================================================


@mcp.tool()
async def search_filings(
    query: str,
    state: str | None = None,
    category: str | None = None,
    limit: int = 10,
) -> str:
    """Search US energy regulatory filings from state PUCs and FERC.

    Find rate cases, battery storage proposals, interconnection applications,
    large load requests, demand response programs, and more across all US states.

    Args:
        query: Search query (e.g. "battery storage Texas", "data center interconnection")
        state: Optional 2-letter state code to filter (e.g. "TX", "CA", "NY")
        category: Optional category filter. One of: rate_case, battery_storage,
                  interconnection, large_load, demand_response, renewable, distributed_energy
        limit: Max results to return (1-50, default 10)
    """
    if state and len(state) != 2:
        return "Error: state must be a 2-letter state code (e.g. 'TX', 'CA')."
    if category and category not in VALID_CATEGORIES:
        return f"Error: category must be one of: {', '.join(VALID_CATEGORIES)}"
    limit = max(1, min(50, limit))

    params: dict[str, Any] = {"q": query, "limit": limit}
    if state:
        params["state_code"] = state.upper()
    if category:
        params["category"] = category

    data = await _get("/v1/filings", params)
    filings = data if isinstance(data, list) else data.get("filings", [])

    if not filings:
        return f"No filings found for query: '{query}'"

    lines = [f"**{len(filings)} filing(s) found:**\n"]
    for f in filings:
        title = f.get("title", "Untitled")
        docket = f.get("docket_number", "N/A")
        date = f.get("filing_date", "N/A")
        st = f.get("state_code", "N/A")
        cat = f.get("category", "N/A")
        source = f.get("source", "N/A")
        pdf = f.get("pdf_url", "")
        lines.append(
            f"- **{title}**\n"
            f"  Docket: {docket} | Date: {date} | State: {st} | Category: {cat}\n"
            f"  Source: {source}" + (f" | [PDF]({pdf})" if pdf else "")
        )
    return "\n".join(lines)


# ===================================================================
# TOOL 2: get_prices
# ===================================================================


@mcp.tool()
async def get_prices(iso: str) -> str:
    """Get current real-time LMP (Locational Marginal Pricing) electricity prices for a US ISO.

    Returns the latest wholesale electricity prices including energy, congestion,
    and loss components for the specified independent system operator.

    Args:
        iso: ISO/RTO identifier. One of: CAISO, ERCOT, PJM, MISO, SPP, NYISO, ISONE
    """
    iso_upper = iso.upper()
    if iso_upper not in VALID_ISOS:
        return f"Error: iso must be one of: {', '.join(VALID_ISOS)}"

    data = await _get(f"/v1/us/prices/{iso_upper}")
    return json.dumps(data, indent=2)


# ===================================================================
# TOOL 3: get_market_data
# ===================================================================


@mcp.tool()
async def get_market_data(
    data_type: str,
    iso: str | None = None,
) -> str:
    """Get energy market data: BESS trackers, interconnection queues, commodity prices, or grid status.

    Args:
        data_type: Type of market data. One of:
            - bess: Battery Energy Storage System project tracker (filter by ISO)
            - queue: Interconnection queue data (filter by ISO, or omit for national summary)
            - commodities: EIA commodity prices (natural gas, coal, crude oil)
            - grid_monitor: Real-time US grid status and demand from EIA
        iso: Optional ISO filter for bess and queue data types.
             One of: CAISO, ERCOT, PJM, MISO, SPP, NYISO, ISONE
    """
    dt = data_type.lower()
    if dt not in VALID_DATA_TYPES:
        return f"Error: data_type must be one of: {', '.join(VALID_DATA_TYPES)}"

    if iso:
        iso_upper = iso.upper()
        if iso_upper not in VALID_ISOS:
            return f"Error: iso must be one of: {', '.join(VALID_ISOS)}"
    else:
        iso_upper = None

    if dt == "bess":
        params = {"iso": iso_upper} if iso_upper else None
        data = await _get("/v1/trackers/bess", params)
    elif dt == "queue":
        if iso_upper:
            data = await _get(f"/v1/queue/{iso_upper}")
        else:
            data = await _get("/v1/queue")
    elif dt == "commodities":
        data = await _get("/v1/eia/commodities")
    elif dt == "grid_monitor":
        data = await _get("/v1/eia/grid-monitor")
    else:
        return f"Error: unknown data_type '{data_type}'"

    return json.dumps(data, indent=2)


# ===================================================================
# TOOL 4: get_high_impact_filings
# ===================================================================


@mcp.tool()
async def get_high_impact_filings(limit: int = 10) -> str:
    """Get regulatory filings scored by potential price impact on energy markets.

    Returns filings rated HIGH or MEDIUM impact based on analysis of rate changes,
    capacity additions, and market structure effects. Useful for tracking filings
    that could move wholesale or retail electricity prices.

    Args:
        limit: Number of filings to return (default 10)
    """
    limit = max(1, min(50, limit))
    data = await _get("/v1/filings/high-impact", {"limit": limit})
    filings = data if isinstance(data, list) else data.get("filings", [])

    if not filings:
        return "No high-impact filings found."

    lines = ["**High-Impact Filings:**\n"]
    for f in filings:
        title = f.get("title", "Untitled")
        docket = f.get("docket_number", "N/A")
        date = f.get("filing_date", "N/A")
        state = f.get("state_code", "N/A")
        impact = f.get("impact_score", f.get("impact", "N/A"))
        category = f.get("category", "N/A")
        pdf = f.get("pdf_url", "")
        lines.append(
            f"- **[{impact}] {title}**\n"
            f"  Docket: {docket} | Date: {date} | State: {state} | Category: {category}"
            + (f"\n  [PDF]({pdf})" if pdf else "")
        )
    return "\n".join(lines)


# ===================================================================
# TOOL 5: ask_axonn
# ===================================================================


@mcp.tool()
async def ask_axonn(question: str) -> str:
    """Ask Axonn's AI a question about US energy markets, regulations, or grid data.

    The AI draws on regulatory filings, ISO data, EIA statistics, and energy market
    knowledge to provide informed answers. Good for questions like:
    - "What states have the most battery storage in their interconnection queues?"
    - "How do ERCOT real-time prices compare to day-ahead this week?"
    - "What are the largest pending rate cases in California?"
    - "Explain the impact of FERC Order 2222 on DERs"

    Args:
        question: Your question about energy markets, regulations, or grid data
    """
    if not question.strip():
        return "Error: question cannot be empty."

    data = await _post("/v1/ask", {"question": question})

    answer = data.get("answer", data.get("response", ""))
    sources = data.get("sources", [])

    lines = [str(answer)]
    if sources:
        lines.append("\n**Sources:**")
        for s in sources:
            if isinstance(s, str):
                lines.append(f"- {s}")
            elif isinstance(s, dict):
                lines.append(f"- {s.get('title', s.get('url', str(s)))}")
    return "\n".join(lines)


# ===================================================================
# Entry point
# ===================================================================


def main():
    """CLI entry point."""
    mcp.run()
