# axonn-mcp

MCP server for [Axonn](https://axonn-power.fly.dev) — US energy regulatory filings, real-time ISO prices, and market data.

## Tools

| Tool | Description |
|------|-------------|
| `search_filings` | Search regulatory filings by keyword, state, and category |
| `get_prices` | Real-time LMP prices for any US ISO (CAISO, ERCOT, PJM, MISO, SPP, NYISO, ISONE) |
| `get_market_data` | BESS trackers, interconnection queues, commodity prices, grid monitor |
| `get_high_impact_filings` | Filings scored by potential price impact (HIGH/MEDIUM) |
| `ask_axonn` | AI-powered Q&A about energy markets and regulations |

## Install

```bash
pip install axonn-mcp
```

## Configure

Set your API key (optional — defaults to demo tier):

```bash
export AXONN_API_KEY=axn_your_key_here
```

### Claude Code

```bash
claude mcp add axonn-mcp -- axonn-mcp
```

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "axonn": {
      "command": "axonn-mcp",
      "env": {
        "AXONN_API_KEY": "axn_your_key_here"
      }
    }
  }
}
```

## Development

```bash
pip install -e ".[dev]"
python3 -m pytest test_server.py -v
```
