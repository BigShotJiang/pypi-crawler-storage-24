"""Tests for axonn-mcp server."""

import os
import unittest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Import tests
# ---------------------------------------------------------------------------


class TestImports(unittest.TestCase):
    """Verify the package imports cleanly."""

    def test_import_package(self):
        import axonn_mcp

        assert axonn_mcp.__version__ == "0.1.0"

    def test_import_server(self):
        from axonn_mcp.server import mcp

        assert mcp is not None

    def test_import_main(self):
        from axonn_mcp.server import main

        assert callable(main)


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


class TestConfig(unittest.TestCase):
    """Test configuration and auth handling."""

    def test_default_api_key(self):
        from axonn_mcp.server import _api_key

        with patch.dict(os.environ, {}, clear=True):
            # Remove AXONN_API_KEY if set
            os.environ.pop("AXONN_API_KEY", None)
            assert _api_key() == "axn_demo_key_001"

    def test_custom_api_key(self):
        from axonn_mcp.server import _api_key

        with patch.dict(os.environ, {"AXONN_API_KEY": "axn_test_key_999"}):
            assert _api_key() == "axn_test_key_999"

    def test_headers_include_api_key(self):
        from axonn_mcp.server import _headers

        with patch.dict(os.environ, {"AXONN_API_KEY": "axn_test_123"}):
            h = _headers()
            assert h["X-API-Key"] == "axn_test_123"
            assert h["Content-Type"] == "application/json"
            assert "axonn-mcp" in h["User-Agent"]

    def test_default_api_url(self):
        from axonn_mcp.server import AXONN_API_URL

        # Module-level constant uses default if env not set at import time
        assert "axonn-power.fly.dev" in AXONN_API_URL


# ---------------------------------------------------------------------------
# Validation tests
# ---------------------------------------------------------------------------


class TestValidation(unittest.TestCase):
    """Test input validation in tool functions."""

    def test_valid_isos(self):
        from axonn_mcp.server import VALID_ISOS

        assert "CAISO" in VALID_ISOS
        assert "ERCOT" in VALID_ISOS
        assert "PJM" in VALID_ISOS
        assert "MISO" in VALID_ISOS
        assert "SPP" in VALID_ISOS
        assert "NYISO" in VALID_ISOS
        assert "ISONE" in VALID_ISOS
        assert len(VALID_ISOS) == 7

    def test_valid_categories(self):
        from axonn_mcp.server import VALID_CATEGORIES

        assert "rate_case" in VALID_CATEGORIES
        assert "battery_storage" in VALID_CATEGORIES
        assert "interconnection" in VALID_CATEGORIES
        assert "large_load" in VALID_CATEGORIES
        assert "demand_response" in VALID_CATEGORIES
        assert "renewable" in VALID_CATEGORIES
        assert "distributed_energy" in VALID_CATEGORIES
        assert len(VALID_CATEGORIES) == 7

    def test_valid_data_types(self):
        from axonn_mcp.server import VALID_DATA_TYPES

        assert "bess" in VALID_DATA_TYPES
        assert "queue" in VALID_DATA_TYPES
        assert "commodities" in VALID_DATA_TYPES
        assert "grid_monitor" in VALID_DATA_TYPES
        assert len(VALID_DATA_TYPES) == 4


# ---------------------------------------------------------------------------
# Tool function tests (mocked HTTP)
# ---------------------------------------------------------------------------


def _mock_response(data: dict, status_code: int = 200):
    """Create a mock httpx.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = data
    resp.raise_for_status = MagicMock()
    return resp


class TestSearchFilings(unittest.IsolatedAsyncioTestCase):
    """Test search_filings tool."""

    async def test_bad_state_code(self):
        from axonn_mcp.server import search_filings

        result = await search_filings(query="test", state="Texas")
        assert "Error" in result
        assert "2-letter" in result

    async def test_bad_category(self):
        from axonn_mcp.server import search_filings

        result = await search_filings(query="test", category="invalid_cat")
        assert "Error" in result
        assert "category" in result

    @patch("axonn_mcp.server._get")
    async def test_no_results(self, mock_get):
        from axonn_mcp.server import search_filings

        mock_get.return_value = {"filings": []}
        result = await search_filings(query="nonexistent filing xyz")
        assert "No filings found" in result

    @patch("axonn_mcp.server._get")
    async def test_results_formatted(self, mock_get):
        from axonn_mcp.server import search_filings

        mock_get.return_value = {
            "filings": [
                {
                    "title": "Test Rate Case",
                    "docket_number": "D-2024-001",
                    "filing_date": "2024-06-15",
                    "state_code": "TX",
                    "category": "rate_case",
                    "source": "PUCT",
                    "pdf_url": "https://example.com/doc.pdf",
                }
            ]
        }
        result = await search_filings(query="rate case", state="TX")
        assert "Test Rate Case" in result
        assert "D-2024-001" in result
        assert "TX" in result
        assert "PUCT" in result
        assert "PDF" in result

    @patch("axonn_mcp.server._get")
    async def test_limit_clamped(self, mock_get):
        from axonn_mcp.server import search_filings

        mock_get.return_value = {"filings": []}
        await search_filings(query="test", limit=100)
        call_params = mock_get.call_args[1].get("params") or mock_get.call_args[0][1]
        assert call_params["limit"] == 50

    @patch("axonn_mcp.server._get")
    async def test_limit_floor(self, mock_get):
        from axonn_mcp.server import search_filings

        mock_get.return_value = {"filings": []}
        await search_filings(query="test", limit=-5)
        call_params = mock_get.call_args[1].get("params") or mock_get.call_args[0][1]
        assert call_params["limit"] == 1


class TestGetPrices(unittest.IsolatedAsyncioTestCase):
    """Test get_prices tool."""

    async def test_invalid_iso(self):
        from axonn_mcp.server import get_prices

        result = await get_prices(iso="FAKE")
        assert "Error" in result
        assert "CAISO" in result

    @patch("axonn_mcp.server._get")
    async def test_valid_iso(self, mock_get):
        from axonn_mcp.server import get_prices

        mock_get.return_value = {"iso": "ERCOT", "lmp": 42.5}
        result = await get_prices(iso="ERCOT")
        assert "ERCOT" in result
        assert "42.5" in result

    @patch("axonn_mcp.server._get")
    async def test_case_insensitive(self, mock_get):
        from axonn_mcp.server import get_prices

        mock_get.return_value = {"iso": "PJM", "lmp": 30.0}
        result = await get_prices(iso="pjm")
        mock_get.assert_called_once_with("/v1/us/prices/PJM")


class TestGetMarketData(unittest.IsolatedAsyncioTestCase):
    """Test get_market_data tool."""

    async def test_invalid_data_type(self):
        from axonn_mcp.server import get_market_data

        result = await get_market_data(data_type="invalid")
        assert "Error" in result

    async def test_invalid_iso(self):
        from axonn_mcp.server import get_market_data

        result = await get_market_data(data_type="bess", iso="FAKE")
        assert "Error" in result

    @patch("axonn_mcp.server._get")
    async def test_bess_with_iso(self, mock_get):
        from axonn_mcp.server import get_market_data

        mock_get.return_value = {"projects": []}
        await get_market_data(data_type="bess", iso="CAISO")
        mock_get.assert_called_once_with("/v1/trackers/bess", {"iso": "CAISO"})

    @patch("axonn_mcp.server._get")
    async def test_bess_no_iso(self, mock_get):
        from axonn_mcp.server import get_market_data

        mock_get.return_value = {"projects": []}
        await get_market_data(data_type="bess")
        mock_get.assert_called_once_with("/v1/trackers/bess", None)

    @patch("axonn_mcp.server._get")
    async def test_queue_with_iso(self, mock_get):
        from axonn_mcp.server import get_market_data

        mock_get.return_value = {"queue": []}
        await get_market_data(data_type="queue", iso="PJM")
        mock_get.assert_called_once_with("/v1/queue/PJM")

    @patch("axonn_mcp.server._get")
    async def test_queue_no_iso(self, mock_get):
        from axonn_mcp.server import get_market_data

        mock_get.return_value = {"summary": {}}
        await get_market_data(data_type="queue")
        mock_get.assert_called_once_with("/v1/queue")

    @patch("axonn_mcp.server._get")
    async def test_commodities(self, mock_get):
        from axonn_mcp.server import get_market_data

        mock_get.return_value = {"natural_gas": 2.50}
        await get_market_data(data_type="commodities")
        mock_get.assert_called_once_with("/v1/eia/commodities")

    @patch("axonn_mcp.server._get")
    async def test_grid_monitor(self, mock_get):
        from axonn_mcp.server import get_market_data

        mock_get.return_value = {"demand_mw": 400000}
        await get_market_data(data_type="grid_monitor")
        mock_get.assert_called_once_with("/v1/eia/grid-monitor")


class TestGetHighImpactFilings(unittest.IsolatedAsyncioTestCase):
    """Test get_high_impact_filings tool."""

    @patch("axonn_mcp.server._get")
    async def test_no_results(self, mock_get):
        from axonn_mcp.server import get_high_impact_filings

        mock_get.return_value = {"filings": []}
        result = await get_high_impact_filings()
        assert "No high-impact" in result

    @patch("axonn_mcp.server._get")
    async def test_formatted_output(self, mock_get):
        from axonn_mcp.server import get_high_impact_filings

        mock_get.return_value = {
            "filings": [
                {
                    "title": "Big Rate Increase",
                    "docket_number": "RC-2024-100",
                    "filing_date": "2024-07-01",
                    "state_code": "CA",
                    "impact_score": "HIGH",
                    "category": "rate_case",
                }
            ]
        }
        result = await get_high_impact_filings(limit=5)
        assert "HIGH" in result
        assert "Big Rate Increase" in result
        assert "CA" in result


class TestAskAxonn(unittest.IsolatedAsyncioTestCase):
    """Test ask_axonn tool."""

    async def test_empty_question(self):
        from axonn_mcp.server import ask_axonn

        result = await ask_axonn(question="   ")
        assert "Error" in result
        assert "empty" in result

    @patch("axonn_mcp.server._post")
    async def test_answer_returned(self, mock_post):
        from axonn_mcp.server import ask_axonn

        mock_post.return_value = {
            "answer": "ERCOT prices spiked due to heat wave.",
            "sources": ["EIA.gov", "ERCOT.com"],
        }
        result = await ask_axonn(question="Why did Texas prices spike?")
        assert "ERCOT prices spiked" in result
        assert "EIA.gov" in result

    @patch("axonn_mcp.server._post")
    async def test_answer_with_dict_sources(self, mock_post):
        from axonn_mcp.server import ask_axonn

        mock_post.return_value = {
            "answer": "Battery storage is growing.",
            "sources": [{"title": "EIA Report", "url": "https://eia.gov/report"}],
        }
        result = await ask_axonn(question="Tell me about battery storage")
        assert "Battery storage" in result
        assert "EIA Report" in result


# ---------------------------------------------------------------------------
# MCP registration tests
# ---------------------------------------------------------------------------


class TestMCPRegistration(unittest.TestCase):
    """Verify tools are registered on the MCP server."""

    def test_mcp_name(self):
        from axonn_mcp.server import mcp

        assert mcp.name == "Axonn"

    def test_tools_registered(self):
        from axonn_mcp.server import mcp

        # FastMCP stores tools in _tool_manager.tools dict
        tool_manager = mcp._tool_manager
        tool_names = set(tool_manager._tools.keys())
        expected = {
            "search_filings",
            "get_prices",
            "get_market_data",
            "get_high_impact_filings",
            "ask_axonn",
        }
        assert expected.issubset(tool_names), f"Missing tools: {expected - tool_names}"


if __name__ == "__main__":
    unittest.main()
