# pyconverters_whisperx

[![license](https://img.shields.io/github/license/oterrier/pyconverters_whisperx)](https://github.com/oterrier/pyconverters_whisperx/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyconverters_whisperx/workflows/tests/badge.svg)](https://github.com/oterrier/pyconverters_whisperx/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyconverters_whisperx)](https://codecov.io/gh/oterrier/pyconverters_whisperx)
[![docs](https://img.shields.io/readthedocs/pyconverters_whisperx)](https://pyconverters_whisperx.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyconverters_whisperx)](https://pypi.org/project/pyconverters_whisperx/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters_whisperx)](https://pypi.org/project/pyconverters_whisperx/)

WhisperX converter for audio transcription with speaker diarization support.

## Installation

You can simply `pip install pyconverters_whisperx`.

## Developing

### Pre-requisites

You will need to install `uv` (for building and managing the package):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyconverters_whisperx
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
