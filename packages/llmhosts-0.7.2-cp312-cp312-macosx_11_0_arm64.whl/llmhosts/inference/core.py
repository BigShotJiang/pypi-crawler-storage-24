"""LLMHosts Core inference engine wrapper."""

from __future__ import annotations

import json
import logging
import os
import sys
from typing import Any, cast

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CUDA DLL discovery — ensure nvrtc is findable before the Rust extension loads.
#
# On Windows, `pip install llmhosts` pulls `nvidia-cuda-nvrtc-cu12` which
# places nvrtc64_*.dll under site-packages/nvidia/cuda_nvrtc/bin/.  Windows
# DLL search doesn't look there by default.  We prepend to PATH (most robust)
# AND register via os.add_dll_directory() so cudarc's LoadLibraryA finds it.
#
# nvidia.cuda_nvrtc is a namespace package — __file__ may be None, so we
# locate the DLLs via site-packages path construction instead.
# ---------------------------------------------------------------------------
if sys.platform == "win32":
    _nvrtc_registered = False
    # Strategy 1: find via site-packages path (most reliable)
    try:
        import site as _site

        for _sp in [*_site.getsitepackages(), _site.getusersitepackages()]:
            _nvrtc_bin = os.path.join(_sp, "nvidia", "cuda_nvrtc", "bin")
            if os.path.isdir(_nvrtc_bin):
                os.environ["PATH"] = _nvrtc_bin + os.pathsep + os.environ.get("PATH", "")
                os.add_dll_directory(_nvrtc_bin)
                # Force CubeCL to use CUDA backend when nvrtc is available.
                # Without this, CubeCL defaults to WGPU which has numerical
                # correctness issues in its matmul kernels.
                os.environ["CUBECL_BACKEND"] = "cuda"
                logger.info("Registered CUDA nvrtc DLL path: %s", _nvrtc_bin)
                _nvrtc_registered = True
                break
    except Exception as exc:
        logger.debug("nvrtc site-packages search failed: %s", exc)

    # Strategy 2: find via nvidia.cuda_nvrtc package location
    if not _nvrtc_registered:
        try:
            import importlib.util

            _spec = importlib.util.find_spec("nvidia.cuda_nvrtc")
            if _spec and _spec.submodule_search_locations:
                _nvrtc_bin = os.path.join(next(iter(_spec.submodule_search_locations)), "bin")
                if os.path.isdir(_nvrtc_bin):
                    os.environ["PATH"] = _nvrtc_bin + os.pathsep + os.environ.get("PATH", "")
                    os.add_dll_directory(_nvrtc_bin)
                    os.environ["CUBECL_BACKEND"] = "cuda"
                    logger.info("Registered CUDA nvrtc DLL path (via spec): %s", _nvrtc_bin)
                    _nvrtc_registered = True
        except Exception as exc:
            logger.debug("nvrtc spec search failed: %s", exc)

    if not _nvrtc_registered:
        logger.info("nvidia-cuda-nvrtc not found — CUDA backend may be unavailable")

LLMHOSTS_CORE_AVAILABLE: bool = False
_LLMHostsEngineNative: type | None = None
_cuda_device_info_fn: Any = None

try:
    from _llmhosts import core as _llmhosts_core_mod

    _LLMHostsEngineNative = _llmhosts_core_mod.LLMHostsEngine
    _cuda_device_info_fn = getattr(_llmhosts_core_mod, "cuda_device_info", None)
    LLMHOSTS_CORE_AVAILABLE = True
    _backends = _LLMHostsEngineNative.available_backends() if _LLMHostsEngineNative else []  # type: ignore[union-attr]
    logger.info(
        "LLMHosts Core engine available (v%s, backends: %s)",
        _llmhosts_core_mod.LLMHOSTS_CORE_VERSION,
        _backends,
    )
except Exception as exc:
    # Catch ALL exceptions — on Windows, missing DLLs raise OSError, not ImportError.
    # Fallback: try standalone module (development mode with individual maturin develop)
    logger.info("_llmhosts.core import failed: %s — trying standalone module", exc)
    try:
        import _llmhosts_core

        _LLMHostsEngineNative = _llmhosts_core.LLMHostsEngine
        _cuda_device_info_fn = getattr(_llmhosts_core, "cuda_device_info", None)
        LLMHOSTS_CORE_AVAILABLE = True
        logger.info(
            "LLMHosts Core engine available via standalone (v%s)",
            _llmhosts_core.LLMHOSTS_CORE_VERSION,
        )
    except Exception as exc2:
        logger.warning("LLMHosts Core engine NOT available: %s", exc2)


class LLMHostsInferenceEngine:
    def __init__(self) -> None:
        self._native = _LLMHostsEngineNative() if _LLMHostsEngineNative else None
        self._tokenizer: Any = None

    @property
    def is_loaded(self) -> bool:
        return self._native is not None and self._native.is_loaded

    def load_model(self, path: str) -> dict[str, Any]:
        if self._native is None:
            raise RuntimeError("LLMHosts Core engine not available (build with: cd llmhosts_core && maturin develop)")
        info: dict[str, Any] = json.loads(self._native.load_model(path))
        self._tokenizer = self._load_tokenizer(path)
        return info

    def _load_tokenizer(self, model_path: str) -> Any:
        import os

        try:
            from tokenizers import Tokenizer
        except ImportError:
            logger.debug("tokenizers package not available (install with: pip install llmhosts[smart])")
            return None

        model_dir = os.path.dirname(model_path)
        model_name = os.path.basename(model_path).lower()

        # Search multiple locations for tokenizer.json
        search_paths = [
            os.path.join(model_dir, "tokenizer.json"),
            os.path.join(model_dir, "..", "tokenizer.json"),
        ]

        for path in search_paths:
            if os.path.exists(path):
                try:
                    logger.info("Loading tokenizer from %s", path)
                    return Tokenizer.from_file(path)
                except Exception as exc:
                    logger.warning("Failed to load tokenizer from %s: %s", path, exc)

        # Auto-download from HuggingFace if model name is recognizable
        hf_repo = self._guess_hf_repo(model_name)
        if hf_repo:
            try:
                from huggingface_hub import hf_hub_download

                logger.info("Downloading tokenizer.json from %s", hf_repo)
                path = hf_hub_download(  # nosec B615 — revision pinned to main
                    repo_id=hf_repo, filename="tokenizer.json", local_dir=model_dir, revision="main"
                )
                return Tokenizer.from_file(path)
            except Exception as exc:
                logger.warning("Failed to download tokenizer from HuggingFace (%s): %s", hf_repo, exc)

        logger.warning("No tokenizer found for %s", model_path)
        return None

    @staticmethod
    def _guess_hf_repo(model_name: str) -> str | None:
        """Guess the HuggingFace repo ID from a GGUF filename."""
        patterns: dict[str, str] = {
            "qwen2.5-0.5b-instruct": "Qwen/Qwen2.5-0.5B-Instruct",
            "qwen2.5-1.5b-instruct": "Qwen/Qwen2.5-1.5B-Instruct",
            "qwen2.5-3b-instruct": "Qwen/Qwen2.5-3B-Instruct",
            "qwen2.5-7b-instruct": "Qwen/Qwen2.5-7B-Instruct",
            "qwen2.5-14b-instruct": "Qwen/Qwen2.5-14B-Instruct",
            "llama-3": "meta-llama/Llama-3.1-8B-Instruct",
            "mistral": "mistralai/Mistral-7B-Instruct-v0.3",
        }
        for pattern, repo in patterns.items():
            if pattern in model_name:
                return repo
        return None

    def generate(
        self, prompt: str, max_tokens: int = 256, temperature: float = 0.0, top_p: float = 0.9
    ) -> dict[str, Any]:
        if self._native is None:
            raise RuntimeError("LLMHosts Core engine not available")
        if self._tokenizer is None:
            raise RuntimeError(
                "No tokenizer loaded. Place a tokenizer.json next to the model file, "
                "or install the tokenizers package: pip install llmhosts[smart]"
            )
        encoded = self._tokenizer.encode(prompt)
        token_ids = encoded.ids
        generated = json.loads(self._native.generate_tokens(token_ids, max_tokens, temperature, top_p))
        text = self._tokenizer.decode(generated)
        return {"text": text, "tokens": generated, "token_count": len(generated)}

    def generate_tokens(
        self, token_ids: list[int], max_tokens: int = 256, temperature: float = 0.0, top_p: float = 0.9
    ) -> list[int]:
        if self._native is None:
            raise RuntimeError("LLMHosts Core engine not available")
        result: list[int] = json.loads(self._native.generate_tokens(token_ids, max_tokens, temperature, top_p))
        return result

    def unload(self) -> None:
        if self._native:
            self._native.unload()
        self._tokenizer = None

    @property
    def backend_name(self) -> str:
        """Return the active compute backend name (e.g. 'cpu', 'cuda:0', 'wgpu:Metal')."""
        if self._native is not None and self._native.is_loaded:
            return cast("str", self._native.backend_name())
        return "none"

    @staticmethod
    def available_backends() -> list[str]:
        """Return list of compute backends compiled into this build."""
        if _LLMHostsEngineNative is not None:
            return cast("list[str]", _LLMHostsEngineNative.available_backends())  # type: ignore[attr-defined]
        return ["cpu"]

    def status(self) -> dict[str, Any]:
        return {
            "available": LLMHOSTS_CORE_AVAILABLE,
            "loaded": self.is_loaded,
            "backend": self.backend_name,
            "available_backends": self.available_backends(),
        }


def query_cuda_devices() -> list[dict[str, Any]]:
    """Return CUDA device info for all NVIDIA GPUs on this machine.

    Returns an empty list if:
    - LLMHosts Core was not built with the ``cuda`` feature.
    - No NVIDIA GPU is present.
    - CUDA driver initialization fails.

    Each element contains: device_index, name, total_vram_bytes, free_vram_bytes,
    compute_capability_major, compute_capability_minor, cuda_driver_version.
    """
    if _cuda_device_info_fn is None:
        return []
    try:
        result: list[dict[str, Any]] = json.loads(_cuda_device_info_fn())
        return result
    except Exception as exc:
        logger.warning("cuda_device_info() failed: %s", exc)
        return []
