# -*- coding: utf-8 -*-
from fastapi import APIRouter, Depends

from ..auth import router as auth_router, require_auth
from .agent import router as agent_router, public_router as agent_public_router
from .config import router as config_router
from .local_models import router as local_models_router
from .providers import router as providers_router
from .skills import router as skills_router
from .workspace import router as workspace_router
from .envs import router as envs_router
from .ollama_models import router as ollama_models_router
from .mcp import router as mcp_router
from ..crons.api import router as cron_router
from ..runner.api import router as runner_router
from .console import router as console_router
from .upload import router as upload_router


router = APIRouter()

# Auth routes are public (login / status don't need auth)
router.include_router(auth_router)

# Agent health & service discovery are public (no auth needed)
router.include_router(agent_public_router)

# All other routes require authentication (when password protection is on)
_protected = APIRouter(dependencies=[Depends(require_auth)])

_protected.include_router(agent_router)
_protected.include_router(config_router)
_protected.include_router(console_router)
_protected.include_router(cron_router)
_protected.include_router(local_models_router)
_protected.include_router(mcp_router)
_protected.include_router(ollama_models_router)
_protected.include_router(providers_router)
_protected.include_router(runner_router)
_protected.include_router(skills_router)
_protected.include_router(upload_router)
_protected.include_router(workspace_router)
_protected.include_router(envs_router)

router.include_router(_protected)

__all__ = ["router"]
