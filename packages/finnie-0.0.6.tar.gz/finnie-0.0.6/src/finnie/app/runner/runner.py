# -*- coding: utf-8 -*-
# pylint: disable=unused-argument too-many-branches too-many-statements
"""AgentRunner — self-built runner, no agentscope_runtime dependency.

Replaces the old ``Runner`` base class from agentscope_runtime.  The key
method ``stream_query(request)`` directly consumes ``RunController.run()``
tokens and yields SSE events (ResponseEvent / MessageEvent / ContentEvent)
without passing through ``adapt_agentscope_message_stream``.
"""
import json
import logging
from pathlib import Path
from typing import Any, AsyncIterator

from dotenv import load_dotenv

from .session import SafeSession
from .run_controller import RunController
from .session_factory import SessionFactory
from .tool_registry import ToolRegistry
from .event_bridge import EventBridge
from ...agents.memory import MemoryManager
from ...constant import WORKING_DIR
from ..schemas import (
    AgentRequest,
    RunStatus,
    MessageType,
)
from ..schemas.events import (
    ResponseEvent,
    MessageEvent,
    ContentEvent,
    SequenceCounter,
)
from ..schemas.content_types import (
    ContentType,
    FunctionCall,
    FunctionCallOutput,
)

logger = logging.getLogger(__name__)


class AgentRunner:
    """Self-built runner that directly produces SSE events.

    ``stream_query(request)`` is consumed by:
      - ``/api/agent/process`` SSE endpoint (via _app.py)
      - Channels via ``make_process_from_runner(runner)``
    """

    def __init__(self) -> None:
        self._chat_manager = None
        self._mcp_manager = None
        self.session: SafeSession | None = None
        self.memory_manager: MemoryManager | None = None

    # ----- external dependency injection -----

    def set_chat_manager(self, chat_manager):
        """Set chat manager for auto-registration."""
        self._chat_manager = chat_manager

    def set_mcp_manager(self, mcp_manager):
        """Set MCP client manager for hot-reload support."""
        self._mcp_manager = mcp_manager

    # ----- lifecycle -----

    async def start(self):
        """Initialise session, memory, etc. (replaces init_handler)."""
        env_path = Path(__file__).resolve().parents[4] / ".env"
        if env_path.exists():
            load_dotenv(env_path)
            logger.debug("Loaded environment variables from %s", env_path)
        else:
            logger.debug(
                ".env file not found at %s, using existing environment variables",
                env_path,
            )

        session_dir = str(WORKING_DIR / "sessions")
        self.session = SafeSession(save_dir=session_dir)

        try:
            if self.memory_manager is None:
                self.memory_manager = MemoryManager(
                    working_dir=str(WORKING_DIR),
                )
            await self.memory_manager.start()
        except Exception as e:
            logger.exception("MemoryManager start failed: %s", e)

    async def stop(self):
        """Shutdown handler."""
        try:
            if self.memory_manager:
                await self.memory_manager.close()
        except Exception as e:
            logger.warning("MemoryManager stop failed: %s", e)

    # ----- core: stream_query -----

    async def stream_query(
        self,
        request: Any,
    ) -> AsyncIterator[Any]:
        """Core SSE event generator.

        Directly consumes RunController.run() token stream and yields
        SSE events — no adapt_agentscope_message_stream, no aggregation.

        Yields:
            ResponseEvent / MessageEvent / ContentEvent instances with
            correct sequence_number, object, status fields.
        """
        seq = SequenceCounter()

        # Parse request if it's a raw dict
        if isinstance(request, dict):
            request = AgentRequest(**request)

        # 1. Response created → in_progress
        resp = ResponseEvent(
            status=RunStatus.Created,
            session_id=getattr(request, "session_id", ""),
        )
        yield seq.stamp(resp)

        resp_ip = resp.model_copy(update={"status": RunStatus.InProgress})
        yield seq.stamp(resp_ip)

        # 2. Consume RunController.run() token stream
        current_msg: MessageEvent | None = None
        message_buffers: dict[str, dict[str, Any]] = {}

        def _buffer_for(msg_id: str) -> dict[str, Any]:
            return message_buffers.setdefault(
                msg_id,
                {"text": "", "blocks": []},
            )

        def _append_text(msg_id: str, text: str) -> None:
            if not msg_id or not text:
                return
            buf = _buffer_for(msg_id)
            buf["text"] = (buf.get("text", "") or "") + text

        def _append_block(msg_id: str, block: dict[str, Any]) -> None:
            if not msg_id:
                return
            _buffer_for(msg_id)["blocks"].append(block)

        def _buffered_text(msg_id: str) -> str:
            if not msg_id:
                return ""
            return str((message_buffers.get(msg_id) or {}).get("text") or "")

        def _hydrate_message_content(msg: MessageEvent | None) -> None:
            if msg is None:
                return
            buf = message_buffers.pop(msg.id, None)
            if not buf:
                return
            text = str(buf.get("text") or "")
            blocks = list(buf.get("blocks") or [])
            content: list[dict[str, Any]] = []
            if text:
                content.append({"type": "text", "text": text})
            content.extend(blocks)
            msg.content = content

        try:
            if self.session is None:
                raise RuntimeError("Session is not initialised")

            session_factory = SessionFactory(
                session=self.session,
                memory_manager=self.memory_manager,
                chat_manager=self._chat_manager,
            )
            tool_registry = ToolRegistry(mcp_manager=self._mcp_manager)
            event_bridge = EventBridge()
            controller = RunController(
                session_factory=session_factory,
                tool_registry=tool_registry,
                event_bridge=event_bridge,
            )

            async for msg, is_last in controller.run(
                msgs=request.input,
                request=request,
            ):
                content = (
                    getattr(msg, "content", "")
                    if hasattr(msg, "content")
                    else str(msg)
                )
                current_id = current_msg.id if current_msg is not None else ""
                has_streamed_text = bool(_buffered_text(current_id))

                # --- text token (str content) ---
                if isinstance(content, str):
                    if current_msg is None:
                        current_msg = MessageEvent(
                            status=RunStatus.InProgress,
                            type=MessageType.MESSAGE,
                            role=getattr(msg, "role", "assistant"),
                        )
                        yield seq.stamp(current_msg.model_copy())
                    # LangGraph may emit final full text (is_last=True)
                    # after streaming chunks. Skip adding duplicated final
                    # full text when we already buffered streamed text.
                    if not (is_last and has_streamed_text):
                        _append_text(current_msg.id, content)
                        yield seq.stamp(ContentEvent(
                            status=RunStatus.InProgress,
                            type=ContentType.TEXT,
                            delta=True,
                            text=content,
                            msg_id=current_msg.id,
                        ))

                # --- structured content (list of blocks) ---
                elif isinstance(content, list):
                    for block in content:
                        if not isinstance(block, dict):
                            continue
                        btype = block.get("type", "text")

                        if btype == "text":
                            if current_msg is None:
                                current_msg = MessageEvent(
                                    status=RunStatus.InProgress,
                                    type=MessageType.MESSAGE,
                                    role=getattr(msg, "role", "assistant"),
                                )
                                yield seq.stamp(current_msg.model_copy())
                            if is_last and has_streamed_text:
                                continue
                            text_block = block.get("text", "")
                            _append_text(current_msg.id, text_block)
                            yield seq.stamp(ContentEvent(
                                status=RunStatus.InProgress,
                                type=ContentType.TEXT,
                                delta=True,
                                text=text_block,
                                msg_id=current_msg.id,
                            ))

                        elif btype == "thinking":
                            # Close any open message
                            if current_msg is not None:
                                current_msg.status = RunStatus.Completed
                                _hydrate_message_content(current_msg)
                                yield seq.stamp(current_msg.model_copy())
                                current_msg = None

                            reasoning_msg = MessageEvent(
                                status=RunStatus.InProgress,
                                type=MessageType.REASONING,
                            )
                            yield seq.stamp(reasoning_msg.model_copy())
                            thinking_text = block.get("thinking", "")
                            _append_text(reasoning_msg.id, thinking_text)
                            yield seq.stamp(ContentEvent(
                                status=RunStatus.InProgress,
                                type=ContentType.TEXT,
                                delta=True,
                                text=thinking_text,
                                msg_id=reasoning_msg.id,
                            ))
                            reasoning_msg.status = RunStatus.Completed
                            _hydrate_message_content(reasoning_msg)
                            yield seq.stamp(reasoning_msg.model_copy())

                        elif btype == "tool_use":
                            # Close any open message
                            if current_msg is not None:
                                current_msg.status = RunStatus.Completed
                                _hydrate_message_content(current_msg)
                                yield seq.stamp(current_msg.model_copy())
                                current_msg = None

                            plugin_msg = MessageEvent(
                                status=RunStatus.InProgress,
                                type=MessageType.PLUGIN_CALL,
                            )
                            yield seq.stamp(plugin_msg.model_copy())

                            arguments = block.get("input", {})
                            if isinstance(arguments, (dict, list)):
                                arguments = json.dumps(
                                    arguments, ensure_ascii=False,
                                )

                            call_data = FunctionCall(
                                call_id=block.get("id"),
                                name=block.get("name"),
                                arguments=arguments,
                            ).model_dump()
                            _append_block(
                                plugin_msg.id,
                                {
                                    "type": ContentType.DATA,
                                    "data": call_data,
                                },
                            )

                            yield seq.stamp(ContentEvent(
                                status=RunStatus.InProgress,
                                type=ContentType.DATA,
                                delta=False,
                                data=call_data,
                                msg_id=plugin_msg.id,
                            ))
                            plugin_msg.status = RunStatus.Completed
                            _hydrate_message_content(plugin_msg)
                            yield seq.stamp(plugin_msg.model_copy())

                        elif btype == "tool_result":
                            # Close any open message
                            if current_msg is not None:
                                current_msg.status = RunStatus.Completed
                                _hydrate_message_content(current_msg)
                                yield seq.stamp(current_msg.model_copy())
                                current_msg = None

                            output_msg = MessageEvent(
                                status=RunStatus.InProgress,
                                type=MessageType.PLUGIN_CALL_OUTPUT,
                            )
                            yield seq.stamp(output_msg.model_copy())

                            output_val = block.get("output") or block.get("content", "")
                            if isinstance(output_val, (dict, list)):
                                output_val = json.dumps(
                                    output_val, ensure_ascii=False,
                                )

                            output_data = FunctionCallOutput(
                                call_id=block.get("id") or block.get("tool_use_id"),
                                name=block.get("name"),
                                output=output_val,
                            ).model_dump(exclude_none=True)
                            _append_block(
                                output_msg.id,
                                {
                                    "type": ContentType.DATA,
                                    "data": output_data,
                                },
                            )

                            yield seq.stamp(ContentEvent(
                                status=RunStatus.InProgress,
                                type=ContentType.DATA,
                                delta=False,
                                data=output_data,
                                msg_id=output_msg.id,
                            ))
                            output_msg.status = RunStatus.Completed
                            _hydrate_message_content(output_msg)
                            yield seq.stamp(output_msg.model_copy())

                        elif btype == "image":
                            if current_msg is None:
                                current_msg = MessageEvent(
                                    status=RunStatus.InProgress,
                                    type=MessageType.MESSAGE,
                                    role=getattr(msg, "role", "assistant"),
                                )
                                yield seq.stamp(current_msg.model_copy())

                            source = block.get("source", {}) or {}
                            image_url = ""
                            if isinstance(source, dict):
                                if source.get("type") == "url":
                                    image_url = source.get("url", "")
                                elif source.get("type") == "base64":
                                    mt = source.get("media_type", "image/jpeg")
                                    b64 = source.get("data", "")
                                    image_url = f"data:{mt};base64,{b64}"
                            if image_url:
                                _append_block(
                                    current_msg.id,
                                    {
                                        "type": ContentType.IMAGE,
                                        "source": {
                                            "type": "url",
                                            "url": image_url,
                                        },
                                    },
                                )

                            yield seq.stamp(ContentEvent(
                                status=RunStatus.InProgress,
                                type=ContentType.IMAGE,
                                delta=False,
                                image_url=image_url,
                                msg_id=current_msg.id,
                            ))

                        elif btype == "file":
                            if current_msg is None:
                                current_msg = MessageEvent(
                                    status=RunStatus.InProgress,
                                    type=MessageType.MESSAGE,
                                    role=getattr(msg, "role", "assistant"),
                                )
                                yield seq.stamp(current_msg.model_copy())
                            file_url = block.get("file_url") or block.get("url", "")
                            filename = block.get("filename") or block.get("name", "")
                            _append_block(
                                current_msg.id,
                                {
                                    "type": ContentType.FILE,
                                    "source": {
                                        "type": "url",
                                        "url": file_url,
                                    },
                                    "filename": filename,
                                },
                            )

                            yield seq.stamp(ContentEvent(
                                status=RunStatus.InProgress,
                                type=ContentType.FILE,
                                delta=False,
                                file_url=file_url,
                                filename=filename,
                                msg_id=current_msg.id,
                            ))

                # is_last → close current message
                if is_last and current_msg is not None:
                    current_msg.status = RunStatus.Completed
                    _hydrate_message_content(current_msg)
                    yield seq.stamp(current_msg.model_copy())
                    current_msg = None

        except Exception as e:
            logger.exception("stream_query error: %s", e)
            # Close any open message as failed
            if current_msg is not None:
                current_msg.status = RunStatus.Failed
                current_msg.error = str(e)
                _hydrate_message_content(current_msg)
                yield seq.stamp(current_msg.model_copy())
            # Response failed
            resp_fail = resp.model_copy(
                update={
                    "status": RunStatus.Failed,
                    "error": {"message": str(e)},
                },
            )
            yield seq.stamp(resp_fail)
            return

        # 3. Response completed
        resp_done = resp.model_copy(update={"status": RunStatus.Completed})
        yield seq.stamp(resp_done)
