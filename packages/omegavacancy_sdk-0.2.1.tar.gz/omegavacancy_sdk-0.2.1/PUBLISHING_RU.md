# Публикация `omegavacancy-sdk` в TestPyPI/PyPI

Документ описывает текущие методы SDK/API и релизный pipeline публикации пакета.

## 1. Какие методы доступны сейчас

### Интеграционный API

- `POST /api/v1/vacancies`
- `DELETE /api/v1/vacancies/{vacancy_id}`

Требования:
- Заголовок `X-API-Key: ovk_<kid>_<secret>`
- Scope ключа: `vacancy:write`

### Внутренние функции API-ключей (`app/core/api_key_auth.py`)

- `generate_kid`
- `generate_secret`
- `build_api_key`
- `parse_api_key`
- `hash_api_secret`
- `verify_api_secret`
- `parse_expires_at`
- `is_key_expired`
- `normalize_scopes`
- `_client_ip`
- `require_api_key_scope`

### Репозиторий ключей (`IntegrationApiKeyRepository`)

- `create_key`
- `list_keys`
- `get_by_id`
- `get_by_kid`
- `revoke_key`
- `touch_last_used`

### SDK-клиент (`OmegaVacancyClient`)

- `__init__`
- `close`
- `__enter__`
- `__exit__`
- `create_vacancy`
- `create_vacancies`
- `delete_vacancy`
- `_request`
- `_extract_message`

### Модели результата

- `CreateVacancyResult.from_dict`
- `DeleteVacancyResult.from_dict`

### Исключения SDK

- `OmegaVacancyError`
- `OmegaVacancyAuthError`
- `OmegaVacancyValidationError`
- `OmegaVacancyServerError`

## 2. Версионирование перед релизом

Источник версии: `pyproject.toml` -> `project.version`.

Правило bump:
- Patch (`0.1.0 -> 0.1.1`) — исправления без изменения контракта.
- Minor (`0.1.0 -> 0.2.0`) — добавление совместимых методов/возможностей.
- Major (`0.x.y -> 1.0.0` и далее) — несовместимые изменения API/SDK.

## 3. Сборка пакета

Из директории `sdk/python`:

```bash
python3 -m pip install --upgrade build twine
python3 -m build
python3 -m twine check dist/*
```

Ожидаемый результат:
- В `dist/` появляются `.whl` и `.tar.gz`
- `twine check` проходит без ошибок

## 4. Публикация в TestPyPI

```bash
python3 -m twine upload --repository testpypi dist/*
```

Авторизация:
- username: `__token__`
- password: `pypi-...` (токен TestPyPI)

Проверка установки:

```bash
pip install -i https://test.pypi.org/simple omegavacancy-sdk
```

## 5. Публикация в PyPI

```bash
python3 -m twine upload dist/*
```

Авторизация:
- username: `__token__`
- password: `pypi-...` (токен PyPI)

## 6. Хранение токенов (локально и в CI)

Рекомендуется не вводить токены вручную и не хранить их в репозитории.

Локально:
- использовать переменные окружения (`TWINE_USERNAME`, `TWINE_PASSWORD`)
- или `~/.pypirc` (без коммита в git)

В CI:
- хранить токены как Secrets/Variables
- использовать `__token__` + токен `pypi-...` в шаге `twine upload`

## 7. Smoke-check после релиза

Минимальная проверка после публикации:

```python
from omegavacancy_sdk import OmegaVacancyClient

client = OmegaVacancyClient(base_url="https://your-host", api_key="ovk_kid_secret")
print("SDK import OK")
client.close()
```

Опционально выполнить один реальный вызов:
- `create_vacancy(...)` на тестовом стенде
- затем `delete_vacancy(...)` для созданной вакансии

## 8. Короткий релизный чек-лист

1. Обновить `project.version` в `pyproject.toml`.
2. Прогнать тесты SDK/API.
3. Собрать пакет (`build`) и проверить (`twine check`).
4. Опубликовать в TestPyPI и проверить установку.
5. Опубликовать в PyPI.
6. Выполнить smoke-check импорта и базового вызова.
