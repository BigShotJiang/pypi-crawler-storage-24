class OmegaVacancyError(Exception):
    """Базовое исключение SDK для ошибок интеграционного API вакансий."""

    def __init__(self, message: str, *, status_code: int | None = None, payload: object | None = None):
        """
        Создать объект ошибки SDK с контекстом HTTP-ответа.

        Args:
            message: Человекочитаемое описание ошибки.
            status_code: HTTP-статус ответа (если есть).
            payload: Исходный payload ошибки (JSON или текст).

        Returns:
            None.
        """
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


class OmegaVacancyAuthError(OmegaVacancyError):
    """Ошибка авторизации/доступа (обычно HTTP 401/403)."""

    pass


class OmegaVacancyValidationError(OmegaVacancyError):
    """Ошибка валидации входных данных (обычно HTTP 422)."""

    pass


class OmegaVacancyServerError(OmegaVacancyError):
    """Сетевая ошибка или серверная ошибка (обычно HTTP 5xx)."""

    pass
