from __future__ import annotations

import time
from typing import Any

import httpx

from .client import SDK_VERSION
from .exceptions import (
    OmegaVacancyAuthError,
    OmegaVacancyError,
    OmegaVacancyServerError,
    OmegaVacancyValidationError,
)

BASE_URL = "https://omegahire.tech"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2
DEFAULT_RETRY_BACKOFF = 0.5
RETRYABLE_STATUS_CODES = (408, 429, 500, 502, 503, 504)


def get_vacancies(
    api_key: str,
    *,
    timeout: float | httpx.Timeout = DEFAULT_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
    retry_backoff: float = DEFAULT_RETRY_BACKOFF,
) -> dict[str, Any]:
    """
    Получить список вакансий через `GET /api/v1/vacancies`.

    Args:
        api_key: Интеграционный API-ключ формата `ovk_<kid>_<secret>`.

    Returns:
        JSON-ответ API в виде словаря.
    """
    return _request(
        "GET",
        "/api/v1/vacancies",
        api_key=api_key,
        timeout=timeout,
        max_retries=max_retries,
        retry_backoff=retry_backoff,
    )


def create_vacancy(
    api_key: str,
    vacancy_json: dict[str, Any],
    *,
    timeout: float | httpx.Timeout = DEFAULT_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
    retry_backoff: float = DEFAULT_RETRY_BACKOFF,
) -> dict[str, Any]:
    """
    Создать вакансию через `POST /api/v1/vacancies`.

    Args:
        api_key: Интеграционный API-ключ формата `ovk_<kid>_<secret>`.
        vacancy_json: JSON-словарь с данными вакансии.

    Returns:
        JSON-ответ API в виде словаря.

    Raises:
        ValueError: Если `vacancy_json` не является словарем.
    """
    if not isinstance(vacancy_json, dict):
        raise ValueError("vacancy_json must be a dict")
    return _request(
        "POST",
        "/api/v1/vacancies",
        api_key=api_key,
        json=vacancy_json,
        timeout=timeout,
        max_retries=max_retries,
        retry_backoff=retry_backoff,
    )


def delete_vacancy(
    api_key: str,
    vacancy_id: str,
    *,
    timeout: float | httpx.Timeout = DEFAULT_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
    retry_backoff: float = DEFAULT_RETRY_BACKOFF,
) -> dict[str, Any]:
    """
    Удалить вакансию через `DELETE /api/v1/vacancies/{vacancy_id}`.

    Args:
        api_key: Интеграционный API-ключ формата `ovk_<kid>_<secret>`.
        vacancy_id: Идентификатор вакансии.

    Returns:
        JSON-ответ API в виде словаря.

    Raises:
        ValueError: Если `vacancy_id` пустой.
    """
    cleaned_id = str(vacancy_id or "").strip()
    if not cleaned_id:
        raise ValueError("vacancy_id is required")
    return _request(
        "DELETE",
        f"/api/v1/vacancies/{cleaned_id}",
        api_key=api_key,
        timeout=timeout,
        max_retries=max_retries,
        retry_backoff=retry_backoff,
    )


def _request(
    method: str,
    path: str,
    *,
    api_key: str,
    json: dict[str, Any] | None = None,
    timeout: float | httpx.Timeout = DEFAULT_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
    retry_backoff: float = DEFAULT_RETRY_BACKOFF,
) -> dict[str, Any]:
    """
    Выполнить HTTP-запрос к интеграционному API и обработать ошибки.

    Args:
        method: HTTP-метод (`GET`, `POST`, `DELETE` и т.д.).
        path: Относительный путь API.
        api_key: Интеграционный API-ключ.
        json: JSON-тело запроса для методов с payload.

    Returns:
        JSON-ответ API в виде словаря.

    Raises:
        ValueError: Если `api_key` пустой.
        OmegaVacancyAuthError: Ошибка авторизации (401/403).
        OmegaVacancyValidationError: Ошибка валидации (422).
        OmegaVacancyServerError: Сетевая или серверная ошибка (5xx).
        OmegaVacancyError: Прочие ошибки API.
    """
    cleaned_key = str(api_key or "").strip()
    if not cleaned_key:
        raise ValueError("api_key is required")

    url = f"{BASE_URL}{path}"
    headers = {
        "X-API-Key": cleaned_key,
        "User-Agent": f"omegavacancy-sdk/{SDK_VERSION}",
        "Content-Type": "application/json",
    }
    request_kwargs: dict[str, Any] = {
        "headers": headers,
        "timeout": _normalize_timeout(timeout),
    }
    if json is not None:
        request_kwargs["json"] = json

    retries = max(0, int(max_retries))
    backoff = max(0.0, float(retry_backoff))
    attempts = retries + 1
    response = None
    for attempt in range(attempts):
        try:
            response = httpx.request(method, url, **request_kwargs)
        except httpx.HTTPError as exc:
            is_retryable_transport = isinstance(exc, (httpx.TimeoutException, httpx.TransportError))
            if is_retryable_transport and attempt < attempts - 1:
                _sleep_before_retry(backoff, attempt)
                continue
            if isinstance(exc, httpx.ReadTimeout):
                timeout_hint = _read_timeout_hint(request_kwargs["timeout"])
                message = "Network error: The read operation timed out."
                if timeout_hint:
                    message = f"{message} Current read timeout={timeout_hint}."
                message = f"{message} Try increasing timeout and/or max_retries."
                raise OmegaVacancyServerError(message) from exc
            raise OmegaVacancyServerError(f"Network error: {exc}") from exc

        if response.status_code in RETRYABLE_STATUS_CODES and attempt < attempts - 1:
            _sleep_before_retry(backoff, attempt)
            continue
        break

    if response is None:
        raise OmegaVacancyServerError("Network error: request did not complete")

    payload: Any
    try:
        payload = response.json()
    except Exception:
        payload = response.text

    if response.status_code in (401, 403):
        raise OmegaVacancyAuthError(
            _extract_message(payload, response.status_code),
            status_code=response.status_code,
            payload=payload,
        )
    if response.status_code == 422:
        raise OmegaVacancyValidationError(
            _extract_message(payload, response.status_code),
            status_code=response.status_code,
            payload=payload,
        )
    if response.status_code >= 500:
        raise OmegaVacancyServerError(
            _extract_message(payload, response.status_code),
            status_code=response.status_code,
            payload=payload,
        )
    if response.status_code >= 400:
        raise OmegaVacancyError(
            _extract_message(payload, response.status_code),
            status_code=response.status_code,
            payload=payload,
        )

    if isinstance(payload, dict):
        return payload

    raise OmegaVacancyError(
        "Unexpected response format",
        status_code=response.status_code,
        payload=payload,
    )


def _normalize_timeout(timeout: float | httpx.Timeout) -> float | httpx.Timeout:
    if isinstance(timeout, httpx.Timeout):
        return timeout
    timeout_value = float(timeout)
    if timeout_value <= 0:
        raise ValueError("timeout must be > 0")
    return timeout_value


def _sleep_before_retry(backoff: float, attempt: int) -> None:
    delay = backoff * (2**attempt)
    if delay > 0:
        time.sleep(delay)


def _read_timeout_hint(timeout: float | httpx.Timeout) -> str:
    if isinstance(timeout, httpx.Timeout):
        read_timeout = timeout.read
    else:
        read_timeout = timeout
    if read_timeout is None:
        return ""
    try:
        return f"{float(read_timeout):g}s"
    except (TypeError, ValueError):
        return str(read_timeout)


def _extract_message(payload: object, status_code: int) -> str:
    """
    Извлечь человекочитаемое сообщение об ошибке из payload ответа.

    Args:
        payload: JSON-объект или текст ответа.
        status_code: HTTP-статус ответа.

    Returns:
        Текст ошибки, пригодный для исключения SDK.
    """
    if isinstance(payload, dict) and "detail" in payload:
        return str(payload["detail"])
    if isinstance(payload, dict) and "message" in payload:
        return str(payload["message"])
    if isinstance(payload, str) and payload.strip():
        return payload.strip()
    return f"Request failed ({status_code})"
