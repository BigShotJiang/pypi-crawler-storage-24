from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CreateVacancyResult:
    """Результат создания одной или нескольких вакансий через интеграционный API."""

    success: bool
    created_count: int
    vacancy_ids: list[str]
    message: str

    @classmethod
    def from_dict(cls, data: dict) -> "CreateVacancyResult":
        """
        Построить `CreateVacancyResult` из JSON-словаря ответа API.

        Args:
            data: Словарь ответа API.

        Returns:
            Экземпляр `CreateVacancyResult` с нормализованными полями.
        """
        vacancy_ids_raw = data.get("vacancy_ids") or []
        vacancy_ids = [str(item) for item in vacancy_ids_raw if str(item).strip()]
        return cls(
            success=bool(data.get("success", False)),
            created_count=int(data.get("created_count", len(vacancy_ids))),
            vacancy_ids=vacancy_ids,
            message=str(data.get("message") or ""),
        )


@dataclass(frozen=True)
class DeleteVacancyResult:
    """Результат удаления вакансии через интеграционный API."""

    success: bool
    vacancy_id: str
    message: str

    @classmethod
    def from_dict(cls, data: dict) -> "DeleteVacancyResult":
        """
        Построить `DeleteVacancyResult` из JSON-словаря ответа API.

        Args:
            data: Словарь ответа API.

        Returns:
            Экземпляр `DeleteVacancyResult` с нормализованными полями.
        """
        return cls(
            success=bool(data.get("success", False)),
            vacancy_id=str(data.get("vacancy_id") or ""),
            message=str(data.get("message") or ""),
        )
