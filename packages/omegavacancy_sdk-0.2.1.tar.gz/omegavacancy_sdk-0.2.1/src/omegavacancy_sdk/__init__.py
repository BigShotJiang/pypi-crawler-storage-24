from .client import OmegaVacancyClient
from .exceptions import (
    OmegaVacancyAuthError,
    OmegaVacancyError,
    OmegaVacancyServerError,
    OmegaVacancyValidationError,
)
from .models import CreateVacancyResult, DeleteVacancyResult
from .simple_api import create_vacancy, delete_vacancy, get_vacancies

__all__ = [
    "OmegaVacancyClient",
    "get_vacancies",
    "create_vacancy",
    "delete_vacancy",
    "CreateVacancyResult",
    "DeleteVacancyResult",
    "OmegaVacancyError",
    "OmegaVacancyAuthError",
    "OmegaVacancyValidationError",
    "OmegaVacancyServerError",
]

__version__ = "0.2.1"
