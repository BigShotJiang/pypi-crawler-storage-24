from __future__ import annotations

import time
from typing import Any

import httpx

from .exceptions import (
    OmegaVacancyAuthError,
    OmegaVacancyError,
    OmegaVacancyServerError,
    OmegaVacancyValidationError,
)
from .models import CreateVacancyResult, DeleteVacancyResult

SDK_VERSION = "0.2.1"
DEFAULT_MAX_RETRIES = 2
DEFAULT_RETRY_BACKOFF = 0.5
RETRYABLE_STATUS_CODES = (408, 429, 500, 502, 503, 504)


class OmegaVacancyClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float | httpx.Timeout = 30.0,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_backoff: float = DEFAULT_RETRY_BACKOFF,
    ):
        """
        Создать sync-клиент для работы с интеграционным API вакансий.

        Args:
            base_url: Базовый URL сервера (например, `https://example.com`).
            api_key: Интеграционный API-ключ формата `ovk_<kid>_<secret>`.
            timeout: Таймаут HTTP-запросов в секундах или `httpx.Timeout`.
            max_retries: Количество повторных попыток для временных сетевых/серверных сбоев.
            retry_backoff: Базовая пауза (сек) между ретраями (экспоненциальный backoff).

        Returns:
            None.

        Raises:
            ValueError: Если `base_url` или `api_key` пустые.
        """
        if not base_url or not str(base_url).strip():
            raise ValueError("base_url is required")
        if not api_key or not str(api_key).strip():
            raise ValueError("api_key is required")

        self.base_url = str(base_url).rstrip("/")
        self.api_key = str(api_key).strip()
        self.timeout = self._normalize_timeout(timeout)
        self.max_retries = max(0, int(max_retries))
        self.retry_backoff = max(0.0, float(retry_backoff))
        self._client = httpx.Client(
            timeout=self.timeout,
            headers={
                "X-API-Key": self.api_key,
                "User-Agent": f"omegavacancy-sdk/{SDK_VERSION}",
                "Content-Type": "application/json",
            },
        )

    def close(self) -> None:
        """
        Закрыть внутренний HTTP-клиент и освободить ресурсы.

        Returns:
            None.
        """
        self._client.close()

    def __enter__(self) -> "OmegaVacancyClient":
        """
        Войти в контекстный менеджер `with`.

        Returns:
            Текущий экземпляр `OmegaVacancyClient`.
        """
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        """
        Выйти из контекстного менеджера и закрыть HTTP-клиент.

        Args:
            exc_type: Тип исключения (если возникло в блоке `with`).
            exc: Объект исключения.
            tb: Traceback исключения.

        Returns:
            None.
        """
        self.close()

    def create_vacancy(self, vacancy: dict[str, Any]) -> CreateVacancyResult:
        """
        Создать одну вакансию через `POST /api/v1/vacancies`.

        Args:
            vacancy: Словарь полей вакансии.

        Returns:
            Объект `CreateVacancyResult`.

        Raises:
            OmegaVacancyAuthError: Ошибка авторизации (401/403).
            OmegaVacancyValidationError: Ошибка валидации payload (422).
            OmegaVacancyServerError: Сетевая или серверная ошибка (5xx).
            OmegaVacancyError: Прочие HTTP-ошибки.
        """
        payload = self._request("POST", "/api/v1/vacancies", json=vacancy)
        return CreateVacancyResult.from_dict(payload)

    def create_vacancies(self, vacancies: list[dict[str, Any]]) -> CreateVacancyResult:
        """
        Создать несколько вакансий за один запрос.

        Args:
            vacancies: Список словарей вакансий.

        Returns:
            Объект `CreateVacancyResult`.

        Raises:
            OmegaVacancyAuthError: Ошибка авторизации (401/403).
            OmegaVacancyValidationError: Ошибка валидации payload (422).
            OmegaVacancyServerError: Сетевая или серверная ошибка (5xx).
            OmegaVacancyError: Прочие HTTP-ошибки.
        """
        payload = self._request("POST", "/api/v1/vacancies", json=vacancies)
        return CreateVacancyResult.from_dict(payload)

    def delete_vacancy(self, vacancy_id: str) -> DeleteVacancyResult:
        """
        Удалить вакансию по `vacancy_id` через `DELETE /api/v1/vacancies/{vacancy_id}`.

        Args:
            vacancy_id: Идентификатор вакансии.

        Returns:
            Объект `DeleteVacancyResult`.

        Raises:
            ValueError: Если `vacancy_id` пустой.
            OmegaVacancyAuthError: Ошибка авторизации (401/403).
            OmegaVacancyValidationError: Ошибка валидации payload (422).
            OmegaVacancyServerError: Сетевая или серверная ошибка (5xx).
            OmegaVacancyError: Прочие HTTP-ошибки.
        """
        cleaned_id = str(vacancy_id or "").strip()
        if not cleaned_id:
            raise ValueError("vacancy_id is required")
        payload = self._request("DELETE", f"/api/v1/vacancies/{cleaned_id}")
        return DeleteVacancyResult.from_dict(payload)

    def _request(self, method: str, path: str, **kwargs) -> dict[str, Any]:
        """
        Выполнить HTTP-запрос к API и нормализовать обработку ошибок.

        Args:
            method: HTTP-метод (`GET`, `POST`, `DELETE` и т.д.).
            path: Путь API относительно `base_url`.
            **kwargs: Дополнительные параметры для `httpx.Client.request`.

        Returns:
            JSON-объект ответа в виде словаря.

        Raises:
            OmegaVacancyAuthError: Ошибка авторизации (401/403).
            OmegaVacancyValidationError: Ошибка валидации payload (422).
            OmegaVacancyServerError: Сетевая ошибка или серверный статус (5xx).
            OmegaVacancyError: Прочие ошибки или неожиданный формат ответа.
        """
        url = f"{self.base_url}{path}"
        attempts = self.max_retries + 1
        response = None
        for attempt in range(attempts):
            try:
                response = self._client.request(method, url, **kwargs)
            except httpx.HTTPError as exc:
                is_retryable_transport = isinstance(exc, (httpx.TimeoutException, httpx.TransportError))
                if is_retryable_transport and attempt < attempts - 1:
                    self._sleep_before_retry(attempt)
                    continue
                if isinstance(exc, httpx.ReadTimeout):
                    timeout_hint = self._read_timeout_hint()
                    message = "Network error: The read operation timed out."
                    if timeout_hint:
                        message = f"{message} Current read timeout={timeout_hint}."
                    message = f"{message} Try increasing timeout and/or max_retries."
                    raise OmegaVacancyServerError(message) from exc
                raise OmegaVacancyServerError(f"Network error: {exc}") from exc

            if response.status_code in RETRYABLE_STATUS_CODES and attempt < attempts - 1:
                self._sleep_before_retry(attempt)
                continue
            break

        if response is None:
            raise OmegaVacancyServerError("Network error: request did not complete")

        payload: Any
        try:
            payload = response.json()
        except Exception:
            payload = response.text

        if response.status_code in (401, 403):
            raise OmegaVacancyAuthError(
                self._extract_message(payload, response.status_code),
                status_code=response.status_code,
                payload=payload,
            )
        if response.status_code == 422:
            raise OmegaVacancyValidationError(
                self._extract_message(payload, response.status_code),
                status_code=response.status_code,
                payload=payload,
            )
        if response.status_code >= 500:
            raise OmegaVacancyServerError(
                self._extract_message(payload, response.status_code),
                status_code=response.status_code,
                payload=payload,
            )
        if response.status_code >= 400:
            raise OmegaVacancyError(
                self._extract_message(payload, response.status_code),
                status_code=response.status_code,
                payload=payload,
            )

        if isinstance(payload, dict):
            return payload
        raise OmegaVacancyError(
            "Unexpected response format",
            status_code=response.status_code,
            payload=payload,
        )

    @staticmethod
    def _normalize_timeout(timeout: float | httpx.Timeout) -> float | httpx.Timeout:
        if isinstance(timeout, httpx.Timeout):
            return timeout
        timeout_value = float(timeout)
        if timeout_value <= 0:
            raise ValueError("timeout must be > 0")
        return timeout_value

    def _sleep_before_retry(self, attempt: int) -> None:
        delay = self.retry_backoff * (2**attempt)
        if delay > 0:
            time.sleep(delay)

    def _read_timeout_hint(self) -> str:
        if isinstance(self.timeout, httpx.Timeout):
            read_timeout = self.timeout.read
        else:
            read_timeout = self.timeout
        if read_timeout is None:
            return ""
        try:
            return f"{float(read_timeout):g}s"
        except (TypeError, ValueError):
            return str(read_timeout)

    @staticmethod
    def _extract_message(payload: object, status_code: int) -> str:
        """
        Извлечь человекочитаемое сообщение об ошибке из payload ответа.

        Args:
            payload: JSON-объект или текст ответа.
            status_code: HTTP-статус ответа.

        Returns:
            Текст ошибки, пригодный для исключения SDK.
        """
        if isinstance(payload, dict) and "detail" in payload:
            return str(payload["detail"])
        if isinstance(payload, dict) and "message" in payload:
            return str(payload["message"])
        if isinstance(payload, str) and payload.strip():
            return payload.strip()
        return f"Request failed ({status_code})"
