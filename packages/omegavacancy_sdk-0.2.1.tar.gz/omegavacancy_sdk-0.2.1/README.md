# omegavacancy-sdk

Python SDK для интеграционного API OmegaHire (`/api/v1/vacancies`).

Подробная инструкция публикации в TestPyPI/PyPI: [PUBLISHING_RU.md](./PUBLISHING_RU.md).

## Install

```bash
pip install -e .
```

## Usage

### Быстрый API (без base_url) — рекомендуется

```python
from omegavacancy_sdk import create_vacancy, delete_vacancy, get_vacancies

api_key = "ovk_xxxxx_secret"

vacancies = get_vacancies(api_key)
print(vacancies["count"])

created = create_vacancy(
    api_key,
    {
        "title": "Python Developer",
        "vacancy_text": "Need FastAPI + PostgreSQL",
        "skills": ["Python", "FastAPI"],
    },
)
print(created["vacancy_ids"])

deleted = delete_vacancy(api_key, "AB-12345")
print(deleted["success"], deleted["vacancy_id"])

# При медленном ответе сервера можно увеличить таймаут и число ретраев
created_retry = create_vacancy(
    api_key,
    {"title": "Data Engineer"},
    timeout=90.0,
    max_retries=3,
)
print(created_retry["success"])
```

В этом режиме SDK использует встроенный адрес API: `https://omegahire.tech`.

### Расширенный API (`OmegaVacancyClient`)

```python
from omegavacancy_sdk import OmegaVacancyClient

api_key = "ovk_xxxxx_secret"

with OmegaVacancyClient(
    base_url="https://your-host",
    api_key=api_key,
    timeout=90.0,
    max_retries=3,
) as client:
    created = client.create_vacancy({
        "title": "Python Developer",
        "vacancy_text": "Need FastAPI + PostgreSQL",
        "skills": ["Python", "FastAPI"],
    })
    print(created.vacancy_ids)

    for vacancy_id in created.vacancy_ids:
        deleted = client.delete_vacancy(vacancy_id)
        print(deleted.success, deleted.vacancy_id)
```

## Errors

- `OmegaVacancyAuthError` — 401/403
- `OmegaVacancyValidationError` — 422
- `OmegaVacancyServerError` — 5xx/transport
- `OmegaVacancyError` — прочие ошибки

## Какие методы доступны сейчас

### Быстрый модуль

- `get_vacancies(api_key: str, *, timeout: float | httpx.Timeout = 30.0, max_retries: int = 2) -> dict`
- `create_vacancy(api_key: str, vacancy_json: dict, *, timeout: float | httpx.Timeout = 30.0, max_retries: int = 2) -> dict`
- `delete_vacancy(api_key: str, vacancy_id: str, *, timeout: float | httpx.Timeout = 30.0, max_retries: int = 2) -> dict`

### `OmegaVacancyClient`

- `create_vacancy(vacancy: dict) -> CreateVacancyResult`
- `create_vacancies(vacancies: list[dict]) -> CreateVacancyResult`
- `delete_vacancy(vacancy_id: str) -> DeleteVacancyResult`
- `close() -> None`

Контекстный менеджер:

- `__enter__()` / `__exit__(...)`
