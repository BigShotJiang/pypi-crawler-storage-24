# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RestoreMetaData2ExistReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'source': 'object',
        'target': 'object'
    }

    attribute_map = {
        'source': 'source',
        'target': 'target'
    }

    def __init__(self, source=None, target=None):
        r"""RestoreMetaData2ExistReq

        The model defined in huaweicloud sdk

        :param source: metadata恢复源。
        :type source: object
        :param target: metadata恢复目标。
        :type target: object
        """
        
        

        self._source = None
        self._target = None
        self.discriminator = None

        if source is not None:
            self.source = source
        if target is not None:
            self.target = target

    @property
    def source(self):
        r"""Gets the source of this RestoreMetaData2ExistReq.

        metadata恢复源。

        :return: The source of this RestoreMetaData2ExistReq.
        :rtype: object
        """
        return self._source

    @source.setter
    def source(self, source):
        r"""Sets the source of this RestoreMetaData2ExistReq.

        metadata恢复源。

        :param source: The source of this RestoreMetaData2ExistReq.
        :type source: object
        """
        self._source = source

    @property
    def target(self):
        r"""Gets the target of this RestoreMetaData2ExistReq.

        metadata恢复目标。

        :return: The target of this RestoreMetaData2ExistReq.
        :rtype: object
        """
        return self._target

    @target.setter
    def target(self, target):
        r"""Sets the target of this RestoreMetaData2ExistReq.

        metadata恢复目标。

        :param target: The target of this RestoreMetaData2ExistReq.
        :type target: object
        """
        self._target = target

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RestoreMetaData2ExistReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
