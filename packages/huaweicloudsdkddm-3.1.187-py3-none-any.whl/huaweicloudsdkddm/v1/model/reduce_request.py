# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ReduceRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'node_number': 'int',
        'group_id': 'str'
    }

    attribute_map = {
        'node_number': 'node_number',
        'group_id': 'group_id'
    }

    def __init__(self, node_number=None, group_id=None):
        r"""ReduceRequest

        The model defined in huaweicloud sdk

        :param node_number: 需要缩容的节点数量，最大值为实例节点数减1。
        :type node_number: int
        :param group_id: 组id，指定当前进行节点扩容的组。当实例的组&gt;1时，必填。
        :type group_id: str
        """
        
        

        self._node_number = None
        self._group_id = None
        self.discriminator = None

        self.node_number = node_number
        if group_id is not None:
            self.group_id = group_id

    @property
    def node_number(self):
        r"""Gets the node_number of this ReduceRequest.

        需要缩容的节点数量，最大值为实例节点数减1。

        :return: The node_number of this ReduceRequest.
        :rtype: int
        """
        return self._node_number

    @node_number.setter
    def node_number(self, node_number):
        r"""Sets the node_number of this ReduceRequest.

        需要缩容的节点数量，最大值为实例节点数减1。

        :param node_number: The node_number of this ReduceRequest.
        :type node_number: int
        """
        self._node_number = node_number

    @property
    def group_id(self):
        r"""Gets the group_id of this ReduceRequest.

        组id，指定当前进行节点扩容的组。当实例的组>1时，必填。

        :return: The group_id of this ReduceRequest.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this ReduceRequest.

        组id，指定当前进行节点扩容的组。当实例的组>1时，必填。

        :param group_id: The group_id of this ReduceRequest.
        :type group_id: str
        """
        self._group_id = group_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ReduceRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
