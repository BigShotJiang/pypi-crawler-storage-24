# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class MigrateLogicDbRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'db_name': 'str',
        'body': 'MigrateLogicDbOpenReq'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'db_name': 'db_name',
        'body': 'body'
    }

    def __init__(self, instance_id=None, db_name=None, body=None):
        r"""MigrateLogicDbRequest

        The model defined in huaweicloud sdk

        :param instance_id: DDM实例ID
        :type instance_id: str
        :param db_name: 逻辑库名称
        :type db_name: str
        :param body: Body of the MigrateLogicDbRequest
        :type body: :class:`huaweicloudsdkddm.v1.MigrateLogicDbOpenReq`
        """
        
        

        self._instance_id = None
        self._db_name = None
        self._body = None
        self.discriminator = None

        self.instance_id = instance_id
        self.db_name = db_name
        if body is not None:
            self.body = body

    @property
    def instance_id(self):
        r"""Gets the instance_id of this MigrateLogicDbRequest.

        DDM实例ID

        :return: The instance_id of this MigrateLogicDbRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this MigrateLogicDbRequest.

        DDM实例ID

        :param instance_id: The instance_id of this MigrateLogicDbRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def db_name(self):
        r"""Gets the db_name of this MigrateLogicDbRequest.

        逻辑库名称

        :return: The db_name of this MigrateLogicDbRequest.
        :rtype: str
        """
        return self._db_name

    @db_name.setter
    def db_name(self, db_name):
        r"""Sets the db_name of this MigrateLogicDbRequest.

        逻辑库名称

        :param db_name: The db_name of this MigrateLogicDbRequest.
        :type db_name: str
        """
        self._db_name = db_name

    @property
    def body(self):
        r"""Gets the body of this MigrateLogicDbRequest.

        :return: The body of this MigrateLogicDbRequest.
        :rtype: :class:`huaweicloudsdkddm.v1.MigrateLogicDbOpenReq`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this MigrateLogicDbRequest.

        :param body: The body of this MigrateLogicDbRequest.
        :type body: :class:`huaweicloudsdkddm.v1.MigrateLogicDbOpenReq`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MigrateLogicDbRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
