import sys
import time

import click
from loguru import logger

from panoptes.utils.config import server
from panoptes.utils.config.client import get_config, server_is_running, set_config


@click.group()
@click.option(
    "--verbose/--no-verbose",
    envvar="PANOPTES_DEBUG",
    help="Turn on panoptes logger for utils, default False",
)
@click.option(
    "--host",
    default=None,
    envvar="PANOPTES_CONFIG_HOST",
    help="The config server IP address or host name. First"
    "checks cli argument, then PANOPTES_CONFIG_HOST, then localhost.",
)
@click.option(
    "--port",
    default=None,
    envvar="PANOPTES_CONFIG_PORT",
    help="The config server port. First checks cli argument, then PANOPTES_CONFIG_PORT, then 6563",
)
@click.pass_context
def config_server_cli(context, host="localhost", port=6563, verbose=False):
    """Command line interface for the config server.

    Args:
        context: Click context object.
        host (str): Host address to bind to. Defaults to "localhost".
        port (int): Port number to bind to. Defaults to 6563.
        verbose (bool): Enable verbose logging. Defaults to False.
    """
    context.ensure_object(dict)

    # Distinguish between the address the server binds to and the address clients use
    # to connect. When binding to 0.0.0.0 (all interfaces) or when no host is set,
    # clients should connect via localhost/127.0.0.1 rather than the wildcard address.
    bind_host = host
    client_host = "localhost" if host in (None, "0.0.0.0") else host

    # For backward compatibility, keep the "host" key pointing at the client host so
    # existing commands that read context.obj["host"] will use a connectable address.
    context.obj["bind_host"] = bind_host
    context.obj["client_host"] = client_host
    context.obj["host"] = client_host
    context.obj["port"] = port

    # Setup the logger.
    logger.remove()
    if verbose:
        logger.add(sys.stderr, level="DEBUG")
    else:
        logger.add(sys.stderr, level="INFO")


@click.command("run")
@click.option(
    "--config-file",
    default=None,
    envvar="PANOPTES_CONFIG_FILE",
    help="The yaml config file to load.",
)
@click.option(
    "--load-local/--no-load-local",
    default=True,
    help="Use the local config files when loading, default True.",
)
@click.option(
    "--save-local/--no-save-local",
    default=True,
    help="If the set values should be saved to the local file, default True.",
)
@click.option("--heartbeat", default=2, help="Heartbeat interval, default 2 seconds.")
@click.option(
    "--startup-timeout",
    default=30,
    help="Seconds to wait for the server to become ready before giving up, default 30.",
)
@click.pass_context
def run(context, config_file=None, save_local=True, load_local=True, heartbeat=2, startup_timeout=30):
    """Runs the config server with command line options.

    This function is installed as an entry_point for the module, accessible
     at `panoptes-config-server`.
    """
    # Prefer the explicitly stored bind/client hosts, falling back to "host" for
    # compatibility with older contexts.
    bind_host = context.obj.get("bind_host", context.obj.get("host"))
    client_host = context.obj.get("client_host", bind_host)
    port = context.obj.get("port")

    try:
        server_process = server.config_server(
            config_file,
            host=bind_host,
            port=port,
            load_local=load_local,
            save_local=save_local,
            auto_start=False,
        )
    except Exception as e:
        logger.error(f"Unable to start config server: {e!r}")
        return

    try:
        print("Starting config server. Ctrl-c to stop")
        server_process.start()
        print(
            f"Config server started on  server_process.pid={server_process.pid!r}. "
            f'Set "config_server.running=False" or Ctrl-c to stop'
        )

        # Wait for the server to become reachable before entering the monitor loop.
        # uvicorn takes a moment to bind its socket after the process is forked.
        logger.info(f"Waiting for config server to be ready on {client_host}:{port}")
        startup_elapsed = 0.0
        startup_interval = 0.5
        while startup_elapsed < startup_timeout:
            if server_is_running(host=client_host, port=port):
                break
            time.sleep(startup_interval)
            startup_elapsed += startup_interval
        else:
            logger.error(f"Config server did not become ready within {startup_timeout}s")
            server_process.terminate()
            server_process.join(5)
            return

        logger.info("Config server is ready")

        # Loop until the server signals it is no longer running.
        while server_is_running(host=client_host, port=port):
            time.sleep(heartbeat)

        server_process.terminate()
        server_process.join(30)
    except KeyboardInterrupt:
        logger.info(f"Config server interrupted, shutting down {server_process.pid}")
        server_process.terminate()
    except Exception as e:  # pragma: no cover
        logger.error(f"Unable to start config server {e!r}")


@click.command("stop")
@click.pass_context
def stop(context):
    """Stops the config server by setting a flag in the server itself."""
    host = context.obj.get("host")
    port = context.obj.get("port")
    logger.info(f"Shutting down config server on {host}:{port}")
    set_config("config_server.running", False, host=host, port=port)


@click.command("get")
@click.argument("key", nargs=-1)
@click.option("--default", help="The default to return if not key is found, default None")
@click.option(
    "--parse/--no-parse",
    default=True,
    help="If results should be parsed into object, default True.",
)
@click.pass_context
def config_getter(context, key, parse=True, default=None):
    """Get an item from the config server by key name, using dotted notation (e.g. 'location.elevation')

    If no key is given, returns the entire config.
    """
    host = context.obj.get("host")
    port = context.obj.get("port")
    try:
        # The nargs=-1 makes this a tuple so we get first entry.
        key = key[0]
    except IndexError:
        key = None
    logger.debug(f"Getting config  key={key!r}")
    try:
        config_entry = get_config(key=key, host=host, port=port, parse=parse, default=default)
    except Exception as e:
        logger.error(f"Error while trying to get config: {e!r}")
        click.secho(f"Error while trying to get config: {e!r}", fg="red")
    else:
        logger.debug(f"Config server response:  config_entry={config_entry!r}")
        click.echo(config_entry)


@click.command("set")
@click.argument("key")
@click.argument("new_value")
@click.option("--parse/--no-parse", default=True, help="If results should be parsed into object.")
@click.pass_context
def config_setter(context, key, new_value, parse=True):
    """Set an item in the config server."""
    host = context.obj.get("host")
    port = context.obj.get("port")

    logger.debug(f"Setting config key={key!r}  new_value={new_value!r} on {host}:{port}")
    config_entry = set_config(key, new_value, host=host, port=port, parse=parse)
    click.echo(config_entry)


config_server_cli.add_command(run)
config_server_cli.add_command(stop)
config_server_cli.add_command(config_setter)
config_server_cli.add_command(config_getter)
