import sqlite3
from pathlib import Path

from bank_statement_parser.data.create_project_db_views import create_views

# DDL for the exchange_rates reference table.  Uses a composite primary key
# (id_date, currency) so it cannot be created via the generic create_table()
# helper (which only supports single-column PKs).
_DDL_EXCHANGE_RATES = """
CREATE TABLE exchange_rates (
    "id_date"   TEXT NOT NULL,
    "currency"  TEXT NOT NULL,
    "rate_USD"  REAL NOT NULL,
    PRIMARY KEY (id_date, currency)
);
"""

SCHEMAS = {
    "checks_and_balances": {
        "ID_CAB": "TEXT",
        "ID_BATCHLINE": "TEXT",
        "ID_BATCH": "TEXT",
        "HAS_TRANSACTIONS": "INTEGER",
        "STD_OPENING_BALANCE_HEADS": "REAL",
        "STD_PAYMENTS_IN_HEADS": "REAL",
        "STD_PAYMENTS_OUT_HEADS": "REAL",
        "STD_MOVEMENT_HEADS": "REAL",
        "STD_CLOSING_BALANCE_HEADS": "REAL",
        "STD_OPENING_BALANCE_LINES": "REAL",
        "STD_PAYMENTS_IN_LINES": "REAL",
        "STD_PAYMENTS_OUT_LINES": "REAL",
        "STD_MOVEMENT_LINES": "REAL",
        "STD_CLOSING_BALANCE_LINES": "REAL",
        "CHECK_PAYMENTS_IN": "INTEGER",
        "CHECK_PAYMENTS_OUT": "INTEGER",
        "CHECK_MOVEMENT": "INTEGER",
        "CHECK_CLOSING": "INTEGER",
    },
    "statement_heads": {
        "ID_STATEMENT": "TEXT",
        "ID_BATCHLINE": "TEXT",
        "ID_ACCOUNT": "TEXT",
        "STD_COMPANY": "TEXT",
        "STD_STATEMENT_TYPE": "TEXT",
        "STD_ACCOUNT": "TEXT",
        "STD_CURRENCY": "TEXT",
        "STD_SORTCODE": "TEXT",
        "STD_ACCOUNT_NUMBER": "TEXT",
        "STD_ACCOUNT_HOLDER": "TEXT",
        "STD_STATEMENT_DATE": "TEXT",
        "STD_OPENING_BALANCE": "REAL",
        "STD_PAYMENTS_IN": "REAL",
        "STD_PAYMENTS_OUT": "REAL",
        "STD_CLOSING_BALANCE": "REAL",
    },
    "statement_lines": {
        "ID_TRANSACTION": "TEXT",
        "ID_STATEMENT": "TEXT",
        "STD_PAGE_NUMBER": "INTEGER",
        "STD_TRANSACTION_DATE": "TEXT",
        "STD_TRANSACTION_NUMBER": "INTEGER",
        "STD_CD": "TEXT",
        "STD_TRANSACTION_TYPE": "TEXT",
        "STD_TRANSACTION_TYPE_CD": "TEXT",
        "STD_TRANSACTION_DESC": "TEXT",
        "STD_OPENING_BALANCE": "REAL",
        "STD_PAYMENTS_IN": "REAL",
        "STD_PAYMENTS_OUT": "REAL",
        "STD_CLOSING_BALANCE": "REAL",
    },
    "batch_heads": {
        "ID_BATCH": "TEXT",
        "ID_SESSION": "TEXT",
        "ID_USER": "TEXT",
        "STD_PATH": "TEXT",
        "STD_COMPANY": "TEXT",
        "STD_ACCOUNT": "TEXT",
        "STD_PDF_COUNT": "INTEGER",
        "STD_ERROR_COUNT": "INTEGER",
        "STD_REVIEW_COUNT": "INTEGER",
        "STD_DURATION_SECS": "REAL",
        "STD_UPDATETIME": "TEXT",
    },
    "batch_lines": {
        "ID_BATCH": "TEXT",
        "ID_BATCHLINE": "TEXT",
        "ID_STATEMENT": "TEXT",
        "STD_BATCH_LINE": "INTEGER",
        "STD_FILENAME": "TEXT",
        "STD_ACCOUNT": "TEXT",
        "STD_DURATION_SECS": "REAL",
        "STD_UPDATETIME": "TEXT",
        "STD_SUCCESS": "INTEGER",
        "STD_ERROR_MESSAGE": "TEXT",
        "ERROR_CAB": "INTEGER",
        "ERROR_CONFIG": "INTEGER",
        "ERROR_DATA": "INTEGER",
    },
}

FOREIGN_KEYS = {
    "checks_and_balances": [
        "FOREIGN KEY (ID_BATCHLINE) REFERENCES batch_lines(ID_BATCHLINE) ON UPDATE CASCADE ON DELETE CASCADE",
        "FOREIGN KEY (ID_BATCH) REFERENCES batch_heads(ID_BATCH) ON UPDATE CASCADE ON DELETE CASCADE",
    ],
    "statement_heads": [
        "FOREIGN KEY (ID_BATCHLINE) REFERENCES batch_lines(ID_BATCHLINE) ON UPDATE CASCADE ON DELETE CASCADE",
    ],
    "statement_lines": [
        "FOREIGN KEY (ID_STATEMENT) REFERENCES statement_heads(ID_STATEMENT) ON UPDATE CASCADE ON DELETE CASCADE",
    ],
    "batch_lines": [
        "FOREIGN KEY (ID_BATCH) REFERENCES batch_heads(ID_BATCH) ON UPDATE CASCADE ON DELETE CASCADE",
    ],
}


PRIMARY_KEYS = {
    "checks_and_balances": "ID_CAB",
    "statement_heads": "ID_STATEMENT",
    "statement_lines": "ID_TRANSACTION",
    "batch_heads": "ID_BATCH",
    "batch_lines": "ID_BATCHLINE",
}


def create_table(conn, table_name, schema: dict, with_fk: bool = False):
    col_defs = []
    for col_name, col_type in schema.items():
        if table_name in PRIMARY_KEYS and PRIMARY_KEYS[table_name] == col_name:
            col_defs.append(f'"{col_name}" {col_type} NOT NULL PRIMARY KEY')
        else:
            col_defs.append(f'"{col_name}" {col_type}')

    if with_fk and table_name in FOREIGN_KEYS:
        col_defs.extend(FOREIGN_KEYS[table_name])

    create_sql = f"CREATE TABLE {table_name} (\n    " + ",\n    ".join(col_defs) + "\n);"
    print(f"Creating table: {table_name}")
    print(create_sql)
    print()
    conn.execute(create_sql)


def main(db_path: Path, with_fk: bool = False) -> None:
    """Create (or recreate) the raw SQLite database with all tables and indexes.

    Drops any existing database file at *db_path* and creates a fresh one with
    all raw source tables (``batch_heads``, ``batch_lines``, ``statement_heads``,
    ``statement_lines``, ``checks_and_balances``) plus their indexes and views.

    Args:
        db_path: Filesystem path for the SQLite database file.  If the file
            already exists it is deleted before the new database is created.
        with_fk: When ``True`` the tables are created with ``FOREIGN KEY``
            constraints (useful for strict-integrity environments).  Defaults
            to ``False``.
    """
    if db_path.exists():
        db_path.unlink()

    conn = sqlite3.connect(db_path)
    if with_fk:
        conn.execute("PRAGMA foreign_keys = ON;")

    table_order = ["batch_heads", "batch_lines", "statement_heads", "checks_and_balances", "statement_lines"]

    for table_name in table_order:
        create_table(conn, table_name, SCHEMAS[table_name], with_fk)

    # exchange_rates has a composite PK — create it separately.
    print("Creating table: exchange_rates")
    print(_DDL_EXCHANGE_RATES)
    conn.execute(_DDL_EXCHANGE_RATES)

    conn.commit()
    conn.close()
    print(f"Database created: {db_path}")

    create_views(db_path)

    create_indexes(db_path)


def create_indexes(db_path: Path):
    conn = sqlite3.connect(db_path)

    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_statement_heads_id_account ON statement_heads(ID_ACCOUNT)",
        "CREATE INDEX IF NOT EXISTS idx_statement_heads_id_batchline ON statement_heads(ID_BATCHLINE)",
        "CREATE INDEX IF NOT EXISTS idx_statement_lines_id_statement ON statement_lines(ID_STATEMENT)",
        "CREATE INDEX IF NOT EXISTS idx_statement_lines_date ON statement_lines(STD_TRANSACTION_DATE)",
        "CREATE INDEX IF NOT EXISTS idx_statement_lines_account_date ON statement_lines(ID_STATEMENT, STD_TRANSACTION_DATE, STD_TRANSACTION_NUMBER)",
        "CREATE INDEX IF NOT EXISTS idx_batch_lines_id_batch ON batch_lines(ID_BATCH)",
        "CREATE INDEX IF NOT EXISTS idx_batch_lines_id_statement ON batch_lines(ID_STATEMENT)",
        "CREATE INDEX IF NOT EXISTS idx_sh_stmt_acct ON statement_heads(ID_STATEMENT, ID_ACCOUNT)",
        "CREATE INDEX IF NOT EXISTS idx_batch_lines_stmt_batch ON batch_lines(ID_STATEMENT, ID_BATCH)",
        "CREATE INDEX IF NOT EXISTS idx_cab_id_batchline ON checks_and_balances(ID_BATCHLINE)",
        "CREATE INDEX IF NOT EXISTS idx_exchange_rates_currency ON exchange_rates(currency)",
        "CREATE INDEX IF NOT EXISTS idx_exchange_rates_id_date ON exchange_rates(id_date)",
    ]

    for idx_sql in indexes:
        print(f"Creating index: {idx_sql}")
        conn.execute(idx_sql)

    conn.commit()
    conn.close()
    print("Indexes created successfully")


if __name__ == "__main__":
    main(db_path=Path(__file__).parent.parent.joinpath("project", "database", "project.db"), with_fk=True)
