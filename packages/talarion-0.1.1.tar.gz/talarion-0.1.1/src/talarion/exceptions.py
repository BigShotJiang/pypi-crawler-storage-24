"""Talarion SDK exceptions.

Each exception maps to an HTTP status code returned by the API.
"""

from __future__ import annotations


class TalarionError(Exception):
    """Base exception for all Talarion SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        detail: str | None = None,
    ):
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class AuthenticationError(TalarionError):
    """Invalid or missing API key (HTTP 401)."""


class ValidationError(TalarionError):
    """Invalid request parameters (HTTP 400)."""


class NotFoundError(TalarionError):
    """Resource not found (HTTP 404)."""


class ConflictError(TalarionError):
    """Conflict — duplicate order, already relayed, etc. (HTTP 409)."""


class QuoteProcessingError(TalarionError):
    """Quote is still being generated (HTTP 202). Retry after a delay."""


class ServerError(TalarionError):
    """Server-side error (HTTP 5xx)."""
