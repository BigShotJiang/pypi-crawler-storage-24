"""Talarion SDK data models.

All response types are frozen dataclasses — immutable and hashable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from uuid import UUID


# -- Instruments ---------------------------------------------------------------

@dataclass(frozen=True)
class Instrument:
    """A prediction market instrument."""

    instrument_id: str
    title: str
    rules: str
    start_time: datetime
    resolution_time: datetime


@dataclass(frozen=True)
class Settlement:
    """Settlement result for a resolved instrument."""

    instrument_id: str
    settlement_value: float  # 0–1, where 1 = YES resolves true


# -- Quotes --------------------------------------------------------------------

@dataclass(frozen=True)
class Quote:
    """A price quote for an instrument."""

    instrument_id: str
    user_id: str | None
    amount: float
    price: float
    buy_yes: bool
    expiry_utc: datetime


# -- Operations (EIP-712 signing) ---------------------------------------------

@dataclass(frozen=True)
class SafeOperation:
    """A single EIP-712 operation to be signed."""

    operation_id: UUID
    description: str
    eip_712_tx: dict[str, Any]


@dataclass(frozen=True)
class OperationSequence:
    """An ordered sequence of operations to sign and relay."""

    sequence_id: UUID
    operations: list[SafeOperation]


@dataclass(frozen=True)
class OperationResult:
    """Result of a single relayed operation."""

    operation: SafeOperation
    successful: bool
    transaction_hash: str | None = None


# -- Order results -------------------------------------------------------------

@dataclass(frozen=True)
class SubmitResult:
    """Result of submitting a trade order.

    Contains the trade parameters and an operation sequence
    with EIP-712 typed data that must be signed and relayed.
    """

    trade_id: str
    instrument_bytes_hex: str
    size_int: int
    price_int: int
    buyer_checksum: str
    seller_checksum: str
    salt_hex: str
    operation_sequence: OperationSequence | None = None


@dataclass(frozen=True)
class CancelResult:
    """Result of requesting a trade cancellation.

    Contains an operation sequence to sign and relay (None for EOA callers).
    """

    trade_id: str
    operation_sequence: OperationSequence | None = None


@dataclass(frozen=True)
class RelayResult:
    """Result of relaying signed operations on-chain."""

    successful: bool
    results: list[OperationResult]


# -- Trades --------------------------------------------------------------------

@dataclass(frozen=True)
class Trade:
    """A trade record."""

    instrument_id: str
    user_id: str
    amount: float
    price: float
    status: str = "pending"


# -- Users ---------------------------------------------------------------------

@dataclass(frozen=True)
class UserPnl:
    """A user's realized profit and loss."""

    user_id: str
    total_realized_pnl: float
