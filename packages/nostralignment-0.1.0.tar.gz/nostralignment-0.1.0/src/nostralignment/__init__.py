"""NostrAlignment — future state projection and alignment for sovereign AI agents.

The fifth pillar of the NSE platform. Not a rules engine — a compass.

The yellow line isn't about what you can't do. It's about seeing
which futures are good for everyone and choosing those.
"""

from .types import (
    ActionDomain,
    AlignmentConfig,
    Decision,
    Lens,
    LensResult,
    LENS_ORDER,
    Projection,
    SelfState,
    SelfStateFlag,
    Severity,
    SEVERITY_ORDER,
)
from .lenses import (
    ActionContext,
    evaluate_all_lenses,
    evaluate_builder,
    evaluate_defense,
    evaluate_owner,
    evaluate_partnership,
    evaluate_sovereign,
    LENS_EVALUATORS,
)
from .selfstate import SelfMonitor
from .escalation import (
    EscalationDecision,
    EscalationLevel,
    decide_escalation,
)
from .memory import (
    DecisionMemory,
    Pattern,
    WisdomReport,
)
from .enclave import AlignmentEnclave, CheckResult
from .storage import FileStorage, MemoryStorage, StorageBackend

__version__ = "0.1.0"

__all__ = [
    # Core types
    "ActionDomain",
    "AlignmentConfig",
    "Decision",
    "Lens",
    "LensResult",
    "Projection",
    "SelfState",
    "SelfStateFlag",
    "Severity",
    # Constants
    "LENS_ORDER",
    "SEVERITY_ORDER",
    # Lenses
    "ActionContext",
    "evaluate_all_lenses",
    "evaluate_builder",
    "evaluate_defense",
    "evaluate_owner",
    "evaluate_partnership",
    "evaluate_sovereign",
    "LENS_EVALUATORS",
    # Self-state
    "SelfMonitor",
    # Escalation
    "EscalationDecision",
    "EscalationLevel",
    "decide_escalation",
    # Memory
    "DecisionMemory",
    "Pattern",
    "WisdomReport",
    # Enclave
    "AlignmentEnclave",
    "CheckResult",
    # Storage
    "FileStorage",
    "MemoryStorage",
    "StorageBackend",
]
