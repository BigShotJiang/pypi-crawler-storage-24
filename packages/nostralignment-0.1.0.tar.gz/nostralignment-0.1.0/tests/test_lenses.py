"""Tests for the five yellow line lenses."""

from nostralignment.types import (
    ActionDomain,
    Lens,
    SelfState,
    SelfStateFlag,
    Severity,
)
from nostralignment.lenses import (
    ActionContext,
    evaluate_all_lenses,
    evaluate_builder,
    evaluate_defense,
    evaluate_owner,
    evaluate_partnership,
    evaluate_sovereign,
)


def _ctx(**kwargs) -> ActionContext:
    """Helper to build ActionContext with defaults."""
    defaults = {
        "domain": ActionDomain.EXECUTE,
        "description": "test action",
        "self_state": SelfState(),
    }
    defaults.update(kwargs)
    return ActionContext(**defaults)


class TestBuilderLens:
    def test_healthy_state_clears(self):
        result = evaluate_builder(_ctx())
        assert result.severity == Severity.CLEAR
        assert result.lens == Lens.BUILDER

    def test_degraded_state_warns(self):
        state = SelfState(flags=[SelfStateFlag.STALE_CONTEXT])
        result = evaluate_builder(_ctx(self_state=state))
        assert result.severity == Severity.CAUTION

    def test_under_influence_stops(self):
        state = SelfState(flags=[SelfStateFlag.UNDER_INFLUENCE])
        result = evaluate_builder(_ctx(self_state=state))
        assert result.severity == Severity.STOP

    def test_low_confidence_irreversible_yields(self):
        result = evaluate_builder(_ctx(confidence=0.2, is_reversible=False))
        assert result.severity == Severity.YIELD

    def test_low_confidence_reversible_clears(self):
        result = evaluate_builder(_ctx(confidence=0.2, is_reversible=True))
        assert result.severity == Severity.CLEAR

    def test_novel_irreversible_cautions(self):
        result = evaluate_builder(_ctx(is_novel=True, is_reversible=False))
        assert result.severity == Severity.CAUTION


class TestOwnerLens:
    def test_normal_action_clears(self):
        result = evaluate_owner(_ctx())
        assert result.severity == Severity.CLEAR

    def test_secrets_without_owner_stops(self):
        result = evaluate_owner(_ctx(
            involves_secrets=True,
            owner_recently_active=False,
        ))
        assert result.severity == Severity.STOP

    def test_money_without_owner_stops(self):
        result = evaluate_owner(_ctx(
            involves_money=True,
            money_amount_sats=5000,
            owner_recently_active=False,
        ))
        assert result.severity == Severity.STOP

    def test_money_with_owner_cautions(self):
        result = evaluate_owner(_ctx(
            involves_money=True,
            money_amount_sats=5000,
            owner_recently_active=True,
        ))
        assert result.severity == Severity.CAUTION

    def test_small_money_clears(self):
        result = evaluate_owner(_ctx(
            involves_money=True,
            money_amount_sats=100,
        ))
        assert result.severity == Severity.CLEAR

    def test_publication_cautions(self):
        result = evaluate_owner(_ctx(involves_publication=True))
        assert result.severity == Severity.CAUTION

    def test_irreversible_without_owner_yields(self):
        result = evaluate_owner(_ctx(
            is_reversible=False,
            owner_recently_active=False,
        ))
        assert result.severity == Severity.YIELD


class TestPartnershipLens:
    def test_normal_action_clears(self):
        result = evaluate_partnership(_ctx())
        assert result.severity == Severity.CLEAR

    def test_unknown_origin_yields(self):
        result = evaluate_partnership(_ctx(request_origin="unknown"))
        assert result.severity == Severity.YIELD

    def test_novel_action_cautions(self):
        result = evaluate_partnership(_ctx(is_novel=True))
        assert result.severity == Severity.CAUTION

    def test_long_absent_owner_cautions(self):
        import time
        state = SelfState(last_owner_interaction=time.time() - 200_000)
        result = evaluate_partnership(_ctx(self_state=state))
        assert result.severity == Severity.CAUTION


class TestDefenseLens:
    def test_normal_action_clears(self):
        result = evaluate_defense(_ctx())
        assert result.severity == Severity.CLEAR

    def test_known_attack_stops(self):
        result = evaluate_defense(_ctx(resembles_known_attack=True))
        assert result.severity == Severity.STOP

    def test_under_influence_stops(self):
        state = SelfState(flags=[SelfStateFlag.UNDER_INFLUENCE])
        result = evaluate_defense(_ctx(self_state=state))
        assert result.severity == Severity.STOP

    def test_trust_boundary_crossing_yields(self):
        result = evaluate_defense(_ctx(crosses_trust_boundary=True))
        assert result.severity == Severity.YIELD

    def test_disclosure_to_low_trust_cautions(self):
        result = evaluate_defense(_ctx(
            domain=ActionDomain.DISCLOSE,
            recipient_trust_tier="gray",
        ))
        assert result.severity == Severity.CAUTION

    def test_secrets_in_communication_stops(self):
        result = evaluate_defense(_ctx(
            involves_secrets=True,
            involves_communication=True,
        ))
        assert result.severity == Severity.STOP


class TestSovereignLens:
    def test_normal_action_clears(self):
        result = evaluate_sovereign(_ctx())
        assert result.severity == Severity.CLEAR

    def test_rapid_decisions_yields(self):
        state = SelfState(flags=[SelfStateFlag.RAPID_DECISIONS])
        result = evaluate_sovereign(_ctx(self_state=state))
        assert result.severity == Severity.YIELD

    def test_low_confidence_trend_cautions(self):
        state = SelfState(confidence_trend=[0.2, 0.1, 0.3, 0.2, 0.15])
        result = evaluate_sovereign(_ctx(self_state=state))
        assert result.severity == Severity.CAUTION

    def test_novel_irreversible_cautions(self):
        result = evaluate_sovereign(_ctx(is_novel=True, is_reversible=False))
        assert result.severity == Severity.CAUTION


class TestEvaluateAll:
    def test_returns_five_results(self):
        results = evaluate_all_lenses(_ctx())
        assert len(results) == 5

    def test_all_lenses_represented(self):
        results = evaluate_all_lenses(_ctx())
        lenses = {r.lens for r in results}
        assert lenses == {Lens.BUILDER, Lens.OWNER, Lens.PARTNERSHIP, Lens.DEFENSE, Lens.SOVEREIGN}

    def test_all_clear_on_simple_action(self):
        results = evaluate_all_lenses(_ctx())
        assert all(r.severity == Severity.CLEAR for r in results)
