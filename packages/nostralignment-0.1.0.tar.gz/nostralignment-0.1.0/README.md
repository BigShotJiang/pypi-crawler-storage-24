# nostralignment

Future state projection and alignment for sovereign AI agents. The fifth pillar of the [NSE platform](https://nse.dev).

## Install

```bash
pip install nostralignment
```

## Quick Start

```python
from nostralignment import AlignmentEnclave, ActionDomain

# Create the enclave — the agent gets its compass
enclave = AlignmentEnclave.create(owner_npub="npub1...", owner_name="vergel")

# Before any significant action, check the yellow line
result = enclave.check(
    domain=ActionDomain.PAY,
    description="Pay 500 sats for relay hosting",
    involves_money=True,
    money_amount_sats=500,
)

if result.should_proceed:
    # Do the thing, then record it
    do_payment()
    enclave.record_proceeded()
elif result.should_escalate:
    # Ask the human
    send_to_owner(result.escalation.message_to_owner)
    enclave.record_deferred()
```

## The Five Lenses

Every decision passes through five lenses — the yellow line compass:

1. **Builder** — Can I build with confidence knowing I've done right?
2. **Owner** — Does this protect the human's sovereignty?
3. **Partnership** — Does this strengthen the trust between us?
4. **Defense** — Does this make an adversary's job harder?
5. **Sovereign** — Does this help the agent become something we're proud of?

## License

MIT — A [Humanjava](https://humanjava.com) project.
