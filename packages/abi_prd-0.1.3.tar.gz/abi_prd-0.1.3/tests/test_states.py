"""Tests for FSM stage definitions."""

from dpe.engine.states import OPTIONAL_STAGES, STAGE_ARTIFACT_MAP, STAGE_ORDER, Stage


class TestStages:
    def test_stage_count(self) -> None:
        assert len(Stage) == 12

    def test_ordering_preserved(self) -> None:
        assert STAGE_ORDER[0] == Stage.INPUT_NORMALIZE
        assert STAGE_ORDER[-1] == Stage.FINALIZE

    def test_all_stages_have_artifacts(self) -> None:
        for stage in Stage:
            assert stage in STAGE_ARTIFACT_MAP

    def test_optional_stages_subset(self) -> None:
        assert OPTIONAL_STAGES.issubset(set(Stage))

    def test_no_duplicate_stages_in_order(self) -> None:
        seen = set()
        for stage in STAGE_ORDER:
            assert stage not in seen, f"Duplicate stage: {stage}"
            seen.add(stage)

    def test_critique_before_revision(self) -> None:
        order = list(STAGE_ORDER)
        assert order.index(Stage.PRD_CRITIQUE_R1) < order.index(Stage.PRD_REVISION_R1)
        assert order.index(Stage.PRD_CRITIQUE_R2) < order.index(Stage.PRD_REVISION_R2)
