# Quality Gates

## Gate 1: Static Analysis

- `ruff check src/ tests/` — zero violations.
- `mypy src/` — zero errors in strict mode.

## Gate 2: Unit Tests

- `pytest tests/ -v --tb=short` — all pass.
- Coverage target: 80% on `engine/` and `models/`.

## Gate 3: Simulation Mode

- `dialectic run --idea "test" --simulation` — completes within budget.
- Produces valid `run_manifest.json` with all required fields.
- All artifact files present and hashed.

## Gate 4: Budget Enforcement

- No code path calls a model adapter without `BudgetController.pre_call_check()`.
- Verified by unit tests that mock adapters and assert budget checks.

## Gate 5: Determinism

- Two identical simulation runs with the same config produce identical `config_hash` values.
- FSM stage ordering matches `STAGE_ORDER` exactly.

## Pre-Commit Checks

All gates 1-2 run on every commit via pre-commit hooks.
