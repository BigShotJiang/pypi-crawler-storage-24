"""Model adapter request / result schemas."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ModelRequest(BaseModel):
    """Payload sent to any model adapter."""

    prompt: str
    role: str
    stage: str
    context: dict[str, Any] = Field(default_factory=dict)


class ModelResult(BaseModel):
    """Structured response from a model adapter."""

    text: str
    adapter_name: str
    role: str
    throttle_detected: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)
