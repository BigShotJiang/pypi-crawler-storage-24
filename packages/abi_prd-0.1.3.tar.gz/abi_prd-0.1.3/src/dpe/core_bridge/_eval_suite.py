"""Build a canonical EvalSuite from DPE run state."""

from __future__ import annotations

from dpe.engine.states import Stage
from dpe.models.manifest import RunManifest

from ._run_id import to_core_run_id

# Canonical artifact files that should be validated against core schemas.
_SCHEMA_VALIDATION_TARGETS = [
    ("plan_graph.json", "plan_graph.schema.json"),
    ("run_manifest.core.json", "run_manifest.schema.json"),
    ("eval_suite.json", "eval_suite.schema.json"),
]

# PRD rubric checks — descriptive cases for downstream eval execution.
_PRD_RUBRIC_CASES = [
    ("rubric-completeness", "PRD contains all required sections"),
    ("rubric-goals", "PRD states clear project goals"),
    ("rubric-non-goals", "PRD explicitly lists non-goals or out-of-scope items"),
    ("rubric-user-stories", "PRD includes user stories or use cases"),
    ("rubric-technical-reqs", "PRD specifies technical requirements"),
    ("rubric-success-metrics", "PRD defines measurable success metrics"),
    ("rubric-traceability", "PRD traces back to the original idea/input"),
    ("rubric-acceptance-criteria", "PRD includes acceptance criteria in Given/When/Then format"),
]

# The final PRD artifact filename (FINALIZE stage output).
_FINAL_PRD_ARTIFACT = "80_prd_final.md"


def build_eval_suite(
    manifest: RunManifest,
    stage_outputs: dict[Stage, str] | None = None,
) -> dict:
    """Build a canonical eval_suite dict from a DPE RunManifest.

    Returns a dict conforming to eval-suite/1.0 schema.
    """
    core_run_id = to_core_run_id(manifest.run_id)
    cases: list[dict] = []

    # --- Sub-suite 1: Schema validation ---
    for artifact_file, schema_file in _SCHEMA_VALIDATION_TARGETS:
        cases.append({
            "case_id": f"schema-{artifact_file.replace('.json', '')}",
            "description": f"Validate {artifact_file} against {schema_file}",
            "input": {"artifact": artifact_file, "schema": schema_file},
            "expected": {"valid": True},
            "comparison": "structural",
            "tags": ["schema-validation"],
        })

    # --- Sub-suite 2: Golden comparison suggestions ---
    has_final_prd = any(
        a.filename == _FINAL_PRD_ARTIFACT for a in manifest.artifacts
    )
    if has_final_prd:
        cases.append({
            "case_id": "golden-prd-final",
            "description": "Compare final PRD against golden baseline (if available)",
            "input": {"artifact": _FINAL_PRD_ARTIFACT},
            "expected": {"exists": True, "non_empty": True},
            "comparison": "structural",
            "tags": ["golden", "prd"],
        })

    cases.append({
        "case_id": "golden-plan-graph",
        "description": "Compare plan_graph.json against golden baseline",
        "input": {"artifact": "plan_graph.json"},
        "expected": {"valid": True},
        "comparison": "structural",
        "tags": ["golden", "plan-graph"],
    })

    cases.append({
        "case_id": "golden-run-manifest-core",
        "description": "Compare run_manifest.core.json against golden baseline",
        "input": {"artifact": "run_manifest.core.json"},
        "expected": {"valid": True},
        "comparison": "structural",
        "tags": ["golden", "run-manifest"],
    })

    # --- Sub-suite 3: PRD rubric ---
    final_prd_file = _FINAL_PRD_ARTIFACT if has_final_prd else None
    for case_id, description in _PRD_RUBRIC_CASES:
        cases.append({
            "case_id": case_id,
            "description": description,
            "input": {"artifact": final_prd_file or "N/A", "check": case_id},
            "expected": {"satisfied": True},
            "comparison": "structural",
            "tags": ["prd-rubric"],
        })

    return {
        "schema_version": "eval-suite/1.0",
        "suite_id": f"dpe-{core_run_id}-eval",
        "description": "DPE evaluation suite: schema validation, golden comparisons, PRD rubric",
        "tags": ["dpe", "prd-generation"],
        "cases": cases,
    }
