"""Core bridge — emit abi-control-core canonical artifacts from DPE runs."""

from ._emitter import EmissionResult, emit_core_artifacts
from ._errors import CoreBridgeError, CoreBridgeValidationError

__all__ = [
    "CoreBridgeError",
    "CoreBridgeValidationError",
    "EmissionResult",
    "emit_core_artifacts",
]
