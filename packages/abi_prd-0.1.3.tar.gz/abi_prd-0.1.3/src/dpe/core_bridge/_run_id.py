"""Run ID bridge — deterministic mapping from DPE 12-char to core 8-char."""

from __future__ import annotations

import re

_DPE_RUN_ID_RE = re.compile(r"^[0-9a-f]{12}$")
_CORE_RUN_ID_RE = re.compile(r"^[0-9a-f]{8}$")


def to_core_run_id(dpe_run_id: str) -> str:
    """Truncate a 12-char DPE run_id to 8-char core run_id.

    Takes the first 8 characters. Deterministic and collision-safe
    for expected run volumes.
    """
    if not _DPE_RUN_ID_RE.match(dpe_run_id):
        raise ValueError(
            f"Invalid DPE run_id: {dpe_run_id!r} "
            f"(expected 12 lowercase hex chars)"
        )
    return dpe_run_id[:8]
