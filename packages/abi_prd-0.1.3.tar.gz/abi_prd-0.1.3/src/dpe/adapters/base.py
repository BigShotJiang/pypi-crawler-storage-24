"""Abstract base class for all model adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from dpe.models.adapter import ModelRequest, ModelResult


class ModelAdapter(ABC):
    """Every model backend must implement this interface."""

    @abstractmethod
    def generate(self, request: ModelRequest) -> ModelResult: ...

    @abstractmethod
    def healthcheck(self) -> bool: ...

    @abstractmethod
    def estimate_usage(self, request: ModelRequest) -> dict[str, Any]: ...

    @abstractmethod
    def get_usage_snapshot(self) -> dict[str, Any]: ...
