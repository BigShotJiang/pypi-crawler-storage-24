"""Simulation adapter — deterministic stubs, no LLM calls."""

from __future__ import annotations

from typing import Any

from dpe.adapters.base import ModelAdapter
from dpe.models.adapter import ModelRequest, ModelResult


class SimulationAdapter(ModelAdapter):
    """Returns deterministic stub outputs. Used for testing and CI."""

    def generate(self, request: ModelRequest) -> ModelResult:
        # For PRD-related stages, include acceptance criteria section
        if request.stage in ("PRD_V1", "PRD_REVISION_R1", "PRD_REVISION_R2", "FINALIZE"):
            text = (
                f"[SIMULATION] Stage: {request.stage}\n"
                f"Role: {request.role}\n"
                f"Prompt length: {len(request.prompt)} chars\n\n"
                f"This is a simulated PRD response for stage '{request.stage}'. "
                f"No LLM call was made.\n\n"
                f"## Acceptance Criteria\n\n"
                f"AC-001: Simulated feature works correctly\n"
                f"Given: A simulated environment\n"
                f"When: The feature is tested\n"
                f"Then: It produces the expected output\n"
            )
        else:
            text = (
                f"[SIMULATION] Stage: {request.stage}\n"
                f"Role: {request.role}\n"
                f"Prompt length: {len(request.prompt)} chars\n\n"
                f"This is a simulated response for stage '{request.stage}'. "
                f"No LLM call was made.\n"
            )
        return ModelResult(
            text=text,
            adapter_name="simulation",
            role=request.role,
            throttle_detected=False,
            metadata={"simulation": True},
        )

    def healthcheck(self) -> bool:
        return True

    def estimate_usage(self, request: ModelRequest) -> dict[str, Any]:
        return {"estimated_tokens": 0, "cost": 0.0}

    def get_usage_snapshot(self) -> dict[str, Any]:
        return {"total_calls": 0, "simulation": True}
