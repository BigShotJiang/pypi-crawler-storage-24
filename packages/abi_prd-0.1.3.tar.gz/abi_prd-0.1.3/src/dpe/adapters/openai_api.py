"""OpenAI API adapter — stub, disabled by default."""

from __future__ import annotations

from typing import Any

from dpe.adapters.base import ModelAdapter
from dpe.models.adapter import ModelRequest, ModelResult


class OpenAIApiAdapter(ModelAdapter):
    """Optional OpenAI API adapter. Not implemented in V1."""

    def generate(self, request: ModelRequest) -> ModelResult:
        raise NotImplementedError("OpenAI API adapter is not enabled in V1.")

    def healthcheck(self) -> bool:
        return False

    def estimate_usage(self, request: ModelRequest) -> dict[str, Any]:
        return {"estimated_tokens": len(request.prompt) // 4}

    def get_usage_snapshot(self) -> dict[str, Any]:
        return {"enabled": False}
