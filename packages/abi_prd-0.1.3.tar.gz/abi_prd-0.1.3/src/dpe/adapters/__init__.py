"""Model adapter implementations."""
