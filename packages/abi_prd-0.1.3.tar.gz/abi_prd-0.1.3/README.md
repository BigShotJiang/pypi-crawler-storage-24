# abi-prd

Deterministic, budget-aware PRD generation engine. Runs a dialectical workflow (thesis → antithesis → synthesis) to produce structured, schema-validated Product Requirements Documents. Part of the **Planning Pack (Layer 2)**.

Depends on `abi-control-core` for schema validation and audit trail artifacts.

## Install

```bash
pip install abi-prd
```

## Quick start (CLI)

```bash
# Generate a PRD from an idea (simulation mode — no real LLM calls)
dialectic run --idea "Add OAuth2 authentication to the API" --simulation

# Full run with a config file
dialectic run --idea "User dashboard" --config config.json --output-dir runs/

# Deterministic smoke test
dialectic run --idea "Test feature" --smoke
```

## Quick start (Python)

```python
from dpe.engine.orchestrator import Orchestrator
from dpe.engine.config_loader import load_config

# Load configuration (supports simulation mode)
config = load_config(None, simulation_mode=True, output_dir="runs/")

# Run the dialectical PRD generation workflow
orchestrator = Orchestrator(config)
result = orchestrator.run(idea="Add user authentication")
```

## What's included

- **Dialectical workflow** -- thesis/antithesis/synthesis cycle for structured PRD generation
- **Budget enforcement** -- token, time, and cost budgets with deterministic tracking
- **Multi-provider adapters** -- Anthropic, OpenAI, Claude Code CLI, Codex CLI, local, and simulation
- **Schema validation** -- generated PRDs are validated against `abi-control-core` contracts
- **Audit trail artifacts** -- each generation run produces sealed audit trail artifacts
- **CLI** -- `dialectic` command for quick PRD generation

## ABI ecosystem

`abi-prd` is part of the Planning Pack (Layer 2), built on top of `abi-control-core` (Layer 1). It pairs with `abi-spec` to form the full planning pipeline: PRD generation followed by specification compilation.

Related packages:

- [abi-control-core](https://github.com/AbilityBI/abi-core) -- contracts and audit trail SDK (Layer 1, required)
- [abi-spec](https://github.com/AbilityBI/abi-spec) -- specification compiler (Layer 2)
- [abi-evals](https://github.com/AbilityBI/abi-evals) -- eval runner for validating PRD quality

## Versioning

Follows Semantic Versioning. Current version: `0.1.3`. See CHANGELOG.md for release notes.

## License

MIT License (see LICENSE file).
