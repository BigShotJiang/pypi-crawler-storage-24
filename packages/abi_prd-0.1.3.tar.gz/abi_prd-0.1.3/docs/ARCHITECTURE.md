# Architecture

## High-Level Design
Deterministic PRD generation kernel for AbilityBI product planning workflows.

## Components
- src/abi_prd/ — PRD generation engine
- tests/ — PRD governance and schema tests
- docs/planning/ — PRD and planning documents

## Interfaces
Inputs: Structured data, policy definitions, or API requests depending on module.
Outputs: Processed results, evidence packs, or structured reports.
