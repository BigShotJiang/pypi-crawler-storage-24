# Smoke Test Mode

Deterministic, offline CI test mode for the abi-prd.

## Purpose

Smoke mode produces **byte-identical canonical artifacts** across runs with
**no external model calls**. It is designed for:

- CI pipelines that must run offline and fast
- Schema validation of all output artifacts
- Regression detection via deterministic output comparison

## Usage

### CLI

```bash
dialectic run --idea "Build a task management app" --smoke
```

`--smoke` implies `--simulation` — no real model adapters are invoked.

### Python

```python
from dpe.models.config import DPEConfig
from dpe.engine.orchestrator import Orchestrator

cfg = DPEConfig(smoke_mode=True, output_dir="runs")
manifest = Orchestrator(config=cfg).run("Build a task management app")
```

## What smoke mode fixes

| Source of non-determinism | Smoke behavior |
|---------------------------|----------------|
| `run_id` | Fixed: `"000000000000"` |
| `datetime.now()` timestamps | Fixed: `2026-01-01T00:00:00Z` |
| `wall_time_seconds` | Fixed: `0.0` |
| `config_hash` | Normalized: `output_dir` excluded from hash |
| Model responses | Simulation adapter returns deterministic stubs |

## Output directory

All artifacts are written to `<output_dir>/000000000000/`:

```
000000000000/
  run_manifest.json          # DPE-native manifest
  artifact_index.json        # Artifact inventory
  plan_graph.json            # Canonical plan graph (abi-control-core)
  eval_suite.json            # Canonical eval suite (abi-control-core)
  run_manifest.core.json     # Canonical run manifest (abi-control-core)
  01_input_normalize.md      # Stage artifacts...
  02_ideation_a.md
  ...
```

## Running tests

```bash
# Smoke tests only
pytest tests/test_smoke.py -v

# Full suite (includes smoke tests)
pytest
```

### Test coverage

| Test class | What it verifies |
|------------|------------------|
| `TestSmokeConfig` | `smoke_mode` forces `simulation_mode`, default is `False`, hash is stable |
| `TestSmokeRunId` | Run ID is fixed, output directory uses fixed ID |
| `TestSmokeTimestamps` | All stage/manifest/artifact timestamps are epoch, wall time is zero |
| `TestSmokeCanonicalArtifacts` | All 3 canonical artifacts exist and pass schema validation |
| `TestSmokeDeterminism` | Two independent runs produce byte-identical artifacts and hashes |
| `TestSmokeNativeArtifacts` | Run completes, no warnings, all files present, simulation adapter used |

## CI integration

Add to your CI pipeline:

```yaml
- name: Smoke test
  run: |
    pip install -e ".[dev]"
    pytest tests/test_smoke.py -v --tb=short
```

No API keys, network access, or external services required.
