# Hygiene Policy

This document defines the working tree hygiene standard for **abi-prd**.

## Clean Tree Requirement

The working tree must be clean (no uncommitted changes) before:
- Running ecosystem gates (`platform_guard.py`)
- Opening or merging pull requests
- Cutting release tags

## Transient Output Directories

| Path | Purpose | Gitignored |
|------|---------|------------|
| `runs/` | Orchestration run outputs | Yes |
| `.tmp/` | Workspace-relative temp files (gate reports) | Yes |
| `artifacts/` | Generated artifacts (evidence, reports) | Yes |

## Quarantine Protocol

If uncommitted work must be preserved before a gate run:

1. Create a WIP branch: `git checkout -b wip/<description>-<date>`
2. Commit all changes: `git add -A && git commit -m "wip: quarantine"`
3. Switch back to the target branch
4. Document recovery in `docs/WIP_RECOVERY.md`

## Enforcement

`scripts/platform_hygiene_gate.py` checks all 9 ABI repos.
Override: `--allow-dirty <repo>` downgrades FAIL to WARN.
