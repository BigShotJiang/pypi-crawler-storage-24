# abi-prd (DPE) — V1

Industrial, Budget-Aware, Deterministic AI Orchestration Kernel

## 1. Executive Summary

The abi-prd (DPE) is a deterministic, budget-aware AI orchestration system that generates a development-ready Product Requirements Document (PRD) from a base idea using a bounded multi-model dialectical workflow.

The system enforces hard execution budgets, produces a complete artifact trail, and exposes a Model Context Protocol (MCP) interface for integration into the Multi Agent Orchestrator (MCO).

DPE is designed to prevent token amplification, uncontrolled recursion, and subscription abuse while preserving the value of structured multi-model critique.

## 2. Core Objectives

- Generate a high-quality PRD from a base idea.
- Use a bounded dialectical workflow (no recursion).
- Enforce deterministic hard budgets:
  - max total calls
  - max premium calls
  - max critique rounds
  - max wall time
- Produce an auditable evidence pack for every run.
- Support multiple model backends:
  - Claude Code CLI (subscription)
  - Codex CLI (ChatGPT subscription)
  - Local LLM (Ollama or equivalent)
  - Optional API adapters (disabled by default)
- Provide MCP server integration.

## 3. Non-Goals (V1)

- No recursive N-level ideation.
- No parallel premium calls.
- No browser automation.
- No automatic "AI agreement scoring."
- No unattended long-running loops.
- No guaranteed cost-per-token accounting for subscriptions.

## 4. V1 Dialectical Workflow

Finite State Machine (FSM):

1. `INPUT_NORMALIZE`
2. `IDEATION_A`
3. `IDEATION_B`
4. `CROSS_CRITIQUE_A` (optional)
5. `CROSS_CRITIQUE_B` (optional)
6. `SYNTHESIS`
7. `PRD_V1`
8. `PRD_CRITIQUE_R1`
9. `PRD_REVISION_R1`
10. `PRD_CRITIQUE_R2` (optional)
11. `PRD_REVISION_R2` (optional)
12. `FINALIZE`

Maximum critique rounds: 2 (default).

## 5. Simulation Mode

The system must support `simulation_mode = true`. In this mode:

- No LLM calls are made.
- Stub deterministic outputs are generated.
- Used for testing and CI.

## 6. Success Criteria

- A complete PRD is generated within budget.
- A full artifact pack is created.
- Manifest reflects deterministic trace.
- Local fallback works if premium throttles.
- MCP endpoint returns structured response.
