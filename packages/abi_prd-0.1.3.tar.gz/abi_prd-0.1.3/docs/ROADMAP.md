# Roadmap

## Near Term
- PRD diff and versioning tooling
- Cross-repo PRD dependency tracking

## Later
- PRD-to-spec auto-generation pipeline
