# Run Manifest Schema

Each run produces `runs/<run_id>/run_manifest.json`.

## Top-Level Fields

| Field | Type | Description |
|---|---|---|
| `run_id` | string | 12-character hex identifier (truncated UUIDv4) |
| `timestamp` | ISO 8601 | Run start time |
| `config_hash` | string | SHA-256 of serialised DPEConfig |
| `models_used` | object | `{stage: adapter_used}` for each executed stage |
| `budget_limits` | object | Configured limits snapshot |
| `budget_actuals` | object | Actual usage at run end |
| `throttle_events` | array | List of throttle event records |
| `stages` | array | Ordered list of stage records |
| `artifacts` | array | List of artifact records with hashes |
| `stop_reason` | string | `"completed"`, `"budget_exceeded"`, `"error: <ExceptionType>"`, `"config_error"` |
| `warnings` | array | Non-fatal warnings |

## Stage Record

| Field | Type |
|---|---|
| `stage` | string (Stage enum value) |
| `adapter_used` | string |
| `started_at` | ISO 8601 |
| `finished_at` | ISO 8601 or null |
| `skipped` | boolean |
| `error` | string or null |

## Artifact Record

| Field | Type |
|---|---|
| `filename` | string |
| `stage` | string |
| `sha256` | string |
| `size_bytes` | integer |
| `written_at` | ISO 8601 |

## Artifact Files

| Filename | Stage |
|---|---|
| `00_input_normalized.md` | INPUT_NORMALIZE |
| `10_ideation_a.md` | IDEATION_A |
| `11_ideation_b.md` | IDEATION_B |
| `20_cross_critique_a.md` | CROSS_CRITIQUE_A |
| `21_cross_critique_b.md` | CROSS_CRITIQUE_B |
| `30_synthesis.md` | SYNTHESIS |
| `40_prd_v1.md` | PRD_V1 |
| `50_critique_r1.md` | PRD_CRITIQUE_R1 |
| `60_prd_v2.md` | PRD_REVISION_R1 |
| `70_critique_r2.md` | PRD_CRITIQUE_R2 |
| `80_prd_v3.md` | PRD_REVISION_R2 |
| `80_prd_final.md` | FINALIZE |
| `run_manifest.json` | — |
| `artifact_index.json` | — |
