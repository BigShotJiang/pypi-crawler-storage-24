# MCP Interface

## Tool: `dialectic.generate_prd`

### Input Schema

```json
{
  "idea": "string (required)",
  "context": "object (optional)",
  "config_overrides": "object (optional)"
}
```

### Output Schema

```json
{
  "final_prd_markdown": "string",
  "run_id": "string",
  "artifact_path": "string",
  "run_manifest": "object (RunManifest)",
  "warnings": ["string"]
}
```

### Behaviour

1. Accepts an idea string and optional context/config overrides.
2. Merges config overrides with default `DPEConfig`.
3. Invokes `Orchestrator.run()`.
4. Returns the final PRD markdown along with the run manifest.
5. On failure, returns partial manifest with `stop_reason` set.

### Error Handling

All errors return a structured dict matching the output schema — no exceptions are raised to the caller.

- Budget breach → returns manifest with `stop_reason: "budget_exceeded"`.
- Adapter failure → returns manifest with `stop_reason: "error: <ExceptionType>"`.
- Invalid config → returns `stop_reason: "config_error"` with `error` details before starting a run.
