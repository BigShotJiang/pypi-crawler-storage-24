﻿"""Agent service: orchestrates LLM + tools with invoke and loop methods."""

import os
import tempfile
from pathlib import Path

from operator_use.bus.views import AudioPart, ContentPart, ImagePart, TextPart, text_from_parts
from operator_use.messages import AIMessage, HumanMessage, ImageMessage, ToolMessage
from operator_use.agent.tools import ToolRegistry, BUILTIN_TOOLS,COMPUTER_USE_TOOLS
from operator_use.bus import Bus, IncomingMessage, OutgoingMessage, StreamPhase
from operator_use.providers.events import LLMEventType, LLMStreamEventType
from operator_use.agent.computer_use import Desktop, WatchDog
from typing import TYPE_CHECKING, Callable, Awaitable
from operator_use.session import SessionStore, Session
from operator_use.agent.context import Context
from operator_use.subagent import SubagentStore
from operator_use.process import ProcessStore
from PIL import Image as PILImage
from io import BytesIO
import base64
import logging
import asyncio

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from operator_use.providers.base import BaseChatLLM, BaseSTT, BaseTTS
    from operator_use.crons.service import Cron


class Agent:
    """Async agent that accepts tools and provides invoke/loop methods."""

    def __init__(
        self,
        bus: Bus,
        llm: "BaseChatLLM",
        stt: "BaseSTT | None" = None,
        tts: "BaseTTS | None" = None,
        sessions: SessionStore | None = None,
        max_iterations: int = 100,
        userdata_dir: Path | None = None,
        computer_use: bool = False,
        streaming: bool = True,
        cron: "Cron | None" = None,
        gateway=None,
    ):
        self.userdata_dir = (userdata_dir or Path.cwd()) / ".operator_use"
        self.workspace = self.userdata_dir / "workspace"
        self.sessions = sessions or SessionStore(workspace=self.workspace)
        self.context = Context(workspace=self.workspace)
        self.computer_use = computer_use
        self.tool_register = ToolRegistry()
        self.max_iterations = max_iterations
        self.streaming = streaming
        self.llm = llm
        self.stt = stt
        self.tts = tts
        self.bus = bus
        self.cron = cron
        self.gateway = gateway
        self.subagent_store = SubagentStore(llm=llm, bus=bus)
        self.process_store = ProcessStore()
        self._running = False
        self._pending_replies: dict[str, asyncio.Future[str]] = {}

        self.desktop = None
        if Desktop and computer_use:
            try:
                self.desktop = Desktop(use_accessibility=True, use_vision=False)
            except Exception as e:
                logger.warning(f"Desktop init failed, computer use disabled: {e}")
        self.tool_register.register_tools(BUILTIN_TOOLS)
        logger.debug(f"Registered tools: {[t.name for t in BUILTIN_TOOLS]}")

    async def _build_request_message(self, message: IncomingMessage) -> HumanMessage | ImageMessage:
        """Build HumanMessage or ImageMessage from parts. Agent does STT for audio paths."""

        parts = message.parts or []
        texts: list[str] = []
        images: list = []

        for part in parts:
            if isinstance(part, TextPart):
                texts.append(part.content)
            elif isinstance(part, AudioPart):
                audio_val = part.audio
                if Path(audio_val).is_file() and self.stt:
                    try:
                        audio_val = await self.stt.atranscribe(audio_val)
                    except Exception as e:
                        logger.warning(f"STT failed for {audio_val}: {e}")
                        audio_val = "[transcription failed]"
                texts.append(audio_val.strip())
            elif isinstance(part, ImagePart) and part.images:
                for b64 in part.images:
                    try:
                        data = base64.b64decode(b64)
                        img = PILImage.open(BytesIO(data)).convert("RGB")
                        images.append(img)
                    except Exception as e:
                        logger.warning(f"Failed to decode image from parts: {e}")
            else:
                logger.warning(f"Unsupported part type: {type(part)}")
           

        content = "\n".join(texts) if texts else ("[image]" if images else "[empty message]")

        if not images:
            return HumanMessage(content=content)

        return ImageMessage(
            content=content,
            images=images,
            mime_type="image/jpeg",
        )

    async def _process_incoming_message(self, message: IncomingMessage) -> OutgoingMessage:
        """Process an incoming message and return an outgoing message."""
        
        session_id = f'{message.channel}:{message.chat_id}'
        self.tool_register.set_extension("_bus", self.bus)
        self.tool_register.set_extension("_gateway", self.gateway)
        self.tool_register.set_extension("_channel", message.channel)
        self.tool_register.set_extension("_chat_id", message.chat_id)
        self.tool_register.set_extension("_metadata", message.metadata or {})
        self.tool_register.set_extension("_cron", self.cron)
        self.tool_register.set_extension("_pending_replies", self._pending_replies)
        self.tool_register.set_extension("_session_id", session_id)
        self.tool_register.set_extension("_subagent_store", self.subagent_store)
        self.tool_register.set_extension("_process_store", self.process_store)
        self.tool_register.set_extension("_llm", self.llm)

        session = self.sessions.get_or_create(session_id=session_id)
        request_message = await self._build_request_message(message)
        # Persist channel metadata (e.g. message_id) on the HumanMessage for future reference
        if hasattr(request_message, "metadata") and message.metadata:
            request_message.metadata = dict(message.metadata)
        session.add_message(request_message)

        streamed = False

        async def publish_stream(content: str, is_final: bool, init: bool = False) -> None:
            nonlocal streamed
            phase = StreamPhase.START if init else (StreamPhase.END if is_final else StreamPhase.CHUNK)
            if is_final:
                streamed = True
            await self.bus.publish_outgoing(
                OutgoingMessage(
                    chat_id=message.chat_id,
                    channel=message.channel,
                    parts=[TextPart(content=content)],
                    metadata=message.metadata,
                    reply=True,
                    stream_phase=phase,
                )
            )

        # No streaming when user sent voice: need one final response for TTS
        # No streaming for cli/direct: no channel to receive streamed chunks (heartbeat, process_direct)
        use_streaming = (
            self.streaming
            and message.channel not in ("direct", "cli")
            and hasattr(self.llm, "astream")
            and not self._user_sent_voice(message)
        )

        if use_streaming:
            response_message = await self._loop_stream(session=session, publish_stream=publish_stream, message=message)
        else:
            response_message = await self._loop(session=session, message=message)
        self.sessions.save(session)

        return await self._build_outgoing_message(message, response_message, streamed)

    def _user_sent_voice(self, message: IncomingMessage) -> bool:
        """True if incoming message had voice/audio from the user."""
        return any(isinstance(p, AudioPart) for p in (message.parts or []))

    async def _build_outgoing_message(self, message: IncomingMessage, response_message: AIMessage, streamed: bool) -> OutgoingMessage:
        """Build OutgoingMessage. Voice in → voice out only. Text in → text out only."""
        import re
        text = response_message.content or ""
        # Strip internal message IDs [msg_id:N] or [bot_msg_id:N] from spoken text
        clean_text = re.sub(r'^\[(bot_)?msg_id:[^\]]+\]\s*', '', text)
        parts: list[ContentPart] = []

        if self.tts and clean_text and len(clean_text) <= 4000 and self._user_sent_voice(message):
            try:
                suffix = ".wav"  # Common TTS output; channel sends as voice/audio
                fd, path = tempfile.mkstemp(suffix=suffix)
                try:
                    os.close(fd)
                    await self.tts.asynthesize(clean_text, path)
                    parts = [AudioPart(audio=path)]
                except Exception:
                    try:
                        os.unlink(path)
                    except OSError:
                        pass
                    raise
            except Exception as e:
                logger.warning("TTS failed: %s", e)

        # Voice in → voice out only (no text). Text in → text out only.
        if not parts:
            parts = [TextPart(content=clean_text)]

        return OutgoingMessage(
            chat_id=message.chat_id,
            channel=message.channel,
            parts=parts,
            metadata=message.metadata,
            reply=True,
            stream_phase=StreamPhase.DONE if streamed else None,
        )

    async def _loop(self, session: Session, message: IncomingMessage | None = None) -> AIMessage:
        """
        Run the agent loop (non-streaming) until a final AIMessage is returned.
        Uses ainvoke for each LLM call.
        """
        tools = self.tool_register.list_tools()
        for _ in range(self.max_iterations):
            history = session.get_history()
            is_voice = self._user_sent_voice(message)

            messages = self.context.build_messages(history=history, is_voice=is_voice)
            if self.computer_use and self.desktop:
                try:
                    loop = asyncio.get_event_loop()
                    desktop_state = await loop.run_in_executor(None, self.desktop.get_state)
                    desktop_content = desktop_state.to_string()
                    if self.desktop.use_vision and desktop_state.screenshot:
                        messages.append(ImageMessage(images=[desktop_state.screenshot], content=desktop_content))
                    else:
                        messages.append(HumanMessage(content=desktop_content))
                except Exception as e:
                    logger.warning(f"Desktop state capture failed: {e}")
            logger.info(f"LLM call | model={self.llm.model_name} messages={len(messages)} tools={len(tools)}")
            llm_event = await self.llm.ainvoke(messages=messages, tools=tools)
            logger.info(f"LLM response | {llm_event.type.name}")
            thinking, thinking_signature = (
                (llm_event.thinking.content, llm_event.thinking.signature)
                if llm_event.thinking
                else (None, None)
            )
            match llm_event.type:
                case LLMEventType.TOOL_CALL:
                    tool_call = llm_event.tool_call
                    name=tool_call.name
                    params=tool_call.params
                    logger.debug(f"Tool call | name={name} params={params}")
                    tool_result = await self.tool_register.aexecute(name, params)
                    content = (tool_result.output if tool_result.success else tool_result.error)
                    if tool_result.success:
                        logger.debug(f"Tool success | {str(content)[:200]}")
                    else:
                        logger.warning(f"Tool error | {str(content)[:200]}")
                    session.add_message(
                        ToolMessage(
                            id=tool_call.id,
                            name=tool_call.name,
                            params=tool_call.params,
                            content=content,
                            thinking=thinking,
                            thinking_signature=thinking_signature,
                        )
                    )
                    if tool_result.metadata and tool_result.metadata.get("stop_loop"):
                        return AIMessage(content=content or "")
                case LLMEventType.TEXT:
                    import re
                    clean_content = re.sub(r'<think>.*?</think>\s*', '', llm_event.content or "", flags=re.DOTALL)
                    clean_content = re.sub(r'^\[(bot_)?msg_id:\d+\]\s*', '', clean_content).strip()
                    logger.info(f"Response | {clean_content[:120]!r}{'...' if len(clean_content) > 120 else ''}")
                    msg = AIMessage(
                        content=clean_content,
                        thinking=thinking,
                        thinking_signature=thinking_signature,
                    )
                    session.add_message(msg)
                    return msg

        raise RuntimeError(f"Agent exceeded max_iterations ({self.max_iterations})")

    async def _loop_stream(self, session: Session, publish_stream: Callable[..., Awaitable[None]], message: IncomingMessage | None = None) -> AIMessage:
        """
        Run the agent loop (streaming) until a final AIMessage is returned.
        Uses astream for each LLM call and publishes tokens via publish_stream.
        """
        tools=self.tool_register.list_tools()
        for _ in range(self.max_iterations):
            history = session.get_history()
            is_voice = self._user_sent_voice(message)

            messages = self.context.build_messages(history=history, is_voice=is_voice)
            if self.computer_use and self.desktop:
                try:
                    loop = asyncio.get_event_loop()
                    desktop_state = await loop.run_in_executor(None, self.desktop.get_state)
                    desktop_content = desktop_state.to_string()
                    if self.desktop.use_vision and desktop_state.screenshot:
                        messages.append(ImageMessage(images=[desktop_state.screenshot], content=desktop_content))
                    else:
                        messages.append(HumanMessage(content=desktop_content))
                except Exception as e:
                    logger.warning(f"Desktop state capture failed: {e}")
                    
            thinking = None
            thinking_signature = None
            content = ""
            last_publish_len = 0
            stream_init_sent = False
            chunk_size = 15  # Batch updates to avoid rate limits

            async for event in self.llm.astream(messages=messages, tools=tools):
                if event.thinking:
                    thinking = event.thinking.content
                    thinking_signature = event.thinking.signature

                match event.type:
                    case LLMStreamEventType.TEXT_START:
                        pass
                    case LLMStreamEventType.TOOL_CALL:
                        logger.debug(f"Tool call | name={event.tool_call.name} params={event.tool_call.params}")
                        tool_call = event.tool_call
                        tool_result = await self.tool_register.aexecute(
                            tool_call.name, tool_call.params
                        )
                        content = (
                            tool_result.output if tool_result.success else tool_result.error
                        )
                        if tool_result.success:
                            logger.debug(f"Tool success | {str(content)[:200]}")
                        else:
                            logger.warning(f"Tool error | {str(content)[:200]}")
                        session.add_message(
                            ToolMessage(
                                id=tool_call.id,
                                name=tool_call.name,
                                params=tool_call.params,
                                content=content,
                                thinking=thinking,
                                thinking_signature=thinking_signature,
                            )
                        )
                        if tool_result.metadata and tool_result.metadata.get("stop_loop"):
                            return AIMessage(content=content or "")
                        break  # continue to next iteration
                    case LLMStreamEventType.TEXT_DELTA:
                        if event.content:
                            content += event.content
                            if len(content) - last_publish_len >= chunk_size:
                                if not stream_init_sent:
                                    await publish_stream(content, False, init=True)
                                    stream_init_sent = True
                                else:
                                    await publish_stream(content, False)
                                last_publish_len = len(content)
                    case LLMStreamEventType.TEXT_END:
                        logger.info(f"Response | {content[:120]!r}{'...' if len(content) > 120 else ''} usage={event.usage}")
                        content = content or "(no response)"
                        import re
                        # Strip thinking tags (Qwen3/DeepSeek style) and leading message IDs
                        content = re.sub(r'<think>.*?</think>\s*', '', content, flags=re.DOTALL)
                        content = re.sub(r'^\[(bot_)?msg_id:\d+\]\s*', '', content)
                        content = content.strip() or "(no response)"
                        if not stream_init_sent:
                            await publish_stream(content, True, init=True)
                        else:
                            await publish_stream(content, True)
                        msg = AIMessage(
                            content=content,
                            thinking=thinking,
                            thinking_signature=thinking_signature,
                        )
                        session.add_message(msg)
                        return msg

        raise RuntimeError(f"Agent exceeded max_iterations ({self.max_iterations})")

    async def process_direct(self, content: str,channel: str = "cli", chat_id:str = "direct") -> None:
        """Process a message directly without publishing to the bus."""
        message = IncomingMessage(
            parts=[TextPart(content=content)],
            user_id="user",
            channel=channel,
            chat_id=chat_id,
        )
        response_message = await self._process_incoming_message(message)
        return text_from_parts(response_message.parts)

    async def _handle_message(self, request_message: IncomingMessage) -> None:
        """Process one incoming message end-to-end (runs as a concurrent task)."""
        session_id = f'{request_message.channel}:{request_message.chat_id}'
        try:
            response_message = await self._process_incoming_message(request_message)
            sent_id_future: asyncio.Future[int | None] = asyncio.get_event_loop().create_future()
            response_message.sent_id_future = sent_id_future
            await self.bus.publish_outgoing(response_message)
            try:
                bot_message_id = await asyncio.wait_for(asyncio.shield(sent_id_future), timeout=5.0)
                if bot_message_id is not None:
                    logger.info(f"Resolved bot message ID: {bot_message_id}")
                    session = self.sessions.get_or_create(session_id=session_id)
                    for msg in reversed(session.messages):
                        if isinstance(msg, AIMessage):
                            if not isinstance(msg.metadata, dict):
                                msg.metadata = {}
                            if msg.metadata.get("message_id") is None:
                                msg.metadata["message_id"] = bot_message_id
                            break
                    self.sessions.save(session)
                else:
                    logger.debug("sent_id_future resolved with None")
            except asyncio.TimeoutError:
                logger.debug("No sent_message_id received within timeout — skipping.")
        except Exception as e:
            logger.error(f"Error processing message: {e}", exc_info=True)
            try:
                error_response = OutgoingMessage(
                    chat_id=request_message.chat_id,
                    channel=request_message.channel,
                    parts=[TextPart(content=f"Sorry, I encountered an error: {type(e).__name__}: {str(e)[:300]}")],
                    metadata=request_message.metadata,
                    reply=True,
                )
                await self.bus.publish_outgoing(error_response)
            except Exception as send_err:
                logger.error(f"Failed to send error response: {send_err}")

    async def ainvoke(self):
        self._running = True
        logger.info("Agent ainvoke loop started")
        while self._running:
            try:
                request_message = await asyncio.wait_for(self.bus.consume_incoming(), timeout=1.0)
                session_id = f'{request_message.channel}:{request_message.chat_id}'
                logger.info(f"Message received | channel={request_message.channel} chat={request_message.chat_id}")

                # If a tool is waiting for a reply from this session, resolve it instead of spawning a new task
                if session_id in self._pending_replies:
                    future = self._pending_replies.pop(session_id)
                    if not future.done():
                        from operator_use.bus.views import text_from_parts
                        future.set_result(text_from_parts(request_message.parts) or "")
                    continue

                asyncio.create_task(self._handle_message(request_message))
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Unexpected error in ainvoke loop: {e}", exc_info=True)
        self._running = False

