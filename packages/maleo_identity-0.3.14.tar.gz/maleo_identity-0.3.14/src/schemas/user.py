from pydantic import BaseModel, Field
from typing import Annotated, Generic, Literal, Self, TypeVar, overload
from uuid import UUID
from nexo.enums.status import (
    ListOfDataStatuses,
    FULL_DATA_STATUSES,
)
from nexo.enums.user import (
    UserType,
    FullUserTypeMixin,
)
from nexo.schemas.mixins.filter import convert as convert_filter
from nexo.schemas.mixins.identity import (
    IdentifierMixin,
    Ids,
    UUIDs,
    IntOrganizationId,
    IntOrganizationIds,
)
from nexo.schemas.mixins.parameter import IncludeURL
from nexo.schemas.mixins.sort import convert as convert_sort
from nexo.schemas.operation.enums import ResourceOperationStatusUpdateType
from nexo.schemas.parameter import (
    ReadSingleParameter as BaseReadSingleParameter,
    ReadPaginatedMultipleParameter,
    StatusUpdateParameter as BaseStatusUpdateParameter,
    DeleteSingleParameter as BaseDeleteSingleParameter,
)
from nexo.types.dict import StrToAnyDict
from nexo.types.integer import OptInt, OptListOfInts
from nexo.types.string import OptStr, OptListOfStrs
from nexo.types.uuid import OptListOfUUIDs
from ..enums.user import IdentifierType
from ..mixins.user_type import UserTypeId, UserTypeIds
from ..mixins.user import (
    Username,
    Usernames,
    Email,
    Emails,
    Phone,
    Phones,
    Password,
    UserIdentifier,
)
from ..types.user import IdentifierValueType


class BaseCreateParameter(
    IntOrganizationId[OptInt],
    Password,
    Phone[str],
    Email[str],
    Username[str],
):
    pass


class CreateParameterV0(
    BaseCreateParameter,
    FullUserTypeMixin[UserType],
):
    pass


class CreateParameter(
    BaseCreateParameter,
    UserTypeId[int],
):
    pass


class VerifyPasswordData(Password):
    pass


class EncryptedVerifyPasswordData(BaseModel):
    encrypted_password: Annotated[str, Field(..., description="Encrypted password")]


VerifyPasswordDataT = TypeVar(
    "VerifyPasswordDataT", VerifyPasswordData, EncryptedVerifyPasswordData
)


class VerifyPasswordDataMixin(BaseModel, Generic[VerifyPasswordDataT]):
    data: Annotated[VerifyPasswordDataT, Field(..., description="Verify Password Data")]


class VerifyPasswordParameter(
    VerifyPasswordDataMixin[VerifyPasswordDataT],
    IdentifierMixin[UserIdentifier],
    Generic[VerifyPasswordDataT],
):
    pass


class ReadMultipleParameter(
    IncludeURL,
    ReadPaginatedMultipleParameter,
    Phones[OptListOfStrs],
    Emails[OptListOfStrs],
    Usernames[OptListOfStrs],
    UserTypeIds[OptListOfInts],
    UUIDs[OptListOfUUIDs],
    Ids[OptListOfInts],
    IntOrganizationIds[OptListOfInts],
):
    organization_ids: Annotated[
        OptListOfInts, Field(None, description="Organization's IDs")
    ] = None
    ids: Annotated[OptListOfInts, Field(None, description="Ids")] = None
    uuids: Annotated[OptListOfUUIDs, Field(None, description="UUIDs")] = None
    user_type_ids: Annotated[
        OptListOfInts, Field(None, description="User Type's IDs", min_length=1)
    ] = None
    usernames: Annotated[OptListOfStrs, Field(None, description="User's Usernames")] = (
        None
    )
    emails: Annotated[OptListOfStrs, Field(None, description="User's Emails")] = None
    phones: Annotated[OptListOfStrs, Field(None, description="User's Phones")] = None

    @property
    def _query_param_fields(self) -> set[str]:
        return {
            "organization_ids",
            "ids",
            "uuids",
            "statuses",
            "user_type_ids",
            "usernames",
            "emails",
            "phones",
            "search",
            "page",
            "limit",
            "use_cache",
            "include_url",
        }

    def to_query_params(self) -> StrToAnyDict:
        params = self.model_dump(
            mode="json", include=self._query_param_fields, exclude_none=True
        )
        params["filters"] = convert_filter(self.range_filters)
        params["sorts"] = convert_sort(self.sort_columns)
        params = {k: v for k, v in params.items()}
        return params


class ReadSingleParameter(IncludeURL, BaseReadSingleParameter[UserIdentifier]):
    @classmethod
    def from_identifier(
        cls,
        identifier: UserIdentifier,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
        include_url: bool = False,
    ) -> "ReadSingleParameter":
        return cls(
            identifier=identifier,
            statuses=statuses,
            use_cache=use_cache,
            include_url=include_url,
        )

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: int,
        statuses: ListOfDataStatuses = list(FULL_DATA_STATUSES),
        use_cache: bool = True,
        include_url: bool = False,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.UUID],
        identifier_value: UUID,
        statuses: ListOfDataStatuses = list(FULL_DATA_STATUSES),
        use_cache: bool = True,
        include_url: bool = False,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.USERNAME, IdentifierType.EMAIL],
        identifier_value: str,
        statuses: ListOfDataStatuses = list(FULL_DATA_STATUSES),
        use_cache: bool = True,
        include_url: bool = False,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = list(FULL_DATA_STATUSES),
        use_cache: bool = True,
        include_url: bool = False,
    ) -> "ReadSingleParameter": ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = list(FULL_DATA_STATUSES),
        use_cache: bool = True,
        include_url: bool = False,
    ) -> "ReadSingleParameter":
        return cls(
            identifier=UserIdentifier(
                type=identifier_type,
                value=identifier_value,
            ),
            statuses=statuses,
            use_cache=use_cache,
            include_url=include_url,
        )

    def to_query_params(self) -> StrToAnyDict:
        return self.model_dump(
            mode="json",
            include={"statuses", "use_cache", "include_url"},
            exclude_none=True,
        )


class FullUpdateData(Phone[str], Email[str], Username[str]):
    pass


class PartialUpdateData(Phone[OptStr], Email[OptStr], Username[OptStr]):
    pass


class PasswordUpdateData(BaseModel):
    old: Annotated[str, Field(..., description="Old Password", max_length=255)]
    new: Annotated[str, Field(..., description="New Password", max_length=255)]


class EncryptedPasswordUpdateData(BaseModel):
    encrypted_data: Annotated[str, Field(..., description="Encrypted data")]


UpdateDataT = TypeVar(
    "UpdateDataT",
    FullUpdateData,
    PartialUpdateData,
    PasswordUpdateData,
)


class UpdateDataMixin(BaseModel, Generic[UpdateDataT]):
    data: UpdateDataT = Field(..., description="Update data")


class UpdateParameter(
    IncludeURL,
    UpdateDataMixin[UpdateDataT],
    IdentifierMixin[UserIdentifier],
    Generic[UpdateDataT],
):
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: int,
        data: UpdateDataT,
        include_url: bool = False,
    ) -> Self: ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.UUID],
        identifier_value: UUID,
        data: UpdateDataT,
        include_url: bool = False,
    ) -> Self: ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.USERNAME, IdentifierType.EMAIL],
        identifier_value: str,
        data: UpdateDataT,
        include_url: bool = False,
    ) -> Self: ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        data: UpdateDataT,
        include_url: bool = False,
    ) -> Self: ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        data: UpdateDataT,
        include_url: bool = False,
    ) -> Self:
        return cls(
            identifier=UserIdentifier(type=identifier_type, value=identifier_value),
            data=data,
            include_url=include_url,
        )


DataUpdateDataT = TypeVar("DataUpdateDataT", FullUpdateData, PartialUpdateData)


class DataUpdateParameter(UpdateParameter[DataUpdateDataT], Generic[DataUpdateDataT]):
    pass


class PasswordUpdateParameter(UpdateParameter[PasswordUpdateData]):
    pass


class StatusUpdateParameter(
    IncludeURL,
    BaseStatusUpdateParameter[UserIdentifier],
):
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: int,
        type: ResourceOperationStatusUpdateType,
        include_url: bool = False,
    ) -> "StatusUpdateParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.UUID],
        identifier_value: UUID,
        type: ResourceOperationStatusUpdateType,
        include_url: bool = False,
    ) -> "StatusUpdateParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.USERNAME, IdentifierType.EMAIL],
        identifier_value: str,
        type: ResourceOperationStatusUpdateType,
        include_url: bool = False,
    ) -> "StatusUpdateParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        type: ResourceOperationStatusUpdateType,
        include_url: bool = False,
    ) -> "StatusUpdateParameter": ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        type: ResourceOperationStatusUpdateType,
        include_url: bool = False,
    ) -> "StatusUpdateParameter":
        return cls(
            identifier=UserIdentifier(type=identifier_type, value=identifier_value),
            type=type,
            include_url=include_url,
        )


class DeleteSingleParameter(BaseDeleteSingleParameter[UserIdentifier]):
    @overload
    @classmethod
    def new(
        cls, identifier_type: Literal[IdentifierType.ID], identifier_value: int
    ) -> "DeleteSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls, identifier_type: Literal[IdentifierType.UUID], identifier_value: UUID
    ) -> "DeleteSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.USERNAME, IdentifierType.EMAIL],
        identifier_value: str,
    ) -> "DeleteSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls, identifier_type: IdentifierType, identifier_value: IdentifierValueType
    ) -> "DeleteSingleParameter": ...
    @classmethod
    def new(
        cls, identifier_type: IdentifierType, identifier_value: IdentifierValueType
    ) -> "DeleteSingleParameter":
        return cls(
            identifier=UserIdentifier(type=identifier_type, value=identifier_value)
        )
