"""
AnalyticsAPI — retrieve KPI analytics for your workspace.

Synchronous. Requires a secret key (trac_live_xxx).
"""

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ._client import TraaactionClient


class AnalyticsAPI:
    """
    Retrieve analytics KPIs — via ``Traaaction().analytics``.

    Returns clicks, leads, sales, revenue, and conversion rates
    for a given date range, powered by Tinybird.

    All methods are **synchronous**.
    Requires a secret key (``trac_live_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def retrieve(
        self,
        interval: str = "30d",
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Retrieve KPI analytics for this workspace.

        You can use either the ``interval`` shorthand or explicit date range.
        If both are provided, explicit dates take precedence.

        Args:
            interval:  Shorthand for date range: ``"7d"``, ``"30d"`` (default), ``"90d"``.
            date_from: Start date as ``YYYY-MM-DD`` string.
            date_to:   End date as ``YYYY-MM-DD`` string.

        Returns:
            ``{"data": {...}}`` with keys:
            - ``clicks``           — total click count
            - ``leads``            — total lead count
            - ``sales``            — total sale count
            - ``revenue``          — total net revenue (in cents)
            - ``conversion_rate``  — sales / clicks * 100
            - ``click_to_lead_rate``
            - ``lead_to_sale_rate``
            - ``timeseries``       — list of daily/monthly data points
            - ``date_from``        — effective start date
            - ``date_to``          — effective end date
        """
        return self._client._management_request(
            "GET",
            "/api/v1/analytics",
            params={
                "interval": interval,
                "date_from": date_from,
                "date_to": date_to,
            },
        )
