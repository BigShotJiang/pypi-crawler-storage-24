"""
Synchronous HTTP client for management API calls.

Unlike the fire-and-forget track.* methods, management API calls (links, missions, etc.)
are synchronous — they block until data is returned (or raise on error).

Uses only Python stdlib (urllib.request) — zero external dependencies.
"""

import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional

from .exceptions import TraaactionAPIError, TraaactionAuthError

logger = logging.getLogger("traaaction")

_DEFAULT_TIMEOUT = 10  # seconds


class BaseSyncClient:
    """
    Synchronous HTTP client for Traaaction management API calls.

    All methods block until the API responds (or raise on error).
    Used by LinksAPI, MissionsAPI, SellersAPI, etc.

    Args:
        api_key:  Secret key (trac_live_xxx) for Authorization header.
        base_url: Traaaction API base URL (no trailing slash).
    """

    def __init__(self, api_key: str, base_url: str) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")

    def request(
        self,
        method: str,
        path: str,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a synchronous HTTP request against the Traaaction API.

        Args:
            method:    HTTP method ("GET", "POST", "PATCH", "DELETE").
            path:      API path (e.g. "/api/v1/links").
            json_body: Optional dict to send as JSON body (POST/PATCH).
            params:    Optional query string parameters (GET).

        Returns:
            Parsed JSON response body (dict).

        Raises:
            TraaactionAuthError:  On 401/403 responses.
            TraaactionAPIError:   On any other non-2xx response.
            urllib.error.URLError: On network-level errors.
        """
        url = self._base_url + path

        # Append query params
        if params:
            filtered = {k: str(v) for k, v in params.items() if v is not None}
            if filtered:
                url = url + "?" + urllib.parse.urlencode(filtered)

        # Encode body
        data: Optional[bytes] = None
        if json_body is not None:
            data = json.dumps(json_body).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method=method,
        )

        try:
            with urllib.request.urlopen(req, timeout=_DEFAULT_TIMEOUT) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else {}

        except urllib.error.HTTPError as e:
            status = e.code
            try:
                body = json.loads(e.read())
                err = body.get("error", {})
                code = err.get("code", "api_error") if isinstance(err, dict) else "api_error"
                message = err.get("message", str(e)) if isinstance(err, dict) else str(e)
            except Exception:
                code = "api_error"
                message = str(e)

            logger.debug("traaaction: API error %s on %s %s — %s: %s", status, method, path, code, message)

            if status in (401, 403):
                raise TraaactionAuthError(message)
            raise TraaactionAPIError(status_code=status, code=code, message=message)
