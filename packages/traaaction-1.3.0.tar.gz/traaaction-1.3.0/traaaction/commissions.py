"""
CommissionsAPI — access commission records for your workspace.

Synchronous. Requires a secret key (trac_live_xxx).
"""

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ._client import TraaactionClient


class CommissionsAPI:
    """
    Access commission records — via ``Traaaction().commissions``.

    Commissions are created automatically via Stripe webhooks (or ``track.sale``).
    Lifecycle: PENDING → PROCEED (matured) → COMPLETE (paid).

    All methods are **synchronous** and read-only.
    Requires a secret key (``trac_live_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def list(
        self,
        page: int = 1,
        limit: int = 50,
        status: Optional[str] = None,
        seller_id: Optional[str] = None,
        mission_id: Optional[str] = None,
        source: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List commissions for this workspace.

        Args:
            page:       Page number (default: 1).
            limit:      Items per page, max 100 (default: 50).
            status:     Filter by status: ``"PENDING"``, ``"PROCEED"``, ``"COMPLETE"``.
            seller_id:  Filter by seller ID.
            mission_id: Filter by mission ID.
            source:     Filter by source: ``"LEAD"``, ``"SALE"``, ``"RECURRING"``.

        Returns:
            ``{"data": [...], "meta": {"total": int, "page": int, "limit": int}}``

            Each commission includes: ``gross_amount``, ``net_amount``,
            ``commission_amount``, ``platform_fee``, ``status``,
            ``commission_source``, ``recurring_month``, and ``matured_at``.
        """
        return self._client._management_request(
            "GET",
            "/api/v1/commissions",
            params={
                "page": page,
                "limit": limit,
                "status": status,
                "seller_id": seller_id,
                "mission_id": mission_id,
                "source": source,
            },
        )
