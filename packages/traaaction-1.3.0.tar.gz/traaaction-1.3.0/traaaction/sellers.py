"""
SellersAPI — access sellers enrolled in your workspace.

Synchronous. Requires a secret key (trac_live_xxx).
"""

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ._client import TraaactionClient


class SellersAPI:
    """
    Access sellers (affiliates) enrolled in your workspace — via ``Traaaction().sellers``.

    All methods are **synchronous** and read-only.
    Requires a secret key (``trac_live_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def list(
        self,
        page: int = 1,
        limit: int = 50,
        mission_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List sellers enrolled in this workspace.

        Args:
            page:       Page number (default: 1).
            limit:      Items per page, max 100 (default: 50).
            mission_id: Filter sellers enrolled in a specific mission.
            status:     Filter by enrollment status: ``"PENDING"``, ``"APPROVED"``, ``"REJECTED"``.

        Returns:
            ``{"data": [...], "meta": {"total": int, "page": int, "limit": int}}``

            Each item includes: ``enrollment_id``, ``mission_id``, ``enrollment_status``,
            ``enrolled_at``, and a ``seller`` sub-object.
        """
        return self._client._management_request(
            "GET",
            "/api/v1/sellers",
            params={
                "page": page,
                "limit": limit,
                "mission_id": mission_id,
                "status": status,
            },
        )

    def get(self, seller_id: str) -> Dict[str, Any]:
        """
        Get a single seller by ID, including their balance.

        Args:
            seller_id: The seller's unique ID.

        Returns:
            The seller object with ``balance`` sub-object (pending, due, paid_total).
        """
        return self._client._management_request("GET", f"/api/v1/sellers/{seller_id}")
