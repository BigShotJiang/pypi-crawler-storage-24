"""
PayoutsAPI — access payout sessions for your workspace.

Synchronous. Requires a secret key (trac_live_xxx).
"""

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ._client import TraaactionClient


class PayoutsAPI:
    """
    Access payout sessions (startup payments) — via ``Traaaction().payouts``.

    A payout session represents a batch of commissions paid by a startup
    to the Traaaction platform for redistribution to sellers.

    All methods are **synchronous** and read-only.
    Requires a secret key (``trac_live_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def list(
        self,
        page: int = 1,
        limit: int = 50,
        status: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List payout sessions for this workspace.

        Args:
            page:   Page number (default: 1).
            limit:  Items per page, max 100 (default: 50).
            status: Filter by status: ``"UNPAID"``, ``"PAID"``.

        Returns:
            ``{"data": [...], "meta": {"total": int, "page": int, "limit": int}}``

            Each payout includes: ``amount``, ``currency``, ``status``,
            ``stripe_session_id``, ``commission_ids``, and timestamps.
        """
        return self._client._management_request(
            "GET",
            "/api/v1/payouts",
            params={"page": page, "limit": limit, "status": status},
        )
