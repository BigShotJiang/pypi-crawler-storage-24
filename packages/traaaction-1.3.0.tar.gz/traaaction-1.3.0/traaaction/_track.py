"""
TrackAPI — fire-and-forget affiliate event tracking.

All methods spawn daemon threads and return immediately.
Errors are logged but never raised — tracking must never block your app.
"""

import logging
from typing import TYPE_CHECKING

from ._models import LeadParams, SaleParams

if TYPE_CHECKING:
    from ._client import TraaactionClient

logger = logging.getLogger("traaaction")


class TrackAPI:
    """
    Track affiliate events — fire-and-forget, never blocks your views.

    Accessed via ``Traaaction().track``.

    All requests are made with the **public key** (``pk_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def lead(
        self,
        customer_id: str,
        event_name: str = "sign_up",
        click_id: str = "",
        customer_email: str = "",
        customer_name: str = "",
        customer_avatar: str = "",
        deferred: bool = False,
        sync: bool = False,
    ) -> None:
        """
        Track a lead event (signup, registration, free trial start, etc.).

        Call this immediately after creating a user in your database.

        For cross-device flows (e.g. signup on PC, email confirm on phone),
        use ``deferred=True`` on first call to save attribution without creating
        the lead event, then call again without ``deferred`` to confirm.

        Args:
            customer_id:     Your app's unique user ID (stable, permanent).
            event_name:      Event label, e.g. ``"sign_up"``, ``"free_trial"``, ``"demo_booked"``.
            click_id:        Traaaction click ID for seller attribution.
                             Read from request via ``get_click_id(request)`` in Django.
            customer_email:  Customer email (optional, improves reporting).
            customer_name:   Customer display name (optional).
            customer_avatar: URL to avatar image (optional).
            deferred:        If True, saves attribution but defers lead event creation.
            sync:            If True, send synchronously (blocking). Required for
                             serverless environments (Vercel, Lambda). Auto-detected
                             if not set.
        """
        params = LeadParams(
            customer_id=customer_id,
            event_name=event_name,
            click_id=click_id,
            customer_email=customer_email,
            customer_name=customer_name,
            customer_avatar=customer_avatar,
            deferred=deferred,
        )
        self._client._fire_and_forget("/api/track/lead", params.to_dict(), sync=sync)

    def sale(
        self,
        customer_id: str,
        amount: int,
        currency: str = "EUR",
        event_name: str = "Purchase",
        click_id: str = "",
        sync: bool = False,
    ) -> None:
        """
        Track a manual sale event.

        .. note::
            If you use Stripe webhooks (recommended), you don't need to call
            this — Traaaction handles sale attribution automatically.

        Args:
            customer_id: Your app's unique user ID (same as used in ``track.lead``).
            amount:      Sale amount in smallest currency unit (cents). E.g. ``5900`` = €59.
            currency:    ISO 4217 currency code (default: ``"EUR"``).
            event_name:  Conversion event label.
            click_id:    Traaaction click ID (optional if lead was already tracked).
            sync:        If True, send synchronously (blocking). Required for
                         serverless environments (Vercel, Lambda). Auto-detected
                         if not set.
        """
        params = SaleParams(
            customer_id=customer_id,
            amount=amount,
            currency=currency,
            event_name=event_name,
            click_id=click_id,
        )
        self._client._fire_and_forget("/api/track/conversion", params.to_dict(), sync=sync)
