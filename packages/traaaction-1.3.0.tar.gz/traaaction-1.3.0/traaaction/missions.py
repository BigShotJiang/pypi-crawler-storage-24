"""
MissionsAPI — read-only access to your affiliate programs.

Synchronous. Requires a secret key (trac_live_xxx).
"""

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ._client import TraaactionClient


class MissionsAPI:
    """
    Access your affiliate missions (programs) — via ``Traaaction().missions``.

    All methods are **synchronous** and read-only.
    Requires a secret key (``trac_live_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def list(
        self,
        page: int = 1,
        limit: int = 50,
        status: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List missions for this workspace.

        Args:
            page:   Page number (default: 1).
            limit:  Items per page, max 100 (default: 50).
            status: Filter by status: ``"ACTIVE"``, ``"DRAFT"``, ``"PAUSED"``, etc.

        Returns:
            ``{"data": [...], "meta": {"total": int, "page": int, "limit": int}}``
        """
        return self._client._management_request(
            "GET",
            "/api/v1/missions",
            params={"page": page, "limit": limit, "status": status},
        )

    def get(self, mission_id: str) -> Dict[str, Any]:
        """
        Get a single mission by ID.

        Args:
            mission_id: The mission's unique ID.

        Returns:
            The mission object with commission config and enrollment counts.
        """
        return self._client._management_request("GET", f"/api/v1/missions/{mission_id}")
