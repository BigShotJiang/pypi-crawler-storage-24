"""
Traaaction Django Middleware
============================
Captures the trac_click_id from URL query params and persists it in the
user's session and a cookie — giving your Django app the same attribution
power as a native Next.js integration.

INSTALLATION
------------
Add to MIDDLEWARE in settings.py (before SessionMiddleware is recommended):

    MIDDLEWARE = [
        ...
        'traaaction.django.TraacMiddleware',
        'django.contrib.sessions.middleware.SessionMiddleware',
        ...
    ]

Optionally set TRAC_COOKIE_DOMAIN to share the cookie across subdomains:

    TRAC_COOKIE_DOMAIN = '.yourdomain.com'   # note the leading dot

HOW IT WORKS
------------
When a customer clicks a Traaaction short link, they land on your site
with ?trac_click_id=clk_xxx in the URL. This middleware:

  1. Reads trac_click_id from URL params (priority: trac_click_id > trac_id)
  2. Saves it to request.session['trac_click_id'] (90-day persistence)
  3. Sets a cookie on your domain for cross-request availability
  4. Exposes request.trac_click_id for use in any view or server action

Fallback chain (when no URL param is present):
  session → trac_click_id cookie (trac.js) → clk_id cookie (proxy)
"""

import re

from django.conf import settings

COOKIE_NAME = "clk_id"
COOKIE_MAX_AGE = 60 * 60 * 24 * 90  # 90 days
SESSION_KEY = "trac_click_id"
URL_PARAMS = ["trac_click_id", "trac_id", "client_reference_id"]


def _is_valid_click_id(value: str) -> bool:
    """
    Validates that the value looks like a Traaaction click ID.
    Supports two formats:
      legacy : clk_abc123def456  (12 alphanumeric)
      new    : clk_1704067200_a1b2c3d4e5f67890  (timestamp_16hex)
    Rejects SQL injection and XSS attempts.
    """
    return bool(re.match(r"^clk_([a-z0-9]{12}|\d+_[a-f0-9]{16})$", value))


class TraacMiddleware:
    """
    Captures Traaaction click IDs and persists them across the session.
    Safe to use on all requests — adds ~0.1ms overhead, no external calls.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # 1. Try URL params (highest priority)
        click_id = None
        for param in URL_PARAMS:
            value = request.GET.get(param, "").strip()
            if value and _is_valid_click_id(value):
                click_id = value
                break

        # 2. Persist to session if found from URL
        if click_id:
            request.session[SESSION_KEY] = click_id
            request.session.modified = True

        # 3. Fall back to session, then trac.js cookie, then proxy cookie
        if not click_id:
            click_id = (
                request.session.get(SESSION_KEY)
                or request.COOKIES.get("trac_click_id")  # set by trac.js (cross-subdomain)
                or request.COOKIES.get(COOKIE_NAME)       # set by proxy (custom domain CNAME)
            )

        # 4. Expose on request
        request.trac_click_id = click_id or ""

        # 5. Process the request
        response = self.get_response(request)

        # 6. Set/refresh cookie when click_id is known
        if click_id:
            cookie_domain = getattr(settings, "TRAC_COOKIE_DOMAIN", None)
            response.set_cookie(
                COOKIE_NAME,
                click_id,
                max_age=COOKIE_MAX_AGE,
                path="/",
                domain=cookie_domain,
                secure=not settings.DEBUG,
                httponly=False,  # trac.js SDK must be able to read this
                samesite="Lax",
            )

        return response
