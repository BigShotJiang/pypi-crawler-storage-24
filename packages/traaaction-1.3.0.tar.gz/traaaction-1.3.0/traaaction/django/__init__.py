"""
Traaaction Django integration.

Usage::

    # settings.py
    MIDDLEWARE = [
        ...
        'traaaction.django.TraacMiddleware',
        ...
    ]

    # views.py
    from traaaction import Traaaction
    from traaaction.django import get_click_id

    trac = Traaaction()

    def signup_view(request):
        # ... create user ...
        click_id = get_click_id(request)
        trac.track.lead(click_id=click_id, event_name="sign_up", customer_id=str(user.id))
        return redirect("/dashboard")

    def checkout_view(request):
        metadata = trac.stripe_metadata(request, str(user.id))
        session = stripe.checkout.Session.create(..., metadata=metadata)
        return redirect(session.url)
"""

from .middleware import TraacMiddleware

__all__ = ["TraacMiddleware", "get_click_id"]


def get_click_id(request: object) -> str:
    """
    Read the Traaaction click ID from a Django (or any) request.

    Priority order:
      1. request.trac_click_id  — set by TraacMiddleware (most reliable)
      2. trac_click_id cookie   — set by trac.js client-side (cross-subdomain)
      3. clk_id cookie          — set by proxy (custom domain CNAME)

    Returns an empty string if no click ID is found.
    """
    # 1. From middleware (already resolved, best source)
    if hasattr(request, "trac_click_id") and request.trac_click_id:
        return request.trac_click_id

    # 2. Fallback to cookies (when middleware is not installed)
    cookies = getattr(request, "COOKIES", {})
    return (
        cookies.get("trac_click_id")  # trac.js cookie (cross-subdomain)
        or cookies.get("clk_id")       # proxy cookie (custom domain)
        or ""
    )
