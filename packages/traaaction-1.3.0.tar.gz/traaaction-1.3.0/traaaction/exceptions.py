"""
Traaaction SDK exceptions.
"""


class TraaactionError(Exception):
    """Base exception for all Traaaction SDK errors."""


class TraaactionAPIError(TraaactionError):
    """
    Raised when the Traaaction REST API returns a non-2xx response.

    Attributes:
        status_code: HTTP status code returned by the API.
        code:        Machine-readable error code (e.g. "not_found", "unauthorized").
        message:     Human-readable error message from the API.
    """

    def __init__(self, status_code: int, code: str, message: str) -> None:
        self.status_code = status_code
        self.code = code
        self.message = message
        super().__init__(f"[{status_code}] {code}: {message}")


class TraaactionAuthError(TraaactionAPIError):
    """
    Raised specifically for authentication failures (HTTP 401/403).

    Usually means the API key is invalid, expired, or lacks permissions.
    """

    def __init__(self, message: str = "Invalid or expired API key.") -> None:
        super().__init__(status_code=401, code="unauthorized", message=message)
