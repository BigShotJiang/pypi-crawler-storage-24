"""
Traaaction FastAPI Integration
==============================

Provides a `get_click_id` dependency for FastAPI/Starlette apps.

Install::

    pip install "traaaction[fastapi]"

Usage::

    from fastapi import FastAPI, Depends
    from traaaction.fastapi import get_click_id

    app = FastAPI()

    @app.post("/signup")
    async def signup(
        payload: SignupPayload,
        click_id: str | None = Depends(get_click_id),
    ):
        user = await create_user(payload)
        await trac.track.lead(
            customer_id=str(user.id),
            click_id=click_id or "",
            event_name="sign_up",
        )
        return {"ok": True}

The dependency reads trac_click_id from cookies first, then query params,
following the same priority order as trac.js and the Django middleware.
"""

from __future__ import annotations

from typing import Optional

from ._utils import extract_click_id


def get_click_id(request) -> Optional[str]:
    """
    FastAPI dependency that extracts trac_click_id from the incoming request.

    Priority: cookie ``trac_click_id`` → cookie ``clk_id`` → query param ``trac_click_id``

    Inject it into any route via ``Depends(get_click_id)``.

    Args:
        request: FastAPI ``Request`` object (injected automatically by FastAPI).

    Returns:
        The click ID string, or None if the visitor has no affiliate attribution.

    Example::

        from fastapi import Depends
        from traaaction.fastapi import get_click_id

        @app.post("/signup")
        async def signup(click_id: str | None = Depends(get_click_id)):
            trac.track.lead(customer_id=user.id, click_id=click_id or "")
    """
    try:
        from fastapi import Request
    except ImportError:
        raise ImportError(
            'FastAPI is required. Install it with: pip install "traaaction[fastapi]"'
        )

    if not isinstance(request, Request):
        # Let FastAPI inject the real Request object
        from fastapi import Request as _Request

        async def _dep(req: _Request) -> Optional[str]:
            return _get_from_request(req)

        return _dep  # type: ignore[return-value]

    return _get_from_request(request)


def _get_from_request(request) -> Optional[str]:
    """Internal helper — extracts click_id from a FastAPI/Starlette Request."""
    return extract_click_id(
        cookies=dict(request.cookies),
        params=dict(request.query_params),
    )


# Make get_click_id work directly as a FastAPI dependency by accepting Request
# FastAPI resolves the `request` param automatically when it's typed as Request.
try:
    from fastapi import Request as _Request

    def get_click_id(request: _Request) -> Optional[str]:  # type: ignore[no-redef]  # noqa: F811
        """
        FastAPI dependency that extracts trac_click_id from the incoming request.

        Priority: cookie ``trac_click_id`` → cookie ``clk_id`` → query param ``trac_click_id``

        Example::

            from fastapi import Depends
            from traaaction.fastapi import get_click_id

            @app.post("/signup")
            async def signup(click_id: str | None = Depends(get_click_id)):
                trac.track.lead(customer_id=user.id, click_id=click_id or "")
        """
        return _get_from_request(request)

except ImportError:
    pass  # FastAPI not installed — function defined above will raise on call
