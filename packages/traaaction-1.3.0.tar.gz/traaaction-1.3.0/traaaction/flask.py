"""
Traaaction Flask Integration
============================

Provides WSGI middleware and a `get_click_id()` helper for Flask apps.

Install::

    pip install "traaaction[flask]"

Usage::

    from flask import Flask
    from traaaction.flask import TraacMiddleware, get_click_id

    app = Flask(__name__)

    # Wrap the WSGI app — reads trac_click_id from cookies/params and
    # makes it available via get_click_id() inside any view.
    app.wsgi_app = TraacMiddleware(app.wsgi_app)

    @app.route("/signup", methods=["POST"])
    def signup():
        click_id = get_click_id()  # str | None

        user = create_user(...)
        trac.track.lead(
            customer_id=str(user.id),
            click_id=click_id or "",
            event_name="sign_up",
        )
        return {"ok": True}

Cross-subdomain cookie refresh::

    # If you set TRAC_COOKIE_DOMAIN in your Flask config, the middleware
    # will refresh the cookie on the response so it's accessible on all
    # subdomains (e.g. .monsite.com):
    app.config["TRAC_COOKIE_DOMAIN"] = ".monsite.com"
    app.wsgi_app = TraacMiddleware(app.wsgi_app)
"""

from __future__ import annotations

from typing import Optional, Callable, Iterable, TYPE_CHECKING

from ._utils import extract_click_id, CLICK_ID_COOKIE

if TYPE_CHECKING:
    from wsgiref.types import WSGIEnvironment, StartResponse

_ENVIRON_KEY = "traaaction.click_id"


class TraacMiddleware:
    """
    WSGI middleware for Flask that extracts trac_click_id from the incoming
    request (cookies first, then URL params) and stores it in the WSGI environ
    so `get_click_id()` can retrieve it from any view.

    Optionally refreshes the cookie on the response to extend its lifetime and
    ensure it is scoped to the configured root domain.

    Args:
        app:            The Flask WSGI application.
        cookie_domain:  Optional cookie domain override (e.g. ".monsite.com").
                        If None, the middleware reads from app.config["TRAC_COOKIE_DOMAIN"].
        cookie_max_age: Cookie max-age in seconds (default: 90 days).
    """

    def __init__(
        self,
        app: Callable,
        cookie_domain: Optional[str] = None,
        cookie_max_age: int = 60 * 60 * 24 * 90,
    ) -> None:
        self.app = app
        self.cookie_domain = cookie_domain
        self.cookie_max_age = cookie_max_age

    def __call__(self, environ: "WSGIEnvironment", start_response: "StartResponse") -> Iterable[bytes]:
        # --- Extract click_id from incoming request ---
        cookies = self._parse_cookies(environ.get("HTTP_COOKIE", ""))
        params = self._parse_query_string(environ.get("QUERY_STRING", ""))
        click_id = extract_click_id(cookies=cookies, params=params)

        # Store in environ for get_click_id()
        environ[_ENVIRON_KEY] = click_id

        # --- Intercept start_response to inject Set-Cookie header ---
        refresh_cookie = click_id is not None

        def custom_start_response(status: str, headers: list, exc_info=None):
            if refresh_cookie:
                domain = self._resolve_cookie_domain(environ)
                cookie_value = (
                    f"{CLICK_ID_COOKIE}={click_id}; "
                    f"Max-Age={self.cookie_max_age}; "
                    f"Path=/; "
                    f"SameSite=Lax"
                )
                if domain:
                    cookie_value += f"; Domain={domain}"
                if environ.get("wsgi.url_scheme") == "https":
                    cookie_value += "; Secure"
                headers.append(("Set-Cookie", cookie_value))
            return start_response(status, headers, exc_info)

        return self.app(environ, custom_start_response)

    def _resolve_cookie_domain(self, environ: "WSGIEnvironment") -> Optional[str]:
        if self.cookie_domain:
            return self.cookie_domain
        # Try to read from Flask app config via environ
        try:
            from flask import current_app
            return current_app.config.get("TRAC_COOKIE_DOMAIN")
        except RuntimeError:
            return None

    @staticmethod
    def _parse_cookies(cookie_header: str) -> dict:
        cookies: dict[str, str] = {}
        for part in cookie_header.split(";"):
            part = part.strip()
            if "=" in part:
                name, _, value = part.partition("=")
                cookies[name.strip()] = value.strip()
        return cookies

    @staticmethod
    def _parse_query_string(query_string: str) -> dict:
        from urllib.parse import parse_qs
        raw = parse_qs(query_string, keep_blank_values=False)
        # Flatten lists to single values
        return {k: v[0] for k, v in raw.items() if v}


def get_click_id() -> Optional[str]:
    """
    Retrieve the trac_click_id for the current request.

    Must be called within a Flask request context after `TraacMiddleware` is
    installed. Returns None if the visitor has no affiliate attribution.

    Returns:
        The click ID string (e.g. ``"clk_1234567890_abcdef0123456789"``),
        or None.

    Example::

        from traaaction.flask import get_click_id

        @app.route("/signup", methods=["POST"])
        def signup():
            click_id = get_click_id()
            trac.track.lead(customer_id=str(user.id), click_id=click_id or "")
    """
    try:
        from flask import request as flask_request
        return flask_request.environ.get(_ENVIRON_KEY)
    except RuntimeError:
        # Outside Flask request context
        return None
