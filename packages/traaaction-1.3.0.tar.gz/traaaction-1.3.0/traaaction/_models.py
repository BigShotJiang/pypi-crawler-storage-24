"""
Typed parameter models for Traaaction API calls.
"""

from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Tracking models (fire-and-forget, pk_xxx)
# ---------------------------------------------------------------------------

@dataclass
class LeadParams:
    """Parameters for tracking a lead (signup/registration) event."""
    customer_id: str
    """Your app's unique user ID (stable, permanent)."""

    event_name: str = "sign_up"
    """Name of the event, e.g. 'sign_up', 'free_trial', 'demo_booked'."""

    click_id: str = ""
    """Traaaction click ID from cookie/URL param. Enables seller attribution."""

    customer_email: str = ""
    """Customer email address (optional)."""

    customer_name: str = ""
    """Customer display name (optional)."""

    customer_avatar: str = ""
    """URL to customer avatar image (optional)."""

    deferred: bool = False
    """If True, saves attribution but defers the lead event. Call again without deferred to confirm."""

    def to_dict(self) -> dict:
        d = {
            "customerExternalId": self.customer_id,
            "eventName": self.event_name,
            "clickId": self.click_id,
            "customerEmail": self.customer_email,
            "customerName": self.customer_name,
            "customerAvatar": self.customer_avatar,
        }
        if self.deferred:
            d["mode"] = "deferred"
        return d


@dataclass
class SaleParams:
    """Parameters for tracking a manual sale event."""
    customer_id: str
    """Your app's unique user ID (must match the ID used in track_lead)."""

    amount: int
    """Sale amount in the smallest currency unit (cents). E.g. 5900 for €59."""

    currency: str = "EUR"
    """ISO 4217 currency code."""

    event_name: str = "Purchase"
    """Name of the conversion event."""

    click_id: str = ""
    """Traaaction click ID (optional if customer was already tracked via lead)."""

    def to_dict(self) -> dict:
        return {
            "customerExternalId": self.customer_id,
            "amount": self.amount,
            "currency": self.currency,
            "eventName": self.event_name,
            "clickId": self.click_id,
        }


# ---------------------------------------------------------------------------
# Management API models (sync, trac_live_xxx)
# ---------------------------------------------------------------------------

@dataclass
class LinkParams:
    """Parameters for creating or updating a short link."""
    destination: str
    """Target URL (required)."""

    mission_id: Optional[str] = None
    """Associate with a specific mission."""

    seller_id: Optional[str] = None
    """Associate with a specific seller."""

    campaign_id: Optional[str] = None
    """Associate with a marketing campaign."""

    folder_id: Optional[str] = None
    """Place in a specific folder."""

    channel: Optional[str] = None
    """Traffic channel label (e.g. 'email', 'twitter', 'instagram')."""

    slug: Optional[str] = None
    """Custom slug for the short link (auto-generated if omitted)."""

    def to_dict(self) -> dict:
        d: dict = {"destination": self.destination}
        if self.mission_id is not None:
            d["mission_id"] = self.mission_id
        if self.seller_id is not None:
            d["seller_id"] = self.seller_id
        if self.campaign_id is not None:
            d["campaign_id"] = self.campaign_id
        if self.folder_id is not None:
            d["folder_id"] = self.folder_id
        if self.channel is not None:
            d["channel"] = self.channel
        if self.slug is not None:
            d["slug"] = self.slug
        return d


@dataclass
class MissionFilter:
    """Filters for listing missions."""
    status: Optional[str] = None
    """Filter by mission status: 'ACTIVE', 'DRAFT', 'PAUSED', 'ARCHIVED'."""

    page: int = 1
    """Page number."""

    limit: int = 50
    """Items per page (max 100)."""

    def to_params(self) -> dict:
        return {k: v for k, v in {
            "status": self.status,
            "page": self.page,
            "limit": self.limit,
        }.items() if v is not None}


@dataclass
class AnalyticsParams:
    """Parameters for the analytics retrieve call."""
    interval: str = "30d"
    """Shorthand: '7d', '30d' (default), '90d'."""

    date_from: Optional[str] = None
    """Start date as YYYY-MM-DD. Overrides interval if provided."""

    date_to: Optional[str] = None
    """End date as YYYY-MM-DD. Overrides interval if provided."""

    def to_params(self) -> dict:
        return {k: v for k, v in {
            "interval": self.interval,
            "date_from": self.date_from,
            "date_to": self.date_to,
        }.items() if v is not None}
