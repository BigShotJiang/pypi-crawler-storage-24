"""
CustomersAPI — access customers attributed to your workspace.

Synchronous. Requires a secret key (trac_live_xxx).
"""

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ._client import TraaactionClient


class CustomersAPI:
    """
    Access customers attributed to your workspace — via ``Traaaction().customers``.

    Customers are created when a user converts via a tracked link (click → lead or sale).
    First-click attribution is permanent — customers are never re-attributed.

    All methods are **synchronous** and read-only.
    Requires a secret key (``trac_live_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def list(
        self,
        page: int = 1,
        limit: int = 50,
        external_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List customers attributed to this workspace.

        Args:
            page:        Page number (default: 1).
            limit:       Items per page, max 100 (default: 50).
            external_id: Filter by your app's user ID (exact match).

        Returns:
            ``{"data": [...], "meta": {"total": int, "page": int, "limit": int}}``
        """
        return self._client._management_request(
            "GET",
            "/api/v1/customers",
            params={"page": page, "limit": limit, "external_id": external_id},
        )

    def get(self, customer_id: str) -> Dict[str, Any]:
        """
        Get a single customer by ID or external ID.

        Supports lookup by both:
        - Internal Traaaction customer ID
        - Your app's user ID (``external_id``)

        Args:
            customer_id: Either the internal ID or your app's ``external_id``.

        Returns:
            The customer object with attribution info (``link_id``, ``affiliate_id``).
        """
        return self._client._management_request("GET", f"/api/v1/customers/{customer_id}")
