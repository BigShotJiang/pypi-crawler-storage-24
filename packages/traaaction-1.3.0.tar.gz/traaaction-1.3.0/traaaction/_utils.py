"""
Shared utilities for extracting trac_click_id from HTTP requests.

Priority order (mirrors trac.js client-side logic):
  1. Cookie 'trac_click_id'  — set by trac.js (root-domain scoped)
  2. Cookie 'clk_id'         — set by Traaaction middleware on link redirect
  3. URL/query param 'trac_click_id' — injected by data-outbound-domains

This module has zero external dependencies — it works with any framework.
"""

from __future__ import annotations

from typing import Optional
from urllib.parse import urlparse, parse_qs

CLICK_ID_COOKIE = "trac_click_id"
CLICK_ID_COOKIE_ALT = "clk_id"
CLICK_ID_PARAM = "trac_click_id"


def extract_click_id(
    cookies: Optional[dict] = None,
    params: Optional[dict] = None,
) -> Optional[str]:
    """
    Extract trac_click_id following the canonical priority order.

    Args:
        cookies: Dict of cookie name → value (e.g. request.COOKIES in Django,
                 request.cookies in Flask, request.cookies in FastAPI).
        params:  Dict of query parameter name → value (e.g. request.GET in Django,
                 request.args in Flask, dict(request.query_params) in FastAPI).

    Returns:
        The click ID string, or None if not found in either source.

    Example::

        from traaaction._utils import extract_click_id

        click_id = extract_click_id(
            cookies=request.COOKIES,
            params=request.GET,
        )
    """
    # 1. Cookie trac_click_id (set by trac.js with root-domain scope)
    if cookies:
        value = cookies.get(CLICK_ID_COOKIE)
        if value:
            return str(value)

        # 2. Fallback cookie clk_id (set by middleware on link redirect)
        value = cookies.get(CLICK_ID_COOKIE_ALT)
        if value:
            return str(value)

    # 3. URL query param (injected by data-outbound-domains or middleware redirect)
    if params:
        value = params.get(CLICK_ID_PARAM)
        if value:
            # params can be a dict of str or list-of-str (Django QueryDict style)
            if isinstance(value, list):
                return str(value[0]) if value else None
            return str(value)

    return None


def extract_click_id_from_cookie_header(cookie_header: str) -> Optional[str]:
    """
    Parse a raw Cookie header string and extract trac_click_id.

    Useful when you only have access to raw headers (e.g. WSGI environ).

    Args:
        cookie_header: Raw Cookie header value, e.g.
                       "trac_click_id=clk_xxx; other=val"

    Returns:
        The click ID string, or None.
    """
    if not cookie_header:
        return None

    cookies: dict[str, str] = {}
    for part in cookie_header.split(";"):
        part = part.strip()
        if "=" in part:
            name, _, value = part.partition("=")
            cookies[name.strip()] = value.strip()

    return extract_click_id(cookies=cookies)
