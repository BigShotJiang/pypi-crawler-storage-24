"""
LinksAPI — create and manage affiliate short links.

Synchronous. Requires a secret key (trac_live_xxx).
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ._client import TraaactionClient


class LinksAPI:
    """
    Manage marketing short links — accessed via ``Traaaction().links``.

    All methods are **synchronous** and block until the API responds.
    Requires a secret key (``trac_live_xxx``).
    """

    def __init__(self, client: "TraaactionClient") -> None:
        self._client = client

    def list(
        self,
        page: int = 1,
        limit: int = 50,
        mission_id: Optional[str] = None,
        seller_id: Optional[str] = None,
        campaign_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List marketing short links for this workspace.

        Args:
            page:        Page number (default: 1).
            limit:       Items per page, max 100 (default: 50).
            mission_id:  Filter by mission ID.
            seller_id:   Filter by seller ID.
            campaign_id: Filter by campaign ID.

        Returns:
            ``{"data": [...], "meta": {"total": int, "page": int, "limit": int}}``
        """
        return self._client._management_request(
            "GET",
            "/api/v1/links",
            params={
                "page": page,
                "limit": limit,
                "mission_id": mission_id,
                "seller_id": seller_id,
                "campaign_id": campaign_id,
            },
        )

    def create(
        self,
        destination: str,
        mission_id: Optional[str] = None,
        seller_id: Optional[str] = None,
        campaign_id: Optional[str] = None,
        folder_id: Optional[str] = None,
        channel: Optional[str] = None,
        slug: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new marketing short link.

        Args:
            destination:  Target URL (required).
            mission_id:   Associate with a specific mission.
            seller_id:    Associate with a specific seller.
            campaign_id:  Associate with a marketing campaign.
            folder_id:    Place in a specific folder.
            channel:      Traffic channel label (e.g. ``"email"``, ``"twitter"``).
            slug:         Custom slug (auto-generated if omitted).

        Returns:
            The created link object.
        """
        body: Dict[str, Any] = {"destination": destination}
        if mission_id is not None:
            body["mission_id"] = mission_id
        if seller_id is not None:
            body["seller_id"] = seller_id
        if campaign_id is not None:
            body["campaign_id"] = campaign_id
        if folder_id is not None:
            body["folder_id"] = folder_id
        if channel is not None:
            body["channel"] = channel
        if slug is not None:
            body["slug"] = slug

        return self._client._management_request("POST", "/api/v1/links", json_body=body)

    def get(self, link_id: str) -> Dict[str, Any]:
        """
        Get a single link by ID.

        Args:
            link_id: The link's unique ID.

        Returns:
            The link object.
        """
        return self._client._management_request("GET", f"/api/v1/links/{link_id}")

    def update(
        self,
        link_id: str,
        destination: Optional[str] = None,
        campaign_id: Optional[str] = None,
        folder_id: Optional[str] = None,
        channel: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing link.

        Args:
            link_id:      The link's unique ID.
            destination:  New target URL.
            campaign_id:  New campaign ID (pass ``None`` to unset).
            folder_id:    New folder ID (pass ``None`` to unset).
            channel:      New channel label.

        Returns:
            The updated link object.
        """
        body: Dict[str, Any] = {}
        if destination is not None:
            body["destination"] = destination
        if campaign_id is not None:
            body["campaign_id"] = campaign_id
        if folder_id is not None:
            body["folder_id"] = folder_id
        if channel is not None:
            body["channel"] = channel

        return self._client._management_request("PATCH", f"/api/v1/links/{link_id}", json_body=body)

    def delete(self, link_id: str) -> Dict[str, Any]:
        """
        Delete a link.

        Args:
            link_id: The link's unique ID.

        Returns:
            ``{"data": {"deleted": True, "id": "..."}}``
        """
        return self._client._management_request("DELETE", f"/api/v1/links/{link_id}")
