# reacnet-md-tools

Small, dependency-light helpers around reactive MD post-processing workflows, built to make **ReacNetGenerator** runs more repeatable.

Design goals:
- minimal dependencies
- safe subprocess execution (no `shell=True`)
- clear, agent-friendly CLIs

## Install / run

### Run without installing (recommended)

```bash
uvx --from reacnet-md-tools rng-pipeline --help
```

### Install into an environment

```bash
python -m pip install -U reacnet-md-tools
```

## Commands

### `rng-xs2x`

Convert a LAMMPS dump with scaled coordinates `xs/ys/zs` into absolute coordinates `x/y/z`.

```bash
rng-xs2x -i in.lammpstrj -o out.lammpstrj
```

Supported boxes:
- orthorhombic
- triclinic (tilt factors `xy xz yz`)

### `rng-infer-atomnames`

Infer `reacnetgenerator -a` atomname order from a LAMMPS data file by parsing the `Masses` section and matching masses to common elements.

```bash
rng-infer-atomnames path/to/system.data
# -> e.g. "C H O Cl"
```

### `rng-pipeline`

End-to-end helper:
1. If the input is a LAMMPS dump and uses `xs/ys/zs`, convert it to `x/y/z` into `out/<basename>/dump_with_xyz.lammpstrj`.
2. If `--atomnames` is not provided, try to infer them from a nearby LAMMPS data file (or ask you to pick one with `--pick-data`).
3. Run ReacNetGenerator, writing everything into `out/<basename>/`.

Example:

```bash
rng-pipeline \
  --input /path/to/traj.lammpstrj \
  --type dump \
  --outroot out \
  --pick-data \
  --stepinterval 10 \
  --maxspecies 50
```

**ReacNetGenerator runner selection**
- default `--runner auto`:
  - use local `reacnetgenerator` if found on PATH
  - otherwise run via: `uvx --from reacnetgenerator reacnetgenerator ...`

## Development

Build (wheel + sdist):

```bash
python -m pip install -U build
python -m build
```

## License

MIT (see `LICENSE`).
