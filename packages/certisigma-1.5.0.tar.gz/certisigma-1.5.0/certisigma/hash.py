"""
CertiSigma SDK — SHA-256 hashing utilities.

Standalone functions for computing SHA-256 hashes in the format expected
by the CertiSigma attestation API (64-char lowercase hex).

Usage:
    from certisigma import hash_file, hash_bytes

    file_hash = hash_file("/path/to/document.pdf")
    data_hash = hash_bytes(b"raw content")

    # Then attest or verify
    client.attest(file_hash)
    client.verify(data_hash)
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Union

CHUNK_SIZE = 8192


def hash_file(path: Union[str, Path]) -> str:
    """
    Compute the SHA-256 hash of a file.

    Reads the file in 8 KiB chunks for constant memory usage regardless of
    file size.

    Args:
        path: Filesystem path to the file.

    Returns:
        64-character lowercase hex string (SHA-256 digest).

    Raises:
        FileNotFoundError: If the file does not exist.
        IsADirectoryError: If the path is a directory.
    """
    sha = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
            sha.update(chunk)
    return sha.hexdigest()


def hash_bytes(data: Union[bytes, bytearray, memoryview]) -> str:
    """
    Compute the SHA-256 hash of raw bytes.

    Args:
        data: Bytes-like object to hash.

    Returns:
        64-character lowercase hex string (SHA-256 digest).

    Raises:
        TypeError: If data is not a bytes-like object.
    """
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError(f"Expected bytes-like object, got {type(data).__name__}")
    return hashlib.sha256(data).hexdigest()
