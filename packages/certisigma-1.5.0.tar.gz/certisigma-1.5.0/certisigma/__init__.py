"""CertiSigma Python SDK — Attestation & Verification client."""

from .client import CertiSigmaClient, AsyncCertiSigmaClient
from .exceptions import CertiSigmaError, AuthenticationError, RateLimitError, QuotaExceededError
from .hash import hash_file, hash_bytes
from .evidence import get_blockchain_url, save_ots_proof

__version__ = "1.5.0"
__all__ = [
    "CertiSigmaClient",
    "AsyncCertiSigmaClient",
    "CertiSigmaError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "hash_file",
    "hash_bytes",
    "get_blockchain_url",
    "save_ots_proof",
]
