"""CertiSigma SDK — Exception hierarchy."""


class CertiSigmaError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, response: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthenticationError(CertiSigmaError):
    """Invalid or missing API key (401)."""
    pass


class RateLimitError(CertiSigmaError):
    """Rate limit exceeded (429). Check retry_after attribute."""

    def __init__(self, message: str, retry_after: int = 60, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class QuotaExceededError(CertiSigmaError):
    """Monthly quota exhausted (429)."""
    pass


class NotFoundError(CertiSigmaError):
    """Resource not found (404)."""
    pass


class ValidationError(CertiSigmaError):
    """Invalid request data (400/422)."""
    pass
