"""Tests for certisigma.evidence utilities."""
import base64
import tempfile
from pathlib import Path

import pytest

from certisigma.evidence import get_blockchain_url, save_ots_proof
from certisigma.types import EvidenceResult


SAMPLE_T2 = {
    "dailyRoot": "aabbcc",
    "t1ToT2Proof": [],
    "bitcoinBlockHeight": 850123,
    "bitcoinBlockHash": "00000000000000000002a7c4aabbccdd",
    "bitcoinTxid": "d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9",
    "confirmedAt": "2025-06-15T14:20:00Z",
    "otsProof": base64.b64encode(b"OTS_PROOF_BINARY_DATA").decode(),
}


class TestGetBlockchainUrl:
    def test_block_url_from_dataclass(self):
        ev = EvidenceResult(hash_hex="aabb", level="T2", t2=SAMPLE_T2)
        url = get_blockchain_url(ev)
        assert url == "https://mempool.space/block/00000000000000000002a7c4aabbccdd"

    def test_tx_url_from_dataclass(self):
        ev = EvidenceResult(hash_hex="aabb", level="T2", t2=SAMPLE_T2)
        url = get_blockchain_url(ev, type="tx")
        assert url == "https://mempool.space/tx/d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9"

    def test_block_url_from_dict(self):
        ev = {"hash_hex": "aabb", "level": "T2", "t2": SAMPLE_T2}
        url = get_blockchain_url(ev)
        assert url == "https://mempool.space/block/00000000000000000002a7c4aabbccdd"

    def test_tx_url_from_dict(self):
        ev = {"hash_hex": "aabb", "level": "T2", "t2": SAMPLE_T2}
        url = get_blockchain_url(ev, type="tx")
        assert url == "https://mempool.space/tx/d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9"

    def test_returns_none_when_no_t2(self):
        ev = EvidenceResult(hash_hex="aabb", level="T1", t2=None)
        assert get_blockchain_url(ev) is None
        assert get_blockchain_url(ev, type="tx") is None

    def test_returns_none_from_dict_no_t2(self):
        ev = {"hash_hex": "aabb", "level": "T1", "t2": None}
        assert get_blockchain_url(ev) is None

    def test_returns_none_when_missing_block_hash(self):
        t2 = {**SAMPLE_T2, "bitcoinBlockHash": None}
        ev = EvidenceResult(hash_hex="aabb", level="T2", t2=t2)
        assert get_blockchain_url(ev) is None

    def test_returns_none_when_missing_txid(self):
        t2 = {**SAMPLE_T2, "bitcoinTxid": None}
        ev = EvidenceResult(hash_hex="aabb", level="T2", t2=t2)
        assert get_blockchain_url(ev, type="tx") is None


class TestSaveOtsProof:
    def test_saves_proof_from_dataclass(self, tmp_path):
        ev = EvidenceResult(hash_hex="aabb", level="T2", t2=SAMPLE_T2)
        out = tmp_path / "test.ots"
        assert save_ots_proof(ev, out) is True
        assert out.read_bytes() == b"OTS_PROOF_BINARY_DATA"

    def test_saves_proof_from_dict(self, tmp_path):
        ev = {"hash_hex": "aabb", "level": "T2", "t2": SAMPLE_T2}
        out = tmp_path / "test.ots"
        assert save_ots_proof(ev, str(out)) is True
        assert out.read_bytes() == b"OTS_PROOF_BINARY_DATA"

    def test_returns_false_when_no_t2(self, tmp_path):
        ev = EvidenceResult(hash_hex="aabb", level="T1", t2=None)
        out = tmp_path / "test.ots"
        assert save_ots_proof(ev, out) is False
        assert not out.exists()

    def test_returns_false_when_no_ots_proof(self, tmp_path):
        t2 = {**SAMPLE_T2, "otsProof": None}
        ev = EvidenceResult(hash_hex="aabb", level="T2", t2=t2)
        out = tmp_path / "test.ots"
        assert save_ots_proof(ev, out) is False
        assert not out.exists()

    def test_overwrites_existing_file(self, tmp_path):
        out = tmp_path / "test.ots"
        out.write_bytes(b"old data")
        ev = EvidenceResult(hash_hex="aabb", level="T2", t2=SAMPLE_T2)
        save_ots_proof(ev, out)
        assert out.read_bytes() == b"OTS_PROOF_BINARY_DATA"
