import typing
import logging
from typing import TYPE_CHECKING

from supersql.engines.connection import IConnection, IEngine, connectable, disconnectable
from supersql.utils.vendor_deps import validate_vendor_dependencies

# Validate dependencies at module level
validate_vendor_dependencies("postgres")

import asyncpg

logger = logging.getLogger('supersql.engines.postgres')


if(TYPE_CHECKING):
    from supersql.core.query import Query

CONNECTED_MESSAGE = "A connection already exists"
DISCONNECTED_MESSAGE = "Not connection found to database"

USER, PASSWORD, HOST, PORT, DATABASE = 'user', 'password', 'host', 'port', 'database'


class EngineConstructorArgs(typing.TypedDict):
    user: str
    password: str
    port: int
    database: str
    host: str
    use_ssl: bool
    pool_min_size: int
    pool_max_size: int
    pool_timeout: int
    pool_recycle: int


class Engine(IEngine):
    def __init__(self, query, **kwargs: EngineConstructorArgs):
        self._query = query
        self._config = kwargs
        self.pool = None

    async def connect(self) -> None:
        if self.pool is not None:
            raise RuntimeError(CONNECTED_MESSAGE)
        logger.debug("Creating PostgreSQL connection pool")
        
        pool_min_size = self._config.get('pool_min_size', 10)
        pool_max_size = self._config.get('pool_max_size', 10)
        pool_timeout = self._config.get('pool_timeout', 60)
        pool_recycle = self._config.get('pool_recycle', -1)
        
        _excluded_keys = {'pool_', 'use_ssl'}
        connect_kwargs = {k: v for k, v in self._config.items() if not k.startswith('pool_') and k not in _excluded_keys}
        
        pool_kwargs = {
            'min_size': pool_min_size,
            'max_size': pool_max_size,
            'timeout': pool_timeout,
        }
        
        if pool_recycle > 0:
            pool_kwargs['max_inactive_connection_lifetime'] = pool_recycle

        try:
            self.pool = await asyncpg.create_pool(**connect_kwargs, **pool_kwargs)
            logger.debug("PostgreSQL connection pool created successfully")
        except Exception as e:
            logger.error(f"Failed to create PostgreSQL connection pool: {e}")
            raise

    async def disconnect(self) -> None:
        if self.pool is None:
            raise RuntimeError(DISCONNECTED_MESSAGE)
        logger.debug("Closing PostgreSQL connection pool")
        try:
            await self.pool.close()
            self.pool = None
            logger.debug("PostgreSQL connection pool closed")
        except Exception as e:
            logger.error(f"Failed to close PostgreSQL connection pool: {e}")
            raise

    @property
    def parameter_placeholder(self) -> str:
        return "$%d"

    async def execute_query(self, query: 'Query') -> typing.Any:
        async with self.pool.acquire() as connection:
            sql = query.build()
            if query._consequence == 'DQL':
                if query._unsafe:
                    return await connection.fetch(sql)
                return await connection.fetch(sql, *query.args)
            elif query._consequence == 'DML':
                if query._unsafe:
                    return await connection.fetchval(sql)
                return await connection.fetchval(sql, *query.args)
            else:
                if query._unsafe:
                    return await connection.execute(sql)
                return await connection.execute(sql, *query.args)

    def connection(self) -> "Connection":
        return Connection(self.pool)


class Connection(IConnection):
    def __init__(self, pool):
        self._pool = pool
        self._connection = None

    @connectable
    async def begin(self):
        self._connection = await self._pool.acquire()
        return self._connection

    @disconnectable
    async def done(self):
        await self._pool.release(self._connection)
        self._connection = None

    @disconnectable
    async def execute(self, query: 'Query') -> typing.Any:
        sql = query.build()
        if query._unsafe:
            return await self._connection.execute(sql)
        return await self._connection.execute(sql, *query.args)

    @disconnectable
    async def executemany(self, queries: typing.List['Query']) -> typing.Any:
        for query in queries:
            sql = query.build()
            if query._unsafe:
                await self._connection.execute(sql)
            else:
                await self._connection.execute(sql, *query.args)

    @disconnectable
    async def fetchall(self, query: 'Query') -> typing.List[typing.Mapping]:
        sql = query.build()
        if query._unsafe:
            return await self._connection.fetch(sql)
        return await self._connection.fetch(sql, *query.args)

    @disconnectable
    async def fetchmany(self, query: 'Query', limit: int) -> typing.Any:
        sql = query.build()
        if query._unsafe:
            rows = await self._connection.fetch(sql)
        else:
            rows = await self._connection.fetch(sql, *query.args)
        return rows[:limit]

    @disconnectable
    async def release(self) -> None:
        if self._connection:
            await self._pool.release(self._connection)
            self._connection = None

    @disconnectable
    async def rowcount(self, query: 'Query') -> int:
        sql = query.build()
        if query._unsafe:
            result = await self._connection.execute(sql)
        else:
            result = await self._connection.execute(sql, *query.args)
        # asyncpg execute returns a status string like 'UPDATE 3'
        parts = result.split()
        if len(parts) > 1 and parts[-1].isdigit():
            return int(parts[-1])
        return 0
