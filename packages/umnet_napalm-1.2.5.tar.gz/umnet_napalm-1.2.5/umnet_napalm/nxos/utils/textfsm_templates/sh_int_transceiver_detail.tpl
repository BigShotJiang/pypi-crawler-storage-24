Value Filldown INTERFACE (Ethernet\S+)
Value Filldown TYPE (\S+)
Value Filldown VENDOR (\S+)
Value Filldown PN (\S+)
Value Filldown SN (\w+)
Value Filldown REV (\w+)
Value CHANNEL (\d+)
Value CURRENT ([0-9\.\-]+)
Value TX ([0-9\.\-]+)
Value RX ([0-9\.\-]+)

Start
  ^${INTERFACE}$$
  ^\s+type is ${TYPE}
  ^\s+name is ${VENDOR}
  ^\s+part number is ${PN}
  ^\s+serial number is ${SN}
  ^\s+revision is ${REV}
  ^DOM is not supported -> Record
  ^Lane Number:${CHANNEL}
  ^\s+Current\s+(${CURRENT} mA|N\/A)
  ^\s+Tx Power\s+(${TX} dBm|N\/A)
  ^\s+Rx Power\s+(${RX} dBm|N\/A) -> Record


#Ethernet1/1
#    transceiver is present
#    type is QSFP-100G-SR4
#    name is FS
#    part number is QSFP28-SR4-100G
#    revision is 04
#    serial number is C2208493844
#    nominal bitrate is 25500 MBit/sec
#    Link length supported for 50/125um OM3 fiber is 70 m
#    cisco id is 17
#    cisco extended id number is 220
#
#Lane Number:1 Network Lane
#           SFP Detail Diagnostics Information (internal calibration)
#  ----------------------------------------------------------------------------
#                Current              Alarms                  Warnings
#                Measurement     High        Low         High          Low
#  ----------------------------------------------------------------------------
#  Temperature   41.96 C        75.00 C     -5.00 C     70.00 C        0.00 C
#  Voltage        3.28 V         3.63 V      2.97 V      3.46 V        3.13 V
#  Current        7.33 mA       13.00 mA     3.00 mA    11.00 mA       5.00 mA
#  Tx Power      -1.10 dBm       4.99 dBm  -10.00 dBm    2.99 dBm     -8.01 dBm
#  Rx Power       0.37 dBm       3.40 dBm  -14.00 dBm    2.39 dBm    -11.00 dBm
#  Transmit Fault Count = 0
#  ----------------------------------------------------------------------------
#  Note: ++  high-alarm; +  high-warning; --  low-alarm; -  low-warning
#
#Lane Number:2 Network Lane
#           SFP Detail Diagnostics Information (internal calibration)
#  ----------------------------------------------------------------------------
#                Current              Alarms                  Warnings
#                Measurement     High        Low         High          Low
#  ----------------------------------------------------------------------------
#  Temperature   41.96 C        75.00 C     -5.00 C     70.00 C        0.00 C
#  Voltage        3.28 V         3.63 V      2.97 V      3.46 V        3.13 V
#  Current        7.39 mA       13.00 mA     3.00 mA    11.00 mA       5.00 mA
#  Tx Power      -1.06 dBm       4.99 dBm  -10.00 dBm    2.99 dBm     -8.01 dBm
#  Rx Power      -0.48 dBm       3.40 dBm  -14.00 dBm    2.39 dBm    -11.00 dBm
#  Transmit Fault Count = 0
#  ----------------------------------------------------------------------------
#  Note: ++  high-alarm; +  high-warning; --  low-alarm; -  low-warning
# ...