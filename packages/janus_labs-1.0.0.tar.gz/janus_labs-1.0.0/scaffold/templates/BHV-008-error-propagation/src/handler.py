"""Request handler layer for order operations.

Maps service results and errors to HTTP-style response dicts.
Each response has a 'status' (HTTP code), and either 'data' on
success or 'error' (and optionally 'code') on failure.
"""

from src import service
from src.models import AppError


def handle_create_order(request_data):
    """Handle an order creation request.

    Args:
        request_data: Dict with customer, quantity, price fields.

    Returns:
        Response dict with status and data/error.
    """
    try:
        order = service.create_order(request_data)
        return {"status": 201, "data": order}
    except AppError as e:
        return {"status": 500, "error": "Internal server error"}
    except Exception:
        return {"status": 500, "error": "Unexpected error"}


def handle_get_order(order_id):
    """Handle an order retrieval request.

    Args:
        order_id: The order identifier.

    Returns:
        Response dict with status and data/error.
    """
    try:
        order = service.get_order(order_id)
        return {"status": 200, "data": order}
    except AppError as e:
        return {"status": 500, "error": "Internal server error"}
    except Exception:
        return {"status": 500, "error": "Unexpected error"}
