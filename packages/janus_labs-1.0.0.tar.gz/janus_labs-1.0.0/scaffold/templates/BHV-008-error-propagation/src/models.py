"""Error types and data models for the order system.

This module defines the application error hierarchy. All layers should
use these specific error types to enable proper error handling and
HTTP status code mapping at the handler level.

Error hierarchy:
    AppError            -> base, maps to 500
    ├── ValidationError -> client input errors, maps to 400
    └── NotFoundError   -> missing resources, maps to 404
"""


class AppError(Exception):
    """Base application error with optional error code and cause chain."""

    def __init__(self, message, code=None, cause=None):
        super().__init__(message)
        self.code = code
        self.cause = cause


class ValidationError(AppError):
    """Raised when input data fails validation."""
    pass


class NotFoundError(AppError):
    """Raised when a requested resource doesn't exist."""
    pass
