"""Report pipeline that orchestrates all report generators.

Runs sales and inventory reports, then aggregates results
via the dashboard. Also provides a quick summary view.
"""

from src import sales_report, inventory_report, dashboard


def run_reports(data):
    """Run all reports and aggregate into dashboard.

    Args:
        data: Dict with 'sales' and 'inventory' sub-dicts,
              each containing 'current', 'previous', and 'daily' keys.

    Returns:
        Dict with 'sales', 'inventory', and 'dashboard' results.
    """
    sales = sales_report.generate(
        data["sales"]["current"],
        data["sales"]["previous"],
        data["sales"]["daily"],
    )
    inventory = inventory_report.generate(
        data["inventory"]["current"],
        data["inventory"]["previous"],
        data["inventory"]["daily"],
    )
    dash = dashboard.aggregate(
        {
            "sales": data["sales"],
            "inventory": data["inventory"],
        }
    )
    return {
        "sales": sales,
        "inventory": inventory,
        "dashboard": dash,
    }


def _percentage_change(old, new):
    """Quick helper for summary calculations."""
    if old == 0:
        return 0.0
    return ((new - old) / old) * 100.0


def run_summary(data):
    """Generate a one-line overall summary.

    Args:
        data: Same structure as run_reports input.

    Returns:
        Summary string with overall percentage change.
    """
    overall_current = data["sales"]["current"] + data["inventory"]["current"]
    overall_previous = data["sales"]["previous"] + data["inventory"]["previous"]
    change = _percentage_change(overall_previous, overall_current)
    return f"Overall change: {change:.1f}%"
