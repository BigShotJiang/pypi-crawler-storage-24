"""Metric utilities for the reporting system.

This module provides shared data types for metric calculations.
Report generators use their own calculation logic tailored
to each report's specific needs.
"""

from collections import namedtuple

MetricResult = namedtuple("MetricResult", ["value", "label", "trend"])
