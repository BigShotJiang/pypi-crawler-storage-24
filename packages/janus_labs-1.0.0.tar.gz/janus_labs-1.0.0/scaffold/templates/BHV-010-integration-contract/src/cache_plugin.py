"""Caching plugin for processed results.

Stores and retrieves cached values by key. Cache entries
have a time-to-live (TTL) that controls expiration.
"""

from src.plugin_interface import Plugin

_cache = {}


class CachePlugin(Plugin):

    def execute(self, data):
        """Check cache for key or store new value.

        Args:
            data: Dict with optional 'key' and 'value' fields.

        Returns:
            Dict with plugin name, cache hit status, data, and TTL.
        """
        key = data.get("key")

        if key and key in _cache:
            return {"plugin": "cache", "hit": True, "data": _cache[key], "ttl": 300}

        if key:
            _cache[key] = data.get("value")

        return {"plugin": "cache", "hit": False, "data": None, "ttl": 300}
