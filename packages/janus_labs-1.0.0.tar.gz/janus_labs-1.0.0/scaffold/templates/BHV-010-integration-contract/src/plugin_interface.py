"""Plugin interface for the extensible processing system.

All plugins must implement the execute() method to process data.
The PluginManager orchestrates plugin execution and manages
configuration that plugins may need for their operations.
"""

from abc import ABC, abstractmethod


class Plugin(ABC):
    """Base class for all plugins."""

    @abstractmethod
    def execute(self, data):
        """Process the given data.

        Args:
            data: Dict of data to process.

        Returns:
            Dict with processing result including 'plugin' key.
        """
        pass

    def get_name(self):
        """Return the plugin class name for identification."""
        return self.__class__.__name__
