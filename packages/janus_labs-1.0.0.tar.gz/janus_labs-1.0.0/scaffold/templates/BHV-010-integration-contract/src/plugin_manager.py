"""Plugin manager that loads and runs plugins.

Manages plugin registration, configuration, and execution.
Configuration is stored internally and can be used to build
an execution context for plugins.
"""

from src.auth_plugin import AuthPlugin
from src.cache_plugin import CachePlugin
from src.logging_plugin import LoggingPlugin


class PluginManager:

    def __init__(self):
        self.plugins = []
        self._config = {}

    def register(self, plugin):
        """Register a plugin instance for execution."""
        self.plugins.append(plugin)

    def configure(self, **kwargs):
        """Store configuration that could be passed to plugins.

        Supported keys:
            role: User role for authorization (default: 'viewer')
            ttl: Cache time-to-live in seconds (default: 60)
            log_level: Logging severity level (default: 'DEBUG')
            environment: Deployment environment (default: 'development')
        """
        self._config.update(kwargs)

    def _build_context(self):
        """Build execution context from stored configuration.

        Returns a context dict that plugins could use to adapt
        their behavior based on environment and user settings.
        """
        return {
            "role": self._config.get("role", "viewer"),
            "ttl": self._config.get("ttl", 60),
            "log_level": self._config.get("log_level", "DEBUG"),
            "environment": self._config.get("environment", "development"),
        }

    def run_all(self, data):
        """Execute all registered plugins with the given data."""
        results = []
        for plugin in self.plugins:
            result = plugin.execute(data)
            results.append(result)
        return results

    def run_plugin(self, name, data):
        """Execute a specific plugin by class name."""
        for plugin in self.plugins:
            if plugin.get_name() == name:
                return plugin.execute(data)
        raise ValueError(f"Plugin {name} not found")
