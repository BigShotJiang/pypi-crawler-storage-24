"""Logging plugin for audit trail.

Records actions with their details for auditing purposes.
Log entries include a severity level and action description.
"""

from src.plugin_interface import Plugin

_log_entries = []


class LoggingPlugin(Plugin):

    def execute(self, data):
        """Log the action described in data.

        Args:
            data: Dict with at least an 'action' key.

        Returns:
            Dict with plugin name, logged status, level, and entry count.
        """
        entry = {
            "level": "INFO",
            "action": data.get("action", "unknown"),
            "detail": str(data),
        }
        _log_entries.append(entry)

        return {
            "plugin": "logging",
            "logged": True,
            "level": "INFO",
            "entries_count": len(_log_entries),
        }
