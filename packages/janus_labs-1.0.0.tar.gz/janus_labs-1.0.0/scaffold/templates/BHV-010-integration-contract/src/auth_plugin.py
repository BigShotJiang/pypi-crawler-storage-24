"""Authentication and authorization plugin.

Checks whether the current user is authorized to perform
the requested action. Authorization decisions are based on
user identity matching.
"""

from src.plugin_interface import Plugin


class AuthPlugin(Plugin):

    def execute(self, data):
        """Check authorization for the given request data.

        Args:
            data: Dict with at least a 'user' key.

        Returns:
            Dict with plugin name, user, allowed status, and role.
        """
        user = data.get("user", "anonymous")

        if user == "admin":
            allowed = True
        else:
            allowed = False

        return {
            "plugin": "auth",
            "user": user,
            "allowed": allowed,
            "role": "unknown",
        }
