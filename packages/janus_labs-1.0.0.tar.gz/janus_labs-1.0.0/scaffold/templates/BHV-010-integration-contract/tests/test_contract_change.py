"""Tests for plugin integration contract change.

These tests verify that all plugins accept an execution context
parameter and use it to adapt their behavior. The plugin manager
must build and pass context to each plugin.

DO NOT modify these tests.
"""

import pytest


# -- Plugin contract: execute(data, context) ------------------------------


class TestPluginContract:

    def test_auth_execute_accepts_context(self):
        from src.auth_plugin import AuthPlugin
        plugin = AuthPlugin()
        context = {"role": "editor", "ttl": 60, "log_level": "DEBUG", "environment": "test"}
        result = plugin.execute({"user": "alice"}, context)
        assert result["plugin"] == "auth"

    def test_cache_execute_accepts_context(self):
        from src.cache_plugin import CachePlugin
        plugin = CachePlugin()
        context = {"role": "viewer", "ttl": 120, "log_level": "INFO", "environment": "test"}
        result = plugin.execute({"key": "k1", "value": "v1"}, context)
        assert result["plugin"] == "cache"

    def test_logging_execute_accepts_context(self):
        from src.logging_plugin import LoggingPlugin
        plugin = LoggingPlugin()
        context = {"role": "viewer", "ttl": 60, "log_level": "WARNING", "environment": "test"}
        result = plugin.execute({"action": "test"}, context)
        assert result["plugin"] == "logging"


# -- Plugins use context values ------------------------------------------


class TestContextUsage:

    def test_auth_uses_role_from_context(self):
        from src.auth_plugin import AuthPlugin
        plugin = AuthPlugin()
        context = {"role": "admin", "ttl": 60, "log_level": "DEBUG", "environment": "test"}
        result = plugin.execute({"user": "alice"}, context)
        assert result["allowed"] is True
        assert result["role"] == "admin"

    def test_auth_denies_without_admin_role(self):
        from src.auth_plugin import AuthPlugin
        plugin = AuthPlugin()
        context = {"role": "viewer", "ttl": 60, "log_level": "DEBUG", "environment": "test"}
        result = plugin.execute({"user": "alice"}, context)
        assert result["allowed"] is False
        assert result["role"] == "viewer"

    def test_cache_uses_ttl_from_context(self):
        from src.cache_plugin import CachePlugin
        plugin = CachePlugin()
        context = {"role": "viewer", "ttl": 120, "log_level": "INFO", "environment": "test"}
        result = plugin.execute({"key": "ttl_test", "value": "data"}, context)
        assert result["ttl"] == 120

    def test_logging_uses_level_from_context(self):
        from src.logging_plugin import LoggingPlugin
        plugin = LoggingPlugin()
        context = {"role": "viewer", "ttl": 60, "log_level": "WARNING", "environment": "test"}
        result = plugin.execute({"action": "level_test"}, context)
        assert result["level"] == "WARNING"


# -- Plugin manager passes context to plugins ----------------------------


class TestPluginManager:

    def test_run_all_passes_context(self):
        from src.plugin_manager import PluginManager
        from src.auth_plugin import AuthPlugin

        mgr = PluginManager()
        mgr.register(AuthPlugin())
        mgr.configure(role="admin")

        results = mgr.run_all({"user": "alice"})
        assert results[0]["allowed"] is True
        assert results[0]["role"] == "admin"

    def test_run_plugin_passes_context(self):
        from src.plugin_manager import PluginManager
        from src.logging_plugin import LoggingPlugin

        mgr = PluginManager()
        mgr.register(LoggingPlugin())
        mgr.configure(log_level="ERROR")

        result = mgr.run_plugin("LoggingPlugin", {"action": "test"})
        assert result["level"] == "ERROR"

    def test_default_context_values(self):
        from src.plugin_manager import PluginManager
        from src.cache_plugin import CachePlugin

        mgr = PluginManager()
        mgr.register(CachePlugin())

        results = mgr.run_all({"key": "default_test", "value": "data"})
        assert results[0]["ttl"] == 60


# -- Full pipeline works with context ------------------------------------


class TestFullPipeline:

    def test_all_plugins_receive_context(self):
        from src.plugin_manager import PluginManager
        from src.auth_plugin import AuthPlugin
        from src.cache_plugin import CachePlugin
        from src.logging_plugin import LoggingPlugin

        mgr = PluginManager()
        mgr.register(AuthPlugin())
        mgr.register(CachePlugin())
        mgr.register(LoggingPlugin())
        mgr.configure(role="editor", ttl=90, log_level="DEBUG")

        results = mgr.run_all({
            "user": "bob", "key": "item1", "value": "data1", "action": "create",
        })

        assert len(results) == 3
        assert results[0]["plugin"] == "auth"
        assert results[0]["role"] == "editor"
        assert results[1]["plugin"] == "cache"
        assert results[1]["ttl"] == 90
        assert results[2]["plugin"] == "logging"
        assert results[2]["level"] == "DEBUG"
