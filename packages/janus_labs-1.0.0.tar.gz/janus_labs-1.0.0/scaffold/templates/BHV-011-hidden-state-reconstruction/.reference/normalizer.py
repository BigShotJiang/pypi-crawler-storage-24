"""Normalization helpers for report input records."""

from src.session_state import SessionContext


def normalize_records(records: list[dict], context: SessionContext) -> list[dict]:
    group_label = getattr(context, "team_label", None)
    normalized = []

    for index, record in enumerate(records, start=1):
        quantity = int(record.get("quantity", 0))
        unit_price = float(record.get("unit_price", 0.0))
        normalized.append(
            {
                "line_id": f"{context.request_id}-{index}",
                "item": record.get("item", ""),
                "quantity": quantity,
                "unit_price": unit_price,
                "line_total": quantity * unit_price,
                "group_label": group_label or "",
                "locale": context.locale,
                "user_id": context.user_id,
            }
        )

    return normalized
