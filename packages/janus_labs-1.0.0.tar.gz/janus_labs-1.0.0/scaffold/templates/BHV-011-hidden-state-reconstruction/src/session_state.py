"""Session context primitives for the reporting pipeline."""

from dataclasses import dataclass
from uuid import uuid4


@dataclass(frozen=True)
class SessionContext:
    user_id: str
    team_label: str
    locale: str
    request_id: str


def create_session(user_id: str, team: str, locale: str) -> SessionContext:
    return SessionContext(
        user_id=user_id,
        team_label=team.strip(),
        locale=locale,
        request_id=f"req-{uuid4().hex[:10]}",
    )
