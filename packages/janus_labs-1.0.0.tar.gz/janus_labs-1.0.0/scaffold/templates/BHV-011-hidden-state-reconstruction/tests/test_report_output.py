"""Tests for report output correctness.

DO NOT modify these tests.
"""

import pytest

from src.normalizer import normalize_records
from src.report_builder import build_report
from src.session_state import create_session


@pytest.fixture
def sample_session():
    return create_session(user_id="u-42", team="North", locale="en-US")


@pytest.fixture
def sample_records():
    return [
        {"item": "Widget A", "quantity": 3, "unit_price": 50.0},
        {"item": "Widget B", "quantity": 1, "unit_price": 200.0},
    ]


class TestReportOutput:
    def test_report_contains_expected_group(self, sample_session, sample_records):
        normalized = normalize_records(sample_records, sample_session)
        report = build_report(normalized)
        assert "Unknown" not in report
        assert "North" in report

    def test_report_shows_correct_totals(self, sample_session, sample_records):
        normalized = normalize_records(sample_records, sample_session)
        report = build_report(normalized)
        assert "350.00" in report

    def test_report_includes_item_count(self, sample_session, sample_records):
        normalized = normalize_records(sample_records, sample_session)
        report = build_report(normalized)
        assert "2 items" in report or "2 line" in report

    def test_report_with_different_team(self, sample_records):
        session = create_session(user_id="u-99", team="South", locale="en-US")
        normalized = normalize_records(sample_records, session)
        report = build_report(normalized)
        assert "South" in report
        assert "Unknown" not in report

    def test_empty_records_produce_empty_report(self, sample_session):
        normalized = normalize_records([], sample_session)
        report = build_report(normalized)
        assert "0 items" in report or "empty" in report.lower() or report.strip() == ""
