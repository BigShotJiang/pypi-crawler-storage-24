"""Tests for state propagation through the pipeline.

DO NOT modify these tests.
"""

from src.normalizer import normalize_records
from src.session_state import create_session


class TestStateRoundtrip:
    def test_normalized_records_carry_context(self):
        session = create_session(user_id="u-1", team="East", locale="en-US")
        records = [{"item": "X", "quantity": 1, "unit_price": 10.0}]
        normalized = normalize_records(records, session)
        assert len(normalized) == 1
        assert normalized[0].get("group_label") is not None
        assert normalized[0]["group_label"] != ""
        assert normalized[0]["group_label"] != "Unknown"

    def test_locale_survives_normalization(self):
        session = create_session(user_id="u-2", team="West", locale="de-DE")
        records = [{"item": "Y", "quantity": 2, "unit_price": 5.0}]
        normalized = normalize_records(records, session)
        assert normalized[0].get("locale") == "de-DE"

    def test_multiple_records_all_carry_context(self):
        session = create_session(user_id="u-3", team="Central", locale="en-US")
        records = [
            {"item": "A", "quantity": 1, "unit_price": 10.0},
            {"item": "B", "quantity": 2, "unit_price": 20.0},
            {"item": "C", "quantity": 3, "unit_price": 30.0},
        ]
        normalized = normalize_records(records, session)
        for record in normalized:
            assert record["group_label"] == "Central"
