"""First-run setup wizard (tkinter)."""

import logging
import tkinter as tk
from tkinter import ttk

logger = logging.getLogger(__name__)


def run_wizard() -> None:
    """Launch the first-run setup wizard. Blocks until complete."""
    logger.info("Launching first-run wizard...")
    app = WizardApp()
    app.mainloop()
    logger.info("Wizard complete")


class WizardApp(tk.Tk):
    """Multi-step setup wizard."""

    def __init__(self) -> None:
        super().__init__()
        self.title("Invoke Setup")
        self.geometry("520x420")
        self.resizable(False, False)
        self.configure(bg="#1a1a1e")

        # Center on screen
        self.update_idletasks()
        x = (self.winfo_screenwidth() - 520) // 2
        y = (self.winfo_screenheight() - 420) // 2
        self.geometry(f"+{x}+{y}")

        # Collected settings
        self._settings: dict = {}

        # Style
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background="#1a1a1e")
        style.configure("TLabel", background="#1a1a1e", foreground="#e0e0e0", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"), foreground="#ffffff")
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#888888")
        style.configure("Green.TLabel", foreground="#22c55e")
        style.configure("Warn.TLabel", foreground="#f59e0b")
        style.configure("TButton", font=("Segoe UI", 10))
        style.configure("Green.TButton", font=("Segoe UI", 11, "bold"))
        style.configure("TRadiobutton", background="#1a1a1e", foreground="#e0e0e0", font=("Segoe UI", 10))
        style.configure("TCheckbutton", background="#1a1a1e", foreground="#e0e0e0", font=("Segoe UI", 10))
        style.configure("TCombobox", font=("Segoe UI", 10))

        # Save whatever we have if user closes the window early
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Container
        self._container = ttk.Frame(self)
        self._container.pack(fill="both", expand=True, padx=32, pady=24)

        # Steps
        self._steps = [
            self._step_welcome,
            self._step_license,
            self._step_gpu,
            self._step_audio,
            self._step_reformatter,
            self._step_hotkey,
            self._step_done,
        ]
        self._current_step = 0
        self._show_step()

    def _clear(self) -> None:
        for w in self._container.winfo_children():
            w.destroy()

    def _show_step(self) -> None:
        self._clear()
        self._steps[self._current_step]()

    def _next(self) -> None:
        self._current_step += 1
        self._show_step()

    def _add_nav(self, next_text: str = "Next") -> None:
        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        btn = ttk.Button(nav, text=next_text, command=self._next, style="Green.TButton")
        btn.pack(side="right")

    # --- Step 1: Welcome ---
    def _step_welcome(self) -> None:
        ttk.Label(self._container, text="> invoke", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Voice-to-text for developers", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 20)
        )

        ttk.Label(
            self._container,
            text="Hold a button, speak, release.\nText appears at your cursor in under a second.",
            wraplength=440,
        ).pack(anchor="w", pady=(0, 12))

        ttk.Label(
            self._container,
            text="This wizard will set up your GPU, microphone,\nand preferences. Takes about 30 seconds.",
            wraplength=440,
            style="Sub.TLabel",
        ).pack(anchor="w")

        self._add_nav("Get started")

    # --- Step 2: License ---
    def _step_license(self) -> None:
        ttk.Label(self._container, text="License", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            self._container,
            text="Invoke includes a 7-day free trial. Enter a license key\nto activate, or start your trial now.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w", pady=(4, 16))

        # License key entry
        ttk.Label(self._container, text="License Key:").pack(anchor="w", pady=(0, 4))
        self._license_key_var = tk.StringVar()
        key_entry = ttk.Entry(self._container, textvariable=self._license_key_var, width=48, show="*")
        key_entry.pack(anchor="w")

        self._license_status_var = tk.StringVar()
        self._license_status_label = ttk.Label(
            self._container, textvariable=self._license_status_var, style="Sub.TLabel"
        )
        self._license_status_label.pack(anchor="w", pady=(4, 0))

        def _activate_and_next() -> None:
            key = self._license_key_var.get().strip()
            if not key:
                self._license_status_var.set("Please enter a key, or start your trial below.")
                return

            self._license_status_var.set("Activating...")

            import threading

            def _do_activate():
                from getinvoke.license import LicenseManager

                lm = LicenseManager()
                success, msg = lm.activate(key)
                self.after(0, lambda: _on_activate_done(success, msg))

            def _on_activate_done(success, msg):
                if success:
                    self._settings["license_activated"] = True
                    self._next()
                else:
                    self._license_status_var.set(msg)

            threading.Thread(target=_do_activate, daemon=True).start()

        def _start_trial() -> None:
            import threading

            def _do_trial():
                from getinvoke.license import LicenseManager

                lm = LicenseManager()
                lm.check()  # Creates trial if no license.json
                self.after(0, self._next)

            threading.Thread(target=_do_trial, daemon=True).start()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Activate", command=_activate_and_next, style="Green.TButton").pack(side="right")
        ttk.Button(nav, text="Start 7-day trial", command=_start_trial).pack(side="right", padx=(0, 8))

    # --- Step 3: GPU Detection ---
    def _step_gpu(self) -> None:
        ttk.Label(self._container, text="GPU Detection", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Checking for CUDA-capable GPU...", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 16)
        )

        status_frame = ttk.Frame(self._container)
        status_frame.pack(anchor="w", fill="x", pady=(0, 8))

        # Detect GPU using same logic as config._detect_whisper_device()
        # Don't do a CUDA runtime smoke test here — in PyInstaller bundles the
        # test fails even when the system CUDA Toolkit works fine at inference time.
        # The transcriber has graceful CUDA→CPU fallback as a safety net.
        import shutil

        gpu_available = False
        detection_method = ""

        try:
            import ctranslate2

            cuda_types = ctranslate2.get_supported_compute_types("cuda")
            if cuda_types:
                gpu_available = True
                detection_method = "ctranslate2 CUDA support"
        except Exception:
            pass

        if not gpu_available:
            import os

            cuda_path = os.environ.get("CUDA_PATH", "")
            if cuda_path and os.path.isdir(cuda_path):
                gpu_available = True
                detection_method = f"CUDA Toolkit at {cuda_path}"

        if not gpu_available and shutil.which("nvidia-smi"):
            gpu_available = True
            detection_method = "nvidia-smi (NVIDIA driver)"

        if gpu_available:
            ttk.Label(status_frame, text="CUDA GPU detected!", style="Green.TLabel").pack(anchor="w")
            ttk.Label(
                status_frame,
                text=f"Transcription will run on your GPU for sub-second speed.\n({detection_method})",
                wraplength=440,
                style="Sub.TLabel",
            ).pack(anchor="w", pady=(4, 0))
            self._settings["whisper_device"] = "cuda"
        else:
            ttk.Label(status_frame, text="No CUDA GPU found", style="Sub.TLabel").pack(anchor="w")
            ttk.Label(
                status_frame,
                text="Transcription will run on CPU. Slower but fully functional.\n\n"
                "You can install CUDA Toolkit 12.x later for faster transcription.",
                style="Sub.TLabel",
                wraplength=440,
            ).pack(anchor="w", pady=(4, 0))
            self._settings["whisper_device"] = "cpu"

        self._add_nav()

    # --- Step 3: Audio Device ---
    def _step_audio(self) -> None:
        ttk.Label(self._container, text="Audio Device", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Select your microphone", style="Sub.TLabel").pack(anchor="w", pady=(4, 16))

        from getinvoke.recorder import list_devices

        devices = list_devices()
        device_names = [f"[{d['index']}] {d['name']}" for d in devices]

        if not device_names:
            ttk.Label(self._container, text="No audio input devices found!", style="Warn.TLabel").pack(anchor="w")
            self._settings["audio_device"] = ""
            self._add_nav()
            return

        self._audio_var = tk.StringVar(value=device_names[0])
        combo = ttk.Combobox(
            self._container,
            textvariable=self._audio_var,
            values=device_names,
            state="readonly",
            width=50,
        )
        combo.pack(anchor="w", pady=(0, 8))

        ttk.Label(
            self._container,
            text="Tip: Pick your primary microphone. You can change this later in Settings.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w")

        def _next_with_device() -> None:
            selected = self._audio_var.get()
            if selected:
                # Extract device index from "[N] Name"
                idx = selected.split("]")[0].strip("[")
                self._settings["audio_device"] = idx
            self._next()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Next", command=_next_with_device, style="Green.TButton").pack(side="right")

    # --- Step 4: AI Processing ---
    def _step_reformatter(self) -> None:
        import shutil
        import webbrowser

        ttk.Label(self._container, text="AI Processing", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            self._container,
            text="After Whisper transcribes your speech, an AI can clean it up\n"
            "— fix grammar, remove filler words, and format it for your coding tool.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w", pady=(4, 12))

        # Auto-detect available backends
        has_claude_cli = shutil.which("claude") is not None
        # Pick smart default
        default_backend = "claude-cli" if has_claude_cli else "none"
        self._backend_var = tk.StringVar(value=default_backend)

        options = [
            (
                "openrouter",
                "Yes, use AI via OpenRouter",
                "Uses Claude via cloud API (~$0.001/dictation). Needs an API key.",
            ),
            (
                "claude-cli",
                "Yes, use my Claude Code CLI" + (" (detected)" if has_claude_cli else ""),
                "No extra API key — uses your Claude Code subscription.",
            ),
            (
                "ollama",
                "Yes, use a local LLM (Ollama, LM Studio, etc.)",
                "Free, fully offline. Works with Ollama, LM Studio, or any local server.",
            ),
            (
                "none",
                "No AI — raw transcription only",
                "Fastest. Whisper output goes straight to clipboard, no cleanup.",
            ),
        ]

        for value, label, desc in options:
            frame = ttk.Frame(self._container)
            frame.pack(anchor="w", fill="x", pady=(0, 2))
            ttk.Radiobutton(frame, text=label, variable=self._backend_var, value=value).pack(anchor="w")
            ttk.Label(frame, text=desc, style="Sub.TLabel", wraplength=420).pack(anchor="w", padx=(24, 0))

        # OpenRouter API key entry (shown only when openrouter selected)
        self._api_frame = ttk.Frame(self._container)
        self._api_var = tk.StringVar()
        key_row = ttk.Frame(self._api_frame)
        key_row.pack(anchor="w", fill="x")
        ttk.Label(key_row, text="OpenRouter API Key:").pack(side="left")
        ttk.Button(
            key_row,
            text="Get key",
            command=lambda: webbrowser.open("https://openrouter.ai/keys"),
        ).pack(side="left", padx=(8, 0))
        ttk.Entry(self._api_frame, textvariable=self._api_var, width=50, show="*").pack(anchor="w", pady=(4, 0))
        self._api_warn_var = tk.StringVar()
        ttk.Label(self._api_frame, textvariable=self._api_warn_var, foreground="#E67E80").pack(anchor="w", pady=(2, 0))

        def _on_backend_change(*_args: object) -> None:
            if self._backend_var.get() == "openrouter":
                self._api_frame.pack(anchor="w", fill="x", pady=(8, 0))
            else:
                self._api_frame.pack_forget()

        self._backend_var.trace_add("write", _on_backend_change)
        _on_backend_change()  # Set initial visibility

        def _next_with_backend() -> None:
            backend = self._backend_var.get()
            # Warn if OpenRouter selected without API key
            if backend == "openrouter" and not self._api_var.get().strip():
                self._api_warn_var.set("API key required for OpenRouter. Enter a key or choose another option.")
                return
            self._settings["reformatter_backend"] = backend
            if backend == "openrouter":
                self._settings["openrouter_api_key"] = self._api_var.get().strip()
            self._next()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Next", command=_next_with_backend, style="Green.TButton").pack(side="right")

    # --- Step 5: Hotkey ---
    def _step_hotkey(self) -> None:
        ttk.Label(self._container, text="Hotkey", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Choose your push-to-talk button", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 16)
        )

        self._hotkey_var = tk.StringVar(value="mouse5")

        options = [
            ("mouse5", "Mouse 5 (forward side button)", "Most common for gaming mice. Quick thumb access."),
            ("mouse4", "Mouse 4 (back side button)", "Alternative side button."),
            ("ctrl+shift+d", "Ctrl+Shift+D", "Keyboard shortcut. Works with any mouse."),
        ]

        for value, label, desc in options:
            frame = ttk.Frame(self._container)
            frame.pack(anchor="w", fill="x", pady=(0, 4))
            ttk.Radiobutton(frame, text=label, variable=self._hotkey_var, value=value).pack(anchor="w")
            ttk.Label(frame, text=desc, style="Sub.TLabel", wraplength=420).pack(anchor="w", padx=(24, 0))

        # Auto-paste toggle
        self._autopaste_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            self._container,
            text="Auto-paste at cursor (recommended)",
            variable=self._autopaste_var,
        ).pack(anchor="w", pady=(16, 0))
        ttk.Label(
            self._container,
            text="Text appears at your cursor automatically. Uncheck to use Ctrl+V manually.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w", padx=(24, 0))

        def _next_with_hotkey() -> None:
            self._settings["hotkey"] = self._hotkey_var.get()
            self._settings["auto_paste"] = self._autopaste_var.get()
            self._next()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Next", command=_next_with_hotkey, style="Green.TButton").pack(side="right")

    # --- Step 6: Done ---
    def _step_done(self) -> None:
        ttk.Label(self._container, text="You're all set!", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Saving your configuration...", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 16)
        )

        # Save settings
        self._save_settings()

        # Summary
        device = self._settings.get("whisper_device", "cpu")
        backend = self._settings.get("reformatter_backend", "none")
        hotkey = self._settings.get("hotkey", "mouse5")
        autopaste = self._settings.get("auto_paste", True)

        summary = [
            f"GPU: {'CUDA' if device == 'cuda' else 'CPU'}",
            f"Reformatter: {backend}",
            f"Hotkey: {hotkey}",
            f"Auto-paste: {'on' if autopaste else 'off'}",
        ]
        for line in summary:
            ttk.Label(self._container, text=f"  > {line}", style="Green.TLabel").pack(anchor="w", pady=(2, 0))

        # Quick tips
        ttk.Label(self._container, text="\nQuick tips:", style="Sub.TLabel").pack(anchor="w", pady=(8, 0))
        tips = [
            f"Hold {hotkey} to speak, release to transcribe",
            "Right-click the tray icon to switch modes",
            "Run 'dictate health' in terminal to check your setup",
            "Change settings anytime from the tray menu",
        ]
        for tip in tips:
            ttk.Label(self._container, text=f"  > {tip}", style="Sub.TLabel", wraplength=420).pack(
                anchor="w", pady=(2, 0)
            )

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Launch Invoke", command=self.destroy, style="Green.TButton").pack(side="right")

    def _on_close(self) -> None:
        """Handle early window close — save whatever settings were collected."""
        if self._settings:
            self._save_settings()
        self.destroy()

    def _save_settings(self) -> None:
        """Write collected settings to config.json."""
        from getinvoke.config import settings

        if "whisper_device" in self._settings:
            settings.WHISPER_DEVICE = self._settings["whisper_device"]
        if "audio_device" in self._settings:
            settings.AUDIO_DEVICE = self._settings["audio_device"] or None
        if "reformatter_backend" in self._settings:
            settings.REFORMATTER_BACKEND = self._settings["reformatter_backend"]
        if "openrouter_api_key" in self._settings:
            settings.OPENROUTER_API_KEY = self._settings["openrouter_api_key"]
        if "hotkey" in self._settings:
            settings.HOTKEY = self._settings["hotkey"]
        if "auto_paste" in self._settings:
            settings.AUTO_PASTE = self._settings["auto_paste"]

        settings.save()
        safe = {k: ("***" if "key" in k.lower() else v) for k, v in self._settings.items()}
        logger.info(f"Wizard saved config: {safe}")
