"""System tray icon via pystray."""

import logging
import platform
import threading
from collections.abc import Callable

import pystray
from PIL import Image, ImageDraw

logger = logging.getLogger(__name__)

# Icon states -> chevron colors
STATE_COLORS = {
    "idle": "#22c55e",  # Green
    "recording": "#5FC8C8",  # Bright teal
    "processing": "#D4943A",  # Gold
    "error": "#E67E80",  # Muted coral
}


def _create_icon_image(color: str, size: int = 64) -> Image.Image:
    """Generate the Invoke icon: dark box with colored '>' chevron."""
    # Render at 4x then downsample for anti-aliasing
    rs = size * 4
    img = Image.new("RGBA", (rs, rs), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    radius = max(rs // 8, 4)
    draw.rounded_rectangle([0, 0, rs - 1, rs - 1], radius=radius, fill="#0D1B1E")

    # Solid chevron polygon
    left = rs * 0.32
    right = rs * 0.68
    top = rs * 0.20
    bottom = rs * 0.80
    cy = rs * 0.50
    t = rs * 0.11

    draw.polygon(
        [
            (left, top - t),
            (right + t, cy),
            (left, bottom + t),
            (left, bottom - t),
            (right - t * 1.5, cy),
            (left, top + t),
        ],
        fill=color,
    )

    return img.resize((size, size), Image.LANCZOS)


class TrayApp:
    """System tray icon with state management and mode selection."""

    def __init__(
        self,
        on_quit: Callable[[], None] | None = None,
        on_open_config: Callable[[], None] | None = None,
        on_mode_change: Callable[[str], None] | None = None,
    ) -> None:
        self._state = "idle"
        self._on_quit = on_quit
        self._on_open_config = on_open_config
        self._on_mode_change = on_mode_change
        self._tooltip = "Invoke — Ready"
        self._icon: pystray.Icon | None = None
        self._thread: threading.Thread | None = None
        self._license_manager = None
        self._update_version: str | None = None

    def start(self) -> None:
        """Start the tray icon in a background thread."""
        from getinvoke.config import settings
        from getinvoke.modes import MODES

        # Build mode submenu with descriptions
        def _make_mode_handler(mode_name: str) -> Callable:
            def handler(icon: pystray.Icon, item: pystray.MenuItem) -> None:
                self._handle_mode_change(mode_name)

            return handler

        def _mode_checked(mode_name: str) -> Callable:
            def checked(item: pystray.MenuItem) -> bool:
                return settings.MODE == mode_name

            return checked

        # Group modes: IDE targets, then utilities, then raw
        ide_modes = ["claude-code", "cursor", "windsurf", "copilot"]
        util_modes = ["commit", "pr"]
        other_modes = ["raw"]

        mode_items = []
        mode_items.append(pystray.MenuItem("-- AI Prompt Modes --", None, enabled=False))
        for name in ide_modes:
            mode = MODES[name]
            mode_items.append(
                pystray.MenuItem(
                    mode.label,
                    _make_mode_handler(mode.name),
                    checked=_mode_checked(mode.name),
                    radio=True,
                )
            )
        mode_items.append(pystray.Menu.SEPARATOR)
        mode_items.append(pystray.MenuItem("-- Utility Modes --", None, enabled=False))
        for name in util_modes:
            mode = MODES[name]
            mode_items.append(
                pystray.MenuItem(
                    mode.label,
                    _make_mode_handler(mode.name),
                    checked=_mode_checked(mode.name),
                    radio=True,
                )
            )
        mode_items.append(pystray.Menu.SEPARATOR)
        for name in other_modes:
            mode = MODES[name]
            mode_items.append(
                pystray.MenuItem(
                    mode.label,
                    _make_mode_handler(mode.name),
                    checked=_mode_checked(mode.name),
                    radio=True,
                )
            )

        mode_submenu = pystray.Menu(*mode_items)

        def _backend_label(item: pystray.MenuItem) -> str:
            b = settings.REFORMATTER_BACKEND.lower()
            if b == "none":
                return "AI: Off (raw Whisper only)"
            if b == "openrouter":
                return f"AI: {settings.DICTATION_MODEL.split('/')[-1]}"
            if b == "claude-cli":
                return f"AI: Claude CLI ({settings.CLAUDE_CLI_MODEL})"
            if b == "ollama":
                return f"AI: Local LLM ({settings.OLLAMA_MODEL})"
            return f"AI: {b}"

        # Build AI Backend submenu
        def _make_backend_handler(backend_name: str) -> Callable:
            def handler(icon: pystray.Icon, item: pystray.MenuItem) -> None:
                self._handle_backend_change(backend_name)

            return handler

        def _backend_checked(backend_name: str) -> Callable:
            def checked(item: pystray.MenuItem) -> bool:
                return settings.REFORMATTER_BACKEND.lower() == backend_name

            return checked

        backend_items = [
            pystray.MenuItem(
                lambda item: f"OpenRouter ({settings.DICTATION_MODEL.split('/')[-1]})",
                _make_backend_handler("openrouter"),
                checked=_backend_checked("openrouter"),
                radio=True,
            ),
            pystray.MenuItem(
                lambda item: f"Claude Code CLI ({settings.CLAUDE_CLI_MODEL})",
                _make_backend_handler("claude-cli"),
                checked=_backend_checked("claude-cli"),
                radio=True,
            ),
            pystray.MenuItem(
                lambda item: f"Local LLM ({settings.OLLAMA_MODEL})",
                _make_backend_handler("ollama"),
                checked=_backend_checked("ollama"),
                radio=True,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(
                "Off (raw Whisper only)",
                _make_backend_handler("none"),
                checked=_backend_checked("none"),
                radio=True,
            ),
        ]
        backend_submenu = pystray.Menu(*backend_items)

        menu = pystray.Menu(
            pystray.MenuItem("Invoke", None, enabled=False),
            pystray.MenuItem(_backend_label, None, enabled=False),
            pystray.MenuItem(
                lambda item: f"Update to v{self._update_version} (restarts app)" if self._update_version else "",
                self._handle_quit,
                visible=lambda item: self._update_version is not None,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Mode", mode_submenu),
            pystray.MenuItem("AI Backend", backend_submenu),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("License...", self._handle_open_license),
            pystray.MenuItem("Settings...", self._handle_open_settings),
            pystray.MenuItem("Open Logs", self._handle_open_logs),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", self._handle_quit),
        )

        self._icon = pystray.Icon(
            "invoke",
            icon=_create_icon_image(STATE_COLORS["idle"]),
            title=self._tooltip,
            menu=menu,
        )

        self._thread = threading.Thread(target=self._icon.run, daemon=True)
        self._thread.start()
        logger.info("Tray icon started")

    def stop(self) -> None:
        """Stop the tray icon."""
        if self._icon is not None:
            self._icon.stop()
            self._icon = None
        logger.info("Tray icon stopped")

    def set_state(self, state: str) -> None:
        """Update tray icon state (idle, recording, processing, error)."""
        self._state = state
        color = STATE_COLORS.get(state, STATE_COLORS["idle"])
        if self._icon is not None:
            self._icon.icon = _create_icon_image(color)
            self._icon.title = self._tooltip

    def set_tooltip(self, text: str) -> None:
        """Update the tooltip text."""
        self._tooltip = f"Invoke — {text}"
        if self._icon is not None:
            self._icon.title = self._tooltip

    def notify(self, message: str, title: str = "Invoke") -> None:
        """Show a system notification (toast on Windows)."""
        if self._icon is not None:
            try:
                self._icon.notify(message, title)
            except Exception as e:
                logger.debug(f"Notification failed: {e}")

    def set_license_manager(self, lm) -> None:
        """Set the license manager for tooltip display."""
        self._license_manager = lm
        # Update tooltip based on license state
        from getinvoke.license import LicenseStatus

        if lm.status == LicenseStatus.TRIAL:
            self.set_tooltip(f"Trial — {lm.trial_days_left} days left")
        elif lm.status == LicenseStatus.GRACE:
            self.set_tooltip("License — offline grace period")

    def set_update_available(self, version: str) -> None:
        """Signal that an update has been downloaded and is ready."""
        self._update_version = version
        if self._icon is not None:
            self._icon.update_menu()

    def _handle_open_license(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        """Open the license activation dialog."""
        if self._license_manager is None:
            return

        from getinvoke.license import LicenseStatus
        from getinvoke.license_gui import show_activation_dialog

        allow_trial = self._license_manager.status == LicenseStatus.TRIAL
        days_left = self._license_manager.trial_days_left

        def _run() -> None:
            show_activation_dialog(
                self._license_manager,
                allow_trial=allow_trial,
                trial_days_left=days_left,
            )
            # Refresh tooltip after dialog closes
            if self._license_manager.status == LicenseStatus.ACTIVE:
                self.set_tooltip("Ready")
            elif self._license_manager.status == LicenseStatus.TRIAL:
                self.set_tooltip(f"Trial — {self._license_manager.trial_days_left} days left")

        threading.Thread(target=_run, daemon=True).start()

    def _handle_backend_change(self, backend_name: str) -> None:
        from getinvoke.config import settings

        settings.REFORMATTER_BACKEND = backend_name
        settings.save()
        logger.info(f"AI backend changed to: {backend_name}")
        if self._icon is not None:
            self._icon.update_menu()

    def _handle_mode_change(self, mode_name: str) -> None:
        from getinvoke.config import settings

        settings.MODE = mode_name
        settings.save()
        logger.info(f"Mode changed to: {mode_name}")
        if self._on_mode_change:
            self._on_mode_change(mode_name)

    def _handle_quit(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        if self._on_quit:
            self._on_quit()
        self.stop()

    def _handle_open_settings(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        from getinvoke.settings_gui import open_settings

        def _on_save() -> None:
            logger.info("Settings saved, updating tray state")
            # Update tray mode display after settings change
            if self._icon is not None:
                self._icon.update_menu()

        open_settings(on_save=_on_save)

    def _handle_open_logs(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        from getinvoke.config import settings

        log_dir = settings.log_dir
        log_dir.mkdir(parents=True, exist_ok=True)
        self._open_path(log_dir)

    def _get_config_dir(self):
        from getinvoke.config import settings

        config_dir = settings.config_dir
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir

    @staticmethod
    def _open_path(path) -> None:
        import subprocess

        if platform.system() == "Windows":
            subprocess.Popen(["explorer", str(path)])
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
