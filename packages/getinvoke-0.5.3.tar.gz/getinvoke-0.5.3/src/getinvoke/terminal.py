"""Rich terminal frontend — headless mode for CLI usage."""

import logging
import sys
import threading
import time

import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from getinvoke.config import settings

logger = logging.getLogger(__name__)

console = Console()


class TerminalFrontend:
    """Frontend that renders state to the terminal using Rich."""

    def __init__(self) -> None:
        self._recording_start: float = 0
        self._timer_thread: threading.Thread | None = None
        self._timer_running = False
        self._license_manager = None

    def set_license_manager(self, lm) -> None:
        """Set the engine's license manager for activation flow."""
        self._license_manager = lm

    def start(self) -> None:
        """Print startup banner with current config."""
        mode = settings.MODE
        backend = settings.REFORMATTER_BACKEND
        device = settings.WHISPER_DEVICE
        hotkey = settings.HOTKEY

        # Build AI label
        if backend == "none":
            ai_label = "off (raw Whisper only)"
        elif backend == "openrouter":
            ai_label = f"openrouter ({settings.DICTATION_MODEL.split('/')[-1]})"
        elif backend == "claude-cli":
            ai_label = f"claude-cli ({settings.CLAUDE_CLI_MODEL})"
        elif backend == "ollama":
            ai_label = f"ollama ({settings.OLLAMA_MODEL})"
        else:
            ai_label = backend

        header = Text()
        header.append("Invoke", style="bold white")
        header.append(" (headless)", style="dim")
        header.append(f" — {mode} mode\n", style="cyan")
        header.append(f"Hotkey: {hotkey}", style="dim")
        header.append(f" | AI: {ai_label}", style="dim")
        header.append(f" | GPU: {device}", style="dim")

        console.print(Panel(header, border_style="cyan"))
        console.print(f"\n  Listening... (hold [bold]{hotkey}[/bold] to record)\n", highlight=False)

    def stop(self) -> None:
        self._timer_running = False
        console.print("\n  [dim]Invoke stopped.[/dim]")

    def on_state_change(self, state: str) -> None:
        pass  # State is communicated through the specific callbacks

    def on_recording_started(self) -> None:
        self._recording_start = time.time()
        self._timer_running = True
        self._timer_thread = threading.Thread(target=self._run_timer, daemon=True)
        self._timer_thread.start()

    def on_recording_stopped(self, duration: float) -> None:
        self._timer_running = False
        time.sleep(0.05)  # Let timer thread finish its last write
        # Overwrite the timer line with final duration
        if sys.stdout is not None:
            sys.stdout.write(f"\r  [recording]  {duration:.1f}s\n")
            sys.stdout.flush()

    def on_processing(self) -> None:
        console.print("  [yellow][processing][/yellow] Transcribing + reformatting...", highlight=False)

    def on_result(self, raw: str, reformatted: str, duration_ms: int) -> None:
        console.print()
        # Show raw vs reformatted
        raw_text = Text()
        raw_text.append("  Raw:  ", style="dim")
        raw_text.append(f'"{raw}"', style="white")
        console.print(raw_text)

        out_text = Text()
        out_text.append("  Out:  ", style="dim")
        out_text.append(reformatted, style="bold white")
        console.print(out_text)

        console.print(f"\n  [green]Copied to clipboard[/green] ({duration_ms}ms)\n", highlight=False)
        console.print(f"  Listening... (hold [bold]{settings.HOTKEY}[/bold] to record)\n", highlight=False)

    def on_error(self, message: str) -> None:
        console.print(f"  [red][error][/red] {message}", highlight=False)
        console.print(f"\n  Listening... (hold [bold]{settings.HOTKEY}[/bold] to record)\n", highlight=False)

    def notify(self, message: str, title: str) -> None:
        console.print(f"  [cyan]{title}:[/cyan] {message}", highlight=False)

    def on_first_run(self) -> None:
        """Trigger CLI setup wizard."""
        from getinvoke.setup_cli import run_cli_wizard

        run_cli_wizard()

    def on_license_needed(self, message: str) -> bool:
        """Terminal-based license activation using the engine's LicenseManager."""
        console.print(f"\n  [yellow]{message}[/yellow]")
        key = click.prompt("  Enter license key (or press Enter to quit)", default="", show_default=False)
        if not key.strip():
            return False

        if self._license_manager is None:
            console.print("  [red]License manager not available[/red]")
            return False

        success, msg = self._license_manager.activate(key.strip())
        if success:
            console.print(f"  [green]{msg}[/green]")
            return True
        else:
            console.print(f"  [red]{msg}[/red]")
            return False

    def _run_timer(self) -> None:
        """Update recording timer in a background thread using raw stdout for \r support."""
        while self._timer_running:
            elapsed = time.time() - self._recording_start
            bars = int(elapsed * 4) % 20
            bar = "|" * bars + "." * (20 - bars)
            if sys.stdout is not None:
                sys.stdout.write(f"\r  [recording]  {elapsed:.1f}s  {bar}")
                sys.stdout.flush()
            time.sleep(0.1)
