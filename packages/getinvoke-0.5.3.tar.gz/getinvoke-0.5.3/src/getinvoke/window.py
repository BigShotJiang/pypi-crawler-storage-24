"""Active window CWD and file detection."""

import logging
import platform
import re
from pathlib import Path

logger = logging.getLogger(__name__)

_IS_WINDOWS = platform.system() == "Windows"

# Regex patterns to extract CWD from terminal window titles
_CWD_PATTERNS = [
    re.compile(r":\s+(/.+?)(?:\s*[-]|$)"),  # /path/to/dir - Terminal
    re.compile(r":\s+(~[^\s]*)"),  # ~/project - Terminal
    re.compile(r"([A-Z]:\\[^\s]+)"),  # C:\Users\... (Windows paths)
]

# Patterns to extract active file from IDE/editor window titles
_FILE_PATTERNS = [
    # VS Code / Cursor: "filename.ts — project — Visual Studio Code" or "filename.ts - project - Cursor"
    re.compile(r"^(.+?\.\w+)\s+[—\-]\s+.+?\s+[—\-]\s+(?:Visual Studio Code|Cursor|Windsurf)"),
    # VS Code with path: "src/file.ts — project"
    re.compile(r"^([\w./\\]+\.\w+)\s+[—\-]"),
    # Vim/Neovim: "filename.ts - NVIM" or "filename.ts (+) - VIM"
    re.compile(r"^(.+?\.\w+)(?:\s+\([+]\))?\s+[—\-]\s+N?VIM"),
    # Generic: anything.ext at the start of a title
    re.compile(r"^([\w\-./\\]+\.\w{1,10})\b"),
]


def get_active_cwd() -> str | None:
    """Get the working directory from the active terminal window."""
    # Try dictation CWD file first (written by Claude Code hook)
    cwd = _read_dictation_cwd_file()
    if cwd:
        return cwd

    # Try window title parsing on Windows
    if _IS_WINDOWS:
        return _get_cwd_from_window_title()

    return None


def get_active_file() -> str | None:
    """Get the active file path from the foreground window title.

    Returns:
        File path string (may be relative), or None if not detected.
    """
    title = _get_window_title()
    if not title:
        return None

    for pattern in _FILE_PATTERNS:
        match = pattern.search(title)
        if match:
            filepath = match.group(1).strip()
            # Sanity check: should look like a file (has extension, not too long)
            if "." in filepath and len(filepath) < 200:
                logger.debug(f"Active file from window title: {filepath}")
                return filepath

    return None


def _get_window_title() -> str | None:
    """Get the foreground window title."""
    if not _IS_WINDOWS:
        return None

    try:
        import ctypes

        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(hwnd)
        if length == 0:
            return None

        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return buf.value or None
    except Exception as e:
        logger.debug(f"Failed to get window title: {e}")
        return None


def _read_dictation_cwd_file() -> str | None:
    """Read CWD from the dictation temp file.

    Uses a user-private path to prevent other users from injecting
    arbitrary directories via a shared /tmp location.
    """
    import os

    if _IS_WINDOWS:
        path = Path(os.environ.get("TEMP", "C:\\Temp")) / ".dictation_cwd"
    else:
        # User-private: ~/.config/invoke/.dictation_cwd (not world-writable /tmp)
        path = Path.home() / ".config" / "invoke" / ".dictation_cwd"
        # Also check legacy /tmp path but only if owned by current user
        legacy_path = Path("/tmp/.dictation_cwd")
        if not path.exists() and legacy_path.exists():
            try:
                stat = legacy_path.stat()
                if stat.st_uid == os.getuid():
                    path = legacy_path
                else:
                    logger.warning("Ignoring /tmp/.dictation_cwd — not owned by current user")
                    return None
            except OSError:
                return None

    try:
        cwd = path.read_text().strip()
        # Validate: must be an existing directory, not a special path
        cwd_path = Path(cwd)
        if cwd and cwd_path.is_dir() and cwd_path.is_absolute():
            logger.debug(f"CWD from dictation file: {cwd}")
            return cwd
    except (OSError, FileNotFoundError):
        pass
    return None


def _get_cwd_from_window_title() -> str | None:
    """Parse CWD from the foreground window title (Windows only)."""
    title = _get_window_title()
    if not title:
        return None

    logger.debug(f"Window title: {title}")

    for pattern in _CWD_PATTERNS:
        match = pattern.search(title)
        if match:
            cwd = match.group(1)
            # Expand ~ on Windows
            if cwd.startswith("~"):
                cwd = str(Path.home() / cwd[2:]) if len(cwd) > 1 else str(Path.home())
            if Path(cwd).exists():
                logger.debug(f"CWD from window title: {cwd}")
                return cwd

    return None
