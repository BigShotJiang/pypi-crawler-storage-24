"""Mode registry — maps mode names to system prompts."""

from dataclasses import dataclass

from getinvoke.modes.prompts import (
    CLAUDE_CODE_PROMPT,
    COMMIT_PROMPT,
    COPILOT_PROMPT,
    CURSOR_PROMPT,
    PR_PROMPT,
    RAW_PROMPT,
    WINDSURF_PROMPT,
)


@dataclass(frozen=True)
class Mode:
    name: str
    label: str
    description: str
    prompt: str


MODES: dict[str, Mode] = {
    "claude-code": Mode(
        name="claude-code",
        label="Claude Code",
        description="Formats speech as conversational prompts for Claude Code",
        prompt=CLAUDE_CODE_PROMPT,
    ),
    "cursor": Mode(
        name="cursor",
        label="Cursor",
        description="Formats speech with @file references for Cursor chat",
        prompt=CURSOR_PROMPT,
    ),
    "windsurf": Mode(
        name="windsurf",
        label="Windsurf",
        description="Formats speech as Cascade-style prompts for Windsurf",
        prompt=WINDSURF_PROMPT,
    ),
    "copilot": Mode(
        name="copilot",
        label="Copilot",
        description="Formats speech for GitHub Copilot Chat",
        prompt=COPILOT_PROMPT,
    ),
    "raw": Mode(
        name="raw",
        label="Raw Dictation",
        description="Cleans up speech (filler, grammar) — no prompt structure added",
        prompt=RAW_PROMPT,
    ),
    "commit": Mode(
        name="commit",
        label="Commit Message",
        description="Turns speech into a conventional git commit message",
        prompt=COMMIT_PROMPT,
    ),
    "pr": Mode(
        name="pr",
        label="PR Description",
        description="Turns speech into a PR title + body",
        prompt=PR_PROMPT,
    ),
}

DEFAULT_MODE = "claude-code"


def get_mode(name: str) -> Mode:
    """Get a mode by name. Falls back to default."""
    return MODES.get(name, MODES[DEFAULT_MODE])


def get_system_prompt(name: str) -> str:
    """Get the system prompt for a mode."""
    return get_mode(name).prompt


def list_modes() -> list[Mode]:
    """List all available modes."""
    return list(MODES.values())
