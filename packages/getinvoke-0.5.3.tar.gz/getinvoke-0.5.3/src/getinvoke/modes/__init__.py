"""Target modes — system prompt variants for different AI coding assistants."""

from getinvoke.modes.registry import MODES, get_mode, get_system_prompt, list_modes

__all__ = ["MODES", "get_mode", "get_system_prompt", "list_modes"]
