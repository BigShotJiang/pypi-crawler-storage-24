"""Core pipeline engine — GUI-agnostic orchestrator with pluggable frontends."""

from __future__ import annotations

import asyncio
import logging
import platform
import signal
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from logging.handlers import RotatingFileHandler
from typing import Protocol, runtime_checkable

from getinvoke import clipboard, feedback, history, updater
from getinvoke.config import settings
from getinvoke.context import (
    extract_project_metadata,
    generate_project_vocabulary,
    invalidate_cache,
    load_project_context,
)
from getinvoke.hotkey import HotkeyListener
from getinvoke.license import LicenseManager, LicenseStatus
from getinvoke.recorder import Recorder
from getinvoke.reformatter import reformat_dictation
from getinvoke.transcriber import load_model, transcribe, unload_model
from getinvoke.window import get_active_cwd, get_active_file

logger = logging.getLogger(__name__)


@runtime_checkable
class FrontendProtocol(Protocol):
    """Interface for pluggable frontends (GUI, terminal, etc.)."""

    def start(self) -> None:
        """Initialize and start the frontend."""
        ...

    def stop(self) -> None:
        """Clean up and stop the frontend."""
        ...

    def on_state_change(self, state: str) -> None:
        """State changed: idle, recording, processing, error."""
        ...

    def on_recording_started(self) -> None:
        """Recording has begun."""
        ...

    def on_recording_stopped(self, duration: float) -> None:
        """Recording stopped after `duration` seconds."""
        ...

    def on_processing(self) -> None:
        """Pipeline is processing (transcribing + reformatting)."""
        ...

    def on_result(self, raw: str, reformatted: str, duration_ms: int) -> None:
        """Pipeline completed with result."""
        ...

    def on_error(self, message: str) -> None:
        """An error occurred."""
        ...

    def notify(self, message: str, title: str) -> None:
        """Show a notification to the user."""
        ...

    def on_first_run(self) -> None:
        """Trigger the first-run setup wizard."""
        ...

    def on_license_needed(self, message: str) -> bool:
        """License activation needed. Returns True if activated, False to quit."""
        ...


class InvokeEngine:
    """Main orchestrator — all pipeline logic, no GUI dependencies."""

    def __init__(self, frontend: FrontendProtocol) -> None:
        self._frontend = frontend
        self._recorder = Recorder(device=settings.AUDIO_DEVICE)
        self._hotkey: HotkeyListener | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._executor = ThreadPoolExecutor(max_workers=2)
        self._quit_event = asyncio.Event()
        self._last_cwd: str | None = None
        self._record_start_time: float = 0
        self._license_manager = LicenseManager()

    def run(self) -> None:
        """Start the engine — blocks until quit."""
        self._setup_logging()

        # Give frontend access to the license manager (for activation flow)
        if hasattr(self._frontend, "set_license_manager"):
            self._frontend.set_license_manager(self._license_manager)

        # First-run wizard (if no config.json exists)
        first_run = not settings.config_file.exists()
        if first_run:
            try:
                self._frontend.on_first_run()
                # Reload settings from the newly created config
                settings.__init__()
            except Exception as e:
                logger.warning(f"Setup failed, using defaults: {e}")

        # License check (before loading heavy resources)
        license_status = self._license_manager.check()
        if license_status in (LicenseStatus.EXPIRED_TRIAL, LicenseStatus.INVALID):
            msg = (
                "Your 7-day trial has ended. Enter a license key to continue."
                if license_status == LicenseStatus.EXPIRED_TRIAL
                else "Your license needs to be re-activated."
            )
            if not self._frontend.on_license_needed(msg):
                logger.info("User quit without activating")
                return
        elif license_status == LicenseStatus.TRIAL:
            logger.info(f"Trial: {self._license_manager.trial_days_left} days remaining")
        elif license_status == LicenseStatus.GRACE:
            logger.info("License in grace period — connect to internet to re-validate")

        logger.info("Starting Invoke...")
        logger.info(f"Whisper model: {settings.WHISPER_MODEL} on {settings.WHISPER_DEVICE}")
        logger.info(f"Reformatter: {settings.REFORMATTER_BACKEND}")
        logger.info(f"Mode: {settings.MODE}")
        logger.info(f"Hotkey: {settings.HOTKEY}")
        if settings.hotwords:
            logger.info(f"Custom vocabulary: {settings.hotwords}")

        # Load Whisper model
        try:
            load_model()
        except Exception as e:
            logger.error(f"Failed to load Whisper model: {e}")
            sys.exit(1)

        # Initialize history database
        history.init_db()

        # Start frontend
        self._frontend.start()

        # Warn if AI backend needs configuration
        if settings.REFORMATTER_BACKEND == "openrouter" and not settings.OPENROUTER_API_KEY:
            logger.warning("OpenRouter backend selected but no API key set — AI processing will fail")
            self._frontend.notify(
                "AI processing needs an API key. Run 'dictate setup' to configure.",
                "Invoke — Setup Needed",
            )

        # Start hotkey listener
        self._loop = asyncio.new_event_loop()
        self._hotkey = HotkeyListener(
            hotkey=settings.HOTKEY,
            on_press=self._on_hotkey_press,
            on_release=self._on_hotkey_release,
        )
        self._hotkey.start()

        # Handle signals (add_signal_handler is Unix-only)
        if platform.system() != "Windows":
            for sig in (signal.SIGINT, signal.SIGTERM):
                self._loop.add_signal_handler(sig, self.request_quit)

        logger.info("Invoke is ready. Hold your hotkey to dictate.")

        # First-run notification
        if first_run:
            self._frontend.notify(f"Hold {settings.HOTKEY} to dictate.", "Invoke is ready!")

        # Run event loop (update check starts once loop is running)
        async def _main() -> None:
            self._loop.create_task(self._check_for_updates())
            await self._quit_event.wait()

        try:
            self._loop.run_until_complete(_main())
        except KeyboardInterrupt:
            pass
        finally:
            self._shutdown()

    @property
    def license_manager(self) -> LicenseManager:
        return self._license_manager

    def _setup_logging(self) -> None:
        """Configure console + file logging."""
        log_level = getattr(logging, settings.LOG_LEVEL, logging.INFO)
        log_format = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        logging.basicConfig(level=log_level, format=log_format)

        log_dir = settings.log_dir
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_dir / "invoke.log",
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        file_handler.setFormatter(logging.Formatter(log_format))
        file_handler.setLevel(log_level)
        logging.getLogger().addHandler(file_handler)

    def _on_hotkey_press(self) -> None:
        """Called when hotkey is pressed — start recording."""
        self._record_start_time = time.time()
        if settings.BEEP_ENABLED:
            feedback.play_start_beep()
        self._frontend.on_state_change("recording")
        self._frontend.on_recording_started()
        try:
            self._recorder.start_recording()
        except Exception as e:
            logger.error(f"Failed to start recording: {e}")
            if settings.BEEP_ENABLED:
                feedback.play_error_buzz()
            self._frontend.on_state_change("error")
            self._frontend.on_error("Mic unavailable")
            return

    def _on_hotkey_release(self) -> None:
        """Called when hotkey is released — process the recording."""
        wav_bytes = self._recorder.stop_recording()
        recording_duration = time.time() - self._record_start_time
        if settings.BEEP_ENABLED:
            feedback.play_stop_beep()

        if not wav_bytes or len(wav_bytes) < 200:
            logger.warning("Recording too short, ignoring")
            self._frontend.on_state_change("idle")
            self._frontend.on_recording_stopped(recording_duration)
            return

        self._frontend.on_recording_stopped(recording_duration)
        self._frontend.on_state_change("processing")
        self._frontend.on_processing()

        # Run pipeline in the event loop
        if self._loop is not None:
            self._loop.call_soon_threadsafe(
                self._loop.create_task,
                self._process_recording(wav_bytes),
            )

    async def _process_recording(self, wav_bytes: bytes) -> None:
        """Full pipeline: context -> transcribe (with auto-vocab) -> reformat -> clipboard -> history."""
        pipeline_start = time.time()
        cwd = None

        try:
            # 1. Get active window CWD + file (fast, cached)
            cwd = await self._loop.run_in_executor(self._executor, get_active_cwd)
            active_file = await self._loop.run_in_executor(self._executor, get_active_file)

            # Invalidate caches on CWD change
            if cwd != self._last_cwd:
                invalidate_cache(self._last_cwd)
                self._last_cwd = cwd

            # 2. Load project context + extract metadata (fast, cached)
            context = ""
            metadata = None
            if cwd:
                context = await self._loop.run_in_executor(self._executor, load_project_context, cwd)
                metadata = await self._loop.run_in_executor(
                    self._executor, lambda: extract_project_metadata(cwd, active_file=active_file)
                )
                if context:
                    logger.info(f"Loaded context from {cwd} ({len(context)} chars)")

            # Inject active file info into context
            if active_file:
                context = f"[active file: {active_file}]\n\n{context}" if context else f"[active file: {active_file}]"

            # 3. Merge auto-vocabulary with manual custom vocab
            manual_vocab = settings.hotwords or []
            auto_vocab = generate_project_vocabulary(metadata) if metadata else []
            hotwords = list(set(manual_vocab + auto_vocab))[:50] or None
            if auto_vocab:
                logger.info(f"Auto-vocabulary: {len(auto_vocab)} terms from project '{metadata.name or 'unknown'}'")

            # 4. Transcribe (CPU/GPU-bound, run in thread pool)
            raw_text = await self._loop.run_in_executor(
                self._executor, lambda: transcribe(wav_bytes, hotwords=hotwords)
            )

            if not raw_text.strip():
                logger.warning("Empty transcription")
                if settings.BEEP_ENABLED:
                    feedback.play_error_buzz()
                self._frontend.on_state_change("idle")
                self._frontend.on_error("No speech detected")
                return

            logger.debug(f"Raw transcription: {raw_text}")

            # 5. Reformat via LLM (with rich metadata)
            reformatted = await reformat_dictation(raw_text, context, mode=settings.MODE, metadata=metadata)
            logger.info(f"Reformatted {len(reformatted)} chars")
            logger.debug(f"Reformatted text: {reformatted[:200]}...")

            # Copy to clipboard (and auto-paste if enabled)
            success = clipboard.copy(reformatted)
            duration_ms = int((time.time() - pipeline_start) * 1000)

            if success:
                if settings.AUTO_PASTE:
                    await self._loop.run_in_executor(self._executor, clipboard.paste)
                if settings.BEEP_ENABLED:
                    feedback.play_success_chirp()
                self._frontend.on_result(raw_text, reformatted, duration_ms)
            else:
                if settings.BEEP_ENABLED:
                    feedback.play_error_buzz()
                self._frontend.on_error("Clipboard error")

            # Save to history
            history.save_entry(
                raw_text=raw_text,
                reformatted=reformatted,
                mode=settings.MODE,
                cwd=cwd,
                duration_ms=duration_ms,
            )

            self._frontend.on_state_change("idle")

        except Exception as e:
            logger.error(f"Pipeline error: {e}", exc_info=True)
            if settings.BEEP_ENABLED:
                feedback.play_error_buzz()
            self._frontend.on_state_change("error")
            self._frontend.on_error(str(e)[:60])
            # Reset to idle after a delay
            await asyncio.sleep(3)
            self._frontend.on_state_change("idle")

    async def _check_for_updates(self) -> None:
        """Background task: check for updates and download if available."""
        try:
            if not self._license_manager.updates_eligible:
                logger.info("Update check skipped — update eligibility expired (Invoke tier, >1 year)")
                return
            info = await updater.check_and_download()
            if info:
                self._frontend.notify(
                    f"Update v{info.version} ready — will apply on quit",
                    "Invoke Update",
                )
        except Exception as e:
            logger.debug(f"Update check error: {e}")

    def request_quit(self) -> None:
        """Signal the engine to shut down."""
        logger.info("Quit requested")
        if self._loop is not None:
            self._loop.call_soon_threadsafe(self._quit_event.set)

    def _shutdown(self) -> None:
        """Clean shutdown."""
        logger.info("Shutting down...")
        if self._hotkey:
            self._hotkey.stop()
        self._frontend.stop()
        history.close_db()
        unload_model()
        self._executor.shutdown(wait=False)

        # Cancel any pending async tasks before closing the loop
        if self._loop:
            pending = [t for t in asyncio.all_tasks(self._loop) if not t.done()]
            for task in pending:
                task.cancel()
            if pending:
                try:
                    self._loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                except Exception:
                    pass
            self._loop.close()

        # Apply pending update (launches installer, then we exit)
        updater.apply_pending_update()

        logger.info("Invoke stopped.")
