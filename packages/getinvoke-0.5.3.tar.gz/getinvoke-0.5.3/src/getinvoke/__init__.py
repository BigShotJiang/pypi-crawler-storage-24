"""Invoke — Voice-to-prompt for vibe coders."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("getinvoke")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
